# EXTR notes — 0001564590-23-000867


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0001564590-23-000867:notes:1]
[same as prior period, unchanged from 0001564590-22-035673:notes:1]

[0001564590-23-000867:notes:2]
[same as prior period, unchanged from 0001564590-22-035673:notes:2]

[0001564590-23-000867:notes:3]
The unaudited condensed consolidated financial statements of Extreme included herein have been prepared under the rules and regulations of the Securities and Exchange Commission (“SEC”). Certain information and footnote disclosures normally included in financial statements prepared in accordance with U.S. generally accepted accounting principles have been condensed or omitted under such rules and regulations. The condensed consolidated balance sheet at June 30, 2022 was derived from audited financial statements as of that date but does not include all disclosures required by generally accepted accounting principles for complete financial statements. These interim financial statements and notes should be read in conjunction with the Company’s audited consolidated financial statements and notes thereto included in the Company’s Annual Report on Form 10-K for the fiscal year ended June 30, 2022.

[0001564590-23-000867:notes:4]
The unaudited condensed consolidated financial statements reflect all adjustments, consisting only of normal recurring adjustments that, in the opinion of management, are necessary for a fair presentation of the results of operations and cash flows for the interim periods presented and the financial condition of Extreme at December 31, 2022. The results of operations for the three and six months ended December 31, 2022 are not necessarily indicative of the results that may be expected for fiscal 2023 or any future periods.

[0001564590-23-000867:notes:5]
[same as prior period, unchanged from 0001564590-22-035673:notes:5]

[0001564590-23-000867:notes:6]
The Company uses a fiscal calendar year ending on June 30. All references herein to “fiscal 2023” represent the fiscal year ending June 30, 2023. All references herein to “fiscal 2022”  represent the fiscal year ended June 30, 2022.

[0001564590-23-000867:notes:7]
[same as prior period, unchanged from 0001564590-22-035673:notes:7]

[0001564590-23-000867:notes:8]
[same as prior period, unchanged from 0001564590-22-035673:notes:8]

[0001564590-23-000867:notes:9]
[same as prior period, unchanged from 0001564590-22-035673:notes:9]

[0001564590-23-000867:notes:10]
[same as prior period, unchanged from 0001564590-22-035673:notes:10]

[0001564590-23-000867:notes:11]
[same as prior period, unchanged from 0001564590-22-035673:notes:11]


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001564590-23-000867:notes:12]
[same as prior period, unchanged from 0001564590-22-035673:notes:12]

[0001564590-23-000867:notes:13]
[same as prior period, unchanged from 0001564590-22-035673:notes:13]

[0001564590-23-000867:notes:14]
Recently Adopted and Recently Issued Accounting Pronouncements

[0001564590-23-000867:notes:15]
In December 2022, the Financial Accounting Standards Board (“FASB”) issued Accounting Standard Update (“ASU”) 2022-06, Reference Rate Reform (Topic 848): Deferral of the Sunset Date of Topic 848, which extends the period of time entities can utilize the reference rate reform relief guidance under ASU 2020-04, Reference Rate Reform (Topic 848): Facilitation of the Effects of Reference Rate Reform on Financial Reporting from December 31, 2022 to December 31, 2024. Upon issuance of ASU 2020-04, the Company elected to apply certain of the optional expedients for contract modifications to its financial instruments impacted by the London Interbank Offered Rate (“LIBOR”) discontinuance. The Company expects to continue to elect various optional expedients for contract

[0001564590-23-000867:notes:16]
modifications to the Company’s financial instruments affected by the reference rate reform through the effective date of December 31, 2024, as extended by ASU 2022-06. The application of this guidance did not have any impact on our consolidated financial statements.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001564590-23-000867:notes:17]
[same as prior period, unchanged from 0001564590-22-035673:notes:16]

[0001564590-23-000867:notes:18]
The Company accounts for revenues in accordance with ASU 2014-09, Revenue from Contracts from Customers (Topic 606). The Company derives the majority of its revenues from sales of its networking equipment, with the remaining revenues generated from sales of services and subscriptions, which primarily includes maintenance contracts and software subscriptions delivered as software as a service (“SaaS”) and additional revenues from professional services, and training for its products. The Company sells its products, maintenance contracts and SaaS direct to customers and to partners in two distribution channels, or tiers. The first tier consists of a limited number of independent distributors that stock its products and sell primarily to resellers. The second tier of the distribution channel consists of non-stocking distributors and value-added resellers that sell directly to end-users. Products and services may be sold separately or in bundled packages.

[0001564590-23-000867:notes:19]
[same as prior period, unchanged from 0001564590-22-035673:notes:18]

[0001564590-23-000867:notes:20]
[same as prior period, unchanged from 0001564590-22-035673:notes:19]

[0001564590-23-000867:notes:21]
[same as prior period, unchanged from 0001564590-22-035673:notes:20]

[0001564590-23-000867:notes:22]
On December 31, 2022, the Company had $445.6 million of remaining performance obligations, which are primarily comprised of deferred maintenance and SaaS revenues. The Company expects to recognize approximately 36% of its deferred revenue as revenue in the remainder of fiscal 2023, an additional 34% in fiscal 2024 and 30% of the balance thereafter.

[0001564590-23-000867:notes:23]
[same as prior period, unchanged from 0001564590-22-035673:notes:22]

[0001564590-23-000867:notes:24]
Revenue recognized for the three months ended December 31, 2022 and 2021 that was included in the deferred revenue balance at the beginning of each period was $83.9 million and $81.9 million, respectively. Revenue recognized for the six months ended December 31, 2022 and 2021 that was included in the deferred revenue balance at the beginning of each period was $145.7 million and $132.5 million, respectively.

[0001564590-23-000867:notes:25]
Contract Costs. The Company recognizes the incremental costs of obtaining contracts as an expense when incurred if the amortization period of the assets that the Company otherwise would have recognized is one year or less. Management expects that commission fees paid to sales representatives as a result of obtaining service and subscription contracts and contract renewals are recoverable and therefore the Company’s condensed consolidated balance sheets included capitalized balances in the amount of $17.5 million and $16.3 million at December 31, 2022 and June 30, 2022, respectively. Capitalized commissions are included within other assets in the condensed consolidated balance sheets. Capitalized commission fees are amortized on a straight-line basis over the average period of service contracts of approximately three years, and are included in “Sales and marketing” in the accompanying condensed consolidated statements of operations. Amortization recognized during the three months ended December 31, 2022 and 2021, was $ 2.2 million and $1.8 million, respectively. Amortization recognized during the six months ended December 31, 2022 and 2021, was $4.3 million and $3.6 million, respectively.

[0001564590-23-000867:notes:26]
[same as prior period, unchanged from 0001564590-22-035673:notes:25]

[0001564590-23-000867:notes:27]
[same as prior period, unchanged from 0001564590-22-035673:notes:26]

[0001564590-23-000867:notes:28]
The Company operates in three geographic regions: Americas, EMEA (Europe, Middle East and Africa) and APAC (Asia Pacific). The following table sets forth the Company’s revenues disaggregated by sales channel and geographic region based on the billing addresses of its customers (in thousands):

[0001564590-23-000867:notes:29]
|  |  | Three Months Ended |  |
|  |  | December 31, 2022 |  |  | December 31, 2021 |  |
|  |  | Distributor |  | Direct |  | Total |  |  | Distributor |  | Direct |  | Total |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  | $ | 70,963 |  | $ | 66,630 |  | $ | 137,593 |  |  | $ | 68,565 |  | $ | 68,585 |  | $ | 137,150 |  |
| Other |  |  | 10,807 |  |  | 4,614 |  |  | 15,421 |  |  |  | 3,865 |  |  | 4,955 |  |  | 8,820 |  |
| Total Americas |  |  | 81,770 |  |  | 71,244 |  |  | 153,014 |  |  |  | 72,430 |  |  | 73,540 |  |  | 145,970 |  |
| EMEA |  |  | 97,147 |  |  | 40,903 |  |  | 138,050 |  |  |  | 68,934 |  |  | 42,128 |  |  | 111,062 |  |
| APAC |  |  | 7,403 |  |  | 19,881 |  |  | 27,284 |  |  |  | 5,034 |  |  | 18,867 |  |  | 23,901 |  |
| Total net revenues |  | $ | 186,320 |  | $ | 132,028 |  | $ | 318,348 |  |  | $ | 146,398 |  | $ | 134,535 |  | $ | 280,933 |  |

[0001564590-23-000867:notes:30]
|  |  | Six Months Ended |  |
|  |  | December 31, 2022 |  |  | December 31, 2021 |  |
|  |  | Distributor |  | Direct |  | Total |  |  | Distributor |  | Direct |  | Total |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  | $ | 144,277 |  | $ | 130,942 |  | $ | 275,219 |  |  | $ | 124,633 |  | $ | 135,916 |  | $ | 260,549 |  |
| Other |  |  | 26,832 |  |  | 8,712 |  |  | 35,544 |  |  |  | 11,664 |  |  | 8,322 |  |  | 19,986 |  |
| Total Americas |  |  | 171,109 |  |  | 139,654 |  |  | 310,763 |  |  |  | 136,297 |  |  | 144,238 |  |  | 280,535 |  |
| EMEA |  |  | 173,403 |  |  | 80,156 |  |  | 253,559 |  |  |  | 146,832 |  |  | 77,859 |  |  | 224,691 |  |
| APAC |  |  | 9,441 |  |  | 42,274 |  |  | 51,715 |  |  |  | 9,369 |  |  | 34,022 |  |  | 43,391 |  |
| Total net revenues |  | $ | 353,953 |  | $ | 262,084 |  | $ | 616,037 |  |  | $ | 292,498 |  | $ | 256,119 |  | $ | 548,617 |  |

[0001564590-23-000867:notes:31]
For three months ended December 31, 2022 the Company generated 11% and 10% of its revenues from the Netherlands and Germany, respectively. For the six months ended December 31, 2022 the Company generated 10% each of its revenues from the Netherlands and Germany. For the six months ended December 31, 2021 the Company generated 10% of its revenues from the Netherlands. No other foreign country accounted for 10% or more of revenue for the three and six months ended December 31, 2022 and 2021.

[0001564590-23-000867:notes:32]
[same as prior period, unchanged from 0001564590-22-035673:notes:30]

[0001564590-23-000867:notes:33]
[same as prior period, unchanged from 0001564590-22-035673:notes:31]

[0001564590-23-000867:notes:34]
[same as prior period, unchanged from 0001564590-22-035673:notes:32]

[0001564590-23-000867:notes:35]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | December 31, 2022 |  |  | December 31, 2021 |  |  | December 31, 2022 |  |  | December 31, 2021 |  |
| Westcon Group, Inc. |  | 19% |  |  | 11% |  |  | 17% |  |  | 15% |  |
| TD Synnex Corporation |  | 17% |  |  | 21% |  |  | 18% |  |  | 22% |  |
| Jenne, Inc. |  | 13% |  |  | 18% |  |  | 13% |  |  | 16% |  |
| ScanSource, Inc. |  | 11% |  |  | * |  |  | * |  |  | * |  |
| * Less than 10% of revenue |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |

[0001564590-23-000867:notes:36]
[same as prior period, unchanged from 0001564590-22-035673:notes:34]

[0001564590-23-000867:notes:37]
|  |  | December 31, 2022 |  |  | June 30, 2022 |  |
| Jenne, Inc. |  | 16% |  |  | 28% |  |
| ScanSource, Inc. |  | 10% |  |  | * |  |
| TD Synnex Corporation |  | 10% |  |  | 11% |  |
| * Less than 10% of accounts receivable. |  |  |  |  |  |  |  |  |


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001564590-23-000867:notes:38]
[same as prior period, unchanged from 0001564590-22-035673:notes:36]

[0001564590-23-000867:notes:39]
[same as prior period, unchanged from 0001564590-22-035673:notes:37]

[0001564590-23-000867:notes:40]
[same as prior period, unchanged from 0001564590-22-035673:notes:38]

[0001564590-23-000867:notes:41]
On September 14, 2021 (the “Acquisition Date”), the Company completed its acquisition (the “Acquisition”) of Ipanematech SAS (“Ipanema”), the cloud-native enterprise Software-Defined Wide Area Network (“SD-WAN”) business unit of Infovista pursuant to a Sale and Purchase Agreement. Under the terms of the Acquisition, the net consideration paid by Extreme to Ipanema stockholders was $70.9 million, which was funded through cash on hand. The primary reason for the acquisition was to acquire the talent and the technology to allow the Company to expand its portfolio with new cloud-managed SD-WAN and security offerings to support its enterprise customers.

[0001564590-23-000867:notes:42]
[same as prior period, unchanged from 0001564590-22-035673:notes:41]

[0001564590-23-000867:notes:43]
[same as prior period, unchanged from 0001564590-22-035673:notes:42]

[0001564590-23-000867:notes:44]
[same as prior period, unchanged from 0001564590-22-035673:notes:43]

[0001564590-23-000867:notes:45]
The unaudited pro forma financial information for the three and six months ended December 31, 2021 combines the historical results for Extreme for that period, which include the results of Ipanema subsequent to the Acquisition Date, and Ipanema’s historical results up to the Acquisition Date.

[0001564590-23-000867:notes:46]
[same as prior period, unchanged from 0001564590-22-035673:notes:45]

[0001564590-23-000867:notes:47]
|  | Three months ended |  | Six Months Ended |
|  | December 31, 2021* |  | December 31, 2021* |  |  |
| Net revenues | $ | 280,438 |  | $ | 551,743 |  |  |
| Net income | $ | 15,562 |  | $ | 29,631 |  |  |
| Net income per share – basic | $ | 0.12 |  | $ | 0.23 |  |  |
| Net income per share – diluted | $ | 0.12 |  | $ | 0.22 |  |  |
| Shares used in per share calculation – basic |  | 129,403 |  |  | 128,863 |  |  |
| Shares used in per share calculation – diluted |  | 133,621 |  |  | 133,423 |  |  |

[0001564590-23-000867:notes:48]
*Amount reflects the adoption of ASU 2021-08, Business Combinations (Topic 805): Accounting for Contract Assets and Contract Liabilities from Contracts with Customers, which the Company early adopted the standard in the quarter ended December 31, 2021 and retrospectively applied to the fiscal year beginning July 1, 2021.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001564590-23-000867:notes:49]
[same as prior period, unchanged from 0001564590-22-035673:notes:48]

[0001564590-23-000867:notes:50]
[same as prior period, unchanged from 0001564590-22-035673:notes:49]

[0001564590-23-000867:notes:51]
[same as prior period, unchanged from 0001564590-22-035673:notes:50]

[0001564590-23-000867:notes:52]
[same as prior period, unchanged from 0001564590-22-035673:notes:51]

[0001564590-23-000867:notes:53]
|  |  | December 31, 2022 |  |  | June 30, 2022 |  |
| Finished goods |  | $ | 55,721 |  |  | $ | 40,733 |  |
| Raw materials |  |  | 8,042 |  |  |  | 8,498 |  |
| Total inventories |  | $ | 63,763 |  |  | $ | 49,231 |  |

[0001564590-23-000867:notes:54]
[same as prior period, unchanged from 0001564590-22-035673:notes:53]

[0001564590-23-000867:notes:55]
[same as prior period, unchanged from 0001564590-22-035673:notes:54]

[0001564590-23-000867:notes:56]
|  |  | December 31, 2022 |  |  | June 30, 2022 |  |
| Computers and equipment |  | $ | 78,042 |  |  | $ | 75,387 |  |
| Purchased software |  |  | 49,285 |  |  |  | 47,161 |  |
| Office equipment, furniture and fixtures |  |  | 9,465 |  |  |  | 9,463 |  |
| Leasehold improvements |  |  | 53,098 |  |  |  | 52,564 |  |
| Total property and equipment |  |  | 189,890 |  |  |  | 184,575 |  |
| Less: accumulated depreciation and amortization |  |  | (144,179 | ) |  |  | (134,997 | ) |
| Property and equipment, net |  | $ | 45,711 |  |  | $ | 49,578 |  |

[0001564590-23-000867:notes:57]
[same as prior period, unchanged from 0001564590-22-035673:notes:56]

[0001564590-23-000867:notes:58]
[same as prior period, unchanged from 0001564590-22-035673:notes:57]

[0001564590-23-000867:notes:59]
[same as prior period, unchanged from 0001564590-22-035673:notes:58]

[0001564590-23-000867:notes:60]
[same as prior period, unchanged from 0001564590-22-035673:notes:59]

[0001564590-23-000867:notes:61]
The following table summarizes the activity related to the Company’s product warranty liability during the three and six months ended December 31, 2022 and 2021 (in thousands):

[0001564590-23-000867:notes:62]
|  |  | Three Months Ended |  |  | Six Months Ended |  |  |
|  |  | December 31, 2022 |  |  | December 31, 2021 |  |  | December 31, 2022 |  |  | December 31, 2021 |  |  |
| Balance beginning of period |  | $ | 11,522 |  |  | $ | 10,780 |  |  | $ | 10,852 |  |  | $ | 11,623 |  |  |
| Warranties assumed due to acquisition |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 41 |  |  |
| New warranties issued |  |  | 3,807 |  |  |  | 3,822 |  |  |  | 7,815 |  |  |  | 6,532 |  |  |
| Warranty expenditures |  |  | (3,509 | ) |  |  | (3,465 | ) |  |  | (6,847 | ) |  |  | (7,059 | ) |  |
| Balance end of period |  | $ | 11,820 |  |  | $ | 11,137 |  |  | $ | 11,820 |  |  | $ | 11,137 |  |  |

[0001564590-23-000867:notes:63]
[same as prior period, unchanged from 0001564590-22-035673:notes:62]

[0001564590-23-000867:notes:64]
[same as prior period, unchanged from 0001564590-22-035673:notes:63]

[0001564590-23-000867:notes:65]
[same as prior period, unchanged from 0001564590-22-035673:notes:64]


## us-gaap:FairValueDisclosuresTextBlock

[0001564590-23-000867:notes:66]
[same as prior period, unchanged from 0001564590-22-035673:notes:65]

[0001564590-23-000867:notes:67]
[same as prior period, unchanged from 0001564590-22-035673:notes:66]

[0001564590-23-000867:notes:68]
[same as prior period, unchanged from 0001564590-22-035673:notes:67]

[0001564590-23-000867:notes:69]
[same as prior period, unchanged from 0001564590-22-035673:notes:68]

[0001564590-23-000867:notes:70]
[same as prior period, unchanged from 0001564590-22-035673:notes:69]

[0001564590-23-000867:notes:71]
The following table presents the Company’s fair value hierarchy for its financial assets and liabilities measured at fair value on a recurring basis at December 31, 2022 and June 30, 2022 (in thousands).

[0001564590-23-000867:notes:72]
| December 31, 2022 |  | Level 1 |  |  | Level 2 |  |  | Level 3 |  |  | Total |  |
| Assets |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency derivatives |  | $ | — |  |  | $ | 475 |  |  | $ | — |  |  | $ | 475 |  |
| Interest rate swaps |  |  | — |  |  |  | 808 |  |  |  | — |  |  |  | 808 |  |
| Total assets measured at fair value |  | $ | — |  |  | $ | 1,283 |  |  | $ | — |  |  | $ | 1,283 |  |
| Liabilities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency derivatives |  | $ | — |  |  | $ | 8 |  |  | $ | — |  |  | $ | 8 |  |
| Total liabilities measured at fair value |  | $ | — |  |  | $ | 8 |  |  | $ | — |  |  | $ | 8 |  |

[0001564590-23-000867:notes:73]
[same as prior period, unchanged from 0001564590-22-035673:notes:72]

[0001564590-23-000867:notes:74]
[same as prior period, unchanged from 0001564590-22-035673:notes:73]

[0001564590-23-000867:notes:75]
[same as prior period, unchanged from 0001564590-22-035673:notes:74]

[0001564590-23-000867:notes:76]
As of December 31, 2022 and June 30, 2022, the Company had foreign exchange forward contracts that were not designated as hedging instruments with notional principal amounts of $11.1 million and $9.6 million, respectively. These contracts have maturities of 60 days or less. Changes in the fair value of these foreign exchange forward contracts not designated as hedging instruments are included in other income or expenses in the condensed consolidated statement of operations. For the three and six months ended December 31, 2022, there were net gains of $0.1 million and net losses of $0.4 million, respectively. For the three and six months ended December 31, 2021, there were net losses of less than $0.1 million and $0.2 million, respectively. As of December 31, 2022, the Company had foreign exchange forward contracts that were designated as hedging instruments with a notional principal amount of $5.5 million. These contracts have maturities of less than twelve months. Gains and losses arising from these contracts designated as hedging instruments are recorded as a component of accumulated other comprehensive income (loss). As of December 31, 2022, these contracts had an unrealized gain of $0.4 million. As of June 30, 2022, there were no outstanding foreign exchange forward contracts that were designated as hedging instruments. See Note 13, Derivatives and Hedging, for additional information.

[0001564590-23-000867:notes:77]
The fair values of the interest rate swaps are based upon inputs corroborated by observable market data which is considered Level 2. As of December 31, 2022 and June 30, 2022, the Company had interest rate swap contracts, designated as cash flow hedges, with the total notional amount of $75.0 million. Changes in the fair value of these contracts are recorded as a component of accumulated other comprehensive income (loss). As of December 31, 2022 and June 30, 2022, these contracts had unrealized gains of $0.8 million and $1.3 million, respectively. See Note 13, Derivatives and Hedging, for additional information.

[0001564590-23-000867:notes:78]
The fair value of borrowings under the 2019 Credit Agreement (as defined in Note 8) is estimated based on valuations provided by alternative pricing sources supported by observable inputs which is considered Level 2. Since the interest rate is variable for the 2019 Credit Agreement, the fair value approximates the face amount of the Company’s indebtedness of $262.0 million and $308.6 million as of December 31, 2022 and June 30, 2022, respectively.

[0001564590-23-000867:notes:79]
[same as prior period, unchanged from 0001564590-22-035673:notes:78]

[0001564590-23-000867:notes:80]
As of December 31, 2022, and June 30, 2022, the Company did not have any asset or liability that were considered Level 3.

[0001564590-23-000867:notes:81]
There were no transfers of assets or liabilities between Level 1, Level 2 and Level 3 during the three and six months ended December 31, 2022 and 2021. There were no impairments recorded for the three and six months ended December 31, 2022 and 2021.


## us-gaap:IntangibleAssetsDisclosureTextBlock

[0001564590-23-000867:notes:82]
| 7. | Intangible Assets and Goodwill |

[0001564590-23-000867:notes:83]
Intangible Assets

[0001564590-23-000867:notes:84]
[same as prior period, unchanged from 0001564590-22-035673:notes:82]

[0001564590-23-000867:notes:85]
|  |  | Weighted Average |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Remaining Amortization |  | Gross Carrying |  |  | Accumulated |  |  | Net Carrying |  |
|  |  | Period |  | Amount |  |  | Amortization |  |  | Amount |  |
| December 31, 2022 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Developed technology |  | 3.0 years |  | $ | 169,203 |  |  | $ | 153,441 |  |  | $ | 15,762 |  |
| Customer relationships |  | 3.4 years |  |  | 64,665 |  |  |  | 57,728 |  |  |  | 6,937 |  |
| Trade names |  | 0.0 years |  |  | 10,700 |  |  |  | 10,700 |  |  |  | — |  |
| License agreements |  | 3.9 years |  |  | 2,445 |  |  |  | 2,160 |  |  |  | 285 |  |
| Total intangibles, net* |  |  |  | $ | 247,013 |  |  | $ | 224,029 |  |  | $ | 22,984 |  |
| * Foreign intangible assets carrying amounts are affected by foreign currency translation. |  |  |  |  |  |

[0001564590-23-000867:notes:86]
|  |  | Weighted Average |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Remaining Amortization |  | Gross Carrying |  |  | Accumulated |  |  | Net Carrying |  |
|  |  | Period |  | Amount |  |  | Amortization |  |  | Amount |  |
| June 30, 2022 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Developed technology |  | 3.3 years |  | $ | 170,600 |  |  | $ | 146,560 |  |  | $ | 24,040 |  |
| Customer relationships |  | 3.9 years |  |  | 64,839 |  |  |  | 56,704 |  |  |  | 8,135 |  |
| Trade names |  | 0.1 years |  |  | 10,700 |  |  |  | 10,680 |  |  |  | 20 |  |
| License agreements |  | 4.4 years |  |  | 2,445 |  |  |  | 2,125 |  |  |  | 320 |  |
| Total intangibles, net* |  |  |  | $ | 248,584 |  |  | $ | 216,069 |  |  | $ | 32,515 |  |

[0001564590-23-000867:notes:87]
| * Foreign intangible assets carrying amounts are affected by foreign currency translation. |

[0001564590-23-000867:notes:88]
[same as prior period, unchanged from 0001564590-22-035673:notes:85]

[0001564590-23-000867:notes:89]
|  |  | Three Months Ended |  |  | Six Months Ended |  |  |
|  |  | December 31, 2022 |  |  | December 31, 2021 |  |  | December 31, 2022 |  |  | December 31, 2021 |  |  |
| Amortization of intangibles in “Total cost of revenues” |  | $ | 3,220 |  |  | $ | 4,149 |  |  | $ | 6,825 |  |  | $ | 9,435 |  |  |
| Amortization of intangibles in “Total operating expenses” |  |  | 504 |  |  |  | 804 |  |  |  | 1,027 |  |  |  | 1,958 |  |  |
| Total amortization expense |  | $ | 3,724 |  |  | $ | 4,953 |  |  | $ | 7,852 |  |  | $ | 11,393 |  |  |

[0001564590-23-000867:notes:90]
The amortization expense that is recognized in “Total cost of revenues” is comprised of amortization for most of the developed technology and license agreements.

[0001564590-23-000867:notes:91]
[same as prior period, unchanged from 0001564590-22-035673:notes:88]

[0001564590-23-000867:notes:92]
| For the fiscal year ending: |  |  |  |  |
| 2023 (the remainder of fiscal 2023) |  | $ | 7,166 |  |
| 2024 |  |  | 5,212 |  |
| 2025 |  |  | 4,450 |  |
| 2026 |  |  | 3,191 |  |
| 2027 |  |  | 1,430 |  |
| Thereafter |  |  | 1,535 |  |
| Total |  | $ | 22,984 |  |

[0001564590-23-000867:notes:93]
Goodwill

[0001564590-23-000867:notes:94]
The Company had Goodwill in the amount of $393.5 million and $400.1 million as of December 31, 2022 and June 30, 2022, respectively. The change in goodwill during the six months ended December 31, 2022 is due to foreign currency translation adjustment that is recorded as a component of accumulated other comprehensive loss.


## us-gaap:DebtDisclosureTextBlock

[0001564590-23-000867:notes:95]
| 8. | Debt |

[0001564590-23-000867:notes:96]
The Company’s debt is comprised of the following (in thousands):

[0001564590-23-000867:notes:97]
|  |  | December 31, 2022 |  |  | June 30, 2022 |  |
| Current portion of long-term debt: |  |  |  |  |  |  |  |  |
| Term Loan |  | $ | 38,000 |  |  | $ | 35,625 |  |
| Less: unamortized debt issuance costs |  |  | (2,181 | ) |  |  | (2,276 | ) |
| Current portion of long-term debt |  | $ | 35,819 |  |  | $ | 33,349 |  |
| Long-term debt, less current portion: |  |  |  |  |  |  |  |  |
| Term Loan |  | $ | 224,000 |  |  | $ | 273,000 |  |
| Less: unamortized debt issuance costs |  |  | (1,331 | ) |  |  | (2,430 | ) |
| Total long-term debt, less current portion |  |  | 222,669 |  |  |  | 270,570 |  |
| Total debt |  | $ | 258,488 |  |  | $ | 303,919 |  |

[0001564590-23-000867:notes:98]
On August 9, 2019, the Company entered into an Amended and Restated Credit Agreement (the “2019 Credit Agreement”), by and among the Company, as borrower, several banks and other financial institutions as Lenders, BMO Harris Bank N.A., as an issuing lender and swingline lender, Silicon Valley Bank, as an Issuing Lender, and Bank of Montreal, as administrative agent and collateral agent for the Lenders.

[0001564590-23-000867:notes:99]
The 2019 Credit Agreement provides for a five-year first lien term loan facility in an aggregate principal amount of $380.0 million and a five-year revolving loan facility in an aggregate principal amount of $75.0 million (the “2019 Revolving Facility”). In addition, the Company may request incremental term loans and/or incremental revolving loan commitments in an aggregate amount not to exceed the sum of $100.0 million, plus an unlimited amount that is subject to pro forma compliance with certain financial tests. On August 9, 2019, the Company used the additional proceeds from the term loan to partially fund the acquisition of Aerohive Networks, Inc. and for working capital and general corporate purposes.

[0001564590-23-000867:notes:100]
At the Company’s election, the initial term loan under the 2019 Credit Agreement may be made as either base rate loans or Eurodollar loans. The applicable margin for base rate loans ranges from 0.25% to 2.50% per annum and the applicable margin for Eurodollar loans ranges from 1.25% to 3.50%, in each case based on Extreme’s consolidated leverage ratio. All Eurodollar loans are subject to a Base Rate of 0.00%. In addition, the Company is required to pay a commitment fee of between 0.25% and 0.40% quarterly (currently 0.25%) on the unused portion of the 2019 Revolving Facility, also based on the Company’s consolidated leverage ratio. Principal installments are payable on the new term loan in varying percentages quarterly starting December 31, 2019 and to the extent not previously paid, all outstanding balances are to be paid at maturity. The 2019 Credit Agreement is secured by substantially all of the Company’s assets.

[0001564590-23-000867:notes:101]
The 2019 Credit Agreement requires the Company to maintain certain minimum financial ratios at the end of each fiscal quarter. The 2019 Credit Agreement also includes covenants and restrictions that limit, among other things, the Company’s ability to incur additional indebtedness, create liens upon any of its property, merge, consolidate or sell all or substantially all of its assets. The 2019 Credit Agreement also includes customary events of default which may result in acceleration of the payment of the outstanding balance.

[0001564590-23-000867:notes:102]
On April 8, 2020, the Company entered into an amendment to the 2019 Credit Agreement (the “First Amendment”) to waive certain terms and financial covenants of the 2019 Credit Agreement through July 31, 2020. On May 8, 2020, the Company entered into a second amendment to the 2019 Credit Agreement (the “Second Amendment”), which superseded the First Amendment and provided certain revised terms and financial covenants through March 31, 2021. The Second Amendment required the Company to maintain certain minimum cash requirement and financial metrics at the end of each fiscal quarter through March 31, 2021 and the Company was restricted from pursuing certain activities such as incurring additional debt, stock repurchases, making acquisitions or declaring a dividend, until the Company was in compliance with the original covenants of the 2019 Credit Agreement.

[0001564590-23-000867:notes:103]
On November 3, 2020, the Company and its lenders entered into a Third Amendment to the 2019 Credit Agreement (the “Third Amendment”), to increase the sublimit for letters of credit to $20.0 million. On December 8, 2020, the Company and its lenders entered into a fourth amendment to the 2019 Credit Agreement (the “Fourth Amendment”), to waive and amend certain terms and financial covenants within the 2019 Credit Agreement through March 31, 2021.

[0001564590-23-000867:notes:104]
The Second Amendment provided for the Company to end the covenant Suspension Period early and revert to the covenants and interest rates per the original terms of the 2019 Credit Agreement dated August 9, 2019 by filing a Suspension Period Early Termination Notice and Covenant Certificate demonstrating compliance. For the twelve-month period ended March 31, 2021, the Company’s financial performance was in compliance with the original covenants defined in the 2019 Credit Agreement and, as such, the Company filed a Suspension Early Termination Notice and Covenant Certificate with the administration agent subsequent to filing the Company’s Quarterly Report on Form 10-Q for the period ended March 31, 2021. Returning to compliance, the original terms and

[0001564590-23-000867:notes:105]
financial covenants under the 2019 Credit Agreement dated August 9, 2019 resumed in effect. During the three and six months ended December 31, 2022, the Company was in compliance with all the terms and financial covenants under the 2019 Credit Agreement.

[0001564590-23-000867:notes:106]
Financing costs incurred in connection with obtaining long-term financing are deferred and amortized over the term of the related indebtedness or credit agreement. Amortization of deferred financing costs included in “Interest expense” in the accompanying condensed consolidated statements of operations were $0.7 million for each of the three months ended December 31, 2022 and 2021 and totaled $1.5 million for each of the six months ended December 31, 2022 and 2021. The interest rate as of December 31, 2022 was 5.5% and as of December 31, 2021 was 1.86%.

[0001564590-23-000867:notes:107]
As of December 31, 2022, the Company did not have any outstanding balance against its 2019 Revolving Facility’s outstanding balance. The Company had $60.2 million of availability under the 2019 Revolving Facility as of December 31, 2022. During the six months ended December 31, 2022 and 2021, the Company made an additional payment of $30.0 million and $12.0 million against its term loan facility, respectively.

[0001564590-23-000867:notes:108]
The Company had $14.8 million of outstanding letters of credit as of December 31, 2022.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001564590-23-000867:notes:109]
| 9. | Commitments and Contingencies |

[0001564590-23-000867:notes:110]
Purchase Commitments

[0001564590-23-000867:notes:111]
The Company currently has arrangements with contract manufacturers and suppliers for the manufacture of its products. Those arrangements allow the contract manufacturers to procure long lead-time component inventory based upon a rolling production forecast provided by the Company. The Company is obligated to purchase long lead-time component inventory that its contract manufacturer procures in accordance with the forecast, unless the Company gives notice of order cancellation outside of applicable component lead-times. As of December 31, 2022, the Company had commitments to purchase $57.1 million of inventory.

[0001564590-23-000867:notes:112]
Legal Proceedings

[0001564590-23-000867:notes:113]
The Company may from time to time be party to litigation arising in the course of its business, including, without limitation, allegations relating to commercial transactions, business relationships or intellectual property rights. Such claims, even if not meritorious, could result in the expenditure of significant financial and managerial resources. Litigation in general, and intellectual property in particular, can be expensive and disruptive to normal business operations. Moreover, the results of legal proceedings are difficult to predict.

[0001564590-23-000867:notes:114]
In accordance with applicable accounting guidance, the Company records accruals for certain of its outstanding legal proceedings, investigations or claims when it is probable that a liability will be incurred, and the amount of loss can be reasonably estimated. The Company evaluates, at least on a quarterly basis, developments in legal proceedings, investigations or claims that could affect the amount of any accrual, as well as any developments that would result in a loss contingency to become both probable and reasonably estimable. When a loss contingency is not both probable and reasonably estimable, the Company does not record a loss accrual. However, if the loss (or an additional loss in excess of any prior accrual) is at least reasonably possible and material, then the Company would disclose an estimate of the possible loss or range of loss, if such estimate can be made, or disclose that an estimate cannot be made. The assessment whether a loss is probable or a reasonable possibility, and whether the loss or a range of loss is estimable, involves a series of complex judgments about future events. Even if a loss is reasonably possible, the Company may not be able to estimate a range of possible loss, particularly where (i) the damages sought are substantial or indeterminate, (ii) the proceedings are in the early stages, or (iii) the matters involve novel or unsettled legal theories or a large number of parties. In such cases, there is considerable uncertainty regarding the ultimate resolution of such matters, including the amount of any possible loss, fine or penalty.  However, an adverse resolution of one or more of such matters could have a material adverse effect on the Company's results of operations in a particular quarter or fiscal year.

[0001564590-23-000867:notes:115]
XR Communications, LLC d/b/a Vivato Technologies v. Extreme Networks, Inc.

[0001564590-23-000867:notes:116]
On April 19, 2017, XR Communications, LLC (“XR”) (d/b/a Vivato Technologies) filed a patent infringement lawsuit against the Company in the Central District of California. The operative Second Amended Complaint asserts infringement of certain U.S. Patents based on the Company’s manufacture, use, sale, offer for sale, and/or importation into the United States of certain access points and routers supporting multi-user, multiple-input, multiple-output technology. XR seeks unspecified damages, on-going royalties, pre- and post-judgment interest, and attorneys’ fees. The Court dismissed the case without prejudice on January 4, 2022 and on April 18, 2022, entered final judgment in favor of the Company. XR filed a notice of appeal on May 9, 2022 and the Company and other defendants filed a response brief on November 7, 2022.

[0001564590-23-000867:notes:117]
Orckit IP, LLC v. Extreme Networks, Inc., Extreme Networks Ireland Ltd., and Extreme Networks GmbH

[0001564590-23-000867:notes:118]
On February 1, 2018, Orckit IP, LLC (“Orckit”) filed a patent infringement lawsuit against the Company and its Irish and German subsidiaries in the District Court in Dusseldorf, Germany. The lawsuit alleges direct and indirect infringement of the German portion of a patent (“EP ‘364”) based on the offer, distribution, use, possession and/or importation into Germany of certain network switches that are equipped with the ExtremeXOS operating system. Orckit is seeking injunctive relief, accounting, and an unspecified declaration of liability for damages and costs of the lawsuit. On January 28, 2020, the Court rendered a decision in the infringement case in favor of the Company. The matter is proceeding through the appellate process.

[0001564590-23-000867:notes:119]
On April 23, 2019, Orckit filed an extension of the patent infringement complaint against the Company and its Irish and German subsidiaries in the District Court in Dusseldorf, Germany. With this extension, Orckit alleges infringement of the German portion of a second patent (“EP ‘077”) based on the offer, distribution, use, possession and/or importation into Germany of certain network switches that the Company no longer sells in Germany. Orckit is seeking injunctive relief, accounting and sales information, and a declaration of liability for damages as well as costs of the lawsuit. On October 13, 2020, the Court issued an infringement decision against the Company and granted Orckit the right to enforce the judgment against the Company, which Orckit has provided notification to the Company that it will enforce the judgment. In the rendering of account, Orckit was informed that the products at issue were in end of sale status prior to the filing of the EP ‘077 complaint. The Company has appealed the infringement decision, and the matter is proceeding through the appellate process.

[0001564590-23-000867:notes:120]
The Company filed a nullity action related to the EP ‘364 patent on May 3, 2018, and one related to the EP ‘077 patent on October 31, 2019, both in the Federal Patent Court in Munich. The Federal Patent Court in Munich found the EP ‘364 patent to be valid and the Company has filed an appeal. On October 25, 2022, the Federal Patent Court in Munich issued an opinion partially invalidating the EP ‘077 patent and the Company has filed an appeal.

[0001564590-23-000867:notes:121]
SNMP Research, Inc. and SNMP Research International, Inc. v. Broadcom Inc., Brocade Communications Systems LLC, and Extreme Networks, Inc.

[0001564590-23-000867:notes:122]
On October 26, 2020, SNMP Research, Inc. and SNMP Research International, Inc. (collectively, “SNMP”) filed a lawsuit against the Company in the Eastern District of Tennessee for copyright infringement, alleging that the Company was not properly licensed to use its software.  SNMP is seeking actual damages and profits attributed to the infringement, as well as equitable relief. The Company filed a motion to transfer the case to the Northern District of California. The motion to dismiss was denied in part and denied without prejudice in part. The Company also filed, and was granted, a motion to compel mediation. The parties conducted a  mediation from January 19 to January 26, 2023. The trial date set for February 2023 has been rescheduled to January 2024.

[0001564590-23-000867:notes:123]
Mala Technologies Ltd. v. Extreme Networks GmbH, Extreme Networks Ireland Ops Ltd., and Extreme Networks, Inc.

[0001564590-23-000867:notes:124]
On April 15, 2021, Mala Technologies Ltd. (“Mala”) filed a patent infringement lawsuit against the Company and its Irish and German subsidiaries in the District Court in Dusseldorf, Germany.  The lawsuit alleges indirect infringement of the German portion of a patent (“EP ‘498”) based on the offer and sale in Germany of certain network switches equipped with the ExtremeXOS operating system.  Mala is seeking injunctive relief, accounting, and an unspecified declaration of liability for damages and costs of the lawsuit. On December 20, 2022, the trial court ruled that the Company did not infringe the EP ‘498 patent and dismissed Mala’s complaint entirely. Mala has filed an appeal.

[0001564590-23-000867:notes:125]
The Company filed a nullity complaint against EP ‘498 with the German Federal Patent Court on September 24, 2021. This matter is still pending.

[0001564590-23-000867:notes:126]
Indemnification Obligations

[0001564590-23-000867:notes:127]
Subject to certain limitations, the Company may be obligated to indemnify its current and former directors, officers and employees. These obligations arise under the terms of its certificate of incorporation, its bylaws, applicable contracts, and applicable law. The obligation to indemnify, where applicable, generally means that the Company is required to pay or reimburse, and in certain circumstances the Company has paid or reimbursed, the individuals’ reasonable legal expenses and possible damages and other liabilities incurred in connection with certain legal matters. The Company also procures Directors and Officers liability insurance to help cover its defense and/or indemnification costs, although its ability to recover such costs through insurance is uncertain.  While it is not possible to estimate the maximum potential amount that could be owed under these governing documents and agreements due to the Company’s limited history with prior indemnification claims, indemnification (including defense) costs could, in the future, have a material adverse effect on the Company’s consolidated financial position, results of operations and cash flows.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001564590-23-000867:notes:128]
[same as prior period, unchanged from 0001564590-22-035673:notes:122]

[0001564590-23-000867:notes:129]
[same as prior period, unchanged from 0001564590-22-035673:notes:123]

[0001564590-23-000867:notes:130]
On May 17, 2021, the Company entered into the Amended and Restated Tax Benefit Preservation Plan (the “2021 Tax Benefit Preservation Plan”), which amended and restated the Amended and Restated Rights Agreement between the Company and Computershare Shareholder Services LLC, as the rights agent. The 2021 Tax Benefit Preservation Plan was approved by stockholders of the Company at the annual meeting of stockholders held on November 4, 2021. The 2021 Tax Benefit Preservation Plan governs the terms of each right (“Right”) that has been issued with respect to each share of common stock of Extreme Networks. Each Right initially represents the right to purchase one one-thousandth of a share of the Company’s Preferred Stock.

[0001564590-23-000867:notes:131]
[same as prior period, unchanged from 0001564590-22-035673:notes:125]

[0001564590-23-000867:notes:132]
[same as prior period, unchanged from 0001564590-22-035673:notes:126]

[0001564590-23-000867:notes:133]
The Compensation Committee of the Board unanimously approved an amendment to the Extreme Networks, Inc. Amended and Restated 2013 Equity Incentive Plan (the “2013 Plan”) on September 12, 2022 to increase the maximum number of available shares by 6.5 million shares. The amendment was approved by the stockholders of the Company at the annual meeting of stockholders held on November 17, 2022.

[0001564590-23-000867:notes:134]
[same as prior period, unchanged from 0001564590-22-035673:notes:128]

[0001564590-23-000867:notes:135]
[same as prior period, unchanged from 0001564590-22-035673:notes:129]

[0001564590-23-000867:notes:136]
[same as prior period, unchanged from 0001564590-22-035673:notes:130]

[0001564590-23-000867:notes:137]
On May 18, 2022, the Company announced the Board had authorized management to repurchase up to $200.0 million of shares of the Company’s common stock over a three-year period commencing July 1, 2022 (as amended, the “2022 Repurchase Program”). Initially, under the 2022 Repurchase program, a maximum of $25.0 million of shares was authorized to be repurchased in any quarter; however, on November 17, 2022, the Board increased the authorization to repurchase shares in any quarter from up to $25.0 million of shares per quarter to up to $50.0 million of shares per quarter. Purchases may be made from time to time in the open market or pursuant to a 10b5-1 plan.

[0001564590-23-000867:notes:138]
During the three and six months ended December 31, 2022, the Company repurchased a total of 2,578,175 shares of its common stock on the open market at a total cost of $49.8 million with an average price of $19.32 per share. During the three and six months ended December 31, 2021, the Company repurchased a total of 1,829,333 shares of its common stock on the open market at total cost of $25.0 million with an average price of $13.65 per share pursuant to a share repurchase authorization that was replaced by the 2022 Repurchase Program. As of December 31, 2022, approximately $150.2 million remains available for share repurchases under the 2022 Repurchase Program.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001564590-23-000867:notes:139]
[same as prior period, unchanged from 0001564590-22-035673:notes:133]

[0001564590-23-000867:notes:140]
[same as prior period, unchanged from 0001564590-22-035673:notes:134]

[0001564590-23-000867:notes:141]
[same as prior period, unchanged from 0001564590-22-035673:notes:135]

[0001564590-23-000867:notes:142]
|  |  | December 31, 2022 |  |  | June 30, 2022 |  |
| 2013 Equity Incentive Plan shares available for grant |  |  | 9,764 |  |  |  | 11,430 |  |
| Employee stock options and awards outstanding |  |  | 10,830 |  |  |  | 7,616 |  |
| 2014 Employee Stock Purchase Plan |  |  | 9,280 |  |  |  | 9,961 |  |
| Total shares reserved for issuance |  |  | 29,874 |  |  |  | 29,007 |  |

[0001564590-23-000867:notes:143]
[same as prior period, unchanged from 0001564590-22-035673:notes:137]

[0001564590-23-000867:notes:144]
[same as prior period, unchanged from 0001564590-22-035673:notes:138]

[0001564590-23-000867:notes:145]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | December 31, 2022 |  |  | December 31, 2021 |  |  | December 31, 2022 |  |  | December 31, 2021 |  |
| Cost of product revenues |  | $ | 499 |  |  | $ | 303 |  |  | $ | 873 |  |  | $ | 613 |  |
| Cost of service and subscription revenues |  |  | 966 |  |  |  | 351 |  |  |  | 1,638 |  |  |  | 713 |  |
| Research and development |  |  | 3,962 |  |  |  | 2,664 |  |  |  | 7,052 |  |  |  | 5,122 |  |
| Sales and marketing |  |  | 5,910 |  |  |  | 3,860 |  |  |  | 10,549 |  |  |  | 7,435 |  |
| General and administrative |  |  | 6,059 |  |  |  | 4,155 |  |  |  | 11,073 |  |  |  | 7,894 |  |
| Total share-based compensation expense |  | $ | 17,396 |  |  | $ | 11,333 |  |  | $ | 31,185 |  |  | $ | 21,777 |  |

[0001564590-23-000867:notes:146]
[same as prior period, unchanged from 0001564590-22-035673:notes:140]

[0001564590-23-000867:notes:147]
The following table summarizes stock option activity for the six months ended December 31, 2022 (in thousands, except per share and contractual term):

[0001564590-23-000867:notes:148]
|  |  | Number of Shares |  |  | Weighted-Average Exercise Price Per Share |  |  | Weighted-Average Remaining Contractual Term (years) |  |  | Aggregate Intrinsic Value |  |
| Options outstanding at June 30, 2022 |  |  | 1,187 |  |  | $ | 6.56 |  |  |  | 3.70 |  |  | $ | 2,801 |  |
| Granted |  |  | — |  |  |  | — |  |  |  |  |  |  |  |  |  |
| Exercised |  |  | — |  |  |  | — |  |  |  |  |  |  |  |  |  |
| Canceled |  |  | — |  |  |  | — |  |  |  |  |  |  |  |  |  |
| Options outstanding at December 31, 2022 |  |  | 1,187 |  |  | $ | 6.56 |  |  |  | 3.20 |  |  | $ | 13,948 |  |
| Vested and expected to vest at December 31, 2022 |  |  | 1,187 |  |  | $ | 6.56 |  |  |  | 3.20 |  |  | $ | 13,948 |  |
| Exercisable at December 31, 2022 |  |  | 1,068 |  |  | $ | 6.55 |  |  |  | 3.14 |  |  | $ | 12,562 |  |

[0001564590-23-000867:notes:149]
The fair value of each stock option grant under the 2013 Plan is estimated on the date of grant using the Black-Scholes-Merton option valuation model. The expected term of options granted is derived from historical data on employee exercise and post-vesting employment termination behavior. The risk-free rate is based upon the estimated life of the option and the U.S. Treasury yield curve in effect at the time of grant. Expected volatility is based on the historical volatility on the Company’s stock. There were no stock options granted during the  three and six months ended December 31, 2022 and 2021. There were no stock options exercised during the three and six months ended December 31, 2022.

[0001564590-23-000867:notes:150]
[same as prior period, unchanged from 0001564590-22-035673:notes:144]

[0001564590-23-000867:notes:151]
[same as prior period, unchanged from 0001564590-22-035673:notes:145]

[0001564590-23-000867:notes:152]
The following table summarizes stock award activity for the six months ended December 31, 2022 (in thousands, except grant date fair value):

[0001564590-23-000867:notes:153]
|  |  | Number of Shares |  |  | Weighted- Average Grant Date Fair Value |  |  | Aggregate Fair Value |  |
| Non-vested stock awards outstanding at June 30, 2022 |  |  | 6,429 |  |  | $ | 9.57 |  |  |  |  |  |
| Granted |  |  | 6,186 |  |  |  | 14.50 |  |  |  |  |  |
| Released |  |  | (2,731 | ) |  |  | 8.30 |  |  |  |  |  |
| Canceled |  |  | (241 | ) |  |  | 11.31 |  |  |  |  |  |
| Non-vested stock awards outstanding at December 31, 2022 |  |  | 9,643 |  |  | $ | 13.05 |  |  | $ | 176,564 |  |
| Stock awards expected to vest at December 31, 2022 |  |  | 9,643 |  |  | $ | 13.05 |  |  | $ | 176,564 |  |

[0001564590-23-000867:notes:154]
The RSUs granted under the 2013 Plan vest over a period of time, generally one to three years, and are subject to participant's continued service to the Company. The stock awards granted during the six months ended December 31, 2022 included 1.4 million RSUs including the market condition awards discussed below to named executive officers and directors.

[0001564590-23-000867:notes:155]
[same as prior period, unchanged from 0001564590-22-035673:notes:149]

[0001564590-23-000867:notes:156]
During the six months ended December 31, 2022 and 2021, the Compensation Committee of the Board granted 1.0 million and 0.7 million RSUs, respectively, with vesting based on market conditions (“MSU”) to certain of the Company’s executive officers. These MSUs vest based on the Company’s total shareholder return (“TSR”) relative to the TSR of the Russell 2000 Index (“Index”).  The MSU award represents the right to receive a target number of shares of common stock of up to 150% of the original grant, as indicated in the table below. The MSUs vest based on the Company’s TSR relative to the TSR of the Index over performance periods of three years from the grant date, subject to the grantees’ continued service through the certification of performance.

[0001564590-23-000867:notes:157]
[same as prior period, unchanged from 0001564590-22-035673:notes:151]

[0001564590-23-000867:notes:158]
[same as prior period, unchanged from 0001564590-22-035673:notes:152]

[0001564590-23-000867:notes:159]
The grant date fair value of each MSU was determined using the Monte Carlo simulation model. The weighted-average grant-date fair value of the MSUs granted during the six months ended December 31, 2022 was $16.57 per share. The assumptions used in the Monte Carlo simulation included the expected volatility of 67%, risk-free rate of 3.12%, no expected dividend yield, expected term of three years and possible future stock prices over the performance period based on the historical stock and market prices. The Company recognizes the expense related to these MSUs on a graded-vesting method over the estimated term.

[0001564590-23-000867:notes:160]
The weighted-average grant-date fair value of the MSUs granted during the six months ended December 31, 2021 was $12.69 per share. The assumptions used in the Monte Carlo simulation included the expected volatility of 66%, risk-free rate of 0.44%, no expected dividend yield, expected term of three years and possible future stock prices over the performance period based on the historical stock and market prices.

[0001564590-23-000867:notes:161]
The fair value of each share purchase option under the ESPP is estimated on the date of grant using the Black-Scholes-Merton option valuation model with the weighted average assumptions noted in the following table. The expected term of the ESPP represents the term of the offering period of each option. The risk-free rate is based upon the estimated life and on the U.S. Treasury yield curve in effect at the time of grant. Expected volatility is based on the historical volatility on the Company’s common stock.

[0001564590-23-000867:notes:162]
There were 0.7 million and 1.0 million shares issued under the ESPP during the six months ended December 31, 2022 and 2021, respectively. The following assumptions were used to determine the grant-date fair values of the ESPP shares during the following periods:

[0001564590-23-000867:notes:163]
|  |  | Employee Stock Purchase Plan |  |
|  |  | Three Months Ended |  |
|  |  | December 31, 2022 |  |  | December 31, 2021 |  |
| Expected life |  | 0.5 years |  |  | 0.5 years |  |
| Risk-free interest rate |  |  | 3.12 | % |  |  | 0.05 | % |
| Volatility |  |  | 60 | % |  |  | 52 | % |
| Dividend yield |  |  | — | % |  |  | — | % |

[0001564590-23-000867:notes:164]
The weighted-average grant-date fair value of shares under the ESPP during the six months ended December 31, 2022 and 2021 was $4.38 and $3.18 per share, respectively.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001564590-23-000867:notes:165]
[same as prior period, unchanged from 0001564590-22-035673:notes:159]

[0001564590-23-000867:notes:166]
The Company operates in one segment, the development and marketing of network infrastructure equipment and related software. The Company conducts business globally and is managed geographically. Revenues are attributed to a geographical area based on the billing address of customers. The Company operates in three geographical areas: Americas, EMEA, and APAC. The Company’s chief operating decision maker, who is its CEO, reviews financial information presented on a consolidated basis for purposes of allocating resources and evaluating financial performance.

[0001564590-23-000867:notes:167]
[same as prior period, unchanged from 0001564590-22-035673:notes:161]

[0001564590-23-000867:notes:168]
[same as prior period, unchanged from 0001564590-22-035673:notes:162]

[0001564590-23-000867:notes:169]
|  |  | December 31, 2022 |  |  | June 30, 2022 |  |
| Americas |  | $ | 122,896 |  |  | $ | 130,715 |  |
| EMEA |  |  | 35,837 |  |  |  | 36,792 |  |
| APAC |  |  | 12,283 |  |  |  | 11,770 |  |
| Total long-lived assets |  | $ | 171,016 |  |  | $ | 179,277 |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001564590-23-000867:notes:170]
[same as prior period, unchanged from 0001564590-22-035673:notes:164]

[0001564590-23-000867:notes:171]
[same as prior period, unchanged from 0001564590-22-035673:notes:165]

[0001564590-23-000867:notes:172]
[same as prior period, unchanged from 0001564590-22-035673:notes:166]

[0001564590-23-000867:notes:173]
[same as prior period, unchanged from 0001564590-22-035673:notes:167]

[0001564590-23-000867:notes:174]
During fiscal 2020, the Company entered into multiple interest rate swap contracts, designated as cash flow hedges, to hedge the variability of cash flows in interest payments associated with the Company’s various tranches of floating-rate debt. As of December 31, 2022 and 2021, the total notional amount of these interest rate swaps were $75.0 million and $200.0 million, respectively, and had maturity dates through April 2023. As of December 31, 2022 and 2021, these contracts had unrealized gains of $0.8 million and unrealized losses of $0.3 million, respectively, and are recorded in “Accumulated other comprehensive income (loss)” with the associated asset in “Prepaid expenses and other current assets” or with the associated liability in “Other accrued liabilities,” respectively, in the condensed consolidated balance sheets. Cash flows associated with periodic settlements of interest rate swaps are classified as operating activities in the condensed consolidated statement of cash flows. Realized gains and losses are recognized as they accrue in interest expense. Amounts reported in accumulated other comprehensive income (loss) related to these cash flow hedges are reclassified to interest expense over the life of the swap contracts. The Company estimates that $0.8 million will be reclassified to interest income over the next twelve months. The classification and fair value of these cash flow hedges are discussed in Note 6, Fair Value Measurements.

[0001564590-23-000867:notes:175]
[same as prior period, unchanged from 0001564590-22-035673:notes:169]

[0001564590-23-000867:notes:176]
[same as prior period, unchanged from 0001564590-22-035673:notes:170]

[0001564590-23-000867:notes:177]
[same as prior period, unchanged from 0001564590-22-035673:notes:171]

[0001564590-23-000867:notes:178]
For foreign exchange forward contracts not designated as hedging instruments, the fair value of the Company’s derivatives in a gain position are recorded in “Prepaid expenses and other current assets” and derivatives in a loss position are recorded in “Other accrued liabilities” in the accompanying condensed consolidated balance sheets. Changes in the fair value of derivatives are recorded in “Other income, net” in the accompanying condensed consolidated statements of operations. As of December 31, 2022 and 2021, foreign exchange forward contracts not designated as hedging instruments had a total notional principal amounts of $11.1 million and $20.4 million, respectively. These contracts have maturities of 60 days or less. The net gains and losses recorded in the condensed consolidated statement of operations from these contracts during the three and six months ended December 31, 2022 were net gain of $0.1 million and net loss of $0.4 million, respectively, and during the three and six months ended December 31, 2021 there were net losses of less than $0.1 million and $0.2 million, respectively. Changes in the fair value of these foreign exchange forward contracts are offset largely by remeasurement of the underlying assets and liabilities.

[0001564590-23-000867:notes:179]
For foreign exchange forward contracts designated as hedging instruments, gains and losses arising from these contracts are recorded as a component of “accumulated other comprehensive income (loss)” on the condensed consolidated balance sheets. The hedging gains and losses in “accumulated other comprehensive income (loss)” are subsequently reclassified to expenses, as applicable, in the condensed consolidated statements of operations in the same period in which the underlying transactions affect the Company’s earnings. As of December 31, 2022 and 2021, foreign exchange forward contracts designated as hedging instruments had the notional amount of $5.5 million and $5.7 million, respectively. These contracts have maturities of less than twelve months, and unrealized gains and losses arising from these contracts designated as hedging instruments are recorded as a component of “accumulated other comprehensive income (loss)”. As of December 31, 2022 and 2021, these contracts had unrealized gain of $0.4 million and unrealized loss of $0.3 million respectively.

[0001564590-23-000867:notes:180]
For the three months ended December 31, 2022 and 2021, the Company recognized total foreign currency gain of less than $0.1 million and losses of less than $0.1 million, respectively, and for the six months ended December 31, 2022 and 2021, the Company recognized total foreign currency gains of $0.8 million and $0.3 million, respectively, related to the change in fair value of foreign currency denominated assets and liabilities.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001564590-23-000867:notes:181]
[same as prior period, unchanged from 0001564590-22-035673:notes:175]

[0001564590-23-000867:notes:182]
The Company recorded $0.5 million and $1.0 million of restructuring and related charges during the three and six months ended December 31, 2022, respectively, which included additional facilities charges related to previously impaired facilities. As of June 30, 2022, the Company has completed all the restructuring activities under the 2020 Plan noted below and no restructuring liabilities remain in the accompanying condensed consolidated balance sheets.

[0001564590-23-000867:notes:183]
The Company recorded $0.3 million and $0.6 million of restructuring and related charges during the three and six months ended December 31, 2021 which primarily included additional facility related expenses related to previously impaired facilities. The Company had minimal activity related to the 2020 Plan during the three months ended December 31, 2021. Severance and benefit restructuring charges consisted primarily of employee severance and benefit expenses incurred under the reduction-in-force action initiated in the third quarter of fiscal 2020 (the “2020 Plan”) to reduce operating costs and enhance financial flexibility as a result of disruptions caused by the COVID-19 global pandemic. With the reduction and realignment of the headcount under the 2020 Plan, the Company relocated certain of its lab test equipment to third-party consulting companies. The Company incurred $9.6 million of charges under the 2020 Plan through June 30, 2022.

[0001564590-23-000867:notes:184]
Restructuring liabilities related to severance, benefits, and equipment relocation obligations are recorded in “Other accrued liabilities” in the accompanying condensed consolidated balance sheets. As of December 31, 2021, the restructuring liability was less than $0.1 million.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001564590-23-000867:notes:185]
[same as prior period, unchanged from 0001564590-22-035673:notes:179]

[0001564590-23-000867:notes:186]
For the three months ended December 31, 2022 and 2021, the Company recorded an income tax provision of $2.6 million and $1.8 million, respectively. For the six months ended December 31, 2022 and 2021, the Company recorded an income tax provision of $4.4 million and $3.9 million, respectively.

[0001564590-23-000867:notes:187]
The income tax provisions for the three and six months ended December 31, 2022 and 2021, consisted of (1) taxes on the income of the Company’s foreign subsidiaries, (2) foreign withholding taxes, (3) state taxes in jurisdictions where the Company has no remaining state net operating losses (“NOLs”) and (4) tax expense associated with the establishment of a U.S. deferred tax liability for amortizable goodwill resulting from the acquisition of Enterasys Networks, Inc., the wireless local area network business from

[0001564590-23-000867:notes:188]
Zebra Technologies Corporation, the Campus Fabric Business from Avaya and the Data Center Business from Brocade. The interim income tax provisions for the three and six months ended December 31, 2022 and 2021 were calculated using the discrete effective tax rate method as allowed by ASC 740-270-30-18, Income Taxes – Interim Reporting. The discrete method is applied when the application of the estimated annual effective tax rate is impractical because it is not possible to reliably estimate the annual effective tax rate. The discrete method treats the year-to-date period as if it was the annual period and determines the income tax expense or benefit on that basis.  The Company believes that, at this time, the use of this discrete method is more appropriate than the annual effective tax rate method as (i) the estimated annual effective tax rate method is not reliable due to the high degree of uncertainty in estimating annual pretax earnings on a jurisdictional basis and (ii) the Company’s ongoing assessment that the recoverability of certain U.S. and Irish deferred tax assets is not more likely than not.

[0001564590-23-000867:notes:189]
The Company has provided a full valuation allowance against all of its U.S. federal and state deferred tax assets as well as a portion of the deferred tax assets in Ireland. Significant judgment is required in determining any valuation allowance recorded against deferred tax assets. In assessing the need for a valuation allowance, the Company considers all available positive and negative evidence to determine whether it is “more likely than not” that deferred tax assets are recoverable including past operating results, estimates of future taxable income, changes to enacted tax laws, and the feasibility of tax planning strategies; such assessment is required on a jurisdiction-by-jurisdiction basis. The Company’s inconsistent earnings in recent periods, including a cumulative loss over the last three years, coupled with its difficulty in forecasting future revenue trends by jurisdiction and the cyclical nature of its business represent sufficient negative evidence to require full valuation allowances against its U.S. federal and state net deferred tax assets as well as a portion of the deferred tax assets in Ireland.  These valuation allowances will be evaluated periodically and can be reversed partially or in whole if business results and the economic environment have sufficiently improved to support realization of some or all of the Company's deferred tax assets. In the event the Company changes its determination as to the amount of deferred tax assets that can be realized, it will adjust its valuation allowance with a corresponding impact to the provision for income taxes in the period in which such determination is made.

[0001564590-23-000867:notes:190]
[same as prior period, unchanged from 0001564590-22-035673:notes:184]

[0001564590-23-000867:notes:191]
The Company had $18.4 million of unrecognized tax benefits as of December 31, 2022. If fully recognized in the future, $0.3 million would impact the effective tax rate and $18.1 million would result in adjustments to deferred tax assets and corresponding adjustments to the valuation allowance with no impact to the effective tax rate.  The Company does not anticipate any events to occur during the next twelve months that would materially reduce the unrealized tax benefit as currently stated in the Company’s condensed consolidated balance sheets.

[0001564590-23-000867:notes:192]
[same as prior period, unchanged from 0001564590-22-035673:notes:186]

[0001564590-23-000867:notes:193]
[same as prior period, unchanged from 0001564590-22-035673:notes:187]


## us-gaap:EarningsPerShareTextBlock

[0001564590-23-000867:notes:194]
[same as prior period, unchanged from 0001564590-22-035673:notes:188]

[0001564590-23-000867:notes:195]
[same as prior period, unchanged from 0001564590-22-035673:notes:189]

[0001564590-23-000867:notes:196]
[same as prior period, unchanged from 0001564590-22-035673:notes:190]

[0001564590-23-000867:notes:197]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | December 31, 2022 |  |  | December 31, 2021 |  |  | December 31, 2022 |  |  | December 31, 2021 |  |
| Net income |  | $ | 17,931 |  |  | $ | 13,341 |  |  | $ | 30,516 |  |  | $ | 26,037 |  |
| Weighted-average shares used in per share calculation – basic |  |  | 130,465 |  |  |  | 129,403 |  |  |  | 130,377 |  |  |  | 128,863 |  |
| Options to purchase common stock |  |  | 717 |  |  |  | 702 |  |  |  | 635 |  |  |  | 677 |  |
| Restricted stock units |  |  | 3,164 |  |  |  | 3,340 |  |  |  | 2,760 |  |  |  | 3,795 |  |
| Employee Stock Purchase Plan shares |  |  | 107 |  |  |  | 176 |  |  |  | 61 |  |  |  | 88 |  |
| Weighted-average shares used in per share calculation – diluted |  |  | 134,453 |  |  |  | 133,621 |  |  |  | 133,833 |  |  |  | 133,423 |  |
| Net income per share – basic and diluted |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income per share – basic |  | $ | 0.14 |  |  | $ | 0.10 |  |  | $ | 0.23 |  |  | $ | 0.20 |  |
| Net income per share – diluted |  | $ | 0.13 |  |  | $ | 0.10 |  |  | $ | 0.23 |  |  | $ | 0.20 |  |

[0001564590-23-000867:notes:198]
[same as prior period, unchanged from 0001564590-22-035673:notes:192]

[0001564590-23-000867:notes:199]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | December 31, 2022 |  |  | December 31, 2021 |  |  | December 31, 2022 |  |  | December 31, 2021 |  |
| Restricted stock units |  |  | 437 |  |  |  | 7 |  |  |  | 306 |  |  |  | 8 |  |
| Employee Stock Purchase Plan shares |  |  | 678 |  |  |  | 764 |  |  |  | 529 |  |  |  | 620 |  |
| Total shares excluded |  |  | 1,115 |  |  |  | 771 |  |  |  | 835 |  |  |  | 628 |  |
