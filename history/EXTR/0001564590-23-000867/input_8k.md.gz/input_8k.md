# EXTR 8-K — 0001564590-23-000754 filed 2023-01-25

## item codes, every 8-K on or before 2023-01-27

- 2023-01-25 0001564590-23-000756 — 5.02, 9.01
- 2023-01-25 0001564590-23-000754 — 2.02, 9.01
- 2022-11-18 0001564590-22-038036 — 5.03, 5.07, 9.01
- 2022-10-27 0001564590-22-035354 — 2.02, 9.01
- 2022-10-12 0001193125-22-261213 — 8.01
- 2022-07-27 0001564590-22-026574 — 2.02, 9.01
- 2022-04-27 0001564590-22-015866 — 2.02, 9.01
- 2022-01-27 0001564590-22-002568 — 2.02, 9.01
- 2021-11-05 0001564590-21-054934 — 5.07
- 2021-11-02 0001564590-21-053306 — 2.02, 9.01
- 2021-09-22 0001564590-21-048585 — 4.01, 9.01
- 2021-08-10 0001564590-21-043098 — 1.01
- 2021-07-28 0001564590-21-038470 — 2.02, 9.01
- 2021-05-18 0001564590-21-028693 — 1.01, 3.03, 9.01
- 2021-04-28 0001564590-21-021102 — 2.02, 9.01
- 2021-02-09 0001564590-21-005000 — 2.02, 9.01
- 2021-01-27 0001564590-21-002633 — 2.02, 9.01
- 2020-11-06 0001564590-20-051993 — 5.07
- 2020-10-28 0001564590-20-048160 — 2.02, 9.01
- 2020-10-08 0001564590-20-046117 — 2.02, 9.01
- 2020-09-11 0001564590-20-043260 — 4.01, 9.01
- 2020-08-05 0001564590-20-036431 — 2.02, 9.01
- 2020-06-01 0001564590-20-027850 — 3.03, 9.01
- 2020-05-11 0001564590-20-024216 — 2.02, 9.01
- 2020-04-08 0001564590-20-015927 — 2.02, 8.01, 9.01
- 2020-02-25 0001193125-20-047202 — 8.01, 9.01
- 2020-01-29 0001564590-20-002375 — 2.02, 9.01
- 2020-01-29 0001193125-20-017673 — 5.02, 9.01
- 2019-11-08 0001193125-19-288358 — 5.07
- 2019-10-30 0001564590-19-038508 — 2.02, 9.01
- 2019-10-25 0001564590-19-037908 — 9.01 — amendment of 0001193125-19-217553
- 2019-10-18 0001193125-19-269734 — 7.01, 9.01
- 2019-08-30 0001193125-19-235271 — 5.02 — amendment of 0001193125-19-229280
- 2019-08-26 0001193125-19-229280 — 5.02, 9.01
- 2019-08-09 0001193125-19-217553 — 1.01, 2.01, 2.03, 9.01
- 2019-07-31 0001564590-19-027208 — 2.02, 9.01
- 2019-06-26 0001193125-19-181938 — 1.01, 2.05, 9.01
- 2019-05-01 0001564590-19-014567 — 2.02, 9.01
- 2019-01-29 0001564590-19-001270 — 2.02, 9.01
- 2019-01-25 0001564590-19-001157 — 8.01, 9.01
- 2018-11-20 0001193125-18-331450 — 5.02, 9.01
- 2018-11-15 0001564590-18-029683 — 5.07
- 2018-11-02 0001564590-18-026372 — 2.02, 8.01, 9.01
- 2018-09-19 0001193125-18-276766 — 5.02
- 2018-08-08 0001564590-18-020191 — 2.02, 9.01
- 2018-06-05 0001564590-18-015067 — 3.03, 9.01
- 2018-05-08 0001564590-18-011817 — 2.02, 9.01
- 2018-05-07 0001564590-18-011264 — 1.01, 1.02, 2.03, 9.01
- 2018-02-06 0001564590-18-001403 — 2.02, 2.05, 9.01
- 2018-02-01 0001564590-18-001166 — 5.02
- 2018-01-12 0001564590-18-000462 — 9.01 — amendment of 0001193125-17-323879
- 2017-11-15 0001564590-17-023847 — 5.07
- 2017-11-07 0001564590-17-022235 — 2.02, 9.01
- 2017-11-03 0001193125-17-332828 — 9.01 — amendment of 0001193125-17-323879
- 2017-10-30 0001193125-17-323879 — 1.01, 2.01, 7.01, 9.01
- 2017-10-03 0001193125-17-302411 — 1.01, 9.01
- 2017-10-03 0001193125-17-301597 — 1.01, 1.02, 7.01, 9.01
- 2017-09-29 0001564590-17-019099 — 9.01 — amendment, the index does not say of what
- 2017-08-14 0001564590-17-017659 — 2.02, 9.01
- 2017-08-02 0001564590-17-014950 — 5.02
- 2017-07-18 0001564590-17-013557 — 1.01, 2.01, 2.03, 9.01
- 2017-06-05 0001564590-17-012126 — 3.03, 9.01
- 2017-05-03 0001564590-17-008378 — 2.02, 9.01
- 2017-03-30 0001193125-17-102344 — 1.01, 9.01
- 2017-03-07 0001193125-17-073306 — 1.01, 9.01
- 2017-02-21 0001193125-17-048182 — 5.02
- 2017-02-01 0001564590-17-000835 — 2.02, 9.01
- 2017-01-06 0001564590-17-000138 — 2.05
- 2016-11-21 0001564590-16-029539 — 5.07
- 2016-11-01 0001564590-16-026732 — 2.02, 9.01
- 2016-10-31 0001193125-16-752557 — 1.01, 2.01, 2.03
- 2016-09-15 0001193125-16-711097 — 1.01, 9.01
- 2016-08-03 0001564590-16-022347 — 2.02, 9.01
- 2016-05-19 0001564590-16-019720 — 5.02, 9.01
- 2016-05-09 0001564590-16-018660 — 3.03, 9.01
- 2016-04-27 0001564590-16-016754 — 2.02, 9.01
- 2016-02-24 0001564590-16-013189 — 8.01
- 2016-02-09 0001564590-16-012469 — 8.01
- 2016-01-28 0001564590-16-012054 — 2.02, 9.01
- 2015-11-17 0001078271-15-000136 — 5.07
- 2015-10-29 0001078271-15-000125 — 2.02, 9.01
- 2015-08-31 0001078271-15-000111 — 8.01, 9.01
- 2015-08-11 0001078271-15-000096 — 5.02
- 2015-08-06 0001078271-15-000093 — 2.02, 9.01
- 2015-06-30 0001078271-15-000089 — 1.01, 9.01
- 2015-05-20 0001078271-15-000077 — 2.05, 9.01
- 2015-05-19 0001078271-15-000075 — 3.03, 9.01
- 2015-05-06 0001078271-15-000050 — 2.02, 9.01
- 2015-05-04 0001078271-15-000048 — 5.02, 9.01
- 2015-04-29 0001078271-15-000038 — 5.02, 9.01
- 2015-04-21 0001078271-15-000034 — 5.02, 9.01
- 2015-04-09 0001078271-15-000032 — 2.02, 5.02, 9.01
- 2015-02-18 0001078271-15-000021 — 8.01
- 2015-02-17 0001078271-15-000019 — 5.02
- 2015-01-28 0001078271-15-000004 — 2.02, 9.01
- 2014-12-18 0001078271-14-000081 — 5.02, 9.01
- 2014-12-17 0001078271-14-000079 — 5.02
- 2014-11-20 0001078271-14-000075 — 1.01, 9.01
- 2014-11-17 0001078271-14-000073 — 5.07
- 2014-10-28 0001078271-14-000062 — 2.02, 9.01
- 2014-10-15 0001078271-14-000060 — 2.02, 9.01
- 2014-10-02 0001078271-14-000057 — 5.02, 9.01
- 2014-08-14 0001078271-14-000047 — 2.02, 9.01
- 2014-07-21 0001078271-14-000042 — 2.02, 9.01
- 2014-05-23 0001078271-14-000036 — 5.02, 9.01
- 2014-05-20 0001078271-14-000034 — 3.03, 9.01
- 2014-05-12 0001078271-14-000030 — 5.02
- 2014-05-08 0001078271-14-000022 — 5.02, 9.01
- 2014-05-07 0001078271-14-000018 — 2.02, 9.01 — amendment, the index does not say of what
- 2014-05-06 0001078271-14-000016 — 2.02, 9.01
- 2014-02-20 0001078271-14-000014 — 5.02, 9.01
- 2014-02-18 0001078271-14-000010 — 5.02
- 2014-02-05 0001078271-14-000006 — 2.02, 9.01
- 2014-01-13 0001104659-14-002030 — 9.01 — amendment of 0001078271-13-000058
- 2013-11-25 0001078271-13-000081 — 5.07
- 2013-11-07 0001078271-13-000064 — 5.02, 9.01
- 2013-11-04 0001078271-13-000060 — 2.02, 9.01
- 2013-11-01 0001078271-13-000058 — 1.01, 2.01, 2.03, 8.01, 9.01
- 2013-10-16 0001078271-13-000056 — 8.01, 9.01
- 2013-09-13 0001078271-13-000052 — 1.01, 8.01, 9.01
- 2013-08-23 0001078271-13-000044 — 5.02, 9.01
- 2013-08-02 0001078271-13-000042 — 5.02
- 2013-07-30 0001078271-13-000039 — 2.02, 9.01
- 2013-07-30 0001078271-13-000037 — 5.02, 9.01
- 2013-06-21 0001078271-13-000032 — 8.01
- 2013-05-01 0001078271-13-000018 — 5.02, 9.01
- 2013-04-30 0001078271-13-000015 — 2.02, 9.01
- 2013-03-01 0001078271-13-000010 — 8.01
- 2013-02-19 0001078271-13-000008 — 5.02
- 2013-01-30 0001078271-13-000004 — 2.02, 9.01
- 2013-01-07 0001078271-13-000002 — 1.01, 2.02, 2.03, 2.05, 9.01
- 2012-12-03 0001078271-12-000094 — 5.02, 5.07, 8.01
- 2012-10-31 0001078271-12-000071 — 2.02, 9.01
- 2012-10-19 0001078271-12-000069 — 1.01, 2.03, 9.01
- 2012-10-16 0001078271-12-000067 — 8.01
- 2012-10-01 0001193125-12-411392 — 5.02, 8.01, 9.01
- 2012-09-24 0001193125-12-401798 — 5.02, 9.01
- 2012-09-21 0001193125-12-399896 — 5.02, 9.01
- 2012-09-18 0001193125-12-394379 — 1.01, 5.02, 9.01
- 2012-09-12 0001193125-12-388591 — 8.01
- 2012-08-27 0001078271-12-000057 — 8.01
- 2012-08-03 0001078271-12-000041 — 7.01, 9.01
- 2012-08-01 0001078271-12-000039 — 2.02, 9.01
- 2012-07-25 0001078271-12-000037 — 8.01
- 2012-05-22 0001078271-12-000033 — 5.02, 9.01
- 2012-05-21 0001078271-12-000030 — 8.01
- 2012-05-09 0001078271-12-000028 — 5.02, 9.01
- 2012-05-02 0001078271-12-000023 — 2.02, 9.01
- 2012-04-30 0001078271-12-000020 — 3.03, 5.07, 9.01
- 2012-04-19 0001078271-12-000012 — 2.02, 5.02, 9.01
- 2012-03-12 0001078271-12-000010 — 5.02, 9.01
- 2012-02-24 0001078271-12-000008 — 8.01
- 2012-02-02 0001078271-12-000004 — 2.02, 9.01
- 2012-01-30 0001078271-12-000002 — 1.01
- 2011-12-01 0001078271-11-000104 — 8.01
- 2011-11-08 0001078271-11-000099 — 8.01
- 2011-11-02 0001078271-11-000094 — 2.02, 9.01
- 2011-10-24 0001078271-11-000089 — 8.01, 9.01
- 2011-10-11 0001078271-11-000085 — 8.01
- 2011-09-29 0001078271-11-000082 — 8.01
- 2011-09-15 0001078271-11-000070 — 5.02, 9.01
- 2011-08-11 0001078271-11-000058 — 8.01
- 2011-08-10 0001078271-11-000055 — 5.02
- 2011-08-08 0001078271-11-000045 — 5.02
- 2011-08-01 0001078271-11-000038 — 2.02, 9.01
- 2011-07-14 0001078271-11-000036 — 2.02, 2.05, 9.01
- 2011-07-12 0001078271-11-000034 — 8.01
- 2011-07-01 0001078271-11-000032 — 5.02
- 2011-06-16 0001078271-11-000030 — 8.01
- 2011-05-06 0001078271-11-000027 — 8.01, 9.01
- 2011-05-04 0001078271-11-000025 — 8.01
- 2011-04-28 0001078271-11-000020 — 2.02, 9.01
- 2011-04-27 0001078271-11-000018 — 3.03, 5.02, 5.03, 9.01
- 2011-04-11 0001078271-11-000016 — 2.02
- 2011-03-31 0001078271-11-000014 — 5.02, 5.03
- 2011-03-15 0001193125-11-066049 — 5.02, 9.01
- 2011-03-01 0001193125-11-052048 — 5.02, 9.01
- 2011-02-10 0001078271-11-000012 — 7.01, 9.01
- 2011-01-31 0001078271-11-000005 — 2.02, 5.02, 5.03, 9.01
- 2010-12-23 0001193125-10-287613 — 8.01
- 2010-12-17 0001193125-10-283495 — 5.03, 5.07, 8.01, 9.01
- 2010-11-10 0001193125-10-255861 — 4.01, 9.01
- 2010-11-01 0001193125-10-242706 — 2.02, 9.01
- 2010-10-14 0001193125-10-229518 — 1.01, 9.01
- 2010-10-06 0001193125-10-224863 — 5.02, 8.01
- 2010-09-29 0001193125-10-219705 — 1.01, 8.01
- 2010-09-08 0001193125-10-206782 — 5.02, 8.01, 9.01
- 2010-08-25 0001193125-10-196951 — 8.01
- 2010-08-09 0001193125-10-182573 — 7.01, 8.01, 9.01
- 2010-08-03 0001193125-10-175255 — 5.02, 8.01, 9.01
- 2010-08-02 0001193125-10-173697 — 2.02, 8.01, 9.01
- 2010-07-30 0001193125-10-172214 — 5.02, 8.01, 9.01
- 2010-07-22 0001193125-10-163896 — 8.01, 9.01
- 2010-07-20 0001193125-10-161832 — 5.02
- 2010-07-12 0001193125-10-157291 — 2.02, 9.01
- 2010-07-01 0001193125-10-152746 — 3.03, 9.01
- 2010-05-10 0001193125-10-114669 — 5.02, 9.01
- 2010-04-26 0001193125-10-093310 — 2.02, 9.01
- 2010-03-19 0001193125-10-061679 — 5.02, 9.01
- 2010-02-16 0001193125-10-032335 — 5.02
- 2010-02-01 0001193125-10-018202 — 2.02, 9.01
- 2010-01-29 0001193125-10-017165 — 5.02
- 2010-01-11 0001193125-10-004099 — 8.01
- 2009-10-26 0001193125-09-213846 — 2.02, 9.01 — amendment of 0001193125-09-213780
- 2009-10-26 0001193125-09-213780 — 2.02, 9.01
- 2009-10-23 0001193125-09-212871 — 2.05, 5.02, 8.01, 9.01
- 2009-10-05 0001193125-09-203522 — 2.02, 9.01
- 2009-08-04 0001193125-09-163799 — 5.02, 9.01
- 2009-07-31 0001193125-09-160772 — 5.02, 9.01
- 2009-07-30 0001193125-09-159578 — 2.02, 9.01
- 2009-07-20 0001193125-09-151500 — 5.02, 9.01
- 2009-07-08 0001193125-09-145840 — 5.02, 9.01
- 2009-05-12 0001193125-09-108340 — 5.02, 9.01
- 2009-04-23 0001193125-09-085849 — 2.02, 9.01
- 2009-03-26 0001193125-09-064502 — 2.05
- 2009-01-28 0001193125-09-013182 — 2.02, 9.01
- 2008-11-06 0001193125-08-227572 — 2.02, 9.01
- 2008-11-03 0001193125-08-222501 — 5.02
- 2008-08-11 0001193125-08-173590 — 5.02
- 2008-08-11 0001193125-08-172587 — 8.01, 9.01
- 2008-08-06 0001193125-08-167934 — 2.02, 9.01
- 2008-08-04 0001193125-08-164673 — 5.02, 9.01
- 2008-05-21 0001193125-08-119640 — 7.01, 9.01
- 2008-04-29 0001193125-08-095270 — 2.02, 9.01
- 2008-03-05 0001193125-08-047893 — 8.01
- 2008-02-19 0001193125-08-033702 — 5.02
- 2008-02-05 0001193125-08-019969 — 5.02
- 2008-01-30 0001193125-08-015378 — 2.02, 9.01
- 2007-12-27 0001193125-07-272178 — 5.03, 9.01
- 2007-10-29 0001193125-07-228368 — 2.02, 9.01
- 2007-10-25 0001193125-07-225906 — 5.02, 9.01
- 2007-10-19 0001193125-07-221578 — 5.02
- 2007-09-26 0001193125-07-207348 — 8.01
- 2007-08-07 0001193125-07-172810 — 2.02, 9.01
- 2007-08-06 0001193125-07-172147 — 5.02, 9.01
- 2007-08-06 0001193125-07-172134 — 3.01
- 2007-07-09 0001193125-07-151467 — 3.01, 9.01
- 2007-06-28 0001193125-07-145519 — 2.02, 9.01
- 2007-06-27 0001193125-07-143262 — 2.05, 3.01, 5.02
- 2007-05-18 0001193125-07-118804 — 3.01, 9.01
- 2007-05-02 0001193125-07-099280 — 2.02, 9.01
- 2007-03-29 0001193125-07-068815 — 5.02, 9.01
- 2007-02-22 0001193125-07-037181 — 3.01, 9.01
- 2007-02-08 0001193125-07-024194 — 5.02
- 2007-01-30 0001193125-07-016428 — 2.02, 9.01
- 2007-01-11 0001193125-07-004825 — 4.02, 9.01
- 2006-11-21 0001193125-06-240068 — 5.02, 9.01
- 2006-11-16 0001193125-06-237262 — 3.01, 9.01
- 2006-11-01 0001193125-06-220707 — 2.02, 9.01
- 2006-10-31 0001193125-06-219237 — 1.01, 1.02, 5.02, 5.03, 8.01, 9.01
- 2006-09-28 0001193125-06-198185 — 3.01, 9.01
- 2006-09-15 0001193125-06-191640 — 7.01, 9.01
- 2006-09-05 0001193125-06-185202 — 5.02, 9.01
- 2006-08-08 0001193125-06-165953 — 1.01, 2.02, 5.02, 9.01
- 2006-07-18 0001193125-06-148526 — 1.01
- 2006-07-10 0001193125-06-143989 — 5.02, 9.01
- 2006-05-16 0001193125-06-113698 — 5.02, 9.01
- 2006-05-01 0001193125-06-094919 — 2.02, 9.01
- 2006-04-26 0001193125-06-089397 — 1.01, 9.01
- 2006-04-07 0001193125-06-075723 — 2.02, 9.01
- 2006-02-13 0001193125-06-029073 — 1.01
- 2006-01-31 0001193125-06-016143 — 1.01
- 2006-01-30 0001193125-06-015165 — 2.02, 9.01
- 2005-12-08 0001193125-05-239157 — 1.01, 1.02, 9.01
- 2005-11-01 0001193125-05-213101 — 2.02, 9.01
- 2005-09-29 0001193125-05-193991 — 1.01, 2.02, 9.01 — amendment of 0001193125-05-162807
- 2005-08-09 0001193125-05-162807 — 1.01, 2.02, 9.01
- 2005-07-14 0001193125-05-142162 — 8.01
- 2005-06-28 0001193125-05-133050 — 1.01, 9.01
- 2005-04-18 0001193125-05-077946 — 2.02, 7.01, 9.01
- 2005-04-14 0001193125-05-076665 — 2.02, 7.01, 9.01
- 2005-01-25 0001193125-05-011466 — 2.02, 9.01
- 2004-12-07 0001193125-04-208693 — 3.01
- 2004-10-26 0001193125-04-178370 — 2.02, 9.01
- 2004-10-04 0001193125-04-166289 — 5.02, 9.01
- 2004-07-28 0001193125-04-126135 — 12, 7
- 2004-05-12 0001193125-04-086287 — 12
- 2004-04-21 0001193125-04-066557 — 12, 7
- 2004-01-22 0001193125-04-007359 — 12, 7
- 2003-12-18 0001193125-03-096351 — 5, 7
- 2003-11-04 0001193125-03-072069 — 5, 7
- 2003-10-24 0001193125-03-066551 — 12, 7
- 2003-07-25 0001193125-03-024087 — 7, 9
- 2003-04-11 0001012870-03-001706 — 7, 9
- 2003-04-08 0001021408-03-005743 — 7, 9
- 2003-01-07 0001012870-03-000039 — 5, 7
- 2002-04-29 0001012870-02-002003 — 5, 7
- 2002-02-20 0001012870-02-000792 — 5, 7
- 2001-12-13 0001012870-01-503160 — 5, 7
- 2001-11-30 0001012870-01-503010 — 5, 7
- 2001-11-02 0001012870-01-502580 — 5
- 2001-10-23 0001021408-01-508589 — 5, 7
- 2001-06-07 0001021408-01-501772 — 5, 7 — amendment of 0001021408-01-500975
- 2001-05-15 0001021408-01-501104 — 5 — amendment of 0001021408-01-500975
- 2001-05-14 0001021408-01-500975 — 5, 7
- 2001-04-06 0001012870-01-500065 — 5, 7

## late-filing notifications on or before 2023-01-27

- 2008-05-12 0001193125-08-111540 — NT 10-Q, for the period ended 2008-03-30
- 2007-05-10 0001193125-07-110075 — NT 10-Q, for the period ended 2007-04-01
- 2007-02-09 0001193125-07-025490 — NT 10-Q, for the period ended 2006-12-31
- 2006-11-13 0001193125-06-232090 — NT 10-Q, for the period ended 2006-10-01
- 2006-09-15 0001193125-06-191838 — NT 10-K, for the period ended 2006-07-02

## item 2.02 — earnings release, exhibit 99.1

[0001564590-23-000754:8k_2_02:1]
EX-99.1
2
extr-ex991_6.htm
EX-99.1

[0001564590-23-000754:8k_2_02:2]
extr-ex991_6.htm

[0001564590-23-000754:8k_2_02:3]
Exhibit 99.1

[0001564590-23-000754:8k_2_02:4]
| For more information, contact: |  |  |  |  |  |  |
| Investor Relations |  |  |  | Media Contact |  |
| Stan Kovler |  |  |  | Amy Aylward |
| 919/595-4196 |  |  |  | 603/952-5138 |  |
| Investor_relations@extremenetworks.com |  |  |  | pr@extremenetworks.com |

[0001564590-23-000754:8k_2_02:5]
Extreme Networks Reports Second Quarter Fiscal Year 2023 Financial Results

[0001564590-23-000754:8k_2_02:6]
Delivers Consistent Double-Digit Growth and Raises FY23 Revenue Outlook

[0001564590-23-000754:8k_2_02:7]
Morrisville, NC, January 25, 2023 -- Extreme Networks, Inc. (“Extreme”) (Nasdaq: EXTR) today released financial results for its second fiscal quarter ended December 31, 2022.

[0001564590-23-000754:8k_2_02:8]
Fiscal Second Quarter Results:

[0001564590-23-000754:8k_2_02:9]
|  | • | Revenue $318.3 million, up 13% year-over-year, and up 7% quarter-over-quarter |

[0001564590-23-000754:8k_2_02:10]
|  | • | SaaS ARR* $115 million, up 29% year-over-year, and up 6% quarter-over-quarter |

[0001564590-23-000754:8k_2_02:11]
|  | • | GAAP diluted EPS $0.13, compared to $0.10 in Q2 last year and $0.09 last quarter |

[0001564590-23-000754:8k_2_02:12]
|  | • | Non-GAAP diluted EPS $0.27, compared to $0.21 in Q2 last year and $0.20 last quarter |

[0001564590-23-000754:8k_2_02:13]
|  | • | GAAP gross margin 57.1% compared to 56.5% in Q2 last year |

[0001564590-23-000754:8k_2_02:14]
|  | • | Non-GAAP gross margin 58.5% compared to 58.2% in Q2 last year |

[0001564590-23-000754:8k_2_02:15]
|  | • | GAAP operating margin 7.4% compared to 6.4% in Q2 last year |

[0001564590-23-000754:8k_2_02:16]
|  | • | Non-GAAP operating margin 14.9% compared to 13.1% in Q2 last year |

[0001564590-23-000754:8k_2_02:17]
|  | • | Net cash provided by operating activities of $70.6 million |

[0001564590-23-000754:8k_2_02:18]
|  | • | Free cash flow of $67.5 million |

[0001564590-23-000754:8k_2_02:19]
|  | • | Repurchased 2.6 million shares for $49.8 million |

[0001564590-23-000754:8k_2_02:20]
President and CEO Ed Meyercord stated: “Extreme delivered another quarter of great results. The continued strength of subscription and accelerated product deliveries drove another quarter of double-digit year-over-year revenue growth. We are raising our FY23 revenue growth outlook to the high-end of our 10-15% range and expect this momentum to continue into FY24, as the supply chain environment continues to improve.”

[0001564590-23-000754:8k_2_02:21]
“We feel confident in end customer demand. The majority of our bookings are with government, education, and healthcare sectors, where spending is more resilient. Our enhanced fabric and cloud

[0001564590-23-000754:8k_2_02:22]
subscription offerings are gaining traction in the marketplace. Finally, we have good visibility for the second half of year based on the strength of our sales funnel,” continued Meyercord.

[0001564590-23-000754:8k_2_02:23]
Regarding the CFO transition that was announced separately, Meyercord added: “We are excited that our very talented SVP of Finance, Cristina Tate, will step into the role of interim CFO. We wish Rémi Thomas nothing but success in his new venture.”

[0001564590-23-000754:8k_2_02:24]
Recent Key Highlights:

[0001564590-23-000754:8k_2_02:25]
|  | • | Extreme was named as a Leader by Gartner, Inc. for the fifth consecutive year in the Gartner® Magic Quadrant™ for Enterprise Wired and Wireless Local Access Network (LAN) Infrastructure.1 Extreme was cited for innovation around solutions like network fabric automation and digital twin. Extreme’s digital twin solution helps simplify staging, validation and deployment of switches and access points from the cloud and can help eliminate weeks or months associated with hardware deployments. |

[0001564590-23-000754:8k_2_02:26]
|  | • | Extreme extended its roster of E-Rate eligible solutions. Now schools across the U.S. can buy Wi-Fi 6E access points, ExtremeCloud™ IQ and CoPilot, and ExtremeCloud SD-WAN bundles. These solutions enable public schools and libraries to modernize their infrastructure and improve the availability and performance of key applications to create a better learning experience for students. |

[0001564590-23-000754:8k_2_02:27]
|  | • | Computerworld named Extreme one of its 2023 Best Places to Work in IT, which identifies top work environments for technology professionals. Extreme also ranked in the Top 10 lists for benefits, career development and hybrid work. |

[0001564590-23-000754:8k_2_02:28]
|  | • | City, University of London deployed ExtremeCloud IQ and Wi-Fi 6 access points across its campus, enabling it to simplify network management, increase bandwidth to ensure students can access online learning materials and gather network insights on user activity and performance to help it continuously improve student experiences and drive operational efficiencies. |

[0001564590-23-000754:8k_2_02:29]
|  | • | Chelsea and Westminster Hospital, a leading NHS Foundation Trust and teaching hospital, has to keep up with the many increasing demands on its network including bandwidth-heavy applications, telehealth visits and medical devices crucial for patient monitoring. With its new cloud-managed Wi-Fi 6E network, powered by ExtremeCloud IQ and the AP4000, the hospital can ensure connectivity for users, applications and devices across its clinical locations as well as best-in-class patient care. |

[0001564590-23-000754:8k_2_02:30]
1 Gartner Magic Quadrant for Enterprise Wired and Wireless LAN Infrastructure, December 21, 2022, Mike Toussaint, Christian Canales and Tim Zimmerman.

[0001564590-23-000754:8k_2_02:31]
Gartner® and Magic Quadrant™ are registered trademarks and service marks of Gartner, Inc. and/or its affiliates in the US and internationally and are used herein with permission.

[0001564590-23-000754:8k_2_02:32]
Gartner does not endorse any vendor, product or service depicted in its research publications, and does not advise

[0001564590-23-000754:8k_2_02:33]
technology users to select only those vendors with the highest rating or other designation. Gartner research publications consist of the opinions of Gartner’s research organization and should not be construed as statements of fact. Gartner disclaims all warranties, express or implied, with respect to this research, including any warranties of merchantability or fitness for a particular purpose.

[0001564590-23-000754:8k_2_02:34]
Fiscal Q2 2023 Financial Metrics:

[0001564590-23-000754:8k_2_02:35]
(in millions, except percentages and per share information)

[0001564590-23-000754:8k_2_02:36]
|  |  | GAAP Results |  |
|  |  | Three Months Ended |  |
|  |  | December 31, 2022 |  |  | December 31, 2021 |  |  | Change |  |
| Product |  | $ | 223.4 |  |  | $ | 191.1 |  |  | $ | 32.3 |  |  |  | 17 | % |
| Service and subscription |  |  | 94.9 |  |  |  | 89.8 |  |  |  | 5.1 |  |  |  | 6 | % |
| Total net revenue |  | $ | 318.3 |  |  | $ | 280.9 |  |  | $ | 37.4 |  |  |  | 13 | % |
| Gross margin |  |  | 57.1 | % |  |  | 56.5 | % |  |  | 0.6 | % |  |  | — |  |
| Operating margin |  |  | 7.4 | % |  |  | 6.4 | % |  |  | 1.0 | % |  |  | — |  |
| Net income |  | $ | 17.9 |  |  | $ | 13.3 |  |  | $ | 4.6 |  |  |  | 35 | % |
| Net income per diluted share |  | $ | 0.13 |  |  | $ | 0.10 |  |  | $ | 0.03 |  |  |  | 30 | % |

[0001564590-23-000754:8k_2_02:37]
|  |  | Non-GAAP Results |  |
|  |  | Three Months Ended |  |
|  |  | December 31, 2022 |  |  | December 31, 2021 |  |  | Change |  |
| Product |  | $ | 223.4 |  |  | $ | 191.1 |  |  | $ | 32.3 |  |  |  | 17 | % |
| Service and subscription |  |  | 94.9 |  |  |  | 89.8 |  |  |  | 5.1 |  |  |  | 6 | % |
| Total net revenue |  | $ | 318.3 |  |  | $ | 280.9 |  |  | $ | 37.4 |  |  |  | 13 | % |
| Gross margin |  |  | 58.5 | % |  |  | 58.2 | % |  |  | 0.3 | % |  |  | — |  |
| Operating margin |  |  | 14.9 | % |  |  | 13.1 | % |  |  | 1.8 | % |  |  | — |  |
| Net income |  | $ | 36.5 |  |  | $ | 28.4 |  |  | $ | 8.1 |  |  |  | 29 | % |
| Net income per diluted share |  | $ | 0.27 |  |  | $ | 0.21 |  |  | $ | 0.06 |  |  |  | 29 | % |

[0001564590-23-000754:8k_2_02:38]
|  | • | Q2 ending cash balance was $202.5 million, an increase of $4.2 million from the end of Q1. This was primarily driven by operating cash flow generation of $70.6 million, partially offset by cash usage of $63.5 million for financing activities primarily for payments against our term loan and stock repurchases and cash usage of $3.1 million for investing activities for capital expenditures. |

[0001564590-23-000754:8k_2_02:39]
|  | • | During Q2, we repurchased a total of 2.58 million shares of our common stock on the open market at a total cost of $49.8 million with a weighted average price of $19.32 per share. |

[0001564590-23-000754:8k_2_02:40]
|  | • | Q2 accounts receivable balance was $152.1 million, a decrease of $6.6 million from the end of Q1 and an increase of $18.8 million from Q2 last year. Days sales outstanding was 44 days, a decrease of 5 days from Q1 and consistent with Q2 last year. |

[0001564590-23-000754:8k_2_02:41]
|  | • | Q2 ending inventory was $63.8 million, an increase of $12.0 million from Q1 and an increase of $26.6 million from Q2 last year. The quarter-over-quarter and year-over-year increases were primarily driven by an increase in finished goods inventory. |

[0001564590-23-000754:8k_2_02:42]
|  | • | Q2 ending gross debt** was $262.0 million, a decrease of $9.5 million from the end of Q1 and decrease of $60.9 million from Q2 last year. The decrease from Q2 last year resulted primarily |

[0001564590-23-000754:8k_2_02:43]
|  |  | from principal payments on our term loan. Q2 ending net debt*** was $59.5 million, a decrease of $13.7 million from $73.2 million in Q1. |

[0001564590-23-000754:8k_2_02:44]
Extreme uses the non-GAAP free cash flow metric as a measure of operating performance. Free cash flow represents GAAP net cash provided by operating activities, less purchases of property, plant and equipment.  Extreme considers free cash flow to be useful information for management and investors regarding the amount of cash generated by the business after the purchases of property, plant and equipment, which can then be used to, among other things, invest in Extreme’s business, make strategic acquisitions, and strengthen the balance sheet. A limitation of the utility of this non-GAAP free cash flow metric as a measure of financial performance is that it does not represent the total increase or decrease in the Company's cash balance for the period. The following table shows non-GAAP free cash flow calculation (in thousands):

[0001564590-23-000754:8k_2_02:45]
| Free Cash Flow | Three Months Ended |  |  | Six Months Ended |  |
|  | December 31, 2022 |  |  | December 31, 2021 |  |  | December 31, 2022 |  |  | December 31, 2021 |  |
| Cash flow provided by operations | $ | 70,603 |  |  | $ | 22,228 |  |  | $ | 120,337 |  |  | $ | 62,482 |  |
| Less: Property and equipment capital expenditures |  | (3,132 | ) |  |  | (3,243 | ) |  |  | (6,271 | ) |  |  | (6,653 | ) |
| Total free cash flow | $ | 67,471 |  |  | $ | 18,985 |  |  | $ | 114,066 |  |  | $ | 55,829 |  |

[0001564590-23-000754:8k_2_02:46]
*SaaS ARR: Extreme uses SaaS annual recurring revenue (“SaaS ARR”) to identify the annual recurring revenue of ExtremeCloud™ IQ (XIQ) and other subscription revenue, based on the annualized value of quarterly subscription revenue and term-based licenses. We continue to refine our ARR methodology and have updated our Q1FY’23 ARR to $109.0 million from the $111.0 million reported last quarter. We believe that SaaS ARR is an important metric because it is driven by our ability to acquire new customers and to maintain and expand our relationships with existing customers. SaaS ARR should be viewed independently of revenue, deferred revenue and other U.S. GAAP accounting. SaaS ARR does not have a standardized meaning and therefore may not be comparable to similarly titled measures presented by other companies. SaaS ARR is not intended to be a replacement for forecasts of revenue.

[0001564590-23-000754:8k_2_02:47]
**Gross Debt: Gross debt is defined as long-term debt and the current portion of long-term debt as shown on the balance sheet plus unamortized debt issuance costs, if any.

[0001564590-23-000754:8k_2_02:48]
***Net Debt is defined as gross debt minus cash, as shown in the table below (in millions):

[0001564590-23-000754:8k_2_02:49]
| Gross debt |  |  | Cash |  |  | Net debt |  |
| $ | 262.0 |  |  | $ | 202.5 |  |  | $ | 59.5 |  |

[0001564590-23-000754:8k_2_02:50]
Business Outlook:

[0001564590-23-000754:8k_2_02:51]
For its third quarter of fiscal 2023, ending March 31, 2023, the Company is targeting:

[0001564590-23-000754:8k_2_02:52]
| (in millions, except percentages and per share information) | Low-End |  |  | High-End |  |
| FQ3'23 Guidance – GAAP |  |  |  |  |  |  |  |
| Total net revenue | $ | 315.0 |  |  | $ | 325.0 |  |
| Gross margin |  | 56.6 | % |  |  | 58.6 | % |
| Operating expenses | $ | 156.4 |  |  | $ | 161.4 |  |
| Operating margin |  | 6.9 | % |  |  | 8.9 | % |
| Net income | $ | 15.7 |  |  | $ | 23.0 |  |
| Net income per diluted share | $ | 0.12 |  |  | $ | 0.17 |  |
| Shares outstanding used in calculating GAAP EPS |  | 133.5 |  |  |  | 133.5 |  |
| FQ3’23 Guidance – Non-GAAP |  |  |  |  |  |  |  |
| Total net revenue | $ | 315.0 |  |  | $ | 325.0 |  |
| Gross margin |  | 58.0 | % |  |  | 60.0 | % |
| Operating expenses | $ | 140.1 |  |  | $ | 145.1 |  |
| Operating margin |  | 13.5 | % |  |  | 15.3 | % |
| Net income | $ | 31.1 |  |  | $ | 38.4 |  |
| Net income per diluted share | $ | 0.23 |  |  | $ | 0.29 |  |
| Shares outstanding used in calculating non-GAAP EPS |  | 133.5 |  |  |  | 133.5 |  |

[0001564590-23-000754:8k_2_02:53]
The following table shows the GAAP to non-GAAP reconciliation for Q3 FY’23 guidance:

[0001564590-23-000754:8k_2_02:54]
|  | Gross Margin Rate |  |  | Operating Margin Rate |  |  | Earnings per Share |  |
| GAAP | 56.6% - 58.6% |  |  | 6.9% - 8.9% |  |  | $0.12 - $0.17 |  |
| Estimated adjustments for: |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of product intangibles | 0.7% |  |  | 0.7% |  |  |  | 0.02 |  |
| Share-based compensation | 0.4% |  |  | 5.3% |  |  |  | 0.13 |  |
| Restructuring |  | — |  |  | 0.1% |  |  |  | 0.00 |  |
| Amortization of non-product intangibles | 0.3% |  |  | 0.4% |  |  |  | 0.01 |  |
| Tax effect of non-GAAP adjustments |  | — |  |  |  | — |  |  |  | (0.04) |  |
| Non-GAAP | 58.0% - 60.0% |  |  | 13.5% -15.3% |  |  | $0.23 - $0.29 |  |

[0001564590-23-000754:8k_2_02:55]
The total of percentage rate changes may not equal the total change in all cases due to rounding.

[0001564590-23-000754:8k_2_02:56]
Conference Call:

[0001564590-23-000754:8k_2_02:57]
Extreme will host a conference call at 8:00 a.m. Eastern (5:00 a.m. Pacific) today to review the Second fiscal quarter results as well as the business outlook for the third quarter ending March 31, 2023, including significant factors and assumptions underlying the targets noted above. The conference call will be available to the public through a live audio web broadcast via the internet at http://investor.extremenetworks.com and a replay of the call will be available on the website for at least 7 days following the call. To access the call by phone, please go to this link (Extreme Networks Q2'23 Earnings Registration Link) and you will be provided with dial in details. To avoid delays, we encourage participants to dial into the conference call fifteen minutes ahead of the scheduled start time.

[0001564590-23-000754:8k_2_02:58]
About Extreme:

[0001564590-23-000754:8k_2_02:59]
Extreme Networks, Inc. (EXTR) creates networking experiences that enable all of us to advance. We push the boundaries of technology leveraging the powers of machine learning, artificial intelligence, analytics, and automation. Over 50,000 customers globally trust our end-to-end, cloud-driven networking solutions and rely on our top-rated services and support to accelerate their digital transformation efforts and deliver

[0001564590-23-000754:8k_2_02:60]
progress like never before. For more information, visit Extreme's website at https://www.extremenetworks.com/ or LinkedIn, YouTube, Twitter, Facebook or Instagram

[0001564590-23-000754:8k_2_02:61]
Extreme Networks, ExtremeCloud, and the Extreme Networks logo, are trademarks of Extreme Networks, Inc. or its subsidiaries in the United States and/or other countries. Other trademarks shown herein are the property of their respective owners.

[0001564590-23-000754:8k_2_02:62]
Non-GAAP Financial Measures:

[0001564590-23-000754:8k_2_02:63]
Extreme provides all financial information required in accordance with U.S. generally accepted accounting principles (“GAAP”). The Company is providing with this press release non-GAAP gross margin, non-GAAP operating expenses, non-GAAP operating margin, non-GAAP operating income, non-GAAP net income, non-GAAP net income per diluted share, net debt and non-GAAP free cash flow. In preparing non-GAAP information, the Company has excluded, where applicable, the impact of share-based compensation, acquisition and integration costs, amortization of intangibles, restructuring charges and the tax effect of non-GAAP adjustments.  The Company believes that excluding these items provides both management and investors with additional insight into its current operations, the trends affecting the Company, the Company's marketplace performance, and the Company's ability to generate cash from operations. Please note the Company’s non-GAAP measures may be different than those used by other companies. The additional non-GAAP financial information the Company presents should be considered in conjunction with, and not as a substitute for, the Company’s GAAP financial information.

[0001564590-23-000754:8k_2_02:64]
The Company has provided a non-GAAP reconciliation of the results for the periods presented in this release, which are adjusted to exclude certain items as indicated.  These measures should only be used to evaluate the Company's results of operations in conjunction with the corresponding GAAP measures for comparable financial information and understanding of the Company’s ongoing performance as a business. Extreme uses both GAAP and non-GAAP measures to evaluate and manage its operations.

[0001564590-23-000754:8k_2_02:65]
Forward-Looking Statements:

[0001564590-23-000754:8k_2_02:66]
More information about potential factors that could affect the Company's business and financial results are described in “Management's Discussion and Analysis of Financial Condition and Results of Operations”

[0001564590-23-000754:8k_2_02:67]
and “Risk Factors” included in the Company’s Annual Report on Form 10-K for the year ended June 30, 2022, Quarterly Report on Form 10-Q for the quarter ended September 30, 2022, and other documents of the Company on file with the Securities and Exchange Commission (available at www.sec.gov).  As a result of these risks and others, actual results could vary significantly from those anticipated in this press release, and the Company’s financial condition and results of operations could be materially adversely affected. Except as required under the U.S. federal securities laws and the rules and regulations of the U.S. Securities and Exchange Commission, Extreme disclaims any obligation to update any forward-looking statements after the date of this release, whether as a result of new information, future events, developments, changes in assumptions or otherwise.

[0001564590-23-000754:8k_2_02:68]
###

[0001564590-23-000754:8k_2_02:69]
EXTREME NETWORKS, INC.

[0001564590-23-000754:8k_2_02:70]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0001564590-23-000754:8k_2_02:71]
(In thousands, except per share amounts)

[0001564590-23-000754:8k_2_02:72]
(Unaudited)

[0001564590-23-000754:8k_2_02:73]
|  |  | December 31, 2022 |  |  | June 30, 2022 |  |
| ASSETS |  |  |  |  |  |  |  |  |
| Current assets: |  |  |  |  |  |  |  |  |
| Cash |  | $ | 202,521 |  |  | $ | 194,522 |  |
| Accounts receivable, net |  |  | 152,050 |  |  |  | 184,097 |  |
| Inventories |  |  | 63,763 |  |  |  | 49,231 |  |
| Prepaid expenses and other current assets |  |  | 79,331 |  |  |  | 61,239 |  |
| Total current assets |  |  | 497,665 |  |  |  | 489,089 |  |
| Property and equipment, net |  |  | 45,711 |  |  |  | 49,578 |  |
| Operating lease right-of-use assets, net |  |  | 32,732 |  |  |  | 36,454 |  |
| Intangible assets, net |  |  | 22,984 |  |  |  | 32,515 |  |
| Goodwill |  |  | 393,495 |  |  |  | 400,144 |  |
| Other assets |  |  | 69,589 |  |  |  | 60,730 |  |
| Total assets |  | $ | 1,062,176 |  |  | $ | 1,068,510 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |  |  |  |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |  |  |  |
| Current portion of long-term debt, net of unamortized debt issuance costs of $2,181 and $2,276, respectively |  | $ | 35,819 |  |  | $ | 33,349 |  |
| Accounts payable |  |  | 86,350 |  |  |  | 84,338 |  |
| Accrued compensation and benefits |  |  | 63,401 |  |  |  | 53,710 |  |
| Accrued warranty |  |  | 11,820 |  |  |  | 10,852 |  |
| Current portion, operating lease liabilities |  |  | 12,095 |  |  |  | 13,956 |  |
| Current portion, deferred revenue |  |  | 260,891 |  |  |  | 238,262 |  |
| Other accrued liabilities |  |  | 58,726 |  |  |  | 65,714 |  |
| Total current liabilities |  |  | 529,102 |  |  |  | 500,181 |  |
| Deferred revenue, less current portion |  |  | 184,723 |  |  |  | 163,357 |  |
| Long-term debt, less current portion, net of unamortized debt issuance costs of $1,331 and $2,430, respectively |  |  | 222,669 |  |  |  | 270,570 |  |
| Operating lease liabilities, less current portion |  |  | 30,275 |  |  |  | 33,256 |  |
| Deferred income taxes |  |  | 7,555 |  |  |  | 7,717 |  |
| Other long-term liabilities |  |  | 3,285 |  |  |  | 3,086 |  |
| Commitments and contingencies |  |  |  |  |  |  |  |  |
| Stockholders’ equity: |  |  |  |  |  |  |  |  |
| Convertible preferred stock, $0.001 par value, issuable in series, 2,000 shares authorized; none issued |  |  | — |  |  |  | — |  |
| Common stock, $0.001 par value, 750,000 shares authorized; 142,137 and 139,742 shares issued, respectively; 129,080 and 129,263 shares outstanding, respectively |  |  | 142 |  |  |  | 140 |  |
| Additional paid-in-capital |  |  | 1,139,416 |  |  |  | 1,115,416 |  |
| Accumulated other comprehensive loss |  |  | (13,546 | ) |  |  | (3,055 | ) |
| Accumulated deficit |  |  | (903,556 | ) |  |  | (934,072 | ) |
| Treasury stock at cost, 13,057 and 10,479 shares, respectively |  |  | (137,889 | ) |  |  | (88,086 | ) |
| Total stockholders’ equity |  |  | 84,567 |  |  |  | 90,343 |  |
| Total liabilities and stockholders’ equity |  | $ | 1,062,176 |  |  | $ | 1,068,510 |  |

[0001564590-23-000754:8k_2_02:74]
EXTREME NETWORKS, INC.

[0001564590-23-000754:8k_2_02:75]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS

[0001564590-23-000754:8k_2_02:76]
(In thousands, except per share amounts)

[0001564590-23-000754:8k_2_02:77]
(Unaudited)

[0001564590-23-000754:8k_2_02:78]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | December 31, 2022 |  |  | December 31, 2021 |  |  | December 31, 2022 |  |  | December 31, 2021 |  |
| Net revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 223,445 |  |  | $ | 191,102 |  |  | $ | 429,721 |  |  | $ | 376,263 |  |
| Service and subscription |  |  | 94,903 |  |  |  | 89,831 |  |  |  | 186,316 |  |  |  | 172,354 |  |
| Total net revenues |  |  | 318,348 |  |  |  | 280,933 |  |  |  | 616,037 |  |  |  | 548,617 |  |
| Cost of revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  |  | 103,587 |  |  |  | 90,933 |  |  |  | 203,350 |  |  |  | 171,877 |  |
| Service and subscription |  |  | 33,106 |  |  |  | 31,214 |  |  |  | 64,324 |  |  |  | 62,351 |  |
| Total cost of revenues |  |  | 136,693 |  |  |  | 122,147 |  |  |  | 267,674 |  |  |  | 234,228 |  |
| Gross profit: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  |  | 119,858 |  |  |  | 100,169 |  |  |  | 226,371 |  |  |  | 204,386 |  |
| Service and subscription |  |  | 61,797 |  |  |  | 58,617 |  |  |  | 121,992 |  |  |  | 110,003 |  |
| Total gross profit |  |  | 181,655 |  |  |  | 158,786 |  |  |  | 348,363 |  |  |  | 314,389 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Research and development |  |  | 52,618 |  |  |  | 48,080 |  |  |  | 103,607 |  |  |  | 95,846 |  |
| Sales and marketing |  |  | 80,538 |  |  |  | 71,565 |  |  |  | 158,920 |  |  |  | 141,092 |  |
| General and administrative |  |  | 24,085 |  |  |  | 17,877 |  |  |  | 42,632 |  |  |  | 34,880 |  |
| Acquisition and integration costs |  |  | — |  |  |  | 2,113 |  |  |  | 390 |  |  |  | 3,623 |  |
| Restructuring and related charges |  |  | 476 |  |  |  | 292 |  |  |  | 957 |  |  |  | 571 |  |
| Amortization of intangibles |  |  | 504 |  |  |  | 804 |  |  |  | 1,027 |  |  |  | 1,958 |  |
| Total operating expenses |  |  | 158,221 |  |  |  | 140,731 |  |  |  | 307,533 |  |  |  | 277,970 |  |
| Operating income |  |  | 23,434 |  |  |  | 18,055 |  |  |  | 40,830 |  |  |  | 36,419 |  |
| Interest income |  |  | 889 |  |  |  | 83 |  |  |  | 1,281 |  |  |  | 193 |  |
| Interest expense |  |  | (3,884 | ) |  |  | (3,076 | ) |  |  | (7,710 | ) |  |  | (6,956 | ) |
| Other income, net |  |  | 138 |  |  |  | 72 |  |  |  | 509 |  |  |  | 243 |  |
| Income before income taxes |  |  | 20,577 |  |  |  | 15,134 |  |  |  | 34,910 |  |  |  | 29,899 |  |
| Provision for income taxes |  |  | 2,646 |  |  |  | 1,793 |  |  |  | 4,394 |  |  |  | 3,862 |  |
| Net income |  | $ | 17,931 |  |  | $ | 13,341 |  |  | $ | 30,516 |  |  | $ | 26,037 |  |
| Basic and diluted income per share: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income per share – basic |  | $ | 0.14 |  |  | $ | 0.10 |  |  | $ | 0.23 |  |  | $ | 0.20 |  |
| Net income per share – diluted |  | $ | 0.13 |  |  | $ | 0.10 |  |  | $ | 0.23 |  |  | $ | 0.20 |  |
| Shares used in per share calculation – basic |  |  | 130,465 |  |  |  | 129,403 |  |  |  | 130,377 |  |  |  | 128,863 |  |
| Shares used in per share calculation – diluted |  |  | 134,453 |  |  |  | 133,621 |  |  |  | 133,833 |  |  |  | 133,423 |  |

[0001564590-23-000754:8k_2_02:79]
EXTREME NETWORKS, INC.

[0001564590-23-000754:8k_2_02:80]
CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS

[0001564590-23-000754:8k_2_02:81]
(In thousands)

[0001564590-23-000754:8k_2_02:82]
(Unaudited)

[0001564590-23-000754:8k_2_02:83]
|  |  | Six Months Ended |  |
|  |  | December 31, 2022 |  |  | December 31, 2021 |  |
| Cash flows from operating activities: |  |  |  |  |  |  |  |  |
| Net Income |  | $ | 30,516 |  |  | $ | 26,037 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |  |  |  |  |
| Depreciation |  |  | 9,983 |  |  |  | 10,233 |  |
| Amortization of intangible assets |  |  | 7,852 |  |  |  | 11,393 |  |
| Reduction in carrying amount of right-of-use asset |  |  | 6,240 |  |  |  | 7,778 |  |
| Provision for doubtful accounts |  |  | 102 |  |  |  | 14 |  |
| Share-based compensation |  |  | 31,185 |  |  |  | 21,777 |  |
| Deferred income taxes |  |  | 65 |  |  |  | 890 |  |
| Non-cash interest expense |  |  | 764 |  |  |  | 2,517 |  |
| Other |  |  | (5,904 | ) |  |  | (474 | ) |
| Changes in operating assets and liabilities, net of acquisition: |  |  |  |  |  |  |  |  |
| Accounts receivable |  |  | 31,944 |  |  |  | 24,626 |  |
| Inventories |  |  | (14,506 | ) |  |  | (4,239 | ) |
| Prepaid expenses and other assets |  |  | (6,557 | ) |  |  | (34,215 | ) |
| Accounts payable |  |  | 2,164 |  |  |  | (2,505 | ) |
| Accrued compensation and benefits |  |  | 9,170 |  |  |  | (8,378 | ) |
| Operating lease liabilities |  |  | (7,383 | ) |  |  | (9,675 | ) |
| Deferred revenue |  |  | 28,776 |  |  |  | 17,785 |  |
| Other current and long-term liabilities |  |  | (4,074 | ) |  |  | (1,082 | ) |
| Net cash provided by operating activities |  |  | 120,337 |  |  |  | 62,482 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |
| Capital expenditures |  |  | (6,271 | ) |  |  | (6,653 | ) |
| Business acquisition, net of cash acquired |  |  | — |  |  |  | (69,517 | ) |
| Net cash used in investing activities |  |  | (6,271 | ) |  |  | (76,170 | ) |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |
| Payments on debt obligations |  |  | (46,625 | ) |  |  | (23,875 | ) |
| Repurchase of common stock |  |  | (49,803 | ) |  |  | (24,974 | ) |
| Payments for tax withholdings, net of proceeds from issuance of common stock |  |  | (7,183 | ) |  |  | (7,729 | ) |
| Payment of contingent consideration obligations |  |  | — |  |  |  | (816 | ) |
| Deferred payments on an acquisition |  |  | (2,000 | ) |  |  | (2,000 | ) |
| Net cash used in financing activities |  |  | (105,611 | ) |  |  | (59,394 | ) |
| Foreign currency effect on cash |  |  | (456 | ) |  |  | (264 | ) |
| Net increase (decrease) in cash |  |  | 7,999 |  |  |  | (73,346 | ) |
| Cash at beginning of period |  |  | 194,522 |  |  |  | 246,894 |  |
| Cash at end of period |  | $ | 202,521 |  |  | $ | 173,548 |  |

[0001564590-23-000754:8k_2_02:84]
Extreme Networks, Inc.

[0001564590-23-000754:8k_2_02:85]
Non-GAAP Measures of Financial Performance

[0001564590-23-000754:8k_2_02:86]
To supplement the Company's consolidated financial statements presented in accordance with U.S. generally accepted accounting principles (“GAAP”), Extreme uses non-GAAP measures of certain components of financial performance.  These non-GAAP measures include non-GAAP gross margin, non-GAAP operating expenses, non-GAAP operating margin, non-GAAP operating income, non-GAAP net income, non-GAAP net income per diluted share, net debt and non-GAAP free cash flow.

[0001564590-23-000754:8k_2_02:87]
Reconciliation to the nearest GAAP measure of all historical non-GAAP measures included in this press release can be found in the tables included with this press release.

[0001564590-23-000754:8k_2_02:88]
Non-GAAP measures presented in this press release are not in accordance with or alternative measures prepared in accordance with GAAP and may be different from non-GAAP measures used by other companies.  In addition, these non-GAAP measures are not based on any comprehensive set of accounting rules or principles.  Non-GAAP measures have limitations in that they do not reflect all of the amounts associated with Extreme’s results of operations as determined in accordance with GAAP.  These non-GAAP measures should only be used to evaluate Extreme’s results of operations in conjunction with the corresponding GAAP measures.

[0001564590-23-000754:8k_2_02:89]
Extreme believes these non-GAAP measures, when shown in conjunction with the corresponding GAAP measures, enhance investors' and management's overall understanding of the Company's current financial performance and the Company's prospects for the future, including cash flows available to pursue opportunities to enhance stockholder value.  In addition, because Extreme has historically reported certain non-GAAP results to investors, the Company believes the inclusion of non-GAAP measures provides consistency in the Company's financial reporting.

[0001564590-23-000754:8k_2_02:90]
For its internal planning process, and as discussed further below, Extreme's management uses financial statements that do not include share-based compensation expense, acquisition and integration costs, amortization of intangibles, restructuring charges, and the tax effect of non-GAAP adjustments.  Extreme’s management also uses non-GAAP measures, in addition to the corresponding GAAP measures, in reviewing the Company's financial results.

[0001564590-23-000754:8k_2_02:91]
As described above, Extreme excludes the following items from one or more of its non-GAAP measures when applicable.

[0001564590-23-000754:8k_2_02:92]
Share-based compensation. Consists of associated expenses for stock options, restricted stock awards and the Company’s Employee Stock Purchase Plan.  Extreme excludes share-based compensation expenses from its non-GAAP measures primarily because they are non-cash expenses that the Company does not believe are reflective of ongoing cash requirement related to its operating results. Extreme expects to incur share-based compensation expenses in future periods.

[0001564590-23-000754:8k_2_02:93]
Acquisition and integration costs. Acquisition and integration costs consist of specified compensation charges, software charges, and legal and professional fees related to the acquisition of Ipanema.  Extreme excludes these expenses since they result from an event that is outside the ordinary course of continuing operations.

[0001564590-23-000754:8k_2_02:94]
Amortization of intangibles. Amortization of intangibles includes the monthly amortization expense of intangible assets such as developed technology, customer relationships, trademarks and order backlog.  The amortization of the developed technology and order backlog are recorded in cost of goods sold, while the amortization for the other intangibles is recorded in operating expenses.  Extreme excludes these expenses since they result from an intangible asset and for which the period expense does not impact the operations of the business and are non-cash in nature.

[0001564590-23-000754:8k_2_02:95]
Restructuring charges. Restructuring charges primarily consist of severance costs for employees which have no benefit to continuing operations and impairment of right-of-use assets, long-lived assets and other charges related to excess facilities. Extreme excludes restructuring expenses since they result from events that occur outside of the ordinary course of continuing operations.

[0001564590-23-000754:8k_2_02:96]
Tax effect of non-GAAP adjustments. We calculate our non-GAAP provision for income taxes in accordance with the SEC guidance on non-GAAP Financial Measures Compliance and Disclosure Interpretation.  We have assumed our U.S. federal and state net operating losses would have been fully consumed by the historical non-GAAP financial adjustments, eliminating the need for a full valuation allowance against our U.S. deferred tax assets which, consequently, enables our use of research and development tax credits.  The non-GAAP tax provision consists of current and deferred income tax expense commensurate with the non-GAAP measure of profitability using our blended U.S. statutory tax rate of 24.2%.

[0001564590-23-000754:8k_2_02:97]
Non-GAAP provision for income taxes may be higher or lower depending on the level and jurisdictional mix of pre-tax income and available U.S. research and development tax credits.  As of the tax year ended June 30, 2022, we have U.S. federal net operating loss carryforwards of $184.4 million, state net operating loss carryforwards of $162.8 million and net operating loss carryforwards for the Irish holding Company of $8.9 million.  These amounts will be reflected in our requisite tax filings for each jurisdiction for the tax year ended June 30, 2022. We anticipate utilization of a portion of these net operating losses in each of the jurisdictions for the tax year ended June 30, 2023; however, we do not expect to pay substantial cash taxes in the U.S. in the near term due to our net operating loss carryforwards.  Over the near term, most of our cash taxes will continue to be mainly driven by the tax expense of our foreign subsidiaries which amounts have not historically been significant, with the exception of the Company’s Indian subsidiary which performs research and development activities, as well as the Company’s Irish operating company subsidiary which fully utilized available net operating loss carryforwards during the tax year ended June 30, 2021.

[0001564590-23-000754:8k_2_02:98]
EXTREME NETWORKS, INC.

[0001564590-23-000754:8k_2_02:99]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS

[0001564590-23-000754:8k_2_02:100]
GAAP TO NON-GAAP RECONCILIATION

[0001564590-23-000754:8k_2_02:101]
(In thousands, except percentages and per share amounts)

[0001564590-23-000754:8k_2_02:102]
(Unaudited)

[0001564590-23-000754:8k_2_02:103]
| Revenues | Three Months Ended | Six Months Ended |  |
|  | December 31, 2022 |  |  | December 31, 2021 |  |  | December 31, 2022 |  |  | December 31, 2021 |  |
| Revenues – GAAP | $ | 318,348 |  |  | $ | 280,933 |  |  | $ | 616,037 |  |  | $ | 548,617 |  |

[0001564590-23-000754:8k_2_02:104]
| Non-GAAP Gross Margin | Three Months Ended | Six Months Ended |  |
|  | December 31, 2022 |  |  | December 31, 2021 |  |  | December 31, 2022 |  |  | December 31, 2021 |  |
| Gross profit – GAAP | $ | 181,655 |  |  | $ | 158,786 |  |  | $ | 348,363 |  |  | $ | 314,389 |  |
| Gross margin – GAAP percentage |  | 57.1 | % |  |  | 56.5 | % |  |  | 56.5 | % |  |  | 57.3 | % |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expense, Product |  | 499 |  |  |  | 303 |  |  |  | 873 |  |  |  | 613 |  |
| Share-based compensation expense, Service and subscription |  | 966 |  |  |  | 351 |  |  |  | 1,638 |  |  |  | 713 |  |
| Amortization of intangibles, Product |  | 2,388 |  |  |  | 3,317 |  |  |  | 5,161 |  |  |  | 7,771 |  |
| Amortization of intangibles, Service and subscription |  | 815 |  |  |  | 815 |  |  |  | 1,629 |  |  |  | 1,630 |  |
| Total adjustments to GAAP gross profit | $ | 4,668 |  |  | $ | 4,786 |  |  | $ | 9,301 |  |  | $ | 10,727 |  |
| Gross profit – non-GAAP | $ | 186,323 |  |  | $ | 163,572 |  |  | $ | 357,664 |  |  | $ | 325,116 |  |
| Gross margin – non-GAAP percentage |  | 58.5 | % |  |  | 58.2 | % |  |  | 58.1 | % |  |  | 59.3 | % |

[0001564590-23-000754:8k_2_02:105]
| Non-GAAP Operating Income | Three Months Ended | Six Months Ended |  |
|  | December 31, 2022 |  |  | December 31, 2021 |  |  | December 31, 2022 |  |  | December 31, 2021 |  |
| GAAP operating income | $ | 23,434 |  |  | $ | 18,055 |  |  | $ | 40,830 |  |  | $ | 36,419 |  |
| GAAP operating income percentage |  | 7.4 | % |  |  | 6.4 | % |  |  | 6.6 | % |  |  | 6.6 | % |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expense, cost of revenues |  | 1,465 |  |  |  | 654 |  |  |  | 2,511 |  |  |  | 1,326 |  |
| Share-based compensation expense, R&D |  | 3,962 |  |  |  | 2,664 |  |  |  | 7,052 |  |  |  | 5,122 |  |
| Share-based compensation expense, S&M |  | 5,910 |  |  |  | 3,860 |  |  |  | 10,549 |  |  |  | 7,435 |  |
| Share-based compensation expense, G&A |  | 6,059 |  |  |  | 4,155 |  |  |  | 11,073 |  |  |  | 7,894 |  |
| Acquisition and integration costs |  | — |  |  |  | 2,113 |  |  |  | 390 |  |  |  | 3,623 |  |
| Restructuring charges |  | 476 |  |  |  | 292 |  |  |  | 957 |  |  |  | 571 |  |
| Litigation charges |  | 2,324 |  |  |  | — |  |  |  | 2,324 |  |  |  | — |  |
| Amortization of intangibles |  | 3,707 |  |  |  | 4,936 |  |  |  | 7,817 |  |  |  | 11,359 |  |
| Total adjustments to GAAP operating income | $ | 23,903 |  |  | $ | 18,674 |  |  | $ | 42,673 |  |  | $ | 37,330 |  |
| Non-GAAP operating income | $ | 47,337 |  |  | $ | 36,729 |  |  | $ | 83,503 |  |  | $ | 73,749 |  |
| Non-GAAP operating income percentage |  | 14.9 | % |  |  | 13.1 | % |  |  | 13.6 | % |  |  | 13.4 | % |

[0001564590-23-000754:8k_2_02:106]
| Non-GAAP net income | Three Months Ended | Six Months Ended |  |
|  | December 31, 2022 |  |  | December 31, 2021 |  |  | December 31, 2022 |  |  | December 31, 2021 |  |
| GAAP net income | $ | 17,931 |  |  | $ | 13,341 |  |  | $ | 30,516 |  |  | $ | 26,037 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expense |  | 17,396 |  |  |  | 11,333 |  |  |  | 31,185 |  |  |  | 21,777 |  |
| Acquisition and integration costs |  | — |  |  |  | 2,113 |  |  |  | 390 |  |  |  | 3,623 |  |
| Restructuring charge, net of reversal |  | 476 |  |  |  | 292 |  |  |  | 957 |  |  |  | 571 |  |
| Litigation charges |  | 2,324 |  |  |  | — |  |  |  | 2,324 |  |  |  | — |  |
| Amortization of intangibles |  | 3,707 |  |  |  | 4,936 |  |  |  | 7,817 |  |  |  | 11,359 |  |
| Tax effect of non-GAAP adjustments |  | (5,354 | ) |  |  | (3,580 | ) |  |  | (9,622 | ) |  |  | (6,980 | ) |
| Total adjustments to GAAP net income | $ | 18,549 |  |  | $ | 15,094 |  |  | $ | 33,051 |  |  | $ | 30,350 |  |
| Non-GAAP net income | $ | 36,480 |  |  | $ | 28,435 |  |  | $ | 63,567 |  |  | $ | 56,387 |  |
| Earnings per share |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| GAAP net income per share – diluted | $ | 0.13 |  |  | $ | 0.10 |  |  | $ | 0.23 |  |  | $ | 0.20 |  |
| Non-GAAP net income per share – diluted | $ | 0.27 |  |  | $ | 0.21 |  |  | $ | 0.47 |  |  | $ | 0.42 |  |
| Shares used in net income per share – diluted: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| GAAP Shares used in per share calculation – basic |  | 130,465 |  |  |  | 129,403 |  |  |  | 130,377 |  |  |  | 128,863 |  |
| Potentially dilutive equity awards |  | 3,988 |  |  |  | 4,218 |  |  |  | 3,456 |  |  |  | 4,560 |  |
| GAAP and Non-GAAP shares used in per share calculation – diluted |  | 134,453 |  |  |  | 133,621 |  |  |  | 133,833 |  |  |  | 133,423 |  |
