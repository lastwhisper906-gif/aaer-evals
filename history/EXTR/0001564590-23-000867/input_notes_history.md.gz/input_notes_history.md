# EXTR note change history — 0001564590-22-035673 → 0001564590-23-000867


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2023-01-27):
[0001564590-23-000867:note_history:1]
The Company currently has arrangements with contract manufacturers and suppliers for the manufacture of its products. Those arrangements allow the contract manufacturers to procure long lead-time component inventory based upon a rolling production forecast provided by the Company. The Company is obligated to purchase long lead-time component inventory that its contract manufacturer procures in accordance with the forecast, unless the Company gives notice of order cancellation outside of applicable component lead-times. As of December 31, 2022, the Company had commitments to purchase $57.1 million of inventory.
  (was, 2022-10-28, similarity 0.9942):
[0001564590-22-035673:note_history:1]
The Company currently has arrangements with contract manufacturers and suppliers for the manufacture of its products. Those arrangements allow the contract manufacturers to procure long lead-time component inventory based upon a rolling production forecast provided by the Company. The Company is obligated to purchase long lead-time component inventory that its contract manufacturer procures in accordance with the forecast, unless the Company gives notice of order cancellation outside of applicable component lead-times. As of September 30, 2022, the Company had commitments to purchase $52.4 million of inventory.

- changed (2023-01-27):
[0001564590-23-000867:note_history:2]
On April 19, 2017, XR Communications, LLC (“XR”) (d/b/a Vivato Technologies) filed a patent infringement lawsuit against the Company in the Central District of California. The operative Second Amended Complaint asserts infringement of certain U.S. Patents based on the Company’s manufacture, use, sale, offer for sale, and/or importation into the United States of certain access points and routers supporting multi-user, multiple-input, multiple-output technology. XR seeks unspecified damages, on-going royalties, pre- and post-judgment interest, and attorneys’ fees. The Court dismissed the case without prejudice on January 4, 2022 and on April 18, 2022, entered final judgment in favor of the Company. XR filed a notice of appeal on May 9, 2022 and the Company and other defendants filed a response brief on November 7, 2022.
  (was, 2022-10-28, similarity 0.9498):
[0001564590-22-035673:note_history:2]
On April 19, 2017, XR Communications, LLC (“XR”) (d/b/a Vivato Technologies) filed a patent infringement lawsuit against the Company in the Central District of California. The operative Second Amended Complaint asserts infringement of certain U.S. Patent based on the Company’s manufacture, use, sale, offer for sale, and/or importation into the United States of certain access points and routers supporting multi-user, multiple-input, multiple-output technology. XR seeks unspecified damages, on-going royalties, pre- and post-judgment interest, and attorneys’ fees. The Court dismissed the case without prejudice on January 4, 2022 and on April 18, 2022, entered final judgment in favor of the Company. XR filed a notice of appeal on May 9, 2022 and a response brief from the Company and other defendants is due on November 2, 2022.

- changed (2023-01-27):
[0001564590-23-000867:note_history:3]
On April 23, 2019, Orckit filed an extension of the patent infringement complaint against the Company and its Irish and German subsidiaries in the District Court in Dusseldorf, Germany. With this extension, Orckit alleges infringement of the German portion of a second patent (“EP ‘077”) based on the offer, distribution, use, possession and/or importation into Germany of certain network switches that the Company no longer sells in Germany. Orckit is seeking injunctive relief, accounting and sales information, and a declaration of liability for damages as well as costs of the lawsuit. On October 13, 2020, the Court issued an infringement decision against the Company and granted Orckit the right to enforce the judgment against the Company, which Orckit has provided notification to the Company that it will enforce the judgment. In the rendering of account, Orckit was informed that the products at issue were in end of sale status prior to the filing of the EP ‘077 complaint. The Company has appealed the infringement decision, and the matter is proceeding through the appellate process.
  (was, 2022-10-28, similarity 0.9995):
[0001564590-22-035673:note_history:3]
On April 23, 2019, Orckit filed an extension of the patent infringement complaint against the Company and its Irish and German subsidiaries in the District Court in Dusseldorf, Germany. With this extension, Orckit alleges infringement of the German portion of a second patent (“EP ‘077”) based on the offer, distribution, use, possession and/or importation into Germany of certain network switches that the Company no longer sells in Germany. Orckit is seeking injunctive relief, accounting and sales information, and a declaration of liability for damages as well as costs of the lawsuit. On October 13, 2020, the Court issued an infringement decision against the Company and granted Orckit the right to enforce the judgment against the Company, which Orckit has provided notification to the Company that it will enforce the judgment. In the rendering of account, Orckit was informed that the products at issue were in end of sale status prior to the filing of the EP‘077 complaint. The Company has appealed the infringement decision, and the matter is proceeding through the appellate process.

- changed (2023-01-27):
[0001564590-23-000867:note_history:4]
The Company filed a nullity action related to the EP ‘364 patent on May 3, 2018, and one related to the EP ‘077 patent on October 31, 2019, both in the Federal Patent Court in Munich. The Federal Patent Court in Munich found the EP ‘364 patent to be valid and the Company has filed an appeal. On October 25, 2022, the Federal Patent Court in Munich issued an opinion partially invalidating the EP ‘077 patent and the Company has filed an appeal.
  (was, 2022-10-28, similarity 0.9323):
[0001564590-22-035673:note_history:4]
The Company filed a nullity action related to the EP ‘364 patent on May 3, 2018, and one related to the EP ‘077 patent on October 31, 2019, both in the Federal Patent Court in Munich. The Federal Patent Court in Munich found the EP ‘364 patent to be valid and the Company has filed an appeal. On October 25, 2022, the Federal Patent Court in Munich issued an opinion partially invalidating the patent.

- changed (2023-01-27):
[0001564590-23-000867:note_history:5]
On October 26, 2020, SNMP Research, Inc. and SNMP Research International, Inc. (collectively, “SNMP”) filed a lawsuit against the Company in the Eastern District of Tennessee for copyright infringement, alleging that the Company was not properly licensed to use its software.  SNMP is seeking actual damages and profits attributed to the infringement, as well as equitable relief. The Company filed a motion to transfer the case to the Northern District of California. The motion to dismiss was denied in part and denied without prejudice in part. The Company also filed, and was granted, a motion to compel mediation. The parties conducted a  mediation from January 19 to January 26, 2023. The trial date set for February 2023 has been rescheduled to January 2024.
  (was, 2022-10-28, similarity 0.8632):
[0001564590-22-035673:note_history:5]
On October 26, 2020, SNMP Research, Inc. and SNMP Research International, Inc. (collectively, “SNMP”) filed a lawsuit against the Company in the Eastern District of Tennessee for copyright infringement, alleging that the Company was not properly licensed to use its software.  SNMP is seeking actual damages and profits attributed to the infringement, as well as equitable relief. The Company filed a motion to transfer the case to the Northern District of California. The motion to dismiss was denied in part and denied without prejudice in part. The Company also filed, and was granted, a motion to compel mediation.  The parties have selected a mediator and set a mediation date of January 19, 2023. The trial date set for February 2023 has been rescheduled to January 2024.

- changed (2023-01-27):
[0001564590-23-000867:note_history:6]
On April 15, 2021, Mala Technologies Ltd. (“Mala”) filed a patent infringement lawsuit against the Company and its Irish and German subsidiaries in the District Court in Dusseldorf, Germany.  The lawsuit alleges indirect infringement of the German portion of a patent (“EP ‘498”) based on the offer and sale in Germany of certain network switches equipped with the ExtremeXOS operating system.  Mala is seeking injunctive relief, accounting, and an unspecified declaration of liability for damages and costs of the lawsuit. On December 20, 2022, the trial court ruled that the Company did not infringe the EP ‘498 patent and dismissed Mala’s complaint entirely. Mala has filed an appeal.
  (was, 2022-10-28, similarity 0.7531):
[0001564590-22-035673:note_history:6]
On April 15, 2021, Mala Technologies Ltd. (“Mala”) filed a patent infringement lawsuit against the Company and its Irish and German subsidiaries in the District Court in Dusseldorf, Germany.  The lawsuit alleges indirect infringement of the German portion of a patent (“EP ‘498”) based on the offer and sale in Germany of certain network switches equipped with the ExtremeXOS operating system.  Mala is seeking injunctive relief, accounting, and an unspecified declaration of liability for damages and costs of the lawsuit.  A hearing date that had been set for July 14, 2022 has been postponed until November 22, 2022. The Company filed a nullity action related to the EP’498 patent on September 24, 2021 in the German Federal Patent Court.

- added (2023-01-27):
[0001564590-23-000867:note_history:7]
The Company filed a nullity complaint against EP ‘498 with the German Federal Patent Court on September 24, 2021. This matter is still pending.

- changed (2023-01-27):
[0001564590-23-000867:note_history:8]
Subject to certain limitations, the Company may be obligated to indemnify its current and former directors, officers and employees. These obligations arise under the terms of its certificate of incorporation, its bylaws, applicable contracts, and applicable law. The obligation to indemnify, where applicable, generally means that the Company is required to pay or reimburse, and in certain circumstances the Company has paid or reimbursed, the individuals’ reasonable legal expenses and possible damages and other liabilities incurred in connection with certain legal matters. The Company also procures Directors and Officers liability insurance to help cover its defense and/or indemnification costs, although its ability to recover such costs through insurance is uncertain.  While it is not possible to estimate the maximum potential amount that could be owed under these governing documents and agreements due to the Company’s limited history with prior indemnification claims, indemnification (including defense) costs could, in the future, have a material adverse effect on the Company’s consolidated financial position, results of operations and cash flows.
  (was, 2022-10-28, similarity 0.9991):
[0001564590-22-035673:note_history:8]
Subject to certain limitations, the Company may be obligated to indemnify its current and former directors, officers and employees. These obligations arise under the terms of its certificate of incorporation, its bylaws, applicable contracts, and applicable law. The obligation to indemnify, where applicable, generally means that the Company is required to pay or reimburse, and in certain circumstances the Company has paid or reimbursed, the individuals’ reasonable legal expenses and possibly damages and other liabilities incurred in connection with certain legal matters. The Company also procures Directors and Officers liability insurance to help cover its defense and/or indemnification costs, although its ability to recover such costs through insurance is uncertain.  While it is not possible to estimate the maximum potential amount that could be owed under these governing documents and agreements due to the Company’s limited history with prior indemnification claims, indemnification (including defense) costs could, in the future, have a material adverse effect on the Company’s consolidated financial position, results of operations and cash flows.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2023-01-27):
[0001564590-23-000867:note_history:9]
The unaudited condensed consolidated financial statements of Extreme included herein have been prepared under the rules and regulations of the Securities and Exchange Commission (“SEC”). Certain information and footnote disclosures normally included in financial statements prepared in accordance with U.S. generally accepted accounting principles have been condensed or omitted under such rules and regulations. The condensed consolidated balance sheet at June 30, 2022 was derived from audited financial statements as of that date but does not include all disclosures required by generally accepted accounting principles for complete financial statements. These interim financial statements and notes should be read in conjunction with the Company’s audited consolidated financial statements and notes thereto included in the Company’s Annual Report on Form 10-K for the fiscal year ended June 30, 2022.
  (was, 2022-10-28, similarity 0.9994):
[0001564590-22-035673:note_history:9]
The unaudited condensed consolidated financial statements of Extreme included herein have been prepared under the rules and regulations of the Securities and Exchange Commission (“SEC”). Certain information and footnote disclosures normally included in financial statements prepared in accordance with U.S. generally accepted accounting principles have been condensed or omitted under such rules and regulations. The condensed consolidated balance sheets at June 30, 2022 was derived from audited financial statements as of that date but does not include all disclosures required by generally accepted accounting principles for complete financial statements. These interim financial statements and notes should be read in conjunction with the Company’s audited consolidated financial statements and notes thereto included in the Company’s Annual Report on Form 10-K for the fiscal year ended June 30, 2022.

- changed (2023-01-27):
[0001564590-23-000867:note_history:10]
The unaudited condensed consolidated financial statements reflect all adjustments, consisting only of normal recurring adjustments that, in the opinion of management, are necessary for a fair presentation of the results of operations and cash flows for the interim periods presented and the financial condition of Extreme at December 31, 2022. The results of operations for the three and six months ended December 31, 2022 are not necessarily indicative of the results that may be expected for fiscal 2023 or any future periods.
  (was, 2022-10-28, similarity 0.775):
[0001564590-22-035673:note_history:10]
The unaudited condensed consolidated financial statements reflect all adjustments, consisting only of normal recurring adjustments that, in the opinion of management, are necessary for a fair presentation of the results of operations and cash flows for the interim periods presented and the financial condition of Extreme at September 30, 2022. The results of operations for the three months ended September 30, 2022 are not necessarily indicative of the results that may be expected for fiscal 2023 or any future periods.

- changed (2023-01-27):
[0001564590-23-000867:note_history:11]
The Company uses a fiscal calendar year ending on June 30. All references herein to “fiscal 2023” represent the fiscal year ending June 30, 2023. All references herein to “fiscal 2022”  represent the fiscal year ended June 30, 2022.
  (was, 2022-10-28, similarity 0.9679):
[0001564590-22-035673:note_history:11]
The Company uses a fiscal calendar year ending on June 30. All references herein to “fiscal 2023” or “2023” represent the fiscal year ending June 30, 2023. All references herein to “fiscal 2022” or “2022” represent the fiscal year ended June 30, 2022.


## us-gaap:SignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- added (2023-01-27):
[0001564590-23-000867:note_history:12]
In December 2022, the Financial Accounting Standards Board (“FASB”) issued Accounting Standard Update (“ASU”) 2022-06, Reference Rate Reform (Topic 848): Deferral of the Sunset Date of Topic 848, which extends the period of time entities can utilize the reference rate reform relief guidance under ASU 2020-04, Reference Rate Reform (Topic 848): Facilitation of the Effects of Reference Rate Reform on Financial Reporting from December 31, 2022 to December 31, 2024. Upon issuance of ASU 2020-04, the Company elected to apply certain of the optional expedients for contract modifications to its financial instruments impacted by the London Interbank Offered Rate (“LIBOR”) discontinuance. The Company expects to continue to elect various optional expedients for contract

- added (2023-01-27):
[0001564590-23-000867:note_history:13]
modifications to the Company’s financial instruments affected by the reference rate reform through the effective date of December 31, 2024, as extended by ASU 2022-06. The application of this guidance did not have any impact on our consolidated financial statements.

- removed (2023-01-27):
[0001564590-22-035673:note_history:14]
There were no recently adopted accounting standards which would have a material effect on our condensed consolidated financial statements and accompanying disclosures, and no recently issued accounting standards that are expected to have a material impact on our condensed consolidated financial statements and accompanying disclosures.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2023-01-27):
[0001564590-23-000867:note_history:15]
|  |  | December 31, 2022 |  |  | June 30, 2022 |  |
| Current portion of long-term debt: |  |  |  |  |  |  |  |  |
| Term Loan |  | $ | 38,000 |  |  | $ | 35,625 |  |
| Less: unamortized debt issuance costs |  |  | (2,181 | ) |  |  | (2,276 | ) |
| Current portion of long-term debt |  | $ | 35,819 |  |  | $ | 33,349 |  |
| Long-term debt, less current portion: |  |  |  |  |  |  |  |  |
| Term Loan |  | $ | 224,000 |  |  | $ | 273,000 |  |
| Less: unamortized debt issuance costs |  |  | (1,331 | ) |  |  | (2,430 | ) |
| Total long-term debt, less current portion |  |  | 222,669 |  |  |  | 270,570 |  |
| Total debt |  | $ | 258,488 |  |  | $ | 303,919 |  |
  (was, 2022-10-28, similarity 0.9934):
[0001564590-22-035673:note_history:15]
|  |  | September 30, 2022 |  |  | June 30, 2022 |  |
| Current portion of long-term debt: |  |  |  |  |  |  |  |  |
| Term Loan |  | $ | 38,000 |  |  | $ | 35,625 |  |
| Less: unamortized debt issuance costs |  |  | (2,236 | ) |  |  | (2,276 | ) |
| Current portion of long-term debt |  | $ | 35,764 |  |  | $ | 33,349 |  |
| Long-term debt, less current portion: |  |  |  |  |  |  |  |  |
| Term Loan |  | $ | 233,500 |  |  | $ | 273,000 |  |
| Less: unamortized debt issuance costs |  |  | (1,860 | ) |  |  | (2,430 | ) |
| Total long-term debt, less current portion |  |  | 231,640 |  |  |  | 270,570 |  |
| Total debt |  | $ | 267,404 |  |  | $ | 303,919 |  |

- changed (2023-01-27):
[0001564590-23-000867:note_history:16]
The 2019 Credit Agreement provides for a five-year first lien term loan facility in an aggregate principal amount of $380.0 million and a five-year revolving loan facility in an aggregate principal amount of $75.0 million (the “2019 Revolving Facility”). In addition, the Company may request incremental term loans and/or incremental revolving loan commitments in an aggregate amount not to exceed the sum of $100.0 million, plus an unlimited amount that is subject to pro forma compliance with certain financial tests. On August 9, 2019, the Company used the additional proceeds from the term loan to partially fund the acquisition of Aerohive Networks, Inc. and for working capital and general corporate purposes.
  (was, 2022-10-28, similarity 0.9065):
[0001564590-22-035673:note_history:16]
The 2019 Credit Agreement provides for a five-year first lien term loan facility in an aggregate principal amount of $380.0 million and a five-year revolving loan facility in an aggregate principal amount of $75.0 million (the “2019 Revolving Facility”). In addition, the Company may request incremental term loans and/or incremental revolving loan commitments in an aggregate amount not to exceed the sum of $100.0 million, plus an unlimited amount that is subject to pro forma compliance with certain financial tests. On August 9, 2019, the Company used the additional proceeds from the term loan to partially fund the Acquisition and for working capital and general corporate purposes.

- changed (2023-01-27):
[0001564590-23-000867:note_history:17]
The Second Amendment provided for the Company to end the covenant Suspension Period early and revert to the covenants and interest rates per the original terms of the 2019 Credit Agreement dated August 9, 2019 by filing a Suspension Period Early Termination Notice and Covenant Certificate demonstrating compliance. For the twelve-month period ended March 31, 2021, the Company’s financial performance was in compliance with the original covenants defined in the 2019 Credit Agreement and, as such, the Company filed a Suspension Early Termination Notice and Covenant Certificate with the administration agent subsequent to filing the Company’s Quarterly Report on Form 10-Q for the period ended March 31, 2021. Returning to compliance, the original terms and
  (was, 2022-10-28, similarity 0.7915):
[0001564590-22-035673:note_history:17]
The Second Amendment provided for the Company to end the covenant Suspension Period early and revert to the covenants and interest rates per the original terms of the 2019 Credit Agreement dated August 9, 2019 by filing a Suspension Period Early Termination Notice and Covenant Certificate demonstrating compliance. For the twelve-month period ended March 31, 2021, the Company’s financial performance was in compliance with the original covenants defined in the 2019 Credit Agreement and, as such,

- added (2023-01-27):
[0001564590-23-000867:note_history:18]
financial covenants under the 2019 Credit Agreement dated August 9, 2019 resumed in effect. During the three and six months ended December 31, 2022, the Company was in compliance with all the terms and financial covenants under the 2019 Credit Agreement.

- changed (2023-01-27):
[0001564590-23-000867:note_history:19]
Financing costs incurred in connection with obtaining long-term financing are deferred and amortized over the term of the related indebtedness or credit agreement. Amortization of deferred financing costs included in “Interest expense” in the accompanying condensed consolidated statements of operations were $0.7 million for each of the three months ended December 31, 2022 and 2021 and totaled $1.5 million for each of the six months ended December 31, 2022 and 2021. The interest rate as of December 31, 2022 was 5.5% and as of December 31, 2021 was 1.86%.
  (was, 2022-10-28, similarity 0.7747):
[0001564590-22-035673:note_history:19]
Financing costs incurred in connection with obtaining long-term financing are deferred and amortized over the term of the related indebtedness or credit agreement. Amortization of deferred financing costs included in “Interest expense” in the accompanying condensed consolidated statements of operations were $0.7 million and $0.8 million for the three months ended September 30, 2022 and 2021. The interest rate as of September 30, 2022 was 4.5% and as of September 30, 2021 was 2.4%.

- changed (2023-01-27):
[0001564590-23-000867:note_history:20]
As of December 31, 2022, the Company did not have any outstanding balance against its 2019 Revolving Facility’s outstanding balance. The Company had $60.2 million of availability under the 2019 Revolving Facility as of December 31, 2022. During the six months ended December 31, 2022 and 2021, the Company made an additional payment of $30.0 million and $12.0 million against its term loan facility, respectively.
  (was, 2022-10-28, similarity 0.9249):
[0001564590-22-035673:note_history:20]
As of September 30, 2022, the Company did not have any outstanding balance against its 2019 Revolving Facility’s outstanding balance.  The Company had $60.2 million of availability under the 2019 Revolving Facility as of September 30, 2022. During the three months ended September 30, 2022 and 2021, the Company made an additional payment of $30.0 million and $12.0 million against its term loan facility, respectively.

- changed (2023-01-27):
[0001564590-23-000867:note_history:21]
The Company had $14.8 million of outstanding letters of credit as of December 31, 2022.
  (was, 2022-10-28, similarity 0.9682):
[0001564590-22-035673:note_history:21]
The Company had $14.8 million of outstanding letters of credit as of September 30, 2022.

- removed (2023-01-27):
[0001564590-22-035673:note_history:22]
the Company filed a Suspension Early Termination Notice and Covenant Certificate with the administration agent subsequent to filing the Company’s Quarterly Report on Form 10-Q for the period ended March 31, 2021. Returning to compliance, the original terms and financial covenants under the 2019 Credit Agreement dated August 9, 2019 resumed in effect. During the three months ended September 30, 2022, the Company was in compliance with all the terms and financial covenants under the 2019 Credit Agreement.


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2023-01-27):
[0001564590-23-000867:note_history:23]
|  |  | December 31, 2022 |  |  | June 30, 2022 |  |
| Current portion of long-term debt: |  |  |  |  |  |  |  |  |
| Term Loan |  | $ | 38,000 |  |  | $ | 35,625 |  |
| Less: unamortized debt issuance costs |  |  | (2,181 | ) |  |  | (2,276 | ) |
| Current portion of long-term debt |  | $ | 35,819 |  |  | $ | 33,349 |  |
| Long-term debt, less current portion: |  |  |  |  |  |  |  |  |
| Term Loan |  | $ | 224,000 |  |  | $ | 273,000 |  |
| Less: unamortized debt issuance costs |  |  | (1,331 | ) |  |  | (2,430 | ) |
| Total long-term debt, less current portion |  |  | 222,669 |  |  |  | 270,570 |  |
| Total debt |  | $ | 258,488 |  |  | $ | 303,919 |  |
  (was, 2022-10-28, similarity 0.9934):
[0001564590-22-035673:note_history:23]
|  |  | September 30, 2022 |  |  | June 30, 2022 |  |
| Current portion of long-term debt: |  |  |  |  |  |  |  |  |
| Term Loan |  | $ | 38,000 |  |  | $ | 35,625 |  |
| Less: unamortized debt issuance costs |  |  | (2,236 | ) |  |  | (2,276 | ) |
| Current portion of long-term debt |  | $ | 35,764 |  |  | $ | 33,349 |  |
| Long-term debt, less current portion: |  |  |  |  |  |  |  |  |
| Term Loan |  | $ | 233,500 |  |  | $ | 273,000 |  |
| Less: unamortized debt issuance costs |  |  | (1,860 | ) |  |  | (2,430 | ) |
| Total long-term debt, less current portion |  |  | 231,640 |  |  |  | 270,570 |  |
| Total debt |  | $ | 267,404 |  |  | $ | 303,919 |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2023-01-27):
[0001564590-23-000867:note_history:24]
|  |  | Three Months Ended |  |
|  |  | December 31, 2022 |  |  | December 31, 2021 |  |
|  |  | Distributor |  | Direct |  | Total |  |  | Distributor |  | Direct |  | Total |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  | $ | 70,963 |  | $ | 66,630 |  | $ | 137,593 |  |  | $ | 68,565 |  | $ | 68,585 |  | $ | 137,150 |  |
| Other |  |  | 10,807 |  |  | 4,614 |  |  | 15,421 |  |  |  | 3,865 |  |  | 4,955 |  |  | 8,820 |  |
| Total Americas |  |  | 81,770 |  |  | 71,244 |  |  | 153,014 |  |  |  | 72,430 |  |  | 73,540 |  |  | 145,970 |  |
| EMEA |  |  | 97,147 |  |  | 40,903 |  |  | 138,050 |  |  |  | 68,934 |  |  | 42,128 |  |  | 111,062 |  |
| APAC |  |  | 7,403 |  |  | 19,881 |  |  | 27,284 |  |  |  | 5,034 |  |  | 18,867 |  |  | 23,901 |  |
| Total net revenues |  | $ | 186,320 |  | $ | 132,028 |  | $ | 318,348 |  |  | $ | 146,398 |  | $ | 134,535 |  | $ | 280,933 |  |
  (was, 2022-10-28, similarity 0.9889):
[0001564590-22-035673:note_history:24]
|  |  | Three Months Ended |  |
|  |  | September 30, 2022 |  |  | September 30, 2021 |  |
|  |  | Distributor |  | Direct |  | Total |  |  | Distributor |  | Direct |  | Total |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  | $ | 73,314 |  | $ | 64,312 |  | $ | 137,626 |  |  | $ | 56,068 |  | $ | 67,331 |  | $ | 123,399 |  |
| Other |  |  | 16,025 |  |  | 4,098 |  |  | 20,123 |  |  |  | 7,799 |  |  | 3,367 |  |  | 11,166 |  |
| Total Americas |  |  | 89,339 |  |  | 68,410 |  |  | 157,749 |  |  |  | 63,867 |  |  | 70,698 |  |  | 134,565 |  |
| EMEA |  |  | 76,256 |  |  | 39,253 |  |  | 115,509 |  |  |  | 77,898 |  |  | 35,731 |  |  | 113,629 |  |
| APAC |  |  | 2,038 |  |  | 22,393 |  |  | 24,431 |  |  |  | 4,335 |  |  | 15,155 |  |  | 19,490 |  |
| Total net revenues |  | $ | 167,633 |  | $ | 130,056 |  | $ | 297,689 |  |  | $ | 146,100 |  | $ | 121,584 |  | $ | 267,684 |  |

- added (2023-01-27):
[0001564590-23-000867:note_history:25]
|  |  | Six Months Ended |  |
|  |  | December 31, 2022 |  |  | December 31, 2021 |  |
|  |  | Distributor |  | Direct |  | Total |  |  | Distributor |  | Direct |  | Total |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  | $ | 144,277 |  | $ | 130,942 |  | $ | 275,219 |  |  | $ | 124,633 |  | $ | 135,916 |  | $ | 260,549 |  |
| Other |  |  | 26,832 |  |  | 8,712 |  |  | 35,544 |  |  |  | 11,664 |  |  | 8,322 |  |  | 19,986 |  |
| Total Americas |  |  | 171,109 |  |  | 139,654 |  |  | 310,763 |  |  |  | 136,297 |  |  | 144,238 |  |  | 280,535 |  |
| EMEA |  |  | 173,403 |  |  | 80,156 |  |  | 253,559 |  |  |  | 146,832 |  |  | 77,859 |  |  | 224,691 |  |
| APAC |  |  | 9,441 |  |  | 42,274 |  |  | 51,715 |  |  |  | 9,369 |  |  | 34,022 |  |  | 43,391 |  |
| Total net revenues |  | $ | 353,953 |  | $ | 262,084 |  | $ | 616,037 |  |  | $ | 292,498 |  | $ | 256,119 |  | $ | 548,617 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2023-01-27):
[0001564590-23-000867:note_history:26]
On December 31, 2022, the Company had $445.6 million of remaining performance obligations, which are primarily comprised of deferred maintenance and SaaS revenues. The Company expects to recognize approximately 36% of its deferred revenue as revenue in the remainder of fiscal 2023, an additional 34% in fiscal 2024 and 30% of the balance thereafter.
  (was, 2022-10-28, similarity 0.9627):
[0001564590-22-035673:note_history:26]
On September 30, 2022, the Company had $424.0 million of remaining performance obligations, which are primarily comprised of deferred maintenance and SaaS revenues. The Company expects to recognize approximately 49% of its deferred revenue as revenue in fiscal 2023, an additional 27% in fiscal 2024 and 24% of the balance thereafter.

- changed (2023-01-27):
[0001564590-23-000867:note_history:27]
Revenue recognized for the three months ended December 31, 2022 and 2021 that was included in the deferred revenue balance at the beginning of each period was $83.9 million and $81.9 million, respectively. Revenue recognized for the six months ended December 31, 2022 and 2021 that was included in the deferred revenue balance at the beginning of each period was $145.7 million and $132.5 million, respectively.
  (was, 2022-10-28, similarity 0.6597):
[0001564590-22-035673:note_history:27]
Revenue recognized for the three months ended September 30, 2022 and 2021 that was included in the deferred revenue balance at the beginning of each period was $80.0 million and $73.4 million, respectively.

- changed (2023-01-27):
[0001564590-23-000867:note_history:28]
Contract Costs. The Company recognizes the incremental costs of obtaining contracts as an expense when incurred if the amortization period of the assets that the Company otherwise would have recognized is one year or less. Management expects that commission fees paid to sales representatives as a result of obtaining service and subscription contracts and contract renewals are recoverable and therefore the Company’s condensed consolidated balance sheets included capitalized balances in the amount of $17.5 million and $16.3 million at December 31, 2022 and June 30, 2022, respectively. Capitalized commissions are included within other assets in the condensed consolidated balance sheets. Capitalized commission fees are amortized on a straight-line basis over the average period of service contracts of approximately three years, and are included in “Sales and marketing” in the accompanying condensed consolidated statements of operations. Amortization recognized during the three months ended December 31, 2022 and 2021, was $ 2.2 million and $1.8 million, respectively. Amortization recognized during the six months ended December 31, 2022 and 2021, was $4.3 million and $3.6 million, respectively.
  (was, 2022-10-28, similarity 0.9272):
[0001564590-22-035673:note_history:28]
Contract Costs. The Company recognizes the incremental costs of obtaining contracts as an expense when incurred if the amortization period of the assets that the Company otherwise would have recognized is one year or less. Management expects that commission fees paid to sales representatives as a result of obtaining service and subscription contracts and contract renewals are recoverable and therefore the Company’s condensed consolidated balance sheets included capitalized balances in the amount of $16.8 million and $16.3 million at September 30, 2022 and June 30, 2022, respectively. Capitalized commissions are included within other assets in the condensed consolidated balance sheets. Capitalized commission fees are amortized on a straight-line basis over the average period of service contracts of approximately three years, and are included in “Sales and marketing” in the accompanying condensed consolidated statements of operations. Amortization recognized during the three months ended September 30, 2022 and 2021, was $2.1 million and $1.8 million, respectively.

- changed (2023-01-27):
[0001564590-23-000867:note_history:29]
The Company operates in three geographic regions: Americas, EMEA (Europe, Middle East and Africa) and APAC (Asia Pacific). The following table sets forth the Company’s revenues disaggregated by sales channel and geographic region based on the billing addresses of its customers (in thousands):
  (was, 2022-10-28, similarity 0.9525):
[0001564590-22-035673:note_history:29]
The Company operates in three geographic regions: Americas, EMEA (“Europe, Middle East and Africa”) and APAC (“Asia Pacific”). The following table sets forth the Company’s revenues disaggregated by sales channel and geographic region based on the billing addresses of its customers (in thousands):

- changed (2023-01-27):
[0001564590-23-000867:note_history:30]
|  |  | Three Months Ended |  |
|  |  | December 31, 2022 |  |  | December 31, 2021 |  |
|  |  | Distributor |  | Direct |  | Total |  |  | Distributor |  | Direct |  | Total |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  | $ | 70,963 |  | $ | 66,630 |  | $ | 137,593 |  |  | $ | 68,565 |  | $ | 68,585 |  | $ | 137,150 |  |
| Other |  |  | 10,807 |  |  | 4,614 |  |  | 15,421 |  |  |  | 3,865 |  |  | 4,955 |  |  | 8,820 |  |
| Total Americas |  |  | 81,770 |  |  | 71,244 |  |  | 153,014 |  |  |  | 72,430 |  |  | 73,540 |  |  | 145,970 |  |
| EMEA |  |  | 97,147 |  |  | 40,903 |  |  | 138,050 |  |  |  | 68,934 |  |  | 42,128 |  |  | 111,062 |  |
| APAC |  |  | 7,403 |  |  | 19,881 |  |  | 27,284 |  |  |  | 5,034 |  |  | 18,867 |  |  | 23,901 |  |
| Total net revenues |  | $ | 186,320 |  | $ | 132,028 |  | $ | 318,348 |  |  | $ | 146,398 |  | $ | 134,535 |  | $ | 280,933 |  |
  (was, 2022-10-28, similarity 0.9889):
[0001564590-22-035673:note_history:30]
|  |  | Three Months Ended |  |
|  |  | September 30, 2022 |  |  | September 30, 2021 |  |
|  |  | Distributor |  | Direct |  | Total |  |  | Distributor |  | Direct |  | Total |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  | $ | 73,314 |  | $ | 64,312 |  | $ | 137,626 |  |  | $ | 56,068 |  | $ | 67,331 |  | $ | 123,399 |  |
| Other |  |  | 16,025 |  |  | 4,098 |  |  | 20,123 |  |  |  | 7,799 |  |  | 3,367 |  |  | 11,166 |  |
| Total Americas |  |  | 89,339 |  |  | 68,410 |  |  | 157,749 |  |  |  | 63,867 |  |  | 70,698 |  |  | 134,565 |  |
| EMEA |  |  | 76,256 |  |  | 39,253 |  |  | 115,509 |  |  |  | 77,898 |  |  | 35,731 |  |  | 113,629 |  |
| APAC |  |  | 2,038 |  |  | 22,393 |  |  | 24,431 |  |  |  | 4,335 |  |  | 15,155 |  |  | 19,490 |  |
| Total net revenues |  | $ | 167,633 |  | $ | 130,056 |  | $ | 297,689 |  |  | $ | 146,100 |  | $ | 121,584 |  | $ | 267,684 |  |

- added (2023-01-27):
[0001564590-23-000867:note_history:31]
|  |  | Six Months Ended |  |
|  |  | December 31, 2022 |  |  | December 31, 2021 |  |
|  |  | Distributor |  | Direct |  | Total |  |  | Distributor |  | Direct |  | Total |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  | $ | 144,277 |  | $ | 130,942 |  | $ | 275,219 |  |  | $ | 124,633 |  | $ | 135,916 |  | $ | 260,549 |  |
| Other |  |  | 26,832 |  |  | 8,712 |  |  | 35,544 |  |  |  | 11,664 |  |  | 8,322 |  |  | 19,986 |  |
| Total Americas |  |  | 171,109 |  |  | 139,654 |  |  | 310,763 |  |  |  | 136,297 |  |  | 144,238 |  |  | 280,535 |  |
| EMEA |  |  | 173,403 |  |  | 80,156 |  |  | 253,559 |  |  |  | 146,832 |  |  | 77,859 |  |  | 224,691 |  |
| APAC |  |  | 9,441 |  |  | 42,274 |  |  | 51,715 |  |  |  | 9,369 |  |  | 34,022 |  |  | 43,391 |  |
| Total net revenues |  | $ | 353,953 |  | $ | 262,084 |  | $ | 616,037 |  |  | $ | 292,498 |  | $ | 256,119 |  | $ | 548,617 |  |

- added (2023-01-27):
[0001564590-23-000867:note_history:32]
For three months ended December 31, 2022 the Company generated 11% and 10% of its revenues from the Netherlands and Germany, respectively. For the six months ended December 31, 2022 the Company generated 10% each of its revenues from the Netherlands and Germany. For the six months ended December 31, 2021 the Company generated 10% of its revenues from the Netherlands. No other foreign country accounted for 10% or more of revenue for the three and six months ended December 31, 2022 and 2021.

- added (2023-01-27):
[0001564590-23-000867:note_history:33]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | December 31, 2022 |  |  | December 31, 2021 |  |  | December 31, 2022 |  |  | December 31, 2021 |  |
| Westcon Group, Inc. |  | 19% |  |  | 11% |  |  | 17% |  |  | 15% |  |
| TD Synnex Corporation |  | 17% |  |  | 21% |  |  | 18% |  |  | 22% |  |
| Jenne, Inc. |  | 13% |  |  | 18% |  |  | 13% |  |  | 16% |  |
| ScanSource, Inc. |  | 11% |  |  | * |  |  | * |  |  | * |  |
| * Less than 10% of revenue |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |

- changed (2023-01-27):
[0001564590-23-000867:note_history:34]
|  |  | December 31, 2022 |  |  | June 30, 2022 |  |
| Jenne, Inc. |  | 16% |  |  | 28% |  |
| ScanSource, Inc. |  | 10% |  |  | * |  |
| TD Synnex Corporation |  | 10% |  |  | 11% |  |
| * Less than 10% of accounts receivable. |  |  |  |  |  |  |  |  |
  (was, 2022-10-28, similarity 0.9716):
[0001564590-22-035673:note_history:34]
|  |  | September 30, 2022 |  |  | June 30, 2022 |  |
| Jenne Inc. |  | 26% |  |  | 28% |  |
| Scansource Inc. |  | 14% |  |  | * |  |
| TD Synnex Corporation |  | * |  |  | 11% |  |
| * Less than 10% of accounts receivable. |  |  |  |  |  |  |  |  |

- removed (2023-01-27):
[0001564590-22-035673:note_history:35]
For three months ended September 30, 2022 no foreign country accounted for 10% or more revenue. For the three months ended September 30, 2021 the Company generated 11% and 10% of its revenues from the Netherlands and Germany, respectively.  No other foreign country accounted for 10% or more of revenue for the three months ended September 30, 2021.

- removed (2023-01-27):
[0001564590-22-035673:note_history:36]
|  |  | Three Months Ended |  |
|  |  | September 30, 2022 |  |  | September 30, 2021 |  |
| TD Synnex Corporation |  | 19% |  |  | 22% |  |
| Westcon Group Inc. |  | 15% |  |  | 18% |  |
| Jenne Inc. |  | 13% |  |  | 14% |  |


## us-gaap:RevenueRecognitionPolicyTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2023-01-27):
[0001564590-23-000867:note_history:37]
On December 31, 2022, the Company had $445.6 million of remaining performance obligations, which are primarily comprised of deferred maintenance and SaaS revenues. The Company expects to recognize approximately 36% of its deferred revenue as revenue in the remainder of fiscal 2023, an additional 34% in fiscal 2024 and 30% of the balance thereafter.
  (was, 2022-10-28, similarity 0.9627):
[0001564590-22-035673:note_history:37]
On September 30, 2022, the Company had $424.0 million of remaining performance obligations, which are primarily comprised of deferred maintenance and SaaS revenues. The Company expects to recognize approximately 49% of its deferred revenue as revenue in fiscal 2023, an additional 27% in fiscal 2024 and 24% of the balance thereafter.

- changed (2023-01-27):
[0001564590-23-000867:note_history:38]
Revenue recognized for the three months ended December 31, 2022 and 2021 that was included in the deferred revenue balance at the beginning of each period was $83.9 million and $81.9 million, respectively. Revenue recognized for the six months ended December 31, 2022 and 2021 that was included in the deferred revenue balance at the beginning of each period was $145.7 million and $132.5 million, respectively.
  (was, 2022-10-28, similarity 0.6597):
[0001564590-22-035673:note_history:38]
Revenue recognized for the three months ended September 30, 2022 and 2021 that was included in the deferred revenue balance at the beginning of each period was $80.0 million and $73.4 million, respectively.

- changed (2023-01-27):
[0001564590-23-000867:note_history:39]
Contract Costs. The Company recognizes the incremental costs of obtaining contracts as an expense when incurred if the amortization period of the assets that the Company otherwise would have recognized is one year or less. Management expects that commission fees paid to sales representatives as a result of obtaining service and subscription contracts and contract renewals are recoverable and therefore the Company’s condensed consolidated balance sheets included capitalized balances in the amount of $17.5 million and $16.3 million at December 31, 2022 and June 30, 2022, respectively. Capitalized commissions are included within other assets in the condensed consolidated balance sheets. Capitalized commission fees are amortized on a straight-line basis over the average period of service contracts of approximately three years, and are included in “Sales and marketing” in the accompanying condensed consolidated statements of operations. Amortization recognized during the three months ended December 31, 2022 and 2021, was $ 2.2 million and $1.8 million, respectively. Amortization recognized during the six months ended December 31, 2022 and 2021, was $4.3 million and $3.6 million, respectively.
  (was, 2022-10-28, similarity 0.9272):
[0001564590-22-035673:note_history:39]
Contract Costs. The Company recognizes the incremental costs of obtaining contracts as an expense when incurred if the amortization period of the assets that the Company otherwise would have recognized is one year or less. Management expects that commission fees paid to sales representatives as a result of obtaining service and subscription contracts and contract renewals are recoverable and therefore the Company’s condensed consolidated balance sheets included capitalized balances in the amount of $16.8 million and $16.3 million at September 30, 2022 and June 30, 2022, respectively. Capitalized commissions are included within other assets in the condensed consolidated balance sheets. Capitalized commission fees are amortized on a straight-line basis over the average period of service contracts of approximately three years, and are included in “Sales and marketing” in the accompanying condensed consolidated statements of operations. Amortization recognized during the three months ended September 30, 2022 and 2021, was $2.1 million and $1.8 million, respectively.

- changed (2023-01-27):
[0001564590-23-000867:note_history:40]
The Company operates in three geographic regions: Americas, EMEA (Europe, Middle East and Africa) and APAC (Asia Pacific). The following table sets forth the Company’s revenues disaggregated by sales channel and geographic region based on the billing addresses of its customers (in thousands):
  (was, 2022-10-28, similarity 0.9525):
[0001564590-22-035673:note_history:40]
The Company operates in three geographic regions: Americas, EMEA (“Europe, Middle East and Africa”) and APAC (“Asia Pacific”). The following table sets forth the Company’s revenues disaggregated by sales channel and geographic region based on the billing addresses of its customers (in thousands):

- changed (2023-01-27):
[0001564590-23-000867:note_history:41]
|  |  | Three Months Ended |  |
|  |  | December 31, 2022 |  |  | December 31, 2021 |  |
|  |  | Distributor |  | Direct |  | Total |  |  | Distributor |  | Direct |  | Total |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  | $ | 70,963 |  | $ | 66,630 |  | $ | 137,593 |  |  | $ | 68,565 |  | $ | 68,585 |  | $ | 137,150 |  |
| Other |  |  | 10,807 |  |  | 4,614 |  |  | 15,421 |  |  |  | 3,865 |  |  | 4,955 |  |  | 8,820 |  |
| Total Americas |  |  | 81,770 |  |  | 71,244 |  |  | 153,014 |  |  |  | 72,430 |  |  | 73,540 |  |  | 145,970 |  |
| EMEA |  |  | 97,147 |  |  | 40,903 |  |  | 138,050 |  |  |  | 68,934 |  |  | 42,128 |  |  | 111,062 |  |
| APAC |  |  | 7,403 |  |  | 19,881 |  |  | 27,284 |  |  |  | 5,034 |  |  | 18,867 |  |  | 23,901 |  |
| Total net revenues |  | $ | 186,320 |  | $ | 132,028 |  | $ | 318,348 |  |  | $ | 146,398 |  | $ | 134,535 |  | $ | 280,933 |  |
  (was, 2022-10-28, similarity 0.9889):
[0001564590-22-035673:note_history:41]
|  |  | Three Months Ended |  |
|  |  | September 30, 2022 |  |  | September 30, 2021 |  |
|  |  | Distributor |  | Direct |  | Total |  |  | Distributor |  | Direct |  | Total |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  | $ | 73,314 |  | $ | 64,312 |  | $ | 137,626 |  |  | $ | 56,068 |  | $ | 67,331 |  | $ | 123,399 |  |
| Other |  |  | 16,025 |  |  | 4,098 |  |  | 20,123 |  |  |  | 7,799 |  |  | 3,367 |  |  | 11,166 |  |
| Total Americas |  |  | 89,339 |  |  | 68,410 |  |  | 157,749 |  |  |  | 63,867 |  |  | 70,698 |  |  | 134,565 |  |
| EMEA |  |  | 76,256 |  |  | 39,253 |  |  | 115,509 |  |  |  | 77,898 |  |  | 35,731 |  |  | 113,629 |  |
| APAC |  |  | 2,038 |  |  | 22,393 |  |  | 24,431 |  |  |  | 4,335 |  |  | 15,155 |  |  | 19,490 |  |
| Total net revenues |  | $ | 167,633 |  | $ | 130,056 |  | $ | 297,689 |  |  | $ | 146,100 |  | $ | 121,584 |  | $ | 267,684 |  |

- added (2023-01-27):
[0001564590-23-000867:note_history:42]
|  |  | Six Months Ended |  |
|  |  | December 31, 2022 |  |  | December 31, 2021 |  |
|  |  | Distributor |  | Direct |  | Total |  |  | Distributor |  | Direct |  | Total |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  | $ | 144,277 |  | $ | 130,942 |  | $ | 275,219 |  |  | $ | 124,633 |  | $ | 135,916 |  | $ | 260,549 |  |
| Other |  |  | 26,832 |  |  | 8,712 |  |  | 35,544 |  |  |  | 11,664 |  |  | 8,322 |  |  | 19,986 |  |
| Total Americas |  |  | 171,109 |  |  | 139,654 |  |  | 310,763 |  |  |  | 136,297 |  |  | 144,238 |  |  | 280,535 |  |
| EMEA |  |  | 173,403 |  |  | 80,156 |  |  | 253,559 |  |  |  | 146,832 |  |  | 77,859 |  |  | 224,691 |  |
| APAC |  |  | 9,441 |  |  | 42,274 |  |  | 51,715 |  |  |  | 9,369 |  |  | 34,022 |  |  | 43,391 |  |
| Total net revenues |  | $ | 353,953 |  | $ | 262,084 |  | $ | 616,037 |  |  | $ | 292,498 |  | $ | 256,119 |  | $ | 548,617 |  |

- added (2023-01-27):
[0001564590-23-000867:note_history:43]
For three months ended December 31, 2022 the Company generated 11% and 10% of its revenues from the Netherlands and Germany, respectively. For the six months ended December 31, 2022 the Company generated 10% each of its revenues from the Netherlands and Germany. For the six months ended December 31, 2021 the Company generated 10% of its revenues from the Netherlands. No other foreign country accounted for 10% or more of revenue for the three and six months ended December 31, 2022 and 2021.

- removed (2023-01-27):
[0001564590-22-035673:note_history:44]
For three months ended September 30, 2022 no foreign country accounted for 10% or more revenue. For the three months ended September 30, 2021 the Company generated 11% and 10% of its revenues from the Netherlands and Germany, respectively.  No other foreign country accounted for 10% or more of revenue for the three months ended September 30, 2021.
