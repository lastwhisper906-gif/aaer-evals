# EXTR MD&A — 0001564590-23-000867


## mdna

[0001564590-23-000867:mdna:1]
[same as prior period, unchanged from 0001564590-22-035673:mdna:1]

[0001564590-23-000867:mdna:2]
[same as prior period, unchanged from 0001564590-22-035673:mdna:2]

[0001564590-23-000867:mdna:3]
[same as prior period, unchanged from 0001564590-22-035673:mdna:3]

[0001564590-23-000867:mdna:4]
Extreme Networks, Inc. (“Extreme” or “Company”) is a leading provider of cloud networking solutions and industry leading services and support. Extreme designs, develops, and manufactures wired, wireless, and software-defined wide area-network (“SD-WAN”) infrastructure equipment. The Company’s cloud solution is a single platform that offers unified network management of wireless access points, switches, and SD-WAN. It leverages machine learning, Artificial Intelligence Operations and analytics to help customers deliver secure connectivity at the edge of the network, speed cloud deployments and uncover actionable insights saves time, lowers costs and streamlines operations. Extreme is currently managing more than two million devices in the cloud.

[0001564590-23-000867:mdna:5]
Extreme has been pushing the boundaries of networking technology since 1996, driven by a higher purpose of helping our customers connect beyond the network. Extreme’s cloud networking technologies provide flexibility and scalability in deployment, management, and licensing of networks globally. Our global footprint provides service to more than 50,000 customers and 10 million daily end users across the world including some of the world’s leading names in business, hospitality, retail, transportation and logistics, education, government, healthcare, manufacturing and service providers. We derive all our revenues from the sale of our networking equipment, software subscriptions, and related maintenance contracts.

[0001564590-23-000867:mdna:6]
[same as prior period, unchanged from 0001564590-22-035673:mdna:6]

[0001564590-23-000867:mdna:7]
Enterprises are adopting new Information Technology (“IT”) delivery models and applications that require fundamental network alterations and enhancements spanning from the access edge to the data center. As networks become more complex and more distributed in nature, we believe IT teams in every industry will need more control and better insights than ever before to ensure secure, distributed connectivity and comprehensive centralized visibility. Machine Learning (“ML”) and Artificial Intelligence (“AI”) technologies have the potential to vastly improve the network experience in the post-pandemic world by collating large data sets to increase accuracy and derive resolutions to improve the operation of the network. When ML and AI are applied with cloud-driven networking and automation, administrators can quickly scale to provide productivity, availability, accessibility, manageability, security, and speed, regardless of the distribution of the network.

[0001564590-23-000867:mdna:8]
As the edge of the network continues to expand, our customers are faced with managing more endpoints. With that comes a host of challenges. This continued expansion creates issues such as: a higher risk of cyberattacks, an increase in applications running across the network which creates a need for more bandwidth.

[0001564590-23-000867:mdna:9]
With more endpoints to manage, application performance suffers, and the tug on internal systems and IT staff becomes more intense. There are more alarms, more IT tickets and often time technology that is being overworked. Most times they have little visibility into the root cause of the problem and are left trying to pinpoint where, when and how these issues exist. Meanwhile, organizational productivity suffers.

[0001564590-23-000867:mdna:10]
[same as prior period, unchanged from 0001564590-22-035673:mdna:8]

[0001564590-23-000867:mdna:11]
As enterprises continue to migrate increasing numbers of applications and services to either private clouds or public clouds offered by third parties and to adopt new IT delivery models and applications, they are required to make fundamental network alterations and enhancements spanning from device access points (“AP”) to the network core. In either case, the network infrastructure must adapt to this new dynamic environment. Intelligence and automation are key if enterprises are to derive maximum benefit from their cloud deployments. With automation applications becoming increasingly critical in manufacturing, warehousing, logistics, healthcare and other key industries, we believe this will continue to create demand for networking technology to serve as a foundation to run these services.

[0001564590-23-000867:mdna:12]
[same as prior period, unchanged from 0001564590-22-035673:mdna:10]

[0001564590-23-000867:mdna:13]
We believe Extreme will continue to benefit from the use of its technology to manage distributed campus network architecture centrally from the cloud. Extreme has blended a dynamic fabric attach architecture that delivers simplicity for moves and changes at the edge of the network together with corporate-wide role-based policy. This enables customers to migrate to new cloud managed switching, Wi-Fi, and SD-WAN, agnostic of the existing switching or wireless equipment they already have installed. In the end, we expect these customers to see lower operating and capital expenditures, lower subscription costs, lower overall cost of ownership and more flexibility along with a more resilient network.

[0001564590-23-000867:mdna:14]
We estimate the total addressable market for our Enterprise Networking solutions consisting of cloud networking, wireless local area networks (“WLAN”), data center networking, ethernet switching, campus local area networks (“LAN”), and SD-WAN solutions to be approximately $33 billion and growing at approximately 12% annually over the next three years. This comprises of $22 billion for campus networking, $4.6 billion for 5G service available market in 5G and data centers, for which Extreme is targeting growing to approximately $50 - $100 million per year over the next three to five years, and a $2.2 billion SD-WAN market. We also participate in the $4 billion networking software market for solutions such as cloud-based network management, network automation, on-premises network management, and other networking related software.

[0001564590-23-000867:mdna:15]
[same as prior period, unchanged from 0001564590-22-035673:mdna:13]

[0001564590-23-000867:mdna:16]
Extreme makes networking intelligent, flexible, and most importantly a strategic asset. The combination of our solutions provides the connectivity, bandwidth, performance, and insights that organizations of all sizes need to move their organization forward. IT leaders are now tasked with ensuring the global, hybrid workforce is functional and successful no matter where they are and ensure people can work wherever they want. The data that sits in the network provides a goldmine of insights that guide our customers to find new ways to drive better outcomes. Cloud allows customers to gain real-time visibility and insights into areas such as app usage, location, and workflow patterns across their environment, helping to inform strategic business decisions and create personalized experiences. Customers benefit from visibility, control, and reduced time to resolution. This is the cornerstone of our One Network, One Cloud, One Extreme vision.

[0001564590-23-000867:mdna:17]
[same as prior period, unchanged from 0001564590-22-035673:mdna:15]

[0001564590-23-000867:mdna:18]
[same as prior period, unchanged from 0001564590-22-035673:mdna:16]

[0001564590-23-000867:mdna:19]
[same as prior period, unchanged from 0001564590-22-035673:mdna:17]

[0001564590-23-000867:mdna:20]
[same as prior period, unchanged from 0001564590-22-035673:mdna:18]

[0001564590-23-000867:mdna:21]
[same as prior period, unchanged from 0001564590-22-035673:mdna:19]

[0001564590-23-000867:mdna:22]
[same as prior period, unchanged from 0001564590-22-035673:mdna:20]

[0001564590-23-000867:mdna:23]
[same as prior period, unchanged from 0001564590-22-035673:mdna:21]

[0001564590-23-000867:mdna:24]
|  | • | Provide a differentiated end-to-end cloud architecture. Cloud networking is estimated to be a $4.1 billion segment of the networking market comprised of cloud managed services and cloud-managed products, which are largely WLAN access points and ethernet switches, growing at a 13% over the next three years, according to data from 650 Group Market Research. Cloud management technology has evolved significantly over the past decade. We believe we deliver a combination of innovation, reliability, and security with the leading end-to-end cloud management platform powered by ML and AI that spans from the Internet of Things (“IoT”) edge to the enterprise data center. Key characteristics of our cloud architecture include: |

[0001564590-23-000867:mdna:25]
[same as prior period, unchanged from 0001564590-22-035673:mdna:23]

[0001564590-23-000867:mdna:26]
[same as prior period, unchanged from 0001564590-22-035673:mdna:24]

[0001564590-23-000867:mdna:27]
|  | o | Enhanced Network Data plans to improve an organization’s ability to make smarter, more effective business decisions. |

[0001564590-23-000867:mdna:28]
|  | o | Consumption Flexibility: Offer a range of financing and network purchase options. Our value-based subscription tiers (including Connect, Navigator and Pilot) provide customers with flexibility to grow as they go, as well as offer pool-able and portable licenses that can be transferred between products (e.g., access points and switches) at one fixed price. |

[0001564590-23-000867:mdna:29]
[same as prior period, unchanged from 0001564590-22-035673:mdna:27]

[0001564590-23-000867:mdna:30]
[same as prior period, unchanged from 0001564590-22-035673:mdna:29]

[0001564590-23-000867:mdna:31]
[same as prior period, unchanged from 0001564590-22-035673:mdna:30]

[0001564590-23-000867:mdna:32]
[same as prior period, unchanged from 0001564590-22-035673:mdna:31]

[0001564590-23-000867:mdna:33]
[same as prior period, unchanged from 0001564590-22-035673:mdna:32]

[0001564590-23-000867:mdna:34]
[same as prior period, unchanged from 0001564590-22-035673:mdna:33]

[0001564590-23-000867:mdna:35]
[same as prior period, unchanged from 0001564590-22-035673:mdna:34]

[0001564590-23-000867:mdna:36]
[same as prior period, unchanged from 0001564590-22-035673:mdna:35]

[0001564590-23-000867:mdna:37]
[same as prior period, unchanged from 0001564590-22-035673:mdna:36]

[0001564590-23-000867:mdna:38]
[same as prior period, unchanged from 0001564590-22-035673:mdna:37]

[0001564590-23-000867:mdna:39]
|  | o | Universal licensing with one portable management license for any device and for any type of management. For switches, operating system feature licenses are portable, and bulk activated through ExtremeCloud IQ. |

[0001564590-23-000867:mdna:40]
[same as prior period, unchanged from 0001564590-22-035673:mdna:39]

[0001564590-23-000867:mdna:41]
[same as prior period, unchanged from 0001564590-22-035673:mdna:40]

[0001564590-23-000867:mdna:42]
[same as prior period, unchanged from 0001564590-22-035673:mdna:61]

[0001564590-23-000867:mdna:43]
[same as prior period, unchanged from 0001564590-22-035673:mdna:41]

[0001564590-23-000867:mdna:44]
[same as prior period, unchanged from 0001564590-22-035673:mdna:42]

[0001564590-23-000867:mdna:45]
|  | • | Expand Wi-Fi technology leadership. Wireless is today’s network access method of choice and every business must deal with scale, density and BYOD challenges. The network edge landscape is changing as the explosion of mobile devices increases the demand for mobile, transparent, and always-on wired to wireless edge services. The unified access layer requires distributed intelligent components to ensure that access control and resiliency of business services are available across the entire infrastructure and manageable from a single console. We are at a technology inflection point with the pending migration from Wi-Fi 5 solutions to Wi-Fi 6 (802.11ax), focused on providing more efficient access to the broad array of connected devices. We believe we have the industry’s broadest Wi-Fi 6 wireless portfolio providing intelligence for the wired/wireless edge and enhanced by our cloud architecture with machine learning and AI-driven insights. |

[0001564590-23-000867:mdna:46]
[same as prior period, unchanged from 0001564590-22-035673:mdna:46]

[0001564590-23-000867:mdna:47]
[same as prior period, unchanged from 0001564590-22-035673:mdna:47]

[0001564590-23-000867:mdna:48]
[same as prior period, unchanged from 0001564590-22-035673:mdna:48]

[0001564590-23-000867:mdna:49]
[same as prior period, unchanged from 0001564590-22-035673:mdna:49]

[0001564590-23-000867:mdna:50]
[same as prior period, unchanged from 0001564590-22-035673:mdna:50]

[0001564590-23-000867:mdna:51]
29

[0001564590-23-000867:mdna:52]
[same as prior period, unchanged from 0001564590-22-035673:mdna:51]

[0001564590-23-000867:mdna:53]
During the second quarter of fiscal 2023, we achieved the following results:

[0001564590-23-000867:mdna:54]
|  | • | Net revenues of $318.3 million compared to $280.9 million in the second quarter of fiscal 2022. |

[0001564590-23-000867:mdna:55]
|  | • | Product revenues of $223.4 million compared to $191.1 million in the second quarter of fiscal 2022. |

[0001564590-23-000867:mdna:56]
|  | • | Service and subscription revenues of $94.9 million compared to $89.8 million in the second quarter of fiscal 2022. |

[0001564590-23-000867:mdna:57]
|  | • | Total gross margin of 57.1% of net revenues compared to 56.5% of net revenues in the second quarter of fiscal 2022. |

[0001564590-23-000867:mdna:58]
|  | • | Operating income of $23.4 million compared to $18.1 million in the second quarter of fiscal 2022. |

[0001564590-23-000867:mdna:59]
|  | • | Net income of $17.9 million compared to $13.3 million in the second quarter of fiscal 2022. |

[0001564590-23-000867:mdna:60]
During the first six months of fiscal 2023, we reflected the following results:

[0001564590-23-000867:mdna:61]
|  | • | Cash flows provided by operating activities of $120.3 million compared to $62.5 million in the six months ended December 31, 2021. |

[0001564590-23-000867:mdna:62]
|  | • | Cash of $202.5 million as of December 31, 2022 compared to $194.5 million as of June 30, 2022. |

[0001564590-23-000867:mdna:63]
[same as prior period, unchanged from 0001564590-22-035673:mdna:62]

[0001564590-23-000867:mdna:64]
[same as prior period, unchanged from 0001564590-22-035673:mdna:63]

[0001564590-23-000867:mdna:65]
|  |  | Three Months Ended |  |  | Six Months Ended |  |  |
|  |  | December 31, 2022 |  |  | December 31, 2021 |  |  | $ Change |  |  | % Change |  |  | December 31, 2022 |  |  | December 31, 2021 |  |  | $ Change |  |  | % Change |  |  |
| Net revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 223,445 |  |  | $ | 191,102 |  |  | $ | 32,343 |  |  |  | 16.9 | % |  | $ | 429,721 |  |  | $ | 376,263 |  |  | $ | 53,458 |  |  |  | 14.2 | % |  |
| Percentage of net revenues |  |  | 70.2 | % |  |  | 68.0 | % |  |  |  |  |  |  |  |  |  |  | 69.8 | % |  |  | 68.6 | % |  |  |  |  |  |  |  |  |  |
| Service and subscription |  |  | 94,903 |  |  |  | 89,831 |  |  |  | 5,072 |  |  |  | 5.6 | % |  |  | 186,316 |  |  |  | 172,354 |  |  |  | 13,962 |  |  |  | 8.1 | % |  |
| Percentage of net revenues |  |  | 29.8 | % |  |  | 32.0 | % |  |  |  |  |  |  |  |  |  |  | 30.2 | % |  |  | 31.4 | % |  |  |  |  |  |  |  |  |  |
| Total net revenues |  | $ | 318,348 |  |  | $ | 280,933 |  |  | $ | 37,415 |  |  |  | 13.3 | % |  | $ | 616,037 |  |  | $ | 548,617 |  |  | $ | 67,420 |  |  |  | 12.3 | % |  |

[0001564590-23-000867:mdna:66]
Product revenues increased $32.3 million or 16.9% for the three months ended December 31, 2022 as compared to the corresponding period in fiscal 2022. Product revenues increased $53.5 million or 14.2% for the six months ended December 31, 2022 as compared to the corresponding period in fiscal 2022. The increases in product revenues were primarily due to strong demand for our products and higher shipments resulting from an easing in supply chain constraints which had impacted our ability to fulfill the demand for our products.

[0001564590-23-000867:mdna:67]
Service and subscription revenues increased $5.1 million or 5.6% for the three months ended December 31, 2022 as compared to the corresponding period in fiscal 2022. Service and subscription revenues increased $14.0 million or 8.1% for the six months ended December 31, 2022 as compared to the corresponding period in fiscal 2022. The increases in service and subscription revenues were primarily due to the growth in our subscription business.

[0001564590-23-000867:mdna:68]
[same as prior period, unchanged from 0001564590-22-035673:mdna:67]

[0001564590-23-000867:mdna:69]
|  |  | Three Months Ended |  |  | Six Months Ended |  |  |
|  |  | December 31, 2022 |  |  | December 31, 2021 |  |  | $ Change |  |  | % Change |  |  | December 31, 2022 |  |  | December 31, 2021 |  |  | $ Change |  |  | % Change |  |  |
| Gross profit: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 119,858 |  |  | $ | 100,169 |  |  | $ | 19,689 |  |  |  | 19.7 | % |  | $ | 226,371 |  |  | $ | 204,386 |  |  | $ | 21,985 |  |  |  | 10.8 | % |  |
| Percentage of product revenues |  |  | 53.6 | % |  |  | 52.4 | % |  |  |  |  |  |  |  |  |  |  | 52.7 | % |  |  | 54.3 | % |  |  |  |  |  |  |  |  |  |
| Service and subscription |  |  | 61,797 |  |  |  | 58,617 |  |  |  | 3,180 |  |  |  | 5.4 | % |  |  | 121,992 |  |  |  | 110,003 |  |  |  | 11,989 |  |  |  | 10.9 | % |  |
| Percentage of service and subscription revenues |  |  | 65.1 | % |  |  | 65.3 | % |  |  |  |  |  |  |  |  |  |  | 65.5 | % |  |  | 63.8 | % |  |  |  |  |  |  |  |  |  |
| Total gross profit |  | $ | 181,655 |  |  | $ | 158,786 |  |  | $ | 22,869 |  |  |  | 14.4 | % |  | $ | 348,363 |  |  | $ | 314,389 |  |  | $ | 33,974 |  |  |  | 10.8 | % |  |
| Percentage of net revenues |  |  | 57.1 | % |  |  | 56.5 | % |  |  |  |  |  |  |  |  |  |  | 56.5 | % |  |  | 57.3 | % |  |  |  |  |  |  |  |  |  |

[0001564590-23-000867:mdna:70]
Product gross profit increased $19.7 million or 19.7% for the three months ended December 31, 2022 as compared to the corresponding period in fiscal 2022. The increase in product gross profit was primarily due to increased product revenues along with lower amortization of intangibles due to certain intangibles being fully amortized, lower distribution costs due to easing of supply chain constraints, partially offset by higher product costs and higher excess and obsolete inventory.

[0001564590-23-000867:mdna:71]
Product gross profit increased $22.0 million or 10.8% for the six months ended December 31, 2022 as compared to the corresponding period in fiscal 2022. The increase in product gross profit was primarily due to increased product revenues along with lower amortization of intangibles due to certain intangibles being fully amortized, partially offset by higher product costs, higher overhead costs and higher excess and obsolete inventory.

[0001564590-23-000867:mdna:72]
Service and subscription gross profit increased $3.2 million or 5.4% for the three months ended December 31, 2022 as compared to the corresponding period in fiscal 2022. Service and subscription gross profit increased $12.0 million or 10.9% for the six months ended December 31, 2022 as compared to the corresponding period in fiscal 2022. The increases in service and subscription gross profits were primarily due to increased service and subscription revenues, partially offset by higher cloud services costs.

[0001564590-23-000867:mdna:73]
[same as prior period, unchanged from 0001564590-22-035673:mdna:71]

[0001564590-23-000867:mdna:74]
[same as prior period, unchanged from 0001564590-22-035673:mdna:72]

[0001564590-23-000867:mdna:75]
|  |  | Three Months Ended |  |  | Six Months Ended |  |  |
|  |  | December 31, 2022 |  |  | December 31, 2021 |  |  | $ Change |  |  | % Change |  |  | December 31, 2022 |  |  | December 31, 2021 |  |  | $ Change |  |  | % Change |  |  |
| Research and development |  | $ | 52,618 |  |  | $ | 48,080 |  |  | $ | 4,538 |  |  |  | 9.4 | % |  | $ | 103,607 |  |  | $ | 95,846 |  |  | $ | 7,761 |  |  |  | 8.1 | % |  |
| Sales and marketing |  |  | 80,538 |  |  |  | 71,565 |  |  |  | 8,973 |  |  |  | 12.5 | % |  |  | 158,920 |  |  |  | 141,092 |  |  |  | 17,828 |  |  |  | 12.6 | % |  |
| General and administrative |  |  | 24,085 |  |  |  | 17,877 |  |  |  | 6,208 |  |  |  | 34.7 | % |  |  | 42,632 |  |  |  | 34,880 |  |  |  | 7,752 |  |  |  | 22.2 | % |  |
| Acquisition and integration costs |  |  | — |  |  |  | 2,113 |  |  |  | (2,113 | ) |  |  | (100.0 | )% |  |  | 390 |  |  |  | 3,623 |  |  |  | (3,233 | ) |  |  | (89.2 | )% |  |
| Restructuring and related charges |  |  | 476 |  |  |  | 292 |  |  |  | 184 |  |  |  | 63.0 | % |  |  | 957 |  |  |  | 571 |  |  |  | 386 |  |  |  | 67.6 | % |  |
| Amortization of intangibles |  |  | 504 |  |  |  | 804 |  |  |  | (300 | ) |  |  | (37.3 | )% |  |  | 1,027 |  |  |  | 1,958 |  |  |  | (931 | ) |  |  | (47.5 | )% |  |
| Total operating expenses |  | $ | 158,221 |  |  | $ | 140,731 |  |  | $ | 17,490 |  |  |  | 12.4 | % |  | $ | 307,533 |  |  | $ | 277,970 |  |  | $ | 29,563 |  |  |  | 10.6 | % |  |

[0001564590-23-000867:mdna:76]
[same as prior period, unchanged from 0001564590-22-035673:mdna:74]

[0001564590-23-000867:mdna:77]
[same as prior period, unchanged from 0001564590-22-035673:mdna:75]

[0001564590-23-000867:mdna:78]
Research and development expenses increased by $4.5 million or 9.4% for the three months ended December 31, 2022 as compared to the corresponding period in fiscal 2022. The increase in research and development expenses was primarily due to a $1.6 million increase in personnel costs due to higher compensation costs primarily related to share-based compensation, a $0.4 million increase in consultant fees, a $0.9 million increase in software licenses and engineering project costs, a $0.7 million increase in equipment related costs, a $0.4 increase in facility and information technology costs and a $0.5 million increase in other costs primarily related to travel and recruiting expenses.

[0001564590-23-000867:mdna:79]
Research and development expenses increased by $7.8 million or 8.1% for the six months ended December 31, 2022 as compared to the corresponding period in fiscal 2022. The increase in research and development expenses was primarily due to a $3.3 million increase in personnel related costs due to higher compensation costs primarily related to share-based compensation, a $0.7 million increase in consultant fees, a $1.4 million increase in software licenses and engineering project costs, a $1.0 million increase in equipment related costs, a $0.7 increase in facility and information technology costs and a $0.7 million increase in other costs primarily related to travel and recruiting expenses.

[0001564590-23-000867:mdna:80]
[same as prior period, unchanged from 0001564590-22-035673:mdna:77]

[0001564590-23-000867:mdna:81]
[same as prior period, unchanged from 0001564590-22-035673:mdna:78]

[0001564590-23-000867:mdna:82]
Sales and marketing expenses increased by $9.0 million or 12.5% for the three months ended December 31, 2022 as compared to the corresponding period in fiscal 2022. The increase in sales and marketing expenses was primarily due to a $7.0 million increase in personnel costs due to higher compensation and benefits costs primarily related to higher commissions and share-based compensation, a $1.3 million increase in travel costs and a $0.9 million increase in marketing and facilities related costs, partially offset by a $0.2 million decrease in equipment and other expenses.

[0001564590-23-000867:mdna:83]
Sales and marketing expenses increased by $17.8 million or 12.6% for the six months ended December 31, 2022 as compared to the corresponding period in fiscal 2022. The increase in sales and marketing expenses was primarily due to a $11.8 million increase in personnel costs due to higher compensation and benefits costs primarily related to higher commission and share-based compensation, a $4.1 million increase in travel costs and a $2.0 million increase in marketing and other related expenses.

[0001564590-23-000867:mdna:84]
[same as prior period, unchanged from 0001564590-22-035673:mdna:80]

[0001564590-23-000867:mdna:85]
[same as prior period, unchanged from 0001564590-22-035673:mdna:81]

[0001564590-23-000867:mdna:86]
General and administrative expenses increased by $6.2 million or 34.7% for the three months ended December 31, 2022 as compared to the corresponding period in fiscal 2022. The increase in general and administrative expenses was primarily due to a $2.9 million increase in personnel costs due to higher compensation and benefits costs primarily related to share-based compensation, a $1.4 million increase in professional service fees and a $2.3 million increase in litigation charges, partially offset by a net $0.4 million decrease in facilities and other costs.

[0001564590-23-000867:mdna:87]
General and administrative expenses increased by $7.8 or 22.2% for the six months ended December 31, 2022 as compared to the corresponding period in fiscal 2022. The increase in general and administrative expenses was primarily due to a $4.5 million increase in personnel costs due to higher compensation and benefits costs primarily related to share-based compensation, a $0.8 million increase in professional service fees, a $2.3 million increase in litigation charges and a net $0.2 million increase in other costs.

[0001564590-23-000867:mdna:88]
[same as prior period, unchanged from 0001564590-22-035673:mdna:83]

[0001564590-23-000867:mdna:89]
During the three months ended December 31, 2022, we did not incur any acquisition and integration costs . During the six months ended December 31, 2022, we incurred acquisition and integration costs of $0.4 million, which primarily  consisted of professional fees and certain compensation charges related to the acquisition of Ipanema.

[0001564590-23-000867:mdna:90]
During the three and six months ended December 31, 2021, we incurred $2.1 million and $3.6 million, respectively, of acquisition and integration costs, which primarily  consisted of professional fees for legal advisory services, system and product integrations and financial services related to the acquisition of Ipanema.

[0001564590-23-000867:mdna:91]
[same as prior period, unchanged from 0001564590-22-035673:mdna:86]

[0001564590-23-000867:mdna:92]
For the three and six months ended December 31, 2022, we recorded restructuring and related charges of $0.5 million and $1.0 million, respectively, which primarily consisted of facility-related charges related to our previously impaired facilities.

[0001564590-23-000867:mdna:93]
For the three and six months ended December 31, 2021, we recorded restructuring charges of $0.3 million and $0.6 million, respectively, which primarily consisted of facility related charges related to our previously impaired facilities.

[0001564590-23-000867:mdna:94]
[same as prior period, unchanged from 0001564590-22-035673:mdna:88]

[0001564590-23-000867:mdna:95]
During the three months ended December 31, 2022 and 2021, we recorded $0.5 million and $0.8 million, respectively, of operating expenses for amortization of intangibles. During the six months ended December 31, 2022 and 2021, we recorded $1.0 million and $2.0 million, respectively. The decreases were primarily due to lower amortization related to certain acquired intangibles from previous acquisitions becoming fully amortized.

[0001564590-23-000867:mdna:96]
[same as prior period, unchanged from 0001564590-22-035673:mdna:90]

[0001564590-23-000867:mdna:97]
During the three months ended December 31, 2022 and 2021, we recorded $3.9 million and $3.1 million, respectively, in interest expense. During the six months ended December 31, 2022 and 2021, we recorded $7.7 million and $7.0 million, respectively, in interest expense. The increases in interest expense were primarily driven by rising interest rates on our 2019 Credit Agreement.

[0001564590-23-000867:mdna:98]
[same as prior period, unchanged from 0001564590-22-035673:mdna:92]

[0001564590-23-000867:mdna:99]
During the three months ended December 31, 2022 and 2021, we recorded other income, net of $0.1 million and $0.1 million, respectively. During the six months ended December 31, 2022 and 2021, we recorded other income, net of $0.5 million and $0.2 million, respectively. The changes for the three and six months ended December 31, 2022 was primarily due to foreign exchange impact from the revaluation of certain assets and liabilities denominated in foreign currencies into U.S. Dollars.

[0001564590-23-000867:mdna:100]
[same as prior period, unchanged from 0001564590-22-035673:mdna:94]

[0001564590-23-000867:mdna:101]
For the three months ended December 31, 2022 and 2021, we recorded an income tax provision of $2.6 million and $1.8 million, respectively. For the six months ended December 31, 2022 and 2021, we recorded an income tax provision of $4.4 million and $3.9 million, respectively.

[0001564590-23-000867:mdna:102]
The income tax provisions for the three and six months ended December 31, 2022 and 2021 consisted of (1) taxes on the income of our foreign subsidiaries, (2) foreign withholding taxes, (3) state taxes in jurisdictions where we have no remaining state net operating losses and (4) tax expense associated with the establishment of a U.S. deferred tax liability for amortizable goodwill resulting from the acquisition of Enterasys Networks, Inc., the WLAN Business, the Campus Fabric Business and the Data Center Business.

[0001564590-23-000867:mdna:103]
[same as prior period, unchanged from 0001564590-22-035673:mdna:97]

[0001564590-23-000867:mdna:104]
[same as prior period, unchanged from 0001564590-22-035673:mdna:98]

[0001564590-23-000867:mdna:105]
[same as prior period, unchanged from 0001564590-22-035673:mdna:99]

[0001564590-23-000867:mdna:106]
[same as prior period, unchanged from 0001564590-22-035673:mdna:100]

[0001564590-23-000867:mdna:107]
[same as prior period, unchanged from 0001564590-22-035673:mdna:101]

[0001564590-23-000867:mdna:108]
[same as prior period, unchanged from 0001564590-22-035673:mdna:102]

[0001564590-23-000867:mdna:109]
[same as prior period, unchanged from 0001564590-22-035673:mdna:103]

[0001564590-23-000867:mdna:110]
[same as prior period, unchanged from 0001564590-22-035673:mdna:104]

[0001564590-23-000867:mdna:111]
|  |  | December 31, 2022 |  |  | June 30, 2022 |  |
| Cash |  | $ | 202,521 |  |  | $ | 194,522 |  |

[0001564590-23-000867:mdna:112]
As of December 31, 2022, our principal sources of liquidity consisted of cash of $202.5 million, accounts receivable, net of $152.1 million, and available borrowings under our five-year 2019 Revolving Facility of $60.2 million. Our principal uses of cash include the purchase of finished goods inventory from our contract manufacturers, payroll and other operating expenses related to the development and marketing of our products, purchases of property and equipment, and repayments of debt and related interest. We believe that our $202.5 million of cash at December 31, 2022, our cash flow from operations, and the availability of borrowings from the 2019 Revolving Facility will be sufficient to fund our planned operations for at least the next 12 months.

[0001564590-23-000867:mdna:113]
On May 18, 2022, our Board of Directors authorized management to repurchase up to $200.0 million shares of our common stock over a three-year period commencing July 1, 2022. A maximum of $25.0 million may be repurchased in any quarter. On November 17, 2022, the Board increased the authorization to repurchase in any quarter from $25.0 million per quarter to $50.0 million per quarter. Purchases may be made from time to time in the open market or pursuant to 10b5-1 plan. The manner, timing and amount of any future purchases will be determined by our management based on their evaluation of market conditions, stock price, Extreme’s ongoing determination that it is the best use of available cash and other factors. The repurchase program does not obligate Extreme to acquire any shares of its common stock, may be suspended or terminated at any time without prior notice and will be subject to regulatory considerations. During the three months ended December 31, 2022, we repurchased a total of 2,578,175 shares of common stock on the open market at a total cost of $49.8 million. As of December 31, 2022, we have $150.2 million available under our share repurchase program.

[0001564590-23-000867:mdna:114]
[same as prior period, unchanged from 0001564590-22-035673:mdna:108]

[0001564590-23-000867:mdna:115]
[same as prior period, unchanged from 0001564590-22-035673:mdna:109]

[0001564590-23-000867:mdna:116]
The 2019 Credit Agreement requires us to maintain certain minimum financial ratios at the end of each fiscal quarter. The 2019 Credit Agreement also includes covenants and restrictions that limit, among other things, our ability to incur additional indebtedness, create liens upon any of our property, merge, consolidate or sell all or substantially all of our assets. The 2019 Credit Agreement also includes customary events of default, which may result in acceleration of the outstanding balance.

[0001564590-23-000867:mdna:117]
Financial covenants under the 2019 Credit Agreement require us to maintain a minimum consolidated fixed charge and consolidated leverage ratio at the end of each fiscal quarter through maturity.  The 2019 Credit Agreement also includes covenants and restrictions that limit, among other things, our ability to incur additional indebtedness, create liens upon any of our property, merge, consolidate or sell all or substantially all of our assets. The 2019 Credit Agreement also includes customary events of default which may result in acceleration of the outstanding balance.

[0001564590-23-000867:mdna:118]
On April 8, 2020, we entered into the First Amendment to waive certain terms and financial covenants of the 2019 Credit Agreement through July 31, 2020. On May 8, 2020, we entered into a Second Amendment which superseded the First Amendment and provided certain revised terms and financial covenants through March 31, 2021. The Second Amendment required us to maintain certain minimum cash requirement and financial metrics at the end of each fiscal quarter through March 31, 2021 and we were restricted from pursuing certain activities such as incurring additional debt, stock repurchases, making acquisitions or declaring a dividend, until we came into compliance with the original covenants of the 2019 Credit Agreement. On November 3, 2020, we and our lenders entered into a Third Amendment to increase the sublimit for letters of credit to $20.0 million. On December 8, 2020, we and our lenders entered into a Fourth Amendment to waive and amend certain terms and financial covenants within the 2019 Credit Agreement through March 31, 2021.

[0001564590-23-000867:mdna:119]
The Second Amendment provided for us to end the covenant Suspension Period early and revert to the covenants and interest rates per the original terms of the 2019 Credit Agreement dated August 9, 2019 by filing a Suspension Period Early Termination Notice and Covenant Certificate demonstrating compliance. For the twelve-month period ended March 31, 2021, our financial performance was in compliance with the original covenants defined in the 2019 Credit Agreement and as such we filed a Suspension Early Termination Notice and Covenant Certificate with the administration agent subsequent to filing our Quarterly Report on Form 10-Q for the period ended March 31, 2021. During the three and six months ended December 31, 2022, we were in compliance with all the original terms and financial covenants under the 2019 Credit Agreement.

[0001564590-23-000867:mdna:120]
[same as prior period, unchanged from 0001564590-22-035673:mdna:114]

[0001564590-23-000867:mdna:121]
[same as prior period, unchanged from 0001564590-22-035673:mdna:115]

[0001564590-23-000867:mdna:122]
|  |  | Six Months Ended |  |
|  |  | December 31, 2022 |  |  | December 31, 2021 |  |
| Net cash provided by operating activities |  | $ | 120,337 |  |  | $ | 62,482 |  |
| Net cash used in investing activities |  |  | (6,271 | ) |  |  | (76,170 | ) |
| Net cash used in financing activities |  |  | (105,611 | ) |  |  | (59,394 | ) |
| Foreign currency effect on cash |  |  | (456 | ) |  |  | (264 | ) |
| Net increase (decrease) in cash |  | $ | 7,999 |  |  | $ | (73,346 | ) |

[0001564590-23-000867:mdna:123]
[same as prior period, unchanged from 0001564590-22-035673:mdna:117]

[0001564590-23-000867:mdna:124]
Cash flows provided by operations in the six months ended December 31, 2022, were $120.3 million, including our net income of $30.5 million and non-cash expenses of $50.3 million for items such as amortization of intangibles, share-based compensation, depreciation, reduction in carrying amount of right-of-use assets, deferred income taxes, and interest. Other sources of cash for the period included a decrease in accounts receivable and increases in accounts payable, accrued compensation and deferred revenue. This was partially offset by increases in inventories, prepaid expenses and other current assets and decreases in operating lease liabilities and other current and long-term liabilities.

[0001564590-23-000867:mdna:125]
Cash flows provided by operations in the six months ended December 31, 2021 were $62.5 million, including our net income of $26.0 million and non-cash expenses of $54.1 million for items such as amortization of intangibles, share-based compensation, depreciation, reduction in carrying amount of right-of-use assets, deferred income taxes and interest. Other sources of cash for the period included a decrease in accounts receivable and increase in deferred revenue. This was partially offset by increases in inventories and prepaid expenses and other current assets and decreases in accounts payable, accrued compensation, operating lease liabilities and other current and long-term liabilities.

[0001564590-23-000867:mdna:126]
[same as prior period, unchanged from 0001564590-22-035673:mdna:120]

[0001564590-23-000867:mdna:127]
Cash flows used in investing activities in the six months ended December 31, 2022 were $6.3 million for the purchases of property and equipment.

[0001564590-23-000867:mdna:128]
Cash flows used in investing activities in the six months ended December 31, 2021 were $76.2 million primarily due to the payment of $69.5 million (net of cash acquired) for the acquisition of Ipanema and $6.7 million for the purchases of property and equipment.

[0001564590-23-000867:mdna:129]
[same as prior period, unchanged from 0001564590-22-035673:mdna:123]

[0001564590-23-000867:mdna:130]
Cash flows used in financing activities in the six months ended December 31, 2022 were $105.6 million due primarily to debt repayments of $46.6 million, $2.0 million for deferred payments on acquisitions, share repurchase of $49.8 million under our share repurchase program, and $7.2 million for taxes paid on vested and released stock awards net of proceeds from the issuance of shares of our common stock under our Employee Stock Purchase Plan (“ESPP”).

[0001564590-23-000867:mdna:131]
Cash flows used in financing activities in the six months ended December 31, 2021 were $59.4 million due primarily to debt repayments of $23.9 million, share repurchases of $25.0 million under our share repurchase program, payment of contingent consideration of $0.8 million, $2.0 million for deferred payments on acquisitions and $7.7 million for taxes paid on vested and released stock awards net of proceeds from the issuance of shares of our common stock under our ESPP and exercise of stock options.

[0001564590-23-000867:mdna:132]
[same as prior period, unchanged from 0001564590-22-035673:mdna:126]

[0001564590-23-000867:mdna:133]
Foreign currency effect on cash decreased in the six months ended December 31, 2022, primarily due to changes in foreign currency exchange rates between the U.S. Dollar and particularly the Indian Rupee, the UK Pound, and the EURO.

[0001564590-23-000867:mdna:134]
[same as prior period, unchanged from 0001564590-22-035673:mdna:128]

[0001564590-23-000867:mdna:135]
As of December 31, 2022, we had contractual obligations resulting from our debt arrangement, agreements to purchase goods and services in the ordinary course of business and obligations under our operating lease arrangements.

[0001564590-23-000867:mdna:136]
Our debt obligations relate to amounts owed under our 2019 Credit Agreement. As of December 31, 2022, we had $262.0 million of debt outstanding which are payable on quarterly installments through our fiscal year 2025. We are subject to interest rate on our debt obligations and unused commitment fee. See Note 8, Debt, in the Notes to Condensed Consolidated Financial Statements for additional information regarding our debt obligations.

[0001564590-23-000867:mdna:137]
Our unconditional purchase obligations represent the purchase of long lead-time component inventory that our contract manufacturers procure in accordance with our forecast. We expect to honor the inventory purchase commitments within the next 12 months. As of December 31, 2022, we had non-cancelable commitments to purchase $57.1 million of inventory. See Note 9, Commitments and Contingencies, in the Notes to Condensed Consolidated Financial Statements for additional information regarding our purchase obligations.

[0001564590-23-000867:mdna:138]
We have contractual commitments to our suppliers which represent commitments for future services. As of December 31, 2022, we had contractual commitments of $44.7 million that are due through our fiscal year 2027.

[0001564590-23-000867:mdna:139]
We lease facilities under operating lease arrangements at various locations that expire at various dates through our fiscal year 2032. As of December 31, 2022, the value of our obligations under operating leases was $47.7 million.

[0001564590-23-000867:mdna:140]
[same as prior period, unchanged from 0001564590-22-035673:mdna:134]

[0001564590-23-000867:mdna:141]
We did not have any material commitments for capital expenditures as of December 31, 2022.

[0001564590-23-000867:mdna:142]
[same as prior period, unchanged from 0001564590-22-035673:mdna:136]

[0001564590-23-000867:mdna:143]
We did not have any off-balance sheet arrangements as of December 31, 2022.
