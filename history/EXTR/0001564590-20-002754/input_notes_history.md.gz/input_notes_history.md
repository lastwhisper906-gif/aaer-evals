# EXTR note change history — 0001564590-19-039190 → 0001564590-20-002754


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2020-01-30):
[0001564590-20-002754:note_history:1]
The Company currently has arrangements with contract manufacturers and suppliers for the manufacture of its products. Those arrangements allow the contract manufactures to procure long lead-time component inventory based upon a rolling production forecast provided by the Company. The Company is obligated to purchase long lead-time component inventory that its contract manufacturer procures in accordance with the forecast, unless the Company gives notice of order cancellation outside of applicable component lead-times. As of December 31, 2019, the Company had commitments to purchase $47.7 million of inventory and other services.
  (was, 2019-10-31, similarity 0.8272):
[0001564590-19-039190:note_history:1]
The Company currently has arrangements with contract manufacturers and suppliers for the manufacture of its products. Those arrangements allow the contract manufactures to procure long lead-time component inventory based upon a rolling production forecast provided by the Company. The Company is obligated to purchase long lead-time component inventory that inventory and other services. As of September 30, 2019, the Company had commitments to purchase $50.6 million of inventory and other services.

- changed (2020-01-30):
[0001564590-20-002754:note_history:2]
The Company may from time to time be party to litigation arising in the course of its business, including, without limitation, allegations relating to commercial transactions, business relationships or intellectual property rights. Such claims, even if not meritorious, could result in the expenditure of significant financial and managerial resources. Litigation in general, and intellectual property in particular, can be expensive and disruptive to normal business operations. Moreover, the results of legal proceedings are difficult to predict.
  (was, 2019-10-31, similarity 0.9768):
[0001564590-19-039190:note_history:2]
The Company may from time to time be party to litigation arising in the course of its business, including, without limitation, allegations relating to commercial transactions, business relationships or intellectual property rights. Such claims, even if not meritorious, could result in the expenditure of significant financial and managerial resources. Litigation in general, and intellectual property and securities litigation in particular, can be expensive and disruptive to normal business operations. Moreover, the results of legal proceedings are difficult to predict.

- changed (2020-01-30):
[0001564590-20-002754:note_history:3]
In accordance with applicable accounting guidance, the Company records accruals for certain of its outstanding legal proceedings, investigations or claims when it is probable that a liability will be incurred and the amount of loss can be reasonably estimated.  The Company evaluates, at least on a quarterly basis, developments in legal proceedings, investigations or claims that could affect the amount of any accrual, as well as any developments that would result in a loss contingency to become both probable and reasonably estimable.  When a loss contingency is not both probable and reasonably estimable, the Company does not record a loss accrual.  However, if the loss (or an additional loss in excess of any prior accrual) is at least a reasonable possibility and material, then the Company would disclose an estimate of the possible loss or range of loss, if such estimate can be made, or disclose that an estimate cannot be made.  The assessment whether a loss is probable or a reasonable possibility, and whether the loss or a range of loss is estimable, involves a series of complex judgments about future events.  Even if a loss is reasonably possible, the Company may not be able to estimate a range of possible loss, particularly where (i) the damages sought are substantial or indeterminate, (ii) the proceedings are in the early stages, or (iii) the matters involve novel or unsettled legal theories or a large number of parties. In such cases, there is considerable uncertainty regarding the ultimate resolution of such matters, including the amount of any possible loss,
  (was, 2019-10-31, similarity 0.899):
[0001564590-19-039190:note_history:3]
In accordance with applicable accounting guidance, the Company records accruals for certain of its outstanding legal proceedings, investigations or claims when it is probable that a liability will be incurred and the amount of loss can be reasonably estimated.  The Company evaluates, at least on a quarterly basis, developments in legal proceedings, investigations or claims that could affect the amount of any accrual, as well as any developments that would result in a loss contingency to become both probable and reasonably estimable.  When a loss contingency is not both probable and reasonably estimable, the Company does not record a loss accrual.  However, if the loss (or an additional loss in excess of any prior accrual) is at least a reasonable possibility and material, then the Company would disclose an estimate of the possible loss or range of loss, if such estimate can be made, or disclose that an estimate cannot be made.  The assessment whether a loss is probable or a reasonable possibility, and whether the loss or a range of loss is estimable, involves a series of complex judgments about future events.  Even if a loss is reasonably possible, the Company may not be able to estimate a range of possible loss, particularly where (i) the damages sought are substantial or indeterminate, (ii) the proceedings are in the early stages, or (iii) the matters involve novel or unsettled legal theories or a large number of parties. In such cases, there is considerable uncertainty regarding the ultimate resolution of such matters, including the amount of any possible loss, fine or penalty.  Accordingly, for current proceedings, except as noted below, the Company is currently unable to estimate any reasonably possible loss or range of possible loss.  However, an adverse resolution of one or more of such matters could have a material adverse effect on the Company's results of operations in a particular quarter or fiscal year.

- added (2020-01-30):
[0001564590-20-002754:note_history:4]
fine or penalty.  Accordingly, for current proceedings, except as noted below, the Company is currently unable to estimate any reasonably possible loss or range of possible loss.  However, an adverse resolution of one or more of such matters could have a material adverse effect on the Company's results of operations in a particular quarter or fiscal year.

- added (2020-01-30):
[0001564590-20-002754:note_history:5]
All currency conversions in this Legal Proceedings section are as of December 31, 2019.

- changed (2020-01-30):
[0001564590-20-002754:note_history:6]
On May 28, 2007, the Public Treasury Department of the State of Sao Paolo, Brazil (the “Tax Authority”) assessed the Company’s Brazilian subsidiary, Enterasys Networks do Brasil Ltda. (“Enterasys Brasil”), based on an alleged underpayment of taxes due to denial of presumed tax credits from 2003 to 2004 (the “ICMS Tax Assessment”).  The value of the disallowed presumed tax credits is BRL 3.4 million (USD $0.8 million), excluding interest and penalties.
  (was, 2019-10-31, similarity 0.6437):
[0001564590-19-039190:note_history:6]
On May 28, 2007, the Public Treasury Department of the State of Sao Paolo, Brazil (the “Tax Authority”) assessed the Company’s Brazilian subsidiary, Enterasys Networks do Brasil Ltda. (“Enterasys Brasil”), based on an alleged underpayment of taxes.  The Tax Authority also charged interest and penalties with respect to the assessment (collectively, the “ICMS Tax Assessment”).  The Tax Authority denied Enterasys Brasil the use of certain presumed tax credits granted by the State of Espirito Santo, Brazil under the terms of the FUNDAP program for the period from February 2003 to December 2004.  The value of the disallowed presumed tax credits is BRL 3.4 million (USD $0.8 million), excluding interest and penalties. All currency conversions in this Legal Proceedings section are as of September 30, 2019.

- added (2020-01-30):
[0001564590-20-002754:note_history:7]
On October 1, 2014, Enterasys Brasil filed a lawsuit in the 11th Public Treasury Court of the Sao Paolo State Court of Justice (Judiciary District of Sao Paolo) to overturn or reduce the ICMS Tax Assessment. A decision in 2017 would require Enterasys Brasil to pay a total of BRL 20.2 million (USD $5.0 million), which includes penalties, court costs, attorneys’ fees, and accrued interest as of December 1, 2019. Enterasys Brasil recorded an accrual of BRL 9.4 million (USD $2.3 million) as of the date the Company acquired Enterasys Networks. The Company has appealed the lower court’s decision.

- added (2020-01-30):
[0001564590-20-002754:note_history:8]
On December 12, 2019, Enterasys Brasil participated in an amnesty program called the Programa Especial de Parcelamento offered by the Brazilian government to reach a resolution to this issue.  On December 18, 2019, Enterasys Brasil paid BRL 8.692 million (USD $2.2 million) to settle the ICMS Tax Assessment.  The Company will dismiss the pending appellate suit and has accrued for payment of the government’s legal fees of approximately BRL 0.632 million (USD $0.157 million).

- changed (2020-01-30):
[0001564590-20-002754:note_history:9]
On April 19, 2017, XR Communications, LLC (“XR”) (d/b/a Vivato Technologies) filed a patent infringement lawsuit against the Company in the Central District of California.  The operative Second Amended Complaint asserts infringement of U.S. Patent Nos. 7,062,296, 7,729,728, and 6,611,231 based on the Company’s manufacture, use, sale, offer for sale, and/or importation into the United States of certain access points and routers supporting multi-user, multiple-input, multiple-output technology. XR seeks unspecified damages, on-going royalties, pre- and post-judgment interest, and attorneys’ fees.  In 2018, the Court stayed the case pending a resolution by the Patent Trial and Appeal Board (“PTAB”) of inter partes review (IPR) petitions filed by several defendants in other XR-related patent lawsuits challenging the validity of the asserted patents. The PTAB has now invalidated all asserted claims of the ’296 patent and ’728 patent, and has found the challenged claims of the ’231 patent not invalid in view of the prior art asserted in the IPR instituted against that patent. The matter has been stayed and a status conference is set for March 17, 2020.  The Company believes the claims are without merit and intends to defend them vigorously.
  (was, 2019-10-31, similarity 0.8346):
[0001564590-19-039190:note_history:9]
On April 19, 2017, XR Communications, LLC (“XR”) (d/b/a Vivato Technologies) filed a patent infringement lawsuit against the Company in the Central District of California (XR Communications, LLC, dba Vivato Technologies v. Extreme Networks, Inc., No. 2:17-cv-2953-AG).  The operative Second Amended Complaint asserts infringement of U.S. Patent Nos. 7,062,296, 7,729,728, and 6,611,231 based on the Company’s manufacture, use, sale, offer for sale, and/or importation into the United States of certain access points and routers supporting multi-user, multiple-input, multiple-output technology. XR seeks unspecified damages, on-going royalties, pre- and post-judgment interest, and attorneys’ fees (but no injunction).  In orders dated April 10 and May 22, 2018, the Court stayed the case pending a resolution by the Patent Trial and Appeal Board (“PTAB”) of inter partes review (IPR) petitions filed by several defendants in other XR-related patent lawsuits challenging the validity of the asserted patents. The PTAB has now invalidated all asserted claims of the ’296 patent and ’728 patent, and has found the challenged claims of the ’231 patent not invalid in view of the prior art asserted in the IPR instituted against that patent. Given the stay, the Court took off calendar all previously scheduled events (including a Markman hearing and potential trial date).  During a status conference on February 11, 2019, the Court continued the stay and set a status conference for December 2, 2019.  The Company believes the claims are without merit and intends to defend them vigorously.

- changed (2020-01-30):
[0001564590-20-002754:note_history:10]
On February 1, 2018, Orckit IP, LLC (“Orckit”) filed a patent infringement lawsuit against the Company and its Irish and German subsidiaries in the District Court in Dusseldorf, Germany.  The lawsuit alleges direct and indirect infringement of the German portion of European Patent EP 1 958 364 B1 (“EP ’364”) based on the offer, distribution, use, possession and/or importation into Germany of certain network switches equipped with the ExtremeXOS operating system.  Orckit is seeking injunctive relief, accounting, and an unspecified declaration of liability for damages and costs of the lawsuit.  On May 3, 2018, Extreme Networks GmbH filed a separate nullity action in the Federal Patent Court in Munich, seeking to invalidate the asserted patents.  The District Court Düsseldorf held a hearing in this case on January 28, 2020 and a decision is expected in a few weeks.
  (was, 2019-10-31, similarity 0.8088):
[0001564590-19-039190:note_history:10]
On February 1, 2018, Orckit IP, LLC (“Orckit”) filed a patent infringement lawsuit against the Company and its Irish and German subsidiaries in the District Court in Dusseldorf, Germany.  The lawsuit alleges direct and indirect infringement of the German portion of European Patent EP 1 958 364 B1 (“EP ’364”) based on the offer, distribution, use, possession and/or importation into Germany of certain network switches equipped with the ExtremeXOS operating system.  Orckit is seeking injunctive relief, accounting, and an unspecified declaration of liability for damages and costs of the lawsuit.  On May 3, 2018, Extreme Networks GmbH filed a separate nullity action in the Federal Patent Court in Munich, seeking to invalidate the asserted patents, and on May 4, 2018, the defendants answered the infringement complaint, denying any infringement and seeking a stay of the action pending the conclusion of the nullity action. Orckit filed its reply on September 26, 2019 and Extreme’s rejoinder is due on December 17, 2019.  The District Court Düsseldorf scheduled a hearing in this case for January 28, 2020.

- changed (2020-01-30):
[0001564590-20-002754:note_history:11]
On April 23, 2019, Orckit filed and extension of the patent infringement complaint against the Company and its Irish and German subsidiaries in the District Court in Dusseldorf, Germany. With this extension, Orckit alleges infringement of the German portion of European Patent EP 3 068 077 B1 (“EP ‘077”) based on the offer, distribution, use, possession and/or importation into Germany of certain network switches.  Orckit is seeking injunctive relief, accounting and sales information, and a declaration of liability for damages as well as costs of the lawsuit.  Extreme filed a nullity action with the German Federal Patent Court on or before that date, seeking to invalidate the asserted patent.  No hearing has been scheduled yet in this case, which was split from the original action involving the first patent in suit.
  (was, 2019-10-31, similarity 0.9409):
[0001564590-19-039190:note_history:11]
On April 23, 2019, Orckit filed and extension of the patent infringement complaint against the Company and its Irish and German subsidiaries in the District Court in Dusseldorf, Germany. With this extension, Orckit alleges infringement of the German portion of European Patent EP 3 068 077 B1 (“EP ‘077”) based on the offer, distribution, use, possession and/or importation into Germany of certain network switches.  Orckit is seeking injunctive relief, accounting and sales information, and a declaration of liability for damages as well as costs of the lawsuit.  Extreme’s answer to the EP ‘077 infringement complaint is due on November 5, 2019.  Extreme also plans to file a nullity action with the German Federal Patent Court on or before that date, seeking to invalidate the asserted patent.  No hearing has been scheduled yet in this case, which was split from the original action involving the first patent in suit.

- changed (2020-01-30):
[0001564590-20-002754:note_history:12]
The Company believes that all claims in both cases are without merit and defends them vigorously.
  (was, 2019-10-31, similarity 0.9222):
[0001564590-19-039190:note_history:12]
The Company believes that all claims are without merit and defends them vigorously.

- added (2020-01-30):
[0001564590-20-002754:note_history:13]
In January 2019, Global Innovation Aggregators, LLC (“GIA”) filed six patent infringement lawsuits against the Company and its Chinese and Hong Kong subsidiaries and Shenzhen Yingzhixiang Technology Co., Ltd. in Shenzhen Intermediate People’s Court in China. The six patents at issue are ZL200610168028.1 (“ZL ‘028.1”), ZL200510120823.9, ZL200410057124.X, ZL200410070933.4, ZL200510103486.2 (“ZL ‘486.2”), and ZL200610060686.9 (“ZL ‘686.9”) (collectively, the “Asserted Patents”). GIA has accused a number of Summit switching products of infringing the Asserted Patents. Each patent was asserted in a separate lawsuit.  The trial related to the ZL ‘4862 patent has been postponed, and the trials for the rest of the cases have not yet been scheduled. Extreme disputes GIA’s claims and intends to defend the matter vigorously.  Additionally, Extreme has filed invalidity challenges with the Chinese patent office to challenge the validity of each asserted patent.  Oral invalidity hearings were held in July and August 2019. The Chinese patent office has issued decisions maintaining the validity of the ZL ‘028.1 and ZL ‘486.2 patents, and Extreme has appealed these two rulings.  All the claims in ZL ‘686.9 have been fully invalidated.  Decisions have not yet been issued for the remaining three patents.

- added (2020-01-30):
[0001564590-20-002754:note_history:14]
Given the uncertainty of litigation and the preliminary stage of the case, Extreme cannot estimate at this time the possible loss or range of loss that may result from this action.

- added (2020-01-30):
[0001564590-20-002754:note_history:15]
On June 20, 2019, Shenzhen Dunjun Technology Ltd. (“Shenzhen Dunjun”) filed a patent infringement lawsuit against Aerohive Networks, Inc. (“Aerohive”), its Chinese subsidiary, and Yunqing Information Technology (Shenzhen) Ltd. in the Shenzhen Intermediate People’s Court in China.  The lawsuit alleges infringement of Chinese patent ZL02123502.3 and seeks damages of RMB 10.0 million (USD $1.4 million). The trial originally scheduled for November 15, 2019 has been postponed by the Court, pending the jurisdictional objections filed by Aerohive and has not yet been rescheduled.  The Court rejected the jurisdictional challenge, which Aerohive is appealing. The Company cannot estimate at this time the possible loss or range of loss that may result from this action.

- changed (2020-01-30):
[0001564590-20-002754:note_history:16]
Subject to certain limitations, the Company may be obligated to indemnify its current and former directors, officers and employees. These obligations arise under the terms of its certificate of incorporation, its bylaws, applicable contracts, and applicable law. The obligation to indemnify, where applicable, generally means that the Company is required to pay or reimburse, and in certain circumstances the Company has paid or reimbursed, the individuals' reasonable legal expenses and possibly damages and other liabilities incurred in connection with certain legal matters. The Company also procures Directors and Officers insurance to help cover its defense and/or indemnification costs, although its ability to recover such costs through insurance is uncertain.  While it is not possible to estimate the maximum potential amount that could be owed under these indemnification agreements due to the Company’s limited history with prior indemnification claims, indemnification (including defense) costs could, in the future, have a material adverse effect on the Company’s consolidated financial position, results of operations and cash flows.
  (was, 2019-10-31, similarity 0.8324):
[0001564590-19-039190:note_history:16]
Subject to certain limitations, the Company may be obligated to indemnify its current and former directors, officers and employees. These obligations arise under the terms of its certificate of incorporation, its bylaws, applicable contracts, and applicable law. The obligation to indemnify, where applicable, generally means that the Company is required to pay or reimburse, and in certain circumstances the Company has paid or reimbursed, the individuals' reasonable legal expenses and possibly damages and other liabilities incurred in connection with certain legal matters. For example, the Company currently is paying or reimbursing legal expenses being incurred by certain current and former officers and directors in connection with the shareholder litigation described above.  The Company also procures Directors and Officers insurance to help cover its defense and/or indemnification costs, although its ability to recover such costs through insurance is uncertain.  While it is not possible to estimate the maximum potential amount that could be owed under these indemnification agreements due to the Company’s limited history with prior indemnification claims, indemnification (including defense) costs could, in the future, have a material adverse effect on the Company’s consolidated financial position, results of operations and cash flows. As of September 30, 2019, the Company has the outstanding indemnification claims described above.

- removed (2020-01-30):
[0001564590-19-039190:note_history:17]
Unable to resolve the matter at the administrative level, on October 1, 2014, Enterasys Brasil filed a lawsuit in the 11th Public Treasury Court of the Sao Paolo State Court of Justice (Judiciary District of Sao Paolo) to overturn or reduce the ICMS Tax Assessment. As part of this lawsuit, Enterasys Brasil requested a stay of execution, so that no tax foreclosure could be filed and no guarantee would be required until the court issued its final ruling.  On or about October 6, 2014, the court granted a preliminary injunction staying any execution on the assessment but requiring that Enterasys Brasil deposit the assessed amount with the court.  Enterasys Brasil appealed this ruling and, on or about January 28, 2015, the appellate court ruled that no cash deposit (or guarantee) was required.  In a decision dated August 28, 2017, and published on October 3, 2017, the court validated the assessment and penalty imposed by the Tax Authority but ruled that the Tax Authority was charging an unlawfully high interest rate on the tax assessment and penalty amounts and ordered the interest rate reduced to the maximum Federal rate. The August 28, 2017, decision, were it to become final, would require Enterasys Brasil to pay a total of BRL 20.0 million (USD $4.8 million), which includes penalties, court costs, attorneys’ fees, and accrued interest as of September 30, 2019.  The Company believes the ICMS Tax Assessment against Enterasys Brasil is without merit and has appealed the lower court’s decision.  The appellate court ruled that no cash deposit (or guarantee) is required during the pendency of the appeal.

- removed (2020-01-30):
[0001564590-19-039190:note_history:18]
Based on the currently available information, the Company believes the ultimate outcome of the ICMS Tax Assessment litigation will not have a material adverse effect on the Company's financial position or overall results of operations. However, due to the complexities and uncertainty surrounding the judicial process in Brazil and the nature of the claims asserted, there can be no assurance of a favorable outcome for Enterasys Brasil, which recorded an accrual of BRL 9.4 million (USD $2.2 million) as of the date the Company acquired Enterasys Networks.

- removed (2020-01-30):
[0001564590-19-039190:note_history:19]
The Company made a demand on April 11, 2014, for a defense from, and indemnification by, the former equity holder of Enterasys Networks, Inc. (“Seller”) in connection with the ICMS Tax Assessment. Seller agreed to assume the defense of the ICMS Tax Assessment on May 20, 2014. In addition, through the settlement of an indemnification-related lawsuit with the Seller on June 18, 2015, Seller agreed to continue to defend the Company with respect to the ICMS Tax Assessment and to indemnify the Company for losses related thereto subject to certain conditions. These conditions include the offsetting of foreign income tax benefits realized by the Company in connection with the acquisition of Enterasys.  Based upon current projections of the foreign income tax benefits to be realized, and the potential liability in the event of an adverse final judgment in the ICMS Tax Assessment litigation, the Company does not presently anticipate that any amounts under the indemnification will be due from the Seller in connection with the ICMS Tax Assessment.

- removed (2020-01-30):
[0001564590-19-039190:note_history:20]
In January 2019, Global Innovation Aggregators, LLC (“GIA”) filed six patent infringement lawsuits against the Company and its Chinese and Hong Kong subsidiaries and Shenzhen Yingzhixiang Technology Co., Ltd. in Shenzhen Intermediate People’s Court in China. The six patents at issue are ZL200610168028.1 (“ZL ‘028.1”), ZL200510120823.9, ZL200410057124.X, ZL200410070933.4, ZL200510103486.2 (“ZL ‘486.2”), and ZL200610060686.9 (collectively, the “Asserted Patents”).  Each patent was asserted in a separate law suit.  The filing date for the first case is January 18, 2019, and the filing date for the rest of the cases is January 23, 2019.  The trial for the first case is currently scheduled for January 15, 2020, and trials for the rest of the cases have not yet been scheduled.  GIA has accused the Summit X440-G2-24t-10GE4 (product number: 16532), Summit X440-G2-24p-10GE4 (product number: 16533) and Summit X460-G2-24x-10GE4-Base (product number: 16705) (collectively the “Accused Products”) of infringing the Asserted Patents. GIA has also alleged that the following Extreme switch products support the same functions as the Accused Products:  Summit X440-G2 series, X450-G2 series, X460-G2 series, X620 series, X670-G2 series, X770 series, X870 series, X690 series, and X590 series.  GIA is a U.S. entity established under the laws of Delaware with its principal office in Pasadena, California.  Extreme disputes GIA’s claims and intends to defend the matter vigorously.  Additionally, Extreme has filed invalidity challenges with the Chinese patent office to challenge the validity of each asserted patent.  Oral invalidity hearings were held in July and August 2019. The Chinese patent office has issued decisions maintaining the validity of the ZL ‘028.1 and ZL ‘486.2 patents, but has not yet issued decisions for the remaining four patents. Given the uncertainty of litigation and the preliminary stage of the case, Extreme cannot estimate at this time the possible loss or range of loss that may result from this action.

- removed (2020-01-30):
[0001564590-19-039190:note_history:21]
In late September 2019, Extreme Networks learned of a patent infringement lawsuit filed by Shenzhen Dunjun Technology Ltd. (“Shenzhen Dunjun”) against Aerohive Networks, Inc., its Chinese subsidiary, and Yunqing Information Technology (Shenzhen) Ltd. in the Shenzhen Intermediate People’s Court in China.  The lawsuit alleges infringement of Chinese patent ZL02123502.3.  The complaint was received by Aerohive Networks, Inc. on October 9 and by its Chinese subsidiary on October 10.  Extreme cannot estimate at this time the possible loss or range of loss that may result from this action, but Shenzhen Dunjun claims damages in the amount of RMB 10,000,000.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2020-01-30):
[0001564590-20-002754:note_history:22]
The unaudited condensed consolidated financial statements of Extreme included herein have been prepared under the rules and regulations of the Securities and Exchange Commission (“SEC”).  Certain information and footnote disclosures normally included in financial statements prepared in accordance with U.S. generally accepted accounting principles have been condensed or omitted under such rules and regulations.  The condensed consolidated balance sheet at June 30, 2019 was derived from audited financial statements as of that date but does not include all disclosures required by generally accepted accounting principles for complete financial statements. These interim financial statements and notes should be read in conjunction with the Company’s audited consolidated financial statements and notes thereto included in the Company’s Annual Report on Form 10-K for the fiscal year ended June 30, 2019.
  (was, 2019-10-31, similarity 0.9972):
[0001564590-19-039190:note_history:22]
The unaudited condensed consolidated financial statements of Extreme included herein have been prepared under the rules and regulations of the Securities and Exchange Commission (“SEC”).  Certain information and footnote disclosures normally included in financial statements prepared in accordance with generally accepted accounting principles have been condensed or omitted under such rules and regulations.  The condensed consolidated balance sheet at June 30, 2019 was derived from audited financial statements as of that date but does not include all disclosures required by generally accepted accounting principles for complete financial statements. These interim financial statements and notes should be read in conjunction with the Company’s audited consolidated financial statements and notes thereto included in the Company’s Annual Report on Form 10-K for the fiscal year ended June 30, 2019.

- changed (2020-01-30):
[0001564590-20-002754:note_history:23]
The unaudited condensed consolidated financial statements reflect all adjustments, consisting only of normal recurring adjustments that, in the opinion of management, are necessary for a fair presentation of the results of operations and cash flows for the interim periods presented and the financial condition of Extreme at December 31, 2019. The results of operations for the three and six months ended December 31, 2019 are not necessarily indicative of the results that may be expected for fiscal 2020 or any future periods.
  (was, 2019-10-31, similarity 0.775):
[0001564590-19-039190:note_history:23]
The unaudited condensed consolidated financial statements reflect all adjustments, consisting only of normal recurring adjustments that, in the opinion of management, are necessary for a fair presentation of the results of operations and cash flows for the interim periods presented and the financial condition of Extreme at September 30, 2019. The results of operations for the three months ended September 30, 2019 are not necessarily indicative of the results that may be expected for fiscal 2020 or any future periods.


## us-gaap:SignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2020-01-30):
[0001564590-20-002754:note_history:24]
For a description of significant accounting policies, see Note 2, Summary of Significant Accounting Policies, to the consolidated financial statements included in the Company’s Annual Report on Form 10-K for the fiscal year ended June 30, 2019. There have been no material changes to the Company’s significant accounting policies since the filing of the Annual Report on Form 10-K, except for the adoption of the new lease guidance and related policies as discussed within these financial statements.
  (was, 2019-10-31, similarity 0.8621):
[0001564590-19-039190:note_history:24]
For a description of significant accounting policies, see Note 2, Summary of Significant Accounting Policies, to the consolidated financial statements included in the Company’s Annual Report on Form 10-K for the fiscal year ended June 30, 2019. There have been no material changes to the Company’s significant accounting policies since the filing of the Annual Report on Form 10-K.

- changed (2020-01-30):
[0001564590-20-002754:note_history:25]
In February 2016, the Financial Accounting Standards Board (“FASB”) issued ASU No. 2016-02, Leases (Topic 842), which requires the identification of arrangements that should be accounted for as leases by lessees and lessors, and key disclosure information about leasing arrangements. In general, for lease arrangements exceeding a twelve-month term, these arrangements are recognized as assets and liabilities on the balance sheet of the lessee. Under Topic 842, a right-of-use asset (“ROU”) and lease obligation are recorded for all leases, whether operating or financing, while the statement of operations will reflect lease expense for operating leases and amortization/interest expense for financing leases. The balance sheet amount recorded for existing leases at the date of adoption of Topic 842 is calculated using the applicable incremental borrowing rate at the date of adoption. Topic 842 also requires lessors to classify leases as a sales-type, direct financing or operating lease.  A lease is a sales-type lease if any one of five criteria are met, each of which indicate that the lease, in effect, transfers control of the underlying asset to the lessee. If none of those five criteria are met, but two additional criteria are both met, indicating that the lessor has transferred substantially all of the risks and benefits to the lessee and a third party, the lease is a direct financing lease.  All leases that are not sales-type or direct financing leases are operating leases. Substantially all of the Company’s leases continue to be classified as operating leases. In addition, Topic 842 was subsequently amended by ASU No 2018-10, Codification Improvements; ASU 2018-11, Targeted Improvements; ASU 2018-20 Narrow Scope Improvements; and ASU 2019-01 Codification Improvements.
  (was, 2019-10-31, similarity 0.998):
[0001564590-19-039190:note_history:25]
In February 2016, the Financial Accounting Standards Board (“FASB”) issued ASU No. 2016-02, Leases (Topic 842), which requires the identification of arrangements that should be accounted for as leases by lessees and lessors, and key disclosure information about leasing arrangements. In general, for lease arrangements exceeding a twelve-month term, these arrangements is recognized as assets and liabilities on the balance sheet of the lessee. Under Topic 842, a right-of-use asset (“ROU”) and lease obligation are recorded for all leases, whether operating or financing, while the statement of operations will reflect lease expense for operating leases and amortization/interest expense for financing leases. The balance sheet amount recorded for existing leases at the date of adoption of Topic 842 is calculated using the applicable incremental borrowing rate at the date of adoption. Topic 842 also required lessors to classify leases as a sales-type, direct financing or operating lease.  A lease is a sales-type lease if any one of five criteria are met, each of which indicate that the lease, in effect, transfers control of the underlying asset to the lessee. If none of those five criteria are met, but two additional criteria are both met, indicating that the lessor has transferred substantially all of the risks and benefits to the lessee and a third party, the lease is a direct financing lease.  All leases that are not sales-type or direct financing leases are operating leases. Substantially all of the Company’s leases continue to be classified as operating leases. In addition, Topic 842 was subsequently amended by ASU No 2018-10, Codification Improvements; ASU 2018-11, Targeted Improvements; ASU 2018-20 Narrow Scope Improvements; and ASU 2019-01 Codification Improvements.

- changed (2020-01-30):
[0001564590-20-002754:note_history:26]
The new standard provides a number of optional practical expedients in transition. The Company elected the “package of practical expedients” which permitted the Company not to reassess under the new standard its prior conclusions about lease identification, lease classification, and initial direct costs. The new standard also provided practical expedients for ongoing accounting. The Company also elected the short-term lease recognition exemption for all leases that qualified. For those leases that qualified, existing short-term leases at the transition date and those entered into subsequent to the transition date, the Company did not recognize right-of-use assets or lease liabilities. In addition, the Company elected the practical expedient not to separate lease and non-lease components for leases except for the logistic services asset class and certain revenue subscription contracts where the Company leases its hardware products and provides maintenance and support over a service period which is recognized under ASC Topic 606. See Note 9, Leases, for additional information regarding the Company’s leases.
  (was, 2019-10-31, similarity 0.9461):
[0001564590-19-039190:note_history:26]
The new standard provides a number of optional practical expedients in transition. The Company elected the “package of practical expedients” which permitted the Company not to reassess under the new standard its prior conclusions about lease identification, lease classification, and initial direct costs. The new standard also provided practical expedients for ongoing accounting. The Company also elected the short-term lease recognition exemption for all leases that qualified. For those leases that qualified, existing short-term leases at the transition date and those entered into subsequent to the transition date, the Company did not recognize right-of-use assets or lease liabilities. In addition, the Company elected the practical expedient not to separate lease and non-lease components for leases except for the logistic services asset class and certain revenue subscription contracts where the Company leases its hardware products and is deemed to be a lessor.  See Note 9, Leases, for additional information regarding the Company’s leases.

- changed (2020-01-30):
[0001564590-20-002754:note_history:27]
On July 1, 2019, the Company recognized ROU assets of approximately $64.6 million and corresponding lease liabilities of $79.5 million on the condensed consolidated balance sheets, which was based on the present value of the remaining minimum rental payments under current leasing standards for existing operating leases.
  (was, 2019-10-31, similarity 0.9475):
[0001564590-19-039190:note_history:27]
The Company recognized ROU assets of approximately $64.6 million and corresponding lease liabilities of $79.5 million on the condensed consolidated balance sheets, which was based on the present value of the remaining minimum rental payments under current leasing standards for existing operating leases. See Note 9 – Leases.

- added (2020-01-30):
[0001564590-20-002754:note_history:28]
In December 2019, the FASB issued ASU 2019-12, Income taxes – Simplifying the Accounting for Income taxes (Topic 740), which reduces the complexity of accounting for income taxes including the removal of certain exceptions to the general principles of ASC 740, Income taxes, and simplification in several other areas such as accounting for franchise tax (or similar tax) that is partially based on income. This standard is effective for interim and annual reporting periods beginning after December 15, 2020, and early adoption is permitted. The Company is currently evaluating the impact the new standard will have on its condensed consolidated financial statements. This guidance is effective for the Company beginning with its fiscal year 2022, beginning on July 1, 2021.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2020-01-30):
[0001564590-20-002754:note_history:29]
|  |  | December 31, 2019 |  |  | June 30, 2019 |  |
| Current portion of long-term debt: |  |  |  |  |  |  |  |  |
| Term Loan |  | $ | 19,000 |  |  | $ | 9,500 |  |
| Less: unamortized debt issuance costs |  |  | (2,186 | ) |  |  | (489 | ) |
| Current portion of long-term debt |  | $ | 16,814 |  |  | $ | 9,011 |  |
| Long-term debt, less current portion: |  |  |  |  |  |  |  |  |
| Term Loan |  | $ | 356,250 |  |  | $ | 171,000 |  |
| Less: unamortized debt issuance costs |  |  | (7,334 | ) |  |  | (1,261 | ) |
| Total long-term debt, less current portion |  |  | 348,916 |  |  |  | 169,739 |  |
| Total debt |  | $ | 365,730 |  |  | $ | 178,750 |  |
  (was, 2019-10-31, similarity 0.9547):
[0001564590-19-039190:note_history:29]
|  |  | September 30, 2019 |  |  | June 30, 2019 |  |
| Current portion of long-term debt: |  |  |  |  |  |  |  |  |
| Term Loan |  | $ | 19,000 |  |  | $ | 9,500 |  |
| Less: unamortized debt issuance costs |  |  | (2,477 | ) |  |  | (489 | ) |
| Current portion of long-term debt |  | $ | 16,523 |  |  | $ | 9,011 |  |
| Long-term debt, less current portion: |  |  |  |  |  |  |  |  |
| Term Loan |  | $ | 361,000 |  |  | $ | 171,000 |  |
| Revolving Facility |  |  | — |  |  |  | — |  |
| Less: unamortized debt issuance costs |  |  | (7,594 | ) |  |  | (1,261 | ) |
| Total long-term debt, less current portion |  |  | 353,406 |  |  |  | 169,739 |  |
| Total debt |  | $ | 369,929 |  |  | $ | 178,750 |  |

- changed (2020-01-30):
[0001564590-20-002754:note_history:30]
In connection with the Acquisition as discussed in Note 4, on August 9, 2019, the Company entered into an Amended and Restated Credit Agreement (the “2019 Credit Agreement”), by and among the Company, as borrower, several banks and other financial institutions as Lenders, BMO Harris Bank N.A., as an issuing lender and swingline lender, Silicon Valley Bank, as an Issuing Lender, and Bank of Montreal, as administrative agent and collateral agent for the Lenders.
  (was, 2019-10-31, similarity 0.987):
[0001564590-19-039190:note_history:30]
In connection with the acquisition of Aerohive as discussed in Note 4, on August 9, 2019, the Company entered into an Amended and Restated Credit Agreement (the “2019 Credit Agreement”), by and among the Company, as borrower, several banks and other financial institutions as Lenders, BMO Harris Bank N.A., as an issuing lender and swingline lender, Silicon Valley Bank, as an Issuing Lender, and Bank of Montreal, as administrative agent and collateral agent for the Lenders.

- changed (2020-01-30):
[0001564590-20-002754:note_history:31]
The 2019 Credit Agreement provides for a 5-year first lien term loan facility in an aggregate principal amount of $380 million (the “2019 Term Loan”) and a 5-year revolving loan facility in an aggregate principal amount of $75 million (the “2019 Revolving Facility”).  In addition, the Company may request incremental term loans and/or incremental revolving loan commitments in an aggregate amount not to exceed the sum of $100 million plus an unlimited amount that is subject to pro forma compliance with certain financial tests. On August 9, 2019, the Company used the proceeds to partially fund the Acquisition and for working capital and general corporate purposes.
  (was, 2019-10-31, similarity 0.9908):
[0001564590-19-039190:note_history:31]
The 2019 Credit Agreement provides for a 5-year first lien term loan facility in an aggregate principal amount of $380 million (the “2019 Term Loan”) and a 5-year revolving loan facility in an aggregate principal amount of $75 million (the “2019 Revolving Facility”).  In addition, the Company may request incremental term loans and/or incremental revolving loan commitments in an aggregate amount not to exceed the sum of $100 million plus an unlimited amount that is subject to pro forma compliance with certain financial tests. On August 9, 2019, the Company used the proceeds to partially fund the acquisition of Aerohive and for working capital and general corporate purposes.

- changed (2020-01-30):
[0001564590-20-002754:note_history:32]
Financing costs incurred in connection with obtaining long-term financing are deferred and amortized over the term of the related indebtedness or credit agreement.  The Company incurred $10.5 million of deferred financing costs in conjunction which this modification of the debt and continues to amortize $1.6 million of debt issuance costs as of August 9, 2019 that were associated with the previous facility.  The interest rate as of December 31, 2019 was 5.0%.
  (was, 2019-10-31, similarity 0.9428):
[0001564590-19-039190:note_history:32]
Financing costs incurred in connection with obtaining long-term financing are deferred and amortized over the term of the related indebtedness or credit agreement.   The Company incurred $10.5 million of deferred financing costs in conjunction which this modification of the debt and continues to amortize $1.6 million of unamortized debt issuance costs associated with the previous facility.  The interest rate as of September 30, 2019 is 5.47%

- changed (2020-01-30):
[0001564590-20-002754:note_history:33]
Amortization of deferred financing costs included in “Interest expense” in the accompanying condensed consolidated statements of operations totaled $0.7 million and $0.2 million for the three months ended December 31, 2019 and 2018, and totaled $1.1 million and $0.3 million for the six months ended December 31, 2019 and 2018, respectively.
  (was, 2019-10-31, similarity 0.8379):
[0001564590-19-039190:note_history:33]
Amortization of deferred financing costs included in “Interest expense” in the accompanying condensed consolidated statements of operations totaled $0.5 million and $0.2 million for the three months ended September 30, 2019 and 2018, respectively.

- changed (2020-01-30):
[0001564590-20-002754:note_history:34]
The Company had $60.3 million of availability under the 2019 Revolving Facility as of December 31, 2019.  The Company had $7.7 million of outstanding letters of credit as of December 31, 2019.
  (was, 2019-10-31, similarity 0.9709):
[0001564590-19-039190:note_history:34]
The Company had $70.6 million of availability under the 2019 Revolving Facility as of September 30, 2019.  The Company had $4.4 million of outstanding letters of credit as of September 30, 2019.


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2020-01-30):
[0001564590-20-002754:note_history:35]
|  |  | December 31, 2019 |  |  | June 30, 2019 |  |
| Current portion of long-term debt: |  |  |  |  |  |  |  |  |
| Term Loan |  | $ | 19,000 |  |  | $ | 9,500 |  |
| Less: unamortized debt issuance costs |  |  | (2,186 | ) |  |  | (489 | ) |
| Current portion of long-term debt |  | $ | 16,814 |  |  | $ | 9,011 |  |
| Long-term debt, less current portion: |  |  |  |  |  |  |  |  |
| Term Loan |  | $ | 356,250 |  |  | $ | 171,000 |  |
| Less: unamortized debt issuance costs |  |  | (7,334 | ) |  |  | (1,261 | ) |
| Total long-term debt, less current portion |  |  | 348,916 |  |  |  | 169,739 |  |
| Total debt |  | $ | 365,730 |  |  | $ | 178,750 |  |
  (was, 2019-10-31, similarity 0.9547):
[0001564590-19-039190:note_history:35]
|  |  | September 30, 2019 |  |  | June 30, 2019 |  |
| Current portion of long-term debt: |  |  |  |  |  |  |  |  |
| Term Loan |  | $ | 19,000 |  |  | $ | 9,500 |  |
| Less: unamortized debt issuance costs |  |  | (2,477 | ) |  |  | (489 | ) |
| Current portion of long-term debt |  | $ | 16,523 |  |  | $ | 9,011 |  |
| Long-term debt, less current portion: |  |  |  |  |  |  |  |  |
| Term Loan |  | $ | 361,000 |  |  | $ | 171,000 |  |
| Revolving Facility |  |  | — |  |  |  | — |  |
| Less: unamortized debt issuance costs |  |  | (7,594 | ) |  |  | (1,261 | ) |
| Total long-term debt, less current portion |  |  | 353,406 |  |  |  | 169,739 |  |
| Total debt |  | $ | 369,929 |  |  | $ | 178,750 |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2020-01-30):
[0001564590-20-002754:note_history:36]
|  |  | Three Months Ended |  |
|  |  | December 31, 2019 |  |  | December 31, 2018 |  |
|  |  | Distributor |  | Direct |  | Total |  |  | Distributor |  | Direct |  | Total |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  | $ | 60,111 |  | $ | 61,622 |  | $ | 121,733 |  |  | $ | 44,141 |  | $ | 55,326 |  | $ | 99,467 |  |
| Other |  |  | 8,204 |  |  | 5,563 |  |  | 13,767 |  |  |  | 8,269 |  |  | 5,380 |  |  | 13,649 |  |
| Total Americas |  |  | 68,315 |  |  | 67,185 |  |  | 135,500 |  |  |  | 52,410 |  |  | 60,706 |  |  | 113,116 |  |
| EMEA |  |  | 64,717 |  |  | 44,257 |  |  | 108,974 |  |  |  | 79,876 |  |  | 32,773 |  |  | 112,649 |  |
| APAC |  |  | 6,007 |  |  | 16,991 |  |  | 22,998 |  |  |  | 4,767 |  |  | 22,148 |  |  | 26,915 |  |
| Total net revenues |  | $ | 139,039 |  | $ | 128,433 |  | $ | 267,472 |  |  | $ | 137,053 |  | $ | 115,627 |  | $ | 252,680 |  |
  (was, 2019-10-31, similarity 0.9889):
[0001564590-19-039190:note_history:36]
|  |  | Three Months Ended |  |
|  |  | September 30, 2019 |  |  | September 30, 2018 |  |
|  |  | Distributor |  | Direct |  | Total |  |  | Distributor |  | Direct |  | Total |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  | $ | 69,978 |  | $ | 62,345 |  | $ | 132,323 |  |  | $ | 56,742 |  | $ | 59,936 |  | $ | 116,678 |  |
| Other |  |  | 4,015 |  |  | 4,999 |  |  | 9,014 |  |  |  | 4,493 |  |  | 5,524 |  |  | 10,017 |  |
| Total Americas |  |  | 73,993 |  |  | 67,344 |  |  | 141,337 |  |  |  | 61,235 |  |  | 65,460 |  |  | 126,695 |  |
| EMEA |  |  | 59,129 |  |  | 29,634 |  |  | 88,763 |  |  |  | 61,331 |  |  | 30,838 |  |  | 92,169 |  |
| APAC |  |  | 9,113 |  |  | 16,293 |  |  | 25,406 |  |  |  | 2,349 |  |  | 18,673 |  |  | 21,022 |  |
| Total net revenues |  | $ | 142,235 |  | $ | 113,271 |  | $ | 255,506 |  |  | $ | 124,915 |  | $ | 114,971 |  | $ | 239,886 |  |

- added (2020-01-30):
[0001564590-20-002754:note_history:37]
|  |  | Six Months Ended |  |
|  |  | December 31, 2019 |  |  | December 31, 2018 |  |
|  |  | Distributor |  | Direct |  | Total |  |  | Distributor |  | Direct |  | Total |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  | $ | 130,089 |  | $ | 123,967 |  | $ | 254,056 |  |  | $ | 100,883 |  | $ | 115,262 |  | $ | 216,145 |  |
| Other |  |  | 12,219 |  |  | 10,562 |  |  | 22,781 |  |  |  | 12,762 |  |  | 10,904 |  |  | 23,666 |  |
| Total Americas |  |  | 142,308 |  |  | 134,529 |  |  | 276,837 |  |  |  | 113,645 |  |  | 126,166 |  |  | 239,811 |  |
| EMEA |  |  | 123,846 |  |  | 73,891 |  |  | 197,737 |  |  |  | 141,207 |  |  | 63,611 |  |  | 204,818 |  |
| APAC: |  |  | 15,120 |  |  | 33,284 |  |  | 48,404 |  |  |  | 7,116 |  |  | 40,821 |  |  | 47,937 |  |
| Total net revenues |  | $ | 281,274 |  | $ | 241,704 |  | $ | 522,978 |  |  | $ | 261,968 |  | $ | 230,598 |  | $ | 492,566 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2020-01-30):
[0001564590-20-002754:note_history:38]
On December 31, 2019, the Company had $277.8 million of remaining performance obligations, which primarily comprised of deferred maintenance and SaaS revenue.  The Company expects to recognize approximately 42 percent of its deferred revenue as revenue in fiscal 2020, an additional 34 percent in fiscal 2021 and 24 percent of the balance thereafter.
  (was, 2019-10-31, similarity 0.9083):
[0001564590-19-039190:note_history:38]
On September 30, 2019, the Company had $273.7 million of remaining performance obligations, which primarily comprised of deferred maintenance and SaaS revenue.  The Company expects to recognize approximately 58 percent of its remaining performance obligations as revenue in fiscal 2020, an additional 24 percent in fiscal 2021 and 18 percent of the balance thereafter.

- changed (2020-01-30):
[0001564590-20-002754:note_history:39]
Revenue recognized for the three months ended December 31, 2019 and 2018 that was included in the deferred revenue balance at the beginning of each period was $67.2 million and $59.9 million, respectively. Revenue recognized for the six months ended December 31, 2019 and 2018 that was included in the deferred revenue balance at the beginning of each period was $90.9 million and $88.8 million, respectively.
  (was, 2019-10-31, similarity 0.6597):
[0001564590-19-039190:note_history:39]
Revenue recognized for the three months ended September 30, 2019 and 2018 that was included in the deferred revenue balance at the beginning of each period was $53.8 million and $50.6 million, respectively.

- changed (2020-01-30):
[0001564590-20-002754:note_history:40]
Contract Costs. The Company recognizes the incremental costs of obtaining contracts as an expense when incurred if the amortization period of the assets that the Company otherwise would have recognized is one year or less.  Management expects that commission fees paid to sales representatives as a result of obtaining service contracts and contract renewals are recoverable and therefore the Company’s condensed consolidated balance sheets included capitalized balances in the amount of $8.3 million and $6.5 million at December 31, 2019 and June 30, 2019, respectively.  Capitalized commission fees are amortized on a straight-line basis over the average period of service contracts of approximately three years, and are included in “Sales and marketing” in the accompanying condensed consolidated statements of operations. Amortization recognized during the three months ended December 31, 2019 and 2018, was $1.5 million and $0.7 million, respectively. Amortization recognized during the six months ended December 31, 2019 and 2018 was $3.0 million and $1.4 million, respectively. There was no impairment loss in relation to the costs capitalized.
  (was, 2019-10-31, similarity 0.8783):
[0001564590-19-039190:note_history:40]
Contract Costs. The Company recognizes the incremental costs of obtaining contracts as an expense when incurred if the amortization period of the assets that the Company otherwise would have recognized is one year or less.  Management expects that commission fees paid to sales representatives as a result of obtaining service contracts and contract renewals are recoverable and therefore the Company’s condensed consolidated balance sheets included capitalized balances in the amount of $7.6 million and $4.9 million at September 30, 2019 and June 30, 2018, respectively.  Capitalized commission fees are amortized on a straight-line basis over the average period of service contracts of approximately three years, and are included in “Sales and marketing” in the accompanying condensed consolidated statements of operations.  Amortization recognized during the three months ended September 30, 2019 and 2018, was $2.7 million and $0.7 million, respectively. There was no impairment loss in relation to the costs capitalized.

- changed (2020-01-30):
[0001564590-20-002754:note_history:41]
|  |  | Three Months Ended |  |
|  |  | December 31, 2019 |  |  | December 31, 2018 |  |
|  |  | Distributor |  | Direct |  | Total |  |  | Distributor |  | Direct |  | Total |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  | $ | 60,111 |  | $ | 61,622 |  | $ | 121,733 |  |  | $ | 44,141 |  | $ | 55,326 |  | $ | 99,467 |  |
| Other |  |  | 8,204 |  |  | 5,563 |  |  | 13,767 |  |  |  | 8,269 |  |  | 5,380 |  |  | 13,649 |  |
| Total Americas |  |  | 68,315 |  |  | 67,185 |  |  | 135,500 |  |  |  | 52,410 |  |  | 60,706 |  |  | 113,116 |  |
| EMEA |  |  | 64,717 |  |  | 44,257 |  |  | 108,974 |  |  |  | 79,876 |  |  | 32,773 |  |  | 112,649 |  |
| APAC |  |  | 6,007 |  |  | 16,991 |  |  | 22,998 |  |  |  | 4,767 |  |  | 22,148 |  |  | 26,915 |  |
| Total net revenues |  | $ | 139,039 |  | $ | 128,433 |  | $ | 267,472 |  |  | $ | 137,053 |  | $ | 115,627 |  | $ | 252,680 |  |
  (was, 2019-10-31, similarity 0.9889):
[0001564590-19-039190:note_history:41]
|  |  | Three Months Ended |  |
|  |  | September 30, 2019 |  |  | September 30, 2018 |  |
|  |  | Distributor |  | Direct |  | Total |  |  | Distributor |  | Direct |  | Total |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  | $ | 69,978 |  | $ | 62,345 |  | $ | 132,323 |  |  | $ | 56,742 |  | $ | 59,936 |  | $ | 116,678 |  |
| Other |  |  | 4,015 |  |  | 4,999 |  |  | 9,014 |  |  |  | 4,493 |  |  | 5,524 |  |  | 10,017 |  |
| Total Americas |  |  | 73,993 |  |  | 67,344 |  |  | 141,337 |  |  |  | 61,235 |  |  | 65,460 |  |  | 126,695 |  |
| EMEA |  |  | 59,129 |  |  | 29,634 |  |  | 88,763 |  |  |  | 61,331 |  |  | 30,838 |  |  | 92,169 |  |
| APAC |  |  | 9,113 |  |  | 16,293 |  |  | 25,406 |  |  |  | 2,349 |  |  | 18,673 |  |  | 21,022 |  |
| Total net revenues |  | $ | 142,235 |  | $ | 113,271 |  | $ | 255,506 |  |  | $ | 124,915 |  | $ | 114,971 |  | $ | 239,886 |  |

- added (2020-01-30):
[0001564590-20-002754:note_history:42]
|  |  | Six Months Ended |  |
|  |  | December 31, 2019 |  |  | December 31, 2018 |  |
|  |  | Distributor |  | Direct |  | Total |  |  | Distributor |  | Direct |  | Total |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  | $ | 130,089 |  | $ | 123,967 |  | $ | 254,056 |  |  | $ | 100,883 |  | $ | 115,262 |  | $ | 216,145 |  |
| Other |  |  | 12,219 |  |  | 10,562 |  |  | 22,781 |  |  |  | 12,762 |  |  | 10,904 |  |  | 23,666 |  |
| Total Americas |  |  | 142,308 |  |  | 134,529 |  |  | 276,837 |  |  |  | 113,645 |  |  | 126,166 |  |  | 239,811 |  |
| EMEA |  |  | 123,846 |  |  | 73,891 |  |  | 197,737 |  |  |  | 141,207 |  |  | 63,611 |  |  | 204,818 |  |
| APAC: |  |  | 15,120 |  |  | 33,284 |  |  | 48,404 |  |  |  | 7,116 |  |  | 40,821 |  |  | 47,937 |  |
| Total net revenues |  | $ | 281,274 |  | $ | 241,704 |  | $ | 522,978 |  |  | $ | 261,968 |  | $ | 230,598 |  | $ | 492,566 |  |

- added (2020-01-30):
[0001564590-20-002754:note_history:43]
Included in the above amounts are $2.3 million and $4.7 million of leasing revenue for the three and six months ended December 31, 2019, respectively.  Included in the above amounts are $3.2 million and $5.9 million of leasing revenue for the three and six months ended December 31, 2018, respectively.

- changed (2020-01-30):
[0001564590-20-002754:note_history:44]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | December 31, 2019 |  |  | December 31, 2018 |  |  | December 31, 2019 |  |  | December 31, 2018 |  |
| Tech Data Corporation |  | 14% |  |  | 22% |  |  | 15% |  |  | 19% |  |
| Jenne Corporation |  | 18% |  |  | 12% |  |  | 16% |  |  | 12% |  |
| Westcon Group Inc. |  | 15% |  |  | 15% |  |  | 13% |  |  | 14% |  |
  (was, 2019-10-31, similarity 0.7535):
[0001564590-19-039190:note_history:44]
|  |  | Three Months Ended |  |
|  |  | September 30, 2019 |  |  | September 30, 2018 |  |
| Tech Data Corporation |  | 16% |  |  | 17% |  |
| Jenne Corporation |  | 14% |  |  | 12% |  |
| Westcon Group Inc. |  | 10% |  |  | 13% |  |

- changed (2020-01-30):
[0001564590-20-002754:note_history:45]
|  |  | December 31, 2019 |  |  | June 30, 2019 |  |
| Tech Data Corporation |  |  | 20 | % |  |  | 12 | % |
| Jenne Corporation |  |  | 23 | % |  |  | 35 | % |
  (was, 2019-10-31, similarity 0.8452):
[0001564590-19-039190:note_history:45]
|  |  | September 30, 2019 |  |  | June 30, 2019 |  |
| Tech Data Corporation |  |  | 21 | % |  |  | 12 | % |
| Jenne Corporation |  |  | 19 | % |  |  | 35 | % |
| Westcon Group Inc. |  |  | 12 | % |  | * |  |

- removed (2020-01-30):
[0001564590-19-039190:note_history:46]
Included in the above amounts is approximately $3.7 million and $4.0 million of leasing revenue for the quarters ended September 30, 2019 and 2018, respectively.


## us-gaap:RevenueRecognitionPolicyTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2020-01-30):
[0001564590-20-002754:note_history:47]
On December 31, 2019, the Company had $277.8 million of remaining performance obligations, which primarily comprised of deferred maintenance and SaaS revenue.  The Company expects to recognize approximately 42 percent of its deferred revenue as revenue in fiscal 2020, an additional 34 percent in fiscal 2021 and 24 percent of the balance thereafter.
  (was, 2019-10-31, similarity 0.9083):
[0001564590-19-039190:note_history:47]
On September 30, 2019, the Company had $273.7 million of remaining performance obligations, which primarily comprised of deferred maintenance and SaaS revenue.  The Company expects to recognize approximately 58 percent of its remaining performance obligations as revenue in fiscal 2020, an additional 24 percent in fiscal 2021 and 18 percent of the balance thereafter.

- changed (2020-01-30):
[0001564590-20-002754:note_history:48]
Revenue recognized for the three months ended December 31, 2019 and 2018 that was included in the deferred revenue balance at the beginning of each period was $67.2 million and $59.9 million, respectively. Revenue recognized for the six months ended December 31, 2019 and 2018 that was included in the deferred revenue balance at the beginning of each period was $90.9 million and $88.8 million, respectively.
  (was, 2019-10-31, similarity 0.6597):
[0001564590-19-039190:note_history:48]
Revenue recognized for the three months ended September 30, 2019 and 2018 that was included in the deferred revenue balance at the beginning of each period was $53.8 million and $50.6 million, respectively.

- changed (2020-01-30):
[0001564590-20-002754:note_history:49]
Contract Costs. The Company recognizes the incremental costs of obtaining contracts as an expense when incurred if the amortization period of the assets that the Company otherwise would have recognized is one year or less.  Management expects that commission fees paid to sales representatives as a result of obtaining service contracts and contract renewals are recoverable and therefore the Company’s condensed consolidated balance sheets included capitalized balances in the amount of $8.3 million and $6.5 million at December 31, 2019 and June 30, 2019, respectively.  Capitalized commission fees are amortized on a straight-line basis over the average period of service contracts of approximately three years, and are included in “Sales and marketing” in the accompanying condensed consolidated statements of operations. Amortization recognized during the three months ended December 31, 2019 and 2018, was $1.5 million and $0.7 million, respectively. Amortization recognized during the six months ended December 31, 2019 and 2018 was $3.0 million and $1.4 million, respectively. There was no impairment loss in relation to the costs capitalized.
  (was, 2019-10-31, similarity 0.8783):
[0001564590-19-039190:note_history:49]
Contract Costs. The Company recognizes the incremental costs of obtaining contracts as an expense when incurred if the amortization period of the assets that the Company otherwise would have recognized is one year or less.  Management expects that commission fees paid to sales representatives as a result of obtaining service contracts and contract renewals are recoverable and therefore the Company’s condensed consolidated balance sheets included capitalized balances in the amount of $7.6 million and $4.9 million at September 30, 2019 and June 30, 2018, respectively.  Capitalized commission fees are amortized on a straight-line basis over the average period of service contracts of approximately three years, and are included in “Sales and marketing” in the accompanying condensed consolidated statements of operations.  Amortization recognized during the three months ended September 30, 2019 and 2018, was $2.7 million and $0.7 million, respectively. There was no impairment loss in relation to the costs capitalized.

- changed (2020-01-30):
[0001564590-20-002754:note_history:50]
|  |  | Three Months Ended |  |
|  |  | December 31, 2019 |  |  | December 31, 2018 |  |
|  |  | Distributor |  | Direct |  | Total |  |  | Distributor |  | Direct |  | Total |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  | $ | 60,111 |  | $ | 61,622 |  | $ | 121,733 |  |  | $ | 44,141 |  | $ | 55,326 |  | $ | 99,467 |  |
| Other |  |  | 8,204 |  |  | 5,563 |  |  | 13,767 |  |  |  | 8,269 |  |  | 5,380 |  |  | 13,649 |  |
| Total Americas |  |  | 68,315 |  |  | 67,185 |  |  | 135,500 |  |  |  | 52,410 |  |  | 60,706 |  |  | 113,116 |  |
| EMEA |  |  | 64,717 |  |  | 44,257 |  |  | 108,974 |  |  |  | 79,876 |  |  | 32,773 |  |  | 112,649 |  |
| APAC |  |  | 6,007 |  |  | 16,991 |  |  | 22,998 |  |  |  | 4,767 |  |  | 22,148 |  |  | 26,915 |  |
| Total net revenues |  | $ | 139,039 |  | $ | 128,433 |  | $ | 267,472 |  |  | $ | 137,053 |  | $ | 115,627 |  | $ | 252,680 |  |
  (was, 2019-10-31, similarity 0.9889):
[0001564590-19-039190:note_history:50]
|  |  | Three Months Ended |  |
|  |  | September 30, 2019 |  |  | September 30, 2018 |  |
|  |  | Distributor |  | Direct |  | Total |  |  | Distributor |  | Direct |  | Total |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  | $ | 69,978 |  | $ | 62,345 |  | $ | 132,323 |  |  | $ | 56,742 |  | $ | 59,936 |  | $ | 116,678 |  |
| Other |  |  | 4,015 |  |  | 4,999 |  |  | 9,014 |  |  |  | 4,493 |  |  | 5,524 |  |  | 10,017 |  |
| Total Americas |  |  | 73,993 |  |  | 67,344 |  |  | 141,337 |  |  |  | 61,235 |  |  | 65,460 |  |  | 126,695 |  |
| EMEA |  |  | 59,129 |  |  | 29,634 |  |  | 88,763 |  |  |  | 61,331 |  |  | 30,838 |  |  | 92,169 |  |
| APAC |  |  | 9,113 |  |  | 16,293 |  |  | 25,406 |  |  |  | 2,349 |  |  | 18,673 |  |  | 21,022 |  |
| Total net revenues |  | $ | 142,235 |  | $ | 113,271 |  | $ | 255,506 |  |  | $ | 124,915 |  | $ | 114,971 |  | $ | 239,886 |  |

- added (2020-01-30):
[0001564590-20-002754:note_history:51]
|  |  | Six Months Ended |  |
|  |  | December 31, 2019 |  |  | December 31, 2018 |  |
|  |  | Distributor |  | Direct |  | Total |  |  | Distributor |  | Direct |  | Total |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  | $ | 130,089 |  | $ | 123,967 |  | $ | 254,056 |  |  | $ | 100,883 |  | $ | 115,262 |  | $ | 216,145 |  |
| Other |  |  | 12,219 |  |  | 10,562 |  |  | 22,781 |  |  |  | 12,762 |  |  | 10,904 |  |  | 23,666 |  |
| Total Americas |  |  | 142,308 |  |  | 134,529 |  |  | 276,837 |  |  |  | 113,645 |  |  | 126,166 |  |  | 239,811 |  |
| EMEA |  |  | 123,846 |  |  | 73,891 |  |  | 197,737 |  |  |  | 141,207 |  |  | 63,611 |  |  | 204,818 |  |
| APAC: |  |  | 15,120 |  |  | 33,284 |  |  | 48,404 |  |  |  | 7,116 |  |  | 40,821 |  |  | 47,937 |  |
| Total net revenues |  | $ | 281,274 |  | $ | 241,704 |  | $ | 522,978 |  |  | $ | 261,968 |  | $ | 230,598 |  | $ | 492,566 |  |
