# EXTR notes — 0001564590-20-002754


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0001564590-20-002754:notes:1]
[same as prior period, unchanged from 0001564590-19-039190:notes:1]

[0001564590-20-002754:notes:2]
[same as prior period, unchanged from 0001564590-19-039190:notes:2]

[0001564590-20-002754:notes:3]
The unaudited condensed consolidated financial statements of Extreme included herein have been prepared under the rules and regulations of the Securities and Exchange Commission (“SEC”).  Certain information and footnote disclosures normally included in financial statements prepared in accordance with U.S. generally accepted accounting principles have been condensed or omitted under such rules and regulations.  The condensed consolidated balance sheet at June 30, 2019 was derived from audited financial statements as of that date but does not include all disclosures required by generally accepted accounting principles for complete financial statements. These interim financial statements and notes should be read in conjunction with the Company’s audited consolidated financial statements and notes thereto included in the Company’s Annual Report on Form 10-K for the fiscal year ended June 30, 2019.

[0001564590-20-002754:notes:4]
The unaudited condensed consolidated financial statements reflect all adjustments, consisting only of normal recurring adjustments that, in the opinion of management, are necessary for a fair presentation of the results of operations and cash flows for the interim periods presented and the financial condition of Extreme at December 31, 2019. The results of operations for the three and six months ended December 31, 2019 are not necessarily indicative of the results that may be expected for fiscal 2020 or any future periods.

[0001564590-20-002754:notes:5]
[same as prior period, unchanged from 0001564590-19-039190:notes:5]

[0001564590-20-002754:notes:6]
[same as prior period, unchanged from 0001564590-19-039190:notes:6]

[0001564590-20-002754:notes:7]
[same as prior period, unchanged from 0001564590-19-039190:notes:7]

[0001564590-20-002754:notes:8]
[same as prior period, unchanged from 0001564590-19-039190:notes:8]

[0001564590-20-002754:notes:9]
[same as prior period, unchanged from 0001564590-19-039190:notes:9]

[0001564590-20-002754:notes:10]
[same as prior period, unchanged from 0001564590-19-039190:notes:10]

[0001564590-20-002754:notes:11]
[same as prior period, unchanged from 0001564590-19-039190:notes:11]


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001564590-20-002754:notes:12]
[same as prior period, unchanged from 0001564590-19-039190:notes:12]

[0001564590-20-002754:notes:13]
For a description of significant accounting policies, see Note 2, Summary of Significant Accounting Policies, to the consolidated financial statements included in the Company’s Annual Report on Form 10-K for the fiscal year ended June 30, 2019. There have been no material changes to the Company’s significant accounting policies since the filing of the Annual Report on Form 10-K, except for the adoption of the new lease guidance and related policies as discussed within these financial statements.

[0001564590-20-002754:notes:14]
Recently Adopted Accounting Pronouncements

[0001564590-20-002754:notes:15]
In February 2016, the Financial Accounting Standards Board (“FASB”) issued ASU No. 2016-02, Leases (Topic 842), which requires the identification of arrangements that should be accounted for as leases by lessees and lessors, and key disclosure information about leasing arrangements. In general, for lease arrangements exceeding a twelve-month term, these arrangements are recognized as assets and liabilities on the balance sheet of the lessee. Under Topic 842, a right-of-use asset (“ROU”) and lease obligation are recorded for all leases, whether operating or financing, while the statement of operations will reflect lease expense for operating leases and amortization/interest expense for financing leases. The balance sheet amount recorded for existing leases at the date of adoption of Topic 842 is calculated using the applicable incremental borrowing rate at the date of adoption. Topic 842 also requires lessors to classify leases as a sales-type, direct financing or operating lease.  A lease is a sales-type lease if any one of five criteria are met, each of which indicate that the lease, in effect, transfers control of the underlying asset to the lessee. If none of those five criteria are met, but two additional criteria are both met, indicating that the lessor has transferred substantially all of the risks and benefits to the lessee and a third party, the lease is a direct financing lease.  All leases that are not sales-type or direct financing leases are operating leases. Substantially all of the Company’s leases continue to be classified as operating leases. In addition, Topic 842 was subsequently amended by ASU No 2018-10, Codification Improvements; ASU 2018-11, Targeted Improvements; ASU 2018-20 Narrow Scope Improvements; and ASU 2019-01 Codification Improvements.

[0001564590-20-002754:notes:16]
[same as prior period, unchanged from 0001564590-19-039190:notes:16]

[0001564590-20-002754:notes:17]
The new standard provides a number of optional practical expedients in transition. The Company elected the “package of practical expedients” which permitted the Company not to reassess under the new standard its prior conclusions about lease identification, lease classification, and initial direct costs. The new standard also provided practical expedients for ongoing accounting. The Company also elected the short-term lease recognition exemption for all leases that qualified. For those leases that qualified, existing short-term leases at the transition date and those entered into subsequent to the transition date, the Company did not recognize right-of-use assets or lease liabilities. In addition, the Company elected the practical expedient not to separate lease and non-lease components for leases except for the logistic services asset class and certain revenue subscription contracts where the Company leases its hardware products and provides maintenance and support over a service period which is recognized under ASC Topic 606. See Note 9, Leases, for additional information regarding the Company’s leases.

[0001564590-20-002754:notes:18]
On July 1, 2019, the Company recognized ROU assets of approximately $64.6 million and corresponding lease liabilities of $79.5 million on the condensed consolidated balance sheets, which was based on the present value of the remaining minimum rental payments under current leasing standards for existing operating leases.

[0001564590-20-002754:notes:19]
In August 2017, the FASB issued ASU 2017-12, Derivatives and Hedging (Topic 815): Targeted Improvements to Accounting for Hedging Activities, which is intended to allow companies to better align risk management activities and financial reporting for hedging relationships through changes to both the designation and measurement guidance for qualifying hedging relationships and the presentation of hedge results by expanding and refining hedge accounting for both nonfinancial and financial risk components and aligning the recognition and presentation of the effects of the hedging instrument and the hedged item in the financial statements. In addition, in October 2018, the FASB issued ASU 2018-16, Derivatives and Hedging (Topic 815), which amends Topic 815 to add the overnight index swap (OIS) rate based on the secured overnight financing rate as a fifth U.S. benchmark interest rate. In addition, Topic 815 was subsequently amended by ASU 2019-04, Codification Improvements. These standards are effective for interim and annual reporting periods beginning after December 15, 2018. This guidance was effective for the Company beginning with its fiscal year 2020. It did not have a material impact on the Company’s financial statements upon adoption.

[0001564590-20-002754:notes:20]
In February 2018, the FASB issued ASU 2018-02, Income Statement - Reporting Comprehensive Income (Topic 220), this standard that allows the reclassification from AOCI to retained earnings for stranded tax effects resulting from the 2017 Tax Cuts and Jobs Act ("Tax Reform Act"). The amount of the reclassification is the effect of the change in the U.S. federal corporate income tax rate on the gross deferred tax amounts and related valuation allowances related to items remaining in AOCI. This standard is effective for fiscal years beginning after December 15, 2018, and interim periods within those fiscal years.  The new standard is to be applied either in the period of adoption or retrospectively to each period (or periods) in which the effects of the change in the income tax rate in the Tax Reform Act are recognized. The standard was adopted on July 1, 2019 and did not have a material impact on the Company’s financial statements upon adoption.

[0001564590-20-002754:notes:21]
Recently Issued Accounting Pronouncements

[0001564590-20-002754:notes:22]
In June 2016, the FASB issued ASU 2016-13, Financial Instruments—Credit Losses (Topic 326). The standard changes the methodology for measuring credit losses on financial instruments and the timing of when such losses are recorded. It replaces the existing incurred loss impairment model with an expected loss model. It also requires credit losses related to available-for-sale debt securities to be recognized as an allowance for credit losses rather than as a reduction to the carrying value of the securities. ASU 2016-13 is effective for fiscal years beginning after December 15, 2020. The Company is currently evaluating the impact of this new standard on its condensed consolidated financial statements and related disclosures. The Company currently plans to adopt this standard beginning with its fiscal year 2021, beginning on July 1, 2020.

[0001564590-20-002754:notes:23]
In January 2017, the FASB issued ASU 2017-04, Simplifying the Test for Goodwill Impairment (Topic 350), which removes Step 2 of the goodwill impairment test, which requires a hypothetical purchase price allocation. An impairment charge will now be the amount by which a reporting unit’s carrying value exceeds the fair value, not to exceed the carrying amount of goodwill.  This standard is effective for fiscal years beginning after December 15, 2019, with early adoption permitted The Company does not expect the adoption to have a material impact on the condensed consolidated financial statements. The Company currently plans to adopt this standard beginning with its fiscal year 2021, beginning on July 1, 2020.

[0001564590-20-002754:notes:24]
In August 2018, the FASB issued ASU 2018-13, Fair Value Measurement (Topic 820), which removes, modifies and adds various disclosure requirements around the topic in order to clarify and improve the cost-benefit nature of disclosures. For example, disclosures around transfers between fair value hierarchy levels will be removed and further detail around changes in unrealized gains and losses for the period and unobservable inputs determining Level 3 fair value measurements will be added. This standard is effective for interim and annual reporting periods beginning after December 15, 2019, and early adoption is permitted. The Company is currently evaluating the impact the new standard will have on its condensed consolidated financial statements. This guidance is effective for the Company beginning with its fiscal year 2021, beginning on July 1, 2020.

[0001564590-20-002754:notes:25]
In August 2018, the FASB issued ASU 2018-15, Intangibles - Goodwill and Other - Internal-Use Software (Subtopic 350-40), which aligns the requirements for capitalizing implementation costs incurred in a service contract hosting arrangement with those of developing or obtaining internal-use software. This standard is effective for interim and annual reporting periods beginning after December 15, 2019, and early adoption is permitted. The Company is currently evaluating the impact the new standard will have on its condensed consolidated financial statements. This guidance is effective for the Company beginning with its fiscal year 2021, beginning on July 1, 2020.

[0001564590-20-002754:notes:26]
In December 2019, the FASB issued ASU 2019-12, Income taxes – Simplifying the Accounting for Income taxes (Topic 740), which reduces the complexity of accounting for income taxes including the removal of certain exceptions to the general principles of ASC 740, Income taxes, and simplification in several other areas such as accounting for franchise tax (or similar tax) that is partially based on income. This standard is effective for interim and annual reporting periods beginning after December 15, 2020, and early adoption is permitted. The Company is currently evaluating the impact the new standard will have on its condensed consolidated financial statements. This guidance is effective for the Company beginning with its fiscal year 2022, beginning on July 1, 2021.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001564590-20-002754:notes:27]
[same as prior period, unchanged from 0001564590-19-039190:notes:26]

[0001564590-20-002754:notes:28]
The Company accounts for revenue in accordance with ASU 2014-09, Revenue from Contracts from Customers (Topic 606), which the Company adopted on July 1, 2017, using the retrospective method.  The Company derives the majority of its revenue from sales of its networking equipment, with the remaining revenue generated from software delivered as a service (“SaaS”) and service fees primarily relating to maintenance contracts with additional revenues from professional services, and training for its products. The Company sells its products and maintenance contracts direct to customers and to partners in two distribution channels, or tiers. The first tier consists of a limited number of independent distributors that stock its products and sell primarily to resellers.  The second tier of the distribution channel consists of non-stocking distributors and value-added resellers that sell directly to end-users.  Products and services may be sold separately or in bundled packages.

[0001564590-20-002754:notes:29]
[same as prior period, unchanged from 0001564590-19-039190:notes:28]

[0001564590-20-002754:notes:30]
[same as prior period, unchanged from 0001564590-19-039190:notes:29]

[0001564590-20-002754:notes:31]
[same as prior period, unchanged from 0001564590-19-039190:notes:30]

[0001564590-20-002754:notes:32]
On December 31, 2019, the Company had $277.8 million of remaining performance obligations, which primarily comprised of deferred maintenance and SaaS revenue.  The Company expects to recognize approximately 42 percent of its deferred revenue as revenue in fiscal 2020, an additional 34 percent in fiscal 2021 and 24 percent of the balance thereafter.

[0001564590-20-002754:notes:33]
[same as prior period, unchanged from 0001564590-19-039190:notes:32]

[0001564590-20-002754:notes:34]
Revenue recognized for the three months ended December 31, 2019 and 2018 that was included in the deferred revenue balance at the beginning of each period was $67.2 million and $59.9 million, respectively. Revenue recognized for the six months ended December 31, 2019 and 2018 that was included in the deferred revenue balance at the beginning of each period was $90.9 million and $88.8 million, respectively.

[0001564590-20-002754:notes:35]
Contract Costs. The Company recognizes the incremental costs of obtaining contracts as an expense when incurred if the amortization period of the assets that the Company otherwise would have recognized is one year or less.  Management expects that commission fees paid to sales representatives as a result of obtaining service contracts and contract renewals are recoverable and therefore the Company’s condensed consolidated balance sheets included capitalized balances in the amount of $8.3 million and $6.5 million at December 31, 2019 and June 30, 2019, respectively.  Capitalized commission fees are amortized on a straight-line basis over the average period of service contracts of approximately three years, and are included in “Sales and marketing” in the accompanying condensed consolidated statements of operations. Amortization recognized during the three months ended December 31, 2019 and 2018, was $1.5 million and $0.7 million, respectively. Amortization recognized during the six months ended December 31, 2019 and 2018 was $3.0 million and $1.4 million, respectively. There was no impairment loss in relation to the costs capitalized.

[0001564590-20-002754:notes:36]
[same as prior period, unchanged from 0001564590-19-039190:notes:35]

[0001564590-20-002754:notes:37]
[same as prior period, unchanged from 0001564590-19-039190:notes:36]

[0001564590-20-002754:notes:38]
[same as prior period, unchanged from 0001564590-19-039190:notes:37]

[0001564590-20-002754:notes:39]
|  |  | Three Months Ended |  |
|  |  | December 31, 2019 |  |  | December 31, 2018 |  |
|  |  | Distributor |  | Direct |  | Total |  |  | Distributor |  | Direct |  | Total |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  | $ | 60,111 |  | $ | 61,622 |  | $ | 121,733 |  |  | $ | 44,141 |  | $ | 55,326 |  | $ | 99,467 |  |
| Other |  |  | 8,204 |  |  | 5,563 |  |  | 13,767 |  |  |  | 8,269 |  |  | 5,380 |  |  | 13,649 |  |
| Total Americas |  |  | 68,315 |  |  | 67,185 |  |  | 135,500 |  |  |  | 52,410 |  |  | 60,706 |  |  | 113,116 |  |
| EMEA |  |  | 64,717 |  |  | 44,257 |  |  | 108,974 |  |  |  | 79,876 |  |  | 32,773 |  |  | 112,649 |  |
| APAC |  |  | 6,007 |  |  | 16,991 |  |  | 22,998 |  |  |  | 4,767 |  |  | 22,148 |  |  | 26,915 |  |
| Total net revenues |  | $ | 139,039 |  | $ | 128,433 |  | $ | 267,472 |  |  | $ | 137,053 |  | $ | 115,627 |  | $ | 252,680 |  |

[0001564590-20-002754:notes:40]
|  |  | Six Months Ended |  |
|  |  | December 31, 2019 |  |  | December 31, 2018 |  |
|  |  | Distributor |  | Direct |  | Total |  |  | Distributor |  | Direct |  | Total |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  | $ | 130,089 |  | $ | 123,967 |  | $ | 254,056 |  |  | $ | 100,883 |  | $ | 115,262 |  | $ | 216,145 |  |
| Other |  |  | 12,219 |  |  | 10,562 |  |  | 22,781 |  |  |  | 12,762 |  |  | 10,904 |  |  | 23,666 |  |
| Total Americas |  |  | 142,308 |  |  | 134,529 |  |  | 276,837 |  |  |  | 113,645 |  |  | 126,166 |  |  | 239,811 |  |
| EMEA |  |  | 123,846 |  |  | 73,891 |  |  | 197,737 |  |  |  | 141,207 |  |  | 63,611 |  |  | 204,818 |  |
| APAC: |  |  | 15,120 |  |  | 33,284 |  |  | 48,404 |  |  |  | 7,116 |  |  | 40,821 |  |  | 47,937 |  |
| Total net revenues |  | $ | 281,274 |  | $ | 241,704 |  | $ | 522,978 |  |  | $ | 261,968 |  | $ | 230,598 |  | $ | 492,566 |  |

[0001564590-20-002754:notes:41]
Included in the above amounts are $2.3 million and $4.7 million of leasing revenue for the three and six months ended December 31, 2019, respectively.  Included in the above amounts are $3.2 million and $5.9 million of leasing revenue for the three and six months ended December 31, 2018, respectively.

[0001564590-20-002754:notes:42]
[same as prior period, unchanged from 0001564590-19-039190:notes:40]

[0001564590-20-002754:notes:43]
[same as prior period, unchanged from 0001564590-19-039190:notes:41]

[0001564590-20-002754:notes:44]
[same as prior period, unchanged from 0001564590-19-039190:notes:42]

[0001564590-20-002754:notes:45]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | December 31, 2019 |  |  | December 31, 2018 |  |  | December 31, 2019 |  |  | December 31, 2018 |  |
| Tech Data Corporation |  | 14% |  |  | 22% |  |  | 15% |  |  | 19% |  |
| Jenne Corporation |  | 18% |  |  | 12% |  |  | 16% |  |  | 12% |  |
| Westcon Group Inc. |  | 15% |  |  | 15% |  |  | 13% |  |  | 14% |  |

[0001564590-20-002754:notes:46]
[same as prior period, unchanged from 0001564590-19-039190:notes:44]

[0001564590-20-002754:notes:47]
|  |  | December 31, 2019 |  |  | June 30, 2019 |  |
| Tech Data Corporation |  |  | 20 | % |  |  | 12 | % |
| Jenne Corporation |  |  | 23 | % |  |  | 35 | % |


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001564590-20-002754:notes:48]
[same as prior period, unchanged from 0001564590-19-039190:notes:46]

[0001564590-20-002754:notes:49]
[same as prior period, unchanged from 0001564590-19-039190:notes:47]

[0001564590-20-002754:notes:50]
[same as prior period, unchanged from 0001564590-19-039190:notes:48]

[0001564590-20-002754:notes:51]
The Acquisition was accounted for using the acquisition method of accounting whereby the acquired assets and liabilities of Aerohive have been recorded at their respective fair values and added to those of the Company including an amount for goodwill calculated as the difference between the acquisition consideration and the fair value of the identifiable net assets.  The purchase price was preliminarily allocated to tangible and identifiable intangible assets acquired and liabilities assumed. The final purchase price allocation is pending the finalization of valuations including intangible assets, goodwill and income tax assets and liabilities that are not able to be finalized yet, which may result in an adjustment to the preliminary purchase price allocation.

[0001564590-20-002754:notes:52]
The estimated fair values were determined through established and generally accepted valuation techniques, including work performed by third-party valuation specialists. The fair value of working capital related items, such as other current assets and accrued liabilities, approximated their book values at the Acquisition Date.  Inventories were valued at fair value using the net realizable value approach. The fair value of the acquired deferred revenue was estimated using the cost build-up approach.  The cost build-up approach determines fair value using estimates of the costs required to provide the contracted deliverables plus an assumed profit. The total costs including the assumed profit were adjusted to present value using a discount rate considered appropriate.  The resulting fair value approximates the amount the Company would be required to pay to a third party to assume the obligation.  Valuations of the intangible assets were valued using income approaches based on management projections, which the Company considers to be Level 3 inputs. The Company also continues to analyze the tax implications of the Acquisition and the intangible assets which may ultimately

[0001564590-20-002754:notes:53]
impact the overall level of goodwill associated with the acquisition.  Results of operations of Aerohive have been included in the operations of the Company beginning with the Acquisition Date.

[0001564590-20-002754:notes:54]
[same as prior period, unchanged from 0001564590-19-039190:notes:51]

[0001564590-20-002754:notes:55]
[same as prior period, unchanged from 0001564590-19-039190:notes:52]

[0001564590-20-002754:notes:56]
[same as prior period, unchanged from 0001564590-19-039190:notes:53]

[0001564590-20-002754:notes:57]
|  | Preliminary Allocation as of August 9, 2019 |  |  | Adjustments |  |  |  |  | Allocation as of December 31, 2019 |  |
| Cash and cash equivalents | $ | 44,158 |  |  | $ | — |  |  |  |  | $ | 44,158 |  |
| Short-term investments |  | 45,148 |  |  |  | — |  |  |  |  |  | 45,148 |  |
| Accounts receivable, net |  | 11,753 |  |  |  | — |  |  |  |  |  | 11,753 |  |
| Inventories |  | 16,698 |  |  |  | 2,534 |  |  | a |  |  | 19,232 |  |
| Prepaid expenses and other current assets |  | 3,980 |  |  |  | (56 | ) |  | b |  |  | 3,924 |  |
| Property and equipment |  | 2,185 |  |  |  | 179 |  |  | c |  |  | 2,364 |  |
| Operating lease right-of-use assets |  | 6,336 |  |  |  | — |  |  |  |  |  | 6,336 |  |
| Other assets |  | 2,195 |  |  |  | — |  |  |  |  |  | 2,195 |  |
| Debt |  | (20,000 | ) |  |  | — |  |  |  |  |  | (20,000 | ) |
| Accounts payable |  | (9,737 | ) |  |  | — |  |  |  |  |  | (9,737 | ) |
| Accrued compensation and benefits |  | (7,129 | ) |  |  | — |  |  |  |  |  | (7,129 | ) |
| Accrued warranty |  | (570 | ) |  |  | — |  |  |  |  |  | (570 | ) |
| Other accrued liabilities |  | (1,960 | ) |  |  | — |  |  |  |  |  | (1,960 | ) |
| Operating lease liabilities |  | (4,752 | ) |  |  | — |  |  |  |  |  | (4,752 | ) |
| Deferred revenue |  | (68,415 | ) |  |  | — |  |  |  |  |  | (68,415 | ) |
| Other liabilities |  | (408 | ) |  |  | — |  |  |  |  |  | (408 | ) |
| Net tangible assets |  | 19,482 |  |  |  | 2,657 |  |  |  |  |  | 22,139 |  |
| Identifiable intangible assets |  | 53,400 |  |  |  | — |  |  |  |  |  | 53,400 |  |
| Goodwill |  | 194,264 |  |  |  | (2,657 | ) |  | a,b,c |  |  | 191,607 |  |
| Total intangible assets acquired |  | 247,664 |  |  |  | (2,657 | ) |  |  |  |  | 245,007 |  |
| Total net assets acquired | $ | 267,146 |  |  | $ | - |  |  |  |  | $ | 267,146 |  |

[0001564590-20-002754:notes:58]
The changes during the period in the table above include: a) adjustment of the fair value of inventories acquired, b) write-off of an asset with no future economic value as of the Acquisition Date, c) adjustment to the value of property and equipment as of the Acquisition Date at an international location.

[0001564590-20-002754:notes:59]
The following table presents details of the identifiable intangible assets acquired as part of the Acquisition (dollars in thousands):

[0001564590-20-002754:notes:60]
| Intangible Assets |  | Estimated Useful Life (in years) |  |  | Amount |  |
| Developed technology |  |  | 4 |  |  | $ | 40,000 |  |
| Backlog |  |  | 1 |  |  |  | 400 |  |
| Customer relationships |  |  | 7 |  |  |  | 11,400 |  |
| Trade names |  |  | 1 |  |  |  | 1,600 |  |
| Total identifiable intangible assets |  |  |  |  |  | $ | 53,400 |  |

[0001564590-20-002754:notes:61]
[same as prior period, unchanged from 0001564590-19-039190:notes:57]

[0001564590-20-002754:notes:62]
The results of operations of Aerohive are included in the accompanying condensed consolidated results of operations beginning August 9, 2019.  The Aerohive revenue for the three and six months ended December 31, 2019 was $41.9 million and $67.3 million, respectively, and was incorporated into the revenue of the Company.  Certain associated expenses of Aerohive were incorporated with the results of operations of the Company and, therefore, stand-alone operating results are not available.

[0001564590-20-002754:notes:63]
In the three and six months ended December 31, 2019, the Company incurred acquisition and integration related expenses of $9.0 million and $24.9 million, respectively, associated with the Acquisition.  In the quarter ended September 30, 2019, this included a $6.8 million compensation charge for certain Aerohive Executive stock awards which were accelerated due to change-in-control and termination provisions included in the Executives’ employment contracts.  Other acquisition and integration costs consist primarily of professional fees for financial and legal advisory services and severance charges for terminated Aerohive employees.  Such acquisition-related costs were expensed as incurred and are included in “Acquisition and integration costs” in the accompanying condensed consolidated statements of operations.

[0001564590-20-002754:notes:64]
[same as prior period, unchanged from 0001564590-19-039190:notes:60]

[0001564590-20-002754:notes:65]
The following unaudited pro forma results of operations are presented as though the Acquisition had occurred as of July 1, 2018, the beginning of fiscal 2019, after giving effect to purchase accounting adjustments relating to inventories, deferred revenue, depreciation and amortization of intangibles, acquisition and integration costs, interest income and expense and related tax effects.

[0001564590-20-002754:notes:66]
[same as prior period, unchanged from 0001564590-19-039190:notes:62]

[0001564590-20-002754:notes:67]
The unaudited pro forma financial information for the three and six months ended December 31, 2019 combines the historical results for Extreme for the period, which include the results of Aerohive subsequent to the Acquisition Date, and Aerohive’s historical results up to the Acquisition Date.

[0001564590-20-002754:notes:68]
Pro forma results of operations for the three and six months ended December 31, 2018 combines the historical results of operations for Extreme and for Aerohive.

[0001564590-20-002754:notes:69]
[same as prior period, unchanged from 0001564590-19-039190:notes:65]

[0001564590-20-002754:notes:70]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | December 31, 2019 |  |  | December 31, 2018 |  |  | December 31, 2019 |  |  | December 31, 2018 |  |
| Net revenues |  | $ | 268,367 |  |  | $ | 288,873 |  |  | $ | 536,045 |  |  | $ | 568,107 |  |
| Net loss |  | $ | (5,031 | ) |  | $ | (20,694 | ) |  | $ | (28,847 | ) |  | $ | (59,779 | ) |
| Net loss per share - basic and diluted |  | $ | (0.04 | ) |  | $ | (0.18 | ) |  | $ | (0.24 | ) |  | $ | (0.51 | ) |
| Shares used in per share calculation - basic and diluted |  |  | 119,555 |  |  |  | 117,544 |  |  |  | 119,891 |  |  |  | 117,456 |  |


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001564590-20-002754:notes:71]
[same as prior period, unchanged from 0001564590-19-039190:notes:67]

[0001564590-20-002754:notes:72]
[same as prior period, unchanged from 0001564590-19-039190:notes:71]

[0001564590-20-002754:notes:73]
[same as prior period, unchanged from 0001564590-19-039190:notes:72]

[0001564590-20-002754:notes:74]
[same as prior period, unchanged from 0001564590-19-039190:notes:73]

[0001564590-20-002754:notes:75]
|  |  | December 31, 2019 |  |  | June 30, 2019 |  |
| Finished goods |  | $ | 62,116 |  |  | $ | 49,492 |  |
| Raw materials |  |  | 17,548 |  |  |  | 14,097 |  |
| Total Inventories |  | $ | 79,664 |  |  | $ | 63,589 |  |

[0001564590-20-002754:notes:76]
[same as prior period, unchanged from 0001564590-19-039190:notes:75]

[0001564590-20-002754:notes:77]
[same as prior period, unchanged from 0001564590-19-039190:notes:76]

[0001564590-20-002754:notes:78]
|  |  | December 31, 2019 |  |  | June 30, 2019 |  |
| Computers and equipment |  | $ | 74,694 |  |  | $ | 72,309 |  |
| Purchased software |  |  | 32,199 |  |  |  | 29,126 |  |
| Office equipment, furniture and fixtures |  |  | 11,453 |  |  |  | 10,815 |  |
| Leasehold improvements |  |  | 52,499 |  |  |  | 51,245 |  |
| Total property and equipment |  |  | 170,845 |  |  |  | 163,495 |  |
| Less: accumulated depreciation and amortization |  |  | (102,907 | ) |  |  | (89,941 | ) |
| Property and equipment, net |  | $ | 67,938 |  |  | $ | 73,554 |  |

[0001564590-20-002754:notes:79]
[same as prior period, unchanged from 0001564590-19-039190:notes:78]

[0001564590-20-002754:notes:80]
[same as prior period, unchanged from 0001564590-19-039190:notes:79]

[0001564590-20-002754:notes:81]
[same as prior period, unchanged from 0001564590-19-039190:notes:80]

[0001564590-20-002754:notes:82]
[same as prior period, unchanged from 0001564590-19-039190:notes:81]

[0001564590-20-002754:notes:83]
The following table summarizes the activity related to the Company’s product warranty liability during the three and six months ended December 31, 2019 and 2018 (in thousands):

[0001564590-20-002754:notes:84]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | December 31, 2019 |  |  | December 31, 2018 |  |  | December 31, 2019 |  |  | December 31, 2018 |  |
| Balance beginning of period |  | $ | 15,988 |  |  | $ | 12,601 |  |  | $ | 14,779 |  |  | $ | 12,807 |  |
| Warranties assumed due to acquisitions |  |  | — |  |  |  | — |  |  |  | 570 |  |  |  | — |  |
| New warranties issued |  |  | 5,539 |  |  |  | 4,145 |  |  |  | 11,461 |  |  |  | 7,867 |  |
| Warranty expenditures |  |  | (5,318 | ) |  |  | (3,938 | ) |  |  | (10,601 | ) |  |  | (7,866 | ) |
| Balance end of period |  | $ | 16,209 |  |  | $ | 12,808 |  |  | $ | 16,209 |  |  | $ | 12,808 |  |

[0001564590-20-002754:notes:85]
[same as prior period, unchanged from 0001564590-19-039190:notes:84]

[0001564590-20-002754:notes:86]
[same as prior period, unchanged from 0001564590-19-039190:notes:85]

[0001564590-20-002754:notes:87]
[same as prior period, unchanged from 0001564590-19-039190:notes:86]

[0001564590-20-002754:notes:88]
|  |  | December 31, 2019 |  |  | June 30, 2019 |  |
| Acquisition related deferred payments, less current portion |  | $ | 7,741 |  |  | $ | 9,604 |  |
| Contingent consideration obligations, less current portion |  |  | 930 |  |  |  | 2,688 |  |
| Other contractual obligations, less current portion |  |  | 22,529 |  |  |  | 26,261 |  |
| Other |  |  | 3,039 |  |  |  | 15,597 |  |
| Total other long-term liabilities |  | $ | 34,239 |  |  | $ | 54,150 |  |

[0001564590-20-002754:notes:89]
[same as prior period, unchanged from 0001564590-19-039190:notes:88]

[0001564590-20-002754:notes:90]
[same as prior period, unchanged from 0001564590-19-039190:notes:89]


## us-gaap:FairValueDisclosuresTextBlock

[0001564590-20-002754:notes:91]
[same as prior period, unchanged from 0001564590-19-039190:notes:90]

[0001564590-20-002754:notes:92]
[same as prior period, unchanged from 0001564590-19-039190:notes:91]

[0001564590-20-002754:notes:93]
[same as prior period, unchanged from 0001564590-19-039190:notes:92]

[0001564590-20-002754:notes:94]
[same as prior period, unchanged from 0001564590-19-039190:notes:93]

[0001564590-20-002754:notes:95]
[same as prior period, unchanged from 0001564590-19-039190:notes:94]

[0001564590-20-002754:notes:96]
The Company had one fair value item at December 31, 2019 and June 30, 2019, a level 3 acquisition-related contingent consideration obligation $4.2 million and $6.3 million, respectively.

[0001564590-20-002754:notes:97]
Level 1 and 2 assets and liabilities:

[0001564590-20-002754:notes:98]
The Company has no Level 1 or Level 2 assets or liabilities at December 31, 2019 or June 30, 2019. There were no transfers of assets or liabilities between levels for the periods presented. The fair value of the borrowings under the 2019 Credit Agreement is estimated based on valuations provided by alternative pricing sources supported by observable inputs which is considered Level 2.  Due to the recent establishment of the Credit Agreement, the fair value approximates the face amount of the Company’s indebtedness of $375.3 million and $180.5 million as of December 31, 2019, and June 30, 2019, respectively.

[0001564590-20-002754:notes:99]
[same as prior period, unchanged from 0001564590-19-039190:notes:104]

[0001564590-20-002754:notes:100]
At December 31, 2019 and June 30, 2019, the Company reflected one liability measured at fair value of $4.2 million and $6.3 million, respectively, for contingent consideration related to a certain acquisition completed in fiscal 2018. The fair value measurement of the contingent consideration obligation is determined using Level 3 inputs. These fair value measurements represent Level 3 measurements as they are based on significant inputs not observable in the market. Significant judgment is employed in determining the appropriateness of these assumptions as of the acquisition date and for each subsequent period.  Accordingly, changes in assumptions could have a material impact on the amount of contingent consideration expense the Company records in any given period.  Changes in the value of the contingent consideration obligations is recorded in general and administrative expenses in the accompanying condensed consolidated statements of operations.

[0001564590-20-002754:notes:101]
[same as prior period, unchanged from 0001564590-19-039190:notes:106]

[0001564590-20-002754:notes:102]
|  |  | Six Months Ended |  |
|  |  | December 31, 2019 |  |
| Beginning balance |  |  | 6,298 |  |
| Payments |  |  | (2,206 | ) |
| Accretion on discount |  |  | 60 |  |
| Ending balance |  | $ | 4,152 |  |

[0001564590-20-002754:notes:103]
There were no transfers of assets or liabilities between Level 2 and Level 3 during the three and six months ended December 31, 2019, or 2018. There were no impairments recorded for the three and six months ended December 31, 2019, or 2018.

[0001564590-20-002754:notes:104]
The Company determines the basis of the cost of a security sold or the amount reclassified out of accumulated other comprehensive income into earnings using the specific identification method. Realized gains or losses recognized on the sale of investment securities were not significant for the three and six months ended December 31, 2019 or for the three and six months ended December 31, 2018.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001564590-20-002754:notes:105]
[same as prior period, unchanged from 0001564590-19-039190:notes:111]

[0001564590-20-002754:notes:106]
[same as prior period, unchanged from 0001564590-19-039190:notes:112]

[0001564590-20-002754:notes:107]
|  |  | December 31, 2019 |  |
| Balance as of June 30, 2019 |  | $ | 138,577 |  |
| Additions due to acquisition (see Note 4) |  |  | 191,607 |  |
| Balance at end of period |  | $ | 330,184 |  |

[0001564590-20-002754:notes:108]
[same as prior period, unchanged from 0001564590-19-039190:notes:114]

[0001564590-20-002754:notes:109]
|  |  | Weighted Average |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Remaining Amortization |  | Gross Carrying |  |  | Accumulated |  |  | Net Carrying |  |
|  |  | Period |  | Amount |  |  | Amortization |  |  | Amount |  |
| December 31, 2019 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Developed technology |  | 2.8 years |  | $ | 157,000 |  |  | $ | 90,673 |  |  | $ | 66,327 |  |
| Customer relationships |  | 4.9 years |  |  | 63,039 |  |  |  | 46,965 |  |  |  | 16,074 |  |
| Backlog |  | — years |  |  | 400 |  |  |  | 400 |  |  |  | — |  |
| Trade names |  | 1.6 years |  |  | 10,700 |  |  |  | 7,034 |  |  |  | 3,666 |  |
| License agreements |  | 5.5 years |  |  | 2,445 |  |  |  | 1,796 |  |  |  | 649 |  |
| Other intangibles |  | 0.1 years |  |  | 1,382 |  |  |  | 1,358 |  |  |  | 24 |  |
| Total intangibles, net |  |  |  | $ | 234,966 |  |  | $ | 148,226 |  |  | $ | 86,740 |  |

[0001564590-20-002754:notes:110]
[same as prior period, unchanged from 0001564590-19-039190:notes:116]

[0001564590-20-002754:notes:111]
[same as prior period, unchanged from 0001564590-19-039190:notes:117]

[0001564590-20-002754:notes:112]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | December 31, 2019 |  |  | December 31, 2018 |  |  | December 31, 2019 |  |  | December 31, 2018 |  |
| Amortization in “Cost of revenues: Product” |  | $ | 6,970 |  |  | $ | 4,904 |  |  | $ | 13,465 |  |  | $ | 9,836 |  |
| Amortization of intangibles in "Operations" |  |  | 2,377 |  |  |  | 1,575 |  |  |  | 4,307 |  |  |  | 3,716 |  |
| Total amortization |  | $ | 9,347 |  |  | $ | 6,479 |  |  | $ | 17,772 |  |  | $ | 13,552 |  |

[0001564590-20-002754:notes:113]
[same as prior period, unchanged from 0001564590-19-039190:notes:119]


## us-gaap:DebtDisclosureTextBlock

[0001564590-20-002754:notes:114]
| 8. | Debt |

[0001564590-20-002754:notes:115]
The Company’s debt is comprised of the following (in thousands):

[0001564590-20-002754:notes:116]
|  |  | December 31, 2019 |  |  | June 30, 2019 |  |
| Current portion of long-term debt: |  |  |  |  |  |  |  |  |
| Term Loan |  | $ | 19,000 |  |  | $ | 9,500 |  |
| Less: unamortized debt issuance costs |  |  | (2,186 | ) |  |  | (489 | ) |
| Current portion of long-term debt |  | $ | 16,814 |  |  | $ | 9,011 |  |
| Long-term debt, less current portion: |  |  |  |  |  |  |  |  |
| Term Loan |  | $ | 356,250 |  |  | $ | 171,000 |  |
| Less: unamortized debt issuance costs |  |  | (7,334 | ) |  |  | (1,261 | ) |
| Total long-term debt, less current portion |  |  | 348,916 |  |  |  | 169,739 |  |
| Total debt |  | $ | 365,730 |  |  | $ | 178,750 |  |

[0001564590-20-002754:notes:117]
In connection with the Acquisition as discussed in Note 4, on August 9, 2019, the Company entered into an Amended and Restated Credit Agreement (the “2019 Credit Agreement”), by and among the Company, as borrower, several banks and other financial institutions as Lenders, BMO Harris Bank N.A., as an issuing lender and swingline lender, Silicon Valley Bank, as an Issuing Lender, and Bank of Montreal, as administrative agent and collateral agent for the Lenders.

[0001564590-20-002754:notes:118]
The 2019 Credit Agreement provides for a 5-year first lien term loan facility in an aggregate principal amount of $380 million (the “2019 Term Loan”) and a 5-year revolving loan facility in an aggregate principal amount of $75 million (the “2019 Revolving Facility”).  In addition, the Company may request incremental term loans and/or incremental revolving loan commitments in an aggregate amount not to exceed the sum of $100 million plus an unlimited amount that is subject to pro forma compliance with certain financial tests. On August 9, 2019, the Company used the proceeds to partially fund the Acquisition and for working capital and general corporate purposes.

[0001564590-20-002754:notes:119]
At the Company’s election, the initial term loan (the “Initial Term Loan”) under the 2019 Credit Agreement may be made as either base rate loans or Eurodollar loans. The applicable margin for base rate loans ranges from 0.25% to 2.50% per annum and the applicable margin for Eurodollar loans ranges from 1.25% to 3.50%, in each case based on Extreme’s consolidated leverage ratio. All Eurodollar loans are subject to a Base Rate of 0.00%. In addition, the Company is required to pay a commitment fee of between 0.25% and 0.40% quarterly (currently 0.35%) on the unused portion of the 2019 Revolving Facility, also based on the Company’s consolidated leverage ratio.  Principal installments are payable on the new term loan in varying percentages quarterly starting December 31, 2019 and to the extent not previously paid, all outstanding balances are to be paid at maturity.  The 2019 Credit Agreement is secured by substantially all of the Company’s assets.

[0001564590-20-002754:notes:120]
The 2019 Credit Agreement requires the Company to maintain certain minimum financial ratios at the end of each fiscal quarter. The 2019 Credit Agreement also includes covenants and restrictions that limit, among other things, the Company’s ability to incur additional indebtedness, create liens upon any of its property, merge, consolidate or sell all or substantially all of its assets. The 2019 Credit Agreement also includes customary events of default which may result in acceleration of the outstanding balance.

[0001564590-20-002754:notes:121]
Financing costs incurred in connection with obtaining long-term financing are deferred and amortized over the term of the related indebtedness or credit agreement.  The Company incurred $10.5 million of deferred financing costs in conjunction which this modification of the debt and continues to amortize $1.6 million of debt issuance costs as of August 9, 2019 that were associated with the previous facility.  The interest rate as of December 31, 2019 was 5.0%.

[0001564590-20-002754:notes:122]
Amortization of deferred financing costs included in “Interest expense” in the accompanying condensed consolidated statements of operations totaled $0.7 million and $0.2 million for the three months ended December 31, 2019 and 2018, and totaled $1.1 million and $0.3 million for the six months ended December 31, 2019 and 2018, respectively.

[0001564590-20-002754:notes:123]
The Company had $60.3 million of availability under the 2019 Revolving Facility as of December 31, 2019.  The Company had $7.7 million of outstanding letters of credit as of December 31, 2019.


## us-gaap:LesseeOperatingLeasesTextBlock

[0001564590-20-002754:notes:124]
[same as prior period, unchanged from 0001564590-19-039190:notes:130]

[0001564590-20-002754:notes:125]
[same as prior period, unchanged from 0001564590-19-039190:notes:131]

[0001564590-20-002754:notes:126]
The Company lease certain facilities, equipment, and vehicles under operating leases that expire on various dates through fiscal 2028. Its leases generally have terms that range from one year to nine years for its facilities, one year to five years for equipment, and one year to five years for vehicles. Some of its leases contain renewal options, escalation clauses, rent concessions, and leasehold improvement incentives.

[0001564590-20-002754:notes:127]
The Company determines if an arrangement is a lease at inception. The Company has elected not to recognize a lease liability or right-of-use (ROU) asset for short-term leases (leases with a term of twelve months or less). Operating lease ROU assets and operating lease liabilities are recognized based on the present value of the future minimum lease payments over the lease term at commencement date. The interest rate used to determine the present value of future payments is the Company’s incremental borrowing rate because the rate implicit in the leases are not readily determinable. The Company’s incremental borrowing rate is a hypothetical rate for collateralized borrowings based on the current economic environment, credit history, credit rating, value of leases, currency in which the lease obligation is satisfied, rate sensitivity, lease term and materiality. Operating lease assets also included a reclassification for previous asset impairments and associated restructuring liabilities, deferred rent, lease incentives and initial direct costs which reduced the operating lease ROU assets as of July 1, 2019.

[0001564590-20-002754:notes:128]
Some operating leases contain lease and non-lease components. Certain lease contracts include fixed payments for services, such as operations, maintenance, or other services. The Company has elected to account for fixed lease and non-lease components as a single lease component except for the logistic service asset class. Cash payments made for non-lease costs and variable lease costs are not included in the measurement of operating lease assets and liabilities and are recognized in the Company’s condensed consolidated statements of operations as incurred. Some lease terms include one or more options to renew. The Company does not assume renewals in its determination of the lease term unless it is reasonably certain that it will exercise that option. The Company’s lease agreements do not contain any residual value guarantees.

[0001564590-20-002754:notes:129]
[same as prior period, unchanged from 0001564590-19-039190:notes:135]

[0001564590-20-002754:notes:130]
|  |  | Three Months Ended December 31, 2019 |  | Six Months Ended December 31, 2019 |  |
| Operating lease costs | $ | 5,002 |  | $ | 10,003 |  |
| Cash paid for amounts included in the measurement of operating liabilities |  | 5,346 |  |  | 10,831 |  |
| ROU assets obtained for new lease obligations |  | 1,357 |  |  | 1,422 |  |
| ROU assets obtained from Aerohive business combination |  | - |  |  | 6,336 |  |

[0001564590-20-002754:notes:131]
|  |  | December 31, 2019 |  |
| Weighted average remaining lease term (in years) |  | 4.7 |  |
| Weighted Average Discount Rate |  | 4.5 | % |

[0001564590-20-002754:notes:132]
Short-term lease expense for the three and six months ended December 31, 2019 was not material.

[0001564590-20-002754:notes:133]
The maturities of the Company’s operating lease liabilities as of December 31, 2019 by fiscal year are as follows:

[0001564590-20-002754:notes:134]
|  |  | Operating Leases (in thousands) |  |
| 2020 (remaining six months) |  | $ | 10,534 |  |
| 2021 |  |  | 20,298 |  |
| 2022 |  |  | 19,486 |  |
| 2023 |  |  | 15,767 |  |
| 2024 |  |  | 6,370 |  |
| Thereafter |  |  | 12,505 |  |
| Total future minimum lease payments |  |  | 84,960 |  |
| Less amount representing interest |  |  | 8,441 |  |
| Total operating lease liabilities |  | $ | 76,519 |  |
| Operating lease liabilities, current |  | $ | 17,921 |  |
| Operating lease liabilities, non-current |  | $ | 58,598 |  |

[0001564590-20-002754:notes:135]
[same as prior period, unchanged from 0001564590-19-039190:notes:140]

[0001564590-20-002754:notes:136]
[same as prior period, unchanged from 0001564590-19-039190:notes:141]

[0001564590-20-002754:notes:137]
[same as prior period, unchanged from 0001564590-19-039190:notes:142]

[0001564590-20-002754:notes:138]
The Company currently is a sublessor on several operating facility subleases that expire on various dates through fiscal 2023. The subleases have terms from 5 to 6 years and extend through the term of the underlying leases. The subleases do not include renewal options, purchase options, or termination rights. These operating subleases include only lease components. Included in lease expense, the Company had $0.6 million and $1.2 million of sublease income for the three and six months ended December 31, 2019, respectively.

[0001564590-20-002754:notes:139]
[same as prior period, unchanged from 0001564590-19-039190:notes:144]

[0001564590-20-002754:notes:140]
Although most of the Company’s revenue from its hardware business comes from sales of hardware, the Company also sells subscription contracts which contain both operating lease and non-lease components. These leases range in duration generally up to three years with payments generally collected in equal quarterly installments and include 60-day termination rights by either party. For the three months ended December 31, 2019 and 2018, $2.3 million and $3.2 million are included in product revenue in the financial statements, respectively. For the six months ended December 31, 2019 and 2018, $4.7 million and $5.9 million are included in product revenue in the financial statements, respectively. There were no changes to the accounting treatment of these transactions from the adoption of ASC 842.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001564590-20-002754:notes:141]
| 10. | Commitments and Contingencies |

[0001564590-20-002754:notes:142]
Purchase Commitments

[0001564590-20-002754:notes:143]
The Company currently has arrangements with contract manufacturers and suppliers for the manufacture of its products. Those arrangements allow the contract manufactures to procure long lead-time component inventory based upon a rolling production forecast provided by the Company. The Company is obligated to purchase long lead-time component inventory that its contract manufacturer procures in accordance with the forecast, unless the Company gives notice of order cancellation outside of applicable component lead-times. As of December 31, 2019, the Company had commitments to purchase $47.7 million of inventory and other services.

[0001564590-20-002754:notes:144]
Legal Proceedings

[0001564590-20-002754:notes:145]
The Company may from time to time be party to litigation arising in the course of its business, including, without limitation, allegations relating to commercial transactions, business relationships or intellectual property rights. Such claims, even if not meritorious, could result in the expenditure of significant financial and managerial resources. Litigation in general, and intellectual property in particular, can be expensive and disruptive to normal business operations. Moreover, the results of legal proceedings are difficult to predict.

[0001564590-20-002754:notes:146]
In accordance with applicable accounting guidance, the Company records accruals for certain of its outstanding legal proceedings, investigations or claims when it is probable that a liability will be incurred and the amount of loss can be reasonably estimated.  The Company evaluates, at least on a quarterly basis, developments in legal proceedings, investigations or claims that could affect the amount of any accrual, as well as any developments that would result in a loss contingency to become both probable and reasonably estimable.  When a loss contingency is not both probable and reasonably estimable, the Company does not record a loss accrual.  However, if the loss (or an additional loss in excess of any prior accrual) is at least a reasonable possibility and material, then the Company would disclose an estimate of the possible loss or range of loss, if such estimate can be made, or disclose that an estimate cannot be made.  The assessment whether a loss is probable or a reasonable possibility, and whether the loss or a range of loss is estimable, involves a series of complex judgments about future events.  Even if a loss is reasonably possible, the Company may not be able to estimate a range of possible loss, particularly where (i) the damages sought are substantial or indeterminate, (ii) the proceedings are in the early stages, or (iii) the matters involve novel or unsettled legal theories or a large number of parties. In such cases, there is considerable uncertainty regarding the ultimate resolution of such matters, including the amount of any possible loss,

[0001564590-20-002754:notes:147]
fine or penalty.  Accordingly, for current proceedings, except as noted below, the Company is currently unable to estimate any reasonably possible loss or range of possible loss.  However, an adverse resolution of one or more of such matters could have a material adverse effect on the Company's results of operations in a particular quarter or fiscal year.

[0001564590-20-002754:notes:148]
All currency conversions in this Legal Proceedings section are as of December 31, 2019.

[0001564590-20-002754:notes:149]
Brazilian Tax Assessment Matter

[0001564590-20-002754:notes:150]
On May 28, 2007, the Public Treasury Department of the State of Sao Paolo, Brazil (the “Tax Authority”) assessed the Company’s Brazilian subsidiary, Enterasys Networks do Brasil Ltda. (“Enterasys Brasil”), based on an alleged underpayment of taxes due to denial of presumed tax credits from 2003 to 2004 (the “ICMS Tax Assessment”).  The value of the disallowed presumed tax credits is BRL 3.4 million (USD $0.8 million), excluding interest and penalties.

[0001564590-20-002754:notes:151]
On October 1, 2014, Enterasys Brasil filed a lawsuit in the 11th Public Treasury Court of the Sao Paolo State Court of Justice (Judiciary District of Sao Paolo) to overturn or reduce the ICMS Tax Assessment. A decision in 2017 would require Enterasys Brasil to pay a total of BRL 20.2 million (USD $5.0 million), which includes penalties, court costs, attorneys’ fees, and accrued interest as of December 1, 2019. Enterasys Brasil recorded an accrual of BRL 9.4 million (USD $2.3 million) as of the date the Company acquired Enterasys Networks. The Company has appealed the lower court’s decision.

[0001564590-20-002754:notes:152]
On December 12, 2019, Enterasys Brasil participated in an amnesty program called the Programa Especial de Parcelamento offered by the Brazilian government to reach a resolution to this issue.  On December 18, 2019, Enterasys Brasil paid BRL 8.692 million (USD $2.2 million) to settle the ICMS Tax Assessment.  The Company will dismiss the pending appellate suit and has accrued for payment of the government’s legal fees of approximately BRL 0.632 million (USD $0.157 million).

[0001564590-20-002754:notes:153]
XR Communications, LLC d/b/a Vivato Technologies v. Extreme Networks, Inc. Patent Infringement Suit

[0001564590-20-002754:notes:154]
On April 19, 2017, XR Communications, LLC (“XR”) (d/b/a Vivato Technologies) filed a patent infringement lawsuit against the Company in the Central District of California.  The operative Second Amended Complaint asserts infringement of U.S. Patent Nos. 7,062,296, 7,729,728, and 6,611,231 based on the Company’s manufacture, use, sale, offer for sale, and/or importation into the United States of certain access points and routers supporting multi-user, multiple-input, multiple-output technology. XR seeks unspecified damages, on-going royalties, pre- and post-judgment interest, and attorneys’ fees.  In 2018, the Court stayed the case pending a resolution by the Patent Trial and Appeal Board (“PTAB”) of inter partes review (IPR) petitions filed by several defendants in other XR-related patent lawsuits challenging the validity of the asserted patents. The PTAB has now invalidated all asserted claims of the ’296 patent and ’728 patent, and has found the challenged claims of the ’231 patent not invalid in view of the prior art asserted in the IPR instituted against that patent. The matter has been stayed and a status conference is set for March 17, 2020.  The Company believes the claims are without merit and intends to defend them vigorously.

[0001564590-20-002754:notes:155]
Orckit IP, LLC v. Extreme Networks, Inc., Extreme Networks Ireland Ltd., and Extreme Networks GmbH

[0001564590-20-002754:notes:156]
On February 1, 2018, Orckit IP, LLC (“Orckit”) filed a patent infringement lawsuit against the Company and its Irish and German subsidiaries in the District Court in Dusseldorf, Germany.  The lawsuit alleges direct and indirect infringement of the German portion of European Patent EP 1 958 364 B1 (“EP ’364”) based on the offer, distribution, use, possession and/or importation into Germany of certain network switches equipped with the ExtremeXOS operating system.  Orckit is seeking injunctive relief, accounting, and an unspecified declaration of liability for damages and costs of the lawsuit.  On May 3, 2018, Extreme Networks GmbH filed a separate nullity action in the Federal Patent Court in Munich, seeking to invalidate the asserted patents.  The District Court Düsseldorf held a hearing in this case on January 28, 2020 and a decision is expected in a few weeks.

[0001564590-20-002754:notes:157]
On April 23, 2019, Orckit filed and extension of the patent infringement complaint against the Company and its Irish and German subsidiaries in the District Court in Dusseldorf, Germany. With this extension, Orckit alleges infringement of the German portion of European Patent EP 3 068 077 B1 (“EP ‘077”) based on the offer, distribution, use, possession and/or importation into Germany of certain network switches.  Orckit is seeking injunctive relief, accounting and sales information, and a declaration of liability for damages as well as costs of the lawsuit.  Extreme filed a nullity action with the German Federal Patent Court on or before that date, seeking to invalidate the asserted patent.  No hearing has been scheduled yet in this case, which was split from the original action involving the first patent in suit.

[0001564590-20-002754:notes:158]
The Company believes that all claims in both cases are without merit and defends them vigorously.

[0001564590-20-002754:notes:159]
Global Innovation Aggregators, LLC v. Extreme Networks, Inc.; Extreme Networks China Limited; Extreme Networks Technology (Beijing) Co., Ltd.; and Shenzhen Yingzhixiang Technology Co.

[0001564590-20-002754:notes:160]
In January 2019, Global Innovation Aggregators, LLC (“GIA”) filed six patent infringement lawsuits against the Company and its Chinese and Hong Kong subsidiaries and Shenzhen Yingzhixiang Technology Co., Ltd. in Shenzhen Intermediate People’s Court in China. The six patents at issue are ZL200610168028.1 (“ZL ‘028.1”), ZL200510120823.9, ZL200410057124.X, ZL200410070933.4, ZL200510103486.2 (“ZL ‘486.2”), and ZL200610060686.9 (“ZL ‘686.9”) (collectively, the “Asserted Patents”). GIA has accused a number of Summit switching products of infringing the Asserted Patents. Each patent was asserted in a separate lawsuit.  The trial related to the ZL ‘4862 patent has been postponed, and the trials for the rest of the cases have not yet been scheduled. Extreme disputes GIA’s claims and intends to defend the matter vigorously.  Additionally, Extreme has filed invalidity challenges with the Chinese patent office to challenge the validity of each asserted patent.  Oral invalidity hearings were held in July and August 2019. The Chinese patent office has issued decisions maintaining the validity of the ZL ‘028.1 and ZL ‘486.2 patents, and Extreme has appealed these two rulings.  All the claims in ZL ‘686.9 have been fully invalidated.  Decisions have not yet been issued for the remaining three patents.

[0001564590-20-002754:notes:161]
Given the uncertainty of litigation and the preliminary stage of the case, Extreme cannot estimate at this time the possible loss or range of loss that may result from this action.

[0001564590-20-002754:notes:162]
Shenzhen Dunjun Technology Ltd. v. Aerohive Networks (Hangzhou) Ltd.; Aerohive Networks, Inc.; and Yunqing Information Technology (Shenzhen) Ltd.

[0001564590-20-002754:notes:163]
On June 20, 2019, Shenzhen Dunjun Technology Ltd. (“Shenzhen Dunjun”) filed a patent infringement lawsuit against Aerohive Networks, Inc. (“Aerohive”), its Chinese subsidiary, and Yunqing Information Technology (Shenzhen) Ltd. in the Shenzhen Intermediate People’s Court in China.  The lawsuit alleges infringement of Chinese patent ZL02123502.3 and seeks damages of RMB 10.0 million (USD $1.4 million). The trial originally scheduled for November 15, 2019 has been postponed by the Court, pending the jurisdictional objections filed by Aerohive and has not yet been rescheduled.  The Court rejected the jurisdictional challenge, which Aerohive is appealing. The Company cannot estimate at this time the possible loss or range of loss that may result from this action.

[0001564590-20-002754:notes:164]
Indemnification Obligations

[0001564590-20-002754:notes:165]
Subject to certain limitations, the Company may be obligated to indemnify its current and former directors, officers and employees. These obligations arise under the terms of its certificate of incorporation, its bylaws, applicable contracts, and applicable law. The obligation to indemnify, where applicable, generally means that the Company is required to pay or reimburse, and in certain circumstances the Company has paid or reimbursed, the individuals' reasonable legal expenses and possibly damages and other liabilities incurred in connection with certain legal matters. The Company also procures Directors and Officers insurance to help cover its defense and/or indemnification costs, although its ability to recover such costs through insurance is uncertain.  While it is not possible to estimate the maximum potential amount that could be owed under these indemnification agreements due to the Company’s limited history with prior indemnification claims, indemnification (including defense) costs could, in the future, have a material adverse effect on the Company’s consolidated financial position, results of operations and cash flows.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001564590-20-002754:notes:166]
[same as prior period, unchanged from 0001564590-19-039190:notes:169]

[0001564590-20-002754:notes:167]
[same as prior period, unchanged from 0001564590-19-039190:notes:170]

[0001564590-20-002754:notes:168]
On April 26, 2012, the Company entered into an Amended and Restated Rights Agreement between the Company and Computershare Shareholder Services LLC as the rights agent (the “Restated Rights Plan”). The Restated Rights Plan governs the terms of each right (“Right”) that has been issued with respect to each share of common stock of Extreme Networks. Each Right initially represents the right to purchase one one-thousandth of a share of the Company’s Preferred Stock.

[0001564590-20-002754:notes:169]
The Company’s Board of Directors (the “Board”) adopted the Restated Rights Plan to preserve the value of deferred tax assets, including net operating loss carry forwards of the Company, with respect to its ability to fully use its tax benefits to offset future income which may be limited if the Company experiences an “ownership change” for purposes of Section 382 of the Internal Revenue Code of 1986 as a result of ordinary buying and selling of its common stock. Following its review of the terms of the plan, the Board decided it was necessary and in the best interests of the Company and its stockholders to enter into the Restated Rights Plan. Each year since 2013 the Board and stockholders have approved an amendment providing for a one-year extension of the term of the Restated Rights Plan.  The Board unanimously approved an amendment to the Restated Rights Plan on May 9, 2019, to extend the Restated Rights Plan through May 31, 2020, which was ratified by a majority of the stockholders of the Company at the November 7, 2019 shareholders meeting.

[0001564590-20-002754:notes:170]
Equity Incentive Plan

[0001564590-20-002754:notes:171]
The Board of Directors unanimously approved an amendment to the Extreme Networks, Inc. Amended and Restated 2013 Equity Incentive Plan to increase the maximum number of available shares by 7,000,000 shares.  The amendment was ratified by a majority of the stockholders at the Company’s annual meeting of stockholders held on November 7, 2019.

[0001564590-20-002754:notes:172]
[same as prior period, unchanged from 0001564590-19-039190:notes:175]

[0001564590-20-002754:notes:173]
On November 2, 2018, the Company announced the Board had authorized management to repurchase up to $60.0 million of the Company’s common stock over a two-year period from the date of authorization. Purchases may be made from time to time through any means including, but not limited to, open market purchases and privately negotiated transactions.  A maximum of $35.0 million of the Company’s common stock may be repurchased in any calendar year.

[0001564590-20-002754:notes:174]
In November 2019, the Company entered into an accelerated share repurchase agreement (the “November 2019 ASR”) to repurchase shares of the Company’s common stock.  Pursuant to the November 2019 ASR, the Company paid $30.0 million for an initial delivery of 3,850,000 shares valued at $25.2 million. The remaining balance of $4.8 million was recorded in additional paid-in-capital as a forward contract in the Company’s common stock. The forward contract was settled on January 24, 2020 and the Company received an additional 381,505 shares of its common stock.

[0001564590-20-002754:notes:175]
The following table summarizes stock award activity for the three and six months ended December 31, 2019 and 2018.

[0001564590-20-002754:notes:176]
|  |  | Three and Six Months Ended |  |
|  |  | December 31, 2019 |  |  | December 31, 2018 |  |
| Total number of shares repurchased |  |  | 3,850 |  |  |  | 2,366 |  |
| Average price paid per share |  | $ | 6.54 |  |  | $ | 6.34 |  |
| Dollar value of shares repurchased |  | $ | 25,179 |  |  | $ | 15,000 |  |
| Dollar value of shares that may yet be repurchased under program |  | $ | 19,821 |  |  | $ | 45,000 |  |


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001564590-20-002754:notes:177]
[same as prior period, unchanged from 0001564590-19-039190:notes:177]

[0001564590-20-002754:notes:178]
[same as prior period, unchanged from 0001564590-19-039190:notes:178]

[0001564590-20-002754:notes:179]
[same as prior period, unchanged from 0001564590-19-039190:notes:179]

[0001564590-20-002754:notes:180]
|  |  | December 31, 2019 |  |  | June 30, 2019 |  |
| 2013 Equity Incentive Plan shares available for grant |  |  | 10,435 |  |  |  | 8,462 |  |
| Employee stock options and awards outstanding |  |  | 13,541 |  |  |  | 10,455 |  |
| 2014 Employee Stock Purchase Plan |  |  | 8,862 |  |  |  | 10,085 |  |
| Total shares reserved for issuance |  |  | 32,838 |  |  |  | 29,002 |  |

[0001564590-20-002754:notes:181]
[same as prior period, unchanged from 0001564590-19-039190:notes:181]

[0001564590-20-002754:notes:182]
Pursuant to the acquisition of Aerohive on August 9, 2019, the Company assumed the Aerohive 2014 Equity Incentive Plan (the "Aerohive Plan").  Stock awards outstanding under the Aerohive Plan were converted into awards for Extreme shares as of the Acquisition Date at a predetermined rate pursuant to the Merger Agreement.  As of December 31, 2019, total awards to acquire 1,147,232 shares of Extreme common stock were outstanding under the Aerohive Plan.  If a participant terminates employment prior to the vesting dates, the non-vested shares will be forfeited and retired. No future grants may be made from the Aerohive Plan.

[0001564590-20-002754:notes:183]
[same as prior period, unchanged from 0001564590-19-039190:notes:183]

[0001564590-20-002754:notes:184]
[same as prior period, unchanged from 0001564590-19-039190:notes:184]

[0001564590-20-002754:notes:185]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | December 31, 2019 |  |  | December 31, 2018 |  |  | December 31, 2019 |  |  | December 31, 2018 |  |
| Cost of product revenue |  | $ | 402 |  |  | $ | 217 |  |  | $ | 652 |  |  | $ | 395 |  |
| Cost of service revenue |  |  | 505 |  |  |  | 677 |  |  |  | 852 |  |  |  | 1,022 |  |
| Research and development |  |  | 3,260 |  |  |  | 2,797 |  |  |  | 5,695 |  |  |  | 5,139 |  |
| Sales and marketing |  |  | 3,511 |  |  |  | 2,983 |  |  |  | 7,230 |  |  |  | 5,342 |  |
| General and administrative |  |  | 2,801 |  |  |  | 2,026 |  |  |  | 4,884 |  |  |  | 3,627 |  |
| Integration costs |  |  | 479 |  |  |  | — |  |  |  | 479 |  |  |  | — |  |
| Total share-based compensation expense |  | $ | 10,958 |  |  | $ | 8,700 |  |  | $ | 19,792 |  |  | $ | 15,525 |  |

[0001564590-20-002754:notes:186]
During the three and six months ended December 31, 2019, and 2018, the Company did not capitalize any share-based compensation expense in inventory, as the amounts were immaterial.

[0001564590-20-002754:notes:187]
[same as prior period, unchanged from 0001564590-19-039190:notes:187]

[0001564590-20-002754:notes:188]
[same as prior period, unchanged from 0001564590-19-039190:notes:188]

[0001564590-20-002754:notes:189]
The following table summarizes stock award activity for the six months ended December 31, 2019 (in thousands, except grant date fair value):

[0001564590-20-002754:notes:190]
|  |  | Number of Shares |  |  | Weighted- Average Grant Date Fair Value |  |  | Aggregate Fair Market Value |  |
| Non-vested stock awards outstanding at June 30, 2019 |  |  | 7,736 |  |  | $ | 7.67 |  |  |  |  |  |
| Granted |  |  | 6,017 |  |  |  | 6.86 |  |  |  |  |  |
| Released |  |  | (2,474 | ) |  |  | 7.08 |  |  |  |  |  |
| Cancelled |  |  | (890 | ) |  |  | 7.08 |  |  |  |  |  |
| Non-vested stock awards outstanding at December 31, 2019 |  |  | 10,389 |  |  | $ | 7.39 |  |  | $ | 76,570 |  |
| Vested and expected to vest at December 31, 2019 |  |  | 9,729 |  |  | $ | 7.30 |  |  | $ | 71,705 |  |

[0001564590-20-002754:notes:191]
The following table summarizes stock option activity for the six months ended December 31, 2019 (in thousands, except per share and contractual term):

[0001564590-20-002754:notes:192]
|  |  | Number of Shares |  |  | Weighted-Average Exercise Price Per Share |  |  | Weighted-Average Remaining Contractual Term (years) |  |  | Aggregate Intrinsic Value |  |
| Options outstanding at June 30, 2019 |  |  | 2,719 |  |  | $ | 4.61 |  |  |  | 3.26 |  |  | $ | 5,070 |  |
| Granted |  |  | 637 |  |  |  | 6.70 |  |  |  |  |  |  |  |  |  |
| Exercised |  |  | (181 | ) |  |  | 4.55 |  |  |  |  |  |  |  |  |  |
| Cancelled |  |  | (23 | ) |  |  | 4.75 |  |  |  |  |  |  |  |  |  |
| Options outstanding at December 31, 2019 |  |  | 3,152 |  |  | $ | 5.03 |  |  |  | 3.66 |  |  | $ | 7,374 |  |
| Vested and expected to vest at December 31, 2019 |  |  | 3,152 |  |  | $ | 5.03 |  |  |  | 3.66 |  |  | $ | 7,374 |  |
| Exercisable at December 31, 2019 |  |  | 1,735 |  |  | $ | 3.80 |  |  |  | 1.65 |  |  | $ | 6,194 |  |

[0001564590-20-002754:notes:193]
The fair value of each stock option grant under the 2013 Plan and 2005 Equity Incentive Plan is estimated on the date of grant using the Black-Scholes-Merton option valuation model.  The Company uses the Monte-Carlo simulation model to determine the fair value and the derived service period of stock awards with market conditions, on the date of the grant.  The expected term of options granted is derived from historical data on employee exercise and post-vesting employment termination behavior.  The risk-free rate is

[0001564590-20-002754:notes:194]
based upon the estimated life of the option and the U.S. Treasury yield curve in effect at the time of grant. Expected volatility is based on the historical volatility on the Company’s stock.  The average fair value of the options granted was $6.70.

[0001564590-20-002754:notes:195]
[same as prior period, unchanged from 0001564590-19-039190:notes:194]

[0001564590-20-002754:notes:196]
The RSUs granted during the six months ended December 31, 2019 vest from the original grant date as to one-third (1/3) on the one-year anniversary and one-twelfth (1/12) each quarter thereafter, subject to continued service to the Company. These RSUs included 566,038 RSUs to named executive officers and directors.

[0001564590-20-002754:notes:197]
During fiscal 2019 and 2018, the Company approved the grant of 0.6 million shares of stock awards each year in the form of PSU’s to named executive officers and other vice president level employees. These PSUs would be considered earned once the Company’s U.S. GAAP earnings aggregates at least $0.20 per share over two consecutive quarters (the “Performance Thresholds”). During the second quarter of fiscal 2020, the compensation committee of the Board of Directors modified the Performance Thresholds of $0.20 earnings per share over two consecutive quarters for PSUs issued in fiscal 2019 and 2018, to $0.09 earnings per share over two consecutive quarters. Upon satisfying the Performance Thresholds, the PSUs will vest with respect to the same number of RSUs that have vested which were granted on the same date and thereafter will vest on the same schedule as the RSUs, subject to continued service to the Company.  If the Performance Thresholds is not met by the third anniversary of the grant date for each award, that award is canceled.  During the six months ended December 31, 2019, the 2019 and 2018 Performance Thresholds for outstanding performance awards were not achieved.

[0001564590-20-002754:notes:198]
[same as prior period, unchanged from 0001564590-19-039190:notes:197]

[0001564590-20-002754:notes:199]
[same as prior period, unchanged from 0001564590-19-039190:notes:198]

[0001564590-20-002754:notes:200]
There were 1,233,434 and 1,280,708 shares issued under the ESPP during the six months ended December 31, 2019 and 2018, respectively.  The following assumptions were used to calculate the fair value of shares granted under the ESPP during the following periods:

[0001564590-20-002754:notes:201]
|  |  | Employee Stock Purchase Plan |  |
|  |  | Six Months Ended |  |
|  |  | December 31, 2019 |  |  | December 31, 2018 |  |
| Expected life |  | 0.5 years |  |  | 0.5 years |  |
| Risk-free interest rate |  |  | 1.85 | % |  |  | 2.20 | % |
| Volatility |  |  | 43 | % |  |  | 63 | % |
| Dividend yield |  |  | — | % |  |  | — | % |

[0001564590-20-002754:notes:202]
The weighted-average fair value of shares granted under the ESPP during the six months ended December 31, 2019 and 2018 was $2.02 and $2.73, respectively.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001564590-20-002754:notes:203]
[same as prior period, unchanged from 0001564590-19-039190:notes:202]

[0001564590-20-002754:notes:204]
The Company operates in one segment, the development and marketing of network infrastructure equipment and related software. The Company conducts business globally and is managed geographically. Revenue is attributed to a geographical area based on the location of its customers. The Company operates in three geographical areas: Americas, which includes the United States, Canada, Mexico, Central America and South America; EMEA, which includes Europe, Russia, Middle East and Africa; and APAC which includes Asia Pacific, South Asia, India, Australia and Japan. The Company’s chief operating decision maker, who is its CEO, reviews financial information presented on a consolidated basis for purposes of allocating resources and evaluating financial performance.

[0001564590-20-002754:notes:205]
[same as prior period, unchanged from 0001564590-19-039190:notes:204]

[0001564590-20-002754:notes:206]
[same as prior period, unchanged from 0001564590-19-039190:notes:205]

[0001564590-20-002754:notes:207]
| Long-lived Assets |  | December 31, 2019 |  |  | June 30, 2019 |  |
| Americas |  | $ | 218,301 |  |  | $ | 136,035 |  |
| EMEA |  |  | 28,630 |  |  |  | 28,744 |  |
| APAC |  |  | 19,926 |  |  |  | 11,529 |  |
| Total long-lived assets |  | $ | 266,857 |  |  | $ | 176,308 |  |


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001564590-20-002754:notes:208]
[same as prior period, unchanged from 0001564590-19-039190:notes:207]

[0001564590-20-002754:notes:209]
The Company recorded $6.6 million and $12.8 million of restructuring charges, net of reversals and impairments during the three and six months ended December 31, 2019, respectively.  The charges included facility related charges of $3.9 million and $7.9 million and severance and benefits charges of $2.7 million and $4.9 million for the three and six-month periods ended December 31, 2019, respectively.

[0001564590-20-002754:notes:210]
During the first quarter of fiscal 2020, the Company continued its initiative to realign its operations by exiting a floor of its San Ignacio building in San Jose California and consolidating its workforce.  Also, the Company exited additional space in its Salem New Hampshire facility, which includes general office and lab space. The Company has the intent and ability to sub-lease these facilities which it has ceased using and as such has considered estimated future sub-lease income based on its existing leases agreement, as well as the local real estate market conditions in measuring the amount of asset impairment. The Company also factored into its estimate the time for a sub-lease tenant to enter into an agreement and complete any improvements.  For the three months ended September 30, 2019, the Company recorded restructuring charges of $3.9 million related to the exited facilities.

[0001564590-20-002754:notes:211]
During the second quarter of fiscal 2020, the Company continued its initiative to realign its operations resulting from the acquisition of Aerohive and consolidating its workforce. The Company exited its facility in Milpitas, California which includes general office and lab space.  The Company has the intent and ability to sub-lease these facilities which it has ceased using and as such has considered estimated future sub-lease income based on its existing leases agreement, as well as the local real estate market conditions in measuring the amount of asset impairment.  The Company also factored into its estimate the time for a sub-lease tenant to enter into an agreement and complete any improvements.  For the three months ended December 31, 2019, the Company recorded charges for the impairment of right-of-use-assets of $2.8 million, long-lived assets of $0.9 million, and other charges of $0.2 million related to the exited facilities.

[0001564590-20-002754:notes:212]
Certain amounts have been reclassified from restructuring liabilities and have been recorded as a reduction to operating lease ROU assets as of July 1, 2019.

[0001564590-20-002754:notes:213]
Restructuring liabilities related to severance and benefits obligations are recorded in “Other accrued liabilities” in the accompanying condensed consolidated balance sheets.  Total restructuring and related liabilities consist of (in thousands):

[0001564590-20-002754:notes:214]
|  |  | Excess Facilities |  |  | Severance Benefits |  |  | Total |  |
| Balance as of June 30, 2019 |  | $ | 1,764 |  |  | $ | 3,559 |  |  | $ | 5,323 |  |
| Period charges |  |  | — |  |  |  | 5,879 |  |  |  | 5,879 |  |
| Period reversals |  |  | — |  |  |  | (1,005 | ) |  |  | (1,005 | ) |
| Reclassification to reduce operating lease assets |  |  | (1,764 | ) |  |  | — |  |  |  | (1,764 | ) |
| Period payments |  |  | — |  |  |  | (7,565 | ) |  |  | (7,565 | ) |
| Balance as of December 31, 2019 |  | $ | — |  |  | $ | 868 |  |  | $ | 868 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0001564590-20-002754:notes:215]
[same as prior period, unchanged from 0001564590-19-039190:notes:215]

[0001564590-20-002754:notes:216]
For the three months ended December 31, 2019 and 2018, the Company recorded an income tax provision of $1.8 million and an income tax benefit of $5.3 million, respectively. For the six months ended December 31, 2019 and 2018, the Company recorded an income tax provision of $3.4 million and an income tax benefit of $3.9 million, respectively.

[0001564590-20-002754:notes:217]
The income tax provisions for the three and six months ended December 31, 2019 and 2018, consisted of (1) taxes on the income of the Company’s foreign subsidiaries, (2) foreign withholding taxes (3) tax expense associated with the establishment of a U.S. deferred tax liability for amortizable goodwill resulting from the acquisition of Enterasys Networks, Inc., the WLAN Business,

[0001564590-20-002754:notes:218]
the Campus Fabric Business and the Data Center Business, and (4) state taxes in jurisdictions where the Company has no remaining state Net Operating Losses (“NOL’S”). In addition, the three and six months ended December 31, 2018 included tax benefits associated with the release of valuation allowance resulting from changes introduced by US tax reform as well as the release of a valuation allowance recorded against deferred tax assets in Australia. The income tax provisions for both fiscal years were calculated based on the actual results of operations for the three and six months ended December 31, 2019 and 2018 , respectively and therefore may not reflect the annual effective tax rate.

[0001564590-20-002754:notes:219]
In the first quarter of fiscal year ended June 30, 2019, the Company adopted ASU 2016-16, Intra-Entity Transfers of Assets Other Than Inventory, which requires an entity to recognize the income tax consequences of an intra-entity transfer of an asset at the time the transfer occurs.  Historically, GAAP has prohibited the recognition of current and deferred income taxes for an intra-entity asset transfer until the asset had been sold outside the consolidated group.  Effective July 1, 2018, the Company adopted ASU 2016-16 on a modified retrospective basis which requires an adjustment of the cumulative-effect of the adoption to retained earnings.  The adjustment was immaterial to the financial statements and as such, no such adjustment was necessary.  As a result of adoption, the income tax consequences of future intra-entity transfer of assets will be recognized in earnings in each period rather than be deferred until the assets leave the consolidated group.  In the three months ended September 30, 2018, the Company recognized a deferred tax asset relating to a transfer of certain assets from the U.S. parent company to its wholly-owned Irish subsidiary of $3.7 million, which was fully offset by the establishment of a valuation allowance resulting in no impact to Company’s statement of operations.

[0001564590-20-002754:notes:220]
The Company has provided a full valuation allowance against all of its U.S. federal and state deferred tax assets as well as a portion of the deferred tax assets in Ireland. A valuation allowance is determined by assessing both negative and positive evidence to determine whether it is “more likely than not” that deferred tax assets are recoverable; such assessment is required on a jurisdiction by jurisdiction basis.  The Company's inconsistent earnings in recent periods, including a cumulative loss over the last three years, coupled with its difficulty in forecasting future revenue trends and the cyclical nature of its business represent sufficient negative evidence to require a full valuation allowance against its U.S. federal and state net deferred tax assets as well as a portion of the deferred tax assets in Ireland.  These valuation allowance will be evaluated periodically and can be reversed partially or in whole if business results and the economic environment have sufficiently improved to support realization of some or all of the Company's deferred tax assets.

[0001564590-20-002754:notes:221]
[same as prior period, unchanged from 0001564590-19-039190:notes:220]

[0001564590-20-002754:notes:222]
The Company had $25.8 million of unrecognized tax benefits as of December 31, 2019.  The future impact of the unrecognized tax benefit of $25.8 million, if recognized, would result in adjustments to deferred tax assets and corresponding adjustments to the valuation allowance with no impact to the effective tax rate.  The Company does not anticipate any events to occur during the next twelve months that would reduce the unrealized tax benefit as currently stated in the Company’s balance sheet.

[0001564590-20-002754:notes:223]
[same as prior period, unchanged from 0001564590-19-039190:notes:222]

[0001564590-20-002754:notes:224]
In general, the Company’s U.S. federal income tax returns are subject to examination by tax authorities for fiscal years 2001 forward due to net operating losses and the Company's state income tax returns are subject to examination for fiscal years 2000 forward due to net operating losses. The Company is not currently under audit in any material jurisdictions.


## us-gaap:EarningsPerShareTextBlock

[0001564590-20-002754:notes:225]
[same as prior period, unchanged from 0001564590-19-039190:notes:224]

[0001564590-20-002754:notes:226]
[same as prior period, unchanged from 0001564590-19-039190:notes:225]

[0001564590-20-002754:notes:227]
The following table presents the calculation of net (loss) income per share of basic and diluted (in thousands, except per share data):

[0001564590-20-002754:notes:228]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | December 31, 2019 |  |  | December 31, 2018 |  |  | December 31, 2019 |  |  | December 31, 2018 |  |
| Net income (loss) |  |  | (23,538 | ) |  |  | 7,199 |  |  |  | (61,276 | ) |  |  | (1,866 | ) |
| Weighted-average shares used in per share calculation - basic |  |  | 119,555 |  |  |  | 117,544 |  |  |  | 119,891 |  |  |  | 117,456 |  |
| Effect of potentially dilutive shares: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Options to purchase common stock |  |  | — |  |  |  | 657 |  |  |  | — |  |  |  | — |  |
| Restricted stock units |  |  | — |  |  |  | 1,129 |  |  |  | — |  |  |  | — |  |
| Employee Stock Purchase Plan shares |  |  | — |  |  |  | 214 |  |  |  | — |  |  |  | — |  |
| Weighted-average shares used in per share calculation - basic and diluted |  |  | 119,555 |  |  |  | 119,544 |  |  |  | 119,891 |  |  |  | 117,456 |  |
| Net loss per share - basic and diluted |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income (loss) per share - basic |  | $ | (0.20 | ) |  | $ | 0.06 |  |  | $ | (0.51 | ) |  | $ | (0.02 | ) |
| Net income (loss) per share - diluted |  | $ | (0.20 | ) |  | $ | 0.06 |  |  | $ | (0.51 | ) |  | $ | (0.02 | ) |

[0001564590-20-002754:notes:229]
[same as prior period, unchanged from 0001564590-19-039190:notes:228]

[0001564590-20-002754:notes:230]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | December 31, 2019 |  |  | December 31, 2018 |  |  | December 31, 2019 |  |  | December 31, 2018 |  |
| Options to purchase common stock |  |  | 3,177 |  |  |  | 781 |  |  |  | 3,037 |  |  |  | 543 |  |
| Restricted stock units |  |  | 10,378 |  |  |  | 6,341 |  |  |  | 9,862 |  |  |  | 1,369 |  |
| Employee Stock Purchase Plan shares |  |  | 1,500 |  |  |  | 1,286 |  |  |  | 1,500 |  |  |  | 1,286 |  |
| Total shares excluded |  |  | 15,055 |  |  |  | 8,408 |  |  |  | 14,399 |  |  |  | 3,198 |  |
