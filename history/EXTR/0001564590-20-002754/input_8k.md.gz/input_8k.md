# EXTR 8-K — 0001564590-20-002375 filed 2020-01-29

## item codes, every 8-K on or before 2020-01-30

- 2020-01-29 0001564590-20-002375 — 2.02, 9.01
- 2020-01-29 0001193125-20-017673 — 5.02, 9.01
- 2019-11-08 0001193125-19-288358 — 5.07
- 2019-10-30 0001564590-19-038508 — 2.02, 9.01
- 2019-10-25 0001564590-19-037908 — 9.01 — amendment of 0001193125-19-217553
- 2019-10-18 0001193125-19-269734 — 7.01, 9.01
- 2019-08-30 0001193125-19-235271 — 5.02 — amendment of 0001193125-19-229280
- 2019-08-26 0001193125-19-229280 — 5.02, 9.01
- 2019-08-09 0001193125-19-217553 — 1.01, 2.01, 2.03, 9.01
- 2019-07-31 0001564590-19-027208 — 2.02, 9.01
- 2019-06-26 0001193125-19-181938 — 1.01, 2.05, 9.01
- 2019-05-01 0001564590-19-014567 — 2.02, 9.01
- 2019-01-29 0001564590-19-001270 — 2.02, 9.01
- 2019-01-25 0001564590-19-001157 — 8.01, 9.01
- 2018-11-20 0001193125-18-331450 — 5.02, 9.01
- 2018-11-15 0001564590-18-029683 — 5.07
- 2018-11-02 0001564590-18-026372 — 2.02, 8.01, 9.01
- 2018-09-19 0001193125-18-276766 — 5.02
- 2018-08-08 0001564590-18-020191 — 2.02, 9.01
- 2018-06-05 0001564590-18-015067 — 3.03, 9.01
- 2018-05-08 0001564590-18-011817 — 2.02, 9.01
- 2018-05-07 0001564590-18-011264 — 1.01, 1.02, 2.03, 9.01
- 2018-02-06 0001564590-18-001403 — 2.02, 2.05, 9.01
- 2018-02-01 0001564590-18-001166 — 5.02
- 2018-01-12 0001564590-18-000462 — 9.01 — amendment of 0001193125-17-323879
- 2017-11-15 0001564590-17-023847 — 5.07
- 2017-11-07 0001564590-17-022235 — 2.02, 9.01
- 2017-11-03 0001193125-17-332828 — 9.01 — amendment of 0001193125-17-323879
- 2017-10-30 0001193125-17-323879 — 1.01, 2.01, 7.01, 9.01
- 2017-10-03 0001193125-17-302411 — 1.01, 9.01
- 2017-10-03 0001193125-17-301597 — 1.01, 1.02, 7.01, 9.01
- 2017-09-29 0001564590-17-019099 — 9.01 — amendment, the index does not say of what
- 2017-08-14 0001564590-17-017659 — 2.02, 9.01
- 2017-08-02 0001564590-17-014950 — 5.02
- 2017-07-18 0001564590-17-013557 — 1.01, 2.01, 2.03, 9.01
- 2017-06-05 0001564590-17-012126 — 3.03, 9.01
- 2017-05-03 0001564590-17-008378 — 2.02, 9.01
- 2017-03-30 0001193125-17-102344 — 1.01, 9.01
- 2017-03-07 0001193125-17-073306 — 1.01, 9.01
- 2017-02-21 0001193125-17-048182 — 5.02
- 2017-02-01 0001564590-17-000835 — 2.02, 9.01
- 2017-01-06 0001564590-17-000138 — 2.05
- 2016-11-21 0001564590-16-029539 — 5.07
- 2016-11-01 0001564590-16-026732 — 2.02, 9.01
- 2016-10-31 0001193125-16-752557 — 1.01, 2.01, 2.03
- 2016-09-15 0001193125-16-711097 — 1.01, 9.01
- 2016-08-03 0001564590-16-022347 — 2.02, 9.01
- 2016-05-19 0001564590-16-019720 — 5.02, 9.01
- 2016-05-09 0001564590-16-018660 — 3.03, 9.01
- 2016-04-27 0001564590-16-016754 — 2.02, 9.01
- 2016-02-24 0001564590-16-013189 — 8.01
- 2016-02-09 0001564590-16-012469 — 8.01
- 2016-01-28 0001564590-16-012054 — 2.02, 9.01
- 2015-11-17 0001078271-15-000136 — 5.07
- 2015-10-29 0001078271-15-000125 — 2.02, 9.01
- 2015-08-31 0001078271-15-000111 — 8.01, 9.01
- 2015-08-11 0001078271-15-000096 — 5.02
- 2015-08-06 0001078271-15-000093 — 2.02, 9.01
- 2015-06-30 0001078271-15-000089 — 1.01, 9.01
- 2015-05-20 0001078271-15-000077 — 2.05, 9.01
- 2015-05-19 0001078271-15-000075 — 3.03, 9.01
- 2015-05-06 0001078271-15-000050 — 2.02, 9.01
- 2015-05-04 0001078271-15-000048 — 5.02, 9.01
- 2015-04-29 0001078271-15-000038 — 5.02, 9.01
- 2015-04-21 0001078271-15-000034 — 5.02, 9.01
- 2015-04-09 0001078271-15-000032 — 2.02, 5.02, 9.01
- 2015-02-18 0001078271-15-000021 — 8.01
- 2015-02-17 0001078271-15-000019 — 5.02
- 2015-01-28 0001078271-15-000004 — 2.02, 9.01
- 2014-12-18 0001078271-14-000081 — 5.02, 9.01
- 2014-12-17 0001078271-14-000079 — 5.02
- 2014-11-20 0001078271-14-000075 — 1.01, 9.01
- 2014-11-17 0001078271-14-000073 — 5.07
- 2014-10-28 0001078271-14-000062 — 2.02, 9.01
- 2014-10-15 0001078271-14-000060 — 2.02, 9.01
- 2014-10-02 0001078271-14-000057 — 5.02, 9.01
- 2014-08-14 0001078271-14-000047 — 2.02, 9.01
- 2014-07-21 0001078271-14-000042 — 2.02, 9.01
- 2014-05-23 0001078271-14-000036 — 5.02, 9.01
- 2014-05-20 0001078271-14-000034 — 3.03, 9.01
- 2014-05-12 0001078271-14-000030 — 5.02
- 2014-05-08 0001078271-14-000022 — 5.02, 9.01
- 2014-05-07 0001078271-14-000018 — 2.02, 9.01 — amendment, the index does not say of what
- 2014-05-06 0001078271-14-000016 — 2.02, 9.01
- 2014-02-20 0001078271-14-000014 — 5.02, 9.01
- 2014-02-18 0001078271-14-000010 — 5.02
- 2014-02-05 0001078271-14-000006 — 2.02, 9.01
- 2014-01-13 0001104659-14-002030 — 9.01 — amendment of 0001078271-13-000058
- 2013-11-25 0001078271-13-000081 — 5.07
- 2013-11-07 0001078271-13-000064 — 5.02, 9.01
- 2013-11-04 0001078271-13-000060 — 2.02, 9.01
- 2013-11-01 0001078271-13-000058 — 1.01, 2.01, 2.03, 8.01, 9.01
- 2013-10-16 0001078271-13-000056 — 8.01, 9.01
- 2013-09-13 0001078271-13-000052 — 1.01, 8.01, 9.01
- 2013-08-23 0001078271-13-000044 — 5.02, 9.01
- 2013-08-02 0001078271-13-000042 — 5.02
- 2013-07-30 0001078271-13-000039 — 2.02, 9.01
- 2013-07-30 0001078271-13-000037 — 5.02, 9.01
- 2013-06-21 0001078271-13-000032 — 8.01
- 2013-05-01 0001078271-13-000018 — 5.02, 9.01
- 2013-04-30 0001078271-13-000015 — 2.02, 9.01
- 2013-03-01 0001078271-13-000010 — 8.01
- 2013-02-19 0001078271-13-000008 — 5.02
- 2013-01-30 0001078271-13-000004 — 2.02, 9.01
- 2013-01-07 0001078271-13-000002 — 1.01, 2.02, 2.03, 2.05, 9.01
- 2012-12-03 0001078271-12-000094 — 5.02, 5.07, 8.01
- 2012-10-31 0001078271-12-000071 — 2.02, 9.01
- 2012-10-19 0001078271-12-000069 — 1.01, 2.03, 9.01
- 2012-10-16 0001078271-12-000067 — 8.01
- 2012-10-01 0001193125-12-411392 — 5.02, 8.01, 9.01
- 2012-09-24 0001193125-12-401798 — 5.02, 9.01
- 2012-09-21 0001193125-12-399896 — 5.02, 9.01
- 2012-09-18 0001193125-12-394379 — 1.01, 5.02, 9.01
- 2012-09-12 0001193125-12-388591 — 8.01
- 2012-08-27 0001078271-12-000057 — 8.01
- 2012-08-03 0001078271-12-000041 — 7.01, 9.01
- 2012-08-01 0001078271-12-000039 — 2.02, 9.01
- 2012-07-25 0001078271-12-000037 — 8.01
- 2012-05-22 0001078271-12-000033 — 5.02, 9.01
- 2012-05-21 0001078271-12-000030 — 8.01
- 2012-05-09 0001078271-12-000028 — 5.02, 9.01
- 2012-05-02 0001078271-12-000023 — 2.02, 9.01
- 2012-04-30 0001078271-12-000020 — 3.03, 5.07, 9.01
- 2012-04-19 0001078271-12-000012 — 2.02, 5.02, 9.01
- 2012-03-12 0001078271-12-000010 — 5.02, 9.01
- 2012-02-24 0001078271-12-000008 — 8.01
- 2012-02-02 0001078271-12-000004 — 2.02, 9.01
- 2012-01-30 0001078271-12-000002 — 1.01
- 2011-12-01 0001078271-11-000104 — 8.01
- 2011-11-08 0001078271-11-000099 — 8.01
- 2011-11-02 0001078271-11-000094 — 2.02, 9.01
- 2011-10-24 0001078271-11-000089 — 8.01, 9.01
- 2011-10-11 0001078271-11-000085 — 8.01
- 2011-09-29 0001078271-11-000082 — 8.01
- 2011-09-15 0001078271-11-000070 — 5.02, 9.01
- 2011-08-11 0001078271-11-000058 — 8.01
- 2011-08-10 0001078271-11-000055 — 5.02
- 2011-08-08 0001078271-11-000045 — 5.02
- 2011-08-01 0001078271-11-000038 — 2.02, 9.01
- 2011-07-14 0001078271-11-000036 — 2.02, 2.05, 9.01
- 2011-07-12 0001078271-11-000034 — 8.01
- 2011-07-01 0001078271-11-000032 — 5.02
- 2011-06-16 0001078271-11-000030 — 8.01
- 2011-05-06 0001078271-11-000027 — 8.01, 9.01
- 2011-05-04 0001078271-11-000025 — 8.01
- 2011-04-28 0001078271-11-000020 — 2.02, 9.01
- 2011-04-27 0001078271-11-000018 — 3.03, 5.02, 5.03, 9.01
- 2011-04-11 0001078271-11-000016 — 2.02
- 2011-03-31 0001078271-11-000014 — 5.02, 5.03
- 2011-03-15 0001193125-11-066049 — 5.02, 9.01
- 2011-03-01 0001193125-11-052048 — 5.02, 9.01
- 2011-02-10 0001078271-11-000012 — 7.01, 9.01
- 2011-01-31 0001078271-11-000005 — 2.02, 5.02, 5.03, 9.01
- 2010-12-23 0001193125-10-287613 — 8.01
- 2010-12-17 0001193125-10-283495 — 5.03, 5.07, 8.01, 9.01
- 2010-11-10 0001193125-10-255861 — 4.01, 9.01
- 2010-11-01 0001193125-10-242706 — 2.02, 9.01
- 2010-10-14 0001193125-10-229518 — 1.01, 9.01
- 2010-10-06 0001193125-10-224863 — 5.02, 8.01
- 2010-09-29 0001193125-10-219705 — 1.01, 8.01
- 2010-09-08 0001193125-10-206782 — 5.02, 8.01, 9.01
- 2010-08-25 0001193125-10-196951 — 8.01
- 2010-08-09 0001193125-10-182573 — 7.01, 8.01, 9.01
- 2010-08-03 0001193125-10-175255 — 5.02, 8.01, 9.01
- 2010-08-02 0001193125-10-173697 — 2.02, 8.01, 9.01
- 2010-07-30 0001193125-10-172214 — 5.02, 8.01, 9.01
- 2010-07-22 0001193125-10-163896 — 8.01, 9.01
- 2010-07-20 0001193125-10-161832 — 5.02
- 2010-07-12 0001193125-10-157291 — 2.02, 9.01
- 2010-07-01 0001193125-10-152746 — 3.03, 9.01
- 2010-05-10 0001193125-10-114669 — 5.02, 9.01
- 2010-04-26 0001193125-10-093310 — 2.02, 9.01
- 2010-03-19 0001193125-10-061679 — 5.02, 9.01
- 2010-02-16 0001193125-10-032335 — 5.02
- 2010-02-01 0001193125-10-018202 — 2.02, 9.01
- 2010-01-29 0001193125-10-017165 — 5.02
- 2010-01-11 0001193125-10-004099 — 8.01
- 2009-10-26 0001193125-09-213846 — 2.02, 9.01 — amendment of 0001193125-09-213780
- 2009-10-26 0001193125-09-213780 — 2.02, 9.01
- 2009-10-23 0001193125-09-212871 — 2.05, 5.02, 8.01, 9.01
- 2009-10-05 0001193125-09-203522 — 2.02, 9.01
- 2009-08-04 0001193125-09-163799 — 5.02, 9.01
- 2009-07-31 0001193125-09-160772 — 5.02, 9.01
- 2009-07-30 0001193125-09-159578 — 2.02, 9.01
- 2009-07-20 0001193125-09-151500 — 5.02, 9.01
- 2009-07-08 0001193125-09-145840 — 5.02, 9.01
- 2009-05-12 0001193125-09-108340 — 5.02, 9.01
- 2009-04-23 0001193125-09-085849 — 2.02, 9.01
- 2009-03-26 0001193125-09-064502 — 2.05
- 2009-01-28 0001193125-09-013182 — 2.02, 9.01
- 2008-11-06 0001193125-08-227572 — 2.02, 9.01
- 2008-11-03 0001193125-08-222501 — 5.02
- 2008-08-11 0001193125-08-173590 — 5.02
- 2008-08-11 0001193125-08-172587 — 8.01, 9.01
- 2008-08-06 0001193125-08-167934 — 2.02, 9.01
- 2008-08-04 0001193125-08-164673 — 5.02, 9.01
- 2008-05-21 0001193125-08-119640 — 7.01, 9.01
- 2008-04-29 0001193125-08-095270 — 2.02, 9.01
- 2008-03-05 0001193125-08-047893 — 8.01
- 2008-02-19 0001193125-08-033702 — 5.02
- 2008-02-05 0001193125-08-019969 — 5.02
- 2008-01-30 0001193125-08-015378 — 2.02, 9.01
- 2007-12-27 0001193125-07-272178 — 5.03, 9.01
- 2007-10-29 0001193125-07-228368 — 2.02, 9.01
- 2007-10-25 0001193125-07-225906 — 5.02, 9.01
- 2007-10-19 0001193125-07-221578 — 5.02
- 2007-09-26 0001193125-07-207348 — 8.01
- 2007-08-07 0001193125-07-172810 — 2.02, 9.01
- 2007-08-06 0001193125-07-172147 — 5.02, 9.01
- 2007-08-06 0001193125-07-172134 — 3.01
- 2007-07-09 0001193125-07-151467 — 3.01, 9.01
- 2007-06-28 0001193125-07-145519 — 2.02, 9.01
- 2007-06-27 0001193125-07-143262 — 2.05, 3.01, 5.02
- 2007-05-18 0001193125-07-118804 — 3.01, 9.01
- 2007-05-02 0001193125-07-099280 — 2.02, 9.01
- 2007-03-29 0001193125-07-068815 — 5.02, 9.01
- 2007-02-22 0001193125-07-037181 — 3.01, 9.01
- 2007-02-08 0001193125-07-024194 — 5.02
- 2007-01-30 0001193125-07-016428 — 2.02, 9.01
- 2007-01-11 0001193125-07-004825 — 4.02, 9.01
- 2006-11-21 0001193125-06-240068 — 5.02, 9.01
- 2006-11-16 0001193125-06-237262 — 3.01, 9.01
- 2006-11-01 0001193125-06-220707 — 2.02, 9.01
- 2006-10-31 0001193125-06-219237 — 1.01, 1.02, 5.02, 5.03, 8.01, 9.01
- 2006-09-28 0001193125-06-198185 — 3.01, 9.01
- 2006-09-15 0001193125-06-191640 — 7.01, 9.01
- 2006-09-05 0001193125-06-185202 — 5.02, 9.01
- 2006-08-08 0001193125-06-165953 — 1.01, 2.02, 5.02, 9.01
- 2006-07-18 0001193125-06-148526 — 1.01
- 2006-07-10 0001193125-06-143989 — 5.02, 9.01
- 2006-05-16 0001193125-06-113698 — 5.02, 9.01
- 2006-05-01 0001193125-06-094919 — 2.02, 9.01
- 2006-04-26 0001193125-06-089397 — 1.01, 9.01
- 2006-04-07 0001193125-06-075723 — 2.02, 9.01
- 2006-02-13 0001193125-06-029073 — 1.01
- 2006-01-31 0001193125-06-016143 — 1.01
- 2006-01-30 0001193125-06-015165 — 2.02, 9.01
- 2005-12-08 0001193125-05-239157 — 1.01, 1.02, 9.01
- 2005-11-01 0001193125-05-213101 — 2.02, 9.01
- 2005-09-29 0001193125-05-193991 — 1.01, 2.02, 9.01 — amendment of 0001193125-05-162807
- 2005-08-09 0001193125-05-162807 — 1.01, 2.02, 9.01
- 2005-07-14 0001193125-05-142162 — 8.01
- 2005-06-28 0001193125-05-133050 — 1.01, 9.01
- 2005-04-18 0001193125-05-077946 — 2.02, 7.01, 9.01
- 2005-04-14 0001193125-05-076665 — 2.02, 7.01, 9.01
- 2005-01-25 0001193125-05-011466 — 2.02, 9.01
- 2004-12-07 0001193125-04-208693 — 3.01
- 2004-10-26 0001193125-04-178370 — 2.02, 9.01
- 2004-10-04 0001193125-04-166289 — 5.02, 9.01
- 2004-07-28 0001193125-04-126135 — 12, 7
- 2004-05-12 0001193125-04-086287 — 12
- 2004-04-21 0001193125-04-066557 — 12, 7
- 2004-01-22 0001193125-04-007359 — 12, 7
- 2003-12-18 0001193125-03-096351 — 5, 7
- 2003-11-04 0001193125-03-072069 — 5, 7
- 2003-10-24 0001193125-03-066551 — 12, 7
- 2003-07-25 0001193125-03-024087 — 7, 9
- 2003-04-11 0001012870-03-001706 — 7, 9
- 2003-04-08 0001021408-03-005743 — 7, 9
- 2003-01-07 0001012870-03-000039 — 5, 7
- 2002-04-29 0001012870-02-002003 — 5, 7
- 2002-02-20 0001012870-02-000792 — 5, 7
- 2001-12-13 0001012870-01-503160 — 5, 7
- 2001-11-30 0001012870-01-503010 — 5, 7
- 2001-11-02 0001012870-01-502580 — 5
- 2001-10-23 0001021408-01-508589 — 5, 7
- 2001-06-07 0001021408-01-501772 — 5, 7 — amendment of 0001021408-01-500975
- 2001-05-15 0001021408-01-501104 — 5 — amendment of 0001021408-01-500975
- 2001-05-14 0001021408-01-500975 — 5, 7
- 2001-04-06 0001012870-01-500065 — 5, 7

## late-filing notifications on or before 2020-01-30

- 2008-05-12 0001193125-08-111540 — NT 10-Q, for the period ended 2008-03-30
- 2007-05-10 0001193125-07-110075 — NT 10-Q, for the period ended 2007-04-01
- 2007-02-09 0001193125-07-025490 — NT 10-Q, for the period ended 2006-12-31
- 2006-11-13 0001193125-06-232090 — NT 10-Q, for the period ended 2006-10-01
- 2006-09-15 0001193125-06-191838 — NT 10-K, for the period ended 2006-07-02

## item 2.02 — earnings release, exhibit 99.1

[0001564590-20-002375:8k_2_02:1]
EX-99.1
2
extr-ex991_6.htm
EX-99.1

[0001564590-20-002375:8k_2_02:2]
extr-ex991_6.htm

[0001564590-20-002375:8k_2_02:3]
Exhibit 99.1

[0001564590-20-002375:8k_2_02:4]
FOR IMMEDIATE RELEASE

[0001564590-20-002375:8k_2_02:5]
| For more information, contact: |  |  |  |  |  |  |
| Investor Relations |  |  |  | Media Contact |  |
| Stan Kovler |  |  |  | Christi Nicolacopoulos |
| 919/595-4196 |  |  |  | 603/952-5005 |  |
| Investor_relations@extremenetworks.com |  |  |  | pr@extremenetworks.com |

[0001564590-20-002375:8k_2_02:6]
Extreme Networks Reports Second Quarter Fiscal Year 2020 Financial Results

[0001564590-20-002375:8k_2_02:7]
Announces Completion of $30 Million Accelerated Share Repurchase Program

[0001564590-20-002375:8k_2_02:8]
Conference Call at 8:00 a.m. EST

[0001564590-20-002375:8k_2_02:9]
SAN JOSE, Calif., January 29, 2020 -- Extreme Networks, Inc. (“Extreme”) (Nasdaq: EXTR) today released financial results for its fiscal second quarter ended December 31, 2019.

[0001564590-20-002375:8k_2_02:10]
Fiscal Second Quarter Results:

[0001564590-20-002375:8k_2_02:11]
|  | • | Revenue $267.5 million, up 6% year-over-year and up 5% quarter-over-quarter |

[0001564590-20-002375:8k_2_02:12]
|  | • | GAAP EPS $(0.20), down $(0.26) year-over-year and up $0.11 quarter-over-quarter |

[0001564590-20-002375:8k_2_02:13]
|  | • | Non-GAAP EPS $0.13, flat year-over-year and up $0.05 quarter-over-quarter |

[0001564590-20-002375:8k_2_02:14]
|  | • | GAAP gross margin 55.6% compared to 55.9% in Q2 last year |

[0001564590-20-002375:8k_2_02:15]
|  | • | Non-GAAP gross margin 60.0% compared to 58.2% in Q2 last year |

[0001564590-20-002375:8k_2_02:16]
|  | • | GAAP operating margin (5.7)% compared to 1.9% in Q2 last year |

[0001564590-20-002375:8k_2_02:17]
|  | • | Non-GAAP operating margin 9.0%, compared to 8.0% in Q2 last year |

[0001564590-20-002375:8k_2_02:18]
|  | • | Net cash provided by operating activities was $22.1 million |

[0001564590-20-002375:8k_2_02:19]
|  | • | Free Cash Flow of $17.9 million |

[0001564590-20-002375:8k_2_02:20]
“Our Q2 Non-GAAP EPS of $0.13 was the result of achieving our long-standing Non-GAAP gross margin target of 60% for the first time in Extreme’s history and growing operating margin both year-over-year and quarter-over-quarter. We made progress in the integration of Aerohive Networks and in extracting related synergies. Nevertheless, Q2 revenue fell short of our guidance expectations owing to weakness in US public sector and Asia Pacific,” stated Ed Meyercord, President and CEO of Extreme Networks.

[0001564590-20-002375:8k_2_02:21]
Meyercord added, “We executed a $30 million accelerated share repurchase program during the quarter, reflecting opportunistic action by our Board of Directors and demonstrating our ongoing commitment to drive shareholder value and minimize dilution from our equity programs.  We remain confident in our ability to execute our long-term strategy and will continue to use share repurchases as a vehicle to create value for our shareholders.”

[0001564590-20-002375:8k_2_02:22]
Meyercord also announced significant changes to Extreme’s sales organization. “We are very focused on driving growth in our business through increased efficiency and sales productivity.  We’ve made changes to streamline operations as we head into the second half of 2020. I am confident that these changes, along

[0001564590-20-002375:8k_2_02:23]
with the refresh and stratification of our product portfolio, will enhance our go-to-market efforts and allow us to drive further gross margins.”

[0001564590-20-002375:8k_2_02:24]
“With our revised guidance we now expect to achieve Non-GAAP operating income margins in the 12-13% range by the end of fiscal year 2020.  We expect to attain organic growth and our 15% Non-GAAP long term operating margin target in the second half of calendar year 2020.  We are confident in our guidance and the execution of our plan based on the growing strength of our enterprise franchise in the market, the market migration to cloud-based networking and our leadership position, our execution on delivering our cloud platform, growth opportunities with 5G and other ecosystem partners, and a clear path to margin expansion from structurally higher gross margins and expense reductions,” concluded Meyercord.

[0001564590-20-002375:8k_2_02:25]
Recent Key Highlights:

[0001564590-20-002375:8k_2_02:26]
|  | • | During the second quarter of Fiscal Year 2020, Extreme initiated a $30 million Accelerated Share Repurchase Program “ASR” with Bank of America with 3.85 million shares initially delivered to Extreme. The ASR was funded using the Company’s working capital. As of December 31, 2019, Extreme Networks had 118.4 million shares of common stock outstanding. On January 28, 2020, the program settled with approximately 382,000 additional shares. Total average price of the share repurchases was $7.09. |

[0001564590-20-002375:8k_2_02:27]
|  | • | The School District of Palm Beach County has standardized on ExtremeSwitching, ExtremeWireless, and Extreme Management Center to centrally, simply, and securely manage connectivity and device access throughout the tech-forward district. The technology will be deployed alongside existing Aerohive (now Extreme) access points. Palm Beach County has the tenth-largest public-school district in the United States, and the fifth-largest school district in Florida, with 180 schools, 193,000 students and 22,340 employees, including more than 12,900 teachers. |

[0001564590-20-002375:8k_2_02:28]
|  | • | Init7, a Swiss provider of broadband Internet, IP-TV and IP Wholesale, will deploy Extreme Networks solutions throughout its international IP backbone as part of a global network refresh. ExtremeRouting SLX 9640s will enable Init7 to offer 100G services from 45 company-owned points of presence (PoPs) in Switzerland, elsewhere in Europe, and America. |

[0001564590-20-002375:8k_2_02:29]
|  | • | UC Health, a collaboration between University of Cincinnati Physicians, University of Cincinnati Medical Center, Drake and West Chester Hospital, has deployed Extreme’s campus fabric solution, including Extreme Fabric Connect, Fabric Attach, Extreme Management Center, and ExtremeControl software. The Extreme-powered network enables the health system to connect, segment, and secure a growing volume of connected medical and consumer IoT devices, and will eventually support HVAC and lighting, across four inpatient campuses and 58 outpatient locations. It also allows for rapid onboarding of new buildings, systems, and devices as the health system expands. |

[0001564590-20-002375:8k_2_02:30]
|  | • | Hills Limited, a publicly traded Australian B2B solutions provider in the building technologies sector, has deployed Extreme networking solutions across 20 sites, including ExtremeSwitching, ExtremeAnalytics, Extreme Management Center and ExtremeControl software, replacing its |

[0001564590-20-002375:8k_2_02:31]
|  |  | legacy network infrastructure to bring the management of its voice and data network in-house and accelerate adoption of cloud-based services. |

[0001564590-20-002375:8k_2_02:32]
|  | • | The National Football League's Tennessee Titans have upgraded to Extreme's industry-leading Wi-Fi 6 solutions, including ExtremeWireless and ExtremeAnalytics, providing tens of thousands of fans with faster speeds and higher-performance connectivity on game day. |

[0001564590-20-002375:8k_2_02:33]
|  | • | Extreme announced availability of Extreme Retail Select curated cloud technology packages designed to remove the cost and complexity associated with selecting, buying, building, deploying, and managing network services at retail locations. The turn-key network solutions give retail chains and franchises the ability to quickly and easily automate set-up and management of network connectivity from one to thousands of sites, maximize operational efficiencies, and deliver consistent services and experiences at scale. With Extreme Retail Select, we developed a unique interface to deliver end user data, such as dwell times, loyalty information, and site flow that supports marketing and sales initiatives to drive better business outcomes. |

[0001564590-20-002375:8k_2_02:34]
|  | • | Extreme introduced new capabilities for its Extreme Fabric Automation software designed to augment enterprise IT teams and reduce human error. The solution automatically manages the validation, testing, and operation of data center fabric networks while providing critically important network reliability and resiliency. Extreme also announced availability of two new high-performance switches embedded with guest VMs – the SLX 9150 leaf switch and the SLX 9250 spine switch. |

[0001564590-20-002375:8k_2_02:35]
|  | • | Extreme announced it was named an October 2019 Gartner Peer Insights Customers' Choice for Data Center Networking. The company received a 4.7 out of 5 rating among customers across many different verticals. This is the second consecutive year Extreme Networks was recognized by its customers as a Gartner Peer Insights Customers' Choice in this category. |

[0001564590-20-002375:8k_2_02:36]
Gartner Peer Insights Customers’ Choice constitute the subjective opinions of individual end-user reviews, ratings, and data applied against a documented methodology; they neither represent the views of, nor constitute an endorsement by, Gartner or its affiliates.

[0001564590-20-002375:8k_2_02:37]
Fiscal Q2 2020 Financial Metrics:

[0001564590-20-002375:8k_2_02:38]
(in millions, except percentages and per share information)

[0001564590-20-002375:8k_2_02:39]
|  |  | Q2 FY'20 |  |  | Q2 FY'19 |  |  | Change |  |
| GAAP Results of Operations |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 190.5 |  |  | $ | 189.6 |  |  | $ | 0.9 |  |  | -% |  |
| Service |  |  | 77.0 |  |  |  | 63.1 |  |  |  | 13.9 |  |  |  | 22 | % |
| Total Net Revenue |  | $ | 267.5 |  |  | $ | 252.7 |  |  | $ | 14.8 |  |  |  | 6 | % |
| Gross Margin |  |  | 55.6 | % |  |  | 55.9 | % |  | -30 bps |  |  | - |  |
| Operating Margin |  |  | (5.7 | )% |  |  | 1.9 | % |  | -760 bps |  |  | - |  |
| Net Income (Loss) |  | $ | (23.5 | ) |  | $ | 7.2 |  |  | $ | (30.7 | ) |  |  | 426 | % |
| Income (loss) per diluted share |  | $ | (0.20 | ) |  | $ | 0.06 |  |  | $ | (0.26 | ) |  |  | 433 | % |
| Non-GAAP Results of Operations |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 190.5 |  |  | $ | 189.6 |  |  | $ | 0.9 |  |  | -% |  |
| Service |  |  | 77.0 |  |  |  | 63.1 |  |  |  | 13.9 |  |  |  | 22 | % |
| Total Net Revenue |  | $ | 267.5 |  |  | $ | 252.7 |  |  | $ | 14.8 |  |  |  | 6 | % |
| Gross Margin |  |  | 60.0 | % |  |  | 58.2 | % |  | 180 bps |  |  | - |  |
| Operating Margin |  |  | 9.0 | % |  |  | 8.0 | % |  | 100 bps |  |  | - |  |
| Net Income |  | $ | 15.8 |  |  | $ | 15.5 |  |  | $ | 0.3 |  |  |  | 2 | % |
| Income per diluted share |  | $ | 0.13 |  |  | $ | 0.13 |  |  | $ | - |  |  |  | — |  |

[0001564590-20-002375:8k_2_02:40]
|  | • | Q2 ending cash and cash equivalents balance was $140.4 million, an increase of $9.0 million from Q1, this was primarily driven by operating cash flow generation of $22.1 million and investing activity cash flow generation of $25.5 million, including $29.7 million of proceeds from sales and maturities of short-term investments, offset by cash usage of $38.7 million for financing activities, including $30.0 million applied to the accelerated share repurchase program. |

[0001564590-20-002375:8k_2_02:41]
|  | • | Q2 Accounts Receivable balance was $159.8 million, with days sales outstanding of 55, the same as Q1 and an increase of 2 days from Q2 last year. |

[0001564590-20-002375:8k_2_02:42]
|  | • | Q2 ending inventory was $79.7 million, a decrease of $2.7 million from Q1 and an increase of $21.4 million from Q2 last year. The year-over-year increase in inventory largely reflects advanced purchases ahead of rising tariffs, new products, and to a lesser extent, the addition of Aerohive Networks inventory. |

[0001564590-20-002375:8k_2_02:43]
|  | • | Q2 ending gross debt was $375.3 million, a decrease of $4.7 million from Q1 and an increase of $190.0 million from Q2 last year following the refinancing of our debt in Q1 to acquire Aerohive Networks in August 2019. Net Debt* of $234.9 million increased by $16.0 million from $218.9 million in Q1. |

[0001564590-20-002375:8k_2_02:44]
Extreme uses the non-GAAP free cash flow metric as a measure of operating performance. Free cash flow represents GAAP operating cash flows less purchases of property, plant and equipment. Extreme considers free cash flow as useful information for management and investors regarding the amount of cash generated by the business after the purchases of property, plant, and equipment, which can then be used to, among other things, invest in Extreme’s business, make strategic acquisitions, and strengthen the balance sheet. A limitation of the utility of the non-GAAP free cash flow metric as a measure of financial performance is that it does not represent the total increase or decrease in the Company's cash balance for the period. As shown in the table below (in thousands):

[0001564590-20-002375:8k_2_02:45]
| Free Cash Flow | Three Months Ended |  |  | Six Months Ended |  |
|  | December 31, 2019 |  |  | December 31, 2018 |  |  | December 31, 2019 |  |  | December 31, 2018 |  |
| Cash flow provided by operations | $ | 22,112 |  |  | $ | 27,281 |  |  | $ | 21,911 |  |  | $ | 61,611 |  |
| Less: PP&E CapEx spending |  | (4,198 | ) |  |  | (3,723 | ) |  |  | (9,438 | ) |  |  | (11,140 | ) |
| Total free cash flow | $ | 17,914 |  |  | $ | 23,558 |  |  | $ | 12,473 |  |  | $ | 50,471 |  |

[0001564590-20-002375:8k_2_02:46]
*Net Debt is defined as gross debt minus cash: as shown in the table below (in millions):

[0001564590-20-002375:8k_2_02:47]
| Gross debt |  |  | Cash |  |  | Net debt |  |
| $ | 375.3 |  |  | $ | 140.4 |  |  | $ | 234.9 |  |

[0001564590-20-002375:8k_2_02:48]
Business Outlook:

[0001564590-20-002375:8k_2_02:49]
For its third quarter of fiscal 2020, ending March 31, 2020, the Company is targeting:

[0001564590-20-002375:8k_2_02:50]
| (in millions) | Low-End |  |  | High-End |  |
| FQ3'20 Guidance – GAAP |  |  |  |  |  |  |  |
| Total Net Revenue | $ | 255.0 |  |  | $ | 265.0 |  |
| Gross Margin |  | 56.0 | % |  |  | 58.0 | % |
| Operating Expenses | $ | 147.3 |  |  | $ | 154.1 |  |
| Operating Margin |  | (1.8 | %) |  |  | (0.2 | %) |
| Net Loss | $ | (12.8 | ) |  | $ | (8.6 | ) |
| Loss per basic share | $ | (0.11 | ) |  | $ | (0.07 | ) |
| Shares outstanding used in calculating GAAP EPS | 119.4 |  |  | 119.4 |  |
| FQ3’20 Guidance – Non - GAAP |  |  |  |  |  |  |  |
| Total Net Revenue | $ | 255.0 |  |  | $ | 265.0 |  |
| Gross Margin |  | 59.1 | % |  |  | 61.1 | % |
| Operating Expenses | $ | 129.3 |  |  | $ | 135.3 |  |
| Operating Margin |  | 8.4 | % |  |  | 10.0 | % |
| Net Income | $ | 13.1 |  |  | $ | 18.3 |  |
| Income per diluted share | $ | 0.11 |  |  | $ | 0.15 |  |
| Shares outstanding used in calculating Non-GAAP EPS |  | 122.6 |  |  |  | 122.6 |  |

[0001564590-20-002375:8k_2_02:51]
The following table shows the GAAP to non-GAAP reconciliation for Q3 FY’20 guidance:

[0001564590-20-002375:8k_2_02:52]
|  | Gross Margin Rate |  |  | Operating Margin Rate |  |  | Earnings per Share |  |
| GAAP | 56.0% - 58.0% |  |  | (1.8%) - (0.2%) |  |  | ($0.11) - ($0.07) |  |
| Estimated adjustments for: |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of product intangibles | 2.3% |  |  | 2.3% |  |  | $ | 0.05 |  |
| Stock based compensation | 0.3% |  |  | 4.0% |  |  | $ | 0.09 |  |
| Restructuring | - |  |  | 0.2% |  |  | $ | - |  |
| Acquisition and integration costs | 0.1% |  |  | 2.4% |  |  | $ | 0.05 |  |
| Adjustment to acquired inventories | - |  |  | - |  |  | $ | - |  |
| Amortization of non-product intangibles | 0.3% |  |  | 1.2% |  |  | $ | 0.03 |  |
| Non-GAAP | 59.1% - 61.1% |  |  | 8.4% - 10.0% |  |  | $0.11 - $0.15 |  |

[0001564590-20-002375:8k_2_02:53]
The total of percentage rate changes may not equal the total change in all cases due to rounding.

[0001564590-20-002375:8k_2_02:54]
Conference Call:

[0001564590-20-002375:8k_2_02:55]
Extreme will host a conference call at 8:00 a.m. Eastern (5:00 a.m. Pacific) today to review the second fiscal quarter results as well as the business outlook for third fiscal quarter ending March 31, 2020, including significant factors and assumptions underlying the targets noted above. The conference call will be available to the public through a live audio web broadcast via the internet at http://investor.extremenetworks.com and a replay of the call will be available on the website through February 5, 2020. The conference call may also be heard by dialing 1(877) 303-9826 or international 1 (224) 357-2194. Supplemental financial information to be discussed during the conference call will be posted in the Investor Relations section of the Company's website www.extremenetworks.com including the non-GAAP reconciliation attached to this press release. The encore recording can be accessed by dialing 1 (855) 859-2056 or international 1 (404) 537-3406. Conference ID # 2146939. The encore recording will be available for 7 days following the call.

[0001564590-20-002375:8k_2_02:56]
About Extreme Networks:

[0001564590-20-002375:8k_2_02:57]
Extreme Networks, Inc. (EXTR) is the industry’s first cloud-driven, end-to-end enterprise networking company. Our best-of-breed technology solutions, from the wireless and IoT edge to the data center, are flexible, agile, and secure to accelerate the digital transformation of our customers and provide them with the fastest path to the autonomous enterprise. Our 100% in-sourced services and support are number one in the industry. Even with 50,000 customers globally, including half of the Fortune 50 and some of the world's leading names in business, hospitality, retail, transportation and logistics, education, government, healthcare, and manufacturing, we remain nimble and responsive to ensure customer and partner success. We call this Customer-Driven Networking™. Founded in 1996, Extreme is headquartered in San Jose, California. For more information, visit Extreme's website or call 1-888-257-3000.

[0001564590-20-002375:8k_2_02:58]
Extreme Networks, the Extreme Networks logo, ExtremeSwitching, ExtremeWireless, Extreme Management Center, ExtremeRouting, Extreme Fabric Connect, ExtremeAnalytics, ExtremeControl, Extreme Retail Select, and Extreme Fabric Automation, are trademarks of Extreme Networks, Inc. or its subsidiaries in the United States and/or other countries.

[0001564590-20-002375:8k_2_02:59]
Non-GAAP Financial Measures:

[0001564590-20-002375:8k_2_02:60]
Extreme provides all financial information required in accordance with generally accepted accounting principles (“GAAP”). The Company is providing with this press release non-GAAP gross margins, non-GAAP operating margins, non-GAAP operating expenses, non-GAAP net income and non-GAAP

[0001564590-20-002375:8k_2_02:61]
earnings per share. In preparing non-GAAP information, the Company has excluded, where applicable, the impact of share-based compensation, acquisition and integration costs, acquired inventory adjustments, amortization of acquired intangibles, inventory valuation adjustment, restructuring charges, income tax and free cash flow.  The Company believes that excluding these items provides both management and investors with additional insight into its current operations, the trends affecting the Company, the Company's marketplace performance, and the Company's ability to generate cash from operations. Please note the Company's non-GAAP measures may be different than those used by other companies. The additional non-GAAP financial information the Company presents should be considered in conjunction with, and not as a substitute for, the Company's GAAP financial information.

[0001564590-20-002375:8k_2_02:62]
The Company has provided a non-GAAP reconciliation of the results for the periods presented in this release, which are adjusted to exclude certain items as indicated.  These measures should only be used to evaluate the Company's results of operations in conjunction with the corresponding GAAP measures for comparable financial information and understanding of the Company's ongoing performance as a business. Extreme Networks uses both GAAP and non-GAAP measures to evaluate and manage its operations.

[0001564590-20-002375:8k_2_02:63]
Forward Looking Statements:

[0001564590-20-002375:8k_2_02:64]
More information about potential factors that could affect the Company's business and financial results are described in "Management's Discussion and Analysis of Financial Condition and Results of Operations" and "Risk Factors" included in the Company’s Annual Report on Form 10-K for the year ended June 30, 2019 and other documents of the Company on file with the Securities and Exchange Commission (available at www.sec.gov).  Except as required under the U.S. federal securities laws and the rules and regulations of the U.S. Securities and Exchange Commission, Extreme Networks disclaims any obligation to update any forward-looking statements after the date of this release, whether as a result of new information, future events, developments, changes in assumptions or otherwise.

[0001564590-20-002375:8k_2_02:65]
###

[0001564590-20-002375:8k_2_02:66]
EXTREME NETWORKS, INC.

[0001564590-20-002375:8k_2_02:67]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0001564590-20-002375:8k_2_02:68]
(in thousands, except per share amounts)

[0001564590-20-002375:8k_2_02:69]
(Unaudited)

[0001564590-20-002375:8k_2_02:70]
|  |  | December 31, 2019 |  |  | June 30, 2019 |  |
| ASSETS |  |  |  |  |  |  |  |  |
| Current assets: |  |  |  |  |  |  |  |  |
| Cash |  | $ | 140,414 |  |  | $ | 169,607 |  |
| Accounts receivable, net of allowance for doubtful accounts of $1,083 and $1,054 respectively |  |  | 159,790 |  |  |  | 174,414 |  |
| Inventories |  |  | 79,664 |  |  |  | 63,589 |  |
| Prepaid expenses and other current assets |  |  | 37,744 |  |  |  | 34,379 |  |
| Total current assets |  |  | 417,612 |  |  |  | 441,989 |  |
| Property and equipment, net |  |  | 67,938 |  |  |  | 73,554 |  |
| Operating lease right-of-use assets, net |  |  | 57,194 |  |  |  | — |  |
| Intangible assets, net |  |  | 86,740 |  |  |  | 51,112 |  |
| Goodwill |  |  | 330,184 |  |  |  | 138,577 |  |
| Other assets |  |  | 54,985 |  |  |  | 51,642 |  |
| Total assets |  | $ | 1,014,653 |  |  | $ | 756,874 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |  |  |  |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |  |  |  |
| Current portion of long-term debt, net of unamortized debt issuance costs of $7,334 and $1,261, respectively |  | $ | 16,814 |  |  | $ | 9,011 |  |
| Accounts payable |  |  | 65,995 |  |  |  | 65,704 |  |
| Accrued compensation and benefits |  |  | 55,718 |  |  |  | 51,625 |  |
| Accrued warranty |  |  | 16,209 |  |  |  | 14,779 |  |
| Current portion, operating lease liability |  |  | 17,921 |  |  |  | — |  |
| Current portion, deferred revenue, net |  |  | 180,935 |  |  |  | 144,230 |  |
| Other accrued liabilities |  |  | 69,365 |  |  |  | 70,680 |  |
| Total current liabilities |  |  | 422,957 |  |  |  | 356,029 |  |
| Deferred revenue, less current portion |  |  | 96,902 |  |  |  | 59,012 |  |
| Long-term debt, less current portion, net of unamortized debt issuance costs of $7,334 and $1,251, respectively |  |  | 348,916 |  |  |  | 169,739 |  |
| Operating lease liability, less current portion |  |  | 58,598 |  |  |  | — |  |
| Deferred income taxes |  |  | 2,114 |  |  |  | 1,957 |  |
| Other long-term liabilities |  |  | 34,239 |  |  |  | 54,150 |  |
| Commitments and contingencies |  |  | — |  |  |  | — |  |
| Stockholders’ equity: |  |  |  |  |  |  |  |  |
| Convertible preferred stock, $.001 par value, issuable in series, 2,000 shares authorized; none issued |  |  | — |  |  |  | — |  |
| Common stock, $.001 par value, 750,000 shares authorized; 124,616 and 121,538 shares issued, respectively; 118,400 and 119,172 shares outstanding, respectively |  |  | 125 |  |  |  | 122 |  |
| Additional paid-in-capital |  |  | 1,008,176 |  |  |  | 986,772 |  |
| Accumulated other comprehensive loss |  |  | (2,485 | ) |  |  | (2,473 | ) |
| Accumulated deficit |  |  | (914,710 | ) |  |  | (853,434 | ) |
| Treasury stock at cost: 6,216 and 2,366 shares, respectively |  |  | (40,179 | ) |  |  | (15,000 | ) |
| Stockholders’ equity |  |  | 50,927 |  |  |  | 115,987 |  |
| Total liabilities and stockholders’ equity |  | $ | 1,014,653 |  |  | $ | 756,874 |  |

[0001564590-20-002375:8k_2_02:71]
EXTREME NETWORKS, INC.

[0001564590-20-002375:8k_2_02:72]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS

[0001564590-20-002375:8k_2_02:73]
(In thousands, except per share amounts)

[0001564590-20-002375:8k_2_02:74]
(Unaudited)

[0001564590-20-002375:8k_2_02:75]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | December 31, 2019 |  |  | December 31, 2018 |  |  | December 31, 2019 |  |  | December 31, 2018 |  |
| Net revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 190,492 |  |  | $ | 189,567 |  |  | $ | 375,626 |  |  | $ | 367,287 |  |
| Service |  |  | 76,980 |  |  |  | 63,113 |  |  |  | 147,352 |  |  |  | 125,279 |  |
| Total net revenues |  |  | 267,472 |  |  |  | 252,680 |  |  |  | 522,978 |  |  |  | 492,566 |  |
| Cost of revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  |  | 91,387 |  |  |  | 86,487 |  |  |  | 182,778 |  |  |  | 170,030 |  |
| Service |  |  | 27,414 |  |  |  | 24,894 |  |  |  | 54,286 |  |  |  | 49,166 |  |
| Total cost of revenues |  |  | 118,801 |  |  |  | 111,381 |  |  |  | 237,064 |  |  |  | 219,196 |  |
| Gross profit: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  |  | 99,105 |  |  |  | 103,080 |  |  |  | 192,848 |  |  |  | 197,257 |  |
| Service |  |  | 49,566 |  |  |  | 38,219 |  |  |  | 93,066 |  |  |  | 76,113 |  |
| Total gross profit |  |  | 148,671 |  |  |  | 141,299 |  |  |  | 285,914 |  |  |  | 273,370 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Research and development |  |  | 55,380 |  |  |  | 52,204 |  |  |  | 114,496 |  |  |  | 103,445 |  |
| Sales and marketing |  |  | 75,436 |  |  |  | 68,342 |  |  |  | 146,793 |  |  |  | 135,924 |  |
| General and administrative |  |  | 15,098 |  |  |  | 13,886 |  |  |  | 30,080 |  |  |  | 26,657 |  |
| Acquisition and integration costs |  |  | 8,994 |  |  |  | 67 |  |  |  | 24,919 |  |  |  | 2,613 |  |
| Restructuring charges, net of reversals and impairment |  |  | 6,622 |  |  |  | 474 |  |  |  | 12,759 |  |  |  | 1,282 |  |
| Amortization of intangibles |  |  | 2,377 |  |  |  | 1,575 |  |  |  | 4,307 |  |  |  | 3,716 |  |
| Total operating expenses |  |  | 163,907 |  |  |  | 136,548 |  |  |  | 333,354 |  |  |  | 273,637 |  |
| Operating (loss) income |  |  | (15,236 | ) |  |  | 4,751 |  |  |  | (47,440 | ) |  |  | (267 | ) |
| Interest income |  |  | 477 |  |  |  | 643 |  |  |  | 1,144 |  |  |  | 1,037 |  |
| Interest expense |  |  | (6,234 | ) |  |  | (3,066 | ) |  |  | (11,398 | ) |  |  | (6,592 | ) |
| Other (expense) income, net |  |  | (748 | ) |  |  | (399 | ) |  |  | (190 | ) |  |  | 88 |  |
| (Loss) income before income taxes |  |  | (21,741 | ) |  |  | 1,929 |  |  |  | (57,884 | ) |  |  | (5,734 | ) |
| Provision (benefit) for income taxes |  |  | 1,797 |  |  |  | (5,270 | ) |  |  | 3,392 |  |  |  | (3,868 | ) |
| Net (loss) income |  | $ | (23,538 | ) |  | $ | 7,199 |  |  | $ | (61,276 | ) |  | $ | (1,866 | ) |
| Basic and diluted net (loss) income per share: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net (loss) income per share - basic |  | $ | (0.20 | ) |  | $ | 0.06 |  |  | $ | (0.51 | ) |  | $ | (0.02 | ) |
| Net (loss) income per share - diluted |  | $ | (0.20 | ) |  | $ | 0.06 |  |  | $ | (0.51 | ) |  | $ | (0.02 | ) |
| Shares used in per share calculation - basic |  |  | 119,555 |  |  |  | 117,544 |  |  |  | 119,891 |  |  |  | 117,456 |  |
| Shares used in per share calculation - diluted |  |  | 119,555 |  |  |  | 119,544 |  |  |  | 119,891 |  |  |  | 117,456 |  |

[0001564590-20-002375:8k_2_02:76]
EXTREME NETWORKS, INC.

[0001564590-20-002375:8k_2_02:77]
CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS

[0001564590-20-002375:8k_2_02:78]
(In thousands)

[0001564590-20-002375:8k_2_02:79]
(Unaudited)

[0001564590-20-002375:8k_2_02:80]
|  |  | Six Months Ended |  |
|  |  | December 31, 2019 |  |  | December 31, 2018 |  |
| Cash flows from operating activities: |  |  |  |  |  |  |  |  |
| Net loss |  | $ | (61,276 | ) |  | $ | (1,866 | ) |
| Adjustments to reconcile net loss to net cash provided by operating activities: |  |  |  |  |  |  |  |  |
| Depreciation |  |  | 14,251 |  |  |  | 13,476 |  |
| Amortization of intangible assets |  |  | 17,772 |  |  |  | 13,552 |  |
| Reduction in carrying amount of right-of-use asset |  |  | 8,477 |  |  |  | - |  |
| Provision for doubtful accounts |  |  | 626 |  |  |  | 861 |  |
| Share-based compensation |  |  | 19,792 |  |  |  | 15,525 |  |
| Deferred income taxes |  |  | 801 |  |  |  | (6,516 | ) |
| Non-cash restructuring and impairment charges |  |  | 7,622 |  |  |  | - |  |
| Unrealized/realized gain on equity investment |  |  | - |  |  |  | 274 |  |
| Non-cash interest expense |  |  | 1,982 |  |  |  | 1,532 |  |
| Other |  |  | 735 |  |  |  | (344 | ) |
| Changes in operating assets and liabilities, net of acquisitions |  |  |  |  |  |  |  |  |
| Accounts receivable |  |  | 25,751 |  |  |  | 66,568 |  |
| Inventories |  |  | 3,157 |  |  |  | 5,570 |  |
| Prepaid expenses and other assets |  |  | (274 | ) |  |  | (12,390 | ) |
| Accounts payable |  |  | (9,070 | ) |  |  | (40,050 | ) |
| Accrued compensation and benefits |  |  | (3,036 | ) |  |  | (3,851 | ) |
| Operating lease liabilities |  |  | (9,051 | ) |  |  | - |  |
| Deferred revenue |  |  | 6,181 |  |  |  | 11,568 |  |
| Other current and long-term liabilities |  |  | (2,529 | ) |  |  | (2,298 | ) |
| Net cash provided by operating activities |  |  | 21,911 |  |  |  | 61,611 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |
| Capital expenditures |  |  | (9,438 | ) |  |  | (11,140 | ) |
| Business acquisitions, net of cash acquired |  |  | (219,458 | ) |  |  | — |  |
| Maturities and sales of investments |  |  | 45,249 |  |  |  | 727 |  |
| Net cash used in investing activities |  |  | (183,647 | ) |  |  | (10,413 | ) |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |
| Borrowings under Term Loan |  |  | 199,500 |  |  |  | — |  |
| Loan fees on borrowings |  |  | (10,514 | ) |  |  | (545 | ) |
| Equity forward contract |  |  | (4,821 | ) |  |  | — |  |
| Repayments of debt |  |  | (24,950 | ) |  |  | (14,933 | ) |
| Repurchase of common stock |  |  | (25,179 | ) |  |  | (15,000 | ) |
| Proceeds from issuance of common stock, net of tax withholding |  |  | 2,906 |  |  |  | 5,005 |  |
| Payment of contingent consideration obligations |  |  | (2,000 | ) |  |  | (3,856 | ) |
| Deferred payments on an acquisition |  |  | (2,206 | ) |  |  | (2,000 | ) |
| Net cash provided by (used in) financing activities |  |  | 132,736 |  |  |  | (31,329 | ) |
| Foreign currency effect on cash |  |  | (193 | ) |  |  | (365 | ) |
| Net (decrease) increase in cash |  |  | (29,193 | ) |  |  | 19,504 |  |
| Cash and cash equivalents at beginning of period |  |  | 169,607 |  |  |  | 121,139 |  |
| Cash and cash equivalents at end of period |  | $ | 140,414 |  |  | $ | 140,643 |  |

[0001564590-20-002375:8k_2_02:81]
Extreme Networks, Inc.

[0001564590-20-002375:8k_2_02:82]
Non-GAAP Measures of Financial Performance

[0001564590-20-002375:8k_2_02:83]
To supplement the Company's condensed consolidated financial statements presented in accordance with U.S. generally accepted accounting principles, ("GAAP"), Extreme Networks uses non-GAAP measures of certain components of financial performance.  These non-GAAP measures include non-GAAP net income, non-GAAP gross margin, non-GAAP operating expenses, non-GAAP operating income, non-GAAP earnings per diluted share and Free Cash Flow.

[0001564590-20-002375:8k_2_02:84]
Reconciliation to the nearest GAAP measure of all historical non-GAAP measures included in this press release can be found in the tables included with this press release.  In this press release, Extreme Networks also presents its target for non-GAAP expenses, which is expenses less share-based compensation expense, acquisition and integration costs, acquired inventory adjustments, restructuring charges, amortization of acquired intangibles, inventory valuation adjustments, income tax and free cash flow.

[0001564590-20-002375:8k_2_02:85]
Non-GAAP measures presented in this press release are not in accordance with or alternative measures prepared in accordance with GAAP and may be different from non-GAAP measures used by other companies.  In addition, these non-GAAP measures are not based on any comprehensive set of accounting rules or principles.  Non-GAAP measures have limitations in that they do not reflect all of the amounts associated with Extreme Networks' results of operations as determined in accordance with GAAP.  These non-GAAP measures should only be used to evaluate Extreme Networks' results of operations in conjunction with the corresponding GAAP measures.

[0001564590-20-002375:8k_2_02:86]
Extreme believes these non-GAAP measures when shown in conjunction with the corresponding GAAP measures enhance investors' and management's overall understanding of the Company's current financial performance and the Company's prospects for the future, including cash flows available to pursue opportunities to enhance stockholder value.  In addition, because Extreme Networks has historically reported certain non-GAAP results to investors, the Company believes the inclusion of non-GAAP measures provides consistency in the Company's financial reporting.

[0001564590-20-002375:8k_2_02:87]
For its internal planning process, and as discussed further below, Extreme's management uses financial statements that do not include share-based compensation expense, acquisition and integration costs, acquired inventory adjustment, amortization of intangibles, inventory valuation adjustments, restructuring charges, leased asset impairments, income tax and free cash flow.  Extreme’s management also uses non-GAAP measures, in addition to the corresponding GAAP measures, in reviewing the Company's financial results.

[0001564590-20-002375:8k_2_02:88]
As described above, Extreme excludes the following items from one or more of its non-GAAP measures when applicable.

[0001564590-20-002375:8k_2_02:89]
Stock-based compensation. Consists of associated expenses for stock options, restricted stock and the Company’s Employee Stock Purchase Plan.  Extreme Networks excludes share-based compensation expenses from its non-GAAP measures primarily because they are non-cash expenses that the Company does not believe are reflective of ongoing cash requirement related to its operating results. Extreme Networks expects to incur share-based compensation expenses in future periods.

[0001564590-20-002375:8k_2_02:90]
Acquired inventory adjustments. Purchase accounting adjustments relating to the mark up of acquired inventory to fair value less disposal costs.

[0001564590-20-002375:8k_2_02:91]
Acquisition and integration costs. Acquisition and integration costs consist of specified compensation charges, software charges, legal and professional fees related to the acquisition of Aerohive in fiscal 2020 and the acquisition of the Campus Fabric and Data Center Businesses in fiscal 2019.  Extreme Networks excludes these expenses since they result from an event that is outside the ordinary course of continuing operations.

[0001564590-20-002375:8k_2_02:92]
Amortization of intangibles. Amortization of intangibles includes the monthly amortization expense of intangible assets such as developed technology, customer relationships, trademarks and order backlog.  The amortization of the developed technology intangible is recorded in product cost of goods sold, while the amortization for the other intangibles are recorded in operating expenses.  Extreme Networks excludes these expenses since they result from an intangible asset and for which the period expense does not impact the operations of the business and are non-cash in nature.

[0001564590-20-002375:8k_2_02:93]
Inventory valuation adjustments. Adjustments relating to the mark down of inventory due to duplication of products lines with acquisition of Aerohive net of recoveries on the sale of inventory marked down in previous quarters.

[0001564590-20-002375:8k_2_02:94]
Restructuring expenses. Restructuring expenses primarily consist of severance costs for employees which have no benefit to continuing operations and impairment of right-of-use assets, long-lived assets and other charges related to excess facilities. Extreme Networks excludes restructuring expenses since they result from events that occur outside of the ordinary course of continuing operations.

[0001564590-20-002375:8k_2_02:95]
Income tax. Income tax adjustment relates to a tax benefit resulting from changes introduced by Tax Reform related to US net operating losses allowing the release of US valuation allowance as well as a separate tax benefit resulting from the release of a foreign valuation allowance given anticipated future profitability.

[0001564590-20-002375:8k_2_02:96]
We do not reflect a tax effect associated with the Non-GAAP operating adjustments as the adjustments are primarily related to the US entity which has a full valuation of various loss carryforward tax attributes.

[0001564590-20-002375:8k_2_02:97]
EXTREME NETWORKS, INC.

[0001564590-20-002375:8k_2_02:98]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS

[0001564590-20-002375:8k_2_02:99]
GAAP TO NON-GAAP RECONCILIATION

[0001564590-20-002375:8k_2_02:100]
(In thousands, except percentages and per share amounts)

[0001564590-20-002375:8k_2_02:101]
(Unaudited)

[0001564590-20-002375:8k_2_02:102]
| Non-GAAP Revenue | Three Months Ended |  |  | Six Months Ended |  |
|  | December 31, 2019 |  |  | December 31, 2018 |  |  | December 31, 2019 |  |  | December 31, 2018 |  |
| Revenue - GAAP Basis | $ | 267,472 |  |  | $ | 252,680 |  |  | $ | 522,978 |  |  | $ | 492,566 |  |
| Revenue - Non-GAAP Basis | $ | 267,472 |  |  | $ | 252,680 |  |  | $ | 522,978 |  |  | $ | 492,566 |  |

[0001564590-20-002375:8k_2_02:103]
| Non-GAAP Gross Margin | Three Months Ended |  |  | Six Months Ended |  |
|  | December 31, 2019 |  |  | December 31, 2018 |  |  | December 31, 2019 |  |  | December 31, 2018 |  |
| Gross profit - GAAP Basis | $ | 148,671 |  |  | $ | 141,299 |  |  | $ | 285,914 |  |  | $ | 273,370 |  |
| Gross margin - GAAP Basis percentage |  | 55.6 | % |  |  | 55.9 | % |  |  | 54.7 | % |  |  | 55.5 | % |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Stock based compensation expense |  | 907 |  |  |  | 894 |  |  |  | 1,504 |  |  |  | 1,417 |  |
| Acquired inventory adjustments |  | 3,434 |  |  |  | — |  |  |  | 7,303 |  |  |  | — |  |
| Acquisition and integration costs |  | 1,734 |  |  |  | — |  |  |  | 1,884 |  |  |  | 1,755 |  |
| Amortization of intangibles |  | 6,867 |  |  |  | 4,800 |  |  |  | 13,259 |  |  |  | 9,732 |  |
| Inventory valuation adjustments |  | (1,169 | ) |  |  | — |  |  |  | 3,677 |  |  |  | — |  |
| Total adjustments to GAAP gross profit | $ | 11,773 |  |  | $ | 5,694 |  |  | $ | 27,627 |  |  | $ | 12,904 |  |
| Gross profit - Non-GAAP | $ | 160,444 |  |  | $ | 146,993 |  |  | $ | 313,541 |  |  | $ | 286,274 |  |
| Gross margin - Non-GAAP percentage |  | 60.0 | % |  |  | 58.2 | % |  |  | 60.0 | % |  |  | 58.1 | % |

[0001564590-20-002375:8k_2_02:104]
| Non-GAAP Operating Income | Three Months Ended |  |  | Six Months Ended |  |
|  | December 31, 2019 |  |  | December 31, 2018 |  |  | December 31, 2019 |  |  | December 31, 2018 |  |
| GAAP operating loss | $ | (15,236 | ) |  | $ | 4,751 |  |  | $ | (47,440 | ) |  | $ | (267 | ) |
| GAAP operating loss percentage |  | (5.7 | )% |  |  | 1.9 | % |  |  | (9.1 | )% |  |  | (.1 | )% |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Stock based compensation expense, cost of revenues |  | 907 |  |  |  | 894 |  |  |  | 1,504 |  |  |  | 1,417 |  |
| Stock based compensation expense, R&D |  | 3,260 |  |  |  | 2,797 |  |  |  | 5,695 |  |  |  | 5,139 |  |
| Stock based compensation expense, S&M |  | 3,511 |  |  |  | 2,983 |  |  |  | 7,230 |  |  |  | 5,342 |  |
| Stock based compensation expense, G&A |  | 2,801 |  |  |  | 2,026 |  |  |  | 4,884 |  |  |  | 3,627 |  |
| Inventory valuation adjustments |  | (1,169 | ) |  |  | — |  |  |  | 3,677 |  |  |  | — |  |
| Acquisition and integration costs |  | 10,728 |  |  |  | — |  |  |  | 26,803 |  |  |  | 4,368 |  |
| Restructuring charge, net of reversal |  | 6,622 |  |  |  | 474 |  |  |  | 12,759 |  |  |  | 1,282 |  |
| Acquired inventory adjustments |  | 3,434 |  |  |  | — |  |  |  | 7,303 |  |  |  | — |  |
| Amortization of intangibles |  | 9,244 |  |  |  | 6,375 |  |  |  | 17,566 |  |  |  | 13,448 |  |
| Total adjustments to GAAP operating loss | $ | 39,338 |  |  | $ | 15,549 |  |  | $ | 87,421 |  |  | $ | 34,623 |  |
| Non-GAAP operating income | $ | 24,102 |  |  | $ | 20,300 |  |  | $ | 39,981 |  |  | $ | 34,356 |  |
| Non-GAAP operating income percentage |  | 9.0 | % |  |  | 8.0 | % |  |  | 7.6 | % |  |  | 7.0 | % |

[0001564590-20-002375:8k_2_02:105]
| Non-GAAP Net Income | Three Months Ended |  |  | Six Months Ended |  |
|  | December 31, 2019 |  |  | December 31, 2018 |  |  | December 31, 2019 |  |  | December 31, 2018 |  |
| GAAP net loss | $ | (23,538 | ) |  | $ | 7,199 |  |  | $ | (61,276 | ) |  | $ | (1,866 | ) |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Stock based compensation expense |  | 10,479 |  |  |  | 8,700 |  |  |  | 19,313 |  |  |  | 15,525 |  |
| Inventory valuation adjustments |  | (1,169 | ) |  |  | — |  |  |  | 3,677 |  |  |  | — |  |
| Acquisition and integration costs |  | 10,728 |  |  |  | — |  |  |  | 26,803 |  |  |  | 4,368 |  |
| Restructuring charge, net of reversal |  | 6,622 |  |  |  | 474 |  |  |  | 12,759 |  |  |  | 1,282 |  |
| Acquired inventory adjustments |  | 3,434 |  |  |  | — |  |  |  | 7,303 |  |  |  | — |  |
| Amortization of intangibles |  | 9,244 |  |  |  | 6,375 |  |  |  | 17,566 |  |  |  | 13,448 |  |
| Income tax |  | — |  |  |  | (7,290 | ) |  |  | — |  |  |  | (7,770 | ) |
| Total adjustments to GAAP net loss | $ | 39,338 |  |  | $ | 8,259 |  |  | $ | 87,421 |  |  | $ | 26,853 |  |
| Non-GAAP net income | $ | 15,800 |  |  | $ | 15,458 |  |  | $ | 26,145 |  |  | $ | 24,987 |  |
| Earnings per share |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Non-GAAP net income per share-diluted | $ | 0.13 |  |  | $ | 0.13 |  |  | $ | 0.21 |  |  | $ | 0.21 |  |
| Shares used in net income per share-diluted |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Non-GAAP shares used |  | 123,187 |  |  |  | 119,544 |  |  |  | 123,446 |  |  |  | 119,893 |  |
