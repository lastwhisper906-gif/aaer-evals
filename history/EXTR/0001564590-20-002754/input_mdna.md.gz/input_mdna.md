# EXTR MD&A — 0001564590-20-002754


## mdna

[0001564590-20-002754:mdna:1]
[same as prior period, unchanged from 0001564590-19-039190:mdna:1]

[0001564590-20-002754:mdna:2]
[same as prior period, unchanged from 0001564590-19-039190:mdna:2]

[0001564590-20-002754:mdna:3]
[same as prior period, unchanged from 0001564590-19-039190:mdna:3]

[0001564590-20-002754:mdna:4]
Extreme Networks, Inc., together with its subsidiaries (collectively referred to as “Extreme” and as “we”, “us” and “our”) is a leader in providing cloud-driven networking solutions for enterprise, data center, and service provider customers. Providing a combined end-to-end solution from the IoT edge to the cloud, Extreme designs, develops, and manufactures wired and wireless network infrastructure equipment and develops the software and cloud architecture for network management, policy, intelligence, analytics, security, and assurance.   We were incorporated in California in May 1996 and reincorporated in Delaware in March 1999.  Our corporate headquarters are located in San Jose, California. We derive substantially all of our revenue from the sale of our networking equipment, software, and related maintenance contracts.

[0001564590-20-002754:mdna:5]
Extreme delivers software-driven solutions from the IoT edge to the cloud that are agile, adaptive, and secure to enable autonomous enterprises of the future. We recognize that every customer environment is unique with its own requirements, which may be industry-specific or site driven. We address these distinctions with our Extreme Elements architecture. Elements gives customers and partners the power to mix and match a broad array of software, hardware, and services (including third-party applications) to create a custom network that can be managed and automated from end-to-end and enabled with intelligence and assurance from the cloud. With this strategic asset in place, organizations have the foundation needed to drive both digital transformation and the outcomes impacting each one of us.

[0001564590-20-002754:mdna:6]
Our 100% in-sourced services and support are number one in the industry, and even as we increase the breadth of our portfolio and scale our organization, we remain nimble and responsive to ensure customer and partner success. We are relentless in our commitment to our over 50,000 customers around the world, including over half of the Fortune 50 and some of the world's leading names in business, hospitality, retail, transportation and logistics, education, government, healthcare, and manufacturing, and provide the building blocks that drive competitive advantage, accelerate innovation, and improve the human experience.

[0001564590-20-002754:mdna:7]
[same as prior period, unchanged from 0001564590-19-039190:mdna:7]

[0001564590-20-002754:mdna:8]
Improving the network experience for enterprises that increasingly require greater simplification at the edge or the access layer of the network to ensure business success and provide a secure, unified, wired / wireless infrastructure augmented and managed through a single plane of glass remains a key focus for Extreme. We enhanced our product portfolio in fiscal year 2019 with the launches of our suite of Wi-Fi 6 access points, ExtremeAI software solutions, and Defender for IoT to simplify IoT security. Enterprises have also migrated increasing numbers of applications and services to either private clouds or public clouds offered by third parties and are adopting new IT delivery models and applications that require fundamental network alterations and enhancements spanning from device access point to the network core.  In either case, the network infrastructure must adapt to this new dynamic environment. Intelligence and automation are key if enterprises are to derive maximum benefit from their cloud deployments.

[0001564590-20-002754:mdna:9]
A trend affecting the enterprise network equipment market is the adoption of the cloud-managed enterprise WLAN in the enterprise market. We continued execution towards our strategic objectives by expanding our cloud portfolio with the acquisition of Aerohive Networks, Inc. (“Aerohive”) in August 2019. This acquisition enhances our cloud offering by adding a 3rd generation cloud with Machine Learning/Artificial Intelligence insights and analytics that we intend to expand to all the Extreme ElementsTM. This cloud-driven solution will be the only offering in the market that seamlessly integrates the Cloud with on premises infrastructures and spans from the IoT edge to the enterprise data center.

[0001564590-20-002754:mdna:10]
[same as prior period, unchanged from 0001564590-19-039190:mdna:64]

[0001564590-20-002754:mdna:11]
We are focused on delivering end-to-end networking and software solutions for today’s enterprise environments. From wireless and wired access technologies, through the campus, core, and into the datacenter, Extreme is developing solutions to deliver outstanding business outcomes for our customers. Leveraging a unified management approach, both on premises and in the cloud, we continue to accelerate adoption and delivery of new technologies in support of emerging trends in enterprise networking. We continue to execute on our growth objectives by maximizing customer, partner, and shareholder value.

[0001564590-20-002754:mdna:12]
In fiscal 2017, we completed the acquisition of the WLAN Business from Zebra. In fiscal 2018, we completed the acquisitions of the Campus Fabric Business from Avaya and the Data Center Business from Brocade. In August 2019, we acquired the entire Cloud Networking portfolio from Aerohive. These acquisitions support our growth strategy to lead the enterprise network equipment market with end-to-end software-driven cloud and on-premises solutions for enterprise customers from the data center to the wireless edge.  After the closing of the acquisitions of the Campus Fabric Business and Data Center Business, Extreme immediately became a networking industry leader with more than 30,000 customers. In addition, the acquisition of Aerohive brought us another 20,000+ customers and solidify our position as the third ranked networking vendor in the United States and the second ranked cloud networking provider globally.  As a network switching leader in enterprise, datacenter, and cloud, we combine and extend our world-class products and technologies to provide customers with some of the most advanced, high performance and open solutions in the market as well as a superb overall customer experience.  The combination of all the Extreme ElementsTM is significant in that it brings together distinct strengths addressing the key areas of the network, from unified wired and wireless edge, to the enterprise core, to the data center to offer a complete, unified portfolio of cloud-driven network access solutions.

[0001564590-20-002754:mdna:13]
Provider of high quality, cloud-driven, secure networking solutions and the industry’s #1 customer support organization

[0001564590-20-002754:mdna:14]
|  | • | Only end-to-end cloud-driven networking vendor with management, intelligence, and assurance values built into every solution. |

[0001564590-20-002754:mdna:15]
|  | • | Delivering new releases of next generation portfolio Elements organically and through acquisition. |

[0001564590-20-002754:mdna:16]
[same as prior period, unchanged from 0001564590-19-039190:mdna:71]

[0001564590-20-002754:mdna:17]
|  | • | Focus on being nimble and responsive to customers and partners. We work with our customers to deliver cloud-driven solutions from the IoT edge to the cloud that are agile, adaptive, and secure to enable digital transformation for our customers. We help our customers move beyond just “keeping the lights on”, so they can think strategically and innovate. By allowing customers to access critical decision-making intelligence, we are able reduce their daily tactical work, so they can spend their time on learning and understanding how to innovate their business with IT. |

[0001564590-20-002754:mdna:18]
|  | • | Provide the industry’s first and only 3rd generation end-to-end cloud architecture. Cloud technologies have evolved significantly over the past decade, from monolithic software images hosted remotely to microservices providing machine learning insights continuous integration and delivery of new features. We deliver unrivaled innovation, reliability, and security with the leading end-to-end cloud management platform powered by ML and AI that spans from the IoT edge to the enterprise data center. |

[0001564590-20-002754:mdna:19]
[same as prior period, unchanged from 0001564590-19-039190:mdna:73]

[0001564590-20-002754:mdna:20]
|  | • | Cloud-driven networking services-led solutions. Our cloud-driven solutions provide visibility, control and strategic intelligence from the edge to the data center, across networks and applications. Our solutions include wired switching, wireless switching, wireless access points, WLAN controllers, routers, and an extensive portfolio of software applications that deliver AI-enhanced access control, network and application analytics, as well as network management. All can be managed, assessed and controlled from a single pane of glass on premises or from the cloud. |

[0001564590-20-002754:mdna:21]
|  | • | Offer customers choice – cloud or on-premises. We leverage cloud where it makes sense for our customers and provide on premises solutions where customers need it and have a solution for those that want to harness the power of both. Our hybrid approach gives our customers options to adapt the technology to their business. At the same time, all of our solutions have visibility, control and strategic information built in, all tightly integrated with a single view across all of the installed products. Our customers can understand what’s going on across the network and applications in real time – who, when, and what is connected to the network, which is critical for BYOD and IoT. |

[0001564590-20-002754:mdna:22]
[same as prior period, unchanged from 0001564590-19-039190:mdna:76]

[0001564590-20-002754:mdna:23]
[same as prior period, unchanged from 0001564590-19-039190:mdna:77]

[0001564590-20-002754:mdna:24]
[same as prior period, unchanged from 0001564590-19-039190:mdna:78]

[0001564590-20-002754:mdna:25]
[same as prior period, unchanged from 0001564590-19-039190:mdna:79]

[0001564590-20-002754:mdna:26]
[same as prior period, unchanged from 0001564590-19-039190:mdna:80]

[0001564590-20-002754:mdna:27]
[same as prior period, unchanged from 0001564590-19-039190:mdna:81]

[0001564590-20-002754:mdna:28]
|  | • | Extend switching and routing technology leadership. Our technological leadership is based on innovative switching, routing and wireless products, the depth and focus of our market experience and our operating systems - the software that runs on all of our networking products. Our products reduce operating expenses for our customers and enable a more flexible and dynamic network environment that will help them meet the upcoming demands of IoT, mobile, and cloud, etc. Furthermore, our network operating systems, our primary merchant silicon vendor Broadcom, and select manufacturing partners permit us to leverage our engineering investment. We have invested in engineering resources to create leading-edge technologies to increase the performance and functionality of our products, and as a direct result, the value of our solution to our current and future customers. We look for maximum synergies from our engineering investment in our targeted verticals. |

[0001564590-20-002754:mdna:29]
|  | • | Expand Wi-Fi technology leadership. Wireless is today’s network access method of choice and every business must deal with scale, density and BYOD challenges. The increase in demand being seen today, fueled by more users with multiple devices, increases the expectation that everything will just work. The network edge landscape is changing as the explosion of mobile devices increases the demand for mobile, transparent, and always-on wired to wireless edge services. The unified access layer requires distributed intelligent components to ensure that access control and resiliency of business services are available across the entire infrastructure and manageable from a single console. We are at a technology inflection point with the pending migration from Wi-Fi 5 solutions to Wi-Fi 6 (802.11ax), focused on providing more efficient access to the broad array of connected devices. We have the industry’s broadest Wi-Fi 6 wireless portfolio providing intelligence for the wired/wireless edge and enhanced by our 3rd generation cloud architecture with machine learning and AI-driven insights. |

[0001564590-20-002754:mdna:30]
[same as prior period, unchanged from 0001564590-19-039190:mdna:84]

[0001564590-20-002754:mdna:31]
[same as prior period, unchanged from 0001564590-19-039190:mdna:85]

[0001564590-20-002754:mdna:32]
[same as prior period, unchanged from 0001564590-19-039190:mdna:41]

[0001564590-20-002754:mdna:33]
[same as prior period, unchanged from 0001564590-19-039190:mdna:86]

[0001564590-20-002754:mdna:34]
[same as prior period, unchanged from 0001564590-19-039190:mdna:87]

[0001564590-20-002754:mdna:35]
|  | • | Cloud-driven networking solutions for the enterprise. We are a cloud-driven networking solution company focused on the enterprise. We focus our R&D team and our sales teams to execute against a refined set of requirements for optimized return on investment, faster innovation, and clearer focus on mega trends and changes in the industry. As a cloud-driven networking company, we offer solutions for the entire enterprise network, the data center, the campus, the core and the WLAN. |

[0001564590-20-002754:mdna:36]
[same as prior period, unchanged from 0001564590-19-039190:mdna:89]

[0001564590-20-002754:mdna:37]
[same as prior period, unchanged from 0001564590-19-039190:mdna:90]

[0001564590-20-002754:mdna:38]
|  | • | Maintain and extend our strategic relationships. We have established strategic relationships with a number of industry-leading vendors to both provide increased and enhanced routes to market, but also to collaboratively develop unique solutions. We announced this in the second quarter of fiscal year ended June 30, 2020 that we were selected by Broadcom, the industry’s largest merchant silicon provider, as their preferred choice for enterprise campus deployments. As a Broadcom preferred provider for enterprise campus networking solutions, Extreme will give enterprise customers and partners powerful security, segmentation, resiliency, policy, telemetry, and performance advantages as they pursue cloud-driven digital transformation with the industry's most simple, secure, and intelligent campus architecture. |

[0001564590-20-002754:mdna:39]
[same as prior period, unchanged from 0001564590-19-039190:mdna:92]

[0001564590-20-002754:mdna:40]
[same as prior period, unchanged from 0001564590-19-039190:mdna:93]

[0001564590-20-002754:mdna:41]
|  | • | Extreme ElementsTM Extreme Elements are the building blocks that enable the creation of an Autonomous Network to deliver the positive outcomes important to customer organizations, including those in education, healthcare, retail, manufacturing, transportation and logistics, and government. Combining architecture, automation, and artificial intelligence, Extreme Elements enable customers to get what they need, when and where they need it. |

[0001564590-20-002754:mdna:42]
[same as prior period, unchanged from 0001564590-19-039190:mdna:96]

[0001564590-20-002754:mdna:43]
[same as prior period, unchanged from 0001564590-19-039190:mdna:97]

[0001564590-20-002754:mdna:44]
[same as prior period, unchanged from 0001564590-19-039190:mdna:98]

[0001564590-20-002754:mdna:45]
[same as prior period, unchanged from 0001564590-19-039190:mdna:99]

[0001564590-20-002754:mdna:46]
32

[0001564590-20-002754:mdna:47]
[same as prior period, unchanged from 0001564590-19-039190:mdna:100]

[0001564590-20-002754:mdna:48]
[same as prior period, unchanged from 0001564590-19-039190:mdna:101]

[0001564590-20-002754:mdna:49]
[same as prior period, unchanged from 0001564590-19-039190:mdna:102]

[0001564590-20-002754:mdna:50]
[same as prior period, unchanged from 0001564590-19-039190:mdna:103]

[0001564590-20-002754:mdna:51]
[same as prior period, unchanged from 0001564590-19-039190:mdna:104]

[0001564590-20-002754:mdna:52]
[same as prior period, unchanged from 0001564590-19-039190:mdna:105]

[0001564590-20-002754:mdna:53]
[same as prior period, unchanged from 0001564590-19-039190:mdna:106]

[0001564590-20-002754:mdna:54]
During the second quarter of fiscal 2020, we achieved the following results:

[0001564590-20-002754:mdna:55]
|  | • | Net revenues of $267.5 million compared to $252.7 million in the second quarter of fiscal 2019. |

[0001564590-20-002754:mdna:56]
|  | • | Product revenue of $190.5 million compared to $189.6 million in the second quarter of fiscal 2019. |

[0001564590-20-002754:mdna:57]
|  | • | Service revenue of $77.0 million compared to $63.1 million in the second quarter of fiscal 2019. |

[0001564590-20-002754:mdna:58]
|  | • | Total gross margin of 55.6% of net revenues compared to 55.9% of net revenues in the second quarter of fiscal 2019. |

[0001564590-20-002754:mdna:59]
|  | • | Operating loss of $15.2 million compared to operating income of $4.8 million in the second quarter of fiscal 2019. |

[0001564590-20-002754:mdna:60]
|  | • | Net loss of $23.5 million compared to net income of $7.2 million in the second quarter of fiscal 2019. |

[0001564590-20-002754:mdna:61]
During the first six months of fiscal 2020, we reflected the following results:

[0001564590-20-002754:mdna:62]
|  | • | Cash flow provided by operating activities of $21.9 million compared to cash flow provided by operating activities of $61.6 million in the six months ended December 31, 2018. Cash of $140.4 million compared to $169.6 million as of June 30, 2019. |

[0001564590-20-002754:mdna:63]
[same as prior period, unchanged from 0001564590-19-039190:mdna:116]

[0001564590-20-002754:mdna:64]
[same as prior period, unchanged from 0001564590-19-039190:mdna:117]

[0001564590-20-002754:mdna:65]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | December 31, 2019 |  |  | December 31, 2018 |  |  | $ Change |  |  | % Change |  |  | December 31, 2019 |  |  | December 31, 2018 |  |  | $ Change |  |  | % Change |  |
| Net Revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 190,492 |  |  | $ | 189,567 |  |  | $ | 925 |  |  |  | 0.5 | % |  | $ | 375,626 |  |  | $ | 367,287 |  |  | $ | 8,339 |  |  |  | 2.3 | % |
| Percentage of net revenue |  |  | 71.2 | % |  |  | 75.0 | % |  |  |  |  |  |  |  |  |  |  | 71.8 | % |  |  | 74.6 | % |  |  |  |  |  |  |  |  |
| Service |  |  | 76,980 |  |  |  | 63,113 |  |  |  | 13,867 |  |  |  | 22.0 | % |  |  | 147,352 |  |  |  | 125,279 |  |  |  | 22,073 |  |  |  | 17.6 | % |
| Percentage of net revenue |  |  | 28.8 | % |  |  | 25.0 | % |  |  |  |  |  |  |  |  |  |  | 28.2 | % |  |  | 25.4 | % |  |  |  |  |  |  |  |  |
| Total net revenues |  | $ | 267,472 |  |  | $ | 252,680 |  |  | $ | 14,792 |  |  |  | 5.9 | % |  | $ | 522,978 |  |  | $ | 492,566 |  |  | $ | 30,412 |  |  |  | 6.2 | % |

[0001564590-20-002754:mdna:66]
Product revenue increased $0.9 million or 0.5% for the three months ended December 31, 2019, as compared to the corresponding period of fiscal 2019. Product revenue increased $8.3 million or 2.3% for the six months ended December 31, 2019, as compared to the corresponding period of fiscal 2019. The increases in product revenues was attributable to growth related to the acquisition of Aerohive offset by lower legacy revenue.

[0001564590-20-002754:mdna:67]
Service revenue increased $13.9 million, or 22.0% for the three months ended December 31, 2019.  Service revenue increased $22.1 million, or 17.6% for the six months ended December 31, 2019. The increase in service revenues was attributable to growth related to the acquisition of Aerohive, as well as higher legacy maintenance revenue.

[0001564590-20-002754:mdna:68]
[same as prior period, unchanged from 0001564590-19-039190:mdna:121]

[0001564590-20-002754:mdna:69]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | December 31, 2019 |  |  | December 31, 2018 |  |  | $ Change |  |  | % Change |  |  | December 31, 2019 |  |  | December 31, 2018 |  |  | $ Change |  |  | % Change |  |
| Gross profit: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 99,105 |  |  | $ | 103,080 |  |  | $ | (3,975 | ) |  |  | (3.9 | )% |  | $ | 192,848 |  |  | $ | 197,257 |  |  | $ | (4,409 | ) |  |  | (2.2 | )% |
| Percentage of product revenue |  |  | 52.0 | % |  |  | 54.4 | % |  |  |  |  |  |  |  |  |  |  | 51.3 | % |  |  | 53.7 | % |  |  |  |  |  |  |  |  |
| Service |  |  | 49,566 |  |  |  | 38,219 |  |  |  | 11,347 |  |  |  | 29.7 | % |  |  | 93,066 |  |  |  | 76,113 |  |  |  | 16,953 |  |  |  | 22.3 | % |
| Percentage of service revenue |  |  | 64.4 | % |  |  | 60.6 | % |  |  |  |  |  |  |  |  |  |  | 63.2 | % |  |  | 60.8 | % |  |  |  |  |  |  |  |  |
| Total gross profit |  | $ | 148,671 |  |  | $ | 141,299 |  |  | $ | 7,372 |  |  |  | 5.2 | % |  | $ | 285,914 |  |  | $ | 273,370 |  |  | $ | 12,544 |  |  |  | 4.6 | % |
| Percentage of net revenues |  |  | 55.6 | % |  |  | 55.9 | % |  |  |  |  |  |  |  |  |  |  | 54.7 | % |  |  | 55.5 | % |  |  |  |  |  |  |  |  |

[0001564590-20-002754:mdna:70]
Product gross profit decreased $4.0 million or 3.9% for the three months ended December 31, 2019, as compared to the corresponding period in fiscal 2019. The decrease in product gross profit was primarily due to the expensing of the fair value step-up of inventories acquired from Aerohive of $3.4 million, higher distribution charges of $1.7 million and higher amortization of intangible assets of $1.2 million.  This was offset by gross profit from higher revenues and more favorable manufacturing costs due to cost reduction efforts.

[0001564590-20-002754:mdna:71]
Product gross profit decreased $4.4 million or 2.2% for the six months ended December 31, 2019, as compared to the corresponding period in fiscal 2019.  The decrease in product gross profit was primarily due to the expensing of the fair value step-up of inventories acquired from Aerohive of $7.3 million, higher excess and obsolete inventory charges of $3.5 million, higher amortization of intangible assets of $2.2 million and higher distribution costs of $1.1 million.  This was partially offset by gross profit from higher revenues and more favorable manufacturing costs due to cost reduction efforts.

[0001564590-20-002754:mdna:72]
Service gross profit increased $11.3 million and $17.0 million or 29.7% and 22.3% for the three and six months ended December 31, 2019. The increases were primarily due to a higher level of service revenues related to the acquisition of the Aerohive, partially offset by higher service material costs and personnel costs due to increased headcount to support acquired contracts as well as amortization of intangible assets of $0.8 million and $1.4 million for the respective three and six-month periods ended December 31, 2019.

[0001564590-20-002754:mdna:73]
[same as prior period, unchanged from 0001564590-19-039190:mdna:125]

[0001564590-20-002754:mdna:74]
[same as prior period, unchanged from 0001564590-19-039190:mdna:126]

[0001564590-20-002754:mdna:75]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | December 31, 2019 |  |  | December 31, 2018 |  |  | $ Change |  |  | % Change |  |  | December 31, 2019 |  |  | December 31, 2018 |  |  | $ Change |  |  | % Change |  |
| Research and development |  | $ | 55,380 |  |  | $ | 52,204 |  |  | $ | 3,176 |  |  |  | 6.1 | % |  | $ | 114,496 |  |  | $ | 103,445 |  |  | $ | 11,051 |  |  |  | 10.7 | % |
| Sales and marketing |  |  | 75,436 |  |  |  | 68,342 |  |  |  | 7,094 |  |  |  | 10.4 | % |  |  | 146,793 |  |  |  | 135,924 |  |  |  | 10,869 |  |  |  | 8.0 | % |
| General and administrative |  |  | 15,098 |  |  |  | 13,886 |  |  |  | 1,212 |  |  |  | 8.7 | % |  |  | 30,080 |  |  |  | 26,657 |  |  |  | 3,423 |  |  |  | 12.8 | % |
| Acquisition and integration costs |  |  | 8,994 |  |  |  | 67 |  |  |  | 8,927 |  |  | * |  |  |  | 24,919 |  |  |  | 2,613 |  |  |  | 22,306 |  |  |  | 853.7 | % |
| Restructuring charges, net of reversals and impairment |  |  | 6,622 |  |  |  | 474 |  |  |  | 6,148 |  |  |  | 1,297.0 | % |  |  | 12,759 |  |  |  | 1,282 |  |  |  | 11,477 |  |  |  | 895.2 | % |
| Amortization of intangibles |  |  | 2,377 |  |  |  | 1,575 |  |  |  | 802 |  |  |  | 50.9 | % |  |  | 4,307 |  |  |  | 3,716 |  |  |  | 591 |  |  |  | 15.9 | % |
| Total operating expenses |  | $ | 163,907 |  |  | $ | 136,548 |  |  | $ | 27,359 |  |  |  | 20.0 | % |  | $ | 333,354 |  |  | $ | 273,637 |  |  | $ | 59,717 |  |  |  | 21.8 | % |

[0001564590-20-002754:mdna:76]
* Not meaningful.

[0001564590-20-002754:mdna:77]
[same as prior period, unchanged from 0001564590-19-039190:mdna:128]

[0001564590-20-002754:mdna:78]
[same as prior period, unchanged from 0001564590-19-039190:mdna:129]

[0001564590-20-002754:mdna:79]
Research and development expenses increased by $3.2 million or 6.1% for the three months ended December 31, 2019, as compared to the corresponding period of fiscal 2019 primarily due to the acquisition of Aerohive.  The increase in research and development expenses was due to $1.3 million of increased salary and compensation costs, $1.8 million increased costs related to equipment, supplies and third-party design and engineering collaboration charges, $0.1 million of increased professional and contractor fees, $0.3 million in increased facility and information technology costs partially offset by a $0.3 million reduction in other operating costs.

[0001564590-20-002754:mdna:80]
Research and development expenses increased by $11.1 million or 10.7% for the six months ended December 31, 2019, as compared to the corresponding period of fiscal 2019 primarily due to the acquisition of Aerohive.  The increase in research and development expenses was due to $6.7 million of increased salary and compensation costs, $3.4 million of increased costs related to equipment, supplies and third-party design and engineering collaboration charges, $0.2 million of increased professional and contractor fees, a $0.6 million in increased facility and information technology costs, and $0.2 million increase in other operating costs.

[0001564590-20-002754:mdna:81]
[same as prior period, unchanged from 0001564590-19-039190:mdna:131]

[0001564590-20-002754:mdna:82]
[same as prior period, unchanged from 0001564590-19-039190:mdna:132]

[0001564590-20-002754:mdna:83]
Sales and marketing expenses increased by $7.1 million or 10.4% for the three months ended December 31, 2019, as compared to the corresponding period of fiscal 2019 primarily due to the acquisition of Aerohive.  The increase was primarily due to $4.5 million of personnel costs, $0.7 million of professional fees and $0.9 million of increased facility and information technology costs, $0.4 million in travel and sales promotion costs and $0.6 million of software and equipment costs.

[0001564590-20-002754:mdna:84]
Sales and marketing expenses increased by $10.9 million or 8.0% for the six months ended December 31, 2019, as compared to the corresponding period of fiscal 2019 primarily due to the acquisition of Aerohive.  The increase was primarily due to $9.0 million of personnel costs, $1.9 million of professional fees and $1.6 million of increased facility and information technology costs, and $1.0 million of increased software and equipment costs partially offset by a $2.6 million reduction in travel and sales promotion costs.

[0001564590-20-002754:mdna:85]
[same as prior period, unchanged from 0001564590-19-039190:mdna:134]

[0001564590-20-002754:mdna:86]
[same as prior period, unchanged from 0001564590-19-039190:mdna:135]

[0001564590-20-002754:mdna:87]
General and administrative expenses increased by $1.2 million or 8.7% for the three months ended December 31, 2019, as compared to the corresponding period of fiscal 2019, primarily due to the acquisition of Aerohive. The increase in general and administrative expenses was primarily due to $0.6 million of increased personnel costs, $0.2 million in higher facility and information technology costs, $0.1 million in professional fees, and $0.3 million of insurance premiums.

[0001564590-20-002754:mdna:88]
General and administrative expenses increased by $3.4 million or 12.8% for the six months ended December 31, 2019, as compared to the corresponding period of fiscal 2019, primarily due to the acquisition of Aerohive. The increase in general and administrative expenses was primarily due to $1.7 million of increased personnel costs, $0.4 million in higher facility and information technology costs $0.8 million in professional fees and $0.5 million of insurance premiums.

[0001564590-20-002754:mdna:89]
[same as prior period, unchanged from 0001564590-19-039190:mdna:137]

[0001564590-20-002754:mdna:90]
During the three and six months ended December 31, 2019, we incurred $9.0 million and $24.9 million, respectively of acquisition and integration costs including a $6.8 million compensation charge for certain Aerohive Executives’ stock awards which were accelerated due to change-in-control and termination provisions included in the Executives’ employment contracts. Other acquisition and integration costs consist primarily of professional fees for financial and legal advisory services and severance charges for Aerohive employees.

[0001564590-20-002754:mdna:91]
During the three and six months ended December 31, 2018, we incurred $0.1 million and $2.6 million, respectively, of operating integration costs related to the acquisitions of the Campus Fabric and Data Center Businesses.

[0001564590-20-002754:mdna:92]
Restructuring Charges, Net of Reversals and Impairment

[0001564590-20-002754:mdna:93]
For the three months ended December 31, 2019 we recorded restructuring charges of $6.6 million. The charges consisted primarily of excess facility charges of $3.9 million for impairment of right-of-use assets related mainly to our Milpitas, California facilities.  Additionally, we continued our reduction-in-force initiative begun in the fourth quarter of fiscal 2019 and we recorded severance and benefits charges of $2.7 million.

[0001564590-20-002754:mdna:94]
For the six months ended December 31, 2019 we recorded restructuring charges of $12.8 million. The charges consisted primarily of excess facility charges of $7.9 million for impairment of right-of-use assets related to our Milpitas California, South San Jose California, and Salem New Hampshire facilities.  Additionally, we continued our reduction-in-force initiative begun in the fourth quarter of fiscal 2019 and we recorded severance and benefits charges of $4.9 million.

[0001564590-20-002754:mdna:95]
For the three and six months ended December 31, 2018, we recorded restructuring charges of $0.5 million and $1.3 million, respectively, associated with a reduction-in-force in the fourth quarter of fiscal 2018 and additional excess facility charges.

[0001564590-20-002754:mdna:96]
[same as prior period, unchanged from 0001564590-19-039190:mdna:143]

[0001564590-20-002754:mdna:97]
During the three months ended December 31, 2019 and 2018, we recorded $2.4 million and $1.6 million, respectively, of operating expenses for amortization of intangibles in the accompanying condensed consolidated statements of operations.  The increase was mainly due to amortization of acquired intangibles from the Aerohive acquisition offset by lower amortization related to certain acquired intangibles from previous acquisitions becoming fully amortized.

[0001564590-20-002754:mdna:98]
During the six months ended December 31, 2019 and 2018, we recorded $4.3 million and $3.7 million, respectively, of operating expenses for amortization of intangibles in the accompanying condensed consolidated statements of operations.  The increase was mainly due to amortization of acquired intangibles from the Aerohive acquisition offset by lower amortization related to certain acquired intangibles from previous acquisitions becoming fully amortized.

[0001564590-20-002754:mdna:99]
[same as prior period, unchanged from 0001564590-19-039190:mdna:145]

[0001564590-20-002754:mdna:100]
During the three months ended December 31, 2019 and 2018, we recorded $6.2 million and $3.1 million, respectively, in interest expense.  The increase in interest expense was primarily driven by higher outstanding loan balances and other charges due to refinancing our Credit Agreement in August 2019.

[0001564590-20-002754:mdna:101]
During the six months ended December 31, 2019 and 2018, we recorded $11.4 million and $6.6 million, respectively, in interest expense.  The increase in interest expense was primarily driven by higher outstanding loan balances and other charges due to refinancing our Credit Agreement in August 2019.

[0001564590-20-002754:mdna:102]
[same as prior period, unchanged from 0001564590-19-039190:mdna:147]

[0001564590-20-002754:mdna:103]
During the three months ended December 31, 2019 and 2018, we recorded expense of $0.7 million and $0.4 million, respectively, in other income (expense), net.  The change for the three months ended December 31, 2019 was primarily due to foreign exchange gains and losses from the revaluation of certain assets and liabilities denominated in foreign currencies into U.S. Dollars.

[0001564590-20-002754:mdna:104]
During the six months ended December 31, 2019 and 2018, we recorded expense of $0.2 million and other income of $0.1 million, respectively, in other income (expense), net. The change for the six months ended December 31, 2019 was primarily due to foreign exchange gains and losses from the revaluation of certain assets and liabilities denominated in foreign currencies into U.S. Dollars.

[0001564590-20-002754:mdna:105]
[same as prior period, unchanged from 0001564590-19-039190:mdna:149]

[0001564590-20-002754:mdna:106]
For the three months ended December 31, 2019 and 2018, we recorded an income tax provision of $1.8 million and tax benefit of $5.3 million, respectively.  For the six months ended December 31, 2019 and 2018, we recorded an income tax provision of $3.4 million and tax benefit of $3.9 million, respectively.

[0001564590-20-002754:mdna:107]
The income tax provisions for the three and six months ended December 31, 2019, consisted primarily of (1) taxes on the income of the Company’s foreign subsidiaries, (2) foreign withholding taxes (3) tax expense associated with the establishment of a U.S. deferred tax liability for amortizable goodwill resulting from the acquisition of Enterasys Networks, Inc., the WLAN Business, the Campus Fabric Business and the Data Center Business, and (4) state taxes in jurisdictions where the Company has no remaining state Net Operating Losses. In addition, the three and six months ended December 31, 2018 included tax benefits associated with the release of valuation allowance resulting from changes introduced by US tax reform as well as the release of a valuation allowance recorded against deferred tax assets in Australia.

[0001564590-20-002754:mdna:108]
[same as prior period, unchanged from 0001564590-19-039190:mdna:152]

[0001564590-20-002754:mdna:109]
[same as prior period, unchanged from 0001564590-19-039190:mdna:153]

[0001564590-20-002754:mdna:110]
[same as prior period, unchanged from 0001564590-19-039190:mdna:154]

[0001564590-20-002754:mdna:111]
[same as prior period, unchanged from 0001564590-19-039190:mdna:155]

[0001564590-20-002754:mdna:112]
[same as prior period, unchanged from 0001564590-19-039190:mdna:156]

[0001564590-20-002754:mdna:113]
[same as prior period, unchanged from 0001564590-19-039190:mdna:157]

[0001564590-20-002754:mdna:114]
[same as prior period, unchanged from 0001564590-19-039190:mdna:158]

[0001564590-20-002754:mdna:115]
[same as prior period, unchanged from 0001564590-19-039190:mdna:159]

[0001564590-20-002754:mdna:116]
[same as prior period, unchanged from 0001564590-19-039190:mdna:160]

[0001564590-20-002754:mdna:117]
[same as prior period, unchanged from 0001564590-19-039190:mdna:161]

[0001564590-20-002754:mdna:118]
The following summarizes information regarding our cash and working capital (in thousands):

[0001564590-20-002754:mdna:119]
|  |  | December 31, 2019 |  |  | June 30, 2019 |  |
| Cash |  | $ | 140,414 |  |  | $ | 169,607 |  |
| Working capital (deficit) |  | $ | (5,345 | ) |  | $ | 85,960 |  |

[0001564590-20-002754:mdna:120]
As of December 31, 2019, our principal sources of liquidity consisted of cash of $140.4 million, accounts receivable, net of $159.8 million, and available borrowings from our five-year 2019 Revolving Facility of $60.3 million. Our principal uses of cash include the purchase of finished goods inventory from our contract manufacturers, payroll and other operating expenses related to the development and marketing of our products, purchases of property and equipment, repayments of debt and related interest and repurchases of common stock outstanding. We believe that our $140.4 million of cash at December 31, 2019 and the availability of borrowings from the 2019 Revolving Facility will be sufficient to fund our principal uses of cash for at least the next 12 months.

[0001564590-20-002754:mdna:121]
On November 2, 2018, our Board of Directors announced that it had authorized management to repurchase up to $60.0 million of its common stock for two years from the date of authorization, of which $15.0 million was used for repurchases in the second quarter of fiscal 2019.  Purchases may be made from time to time in the open market or in privately negotiated transactions. The manner, timing and amount of any future purchases will be determined by our management based on their evaluation of market conditions, stock price, Extreme’s ongoing determination that it is the best use of available cash and other factors. The repurchase program does not obligate Extreme to acquire any common stock, may be suspended or terminated at any time without prior notice and will be subject to regulatory considerations. In November 2019, the Company entered into an accelerated share repurchase agreement (the “November 2019 ASR”) to repurchase shares of the Company’s common stock.  Pursuant to the November 2019 ASR, the Company paid $30.0 million for an initial delivery of 3,850,000 shares valued at $25.2 million. The remaining balance of $4.8 million was recorded as a forward contract in the Company’s common stock. The forward contract was settled on January 24, 2020 and the Company received an additional 381,505 shares of its common stock.

[0001564590-20-002754:mdna:122]
In connection with the acquisition of Aerohive as discussed in Note 4 of the accompanying condensed consolidated financial statements included elsewhere in this Report, as of August 9, 2019, we amended the 2018 Credit Agreement and entered into the 2019 Credit Agreement, by and among us, as borrower, several banks and other financial institutions as Lenders, BMO Harris Bank N.A., as an issuing lender and swingline lender, Silicon Valley Bank, as an Issuing Lender, and Bank of Montreal, as administrative agent and collateral agent for the Lenders. The 2019 Credit Agreement provides for a 5-year first lien term loan facility in an aggregate principal amount of $380 million (“2019 Term Loan”) and a 5-year revolving loan facility in an aggregate principal amount of $75 million (“2019 Revolving Facility”).  In addition, we may request incremental term loans and/or incremental revolving loan commitments in an aggregate amount not to exceed the sum of $100 million plus an unlimited amount that is subject to pro forma compliance with certain financial tests.  On August 9, 2019, we used the proceeds to partially fund the acquisition of Aerohive and for working capital and general corporate purposes.

[0001564590-20-002754:mdna:123]
[same as prior period, unchanged from 0001564590-19-039190:mdna:167]

[0001564590-20-002754:mdna:124]
The 2019 Credit Agreement requires us to maintain certain minimum financial ratios at the end of each fiscal quarter. The 2019 Credit Agreement also includes covenants and restrictions that limit, among other things, our ability to incur additional indebtedness, create liens upon any of our property, merge, consolidate or sell all or substantially all of our assets. The 2019 Credit Agreement also includes customary events of default which may result in acceleration of the outstanding balance.

[0001564590-20-002754:mdna:125]
Financial covenants under the 2019 Credit Agreement require us to maintain a minimum consolidated fixed charge and consolidated leverage ratio at the end of each fiscal quarter through maturity.  The 2019 Credit Agreement also includes covenants and restrictions that limit, among other things, our ability to incur additional indebtedness, create liens upon any of our property, merge, consolidate or sell all or substantially all of our assets.  The 2019 Credit Agreement also includes customary events of default which may result in acceleration of the outstanding balance.  At December 31, 2019, we were in compliance with the covenants of the 2019 Credit Agreement.

[0001564590-20-002754:mdna:126]
[same as prior period, unchanged from 0001564590-19-039190:mdna:170]

[0001564590-20-002754:mdna:127]
A summary of the sources and uses of cash is as follows (in thousands):

[0001564590-20-002754:mdna:128]
|  |  | Six Months Ended |  |
|  |  | December 31, 2019 |  |  | December 31, 2018 |  |
| Net cash provided by operating activities |  | $ | 21,911 |  |  | $ | 61,611 |  |
| Net cash used in investing activities |  |  | (183,647 | ) |  |  | (10,413 | ) |
| Net cash provided by (used in) financing activities |  |  | 132,736 |  |  |  | (31,329 | ) |
| Foreign currency effect on cash |  |  | (193 | ) |  |  | (365 | ) |
| Net (decrease) increase in cash |  | $ | (29,193 | ) |  | $ | 19,504 |  |

[0001564590-20-002754:mdna:129]
Net Cash Provided by Operating Activities

[0001564590-20-002754:mdna:130]
Cash flows provided by operations in the six months ended December 31, 2019, were $21.9 million, including our net loss of $61.3 million and non-cash expenses of $72.1 million for items such as amortization of intangibles, reduction in carrying amount of right-of-use asset, depreciation, restructuring, deferred income taxes and imputed interest.  Other sources of cash for the period included a decrease in accounts receivables and inventory and increases in deferred revenues. This was partially offset by decreases in accounts payable, accrued compensation, other current and long-term liabilities, and operating lease liabilities.

[0001564590-20-002754:mdna:131]
Cash flows provided by operations in the six months ended December 31, 2018 were $61.6 million, including our net loss of $1.9 million and non-cash expenses of $38.4 million for items such as amortization of intangibles, stock-based compensation, depreciation, deferred income taxes and imputed interest.  Other sources of cash for the period included a decrease in accounts receivables, inventories and increases in deferred revenues. This was partially offset by decreases in accounts payable, accrued compensation and other current and long-term liabilities, and increases in prepaid expenses and other current assets.

[0001564590-20-002754:mdna:132]
[same as prior period, unchanged from 0001564590-19-039190:mdna:176]

[0001564590-20-002754:mdna:133]
Cash flows used in investing activities in the six months ended December 31, 2019 were $183.6 million, including $219.5 million for the acquisition of Aerohive (net of cash acquired), purchases of property and equipment of $9.4 million, which was partially offset by proceeds of $45.2 million related to the maturity and sales of short-term investments.

[0001564590-20-002754:mdna:134]
Cash flows used in investing activities in the six months ended December 31, 2018 were $10.4 million which consisted of purchases of property and equipment of $11.1 million and proceeds of $0.7 million related to the sale of investments.

[0001564590-20-002754:mdna:135]
[same as prior period, unchanged from 0001564590-19-039190:mdna:179]

[0001564590-20-002754:mdna:136]
Cash flows provided by financing activities in the six months ended December 31, 2019 were $132.7 million due primarily to additional borrowings of $199.5 million under our 2019 Credit Agreement to partially fund our acquisition of Aerohive, $2.9 million of proceeds from the issuance of shares of our common stock under our Employee Stock Purchase Plan (“ESPP”), the exercise of stock options and net of taxes paid on vested and released stock awards. This was partially offset by debt repayments of $25.0 million, assumed from the Aerohive acquisition, payment of loan fees of $10.5 million, contingent consideration of $2.0 million, and $2.2 million for deferred payments on acquisitions.

[0001564590-20-002754:mdna:137]
Cash flows provided by financing activities for the period also included repurchasing of our common shares valued at $25.2 million during the six months ended December 31, 2019, in accordance with our approved share repurchase plan. The share repurchases were executed through an accelerated share repurchase program, and future share repurchases may be completed through the combination of individually negotiated transactions, accelerated share repurchases, and/or open market purchases. In addition, related to this transaction, there was an equity forward contract related to the Company’s stock of $4.8 million. As of December 31, 2019, we have $19.8 million available under our share repurchase plan. Our Credit Facility does not contain any restrictions on the amount of borrowings that can be used to make share repurchases, as long as we are in compliance with our financial and non-financial covenants.

[0001564590-20-002754:mdna:138]
Cash flows used in financing activities in the six months ended December 31, 2018 were $31.3 million consisting of repayments of debt totaling $14.9 million, contingent consideration of $3.9 million, and $2.0 million for deferred payments on acquisitions.  This was partially offset by $5.0 million of proceeds from the issuance of shares of our common stock under our Employee Stock Purchase Plan, the exercise of stock options and net of taxes paid on vested and released stock awards. Cash flows used in financing activities for the period also included repurchasing of our common shares valued at $15.0 million during the six months ended December 31, 2018, in accordance with our approved share repurchase plan.

[0001564590-20-002754:mdna:139]
[same as prior period, unchanged from 0001564590-19-039190:mdna:182]

[0001564590-20-002754:mdna:140]
Foreign currency effect on cash decreased in the three months ended December 31, 2019, primarily due to changes in foreign currency exchange rates between the U.S. Dollar and particularly the Brazilian Real, Indian Rupee and the EURO. Foreign currency effect on cash decreased in the three months ended December 31, 2018, primarily due to changes in foreign currency exchange rates between the U.S. Dollar and particularly the Brazilian Real, Indian Rupee and the EURO.

[0001564590-20-002754:mdna:141]
[same as prior period, unchanged from 0001564590-19-039190:mdna:184]

[0001564590-20-002754:mdna:142]
The following summarizes our contractual obligations as of December 31, 2019, and the effect such obligations are expected to have on our liquidity and cash flow in future periods (in thousands):

[0001564590-20-002754:mdna:143]
|  |  | Total |  |  | Less than 1 Year |  |  |  |  | 1-3 years |  |  | 3-5 years |  |  | More than 5 years |  |
| Contractual Obligations: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Debt obligations |  | $ | 375,250 |  |  | $ | 19,000 |  |  |  |  | $ | 52,250 |  |  | $ | 304,000 |  |  | $ | — |  |
| Interest on debt obligations |  |  | 76,011 |  |  |  | 18,804 |  |  |  |  |  | 34,338 |  |  |  | 22,869 |  |  |  | — |  |
| Unconditional purchase obligations |  |  | 47,578 |  |  |  | 47,578 |  |  |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Contractual commitments |  |  | 82,250 |  |  |  | 23,500 |  |  |  |  |  | 47,000 |  |  |  | 11,750 |  |  |  | — |  |
| Lease payments on operating leases. |  |  | 84,960 |  |  |  | 10,534 |  |  |  |  |  | 39,784 |  |  |  | 22,137 |  |  |  | 12,505 |  |
| Deferred payments for an acquisition |  |  | 13,000 |  |  |  | 4,000 |  |  |  |  |  | 8,000 |  |  |  | 1,000 |  |  |  | — |  |
| Contingent consideration for an acquisition |  |  | 4,152 |  |  |  | 2,367 |  |  |  |  |  | 1,695 |  |  |  | 90 |  |  |  | — |  |
| Other liabilities |  |  | 1,090 |  |  |  | 236 |  |  |  |  |  | 473 |  |  |  | 381 |  |  |  | — |  |
| Total contractual cash obligations |  | $ | 684,291 |  |  | $ | 126,019 |  |  |  |  | $ | 183,540 |  |  | $ | 362,227 |  |  | $ | 12,505 |  |

[0001564590-20-002754:mdna:144]
[same as prior period, unchanged from 0001564590-19-039190:mdna:187]

[0001564590-20-002754:mdna:145]
[same as prior period, unchanged from 0001564590-19-039190:mdna:188]

[0001564590-20-002754:mdna:146]
[same as prior period, unchanged from 0001564590-19-039190:mdna:189]

[0001564590-20-002754:mdna:147]
[same as prior period, unchanged from 0001564590-19-039190:mdna:190]

[0001564590-20-002754:mdna:148]
[same as prior period, unchanged from 0001564590-19-039190:mdna:191]

[0001564590-20-002754:mdna:149]
[same as prior period, unchanged from 0001564590-19-039190:mdna:192]

[0001564590-20-002754:mdna:150]
[same as prior period, unchanged from 0001564590-19-039190:mdna:193]

[0001564590-20-002754:mdna:151]
[same as prior period, unchanged from 0001564590-19-039190:mdna:194]

[0001564590-20-002754:mdna:152]
[same as prior period, unchanged from 0001564590-19-039190:mdna:195]

[0001564590-20-002754:mdna:153]
We did not have any material commitments for capital expenditures as of December 31, 2019.

[0001564590-20-002754:mdna:154]
[same as prior period, unchanged from 0001564590-19-039190:mdna:197]

[0001564590-20-002754:mdna:155]
We did not have any off-balance sheet arrangements as of December 31, 2019.
