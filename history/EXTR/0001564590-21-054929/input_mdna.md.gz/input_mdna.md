# EXTR MD&A — 0001564590-21-054929


## mdna

[0001564590-21-054929:mdna:1]
[same as prior period, unchanged from 0001564590-21-021969:mdna:1]

[0001564590-21-054929:mdna:2]
[same as prior period, unchanged from 0001564590-21-021969:mdna:2]

[0001564590-21-054929:mdna:3]
[same as prior period, unchanged from 0001564590-21-021969:mdna:3]

[0001564590-21-054929:mdna:4]
Extreme Networks, Inc. (“Extreme” or “Company”) is a leading provider of end-to-end, cloud-driven networking solutions and top-rated services and support. Providing a set of comprehensive solutions from the Internet of Things (“IoT”) edge to the cloud, Extreme designs, develops, and manufactures wired and wireless network infrastructure equipment as well as a leading cloud networking platform and applications portfolio using cloud management, machine learning (“ML”), and artificial intelligence (“AI”) to deliver network policy, analytics, security, and access controls. Our solutions enable companies to embrace the value of new cloud technology without having to rip and replace existing infrastructures. Extreme has been pushing the boundaries of networking technology for a quarter of a century, driven by a higher purpose of helping our customers connect beyond the network. Extreme’s cloud-driven technologies provide flexibility and scalability in deployment, management, and licensing of networks globally. Our global footprint provides service to over 50,000 customers across the world including some of the world’s leading names in business, hospitality, retail, transportation and logistics, education, government, healthcare, manufacturing and service providers. We derive all our revenues from the sale of our networking equipment, software subscriptions, and related maintenance contracts.

[0001564590-21-054929:mdna:5]
Industry Background

[0001564590-21-054929:mdna:6]
Enterprises are adopting new Information Technology (“IT”) delivery models and applications that require fundamental network alterations and enhancements spanning from the access edge to the data center. With the impact of the global pandemic, we believe IT teams in every industry will need more control and better insights than ever before to ensure secure, distributed connectivity and comprehensive centralized visibility. ML and AI technologies have the potential to vastly improve the network experience in the post-pandemic world by collating large data sets to increase accuracy and derive resolutions to improve the operation of the network. When applied with cloud-driven networking and automation, administrators can quickly scale to provide productivity, availability, manageability, security, and speed, regardless of how distributed the network is.

[0001564590-21-054929:mdna:7]
We believe that the network has never been more vital than it is today. As administrators grapple with more data, coming from more places, more connected devices, and more Software-as-a-service (“SaaS”) based applications, the cloud is fundamental to establishing a new normal. Traditional network offerings are not well-suited to fulfill enterprise expectations for rapid delivery of new services, more flexible business models, real-time response, and massive scalability. As enterprises continue to migrate increasing numbers of applications and services to either private clouds or public clouds offered by third parties and to adopt new IT delivery models and applications, they are required to make fundamental network alterations and enhancements spanning from device access points (“AP”) to the network core.  In either case, the network infrastructure must adapt to this new dynamic environment. Intelligence and automation are key if enterprises are to derive maximum benefit from their cloud deployments. Service providers are also investing in network enhancements with platforms and applications that deliver data insights, provide flexibility, and can quickly respond to new user demands and 5G use cases.

[0001564590-21-054929:mdna:8]
We believe Extreme stands to benefit from the use of its technology to manage distributed campus network architecture centrally from the cloud. Extreme has blended a dynamic fabric attach architecture, that delivers simplicity for moves and changes at the edge of the network, together with corporate-wide role-based policy. This enables customers to migrate to new cloud managed switching and Wi-Fi, agnostic of the existing networking or wireless equipment they already have installed. In the end, we expect these customers to see lower operating and capital expenditures, lower subscription costs, lower overall cost of ownership and more flexibility along with a more resilient network. We estimate the total addressable market for our Enterprise Networking solutions consisting of cloud networking, wireless local area networks (“WLAN”), data center networking, ethernet switching, campus local area networks (“LAN”), and software-defined wide area network (“SD-WAN”) solutions to be approximately $26 billion and growing at approximately five percent per year over the next three years.  In addition, 5G provides an estimated $3 billion serviceable available market for Service Provider Networking.

[0001564590-21-054929:mdna:9]
The Extreme Strategy

[0001564590-21-054929:mdna:10]
The year 2020 resulted in unprecedented change – from the physical footprint of offices, to supply chain operations, to how we connect. Organizations and workforces extend anywhere and everywhere.  IT leaders are now tasked with ensuring the global, hybrid workforce is functional and successful no matter where they are and ensure people can work wherever they want.

[0001564590-21-054929:mdna:11]
Extreme has recognized that the way we and our customers communicate has changed and the new normal has given rise to these distributed enterprise environments, or in other words, the Infinite Enterprise, which has three key tenets:

[0001564590-21-054929:mdna:12]
|  | • | Infinitely distributed connectivity is the enterprise-grade reliable connectivity that allows users to connect anywhere, from anywhere. It is always present, available and assured, while being secure and manageable. |

[0001564590-21-054929:mdna:13]
|  | • | Scalable cloud allows administrators to harness the power of the cloud to efficiently onboard, manage, orchestrate, troubleshoot the network, and find data and insights of the distributed connectivity at their pace in their way. |

[0001564590-21-054929:mdna:14]
|  | • | Consumer-centric experience designed to deliver a best-in-class experience to users who consume network services. |

[0001564590-21-054929:mdna:15]
Extreme’s broad product, solutions and technology portfolio supports these three tenets and continues to innovate and evolve them to help businesses succeed.

[0001564590-21-054929:mdna:16]
Key elements of Extreme’s strategy and differentiation include:

[0001564590-21-054929:mdna:17]
|  | • | Creating effortless networking solutions that allow all of us to advance. We believe that progress is achieved when we connect—allowing us to learn, understand, create, and grow. We make connecting simple and easy with effortless networking experiences that enable all of us to advance how we live, work, and share. |

[0001564590-21-054929:mdna:18]
|  | • | Provide a differentiated end-to-end cloud architecture. Cloud networking is estimated to be a $2 billion segment of the networking market and is projected to be the fastest growing part of the networking industry at approximately 20% per year over the next three years, according to data from 650 Group Market Research. Cloud management technology has evolved significantly over the past decade. We believe we deliver a combination of innovation, reliability, and security with the leading end-to-end cloud management platform powered by ML and AI that spans from the IoT edge to the enterprise data center. Key characteristics of our cloud architecture include: |

[0001564590-21-054929:mdna:19]
[same as prior period, unchanged from 0001564590-21-021969:mdna:8]

[0001564590-21-054929:mdna:20]
|  | o | Cloud Choice for customers: Our cloud networking solution is available on all major cloud providers (Amazon Web Services (“AWS”), Google Cloud Platform (“GCP”) and Microsoft Azure). |

[0001564590-21-054929:mdna:21]
[same as prior period, unchanged from 0001564590-21-021969:mdna:10]

[0001564590-21-054929:mdna:22]
|  | o | Consumption Flexibility: Offer a range of financing and network purchase options. Our value-based subscription tiers (including Connect, Navigator and Pilot) provide customers with flexibility to grow as they go, as well as offer pool-able and portable licenses that can be transferred between products (e.g. access points and switches) at one fixed price. |

[0001564590-21-054929:mdna:23]
[same as prior period, unchanged from 0001564590-21-021969:mdna:12]

[0001564590-21-054929:mdna:24]
|  | o | Zero-Trust Security (Information Security Management (“ISO”) 27001 Certified). |

[0001564590-21-054929:mdna:25]
|  | • | Offer customers choice: public or private cloud, or on-premises. We leverage the cloud where it makes sense for our customers and provide on-premises solutions where customers need it and also have a solution for those who want to harness the power of both. Our hybrid approach gives our customers options to adapt the technology to their business. At the same time, all of our solutions have visibility, control and strategic information built in, all tightly integrated with a single view across all of the installed products. Our customers can understand what is going on across their network and applications in real time – who, when, and what is connected to the network - critical for bring your own device (“BYOD”) and IoT usage. |

[0001564590-21-054929:mdna:26]
|  | • | Highest value of cloud management subscriptions. ExtremeCloud IQ Pilot provides our customers with four key applications enabling organizations to eliminate overlays. |

[0001564590-21-054929:mdna:27]
27

[0001564590-21-054929:mdna:28]
|  | o | Extreme AirDefense™ is a comprehensive wireless intrusion prevention system (“WIPS”) that simplifies the protection, monitoring and security of wireless networks. With the added Bluetooth and Bluetooth low energy intrusion prevention, network administrators can address growing threats against bluetooth and low energy devices. |

[0001564590-21-054929:mdna:29]
|  | o | ExtremeLocation™ delivers proximity, presence and location-based services for advanced contact tracing in support of the location-intelligent enterprise. |

[0001564590-21-054929:mdna:30]
|  | o | ExtremeGuest™ is a comprehensive guest engagement solution that enables IT administrators to use analytical insights to engage visitors with personalized engagements. |

[0001564590-21-054929:mdna:31]
|  | o | Extreme IoT™ delivers simple and secure onboarding, profiling, segmentation and filtering of IoT devices on a production network. |

[0001564590-21-054929:mdna:32]
|  | • | Offers universal platforms for enterprise class switching and wireless infrastructure. Extreme offers universal platforms which support multiple deployment use cases, providing flexibility and investment protection. |

[0001564590-21-054929:mdna:33]
|  | o | Universal switches (5520/5420) support fabric or traditional networking with a choice of cloud or on-premises (air-gapped or cloud connected) management. |

[0001564590-21-054929:mdna:34]
|  | o | Universal WiFi 6 APs (300/400 series) support campus or distributed deployments with a choice of cloud or on-premises (air-gapped or cloud connected) management. |

[0001564590-21-054929:mdna:35]
|  | o | Universal licensing with one portable management license for any device and for any type of management. For switches, OS feature licenses are portable, and bulk activated through ExtremeCloud IQ. |

[0001564590-21-054929:mdna:36]
[same as prior period, unchanged from 0001564590-21-021969:mdna:14]

[0001564590-21-054929:mdna:37]
|  | • | End-to-End Portfolio. Our cloud-driven solutions provide visibility, control and strategic intelligence from the edge to the data center, across networks and applications. Our solutions include wired switching, wireless switching, wireless access points, WLAN controllers, routers, and an extensive portfolio of software applications that deliver AI-enhanced access control, network and application analytics, as well as network management. All can be managed, assessed and controlled from a single pane of glass on premises or from the cloud. |

[0001564590-21-054929:mdna:38]
[same as prior period, unchanged from 0001564590-21-021969:mdna:17]

[0001564590-21-054929:mdna:39]
[same as prior period, unchanged from 0001564590-21-021969:mdna:18]

[0001564590-21-054929:mdna:40]
[same as prior period, unchanged from 0001564590-21-021969:mdna:19]

[0001564590-21-054929:mdna:41]
[same as prior period, unchanged from 0001564590-21-021969:mdna:20]

[0001564590-21-054929:mdna:42]
[same as prior period, unchanged from 0001564590-21-021969:mdna:21]

[0001564590-21-054929:mdna:43]
[same as prior period, unchanged from 0001564590-21-021969:mdna:22]

[0001564590-21-054929:mdna:44]
[same as prior period, unchanged from 0001564590-21-021969:mdna:23]

[0001564590-21-054929:mdna:45]
Acquisition

[0001564590-21-054929:mdna:46]
On September On September 14, 2021 (the “Acquisition Date”), the Company completed its acquisition (the “Acquisition”) of Ipanematech SAS (“Ipanema”), the cloud-native enterprise Software-Defined Wide Area Network (“SD-WAN”) business unit of Infovista pursuant to a Sale and Purchase Agreement (“the Agreement”).  Under the terms of the Acquisition, the net consideration paid by Extreme to Ipanema stockholders was $70.9 million. The primary reason for the acquisition was to acquire the talent and the technology which will allow us to expand our portfolio with new cloud-managed SD-WAN and security offerings to support our enterprise customers.

[0001564590-21-054929:mdna:47]
[same as prior period, unchanged from 0001564590-21-021969:mdna:24]

[0001564590-21-054929:mdna:48]
During the first quarter of fiscal 2022, we achieved the following results:

[0001564590-21-054929:mdna:49]
|  | • | Net revenues of $267.7 million compared to $235.8 million in the first quarter of fiscal 2021. |

[0001564590-21-054929:mdna:50]
|  | • | Product revenues of $185.2 million compared to $161.4 million in the first quarter of fiscal 2021. |

[0001564590-21-054929:mdna:51]
|  | • | Service and subscription revenues of $82.5 million compared to $74.4 million in the first quarter of fiscal 2021. |

[0001564590-21-054929:mdna:52]
|  | • | Total gross margin of 58.1% of net revenues compared to 57.3% of net revenues in the first quarter of fiscal 2021. |

[0001564590-21-054929:mdna:53]
|  | • | Operating income of $18.4 million compared to operating loss of $0.1 million in the first quarter of fiscal 2021. |

[0001564590-21-054929:mdna:54]
|  | • | Net income of $12.7 million compared to net loss of $8.8 million in the first quarter of fiscal 2021. |

[0001564590-21-054929:mdna:55]
|  | • | Cash flows provided by operating activities of $40.3 million compared to $24.7 million in the three months ended September 30, 2020. |

[0001564590-21-054929:mdna:56]
|  | • | Cash of $191.3 million as of September 30, 2021 compared to $246.9 million as of June 30, 2021. |

[0001564590-21-054929:mdna:57]
[same as prior period, unchanged from 0001564590-21-021969:mdna:38]

[0001564590-21-054929:mdna:58]
[same as prior period, unchanged from 0001564590-21-021969:mdna:39]

[0001564590-21-054929:mdna:59]
|  |  | Three Months Ended |  |  |  |
|  |  | September 30, 2021 |  |  | September 30, 2020 |  |  | $ Change |  |  | % Change |  |  |  |
| Net revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 185,161 |  |  | $ | 161,396 |  |  | $ | 23,765 |  |  |  | 14.7 | % |  |  |
| Percentage of net revenues |  |  | 69.2 | % |  |  | 68.4 | % |  |  |  |  |  |  |  |  |  |  |
| Service and subscription |  |  | 82,523 |  |  |  | 74,406 |  |  |  | 8,117 |  |  |  | 10.9 | % |  |  |
| Percentage of net revenues |  |  | 30.8 | % |  |  | 31.6 | % |  |  |  |  |  |  |  |  |  |  |
| Total net revenues |  | $ | 267,684 |  |  | $ | 235,802 |  |  | $ | 31,882 |  |  |  | 13.5 | % |  |  |

[0001564590-21-054929:mdna:60]
Product revenues increased $23.8 million or 14.7% for the three months ended September 30, 2021, as compared to the corresponding period of fiscal 2021. The product revenues increase for the three months ended September 30, 2021 was primarily due to the material slow-down in global demand during the corresponding period of fiscal 2021 due to the global outbreak of COVID-19.

[0001564590-21-054929:mdna:61]
Service and subscription revenues increased $8.1 million, or 10.9% for the three months ended September 30, 2021 as compared to the corresponding period in fiscal 2021. The increase in service and subscription revenues was primarily due to the growth in subscription revenues.

[0001564590-21-054929:mdna:62]
[same as prior period, unchanged from 0001564590-21-021969:mdna:43]

[0001564590-21-054929:mdna:63]
|  |  | Three Months Ended |  |
|  |  | September 30, 2021 |  |  | September 30, 2020 |  |  | $ Change |  |  | % Change |  |
| Gross profit: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 104,217 |  |  | $ | 88,001 |  |  | $ | 16,216 |  |  |  | 18.4 | % |
| Percentage of product revenues |  |  | 56.3 | % |  |  | 54.5 | % |  |  |  |  |  |  |  |  |
| Service and subscription |  |  | 51,386 |  |  |  | 47,017 |  |  |  | 4,369 |  |  |  | 9.3 | % |
| Percentage of service and subscription revenues |  |  | 62.3 | % |  |  | 63.2 | % |  |  |  |  |  |  |  |  |
| Total gross profit |  | $ | 155,603 |  |  | $ | 135,018 |  |  | $ | 20,585 |  |  |  | 15.2 | % |
| Percentage of net revenues |  |  | 58.1 | % |  |  | 57.3 | % |  |  |  |  |  |  |  |  |

[0001564590-21-054929:mdna:64]
Product gross profit increased $16.2 million or 18.4% for the three months ended September 30, 2021, as compared to the corresponding period in fiscal 2021. The increase in product gross profit was primarily due to increased revenues along with lower distribution charges of $0.5 million, which were mainly due to decreased tariffs, lower excess and obsolete inventory charges of $0.6 million, lower warranty costs of $0.4 million and lower amortization of intangibles due to certain intangibles being fully depreciated.

[0001564590-21-054929:mdna:65]
Service and subscription gross profit increased $4.4 million or 9.3% for the three months ended September 30, 2021, as compared to the corresponding period in fiscal 2021. The increase was primarily due to increased service and subscription revenues, partially offset by higher personnel costs, professional fees and increased cloud service costs.

[0001564590-21-054929:mdna:66]
[same as prior period, unchanged from 0001564590-21-021969:mdna:49]

[0001564590-21-054929:mdna:67]
[same as prior period, unchanged from 0001564590-21-021969:mdna:50]

[0001564590-21-054929:mdna:68]
|  |  | Three Months Ended |  |
|  |  | September 30, 2021 |  |  | September 30, 2020 |  |  | $ Change |  |  | % Change |  |
| Research and development |  | $ | 47,766 |  |  | $ | 49,524 |  |  | $ | (1,758 | ) |  |  | (3.5 | )% |
| Sales and marketing |  |  | 69,527 |  |  |  | 64,325 |  |  |  | 5,202 |  |  |  | 8.1 | % |
| General and administrative |  |  | 17,003 |  |  |  | 16,461 |  |  |  | 542 |  |  |  | 3.3 | % |
| Acquisition and integration costs |  |  | 1,510 |  |  |  | 1,975 |  |  |  | (465 | ) |  |  | (23.5 | )% |
| Restructuring and related charges |  |  | 279 |  |  |  | 1,001 |  |  |  | (722 | ) |  |  | (72.1 | )% |
| Amortization of intangibles |  |  | 1,154 |  |  |  | 1,792 |  |  |  | (638 | ) |  |  | (35.6 | )% |
| Total operating expenses |  | $ | 137,239 |  |  | $ | 135,078 |  |  | $ | 2,161 |  |  |  | 1.6 | % |

[0001564590-21-054929:mdna:69]
[same as prior period, unchanged from 0001564590-21-021969:mdna:52]

[0001564590-21-054929:mdna:70]
[same as prior period, unchanged from 0001564590-21-021969:mdna:53]

[0001564590-21-054929:mdna:71]
Research and development expenses decreased by $1.8 million or 3.5% for the three months ended September 30, 2021, as compared to the corresponding period in fiscal 2021. The decrease in research and development expenses was due to a $1.3 million decrease in facility and information technology costs and a $1.4 million decrease in software licenses and engineering project costs which lowered depreciation expense, partially offset by a $0.6 million increase in professional and contractor fees and a $0.4 million increase in personnel related costs.

[0001564590-21-054929:mdna:72]
[same as prior period, unchanged from 0001564590-21-021969:mdna:56]

[0001564590-21-054929:mdna:73]
[same as prior period, unchanged from 0001564590-21-021969:mdna:57]

[0001564590-21-054929:mdna:74]
Sales and marketing expenses increased by $5.2 million or 8.1% for the three months ended September 30, 2021, as compared to the corresponding period in fiscal 2021. The increase in sales and marketing expenses was primarily due to a $4.1 million increase in personnel costs primarily due to higher compensation and benefits costs due to increase in headcount, a $1.0 million increase in travel costs and a $0.4 million increase in other expenses primarily marketing and sales promotions costs, partially offset by a $0.3 million decrease in professional fees.

[0001564590-21-054929:mdna:75]
[same as prior period, unchanged from 0001564590-21-021969:mdna:60]

[0001564590-21-054929:mdna:76]
General and administrative expenses consist primarily of personnel costs (which consist of compensation, benefits and share-based compensation), legal and professional service costs, and facilities and information technology costs.

[0001564590-21-054929:mdna:77]
General and administrative expenses increased by $0.5 million or 3.3% for the three months ended September 30, 2021, as compared to the corresponding period in fiscal 2021. The increase in general and administrative expenses was primarily due to a $1.2 million increase in personnel costs primarily compensation expenses partially offset by a $0.7 million decrease in legal and professional fees.

[0001564590-21-054929:mdna:78]
[same as prior period, unchanged from 0001564590-21-021969:mdna:64]

[0001564590-21-054929:mdna:79]
During the three months ended September 30, 2021, we incurred $1.5 million of integration costs which consisted primarily of professional fees for legal advisory services and financial services related to the acquisition of Ipanema.

[0001564590-21-054929:mdna:80]
During the three months ended September 30, 2020, we incurred $2.0 million of acquisition and integration costs. Acquisition and integration costs consisted primarily of additional professional fees for system integration and financial services related to Aerohive acquisition.

[0001564590-21-054929:mdna:81]
Restructuring and Related Charges

[0001564590-21-054929:mdna:82]
For the three months ended September 30, 2021, we recorded restructuring and related charges of $0.3 million which primarily comprised of facility-related charges related to our previously impaired facilities.

[0001564590-21-054929:mdna:83]
For the three months ended September 30, 2020, we recorded restructuring charges of $1.0 million. We continued our reduction-in-force initiative began in the third quarter of fiscal 2020 and recorded related severance and benefits charges of $0.7 million related to the 2020 Plan. In addition, we had facility-related charges of $0.3 million related to our previously impaired facilities.

[0001564590-21-054929:mdna:84]
[same as prior period, unchanged from 0001564590-21-021969:mdna:70]

[0001564590-21-054929:mdna:85]
During the three months ended September 30, 2021 and 2020, we recorded $1.2 million and $1.8 million, respectively, of operating expenses for amortization of intangibles. The decrease was primarily due to lower amortization related to certain acquired intangibles from previous acquisitions becoming fully amortized.

[0001564590-21-054929:mdna:86]
[same as prior period, unchanged from 0001564590-21-021969:mdna:73]

[0001564590-21-054929:mdna:87]
During the three months ended September 30, 2021 and 2020, we recorded $3.9 million and $6.7 million, respectively, in interest expense.  The decreases in interest expense were primarily driven by lower average loan balances and lower average rates for the three months ended September 30, 2021 under our 2019 Credit Agreement.

[0001564590-21-054929:mdna:88]
[same as prior period, unchanged from 0001564590-21-021969:mdna:76]

[0001564590-21-054929:mdna:89]
During the three months ended September 30, 2021 and 2020, we recorded other income, net of $0.2 million and other expense, net of $0.9 million, respectively. The changes for the three months ended September 30, 2021 was primarily due to foreign exchange losses from the revaluation of certain assets and liabilities denominated in foreign currencies into U.S. Dollars.

[0001564590-21-054929:mdna:90]
[same as prior period, unchanged from 0001564590-21-021969:mdna:78]

[0001564590-21-054929:mdna:91]
For the three months ended September 30, 2021 and 2020, we recorded an income tax provision of $2.1 million and $1.3 million, respectively.

[0001564590-21-054929:mdna:92]
The income tax provisions for the three months ended September 30, 2021 and 2020 consisted of (1) taxes on the income of our foreign subsidiaries, (2) foreign withholding taxes, (3) state taxes in jurisdictions where we have no remaining state net operating losses and (4) tax expense associated with the establishment of a U.S. deferred tax liability for amortizable goodwill resulting from the acquisition of Enterasys Networks, Inc., the WLAN Business, the Campus Fabric Business and the Data Center Business.

[0001564590-21-054929:mdna:93]
[same as prior period, unchanged from 0001564590-21-021969:mdna:81]

[0001564590-21-054929:mdna:94]
[same as prior period, unchanged from 0001564590-21-021969:mdna:82]

[0001564590-21-054929:mdna:95]
As discussed in Part II, Item 7, “Management’s Discussion and Analysis of Financial Condition and Results of Operations” of our Annual Report on Form 10-K for the year ended June 30, 2021, we consider the following accounting policies to be the most critical in understanding the judgments that are involved in preparing our consolidated financial statements:

[0001564590-21-054929:mdna:96]
[same as prior period, unchanged from 0001564590-21-021969:mdna:84]

[0001564590-21-054929:mdna:97]
[same as prior period, unchanged from 0001564590-21-021969:mdna:85]

[0001564590-21-054929:mdna:98]
[same as prior period, unchanged from 0001564590-21-021969:mdna:86]

[0001564590-21-054929:mdna:99]
[same as prior period, unchanged from 0001564590-21-021969:mdna:89]

[0001564590-21-054929:mdna:100]
[same as prior period, unchanged from 0001564590-21-021969:mdna:90]

[0001564590-21-054929:mdna:101]
|  |  | September 30, 2021 |  |  | June 30, 2021 |  |
| Cash |  | $ | 191,349 |  |  | $ | 246,894 |  |

[0001564590-21-054929:mdna:102]
As of September 30, 2021, our principal sources of liquidity consisted of cash of $191.3 million and accounts receivable, net of $129.6 million, and available borrowings under our five-year 2019 Revolving Facility of $60.2 million. Our principal uses of cash include the purchase of finished goods inventory from our contract manufacturers, payroll and other operating expenses related to the development and marketing of our products, purchases of property and equipment, and repayments of debt and related interest. We believe that our $191.3 million of cash at September 30, 2021, our cash flow from operations, and the availability of borrowings from the 2019 Revolving Facility will be sufficient to fund our planned operations for at least the next 12 months.

[0001564590-21-054929:mdna:103]
On November 2, 2018, our Board of Directors announced that it had authorized management to repurchase up to $60.0 million of its shares of common stock for two years from the date of authorization, of which $15.0 million was used for repurchases in fiscal 2019 and $30.0 million was used for repurchases in fiscal 2020. In February 2020, our Board of Directors increased the authorization to repurchase by $40.0 million to $100.0 million and extended the period for repurchases for three years from February 5, 2020.  Purchases may be made from time to time in the open market or in privately negotiated transactions. The manner, timing and amount of any future purchases will be determined by our management based on their evaluation of market conditions, stock price, Extreme’s ongoing determination that it is the best use of available cash and other factors. The repurchase program does not obligate Extreme to acquire any shares of its common stock, may be suspended or terminated at any time without prior notice and will be subject to regulatory considerations. There were no repurchases in the three months ended September 30, 2021.

[0001564590-21-054929:mdna:104]
In connection with the acquisition of Aerohive, as of August 9, 2019, we amended the 2018 Credit Agreement, which is no longer outstanding, and entered into the 2019 Credit Agreement, by and among us, as borrower, several banks and other financial institutions as Lenders, BMO Harris Bank N.A., as an issuing lender and swingline lender, Silicon Valley Bank, as an Issuing Lender, and Bank of Montreal, as administrative agent and collateral agent for the Lenders. The 2019 Credit Agreement provides for a five-year first lien term loan facility in an aggregate principal amount of $380.0 million and a five-year revolving loan facility in an aggregate principal amount of $75.0 million (“2019 Revolving Facility”).  In addition, we may request incremental term loans and/or incremental revolving loan commitments in an aggregate amount not to exceed the sum of $100.0 million plus an unlimited amount that is subject to pro forma compliance with certain financial tests.  On August 9, 2019, we used the proceeds to partially fund the acquisition of Aerohive and for working capital and general corporate purposes.

[0001564590-21-054929:mdna:105]
[same as prior period, unchanged from 0001564590-21-021969:mdna:95]

[0001564590-21-054929:mdna:106]
The 2019 Credit Agreement requires us to maintain certain minimum financial ratios at the end of each fiscal quarter. The 2019 Credit Agreement also includes covenants and restrictions that limit, among other things, our ability to incur additional indebtedness, create liens upon any of our property, merge, consolidate or sell all or substantially all of our assets. The 2019 Credit Agreement also includes customary events of default which may result in acceleration of the outstanding balance.

[0001564590-21-054929:mdna:107]
Financial covenants under the 2019 Credit Agreement require us to maintain a minimum consolidated fixed charge and consolidated leverage ratio at the end of each fiscal quarter through maturity.  The 2019 Credit Agreement also includes covenants and restrictions that limit, among other things, our ability to incur additional indebtedness, create liens upon any of our property, merge, consolidate or sell all or substantially all of our assets.  The 2019 Credit Agreement also includes customary events of default which may result in acceleration of the outstanding balance.

[0001564590-21-054929:mdna:108]
On April 8, 2020, we entered into the First Amendment to waive certain terms and financial covenants of the 2019 Credit Agreement through July 31, 2020. On May 8, 2020, we entered into the Second Amendment which superseded the First Amendment and provided certain revised terms and financial covenants through March 31, 2021. Subsequent to March 31, 2021, the original terms

[0001564590-21-054929:mdna:109]
and financial covenants under the 2019 Credit Agreement resumed in effect. The Second Amendment required us to maintain certain minimum cash requirement and certain financial metrics at the end of each fiscal quarter through March 31, 2021.  Under the terms of the Second Amendment, we were not permitted to exceed $55.0 million in our outstanding balance under the 2019 Revolving Facility, the applicable margin for Eurodollar rate was 4.5% and we were restricted from pursuing certain activities such as incurring additional debt, stock repurchases, making acquisitions or declaring a dividend, until we are in compliance with the original covenants of the 2019 Credit Agreement. On November 3, 2020, we and our lenders entered into the Third Amendment to increase the sublimit for letters of credit to $20.0 million. On December 8, 2020, we and our lenders entered into the Fourth Amendment to waive and amend certain terms and financial covenants within the 2019 Credit Agreement through March 31, 2021.

[0001564590-21-054929:mdna:110]
The Second Amendment provided for us to end the covenant Suspension Period early and revert to the covenants and interest rates per the original terms of the 2019 Credit Agreement dated August 9, 2019 by filing a Suspension Period Early Termination Notice and Covenant Certificate demonstrating compliance. For the twelve-month period ended March 31, 2021 our financial performance was in compliance with the original covenants defined in the 2019 Credit Agreement and as such we filed a Suspension Early Termination Notice and Covenant Certificate with the administration agent subsequent to filing our Form 10-Q for the quarterly period ended March 31, 2021.  Returning to compliance with the covenants per the original terms of the 2019 Credit Agreement dated August 9, 2019, resulted in our Eurodollar loan spread decreasing from 4.5% during the suspension period to 2.75% and unused facility commitment fee decreasing from 0.4% to 0.35%, and the limitation on revolver borrowings being removed effective May 1, 2021 after filing of the certificate with the administrative agent.

[0001564590-21-054929:mdna:111]
[same as prior period, unchanged from 0001564590-21-021969:mdna:101]

[0001564590-21-054929:mdna:112]
[same as prior period, unchanged from 0001564590-21-021969:mdna:102]

[0001564590-21-054929:mdna:113]
|  |  | Three Months Ended |  |
|  |  | September 30, 2021 |  |  | September 30, 2020 |  |
| Net cash provided by operating activities |  | $ | 40,255 |  |  | $ | 24,745 |  |
| Net cash used in investing activities |  |  | (72,927 | ) |  |  | (3,023 | ) |
| Net cash used in financing activities |  |  | (22,682 | ) |  |  | (22,772 | ) |
| Foreign currency effect on cash |  |  | (191 | ) |  |  | 294 |  |
| Net decrease in cash |  | $ | (55,545 | ) |  | $ | (756 | ) |

[0001564590-21-054929:mdna:114]
[same as prior period, unchanged from 0001564590-21-021969:mdna:104]

[0001564590-21-054929:mdna:115]
Cash flows provided by operations in the three months ended September 30, 2021, were $40.3 million, including our net income of $12.7 million and non-cash expenses of $27.8 million for items such as amortization of intangibles, share-based compensation, depreciation, reduction in carrying amount of right-of-use assets, deferred income taxes, and interest.  Other sources of cash for the period included decreases in accounts receivables and inventory and increases in accounts payable, deferred revenues and other current and long-term liabilities. This was partially offset by increase in prepaid expenses and other current assets and decreases in accrued compensation and operating lease liabilities.

[0001564590-21-054929:mdna:116]
Cash flows provided by operations in the three months ended September 30, 2020, were $24.7 million, including our net loss of $8.8 million and non-cash expenses of $30.4 million for items such as amortization of intangibles, share-based compensation, depreciation, reduction in carrying amount of right-of-use assets, deferred income taxes and imputed interest.  Other sources of cash for the period included a decrease in inventory and increase in accounts payable and deferred revenues. This was partially offset by decreases in accrued compensation, other current and long-term liabilities, and operating lease liabilities and increases in accounts receivables and prepaid expenses and other current assets.

[0001564590-21-054929:mdna:117]
[same as prior period, unchanged from 0001564590-21-021969:mdna:107]

[0001564590-21-054929:mdna:118]
Cash flows used in investing activities in the three months ended September 30, 2021 were $72.9 million primarily due to the payment of $69.5 million (net of cash acquired) for the acquisition of Ipanema and $3.4 million for the purchases of property and equipment.

[0001564590-21-054929:mdna:119]
Cash flows used in investing activities in the three months ended September 30, 2020 were $3.0 million for the purchases of property and equipment.

[0001564590-21-054929:mdna:120]
Net Cash Used in Financing Activities

[0001564590-21-054929:mdna:121]
Cash flows used in financing activities in the three months ended September 30, 2021 were $22.7 million due primarily to debt repayments of $16.8 million, payment of contingent consideration of $0.6 million, $1.0 million for deferred payments on acquisitions and $4.4 million for taxes paid on vested and released stock awards net of proceeds from the issuance of shares of our common stock under our Employee Stock Purchase Plan (“ESPP”) and exercise of stock options.

[0001564590-21-054929:mdna:122]
Cash flows used in financing activities in the three months ended September 30, 2020 were $22.8 million due primarily to debt repayments of $24.8 million, payment of contingent consideration of $0.6 million, and $1.0 million for deferred payments on acquisitions. This was partially offset by $3.6 million of proceeds from the issuance of shares of our common stock under our ESPP and exercise of stock options, net of taxes paid on vested and released stock awards.

[0001564590-21-054929:mdna:123]
[same as prior period, unchanged from 0001564590-21-021969:mdna:113]

[0001564590-21-054929:mdna:124]
Foreign currency effect on cash increased in the three months ended September 30, 2021 and 2020, primarily due to changes in foreign currency exchange rates between the U.S. Dollar and particularly the Indian Rupee, the UK Pound, and the EURO.

[0001564590-21-054929:mdna:125]
[same as prior period, unchanged from 0001564590-21-021969:mdna:115]

[0001564590-21-054929:mdna:126]
The following summarizes our contractual obligations as of September 30, 2021, and the effect such obligations are expected to have on our liquidity and cash flow in future periods (in thousands):

[0001564590-21-054929:mdna:127]
|  |  | Payments due by Period |  |
|  |  | Total |  |  | Less than 1 Year |  |  | 1-3 years |  |  | 3-5 years |  |  | More than 5 years |  |
| Contractual obligations: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Debt obligations |  | $ | 330,000 |  |  | $ | 28,500 |  |  | $ | 301,500 |  |  | $ | — |  |  | $ | — |  |
| Interest on debt obligations |  |  | 21,711 |  |  |  | 8,811 |  |  |  | 12,900 |  |  |  | — |  |  |  | — |  |
| Unconditional purchase obligations |  |  | 64,910 |  |  |  | 64,910 |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Contractual commitments |  |  | 90,844 |  |  |  | 27,732 |  |  |  | 39,416 |  |  |  | 17,233 |  |  |  | 6,463 |  |
| Lease payments on operating leases |  |  | 50,995 |  |  |  | 15,566 |  |  |  | 22,732 |  |  |  | 8,765 |  |  |  | 3,932 |  |
| Deferred payments for an acquisition |  |  | 6,000 |  |  |  | 4,000 |  |  |  | 2,000 |  |  |  | — |  |  |  | — |  |
| Contingent consideration for an acquisition |  |  | 358 |  |  |  | 358 |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Other liabilities |  |  | 517 |  |  |  | 181 |  |  |  | 336 |  |  |  | — |  |  |  | — |  |
| Total contractual cash obligations |  | $ | 565,335 |  |  | $ | 150,058 |  |  | $ | 378,884 |  |  | $ | 25,998 |  |  | $ | 10,395 |  |

[0001564590-21-054929:mdna:128]
[same as prior period, unchanged from 0001564590-21-021969:mdna:118]

[0001564590-21-054929:mdna:129]
[same as prior period, unchanged from 0001564590-21-021969:mdna:119]

[0001564590-21-054929:mdna:130]
Interest on debt obligations includes the effect of our interest rate swap agreements.

[0001564590-21-054929:mdna:131]
[same as prior period, unchanged from 0001564590-21-021969:mdna:120]

[0001564590-21-054929:mdna:132]
Contractual commitments to suppliers represent commitments for future services.

[0001564590-21-054929:mdna:133]
[same as prior period, unchanged from 0001564590-21-021969:mdna:122]

[0001564590-21-054929:mdna:134]
[same as prior period, unchanged from 0001564590-21-021969:mdna:123]

[0001564590-21-054929:mdna:135]
[same as prior period, unchanged from 0001564590-21-021969:mdna:124]

[0001564590-21-054929:mdna:136]
[same as prior period, unchanged from 0001564590-21-021969:mdna:125]

[0001564590-21-054929:mdna:137]
[same as prior period, unchanged from 0001564590-21-021969:mdna:126]

[0001564590-21-054929:mdna:138]
We did not have any material commitments for capital expenditures as of September 30, 2021.

[0001564590-21-054929:mdna:139]
[same as prior period, unchanged from 0001564590-21-021969:mdna:128]

[0001564590-21-054929:mdna:140]
We did not have any off-balance sheet arrangements as of September 30, 2021.
