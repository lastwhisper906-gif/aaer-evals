# EXTR 8-K — 0001564590-21-053306 filed 2021-11-02

## item codes, every 8-K on or before 2021-11-05

- 2021-11-05 0001564590-21-054934 — 5.07
- 2021-11-02 0001564590-21-053306 — 2.02, 9.01
- 2021-09-22 0001564590-21-048585 — 4.01, 9.01
- 2021-08-10 0001564590-21-043098 — 1.01
- 2021-07-28 0001564590-21-038470 — 2.02, 9.01
- 2021-05-18 0001564590-21-028693 — 1.01, 3.03, 9.01
- 2021-04-28 0001564590-21-021102 — 2.02, 9.01
- 2021-02-09 0001564590-21-005000 — 2.02, 9.01
- 2021-01-27 0001564590-21-002633 — 2.02, 9.01
- 2020-11-06 0001564590-20-051993 — 5.07
- 2020-10-28 0001564590-20-048160 — 2.02, 9.01
- 2020-10-08 0001564590-20-046117 — 2.02, 9.01
- 2020-09-11 0001564590-20-043260 — 4.01, 9.01
- 2020-08-05 0001564590-20-036431 — 2.02, 9.01
- 2020-06-01 0001564590-20-027850 — 3.03, 9.01
- 2020-05-11 0001564590-20-024216 — 2.02, 9.01
- 2020-04-08 0001564590-20-015927 — 2.02, 8.01, 9.01
- 2020-02-25 0001193125-20-047202 — 8.01, 9.01
- 2020-01-29 0001564590-20-002375 — 2.02, 9.01
- 2020-01-29 0001193125-20-017673 — 5.02, 9.01
- 2019-11-08 0001193125-19-288358 — 5.07
- 2019-10-30 0001564590-19-038508 — 2.02, 9.01
- 2019-10-25 0001564590-19-037908 — 9.01 — amendment of 0001193125-19-217553
- 2019-10-18 0001193125-19-269734 — 7.01, 9.01
- 2019-08-30 0001193125-19-235271 — 5.02 — amendment of 0001193125-19-229280
- 2019-08-26 0001193125-19-229280 — 5.02, 9.01
- 2019-08-09 0001193125-19-217553 — 1.01, 2.01, 2.03, 9.01
- 2019-07-31 0001564590-19-027208 — 2.02, 9.01
- 2019-06-26 0001193125-19-181938 — 1.01, 2.05, 9.01
- 2019-05-01 0001564590-19-014567 — 2.02, 9.01
- 2019-01-29 0001564590-19-001270 — 2.02, 9.01
- 2019-01-25 0001564590-19-001157 — 8.01, 9.01
- 2018-11-20 0001193125-18-331450 — 5.02, 9.01
- 2018-11-15 0001564590-18-029683 — 5.07
- 2018-11-02 0001564590-18-026372 — 2.02, 8.01, 9.01
- 2018-09-19 0001193125-18-276766 — 5.02
- 2018-08-08 0001564590-18-020191 — 2.02, 9.01
- 2018-06-05 0001564590-18-015067 — 3.03, 9.01
- 2018-05-08 0001564590-18-011817 — 2.02, 9.01
- 2018-05-07 0001564590-18-011264 — 1.01, 1.02, 2.03, 9.01
- 2018-02-06 0001564590-18-001403 — 2.02, 2.05, 9.01
- 2018-02-01 0001564590-18-001166 — 5.02
- 2018-01-12 0001564590-18-000462 — 9.01 — amendment of 0001193125-17-323879
- 2017-11-15 0001564590-17-023847 — 5.07
- 2017-11-07 0001564590-17-022235 — 2.02, 9.01
- 2017-11-03 0001193125-17-332828 — 9.01 — amendment of 0001193125-17-323879
- 2017-10-30 0001193125-17-323879 — 1.01, 2.01, 7.01, 9.01
- 2017-10-03 0001193125-17-302411 — 1.01, 9.01
- 2017-10-03 0001193125-17-301597 — 1.01, 1.02, 7.01, 9.01
- 2017-09-29 0001564590-17-019099 — 9.01 — amendment, the index does not say of what
- 2017-08-14 0001564590-17-017659 — 2.02, 9.01
- 2017-08-02 0001564590-17-014950 — 5.02
- 2017-07-18 0001564590-17-013557 — 1.01, 2.01, 2.03, 9.01
- 2017-06-05 0001564590-17-012126 — 3.03, 9.01
- 2017-05-03 0001564590-17-008378 — 2.02, 9.01
- 2017-03-30 0001193125-17-102344 — 1.01, 9.01
- 2017-03-07 0001193125-17-073306 — 1.01, 9.01
- 2017-02-21 0001193125-17-048182 — 5.02
- 2017-02-01 0001564590-17-000835 — 2.02, 9.01
- 2017-01-06 0001564590-17-000138 — 2.05
- 2016-11-21 0001564590-16-029539 — 5.07
- 2016-11-01 0001564590-16-026732 — 2.02, 9.01
- 2016-10-31 0001193125-16-752557 — 1.01, 2.01, 2.03
- 2016-09-15 0001193125-16-711097 — 1.01, 9.01
- 2016-08-03 0001564590-16-022347 — 2.02, 9.01
- 2016-05-19 0001564590-16-019720 — 5.02, 9.01
- 2016-05-09 0001564590-16-018660 — 3.03, 9.01
- 2016-04-27 0001564590-16-016754 — 2.02, 9.01
- 2016-02-24 0001564590-16-013189 — 8.01
- 2016-02-09 0001564590-16-012469 — 8.01
- 2016-01-28 0001564590-16-012054 — 2.02, 9.01
- 2015-11-17 0001078271-15-000136 — 5.07
- 2015-10-29 0001078271-15-000125 — 2.02, 9.01
- 2015-08-31 0001078271-15-000111 — 8.01, 9.01
- 2015-08-11 0001078271-15-000096 — 5.02
- 2015-08-06 0001078271-15-000093 — 2.02, 9.01
- 2015-06-30 0001078271-15-000089 — 1.01, 9.01
- 2015-05-20 0001078271-15-000077 — 2.05, 9.01
- 2015-05-19 0001078271-15-000075 — 3.03, 9.01
- 2015-05-06 0001078271-15-000050 — 2.02, 9.01
- 2015-05-04 0001078271-15-000048 — 5.02, 9.01
- 2015-04-29 0001078271-15-000038 — 5.02, 9.01
- 2015-04-21 0001078271-15-000034 — 5.02, 9.01
- 2015-04-09 0001078271-15-000032 — 2.02, 5.02, 9.01
- 2015-02-18 0001078271-15-000021 — 8.01
- 2015-02-17 0001078271-15-000019 — 5.02
- 2015-01-28 0001078271-15-000004 — 2.02, 9.01
- 2014-12-18 0001078271-14-000081 — 5.02, 9.01
- 2014-12-17 0001078271-14-000079 — 5.02
- 2014-11-20 0001078271-14-000075 — 1.01, 9.01
- 2014-11-17 0001078271-14-000073 — 5.07
- 2014-10-28 0001078271-14-000062 — 2.02, 9.01
- 2014-10-15 0001078271-14-000060 — 2.02, 9.01
- 2014-10-02 0001078271-14-000057 — 5.02, 9.01
- 2014-08-14 0001078271-14-000047 — 2.02, 9.01
- 2014-07-21 0001078271-14-000042 — 2.02, 9.01
- 2014-05-23 0001078271-14-000036 — 5.02, 9.01
- 2014-05-20 0001078271-14-000034 — 3.03, 9.01
- 2014-05-12 0001078271-14-000030 — 5.02
- 2014-05-08 0001078271-14-000022 — 5.02, 9.01
- 2014-05-07 0001078271-14-000018 — 2.02, 9.01 — amendment, the index does not say of what
- 2014-05-06 0001078271-14-000016 — 2.02, 9.01
- 2014-02-20 0001078271-14-000014 — 5.02, 9.01
- 2014-02-18 0001078271-14-000010 — 5.02
- 2014-02-05 0001078271-14-000006 — 2.02, 9.01
- 2014-01-13 0001104659-14-002030 — 9.01 — amendment of 0001078271-13-000058
- 2013-11-25 0001078271-13-000081 — 5.07
- 2013-11-07 0001078271-13-000064 — 5.02, 9.01
- 2013-11-04 0001078271-13-000060 — 2.02, 9.01
- 2013-11-01 0001078271-13-000058 — 1.01, 2.01, 2.03, 8.01, 9.01
- 2013-10-16 0001078271-13-000056 — 8.01, 9.01
- 2013-09-13 0001078271-13-000052 — 1.01, 8.01, 9.01
- 2013-08-23 0001078271-13-000044 — 5.02, 9.01
- 2013-08-02 0001078271-13-000042 — 5.02
- 2013-07-30 0001078271-13-000039 — 2.02, 9.01
- 2013-07-30 0001078271-13-000037 — 5.02, 9.01
- 2013-06-21 0001078271-13-000032 — 8.01
- 2013-05-01 0001078271-13-000018 — 5.02, 9.01
- 2013-04-30 0001078271-13-000015 — 2.02, 9.01
- 2013-03-01 0001078271-13-000010 — 8.01
- 2013-02-19 0001078271-13-000008 — 5.02
- 2013-01-30 0001078271-13-000004 — 2.02, 9.01
- 2013-01-07 0001078271-13-000002 — 1.01, 2.02, 2.03, 2.05, 9.01
- 2012-12-03 0001078271-12-000094 — 5.02, 5.07, 8.01
- 2012-10-31 0001078271-12-000071 — 2.02, 9.01
- 2012-10-19 0001078271-12-000069 — 1.01, 2.03, 9.01
- 2012-10-16 0001078271-12-000067 — 8.01
- 2012-10-01 0001193125-12-411392 — 5.02, 8.01, 9.01
- 2012-09-24 0001193125-12-401798 — 5.02, 9.01
- 2012-09-21 0001193125-12-399896 — 5.02, 9.01
- 2012-09-18 0001193125-12-394379 — 1.01, 5.02, 9.01
- 2012-09-12 0001193125-12-388591 — 8.01
- 2012-08-27 0001078271-12-000057 — 8.01
- 2012-08-03 0001078271-12-000041 — 7.01, 9.01
- 2012-08-01 0001078271-12-000039 — 2.02, 9.01
- 2012-07-25 0001078271-12-000037 — 8.01
- 2012-05-22 0001078271-12-000033 — 5.02, 9.01
- 2012-05-21 0001078271-12-000030 — 8.01
- 2012-05-09 0001078271-12-000028 — 5.02, 9.01
- 2012-05-02 0001078271-12-000023 — 2.02, 9.01
- 2012-04-30 0001078271-12-000020 — 3.03, 5.07, 9.01
- 2012-04-19 0001078271-12-000012 — 2.02, 5.02, 9.01
- 2012-03-12 0001078271-12-000010 — 5.02, 9.01
- 2012-02-24 0001078271-12-000008 — 8.01
- 2012-02-02 0001078271-12-000004 — 2.02, 9.01
- 2012-01-30 0001078271-12-000002 — 1.01
- 2011-12-01 0001078271-11-000104 — 8.01
- 2011-11-08 0001078271-11-000099 — 8.01
- 2011-11-02 0001078271-11-000094 — 2.02, 9.01
- 2011-10-24 0001078271-11-000089 — 8.01, 9.01
- 2011-10-11 0001078271-11-000085 — 8.01
- 2011-09-29 0001078271-11-000082 — 8.01
- 2011-09-15 0001078271-11-000070 — 5.02, 9.01
- 2011-08-11 0001078271-11-000058 — 8.01
- 2011-08-10 0001078271-11-000055 — 5.02
- 2011-08-08 0001078271-11-000045 — 5.02
- 2011-08-01 0001078271-11-000038 — 2.02, 9.01
- 2011-07-14 0001078271-11-000036 — 2.02, 2.05, 9.01
- 2011-07-12 0001078271-11-000034 — 8.01
- 2011-07-01 0001078271-11-000032 — 5.02
- 2011-06-16 0001078271-11-000030 — 8.01
- 2011-05-06 0001078271-11-000027 — 8.01, 9.01
- 2011-05-04 0001078271-11-000025 — 8.01
- 2011-04-28 0001078271-11-000020 — 2.02, 9.01
- 2011-04-27 0001078271-11-000018 — 3.03, 5.02, 5.03, 9.01
- 2011-04-11 0001078271-11-000016 — 2.02
- 2011-03-31 0001078271-11-000014 — 5.02, 5.03
- 2011-03-15 0001193125-11-066049 — 5.02, 9.01
- 2011-03-01 0001193125-11-052048 — 5.02, 9.01
- 2011-02-10 0001078271-11-000012 — 7.01, 9.01
- 2011-01-31 0001078271-11-000005 — 2.02, 5.02, 5.03, 9.01
- 2010-12-23 0001193125-10-287613 — 8.01
- 2010-12-17 0001193125-10-283495 — 5.03, 5.07, 8.01, 9.01
- 2010-11-10 0001193125-10-255861 — 4.01, 9.01
- 2010-11-01 0001193125-10-242706 — 2.02, 9.01
- 2010-10-14 0001193125-10-229518 — 1.01, 9.01
- 2010-10-06 0001193125-10-224863 — 5.02, 8.01
- 2010-09-29 0001193125-10-219705 — 1.01, 8.01
- 2010-09-08 0001193125-10-206782 — 5.02, 8.01, 9.01
- 2010-08-25 0001193125-10-196951 — 8.01
- 2010-08-09 0001193125-10-182573 — 7.01, 8.01, 9.01
- 2010-08-03 0001193125-10-175255 — 5.02, 8.01, 9.01
- 2010-08-02 0001193125-10-173697 — 2.02, 8.01, 9.01
- 2010-07-30 0001193125-10-172214 — 5.02, 8.01, 9.01
- 2010-07-22 0001193125-10-163896 — 8.01, 9.01
- 2010-07-20 0001193125-10-161832 — 5.02
- 2010-07-12 0001193125-10-157291 — 2.02, 9.01
- 2010-07-01 0001193125-10-152746 — 3.03, 9.01
- 2010-05-10 0001193125-10-114669 — 5.02, 9.01
- 2010-04-26 0001193125-10-093310 — 2.02, 9.01
- 2010-03-19 0001193125-10-061679 — 5.02, 9.01
- 2010-02-16 0001193125-10-032335 — 5.02
- 2010-02-01 0001193125-10-018202 — 2.02, 9.01
- 2010-01-29 0001193125-10-017165 — 5.02
- 2010-01-11 0001193125-10-004099 — 8.01
- 2009-10-26 0001193125-09-213846 — 2.02, 9.01 — amendment of 0001193125-09-213780
- 2009-10-26 0001193125-09-213780 — 2.02, 9.01
- 2009-10-23 0001193125-09-212871 — 2.05, 5.02, 8.01, 9.01
- 2009-10-05 0001193125-09-203522 — 2.02, 9.01
- 2009-08-04 0001193125-09-163799 — 5.02, 9.01
- 2009-07-31 0001193125-09-160772 — 5.02, 9.01
- 2009-07-30 0001193125-09-159578 — 2.02, 9.01
- 2009-07-20 0001193125-09-151500 — 5.02, 9.01
- 2009-07-08 0001193125-09-145840 — 5.02, 9.01
- 2009-05-12 0001193125-09-108340 — 5.02, 9.01
- 2009-04-23 0001193125-09-085849 — 2.02, 9.01
- 2009-03-26 0001193125-09-064502 — 2.05
- 2009-01-28 0001193125-09-013182 — 2.02, 9.01
- 2008-11-06 0001193125-08-227572 — 2.02, 9.01
- 2008-11-03 0001193125-08-222501 — 5.02
- 2008-08-11 0001193125-08-173590 — 5.02
- 2008-08-11 0001193125-08-172587 — 8.01, 9.01
- 2008-08-06 0001193125-08-167934 — 2.02, 9.01
- 2008-08-04 0001193125-08-164673 — 5.02, 9.01
- 2008-05-21 0001193125-08-119640 — 7.01, 9.01
- 2008-04-29 0001193125-08-095270 — 2.02, 9.01
- 2008-03-05 0001193125-08-047893 — 8.01
- 2008-02-19 0001193125-08-033702 — 5.02
- 2008-02-05 0001193125-08-019969 — 5.02
- 2008-01-30 0001193125-08-015378 — 2.02, 9.01
- 2007-12-27 0001193125-07-272178 — 5.03, 9.01
- 2007-10-29 0001193125-07-228368 — 2.02, 9.01
- 2007-10-25 0001193125-07-225906 — 5.02, 9.01
- 2007-10-19 0001193125-07-221578 — 5.02
- 2007-09-26 0001193125-07-207348 — 8.01
- 2007-08-07 0001193125-07-172810 — 2.02, 9.01
- 2007-08-06 0001193125-07-172147 — 5.02, 9.01
- 2007-08-06 0001193125-07-172134 — 3.01
- 2007-07-09 0001193125-07-151467 — 3.01, 9.01
- 2007-06-28 0001193125-07-145519 — 2.02, 9.01
- 2007-06-27 0001193125-07-143262 — 2.05, 3.01, 5.02
- 2007-05-18 0001193125-07-118804 — 3.01, 9.01
- 2007-05-02 0001193125-07-099280 — 2.02, 9.01
- 2007-03-29 0001193125-07-068815 — 5.02, 9.01
- 2007-02-22 0001193125-07-037181 — 3.01, 9.01
- 2007-02-08 0001193125-07-024194 — 5.02
- 2007-01-30 0001193125-07-016428 — 2.02, 9.01
- 2007-01-11 0001193125-07-004825 — 4.02, 9.01
- 2006-11-21 0001193125-06-240068 — 5.02, 9.01
- 2006-11-16 0001193125-06-237262 — 3.01, 9.01
- 2006-11-01 0001193125-06-220707 — 2.02, 9.01
- 2006-10-31 0001193125-06-219237 — 1.01, 1.02, 5.02, 5.03, 8.01, 9.01
- 2006-09-28 0001193125-06-198185 — 3.01, 9.01
- 2006-09-15 0001193125-06-191640 — 7.01, 9.01
- 2006-09-05 0001193125-06-185202 — 5.02, 9.01
- 2006-08-08 0001193125-06-165953 — 1.01, 2.02, 5.02, 9.01
- 2006-07-18 0001193125-06-148526 — 1.01
- 2006-07-10 0001193125-06-143989 — 5.02, 9.01
- 2006-05-16 0001193125-06-113698 — 5.02, 9.01
- 2006-05-01 0001193125-06-094919 — 2.02, 9.01
- 2006-04-26 0001193125-06-089397 — 1.01, 9.01
- 2006-04-07 0001193125-06-075723 — 2.02, 9.01
- 2006-02-13 0001193125-06-029073 — 1.01
- 2006-01-31 0001193125-06-016143 — 1.01
- 2006-01-30 0001193125-06-015165 — 2.02, 9.01
- 2005-12-08 0001193125-05-239157 — 1.01, 1.02, 9.01
- 2005-11-01 0001193125-05-213101 — 2.02, 9.01
- 2005-09-29 0001193125-05-193991 — 1.01, 2.02, 9.01 — amendment of 0001193125-05-162807
- 2005-08-09 0001193125-05-162807 — 1.01, 2.02, 9.01
- 2005-07-14 0001193125-05-142162 — 8.01
- 2005-06-28 0001193125-05-133050 — 1.01, 9.01
- 2005-04-18 0001193125-05-077946 — 2.02, 7.01, 9.01
- 2005-04-14 0001193125-05-076665 — 2.02, 7.01, 9.01
- 2005-01-25 0001193125-05-011466 — 2.02, 9.01
- 2004-12-07 0001193125-04-208693 — 3.01
- 2004-10-26 0001193125-04-178370 — 2.02, 9.01
- 2004-10-04 0001193125-04-166289 — 5.02, 9.01
- 2004-07-28 0001193125-04-126135 — 12, 7
- 2004-05-12 0001193125-04-086287 — 12
- 2004-04-21 0001193125-04-066557 — 12, 7
- 2004-01-22 0001193125-04-007359 — 12, 7
- 2003-12-18 0001193125-03-096351 — 5, 7
- 2003-11-04 0001193125-03-072069 — 5, 7
- 2003-10-24 0001193125-03-066551 — 12, 7
- 2003-07-25 0001193125-03-024087 — 7, 9
- 2003-04-11 0001012870-03-001706 — 7, 9
- 2003-04-08 0001021408-03-005743 — 7, 9
- 2003-01-07 0001012870-03-000039 — 5, 7
- 2002-04-29 0001012870-02-002003 — 5, 7
- 2002-02-20 0001012870-02-000792 — 5, 7
- 2001-12-13 0001012870-01-503160 — 5, 7
- 2001-11-30 0001012870-01-503010 — 5, 7
- 2001-11-02 0001012870-01-502580 — 5
- 2001-10-23 0001021408-01-508589 — 5, 7
- 2001-06-07 0001021408-01-501772 — 5, 7 — amendment of 0001021408-01-500975
- 2001-05-15 0001021408-01-501104 — 5 — amendment of 0001021408-01-500975
- 2001-05-14 0001021408-01-500975 — 5, 7
- 2001-04-06 0001012870-01-500065 — 5, 7

## late-filing notifications on or before 2021-11-05

- 2008-05-12 0001193125-08-111540 — NT 10-Q, for the period ended 2008-03-30
- 2007-05-10 0001193125-07-110075 — NT 10-Q, for the period ended 2007-04-01
- 2007-02-09 0001193125-07-025490 — NT 10-Q, for the period ended 2006-12-31
- 2006-11-13 0001193125-06-232090 — NT 10-Q, for the period ended 2006-10-01
- 2006-09-15 0001193125-06-191838 — NT 10-K, for the period ended 2006-07-02

## item 2.02 — earnings release, exhibit 99.1

[0001564590-21-053306:8k_2_02:1]
EX-99.1
2
extr-ex991_6.htm
EX-99.1

[0001564590-21-053306:8k_2_02:2]
extr-ex991_6.htm

[0001564590-21-053306:8k_2_02:3]
Exhibit 99.1

[0001564590-21-053306:8k_2_02:4]
| For more information, contact: |  |  |  |  |  |  |
| Investor Relations |  |  |  | Media Contact |  |
| Stan Kovler |  |  |  | Amy Aylward |
| 919/595-4196 |  |  |  | 603/952-5138 |  |
| Investor_relations@extremenetworks.com |  |  |  | pr@extremenetworks.com |

[0001564590-21-053306:8k_2_02:5]
Extreme Networks Reports First Quarter Fiscal Year 2022 Financial Results

[0001564590-21-053306:8k_2_02:6]
Strong Bookings Drive Continued Double-Digit Year-Over-Year Revenue Growth and Record Quarterly Operating and Net Income

[0001564590-21-053306:8k_2_02:7]
Expects Double-Digit Growth Driven by Strength of Cloud Solutions

[0001564590-21-053306:8k_2_02:8]
Morrisville, NC, November 2, 2021 -- Extreme Networks, Inc. (“Extreme”) (Nasdaq: EXTR) today released financial results for its first fiscal quarter ended September 30, 2021.

[0001564590-21-053306:8k_2_02:9]
Fiscal First Quarter Results:

[0001564590-21-053306:8k_2_02:10]
|  | • | Revenue $267.7 million, up 14% year-over-year |

[0001564590-21-053306:8k_2_02:11]
|  | • | GAAP EPS $0.10, up from ($0.07) in Q1 last year |

[0001564590-21-053306:8k_2_02:12]
|  | • | Non-GAAP EPS $0.21, up from $0.09 in Q1 last year |

[0001564590-21-053306:8k_2_02:13]
|  | • | GAAP gross margin 58.1% compared to 57.3% in Q1 last year |

[0001564590-21-053306:8k_2_02:14]
|  | • | Non-GAAP gross margin 60.3% consistent with 60.3% in Q1 last year |

[0001564590-21-053306:8k_2_02:15]
|  | • | GAAP operating margin 6.9% compared to 0.0% in Q1 last year |

[0001564590-21-053306:8k_2_02:16]
|  | • | Non-GAAP operating margin 13.8% compared to 8.3% in Q1 last year |

[0001564590-21-053306:8k_2_02:17]
|  | • | Net cash provided by operating activities of $40.3 million |

[0001564590-21-053306:8k_2_02:18]
|  | • | Free Cash Flow of $36.8 million |

[0001564590-21-053306:8k_2_02:19]
“It was a very strong first quarter, characterized by unprecedented bookings. We strengthened our number two position in cloud networking, the fastest growing segment of the industry. Customer interest in our solutions resulted in a doubling of our backlog to over $200 million. We exceeded our quarterly revenue outlook despite significant supply chain challenges that our industry is facing,” stated Ed Meyercord, President and CEO of Extreme.

[0001564590-21-053306:8k_2_02:20]
“Our SaaS subscription bookings grew 71% during the quarter. This is a testament to the demand for our highly differentiated cloud-driven networking solutions. Our continued success is directly linked to delivering on our Infinite Enterprise vision to reduce the complexity of running increasingly distributed networks at scale. The recently acquired Ipanema business brings game-changing SD-WAN capabilities to our portfolio, and further expands on this vision while strengthening our competitive position,” concluded Meyercord.

[0001564590-21-053306:8k_2_02:21]
“Extreme enjoyed another quarter of strong financial performance. On a year-over-year basis, we achieved double-digit revenue growth for the third consecutive quarter, improved our non-GAAP

[0001564590-21-053306:8k_2_02:22]
operating margin by more than 5-percentage points to 13.8%, the highest level in the company’s history, and increased our free cash flow by 70%. In Q2, we expect expedite fees and freight costs to peak, partially offset by the benefits of our recent list price increases. We plan to manage through the current environment and start reducing our backlog – currently at historical levels – in the second half of fiscal year 2022. We are confident we can deliver double-digit organic revenue growth in FY22, above our previous guidance of 5% to 9%, with 10 to 15% non-GAAP operating margins,” concluded Remi Thomas, Chief Financial Officer.

[0001564590-21-053306:8k_2_02:23]
Recent Key Highlights:

[0001564590-21-053306:8k_2_02:24]
|  | • | Extreme was recently recognized with several awards for innovation, including: |

[0001564590-21-053306:8k_2_02:25]
|  | • | Wi-Fi Forward’s Wi-Fi at Work Award, which recognized Extreme’s support of Novant Health’s COVID-19 vaccination clinic; |

[0001564590-21-053306:8k_2_02:26]
|  | • | Network Computing’s Product of the Year award for ExtremeCloud IQ; and, |

[0001564590-21-053306:8k_2_02:27]
|  | • | Inc.’s 2021 Best-Led Companies, which recognizes middle market companies that have a successful track record with leadership teams that spur solid performance, create value, penetrate markets, engage with customers, and more. |

[0001564590-21-053306:8k_2_02:28]
|  | • | Extreme officially extended its partnership with the National Football League (NFL) and will remain the Official Wi-Fi Network Solutions Provider and Official Wi-Fi Analytics Provider of the NFL through 2024. Extreme is rolling out next-generation analytics capabilities to the NFL this season, providing IT teams with richer data sets and insights around app performance and usage, dwell time, and location-based services. |

[0001564590-21-053306:8k_2_02:29]
|  | • | Extreme successfully implemented support of Wireless Broadband Alliance (WBA) OpenRoaming at the Polytechnic Institute of Viseu (IPV) in Portugal, the first installation of its kind in the country. OpenRoaming enables students, teachers, and other users on IPV's campus to connect to a high-speed, secure, carrier-grade Wi-Fi 6 network wherever they are, indoors and outdoors, without experiencing disruption to their wireless network connection. |

[0001564590-21-053306:8k_2_02:30]
|  | • | Extreme continues to be a top choice for local governments including: |

[0001564590-21-053306:8k_2_02:31]
|  | • | The City of Zoetermeer in the Netherlands, which selected Extreme to deliver a full network refresh for its town hall and eight public buildings. The deployment includes the ExtremeCloud IQ platform and automated campus fabric solutions, which provides city IT staff with full visibility and control of network and device activity. |

[0001564590-21-053306:8k_2_02:32]
|  | • | The City of Mönchengladbach in Germany deployed Extreme solutions to standardize its education network infrastructure across the 86 schools within its borders. The city rolled out Extreme switches, Wi-Fi 6 access points and ExtremeCloud IQ. By standardizing on Extreme, schools across the city will connect to a secure network, that IT teams can centrally manage through the cloud. |

[0001564590-21-053306:8k_2_02:33]
|  | • | The historic Olympiastadion Berlin in Germany selected Extreme as its official Wi-Fi solutions provider. The project was the first and largest public Wi-Fi 6 deployment in a European stadium |

[0001564590-21-053306:8k_2_02:34]
|  |  | and will enable the venue to meet the most demanding connectivity requirements of spectators, staff, and media attending football tournaments, concerts, and international sporting events. |

[0001564590-21-053306:8k_2_02:35]
|  | • | Novant Health and the University of Massachusetts Chan Medical School both selected Extreme to deploy an enterprise-grade Wi-Fi 6E solution, leveraging the Extreme AP4000 universal wireless platform. As a result, Novant Health can deliver high-speed Wi-Fi throughout its facilities and enable secure, dedicated connectivity for mission-critical healthcare applications and medical devices. UMass Chan Medical School will tap into the 6 GHz band to better support its dense population of personal, academic, and medical research devices. Combined with the ExtremeCloud IQ platform, the new network will be simple to manage and give students and staff access to the fastest Wi-Fi speeds available. |

[0001564590-21-053306:8k_2_02:36]
Fiscal Q1 2022 Financial Metrics:

[0001564590-21-053306:8k_2_02:37]
(in millions, except percentages and per share information)

[0001564590-21-053306:8k_2_02:38]
|  |  | GAAP Results |  |
|  |  | Three Months Ended |  |
|  |  | September 30, 2021 |  |  | September 30, 2020 |  |  | Change |  |
| Product |  | $ | 185.2 |  |  | $ | 161.4 |  |  | $ | 23.8 |  |  |  | 15 | % |
| Service and subscription |  |  | 82.5 |  |  |  | 74.4 |  |  |  | 8.1 |  |  |  | 11 | % |
| Total net revenue |  | $ | 267.7 |  |  | $ | 235.8 |  |  | $ | 31.9 |  |  |  | 14 | % |
| Gross margin |  |  | 58.1 | % |  |  | 57.3 | % |  | 80 bps |  |  | - |  |
| Operating margin |  |  | 6.9 | % |  |  | (0.0 | )% |  | 689 bps |  |  | - |  |
| Net income (loss) |  | $ | 12.7 |  |  | $ | (8.8 | ) |  | $ | 21.5 |  |  |  | 244 | % |
| Net income (loss) per diluted share |  | $ | 0.10 |  |  | $ | (0.07 | ) |  | $ | 0.17 |  |  |  | 243 | % |

[0001564590-21-053306:8k_2_02:39]
|  |  | Non-GAAP Results |  |
|  |  | Three Months Ended |  |
|  |  | September 30, 2021 |  |  | September 30, 2020 |  |  | Change |  |
| Product |  | $ | 185.2 |  |  | $ | 161.4 |  |  | $ | 23.8 |  |  |  | 15 | % |
| Service and subscription |  |  | 82.5 |  |  |  | 74.4 |  |  |  | 8.1 |  |  |  | 11 | % |
| Total net revenue |  | $ | 267.7 |  |  | $ | 235.8 |  |  | $ | 31.9 |  |  |  | 14 | % |
| Gross margin |  |  | 60.3 | % |  |  | 60.3 | % |  | 0 bps |  |  | - |  |
| Operating margin |  |  | 13.8 | % |  |  | 8.3 | % |  | 550 bps |  |  | - |  |
| Net income |  | $ | 28.0 |  |  | $ | 11.0 |  |  | $ | 17.0 |  |  |  | 155 | % |
| Net income per diluted share |  | $ | 0.21 |  |  | $ | 0.09 |  |  | $ | 0.12 |  |  |  | 133 | % |

[0001564590-21-053306:8k_2_02:40]
|  | • | Q1 ending cash balance was $191.3 million, a decrease of $55.5 million from the end of Q4. This was primarily driven by the acquisition of Ipanema, along with the cash usage of $22.7 million for financing activities and $3.4 million for capital expenditure, partially offset by operating cash flow generation of $40.3 million. |

[0001564590-21-053306:8k_2_02:41]
|  | • | Q1 accounts receivable balance was $129.6 million, a decrease of $26.9 million from the end of Q4 and an increase of $6.0 million from Q1 last year. Days sales outstanding was 45 days, a decrease of 6 days from Q4 and a decrease of 3 days from Q1 last year. |

[0001564590-21-053306:8k_2_02:42]
|  | • | Q1 ending inventory was $32.4 million, a decrease of $0.5 million from Q4 and a decrease of $23.4 million from Q1 last year. The year-over-year and quarter-over-quarter decreases in inventory largely reflect improved demand planning, SKU rationalization and higher inventory turnover. In addition, supply constraints in the recent quarters have contributed to the reduction in inventory. |

[0001564590-21-053306:8k_2_02:43]
|  | • | Q1 ending gross debt* was $330.0 million, a decrease of $16.8 million from the prior quarter. The $66.0 million decrease from Q1 last year resulted primarily from principal payments and payments on our revolver loan. Q1 ending net debt* was $138.7 million, increased by $38.8 million from $99.9 million in Q4. |

[0001564590-21-053306:8k_2_02:44]
Extreme uses the non-GAAP free cash flow metric as a measure of operating performance. Free cash flow represents GAAP net cash provided by operating activities, less purchases of property, plant and equipment.  Extreme considers free cash flow to be useful information for management and investors regarding the amount of cash generated by the business after the purchases of property, plant and equipment, which can then be used to, among other things, invest in Extreme’s business, make strategic acquisitions, and strengthen the balance sheet. A limitation of the utility of this non-GAAP free cash flow metric as a measure of financial performance is that it does not represent the total increase or decrease in the Company's cash balance for the period. The following table shows non-GAAP free cash flow calculation (in thousands):

[0001564590-21-053306:8k_2_02:45]
| Free Cash Flow | Three Months Ended |  |  |
|  | September 30, 2021 |  |  | September 30, 2020 |  |  |
| Cash flow provided by operations | $ | 40,254 |  |  | $ | 24,745 |  |  |
| Less: Property and equipment capital expenditures |  | (3,410 | ) |  |  | (3,023 | ) |  |
| Total free cash flow | $ | 36,844 |  |  | $ | 21,722 |  |  |

[0001564590-21-053306:8k_2_02:46]
*Gross debt is defined as long-term and current portion of long-term debt as shown on the balance sheet plus unamortized debt issuance costs, if any. Net debt is defined as gross debt minus cash, as shown in the table below (in millions):

[0001564590-21-053306:8k_2_02:47]
| Gross debt |  |  | Cash |  |  | Net debt |  |
| $ | 330.0 |  |  | $ | 191.3 |  |  | $ | 138.7 |  |

[0001564590-21-053306:8k_2_02:48]
Business Outlook:

[0001564590-21-053306:8k_2_02:49]
For its second quarter of fiscal 2022, ending December 31, 2021, the Company is targeting:

[0001564590-21-053306:8k_2_02:50]
| (in millions, except percentages and per share information) | Low-End |  |  | High-End |  |
| FQ2'22 Guidance – GAAP |  |  |  |  |  |  |  |
| Total net revenue | $ | 265.0 |  |  | $ | 280.0 |  |
| Gross margin |  | 55.4 | % |  |  | 57.5 | % |
| Operating expenses | $ | 140.7 |  |  | $ | 143.0 |  |
| Operating margin |  | 2.3 | % |  |  | 6.4 | % |
| Net income | $ | 0.00 |  |  | $ | 11.9 |  |
| Net income per diluted share | $ | 0.00 |  |  | $ | 0.09 |  |
| Shares outstanding used in calculating GAAP EPS |  | 135.0 |  |  |  | 135.0 |  |
| FQ2’22 Guidance – Non - GAAP |  |  |  |  |  |  |  |
| Total net revenue | $ | 265.0 |  |  | $ | 280.0 |  |
| Gross margin |  | 57.0 | % |  |  | 59.0 | % |
| Operating expenses | $ | 125.8 |  |  | $ | 127.4 |  |
| Operating margin |  | 9.5 | % |  |  | 13.5 | % |
| Net income | $ | 18.4 |  |  | $ | 28.9 |  |
| Net income per diluted share | $ | 0.14 |  |  | $ | 0.21 |  |
| Shares outstanding used in calculating non-GAAP EPS |  | 135.0 |  |  |  | 135.0 |  |

[0001564590-21-053306:8k_2_02:51]
The following table shows the GAAP to non-GAAP reconciliation for Q2 FY’22 guidance:

[0001564590-21-053306:8k_2_02:52]
|  | Gross Margin Rate |  |  | Operating Margin Rate |  |  | Earnings per Share |  |
| GAAP | 55.4% - 57.5% |  |  | 2.3% - 6.4% |  |  | $0.00 - $0.09 |  |
| Estimated adjustments for: |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of product intangibles | 1.0% |  |  | 1.0% |  |  |  | 0.02 |  |
| Share-based compensation | 0.3% |  |  | 4.1% |  |  |  | 0.08 |  |
| Restructuring | - |  |  | 0.1% |  |  |  | 0.00 |  |
| Acquisition and integration costs | - |  |  | 1.4% |  |  |  | 0.03 |  |
| Amortization of non-product intangibles | 0.3% |  |  | 0.6% |  |  |  | 0.01 |  |
| Tax effect of non-GAAP adjustments | - |  |  | - |  |  | (0.00) - (0.02) |  |
| Non-GAAP | 57.0% - 59.0% |  |  | 9.5% - 13.5% |  |  | $0.14 - $0.21 |  |

[0001564590-21-053306:8k_2_02:53]
The total of percentage rate changes may not equal the total change in all cases due to rounding.

[0001564590-21-053306:8k_2_02:54]
Conference Call:

[0001564590-21-053306:8k_2_02:55]
Extreme will host a conference call at 8:00 a.m. Eastern (5:00 a.m. Pacific) today to review the first fiscal quarter results as well as the business outlook for the second quarter ending December 31, 2021, including significant factors and assumptions underlying the targets noted above. The conference call will be available to the public through a live audio web broadcast via the internet at http://investor.extremenetworks.com and a replay of the call will be available on the website for at least 7 days following the call. The conference call may also be heard by dialing 1 (877) 303-9826 or international 1 (224) 357-2194 with Conference ID # 2766837. Supplemental financial information to be

[0001564590-21-053306:8k_2_02:56]
discussed during the conference call will be posted in the Investor Relations section of the Company's website www.extremenetworks.com including the non-GAAP reconciliation attached to this press release. The encore recording can be accessed by dialing 1 (855) 859-2056 or international 1 (404) 537-3406. Conference ID # 2766837. The encore recording will be available for at least 7 days following the call.

[0001564590-21-053306:8k_2_02:57]
About Extreme:

[0001564590-21-053306:8k_2_02:58]
Extreme Networks, Inc. (EXTR) creates effortless networking experiences that enable all of us to advance. We push the boundaries of technology leveraging the powers of machine learning, artificial intelligence, analytics, and automation. Over 50,000 customers globally trust our end-to-end, cloud-driven networking solutions and rely on our top-rated services and support to accelerate their digital transformation efforts and deliver progress like never before. For more information, visit Extreme's website or follow us on Twitter, LinkedIn, and Facebook.

[0001564590-21-053306:8k_2_02:59]
Extreme Networks, ExtremeCloud, and the Extreme Networks logo, are trademarks of Extreme Networks, Inc. or its subsidiaries in the United States and/or other countries. Other trademarks shown herein are the property of their respective owners.

[0001564590-21-053306:8k_2_02:60]
Non-GAAP Financial Measures:

[0001564590-21-053306:8k_2_02:61]
Extreme provides all financial information required in accordance with U.S. generally accepted accounting principles (“GAAP”). The Company is providing with this press release non-GAAP gross margin, non-GAAP operating expenses, non-GAAP operating margin, non-GAAP operating income, non-GAAP net income, non-GAAP net income per diluted share, and non-GAAP free cash flow. In preparing non-GAAP information, the Company has excluded, where applicable, the impact of share-based compensation, acquisition and integration costs, amortization of intangibles, and restructuring charges.  The Company believes that excluding these items provides both management and investors with additional insight into its current operations, the trends affecting the Company, the Company's marketplace performance, and the Company's ability to generate cash from operations. Please note the Company's non-GAAP measures may be different than those used by other companies. The additional non-GAAP financial information the Company presents should be considered in conjunction with, and not as a substitute for, the Company's GAAP financial information.

[0001564590-21-053306:8k_2_02:62]
The Company has provided a non-GAAP reconciliation of the results for the periods presented in this release, which are adjusted to exclude certain items as indicated.  These measures should only be used to evaluate the Company's results of operations in conjunction with the corresponding GAAP measures for comparable financial information and understanding of the Company's ongoing performance as a business. Extreme uses both GAAP and non-GAAP measures to evaluate and manage its operations.

[0001564590-21-053306:8k_2_02:63]
Forward-Looking Statements:

[0001564590-21-053306:8k_2_02:64]
expenses; the possibility that the company might experience delays in the development or introduction of new technology and products; customer response to the company’s new technology and products; risks related to pending or future litigation; risks related to the supply chain for the company’s products; macroeconomic and political and geopolitical factors; a dependency on third parties for certain components and for the manufacturing of the company’s products; and the impacts of COVID-19, and any worsening of the global business and economic environment as a result, on the company’s business.

[0001564590-21-053306:8k_2_02:65]
More information about potential factors that could affect the Company's business and financial results are described in “Management's Discussion and Analysis of Financial Condition and Results of Operations” and “Risk Factors” included in the Company’s Annual Report on Form 10-K for the year ended June 30, 2021 and other documents of the Company on file with the Securities and Exchange Commission (available at www.sec.gov).  As a result of these risks and others, actual results could vary significantly from those anticipated in this press release, and the company’s financial condition and results of operations could be materially adversely affected. Except as required under the U.S. federal securities laws and the rules and regulations of the U.S. Securities and Exchange Commission, Extreme disclaims any obligation to update any forward-looking statements after the date of this release, whether as a result of new information, future events, developments, changes in assumptions or otherwise.

[0001564590-21-053306:8k_2_02:66]
###

[0001564590-21-053306:8k_2_02:67]
EXTREME NETWORKS, INC.

[0001564590-21-053306:8k_2_02:68]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0001564590-21-053306:8k_2_02:69]
(In thousands, except per share amounts)

[0001564590-21-053306:8k_2_02:70]
(Unaudited)

[0001564590-21-053306:8k_2_02:71]
|  |  | September 30, 2021 |  |  | June 30, 2021 |  |
| ASSETS |  |  |  |  |  |  |  |  |
| Current assets: |  |  |  |  |  |  |  |  |
| Cash |  | $ | 191,349 |  |  | $ | 246,894 |  |
| Accounts receivable, net |  |  | 129,611 |  |  |  | 156,476 |  |
| Inventories |  |  | 32,439 |  |  |  | 32,885 |  |
| Prepaid expenses and other current assets |  |  | 70,772 |  |  |  | 51,340 |  |
| Total current assets |  |  | 424,171 |  |  |  | 487,595 |  |
| Property and equipment, net |  |  | 52,878 |  |  |  | 55,004 |  |
| Operating lease right-of-use assets, net |  |  | 33,820 |  |  |  | 36,927 |  |
| Intangible assets, net |  |  | 45,898 |  |  |  | 36,038 |  |
| Goodwill |  |  | 387,808 |  |  |  | 331,159 |  |
| Other assets |  |  | 64,229 |  |  |  | 63,370 |  |
| Total assets |  | $ | 1,008,804 |  |  | $ | 1,010,093 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |  |  |  |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |  |  |  |
| Current portion of long-term debt, net of unamortized debt issuance costs of $2,356 and $2,404, respectively |  | $ | 26,144 |  |  | $ | 23,721 |  |
| Accounts payable |  |  | 63,394 |  |  |  | 60,142 |  |
| Accrued compensation and benefits |  |  | 52,098 |  |  |  | 71,610 |  |
| Accrued warranty |  |  | 10,780 |  |  |  | 11,623 |  |
| Current portion, operating lease liabilities |  |  | 18,453 |  |  |  | 18,743 |  |
| Current portion, deferred revenue |  |  | 216,807 |  |  |  | 212,412 |  |
| Other accrued liabilities |  |  | 67,384 |  |  |  | 57,449 |  |
| Total current liabilities |  |  | 455,060 |  |  |  | 455,700 |  |
| Deferred revenue, less current portion |  |  | 139,216 |  |  |  | 133,172 |  |
| Long-term debt, less current portion, net of unamortized debt issuance costs of $4,121 and $4,760, respectively |  |  | 297,379 |  |  |  | 315,865 |  |
| Operating lease liabilities, less current portion |  |  | 28,744 |  |  |  | 32,515 |  |
| Deferred income taxes |  |  | 3,986 |  |  |  | 3,828 |  |
| Other long-term liabilities |  |  | 12,094 |  |  |  | 14,545 |  |
| Commitments and contingencies |  |  |  |  |  |  |  |  |
| Stockholders’ equity: |  |  |  |  |  |  |  |  |
| Convertible preferred stock, $0.001 par value, issuable in series, 2,000 shares authorized; none issued |  |  | — |  |  |  | — |  |
| Common stock, $0.001 par value, 750,000 shares authorized; 136,351 and 133,279 shares issued, respectively; 129,754 and 126,682 shares outstanding, respectively |  |  | 136 |  |  |  | 133 |  |
| Additional paid-in-capital |  |  | 1,084,671 |  |  |  | 1,078,602 |  |
| Accumulated other comprehensive loss |  |  | (3,722 | ) |  |  | (2,811 | ) |
| Accumulated deficit |  |  | (965,647 | ) |  |  | (978,343 | ) |
| Treasury stock at cost, 6,597 shares |  |  | (43,113 | ) |  |  | (43,113 | ) |
| Total stockholders’ equity |  |  | 72,325 |  |  |  | 54,468 |  |
| Total liabilities and stockholders’ equity |  | $ | 1,008,804 |  |  | $ | 1,010,093 |  |

[0001564590-21-053306:8k_2_02:72]
EXTREME NETWORKS, INC.

[0001564590-21-053306:8k_2_02:73]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS

[0001564590-21-053306:8k_2_02:74]
(In thousands, except per share amounts)

[0001564590-21-053306:8k_2_02:75]
(Unaudited)

[0001564590-21-053306:8k_2_02:76]
|  |  | Three Months Ended |  |
|  |  | September 30, 2021 |  |  | September 30, 2020 |  |
| Net revenues: |  |  |  |  |  |  |  |  |
| Product |  | $ | 185,161 |  |  | $ | 161,396 |  |
| Service and subscription |  |  | 82,523 |  |  |  | 74,406 |  |
| Total net revenues |  |  | 267,684 |  |  |  | 235,802 |  |
| Cost of revenues: |  |  |  |  |  |  |  |  |
| Product |  |  | 80,944 |  |  |  | 73,395 |  |
| Service and subscription |  |  | 31,137 |  |  |  | 27,389 |  |
| Total cost of revenues |  |  | 112,081 |  |  |  | 100,784 |  |
| Gross profit: |  |  |  |  |  |  |  |  |
| Product |  |  | 104,217 |  |  |  | 88,001 |  |
| Service and subscription |  |  | 51,386 |  |  |  | 47,017 |  |
| Total gross profit |  |  | 155,603 |  |  |  | 135,018 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |
| Research and development |  |  | 47,766 |  |  |  | 49,524 |  |
| Sales and marketing |  |  | 69,527 |  |  |  | 64,325 |  |
| General and administrative |  |  | 17,003 |  |  |  | 16,461 |  |
| Acquisition and integration costs |  |  | 1,510 |  |  |  | 1,975 |  |
| Restructuring and related charges |  |  | 279 |  |  |  | 1,001 |  |
| Amortization of intangibles |  |  | 1,154 |  |  |  | 1,792 |  |
| Total operating expenses |  |  | 137,239 |  |  |  | 135,078 |  |
| Operating income (loss) |  |  | 18,364 |  |  |  | (60 | ) |
| Interest income |  |  | 110 |  |  |  | 118 |  |
| Interest expense |  |  | (3,880 | ) |  |  | (6,663 | ) |
| Other income (expense), net |  |  | 171 |  |  |  | (887 | ) |
| Income (loss) before income taxes |  |  | 14,765 |  |  |  | (7,492 | ) |
| Provision for income taxes |  |  | 2,069 |  |  |  | 1,320 |  |
| Net income (loss) |  | $ | 12,696 |  |  | $ | (8,812 | ) |
| Basic and diluted income (loss) per share: |  |  |  |  |  |  |  |  |
| Net income (loss) per share - basic |  | $ | 0.10 |  |  | $ | (0.07 | ) |
| Net income (loss) per share - diluted |  | $ | 0.10 |  |  | $ | (0.07 | ) |
| Shares used in per share calculation - basic |  |  | 128,324 |  |  |  | 121,705 |  |
| Shares used in per share calculation - diluted |  |  | 133,225 |  |  |  | 121,705 |  |

[0001564590-21-053306:8k_2_02:77]
EXTREME NETWORKS, INC.

[0001564590-21-053306:8k_2_02:78]
CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS

[0001564590-21-053306:8k_2_02:79]
(In thousands)

[0001564590-21-053306:8k_2_02:80]
(Unaudited)

[0001564590-21-053306:8k_2_02:81]
|  |  | Three Months Ended |  |
|  |  | September 30, 2021 |  |  | September 30, 2020 |  |
| Cash flows from operating activities: |  |  |  |  |  |  |  |  |
| Net Income (loss) |  | $ | 12,696 |  |  | $ | (8,812 | ) |
| Adjustments to reconcile net income (loss) to net cash provided by operating activities: |  |  |  |  |  |  |  |  |
| Depreciation |  |  | 5,155 |  |  |  | 6,727 |  |
| Amortization of intangible assets |  |  | 6,440 |  |  |  | 8,491 |  |
| Reduction in carrying amount of right-of-use asset |  |  | 3,902 |  |  |  | 4,038 |  |
| Provision for doubtful accounts |  |  | 26 |  |  |  | — |  |
| Share-based compensation |  |  | 10,444 |  |  |  | 8,302 |  |
| Deferred income taxes |  |  | 682 |  |  |  | 312 |  |
| Non-cash interest expense |  |  | 1,314 |  |  |  | 1,103 |  |
| Other |  |  | (176 | ) |  |  | 1,380 |  |
| Changes in operating assets and liabilities, net of acquisition: |  |  |  |  |  |  |  |  |
| Accounts receivable |  |  | 28,281 |  |  |  | (910 | ) |
| Inventories |  |  | 604 |  |  |  | 6,628 |  |
| Prepaid expenses and other assets |  |  | (18,640 | ) |  |  | (1,521 | ) |
| Accounts payable |  |  | 2,577 |  |  |  | 10,628 |  |
| Accrued compensation and benefits |  |  | (22,540 | ) |  |  | (5,482 | ) |
| Operating lease liabilities |  |  | (4,839 | ) |  |  | (4,812 | ) |
| Deferred revenue |  |  | 7,680 |  |  |  | 6,607 |  |
| Other current and long-term liabilities |  |  | 6,648 |  |  |  | (7,934 | ) |
| Net cash provided by operating activities |  |  | 40,254 |  |  |  | 24,745 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |
| Capital expenditures |  |  | (3,410 | ) |  |  | (3,023 | ) |
| Business acquisition, net of cash acquired |  |  | (69,517 | ) |  |  | — |  |
| Net cash used in investing activities |  |  | (72,927 | ) |  |  | (3,023 | ) |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |
| Payments on debt obligations |  |  | (16,750 | ) |  |  | (24,750 | ) |
| Payments for tax withholdings, net of proceeds from issuance of common stock |  |  | (4,372 | ) |  |  | 3,581 |  |
| Payment of contingent consideration obligations |  |  | (559 | ) |  |  | (603 | ) |
| Deferred payments on an acquisition |  |  | (1,000 | ) |  |  | (1,000 | ) |
| Net cash used in financing activities |  |  | (22,681 | ) |  |  | (22,772 | ) |
| Foreign currency effect on cash |  |  | (191 | ) |  |  | 294 |  |
| Net decrease in cash |  |  | (55,545 | ) |  |  | (756 | ) |
| Cash at beginning of period |  |  | 246,894 |  |  |  | 193,872 |  |
| Cash at end of period |  | $ | 191,349 |  |  | $ | 193,116 |  |

[0001564590-21-053306:8k_2_02:82]
Extreme Networks, Inc.

[0001564590-21-053306:8k_2_02:83]
Non-GAAP Measures of Financial Performance

[0001564590-21-053306:8k_2_02:84]
To supplement the Company's consolidated financial statements presented in accordance with U.S. generally accepted accounting principles, (“GAAP”), Extreme uses non-GAAP measures of certain components of financial performance.  These non-GAAP measures include non-GAAP gross margin, non-GAAP operating expenses, non-GAAP operating margin, non-GAAP operating income, non-GAAP net income, non-GAAP net income per diluted share and non-GAAP free cash flow.

[0001564590-21-053306:8k_2_02:85]
Reconciliation to the nearest GAAP measure of all historical non-GAAP measures included in this press release can be found in the tables included with this press release.

[0001564590-21-053306:8k_2_02:86]
Non-GAAP measures presented in this press release are not in accordance with or alternative measures prepared in accordance with GAAP and may be different from non-GAAP measures used by other companies.  In addition, these non-GAAP measures are not based on any comprehensive set of accounting rules or principles.  Non-GAAP measures have limitations in that they do not reflect all of the amounts associated with Extreme’s results of operations as determined in accordance with GAAP.  These non-GAAP measures should only be used to evaluate Extreme’s results of operations in conjunction with the corresponding GAAP measures.

[0001564590-21-053306:8k_2_02:87]
Extreme believes these non-GAAP measures when shown in conjunction with the corresponding GAAP measures enhance investors' and management's overall understanding of the Company's current financial performance and the Company's prospects for the future, including cash flows available to pursue opportunities to enhance stockholder value.  In addition, because Extreme has historically reported certain non-GAAP results to investors, the Company believes the inclusion of non-GAAP measures provides consistency in the Company's financial reporting.

[0001564590-21-053306:8k_2_02:88]
For its internal planning process, and as discussed further below, Extreme's management uses financial statements that do not include share-based compensation expense, acquisition and integration costs, amortization of intangibles, restructuring charges, and the tax effect of non-GAAP adjustments.  Extreme’s management also uses non-GAAP measures, in addition to the corresponding GAAP measures, in reviewing the Company's financial results.

[0001564590-21-053306:8k_2_02:89]
As described above, Extreme excludes the following items from one or more of its non-GAAP measures when applicable.

[0001564590-21-053306:8k_2_02:90]
Share-based compensation. Consists of associated expenses for stock options, restricted stock awards and the Company’s Employee Stock Purchase Plan.  Extreme excludes share-based compensation expenses from its non-GAAP measures primarily because they are non-cash expenses that the Company does not believe are reflective of ongoing cash requirement related to its operating results. Extreme expects to incur share-based compensation expenses in future periods.

[0001564590-21-053306:8k_2_02:91]
Acquisition and integration costs. Acquisition and integration costs consist of specified compensation charges, software charges, legal and professional fees related to the acquisition of Aerohive and Ipanema.  Extreme excludes these expenses since they result from an event that is outside the ordinary course of continuing operations.

[0001564590-21-053306:8k_2_02:92]
Amortization of intangibles. Amortization of intangibles includes the monthly amortization expense of intangible assets such as developed technology, customer relationships, trademarks and order backlog.  The amortization of the developed technology and order backlog are recorded in cost of goods sold, while the amortization for the other intangibles are recorded in operating expenses.  Extreme excludes these expenses since they result from an intangible asset and for which the period expense does not impact the operations of the business and are non-cash in nature.

[0001564590-21-053306:8k_2_02:93]
Restructuring charges. Restructuring charges primarily consist of severance costs for employees which have no benefit to continuing operations and impairment of right-of-use assets, long-lived assets and other charges related to excess facilities. Extreme excludes restructuring expenses since they result from events that occur outside of the ordinary course of continuing operations.

[0001564590-21-053306:8k_2_02:94]
Tax effect of non-GAAP adjustments. We calculate our non-GAAP provision for income taxes in accordance with the SEC guidance on non-GAAP Financial Measures Compliance and Disclosure Interpretation.  We have assumed our U.S. federal and state net operating losses would have been fully consumed by the historical non-GAAP financial adjustments, eliminating the need for a full valuation allowance against our U.S. deferred tax assets which, consequently, enables our use of research and development tax credits.  The non-GAAP tax provision consists of current and deferred income tax expense commensurate with the non-GAAP measure of profitability using our blended U.S. statutory tax rate of 24.2%.

[0001564590-21-053306:8k_2_02:95]
Non-GAAP provision for income taxes may be higher or lower depending on the level and jurisdictional mix of pre-tax income and available U.S. research and development tax credits.  As of June 30, 2021, we had U.S. federal net operating loss carryforwards of $242 million, state net operating loss carryforwards of $156 million and Irish net operating losses of $17 million.  These amounts will be reflected in our requisite tax filings for each jurisdiction for the tax year ended June 30, 2021. We do not expect to pay substantial taxes on a GAAP basis in the U.S. for the foreseeable future due to our net operating loss carryforward balances.  Over the near term, most of our cash taxes will continue to be mainly driven by the tax expense of our foreign subsidiaries which amounts have not historically been significant, with the exception of the Company’s Irish operating company which has fully utilized available net operating loss carryforwards during fiscal 2021.  We also believe our long-term effective GAAP tax rate will be lower than the U.S. statutory rate based upon our established tax structure.

[0001564590-21-053306:8k_2_02:96]
EXTREME NETWORKS, INC.

[0001564590-21-053306:8k_2_02:97]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS

[0001564590-21-053306:8k_2_02:98]
GAAP TO NON-GAAP RECONCILIATION

[0001564590-21-053306:8k_2_02:99]
(In thousands, except percentages and per share amounts)

[0001564590-21-053306:8k_2_02:100]
(Unaudited)

[0001564590-21-053306:8k_2_02:101]
| Revenues | Three Months Ended |  |  |
|  | September 30, 2021 |  |  | September 30, 2020 |  |  |
| Revenues - GAAP | $ | 267,684 |  |  | $ | 235,802 |  |  |

[0001564590-21-053306:8k_2_02:102]
| Non-GAAP Gross Margin | Three Months Ended |  |  |
|  | September 30, 2021 |  |  | September 30, 2020 |  |  |
| Gross profit - GAAP | $ | 155,603 |  |  | $ | 135,018 |  |  |
| Gross margin - GAAP percentage |  | 58.1 | % |  |  | 57.3 | % |  |
| Adjustments: |  |  |  |  |  |  |  |  |
| Share-based compensation expense |  | 672 |  |  |  | 630 |  |  |
| Acquisition and integration costs |  | — |  |  |  | 10 |  |  |
| Amortization of intangibles |  | 5,269 |  |  |  | 6,633 |  |  |
| Total adjustments to GAAP gross profit | $ | 5,941 |  |  | $ | 7,273 |  |  |
| Gross profit - non-GAAP | $ | 161,544 |  |  | $ | 142,291 |  |  |
| Gross margin - non-GAAP percentage |  | 60.3 | % |  |  | 60.3 | % |  |

[0001564590-21-053306:8k_2_02:103]
| Non-GAAP Operating Income (Loss) | Three Months Ended |  |  |
|  | September 30, 2021 |  |  | September 30, 2020 |  |  |
| GAAP operating income (loss) | $ | 18,364 |  |  | $ | (60 | ) |  |
| GAAP operating income (loss) percentage |  | 6.9 | % |  |  | (0.0 | )% |  |
| Adjustments: |  |  |  |  |  |  |  |  |
| Share-based compensation expense, cost of revenues |  | 672 |  |  |  | 630 |  |  |
| Share-based compensation expense, R&D |  | 2,458 |  |  |  | 2,272 |  |  |
| Share-based compensation expense, S&M |  | 3,575 |  |  |  | 2,647 |  |  |
| Share-based compensation expense, G&A |  | 3,739 |  |  |  | 2,753 |  |  |
| Acquisition and integration costs |  | 1,510 |  |  |  | 1,985 |  |  |
| Restructuring charges, net of reversals |  | 279 |  |  |  | 1,001 |  |  |
| Amortization of intangibles |  | 6,423 |  |  |  | 8,425 |  |  |
| Total adjustments to GAAP operating income (loss) | $ | 18,656 |  |  | $ | 19,713 |  |  |
| Non-GAAP operating income | $ | 37,020 |  |  | $ | 19,653 |  |  |
| Non-GAAP operating income percentage |  | 13.8 | % |  |  | 8.3 | % |  |

[0001564590-21-053306:8k_2_02:104]
| Non-GAAP net income | Three Months Ended |  |  |
|  | September 30, 2021 |  |  | September 30, 2020 |  |  |
| GAAP net income (loss) | $ | 12,696 |  |  | $ | (8,812 | ) |  |
| Adjustments: |  |  |  |  |  |  |  |  |
| Share-based compensation expense |  | 10,444 |  |  |  | 8,302 |  |  |
| Acquisition and integration costs |  | 1,510 |  |  |  | 1,985 |  |  |
| Restructuring charge, net of reversal |  | 279 |  |  |  | 1,001 |  |  |
| Amortization of intangibles |  | 6,423 |  |  |  | 8,425 |  |  |
| Tax effect of non-GAAP adjustments |  | (3,400 | ) |  |  | 58 |  |  |
| Total adjustments to GAAP net income (loss) | $ | 15,256 |  |  | $ | 19,771 |  |  |
| Non-GAAP net income | $ | 27,952 |  |  | $ | 10,959 |  |  |
| Earnings per share |  |  |  |  |  |  |  |  |
| Non-GAAP net income per share-diluted | $ | 0.21 |  |  | $ | 0.09 |  |  |
| Shares used in net income per share - diluted: |  |  |  |  |  |  |  |  |
| GAAP Shares used in per share calculation - basic |  | 128,324 |  |  |  | 121,705 |  |  |
| Potentially dilutive equity awards |  | 4,901 |  |  |  | 901 |  |  |
| GAAP and Non-GAAP shares used in per share calculation - diluted |  | 133,225 |  |  |  | 122,606 |  |  |
