# EXTR notes — 0001564590-21-054929


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0001564590-21-054929:notes:1]
[same as prior period, unchanged from 0001564590-21-021969:notes:1]

[0001564590-21-054929:notes:2]
[same as prior period, unchanged from 0001564590-21-021969:notes:2]

[0001564590-21-054929:notes:3]
The unaudited condensed consolidated financial statements of Extreme included herein have been prepared under the rules and regulations of the Securities and Exchange Commission (“SEC”).  Certain information and footnote disclosures normally included in financial statements prepared in accordance with U.S. generally accepted accounting principles have been condensed or omitted under such rules and regulations.  The condensed consolidated balance sheet at June 30, 2021 was derived from audited financial statements as of that date but does not include all disclosures required by generally accepted accounting principles for complete financial statements. These interim financial statements and notes should be read in conjunction with the Company’s audited consolidated financial statements and notes thereto included in the Company’s Annual Report on Form 10-K for the fiscal year ended June 30, 2021.

[0001564590-21-054929:notes:4]
The unaudited condensed consolidated financial statements reflect all adjustments, consisting only of normal recurring adjustments that, in the opinion of management, are necessary for a fair presentation of the results of operations and cash flows for the interim periods presented and the financial condition of Extreme at September 30, 2021. The results of operations for the three months ended September 30, 2021 are not necessarily indicative of the results that may be expected for fiscal 2022 or any future periods.

[0001564590-21-054929:notes:5]
[same as prior period, unchanged from 0001564590-21-021969:notes:5]

[0001564590-21-054929:notes:6]
The Company uses a fiscal calendar year ending on June 30.  All references herein to “fiscal 2022” or “2022” represent the fiscal year ending June 30, 2022.  All references herein to “fiscal 2021” or “2021” represent the fiscal year ended June 30, 2021.

[0001564590-21-054929:notes:7]
[same as prior period, unchanged from 0001564590-21-021969:notes:7]

[0001564590-21-054929:notes:8]
[same as prior period, unchanged from 0001564590-21-021969:notes:8]

[0001564590-21-054929:notes:9]
[same as prior period, unchanged from 0001564590-21-021969:notes:9]

[0001564590-21-054929:notes:10]
[same as prior period, unchanged from 0001564590-21-021969:notes:10]

[0001564590-21-054929:notes:11]
[same as prior period, unchanged from 0001564590-21-021969:notes:11]


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001564590-21-054929:notes:12]
[same as prior period, unchanged from 0001564590-21-021969:notes:12]

[0001564590-21-054929:notes:13]
For a description of significant accounting policies, see Note 2, Summary of Significant Accounting Policies, to the consolidated financial statements included in the Company’s Annual Report on Form 10-K for the fiscal year ended June 30, 2021. There have been no material changes to the Company’s significant accounting policies since the filing of the Annual Report on Form 10-K.

[0001564590-21-054929:notes:14]
Recently Adopted Accounting Pronouncements

[0001564590-21-054929:notes:15]
In December 2019, the FASB issued ASU 2019-12, Income taxes – Simplifying the Accounting for Income Taxes (Topic 740), which reduces the complexity of accounting for income taxes including the removal of certain exceptions to the general principles of ASC 740, Income Taxes, and simplification in several other areas such as accounting for franchise tax (or similar tax) that is partially based on income. This standard is effective for fiscal years beginning after December 15, 2020, including interim periods within the fiscal year. The standard was adopted on July 1, 2021 and did not have a material impact on the Company’s financial statements upon adoption.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001564590-21-054929:notes:16]
[same as prior period, unchanged from 0001564590-21-021969:notes:20]

[0001564590-21-054929:notes:17]
The Company accounts for revenues in accordance with ASU 2014-09, Revenue from Contracts from Customers (Topic 606), which the Company adopted on July 1, 2017.  The Company derives the majority of its revenues from sales of its networking equipment, with the remaining revenues generated from sales of services and subscriptions, which primarily includes maintenance contracts and software subscriptions delivered as software as a service (“SaaS”) and additional revenues from professional services, and training for its products. The Company sells its products, maintenance contracts and SaaS direct to customers and to partners in two distribution channels, or tiers. The first tier consists of a limited number of independent distributors that stock its products and sell primarily to resellers.  The second tier of the distribution channel consists of non-stocking distributors and value-added resellers that sell directly to end-users.  Products and services may be sold separately or in bundled packages.

[0001564590-21-054929:notes:18]
[same as prior period, unchanged from 0001564590-21-021969:notes:22]

[0001564590-21-054929:notes:19]
[same as prior period, unchanged from 0001564590-21-021969:notes:23]

[0001564590-21-054929:notes:20]
[same as prior period, unchanged from 0001564590-21-021969:notes:24]

[0001564590-21-054929:notes:21]
On September 30, 2021, the Company had $356.0 million of remaining performance obligations, which are primarily comprised of deferred maintenance and SaaS revenues.  The Company expects to recognize approximately 52 percent of its deferred revenue as revenue in fiscal 2022, an additional 25 percent in fiscal 2023 and 23 percent of the balance thereafter.

[0001564590-21-054929:notes:22]
[same as prior period, unchanged from 0001564590-21-021969:notes:26]

[0001564590-21-054929:notes:23]
Revenue recognized for the three months ended September 30, 2021 and 2020 that was included in the deferred revenue balance at the beginning of each period was $73.4 million and $66.9 million, respectively.

[0001564590-21-054929:notes:24]
Contract Costs. The Company recognizes the incremental costs of obtaining contracts as an expense when incurred if the amortization period of the assets that the Company otherwise would have recognized is one year or less.  Management expects that commission fees paid to sales representatives as a result of obtaining service contracts and contract renewals are recoverable and therefore the Company’s condensed consolidated balance sheets included capitalized balances in the amount of $13.5 million and $13.1 million at September 30, 2021 and June 30, 2021, respectively. Capitalized commission fees are amortized on a straight-line basis over the average period of service contracts of approximately three years, and are included in “Sales and marketing” in the accompanying condensed consolidated statements of operations. Amortization recognized during the three months ended September 30, 2021 and 2020, was $1.8 million and $1.2 million, respectively.

[0001564590-21-054929:notes:25]
Estimated Variable Consideration. There were no material changes in the current period to the estimated variable consideration for performance obligations, which were satisfied or partially satisfied during previous periods.

[0001564590-21-054929:notes:26]
[same as prior period, unchanged from 0001564590-21-021969:notes:30]

[0001564590-21-054929:notes:27]
The Company operates in three geographic regions: Americas, which includes the United States, Canada, Mexico, Central America and South America; EMEA, which includes Europe, Russia, Middle East and Africa; and APAC, which includes Asia Pacific, China, South Asia and Japan. The following table sets forth the Company’s revenues disaggregated by sales channel and geographic region based on the billing addresses of its customer’s (in thousands):

[0001564590-21-054929:notes:28]
|  |  | Three Months Ended |  |
|  |  | September 30, 2021 |  |  | September 30, 2020 |  |
|  |  | Distributor |  | Direct |  | Total |  |  | Distributor |  | Direct |  | Total |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  | $ | 56,068 |  | $ | 67,331 |  | $ | 123,399 |  |  | $ | 60,670 |  | $ | 57,347 |  | $ | 118,017 |  |
| Other |  |  | 7,799 |  |  | 3,367 |  |  | 11,166 |  |  |  | 8,241 |  |  | 4,090 |  |  | 12,331 |  |
| Total Americas |  |  | 63,867 |  |  | 70,698 |  |  | 134,565 |  |  |  | 68,911 |  |  | 61,437 |  |  | 130,348 |  |
| EMEA |  |  | 77,898 |  |  | 35,731 |  |  | 113,629 |  |  |  | 47,529 |  |  | 33,576 |  |  | 81,105 |  |
| APAC |  |  | 4,335 |  |  | 15,155 |  |  | 19,490 |  |  |  | 5,051 |  |  | 19,298 |  |  | 24,349 |  |
| Total net revenues |  | $ | 146,100 |  | $ | 121,584 |  | $ | 267,684 |  |  | $ | 121,491 |  | $ | 114,311 |  | $ | 235,802 |  |

[0001564590-21-054929:notes:29]
For the three months ended September 30, 2021 the Company generated 11% of its revenues from the Netherlands and 10% of its revenues from the Germany. No other foreign country accounted for 10% or more of revenue for the three months ended September 30, 2021 or 2020.

[0001564590-21-054929:notes:30]
[same as prior period, unchanged from 0001564590-21-021969:notes:35]

[0001564590-21-054929:notes:31]
[same as prior period, unchanged from 0001564590-21-021969:notes:36]

[0001564590-21-054929:notes:32]
[same as prior period, unchanged from 0001564590-21-021969:notes:37]

[0001564590-21-054929:notes:33]
|  |  | Three Months Ended |  |
|  |  | September 30, 2021 |  |  | September 30, 2020 |  |
| Tech Data Corporation |  | 22% |  |  | 27% |  |
| Jenne Corporation |  | 14% |  |  | 15% |  |
| Westcon Group Inc. |  | 18% |  |  | 13% |  |

[0001564590-21-054929:notes:34]
[same as prior period, unchanged from 0001564590-21-021969:notes:39]

[0001564590-21-054929:notes:35]
|  |  | September 30, 2021 |  |  | June 30, 2021 |  |
| Tech Data Corporation |  | 17% |  |  | 19% |  |
| Jenne Corporation |  | 22% |  |  | 24% |  |


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001564590-21-054929:notes:36]
[same as prior period, unchanged from 0001564590-21-021969:notes:41]

[0001564590-21-054929:notes:37]
Fiscal 2022 Acquisition

[0001564590-21-054929:notes:38]
Ipanema Acquisition

[0001564590-21-054929:notes:39]
On September 14, 2021 (the “Acquisition Date”), the Company completed its acquisition (the “Acquisition”) of Ipanematech SAS (“Ipanema”), the cloud-native enterprise Software-Defined Wide Area Network (“SD-WAN”) business unit of Infovista pursuant to a Sale and Purchase Agreement (“the Agreement”).  Under the terms of the Acquisition, the net consideration paid by Extreme to Ipanema stockholders was $70.9 million which was funded from existing cash on hand. The primary reason for the acquisition was to acquire the talent and the technology which will allow us to expand our portfolio with new cloud-managed SD-WAN and security offerings to support our enterprise customers.

[0001564590-21-054929:notes:40]
The Acquisition has been accounted for using the acquisition method of accounting whereby the acquired assets and liabilities of Ipanema have been recorded at their respective fair values and added to those of the Company including an amount for goodwill

[0001564590-21-054929:notes:41]
calculated as the difference between the acquisition consideration and the fair value of the identifiable net assets. The purchase price has been preliminarily allocated to tangible and identifiable intangible assets acquired and liabilities assumed. The final purchase price allocation is pending the finalization of valuations primarily intangible assets and deferred revenue, which may result in an adjustment to the preliminary purchase price allocation.

[0001564590-21-054929:notes:42]
The estimated fair values were determined through established and generally accepted valuation techniques, including work performed by third-party valuation specialists. The fair value of working capital related items, such as accounts receivable, other current assets and accrued liabilities, approximated their book values at the date of acquisition. The fair value of the acquired deferred revenue was estimated using the cost build-up approach. The cost build-up approach determines fair value using estimates of the costs required to provide the contracted deliverables plus an assumed profit. The total costs including the assumed profit were adjusted to present value using a discount rate considered appropriate. The resulting fair value approximates the amount that the Company would be required to pay to a third party to assume the obligation. Valuations of the intangible assets were valued using income approaches based on management projections, which the Company considers to be Level 3 inputs. The Company also continues to analyze the tax implications of the acquisition of the intangible assets which may ultimately impact the overall level of goodwill associated with the acquisition. Results of operations of Ipanema have been included in the operations of the Company beginning with the Acquisition Date.

[0001564590-21-054929:notes:43]
The preliminary purchase price allocation is set forth in the table below and reflects estimated fair values (in thousands):

[0001564590-21-054929:notes:44]
|  | Preliminary Allocation as of September 14, 2021 |  |
| Cash and cash equivalents | $ | 1,364 |  |
| Accounts receivable, net |  | 1,440 |  |
| Inventories |  | 337 |  |
| Prepaid expenses and other current assets |  | 1,841 |  |
| Property and equipment |  | 46 |  |
| Other assets |  | 21 |  |
| Accounts payable |  | (1,220 | ) |
| Accrued compensation and benefits |  | (2,304 | ) |
| Accrued warranty |  | (41 | ) |
| Other accrued liabilities |  | (71 | ) |
| Deferred revenue |  | (2,758 | ) |
| Other liabilities |  | (723 | ) |
| Net tangible liabilities |  | (2,068 | ) |
| Identifiable intangible assets |  | 16,300 |  |
| Goodwill |  | 56,649 |  |
| Total intangible assets acquired |  | 72,949 |  |
| Total net assets acquired | $ | 70,881 |  |

[0001564590-21-054929:notes:45]
The following table presents details of the identifiable intangible assets acquired as part of the acquisition (in thousands):

[0001564590-21-054929:notes:46]
| Intangible Assets |  | Weighted Average Estimated Useful Life (in years) |  |  | Amount |  |
| Developed technologies |  |  | 6 |  |  | $ | 14,500 |  |
| Customer relationships |  |  | 4 |  |  |  | 1,800 |  |
| Total identifiable intangible assets |  |  |  |  |  | $ | 16,300 |  |

[0001564590-21-054929:notes:47]
The amortization for the developed technologies is recorded in “Cost of revenues” for product and the amortization for the remaining intangibles is recorded in “Amortization of intangibles” in the accompanying condensed consolidated statements of operations. The goodwill recognized is attributable primarily to expected synergies and the assembled workforce of Ipanema. The Company will not be entitled to amortization of the goodwill and intangible assets for tax purposes as this acquisition is a nontaxable stock acquisition.

[0001564590-21-054929:notes:48]
The results of operations of Ipanema are included in the accompanying condensed consolidated results of operations beginning September 15, 2021.  The overall results of Operations of Ipanema were not material to the condensed consolidated financial statements of Extreme.

[0001564590-21-054929:notes:49]
In the quarter ended September 30, 2021, the Company incurred acquisition and integration related expenses of $1.5 million associated with the acquisition of Ipanema. Acquisition and integration costs consist primarily of professional fees for financial and legal advisory services. Such acquisition-related costs were expensed as incurred and are included in “Acquisition and integration costs” in the accompanying condensed consolidated statements of operations.

[0001564590-21-054929:notes:50]
Pro forma financial information

[0001564590-21-054929:notes:51]
The following unaudited pro forma results of operations are presented as though the Acquisition had occurred as of the beginning of the earliest period presented, July 1, 2020, the beginning of fiscal 2021, after giving effect to purchase accounting adjustments relating to deferred revenue, depreciation and amortization of intangibles and acquisition and integration costs.

[0001564590-21-054929:notes:52]
The pro forma results of operations are not necessarily indicative of the combined results that would have occurred had the acquisition been consummated as of the beginning of fiscal 2021, nor are they necessarily indicative of future operating results. The unaudited pro forma results do not include the impact of synergies, nor any potential impacts on current or future market conditions which could alter the unaudited pro forma results.

[0001564590-21-054929:notes:53]
The unaudited pro forma financial information for the three months ended September 30, 2020 combines the historical results for Extreme for such periods assuming the transaction closed on July 1, 2020, which include the results of Ipanema subsequent to the Acquisition Date, and Ipanema’s historical results up to the Acquisition Date.

[0001564590-21-054929:notes:54]
[same as prior period, unchanged from 0001564590-21-021969:notes:49]

[0001564590-21-054929:notes:55]
|  |  | Three months ended |  |
|  |  | September 30, 2021 |  |  | September 30, 2020 |  |
| Net revenues |  | $ | 270,051 |  |  | $ | 237,494 |  |
| Net income (loss) |  | $ | 12,815 |  |  | $ | (14,298 | ) |
| Net income (loss) per share - basic |  | $ | 0.10 |  |  | $ | (0.12 | ) |
| Net income (loss) per share - diluted |  | $ | 0.10 |  |  | $ | (0.12 | ) |
| Shares used in per share calculation - basic |  |  | 128,324 |  |  |  | 121,705 |  |
| Shares used in per share calculation - diluted |  |  | 133,225 |  |  |  | 121,705 |  |


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001564590-21-054929:notes:56]
[same as prior period, unchanged from 0001564590-21-021969:notes:51]

[0001564590-21-054929:notes:57]
[same as prior period, unchanged from 0001564590-21-021969:notes:52]

[0001564590-21-054929:notes:58]
[same as prior period, unchanged from 0001564590-21-021969:notes:53]

[0001564590-21-054929:notes:59]
[same as prior period, unchanged from 0001564590-21-021969:notes:54]

[0001564590-21-054929:notes:60]
|  |  | September 30, 2021 |  |  | June 30, 2021 |  |
| Finished goods |  | $ | 26,398 |  |  | $ | 27,901 |  |
| Raw materials |  |  | 6,041 |  |  |  | 4,984 |  |
| Total Inventories |  | $ | 32,439 |  |  | $ | 32,885 |  |

[0001564590-21-054929:notes:61]
[same as prior period, unchanged from 0001564590-21-021969:notes:56]

[0001564590-21-054929:notes:62]
[same as prior period, unchanged from 0001564590-21-021969:notes:57]

[0001564590-21-054929:notes:63]
|  |  | September 30, 2021 |  |  | June 30, 2021 |  |
| Computers and equipment |  | $ | 74,943 |  |  | $ | 75,866 |  |
| Purchased software |  |  | 41,421 |  |  |  | 40,037 |  |
| Office equipment, furniture and fixtures |  |  | 10,219 |  |  |  | 10,201 |  |
| Leasehold improvements |  |  | 53,130 |  |  |  | 53,329 |  |
| Total property and equipment |  |  | 179,713 |  |  |  | 179,433 |  |
| Less: accumulated depreciation and amortization |  |  | (126,835 | ) |  |  | (124,429 | ) |
| Property and equipment, net |  | $ | 52,878 |  |  | $ | 55,004 |  |

[0001564590-21-054929:notes:64]
[same as prior period, unchanged from 0001564590-21-021969:notes:59]

[0001564590-21-054929:notes:65]
[same as prior period, unchanged from 0001564590-21-021969:notes:60]

[0001564590-21-054929:notes:66]
[same as prior period, unchanged from 0001564590-21-021969:notes:61]

[0001564590-21-054929:notes:67]
[same as prior period, unchanged from 0001564590-21-021969:notes:62]

[0001564590-21-054929:notes:68]
The following table summarizes the activity related to the Company’s product warranty liability during the three months ended September 30, 2021 and 2020 (in thousands):

[0001564590-21-054929:notes:69]
|  |  | Three Months Ended |  |
|  |  | September 30, 2021 |  |  | September 30, 2020 |  |
| Balance beginning of period |  | $ | 11,623 |  |  | $ | 14,035 |  |
| Warranties assumed due to acquisition |  |  | 41 |  |  |  | — |  |
| New warranties issued |  |  | 2,710 |  |  |  | 3,079 |  |
| Warranty expenditures |  |  | (3,594 | ) |  |  | (3,630 | ) |
| Balance end of period |  | $ | 10,780 |  |  | $ | 13,484 |  |

[0001564590-21-054929:notes:70]
[same as prior period, unchanged from 0001564590-21-021969:notes:65]

[0001564590-21-054929:notes:71]
[same as prior period, unchanged from 0001564590-21-021969:notes:66]

[0001564590-21-054929:notes:72]
The Company may be subject to concentration of credit risk as a result of certain financial instruments consisting of accounts receivable. The Company does not invest an amount exceeding 10% of its combined cash in the securities of any one obligor or maker, except for obligations of the United States government, obligations of United States government agencies and money market accounts.


## us-gaap:FairValueDisclosuresTextBlock

[0001564590-21-054929:notes:73]
[same as prior period, unchanged from 0001564590-21-021969:notes:68]

[0001564590-21-054929:notes:74]
[same as prior period, unchanged from 0001564590-21-021969:notes:69]

[0001564590-21-054929:notes:75]
[same as prior period, unchanged from 0001564590-21-021969:notes:70]

[0001564590-21-054929:notes:76]
[same as prior period, unchanged from 0001564590-21-021969:notes:71]

[0001564590-21-054929:notes:77]
[same as prior period, unchanged from 0001564590-21-021969:notes:72]

[0001564590-21-054929:notes:78]
The following table presents the Company’s fair value hierarchy for its financial assets and liabilities measured at fair value on a recurring basis at September 30, 2021 and June 30, 2021 (in thousands).

[0001564590-21-054929:notes:79]
| September 30, 2021 |  | Level 1 |  |  | Level 2 |  |  | Level 3 |  |  | Total |  |
| Liabilities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency derivatives |  | $ | — |  |  | $ | 740 |  |  | $ | — |  |  | $ | 740 |  |
| Interest rate swaps |  |  | — |  |  |  | 937 |  |  |  | — |  |  |  | 937 |  |
| Acquisition-related contingent consideration obligations |  |  | — |  |  |  | — |  |  |  | 358 |  |  |  | 358 |  |
| Total liabilities measured at fair value |  | $ | — |  |  | $ | 1,677 |  |  | $ | 358 |  |  | $ | 2,035 |  |

[0001564590-21-054929:notes:80]
| June 30, 2021 |  | Level 1 |  |  | Level 2 |  |  | Level 3 |  |  | Total |  |
| Liabilities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency derivatives |  | $ | — |  |  | $ | 560 |  |  | $ | — |  |  | $ | 560 |  |
| Interest rate swaps |  |  | — |  |  |  | 1,133 |  |  |  | — |  |  |  | 1,133 |  |
| Acquisition-related contingent consideration obligations |  |  | — |  |  |  | — |  |  |  | 913 |  |  |  | 913 |  |
| Total liabilities measured at fair value |  | $ | — |  |  | $ | 1,693 |  |  | $ | 913 |  |  | $ | 2,606 |  |

[0001564590-21-054929:notes:81]
[same as prior period, unchanged from 0001564590-21-021969:notes:76]

[0001564590-21-054929:notes:82]
[same as prior period, unchanged from 0001564590-21-021969:notes:77]

[0001564590-21-054929:notes:83]
As of September 30, 2021 and June 30, 2021, the Company had foreign exchange forward contracts that were not designated as hedging instruments with notional principal amount of $22.6 million and $23.0 million, respectively. These contracts have maturities of 40 days or less. Changes in the fair value of these foreign exchange forward contracts are included in other income (expense), net in the condensed consolidated statement of operations. For the three months ended September 30, 2021, there were net losses of $0.2 million. For the three months ended September 30, 2020, there were gains of less than $0.1 million. As of September 30, 2021 and June 30, 2021, the Company had foreign exchange forward contracts that were designated as hedging instruments with notional principal amount of $11.3 million and $21.8 million, respectively. These contracts have maturities of less than twelve months. Gains and losses arising from these contracts designated as hedging instruments are recorded as a component of accumulated other comprehensive income (loss). As of September 30, 2021 and June 30, 2021, these contracts had unrealized losses of $0.4 million and $0.2 million, respectively. See Note 13, Derivatives and Hedging, for additional information.

[0001564590-21-054929:notes:84]
The fair values of the interest rate swaps are based upon inputs corroborated by observable market data which is considered Level 2. As of September 30, 2021 and as of June 30, 2021, the Company had interest rate swap contracts, designated as cash flow hedges, with the total notional amount of $200.0 million. Changes in fair value of these contracts are recorded as a component of accumulated other comprehensive loss. As of September 30, 2021 and as of June 30, 2021, these contracts had an unrealized loss of $0.9 million and $1.1 million, respectively. See Note 13, Derivatives and Hedging, for additional information.

[0001564590-21-054929:notes:85]
The fair value of the borrowings under the 2019 Credit Agreement (as discussed in Note 8) is estimated based on valuations provided by alternative pricing sources supported by observable inputs which is considered Level 2.  Since the interest rate is variable for the 2019 Credit Agreement, the fair value approximates the face amount of the Company’s indebtedness of $330.0 million and $346.7 million as of September 30, 2021, and June 30, 2021, respectively.

[0001564590-21-054929:notes:86]
[same as prior period, unchanged from 0001564590-21-021969:notes:81]

[0001564590-21-054929:notes:87]
At September 30, 2021 and June 30, 2021, the Company reflected one liability measured at fair value of $0.4 million and $0.9 million, respectively, for contingent consideration related to a certain acquisition completed in fiscal 2018. The fair value measurement of the contingent consideration obligation is determined using Level 3 inputs. These fair value measurements represent Level 3 measurements as they are based on significant inputs not observable in the market. Changes in the value of the contingent consideration obligations is recorded in general and administrative expenses in the accompanying condensed consolidated statements of operations.

[0001564590-21-054929:notes:88]
[same as prior period, unchanged from 0001564590-21-021969:notes:83]

[0001564590-21-054929:notes:89]
|  |  | Three Months Ended |  |
|  |  | September 30, 2021 |  |  | September 30, 2020 |  |
| Beginning balance |  |  | 913 |  |  |  | 2,167 |  |
| Payments |  |  | (559 | ) |  |  | (603 | ) |
| Accretion on discount |  |  | 4 |  |  |  | 12 |  |
| Ending balance |  | $ | 358 |  |  | $ | 1,576 |  |

[0001564590-21-054929:notes:90]
There were no transfers of assets or liabilities between Level 1, Level 2 and Level 3 during the three months ended September 30, 2021 and 2020. There were no impairments recorded for the three months ended September 30, 2021 and 2020.

[0001564590-21-054929:notes:91]
[same as prior period, unchanged from 0001564590-21-021969:notes:86]


## us-gaap:IntangibleAssetsDisclosureTextBlock

[0001564590-21-054929:notes:92]
[same as prior period, unchanged from 0001564590-21-021969:notes:87]

[0001564590-21-054929:notes:93]
[same as prior period, unchanged from 0001564590-21-021969:notes:88]

[0001564590-21-054929:notes:94]
|  |  | Weighted Average |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Remaining Amortization |  | Gross Carrying |  |  | Accumulated |  |  | Net Carrying |  |
|  |  | Period |  | Amount |  |  | Amortization |  |  | Amount |  |
| September 30, 2021 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Developed technology |  | 3.4 years |  | $ | 170,600 |  |  | $ | 135,112 |  |  | $ | 35,488 |  |
| Customer relationships |  | 4.6 years |  |  | 64,839 |  |  |  | 55,074 |  |  |  | 9,765 |  |
| Backlog |  | — years |  |  | 400 |  |  |  | 400 |  |  |  | — |  |
| Trade names |  | 0.6 years |  |  | 10,700 |  |  |  | 10,429 |  |  |  | 271 |  |
| License agreements |  | 5.2 years |  |  | 2,445 |  |  |  | 2,071 |  |  |  | 374 |  |
| Total intangibles, net |  |  |  | $ | 248,984 |  |  | $ | 203,086 |  |  | $ | 45,898 |  |

[0001564590-21-054929:notes:95]
|  |  | Weighted Average |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Remaining Amortization |  | Gross Carrying |  |  | Accumulated |  |  | Net Carrying |  |
|  |  | Period |  | Amount |  |  | Amortization |  |  | Amount |  |
| June 30, 2021 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Developed technology |  | 1.8 years |  | $ | 156,100 |  |  | $ | 129,861 |  |  | $ | 26,239 |  |
| Customer relationships |  | 4.8 years |  |  | 63,039 |  |  |  | 54,204 |  |  |  | 8,835 |  |
| Backlog |  | — years |  |  | 400 |  |  |  | 400 |  |  |  | — |  |
| Trade names |  | 0.7 years |  |  | 10,700 |  |  |  | 10,128 |  |  |  | 572 |  |
| License agreements |  | 5.4 years |  |  | 2,445 |  |  |  | 2,053 |  |  |  | 392 |  |
| Total intangibles, net |  |  |  | $ | 232,684 |  |  | $ | 196,646 |  |  | $ | 36,038 |  |

[0001564590-21-054929:notes:96]
[same as prior period, unchanged from 0001564590-21-021969:notes:91]

[0001564590-21-054929:notes:97]
|  |  | Three Months Ended |  |
|  |  | September 30, 2021 |  |  | September 30, 2020 |  |
| Amortization of intangibles in “Total cost of revenues” |  | $ | 5,286 |  |  | $ | 6,699 |  |
| Amortization of intangibles in "Operations" |  |  | 1,154 |  |  |  | 1,792 |  |
| Total amortization expense |  | $ | 6,440 |  |  | $ | 8,491 |  |

[0001564590-21-054929:notes:98]
The amortization expense that is recognized in “Total cost of revenues” is comprised of amortization for developed technology, license agreements and other intangibles.


## us-gaap:DebtDisclosureTextBlock

[0001564590-21-054929:notes:99]
| 8. | Debt |

[0001564590-21-054929:notes:100]
The Company’s debt is comprised of the following (in thousands):

[0001564590-21-054929:notes:101]
|  |  | September 30, 2021 |  |  | June 30, 2021 |  |
| Current portion of long-term debt: |  |  |  |  |  |  |  |  |
| Term Loan |  | $ | 28,500 |  |  | $ | 26,125 |  |
| Less: unamortized debt issuance costs |  |  | (2,356 | ) |  |  | (2,404 | ) |
| Current portion of long-term debt |  | $ | 26,144 |  |  | $ | 23,721 |  |
| Long-term debt, less current portion: |  |  |  |  |  |  |  |  |
| Term Loan |  | $ | 301,500 |  |  | $ | 320,625 |  |
| Less: unamortized debt issuance costs |  |  | (4,121 | ) |  |  | (4,760 | ) |
| Total long-term debt, less current portion |  |  | 297,379 |  |  |  | 315,865 |  |
| Total debt |  | $ | 323,523 |  |  | $ | 339,586 |  |

[0001564590-21-054929:notes:102]
In connection with the acquisition of Aerohive Networks, Inc., on August 9, 2019, the Company entered into an Amended and Restated Credit Agreement (the “2019 Credit Agreement”), by and among the Company, as borrower, several banks and other financial institutions as Lenders, BMO Harris Bank N.A., as an issuing lender and swingline lender, Silicon Valley Bank, as an Issuing Lender, and Bank of Montreal, as administrative agent and collateral agent for the Lenders.

[0001564590-21-054929:notes:103]
The 2019 Credit Agreement provides for a five-year first lien term loan facility in an aggregate principal amount of $380 million and a five-year revolving loan facility in an aggregate principal amount of $75 million (the “2019 Revolving Facility”).  In addition, the Company may request incremental term loans and/or incremental revolving loan commitments in an aggregate amount not to exceed the sum of $100 million plus an unlimited amount that is subject to pro forma compliance with certain financial tests. On August 9, 2019, the Company used the additional proceeds from the term loan to partially fund the Acquisition and for working capital and general corporate purposes.

[0001564590-21-054929:notes:104]
At the Company’s election, the initial term loan under the 2019 Credit Agreement may be made as either base rate loans or Eurodollar loans. The applicable margin for base rate loans ranges from 0.25% to 2.50% per annum and the applicable margin for Eurodollar loans ranges from 1.25% to 3.50%, in each case based on Extreme’s consolidated leverage ratio. All Eurodollar loans are subject to a Base Rate of 0.00%. In addition, the Company is required to pay a commitment fee of between 0.25% and 0.40% quarterly (currently 0.30%) on the unused portion of the 2019 Revolving Facility, also based on the Company’s consolidated leverage ratio. Principal installments are payable on the new term loan in varying percentages quarterly starting December 31, 2019 and to the extent not previously paid, all outstanding balances are to be paid at maturity. The 2019 Credit Agreement is secured by substantially all of the Company’s assets.

[0001564590-21-054929:notes:105]
The 2019 Credit Agreement requires the Company to maintain certain minimum financial ratios at the end of each fiscal quarter. The 2019 Credit Agreement also includes covenants and restrictions that limit, among other things, the Company’s ability to incur additional indebtedness, create liens upon any of its property, merge, consolidate or sell all or substantially all of its assets. The 2019 Credit Agreement also includes customary events of default which may result in acceleration of the payment of the outstanding balance.

[0001564590-21-054929:notes:106]
On April 8, 2020, the Company entered into the first amendment to the 2019 Credit Agreement (the “First Amendment”) to waive certain terms and financial covenants of the 2019 Credit Agreement through July 31, 2020. On May 8, 2020, the Company entered into the second amendment to the 2019 Credit Agreement (the “Second Amendment”) which superseded the First Amendment and provided certain revised terms and financial covenants through March 31, 2021. Subsequent to March 31, 2021, the original terms and financial covenants under the 2019 Credit Agreement resumed in effect. The Second Amendment required the Company to maintain certain minimum cash requirement and certain financial metrics at the end of each fiscal quarter through March 31, 2021.

[0001564590-21-054929:notes:107]
Under the terms of the Second Amendment, the Company was not permitted to exceed $55.0 million in its outstanding balance under the 2019 Revolving Facility, the applicable margin for Eurodollar rate was 4.5%, and the Company was restricted from pursuing certain activities such as incurring additional debt, stock repurchases, making acquisitions or declaring a dividend, until the Company was in compliance with the original covenants of the 2019 Credit Agreement.

[0001564590-21-054929:notes:108]
On November 3, 2020, The Company and its lenders entered into the Third Amendment to the 2019 Credit Agreement (the “Third Amendment”), to increase the sublimit for letters of credit to $20.0 million. On December 8, 2020, the Company and its lenders entered into the fourth amendment to the 2019 Credit Agreement (the “Fourth Amendment”), to waive and amend certain terms and financial covenants within the 2019 Credit Agreement through March 31, 2021.

[0001564590-21-054929:notes:109]
The Second Amendment provided for the Company to end the covenant Suspension Period early and revert to the covenants and interest rates per the original terms of the 2019 Credit Agreement dated August 9, 2019 by filing a Suspension Period Early Termination Notice and Covenant Certificate demonstrating compliance. For the twelve-month period ended March 31, 2021 the Company’s financial performance was in compliance with the original covenants defined in the 2019 Credit Agreement and as such the Company filed a Suspension Early Termination Notice and Covenant Certificate with the administration agent subsequent to filing our Form 10-Q for the quarterly period ended March 31, 2021. Returning to compliance with the covenants per the original terms of the 2019 Credit Agreement dated August 9, 2019 resulted in the Company’s Eurodollar loan spread decreasing from 4.5% during the suspension period to 2.75% and unused facility commitment fee decreasing from 0.4% to 0.35%, and the limitation on revolver borrowings being removed effective May 1, 2021 after filing of the certificate with the administrative agent.

[0001564590-21-054929:notes:110]
Financing costs incurred in connection with obtaining long-term financing are deferred and amortized over the term of the related indebtedness or credit agreement. During the year ended June 30, 2020, the Company incurred $10.5 million of deferred financing costs in conjunction with the 2019 Credit Agreement and $1.5 million of deferred financing costs from the amendments, and continues to amortize $1.6 million of debt issuance costs as of August 9, 2019 that were associated with the previous facility. The interest rate as of September 30, 2021 was 2.4%. and as of September 30, 2020 was 4.9%.

[0001564590-21-054929:notes:111]
Amortization of deferred financing costs included in “Interest expense” in the accompanying condensed consolidated statements of operations totaled $0.8 million and $0.8 million for the three months ended September 30, 2021 and 2020

[0001564590-21-054929:notes:112]
During the fiscal year ended June 30, 2021, the Company repaid $55.0 million against its 2019 Revolving Facility’s outstanding balance of $55.0 million and has no remaining outstanding balance at September 30, 2021. The Company has $60.2 million of availability under the 2019 Revolving Facility as of September 30, 2021. During the three months ended September 30, 2021, the Company made an additional payment of $12 million against its term loan facility.

[0001564590-21-054929:notes:113]
The Company had $14.8 million of outstanding letters of credit as of September 30, 2021.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001564590-21-054929:notes:114]
| 9. | Commitments and Contingencies |

[0001564590-21-054929:notes:115]
Purchase Commitments

[0001564590-21-054929:notes:116]
The Company currently has arrangements with contract manufacturers and suppliers for the manufacture of its products. Those arrangements allow the contract manufactures to procure long lead-time component inventory based upon a rolling production forecast provided by the Company. The Company is obligated to purchase long lead-time component inventory that its contract manufacturer procures in accordance with the forecast, unless the Company gives notice of order cancellation outside of applicable component lead-times. As of September 30, 2021, the Company had commitments to purchase $64.9 million of inventory.

[0001564590-21-054929:notes:117]
Legal Proceedings

[0001564590-21-054929:notes:118]
The Company may from time to time be party to litigation arising in the course of its business, including, without limitation, allegations relating to commercial transactions, business relationships or intellectual property rights. Such claims, even if not meritorious, could result in the expenditure of significant financial and managerial resources. Litigation in general, and intellectual property in particular, can be expensive and disruptive to normal business operations. Moreover, the results of legal proceedings are difficult to predict.

[0001564590-21-054929:notes:119]
In accordance with applicable accounting guidance, the Company records accruals for certain of its outstanding legal proceedings, investigations or claims when it is probable that a liability will be incurred, and the amount of loss can be reasonably estimated. The Company evaluates, at least on a quarterly basis, developments in legal proceedings, investigations or claims that could affect the amount of any accrual, as well as any developments that would result in a loss contingency to become both probable and reasonably estimable. When a loss contingency is not both probable and reasonably estimable, the Company does not record a loss accrual. However, if the loss (or an additional loss in excess of any prior accrual) is at least reasonably possible and material, then the Company would disclose an estimate of the possible loss or range of loss, if such estimate can be made, or disclose that an estimate cannot be made. The assessment whether a loss is probable or a reasonable possibility, and whether the loss or a range of loss is estimable, involves a series of complex judgments about future events. Even if a loss is reasonably possible, the Company may not be

[0001564590-21-054929:notes:120]
able to estimate a range of possible loss, particularly where (i) the damages sought are substantial or indeterminate, (ii) the proceedings are in the early stages, or (iii) the matters involve novel or unsettled legal theories or a large number of parties. In such cases, there is considerable uncertainty regarding the ultimate resolution of such matters, including the amount of any possible loss, fine or penalty. An adverse resolution of one or more of such matters could have a material adverse effect on the Company's results of operations in a particular quarter or fiscal year.

[0001564590-21-054929:notes:121]
XR Communications, LLC d/b/a Vivato Technologies v. Extreme Networks, Inc.

[0001564590-21-054929:notes:122]
On April 19, 2017, XR Communications, LLC (“XR”) (d/b/a Vivato Technologies) filed a patent infringement lawsuit against the Company in the Central District of California. The operative Second Amended Complaint asserts infringement of certain U.S. Patent based on the Company’s manufacture, use, sale, offer for sale, and/or importation into the United States of certain access points and routers supporting multi-user, multiple-input, multiple-output technology. XR seeks unspecified damages, on-going royalties, pre- and post-judgment interest, and attorneys’ fees. The stay issued by the District Court in 2018 has been lifted.

[0001564590-21-054929:notes:123]
Orckit IP, LLC v. Extreme Networks, Inc., Extreme Networks Ireland Ltd., and Extreme Networks GmbH

[0001564590-21-054929:notes:124]
On February 1, 2018, Orckit IP, LLC (“Orckit”) filed a patent infringement lawsuit against the Company and its Irish and German subsidiaries in the District Court in Dusseldorf, Germany. The lawsuit alleges direct and indirect infringement of the German portion of a patent (“EP ’364”) based on the offer, distribution, use, possession and/or importation into Germany of certain network switches that equipped with the ExtremeXOS operating system. Orckit is seeking injunctive relief, accounting, and an unspecified declaration of liability for damages and costs of the lawsuit. On January 28, 2020, the Court rendered a decision in the infringement case in favor of the Company. The matter is proceeding through the appellate process, and an oral hearing was held on October 21, 2021.  A decision is pending.

[0001564590-21-054929:notes:125]
On April 23, 2019, Orckit filed an extension of the patent infringement complaint against the Company and its Irish and German subsidiaries in the District Court in Dusseldorf, Germany. With this extension, Orckit alleges infringement of the German portion of a second patent (“EP ‘077”) based on the offer, distribution, use, possession and/or importation into Germany of certain network switches that the Company no longer sells in Germany. Orckit is seeking injunctive relief, accounting and sales information, and a declaration of liability for damages as well as costs of the lawsuit. On October 13, 2020, the Court issued an infringement decision against the Company and granted to Orckit the right to enforce the judgment against the Company, which Orckit has provided notification to the Company that it will enforce the judgment. The matter is proceeding through the appellate process.

[0001564590-21-054929:notes:126]
The Company filed a nullity action related to the EP ‘364 patent on May 3, 2018, and one related to the EP ‘077 patent on October 31, 2019, both in the Federal Patent Court in Munich. The court found the EP ‘364 patent to be valid and the Company is considering an appeal.  The case filed to seek to invalidate the EP ‘077 patent is proceeding.

[0001564590-21-054929:notes:127]
SNMP Research, Inc. and SNMP Research International, Inc. v. Broadcom Inc., Brocade Communications Systems LLC, and Extreme Networks, Inc.

[0001564590-21-054929:notes:128]
On October 26, 2020, SNMP Research, Inc. and SNMP Research International, Inc. (collectively, “SNMP”) filed a lawsuit against the Company in the Eastern District of Tennessee for copyright infringement, alleging that the Company was not properly licensed to use their software.  SNMP is seeking actual damages and profits attributed to the infringement, as well as equitable relief. The Company has filed a motion to dismiss and a motion to transfer the case to the Northern District of California. Both motions are pending. A trial date has been set for November 2022.

[0001564590-21-054929:notes:129]
Mala Technologies Ltd. v. Extreme Networks GmbH, Extreme Networks Ireland Ops Ltd., and Extreme Networks, Inc.

[0001564590-21-054929:notes:130]
On April 15, 2021, Mala Technologies Ltd. (“Mala”) filed a patent infringement lawsuit against the Company and its Irish and German subsidiaries in the District Court in Dusseldorf, Germany.  The lawsuit alleges indirect infringement of the German portion of a patent (“EP ‘498”) based on the offer and sale in Germany of certain network switches equipped with the ExtremeXOS operating system.  Mala is seeking injunctive relief, accounting, and an unspecified declaration of liability for damages and costs of the lawsuit.  A hearing date has been set for July 14, 2022.  The Company filed a nullity action related to the EP’498 patent on September 24, 2021 in the German Federal Patent Court.

[0001564590-21-054929:notes:131]
Indemnification Obligations

[0001564590-21-054929:notes:132]
Subject to certain limitations, the Company may be obligated to indemnify its current and former directors, officers and employees. These obligations arise under the terms of its certificate of incorporation, its bylaws, applicable contracts, and applicable law. The obligation to indemnify, where applicable, generally means that the Company is required to pay or reimburse, and in certain circumstances the Company has paid or reimbursed, the individuals' reasonable legal expenses and possibly damages and other liabilities incurred in connection with certain legal matters. The Company also procures Directors and Officers liability insurance to

[0001564590-21-054929:notes:133]
help cover its defense and/or indemnification costs, although its ability to recover such costs through insurance is uncertain.  While it is not possible to estimate the maximum potential amount that could be owed under these governing documents and agreements due to the Company’s limited history with prior indemnification claims, indemnification (including defense) costs could, in the future, have a material adverse effect on the Company’s consolidated financial position, results of operations and cash flows.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001564590-21-054929:notes:134]
[same as prior period, unchanged from 0001564590-21-021969:notes:133]

[0001564590-21-054929:notes:135]
[same as prior period, unchanged from 0001564590-21-021969:notes:134]

[0001564590-21-054929:notes:136]
[same as prior period, unchanged from 0001564590-21-021969:notes:135]

[0001564590-21-054929:notes:137]
The Company’s Board of Directors (the “Board”) adopted the Restated Rights Plan to preserve the value of deferred tax assets, including net operating loss carry forwards of the Company, with respect to its ability to fully use its tax benefits to offset future income which may be limited if the Company experiences an “ownership change” for purposes of Section 382 of the Internal Revenue Code of 1986 as a result of ordinary buying and selling of shares of its common stock. Following its review of the terms of the plan, the Board decided it was necessary and in the best interests of the Company and its stockholders to enter into the Restated Rights Plan. From 2013 through 2020, the Board and stockholders approved amendments providing for one-year extensions of the term of the Restated Rights Plan. On May 17, 2021, the Board unanimously approved the 2021 Tax Benefit Preservation Plan, which amended and restated the Restated Rights Plan with a term that expires on May 17, 2024.  The amendment was approved by the stockholders of the Company at the annual meeting of stockholders on November 4, 2021.

[0001564590-21-054929:notes:138]
[same as prior period, unchanged from 0001564590-21-021969:notes:137]

[0001564590-21-054929:notes:139]
The Compensation Committee of the Board unanimously approved an amendment to the Extreme Networks, Inc. Amended and Restated 2013 Equity Incentive Plan (the “2013 Plan”) on August 11, 2021 to update tax withholding obligations.  The Compensation Committee of the Board unanimously approved an amendment to the 2013 Plan on September 10, 2021 to increase the maximum number of available shares by 7.9 million shares, which amendment was approved by the stockholders at the Company’s annual meeting of stockholders held on November 4, 2021.

[0001564590-21-054929:notes:140]
[same as prior period, unchanged from 0001564590-21-021969:notes:139]

[0001564590-21-054929:notes:141]
The Compensation Committee of the Board unanimously approved an amendment to the 2014 Employee Stock Purchase Plan (the “ESPP”) on September 9, 2021 to increase the maximum number of shares that will be available for sale thereunder by 7.5 million shares.  The amendment was approved by the stockholders of the Company at the annual meeting of stockholders held on November 4, 2021.

[0001564590-21-054929:notes:142]
[same as prior period, unchanged from 0001564590-21-021969:notes:141]

[0001564590-21-054929:notes:143]
On November 2, 2018, the Company announced the Board had authorized management to repurchase up to $60.0 million of the Company’s common stock over a two-year period from the date of authorization. Purchases may be made from time to time through any means including, but not limited to, open market purchases and privately negotiated transactions. In February 2020, the Board increased the authorization to repurchase by $40.0 million to $100.0 million and extended the period for repurchase for three years from February 5, 2020. A maximum of $30.0 million of the Company’s common stock may be repurchased in any calendar year.

[0001564590-21-054929:notes:144]
There were no shares repurchased during the three months ended September 30, 2021 and 2020.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001564590-21-054929:notes:145]
[same as prior period, unchanged from 0001564590-21-021969:notes:145]

[0001564590-21-054929:notes:146]
[same as prior period, unchanged from 0001564590-21-021969:notes:146]

[0001564590-21-054929:notes:147]
[same as prior period, unchanged from 0001564590-21-021969:notes:147]

[0001564590-21-054929:notes:148]
|  |  | September 30, 2021 |  |  | June 30, 2021 |  |
| 2013 Equity Incentive Plan shares available for grant |  |  | 2,784 |  |  |  | 6,753 |  |
| Employee stock options and awards outstanding |  |  | 10,553 |  |  |  | 10,359 |  |
| 2014 Employee Stock Purchase Plan |  |  | 3,425 |  |  |  | 4,414 |  |
| Total shares reserved for issuance |  |  | 16,762 |  |  |  | 21,526 |  |

[0001564590-21-054929:notes:149]
[same as prior period, unchanged from 0001564590-21-021969:notes:149]

[0001564590-21-054929:notes:150]
Share-based compensation expense recognized in the condensed consolidated financial statements by line-item caption is as follows (in thousands):

[0001564590-21-054929:notes:151]
|  | Three Months Ended |  |
|  | September 30, 2021 |  |  | September 30, 2020 |  |
| Cost of product revenues | $ | 310 |  |  | $ | 258 |  |
| Cost of service and subscription revenues |  | 362 |  |  |  | 372 |  |
| Research and development |  | 2,458 |  |  |  | 2,272 |  |
| Sales and marketing |  | 3,575 |  |  |  | 2,647 |  |
| General and administrative |  | 3,739 |  |  |  | 2,753 |  |
| Total share-based compensation expense | $ | 10,444 |  |  | $ | 8,302 |  |

[0001564590-21-054929:notes:152]
[same as prior period, unchanged from 0001564590-21-021969:notes:152]

[0001564590-21-054929:notes:153]
The following table summarizes stock option activity for the three months ended September 30, 2021 (in thousands, except per share and contractual term):

[0001564590-21-054929:notes:154]
|  |  | Number of Shares |  |  | Weighted-Average Exercise Price Per Share |  |  | Weighted-Average Remaining Contractual Term (years) |  |  | Aggregate Intrinsic Value |  |
| Options outstanding at June 30, 2021 |  |  | 1,645 |  |  | $ | 5.44 |  |  |  | 3.62 |  |  | $ | 9,404 |  |
| Granted |  |  | — |  |  |  | — |  |  |  |  |  |  |  |  |  |
| Exercised |  |  | (80 | ) |  |  | 2.67 |  |  |  |  |  |  |  |  |  |
| Cancelled |  |  | — |  |  |  | — |  |  |  |  |  |  |  |  |  |
| Options outstanding at September 30, 2021 |  |  | 1,565 |  |  | $ | 5.58 |  |  |  | 3.52 |  |  | $ | 6,677 |  |
| Vested and expected to vest at September 30, 2021 |  |  | 1,565 |  |  | $ | 5.58 |  |  |  | 3.52 |  |  | $ | 6,677 |  |
| Exercisable at September 30, 2021 |  |  | 1,247 |  |  | $ | 5.29 |  |  |  | 3.16 |  |  | $ | 5,674 |  |

[0001564590-21-054929:notes:155]
The fair value of each stock option grant under the 2013 Plan is estimated on the date of grant using the Black-Scholes-Merton option valuation model. The expected term of options granted is derived from historical data on employee exercise and post-vesting employment termination behavior. The risk-free rate is based upon the estimated life of the option and the U.S. Treasury yield curve in effect at the time of grant. Expected volatility is based on the historical volatility on the Company’s stock. There were no stock options granted during the three months ended September 30, 2021 and 2020.

[0001564590-21-054929:notes:156]
[same as prior period, unchanged from 0001564590-21-021969:notes:156]

[0001564590-21-054929:notes:157]
Stock awards may be granted under the 2013 Plan on terms approved by the Compensation Committee of the Board. Stock awards generally provide for the issuance of restricted stock units (“RSUs”) including performance-condition or market-condition RSUs which vest over a fixed period of time or based upon the satisfaction of certain performance criteria or market conditions. The Company recognizes compensation expense on the awards over the vesting period based on the awards’ fair value as of the date of grant.  The Company does not estimate forfeitures, but accounts for them as incurred.

[0001564590-21-054929:notes:158]
The following table summarizes stock award activity for the three months ended September 30, 2021 (in thousands, except grant date fair value):

[0001564590-21-054929:notes:159]
|  |  | Number of Shares |  |  | Weighted- Average Grant Date Fair Value |  |  | Aggregate Fair Value |  |
| Non-vested stock awards outstanding at June 30, 2021 |  |  | 8,714 |  |  | $ | 5.51 |  |  |  |  |  |
| Granted |  |  | 3,611 |  |  |  | 11.37 |  |  |  |  |  |
| Released |  |  | (3,161 | ) |  |  | 5.17 |  |  |  |  |  |
| Cancelled |  |  | (176 | ) |  |  | 5.93 |  |  |  |  |  |
| Non-vested stock awards outstanding at September, 2021 |  |  | 8,988 |  |  | $ | 7.97 |  |  | $ | 88,534 |  |
| Stock awards expected to vest at September 30, 2021 |  |  | 8,988 |  |  | $ | 7.97 |  |  | $ | 88,534 |  |

[0001564590-21-054929:notes:160]
The RSU's granted under the 2013 plan vest over a period of time, generally one to three years, and are subject to participant's continued service to the Company. The stock awards granted during the three months ended September 30, 2021 included 0.9 million RSUs including the market condition awards discussed below to named executive officers and directors.

[0001564590-21-054929:notes:161]
Market Condition Awards

[0001564590-21-054929:notes:162]
During the three months ended September 30, 2021 and 2020, the Compensation Committee of the Board approved 0.7 million and 0.5 million RSUs, respectively, with vesting based on market conditions (“MSU”) to certain of the Company’s executive officers. These MSUs vest based on the Company’s total shareholder return (“TSR”) relative to the TSR of the Russell 2000 Index (“Index”).  The MSU award represents the right to receive a target number of shares of common stock up to 150% of the original grant. The MSUs vest based on the Company’s TSR relative to the TSR of the Index over performance periods of three years from the grant date, subject to the grantees’ continued service through the certification of performance.

[0001564590-21-054929:notes:163]
[same as prior period, unchanged from 0001564590-21-021969:notes:164]

[0001564590-21-054929:notes:164]
Total shareholder return is calculated based on the average closing price for the 30-trading days prior to the beginning and end of the performance periods. Performance is measured based on three periods, with the ability for up to one-third of target shares to vest after years 1 and 2 and the ability for up to the maximum of the full award to vest based on the full 3-year TSR less any shares vested based on 1- and 2-year periods. Linear interpolation is used to determine the number of shares vested for achievement between target levels.

[0001564590-21-054929:notes:165]
The grant date fair value of each MSU was determined using the Monte Carlo simulation model. The weighted-average grant-date fair value of these MSU granted during the three months ended September 30, 2021 was $12.69 per share. The assumptions used in the Monte-Carlo simulation included the expected volatility of 66%, risk-free rate of 0.44%, no expected dividend yield, expected term of 3 years and possible future stock prices over the performance period based on the historical stock and market prices. The Company recognizes the expense related to these MSUs on a graded-vesting method over the estimated term.

[0001564590-21-054929:notes:166]
The weighted-average grant-date fair value of these MSU granted during the three months ended September 30, 2020 was $5.32 per share. The assumptions used in the Monte Carlo simulation included the expected volatility of 69%, risk-free rate of 0.18%, no expected dividend yield, expected term of 3 years and possible future stock prices over the performance period based on the historical stock and market prices.

[0001564590-21-054929:notes:167]
The fair value of each share purchase option under the ESPP is estimated on the date of grant using the Black-Scholes-Merton option valuation model with the weighted average assumptions noted in the following table. The expected term of the ESPP represents the term of the offering period of each option.  The risk-free rate is based upon the estimated life and on the U.S. Treasury yield curve in effect at the time of grant.  Expected volatility is based on the historical volatility on the Company’s stock.

[0001564590-21-054929:notes:168]
There were 1.0 million and 1.5 million shares issued under the ESPP during the three months ended September 30, 2021 and 2020, respectively. The following assumptions were used to determine the grant-date fair values of the ESPP shares during the following periods:

[0001564590-21-054929:notes:169]
|  |  | Employee Stock Purchase Plan |  |  |
|  |  | Three Months Ended |  |  |
|  |  | September 30, 2021 |  |  | September 30, 2020 |  |  |
| Expected life |  | 0.5 years |  |  | 0.5 years |  |  |
| Risk-free interest rate |  |  | 0.05 | % |  |  | 0.12 | % |  |
| Volatility |  |  | 52 | % |  |  | 119 | % |  |
| Dividend yield |  |  | — | % |  |  | — | % |  |

[0001564590-21-054929:notes:170]
The weighted-average grant-date fair value of shares under the ESPP during the three months ended September 30, 2021 and 2020 was $3.18 and $2.23 per share, respectively.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001564590-21-054929:notes:171]
[same as prior period, unchanged from 0001564590-21-021969:notes:173]

[0001564590-21-054929:notes:172]
The Company operates in one segment, the development and marketing of network infrastructure equipment and related software. The Company conducts business globally and is managed geographically. Revenues are attributed to a geographical area based on the billing address of customers. The Company operates in three geographical areas: Americas, which includes the United States, Canada, Mexico, Central America and South America; EMEA, which includes Europe, Russia, Middle East and Africa; and APAC which includes Asia Pacific, South Asia, India, Australia and Japan. The Company’s chief operating decision maker, who is its CEO, reviews financial information presented on a consolidated basis for purposes of allocating resources and evaluating financial performance.

[0001564590-21-054929:notes:173]
See Note 3, Revenues, for the Company’s revenues by geographic regions and channel based on the customer’s billing address.

[0001564590-21-054929:notes:174]
[same as prior period, unchanged from 0001564590-21-021969:notes:176]

[0001564590-21-054929:notes:175]
| Long-lived Assets |  | September 30, 2021 |  |  | June 30, 2021 |  |
| Americas |  | $ | 161,956 |  |  | $ | 151,839 |  |
| EMEA |  |  | 22,486 |  |  |  | 25,940 |  |
| APAC |  |  | 12,383 |  |  |  | 13,560 |  |
| Total long-lived assets |  | $ | 196,825 |  |  | $ | 191,339 |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001564590-21-054929:notes:176]
[same as prior period, unchanged from 0001564590-21-021969:notes:178]

[0001564590-21-054929:notes:177]
[same as prior period, unchanged from 0001564590-21-021969:notes:179]

[0001564590-21-054929:notes:178]
[same as prior period, unchanged from 0001564590-21-021969:notes:180]

[0001564590-21-054929:notes:179]
At the inception date of the derivative contract, the Company performs an assessment of these contracts and has designated these contracts as cash flow hedges. Interest rate swaps designated as cash flow hedges involve the receipt of variable-rate amounts from a counterparty in exchange for the Company making fixed-rate payments over the life of the agreement without exchange of the underlying notional amount. The Company also formally assesses, both at the hedge’s inception and on an ongoing basis, by performing qualitative and quantitative assessment, whether the derivatives that are used in hedging transactions are highly effective in offsetting changes in cash flow of hedged items. Changes in the fair value of a derivative that is qualified, designated and highly effective as a cash flow hedge are recorded in other comprehensive income (loss). When it is determined that a derivative is not highly effective as a hedge or that it has ceased to be a highly effective hedge, the Company discontinues hedge accounting prospectively. In accordance with ASC 815 “Derivatives and Hedging,” the Company may prospectively discontinue the hedge accounting for an existing hedge if the applicable criteria are no longer met, the derivative instrument expires, is sold, terminated or exercised or if the Company removes the designation of the respective cash flow hedge. In those circumstances, the net gain or loss remains in accumulated other comprehensive loss and is reclassified into earnings in the same period or periods during which the hedged forecasted transaction affects earnings, unless the forecasted transaction is no longer probable in which case the net gain or loss is reclassified into earnings immediately.

[0001564590-21-054929:notes:180]
During fiscal 2020, the Company entered into multiple interest rate swap contracts, designated as cash flow hedges, to hedge the variability of cash flows in interest payments associated with the Company’s various tranches of floating-rate debt. As of September 30, 2021 and September 30, 2020, the total notional amount of these interest rate swaps was $200.0 million and had maturity dates through April 2023. As of September 30, 2021 and September 30, 2020, these contracts had unrealized losses of $0.9 million and $1.8 million, respectively, which are recorded in “Accumulated other comprehensive loss” with the associated liability in “Other accrued liabilities” in the condensed consolidated balance sheet. Cash flows associated with periodic settlements of interest rate swaps are classified as operating activities in the condensed consolidated statement of cash flows. Realized gains and losses are recognized as they accrue in interest expense. Amounts reported in accumulated other comprehensive loss related to these cash flow hedges are reclassified to interest expense over the life of the swap contracts. The Company estimates that $0.8 million will be reclassified to interest expense over the next twelve months. The classification and fair value of these cash flow hedges are discussed in Note 6, Fair Value Measurements.

[0001564590-21-054929:notes:181]
[same as prior period, unchanged from 0001564590-21-021969:notes:184]

[0001564590-21-054929:notes:182]
The Company uses derivative financial instruments to manage exposures to foreign currency that may or may not be designated as hedging instruments. The Company’s objective for holding derivatives is to use the most effective methods to minimize the impact

[0001564590-21-054929:notes:183]
of these exposures. The Company does not enter into derivatives for speculative or trading purposes. The Company enters into foreign exchange forward contracts primarily to mitigate the effect of gains and losses generated by foreign currency transactions related to certain operating expenses and re-measurement of certain assets and liabilities denominated in foreign currencies.

[0001564590-21-054929:notes:184]
For foreign exchange forward contracts not designated as hedging instruments, the fair value of the Company’s derivatives in a gain position are recorded in “Prepaid expenses and other current assets” and derivatives in a loss position are recorded in “Other accrued liabilities” in the accompanying condensed consolidated balance sheets. Changes in the fair value of derivatives are recorded in “Other income (expense), net” in the accompanying condensed consolidated statements of operations. As of September 30, 2021 and 2020, foreign exchange forward contracts not designated as hedging instruments had the total notional principal amount of $22.6 and $7.5 million, respectively. These contracts have maturities of 40 days or less. The net gains and losses recorded in the condensed consolidated statement of operations from these transactions during the three months ended September 30, 2021 and 2020 were losses of $0.2 million and gains of less than $0.1 million, respectively. Changes in the fair value of these foreign exchange forward contracts are offset largely by remeasurement of the underlying assets and liabilities

[0001564590-21-054929:notes:185]
For foreign exchange forward contracts designated as hedging instruments, gains and losses arising from these contracts are recorded as a component of accumulated other comprehensive income (loss) on the condensed consolidated balance sheets. The hedging gains and losses in accumulated other comprehensive income are subsequently reclassified to expenses, as applicable, in the condensed consolidated statements of operations in the same period in which the underlying transactions affect our earnings. As of September 30, 2021, foreign exchange forward contracts designated as hedging instruments had the notional amount of $11.3 million. These contracts have maturities of less than twelve months. As of September 30, 2021, these contracts had unrealized losses of $0.4 million which are recorded in accumulated other comprehensive income (loss) with the associated liability in other accrued liabilities in the accompanying consolidated balance sheets. There were no foreign exchange forward contracts at September 30, 2020 that were designated as hedging instruments.

[0001564590-21-054929:notes:186]
The Company recognized total foreign currency gains of $0.3 million and losses of $1.2 million for the three months ended September 30, 2021 and 2020, respectively related to the change in fair value of foreign currency denominated assets and liabilities.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001564590-21-054929:notes:187]
| 14. | Restructuring and Related Charges. |

[0001564590-21-054929:notes:188]
The Company recorded $0.3 million of restructuring and related charges during the three months ended September 30, 2021 which primarily included facility related charges of $0.3 million for the three months ended September 30, 2021. Severance and benefit restructuring charges consisted primarily of employee severance and benefit expenses incurred under the reduction-in-force action initiated in the third quarter of fiscal 2020 (the “2020 Plan”) to reduce operating costs and enhance financial flexibility as a result of disruptions caused by the COVID-19 global pandemic. With the reduction and realignment of the headcount under the 2020 Plan, the Company is relocating certain of its lab test equipment to third-party consulting companies. The Company has incurred $9.6 million of charges under the 2020 Plan through September 30, 2021. The Company expects to incur additional equipment related relocation expenses of $0.1 million and expects to substantially complete these activities by the first half of fiscal 2022. The facility restructuring charges included additional facilities expenses related to previously impaired facilities.

[0001564590-21-054929:notes:189]
The Company recorded $1.0 million of restructuring and related charges during the three months ended September 30, 2020. The charges included $0.3 million for charges related to facilities which the Company has exited, and $0.7 million for employee severance and benefit expenses incurred under the Company’s restructuring plans.

[0001564590-21-054929:notes:190]
Restructuring liabilities related to severance, benefits, and equipment relocation obligations are recorded in “Other accrued liabilities” in the accompanying condensed consolidated balance sheets. The following table summarizes the activity related to the severance, benefits, and equipment relocation liabilities during the three months ended September 30, 2021 (in thousands):

[0001564590-21-054929:notes:191]
|  |  | Three Months Ended |  |
|  |  | September 30, 2021 |  |  | September 30, 2020 |  |
|  |  | Severance and Other |  |
| Balance at beginning of period |  | $ | 271 |  |  | $ | 2,219 |  |
| Period charges |  |  | 8 |  |  |  | 772 |  |
| Period reversals |  |  | (30 | ) |  |  | (50 | ) |
| Period payments |  |  | (156 | ) |  |  | (2,639 | ) |
| Balance at end of period |  | $ | 93 |  |  | $ | 302 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0001564590-21-054929:notes:192]
[same as prior period, unchanged from 0001564590-21-021969:notes:193]

[0001564590-21-054929:notes:193]
For the three months ended September 30, 2021 and 2020, the Company recorded an income tax provision of $2.1 million and $1.3 million, respectively.

[0001564590-21-054929:notes:194]
The income tax provisions for the three months ended September 30, 2021 and 2020, consisted of (1) taxes on the income of the Company’s foreign subsidiaries, (2) foreign withholding taxes, (3) state taxes in jurisdictions where the Company has no remaining state net operating losses (“NOLs”) and (4) tax expense associated with the establishment of a U.S. deferred tax liability for amortizable goodwill resulting from the acquisition of Enterasys Networks, Inc., the wireless local area network business from Zebra Technologies Corporation, the Campus Fabric Business from Avaya and the Data Center Business from Brocade. The interim income tax provisions for the three months ended September 30, 2021 and 2020 were calculated using the discrete effective tax rate method as allowed by Accounting Standards Codification (“ASC”) 740-270-30-18, “Income Taxes – Interim Reporting.”  The discrete method is applied when the application of the estimated annual effective tax rate is impractical because it is not possible to reliably estimate the annual effective tax rate.  The discrete method treats the year to date period as if it was the annual period and determines the income tax expense or benefit on that basis.  The Company believes that, at this time, the use of this discrete method is more appropriate than the annual effective tax rate method as (i) the estimated annual effective tax rate method is not reliable due to the high degree of uncertainty in estimating annual pretax earnings on a jurisdictional basis and (ii) the Company’s ongoing assessment that the recoverability of certain U.S. and Irish deferred tax assets is not more likely than not.

[0001564590-21-054929:notes:195]
The Company has provided a full valuation allowance against all of its U.S. federal and state deferred tax assets as well as a portion of the deferred tax assets in Ireland. A valuation allowance is determined by assessing both negative and positive evidence to determine whether it is “more likely than not” that deferred tax assets are recoverable; such assessment is required on a jurisdiction-by-jurisdiction basis.  The Company's inconsistent earnings in recent periods, including a cumulative loss over the last three years, coupled with its difficulty in forecasting future revenue trends and the cyclical nature of its business represent sufficient negative evidence to require full valuation allowances against its U.S. federal and state net deferred tax assets as well as a portion of the deferred tax assets in Ireland.  These valuation allowances will be evaluated periodically and can be reversed partially or in whole if business results and the economic environment have sufficiently improved to support realization of some or all of the Company's deferred tax assets.

[0001564590-21-054929:notes:196]
On September 14, 2021, the Company completed its acquisition of Ipanema. This acquisition is treated as a non-taxable stock acquisition and therefore, Extreme will have carryover tax basis in the assets and liabilities acquired.

[0001564590-21-054929:notes:197]
The Company had $19.1 million of unrecognized tax benefits as of September 30, 2021.  If fully recognized in the future, $0.4 million would impact the effective tax rate and $18.7 million, would result in adjustments to deferred tax assets and corresponding adjustments to the valuation allowance with no impact to the effective tax rate.  The Company does not anticipate any events to occur during the next twelve months that would materially reduce the unrealized tax benefit as currently stated in the Company’s balance sheet.

[0001564590-21-054929:notes:198]
[same as prior period, unchanged from 0001564590-21-021969:notes:201]

[0001564590-21-054929:notes:199]
[same as prior period, unchanged from 0001564590-21-021969:notes:202]


## us-gaap:EarningsPerShareTextBlock

[0001564590-21-054929:notes:200]
[same as prior period, unchanged from 0001564590-21-021969:notes:203]

[0001564590-21-054929:notes:201]
[same as prior period, unchanged from 0001564590-21-021969:notes:204]

[0001564590-21-054929:notes:202]
[same as prior period, unchanged from 0001564590-21-021969:notes:205]

[0001564590-21-054929:notes:203]
|  |  | Three Months Ended |  |  |
|  |  | September 30, 2021 |  |  | September 30, 2020 |  |  |
| Net income (loss) |  | $ | 12,696 |  |  | $ | (8,812 | ) |  |
| Weighted-average shares used in per share calculation - basic |  |  | 128,324 |  |  |  | 121,705 |  |  |
| Options to purchase common stock |  |  | 651 |  |  |  | — |  |  |
| Restricted stock units |  |  | 4,250 |  |  |  | — |  |  |
| Employee Stock Purchase Plan shares |  |  | — |  |  |  | — |  |  |
| Weighted-average shares used in per share calculation - diluted |  |  | 133,225 |  |  |  | 121,705 |  |  |
| Net income (loss) per share - basic and diluted |  |  |  |  |  |  |  |  |  |
| Net income (loss) per share - basic |  | $ | 0.10 |  |  | $ | (0.07 | ) |  |
| Net income (loss) per share - diluted |  | $ | 0.10 |  |  | $ | (0.07 | ) |  |

[0001564590-21-054929:notes:204]
[same as prior period, unchanged from 0001564590-21-021969:notes:207]

[0001564590-21-054929:notes:205]
|  |  | Three Months Ended |  |
|  |  | September 30, 2021 |  |  | September 30, 2020 |  |
| Options to purchase common stock |  |  | — |  |  |  | 2,864 |  |
| Restricted stock units |  |  | 1,441 |  |  |  | 8,877 |  |
| Employee Stock Purchase Plan shares |  |  | 514 |  |  |  | 750 |  |
| Total shares excluded |  |  | 1,955 |  |  |  | 12,491 |  |
