# EXTR note change history — 0001564590-21-021969 → 0001564590-21-054929


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2021-11-05):
[0001564590-21-054929:note_history:1]
The Company currently has arrangements with contract manufacturers and suppliers for the manufacture of its products. Those arrangements allow the contract manufactures to procure long lead-time component inventory based upon a rolling production forecast provided by the Company. The Company is obligated to purchase long lead-time component inventory that its contract manufacturer procures in accordance with the forecast, unless the Company gives notice of order cancellation outside of applicable component lead-times. As of September 30, 2021, the Company had commitments to purchase $64.9 million of inventory.
  (was, 2021-04-29, similarity 0.9732):
[0001564590-21-021969:note_history:1]
The Company currently has arrangements with contract manufacturers and suppliers for the manufacture of its products. Those arrangements allow the contract manufactures to procure long lead-time component inventory based upon a rolling production forecast provided by the Company. The Company is obligated to purchase long lead-time component inventory that its contract manufacturer procures in accordance with the forecast, unless the Company gives notice of order cancellation outside of applicable component lead-times. As of March 31, 2021, the Company had commitments to purchase $33.0 million of inventory and other services.

- changed (2021-11-05):
[0001564590-21-054929:note_history:2]
In accordance with applicable accounting guidance, the Company records accruals for certain of its outstanding legal proceedings, investigations or claims when it is probable that a liability will be incurred, and the amount of loss can be reasonably estimated. The Company evaluates, at least on a quarterly basis, developments in legal proceedings, investigations or claims that could affect the amount of any accrual, as well as any developments that would result in a loss contingency to become both probable and reasonably estimable. When a loss contingency is not both probable and reasonably estimable, the Company does not record a loss accrual. However, if the loss (or an additional loss in excess of any prior accrual) is at least reasonably possible and material, then the Company would disclose an estimate of the possible loss or range of loss, if such estimate can be made, or disclose that an estimate cannot be made. The assessment whether a loss is probable or a reasonable possibility, and whether the loss or a range of loss is estimable, involves a series of complex judgments about future events. Even if a loss is reasonably possible, the Company may not be
  (was, 2021-04-29, similarity 0.7571):
[0001564590-21-021969:note_history:2]
In accordance with applicable accounting guidance, the Company records accruals for certain of its outstanding legal proceedings, investigations or claims when it is probable that a liability will be incurred, and the amount of loss can be reasonably estimated.  The Company evaluates, at least on a quarterly basis, developments in legal proceedings, investigations or claims that could affect the amount of any accrual, as well as any developments that would result in a loss contingency to become both probable and reasonably estimable.  When a loss contingency is not both probable and reasonably estimable, the Company does not record a loss accrual.  However, if the loss (or an additional loss in excess of any prior accrual) is at least a reasonable possibility and material,

- changed (2021-11-05):
[0001564590-21-054929:note_history:3]
able to estimate a range of possible loss, particularly where (i) the damages sought are substantial or indeterminate, (ii) the proceedings are in the early stages, or (iii) the matters involve novel or unsettled legal theories or a large number of parties. In such cases, there is considerable uncertainty regarding the ultimate resolution of such matters, including the amount of any possible loss, fine or penalty. An adverse resolution of one or more of such matters could have a material adverse effect on the Company's results of operations in a particular quarter or fiscal year.
  (was, 2021-04-29, similarity 0.6747):
[0001564590-21-021969:note_history:3]
then the Company would disclose an estimate of the possible loss or range of loss, if such estimate can be made, or disclose that an estimate cannot be made. The assessment whether a loss is probable or a reasonable possibility, and whether the loss or a range of loss is estimable, involves a series of complex judgments about future events.  Even if a loss is reasonably possible, the Company may not be able to estimate a range of possible loss, particularly where (i) the damages sought are substantial or indeterminate, (ii) the proceedings are in the early stages, or (iii) the matters involve novel or unsettled legal theories or a large number of parties. In such cases, there is considerable uncertainty regarding the ultimate resolution of such matters, including the amount of any possible loss, fine or penalty. An adverse resolution of one or more of such matters could have a material adverse effect on the Company's results of operations in a particular quarter or fiscal year.

- changed (2021-11-05):
[0001564590-21-054929:note_history:4]
XR Communications, LLC d/b/a Vivato Technologies v. Extreme Networks, Inc.
  (was, 2021-04-29, similarity 0.8555):
[0001564590-21-021969:note_history:4]
XR Communications, LLC d/b/a Vivato Technologies v. Extreme Networks, Inc. Patent Infringement Suit

- changed (2021-11-05):
[0001564590-21-054929:note_history:5]
On April 19, 2017, XR Communications, LLC (“XR”) (d/b/a Vivato Technologies) filed a patent infringement lawsuit against the Company in the Central District of California. The operative Second Amended Complaint asserts infringement of certain U.S. Patent based on the Company’s manufacture, use, sale, offer for sale, and/or importation into the United States of certain access points and routers supporting multi-user, multiple-input, multiple-output technology. XR seeks unspecified damages, on-going royalties, pre- and post-judgment interest, and attorneys’ fees. The stay issued by the District Court in 2018 has been lifted.
  (was, 2021-04-29, similarity 0.6378):
[0001564590-21-021969:note_history:5]
On April 19, 2017, XR Communications, LLC (“XR”) (d/b/a Vivato Technologies) filed a patent infringement lawsuit against the Company in the Central District of California. The operative Second Amended Complaint asserts infringement of U.S. Patent Nos. 7,062,296, 7,729,728, and 6,611,231 based on the Company’s manufacture, use, sale, offer for sale, and/or importation into the United States of certain access points and routers supporting multi-user, multiple-input, multiple-output technology. XR seeks unspecified damages, on-going royalties, pre- and post-judgment interest, and attorneys’ fees. In 2018, the Court stayed the case pending a resolution by the Patent Trial and Appeal Board (“PTAB”) of inter partes review (“IPR”) petitions filed by several defendants in other XR-related patent lawsuits challenging the validity of the asserted patents. The PTAB previously invalidated all asserted claims of the ’296 patent and ’728 patent and has found the challenged claims of the ’231 patent not invalid in view of the prior art asserted in the IPR instituted against that patent. The Federal Circuit Court ruled for XR on November 25, 2020 in Cisco’s appeal of the ‘231 PTAB decision, and the stay of the District Court case has been lifted.

- changed (2021-11-05):
[0001564590-21-054929:note_history:6]
On February 1, 2018, Orckit IP, LLC (“Orckit”) filed a patent infringement lawsuit against the Company and its Irish and German subsidiaries in the District Court in Dusseldorf, Germany. The lawsuit alleges direct and indirect infringement of the German portion of a patent (“EP ’364”) based on the offer, distribution, use, possession and/or importation into Germany of certain network switches that equipped with the ExtremeXOS operating system. Orckit is seeking injunctive relief, accounting, and an unspecified declaration of liability for damages and costs of the lawsuit. On January 28, 2020, the Court rendered a decision in the infringement case in favor of the Company. The matter is proceeding through the appellate process, and an oral hearing was held on October 21, 2021.  A decision is pending.
  (was, 2021-04-29, similarity 0.9052):
[0001564590-21-021969:note_history:6]
On February 1, 2018, Orckit IP, LLC (“Orckit”) filed a patent infringement lawsuit against the Company and its Irish and German subsidiaries in the District Court in Dusseldorf, Germany. The lawsuit alleges direct and indirect infringement of the German portion of European Patent EP 1 958 364 B1 (“EP ’364”) based on the offer, distribution, use, possession and/or importation into Germany of certain network switches that equipped with the ExtremeXOS operating system. Orckit is seeking injunctive relief, accounting, and an unspecified declaration of liability for damages and costs of the lawsuit. On January 28, 2020, the Court rendered a decision in the infringement case in favor of the Company. The matter is proceeding through the appellate process, pursuant to the appeal filed by Orckit on March 13, 2020.

- changed (2021-11-05):
[0001564590-21-054929:note_history:7]
On April 23, 2019, Orckit filed an extension of the patent infringement complaint against the Company and its Irish and German subsidiaries in the District Court in Dusseldorf, Germany. With this extension, Orckit alleges infringement of the German portion of a second patent (“EP ‘077”) based on the offer, distribution, use, possession and/or importation into Germany of certain network switches that the Company no longer sells in Germany. Orckit is seeking injunctive relief, accounting and sales information, and a declaration of liability for damages as well as costs of the lawsuit. On October 13, 2020, the Court issued an infringement decision against the Company and granted to Orckit the right to enforce the judgment against the Company, which Orckit has provided notification to the Company that it will enforce the judgment. The matter is proceeding through the appellate process.
  (was, 2021-04-29, similarity 0.8179):
[0001564590-21-021969:note_history:7]
On April 23, 2019, Orckit filed an extension of the patent infringement complaint against the Company and its Irish and German subsidiaries in the District Court in Dusseldorf, Germany. With this extension, Orckit alleges infringement of the German portion of European Patent EP 3 068 077 B1 (“EP ‘077”) based on the offer, distribution, use, possession and/or importation into Germany of certain network switches that the Company no longer sells in Germany. Orckit is seeking injunctive relief, accounting and sales information, and a declaration of liability for damages as well as costs of the lawsuit. On October 13, 2020, the Court issued an infringement decision against the Company and granted to Orckit the right to enforce an injunction against the Company. The Company filed a notice of appeal on November 12, 2020 and the matter is proceeding through the appellate process.

- changed (2021-11-05):
[0001564590-21-054929:note_history:8]
The Company filed a nullity action related to the EP ‘364 patent on May 3, 2018, and one related to the EP ‘077 patent on October 31, 2019, both in the Federal Patent Court in Munich. The court found the EP ‘364 patent to be valid and the Company is considering an appeal.  The case filed to seek to invalidate the EP ‘077 patent is proceeding.
  (was, 2021-04-29, similarity 0.6):
[0001564590-21-021969:note_history:8]
The Company filed a nullity action related to the EP ‘364 patent on May 3, 2018, and one related to the EP ‘077 patent on October 31, 2019. Both cases were filed in the Federal Patent Court in Munich and seek to invalidate the asserted patents. Both nullity actions are proceeding.

- changed (2021-11-05):
[0001564590-21-054929:note_history:9]
On October 26, 2020, SNMP Research, Inc. and SNMP Research International, Inc. (collectively, “SNMP”) filed a lawsuit against the Company in the Eastern District of Tennessee for copyright infringement, alleging that the Company was not properly licensed to use their software.  SNMP is seeking actual damages and profits attributed to the infringement, as well as equitable relief. The Company has filed a motion to dismiss and a motion to transfer the case to the Northern District of California. Both motions are pending. A trial date has been set for November 2022.
  (was, 2021-04-29, similarity 0.7612):
[0001564590-21-021969:note_history:9]
On October 26, 2020, SNMP Research, Inc. and SNMP Research International, Inc. (collectively, “SNMP”) filed a lawsuit against the Company in the Eastern District of Tennessee for copyright infringement, alleging that the Company was not properly licensed to use their software.  SNMP is seeking actual damages and profits attributed to the infringement, as well as equitable relief. The Company has filed a petition to transfer the case to the Northern District of California. This motion is pending.

- added (2021-11-05):
[0001564590-21-054929:note_history:10]
Mala Technologies Ltd. v. Extreme Networks GmbH, Extreme Networks Ireland Ops Ltd., and Extreme Networks, Inc.

- added (2021-11-05):
[0001564590-21-054929:note_history:11]
On April 15, 2021, Mala Technologies Ltd. (“Mala”) filed a patent infringement lawsuit against the Company and its Irish and German subsidiaries in the District Court in Dusseldorf, Germany.  The lawsuit alleges indirect infringement of the German portion of a patent (“EP ‘498”) based on the offer and sale in Germany of certain network switches equipped with the ExtremeXOS operating system.  Mala is seeking injunctive relief, accounting, and an unspecified declaration of liability for damages and costs of the lawsuit.  A hearing date has been set for July 14, 2022.  The Company filed a nullity action related to the EP’498 patent on September 24, 2021 in the German Federal Patent Court.

- changed (2021-11-05):
[0001564590-21-054929:note_history:12]
Subject to certain limitations, the Company may be obligated to indemnify its current and former directors, officers and employees. These obligations arise under the terms of its certificate of incorporation, its bylaws, applicable contracts, and applicable law. The obligation to indemnify, where applicable, generally means that the Company is required to pay or reimburse, and in certain circumstances the Company has paid or reimbursed, the individuals' reasonable legal expenses and possibly damages and other liabilities incurred in connection with certain legal matters. The Company also procures Directors and Officers liability insurance to
  (was, 2021-04-29, similarity 0.7159):
[0001564590-21-021969:note_history:12]
Subject to certain limitations, the Company may be obligated to indemnify its current and former directors, officers and employees. These obligations arise under the terms of its certificate of incorporation, its bylaws, applicable contracts, and applicable law. The obligation to indemnify, where applicable, generally means that the Company is required to pay or reimburse, and in certain circumstances the Company has paid or reimbursed, the individuals' reasonable legal expenses and possibly damages and other liabilities incurred in connection with certain legal matters. The Company also procures Directors and Officers liability insurance to help cover its defense and/or indemnification costs, although its ability to recover such costs through insurance is uncertain.  While it is not possible to estimate the maximum potential amount that could be owed under these governing documents and agreements due to the Company’s limited history with prior indemnification claims, indemnification (including defense) costs could, in the future, have a material adverse effect on the Company’s consolidated financial position, results of operations and cash flows.

- added (2021-11-05):
[0001564590-21-054929:note_history:13]
help cover its defense and/or indemnification costs, although its ability to recover such costs through insurance is uncertain.  While it is not possible to estimate the maximum potential amount that could be owed under these governing documents and agreements due to the Company’s limited history with prior indemnification claims, indemnification (including defense) costs could, in the future, have a material adverse effect on the Company’s consolidated financial position, results of operations and cash flows.

- removed (2021-11-05):
[0001564590-21-021969:note_history:14]
All currency conversions in this Legal Proceedings section are as of March 31, 2021.

- removed (2021-11-05):
[0001564590-21-021969:note_history:15]
Shenzhen Dunjun Technology Ltd. v. Aerohive Networks (Hangzhou) Ltd.; Aerohive Networks, Inc.; and Yunqing Information Technology (Shenzhen) Ltd.

- removed (2021-11-05):
[0001564590-21-021969:note_history:16]
On June 20, 2019, Shenzhen Dunjun Technology Ltd. filed a patent infringement lawsuit against Aerohive Networks, Inc. (“Aerohive”), a Chinese subsidiary of the Company, and Yunqing Information Technology (Shenzhen) Ltd. in the Shenzhen Intermediate People’s Court in China.  The lawsuit alleges infringement of a Chinese patent and seeks damages of RMB 10.0 million (USD $1.5 million). The parties have reached a tentative agreement to settle the matter for an immaterial amount.

- removed (2021-11-05):
[0001564590-21-021969:note_history:17]
DataCloud Technologies, LLC. v. Extreme Networks, Inc.

- removed (2021-11-05):
[0001564590-21-021969:note_history:18]
On June 5, 2020, DataCloud Technologies, LLC (“DataCloud”) filed a patent infringement lawsuit against the Company in the District of Delaware. The lawsuit alleges direct infringement of four U.S. patents. DataCloud seeks injunctive relief, monetary damages, interest, and attorneys’ fees. DataCloud amended the complaint on November 13, 2020, asserting claims of direct, induced, and willful infringement of four new patents, and filed a second amended complaint on February 12, 2021. The parties settled this case on March 31, 2021 for an immaterial amount and the matter was dismissed in the District Court on April 9, 2021.

- removed (2021-11-05):
[0001564590-21-021969:note_history:19]
Hanger Solutions, LLC v. Extreme Networks, Inc.

- removed (2021-11-05):
[0001564590-21-021969:note_history:20]
On January 14, 2021, Hanger Solutions, LLC (“Hanger”) filed a patent infringement lawsuit against the Company in the District of Delaware. The complaint alleges infringement of three U.S. patents. The parties settled this case on March 31, 2021 for an immaterial amount and the matter was dismissed in the District Court on April 12, 2021.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2021-11-05):
[0001564590-21-054929:note_history:21]
The unaudited condensed consolidated financial statements reflect all adjustments, consisting only of normal recurring adjustments that, in the opinion of management, are necessary for a fair presentation of the results of operations and cash flows for the interim periods presented and the financial condition of Extreme at September 30, 2021. The results of operations for the three months ended September 30, 2021 are not necessarily indicative of the results that may be expected for fiscal 2022 or any future periods.
  (was, 2021-04-29, similarity 0.6824):
[0001564590-21-021969:note_history:21]
The unaudited condensed consolidated financial statements reflect all adjustments, consisting only of normal recurring adjustments that, in the opinion of management, are necessary for a fair presentation of the results of operations and cash flows for the interim periods presented and the financial condition of Extreme at March 31, 2021. The results of operations for the three and nine months ended March 31, 2021 are not necessarily indicative of the results that may be expected for fiscal 2021 or any future periods.


## us-gaap:SignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2021-11-05):
[0001564590-21-054929:note_history:22]
In December 2019, the FASB issued ASU 2019-12, Income taxes – Simplifying the Accounting for Income Taxes (Topic 740), which reduces the complexity of accounting for income taxes including the removal of certain exceptions to the general principles of ASC 740, Income Taxes, and simplification in several other areas such as accounting for franchise tax (or similar tax) that is partially based on income. This standard is effective for fiscal years beginning after December 15, 2020, including interim periods within the fiscal year. The standard was adopted on July 1, 2021 and did not have a material impact on the Company’s financial statements upon adoption.
  (was, 2021-04-29, similarity 0.6581):
[0001564590-21-021969:note_history:22]
In December 2019, the FASB issued ASU 2019-12, Income taxes – Simplifying the Accounting for Income Taxes (Topic 740), which reduces the complexity of accounting for income taxes including the removal of certain exceptions to the general principles of ASC 740, Income Taxes, and simplification in several other areas such as accounting for franchise tax (or similar tax) that is partially based on income. This standard is effective for fiscal years beginning after December 15, 2020, including interim periods within the fiscal year, which is the Company’s fiscal year 2022, beginning on July 1, 2021. The Company is currently evaluating the impact the new standard will have on its consolidated financial statements and related disclosures but does not believe there will be a material impact on the Company’s financial statements outside of potentially the change to recognition of state income and franchise taxes under the new Accounting Standard.

- removed (2021-11-05):
[0001564590-21-021969:note_history:23]
In June 2016, the FASB issued ASU 2016-13, Financial Instruments—Credit Losses (Topic 326). The standard changes the methodology for measuring credit losses on financial instruments and the timing of when such losses are recorded. It replaces the existing incurred loss impairment model with an expected loss model. It also requires credit losses related to available-for-sale debt securities to be recognized as an allowance for credit losses rather than as a reduction to the carrying value of the securities. ASU 2016-13 was effective for fiscal years beginning after December 15, 2019.  The Company adopted the standard on July 1, 2020 and the impact of the adoption was not material to the Company's condensed consolidated financial statements as credit losses are not expected to be significant based on historical collection trends, the financial condition of payment partners, and external market factors.

- removed (2021-11-05):
[0001564590-21-021969:note_history:24]
In August 2018, the FASB issued ASU 2018-13, Fair Value Measurement (Topic 820), which removes, modifies and adds various disclosure requirements around the topic in order to clarify and improve the cost-benefit nature of disclosures. For example, disclosures around transfers between fair value hierarchy levels will be removed and further detail around changes in unrealized gains and losses for the period and unobservable inputs determining Level 3 fair value measurements will be added.  This standard was effective for fiscal years beginning after December 15, 2019, including interim periods within the fiscal year. The standard was adopted on July 1, 2020 and did not have a material impact on the Company’s financial statements upon adoption.

- removed (2021-11-05):
[0001564590-21-021969:note_history:25]
In August 2018, the FASB issued ASU 2018-15, Intangibles - Goodwill and Other - Internal-Use Software (Subtopic 350-40), which aligns the requirements for capitalizing implementation costs incurred in a service contract hosting arrangement with those of developing or obtaining internal-use software. This standard was effective for fiscal years beginning after December 15, 2019, including interim periods within the fiscal year. The standard was adopted on July 1, 2020 and did not have a material impact on the Company’s financial statements upon adoption.

- removed (2021-11-05):
[0001564590-21-021969:note_history:26]
Recently Issued Accounting Pronouncements


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2021-11-05):
[0001564590-21-054929:note_history:27]
|  |  | September 30, 2021 |  |  | June 30, 2021 |  |
| Current portion of long-term debt: |  |  |  |  |  |  |  |  |
| Term Loan |  | $ | 28,500 |  |  | $ | 26,125 |  |
| Less: unamortized debt issuance costs |  |  | (2,356 | ) |  |  | (2,404 | ) |
| Current portion of long-term debt |  | $ | 26,144 |  |  | $ | 23,721 |  |
| Long-term debt, less current portion: |  |  |  |  |  |  |  |  |
| Term Loan |  | $ | 301,500 |  |  | $ | 320,625 |  |
| Less: unamortized debt issuance costs |  |  | (4,121 | ) |  |  | (4,760 | ) |
| Total long-term debt, less current portion |  |  | 297,379 |  |  |  | 315,865 |  |
| Total debt |  | $ | 323,523 |  |  | $ | 339,586 |  |
  (was, 2021-04-29, similarity 0.9482):
[0001564590-21-021969:note_history:27]
|  |  | March 31, 2021 |  |  | June 30, 2020 |  |
| Current portion of long-term debt: |  |  |  |  |  |  |  |  |
| Term Loan |  | $ | 23,750 |  |  | $ | 19,000 |  |
| Less: unamortized debt issuance costs |  |  | (2,436 | ) |  |  | (2,484 | ) |
| Current portion of long-term debt |  | $ | 21,314 |  |  | $ | 16,516 |  |
| Long-term debt, less current portion: |  |  |  |  |  |  |  |  |
| Term Loan |  | $ | 327,750 |  |  | $ | 346,750 |  |
| Revolving Facility |  |  | — |  |  |  | 55,000 |  |
| Less: unamortized debt issuance costs |  |  | (5,348 | ) |  |  | (7,165 | ) |
| Total long-term debt, less current portion |  |  | 322,402 |  |  |  | 394,585 |  |
| Total debt |  | $ | 343,716 |  |  | $ | 411,101 |  |

- changed (2021-11-05):
[0001564590-21-054929:note_history:28]
In connection with the acquisition of Aerohive Networks, Inc., on August 9, 2019, the Company entered into an Amended and Restated Credit Agreement (the “2019 Credit Agreement”), by and among the Company, as borrower, several banks and other financial institutions as Lenders, BMO Harris Bank N.A., as an issuing lender and swingline lender, Silicon Valley Bank, as an Issuing Lender, and Bank of Montreal, as administrative agent and collateral agent for the Lenders.
  (was, 2021-04-29, similarity 0.9496):
[0001564590-21-021969:note_history:28]
In connection with the Acquisition discussed in Note 4, on August 9, 2019, the Company entered into an Amended and Restated Credit Agreement (the “2019 Credit Agreement”), by and among the Company, as borrower, several banks and other financial institutions as Lenders, BMO Harris Bank N.A., as an issuing lender and swingline lender, Silicon Valley Bank, as an Issuing Lender, and Bank of Montreal, as administrative agent and collateral agent for the Lenders.

- changed (2021-11-05):
[0001564590-21-054929:note_history:29]
On April 8, 2020, the Company entered into the first amendment to the 2019 Credit Agreement (the “First Amendment”) to waive certain terms and financial covenants of the 2019 Credit Agreement through July 31, 2020. On May 8, 2020, the Company entered into the second amendment to the 2019 Credit Agreement (the “Second Amendment”) which superseded the First Amendment and provided certain revised terms and financial covenants through March 31, 2021. Subsequent to March 31, 2021, the original terms and financial covenants under the 2019 Credit Agreement resumed in effect. The Second Amendment required the Company to maintain certain minimum cash requirement and certain financial metrics at the end of each fiscal quarter through March 31, 2021.
  (was, 2021-04-29, similarity 0.6144):
[0001564590-21-021969:note_history:29]
On April 8, 2020, the Company entered into the first amendment to the 2019 Credit Agreement (the “First Amendment”) to waive certain terms and financial covenants of the 2019 Credit Agreement through July 31, 2020. On May 8, 2020, the Company entered into the second amendment to the 2019 Credit Agreement (the “Second Amendment”) which supersedes the First Amendment

- added (2021-11-05):
[0001564590-21-054929:note_history:30]
Under the terms of the Second Amendment, the Company was not permitted to exceed $55.0 million in its outstanding balance under the 2019 Revolving Facility, the applicable margin for Eurodollar rate was 4.5%, and the Company was restricted from pursuing certain activities such as incurring additional debt, stock repurchases, making acquisitions or declaring a dividend, until the Company was in compliance with the original covenants of the 2019 Credit Agreement.

- changed (2021-11-05):
[0001564590-21-054929:note_history:31]
The Second Amendment provided for the Company to end the covenant Suspension Period early and revert to the covenants and interest rates per the original terms of the 2019 Credit Agreement dated August 9, 2019 by filing a Suspension Period Early Termination Notice and Covenant Certificate demonstrating compliance. For the twelve-month period ended March 31, 2021 the Company’s financial performance was in compliance with the original covenants defined in the 2019 Credit Agreement and as such the Company filed a Suspension Early Termination Notice and Covenant Certificate with the administration agent subsequent to filing our Form 10-Q for the quarterly period ended March 31, 2021. Returning to compliance with the covenants per the original terms of the 2019 Credit Agreement dated August 9, 2019 resulted in the Company’s Eurodollar loan spread decreasing from 4.5% during the suspension period to 2.75% and unused facility commitment fee decreasing from 0.4% to 0.35%, and the limitation on revolver borrowings being removed effective May 1, 2021 after filing of the certificate with the administrative agent.
  (was, 2021-04-29, similarity 0.6692):
[0001564590-21-021969:note_history:31]
The Second Amendment provides for the Company to end the covenant Suspension Period early and revert to the covenants and interest rates per the original terms of the 2019 Credit Agreement dated August 9, 2019 by filing a Suspension Period Early Termination Notice and Covenant Certificate demonstrating compliance. For the 12 month period ended March 31, 2021 the Company’s financial performance is in compliance with the original covenants defined in the 2019 Credit Agreement and as such the Company will file a Suspension Early Termination Notice and Covenant Certificate with the loan administration agent subsequent to filing our Form 10-Q for the quarterly period ended March 31, 2021. Returning to compliance will result in the Company’s Eurodollar loan spread to decrease from 4.5% suspension period rate, to 2.75% and unused facility commitment fee will decrease from 0.4% to 0.35%, and the limitation on revolver borrowings will be removed effective May 1, 2021 after filing of the certificate with the administrative agent.

- changed (2021-11-05):
[0001564590-21-054929:note_history:32]
Financing costs incurred in connection with obtaining long-term financing are deferred and amortized over the term of the related indebtedness or credit agreement. During the year ended June 30, 2020, the Company incurred $10.5 million of deferred financing costs in conjunction with the 2019 Credit Agreement and $1.5 million of deferred financing costs from the amendments, and continues to amortize $1.6 million of debt issuance costs as of August 9, 2019 that were associated with the previous facility. The interest rate as of September 30, 2021 was 2.4%. and as of September 30, 2020 was 4.9%.
  (was, 2021-04-29, similarity 0.958):
[0001564590-21-021969:note_history:32]
Financing costs incurred in connection with obtaining long-term financing are deferred and amortized over the term of the related indebtedness or credit agreement. During the year ended June 30, 2020, the Company incurred $10.5 million of deferred financing costs in conjunction with the 2019 Credit Agreement and $1.5 million of deferred financing costs from the amendments, and continues to amortize $1.6 million of debt issuance costs as of August 9, 2019 that were associated with the previous facility. The interest rate as of March 31, 2021 was 4.6%.

- changed (2021-11-05):
[0001564590-21-054929:note_history:33]
Amortization of deferred financing costs included in “Interest expense” in the accompanying condensed consolidated statements of operations totaled $0.8 million and $0.8 million for the three months ended September 30, 2021 and 2020
  (was, 2021-04-29, similarity 0.7791):
[0001564590-21-021969:note_history:33]
Amortization of deferred financing costs included in “Interest expense” in the accompanying condensed consolidated statements of operations totaled $0.7 million and $0.6 million for the three months ended March 31, 2021 and 2020, and totaled $2.3 million and $1.8 million for the nine months ended March 31, 2021 and 2020.

- changed (2021-11-05):
[0001564590-21-054929:note_history:34]
During the fiscal year ended June 30, 2021, the Company repaid $55.0 million against its 2019 Revolving Facility’s outstanding balance of $55.0 million and has no remaining outstanding balance at September 30, 2021. The Company has $60.2 million of availability under the 2019 Revolving Facility as of September 30, 2021. During the three months ended September 30, 2021, the Company made an additional payment of $12 million against its term loan facility.
  (was, 2021-04-29, similarity 0.6629):
[0001564590-21-021969:note_history:34]
During the six months ended December 31, 2020, the Company repaid $55.0 million against its 2019 Revolving Facility’s outstanding balance of $55.0 million and has no remaining outstanding balance at March 31, 2021. The Company has $55.0 million of availability under the 2019 Revolving Facility as of March 31, 2021.

- changed (2021-11-05):
[0001564590-21-054929:note_history:35]
The Company had $14.8 million of outstanding letters of credit as of September 30, 2021.
  (was, 2021-04-29, similarity 0.9351):
[0001564590-21-021969:note_history:35]
The Company had $14.8 million of outstanding letters of credit as of March 31, 2021.

- removed (2021-11-05):
[0001564590-21-021969:note_history:36]
and provides certain revised terms and financial covenants through March 31, 2021.  Subsequent to March 31, 2021, the original terms and financial covenants under the 2019 Credit Agreement will resume in effect. The Second Amendment requires the Company to maintain certain minimum cash requirements and certain financial metrics at the end of each fiscal quarter through March 31, 2021. Under the terms of the Second Amendment, the Company is not permitted to exceed $55.0 million in its outstanding balance under the 2019 Revolving Facility, the applicable margin for Eurodollar rate will be 4.5%, and the Company is restricted from pursuing certain activities such as incurring additional debt, stock repurchases, making acquisitions or declaring a dividend, until the Company is in compliance with the original covenants of the 2019 Credit Agreement.


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2021-11-05):
[0001564590-21-054929:note_history:37]
|  |  | September 30, 2021 |  |  | June 30, 2021 |  |
| Current portion of long-term debt: |  |  |  |  |  |  |  |  |
| Term Loan |  | $ | 28,500 |  |  | $ | 26,125 |  |
| Less: unamortized debt issuance costs |  |  | (2,356 | ) |  |  | (2,404 | ) |
| Current portion of long-term debt |  | $ | 26,144 |  |  | $ | 23,721 |  |
| Long-term debt, less current portion: |  |  |  |  |  |  |  |  |
| Term Loan |  | $ | 301,500 |  |  | $ | 320,625 |  |
| Less: unamortized debt issuance costs |  |  | (4,121 | ) |  |  | (4,760 | ) |
| Total long-term debt, less current portion |  |  | 297,379 |  |  |  | 315,865 |  |
| Total debt |  | $ | 323,523 |  |  | $ | 339,586 |  |
  (was, 2021-04-29, similarity 0.9482):
[0001564590-21-021969:note_history:37]
|  |  | March 31, 2021 |  |  | June 30, 2020 |  |
| Current portion of long-term debt: |  |  |  |  |  |  |  |  |
| Term Loan |  | $ | 23,750 |  |  | $ | 19,000 |  |
| Less: unamortized debt issuance costs |  |  | (2,436 | ) |  |  | (2,484 | ) |
| Current portion of long-term debt |  | $ | 21,314 |  |  | $ | 16,516 |  |
| Long-term debt, less current portion: |  |  |  |  |  |  |  |  |
| Term Loan |  | $ | 327,750 |  |  | $ | 346,750 |  |
| Revolving Facility |  |  | — |  |  |  | 55,000 |  |
| Less: unamortized debt issuance costs |  |  | (5,348 | ) |  |  | (7,165 | ) |
| Total long-term debt, less current portion |  |  | 322,402 |  |  |  | 394,585 |  |
| Total debt |  | $ | 343,716 |  |  | $ | 411,101 |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- added (2021-11-05):
[0001564590-21-054929:note_history:38]
The Company operates in three geographic regions: Americas, which includes the United States, Canada, Mexico, Central America and South America; EMEA, which includes Europe, Russia, Middle East and Africa; and APAC, which includes Asia Pacific, China, South Asia and Japan. The following table sets forth the Company’s revenues disaggregated by sales channel and geographic region based on the billing addresses of its customer’s (in thousands):

- changed (2021-11-05):
[0001564590-21-054929:note_history:39]
|  |  | Three Months Ended |  |
|  |  | September 30, 2021 |  |  | September 30, 2020 |  |
|  |  | Distributor |  | Direct |  | Total |  |  | Distributor |  | Direct |  | Total |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  | $ | 56,068 |  | $ | 67,331 |  | $ | 123,399 |  |  | $ | 60,670 |  | $ | 57,347 |  | $ | 118,017 |  |
| Other |  |  | 7,799 |  |  | 3,367 |  |  | 11,166 |  |  |  | 8,241 |  |  | 4,090 |  |  | 12,331 |  |
| Total Americas |  |  | 63,867 |  |  | 70,698 |  |  | 134,565 |  |  |  | 68,911 |  |  | 61,437 |  |  | 130,348 |  |
| EMEA |  |  | 77,898 |  |  | 35,731 |  |  | 113,629 |  |  |  | 47,529 |  |  | 33,576 |  |  | 81,105 |  |
| APAC |  |  | 4,335 |  |  | 15,155 |  |  | 19,490 |  |  |  | 5,051 |  |  | 19,298 |  |  | 24,349 |  |
| Total net revenues |  | $ | 146,100 |  | $ | 121,584 |  | $ | 267,684 |  |  | $ | 121,491 |  | $ | 114,311 |  | $ | 235,802 |  |
  (was, 2021-04-29, similarity 0.9634):
[0001564590-21-021969:note_history:39]
|  |  | Three Months Ended |  |
|  |  | March 31, 2021 |  |  | March 31, 2020 |  |
|  |  | Distributor |  | Direct |  | Total |  |  | Distributor |  | Direct |  | Total |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  | $ | 54,873 |  | $ | 62,172 |  | $ | 117,045 |  |  | $ | 38,666 |  | $ | 56,391 |  | $ | 95,057 |  |
| Other |  |  | 8,926 |  |  | 3,730 |  |  | 12,656 |  |  |  | 3,277 |  |  | 5,781 |  |  | 9,058 |  |
| Total Americas |  |  | 63,799 |  |  | 65,902 |  |  | 129,701 |  |  |  | 41,943 |  |  | 62,172 |  |  | 104,115 |  |
| EMEA |  |  | 65,210 |  |  | 34,127 |  |  | 99,337 |  |  |  | 49,979 |  |  | 33,630 |  |  | 83,609 |  |
| APAC |  |  | 3,569 |  |  | 20,793 |  |  | 24,362 |  |  |  | 3,242 |  |  | 18,553 |  |  | 21,795 |  |
| Total net revenues |  | $ | 132,578 |  | $ | 120,822 |  | $ | 253,400 |  |  | $ | 95,164 |  | $ | 114,355 |  | $ | 209,519 |  |

- added (2021-11-05):
[0001564590-21-054929:note_history:40]
For the three months ended September 30, 2021 the Company generated 11% of its revenues from the Netherlands and 10% of its revenues from the Germany. No other foreign country accounted for 10% or more of revenue for the three months ended September 30, 2021 or 2020.

- removed (2021-11-05):
[0001564590-21-021969:note_history:41]
The following table sets forth the Company’s revenues disaggregated by sales channel and geographic region based on the customer’s ship-to locations (in thousands):

- removed (2021-11-05):
[0001564590-21-021969:note_history:42]
|  |  | Nine Months Ended |  |
|  |  | March 31, 2021 |  |  | March 31, 2020 |  |
|  |  | Distributor |  | Direct |  | Total |  |  | Distributor |  | Direct |  | Total |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  | $ | 162,049 |  | $ | 178,263 |  | $ | 340,312 |  |  | $ | 168,755 |  | $ | 180,358 |  | $ | 349,113 |  |
| Other |  |  | 26,117 |  |  | 11,468 |  |  | 37,585 |  |  |  | 15,496 |  |  | 16,343 |  |  | 31,839 |  |
| Total Americas |  |  | 188,166 |  |  | 189,731 |  |  | 377,897 |  |  |  | 184,251 |  |  | 196,701 |  |  | 380,952 |  |
| EMEA |  |  | 182,341 |  |  | 101,923 |  |  | 284,264 |  |  |  | 173,825 |  |  | 107,521 |  |  | 281,346 |  |
| APAC |  |  | 11,413 |  |  | 57,756 |  |  | 69,169 |  |  |  | 18,362 |  |  | 51,837 |  |  | 70,199 |  |
| Total net revenues |  | $ | 381,920 |  | $ | 349,410 |  | $ | 731,330 |  |  | $ | 376,438 |  | $ | 356,059 |  | $ | 732,497 |  |

- removed (2021-11-05):
[0001564590-21-021969:note_history:43]
For the three months ended March 31, 2021 the Company reflected 11% of its revenues from the Netherlands. For the nine months ended March 31, 2021 the Company reflected 10% of its revenues from the Netherlands.  No other foreign country accounted for 10% or more of revenue for the three and nine months ended March 31, 2021 or 2020.


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- added (2021-11-05):
[0001564590-21-054929:note_history:44]
On September 30, 2021, the Company had $356.0 million of remaining performance obligations, which are primarily comprised of deferred maintenance and SaaS revenues.  The Company expects to recognize approximately 52 percent of its deferred revenue as revenue in fiscal 2022, an additional 25 percent in fiscal 2023 and 23 percent of the balance thereafter.

- changed (2021-11-05):
[0001564590-21-054929:note_history:45]
Revenue recognized for the three months ended September 30, 2021 and 2020 that was included in the deferred revenue balance at the beginning of each period was $73.4 million and $66.9 million, respectively.
  (was, 2021-04-29, similarity 0.6444):
[0001564590-21-021969:note_history:45]
Revenue recognized for the three months ended March 31, 2021 and 2020 that was included in the deferred revenue balance at the beginning of each period was $67.9 million and $64.3 million, respectively. Revenue recognized for the nine months ended March 31, 2021 and 2020 that was included in the deferred revenue balance at the beginning of each period was $158.7 million and $116.7 million, respectively.

- changed (2021-11-05):
[0001564590-21-054929:note_history:46]
Contract Costs. The Company recognizes the incremental costs of obtaining contracts as an expense when incurred if the amortization period of the assets that the Company otherwise would have recognized is one year or less.  Management expects that commission fees paid to sales representatives as a result of obtaining service contracts and contract renewals are recoverable and therefore the Company’s condensed consolidated balance sheets included capitalized balances in the amount of $13.5 million and $13.1 million at September 30, 2021 and June 30, 2021, respectively. Capitalized commission fees are amortized on a straight-line basis over the average period of service contracts of approximately three years, and are included in “Sales and marketing” in the accompanying condensed consolidated statements of operations. Amortization recognized during the three months ended September 30, 2021 and 2020, was $1.8 million and $1.2 million, respectively.
  (was, 2021-04-29, similarity 0.9276):
[0001564590-21-021969:note_history:46]
Contract Costs. The Company recognizes the incremental costs of obtaining contracts as an expense when incurred if the amortization period of the assets that the Company otherwise would have recognized is one year or less.  Management expects that commission fees paid to sales representatives as a result of obtaining service contracts and contract renewals are recoverable and therefore the Company’s condensed consolidated balance sheets included capitalized balances in the amount of $10.2 million and $8.1 million at March 31, 2021 and June 30, 2020, respectively. Capitalized commission fees are amortized on a straight-line basis over the average period of service contracts of approximately three years, and are included in “Sales and marketing” in the accompanying condensed consolidated statements of operations. Amortization recognized during the three months ended March 31, 2021 and 2020, was $1.4 million and $1.1 million, respectively. Amortization recognized during the nine months ended March 31, 2021 and 2020, was $3.9 million and $4.1 million, respectively.

- changed (2021-11-05):
[0001564590-21-054929:note_history:47]
Estimated Variable Consideration. There were no material changes in the current period to the estimated variable consideration for performance obligations, which were satisfied or partially satisfied during previous periods.
  (was, 2021-04-29, similarity 0.9978):
[0001564590-21-021969:note_history:47]
Estimated Variable Consideration. There were no material changes in the current period to the estimated variable consideration for performance obligations which were satisfied or partially satisfied during previous periods.

- added (2021-11-05):
[0001564590-21-054929:note_history:48]
The Company operates in three geographic regions: Americas, which includes the United States, Canada, Mexico, Central America and South America; EMEA, which includes Europe, Russia, Middle East and Africa; and APAC, which includes Asia Pacific, China, South Asia and Japan. The following table sets forth the Company’s revenues disaggregated by sales channel and geographic region based on the billing addresses of its customer’s (in thousands):

- changed (2021-11-05):
[0001564590-21-054929:note_history:49]
|  |  | Three Months Ended |  |
|  |  | September 30, 2021 |  |  | September 30, 2020 |  |
|  |  | Distributor |  | Direct |  | Total |  |  | Distributor |  | Direct |  | Total |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  | $ | 56,068 |  | $ | 67,331 |  | $ | 123,399 |  |  | $ | 60,670 |  | $ | 57,347 |  | $ | 118,017 |  |
| Other |  |  | 7,799 |  |  | 3,367 |  |  | 11,166 |  |  |  | 8,241 |  |  | 4,090 |  |  | 12,331 |  |
| Total Americas |  |  | 63,867 |  |  | 70,698 |  |  | 134,565 |  |  |  | 68,911 |  |  | 61,437 |  |  | 130,348 |  |
| EMEA |  |  | 77,898 |  |  | 35,731 |  |  | 113,629 |  |  |  | 47,529 |  |  | 33,576 |  |  | 81,105 |  |
| APAC |  |  | 4,335 |  |  | 15,155 |  |  | 19,490 |  |  |  | 5,051 |  |  | 19,298 |  |  | 24,349 |  |
| Total net revenues |  | $ | 146,100 |  | $ | 121,584 |  | $ | 267,684 |  |  | $ | 121,491 |  | $ | 114,311 |  | $ | 235,802 |  |
  (was, 2021-04-29, similarity 0.9634):
[0001564590-21-021969:note_history:49]
|  |  | Three Months Ended |  |
|  |  | March 31, 2021 |  |  | March 31, 2020 |  |
|  |  | Distributor |  | Direct |  | Total |  |  | Distributor |  | Direct |  | Total |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  | $ | 54,873 |  | $ | 62,172 |  | $ | 117,045 |  |  | $ | 38,666 |  | $ | 56,391 |  | $ | 95,057 |  |
| Other |  |  | 8,926 |  |  | 3,730 |  |  | 12,656 |  |  |  | 3,277 |  |  | 5,781 |  |  | 9,058 |  |
| Total Americas |  |  | 63,799 |  |  | 65,902 |  |  | 129,701 |  |  |  | 41,943 |  |  | 62,172 |  |  | 104,115 |  |
| EMEA |  |  | 65,210 |  |  | 34,127 |  |  | 99,337 |  |  |  | 49,979 |  |  | 33,630 |  |  | 83,609 |  |
| APAC |  |  | 3,569 |  |  | 20,793 |  |  | 24,362 |  |  |  | 3,242 |  |  | 18,553 |  |  | 21,795 |  |
| Total net revenues |  | $ | 132,578 |  | $ | 120,822 |  | $ | 253,400 |  |  | $ | 95,164 |  | $ | 114,355 |  | $ | 209,519 |  |

- added (2021-11-05):
[0001564590-21-054929:note_history:50]
For the three months ended September 30, 2021 the Company generated 11% of its revenues from the Netherlands and 10% of its revenues from the Germany. No other foreign country accounted for 10% or more of revenue for the three months ended September 30, 2021 or 2020.

- added (2021-11-05):
[0001564590-21-054929:note_history:51]
|  |  | Three Months Ended |  |
|  |  | September 30, 2021 |  |  | September 30, 2020 |  |
| Tech Data Corporation |  | 22% |  |  | 27% |  |
| Jenne Corporation |  | 14% |  |  | 15% |  |
| Westcon Group Inc. |  | 18% |  |  | 13% |  |

- changed (2021-11-05):
[0001564590-21-054929:note_history:52]
|  |  | September 30, 2021 |  |  | June 30, 2021 |  |
| Tech Data Corporation |  | 17% |  |  | 19% |  |
| Jenne Corporation |  | 22% |  |  | 24% |  |
  (was, 2021-04-29, similarity 0.6627):
[0001564590-21-021969:note_history:52]
|  |  | March 31, 2021 |  |  | June 30, 2020 |  |
| Tech Data Corporation |  | * |  |  | 23% |  |
| Jenne Corporation |  | 19% |  |  | 25% |  |
| Westcon Group Inc. |  | 16% |  |  | * |  |
| * Less than 10% of accounts receivable. |  |  |  |  |  |  |  |  |

- removed (2021-11-05):
[0001564590-21-021969:note_history:53]
On March 31, 2021, the Company had $318.4 million of remaining performance obligations, which are primarily comprised of deferred maintenance and SaaS revenues.  The Company expects to recognize approximately 22 percent of its deferred revenue as revenue in fiscal 2021, an additional 44 percent in fiscal 2022 and 34 percent of the balance thereafter.

- removed (2021-11-05):
[0001564590-21-021969:note_history:54]
The following table sets forth the Company’s revenues disaggregated by sales channel and geographic region based on the customer’s ship-to locations (in thousands):

- removed (2021-11-05):
[0001564590-21-021969:note_history:55]
|  |  | Nine Months Ended |  |
|  |  | March 31, 2021 |  |  | March 31, 2020 |  |
|  |  | Distributor |  | Direct |  | Total |  |  | Distributor |  | Direct |  | Total |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  | $ | 162,049 |  | $ | 178,263 |  | $ | 340,312 |  |  | $ | 168,755 |  | $ | 180,358 |  | $ | 349,113 |  |
| Other |  |  | 26,117 |  |  | 11,468 |  |  | 37,585 |  |  |  | 15,496 |  |  | 16,343 |  |  | 31,839 |  |
| Total Americas |  |  | 188,166 |  |  | 189,731 |  |  | 377,897 |  |  |  | 184,251 |  |  | 196,701 |  |  | 380,952 |  |
| EMEA |  |  | 182,341 |  |  | 101,923 |  |  | 284,264 |  |  |  | 173,825 |  |  | 107,521 |  |  | 281,346 |  |
| APAC |  |  | 11,413 |  |  | 57,756 |  |  | 69,169 |  |  |  | 18,362 |  |  | 51,837 |  |  | 70,199 |  |
| Total net revenues |  | $ | 381,920 |  | $ | 349,410 |  | $ | 731,330 |  |  | $ | 376,438 |  | $ | 356,059 |  | $ | 732,497 |  |

- removed (2021-11-05):
[0001564590-21-021969:note_history:56]
For the three months ended March 31, 2021 the Company reflected 11% of its revenues from the Netherlands. For the nine months ended March 31, 2021 the Company reflected 10% of its revenues from the Netherlands.  No other foreign country accounted for 10% or more of revenue for the three and nine months ended March 31, 2021 or 2020.

- removed (2021-11-05):
[0001564590-21-021969:note_history:57]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | March 31, 2021 |  |  | March 31, 2020 |  |  | March 31, 2021 |  |  | March 31, 2020 |  |
| Tech Data Corporation |  | 15% |  |  | 19% |  |  | 21% |  |  | 16% |  |
| Jenne Corporation |  | 16% |  |  | * |  |  | 14% |  |  | 13% |  |
| Westcon Group Inc. |  | 19% |  |  | 19% |  |  | 17% |  |  | 14% |  |
| * Less than 10% of revenue |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |


## us-gaap:RevenueRecognitionPolicyTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- added (2021-11-05):
[0001564590-21-054929:note_history:58]
On September 30, 2021, the Company had $356.0 million of remaining performance obligations, which are primarily comprised of deferred maintenance and SaaS revenues.  The Company expects to recognize approximately 52 percent of its deferred revenue as revenue in fiscal 2022, an additional 25 percent in fiscal 2023 and 23 percent of the balance thereafter.

- changed (2021-11-05):
[0001564590-21-054929:note_history:59]
Revenue recognized for the three months ended September 30, 2021 and 2020 that was included in the deferred revenue balance at the beginning of each period was $73.4 million and $66.9 million, respectively.
  (was, 2021-04-29, similarity 0.6444):
[0001564590-21-021969:note_history:59]
Revenue recognized for the three months ended March 31, 2021 and 2020 that was included in the deferred revenue balance at the beginning of each period was $67.9 million and $64.3 million, respectively. Revenue recognized for the nine months ended March 31, 2021 and 2020 that was included in the deferred revenue balance at the beginning of each period was $158.7 million and $116.7 million, respectively.

- changed (2021-11-05):
[0001564590-21-054929:note_history:60]
Contract Costs. The Company recognizes the incremental costs of obtaining contracts as an expense when incurred if the amortization period of the assets that the Company otherwise would have recognized is one year or less.  Management expects that commission fees paid to sales representatives as a result of obtaining service contracts and contract renewals are recoverable and therefore the Company’s condensed consolidated balance sheets included capitalized balances in the amount of $13.5 million and $13.1 million at September 30, 2021 and June 30, 2021, respectively. Capitalized commission fees are amortized on a straight-line basis over the average period of service contracts of approximately three years, and are included in “Sales and marketing” in the accompanying condensed consolidated statements of operations. Amortization recognized during the three months ended September 30, 2021 and 2020, was $1.8 million and $1.2 million, respectively.
  (was, 2021-04-29, similarity 0.9276):
[0001564590-21-021969:note_history:60]
Contract Costs. The Company recognizes the incremental costs of obtaining contracts as an expense when incurred if the amortization period of the assets that the Company otherwise would have recognized is one year or less.  Management expects that commission fees paid to sales representatives as a result of obtaining service contracts and contract renewals are recoverable and therefore the Company’s condensed consolidated balance sheets included capitalized balances in the amount of $10.2 million and $8.1 million at March 31, 2021 and June 30, 2020, respectively. Capitalized commission fees are amortized on a straight-line basis over the average period of service contracts of approximately three years, and are included in “Sales and marketing” in the accompanying condensed consolidated statements of operations. Amortization recognized during the three months ended March 31, 2021 and 2020, was $1.4 million and $1.1 million, respectively. Amortization recognized during the nine months ended March 31, 2021 and 2020, was $3.9 million and $4.1 million, respectively.

- changed (2021-11-05):
[0001564590-21-054929:note_history:61]
Estimated Variable Consideration. There were no material changes in the current period to the estimated variable consideration for performance obligations, which were satisfied or partially satisfied during previous periods.
  (was, 2021-04-29, similarity 0.9978):
[0001564590-21-021969:note_history:61]
Estimated Variable Consideration. There were no material changes in the current period to the estimated variable consideration for performance obligations which were satisfied or partially satisfied during previous periods.

- added (2021-11-05):
[0001564590-21-054929:note_history:62]
The Company operates in three geographic regions: Americas, which includes the United States, Canada, Mexico, Central America and South America; EMEA, which includes Europe, Russia, Middle East and Africa; and APAC, which includes Asia Pacific, China, South Asia and Japan. The following table sets forth the Company’s revenues disaggregated by sales channel and geographic region based on the billing addresses of its customer’s (in thousands):

- changed (2021-11-05):
[0001564590-21-054929:note_history:63]
|  |  | Three Months Ended |  |
|  |  | September 30, 2021 |  |  | September 30, 2020 |  |
|  |  | Distributor |  | Direct |  | Total |  |  | Distributor |  | Direct |  | Total |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  | $ | 56,068 |  | $ | 67,331 |  | $ | 123,399 |  |  | $ | 60,670 |  | $ | 57,347 |  | $ | 118,017 |  |
| Other |  |  | 7,799 |  |  | 3,367 |  |  | 11,166 |  |  |  | 8,241 |  |  | 4,090 |  |  | 12,331 |  |
| Total Americas |  |  | 63,867 |  |  | 70,698 |  |  | 134,565 |  |  |  | 68,911 |  |  | 61,437 |  |  | 130,348 |  |
| EMEA |  |  | 77,898 |  |  | 35,731 |  |  | 113,629 |  |  |  | 47,529 |  |  | 33,576 |  |  | 81,105 |  |
| APAC |  |  | 4,335 |  |  | 15,155 |  |  | 19,490 |  |  |  | 5,051 |  |  | 19,298 |  |  | 24,349 |  |
| Total net revenues |  | $ | 146,100 |  | $ | 121,584 |  | $ | 267,684 |  |  | $ | 121,491 |  | $ | 114,311 |  | $ | 235,802 |  |
  (was, 2021-04-29, similarity 0.9634):
[0001564590-21-021969:note_history:63]
|  |  | Three Months Ended |  |
|  |  | March 31, 2021 |  |  | March 31, 2020 |  |
|  |  | Distributor |  | Direct |  | Total |  |  | Distributor |  | Direct |  | Total |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  | $ | 54,873 |  | $ | 62,172 |  | $ | 117,045 |  |  | $ | 38,666 |  | $ | 56,391 |  | $ | 95,057 |  |
| Other |  |  | 8,926 |  |  | 3,730 |  |  | 12,656 |  |  |  | 3,277 |  |  | 5,781 |  |  | 9,058 |  |
| Total Americas |  |  | 63,799 |  |  | 65,902 |  |  | 129,701 |  |  |  | 41,943 |  |  | 62,172 |  |  | 104,115 |  |
| EMEA |  |  | 65,210 |  |  | 34,127 |  |  | 99,337 |  |  |  | 49,979 |  |  | 33,630 |  |  | 83,609 |  |
| APAC |  |  | 3,569 |  |  | 20,793 |  |  | 24,362 |  |  |  | 3,242 |  |  | 18,553 |  |  | 21,795 |  |
| Total net revenues |  | $ | 132,578 |  | $ | 120,822 |  | $ | 253,400 |  |  | $ | 95,164 |  | $ | 114,355 |  | $ | 209,519 |  |

- added (2021-11-05):
[0001564590-21-054929:note_history:64]
For the three months ended September 30, 2021 the Company generated 11% of its revenues from the Netherlands and 10% of its revenues from the Germany. No other foreign country accounted for 10% or more of revenue for the three months ended September 30, 2021 or 2020.

- removed (2021-11-05):
[0001564590-21-021969:note_history:65]
On March 31, 2021, the Company had $318.4 million of remaining performance obligations, which are primarily comprised of deferred maintenance and SaaS revenues.  The Company expects to recognize approximately 22 percent of its deferred revenue as revenue in fiscal 2021, an additional 44 percent in fiscal 2022 and 34 percent of the balance thereafter.

- removed (2021-11-05):
[0001564590-21-021969:note_history:66]
The following table sets forth the Company’s revenues disaggregated by sales channel and geographic region based on the customer’s ship-to locations (in thousands):

- removed (2021-11-05):
[0001564590-21-021969:note_history:67]
|  |  | Nine Months Ended |  |
|  |  | March 31, 2021 |  |  | March 31, 2020 |  |
|  |  | Distributor |  | Direct |  | Total |  |  | Distributor |  | Direct |  | Total |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  | $ | 162,049 |  | $ | 178,263 |  | $ | 340,312 |  |  | $ | 168,755 |  | $ | 180,358 |  | $ | 349,113 |  |
| Other |  |  | 26,117 |  |  | 11,468 |  |  | 37,585 |  |  |  | 15,496 |  |  | 16,343 |  |  | 31,839 |  |
| Total Americas |  |  | 188,166 |  |  | 189,731 |  |  | 377,897 |  |  |  | 184,251 |  |  | 196,701 |  |  | 380,952 |  |
| EMEA |  |  | 182,341 |  |  | 101,923 |  |  | 284,264 |  |  |  | 173,825 |  |  | 107,521 |  |  | 281,346 |  |
| APAC |  |  | 11,413 |  |  | 57,756 |  |  | 69,169 |  |  |  | 18,362 |  |  | 51,837 |  |  | 70,199 |  |
| Total net revenues |  | $ | 381,920 |  | $ | 349,410 |  | $ | 731,330 |  |  | $ | 376,438 |  | $ | 356,059 |  | $ | 732,497 |  |

- removed (2021-11-05):
[0001564590-21-021969:note_history:68]
For the three months ended March 31, 2021 the Company reflected 11% of its revenues from the Netherlands. For the nine months ended March 31, 2021 the Company reflected 10% of its revenues from the Netherlands.  No other foreign country accounted for 10% or more of revenue for the three and nine months ended March 31, 2021 or 2020.
