# EXTR notes — 0001564590-22-003010


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0001564590-22-003010:notes:1]
[same as prior period, unchanged from 0001564590-21-054929:notes:1]

[0001564590-22-003010:notes:2]
[same as prior period, unchanged from 0001564590-21-054929:notes:2]

[0001564590-22-003010:notes:3]
The unaudited condensed consolidated financial statements of Extreme included herein have been prepared under the rules and regulations of the Securities and Exchange Commission (“SEC”).  Certain information and footnote disclosures normally included in financial statements prepared in accordance with U.S. generally accepted accounting principles have been condensed or omitted under such rules and regulations.  The condensed consolidated balance sheets at June 30, 2021 was derived from audited financial statements as of that date but does not include all disclosures required by generally accepted accounting principles for complete financial statements. These interim financial statements and notes should be read in conjunction with the Company’s audited consolidated financial statements and notes thereto included in the Company’s Annual Report on Form 10-K for the fiscal year ended June 30, 2021.

[0001564590-22-003010:notes:4]
The unaudited condensed consolidated financial statements reflect all adjustments, consisting only of normal recurring adjustments that, in the opinion of management, are necessary for a fair presentation of the results of operations and cash flows for the interim periods presented and the financial condition of Extreme at December 31, 2021. The results of operations for the three and six months ended December 31, 2021 are not necessarily indicative of the results that may be expected for fiscal 2022 or any future periods.

[0001564590-22-003010:notes:5]
[same as prior period, unchanged from 0001564590-21-054929:notes:5]

[0001564590-22-003010:notes:6]
[same as prior period, unchanged from 0001564590-21-054929:notes:6]

[0001564590-22-003010:notes:7]
[same as prior period, unchanged from 0001564590-21-054929:notes:7]

[0001564590-22-003010:notes:8]
[same as prior period, unchanged from 0001564590-21-054929:notes:8]

[0001564590-22-003010:notes:9]
[same as prior period, unchanged from 0001564590-21-054929:notes:9]

[0001564590-22-003010:notes:10]
[same as prior period, unchanged from 0001564590-21-054929:notes:10]

[0001564590-22-003010:notes:11]
[same as prior period, unchanged from 0001564590-21-054929:notes:11]


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001564590-22-003010:notes:12]
[same as prior period, unchanged from 0001564590-21-054929:notes:12]

[0001564590-22-003010:notes:13]
[same as prior period, unchanged from 0001564590-21-054929:notes:13]

[0001564590-22-003010:notes:14]
Recently Adopted Accounting Pronouncements

[0001564590-22-003010:notes:15]
In December 2019, the Financial Accounting Standards Board (“the FASB”) issued ASU 2019-12, Income Taxes – Simplifying the Accounting for Income Taxes (Topic 740), which reduces the complexity of accounting for income taxes including the removal of certain exceptions to the general principles of Accounting Standards Codification (“ASC”) 740, Income Taxes, and simplification in several other areas such as accounting for franchise tax (or similar tax) that is partially based on income. This standard is effective for fiscal years beginning after December 15, 2020, including interim periods within the fiscal year. The standard was adopted on July 1, 2021 and did not have a material impact on the Company’s financial statements upon adoption.

[0001564590-22-003010:notes:16]
Recently Issued and Adopted Accounting Pronouncements

[0001564590-22-003010:notes:17]
In October 2021, the FASB issued ASU 2021-08, Business Combinations (Topic 805): Accounting for Contract Assets and Contract Liabilities from Contracts with Customers, which requires contract assets and contract liabilities acquired in a business combination to be recognized and measured by the acquirer on the acquisition date in accordance with ASC 606, Revenue from Contracts with Customers, as if it had originated the contracts. Under the current business combinations guidance, such assets and liabilities are recognized by the acquirer at fair value on the acquisition date. ASU 2021-08 is effective for annual periods beginning after December 15, 2022 and interim periods within those annual periods, with early adoption permitted, including adoption in an interim period. The Company has elected to early adopt the standard in the quarter ended December 31, 2021 and retrospectively applied the standard to the acquisition that happened in the current fiscal year beginning July 1, 2021. The application of the guidance increased the deferred revenue balance acquired through the acquisition of Ipanema by $7.1 million as of the acquisition date.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001564590-22-003010:notes:18]
[same as prior period, unchanged from 0001564590-21-054929:notes:16]

[0001564590-22-003010:notes:19]
The Company accounts for revenues in accordance with ASU 2014-09, Revenue from Contracts from Customers (Topic 606).  The Company derives the majority of its revenues from sales of its networking equipment, with the remaining revenues generated from sales of services and subscriptions, which primarily includes maintenance contracts and software subscriptions delivered as software as a service (“SaaS”) and additional revenues from professional services, and training for its products. The Company sells its products, maintenance contracts and SaaS direct to customers and to partners in two distribution channels, or tiers. The first tier consists of a limited number of independent distributors that stock its products and sell primarily to resellers.  The second tier of the distribution channel consists of non-stocking distributors and value-added resellers that sell directly to end-users.  Products and services may be sold separately or in bundled packages.

[0001564590-22-003010:notes:20]
[same as prior period, unchanged from 0001564590-21-054929:notes:18]

[0001564590-22-003010:notes:21]
Performance Obligations. A performance obligation is a promise in a contract to transfer a distinct good or service to the customer and is the unit of account in Topic 606. A contract’s transaction price is allocated to each distinct performance obligation and recognized as revenue when, or as, the performance obligation is satisfied.  Certain of the Company’s contracts have multiple performance obligations, as the promise to transfer individual goods or services is separately identifiable from other promises in the contracts and, therefore, is distinct.  For contracts with multiple performance obligations, the Company allocates the contract’s transaction price to each performance obligation based on its relative standalone selling price. The stand-alone selling prices are determined based on the prices at which the Company separately sells these products. For items that are not sold separately, the Company estimates the stand-alone selling prices using other observable inputs.

[0001564590-22-003010:notes:22]
[same as prior period, unchanged from 0001564590-21-054929:notes:20]

[0001564590-22-003010:notes:23]
On December 31, 2021, the Company had $373.2 million of remaining performance obligations, which are primarily comprised of deferred maintenance and SaaS revenues. The Company expects to recognize approximately 38% of its deferred revenue as revenue in fiscal 2022, an additional 34% in fiscal 2023 and 28% of the balance thereafter.

[0001564590-22-003010:notes:24]
Contract Balances. The timing of revenue recognition, billings and cash collections results in billed accounts receivable and deferred revenue in the condensed consolidated balance sheets. Services provided under renewable support arrangements of the Company are billed in accordance with agreed-upon contractual terms, which are either billed fully at the inception of contract or at periodic intervals (e.g., quarterly or annually).  The Company sometimes receives payments from its customers in advance of services being provided, resulting in deferred revenues. These liabilities are reported on the condensed consolidated balance sheets on a contract-by-contract basis at the end of each reporting period.

[0001564590-22-003010:notes:25]
Revenue recognized for the three months ended December 31, 2021 and 2020 that was included in the deferred revenue balance at the beginning of each period was $81.9 million and $68.8 million, respectively. Revenue recognized for the six months ended December 31, 2021 and 2020 that was included in the deferred revenue balance at the beginning of each period was $132.5 million and $120.5 million, respectively.

[0001564590-22-003010:notes:26]
Contract Costs. The Company recognizes the incremental costs of obtaining contracts as an expense when incurred if the amortization period of the assets that the Company otherwise would have recognized is one year or less.  Management expects that commission fees paid to sales representatives as a result of obtaining service contracts and contract renewals are recoverable and therefore the Company’s condensed consolidated balance sheets included capitalized balances in the amount of $14.2 million and $13.1 million at December 31, 2021 and June 30, 2021, respectively. Capitalized commission fees are amortized on a straight-line basis over the average period of service contracts of approximately three years, and are included in “Sales and marketing” in the accompanying condensed consolidated statements of operations. Amortization recognized during the three months ended December 31, 2021 and 2020, was $1.8 million and $1.2 million, respectively. Amortization recognized during the six months ended December 31, 2021 and 2020, was $3.6 million and $2.5 million, respectively.

[0001564590-22-003010:notes:27]
[same as prior period, unchanged from 0001564590-21-054929:notes:25]

[0001564590-22-003010:notes:28]
[same as prior period, unchanged from 0001564590-21-054929:notes:26]

[0001564590-22-003010:notes:29]
The Company operates in three geographic regions: Americas, which includes the United States, Canada, Mexico, Central America and South America; EMEA, which includes Europe, Russia, Middle East and Africa; and APAC, which includes Asia Pacific, China, South Asia and Japan. The following table sets forth the Company’s revenues disaggregated by sales channel and geographic region based on the billing addresses of its customers (in thousands):

[0001564590-22-003010:notes:30]
|  |  | Three Months Ended |  |
|  |  | December 31, 2021 |  |  | December 31, 2020 |  |
|  |  | Distributor |  | Direct |  | Total |  |  | Distributor |  | Direct |  | Total |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  | $ | 68,565 |  | $ | 68,585 |  | $ | 137,150 |  |  | $ | 46,506 |  | $ | 58,744 |  | $ | 105,250 |  |
| Other |  |  | 3,865 |  |  | 4,955 |  |  | 8,820 |  |  |  | 8,950 |  |  | 3,648 |  |  | 12,598 |  |
| Total Americas |  |  | 72,430 |  |  | 73,540 |  |  | 145,970 |  |  |  | 55,456 |  |  | 62,392 |  |  | 117,848 |  |
| EMEA |  |  | 68,934 |  |  | 42,128 |  |  | 111,062 |  |  |  | 69,602 |  |  | 34,220 |  |  | 103,822 |  |
| APAC |  |  | 5,034 |  |  | 18,867 |  |  | 23,901 |  |  |  | 2,793 |  |  | 17,665 |  |  | 20,458 |  |
| Total net revenues |  | $ | 146,398 |  | $ | 134,535 |  | $ | 280,933 |  |  | $ | 127,851 |  | $ | 114,277 |  | $ | 242,128 |  |

[0001564590-22-003010:notes:31]
|  |  | Six Months Ended |  |
|  |  | December 31, 2021 |  |  | December 31, 2020 |  |
|  |  | Distributor |  | Direct |  | Total |  |  | Distributor |  | Direct |  | Total |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  | $ | 124,633 |  | $ | 135,916 |  | $ | 260,549 |  |  | $ | 107,176 |  | $ | 116,091 |  | $ | 223,267 |  |
| Other |  |  | 11,664 |  |  | 8,322 |  |  | 19,986 |  |  |  | 17,191 |  |  | 7,738 |  |  | 24,929 |  |
| Total Americas |  |  | 136,297 |  |  | 144,238 |  |  | 280,535 |  |  |  | 124,367 |  |  | 123,829 |  |  | 248,196 |  |
| EMEA |  |  | 146,832 |  |  | 77,859 |  |  | 224,691 |  |  |  | 117,131 |  |  | 67,796 |  |  | 184,927 |  |
| APAC |  |  | 9,369 |  |  | 34,022 |  |  | 43,391 |  |  |  | 7,844 |  |  | 36,963 |  |  | 44,807 |  |
| Total net revenues |  | $ | 292,498 |  | $ | 256,119 |  | $ | 548,617 |  |  | $ | 249,342 |  | $ | 228,588 |  | $ | 477,930 |  |

[0001564590-22-003010:notes:32]
For the six months ended December 31, 2021, the Company generated 10% of its revenues from the Netherlands. For the three months ended December 31, 2020, the Company generated 11% of its revenues from the Netherlands and 11% of its revenues from Germany. For the six months ended December 31, 2020, the Company generated 10% of its revenues from the Netherlands and 10% of its revenues from Germany. No other foreign country accounted for 10% or more of revenue for the three and six months ended December 31, 2021 or 2020.

[0001564590-22-003010:notes:33]
[same as prior period, unchanged from 0001564590-21-054929:notes:30]

[0001564590-22-003010:notes:34]
[same as prior period, unchanged from 0001564590-21-054929:notes:31]

[0001564590-22-003010:notes:35]
[same as prior period, unchanged from 0001564590-21-054929:notes:32]

[0001564590-22-003010:notes:36]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | December 31, 2021 |  |  | December 31, 2020 |  |  | December 31, 2021 |  |  | December 31, 2020 |  |
| TD Synnex Corporation |  | 21% |  |  | 21% |  |  | 22% |  |  | 24% |  |
| Jenne Corporation |  | 18% |  |  | 11% |  |  | 16% |  |  | 13% |  |
| Westcon Group Inc. |  | 11% |  |  | 19% |  |  | 15% |  |  | 16% |  |

[0001564590-22-003010:notes:37]
[same as prior period, unchanged from 0001564590-21-054929:notes:34]

[0001564590-22-003010:notes:38]
|  |  | December 31, 2021 |  |  | June 30, 2021 |  |
| TD Synnex Corporation |  | 10% |  |  | 19% |  |
| Jenne Corporation |  | * |  |  | 24% |  |
| * Less than 10% of accounts receivable. |  |  |  |  |  |  |  |  |


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001564590-22-003010:notes:39]
[same as prior period, unchanged from 0001564590-21-054929:notes:36]

[0001564590-22-003010:notes:40]
[same as prior period, unchanged from 0001564590-21-054929:notes:37]

[0001564590-22-003010:notes:41]
[same as prior period, unchanged from 0001564590-21-054929:notes:38]

[0001564590-22-003010:notes:42]
On September 14, 2021 (the “Acquisition Date”), the Company completed its acquisition (the “Acquisition”) of Ipanematech SAS (“Ipanema”), the cloud-native enterprise Software-Defined Wide Area Network (“SD-WAN”) business unit of Infovista pursuant to a Sale and Purchase Agreement.  Under the terms of the Acquisition, the net consideration paid by Extreme to Ipanema stockholders was $70.9 million, which was funded from existing cash on hand. The primary reason for the acquisition was to acquire the talent and the technology to allow us to expand our portfolio with new cloud-managed SD-WAN and security offerings to support our enterprise customers.

[0001564590-22-003010:notes:43]
The Acquisition has been accounted for using the acquisition method of accounting whereby the acquired assets and liabilities of Ipanema have been recorded at their respective fair values and added to those of the Company including an amount for goodwill calculated as the difference between the acquisition consideration and the fair value of the identifiable net assets. The purchase price has been preliminarily allocated to tangible and identifiable intangible assets acquired and liabilities assumed. The final purchase price allocation is pending the finalization of valuations primarily intangible assets, goodwill and income tax assets and liabilities, which may result in an adjustment to the preliminary purchase price allocation.

[0001564590-22-003010:notes:44]
The estimated fair values were determined through established and generally accepted valuation techniques, including work performed by third-party valuation specialists. The fair value of working capital related items, such as accounts receivable, other current assets and accrued liabilities, approximated their book values at the date of acquisition. The fair value of the acquired deferred revenue was estimated using the cost build-up approach. The cost build-up approach determines fair value using estimates of the costs required to provide the contracted deliverables plus an assumed profit. The total costs including the assumed profit were adjusted to present value using a discount rate considered appropriate. The resulting fair value approximates the amount that the Company would be required to pay to a third party to assume the obligation. The fair value of the acquired deferred revenue was subsequently remeasured in accordance with ASC Topic 606 based on the recently issued and adopted guidance ASU 2021-08. Valuations of the intangible assets were valued using income approaches based on management projections, which the Company considers to be Level 3 inputs. The Company also continues to analyze the tax implications of the acquisition of the intangible assets, which may ultimately impact the overall level of goodwill associated with the Acquisition. Results of operations of Ipanema have been included in the operations of the Company beginning with the Acquisition Date.

[0001564590-22-003010:notes:45]
[same as prior period, unchanged from 0001564590-21-054929:notes:43]

[0001564590-22-003010:notes:46]
|  | Preliminary Allocation as of September 14, 2021 |  |  | Adjustments |  |  | Allocation as of December 31, 2021 |  |
| Cash and cash equivalents | $ | 1,364 |  |  | $ | — |  |  | $ | 1,364 |  |
| Accounts receivable, net |  | 1,440 |  |  |  | (6 | ) | a |  | 1,434 |  |
| Inventories |  | 337 |  |  |  | (63 | ) | a |  | 274 |  |
| Prepaid expenses and other current assets |  | 1,841 |  |  |  | (1,082 | ) | a |  | 759 |  |
| Property and equipment |  | 46 |  |  |  | — |  |  |  | 46 |  |
| Other assets |  | 21 |  |  |  | — |  |  |  | 21 |  |
| Accounts payable |  | (1,220 | ) |  |  | 244 |  | a |  | (976 | ) |
| Accrued compensation and benefits |  | (2,304 | ) |  |  | 638 |  | a |  | (1,666 | ) |
| Accrued warranty |  | (41 | ) |  |  | — |  |  |  | (41 | ) |
| Other accrued liabilities |  | (71 | ) |  |  | (51 | ) | b |  | (122 | ) |
| Deferred revenue |  | (2,758 | ) |  |  | (7,118 | ) | b |  | (9,876 | ) |
| Other liabilities |  | (723 | ) |  |  |  |  |  |  | (723 | ) |
| Net tangible liabilities |  | (2,068 | ) |  |  | (7,438 | ) |  |  | (9,506 | ) |
| Identifiable intangible assets |  | 16,300 |  |  |  | — |  |  |  | 16,300 |  |
| Goodwill |  | 56,649 |  |  |  | 7,438 |  | a,b |  | 64,087 |  |
| Total intangible assets acquired |  | 72,949 |  |  |  | 7,438 |  |  |  | 80,387 |  |
| Total net assets acquired | $ | 70,881 |  |  | $ | — |  |  | $ | 70,881 |  |

[0001564590-22-003010:notes:47]
The changes made during the period in the table above include: a) measurement period adjustments attributable to the Company’s review of the additional information being obtained on preacquisition assets and liabilities, b) the increase in deferred revenue (and the corresponding increase to Goodwill by the same amount) is the result of the adoption of ASU 2021-08 in the period ended December 31, 2021.

[0001564590-22-003010:notes:48]
[same as prior period, unchanged from 0001564590-21-054929:notes:45]

[0001564590-22-003010:notes:49]
[same as prior period, unchanged from 0001564590-21-054929:notes:46]

[0001564590-22-003010:notes:50]
[same as prior period, unchanged from 0001564590-21-054929:notes:47]

[0001564590-22-003010:notes:51]
[same as prior period, unchanged from 0001564590-21-054929:notes:48]

[0001564590-22-003010:notes:52]
For the three and six months ended December 31, 2021, the Company incurred acquisition and integration related expenses of $2.1 million and $3.6 million, respectively, associated with the acquisition of Ipanema. Acquisition and integration costs consisted primarily of professional fees for financial and legal advisory services. Such acquisition-related costs were expensed as incurred and are included in “Acquisition and integration costs” in the accompanying condensed consolidated statements of operations.

[0001564590-22-003010:notes:53]
[same as prior period, unchanged from 0001564590-21-054929:notes:50]

[0001564590-22-003010:notes:54]
[same as prior period, unchanged from 0001564590-21-054929:notes:51]

[0001564590-22-003010:notes:55]
The pro forma results of operations are not necessarily indicative of the combined results that would have occurred had the acquisition been consummated as of the beginning of fiscal 2021, nor are they necessarily indicative of future operating results. The

[0001564590-22-003010:notes:56]
unaudited pro forma results do not include the impact of synergies, nor any potential impacts on current or future market conditions, which could alter the unaudited pro forma results.

[0001564590-22-003010:notes:57]
The unaudited pro forma financial information for the three and six months ended December 31, 2020 combines the historical results for Extreme for such periods assuming the transaction closed on July 1, 2020, which include the results of Ipanema subsequent to the Acquisition Date, and Ipanema’s historical results up to the Acquisition Date.

[0001564590-22-003010:notes:58]
[same as prior period, unchanged from 0001564590-21-054929:notes:54]

[0001564590-22-003010:notes:59]
|  |  | Three months ended |  |  | Six Months Ended |  |
|  |  | December 31, 2021 |  |  | December 31, 2020 |  |  | December 31, 2021 |  |  | December 31, 2020 |  |
| Net revenues |  | $ | 280,438 |  |  | $ | 248,474 |  |  | $ | 551,743 |  |  | $ | 488,828 |  |
| Net income (loss) |  | $ | 15,562 |  |  | $ | (5,439 | ) |  | $ | 29,631 |  |  | $ | (16,877 | ) |
| Net income (loss) per share - basic |  | $ | 0.12 |  |  | $ | (0.04 | ) |  | $ | 0.23 |  |  | $ | (0.14 | ) |
| Net income (loss) per share - diluted |  | $ | 0.12 |  |  | $ | (0.04 | ) |  | $ | 0.22 |  |  | $ | (0.14 | ) |
| Shares used in per share calculation - basic |  |  | 129,403 |  |  |  | 123,264 |  |  |  | 128,863 |  |  |  | 122,485 |  |
| Shares used in per share calculation - diluted |  |  | 133,621 |  |  |  | 123,264 |  |  |  | 133,423 |  |  |  | 122,485 |  |


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001564590-22-003010:notes:60]
[same as prior period, unchanged from 0001564590-21-054929:notes:56]

[0001564590-22-003010:notes:61]
[same as prior period, unchanged from 0001564590-21-054929:notes:57]

[0001564590-22-003010:notes:62]
[same as prior period, unchanged from 0001564590-21-054929:notes:58]

[0001564590-22-003010:notes:63]
[same as prior period, unchanged from 0001564590-21-054929:notes:59]

[0001564590-22-003010:notes:64]
|  |  | December 31, 2021 |  |  | June 30, 2021 |  |
| Finished goods |  | $ | 30,342 |  |  | $ | 27,901 |  |
| Raw materials |  |  | 6,838 |  |  |  | 4,984 |  |
| Total inventories |  | $ | 37,180 |  |  | $ | 32,885 |  |

[0001564590-22-003010:notes:65]
[same as prior period, unchanged from 0001564590-21-054929:notes:61]

[0001564590-22-003010:notes:66]
[same as prior period, unchanged from 0001564590-21-054929:notes:62]

[0001564590-22-003010:notes:67]
|  |  | December 31, 2021 |  |  | June 30, 2021 |  |
| Computers and equipment |  | $ | 76,308 |  |  | $ | 75,866 |  |
| Purchased software |  |  | 44,305 |  |  |  | 40,037 |  |
| Office equipment, furniture and fixtures |  |  | 10,242 |  |  |  | 10,201 |  |
| Leasehold improvements |  |  | 52,984 |  |  |  | 53,329 |  |
| Total property and equipment |  |  | 183,839 |  |  |  | 179,433 |  |
| Less: accumulated depreciation and amortization |  |  | (131,722 | ) |  |  | (124,429 | ) |
| Property and equipment, net |  | $ | 52,117 |  |  | $ | 55,004 |  |

[0001564590-22-003010:notes:68]
[same as prior period, unchanged from 0001564590-21-054929:notes:64]

[0001564590-22-003010:notes:69]
[same as prior period, unchanged from 0001564590-21-054929:notes:65]

[0001564590-22-003010:notes:70]
[same as prior period, unchanged from 0001564590-21-054929:notes:66]

[0001564590-22-003010:notes:71]
[same as prior period, unchanged from 0001564590-21-054929:notes:67]

[0001564590-22-003010:notes:72]
The following table summarizes the activity related to the Company’s product warranty liability during the three and six months ended December 31, 2021 and 2020 (in thousands):

[0001564590-22-003010:notes:73]
|  |  | Three Months Ended |  | Six Months Ended |  |
|  |  | December 31, 2021 |  |  | December 31, 2020 |  | December 31, 2021 |  | December 31, 2020 |  |
| Balance beginning of period |  | $ | 10,780 |  |  | $ | 13,484 |  | $ | 11,623 |  | $ | 14,035 |  |
| Warranties assumed due to acquisition |  |  | — |  |  |  | — |  |  | 41 |  |  | — |  |
| New warranties issued |  |  | 3,822 |  |  |  | 3,056 |  |  | 6,532 |  |  | 6,135 |  |
| Warranty expenditures |  |  | (3,465 | ) |  |  | (3,467 | ) |  | (7,059 | ) |  | (7,097 | ) |
| Balance end of period |  | $ | 11,137 |  |  | $ | 13,073 |  | $ | 11,137 |  | $ | 13,073 |  |

[0001564590-22-003010:notes:74]
[same as prior period, unchanged from 0001564590-21-054929:notes:70]

[0001564590-22-003010:notes:75]
[same as prior period, unchanged from 0001564590-21-054929:notes:71]

[0001564590-22-003010:notes:76]
[same as prior period, unchanged from 0001564590-21-054929:notes:72]


## us-gaap:FairValueDisclosuresTextBlock

[0001564590-22-003010:notes:77]
[same as prior period, unchanged from 0001564590-21-054929:notes:73]

[0001564590-22-003010:notes:78]
[same as prior period, unchanged from 0001564590-21-054929:notes:74]

[0001564590-22-003010:notes:79]
[same as prior period, unchanged from 0001564590-21-054929:notes:75]

[0001564590-22-003010:notes:80]
[same as prior period, unchanged from 0001564590-21-054929:notes:76]

[0001564590-22-003010:notes:81]
[same as prior period, unchanged from 0001564590-21-054929:notes:77]

[0001564590-22-003010:notes:82]
The following table presents the Company’s fair value hierarchy for its financial assets and liabilities measured at fair value on a recurring basis at December 31, 2021 and June 30, 2021 (in thousands).

[0001564590-22-003010:notes:83]
| December 31, 2021 |  | Level 1 |  |  | Level 2 |  |  | Level 3 |  |  | Total |  |
| Assets |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency derivatives |  | $ | — |  |  | $ | 168 |  |  | $ | — |  |  | $ | 168 |  |
| Total assets measured at fair value |  | $ | — |  |  | $ | 168 |  |  | $ | — |  |  | $ | 168 |  |
| Liabilities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency derivatives |  | $ | — |  |  | $ | 274 |  |  | $ | — |  |  | $ | 274 |  |
| Interest rate swaps |  |  | — |  |  |  | 306 |  |  |  | — |  |  |  | 306 |  |
| Acquisition-related contingent consideration obligations |  |  | — |  |  |  | — |  |  |  | 208 |  |  |  | 208 |  |
| Total liabilities measured at fair value |  | $ | — |  |  | $ | 580 |  |  | $ | 208 |  |  | $ | 788 |  |

[0001564590-22-003010:notes:84]
[same as prior period, unchanged from 0001564590-21-054929:notes:80]

[0001564590-22-003010:notes:85]
[same as prior period, unchanged from 0001564590-21-054929:notes:81]

[0001564590-22-003010:notes:86]
[same as prior period, unchanged from 0001564590-21-054929:notes:82]

[0001564590-22-003010:notes:87]
As of December 31, 2021 and June 30, 2021, the Company had foreign exchange forward contracts that were not designated as hedging instruments with notional principal amount of $20.4 million and $23.0 million, respectively. These contracts have maturities of 40 days or less. Changes in the fair value of these foreign exchange forward contracts are included in other income (expense), net in the condensed consolidated statement of operations. For the three and six months ended December 31, 2021, there were net losses of less than $0.1 million and $0.2 million, respectively. For the three and six months ended December 31, 2020, there were net gains of $0.4 million and $0.5 million, respectively. As of December 31, 2021 and June 30, 2021, the Company had foreign exchange forward contracts that were designated as hedging instruments with notional principal amount of $5.7 million and $21.8 million, respectively. These contracts have maturities of less than twelve months. Gains and losses arising from these contracts designated as hedging instruments are recorded as a component of accumulated other comprehensive income (loss). As of December 31, 2021 and June 30, 2021, these contracts had unrealized losses of $0.3 million and $0.2 million, respectively. See Note 13, Derivatives and Hedging, for additional information.

[0001564590-22-003010:notes:88]
The fair values of the interest rate swaps are based upon inputs corroborated by observable market data which is considered Level 2. As of December 31, 2021 and as of June 30, 2021, the Company had interest rate swap contracts, designated as cash flow hedges, with the total notional amount of $200.0 million. Changes in fair value of these contracts are recorded as a component of accumulated other comprehensive loss. As of December 31, 2021 and as of June 30, 2021, these contracts had an unrealized loss of $0.3 million and $1.1 million, respectively. See Note 13, Derivatives and Hedging, for additional information.

[0001564590-22-003010:notes:89]
The fair value of the borrowings under the 2019 Credit Agreement (as defined in Note 8) is estimated based on valuations provided by alternative pricing sources supported by observable inputs which is considered Level 2.  Since the interest rate is variable for the 2019 Credit Agreement, the fair value approximates the face amount of the Company’s indebtedness of $322.9 million and $346.7 million as of December 31, 2021, and June 30, 2021, respectively.

[0001564590-22-003010:notes:90]
[same as prior period, unchanged from 0001564590-21-054929:notes:86]

[0001564590-22-003010:notes:91]
At December 31, 2021 and June 30, 2021, the Company reflected one liability measured at fair value of $0.2 million and $0.9 million, respectively, for contingent consideration related to a certain acquisition completed in fiscal 2018. The fair value measurement of the contingent consideration obligation is determined using Level 3 inputs. These fair value measurements represent Level 3 measurements as they are based on significant inputs not observable in the market. Changes in the value of the contingent consideration obligations are recorded in general and administrative expenses in the accompanying condensed consolidated statements of operations. The activities related to acquisition-related contingent consideration obligations during the period were not significant.

[0001564590-22-003010:notes:92]
There were no transfers of assets or liabilities between Level 1, Level 2 and Level 3 during the three and six months ended December 31, 2021 and 2020. There were no impairments recorded for the three and six months ended December 31, 2021 and 2020.

[0001564590-22-003010:notes:93]
[same as prior period, unchanged from 0001564590-21-054929:notes:91]


## us-gaap:IntangibleAssetsDisclosureTextBlock

[0001564590-22-003010:notes:94]
[same as prior period, unchanged from 0001564590-21-054929:notes:92]

[0001564590-22-003010:notes:95]
[same as prior period, unchanged from 0001564590-21-054929:notes:93]

[0001564590-22-003010:notes:96]
|  |  | Weighted Average |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Remaining Amortization |  | Gross Carrying |  |  | Accumulated |  |  | Net Carrying |  |
|  |  | Period |  | Amount |  |  | Amortization |  |  | Amount |  |
| December 31, 2021 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Developed technology |  | 3.3 years |  | $ | 170,600 |  |  | $ | 139,284 |  |  | $ | 31,316 |  |
| Customer relationships |  | 4.4 years |  |  | 64,839 |  |  |  | 55,706 |  |  |  | 9,133 |  |
| Backlog |  | — years |  |  | 400 |  |  |  | 400 |  |  |  | — |  |
| Trade names |  | 0.6 years |  |  | 10,700 |  |  |  | 10,560 |  |  |  | 140 |  |
| License agreements |  | 4.9 years |  |  | 2,445 |  |  |  | 2,089 |  |  |  | 356 |  |
| Total intangibles, net |  |  |  | $ | 248,984 |  |  | $ | 208,039 |  |  | $ | 40,945 |  |

[0001564590-22-003010:notes:97]
[same as prior period, unchanged from 0001564590-21-054929:notes:95]

[0001564590-22-003010:notes:98]
[same as prior period, unchanged from 0001564590-21-054929:notes:96]

[0001564590-22-003010:notes:99]
|  |  | Three Months Ended |  | Six Months Ended |  |
|  |  | December 31, 2021 |  |  | December 31, 2020 |  | December 31, 2021 |  |  | December 31, 2020 |  |
| Amortization of intangibles in “Total cost of revenues” |  | $ | 4,149 |  |  | $ | 6,649 |  | $ | 9,435 |  |  | $ | 13,348 |  |
| Amortization of intangibles in “Operations” |  |  | 804 |  |  |  | 1,506 |  |  | 1,958 |  |  |  | 3,298 |  |
| Total amortization expense |  | $ | 4,953 |  |  | $ | 8,155 |  | $ | 11,393 |  |  | $ | 16,646 |  |

[0001564590-22-003010:notes:100]
[same as prior period, unchanged from 0001564590-21-054929:notes:98]


## us-gaap:DebtDisclosureTextBlock

[0001564590-22-003010:notes:101]
| 8. | Debt |

[0001564590-22-003010:notes:102]
The Company’s debt is comprised of the following (in thousands):

[0001564590-22-003010:notes:103]
|  |  | December 31, 2021 |  |  | June 30, 2021 |  |
| Current portion of long-term debt: |  |  |  |  |  |  |  |  |
| Term Loan |  | $ | 30,875 |  |  | $ | 26,125 |  |
| Less: unamortized debt issuance costs |  |  | (2,333 | ) |  |  | (2,404 | ) |
| Current portion of long-term debt |  | $ | 28,542 |  |  | $ | 23,721 |  |
| Long-term debt, less current portion: |  |  |  |  |  |  |  |  |
| Term Loan |  | $ | 292,000 |  |  | $ | 320,625 |  |
| Less: unamortized debt issuance costs |  |  | (3,542 | ) |  |  | (4,760 | ) |
| Total long-term debt, less current portion |  |  | 288,458 |  |  |  | 315,865 |  |
| Total debt |  | $ | 317,000 |  |  | $ | 339,586 |  |

[0001564590-22-003010:notes:104]
In connection with the acquisition of Aerohive Networks, Inc., on August 9, 2019, the Company entered into an Amended and Restated Credit Agreement (the “2019 Credit Agreement”), by and among the Company, as borrower, several banks and other financial institutions as Lenders, BMO Harris Bank N.A., as an issuing lender and swingline lender, Silicon Valley Bank, as an Issuing Lender, and Bank of Montreal, as administrative agent and collateral agent for the Lenders.

[0001564590-22-003010:notes:105]
The 2019 Credit Agreement provides for a five-year first lien term loan facility in an aggregate principal amount of $380.0 million and a five-year revolving loan facility in an aggregate principal amount of $75.0 million (the “2019 Revolving Facility”).  In addition, the Company may request incremental term loans and/or incremental revolving loan commitments in an aggregate amount not to exceed the sum of $100.0 million, plus an unlimited amount that is subject to pro forma compliance with certain financial tests. On August 9, 2019, the Company used the additional proceeds from the term loan to partially fund the Acquisition and for working capital and general corporate purposes.

[0001564590-22-003010:notes:106]
At the Company’s election, the initial term loan under the 2019 Credit Agreement may be made as either base rate loans or Eurodollar loans. The applicable margin for base rate loans ranges from 0.25% to 2.50% per annum and the applicable margin for Eurodollar loans ranges from 1.25% to 3.50%, in each case based on Extreme’s consolidated leverage ratio. All Eurodollar loans are subject to a Base Rate of 0.00%. In addition, the Company is required to pay a commitment fee of between 0.25% and 0.40% quarterly (currently 0.25%) on the unused portion of the 2019 Revolving Facility, also based on the Company’s consolidated leverage ratio. Principal installments are payable on the new term loan in varying percentages quarterly starting December 31, 2019 and to the extent not previously paid, all outstanding balances are to be paid at maturity. The 2019 Credit Agreement is secured by substantially all of the Company’s assets.

[0001564590-22-003010:notes:107]
The 2019 Credit Agreement requires the Company to maintain certain minimum financial ratios at the end of each fiscal quarter. The 2019 Credit Agreement also includes covenants and restrictions that limit, among other things, the Company’s ability to incur additional indebtedness, create liens upon any of its property, merge, consolidate or sell all or substantially all of its assets. The 2019 Credit Agreement also includes customary events of default which may result in acceleration of the payment of the outstanding balance.

[0001564590-22-003010:notes:108]
On April 8, 2020, the Company entered into the first amendment to the 2019 Credit Agreement (the “First Amendment”) to waive certain terms and financial covenants of the 2019 Credit Agreement through July 31, 2020. On May 8, 2020, the Company entered into the second amendment to the 2019 Credit Agreement (the “Second Amendment”), which superseded the First Amendment and provided certain revised terms and financial covenants through March 31, 2021. Subsequent to March 31, 2021, the original terms and financial covenants under the 2019 Credit Agreement resumed in effect. The Second Amendment required the Company to maintain certain minimum cash requirement and certain financial metrics at the end of each fiscal quarter through March 31, 2021. Under the terms of the Second Amendment, the Company was not permitted to exceed $55.0 million in its outstanding balance under the 2019 Revolving Facility, the applicable margin for Eurodollar rate was 4.5%, and the Company was restricted from pursuing certain activities such as incurring additional debt, stock repurchases, making acquisitions or declaring a dividend, until the Company was in compliance with the original covenants of the 2019 Credit Agreement.

[0001564590-22-003010:notes:109]
On November 3, 2020, the Company and its lenders entered into the Third Amendment to the 2019 Credit Agreement (the “Third Amendment”), to increase the sublimit for letters of credit to $20.0 million. On December 8, 2020, the Company and its lenders entered into the fourth amendment to the 2019 Credit Agreement (the “Fourth Amendment”), to waive and amend certain terms and financial covenants within the 2019 Credit Agreement through March 31, 2021.

[0001564590-22-003010:notes:110]
The Second Amendment provided for the Company to end the covenant Suspension Period early and revert to the covenants and interest rates per the original terms of the 2019 Credit Agreement dated August 9, 2019 by filing a Suspension Period Early Termination Notice and Covenant Certificate demonstrating compliance. For the twelve-month period ended March 31, 2021, the

[0001564590-22-003010:notes:111]
Company’s financial performance was in compliance with the original covenants defined in the 2019 Credit Agreement and, as such, the Company filed a Suspension Early Termination Notice and Covenant Certificate with the administration agent subsequent to filing the Company’s Quarterly Report on Form 10-Q for the period ended March 31, 2021. Returning to compliance with the covenants per the original terms of the 2019 Credit Agreement dated August 9, 2019 resulted in the Company’s Eurodollar loan spread decreasing from 4.5% during the suspension period to 2.75% and unused facility commitment fee decreasing from 0.4% to 0.35%, and the limitation on revolver borrowings being removed effective May 1, 2021 after filing of the certificate with the administrative agent.

[0001564590-22-003010:notes:112]
Financing costs incurred in connection with obtaining long-term financing are deferred and amortized over the term of the related indebtedness or credit agreement. During the year ended June 30, 2020, the Company incurred $10.5 million of deferred financing costs in conjunction with the 2019 Credit Agreement and $1.5 million of deferred financing costs from the amendments, and continues to amortize $1.6 million of debt issuance costs as of August 9, 2019 that were associated with the previous facility. The interest rate as of December 31, 2021 was 1.86% and as of December 31, 2020 was 4.65%.

[0001564590-22-003010:notes:113]
Amortization of deferred financing costs included in “Interest expense” in the accompanying condensed consolidated statements of operations totaled $0.7 million and $0.8 million for the three months ended December 31, 2021 and 2020, and totaled $1.5 million each for the six months ended December 31, 2021 and 2020.

[0001564590-22-003010:notes:114]
During the fiscal year ended June 30, 2021, the Company repaid $55.0 million against its 2019 Revolving Facility’s outstanding balance of $55.0 million and had no remaining outstanding balance at December 31, 2021. The Company had $60.2 million of availability under the 2019 Revolving Facility as of December 31, 2021. During the six months ended December 31, 2021, the Company made an additional payment of $12.0 million against its term loan facility.

[0001564590-22-003010:notes:115]
The Company had $14.8 million of outstanding letters of credit as of December 31, 2021.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001564590-22-003010:notes:116]
| 9. | Commitments and Contingencies |

[0001564590-22-003010:notes:117]
Purchase Commitments

[0001564590-22-003010:notes:118]
The Company currently has arrangements with contract manufacturers and suppliers for the manufacture of its products. Those arrangements allow the contract manufactures to procure long lead-time component inventory based upon a rolling production forecast provided by the Company. The Company is obligated to purchase long lead-time component inventory that its contract manufacturer procures in accordance with the forecast, unless the Company gives notice of order cancellation outside of applicable component lead-times. As of December 31, 2021, the Company had commitments to purchase $53.2 million of inventory.

[0001564590-22-003010:notes:119]
Legal Proceedings

[0001564590-22-003010:notes:120]
The Company may from time to time be party to litigation arising in the course of its business, including, without limitation, allegations relating to commercial transactions, business relationships or intellectual property rights. Such claims, even if not meritorious, could result in the expenditure of significant financial and managerial resources. Litigation in general, and intellectual property in particular, can be expensive and disruptive to normal business operations. Moreover, the results of legal proceedings are difficult to predict.

[0001564590-22-003010:notes:121]
In accordance with applicable accounting guidance, the Company records accruals for certain of its outstanding legal proceedings, investigations or claims when it is probable that a liability will be incurred, and the amount of loss can be reasonably estimated. The Company evaluates, at least on a quarterly basis, developments in legal proceedings, investigations or claims that could affect the amount of any accrual, as well as any developments that would result in a loss contingency to become both probable and reasonably estimable. When a loss contingency is not both probable and reasonably estimable, the Company does not record a loss accrual. However, if the loss (or an additional loss in excess of any prior accrual) is at least reasonably possible and material and a reasonable estimate can be made, then the Company would make an accrual. The assessment whether a loss is probable or a reasonable possibility, and whether the loss or a range of loss is estimable, involves a series of complex judgments about future events. Litigation is unpredictable, and even if a loss is reasonably possible, the Company may not be able to estimate a range of possible loss, particularly where (i) the damages sought are substantial or indeterminate, (ii) the proceedings are in the early stages, or (iii) the matters involve novel or unsettled legal theories or a large number of parties. In such cases, there is considerable uncertainty regarding the ultimate resolution of such matters, including the amount of any possible loss, fine or penalty. An adverse resolution of one or more of such matters could have a material adverse effect on the Company's results of operations in a particular quarter or fiscal year.

[0001564590-22-003010:notes:122]
XR Communications, LLC d/b/a Vivato Technologies v. Extreme Networks, Inc.

[0001564590-22-003010:notes:123]
On April 19, 2017, XR Communications, LLC (“XR”) (d/b/a Vivato Technologies) filed a patent infringement lawsuit against the Company in the Central District of California. The operative Second Amended Complaint asserts infringement of certain U.S. Patent based on the Company’s manufacture, use, sale, offer for sale, and/or importation into the United States of certain access points and routers supporting multi-user, multiple-input, multiple-output technology. XR seeks unspecified damages, on-going

[0001564590-22-003010:notes:124]
royalties, pre- and post-judgment interest, and attorneys’ fees. The Court has dismissed the case with prejudice.  The deadline for XR to appeal the dismissal is February 3, 2022.

[0001564590-22-003010:notes:125]
Orckit IP, LLC v. Extreme Networks, Inc., Extreme Networks Ireland Ltd., and Extreme Networks GmbH

[0001564590-22-003010:notes:126]
On February 1, 2018, Orckit IP, LLC (“Orckit”) filed a patent infringement lawsuit against the Company and its Irish and German subsidiaries in the District Court in Dusseldorf, Germany. The lawsuit alleges direct and indirect infringement of the German portion of a patent (“EP ‘364”) based on the offer, distribution, use, possession and/or importation into Germany of certain network switches that equipped with the ExtremeXOS operating system. Orckit is seeking injunctive relief, accounting, and an unspecified declaration of liability for damages and costs of the lawsuit. On January 28, 2020, the Court rendered a decision in the infringement case in favor of the Company. The matter is proceeding through the appellate process, and an oral hearing was held on October 21, 2021.  The Court has appointed an expert to provide an opinion and a decision is pending.

[0001564590-22-003010:notes:127]
On April 23, 2019, Orckit filed an extension of the patent infringement complaint against the Company and its Irish and German subsidiaries in the District Court in Dusseldorf, Germany. With this extension, Orckit alleges infringement of the German portion of a second patent (“EP ‘077”) based on the offer, distribution, use, possession and/or importation into Germany of certain network switches that the Company no longer sells in Germany. Orckit is seeking injunctive relief, accounting and sales information, and a declaration of liability for damages as well as costs of the lawsuit. On October 13, 2020, the Court issued an infringement decision against the Company and granted to Orckit the right to enforce the judgment against the Company, which Orckit has provided notification to the Company that it will enforce the judgment. In the rendering of account, Orckit was informed that the products at issue were in end of sale status prior to the filing of the ‘077 complaint. The Company has appealed the infringement decision, and the matter is proceeding through the appellate process.

[0001564590-22-003010:notes:128]
The Company filed a nullity action related to the EP ‘364 patent on May 3, 2018, and one related to the EP ‘077 patent on October 31, 2019, both in the Federal Patent Court in Munich. The court found the EP ‘364 patent to be valid and the Company has filed an appeal.  The case filed to seek to invalidate the EP ‘077 patent is proceeding.

[0001564590-22-003010:notes:129]
SNMP Research, Inc. and SNMP Research International, Inc. v. Broadcom Inc., Brocade Communications Systems LLC, and Extreme Networks, Inc.

[0001564590-22-003010:notes:130]
On October 26, 2020, SNMP Research, Inc. and SNMP Research International, Inc. (collectively, “SNMP”) filed a lawsuit against the Company in the Eastern District of Tennessee for copyright infringement, alleging that the Company was not properly licensed to use its software.  SNMP is seeking actual damages and profits attributed to the infringement, as well as equitable relief. The Company has filed a motion to dismiss and a motion to transfer the case to the Northern District of California. Both motions are pending. A trial date has been set for February 2023.

[0001564590-22-003010:notes:131]
Mala Technologies Ltd. v. Extreme Networks GmbH, Extreme Networks Ireland Ops Ltd., and Extreme Networks, Inc.

[0001564590-22-003010:notes:132]
On April 15, 2021, Mala Technologies Ltd. (“Mala”) filed a patent infringement lawsuit against the Company and its Irish and German subsidiaries in the District Court in Dusseldorf, Germany.  The lawsuit alleges indirect infringement of the German portion of a patent (“EP ‘498”) based on the offer and sale in Germany of certain network switches equipped with the ExtremeXOS operating system.  Mala is seeking injunctive relief, accounting, and an unspecified declaration of liability for damages and costs of the lawsuit.  A hearing date has been set for July 14, 2022.  The Company filed a nullity action related to the EP’498 patent on September 24, 2021 in the German Federal Patent Court.

[0001564590-22-003010:notes:133]
Indemnification Obligations

[0001564590-22-003010:notes:134]
Subject to certain limitations, the Company may be obligated to indemnify its current and former directors, officers and employees. These obligations arise under the terms of its certificate of incorporation, its bylaws, applicable contracts, and applicable law. The obligation to indemnify, where applicable, generally means that the Company is required to pay or reimburse, and in certain circumstances the Company has paid or reimbursed, the individuals’ reasonable legal expenses and possibly damages and other liabilities incurred in connection with certain legal matters. The Company also procures Directors and Officers liability insurance to help cover its defense and/or indemnification costs, although its ability to recover such costs through insurance is uncertain.  While it is not possible to estimate the maximum potential amount that could be owed under these governing documents and agreements due to the Company’s limited history with prior indemnification claims, indemnification (including defense) costs could, in the future, have a material adverse effect on the Company’s consolidated financial position, results of operations and cash flows.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001564590-22-003010:notes:135]
[same as prior period, unchanged from 0001564590-21-054929:notes:134]

[0001564590-22-003010:notes:136]
[same as prior period, unchanged from 0001564590-21-054929:notes:135]

[0001564590-22-003010:notes:137]
On May 17, 2021, the Company entered into the Amended and Restated Tax Benefit Preservation Plan (the “2021 Tax Benefit Preservation Plan”), which amended and restated the Amended and Restated Rights Agreement between the Company and Computershare Shareholder Services LLC, as the rights agent. The 2021 Tax Benefit Preservation Plan was approved by stockholders of the Company at the annual meeting of stockholders on November 4, 2021. The 2021 Tax Benefit Preservation Plan governs the terms of each right (“Right”) that has been issued with respect to each share of common stock of Extreme Networks. Each Right initially represents the right to purchase one one-thousandth of a share of the Company’s Preferred Stock.

[0001564590-22-003010:notes:138]
The Company’s Board of Directors (the “Board”) adopted the 2021 Tax Benefit Preservation Plan to preserve the value of deferred tax assets, including net operating loss carry forwards of the Company, with respect to its ability to fully use its tax benefits to offset future income which may be limited if the Company experiences an “ownership change” for purposes of Section 382 of the Internal Revenue Code of 1986 as a result of ordinary buying and selling of shares of its common stock. Following its review of the terms of the plan, the Board decided it was necessary and in the best interests of the Company and its stockholders to enter into the 2021 Tax Benefit Preservation Plan.

[0001564590-22-003010:notes:139]
[same as prior period, unchanged from 0001564590-21-054929:notes:138]

[0001564590-22-003010:notes:140]
[same as prior period, unchanged from 0001564590-21-054929:notes:139]

[0001564590-22-003010:notes:141]
[same as prior period, unchanged from 0001564590-21-054929:notes:140]

[0001564590-22-003010:notes:142]
[same as prior period, unchanged from 0001564590-21-054929:notes:141]

[0001564590-22-003010:notes:143]
[same as prior period, unchanged from 0001564590-21-054929:notes:142]

[0001564590-22-003010:notes:144]
[same as prior period, unchanged from 0001564590-21-054929:notes:143]

[0001564590-22-003010:notes:145]
During the three and six months ended December 31, 2021, the Company repurchased a total of 1,829,333 shares of its common stock on the open market at a total cost of $25.0 million with an average price of $13.65 per share. There were no shares repurchased during the three and six months ended December 31, 2020. As of December 31, 2021, approximately $30.0 million remains available for share repurchases under the program.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001564590-22-003010:notes:146]
[same as prior period, unchanged from 0001564590-21-054929:notes:145]

[0001564590-22-003010:notes:147]
[same as prior period, unchanged from 0001564590-21-054929:notes:146]

[0001564590-22-003010:notes:148]
[same as prior period, unchanged from 0001564590-21-054929:notes:147]

[0001564590-22-003010:notes:149]
|  |  | December 31, 2021 |  |  | June 30, 2021 |  |
| 2013 Equity Incentive Plan shares available for grant |  |  | 10,920 |  |  |  | 6,753 |  |
| Employee stock options and awards outstanding |  |  | 9,262 |  |  |  | 10,359 |  |
| 2014 Employee Stock Purchase Plan |  |  | 10,924 |  |  |  | 4,414 |  |
| Total shares reserved for issuance |  |  | 31,106 |  |  |  | 21,526 |  |

[0001564590-22-003010:notes:150]
[same as prior period, unchanged from 0001564590-21-054929:notes:149]

[0001564590-22-003010:notes:151]
[same as prior period, unchanged from 0001564590-21-054929:notes:150]

[0001564590-22-003010:notes:152]
|  | Three Months Ended |  |  | Six Months Ended |  |
|  | December 31, 2021 |  |  | December 31, 2020 |  |  | December 31, 2021 |  |  | December 31, 2020 |  |
| Cost of product revenues | $ | 303 |  |  | $ | 314 |  |  | $ | 613 |  |  | $ | 572 |  |
| Cost of service and subscription revenues |  | 351 |  |  |  | 439 |  |  |  | 713 |  |  |  | 811 |  |
| Research and development |  | 2,664 |  |  |  | 2,694 |  |  |  | 5,122 |  |  |  | 4,966 |  |
| Sales and marketing |  | 3,860 |  |  |  | 3,239 |  |  |  | 7,435 |  |  |  | 5,886 |  |
| General and administrative |  | 4,155 |  |  |  | 3,409 |  |  |  | 7,894 |  |  |  | 6,162 |  |
| Total share-based compensation expense | $ | 11,333 |  |  | $ | 10,095 |  |  | $ | 21,777 |  |  | $ | 18,397 |  |

[0001564590-22-003010:notes:153]
[same as prior period, unchanged from 0001564590-21-054929:notes:152]

[0001564590-22-003010:notes:154]
The following table summarizes stock option activity for the six months ended December 31, 2021 (in thousands, except per share and contractual term):

[0001564590-22-003010:notes:155]
|  |  | Number of Shares |  |  | Weighted-Average Exercise Price Per Share |  |  | Weighted-Average Remaining Contractual Term (years) |  |  | Aggregate Intrinsic Value |  |
| Options outstanding at June 30, 2021 |  |  | 1,645 |  |  | $ | 5.44 |  |  |  | 3.62 |  |  | $ | 9,404 |  |
| Granted |  |  | — |  |  |  | — |  |  |  |  |  |  |  |  |  |
| Exercised |  |  | (356 | ) |  |  | 2.55 |  |  |  |  |  |  |  |  |  |
| Cancelled |  |  | — |  |  |  | — |  |  |  |  |  |  |  |  |  |
| Options outstanding at December 31, 2021 |  |  | 1,289 |  |  | $ | 6.24 |  |  |  | 3.89 |  |  | $ | 12,188 |  |
| Vested and expected to vest at December 31, 2021 |  |  | 1,289 |  |  | $ | 6.24 |  |  |  | 3.89 |  |  | $ | 12,188 |  |
| Exercisable at December 31, 2021 |  |  | 1,010 |  |  | $ | 6.12 |  |  |  | 3.68 |  |  | $ | 9,681 |  |

[0001564590-22-003010:notes:156]
The fair value of each stock option grant under the 2013 Plan is estimated on the date of grant using the Black-Scholes-Merton option valuation model. The expected term of options granted is derived from historical data on employee exercise and post-vesting employment termination behavior. The risk-free rate is based upon the estimated life of the option and the U.S. Treasury yield curve in effect at the time of grant. Expected volatility is based on the historical volatility on the Company’s stock. There were no stock options granted during the six months ended December 31, 2021 and 2020.

[0001564590-22-003010:notes:157]
[same as prior period, unchanged from 0001564590-21-054929:notes:156]

[0001564590-22-003010:notes:158]
[same as prior period, unchanged from 0001564590-21-054929:notes:157]

[0001564590-22-003010:notes:159]
The following table summarizes stock award activity for the six months ended December 31, 2021 (in thousands, except grant date fair value):

[0001564590-22-003010:notes:160]
|  |  | Number of Shares |  |  | Weighted- Average Grant Date Fair Value |  |  | Aggregate Fair Value |  |
| Non-vested stock awards outstanding at June 30, 2021 |  |  | 8,714 |  |  | $ | 5.51 |  |  |  |  |  |
| Granted |  |  | 3,889 |  |  |  | 11.36 |  |  |  |  |  |
| Released |  |  | (4,353 | ) |  |  | 5.18 |  |  |  |  |  |
| Cancelled |  |  | (277 | ) |  |  | 6.47 |  |  |  |  |  |
| Non-vested stock awards outstanding at December 31, 2021 |  |  | 7,973 |  |  | $ | 8.51 |  |  | $ | 125,178 |  |
| Stock awards expected to vest at December 31, 2021 |  |  | 7,973 |  |  | $ | 8.51 |  |  | $ | 125,178 |  |

[0001564590-22-003010:notes:161]
The RSU’s granted under the 2013 Plan vest over a period of time, generally one to three years, and are subject to participant's continued service to the Company. The stock awards granted during the six months ended December 31, 2021 included 1.0 million RSUs including the market condition awards discussed below to named executive officers and directors.

[0001564590-22-003010:notes:162]
[same as prior period, unchanged from 0001564590-21-054929:notes:161]

[0001564590-22-003010:notes:163]
During the six months ended December 31, 2021 and 2020, the Compensation Committee of the Board granted 0.7 million and 0.5 million RSUs, respectively, with vesting based on market conditions (“MSU”) to certain of the Company’s executive officers. These MSUs vest based on the Company’s total shareholder return (“TSR”) relative to the TSR of the Russell 2000 Index (“Index”).  The MSU award represents the right to receive a target number of shares of common stock of up to 150% of the original grant. The MSUs vest based on the Company’s TSR relative to the TSR of the Index over performance periods of three years from the grant date, subject to the grantees’ continued service through the certification of performance.

[0001564590-22-003010:notes:164]
[same as prior period, unchanged from 0001564590-21-054929:notes:163]

[0001564590-22-003010:notes:165]
Total shareholder return is calculated based on the average closing price for the 30-trading days prior to the beginning and end of the performance periods. Performance is measured based on three periods, with the ability for up to one-third of target shares to vest after years one and two and the ability for up to the maximum of the full award to vest based on the full three-year TSR less any shares vested based on one- and two-year periods. Linear interpolation is used to determine the number of shares vested for achievement between target levels.

[0001564590-22-003010:notes:166]
The grant date fair value of each MSU was determined using the Monte Carlo simulation model. The weighted-average grant-date fair value of the MSUs granted during the six months ended December 31, 2021 was $12.69 per share. The assumptions used in the Monte Carlo simulation included the expected volatility of 66%, risk-free rate of 0.44%, no expected dividend yield, expected term of three years and possible future stock prices over the performance period based on the historical stock and market prices. The Company recognizes the expense related to these MSUs on a graded-vesting method over the estimated term.

[0001564590-22-003010:notes:167]
The weighted-average grant-date fair value of the MSUs granted during the six months ended December 31, 2020 was $5.32 per share. The assumptions used in the Monte Carlo simulation included the expected volatility of 69%, risk-free rate of 0.18%, no expected dividend yield, expected term of three years and possible future stock prices over the performance period based on the historical stock and market prices.

[0001564590-22-003010:notes:168]
[same as prior period, unchanged from 0001564590-21-054929:notes:167]

[0001564590-22-003010:notes:169]
There were 1.0 million and 1.5 million shares issued under the ESPP during the six months ended December 31, 2021 and 2020, respectively. The following assumptions were used to determine the grant-date fair values of the ESPP shares during the following periods:

[0001564590-22-003010:notes:170]
|  |  | Employee Stock Purchase Plan |  |
|  |  | Six Months Ended |  |
|  |  | December 31, 2021 |  |  | December 31, 2020 |  |
| Expected life |  | 0.5 years |  |  | 0.5 years |  |
| Risk-free interest rate |  |  | 0.05 | % |  |  | 0.12 | % |
| Volatility |  |  | 52 | % |  |  | 119 | % |
| Dividend yield |  |  | — | % |  |  | — | % |

[0001564590-22-003010:notes:171]
The weighted-average grant-date fair value of shares under the ESPP during the six months ended December 31, 2021 and 2020 was $3.18 and $2.23 per share, respectively.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001564590-22-003010:notes:172]
[same as prior period, unchanged from 0001564590-21-054929:notes:171]

[0001564590-22-003010:notes:173]
[same as prior period, unchanged from 0001564590-21-054929:notes:172]

[0001564590-22-003010:notes:174]
[same as prior period, unchanged from 0001564590-21-054929:notes:173]

[0001564590-22-003010:notes:175]
[same as prior period, unchanged from 0001564590-21-054929:notes:174]

[0001564590-22-003010:notes:176]
|  |  | December 31, 2021 |  |  | June 30, 2021 |  |
| Americas |  | $ | 154,720 |  |  | $ | 151,839 |  |
| EMEA |  |  | 20,155 |  |  |  | 25,940 |  |
| APAC |  |  | 12,162 |  |  |  | 13,560 |  |
| Total long-lived assets |  | $ | 187,037 |  |  | $ | 191,339 |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001564590-22-003010:notes:177]
[same as prior period, unchanged from 0001564590-21-054929:notes:176]

[0001564590-22-003010:notes:178]
[same as prior period, unchanged from 0001564590-21-054929:notes:177]

[0001564590-22-003010:notes:179]
[same as prior period, unchanged from 0001564590-21-054929:notes:178]

[0001564590-22-003010:notes:180]
[same as prior period, unchanged from 0001564590-21-054929:notes:179]

[0001564590-22-003010:notes:181]
During fiscal 2020, the Company entered into multiple interest rate swap contracts, designated as cash flow hedges, to hedge the variability of cash flows in interest payments associated with the Company’s various tranches of floating-rate debt. As of December 31, 2021 and December 31, 2020, the total notional amount of these interest rate swaps was $200.0 million and had maturity dates through April 2023. As of December 31, 2021 and December 31, 2020, these contracts had unrealized losses of $0.3 million and $1.7 million, respectively, which are recorded in “Accumulated other comprehensive loss” with the associated liability in “Other accrued liabilities” in the condensed consolidated balance sheets. Cash flows associated with periodic settlements of interest rate swaps are classified as operating activities in the condensed consolidated statement of cash flows. Realized gains and losses are recognized as they accrue in interest expense. Amounts reported in accumulated other comprehensive loss related to these cash flow hedges are reclassified to interest expense over the life of the swap contracts. The Company estimates that $0.4 million will be reclassified to interest expense over the next twelve months. The classification and fair value of these cash flow hedges are discussed in Note 6, Fair Value Measurements.

[0001564590-22-003010:notes:182]
[same as prior period, unchanged from 0001564590-21-054929:notes:181]

[0001564590-22-003010:notes:183]
[same as prior period, unchanged from 0001564590-21-054929:notes:182]

[0001564590-22-003010:notes:184]
[same as prior period, unchanged from 0001564590-21-054929:notes:183]

[0001564590-22-003010:notes:185]
For foreign exchange forward contracts not designated as hedging instruments, the fair value of the Company’s derivatives in a gain position are recorded in “Prepaid expenses and other current assets” and derivatives in a loss position are recorded in “Other accrued liabilities” in the accompanying condensed consolidated balance sheets. Changes in the fair value of derivatives are recorded in “Other income (expense), net” in the accompanying condensed consolidated statements of operations. As of December 31, 2021 and 2020, foreign exchange forward contracts not designated as hedging instruments had the total notional principal amount of $20.4 and $22.7 million, respectively. These contracts have maturities of 40 days or less. The net gains and losses recorded in the condensed consolidated statement of operations from these transactions during the three and six months ended December 31, 2021 were losses of less than $0.1 million and $0.2 million, respectively, and during the three and six months ended December 31, 2020, there were net gains of $0.4 million and $0.5 million, respectively. Changes in the fair value of these foreign exchange forward contracts are offset largely by remeasurement of the underlying assets and liabilities

[0001564590-22-003010:notes:186]
For foreign exchange forward contracts designated as hedging instruments, gains and losses arising from these contracts are recorded as a component of accumulated other comprehensive income (loss) on the condensed consolidated balance sheets. The hedging gains and losses in accumulated other comprehensive income are subsequently reclassified to expenses, as applicable, in the condensed consolidated statements of operations in the same period in which the underlying transactions affect our earnings. As of December 31, 2021, foreign exchange forward contracts designated as hedging instruments had the notional amount of $5.7 million. These contracts have maturities of less than twelve months. As of December 31, 2021, these contracts had unrealized losses of $0.3 million which are recorded in accumulated other comprehensive income (loss) with the associated liability in other accrued liabilities in the accompanying consolidated balance sheets. There were no foreign exchange forward contracts at December 31, 2020 that were designated as hedging instruments.

[0001564590-22-003010:notes:187]
The Company recognized total foreign currency losses of less than $0.1 million and $1.3 million for the three months ended December 31, 2021 and 2020, respectively, related to the change in fair value of foreign currency denominated assets and liabilities. The Company recognized total foreign currency gains of $0.3 million and a loss of $2.4 million for the six months ended December 31, 2021 and 2020, respectively, related to the change in fair value of foreign currency denominated assets and liabilities.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001564590-22-003010:notes:188]
| 14. | Restructuring and Related Charges |

[0001564590-22-003010:notes:189]
The Company recorded $0.3 million and $0.6 million of restructuring and related charges during the three and six months ended December 31, 2021, respectively, which primarily included facility related charges of $0.3 million and $0.6 million for the three and six months ended December 31, 2021, respectively. Severance and benefit restructuring charges consisted primarily of employee severance and benefit expenses incurred under the reduction-in-force action initiated in the third quarter of fiscal 2020 (the “2020 Plan”) to reduce operating costs and enhance financial flexibility as a result of disruptions caused by the COVID-19 global pandemic. With the reduction and realignment of the headcount under the 2020 Plan, the Company is relocating certain of its lab test equipment to third-party consulting companies. The Company has incurred $9.6 million of charges under the 2020 Plan through December 31, 2021. As of December 31, 2021, the Company has substantially completed all these activities under the 2020 Plan. The facility restructuring charges included additional facilities expenses related to previously impaired facilities.

[0001564590-22-003010:notes:190]
The Company recorded $0.7 million and $1.7 million of restructuring charges, net of reversals and impairments during the three and six months ended December 31, 2020, respectively. Total restructuring charges included severance, benefits, and equipment relocation charges of $0.4 million and $1.1 million, as well as facility related charges of $0.3 million and $0.6 million for the three and six months ended December 31, 2020, respectively. Severance and benefit restructuring charges consisted primarily of additional employee severance and benefit expenses incurred under the 2020 Plan to reduce operating costs and enhance financial flexibility as a result of disruptions caused by the COVID-19 global pandemic. With the reduction and realignment of the headcount under 2020 Plan, the Company relocated certain of its lab test equipment to third-party consulting companies. The Company incurred $9.2 million charges under the 2020 Plan through December 31, 2020. The facility restructuring charges included additional facilities expenses related to previously impaired facilities.

[0001564590-22-003010:notes:191]
Restructuring liabilities related to severance, benefits, and equipment relocation obligations are recorded in “Other accrued liabilities” in the accompanying condensed consolidated balance sheets. The following table summarizes the activity related to the severance, benefits, and equipment relocation liabilities during the three and six months ended December 31, 2021 (in thousands):

[0001564590-22-003010:notes:192]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | December 31, 2021 |  |  | December 31, 2020 |  |  | December 31, 2021 |  |  | December 31, 2020 |  |
|  |  | Severance and Other |  |  | Severance and Other |  |
| Balance at beginning of period |  | $ | 93 |  |  | $ | 302 |  |  | $ | 271 |  |  | $ | 2,219 |  |
| Period charges |  |  | 4 |  |  |  | 475 |  |  |  | 12 |  |  |  | 1,247 |  |
| Period reversals |  |  | — |  |  |  | (78 | ) |  |  | (30 | ) |  |  | (128 | ) |
| Period payments |  |  | — |  |  |  | (518 | ) |  |  | (156 | ) |  |  | (3,157 | ) |
| Balance at end of period |  | $ | 97 |  |  | $ | 181 |  |  | $ | 97 |  |  | $ | 181 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0001564590-22-003010:notes:193]
[same as prior period, unchanged from 0001564590-21-054929:notes:192]

[0001564590-22-003010:notes:194]
For the three months ended December 31, 2021 and 2020, the Company recorded an income tax provision of $1.8 million. For the six months ended December 31, 2021 and 2020, the Company recorded an income tax provision of $3.9 million and $3.1 million, respectively.

[0001564590-22-003010:notes:195]
The income tax provisions for the three and six months ended December 31, 2021 and 2020, consisted of (1) taxes on the income of the Company’s foreign subsidiaries, (2) foreign withholding taxes, (3) state taxes in jurisdictions where the Company has no remaining state net operating losses (“NOLs”) and (4) tax expense associated with the establishment of a U.S. deferred tax liability for amortizable goodwill resulting from the acquisition of Enterasys Networks, Inc., the wireless local area network business from Zebra Technologies Corporation, the Campus Fabric Business from Avaya and the Data Center Business from Brocade. The interim income tax provisions for the three and six months ended December 31, 2021 and 2020 were calculated using the discrete effective tax rate method as allowed by ASC 740-270-30-18, “Income Taxes – Interim Reporting.”  The discrete method is applied when the application of the estimated annual effective tax rate is impractical because it is not possible to reliably estimate the annual effective tax rate.  The discrete method treats the year-to-date period as if it was the annual period and determines the income tax expense or benefit on that basis.  The Company believes that, at this time, the use of this discrete method is more appropriate than the annual effective tax rate method as (i) the estimated annual effective tax rate method is not reliable due to the high degree of uncertainty in estimating annual pretax earnings on a jurisdictional basis and (ii) the Company’s ongoing assessment that the recoverability of certain U.S. and Irish deferred tax assets is not more likely than not.

[0001564590-22-003010:notes:196]
The Company has provided a full valuation allowance against all of its U.S. federal and state deferred tax assets as well as a portion of the deferred tax assets in Ireland. A valuation allowance is determined by assessing both negative and positive evidence to determine whether it is “more likely than not” that deferred tax assets are recoverable; such assessment is required on a jurisdiction-by-jurisdiction basis.  The Company’s inconsistent earnings in recent periods, including a cumulative loss over the last three years, coupled with its difficulty in forecasting future revenue trends and the cyclical nature of its business represent sufficient negative evidence to require full valuation allowances against its U.S. federal and state net deferred tax assets as well as a portion of the deferred tax assets in Ireland.  These valuation allowances will be evaluated periodically and can be reversed partially or in whole if business results and the economic environment have sufficiently improved to support realization of some or all of the Company's deferred tax assets.

[0001564590-22-003010:notes:197]
On September 14, 2021, the Company completed its acquisition of Ipanema. This acquisition is treated as a non-taxable stock acquisition and, therefore, Extreme will have carryover tax basis in the assets and liabilities acquired.

[0001564590-22-003010:notes:198]
The Company had $19.1 million of unrecognized tax benefits as of December 31, 2021.  If fully recognized in the future, $0.5 million would impact the effective tax rate and $18.6 million would result in adjustments to deferred tax assets and corresponding adjustments to the valuation allowance with no impact to the effective tax rate.  The Company does not anticipate any events to occur

[0001564590-22-003010:notes:199]
during the next twelve months that would materially reduce the unrealized tax benefit as currently stated in the Company’s condensed consolidated balance sheets.

[0001564590-22-003010:notes:200]
[same as prior period, unchanged from 0001564590-21-054929:notes:198]

[0001564590-22-003010:notes:201]
In general, the Company’s U.S. federal income tax returns are subject to examination by tax authorities for fiscal years 2001 forward due to NOLs and the Company’s state income tax returns are subject to examination for fiscal years 2000 forward due to NOLs. The Company is not currently under audit in any material jurisdictions.


## us-gaap:EarningsPerShareTextBlock

[0001564590-22-003010:notes:202]
[same as prior period, unchanged from 0001564590-21-054929:notes:200]

[0001564590-22-003010:notes:203]
Basic net income (loss) per share is calculated by dividing net income (loss) by the weighted-average number of shares of common stock outstanding during the period. Dilutive income per share is calculated by dividing net income by the weighted-average number of shares of common stock used in the basic net income (loss) per share calculation plus the dilutive effect of shares subject to repurchase, options and unvested RSUs.

[0001564590-22-003010:notes:204]
[same as prior period, unchanged from 0001564590-21-054929:notes:202]

[0001564590-22-003010:notes:205]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | December 31, 2021 |  |  | December 31, 2020 |  |  | December 31, 2021 |  |  | December 31, 2020 |  |
| Net income (loss) |  | $ | 13,341 |  |  | $ | (3,050 | ) |  | $ | 26,037 |  |  | $ | (11,862 | ) |
| Weighted-average shares used in per share calculation - basic |  |  | 129,403 |  |  |  | 123,264 |  |  |  | 128,863 |  |  |  | 122,485 |  |
| Options to purchase common stock |  |  | 702 |  |  |  | — |  |  |  | 677 |  |  |  | — |  |
| Restricted stock units |  |  | 3,340 |  |  |  | — |  |  |  | 3,795 |  |  |  | — |  |
| Employee Stock Purchase Plan shares |  |  | 176 |  |  |  | — |  |  |  | 88 |  |  |  | — |  |
| Weighted-average shares used in per share calculation - diluted |  |  | 133,621 |  |  |  | 123,264 |  |  |  | 133,423 |  |  |  | 122,485 |  |
| Net income (loss) per share - basic and diluted |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income (loss) per share - basic |  | $ | 0.10 |  |  | $ | (0.02 | ) |  | $ | 0.20 |  |  | $ | (0.10 | ) |
| Net income (loss) per share - diluted |  | $ | 0.10 |  |  | $ | (0.02 | ) |  | $ | 0.20 |  |  | $ | (0.10 | ) |

[0001564590-22-003010:notes:206]
[same as prior period, unchanged from 0001564590-21-054929:notes:204]

[0001564590-22-003010:notes:207]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | December 31, 2021 |  |  | December 31, 2020 |  |  | December 31, 2021 |  |  | December 31, 2020 |  |
| Options to purchase common stock |  |  | — |  |  |  | 2,156 |  |  |  | — |  |  |  | 2,345 |  |
| Restricted stock units |  |  | 7 |  |  |  | 9,553 |  |  |  | 8 |  |  |  | 9,003 |  |
| Employee Stock Purchase Plan shares |  |  | 764 |  |  |  | 1,324 |  |  |  | 620 |  |  |  | 1,040 |  |
| Total shares excluded |  |  | 771 |  |  |  | 13,033 |  |  |  | 628 |  |  |  | 12,388 |  |
