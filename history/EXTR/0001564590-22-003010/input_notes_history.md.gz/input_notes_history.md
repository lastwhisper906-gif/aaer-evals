# EXTR note change history — 0001564590-21-054929 → 0001564590-22-003010


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2022-01-28):
[0001564590-22-003010:note_history:1]
The Company currently has arrangements with contract manufacturers and suppliers for the manufacture of its products. Those arrangements allow the contract manufactures to procure long lead-time component inventory based upon a rolling production forecast provided by the Company. The Company is obligated to purchase long lead-time component inventory that its contract manufacturer procures in accordance with the forecast, unless the Company gives notice of order cancellation outside of applicable component lead-times. As of December 31, 2021, the Company had commitments to purchase $53.2 million of inventory.
  (was, 2021-11-05, similarity 0.9942):
[0001564590-21-054929:note_history:1]
The Company currently has arrangements with contract manufacturers and suppliers for the manufacture of its products. Those arrangements allow the contract manufactures to procure long lead-time component inventory based upon a rolling production forecast provided by the Company. The Company is obligated to purchase long lead-time component inventory that its contract manufacturer procures in accordance with the forecast, unless the Company gives notice of order cancellation outside of applicable component lead-times. As of September 30, 2021, the Company had commitments to purchase $64.9 million of inventory.

- changed (2022-01-28):
[0001564590-22-003010:note_history:2]
In accordance with applicable accounting guidance, the Company records accruals for certain of its outstanding legal proceedings, investigations or claims when it is probable that a liability will be incurred, and the amount of loss can be reasonably estimated. The Company evaluates, at least on a quarterly basis, developments in legal proceedings, investigations or claims that could affect the amount of any accrual, as well as any developments that would result in a loss contingency to become both probable and reasonably estimable. When a loss contingency is not both probable and reasonably estimable, the Company does not record a loss accrual. However, if the loss (or an additional loss in excess of any prior accrual) is at least reasonably possible and material and a reasonable estimate can be made, then the Company would make an accrual. The assessment whether a loss is probable or a reasonable possibility, and whether the loss or a range of loss is estimable, involves a series of complex judgments about future events. Litigation is unpredictable, and even if a loss is reasonably possible, the Company may not be able to estimate a range of possible loss, particularly where (i) the damages sought are substantial or indeterminate, (ii) the proceedings are in the early stages, or (iii) the matters involve novel or unsettled legal theories or a large number of parties. In such cases, there is considerable uncertainty regarding the ultimate resolution of such matters, including the amount of any possible loss, fine or penalty. An adverse resolution of one or more of such matters could have a material adverse effect on the Company's results of operations in a particular quarter or fiscal year.
  (was, 2021-11-05, similarity 0.7221):
[0001564590-21-054929:note_history:2]
In accordance with applicable accounting guidance, the Company records accruals for certain of its outstanding legal proceedings, investigations or claims when it is probable that a liability will be incurred, and the amount of loss can be reasonably estimated. The Company evaluates, at least on a quarterly basis, developments in legal proceedings, investigations or claims that could affect the amount of any accrual, as well as any developments that would result in a loss contingency to become both probable and reasonably estimable. When a loss contingency is not both probable and reasonably estimable, the Company does not record a loss accrual. However, if the loss (or an additional loss in excess of any prior accrual) is at least reasonably possible and material, then the Company would disclose an estimate of the possible loss or range of loss, if such estimate can be made, or disclose that an estimate cannot be made. The assessment whether a loss is probable or a reasonable possibility, and whether the loss or a range of loss is estimable, involves a series of complex judgments about future events. Even if a loss is reasonably possible, the Company may not be

- changed (2022-01-28):
[0001564590-22-003010:note_history:3]
On April 19, 2017, XR Communications, LLC (“XR”) (d/b/a Vivato Technologies) filed a patent infringement lawsuit against the Company in the Central District of California. The operative Second Amended Complaint asserts infringement of certain U.S. Patent based on the Company’s manufacture, use, sale, offer for sale, and/or importation into the United States of certain access points and routers supporting multi-user, multiple-input, multiple-output technology. XR seeks unspecified damages, on-going
  (was, 2021-11-05, similarity 0.8881):
[0001564590-21-054929:note_history:3]
On April 19, 2017, XR Communications, LLC (“XR”) (d/b/a Vivato Technologies) filed a patent infringement lawsuit against the Company in the Central District of California. The operative Second Amended Complaint asserts infringement of certain U.S. Patent based on the Company’s manufacture, use, sale, offer for sale, and/or importation into the United States of certain access points and routers supporting multi-user, multiple-input, multiple-output technology. XR seeks unspecified damages, on-going royalties, pre- and post-judgment interest, and attorneys’ fees. The stay issued by the District Court in 2018 has been lifted.

- added (2022-01-28):
[0001564590-22-003010:note_history:4]
royalties, pre- and post-judgment interest, and attorneys’ fees. The Court has dismissed the case with prejudice.  The deadline for XR to appeal the dismissal is February 3, 2022.

- changed (2022-01-28):
[0001564590-22-003010:note_history:5]
On February 1, 2018, Orckit IP, LLC (“Orckit”) filed a patent infringement lawsuit against the Company and its Irish and German subsidiaries in the District Court in Dusseldorf, Germany. The lawsuit alleges direct and indirect infringement of the German portion of a patent (“EP ‘364”) based on the offer, distribution, use, possession and/or importation into Germany of certain network switches that equipped with the ExtremeXOS operating system. Orckit is seeking injunctive relief, accounting, and an unspecified declaration of liability for damages and costs of the lawsuit. On January 28, 2020, the Court rendered a decision in the infringement case in favor of the Company. The matter is proceeding through the appellate process, and an oral hearing was held on October 21, 2021.  The Court has appointed an expert to provide an opinion and a decision is pending.
  (was, 2021-11-05, similarity 0.9621):
[0001564590-21-054929:note_history:5]
On February 1, 2018, Orckit IP, LLC (“Orckit”) filed a patent infringement lawsuit against the Company and its Irish and German subsidiaries in the District Court in Dusseldorf, Germany. The lawsuit alleges direct and indirect infringement of the German portion of a patent (“EP ’364”) based on the offer, distribution, use, possession and/or importation into Germany of certain network switches that equipped with the ExtremeXOS operating system. Orckit is seeking injunctive relief, accounting, and an unspecified declaration of liability for damages and costs of the lawsuit. On January 28, 2020, the Court rendered a decision in the infringement case in favor of the Company. The matter is proceeding through the appellate process, and an oral hearing was held on October 21, 2021.  A decision is pending.

- changed (2022-01-28):
[0001564590-22-003010:note_history:6]
On April 23, 2019, Orckit filed an extension of the patent infringement complaint against the Company and its Irish and German subsidiaries in the District Court in Dusseldorf, Germany. With this extension, Orckit alleges infringement of the German portion of a second patent (“EP ‘077”) based on the offer, distribution, use, possession and/or importation into Germany of certain network switches that the Company no longer sells in Germany. Orckit is seeking injunctive relief, accounting and sales information, and a declaration of liability for damages as well as costs of the lawsuit. On October 13, 2020, the Court issued an infringement decision against the Company and granted to Orckit the right to enforce the judgment against the Company, which Orckit has provided notification to the Company that it will enforce the judgment. In the rendering of account, Orckit was informed that the products at issue were in end of sale status prior to the filing of the ‘077 complaint. The Company has appealed the infringement decision, and the matter is proceeding through the appellate process.
  (was, 2021-11-05, similarity 0.8429):
[0001564590-21-054929:note_history:6]
On April 23, 2019, Orckit filed an extension of the patent infringement complaint against the Company and its Irish and German subsidiaries in the District Court in Dusseldorf, Germany. With this extension, Orckit alleges infringement of the German portion of a second patent (“EP ‘077”) based on the offer, distribution, use, possession and/or importation into Germany of certain network switches that the Company no longer sells in Germany. Orckit is seeking injunctive relief, accounting and sales information, and a declaration of liability for damages as well as costs of the lawsuit. On October 13, 2020, the Court issued an infringement decision against the Company and granted to Orckit the right to enforce the judgment against the Company, which Orckit has provided notification to the Company that it will enforce the judgment. The matter is proceeding through the appellate process.

- changed (2022-01-28):
[0001564590-22-003010:note_history:7]
The Company filed a nullity action related to the EP ‘364 patent on May 3, 2018, and one related to the EP ‘077 patent on October 31, 2019, both in the Federal Patent Court in Munich. The court found the EP ‘364 patent to be valid and the Company has filed an appeal.  The case filed to seek to invalidate the EP ‘077 patent is proceeding.
  (was, 2021-11-05, similarity 0.9642):
[0001564590-21-054929:note_history:7]
The Company filed a nullity action related to the EP ‘364 patent on May 3, 2018, and one related to the EP ‘077 patent on October 31, 2019, both in the Federal Patent Court in Munich. The court found the EP ‘364 patent to be valid and the Company is considering an appeal.  The case filed to seek to invalidate the EP ‘077 patent is proceeding.

- changed (2022-01-28):
[0001564590-22-003010:note_history:8]
On October 26, 2020, SNMP Research, Inc. and SNMP Research International, Inc. (collectively, “SNMP”) filed a lawsuit against the Company in the Eastern District of Tennessee for copyright infringement, alleging that the Company was not properly licensed to use its software.  SNMP is seeking actual damages and profits attributed to the infringement, as well as equitable relief. The Company has filed a motion to dismiss and a motion to transfer the case to the Northern District of California. Both motions are pending. A trial date has been set for February 2023.
  (was, 2021-11-05, similarity 0.9803):
[0001564590-21-054929:note_history:8]
On October 26, 2020, SNMP Research, Inc. and SNMP Research International, Inc. (collectively, “SNMP”) filed a lawsuit against the Company in the Eastern District of Tennessee for copyright infringement, alleging that the Company was not properly licensed to use their software.  SNMP is seeking actual damages and profits attributed to the infringement, as well as equitable relief. The Company has filed a motion to dismiss and a motion to transfer the case to the Northern District of California. Both motions are pending. A trial date has been set for November 2022.

- changed (2022-01-28):
[0001564590-22-003010:note_history:9]
Subject to certain limitations, the Company may be obligated to indemnify its current and former directors, officers and employees. These obligations arise under the terms of its certificate of incorporation, its bylaws, applicable contracts, and applicable law. The obligation to indemnify, where applicable, generally means that the Company is required to pay or reimburse, and in certain circumstances the Company has paid or reimbursed, the individuals’ reasonable legal expenses and possibly damages and other liabilities incurred in connection with certain legal matters. The Company also procures Directors and Officers liability insurance to help cover its defense and/or indemnification costs, although its ability to recover such costs through insurance is uncertain.  While it is not possible to estimate the maximum potential amount that could be owed under these governing documents and agreements due to the Company’s limited history with prior indemnification claims, indemnification (including defense) costs could, in the future, have a material adverse effect on the Company’s consolidated financial position, results of operations and cash flows.
  (was, 2021-11-05, similarity 0.7148):
[0001564590-21-054929:note_history:9]
Subject to certain limitations, the Company may be obligated to indemnify its current and former directors, officers and employees. These obligations arise under the terms of its certificate of incorporation, its bylaws, applicable contracts, and applicable law. The obligation to indemnify, where applicable, generally means that the Company is required to pay or reimburse, and in certain circumstances the Company has paid or reimbursed, the individuals' reasonable legal expenses and possibly damages and other liabilities incurred in connection with certain legal matters. The Company also procures Directors and Officers liability insurance to

- removed (2022-01-28):
[0001564590-21-054929:note_history:10]
able to estimate a range of possible loss, particularly where (i) the damages sought are substantial or indeterminate, (ii) the proceedings are in the early stages, or (iii) the matters involve novel or unsettled legal theories or a large number of parties. In such cases, there is considerable uncertainty regarding the ultimate resolution of such matters, including the amount of any possible loss, fine or penalty. An adverse resolution of one or more of such matters could have a material adverse effect on the Company's results of operations in a particular quarter or fiscal year.

- removed (2022-01-28):
[0001564590-21-054929:note_history:11]
help cover its defense and/or indemnification costs, although its ability to recover such costs through insurance is uncertain.  While it is not possible to estimate the maximum potential amount that could be owed under these governing documents and agreements due to the Company’s limited history with prior indemnification claims, indemnification (including defense) costs could, in the future, have a material adverse effect on the Company’s consolidated financial position, results of operations and cash flows.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2022-01-28):
[0001564590-22-003010:note_history:12]
The unaudited condensed consolidated financial statements of Extreme included herein have been prepared under the rules and regulations of the Securities and Exchange Commission (“SEC”).  Certain information and footnote disclosures normally included in financial statements prepared in accordance with U.S. generally accepted accounting principles have been condensed or omitted under such rules and regulations.  The condensed consolidated balance sheets at June 30, 2021 was derived from audited financial statements as of that date but does not include all disclosures required by generally accepted accounting principles for complete financial statements. These interim financial statements and notes should be read in conjunction with the Company’s audited consolidated financial statements and notes thereto included in the Company’s Annual Report on Form 10-K for the fiscal year ended June 30, 2021.
  (was, 2021-11-05, similarity 0.9994):
[0001564590-21-054929:note_history:12]
The unaudited condensed consolidated financial statements of Extreme included herein have been prepared under the rules and regulations of the Securities and Exchange Commission (“SEC”).  Certain information and footnote disclosures normally included in financial statements prepared in accordance with U.S. generally accepted accounting principles have been condensed or omitted under such rules and regulations.  The condensed consolidated balance sheet at June 30, 2021 was derived from audited financial statements as of that date but does not include all disclosures required by generally accepted accounting principles for complete financial statements. These interim financial statements and notes should be read in conjunction with the Company’s audited consolidated financial statements and notes thereto included in the Company’s Annual Report on Form 10-K for the fiscal year ended June 30, 2021.

- changed (2022-01-28):
[0001564590-22-003010:note_history:13]
The unaudited condensed consolidated financial statements reflect all adjustments, consisting only of normal recurring adjustments that, in the opinion of management, are necessary for a fair presentation of the results of operations and cash flows for the interim periods presented and the financial condition of Extreme at December 31, 2021. The results of operations for the three and six months ended December 31, 2021 are not necessarily indicative of the results that may be expected for fiscal 2022 or any future periods.
  (was, 2021-11-05, similarity 0.775):
[0001564590-21-054929:note_history:13]
The unaudited condensed consolidated financial statements reflect all adjustments, consisting only of normal recurring adjustments that, in the opinion of management, are necessary for a fair presentation of the results of operations and cash flows for the interim periods presented and the financial condition of Extreme at September 30, 2021. The results of operations for the three months ended September 30, 2021 are not necessarily indicative of the results that may be expected for fiscal 2022 or any future periods.


## us-gaap:SignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2022-01-28):
[0001564590-22-003010:note_history:14]
In December 2019, the Financial Accounting Standards Board (“the FASB”) issued ASU 2019-12, Income Taxes – Simplifying the Accounting for Income Taxes (Topic 740), which reduces the complexity of accounting for income taxes including the removal of certain exceptions to the general principles of Accounting Standards Codification (“ASC”) 740, Income Taxes, and simplification in several other areas such as accounting for franchise tax (or similar tax) that is partially based on income. This standard is effective for fiscal years beginning after December 15, 2020, including interim periods within the fiscal year. The standard was adopted on July 1, 2021 and did not have a material impact on the Company’s financial statements upon adoption.
  (was, 2021-11-05, similarity 0.9331):
[0001564590-21-054929:note_history:14]
In December 2019, the FASB issued ASU 2019-12, Income taxes – Simplifying the Accounting for Income Taxes (Topic 740), which reduces the complexity of accounting for income taxes including the removal of certain exceptions to the general principles of ASC 740, Income Taxes, and simplification in several other areas such as accounting for franchise tax (or similar tax) that is partially based on income. This standard is effective for fiscal years beginning after December 15, 2020, including interim periods within the fiscal year. The standard was adopted on July 1, 2021 and did not have a material impact on the Company’s financial statements upon adoption.

- added (2022-01-28):
[0001564590-22-003010:note_history:15]
Recently Issued and Adopted Accounting Pronouncements

- added (2022-01-28):
[0001564590-22-003010:note_history:16]
In October 2021, the FASB issued ASU 2021-08, Business Combinations (Topic 805): Accounting for Contract Assets and Contract Liabilities from Contracts with Customers, which requires contract assets and contract liabilities acquired in a business combination to be recognized and measured by the acquirer on the acquisition date in accordance with ASC 606, Revenue from Contracts with Customers, as if it had originated the contracts. Under the current business combinations guidance, such assets and liabilities are recognized by the acquirer at fair value on the acquisition date. ASU 2021-08 is effective for annual periods beginning after December 15, 2022 and interim periods within those annual periods, with early adoption permitted, including adoption in an interim period. The Company has elected to early adopt the standard in the quarter ended December 31, 2021 and retrospectively applied the standard to the acquisition that happened in the current fiscal year beginning July 1, 2021. The application of the guidance increased the deferred revenue balance acquired through the acquisition of Ipanema by $7.1 million as of the acquisition date.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2022-01-28):
[0001564590-22-003010:note_history:17]
|  |  | December 31, 2021 |  |  | June 30, 2021 |  |
| Current portion of long-term debt: |  |  |  |  |  |  |  |  |
| Term Loan |  | $ | 30,875 |  |  | $ | 26,125 |  |
| Less: unamortized debt issuance costs |  |  | (2,333 | ) |  |  | (2,404 | ) |
| Current portion of long-term debt |  | $ | 28,542 |  |  | $ | 23,721 |  |
| Long-term debt, less current portion: |  |  |  |  |  |  |  |  |
| Term Loan |  | $ | 292,000 |  |  | $ | 320,625 |  |
| Less: unamortized debt issuance costs |  |  | (3,542 | ) |  |  | (4,760 | ) |
| Total long-term debt, less current portion |  |  | 288,458 |  |  |  | 315,865 |  |
| Total debt |  | $ | 317,000 |  |  | $ | 339,586 |  |
  (was, 2021-11-05, similarity 0.9934):
[0001564590-21-054929:note_history:17]
|  |  | September 30, 2021 |  |  | June 30, 2021 |  |
| Current portion of long-term debt: |  |  |  |  |  |  |  |  |
| Term Loan |  | $ | 28,500 |  |  | $ | 26,125 |  |
| Less: unamortized debt issuance costs |  |  | (2,356 | ) |  |  | (2,404 | ) |
| Current portion of long-term debt |  | $ | 26,144 |  |  | $ | 23,721 |  |
| Long-term debt, less current portion: |  |  |  |  |  |  |  |  |
| Term Loan |  | $ | 301,500 |  |  | $ | 320,625 |  |
| Less: unamortized debt issuance costs |  |  | (4,121 | ) |  |  | (4,760 | ) |
| Total long-term debt, less current portion |  |  | 297,379 |  |  |  | 315,865 |  |
| Total debt |  | $ | 323,523 |  |  | $ | 339,586 |  |

- changed (2022-01-28):
[0001564590-22-003010:note_history:18]
The 2019 Credit Agreement provides for a five-year first lien term loan facility in an aggregate principal amount of $380.0 million and a five-year revolving loan facility in an aggregate principal amount of $75.0 million (the “2019 Revolving Facility”).  In addition, the Company may request incremental term loans and/or incremental revolving loan commitments in an aggregate amount not to exceed the sum of $100.0 million, plus an unlimited amount that is subject to pro forma compliance with certain financial tests. On August 9, 2019, the Company used the additional proceeds from the term loan to partially fund the Acquisition and for working capital and general corporate purposes.
  (was, 2021-11-05, similarity 0.9992):
[0001564590-21-054929:note_history:18]
The 2019 Credit Agreement provides for a five-year first lien term loan facility in an aggregate principal amount of $380 million and a five-year revolving loan facility in an aggregate principal amount of $75 million (the “2019 Revolving Facility”).  In addition, the Company may request incremental term loans and/or incremental revolving loan commitments in an aggregate amount not to exceed the sum of $100 million plus an unlimited amount that is subject to pro forma compliance with certain financial tests. On August 9, 2019, the Company used the additional proceeds from the term loan to partially fund the Acquisition and for working capital and general corporate purposes.

- changed (2022-01-28):
[0001564590-22-003010:note_history:19]
On April 8, 2020, the Company entered into the first amendment to the 2019 Credit Agreement (the “First Amendment”) to waive certain terms and financial covenants of the 2019 Credit Agreement through July 31, 2020. On May 8, 2020, the Company entered into the second amendment to the 2019 Credit Agreement (the “Second Amendment”), which superseded the First Amendment and provided certain revised terms and financial covenants through March 31, 2021. Subsequent to March 31, 2021, the original terms and financial covenants under the 2019 Credit Agreement resumed in effect. The Second Amendment required the Company to maintain certain minimum cash requirement and certain financial metrics at the end of each fiscal quarter through March 31, 2021. Under the terms of the Second Amendment, the Company was not permitted to exceed $55.0 million in its outstanding balance under the 2019 Revolving Facility, the applicable margin for Eurodollar rate was 4.5%, and the Company was restricted from pursuing certain activities such as incurring additional debt, stock repurchases, making acquisitions or declaring a dividend, until the Company was in compliance with the original covenants of the 2019 Credit Agreement.
  (was, 2021-11-05, similarity 0.7551):
[0001564590-21-054929:note_history:19]
On April 8, 2020, the Company entered into the first amendment to the 2019 Credit Agreement (the “First Amendment”) to waive certain terms and financial covenants of the 2019 Credit Agreement through July 31, 2020. On May 8, 2020, the Company entered into the second amendment to the 2019 Credit Agreement (the “Second Amendment”) which superseded the First Amendment and provided certain revised terms and financial covenants through March 31, 2021. Subsequent to March 31, 2021, the original terms and financial covenants under the 2019 Credit Agreement resumed in effect. The Second Amendment required the Company to maintain certain minimum cash requirement and certain financial metrics at the end of each fiscal quarter through March 31, 2021.

- added (2022-01-28):
[0001564590-22-003010:note_history:20]
The Second Amendment provided for the Company to end the covenant Suspension Period early and revert to the covenants and interest rates per the original terms of the 2019 Credit Agreement dated August 9, 2019 by filing a Suspension Period Early Termination Notice and Covenant Certificate demonstrating compliance. For the twelve-month period ended March 31, 2021, the

- added (2022-01-28):
[0001564590-22-003010:note_history:21]
Company’s financial performance was in compliance with the original covenants defined in the 2019 Credit Agreement and, as such, the Company filed a Suspension Early Termination Notice and Covenant Certificate with the administration agent subsequent to filing the Company’s Quarterly Report on Form 10-Q for the period ended March 31, 2021. Returning to compliance with the covenants per the original terms of the 2019 Credit Agreement dated August 9, 2019 resulted in the Company’s Eurodollar loan spread decreasing from 4.5% during the suspension period to 2.75% and unused facility commitment fee decreasing from 0.4% to 0.35%, and the limitation on revolver borrowings being removed effective May 1, 2021 after filing of the certificate with the administrative agent.

- changed (2022-01-28):
[0001564590-22-003010:note_history:22]
Financing costs incurred in connection with obtaining long-term financing are deferred and amortized over the term of the related indebtedness or credit agreement. During the year ended June 30, 2020, the Company incurred $10.5 million of deferred financing costs in conjunction with the 2019 Credit Agreement and $1.5 million of deferred financing costs from the amendments, and continues to amortize $1.6 million of debt issuance costs as of August 9, 2019 that were associated with the previous facility. The interest rate as of December 31, 2021 was 1.86% and as of December 31, 2020 was 4.65%.
  (was, 2021-11-05, similarity 0.9388):
[0001564590-21-054929:note_history:22]
Financing costs incurred in connection with obtaining long-term financing are deferred and amortized over the term of the related indebtedness or credit agreement. During the year ended June 30, 2020, the Company incurred $10.5 million of deferred financing costs in conjunction with the 2019 Credit Agreement and $1.5 million of deferred financing costs from the amendments, and continues to amortize $1.6 million of debt issuance costs as of August 9, 2019 that were associated with the previous facility. The interest rate as of September 30, 2021 was 2.4%. and as of September 30, 2020 was 4.9%.

- changed (2022-01-28):
[0001564590-22-003010:note_history:23]
Amortization of deferred financing costs included in “Interest expense” in the accompanying condensed consolidated statements of operations totaled $0.7 million and $0.8 million for the three months ended December 31, 2021 and 2020, and totaled $1.5 million each for the six months ended December 31, 2021 and 2020.
  (was, 2021-11-05, similarity 0.8454):
[0001564590-21-054929:note_history:23]
Amortization of deferred financing costs included in “Interest expense” in the accompanying condensed consolidated statements of operations totaled $0.8 million and $0.8 million for the three months ended September 30, 2021 and 2020

- changed (2022-01-28):
[0001564590-22-003010:note_history:24]
During the fiscal year ended June 30, 2021, the Company repaid $55.0 million against its 2019 Revolving Facility’s outstanding balance of $55.0 million and had no remaining outstanding balance at December 31, 2021. The Company had $60.2 million of availability under the 2019 Revolving Facility as of December 31, 2021. During the six months ended December 31, 2021, the Company made an additional payment of $12.0 million against its term loan facility.
  (was, 2021-11-05, similarity 0.7286):
[0001564590-21-054929:note_history:24]
During the fiscal year ended June 30, 2021, the Company repaid $55.0 million against its 2019 Revolving Facility’s outstanding balance of $55.0 million and has no remaining outstanding balance at September 30, 2021. The Company has $60.2 million of availability under the 2019 Revolving Facility as of September 30, 2021. During the three months ended September 30, 2021, the Company made an additional payment of $12 million against its term loan facility.

- changed (2022-01-28):
[0001564590-22-003010:note_history:25]
The Company had $14.8 million of outstanding letters of credit as of December 31, 2021.
  (was, 2021-11-05, similarity 0.9682):
[0001564590-21-054929:note_history:25]
The Company had $14.8 million of outstanding letters of credit as of September 30, 2021.

- removed (2022-01-28):
[0001564590-21-054929:note_history:26]
Under the terms of the Second Amendment, the Company was not permitted to exceed $55.0 million in its outstanding balance under the 2019 Revolving Facility, the applicable margin for Eurodollar rate was 4.5%, and the Company was restricted from pursuing certain activities such as incurring additional debt, stock repurchases, making acquisitions or declaring a dividend, until the Company was in compliance with the original covenants of the 2019 Credit Agreement.

- removed (2022-01-28):
[0001564590-21-054929:note_history:27]
The Second Amendment provided for the Company to end the covenant Suspension Period early and revert to the covenants and interest rates per the original terms of the 2019 Credit Agreement dated August 9, 2019 by filing a Suspension Period Early Termination Notice and Covenant Certificate demonstrating compliance. For the twelve-month period ended March 31, 2021 the Company’s financial performance was in compliance with the original covenants defined in the 2019 Credit Agreement and as such the Company filed a Suspension Early Termination Notice and Covenant Certificate with the administration agent subsequent to filing our Form 10-Q for the quarterly period ended March 31, 2021. Returning to compliance with the covenants per the original terms of the 2019 Credit Agreement dated August 9, 2019 resulted in the Company’s Eurodollar loan spread decreasing from 4.5% during the suspension period to 2.75% and unused facility commitment fee decreasing from 0.4% to 0.35%, and the limitation on revolver borrowings being removed effective May 1, 2021 after filing of the certificate with the administrative agent.


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2022-01-28):
[0001564590-22-003010:note_history:28]
|  |  | December 31, 2021 |  |  | June 30, 2021 |  |
| Current portion of long-term debt: |  |  |  |  |  |  |  |  |
| Term Loan |  | $ | 30,875 |  |  | $ | 26,125 |  |
| Less: unamortized debt issuance costs |  |  | (2,333 | ) |  |  | (2,404 | ) |
| Current portion of long-term debt |  | $ | 28,542 |  |  | $ | 23,721 |  |
| Long-term debt, less current portion: |  |  |  |  |  |  |  |  |
| Term Loan |  | $ | 292,000 |  |  | $ | 320,625 |  |
| Less: unamortized debt issuance costs |  |  | (3,542 | ) |  |  | (4,760 | ) |
| Total long-term debt, less current portion |  |  | 288,458 |  |  |  | 315,865 |  |
| Total debt |  | $ | 317,000 |  |  | $ | 339,586 |  |
  (was, 2021-11-05, similarity 0.9934):
[0001564590-21-054929:note_history:28]
|  |  | September 30, 2021 |  |  | June 30, 2021 |  |
| Current portion of long-term debt: |  |  |  |  |  |  |  |  |
| Term Loan |  | $ | 28,500 |  |  | $ | 26,125 |  |
| Less: unamortized debt issuance costs |  |  | (2,356 | ) |  |  | (2,404 | ) |
| Current portion of long-term debt |  | $ | 26,144 |  |  | $ | 23,721 |  |
| Long-term debt, less current portion: |  |  |  |  |  |  |  |  |
| Term Loan |  | $ | 301,500 |  |  | $ | 320,625 |  |
| Less: unamortized debt issuance costs |  |  | (4,121 | ) |  |  | (4,760 | ) |
| Total long-term debt, less current portion |  |  | 297,379 |  |  |  | 315,865 |  |
| Total debt |  | $ | 323,523 |  |  | $ | 339,586 |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2022-01-28):
[0001564590-22-003010:note_history:29]
The Company operates in three geographic regions: Americas, which includes the United States, Canada, Mexico, Central America and South America; EMEA, which includes Europe, Russia, Middle East and Africa; and APAC, which includes Asia Pacific, China, South Asia and Japan. The following table sets forth the Company’s revenues disaggregated by sales channel and geographic region based on the billing addresses of its customers (in thousands):
  (was, 2021-11-05, similarity 0.9989):
[0001564590-21-054929:note_history:29]
The Company operates in three geographic regions: Americas, which includes the United States, Canada, Mexico, Central America and South America; EMEA, which includes Europe, Russia, Middle East and Africa; and APAC, which includes Asia Pacific, China, South Asia and Japan. The following table sets forth the Company’s revenues disaggregated by sales channel and geographic region based on the billing addresses of its customer’s (in thousands):

- changed (2022-01-28):
[0001564590-22-003010:note_history:30]
|  |  | Three Months Ended |  |
|  |  | December 31, 2021 |  |  | December 31, 2020 |  |
|  |  | Distributor |  | Direct |  | Total |  |  | Distributor |  | Direct |  | Total |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  | $ | 68,565 |  | $ | 68,585 |  | $ | 137,150 |  |  | $ | 46,506 |  | $ | 58,744 |  | $ | 105,250 |  |
| Other |  |  | 3,865 |  |  | 4,955 |  |  | 8,820 |  |  |  | 8,950 |  |  | 3,648 |  |  | 12,598 |  |
| Total Americas |  |  | 72,430 |  |  | 73,540 |  |  | 145,970 |  |  |  | 55,456 |  |  | 62,392 |  |  | 117,848 |  |
| EMEA |  |  | 68,934 |  |  | 42,128 |  |  | 111,062 |  |  |  | 69,602 |  |  | 34,220 |  |  | 103,822 |  |
| APAC |  |  | 5,034 |  |  | 18,867 |  |  | 23,901 |  |  |  | 2,793 |  |  | 17,665 |  |  | 20,458 |  |
| Total net revenues |  | $ | 146,398 |  | $ | 134,535 |  | $ | 280,933 |  |  | $ | 127,851 |  | $ | 114,277 |  | $ | 242,128 |  |
  (was, 2021-11-05, similarity 0.9889):
[0001564590-21-054929:note_history:30]
|  |  | Three Months Ended |  |
|  |  | September 30, 2021 |  |  | September 30, 2020 |  |
|  |  | Distributor |  | Direct |  | Total |  |  | Distributor |  | Direct |  | Total |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  | $ | 56,068 |  | $ | 67,331 |  | $ | 123,399 |  |  | $ | 60,670 |  | $ | 57,347 |  | $ | 118,017 |  |
| Other |  |  | 7,799 |  |  | 3,367 |  |  | 11,166 |  |  |  | 8,241 |  |  | 4,090 |  |  | 12,331 |  |
| Total Americas |  |  | 63,867 |  |  | 70,698 |  |  | 134,565 |  |  |  | 68,911 |  |  | 61,437 |  |  | 130,348 |  |
| EMEA |  |  | 77,898 |  |  | 35,731 |  |  | 113,629 |  |  |  | 47,529 |  |  | 33,576 |  |  | 81,105 |  |
| APAC |  |  | 4,335 |  |  | 15,155 |  |  | 19,490 |  |  |  | 5,051 |  |  | 19,298 |  |  | 24,349 |  |
| Total net revenues |  | $ | 146,100 |  | $ | 121,584 |  | $ | 267,684 |  |  | $ | 121,491 |  | $ | 114,311 |  | $ | 235,802 |  |

- added (2022-01-28):
[0001564590-22-003010:note_history:31]
|  |  | Six Months Ended |  |
|  |  | December 31, 2021 |  |  | December 31, 2020 |  |
|  |  | Distributor |  | Direct |  | Total |  |  | Distributor |  | Direct |  | Total |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  | $ | 124,633 |  | $ | 135,916 |  | $ | 260,549 |  |  | $ | 107,176 |  | $ | 116,091 |  | $ | 223,267 |  |
| Other |  |  | 11,664 |  |  | 8,322 |  |  | 19,986 |  |  |  | 17,191 |  |  | 7,738 |  |  | 24,929 |  |
| Total Americas |  |  | 136,297 |  |  | 144,238 |  |  | 280,535 |  |  |  | 124,367 |  |  | 123,829 |  |  | 248,196 |  |
| EMEA |  |  | 146,832 |  |  | 77,859 |  |  | 224,691 |  |  |  | 117,131 |  |  | 67,796 |  |  | 184,927 |  |
| APAC |  |  | 9,369 |  |  | 34,022 |  |  | 43,391 |  |  |  | 7,844 |  |  | 36,963 |  |  | 44,807 |  |
| Total net revenues |  | $ | 292,498 |  | $ | 256,119 |  | $ | 548,617 |  |  | $ | 249,342 |  | $ | 228,588 |  | $ | 477,930 |  |

- added (2022-01-28):
[0001564590-22-003010:note_history:32]
For the six months ended December 31, 2021, the Company generated 10% of its revenues from the Netherlands. For the three months ended December 31, 2020, the Company generated 11% of its revenues from the Netherlands and 11% of its revenues from Germany. For the six months ended December 31, 2020, the Company generated 10% of its revenues from the Netherlands and 10% of its revenues from Germany. No other foreign country accounted for 10% or more of revenue for the three and six months ended December 31, 2021 or 2020.

- removed (2022-01-28):
[0001564590-21-054929:note_history:33]
For the three months ended September 30, 2021 the Company generated 11% of its revenues from the Netherlands and 10% of its revenues from the Germany. No other foreign country accounted for 10% or more of revenue for the three months ended September 30, 2021 or 2020.


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2022-01-28):
[0001564590-22-003010:note_history:34]
The Company accounts for revenues in accordance with ASU 2014-09, Revenue from Contracts from Customers (Topic 606).  The Company derives the majority of its revenues from sales of its networking equipment, with the remaining revenues generated from sales of services and subscriptions, which primarily includes maintenance contracts and software subscriptions delivered as software as a service (“SaaS”) and additional revenues from professional services, and training for its products. The Company sells its products, maintenance contracts and SaaS direct to customers and to partners in two distribution channels, or tiers. The first tier consists of a limited number of independent distributors that stock its products and sell primarily to resellers.  The second tier of the distribution channel consists of non-stocking distributors and value-added resellers that sell directly to end-users.  Products and services may be sold separately or in bundled packages.
  (was, 2021-11-05, similarity 0.9795):
[0001564590-21-054929:note_history:34]
The Company accounts for revenues in accordance with ASU 2014-09, Revenue from Contracts from Customers (Topic 606), which the Company adopted on July 1, 2017.  The Company derives the majority of its revenues from sales of its networking equipment, with the remaining revenues generated from sales of services and subscriptions, which primarily includes maintenance contracts and software subscriptions delivered as software as a service (“SaaS”) and additional revenues from professional services, and training for its products. The Company sells its products, maintenance contracts and SaaS direct to customers and to partners in two distribution channels, or tiers. The first tier consists of a limited number of independent distributors that stock its products and sell primarily to resellers.  The second tier of the distribution channel consists of non-stocking distributors and value-added resellers that sell directly to end-users.  Products and services may be sold separately or in bundled packages.

- changed (2022-01-28):
[0001564590-22-003010:note_history:35]
On December 31, 2021, the Company had $373.2 million of remaining performance obligations, which are primarily comprised of deferred maintenance and SaaS revenues. The Company expects to recognize approximately 38% of its deferred revenue as revenue in fiscal 2022, an additional 34% in fiscal 2023 and 28% of the balance thereafter.
  (was, 2021-11-05, similarity 0.892):
[0001564590-21-054929:note_history:35]
On September 30, 2021, the Company had $356.0 million of remaining performance obligations, which are primarily comprised of deferred maintenance and SaaS revenues.  The Company expects to recognize approximately 52 percent of its deferred revenue as revenue in fiscal 2022, an additional 25 percent in fiscal 2023 and 23 percent of the balance thereafter.

- changed (2022-01-28):
[0001564590-22-003010:note_history:36]
Revenue recognized for the three months ended December 31, 2021 and 2020 that was included in the deferred revenue balance at the beginning of each period was $81.9 million and $68.8 million, respectively. Revenue recognized for the six months ended December 31, 2021 and 2020 that was included in the deferred revenue balance at the beginning of each period was $132.5 million and $120.5 million, respectively.
  (was, 2021-11-05, similarity 0.6597):
[0001564590-21-054929:note_history:36]
Revenue recognized for the three months ended September 30, 2021 and 2020 that was included in the deferred revenue balance at the beginning of each period was $73.4 million and $66.9 million, respectively.

- changed (2022-01-28):
[0001564590-22-003010:note_history:37]
Contract Costs. The Company recognizes the incremental costs of obtaining contracts as an expense when incurred if the amortization period of the assets that the Company otherwise would have recognized is one year or less.  Management expects that commission fees paid to sales representatives as a result of obtaining service contracts and contract renewals are recoverable and therefore the Company’s condensed consolidated balance sheets included capitalized balances in the amount of $14.2 million and $13.1 million at December 31, 2021 and June 30, 2021, respectively. Capitalized commission fees are amortized on a straight-line basis over the average period of service contracts of approximately three years, and are included in “Sales and marketing” in the accompanying condensed consolidated statements of operations. Amortization recognized during the three months ended December 31, 2021 and 2020, was $1.8 million and $1.2 million, respectively. Amortization recognized during the six months ended December 31, 2021 and 2020, was $3.6 million and $2.5 million, respectively.
  (was, 2021-11-05, similarity 0.934):
[0001564590-21-054929:note_history:37]
Contract Costs. The Company recognizes the incremental costs of obtaining contracts as an expense when incurred if the amortization period of the assets that the Company otherwise would have recognized is one year or less.  Management expects that commission fees paid to sales representatives as a result of obtaining service contracts and contract renewals are recoverable and therefore the Company’s condensed consolidated balance sheets included capitalized balances in the amount of $13.5 million and $13.1 million at September 30, 2021 and June 30, 2021, respectively. Capitalized commission fees are amortized on a straight-line basis over the average period of service contracts of approximately three years, and are included in “Sales and marketing” in the accompanying condensed consolidated statements of operations. Amortization recognized during the three months ended September 30, 2021 and 2020, was $1.8 million and $1.2 million, respectively.

- changed (2022-01-28):
[0001564590-22-003010:note_history:38]
The Company operates in three geographic regions: Americas, which includes the United States, Canada, Mexico, Central America and South America; EMEA, which includes Europe, Russia, Middle East and Africa; and APAC, which includes Asia Pacific, China, South Asia and Japan. The following table sets forth the Company’s revenues disaggregated by sales channel and geographic region based on the billing addresses of its customers (in thousands):
  (was, 2021-11-05, similarity 0.9989):
[0001564590-21-054929:note_history:38]
The Company operates in three geographic regions: Americas, which includes the United States, Canada, Mexico, Central America and South America; EMEA, which includes Europe, Russia, Middle East and Africa; and APAC, which includes Asia Pacific, China, South Asia and Japan. The following table sets forth the Company’s revenues disaggregated by sales channel and geographic region based on the billing addresses of its customer’s (in thousands):

- changed (2022-01-28):
[0001564590-22-003010:note_history:39]
|  |  | Three Months Ended |  |
|  |  | December 31, 2021 |  |  | December 31, 2020 |  |
|  |  | Distributor |  | Direct |  | Total |  |  | Distributor |  | Direct |  | Total |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  | $ | 68,565 |  | $ | 68,585 |  | $ | 137,150 |  |  | $ | 46,506 |  | $ | 58,744 |  | $ | 105,250 |  |
| Other |  |  | 3,865 |  |  | 4,955 |  |  | 8,820 |  |  |  | 8,950 |  |  | 3,648 |  |  | 12,598 |  |
| Total Americas |  |  | 72,430 |  |  | 73,540 |  |  | 145,970 |  |  |  | 55,456 |  |  | 62,392 |  |  | 117,848 |  |
| EMEA |  |  | 68,934 |  |  | 42,128 |  |  | 111,062 |  |  |  | 69,602 |  |  | 34,220 |  |  | 103,822 |  |
| APAC |  |  | 5,034 |  |  | 18,867 |  |  | 23,901 |  |  |  | 2,793 |  |  | 17,665 |  |  | 20,458 |  |
| Total net revenues |  | $ | 146,398 |  | $ | 134,535 |  | $ | 280,933 |  |  | $ | 127,851 |  | $ | 114,277 |  | $ | 242,128 |  |
  (was, 2021-11-05, similarity 0.9889):
[0001564590-21-054929:note_history:39]
|  |  | Three Months Ended |  |
|  |  | September 30, 2021 |  |  | September 30, 2020 |  |
|  |  | Distributor |  | Direct |  | Total |  |  | Distributor |  | Direct |  | Total |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  | $ | 56,068 |  | $ | 67,331 |  | $ | 123,399 |  |  | $ | 60,670 |  | $ | 57,347 |  | $ | 118,017 |  |
| Other |  |  | 7,799 |  |  | 3,367 |  |  | 11,166 |  |  |  | 8,241 |  |  | 4,090 |  |  | 12,331 |  |
| Total Americas |  |  | 63,867 |  |  | 70,698 |  |  | 134,565 |  |  |  | 68,911 |  |  | 61,437 |  |  | 130,348 |  |
| EMEA |  |  | 77,898 |  |  | 35,731 |  |  | 113,629 |  |  |  | 47,529 |  |  | 33,576 |  |  | 81,105 |  |
| APAC |  |  | 4,335 |  |  | 15,155 |  |  | 19,490 |  |  |  | 5,051 |  |  | 19,298 |  |  | 24,349 |  |
| Total net revenues |  | $ | 146,100 |  | $ | 121,584 |  | $ | 267,684 |  |  | $ | 121,491 |  | $ | 114,311 |  | $ | 235,802 |  |

- added (2022-01-28):
[0001564590-22-003010:note_history:40]
|  |  | Six Months Ended |  |
|  |  | December 31, 2021 |  |  | December 31, 2020 |  |
|  |  | Distributor |  | Direct |  | Total |  |  | Distributor |  | Direct |  | Total |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  | $ | 124,633 |  | $ | 135,916 |  | $ | 260,549 |  |  | $ | 107,176 |  | $ | 116,091 |  | $ | 223,267 |  |
| Other |  |  | 11,664 |  |  | 8,322 |  |  | 19,986 |  |  |  | 17,191 |  |  | 7,738 |  |  | 24,929 |  |
| Total Americas |  |  | 136,297 |  |  | 144,238 |  |  | 280,535 |  |  |  | 124,367 |  |  | 123,829 |  |  | 248,196 |  |
| EMEA |  |  | 146,832 |  |  | 77,859 |  |  | 224,691 |  |  |  | 117,131 |  |  | 67,796 |  |  | 184,927 |  |
| APAC |  |  | 9,369 |  |  | 34,022 |  |  | 43,391 |  |  |  | 7,844 |  |  | 36,963 |  |  | 44,807 |  |
| Total net revenues |  | $ | 292,498 |  | $ | 256,119 |  | $ | 548,617 |  |  | $ | 249,342 |  | $ | 228,588 |  | $ | 477,930 |  |

- added (2022-01-28):
[0001564590-22-003010:note_history:41]
For the six months ended December 31, 2021, the Company generated 10% of its revenues from the Netherlands. For the three months ended December 31, 2020, the Company generated 11% of its revenues from the Netherlands and 11% of its revenues from Germany. For the six months ended December 31, 2020, the Company generated 10% of its revenues from the Netherlands and 10% of its revenues from Germany. No other foreign country accounted for 10% or more of revenue for the three and six months ended December 31, 2021 or 2020.

- changed (2022-01-28):
[0001564590-22-003010:note_history:42]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | December 31, 2021 |  |  | December 31, 2020 |  |  | December 31, 2021 |  |  | December 31, 2020 |  |
| TD Synnex Corporation |  | 21% |  |  | 21% |  |  | 22% |  |  | 24% |  |
| Jenne Corporation |  | 18% |  |  | 11% |  |  | 16% |  |  | 13% |  |
| Westcon Group Inc. |  | 11% |  |  | 19% |  |  | 15% |  |  | 16% |  |
  (was, 2021-11-05, similarity 0.7258):
[0001564590-21-054929:note_history:42]
|  |  | Three Months Ended |  |
|  |  | September 30, 2021 |  |  | September 30, 2020 |  |
| Tech Data Corporation |  | 22% |  |  | 27% |  |
| Jenne Corporation |  | 14% |  |  | 15% |  |
| Westcon Group Inc. |  | 18% |  |  | 13% |  |

- changed (2022-01-28):
[0001564590-22-003010:note_history:43]
|  |  | December 31, 2021 |  |  | June 30, 2021 |  |
| TD Synnex Corporation |  | 10% |  |  | 19% |  |
| Jenne Corporation |  | * |  |  | 24% |  |
| * Less than 10% of accounts receivable. |  |  |  |  |  |  |  |  |
  (was, 2021-11-05, similarity 0.7309):
[0001564590-21-054929:note_history:43]
|  |  | September 30, 2021 |  |  | June 30, 2021 |  |
| Tech Data Corporation |  | 17% |  |  | 19% |  |
| Jenne Corporation |  | 22% |  |  | 24% |  |

- removed (2022-01-28):
[0001564590-21-054929:note_history:44]
For the three months ended September 30, 2021 the Company generated 11% of its revenues from the Netherlands and 10% of its revenues from the Germany. No other foreign country accounted for 10% or more of revenue for the three months ended September 30, 2021 or 2020.


## us-gaap:RevenueRecognitionPolicyTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2022-01-28):
[0001564590-22-003010:note_history:45]
On December 31, 2021, the Company had $373.2 million of remaining performance obligations, which are primarily comprised of deferred maintenance and SaaS revenues. The Company expects to recognize approximately 38% of its deferred revenue as revenue in fiscal 2022, an additional 34% in fiscal 2023 and 28% of the balance thereafter.
  (was, 2021-11-05, similarity 0.892):
[0001564590-21-054929:note_history:45]
On September 30, 2021, the Company had $356.0 million of remaining performance obligations, which are primarily comprised of deferred maintenance and SaaS revenues.  The Company expects to recognize approximately 52 percent of its deferred revenue as revenue in fiscal 2022, an additional 25 percent in fiscal 2023 and 23 percent of the balance thereafter.

- changed (2022-01-28):
[0001564590-22-003010:note_history:46]
Revenue recognized for the three months ended December 31, 2021 and 2020 that was included in the deferred revenue balance at the beginning of each period was $81.9 million and $68.8 million, respectively. Revenue recognized for the six months ended December 31, 2021 and 2020 that was included in the deferred revenue balance at the beginning of each period was $132.5 million and $120.5 million, respectively.
  (was, 2021-11-05, similarity 0.6597):
[0001564590-21-054929:note_history:46]
Revenue recognized for the three months ended September 30, 2021 and 2020 that was included in the deferred revenue balance at the beginning of each period was $73.4 million and $66.9 million, respectively.

- changed (2022-01-28):
[0001564590-22-003010:note_history:47]
Contract Costs. The Company recognizes the incremental costs of obtaining contracts as an expense when incurred if the amortization period of the assets that the Company otherwise would have recognized is one year or less.  Management expects that commission fees paid to sales representatives as a result of obtaining service contracts and contract renewals are recoverable and therefore the Company’s condensed consolidated balance sheets included capitalized balances in the amount of $14.2 million and $13.1 million at December 31, 2021 and June 30, 2021, respectively. Capitalized commission fees are amortized on a straight-line basis over the average period of service contracts of approximately three years, and are included in “Sales and marketing” in the accompanying condensed consolidated statements of operations. Amortization recognized during the three months ended December 31, 2021 and 2020, was $1.8 million and $1.2 million, respectively. Amortization recognized during the six months ended December 31, 2021 and 2020, was $3.6 million and $2.5 million, respectively.
  (was, 2021-11-05, similarity 0.934):
[0001564590-21-054929:note_history:47]
Contract Costs. The Company recognizes the incremental costs of obtaining contracts as an expense when incurred if the amortization period of the assets that the Company otherwise would have recognized is one year or less.  Management expects that commission fees paid to sales representatives as a result of obtaining service contracts and contract renewals are recoverable and therefore the Company’s condensed consolidated balance sheets included capitalized balances in the amount of $13.5 million and $13.1 million at September 30, 2021 and June 30, 2021, respectively. Capitalized commission fees are amortized on a straight-line basis over the average period of service contracts of approximately three years, and are included in “Sales and marketing” in the accompanying condensed consolidated statements of operations. Amortization recognized during the three months ended September 30, 2021 and 2020, was $1.8 million and $1.2 million, respectively.

- changed (2022-01-28):
[0001564590-22-003010:note_history:48]
The Company operates in three geographic regions: Americas, which includes the United States, Canada, Mexico, Central America and South America; EMEA, which includes Europe, Russia, Middle East and Africa; and APAC, which includes Asia Pacific, China, South Asia and Japan. The following table sets forth the Company’s revenues disaggregated by sales channel and geographic region based on the billing addresses of its customers (in thousands):
  (was, 2021-11-05, similarity 0.9989):
[0001564590-21-054929:note_history:48]
The Company operates in three geographic regions: Americas, which includes the United States, Canada, Mexico, Central America and South America; EMEA, which includes Europe, Russia, Middle East and Africa; and APAC, which includes Asia Pacific, China, South Asia and Japan. The following table sets forth the Company’s revenues disaggregated by sales channel and geographic region based on the billing addresses of its customer’s (in thousands):

- changed (2022-01-28):
[0001564590-22-003010:note_history:49]
|  |  | Three Months Ended |  |
|  |  | December 31, 2021 |  |  | December 31, 2020 |  |
|  |  | Distributor |  | Direct |  | Total |  |  | Distributor |  | Direct |  | Total |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  | $ | 68,565 |  | $ | 68,585 |  | $ | 137,150 |  |  | $ | 46,506 |  | $ | 58,744 |  | $ | 105,250 |  |
| Other |  |  | 3,865 |  |  | 4,955 |  |  | 8,820 |  |  |  | 8,950 |  |  | 3,648 |  |  | 12,598 |  |
| Total Americas |  |  | 72,430 |  |  | 73,540 |  |  | 145,970 |  |  |  | 55,456 |  |  | 62,392 |  |  | 117,848 |  |
| EMEA |  |  | 68,934 |  |  | 42,128 |  |  | 111,062 |  |  |  | 69,602 |  |  | 34,220 |  |  | 103,822 |  |
| APAC |  |  | 5,034 |  |  | 18,867 |  |  | 23,901 |  |  |  | 2,793 |  |  | 17,665 |  |  | 20,458 |  |
| Total net revenues |  | $ | 146,398 |  | $ | 134,535 |  | $ | 280,933 |  |  | $ | 127,851 |  | $ | 114,277 |  | $ | 242,128 |  |
  (was, 2021-11-05, similarity 0.9889):
[0001564590-21-054929:note_history:49]
|  |  | Three Months Ended |  |
|  |  | September 30, 2021 |  |  | September 30, 2020 |  |
|  |  | Distributor |  | Direct |  | Total |  |  | Distributor |  | Direct |  | Total |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  | $ | 56,068 |  | $ | 67,331 |  | $ | 123,399 |  |  | $ | 60,670 |  | $ | 57,347 |  | $ | 118,017 |  |
| Other |  |  | 7,799 |  |  | 3,367 |  |  | 11,166 |  |  |  | 8,241 |  |  | 4,090 |  |  | 12,331 |  |
| Total Americas |  |  | 63,867 |  |  | 70,698 |  |  | 134,565 |  |  |  | 68,911 |  |  | 61,437 |  |  | 130,348 |  |
| EMEA |  |  | 77,898 |  |  | 35,731 |  |  | 113,629 |  |  |  | 47,529 |  |  | 33,576 |  |  | 81,105 |  |
| APAC |  |  | 4,335 |  |  | 15,155 |  |  | 19,490 |  |  |  | 5,051 |  |  | 19,298 |  |  | 24,349 |  |
| Total net revenues |  | $ | 146,100 |  | $ | 121,584 |  | $ | 267,684 |  |  | $ | 121,491 |  | $ | 114,311 |  | $ | 235,802 |  |

- added (2022-01-28):
[0001564590-22-003010:note_history:50]
|  |  | Six Months Ended |  |
|  |  | December 31, 2021 |  |  | December 31, 2020 |  |
|  |  | Distributor |  | Direct |  | Total |  |  | Distributor |  | Direct |  | Total |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  | $ | 124,633 |  | $ | 135,916 |  | $ | 260,549 |  |  | $ | 107,176 |  | $ | 116,091 |  | $ | 223,267 |  |
| Other |  |  | 11,664 |  |  | 8,322 |  |  | 19,986 |  |  |  | 17,191 |  |  | 7,738 |  |  | 24,929 |  |
| Total Americas |  |  | 136,297 |  |  | 144,238 |  |  | 280,535 |  |  |  | 124,367 |  |  | 123,829 |  |  | 248,196 |  |
| EMEA |  |  | 146,832 |  |  | 77,859 |  |  | 224,691 |  |  |  | 117,131 |  |  | 67,796 |  |  | 184,927 |  |
| APAC |  |  | 9,369 |  |  | 34,022 |  |  | 43,391 |  |  |  | 7,844 |  |  | 36,963 |  |  | 44,807 |  |
| Total net revenues |  | $ | 292,498 |  | $ | 256,119 |  | $ | 548,617 |  |  | $ | 249,342 |  | $ | 228,588 |  | $ | 477,930 |  |

- added (2022-01-28):
[0001564590-22-003010:note_history:51]
For the six months ended December 31, 2021, the Company generated 10% of its revenues from the Netherlands. For the three months ended December 31, 2020, the Company generated 11% of its revenues from the Netherlands and 11% of its revenues from Germany. For the six months ended December 31, 2020, the Company generated 10% of its revenues from the Netherlands and 10% of its revenues from Germany. No other foreign country accounted for 10% or more of revenue for the three and six months ended December 31, 2021 or 2020.

- removed (2022-01-28):
[0001564590-21-054929:note_history:52]
For the three months ended September 30, 2021 the Company generated 11% of its revenues from the Netherlands and 10% of its revenues from the Germany. No other foreign country accounted for 10% or more of revenue for the three months ended September 30, 2021 or 2020.
