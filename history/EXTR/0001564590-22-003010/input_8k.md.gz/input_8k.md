# EXTR 8-K — 0001564590-22-002568 filed 2022-01-27

## item codes, every 8-K on or before 2022-01-28

- 2022-01-27 0001564590-22-002568 — 2.02, 9.01
- 2021-11-05 0001564590-21-054934 — 5.07
- 2021-11-02 0001564590-21-053306 — 2.02, 9.01
- 2021-09-22 0001564590-21-048585 — 4.01, 9.01
- 2021-08-10 0001564590-21-043098 — 1.01
- 2021-07-28 0001564590-21-038470 — 2.02, 9.01
- 2021-05-18 0001564590-21-028693 — 1.01, 3.03, 9.01
- 2021-04-28 0001564590-21-021102 — 2.02, 9.01
- 2021-02-09 0001564590-21-005000 — 2.02, 9.01
- 2021-01-27 0001564590-21-002633 — 2.02, 9.01
- 2020-11-06 0001564590-20-051993 — 5.07
- 2020-10-28 0001564590-20-048160 — 2.02, 9.01
- 2020-10-08 0001564590-20-046117 — 2.02, 9.01
- 2020-09-11 0001564590-20-043260 — 4.01, 9.01
- 2020-08-05 0001564590-20-036431 — 2.02, 9.01
- 2020-06-01 0001564590-20-027850 — 3.03, 9.01
- 2020-05-11 0001564590-20-024216 — 2.02, 9.01
- 2020-04-08 0001564590-20-015927 — 2.02, 8.01, 9.01
- 2020-02-25 0001193125-20-047202 — 8.01, 9.01
- 2020-01-29 0001564590-20-002375 — 2.02, 9.01
- 2020-01-29 0001193125-20-017673 — 5.02, 9.01
- 2019-11-08 0001193125-19-288358 — 5.07
- 2019-10-30 0001564590-19-038508 — 2.02, 9.01
- 2019-10-25 0001564590-19-037908 — 9.01 — amendment of 0001193125-19-217553
- 2019-10-18 0001193125-19-269734 — 7.01, 9.01
- 2019-08-30 0001193125-19-235271 — 5.02 — amendment of 0001193125-19-229280
- 2019-08-26 0001193125-19-229280 — 5.02, 9.01
- 2019-08-09 0001193125-19-217553 — 1.01, 2.01, 2.03, 9.01
- 2019-07-31 0001564590-19-027208 — 2.02, 9.01
- 2019-06-26 0001193125-19-181938 — 1.01, 2.05, 9.01
- 2019-05-01 0001564590-19-014567 — 2.02, 9.01
- 2019-01-29 0001564590-19-001270 — 2.02, 9.01
- 2019-01-25 0001564590-19-001157 — 8.01, 9.01
- 2018-11-20 0001193125-18-331450 — 5.02, 9.01
- 2018-11-15 0001564590-18-029683 — 5.07
- 2018-11-02 0001564590-18-026372 — 2.02, 8.01, 9.01
- 2018-09-19 0001193125-18-276766 — 5.02
- 2018-08-08 0001564590-18-020191 — 2.02, 9.01
- 2018-06-05 0001564590-18-015067 — 3.03, 9.01
- 2018-05-08 0001564590-18-011817 — 2.02, 9.01
- 2018-05-07 0001564590-18-011264 — 1.01, 1.02, 2.03, 9.01
- 2018-02-06 0001564590-18-001403 — 2.02, 2.05, 9.01
- 2018-02-01 0001564590-18-001166 — 5.02
- 2018-01-12 0001564590-18-000462 — 9.01 — amendment of 0001193125-17-323879
- 2017-11-15 0001564590-17-023847 — 5.07
- 2017-11-07 0001564590-17-022235 — 2.02, 9.01
- 2017-11-03 0001193125-17-332828 — 9.01 — amendment of 0001193125-17-323879
- 2017-10-30 0001193125-17-323879 — 1.01, 2.01, 7.01, 9.01
- 2017-10-03 0001193125-17-302411 — 1.01, 9.01
- 2017-10-03 0001193125-17-301597 — 1.01, 1.02, 7.01, 9.01
- 2017-09-29 0001564590-17-019099 — 9.01 — amendment, the index does not say of what
- 2017-08-14 0001564590-17-017659 — 2.02, 9.01
- 2017-08-02 0001564590-17-014950 — 5.02
- 2017-07-18 0001564590-17-013557 — 1.01, 2.01, 2.03, 9.01
- 2017-06-05 0001564590-17-012126 — 3.03, 9.01
- 2017-05-03 0001564590-17-008378 — 2.02, 9.01
- 2017-03-30 0001193125-17-102344 — 1.01, 9.01
- 2017-03-07 0001193125-17-073306 — 1.01, 9.01
- 2017-02-21 0001193125-17-048182 — 5.02
- 2017-02-01 0001564590-17-000835 — 2.02, 9.01
- 2017-01-06 0001564590-17-000138 — 2.05
- 2016-11-21 0001564590-16-029539 — 5.07
- 2016-11-01 0001564590-16-026732 — 2.02, 9.01
- 2016-10-31 0001193125-16-752557 — 1.01, 2.01, 2.03
- 2016-09-15 0001193125-16-711097 — 1.01, 9.01
- 2016-08-03 0001564590-16-022347 — 2.02, 9.01
- 2016-05-19 0001564590-16-019720 — 5.02, 9.01
- 2016-05-09 0001564590-16-018660 — 3.03, 9.01
- 2016-04-27 0001564590-16-016754 — 2.02, 9.01
- 2016-02-24 0001564590-16-013189 — 8.01
- 2016-02-09 0001564590-16-012469 — 8.01
- 2016-01-28 0001564590-16-012054 — 2.02, 9.01
- 2015-11-17 0001078271-15-000136 — 5.07
- 2015-10-29 0001078271-15-000125 — 2.02, 9.01
- 2015-08-31 0001078271-15-000111 — 8.01, 9.01
- 2015-08-11 0001078271-15-000096 — 5.02
- 2015-08-06 0001078271-15-000093 — 2.02, 9.01
- 2015-06-30 0001078271-15-000089 — 1.01, 9.01
- 2015-05-20 0001078271-15-000077 — 2.05, 9.01
- 2015-05-19 0001078271-15-000075 — 3.03, 9.01
- 2015-05-06 0001078271-15-000050 — 2.02, 9.01
- 2015-05-04 0001078271-15-000048 — 5.02, 9.01
- 2015-04-29 0001078271-15-000038 — 5.02, 9.01
- 2015-04-21 0001078271-15-000034 — 5.02, 9.01
- 2015-04-09 0001078271-15-000032 — 2.02, 5.02, 9.01
- 2015-02-18 0001078271-15-000021 — 8.01
- 2015-02-17 0001078271-15-000019 — 5.02
- 2015-01-28 0001078271-15-000004 — 2.02, 9.01
- 2014-12-18 0001078271-14-000081 — 5.02, 9.01
- 2014-12-17 0001078271-14-000079 — 5.02
- 2014-11-20 0001078271-14-000075 — 1.01, 9.01
- 2014-11-17 0001078271-14-000073 — 5.07
- 2014-10-28 0001078271-14-000062 — 2.02, 9.01
- 2014-10-15 0001078271-14-000060 — 2.02, 9.01
- 2014-10-02 0001078271-14-000057 — 5.02, 9.01
- 2014-08-14 0001078271-14-000047 — 2.02, 9.01
- 2014-07-21 0001078271-14-000042 — 2.02, 9.01
- 2014-05-23 0001078271-14-000036 — 5.02, 9.01
- 2014-05-20 0001078271-14-000034 — 3.03, 9.01
- 2014-05-12 0001078271-14-000030 — 5.02
- 2014-05-08 0001078271-14-000022 — 5.02, 9.01
- 2014-05-07 0001078271-14-000018 — 2.02, 9.01 — amendment, the index does not say of what
- 2014-05-06 0001078271-14-000016 — 2.02, 9.01
- 2014-02-20 0001078271-14-000014 — 5.02, 9.01
- 2014-02-18 0001078271-14-000010 — 5.02
- 2014-02-05 0001078271-14-000006 — 2.02, 9.01
- 2014-01-13 0001104659-14-002030 — 9.01 — amendment of 0001078271-13-000058
- 2013-11-25 0001078271-13-000081 — 5.07
- 2013-11-07 0001078271-13-000064 — 5.02, 9.01
- 2013-11-04 0001078271-13-000060 — 2.02, 9.01
- 2013-11-01 0001078271-13-000058 — 1.01, 2.01, 2.03, 8.01, 9.01
- 2013-10-16 0001078271-13-000056 — 8.01, 9.01
- 2013-09-13 0001078271-13-000052 — 1.01, 8.01, 9.01
- 2013-08-23 0001078271-13-000044 — 5.02, 9.01
- 2013-08-02 0001078271-13-000042 — 5.02
- 2013-07-30 0001078271-13-000039 — 2.02, 9.01
- 2013-07-30 0001078271-13-000037 — 5.02, 9.01
- 2013-06-21 0001078271-13-000032 — 8.01
- 2013-05-01 0001078271-13-000018 — 5.02, 9.01
- 2013-04-30 0001078271-13-000015 — 2.02, 9.01
- 2013-03-01 0001078271-13-000010 — 8.01
- 2013-02-19 0001078271-13-000008 — 5.02
- 2013-01-30 0001078271-13-000004 — 2.02, 9.01
- 2013-01-07 0001078271-13-000002 — 1.01, 2.02, 2.03, 2.05, 9.01
- 2012-12-03 0001078271-12-000094 — 5.02, 5.07, 8.01
- 2012-10-31 0001078271-12-000071 — 2.02, 9.01
- 2012-10-19 0001078271-12-000069 — 1.01, 2.03, 9.01
- 2012-10-16 0001078271-12-000067 — 8.01
- 2012-10-01 0001193125-12-411392 — 5.02, 8.01, 9.01
- 2012-09-24 0001193125-12-401798 — 5.02, 9.01
- 2012-09-21 0001193125-12-399896 — 5.02, 9.01
- 2012-09-18 0001193125-12-394379 — 1.01, 5.02, 9.01
- 2012-09-12 0001193125-12-388591 — 8.01
- 2012-08-27 0001078271-12-000057 — 8.01
- 2012-08-03 0001078271-12-000041 — 7.01, 9.01
- 2012-08-01 0001078271-12-000039 — 2.02, 9.01
- 2012-07-25 0001078271-12-000037 — 8.01
- 2012-05-22 0001078271-12-000033 — 5.02, 9.01
- 2012-05-21 0001078271-12-000030 — 8.01
- 2012-05-09 0001078271-12-000028 — 5.02, 9.01
- 2012-05-02 0001078271-12-000023 — 2.02, 9.01
- 2012-04-30 0001078271-12-000020 — 3.03, 5.07, 9.01
- 2012-04-19 0001078271-12-000012 — 2.02, 5.02, 9.01
- 2012-03-12 0001078271-12-000010 — 5.02, 9.01
- 2012-02-24 0001078271-12-000008 — 8.01
- 2012-02-02 0001078271-12-000004 — 2.02, 9.01
- 2012-01-30 0001078271-12-000002 — 1.01
- 2011-12-01 0001078271-11-000104 — 8.01
- 2011-11-08 0001078271-11-000099 — 8.01
- 2011-11-02 0001078271-11-000094 — 2.02, 9.01
- 2011-10-24 0001078271-11-000089 — 8.01, 9.01
- 2011-10-11 0001078271-11-000085 — 8.01
- 2011-09-29 0001078271-11-000082 — 8.01
- 2011-09-15 0001078271-11-000070 — 5.02, 9.01
- 2011-08-11 0001078271-11-000058 — 8.01
- 2011-08-10 0001078271-11-000055 — 5.02
- 2011-08-08 0001078271-11-000045 — 5.02
- 2011-08-01 0001078271-11-000038 — 2.02, 9.01
- 2011-07-14 0001078271-11-000036 — 2.02, 2.05, 9.01
- 2011-07-12 0001078271-11-000034 — 8.01
- 2011-07-01 0001078271-11-000032 — 5.02
- 2011-06-16 0001078271-11-000030 — 8.01
- 2011-05-06 0001078271-11-000027 — 8.01, 9.01
- 2011-05-04 0001078271-11-000025 — 8.01
- 2011-04-28 0001078271-11-000020 — 2.02, 9.01
- 2011-04-27 0001078271-11-000018 — 3.03, 5.02, 5.03, 9.01
- 2011-04-11 0001078271-11-000016 — 2.02
- 2011-03-31 0001078271-11-000014 — 5.02, 5.03
- 2011-03-15 0001193125-11-066049 — 5.02, 9.01
- 2011-03-01 0001193125-11-052048 — 5.02, 9.01
- 2011-02-10 0001078271-11-000012 — 7.01, 9.01
- 2011-01-31 0001078271-11-000005 — 2.02, 5.02, 5.03, 9.01
- 2010-12-23 0001193125-10-287613 — 8.01
- 2010-12-17 0001193125-10-283495 — 5.03, 5.07, 8.01, 9.01
- 2010-11-10 0001193125-10-255861 — 4.01, 9.01
- 2010-11-01 0001193125-10-242706 — 2.02, 9.01
- 2010-10-14 0001193125-10-229518 — 1.01, 9.01
- 2010-10-06 0001193125-10-224863 — 5.02, 8.01
- 2010-09-29 0001193125-10-219705 — 1.01, 8.01
- 2010-09-08 0001193125-10-206782 — 5.02, 8.01, 9.01
- 2010-08-25 0001193125-10-196951 — 8.01
- 2010-08-09 0001193125-10-182573 — 7.01, 8.01, 9.01
- 2010-08-03 0001193125-10-175255 — 5.02, 8.01, 9.01
- 2010-08-02 0001193125-10-173697 — 2.02, 8.01, 9.01
- 2010-07-30 0001193125-10-172214 — 5.02, 8.01, 9.01
- 2010-07-22 0001193125-10-163896 — 8.01, 9.01
- 2010-07-20 0001193125-10-161832 — 5.02
- 2010-07-12 0001193125-10-157291 — 2.02, 9.01
- 2010-07-01 0001193125-10-152746 — 3.03, 9.01
- 2010-05-10 0001193125-10-114669 — 5.02, 9.01
- 2010-04-26 0001193125-10-093310 — 2.02, 9.01
- 2010-03-19 0001193125-10-061679 — 5.02, 9.01
- 2010-02-16 0001193125-10-032335 — 5.02
- 2010-02-01 0001193125-10-018202 — 2.02, 9.01
- 2010-01-29 0001193125-10-017165 — 5.02
- 2010-01-11 0001193125-10-004099 — 8.01
- 2009-10-26 0001193125-09-213846 — 2.02, 9.01 — amendment of 0001193125-09-213780
- 2009-10-26 0001193125-09-213780 — 2.02, 9.01
- 2009-10-23 0001193125-09-212871 — 2.05, 5.02, 8.01, 9.01
- 2009-10-05 0001193125-09-203522 — 2.02, 9.01
- 2009-08-04 0001193125-09-163799 — 5.02, 9.01
- 2009-07-31 0001193125-09-160772 — 5.02, 9.01
- 2009-07-30 0001193125-09-159578 — 2.02, 9.01
- 2009-07-20 0001193125-09-151500 — 5.02, 9.01
- 2009-07-08 0001193125-09-145840 — 5.02, 9.01
- 2009-05-12 0001193125-09-108340 — 5.02, 9.01
- 2009-04-23 0001193125-09-085849 — 2.02, 9.01
- 2009-03-26 0001193125-09-064502 — 2.05
- 2009-01-28 0001193125-09-013182 — 2.02, 9.01
- 2008-11-06 0001193125-08-227572 — 2.02, 9.01
- 2008-11-03 0001193125-08-222501 — 5.02
- 2008-08-11 0001193125-08-173590 — 5.02
- 2008-08-11 0001193125-08-172587 — 8.01, 9.01
- 2008-08-06 0001193125-08-167934 — 2.02, 9.01
- 2008-08-04 0001193125-08-164673 — 5.02, 9.01
- 2008-05-21 0001193125-08-119640 — 7.01, 9.01
- 2008-04-29 0001193125-08-095270 — 2.02, 9.01
- 2008-03-05 0001193125-08-047893 — 8.01
- 2008-02-19 0001193125-08-033702 — 5.02
- 2008-02-05 0001193125-08-019969 — 5.02
- 2008-01-30 0001193125-08-015378 — 2.02, 9.01
- 2007-12-27 0001193125-07-272178 — 5.03, 9.01
- 2007-10-29 0001193125-07-228368 — 2.02, 9.01
- 2007-10-25 0001193125-07-225906 — 5.02, 9.01
- 2007-10-19 0001193125-07-221578 — 5.02
- 2007-09-26 0001193125-07-207348 — 8.01
- 2007-08-07 0001193125-07-172810 — 2.02, 9.01
- 2007-08-06 0001193125-07-172147 — 5.02, 9.01
- 2007-08-06 0001193125-07-172134 — 3.01
- 2007-07-09 0001193125-07-151467 — 3.01, 9.01
- 2007-06-28 0001193125-07-145519 — 2.02, 9.01
- 2007-06-27 0001193125-07-143262 — 2.05, 3.01, 5.02
- 2007-05-18 0001193125-07-118804 — 3.01, 9.01
- 2007-05-02 0001193125-07-099280 — 2.02, 9.01
- 2007-03-29 0001193125-07-068815 — 5.02, 9.01
- 2007-02-22 0001193125-07-037181 — 3.01, 9.01
- 2007-02-08 0001193125-07-024194 — 5.02
- 2007-01-30 0001193125-07-016428 — 2.02, 9.01
- 2007-01-11 0001193125-07-004825 — 4.02, 9.01
- 2006-11-21 0001193125-06-240068 — 5.02, 9.01
- 2006-11-16 0001193125-06-237262 — 3.01, 9.01
- 2006-11-01 0001193125-06-220707 — 2.02, 9.01
- 2006-10-31 0001193125-06-219237 — 1.01, 1.02, 5.02, 5.03, 8.01, 9.01
- 2006-09-28 0001193125-06-198185 — 3.01, 9.01
- 2006-09-15 0001193125-06-191640 — 7.01, 9.01
- 2006-09-05 0001193125-06-185202 — 5.02, 9.01
- 2006-08-08 0001193125-06-165953 — 1.01, 2.02, 5.02, 9.01
- 2006-07-18 0001193125-06-148526 — 1.01
- 2006-07-10 0001193125-06-143989 — 5.02, 9.01
- 2006-05-16 0001193125-06-113698 — 5.02, 9.01
- 2006-05-01 0001193125-06-094919 — 2.02, 9.01
- 2006-04-26 0001193125-06-089397 — 1.01, 9.01
- 2006-04-07 0001193125-06-075723 — 2.02, 9.01
- 2006-02-13 0001193125-06-029073 — 1.01
- 2006-01-31 0001193125-06-016143 — 1.01
- 2006-01-30 0001193125-06-015165 — 2.02, 9.01
- 2005-12-08 0001193125-05-239157 — 1.01, 1.02, 9.01
- 2005-11-01 0001193125-05-213101 — 2.02, 9.01
- 2005-09-29 0001193125-05-193991 — 1.01, 2.02, 9.01 — amendment of 0001193125-05-162807
- 2005-08-09 0001193125-05-162807 — 1.01, 2.02, 9.01
- 2005-07-14 0001193125-05-142162 — 8.01
- 2005-06-28 0001193125-05-133050 — 1.01, 9.01
- 2005-04-18 0001193125-05-077946 — 2.02, 7.01, 9.01
- 2005-04-14 0001193125-05-076665 — 2.02, 7.01, 9.01
- 2005-01-25 0001193125-05-011466 — 2.02, 9.01
- 2004-12-07 0001193125-04-208693 — 3.01
- 2004-10-26 0001193125-04-178370 — 2.02, 9.01
- 2004-10-04 0001193125-04-166289 — 5.02, 9.01
- 2004-07-28 0001193125-04-126135 — 12, 7
- 2004-05-12 0001193125-04-086287 — 12
- 2004-04-21 0001193125-04-066557 — 12, 7
- 2004-01-22 0001193125-04-007359 — 12, 7
- 2003-12-18 0001193125-03-096351 — 5, 7
- 2003-11-04 0001193125-03-072069 — 5, 7
- 2003-10-24 0001193125-03-066551 — 12, 7
- 2003-07-25 0001193125-03-024087 — 7, 9
- 2003-04-11 0001012870-03-001706 — 7, 9
- 2003-04-08 0001021408-03-005743 — 7, 9
- 2003-01-07 0001012870-03-000039 — 5, 7
- 2002-04-29 0001012870-02-002003 — 5, 7
- 2002-02-20 0001012870-02-000792 — 5, 7
- 2001-12-13 0001012870-01-503160 — 5, 7
- 2001-11-30 0001012870-01-503010 — 5, 7
- 2001-11-02 0001012870-01-502580 — 5
- 2001-10-23 0001021408-01-508589 — 5, 7
- 2001-06-07 0001021408-01-501772 — 5, 7 — amendment of 0001021408-01-500975
- 2001-05-15 0001021408-01-501104 — 5 — amendment of 0001021408-01-500975
- 2001-05-14 0001021408-01-500975 — 5, 7
- 2001-04-06 0001012870-01-500065 — 5, 7

## late-filing notifications on or before 2022-01-28

- 2008-05-12 0001193125-08-111540 — NT 10-Q, for the period ended 2008-03-30
- 2007-05-10 0001193125-07-110075 — NT 10-Q, for the period ended 2007-04-01
- 2007-02-09 0001193125-07-025490 — NT 10-Q, for the period ended 2006-12-31
- 2006-11-13 0001193125-06-232090 — NT 10-Q, for the period ended 2006-10-01
- 2006-09-15 0001193125-06-191838 — NT 10-K, for the period ended 2006-07-02

## item 2.02 — earnings release, exhibit 99.1

[0001564590-22-002568:8k_2_02:1]
EX-99.1
2
extr-ex991_6.htm
EX-99.1

[0001564590-22-002568:8k_2_02:2]
extr-ex991_6.htm

[0001564590-22-002568:8k_2_02:3]
Exhibit 99.1

[0001564590-22-002568:8k_2_02:4]
| For more information, contact: |  |  |  |  |  |  |
| Investor Relations |  |  |  | Media Contact |  |
| Stan Kovler |  |  |  | Amy Aylward |
| 919/595-4196 |  |  |  | 603/952-5138 |  |
| Investor_relations@extremenetworks.com |  |  |  | pr@extremenetworks.com |

[0001564590-22-002568:8k_2_02:5]
Extreme Networks Reports Second Quarter Fiscal Year 2022 Financial Results

[0001564590-22-002568:8k_2_02:6]
Achieved Record Quarterly Revenue and Net Income

[0001564590-22-002568:8k_2_02:7]
Double-Digit Growth Expected from Unprecedented Backlog, Demand for Cloud-Driven Networking and Emerging 5G Solutions

[0001564590-22-002568:8k_2_02:8]
Morrisville, NC, January 27, 2022 -- Extreme Networks, Inc. (“Extreme”) (Nasdaq: EXTR) today released financial results for its second fiscal quarter ended December 31, 2021.

[0001564590-22-002568:8k_2_02:9]
Fiscal Second Quarter Results:

[0001564590-22-002568:8k_2_02:10]
|  | • | Revenue $280.9 million, up 16% year-over-year, and up 5% quarter-over-quarter |

[0001564590-22-002568:8k_2_02:11]
|  | • | SaaS ARR* $88.3 million, up 55% year-over-year, and up 11% quarter-over-quarter |

[0001564590-22-002568:8k_2_02:12]
|  | • | GAAP EPS $0.10, up from ($0.02) in Q2 last year |

[0001564590-22-002568:8k_2_02:13]
|  | • | Non-GAAP EPS $0.21, up from $0.13 in Q2 last year |

[0001564590-22-002568:8k_2_02:14]
|  | • | GAAP gross margin 56.5% compared to 57.9% in Q2 last year |

[0001564590-22-002568:8k_2_02:15]
|  | • | Non-GAAP gross margin 58.2% compared to 61.0% in Q2 last year |

[0001564590-22-002568:8k_2_02:16]
|  | • | GAAP operating margin 6.4% compared to 2.4% in Q2 last year |

[0001564590-22-002568:8k_2_02:17]
|  | • | Non-GAAP operating margin 13.1% compared to 10.2% in Q2 last year |

[0001564590-22-002568:8k_2_02:18]
|  | • | Net cash provided by operating activities of $22.2 million |

[0001564590-22-002568:8k_2_02:19]
|  | • | Free Cash Flow of $19.0 million |

[0001564590-22-002568:8k_2_02:20]
|  | • | Executed $25.0 million share repurchase during the quarter |

[0001564590-22-002568:8k_2_02:21]
“Extreme continued its momentum with strong execution, once again exceeding our outlook to set a new quarterly record for revenue and net income, despite significant supply chain challenges.  We continued to gain market share in cloud networking, delivering 55% growth year-over-year in SaaS ARR. Strong demand for our solutions across all our customer verticals resulted in over $90 million of incremental backlog during the quarter, bringing the total to nearly $300 million at quarter end. I am also very proud to report that earlier this month we completed the integration of Ipanema ahead of plan. We will launch our ExtremeCloud SD-WAN solutions this quarter, which will drive additional subscription revenue for Extreme, particularly as we enter Fiscal ’23,” stated Ed Meyercord, President and CEO of Extreme.

[0001564590-22-002568:8k_2_02:22]
“The ability to create new services and unlock value from the data in our cloud to extract meaningful insights and analytics from networks is driving multi-year investment cycles with major new and existing customers. This is highlighted by being named the official Wi-Fi analytics provider for Manchester United, the NHL, and the 9th consecutive NFL Super Bowl. Our cloud-driven networking solutions are helping our customers drive operational efficiencies, enhance security, inform sales strategies, and

[0001564590-22-002568:8k_2_02:23]
accelerate business growth. We are also innovating and driving new growth opportunities with the early rollout of 5G networks” concluded Meyercord.

[0001564590-22-002568:8k_2_02:24]
“Extreme delivered another quarter of strong financial performance with double-digit year over year revenue growth for the fourth consecutive quarter and an improvement in our non-GAAP operating margin of nearly 3-percentage points to 13.1%, despite higher costs associated with supply chain constraints. During the quarter, we executed a buyback of 1.8 million Extreme shares for $25 million under our existing share repurchase program. As we enter the second half of fiscal year 2022, we remain confident in our ability to deliver double-digit revenue growth and a non-GAAP operating margin in the range of 10 to 15%,” concluded Remi Thomas, Chief Financial Officer.

[0001564590-22-002568:8k_2_02:25]
Recent Key Highlights:

[0001564590-22-002568:8k_2_02:26]
|  | • | In addition to Q2 FY22 financial results, Extreme today demonstrated its continued dominance as the preferred Wi-Fi and Wi-Fi Analytics provider of several global professional sports organizations committed to up-leveling the gameday experience for players and fans, including: |

[0001564590-22-002568:8k_2_02:27]
|  | • | Manchester United has selected Extreme to modernize the fan experience at Old Trafford stadium with fast, reliable Wi-Fi connectivity and increase the Club’s capability to deliver high performance, low latency and secure digital services. Extreme will enable Manchester United to access real-time network analytics to drive more personalized and informed decisions around both the fan experience and overall venue operations. The deployment will start later this year. |

[0001564590-22-002568:8k_2_02:28]
|  | • | Extreme was named the Official Wi-Fi Analytics Provider and an Official Wi-Fi Partner of the NHL in the U.S. through 2026. As part of the partnership, Extreme will deploy ExtremeAnalytics™ across select NHL arenas and work together to create more personalized, fluid, and memorable gameday experiences. |

[0001564590-22-002568:8k_2_02:29]
|  | • | For the ninth consecutive year, Extreme is the Official Wi-Fi Analytics provider of Super Bowl LVI, set to take place on February 13, 2022 at SoFi Stadium in Inglewood, California. Extreme officially extended its partnership with the National Football League (NFL) and will remain the Official Wi-Fi Network Solutions Provider and Official Wi-Fi Analytics Provider of the NFL through 2024. Extreme is rolling out next-generation analytics capabilities to the NFL this season, providing IT teams with richer data sets and insights around app performance and usage, dwell time, and location-based services. |

[0001564590-22-002568:8k_2_02:30]
|  | • | Extreme Networks, Inc announced it is once again positioned as a Leader in the 2021 Gartner®**Magic Quadrant™ for Enterprise Wired and Wireless LAN Infrastructure. This is the fourth consecutive year Extreme has been positioned as a Leader in this annual research report. |

[0001564590-22-002568:8k_2_02:31]
|  | • | Skyguide, the leading provider of air navigation services in Switzerland and delegated airspaces, needed a network that would enable more efficient deployments of multiple wide area security zones with strong support for multicast traffic. Extreme was selected to deliver switching and management solutions including Extreme Fabric Connect, making Skyguide’s network infrastructure more flexible, simpler to deploy, and easier to automate. |

[0001564590-22-002568:8k_2_02:32]
|  | • | Onondaga Community College, part of the State University of New York system, selected Extreme to replace its entire edge-to-core network infrastructure. The new cloud-managed fabric network eliminates configuration touchpoints and errors and provides full network visibility from a single pane of glass, simplifying network management for the college’s two-person IT team and improving network performance. |

[0001564590-22-002568:8k_2_02:33]
|  | • | Extreme introduced Trusted Delivery, a carrier-grade solution designed to protect critical 5G network infrastructure and help ensure it is performing as anticipated without interference, regardless of location. Available across the 8000 Series (8520 and Extreme 8720) data center and cellular edge leaf and spine switches, Trusted Delivery provides mechanisms for service providers to verify device security and performance during operation without shutting the device down. |

[0001564590-22-002568:8k_2_02:34]
**Gartner, Magic Quadrant for Enterprise Wired and Wireless LAN Infrastructure, Published 15 November 2021.

[0001564590-22-002568:8k_2_02:35]
**Gartner and Magic Quadrant are registered trademarks of Gartner, Inc. and/or its affiliates in the U.S. and internationally and are used herein with permission. All rights reserved.

[0001564590-22-002568:8k_2_02:36]
**Gartner does not endorse any vendor, product or service depicted in its research publications, and does not advise technology users to select only those vendors with the highest ratings or other designation. Gartner research publications consist of the opinions of Gartner's research organization and should not be construed as statements of fact. Gartner disclaims all warranties, express or implied, with respect to this research, including any warranties of merchantability or fitness for a particular purpose.

[0001564590-22-002568:8k_2_02:37]
Fiscal Q2 2022 Financial Metrics:

[0001564590-22-002568:8k_2_02:38]
(in millions, except percentages and per share information)

[0001564590-22-002568:8k_2_02:39]
|  |  | GAAP Results |  |
|  |  | Three Months Ended |  |
|  |  | December 31, 2021 |  |  | December 31, 2020 |  |  | Change |  |
| Product |  | $ | 191.1 |  |  | $ | 165.8 |  |  | $ | 25.3 |  |  |  | 15 | % |
| Service and subscription |  |  | 89.8 |  |  |  | 76.3 |  |  |  | 13.5 |  |  |  | 18 | % |
| Total net revenue |  | $ | 280.9 |  |  | $ | 242.1 |  |  | $ | 38.8 |  |  |  | 16 | % |
| Gross margin |  |  | 56.5 | % |  |  | 57.9 | % |  | -140 bps |  |  | - |  |
| Operating margin |  |  | 6.4 | % |  |  | 2.4 | % |  | 407 bps |  |  | - |  |
| Net income (loss) |  | $ | 13.3 |  |  | $ | (3.1 | ) |  | $ | 16.4 |  |  |  | 529 | % |
| Net income (loss) per diluted share |  | $ | 0.10 |  |  | $ | (0.02 | ) |  | $ | 0.12 |  |  |  | 600 | % |

[0001564590-22-002568:8k_2_02:40]
|  |  | Non-GAAP Results |  |
|  |  | Three Months Ended |  |
|  |  | December 31, 2021 |  |  | December 31, 2020 |  |  | Change |  |
| Product |  | $ | 191.1 |  |  | $ | 165.8 |  |  | $ | 25.3 |  |  |  | 15 | % |
| Service and subscription |  |  | 89.8 |  |  |  | 76.3 |  |  |  | 13.5 |  |  |  | 18 | % |
| Total net revenue |  | $ | 280.9 |  |  | $ | 242.1 |  |  | $ | 38.8 |  |  |  | 16 | % |
| Gross margin |  |  | 58.2 | % |  |  | 61.0 | % |  | -280 bps |  |  | - |  |
| Operating margin |  |  | 13.1 | % |  |  | 10.2 | % |  | 290 bps |  |  | - |  |
| Net income |  | $ | 28.4 |  |  | $ | 16.0 |  |  | $ | 12.4 |  |  |  | 78 | % |
| Net income per diluted share |  | $ | 0.21 |  |  | $ | 0.13 |  |  | $ | 0.08 |  |  |  | 62 | % |

[0001564590-22-002568:8k_2_02:41]
|  | • | Q2 ending cash balance was $173.5 million, a decrease of $17.8 million from the end of Q1. This was primarily driven by the cash usage of $36.7 million for financing activities primarily due to |

[0001564590-22-002568:8k_2_02:42]
|  |  | share repurchases and $3.2 million for capital expenditure, partially offset by operating cash flow generation of $22.2 million. |

[0001564590-22-002568:8k_2_02:43]
|  | • | During Q2, we repurchased a total of 1.83 million shares of our common stock on the open market at a total cost of $25.0 million with an average price of $13.65 per share. |

[0001564590-22-002568:8k_2_02:44]
|  | • | Q2 accounts receivable balance was $133.3 million, an increase of $3.7 million from the end of Q1 and an increase of $5.1 million from Q2 last year. Days sales outstanding was 44 days, a decrease of 1 day from Q1 and a decrease of 5 days from Q2 last year. |

[0001564590-22-002568:8k_2_02:45]
|  | • | Q2 ending inventory was $37.2 million, an increase of $4.8 million from Q1 and a decrease of $12.6 million from Q2 last year. The quarter-over-quarter increase was primarily driven by an increase in finished goods inventory. The year-over-year decrease in inventory largely reflect improved demand planning, SKU rationalization and higher inventory turnover. In addition, supply constraints in the recent quarters have contributed to the reduction in inventory year-over-year. |

[0001564590-22-002568:8k_2_02:46]
|  | • | Q2 ending gross debt*** was $322.9 million, a decrease of $7.1 million from the prior quarter. The $33.4 million decrease from Q2 last year resulted primarily from principal payments on our term loan. Q2 ending net debt*** was $149.4 million, increased by $10.7 million from $138.7 million in Q1. |

[0001564590-22-002568:8k_2_02:47]
*SaaS ARR: Extreme uses SaaS annual recurring revenue (“SaaS ARR”) to identify the annual recurring value of customer contracts at the end of a reporting period. We believe that SaaS ARR is an important metric because it is driven by our ability to acquire new customers and to maintain and expand our relationship with existing customers. SaaS ARR represents the projected annualized revenue run-rate of active ExtremeCloud™ IQ (XIQ) and other subscription contracts, at the end of a reporting period.  Each contract (either fulfilled or yet to be fulfilled) is annualized by dividing the contract value by the number of months in the contract term and then multiplying by 12. Calculated SaaS ARR for each contract is then aggregated to arrive at total SaaS ARR. SaaS ARR should be viewed independently of revenue and does not represent our revenue under U.S. GAAP on an annualized basis. It is an operating metric that can be impacted by contract start and end dates, bookings changes and renewal rates. SaaS ARR does not have a standardized meaning and therefore may not be comparable to similarly titled measures presented by other companies. SaaS ARR is not intended to be a replacement for forecasts of revenue.

[0001564590-22-002568:8k_2_02:48]
Extreme uses the non-GAAP free cash flow metric as a measure of operating performance. Free cash flow represents GAAP net cash provided by operating activities, less purchases of property, plant and equipment.  Extreme considers free cash flow to be useful information for management and investors regarding the amount of cash generated by the business after the purchases of property, plant and equipment, which can then be used to, among other things, invest in Extreme’s business, make strategic acquisitions, and strengthen the balance sheet. A limitation of the utility of this non-GAAP free cash flow metric as a measure of financial performance is that it does not represent the total increase or decrease in the Company's cash balance for the period. The following table shows non-GAAP free cash flow calculation (in thousands):

[0001564590-22-002568:8k_2_02:49]
| Free Cash Flow | Three Months Ended |  |  | Six Months Ended |  |
|  | December 31, 2021 |  |  | December 31, 2020 |  |  | December 31, 2021 |  |  | December 31, 2020 |  |
| Cash flow provided by operations | $ | 22,228 |  |  | $ | 38,026 |  |  | $ | 62,482 |  |  | $ | 62,771 |  |
| Less: Property and equipment capital expenditures |  | (3,243 | ) |  |  | (5,016 | ) |  |  | (6,653 | ) |  |  | (8,039 | ) |
| Total free cash flow | $ | 18,985 |  |  | $ | 33,010 |  |  | $ | 55,829 |  |  | $ | 54,732 |  |

[0001564590-22-002568:8k_2_02:50]
***Gross Debt: Gross debt is defined as long-term and current portion of long-term debt as shown on the balance sheet plus unamortized debt issuance costs, if any. Net debt is defined as gross debt minus cash, as shown in the table below (in millions):

[0001564590-22-002568:8k_2_02:51]
| Gross debt |  |  | Cash |  |  | Net debt |  |
| $ | 322.9 |  |  | $ | 173.5 |  |  | $ | 149.4 |  |

[0001564590-22-002568:8k_2_02:52]
Business Outlook:

[0001564590-22-002568:8k_2_02:53]
For its third quarter of fiscal 2022, ending March 31, 2022, the Company is targeting:

[0001564590-22-002568:8k_2_02:54]
| (in millions, except percentages and per share information) | Low-End |  |  | High-End |  |
| FQ3'22 Guidance – GAAP |  |  |  |  |  |  |  |
| Total net revenue | $ | 276.0 |  |  | $ | 286.0 |  |
| Gross margin |  | 55.8 | % |  |  | 57.8 | % |
| Operating expenses | $ | 143.1 |  |  | $ | 147.1 |  |
| Operating margin |  | 3.9 | % |  |  | 6.4 | % |
| Net income | $ | 5.1 |  |  | $ 12.6 |  |
| Net income per diluted share | $ | 0.04 |  |  | $ | 0.09 |  |
| Shares outstanding used in calculating GAAP EPS |  | 133.6 |  |  |  | 133.6 |  |
| FQ3’22 Guidance – Non - GAAP |  |  |  |  |  |  |  |
| Total net revenue | $ | 276.0 |  |  | $ | 286.0 |  |
| Gross margin |  | 57.3 | % |  |  | 59.3 | % |
| Operating expenses | $ | 129.3 |  |  | $ | 133.3 |  |
| Operating margin |  | 10.5 | % |  |  | 12.7 | % |
| Net income | $ | 21.3 |  |  | $ | 28.7 |  |
| Net income per diluted share | $ | 0.16 |  |  | $ | 0.21 |  |
| Shares outstanding used in calculating non-GAAP EPS |  | 133.6 |  |  |  | 133.6 |  |

[0001564590-22-002568:8k_2_02:55]
The following table shows the GAAP to non-GAAP reconciliation for Q3 FY’22 guidance:

[0001564590-22-002568:8k_2_02:56]
|  | Gross Margin Rate |  |  | Operating Margin Rate |  |  | Earnings per Share |  |
| GAAP | 55.8% - 57.8% |  |  | 3.9% - 6.4% |  |  | $0.04 - $0.09 |  |
| Estimated adjustments for: |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of product intangibles | 1.0% |  |  | 1.0% |  |  |  | 0.02 |  |
| Share-based compensation | 0.2% |  |  | 3.8% |  |  |  | 0.08 |  |
| Restructuring | — |  |  | 0.1% |  |  |  | 0.00 |  |
| Acquisition and integration costs | — |  |  | 1.0% |  |  |  | 0.02 |  |
| Amortization of non-product intangibles | 0.3% |  |  | 0.5% |  |  |  | 0.01 |  |
| Tax effect of non-GAAP adjustments |  | — |  |  | — |  |  |  | (0.01) |  |
| Non-GAAP | 57.3% - 59.3% |  |  | 10.5% - 12.7% |  |  | $0.16 - $0.21 |  |

[0001564590-22-002568:8k_2_02:57]
The total of percentage rate changes may not equal the total change in all cases due to rounding.

[0001564590-22-002568:8k_2_02:58]
Conference Call:

[0001564590-22-002568:8k_2_02:59]
Extreme will host a conference call at 8:00 a.m. Eastern (5:00 a.m. Pacific) today to review the second fiscal quarter results as well as the business outlook for the third quarter ending March 31, 2022, including significant factors and assumptions underlying the targets noted above. The conference call will be available to the public through a live audio web broadcast via the internet at http://investor.extremenetworks.com and a replay of the call will be available on the website for at least 7 days following the call. The conference call may also be heard by dialing 1 (877) 303-9826 or international 1 (224) 357-2194 with Conference ID #5061488. Supplemental financial information to be discussed during the conference call will be posted in the Investor Relations section of the Company's website www.extremenetworks.com including the non-GAAP reconciliation attached to this press release. The encore recording can be accessed by dialing 1 (855) 859-2056 or international 1 (404) 537-3406. Conference ID #5061488. The encore recording will be available for at least 7 days following the call.

[0001564590-22-002568:8k_2_02:60]
About Extreme:

[0001564590-22-002568:8k_2_02:61]
Extreme Networks, Inc. (EXTR) creates effortless networking experiences that enable all of us to advance. We push the boundaries of technology leveraging the powers of machine learning, artificial intelligence, analytics, and automation. Over 50,000 customers globally trust our end-to-end, cloud-driven networking solutions and rely on our top-rated services and support to accelerate their digital transformation efforts and deliver progress like never before. For more information, visit Extreme's website or follow us on Twitter, LinkedIn, and Facebook.

[0001564590-22-002568:8k_2_02:62]
Extreme Networks, ExtremeCloud, and the Extreme Networks logo, are trademarks of Extreme Networks, Inc. or its subsidiaries in the United States and/or other countries. Other trademarks shown herein are the property of their respective owners.

[0001564590-22-002568:8k_2_02:63]
Non-GAAP Financial Measures:

[0001564590-22-002568:8k_2_02:64]
Extreme provides all financial information required in accordance with U.S. generally accepted accounting principles (“GAAP”). The Company is providing with this press release non-GAAP gross margin, non-GAAP operating expenses, non-GAAP operating margin, non-GAAP operating income, non-GAAP net income, non-GAAP net income per diluted share, non-GAAP free cash flow and SaaS ARR. In preparing non-GAAP information, the Company has excluded, where applicable, the impact of share-

[0001564590-22-002568:8k_2_02:65]
based compensation, acquisition and integration costs, amortization of intangibles, and restructuring charges.  The Company believes that excluding these items provides both management and investors with additional insight into its current operations, the trends affecting the Company, the Company's marketplace performance, and the Company's ability to generate cash from operations. Please note the Company's non-GAAP measures may be different than those used by other companies. The additional non-GAAP financial information the Company presents should be considered in conjunction with, and not as a substitute for, the Company's GAAP financial information.

[0001564590-22-002568:8k_2_02:66]
The Company has provided a non-GAAP reconciliation of the results for the periods presented in this release, which are adjusted to exclude certain items as indicated.  These measures should only be used to evaluate the Company's results of operations in conjunction with the corresponding GAAP measures for comparable financial information and understanding of the Company's ongoing performance as a business. Extreme uses both GAAP and non-GAAP measures to evaluate and manage its operations.

[0001564590-22-002568:8k_2_02:67]
Forward-Looking Statements:

[0001564590-22-002568:8k_2_02:68]
More information about potential factors that could affect the Company's business and financial results are described in “Management's Discussion and Analysis of Financial Condition and Results of Operations” and “Risk Factors” included in the Company’s Annual Report on Form 10-K for the year ended June 30, 2021, Quarterly Report on form 10-Q for the quarter ended September 30, 2021, and other documents of the Company on file with the Securities and Exchange Commission (available at www.sec.gov).  As a result of these risks and others, actual results could vary significantly from those anticipated in this press release, and the company’s financial condition and results of operations could be materially adversely affected. Except as required under the U.S. federal securities laws and the rules and regulations of the U.S. Securities and Exchange Commission, Extreme disclaims any obligation to update any forward-looking statements after the date of this release, whether as a result of new information, future events, developments, changes in assumptions or otherwise.

[0001564590-22-002568:8k_2_02:69]
###

[0001564590-22-002568:8k_2_02:70]
EXTREME NETWORKS, INC.

[0001564590-22-002568:8k_2_02:71]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0001564590-22-002568:8k_2_02:72]
(In thousands, except per share amounts)

[0001564590-22-002568:8k_2_02:73]
(Unaudited)

[0001564590-22-002568:8k_2_02:74]
|  |  | December 31, 2021 |  |  | June 30, 2021 |  |
| ASSETS |  |  |  |  |  |  |  |  |
| Current assets: |  |  |  |  |  |  |  |  |
| Cash |  | $ | 173,548 |  |  | $ | 246,894 |  |
| Accounts receivable, net |  |  | 133,255 |  |  |  | 156,476 |  |
| Inventories |  |  | 37,180 |  |  |  | 32,885 |  |
| Prepaid expenses and other current assets |  |  | 86,534 |  |  |  | 51,340 |  |
| Total current assets |  |  | 430,517 |  |  |  | 487,595 |  |
| Property and equipment, net |  |  | 52,117 |  |  |  | 55,004 |  |
| Operating lease right-of-use assets, net |  |  | 31,177 |  |  |  | 36,927 |  |
| Intangible assets, net |  |  | 40,945 |  |  |  | 36,038 |  |
| Goodwill |  |  | 395,246 |  |  |  | 331,159 |  |
| Other assets |  |  | 62,798 |  |  |  | 63,370 |  |
| Total assets |  | $ | 1,012,800 |  |  | $ | 1,010,093 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |  |  |  |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |  |  |  |
| Current portion of long-term debt, net of unamortized debt issuance costs of $2,333 and $2,404, respectively |  | $ | 28,542 |  |  | $ | 23,721 |  |
| Accounts payable |  |  | 58,831 |  |  |  | 60,142 |  |
| Accrued compensation and benefits |  |  | 65,543 |  |  |  | 71,610 |  |
| Accrued warranty |  |  | 11,137 |  |  |  | 11,623 |  |
| Current portion, operating lease liabilities |  |  | 18,140 |  |  |  | 18,743 |  |
| Current portion, deferred revenue |  |  | 224,735 |  |  |  | 212,412 |  |
| Other accrued liabilities |  |  | 60,752 |  |  |  | 57,449 |  |
| Total current liabilities |  |  | 467,680 |  |  |  | 455,700 |  |
| Deferred revenue, less current portion |  |  | 148,477 |  |  |  | 133,172 |  |
| Long-term debt, less current portion, net of unamortized debt issuance costs of $3,542 and $4,760, respectively |  |  | 288,458 |  |  |  | 315,865 |  |
| Operating lease liabilities, less current portion |  |  | 25,437 |  |  |  | 32,515 |  |
| Deferred income taxes |  |  | 4,139 |  |  |  | 3,828 |  |
| Other long-term liabilities |  |  | 9,010 |  |  |  | 14,545 |  |
| Commitments and contingencies |  |  |  |  |  |  |  |  |
| Stockholders’ equity: |  |  |  |  |  |  |  |  |
| Convertible preferred stock, $0.001 par value, issuable in series, 2,000 shares authorized; none issued |  |  | — |  |  |  | — |  |
| Common stock, $0.001 par value, 750,000 shares authorized; 137,478 and 133,279 shares issued, respectively; 129,052 and 126,682 shares outstanding, respectively |  |  | 137 |  |  |  | 133 |  |
| Additional paid-in-capital |  |  | 1,092,646 |  |  |  | 1,078,602 |  |
| Accumulated other comprehensive loss |  |  | (2,791 | ) |  |  | (2,811 | ) |
| Accumulated deficit |  |  | (952,306 | ) |  |  | (978,343 | ) |
| Treasury stock at cost, 8,426 and 6,597 shares, respectively |  |  | (68,087 | ) |  |  | (43,113 | ) |
| Total stockholders’ equity |  |  | 69,599 |  |  |  | 54,468 |  |
| Total liabilities and stockholders’ equity |  | $ | 1,012,800 |  |  | $ | 1,010,093 |  |

[0001564590-22-002568:8k_2_02:75]
EXTREME NETWORKS, INC.

[0001564590-22-002568:8k_2_02:76]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS

[0001564590-22-002568:8k_2_02:77]
(In thousands, except per share amounts)

[0001564590-22-002568:8k_2_02:78]
(Unaudited)

[0001564590-22-002568:8k_2_02:79]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | December 31, 2021 |  |  | December 31, 2020 |  |  | December 31, 2021 |  |  | December 31, 2020 |  |
| Net revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 191,102 |  |  | $ | 165,845 |  |  | $ | 376,263 |  |  | $ | 327,241 |  |
| Service and subscription |  |  | 89,831 |  |  |  | 76,283 |  |  |  | 172,354 |  |  |  | 150,689 |  |
| Total net revenues |  |  | 280,933 |  |  |  | 242,128 |  |  |  | 548,617 |  |  |  | 477,930 |  |
| Cost of revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  |  | 90,933 |  |  |  | 74,005 |  |  |  | 171,877 |  |  |  | 147,400 |  |
| Service and subscription |  |  | 31,214 |  |  |  | 27,931 |  |  |  | 62,351 |  |  |  | 55,320 |  |
| Total cost of revenues |  |  | 122,147 |  |  |  | 101,936 |  |  |  | 234,228 |  |  |  | 202,720 |  |
| Gross profit: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  |  | 100,169 |  |  |  | 91,840 |  |  |  | 204,386 |  |  |  | 179,841 |  |
| Service and subscription |  |  | 58,617 |  |  |  | 48,352 |  |  |  | 110,003 |  |  |  | 95,369 |  |
| Total gross profit |  |  | 158,786 |  |  |  | 140,192 |  |  |  | 314,389 |  |  |  | 275,210 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Research and development |  |  | 48,080 |  |  |  | 49,186 |  |  |  | 95,846 |  |  |  | 98,710 |  |
| Sales and marketing |  |  | 71,565 |  |  |  | 66,732 |  |  |  | 141,092 |  |  |  | 131,057 |  |
| General and administrative |  |  | 17,877 |  |  |  | 16,360 |  |  |  | 34,880 |  |  |  | 32,821 |  |
| Acquisition and integration costs |  |  | 2,113 |  |  |  | — |  |  |  | 3,623 |  |  |  | 1,975 |  |
| Restructuring and related charges |  |  | 292 |  |  |  | 695 |  |  |  | 571 |  |  |  | 1,696 |  |
| Amortization of intangibles |  |  | 804 |  |  |  | 1,506 |  |  |  | 1,958 |  |  |  | 3,298 |  |
| Total operating expenses |  |  | 140,731 |  |  |  | 134,479 |  |  |  | 277,970 |  |  |  | 269,557 |  |
| Operating income |  |  | 18,055 |  |  |  | 5,713 |  |  |  | 36,419 |  |  |  | 5,653 |  |
| Interest income |  |  | 83 |  |  |  | 82 |  |  |  | 193 |  |  |  | 200 |  |
| Interest expense |  |  | (3,076 | ) |  |  | (6,068 | ) |  |  | (6,956 | ) |  |  | (12,731 | ) |
| Other income (expense), net |  |  | 72 |  |  |  | (954 | ) |  |  | 243 |  |  |  | (1,841 | ) |
| Income (loss) before income taxes |  |  | 15,134 |  |  |  | (1,227 | ) |  |  | 29,899 |  |  |  | (8,719 | ) |
| Provision for income taxes |  |  | 1,793 |  |  |  | 1,823 |  |  |  | 3,862 |  |  |  | 3,143 |  |
| Net income (loss) |  | $ | 13,341 |  |  | $ | (3,050 | ) |  | $ | 26,037 |  |  | $ | (11,862 | ) |
| Basic and diluted income (loss) per share: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income (loss) per share - basic |  | $ | 0.10 |  |  | $ | (0.02 | ) |  | $ | 0.20 |  |  | $ | (0.10 | ) |
| Net income (loss) per share - diluted |  | $ | 0.10 |  |  | $ | (0.02 | ) |  | $ | 0.20 |  |  | $ | (0.10 | ) |
| Shares used in per share calculation - basic |  |  | 129,403 |  |  |  | 123,264 |  |  |  | 128,863 |  |  |  | 122,485 |  |
| Shares used in per share calculation - diluted |  |  | 133,621 |  |  |  | 123,264 |  |  |  | 133,423 |  |  |  | 122,485 |  |

[0001564590-22-002568:8k_2_02:80]
EXTREME NETWORKS, INC.

[0001564590-22-002568:8k_2_02:81]
CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS

[0001564590-22-002568:8k_2_02:82]
(In thousands)

[0001564590-22-002568:8k_2_02:83]
(Unaudited)

[0001564590-22-002568:8k_2_02:84]
|  |  | Six Months Ended |  |
|  |  | December 31, 2021 |  |  | December 31, 2020 |  |
| Cash flows from operating activities: |  |  |  |  |  |  |  |  |
| Net Income (loss) |  | $ | 26,037 |  |  | $ | (11,862 | ) |
| Adjustments to reconcile net income (loss) to net cash provided by operating activities: |  |  |  |  |  |  |  |  |
| Depreciation |  |  | 10,233 |  |  |  | 12,471 |  |
| Amortization of intangible assets |  |  | 11,393 |  |  |  | 16,646 |  |
| Reduction in carrying amount of right-of-use asset |  |  | 7,778 |  |  |  | 8,072 |  |
| Provision for doubtful accounts |  |  | 14 |  |  |  | 143 |  |
| Share-based compensation |  |  | 21,777 |  |  |  | 18,397 |  |
| Deferred income taxes |  |  | 890 |  |  |  | 628 |  |
| Non-cash interest expense |  |  | 2,517 |  |  |  | 2,171 |  |
| Other |  |  | (474 | ) |  |  | 3,195 |  |
| Changes in operating assets and liabilities, net of acquisition: |  |  |  |  |  |  |  |  |
| Accounts receivable |  |  | 24,626 |  |  |  | (5,658 | ) |
| Inventories |  |  | (4,239 | ) |  |  | 6,340 |  |
| Prepaid expenses and other assets |  |  | (34,215 | ) |  |  | (3,740 | ) |
| Accounts payable |  |  | (2,505 | ) |  |  | 4,913 |  |
| Accrued compensation and benefits |  |  | (8,378 | ) |  |  | 10,984 |  |
| Operating lease liabilities |  |  | (9,675 | ) |  |  | (10,116 | ) |
| Deferred revenue |  |  | 17,785 |  |  |  | 17,949 |  |
| Other current and long-term liabilities |  |  | (1,082 | ) |  |  | (7,762 | ) |
| Net cash provided by operating activities |  |  | 62,482 |  |  |  | 62,771 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |
| Capital expenditures |  |  | (6,653 | ) |  |  | (8,039 | ) |
| Business acquisition, net of cash acquired |  |  | (69,517 | ) |  |  | — |  |
| Net cash used in investing activities |  |  | (76,170 | ) |  |  | (8,039 | ) |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |
| Payments on debt obligations |  |  | (23,875 | ) |  |  | (64,500 | ) |
| Repurchase of common stock |  |  | (24,974 | ) |  |  | — |  |
| Payments for tax withholdings, net of proceeds from issuance of common stock |  |  | (7,729 | ) |  |  | 2,284 |  |
| Payment of contingent consideration obligations |  |  | (816 | ) |  |  | (1,021 | ) |
| Deferred payments on an acquisition |  |  | (2,000 | ) |  |  | (2,000 | ) |
| Net cash used in financing activities |  |  | (59,394 | ) |  |  | (65,237 | ) |
| Foreign currency effect on cash |  |  | (264 | ) |  |  | 602 |  |
| Net decrease in cash |  |  | (73,346 | ) |  |  | (9,903 | ) |
| Cash at beginning of period |  |  | 246,894 |  |  |  | 193,872 |  |
| Cash at end of period |  | $ | 173,548 |  |  | $ | 183,969 |  |

[0001564590-22-002568:8k_2_02:85]
Extreme Networks, Inc.

[0001564590-22-002568:8k_2_02:86]
Non-GAAP Measures of Financial Performance

[0001564590-22-002568:8k_2_02:87]
To supplement the Company's consolidated financial statements presented in accordance with U.S. generally accepted accounting principles, (“GAAP”), Extreme uses non-GAAP measures of certain components of financial performance.  These non-GAAP measures include non-GAAP gross margin, non-GAAP operating expenses, non-GAAP operating margin, non-GAAP operating income, non-GAAP net income, non-GAAP net income per diluted share, non-GAAP free cash flow and SaaS ARR.

[0001564590-22-002568:8k_2_02:88]
Reconciliation to the nearest GAAP measure of all historical non-GAAP measures included in this press release can be found in the tables included with this press release.

[0001564590-22-002568:8k_2_02:89]
Non-GAAP measures presented in this press release are not in accordance with or alternative measures prepared in accordance with GAAP and may be different from non-GAAP measures used by other companies.  In addition, these non-GAAP measures are not based on any comprehensive set of accounting rules or principles.  Non-GAAP measures have limitations in that they do not reflect all of the amounts associated with Extreme’s results of operations as determined in accordance with GAAP.  These non-GAAP measures should only be used to evaluate Extreme’s results of operations in conjunction with the corresponding GAAP measures.

[0001564590-22-002568:8k_2_02:90]
Extreme believes these non-GAAP measures when shown in conjunction with the corresponding GAAP measures enhance investors' and management's overall understanding of the Company's current financial performance and the Company's prospects for the future, including cash flows available to pursue opportunities to enhance stockholder value.  In addition, because Extreme has historically reported certain non-GAAP results to investors, the Company believes the inclusion of non-GAAP measures provides consistency in the Company's financial reporting.

[0001564590-22-002568:8k_2_02:91]
For its internal planning process, and as discussed further below, Extreme's management uses financial statements that do not include share-based compensation expense, acquisition and integration costs, amortization of intangibles, restructuring charges, and the tax effect of non-GAAP adjustments.  Extreme’s management also uses non-GAAP measures, in addition to the corresponding GAAP measures, in reviewing the Company's financial results.

[0001564590-22-002568:8k_2_02:92]
As described above, Extreme excludes the following items from one or more of its non-GAAP measures when applicable.

[0001564590-22-002568:8k_2_02:93]
Share-based compensation. Consists of associated expenses for stock options, restricted stock awards and the Company’s Employee Stock Purchase Plan.  Extreme excludes share-based compensation expenses from its non-GAAP measures primarily because they are non-cash expenses that the Company does not believe are reflective of ongoing cash requirement related to its operating results. Extreme expects to incur share-based compensation expenses in future periods.

[0001564590-22-002568:8k_2_02:94]
Acquisition and integration costs. Acquisition and integration costs consist of specified compensation charges, software charges, legal and professional fees related to the acquisition of Aerohive and Ipanema.  Extreme excludes these expenses since they result from an event that is outside the ordinary course of continuing operations.

[0001564590-22-002568:8k_2_02:95]
Amortization of intangibles. Amortization of intangibles includes the monthly amortization expense of intangible assets such as developed technology, customer relationships, trademarks and order backlog.  The amortization of the developed technology and order backlog are recorded in cost of goods sold, while the amortization for the other intangibles are recorded in operating expenses.  Extreme excludes these expenses since they result from an intangible asset and for which the period expense does not impact the operations of the business and are non-cash in nature.

[0001564590-22-002568:8k_2_02:96]
Restructuring charges. Restructuring charges primarily consist of severance costs for employees which have no benefit to continuing operations and impairment of right-of-use assets, long-lived assets and other charges related to excess facilities. Extreme excludes restructuring expenses since they result from events that occur outside of the ordinary course of continuing operations.

[0001564590-22-002568:8k_2_02:97]
Tax effect of non-GAAP adjustments. We calculate our non-GAAP provision for income taxes in accordance with the SEC guidance on non-GAAP Financial Measures Compliance and Disclosure Interpretation.  We have assumed our U.S. federal and state net operating losses would have been fully consumed by the historical non-GAAP financial adjustments, eliminating the need for a full valuation allowance against our U.S. deferred tax assets which, consequently, enables our use of research and development tax credits.  The non-GAAP tax provision consists of current and deferred income tax expense commensurate with the non-GAAP measure of profitability using our blended U.S. statutory tax rate of 24.2%.

[0001564590-22-002568:8k_2_02:98]
Non-GAAP provision for income taxes may be higher or lower depending on the level and jurisdictional mix of pre-tax income and available U.S. research and development tax credits.  As of the tax year ended June 30, 2021, we had U.S. federal net operating loss carryforwards of $242 million, state net operating loss carryforwards of $156 million and Irish net operating losses of $15 million.  These amounts will be reflected in our requisite tax filings for each jurisdiction for the tax year ended June 30, 2021. We do not expect to pay substantial taxes on a GAAP basis in the U.S. for the foreseeable future due to our net operating loss carryforward balances.  Over the near term, most of our cash taxes will continue to be mainly driven by the tax expense of our foreign subsidiaries which amounts have not historically been significant, with the exception of the Company’s Irish operating company which has fully utilized available net operating loss carryforwards during fiscal 2021.  We also believe our long-term effective GAAP tax rate will be lower than the U.S. statutory rate based upon our established tax structure.

[0001564590-22-002568:8k_2_02:99]
EXTREME NETWORKS, INC.

[0001564590-22-002568:8k_2_02:100]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS

[0001564590-22-002568:8k_2_02:101]
GAAP TO NON-GAAP RECONCILIATION

[0001564590-22-002568:8k_2_02:102]
(In thousands, except percentages and per share amounts)

[0001564590-22-002568:8k_2_02:103]
(Unaudited)

[0001564590-22-002568:8k_2_02:104]
| Revenues | Three Months Ended |  |  | Six Months Ended |  |
|  | December 31, 2021 |  |  | December 31, 2020 |  |  | December 31, 2021 |  |  | December 31, 2020 |  |
| Revenues – GAAP | $ | 280,933 |  |  | $ | 242,128 |  |  | $ | 548,617 |  |  | $ | 477,930 |  |

[0001564590-22-002568:8k_2_02:105]
| Non-GAAP Gross Margin | Three Months Ended |  |  | Six Months Ended |  |
|  | December 31, 2021 |  |  | December 31, 2020 |  |  | December 31, 2021 |  |  | December 31, 2020 |  |
| Gross profit – GAAP | $ | 158,786 |  |  | $ | 140,192 |  |  | $ | 314,389 |  |  | $ | 275,210 |  |
| Gross margin – GAAP percentage |  | 56.5 | % |  |  | 57.9 | % |  |  | 57.3 | % |  |  | 57.6 | % |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expense |  | 654 |  |  |  | 753 |  |  |  | 1,326 |  |  |  | 1,383 |  |
| Acquisition and integration costs |  | — |  |  |  | — |  |  |  | — |  |  |  | 10 |  |
| Amortization of intangibles |  | 4,132 |  |  |  | 6,633 |  |  |  | 9,401 |  |  |  | 13,266 |  |
| Total adjustments to GAAP gross profit | $ | 4,786 |  |  | $ | 7,386 |  |  | $ | 10,727 |  |  | $ | 14,659 |  |
| Gross profit – non-GAAP | $ | 163,572 |  |  | $ | 147,578 |  |  | $ | 325,116 |  |  | $ | 289,869 |  |
| Gross margin – non-GAAP percentage |  | 58.2 | % |  |  | 61.0 | % |  |  | 59.3 | % |  |  | 60.7 | % |

[0001564590-22-002568:8k_2_02:106]
| Non-GAAP Operating Income | Three Months Ended |  |  | Six Months Ended |  |
|  | December 31, 2021 |  |  | December 31, 2020 |  |  | December 31, 2021 |  |  | December 31, 2020 |  |
| GAAP operating income | $ | 18,055 |  |  | $ | 5,713 |  |  | $ | 36,419 |  |  | $ | 5,653 |  |
| GAAP operating income percentage |  | 6.4 | % |  |  | 2.4 | % |  |  | 6.6 | % |  |  | 1.2 | % |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expense, cost of revenues |  | 654 |  |  |  | 753 |  |  |  | 1,326 |  |  |  | 1,383 |  |
| Share-based compensation expense, R&D |  | 2,664 |  |  |  | 2,694 |  |  |  | 5,122 |  |  |  | 4,966 |  |
| Share-based compensation expense, S&M |  | 3,860 |  |  |  | 3,239 |  |  |  | 7,435 |  |  |  | 5,886 |  |
| Share-based compensation expense, G&A |  | 4,155 |  |  |  | 3,409 |  |  |  | 7,894 |  |  |  | 6,162 |  |
| Acquisition and integration costs |  | 2,113 |  |  |  | — |  |  |  | 3,623 |  |  |  | 1,985 |  |
| Restructuring charges, net of reversals |  | 292 |  |  |  | 695 |  |  |  | 571 |  |  |  | 1,696 |  |
| Amortization of intangibles |  | 4,936 |  |  |  | 8,139 |  |  |  | 11,359 |  |  |  | 16,564 |  |
| Total adjustments to GAAP operating income | $ | 18,674 |  |  | $ | 18,929 |  |  | $ | 37,330 |  |  | $ | 38,642 |  |
| Non-GAAP operating income | $ | 36,729 |  |  | $ | 24,642 |  |  | $ | 73,749 |  |  | $ | 44,295 |  |
| Non-GAAP operating income percentage |  | 13.1 | % |  |  | 10.2 | % |  |  | 13.4 | % |  |  | 9.3 | % |

[0001564590-22-002568:8k_2_02:107]
| Non-GAAP net income | Three Months Ended |  |  | Six Months Ended |  |
|  | December 31, 2021 |  |  | December 31, 2020 |  |  | December 31, 2021 |  |  | December 31, 2020 |  |
| GAAP net income (loss) | $ | 13,341 |  |  | $ | (3,050 | ) |  | $ | 26,037 |  |  | $ | (11,862 | ) |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expense |  | 11,333 |  |  |  | 10,095 |  |  |  | 21,777 |  |  |  | 18,397 |  |
| Acquisition and integration costs |  | 2,113 |  |  |  | — |  |  |  | 3,623 |  |  |  | 1,985 |  |
| Restructuring charge, net of reversal |  | 292 |  |  |  | 695 |  |  |  | 571 |  |  |  | 1,696 |  |
| Amortization of intangibles |  | 4,936 |  |  |  | 8,139 |  |  |  | 11,359 |  |  |  | 16,564 |  |
| Tax effect of non-GAAP adjustments |  | (3,580 | ) |  |  | 107 |  |  |  | (6,980 | ) |  |  | 165 |  |
| Total adjustments to GAAP net income (loss) | $ | 15,094 |  |  | $ | 19,036 |  |  | $ | 30,350 |  |  | $ | 38,807 |  |
| Non-GAAP net income | $ | 28,435 |  |  | $ | 15,986 |  |  | $ | 56,387 |  |  | $ | 26,945 |  |
| Earnings per share |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Non-GAAP net income per share – diluted | $ | 0.21 |  |  | $ | 0.13 |  |  | $ | 0.42 |  |  | $ | 0.22 |  |
| Shares used in net income per share – diluted: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| GAAP Shares used in per share calculation – basic |  | 129,403 |  |  |  | 123,264 |  |  |  | 128,863 |  |  |  | 122,485 |  |
| Potentially dilutive equity awards |  | 4,218 |  |  |  | 2,463 |  |  |  | 4,560 |  |  |  | 1,681 |  |
| GAAP and Non-GAAP shares used in per share calculation – diluted |  | 133,621 |  |  |  | 125,727 |  |  |  | 133,423 |  |  |  | 124,166 |  |
