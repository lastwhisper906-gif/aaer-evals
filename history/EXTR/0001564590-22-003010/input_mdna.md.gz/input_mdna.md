# EXTR MD&A — 0001564590-22-003010


## mdna

[0001564590-22-003010:mdna:1]
[same as prior period, unchanged from 0001564590-21-054929:mdna:1]

[0001564590-22-003010:mdna:2]
[same as prior period, unchanged from 0001564590-21-054929:mdna:2]

[0001564590-22-003010:mdna:3]
[same as prior period, unchanged from 0001564590-21-054929:mdna:3]

[0001564590-22-003010:mdna:4]
[same as prior period, unchanged from 0001564590-21-054929:mdna:4]

[0001564590-22-003010:mdna:5]
[same as prior period, unchanged from 0001564590-21-054929:mdna:5]

[0001564590-22-003010:mdna:6]
[same as prior period, unchanged from 0001564590-21-054929:mdna:6]

[0001564590-22-003010:mdna:7]
[same as prior period, unchanged from 0001564590-21-054929:mdna:7]

[0001564590-22-003010:mdna:8]
We believe Extreme stands to benefit from the use of its technology to manage distributed campus network architecture centrally from the cloud. Extreme has blended a dynamic fabric attach architecture, that delivers simplicity for moves and changes at the edge of the network, together with corporate-wide role-based policy. This enables customers to migrate to new cloud managed switching and Wi-Fi, agnostic of the existing networking or wireless equipment they already have installed. In the end, we expect these customers to see lower operating and capital expenditures, lower subscription costs, lower overall cost of ownership and more flexibility along with a more resilient network. We estimate the total addressable market for our Enterprise Networking solutions consisting of cloud networking, wireless local area networks (“WLAN”), data center networking, ethernet switching, campus local area networks (“LAN”), and software-defined wide area network (“SD-WAN”) solutions to be approximately $26 billion and growing at approximately five percent per year over the next three years.  In addition, we estimate that 5G provides an estimated $3 billion serviceable available market for Service Provider Networking.

[0001564590-22-003010:mdna:9]
[same as prior period, unchanged from 0001564590-21-054929:mdna:9]

[0001564590-22-003010:mdna:10]
[same as prior period, unchanged from 0001564590-21-054929:mdna:10]

[0001564590-22-003010:mdna:11]
[same as prior period, unchanged from 0001564590-21-054929:mdna:11]

[0001564590-22-003010:mdna:12]
|  | • | Infinitely distributed connectivity is the enterprise-grade reliable connectivity that allows users to connect to anywhere, from anywhere. It is always present, available and assured, while being secure and manageable. |

[0001564590-22-003010:mdna:13]
[same as prior period, unchanged from 0001564590-21-054929:mdna:13]

[0001564590-22-003010:mdna:14]
[same as prior period, unchanged from 0001564590-21-054929:mdna:14]

[0001564590-22-003010:mdna:15]
[same as prior period, unchanged from 0001564590-21-054929:mdna:15]

[0001564590-22-003010:mdna:16]
[same as prior period, unchanged from 0001564590-21-054929:mdna:16]

[0001564590-22-003010:mdna:17]
[same as prior period, unchanged from 0001564590-21-054929:mdna:17]

[0001564590-22-003010:mdna:18]
[same as prior period, unchanged from 0001564590-21-054929:mdna:18]

[0001564590-22-003010:mdna:19]
[same as prior period, unchanged from 0001564590-21-054929:mdna:19]

[0001564590-22-003010:mdna:20]
[same as prior period, unchanged from 0001564590-21-054929:mdna:20]

[0001564590-22-003010:mdna:21]
[same as prior period, unchanged from 0001564590-21-054929:mdna:21]

[0001564590-22-003010:mdna:22]
[same as prior period, unchanged from 0001564590-21-054929:mdna:22]

[0001564590-22-003010:mdna:23]
[same as prior period, unchanged from 0001564590-21-054929:mdna:23]

[0001564590-22-003010:mdna:24]
[same as prior period, unchanged from 0001564590-21-054929:mdna:24]

[0001564590-22-003010:mdna:25]
|  | • | Offer customers choice: public or private cloud, or on-premises. We leverage the cloud where it makes sense for our customers and provide on-premises solutions where customers need it and also have a solution for those who want to harness the power of both. Our hybrid approach gives our customers options to adapt the technology to their business. At the same time, all of our solutions have visibility, control and strategic information built in, all tightly integrated with a single view across all of the installed products. Our customers can understand what is going on across their network and applications in real time – who, when, and what is connected to the network – critical for bring your own device (“BYOD”) and IoT usage. |

[0001564590-22-003010:mdna:26]
[same as prior period, unchanged from 0001564590-21-054929:mdna:26]

[0001564590-22-003010:mdna:27]
|  | o | Extreme AirDefense™ is a comprehensive wireless intrusion prevention system that simplifies the protection, monitoring and security of wireless networks. With the added Bluetooth and Bluetooth low energy intrusion prevention, network administrators can address growing threats against Bluetooth and low energy devices. |

[0001564590-22-003010:mdna:28]
[same as prior period, unchanged from 0001564590-21-054929:mdna:29]

[0001564590-22-003010:mdna:29]
[same as prior period, unchanged from 0001564590-21-054929:mdna:30]

[0001564590-22-003010:mdna:30]
[same as prior period, unchanged from 0001564590-21-054929:mdna:31]

[0001564590-22-003010:mdna:31]
[same as prior period, unchanged from 0001564590-21-054929:mdna:32]

[0001564590-22-003010:mdna:32]
[same as prior period, unchanged from 0001564590-21-054929:mdna:33]

[0001564590-22-003010:mdna:33]
[same as prior period, unchanged from 0001564590-21-054929:mdna:34]

[0001564590-22-003010:mdna:34]
[same as prior period, unchanged from 0001564590-21-054929:mdna:35]

[0001564590-22-003010:mdna:35]
[same as prior period, unchanged from 0001564590-21-054929:mdna:36]

[0001564590-22-003010:mdna:36]
[same as prior period, unchanged from 0001564590-21-054929:mdna:37]

[0001564590-22-003010:mdna:37]
[same as prior period, unchanged from 0001564590-21-054929:mdna:38]

[0001564590-22-003010:mdna:38]
[same as prior period, unchanged from 0001564590-21-054929:mdna:39]

[0001564590-22-003010:mdna:39]
[same as prior period, unchanged from 0001564590-21-054929:mdna:40]

[0001564590-22-003010:mdna:40]
29

[0001564590-22-003010:mdna:41]
[same as prior period, unchanged from 0001564590-21-054929:mdna:41]

[0001564590-22-003010:mdna:42]
[same as prior period, unchanged from 0001564590-21-054929:mdna:42]

[0001564590-22-003010:mdna:43]
[same as prior period, unchanged from 0001564590-21-054929:mdna:43]

[0001564590-22-003010:mdna:44]
[same as prior period, unchanged from 0001564590-21-054929:mdna:44]

[0001564590-22-003010:mdna:45]
[same as prior period, unchanged from 0001564590-21-054929:mdna:45]

[0001564590-22-003010:mdna:46]
On September 14, 2021, we completed our acquisition (the “Acquisition”) of Ipanematech SAS (“Ipanema”), the cloud-native enterprise Software-Defined Wide Area Network (“SD-WAN”) business unit of Infovista pursuant to a Sale and Purchase Agreement.  Under the terms of the Acquisition, the net consideration paid by Extreme to Ipanema stockholders was $70.9 million. The primary reason for the Acquisition was to acquire the talent and the technology to allow us to expand our portfolio with new cloud-managed SD-WAN and security offerings to support our enterprise customers.

[0001564590-22-003010:mdna:47]
[same as prior period, unchanged from 0001564590-21-054929:mdna:47]

[0001564590-22-003010:mdna:48]
During the second quarter of fiscal 2022, we achieved the following results:

[0001564590-22-003010:mdna:49]
|  | • | Net revenues of $280.9 million compared to $242.1 million in the second quarter of fiscal 2021. |

[0001564590-22-003010:mdna:50]
|  | • | Product revenues of $191.1 million compared to $165.8 million in the second quarter of fiscal 2021. |

[0001564590-22-003010:mdna:51]
|  | • | Service and subscription revenues of $89.8 million compared to $76.3 million in the second quarter of fiscal 2021. |

[0001564590-22-003010:mdna:52]
|  | • | Total gross margin of 56.5% of net revenues compared to 57.9% of net revenues in the second quarter of fiscal 2021. |

[0001564590-22-003010:mdna:53]
|  | • | Operating income of $18.1 million compared to operating income of $5.7 million in the second quarter of fiscal 2021. |

[0001564590-22-003010:mdna:54]
|  | • | Net income of $13.3 million compared to net loss of $3.1 million in the second quarter of fiscal 2021. |

[0001564590-22-003010:mdna:55]
During the first six months of fiscal 2022, we reflected the following results:

[0001564590-22-003010:mdna:56]
|  | • | Cash flows provided by operating activities of $62.4 million compared to $62.8 million in the six months ended December 31, 2020. |

[0001564590-22-003010:mdna:57]
|  | • | Cash of $173.5 million as of December 31, 2021 compared to $246.9 million as of June 30, 2021. |

[0001564590-22-003010:mdna:58]
30

[0001564590-22-003010:mdna:59]
[same as prior period, unchanged from 0001564590-21-054929:mdna:57]

[0001564590-22-003010:mdna:60]
[same as prior period, unchanged from 0001564590-21-054929:mdna:58]

[0001564590-22-003010:mdna:61]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | December 31, 2021 |  |  | December 31, 2020 |  |  | $ Change |  |  | % Change |  |  | December 31, 2021 |  |  | December 31, 2020 |  |  | $ Change |  |  | % Change |  |
| Net revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 191,102 |  |  | $ | 165,845 |  |  | $ | 25,257 |  |  |  | 15.2 | % |  | $ | 376,263 |  |  | $ | 327,241 |  |  | $ | 49,022 |  |  |  | 15.0 | % |
| Percentage of net revenues |  |  | 68.0 | % |  |  | 68.5 | % |  |  |  |  |  |  |  |  |  |  | 68.6 | % |  |  | 68.5 | % |  |  |  |  |  |  |  |  |
| Service and subscription |  |  | 89,831 |  |  |  | 76,283 |  |  |  | 13,548 |  |  |  | 17.8 | % |  |  | 172,354 |  |  |  | 150,689 |  |  |  | 21,665 |  |  |  | 14.4 | % |
| Percentage of net revenues |  |  | 32.0 | % |  |  | 31.5 | % |  |  |  |  |  |  |  |  |  |  | 31.4 | % |  |  | 31.5 | % |  |  |  |  |  |  |  |  |
| Total net revenues |  | $ | 280,933 |  |  | $ | 242,128 |  |  | $ | 38,805 |  |  |  | 16.0 | % |  | $ | 548,617 |  |  | $ | 477,930 |  |  | $ | 70,687 |  |  |  | 14.8 | % |

[0001564590-22-003010:mdna:62]
Product revenues increased $25.3 million or 15.2% for the three months ended December 31, 2021, as compared to the corresponding period of fiscal 2021. Product revenues increased $49.0 million or 15.0% for the six months ended December 31, 2021, as compared to the corresponding period of fiscal 2021. The product revenues increase was primarily due to stronger demand for our products and also due to the material slow-down in global demand during the corresponding period of fiscal 2021 due to the global outbreak of COVID-19.

[0001564590-22-003010:mdna:63]
Service and subscription revenues increased $13.5 million, or 17.8% for the three months ended December 31, 2021 as compared to the corresponding period in fiscal 2021. The increase in service and subscription revenues was primarily due to the growth in our subscription revenues and partially due to the acquisition of Ipanema.

[0001564590-22-003010:mdna:64]
Service and subscription revenues increased $21.7 million, or 14.4% for the six months ended December 31, 2021 as compared to the corresponding period in fiscal 2021. The increase in service and subscription revenues was primarily due to the growth in our subscription revenues.

[0001564590-22-003010:mdna:65]
[same as prior period, unchanged from 0001564590-21-054929:mdna:62]

[0001564590-22-003010:mdna:66]
|  |  | Three Months Ended |  |  | Six Months Ended |  |  |
|  |  | December 31, 2021 |  |  | December 31, 2020 |  |  | $ Change |  |  | % Change |  |  | December 31, 2021 |  | 0 | December 31, 2020 |  |  | $ Change |  |  | % Change |  |  |
| Gross profit: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 100,169 |  |  | $ | 91,840 |  |  | $ | 8,329 |  |  |  | 9.1 | % |  | $ | 204,386 |  |  | $ | 179,841 |  |  | $ | 24,545 |  |  |  | 13.6 | % |  |
| Percentage of product revenues |  |  | 52.4 | % |  |  | 55.4 | % |  |  |  |  |  |  |  |  |  |  | 54.3 | % |  |  | 55.0 | % |  |  |  |  |  |  |  |  |  |
| Service and subscription |  |  | 58,617 |  |  |  | 48,352 |  |  |  | 10,265 |  |  |  | 21.2 | % |  |  | 110,003 |  |  |  | 95,369 |  |  |  | 14,634 |  |  |  | 15.3 | % |  |
| Percentage of service and subscription revenues |  |  | 65.3 | % |  |  | 63.4 | % |  |  |  |  |  |  |  |  |  |  | 63.8 | % |  |  | 63.3 | % |  |  |  |  |  |  |  |  |  |
| Total gross profit |  | $ | 158,786 |  |  | $ | 140,192 |  |  | $ | 18,594 |  |  |  | 13.3 | % |  | $ | 314,389 |  |  | $ | 275,210 |  |  | $ | 39,179 |  |  |  | 14.2 | % |  |
| Percentage of net revenues |  |  | 56.5 | % |  |  | 57.9 | % |  |  |  |  |  |  |  |  |  |  | 57.3 | % |  |  | 57.6 | % |  |  |  |  |  |  |  |  |  |

[0001564590-22-003010:mdna:67]
Product gross profit increased $8.3 million or 9.1% for the three months ended December 31, 2021, as compared to the corresponding period in fiscal 2021. The increase in product gross profit was primarily due to increased revenues along with lower excess and obsolete inventory charges of $1.9 million and lower amortization of intangibles due to certain intangibles being fully depreciated, partially offset by higher distribution cost of $5.1 million primarily due to higher freight costs and higher product costs of $14.0 million primarily related to higher expedite fees due to supply constraints.

[0001564590-22-003010:mdna:68]
Product gross profit increased $24.5 million or 13.6% for the six months ended December 31, 2021, as compared to the corresponding period in fiscal 2021. The increase in product gross profit was primarily due to increased revenues along with lower excess and obsolete inventory charges of $2.4 million and lower amortization of intangibles due to certain intangibles being fully depreciated, partially offset by higher distribution cost of $4.6 million primarily due to higher freight costs and higher product costs of $19.8 million primarily related to higher expedite fees due to supply constraints.

[0001564590-22-003010:mdna:69]
Service and subscription gross profit increased $10.3 million or 21.2% for the three months ended December 31, 2021, as compared to the corresponding period in fiscal 2021. The increase was primarily due to increased service and subscription revenues, partially offset by higher personnel costs, professional fees and increased cloud service costs.

[0001564590-22-003010:mdna:70]
Service and subscription gross profit increased $14.6 million or 15.3% for the six months ended December 31, 2021, as compared to the corresponding period in fiscal 2021. The increase was primarily due to increased service and subscription revenues, partially offset by higher professional fees and increased cloud service costs.

[0001564590-22-003010:mdna:71]
[same as prior period, unchanged from 0001564590-21-054929:mdna:66]

[0001564590-22-003010:mdna:72]
[same as prior period, unchanged from 0001564590-21-054929:mdna:67]

[0001564590-22-003010:mdna:73]
|  |  | Three Months Ended |  | Six Months Ended |  |
|  |  | December 31, 2021 |  |  | December 31, 2020 |  |  | $ Change |  |  | % Change |  | December 31, 2021 |  |  | December 31, 2020 |  |  | $ Change |  |  | % Change |  |
| Research and development |  | $ | 48,080 |  |  | $ | 49,186 |  |  | $ | (1,106 | ) |  |  | (2.2 | )% | $ | 95,846 |  |  | $ | 98,710 |  |  | $ | (2,864 | ) |  |  | (2.9 | )% |
| Sales and marketing |  |  | 71,565 |  |  |  | 66,732 |  |  |  | 4,833 |  |  |  | 7.2 | % |  | 141,092 |  |  |  | 131,057 |  |  |  | 10,035 |  |  |  | 7.7 | % |
| General and administrative |  |  | 17,877 |  |  |  | 16,360 |  |  |  | 1,517 |  |  |  | 9.3 | % |  | 34,880 |  |  |  | 32,821 |  |  |  | 2,059 |  |  |  | 6.3 | % |
| Acquisition and integration costs |  |  | 2,113 |  |  |  | — |  |  |  | 2,113 |  |  |  | 100.0 | % |  | 3,623 |  |  |  | 1,975 |  |  |  | 1,648 |  |  |  | 83.4 | % |
| Restructuring and related charges |  |  | 292 |  |  |  | 695 |  |  |  | (403 | ) |  |  | (58.0 | )% |  | 571 |  |  |  | 1,696 |  |  |  | (1,125 | ) |  |  | (66.3 | )% |
| Amortization of intangibles |  |  | 804 |  |  |  | 1,506 |  |  |  | (702 | ) |  |  | (46.6 | )% |  | 1,958 |  |  |  | 3,298 |  |  |  | (1,340 | ) |  |  | (40.6 | )% |
| Total operating expenses |  | $ | 140,731 |  |  | $ | 134,479 |  |  | $ | 6,252 |  |  |  | 4.6 | % | $ | 277,970 |  |  | $ | 269,557 |  |  | $ | 8,413 |  |  |  | 3.1 | % |

[0001564590-22-003010:mdna:74]
[same as prior period, unchanged from 0001564590-21-054929:mdna:69]

[0001564590-22-003010:mdna:75]
[same as prior period, unchanged from 0001564590-21-054929:mdna:70]

[0001564590-22-003010:mdna:76]
Research and development expenses decreased by $1.1 million or 2.2% for the three months ended December 31, 2021, as compared to the corresponding period in fiscal 2021. The decrease in research and development expenses was due to a $1.4 million decrease in facility and information technology costs, a $0.6 million decrease in professional and contractor fees and a $0.5 million decrease in software licenses and engineering project costs, partially offset by a $1.4 million increase in personnel related costs due to increased headcount.

[0001564590-22-003010:mdna:77]
Research and development expenses decreased by $2.9 million or 2.9% for the six months ended December 31, 2021, as compared to the corresponding period in fiscal 2021. The decrease in research and development expenses was due to a $2.8 million decrease in facility and information technology costs and a $1.9 million decrease in software licenses and engineering project costs which lowered the depreciation expense, partially offset by a $1.8 million increase in personnel related costs.

[0001564590-22-003010:mdna:78]
[same as prior period, unchanged from 0001564590-21-054929:mdna:72]

[0001564590-22-003010:mdna:79]
[same as prior period, unchanged from 0001564590-21-054929:mdna:73]

[0001564590-22-003010:mdna:80]
Sales and marketing expenses increased by $4.8 million or 7.2% for the three months ended December 31, 2021, as compared to the corresponding period in fiscal 2021. The increase in sales and marketing expenses was primarily due to a $4.0 million increase in personnel costs primarily due to higher compensation and benefits costs due to increase in headcount, a $1.0 million increase in travel costs and a $0.2 million increase in other expenses primarily information technology costs, partially offset by a $0.4 million decrease in professional fees.

[0001564590-22-003010:mdna:81]
Sales and marketing expenses increased by $10.0 million or 7.7% for the six months ended December 31, 2021, as compared to the corresponding period in fiscal 2021. The increase in sales and marketing expenses was primarily due to a $8.1 million increase in personnel costs due to higher compensation and benefits costs due to increase in headcount, a $2.0 million increase in travel cost and a $0.6 million increase in other expenses primarily marketing and sales promotions costs, partially offset by a $0.7 million decrease in professional fees.

[0001564590-22-003010:mdna:82]
[same as prior period, unchanged from 0001564590-21-054929:mdna:75]

[0001564590-22-003010:mdna:83]
[same as prior period, unchanged from 0001564590-21-054929:mdna:76]

[0001564590-22-003010:mdna:84]
General and administrative expenses increased by $1.5 million or 9.3% for the three months ended December 31, 2021, as compared to the corresponding period in fiscal 2021. The increase in general and administrative expenses was primarily due to a $0.8 million increase in legal and professional fees and a $0.7 million increase in equipment and software licensing costs.

[0001564590-22-003010:mdna:85]
General and administrative expenses increased by $2.1 million or 6.3% for the six months ended December 31, 2021, as compared to the corresponding period in fiscal 2021. The increase in general and administrative expense was primarily due to $1.4 million increase in personnel costs primarily compensation expenses, a $0.5 million increase in equipment and software licensing costs and $0.1 million increase in other expenses primarily professional fees and travel.

[0001564590-22-003010:mdna:86]
[same as prior period, unchanged from 0001564590-21-054929:mdna:78]

[0001564590-22-003010:mdna:87]
During the three months ended December 31, 2021, we incurred acquisition and integration costs of $2.1 million. During the six months ended December 31, 2021, we incurred $3.6 million of integration costs. Acquisition and integration costs for the three and six months ended December 31, 2021 consisted primarily of professional fees for legal advisory services, system and product integrations, and financial services related to the acquisition of Ipanema.

[0001564590-22-003010:mdna:88]
During the three months ended December 31, 2020 we did not incur any acquisition and integration costs. During the six months ended December 31, 2020, we incurred $2.0 million of acquisition and integration costs. Acquisition and integration costs for the six months ended December 31, 2020 consisted primarily of additional professional fees for system integration and financial services related to the Aerohive acquisition.

[0001564590-22-003010:mdna:89]
[same as prior period, unchanged from 0001564590-21-054929:mdna:81]

[0001564590-22-003010:mdna:90]
For the three and six months ended December 31, 2021, we recorded restructuring and related charges of $0.3 million and $0.6 million respectively, which primarily comprised of facility-related charges related to our previously impaired facilities.

[0001564590-22-003010:mdna:91]
For the three and six months ended December 31, 2020, we recorded restructuring charges of $0.7 million and $1.7 million, respectively. We continued our cost reduction initiative began in the third quarter of fiscal 2020 and recorded related severance, benefits, and equipment relocation charges of $0.4 million and $1.1 million respectively, related to the 2020 Plan. In addition, we had facility-related charges of $0.3 million and $0.6 million, respectively, related to our previously impaired facilities.

[0001564590-22-003010:mdna:92]
[same as prior period, unchanged from 0001564590-21-054929:mdna:84]

[0001564590-22-003010:mdna:93]
During the three months ended December 31, 2021 and 2020, we recorded $0.8 million and $1.5 million, respectively, of operating expenses for amortization of intangibles. During the six months ended December 31, 2021 and 2020, recorded $2.0 million and $3.3 million, respectively, of operating expenses for amortization of intangibles. The decreases were primarily due to lower amortization related to certain acquired intangibles from previous acquisitions becoming fully amortized.

[0001564590-22-003010:mdna:94]
[same as prior period, unchanged from 0001564590-21-054929:mdna:86]

[0001564590-22-003010:mdna:95]
During the three months ended December 31, 2021 and 2020, we recorded $3.1 million and $6.1 million, respectively, in interest expense.  During the six months ended December 31, 2021 and 2020, we recorded $7.0 million and $12.7 million, respectively, in interest expense. The decreases in interest expense were primarily driven by lower average loan balances and lower average rates during the respective period under our Amended and Restated Credit Agreement (as amended, the “2019 Credit Agreement”), dated August 9, 2019, by and among us, as borrower, several banks and other financial institutions as Lenders, BMO Harris Bank N.A., as an issuing lender and swingline lender, Silicon Valley Bank, as an Issuing Lender, and Bank of Montreal, as administrative agent and collateral agent for the Lenders.

[0001564590-22-003010:mdna:96]
[same as prior period, unchanged from 0001564590-21-054929:mdna:88]

[0001564590-22-003010:mdna:97]
During the three months ended December 31, 2021 and 2020, we recorded other income, net of $0.1 million and other expense, net of $1.0 million, respectively. During the six months ended December 31, 2021 and 2020, recorded other income, net of $0.2 million and other expense, net of $1.8 million, respectively. The changes for the three and six months ended December 31, 2021 was primarily due to foreign exchange gains from the revaluation of certain assets and liabilities denominated in foreign currencies into U.S. Dollars.

[0001564590-22-003010:mdna:98]
[same as prior period, unchanged from 0001564590-21-054929:mdna:90]

[0001564590-22-003010:mdna:99]
For the three months ended December 31, 2021 and 2020, we recorded an income tax provision of $1.8 million. For the six months ended December 31, 2021 and 2020, we recorded an income tax provision of $3.9 million and $3.1 million, respectively.

[0001564590-22-003010:mdna:100]
The income tax provisions for the three and six months ended December 31, 2021 and 2020 consisted of (1) taxes on the income of our foreign subsidiaries, (2) foreign withholding taxes, (3) state taxes in jurisdictions where we have no remaining state net operating losses and (4) tax expense associated with the establishment of a U.S. deferred tax liability for amortizable goodwill resulting from the acquisition of Enterasys Networks, Inc., the WLAN Business, the Campus Fabric Business and the Data Center Business.

[0001564590-22-003010:mdna:101]
[same as prior period, unchanged from 0001564590-21-054929:mdna:93]

[0001564590-22-003010:mdna:102]
[same as prior period, unchanged from 0001564590-21-054929:mdna:94]

[0001564590-22-003010:mdna:103]
[same as prior period, unchanged from 0001564590-21-054929:mdna:95]

[0001564590-22-003010:mdna:104]
[same as prior period, unchanged from 0001564590-21-054929:mdna:96]

[0001564590-22-003010:mdna:105]
[same as prior period, unchanged from 0001564590-21-054929:mdna:97]

[0001564590-22-003010:mdna:106]
[same as prior period, unchanged from 0001564590-21-054929:mdna:98]

[0001564590-22-003010:mdna:107]
[same as prior period, unchanged from 0001564590-21-054929:mdna:99]

[0001564590-22-003010:mdna:108]
[same as prior period, unchanged from 0001564590-21-054929:mdna:100]

[0001564590-22-003010:mdna:109]
|  |  | December 31, 2021 |  |  | June 30, 2021 |  |
| Cash |  | $ | 173,548 |  |  | $ | 246,894 |  |

[0001564590-22-003010:mdna:110]
As of December 31, 2021, our principal sources of liquidity consisted of cash of $173.5 million and accounts receivable, net of $133.3 million, and available borrowings under our five-year 2019 Revolving Facility of $60.2 million. Our principal uses of cash include the purchase of finished goods inventory from our contract manufacturers, payroll and other operating expenses related to the development and marketing of our products, purchases of property and equipment, and repayments of debt and related interest. We believe that our $173.5 million of cash at December 31, 2021, our cash flow from operations, and the availability of borrowings from the 2019 Revolving Facility will be sufficient to fund our planned operations for at least the next 12 months.

[0001564590-22-003010:mdna:111]
On November 2, 2018, our Board of Directors announced that it had authorized management to repurchase up to $60.0 million of our shares of common stock for two years from the date of authorization, of which $15.0 million was used for repurchases in fiscal 2019 and $30.0 million was used for repurchases in fiscal 2020. In February 2020, our Board of Directors increased the authorization to repurchase by $40.0 million to $100.0 million and extended the period for repurchases for three years from February 5, 2020.  Purchases may be made from time to time in the open market or in privately negotiated transactions. The manner, timing and amount of any future purchases will be determined by our management based on their evaluation of market conditions, stock price, Extreme’s ongoing determination that it is the best use of available cash and other factors. The repurchase program does not obligate Extreme to acquire any shares of its common stock, may be suspended or terminated at any time without prior notice and will be subject to regulatory considerations. During the three and six months ended December 31, 2021, we repurchased a total of 1,829,333 shares of common stock on the open market at a total cost of $25.0 million. As of December 31, 2021, we have $30.0 million available under our share repurchase program.

[0001564590-22-003010:mdna:112]
In connection with the acquisition of Aerohive, as of August 9, 2019, we amended the 2018 Credit Agreement, which is no longer outstanding, and entered into the 2019 Credit Agreement. The 2019 Credit Agreement provides for a five-year first lien term loan facility in an aggregate principal amount of $380.0 million and a five-year revolving loan facility in an aggregate principal amount of $75.0 million (“2019 Revolving Facility”). In addition, we may request incremental term loans and/or incremental revolving loan commitments in an aggregate amount not to exceed the sum of $100.0 million plus an unlimited amount that is subject to pro forma compliance with certain financial tests.  On August 9, 2019, we used the proceeds to partially fund the acquisition of Aerohive and for working capital and general corporate purposes.

[0001564590-22-003010:mdna:113]
[same as prior period, unchanged from 0001564590-21-054929:mdna:105]

[0001564590-22-003010:mdna:114]
The 2019 Credit Agreement requires us to maintain certain minimum financial ratios at the end of each fiscal quarter. The 2019 Credit Agreement also includes covenants and restrictions that limit, among other things, our ability to incur additional indebtedness, create liens upon any of our property, merge, consolidate or sell all or substantially all of our assets. The 2019 Credit Agreement also includes customary events of default, which may result in acceleration of the outstanding balance.

[0001564590-22-003010:mdna:115]
Financial covenants under the 2019 Credit Agreement require us to maintain a minimum consolidated fixed charge and consolidated leverage ratio at the end of each fiscal quarter through maturity.  The 2019 Credit Agreement also includes covenants and restrictions that limit, among other things, our ability to incur additional indebtedness, create liens upon any of our property, merge, consolidate or sell all or substantially all of our assets.  The 2019 Credit Agreement also includes customary events of default which may result in acceleration of the outstanding balance.

[0001564590-22-003010:mdna:116]
On April 8, 2020, we entered into the First Amendment to waive certain terms and financial covenants of the 2019 Credit Agreement through July 31, 2020. On May 8, 2020, we entered into the Second Amendment which superseded the First Amendment and provided certain revised terms and financial covenants through March 31, 2021. Subsequent to March 31, 2021, the original terms and financial covenants under the 2019 Credit Agreement resumed in effect. The Second Amendment required us to maintain certain minimum cash requirement and certain financial metrics at the end of each fiscal quarter through March 31, 2021.  Under the terms of the Second Amendment, we were not permitted to exceed $55.0 million in our outstanding balance under the 2019 Revolving Facility, the applicable margin for Eurodollar rate was 4.5% and we were restricted from pursuing certain activities such as incurring additional debt, stock repurchases, making acquisitions or declaring a dividend, until we are in compliance with the original covenants of the 2019 Credit Agreement. On November 3, 2020, we and our lenders entered into the Third Amendment to increase the sublimit for letters of credit to $20.0 million. On December 8, 2020, we and our lenders entered into the Fourth Amendment to waive and amend certain terms and financial covenants within the 2019 Credit Agreement through March 31, 2021.

[0001564590-22-003010:mdna:117]
The Second Amendment provided for us to end the covenant Suspension Period early and revert to the covenants and interest rates per the original terms of the 2019 Credit Agreement dated August 9, 2019 by filing a Suspension Period Early Termination Notice and Covenant Certificate demonstrating compliance. For the twelve-month period ended March 31, 2021 our financial performance was in compliance with the original covenants defined in the 2019 Credit Agreement and as such we filed a Suspension Early Termination Notice and Covenant Certificate with the administration agent subsequent to filing our Quarterly Report on Form 10-Q for the period ended March 31, 2021. Returning to compliance with the covenants per the original terms of the 2019 Credit Agreement dated August 9, 2019, resulted in our Eurodollar loan spread decreasing from 4.5% during the suspension period to 2.75% and unused facility commitment fee decreasing from 0.4% to 0.35%, and the limitation on revolver borrowings being removed effective May 1, 2021 after filing of the certificate with the administrative agent.

[0001564590-22-003010:mdna:118]
[same as prior period, unchanged from 0001564590-21-054929:mdna:111]

[0001564590-22-003010:mdna:119]
[same as prior period, unchanged from 0001564590-21-054929:mdna:112]

[0001564590-22-003010:mdna:120]
|  |  | Six Months Ended |  |
|  |  | December 31, 2021 |  |  | December 31, 2020 |  |
| Net cash provided by operating activities |  | $ | 62,482 |  |  | $ | 62,771 |  |
| Net cash used in investing activities |  |  | (76,170 | ) |  |  | (8,039 | ) |
| Net cash used in financing activities |  |  | (59,394 | ) |  |  | (65,237 | ) |
| Foreign currency effect on cash |  |  | (264 | ) |  |  | 602 |  |
| Net decrease in cash |  | $ | (73,346 | ) |  | $ | (9,903 | ) |

[0001564590-22-003010:mdna:121]
35

[0001564590-22-003010:mdna:122]
[same as prior period, unchanged from 0001564590-21-054929:mdna:114]

[0001564590-22-003010:mdna:123]
Cash flows provided by operations in the six months ended December 31, 2021, were $62.5 million, including our net income of $26.0 million and non-cash expenses of $54.1 million for items such as amortization of intangibles, share-based compensation, depreciation, reduction in carrying amount of right-of-use assets, deferred income taxes, and interest.  Other sources of cash for the period included decreases in accounts receivables and increase in deferred revenues. This was partially offset by increase in inventories and prepaid expenses and other current assets and decreases in accounts payable, accrued compensation, operating lease liabilities and other current and long-term liabilities.

[0001564590-22-003010:mdna:124]
Cash flows provided by operations in the six months ended December 31, 2020, were $62.8 million, including our net loss of $11.9 million and non-cash expenses of $61.7 million for items such as amortization of intangibles, share-based compensation, depreciation, reduction in carrying amount of right-of-use assets, deferred income taxes and imputed interest. Other sources of cash for the period included a decrease in inventory and increases in accounts payable, accrued compensation, and deferred revenues. This was partially offset by decreases in other current and long-term liabilities and operating lease liabilities and increases in accounts receivables and prepaid expenses and other current assets.

[0001564590-22-003010:mdna:125]
[same as prior period, unchanged from 0001564590-21-054929:mdna:117]

[0001564590-22-003010:mdna:126]
Cash flows used in investing activities in the six months ended December 31, 2021 were $76.2 million primarily due to the payment of $69.5 million (net of cash acquired) for the acquisition of Ipanema and $6.7 million for the purchases of property and equipment.

[0001564590-22-003010:mdna:127]
Cash flows used in investing activities in the six months ended December 31, 2020 were $8.0 million for the purchases of property and equipment.

[0001564590-22-003010:mdna:128]
[same as prior period, unchanged from 0001564590-21-054929:mdna:120]

[0001564590-22-003010:mdna:129]
Cash flows used in financing activities in the six months ended December 31, 2021 were $59.4 million due primarily to debt repayments of $23.9 million, share repurchases of $25.0 million under our share repurchase program, payment of contingent consideration of $0.8 million, $2.0 million for deferred payments on acquisitions and $7.7 million for taxes paid on vested and released stock awards net of proceeds from the issuance of shares of our common stock under our Employee Stock Purchase Plan (“ESPP”) and exercise of stock options.

[0001564590-22-003010:mdna:130]
Cash flows used in financing activities in the six months ended December 31, 2020 were $65.2 million due primarily to debt repayments of $64.5 million, payment of contingent consideration of $1.0 million, and $2.0 million for deferred payments on acquisitions. This was partially offset by $2.3 million of proceeds from the issuance of shares of our common stock under our ESPP and exercise of stock options, net of taxes paid on vested and released stock awards.

[0001564590-22-003010:mdna:131]
[same as prior period, unchanged from 0001564590-21-054929:mdna:123]

[0001564590-22-003010:mdna:132]
Foreign currency effect on cash decreased in the six months ended December 31, 2021, primarily due to changes in foreign currency exchange rates between the U.S. Dollar and particularly the Indian Rupee, the UK Pound, and the EURO. Foreign currency effect on the cash increased in the six months ended December 31, 2020, primarily due to changes in foreign currency exchange rates between the U.S. Dollar and particularly the Indian Rupee, the UK Pound, and the EURO.

[0001564590-22-003010:mdna:133]
[same as prior period, unchanged from 0001564590-21-054929:mdna:125]

[0001564590-22-003010:mdna:134]
The following summarizes our contractual obligations as of December 31, 2021, and the effect such obligations are expected to have on our liquidity and cash flow in future periods (in thousands):

[0001564590-22-003010:mdna:135]
|  |  | Payments due by Period |  |
|  |  | Total |  |  | Less than 1 Year |  |  | 1-3 years |  |  | 3-5 years |  |  | More than 5 years |  |
| Contractual obligations: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Debt obligations |  | $ | 322,875 |  |  | $ | 30,875 |  |  | $ | 292,000 |  |  | $ | — |  |  | $ | — |  |
| Interest on debt obligations |  |  | 14,954 |  |  |  | 6,514 |  |  |  | 8,440 |  |  |  | — |  |  |  | — |  |
| Unconditional purchase obligations |  |  | 53,243 |  |  |  | 53,243 |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Contractual commitments |  |  | 83,912 |  |  |  | 27,738 |  |  |  | 34,633 |  |  |  | 17,233 |  |  |  | 4,308 |  |
| Lease payments on operating leases |  |  | 46,883 |  |  |  | 10,282 |  |  |  | 23,865 |  |  |  | 8,807 |  |  |  | 3,929 |  |
| Deferred payments for an acquisition |  |  | 5,000 |  |  |  | 4,000 |  |  |  | 1,000 |  |  |  | — |  |  |  | — |  |
| Contingent consideration for an acquisition |  |  | 208 |  |  |  | 208 |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Other liabilities |  |  | 393 |  |  |  | 151 |  |  |  | 242 |  |  |  | — |  |  |  | — |  |
| Total contractual cash obligations |  | $ | 527,468 |  |  | $ | 133,011 |  |  | $ | 360,180 |  |  | $ | 26,040 |  |  | $ | 8,237 |  |

[0001564590-22-003010:mdna:136]
[same as prior period, unchanged from 0001564590-21-054929:mdna:128]

[0001564590-22-003010:mdna:137]
[same as prior period, unchanged from 0001564590-21-054929:mdna:129]

[0001564590-22-003010:mdna:138]
[same as prior period, unchanged from 0001564590-21-054929:mdna:130]

[0001564590-22-003010:mdna:139]
[same as prior period, unchanged from 0001564590-21-054929:mdna:131]

[0001564590-22-003010:mdna:140]
[same as prior period, unchanged from 0001564590-21-054929:mdna:132]

[0001564590-22-003010:mdna:141]
[same as prior period, unchanged from 0001564590-21-054929:mdna:133]

[0001564590-22-003010:mdna:142]
[same as prior period, unchanged from 0001564590-21-054929:mdna:134]

[0001564590-22-003010:mdna:143]
[same as prior period, unchanged from 0001564590-21-054929:mdna:135]

[0001564590-22-003010:mdna:144]
[same as prior period, unchanged from 0001564590-21-054929:mdna:136]

[0001564590-22-003010:mdna:145]
[same as prior period, unchanged from 0001564590-21-054929:mdna:137]

[0001564590-22-003010:mdna:146]
We did not have any material commitments for capital expenditures as of December 31, 2021.

[0001564590-22-003010:mdna:147]
[same as prior period, unchanged from 0001564590-21-054929:mdna:139]

[0001564590-22-003010:mdna:148]
We did not have any off-balance sheet arrangements as of December 31, 2021.
