# EXTR MD&A — 0001078271-13-000049


## mdna

[0001078271-13-000049:mdna:1]
Item 7. Management’s Discussion and Analysis of Financial Condition and Results of Operations

[0001078271-13-000049:mdna:2]
Business Overview

[0001078271-13-000049:mdna:3]
We develop and sell network infrastructure equipment and offer related services contracts for extended warranty and maintenance to our enterprise, data center and service provider customers. Substantially all of our revenue is derived from the sale of our networking equipment and related service contracts.

[0001078271-13-000049:mdna:4]
We believe that understanding the following key developments is helpful to an understanding of our operating results for the fiscal year ended June 30, 2013.

[0001078271-13-000049:mdna:5]
Impact of the Global Economic Developments

[0001078271-13-000049:mdna:6]
We believe that the credit market crisis, slow economic recovery in the United States and Europe, and other challenges affecting global economic conditions placed significant limitations on our financial performance. We operate in three regions: Americas, which includes the United States, Canada, Mexico, Central America and South America; EMEA, which includes Europe, Middle East, and Africa; and APAC which includes Asia Pacific, South Asia, Japan and Australia. Sales in the APAC and some European countries were most impacted as a result of the soft global economy. We believe that conservative purchasing patterns and delays or cancellation of IT infrastructure plans in the face of continued uncertainty regarding the global economy, may continue to negatively impact overall demand for networking solutions, including Ethernet equipment.

[0001078271-13-000049:mdna:7]
We have taken, and plan to continue to take, other steps to manage our business in the current economic environment. For example, we have managed from time to time our contingent work force, reduced travel and other discretionary spending, realigned our product portfolio and organization to grow revenue and operating income, and controlled all hiring activities.

[0001078271-13-000049:mdna:8]
Increasing Demand for Bandwidth

[0001078271-13-000049:mdna:9]
We believe that the continued increase in demand for bandwidth will over time drive future demand for high performance Ethernet solutions. Wide-spread adoption of electronic communications in all aspects of our lives, proliferation of next generation converged mobile devices and deployment of triple-play services to residences and businesses alike, continues to generate demand for greater network performance across broader geographic locations. In parallel to these transformational forces within society and the community at large, the accelerating adoption of internet and intranet “cloud” solutions within business enterprises is enabling organizations to offer greater business scalability to improve efficiency and through more effective operations, improve profitability. In order to realize the benefits of these developments, customers require additional bandwidth and high performance from their network infrastructure at affordable prices. We are seeing the initial indications that the Ethernet segment of the networking equipment market will return to growth as enterprise, data center and carrier customers continue to recognize the performance and operating cost benefits of Ethernet technology.

[0001078271-13-000049:mdna:10]
Expanding Product Portfolio

[0001078271-13-000049:mdna:11]
We believe that continued success in our marketplace is dependent upon a variety of factors that includes, but is not limited to, our ability to design, develop and distribute new and enhanced products employing leading-edge technology. Over the past few years, we further extended our Ethernet product portfolio through continued evolutions of our BlackDiamond BD-X, a highly-scalable core switch for IT and cloud data centers, the Summit X440 for the intelligent edge, the Summit X670 for data center top-of-rack deployments, the E4G Cell Site Router family for mobile backhaul, as well as introducing a revamp of our RidgeLine network management platform.  We also introduced the Summit X430, further extending our ExtremeXOS technology into more cost-conscious environments.  During fiscal 2013 we also introduced key software functionality that will drive differentiation.  This included support for OpenFlow and OpenStack as part of our SDN strategy, automation of IP cameras for physical security, and Audio-Video Bridging, a breakthrough set of technologies for professional audio and video.

[0001078271-13-000049:mdna:12]
Industry Developments

[0001078271-13-000049:mdna:13]
The market for network infrastructure equipment is highly competitive and dominated by a few large companies. The current economic climate has further driven consolidation of vendors within the Ethernet networking market and with vendors from adjacent markets, including storage, security, wireless and voice applications. We believe that the underpinning technology for all of these adjacent markets is Ethernet. As a result, independent Ethernet switch vendors are being acquired or merged with larger, adjacent market vendors to enable them to deliver complete and broad solutions. As an independent Ethernet switch vendor, we must provide products that, when combined with the products of our large strategic partners, create compelling solutions for end-user customers. Our approach is to focus on the intelligence and automation layer that spans our hardware products and that facilitates end-to-end solutions, as opposed to positioning Extreme Networks as a low-cost-vendor with point products. Lower overall market growth has also created an environment of declining margins due to increased competition between the remaining vendors in this space. During the last year, overall Ethernet port counts have grown, while industry revenues have decreased,

[0001078271-13-000049:mdna:14]
signaling a decline in average selling price. Our product life cycle and operational cost reduction efforts are therefore even more critical for margin preservation.

[0001078271-13-000049:mdna:15]
Amendment to Rights Agreement

[0001078271-13-000049:mdna:16]
On November 27, 2012, our Board of Directors adopted an Amended and Restated Rights Agreement between Extreme Networks and Computershare Shareholder Services LLC as the rights agent (the “Restated Rights Plan”). The Restated Rights Plan governs the terms of each right (“Right”) that has been issued with respect to each share of Common Stock of Extreme Networks. Each Right initially represents the right to purchase one one-thousandth of a share of Series A Preferred Stock of Extreme Networks. The Restated Rights Plan replaces in its entirety the Rights Agreement, dated as of April 27, 2001, as amended on June 30, 2010; April 26, 2011, between Extreme Networks and Mellon Investor services LLC (the “Prior Rights Plan”).

[0001078271-13-000049:mdna:17]
The Board reviewed the necessity of the provision of the Prior Rights Plan adopted to preserve the value of Extreme Networks' deferred tax assets, including its net operating loss carry forwards, with respect to its ability to fully use its tax benefits to offset future income may be limited if it experiences an “ownership change” for purposes of Section 382 of the Internal Revenue Code of 1986 as a result of ordinary buying and selling of Extreme Networks' common stock. Following its review, the Board decided it was necessary and in the best interests of Extreme Networks and its stockholders to enter into the Restated Rights Plan. The Restated Rights Plan incorporates the Prior Rights Plan and the amendments thereto into a single agreement and extended the term of the Prior Rights Plan to April 30, 3013.  Our stockholders voted to extend the term of the Restated Rights Plan from April 30, 2013 to April 30, 2014 at our 2012 Annual Meeting of Stockholders, and the Restated Rights Plan was amended effective April 30, 2013 to reflect the extension of the term.

[0001078271-13-000049:mdna:18]
Results of Operations

[0001078271-13-000049:mdna:19]
Effective June 30, 2012, we changed our fiscal period to coincide with calendar month-end.  Previously, we used a fiscal 52/53 week manufacturing calendar year. Accordingly, the fiscal year ended June 30, 2012 has 52 weeks compared to 53 weeks in 2011.

[0001078271-13-000049:mdna:20]
Our operations and financial performance have been affected by the economic factors described above, and during fiscal 2013, we achieved the following results:

[0001078271-13-000049:mdna:21]
| • | Net revenue of $299.3 million, a decrease of 7.2% from fiscal 2012 net revenue of $322.7 million. |

[0001078271-13-000049:mdna:22]
| • | Product revenue of $240.0 million, a decrease of 8.4% from fiscal 2012 product revenue of $261.9 million. |

[0001078271-13-000049:mdna:23]
| • | Service revenue of $59.4 million, a decrease of 2.4% from fiscal 2012 service revenue of $60.8 million. |

[0001078271-13-000049:mdna:24]
| • | Total gross margin of 54.3% of net revenue in fiscal 2013, compared to 55.7% in fiscal 2012. |

[0001078271-13-000049:mdna:25]
| • | Operating income of $10.9 million (including gain on sale of campus of $11.5 million, restructuring charges of $6.8 million, and $2.0 million of litigation settlement charges and associated legal expenses), a decrease from operating income of $13.9 million in fiscal 2012. |

[0001078271-13-000049:mdna:26]
| • | Net income was $9.7 million in fiscal 2013, a decrease from net income of $15.9 million in fiscal 2012. |

[0001078271-13-000049:mdna:27]
| • | Cash flow provided by operating activities was $32.2 million, compared to cash flow provided by operating activities of $13.8 million in fiscal 2012, an increase of $18.4 million. Cash and cash equivalents, short-term investments and marketable securities were $205.6 million as of June 30, 2013, an increase of $52.1 million from fiscal 2012 primarily due to cash provided by operating and investing activities including the sale of buildings and land offset by cash used for repurchase of common stock. |

[0001078271-13-000049:mdna:28]
Net Revenue

[0001078271-13-000049:mdna:29]
The following table presents net product and service revenue for the fiscal years 2013, 2012 and 2011 (dollars in thousands):

[0001078271-13-000049:mdna:30]
|  | Year Ended |  | Year Ended |
|  | June 30, 2013 |  | June 30, 2012 |  | $Change |  | %Change |  | June 30, 2012 |  | July 3, 2011 |  | $Change |  | %Change |
| Net Revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product | $ | 239,955 |  |  | $ | 261,873 |  |  | $ | (21,918 | ) |  | (8.4 | )% |  | $ | 261,873 |  |  | $ | 274,388 |  |  | $ | (12,515 | ) |  | (4.6 | )% |
| Percentage of net revenue | 80.2 | % |  | 81.2 | % |  |  |  |  |  | 81.2 | % |  | 82.1 | % |  |  |  |  |
| Service | 59,388 |  |  | 60,849 |  |  | (1,461 | ) |  | (2.4 | )% |  | 60,849 |  |  | 60,040 |  |  | 809 |  |  | 1.3 | % |
| Percentage of net revenue | 19.8 | % |  | 18.9 | % |  |  |  |  |  | 18.9 | % |  | 18.0 | % |  |  |  |  |
| Total net revenue | $ | 299,343 |  |  | $ | 322,722 |  |  | $ | (23,379 | ) |  | (7.2 | )% |  | $ | 322,722 |  |  | $ | 334,428 |  |  | $ | (11,706 | ) |  | (3.5 | )% |

[0001078271-13-000049:mdna:31]
Product revenue decreased in fiscal 2013 as compared to fiscal 2012 primarily due to weaker than expected demand from our public sector and enterprise customers in the United States and we continued to experience weak demand from our public sector and strategic customers and distributors in the EMEA region attributable to the persistent macroeconomic challenges in Western Europe.

[0001078271-13-000049:mdna:32]
Product revenue decreased in fiscal 2012 as compared to fiscal 2011 primarily due to increased pricing pressure on our  products and lower volumes. The decreases were also a result of elimination of certain products and product mix shift.

[0001078271-13-000049:mdna:33]
Service revenue decreased in fiscal 2013 as compared to fiscal 2012 reflecting slight decrease in the levels of service contract renewals.

[0001078271-13-000049:mdna:34]
Service revenue increased in fiscal 2012 as compared to fiscal 2011 resulting from a significant one time renewal contract for a single customer and maintenance contract extensions.

[0001078271-13-000049:mdna:35]
As noted previously, we operate in three regions: Americas, which includes the United States, Canada, Mexico, Central America and South America; EMEA, which includes Europe, Russia, Middle East, and Africa; and APAC which includes Asia Pacific, South Asia, Japan and Australia. Prior to fiscal 2012, South America was included as part of EMEA. The following table presents the total net revenue geographically for the fiscal years 2013, 2012 and 2011 (dollars in thousands):

[0001078271-13-000049:mdna:36]
|  | Year Ended |  | Year Ended |
| Net Revenue | June 30, 2013 |  | June 30, 2012 |  | $Change |  | %Change |  | June 30, 2012 |  | July 3, 2011 |  | $Change |  | %Change |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States | $ | 101,790 |  |  | $ | 106,110 |  |  | $ | (4,320 | ) |  | (4.1 | )% |  | $ | 106,110 |  |  | $ | 103,087 |  |  | $ | 3,023 |  |  | 2.9 | % |
| Other | 33,584 |  |  | 34,970 |  |  | (1,386 | ) |  | (4.0 | )% |  | 34,970 |  |  | 30,487 |  |  | 4,483 |  |  | 14.7 | % |
| Total Americas | 135,374 |  |  | 141,080 |  |  | (5,706 | ) |  | (4.0 | )% |  | 141,080 |  |  | 133,574 |  |  | 7,506 |  |  | 5.6 | % |
| Percentage of net revenue | 45.2 | % |  | 43.7 | % |  |  |  |  |  | 43.7 | % |  | 39.9 | % |  |  |  |  |
| EMEA | 112,812 |  |  | 128,093 |  |  | (15,281 | ) |  | (11.9 | )% |  | 128,093 |  |  | 134,730 |  |  | (6,637 | ) |  | (4.9 | )% |
| Percentage of net revenue | 37.7 | % |  | 39.7 | % |  |  |  |  |  | 39.7 | % |  | 40.3 | % |  |  |  |  |
| APAC | 51,157 |  |  | 53,549 |  |  | (2,392 | ) |  | (4.5 | )% |  | 53,549 |  |  | 66,124 |  |  | (12,575 | ) |  | (19.0 | )% |
| Percentage of net revenue | 17.1 | % |  | 16.6 | % |  |  |  |  |  | 16.6 | % |  | 19.8 | % |  |  |  |  |
| Total net revenues | $ | 299,343 |  |  | $ | 322,722 |  |  | $ | (23,379 | ) |  | (7.2 | )% |  | $ | 322,722 |  |  | $ | 334,428 |  |  | $ | (11,706 | ) |  | (3.5 | )% |

[0001078271-13-000049:mdna:37]
Revenue in the EMEA decreased in 2013 as compared to fiscal 2012 primarily due to macroeconomic challenges which affected the demand from customers in those regions.  Revenue in the Americas and APAC decreased slightly as compared to fiscal 2012.

[0001078271-13-000049:mdna:38]
Revenue in the Americas increased in 2012 as compared to fiscal 2011 primarily due to sales to several large customers. Revenue in EMEA decreased in fiscal 2012 as compared to fiscal 2011 due to slow economic recovery in Europe.  Revenue in APAC also decreased in fiscal 2012 as compared to fiscal 2011 due to weaker sales in India, Korea, Hong Kong and Japan and organizational changes made in 2012.

[0001078271-13-000049:mdna:39]
We rely upon multiple channels of distribution, including distributors, direct resellers, OEM, and direct sales.  Revenue through our distributor channel was 43% of total product revenue in fiscal 2013, 42% of total product revenue in fiscal 2012, and 52% in fiscal 2011. The decrease in distributor channel revenue from fiscal 2011 was due to a shift in sales from distributors to our OEMs and direct resellers.

[0001078271-13-000049:mdna:40]
The level of sales to any one customer, including a distributor, may vary from period to period.

[0001078271-13-000049:mdna:41]
Cost of Revenue and Gross Profit

[0001078271-13-000049:mdna:42]
The following table presents the gross profit on product and service revenue and the gross profit percentage of net revenue for the fiscal years 2013, 2012 and 2011 (dollars in thousands):

[0001078271-13-000049:mdna:43]
|  | Year Ended |  | Year Ended |
|  | June 30, 2013 |  | June 30, 2012 |  | $Change |  | %Change |  | June 30, 2012 |  | July 3, 2011 |  | $Change |  | %Change |
| Gross profit: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product | $ | 124,093 |  |  | $ | 141,646 |  |  | $ | (17,553 | ) |  | (12.4 | )% |  | $ | 141,646 |  |  | $ | 144,832 |  |  | $ | (3,186 | ) |  | (2.2 | )% |
| Percentage of product revenue | 51.7 | % |  | 54.1 | % |  |  |  |  |  | 54.1 | % |  | 52.8 | % |  |  |  |  |
| Service | 38,533 |  |  | 38,201 |  |  | 332 |  |  | 0.9 | % |  | 38,201 |  |  | 35,129 |  |  | 3,072 |  |  | 8.7 | % |
| Percentage of service revenue | 64.9 | % |  | 62.8 | % |  |  |  |  |  | 62.8 | % |  | 58.5 | % |  |  |  |  |
| Total gross profit | $ | 162,626 |  |  | $ | 179,847 |  |  | $ | (17,221 | ) |  | (9.6 | )% |  | $ | 179,847 |  |  | $ | 179,961 |  |  | $ | (114 | ) |  | (0.1 | )% |
| Percentage of net revenue | 54.3 | % |  | 55.7 | % |  |  |  |  |  | 55.7 | % |  | 53.8 | % |  |  |  |  |

[0001078271-13-000049:mdna:44]
Cost of product revenue includes costs of materials, amounts paid to third-party contract manufacturers, costs related to warranty obligations, charges for excess and obsolete inventory, royalties under technology license agreements, and internal costs associated with manufacturing overhead, including management, manufacturing engineering, quality assurance, development of test plans, and document control. We outsource substantially all of our manufacturing and supply chain management operations, and we conduct quality assurance, manufacturing engineering, document control and distribution at our facilities in San Jose, California, China, and Taiwan. Accordingly, a significant portion of our cost of product revenue consists of payments to our primary contract manufacturer, Alpha Networks, located in Hsinchu, Taiwan. In addition, we OEM our wireless product line from Motorola.

[0001078271-13-000049:mdna:45]
Product gross profit in fiscal 2013 decreased as compared to fiscal 2012 due to lower product revenue and an increase in charges for excess and obsolete inventory offset by economic benefits realized in our manufacturing costs.

[0001078271-13-000049:mdna:46]
Product gross profit in fiscal 2012 decreased as compared to fiscal 2011 due to lower sales offset by lower material cost, costs associated with inventory write-down charges, and a decrease in inbound freight costs due to our new Hong Kong distribution center which is located closer to our contract manufacturer Alpha Networks.

[0001078271-13-000049:mdna:47]
Our cost of service revenue consists primarily of labor, overhead, repair and freight costs and the cost of spares used in providing support under customer service contracts.

[0001078271-13-000049:mdna:48]
Service gross profit in fiscal 2013 increased as compared to fiscal 2012 primarily due to lower labor costs from our cost reduction initiatives.

[0001078271-13-000049:mdna:49]
Service gross profit in fiscal 2012 increased as compared to fiscal 2011 primarily due to lower return material authorization shipments for legacy chassis products, mix change from higher repair cost chassis products to lower repair cost stackable products.

[0001078271-13-000049:mdna:50]
Operating Expenses

[0001078271-13-000049:mdna:51]
The following table presents operating expenses and operating income (dollars in thousands):

[0001078271-13-000049:mdna:52]
|  | Year Ended |  | Year Ended |
|  | June 30, 2013 |  | June 30, 2012 |  | $Change |  | %Change |  | June 30, 2012 |  | July 3, 2011 |  | $Change |  | %Change |
| Research and development | $ | 40,521 |  |  | $ | 45,640 |  |  | $ | (5,119 | ) |  | (11.2 | )% |  | $ | 45,640 |  |  | $ | 49,330 |  |  | $ | (3,690 | ) |  | (7.5 | )% |
| Sales and marketing | 87,202 |  |  | 90,167 |  |  | (2,965 | ) |  | (3.3 | )% |  | 90,167 |  |  | 103,277 |  |  | (13,110 | ) |  | (12.7 | )% |
| General and administrative | 26,725 |  |  | 28,658 |  |  | (1,933 | ) |  | (6.7 | )% |  | 28,658 |  |  | 24,683 |  |  | 3,975 |  |  | 16.1 | % |
| Restructuring charge, net of reversals | 6,836 |  |  | 1,594 |  |  | 5,242 |  |  | 328.9 | % |  | 1,594 |  |  | 3,806 |  |  | (2,212 | ) |  | (58.1 | )% |
| Litigation settlement (gain)/loss | 2,029 |  |  | (121 | ) |  | 2,150 |  |  | (1,776.9 | )% |  | (121 | ) |  | (4,249 | ) |  | 4,128 |  |  | (97.2 | )% |
| Gain on sale of campus | (11,539 | ) |  | — |  |  | (11,539 | ) |  | 100.0 | % |  | — |  |  | — |  |  | — |  |  | — | % |
| Total operating expenses | $ | 151,774 |  |  | $ | 165,938 |  |  | $ | (14,164 | ) |  | (8.5 | )% |  | $ | 165,938 |  |  | $ | 176,847 |  |  | $ | (10,909 | ) |  | (6.2 | )% |
| Operating income | $ | 10,852 |  |  | $ | 13,909 |  |  | $ | (3,057 | ) |  | (22.0 | )% |  | $ | 13,909 |  |  | $ | 3,114 |  |  | $ | 10,795 |  |  | 346.7 | % |

[0001078271-13-000049:mdna:53]
The following table highlights our operating expenses and operating income as a percentage of net revenues:

[0001078271-13-000049:mdna:54]
|  | Year Ended |
|  | June 30, 2013 |  | June 30, 2012 |  | July 3, 2011 |
| Research and development | 13.5 | % |  | 14.1 | % |  | 14.8 | % |
| Sales and marketing | 29.1 | % |  | 27.9 | % |  | 30.9 | % |
| General and administrative | 8.9 | % |  | 8.9 | % |  | 7.4 | % |
| Restructuring charge, net of reversals | 2.3 | % |  | 0.5 | % |  | 1.1 | % |
| Litigation settlement (gain)/loss | 0.7 | % |  | — | % |  | (1.3 | )% |
| Gain on sale of campus | (3.9 | )% |  | — | % |  | — | % |
| Total operating expenses | 50.6 | % |  | 51.4 | % |  | 52.9 | % |
| Operating income | 3.6 | % |  | 4.3 | % |  | 0.9 | % |

[0001078271-13-000049:mdna:55]
Research and Development Expenses

[0001078271-13-000049:mdna:56]
Research and development expenses consist primarily of salaries and related personnel expenses, consultant fees and prototype expenses related to the design, development, and testing of our products. Research and development expenses decreased in fiscal 2013 as compared to fiscal 2012 primarily due to lower spending on engineering projects due to differences in timing and pattern of planned engineering project spending as compared to fiscal 2012.

[0001078271-13-000049:mdna:57]
Research and development expenses decreased in fiscal 2012 as compared to fiscal 2011 primarily due to $3.5 million less in salaries and benefits expense due to a reduction in headcount and a transfer of resources to lower cost regions and $0.9 million less in small equipment expenses due to better utilization of existing test equipment, offset by $0.6 million increase in professional fees related to new product launches.

[0001078271-13-000049:mdna:58]
Sales and Marketing Expenses

[0001078271-13-000049:mdna:59]
Sales and marketing expenses consist of salaries, commissions and related expenses for personnel engaged in marketing and sales functions, as well as trade shows and promotional expenses. Sales and marketing expenses decreased in fiscal 2013 as compared to fiscal 2012 primarily due to lower commissions and reduced personnel costs resulting from lower revenue levels and a reduction in headcount during the year.

[0001078271-13-000049:mdna:60]
Sales and marketing expenses decreased in fiscal 2012 as compared to fiscal 2011 primarily due to $4.5 million reduction in salaries and benefits, $3.5 million reduction in commissions due to lower revenue, $1.7 million less professional fees due to utilization of in-house services, and $1.4 million lesser travel expenses resulting from the reduction in headcount at the beginning of fiscal 2012.

[0001078271-13-000049:mdna:61]
General and Administrative Expenses

[0001078271-13-000049:mdna:62]
General and administrative expenses decreased in fiscal 2013 as compared to fiscal 2012 primarily due to cost reduction initiatives realized as part of the restructuring plan offset by CEO transition expenses of $2.1 million.

[0001078271-13-000049:mdna:63]
General and administrative expenses increased in fiscal 2012 as compared to fiscal 2011 primarily due to increased legal expense of $2.0 million, increased contract labor expense for accounting and finance of $1.0 million, increased stock based compensation expense of $0.8 million, increased international accounting fees of $0.8 million offset by lower salaries and benefits expense of $0.8 million due to fewer headcount.

[0001078271-13-000049:mdna:64]
Restructuring Charge, Net of Reversal

[0001078271-13-000049:mdna:65]
During fiscal 2013, 2012 and 2011, we recorded restructuring charges of $6.8 million, $1.6 million, and $3.8 million, respectively.

[0001078271-13-000049:mdna:66]
Fiscal 2013 Restructuring

[0001078271-13-000049:mdna:67]
During the second quarter of fiscal 2013, we further reduced costs through targeted restructuring activities intended to reduce operating costs and realign our organization in the current competitive environment. As part of our restructuring efforts in the second quarter, we initiated a plan to reduce our worldwide headcount by 13%, consolidate specific global administrative functions, and shift certain operating costs to lower cost regions, among other actions. As of June 30, 2013, we had restructuring liabilities of $1.1 million related to the fiscal 2013 restructuring, which we anticipate paying by the end of the first quarter of fiscal 2014. We anticipate incurring additional restructuring charges of approximately $0.3 million through the end of the first quarter of fiscal 2014.

[0001078271-13-000049:mdna:68]
Fiscal 2012 Restructuring

[0001078271-13-000049:mdna:69]
During fiscal 2012, we incurred total charges of $2.2 million, including $1.8 million related to severance, $0.1 million of contract termination fees, and $0.2 million other charges. A portion of this restructuring activity was related to the liquidation of our Japan subsidiary with a cost of $0.5 million at June 30, 2012. We substantially liquidated the subsidiary in Japan in the fourth quarter or fiscal 2012, as part of our broad restructuring effort. We disposed of the remaining immaterial assets and liabilities and completed the liquidation process during fiscal 2013.  There were no outstanding liabilities related to the fiscal 2012 restructuring as of June 30, 2013.

[0001078271-13-000049:mdna:70]
Fiscal 2011 Restructuring

[0001078271-13-000049:mdna:71]
During fiscal 2011, we commenced a strategy to focus on growing revenue in specific market verticals and on improving operational effectiveness.  As part of the strategy, we reduced headcount and incurred total restructuring charges of $4.2 million, of which $1.0 million and $3.2 million were recognized in the third and fourth quarter of fiscal 2011, respectively.  During the fourth quarter of fiscal 2011, the lease term for the excess leased facilities ended. We recognized a restructuring reversal of $0.4 million related to the true up of operating and rent expenses in fiscal 2012. As of June 30, 2013, we had restructuring liabilities of $0.4 million remaining related to the fiscal 2011 restructuring, which we anticipate paying during fiscal 2014.

[0001078271-13-000049:mdna:72]
Litigation Settlement

[0001078271-13-000049:mdna:73]
During the third quarter of fiscal 2013, we recognized a litigation charge of $2.5 million related to a settlement agreement with Enterasys Networks.

[0001078271-13-000049:mdna:74]
During the fourth quarter of fiscal 2012, from a judgment related to our lawsuit with Enterasys Networks for patent infringement, we received $0.6 million from Enterasys including a first trial damage award of $0.2 million, reimbursement of legal costs from the first trial of $0.4 million, and interest.

[0001078271-13-000049:mdna:75]
Gain on Sale of Campus

[0001078271-13-000049:mdna:76]
During fiscal 2013, we completed the sale of our corporate campus and accompanying 16 acres of land in Santa Clara, California for net cash proceeds of approximately $44.7 million of which approximately $2.0 million was received in fiscal 2012. We realized a gain of approximately $11.5 million in connection with this transaction, yet recorded a tax loss of approximately $24.6 million.

[0001078271-13-000049:mdna:77]
Interest Income

[0001078271-13-000049:mdna:78]
Interest income was $1.1 million in fiscal 2013, $1.2 million in fiscal 2012 and $1.3 million in fiscal 2011, representing a decrease of $0.1 million in fiscal 2013 from fiscal 2012, and a decrease of $0.1 million in fiscal 2012 from fiscal 2011.  The

[0001078271-13-000049:mdna:79]
decrease in interest income in fiscal 2013 from fiscal 2012 was due to a decrease in the average interest yield from 0.95% in fiscal 2012 to 0.54% in fiscal 2013. The decrease in interest income in fiscal 2012 from fiscal 2011 was due to a decrease in the average interest yield from 1.2% in fiscal 2011 to 0.95% in fiscal 2012.

[0001078271-13-000049:mdna:80]
Interest Expense

[0001078271-13-000049:mdna:81]
We had immaterial interest expense for fiscal 2013.  Interest expense was $0.1 million for both fiscal year 2012 and 2011. Interest expense in fiscal 2012 and fiscal 2011 were primarily related to interest amortization of technology agreements.

[0001078271-13-000049:mdna:82]
Other Income (Expense), net

[0001078271-13-000049:mdna:83]
Other income (expense) net was expense of $0.6 million in fiscal 2013, income of $2.0 million in fiscal 2012 and expense of $0.6 million in fiscal 2011.  Other expense in fiscal 2013 was primarily due to the revaluation of certain assets and liabilities denominated in foreign currencies into U.S. dollars.

[0001078271-13-000049:mdna:84]
Other income in fiscal 2012 was primarily comprised of $1.9 million in foreign currency translation gains that were reclassified from other comprehensive income (loss) due to the substantial liquidation of our Japan subsidiary.

[0001078271-13-000049:mdna:85]
Other expense in fiscal 2011 was primarily comprised of foreign currency losses of $0.6 million due to a weaker U.S. dollar.

[0001078271-13-000049:mdna:86]
Provision for Income Taxes

[0001078271-13-000049:mdna:87]
We recorded an income tax provision of $1.7 million for fiscal 2013. The effective tax rate in fiscal 2013 was 14.8% which differs from the federal statutory tax rate of 35% due primarily to the tax impact of income from foreign operations and the change in valuation allowance.  We recorded an income tax provision of $1.7 million for fiscal 2013 due to profits in our foreign subsidiaries, change in U.S. valuation allowance, state taxes, foreign withholding taxes and the release of foreign tax reserves due to a lapse in the statute of limitations on the positions.

[0001078271-13-000049:mdna:88]
The income tax provision of $1.2 million and $1.0 million for fiscal 2012 and 2011, respectively, were recorded for taxes due on income generated in U.S. federal, certain states and foreign tax jurisdictions. The effective tax rate was 7.0% for fiscal 2012 which differs from the federal statutory tax rate of 35% due primarily to the tax impact of income from foreign operations and the change in valuation allowance.

[0001078271-13-000049:mdna:89]
Critical Accounting Policies and Estimates

[0001078271-13-000049:mdna:90]
Our significant accounting policies are more fully described in Note 2 of Notes to Consolidated Financial Statements included in Item 8 of this Annual Report on Form 10-K. The preparation of consolidated financial statements in accordance with generally accepted accounting principles requires management to make estimates, assumptions and judgments that affect the reported amounts of assets and liabilities and the disclosure of contingent assets and liabilities at the date of the consolidated financial statements, and the reported amounts of revenue and expenses during the period reported. By their nature, these estimates, assumptions and judgments are subject to an inherent degree of uncertainty. We base our estimates, assumptions and judgments on historical experience, market trends and other factors that are believed to be reasonable under the circumstances. Estimates, assumptions and judgments are reviewed on an ongoing basis and the effects of revisions are reflected in the consolidated financial statements in the period they are determined to be necessary. Actual results may differ from these estimates under different assumptions or conditions. We believe the critical accounting policies stated below, among others, affect our more significant judgments and estimates used in the preparation of our consolidated financial statements.

[0001078271-13-000049:mdna:91]
Share-based Payments

[0001078271-13-000049:mdna:92]
We use the Black-Scholes option-pricing model to determine the fair value of option awards other than performance-based option awards, and share purchase options under our Employee Stock Purchase Plan (“ESPP”) on the date of grant with the weighted average assumptions. We use the Monte-Carlo simulation model to determine the fair value and the derived service period of performance-based option awards, with market conditions, on the date of grant.  The expected term of options granted is derived from historical data on employee exercise and post-vesting employment termination behavior. The expected term of purchase options under our ESPP represents the contractual life of the ESPP purchase period. The risk-free rate based upon the estimated life of the option and ESPP award is based on the U.S. Treasury yield curve in effect at the time of grant. Expected volatility is based on both the implied volatilities from traded options on our stock and historical volatility on our stock. We do not currently pay cash dividends on our common stock and do not anticipate doing so in the foreseeable future. Accordingly, our expected dividend yield is zero. We are required to estimate forfeitures at the time of grant and revise those estimates in subsequent periods if actual forfeitures differ from those estimates. In fiscal 2013, our estimated forfeiture rates based on historical forfeiture experiences are 3% for executives and 9% for non-executive employees. We use the straight-line method for expense attribution, and we only recognize expense for those shares expected to vest.

[0001078271-13-000049:mdna:93]
Revenue Recognition

[0001078271-13-000049:mdna:94]
We derive the majority of our revenue from sales of our networking equipment, with the remaining revenue generated from service fees relating to maintenance service contracts, professional services, and training for our products. We recognize revenue when persuasive evidence of an arrangement exists, delivery has occurred, the price of the product is fixed or determinable, and the collection of the sales proceeds is reasonably assured. In instances where any of the criteria for revenue recognition are not met, we defer revenue until all criteria have been met.

[0001078271-13-000049:mdna:95]
Product revenue from our value-added resellers, non-stocking distributors and end-user customers is recognized at the time of shipment, provided that all of the foregoing revenue recognition requirements have been satisfied.  We generally do not grant return privileges, except for defective products during the warranty period, nor do we grant pricing credits. Accordingly, we recognize revenue upon transfer of title and risk of loss to the customer, which is generally upon shipment. We maintain estimated accruals and allowances for sales incentives and other programs that we may make available to our partners, based on historical experience or applicable contractual terms. Shipping costs are included in cost of product revenues. Sales taxes collected from customers are excluded from revenues.

[0001078271-13-000049:mdna:96]
We also sell our products to distributors that stock inventory and sell to resellers. We defer recognition of revenue on all sales to our stocking distributors until the distributors have sold the products, as evidenced by sales data that the distributors provide to us. We grant stocking distributors certain price protection rights and the right to return a portion of unsold inventory for the purpose of stock rotation. The distributor-related deferred revenue and receivables are adjusted at the time of the stock rotation return or price reduction. We also provide stocking distributors with credits for changes in selling prices based on competitive conditions, and provide funding for our distributors and their resellers to perform marketing development activities. We maintain estimated accruals and allowances for these exposures based upon our contractual obligations. Our marketing development channel programs do not meet the criteria for recognizing the costs as marketing expenses and therefore these costs are accrued as a reduction to revenue in the same period that the products are sold.

[0001078271-13-000049:mdna:97]
Revenue from service contracts is deferred and recognized ratably over the contractual service period, which is typically from one to two years. Professional service revenue is recognized upon delivery or completion of performance.

[0001078271-13-000049:mdna:98]
Our networking products are tangible products that contain software and non-software components that function together to deliver the tangible product's essential functionality. Our sales arrangements may contain multiple deliverables comprised of our tangible products, standalone software licenses, and service offerings depending on the distribution sales channel through which the products are sold and the requirements of our customers. We recognize revenue for our multiple deliverable arrangements in accordance with the accounting standard for multiple deliverable revenue arrangements, which provides guidance on whether multiple deliverables exist, how deliverables in an arrangement should be separated, and how consideration should be allocated. The industry-specific software revenue recognition guidance does not apply to the sales of our tangible products.  Software revenue guidance is applied to sales of our standalone software products, including software upgrades and software that is not essential to the functionality of the hardware with which it is sold.

[0001078271-13-000049:mdna:99]
Pursuant to the guidance of the accounting standard for multiple-deliverable revenue arrangements, we allocate the total arrangement consideration to each separable element of an arrangement based on the relative selling price of each element.  We determine the standalone selling price for each element based on a selling price hierarchy. Under the selling price hierarchy, the selling price for each deliverable is based on our vendor-specific objective evidence of selling price (“VSOE”), which is determined by a substantial majority of our historical standalone sales transactions for a product or service falling within a reasonable range. If VSOE is not available due to a lack of standalone sales transactions or lack of pricing within a narrow range, then third party evidence (“TPE”), as determined by the standalone pricing of competitive vendor products in similar markets, is used. TPE typically is difficult to establish due to the proprietary differences of competitive products and difficulty in obtaining reliable competitive standalone pricing information. When neither VSOE nor TPE is available, we determine the best estimate of standalone selling price (“ESP”) for a product or service by considering several factors including, but not limited to, the 12-month historical median sales price, sales channels, geography, gross margin consistency, competitive product pricing, and product life cycle. In consideration of all relevant pricing factors, we apply management judgment to determine the best estimate of selling price through consultation with and formal approval by our management for all products and services for which neither VSOE nor TPE is available. Generally, the standalone selling price of services is determined using VSOE and the standalone selling price of all other deliverables is determined by using ESP. We regularly review VSOE, TPE and ESP for all of our products and services and maintain internal controls over the establishment and updates of these estimates.

[0001078271-13-000049:mdna:100]
Pursuant to the software revenue recognition accounting standard, we continue to recognize revenue for software using the residual method for our sales of standalone software products, including optional software upgrades, and other software that is not essential to the functionality of the hardware with which it is sold. After allocation of the relative selling price to each element of the multiple deliverable arrangement, we recognize revenue in accordance with our policies for product, software, and service revenue recognition.

[0001078271-13-000049:mdna:101]
Our total deferred product revenue from customers other than distributors was $3.1 million and $2.2 million as of June 30, 2013 and June 30, 2012, respectively. Our total deferred revenue for services, primarily from service contracts, was $38.7 million as of June 30, 2013 and $37.7 million as of June 30, 2012. Service contracts typically range from one to two years. Shipping costs are included in cost of product revenues.

[0001078271-13-000049:mdna:102]
We provide an allowance for sales returns based on our historical returns, analysis of credit memo data and our return policies. The allowance for sales returns was $0.8 million and $1.3 million as of June 30, 2013 and June 30, 2012, respectively, for estimated future returns that were recorded as a reduction of our accounts receivable. If the historical data that we use to calculate the estimated sales returns and allowances does not properly reflect future levels of product returns, these estimates will be revised, thus resulting in an impact on future net revenue. We estimate and adjust this allowance at each balance sheet date.

[0001078271-13-000049:mdna:103]
Inventory Valuation

[0001078271-13-000049:mdna:104]
Our inventory balance was $16.2 million as of June 30, 2013, compared with $26.6 million as of June 30, 2012. We value our inventory at lower of cost or market. Cost is computed using standard cost, which approximates actual cost, on a first-in, first-out basis. We provide inventory allowances based on excess and obsolete inventories determined primarily by the age of inventory. At the point of the loss recognition, a new, lower-cost basis for that inventory is established, and subsequent changes in facts and circumstances do not result in the restoration or increase in that newly established cost basis. Any written down or obsolete inventory subsequently sold has not had a material impact on gross margin for any of the periods disclosed. Inventory write-downs charged to cost of product revenue were $0.8 million in fiscal 2013, $1.1 million in fiscal 2012 and $2.2 million in fiscal 2011.

[0001078271-13-000049:mdna:105]
Long Lived Assets

[0001078271-13-000049:mdna:106]
Long-lived assets include property and equipment, intangible assets, and service inventory which we hold to support customers who have purchased service contracts with a hardware replacement element.   Long-lived assets are reviewed for impairment whenever events or changes in circumstances indicate that the carrying amount of such assets or asset groups may not be recoverable. If such facts and circumstances exist, we assess the recoverability of the long-lived assets by comparing the projected un-discounted net cash flows associated with the related asset or group of assets over their remaining lives against their respective carrying amounts. Impairments, if any, are based on the excess of the carrying amount over the fair value of those assets.

[0001078271-13-000049:mdna:107]
Accrued Warranty

[0001078271-13-000049:mdna:108]
Networking products may contain undetected hardware or software errors when new products or new versions or updates of existing products are released to the marketplace. In the past, we had experienced such errors in connection with products and product updates. Our standard hardware warranty period is typically 12 months from the date of shipment to end-users and 90 days for software. For certain access products, we offer a limited lifetime hardware warranty commencing on the date of shipment from us and ending five years following the our announcement of the end of sale of such product. Upon shipment of products to our customers, including both end-users and channel partners, we estimate expenses for the cost to repair or replace products that may be returned under warranty and accrue a liability through charges to cost of product revenue for this amount.

[0001078271-13-000049:mdna:109]
Our accrued warranty balance was $3.3 million and $2.9 million as of June 30, 2013 and June 30, 2012, respectively. The determination of our warranty requirements is based on our actual historical experience with the product or product family, estimates of repair and replacement costs and any product warranty problems that are identified after shipment. We estimate and adjust this accrual at each balance sheet date in accordance with changes in these factors.

[0001078271-13-000049:mdna:110]
The cost of new warranties issued that was charged to cost of product revenue was $4.3 million in fiscal 2013, $3.1 million in fiscal 2012, and $2.4 million in fiscal 2011.

[0001078271-13-000049:mdna:111]
Accounts Receivable and Allowance for Doubtful Accounts

[0001078271-13-000049:mdna:112]
Our accounts receivable balance, net of allowance for doubtful accounts, was $47.6 million and $41.2 million as of June 30, 2013 and June 30, 2012, respectively. The allowance for doubtful accounts for trade accounts receivable was $0.5 million and $0.4 million as of June 30, 2013 and June 30, 2012, respectively. We continually monitor and evaluate the collectability of our trade receivables based on a combination of factors. We record specific allowances for bad debts in general and administrative expense when we become aware of a specific customer’s inability to meet its financial obligation to us, such as in the case of bankruptcy filings or deterioration of financial position. Estimates are used in determining our allowances for all other customers based on factors such as current trends in the length of time the receivables are past due and historical collection experience. We mitigate some collection risk by requiring most of our customers in the Asia-Pacific region, excluding Japan and Australia, to pay cash in advance or secure letters of credit when placing an order with us. Our provision for doubtful accounts was an expense of $0.3 million in fiscal 2013, expense of $0.1 million in fiscal 2012 and benefit of $9,000 in fiscal 2011.

[0001078271-13-000049:mdna:113]
Deferred Tax Asset Valuation Allowance

[0001078271-13-000049:mdna:114]
We recognize deferred tax assets and liabilities based on the differences between the financial statement carrying amounts and the tax bases of assets and liabilities. Significant management judgment is required in determining our valuation allowance recorded against our net deferred tax assets. We make an assessment of the likelihood that our net deferred tax assets will be recovered from future taxable income, and to the extent that recovery is not believed to be likely, a valuation allowance is established. In fiscal 2013, the valuation allowance increased by $1.4 million to $142.0 million, and in fiscal 2012, the valuation allowance decreased by $9.9 million to $140.6 million. We have not provided a valuation allowance against any of our non-U.S. deferred tax assets.

[0001078271-13-000049:mdna:115]
The valuation allowance requires an assessment of both negative and positive evidence when determining the need for a valuation allowance. Evidence, such as operating results during the most recent three-year period was given more weight than our expectations of future profitability, which are inherently uncertain. Our inconsistent history of earnings during those periods coupled with difficulties in forecasting more than one quarter in advance as well as the cyclical nature of our industry represent sufficient negative evidence to require a full valuation allowance against our U.S. federal and state net deferred tax assets. This valuation allowance will be evaluated periodically and can be reversed partially or totally if business results have sufficiently improved to support realization of our deferred tax assets.

[0001078271-13-000049:mdna:116]
Accounting for Uncertainty in Income Taxes

[0001078271-13-000049:mdna:117]
We had unrecognized tax benefits of $10.9 million as of June 30, 2013. If fully recognized in the future, $0.3 million would impact our effective tax rate, and $10.6 million would result in adjustments to deferred tax assets and corresponding adjustments to the valuation allowance. It is reasonably possible that the amount of unrealized tax benefit could decrease by approximately $0.1 million during the next twelve months due to the expiration of the statute of limitations in certain foreign jurisdictions.  During the year ended June 30, 2013, we performed a study on our research and development credits documenting the historic credits as prescribed by Internal Revenue Service. As a result of this study we adjusted our available federal and state research credits as well as the amount of these credits that would be unrecognized tax benefits. The credits classified as unrecognized tax benefits decreased by approximately $15.0 million as a result of this study.

[0001078271-13-000049:mdna:118]
Legal Contingencies

[0001078271-13-000049:mdna:119]
We are currently involved in various claims and legal proceedings, including negotiations regarding potential licenses from third parties who have notified us that they believe our products may infringe certain patents. Periodically, we review the status of each significant matter, whether litigation or licensing negotiation, and assess our potential financial exposure. If the potential loss from any claim or legal proceeding is considered probable and the amount can be estimated, we accrue a liability for the estimated loss. Because of uncertainties related to these matters, accruals, if any, are based only on the most current and dependable information available at any given time. As additional information becomes available, we may reassess the potential liability from pending claims and litigation and the probability of claims being successfully asserted against us. As a result, we may revise our estimates related to these pending claims and litigation. Such revisions in the estimates of the potential liabilities could have a material impact on our consolidated results of operations, financial position and cash flows in the future. For further detail, see Note 3 of Notes to Consolidated Financial Statements.

[0001078271-13-000049:mdna:120]
Impact of Recently Issued Accounting Standards

[0001078271-13-000049:mdna:121]
In February 2013, the Financial Accounting Standards Board (the "FASB") issued Accounting Standards Update ("ASU") No. 2013-02, Topic 350 - Comprehensive Income ("ASU 2013-02"), which amends Topic 220 for the reporting of reclassifications out of accumulated other comprehensive income to the respective line items in net income. ASU 2013-02 is effective for annual reporting periods, and interim periods within those years, beginning after December 15, 2012. We intend to adopt this standard in the first quarter of 2014 and do not expect the adoption will have a material impact on our consolidated results of operations or financial condition.

[0001078271-13-000049:mdna:122]
In July 2013, the FASB issued ASU No. 2013-11, Topic 740 - Income Taxes ("ASU 2013-11"), which provides guidance to the presentation of an unrecognized tax benefit when a net operating loss carryforward, a similar tax loss, or a tax credit carryforward exists.  ASU 2013-11 is effective for fiscal years, and interim periods within those years, beginning after December 15, 2013.  We intend to adopt this standard in the first quarter of fiscal 2015 and do not expect the adoption will have an impact on our consolidated financial statements.

[0001078271-13-000049:mdna:123]
Liquidity and Capital Resources

[0001078271-13-000049:mdna:124]
The following summarizes information regarding our cash, investments, and working capital (in thousands):

[0001078271-13-000049:mdna:125]
|  | June 30, 2013 |  | June 30, 2012 |
| Cash and cash equivalent | $ | 95,803 |  |  | $ | 54,596 |  |
| Short-term investments | 43,034 |  |  | 23,358 |  |
| Marketable securities | 66,776 |  |  | 75,561 |  |
| Total cash and investments | $ | 205,613 |  |  | $ | 153,515 |  |
| Working capital | $ | 96,279 |  |  | $ | 72,361 |  |

[0001078271-13-000049:mdna:126]
Cash and cash equivalents increased by $41.2 million primarily due to cash provided by operating activities of $32.2 million, cash provided by investing activities of $16.5 million offset by cash used in financing activities of $7.4 million. Refer to further discussions below under Key Components of Cash Flows and Liquidity.

[0001078271-13-000049:mdna:127]
Short-term investments increased by $19.7 million and Long Term Marketable Securities decreased by $8.8 million.  The primary increase in Cash and Cash Equivalents is attributable to the $42.7 million sale of our Santa Clara campus.  The changes  among our Short Term Investments and Marketable Securities was the result of our efforts to manage our various investments so as to fund operations and share repurchases. Refer to further discussions below under Item 7A. Quantitative and Qualitative Disclosures About Market Risk.

[0001078271-13-000049:mdna:128]
The increase in working capital of $23.9 million was primarily due to higher cash and cash equivalents and short term investments offset by higher accounts payables and decrease in the assets held for sale classified as current assets.

[0001078271-13-000049:mdna:129]
Key Components of Cash Flows and Liquidity

[0001078271-13-000049:mdna:130]
A summary of the sources and uses of cash and cash equivalents is as follows (in thousands):

[0001078271-13-000049:mdna:131]
|  | Year Ended |
|  | June 30, 2013 |  | June 30, 2012 |  | July 3, 2011 |
| Net cash provided by operating activities | $ | 32,237 |  |  | $ | 13,813 |  |  | $ | 16,777 |  |
| Net cash provided by (used in) investing activities | $ | 16,480 |  |  | $ | (10,410 | ) |  | $ | (22,079 | ) |
| Net cash (used in) provided by financing activities | $ | (7,391 | ) |  | $ | 2,393 |  |  | $ | 2,530 |  |
| Foreign currency effect on cash | $ | (119 | ) |  | $ | (1,172 | ) |  | $ | 800 |  |
| Net increase (decrease) in cash and cash equivalents | $ | 41,207 |  |  | $ | 4,624 |  |  | $ | (1,972 | ) |

[0001078271-13-000049:mdna:132]
Cash and cash equivalents, short-term investments and marketable securities were $205.6 million at June 30, 2013, representing an increase of $52.1 million from $153.5 million at June 30, 2012. This increase was primarily due to cash provided by operations of $32.2 million and cash provided by investing activities of $16.5 million offset by cash used in financing activities of $7.4 million and foreign currency impact of 0.1 million.

[0001078271-13-000049:mdna:133]
Cash provided by operating activities was $32.2 million, an increase of $18.4 million compared to cash provided by operating activities of $13.8 million in fiscal 2012. Accounts receivable, net, increased to $47.6 million at June 30, 2013 from $41.2 million at June 30, 2012. Days sales outstanding in receivables increased to 54 days at June 30, 2013 from 42 days at June 30, 2012. The increase in accounts receivable and days sales outstanding were primarily due to increased billings during the fourth quarter of 2013 resulting in a higher receivables balance. Inventories decreased to $16.2 million at June 30, 2013 from $26.6 million at June 30, 2012 due to the timing of inventory receipts because of which we had lower inventory on hand. Accounts payable increased to $27.2 million at June 30, 2013 from $19.4 million at June 30, 2012 due to timing of payments.

[0001078271-13-000049:mdna:134]
Deferred revenue, net increased to $41.5 million at June 30, 2013 from $39.3 million at June 30, 2012. This increase was a result of higher sales of service maintenance agreements.

[0001078271-13-000049:mdna:135]
Cash flow provided by investing activities was $16.5 million. Proceeds of $42.7 million from the sale of buildings and land in Santa Clara, California, proceeds from maturities of investments and marketable securities of $16.4 million and sales of investments and marketable securities of $28.5 million were offset by capital expenditures of $12.7 million and purchases of investments of $57.7 million.

[0001078271-13-000049:mdna:136]
Cash flow used in financing activities was $2.4 million resulting from $14.5 million used to repurchase shares of our common stock, offset by $7.1 million of proceeds from the exercise of stock options and purchases of shares of our common stock under the ESPP, net of taxes paid on vested and released stock awards.

[0001078271-13-000049:mdna:137]
Contractual Obligations

[0001078271-13-000049:mdna:138]
The following summarizes our contractual obligations at June 30, 2013, and the effect such obligations are expected to have on our liquidity and cash flow in future periods (in thousands):

[0001078271-13-000049:mdna:139]
|  | Total |  | Less Than1 Year |  | 1 – 3 Years |  | 3 – 5 Years |  | More ThanFive Years |
| Contractual Obligations: |  |  |  |  |  |  |  |  |  |
| Non-cancelable inventory purchase commitments | $ | 50,050 |  |  | $ | 50,050 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Non-cancelable operating lease obligations | 39,573 |  |  | 6,180 |  |  | 9,657 |  |  | 8,621 |  |  | 15,115 |  |
| Total contractual cash obligations | $ | 89,623 |  |  | $ | 56,230 |  |  | $ | 9,657 |  |  | $ | 8,621 |  |  | $ | 15,115 |  |

[0001078271-13-000049:mdna:140]
Non-cancelable inventory purchase commitments represent the purchase of long lead-time component inventory that our contract manufacturers procure in accordance with our forecast. Inventory purchase commitments were $50.1 million as of June 30, 2013, an increase of $11.3 million from $38.8 million as of June 30, 2012.

[0001078271-13-000049:mdna:141]
Non-cancelable operating lease obligations represent base rents and operating expense obligations to landlords for facilities we occupy at various locations.

[0001078271-13-000049:mdna:142]
The amounts in the table above exclude $0.3 million of income tax liabilities related to uncertain tax positions as we are unable to reasonably estimate the timing of settlement.

[0001078271-13-000049:mdna:143]
We did not have any material commitments for capital expenditures as of June 30, 2013. Other non-cancelable purchase commitments represent OEM and technology agreements.

[0001078271-13-000049:mdna:144]
Off-Balance Sheet Arrangements

[0001078271-13-000049:mdna:145]
We did not have any off-balance sheet arrangements as of June 30, 2013.

[0001078271-13-000049:mdna:146]
Capital Resources and Financial Condition

[0001078271-13-000049:mdna:147]
As of June 30, 2013, in addition to $95.8 million in cash and cash equivalents, we had $43.0 million invested in short-term investments and $66.8 million invested in long-term marketable investments for total cash and cash equivalents, short-term investments and marketable securities of $205.6 million.

[0001078271-13-000049:mdna:148]
We believe that our current cash and cash equivalents, short-term investments, marketable securities and cash available from future operations will enable us to meet our working capital requirements for at least the next 12 months.
