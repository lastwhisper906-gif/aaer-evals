# EXTR 8-K — 0001078271-13-000039 filed 2013-07-30

## item codes, every 8-K on or before 2013-08-30

- 2013-08-23 0001078271-13-000044 — 5.02, 9.01
- 2013-08-02 0001078271-13-000042 — 5.02
- 2013-07-30 0001078271-13-000039 — 2.02, 9.01
- 2013-07-30 0001078271-13-000037 — 5.02, 9.01
- 2013-06-21 0001078271-13-000032 — 8.01
- 2013-05-01 0001078271-13-000018 — 5.02, 9.01
- 2013-04-30 0001078271-13-000015 — 2.02, 9.01
- 2013-03-01 0001078271-13-000010 — 8.01
- 2013-02-19 0001078271-13-000008 — 5.02
- 2013-01-30 0001078271-13-000004 — 2.02, 9.01
- 2013-01-07 0001078271-13-000002 — 1.01, 2.02, 2.03, 2.05, 9.01
- 2012-12-03 0001078271-12-000094 — 5.02, 5.07, 8.01
- 2012-10-31 0001078271-12-000071 — 2.02, 9.01
- 2012-10-19 0001078271-12-000069 — 1.01, 2.03, 9.01
- 2012-10-16 0001078271-12-000067 — 8.01
- 2012-10-01 0001193125-12-411392 — 5.02, 8.01, 9.01
- 2012-09-24 0001193125-12-401798 — 5.02, 9.01
- 2012-09-21 0001193125-12-399896 — 5.02, 9.01
- 2012-09-18 0001193125-12-394379 — 1.01, 5.02, 9.01
- 2012-09-12 0001193125-12-388591 — 8.01
- 2012-08-27 0001078271-12-000057 — 8.01
- 2012-08-03 0001078271-12-000041 — 7.01, 9.01
- 2012-08-01 0001078271-12-000039 — 2.02, 9.01
- 2012-07-25 0001078271-12-000037 — 8.01
- 2012-05-22 0001078271-12-000033 — 5.02, 9.01
- 2012-05-21 0001078271-12-000030 — 8.01
- 2012-05-09 0001078271-12-000028 — 5.02, 9.01
- 2012-05-02 0001078271-12-000023 — 2.02, 9.01
- 2012-04-30 0001078271-12-000020 — 3.03, 5.07, 9.01
- 2012-04-19 0001078271-12-000012 — 2.02, 5.02, 9.01
- 2012-03-12 0001078271-12-000010 — 5.02, 9.01
- 2012-02-24 0001078271-12-000008 — 8.01
- 2012-02-02 0001078271-12-000004 — 2.02, 9.01
- 2012-01-30 0001078271-12-000002 — 1.01
- 2011-12-01 0001078271-11-000104 — 8.01
- 2011-11-08 0001078271-11-000099 — 8.01
- 2011-11-02 0001078271-11-000094 — 2.02, 9.01
- 2011-10-24 0001078271-11-000089 — 8.01, 9.01
- 2011-10-11 0001078271-11-000085 — 8.01
- 2011-09-29 0001078271-11-000082 — 8.01
- 2011-09-15 0001078271-11-000070 — 5.02, 9.01
- 2011-08-11 0001078271-11-000058 — 8.01
- 2011-08-10 0001078271-11-000055 — 5.02
- 2011-08-08 0001078271-11-000045 — 5.02
- 2011-08-01 0001078271-11-000038 — 2.02, 9.01
- 2011-07-14 0001078271-11-000036 — 2.02, 2.05, 9.01
- 2011-07-12 0001078271-11-000034 — 8.01
- 2011-07-01 0001078271-11-000032 — 5.02
- 2011-06-16 0001078271-11-000030 — 8.01
- 2011-05-06 0001078271-11-000027 — 8.01, 9.01
- 2011-05-04 0001078271-11-000025 — 8.01
- 2011-04-28 0001078271-11-000020 — 2.02, 9.01
- 2011-04-27 0001078271-11-000018 — 3.03, 5.02, 5.03, 9.01
- 2011-04-11 0001078271-11-000016 — 2.02
- 2011-03-31 0001078271-11-000014 — 5.02, 5.03
- 2011-03-15 0001193125-11-066049 — 5.02, 9.01
- 2011-03-01 0001193125-11-052048 — 5.02, 9.01
- 2011-02-10 0001078271-11-000012 — 7.01, 9.01
- 2011-01-31 0001078271-11-000005 — 2.02, 5.02, 5.03, 9.01
- 2010-12-23 0001193125-10-287613 — 8.01
- 2010-12-17 0001193125-10-283495 — 5.03, 5.07, 8.01, 9.01
- 2010-11-10 0001193125-10-255861 — 4.01, 9.01
- 2010-11-01 0001193125-10-242706 — 2.02, 9.01
- 2010-10-14 0001193125-10-229518 — 1.01, 9.01
- 2010-10-06 0001193125-10-224863 — 5.02, 8.01
- 2010-09-29 0001193125-10-219705 — 1.01, 8.01
- 2010-09-08 0001193125-10-206782 — 5.02, 8.01, 9.01
- 2010-08-25 0001193125-10-196951 — 8.01
- 2010-08-09 0001193125-10-182573 — 7.01, 8.01, 9.01
- 2010-08-03 0001193125-10-175255 — 5.02, 8.01, 9.01
- 2010-08-02 0001193125-10-173697 — 2.02, 8.01, 9.01
- 2010-07-30 0001193125-10-172214 — 5.02, 8.01, 9.01
- 2010-07-22 0001193125-10-163896 — 8.01, 9.01
- 2010-07-20 0001193125-10-161832 — 5.02
- 2010-07-12 0001193125-10-157291 — 2.02, 9.01
- 2010-07-01 0001193125-10-152746 — 3.03, 9.01
- 2010-05-10 0001193125-10-114669 — 5.02, 9.01
- 2010-04-26 0001193125-10-093310 — 2.02, 9.01
- 2010-03-19 0001193125-10-061679 — 5.02, 9.01
- 2010-02-16 0001193125-10-032335 — 5.02
- 2010-02-01 0001193125-10-018202 — 2.02, 9.01
- 2010-01-29 0001193125-10-017165 — 5.02
- 2010-01-11 0001193125-10-004099 — 8.01
- 2009-10-26 0001193125-09-213846 — 2.02, 9.01 — amendment of 0001193125-09-213780
- 2009-10-26 0001193125-09-213780 — 2.02, 9.01
- 2009-10-23 0001193125-09-212871 — 2.05, 5.02, 8.01, 9.01
- 2009-10-05 0001193125-09-203522 — 2.02, 9.01
- 2009-08-04 0001193125-09-163799 — 5.02, 9.01
- 2009-07-31 0001193125-09-160772 — 5.02, 9.01
- 2009-07-30 0001193125-09-159578 — 2.02, 9.01
- 2009-07-20 0001193125-09-151500 — 5.02, 9.01
- 2009-07-08 0001193125-09-145840 — 5.02, 9.01
- 2009-05-12 0001193125-09-108340 — 5.02, 9.01
- 2009-04-23 0001193125-09-085849 — 2.02, 9.01
- 2009-03-26 0001193125-09-064502 — 2.05
- 2009-01-28 0001193125-09-013182 — 2.02, 9.01
- 2008-11-06 0001193125-08-227572 — 2.02, 9.01
- 2008-11-03 0001193125-08-222501 — 5.02
- 2008-08-11 0001193125-08-173590 — 5.02
- 2008-08-11 0001193125-08-172587 — 8.01, 9.01
- 2008-08-06 0001193125-08-167934 — 2.02, 9.01
- 2008-08-04 0001193125-08-164673 — 5.02, 9.01
- 2008-05-21 0001193125-08-119640 — 7.01, 9.01
- 2008-04-29 0001193125-08-095270 — 2.02, 9.01
- 2008-03-05 0001193125-08-047893 — 8.01
- 2008-02-19 0001193125-08-033702 — 5.02
- 2008-02-05 0001193125-08-019969 — 5.02
- 2008-01-30 0001193125-08-015378 — 2.02, 9.01
- 2007-12-27 0001193125-07-272178 — 5.03, 9.01
- 2007-10-29 0001193125-07-228368 — 2.02, 9.01
- 2007-10-25 0001193125-07-225906 — 5.02, 9.01
- 2007-10-19 0001193125-07-221578 — 5.02
- 2007-09-26 0001193125-07-207348 — 8.01
- 2007-08-07 0001193125-07-172810 — 2.02, 9.01
- 2007-08-06 0001193125-07-172147 — 5.02, 9.01
- 2007-08-06 0001193125-07-172134 — 3.01
- 2007-07-09 0001193125-07-151467 — 3.01, 9.01
- 2007-06-28 0001193125-07-145519 — 2.02, 9.01
- 2007-06-27 0001193125-07-143262 — 2.05, 3.01, 5.02
- 2007-05-18 0001193125-07-118804 — 3.01, 9.01
- 2007-05-02 0001193125-07-099280 — 2.02, 9.01
- 2007-03-29 0001193125-07-068815 — 5.02, 9.01
- 2007-02-22 0001193125-07-037181 — 3.01, 9.01
- 2007-02-08 0001193125-07-024194 — 5.02
- 2007-01-30 0001193125-07-016428 — 2.02, 9.01
- 2007-01-11 0001193125-07-004825 — 4.02, 9.01
- 2006-11-21 0001193125-06-240068 — 5.02, 9.01
- 2006-11-16 0001193125-06-237262 — 3.01, 9.01
- 2006-11-01 0001193125-06-220707 — 2.02, 9.01
- 2006-10-31 0001193125-06-219237 — 1.01, 1.02, 5.02, 5.03, 8.01, 9.01
- 2006-09-28 0001193125-06-198185 — 3.01, 9.01
- 2006-09-15 0001193125-06-191640 — 7.01, 9.01
- 2006-09-05 0001193125-06-185202 — 5.02, 9.01
- 2006-08-08 0001193125-06-165953 — 1.01, 2.02, 5.02, 9.01
- 2006-07-18 0001193125-06-148526 — 1.01
- 2006-07-10 0001193125-06-143989 — 5.02, 9.01
- 2006-05-16 0001193125-06-113698 — 5.02, 9.01
- 2006-05-01 0001193125-06-094919 — 2.02, 9.01
- 2006-04-26 0001193125-06-089397 — 1.01, 9.01
- 2006-04-07 0001193125-06-075723 — 2.02, 9.01
- 2006-02-13 0001193125-06-029073 — 1.01
- 2006-01-31 0001193125-06-016143 — 1.01
- 2006-01-30 0001193125-06-015165 — 2.02, 9.01
- 2005-12-08 0001193125-05-239157 — 1.01, 1.02, 9.01
- 2005-11-01 0001193125-05-213101 — 2.02, 9.01
- 2005-09-29 0001193125-05-193991 — 1.01, 2.02, 9.01 — amendment of 0001193125-05-162807
- 2005-08-09 0001193125-05-162807 — 1.01, 2.02, 9.01
- 2005-07-14 0001193125-05-142162 — 8.01
- 2005-06-28 0001193125-05-133050 — 1.01, 9.01
- 2005-04-18 0001193125-05-077946 — 2.02, 7.01, 9.01
- 2005-04-14 0001193125-05-076665 — 2.02, 7.01, 9.01
- 2005-01-25 0001193125-05-011466 — 2.02, 9.01
- 2004-12-07 0001193125-04-208693 — 3.01
- 2004-10-26 0001193125-04-178370 — 2.02, 9.01
- 2004-10-04 0001193125-04-166289 — 5.02, 9.01
- 2004-07-28 0001193125-04-126135 — 12, 7
- 2004-05-12 0001193125-04-086287 — 12
- 2004-04-21 0001193125-04-066557 — 12, 7
- 2004-01-22 0001193125-04-007359 — 12, 7
- 2003-12-18 0001193125-03-096351 — 5, 7
- 2003-11-04 0001193125-03-072069 — 5, 7
- 2003-10-24 0001193125-03-066551 — 12, 7
- 2003-07-25 0001193125-03-024087 — 7, 9
- 2003-04-11 0001012870-03-001706 — 7, 9
- 2003-04-08 0001021408-03-005743 — 7, 9
- 2003-01-07 0001012870-03-000039 — 5, 7
- 2002-04-29 0001012870-02-002003 — 5, 7
- 2002-02-20 0001012870-02-000792 — 5, 7
- 2001-12-13 0001012870-01-503160 — 5, 7
- 2001-11-30 0001012870-01-503010 — 5, 7
- 2001-11-02 0001012870-01-502580 — 5
- 2001-10-23 0001021408-01-508589 — 5, 7
- 2001-06-07 0001021408-01-501772 — 5, 7 — amendment of 0001021408-01-500975
- 2001-05-15 0001021408-01-501104 — 5 — amendment of 0001021408-01-500975
- 2001-05-14 0001021408-01-500975 — 5, 7
- 2001-04-06 0001012870-01-500065 — 5, 7

## late-filing notifications on or before 2013-08-30

- 2008-05-12 0001193125-08-111540 — NT 10-Q, for the period ended 2008-03-30
- 2007-05-10 0001193125-07-110075 — NT 10-Q, for the period ended 2007-04-01
- 2007-02-09 0001193125-07-025490 — NT 10-Q, for the period ended 2006-12-31
- 2006-11-13 0001193125-06-232090 — NT 10-Q, for the period ended 2006-10-01
- 2006-09-15 0001193125-06-191838 — NT 10-K, for the period ended 2006-07-02

## item 2.02 — earnings release, exhibit 99.1

[0001078271-13-000039:8k_2_02:1]
EX-99.1
2
ex99-1q413earningsrelease.htm
PRESS RELEASE

[0001078271-13-000039:8k_2_02:2]
Ex 99-1 Q4'13 Earnings Release

[0001078271-13-000039:8k_2_02:3]
FOR IMMEDIATE RELEASE

[0001078271-13-000039:8k_2_02:4]
| For more information, contact: |  |  |
| Investor Relations |  | Public Relations |
| 408/579-3030 |  | 408/579-3483 |
| investor_relations@extremenetworks.com |  | gcross@extremenetworks.com |

[0001078271-13-000039:8k_2_02:5]
Extreme Networks Reports Fourth Quarter and Fiscal Year 2013 Earnings

[0001078271-13-000039:8k_2_02:6]
Q4 Revenue: $79.5 million, an increase of 16.5% quarter over quarter

[0001078271-13-000039:8k_2_02:7]
GAAP EPS: $0.03, an increase of $0.05 quarter over quarter

[0001078271-13-000039:8k_2_02:8]
Non-GAAP EPS: $0.07, up from $0.04 for the prior quarter

[0001078271-13-000039:8k_2_02:9]
Cash and Investments: $205.6 million, an increase of $16.5 million quarter over quarter

[0001078271-13-000039:8k_2_02:10]
SAN JOSE, Calif., July 30, 2013 /PRNewswire/ -- Extreme Networks, Inc. (Nasdaq: EXTR) (the “Company”) today reported revenues for its fiscal fourth quarter ending June 30, 2013 of $79.5 million. This represents a 16.5% increase compared to the prior quarter's revenues of $68.2 million and a 9.4% decrease compared to revenues of $87.7 million in Q4 2012. GAAP net income for Q4 was $3.2 million, or $0.03 per diluted share, an increase of $5.4 million, or $0.05 per diluted share compared to Q3 2013 and a decrease from $7.8 million, or $0.08 per diluted share for Q4 2012. Q4 non-GAAP net income was $6.7 million, or $0.07 per share, an increase of $3.4 million, or $0.03 per share compared to Q3 2013 and a decrease from Q4 2012 results of $7.6 million, or $0.08 per diluted share.

[0001078271-13-000039:8k_2_02:11]
For the full fiscal year, Extreme Networks reported 2013 revenues of $299.3 million, compared to $322.7 million for fiscal 2012.  GAAP net income was $9.7 million, or $0.10 per diluted share, compared to $15.9 million, or $0.17 per diluted share for the prior year.  On a non-GAAP basis, net income for fiscal year 2013 was $16.2 million, or $0.17 per diluted share, compared to $21.7 million, or $0.23 per diluted share, for fiscal 2012.  Cash and Investments ended fiscal year 2013 at $205.6 million compared to $153.5 million at the end of fiscal 2012.

[0001078271-13-000039:8k_2_02:12]
“We are pleased with the significant sequential quarter over quarter growth in revenues and operating income, which is indicative of the strength of our product offering,” said Chuck Berger, president and chief executive officer of Extreme Networks. “Our extensive line of Ethernet switches, reaching from the edge of the campus to data centers, all running on the most robust network operating system in the industry, have strong appeal to customers and partners.  That said, we continued to report year over year declines in revenues, which clearly indicates there is much to be done to improve our execution across the board.  We have identified the areas where changes are needed and are making solid progress, but it will take several quarters to realize the full benefit of these efforts.  Additionally, as in our third fiscal quarter, we were unable to fulfill a significant amount of orders due to reduced inventory levels and lengthening component lead times.  We will continue to face these shortages for the first half of the first quarter, but believe we will have caught up with demand as we go into September.”

[0001078271-13-000039:8k_2_02:13]
“During this past quarter we announced a global alliance with Lenovo.  We are a networking partner of theirs as they move strongly into the server market with a converged infrastructure solution.  Additionally we added a number of new customers and expanded our footprint with existing customers. Finally, yesterday we announced that Ed Carney has joined Extreme as our executive vice president, products and customer success.  Ed brings over three decades of experience in the networking industry, including most recently 15 years with Cisco.  Ed and his team will drive product innovation, development and quality

[0001078271-13-000039:8k_2_02:14]
with direct input from our customers.  We have a great deal of work to do, but I am encouraged after ending my first quarter with Extreme Networks with our progress and the tremendous potential of our technologies and market.”

[0001078271-13-000039:8k_2_02:15]
Fiscal Q4 2013 Financial Metrics:

[0001078271-13-000039:8k_2_02:16]
|  |  | Fourth Quarter |  |  |  |  |
|  |  | (in millions, except per share amounts and percentages) |  |  |  |  |
|  |  | (unaudited) |  |  |  |  |
|  |  | 2013 |  | 2012 |  | Change |
| Net Revenue |  |  |  |  |  |  |  |  |
| Product |  | $ | 64.5 |  |  | $ | 72.6 |  |  | $ | (8.1 | ) |  | (11.2 | )% |
| Service |  | $ | 15.0 |  |  | $ | 15.1 |  |  | $ | (0.1 | ) |  | (0.7 | )% |
| Total Net Revenue |  | $ | 79.5 |  |  | $ | 87.7 |  |  | $ | (8.2 | ) |  | (9.4 | )% |
| GAAP |  |  |  |  |  |  |  |  |
| Gross Margin |  | 55.3 | % |  | 55.7 | % |  | (0.4 | )% |  |  |
| Operating Margin/Loss |  | 3.7 | % |  | 6.2 | % |  | (2.5 | )% |  |  |
| Net Income |  | $ | 3.2 |  |  | $ | 7.8 |  |  | $ | (4.6 | ) |  |  |
| Earnings per diluted share |  | $ | 0.03 |  |  | $ | 0.08 |  |  | $ | (0.05 | ) |  |  |
| Non-GAAP |  |  |  |  |  |  |  |  |
| Gross Margin |  | 55.3 | % |  | 56.0 | % |  | (0.7 | )% |  |  |
| Operating Margin |  | 8.2 | % |  | 8.1 | % |  | 0.1 | % |  |  |
| Net Income |  | $ | 6.7 |  |  | $ | 7.6 |  |  | $ | (0.9 | ) |  |  |
| Earnings per diluted share |  | $ | 0.07 |  |  | $ | 0.08 |  |  | $ | (0.01 | ) |  |  |

[0001078271-13-000039:8k_2_02:17]
| • | GAAP operating margin includes $0.9 million of stock based compensation, CEO transition costs of $2.1 million and $0.6 million from a previously announced restructuring. These items are excluded from our non-GAAP operating margin. |

[0001078271-13-000039:8k_2_02:18]
| • | Cash and investments ended the quarter at $205.6 million, as compared to $189.1 million at Q3 of fiscal 2013. Free Cash flow for the year was $19.5 million. During the quarter, we repurchased 1.0 million shares for $3.5 million and for the fiscal year repurchased 4.1 million shares for $14.5 million. There remains $61 million in the previously announced three year $75 million buy-back program. |

[0001078271-13-000039:8k_2_02:19]
| • | Accounts receivable balance ending Q4 was $47.6 million, a (net) increase of $4.0 million from Q3 of fiscal 2013, with days sales outstanding (DSO) of 54, a decrease of 4 days from Q3 of fiscal 2013. |

[0001078271-13-000039:8k_2_02:20]
| • | Inventory ending Q4 was $16.2 million, a (net) increase of $0.5 million from Q3 of fiscal 2013 and represents 47 days of inventory (DOI), sequentially down 9 days from Q3 of fiscal 2013. |

[0001078271-13-000039:8k_2_02:21]
Recent Business Highlights:

[0001078271-13-000039:8k_2_02:22]
| • | Charles (Chuck) W. Berger was named Extreme Networks president and chief executive officer and was elected to our Board of Directors in April 2013. The Company also moved its corporate headquarters to San Jose, California, in the heart of the Silicon Valley, and opened its new and expanded R&D facility within Research Triangle Park (RTP) in North Carolina. |

[0001078271-13-000039:8k_2_02:23]
| • | Lenovo and Extreme Networks entered into a strategic global reseller alliance. Extreme Networks will enhance Lenovo's focus on enterprise-grade manageability, open standards and business critical reliability with industry leading networking solutions. Extreme Networks' Open Fabric Ethernet switches uniquely address the challenges of cloud computing with scale, reliability and via SDN with support of the OpenStack™ cloud initiative. |

[0001078271-13-000039:8k_2_02:24]
| • | EMC has certified Extreme Networks' Summit® X670 switch and can be used as part of a VSPEX-anchored implementation at data centers and cloud providers. EMC rolled out VSPEX in 2012; the initiative is a collection of server, storage and networking components that are certified to work together. Extreme Networks is one of only three EMC validated network switch vendors that can be considered in VSPEX deployments. |

[0001078271-13-000039:8k_2_02:25]
| • | Edward (Ed) T. Carney joined Extreme Networks on July 29 as Executive Vice President, Product and Customer Success, where he will oversee the development of market leading network platforms and shape the customer experience by leading Extreme Networks' global service and support organizations. |

[0001078271-13-000039:8k_2_02:26]
| • | Caixa, one of Brazil's leading financial institutions, added to its data center with follow-on orders and is the largest global installation to date of our flagship product, the BlackDiamond® X8. This is a strong endorsement for the product quality of this leading edge Open Fabric solution. |

[0001078271-13-000039:8k_2_02:27]
Business Outlook:

[0001078271-13-000039:8k_2_02:28]
For its first quarter of fiscal 2014 ending September 31, 2013, Extreme Networks is targeting revenues in a range of $72 million to $77 million.  GAAP and non-GAAP gross margin targeted to be between 55% and 56%. GAAP net income is targeted at breakeven to $4.0 million, or $0.00 to $0.04 per diluted share.  Non-GAAP net income is targeted in a range of $2.0 million to $6.0 million, or $0.02 to $0.06 per diluted share. The GAAP and non-GAAP net income targets are based on an estimated 95 million diluted weighted average shares.  Targeted non-GAAP earnings exclude expenses related to stock-based compensation expense of approximately $1.7 million and restructuring charges of approximately $0.3 million.

[0001078271-13-000039:8k_2_02:29]
The schedules attached hereto are an integral part of this release.

[0001078271-13-000039:8k_2_02:30]
Conference Call:

[0001078271-13-000039:8k_2_02:31]
Extreme Networks will host a conference call at 5:00 p.m. Eastern (2:00 p.m. Pacific) today to review the highlights of the fourth fiscal quarter 2013 and the business outlook for the first fiscal quarter of 2014, including significant factors and assumptions underlying the targets noted above. The conference call will be available to the public through a live audio web broadcast via the Internet at http://investor.extremenetworks.com and a replay of the call will be available on the website through August 15, 2013.  The conference call may also be heard by dialing 1-877-303-9826 and International callers' dial 1-224-357-2194, Conference ID: 93884800.  Supplemental financial information to be discussed during the conference call will be posted in the Investor Relations section of the Company's website www.extremenetworks.com including the non-GAAP reconciliation attached to this press release.

[0001078271-13-000039:8k_2_02:32]
About Extreme Networks:

[0001078271-13-000039:8k_2_02:33]
Extreme Networks is a San Jose, CA-based leader in high-performance Ethernet switching for cloud, data center and mobile networks.  Extreme Networks is a trademark or registered trademark of Extreme Networks, Inc. in the United States and/or other countries.

[0001078271-13-000039:8k_2_02:34]
For additional product and company information, please refer to www.extremenetworks.com.

[0001078271-13-000039:8k_2_02:35]
Non-GAAP Financial Measures:

[0001078271-13-000039:8k_2_02:36]
Extreme Networks provides all financial information required in accordance with generally accepted accounting principles (GAAP). To supplement its consolidated financial statements presented in accordance with GAAP, the Company is also providing with this press release non-GAAP net income and non-GAAP operating income. In preparing non-GAAP information, the Company has excluded, where applicable, the impact of restructuring charges, share-based compensation, litigation settlements, Chief Executive Officer transition expenses, gain on the sale of facilities and the currency loss from closing subsidiaries.  The Company believes that excluding these items provides both management and investors with additional insight into its current operations, the trends affecting the Company and the Company's marketplace performance. In particular, management finds it useful to exclude these items in order to more readily correlate the Company's operating activities with the Company's ability to generate cash from operations. Accordingly, management uses these non-GAAP measures, along with the comparable GAAP information, in evaluating the Company's historical performance and in planning its future business activities. Please note that the Company's non-GAAP measures may be different than those used by other companies. The additional non-GAAP financial information the Company presents should be considered in conjunction with, and not as a substitute for, the Company's financial information presented in accordance with GAAP.  The Company has provided a non-GAAP reconciliation of the Condensed Consolidated Statement of Operations for the periods presented in this release, which are adjusted to exclude restructuring charges, share-based compensation expense and litigation settlements for these periods. These measures should only be used to evaluate the Company's results of operations in conjunction with the corresponding GAAP measures for comparable financial information and understanding of the Company's ongoing performance as a business. Extreme Networks uses both GAAP and non-GAAP measures to evaluate and manage its operations.

[0001078271-13-000039:8k_2_02:37]
Forward Looking Statements:

[0001078271-13-000039:8k_2_02:38]
Actual results, including with respect to the Company's financial targets and general business prospects, could differ materially due to a number of factors, including the risk that the Company may not obtain sufficient orders to achieve targeted revenues for the Company's products and services given both increasing price competition in key network switching equipment markets and the need to align the Company's cost structure to meet the Company's financial goals; the Company's effectiveness in controlling expenses, including the risk that the Company's restructuring efforts may not achieve as significant a reduction in operating expenses as anticipated, the risk that it or its distributors and other channel partners are not able to develop and expand customer bases and accurately anticipate demand from end customers, which can result in increased inventory and reduced orders as it experiences wide fluctuations in supply and demand; the risk that its results will suffer if it is  unable to balance fluctuations in customer demand and capacity; risks associated with the ramp-up of production of its new products and its entry into new business channels different from those in which it has historically operated; the risk that it may experience production delays that preclude it from shipping sufficient quantities to meet customer orders or that result in higher production costs and lower margins; ongoing uncertainty in global economic conditions, infrastructure development or customer demand that could negatively affect product demand, collectability of receivables and other related matters as consumers and businesses may defer purchases or payments, or default on payments; its ability to complete development and commercialization of products under development, such as its pipeline of new

[0001078271-13-000039:8k_2_02:39]
network switches and related software; its ability to lower costs; risks resulting from the concentration of business among few customers, including the risk that customers may reduce or cancel orders or fail to honor purchase commitments; the rapid development of new technology and competing products that may impair demand or render its products obsolete; the potential lack of customer acceptance for new products; and risks associated with ongoing litigation; a dependency on third parties for certain components and for the manufacturing of the Company's products.

[0001078271-13-000039:8k_2_02:40]
More information about potential factors that could affect the Company's business and financial results is included in its filings with the Securities and Exchange Commission, including, without limitation, under the captions: “Management's Discussion and Analysis of Financial Condition and Results of Operations,” and “Risk Factors,” which are on file with the Securities and Exchange Commission. Except as required under the U.S. federal securities laws and the rules and regulations of the SEC, Extreme Networks disclaims any obligation to update any forward-looking statements after the date of this release, whether as a result of new information, future events, developments, changes in assumptions or otherwise.

[0001078271-13-000039:8k_2_02:41]
EXTREME NETWORKS, INC.

[0001078271-13-000039:8k_2_02:42]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0001078271-13-000039:8k_2_02:43]
(In thousands, except share and per share amounts)

[0001078271-13-000039:8k_2_02:44]
(Unaudited)

[0001078271-13-000039:8k_2_02:45]
|  | June 30, 2013 |  | June 30, 2012 |
| ASSETS |  |  |  |
| Current assets: |  |  |  |
| Cash and cash equivalents | $ | 95,803 |  |  | $ | 54,596 |  |
| Short-term investments | 43,034 |  |  | 23,358 |  |
| Accounts receivable, net of allowances of $1,252 at June 30, 2013 and $1,646 at June 30, 2012 | 47,642 |  |  | 41,166 |  |
| Inventories | 16,167 |  |  | 26,609 |  |
| Deferred income taxes | 386 |  |  | 644 |  |
| Prepaid expenses and other current assets | 5,749 |  |  | 5,655 |  |
| Assets held for sale | — |  |  | 17,081 |  |
| Total current assets | 208,781 |  |  | 169,109 |  |
| Property and equipment, net | 23,644 |  |  | 25,180 |  |
| Marketable securities | 66,776 |  |  | 75,561 |  |
| Intangible assets, net | 4,243 |  |  | 5,106 |  |
| Other assets, net | 7,980 |  |  | 9,634 |  |
| Total assets | $ | 311,424 |  |  | $ | 284,590 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |  |  |  |
| Current liabilities: |  |  |  |
| Accounts payable | $ | 27,163 |  |  | $ | 19,437 |  |
| Accrued compensation and benefits | 13,503 |  |  | 13,409 |  |
| Restructuring liabilities | 1,466 |  |  | 463 |  |
| Accrued warranty | 3,296 |  |  | 2,871 |  |
| Deferred revenue, net | 33,184 |  |  | 31,769 |  |
| Deferred distributors revenue, net of cost of sales to distributors | 17,388 |  |  | 15,319 |  |
| Other accrued liabilities | 16,502 |  |  | 13,480 |  |
| Total current liabilities | 112,502 |  |  | 96,748 |  |
| Deferred revenue, less current portion | 8,270 |  |  | 7,559 |  |
| Other long-term liabilities | 1,507 |  |  | 643 |  |
| Commitments and contingencies |  |  |  |
| Stockholders’ equity | 189,145 |  |  | 179,640 |  |
| Total liabilities and stockholders’ equity | $ | 311,424 |  |  | $ | 284,590 |  |

[0001078271-13-000039:8k_2_02:46]
EXTREME NETWORKS, INC.

[0001078271-13-000039:8k_2_02:47]
CONDENSED CONSOLIDATED STATEMENTS OF INCOME

[0001078271-13-000039:8k_2_02:48]
(In thousands, except per share amounts)

[0001078271-13-000039:8k_2_02:49]
(Unaudited)

[0001078271-13-000039:8k_2_02:50]
|  | Three Months Ended |  | Year Ended |
|  | June 30, 2013 |  | June 30, 2012 |  | June 30, 2013 |  | June 30, 2012 |
| Net revenues: |  |  |  |  |  |  |  |
| Product | $ | 64,505 |  |  | $ | 72,558 |  |  | $ | 239,955 |  |  | $ | 261,873 |  |
| Service | 14,957 |  |  | 15,091 |  |  | 59,388 |  |  | 60,849 |  |
| Total net revenues | 79,462 |  |  | 87,649 |  |  | 299,343 |  |  | 322,722 |  |
| Cost of revenues: |  |  |  |  |  |  |  |
| Product | 30,803 |  |  | 33,305 |  |  | 115,862 |  |  | 120,227 |  |
| Service | 4,684 |  |  | 5,511 |  |  | 20,855 |  |  | 22,648 |  |
| Total cost of revenues | 35,487 |  |  | 38,816 |  |  | 136,717 |  |  | 142,875 |  |
| Gross profit: |  |  |  |  |  |  |  |
| Product | 33,702 |  |  | 39,253 |  |  | 124,093 |  |  | 141,646 |  |
| Service | 10,273 |  |  | 9,580 |  |  | 38,533 |  |  | 38,201 |  |
| Total gross profit | 43,975 |  |  | 48,833 |  |  | 162,626 |  |  | 179,847 |  |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | 9,567 |  |  | 11,774 |  |  | 40,521 |  |  | 45,640 |  |
| Sales and marketing | 22,438 |  |  | 24,655 |  |  | 87,202 |  |  | 90,167 |  |
| General and administrative | 8,434 |  |  | 6,880 |  |  | 26,725 |  |  | 28,658 |  |
| Restructuring charge, net of reversals | 593 |  |  | 237 |  |  | 6,836 |  |  | 1,594 |  |
| Litigation Settlement | — |  |  | (121 | ) |  | 2,029 |  |  | (121 | ) |
| Gain on sale of facilities | — |  |  | — |  |  | (11,539 | ) |  | — |  |
| Total operating expenses | 41,032 |  |  | 43,425 |  |  | 151,774 |  |  | 165,938 |  |
| Operating income | 2,943 |  |  | 5,408 |  |  | 10,852 |  |  | 13,909 |  |
| Interest income | 284 |  |  | 311 |  |  | 1,070 |  |  | 1,239 |  |
| Interest expense | — |  |  | — |  |  | — |  |  | (75 | ) |
| Other income (expense), net | 243 |  |  | 2,049 |  |  | (571 | ) |  | 1,995 |  |
| Income before income taxes | 3,470 |  |  | 7,768 |  |  | 11,351 |  |  | 17,068 |  |
| Provision for income taxes | 286 |  |  | (44 | ) |  | 1,678 |  |  | 1,196 |  |
| Net income | $ | 3,184 |  |  | $ | 7,812 |  |  | $ | 9,673 |  |  | $ | 15,872 |  |
| Basic and diluted net income per share: |  |  |  |  |  |  |  |
| Net income per share - basic | $ | 0.03 |  |  | $ | 0.08 |  |  | $ | 0.10 |  |  | $ | 0.17 |  |
| Net income per share - diluted | $ | 0.03 |  |  | $ | 0.08 |  |  | $ | 0.10 |  |  | $ | 0.17 |  |
| Shares used in per share calculation - basic | 93,611 |  |  | 94,186 |  |  | 93,954 |  |  | 93,451 |  |
| Shares used in per share calculation - diluted | 94,894 |  |  | 95,225 |  |  | 95,044 |  |  | 94,490 |  |

[0001078271-13-000039:8k_2_02:51]
EXTREME NETWORKS, INC.

[0001078271-13-000039:8k_2_02:52]
CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS

[0001078271-13-000039:8k_2_02:53]
(In thousands)

[0001078271-13-000039:8k_2_02:54]
(Unaudited)

[0001078271-13-000039:8k_2_02:55]
|  | Year Ended |
|  | June 30, 2013 |  | June 30, 2012 |
| Net cash provided by operating activities | $ | 32,237 |  |  | $ | 13,813 |  |
| Cash flows from investing activities: |  |  |  |
| Capital expenditures | (12,737 | ) |  | (5,237 | ) |
| Purchases of investments | (57,712 | ) |  | (75,851 | ) |
| Proceeds from maturities of investments and marketable securities | 16,367 |  |  | 30,295 |  |
| Proceeds from sales of investments and marketable securities | 28,528 |  |  | 40,658 |  |
| Purchase of intangible assets | (625 | ) |  | (275 | ) |
| Proceeds from sales of facilities | 42,659 |  |  | — |  |
| Net cash provided by (used in) investing activities | 16,480 |  |  | (10,410 | ) |
| Cash flows from financing activities: |  |  |  |
| Proceeds from issuance of common stock | 7,084 |  |  | 1,392 |  |
| Repurchases of common stock | (14,475 | ) |  | — |  |
| Deposit from sale of buildings | — |  |  | 1,001 |  |
| Net cash (used in) provided by financing activities | (7,391 | ) |  | 2,393 |  |
| Foreign currency effect on cash | (119 | ) |  | (1,172 | ) |
| Net increase in cash and cash equivalents | 41,207 |  |  | 4,624 |  |
| Cash and cash equivalents at beginning of period | 54,596 |  |  | 49,972 |  |
| Cash and cash equivalents at end of period | $ | 95,803 |  |  | $ | 54,596 |  |

[0001078271-13-000039:8k_2_02:56]
Extreme Networks, Inc.

[0001078271-13-000039:8k_2_02:57]
Non-GAAP Measures of Financial Performance

[0001078271-13-000039:8k_2_02:58]
To supplement the Company's consolidated financial statements presented in accordance with generally accepted accounting principles, or GAAP, Extreme Networks uses non-GAAP measure of certain components of financial performance.  These non-GAAP measures include non-GAAP net income, non-GAAP earnings per diluted share, non-GAAP gross margin, non-GAAP operating expenses and free cash flow.

[0001078271-13-000039:8k_2_02:59]
Reconciliation to the nearest GAAP measure of all historical non-GAAP measures included in this press release can be found in the tables included with this press release.  In this press release, Extreme Networks also presents its target for non-GAAP expenses, which is expenses less stock based compensation expense, litigation settlements, restructuring expenses, gains related to the sale of the Santa Clara campus, one-time CEO transition expenses and currency gains or losses related to closing of certain foreign subsidiaries.

[0001078271-13-000039:8k_2_02:60]
Non-GAAP measures presented in this press release are not in accordance with or an alternative measures prepared in accordance with GAAP and may be different from non-GAAP measures used by other companies.  In addition these, non-GAAP measures are not based on any comprehensive set of accounting rules or principles.  Non-GAAP measures have limitations in that they do not reflect all of the amounts associated with Extreme Networks' results of operations as determined in accordance with GAAP.  These non-GAAP measures should only be used to evaluate Extreme Networks' results of operations in conjunction with the corresponding GAAP measures.

[0001078271-13-000039:8k_2_02:61]
Extreme Networks believes that these non-GAAP measures when shown in conjunction with the corresponding GAAP measures enhance investors' and management's overall understanding of the Company's current financial performance and the Company's prospects for the future, including cash flows available to pursue opportunities to enhance shareholder value.  In addition, because Extreme Networks has historically reported certain non-GAAP results to investors, the Company believes that the inclusion of non-GAAP measures provides consistency in the Company's financial reporting.

[0001078271-13-000039:8k_2_02:62]
For its internal planning process, and as discussed further below, Extreme Network's management uses financial statements that do not include stock-based compensation expense, litigation settlement gains or losses, restructuring expenses , gains related to the sale of the Santa Clara campus and currency gains or losses related to closing of certain foreign subsidiaries.  Extreme Networks' management also uses non-GAAP measures, in addition to the corresponding GAAP measures, in reviewing the Company's financial results.

[0001078271-13-000039:8k_2_02:63]
As described above, Extreme Networks excludes the following items from one or more of its non-GAAP measures when applicable.

[0001078271-13-000039:8k_2_02:64]
Stock based compensation expense. This expense consists of expenses for stock options, restricted stock and employee stock purchases through its ESPP.  Extreme Networks excludes stock based compensation expenses from its non-GAAP measures primarily because they are non-cash expenses that the Company does not believe are reflective of ongoing cash requirement related to operating results. Extreme Networks expects to incur stock-based compensation expenses in future periods.

[0001078271-13-000039:8k_2_02:65]
Restructuring expenses. Restructuring expenses primarily consist of cash severance and termination benefits. Extreme Networks excludes restructuring expenses since they result from events that often occur outside of the ordinary course of continuing operations. Extreme Networks expects to incur restructuring expenses in future periods

[0001078271-13-000039:8k_2_02:66]
Gains related to the sale of facilities.  The one-time net gain related to the sale of the Santa Clara campus consist of the gross proceeds of the sale less the expenses directly related to the sale such as commissions, closing costs and legal fees.  Extreme Networks excludes this gain because it is a one-time event and does not believe that the gain is reflective of ongoing operations.

[0001078271-13-000039:8k_2_02:67]
Chief Executive Officer (CEO) transition expenses.  This expense is related to the costs associated with the severance payments, both cash and stock based, for the Company's prior CEO and the cost of transitioning with a new CEO.  Extreme Networks excludes these costs as it does not believe it is reflective of ongoing operations.

[0001078271-13-000039:8k_2_02:68]
Currency gains or losses related to closing of certain foreign subsidiaries.  This is related to the closing of our Japanese subsidiary.  This has accumulated over time and has historically been included in Other Comprehensive Income.   Extreme Networks excludes these gains and losses as it is a one-time event and does not believe it is reflective of ongoing operations.

[0001078271-13-000039:8k_2_02:69]
In addition to the non-GAAP measures discussed above, Extreme Networks also uses free cash flow as a measure of operating performance.  Free cash flow represents operating cash flows less net purchase of property and equipment.  Extreme Networks considers free cash flows to be a liquidity measure that provides useful information to management and investors about the amount of cash generated by the business after the purchases of property and equipment, which can then be used to, among other things, invest in Extreme Networks business, make strategic acquisitions, strengthen the balance sheet and repurchase stock.  A limitation of the utility of free cash slows as a measure of financial performance is that it does not represent the total increases or decrease in the Company's cash balance for the period.

[0001078271-13-000039:8k_2_02:70]
EXTREME NETWORKS, INC.

[0001078271-13-000039:8k_2_02:71]
CONDENSED CONSOLIDATED STATEMENTS OF INCOME

[0001078271-13-000039:8k_2_02:72]
GAAP TO NON-GAAP RECONCILIATION

[0001078271-13-000039:8k_2_02:73]
(In thousands, except per share amounts)

[0001078271-13-000039:8k_2_02:74]
(Unaudited)

[0001078271-13-000039:8k_2_02:75]
| Non-GAAP Gross Margin | Three Months Ended |  | Year Ended |
|  | June 30, 2013 |  | June 30, 2012 |  | June 30, 2013 |  | June 30, 2012 |
| Gross profit - GAAP Basis | $ | 43,975 |  |  | $ | 48,833 |  |  | $ | 162,626 |  |  | $ | 179,847 |  |
| Gross margin - GAAP Basis percentage | 55.3 | % |  | 55.7 | % |  | 54.3 | % |  | 55.7 | % |
| Adjustments: |  |  |  |  |  |  |  |
| Stock based compensation expense | $ | 3 |  |  | $ | 212 |  |  | $ | 720 |  |  | $ | 788 |  |
| Gross profit - Non-GAAP Basis | $ | 43,978 |  |  | $ | 49,045 |  |  | $ | 163,346 |  |  | $ | 180,635 |  |
| Gross margin - Non-GAAP Basis percentage | 55.3 | % |  | 56.0 | % |  | 54.6 | % |  | 56.0 | % |
| Non-GAAP Operating Income | Three Months Ended |  | Year Ended |
|  | June 30, 2013 |  | June 30, 2012 |  | June 30, 2013 |  | June 30, 2012 |
| GAAP operating income | $ | 2,943 |  |  | $ | 5,408 |  |  | $ | 10,852 |  |  | $ | 13,909 |  |
| GAAP operating income percentage | 3.7 | % |  | 6.2 | % |  | 3.6 | % |  | 4.3 | % |
| Adjustments: |  |  |  |  |  |  |  |
| Stock based compensation expense | $ | 886 |  |  | $ | 1,537 |  |  | $ | 6,511 |  |  | $ | 6,189 |  |
| Restructuring charge, net of reversals | $ | 593 |  |  | $ | 237 |  |  | $ | 6,836 |  |  | $ | 1,594 |  |
| Litigation Settlement | $ | — |  |  | $ | (53 | ) |  | $ | 2,197 |  |  | $ | (53 | ) |
| Gain on sale of facilities | $ | — |  |  | $ | — |  |  | $ | (11,539 | ) |  | $ | — |  |
| One-time CEO transition expenses | $ | 2,086 |  |  | $ | — |  |  | $ | 2,086 |  |  | $ | — |  |
| Total adjustments to GAAP operating income | $ | 3,565 |  |  | $ | 1,721 |  |  | $ | 6,091 |  |  | $ | 7,730 |  |
| Non-GAAP operating income | $ | 6,508 |  |  | $ | 7,129 |  |  | $ | 16,943 |  |  | $ | 21,639 |  |
| Non-GAAP operating income percentage | 8.2 | % |  | 8.1 | % |  | 5.7 | % |  | 6.7 | % |
| Non-GAAP Net Income | Three Months Ended |  | Year Ended |
|  | June 30, 2013 |  | June 30, 2012 |  | June 30, 2013 |  | June 30, 2012 |
| GAAP net income | $ | 3,184 |  |  | $ | 7,812 |  |  | $ | 9,673 |  |  | $ | 15,872 |  |
| Adjustments: |  |  |  |  |  |  |  |
| Stock based compensation expense | $ | 886 |  |  | $ | 1,537 |  |  | $ | 6,511 |  |  | $ | 6,189 |  |
| Restructuring charge, net of reversals | $ | 593 |  |  | $ | 237 |  |  | $ | 6,836 |  |  | $ | 1,594 |  |
| Litigation Settlement | $ | — |  |  | $ | (53 | ) |  | $ | 2,197 |  |  | $ | (53 | ) |
| Gain on sale of facilities | $ | — |  |  | $ | — |  |  | $ | (11,539 | ) |  | $ | — |  |
| One-time CEO transition expenses | $ | 2,086 |  |  | $ | — |  |  | $ | 2,086 |  |  | $ | — |  |
| Currency loss from closing of a foreign subsidiary | $ | — |  |  | $ | (1,887 | ) |  | $ | 465 |  |  | $ | (1,887 | ) |
| Total adjustments to GAAP net income | $ | 3,565 |  |  | $ | (166 | ) |  | $ | 6,556 |  |  | $ | 5,843 |  |
| Non-GAAP net income | $ | 6,749 |  |  | $ | 7,646 |  |  | $ | 16,229 |  |  | $ | 21,715 |  |

[0001078271-13-000039:8k_2_02:76]
| Earnings per share |  |  |  |  |  |  |  |
| Non-GAAP diluted net income per share | $ | 0.07 |  |  | $ | 0.08 |  |  | $ | 0.17 |  |  | $ | 0.23 |  |
| Shares used in diluted net income per share calculation | 94,984 |  |  | 95,225 |  |  | 95,044 |  |  | 94,490 |  |
| Free Cash Flow | Three Months Ended |  | Year Ended |
|  | June 30, 2013 |  | June 30, 2012 |  | June 30, 2013 |  | June 30, 2012 |
| Cash flow provided by operations | $ | 25,235 |  |  | $ | 7,406 |  |  | $ | 32,237 |  |  | $ | 13,813 |  |
| Add: PP&E CapEx spending | $ | (8,315 | ) |  | $ | (816 | ) |  | $ | (12,737 | ) |  | $ | (5,237 | ) |
| Total free cash flow | $ | 16,920 |  |  | $ | 6,590 |  |  | $ | 19,500 |  |  | $ | 8,576 |  |
