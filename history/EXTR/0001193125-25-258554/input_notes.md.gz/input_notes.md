# EXTR notes — 0001193125-25-258554


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0001193125-25-258554:notes:1]
[same as prior period, unchanged from 0000950170-25-061827:notes:1]

[0001193125-25-258554:notes:2]
[same as prior period, unchanged from 0000950170-25-061827:notes:2]

[0001193125-25-258554:notes:3]
The unaudited condensed consolidated financial statements of Extreme included herein have been prepared under the rules and regulations of the Securities and Exchange Commission (“SEC”). Certain information and footnote disclosures normally included in financial statements prepared in accordance with U.S. generally accepted accounting principles have been condensed or omitted under such rules and regulations. The condensed consolidated balance sheet at June 30, 2025 was derived from audited financial statements as of that date but does not include all disclosures required by generally accepted accounting principles for complete financial statements. These interim financial statements and notes should be read in conjunction with the Company’s audited consolidated financial statements and notes thereto included in the Company’s Annual Report on Form 10-K for the fiscal year ended June 30, 2025.

[0001193125-25-258554:notes:4]
The unaudited condensed consolidated financial statements reflect all adjustments, consisting only of normal recurring adjustments that, in the opinion of management, are necessary for a fair presentation of the results of operations and cash flows for the interim periods presented and the financial condition of Extreme at September 30, 2025. The results of operations for the three months ended September 30, 2025 are not necessarily indicative of the results that may be expected for fiscal 2026 or any future periods.

[0001193125-25-258554:notes:5]
[same as prior period, unchanged from 0000950170-25-061827:notes:5]

[0001193125-25-258554:notes:6]
The Company uses a fiscal calendar year ending on June 30. All references herein to “fiscal 2026” represent the fiscal year ending June 30, 2026. All references herein to “fiscal 2025” represent the fiscal year ended June 30, 2025.

[0001193125-25-258554:notes:7]
[same as prior period, unchanged from 0000950170-25-061827:notes:7]

[0001193125-25-258554:notes:8]
[same as prior period, unchanged from 0000950170-25-061827:notes:8]

[0001193125-25-258554:notes:9]
[same as prior period, unchanged from 0000950170-25-061827:notes:9]

[0001193125-25-258554:notes:10]
[same as prior period, unchanged from 0000950170-25-061827:notes:10]

[0001193125-25-258554:notes:11]
[same as prior period, unchanged from 0000950170-25-061827:notes:11]


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001193125-25-258554:notes:12]
[same as prior period, unchanged from 0000950170-25-061827:notes:12]

[0001193125-25-258554:notes:13]
For a description of significant accounting policies, see Note 2, Summary of Significant Accounting Policies, to the consolidated financial statements included in the Company’s Annual Report on Form 10-K for the fiscal year ended June 30, 2025. There have been no material changes to the Company’s significant accounting policies since the filing of the Annual Report on Form 10-K.

[0001193125-25-258554:notes:14]
Recently Adopted Accounting Pronouncements

[0001193125-25-258554:notes:15]
There were no recently adopted accounting standards which would have a material effect on the Company's condensed consolidated financial statements and accompanying disclosures.

[0001193125-25-258554:notes:16]
Recently Issued Accounting Pronouncements Not Yet Adopted

[0001193125-25-258554:notes:17]
In September 2025, the Financial Accounting Standards Board (“FASB") issued Accounting Standards Update ("ASU") 2025-06, Intangibles—Goodwill and Other—Internal-Use Software (Subtopic 350-40): Targeted Improvements to the Accounting for Internal-Use Software. This ASU removes all references to prescriptive and sequential software development stages and requires entities to begin capitalizing software costs when management authorizes and commits to funding the software project, and it is probable that the project will be completed, and the software will be used for its intended purpose. The amendments in this ASU are effective for fiscal years beginning after December 15, 2027, and interim periods within those annual reporting periods. Early adoption is permitted. The Company is currently evaluating the impact of adopting ASU 2025-06 on its consolidated financial statements and related disclosures.

[0001193125-25-258554:notes:18]
In July 2025, the FASB issued ASU 2025-05, Financial Instruments—Credit Losses (Topic 326): Measurement of Credit Losses for Accounts Receivable and Contract Assets to address challenges encountered when applying the guidance in Topic 326, Financial Instruments—Credit Losses, to current accounts receivable and current contract assets arising from transactions accounted for under Topic 606, Revenue from Contracts with Customers. ASU 2025-05 is effective for fiscal years beginning after December 15, 2025, and interim periods within those annual reporting periods. Early adoption is permitted. The Company is currently evaluating the impact of adopting ASU 2025-05 on its consolidated financial statements and related disclosures.

[0001193125-25-258554:notes:19]
In November 2024, the FASB issued ASU 2024-03, Income Statement—Reporting Comprehensive Income—Expense Disaggregation Disclosures (Subtopic 220-40): Disaggregation of Income Statement Expenses to improve disclosures about public business entities’ expenses and to provide more detailed information around the types of expenses included in commonly presented expense captions. Additionally, in January 2025 the FASB issued ASU 2025-01 to clarify the effective date of ASU 2024-03. ASU 2024-03 is effective for fiscal years beginning after December 15, 2026, and interim periods for fiscal years beginning after December 15, 2027, and can be applied on a prospective basis or on a retrospective basis to all periods presented. Early adoption is permitted. The Company is currently evaluating the impact of adopting ASU 2024-03 and ASU 2025-01 on its consolidated financial statements and related disclosures.

[0001193125-25-258554:notes:20]
In December 2023, the FASB issued ASU 2023-09, Income Taxes (Topic 740), Improvements to Income Tax Disclosures to enhance income tax disclosures primarily through changes in the rate reconciliation and income taxes paid information. ASU 2023-09 is effective for fiscal years beginning after December 15, 2024 on a prospective basis. Early adoption is permitted. The Company is currently evaluating the impact of adopting ASU 2023-09 on its consolidated financial statements and related disclosures.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001193125-25-258554:notes:21]
[same as prior period, unchanged from 0000950170-25-061827:notes:20]

[0001193125-25-258554:notes:22]
[same as prior period, unchanged from 0000950170-25-061827:notes:21]

[0001193125-25-258554:notes:23]
[same as prior period, unchanged from 0000950170-25-061827:notes:22]

[0001193125-25-258554:notes:24]
[same as prior period, unchanged from 0000950170-25-061827:notes:23]

[0001193125-25-258554:notes:25]
[same as prior period, unchanged from 0000950170-25-061827:notes:24]

[0001193125-25-258554:notes:26]
As of September 30, 2025, the Company had $632.2 million of remaining performance obligations, which is primarily comprised of deferred SaaS subscription and deferred support revenues. The Company expects to recognize approximately 43% of its deferred revenue as revenue in the remainder of fiscal 2026, an additional 27% in fiscal 2027, and the remaining 30% of the balance thereafter.

[0001193125-25-258554:notes:27]
[same as prior period, unchanged from 0000950170-25-061827:notes:26]

[0001193125-25-258554:notes:28]
Revenue recognized for the three months ended September 30, 2025 and 2024 that was included in the deferred revenue balance at the beginning of each period was $104.7 million and $100.3 million, respectively.

[0001193125-25-258554:notes:29]
Contract Costs. The Company recognizes the incremental costs of obtaining contracts as an expense when incurred if the amortization period of the assets that the Company otherwise would have recognized is one year or less. Management expects that commission fees paid to sales representatives as a result of obtaining subscription and support contracts and contract renewals are recoverable and therefore the Company’s condensed consolidated balance sheets included capitalized balances in the amount of $28.6 million and $26.9 million as of September 30, 2025 and June 30, 2025, respectively. Capitalized commissions are included within other assets in the condensed consolidated balance sheets. Capitalized commission fees are amortized on a straight-line basis over the average period of service contracts of approximately three years, and are included in “Sales and marketing” in the accompanying condensed consolidated statements of operations. Amortization recognized during the three months ended September 30, 2025 and 2024 was $3.4 million and $3.0 million, respectively.

[0001193125-25-258554:notes:30]
[same as prior period, unchanged from 0000950170-25-061827:notes:29]

[0001193125-25-258554:notes:31]
[same as prior period, unchanged from 0000950170-25-061827:notes:30]

[0001193125-25-258554:notes:32]
[same as prior period, unchanged from 0000950170-25-061827:notes:31]

[0001193125-25-258554:notes:33]
|  | Three Months Ended |  |
|  |  | September 30,2025 |  |  | September 30,2024 |  |
| Americas: |  |  |  |  |  |  |
| United States |  |  | 136,384 |  |  | $ | 153,253 |  |
| Other |  |  | 12,875 |  |  |  | 12,182 |  |
| Total Americas |  |  | 149,259 |  |  |  | 165,435 |  |
| EMEA |  |  | 121,246 |  |  |  | 84,918 |  |
| APAC |  |  | 39,740 |  |  |  | 18,851 |  |
| Total net revenues |  | $ | 310,245 |  |  | $ | 269,204 |  |

[0001193125-25-258554:notes:34]
[same as prior period, unchanged from 0000950170-25-061827:notes:33]

[0001193125-25-258554:notes:35]
For the three months ended September 30, 2025 and 2024 no foreign country accounted for 10% or more of the Company's net revenues.

[0001193125-25-258554:notes:36]
[same as prior period, unchanged from 0000950170-25-061827:notes:35]

[0001193125-25-258554:notes:37]
[same as prior period, unchanged from 0000950170-25-061827:notes:36]

[0001193125-25-258554:notes:38]
[same as prior period, unchanged from 0000950170-25-061827:notes:37]

[0001193125-25-258554:notes:39]
|  |  | Three Months Ended |
|  |  | September 30,2025 |  | September 30,2024 |
| Jenne, Inc. |  | 18% |  | 21% |
| TD Synnex Corporation |  | 16% |  | 22% |
| Westcon Group, Inc. |  | 15% |  | 15% |

[0001193125-25-258554:notes:40]
[same as prior period, unchanged from 0000950170-25-061827:notes:39]

[0001193125-25-258554:notes:41]
|  |  | September 30,2025 |  | June 30,2025 |
| Jenne, Inc. |  | 21% |  | 22% |
| J's Communication Co., Ltd. |  | 11% |  | * |
| Ericcson, Inc. |  | * |  | 11% |
| * Less than 10% of accounts receivable |  |  |  |  |


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001193125-25-258554:notes:42]
[same as prior period, unchanged from 0000950170-25-061827:notes:41]

[0001193125-25-258554:notes:43]
[same as prior period, unchanged from 0000950170-25-061827:notes:42]

[0001193125-25-258554:notes:44]
[same as prior period, unchanged from 0000950170-25-061827:notes:43]

[0001193125-25-258554:notes:45]
[same as prior period, unchanged from 0000950170-25-061827:notes:44]

[0001193125-25-258554:notes:46]
|  |  | September 30,2025 |  |  | June 30,2025 |  |
| Cash |  | $ | 206,606 |  |  | $ | 225,656 |  |
| Cash equivalents |  |  | 2,397 |  |  |  | 6,089 |  |
| Total cash and cash equivalents |  | $ | 209,003 |  |  | $ | 231,745 |  |

[0001193125-25-258554:notes:47]
[same as prior period, unchanged from 0000950170-25-061827:notes:46]

[0001193125-25-258554:notes:48]
[same as prior period, unchanged from 0000950170-25-061827:notes:48]

[0001193125-25-258554:notes:49]
|  |  | September 30,2025 |  |  | June 30,2025 |  |
| Finished goods |  | $ | 54,665 |  |  | $ | 57,770 |  |
| Raw materials |  |  | 39,068 |  |  |  | 44,808 |  |
| Total inventories |  | $ | 93,733 |  |  | $ | 102,578 |  |

[0001193125-25-258554:notes:50]
[same as prior period, unchanged from 0000950170-25-061827:notes:50]

[0001193125-25-258554:notes:51]
[same as prior period, unchanged from 0000950170-25-061827:notes:51]

[0001193125-25-258554:notes:52]
|  |  | September 30,2025 |  |  | June 30,2025 |  |
| Computers and equipment |  | $ | 83,684 |  |  | $ | 80,782 |  |
| Software |  |  | 65,949 |  |  |  | 62,089 |  |
| Office equipment, furniture and fixtures |  |  | 8,015 |  |  |  | 8,031 |  |
| Leasehold improvements |  |  | 48,133 |  |  |  | 47,962 |  |
| Total property and equipment |  |  | 205,781 |  |  |  | 198,864 |  |
| Less: accumulated depreciation and amortization |  |  | (157,705 | ) |  |  | (154,498 | ) |
| Property and equipment, net |  | $ | 48,076 |  |  | $ | 44,366 |  |

[0001193125-25-258554:notes:53]
[same as prior period, unchanged from 0000950170-25-061827:notes:53]

[0001193125-25-258554:notes:54]
Deferred revenue represents invoiced amounts for deferred subscription and support and other deferred revenue including professional services and training when the revenue recognition criteria have not been met.

[0001193125-25-258554:notes:55]
[same as prior period, unchanged from 0000950170-25-061827:notes:55]

[0001193125-25-258554:notes:56]
[same as prior period, unchanged from 0000950170-25-061827:notes:56]

[0001193125-25-258554:notes:57]
[same as prior period, unchanged from 0000950170-25-061827:notes:57]

[0001193125-25-258554:notes:58]
|  |  | Three Months Ended |  |
|  |  | September 30,2025 |  |  | September 30,2024 |  |
| Balance at beginning of period |  | $ | 9,684 |  |  | $ | 10,942 |  |
| New warranties issued |  |  | 3,025 |  |  |  | 2,487 |  |
| Warranty expenditures |  |  | (3,084 | ) |  |  | (3,190 | ) |
| Balance at end of period |  | $ | 9,625 |  |  | $ | 10,239 |  |

[0001193125-25-258554:notes:59]
[same as prior period, unchanged from 0000950170-25-061827:notes:59]

[0001193125-25-258554:notes:60]
[same as prior period, unchanged from 0000950170-25-061827:notes:60]

[0001193125-25-258554:notes:61]
[same as prior period, unchanged from 0000950170-25-061827:notes:61]


## us-gaap:FairValueDisclosuresTextBlock

[0001193125-25-258554:notes:62]
[same as prior period, unchanged from 0000950170-25-061827:notes:62]

[0001193125-25-258554:notes:63]
[same as prior period, unchanged from 0000950170-25-061827:notes:63]

[0001193125-25-258554:notes:64]
[same as prior period, unchanged from 0000950170-25-061827:notes:64]

[0001193125-25-258554:notes:65]
[same as prior period, unchanged from 0000950170-25-061827:notes:65]

[0001193125-25-258554:notes:66]
[same as prior period, unchanged from 0000950170-25-061827:notes:66]

[0001193125-25-258554:notes:67]
[same as prior period, unchanged from 0000950170-25-061827:notes:67]

[0001193125-25-258554:notes:68]
| September 30, 2025 |  | Level 1 |  |  | Level 2 |  |  | Level 3 |  |  | Total |  |
| Assets |  |  |  |  |  |  |  |  |  |  |  |  |
| Certificates of deposit |  | $ | — |  |  | $ | 2,397 |  |  | $ | — |  |  | $ | 2,397 |  |
| Foreign currency derivatives |  |  | — |  |  |  | 109 |  |  |  | — |  |  |  | 109 |  |
| Total assets measured at fair value |  | $ | — |  |  | $ | 2,506 |  |  | $ | — |  |  | $ | 2,506 |  |
| Liabilities |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency derivatives |  | $ | — |  |  | $ | 74 |  |  | $ | — |  |  | $ | 74 |  |
| Total liabilities measured at fair value |  | $ | — |  |  | $ | 74 |  |  | $ | — |  |  | $ | 74 |  |

[0001193125-25-258554:notes:69]
| June 30, 2025 |  | Level 1 |  |  | Level 2 |  |  | Level 3 |  |  | Total |  |
| Assets |  |  |  |  |  |  |  |  |  |  |  |  |
| Certificates of deposit |  | $ | — |  |  | $ | 6,089 |  |  | $ | — |  |  | $ | 6,089 |  |
| Foreign currency derivatives |  |  | — |  |  |  | 298 |  |  |  | — |  |  |  | 298 |  |
| Total assets measured at fair value |  | $ | — |  |  | $ | 6,387 |  |  | $ | — |  |  | $ | 6,387 |  |
| Liabilities |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency derivatives |  | $ | — |  |  | $ | 11 |  |  | $ | — |  |  | $ | 11 |  |
| Total liabilities measured at fair value |  | $ | — |  |  | $ | 11 |  |  | $ | — |  |  | $ | 11 |  |

[0001193125-25-258554:notes:70]
[same as prior period, unchanged from 0000950170-25-061827:notes:70]

[0001193125-25-258554:notes:71]
[same as prior period, unchanged from 0000950170-25-061827:notes:71]

[0001193125-25-258554:notes:72]
As of September 30, 2025 and June 30, 2025, the Company had investment in certificates of deposit of $2.4 million and $6.1 million, respectively, with maturity of three months at the date of purchase, which are recorded as cash equivalents in the condensed consolidated balance sheets. The Company considers these cash equivalents to be available-for-sale and, as of September 30, 2025 and June 30, 2025, their fair value approximated their amortized cost.

[0001193125-25-258554:notes:73]
As of September 30, 2025 and June 30, 2025, the Company had foreign exchange forward contracts that were not designated as hedging instruments with a total notional principal amount of $65.1 million and $57.2 million, respectively. Changes in the fair value of these foreign exchange forward contracts not designated as hedging instruments are included in “Other expense, net” in the condensed consolidated statements of operations. For the three months ended September 30, 2025 and 2024, the net gains and losses recorded in the condensed consolidated statement of operations were net losses of $1.4 million and net gains of $0.8 million, respectively. As of September 30, 2025 and June 30, 2025, there were no outstanding foreign exchange forward contracts that were designated as hedging instruments. See Note 12, Derivatives and Hedging, for additional information.

[0001193125-25-258554:notes:74]
The fair value of borrowings under the Amended Credit Agreement (as defined in Note 7) is estimated based on valuations provided by alternative pricing sources supported by observable inputs which is considered Level 2. Since the interest rate is variable in the Amended Credit Agreement, the fair value approximates the face amount of the Company’s indebtedness of $201.2 million and $180.0 million as of September 30, 2025 and June 30, 2025, respectively.

[0001193125-25-258554:notes:75]
[same as prior period, unchanged from 0000950170-25-061827:notes:75]

[0001193125-25-258554:notes:76]
As of September 30, 2025 and June 30, 2025, the Company did not have any assets or liabilities that were considered Level 3. 
There were no transfers of assets or liabilities between Level 1, Level 2, or Level 3 during the three months ended September 30, 2025 and 2024. There were no impairments recorded for the three months ended September 30, 2025 and 2024.


## us-gaap:IntangibleAssetsDisclosureTextBlock

[0001193125-25-258554:notes:77]
[same as prior period, unchanged from 0000950170-25-061827:notes:77]

[0001193125-25-258554:notes:78]
[same as prior period, unchanged from 0000950170-25-061827:notes:78]

[0001193125-25-258554:notes:79]
[same as prior period, unchanged from 0000950170-25-061827:notes:79]

[0001193125-25-258554:notes:80]
|  |  | Weighted Average |  |  |  |  |  |  |  |  |  |
|  |  | Remaining Amortization |  | Gross Carrying |  |  | Accumulated |  |  | Net Carrying |  |
|  |  | Period |  | Amount |  |  | Amortization |  |  | Amount |  |
| September 30, 2025 |  |  |  |  |  |  |  |  |  |  |  |
| Developed technology |  | 2.9 years |  | $ | 170,492 |  |  | $ | 166,506 |  |  | $ | 3,986 |  |
| Customer relationships |  | 0.8 years |  |  | 64,825 |  |  |  | 63,468 |  |  |  | 1,357 |  |
| Trade names |  | 0.0 years |  |  | 10,700 |  |  |  | 10,700 |  |  |  | — |  |
| License agreements |  | 1.2 years |  |  | 1,282 |  |  |  | 1,193 |  |  |  | 89 |  |
| Total intangible assets, net* |  |  |  | $ | 247,299 |  |  | $ | 241,867 |  |  | $ | 5,432 |  |
| * The carrying amount of foreign intangible assets are affected by foreign currency translation |  |  |  |  |

[0001193125-25-258554:notes:81]
|  |  | Weighted Average |  |  |  |  |  |  |  |  |  |
|  |  | Remaining Amortization |  | Gross Carrying |  |  | Accumulated |  |  | Net Carrying |  |
|  |  | Period |  | Amount |  |  | Amortization |  |  | Amount |  |
| June 30, 2025 |  |  |  |  |  |  |  |  |  |  |  |
| Developed technology |  | 3.0 years |  | $ | 170,480 |  |  | $ | 165,908 |  |  | $ | 4,572 |  |
| Customer relationships |  | 1.0 years |  |  | 64,824 |  |  |  | 62,961 |  |  |  | 1,863 |  |
| Trade names |  | 0.0 years |  |  | 10,700 |  |  |  | 10,700 |  |  |  | — |  |
| License agreements |  | 1.4 years |  |  | 1,282 |  |  |  | 1,176 |  |  |  | 106 |  |
| Total intangible assets, net* |  |  |  | $ | 247,286 |  |  | $ | 240,745 |  |  | $ | 6,541 |  |
| * The carrying amount of foreign intangible assets are affected by foreign currency translation |  |  |  |  |

[0001193125-25-258554:notes:82]
[same as prior period, unchanged from 0000950170-25-061827:notes:82]

[0001193125-25-258554:notes:83]
|  |  | Three Months Ended |  |
|  |  | September 30,2025 |  |  | September 30,2024 |  |
| Amortization of intangible assets in “Total cost of revenues” |  | $ | 611 |  |  | $ | 624 |  |
| Amortization of intangible assets in “Total operating expenses” |  |  | 500 |  |  |  | 512 |  |
| Total amortization expense |  | $ | 1,111 |  |  | $ | 1,136 |  |

[0001193125-25-258554:notes:84]
[same as prior period, unchanged from 0000950170-25-061827:notes:84]

[0001193125-25-258554:notes:85]
[same as prior period, unchanged from 0000950170-25-061827:notes:85]

[0001193125-25-258554:notes:86]
|  |  | Amount |  |
| For the fiscal year ending June 30: |  |  |  |
| 2026 (the remainder of fiscal 2026) |  | $ | 2,427 |  |
| 2027 |  |  | 1,450 |  |
| 2028 |  |  | 1,287 |  |
| 2029 |  |  | 268 |  |
| Total |  | $ | 5,432 |  |

[0001193125-25-258554:notes:87]
[same as prior period, unchanged from 0000950170-25-061827:notes:87]

[0001193125-25-258554:notes:88]
The Company had goodwill in the amount of $399.6 million as of September 30, 2025 and June 30, 2025.


## us-gaap:DebtDisclosureTextBlock

[0001193125-25-258554:notes:89]
7.
Debt

[0001193125-25-258554:notes:90]
The Company’s debt is comprised of the following (in thousands):

[0001193125-25-258554:notes:91]
|  |  | September 30,2025 |  |  | June 30,2025 |  |
| Current portion of long-term debt: |  |  |  |  |  |  |
| Term Loan |  | $ | 16,250 |  |  | $ | 15,000 |  |
| Revolving Facility |  |  | 25,000 |  |  |  | — |  |
| Less: unamortized debt issuance costs |  |  | (714 | ) |  |  | (729 | ) |
| Current portion of long-term debt |  | $ | 40,536 |  |  | $ | 14,271 |  |
| Long-term debt, less current portion: |  |  |  |  |  |  |
| Term Loan |  | $ | 160,000 |  |  | $ | 165,000 |  |
| Less: unamortized debt issuance costs |  |  | (1,104 | ) |  |  | (1,276 | ) |
| Total long-term debt, less current portion |  |  | 158,896 |  |  |  | 163,724 |  |
| Total debt |  | $ | 199,432 |  |  | $ | 177,995 |  |

[0001193125-25-258554:notes:92]
On June 22, 2023, the Company entered into a Second Amended and Restated Credit Agreement (the “2023 Credit Agreement”), by and among the Company, as borrower, BMO Harris Bank, N.A., as an issuing lender and swingline lender, Bank of America, N.A., JPMorgan Chase Bank, N.A., PNC Bank, National Association, and Wells Fargo Bank, National Association, as issuing lenders, the financial institutions or entities party thereto as lenders, and Bank of Montreal, as administrative agent and collateral agent, which amended and restated the Amended and Restated Credit Agreement, dated August 9, 2019, by and among the Company, as borrower,

[0001193125-25-258554:notes:93]
several banks and other financial institutions as Lenders, BMO Harris Bank N.A., as an issuing lender and swingline lender, Silicon Valley Bank, as an Issuing Lender, and Bank of Montreal, as administrative agent and collateral agent for the Lenders. The 2023 Credit Agreement provides for i) a $200.0 million first lien term loan facility in an aggregate principal amount (the “2023 Term Loan”), ii) a $150.0 million five-year revolving credit facility (the “2023 Revolving Facility”) and, iii) an uncommitted additional incremental loan facility in the principal amount of up to $100.0 million.

[0001193125-25-258554:notes:94]
Borrowings under the 2023 Credit Agreement bear interest, and at the Company’s election, the initial term loan may be made as either a base rate loan or a Secured Overnight Funding Rate (“SOFR”) loan. The applicable margin for base rate loans ranges from 1.00% to 1.75% per annum, and the applicable margin for SOFR loans ranges from 2.00% to 2.75%, in each case based on the Company’s consolidated leverage ratio. All SOFR loans are subject to a floor of 0.00% per annum and spread adjustment of 0.10% per annum. The Company paid other closing fees, arrangement fees, and administration fees associated with the 2023 Credit Agreement.

[0001193125-25-258554:notes:95]
The 2023 Credit Agreement requires the Company to maintain certain minimum financial ratios at the end of each fiscal quarter. The 2023 Credit Agreement also includes covenants and restrictions that limit, among other things, the Company’s ability to incur additional indebtedness, create liens upon any of its property, merge, consolidate or sell all or substantially all of its assets. The 2023 Credit Agreement also includes customary events of default which may result in acceleration of the outstanding balance.

[0001193125-25-258554:notes:96]
On August 14, 2024, the Company entered into an Amendment Number One to the 2023 Credit Agreement (the 2023 Credit Agreement as amended by that certain Amendment Number One, the “Amended Credit Agreement”). Under the Amended Credit Agreement, the Company modified the definition of the consolidated EBITDA for the purposes of evaluating compliance with financial covenants under the 2023 Credit Agreement. The amended definition of consolidated EBITDA modifies the amount and type of add-backs that are allowable to better align with the Company's operations and activities. Further, the Amended Credit Agreement provided a waiver for the Company's compliance with the consolidated interest charge coverage ratio for each of the quarters ended June 30, 2024, September 30, 2024, and December 31, 2024. As of September 30, 2025, the Company was in compliance with the modified terms and financial covenants under the Amended Credit Agreement.

[0001193125-25-258554:notes:97]
Financing costs incurred in connection with obtaining long-term financing are deferred and amortized over the term of the related indebtedness or credit agreement. Amortization of deferred financing costs is included in “Interest expense” in the accompanying condensed consolidated statements of operations was $0.3 million for each of the three months ended September 30, 2025 and 2024, respectively. The interest rate was 6.54% and 7.52% as of September 30, 2025 and 2024, respectively.

[0001193125-25-258554:notes:98]
During the three months ended September 30, 2025, the Company borrowed $25.0 million against the 2023 Revolving Facility which was subsequently paid out in October 2025. The Company had $110.8 million of availability under the 2023 Revolving Facility as of September 30, 2025. During the three months ended September 30, 2025 and 2024, the Company did not make any additional payments against its term loan facility other than the scheduled payments per the terms of the Amended Credit Agreement.

[0001193125-25-258554:notes:99]
The Company had $14.2 million of outstanding letters of credit as of September 30, 2025.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001193125-25-258554:notes:100]
8.
Commitments and Contingencies

[0001193125-25-258554:notes:101]
Purchase Commitments

[0001193125-25-258554:notes:102]
The Company currently has arrangements with contract manufacturers and suppliers for the manufacture of its products. Those arrangements allow the contract manufacturers to procure long lead-time component inventory based upon a rolling production forecast provided by the Company. The Company is obligated to purchase long lead-time component inventory that its contract manufacturer procures in accordance with the forecast, unless the Company gives notice of order cancellation outside of applicable component lead-times. As of September 30, 2025, the Company had commitments to purchase $48.8 million of inventory.

[0001193125-25-258554:notes:103]
Legal Proceedings

[0001193125-25-258554:notes:104]
The Company may from time to time be party to litigation arising in the course of its business, including, without limitation, allegations relating to commercial transactions, business relationships, or intellectual property rights. Such claims, even if not meritorious, could result in the expenditure of significant financial and managerial resources. Litigation in general, and intellectual property litigation in particular, can be expensive and disruptive to normal business operations. Moreover, the results of legal proceedings are difficult to predict.

[0001193125-25-258554:notes:105]
In accordance with applicable accounting guidance, the Company records accruals for certain of its outstanding legal proceedings, investigations or claims when it is probable that a liability will be incurred, and the amount of loss can be reasonably estimated. The Company evaluates, at least on a quarterly basis, developments in legal proceedings, investigations or claims that could affect the amount of any accrual, as well as any developments that would result in a loss contingency to become both probable and reasonably estimable. When a loss contingency is not both probable and reasonably estimable, the Company does not record a loss accrual. However, if the loss (or an additional loss in excess of any prior accrual) is at least reasonably possible and material, then the Company would disclose an estimate of the possible loss or range of loss, if such estimate can be made, or disclose that an estimate cannot be made. The assessment of whether a loss is probable or a reasonable possibility, and whether the loss or a range of loss is estimable, involves a series of complex

[0001193125-25-258554:notes:106]
judgments about future events. Even if a loss is reasonably possible, the Company may not be able to estimate a range of possible loss, particularly where (i) the damages sought are substantial or indeterminate, (ii) the proceedings are in the early stages, or (iii) the matters involve novel or unsettled legal theories or a large number of parties. In such cases, there is considerable uncertainty regarding the ultimate resolution of such matters, including the amount of any possible loss, fine or penalty. However, an adverse resolution of one or more of such matters could have a material adverse effect on the Company's results of operations in a particular quarter or fiscal year.

[0001193125-25-258554:notes:107]
SNMP Research, Inc. and SNMP Research International, Inc. v. Broadcom Inc., Brocade Communications Systems LLC, and Extreme Networks, Inc.

[0001193125-25-258554:notes:108]
On October 26, 2020, SNMP Research, Inc. and SNMP Research International, Inc. (collectively, “SNMP”) filed a lawsuit against the Company in the Eastern District of Tennessee for copyright infringement, alleging that the Company was not properly licensed to use its software. SNMP sought actual damages and profits attributed to the infringement, as well as equitable relief. On March 2, 2023, SNMP filed an amended complaint adding claims against Extreme on additional products for copyright infringement, breach of contract, and fraud. The parties reached a settlement, and on July 29, 2025, the case was dismissed with prejudice.

[0001193125-25-258554:notes:109]
Mala Technologies Ltd. v. Extreme Networks GmbH, Extreme Networks Ireland Ops Ltd., and Extreme Networks, Inc.

[0001193125-25-258554:notes:110]
On April 15, 2021, Mala Technologies Ltd. (“Mala”) filed a patent infringement lawsuit against the Company and its Irish and German subsidiaries in the District Court in Dusseldorf, Germany. The lawsuit alleges indirect infringement of the German portion of a patent (“EP ‘498”) based on the offer and sale in Germany of certain network switches equipped with the ExtremeXOS operating system. Mala is seeking injunctive relief, accounting, and an unspecified declaration of liability for damages and costs of the lawsuit. On December 20, 2022, the trial court ruled that the Company did not infringe the EP ‘498 patent and dismissed Mala’s complaint entirely. Mala has filed an appeal. On December 9, 2024, the Higher Regional Court stayed the matter until the nullity action has been finally decided.

[0001193125-25-258554:notes:111]
The Company filed a nullity complaint against EP ‘498 with the German Federal Patent Court on September 24, 2021. The German Federal Patent Court issued a decision finding that the patent was invalid on November 20, 2024. Mala appealed the decision on March 3, 2025, and filed its Grounds of Appeal on June 5, 2025. The Company filed its response to the Grounds of Appeal on October 6, 2025.

[0001193125-25-258554:notes:112]
Steamfitters Local 449 Pension & Retirement Security Funds v. Extreme Networks, Inc., et al.

[0001193125-25-258554:notes:113]
On August 13, 2024, a putative securities class action (the “Class Action”) was filed in the United States District Court for the Northern District of California captioned Steamfitters Local 449 Pension & Retirement Security Funds v. Extreme Networks, Inc., et al., Case No. 5:24-cv-05102-TLT, naming the Company and certain of its current and former executive officers as defendants. The lawsuit is purportedly brought on behalf of purchasers of Extreme Networks securities between July 27, 2022 and January 30, 2024 (the “Class Period”). The complaint alleges claims under Sections 10(b) and 20(a) of the Securities Exchange Act of 1934, and Rule 10b-5 promulgated thereunder, based on allegedly false and misleading statements about the Company's business and prospects during the Class Period. The lawsuit seeks unspecified damages. On December 30, 2024, the Court selected Oklahoma Firefighters Pension and Retirement System, Oklahoma Police Pension and Retirement System, Oakland County Voluntary Employees’ Beneficiary Association, Oakland County Employees’ Retirement System as the lead plaintiffs. The Company's Motion to Dismiss was granted on August 15, 2025, but the plaintiffs were granted leave to file a second amended complaint. Plaintiffs filed a second amended complaint on September 9, 2025. The Company filed a motion to dismiss the second amended complaint on October 3, 2025.

[0001193125-25-258554:notes:114]
On February 27, 2025, a shareholder derivative case was filed in the United States District Court for the Northern District of California captioned Turner v. Brown et al., Case No. 3:25-cv-02101. On March 6, 2025, a shareholder derivative case was filed in the United States District Court for the Northern District of California captioned Hemani v. Meyercord et al., Case No. 3:25-cv-02318-AGT. On March 25, 2025, a shareholder derivative case was filed in the United States District Court for the Eastern District of North Carolina captioned Miller v. Meyercord et al., Case No. 5:25-cv-00161. Each of these cases (collectively, the “Derivative Cases”) names current and former officers, directors, and employees of the Company as defendants, and seeks recovery on behalf of the Company based on substantially the same allegations as the Class Action. These cases remain stayed pending a decision on the motion to dismiss the second amended complaint in the Class Action.

[0001193125-25-258554:notes:115]
Indemnification Obligations

[0001193125-25-258554:notes:116]
Subject to certain limitations, the Company may be obligated to indemnify its current and former directors, officers, and employees. These obligations arise under the terms of its certificate of incorporation, its bylaws, applicable contracts, and applicable law. The obligation to indemnify, where applicable, generally means that the Company is required to pay or reimburse, and in certain circumstances the Company has paid or reimbursed, the individuals’ reasonable legal expenses and possible damages and other liabilities incurred in connection with certain legal matters. The Company also procures Directors and Officers liability insurance to help cover its defense and/or indemnification costs, although its ability to recover such costs through insurance is uncertain. While it is not possible to estimate the maximum potential amount that could be owed under these governing documents and agreements due to the Company’s

[0001193125-25-258554:notes:117]
limited history with prior indemnification claims, indemnification (including defense) costs could, in the future, have a material adverse effect on the Company’s consolidated financial position, results of operations and cash flows.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001193125-25-258554:notes:118]
[same as prior period, unchanged from 0000950170-25-061827:notes:117]

[0001193125-25-258554:notes:119]
[same as prior period, unchanged from 0000950170-25-061827:notes:118]

[0001193125-25-258554:notes:120]
The Compensation Committee of the Board unanimously approved an amendment to the Extreme Networks, Inc. Amended and Restated 2013 Equity Incentive Plan (the “2013 Plan”) on September 14, 2025 to increase the maximum number of available shares by 6.8 million shares, which is pending ratification by the stockholders of the Company at the annual meeting of stockholders to be held on November 12, 2025.

[0001193125-25-258554:notes:121]
[same as prior period, unchanged from 0000950170-25-061827:notes:120]

[0001193125-25-258554:notes:122]
On February 18, 2025, the Company announced that the Board had authorized management to repurchase up to $200.0 million of shares of the Company's common stock over a three-year period, commencing July 1, 2025 (the “2025 Repurchase Program”). Purchases may be made from time to time in the open market or pursuant to a 10b5-1 plan.

[0001193125-25-258554:notes:123]
During the three months ended September 30, 2025, the Company repurchased a total of 577,281 shares of its common stock on the open market at a total cost of $12.0 million with an average price of $20.79 per share. During the three months ended September 30, 2024, the Company did not repurchase any shares of its common stock. As of September 30, 2025, approximately $188.0 million remains available for share repurchases under the 2025 Repurchase Program.

[0001193125-25-258554:notes:124]
As a provision of the Inflation Reduction Act enacted in the U.S., the Company is subject to an excise tax on corporate stock repurchases, which is assessed as one percent of the fair market value of net corporate stock repurchases after December 31, 2022. The Company had no excise tax liability for fiscal 2025 and expects the impact of the excise tax on net corporate stock repurchases will not be material for fiscal 2026.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001193125-25-258554:notes:125]
[same as prior period, unchanged from 0000950170-25-061827:notes:124]

[0001193125-25-258554:notes:126]
[same as prior period, unchanged from 0000950170-25-061827:notes:125]

[0001193125-25-258554:notes:127]
[same as prior period, unchanged from 0000950170-25-061827:notes:126]

[0001193125-25-258554:notes:128]
|  |  | September 30,2025 |  |  | June 30,2025 |  |
| 2013 Equity Incentive Plan shares available for grant |  |  | 6,276 |  |  |  | 10,935 |  |
| Employee stock options and awards outstanding |  |  | 9,060 |  |  |  | 7,566 |  |
| 2014 Employee Stock Purchase Plan |  |  | 5,418 |  |  |  | 5,952 |  |
| Total shares reserved for issuance |  |  | 20,754 |  |  |  | 24,453 |  |

[0001193125-25-258554:notes:129]
[same as prior period, unchanged from 0000950170-25-061827:notes:128]

[0001193125-25-258554:notes:130]
[same as prior period, unchanged from 0000950170-25-061827:notes:129]

[0001193125-25-258554:notes:131]
|  |  | Three Months Ended |  |
|  |  | September 30,2025 |  |  | September 30,2024 |  |
| Cost of product revenues |  | $ | 752 |  |  | $ | 618 |  |
| Cost of subscription and support revenues |  |  | 727 |  |  |  | 689 |  |
| Research and development |  |  | 4,447 |  |  |  | 4,213 |  |
| Sales and marketing |  |  | 7,513 |  |  |  | 6,882 |  |
| General and administrative |  |  | 8,341 |  |  |  | 7,365 |  |
| Total share-based compensation expense |  | $ | 21,780 |  |  | $ | 19,767 |  |

[0001193125-25-258554:notes:132]
[same as prior period, unchanged from 0000950170-25-061827:notes:131]

[0001193125-25-258554:notes:133]
The following table summarizes stock option activity for the three months ended September 30, 2025 (in thousands, except per share amount and contractual term):

[0001193125-25-258554:notes:134]
|  |  | Number of Shares |  |  | Weighted-Average Exercise Price Per Share |  |  | Weighted-Average Remaining Contractual Term (years) |  |  | Aggregate Intrinsic Value |  |
| Options outstanding at June 30, 2025 |  |  | 496 |  |  | $ | 6.70 |  |  |  | 1.16 |  |  | $ | 5,580 |  |
| Granted |  |  | — |  |  |  | — |  |  |  |  |  |  |  |
| Exercised |  |  | (71 | ) |  |  | 6.70 |  |  |  |  |  |  |  |
| Canceled |  |  | — |  |  |  | — |  |  |  |  |  |  |  |
| Options outstanding at September 30, 2025 |  |  | 425 |  |  | $ | 6.70 |  |  |  | 0.91 |  |  | $ | 5,923 |  |
| Vested and expected to vest at September 30, 2025 |  |  | 425 |  |  | $ | 6.70 |  |  |  | 0.91 |  |  | $ | 5,923 |  |
| Exercisable at September 30, 2025 |  |  | 425 |  |  | $ | 6.70 |  |  |  | 0.91 |  |  | $ | 5,923 |  |

[0001193125-25-258554:notes:135]
There were no stock options granted during the three months ended September 30, 2025 and 2024.

[0001193125-25-258554:notes:136]
[same as prior period, unchanged from 0000950170-25-061827:notes:135]

[0001193125-25-258554:notes:137]
[same as prior period, unchanged from 0000950170-25-061827:notes:136]

[0001193125-25-258554:notes:138]
The following table summarizes stock award activity for the three months ended September 30, 2025 (in thousands, except grant date fair value):

[0001193125-25-258554:notes:139]
|  |  | Number of Shares |  |  | Weighted- Average Grant Date Fair Value |  |  | Aggregate Fair Value |  |
| Non-vested stock awards outstanding at June 30, 2025 |  |  | 7,070 |  |  | $ | 19.53 |  |  |  |  |
| Granted |  |  | 4,129 |  |  |  | 19.57 |  |  |  |  |
| Released |  |  | (2,520 | ) |  |  | 18.85 |  |  |  |  |
| Canceled |  |  | (44 | ) |  |  | 19.56 |  |  |  |  |
| Non-vested stock awards outstanding at September 30, 2025 |  |  | 8,635 |  |  | $ | 19.73 |  |  |  |  |
| Stock awards expected to vest at September 30, 2025 |  |  | 8,635 |  |  | $ | 19.73 |  |  | $ | 170,378 |  |

[0001193125-25-258554:notes:140]
The RSUs granted under the 2013 Plan vest over a period of time, generally one to three years, and are subject to participant's continued service to the Company.

[0001193125-25-258554:notes:141]
During the three months ended September 30, 2025, the Company granted 0.8 million stock awards with vesting based on market conditions (“MSU”) to certain of the Company’s employees. The MSUs vest based on the Company’s total shareholder return (“TSR”) relative to the TSR of the Russell 2000 Index (“Index”). The MSU award represents the right to receive a target number of shares of common stock of up to 150% of the original grant. The MSUs vest based on the Company’s TSR relative to the TSR of the Index over performance periods of three years from the grant date, subject to the grantees’ continued service through the certification of performance.

[0001193125-25-258554:notes:142]
The grant date fair value of each MSU was determined using the Monte Carlo simulation model. The weighted-average grant-date fair value of the TSR MSUs granted during the three months ended September 30, 2025 and 2024 was $22.23 per share and $17.22 per share, respectively. The following assumptions used to determine the grant-date fair values of the MSU during the following periods:

[0001193125-25-258554:notes:143]
|  |  | Three Months Ended |  |
|  |  | September 30,2025 |  |  | September 30,2024 |  |
| Expected term |  | 3.0 years |  |  | 3.0 years |  |
| Risk-free interest rate |  |  | 3.70 | % |  |  | 3.86 | % |
| Volatility |  |  | 45 | % |  |  | 48 | % |
| Dividend yield |  |  | — | % |  |  | — | % |

[0001193125-25-258554:notes:144]
As of September 30, 2025, there was $137.3 million in unrecognized compensation cost related to non-vested stock awards, including performance and market condition awards. This cost is expected to be recognized over a weighted average period of 1.95 years.

[0001193125-25-258554:notes:145]
[same as prior period, unchanged from 0000950170-25-061827:notes:149]

[0001193125-25-258554:notes:146]
There were approximately 0.5 million shares issued under the ESPP during each of the three months ended September 30, 2025 and 2024, respectively. The following assumptions were used to determine the grant-date fair values of the ESPP shares during the following periods:

[0001193125-25-258554:notes:147]
|  |  | Employee Stock Purchase Plan |  |
|  |  | Three Months Ended |  |
|  |  | September 30,2025 |  |  | September 30,2024 |  |
| Expected term |  | 0.5 years |  |  | 0.5 years |  |
| Risk-free interest rate |  |  | 4.12 | % |  |  | 5.04 | % |
| Volatility |  |  | 50 | % |  |  | 36 | % |
| Dividend yield |  |  | — | % |  |  | — | % |

[0001193125-25-258554:notes:148]
The weighted-average grant-date fair value of shares under the ESPP during the three months ended September 30, 2025 and 2024 was $5.83 and $3.74 per share, respectively.


## us-gaap:ScheduleOfShareBasedPaymentAwardEmployeeStockPurchasePlanValuationAssumptionsTableTextBlock

[0001193125-25-258554:notes:149]
The following assumptions used to determine the grant-date fair values of the MSU during the following periods:

[0001193125-25-258554:notes:150]
The following assumptions were used to determine the grant-date fair values of the ESPP shares during the following periods:


## us-gaap:SegmentReportingDisclosureTextBlock

[0001193125-25-258554:notes:151]
[same as prior period, unchanged from 0000950170-25-061827:notes:154]

[0001193125-25-258554:notes:152]
The Company has one reportable segment, the development, marketing, and sale of network infrastructure equipment and related software. The Company conducts business globally and is managed geographically. Revenues are attributed to a geographical area. The Company operates in three geographical areas: Americas, EMEA, and APAC. See Note 3, Revenues, for additional information on the Company's revenues by geographic region.

[0001193125-25-258554:notes:153]
Measure of segment profit or loss:

[0001193125-25-258554:notes:154]
The Company’s chief operating decision maker (“CODM”), who is its Chief Executive Officer, reviews financial information presented on a consolidated basis and uses consolidated non-GAAP net income to measure segment profit or loss and to monitor period-over-period results to decide where to allocate and invest additional resources within the business.

[0001193125-25-258554:notes:155]
Consolidated non-GAAP net income is exclusive of certain items that are non-recurring or not consistent with the Company's operations. The CODM reviews and utilizes functional expenses (costs of revenue, research and development, sales and marketing, and general and administrative) at the consolidated level to manage and assess the Company's operations. Other segment items included in consolidated non-GAAP net income are interest income, interest expense, other expense, net, and the provision for income taxes, which are reflected in the condensed consolidated statements of operations.

[0001193125-25-258554:notes:156]
A reconciliation of consolidated GAAP net income (loss) to consolidated non-GAAP net income is shown in the table below:

[0001193125-25-258554:notes:157]
|  |  | Three Months Ended |  |
|  |  | September 30,2025 |  |  | September 30,2024 |  |
| GAAP net income (loss) |  | $ | 5,611 |  |  | $ | (10,504 | ) |
| Adjustments: |  |  |  |  |  |  |
| Share-based compensation expense |  |  | 21,780 |  |  |  | 19,767 |  |
| Restructuring and related charges |  |  | 371 |  |  |  | 1,277 |  |
| Litigation charges(1) |  |  | 1,937 |  |  |  | 10,715 |  |
| System transition costs(2) |  |  | 4,925 |  |  |  | 5,345 |  |
| Amortization of intangibles |  |  | 1,093 |  |  |  | 1,118 |  |
| Debt refinancing charges, Other expense |  |  | — |  |  |  | 79 |  |
| Tax effect of non-GAAP adjustments |  |  | (5,573 | ) |  |  | (5,398 | ) |
| Total adjustments to GAAP net income (loss) |  | $ | 24,533 |  |  | $ | 32,903 |  |
| Non-GAAP net income |  | $ | 30,144 |  |  | $ | 22,399 |  |

[0001193125-25-258554:notes:158]
(1)Litigation charges consist of estimated settlement and related legal expenses for non-recurring litigation offset by any proceeds received or expected to be received from insurance.

[0001193125-25-258554:notes:159]
(2)System transition costs consist of costs related to direct and incremental costs incurred in connection with our multi-phase transition of our customer relationship management solution, our configure, price, quote solution and our enterprise resource planning tools that were not capitalizable.

[0001193125-25-258554:notes:160]
Measure of segment assets:

[0001193125-25-258554:notes:161]
The measure of segment assets that is reviewed by the CODM is reported within the condensed consolidated balance sheets as “Total assets.” Depreciation expense recorded for the three months ended September 30, 2025 and 2024 was $3.7 million, and $3.9 million, respectively. Total expenditures for additions to property, plant and equipment recorded for each of the three months ended September 30, 2025 and 2024 was $6.9 million.

[0001193125-25-258554:notes:162]
[same as prior period, unchanged from 0000950170-25-061827:notes:157]

[0001193125-25-258554:notes:163]
|  |  | September 30,2025 |  |  | June 30,2025 |  |
| Segment long-lived assets: |  |  |  |  |  |  |
| Americas |  | $ | 178,693 |  |  | $ | 167,499 |  |
| EMEA |  |  | 38,900 |  |  |  | 40,299 |  |
| APAC |  |  | 9,865 |  |  |  | 10,550 |  |
| Total segment long-lived assets |  | $ | 227,458 |  |  | $ | 218,348 |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001193125-25-258554:notes:164]
[same as prior period, unchanged from 0000950170-25-061827:notes:159]

[0001193125-25-258554:notes:165]
[same as prior period, unchanged from 0000950170-25-061827:notes:160]

[0001193125-25-258554:notes:166]
The Company uses derivative financial instruments to manage exposures to foreign currency risk that may or may not be designated as hedging instruments. The Company’s objective for holding derivatives is to use the most effective methods to minimize the impact of these exposures. The Company does not enter into derivatives for speculative or trading purposes. The Company enters into foreign exchange forward contracts to attempt to mitigate the effect of gains and losses generated by foreign currency transactions related to certain operating expenses and remeasurement of certain assets and liabilities denominated in foreign currencies.

[0001193125-25-258554:notes:167]
For foreign exchange forward contracts not designated as hedging instruments, the fair value of the Company’s derivatives in a gain position are recorded in “Prepaid expenses and other current assets” and derivatives in a loss position are recorded in “Other accrued liabilities” in the accompanying condensed consolidated balance sheets. Changes in the fair value of derivatives are recorded in “Other expense, net” in the accompanying condensed consolidated statements of operations. As of September 30, 2025 and June 30, 2025, foreign exchange forward contracts not designated as hedging instruments had a total notional principal amount of $65.1 million and $57.2 million, respectively. For the three months ended September 30, 2025 and 2024, the net gains and losses recorded in the condensed consolidated statement of operations from these contracts were net losses of $1.4 million and net gains of $0.8 million, respectively. Changes in the fair value of these foreign exchange forward contracts are offset largely by remeasurement of the underlying assets and liabilities.

[0001193125-25-258554:notes:168]
There were no foreign exchange forward contracts that were designated as hedging instruments as of September 30, 2025 or June 30, 2025.
For the three months ended September 30, 2025 and 2024, the Company recognized foreign currency transaction net gains of $0.9 million and foreign currency transaction net losses of $1.4 million, respectively, related to the change in fair value of foreign currency denominated assets and liabilities.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001193125-25-258554:notes:169]
[same as prior period, unchanged from 0000950170-25-061827:notes:165]

[0001193125-25-258554:notes:170]
The Company recorded restructuring charges of $0.4 million and $1.3 million during the three months ended September 30, 2025 and 2024, respectively. These charges primarily included severance and benefits costs and professional fees related to the restructuring plans executed in prior years.

[0001193125-25-258554:notes:171]
During the third quarter of fiscal 2024, the Company executed a global reduction-in-force plan targeted towards the reorganization of the Company's research and development and sales and marketing functions to align the Company's workforce with its strategic priorities and to focus on specific geographies and industry segments with higher growth opportunities (the “Q3 2024 Plan”). During the three months ended September 30, 2025 and 2024, the Company recorded restructuring charges of $0.4 million and $0.7 million related to the Q3 2024 Plan, which primarily consisted of additions to severance and benefits expenses, legal and consulting fees.

[0001193125-25-258554:notes:172]
During the second quarter of fiscal 2024, the Company executed a global reduction-in-force plan to rebalance its workforce to create greater efficiency and improve execution, in alignment with the Company's business and strategic priorities, while reducing its ongoing operating expenses to address reduced revenue and macro-economic conditions (the “Q2 2024 Plan”). During the three months ended September 30, 2024, the Company recorded restructuring charges of $0.5 million related to the Q2 2024 Plan, which primarily consisted of severance and benefits expenses, legal and consulting fees.

[0001193125-25-258554:notes:173]
Through September 30, 2025, the Company has incurred $28.7 million in restructuring charges under the Q2 2024 Plan and Q3 2024 Plan which primarily related to severance and benefits costs. The Company expects to complete these ongoing restructuring plans by the end of calendar year 2025 and does not expect to incur any significant additional charges.

[0001193125-25-258554:notes:174]
During the third quarter of fiscal 2023, the Company initiated a restructuring plan to transform its business infrastructure and reduce its facilities footprint and the facilities related charges (the “2023 Plan”). As part of this project, the Company moved engineering labs from its San Jose, California location to its Salem, New Hampshire location. This move is expected to help reduce the cost of operating the Company's labs. During the three months ended September 30, 2024, the Company recorded restructuring charges of approximately $0.1 million related to the 2023 Plan. The Company expects to complete the 2023 Plan by the end of fiscal year 2026 and expects the charges related to the completion to be immaterial.

[0001193125-25-258554:notes:175]
Restructuring liabilities are recorded in “Other accrued liabilities” in the accompanying condensed consolidated balance sheets. As of September 30, 2025 and June 30, 2025, the restructuring liability was $0.6 million and $0.7 million, respectively related to these restructuring plans.

[0001193125-25-258554:notes:176]
[same as prior period, unchanged from 0000950170-25-061827:notes:174]

[0001193125-25-258554:notes:177]
|  |  | Three Months Ended |  |
|  |  | September 30,2025 |  |  | September 30,2024 |  |
| Balance at beginning of period |  | $ | 693 |  |  | $ | 11,469 |  |
| Period charges |  |  | 437 |  |  |  | 1,573 |  |
| Period reversals |  |  | (67 | ) |  |  | (296 | ) |
| Period payments |  |  | (445 | ) |  |  | (8,353 | ) |
| Balance at end of period |  | $ | 618 |  |  | $ | 4,393 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0001193125-25-258554:notes:178]
[same as prior period, unchanged from 0000950170-25-061827:notes:176]

[0001193125-25-258554:notes:179]
For the three months ended September 30, 2025 and 2024, the Company recorded an income tax provision of $2.7 million and $1.5 million, respectively.

[0001193125-25-258554:notes:180]
The income tax provisions for the three months ended September 30, 2025 and 2024, consisted of (1) taxes on the income of the Company’s foreign subsidiaries, (2) state taxes in jurisdictions where the Company has no remaining state net operating losses (“NOLs”), (3) foreign withholding taxes, and (4) tax expense associated with the establishment of a U.S. deferred tax liability for amortizable goodwill resulting from the acquisition of Enterasys Networks, Inc., the wireless local area network business from Zebra Technologies Corporation, the Campus Fabric Business from Avaya and the Data Center Business from Brocade. The interim income tax provisions for the three months ended September 30, 2025 and 2024 were calculated using the discrete effective tax rate method as

[0001193125-25-258554:notes:181]
allowed by ASC 740-270-30-18, Income Taxes – Interim Reporting. The discrete method is applied when the application of the estimated annual effective tax rate is impractical because it is not possible to reliably estimate the annual effective tax rate. The discrete method treats the year-to-date period as if it was the annual period and determines the income tax expense or benefit on that basis. The Company believes that, at this time, the use of this discrete method is more appropriate than the annual effective tax rate method as (i) the estimated annual effective tax rate method is not reliable due to the high degree of uncertainty in estimating annual pretax earnings on a jurisdictional basis and (ii) the Company’s ongoing assessment that the recoverability of certain U.S. and Irish deferred tax assets is not more likely than not.

[0001193125-25-258554:notes:182]
[same as prior period, unchanged from 0000950170-25-061827:notes:179]

[0001193125-25-258554:notes:183]
The Company had $18.1 million of unrecognized tax benefits as of September 30, 2025. If fully recognized in the future, $0.1 million would impact the effective tax rate and $18.0 million would result in adjustments to deferred tax assets and corresponding adjustments to the valuation allowance with no impact to the effective tax rate. The Company does not anticipate any events to occur during the next twelve months that would materially reduce the unrealized tax benefit as currently stated in the Company’s condensed consolidated balance sheets.

[0001193125-25-258554:notes:184]
[same as prior period, unchanged from 0000950170-25-061827:notes:181]

[0001193125-25-258554:notes:185]
In general, the Company’s U.S. federal income tax returns are subject to examination by tax authorities for fiscal years 2004 forward due to NOLs and the Company’s state income tax returns are subject to examination for fiscal years 2005 and forward due to NOLs. In general, the Company’s Irish tax returns are subject to examination by tax authorities for fiscal years 2022 and forward.

[0001193125-25-258554:notes:186]
The Company is currently under examination in the U.S. by the Internal Revenue Service for the tax year ended June 30, 2023. Management believes that adequate provision has been made in the financial statements for any potential assessments that may result from tax examinations and other tax-related matters for all open tax years.

[0001193125-25-258554:notes:187]
On July 4,2025, federal legislation commonly referred to as the One Big Beautiful Bill Act (“OBBBA”) was enacted in the U.S. The OBBBA includes numerous changes to existing tax law including provisions providing current deductibility of domestic research and development costs, modifications to the limitation on deductibility of business interest expense and modifications to the international tax framework. This legislation has multiple effective dates, with certain provisions effective for the Company's fiscal year ended June 30, 2026 and others for the Company's fiscal year ended June 30, 2027. ASC 740, Income Taxes, requires the effects of changes in tax rates and laws to be recognized in the period in which the legislation is enacted. The effects of the new legislation are reflected in the condensed consolidated financial statements for the period ended September 30, 2025.


## us-gaap:EarningsPerShareTextBlock

[0001193125-25-258554:notes:188]
[same as prior period, unchanged from 0000950170-25-061827:notes:183]

[0001193125-25-258554:notes:189]
[same as prior period, unchanged from 0000950170-25-061827:notes:184]

[0001193125-25-258554:notes:190]
[same as prior period, unchanged from 0000950170-25-061827:notes:185]

[0001193125-25-258554:notes:191]
|  |  | Three Months Ended |  |
|  |  | September 30,2025 |  |  | September 30,2024 |  |
| Net income (loss) |  | $ | 5,611 |  |  | $ | (10,504 | ) |
| Weighted-average shares used in per share calculation – basic |  |  | 132,973 |  |  |  | 131,176 |  |
| Options to purchase common stock |  |  | 289 |  |  |  | — |  |
| Restricted stock units |  |  | 1,736 |  |  |  | — |  |
| Employee Stock Purchase Plan shares |  |  | 73 |  |  |  | — |  |
| Weighted-average shares used in per share calculation – diluted |  |  | 135,071 |  |  |  | 131,176 |  |
| Net income (loss) per share – basic and diluted |  |  |  |  |  |  |
| Net income (loss) per share – basic |  | $ | 0.04 |  |  | $ | (0.08 | ) |
| Net income (loss) per share – diluted |  | $ | 0.04 |  |  | $ | (0.08 | ) |

[0001193125-25-258554:notes:192]
[same as prior period, unchanged from 0000950170-25-061827:notes:187]

[0001193125-25-258554:notes:193]
|  |  | Three Months Ended |  |
|  |  | September 30,2025 |  |  | September 30,2024 |  |
| Options to purchase common stock |  |  | — |  |  |  | 1,063 |  |
| Restricted stock units |  |  | 651 |  |  |  | 5,423 |  |
| Employee Stock Purchase Plan shares |  |  | 289 |  |  |  | 376 |  |
| Total shares excluded |  |  | 940 |  |  |  | 6,862 |  |


## ecd:MtrlTermsOfTrdArrTextBlock

[0001193125-25-258554:notes:194]
On August 28, 2025, Edward Meyercord, the Company's President and Chief Executive Officer, adopted a Rule 10b5-1 trading arrangement that is intended to satisfy the affirmative defense conditions of Rule 10b5-1(c) for the sale of up to 900,000 shares of the Company's common stock until December 31, 2026.

[0001193125-25-258554:notes:195]
On September 2, 2025, Rajendra K. Khanna, a member of the Company's board of directors, adopted a Rule 10b5-1 trading arrangement that is intended to satisfy the affirmative defense conditions of Rule 10b5-1(c) for the sale of up to 35,000 shares of the Company's common stock until October 30, 2026.

[0001193125-25-258554:notes:196]
On September 4, 2025, Katayoun ("Katy") Motiey, the Company's Chief Legal, Administrative & Sustainability Officer, adopted a Rule 10b5-1 trading arrangement that is intended to satisfy the affirmative defense conditions of Rule 10b5-1(c) for the sale of up to 45,161 shares of the Company's common stock until January 5, 2027.
