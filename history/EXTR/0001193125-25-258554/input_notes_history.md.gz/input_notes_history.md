# EXTR note change history — 0000950170-25-061827 → 0001193125-25-258554


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2025-10-30):
[0001193125-25-258554:note_history:1]
The Company currently has arrangements with contract manufacturers and suppliers for the manufacture of its products. Those arrangements allow the contract manufacturers to procure long lead-time component inventory based upon a rolling production forecast provided by the Company. The Company is obligated to purchase long lead-time component inventory that its contract manufacturer procures in accordance with the forecast, unless the Company gives notice of order cancellation outside of applicable component lead-times. As of September 30, 2025, the Company had commitments to purchase $48.8 million of inventory.
  (was, 2025-05-01, similarity 0.9885):
[0000950170-25-061827:note_history:1]
The Company currently has arrangements with contract manufacturers and suppliers for the manufacture of its products. Those arrangements allow the contract manufacturers to procure long lead-time component inventory based upon a rolling production forecast provided by the Company. The Company is obligated to purchase long lead-time component inventory that its contract manufacturer procures in accordance with the forecast, unless the Company gives notice of order cancellation outside of applicable component lead-times. As of March 31, 2025, the Company had commitments to purchase $36.0 million of inventory.

- changed (2025-10-30):
[0001193125-25-258554:note_history:2]
In accordance with applicable accounting guidance, the Company records accruals for certain of its outstanding legal proceedings, investigations or claims when it is probable that a liability will be incurred, and the amount of loss can be reasonably estimated. The Company evaluates, at least on a quarterly basis, developments in legal proceedings, investigations or claims that could affect the amount of any accrual, as well as any developments that would result in a loss contingency to become both probable and reasonably estimable. When a loss contingency is not both probable and reasonably estimable, the Company does not record a loss accrual. However, if the loss (or an additional loss in excess of any prior accrual) is at least reasonably possible and material, then the Company would disclose an estimate of the possible loss or range of loss, if such estimate can be made, or disclose that an estimate cannot be made. The assessment of whether a loss is probable or a reasonable possibility, and whether the loss or a range of loss is estimable, involves a series of complex
  (was, 2025-05-01, similarity 0.6965):
[0000950170-25-061827:note_history:2]
In accordance with applicable accounting guidance, the Company records accruals for certain of its outstanding legal proceedings, investigations or claims when it is probable that a liability will be incurred, and the amount of loss can be reasonably estimated. The Company evaluates, at least on a quarterly basis, developments in legal proceedings, investigations or claims that could affect the amount of any accrual, as well as any developments that would result in a loss contingency to become both probable and reasonably estimable. When a loss contingency is not both probable and reasonably estimable, the Company does not record a loss accrual. However, if the loss (or an additional loss in excess of any prior accrual) is at least reasonably possible and material, then the Company would disclose an estimate of the possible loss or range of loss, if such estimate can be made, or disclose that an estimate cannot be made. The assessment of whether a loss is probable or a reasonable possibility, and whether the loss or a range of loss is estimable, involves a series of complex judgments about future events. Even if a loss is reasonably possible, the Company may not be able to estimate a range of possible loss, particularly where (i) the damages sought are substantial or indeterminate, (ii) the proceedings are in the early stages, or (iii) the matters involve novel or unsettled legal theories or a large number of parties. In such cases, there is considerable uncertainty regarding the ultimate resolution of such matters, including the amount of any possible loss, fine or penalty. However, an adverse resolution of one or more of such matters could have a material adverse effect on the Company's results of operations in a particular quarter or fiscal year. As of March 31, 2025, the total estimated litigation expense accrual included in the “Other accrued liabilities” in the condensed consolidated balance sheets was $28.5 million for various ongoing litigation matters with probable losses that can be reasonably estimated.

- added (2025-10-30):
[0001193125-25-258554:note_history:3]
judgments about future events. Even if a loss is reasonably possible, the Company may not be able to estimate a range of possible loss, particularly where (i) the damages sought are substantial or indeterminate, (ii) the proceedings are in the early stages, or (iii) the matters involve novel or unsettled legal theories or a large number of parties. In such cases, there is considerable uncertainty regarding the ultimate resolution of such matters, including the amount of any possible loss, fine or penalty. However, an adverse resolution of one or more of such matters could have a material adverse effect on the Company's results of operations in a particular quarter or fiscal year.

- changed (2025-10-30):
[0001193125-25-258554:note_history:4]
On October 26, 2020, SNMP Research, Inc. and SNMP Research International, Inc. (collectively, “SNMP”) filed a lawsuit against the Company in the Eastern District of Tennessee for copyright infringement, alleging that the Company was not properly licensed to use its software. SNMP sought actual damages and profits attributed to the infringement, as well as equitable relief. On March 2, 2023, SNMP filed an amended complaint adding claims against Extreme on additional products for copyright infringement, breach of contract, and fraud. The parties reached a settlement, and on July 29, 2025, the case was dismissed with prejudice.
  (was, 2025-05-01, similarity 0.7994):
[0000950170-25-061827:note_history:4]
On October 26, 2020, SNMP Research, Inc. and SNMP Research International, Inc. (collectively, “SNMP”) filed a lawsuit against the Company in the Eastern District of Tennessee for copyright infringement, alleging that the Company was not properly licensed to use its software. SNMP is seeking actual damages and profits attributed to the infringement, as well as equitable relief. On March 2, 2023, SNMP filed an amended complaint adding claims against Extreme on additional products for copyright infringement, breach of contract, and fraud. On January 3, 2025, both parties filed motions for summary judgment seeking to resolve various claims in the case. Those motions are currently pending before the Court. The trial is set for August 5, 2025.

- changed (2025-10-30):
[0001193125-25-258554:note_history:5]
The Company filed a nullity complaint against EP ‘498 with the German Federal Patent Court on September 24, 2021. The German Federal Patent Court issued a decision finding that the patent was invalid on November 20, 2024. Mala appealed the decision on March 3, 2025, and filed its Grounds of Appeal on June 5, 2025. The Company filed its response to the Grounds of Appeal on October 6, 2025.
  (was, 2025-05-01, similarity 0.8136):
[0000950170-25-061827:note_history:5]
The Company filed a nullity complaint against EP ‘498 with the German Federal Patent Court on September 24, 2021. The German Federal Patent Court issued a decision finding that the patent was invalid on November 20, 2024. Mala appealed the decision on March 3, 2025, and the Company will defend the appeal.

- changed (2025-10-30):
[0001193125-25-258554:note_history:6]
On August 13, 2024, a putative securities class action (the “Class Action”) was filed in the United States District Court for the Northern District of California captioned Steamfitters Local 449 Pension & Retirement Security Funds v. Extreme Networks, Inc., et al., Case No. 5:24-cv-05102-TLT, naming the Company and certain of its current and former executive officers as defendants. The lawsuit is purportedly brought on behalf of purchasers of Extreme Networks securities between July 27, 2022 and January 30, 2024 (the “Class Period”). The complaint alleges claims under Sections 10(b) and 20(a) of the Securities Exchange Act of 1934, and Rule 10b-5 promulgated thereunder, based on allegedly false and misleading statements about the Company's business and prospects during the Class Period. The lawsuit seeks unspecified damages. On December 30, 2024, the Court selected Oklahoma Firefighters Pension and Retirement System, Oklahoma Police Pension and Retirement System, Oakland County Voluntary Employees’ Beneficiary Association, Oakland County Employees’ Retirement System as the lead plaintiffs. The Company's Motion to Dismiss was granted on August 15, 2025, but the plaintiffs were granted leave to file a second amended complaint. Plaintiffs filed a second amended complaint on September 9, 2025. The Company filed a motion to dismiss the second amended complaint on October 3, 2025.
  (was, 2025-05-01, similarity 0.8579):
[0000950170-25-061827:note_history:6]
On August 13, 2024, a putative securities class action (the “Class Action”) was filed in the United States District Court for the Northern District of California captioned Steamfitters Local 449 Pension & Retirement Security Funds v. Extreme Networks, Inc., et al., Case No. 5:24-cv-05102-TLT, naming the Company and certain of its current and former executive officers as defendants. The lawsuit is purportedly brought on behalf of purchasers of Extreme Networks securities between July 27, 2022 and January 30, 2024 (the “Class Period”). The complaint alleges claims under Sections 10(b) and 20(a) of the Securities Exchange Act of 1934, and Rule 10b-5 promulgated thereunder, based on allegedly false and misleading statements about the Company's business and prospects during the Class Period. The lawsuit seeks unspecified damages. On December 30, 2024, the Court selected Oklahoma Firefighters Pension and Retirement System, Oklahoma Police Pension and Retirement System, Oakland County Voluntary Employees’ Beneficiary Association, Oakland County Employees’ Retirement System as the lead plaintiffs. The Company filed a Motion to Dismiss the amended complaint on April 15, 2025. Trial has been scheduled for March 29, 2027.

- changed (2025-10-30):
[0001193125-25-258554:note_history:7]
On February 27, 2025, a shareholder derivative case was filed in the United States District Court for the Northern District of California captioned Turner v. Brown et al., Case No. 3:25-cv-02101. On March 6, 2025, a shareholder derivative case was filed in the United States District Court for the Northern District of California captioned Hemani v. Meyercord et al., Case No. 3:25-cv-02318-AGT. On March 25, 2025, a shareholder derivative case was filed in the United States District Court for the Eastern District of North Carolina captioned Miller v. Meyercord et al., Case No. 5:25-cv-00161. Each of these cases (collectively, the “Derivative Cases”) names current and former officers, directors, and employees of the Company as defendants, and seeks recovery on behalf of the Company based on substantially the same allegations as the Class Action. These cases remain stayed pending a decision on the motion to dismiss the second amended complaint in the Class Action.
  (was, 2025-05-01, similarity 0.8895):
[0000950170-25-061827:note_history:7]
On February 27, 2025, a shareholder derivative case was filed in the United States District Court for the Northern District of California captioned Turner v. Brown et al., Case No. 3:25-cv-02101. On March 6, 2025, a shareholder derivative case was filed in the United States District Court for the Northern District of California captioned Hemani v. Meyercord et al., Case No. 3:25-cv-02318-AGT. On March 25, 2025, a shareholder derivative case was filed in the United States District Court for the Eastern District of North Carolina captioned Miller v. Meyercord et al., Case No. 5:25-cv-00161. Each of these cases (collectively, the “Derivative Cases”) names current and former officers, directors, and employees of the Company as defendants, and seeks recovery on behalf of the Company based on substantially the same allegations as the Class Action. The plaintiffs in the Derivative Cases have agreed in principle to stay the matters pending resolution of the Class Action.

- changed (2025-10-30):
[0001193125-25-258554:note_history:8]
Subject to certain limitations, the Company may be obligated to indemnify its current and former directors, officers, and employees. These obligations arise under the terms of its certificate of incorporation, its bylaws, applicable contracts, and applicable law. The obligation to indemnify, where applicable, generally means that the Company is required to pay or reimburse, and in certain circumstances the Company has paid or reimbursed, the individuals’ reasonable legal expenses and possible damages and other liabilities incurred in connection with certain legal matters. The Company also procures Directors and Officers liability insurance to help cover its defense and/or indemnification costs, although its ability to recover such costs through insurance is uncertain. While it is not possible to estimate the maximum potential amount that could be owed under these governing documents and agreements due to the Company’s
  (was, 2025-05-01, similarity 0.8884):
[0000950170-25-061827:note_history:8]
Subject to certain limitations, the Company may be obligated to indemnify its current and former directors, officers, and employees. These obligations arise under the terms of its certificate of incorporation, its bylaws, applicable contracts, and applicable law. The obligation to indemnify, where applicable, generally means that the Company is required to pay or reimburse, and in certain circumstances the Company has paid or reimbursed, the individuals’ reasonable legal expenses and possible damages and other liabilities incurred in connection with certain legal matters. The Company also procures Directors and Officers liability insurance to help cover its defense and/or indemnification costs, although its ability to recover such costs through insurance is uncertain. While it is not possible to estimate the maximum potential amount that could be owed under these governing documents and agreements due to the Company’s limited history with prior indemnification claims, indemnification (including defense) costs could, in the future, have a material adverse effect on the Company’s consolidated financial position, results of operations and cash flows.

- added (2025-10-30):
[0001193125-25-258554:note_history:9]
limited history with prior indemnification claims, indemnification (including defense) costs could, in the future, have a material adverse effect on the Company’s consolidated financial position, results of operations and cash flows.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2025-10-30):
[0001193125-25-258554:note_history:10]
The unaudited condensed consolidated financial statements reflect all adjustments, consisting only of normal recurring adjustments that, in the opinion of management, are necessary for a fair presentation of the results of operations and cash flows for the interim periods presented and the financial condition of Extreme at September 30, 2025. The results of operations for the three months ended September 30, 2025 are not necessarily indicative of the results that may be expected for fiscal 2026 or any future periods.
  (was, 2025-05-01, similarity 0.6824):
[0000950170-25-061827:note_history:10]
The unaudited condensed consolidated financial statements reflect all adjustments, consisting only of normal recurring adjustments that, in the opinion of management, are necessary for a fair presentation of the results of operations and cash flows for the interim periods presented and the financial condition of Extreme at March 31, 2025. The results of operations for the three and nine months ended March 31, 2025 are not necessarily indicative of the results that may be expected for fiscal 2025 or any future periods.


## us-gaap:SignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- added (2025-10-30):
[0001193125-25-258554:note_history:11]
In September 2025, the Financial Accounting Standards Board (“FASB") issued Accounting Standards Update ("ASU") 2025-06, Intangibles—Goodwill and Other—Internal-Use Software (Subtopic 350-40): Targeted Improvements to the Accounting for Internal-Use Software. This ASU removes all references to prescriptive and sequential software development stages and requires entities to begin capitalizing software costs when management authorizes and commits to funding the software project, and it is probable that the project will be completed, and the software will be used for its intended purpose. The amendments in this ASU are effective for fiscal years beginning after December 15, 2027, and interim periods within those annual reporting periods. Early adoption is permitted. The Company is currently evaluating the impact of adopting ASU 2025-06 on its consolidated financial statements and related disclosures.

- added (2025-10-30):
[0001193125-25-258554:note_history:12]
In July 2025, the FASB issued ASU 2025-05, Financial Instruments—Credit Losses (Topic 326): Measurement of Credit Losses for Accounts Receivable and Contract Assets to address challenges encountered when applying the guidance in Topic 326, Financial Instruments—Credit Losses, to current accounts receivable and current contract assets arising from transactions accounted for under Topic 606, Revenue from Contracts with Customers. ASU 2025-05 is effective for fiscal years beginning after December 15, 2025, and interim periods within those annual reporting periods. Early adoption is permitted. The Company is currently evaluating the impact of adopting ASU 2025-05 on its consolidated financial statements and related disclosures.

- changed (2025-10-30):
[0001193125-25-258554:note_history:13]
In November 2024, the FASB issued ASU 2024-03, Income Statement—Reporting Comprehensive Income—Expense Disaggregation Disclosures (Subtopic 220-40): Disaggregation of Income Statement Expenses to improve disclosures about public business entities’ expenses and to provide more detailed information around the types of expenses included in commonly presented expense captions. Additionally, in January 2025 the FASB issued ASU 2025-01 to clarify the effective date of ASU 2024-03. ASU 2024-03 is effective for fiscal years beginning after December 15, 2026, and interim periods for fiscal years beginning after December 15, 2027, and can be applied on a prospective basis or on a retrospective basis to all periods presented. Early adoption is permitted. The Company is currently evaluating the impact of adopting ASU 2024-03 and ASU 2025-01 on its consolidated financial statements and related disclosures.
  (was, 2025-05-01, similarity 0.9435):
[0000950170-25-061827:note_history:13]
In November 2024, the Financial Accounting Standards Board (“FASB”) issued Accounting Standards Update (“ASU”) 2024-03, Income Statement—Reporting Comprehensive Income—Expense Disaggregation Disclosures (Subtopic 220-40): Disaggregation of Income Statement Expenses to improve disclosures about public business entities’ expenses and to provide more detailed information around the types of expenses included in commonly presented expense captions. Additionally, in January 2025 the FASB issued ASU 2025-01 to clarify the effective date of ASU 2024-03. ASU 2024-03 is effective for fiscal years beginning after December 15, 2026, and interim periods for fiscal years beginning after December 15, 2027, and can be applied on a prospective basis or on a retrospective basis to all periods presented. Early adoption is permitted. The Company is currently evaluating the impact of adopting ASU 2024-03 and ASU 2025-01 on its consolidated financial statements and related disclosures.

- removed (2025-10-30):
[0000950170-25-061827:note_history:14]
In November 2023, the FASB issued ASU 2023-07, Segment Reporting (Topic 280): Improvements to Reportable Segment Disclosures to improve reportable segment disclosure requirements primarily through enhanced disclosures about significant segment expenses and information used to assess segment performance. All disclosure requirements of ASU 2023-07 are required for entities with a single reportable segment. ASU 2023-07 is effective for fiscal years beginning after December 15, 2023, and interim periods for fiscal years beginning after December 15, 2024, and should be applied on a retrospective basis to all periods presented. Early adoption is permitted. The Company is currently evaluating the impact of adopting ASU 2023-07 on its consolidated financial statements and related disclosures.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2025-10-30):
[0001193125-25-258554:note_history:15]
|  |  | September 30,2025 |  |  | June 30,2025 |  |
| Current portion of long-term debt: |  |  |  |  |  |  |
| Term Loan |  | $ | 16,250 |  |  | $ | 15,000 |  |
| Revolving Facility |  |  | 25,000 |  |  |  | — |  |
| Less: unamortized debt issuance costs |  |  | (714 | ) |  |  | (729 | ) |
| Current portion of long-term debt |  | $ | 40,536 |  |  | $ | 14,271 |  |
| Long-term debt, less current portion: |  |  |  |  |  |  |
| Term Loan |  | $ | 160,000 |  |  | $ | 165,000 |  |
| Less: unamortized debt issuance costs |  |  | (1,104 | ) |  |  | (1,276 | ) |
| Total long-term debt, less current portion |  |  | 158,896 |  |  |  | 163,724 |  |
| Total debt |  | $ | 199,432 |  |  | $ | 177,995 |  |
  (was, 2025-05-01, similarity 0.9471):
[0000950170-25-061827:note_history:15]
|  |  | March 31,2025 |  |  | June 30,2024 |  |
| Current portion of long-term debt: |  |  |  |  |  |  |
| Term Loan |  | $ | 13,750 |  |  | $ | 10,000 |  |
| Less: unamortized debt issuance costs |  |  | (741 | ) |  |  | (674 | ) |
| Current portion of long-term debt |  | $ | 13,009 |  |  | $ | 9,326 |  |
| Long-term debt, less current portion: |  |  |  |  |  |  |
| Term Loan |  | $ | 168,750 |  |  | $ | 180,000 |  |
| Less: unamortized debt issuance costs |  |  | (1,456 | ) |  |  | (1,735 | ) |
| Total long-term debt, less current portion |  |  | 167,294 |  |  |  | 178,265 |  |
| Total debt |  | $ | 180,303 |  |  | $ | 187,591 |  |

- changed (2025-10-30):
[0001193125-25-258554:note_history:16]
On June 22, 2023, the Company entered into a Second Amended and Restated Credit Agreement (the “2023 Credit Agreement”), by and among the Company, as borrower, BMO Harris Bank, N.A., as an issuing lender and swingline lender, Bank of America, N.A., JPMorgan Chase Bank, N.A., PNC Bank, National Association, and Wells Fargo Bank, National Association, as issuing lenders, the financial institutions or entities party thereto as lenders, and Bank of Montreal, as administrative agent and collateral agent, which amended and restated the Amended and Restated Credit Agreement, dated August 9, 2019, by and among the Company, as borrower,
  (was, 2025-05-01, similarity 0.7118):
[0000950170-25-061827:note_history:16]
On June 22, 2023, the Company entered into a Second Amended and Restated Credit Agreement (the “2023 Credit Agreement”), by and among the Company, as borrower, BMO Harris Bank, N.A., as an issuing lender and swingline lender, Bank of America, N.A., JPMorgan Chase Bank, N.A., PNC Bank, National Association, and Wells Fargo Bank, National Association, as issuing lenders, the financial institutions or entities party thereto as lenders, and Bank of Montreal, as administrative agent and collateral agent, which amended and restated the 2019 Credit Agreement. The 2023 Credit Agreement provides for i) a $200.0 million first lien term loan facility in an aggregate principal amount (the “2023 Term Loan”), ii) a $150.0 million five-year revolving credit facility (the “2023 Revolving Facility”) and, iii) an uncommitted additional incremental loan facility in the principal amount of up to $100.0 million.

- added (2025-10-30):
[0001193125-25-258554:note_history:17]
several banks and other financial institutions as Lenders, BMO Harris Bank N.A., as an issuing lender and swingline lender, Silicon Valley Bank, as an Issuing Lender, and Bank of Montreal, as administrative agent and collateral agent for the Lenders. The 2023 Credit Agreement provides for i) a $200.0 million first lien term loan facility in an aggregate principal amount (the “2023 Term Loan”), ii) a $150.0 million five-year revolving credit facility (the “2023 Revolving Facility”) and, iii) an uncommitted additional incremental loan facility in the principal amount of up to $100.0 million.

- changed (2025-10-30):
[0001193125-25-258554:note_history:18]
On August 14, 2024, the Company entered into an Amendment Number One to the 2023 Credit Agreement (the 2023 Credit Agreement as amended by that certain Amendment Number One, the “Amended Credit Agreement”). Under the Amended Credit Agreement, the Company modified the definition of the consolidated EBITDA for the purposes of evaluating compliance with financial covenants under the 2023 Credit Agreement. The amended definition of consolidated EBITDA modifies the amount and type of add-backs that are allowable to better align with the Company's operations and activities. Further, the Amended Credit Agreement provided a waiver for the Company's compliance with the consolidated interest charge coverage ratio for each of the quarters ended June 30, 2024, September 30, 2024, and December 31, 2024. As of September 30, 2025, the Company was in compliance with the modified terms and financial covenants under the Amended Credit Agreement.
  (was, 2025-05-01, similarity 0.9186):
[0000950170-25-061827:note_history:18]
On August 14, 2024, the Company entered into an Amendment Number One to the 2023 Credit Agreement (the 2023 Credit Agreement as amended by that certain Amendment Number One, the “Amended Credit Agreement”). Under the Amended Credit Agreement, the Company modified the definition of the consolidated EBITDA for the purposes of evaluating compliance with financial covenants under the 2023 Credit Agreement. The amended definition of consolidated EBITDA modifies the amount and type of add-backs that are allowable to better align with the Company's operations and activities. Further, the Amended Credit Agreement provides a waiver for the Company's compliance with the consolidated interest charge coverage ratio for each of the quarters ended June 30, 2024, September 30, 2024, and December 31, 2024.

- changed (2025-10-30):
[0001193125-25-258554:note_history:19]
Financing costs incurred in connection with obtaining long-term financing are deferred and amortized over the term of the related indebtedness or credit agreement. Amortization of deferred financing costs is included in “Interest expense” in the accompanying condensed consolidated statements of operations was $0.3 million for each of the three months ended September 30, 2025 and 2024, respectively. The interest rate was 6.54% and 7.52% as of September 30, 2025 and 2024, respectively.
  (was, 2025-05-01, similarity 0.8355):
[0000950170-25-061827:note_history:19]
Financing costs incurred in connection with obtaining long-term financing are deferred and amortized over the term of the related indebtedness or credit agreement. Amortization of deferred financing costs is included in “Interest expense” in the accompanying condensed consolidated statements of operations was $0.3 million for each period during the three months ended March 31, 2025 and 2024, and was $0.9 million and $0.8 million for the nine months ended March 31, 2025 and 2024, respectively. The interest rate was 6.41% and 7.44% as of March 31, 2025 and 2024, respectively.

- added (2025-10-30):
[0001193125-25-258554:note_history:20]
During the three months ended September 30, 2025, the Company borrowed $25.0 million against the 2023 Revolving Facility which was subsequently paid out in October 2025. The Company had $110.8 million of availability under the 2023 Revolving Facility as of September 30, 2025. During the three months ended September 30, 2025 and 2024, the Company did not make any additional payments against its term loan facility other than the scheduled payments per the terms of the Amended Credit Agreement.

- changed (2025-10-30):
[0001193125-25-258554:note_history:21]
The Company had $14.2 million of outstanding letters of credit as of September 30, 2025.
  (was, 2025-05-01, similarity 0.9351):
[0000950170-25-061827:note_history:21]
The Company had $14.2 million of outstanding letters of credit as of March 31, 2025.

- removed (2025-10-30):
[0000950170-25-061827:note_history:22]
On August 9, 2019, the Company entered into an Amended and Restated Credit Agreement (the “2019 Credit Agreement”), by and among the Company, as borrower, several banks and other financial institutions as Lenders, BMO Harris Bank N.A., as an issuing lender and swingline lender, Silicon Valley Bank, as an Issuing Lender, and Bank of Montreal, as administrative agent and collateral agent for the Lenders which was subsequently amended during fiscal 2023.

- removed (2025-10-30):
[0000950170-25-061827:note_history:23]
As of March 31, 2025, the Company was in compliance with all the terms and financial covenants of the Amended Credit Agreement.

- removed (2025-10-30):
[0000950170-25-061827:note_history:24]
As of March 31, 2025, the Company did not have any outstanding balance against its 2023 Revolving Facility. The Company had $135.8 million of availability under the 2023 Revolving Facility as of March 31, 2025. During the three and nine months ended March 31, 2025 and 2024, the Company did not make any additional payments against its term loan facility other than the scheduled payments per the terms of the Amended Credit Agreement.


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2025-10-30):
[0001193125-25-258554:note_history:25]
|  |  | September 30,2025 |  |  | June 30,2025 |  |
| Current portion of long-term debt: |  |  |  |  |  |  |
| Term Loan |  | $ | 16,250 |  |  | $ | 15,000 |  |
| Revolving Facility |  |  | 25,000 |  |  |  | — |  |
| Less: unamortized debt issuance costs |  |  | (714 | ) |  |  | (729 | ) |
| Current portion of long-term debt |  | $ | 40,536 |  |  | $ | 14,271 |  |
| Long-term debt, less current portion: |  |  |  |  |  |  |
| Term Loan |  | $ | 160,000 |  |  | $ | 165,000 |  |
| Less: unamortized debt issuance costs |  |  | (1,104 | ) |  |  | (1,276 | ) |
| Total long-term debt, less current portion |  |  | 158,896 |  |  |  | 163,724 |  |
| Total debt |  | $ | 199,432 |  |  | $ | 177,995 |  |
  (was, 2025-05-01, similarity 0.9471):
[0000950170-25-061827:note_history:25]
|  |  | March 31,2025 |  |  | June 30,2024 |  |
| Current portion of long-term debt: |  |  |  |  |  |  |
| Term Loan |  | $ | 13,750 |  |  | $ | 10,000 |  |
| Less: unamortized debt issuance costs |  |  | (741 | ) |  |  | (674 | ) |
| Current portion of long-term debt |  | $ | 13,009 |  |  | $ | 9,326 |  |
| Long-term debt, less current portion: |  |  |  |  |  |  |
| Term Loan |  | $ | 168,750 |  |  | $ | 180,000 |  |
| Less: unamortized debt issuance costs |  |  | (1,456 | ) |  |  | (1,735 | ) |
| Total long-term debt, less current portion |  |  | 167,294 |  |  |  | 178,265 |  |
| Total debt |  | $ | 180,303 |  |  | $ | 187,591 |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- added (2025-10-30):
[0001193125-25-258554:note_history:26]
|  | Three Months Ended |  |
|  |  | September 30,2025 |  |  | September 30,2024 |  |
| Americas: |  |  |  |  |  |  |
| United States |  |  | 136,384 |  |  | $ | 153,253 |  |
| Other |  |  | 12,875 |  |  |  | 12,182 |  |
| Total Americas |  |  | 149,259 |  |  |  | 165,435 |  |
| EMEA |  |  | 121,246 |  |  |  | 84,918 |  |
| APAC |  |  | 39,740 |  |  |  | 18,851 |  |
| Total net revenues |  | $ | 310,245 |  |  | $ | 269,204 |  |

- removed (2025-10-30):
[0000950170-25-061827:note_history:27]
|  | Three Months Ended |  | Nine Months Ended |  |
|  |  | March 31,2025 |  |  | March 31,2024 |  |  | March 31,2025 |  |  | March 31,2024 |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  |  | 145,426 |  |  | $ | 124,082 |  |  |  | 418,356 |  |  | $ | 456,383 |  |
| Other |  |  | 14,126 |  |  |  | 10,291 |  |  |  | 38,018 |  |  |  | 36,274 |  |
| Total Americas |  |  | 159,552 |  |  |  | 134,373 |  |  |  | 456,374 |  |  |  | 492,657 |  |
| EMEA |  |  | 107,132 |  |  |  | 59,035 |  |  |  | 320,307 |  |  |  | 313,243 |  |
| APAC |  |  | 17,821 |  |  |  | 17,628 |  |  |  | 56,383 |  |  |  | 54,650 |  |
| Total net revenues |  | $ | 284,505 |  |  | $ | 211,036 |  |  | $ | 833,064 |  |  | $ | 860,550 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- added (2025-10-30):
[0001193125-25-258554:note_history:28]
As of September 30, 2025, the Company had $632.2 million of remaining performance obligations, which is primarily comprised of deferred SaaS subscription and deferred support revenues. The Company expects to recognize approximately 43% of its deferred revenue as revenue in the remainder of fiscal 2026, an additional 27% in fiscal 2027, and the remaining 30% of the balance thereafter.

- changed (2025-10-30):
[0001193125-25-258554:note_history:29]
Revenue recognized for the three months ended September 30, 2025 and 2024 that was included in the deferred revenue balance at the beginning of each period was $104.7 million and $100.3 million, respectively.
  (was, 2025-05-01, similarity 0.6444):
[0000950170-25-061827:note_history:29]
Revenue recognized for the three months ended March 31, 2025 and 2024 that was included in the deferred revenue balance at the beginning of each period was $96.9 million and $95.9 million, respectively. Revenue recognized for the nine months ended March 31, 2025 and 2024 that was included in the deferred revenue balance at the beginning of each period was $245.5 million and $230.8 million, respectively.

- changed (2025-10-30):
[0001193125-25-258554:note_history:30]
Contract Costs. The Company recognizes the incremental costs of obtaining contracts as an expense when incurred if the amortization period of the assets that the Company otherwise would have recognized is one year or less. Management expects that commission fees paid to sales representatives as a result of obtaining subscription and support contracts and contract renewals are recoverable and therefore the Company’s condensed consolidated balance sheets included capitalized balances in the amount of $28.6 million and $26.9 million as of September 30, 2025 and June 30, 2025, respectively. Capitalized commissions are included within other assets in the condensed consolidated balance sheets. Capitalized commission fees are amortized on a straight-line basis over the average period of service contracts of approximately three years, and are included in “Sales and marketing” in the accompanying condensed consolidated statements of operations. Amortization recognized during the three months ended September 30, 2025 and 2024 was $3.4 million and $3.0 million, respectively.
  (was, 2025-05-01, similarity 0.9318):
[0000950170-25-061827:note_history:30]
Contract Costs. The Company recognizes the incremental costs of obtaining contracts as an expense when incurred if the amortization period of the assets that the Company otherwise would have recognized is one year or less. Management expects that commission fees paid to sales representatives as a result of obtaining subscription and support contracts and contract renewals are recoverable and therefore the Company’s condensed consolidated balance sheets included capitalized balances in the amount of $25.6 million and $24.7 as of March 31, 2025 and June 30, 2024, respectively. Capitalized commissions are included within other assets in the condensed consolidated balance sheets. Capitalized commission fees are amortized on a straight-line basis over the average period of service contracts of approximately three years, and are included in “Sales and marketing” in the accompanying condensed consolidated statements of operations. Amortization recognized during the three months ended March 31, 2025 and 2024 was $3.2 million and $2.8 million, respectively. Amortization recognized during the nine months ended March 31, 2025 and 2024 was $9.3 million and $8.0 million, respectively.

- added (2025-10-30):
[0001193125-25-258554:note_history:31]
|  | Three Months Ended |  |
|  |  | September 30,2025 |  |  | September 30,2024 |  |
| Americas: |  |  |  |  |  |  |
| United States |  |  | 136,384 |  |  | $ | 153,253 |  |
| Other |  |  | 12,875 |  |  |  | 12,182 |  |
| Total Americas |  |  | 149,259 |  |  |  | 165,435 |  |
| EMEA |  |  | 121,246 |  |  |  | 84,918 |  |
| APAC |  |  | 39,740 |  |  |  | 18,851 |  |
| Total net revenues |  | $ | 310,245 |  |  | $ | 269,204 |  |

- added (2025-10-30):
[0001193125-25-258554:note_history:32]
For the three months ended September 30, 2025 and 2024 no foreign country accounted for 10% or more of the Company's net revenues.

- changed (2025-10-30):
[0001193125-25-258554:note_history:33]
|  |  | Three Months Ended |
|  |  | September 30,2025 |  | September 30,2024 |
| Jenne, Inc. |  | 18% |  | 21% |
| TD Synnex Corporation |  | 16% |  | 22% |
| Westcon Group, Inc. |  | 15% |  | 15% |
  (was, 2025-05-01, similarity 0.6705):
[0000950170-25-061827:note_history:33]
|  |  | March 31,2025 |  | June 30,2024 |
| Jenne, Inc. |  | 33% |  | 64% |
| TD Synnex Corporation |  | 13% |  | * |
| ScanSource, Inc. |  | * |  | 11% |
| * Less than 10% of accounts receivable |  |  |  |  |

- added (2025-10-30):
[0001193125-25-258554:note_history:34]
|  |  | September 30,2025 |  | June 30,2025 |
| Jenne, Inc. |  | 21% |  | 22% |
| J's Communication Co., Ltd. |  | 11% |  | * |
| Ericcson, Inc. |  | * |  | 11% |
| * Less than 10% of accounts receivable |  |  |  |  |

- removed (2025-10-30):
[0000950170-25-061827:note_history:35]
As of March 31, 2025, the Company had $588.7 million of remaining performance obligations, which primarily comprised of deferred SaaS subscription and deferred support revenues. The Company expects to recognize approximately 17% of its deferred revenue as revenue in the remainder of fiscal 2025, an additional 42% in fiscal 2026, and the remaining 41% of the balance thereafter.

- removed (2025-10-30):
[0000950170-25-061827:note_history:36]
|  | Three Months Ended |  | Nine Months Ended |  |
|  |  | March 31,2025 |  |  | March 31,2024 |  |  | March 31,2025 |  |  | March 31,2024 |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  |  | 145,426 |  |  | $ | 124,082 |  |  |  | 418,356 |  |  | $ | 456,383 |  |
| Other |  |  | 14,126 |  |  |  | 10,291 |  |  |  | 38,018 |  |  |  | 36,274 |  |
| Total Americas |  |  | 159,552 |  |  |  | 134,373 |  |  |  | 456,374 |  |  |  | 492,657 |  |
| EMEA |  |  | 107,132 |  |  |  | 59,035 |  |  |  | 320,307 |  |  |  | 313,243 |  |
| APAC |  |  | 17,821 |  |  |  | 17,628 |  |  |  | 56,383 |  |  |  | 54,650 |  |
| Total net revenues |  | $ | 284,505 |  |  | $ | 211,036 |  |  | $ | 833,064 |  |  | $ | 860,550 |  |

- removed (2025-10-30):
[0000950170-25-061827:note_history:37]
For the three and nine months ended March 31, 2025, the Company generated 10% and 11% of its net revenues respectively from the Netherlands. For the nine months ended March 31, 2024, the Company generated 10% of its net revenues from the Netherlands. No other foreign country accounted for 10% or more of the Company's net revenues for the three and nine months ended March 31, 2025 and 2024.

- removed (2025-10-30):
[0000950170-25-061827:note_history:38]
|  |  | Three Months Ended |  | Nine Months Ended |
|  |  | March 31,2025 |  | March 31,2024 |  | March 31,2025 |  | March 31,2024 |
| Jenne, Inc. |  | 21% |  | 12% |  | 19% |  | 22% |
| TD Synnex Corporation |  | 18% |  | 22% |  | 19% |  | 21% |
| Westcon Group, Inc. |  | 16% |  | 13% |  | 17% |  | 17% |
| ScanSource, Inc. |  | * |  | 11% |  | * |  | * |
| * Less than 10% of net revenue |  |  |  |  |  |  |  |  |


## us-gaap:RevenueRecognitionPolicyTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- added (2025-10-30):
[0001193125-25-258554:note_history:39]
As of September 30, 2025, the Company had $632.2 million of remaining performance obligations, which is primarily comprised of deferred SaaS subscription and deferred support revenues. The Company expects to recognize approximately 43% of its deferred revenue as revenue in the remainder of fiscal 2026, an additional 27% in fiscal 2027, and the remaining 30% of the balance thereafter.

- changed (2025-10-30):
[0001193125-25-258554:note_history:40]
Revenue recognized for the three months ended September 30, 2025 and 2024 that was included in the deferred revenue balance at the beginning of each period was $104.7 million and $100.3 million, respectively.
  (was, 2025-05-01, similarity 0.6444):
[0000950170-25-061827:note_history:40]
Revenue recognized for the three months ended March 31, 2025 and 2024 that was included in the deferred revenue balance at the beginning of each period was $96.9 million and $95.9 million, respectively. Revenue recognized for the nine months ended March 31, 2025 and 2024 that was included in the deferred revenue balance at the beginning of each period was $245.5 million and $230.8 million, respectively.

- changed (2025-10-30):
[0001193125-25-258554:note_history:41]
Contract Costs. The Company recognizes the incremental costs of obtaining contracts as an expense when incurred if the amortization period of the assets that the Company otherwise would have recognized is one year or less. Management expects that commission fees paid to sales representatives as a result of obtaining subscription and support contracts and contract renewals are recoverable and therefore the Company’s condensed consolidated balance sheets included capitalized balances in the amount of $28.6 million and $26.9 million as of September 30, 2025 and June 30, 2025, respectively. Capitalized commissions are included within other assets in the condensed consolidated balance sheets. Capitalized commission fees are amortized on a straight-line basis over the average period of service contracts of approximately three years, and are included in “Sales and marketing” in the accompanying condensed consolidated statements of operations. Amortization recognized during the three months ended September 30, 2025 and 2024 was $3.4 million and $3.0 million, respectively.
  (was, 2025-05-01, similarity 0.9318):
[0000950170-25-061827:note_history:41]
Contract Costs. The Company recognizes the incremental costs of obtaining contracts as an expense when incurred if the amortization period of the assets that the Company otherwise would have recognized is one year or less. Management expects that commission fees paid to sales representatives as a result of obtaining subscription and support contracts and contract renewals are recoverable and therefore the Company’s condensed consolidated balance sheets included capitalized balances in the amount of $25.6 million and $24.7 as of March 31, 2025 and June 30, 2024, respectively. Capitalized commissions are included within other assets in the condensed consolidated balance sheets. Capitalized commission fees are amortized on a straight-line basis over the average period of service contracts of approximately three years, and are included in “Sales and marketing” in the accompanying condensed consolidated statements of operations. Amortization recognized during the three months ended March 31, 2025 and 2024 was $3.2 million and $2.8 million, respectively. Amortization recognized during the nine months ended March 31, 2025 and 2024 was $9.3 million and $8.0 million, respectively.

- added (2025-10-30):
[0001193125-25-258554:note_history:42]
|  | Three Months Ended |  |
|  |  | September 30,2025 |  |  | September 30,2024 |  |
| Americas: |  |  |  |  |  |  |
| United States |  |  | 136,384 |  |  | $ | 153,253 |  |
| Other |  |  | 12,875 |  |  |  | 12,182 |  |
| Total Americas |  |  | 149,259 |  |  |  | 165,435 |  |
| EMEA |  |  | 121,246 |  |  |  | 84,918 |  |
| APAC |  |  | 39,740 |  |  |  | 18,851 |  |
| Total net revenues |  | $ | 310,245 |  |  | $ | 269,204 |  |

- added (2025-10-30):
[0001193125-25-258554:note_history:43]
For the three months ended September 30, 2025 and 2024 no foreign country accounted for 10% or more of the Company's net revenues.

- removed (2025-10-30):
[0000950170-25-061827:note_history:44]
As of March 31, 2025, the Company had $588.7 million of remaining performance obligations, which primarily comprised of deferred SaaS subscription and deferred support revenues. The Company expects to recognize approximately 17% of its deferred revenue as revenue in the remainder of fiscal 2025, an additional 42% in fiscal 2026, and the remaining 41% of the balance thereafter.

- removed (2025-10-30):
[0000950170-25-061827:note_history:45]
|  | Three Months Ended |  | Nine Months Ended |  |
|  |  | March 31,2025 |  |  | March 31,2024 |  |  | March 31,2025 |  |  | March 31,2024 |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  |  | 145,426 |  |  | $ | 124,082 |  |  |  | 418,356 |  |  | $ | 456,383 |  |
| Other |  |  | 14,126 |  |  |  | 10,291 |  |  |  | 38,018 |  |  |  | 36,274 |  |
| Total Americas |  |  | 159,552 |  |  |  | 134,373 |  |  |  | 456,374 |  |  |  | 492,657 |  |
| EMEA |  |  | 107,132 |  |  |  | 59,035 |  |  |  | 320,307 |  |  |  | 313,243 |  |
| APAC |  |  | 17,821 |  |  |  | 17,628 |  |  |  | 56,383 |  |  |  | 54,650 |  |
| Total net revenues |  | $ | 284,505 |  |  | $ | 211,036 |  |  | $ | 833,064 |  |  | $ | 860,550 |  |

- removed (2025-10-30):
[0000950170-25-061827:note_history:46]
For the three and nine months ended March 31, 2025, the Company generated 10% and 11% of its net revenues respectively from the Netherlands. For the nine months ended March 31, 2024, the Company generated 10% of its net revenues from the Netherlands. No other foreign country accounted for 10% or more of the Company's net revenues for the three and nine months ended March 31, 2025 and 2024.
