# EXTR 8-K — 0001193125-25-254626 filed 2025-10-29

## item codes, every 8-K on or before 2025-10-30

- 2025-10-29 0001193125-25-254626 — 2.02, 9.01
- 2025-08-06 0000950170-25-103531 — 2.02, 9.01
- 2025-04-30 0000950170-25-060571 — 2.02, 9.01
- 2025-02-18 0000950170-25-021808 — 8.01, 9.01
- 2025-01-29 0000950170-25-010203 — 2.02, 9.01
- 2024-11-15 0000950170-24-127573 — 5.07, 9.01
- 2024-10-30 0000950170-24-118589 — 2.02, 9.01
- 2024-08-07 0000950170-24-092273 — 2.02, 9.01
- 2024-05-01 0000950170-24-050891 — 2.02, 9.01
- 2024-01-31 0000950170-24-009144 — 2.02, 9.01
- 2024-01-08 0001193125-24-004497 — 5.02
- 2024-01-08 0000950170-24-002958 — 2.02, 9.01
- 2023-11-09 0000950170-23-062050 — 5.03, 5.07, 9.01
- 2023-11-01 0000950170-23-057125 — 2.02, 9.01
- 2023-08-02 0000950170-23-036775 — 2.02, 9.01
- 2023-06-23 0000950170-23-029645 — 1.01, 2.03, 9.01
- 2023-06-09 0000950170-23-027267 — 5.03, 9.01
- 2023-04-26 0000950170-23-014563 — 2.02, 9.01
- 2023-04-24 0001193125-23-113052 — 5.02, 9.01
- 2023-01-25 0001564590-23-000756 — 5.02, 9.01
- 2023-01-25 0001564590-23-000754 — 2.02, 9.01
- 2022-11-18 0001564590-22-038036 — 5.03, 5.07, 9.01
- 2022-10-27 0001564590-22-035354 — 2.02, 9.01
- 2022-10-12 0001193125-22-261213 — 8.01
- 2022-07-27 0001564590-22-026574 — 2.02, 9.01
- 2022-04-27 0001564590-22-015866 — 2.02, 9.01
- 2022-01-27 0001564590-22-002568 — 2.02, 9.01
- 2021-11-05 0001564590-21-054934 — 5.07
- 2021-11-02 0001564590-21-053306 — 2.02, 9.01
- 2021-09-22 0001564590-21-048585 — 4.01, 9.01
- 2021-08-10 0001564590-21-043098 — 1.01
- 2021-07-28 0001564590-21-038470 — 2.02, 9.01
- 2021-05-18 0001564590-21-028693 — 1.01, 3.03, 9.01
- 2021-04-28 0001564590-21-021102 — 2.02, 9.01
- 2021-02-09 0001564590-21-005000 — 2.02, 9.01
- 2021-01-27 0001564590-21-002633 — 2.02, 9.01
- 2020-11-06 0001564590-20-051993 — 5.07
- 2020-10-28 0001564590-20-048160 — 2.02, 9.01
- 2020-10-08 0001564590-20-046117 — 2.02, 9.01
- 2020-09-11 0001564590-20-043260 — 4.01, 9.01
- 2020-08-05 0001564590-20-036431 — 2.02, 9.01
- 2020-06-01 0001564590-20-027850 — 3.03, 9.01
- 2020-05-11 0001564590-20-024216 — 2.02, 9.01
- 2020-04-08 0001564590-20-015927 — 2.02, 8.01, 9.01
- 2020-02-25 0001193125-20-047202 — 8.01, 9.01
- 2020-01-29 0001564590-20-002375 — 2.02, 9.01
- 2020-01-29 0001193125-20-017673 — 5.02, 9.01
- 2019-11-08 0001193125-19-288358 — 5.07
- 2019-10-30 0001564590-19-038508 — 2.02, 9.01
- 2019-10-25 0001564590-19-037908 — 9.01 — amendment of 0001193125-19-217553
- 2019-10-18 0001193125-19-269734 — 7.01, 9.01
- 2019-08-30 0001193125-19-235271 — 5.02 — amendment of 0001193125-19-229280
- 2019-08-26 0001193125-19-229280 — 5.02, 9.01
- 2019-08-09 0001193125-19-217553 — 1.01, 2.01, 2.03, 9.01
- 2019-07-31 0001564590-19-027208 — 2.02, 9.01
- 2019-06-26 0001193125-19-181938 — 1.01, 2.05, 9.01
- 2019-05-01 0001564590-19-014567 — 2.02, 9.01
- 2019-01-29 0001564590-19-001270 — 2.02, 9.01
- 2019-01-25 0001564590-19-001157 — 8.01, 9.01
- 2018-11-20 0001193125-18-331450 — 5.02, 9.01
- 2018-11-15 0001564590-18-029683 — 5.07
- 2018-11-02 0001564590-18-026372 — 2.02, 8.01, 9.01
- 2018-09-19 0001193125-18-276766 — 5.02
- 2018-08-08 0001564590-18-020191 — 2.02, 9.01
- 2018-06-05 0001564590-18-015067 — 3.03, 9.01
- 2018-05-08 0001564590-18-011817 — 2.02, 9.01
- 2018-05-07 0001564590-18-011264 — 1.01, 1.02, 2.03, 9.01
- 2018-02-06 0001564590-18-001403 — 2.02, 2.05, 9.01
- 2018-02-01 0001564590-18-001166 — 5.02
- 2018-01-12 0001564590-18-000462 — 9.01 — amendment of 0001193125-17-323879
- 2017-11-15 0001564590-17-023847 — 5.07
- 2017-11-07 0001564590-17-022235 — 2.02, 9.01
- 2017-11-03 0001193125-17-332828 — 9.01 — amendment of 0001193125-17-323879
- 2017-10-30 0001193125-17-323879 — 1.01, 2.01, 7.01, 9.01
- 2017-10-03 0001193125-17-302411 — 1.01, 9.01
- 2017-10-03 0001193125-17-301597 — 1.01, 1.02, 7.01, 9.01
- 2017-09-29 0001564590-17-019099 — 9.01 — amendment, the index does not say of what
- 2017-08-14 0001564590-17-017659 — 2.02, 9.01
- 2017-08-02 0001564590-17-014950 — 5.02
- 2017-07-18 0001564590-17-013557 — 1.01, 2.01, 2.03, 9.01
- 2017-06-05 0001564590-17-012126 — 3.03, 9.01
- 2017-05-03 0001564590-17-008378 — 2.02, 9.01
- 2017-03-30 0001193125-17-102344 — 1.01, 9.01
- 2017-03-07 0001193125-17-073306 — 1.01, 9.01
- 2017-02-21 0001193125-17-048182 — 5.02
- 2017-02-01 0001564590-17-000835 — 2.02, 9.01
- 2017-01-06 0001564590-17-000138 — 2.05
- 2016-11-21 0001564590-16-029539 — 5.07
- 2016-11-01 0001564590-16-026732 — 2.02, 9.01
- 2016-10-31 0001193125-16-752557 — 1.01, 2.01, 2.03
- 2016-09-15 0001193125-16-711097 — 1.01, 9.01
- 2016-08-03 0001564590-16-022347 — 2.02, 9.01
- 2016-05-19 0001564590-16-019720 — 5.02, 9.01
- 2016-05-09 0001564590-16-018660 — 3.03, 9.01
- 2016-04-27 0001564590-16-016754 — 2.02, 9.01
- 2016-02-24 0001564590-16-013189 — 8.01
- 2016-02-09 0001564590-16-012469 — 8.01
- 2016-01-28 0001564590-16-012054 — 2.02, 9.01
- 2015-11-17 0001078271-15-000136 — 5.07
- 2015-10-29 0001078271-15-000125 — 2.02, 9.01
- 2015-08-31 0001078271-15-000111 — 8.01, 9.01
- 2015-08-11 0001078271-15-000096 — 5.02
- 2015-08-06 0001078271-15-000093 — 2.02, 9.01
- 2015-06-30 0001078271-15-000089 — 1.01, 9.01
- 2015-05-20 0001078271-15-000077 — 2.05, 9.01
- 2015-05-19 0001078271-15-000075 — 3.03, 9.01
- 2015-05-06 0001078271-15-000050 — 2.02, 9.01
- 2015-05-04 0001078271-15-000048 — 5.02, 9.01
- 2015-04-29 0001078271-15-000038 — 5.02, 9.01
- 2015-04-21 0001078271-15-000034 — 5.02, 9.01
- 2015-04-09 0001078271-15-000032 — 2.02, 5.02, 9.01
- 2015-02-18 0001078271-15-000021 — 8.01
- 2015-02-17 0001078271-15-000019 — 5.02
- 2015-01-28 0001078271-15-000004 — 2.02, 9.01
- 2014-12-18 0001078271-14-000081 — 5.02, 9.01
- 2014-12-17 0001078271-14-000079 — 5.02
- 2014-11-20 0001078271-14-000075 — 1.01, 9.01
- 2014-11-17 0001078271-14-000073 — 5.07
- 2014-10-28 0001078271-14-000062 — 2.02, 9.01
- 2014-10-15 0001078271-14-000060 — 2.02, 9.01
- 2014-10-02 0001078271-14-000057 — 5.02, 9.01
- 2014-08-14 0001078271-14-000047 — 2.02, 9.01
- 2014-07-21 0001078271-14-000042 — 2.02, 9.01
- 2014-05-23 0001078271-14-000036 — 5.02, 9.01
- 2014-05-20 0001078271-14-000034 — 3.03, 9.01
- 2014-05-12 0001078271-14-000030 — 5.02
- 2014-05-08 0001078271-14-000022 — 5.02, 9.01
- 2014-05-07 0001078271-14-000018 — 2.02, 9.01 — amendment, the index does not say of what
- 2014-05-06 0001078271-14-000016 — 2.02, 9.01
- 2014-02-20 0001078271-14-000014 — 5.02, 9.01
- 2014-02-18 0001078271-14-000010 — 5.02
- 2014-02-05 0001078271-14-000006 — 2.02, 9.01
- 2014-01-13 0001104659-14-002030 — 9.01 — amendment of 0001078271-13-000058
- 2013-11-25 0001078271-13-000081 — 5.07
- 2013-11-07 0001078271-13-000064 — 5.02, 9.01
- 2013-11-04 0001078271-13-000060 — 2.02, 9.01
- 2013-11-01 0001078271-13-000058 — 1.01, 2.01, 2.03, 8.01, 9.01
- 2013-10-16 0001078271-13-000056 — 8.01, 9.01
- 2013-09-13 0001078271-13-000052 — 1.01, 8.01, 9.01
- 2013-08-23 0001078271-13-000044 — 5.02, 9.01
- 2013-08-02 0001078271-13-000042 — 5.02
- 2013-07-30 0001078271-13-000039 — 2.02, 9.01
- 2013-07-30 0001078271-13-000037 — 5.02, 9.01
- 2013-06-21 0001078271-13-000032 — 8.01
- 2013-05-01 0001078271-13-000018 — 5.02, 9.01
- 2013-04-30 0001078271-13-000015 — 2.02, 9.01
- 2013-03-01 0001078271-13-000010 — 8.01
- 2013-02-19 0001078271-13-000008 — 5.02
- 2013-01-30 0001078271-13-000004 — 2.02, 9.01
- 2013-01-07 0001078271-13-000002 — 1.01, 2.02, 2.03, 2.05, 9.01
- 2012-12-03 0001078271-12-000094 — 5.02, 5.07, 8.01
- 2012-10-31 0001078271-12-000071 — 2.02, 9.01
- 2012-10-19 0001078271-12-000069 — 1.01, 2.03, 9.01
- 2012-10-16 0001078271-12-000067 — 8.01
- 2012-10-01 0001193125-12-411392 — 5.02, 8.01, 9.01
- 2012-09-24 0001193125-12-401798 — 5.02, 9.01
- 2012-09-21 0001193125-12-399896 — 5.02, 9.01
- 2012-09-18 0001193125-12-394379 — 1.01, 5.02, 9.01
- 2012-09-12 0001193125-12-388591 — 8.01
- 2012-08-27 0001078271-12-000057 — 8.01
- 2012-08-03 0001078271-12-000041 — 7.01, 9.01
- 2012-08-01 0001078271-12-000039 — 2.02, 9.01
- 2012-07-25 0001078271-12-000037 — 8.01
- 2012-05-22 0001078271-12-000033 — 5.02, 9.01
- 2012-05-21 0001078271-12-000030 — 8.01
- 2012-05-09 0001078271-12-000028 — 5.02, 9.01
- 2012-05-02 0001078271-12-000023 — 2.02, 9.01
- 2012-04-30 0001078271-12-000020 — 3.03, 5.07, 9.01
- 2012-04-19 0001078271-12-000012 — 2.02, 5.02, 9.01
- 2012-03-12 0001078271-12-000010 — 5.02, 9.01
- 2012-02-24 0001078271-12-000008 — 8.01
- 2012-02-02 0001078271-12-000004 — 2.02, 9.01
- 2012-01-30 0001078271-12-000002 — 1.01
- 2011-12-01 0001078271-11-000104 — 8.01
- 2011-11-08 0001078271-11-000099 — 8.01
- 2011-11-02 0001078271-11-000094 — 2.02, 9.01
- 2011-10-24 0001078271-11-000089 — 8.01, 9.01
- 2011-10-11 0001078271-11-000085 — 8.01
- 2011-09-29 0001078271-11-000082 — 8.01
- 2011-09-15 0001078271-11-000070 — 5.02, 9.01
- 2011-08-11 0001078271-11-000058 — 8.01
- 2011-08-10 0001078271-11-000055 — 5.02
- 2011-08-08 0001078271-11-000045 — 5.02
- 2011-08-01 0001078271-11-000038 — 2.02, 9.01
- 2011-07-14 0001078271-11-000036 — 2.02, 2.05, 9.01
- 2011-07-12 0001078271-11-000034 — 8.01
- 2011-07-01 0001078271-11-000032 — 5.02
- 2011-06-16 0001078271-11-000030 — 8.01
- 2011-05-06 0001078271-11-000027 — 8.01, 9.01
- 2011-05-04 0001078271-11-000025 — 8.01
- 2011-04-28 0001078271-11-000020 — 2.02, 9.01
- 2011-04-27 0001078271-11-000018 — 3.03, 5.02, 5.03, 9.01
- 2011-04-11 0001078271-11-000016 — 2.02
- 2011-03-31 0001078271-11-000014 — 5.02, 5.03
- 2011-03-15 0001193125-11-066049 — 5.02, 9.01
- 2011-03-01 0001193125-11-052048 — 5.02, 9.01
- 2011-02-10 0001078271-11-000012 — 7.01, 9.01
- 2011-01-31 0001078271-11-000005 — 2.02, 5.02, 5.03, 9.01
- 2010-12-23 0001193125-10-287613 — 8.01
- 2010-12-17 0001193125-10-283495 — 5.03, 5.07, 8.01, 9.01
- 2010-11-10 0001193125-10-255861 — 4.01, 9.01
- 2010-11-01 0001193125-10-242706 — 2.02, 9.01
- 2010-10-14 0001193125-10-229518 — 1.01, 9.01
- 2010-10-06 0001193125-10-224863 — 5.02, 8.01
- 2010-09-29 0001193125-10-219705 — 1.01, 8.01
- 2010-09-08 0001193125-10-206782 — 5.02, 8.01, 9.01
- 2010-08-25 0001193125-10-196951 — 8.01
- 2010-08-09 0001193125-10-182573 — 7.01, 8.01, 9.01
- 2010-08-03 0001193125-10-175255 — 5.02, 8.01, 9.01
- 2010-08-02 0001193125-10-173697 — 2.02, 8.01, 9.01
- 2010-07-30 0001193125-10-172214 — 5.02, 8.01, 9.01
- 2010-07-22 0001193125-10-163896 — 8.01, 9.01
- 2010-07-20 0001193125-10-161832 — 5.02
- 2010-07-12 0001193125-10-157291 — 2.02, 9.01
- 2010-07-01 0001193125-10-152746 — 3.03, 9.01
- 2010-05-10 0001193125-10-114669 — 5.02, 9.01
- 2010-04-26 0001193125-10-093310 — 2.02, 9.01
- 2010-03-19 0001193125-10-061679 — 5.02, 9.01
- 2010-02-16 0001193125-10-032335 — 5.02
- 2010-02-01 0001193125-10-018202 — 2.02, 9.01
- 2010-01-29 0001193125-10-017165 — 5.02
- 2010-01-11 0001193125-10-004099 — 8.01
- 2009-10-26 0001193125-09-213846 — 2.02, 9.01 — amendment of 0001193125-09-213780
- 2009-10-26 0001193125-09-213780 — 2.02, 9.01
- 2009-10-23 0001193125-09-212871 — 2.05, 5.02, 8.01, 9.01
- 2009-10-05 0001193125-09-203522 — 2.02, 9.01
- 2009-08-04 0001193125-09-163799 — 5.02, 9.01
- 2009-07-31 0001193125-09-160772 — 5.02, 9.01
- 2009-07-30 0001193125-09-159578 — 2.02, 9.01
- 2009-07-20 0001193125-09-151500 — 5.02, 9.01
- 2009-07-08 0001193125-09-145840 — 5.02, 9.01
- 2009-05-12 0001193125-09-108340 — 5.02, 9.01
- 2009-04-23 0001193125-09-085849 — 2.02, 9.01
- 2009-03-26 0001193125-09-064502 — 2.05
- 2009-01-28 0001193125-09-013182 — 2.02, 9.01
- 2008-11-06 0001193125-08-227572 — 2.02, 9.01
- 2008-11-03 0001193125-08-222501 — 5.02
- 2008-08-11 0001193125-08-173590 — 5.02
- 2008-08-11 0001193125-08-172587 — 8.01, 9.01
- 2008-08-06 0001193125-08-167934 — 2.02, 9.01
- 2008-08-04 0001193125-08-164673 — 5.02, 9.01
- 2008-05-21 0001193125-08-119640 — 7.01, 9.01
- 2008-04-29 0001193125-08-095270 — 2.02, 9.01
- 2008-03-05 0001193125-08-047893 — 8.01
- 2008-02-19 0001193125-08-033702 — 5.02
- 2008-02-05 0001193125-08-019969 — 5.02
- 2008-01-30 0001193125-08-015378 — 2.02, 9.01
- 2007-12-27 0001193125-07-272178 — 5.03, 9.01
- 2007-10-29 0001193125-07-228368 — 2.02, 9.01
- 2007-10-25 0001193125-07-225906 — 5.02, 9.01
- 2007-10-19 0001193125-07-221578 — 5.02
- 2007-09-26 0001193125-07-207348 — 8.01
- 2007-08-07 0001193125-07-172810 — 2.02, 9.01
- 2007-08-06 0001193125-07-172147 — 5.02, 9.01
- 2007-08-06 0001193125-07-172134 — 3.01
- 2007-07-09 0001193125-07-151467 — 3.01, 9.01
- 2007-06-28 0001193125-07-145519 — 2.02, 9.01
- 2007-06-27 0001193125-07-143262 — 2.05, 3.01, 5.02
- 2007-05-18 0001193125-07-118804 — 3.01, 9.01
- 2007-05-02 0001193125-07-099280 — 2.02, 9.01
- 2007-03-29 0001193125-07-068815 — 5.02, 9.01
- 2007-02-22 0001193125-07-037181 — 3.01, 9.01
- 2007-02-08 0001193125-07-024194 — 5.02
- 2007-01-30 0001193125-07-016428 — 2.02, 9.01
- 2007-01-11 0001193125-07-004825 — 4.02, 9.01
- 2006-11-21 0001193125-06-240068 — 5.02, 9.01
- 2006-11-16 0001193125-06-237262 — 3.01, 9.01
- 2006-11-01 0001193125-06-220707 — 2.02, 9.01
- 2006-10-31 0001193125-06-219237 — 1.01, 1.02, 5.02, 5.03, 8.01, 9.01
- 2006-09-28 0001193125-06-198185 — 3.01, 9.01
- 2006-09-15 0001193125-06-191640 — 7.01, 9.01
- 2006-09-05 0001193125-06-185202 — 5.02, 9.01
- 2006-08-08 0001193125-06-165953 — 1.01, 2.02, 5.02, 9.01
- 2006-07-18 0001193125-06-148526 — 1.01
- 2006-07-10 0001193125-06-143989 — 5.02, 9.01
- 2006-05-16 0001193125-06-113698 — 5.02, 9.01
- 2006-05-01 0001193125-06-094919 — 2.02, 9.01
- 2006-04-26 0001193125-06-089397 — 1.01, 9.01
- 2006-04-07 0001193125-06-075723 — 2.02, 9.01
- 2006-02-13 0001193125-06-029073 — 1.01
- 2006-01-31 0001193125-06-016143 — 1.01
- 2006-01-30 0001193125-06-015165 — 2.02, 9.01
- 2005-12-08 0001193125-05-239157 — 1.01, 1.02, 9.01
- 2005-11-01 0001193125-05-213101 — 2.02, 9.01
- 2005-09-29 0001193125-05-193991 — 1.01, 2.02, 9.01 — amendment of 0001193125-05-162807
- 2005-08-09 0001193125-05-162807 — 1.01, 2.02, 9.01
- 2005-07-14 0001193125-05-142162 — 8.01
- 2005-06-28 0001193125-05-133050 — 1.01, 9.01
- 2005-04-18 0001193125-05-077946 — 2.02, 7.01, 9.01
- 2005-04-14 0001193125-05-076665 — 2.02, 7.01, 9.01
- 2005-01-25 0001193125-05-011466 — 2.02, 9.01
- 2004-12-07 0001193125-04-208693 — 3.01
- 2004-10-26 0001193125-04-178370 — 2.02, 9.01
- 2004-10-04 0001193125-04-166289 — 5.02, 9.01
- 2004-07-28 0001193125-04-126135 — 12, 7
- 2004-05-12 0001193125-04-086287 — 12
- 2004-04-21 0001193125-04-066557 — 12, 7
- 2004-01-22 0001193125-04-007359 — 12, 7
- 2003-12-18 0001193125-03-096351 — 5, 7
- 2003-11-04 0001193125-03-072069 — 5, 7
- 2003-10-24 0001193125-03-066551 — 12, 7
- 2003-07-25 0001193125-03-024087 — 7, 9
- 2003-04-11 0001012870-03-001706 — 7, 9
- 2003-04-08 0001021408-03-005743 — 7, 9
- 2003-01-07 0001012870-03-000039 — 5, 7
- 2002-04-29 0001012870-02-002003 — 5, 7
- 2002-02-20 0001012870-02-000792 — 5, 7
- 2001-12-13 0001012870-01-503160 — 5, 7
- 2001-11-30 0001012870-01-503010 — 5, 7
- 2001-11-02 0001012870-01-502580 — 5
- 2001-10-23 0001021408-01-508589 — 5, 7
- 2001-06-07 0001021408-01-501772 — 5, 7 — amendment of 0001021408-01-500975
- 2001-05-15 0001021408-01-501104 — 5 — amendment of 0001021408-01-500975
- 2001-05-14 0001021408-01-500975 — 5, 7
- 2001-04-06 0001012870-01-500065 — 5, 7

## late-filing notifications on or before 2025-10-30

- 2008-05-12 0001193125-08-111540 — NT 10-Q, for the period ended 2008-03-30
- 2007-05-10 0001193125-07-110075 — NT 10-Q, for the period ended 2007-04-01
- 2007-02-09 0001193125-07-025490 — NT 10-Q, for the period ended 2006-12-31
- 2006-11-13 0001193125-06-232090 — NT 10-Q, for the period ended 2006-10-01
- 2006-09-15 0001193125-06-191838 — NT 10-K, for the period ended 2006-07-02

## item 2.02 — earnings release, exhibit 99.1

[0001193125-25-254626:8k_2_02:1]
EX-99.1
2
extr-ex99_1.htm
EX-99.1

[0001193125-25-254626:8k_2_02:2]
EX-99.1

[0001193125-25-254626:8k_2_02:3]
Exhibit 99.1

[0001193125-25-254626:8k_2_02:4]
| For more information, contact: |  |  |  |  |  |  |
| Investor Relations |  |  |  | Media Contact |  |
| Stan Kovler |  |  |  | Amy Aylward |
| 919/595-4196 |  |  |  | 603/952-5138 |  |
| Investor_relations@extremenetworks.com |  |  |  | pr@extremenetworks.com |

[0001193125-25-254626:8k_2_02:5]
Extreme Networks Reports First Quarter Fiscal Year 2026 Financial Results

[0001193125-25-254626:8k_2_02:6]
Q1 revenue up 15% year-over-year, marking sixth consecutive quarter of sequential growth

[0001193125-25-254626:8k_2_02:7]
SaaS ARR up 24% YoY

[0001193125-25-254626:8k_2_02:8]
Morrisville, NC, October 29, 2025 -- Extreme Networks, Inc. (“Extreme”) (Nasdaq: EXTR) today released financial results for its first quarter of fiscal 2026 ended September 30, 2025.

[0001193125-25-254626:8k_2_02:9]
“The strength of our first quarter results was driven by improved execution, increasing customer demand and expanding interest in our AI-powered networking platform and our high-performance solutions,” said Ed Meyercord, President and CEO of Extreme. “This marked six consecutive quarters of revenue growth and three straight quarters of double-digit year-over-year gains, which is a positive sign that we are gaining share. ARR is up 24% year-over-year, as momentum grows with our subscription model. Continuing share gains in the Americas along with increased customer engagement in EMEA and APAC underscores our global momentum, highlighted by significant wins this quarter.”

[0001193125-25-254626:8k_2_02:10]
Meyercord said, “bookings for Extreme Platform ONE were solid in the quarter. Since its general availability in mid-July, customers have responded positively to the platform’s simplicity and advanced AI capabilities, which combine conversational, multimodal, and agentic technologies to automate a wide range of networking tasks. Our recently released service agent is designed to streamline network management, automate routine workflows, and enable IT teams to deliver faster, smarter support, reducing manual effort by up to 95%. These innovations position us to drive growth, expand market share, and capitalize on opportunities arising from shifts among competitors.”

[0001193125-25-254626:8k_2_02:11]
Kevin Rhodes, Executive Vice President and Chief Financial Officer stated, “First quarter results were strong, driven by continuous growth in revenue, higher margin ARR growth, and prudent expense management leading to earnings above our expectations. Our outlook for a re-acceleration of overall revenue growth to 10% at the midpoint of our outlook on a full-year basis continues to improve, and we expect that to translate to even higher earnings and cash flow than our initial forecast. I’m also pleased with our overall execution as a company.”

[0001193125-25-254626:8k_2_02:12]
Fiscal First Quarter Results:

[0001193125-25-254626:8k_2_02:13]
•
Revenue $310.2 million, up 15.2% year-over-year and up 1.1% quarter-over-quarter

[0001193125-25-254626:8k_2_02:14]
•
SaaS ARR $216.2 million, up 24.2% year-over-year and 4.1% quarter-over-quarter

[0001193125-25-254626:8k_2_02:15]
•
GAAP diluted EPS $0.04, compared to GAAP diluted loss per share $0.08 last year and GAAP diluted loss per share $0.06 last quarter

[0001193125-25-254626:8k_2_02:16]
•
Non-GAAP diluted EPS $0.22, compared to $0.17 last year and $0.25 last quarter

[0001193125-25-254626:8k_2_02:17]
•
GAAP gross margin 60.6%, compared to 63.0% last year and 61.6% last quarter

[0001193125-25-254626:8k_2_02:18]
•
Non-GAAP gross margin 61.3%, compared to 63.7% last year and 62.3% last quarter

[0001193125-25-254626:8k_2_02:19]
•
GAAP operating profit margin 3.6%, compared to GAAP operating loss margin 1.8% last year and GAAP operating loss margin 0.4% last quarter

[0001193125-25-254626:8k_2_02:20]
•
Non-GAAP operating margin 13.3 % compared to 12.4 % last year and 15.2% last quarter

[0001193125-25-254626:8k_2_02:21]
•
Shares repurchases amounted to $12.0 million during the quarter for a total of approximately 0.6 million shares

[0001193125-25-254626:8k_2_02:22]
Liquidity:

[0001193125-25-254626:8k_2_02:23]
•
Q1 ending cash balance was $209.0 million, a decrease of $22.7 million from the end of Q4 2025 and an increase of $49.5 million from the end of Q1 in the prior year.

[0001193125-25-254626:8k_2_02:24]
•
Due to a one-time settlement, Q1 net cash was $7.8 million, as compared to net cash of $51.7 million at the end of Q4 2025 and net debt of $28.0 million at the end of Q1 in the prior year.

[0001193125-25-254626:8k_2_02:25]
Recent Key Highlights:

[0001193125-25-254626:8k_2_02:26]
•
Extreme scored a major win within a major government customer in APAC to deploy a nationwide backbone powered by Extreme Fabric over SD-WAN. The network unites agencies and regional offices with secure, resilient connectivity, showcasing Extreme’s ability to drive large-scale, multi-phase government transformations with scalable, future-ready solutions.

[0001193125-25-254626:8k_2_02:27]
•
T-Mobile Center, a multi-purpose arena in downtown Kansas City that hosts top concerts, family shows, and sporting events, is now fully supported by Extreme’s wired and wireless networking solutions. The venue deployed Extreme’s Wi-Fi 7 access points, centrally managed through Extreme Platform ONE to enhance operational connectivity and elevate the digital fan experience.

[0001193125-25-254626:8k_2_02:28]
•
Doosan Enerbility, the world’s largest SMR (Small Modular Reactor) manufacturer specializing in sustainable energy and water infrastructure with operations across 40 countries, is refreshing networks across its HQ and domestic plants. Using Extreme Fabric and ExtremeCloud IQ, they’ll gain secure data management, reliable connectivity, real-time monitoring, and simplified automation—scaling operations while advancing their mission of sustainable energy solutions.

[0001193125-25-254626:8k_2_02:29]
•
Exyte, a €5 billion global pioneer in cleanroom technology and complex plant engineering, headquartered in Stuttgart, Germany has standardized exclusively on Extreme for LAN, WLAN, and NAC managed all by ExtremeCloud XIQ. Exyte benefits from a standardized, scalable network that accelerates integration of new sites, enables efficient network management, ensures security and compliance, and delivers improved performance across its mission-critical environment.

[0001193125-25-254626:8k_2_02:30]
•
Burgers Zoo, one of the largest zoos in the Netherlands at over 111 acres, recently deployed Extreme wired and wireless solutions managed by Extreme Platform ONE to ensure reliable connectivity for security cameras, ticketing, guest Wi-Fi, mobile point-of-sale systems, and smart habitats. With Platform ONE, the IT team can now monitor and optimize the entire network from a single platform, reduce troubleshooting time, and easily scale as new exhibits are added.

[0001193125-25-254626:8k_2_02:31]
•
King County Housing Authority in Washington State recently chose Extreme to drive a network refresh with a Network Infrastructure as a Service as their existing infrastructure from a large competitor was nearing end of life. The new network, which includes a mix of Extreme wired and wireless solutions, managed by Extreme Platform ONE and secured by Extreme Security Cloud NAC, will help the housing authority create more predictable costs for IT investments, manage the network from any location, and easily scale as they add new properties.

[0001193125-25-254626:8k_2_02:32]
•
Hyatt Regency Samarafushi Maldives, a new luxury resort set to open next year, is raising the bar for guests by choosing Extreme to deliver seamless Wi-Fi to both enhance guest experiences and power hotel operations. Located on a remote island, the resort is turning to ExtremeCloud™ XIQ to make it simple and flexible for its teams to manage the network from remote locations.

[0001193125-25-254626:8k_2_02:33]
•
Gateshead Council, a metro borough in England, selected Extreme to modernize and secure its entire network infrastructure with Extreme Fabric. Fabric delivers unified network management, enhanced cyber resilience, and automation capabilities that align with Gateshead’s vision for a smarter, more connected borough. This transformation will create a single, secure, and agile digital foundation, managed through Extreme Platform ONE, which will help improve service delivery, support hybrid working, and future-proof IT operations across roughly 200 sites.

[0001193125-25-254626:8k_2_02:34]
Fiscal Q1 2026 Financial Results:

[0001193125-25-254626:8k_2_02:35]
(in millions, except percentages and per share information)

[0001193125-25-254626:8k_2_02:36]
|  |  | GAAP Results |  |
|  |  | Three Months Ended |  |
|  |  | September 30,2025 |  |  | September 30,2024 |  |  | Change |  |
| Product |  | $ | 194.0 |  |  | $ | 162.3 |  |  | $ | 31.7 |  |
| Subscription and support |  |  | 116.2 |  |  |  | 106.9 |  |  |  | 9.3 |  |
| Total net revenue |  | $ | 310.2 |  |  | $ | 269.2 |  |  | $ | 41.0 |  |
| Gross margin |  |  | 60.6 | % |  |  | 63.0 | % |  |  | (2.4 | )% |
| Operating margin |  |  | 3.6 | % |  |  | (1.8 | )% |  |  | 5.4 | % |
| Net income (loss) |  | $ | 5.6 |  |  | $ | (10.5 | ) |  | $ | 16.1 |  |
| Net income (loss) per diluted share |  | $ | 0.04 |  |  | $ | (0.08 | ) |  | $ | 0.12 |  |

[0001193125-25-254626:8k_2_02:37]
|  |  | Non-GAAP Results |  |
|  |  | Three Months Ended |  |
|  |  | September 30,2025 |  |  | September 30,2024 |  |  | Change |  |
| Product |  | $ | 194.0 |  |  | $ | 162.3 |  |  | $ | 31.7 |  |
| Subscription and support |  |  | 116.2 |  |  |  | 106.9 |  |  |  | 9.3 |  |
| Total net revenue |  | $ | 310.2 |  |  | $ | 269.2 |  |  | $ | 41.0 |  |
| Gross margin |  |  | 61.3 | % |  |  | 63.7 | % |  |  | (2.4 | )% |
| Operating margin |  |  | 13.3 | % |  |  | 12.4 | % |  |  | 0.9 | % |
| Net income |  | $ | 30.1 |  |  | $ | 22.4 |  |  | $ | 7.7 |  |
| Net income per diluted share |  | $ | 0.22 |  |  | $ | 0.17 |  |  | $ | 0.05 |  |

[0001193125-25-254626:8k_2_02:38]
Extreme uses the non-GAAP free cash flow metric as a measure of operating performance. Free cash flow represents GAAP net cash provided by (used in) operating activities, less purchases of property, equipment and capitalized software development costs. Extreme considers free cash flow to be useful information for management and investors regarding the amount of cash generated by the business after the purchases of property, equipment and capitalized software development costs, which can then be used to, among other things, invest in Extreme’s business, make strategic acquisitions, and strengthen the balance sheet. A limitation of the utility of this non-GAAP free cash flow metric as a measure of financial performance is that it does not represent the total increase or decrease in the Company's cash balance for the period. The following table shows non-GAAP free cash flow calculation (in millions):

[0001193125-25-254626:8k_2_02:39]
| Free Cash Flow | Three Months Ended |  |
|  | September 30,2025 |  |  | September 30,2024 |  |
| Cash flow provided by (used in) operations | $ | (14.0 | ) |  | $ | 18.6 |  |
| Less: Capital expenditures for property, equipment and capitalized software development costs |  | (6.9 | ) |  |  | (6.9 | ) |
| Total free cash flow (deficit) | $ | (20.9 | ) |  | $ | 11.7 |  |

[0001193125-25-254626:8k_2_02:40]
SaaS ARR: Extreme uses SaaS annual recurring revenue (“SaaS ARR”) to identify the annual recurring revenue of ExtremeCloud IQ and other subscription revenue, based on the annualized value of quarterly subscription revenue and term-based licenses. We believe that SaaS ARR is an important metric because it is driven by our ability to acquire new customers and to maintain and expand our relationships with existing customers. SaaS ARR should be viewed independently of revenue or deferred revenue that are accounted for under U.S. GAAP. SaaS ARR does not have a standardized meaning and therefore may not be comparable to similarly titled measures presented by other companies. SaaS ARR is not intended to be a replacement for forecasts of revenue.

[0001193125-25-254626:8k_2_02:41]
Gross debt: Gross debt is defined as long-term debt and the current portion of long-term debt as shown on the balance sheet plus unamortized debt issuance costs, if any.

[0001193125-25-254626:8k_2_02:42]
Net cash (debt): is defined as cash and cash equivalents minus gross debt, as shown in the table below (in millions):

[0001193125-25-254626:8k_2_02:43]
| Cash and cash equivalents |  |  | Gross debt |  |  | Net cash (debt) |  |
| $ | 209.0 |  |  | $ | 201.2 |  |  | $ | 7.8 |  |

[0001193125-25-254626:8k_2_02:44]
Business Outlook:

[0001193125-25-254626:8k_2_02:45]
For its second quarter fiscal 2026, ending December 31, 2025, the Company is targeting:

[0001193125-25-254626:8k_2_02:46]
| (in millions, except percentages and per share information) | Low-End |  |  | High-End |  |
| FQ2'26 Guidance – GAAP |  |  |  |  |  |
| Total net revenue | $ | 309.0 |  |  | $ | 315.0 |  |
| Gross margin |  | 60.8 | % |  |  | 61.4 | % |
| Operating margin |  | 2.6 | % |  |  | 4.0 | % |
| Earnings per share | $ | 0.03 |  |  | $ | 0.06 |  |
| Diluted Shares outstanding used in calculating GAAP EPS |  | 135.7 |  |  |  | 135.7 |  |
| FQ2'26 Guidance – Non-GAAP |  |  |  |  |  |
| Total net revenue | $ | 309.0 |  |  | $ | 315.0 |  |
| Gross margin |  | 61.4 | % |  |  | 62.0 | % |
| Operating margin |  | 13.4 | % |  |  | 14.6 | % |
| Earnings per share | $ | 0.23 |  |  | $ | 0.25 |  |
| Diluted Shares outstanding used in calculating non-GAAP EPS |  | 135.7 |  |  |  | 135.7 |  |

[0001193125-25-254626:8k_2_02:47]
The following table shows the GAAP to non-GAAP reconciliation for Q2 FY'26 guidance:

[0001193125-25-254626:8k_2_02:48]
|  | FQ2'26 |
|  | Gross Margin |  | Operating Margin |  | Earnings per Share |
| GAAP | 60.8% - 61.4% |  | 2.6% - 4.0% |  | $0.03 - $0.06 |
| Estimated adjustments for: |  |  |  |  |  |
| Share-based compensation | 0.5% |  | 7.4% - 7.5% |  | 0.17 |
| Amortization of product intangibles | 0.1% |  | 0.1% |  | 0.00 |
| Amortization of non-product intangibles | — |  | 0.1% |  | 0.01 |
| Amortization of cloud computing implementation costs | — |  | 0.4% |  | 0.01 |
| Litigation charges | — |  | 0.5% - 0.6% |  | 0.01 |
| System transition cost | — |  | 2.1% |  | 0.05 |
| Tax adjustment | — |  | — |  | (0.06) - (0.05) |
| Non-GAAP | 61.4% - 62.0% |  | 13.4% - 14.6% |  | $0.23-$0.25 |

[0001193125-25-254626:8k_2_02:49]
The total of percentage rate changes may not equal the total change in all cases due to rounding.

[0001193125-25-254626:8k_2_02:50]
For the full year fiscal 2026, ending June 30, 2026, the Company is targeting (in millions):

[0001193125-25-254626:8k_2_02:51]
|  | Low-End |  |  | High-End |  |
| FY'26 Guidance |  |  |  |  |  |
| Total net revenue | $ | 1,247.0 |  |  | $ | 1,264.0 |  |

[0001193125-25-254626:8k_2_02:52]
Conference Call:

[0001193125-25-254626:8k_2_02:53]
Extreme will host a conference call at 8:00 a.m. Eastern (5:00 a.m. Pacific) today to review the first quarter results of fiscal 2026 as well as the business outlook for the second quarter of fiscal 2026 ending December 31, 2025, including significant factors and assumptions underlying the targets noted above. The conference call will be available to the public through a live audio web broadcast via the internet at http://investor.extremenetworks.com and a replay of the call will be available on the website for at least 7 days following the call. To access the call, please go to this link (Registration Link) and you will be provided with dial in details. If you would like to participate in the Q&A, please register here: Q&A Registration Link. To avoid delays, we encourage participants to dial into the conference call fifteen minutes ahead of the scheduled start time.

[0001193125-25-254626:8k_2_02:54]
About Extreme:

[0001193125-25-254626:8k_2_02:55]
Extreme Networks, Inc. (EXTR) is a leader in AI-driven cloud networking, focused on delivering simple and secure solutions that help businesses address challenges and enable connections among devices, applications, and users. We push the boundaries of technology, leveraging the powers of artificial intelligence, analytics, and automation. Tens of thousands of customers globally trust our AI-driven cloud networking solutions and industry-leading support to enable businesses to drive value, foster innovation, and overcome extreme challenges. For more information, visit Extreme's website at https://www.extremenetworks.com/ or LinkedIn, YouTube, X (Formerly Twitter), Facebook or Instagram

[0001193125-25-254626:8k_2_02:56]
Extreme Networks, ExtremeCloud, Extreme Platform ONE, and the Extreme Networks logo, are trademarks of Extreme Networks, Inc. or its subsidiaries in the United States and/or other countries. Other trademarks shown herein are the property of their respective owners.

[0001193125-25-254626:8k_2_02:57]
Non-GAAP Financial Measures:

[0001193125-25-254626:8k_2_02:58]
Extreme provides all financial information required in accordance with U.S. generally accepted accounting principles (“GAAP”). The Company is providing with this press release non-GAAP gross profit, non-GAAP gross margin, non-GAAP operating margin, non-GAAP operating income, non-GAAP net income, non-GAAP net income per diluted share, net cash (debt) and free cash flow. In preparing non-GAAP information, the Company has excluded, where applicable, the impact of share-based compensation, amortization of intangibles, amortization of cloud computing implementation costs, restructuring and related charges, system transition costs, litigation charges, debt refinancing charges and the tax effect of non-GAAP adjustments. The Company believes that excluding these items provides both management and investors with additional insight into its current operations, the trends affecting the Company, the Company's marketplace performance, and the Company's ability to generate cash from operations. Please note the Company’s non-GAAP measures may be different than those used by other companies. The additional non-GAAP financial information the Company presents should be considered in conjunction with, and not as a substitute for, the Company’s GAAP financial information.

[0001193125-25-254626:8k_2_02:59]
The Company has provided a non-GAAP reconciliation of the results for the periods presented in this release, which are adjusted to exclude certain items as indicated. These measures should only be used to evaluate the Company's results of operations in conjunction with the corresponding GAAP measures for comparable financial information and understanding of the Company’s ongoing performance as a business. Extreme uses both GAAP and non-GAAP measures to evaluate and manage its operations.

[0001193125-25-254626:8k_2_02:60]
Forward-Looking Statements:

[0001193125-25-254626:8k_2_02:61]
For more information about factors that could cause actual results and other future events to differ materially from those suggested or indicated by such forward-looking statements, see “Management's Discussion and Analysis of Financial Condition and Results of Operations” and “Risk Factors” included in the Company’s Annual Report on Form 10-K for the year ended June 30, 2025, and other documents of the Company on file with the Securities and Exchange Commission (available at www.sec.gov). As a result of these risks and others, actual results could vary significantly from those anticipated in this press release, and the Company’s financial condition and results of operations could be materially adversely affected. Except as required under the U.S. federal securities laws and the rules and regulations of the Securities and Exchange Commission, Extreme disclaims any obligation to update any forward-looking statements after the date of this release, whether as a result of new information, future events, developments, changes in assumptions or otherwise.

[0001193125-25-254626:8k_2_02:62]
###

[0001193125-25-254626:8k_2_02:63]
EXTREME NETWORKS, INC.

[0001193125-25-254626:8k_2_02:64]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0001193125-25-254626:8k_2_02:65]
(In thousands, except per share amounts)

[0001193125-25-254626:8k_2_02:66]
(Unaudited)

[0001193125-25-254626:8k_2_02:67]
|  |  | September 30,2025 |  |  | June 30,2025 |  |
| ASSETS |  |  |  |  |  |  |
| Current assets: |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 209,003 |  |  | $ | 231,745 |  |
| Accounts receivable, net |  |  | 145,801 |  |  |  | 126,708 |  |
| Inventories |  |  | 93,733 |  |  |  | 102,578 |  |
| Prepaid expenses and other current assets |  |  | 77,327 |  |  |  | 74,265 |  |
| Total current assets |  |  | 525,864 |  |  |  | 535,296 |  |
| Property and equipment, net |  |  | 48,076 |  |  |  | 44,366 |  |
| Operating lease right-of-use assets, net |  |  | 36,566 |  |  |  | 38,655 |  |
| Goodwill |  |  | 399,630 |  |  |  | 399,574 |  |
| Intangible assets, net |  |  | 5,432 |  |  |  | 6,541 |  |
| Other assets |  |  | 137,384 |  |  |  | 128,786 |  |
| Total assets |  | $ | 1,152,952 |  |  | $ | 1,153,218 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |  |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |  |
| Accounts payable |  | $ | 77,765 |  |  | $ | 63,939 |  |
| Accrued compensation and benefits |  |  | 52,470 |  |  |  | 62,895 |  |
| Accrued warranty |  |  | 9,625 |  |  |  | 9,684 |  |
| Current portion of deferred revenue |  |  | 325,115 |  |  |  | 325,078 |  |
| Current portion of long-term debt, net of unamortized debt issuance costs of $714 and $729, respectively |  |  | 40,536 |  |  |  | 14,271 |  |
| Current portion, operating lease liabilities |  |  | 11,593 |  |  |  | 11,456 |  |
| Other accrued liabilities |  |  | 60,384 |  |  |  | 100,552 |  |
| Total current liabilities |  |  | 577,488 |  |  |  | 587,875 |  |
| Deferred revenue, less current portion |  |  | 307,062 |  |  |  | 292,415 |  |
| Long-term debt, less current portion, net of unamortized debt issuance costs of $1,104 and $1,276, respectively |  |  | 158,896 |  |  |  | 163,724 |  |
| Operating lease liabilities, less current portion |  |  | 31,361 |  |  |  | 33,991 |  |
| Deferred income taxes |  |  | 7,009 |  |  |  | 7,033 |  |
| Other long-term liabilities |  |  | 2,573 |  |  |  | 2,596 |  |
| Commitments and contingencies |  |  |  |  |  |  |
| Stockholders’ equity: |  |  |  |  |  |  |
| Convertible preferred stock, $0.001 par value, issuable in series, 2,000 shares authorized; none issued |  |  | — |  |  |  | — |  |
| Common stock, $0.001 par value, 750,000 shares authorized; 154,839 and 152,673 shares issued, respectively; 133,653 and 132,064 shares outstanding, respectively |  |  | 155 |  |  |  | 153 |  |
| Additional paid-in-capital |  |  | 1,309,603 |  |  |  | 1,298,791 |  |
| Accumulated other comprehensive loss |  |  | (9,583 | ) |  |  | (8,137 | ) |
| Accumulated deficit |  |  | (943,818 | ) |  |  | (949,429 | ) |
| Treasury stock at cost, 21,186 shares and 20,609 shares, respectively |  |  | (287,794 | ) |  |  | (275,794 | ) |
| Total stockholders’ equity |  |  | 68,563 |  |  |  | 65,584 |  |
| Total liabilities and stockholders’ equity |  | $ | 1,152,952 |  |  | $ | 1,153,218 |  |

[0001193125-25-254626:8k_2_02:68]
EXTREME NETWORKS, INC.

[0001193125-25-254626:8k_2_02:69]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS

[0001193125-25-254626:8k_2_02:70]
(In thousands, except per share amounts)

[0001193125-25-254626:8k_2_02:71]
(Unaudited)

[0001193125-25-254626:8k_2_02:72]
|  |  | Three Months Ended |  |
|  |  | September 30,2025 |  |  | September 30,2024 |  |
| Net revenues: |  |  |  |  |  |  |
| Product |  | $ | 194,041 |  |  | $ | 162,284 |  |
| Subscription and support |  |  | 116,204 |  |  |  | 106,920 |  |
| Total net revenues |  |  | 310,245 |  |  |  | 269,204 |  |
| Cost of revenues: |  |  |  |  |  |  |
| Product |  |  | 86,128 |  |  |  | 69,402 |  |
| Subscription and support |  |  | 36,088 |  |  |  | 30,295 |  |
| Total cost of revenues |  |  | 122,216 |  |  |  | 99,697 |  |
| Gross profit: |  |  |  |  |  |  |
| Product |  |  | 107,913 |  |  |  | 92,882 |  |
| Subscription and support |  |  | 80,116 |  |  |  | 76,625 |  |
| Total gross profit |  |  | 188,029 |  |  |  | 169,507 |  |
| Operating expenses: |  |  |  |  |  |  |
| Research and development |  |  | 57,753 |  |  |  | 54,451 |  |
| Sales and marketing |  |  | 88,923 |  |  |  | 81,383 |  |
| General and administrative |  |  | 29,187 |  |  |  | 36,601 |  |
| Restructuring and related charges |  |  | 371 |  |  |  | 1,277 |  |
| Amortization of intangible assets |  |  | 500 |  |  |  | 512 |  |
| Total operating expenses |  |  | 176,734 |  |  |  | 174,224 |  |
| Operating income (loss) |  |  | 11,295 |  |  |  | (4,717 | ) |
| Interest income |  |  | 1,197 |  |  |  | 846 |  |
| Interest expense |  |  | (3,653 | ) |  |  | (4,422 | ) |
| Other expense, net |  |  | (487 | ) |  |  | (721 | ) |
| Income (loss) before income taxes |  |  | 8,352 |  |  |  | (9,014 | ) |
| Provision for income taxes |  |  | 2,741 |  |  |  | 1,490 |  |
| Net income (loss) |  | $ | 5,611 |  |  | $ | (10,504 | ) |
| Basic and diluted income (loss) per share: |  |  |  |  |  |  |
| Net income (loss) per share – basic |  | $ | 0.04 |  |  | $ | (0.08 | ) |
| Net income (loss) per share – diluted |  | $ | 0.04 |  |  | $ | (0.08 | ) |
| Shares used in per share calculation – basic |  |  | 132,973 |  |  |  | 131,176 |  |
| Shares used in per share calculation – diluted |  |  | 135,071 |  |  |  | 131,176 |  |

[0001193125-25-254626:8k_2_02:73]
EXTREME NETWORKS, INC.

[0001193125-25-254626:8k_2_02:74]
CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS

[0001193125-25-254626:8k_2_02:75]
(In thousands)

[0001193125-25-254626:8k_2_02:76]
(Unaudited)

[0001193125-25-254626:8k_2_02:77]
|  |  | Three Months Ended |  |
|  |  | September 30,2025 |  |  | September 30,2024 |  |
| Cash flows from operating activities: |  |  |  |  |  |  |
| Net income (loss) |  | $ | 5,611 |  |  | $ | (10,504 | ) |
| Adjustments to reconcile net income (loss) to net cash provided by (used in) operating activities: |  |  |  |  |  |  |
| Depreciation |  |  | 3,799 |  |  |  | 3,941 |  |
| Amortization of intangible assets |  |  | 1,111 |  |  |  | 1,136 |  |
| Reduction in carrying amount of right-of-use asset |  |  | 2,544 |  |  |  | 2,449 |  |
| Provision for credit losses |  |  | 218 |  |  |  | 14 |  |
| Share-based compensation |  |  | 21,780 |  |  |  | 19,767 |  |
| Deferred income taxes |  |  | 97 |  |  |  | 39 |  |
| Provision for (benefit from) excess and obsolete inventory |  |  | 8 |  |  |  | (624 | ) |
| Non-cash interest expense |  |  | 306 |  |  |  | 282 |  |
| Other |  |  | (76 | ) |  |  | 746 |  |
| Changes in operating assets and liabilities: |  |  |  |  |  |  |
| Accounts receivable, net |  |  | (19,311 | ) |  |  | (7,709 | ) |
| Inventories |  |  | 8,116 |  |  |  | (8,669 | ) |
| Prepaid expenses and other assets |  |  | (14,016 | ) |  |  | 3,096 |  |
| Accounts payable |  |  | 13,760 |  |  |  | 14,492 |  |
| Accrued compensation and benefits |  |  | (10,726 | ) |  |  | 2,844 |  |
| Operating lease liabilities |  |  | (2,929 | ) |  |  | (2,757 | ) |
| Deferred revenue |  |  | 16,027 |  |  |  | 3,823 |  |
| Other current and long-term liabilities |  |  | (40,317 | ) |  |  | (3,781 | ) |
| Net cash provided by (used in) operating activities |  |  | (13,998 | ) |  |  | 18,585 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |
| Capital expenditures for property, equipment and capitalized software development costs |  |  | (6,855 | ) |  |  | (6,916 | ) |
| Net cash used in investing activities |  |  | (6,855 | ) |  |  | (6,916 | ) |
| Cash flows from financing activities: |  |  |  |  |  |  |
| Borrowings under revolving facility |  |  | 25,000 |  |  |  | — |  |
| Payments on debt obligations |  |  | (3,750 | ) |  |  | (2,500 | ) |
| Payments on debt financing costs |  |  | — |  |  |  | (695 | ) |
| Repurchase of common stock |  |  | (12,000 | ) |  |  | — |  |
| Payments for tax withholdings, net of proceeds from issuance of common stock |  |  | (10,966 | ) |  |  | (5,926 | ) |
| Net cash used in financing activities |  |  | (1,716 | ) |  |  | (9,121 | ) |
| Foreign currency effect on cash and cash equivalents |  |  | (173 | ) |  |  | 299 |  |
| Net increase (decrease) in cash and cash equivalents |  |  | (22,742 | ) |  |  | 2,847 |  |
| Cash and cash equivalents at beginning of period |  |  | 231,745 |  |  |  | 156,699 |  |
| Cash and cash equivalents at end of period |  | $ | 209,003 |  |  | $ | 159,546 |  |

[0001193125-25-254626:8k_2_02:78]
Extreme Networks, Inc.

[0001193125-25-254626:8k_2_02:79]
Non-GAAP Measures of Financial Performance

[0001193125-25-254626:8k_2_02:80]
To supplement the Company's consolidated financial statements presented in accordance with U.S. generally accepted accounting principles (“GAAP”), Extreme uses non-GAAP measures of certain components of financial performance. These non-GAAP measures include non-GAAP gross profit, non-GAAP gross margin, non-GAAP operating margin, non-GAAP operating income, non-GAAP net income, non-GAAP net income per diluted share, net cash (debt) and free cash flow.

[0001193125-25-254626:8k_2_02:81]
Reconciliation to the nearest GAAP measure of all historical non-GAAP measures included in this press release can be found in the tables included with this press release.

[0001193125-25-254626:8k_2_02:82]
Non-GAAP measures presented in this press release are not in accordance with or alternative measures prepared in accordance with GAAP and may be different from non-GAAP measures used by other companies. In addition, these non-GAAP measures are not based on any comprehensive set of accounting rules or principles. Non-GAAP measures have limitations in that they do not reflect all of the amounts associated with Extreme’s results of operations as determined in accordance with GAAP. These non-GAAP measures should only be used to evaluate Extreme’s results of operations in conjunction with the corresponding GAAP measures.

[0001193125-25-254626:8k_2_02:83]
Extreme believes these non-GAAP measures, when shown in conjunction with the corresponding GAAP measures, enhance investors' and management's overall understanding of the Company's current financial performance and the Company's prospects for the future, including cash flows available to pursue opportunities to enhance stockholder value. In addition, because Extreme has historically reported certain non-GAAP results to investors, the Company believes the inclusion of non-GAAP measures provides consistency in the Company's financial reporting.

[0001193125-25-254626:8k_2_02:84]
For its internal planning process, and as discussed further below, Extreme's management uses financial statements that do not include share-based compensation expense, amortization of intangibles, amortization of cloud computing implementation costs, restructuring and related charges, system transition costs, litigation charges, debt refinancing charges, and the tax effect of non-GAAP adjustments. Extreme’s management also uses non-GAAP measures, in addition to the corresponding GAAP measures, in reviewing the Company's financial results.

[0001193125-25-254626:8k_2_02:85]
As described above, Extreme excludes the following items from one or more of its non-GAAP measures when applicable.

[0001193125-25-254626:8k_2_02:86]
Share-based compensation. Consists of associated expenses for stock options, restricted stock awards and the Company’s Employee Stock Purchase Plan. Extreme excludes share-based compensation expenses from its non-GAAP measures primarily because they are non-cash expenses that the Company does not believe are reflective of ongoing cash requirement related to its operating results. Extreme expects to incur share-based compensation expenses in future periods.

[0001193125-25-254626:8k_2_02:87]
Amortization of intangibles. Amortization of intangibles includes the monthly amortization expense of intangible assets such as developed technology, customer relationships and trademarks. The amortization of the developed technology are recorded in cost of goods sold, while the amortization for the other intangibles are recorded in operating expenses. Extreme excludes these expenses since they result from an intangible asset and for which the period expense does not impact the operations of the business and are non-cash in nature.

[0001193125-25-254626:8k_2_02:88]
Amortization of cloud computing implementation costs. Amortization of cloud computing implementation costs includes the amortization expense of the capitalized cloud computing arrangement implementation costs primarily related to our multi-phase transition of our customer relationship management solution, our configure, price, quote solution and our enterprise resource planning tools. Extreme excludes these expenses since these costs relate to enterprise-wide transformation of our core business systems which are non-routine to normal operations.

[0001193125-25-254626:8k_2_02:89]
Restructuring and related charges. Restructuring and related charges consist of severance costs for employees, asset disposal costs and other charges related to excess facilities that do not provide economic benefit to our future operations. Extreme excludes restructuring expenses since they result from events that occur outside of the ordinary course of continuing operations.

[0001193125-25-254626:8k_2_02:90]
System transition costs. System transition costs consist of costs related to direct and incremental costs incurred in connection with our multi-phase transition of our customer relationship management solution, our configure, price, quote solution and our enterprise resource planning tools that were not capitalizable. Extreme excludes these costs because we believe that these costs do not reflect future operating expenses and will be inconsistent in amount and frequency, making it difficult to contribute to a meaningful evaluation of our operating performance.

[0001193125-25-254626:8k_2_02:91]
Litigation charges. Litigation charges consist of estimated settlement and related legal expenses for non-recurring litigations offset by any proceeds received or expected to be received from insurance.

[0001193125-25-254626:8k_2_02:92]
Debt refinancing charges. Debt refinancing charges consist of costs that were not capitalizable and are included in other expense, net, that occurred in conjunction with the amendments related to our outstanding credit facility.

[0001193125-25-254626:8k_2_02:93]
Tax effect of non-GAAP adjustments. We calculate our non-GAAP provision for income taxes in accordance with the SEC guidance on non-GAAP Financial Measures Compliance and Disclosure Interpretation. We have assumed our U.S. federal and state net operating losses would have been fully consumed by the historical non-GAAP financial adjustments, eliminating the need for a full valuation allowance against our U.S. deferred tax assets which, consequently, enables our use of research and development tax credits. The non-GAAP tax provision consists of current and deferred income tax expense commensurate with the non-GAAP measure of profitability using our blended U.S. statutory tax rate of 24.6%.

[0001193125-25-254626:8k_2_02:94]
The non-GAAP provision for income taxes has typically been and is currently higher than the GAAP provision given the Company has a valuation allowance against its US and a portion of its Irish deferred tax assets due to historical losses. Once these valuation allowances are released, the non-GAAP and the GAAP provision for income taxes will be more closely aligned.

[0001193125-25-254626:8k_2_02:95]
Over the next year, our cash taxes will be driven by US federal and state taxes and the tax expense of our foreign subsidiaries, which amounts have not historically been significant, with the exception of the Company’s Canadian, German and Indian subsidiaries which perform research and development and sales and marketing activities for the Company, as well as the Company’s Irish trading subsidiaries.

[0001193125-25-254626:8k_2_02:96]
EXTREME NETWORKS, INC.

[0001193125-25-254626:8k_2_02:97]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS

[0001193125-25-254626:8k_2_02:98]
GAAP TO NON-GAAP RECONCILIATION

[0001193125-25-254626:8k_2_02:99]
(In thousands, except percentages and per share amounts)

[0001193125-25-254626:8k_2_02:100]
(Unaudited)

[0001193125-25-254626:8k_2_02:101]
| Revenues | Three Months Ended |  |
|  | September 30,2025 |  |  | September 30,2024 |  |  | June 30,2025 |  |
| Revenues – GAAP | $ | 310,245 |  |  | $ | 269,204 |  |  | $ | 307,003 |  |

[0001193125-25-254626:8k_2_02:102]
| Non-GAAP Gross Margin | Three Months Ended |  |
|  | September 30,2025 |  |  | September 30,2024 |  |  | June 30,2025 |  |
| Gross profit – GAAP | $ | 188,029 |  |  | $ | 169,507 |  |  | $ | 189,088 |  |
| Gross margin – GAAP percentage |  | 60.6 | % |  |  | 63.0 | % |  |  | 61.6 | % |
| Adjustments: |  |  |  |  |  |  |  |  |
| Share-based compensation expense, Product |  | 752 |  |  |  | 618 |  |  |  | 700 |  |
| Share-based compensation expense, Subscription and support |  | 727 |  |  |  | 689 |  |  |  | 719 |  |
| Amortization of intangibles, Product |  | 593 |  |  |  | 606 |  |  |  | 625 |  |
| Total adjustments to GAAP gross profit | $ | 2,072 |  |  | $ | 1,913 |  |  | $ | 2,044 |  |
| Gross profit – non-GAAP | $ | 190,101 |  |  | $ | 171,420 |  |  | $ | 191,132 |  |
| Gross margin – non-GAAP percentage |  | 61.3 | % |  |  | 63.7 | % |  |  | 62.3 | % |

[0001193125-25-254626:8k_2_02:103]
| Non-GAAP Operating Margin | Three Months Ended |  |
|  | September 30,2025 |  |  | September 30,2024 |  |  | June 30,2025 |  |
| GAAP operating income (loss) | $ | 11,295 |  |  | $ | (4,717 | ) |  | $ | (1,376 | ) |
| GAAP operating margin |  | 3.6 | % |  |  | (1.8 | )% |  |  | (0.4 | )% |
| Adjustments: |  |  |  |  |  |  |  |  |
| Share-based compensation expense, cost of revenues |  | 1,479 |  |  |  | 1,307 |  |  |  | 1,419 |  |
| Share-based compensation expense, R&D |  | 4,447 |  |  |  | 4,213 |  |  |  | 4,296 |  |
| Share-based compensation expense, S&M |  | 7,513 |  |  |  | 6,882 |  |  |  | 6,952 |  |
| Share-based compensation expense, G&A |  | 8,341 |  |  |  | 7,365 |  |  |  | 8,074 |  |
| Restructuring and related charges (benefit) |  | 371 |  |  |  | 1,277 |  |  |  | (379 | ) |
| Litigation charges |  | 1,937 |  |  |  | 10,715 |  |  |  | 22,006 |  |
| System transition costs |  | 4,925 |  |  |  | 5,345 |  |  |  | 4,631 |  |
| Amortization of intangibles |  | 1,093 |  |  |  | 1,118 |  |  |  | 1,140 |  |
| Total adjustments to GAAP operating income (loss) | $ | 30,106 |  |  | $ | 38,222 |  |  | $ | 48,139 |  |
| Non-GAAP operating income | $ | 41,401 |  |  | $ | 33,505 |  |  | $ | 46,763 |  |
| Non-GAAP operating margin |  | 13.3 | % |  |  | 12.4 | % |  |  | 15.2 | % |

[0001193125-25-254626:8k_2_02:104]
| Non-GAAP Net Income | Three Months Ended |  |
|  | September 30,2025 |  |  | September 30,2024 |  |  | June 30,2025 |  |
| GAAP net income (loss) | $ | 5,611 |  |  | $ | (10,504 | ) |  | $ | (7,803 | ) |
| Adjustments: |  |  |  |  |  |  |  |  |
| Share-based compensation expense |  | 21,780 |  |  |  | 19,767 |  |  |  | 20,741 |  |
| Restructuring and related charges (benefit) |  | 371 |  |  |  | 1,277 |  |  |  | (379 | ) |
| Litigation charges |  | 1,937 |  |  |  | 10,715 |  |  |  | 22,006 |  |
| System transition costs |  | 4,925 |  |  |  | 5,345 |  |  |  | 4,631 |  |
| Amortization of intangibles |  | 1,093 |  |  |  | 1,118 |  |  |  | 1,140 |  |
| Debt refinancing charges |  | — |  |  |  | 79 |  |  |  | — |  |
| Tax effect of non-GAAP adjustments |  | (5,573 | ) |  |  | (5,398 | ) |  |  | (6,843 | ) |
| Total adjustments to GAAP net income (loss) | $ | 24,533 |  |  | $ | 32,903 |  |  | $ | 41,296 |  |
| Non-GAAP net income | $ | 30,144 |  |  | $ | 22,399 |  |  | $ | 33,493 |  |
| Earnings (loss) per share |  |  |  |  |  |  |  |  |
| GAAP net income (loss) per share – diluted | $ | 0.04 |  |  | $ | (0.08 | ) |  | $ | (0.06 | ) |
| Non-GAAP net income per share – diluted | $ | 0.22 |  |  | $ | 0.17 |  |  | $ | 0.25 |  |
| Shares used in net income (loss) per share – diluted: |  |  |  |  |  |  |  |  |
| GAAP shares used in per share calculation – basic |  | 132,973 |  |  |  | 131,176 |  |  |  | 132,808 |  |
| Potentially dilutive equity awards |  | 2,098 |  |  |  | 1,103 |  |  |  | 1,492 |  |
| GAAP and Non-GAAP shares used in per share calculation – diluted |  | 135,071 |  |  |  | 132,279 |  |  |  | 134,300 |  |
