# EXTR 8-K — 0001564590-16-012054 filed 2016-01-28

## item codes, every 8-K on or before 2016-02-02

- 2016-01-28 0001564590-16-012054 — 2.02, 9.01
- 2015-11-17 0001078271-15-000136 — 5.07
- 2015-10-29 0001078271-15-000125 — 2.02, 9.01
- 2015-08-31 0001078271-15-000111 — 8.01, 9.01
- 2015-08-11 0001078271-15-000096 — 5.02
- 2015-08-06 0001078271-15-000093 — 2.02, 9.01
- 2015-06-30 0001078271-15-000089 — 1.01, 9.01
- 2015-05-20 0001078271-15-000077 — 2.05, 9.01
- 2015-05-19 0001078271-15-000075 — 3.03, 9.01
- 2015-05-06 0001078271-15-000050 — 2.02, 9.01
- 2015-05-04 0001078271-15-000048 — 5.02, 9.01
- 2015-04-29 0001078271-15-000038 — 5.02, 9.01
- 2015-04-21 0001078271-15-000034 — 5.02, 9.01
- 2015-04-09 0001078271-15-000032 — 2.02, 5.02, 9.01
- 2015-02-18 0001078271-15-000021 — 8.01
- 2015-02-17 0001078271-15-000019 — 5.02
- 2015-01-28 0001078271-15-000004 — 2.02, 9.01
- 2014-12-18 0001078271-14-000081 — 5.02, 9.01
- 2014-12-17 0001078271-14-000079 — 5.02
- 2014-11-20 0001078271-14-000075 — 1.01, 9.01
- 2014-11-17 0001078271-14-000073 — 5.07
- 2014-10-28 0001078271-14-000062 — 2.02, 9.01
- 2014-10-15 0001078271-14-000060 — 2.02, 9.01
- 2014-10-02 0001078271-14-000057 — 5.02, 9.01
- 2014-08-14 0001078271-14-000047 — 2.02, 9.01
- 2014-07-21 0001078271-14-000042 — 2.02, 9.01
- 2014-05-23 0001078271-14-000036 — 5.02, 9.01
- 2014-05-20 0001078271-14-000034 — 3.03, 9.01
- 2014-05-12 0001078271-14-000030 — 5.02
- 2014-05-08 0001078271-14-000022 — 5.02, 9.01
- 2014-05-07 0001078271-14-000018 — 2.02, 9.01 — amendment, the index does not say of what
- 2014-05-06 0001078271-14-000016 — 2.02, 9.01
- 2014-02-20 0001078271-14-000014 — 5.02, 9.01
- 2014-02-18 0001078271-14-000010 — 5.02
- 2014-02-05 0001078271-14-000006 — 2.02, 9.01
- 2014-01-13 0001104659-14-002030 — 9.01 — amendment of 0001078271-13-000058
- 2013-11-25 0001078271-13-000081 — 5.07
- 2013-11-07 0001078271-13-000064 — 5.02, 9.01
- 2013-11-04 0001078271-13-000060 — 2.02, 9.01
- 2013-11-01 0001078271-13-000058 — 1.01, 2.01, 2.03, 8.01, 9.01
- 2013-10-16 0001078271-13-000056 — 8.01, 9.01
- 2013-09-13 0001078271-13-000052 — 1.01, 8.01, 9.01
- 2013-08-23 0001078271-13-000044 — 5.02, 9.01
- 2013-08-02 0001078271-13-000042 — 5.02
- 2013-07-30 0001078271-13-000039 — 2.02, 9.01
- 2013-07-30 0001078271-13-000037 — 5.02, 9.01
- 2013-06-21 0001078271-13-000032 — 8.01
- 2013-05-01 0001078271-13-000018 — 5.02, 9.01
- 2013-04-30 0001078271-13-000015 — 2.02, 9.01
- 2013-03-01 0001078271-13-000010 — 8.01
- 2013-02-19 0001078271-13-000008 — 5.02
- 2013-01-30 0001078271-13-000004 — 2.02, 9.01
- 2013-01-07 0001078271-13-000002 — 1.01, 2.02, 2.03, 2.05, 9.01
- 2012-12-03 0001078271-12-000094 — 5.02, 5.07, 8.01
- 2012-10-31 0001078271-12-000071 — 2.02, 9.01
- 2012-10-19 0001078271-12-000069 — 1.01, 2.03, 9.01
- 2012-10-16 0001078271-12-000067 — 8.01
- 2012-10-01 0001193125-12-411392 — 5.02, 8.01, 9.01
- 2012-09-24 0001193125-12-401798 — 5.02, 9.01
- 2012-09-21 0001193125-12-399896 — 5.02, 9.01
- 2012-09-18 0001193125-12-394379 — 1.01, 5.02, 9.01
- 2012-09-12 0001193125-12-388591 — 8.01
- 2012-08-27 0001078271-12-000057 — 8.01
- 2012-08-03 0001078271-12-000041 — 7.01, 9.01
- 2012-08-01 0001078271-12-000039 — 2.02, 9.01
- 2012-07-25 0001078271-12-000037 — 8.01
- 2012-05-22 0001078271-12-000033 — 5.02, 9.01
- 2012-05-21 0001078271-12-000030 — 8.01
- 2012-05-09 0001078271-12-000028 — 5.02, 9.01
- 2012-05-02 0001078271-12-000023 — 2.02, 9.01
- 2012-04-30 0001078271-12-000020 — 3.03, 5.07, 9.01
- 2012-04-19 0001078271-12-000012 — 2.02, 5.02, 9.01
- 2012-03-12 0001078271-12-000010 — 5.02, 9.01
- 2012-02-24 0001078271-12-000008 — 8.01
- 2012-02-02 0001078271-12-000004 — 2.02, 9.01
- 2012-01-30 0001078271-12-000002 — 1.01
- 2011-12-01 0001078271-11-000104 — 8.01
- 2011-11-08 0001078271-11-000099 — 8.01
- 2011-11-02 0001078271-11-000094 — 2.02, 9.01
- 2011-10-24 0001078271-11-000089 — 8.01, 9.01
- 2011-10-11 0001078271-11-000085 — 8.01
- 2011-09-29 0001078271-11-000082 — 8.01
- 2011-09-15 0001078271-11-000070 — 5.02, 9.01
- 2011-08-11 0001078271-11-000058 — 8.01
- 2011-08-10 0001078271-11-000055 — 5.02
- 2011-08-08 0001078271-11-000045 — 5.02
- 2011-08-01 0001078271-11-000038 — 2.02, 9.01
- 2011-07-14 0001078271-11-000036 — 2.02, 2.05, 9.01
- 2011-07-12 0001078271-11-000034 — 8.01
- 2011-07-01 0001078271-11-000032 — 5.02
- 2011-06-16 0001078271-11-000030 — 8.01
- 2011-05-06 0001078271-11-000027 — 8.01, 9.01
- 2011-05-04 0001078271-11-000025 — 8.01
- 2011-04-28 0001078271-11-000020 — 2.02, 9.01
- 2011-04-27 0001078271-11-000018 — 3.03, 5.02, 5.03, 9.01
- 2011-04-11 0001078271-11-000016 — 2.02
- 2011-03-31 0001078271-11-000014 — 5.02, 5.03
- 2011-03-15 0001193125-11-066049 — 5.02, 9.01
- 2011-03-01 0001193125-11-052048 — 5.02, 9.01
- 2011-02-10 0001078271-11-000012 — 7.01, 9.01
- 2011-01-31 0001078271-11-000005 — 2.02, 5.02, 5.03, 9.01
- 2010-12-23 0001193125-10-287613 — 8.01
- 2010-12-17 0001193125-10-283495 — 5.03, 5.07, 8.01, 9.01
- 2010-11-10 0001193125-10-255861 — 4.01, 9.01
- 2010-11-01 0001193125-10-242706 — 2.02, 9.01
- 2010-10-14 0001193125-10-229518 — 1.01, 9.01
- 2010-10-06 0001193125-10-224863 — 5.02, 8.01
- 2010-09-29 0001193125-10-219705 — 1.01, 8.01
- 2010-09-08 0001193125-10-206782 — 5.02, 8.01, 9.01
- 2010-08-25 0001193125-10-196951 — 8.01
- 2010-08-09 0001193125-10-182573 — 7.01, 8.01, 9.01
- 2010-08-03 0001193125-10-175255 — 5.02, 8.01, 9.01
- 2010-08-02 0001193125-10-173697 — 2.02, 8.01, 9.01
- 2010-07-30 0001193125-10-172214 — 5.02, 8.01, 9.01
- 2010-07-22 0001193125-10-163896 — 8.01, 9.01
- 2010-07-20 0001193125-10-161832 — 5.02
- 2010-07-12 0001193125-10-157291 — 2.02, 9.01
- 2010-07-01 0001193125-10-152746 — 3.03, 9.01
- 2010-05-10 0001193125-10-114669 — 5.02, 9.01
- 2010-04-26 0001193125-10-093310 — 2.02, 9.01
- 2010-03-19 0001193125-10-061679 — 5.02, 9.01
- 2010-02-16 0001193125-10-032335 — 5.02
- 2010-02-01 0001193125-10-018202 — 2.02, 9.01
- 2010-01-29 0001193125-10-017165 — 5.02
- 2010-01-11 0001193125-10-004099 — 8.01
- 2009-10-26 0001193125-09-213846 — 2.02, 9.01 — amendment of 0001193125-09-213780
- 2009-10-26 0001193125-09-213780 — 2.02, 9.01
- 2009-10-23 0001193125-09-212871 — 2.05, 5.02, 8.01, 9.01
- 2009-10-05 0001193125-09-203522 — 2.02, 9.01
- 2009-08-04 0001193125-09-163799 — 5.02, 9.01
- 2009-07-31 0001193125-09-160772 — 5.02, 9.01
- 2009-07-30 0001193125-09-159578 — 2.02, 9.01
- 2009-07-20 0001193125-09-151500 — 5.02, 9.01
- 2009-07-08 0001193125-09-145840 — 5.02, 9.01
- 2009-05-12 0001193125-09-108340 — 5.02, 9.01
- 2009-04-23 0001193125-09-085849 — 2.02, 9.01
- 2009-03-26 0001193125-09-064502 — 2.05
- 2009-01-28 0001193125-09-013182 — 2.02, 9.01
- 2008-11-06 0001193125-08-227572 — 2.02, 9.01
- 2008-11-03 0001193125-08-222501 — 5.02
- 2008-08-11 0001193125-08-173590 — 5.02
- 2008-08-11 0001193125-08-172587 — 8.01, 9.01
- 2008-08-06 0001193125-08-167934 — 2.02, 9.01
- 2008-08-04 0001193125-08-164673 — 5.02, 9.01
- 2008-05-21 0001193125-08-119640 — 7.01, 9.01
- 2008-04-29 0001193125-08-095270 — 2.02, 9.01
- 2008-03-05 0001193125-08-047893 — 8.01
- 2008-02-19 0001193125-08-033702 — 5.02
- 2008-02-05 0001193125-08-019969 — 5.02
- 2008-01-30 0001193125-08-015378 — 2.02, 9.01
- 2007-12-27 0001193125-07-272178 — 5.03, 9.01
- 2007-10-29 0001193125-07-228368 — 2.02, 9.01
- 2007-10-25 0001193125-07-225906 — 5.02, 9.01
- 2007-10-19 0001193125-07-221578 — 5.02
- 2007-09-26 0001193125-07-207348 — 8.01
- 2007-08-07 0001193125-07-172810 — 2.02, 9.01
- 2007-08-06 0001193125-07-172147 — 5.02, 9.01
- 2007-08-06 0001193125-07-172134 — 3.01
- 2007-07-09 0001193125-07-151467 — 3.01, 9.01
- 2007-06-28 0001193125-07-145519 — 2.02, 9.01
- 2007-06-27 0001193125-07-143262 — 2.05, 3.01, 5.02
- 2007-05-18 0001193125-07-118804 — 3.01, 9.01
- 2007-05-02 0001193125-07-099280 — 2.02, 9.01
- 2007-03-29 0001193125-07-068815 — 5.02, 9.01
- 2007-02-22 0001193125-07-037181 — 3.01, 9.01
- 2007-02-08 0001193125-07-024194 — 5.02
- 2007-01-30 0001193125-07-016428 — 2.02, 9.01
- 2007-01-11 0001193125-07-004825 — 4.02, 9.01
- 2006-11-21 0001193125-06-240068 — 5.02, 9.01
- 2006-11-16 0001193125-06-237262 — 3.01, 9.01
- 2006-11-01 0001193125-06-220707 — 2.02, 9.01
- 2006-10-31 0001193125-06-219237 — 1.01, 1.02, 5.02, 5.03, 8.01, 9.01
- 2006-09-28 0001193125-06-198185 — 3.01, 9.01
- 2006-09-15 0001193125-06-191640 — 7.01, 9.01
- 2006-09-05 0001193125-06-185202 — 5.02, 9.01
- 2006-08-08 0001193125-06-165953 — 1.01, 2.02, 5.02, 9.01
- 2006-07-18 0001193125-06-148526 — 1.01
- 2006-07-10 0001193125-06-143989 — 5.02, 9.01
- 2006-05-16 0001193125-06-113698 — 5.02, 9.01
- 2006-05-01 0001193125-06-094919 — 2.02, 9.01
- 2006-04-26 0001193125-06-089397 — 1.01, 9.01
- 2006-04-07 0001193125-06-075723 — 2.02, 9.01
- 2006-02-13 0001193125-06-029073 — 1.01
- 2006-01-31 0001193125-06-016143 — 1.01
- 2006-01-30 0001193125-06-015165 — 2.02, 9.01
- 2005-12-08 0001193125-05-239157 — 1.01, 1.02, 9.01
- 2005-11-01 0001193125-05-213101 — 2.02, 9.01
- 2005-09-29 0001193125-05-193991 — 1.01, 2.02, 9.01 — amendment of 0001193125-05-162807
- 2005-08-09 0001193125-05-162807 — 1.01, 2.02, 9.01
- 2005-07-14 0001193125-05-142162 — 8.01
- 2005-06-28 0001193125-05-133050 — 1.01, 9.01
- 2005-04-18 0001193125-05-077946 — 2.02, 7.01, 9.01
- 2005-04-14 0001193125-05-076665 — 2.02, 7.01, 9.01
- 2005-01-25 0001193125-05-011466 — 2.02, 9.01
- 2004-12-07 0001193125-04-208693 — 3.01
- 2004-10-26 0001193125-04-178370 — 2.02, 9.01
- 2004-10-04 0001193125-04-166289 — 5.02, 9.01
- 2004-07-28 0001193125-04-126135 — 12, 7
- 2004-05-12 0001193125-04-086287 — 12
- 2004-04-21 0001193125-04-066557 — 12, 7
- 2004-01-22 0001193125-04-007359 — 12, 7
- 2003-12-18 0001193125-03-096351 — 5, 7
- 2003-11-04 0001193125-03-072069 — 5, 7
- 2003-10-24 0001193125-03-066551 — 12, 7
- 2003-07-25 0001193125-03-024087 — 7, 9
- 2003-04-11 0001012870-03-001706 — 7, 9
- 2003-04-08 0001021408-03-005743 — 7, 9
- 2003-01-07 0001012870-03-000039 — 5, 7
- 2002-04-29 0001012870-02-002003 — 5, 7
- 2002-02-20 0001012870-02-000792 — 5, 7
- 2001-12-13 0001012870-01-503160 — 5, 7
- 2001-11-30 0001012870-01-503010 — 5, 7
- 2001-11-02 0001012870-01-502580 — 5
- 2001-10-23 0001021408-01-508589 — 5, 7
- 2001-06-07 0001021408-01-501772 — 5, 7 — amendment of 0001021408-01-500975
- 2001-05-15 0001021408-01-501104 — 5 — amendment of 0001021408-01-500975
- 2001-05-14 0001021408-01-500975 — 5, 7
- 2001-04-06 0001012870-01-500065 — 5, 7

## late-filing notifications on or before 2016-02-02

- 2008-05-12 0001193125-08-111540 — NT 10-Q, for the period ended 2008-03-30
- 2007-05-10 0001193125-07-110075 — NT 10-Q, for the period ended 2007-04-01
- 2007-02-09 0001193125-07-025490 — NT 10-Q, for the period ended 2006-12-31
- 2006-11-13 0001193125-06-232090 — NT 10-Q, for the period ended 2006-10-01
- 2006-09-15 0001193125-06-191838 — NT 10-K, for the period ended 2006-07-02

## item 2.02 — earnings release, exhibit 99.1

[0001564590-16-012054:8k_2_02:1]
EX-99
2
extr-ex991_6.htm
EX-99.1

[0001564590-16-012054:8k_2_02:2]
extr-ex991_6.htm

[0001564590-16-012054:8k_2_02:3]
Exhibit 99.1

[0001564590-16-012054:8k_2_02:4]
FOR IMMEDIATE RELEASE

[0001564590-16-012054:8k_2_02:5]
| For more information, contact: |  |  |
| Investor Relations |  | Media Contact |
| 408/579-3456 |  | 617/624-3231 |
| fyoshino@extremenetworks.com |  | ExtremeUS@racepointglobal.com |

[0001564590-16-012054:8k_2_02:6]
Extreme Networks Reports Second Quarter Fiscal Year 2016 Financial Results

[0001564590-16-012054:8k_2_02:7]
Q2 GAAP Revenue of $139.3 Million & Non-GAAP Revenue of $139.7 Million

[0001564590-16-012054:8k_2_02:8]
Q2 GAAP EPS Loss of $0.07 & Non-GAAP EPS Income of $0.09

[0001564590-16-012054:8k_2_02:9]
SAN JOSE, Calif., January 28, 2016 -- Extreme Networks, Inc. (Nasdaq: EXTR) today released financial results for its fiscal second quarter ended December 31, 2015.  Second quarter GAAP revenue was $139.3 million and non-GAAP revenue was $139.7 million.  GAAP net loss for the second fiscal quarter was $7.2 million, or $0.07 per basic share, and non-GAAP net income was $9.0 million, or $0.09 per diluted share.

[0001564590-16-012054:8k_2_02:10]
“We delivered another quarter of strong results across all geographies reflecting the continued success of our go-to-market strategy,” stated Ed Meyercord, President and CEO of Extreme Networks.  “Revenue growth in the US was driven by strength in education with the expected rebound in E-Rate business, while EMEA generated strong results with government and manufacturing customers,” said Meyercord.  “In addition, our continued focus on controlling costs has delivered significant operating and net income expansion year over year.”

[0001564590-16-012054:8k_2_02:11]
“Now that we’ve laid the groundwork over the past two quarters,” Meyercord continued, “we are concentrating our efforts on new product introductions and executing our solutions-based selling initiatives in our target vertical markets.  With better visibility into our pipeline and strong business momentum, we are projecting year over year growth for the March quarter.”

[0001564590-16-012054:8k_2_02:12]
Recent Key Events:

[0001564590-16-012054:8k_2_02:13]
|  | · | Unveiled First Flow-based 802.11ac Wave 2 Wireless Solution. During the quarter, we expanded our wireless portfolio with high-density 802.11ac Wave 2 access points (APs) to address the network demands driven by mobility, smart devices and the rapidly expanding wireless enabled Internet of Things. |

[0001564590-16-012054:8k_2_02:14]
|  | · | Enhanced Partner Program. To further empower and reward our channel partners, we announced several enhancements to the Extreme Partner Network (EPN) aimed at delivering increased predictability, expanded training and solution-based incentive programs. We also announced two new ExtremeWorks Managed Services offerings to allow partners to take advantage of new consumption models while evolving their businesses to be better positioned for future opportunities. |

[0001564590-16-012054:8k_2_02:15]
|  | · | Integrations with VMware. To accelerate the adoption of the Software-Defined Data Center (SDDC) for SMBs and enterprises, we announced extended integration offerings with VMware to deliver IT management and analytics solutions. As part of the collaboration, our NetSight advanced network management system is now integrated with the VMware vRealize® Suite. |

[0001564590-16-012054:8k_2_02:16]
|  | · | Key Customer Wins in Focus Markets. Extreme Networks continued to showcase customer momentum across the global education, healthcare, manufacturing, sports and entertainment, and government markets. Notable Customer wins include the Matanuska-Susitna Borough School District, Royal Bolton NHS Trust, Instituto Nacional de Antropologia e Historia, Becker Stahl-Service GmbH, SAK Holdings, Comision Reguladora de Energia,Twin Rivers Unified School District. In addition, Extreme was awarded NRG Stadium, Home of the Houston Texans and Super Bowl LI. |

[0001564590-16-012054:8k_2_02:17]
Fiscal Q2 2016 Financial Metrics:

[0001564590-16-012054:8k_2_02:18]
|  |  | 2016 |  |  | 2015 |  |  | Change |  |
| GAAP Net Revenue |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 105.4 |  |  | $ | 112.5 |  |  | $ | (7.1 | ) |  |  | (6 | )% |
| Service |  |  | 34.0 |  |  |  | 34.7 |  |  |  | (0.8 | ) |  |  | (2 | )% |
| Total Net Revenue |  | $ | 139.3 |  |  | $ | 147.2 |  |  | $ | (7.9 | ) |  |  | (5 | )% |
| Gross Margin |  |  | 50.4 | % |  |  | 51.1 | % |  |  | (.7 | )% |  |  | (1 | )% |
| Operating Loss |  |  | (3.8 | )% |  |  | (7.5 | )% |  |  | 3.7 | % |  |  | (49 | )% |
| Net Loss |  | $ | (7.2 | ) |  | $ | (13.1 | ) |  | $ | 5.9 |  |  |  | (45 | )% |
| Loss per basic share |  | $ | (0.07 | ) |  | $ | (0.13 | ) |  | $ | 0.06 |  |  |  | (46 | )% |
| Non-GAAP Net Revenue |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 105.4 |  |  | $ | 112.5 |  |  | $ | (7.1 | ) |  |  | (6 | )% |
| Service |  |  | 34.3 |  |  |  | 35.5 |  |  |  | (1.2 | ) |  |  | (3 | )% |
| Total Net Revenue |  | $ | 139.7 |  |  | $ | 148.0 |  |  | $ | (8.3 | ) |  |  | (6 | )% |
| Gross Margin |  |  | 53.6 | % |  |  | 54.6 | % |  |  | (1.0 | )% |  |  | (2 | )% |
| Operating Margin |  |  | 7.8 | % |  |  | 4.5 | % |  |  | 3.3 | % |  |  | 72 | % |
| Net Income |  | $ | 9.0 |  |  | $ | 4.7 |  |  | $ | 4.3 |  |  |  | 91 | % |
| Earnings per diluted share |  | $ | 0.09 |  |  | $ | 0.05 |  |  | $ | 0.04 |  |  |  | 71 | % |

[0001564590-16-012054:8k_2_02:19]
|  | · | Cash and investments ended the quarter at $85.9 million, as compared to $82.0 million from the prior quarter. |

[0001564590-16-012054:8k_2_02:20]
|  | · | Accounts receivable balance ending Q2 was $73.1 million, with days sales outstanding (DSO) of 48. |

[0001564590-16-012054:8k_2_02:21]
|  | · | Inventory ending Q2 was $56.6 million, a decrease of $5.1 million from the prior quarter. |

[0001564590-16-012054:8k_2_02:22]
Business Outlook:

[0001564590-16-012054:8k_2_02:23]
For its third quarter of fiscal 2016 ending March 31, 2016, the Company is targeting GAAP revenue in a range of $117.6 million to $127.6 million with non-GAAP revenue in a range of $118.0 million to $128.0 million. GAAP gross margin is targeted between 49.9% and 51.2% and non-GAAP gross margin targeted between 53.5% and 54.5%. Operating expenses are targeted to be between $69.5 million and $72.0 million on a GAAP basis and $62.0 million to $64.5 million on a non-GAAP basis. GAAP net loss is targeted to be between $9.0 million to $13.0 million, or $0.09 to $0.13 per share.  Non-GAAP earnings are targeted in a range of a net loss of $1.0 million to net income of $3.0 million, or a loss of $0.01 to net income of $0.03 per diluted share. The GAAP and non-GAAP net income (loss) targets are based on an estimated 103 million and 106 million average outstanding shares, respectively. Targeted non-GAAP earnings exclude expenses related to stock-based compensation expense, the amortization of acquired

[0001564590-16-012054:8k_2_02:24]
intangibles, acquisition and integration related expenses, restructuring expenses, litigation expenses, overhead adjustments and the purchase accounting adjustment related to deferred service revenue.

[0001564590-16-012054:8k_2_02:25]
Conference Call:

[0001564590-16-012054:8k_2_02:26]
Extreme Networks will host a conference call at 8:00 a.m. Eastern (5:00 a.m. Pacific) today to review the second fiscal quarter results and third fiscal quarter 2016 business outlook, including significant factors and assumptions underlying the targets noted above. The conference call will be available to the public through a live audio web broadcast via the Internet at http://investor.extremenetworks.com and a replay of the call will be available on the website through October 28, 2016.  The conference call may also be heard by dialing 1-877-303-9826 (international callers dial 1-224-357-2194). Supplemental financial information to be discussed during the conference call will be posted in the Investor Relations section of the Company's website www.extremenetworks.com including the non-GAAP reconciliation attached to this press release. The encore recording can be accessed by dialing (855) 859-2056 /or international 1 (404) 537-3406; Conference ID #:21560759.

[0001564590-16-012054:8k_2_02:27]
About Extreme Networks:

[0001564590-16-012054:8k_2_02:28]
Extreme Networks, Inc. (EXTR) delivers software-driven networking solutions that help IT departments everywhere deliver the ultimate business outcome: stronger connections with customers, partners and employees. Wired to wireless, desktop to datacenter, we go to extreme measures for our 20,000-plus customers in more than 80 countries, delivering 100% insourced support to organizations large and small, including some of the world’s leading names in business, education, government, healthcare, manufacturing and hospitality. Founded in 1996, Extreme is headquartered in San Jose, California. For more information, visit Extreme's website or call 1-888-257-3000.

[0001564590-16-012054:8k_2_02:29]
Extreme Networks and the Extreme Networks logo, ExtremeWireless, ExtremeControl and ExtremeAnalytics are either trademarks or registered trademarks of Extreme Networks, Inc. in the United States and/or other countries.

[0001564590-16-012054:8k_2_02:30]
Non-GAAP Financial Measures:

[0001564590-16-012054:8k_2_02:31]
Extreme Networks provides all financial information required in accordance with generally accepted accounting principles (GAAP). The Company is providing with this press release non-GAAP revenue, non-GAAP gross margins, non-GAAP operating expenses, and non-GAAP income (loss) per share. In preparing non-GAAP information, the Company has excluded, where applicable, the impact of acquisition and integration costs, purchase accounting adjustments, amortization of acquired intangibles, restructuring charges, litigation expenses, share-based compensation and overhead adjustments.  The Company believes that excluding these items provides both management and investors with additional insight into its current operations, the trends affecting the Company, the Company's marketplace performance, and the Company's ability to generate cash from operations. Please note that the Company's non-GAAP measures may be different than those used by other companies. The additional non-GAAP financial information the Company presents should be considered in conjunction with, and not as a substitute for, the Company's GAAP financial information.  The Company has provided a non-GAAP reconciliation of the results for the periods presented in this release, which are adjusted to exclude certain items as indicated.  These measures should only be used to evaluate the Company's results of operations in conjunction with the corresponding GAAP measures for comparable financial information and understanding of the Company's ongoing performance as a business. Extreme Networks uses both GAAP and non-GAAP measures to evaluate and manage its operations.

[0001564590-16-012054:8k_2_02:32]
Forward Looking Statements:

[0001564590-16-012054:8k_2_02:33]
More information about potential factors that could affect the Company's business and financial results is included in the Company’s filings with the Securities and Exchange Commission, including, without limitation, under the captions: "Management's Discussion and Analysis of Financial Condition and Results of Operations," and "Risk Factors".  Except as required under the U.S. federal securities laws and the rules and regulations of the U.S. Securities and Exchange Commission, Extreme Networks disclaims any obligation to update any forward-looking statements after the date of this release, whether as a result of new information, future events, developments, changes in assumptions or otherwise.

[0001564590-16-012054:8k_2_02:34]
EXTREME NETWORKS, INC.

[0001564590-16-012054:8k_2_02:35]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0001564590-16-012054:8k_2_02:36]
(In thousands)

[0001564590-16-012054:8k_2_02:37]
(Unaudited)

[0001564590-16-012054:8k_2_02:38]
|  |  | December 31, 2015 |  |  | June 30, 2015 |  |
| ASSETS |  |  |  |  |  |  |  |  |
| Current assets: |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 85,865 |  |  | $ | 76,225 |  |
| Accounts receivable, net of allowances of $6,464 at December 31, 2015 and $2,396 at June 30, 2015 |  |  | 73,110 |  |  |  | 92,737 |  |
| Inventories |  |  | 56,601 |  |  |  | 58,014 |  |
| Deferred income taxes |  |  | 705 |  |  |  | 760 |  |
| Prepaid expenses and other current assets |  |  | 9,925 |  |  |  | 10,258 |  |
| Total current assets |  |  | 226,206 |  |  |  | 237,994 |  |
| Property and equipment, net |  |  | 32,948 |  |  |  | 39,862 |  |
| Intangible assets, net |  |  | 35,138 |  |  |  | 52,132 |  |
| Goodwill |  |  | 70,877 |  |  |  | 70,877 |  |
| Other assets |  |  | 27,618 |  |  |  | 27,795 |  |
| Total assets |  | $ | 392,787 |  |  | $ | 428,660 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |  |  |  |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |  |  |  |
| Current portion of long-term debt |  | $ | 14,625 |  |  | $ | 11,375 |  |
| Accounts payable |  |  | 25,536 |  |  |  | 40,135 |  |
| Accrued compensation and benefits |  |  | 28,995 |  |  |  | 25,195 |  |
| Accrued warranty |  |  | 10,415 |  |  |  | 8,676 |  |
| Deferred revenue, net |  |  | 75,548 |  |  |  | 76,551 |  |
| Deferred distributors revenue, net of cost of sales to distributors |  |  | 31,677 |  |  |  | 40,875 |  |
| Other accrued liabilities |  |  | 29,968 |  |  |  | 32,623 |  |
| Total current liabilities |  |  | 216,764 |  |  |  | 235,430 |  |
| Deferred revenue, less current portion |  |  | 21,505 |  |  |  | 23,231 |  |
| Long-term debt, less current portion |  |  | 47,375 |  |  |  | 55,500 |  |
| Deferred income taxes |  |  | 3,471 |  |  |  | 2,979 |  |
| Other long-term liabilities |  |  | 8,536 |  |  |  | 7,285 |  |
| Commitments and contingencies |  |  |  |  |  |  |  |  |
| Stockholders’ equity |  |  | 95,136 |  |  |  | 104,235 |  |
| Total liabilities and stockholders’ equity |  | $ | 392,787 |  |  | $ | 428,660 |  |

[0001564590-16-012054:8k_2_02:39]
EXTREME NETWORKS, INC.

[0001564590-16-012054:8k_2_02:40]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS

[0001564590-16-012054:8k_2_02:41]
(In thousands, except per share amounts)

[0001564590-16-012054:8k_2_02:42]
(Unaudited)

[0001564590-16-012054:8k_2_02:43]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | December 31, 2015 |  |  | December 31, 2014 |  |  | December 31, 2015 |  |  | December 31, 2014 |  |
| Net revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 105,355 |  |  | $ | 112,501 |  |  | $ | 196,736 |  |  | $ | 215,173 |  |
| Service |  |  | 33,950 |  |  |  | 34,707 |  |  |  | 67,150 |  |  |  | 68,309 |  |
| Total net revenues |  |  | 139,305 |  |  |  | 147,208 |  |  |  | 263,886 |  |  |  | 283,482 |  |
| Cost of revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  |  | 57,103 |  |  |  | 60,496 |  |  |  | 104,037 |  |  |  | 114,521 |  |
| Service |  |  | 11,927 |  |  |  | 11,550 |  |  |  | 24,456 |  |  |  | 23,272 |  |
| Total cost of revenues |  |  | 69,030 |  |  |  | 72,046 |  |  |  | 128,493 |  |  |  | 137,793 |  |
| Gross profit: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  |  | 48,252 |  |  |  | 52,005 |  |  |  | 92,699 |  |  |  | 100,652 |  |
| Service |  |  | 22,023 |  |  |  | 23,157 |  |  |  | 42,694 |  |  |  | 45,037 |  |
| Total gross profit |  |  | 70,275 |  |  |  | 75,162 |  |  |  | 135,393 |  |  |  | 145,689 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Research and development |  |  | 20,716 |  |  |  | 24,000 |  |  |  | 40,984 |  |  |  | 47,347 |  |
| Sales and marketing |  |  | 37,058 |  |  |  | 43,971 |  |  |  | 73,120 |  |  |  | 88,750 |  |
| General and administrative |  |  | 9,775 |  |  |  | 10,306 |  |  |  | 18,951 |  |  |  | 21,380 |  |
| Acquisition and integration costs |  |  | 807 |  |  |  | 3,500 |  |  |  | 1,145 |  |  |  | 7,558 |  |
| Restructuring charge, net of reversals |  |  | 3,031 |  |  |  | — |  |  |  | 8,634 |  |  |  | — |  |
| Amortization of intangibles |  |  | 4,251 |  |  |  | 4,467 |  |  |  | 8,718 |  |  |  | 8,934 |  |
| Total operating expenses |  |  | 75,638 |  |  |  | 86,244 |  |  |  | 151,552 |  |  |  | 173,969 |  |
| Operating loss |  |  | (5,363 | ) |  |  | (11,082 | ) |  |  | (16,159 | ) |  |  | (28,280 | ) |
| Interest income |  |  | 29 |  |  |  | 196 |  |  |  | 56 |  |  |  | 342 |  |
| Interest expense |  |  | (809 | ) |  |  | (825 | ) |  |  | (1,635 | ) |  |  | (1,661 | ) |
| Other income (expense), net |  |  | 112 |  |  |  | (64 | ) |  |  | 1,079 |  |  |  | (498 | ) |
| Loss before income taxes |  |  | (6,031 | ) |  |  | (11,775 | ) |  |  | (16,659 | ) |  |  | (30,097 | ) |
| Provision for income taxes |  |  | 1,203 |  |  |  | 1,330 |  |  |  | 2,101 |  |  |  | 2,338 |  |
| Net loss |  | $ | (7,234 | ) |  | $ | (13,105 | ) |  | $ | (18,760 | ) |  | $ | (32,435 | ) |
| Basic and diluted net loss per share: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net loss per share - basic |  | $ | (0.07 | ) |  | $ | (0.13 | ) |  | $ | (0.18 | ) |  | $ | (0.33 | ) |
| Net loss per share - diluted |  | $ | (0.07 | ) |  | $ | (0.13 | ) |  | $ | (0.18 | ) |  | $ | (0.33 | ) |
| Shares used in per share calculation - basic |  |  | 102,369 |  |  |  | 98,677 |  |  |  | 101,677 |  |  |  | 97,996 |  |
| Shares used in per share calculation - diluted |  |  | 102,369 |  |  |  | 98,677 |  |  |  | 101,677 |  |  |  | 97,996 |  |

[0001564590-16-012054:8k_2_02:44]
EXTREME NETWORKS, INC.

[0001564590-16-012054:8k_2_02:45]
CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS

[0001564590-16-012054:8k_2_02:46]
(In thousands)

[0001564590-16-012054:8k_2_02:47]
(Unaudited)

[0001564590-16-012054:8k_2_02:48]
|  |  | Six Months Ended |  |
|  |  | December 31, 2015 |  |  | December 31, 2014 |  |
| Net cash provided by operating activities |  | $ | 13,967 |  |  | $ | 41,453 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |
| Capital expenditures |  |  | (1,409 | ) |  |  | (3,962 | ) |
| Proceeds from maturities of investments and marketable securities |  |  | - |  |  |  | 3,000 |  |
| Proceeds from sales of investments and marketable securities |  |  | - |  |  |  | 9,051 |  |
| Purchases of intangible assets |  |  | - |  |  |  | (419 | ) |
| Net cash (used in) provided by investing activities |  |  | (1,409 | ) |  |  | 7,670 |  |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |
| Borrowings under Revolving Facility |  |  | 15,000 |  |  |  | 24,000 |  |
| Repayment of debt |  |  | (19,875 | ) |  |  | (56,438 | ) |
| Proceeds from issuance of common stock |  |  | 2,330 |  |  |  | 1,722 |  |
| Net cash used in financing activities |  |  | (2,545 | ) |  |  | (30,716 | ) |
| Foreign currency effect on cash |  |  | (373 | ) |  |  | (2,625 | ) |
| Net increase in cash and cash equivalents |  |  | 9,640 |  |  |  | 15,782 |  |
| Cash and cash equivalents at beginning of period |  |  | 76,225 |  |  |  | 73,190 |  |
| Cash and cash equivalents at end of period |  | $ | 85,865 |  |  | $ | 88,972 |  |

[0001564590-16-012054:8k_2_02:49]
Extreme Networks, Inc.

[0001564590-16-012054:8k_2_02:50]
Non-GAAP Measures of Financial Performance

[0001564590-16-012054:8k_2_02:51]
To supplement the Company's consolidated financial statements presented in accordance with generally accepted accounting principles, ("GAAP"), Extreme Networks uses non-GAAP measures of certain components of financial performance.  These non-GAAP measures include non-GAAP net income, non-GAAP earnings per diluted share, non-GAAP gross margin, non-GAAP operating expenses and free cash flow.

[0001564590-16-012054:8k_2_02:52]
Reconciliation to the nearest GAAP measure of all historical non-GAAP measures included in this press release can be found in the tables included with this press release.  In this press release, Extreme Networks also presents its target for non-GAAP expenses, which is expenses less stock based compensation expense, acquisition and integration costs, purchase accounting adjustments, amortization of intangibles, restructuring expenses and overhead adjustments.

[0001564590-16-012054:8k_2_02:53]
Non-GAAP measures presented in this press release are not in accordance with or alternative measures prepared in accordance with GAAP and may be different from non-GAAP measures used by other companies.  In addition, these non-GAAP measures are not based on any comprehensive set of accounting rules or principles.  Non-GAAP measures have limitations in that they do not reflect all of the amounts associated with Extreme Networks' results of operations as determined in accordance with GAAP.  These non-GAAP measures should only be used to evaluate Extreme Networks' results of operations in conjunction with the corresponding GAAP measures.

[0001564590-16-012054:8k_2_02:54]
Extreme Networks believes that these non-GAAP measures when shown in conjunction with the corresponding GAAP measures enhance investors' and management's overall understanding of the Company's current financial performance and the Company's prospects for the future, including cash flows available to pursue opportunities to enhance shareholder value.  In addition, because Extreme Networks has historically reported certain non-GAAP results to investors, the Company believes that the inclusion of non-GAAP measures provides consistency in the Company's financial reporting.

[0001564590-16-012054:8k_2_02:55]
For its internal planning process, and as discussed further below, Extreme Networks' management uses financial statements that do not include stock-based compensation expense, acquisition and integration costs, purchase accounting adjustments, amortization of  intangibles, restructuring expenses, litigation expenses and overhead adjustments.  Extreme Networks' management also uses non-GAAP measures, in addition to the corresponding GAAP measures, in reviewing the Company's financial results.

[0001564590-16-012054:8k_2_02:56]
As described above, Extreme Networks excludes the following items from one or more of its non-GAAP measures when applicable.

[0001564590-16-012054:8k_2_02:57]
Stock based compensation expense. This expense consists of expenses for stock options, restricted stock and employee stock purchases through its ESPP.  Extreme Networks excludes stock based compensation expenses from its non-GAAP measures primarily because they are non-cash expenses that the Company does not believe are reflective of ongoing cash requirement related to operating results. Extreme Networks expects to incur stock-based compensation expenses in future periods.

[0001564590-16-012054:8k_2_02:58]
Acquisition and integration costs. Acquisition and integration costs primarily consist of legal and professional fees, severance costs, and other expenses related to the acquisition and integration of Enterasys Inc.  Extreme Networks excludes these expenses since they result from an event that is outside the ordinary course of continuing operations.

[0001564590-16-012054:8k_2_02:59]
Amortization of intangibles.  Amortization of intangibles includes the monthly amortization expense of acquired intangible assets such as developed technology, customer relationships, trademarks and order backlog.  The amortization of the developed technology intangible is recorded in product cost of goods sold, while the amortization for the other intangibles are recorded in operating expenses.  Extreme Networks excludes these non-cash expenses since they result from an intangible asset and for which the period expense does not impact the operations of the business.

[0001564590-16-012054:8k_2_02:60]
Purchase accounting adjustments relating to deferred revenue.  Purchase accounting adjustments relating to deferred revenue consists of adjustments to the carrying value of deferred revenue.  We have recorded adjustments to the assumed deferred revenue to reflect only a fulfillment margin and thereby excluding the profit margin and revenue which would have been incurred had Extreme Networks entered into the service contract post-acquisition.

[0001564590-16-012054:8k_2_02:61]
Restructuring expenses. Restructuring expenses primarily consists of cash severance and termination benefits. Extreme Networks excludes restructuring expenses since they result from events that often occur outside of the ordinary course of continuing operations. Extreme Networks expects to incur restructuring expenses in future periods.

[0001564590-16-012054:8k_2_02:62]
Litigation expenses. Litigation expenses consist of legal and professional fees and expenses related to our on-going ligation matter as a result of a securities laws class action lawsuit.

[0001564590-16-012054:8k_2_02:63]
Overhead adjustments. Overhead adjustment relate to service inventory overhead capitalization.

[0001564590-16-012054:8k_2_02:64]
In addition to the non-GAAP measures discussed above, Extreme Networks uses free cash flow as a measure of operating performance.  Free cash flow represents operating cash flows less net purchase of property and equipment on a GAAP basis.  Extreme Networks considers free cash flows to be a liquidity measure that provides useful information to management and investors about the amount of cash generated by the business after the purchases of property and equipment, which can then be used to, among other things, invest in Extreme Networks business, make strategic acquisitions, and strengthen the balance sheet.  A limitation of the utility of free cash flows as a measure of financial performance is that it does not represent the total increase or decrease in the Company's cash balance for the period.

[0001564590-16-012054:8k_2_02:65]
EXTREME NETWORKS, INC.

[0001564590-16-012054:8k_2_02:66]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS

[0001564590-16-012054:8k_2_02:67]
GAAP TO NON-GAAP RECONCILIATION

[0001564590-16-012054:8k_2_02:68]
(In thousands, except per share amounts)

[0001564590-16-012054:8k_2_02:69]
(Unaudited)

[0001564590-16-012054:8k_2_02:70]
| Non-GAAP Revenue | Three Months Ended |  |  | Six Months Ended |  |
|  | December 31, 2015 |  |  | December 31, 2014 |  |  | December 31, 2015 |  |  | December 31, 2014 |  |
| Revenue - GAAP Basis | $ | 139,305 |  |  | $ | 147,208 |  |  | $ | 263,886 |  |  | $ | 283,482 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Purchase accounting adjustment |  | 377 |  |  | $ | 766 |  |  |  | 754 |  |  | $ | 1,533 |  |
| Revenue - Non-GAAP Basis | $ | 139,682 |  |  | $ | 147,974 |  |  | $ | 264,640 |  |  | $ | 285,015 |  |

[0001564590-16-012054:8k_2_02:71]
| Non-GAAP Gross Margin | Three Months Ended |  |  | Six Months Ended |  |
|  | December 31, 2015 |  |  | December 31, 2014 |  |  | December 31, 2015 |  |  | December 31, 2014 |  |
| Gross profit - GAAP Basis | $ | 70,275 |  |  | $ | 75,162 |  |  | $ | 135,393 |  |  | $ | 145,689 |  |
| Gross margin - GAAP Basis percentage |  | 50.4 | % |  |  | 51.1 | % |  |  | 51.3 | % |  |  | 51.4 | % |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Stock based compensation expense |  | 554 |  |  |  | 574 |  |  |  | 1,216 |  |  |  | 1,121 |  |
| Purchase accounting adjustments |  | 377 |  |  |  | 766 |  |  |  | 754 |  |  |  | 1,533 |  |
| Amortization of intangibles |  | 3,708 |  |  |  | 4,292 |  |  |  | 8,000 |  |  |  | 8,583 |  |
| Service inventory overhead capitalization |  | - |  |  |  | - |  |  |  | (1,493 | ) |  |  | - |  |
| Gross profit - Non-GAAP Basis | $ | 74,914 |  |  | $ | 80,794 |  |  | $ | 143,870 |  |  | $ | 156,926 |  |
| Gross margin - Non-GAAP Basis percentage |  | 53.6 | % |  |  | 54.6 | % |  |  | 54.4 | % |  |  | 55.1 | % |

[0001564590-16-012054:8k_2_02:72]
| Non-GAAP Operating Income | Three Months Ended |  |  | Six Months Ended |  |
|  | December 31, 2015 |  |  | December 31, 2014 |  |  | December 31, 2015 |  |  | December 31, 2014 |  |
| GAAP operating loss | $ | (5,363 | ) |  | $ | (11,082 | ) |  | $ | (16,159 | ) |  | $ | (28,280 | ) |
| GAAP operating loss percentage |  | (3.8 | )% |  |  | (7.5 | )% |  |  | (6.1 | )% |  |  | (10.0 | )% |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Stock based compensation expense |  | 3,945 |  |  |  | 4,750 |  |  |  | 8,616 |  |  |  | 9,563 |  |
| Acquisition and integration costs |  | 807 |  |  |  | 3,500 |  |  |  | 1,145 |  |  |  | 7,558 |  |
| Restructuring charge, net of reversal |  | 3,031 |  |  |  | - |  |  |  | 8,634 |  |  |  | - |  |
| Amortization of intangibles |  | 7,959 |  |  |  | 8,759 |  |  |  | 16,718 |  |  |  | 17,517 |  |
| Purchase accounting adjustments |  | 377 |  |  |  | 766 |  |  |  | 754 |  |  |  | 1,533 |  |
| Litigation |  | 79 |  |  |  | - |  |  |  | 79 |  |  |  | - |  |
| Service inventory overhead capitalization |  | - |  |  |  | - |  |  |  | (1,493 | ) |  |  | - |  |
| Total adjustments to GAAP operating loss | $ | 16,198 |  |  | $ | 17,775 |  |  | $ | 34,453 |  |  | $ | 36,171 |  |
| Non-GAAP operating income | $ | 10,835 |  |  | $ | 6,693 |  |  | $ | 18,294 |  |  | $ | 7,891 |  |
| Non-GAAP operating income percentage |  | 7.8 | % |  |  | 4.5 | % |  |  | 6.9 | % |  |  | 2.8 | % |

[0001564590-16-012054:8k_2_02:73]
| Non-GAAP Net Income | Three Months Ended |  |  | Six Months Ended |  |
|  | December 31, 2015 |  |  | December 31, 2014 |  |  | December 31, 2015 |  |  | December 31, 2014 |  |
| GAAP net loss | $ | (7,234 | ) |  | $ | (13,105 | ) |  | $ | (18,760 | ) |  | $ | (32,435 | ) |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Stock based compensation expense |  | 3,945 |  |  |  | 4,750 |  |  |  | 8,616 |  |  |  | 9,563 |  |
| Acquisition and integration costs |  | 807 |  |  |  | 3,500 |  |  |  | 1,145 |  |  |  | 7,558 |  |
| Restructuring charge, net of reversal |  | 3,031 |  |  |  | - |  |  |  | 8,634 |  |  |  | - |  |
| Amortization of intangibles |  | 7,959 |  |  |  | 8,759 |  |  |  | 16,718 |  |  |  | 17,517 |  |
| Purchase accounting adjustments |  | 377 |  |  |  | 766 |  |  |  | 754 |  |  |  | 1,533 |  |
| Litigation |  | 79 |  |  |  | - |  |  |  | 79 |  |  |  | - |  |
| Service inventory overhead capitalization |  | - |  |  |  | - |  |  |  | (1,493 | ) |  |  | - |  |
| Total adjustments to GAAP net loss | $ | 16,198 |  |  | $ | 17,775 |  |  | $ | 34,453 |  |  | $ | 36,171 |  |
| Non-GAAP net income | $ | 8,964 |  |  | $ | 4,670 |  |  | $ | 15,693 |  |  | $ | 3,736 |  |
| Earnings per share |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Non-GAAP diluted net income per share | $ | 0.09 |  |  | $ | 0.05 |  |  | $ | 0.15 |  |  | $ | 0.04 |  |
| Shares used in diluted net income per share calculation |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Non-GAAP shares used |  | 105,087 |  |  |  | 100,788 |  |  |  | 103,997 |  |  |  | 100,606 |  |

[0001564590-16-012054:8k_2_02:74]
| Free Cash Flow | Three Months Ended |  |  | Six Months Ended |  |
|  | December 31, 2015 |  |  | December 31, 2014 |  |  | December 31, 2015 |  |  | December 31, 2014 |  |
| Cash flow used in operations | $ | 7,441 |  |  | $ | 39,822 |  |  | $ | 13,967 |  |  | $ | 41,453 |  |
| Add: PP&E CapEx spending |  | (776 | ) |  | $ | (1,178 | ) |  |  | (1,409 | ) |  |  | (3,962 | ) |
| Total free cash flow | $ | 6,665 |  |  | $ | 38,644 |  |  | $ | 12,558 |  |  | $ | 37,491 |  |
