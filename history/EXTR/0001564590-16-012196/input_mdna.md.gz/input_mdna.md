# EXTR MD&A — 0001564590-16-012196


## mdna

[0001564590-16-012196:mdna:1]
[same as prior period, unchanged from 0001078271-15-000127:mdna:1]

[0001564590-16-012196:mdna:2]
[same as prior period, unchanged from 0001078271-15-000127:mdna:2]

[0001564590-16-012196:mdna:3]
We believe that understanding the following key developments is helpful to an understanding of our operating results for the fiscal quarter ended December 31, 2015.

[0001564590-16-012196:mdna:4]
We are a leading provider of network infrastructure equipment and offer related services contracts for extended warranty and maintenance to our enterprise, data center and service provider customers. We are a networking industry leader with more than 20,000 customers. We were incorporated in California in May 1996, and reincorporated in Delaware in March 1999. Our corporate headquarters are located in San Jose, California. Substantially all of our revenue is derived from the sale of our networking equipment and related service contracts.

[0001564590-16-012196:mdna:5]
[same as prior period, unchanged from 0001078271-15-000127:mdna:5]

[0001564590-16-012196:mdna:6]
|  | · | Highly scaled and differentiated products and solutions: Our combined product portfolio spans data center networking, switching and routing, Software-Defined Networking (“SDN”), wired and wireless LAN access, network management with analytics and integrated security features. This broader solutions portfolio can be leveraged to better serve existing and new customers. We intend to increase research and development to accelerate our vision for high-performance, modular, open networking. |

[0001564590-16-012196:mdna:7]
|  | · | Leading customer service and support: We are working to augment our current outsourced support model by integrating Enterasys’ in-sourced expertise, building on Enterasys’ award-winning heritage and strong commitment to exceptional customer experience. The Company’s expanded global network of channel partners and distributors will benefit from expanded services and support capabilities. |

[0001564590-16-012196:mdna:8]
|  | · | Strong Channels and Strategic Partners: Our focus is to leverage the capabilities of the combined Company and expand existing partnerships with Ericsson, as well as continue to add new strategic partnerships in the future. Additionally, we will increase our focus on partnering with distributors and channel partners globally. The goal is to develop and enhance relationships that grow revenue and profits for the Company and our alliance and channel partners. At the same time, we are investing in infrastructure to make doing business with the Company easier and more efficient. |

[0001564590-16-012196:mdna:9]
[same as prior period, unchanged from 0001078271-15-000127:mdna:9]

[0001564590-16-012196:mdna:10]
We operate in three regions: Americas, which includes the United States, Canada, Mexico, Central America and South America; EMEA, which includes Europe, Middle East, and Africa; and APAC which includes Asia Pacific, South Asia, Japan and Australia. Sales in APAC and some European countries have continued to be impacted as a result of the soft global economy. We believe that conservative purchasing patterns and delays or cancellation of IT infrastructure plans in the face of continued uncertainty regarding the global economy, may continue to negatively impact overall demand for networking solutions, including Ethernet equipment. Additionally, the continuation of the strong U.S. Dollar compared to most other currency, particularly on a year over year basis, has contributed to the conservative purchasing trends in many international locations.

[0001564590-16-012196:mdna:11]
[same as prior period, unchanged from 0001078271-15-000127:mdna:11]

[0001564590-16-012196:mdna:12]
[same as prior period, unchanged from 0001078271-15-000127:mdna:12]

[0001564590-16-012196:mdna:13]
[same as prior period, unchanged from 0001078271-15-000127:mdna:13]

[0001564590-16-012196:mdna:14]
[same as prior period, unchanged from 0001078271-15-000127:mdna:14]

[0001564590-16-012196:mdna:15]
We believe that continued success in our marketplace is dependent upon a variety of factors that includes, but is not limited to, our ability to design, develop and distribute new and enhanced products employing leading-edge technology. New software and hardware introductions during fiscal 2015 included a Summit X770 switch supporting industry’s highest density performing top of rack switching, Purview - a network-powered application analytics and optimization solution, identiFi 38xx WiFi Access Points supporting 802.11ac, SDN 2.0 - an open, standards-based (based on OpenDaylight) and comprehensive SDN solution, 100GbE support for the BDX8 and NetSight 6.0 a consolidated management across the expanded portfolio. ​

[0001564590-16-012196:mdna:16]
[same as prior period, unchanged from 0001078271-15-000127:mdna:16]

[0001564590-16-012196:mdna:17]
The market for network infrastructure equipment is highly competitive and dominated by a few large companies. The current economic climate has further driven consolidation of vendors within the Ethernet networking market and with vendors from adjacent markets, including storage, security, wireless and voice applications. We believe that the underpinning technology for all of these adjacent markets is Ethernet. As a result, independent Ethernet switch vendors are being acquired or merged with larger, adjacent market vendors to enable them to deliver complete and broad solutions. As an independent Ethernet switch vendor, we must provide products that, when combined with the products of our large strategic partners, create compelling solutions for end-user customers. Our acquisition of Enterasys gives us a larger market share and presence and an opportunity to create complementary solutions for our customers. Our approach is to focus on the intelligence and automation layer that spans our hardware products and that facilitates end-to-end solutions, as opposed to positioning ourselves as a low-cost-vendor with point products.  Lower overall market growth has also created an environment of declining margins due to increased competition between the remaining vendors in this space. During the last year, overall Ethernet port counts have grown, while industry revenues have decreased, signaling a decline in average selling price per port. Our product life cycle and operational cost reduction efforts are therefore even more critical for margin preservation.

[0001564590-16-012196:mdna:18]
[same as prior period, unchanged from 0001078271-15-000127:mdna:18]

[0001564590-16-012196:mdna:19]
During the second quarter of fiscal 2016, we achieved the following results:

[0001564590-16-012196:mdna:20]
|  | · | Net revenues of $139.3 million compared to $147.2 million in the second quarter of fiscal 2015. |

[0001564590-16-012196:mdna:21]
|  | · | Product revenues of $105.4 million compared to $112.5 million in the second quarter of fiscal 2015. |

[0001564590-16-012196:mdna:22]
|  | · | Service revenues of $34.0 million compared to $34.7 million in the second quarter of fiscal 2015. |

[0001564590-16-012196:mdna:23]
|  | · | Total gross margin of 50% of net revenues compared to 51% of net revenues in the second quarter of fiscal 2015. |

[0001564590-16-012196:mdna:24]
|  | · | Operating loss of $5.4 million compared to $11.1 million in the second quarter of fiscal 2015. |

[0001564590-16-012196:mdna:25]
|  | · | Net loss of $7.2 million compared to $13.1 million in the second quarter of fiscal 2015. |

[0001564590-16-012196:mdna:26]
|  | · | Cash flow provided by operating activities of $14.0 million in the six months ended December 31, 2015 compared to cash flow provided by operating activities of $41.5 million in the six months ended December 31, 2014. |

[0001564590-16-012196:mdna:27]
|  | · | Cash and cash equivalents of $85.9 million as of December 31, 2015 compared to $76.2 million as of June 30, 2015. |

[0001564590-16-012196:mdna:28]
[same as prior period, unchanged from 0001078271-15-000127:mdna:28]

[0001564590-16-012196:mdna:29]
The following table presents the total net revenue geographically for the three and six months ended December 31, 2015 and 2014 (dollars in thousands):

[0001564590-16-012196:mdna:30]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
| Net Revenues |  | December 31, 2015 |  |  | December 31, 2014 |  |  | $ Change |  |  | % Change |  |  | December 31, 2015 |  |  | December 31, 2014 |  |  | $ Change |  |  | % Change |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  | $ | 58,749 |  |  | $ | 58,160 |  |  | $ | 589 |  |  |  | 1.0 | % |  | $ | 115,093 |  |  | $ | 116,648 |  |  | $ | (1,555 | ) |  |  | (1.3 | )% |
| Other |  |  | 7,743 |  |  |  | 12,576 |  |  |  | (4,833 | ) |  |  | (38.4 | )% |  |  | 13,585 |  |  |  | 19,917 |  |  |  | (6,332 | ) |  |  | (31.8 | )% |
| Total Americas |  |  | 66,492 |  |  |  | 70,736 |  |  |  | (4,244 | ) |  |  | (6.0 | )% |  |  | 128,678 |  |  |  | 136,565 |  |  |  | (7,887 | ) |  |  | (5.8 | )% |
| Percentage of net revenue |  |  | 47.7 | % |  |  | 48.1 | % |  |  |  |  |  |  |  |  |  |  | 48.8 | % |  |  | 48.2 | % |  |  |  |  |  |  |  |  |
| EMEA |  |  | 60,102 |  |  |  | 62,574 |  |  |  | (2,472 | ) |  |  | (4.0 | )% |  |  | 111,128 |  |  |  | 116,509 |  |  |  | (5,381 | ) |  |  | (4.6 | )% |
| Percentage of net revenue |  |  | 43.1 | % |  |  | 42.5 | % |  |  |  |  |  |  |  |  |  |  | 42.1 | % |  |  | 41.1 | % |  |  |  |  |  |  |  |  |
| APAC |  |  | 12,711 |  |  |  | 13,898 |  |  |  | (1,187 | ) |  |  | (8.5 | )% |  |  | 24,080 |  |  |  | 30,408 |  |  |  | (6,328 | ) |  |  | (20.8 | )% |
| Percentage of net revenue |  |  | 9.1 | % |  |  | 9.4 | % |  |  |  |  |  |  |  |  |  |  | 9.1 | % |  |  | 10.7 | % |  |  |  |  |  |  |  |  |
| Total net revenues |  | $ | 139,305 |  |  | $ | 147,208 |  |  | $ | (7,903 | ) |  |  | (5.4 | )% |  | $ | 263,886 |  |  | $ | 283,482 |  |  | $ | (19,596 | ) |  |  | (6.9 | )% |

[0001564590-16-012196:mdna:31]
[same as prior period, unchanged from 0001078271-15-000127:mdna:31]

[0001564590-16-012196:mdna:32]
The following table presents net product and service revenue for the three and six months ended December 31, 2015 and 2014 (dollars in thousands):

[0001564590-16-012196:mdna:33]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | December 31, 2015 |  |  | December 31, 2014 |  |  | $ Change |  |  | % Change |  |  | December 31, 2015 |  |  | December 31, 2014 |  |  | $ Change |  |  | % Change |  |
| Net Revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 105,355 |  |  | $ | 112,501 |  |  | $ | (7,146 | ) |  |  | (6.4 | )% |  | $ | 196,736 |  |  | $ | 215,173 |  |  | $ | (18,437 | ) |  |  | (8.6 | )% |
| Percentage of net revenue |  |  | 75.6 | % |  |  | 76.4 | % |  |  |  |  |  |  |  |  |  |  | 74.6 | % |  |  | 75.9 | % |  |  |  |  |  |  |  |  |
| Service |  |  | 33,950 |  |  |  | 34,707 |  |  |  | (757 | ) |  |  | (2.2 | )% |  |  | 67,150 |  |  |  | 68,309 |  |  |  | (1,159 | ) |  |  | (1.7 | )% |
| Percentage of net revenue |  |  | 24.4 | % |  |  | 23.6 | % |  |  |  |  |  |  |  |  |  |  | 25.4 | % |  |  | 24.1 | % |  |  |  |  |  |  |  |  |
| Total net revenues |  | $ | 139,305 |  |  | $ | 147,208 |  |  | $ | (7,903 | ) |  |  | (5.4 | )% |  | $ | 263,886 |  |  | $ | 283,482 |  |  | $ | (19,596 | ) |  |  | (6.9 | )% |

[0001564590-16-012196:mdna:34]
Product revenue decreased by $6.0 million or 5.3% and decreased $17.3 million or 8.0% for the three and six-month periods ended December 31, 2015, respectively, as compared to the corresponding periods of fiscal 2015.  The decline in product revenues was due to the continuing strong U.S. Dollar and increased price competition.

[0001564590-16-012196:mdna:35]
Service revenue decreased $1.1 million or 3.1% in the second quarter of fiscal 2016, compared to the corresponding period of fiscal 2015.  Customer service revenue declined $1.5 million due to lower maintenance revenues partially offset by lower purchase accounting charges related to deferred service revenues of $0.4 million in second quarter of fiscal 2016 as compared to $0.8 million in the second quarter of fiscal 2015.

[0001564590-16-012196:mdna:36]
Service revenue decreased $1.5 million or 2.2% in the six months ended December 31, 2015, compared to the corresponding period of fiscal 2015.  Customer service revenue declined $2.3 million due to lower maintenance revenues partially offset by lower purchase accounting charges related to deferred service revenues of $0.8 million in the first half of fiscal 2016 as compared to $1.6 million in the first half of fiscal 2015.

[0001564590-16-012196:mdna:37]
The following table presents the product and service revenue gross profit and the respective gross profit percentages for the three and six months ended December 31, 2015 and 2014 (dollars in thousands):

[0001564590-16-012196:mdna:38]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | December 31, 2015 |  |  | December 31, 2014 |  |  | $ Change |  |  | % Change |  |  | December 31, 2015 |  |  | December 31, 2014 |  |  | $ Change |  |  | % Change |  |
| Gross profit: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 48,252 |  |  | $ | 52,005 |  |  | $ | (3,753 | ) |  |  | (7.2 | )% |  | $ | 92,699 |  |  | $ | 100,652 |  |  | $ | (7,953 | ) |  |  | (7.9 | )% |
| Percentage of product revenue |  |  | 45.8 | % |  |  | 46.2 | % |  |  |  |  |  |  |  |  |  |  | 47.1 | % |  |  | 46.8 | % |  |  |  |  |  |  |  |  |
| Service |  |  | 22,023 |  |  |  | 23,157 |  |  |  | (1,134 | ) |  |  | (4.9 | )% |  |  | 42,694 |  |  |  | 45,037 |  |  |  | (2,343 | ) |  |  | (5.2 | )% |
| Percentage of service revenue |  |  | 64.9 | % |  |  | 66.7 | % |  |  |  |  |  |  |  |  |  |  | 63.6 | % |  |  | 65.9 | % |  |  |  |  |  |  |  |  |
| Total gross profit |  | $ | 70,275 |  |  | $ | 75,162 |  |  | $ | (4,887 | ) |  |  | (6.5 | )% |  | $ | 135,393 |  |  | $ | 145,689 |  |  | $ | (10,296 | ) |  |  | (7.1 | )% |
| Percentage of net revenue |  |  | 50.4 | % |  |  | 51.1 | % |  |  |  |  |  |  |  |  |  |  | 51.3 | % |  |  | 51.4 | % |  |  |  |  |  |  |  |  |

[0001564590-16-012196:mdna:39]
Product gross profit decreased $2.6 million or 5.0% in the second quarter of fiscal 2016 as compared to the corresponding period in fiscal 2015. Gross profit was impacted during the second quarter of fiscal 2016 by a decrease in product revenue of $6.0 million and higher excess inventory charges of $1.0 million and warranty charges of $1.3 million as compared to the corresponding period of fiscal 2015 offset by lower overhead costs of $0.6 million due in part to the reduction in force ("RIF") during the fourth quarter of fiscal 2015, lower royalties on older products which have been discontinued of $0.7 million and distribution expenses of $0.7 million.

[0001564590-16-012196:mdna:40]
Product gross profit decreased $6.8 million or 6.7% in the six months ended December 31, 2015 as compared to the corresponding period in fiscal 2015. Gross profit was impacted during the second quarter of fiscal 2016 by a decrease in product revenue of $17.3 million and higher excess inventory charges of $0.7 million and warranty charges of $1.4 million as compared to the corresponding period of fiscal 2015 offset by lower overhead costs of $1.3 million due in part to the RIF during the fourth quarter of fiscal 2015, lower royalties of $1.4 million on older products which have been discontinued and distribution expenses of $0.5 million.

[0001564590-16-012196:mdna:41]
Service gross profit decreased $1.5 million or 6.4% to $21.7 million in the second quarter of fiscal 2016 from $23.2 million in the second quarter of fiscal 2015.  The decrease was due to lower service revenues of $1.1 million and higher professional fees of $0.4 million to service maintenance contracts as compared to the second quarter of fiscal 2015.

[0001564590-16-012196:mdna:42]
Service gross profit decreased $2.7 million or 6.0% to $42.3 million for the six months ended December 31, 2015 from $45.0 million.  The decrease was due to lower service revenues of $1.5 million and excess inventory charges of $1.2 million for the first six months of fiscal 2016.

[0001564590-16-012196:mdna:43]
[same as prior period, unchanged from 0001078271-15-000127:mdna:42]

[0001564590-16-012196:mdna:44]
[same as prior period, unchanged from 0001078271-15-000127:mdna:43]

[0001564590-16-012196:mdna:45]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | December 31, 2015 |  |  | December 31, 2014 |  |  | $ Change |  |  | % Change |  |  | December 31, 2015 |  |  | December 31, 2014 |  |  | $ Change |  |  | % Change |  |
| Research and development |  | $ | 20,716 |  |  | $ | 24,000 |  |  | $ | (3,284 | ) |  |  | (13.7 | )% |  | $ | 40,984 |  |  | $ | 47,347 |  |  | $ | (6,363 | ) |  |  | (13.4 | )% |
| Sales and marketing |  |  | 37,058 |  |  |  | 43,971 |  |  |  | (6,913 | ) |  |  | (15.7 | )% |  |  | 73,120 |  |  |  | 88,750 |  |  |  | (15,630 | ) |  |  | (17.6 | )% |
| General and administrative |  |  | 9,775 |  |  |  | 10,306 |  |  |  | (531 | ) |  |  | (5.2 | )% |  |  | 18,951 |  |  |  | 21,380 |  |  |  | (2,429 | ) |  |  | (11.4 | )% |
| Acquisition and integration costs |  |  | 807 |  |  |  | 3,500 |  |  |  | (2,693 | ) |  |  | (76.9 | )% |  |  | 1,145 |  |  |  | 7,558 |  |  |  | (6,413 | ) |  |  | (84.9 | )% |
| Restructuring charge, net of reversals |  |  | 3,031 |  |  |  | — |  |  |  | 3,031 |  |  |  | 100.0 | % |  |  | 8,634 |  |  |  | — |  |  |  | 8,634 |  |  |  | 100.0 | % |
| Amortization of intangibles |  |  | 4,251 |  |  |  | 4,467 |  |  |  | (216 | ) |  |  | (4.8 | )% |  |  | 8,718 |  |  |  | 8,934 |  |  |  | (216 | ) |  |  | (2.4 | )% |
| Total operating expenses |  | $ | 75,638 |  |  | $ | 86,244 |  |  | $ | (10,606 | ) |  |  | (12.3 | )% |  | $ | 151,552 |  |  | $ | 173,969 |  |  | $ | (22,417 | ) |  |  | (12.9 | )% |
| Operating loss |  | $ | (5,363 | ) |  | $ | (11,082 | ) |  | $ | 5,719 |  |  |  | 51.6 | % |  | $ | (16,159 | ) |  | $ | (28,280 | ) |  | $ | 12,121 |  |  |  | 42.9 | % |

[0001564590-16-012196:mdna:46]
[same as prior period, unchanged from 0001078271-15-000127:mdna:45]

[0001564590-16-012196:mdna:47]
[same as prior period, unchanged from 0001078271-15-000127:mdna:46]

[0001564590-16-012196:mdna:48]
Research and development expenses decreased by $3.3 million, or 13.7% for the three months ended December 31, 2015 as compared to the corresponding periods of fiscal 2015. The decreases in research and development expenses were due to lower personnel costs of $2.0 million primarily driven by the RIF during the fourth quarter of fiscal 2015 and reduced software tools and maintenance of $0.5 million.

[0001564590-16-012196:mdna:49]
Research and development expenses decreased by $6.4 million, or 13.4% for the six months ended December 31, 2015 as compared to the corresponding period of fiscal 2015. The decreases in research and development expenses were due to lower personnel costs of $4.3 million primarily driven by the RIF during the fourth quarter of fiscal 2015, reduced software tools and maintenance of $1.0 million.

[0001564590-16-012196:mdna:50]
[same as prior period, unchanged from 0001078271-15-000127:mdna:48]

[0001564590-16-012196:mdna:51]
[same as prior period, unchanged from 0001078271-15-000127:mdna:49]

[0001564590-16-012196:mdna:52]
Sales and marketing expenses decreased by $6.9 million, or 15.7% for the three months ended December 31, 2015 as compared to the corresponding periods of fiscal 2015. The decreases in sales and marketing expenses were primarily due to lower personnel costs (which includes benefits and stock based compensation) of $6.5 million as a result of the RIF during the fourth quarter of fiscal 2015.

[0001564590-16-012196:mdna:53]
Sales and marketing expenses decreased by $15.6 million, or 17.6% for the six months ended December 31, 2015 as compared to the corresponding period of fiscal 2015. The decreases in sales and marketing expenses were primarily due to lower personnel costs of $12.3 million as a result of the RIF during the fourth quarter of fiscal 2015 and a corresponding reduction of $2.3 million in travel and entertainment related expense.

[0001564590-16-012196:mdna:54]
[same as prior period, unchanged from 0001078271-15-000127:mdna:52]

[0001564590-16-012196:mdna:55]
General and administrative expense consists primarily of personnel costs, legal and professional service costs, share-based compensation, travel and facilities and information technology costs.

[0001564590-16-012196:mdna:56]
General and administrative expenses decreased by $0.5 million, or 5.2% for the three months ended December 31, 2015 as compared to the corresponding period of fiscal 2015. The decrease in general and administrative expenses was due to lower personnel costs of $0.7 million as a result of the RIF during the fourth quarter of fiscal 2015, partially offset by higher bad debt expense of $0.2 million.

[0001564590-16-012196:mdna:57]
General and administrative expenses decreased by $2.4 million, or 11.4% for the six months ended December 31, 2015 as compared to the corresponding period of fiscal 2015. The decrease in general and administrative expenses was due to lower personnel costs (which includes benefits and stock based compensation) of $0.3 million as a result of the RIF during the fourth quarter of fiscal 2015 and professional services of $1.2 million.

[0001564590-16-012196:mdna:58]
[same as prior period, unchanged from 0001078271-15-000127:mdna:54]

[0001564590-16-012196:mdna:59]
Acquisition and integration costs include those costs that we have incurred only as result of the acquisition of Enterasys and related subsequent integration of the two companies.  We expect that any future integration costs will be immaterial.

[0001564590-16-012196:mdna:60]
During the three months ended December 31, 2015 and 2014, we recorded $0.8 million and $3.5 million, respectively of integration costs primarily for IT and sales integration costs.

[0001564590-16-012196:mdna:61]
During the six months ended December 31, 2015 and 2014, we recorded $1.1 million and $7.6 million, respectively of integration costs primarily for IT, warehouse, and sales integration and severance costs.

[0001564590-16-012196:mdna:62]
[same as prior period, unchanged from 0001078271-15-000127:mdna:57]

[0001564590-16-012196:mdna:63]
During the three and six months ended December 31, 2015, we recorded $3.0 million and $8.6 million in restructuring charges, respectively, primarily for excess facilities, net of future sub-lease income. There were no restructuring charges during the corresponding periods in fiscal 2015. During the first half of fiscal 2016, we continued our initiative begun in the fourth quarter of fiscal 2015 to realign our operations by abandoning excess facilities, primarily in San Jose California; Salem, New Hampshire; Research Triangle Park, North Carolina and Shannon, Ireland. The abandoned facilities represented approximately 29% of our original space, and included general office and warehouse space. There may be additional activities in abandonments of excess facilities in future periods as we further align our organization to our business and operational needs.

[0001564590-16-012196:mdna:64]
During the second quarter of fiscal 2016, in conjunction with the exiting of the facilities noted above, we incurred $2.9 million in charges related to amending our facility lease in North Carolina and $0.2 million of adjustments to severance benefits.  Excess facilities charges included the acceleration of depreciation of leasehold improvements in the amount of $1.9 million, and contract termination charges and professional fees of $1.0 million.

[0001564590-16-012196:mdna:65]
During the six months ended December 31, 2015, in conjunction with the exiting of the facilities noted above, we incurred $8.3 million in excess facilities charges and $0.4 million of adjustments to severance benefits. Excess facilities charges included $4.1 million of accrued lease costs pertaining to the estimated future obligations for non-cancelable lease payments for excess facilities, acceleration of depreciation of leasehold improvements of $3.2 million and contract termination charges and professional fees of $1.0 million.

[0001564590-16-012196:mdna:66]
[same as prior period, unchanged from 0001078271-15-000127:mdna:60]

[0001564590-16-012196:mdna:67]
During the three months ended December 31, 2015 and 2014, we recorded $4.3 million and $4.5 million, respectively of amortization expense recorded in operating expenses in the condensed consolidated statements of operations.

[0001564590-16-012196:mdna:68]
During the six months ended December 31, 2015 and 2014, we recorded $8.7 million and $8.9 million, respectively of amortization expense recorded in operating expenses in the condensed consolidated statements of operations.

[0001564590-16-012196:mdna:69]
[same as prior period, unchanged from 0001078271-15-000127:mdna:62]

[0001564590-16-012196:mdna:70]
During the three and six months ended December 31, 2015 and 2014 we recorded $0.8 million, $1.6 million, $0.8 million and $1.6 million respectively in interest expense.

[0001564590-16-012196:mdna:71]
[same as prior period, unchanged from 0001078271-15-000127:mdna:64]

[0001564590-16-012196:mdna:72]
During the three months ended December 31, 2015 and 2014 we recorded $0.1 million of gains and $0.1 million of losses, respectively, in other income (expense), net. The increase was primarily due to foreign exchange gains from the revaluation of certain assets and liabilities denominated in foreign currencies into U.S. Dollars.

[0001564590-16-012196:mdna:73]
During the six months ended December 31, 2015 and 2014 we recorded $1.1 million of gains and $0.5 million of losses, respectively, in other income (expense), net. The increase was primarily due to foreign exchange gains from the revaluation of certain assets and liabilities denominated in foreign currencies into U.S. Dollars.

[0001564590-16-012196:mdna:74]
[same as prior period, unchanged from 0001078271-15-000127:mdna:66]

[0001564590-16-012196:mdna:75]
For the three months ended December 31, 2015 and 2014, we recorded an income tax provision of $1.2 million and $1.3 million, respectively.  For the six months ended December 31, 2015 and 2014, we recorded an income tax provision of $2.1 million and $2.3 million, respectively.

[0001564590-16-012196:mdna:76]
The income tax provisions for the three and six months ended December 31, 2015 and 2014 consisted primarily of taxes on the income of our foreign subsidiaries as well as tax expense associated with the establishment of a U.S. deferred tax liability for amortizable goodwill resulting from the acquisition of Enterasys.

[0001564590-16-012196:mdna:77]
[same as prior period, unchanged from 0001078271-15-000127:mdna:69]

[0001564590-16-012196:mdna:78]
[same as prior period, unchanged from 0001078271-15-000127:mdna:70]

[0001564590-16-012196:mdna:79]
As discussed in Part II, Item 7, “Management's Discussion and Analysis of Financial Condition and Results of Operations” of our Annual Report on Form 10-K for the year ended June 30, 2015 , we consider the following accounting policies to be the most critical in understanding the judgments that are involved in preparing our consolidated financial statements:

[0001564590-16-012196:mdna:80]
|  | · | Revenue Recognition |

[0001564590-16-012196:mdna:81]
|  | · | Goodwill |

[0001564590-16-012196:mdna:82]
|  | · | Share-based Payments |

[0001564590-16-012196:mdna:83]
|  | · | Restructuring Charges |

[0001564590-16-012196:mdna:84]
[same as prior period, unchanged from 0001078271-15-000127:mdna:76]

[0001564590-16-012196:mdna:85]
[same as prior period, unchanged from 0001078271-15-000127:mdna:77]

[0001564590-16-012196:mdna:86]
[same as prior period, unchanged from 0001078271-15-000127:mdna:78]

[0001564590-16-012196:mdna:87]
[same as prior period, unchanged from 0001078271-15-000127:mdna:79]

[0001564590-16-012196:mdna:88]
[same as prior period, unchanged from 0001078271-15-000127:mdna:80]

[0001564590-16-012196:mdna:89]
|  |  | December 31, 2015 |  |  | June 30, 2015 |  |
| Cash and cash equivalent |  | $ | 85,865 |  |  | $ | 76,225 |  |
| Total cash and investments |  | $ | 85,865 |  |  | $ | 76,225 |  |
| Working capital |  | $ | 9,442 |  |  | $ | 2,564 |  |

[0001564590-16-012196:mdna:90]
As of December 31, 2015, our principal sources of liquidity consisted of cash and cash equivalents of $85.9 million, accounts receivable, net of $73.1 million and availability of borrowings from the Revolving Facility of $32.2 million. Our principal uses of cash will include repayments of debt and related interest, purchase of finished goods inventory from our contract manufacturers, payroll, restructuring expenses and other operating expenses related to the development, marketing of our products and purchases of property and equipment. We believe that our $85.9 million of cash and cash equivalents at December 31, 2015, cash flows from operations along with the availability of borrowings from the Revolving Facility will be sufficient to fund our principal uses of cash for at least the next 12 months.

[0001564590-16-012196:mdna:91]
The Senior Secured Credit Facilities, as amended, contain financial covenants that require us to maintain a minimum Consolidated Fixed Charge Coverage Ratio and Consolidated Quick Ratio and a maximum Consolidated Leverage Ratio and other financial and non-financial covenants and restrictions that limit our ability to incur additional indebtedness, create liens upon any of our property, merge, consolidate or sell all or substantially all of our assets, etc.

[0001564590-16-012196:mdna:92]
The Senior Secured Credit Facilities, as amended, also include customary events of default, including failure to pay principal, interest or fees when due, failure to comply with covenants, if any representation or warranty made by us is false or misleading in any material respect, certain insolvency or receivership events affecting Extreme and its subsidiaries, the occurrence of certain material judgments, the occurrence of certain ERISA events, the invalidity of the loan documents or a change in control of our Company.  The amounts outstanding under the Senior Secured Credit Facilities, as amended, may be accelerated upon certain events of default. At December 31, 2015, we are in compliance and expect to remain in compliance with the covenants of the Senior Secured Credit Facilities, as amended, and they are not expected to impact our liquidity or capital resources.

[0001564590-16-012196:mdna:93]
[same as prior period, unchanged from 0001078271-15-000127:mdna:85]

[0001564590-16-012196:mdna:94]
[same as prior period, unchanged from 0001078271-15-000127:mdna:86]

[0001564590-16-012196:mdna:95]
|  |  | Six Months Ended |  |
|  |  | December 31, 2015 |  |  | December 31, 2014 |  |
| Net cash provided by operating activities |  | $ | 13,967 |  |  | $ | 41,453 |  |
| Net cash (used in) provided by investing activities |  |  | (1,409 | ) |  |  | 7,670 |  |
| Net cash used in financing activities |  |  | (2,545 | ) |  |  | (30,716 | ) |
| Foreign currency effect on cash |  |  | (373 | ) |  |  | (2,625 | ) |
| Net increase in cash and cash equivalents |  | $ | 9,640 |  |  | $ | 15,782 |  |

[0001564590-16-012196:mdna:96]
[same as prior period, unchanged from 0001078271-15-000127:mdna:88]

[0001564590-16-012196:mdna:97]
Cash flows provided by operations in the six months ended December 31, 2015 was $14.0 million and was generated from non-cash expenses of $36.0 million such as amortization of intangibles, stock-based compensation expense and depreciation as well as decreases in accounts receivables and was partially offset by the current period's net loss of $18.8 million along with increases in inventories and decreases in accounts payable, accrued compensation and deferred revenues.

[0001564590-16-012196:mdna:98]
Cash flows provided by operations in the six months ending December 31, 2014 was $41.5 million. The prior year's net loss of $32.4 million was primarily offset by non-cash expenses of $37.0 million such as amortization of intangibles, stock-based compensation expense and depreciation. Accounts receivables decreased due to lower revenue during the quarter combined with higher collections. Inventories decreased due to the timing of inventory receipts to bring inventory levels in line with the near term demand. Such increases in cash inflows were offset by decreases in accounts payables primarily due to the timing of payments.

[0001564590-16-012196:mdna:99]
Net Cash (Used In) Provided By Investing Activities

[0001564590-16-012196:mdna:100]
Cash flows used in investing activities in the six months ended December 31, 2015 was $1.4 million and was comprised of purchases of property and equipment.

[0001564590-16-012196:mdna:101]
Cash flows provided by investing activities in the six months ending December 31, 2014 was $7.7 million and was comprised of proceeds of $12.1 million from the maturities and sales of investments offset by $4.0 million of purchases of property and equipment.

[0001564590-16-012196:mdna:102]
Net Cash Used In Financing Activities

[0001564590-16-012196:mdna:103]
Cash flows used in financing activities in the six months ended December 31, 2015 was $2.5 million which was comprised of $2.3 million proceeds from the issuance of shares of our common stock under the ESPP and the exercise of stock options, net of taxes paid on vested and released stock awards, offset by a net repayment of debt of $4.9 million.

[0001564590-16-012196:mdna:104]
Cash flows used in financing activities in the six months ending December 31, 2014 was $30.7 million which was comprised of a $24.0 million draw on the Revolving Facility, $1.7 million of proceeds from the exercise of stock options and issuance of shares of our common stock under the ESPP, net of taxes paid on vested and released stock awards, offset by $56.4 million of cash used for repayment of debt.

[0001564590-16-012196:mdna:105]
[same as prior period, unchanged from 0001078271-15-000127:mdna:98]

[0001564590-16-012196:mdna:106]
Foreign currency effect on cash increased in the six months ended December 31, 2015, primarily due to changes in foreign currency exchange rates between US Dollar and particularly the Brazilian Real, British Pound, Indian Rupee and the EURO.

[0001564590-16-012196:mdna:107]
[same as prior period, unchanged from 0001078271-15-000127:mdna:100]

[0001564590-16-012196:mdna:108]
The following summarizes our contractual obligations at six months ended December 31, 2015, and the effect such obligations are expected to have on our liquidity and cash flow in future periods (in thousands):

[0001564590-16-012196:mdna:109]
|  |  | Total |  |  | Less than 1 Year |  |  | 1-3 years |  |  | 3-5 years |  |  | More than 5 years |  |
| Contractual Obligations: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Debt obligations |  | $ | 62,000 |  |  | $ | 14,625 |  |  | $ | 47,375 |  |  | $ | — |  |  | $ | — |  |
| Interest on debt obligations |  |  | 4,184 |  |  |  | 2,073 |  |  |  | 2,111 |  |  |  | — |  |  |  | — |  |
| Non-cancellable inventory purchase commitments |  |  | 64,284 |  |  |  | 64,284 |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Non-cancellable operating lease obligations |  |  | 58,324 |  |  |  | 9,795 |  |  |  | 16,408 |  |  |  | 11,658 |  |  |  | 20,463 |  |
| Other liabilities |  |  | 5,056 |  |  |  | 4,698 |  |  |  | 358 |  |  |  | — |  |  |  | — |  |
| Total contractual cash obligations |  | $ | 193,848 |  |  | $ | 95,475 |  |  | $ | 66,252 |  |  | $ | 11,658 |  |  | $ | 20,463 |  |

[0001564590-16-012196:mdna:110]
Non-cancelable inventory purchase commitments represent the purchase of long lead-time component inventory that our contract manufacturers procure in accordance with our forecast. Inventory purchase commitments were $64.3 million as of six months ended December 31, 2015. We expect to honor the inventory purchase commitments within the next 12 months.

[0001564590-16-012196:mdna:111]
[same as prior period, unchanged from 0001078271-15-000127:mdna:104]

[0001564590-16-012196:mdna:112]
[same as prior period, unchanged from 0001078271-15-000127:mdna:105]

[0001564590-16-012196:mdna:113]
[same as prior period, unchanged from 0001078271-15-000127:mdna:106]

[0001564590-16-012196:mdna:114]
We did not have any material commitments for capital expenditures as of December 31, 2015.

[0001564590-16-012196:mdna:115]
[same as prior period, unchanged from 0001078271-15-000127:mdna:108]

[0001564590-16-012196:mdna:116]
We did not have any off-balance sheet arrangements as of December 31, 2015.
