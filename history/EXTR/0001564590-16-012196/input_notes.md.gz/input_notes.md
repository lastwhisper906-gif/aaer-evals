# EXTR notes — 0001564590-16-012196


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0001564590-16-012196:notes:1]
| 1. | Description of Business and Basis of Presentation |

[0001564590-16-012196:notes:2]
Extreme Networks, Inc. (“Extreme Networks” or the “Company”) is a leading provider of network infrastructure equipment and markets its products primarily to business, governmental, health care, service provider, and educational customers with a focus on large corporate enterprises and metropolitan service providers on a global basis. The Company conducts its sales and marketing activities on a worldwide basis through distributors, resellers and the Company’s field sales organization. Extreme Networks was incorporated in California in 1996 and reincorporated in Delaware in 1999.

[0001564590-16-012196:notes:3]
The unaudited condensed consolidated financial statements of Extreme Networks included herein have been prepared under the rules and regulations of the Securities and Exchange Commission (“SEC”). Certain information and footnote disclosures normally included in financial statements prepared in accordance with generally accepted accounting principles have been condensed or omitted under such rules and regulations. The condensed consolidated balance sheet at June 30, 2015 was derived from audited financial statements as of that date but does not include all disclosures required by generally accepted accounting principles for complete financial statements. These interim financial statements and notes should be read in conjunction with the Company’s audited consolidated financial statements and notes thereto included in the Company’s Annual Report on Form 10-K for the fiscal year ended June 30, 2015.

[0001564590-16-012196:notes:4]
The unaudited condensed consolidated financial statements reflect all adjustments, consisting only of normal recurring adjustments that, in the opinion of management, are necessary for a fair presentation of the results of operations and cash flows for the interim periods presented and the financial condition of Extreme Networks at December 31, 2015. The results of operations for the three and six months ended December 31, 2015 are not necessarily indicative of the results that may be expected for fiscal 2016 or any future periods.

[0001564590-16-012196:notes:5]
[same as prior period, unchanged from 0001078271-15-000127:notes:76]

[0001564590-16-012196:notes:6]
The Company uses a fiscal calendar year ending on June 30. All references herein to "fiscal 2016" or "2016" represent the fiscal year ending June 30, 2016.

[0001564590-16-012196:notes:7]
[same as prior period, unchanged from 0001078271-15-000127:notes:78]

[0001564590-16-012196:notes:8]
[same as prior period, unchanged from 0001078271-15-000127:notes:79]

[0001564590-16-012196:notes:9]
[same as prior period, unchanged from 0001078271-15-000127:notes:80]

[0001564590-16-012196:notes:10]
[same as prior period, unchanged from 0001078271-15-000127:notes:81]

[0001564590-16-012196:notes:11]
[same as prior period, unchanged from 0001078271-15-000127:notes:82]

[0001564590-16-012196:notes:12]
Certain balances included in the condensed consolidated statements of cash flows related to restructuring liabilities for prior periods have been reclassified to conform to the current period presentation.  In the condensed consolidated statement of cash flows, the changes in operating assets and liabilities for Other long-term liabilities includes the changes in restructuring liabilities and other accrued liabilities which were previously disclosed separately.


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001564590-16-012196:notes:13]
| 2. | Summary of Significant Accounting Policies |

[0001564590-16-012196:notes:14]
[same as prior period, unchanged from 0001078271-15-000127:notes:117]


## us-gaap:NewAccountingPronouncementsAndChangesInAccountingPrinciplesTextBlock

[0001564590-16-012196:notes:15]
| 3. | Recently Issued Accounting Pronouncements |

[0001564590-16-012196:notes:16]
For a description of recently issued accounting pronouncements, see Note 4, Recently Issued Accounting Pronouncements, to the consolidated financial statements included in the Company's Annual report on Form 10-K for the fiscal year ended June 30, 2015. The following are accounting pronouncements issued that may materially affect the Company's financial statements since the filing of the Annual report on Form 10-K.

[0001564590-16-012196:notes:17]
In November 2015, the FASB issued Accounting Standards Update No. 2015-17 (“ASU 2015-17”), Income Taxes (Topic 740): Balance Sheet Classification of Deferred Taxes. Current GAAP requires an entity to separate deferred income tax liabilities and assets into current and noncurrent amounts in a classified statement of financial position. To simplify the presentation of deferred income taxes, ASU 2015-17 requires that deferred tax liabilities and assets be classified as noncurrent in a classified statement of financial position.  The current requirement that deferred tax liabilities and assets of a tax-paying component of an entity be offset and presented as a single amount is not affected by the amendments in this Update. The amendments in this Update are effective for financial statements issued for annual periods beginning after December 15, 2016, and interim periods within those annual periods. Earlier application is permitted for all entities as of the beginning of an interim or annual reporting period and the amendments for ASU-2015-17 can be applied retrospectively or prospectively.  The adoption of this guidance is not expected to have a material impact upon our financial condition or results of operations.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001564590-16-012196:notes:18]
| 4. | Balance Sheet Accounts |

[0001564590-16-012196:notes:19]
[same as prior period, unchanged from 0001078271-15-000127:notes:119]

[0001564590-16-012196:notes:20]
[same as prior period, unchanged from 0001078271-15-000127:notes:120]

[0001564590-16-012196:notes:21]
|  |  | December 31, 2015 |  |  | June 30, 2015 |  |
| Cash |  | $ | 81,096 |  |  | $ | 71,455 |  |
| Cash equivalents |  | $ | 4,769 |  |  | $ | 4,770 |  |
| Total available-for-sale |  | $ | 4,769 |  |  | $ | 4,770 |  |
| Total cash, cash equivalents and available for sale securities |  | $ | 85,865 |  |  | $ | 76,225 |  |

[0001564590-16-012196:notes:22]
The Company considers highly liquid investments with maturities of three months or less at the date of purchase to be cash equivalents. Investments with original maturities of greater than three months, but less than one year at the balance sheet date are classified as short-term investments.

[0001564590-16-012196:notes:23]
[same as prior period, unchanged from 0001078271-15-000127:notes:121]

[0001564590-16-012196:notes:24]
The Company’s inventory balances as of December 31 and June 30, 2015 were $56.6 million and $58.0 million, respectively. The Company values its inventory at lower of cost or market. Cost is computed using standard cost, which approximates actual cost, on a first-in, first-out basis. The Company has established inventory allowances primarily determined by the age of inventory or when conditions exist that suggest that inventory may be in excess of anticipated demand or is obsolete based upon assumptions about future demand. At the point of the loss recognition, a new, lower-cost basis for that inventory is established, and subsequent changes in facts and circumstances do not result in the restoration or increase in that newly established cost basis. Any written down or obsolete inventory subsequently sold has not had a material impact on gross margin for any of the periods disclosed.

[0001564590-16-012196:notes:25]
The following is a summary of our inventory by category (in thousands):

[0001564590-16-012196:notes:26]
|  |  | December 31, 2015 |  |  | June 30, 2015 |  |
| Finished goods |  | $ | 52,640 |  |  | $ | 55,301 |  |
| Raw materials |  |  | 3,961 |  |  |  | 2,713 |  |
| Total Inventory |  | $ | 56,601 |  |  | $ | 58,014 |  |

[0001564590-16-012196:notes:27]
[same as prior period, unchanged from 0001078271-15-000127:notes:123]

[0001564590-16-012196:notes:28]
Property and equipment consist of the following (in thousands):

[0001564590-16-012196:notes:29]
|  |  | December 31, 2015 |  |  | June 30, 2015 |  |
| Computer equipment |  | $ | 33,943 |  |  | $ | 32,753 |  |
| Purchased software |  |  | 5,671 |  |  |  | 5,425 |  |
| Office equipment, furniture and fixtures |  |  | 11,113 |  |  |  | 10,908 |  |
| Leasehold improvements |  |  | 20,682 |  |  |  | 24,293 |  |
| Total property and equipment |  |  | 71,409 |  |  |  | 73,379 |  |
| Less: accumulated depreciation and amortization |  |  | (38,461 | ) |  |  | (33,517 | ) |
| Property and equipment, net |  | $ | 32,948 |  |  | $ | 39,862 |  |

[0001564590-16-012196:notes:30]
[same as prior period, unchanged from 0001078271-15-000127:notes:124]

[0001564590-16-012196:notes:31]
The following tables summarize the components of gross and net intangible asset balances (in thousands):

[0001564590-16-012196:notes:32]
|  |  | Weighted Average |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Remaining Amortization |  | Gross Carrying |  |  | Accumulated |  |  | Net Carrying |  |
|  |  | Period |  | Amount |  |  | Amortization |  |  | Amount |  |
| December 31, 2015 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Developed technology |  | 0.65 years |  | $ | 48,000 |  |  | $ | 36,194 |  |  | $ | 11,806 |  |
| Customer relationships |  | 0.75 years |  |  | 37,000 |  |  |  | 26,722 |  |  |  | 10,278 |  |
| Maintenance contracts |  | 2.75 years |  |  | 17,000 |  |  |  | 7,367 |  |  |  | 9,633 |  |
| Trademarks |  | 0.75 years |  |  | 2,500 |  |  |  | 1,805 |  |  |  | 695 |  |
| Order backlog |  | 0.00 years |  |  | 7,400 |  |  |  | 7,400 |  |  |  | — |  |
| License agreements |  | 9.90 years |  |  | 3,596 |  |  |  | 1,494 |  |  |  | 2,102 |  |
| Other intangibles |  | 4.20 years |  |  | 1,426 |  |  |  | 802 |  |  |  | 624 |  |
| Total intangibles, net |  |  |  | $ | 116,922 |  |  | $ | 81,784 |  |  | $ | 35,138 |  |

[0001564590-16-012196:notes:33]
|  |  | Weighted Average |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Remaining Amortization |  | Gross Carrying |  |  | Accumulated |  |  | Net Carrying |  |
|  |  | Period |  | Amount |  |  | Amortization |  |  | Amount |  |
| June 30, 2015 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Developed technology |  | 1.20 years |  | $ | 48,000 |  |  | $ | 28,194 |  |  | $ | 19,806 |  |
| Customer relationships |  | 1.30 years |  |  | 37,000 |  |  |  | 20,556 |  |  |  | 16,444 |  |
| Maintenance contracts |  | 3.30 years |  |  | 17,000 |  |  |  | 5,667 |  |  |  | 11,333 |  |
| Trademarks |  | 1.30 years |  |  | 2,500 |  |  |  | 1,389 |  |  |  | 1,111 |  |
| Order backlog |  | 0.30 years |  |  | 7,400 |  |  |  | 6,967 |  |  |  | 433 |  |
| License agreements |  | 10.20 years |  |  | 10,924 |  |  |  | 8,620 |  |  |  | 2,304 |  |
| Other intangibles |  | 3.80 years |  |  | 2,684 |  |  |  | 1,983 |  |  |  | 701 |  |
| Total intangibles, net |  |  |  | $ | 125,508 |  |  | $ | 73,376 |  |  | $ | 52,132 |  |

[0001564590-16-012196:notes:34]
Amortization expense for the three months ended December 31, 2015 and 2014, was $8.1 million and $9.0 million, respectively. For the three months ended December 31, 2015 and 2014 amortization expense of $3.8 million and $4.5 million, respectively, is included in “Cost of revenues for products” on the condensed consolidated statements of operations. Amortization expense for the six months ended December 31, 2015 and 2014, was $17.0 million and $18.0 million, respectively.  For the six months ended December 31, 2015 and 2014 amortization expense of $8.3 million and $9.1 million, respectively, is included in “Cost of revenues for products” on the condensed consolidated statements of operations.  The remainder of the amortization expense is included in “Amortization of intangibles” on the condensed consolidated statement of operations for all periods. The amortization expense that is recognized in “Cost of revenues for products” is comprised of amortization for developed technology, license agreements and other intangibles.

[0001564590-16-012196:notes:35]
[same as prior period, unchanged from 0001078271-15-000127:notes:126]

[0001564590-16-012196:notes:36]
The following are the components of other accrued liabilities (in thousands):

[0001564590-16-012196:notes:37]
|  |  | December 31, 2015 |  |  | June 30, 2015 |  |
| Accrued general and administrative costs |  | $ | 4,383 |  |  | $ | 1,204 |  |
| Restructuring |  |  | 2,588 |  |  |  | 5,854 |  |
| Other accrued liabilities |  |  | 22,997 |  |  |  | 25,565 |  |
| Total other accrued liabilities |  | $ | 29,968 |  |  | $ | 32,623 |  |

[0001564590-16-012196:notes:38]
[same as prior period, unchanged from 0001078271-15-000127:notes:127]

[0001564590-16-012196:notes:39]
Deferred revenue, net represents amounts for (i) deferred services revenue (support arrangements, professional services and training), and (ii) deferred product revenue net of the related cost of revenue when the revenue recognition criteria have not been met.

[0001564590-16-012196:notes:40]
The following table summarizes deferred revenue, net (in thousands):

[0001564590-16-012196:notes:41]
|  |  | December 31, 2015 |  |  | June 30, 2015 |  |
| Deferred services |  | $ | 84,706 |  |  | $ | 87,441 |  |
| Deferred product and other revenue |  |  | 12,347 |  |  |  | 12,341 |  |
| Total deferred revenue |  |  | 97,053 |  |  |  | 99,782 |  |
| Less: current portion |  |  | 75,548 |  |  |  | 76,551 |  |
| Non-current deferred revenue, net |  | $ | 21,505 |  |  | $ | 23,231 |  |

[0001564590-16-012196:notes:42]
The Company offers for sale to its customers, renewable support arrangements that range from one to five years. Deferred support revenue is included within deferred revenue, net within the services category above. The change in the Company’s deferred support revenue balance in relation to these arrangements was as follows (in thousands):

[0001564590-16-012196:notes:43]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | December 31, 2015 |  |  | December 31, 2014 |  |  | December 31, 2015 |  |  | December 31, 2014 |  |
| Balance beginning of period |  | $ | 85,255 |  |  | $ | 87,012 |  |  | $ | 87,441 |  |  | $ | 89,657 |  |
| New support arrangements |  |  | 29,773 |  |  |  | 35,517 |  |  |  | 56,819 |  |  |  | 64,056 |  |
| Recognition of support revenue |  |  | (30,322 | ) |  |  | (31,156 | ) |  |  | (59,554 | ) |  |  | (62,340 | ) |
| Balance end of period |  |  | 84,706 |  |  |  | 91,373 |  |  |  | 84,706 |  |  |  | 91,373 |  |
| Less: current portion |  |  | 63,201 |  |  |  | 67,433 |  |  |  | 63,201 |  |  |  | 67,433 |  |
| Non-current deferred revenue |  | $ | 21,505 |  |  | $ | 23,940 |  |  | $ | 21,505 |  |  | $ | 23,940 |  |

[0001564590-16-012196:notes:44]
[same as prior period, unchanged from 0001078271-15-000127:notes:130]

[0001564590-16-012196:notes:45]
[same as prior period, unchanged from 0001078271-15-000127:notes:131]

[0001564590-16-012196:notes:46]
The following table summarizes deferred distributors revenue, net of cost of sales to distributors (in thousands):

[0001564590-16-012196:notes:47]
|  |  | December 31, 2015 |  |  | June 30, 2015 |  |
| Deferred distributors revenue |  | $ | 41,653 |  |  | $ | 53,366 |  |
| Deferred cost of sales to distributors |  |  | (9,976 | ) |  |  | (12,491 | ) |
| Deferred distributors revenue, net of cost of sales to distributors |  | $ | 31,677 |  |  | $ | 40,875 |  |

[0001564590-16-012196:notes:48]
[same as prior period, unchanged from 0001078271-15-000127:notes:132]

[0001564590-16-012196:notes:49]
The Company’s debt is comprised of the following:

[0001564590-16-012196:notes:50]
|  |  | December 31, 2015 |  |  | June 30, 2015 |  |
| Current portion of long-term debt: |  |  |  |  |  |  |  |  |
| Term Loan |  | $ | 14,625 |  |  | $ | 11,375 |  |
| Current portion of long-term debt |  | $ | 14,625 |  |  | $ | 11,375 |  |
| Long-term debt, less current portion: |  |  |  |  |  |  |  |  |
| Term Loan |  | $ | 37,375 |  |  | $ | 45,500 |  |
| Revolving Facility |  |  | 10,000 |  |  |  | 10,000 |  |
| Total long-term debt, less current portion |  |  | 47,375 |  |  |  | 55,500 |  |
| Total debt |  | $ | 62,000 |  |  | $ | 66,875 |  |

[0001564590-16-012196:notes:51]
During fiscal 2015, the Company amended its credit agreement which provides for a five-year revolving credit facility for up to $50.0 million (the “Revolving Facility”) and a $65.0 million five-year term loan (the “Term Loan”) and together with the Revolving Facility the (“Senior Secured Credit Facilities, as amended”).

[0001564590-16-012196:notes:52]
The Senior Secured Credit Facilities, as amended contains, among others, certain financial covenants that require the Company to maintain defined minimum financial ratios which may limit the Company’s availability to borrowings under the Revolving Facility. As of December 31, 2015, the Company had $32.2 million of availability under the Revolving Facility and is in compliance with its covenants.

[0001564590-16-012196:notes:53]
The Company had $1.0 million of outstanding letters of credit as of December 31, 2015.

[0001564590-16-012196:notes:54]
[same as prior period, unchanged from 0001078271-15-000127:notes:136]

[0001564590-16-012196:notes:55]
Networking products may contain undetected hardware or software errors when new products or new versions or updates of existing products are released to the marketplace. In the past, we had experienced such errors in connection with products and product updates. The Company’s standard hardware warranty period is typically 12 months from the date of shipment to end-users and 90 days for software. For certain access products, the Company offers a limited lifetime hardware warranty commencing on the date of shipment from the Company and ending five (5) years following the Company’s announcement of the end of sale of such product. Upon shipment of products to its customers, the Company estimates expenses for the cost to repair or replace products that may be returned under warranty and accrue a liability in cost of product revenue for this amount. The determination of the Company’s warranty requirements is based on actual historical experience with the product or product family, estimates of repair and replacement costs and any product warranty problems that are identified after shipment.  The Company estimates and adjusts these accruals at each balance sheet date in accordance with changes in these factors.

[0001564590-16-012196:notes:56]
Upon issuance of a standard product warranty, the Company discloses and recognizes a liability for the obligations it assumes under the product warranty. The following table summarizes the activity related to the Company’s product warranty liability during the three and six months ended December 31, 2015 and 2014:

[0001564590-16-012196:notes:57]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | December 31, 2015 |  |  | December 31, 2014 |  |  | December 31, 2015 |  |  | December 31, 2014 |  |
| Balance beginning of period |  | $ | 9,244 |  |  | $ | 7,889 |  |  | $ | 8,676 |  |  | $ | 7,551 |  |
| New warranties issued |  |  | 2,956 |  |  |  | 1,683 |  |  |  | 5,520 |  |  |  | 3,948 |  |
| Warranty expenditures |  |  | (1,785 | ) |  |  | (1,727 | ) |  |  | (3,781 | ) |  |  | (3,654 | ) |
| Balance end of period |  | $ | 10,415 |  |  | $ | 7,845 |  |  | $ | 10,415 |  |  | $ | 7,845 |  |

[0001564590-16-012196:notes:58]
To facilitate sales of its products in the normal course of business, the Company indemnifies its resellers and end-user customers with respect to certain matters. The Company has agreed to hold the customer harmless against losses arising from a breach of intellectual property infringement or other claims made against certain parties. These agreements may limit the time within which an indemnification claim can be made and the amount of the claim. It is not possible to estimate the maximum potential amount under these indemnification agreements due to the limited history of prior indemnification claims and the unique facts and circumstances involved in each particular agreement. Historically, payments made by the Company under these agreements have not had a material impact on its operating results or financial position.

[0001564590-16-012196:notes:59]
[same as prior period, unchanged from 0001078271-15-000127:notes:140]

[0001564590-16-012196:notes:60]
Cooperative advertising expenses are recorded as marketing expenses to the extent that an advertising benefit separate from the revenue transaction can be identified and the cash paid does not exceed the fair value of that advertising benefit received. Cooperative advertising obligations with customers are accrued and the costs expensed at the time the related revenue is recognized. If the Company does not meet the criteria for recognizing such cooperative advertising obligations as marketing expense, the costs are recorded as a reduction of revenue. All other advertising costs are expensed as incurred.  Advertising expenses for three and six months ended December 31, 2015 and 2014, were immaterial.

[0001564590-16-012196:notes:61]
[same as prior period, unchanged from 0001078271-15-000127:notes:142]

[0001564590-16-012196:notes:62]
The Company may be subject to concentration of credit risk as a result of certain financial instruments consisting of accounts receivable and short-term investments. The Company does not invest an amount exceeding 10% of its combined cash or cash equivalents in the securities of any one obligor or maker, except for obligations of the United States government, obligations of United States government agencies and money market accounts.

[0001564590-16-012196:notes:63]
[same as prior period, unchanged from 0001078271-15-000127:notes:144]

[0001564590-16-012196:notes:64]
The following table sets forth major customers accounting for 10% or more of our net revenue:

[0001564590-16-012196:notes:65]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | December 31, 2015 |  |  | December 31, 2014 |  |  | December 31, 2015 |  |  | December 31, 2014 |  |
| Tech Data Corporation |  |  | 19% |  |  |  | 15% |  |  |  | 16% |  |  |  | 15% |  |
| Westcon Group Inc. |  |  | 14% |  |  |  | 13% |  |  |  | 15% |  |  |  | 13% |  |
| Jenne |  |  | 12% |  |  | * |  |  |  | 11% |  |  | * |  |

[0001564590-16-012196:notes:66]
| * | Less than 10% of net revenue |


## us-gaap:FairValueDisclosuresTextBlock

[0001564590-16-012196:notes:67]
| 5. | Fair Value Measurements |

[0001564590-16-012196:notes:68]
A three-tier fair value hierarchy is utilized to prioritize the inputs used in measuring fair value. The hierarchy gives the highest priority to quoted prices in active markets (Level 1) and the lowest priority to unobservable inputs (Level 3). The three levels are defined as follows:

[0001564590-16-012196:notes:69]
|  | · | Level 1 Inputs - unadjusted quoted prices in active markets for identical assets or liabilities; |

[0001564590-16-012196:notes:70]
|  | · | Level 2 Inputs - quoted prices for similar assets and liabilities in active markets or inputs that are observable for the asset or liability, either directly or indirectly through market corroboration, for substantially the full term of the financial instrument; and |

[0001564590-16-012196:notes:71]
|  | · | Level 3 Inputs - unobservable inputs reflecting the Company's own assumptions in measuring the asset or liability at fair value. |

[0001564590-16-012196:notes:72]
The Company did not hold any financial liabilities that required measurement at fair value on a recurring basis. The following table presents the Company’s fair value hierarchy for its financial assets measured at fair value on a recurring basis (in thousands):

[0001564590-16-012196:notes:73]
| December 31, 2015 |  | Level 1 |  |  | Level 2 |  |  | Level 3 |  |  | Total |  |
|  |  | (In thousands) |  |
| Assets |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Investments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 4,769 |  |  | $ | — |  |  | $ | — |  |  | $ | 4,769 |  |
| Total |  | $ | 4,769 |  |  | $ | — |  |  | $ | — |  |  | $ | 4,769 |  |

[0001564590-16-012196:notes:74]
| June 30, 2015 |  | Level 1 |  |  | Level 2 |  |  | Level 3 |  |  | Total |  |
|  |  | (In thousands) |  |
| Assets |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Investments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 4,770 |  |  | $ | — |  |  | $ | — |  |  | $ | 4,770 |  |
| Total |  | $ | 4,770 |  |  | $ | — |  |  | $ | — |  |  | $ | 4,770 |  |

[0001564590-16-012196:notes:75]
Level 2 investments: the Company includes U.S. government and sovereign obligations, most government agency securities, investment-grade corporate bonds, and state, municipal and provincial obligations for which quoted prices are available as Level 2. There were no transfers of assets or liabilities between Level 1 and Level 2 for the periods presented.

[0001564590-16-012196:notes:76]
The fair value of the borrowings under the Senior Secured Credit Facility, as amended is estimated based on valuations provided by alternative pricing sources supported by observable inputs which is considered Level 2. Due to the short duration until maturity of the credit facility, the fair value approximates the carrying amount of the Company’s total long-term indebtedness, including current portion of $62.0 million and $66.9 million as of December 31 and June 30, 2015, respectively.

[0001564590-16-012196:notes:77]
[same as prior period, unchanged from 0001078271-15-000127:notes:59]

[0001564590-16-012196:notes:78]
Certain of the Company's assets, including intangible assets and goodwill are measured at fair value on a non-recurring basis if impairment is indicated. There were no impairments recorded for the three and six months ended December 31, 2015 or 2014.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001564590-16-012196:notes:79]
| 6. | Share-based Compensation |

[0001564590-16-012196:notes:80]
[same as prior period, unchanged from 0001078271-15-000127:notes:27]

[0001564590-16-012196:notes:81]
As of December 31, 2015, the Company had reserved for issuance (in thousands):

[0001564590-16-012196:notes:82]
|  |  | December 31, 2015 |  |  | June 30, 2015 |  |
| 2014 Employee Stock Purchase Plan |  |  | 11,000 |  |  |  | 12,000 |  |
| Employee stock options and awards outstanding |  |  | 12,485 |  |  |  | 15,273 |  |
| Employee stock options and awards available for grant |  |  | 4,768 |  |  |  | 5,450 |  |
| Total shares reserved for issuance |  |  | 28,253 |  |  |  | 32,723 |  |

[0001564590-16-012196:notes:83]
[same as prior period, unchanged from 0001078271-15-000127:notes:28]

[0001564590-16-012196:notes:84]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | December 31, 2015 |  |  | December 31, 2014 |  |  | December 31, 2015 |  |  | December 31, 2014 |  |
| Cost of product revenue |  | $ | 277 |  |  | $ | 275 |  |  | $ | 572 |  |  | $ | 558 |  |
| Cost of service revenue |  |  | 277 |  |  |  | 272 |  |  |  | 644 |  |  |  | 563 |  |
| Research and development |  |  | 1,165 |  |  |  | 1,544 |  |  |  | 2,795 |  |  |  | 3,188 |  |
| Sales and marketing |  |  | 1,291 |  |  |  | 1,566 |  |  |  | 2,719 |  |  |  | 3,123 |  |
| General and administrative |  |  | 935 |  |  |  | 1,092 |  |  |  | 1,886 |  |  |  | 2,131 |  |
| Total share-based compensation expense |  | $ | 3,945 |  |  | $ | 4,749 |  |  | $ | 8,616 |  |  | $ | 9,563 |  |

[0001564590-16-012196:notes:85]
During the three and six months ended December 31, 2015 and 2014, the Company did not capitalize any share-based compensation expense in inventory, as the amounts were immaterial.

[0001564590-16-012196:notes:86]
[same as prior period, unchanged from 0001078271-15-000127:notes:31]

[0001564590-16-012196:notes:87]
Stock awards may be granted under the 2013 Equity Incentive Plan (the “2013 Plan”) on terms approved by the Compensation Committee of the Board of Directors. Stock awards generally provide for the issuance of restricted stock units (including performance or market-based restricted stock units) which vest over a fixed period.

[0001564590-16-012196:notes:88]
The following table summarizes stock award activity for the six months ended December 31, 2015 (in thousands, except grant date fair value):

[0001564590-16-012196:notes:89]
|  |  | Number of |  |  | Weighted- |  |  |  |  |  |
|  |  | Shares |  |  | Average Grant- |  |  | Aggregate Fair |  |
|  |  | (000’s) |  |  | Date Fair Value |  |  | Market Value ($000’s) |  |
| Non-vested stock awards outstanding at June 30, 2015 |  |  | 4,597 |  |  | $ | 3.82 |  |  |  |  |  |
| Granted |  |  | 2,889 |  |  | $ | 3.14 |  |  |  |  |  |
| Vested |  |  | (1,729 | ) |  | $ | 4.68 |  |  |  |  |  |
| Cancelled |  |  | (582 | ) |  | $ | 3.77 |  |  |  |  |  |
| Non-vested stock awards outstanding at December 31, 2015 |  |  | 5,175 |  |  | $ | 3.16 |  |  | $ | 21,113 |  |

[0001564590-16-012196:notes:90]
The following table summarizes stock option activity under all plans for the six months ended December 31, 2015 (in thousands, except per share and contractual term):

[0001564590-16-012196:notes:91]
|  |  |  |  |  |  | Weighted- |  |  | Weighted- |  |  |  |  |  |
|  |  |  |  |  |  | Average |  |  | Average |  |  | Aggregate |  |
|  |  | Number of |  |  | Exercise |  |  | Remaining |  |  | Intrinsic |  |
|  |  | Shares |  |  | Price |  |  | Contractual |  |  | Value |  |
|  |  | (000’s) |  |  | Per Share |  |  | Term (years) |  |  | (000’s) |  |
| Options outstanding at June 30, 2015 |  |  | 10,604 |  |  | $ | 4.03 |  |  |  | 3.79 |  |  |  | 410 |  |
| Granted |  |  | 5 |  |  | $ | 3.79 |  |  |  |  |  |  |  |  |  |
| Exercised |  |  | (240 | ) |  | $ | 3.23 |  |  |  |  |  |  |  |  |  |
| Cancelled |  |  | (3,059 | ) |  | $ | 3.83 |  |  |  |  |  |  |  |  |  |
| Options outstanding at December 31, 2015 |  |  | 7,310 |  |  | $ | 4.13 |  |  |  | 4.32 |  |  | $ | 3,632 |  |
| Exercisable at December 31, 2015 |  |  | 4,908 |  |  | $ | 4.14 |  |  |  | 3.39 |  |  | $ | 2,174 |  |
| Vested and expected to vest at December 31, 2015 |  |  | 6,984 |  |  | $ | 4.12 |  |  |  | 4.25 |  |  | $ | 3,476 |  |

[0001564590-16-012196:notes:92]
The weighted-average grant-date fair value of options granted during the three and six months ended December 31, 2015 was $1.59. The weighted-average grant-date fair value of options granted during the three and six months ended December 31, 2014 was $1.66 and $1.96, respectively.

[0001564590-16-012196:notes:93]
The weighted-average fair value of shares granted under the Company’s 2014 ESPP during the six months ended December 31, 2015, was $1.97.  The weighted-average fair value of shares granted under the Company’s 1999 ESPP during the three and six months ended December 31, 2014, was $1.17 and $1.33, respectively.

[0001564590-16-012196:notes:94]
The Company uses the straight-line method for expense attribution, and the Company estimates forfeitures and only recognizes expense for those shares expected to vest. The Company’s estimated forfeiture rate for fiscal 2016 is based on the Company’s historical forfeiture experience and is 13% for non-executives and 19% for executives.

[0001564590-16-012196:notes:95]
The fair value of each stock option grant under the Company's 2013 Plan and 2005 Equity Incentive Plan is estimated on the date of grant using the Black-Scholes-Merton option valuation model with the weighted average assumptions noted in the following table. The Company uses the Monte-Carlo simulation model to determine the fair value and the derived service period of stock awards with market conditions, on the date of the grant. The expected term of options granted is derived from historical data on employee exercise and post-vesting employment termination behavior. The risk-free rate is based upon the estimated life of the option and is based on the U.S. Treasury yield curve in effect at the time of grant. Expected volatility is based on a blended rate of the implied volatilities from traded options on the Company’s stock and historical volatility on the Company’s stock.

[0001564590-16-012196:notes:96]
The fair value of each share purchase option under the Company's 2014 ESPP and 1999 ESPP is estimated on the date of grant using the Black-Scholes-Merton option valuation model with the weighted average assumptions noted in the following table. The expected term of the 2014 ESPP and the 1999 ESPP represents the term of the offering period of each option. The risk-free rate is based upon the estimated life and is based on the U.S. Treasury yield curve in effect at the time of grant. Expected volatility is based on a blended rate of the implied volatilities from traded options and historical volatility on the Company’s stock.

[0001564590-16-012196:notes:97]
|  |  | Stock Option Plan |  |  | Employee Stock Purchase Plan |  |  | Stock Option Plan |  |  | Employee Stock Purchase Plan |  |
|  |  | Three Months Ended |  |  | Three Months Ended |  |  | Six Months Ended |  |  | Six Months Ended |  |
|  |  | December 31, 2015 |  |  | December 31, 2014 |  |  | December 31, 2015 |  |  | December 31, 2014 |  |  | December 31, 2015 |  |  | December 31, 2014 |  |  | December 31, 2015 |  |  | December 31, 2014 |  |
| Expected life |  | 4.0 years |  |  | 4.8 years |  |  | — |  |  | 0.25 years |  |  | 4.0 years |  |  | 4.7 years |  |  | 1.25 years |  |  | 0.25 years |  |
| Risk-free interest rate |  |  | 1.78 | % |  |  | 1.67 | % |  |  | — | % |  |  | 0.03 | % |  |  | 1.78 | % |  |  | 1.61 | % |  |  | 0.29 | % |  |  | 0.02 | % |
| Volatility |  |  | 52 | % |  |  | 54 | % |  |  | — | % |  |  | 63 | % |  |  | 52 | % |  |  | 54 | % |  |  | 58 | % |  |  | 57 | % |
| Dividend yield |  |  | — | % |  |  | — | % |  |  | — | % |  |  | — | % |  |  | — | % |  |  | — | % |  |  | — | % |  |  | — | % |


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001564590-16-012196:notes:98]
| 7. | Restructuring Charges |

[0001564590-16-012196:notes:99]
As of December 31, 2015, restructuring liabilities were $4.7 million and consisted of obligations for severance benefits, contract termination and other expenses. The short-term restructuring liability is recorded in "Other accrued liabilities" and the long-term restructuring liability is recorded in "Other long-term liabilities" in the condensed consolidated balance sheets. During the three and six months ended December 31, 2015, the Company recorded restructuring charges of $3.0 million and $8.6 million, respectively. Included in the restructuring charges were offsets for future sub-leasing income. The Company has estimated the sub-lease income based on its existing leases agreement, as well the real estate market conditions at the respective locations. The Company also factored into its estimate the time for a sub-lease tenant to enter into an agreement and complete any improvements. The Company will reevaluate any sub-lease income on a regular basis and adjust the accrual as necessary if and when facts should change.

[0001564590-16-012196:notes:100]
[same as prior period, unchanged from 0001078271-15-000127:notes:88]

[0001564590-16-012196:notes:101]
During the fourth quarter of fiscal 2015, we reduced costs through targeted restructuring activities intended to reduce operating costs and realign our organization in the current competitive environment. We initiated a plan to reduce our worldwide headcount by more than 225 employees, primarily in sales and marketing, as well as research and development, consolidate specific global administrative functions, and shift certain operating costs to lower cost regions, among other actions.

[0001564590-16-012196:notes:102]
[same as prior period, unchanged from 0001078271-15-000127:notes:90]

[0001564590-16-012196:notes:103]
During the first half of fiscal 2016, we continued our initiative to realign our operations with a second phase by abandoning excess facilities, primarily in San Jose, California; Salem, New Hampshire; Research Triangle Park, North Carolina and Shannon, Ireland. The abandoned facilities represented approximately 29% of the floor space at these locations and included general office and warehouse space. There may be additional abandonments of excess facilities in future periods as we further align our organization to our business and operational needs.

[0001564590-16-012196:notes:104]
During the first quarter fiscal of 2016, in conjunction with the exiting of facilities noted above, the Company recorded restructuring charges of $5.6 million including $5.4 million for excess facility charges and adjustments to service benefits of $0.2 million.  Excess facilities charges included $4.1 million of accrued lease costs pertaining to the estimated future obligations for non-cancelable lease payments for excess facilities and accelerated depreciation of leasehold improvements in the amount of $1.3 million. This charge is reflected in "Restructuring charge, net of reversals" in the condensed consolidated statements of operations.

[0001564590-16-012196:notes:105]
During the second quarter fiscal of 2016, in conjunction with the exiting of the facilities noted above, the Company incurred restructuring charges of $3.0 million including $2.9 million in excess facilities charges related to amending its lease in North Carolina, thereby reducing it floor space by 36%, and adjustments to severance benefits of $0.2 million. Excess facilities charges included accelerated depreciation of leasehold improvements in the amount of $1.9 million and contract termination charges and professional fees of $1.0 million. This charge is reflected in "Restructuring charge, net of reversals" in the condensed consolidated statements of operations.

[0001564590-16-012196:notes:106]
As of December 31, 2015, the Company had restructuring liabilities of $4.7 million. The severance benefits accrual is expected to be paid by the end of the third quarter of fiscal 2016. The excess facilities accrual payments will continue through fiscal year 2023, due to the length of the agreements.

[0001564590-16-012196:notes:107]
[same as prior period, unchanged from 0001078271-15-000127:notes:94]

[0001564590-16-012196:notes:108]
|  |  | Excess Facilities |  |  | Severance Benefits |  |  | Other |  |  | Total |  |
| Balance as of June 30, 2015 |  | $ | — |  |  | $ | 5,737 |  |  | $ | 117 |  |  | $ | 5,854 |  |
| Period charges |  |  | 5,409 |  |  |  | 321 |  |  |  | 178 |  |  |  | 5,908 |  |
| Period reversals |  |  | — |  |  |  | (235 | ) |  |  | (70 | ) |  |  | (305 | ) |
| Non cash adjustments |  |  | (1,344 | ) |  |  | — |  |  |  | — |  |  |  | (1,344 | ) |
| Period payments |  |  | (42 | ) |  |  | (4,207 | ) |  |  | (125 | ) |  |  | (4,374 | ) |
| Balance as of September 30, 2015 |  |  | 4,023 |  |  |  | 1,616 |  |  |  | 100 |  |  |  | 5,739 |  |
| Period charges |  |  | 2,874 |  |  |  | 347 |  |  |  | 53 |  |  |  | 3,274 |  |
| Period reversals |  |  | (14 | ) |  |  | (209 | ) |  |  | (20 | ) |  |  | (243 | ) |
| Non cash adjustments |  |  | (1,876 | ) |  |  | — |  |  |  | — |  |  |  | (1,876 | ) |
| Period payments |  |  | (653 | ) |  |  | (1,365 | ) |  |  | (133 | ) |  |  | (2,151 | ) |
| Balance as of December 31, 2015 |  | $ | 4,354 |  |  | $ | 389 |  |  | $ | — |  |  | $ | 4,743 |  |
| Less: current portion recorded in Other accrued liabilities |  |  |  |  |  |  |  |  |  |  |  |  |  |  | (2,588 | ) |
| Restructuring accrual included in Other long-term liabilities |  |  |  |  |  |  |  |  |  |  |  |  |  | $ | 2,155 |  |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001564590-16-012196:notes:109]
| 8. | Commitments and Contingencies |

[0001564590-16-012196:notes:110]
Purchase Commitments

[0001564590-16-012196:notes:111]
The Company currently has arrangements with contract manufacturers and suppliers for the manufacture of its products. The arrangements allow them to procure long lead-time component inventory based upon a rolling production forecast provided by the Company. The Company is obligated to purchase long lead-time component inventory that its contract manufacturer procures in accordance with the Company’s forecast, unless the Company gives notice of order cancellation outside of applicable component lead-times. As of December 31, 2015, the Company had non-cancelable commitments to purchase $64.3 million of such inventory.

[0001564590-16-012196:notes:112]
Legal Proceedings

[0001564590-16-012196:notes:113]
The Company may from time to time be party to litigation arising in the course of its business, including, without limitation, allegations relating to commercial transactions, business relationships or intellectual property rights. Such claims, even if not meritorious, could result in the expenditure of significant financial and managerial resources. Litigation in general and intellectual property and securities litigation in particular, can be expensive and disruptive to normal business operations. Moreover, the results of legal proceedings are difficult to predict.

[0001564590-16-012196:notes:114]
In accordance with applicable accounting guidance, the Company records accruals for certain of its outstanding legal proceedings, investigations or claims when it is probable that a liability will be incurred and the amount of loss can be reasonably estimated. The Company evaluates, at least on a quarterly basis, developments in legal proceedings, investigations or claims that could affect the amount of any accrual, as well as any developments that would result in a loss contingency to become both probable and reasonably estimable. When a loss contingency is not both probable and reasonably estimable, the Company does not record a loss accrual.  However, if the loss (or an additional loss in excess of any prior accrual) is at least a reasonable possibility and material, then the Company would disclose an estimate of the possible loss or range of loss, if such estimate can be made, or disclose that an estimate cannot be made. The assessment whether a loss is probable or a reasonable possibility, and whether the loss or a range of loss is estimable, involves a series of complex judgments about future events. Even if a loss is reasonably possible, the Company may not be able to estimate a range of possible loss, particularly where (i) the damages sought are substantial or indeterminate, (ii) the proceedings are in the early stages, or (iii) the matters involve novel or unsettled legal theories or a large number of parties. In such cases, there is considerable uncertainty regarding the ultimate resolution of such matters, including the amount of any possible loss, fine or penalty.  Accordingly, for current proceedings, except as noted below, the Company is currently unable to estimate any reasonably possible loss or range of possible loss.  However, an adverse resolution of one or more of such matters could have a material adverse effect on the Company's results of operations in a particular quarter or fiscal year.

[0001564590-16-012196:notes:115]
Brazilian Tax Assessment Matters

[0001564590-16-012196:notes:116]
Certain Brazilian tax authorities have made tax assessments against our Brazilian subsidiary, Enterasys Networks do Brazil Ltda., based on an alleged underpayment of taxes.  The tax authorities are also seeking interest and penalties with respect to such claims (collectively, the “ICMS Tax Assessments”).  The State of Sao Paolo, Brazil denied Enterasys Networks do Brazil Ltda. the use of certain tax credits granted by the State of Espirito Santo, Brazil under the terms of the FUNDAP program for the tax years of 2002 through 2009. The Company’s application to resolve the ICMS Tax Assessments at the administrative level of the Sao Paolo Tax Department under the amnesty relief program (Reference No 3.056.963-1) was denied in March, 2014, by the Sao Paolo Tax Administration. The value of the ICMS tax credits that were disallowed by the Sao Paolo Tax Administration is BR 3.4   million (US $0.9 million), plus interest and penalties BR 16.6 million (US $4.3 million). Possible court fees are estimated to be BR 4.0 million (US $1.0 million). On January 10, 2014, the Company filed a lawsuit to overturn or reduce the ICMS Assessments, which lawsuit remains on-going. As part of this lawsuit, the Company made a request for a stay of execution, so that no tax foreclosure can be filed until a final ruling is made and no guarantee needs to be presented. On or about October 6, 2014, the preliminary injunction was granted with regard to the stay of execution, and in response to an appeal on the guarantee requirement, the appellant court further ruled on or about January 28, 2015 that no cash deposit (or guarantee) need be made by the Company.

[0001564590-16-012196:notes:117]
On or about June 18, 2014, the State of San Paolo notified Enterasys Networks do Brazil Ltda. that it intends to audit the records of such entity for tax years 2012 and 2013.  In addition, the Company received a similar notice in December 2015 with respect to an audit by the State of San Paolo of tax years 2011-2014. The audits are expected to cover the same or very similar issues as the ICMS Tax Assessments for tax years 2002-2009, however, the Company changed their ICMS procedures effective May 2009 and a similar tax assessment is not anticipated.  The Company has provided the requested information for these tax years to the Brazilian tax authorities, but has received no further response from the Brazilian tax authorities.

[0001564590-16-012196:notes:118]
Based on the currently available information, the Company believes the ultimate outcome of the above audits and assessments will not have a material adverse effect on the Company's financial position or overall results of operations. The Company believes that the ICMS Tax Assessments against our Brazilian subsidiary are without merit and we are defending the claims vigorously. While the Company believes there is no legal basis for the alleged liability, due to the complexities and uncertainty surrounding the judicial process in Brazil and the nature of the claims asserted, we are unable to determine the likelihood of an unfavorable outcome against our Brazilian subsidiary and estimate the potential tax liability related to the ICMS Tax Assessments, if any, may be up to BR23.4 million (US $6.0 million). We do not expect a final judicial determination for several years.  The Company believes BR 9.4 million (US $2.4 million) is the best estimate within the range and has recorded an accrual as of the Acquisition Date of Enterasys as such matter relates to the period before the acquisition.

[0001564590-16-012196:notes:119]
The Company made a demand on April 11, 2014 for a defense from, and indemnification by, the former equity holder of Enterasys Networks (“Seller”) of the ICMS Tax Assessments. Seller agreed to assume the defense of the ICMS Tax Assessments on May 20, 2014. In addition, through the settlement of the Unify Indemnification Suit on June 18, 2015, Seller has agreed to continue to defend the Company with respect to the ICMS Tax Assessments and to indemnify the Company for losses related thereto subject to certain conditions. In addition, the Seller has agreed to indemnify the Company in connection with tax assessments up to a specified cap related to the 2012 and 2013 tax years subject to certain conditions.  These conditions include the offsetting of foreign income tax benefits realized by the Company in the connection with the acquisition of Enterasys. Based upon current projections of the foreign income tax benefits to be realized, the Company does not anticipate that any amounts under the indemnification will be due from Seller in connection with either the ICMS Tax Assessments or any potential tax assessments for tax years 2012 and 2013.

[0001564590-16-012196:notes:120]
In re Extreme Networks, Inc. Securities Litigation

[0001564590-16-012196:notes:121]
On October 23 and 29, 2015, complaints were filed for violations of securities laws in the U.S. District Court for the Northern District of California against the Company and three of its current or former officers (Charles W. Berger, Kenneth B. Arola, and John T. Kurtzweil).  Subsequently, the cases were consolidated.  Plaintiffs allege that defendants violated the securities laws by disseminating materially false and misleading statements and concealing material adverse facts regarding Extreme Networks' current financial condition and growth prospects. Plaintiffs seek damages of an unspecified amount on behalf of a purported class of investors who purchased the Company's common stock from November 4, 2013 through April 9, 2015.  Motions for appointment of lead plaintiff have been filed, and are scheduled to be heard on May 5, 2016.  The Company believes the claims are without merit and intends to vigorously defend the claims.

[0001564590-16-012196:notes:122]
Indemnification Obligations

[0001564590-16-012196:notes:123]
Subject to certain limitations, the Company may be obligated to indemnify its current and former directors, officers and employees. These obligations arise under the terms of its certificate of incorporation, its bylaws, applicable contracts, and Delaware and California law. The obligation to indemnify, where applicable, generally means that the Company is required to pay or reimburse, and in certain circumstances the Company has paid or reimbursed, the individuals' reasonable legal expenses and possibly damages and other liabilities incurred in connection with these matters. It is not possible to estimate the maximum potential amount under these indemnification agreements due to the limited history of these claims. The cost to defend the Company and the named individuals could have a material adverse effect on its consolidated financial position, results of operations and cash flows in the future. Recovery of such costs under its director and officers’ insurance coverage is uncertain. As of December 31, 2015, the Company had no outstanding indemnification claims.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001564590-16-012196:notes:124]
| 9. | Income Taxes |

[0001564590-16-012196:notes:125]
For the three and six months ended December 31, 2015, the Company recorded an income tax provision of $1.2 million and $2.1 million, respectively. For the three and six months ended December 31, 2014, the Company recorded an income tax provision of $1.3 million and $2.3 million, respectively.

[0001564590-16-012196:notes:126]
The income tax provisions for the three and six months ended December 31, 2015 and 2014, consisted primarily of taxes on the income of our foreign subsidiaries as well as tax expense associated with the establishment of a U.S. deferred tax liability for amortizable goodwill resulting from the acquisition of Enterasys Networks, Inc. The income tax provisions for both fiscal years were calculated based on the actual results of operations for the three and six months ended December 31, 2015 and 2014, and therefore may not reflect the annual effective tax rate.

[0001564590-16-012196:notes:127]
The Company has provided a full valuation allowance against all of its U.S. federal and state deferred tax assets as well as the deferred tax assets in Australia, Brazil, Japan and Singapore. A valuation allowance is determined by assessing both negative and positive evidence to determine whether it is “more likely than not” that the deferred tax assets are recoverable; such assessment is required on a jurisdiction by jurisdiction basis. The Company's inconsistent earnings in recent periods, including a cumulative loss over the last three years, coupled with its difficulty in forecasting future revenue trends as well as the cyclical nature of its business represent sufficient negative evidence to require a full valuation allowance against its U.S. federal and state net deferred tax assets as well as the above mentioned foreign jurisdictions. This valuation allowance will be evaluated periodically and can be reversed partially or in whole if business results and the economic environment have sufficiently improved to support realization of some or all of the Company's deferred tax assets.

[0001564590-16-012196:notes:128]
During 2015, Congress passed legislation that would make the R&D Tax Credit permanent and on December 18, 2015, President Obama signed the Protecting Americans from Tax Hikes (“PATH”) Act of 2015, which includes a provision making permanent the R&D tax credit under Section 41 of the Code. This credit previously expired on December 31, 2014.  The Company’s balance sheet at December 31, 2015, reflects this retroactive reinstatement of the credit to January 1, 2015 offset in full by a valuation allowance.

[0001564590-16-012196:notes:129]
The acquisition of Enterasys included a U.S. parent company as well as its wholly-owned domestic and foreign subsidiaries. The Company has elected to treat this stock acquisition as an asset purchase by filing the required election forms under IRC Sec 338(h)(10). The Company has estimated the value of the intangible assets from this transaction and is amortizing the amount over 15 years for tax purposes. During the three and six months ended December 31, 2015, the Company deducted $1.1 million and $2.2 million of tax amortization expense, respectively related to capitalized goodwill. As of December 31, 2015, the Company recorded a deferred tax liability of $3.6 million related to this amortization which is not considered a future source of taxable income in evaluating the need for a valuation allowance against our deferred tax assets.

[0001564590-16-012196:notes:130]
The Company had $11.5 million of unrecognized tax benefits as of December 31, 2015. The future impact of the unrecognized tax benefit of $11.5 million, if recognized, would result in adjustments to deferred tax assets and corresponding adjustments to the valuation allowance. The Company does not anticipate any events to occur during the next twelve months that would reduce the unrealized tax benefit as currently stated in the Company’s balance sheet.

[0001564590-16-012196:notes:131]
The Company’s policy is to accrue interest and penalties related to the underpayment of income taxes as a component of tax expense in the condensed consolidated statements of operations.

[0001564590-16-012196:notes:132]
[same as prior period, unchanged from 0001078271-15-000127:notes:68]


## us-gaap:EarningsPerShareTextBlock

[0001564590-16-012196:notes:133]
| 10. | Net Loss Per Share |

[0001564590-16-012196:notes:134]
Basic earnings per share is calculated by dividing net earnings by the weighted average number of common shares outstanding during the period. Dilutive earnings per share is calculated by dividing net earnings by the weighted average number of common shares used in the basic earnings per share calculation plus the dilutive effect of shares subject to repurchase, options, warrants and unvested restricted stock units.

[0001564590-16-012196:notes:135]
[same as prior period, unchanged from 0001078271-15-000127:notes:45]

[0001564590-16-012196:notes:136]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | December 31, 2015 |  |  | December 31, 2014 |  |  | December 31, 2015 |  |  | December 31, 2014 |  |
| Net loss |  | $ | (7,234 | ) |  | $ | (13,105 | ) |  | $ | (18,760 | ) |  | $ | (32,435 | ) |
| Weighted-average shares used in per share calculation - basic and diluted |  |  | 102,369 |  |  |  | 98,677 |  |  |  | 101,677 |  |  |  | 97,996 |  |
| Net loss per share - basic and diluted |  | $ | (0.07 | ) |  | $ | (0.13 | ) |  | $ | (0.18 | ) |  | $ | (0.33 | ) |

[0001564590-16-012196:notes:137]
[same as prior period, unchanged from 0001078271-15-000127:notes:47]

[0001564590-16-012196:notes:138]
|  |  | December 31, 2015 |  |  | December 31, 2014 |  |
| Options to purchase common stock |  |  | 5,280 |  |  |  | 9,203 |  |
| Restricted stock units |  |  | 1,895 |  |  |  | 1,369 |  |
| Employee Stock Purchase Plan shares |  |  | 449 |  |  |  | 563 |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001564590-16-012196:notes:139]
| 11. | Foreign Exchange Forward Contracts |

[0001564590-16-012196:notes:140]
The Company from time to time enters into foreign exchange forward contracts to mitigate the effect of gains and losses generated by the foreign currency forecasted transactions related to certain operating expenses and re-measurement of certain assets and liabilities denominated in foreign currencies. These derivatives do not qualify as hedges. Changes in the fair value of these foreign exchange forward contracts are offset largely by re-measurement of the underlying assets and liabilities. At December 31,
 2015, we did not have any forward foreign currency contracts.

[0001564590-16-012196:notes:141]
Foreign currency transaction gains and losses from operations was a gain of $0.2 million and $1.3 million for the three and six months ended December 31, 2015, respectively. Foreign currency transaction gains and losses from operations was a gain of less than $0.1 million and a loss of $0.3 million for the three and six months ended December 31, 2014, respectively.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001564590-16-012196:notes:142]
| 12. | Disclosure about Segments of an Enterprise and Geographic Areas |

[0001564590-16-012196:notes:143]
[same as prior period, unchanged from 0001078271-15-000127:notes:115]

[0001564590-16-012196:notes:144]
The Company attributes revenues to geographic regions primarily based on the customer's ship-to location. Information regarding geographic areas is as follows (in thousands):

[0001564590-16-012196:notes:145]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
| Net Revenues: |  | December 31, 2015 |  |  | December 31, 2014 |  |  | December 31, 2015 |  |  | December 31, 2014 |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  | $ | 58,749 |  |  | $ | 58,160 |  |  | $ | 115,093 |  |  | $ | 116,648 |  |
| Other |  |  | 7,743 |  |  |  | 12,576 |  |  |  | 13,585 |  |  |  | 19,917 |  |
| Total Americas |  |  | 66,492 |  |  |  | 70,736 |  |  |  | 128,678 |  |  |  | 136,565 |  |
| EMEA |  |  | 60,102 |  |  |  | 62,574 |  |  |  | 111,128 |  |  |  | 116,509 |  |
| APAC |  |  | 12,711 |  |  |  | 13,898 |  |  |  | 24,080 |  |  |  | 30,408 |  |
| Total net revenues |  | $ | 139,305 |  |  | $ | 147,208 |  |  | $ | 263,886 |  |  | $ | 283,482 |  |

[0001564590-16-012196:notes:146]
| Long Lived Assets: |  | December 31, 2015 |  |  | June 30, 2015 |  |
| Americas |  | $ | 72,674 |  |  | $ | 87,071 |  |
| EMEA |  |  | 20,498 |  |  |  | 29,610 |  |
| APAC |  |  | 2,532 |  |  |  | 3,108 |  |
| Total long lived assets |  | $ | 95,704 |  |  | $ | 119,789 |  |
