# EXTR note change history — 0001078271-15-000127 → 0001564590-16-012196


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2016-02-02):
[0001564590-16-012196:note_history:1]
| 8. | Commitments and Contingencies |
  (was, 2015-11-02, similarity 0.8788):
[0001078271-15-000127:note_history:1]
Commitments and Contingencies

- changed (2016-02-02):
[0001564590-16-012196:note_history:2]
The Company currently has arrangements with contract manufacturers and suppliers for the manufacture of its products. The arrangements allow them to procure long lead-time component inventory based upon a rolling production forecast provided by the Company. The Company is obligated to purchase long lead-time component inventory that its contract manufacturer procures in accordance with the Company’s forecast, unless the Company gives notice of order cancellation outside of applicable component lead-times. As of December 31, 2015, the Company had non-cancelable commitments to purchase $64.3 million of such inventory.
  (was, 2015-11-02, similarity 0.9674):
[0001078271-15-000127:note_history:2]
The Company currently has arrangements with contract manufacturers and suppliers for the manufacture of its products. The arrangements allow them to procure long lead-time component inventory based upon a rolling production forecast provided by the Company. The Company is obligated to the purchase of long lead-time component inventory that its contract manufacturer procures in accordance with the forecast, unless the Company gives notice of order cancellation outside of applicable component lead-times.  As of September 30, 2015, the Company had non-cancelable commitments to purchase $72.5 million of such inventory.

- changed (2016-02-02):
[0001564590-16-012196:note_history:3]
Brazilian Tax Assessment Matters
  (was, 2015-11-02, similarity 0.7385):
[0001078271-15-000127:note_history:3]
2002 - 2009 ICMS Tax Assessment Matters

- added (2016-02-02):
[0001564590-16-012196:note_history:4]
Certain Brazilian tax authorities have made tax assessments against our Brazilian subsidiary, Enterasys Networks do Brazil Ltda., based on an alleged underpayment of taxes.  The tax authorities are also seeking interest and penalties with respect to such claims (collectively, the “ICMS Tax Assessments”).  The State of Sao Paolo, Brazil denied Enterasys Networks do Brazil Ltda. the use of certain tax credits granted by the State of Espirito Santo, Brazil under the terms of the FUNDAP program for the tax years of 2002 through 2009. The Company’s application to resolve the ICMS Tax Assessments at the administrative level of the Sao Paolo Tax Department under the amnesty relief program (Reference No 3.056.963-1) was denied in March, 2014, by the Sao Paolo Tax Administration. The value of the ICMS tax credits that were disallowed by the Sao Paolo Tax Administration is BR 3.4   million (US $0.9 million), plus interest and penalties BR 16.6 million (US $4.3 million). Possible court fees are estimated to be BR 4.0 million (US $1.0 million). On January 10, 2014, the Company filed a lawsuit to overturn or reduce the ICMS Assessments, which lawsuit remains on-going. As part of this lawsuit, the Company made a request for a stay of execution, so that no tax foreclosure can be filed until a final ruling is made and no guarantee needs to be presented. On or about October 6, 2014, the preliminary injunction was granted with regard to the stay of execution, and in response to an appeal on the guarantee requirement, the appellant court further ruled on or about January 28, 2015 that no cash deposit (or guarantee) need be made by the Company.

- added (2016-02-02):
[0001564590-16-012196:note_history:5]
On or about June 18, 2014, the State of San Paolo notified Enterasys Networks do Brazil Ltda. that it intends to audit the records of such entity for tax years 2012 and 2013.  In addition, the Company received a similar notice in December 2015 with respect to an audit by the State of San Paolo of tax years 2011-2014. The audits are expected to cover the same or very similar issues as the ICMS Tax Assessments for tax years 2002-2009, however, the Company changed their ICMS procedures effective May 2009 and a similar tax assessment is not anticipated.  The Company has provided the requested information for these tax years to the Brazilian tax authorities, but has received no further response from the Brazilian tax authorities.

- added (2016-02-02):
[0001564590-16-012196:note_history:6]
Based on the currently available information, the Company believes the ultimate outcome of the above audits and assessments will not have a material adverse effect on the Company's financial position or overall results of operations. The Company believes that the ICMS Tax Assessments against our Brazilian subsidiary are without merit and we are defending the claims vigorously. While the Company believes there is no legal basis for the alleged liability, due to the complexities and uncertainty surrounding the judicial process in Brazil and the nature of the claims asserted, we are unable to determine the likelihood of an unfavorable outcome against our Brazilian subsidiary and estimate the potential tax liability related to the ICMS Tax Assessments, if any, may be up to BR23.4 million (US $6.0 million). We do not expect a final judicial determination for several years.  The Company believes BR 9.4 million (US $2.4 million) is the best estimate within the range and has recorded an accrual as of the Acquisition Date of Enterasys as such matter relates to the period before the acquisition.

- added (2016-02-02):
[0001564590-16-012196:note_history:7]
The Company made a demand on April 11, 2014 for a defense from, and indemnification by, the former equity holder of Enterasys Networks (“Seller”) of the ICMS Tax Assessments. Seller agreed to assume the defense of the ICMS Tax Assessments on May 20, 2014. In addition, through the settlement of the Unify Indemnification Suit on June 18, 2015, Seller has agreed to continue to defend the Company with respect to the ICMS Tax Assessments and to indemnify the Company for losses related thereto subject to certain conditions. In addition, the Seller has agreed to indemnify the Company in connection with tax assessments up to a specified cap related to the 2012 and 2013 tax years subject to certain conditions.  These conditions include the offsetting of foreign income tax benefits realized by the Company in the connection with the acquisition of Enterasys. Based upon current projections of the foreign income tax benefits to be realized, the Company does not anticipate that any amounts under the indemnification will be due from Seller in connection with either the ICMS Tax Assessments or any potential tax assessments for tax years 2012 and 2013.

- added (2016-02-02):
[0001564590-16-012196:note_history:8]
In re Extreme Networks, Inc. Securities Litigation

- added (2016-02-02):
[0001564590-16-012196:note_history:9]
On October 23 and 29, 2015, complaints were filed for violations of securities laws in the U.S. District Court for the Northern District of California against the Company and three of its current or former officers (Charles W. Berger, Kenneth B. Arola, and John T. Kurtzweil).  Subsequently, the cases were consolidated.  Plaintiffs allege that defendants violated the securities laws by disseminating materially false and misleading statements and concealing material adverse facts regarding Extreme Networks' current financial condition and growth prospects. Plaintiffs seek damages of an unspecified amount on behalf of a purported class of investors who purchased the Company's common stock from November 4, 2013 through April 9, 2015.  Motions for appointment of lead plaintiff have been filed, and are scheduled to be heard on May 5, 2016.  The Company believes the claims are without merit and intends to vigorously defend the claims.

- changed (2016-02-02):
[0001564590-16-012196:note_history:10]
Subject to certain limitations, the Company may be obligated to indemnify its current and former directors, officers and employees. These obligations arise under the terms of its certificate of incorporation, its bylaws, applicable contracts, and Delaware and California law. The obligation to indemnify, where applicable, generally means that the Company is required to pay or reimburse, and in certain circumstances the Company has paid or reimbursed, the individuals' reasonable legal expenses and possibly damages and other liabilities incurred in connection with these matters. It is not possible to estimate the maximum potential amount under these indemnification agreements due to the limited history of these claims. The cost to defend the Company and the named individuals could have a material adverse effect on its consolidated financial position, results of operations and cash flows in the future. Recovery of such costs under its director and officers’ insurance coverage is uncertain. As of December 31, 2015, the Company had no outstanding indemnification claims.
  (was, 2015-11-02, similarity 0.9963):
[0001078271-15-000127:note_history:10]
Subject to certain limitations, the Company may be obligated to indemnify its current and former directors, officers and employees. These obligations arise under the terms of its certificate of incorporation, its bylaws, applicable contracts, and Delaware and California law. The obligation to indemnify, where applicable, generally means that the Company is required to pay or reimburse, and in certain circumstances the Company has paid or reimbursed, the individuals' reasonable legal expenses and possibly damages and other liabilities incurred in connection with these matters. It is not possible to estimate the maximum potential amount under these indemnification agreements due to the limited history of these claims. The cost to defend the Company and the named individuals could have a material adverse effect on its consolidated financial position, results of operations and cash flows in the future. Recovery of such costs under its directors and officers’ insurance coverage is uncertain. As of September 30, 2015, the Company had no outstanding indemnification claims.

- removed (2016-02-02):
[0001078271-15-000127:note_history:11]
The State of Sao Paolo (Brazil) denied Enterasys Networks do Brazil Ltda. the use of certain credits derived from the State of Espirito Santo under the terms of the FUNDAP scheme for the tax years of 2002 through 2009.  Enterasys’ application to resolve the ICMS Tax Assessments at the administrative level of the Sao Paolo Tax Department under the amnesty relief program (Reference No 3.056.963-1) was denied in March, 2014, by the Sao Paolo Tax Administration.  The value of the ICMS tax credits that were disallowed by the Sao Paolo Tax Administration is approximately BR 3,433,914 (or approximately US $0.9 million), plus interest and penalties (that are currently estimated to be approximately US $4.1 million).  Possible court fees are estimated to be BR 3,952,598 (or approximately US $1.0 million). On January 10, 2014, Enterasys filed a lawsuit to overturn or reduce the assessment, which lawsuit remains on-going.  As part of this lawsuit, Enterasys made a request for a stay of execution, so that no tax foreclosure can be filed until a final ruling is made and no guarantee needs to be presented.  On or about October 6, 2014, the preliminary injunction was granted with regard to the stay of execution, and in response to an appeal on the guarantee requirement, the appellant court further ruled on or about January 28, 2015 that no cash deposit (or guarantee) need be made by Enterasys.

- removed (2016-02-02):
[0001078271-15-000127:note_history:12]
Given the preliminary nature of the lawsuit, it is premature to assess the likelihood of a particular final outcome.  Based on the currently available information, the Company believes the ultimate outcome of this audit will not have material adverse effect on the Company's financial position or overall results of operations.  The range of the potential total tax liability related to these matters is estimated to be from US $0 million to US $6.0 million, of which the Company believes US $4.3 million is the best estimate within the range and has recorded an accrual as of the Acquisition Date of Enterasys as such matter relates to the period before the acquisition.

- removed (2016-02-02):
[0001078271-15-000127:note_history:13]
Extreme made a demand on April 11, 2014 for a defense from, and indemnification by, Seller of these 2002-2009 ICMS Tax Assessment matters.  Seller agreed to assume the defense of these 2002-2009 ICMS Tax Assessment Matters on May 20, 2014.  In addition, through the settlement of the Unify Indemnification Suit on June 18, 2015, Seller has agreed to continue to defend Extreme in this matter and to indemnify Extreme for losses related thereto subject to certain conditions.  These conditions relate to offsetting of foreign income tax benefits realized by the Company in the connection with the acquisition of Enterasys.  Based upon current projections of the foreign income tax benefits to be realized, the Company does not anticipated that any amounts under the indemnification will be due.

- removed (2016-02-02):
[0001078271-15-000127:note_history:14]
Hong vs Extreme

- removed (2016-02-02):
[0001078271-15-000127:note_history:15]
On October 23, 2015, a complaint was filed for violations of securities laws in the U.S. District Court for the Northern District of California in the name of Jui-Yang Hong, Individually and on behalf of all others similarly situated, against the Company, and named defendants Charles W. Berger, Kenneth B. Arola, and John T. Kurtzweil.  Plaintiff alleges that defendants violated the securities laws by disseminating materially false and misleading statements and concealing material adverse facts regarding Extreme Networks' current financial condition and growth prospects. Plaintiffs seek damages of an unspecified amount.  The Company intends to vigorously defend the suit.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2016-02-02):
[0001564590-16-012196:note_history:16]
| 1. | Description of Business and Basis of Presentation |
  (was, 2015-11-02, similarity 0.9245):
[0001078271-15-000127:note_history:16]
Description of Business and Basis of Presentation

- changed (2016-02-02):
[0001564590-16-012196:note_history:17]
Extreme Networks, Inc. (“Extreme Networks” or the “Company”) is a leading provider of network infrastructure equipment and markets its products primarily to business, governmental, health care, service provider, and educational customers with a focus on large corporate enterprises and metropolitan service providers on a global basis. The Company conducts its sales and marketing activities on a worldwide basis through distributors, resellers and the Company’s field sales organization. Extreme Networks was incorporated in California in 1996 and reincorporated in Delaware in 1999.
  (was, 2015-11-02, similarity 0.9931):
[0001078271-15-000127:note_history:17]
Extreme Networks, Inc. (“Extreme Networks” or “the Company”) is a leading provider of network infrastructure equipment and markets its products primarily to business, governmental, health care, service provider, and educational customers with a focus on large corporate enterprises and metropolitan service providers on a global basis. The Company conducts its sales and marketing activities on a worldwide basis through distributors, resellers and the Company’s field sales organization. Extreme Networks was incorporated in California in 1996 and reincorporated in Delaware in 1999.

- changed (2016-02-02):
[0001564590-16-012196:note_history:18]
The unaudited condensed consolidated financial statements reflect all adjustments, consisting only of normal recurring adjustments that, in the opinion of management, are necessary for a fair presentation of the results of operations and cash flows for the interim periods presented and the financial condition of Extreme Networks at December 31, 2015. The results of operations for the three and six months ended December 31, 2015 are not necessarily indicative of the results that may be expected for fiscal 2016 or any future periods.
  (was, 2015-11-02, similarity 0.7788):
[0001078271-15-000127:note_history:18]
The unaudited condensed consolidated financial statements reflect all adjustments, consisting only of normal recurring adjustments that, in the opinion of management, are necessary for a fair presentation of the results of operations and cash flows for the interim periods presented and the financial condition of Extreme Networks at September 30, 2015.  The results of operations for the three months ended September 30, 2015 are not necessarily indicative of the results that may be expected for fiscal 2016 or any future periods.

- changed (2016-02-02):
[0001564590-16-012196:note_history:19]
Certain balances included in the condensed consolidated statements of cash flows related to restructuring liabilities for prior periods have been reclassified to conform to the current period presentation.  In the condensed consolidated statement of cash flows, the changes in operating assets and liabilities for Other long-term liabilities includes the changes in restructuring liabilities and other accrued liabilities which were previously disclosed separately.
  (was, 2015-11-02, similarity 0.978):
[0001078271-15-000127:note_history:19]
Certain balances included in the consolidated statements of cash flows related to restructuring liabilities for prior periods have been reclassified to conform to the current period presentation.  In the consolidated statement of cash flows, the changes in operating assets and liabilities for Other long-term liabilities includes the changes in restructuring liabilities and other accrued liabilities which were previously disclosed separately.


## us-gaap:SignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2016-02-02):
[0001564590-16-012196:note_history:20]
| 2. | Summary of Significant Accounting Policies |
  (was, 2015-11-02, similarity 0.913):
[0001078271-15-000127:note_history:20]
Summary of Significant Accounting Policies


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2016-02-02):
[0001564590-16-012196:note_history:21]
The Company’s debt is comprised of the following:
  (was, 2015-11-02, similarity 0.9796):
[0001078271-15-000127:note_history:21]
The Company's debt is comprised of the following:

- changed (2016-02-02):
[0001564590-16-012196:note_history:22]
|  |  | December 31, 2015 |  |  | June 30, 2015 |  |
| Current portion of long-term debt: |  |  |  |  |  |  |  |  |
| Term Loan |  | $ | 14,625 |  |  | $ | 11,375 |  |
| Current portion of long-term debt |  | $ | 14,625 |  |  | $ | 11,375 |  |
| Long-term debt, less current portion: |  |  |  |  |  |  |  |  |
| Term Loan |  | $ | 37,375 |  |  | $ | 45,500 |  |
| Revolving Facility |  |  | 10,000 |  |  |  | 10,000 |  |
| Total long-term debt, less current portion |  |  | 47,375 |  |  |  | 55,500 |  |
| Total debt |  | $ | 62,000 |  |  | $ | 66,875 |  |
  (was, 2015-11-02, similarity 0.7479):
[0001078271-15-000127:note_history:22]
|  | September 30, 2015 |  | June 30, 2015 |
| Current portion of long-term debt: |  |  |  |
| Term Loan | $ | 13,000 |  |  | $ | 11,375 |  |
| Current portion of long-term debt | $ | 13,000 |  |  | $ | 11,375 |  |
| Long-term debt, less current portion: |  |  |  |
| Term Loan | $ | 42,250 |  |  | $ | 45,500 |  |
| Revolving Facility | 10,000 |  |  | 10,000 |  |
| Total long-term debt, less current portion | 52,250 |  |  | 55,500 |  |
| Total debt | $ | 65,250 |  |  | $ | 66,875 |  |
