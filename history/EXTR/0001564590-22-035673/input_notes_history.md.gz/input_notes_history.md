# EXTR note change history — 0001564590-22-016543 → 0001564590-22-035673


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2022-10-28):
[0001564590-22-035673:note_history:1]
The Company currently has arrangements with contract manufacturers and suppliers for the manufacture of its products. Those arrangements allow the contract manufacturers to procure long lead-time component inventory based upon a rolling production forecast provided by the Company. The Company is obligated to purchase long lead-time component inventory that its contract manufacturer procures in accordance with the forecast, unless the Company gives notice of order cancellation outside of applicable component lead-times. As of September 30, 2022, the Company had commitments to purchase $52.4 million of inventory.
  (was, 2022-04-29, similarity 0.9876):
[0001564590-22-016543:note_history:1]
The Company currently has arrangements with contract manufacturers and suppliers for the manufacture of its products. Those arrangements allow the contract manufactures to procure long lead-time component inventory based upon a rolling production forecast provided by the Company. The Company is obligated to purchase long lead-time component inventory that its contract manufacturer procures in accordance with the forecast, unless the Company gives notice of order cancellation outside of applicable component lead-times. As of March 31, 2022, the Company had commitments to purchase $70.4 million of inventory.

- changed (2022-10-28):
[0001564590-22-035673:note_history:2]
In accordance with applicable accounting guidance, the Company records accruals for certain of its outstanding legal proceedings, investigations or claims when it is probable that a liability will be incurred, and the amount of loss can be reasonably estimated. The Company evaluates, at least on a quarterly basis, developments in legal proceedings, investigations or claims that could affect the amount of any accrual, as well as any developments that would result in a loss contingency to become both probable and reasonably estimable. When a loss contingency is not both probable and reasonably estimable, the Company does not record a loss accrual. However, if the loss (or an additional loss in excess of any prior accrual) is at least reasonably possible and material, then the Company would disclose an estimate of the possible loss or range of loss, if such estimate can be made, or disclose that an estimate cannot be made. The assessment whether a loss is probable or a reasonable possibility, and whether the loss or a range of loss is estimable, involves a series of complex judgments about future events. Even if a loss is reasonably possible, the Company may not be able to estimate a range of possible loss, particularly where (i) the damages sought are substantial or indeterminate, (ii) the proceedings are in the early stages, or (iii) the matters involve novel or unsettled legal theories or a large number of parties. In such cases, there is considerable uncertainty regarding the ultimate resolution of such matters, including the amount of any possible loss, fine or penalty.  However, an adverse resolution of one or more of such matters could have a material adverse effect on the Company's results of operations in a particular quarter or fiscal year.
  (was, 2022-04-29, similarity 0.8936):
[0001564590-22-016543:note_history:2]
In accordance with applicable accounting guidance, the Company records accruals for certain of its outstanding legal proceedings, investigations or claims when it is probable that a liability will be incurred, and the amount of loss can be reasonably estimated. The Company evaluates, at least on a quarterly basis, developments in legal proceedings, investigations or claims that could affect the amount of any accrual, as well as any developments that would result in a loss contingency to become both probable and reasonably estimable. When a loss contingency is not both probable and reasonably estimable, the Company does not record a loss accrual. However, if the loss (or an additional loss in excess of any prior accrual) is at least reasonably possible and material and a reasonable estimate can be made, then the Company would make an accrual. The assessment whether a loss is probable or a reasonable possibility, and whether the loss or a range of loss is estimable, involves a series of complex judgments about future events. Litigation is unpredictable, and even if a loss is reasonably possible, the Company may not be able to estimate a range of possible loss, particularly where (i) the damages sought are substantial or indeterminate, (ii) the proceedings are in the early stages, or (iii) the matters involve novel or unsettled legal theories or a large number of parties. In such cases, there is considerable uncertainty regarding the ultimate resolution of such matters, including the amount of any possible loss, fine or penalty. An adverse resolution of one or more of such matters could have a material adverse effect on the Company's results of operations in a particular quarter or fiscal year.

- changed (2022-10-28):
[0001564590-22-035673:note_history:3]
On April 19, 2017, XR Communications, LLC (“XR”) (d/b/a Vivato Technologies) filed a patent infringement lawsuit against the Company in the Central District of California. The operative Second Amended Complaint asserts infringement of certain U.S. Patent based on the Company’s manufacture, use, sale, offer for sale, and/or importation into the United States of certain access points and routers supporting multi-user, multiple-input, multiple-output technology. XR seeks unspecified damages, on-going royalties, pre- and post-judgment interest, and attorneys’ fees. The Court dismissed the case without prejudice on January 4, 2022 and on April 18, 2022, entered final judgment in favor of the Company. XR filed a notice of appeal on May 9, 2022 and a response brief from the Company and other defendants is due on November 2, 2022.
  (was, 2022-04-29, similarity 0.7602):
[0001564590-22-016543:note_history:3]
On April 19, 2017, XR Communications, LLC (“XR”) (d/b/a Vivato Technologies) filed a patent infringement lawsuit against the Company in the Central District of California. The operative Second Amended Complaint asserts infringement of certain U.S. Patent based on the Company’s manufacture, use, sale, offer for sale, and/or importation into the United States of certain access points and routers supporting multi-user, multiple-input, multiple-output technology. XR seeks unspecified damages, on-going

- changed (2022-10-28):
[0001564590-22-035673:note_history:4]
On February 1, 2018, Orckit IP, LLC (“Orckit”) filed a patent infringement lawsuit against the Company and its Irish and German subsidiaries in the District Court in Dusseldorf, Germany. The lawsuit alleges direct and indirect infringement of the German portion of a patent (“EP ‘364”) based on the offer, distribution, use, possession and/or importation into Germany of certain network switches that are equipped with the ExtremeXOS operating system. Orckit is seeking injunctive relief, accounting, and an unspecified declaration of liability for damages and costs of the lawsuit. On January 28, 2020, the Court rendered a decision in the infringement case in favor of the Company. The matter is proceeding through the appellate process.
  (was, 2022-04-29, similarity 0.9168):
[0001564590-22-016543:note_history:4]
On February 1, 2018, Orckit IP, LLC (“Orckit”) filed a patent infringement lawsuit against the Company and its Irish and German subsidiaries in the District Court in Dusseldorf, Germany. The lawsuit alleges direct and indirect infringement of the German portion of a patent (“EP ‘364”) based on the offer, distribution, use, possession and/or importation into Germany of certain network switches that equipped with the ExtremeXOS operating system. Orckit is seeking injunctive relief, accounting, and an unspecified declaration of liability for damages and costs of the lawsuit. On January 28, 2020, the Court rendered a decision in the infringement case in favor of the Company. The matter is proceeding through the appellate process, and an oral hearing was held on October 21, 2021.  The Court has appointed an expert to provide an opinion and a decision is pending.

- changed (2022-10-28):
[0001564590-22-035673:note_history:5]
On April 23, 2019, Orckit filed an extension of the patent infringement complaint against the Company and its Irish and German subsidiaries in the District Court in Dusseldorf, Germany. With this extension, Orckit alleges infringement of the German portion of a second patent (“EP ‘077”) based on the offer, distribution, use, possession and/or importation into Germany of certain network switches that the Company no longer sells in Germany. Orckit is seeking injunctive relief, accounting and sales information, and a declaration of liability for damages as well as costs of the lawsuit. On October 13, 2020, the Court issued an infringement decision against the Company and granted Orckit the right to enforce the judgment against the Company, which Orckit has provided notification to the Company that it will enforce the judgment. In the rendering of account, Orckit was informed that the products at issue were in end of sale status prior to the filing of the EP‘077 complaint. The Company has appealed the infringement decision, and the matter is proceeding through the appellate process.
  (was, 2022-04-29, similarity 0.9986):
[0001564590-22-016543:note_history:5]
On April 23, 2019, Orckit filed an extension of the patent infringement complaint against the Company and its Irish and German subsidiaries in the District Court in Dusseldorf, Germany. With this extension, Orckit alleges infringement of the German portion of a second patent (“EP ‘077”) based on the offer, distribution, use, possession and/or importation into Germany of certain network switches that the Company no longer sells in Germany. Orckit is seeking injunctive relief, accounting and sales information, and a declaration of liability for damages as well as costs of the lawsuit. On October 13, 2020, the Court issued an infringement decision against the Company and granted to Orckit the right to enforce the judgment against the Company, which Orckit has provided notification to the Company that it will enforce the judgment. In the rendering of account, Orckit was informed that the products at issue were in end of sale status prior to the filing of the EP‘077 complaint. The Company has appealed the infringement decision, and the matter is proceeding through the appellate process.

- added (2022-10-28):
[0001564590-22-035673:note_history:6]
The Company filed a nullity action related to the EP ‘364 patent on May 3, 2018, and one related to the EP ‘077 patent on October 31, 2019, both in the Federal Patent Court in Munich. The Federal Patent Court in Munich found the EP ‘364 patent to be valid and the Company has filed an appeal. On October 25, 2022, the Federal Patent Court in Munich issued an opinion partially invalidating the patent.

- changed (2022-10-28):
[0001564590-22-035673:note_history:7]
On October 26, 2020, SNMP Research, Inc. and SNMP Research International, Inc. (collectively, “SNMP”) filed a lawsuit against the Company in the Eastern District of Tennessee for copyright infringement, alleging that the Company was not properly licensed to use its software.  SNMP is seeking actual damages and profits attributed to the infringement, as well as equitable relief. The Company filed a motion to transfer the case to the Northern District of California. The motion to dismiss was denied in part and denied without prejudice in part. The Company also filed, and was granted, a motion to compel mediation.  The parties have selected a mediator and set a mediation date of January 19, 2023. The trial date set for February 2023 has been rescheduled to January 2024.
  (was, 2022-04-29, similarity 0.7073):
[0001564590-22-016543:note_history:7]
On October 26, 2020, SNMP Research, Inc. and SNMP Research International, Inc. (collectively, “SNMP”) filed a lawsuit against the Company in the Eastern District of Tennessee for copyright infringement, alleging that the Company was not properly licensed to use its software.  SNMP is seeking actual damages and profits attributed to the infringement, as well as equitable relief. The Company has filed a motion to dismiss and a motion to transfer the case to the Northern District of California. Both motions are pending. A trial date has been set for February 2023.

- changed (2022-10-28):
[0001564590-22-035673:note_history:8]
On April 15, 2021, Mala Technologies Ltd. (“Mala”) filed a patent infringement lawsuit against the Company and its Irish and German subsidiaries in the District Court in Dusseldorf, Germany.  The lawsuit alleges indirect infringement of the German portion of a patent (“EP ‘498”) based on the offer and sale in Germany of certain network switches equipped with the ExtremeXOS operating system.  Mala is seeking injunctive relief, accounting, and an unspecified declaration of liability for damages and costs of the lawsuit.  A hearing date that had been set for July 14, 2022 has been postponed until November 22, 2022. The Company filed a nullity action related to the EP’498 patent on September 24, 2021 in the German Federal Patent Court.
  (was, 2022-04-29, similarity 0.8617):
[0001564590-22-016543:note_history:8]
On April 15, 2021, Mala Technologies Ltd. (“Mala”) filed a patent infringement lawsuit against the Company and its Irish and German subsidiaries in the District Court in Dusseldorf, Germany.  The lawsuit alleges indirect infringement of the German portion of a patent (“EP ‘498”) based on the offer and sale in Germany of certain network switches equipped with the ExtremeXOS operating system.  Mala is seeking injunctive relief, accounting, and an unspecified declaration of liability for damages and costs of the lawsuit.  A hearing date has been set for July 14, 2022.  The Company filed a nullity action related to the EP’498 patent on September 24, 2021 in the German Federal Patent Court.

- removed (2022-10-28):
[0001564590-22-016543:note_history:9]
royalties, pre- and post-judgment interest, and attorneys’ fees. The Court dismissed the case without prejudice on January 4, 2022 and on April 18, 2022, entered final judgment in favor of the Company.  XR has 30 days to file a notice of appeal.

- removed (2022-10-28):
[0001564590-22-016543:note_history:10]
The Company filed a nullity action related to the EP ‘364 patent on May 3, 2018, and one related to the EP ‘077 patent on October 31, 2019, both in the Federal Patent Court in Munich. The court found the EP ‘364 patent to be valid and the Company has filed an appeal.  The case filed to seek to invalidate the EP ‘077 patent is proceeding, with a hearing to be held June 29, 2022.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2022-10-28):
[0001564590-22-035673:note_history:11]
The unaudited condensed consolidated financial statements reflect all adjustments, consisting only of normal recurring adjustments that, in the opinion of management, are necessary for a fair presentation of the results of operations and cash flows for the interim periods presented and the financial condition of Extreme at September 30, 2022. The results of operations for the three months ended September 30, 2022 are not necessarily indicative of the results that may be expected for fiscal 2023 or any future periods.
  (was, 2022-04-29, similarity 0.6824):
[0001564590-22-016543:note_history:11]
The unaudited condensed consolidated financial statements reflect all adjustments, consisting only of normal recurring adjustments that, in the opinion of management, are necessary for a fair presentation of the results of operations and cash flows for the interim periods presented and the financial condition of Extreme at March 31, 2022. The results of operations for the three and nine months ended March 31, 2022 are not necessarily indicative of the results that may be expected for fiscal 2022 or any future periods.


## us-gaap:SignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2022-10-28):
[0001564590-22-035673:note_history:12]
Recently Adopted and Recently Issued Accounting Pronouncements
  (was, 2022-04-29, similarity 0.8077):
[0001564590-22-016543:note_history:12]
Recently Adopted Accounting Pronouncements

- added (2022-10-28):
[0001564590-22-035673:note_history:13]
There were no recently adopted accounting standards which would have a material effect on our condensed consolidated financial statements and accompanying disclosures, and no recently issued accounting standards that are expected to have a material impact on our condensed consolidated financial statements and accompanying disclosures.

- removed (2022-10-28):
[0001564590-22-016543:note_history:14]
In December 2019, the Financial Accounting Standards Board (“the FASB”) issued ASU 2019-12, Income Taxes – Simplifying the Accounting for Income Taxes (Topic 740), which reduces the complexity of accounting for income taxes including the removal of certain exceptions to the general principles of Accounting Standards Codification (“ASC”) 740, Income Taxes, and simplification in several other areas such as accounting for franchise tax (or similar tax) that is partially based on income. This standard is effective for fiscal years beginning after December 15, 2020, including interim periods within the fiscal year. The standard was adopted on July 1, 2021 and did not have a material impact on the Company’s financial statements upon adoption.

- removed (2022-10-28):
[0001564590-22-016543:note_history:15]
Recently Issued and Adopted Accounting Pronouncements

- removed (2022-10-28):
[0001564590-22-016543:note_history:16]
In October 2021, the FASB issued ASU 2021-08, Business Combinations (Topic 805): Accounting for Contract Assets and Contract Liabilities from Contracts with Customers, which requires contract assets and contract liabilities acquired in a business combination to be recognized and measured by the acquirer on the acquisition date in accordance with ASC 606, Revenue from Contracts with Customers, as if it had originated the contracts. Under the current business combinations guidance, such assets and liabilities are recognized by the acquirer at fair value on the acquisition date. ASU 2021-08 is effective for annual periods beginning after December 15, 2022 and interim periods within those annual periods, with early adoption permitted, including adoption in an interim period. The Company elected to early adopt the standard in the quarter ended December 31, 2021 and retrospectively applied the standard to the acquisition that happened in the current fiscal year beginning July 1, 2021. The application of the guidance increased the deferred revenue balance acquired through the acquisition of Ipanema by $7.1 million as of the acquisition date.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2022-10-28):
[0001564590-22-035673:note_history:17]
|  |  | September 30, 2022 |  |  | June 30, 2022 |  |
| Current portion of long-term debt: |  |  |  |  |  |  |  |  |
| Term Loan |  | $ | 38,000 |  |  | $ | 35,625 |  |
| Less: unamortized debt issuance costs |  |  | (2,236 | ) |  |  | (2,276 | ) |
| Current portion of long-term debt |  | $ | 35,764 |  |  | $ | 33,349 |  |
| Long-term debt, less current portion: |  |  |  |  |  |  |  |  |
| Term Loan |  | $ | 233,500 |  |  | $ | 273,000 |  |
| Less: unamortized debt issuance costs |  |  | (1,860 | ) |  |  | (2,430 | ) |
| Total long-term debt, less current portion |  |  | 231,640 |  |  |  | 270,570 |  |
| Total debt |  | $ | 267,404 |  |  | $ | 303,919 |  |
  (was, 2022-04-29, similarity 0.9868):
[0001564590-22-016543:note_history:17]
|  |  | March 31, 2022 |  |  | June 30, 2021 |  |
| Current portion of long-term debt: |  |  |  |  |  |  |  |  |
| Term Loan |  | $ | 33,250 |  |  | $ | 26,125 |  |
| Less: unamortized debt issuance costs |  |  | (2,305 | ) |  |  | (2,404 | ) |
| Current portion of long-term debt |  | $ | 30,945 |  |  | $ | 23,721 |  |
| Long-term debt, less current portion: |  |  |  |  |  |  |  |  |
| Term Loan |  | $ | 282,500 |  |  | $ | 320,625 |  |
| Less: unamortized debt issuance costs |  |  | (2,986 | ) |  |  | (4,760 | ) |
| Total long-term debt, less current portion |  |  | 279,514 |  |  |  | 315,865 |  |
| Total debt |  | $ | 310,459 |  |  | $ | 339,586 |  |

- changed (2022-10-28):
[0001564590-22-035673:note_history:18]
On August 9, 2019, the Company entered into an Amended and Restated Credit Agreement (the “2019 Credit Agreement”), by and among the Company, as borrower, several banks and other financial institutions as Lenders, BMO Harris Bank N.A., as an issuing lender and swingline lender, Silicon Valley Bank, as an Issuing Lender, and Bank of Montreal, as administrative agent and collateral agent for the Lenders.
  (was, 2022-04-29, similarity 0.9265):
[0001564590-22-016543:note_history:18]
In connection with the acquisition of Aerohive Networks, Inc., on August 9, 2019, the Company entered into an Amended and Restated Credit Agreement (the “2019 Credit Agreement”), by and among the Company, as borrower, several banks and other financial institutions as Lenders, BMO Harris Bank N.A., as an issuing lender and swingline lender, Silicon Valley Bank, as an Issuing Lender, and Bank of Montreal, as administrative agent and collateral agent for the Lenders.

- changed (2022-10-28):
[0001564590-22-035673:note_history:19]
On April 8, 2020, the Company entered into an amendment to the 2019 Credit Agreement (the “First Amendment”) to waive certain terms and financial covenants of the 2019 Credit Agreement through July 31, 2020. On May 8, 2020, the Company entered into a second amendment to the 2019 Credit Agreement (the “Second Amendment”), which superseded the First Amendment and provided certain revised terms and financial covenants through March 31, 2021. The Second Amendment required the Company to maintain certain minimum cash requirement and financial metrics at the end of each fiscal quarter through March 31, 2021 and the Company was restricted from pursuing certain activities such as incurring additional debt, stock repurchases, making acquisitions or declaring a dividend, until the Company was in compliance with the original covenants of the 2019 Credit Agreement.
  (was, 2022-04-29, similarity 0.7285):
[0001564590-22-016543:note_history:19]
On April 8, 2020, the Company entered into the first amendment to the 2019 Credit Agreement (the “First Amendment”) to waive certain terms and financial covenants of the 2019 Credit Agreement through July 31, 2020. On May 8, 2020, the Company entered into the second amendment to the 2019 Credit Agreement (the “Second Amendment”), which superseded the First Amendment and provided certain revised terms and financial covenants through March 31, 2021. Subsequent to March 31, 2021, the original terms and financial covenants under the 2019 Credit Agreement resumed in effect. The Second Amendment required the Company to maintain certain minimum cash requirement and certain financial metrics at the end of each fiscal quarter through March 31, 2021. Under the terms of the Second Amendment, the Company was not permitted to exceed $55.0 million in its outstanding balance under the 2019 Revolving Facility, the applicable margin for Eurodollar rate was 4.50%, and the Company was restricted from pursuing certain activities such as incurring additional debt, stock repurchases, making acquisitions or declaring a dividend, until the Company was in compliance with the original covenants of the 2019 Credit Agreement.

- changed (2022-10-28):
[0001564590-22-035673:note_history:20]
On November 3, 2020, the Company and its lenders entered into a Third Amendment to the 2019 Credit Agreement (the “Third Amendment”), to increase the sublimit for letters of credit to $20.0 million. On December 8, 2020, the Company and its lenders entered into a fourth amendment to the 2019 Credit Agreement (the “Fourth Amendment”), to waive and amend certain terms and financial covenants within the 2019 Credit Agreement through March 31, 2021.
  (was, 2022-04-29, similarity 0.9905):
[0001564590-22-016543:note_history:20]
On November 3, 2020, the Company and its lenders entered into the Third Amendment to the 2019 Credit Agreement (the “Third Amendment”), to increase the sublimit for letters of credit to $20.0 million. On December 8, 2020, the Company and its lenders entered into the fourth amendment to the 2019 Credit Agreement (the “Fourth Amendment”), to waive and amend certain terms and financial covenants within the 2019 Credit Agreement through March 31, 2021.

- changed (2022-10-28):
[0001564590-22-035673:note_history:21]
The Second Amendment provided for the Company to end the covenant Suspension Period early and revert to the covenants and interest rates per the original terms of the 2019 Credit Agreement dated August 9, 2019 by filing a Suspension Period Early Termination Notice and Covenant Certificate demonstrating compliance. For the twelve-month period ended March 31, 2021, the Company’s financial performance was in compliance with the original covenants defined in the 2019 Credit Agreement and, as such,
  (was, 2022-04-29, similarity 0.8496):
[0001564590-22-016543:note_history:21]
The Second Amendment provided for the Company to end the covenant Suspension Period early and revert to the covenants and interest rates per the original terms of the 2019 Credit Agreement dated August 9, 2019 by filing a Suspension Period Early Termination Notice and Covenant Certificate demonstrating compliance. For the twelve-month period ended March 31, 2021, the

- added (2022-10-28):
[0001564590-22-035673:note_history:22]
the Company filed a Suspension Early Termination Notice and Covenant Certificate with the administration agent subsequent to filing the Company’s Quarterly Report on Form 10-Q for the period ended March 31, 2021. Returning to compliance, the original terms and financial covenants under the 2019 Credit Agreement dated August 9, 2019 resumed in effect. During the three months ended September 30, 2022, the Company was in compliance with all the terms and financial covenants under the 2019 Credit Agreement.

- added (2022-10-28):
[0001564590-22-035673:note_history:23]
Financing costs incurred in connection with obtaining long-term financing are deferred and amortized over the term of the related indebtedness or credit agreement. Amortization of deferred financing costs included in “Interest expense” in the accompanying condensed consolidated statements of operations were $0.7 million and $0.8 million for the three months ended September 30, 2022 and 2021. The interest rate as of September 30, 2022 was 4.5% and as of September 30, 2021 was 2.4%.

- added (2022-10-28):
[0001564590-22-035673:note_history:24]
As of September 30, 2022, the Company did not have any outstanding balance against its 2019 Revolving Facility’s outstanding balance.  The Company had $60.2 million of availability under the 2019 Revolving Facility as of September 30, 2022. During the three months ended September 30, 2022 and 2021, the Company made an additional payment of $30.0 million and $12.0 million against its term loan facility, respectively.

- changed (2022-10-28):
[0001564590-22-035673:note_history:25]
The Company had $14.8 million of outstanding letters of credit as of September 30, 2022.
  (was, 2022-04-29, similarity 0.9351):
[0001564590-22-016543:note_history:25]
The Company had $14.8 million of outstanding letters of credit as of March 31, 2022.

- removed (2022-10-28):
[0001564590-22-016543:note_history:26]
Company’s financial performance was in compliance with the original covenants defined in the 2019 Credit Agreement and, as such, the Company filed a Suspension Early Termination Notice and Covenant Certificate with the administration agent subsequent to filing the Company’s Quarterly Report on Form 10-Q for the period ended March 31, 2021. Returning to compliance with the covenants per the original terms of the 2019 Credit Agreement dated August 9, 2019 resulted in the Company’s Eurodollar loan spread decreasing from 4.50% during the suspension period to 2.75% and unused facility commitment fee decreasing from 0.40% to 0.35%, and the limitation on revolver borrowings being removed effective May 1, 2021 after filing of the certificate with the administrative agent.

- removed (2022-10-28):
[0001564590-22-016543:note_history:27]
Financing costs incurred in connection with obtaining long-term financing are deferred and amortized over the term of the related indebtedness or credit agreement. During the year ended June 30, 2020, the Company incurred $10.5 million of deferred financing costs in conjunction with the 2019 Credit Agreement and $1.5 million of deferred financing costs from the amendments, and continues to amortize $1.6 million of debt issuance costs as of August 9, 2019 that were associated with the previous facility. The interest rate as of March 31, 2022 was 2.07% and as of March 31, 2021 was 4.60%.

- removed (2022-10-28):
[0001564590-22-016543:note_history:28]
Amortization of deferred financing costs included in “Interest expense” in the accompanying condensed consolidated statements of operations were $0.7 million each for the three months ended March 31, 2022 and 2021 and were $2.3 million each for the nine months ended March 31, 2022 and 2021.

- removed (2022-10-28):
[0001564590-22-016543:note_history:29]
During the fiscal year ended June 30, 2021, the Company repaid $55.0 million against its 2019 Revolving Facility’s outstanding balance of $55.0 million and had no remaining outstanding balance at March 31, 2022. The Company had $60.2 million of availability under the 2019 Revolving Facility as of March 31, 2022. During the nine months ended March 31, 2022, the Company made an additional payment of $12.0 million against its term loan facility.


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2022-10-28):
[0001564590-22-035673:note_history:30]
|  |  | September 30, 2022 |  |  | June 30, 2022 |  |
| Current portion of long-term debt: |  |  |  |  |  |  |  |  |
| Term Loan |  | $ | 38,000 |  |  | $ | 35,625 |  |
| Less: unamortized debt issuance costs |  |  | (2,236 | ) |  |  | (2,276 | ) |
| Current portion of long-term debt |  | $ | 35,764 |  |  | $ | 33,349 |  |
| Long-term debt, less current portion: |  |  |  |  |  |  |  |  |
| Term Loan |  | $ | 233,500 |  |  | $ | 273,000 |  |
| Less: unamortized debt issuance costs |  |  | (1,860 | ) |  |  | (2,430 | ) |
| Total long-term debt, less current portion |  |  | 231,640 |  |  |  | 270,570 |  |
| Total debt |  | $ | 267,404 |  |  | $ | 303,919 |  |
  (was, 2022-04-29, similarity 0.9868):
[0001564590-22-016543:note_history:30]
|  |  | March 31, 2022 |  |  | June 30, 2021 |  |
| Current portion of long-term debt: |  |  |  |  |  |  |  |  |
| Term Loan |  | $ | 33,250 |  |  | $ | 26,125 |  |
| Less: unamortized debt issuance costs |  |  | (2,305 | ) |  |  | (2,404 | ) |
| Current portion of long-term debt |  | $ | 30,945 |  |  | $ | 23,721 |  |
| Long-term debt, less current portion: |  |  |  |  |  |  |  |  |
| Term Loan |  | $ | 282,500 |  |  | $ | 320,625 |  |
| Less: unamortized debt issuance costs |  |  | (2,986 | ) |  |  | (4,760 | ) |
| Total long-term debt, less current portion |  |  | 279,514 |  |  |  | 315,865 |  |
| Total debt |  | $ | 310,459 |  |  | $ | 339,586 |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- added (2022-10-28):
[0001564590-22-035673:note_history:31]
The following table sets forth the Company’s revenues disaggregated by sales channel and geographic region based on the billing addresses of its customers (in thousands):

- changed (2022-10-28):
[0001564590-22-035673:note_history:32]
|  |  | Three Months Ended |  |
|  |  | September 30, 2022 |  |  | September 30, 2021 |  |
|  |  | Distributor |  | Direct |  | Total |  |  | Distributor |  | Direct |  | Total |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  | $ | 73,314 |  | $ | 64,312 |  | $ | 137,626 |  |  | $ | 56,068 |  | $ | 67,331 |  | $ | 123,399 |  |
| Other |  |  | 16,025 |  |  | 4,098 |  |  | 20,123 |  |  |  | 7,799 |  |  | 3,367 |  |  | 11,166 |  |
| Total Americas |  |  | 89,339 |  |  | 68,410 |  |  | 157,749 |  |  |  | 63,867 |  |  | 70,698 |  |  | 134,565 |  |
| EMEA |  |  | 76,256 |  |  | 39,253 |  |  | 115,509 |  |  |  | 77,898 |  |  | 35,731 |  |  | 113,629 |  |
| APAC |  |  | 2,038 |  |  | 22,393 |  |  | 24,431 |  |  |  | 4,335 |  |  | 15,155 |  |  | 19,490 |  |
| Total net revenues |  | $ | 167,633 |  | $ | 130,056 |  | $ | 297,689 |  |  | $ | 146,100 |  | $ | 121,584 |  | $ | 267,684 |  |
  (was, 2022-04-29, similarity 0.9634):
[0001564590-22-016543:note_history:32]
|  |  | Three Months Ended |  |
|  |  | March 31, 2022 |  |  | March 31, 2021 |  |
|  |  | Distributor |  | Direct |  | Total |  |  | Distributor |  | Direct |  | Total |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  | $ | 59,582 |  | $ | 60,852 |  | $ | 120,434 |  |  | $ | 54,873 |  | $ | 62,172 |  | $ | 117,045 |  |
| Other |  |  | 7,574 |  |  | 3,513 |  |  | 11,087 |  |  |  | 8,926 |  |  | 3,730 |  |  | 12,656 |  |
| Total Americas |  |  | 67,156 |  |  | 64,365 |  |  | 131,521 |  |  |  | 63,799 |  |  | 65,902 |  |  | 129,701 |  |
| EMEA |  |  | 101,980 |  |  | 36,844 |  |  | 138,824 |  |  |  | 65,210 |  |  | 34,127 |  |  | 99,337 |  |
| APAC |  |  | 40 |  |  | 15,123 |  |  | 15,163 |  |  |  | 3,569 |  |  | 20,793 |  |  | 24,362 |  |
| Total net revenues |  | $ | 169,176 |  | $ | 116,332 |  | $ | 285,508 |  |  | $ | 132,578 |  | $ | 120,822 |  | $ | 253,400 |  |

- removed (2022-10-28):
[0001564590-22-016543:note_history:33]
The Company operates in three geographic regions: Americas, which includes the United States, Canada, Mexico, Central America and South America; EMEA, which includes Europe, Russia, Middle East and Africa; and APAC, which includes Asia Pacific, China, South Asia and Japan. The following table sets forth the Company’s revenues disaggregated by sales channel and geographic region based on the billing addresses of its customers (in thousands):

- removed (2022-10-28):
[0001564590-22-016543:note_history:34]
|  |  | Nine Months Ended |  |
|  |  | March 31, 2022 |  |  | March 31, 2021 |  |
|  |  | Distributor |  | Direct |  | Total |  |  | Distributor |  | Direct |  | Total |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  | $ | 184,215 |  | $ | 196,768 |  | $ | 380,983 |  |  | $ | 162,049 |  | $ | 178,263 |  | $ | 340,312 |  |
| Other |  |  | 19,238 |  |  | 11,835 |  |  | 31,073 |  |  |  | 26,117 |  |  | 11,468 |  |  | 37,585 |  |
| Total Americas |  |  | 203,453 |  |  | 208,603 |  |  | 412,056 |  |  |  | 188,166 |  |  | 189,731 |  |  | 377,897 |  |
| EMEA |  |  | 248,812 |  |  | 114,703 |  |  | 363,515 |  |  |  | 182,341 |  |  | 101,923 |  |  | 284,264 |  |
| APAC |  |  | 9,409 |  |  | 49,145 |  |  | 58,554 |  |  |  | 11,413 |  |  | 57,756 |  |  | 69,169 |  |
| Total net revenues |  | $ | 461,674 |  | $ | 372,451 |  | $ | 834,125 |  |  | $ | 381,920 |  | $ | 349,410 |  | $ | 731,330 |  |

- removed (2022-10-28):
[0001564590-22-016543:note_history:35]
For the three months ended March 31, 2022 and 2021, the Company generated 18% and 11% of its revenues from the Netherlands. For the nine months ended March 31, 2022 and 2021, the Company generated 12% and 10% of its revenues from the Netherlands. No other foreign country accounted for 10% or more of revenue for the three and nine months ended March 31, 2022 or 2021.


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- added (2022-10-28):
[0001564590-22-035673:note_history:36]
On September 30, 2022, the Company had $424.0 million of remaining performance obligations, which are primarily comprised of deferred maintenance and SaaS revenues. The Company expects to recognize approximately 49% of its deferred revenue as revenue in fiscal 2023, an additional 27% in fiscal 2024 and 24% of the balance thereafter.

- changed (2022-10-28):
[0001564590-22-035673:note_history:37]
Revenue recognized for the three months ended September 30, 2022 and 2021 that was included in the deferred revenue balance at the beginning of each period was $80.0 million and $73.4 million, respectively.
  (was, 2022-04-29, similarity 0.6444):
[0001564590-22-016543:note_history:37]
Revenue recognized for the three months ended March 31, 2022 and 2021 that was included in the deferred revenue balance at the beginning of each period was $77.3 million and $67.9 million, respectively. Revenue recognized for the nine months ended March 31, 2022 and 2021 that was included in the deferred revenue balance at the beginning of each period was $176.1 million and $158.7 million, respectively.

- changed (2022-10-28):
[0001564590-22-035673:note_history:38]
Contract Costs. The Company recognizes the incremental costs of obtaining contracts as an expense when incurred if the amortization period of the assets that the Company otherwise would have recognized is one year or less. Management expects that commission fees paid to sales representatives as a result of obtaining service and subscription contracts and contract renewals are recoverable and therefore the Company’s condensed consolidated balance sheets included capitalized balances in the amount of $16.8 million and $16.3 million at September 30, 2022 and June 30, 2022, respectively. Capitalized commissions are included within other assets in the condensed consolidated balance sheets. Capitalized commission fees are amortized on a straight-line basis over the average period of service contracts of approximately three years, and are included in “Sales and marketing” in the accompanying condensed consolidated statements of operations. Amortization recognized during the three months ended September 30, 2022 and 2021, was $2.1 million and $1.8 million, respectively.
  (was, 2022-04-29, similarity 0.6355):
[0001564590-22-016543:note_history:38]
Contract Costs. The Company recognizes the incremental costs of obtaining contracts as an expense when incurred if the amortization period of the assets that the Company otherwise would have recognized is one year or less.  Management expects that commission fees paid to sales representatives as a result of obtaining service and subscription contracts and contract renewals are recoverable and therefore the Company’s condensed consolidated balance sheets included capitalized balances in the amount of $14.8 million and $13.1 million at March 31, 2022 and June 30, 2021, respectively. Capitalized commission fees are amortized on a straight-line basis over the average period of service contracts of approximately three years, and are included in “Sales and marketing” in the accompanying condensed consolidated statements of operations. Amortization recognized during the three months ended March 31, 2022 and 2021, was $1.9 million and $1.4 million, respectively. Amortization recognized during the nine months ended March 31, 2022 and 2021, was $5.5 million and $3.9 million, respectively.

- changed (2022-10-28):
[0001564590-22-035673:note_history:39]
The Company operates in three geographic regions: Americas, EMEA (“Europe, Middle East and Africa”) and APAC (“Asia Pacific”). The following table sets forth the Company’s revenues disaggregated by sales channel and geographic region based on the billing addresses of its customers (in thousands):
  (was, 2022-04-29, similarity 0.7233):
[0001564590-22-016543:note_history:39]
The Company operates in three geographic regions: Americas, which includes the United States, Canada, Mexico, Central America and South America; EMEA, which includes Europe, Russia, Middle East and Africa; and APAC, which includes Asia Pacific, China, South Asia and Japan. The following table sets forth the Company’s revenues disaggregated by sales channel and geographic region based on the billing addresses of its customers (in thousands):

- changed (2022-10-28):
[0001564590-22-035673:note_history:40]
|  |  | Three Months Ended |  |
|  |  | September 30, 2022 |  |  | September 30, 2021 |  |
|  |  | Distributor |  | Direct |  | Total |  |  | Distributor |  | Direct |  | Total |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  | $ | 73,314 |  | $ | 64,312 |  | $ | 137,626 |  |  | $ | 56,068 |  | $ | 67,331 |  | $ | 123,399 |  |
| Other |  |  | 16,025 |  |  | 4,098 |  |  | 20,123 |  |  |  | 7,799 |  |  | 3,367 |  |  | 11,166 |  |
| Total Americas |  |  | 89,339 |  |  | 68,410 |  |  | 157,749 |  |  |  | 63,867 |  |  | 70,698 |  |  | 134,565 |  |
| EMEA |  |  | 76,256 |  |  | 39,253 |  |  | 115,509 |  |  |  | 77,898 |  |  | 35,731 |  |  | 113,629 |  |
| APAC |  |  | 2,038 |  |  | 22,393 |  |  | 24,431 |  |  |  | 4,335 |  |  | 15,155 |  |  | 19,490 |  |
| Total net revenues |  | $ | 167,633 |  | $ | 130,056 |  | $ | 297,689 |  |  | $ | 146,100 |  | $ | 121,584 |  | $ | 267,684 |  |
  (was, 2022-04-29, similarity 0.9634):
[0001564590-22-016543:note_history:40]
|  |  | Three Months Ended |  |
|  |  | March 31, 2022 |  |  | March 31, 2021 |  |
|  |  | Distributor |  | Direct |  | Total |  |  | Distributor |  | Direct |  | Total |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  | $ | 59,582 |  | $ | 60,852 |  | $ | 120,434 |  |  | $ | 54,873 |  | $ | 62,172 |  | $ | 117,045 |  |
| Other |  |  | 7,574 |  |  | 3,513 |  |  | 11,087 |  |  |  | 8,926 |  |  | 3,730 |  |  | 12,656 |  |
| Total Americas |  |  | 67,156 |  |  | 64,365 |  |  | 131,521 |  |  |  | 63,799 |  |  | 65,902 |  |  | 129,701 |  |
| EMEA |  |  | 101,980 |  |  | 36,844 |  |  | 138,824 |  |  |  | 65,210 |  |  | 34,127 |  |  | 99,337 |  |
| APAC |  |  | 40 |  |  | 15,123 |  |  | 15,163 |  |  |  | 3,569 |  |  | 20,793 |  |  | 24,362 |  |
| Total net revenues |  | $ | 169,176 |  | $ | 116,332 |  | $ | 285,508 |  |  | $ | 132,578 |  | $ | 120,822 |  | $ | 253,400 |  |

- added (2022-10-28):
[0001564590-22-035673:note_history:41]
For three months ended September 30, 2022 no foreign country accounted for 10% or more revenue. For the three months ended September 30, 2021 the Company generated 11% and 10% of its revenues from the Netherlands and Germany, respectively.  No other foreign country accounted for 10% or more of revenue for the three months ended September 30, 2021.

- added (2022-10-28):
[0001564590-22-035673:note_history:42]
|  |  | Three Months Ended |  |
|  |  | September 30, 2022 |  |  | September 30, 2021 |  |
| TD Synnex Corporation |  | 19% |  |  | 22% |  |
| Westcon Group Inc. |  | 15% |  |  | 18% |  |
| Jenne Inc. |  | 13% |  |  | 14% |  |

- added (2022-10-28):
[0001564590-22-035673:note_history:43]
|  |  | September 30, 2022 |  |  | June 30, 2022 |  |
| Jenne Inc. |  | 26% |  |  | 28% |  |
| Scansource Inc. |  | 14% |  |  | * |  |
| TD Synnex Corporation |  | * |  |  | 11% |  |
| * Less than 10% of accounts receivable. |  |  |  |  |  |  |  |  |

- removed (2022-10-28):
[0001564590-22-016543:note_history:44]
On March 31, 2022, the Company had $372.4 million of remaining performance obligations, which are primarily comprised of deferred maintenance and SaaS revenues. The Company expects to recognize approximately 21% of its deferred revenue as revenue in fiscal 2022, an additional 45% in fiscal 2023 and 34% of the balance thereafter.

- removed (2022-10-28):
[0001564590-22-016543:note_history:45]
|  |  | Nine Months Ended |  |
|  |  | March 31, 2022 |  |  | March 31, 2021 |  |
|  |  | Distributor |  | Direct |  | Total |  |  | Distributor |  | Direct |  | Total |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  | $ | 184,215 |  | $ | 196,768 |  | $ | 380,983 |  |  | $ | 162,049 |  | $ | 178,263 |  | $ | 340,312 |  |
| Other |  |  | 19,238 |  |  | 11,835 |  |  | 31,073 |  |  |  | 26,117 |  |  | 11,468 |  |  | 37,585 |  |
| Total Americas |  |  | 203,453 |  |  | 208,603 |  |  | 412,056 |  |  |  | 188,166 |  |  | 189,731 |  |  | 377,897 |  |
| EMEA |  |  | 248,812 |  |  | 114,703 |  |  | 363,515 |  |  |  | 182,341 |  |  | 101,923 |  |  | 284,264 |  |
| APAC |  |  | 9,409 |  |  | 49,145 |  |  | 58,554 |  |  |  | 11,413 |  |  | 57,756 |  |  | 69,169 |  |
| Total net revenues |  | $ | 461,674 |  | $ | 372,451 |  | $ | 834,125 |  |  | $ | 381,920 |  | $ | 349,410 |  | $ | 731,330 |  |

- removed (2022-10-28):
[0001564590-22-016543:note_history:46]
For the three months ended March 31, 2022 and 2021, the Company generated 18% and 11% of its revenues from the Netherlands. For the nine months ended March 31, 2022 and 2021, the Company generated 12% and 10% of its revenues from the Netherlands. No other foreign country accounted for 10% or more of revenue for the three and nine months ended March 31, 2022 or 2021.

- removed (2022-10-28):
[0001564590-22-016543:note_history:47]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | March 31, 2022 |  |  | March 31, 2021 |  |  | March 31, 2022 |  |  | March 31, 2021 |  |
| TD Synnex Corporation |  | 17% |  |  | 15% |  |  | 20% |  |  | 21% |  |
| Jenne Corporation |  | 20% |  |  | 16% |  |  | 17% |  |  | 14% |  |
| Westcon Group Inc. |  | 25% |  |  | 19% |  |  | 18% |  |  | 17% |  |

- removed (2022-10-28):
[0001564590-22-016543:note_history:48]
|  |  | March 31, 2022 |  |  | June 30, 2021 |  |
| TD Synnex Corporation |  | * |  |  | 19% |  |
| Jenne Corporation |  | 23% |  |  | 24% |  |
| Westcon Group Inc. |  | 29% |  |  | * |  |
| * Less than 10% of accounts receivable. |  |  |  |  |  |  |  |  |


## us-gaap:RevenueRecognitionPolicyTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- added (2022-10-28):
[0001564590-22-035673:note_history:49]
On September 30, 2022, the Company had $424.0 million of remaining performance obligations, which are primarily comprised of deferred maintenance and SaaS revenues. The Company expects to recognize approximately 49% of its deferred revenue as revenue in fiscal 2023, an additional 27% in fiscal 2024 and 24% of the balance thereafter.

- changed (2022-10-28):
[0001564590-22-035673:note_history:50]
Revenue recognized for the three months ended September 30, 2022 and 2021 that was included in the deferred revenue balance at the beginning of each period was $80.0 million and $73.4 million, respectively.
  (was, 2022-04-29, similarity 0.6444):
[0001564590-22-016543:note_history:50]
Revenue recognized for the three months ended March 31, 2022 and 2021 that was included in the deferred revenue balance at the beginning of each period was $77.3 million and $67.9 million, respectively. Revenue recognized for the nine months ended March 31, 2022 and 2021 that was included in the deferred revenue balance at the beginning of each period was $176.1 million and $158.7 million, respectively.

- changed (2022-10-28):
[0001564590-22-035673:note_history:51]
Contract Costs. The Company recognizes the incremental costs of obtaining contracts as an expense when incurred if the amortization period of the assets that the Company otherwise would have recognized is one year or less. Management expects that commission fees paid to sales representatives as a result of obtaining service and subscription contracts and contract renewals are recoverable and therefore the Company’s condensed consolidated balance sheets included capitalized balances in the amount of $16.8 million and $16.3 million at September 30, 2022 and June 30, 2022, respectively. Capitalized commissions are included within other assets in the condensed consolidated balance sheets. Capitalized commission fees are amortized on a straight-line basis over the average period of service contracts of approximately three years, and are included in “Sales and marketing” in the accompanying condensed consolidated statements of operations. Amortization recognized during the three months ended September 30, 2022 and 2021, was $2.1 million and $1.8 million, respectively.
  (was, 2022-04-29, similarity 0.6355):
[0001564590-22-016543:note_history:51]
Contract Costs. The Company recognizes the incremental costs of obtaining contracts as an expense when incurred if the amortization period of the assets that the Company otherwise would have recognized is one year or less.  Management expects that commission fees paid to sales representatives as a result of obtaining service and subscription contracts and contract renewals are recoverable and therefore the Company’s condensed consolidated balance sheets included capitalized balances in the amount of $14.8 million and $13.1 million at March 31, 2022 and June 30, 2021, respectively. Capitalized commission fees are amortized on a straight-line basis over the average period of service contracts of approximately three years, and are included in “Sales and marketing” in the accompanying condensed consolidated statements of operations. Amortization recognized during the three months ended March 31, 2022 and 2021, was $1.9 million and $1.4 million, respectively. Amortization recognized during the nine months ended March 31, 2022 and 2021, was $5.5 million and $3.9 million, respectively.

- changed (2022-10-28):
[0001564590-22-035673:note_history:52]
The Company operates in three geographic regions: Americas, EMEA (“Europe, Middle East and Africa”) and APAC (“Asia Pacific”). The following table sets forth the Company’s revenues disaggregated by sales channel and geographic region based on the billing addresses of its customers (in thousands):
  (was, 2022-04-29, similarity 0.7233):
[0001564590-22-016543:note_history:52]
The Company operates in three geographic regions: Americas, which includes the United States, Canada, Mexico, Central America and South America; EMEA, which includes Europe, Russia, Middle East and Africa; and APAC, which includes Asia Pacific, China, South Asia and Japan. The following table sets forth the Company’s revenues disaggregated by sales channel and geographic region based on the billing addresses of its customers (in thousands):

- changed (2022-10-28):
[0001564590-22-035673:note_history:53]
|  |  | Three Months Ended |  |
|  |  | September 30, 2022 |  |  | September 30, 2021 |  |
|  |  | Distributor |  | Direct |  | Total |  |  | Distributor |  | Direct |  | Total |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  | $ | 73,314 |  | $ | 64,312 |  | $ | 137,626 |  |  | $ | 56,068 |  | $ | 67,331 |  | $ | 123,399 |  |
| Other |  |  | 16,025 |  |  | 4,098 |  |  | 20,123 |  |  |  | 7,799 |  |  | 3,367 |  |  | 11,166 |  |
| Total Americas |  |  | 89,339 |  |  | 68,410 |  |  | 157,749 |  |  |  | 63,867 |  |  | 70,698 |  |  | 134,565 |  |
| EMEA |  |  | 76,256 |  |  | 39,253 |  |  | 115,509 |  |  |  | 77,898 |  |  | 35,731 |  |  | 113,629 |  |
| APAC |  |  | 2,038 |  |  | 22,393 |  |  | 24,431 |  |  |  | 4,335 |  |  | 15,155 |  |  | 19,490 |  |
| Total net revenues |  | $ | 167,633 |  | $ | 130,056 |  | $ | 297,689 |  |  | $ | 146,100 |  | $ | 121,584 |  | $ | 267,684 |  |
  (was, 2022-04-29, similarity 0.9634):
[0001564590-22-016543:note_history:53]
|  |  | Three Months Ended |  |
|  |  | March 31, 2022 |  |  | March 31, 2021 |  |
|  |  | Distributor |  | Direct |  | Total |  |  | Distributor |  | Direct |  | Total |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  | $ | 59,582 |  | $ | 60,852 |  | $ | 120,434 |  |  | $ | 54,873 |  | $ | 62,172 |  | $ | 117,045 |  |
| Other |  |  | 7,574 |  |  | 3,513 |  |  | 11,087 |  |  |  | 8,926 |  |  | 3,730 |  |  | 12,656 |  |
| Total Americas |  |  | 67,156 |  |  | 64,365 |  |  | 131,521 |  |  |  | 63,799 |  |  | 65,902 |  |  | 129,701 |  |
| EMEA |  |  | 101,980 |  |  | 36,844 |  |  | 138,824 |  |  |  | 65,210 |  |  | 34,127 |  |  | 99,337 |  |
| APAC |  |  | 40 |  |  | 15,123 |  |  | 15,163 |  |  |  | 3,569 |  |  | 20,793 |  |  | 24,362 |  |
| Total net revenues |  | $ | 169,176 |  | $ | 116,332 |  | $ | 285,508 |  |  | $ | 132,578 |  | $ | 120,822 |  | $ | 253,400 |  |

- added (2022-10-28):
[0001564590-22-035673:note_history:54]
For three months ended September 30, 2022 no foreign country accounted for 10% or more revenue. For the three months ended September 30, 2021 the Company generated 11% and 10% of its revenues from the Netherlands and Germany, respectively.  No other foreign country accounted for 10% or more of revenue for the three months ended September 30, 2021.

- removed (2022-10-28):
[0001564590-22-016543:note_history:55]
On March 31, 2022, the Company had $372.4 million of remaining performance obligations, which are primarily comprised of deferred maintenance and SaaS revenues. The Company expects to recognize approximately 21% of its deferred revenue as revenue in fiscal 2022, an additional 45% in fiscal 2023 and 34% of the balance thereafter.

- removed (2022-10-28):
[0001564590-22-016543:note_history:56]
|  |  | Nine Months Ended |  |
|  |  | March 31, 2022 |  |  | March 31, 2021 |  |
|  |  | Distributor |  | Direct |  | Total |  |  | Distributor |  | Direct |  | Total |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  | $ | 184,215 |  | $ | 196,768 |  | $ | 380,983 |  |  | $ | 162,049 |  | $ | 178,263 |  | $ | 340,312 |  |
| Other |  |  | 19,238 |  |  | 11,835 |  |  | 31,073 |  |  |  | 26,117 |  |  | 11,468 |  |  | 37,585 |  |
| Total Americas |  |  | 203,453 |  |  | 208,603 |  |  | 412,056 |  |  |  | 188,166 |  |  | 189,731 |  |  | 377,897 |  |
| EMEA |  |  | 248,812 |  |  | 114,703 |  |  | 363,515 |  |  |  | 182,341 |  |  | 101,923 |  |  | 284,264 |  |
| APAC |  |  | 9,409 |  |  | 49,145 |  |  | 58,554 |  |  |  | 11,413 |  |  | 57,756 |  |  | 69,169 |  |
| Total net revenues |  | $ | 461,674 |  | $ | 372,451 |  | $ | 834,125 |  |  | $ | 381,920 |  | $ | 349,410 |  | $ | 731,330 |  |

- removed (2022-10-28):
[0001564590-22-016543:note_history:57]
For the three months ended March 31, 2022 and 2021, the Company generated 18% and 11% of its revenues from the Netherlands. For the nine months ended March 31, 2022 and 2021, the Company generated 12% and 10% of its revenues from the Netherlands. No other foreign country accounted for 10% or more of revenue for the three and nine months ended March 31, 2022 or 2021.
