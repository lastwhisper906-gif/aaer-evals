# EXTR MD&A — 0001564590-22-035673


## mdna

[0001564590-22-035673:mdna:1]
[same as prior period, unchanged from 0001564590-22-016543:mdna:1]

[0001564590-22-035673:mdna:2]
[same as prior period, unchanged from 0001564590-22-016543:mdna:2]

[0001564590-22-035673:mdna:3]
The following discussion is based upon our unaudited condensed consolidated financial statements included elsewhere in this Report. In the course of operating our business, we routinely make decisions as to the timing of the payment of invoices, the collection of receivables, the manufacturing and shipment of products, the fulfillment of orders, the purchase of supplies, and the building of inventory and service parts, among other matters. Each of these decisions has some impact on the financial results for any given period. In making these decisions, we consider various factors including contractual obligations, customer satisfaction, competition, internal and external financial targets and expectations, and financial planning objectives. For further information about our critical accounting policies and estimates, see the “Critical Accounting Policies and Estimates” section included in this “Management's Discussion and Analysis of Financial Condition and Results of Operations.”

[0001564590-22-035673:mdna:4]
Extreme Networks, Inc. (“Extreme” or “Company”) is a leading provider of end-to-end, cloud-driven networking solutions and industry leading services and support. Extreme designs, develops, and manufactures wired and wireless network infrastructure equipment as well as a cloud networking solution that delivers unified network management of access points, switches, and routers and leverages machine learning, AIOps and analytics to help customers enabling customers to deliver secure connectivity at the edge of the network, speed cloud deployments and uncover actionable insights that make their job easier and save time – all from within a single platform.

[0001564590-22-035673:mdna:5]
Extreme has been pushing the boundaries of networking technology for a quarter of a century, driven by a higher purpose of helping our customers connect beyond the network. Extreme’s cloud-driven technologies provide flexibility and scalability in deployment, management, and licensing of networks globally. Our global footprint provides service to over 50,000 customers and over 10 million daily end users across the world including some of the world’s leading names in business, hospitality, retail, transportation and logistics, education, government, healthcare, manufacturing and service providers. We derive all our revenues from the sale of our networking equipment, software subscriptions, and related maintenance contracts.

[0001564590-22-035673:mdna:6]
[same as prior period, unchanged from 0001564590-22-016543:mdna:5]

[0001564590-22-035673:mdna:7]
Enterprises are adopting new Information Technology (“IT”) delivery models and applications that require fundamental network alterations and enhancements spanning from the access edge to the data center. With the impact of the global COVID-19 pandemic, we believe IT teams in every industry will need more control and better insights than ever before to ensure secure, distributed connectivity and comprehensive centralized visibility. Machine Learning (“ML”) and Artificial Intelligence (“AI”) technologies have the potential to vastly improve the network experience in the post-pandemic world by collating large data sets to increase accuracy and derive resolutions to improve the operation of the network. When ML and AI are applied with cloud-driven networking and automation, administrators can quickly scale to provide productivity, availability, accessibility, manageability, security, and speed, regardless of the distribution of the network.

[0001564590-22-035673:mdna:8]
We believe that the network has never been more vital and strategic than it is today. As administrators grapple with more data, coming from more places, more connected devices, and more Software-as-a-service (“SaaS”) based applications, the cloud is fundamental to establishing a new normal. Traditional network offerings are not well-suited to fulfill enterprise expectations for rapid delivery of new services, more flexible business models, real-time response, and massive scalability.

[0001564590-22-035673:mdna:9]
As enterprises continue to migrate increasing numbers of applications and services to either private clouds or public clouds offered by third parties and to adopt new IT delivery models and applications, they are required to make fundamental network alterations and enhancements spanning from device access points (“AP”) to the network core. In either case, the network infrastructure must adapt to this new dynamic environment. Intelligence and automation are key if enterprises are to derive maximum benefit from their cloud deployments.

[0001564590-22-035673:mdna:10]
Service providers are investing in network enhancements with platforms and applications that deliver data insights, provide flexibility, and can quickly respond to new user demands and 5G use cases.

[0001564590-22-035673:mdna:11]
We believe Extreme stands to benefit from the use of its technology to manage distributed campus network architecture centrally from the cloud. Extreme has blended a dynamic fabric attach architecture that delivers simplicity for moves and changes at the edge of the network together with corporate-wide role-based policy. This enables customers to migrate to new cloud managed switching and Wi-Fi, agnostic of the existing networking or wireless equipment they already have installed. In the end, we expect these customers to see lower operating and capital expenditures, lower subscription costs, lower overall cost of ownership and more flexibility along with a more resilient network.

[0001564590-22-035673:mdna:12]
We estimate the total addressable market for our Enterprise Networking solutions consisting of cloud networking, wireless local area networks (“WLAN”), data center networking, ethernet switching, campus local area networks (“LAN”), and software-defined wide area network (“SD-WAN”) solutions to be approximately $33 billion and growing at approximately 12% annually over the next three years. This is comprised of $22 billion for campus networking, $4.6 billion for 5G service available market in 5G and data centers, for which Extreme is targeting growing to approximately $50 - $100 million per year over the next three to five years, and a $2.2 billion SD-WAN market. We also participate in the $4 billion networking software market for solutions such as cloud-based network management, network automation, on-premises network management, and other networking related software.

[0001564590-22-035673:mdna:13]
[same as prior period, unchanged from 0001564590-22-016543:mdna:9]

[0001564590-22-035673:mdna:14]
The global COVID-19 pandemic resulted in unprecedented change – from the physical footprint of offices, to supply chain operations, to how we connect. Organizations and workforces extend anywhere and everywhere.  IT leaders are now tasked with ensuring the global, hybrid workforce is functional and successful no matter where they are and ensure people can work wherever they want.

[0001564590-22-035673:mdna:15]
[same as prior period, unchanged from 0001564590-22-016543:mdna:11]

[0001564590-22-035673:mdna:16]
[same as prior period, unchanged from 0001564590-22-016543:mdna:12]

[0001564590-22-035673:mdna:17]
[same as prior period, unchanged from 0001564590-22-016543:mdna:13]

[0001564590-22-035673:mdna:18]
[same as prior period, unchanged from 0001564590-22-016543:mdna:14]

[0001564590-22-035673:mdna:19]
[same as prior period, unchanged from 0001564590-22-016543:mdna:15]

[0001564590-22-035673:mdna:20]
[same as prior period, unchanged from 0001564590-22-016543:mdna:16]

[0001564590-22-035673:mdna:21]
[same as prior period, unchanged from 0001564590-22-016543:mdna:17]

[0001564590-22-035673:mdna:22]
|  | • | Provide a differentiated end-to-end cloud architecture. Cloud networking is estimated to be a $4.1 billion segment of the networking market comprised of cloud managed services and cloud-managed products, which are largely WLAN access points and ethernet switches, growing at a 13% over the next three years, according to data from 650 Group Market Research. Cloud management technology has evolved significantly over the past decade. We believe we deliver a combination of innovation, reliability, and security with the leading end-to-end cloud management platform powered by ML and AI that spans from the IoT edge to the enterprise data center. Key characteristics of our cloud architecture include: |

[0001564590-22-035673:mdna:23]
[same as prior period, unchanged from 0001564590-22-016543:mdna:19]

[0001564590-22-035673:mdna:24]
[same as prior period, unchanged from 0001564590-22-016543:mdna:20]

[0001564590-22-035673:mdna:25]
[same as prior period, unchanged from 0001564590-22-016543:mdna:21]

[0001564590-22-035673:mdna:26]
[same as prior period, unchanged from 0001564590-22-016543:mdna:22]

[0001564590-22-035673:mdna:27]
[same as prior period, unchanged from 0001564590-22-016543:mdna:23]

[0001564590-22-035673:mdna:28]
|  | o | Zero-Trust Security (Information Security Management (“ISO”) 27001,27017, and 27701 Certified). |

[0001564590-22-035673:mdna:29]
|  | • | Offer customers choice: public or private cloud, or on-premises. We leverage the cloud where it makes sense for our customers and provide on-premises solutions where customers need them and also have a solution for those who want to harness the power of both. Our hybrid approach gives our customers options to adapt the technology to their business. At the same time, all of our solutions have visibility, control and strategic information built in, all tightly integrated with a single view across all of the installed products. Our customers can understand what is going on across their network and applications in real time – who, when, and what is connected to the network, which is critical for bring your own device (“BYOD”) and IoT usage. |

[0001564590-22-035673:mdna:30]
[same as prior period, unchanged from 0001564590-22-016543:mdna:26]

[0001564590-22-035673:mdna:31]
[same as prior period, unchanged from 0001564590-22-016543:mdna:27]

[0001564590-22-035673:mdna:32]
[same as prior period, unchanged from 0001564590-22-016543:mdna:28]

[0001564590-22-035673:mdna:33]
[same as prior period, unchanged from 0001564590-22-016543:mdna:29]

[0001564590-22-035673:mdna:34]
[same as prior period, unchanged from 0001564590-22-016543:mdna:30]

[0001564590-22-035673:mdna:35]
[same as prior period, unchanged from 0001564590-22-016543:mdna:31]

[0001564590-22-035673:mdna:36]
|  | o | Universal switches (5720/5520/5420/5320) support fabric or traditional networking with a choice of cloud or on-premises (air-gapped or cloud connected) management. |

[0001564590-22-035673:mdna:37]
|  | o | Universal WiFi 6/6E Aps (300/400, 5000 series) support campus or distributed deployments with a choice of cloud or on-premises (air-gapped or cloud connected) management. |

[0001564590-22-035673:mdna:38]
[same as prior period, unchanged from 0001564590-22-016543:mdna:34]

[0001564590-22-035673:mdna:39]
[same as prior period, unchanged from 0001564590-22-016543:mdna:35]

[0001564590-22-035673:mdna:40]
[same as prior period, unchanged from 0001564590-22-016543:mdna:36]

[0001564590-22-035673:mdna:41]
[same as prior period, unchanged from 0001564590-22-016543:mdna:37]

[0001564590-22-035673:mdna:42]
[same as prior period, unchanged from 0001564590-22-016543:mdna:38]

[0001564590-22-035673:mdna:43]
|  | • | Expand Wi-Fi technology leadership. Wireless is today’s network access method of choice and every business must deal with scale, density and BYOD challenges. The network edge landscape is changing as the explosion of mobile devices increases the demand for mobile, transparent, and always-on wired to wireless edge services. The unified access layer requires distributed intelligent components to ensure that access control and resiliency of business services are available across the entire infrastructure and manageable from a single console. We are at a technology inflection point with the pending migration from Wi-Fi 5 solutions to Wi-Fi 6 (802.11ax), focused on providing more efficient access to the broad |

[0001564590-22-035673:mdna:44]
27

[0001564590-22-035673:mdna:45]
|  |  | array of connected devices. We believe we have the industry’s broadest Wi-Fi 6 wireless portfolio providing intelligence for the wired/wireless edge and enhanced by our cloud architecture with machine learning and AI-driven insights. |

[0001564590-22-035673:mdna:46]
[same as prior period, unchanged from 0001564590-22-016543:mdna:41]

[0001564590-22-035673:mdna:47]
[same as prior period, unchanged from 0001564590-22-016543:mdna:42]

[0001564590-22-035673:mdna:48]
[same as prior period, unchanged from 0001564590-22-016543:mdna:43]

[0001564590-22-035673:mdna:49]
[same as prior period, unchanged from 0001564590-22-016543:mdna:44]

[0001564590-22-035673:mdna:50]
|  | • | Expand our reach with ExtremeCloud SD-WAN. ExtremeCloud SD-WAN is a software-defined wide area networks solution offered as an all-inclusive subscription, which includes hardware, the cloud-based SD-WAN service, support and maintenance, and customer success support. This helps customers reduce total cost of ownership as they deliver quality user experience for applications used in site-to-site and site-to-cloud environments. This solution detects and optimizes applications automatically and can apply performance-based dynamic WAN selection for quality and reliability. Included also are security options such as a built-in zone-based firewall, EdgeSentry (in partnership with Check Point) for cloud-based firewall as a service and other advanced security capabilities, and integration with Secure Web Gateway partners such as Palo Alto Networks, Zscaler, and Symantec. |

[0001564590-22-035673:mdna:51]
[same as prior period, unchanged from 0001564590-22-016543:mdna:47]

[0001564590-22-035673:mdna:52]
During the first quarter of fiscal 2023, we achieved the following results:

[0001564590-22-035673:mdna:53]
|  | • | Net revenues of $297.7 million compared to $267.7 million in the first quarter of fiscal 2022. |

[0001564590-22-035673:mdna:54]
|  | • | Product revenues of $206.3 million compared to $185.2 million in the first quarter of fiscal 2022. |

[0001564590-22-035673:mdna:55]
|  | • | Service and subscription revenues of $91.4 million compared to $82.5 million in the first quarter of fiscal 2022. |

[0001564590-22-035673:mdna:56]
|  | • | Total gross margin of 56.0% of net revenues compared to 58.1% of net revenues in the first quarter of fiscal 2022. |

[0001564590-22-035673:mdna:57]
|  | • | Operating income of $17.4 million compared to $18.4 million in the first quarter of fiscal 2022. |

[0001564590-22-035673:mdna:58]
|  | • | Net income of $12.6 million compared to $12.7 million in the first quarter of fiscal 2022. |

[0001564590-22-035673:mdna:59]
|  | • | Cash flows provided by operating activities of $49.7 million compared to $40.3 million in the three months ended September 30, 2021. |

[0001564590-22-035673:mdna:60]
|  | • | Cash of $198.3 million as of September 30, 2022 compared to $194.5 million as of June 30, 2022. |

[0001564590-22-035673:mdna:61]
28

[0001564590-22-035673:mdna:62]
[same as prior period, unchanged from 0001564590-22-016543:mdna:59]

[0001564590-22-035673:mdna:63]
[same as prior period, unchanged from 0001564590-22-016543:mdna:60]

[0001564590-22-035673:mdna:64]
|  |  | Three Months Ended |  |  |
|  |  | September 30, 2022 |  |  | September 30, 2021 |  |  | $ Change |  |  | % Change |  |  |
| Net revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 206,276 |  |  | $ | 185,161 |  |  | $ | 21,115 |  |  |  | 11.4 | % |  |
| Percentage of net revenues |  |  | 69.3 | % |  |  | 69.2 | % |  |  |  |  |  |  |  |  |  |
| Service and subscription |  |  | 91,413 |  |  |  | 82,523 |  |  |  | 8,890 |  |  |  | 10.8 | % |  |
| Percentage of net revenues |  |  | 30.7 | % |  |  | 30.8 | % |  |  |  |  |  |  |  |  |  |
| Total net revenues |  | $ | 297,689 |  |  | $ | 267,684 |  |  | $ | 30,005 |  |  |  | 11.2 | % |  |

[0001564590-22-035673:mdna:65]
Product revenues increased $21.1 million or 11.4% for the three months ended September 30, 2022, as compared to the corresponding period of fiscal 2022.  The product revenues increase was primarily due to strong demand for our products, partially offset by supply chain constraints which have impacted our ability to fulfill the demand for our products since the global outbreak of COVID-19.

[0001564590-22-035673:mdna:66]
Service and subscription revenues increased $8.9 million or 10.8% for the three months ended September 30, 2022 as compared to the corresponding period in fiscal 2022. The increase in service and subscription revenues was primarily due to the growth in our subscription revenues and partially due to a full quarter of revenue for Ipanema, which we acquired on September 14, 2021.

[0001564590-22-035673:mdna:67]
[same as prior period, unchanged from 0001564590-22-016543:mdna:64]

[0001564590-22-035673:mdna:68]
|  |  | Three Months Ended |  |  |
|  |  | September 30, 2022 |  |  | September 30, 2021 |  |  | $ Change |  |  | % Change |  |  |
| Gross profit: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 106,513 |  |  | $ | 104,217 |  |  | $ | 2,296 |  |  |  | 2.2 | % |  |
| Percentage of product revenues |  |  | 51.6 | % |  |  | 56.3 | % |  |  |  |  |  |  |  |  |  |
| Service and subscription |  |  | 60,195 |  |  |  | 51,386 |  |  |  | 8,809 |  |  |  | 17.1 | % |  |
| Percentage of service and subscription revenues |  |  | 65.8 | % |  |  | 62.3 | % |  |  |  |  |  |  |  |  |  |
| Total gross profit |  | $ | 166,708 |  |  | $ | 155,603 |  |  | $ | 11,105 |  |  |  | 7.1 | % |  |
| Percentage of net revenues |  |  | 56.0 | % |  |  | 58.1 | % |  |  |  |  |  |  |  |  |  |

[0001564590-22-035673:mdna:69]
Product gross profit increased $2.3 million or 2.2% for the three months ended September 30, 2022, as compared to the corresponding period in fiscal 2022. The increase in product gross profit was primarily due to increased product revenues along with lower amortization of intangibles due to certain intangibles being fully amortized, partially offset by higher product costs and higher distribution cost primarily due to higher freight costs due to supply constraints.

[0001564590-22-035673:mdna:70]
Service and subscription gross profit increased $8.8 million or 17.1% for the three months ended September 30, 2022, as compared to the corresponding period in fiscal 2022.    The increases were primarily due to increased service and subscription revenues.

[0001564590-22-035673:mdna:71]
[same as prior period, unchanged from 0001564590-22-016543:mdna:69]

[0001564590-22-035673:mdna:72]
[same as prior period, unchanged from 0001564590-22-016543:mdna:70]

[0001564590-22-035673:mdna:73]
|  |  | Three Months Ended |  |  |
|  |  | September 30, 2022 |  |  | September 30, 2021 |  |  | $ Change |  |  | % Change |  |  |
| Research and development |  | $ | 50,989 |  |  | $ | 47,766 |  |  | $ | 3,223 |  |  |  | 6.7 | % |  |
| Sales and marketing |  |  | 78,382 |  |  |  | 69,527 |  |  |  | 8,855 |  |  |  | 12.7 | % |  |
| General and administrative |  |  | 18,547 |  |  |  | 17,003 |  |  |  | 1,544 |  |  |  | 9.1 | % |  |
| Acquisition and integration costs |  |  | 390 |  |  |  | 1,510 |  |  |  | (1,120 | ) |  |  | (74.2 | )% |  |
| Restructuring and related charges |  |  | 481 |  |  |  | 279 |  |  |  | 202 |  |  |  | 72.4 | % |  |
| Amortization of intangibles |  |  | 523 |  |  |  | 1,154 |  |  |  | (631 | ) |  |  | (54.7 | )% |  |
| Total operating expenses |  | $ | 149,312 |  |  | $ | 137,239 |  |  | $ | 12,073 |  |  |  | 8.8 | % |  |

[0001564590-22-035673:mdna:74]
[same as prior period, unchanged from 0001564590-22-016543:mdna:72]

[0001564590-22-035673:mdna:75]
[same as prior period, unchanged from 0001564590-22-016543:mdna:73]

[0001564590-22-035673:mdna:76]
Research and development expenses increased by $3.2 million or 6.7% for the three months ended September 30, 2022, as compared to the corresponding period in fiscal 2022. The increase in research and development expenses was primarily due to a $1.7 million increase in personnel related costs, a $0.8 million increase in software licenses and engineering project costs, a $0.6 million increase in equipment related and consultant costs, and a $0.3 increase in facility and information technology costs, partially offset by a $0.1 million decrease in other costs.

[0001564590-22-035673:mdna:77]
[same as prior period, unchanged from 0001564590-22-016543:mdna:76]

[0001564590-22-035673:mdna:78]
[same as prior period, unchanged from 0001564590-22-016543:mdna:77]

[0001564590-22-035673:mdna:79]
Sales and marketing expenses increased by $8.9 million or 12.7% for the three months ended September 30, 2022, as compared to the corresponding period in fiscal 2022. The increase in sales and marketing expenses was primarily due to a $4.7 million increase in personnel costs primarily due to higher compensation and benefits costs, a $2.8 million increase in travel costs and a $2.9 million increase in marketing and facilities related costs, partially offset by a $1.4 million decrease in equipment related and marketing expenses.

[0001564590-22-035673:mdna:80]
[same as prior period, unchanged from 0001564590-22-016543:mdna:80]

[0001564590-22-035673:mdna:81]
[same as prior period, unchanged from 0001564590-22-016543:mdna:81]

[0001564590-22-035673:mdna:82]
General and administrative expenses increased by $1.5 million or 9.1% for the three months ended September 30, 2022, as compared to the corresponding period in fiscal 2022. The increase in general and administrative expenses was primarily due to a $1.7 million increase in personnel costs due to higher compensation and benefits cost primarily related to share-based compensation, partially offset by decrease in other costs, primarily legal and professional fees.

[0001564590-22-035673:mdna:83]
[same as prior period, unchanged from 0001564590-22-016543:mdna:84]

[0001564590-22-035673:mdna:84]
During the three months ended September 30, 2022, we incurred acquisition and integration costs of $0.4 million, which consisted primarily of professional fees and certain compensation charges related to the acquisition of Ipanema.

[0001564590-22-035673:mdna:85]
During the three months ended September 30, 2021 we incurred $1.5 million of integration costs which consisted primarily of professional fees for legal advisory services and financial services related to the acquisition of Ipanema.

[0001564590-22-035673:mdna:86]
[same as prior period, unchanged from 0001564590-22-016543:mdna:87]

[0001564590-22-035673:mdna:87]
For the three months ended September 30, 2022 and 2021, we recorded restructuring and related charges of $0.5 million and $0.3 million, respectively, which primarily comprised of facility-related charges related to our previously impaired facilities.

[0001564590-22-035673:mdna:88]
[same as prior period, unchanged from 0001564590-22-016543:mdna:90]

[0001564590-22-035673:mdna:89]
During the three months ended September 30, 2022 and 2021, we recorded $0.5 million and $1.2 million, respectively, of operating expenses for amortization of intangibles. The decrease during the three months ended September 30, 2022 was primarily due to lower amortization related to certain acquired intangibles from previous acquisitions becoming fully amortized.

[0001564590-22-035673:mdna:90]
[same as prior period, unchanged from 0001564590-22-016543:mdna:92]

[0001564590-22-035673:mdna:91]
During the three months ended September 30, 2022 and 2021, we recorded $3.8 million and $3.9 million, respectively, in interest expense. The decrease in interest expense was primarily driven by lower average loan balances offset by rising interest rates on 2019 Credit Agreement.

[0001564590-22-035673:mdna:92]
Other Income, Net

[0001564590-22-035673:mdna:93]
During the three months ended September 30, 2022 and 2021, we recorded other income, net of $0.4 million and $0.2 million, respectively. The changes for the three months ended September 30, 2022 was primarily due to foreign exchange impact from the revaluation of certain assets and liabilities denominated in foreign currencies into U.S. Dollars.

[0001564590-22-035673:mdna:94]
[same as prior period, unchanged from 0001564590-22-016543:mdna:96]

[0001564590-22-035673:mdna:95]
For the three months ended September 30, 2022 and 2021, we recorded an income tax provision of $1.7 million and $2.1 million, respectively.

[0001564590-22-035673:mdna:96]
The income tax provisions for the three months ended September 30, 2022 and 2021 consisted of (1) taxes on the income of our foreign subsidiaries, (2) foreign withholding taxes, (3) state taxes in jurisdictions where we have no remaining state net operating losses and (4) tax expense associated with the establishment of a U.S. deferred tax liability for amortizable goodwill resulting from the acquisition of Enterasys Networks, Inc., the WLAN Business, the Campus Fabric Business and the Data Center Business.

[0001564590-22-035673:mdna:97]
[same as prior period, unchanged from 0001564590-22-016543:mdna:99]

[0001564590-22-035673:mdna:98]
[same as prior period, unchanged from 0001564590-22-016543:mdna:100]

[0001564590-22-035673:mdna:99]
As discussed in Part II, Item 7, “Management’s Discussion and Analysis of Financial Condition and Results of Operations” of our Annual Report on Form 10-K for the year ended June 30, 2022, we consider the following accounting policies to be the most critical in understanding the judgments that are involved in preparing our consolidated financial statements:

[0001564590-22-035673:mdna:100]
[same as prior period, unchanged from 0001564590-22-016543:mdna:102]

[0001564590-22-035673:mdna:101]
[same as prior period, unchanged from 0001564590-22-016543:mdna:103]

[0001564590-22-035673:mdna:102]
[same as prior period, unchanged from 0001564590-22-016543:mdna:104]

[0001564590-22-035673:mdna:103]
[same as prior period, unchanged from 0001564590-22-016543:mdna:105]

[0001564590-22-035673:mdna:104]
[same as prior period, unchanged from 0001564590-22-016543:mdna:106]

[0001564590-22-035673:mdna:105]
|  |  | September 30, 2022 |  |  | June 30, 2022 |  |
| Cash |  | $ | 198,344 |  |  | $ | 194,522 |  |

[0001564590-22-035673:mdna:106]
As of September 30, 2022, our principal sources of liquidity consisted of cash of $198.3 million, accounts receivable, net of $158.7 million, and available borrowings under our five-year 2019 Revolving Facility of $60.2 million. Our principal uses of cash include the purchase of finished goods inventory from our contract manufacturers, payroll and other operating expenses related to the development and marketing of our products, purchases of property and equipment, and repayments of debt and related interest. We believe that our $198.3 million of cash at September 30, 2022, our cash flow from operations, and the availability of borrowings from the 2019 Revolving Facility will be sufficient to fund our planned operations for at least the next 12 months.

[0001564590-22-035673:mdna:107]
On May 18, 2022, our Board of Directors authorized management to repurchase up to $200.0 million shares of our common stock over a three-year period commencing July 1, 2022. A maximum of $25.0 million may be repurchased in any quarter. Purchases may be made from time to time in the open market or pursuant to 10b5-1 plan. The manner, timing and amount of any future purchases will be determined by our management based on their evaluation of market conditions, stock price, Extreme’s ongoing determination that it is the best use of available cash and other factors. The repurchase program does not obligate Extreme to acquire any shares of its common stock, may be suspended or terminated at any time without prior notice and will be subject to regulatory considerations. There were no shares repurchased during the three months ended September 30, 2022.

[0001564590-22-035673:mdna:108]
On August 9, 2019, we entered into the 2019 Credit Agreement. The 2019 Credit Agreement provides for a five-year first lien term loan facility in an aggregate principal amount of $380.0 million and a five-year revolving loan facility in an aggregate principal amount of $75.0 million (“2019 Revolving Facility”). In addition, we may request incremental term loans and/or incremental revolving loan commitments in an aggregate amount not to exceed the sum of $100.0 million plus an unlimited amount that is subject to pro forma compliance with certain financial tests.  On August 9, 2019, we used the proceeds to partially fund the acquisition of Aerohive and for working capital and general corporate purposes.

[0001564590-22-035673:mdna:109]
[same as prior period, unchanged from 0001564590-22-016543:mdna:111]

[0001564590-22-035673:mdna:110]
The 2019 Credit Agreement requires us to maintain certain minimum financial ratios at the end of each fiscal quarter. The 2019 Credit Agreement also includes covenants and restrictions that limit, among other things, our ability to incur additional indebtedness, create liens upon any of our property, merge, consolidate or sell all or substantially all of our assets. The 2019 Credit Agreement also includes customary events of default, which may result in acceleration of the outstanding balance.

[0001564590-22-035673:mdna:111]
Financial covenants under the 2019 Credit Agreement require us to maintain a minimum consolidated fixed charge and consolidated leverage ratio at the end of each fiscal quarter through maturity.  The 2019 Credit Agreement also includes covenants and restrictions that limit, among other things, our ability to incur additional indebtedness, create liens upon any of our property, merge, consolidate or sell all or substantially all of our assets.  The 2019 Credit Agreement also includes customary events of default which may result in acceleration of the outstanding balance.

[0001564590-22-035673:mdna:112]
On April 8, 2020, we entered into the First Amendment to waive certain terms and financial covenants of the 2019 Credit Agreement through July 31, 2020. On May 8, 2020, we entered into a Second Amendment which superseded the First Amendment and provided certain revised terms and financial covenants through March 31, 2021. The Second Amendment required us to maintain certain minimum cash requirement and financial metrics at the end of each fiscal quarter through March 31, 2021  and we were restricted from pursuing certain activities such as incurring additional debt, stock repurchases, making acquisitions or declaring a dividend, until we came into compliance with the original covenants of the 2019 Credit Agreement. On November 3, 2020, we and our lenders entered into a Third Amendment to increase the sublimit for letters of credit to $20.0 million. On December 8, 2020, we and our lenders entered into a Fourth Amendment to waive and amend certain terms and financial covenants within the 2019 Credit Agreement through March 31, 2021.

[0001564590-22-035673:mdna:113]
The Second Amendment provided for us to end the covenant Suspension Period early and revert to the covenants and interest rates per the original terms of the 2019 Credit Agreement dated August 9, 2019 by filing a Suspension Period Early Termination Notice and Covenant Certificate demonstrating compliance. For the twelve-month period ended March 31, 2021, our financial performance was in compliance with the original covenants defined in the 2019 Credit Agreement and as such we filed a Suspension Early Termination Notice and Covenant Certificate with the administration agent subsequent to filing our Quarterly Report on Form 10-Q for the period ended March 31, 2021. During the three months ended September 30, 2022, the Company was in compliance with all the original terms and financial covenants under the 2019 Credit Agreement.

[0001564590-22-035673:mdna:114]
[same as prior period, unchanged from 0001564590-22-016543:mdna:116]

[0001564590-22-035673:mdna:115]
[same as prior period, unchanged from 0001564590-22-016543:mdna:117]

[0001564590-22-035673:mdna:116]
|  |  | Three Months Ended |  |
|  |  | September 30, 2022 |  |  | September 30, 2021 |  |
| Net cash provided by operating activities |  | $ | 49,734 |  |  | $ | 40,254 |  |
| Net cash used in investing activities |  |  | (3,139 | ) |  |  | (72,927 | ) |
| Net cash used in financing activities |  |  | (42,124 | ) |  |  | (22,681 | ) |
| Foreign currency effect on cash |  |  | (649 | ) |  |  | (191 | ) |
| Net increase (decrease) in cash |  | $ | 3,822 |  |  | $ | (55,545 | ) |

[0001564590-22-035673:mdna:117]
[same as prior period, unchanged from 0001564590-22-016543:mdna:120]

[0001564590-22-035673:mdna:118]
Cash flows provided by operations in the three months ended September 30, 2022, were $49.7 million, including our net income of $12.6 million and non-cash expenses of $22.8 million for items such as amortization of intangibles, share-based compensation, depreciation, reduction in carrying amount of right-of-use assets, deferred income taxes, and interest. Other sources of cash for the period included a decrease in accounts payable and increase in deferred revenues. This was partially offset by increases in inventories, prepaid expenses and other current assets and decreases in accounts payable, accrued compensation, operating lease liabilities and other current and long-term liabilities.

[0001564590-22-035673:mdna:119]
Cash flows provided by operations in the three months ended September 30, 2021 were $40.3 million, including our net income of $12.7 million and non-cash expenses of $27.8 million for items such as amortization of intangibles, share-based compensation, depreciation, reduction in carrying amount of right-of-use assets, deferred income taxes and interest. Other sources of cash for the period included decreases in accounts receivables and inventory and increases in accounts payable, deferred revenues and other current and long-term liabilities. This was partially offset by increase in prepaid expenses and other current assets and decreases in accrued compensation and operating lease liabilities.

[0001564590-22-035673:mdna:120]
[same as prior period, unchanged from 0001564590-22-016543:mdna:123]

[0001564590-22-035673:mdna:121]
Cash flows used in investing activities in the three months ended September 30, 2022 were $3.1 million for the purchases of property and equipment.

[0001564590-22-035673:mdna:122]
Cash flows used in investing activities in the three months ended September 30, 2021 were $72.9 million primarily due to the payment of $69.5 million (net of cash acquired) for the acquisition of Ipanema and $3.4 million for the purchases of property and equipment.

[0001564590-22-035673:mdna:123]
[same as prior period, unchanged from 0001564590-22-016543:mdna:126]

[0001564590-22-035673:mdna:124]
Cash flows used in financing activities in the three months ended September 30, 2022 were $42.1 million due primarily to debt repayments of $37.1 million, $1.0 million for deferred payments on acquisitions and $4.0 million for taxes paid on vested and released stock awards net of proceeds from the issuance of shares of our common stock under our Employee Stock Purchase Plan (“ESPP”).

[0001564590-22-035673:mdna:125]
Cash flows used in financing activities in the three months ended September 30, 2021 were $22.7 million due primarily to debt repayments of $16.8 million, payment of contingent consideration of $0.6 million, $1.0 million for deferred payments on acquisitions and $4.4 million for taxes paid on vested and released stock awards net of proceeds from the issuance of shares of our common stock under our ESPP and exercise of stock options.

[0001564590-22-035673:mdna:126]
[same as prior period, unchanged from 0001564590-22-016543:mdna:129]

[0001564590-22-035673:mdna:127]
Foreign currency effect on cash decreased in the three months ended September 30, 2022, primarily due to changes in foreign currency exchange rates between the U.S. Dollar and particularly the Indian Rupee, the UK Pound, and the EURO.

[0001564590-22-035673:mdna:128]
[same as prior period, unchanged from 0001564590-22-016543:mdna:131]

[0001564590-22-035673:mdna:129]
As of September 30, 2022, we had contractual obligations resulting from our debt arrangement, agreements to purchase goods and services in the ordinary course of business and obligations under our operating lease arrangements.

[0001564590-22-035673:mdna:130]
Our debt obligations relate to amounts owed under our 2019 Credit Agreement. As of September 30, 2022, we had $271.5 million of debt outstanding which are payable on quarterly installments through our fiscal year 2025. We are subject to interest rate on our debt obligations and unused commitment fee. See Note 8, Debt, in the Notes to Condensed Consolidated Financial Statements for additional information regarding our debt obligations.

[0001564590-22-035673:mdna:131]
Our unconditional purchase obligations represent the purchase of long lead-time component inventory that our contract manufacturers procure in accordance with our forecast. We expect to honor the inventory purchase commitments within the next 12 months. As of September 30, 2022, we had non-cancelable commitments to purchase $52.4 million of inventory. See Note 9, Commitments and Contingencies, in the Notes to Condensed Consolidated Financial Statements for additional information regarding our purchase obligations.

[0001564590-22-035673:mdna:132]
We have contractual commitments to our suppliers which represent commitments for future services. As of September 30, 2022, we had contractual commitments of $49.7 million that are due through our fiscal year 2027.

[0001564590-22-035673:mdna:133]
We lease facilities under operating lease arrangements at various locations that expire at various dates through our fiscal year 2032. As of September 30, 2022, the value of our obligations under operating leases was $49.8 million.

[0001564590-22-035673:mdna:134]
We have immaterial income tax liabilities related to uncertain tax positions and we are unable to reasonably estimate the timing of the settlement of those liabilities.

[0001564590-22-035673:mdna:135]
We did not have any material commitments for capital expenditures as of September 30, 2022.

[0001564590-22-035673:mdna:136]
[same as prior period, unchanged from 0001564590-22-016543:mdna:145]

[0001564590-22-035673:mdna:137]
We did not have any off-balance sheet arrangements as of September 30, 2022.
