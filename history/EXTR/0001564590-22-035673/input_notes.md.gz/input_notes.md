# EXTR notes — 0001564590-22-035673


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0001564590-22-035673:notes:1]
[same as prior period, unchanged from 0001564590-22-016543:notes:1]

[0001564590-22-035673:notes:2]
Extreme Networks, Inc., together with its subsidiaries (collectively referred to as “Extreme” or the “Company”), is a leader in providing software-driven networking solutions for enterprise customers. The Company conducts its sales and marketing activities on a worldwide basis through distributors, resellers and the Company’s field sales organization. Extreme was incorporated in California in 1996 and reincorporated in Delaware in 1999.

[0001564590-22-035673:notes:3]
The unaudited condensed consolidated financial statements of Extreme included herein have been prepared under the rules and regulations of the Securities and Exchange Commission (“SEC”). Certain information and footnote disclosures normally included in financial statements prepared in accordance with U.S. generally accepted accounting principles have been condensed or omitted under such rules and regulations. The condensed consolidated balance sheets at June 30, 2022 was derived from audited financial statements as of that date but does not include all disclosures required by generally accepted accounting principles for complete financial statements. These interim financial statements and notes should be read in conjunction with the Company’s audited consolidated financial statements and notes thereto included in the Company’s Annual Report on Form 10-K for the fiscal year ended June 30, 2022.

[0001564590-22-035673:notes:4]
The unaudited condensed consolidated financial statements reflect all adjustments, consisting only of normal recurring adjustments that, in the opinion of management, are necessary for a fair presentation of the results of operations and cash flows for the interim periods presented and the financial condition of Extreme at September 30, 2022. The results of operations for the three months ended September 30, 2022 are not necessarily indicative of the results that may be expected for fiscal 2023 or any future periods.

[0001564590-22-035673:notes:5]
[same as prior period, unchanged from 0001564590-22-016543:notes:5]

[0001564590-22-035673:notes:6]
The Company uses a fiscal calendar year ending on June 30. All references herein to “fiscal 2023” or “2023” represent the fiscal year ending June 30, 2023. All references herein to “fiscal 2022” or “2022” represent the fiscal year ended June 30, 2022.

[0001564590-22-035673:notes:7]
[same as prior period, unchanged from 0001564590-22-016543:notes:7]

[0001564590-22-035673:notes:8]
[same as prior period, unchanged from 0001564590-22-016543:notes:8]

[0001564590-22-035673:notes:9]
The Company predominantly uses the United States Dollar as its functional currency. The functional currency for certain of its foreign subsidiaries is the local currency. For those subsidiaries that operate in a local functional currency environment, all assets and liabilities are translated to United States Dollars at current month end rates of exchange and revenues and expenses are translated using the monthly average rate.

[0001564590-22-035673:notes:10]
[same as prior period, unchanged from 0001564590-22-016543:notes:10]

[0001564590-22-035673:notes:11]
[same as prior period, unchanged from 0001564590-22-016543:notes:11]


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001564590-22-035673:notes:12]
[same as prior period, unchanged from 0001564590-22-016543:notes:12]

[0001564590-22-035673:notes:13]
For a description of significant accounting policies, see Note 2, Summary of Significant Accounting Policies, to the consolidated financial statements included in the Company’s Annual Report on Form 10-K for the fiscal year ended June 30, 2022. There have been no material changes to the Company’s significant accounting policies since the filing of the Annual Report on Form 10-K.

[0001564590-22-035673:notes:14]
Recently Adopted and Recently Issued Accounting Pronouncements

[0001564590-22-035673:notes:15]
There were no recently adopted accounting standards which would have a material effect on our condensed consolidated financial statements and accompanying disclosures, and no recently issued accounting standards that are expected to have a material impact on our condensed consolidated financial statements and accompanying disclosures.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001564590-22-035673:notes:16]
[same as prior period, unchanged from 0001564590-22-016543:notes:18]

[0001564590-22-035673:notes:17]
The Company accounts for revenues in accordance with ASU 2014-09, Revenue from Contracts from Customers (Topic 606). The Company derives the majority of its revenues from sales of its networking equipment, with the remaining revenues generated from sales of services and subscriptions, which primarily includes maintenance contracts and software subscriptions delivered as software as a service (“SaaS”) and additional revenues from professional services, and training for its products. The Company sells its products, maintenance contracts and SaaS direct to customers and to partners in two distribution channels, or tiers. The first tier consists of a limited number of independent distributors that stock its products and sell primarily to resellers. The second tier of the distribution channel consists of non-stocking distributors and value-added resellers that sell directly to end-users. Products and services may be sold separately or in bundled packages.

[0001564590-22-035673:notes:18]
[same as prior period, unchanged from 0001564590-22-016543:notes:20]

[0001564590-22-035673:notes:19]
Performance Obligations. A performance obligation is a promise in a contract to transfer a distinct good or service to the customer and is the unit of account in Topic 606. A contract’s transaction price is allocated to each distinct performance obligation and recognized as revenue when, or as, the performance obligation is satisfied. Certain of the Company’s contracts have multiple performance obligations, as the promise to transfer individual goods or services is separately identifiable from other promises in the contracts and, therefore, is distinct. For contracts with multiple performance obligations, the Company allocates the contract’s transaction price to each performance obligation based on its relative standalone selling price. The stand-alone selling prices are determined based on the prices at which the Company separately sells these products. For items that are not sold separately, the Company estimates the stand-alone selling prices using other observable inputs.

[0001564590-22-035673:notes:20]
[same as prior period, unchanged from 0001564590-22-016543:notes:22]

[0001564590-22-035673:notes:21]
On September 30, 2022, the Company had $424.0 million of remaining performance obligations, which are primarily comprised of deferred maintenance and SaaS revenues. The Company expects to recognize approximately 49% of its deferred revenue as revenue in fiscal 2023, an additional 27% in fiscal 2024 and 24% of the balance thereafter.

[0001564590-22-035673:notes:22]
[same as prior period, unchanged from 0001564590-22-016543:notes:24]

[0001564590-22-035673:notes:23]
Revenue recognized for the three months ended September 30, 2022 and 2021 that was included in the deferred revenue balance at the beginning of each period was $80.0 million and $73.4 million, respectively.

[0001564590-22-035673:notes:24]
Contract Costs. The Company recognizes the incremental costs of obtaining contracts as an expense when incurred if the amortization period of the assets that the Company otherwise would have recognized is one year or less. Management expects that commission fees paid to sales representatives as a result of obtaining service and subscription contracts and contract renewals are recoverable and therefore the Company’s condensed consolidated balance sheets included capitalized balances in the amount of $16.8 million and $16.3 million at September 30, 2022 and June 30, 2022, respectively. Capitalized commissions are included within other assets in the condensed consolidated balance sheets. Capitalized commission fees are amortized on a straight-line basis over the average period of service contracts of approximately three years, and are included in “Sales and marketing” in the accompanying condensed consolidated statements of operations. Amortization recognized during the three months ended September 30, 2022 and 2021, was $2.1 million and $1.8 million, respectively.

[0001564590-22-035673:notes:25]
[same as prior period, unchanged from 0001564590-22-016543:notes:27]

[0001564590-22-035673:notes:26]
[same as prior period, unchanged from 0001564590-22-016543:notes:28]

[0001564590-22-035673:notes:27]
The Company operates in three geographic regions: Americas, EMEA (“Europe, Middle East and Africa”) and APAC (“Asia Pacific”). The following table sets forth the Company’s revenues disaggregated by sales channel and geographic region based on the billing addresses of its customers (in thousands):

[0001564590-22-035673:notes:28]
|  |  | Three Months Ended |  |
|  |  | September 30, 2022 |  |  | September 30, 2021 |  |
|  |  | Distributor |  | Direct |  | Total |  |  | Distributor |  | Direct |  | Total |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  | $ | 73,314 |  | $ | 64,312 |  | $ | 137,626 |  |  | $ | 56,068 |  | $ | 67,331 |  | $ | 123,399 |  |
| Other |  |  | 16,025 |  |  | 4,098 |  |  | 20,123 |  |  |  | 7,799 |  |  | 3,367 |  |  | 11,166 |  |
| Total Americas |  |  | 89,339 |  |  | 68,410 |  |  | 157,749 |  |  |  | 63,867 |  |  | 70,698 |  |  | 134,565 |  |
| EMEA |  |  | 76,256 |  |  | 39,253 |  |  | 115,509 |  |  |  | 77,898 |  |  | 35,731 |  |  | 113,629 |  |
| APAC |  |  | 2,038 |  |  | 22,393 |  |  | 24,431 |  |  |  | 4,335 |  |  | 15,155 |  |  | 19,490 |  |
| Total net revenues |  | $ | 167,633 |  | $ | 130,056 |  | $ | 297,689 |  |  | $ | 146,100 |  | $ | 121,584 |  | $ | 267,684 |  |

[0001564590-22-035673:notes:29]
For three months ended September 30, 2022 no foreign country accounted for 10% or more revenue. For the three months ended September 30, 2021 the Company generated 11% and 10% of its revenues from the Netherlands and Germany, respectively.  No other foreign country accounted for 10% or more of revenue for the three months ended September 30, 2021.

[0001564590-22-035673:notes:30]
[same as prior period, unchanged from 0001564590-22-016543:notes:33]

[0001564590-22-035673:notes:31]
[same as prior period, unchanged from 0001564590-22-016543:notes:34]

[0001564590-22-035673:notes:32]
[same as prior period, unchanged from 0001564590-22-016543:notes:35]

[0001564590-22-035673:notes:33]
|  |  | Three Months Ended |  |
|  |  | September 30, 2022 |  |  | September 30, 2021 |  |
| TD Synnex Corporation |  | 19% |  |  | 22% |  |
| Westcon Group Inc. |  | 15% |  |  | 18% |  |
| Jenne Inc. |  | 13% |  |  | 14% |  |

[0001564590-22-035673:notes:34]
[same as prior period, unchanged from 0001564590-22-016543:notes:37]

[0001564590-22-035673:notes:35]
|  |  | September 30, 2022 |  |  | June 30, 2022 |  |
| Jenne Inc. |  | 26% |  |  | 28% |  |
| Scansource Inc. |  | 14% |  |  | * |  |
| TD Synnex Corporation |  | * |  |  | 11% |  |
| * Less than 10% of accounts receivable. |  |  |  |  |  |  |  |  |


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001564590-22-035673:notes:36]
[same as prior period, unchanged from 0001564590-22-016543:notes:39]

[0001564590-22-035673:notes:37]
[same as prior period, unchanged from 0001564590-22-016543:notes:40]

[0001564590-22-035673:notes:38]
[same as prior period, unchanged from 0001564590-22-016543:notes:41]

[0001564590-22-035673:notes:39]
On September 14, 2021 (the “Acquisition Date”), the Company completed its acquisition (the “Acquisition”) of Ipanematech SAS (“Ipanema”), the cloud-native enterprise Software-Defined Wide Area Network (“SD-WAN”) business unit of Infovista pursuant to a Sale and Purchase Agreement. Under the terms of the Acquisition, the net consideration paid by Extreme to Ipanema stockholders was $70.9 million, which was funded from existing cash on hand. The primary reason for the acquisition was to acquire the talent and

[0001564590-22-035673:notes:40]
the technology to allow us to expand our portfolio with new cloud-managed SD-WAN and security offerings to support our enterprise customers.

[0001564590-22-035673:notes:41]
The Acquisition was accounted for using the acquisition method of accounting whereby the acquired assets and liabilities of Ipanema have been recorded at their respective fair values and added to those of the Company including an amount for goodwill calculated as the difference between the acquisition consideration and the fair value of the identifiable net assets. The purchase price has been allocated to tangible and identifiable intangible assets acquired and liabilities assumed. Of the total purchase consideration, $68.9 million was allocated to goodwill, $16.3 million to identifiable intangible assets and the remainder to net tangible liabilities assumed. All valuations were finalized as of June 30, 2022.

[0001564590-22-035673:notes:42]
The unaudited pro forma results of operations reflect the Acquisition as if it had occurred on July 1, 2020, the beginning of fiscal 2021, after giving effect to purchase accounting adjustments relating to depreciation and amortization of intangibles and acquisition and integration costs.

[0001564590-22-035673:notes:43]
[same as prior period, unchanged from 0001564590-22-016543:notes:55]

[0001564590-22-035673:notes:44]
The unaudited pro forma financial information for the three months ended September 30, 2021 combines the historical results for Extreme for that period, which include the results of Ipanema subsequent to the Acquisition Date, and Ipanema’s historical results up to the Acquisition Date.

[0001564590-22-035673:notes:45]
[same as prior period, unchanged from 0001564590-22-016543:notes:57]

[0001564590-22-035673:notes:46]
|  | Three months ended |  |
|  | September 30, 2021* |  |
| Net revenues | $ | 271,305 |  |
| Net income | $ | 14,069 |  |
| Net income per share – basic | $ | 0.11 |  |
| Net income per share – diluted | $ | 0.11 |  |
| Shares used in per share calculation – basic |  | 128,324 |  |
| Shares used in per share calculation – diluted |  | 133,225 |  |

[0001564590-22-035673:notes:47]
*Amount reflects the adoption of ASU 2021-08, Business Combinations (Topic 805): Accounting for Contract Assets and Contract Liabilities from Contracts with Customers, which the Company early adopted the standard in the quarter ended December 31, 2021 and retrospectively applied to the fiscal year beginning July 1, 2021.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001564590-22-035673:notes:48]
[same as prior period, unchanged from 0001564590-22-016543:notes:59]

[0001564590-22-035673:notes:49]
[same as prior period, unchanged from 0001564590-22-016543:notes:60]

[0001564590-22-035673:notes:50]
Inventories are stated at the lower of cost, determined on the first-in, first-out (“FIFO”) basis, or net realizable value. Extreme uses a standard cost methodology to determine the cost basis for its inventories. Cost is computed using standard cost, which approximates actual cost, on a first-in, first-out basis. The Company adjusts the carrying value of its inventory when conditions exist that suggest that inventory may be in excess of anticipated demand or is obsolete based upon assumptions about future demand. At the point of loss recognition, a new, lower-cost basis for that inventory is established, and subsequent changes in facts and circumstances do not result in the restoration or increase in that newly established cost basis. Any previously written down or obsolete inventory subsequently sold has not had a material impact on gross margin for any of the periods presented.

[0001564590-22-035673:notes:51]
[same as prior period, unchanged from 0001564590-22-016543:notes:62]

[0001564590-22-035673:notes:52]
|  |  | September 30, 2022 |  |  | June 30, 2022 |  |
| Finished goods |  | $ | 45,534 |  |  | $ | 40,733 |  |
| Raw materials |  |  | 6,232 |  |  |  | 8,498 |  |
| Total inventories |  | $ | 51,766 |  |  | $ | 49,231 |  |

[0001564590-22-035673:notes:53]
[same as prior period, unchanged from 0001564590-22-016543:notes:64]

[0001564590-22-035673:notes:54]
[same as prior period, unchanged from 0001564590-22-016543:notes:65]

[0001564590-22-035673:notes:55]
|  |  | September 30, 2022 |  |  | June 30, 2022 |  |
| Computers and equipment |  | $ | 76,535 |  |  | $ | 75,387 |  |
| Purchased software |  |  | 48,397 |  |  |  | 47,161 |  |
| Office equipment, furniture and fixtures |  |  | 9,428 |  |  |  | 9,463 |  |
| Leasehold improvements |  |  | 52,460 |  |  |  | 52,564 |  |
| Total property and equipment |  |  | 186,820 |  |  |  | 184,575 |  |
| Less: accumulated depreciation and amortization |  |  | (138,868 | ) |  |  | (134,997 | ) |
| Property and equipment, net |  | $ | 47,952 |  |  | $ | 49,578 |  |

[0001564590-22-035673:notes:56]
[same as prior period, unchanged from 0001564590-22-016543:notes:67]

[0001564590-22-035673:notes:57]
[same as prior period, unchanged from 0001564590-22-016543:notes:68]

[0001564590-22-035673:notes:58]
[same as prior period, unchanged from 0001564590-22-016543:notes:69]

[0001564590-22-035673:notes:59]
The majority of the Company’s hardware products are shipped with either a one-year warranty or a limited lifetime warranty, and software products receive a 90-day warranty. Upon shipment of products to its customers, the Company estimates expenses for the cost to repair or replace products that may be returned under warranty and accrues a liability in cost of product revenues for this amount. The determination of the Company’s warranty requirements is based on actual historical experience with the product or product family, estimates of repair and replacement costs and any product warranty problems that are identified after shipment. The Company estimates and adjusts these accruals at each balance sheet date in accordance with changes in these factors.

[0001564590-22-035673:notes:60]
The following table summarizes the activity related to the Company’s product warranty liability during the three months ended September 30, 2022 and 2021 (in thousands):

[0001564590-22-035673:notes:61]
|  |  | Three Months Ended |  |
|  |  | September 30, 2022 |  |  | September 30, 2021 |  |
| Balance beginning of period |  | $ | 10,852 |  |  | $ | 11,623 |  |
| Warranties assumed due to acquisition |  |  | — |  |  |  | 41 |  |
| New warranties issued |  |  | 4,008 |  |  |  | 2,710 |  |
| Warranty expenditures |  |  | (3,338 | ) |  |  | (3,594 | ) |
| Balance end of period |  | $ | 11,522 |  |  | $ | 10,780 |  |

[0001564590-22-035673:notes:62]
To facilitate sales of its products in the normal course of business, the Company indemnifies its resellers and end-user customers with respect to certain matters. The Company has agreed to hold the customer harmless against losses arising for intellectual property infringement and certain other losses. These agreements may limit the time within which an indemnification claim can be made and the amount of the claim. It is not possible to estimate the maximum potential amount under these indemnification agreements due to the limited history of prior indemnification claims and the unique facts and circumstances involved in each particular agreement. Historically, payments made by the Company under these agreements have not had a material impact on its operating results or financial position.

[0001564590-22-035673:notes:63]
[same as prior period, unchanged from 0001564590-22-016543:notes:74]

[0001564590-22-035673:notes:64]
[same as prior period, unchanged from 0001564590-22-016543:notes:75]


## us-gaap:FairValueDisclosuresTextBlock

[0001564590-22-035673:notes:65]
[same as prior period, unchanged from 0001564590-22-016543:notes:76]

[0001564590-22-035673:notes:66]
[same as prior period, unchanged from 0001564590-22-016543:notes:77]

[0001564590-22-035673:notes:67]
[same as prior period, unchanged from 0001564590-22-016543:notes:78]

[0001564590-22-035673:notes:68]
[same as prior period, unchanged from 0001564590-22-016543:notes:79]

[0001564590-22-035673:notes:69]
[same as prior period, unchanged from 0001564590-22-016543:notes:80]

[0001564590-22-035673:notes:70]
The following table presents the Company’s fair value hierarchy for its financial assets and liabilities measured at fair value on a recurring basis at September 30, 2022 and June 30, 2022 (in thousands).

[0001564590-22-035673:notes:71]
| September 30, 2022 |  | Level 1 |  |  | Level 2 |  |  | Level 3 |  |  | Total |  |
| Assets |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency derivatives |  | $ | — |  |  | $ | 21 |  |  | $ | — |  |  | $ | 21 |  |
| Interest rate swaps |  | $ | — |  |  | $ | 1,338 |  |  | $ | — |  |  | $ | 1,338 |  |
| Total assets measured at fair value |  | $ | — |  |  | $ | 1,359 |  |  | $ | — |  |  | $ | 1,359 |  |

[0001564590-22-035673:notes:72]
| June 30, 2022 |  | Level 1 |  |  | Level 2 |  |  | Level 3 |  |  | Total |  |
| Assets |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest rate swaps |  | $ | — |  |  | $ | 1,314 |  |  | $ | — |  |  | $ | 1,314 |  |
| Total assets measured at fair value |  | $ | — |  |  | $ | 1,314 |  |  | $ | — |  |  | $ | 1,314 |  |
| Liabilities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency derivatives |  | $ | — |  |  | $ | 31 |  |  | $ | — |  |  | $ | 31 |  |
| Total liabilities measured at fair value |  | $ | — |  |  | $ | 31 |  |  | $ | — |  |  | $ | 31 |  |

[0001564590-22-035673:notes:73]
[same as prior period, unchanged from 0001564590-22-016543:notes:84]

[0001564590-22-035673:notes:74]
[same as prior period, unchanged from 0001564590-22-016543:notes:85]

[0001564590-22-035673:notes:75]
As of September 30, 2022 and June 30, 2022, the Company had foreign exchange forward contracts that were not designated as hedging instruments with notional principal amount of $4.2 million and $9.6 million, respectively. These contracts have maturities of 40 days or less. Changes in the fair value of these foreign exchange forward contracts not designated as hedging instruments are included in other income or expense in the condensed consolidated statement of operations. For the three months ended September 30, 2022, and 2021, there were net losses of $0.5 million and  $0.2 million, respectively. As of September 30, 2022 and June 30, 2022 there were no outstanding foreign exchange forward contract that were designated as hedging instruments.

[0001564590-22-035673:notes:76]
The fair values of the interest rate swaps are based upon inputs corroborated by observable market data which is considered Level 2. As of September 30, 2022 and as of June 30, 2022, the Company had interest rate swap contracts, designated as cash flow hedges, with the total notional amount of $75.0 million, respectively. Changes in fair value of these contracts are recorded as a component of accumulated other comprehensive income. As of September 30, 2022 and as of June 30, 2022, these contracts had an unrealized gain of $1.3 million, respectively. See Note 13, Derivatives and Hedging, for additional information.

[0001564590-22-035673:notes:77]
The fair value of the borrowings under the 2019 Credit Agreement (as defined in Note 8) is estimated based on valuations provided by alternative pricing sources supported by observable inputs which is considered Level 2. Since the interest rate is variable for the 2019 Credit Agreement, the fair value approximates the face amount of the Company’s indebtedness of $271.5 million and $308.6 million as of September 30, 2022, and June 30, 2022, respectively.

[0001564590-22-035673:notes:78]
[same as prior period, unchanged from 0001564590-22-016543:notes:89]

[0001564590-22-035673:notes:79]
As of September 30, 2022, and June 30, 2022, the Company did not have any asset or liability that were considered level 3.

[0001564590-22-035673:notes:80]
There were no transfers of assets or liabilities between Level 1, Level 2 and Level 3 during the three months ended September 30, 2022 and 2021. There were no impairments recorded for the three months ended September 30, 2022 and 2021.


## us-gaap:IntangibleAssetsDisclosureTextBlock

[0001564590-22-035673:notes:81]
[same as prior period, unchanged from 0001564590-22-016543:notes:93]

[0001564590-22-035673:notes:82]
[same as prior period, unchanged from 0001564590-22-016543:notes:94]

[0001564590-22-035673:notes:83]
|  |  | Weighted Average |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Remaining Amortization |  | Gross Carrying |  |  | Accumulated |  |  | Net Carrying |  |
|  |  | Period |  | Amount |  |  | Amortization |  |  | Amount |  |
| September 30, 2022 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Developed technology |  | 3.4 years |  | $ | 170,600 |  |  | $ | 149,990 |  |  | $ | 20,610 |  |
| Customer relationships |  | 3.7 years |  |  | 64,839 |  |  |  | 57,186 |  |  |  | 7,653 |  |
| Trade names |  | 0 years |  |  | 10,700 |  |  |  | 10,700 |  |  |  | - |  |
| License agreements |  | 4.2 years |  |  | 2,445 |  |  |  | 2,143 |  |  |  | 302 |  |
| Total intangibles, net |  |  |  | $ | 248,584 |  |  | $ | 220,019 |  |  | $ | 28,565 |  |

[0001564590-22-035673:notes:84]
|  |  | Weighted Average |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Remaining Amortization |  | Gross Carrying |  |  | Accumulated |  |  | Net Carrying |  |
|  |  | Period |  | Amount |  |  | Amortization |  |  | Amount |  |
| June 30, 2022 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Developed technology |  | 3.3 years |  | $ | 170,600 |  |  | $ | 146,560 |  |  | $ | 24,040 |  |
| Customer relationships |  | 3.9 years |  |  | 64,839 |  |  |  | 56,704 |  |  |  | 8,135 |  |
| Trade names |  | 0.1 years |  |  | 10,700 |  |  |  | 10,680 |  |  |  | 20 |  |
| License agreements |  | 4.4 years |  |  | 2,445 |  |  |  | 2,125 |  |  |  | 320 |  |
| Total intangibles, net |  |  |  | $ | 248,584 |  |  | $ | 216,069 |  |  | $ | 32,515 |  |

[0001564590-22-035673:notes:85]
[same as prior period, unchanged from 0001564590-22-016543:notes:97]

[0001564590-22-035673:notes:86]
|  |  | Three Months Ended |  |
|  |  | September 30, 2022 |  |  | September 30, 2021 |  |
| Amortization of intangibles in “Total cost of revenues” |  | $ | 3,605 |  |  | $ | 5,286 |  |
| Amortization of intangibles in "Total operating expenses" |  |  | 523 |  |  |  | 1,154 |  |
| Total amortization expense |  | $ | 4,128 |  |  | $ | 6,440 |  |

[0001564590-22-035673:notes:87]
The amortization expense that is recognized in “Total cost of revenues” is comprised of amortization for most of developed technology and license agreements.

[0001564590-22-035673:notes:88]
The estimated future amortization expense to be recorded for each of the respective future fiscal years is as follows (in thousands):

[0001564590-22-035673:notes:89]
| For the fiscal year ending: |  |  |  |  |
| 2023 (the remainder of fiscal 2023) |  | $ | 11,562 |  |
| 2024 |  |  | 5,571 |  |
| 2025 |  |  | 4,757 |  |
| 2026 |  |  | 3,411 |  |
| 2027 |  |  | 1,528 |  |
| Thereafter |  |  | 1,736 |  |
| Total |  | $ | 28,565 |  |


## us-gaap:DebtDisclosureTextBlock

[0001564590-22-035673:notes:90]
| 8. | Debt |

[0001564590-22-035673:notes:91]
The Company’s debt is comprised of the following (in thousands):

[0001564590-22-035673:notes:92]
|  |  | September 30, 2022 |  |  | June 30, 2022 |  |
| Current portion of long-term debt: |  |  |  |  |  |  |  |  |
| Term Loan |  | $ | 38,000 |  |  | $ | 35,625 |  |
| Less: unamortized debt issuance costs |  |  | (2,236 | ) |  |  | (2,276 | ) |
| Current portion of long-term debt |  | $ | 35,764 |  |  | $ | 33,349 |  |
| Long-term debt, less current portion: |  |  |  |  |  |  |  |  |
| Term Loan |  | $ | 233,500 |  |  | $ | 273,000 |  |
| Less: unamortized debt issuance costs |  |  | (1,860 | ) |  |  | (2,430 | ) |
| Total long-term debt, less current portion |  |  | 231,640 |  |  |  | 270,570 |  |
| Total debt |  | $ | 267,404 |  |  | $ | 303,919 |  |

[0001564590-22-035673:notes:93]
On August 9, 2019, the Company entered into an Amended and Restated Credit Agreement (the “2019 Credit Agreement”), by and among the Company, as borrower, several banks and other financial institutions as Lenders, BMO Harris Bank N.A., as an issuing lender and swingline lender, Silicon Valley Bank, as an Issuing Lender, and Bank of Montreal, as administrative agent and collateral agent for the Lenders.

[0001564590-22-035673:notes:94]
The 2019 Credit Agreement provides for a five-year first lien term loan facility in an aggregate principal amount of $380.0 million and a five-year revolving loan facility in an aggregate principal amount of $75.0 million (the “2019 Revolving Facility”). In addition, the Company may request incremental term loans and/or incremental revolving loan commitments in an aggregate amount not to exceed the sum of $100.0 million, plus an unlimited amount that is subject to pro forma compliance with certain financial tests. On August 9, 2019, the Company used the additional proceeds from the term loan to partially fund the Acquisition and for working capital and general corporate purposes.

[0001564590-22-035673:notes:95]
At the Company’s election, the initial term loan under the 2019 Credit Agreement may be made as either base rate loans or Eurodollar loans. The applicable margin for base rate loans ranges from 0.25% to 2.50% per annum and the applicable margin for Eurodollar loans ranges from 1.25% to 3.50%, in each case based on Extreme’s consolidated leverage ratio. All Eurodollar loans are subject to a Base Rate of 0.00%. In addition, the Company is required to pay a commitment fee of between 0.25% and 0.40% quarterly (currently 0.25%) on the unused portion of the 2019 Revolving Facility, also based on the Company’s consolidated leverage ratio. Principal installments are payable on the new term loan in varying percentages quarterly starting December 31, 2019 and to the extent not previously paid, all outstanding balances are to be paid at maturity. The 2019 Credit Agreement is secured by substantially all of the Company’s assets.

[0001564590-22-035673:notes:96]
The 2019 Credit Agreement requires the Company to maintain certain minimum financial ratios at the end of each fiscal quarter. The 2019 Credit Agreement also includes covenants and restrictions that limit, among other things, the Company’s ability to incur additional indebtedness, create liens upon any of its property, merge, consolidate or sell all or substantially all of its assets. The 2019 Credit Agreement also includes customary events of default which may result in acceleration of the payment of the outstanding balance.

[0001564590-22-035673:notes:97]
On April 8, 2020, the Company entered into an amendment to the 2019 Credit Agreement (the “First Amendment”) to waive certain terms and financial covenants of the 2019 Credit Agreement through July 31, 2020. On May 8, 2020, the Company entered into a second amendment to the 2019 Credit Agreement (the “Second Amendment”), which superseded the First Amendment and provided certain revised terms and financial covenants through March 31, 2021. The Second Amendment required the Company to maintain certain minimum cash requirement and financial metrics at the end of each fiscal quarter through March 31, 2021 and the Company was restricted from pursuing certain activities such as incurring additional debt, stock repurchases, making acquisitions or declaring a dividend, until the Company was in compliance with the original covenants of the 2019 Credit Agreement.

[0001564590-22-035673:notes:98]
On November 3, 2020, the Company and its lenders entered into a Third Amendment to the 2019 Credit Agreement (the “Third Amendment”), to increase the sublimit for letters of credit to $20.0 million. On December 8, 2020, the Company and its lenders entered into a fourth amendment to the 2019 Credit Agreement (the “Fourth Amendment”), to waive and amend certain terms and financial covenants within the 2019 Credit Agreement through March 31, 2021.

[0001564590-22-035673:notes:99]
The Second Amendment provided for the Company to end the covenant Suspension Period early and revert to the covenants and interest rates per the original terms of the 2019 Credit Agreement dated August 9, 2019 by filing a Suspension Period Early Termination Notice and Covenant Certificate demonstrating compliance. For the twelve-month period ended March 31, 2021, the Company’s financial performance was in compliance with the original covenants defined in the 2019 Credit Agreement and, as such,

[0001564590-22-035673:notes:100]
the Company filed a Suspension Early Termination Notice and Covenant Certificate with the administration agent subsequent to filing the Company’s Quarterly Report on Form 10-Q for the period ended March 31, 2021. Returning to compliance, the original terms and financial covenants under the 2019 Credit Agreement dated August 9, 2019 resumed in effect. During the three months ended September 30, 2022, the Company was in compliance with all the terms and financial covenants under the 2019 Credit Agreement.

[0001564590-22-035673:notes:101]
Financing costs incurred in connection with obtaining long-term financing are deferred and amortized over the term of the related indebtedness or credit agreement. Amortization of deferred financing costs included in “Interest expense” in the accompanying condensed consolidated statements of operations were $0.7 million and $0.8 million for the three months ended September 30, 2022 and 2021. The interest rate as of September 30, 2022 was 4.5% and as of September 30, 2021 was 2.4%.

[0001564590-22-035673:notes:102]
As of September 30, 2022, the Company did not have any outstanding balance against its 2019 Revolving Facility’s outstanding balance.  The Company had $60.2 million of availability under the 2019 Revolving Facility as of September 30, 2022. During the three months ended September 30, 2022 and 2021, the Company made an additional payment of $30.0 million and $12.0 million against its term loan facility, respectively.

[0001564590-22-035673:notes:103]
The Company had $14.8 million of outstanding letters of credit as of September 30, 2022.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001564590-22-035673:notes:104]
| 9. | Commitments and Contingencies |

[0001564590-22-035673:notes:105]
Purchase Commitments

[0001564590-22-035673:notes:106]
The Company currently has arrangements with contract manufacturers and suppliers for the manufacture of its products. Those arrangements allow the contract manufacturers to procure long lead-time component inventory based upon a rolling production forecast provided by the Company. The Company is obligated to purchase long lead-time component inventory that its contract manufacturer procures in accordance with the forecast, unless the Company gives notice of order cancellation outside of applicable component lead-times. As of September 30, 2022, the Company had commitments to purchase $52.4 million of inventory.

[0001564590-22-035673:notes:107]
Legal Proceedings

[0001564590-22-035673:notes:108]
The Company may from time to time be party to litigation arising in the course of its business, including, without limitation, allegations relating to commercial transactions, business relationships or intellectual property rights. Such claims, even if not meritorious, could result in the expenditure of significant financial and managerial resources. Litigation in general, and intellectual property in particular, can be expensive and disruptive to normal business operations. Moreover, the results of legal proceedings are difficult to predict.

[0001564590-22-035673:notes:109]
In accordance with applicable accounting guidance, the Company records accruals for certain of its outstanding legal proceedings, investigations or claims when it is probable that a liability will be incurred, and the amount of loss can be reasonably estimated. The Company evaluates, at least on a quarterly basis, developments in legal proceedings, investigations or claims that could affect the amount of any accrual, as well as any developments that would result in a loss contingency to become both probable and reasonably estimable. When a loss contingency is not both probable and reasonably estimable, the Company does not record a loss accrual. However, if the loss (or an additional loss in excess of any prior accrual) is at least reasonably possible and material, then the Company would disclose an estimate of the possible loss or range of loss, if such estimate can be made, or disclose that an estimate cannot be made. The assessment whether a loss is probable or a reasonable possibility, and whether the loss or a range of loss is estimable, involves a series of complex judgments about future events. Even if a loss is reasonably possible, the Company may not be able to estimate a range of possible loss, particularly where (i) the damages sought are substantial or indeterminate, (ii) the proceedings are in the early stages, or (iii) the matters involve novel or unsettled legal theories or a large number of parties. In such cases, there is considerable uncertainty regarding the ultimate resolution of such matters, including the amount of any possible loss, fine or penalty.  However, an adverse resolution of one or more of such matters could have a material adverse effect on the Company's results of operations in a particular quarter or fiscal year.

[0001564590-22-035673:notes:110]
XR Communications, LLC d/b/a Vivato Technologies v. Extreme Networks, Inc.

[0001564590-22-035673:notes:111]
On April 19, 2017, XR Communications, LLC (“XR”) (d/b/a Vivato Technologies) filed a patent infringement lawsuit against the Company in the Central District of California. The operative Second Amended Complaint asserts infringement of certain U.S. Patent based on the Company’s manufacture, use, sale, offer for sale, and/or importation into the United States of certain access points and routers supporting multi-user, multiple-input, multiple-output technology. XR seeks unspecified damages, on-going royalties, pre- and post-judgment interest, and attorneys’ fees. The Court dismissed the case without prejudice on January 4, 2022 and on April 18, 2022, entered final judgment in favor of the Company. XR filed a notice of appeal on May 9, 2022 and a response brief from the Company and other defendants is due on November 2, 2022.

[0001564590-22-035673:notes:112]
Orckit IP, LLC v. Extreme Networks, Inc., Extreme Networks Ireland Ltd., and Extreme Networks GmbH

[0001564590-22-035673:notes:113]
On February 1, 2018, Orckit IP, LLC (“Orckit”) filed a patent infringement lawsuit against the Company and its Irish and German subsidiaries in the District Court in Dusseldorf, Germany. The lawsuit alleges direct and indirect infringement of the German portion of a patent (“EP ‘364”) based on the offer, distribution, use, possession and/or importation into Germany of certain network switches that are equipped with the ExtremeXOS operating system. Orckit is seeking injunctive relief, accounting, and an unspecified declaration of liability for damages and costs of the lawsuit. On January 28, 2020, the Court rendered a decision in the infringement case in favor of the Company. The matter is proceeding through the appellate process.

[0001564590-22-035673:notes:114]
On April 23, 2019, Orckit filed an extension of the patent infringement complaint against the Company and its Irish and German subsidiaries in the District Court in Dusseldorf, Germany. With this extension, Orckit alleges infringement of the German portion of a second patent (“EP ‘077”) based on the offer, distribution, use, possession and/or importation into Germany of certain network switches that the Company no longer sells in Germany. Orckit is seeking injunctive relief, accounting and sales information, and a declaration of liability for damages as well as costs of the lawsuit. On October 13, 2020, the Court issued an infringement decision against the Company and granted Orckit the right to enforce the judgment against the Company, which Orckit has provided notification to the Company that it will enforce the judgment. In the rendering of account, Orckit was informed that the products at issue were in end of sale status prior to the filing of the EP‘077 complaint. The Company has appealed the infringement decision, and the matter is proceeding through the appellate process.

[0001564590-22-035673:notes:115]
The Company filed a nullity action related to the EP ‘364 patent on May 3, 2018, and one related to the EP ‘077 patent on October 31, 2019, both in the Federal Patent Court in Munich. The Federal Patent Court in Munich found the EP ‘364 patent to be valid and the Company has filed an appeal. On October 25, 2022, the Federal Patent Court in Munich issued an opinion partially invalidating the patent.

[0001564590-22-035673:notes:116]
SNMP Research, Inc. and SNMP Research International, Inc. v. Broadcom Inc., Brocade Communications Systems LLC, and Extreme Networks, Inc.

[0001564590-22-035673:notes:117]
On October 26, 2020, SNMP Research, Inc. and SNMP Research International, Inc. (collectively, “SNMP”) filed a lawsuit against the Company in the Eastern District of Tennessee for copyright infringement, alleging that the Company was not properly licensed to use its software.  SNMP is seeking actual damages and profits attributed to the infringement, as well as equitable relief. The Company filed a motion to transfer the case to the Northern District of California. The motion to dismiss was denied in part and denied without prejudice in part. The Company also filed, and was granted, a motion to compel mediation.  The parties have selected a mediator and set a mediation date of January 19, 2023. The trial date set for February 2023 has been rescheduled to January 2024.

[0001564590-22-035673:notes:118]
Mala Technologies Ltd. v. Extreme Networks GmbH, Extreme Networks Ireland Ops Ltd., and Extreme Networks, Inc.

[0001564590-22-035673:notes:119]
On April 15, 2021, Mala Technologies Ltd. (“Mala”) filed a patent infringement lawsuit against the Company and its Irish and German subsidiaries in the District Court in Dusseldorf, Germany.  The lawsuit alleges indirect infringement of the German portion of a patent (“EP ‘498”) based on the offer and sale in Germany of certain network switches equipped with the ExtremeXOS operating system.  Mala is seeking injunctive relief, accounting, and an unspecified declaration of liability for damages and costs of the lawsuit.  A hearing date that had been set for July 14, 2022 has been postponed until November 22, 2022. The Company filed a nullity action related to the EP’498 patent on September 24, 2021 in the German Federal Patent Court.

[0001564590-22-035673:notes:120]
Indemnification Obligations

[0001564590-22-035673:notes:121]
Subject to certain limitations, the Company may be obligated to indemnify its current and former directors, officers and employees. These obligations arise under the terms of its certificate of incorporation, its bylaws, applicable contracts, and applicable law. The obligation to indemnify, where applicable, generally means that the Company is required to pay or reimburse, and in certain circumstances the Company has paid or reimbursed, the individuals’ reasonable legal expenses and possibly damages and other liabilities incurred in connection with certain legal matters. The Company also procures Directors and Officers liability insurance to help cover its defense and/or indemnification costs, although its ability to recover such costs through insurance is uncertain.  While it is not possible to estimate the maximum potential amount that could be owed under these governing documents and agreements due to the Company’s limited history with prior indemnification claims, indemnification (including defense) costs could, in the future, have a material adverse effect on the Company’s consolidated financial position, results of operations and cash flows.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001564590-22-035673:notes:122]
[same as prior period, unchanged from 0001564590-22-016543:notes:134]

[0001564590-22-035673:notes:123]
[same as prior period, unchanged from 0001564590-22-016543:notes:135]

[0001564590-22-035673:notes:124]
[same as prior period, unchanged from 0001564590-22-016543:notes:136]

[0001564590-22-035673:notes:125]
[same as prior period, unchanged from 0001564590-22-016543:notes:137]

[0001564590-22-035673:notes:126]
[same as prior period, unchanged from 0001564590-22-016543:notes:138]

[0001564590-22-035673:notes:127]
The Compensation Committee of the Board unanimously approved an amendment to the Extreme Networks, Inc. Amended and Restated 2013 Equity Incentive Plan (the “2013 Plan”) on September 12, 2022 to increase the maximum number of available shares by 6.5 million shares, which is pending ratification by the stockholders at the Company’s annual meeting of the stockholders to be held on November 17, 2022.

[0001564590-22-035673:notes:128]
[same as prior period, unchanged from 0001564590-22-016543:notes:140]

[0001564590-22-035673:notes:129]
The Compensation Committee of the Board unanimously approved an amendment to the 2014 Employee Stock Purchase Plan (the “ESPP”) on September 9, 2021 to increase the maximum number of shares that will be available for sale thereunder by 7.5 million shares. The amendment was approved by the stockholders of the Company at the annual meeting of stockholders held on November 4, 2021.

[0001564590-22-035673:notes:130]
[same as prior period, unchanged from 0001564590-22-016543:notes:142]

[0001564590-22-035673:notes:131]
On May 18, 2022, the Company announced the Board had authorized management to repurchase up to $200.0 million over a three-year period commencing July 1, 2022. A maximum of $25.0 million may be repurchased in any quarter. Purchases may be made from time to time in the open market or pursuant to a 10b5-1 plan.

[0001564590-22-035673:notes:132]
There were no shares repurchased during the three months ended September 30, 2022 and 2021. As of September 30, 2022, approximately $200.0 million remains available for share repurchases under the program.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001564590-22-035673:notes:133]
[same as prior period, unchanged from 0001564590-22-016543:notes:145]

[0001564590-22-035673:notes:134]
[same as prior period, unchanged from 0001564590-22-016543:notes:146]

[0001564590-22-035673:notes:135]
[same as prior period, unchanged from 0001564590-22-016543:notes:147]

[0001564590-22-035673:notes:136]
|  |  | September 30, 2022 |  |  | June 30, 2022 |  |
| 2013 Equity Incentive Plan shares available for grant |  |  | 3,341 |  |  |  | 11,430 |  |
| Employee stock options and awards outstanding |  |  | 11,210 |  |  |  | 7,616 |  |
| 2014 Employee Stock Purchase Plan |  |  | 9,280 |  |  |  | 9,961 |  |
| Total shares reserved for issuance |  |  | 23,831 |  |  |  | 29,007 |  |

[0001564590-22-035673:notes:137]
[same as prior period, unchanged from 0001564590-22-016543:notes:149]

[0001564590-22-035673:notes:138]
[same as prior period, unchanged from 0001564590-22-016543:notes:150]

[0001564590-22-035673:notes:139]
|  |  | Three Months Ended |  |
|  |  | September 30, 2022 |  |  | September 30, 2021 |  |
| Cost of product revenues |  | $ | 374 |  |  | $ | 310 |  |
| Cost of service and subscription revenues |  |  | 672 |  |  |  | 362 |  |
| Research and development |  |  | 3,090 |  |  |  | 2,458 |  |
| Sales and marketing |  |  | 4,639 |  |  |  | 3,575 |  |
| General and administrative |  |  | 5,014 |  |  |  | 3,739 |  |
| Total share-based compensation expense |  | $ | 13,789 |  |  | $ | 10,444 |  |

[0001564590-22-035673:notes:140]
[same as prior period, unchanged from 0001564590-22-016543:notes:152]

[0001564590-22-035673:notes:141]
The following table summarizes stock option activity for the three months ended September 30, 2022 (in thousands, except per share and contractual term):

[0001564590-22-035673:notes:142]
|  |  | Number of Shares |  |  | Weighted-Average Exercise Price Per Share |  |  | Weighted-Average Remaining Contractual Term (years) |  |  | Aggregate Intrinsic Value |  |
| Options outstanding at June 30, 2022 |  |  | 1,187 |  |  | $ | 6.56 |  |  |  | 3.70 |  |  | $ | 2,801 |  |
| Granted |  |  | — |  |  |  | — |  |  |  |  |  |  |  |  |  |
| Exercised |  |  | — |  |  |  | — |  |  |  |  |  |  |  |  |  |
| Cancelled |  |  | — |  |  |  | — |  |  |  |  |  |  |  |  |  |
| Options outstanding at September 30, 2022 |  |  | 1,187 |  |  | $ | 6.56 |  |  |  | 3.45 |  |  | $ | 7,727 |  |
| Vested and expected to vest at September 30, 2022 |  |  | 1,187 |  |  | $ | 6.56 |  |  |  | 3.45 |  |  | $ | 7,727 |  |
| Exercisable at September 30, 2022 |  |  | 1,028 |  |  | $ | 6.54 |  |  |  | 3.37 |  |  | $ | 6,713 |  |

[0001564590-22-035673:notes:143]
The fair value of each stock option grant under the 2013 Plan is estimated on the date of grant using the Black-Scholes-Merton option valuation model. The expected term of options granted is derived from historical data on employee exercise and post-vesting employment termination behavior. The risk-free rate is based upon the estimated life of the option and the U.S. Treasury yield curve in effect at the time of grant. Expected volatility is based on the historical volatility on the Company’s stock. There were no stock options granted during the three months ended September 30, 2022 and 2021. There were no stock options exercised during the three months ended September 30, 2022.

[0001564590-22-035673:notes:144]
[same as prior period, unchanged from 0001564590-22-016543:notes:156]

[0001564590-22-035673:notes:145]
Stock awards may be granted under the 2013 Plan on terms approved by the Compensation Committee of the Board. Stock awards generally provide for the issuance of restricted stock units (“RSUs”) including performance-condition or market-condition RSUs which vest over a fixed period of time or based upon the satisfaction of certain performance criteria or market conditions. The Company recognizes compensation expense on the awards over the vesting period based on the awards’ fair value as of the date of grant. The Company does not estimate forfeitures, but accounts for them as incurred.

[0001564590-22-035673:notes:146]
The following table summarizes stock award activity for the three months ended September 30, 2022 (in thousands, except grant date fair value):

[0001564590-22-035673:notes:147]
|  |  | Number of Shares |  |  | Weighted- Average Grant Date Fair Value |  |  | Aggregate Fair Value |  |
| Non-vested stock awards outstanding at June 30, 2022 |  |  | 6,429 |  |  | $ | 9.57 |  |  |  |  |  |
| Granted |  |  | 5,845 |  |  |  | 14.38 |  |  |  |  |  |
| Released |  |  | (2,111 | ) |  |  | 8.10 |  |  |  |  |  |
| Cancelled |  |  | (140 | ) |  |  | 11.22 |  |  |  |  |  |
| Non-vested stock awards outstanding at September 30, 2022 |  |  | 10,023 |  |  | $ | 12.66 |  |  | $ | 130,996 |  |
| Stock awards expected to vest at September 30, 2022 |  |  | 10,023 |  |  | $ | 12.66 |  |  | $ | 130,996 |  |

[0001564590-22-035673:notes:148]
The RSU’s granted under the 2013 Plan vest over a period of time, generally one to three years, and are subject to participant's continued service to the Company. The stock awards granted during the three months ended September 30, 2022 included 1.3 million RSUs including the market condition awards discussed below to named executive officers and directors.

[0001564590-22-035673:notes:149]
[same as prior period, unchanged from 0001564590-22-016543:notes:161]

[0001564590-22-035673:notes:150]
During the three months ended September 30, 2022 and 2021, the Compensation Committee of the Board granted 1.0 million and 0.7 million RSUs, respectively, with vesting based on market conditions (“MSU”) to certain of the Company’s executive officers. These MSUs vest based on the Company’s total shareholder return (“TSR”) relative to the TSR of the Russell 2000 Index (“Index”).  The MSU award represents the right to receive a target number of shares of common stock of up to 150% of the original grant. The MSUs vest based on the Company’s TSR relative to the TSR of the Index over performance periods of three years from the grant date, subject to the grantees’ continued service through the certification of performance.

[0001564590-22-035673:notes:151]
[same as prior period, unchanged from 0001564590-22-016543:notes:163]

[0001564590-22-035673:notes:152]
[same as prior period, unchanged from 0001564590-22-016543:notes:164]

[0001564590-22-035673:notes:153]
The grant date fair value of each MSU was determined using the Monte Carlo simulation model. The weighted-average grant-date fair value of the MSUs granted during the three months ended September 30, 2022 was $16.57 per share. The assumptions used in the Monte Carlo simulation included the expected volatility of 67%, risk-free rate of 3.12%, no expected dividend yield, expected term of three years and possible future stock prices over the performance period based on the historical stock and market prices. The Company recognizes the expense related to these MSUs on a graded-vesting method over the estimated term.

[0001564590-22-035673:notes:154]
The weighted-average grant-date fair value of the MSUs granted during the three months ended September 30, 2021 was $12.69 per share. The assumptions used in the Monte Carlo simulation included the expected volatility of 66%, risk-free rate of 0.44%, no expected dividend yield, expected term of three years and possible future stock prices over the performance period based on the historical stock and market prices.

[0001564590-22-035673:notes:155]
The fair value of each share purchase option under the ESPP is estimated on the date of grant using the Black-Scholes-Merton option valuation model with the weighted average assumptions noted in the following table. The expected term of the ESPP represents the term of the offering period of each option. The risk-free rate is based upon the estimated life and on the U.S. Treasury yield curve in effect at the time of grant. Expected volatility is based on the historical volatility on the Company’s stock.

[0001564590-22-035673:notes:156]
There were 0.7 million and 1.0 million shares issued under the ESPP during the three months ended September 30, 2022 and 2021, respectively. The following assumptions were used to determine the grant-date fair values of the ESPP shares during the following periods:

[0001564590-22-035673:notes:157]
|  |  | Employee Stock Purchase Plan |  |
|  |  | Three Months Ended |  |
|  |  | September 30, 2022 |  |  | September 30, 2021 |  |
| Expected life |  | 0.5 years |  |  | 0.5 years |  |
| Risk-free interest rate |  |  | 3.12 | % |  |  | 0.05 | % |
| Volatility |  |  | 60 | % |  |  | 52 | % |
| Dividend yield |  |  | — | % |  |  | — | % |

[0001564590-22-035673:notes:158]
The weighted-average grant-date fair value of shares under the ESPP during the three months ended September 30, 2022 and 2021 was $4.38 and $3.18 per share respectively.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001564590-22-035673:notes:159]
[same as prior period, unchanged from 0001564590-22-016543:notes:171]

[0001564590-22-035673:notes:160]
The Company operates in one segment, the development and marketing of network infrastructure equipment and related software. The Company conducts business globally and is managed geographically. Revenues are attributed to a geographical area based on the billing address of customers. The Company operates in three geographical areas: Americas, EMEA (Europe, Middle East and Africa) and APAC (“Asia Pacific”). The Company’s chief operating decision maker, who is its CEO, reviews financial information presented on a consolidated basis for purposes of allocating resources and evaluating financial performance.

[0001564590-22-035673:notes:161]
[same as prior period, unchanged from 0001564590-22-016543:notes:173]

[0001564590-22-035673:notes:162]
[same as prior period, unchanged from 0001564590-22-016543:notes:174]

[0001564590-22-035673:notes:163]
|  |  | September 30, 2022 |  |  | June 30, 2022 |  |
| Americas |  | $ | 128,508 |  |  | $ | 130,715 |  |
| EMEA |  |  | 34,552 |  |  |  | 36,792 |  |
| APAC |  |  | 12,472 |  |  |  | 11,770 |  |
| Total long-lived assets |  | $ | 175,532 |  |  | $ | 179,277 |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001564590-22-035673:notes:164]
[same as prior period, unchanged from 0001564590-22-016543:notes:176]

[0001564590-22-035673:notes:165]
[same as prior period, unchanged from 0001564590-22-016543:notes:177]

[0001564590-22-035673:notes:166]
The Company is exposed to interest rate risk on its debt. The Company enters into interest rate swap contracts to effectively manage the impact of fluctuations of interest rate changes on its outstanding debt which has a floating interest rate. The Company does not enter into derivative contracts for trading or speculative purposes.

[0001564590-22-035673:notes:167]
At the inception date of the derivative contract, the Company performs an assessment of these contracts and has designated these contracts as cash flow hedges. Interest rate swaps designated as cash flow hedges involve the receipt of variable-rate amounts from a counterparty in exchange for the Company making fixed-rate payments over the life of the agreement without exchange of the underlying notional amount. The Company also formally assesses, both at the hedge’s inception and on an ongoing basis, by performing qualitative and quantitative assessment, whether the derivatives that are used in hedging transactions are highly effective in offsetting changes in cash flow of hedged items. Changes in the fair value of a derivative that is qualified, designated and highly effective as a cash flow hedge are recorded in other comprehensive income (loss). When it is determined that a derivative is not highly effective as a hedge or that it has ceased to be a highly effective hedge, the Company discontinues hedge accounting prospectively. In accordance with ASC 815 “Derivatives and Hedging,” the Company may prospectively discontinue the hedge accounting for an existing hedge if the applicable criteria are no longer met, the derivative instrument expires, is sold, terminated or exercised or if the Company removes the designation of the respective cash flow hedge. In those circumstances, the net gain or loss remains in accumulated other comprehensive income (loss) and is reclassified into earnings in the same period or periods during which the hedged forecasted transaction affects earnings, unless the forecasted transaction is no longer probable in which case the net gain or loss is reclassified into earnings immediately.

[0001564590-22-035673:notes:168]
During fiscal 2020, the Company entered into multiple interest rate swap contracts, designated as cash flow hedges, to hedge the variability of cash flows in interest payments associated with the Company’s various tranches of floating-rate debt. As of September 30, 2022 and September 30, 2021, the total notional amount of these interest rate swaps were $75.0 million and $200.0 million, respectively, and had maturity dates through April 2023. As of September 30, 2022 and September 30, 2021, these contracts had unrealized gains of $1.3 million and unrealized losses of $0.9 million, respectively, and are recorded in “Accumulated other comprehensive income (loss)” with the associated asset in “Prepaid expenses and other current assets” or with the associated liability in “Other accrued liabilities”, respectively in the condensed consolidated balance sheets. Cash flows associated with periodic settlements of interest rate swaps are classified as operating activities in the condensed consolidated statement of cash flows. Realized gains and losses are recognized as they accrue in interest expense. Amounts reported in accumulated other comprehensive income (loss) related to these cash flow hedges are reclassified to interest expense over the life of the swap contracts. The Company estimates that $1.3 million will be reclassified to interest income over the next twelve months. The classification and fair value of these cash flow hedges are discussed in Note 6, Fair Value Measurements.

[0001564590-22-035673:notes:169]
[same as prior period, unchanged from 0001564590-22-016543:notes:181]

[0001564590-22-035673:notes:170]
[same as prior period, unchanged from 0001564590-22-016543:notes:182]

[0001564590-22-035673:notes:171]
[same as prior period, unchanged from 0001564590-22-016543:notes:183]

[0001564590-22-035673:notes:172]
For foreign exchange forward contracts not designated as hedging instruments, the fair value of the Company’s derivatives in a gain position are recorded in “Prepaid expenses and other current assets” and derivatives in a loss position are recorded in “Other accrued liabilities” in the accompanying condensed consolidated balance sheets. Changes in the fair value of derivatives are recorded in “Other income (expense), net” in the accompanying condensed consolidated statements of operations. As of September 30, 2022 and 2021, foreign exchange forward contracts not designated as hedging instruments had a total notional principal amount of $4.2 million and $22.6 million, respectively. These contracts have maturities of 40 days or less. The net gains and losses recorded in the  condensed consolidated statement of operations from these contracts during the three months ended September 30, 2022 and 2021 were net losses of $0.5 million and $0.2 million, respectively.  Changes in the fair value of these foreign exchange forward contracts are offset largely by remeasurement of the underlying assets and liabilities.

[0001564590-22-035673:notes:173]
For foreign exchange forward contracts designated as hedging instruments, gains and losses arising from these contracts are recorded as a component of “accumulated other comprehensive income (loss)” on the condensed consolidated balance sheets. The hedging gains and losses in “accumulated other comprehensive income (loss)” are subsequently reclassified to expenses, as applicable, in the condensed consolidated statements of operations in the same period in which the underlying transactions affect our earnings. As of September 30, 2022, there were no foreign exchange forward contracts designated as hedging instruments. As of September 30, 2021, the Company had foreign exchange forward contracts that were designated as hedging instruments with a notional principal amount of $11.3 million and had maturities of less than twelve months. Gains and losses arising from these contracts designated as hedging instruments are recorded as a component of “accumulated other comprehensive income (loss)”. As of September 30, 2021 these contracts had unrealized losses of $0.4 million.

[0001564590-22-035673:notes:174]
The Company recognized total foreign currency gains of $0.9 million and $0.3 million for the three months ended September 30, 2022 and 2021, respectively, related to the change in fair value of foreign currency denominated assets and liabilities.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001564590-22-035673:notes:175]
[same as prior period, unchanged from 0001564590-22-016543:notes:187]

[0001564590-22-035673:notes:176]
The Company recorded $0.5 million of restructuring and related charges during the three months ended September 30, 2022, which included additional facilities charges related to previously impaired facilities.   As of June 30, 2022, the Company has completed all the restructuring activities under the 2020 Plan noted below and no restructuring liabilities remain in the accompanying condensed consolidated balance sheets.

[0001564590-22-035673:notes:177]
The Company recorded $0.3 million of restructuring and related charges during the three months ended September 30, 2021 which primarily included additional facility related expenses related to previously impaired facilities. The Company had minimal activity related to the 2020 Plan during the three months ended September 30, 2021. Severance and benefit restructuring charges consisted primarily of employee severance and benefit expenses incurred under the reduction-in-force action initiated in the third quarter of fiscal 2020 (the “2020 Plan”) to reduce operating costs and enhance financial flexibility as a result of disruptions caused by the COVID-19 global pandemic. With the reduction and realignment of the headcount under the 2020 Plan, the Company relocated certain of its lab test equipment to third-party consulting companies. The Company incurred $9.6 million of charges under the 2020 Plan through June 30, 2022.

[0001564590-22-035673:notes:178]
Restructuring liabilities related to severance, benefits, and equipment relocation obligations are recorded in “Other accrued liabilities” in the accompanying condensed consolidated balance sheets. As of September 30, 2021, the restructuring liability was less than $0.1 million.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001564590-22-035673:notes:179]
[same as prior period, unchanged from 0001564590-22-016543:notes:192]

[0001564590-22-035673:notes:180]
For the three months ended September 30, 2022 and 2021, the Company recorded an income tax provision of $1.7 million and $2.1 million, respectively.

[0001564590-22-035673:notes:181]
The income tax provisions for the three months ended September 30, 2022 and 2021, consisted of (1) taxes on the income of the Company’s foreign subsidiaries, (2) foreign withholding taxes, (3) state taxes in jurisdictions where the Company has no remaining state net operating losses (“NOLs”) and (4) tax expense associated with the establishment of a U.S. deferred tax liability for amortizable goodwill resulting from the acquisition of Enterasys Networks, Inc., the wireless local area network business from Zebra Technologies Corporation, the Campus Fabric Business from Avaya and the Data Center Business from Brocade. The interim income tax provisions for the three months ended September 30, 2022 and 2021 were calculated using the discrete effective tax rate method as allowed by ASC 740-270-30-18, “Income Taxes – Interim Reporting.”  The discrete method is applied when the application of the estimated annual effective tax rate is impractical because it is not possible to reliably estimate the annual effective tax rate. The

[0001564590-22-035673:notes:182]
discrete method treats the year-to-date period as if it was the annual period and determines the income tax expense or benefit on that basis.  The Company believes that, at this time, the use of this discrete method is more appropriate than the annual effective tax rate method as (i) the estimated annual effective tax rate method is not reliable due to the high degree of uncertainty in estimating annual pretax earnings on a jurisdictional basis and (ii) the Company’s ongoing assessment that the recoverability of certain U.S. and Irish deferred tax assets is not more likely than not.

[0001564590-22-035673:notes:183]
The Company has provided a full valuation allowance against all of its U.S. federal and state deferred tax assets as well as a portion of the deferred tax assets in Ireland. Significant judgement is required in determining any valuation allowance recorded against deferred tax assets. In assessing the need for a valuation allowance, we consider all available positive and negative evidence to determine whether it is “more likely than not” that deferred tax assets are recoverable including past operating results, estimates of future taxable income, changes to enacted tax laws, and the feasibility of tax planning strategies; such assessment is required on a jurisdiction-by-jurisdiction basis. The Company’s inconsistent earnings in recent periods, including a cumulative loss over the last three years, coupled with its difficulty in forecasting future revenue trends by jurisdiction and the cyclical nature of its business represent sufficient negative evidence to require full valuation allowances against its U.S. federal and state net deferred tax assets as well as a portion of the deferred tax assets in Ireland.  These valuation allowances will be evaluated periodically and can be reversed partially or in whole if business results and the economic environment have sufficiently improved to support realization of some or all of the Company's deferred tax assets. In the event we change our determination as to the amount of deferred tax assets that can be realized, we will adjust our valuation allowance with a corresponding impact to the provision for income taxes in the period in which such determination is made.

[0001564590-22-035673:notes:184]
[same as prior period, unchanged from 0001564590-22-016543:notes:196]

[0001564590-22-035673:notes:185]
The Company had $18.4 million of unrecognized tax benefits as of September 30, 2022. If fully recognized in the future, $0.3 million would impact the effective tax rate and $18.1 million would result in adjustments to deferred tax assets and corresponding adjustments to the valuation allowance with no impact to the effective tax rate.  The Company does not anticipate any events to occur during the next twelve months that would materially reduce the unrealized tax benefit as currently stated in the Company’s condensed consolidated balance sheets.

[0001564590-22-035673:notes:186]
[same as prior period, unchanged from 0001564590-22-016543:notes:199]

[0001564590-22-035673:notes:187]
In general, the Company’s U.S. federal income tax returns are subject to examination by tax authorities for fiscal years 2001 forward due to NOLs and the Company’s state income tax returns are subject to examination for fiscal years 2000 forward due to NOLs. The Company is not currently under audit for income tax purposes in any material jurisdictions.


## us-gaap:EarningsPerShareTextBlock

[0001564590-22-035673:notes:188]
| 16. | Net Income Per Share |

[0001564590-22-035673:notes:189]
Basic net income per share is calculated by dividing net income by the weighted-average number of shares of common stock outstanding during the period. Diluted income per share is calculated by dividing net income by the weighted-average number of shares of common stock used in the basic net income per share calculation plus the dilutive effect of shares subject to repurchase, options and unvested RSUs.

[0001564590-22-035673:notes:190]
The following table presents the calculation of net income per share of basic and diluted (in thousands, except per share data):

[0001564590-22-035673:notes:191]
|  |  | Three Months Ended |  |
|  |  | September 30, 2022 |  |  | September 30, 2021 |  |
| Net income |  | $ | 12,585 |  |  | $ | 12,696 |  |
| Weighted-average shares used in per share calculation – basic |  |  | 130,289 |  |  |  | 128,324 |  |
| Options to purchase common stock |  |  | 523 |  |  |  | 651 |  |
| Restricted stock units |  |  | 2,121 |  |  |  | 4,250 |  |
| Weighted-average shares used in per share calculation – diluted |  |  | 132,933 |  |  |  | 133,225 |  |
| Net income per share – basic and diluted |  |  |  |  |  |  |  |  |
| Net income per share – basic |  | $ | 0.10 |  |  | $ | 0.10 |  |
| Net income per share – diluted |  | $ | 0.09 |  |  | $ | 0.10 |  |

[0001564590-22-035673:notes:192]
The following securities were excluded from the computation of net income per diluted share of common stock for the periods presented as their effect would have been anti-dilutive (in thousands):

[0001564590-22-035673:notes:193]
|  |  | Three Months Ended |  |
|  |  | September 30, 2022 |  |  | September 30, 2021 |  |
| Options to purchase common stock |  |  | — |  |  |  | — |  |
| Restricted stock units |  |  | 2,343 |  |  |  | 1,441 |  |
| Employee Stock Purchase Plan shares |  |  | 410 |  |  |  | 514 |  |
| Total shares excluded |  |  | 2,753 |  |  |  | 1,955 |  |
