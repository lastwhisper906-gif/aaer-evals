# EXTR 8-K — 0001564590-22-035354 filed 2022-10-27

## item codes, every 8-K on or before 2022-10-28

- 2022-10-27 0001564590-22-035354 — 2.02, 9.01
- 2022-10-12 0001193125-22-261213 — 8.01
- 2022-07-27 0001564590-22-026574 — 2.02, 9.01
- 2022-04-27 0001564590-22-015866 — 2.02, 9.01
- 2022-01-27 0001564590-22-002568 — 2.02, 9.01
- 2021-11-05 0001564590-21-054934 — 5.07
- 2021-11-02 0001564590-21-053306 — 2.02, 9.01
- 2021-09-22 0001564590-21-048585 — 4.01, 9.01
- 2021-08-10 0001564590-21-043098 — 1.01
- 2021-07-28 0001564590-21-038470 — 2.02, 9.01
- 2021-05-18 0001564590-21-028693 — 1.01, 3.03, 9.01
- 2021-04-28 0001564590-21-021102 — 2.02, 9.01
- 2021-02-09 0001564590-21-005000 — 2.02, 9.01
- 2021-01-27 0001564590-21-002633 — 2.02, 9.01
- 2020-11-06 0001564590-20-051993 — 5.07
- 2020-10-28 0001564590-20-048160 — 2.02, 9.01
- 2020-10-08 0001564590-20-046117 — 2.02, 9.01
- 2020-09-11 0001564590-20-043260 — 4.01, 9.01
- 2020-08-05 0001564590-20-036431 — 2.02, 9.01
- 2020-06-01 0001564590-20-027850 — 3.03, 9.01
- 2020-05-11 0001564590-20-024216 — 2.02, 9.01
- 2020-04-08 0001564590-20-015927 — 2.02, 8.01, 9.01
- 2020-02-25 0001193125-20-047202 — 8.01, 9.01
- 2020-01-29 0001564590-20-002375 — 2.02, 9.01
- 2020-01-29 0001193125-20-017673 — 5.02, 9.01
- 2019-11-08 0001193125-19-288358 — 5.07
- 2019-10-30 0001564590-19-038508 — 2.02, 9.01
- 2019-10-25 0001564590-19-037908 — 9.01 — amendment of 0001193125-19-217553
- 2019-10-18 0001193125-19-269734 — 7.01, 9.01
- 2019-08-30 0001193125-19-235271 — 5.02 — amendment of 0001193125-19-229280
- 2019-08-26 0001193125-19-229280 — 5.02, 9.01
- 2019-08-09 0001193125-19-217553 — 1.01, 2.01, 2.03, 9.01
- 2019-07-31 0001564590-19-027208 — 2.02, 9.01
- 2019-06-26 0001193125-19-181938 — 1.01, 2.05, 9.01
- 2019-05-01 0001564590-19-014567 — 2.02, 9.01
- 2019-01-29 0001564590-19-001270 — 2.02, 9.01
- 2019-01-25 0001564590-19-001157 — 8.01, 9.01
- 2018-11-20 0001193125-18-331450 — 5.02, 9.01
- 2018-11-15 0001564590-18-029683 — 5.07
- 2018-11-02 0001564590-18-026372 — 2.02, 8.01, 9.01
- 2018-09-19 0001193125-18-276766 — 5.02
- 2018-08-08 0001564590-18-020191 — 2.02, 9.01
- 2018-06-05 0001564590-18-015067 — 3.03, 9.01
- 2018-05-08 0001564590-18-011817 — 2.02, 9.01
- 2018-05-07 0001564590-18-011264 — 1.01, 1.02, 2.03, 9.01
- 2018-02-06 0001564590-18-001403 — 2.02, 2.05, 9.01
- 2018-02-01 0001564590-18-001166 — 5.02
- 2018-01-12 0001564590-18-000462 — 9.01 — amendment of 0001193125-17-323879
- 2017-11-15 0001564590-17-023847 — 5.07
- 2017-11-07 0001564590-17-022235 — 2.02, 9.01
- 2017-11-03 0001193125-17-332828 — 9.01 — amendment of 0001193125-17-323879
- 2017-10-30 0001193125-17-323879 — 1.01, 2.01, 7.01, 9.01
- 2017-10-03 0001193125-17-302411 — 1.01, 9.01
- 2017-10-03 0001193125-17-301597 — 1.01, 1.02, 7.01, 9.01
- 2017-09-29 0001564590-17-019099 — 9.01 — amendment, the index does not say of what
- 2017-08-14 0001564590-17-017659 — 2.02, 9.01
- 2017-08-02 0001564590-17-014950 — 5.02
- 2017-07-18 0001564590-17-013557 — 1.01, 2.01, 2.03, 9.01
- 2017-06-05 0001564590-17-012126 — 3.03, 9.01
- 2017-05-03 0001564590-17-008378 — 2.02, 9.01
- 2017-03-30 0001193125-17-102344 — 1.01, 9.01
- 2017-03-07 0001193125-17-073306 — 1.01, 9.01
- 2017-02-21 0001193125-17-048182 — 5.02
- 2017-02-01 0001564590-17-000835 — 2.02, 9.01
- 2017-01-06 0001564590-17-000138 — 2.05
- 2016-11-21 0001564590-16-029539 — 5.07
- 2016-11-01 0001564590-16-026732 — 2.02, 9.01
- 2016-10-31 0001193125-16-752557 — 1.01, 2.01, 2.03
- 2016-09-15 0001193125-16-711097 — 1.01, 9.01
- 2016-08-03 0001564590-16-022347 — 2.02, 9.01
- 2016-05-19 0001564590-16-019720 — 5.02, 9.01
- 2016-05-09 0001564590-16-018660 — 3.03, 9.01
- 2016-04-27 0001564590-16-016754 — 2.02, 9.01
- 2016-02-24 0001564590-16-013189 — 8.01
- 2016-02-09 0001564590-16-012469 — 8.01
- 2016-01-28 0001564590-16-012054 — 2.02, 9.01
- 2015-11-17 0001078271-15-000136 — 5.07
- 2015-10-29 0001078271-15-000125 — 2.02, 9.01
- 2015-08-31 0001078271-15-000111 — 8.01, 9.01
- 2015-08-11 0001078271-15-000096 — 5.02
- 2015-08-06 0001078271-15-000093 — 2.02, 9.01
- 2015-06-30 0001078271-15-000089 — 1.01, 9.01
- 2015-05-20 0001078271-15-000077 — 2.05, 9.01
- 2015-05-19 0001078271-15-000075 — 3.03, 9.01
- 2015-05-06 0001078271-15-000050 — 2.02, 9.01
- 2015-05-04 0001078271-15-000048 — 5.02, 9.01
- 2015-04-29 0001078271-15-000038 — 5.02, 9.01
- 2015-04-21 0001078271-15-000034 — 5.02, 9.01
- 2015-04-09 0001078271-15-000032 — 2.02, 5.02, 9.01
- 2015-02-18 0001078271-15-000021 — 8.01
- 2015-02-17 0001078271-15-000019 — 5.02
- 2015-01-28 0001078271-15-000004 — 2.02, 9.01
- 2014-12-18 0001078271-14-000081 — 5.02, 9.01
- 2014-12-17 0001078271-14-000079 — 5.02
- 2014-11-20 0001078271-14-000075 — 1.01, 9.01
- 2014-11-17 0001078271-14-000073 — 5.07
- 2014-10-28 0001078271-14-000062 — 2.02, 9.01
- 2014-10-15 0001078271-14-000060 — 2.02, 9.01
- 2014-10-02 0001078271-14-000057 — 5.02, 9.01
- 2014-08-14 0001078271-14-000047 — 2.02, 9.01
- 2014-07-21 0001078271-14-000042 — 2.02, 9.01
- 2014-05-23 0001078271-14-000036 — 5.02, 9.01
- 2014-05-20 0001078271-14-000034 — 3.03, 9.01
- 2014-05-12 0001078271-14-000030 — 5.02
- 2014-05-08 0001078271-14-000022 — 5.02, 9.01
- 2014-05-07 0001078271-14-000018 — 2.02, 9.01 — amendment, the index does not say of what
- 2014-05-06 0001078271-14-000016 — 2.02, 9.01
- 2014-02-20 0001078271-14-000014 — 5.02, 9.01
- 2014-02-18 0001078271-14-000010 — 5.02
- 2014-02-05 0001078271-14-000006 — 2.02, 9.01
- 2014-01-13 0001104659-14-002030 — 9.01 — amendment of 0001078271-13-000058
- 2013-11-25 0001078271-13-000081 — 5.07
- 2013-11-07 0001078271-13-000064 — 5.02, 9.01
- 2013-11-04 0001078271-13-000060 — 2.02, 9.01
- 2013-11-01 0001078271-13-000058 — 1.01, 2.01, 2.03, 8.01, 9.01
- 2013-10-16 0001078271-13-000056 — 8.01, 9.01
- 2013-09-13 0001078271-13-000052 — 1.01, 8.01, 9.01
- 2013-08-23 0001078271-13-000044 — 5.02, 9.01
- 2013-08-02 0001078271-13-000042 — 5.02
- 2013-07-30 0001078271-13-000039 — 2.02, 9.01
- 2013-07-30 0001078271-13-000037 — 5.02, 9.01
- 2013-06-21 0001078271-13-000032 — 8.01
- 2013-05-01 0001078271-13-000018 — 5.02, 9.01
- 2013-04-30 0001078271-13-000015 — 2.02, 9.01
- 2013-03-01 0001078271-13-000010 — 8.01
- 2013-02-19 0001078271-13-000008 — 5.02
- 2013-01-30 0001078271-13-000004 — 2.02, 9.01
- 2013-01-07 0001078271-13-000002 — 1.01, 2.02, 2.03, 2.05, 9.01
- 2012-12-03 0001078271-12-000094 — 5.02, 5.07, 8.01
- 2012-10-31 0001078271-12-000071 — 2.02, 9.01
- 2012-10-19 0001078271-12-000069 — 1.01, 2.03, 9.01
- 2012-10-16 0001078271-12-000067 — 8.01
- 2012-10-01 0001193125-12-411392 — 5.02, 8.01, 9.01
- 2012-09-24 0001193125-12-401798 — 5.02, 9.01
- 2012-09-21 0001193125-12-399896 — 5.02, 9.01
- 2012-09-18 0001193125-12-394379 — 1.01, 5.02, 9.01
- 2012-09-12 0001193125-12-388591 — 8.01
- 2012-08-27 0001078271-12-000057 — 8.01
- 2012-08-03 0001078271-12-000041 — 7.01, 9.01
- 2012-08-01 0001078271-12-000039 — 2.02, 9.01
- 2012-07-25 0001078271-12-000037 — 8.01
- 2012-05-22 0001078271-12-000033 — 5.02, 9.01
- 2012-05-21 0001078271-12-000030 — 8.01
- 2012-05-09 0001078271-12-000028 — 5.02, 9.01
- 2012-05-02 0001078271-12-000023 — 2.02, 9.01
- 2012-04-30 0001078271-12-000020 — 3.03, 5.07, 9.01
- 2012-04-19 0001078271-12-000012 — 2.02, 5.02, 9.01
- 2012-03-12 0001078271-12-000010 — 5.02, 9.01
- 2012-02-24 0001078271-12-000008 — 8.01
- 2012-02-02 0001078271-12-000004 — 2.02, 9.01
- 2012-01-30 0001078271-12-000002 — 1.01
- 2011-12-01 0001078271-11-000104 — 8.01
- 2011-11-08 0001078271-11-000099 — 8.01
- 2011-11-02 0001078271-11-000094 — 2.02, 9.01
- 2011-10-24 0001078271-11-000089 — 8.01, 9.01
- 2011-10-11 0001078271-11-000085 — 8.01
- 2011-09-29 0001078271-11-000082 — 8.01
- 2011-09-15 0001078271-11-000070 — 5.02, 9.01
- 2011-08-11 0001078271-11-000058 — 8.01
- 2011-08-10 0001078271-11-000055 — 5.02
- 2011-08-08 0001078271-11-000045 — 5.02
- 2011-08-01 0001078271-11-000038 — 2.02, 9.01
- 2011-07-14 0001078271-11-000036 — 2.02, 2.05, 9.01
- 2011-07-12 0001078271-11-000034 — 8.01
- 2011-07-01 0001078271-11-000032 — 5.02
- 2011-06-16 0001078271-11-000030 — 8.01
- 2011-05-06 0001078271-11-000027 — 8.01, 9.01
- 2011-05-04 0001078271-11-000025 — 8.01
- 2011-04-28 0001078271-11-000020 — 2.02, 9.01
- 2011-04-27 0001078271-11-000018 — 3.03, 5.02, 5.03, 9.01
- 2011-04-11 0001078271-11-000016 — 2.02
- 2011-03-31 0001078271-11-000014 — 5.02, 5.03
- 2011-03-15 0001193125-11-066049 — 5.02, 9.01
- 2011-03-01 0001193125-11-052048 — 5.02, 9.01
- 2011-02-10 0001078271-11-000012 — 7.01, 9.01
- 2011-01-31 0001078271-11-000005 — 2.02, 5.02, 5.03, 9.01
- 2010-12-23 0001193125-10-287613 — 8.01
- 2010-12-17 0001193125-10-283495 — 5.03, 5.07, 8.01, 9.01
- 2010-11-10 0001193125-10-255861 — 4.01, 9.01
- 2010-11-01 0001193125-10-242706 — 2.02, 9.01
- 2010-10-14 0001193125-10-229518 — 1.01, 9.01
- 2010-10-06 0001193125-10-224863 — 5.02, 8.01
- 2010-09-29 0001193125-10-219705 — 1.01, 8.01
- 2010-09-08 0001193125-10-206782 — 5.02, 8.01, 9.01
- 2010-08-25 0001193125-10-196951 — 8.01
- 2010-08-09 0001193125-10-182573 — 7.01, 8.01, 9.01
- 2010-08-03 0001193125-10-175255 — 5.02, 8.01, 9.01
- 2010-08-02 0001193125-10-173697 — 2.02, 8.01, 9.01
- 2010-07-30 0001193125-10-172214 — 5.02, 8.01, 9.01
- 2010-07-22 0001193125-10-163896 — 8.01, 9.01
- 2010-07-20 0001193125-10-161832 — 5.02
- 2010-07-12 0001193125-10-157291 — 2.02, 9.01
- 2010-07-01 0001193125-10-152746 — 3.03, 9.01
- 2010-05-10 0001193125-10-114669 — 5.02, 9.01
- 2010-04-26 0001193125-10-093310 — 2.02, 9.01
- 2010-03-19 0001193125-10-061679 — 5.02, 9.01
- 2010-02-16 0001193125-10-032335 — 5.02
- 2010-02-01 0001193125-10-018202 — 2.02, 9.01
- 2010-01-29 0001193125-10-017165 — 5.02
- 2010-01-11 0001193125-10-004099 — 8.01
- 2009-10-26 0001193125-09-213846 — 2.02, 9.01 — amendment of 0001193125-09-213780
- 2009-10-26 0001193125-09-213780 — 2.02, 9.01
- 2009-10-23 0001193125-09-212871 — 2.05, 5.02, 8.01, 9.01
- 2009-10-05 0001193125-09-203522 — 2.02, 9.01
- 2009-08-04 0001193125-09-163799 — 5.02, 9.01
- 2009-07-31 0001193125-09-160772 — 5.02, 9.01
- 2009-07-30 0001193125-09-159578 — 2.02, 9.01
- 2009-07-20 0001193125-09-151500 — 5.02, 9.01
- 2009-07-08 0001193125-09-145840 — 5.02, 9.01
- 2009-05-12 0001193125-09-108340 — 5.02, 9.01
- 2009-04-23 0001193125-09-085849 — 2.02, 9.01
- 2009-03-26 0001193125-09-064502 — 2.05
- 2009-01-28 0001193125-09-013182 — 2.02, 9.01
- 2008-11-06 0001193125-08-227572 — 2.02, 9.01
- 2008-11-03 0001193125-08-222501 — 5.02
- 2008-08-11 0001193125-08-173590 — 5.02
- 2008-08-11 0001193125-08-172587 — 8.01, 9.01
- 2008-08-06 0001193125-08-167934 — 2.02, 9.01
- 2008-08-04 0001193125-08-164673 — 5.02, 9.01
- 2008-05-21 0001193125-08-119640 — 7.01, 9.01
- 2008-04-29 0001193125-08-095270 — 2.02, 9.01
- 2008-03-05 0001193125-08-047893 — 8.01
- 2008-02-19 0001193125-08-033702 — 5.02
- 2008-02-05 0001193125-08-019969 — 5.02
- 2008-01-30 0001193125-08-015378 — 2.02, 9.01
- 2007-12-27 0001193125-07-272178 — 5.03, 9.01
- 2007-10-29 0001193125-07-228368 — 2.02, 9.01
- 2007-10-25 0001193125-07-225906 — 5.02, 9.01
- 2007-10-19 0001193125-07-221578 — 5.02
- 2007-09-26 0001193125-07-207348 — 8.01
- 2007-08-07 0001193125-07-172810 — 2.02, 9.01
- 2007-08-06 0001193125-07-172147 — 5.02, 9.01
- 2007-08-06 0001193125-07-172134 — 3.01
- 2007-07-09 0001193125-07-151467 — 3.01, 9.01
- 2007-06-28 0001193125-07-145519 — 2.02, 9.01
- 2007-06-27 0001193125-07-143262 — 2.05, 3.01, 5.02
- 2007-05-18 0001193125-07-118804 — 3.01, 9.01
- 2007-05-02 0001193125-07-099280 — 2.02, 9.01
- 2007-03-29 0001193125-07-068815 — 5.02, 9.01
- 2007-02-22 0001193125-07-037181 — 3.01, 9.01
- 2007-02-08 0001193125-07-024194 — 5.02
- 2007-01-30 0001193125-07-016428 — 2.02, 9.01
- 2007-01-11 0001193125-07-004825 — 4.02, 9.01
- 2006-11-21 0001193125-06-240068 — 5.02, 9.01
- 2006-11-16 0001193125-06-237262 — 3.01, 9.01
- 2006-11-01 0001193125-06-220707 — 2.02, 9.01
- 2006-10-31 0001193125-06-219237 — 1.01, 1.02, 5.02, 5.03, 8.01, 9.01
- 2006-09-28 0001193125-06-198185 — 3.01, 9.01
- 2006-09-15 0001193125-06-191640 — 7.01, 9.01
- 2006-09-05 0001193125-06-185202 — 5.02, 9.01
- 2006-08-08 0001193125-06-165953 — 1.01, 2.02, 5.02, 9.01
- 2006-07-18 0001193125-06-148526 — 1.01
- 2006-07-10 0001193125-06-143989 — 5.02, 9.01
- 2006-05-16 0001193125-06-113698 — 5.02, 9.01
- 2006-05-01 0001193125-06-094919 — 2.02, 9.01
- 2006-04-26 0001193125-06-089397 — 1.01, 9.01
- 2006-04-07 0001193125-06-075723 — 2.02, 9.01
- 2006-02-13 0001193125-06-029073 — 1.01
- 2006-01-31 0001193125-06-016143 — 1.01
- 2006-01-30 0001193125-06-015165 — 2.02, 9.01
- 2005-12-08 0001193125-05-239157 — 1.01, 1.02, 9.01
- 2005-11-01 0001193125-05-213101 — 2.02, 9.01
- 2005-09-29 0001193125-05-193991 — 1.01, 2.02, 9.01 — amendment of 0001193125-05-162807
- 2005-08-09 0001193125-05-162807 — 1.01, 2.02, 9.01
- 2005-07-14 0001193125-05-142162 — 8.01
- 2005-06-28 0001193125-05-133050 — 1.01, 9.01
- 2005-04-18 0001193125-05-077946 — 2.02, 7.01, 9.01
- 2005-04-14 0001193125-05-076665 — 2.02, 7.01, 9.01
- 2005-01-25 0001193125-05-011466 — 2.02, 9.01
- 2004-12-07 0001193125-04-208693 — 3.01
- 2004-10-26 0001193125-04-178370 — 2.02, 9.01
- 2004-10-04 0001193125-04-166289 — 5.02, 9.01
- 2004-07-28 0001193125-04-126135 — 12, 7
- 2004-05-12 0001193125-04-086287 — 12
- 2004-04-21 0001193125-04-066557 — 12, 7
- 2004-01-22 0001193125-04-007359 — 12, 7
- 2003-12-18 0001193125-03-096351 — 5, 7
- 2003-11-04 0001193125-03-072069 — 5, 7
- 2003-10-24 0001193125-03-066551 — 12, 7
- 2003-07-25 0001193125-03-024087 — 7, 9
- 2003-04-11 0001012870-03-001706 — 7, 9
- 2003-04-08 0001021408-03-005743 — 7, 9
- 2003-01-07 0001012870-03-000039 — 5, 7
- 2002-04-29 0001012870-02-002003 — 5, 7
- 2002-02-20 0001012870-02-000792 — 5, 7
- 2001-12-13 0001012870-01-503160 — 5, 7
- 2001-11-30 0001012870-01-503010 — 5, 7
- 2001-11-02 0001012870-01-502580 — 5
- 2001-10-23 0001021408-01-508589 — 5, 7
- 2001-06-07 0001021408-01-501772 — 5, 7 — amendment of 0001021408-01-500975
- 2001-05-15 0001021408-01-501104 — 5 — amendment of 0001021408-01-500975
- 2001-05-14 0001021408-01-500975 — 5, 7
- 2001-04-06 0001012870-01-500065 — 5, 7

## late-filing notifications on or before 2022-10-28

- 2008-05-12 0001193125-08-111540 — NT 10-Q, for the period ended 2008-03-30
- 2007-05-10 0001193125-07-110075 — NT 10-Q, for the period ended 2007-04-01
- 2007-02-09 0001193125-07-025490 — NT 10-Q, for the period ended 2006-12-31
- 2006-11-13 0001193125-06-232090 — NT 10-Q, for the period ended 2006-10-01
- 2006-09-15 0001193125-06-191838 — NT 10-K, for the period ended 2006-07-02

## item 2.02 — earnings release, exhibit 99.1

[0001564590-22-035354:8k_2_02:1]
EX-99.1
2
extr-ex991_6.htm
EX-99.1

[0001564590-22-035354:8k_2_02:2]
extr-ex991_6.htm

[0001564590-22-035354:8k_2_02:3]
Exhibit 99.1

[0001564590-22-035354:8k_2_02:4]
| For more information, contact: |  |  |  |  |  |  |
| Investor Relations |  |  |  | Media Contact |  |
| Stan Kovler |  |  |  | Amy Aylward |
| 919/595-4196 |  |  |  | 603/952-5138 |  |
| Investor_relations@extremenetworks.com |  |  |  | pr@extremenetworks.com |

[0001564590-22-035354:8k_2_02:5]
Extreme Networks Reports First Quarter Fiscal Year 2023 Financial Results

[0001564590-22-035354:8k_2_02:6]
Double-Digit Growth Fueled by Cloud Subscription Results in Record Revenue

[0001564590-22-035354:8k_2_02:7]
Reiterates FY23 Revenue Growth Outlook of 10-15%

[0001564590-22-035354:8k_2_02:8]
Morrisville, NC, October 27, 2022 -- Extreme Networks, Inc. (“Extreme”) (Nasdaq: EXTR) today released financial results for its first fiscal quarter ended September 30, 2022.

[0001564590-22-035354:8k_2_02:9]
Fiscal First Quarter Results:

[0001564590-22-035354:8k_2_02:10]
|  | • | Revenue $297.7 million, up 11% year-over-year, and up 7% quarter-over-quarter |

[0001564590-22-035354:8k_2_02:11]
|  | • | SaaS ARR* $111.0 million, up 41% year-over-year, and up 8% quarter-over-quarter |

[0001564590-22-035354:8k_2_02:12]
|  | • | GAAP diluted EPS $0.09, compared to $0.10 in Q1 last year and $0.04 last quarter |

[0001564590-22-035354:8k_2_02:13]
|  | • | Non-GAAP diluted EPS $0.20, compared to $0.21 in Q1 last year and $0.15 last quarter |

[0001564590-22-035354:8k_2_02:14]
|  | • | GAAP gross margin 56.0% compared to 55.4% in the prior quarter |

[0001564590-22-035354:8k_2_02:15]
|  | • | Non-GAAP gross margin 57.6% compared to 57.0% in the prior quarter |

[0001564590-22-035354:8k_2_02:16]
|  | • | GAAP operating margin 5.8% compared to 3.8% in the prior quarter |

[0001564590-22-035354:8k_2_02:17]
|  | • | Non-GAAP operating margin 12.1% compared to 9.6% in the prior quarter |

[0001564590-22-035354:8k_2_02:18]
|  | • | Net cash provided by operating activities of $49.7 million |

[0001564590-22-035354:8k_2_02:19]
|  | • | Free cash flow of $46.6 million |

[0001564590-22-035354:8k_2_02:20]
“We delivered record quarterly revenue of $297.7 million, and SaaS ARR of $111 million. Our customers view networking as a strategic asset, and they choose Extreme because we are the best choice to drive operational efficiencies and create better outcomes for their end users. This is evidenced by this quarter’s impressive double-digit revenue growth, record revenue, and continued growth of backlog, which now sits at $555 million,” said Ed Meyercord, President and CEO of Extreme.

[0001564590-22-035354:8k_2_02:21]
“Extreme continues to take share in a thriving and competitive market. The flexibility and intelligence of our products like Extreme Fabric, ExtremeCloud IQ, and innovative capabilities such as Digital Twin and AIOps, are gamechangers. We make it simple to deploy and manage networks, which transforms the way our customers drive their businesses. The combination of our

[0001564590-22-035354:8k_2_02:22]
continued revenue growth and record backlog gives us even greater confidence in our long-term growth outlook,” concluded Meyercord.

[0001564590-22-035354:8k_2_02:23]
Extreme’s Chief Financial Officer Remi Thomas, added, “In addition to our strong topline results, both gross and operating margins improved sequentially. Our subscription business revenue grew approximately 40% year-over-year driven by the adoption of our cloud solutions. Given another quarter of strong free cash flow, we retired $37 million of our debt, which will be accretive to earnings.”

[0001564590-22-035354:8k_2_02:24]
“As we look at the remainder of FY23, the continued improvement in the supply chain environment gives us further confidence in our topline growth outlook of 10-15%. We expect to cross the 60% gross margin threshold and achieve an operating margin in the mid-teens in the second half of our fiscal year,” concluded Thomas.

[0001564590-22-035354:8k_2_02:25]
Recent Key Highlights:

[0001564590-22-035354:8k_2_02:26]
|  | • | Extreme introduced the Extreme AP5050: the industry’s first Wi-Fi 6E Outdoor Access Point (AP) optimized for deployment in venues, convention centers, hospital and university campuses and large stadiums, among others. Specifically designed for high-density outdoor environments, the AP5050 improves mobile speed and performance and reduces interference of devices. |

[0001564590-22-035354:8k_2_02:27]
|  | • | For the fifth consecutive year, Extreme was named a Gartner Peer Insights Customers' Choice for Wired and Wireless LAN Access Infrastructure. |

[0001564590-22-035354:8k_2_02:28]
|  | • | Minor League Baseball (MiLB) selected Extreme as an Official Technology Innovation Partner, supporting the testing of new stadium and in-game technologies. As part of the agreement, all of MiLB’s 120 teams will have access to Extreme’s SD-WAN solution, which will enable them to share data easily and securely, including player performance data, game review videos and other proprietary information. |

[0001564590-22-035354:8k_2_02:29]
|  | • | Hana Bank, one of the largest banks in South Korea, needed to refresh its data center network so it could continue to protect sensitive customer information and ensure uninterrupted operations. Extreme’s high-capacity switches and Extreme Fabric technology will help support the mission-critical network with best-in-class network security, stability, and performance. |

[0001564590-22-035354:8k_2_02:30]
|  | • | A major luxury Las Vegas casino scheduled to open in 2023, has chosen Extreme to provide critical networking infrastructure needed to support corporate IT operations, A/V requirements and connectivity for guests and staff across its 4,000 rooms, 550,000 square feet of convention space and the casino floor. Extreme will deliver a flexible, secure network that can scale to support the casino’s wide range of day-to-day needs as well as special events like business conferences, entertainment events and guest receptions. |

[0001564590-22-035354:8k_2_02:31]
|  | • | Extreme helped the Ministry of Justice in France automate the deployment and management of its network, which spans hundreds of remote sites across the country, and gain better visibility into network performance across all points. The Ministry deployed end-to-end networking solutions |

[0001564590-22-035354:8k_2_02:32]
|  |  | and invested in Extreme Premier Services, significantly reducing the need for additional internal or external IT resources. |

[0001564590-22-035354:8k_2_02:33]
|  | • | The San Diego Community College District, one of the largest community college districts in the U.S., was looking to scale connectivity across its campus to offer more tech-driven curriculums and support a variety of IoT devices across campus. The college deployed Extreme Wi-Fi 6 Access points and switches and is managing the entire network from ExtremeCloud IQ, reducing the need for additional IT staff and creating visibility into network performance across the entire campus. |

[0001564590-22-035354:8k_2_02:34]
Fiscal Q1 2023 Financial Metrics:

[0001564590-22-035354:8k_2_02:35]
(in millions, except percentages and per share information)

[0001564590-22-035354:8k_2_02:36]
|  |  | GAAP Results |  |
|  |  | Three Months Ended |  |
|  |  | September 30, 2022 |  |  | September 30, 2021 |  |  | Change |  |
| Product |  | $ | 206.3 |  |  | $ | 185.2 |  |  | $ | 21.1 |  |  |  | 11 | % |
| Service and subscription |  |  | 91.4 |  |  |  | 82.5 |  |  |  | 8.9 |  |  |  | 11 | % |
| Total net revenue |  | $ | 297.7 |  |  | $ | 267.7 |  |  | $ | 30.0 |  |  |  | 11 | % |
| Gross margin |  |  | 56.0 | % |  |  | 58.1 | % |  |  | (2.1 | )% |  |  | — |  |
| Operating margin |  |  | 5.8 | % |  |  | 6.9 | % |  |  | (1.0 | )% |  |  | — |  |
| Net income |  | $ | 12.6 |  |  | $ | 12.7 |  |  | $ | (0.1 | ) |  |  | (1 | )% |
| Net income per diluted share |  | $ | 0.09 |  |  | $ | 0.10 |  |  | $ | (0.01 | ) |  |  | (10 | )% |

[0001564590-22-035354:8k_2_02:37]
|  |  | Non-GAAP Results |  |
|  |  | Three Months Ended |  |
|  |  | September 30, 2022 |  |  | September 30, 2021 |  |  | Change |  |
| Product |  | $ | 206.3 |  |  | $ | 185.2 |  |  | $ | 21.1 |  |  |  | 11 | % |
| Service and subscription |  |  | 91.4 |  |  |  | 82.5 |  |  |  | 8.9 |  |  |  | 11 | % |
| Total net revenue |  | $ | 297.7 |  |  | $ | 267.7 |  |  | $ | 30.0 |  |  |  | 11 | % |
| Gross margin |  |  | 57.6 | % |  |  | 60.3 | % |  |  | (2.7 | )% |  |  | — |  |
| Operating margin |  |  | 12.1 | % |  |  | 13.8 | % |  |  | (1.7 | )% |  |  | — |  |
| Net income |  | $ | 27.1 |  |  | $ | 28.0 |  |  | $ | (0.9 | ) |  |  | (3 | )% |
| Net income per diluted share |  | $ | 0.20 |  |  | $ | 0.21 |  |  | $ | (0.01 | ) |  |  | (5 | )% |

[0001564590-22-035354:8k_2_02:38]
|  | • | Q1 ending cash balance was $198.3 million, an increase of $3.8 million from the end of Q4. This was primarily driven by operating cash flow generation of $49.7 million, partially offset by cash usage of $42.1 million for financing activities primarily for payments against our term loan and cash usage of $3.1 million for investing activities for capital expenditures. |

[0001564590-22-035354:8k_2_02:39]
|  | • | Q1 accounts receivable balance was $158.7 million, a decrease of $25.4 million from the end of Q4 and an increase of $29.1 million from Q1 last year. Days sales outstanding was 49 days, a decrease of 11 days from Q4 and an increase of 4 days from Q1 last year. |

[0001564590-22-035354:8k_2_02:40]
|  | • | Q1 ending inventory was $51.8 million, an increase of $2.6 million from Q4 and an increase of $19.4 million from Q1 last year. The quarter-over-quarter and year-over-year increases were primarily driven by an increase in finished goods inventory. |

[0001564590-22-035354:8k_2_02:41]
|  | • | Q1 ending gross debt** was $271.5 million, a decrease of $37.1 million from the prior quarter. The $58.5 million decrease from Q1 last year resulted primarily from principal payments on our term loan. Q1 ending net debt*** was $73.2 million, a decrease of $40.9 million from $114.1 million in Q4. |

[0001564590-22-035354:8k_2_02:42]
Extreme uses the non-GAAP free cash flow metric as a measure of operating performance. Free cash flow represents GAAP net cash provided by operating activities, less purchases of property, plant and equipment.  Extreme considers free cash flow to be useful information for management and investors regarding the amount of cash generated by the business after the purchases of property, plant and equipment, which can then be used to, among other things, invest in Extreme’s business, make strategic acquisitions, and strengthen the balance sheet. A limitation of the utility of this non-GAAP free cash flow metric as a measure of financial performance is that it does not represent the total increase or decrease in the Company's cash balance for the period. The following table shows non-GAAP free cash flow calculation (in thousands):

[0001564590-22-035354:8k_2_02:43]
| Free Cash Flow | Three Months Ended |  |
|  | September 30, 2022 |  |  | September 30, 2021 |  |
| Cash flow provided by operations | $ | 49,734 |  |  | $ | 40,254 |  |
| Less: Property and equipment capital expenditures |  | (3,139 | ) |  |  | (3,410 | ) |
| Total free cash flow | $ | 46,595 |  |  | $ | 36,844 |  |

[0001564590-22-035354:8k_2_02:44]
*SaaS ARR: Extreme uses SaaS annual recurring revenue (“SaaS ARR”) to identify the annual recurring revenue of ExtremeCloud™ IQ (XIQ) and other subscription revenue, based on the annualized value of quarterly subscription revenue and term-based licenses. We believe that SaaS ARR is an important metric because it is driven by our ability to acquire new customers and to maintain and expand our relationship with existing customers. SaaS ARR should be viewed independently of revenue, deferred revenue and other U.S. GAAP accounting. SaaS ARR does not have a standardized meaning and therefore may not be comparable to similarly titled measures presented by other companies. SaaS ARR is not intended to be a replacement for forecasts of revenue.

[0001564590-22-035354:8k_2_02:45]
**Gross Debt: Gross debt is defined as long-term and current portion of long-term debt as shown on the balance sheet plus unamortized debt issuance costs, if any.

[0001564590-22-035354:8k_2_02:46]
***Net Debt is defined as gross debt minus cash, as shown in the table below (in millions):

[0001564590-22-035354:8k_2_02:47]
| Gross debt |  |  | Cash |  |  | Net debt |  |
| $ | 271.5 |  |  | $ | 198.3 |  |  | $ | 73.2 |  |

[0001564590-22-035354:8k_2_02:48]
Business Outlook:

[0001564590-22-035354:8k_2_02:49]
For its second quarter of fiscal 2023, ending December 31, 2022, the Company is targeting:

[0001564590-22-035354:8k_2_02:50]
| (in millions, except percentages and per share information) | Low-End |  |  | High-End |  |
| FQ2'23 Guidance – GAAP |  |  |  |  |  |  |  |
| Total net revenue | $ | 299.0 |  |  | $ | 309.0 |  |
| Gross margin |  | 56.0 | % |  |  | 58.0 | % |
| Operating expenses | $ | 149.8 |  |  | $ | 155.1 |  |
| Operating margin |  | 5.9 | % |  |  | 7.8 | % |
| Net income | $ | 11.6 |  |  | $ | 18.2 |  |
| Net income per diluted share | $ | 0.09 |  |  | $ | 0.14 |  |
| Shares outstanding used in calculating GAAP EPS |  | 133.9 |  |  |  | 133.9 |  |
| FQ2’23 Guidance – Non–GAAP |  |  |  |  |  |  |  |
| Total net revenue | $ | 299.0 |  |  | $ | 309.0 |  |
| Gross margin |  | 57.5 | % |  |  | 59.5 | % |
| Operating expenses | $ | 132.9 |  |  | $ | 137.8 |  |
| Operating margin |  | 13.0 | % |  |  | 14.9 | % |
| Net income | $ | 27.9 |  |  | $ | 35.0 |  |
| Net income per diluted share | $ | 0.21 |  |  | $ | 0.26 |  |
| Shares outstanding used in calculating non-GAAP EPS |  | 133.9 |  |  |  | 133.9 |  |

[0001564590-22-035354:8k_2_02:51]
The following table shows the GAAP to non-GAAP reconciliation for Q2 FY’23 guidance:

[0001564590-22-035354:8k_2_02:52]
|  | Gross Margin Rate |  |  | Operating Margin Rate |  |  | Earnings per Share |  |
| GAAP | 56.0% - 58.0% |  |  | 5.9% - 7.8% |  |  | $0.09 - $0.14 |  |
| Estimated adjustments for: |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of product intangibles | 0.8% |  |  | 0.8% |  |  |  | 0.02 |  |
| Share-based compensation | 0.4% |  |  | 5.7% |  |  |  | 0.13 |  |
| Restructuring |  | — |  |  | 0.1% |  |  |  | 0.00 |  |
| Amortization of non-product intangibles | 0.3% |  |  | 0.5% |  |  |  | 0.01 |  |
| Tax effect of non-GAAP adjustments |  | — |  |  |  | — |  |  |  | (0.04) |  |
| Non-GAAP | 57.5% -59.5% |  |  | 13.0% - 14.9% |  |  | $0.21 - $0.26 |  |

[0001564590-22-035354:8k_2_02:53]
The total of percentage rate changes may not equal the total change in all cases due to rounding.

[0001564590-22-035354:8k_2_02:54]
Conference Call:

[0001564590-22-035354:8k_2_02:55]
Extreme will host a conference call at 8:00 a.m. Eastern (5:00 a.m. Pacific) today to review the first fiscal quarter results as well as the business outlook for the second quarter ending December 31, 2022, including significant factors and assumptions underlying the targets noted above. The conference call will be available to the public through a live audio web broadcast via the internet at http://investor.extremenetworks.com and a replay of the call will be available on the website for at least 7 days following the call. To access the call by phone, please go to this link (Extreme Networks Q1'23 Earnings Registration Link) and you will be provided with dial in details. To avoid delays, we encourage participants to dial into the conference call fifteen minutes ahead of the scheduled start time.

[0001564590-22-035354:8k_2_02:56]
About Extreme:

[0001564590-22-035354:8k_2_02:57]
Extreme Networks, Inc. (EXTR) creates networking experiences that enable all of us to advance. We push the boundaries of technology leveraging the powers of machine learning, artificial intelligence, analytics, and automation. Over 50,000 customers globally trust our end-to-end, cloud-driven networking solutions and rely on our top-rated services and support to accelerate their digital transformation efforts and deliver

[0001564590-22-035354:8k_2_02:58]
progress like never before. For more information, visit Extreme's website at https://www.extremenetworks.com/ or LinkedIn, YouTube, Twitter, Facebook or Instagram

[0001564590-22-035354:8k_2_02:59]
Extreme Networks, ExtremeCloud, and the Extreme Networks logo, are trademarks of Extreme Networks, Inc. or its subsidiaries in the United States and/or other countries. Other trademarks shown herein are the property of their respective owners.

[0001564590-22-035354:8k_2_02:60]
Non-GAAP Financial Measures:

[0001564590-22-035354:8k_2_02:61]
Extreme provides all financial information required in accordance with U.S. generally accepted accounting principles (“GAAP”). The Company is providing with this press release non-GAAP gross margin, non-GAAP operating expenses, non-GAAP operating margin, non-GAAP operating income, non-GAAP net income, non-GAAP net income per diluted share, non-GAAP free cash flow. In preparing non-GAAP information, the Company has excluded, where applicable, the impact of share-based compensation, acquisition and integration costs, amortization of intangibles, restructuring charges and the tax effect of non-GAAP adjustments.  The Company believes that excluding these items provides both management and investors with additional insight into its current operations, the trends affecting the Company, the Company's marketplace performance, and the Company's ability to generate cash from operations. Please note the Company's non-GAAP measures may be different than those used by other companies. The additional non-GAAP financial information the Company presents should be considered in conjunction with, and not as a substitute for, the Company's GAAP financial information.

[0001564590-22-035354:8k_2_02:62]
The Company has provided a non-GAAP reconciliation of the results for the periods presented in this release, which are adjusted to exclude certain items as indicated.  These measures should only be used to evaluate the Company's results of operations in conjunction with the corresponding GAAP measures for comparable financial information and understanding of the Company's ongoing performance as a business. Extreme uses both GAAP and non-GAAP measures to evaluate and manage its operations.

[0001564590-22-035354:8k_2_02:63]
Forward-Looking Statements:

[0001564590-22-035354:8k_2_02:64]
More information about potential factors that could affect the Company's business and financial results are described in “Management's Discussion and Analysis of Financial Condition and Results of Operations”

[0001564590-22-035354:8k_2_02:65]
and “Risk Factors” included in the Company’s Annual Report on Form 10-K for the year ended June 30, 2022, and other documents of the Company on file with the Securities and Exchange Commission (available at www.sec.gov).  As a result of these risks and others, actual results could vary significantly from those anticipated in this press release, and the Company’s financial condition and results of operations could be materially adversely affected. Except as required under the U.S. federal securities laws and the rules and regulations of the U.S. Securities and Exchange Commission, Extreme disclaims any obligation to update any forward-looking statements after the date of this release, whether as a result of new information, future events, developments, changes in assumptions or otherwise.

[0001564590-22-035354:8k_2_02:66]
###

[0001564590-22-035354:8k_2_02:67]
EXTREME NETWORKS, INC.

[0001564590-22-035354:8k_2_02:68]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0001564590-22-035354:8k_2_02:69]
(In thousands, except per share amounts)

[0001564590-22-035354:8k_2_02:70]
(Unaudited)

[0001564590-22-035354:8k_2_02:71]
|  |  | September 30, 2022 |  |  | June 30, 2022 |  |
| ASSETS |  |  |  |  |  |  |  |  |
| Current assets: |  |  |  |  |  |  |  |  |
| Cash |  | $ | 198,344 |  |  | $ | 194,522 |  |
| Accounts receivable, net |  |  | 158,727 |  |  |  | 184,097 |  |
| Inventories |  |  | 51,766 |  |  |  | 49,231 |  |
| Prepaid expenses and other current assets |  |  | 73,267 |  |  |  | 61,239 |  |
| Total current assets |  |  | 482,104 |  |  |  | 489,089 |  |
| Property and equipment, net |  |  | 47,952 |  |  |  | 49,578 |  |
| Operating lease right-of-use assets, net |  |  | 34,269 |  |  |  | 36,454 |  |
| Intangible assets, net |  |  | 28,565 |  |  |  | 32,515 |  |
| Goodwill |  |  | 400,144 |  |  |  | 400,144 |  |
| Other assets |  |  | 64,746 |  |  |  | 60,730 |  |
| Total assets |  | $ | 1,057,780 |  |  | $ | 1,068,510 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |  |  |  |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |  |  |  |
| Current portion of long-term debt, net of unamortized debt issuance costs of $2,236 and $2,276, respectively |  | $ | 35,764 |  |  | $ | 33,349 |  |
| Accounts payable |  |  | 84,848 |  |  |  | 84,338 |  |
| Accrued compensation and benefits |  |  | 47,544 |  |  |  | 53,710 |  |
| Accrued warranty |  |  | 11,522 |  |  |  | 10,852 |  |
| Current portion, operating lease liabilities |  |  | 12,805 |  |  |  | 13,956 |  |
| Current portion, deferred revenue |  |  | 252,841 |  |  |  | 238,262 |  |
| Other accrued liabilities |  |  | 57,375 |  |  |  | 65,714 |  |
| Total current liabilities |  |  | 502,699 |  |  |  | 500,181 |  |
| Deferred revenue, less current portion |  |  | 171,144 |  |  |  | 163,357 |  |
| Long-term debt, less current portion, net of unamortized debt issuance costs of $1,860 and $2,430, respectively |  |  | 231,640 |  |  |  | 270,570 |  |
| Operating lease liabilities, less current portion |  |  | 31,291 |  |  |  | 33,256 |  |
| Deferred income taxes |  |  | 7,311 |  |  |  | 7,717 |  |
| Other long-term liabilities |  |  | 3,092 |  |  |  | 3,086 |  |
| Commitments and contingencies |  |  |  |  |  |  |  |  |
| Stockholders’ equity: |  |  |  |  |  |  |  |  |
| Convertible preferred stock, $0.001 par value, issuable in series, 2,000 shares authorized; none issued |  |  | — |  |  |  | — |  |
| Common stock, $0.001 par value, 750,000 shares authorized; 141,706 and 139,742 shares issued, respectively; 131,227 and 129,263 shares outstanding, respectively |  |  | 142 |  |  |  | 140 |  |
| Additional paid-in-capital |  |  | 1,125,204 |  |  |  | 1,115,416 |  |
| Accumulated other comprehensive loss |  |  | (5,170 | ) |  |  | (3,055 | ) |
| Accumulated deficit |  |  | (921,487 | ) |  |  | (934,072 | ) |
| Treasury stock at cost, 10,479 shares |  |  | (88,086 | ) |  |  | (88,086 | ) |
| Total stockholders’ equity |  |  | 110,603 |  |  |  | 90,343 |  |
| Total liabilities and stockholders’ equity |  | $ | 1,057,780 |  |  | $ | 1,068,510 |  |

[0001564590-22-035354:8k_2_02:72]
EXTREME NETWORKS, INC.

[0001564590-22-035354:8k_2_02:73]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS

[0001564590-22-035354:8k_2_02:74]
(In thousands, except per share amounts)

[0001564590-22-035354:8k_2_02:75]
(Unaudited)

[0001564590-22-035354:8k_2_02:76]
|  |  | Three Months Ended |  |
|  |  | September 30, 2022 |  |  | September 30, 2021 |  |
| Net revenues: |  |  |  |  |  |  |  |  |
| Product |  | $ | 206,276 |  |  | $ | 185,161 |  |
| Service and subscription |  |  | 91,413 |  |  |  | 82,523 |  |
| Total net revenues |  |  | 297,689 |  |  |  | 267,684 |  |
| Cost of revenues: |  |  |  |  |  |  |  |  |
| Product |  |  | 99,763 |  |  |  | 80,944 |  |
| Service and subscription |  |  | 31,218 |  |  |  | 31,137 |  |
| Total cost of revenues |  |  | 130,981 |  |  |  | 112,081 |  |
| Gross profit: |  |  |  |  |  |  |  |  |
| Product |  |  | 106,513 |  |  |  | 104,217 |  |
| Service and subscription |  |  | 60,195 |  |  |  | 51,386 |  |
| Total gross profit |  |  | 166,708 |  |  |  | 155,603 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |
| Research and development |  |  | 50,989 |  |  |  | 47,766 |  |
| Sales and marketing |  |  | 78,382 |  |  |  | 69,527 |  |
| General and administrative |  |  | 18,547 |  |  |  | 17,003 |  |
| Acquisition and integration costs |  |  | 390 |  |  |  | 1,510 |  |
| Restructuring and related charges |  |  | 481 |  |  |  | 279 |  |
| Amortization of intangibles |  |  | 523 |  |  |  | 1,154 |  |
| Total operating expenses |  |  | 149,312 |  |  |  | 137,239 |  |
| Operating income |  |  | 17,396 |  |  |  | 18,364 |  |
| Interest income |  |  | 392 |  |  |  | 110 |  |
| Interest expense |  |  | (3,826 | ) |  |  | (3,880 | ) |
| Other income, net |  |  | 371 |  |  |  | 171 |  |
| Income before income taxes |  |  | 14,333 |  |  |  | 14,765 |  |
| Provision for income taxes |  |  | 1,748 |  |  |  | 2,069 |  |
| Net income |  | $ | 12,585 |  |  | $ | 12,696 |  |
| Basic and diluted income per share: |  |  |  |  |  |  |  |  |
| Net income per share – basic |  | $ | 0.10 |  |  | $ | 0.10 |  |
| Net income per share – diluted |  | $ | 0.09 |  |  | $ | 0.10 |  |
| Shares used in per share calculation – basic |  |  | 130,289 |  |  |  | 128,324 |  |
| Shares used in per share calculation – diluted |  |  | 132,933 |  |  |  | 133,225 |  |

[0001564590-22-035354:8k_2_02:77]
EXTREME NETWORKS, INC.

[0001564590-22-035354:8k_2_02:78]
CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS

[0001564590-22-035354:8k_2_02:79]
(In thousands)

[0001564590-22-035354:8k_2_02:80]
(Unaudited)

[0001564590-22-035354:8k_2_02:81]
|  |  | Three Months Ended |  |
|  |  | September 30, 2022 |  |  | September 30, 2021 |  |
| Cash flows from operating activities: |  |  |  |  |  |  |  |  |
| Net Income |  | $ | 12,585 |  |  | $ | 12,696 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |  |  |  |  |
| Depreciation |  |  | 4,953 |  |  |  | 5,155 |  |
| Amortization of intangible assets |  |  | 4,128 |  |  |  | 6,440 |  |
| Reduction in carrying amount of right-of-use asset |  |  | 3,063 |  |  |  | 3,902 |  |
| Provision for doubtful accounts |  |  | 23 |  |  |  | 26 |  |
| Share-based compensation |  |  | 13,789 |  |  |  | 10,444 |  |
| Deferred income taxes |  |  | (85 | ) |  |  | 682 |  |
| Non-cash interest expense |  |  | 552 |  |  |  | 1,314 |  |
| Other |  |  | (3,595 | ) |  |  | (176 | ) |
| Changes in operating assets and liabilities, net of acquisition: |  |  |  |  |  |  |  |  |
| Accounts receivable |  |  | 25,347 |  |  |  | 28,281 |  |
| Inventories |  |  | (2,671 | ) |  |  | 604 |  |
| Prepaid expenses and other assets |  |  | (318 | ) |  |  | (18,640 | ) |
| Accounts payable |  |  | (591 | ) |  |  | 2,577 |  |
| Accrued compensation and benefits |  |  | (6,564 | ) |  |  | (22,540 | ) |
| Operating lease liabilities |  |  | (3,952 | ) |  |  | (4,839 | ) |
| Deferred revenue |  |  | 9,699 |  |  |  | 7,680 |  |
| Other current and long-term liabilities |  |  | (6,629 | ) |  |  | 6,648 |  |
| Net cash provided by operating activities |  |  | 49,734 |  |  |  | 40,254 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |
| Capital expenditures |  |  | (3,139 | ) |  |  | (3,410 | ) |
| Business acquisition, net of cash acquired |  |  | — |  |  |  | (69,517 | ) |
| Net cash used in investing activities |  |  | (3,139 | ) |  |  | (72,927 | ) |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |
| Payments on debt obligations |  |  | (37,125 | ) |  |  | (16,750 | ) |
| Payments for tax withholdings, net of proceeds from issuance of common stock |  |  | (3,999 | ) |  |  | (4,372 | ) |
| Payment of contingent consideration obligations |  |  | — |  |  |  | (559 | ) |
| Deferred payments on an acquisition |  |  | (1,000 | ) |  |  | (1,000 | ) |
| Net cash used in financing activities |  |  | (42,124 | ) |  |  | (22,681 | ) |
| Foreign currency effect on cash |  |  | (649 | ) |  |  | (191 | ) |
| Net increase (decrease) in cash |  |  | 3,822 |  |  |  | (55,545 | ) |
| Cash at beginning of period |  |  | 194,522 |  |  |  | 246,894 |  |
| Cash at end of period |  | $ | 198,344 |  |  | $ | 191,349 |  |

[0001564590-22-035354:8k_2_02:82]
Extreme Networks, Inc.

[0001564590-22-035354:8k_2_02:83]
Non-GAAP Measures of Financial Performance

[0001564590-22-035354:8k_2_02:84]
To supplement the Company's consolidated financial statements presented in accordance with U.S. generally accepted accounting principles, (“GAAP”), Extreme uses non-GAAP measures of certain components of financial performance.  These non-GAAP measures include non-GAAP gross margin, non-GAAP operating expenses, non-GAAP operating margin, non-GAAP operating income, non-GAAP net income, non-GAAP net income per diluted share, non-GAAP free cash flow.

[0001564590-22-035354:8k_2_02:85]
Reconciliation to the nearest GAAP measure of all historical non-GAAP measures included in this press release can be found in the tables included with this press release.

[0001564590-22-035354:8k_2_02:86]
Non-GAAP measures presented in this press release are not in accordance with or alternative measures prepared in accordance with GAAP and may be different from non-GAAP measures used by other companies.  In addition, these non-GAAP measures are not based on any comprehensive set of accounting rules or principles.  Non-GAAP measures have limitations in that they do not reflect all of the amounts associated with Extreme’s results of operations as determined in accordance with GAAP.  These non-GAAP measures should only be used to evaluate Extreme’s results of operations in conjunction with the corresponding GAAP measures.

[0001564590-22-035354:8k_2_02:87]
Extreme believes these non-GAAP measures when shown in conjunction with the corresponding GAAP measures enhance investors' and management's overall understanding of the Company's current financial performance and the Company's prospects for the future, including cash flows available to pursue opportunities to enhance stockholder value.  In addition, because Extreme has historically reported certain non-GAAP results to investors, the Company believes the inclusion of non-GAAP measures provides consistency in the Company's financial reporting.

[0001564590-22-035354:8k_2_02:88]
For its internal planning process, and as discussed further below, Extreme's management uses financial statements that do not include share-based compensation expense, acquisition and integration costs, amortization of intangibles, restructuring charges, and the tax effect of non-GAAP adjustments.  Extreme’s management also uses non-GAAP measures, in addition to the corresponding GAAP measures, in reviewing the Company's financial results.

[0001564590-22-035354:8k_2_02:89]
As described above, Extreme excludes the following items from one or more of its non-GAAP measures when applicable.

[0001564590-22-035354:8k_2_02:90]
Share-based compensation. Consists of associated expenses for stock options, restricted stock awards and the Company’s Employee Stock Purchase Plan.  Extreme excludes share-based compensation expenses from its non-GAAP measures primarily because they are non-cash expenses that the Company does not believe are reflective of ongoing cash requirement related to its operating results. Extreme expects to incur share-based compensation expenses in future periods.

[0001564590-22-035354:8k_2_02:91]
Acquisition and integration costs. Acquisition and integration costs consist of specified compensation charges, software charges, legal and professional fees related to the acquisition of  Ipanema.  Extreme excludes these expenses since they result from an event that is outside the ordinary course of continuing operations.

[0001564590-22-035354:8k_2_02:92]
Amortization of intangibles. Amortization of intangibles includes the monthly amortization expense of intangible assets such as developed technology, customer relationships, trademarks and order backlog.  The amortization of the developed technology and order backlog are recorded in cost of goods sold, while the amortization for the other intangibles is recorded in operating expenses.  Extreme excludes these expenses since they result from an intangible asset and for which the period expense does not impact the operations of the business and are non-cash in nature.

[0001564590-22-035354:8k_2_02:93]
Restructuring charges. Restructuring charges primarily consist of severance costs for employees which have no benefit to continuing operations and impairment of right-of-use assets, long-lived assets and other charges related to excess facilities. Extreme excludes restructuring expenses since they result from events that occur outside of the ordinary course of continuing operations.

[0001564590-22-035354:8k_2_02:94]
Tax effect of non-GAAP adjustments. We calculate our non-GAAP provision for income taxes in accordance with the SEC guidance on non-GAAP Financial Measures Compliance and Disclosure Interpretation.  We have assumed our U.S. federal and state net operating losses would have been fully consumed by the historical non-GAAP financial adjustments, eliminating the need for a full valuation allowance against our U.S. deferred tax assets which, consequently, enables our use of research and development tax credits.  The non-GAAP tax provision consists of current and deferred income tax expense commensurate with the non-GAAP measure of profitability using our blended U.S. statutory tax rate of 24.2%.

[0001564590-22-035354:8k_2_02:95]
Non-GAAP provision for income taxes may be higher or lower depending on the level and jurisdictional mix of pre-tax income and available U.S. research and development tax credits.  As of the tax year ended June 30, 2022, we have U.S. federal net operating loss carryforwards of $184.5 million, state net operating loss carryforwards of $162.8 million and net operating loss carryforwards for the Irish holding Company of $8.9 million.  These amounts will be reflected in our requisite tax filings for each jurisdiction for the tax year ended June 30, 2022. We anticipate utilization of a portion of these net operating losses in each of the jurisdiction for the tax year ended June 30, 2023; however, we do not expect to pay substantial taxes on a GAAP basis in the U.S. in the near term due to our net operating loss carryforward balances.  Over the near term, most of our cash taxes will continue to be mainly driven by the tax expense of our foreign subsidiaries which amounts have not historically been significant, with the exception of the Company’s Indian subsidiary which primarily performs research and development activities, as well as the Company’s Irish operating company which fully utilized available net operating loss carryforwards during the tax year ended June 30, 2021.

[0001564590-22-035354:8k_2_02:96]
EXTREME NETWORKS, INC.

[0001564590-22-035354:8k_2_02:97]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS

[0001564590-22-035354:8k_2_02:98]
GAAP TO NON-GAAP RECONCILIATION

[0001564590-22-035354:8k_2_02:99]
(In thousands, except percentages and per share amounts)

[0001564590-22-035354:8k_2_02:100]
(Unaudited)

[0001564590-22-035354:8k_2_02:101]
| Revenues | Three Months Ended |  |
|  | September 30, 2022 |  |  | September 30, 2021 |  |  | June 30, 2022 |  |
| Revenues - GAAP | $ | 297,689 |  |  | $ | 267,684 |  |  | $ | 278,196 |  |

[0001564590-22-035354:8k_2_02:102]
| Non-GAAP Gross Margin | Three Months Ended |  |
|  | September 30, 2022 |  |  | September 30, 2021 |  |  | June 30, 2022 |  |
| Gross profit - GAAP | $ | 166,708 |  |  | $ | 155,603 |  |  | $ | 154,191 |  |
| Gross margin - GAAP percentage |  | 56.0 | % |  |  | 58.1 | % |  |  | 55.4 | % |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expense |  | 1,046 |  |  |  | 672 |  |  |  | 646 |  |
| Amortization of intangibles |  | 3,587 |  |  |  | 5,269 |  |  |  | 3,619 |  |
| Total adjustments to GAAP gross profit | $ | 4,633 |  |  | $ | 5,941 |  |  | $ | 4,265 |  |
| Gross profit - non-GAAP | $ | 171,341 |  |  | $ | 161,544 |  |  | $ | 158,456 |  |
| Gross margin - non-GAAP percentage |  | 57.6 | % |  |  | 60.3 | % |  |  | 57.0 | % |

[0001564590-22-035354:8k_2_02:103]
| Non-GAAP Operating Income | Three Months Ended |  |
|  | September 30, 2022 |  |  | September 30, 2021 |  |  | June 30, 2022 |  |
| GAAP operating income | $ | 17,396 |  |  | $ | 18,364 |  |  | $ | 10,458 |  |
| GAAP operating income percentage |  | 5.8 | % |  |  | 6.9 | % |  |  | 3.8 | % |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expense, cost of revenues |  | 1,046 |  |  |  | 672 |  |  |  | 646 |  |
| Share-based compensation expense, R&D |  | 3,090 |  |  |  | 2,458 |  |  |  | 2,427 |  |
| Share-based compensation expense, S&M |  | 4,639 |  |  |  | 3,575 |  |  |  | 3,733 |  |
| Share-based compensation expense, G&A |  | 5,014 |  |  |  | 3,739 |  |  |  | 3,925 |  |
| Acquisition and integration costs |  | 390 |  |  |  | 1,510 |  |  |  | 553 |  |
| Restructuring charges |  | 481 |  |  |  | 279 |  |  |  | 770 |  |
| Amortization of intangibles |  | 4,110 |  |  |  | 6,423 |  |  |  | 4,258 |  |
| Total adjustments to GAAP operating income | $ | 18,770 |  |  | $ | 18,656 |  |  | $ | 16,312 |  |
| Non-GAAP operating income | $ | 36,166 |  |  | $ | 37,020 |  |  | $ | 26,770 |  |
| Non-GAAP operating income percentage |  | 12.1 | % |  |  | 13.8 | % |  |  | 9.6 | % |

[0001564590-22-035354:8k_2_02:104]
| Non-GAAP net income | Three Months Ended |  |
|  | September 30, 2022 |  |  | September 30, 2021 |  |  | June 30, 2022 |  |
| GAAP net income | $ | 12,585 |  |  | $ | 12,696 |  |  | $ | 5,410 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expense |  | 13,789 |  |  |  | 10,444 |  |  |  | 10,731 |  |
| Acquisition and integration costs |  | 390 |  |  |  | 1,510 |  |  |  | 553 |  |
| Restructuring charge, net of reversal |  | 481 |  |  |  | 279 |  |  |  | 770 |  |
| Amortization of intangibles |  | 4,110 |  |  |  | 6,423 |  |  |  | 4,258 |  |
| Tax effect of non-GAAP adjustments |  | (4,268 | ) |  |  | (3,400 | ) |  |  | (2,074 | ) |
| Total adjustments to GAAP net income | $ | 14,502 |  |  | $ | 15,256 |  |  | $ | 14,238 |  |
| Non-GAAP net income | $ | 27,087 |  |  | $ | 27,952 |  |  | $ | 19,648 |  |
| Earnings per share |  |  |  |  |  |  |  |  |  |  |  |
| GAAP net income per share-diluted | $ | 0.09 |  |  | $ | 0.10 |  |  | $ | 0.04 |  |
| Non-GAAP net income per share-diluted | $ | 0.20 |  |  | $ | 0.21 |  |  | $ | 0.15 |  |
| Shares used in net income per share - diluted: |  |  |  |  |  |  |  |  |  |  |  |
| GAAP Shares used in per share calculation - basic |  | 130,289 |  |  |  | 128,324 |  |  |  | 129,788 |  |
| Potentially dilutive equity awards |  | 2,644 |  |  |  | 4,901 |  |  |  | 2,516 |  |
| GAAP and Non-GAAP shares used in per share calculation - diluted |  | 132,933 |  |  |  | 133,225 |  |  |  | 132,304 |  |
