# EXTR notes — 0001564590-17-023316


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0001564590-17-023316:notes:1]
[same as prior period, unchanged from 0001564590-17-008860:notes:1]

[0001564590-17-023316:notes:2]
[same as prior period, unchanged from 0001564590-17-008860:notes:2]

[0001564590-17-023316:notes:3]
The unaudited condensed consolidated financial statements of Extreme included herein have been prepared under the rules and regulations of the Securities and Exchange Commission (“SEC”).  Certain information and footnote disclosures normally included in financial statements prepared in accordance with generally accepted accounting principles have been condensed or omitted under such rules and regulations.  The condensed consolidated balance sheet at June 30, 2017 was derived from audited financial statements as of that date but does not include all disclosures required by generally accepted accounting principles for complete financial statements. These interim financial statements and notes should be read in conjunction with the Company’s audited consolidated financial statements and notes thereto included in the Company’s Annual Report on Form 10-K for the fiscal year ended June 30, 2017.

[0001564590-17-023316:notes:4]
The unaudited condensed consolidated financial statements reflect all adjustments, consisting only of normal recurring adjustments that, in the opinion of management, are necessary for a fair presentation of the results of operations and cash flows for the interim periods presented and the financial condition of Extreme at September 30, 2017. The results of operations for the three months ended September 30, 2017 are not necessarily indicative of the results that may be expected for fiscal 2018 or any future periods.

[0001564590-17-023316:notes:5]
Effective July 1, 2017, the Company adopted the requirements of Accounting Standards Update (“ASU”) No. 2014-09, Revenue from Contracts with Customers. All amounts and disclosures set forth in this Form 10-Q have been updated to comply with the new standards, as indicated by the “as adjusted” footnote.

[0001564590-17-023316:notes:6]
[same as prior period, unchanged from 0001564590-17-008860:notes:5]

[0001564590-17-023316:notes:7]
The Company uses a fiscal calendar year ending on June 30.  All references herein to “fiscal 2018” or “2018” represent the fiscal year ending June 30, 2018.  All references herein to “fiscal 2017” or “2017” represent the fiscal year ending June 30, 2017.

[0001564590-17-023316:notes:8]
[same as prior period, unchanged from 0001564590-17-008860:notes:7]

[0001564590-17-023316:notes:9]
[same as prior period, unchanged from 0001564590-17-008860:notes:8]

[0001564590-17-023316:notes:10]
[same as prior period, unchanged from 0001564590-17-008860:notes:9]

[0001564590-17-023316:notes:11]
[same as prior period, unchanged from 0001564590-17-008860:notes:10]

[0001564590-17-023316:notes:12]
[same as prior period, unchanged from 0001564590-17-008860:notes:11]


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001564590-17-023316:notes:13]
[same as prior period, unchanged from 0001564590-17-008860:notes:12]

[0001564590-17-023316:notes:14]
2018 Acquisition

[0001564590-17-023316:notes:15]
On July 14, 2017, (the “Avaya Closing Date”) the Company completed its acquisition of Avaya Inc.’s. (“Avaya”) fabric-based secure networking solutions and network security solutions business (“Avaya Networking”) that had been announced on March 7, 2017.  Upon the terms and subject to the conditions of the asset purchase agreement (the “Avaya Purchase Agreement”), the Company acquired the customers, employees, technology and other assets of Avaya Networking, as well as assume certain contracts and other liabilities of Avaya Networking, for total provisional consideration  of $79.8 million, calculated as $100.0 million, less adjustments set forth in the Avaya Purchase Agreement related to net working capital, deferred revenue, certain assumed lease obligations and certain assumed pension obligations for transferring employees of Avaya Networking.  Pursuant to certain ancillary agreements, Avaya will also provide the Company with access to specified technology related to Avaya Networking, as well as transition services for a period of time following the Avaya Closing Date of the transaction. As a condition of the Avaya Purchase Agreement, the Company had made deposits of $10.2 million in the third quarter of fiscal 2017, which were applied to the purchase price upon the Avaya Closing Date.

[0001564590-17-023316:notes:16]
The transaction has been accounted for using the acquisition method of accounting.  The provisional purchase price has been allocated on a preliminary basis to tangible and intangible assets acquired and liabilities assumed.  The final purchase price allocation is pending the finalization of valuations, which may result in an adjustment to the preliminary purchase price allocation. Also, additional information which existed as of the acquisition date, but was unknown to the Company at that time, may become known to the Company during the remainder of the measurement period (up to one year from the acquisition date), and may result in a change in the purchase price allocation.  While management believes that its preliminary estimates and assumptions underlying the valuations are reasonable, different estimates and assumptions could result in different valuations assigned to the individual assets acquired and liabilities assumed, and the resulting amount of goodwill.

[0001564590-17-023316:notes:17]
The following table below summarizes the preliminary allocation as of September 30, 2017 of the tangible and identifiable intangible assets acquired and liabilities assumed:

[0001564590-17-023316:notes:18]
|  | Preliminary Allocation as of July 14, 2017 |  |
| Accounts receivables, net | $ | 18,112 |  |
| Inventory |  | 16,605 |  |
| Other current assets |  | 673 |  |
| Property and equipment |  | 3,768 |  |
| Other long-term assets |  | 2,568 |  |
| Accounts payable and accrued expenses |  | (29,716 | ) |
| Deferred revenue |  | (10,214 | ) |
| Other liabilities |  | (6,608 | ) |
| Net tangible assets acquired |  | (4,812 | ) |
| Identifiable intangible assets |  | 44,000 |  |
| In-process research and development |  | 2,300 |  |
| Goodwill |  | 38,338 |  |
| Total intangible assets acquired |  | 84,638 |  |
| Total net assets acquired | $ | 79,826 |  |

[0001564590-17-023316:notes:19]
The estimated purchase price has been allocated based on the preliminary estimates of the fair value of assets acquired and liabilities assumed as of the acquisition date.  The fair value of working capital related items, such as other current assets and accrued liabilities, approximated their book values at the date of acquisition.  Inventories were valued at fair value using the net realizable value approach.   The fair value of property and equipment was determined using a cost approach. The fair value of the acquired deferred revenue was estimated using the cost build-up approach. The cost build-up approach determines fair value using estimates of the costs required to provide the contracted deliverables plus an assumed profit.  The total costs including the assumed profit were adjusted to present value using a discount rate considered appropriate. The resulting fair value approximates the amount that the Company would be required to pay a third party to assume the obligation. Valuations of the intangible assets were valued using income approaches based on projections provided by management, which the Company considers to be Level 3 inputs. The Company also continues to analyze the tax implications of the acquisition of the intangible assets which may ultimately impact the overall level of goodwill associated with the acquisition.

[0001564590-17-023316:notes:20]
[same as prior period, unchanged from 0001564590-17-008860:notes:19]

[0001564590-17-023316:notes:21]
| Intangible Assets |  | Estimated Useful Life (in years) |  |  | Amount |  |
| Developed technology |  |  | 6 |  |  | $ | 34,800 |  |
| Customer relationships |  |  | 4 |  |  |  | 5,300 |  |
| Trademarks |  |  | 5 |  |  |  | 2,400 |  |
| Backlog |  |  | 1 |  |  |  | 1,500 |  |
| Total identifiable intangible assets |  |  |  |  |  | $ | 44,000 |  |

[0001564590-17-023316:notes:22]
The amortization for the developed technology is recorded in “Cost of revenues” for product and the amortization for the remaining intangibles is recorded in “Amortization of intangibles” on the condensed consolidated statement of operations.  The goodwill recognized is attributable primarily to expected synergies and the assembled workforce of the Avaya Networking.  The Company anticipates both the goodwill and intangible assets to be fully deductible for tax purposes.

[0001564590-17-023316:notes:23]
The Company also acquired an indefinite lived asset of $2.3 million which represents the fair value of in-process research and development activities.  Once the related research and development efforts are completed, the Company will determine whether the asset will continue to be an indefinite lived asset or become a finite lived asset and apply the appropriate accounting accordingly.

[0001564590-17-023316:notes:24]
The results of operations of Avaya Networking are included in the condensed consolidated results of operations beginning July 14, 2017.  The associated expenses of the Avaya Networking business have been incorporated with the results of operations of the Company as a product line and, therefore, stand-alone operating results are not available. The Company incurred $5.1 million of acquisition-related expenses of which $2.9 million was incurred in the three months ended September 30, 2017.  Such acquisition-related costs are included in “Acquisition and integration costs” on the condensed consolidated statement of operations.  The costs, which the Company expensed as incurred, consist primarily of professional fees to financial and legal advisors and IT consultants and companies.

[0001564590-17-023316:notes:25]
2017 Acquisition

[0001564590-17-023316:notes:26]
On October 28, 2016, the Company completed the acquisition of the wireless local area network business (“WLAN Business”) from Zebra Technologies Corporation.  Under the terms of the purchase agreement, the Company acquired customers, employees, technology and other assets as well as assumed certain contracts and other liabilities of the WLAN Business, for a net cash consideration to $49.5 million.

[0001564590-17-023316:notes:27]
The acquisition has been accounted for using the acquisition method of accounting.  The purchase price allocation as of the acquisition date is set forth in the table below and reflects fair values. The fair values were determined through established and generally accepted valuation techniques, including work performed by third-party valuation specialists.  All valuations were considered finalized as of June 30, 2017.

[0001564590-17-023316:notes:28]
The following table below summarizes the final allocation of the tangible and identifiable intangible assets acquired and liabilities assumed:

[0001564590-17-023316:notes:29]
|  | Final Allocation as of October 28, 2016 |  |
| Accounts receivables, net | $ | 14,636 |  |
| Inventory |  | 13,593 |  |
| Other current assets |  | 808 |  |
| Property and equipment |  | 3,159 |  |
| Other long-term assets |  | 7,634 |  |
| Deferred revenue |  | (14,159 | ) |
| Other liabilities |  | (7,201 | ) |
| Total tangible assets acquired and liabilities assumed |  | 18,470 |  |
| Identifiable intangible assets |  | 20,300 |  |
| In-process research and development |  | 1,400 |  |
| Goodwill |  | 9,339 |  |
| Total intangible assets acquired |  | 31,039 |  |
| Total net assets acquired | $ | 49,509 |  |

[0001564590-17-023316:notes:30]
The purchase price has been allocated based on the fair value of assets acquired and liabilities assumed as of the acquisition date.  The fair value of working capital related items, such as other current assets and accrued liabilities, approximated their book values at the date of acquisition.  Inventories were valued at fair value using the net realizable value approach.  The fair value of property and equipment was determined using a cost approach.  The fair value of the acquired deferred revenue was estimated using the cost build-up approach. The cost build-up approach determines fair value using estimates of the costs required to provide the contracted deliverables plus an assumed profit.  The total costs including the assumed profit were adjusted to present value using a discount rate considered appropriate. The resulting fair value approximates the amount that the Company would be required to pay a third party to assume the obligation.  Valuations of the intangible assets were valued using income approaches based on projections provided by management, which we consider to be Level 3 inputs.

[0001564590-17-023316:notes:31]
[same as prior period, unchanged from 0001564590-17-008860:notes:24]

[0001564590-17-023316:notes:32]
The following unaudited pro forma results of operations are presented as though the acquisition of Avaya Networking and WLAN Business had occurred as of the beginning of the earliest period presented after giving effect to purchase accounting adjustments relating to inventories, deferred revenue, depreciation and amortization on acquired property and equipment and intangibles, acquisition costs, interest income and expense and related tax effects.

[0001564590-17-023316:notes:33]
[same as prior period, unchanged from 0001564590-17-008860:notes:26]

[0001564590-17-023316:notes:34]
The unaudited pro forma financial information for the three months ended September 30, 2017, combines the results for Extreme for the three months ended September 30, 2017, which include the results of Avaya Networking subsequent to the acquisition date, and the historical results of Avaya Networking for the month of July 2017 up to the acquisition date of July 14, 2017. Pro forma results of operations from Avaya Networking acquisition for the quarter ended September 30, 2017 prior to the acquisition date have not been adjusted for the adoption of ASC 606 because the Company determined that it was impractical to estimate the impact of the adoption.

[0001564590-17-023316:notes:35]
The unaudited pro forma financial information for the three months ended September 30, 2016, combines the historical results for Extreme for those periods, as adjusted for the adoption of ASC 606, with the historical results of Avaya Networking and WLAN Business for the three months ended September 30, 2016. Pro forma results of operations from Avaya Networking and WLAN Business acquisitions for the quarter ended September 30, 2016 have not been adjusted for the adoption of ASC 606 because the Company determined that it is impractical to estimate the impact of the adoption.

[0001564590-17-023316:notes:36]
[same as prior period, unchanged from 0001564590-17-008860:notes:31]

[0001564590-17-023316:notes:37]
|  |  | Three Months Ended |  |
|  |  | September 30, 2017 |  |  | September 30, 2016 |  |
|  |  |  |  |  |  | (As adjusted) |  |
| Net revenues |  | $ | 222,382 |  |  | $ | 238,858 |  |
| Net income (loss) |  | $ | 16,776 |  |  | $ | (8,936 | ) |
| Net income (loss) per share - basic |  | $ | 0.15 |  |  | $ | (0.08 | ) |
| Net income (loss) per share - diluted |  | $ | 0.14 |  |  | $ | (0.08 | ) |
| Shares used in per share calculation - basic |  |  | 112,241 |  |  |  | 105,955 |  |
| Shares used in per share calculation - diluted |  |  | 118,431 |  |  |  | 105,955 |  |


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001564590-17-023316:notes:38]
[same as prior period, unchanged from 0001564590-17-008860:notes:33]

[0001564590-17-023316:notes:39]
For a description of significant accounting policies, see Note 3, Summary of Significant Accounting Policies, to the consolidated financial statements included in the Company’s Annual Report on Form 10-K for the fiscal year ended June 30, 2017. Except for the following policy, there have been no material changes to the Company’s significant accounting policies since the filing of the Annual Report on Form 10-K.

[0001564590-17-023316:notes:40]
Revenue Recognition

[0001564590-17-023316:notes:41]
The Company accounts for revenue in accordance with ASC Topic 606, Revenue from Contracts with Customers, which the Company adopted on July 1, 2017, using the retrospective method.  The Company derives the majority of its revenue from sales of its networking equipment, with the remaining revenue generated from service fees relating to maintenance contracts, professional services, and training for its products. The Company sells its products and maintenance contracts direct to customers and to partners in two distribution channels, or tiers. The first tier consists of a limited number of independent distributors that stock its products and sell primarily to resellers.  The second tier of the distribution channel consists of a non-stocking distributors and value-added resellers that sell directly to end-users.  Products and services may be sold separately or in bundled packages.

[0001564590-17-023316:notes:42]
The Company considers customer purchase orders, which in some cases are governed by master sales agreements, to be the contracts with a customer.  For each contract, the Company considers the promise to transfer products and services, each of which are distinct, to be the identified performance obligations. In determining the transaction price the Company evaluates whether the price is subject to refund or adjustment to determine the net consideration to which the Company expects to be entitled.

[0001564590-17-023316:notes:43]
For all of the Company’s sales and distribution channels, revenue is recognized when control of the product is transferred to the customer (i.e. when the Company’s performance obligation is satisfied), which typically occurs at shipment for product sales. Revenue from maintenance contracts is recognized over time as the Company’s performance obligations are satisfied. This is typically the contractual service period, which range from one to three years.  For product sales to value-added resellers of the Company, non-stocking distributors and end-user customers, the Company generally does not grant return privileges, except for defective products during the warranty period, nor does the Company grant pricing credits.  Sales incentives and other programs that the Company may make available to these customers are considered to be a form of variable consideration and the Company maintains estimated accruals and allowances using the expected value method. There were no material changes in the current period to the estimated transaction price for performance obligations which were satisfied or partially satisfied during previous periods.

[0001564590-17-023316:notes:44]
Sales to stocking distributors are made under terms allowing certain price adjustments and limited rights of return (known as “stock rotation”) of the Company’s products held in their inventory. Revenue from sales to distributors is recognized upon the transfer of control to the distributor.  Frequently, distributors need to sell at a price lower than the contractual distribution price in order to win business, and submit rebate requests for Company pre-approval prior to selling the product through at the discounted price.  At the time the distributor invoices its customer or soon thereafter, the distributor submits a rebate claim to the Company to adjust the distributor’s cost from the contractual price to the pre-approved lower price. After the Company verifies that the claim was pre-approved, a credit memo is issued to the distributor for the rebate claim. In determining the transaction price, the Company considers these rebate adjustments to be variable consideration. Such price adjustments are estimated using the expected value method based on an analysis of actual claims, at the distributor level over a trailing twelve month period of time considered adequate to account for current pricing and business trends. Stock rotation rights grant the distributor the ability to return certain specified amounts of inventory. Stock rotation adjustments are an additional form of variable consideration and are also estimated using the expected value method based on historical return rates. There were no material changes in the current period to the estimated variable consideration for performance obligations which were satisfied or partially satisfied during previous periods.

[0001564590-17-023316:notes:45]
Performance Obligations. A performance obligation is a promise in a contract to transfer a distinct good or service to the customer, and is the unit of account in ASC Topic 606. A contract’s transaction price is allocated to each distinct performance obligation and recognized as revenue when, or as, the performance obligation is satisfied.  Certain of the Company’s contracts have multiple performance obligations, as the promise to transfer individual goods or services is separately identifiable from other promises in the contracts and, therefore, is distinct.  For contracts with multiple performance obligations, the Company allocates the contract’s transaction price to each performance obligation based on its relative standalone selling price.  The stand-alone selling prices are determined based on the prices at which the Company separately sells these products.  For items that are not sold separately, the Company estimates the stand-alone selling prices using the best estimated selling price approach.

[0001564590-17-023316:notes:46]
The Company’s performance obligations are satisfied at a point in time or over time as work progresses.  Substantially all of the Company’s product sales revenues as reflected on the consolidated statements of operations for the three-month periods ended September 30, 2017, and 2016 are recognized at a point in time. Substantially all of the Company’s service revenue is recognized over time.  For revenue recognized over time, the Company uses an input measure, days elapsed, to measure progress.

[0001564590-17-023316:notes:47]
On September 30, 2017, the Company had $119.2 million of remaining performance obligations, which is comprised of deferred maintenance revenue and services not yet delivered.  The Company expects to recognize approximately 70 percent of its remaining performance obligations as revenue in fiscal 2018, an additional 18 percent by fiscal 2019 and the balance thereafter.

[0001564590-17-023316:notes:48]
Contract Balances. The timing of revenue recognition, billings and cash collections results in billed accounts receivable and deferred revenue on the consolidated balance sheet. Services provided under renewable support arrangements of the Company are billed in accordance with agreed-upon contractual terms, which are typically at periodic intervals (e.g., quarterly or annually).  The Company sometimes receives payments from its customers in advance of services being provided, resulting in deferred revenues.  These liabilities are reported on the consolidated balance sheet on a contract-by-contract basis at the end of each reporting period.

[0001564590-17-023316:notes:49]
Revenue recognized for the three month periods ended September 30, 2017 and 2016, that was included in the deferred revenue balance at the beginning of each year was $42.1 million and $37.2 million respectively.

[0001564590-17-023316:notes:50]
Contract Costs.  The Company recognizes the incremental costs of obtaining contracts as an expense when incurred if the amortization period of the assets that the Company otherwise would have recognized is one year or less.  These costs are included in selling and marketing expenses.  Management expects that commission fees paid to sales representative as a result of obtaining service contracts and contract renewals are recoverable and therefore the Company capitalized them as contract costs in the amount of $2.5 million and $2.3 million at September 30, 2017 and 2016, respectively.  Capitalized commission fees are amortized on a straight-line basis over the average period of service contracts of approximately three years, and are included in sales and marketing expenses.  Amortization recognized during the three-month period ended September 30, 2017 and September 30, 2016, was $0.4 million and $0.3 million, respectively.  There was no impairment loss in relation to the costs capitalized.

[0001564590-17-023316:notes:51]
Revenue by Category: The following table sets forth the Company’s revenue disaggregated by sales channel and geographic region based on the billing addresses of our customers (in thousands, unaudited):

[0001564590-17-023316:notes:52]
|  |  | Three Months Ended |  |
|  |  | September 30, 2017 |  |  | September 30, 2016 |  |
|  |  |  |  |  |  |  |  |  |  |  |  | (As adjusted) |  |
|  |  | Distributor |  | Direct |  | Total |  |  | Distributor |  | Direct |  | Total |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  | $ | 42,392 |  | $ | 50,990 |  | $ | 93,382 |  |  | $ | 26,991 |  | $ | 26,829 |  | $ | 53,820 |  |
| Other |  |  | 14,336 |  |  | 6,395 |  |  | 20,731 |  |  |  | 1,393 |  |  | 9,628 |  |  | 11,021 |  |
| Total Americas |  |  | 56,728 |  |  | 57,385 |  |  | 114,113 |  |  |  | 28,384 |  |  | 36,457 |  |  | 64,841 |  |
| EMEA: |  |  | 51,232 |  |  | 27,903 |  |  | 79,135 |  |  |  | 31,299 |  |  | 16,529 |  |  | 47,828 |  |
| APAC: |  |  | 3,264 |  |  | 15,203 |  |  | 18,467 |  |  |  | 1,452 |  |  | 8,483 |  |  | 9,935 |  |
| Total net revenues |  | $ | 111,224 |  | $ | 100,491 |  | $ | 211,715 |  |  | $ | 61,135 |  | $ | 61,469 |  | $ | 122,604 |  |


## us-gaap:NewAccountingPronouncementsAndChangesInAccountingPrinciplesTextBlock

[0001564590-17-023316:notes:53]
| 4. | Recent Accounting Pronouncements |

[0001564590-17-023316:notes:54]
Recently Issued Accounting Pronouncements

[0001564590-17-023316:notes:55]
In August 2017, the Financial Accounting Standards Board (“FASB”) issued Accounting Standards Update (ASU) 2017-12, Derivatives and Hedging (Topic 815) – Targeted Improvements to Accounting for Hedging Activities (“ASU 2017-12”), which is intended to allow companies to better align risk management activities and financial reporting for hedging relationships through changes to both the designation and measurement guidance for qualifying hedging relationships and the presentation of hedge results by expanding and refining hedge accounting for both nonfinancial and financial risk components and aligning the recognition and presentation of the effects of the hedging instrument and the hedged item in the financial statements. The guidance is effective for fiscal years beginning after December 15, 2018. The Company is evaluating the accounting, transition and disclosure requirements of the standard and cannot currently estimate the financial statement impact of adoption. This guidance is effective for the Company beginning with its fiscal year 2020.

[0001564590-17-023316:notes:56]
In May 2017, the FASB issued ASU 2017-09, Compensation—Stock Compensation (Topic 718) - Scope of Modification Accounting (“ASU 2017-09”) which amends the scope of modification accounting for share-based payment arrangements and provides guidance on the types of changes to the terms or conditions of share-based payment awards to which an entity would be required to apply modification accounting under ASC 718. Specifically, an entity would not apply modification accounting if the fair value, vesting conditions, and classification of the awards are the same immediately before and after the modification. The guidance is effective prospectively for fiscal years beginning after December 15, 2017, and interim periods within that reporting period. Early adoption is permitted, including adoption in any interim period. The Company does not expect the adoption of this guidance to have a material effect on our financial statements. This guidance will be effective for the Company beginning with its fiscal year 2019.

[0001564590-17-023316:notes:57]
In January 2016, the FASB issued ASU No. 2016-01, Recognition and Measurement of Financial Assets and Financial Liabilities, which provides guidance for the recognition, measurement, presentation, and disclosure of financial assets and liabilities.  The Company is currently assessing the impact that adopting this new accounting standard will have on its consolidated financial statements and footnote disclosures. This guidance will become effective for the Company beginning with its fiscal year 2019.

[0001564590-17-023316:notes:58]
In February 2016, the FASB issued ASU No. 2016-02 (Topic 842), Leases (“ASU 2016-02”) which requires the identification of arrangements that should be accounted for as leases by lessees. In general, for lease arrangements exceeding a twelve month term, these arrangements must now be recognized as assets and liabilities on the balance sheet of the lessee. Under ASU 2016-02, a right-of-use asset and lease obligation will be recorded for all leases, whether operating or financing, while the statement of operations will reflect lease expense for operating leases and amortization/interest expense for financing leases. The balance sheet amount recorded for existing leases at the date of adoption of ASU 2016-02 must be calculated using the applicable incremental borrowing rate at the date of adoption. In addition, ASU 2016-02 requires the use of the modified retrospective method, which will require adjustment to all comparative periods presented in the consolidated financial statements. The Company is currently assessing the impact that adopting this new accounting standard will have on its consolidated financial statements and footnote disclosures. This guidance will become effective for the Company beginning with its fiscal year 2020.

[0001564590-17-023316:notes:59]
Recently Adopted Accounting Pronouncements

[0001564590-17-023316:notes:60]
In May 2014, the FASB issued ASU 2014-09, Revenue from Contracts with Customers (Topic 606), to clarify the principles of recognizing revenue and create common revenue recognition guidance between U.S. GAAP and International Financial Reporting Standards. Under ASU 2014-09, revenue is recognized when a customer obtains control of promised goods or services and is recognized at an amount that reflects the consideration expected to be received in exchange for such goods or services.  In addition, ASU 2014-09 requires disclosure of the nature, amount, timing, and uncertainty of revenue and cash flows arising from contracts with customers.

[0001564590-17-023316:notes:61]
The Company adopted Topic 606 on July 1, 2017, using the full retrospective method. This adoption primarily affected the Company’s accounting for distributor and resellers revenues from a primarily “sell-through” model, where revenue is recognized upon the sale from the distribution channel to the end customer, to the “sell-in” method where revenue is recognized upon transfer of control to its customers, including distributors. Under the sell-in method, the Company is required to make estimates at the time of shipment to its distributors of variable consideration as well as estimated returns under stock rotation rights granted to the distributors.  Additionally, the Company capitalizes contract acquisition costs such as commissions paid for maintenance services contracts in excess of one year.  Following the adoption of ASU 2014-09, the revenue recognition for the Company’s other sales arrangements remained materially consistent with our historical practice.

[0001564590-17-023316:notes:62]
Upon adoption of Topic 606, we applied the standard’s practical expedients that allows a) an entity to use the transaction price at the date the contract was completed rather than estimating variable consideration amounts in the comparative reporting periods, b) that permits the omission of prior-period information about our performance obligations, and c) that allows the Company to reflect the aggregate effect of all modifications that occur before the beginning of the earliest period presented when identifying the satisfied and unsatisfied performance obligations, determining the transaction price and allocating the transaction price to the satisfied and unsatisfied performance obligations.

[0001564590-17-023316:notes:63]
See the tables at the end of this note for the effects of the adoption of ASU 2014-09 on our condensed consolidated financial statements as of June 30, 2017, and for the three months ended September 30, 2016.  See Note 3. “Summary of Significant Accounting Policies” to our condensed consolidated financial statements for further discussion of the effects of the adoption of ASU 2014-09 on our significant accounting policies.

[0001564590-17-023316:notes:64]
Adjustments to Previously Reported Financial Statements from the Adoption of Accounting Pronouncements

[0001564590-17-023316:notes:65]
The following table presents the effect of the adoption of ASU 2014-09 on our condensed consolidated balance sheet (unaudited) as of June 30, 2017, (in thousands):

[0001564590-17-023316:notes:66]
|  | As of June 30, 2017 |  |
|  | As Reported |  |  | Adjustment |  |  | As Adjusted |  |
| Accounts receivable, net | $ | 120,770 |  |  | $ | (27,655 | ) |  | $ | 93,115 |  |
| Inventories |  | 45,880 |  |  |  | 1,530 |  |  |  | 47,410 |  |
| Total current assets |  | 324,967 |  |  |  | (26,125 | ) |  |  | 298,842 |  |
| Other assets |  | 22,586 |  |  |  | 2,479 |  |  |  | 25,065 |  |
| Total assets |  | 483,346 |  |  |  | (23,646 | ) |  |  | 459,700 |  |
| Accrued warranty |  | 10,007 |  |  |  | 577 |  |  |  | 10,584 |  |
| Other accrued liabilities |  | 36,713 |  |  |  | 331 |  |  |  | 37,044 |  |
| Deferred distributors revenue, net of cost of sales to distributors |  | 43,525 |  |  |  | (43,525 | ) |  |  | — |  |
| Total current liabilities |  | 255,822 |  |  |  | (42,617 | ) |  |  | 213,205 |  |
| Accumulated deficit |  | (800,257 | ) |  |  | 18,971 |  |  |  | (781,286 | ) |
| Total stockholders’ equity |  | 106,707 |  |  |  | 18,971 |  |  |  | 125,678 |  |
| Total liabilities and stockholders’ equity | $ | 483,346 |  |  | $ | (23,646 | ) |  | $ | 459,700 |  |

[0001564590-17-023316:notes:67]
The following table presents the effect of the adoption of ASU 2014-09 on our condensed consolidated statements of operations (unaudited) for the three months ended September 30, 2016 (in thousands, except per share amounts):

[0001564590-17-023316:notes:68]
|  | Three months ended September 30, 2016 |  |
|  | As Reported |  |  | Adjustment |  |  | As Adjusted |  |
| Net revenues |  |  |  |  |  |  |  |  |  |  |  |
| Product | $ | 90,131 |  |  | $ | (38 | ) |  | $ | 90,093 |  |
| Service |  | 32,511 |  |  |  | — |  |  |  | 32,511 |  |
| Total net revenues |  | 122,642 |  |  |  | (38 | ) |  |  | 122,604 |  |
| Cost of revenues |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | 44,927 |  |  |  | (678 | ) |  |  | 44,249 |  |
| Service |  | 12,469 |  |  |  | — |  |  |  | 12,469 |  |
| Total cost of revenues |  | 57,396 |  |  |  | (678 | ) |  |  | 56,718 |  |
| Gross profit |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | 45,204 |  |  |  | 640 |  |  |  | 45,844 |  |
| Service |  | 20,042 |  |  |  | — |  |  |  | 20,042 |  |
| Total Gross profit |  | 65,246 |  |  |  | 640 |  |  |  | 65,886 |  |
| Sales and marketing expenses |  | 36,956 |  |  |  | (97 | ) |  |  | 36,859 |  |
| Operating loss |  | (4,759 | ) |  |  | 737 |  |  |  | (4,022 | ) |
| Net loss before tax |  | (5,572 | ) |  |  | 737 |  |  |  | (4,835 | ) |
| Net loss | $ | (6,479 | ) |  | $ | 737 |  |  | $ | (5,742 | ) |
| Basic and diluted net loss per share |  |  |  |  |  |  |  |  |  |  |  |
| Net loss per share - basic | $ | (0.06 | ) |  |  |  |  |  | $ | (0.05 | ) |
| Net loss per share - diluted | $ | (0.06 | ) |  |  |  |  |  | $ | (0.05 | ) |
| Shares used in per share calculation - basic |  | 105,955 |  |  |  |  |  |  |  | 105,955 |  |
| Shares used in per share calculation - diluted |  | 105,955 |  |  |  |  |  |  |  | 105,955 |  |

[0001564590-17-023316:notes:69]
The following table presents the effect of the adoption of ASU 2014-09 on our condensed consolidated statement of cash flows (unaudited) for the three months ended September 30, 2016 (in thousands):

[0001564590-17-023316:notes:70]
|  | Three months ended September 30, 2016 |  |
|  | As Reported |  |  | Adjustment |  |  | As Adjusted |  |
| Cash flows from operating activities |  |  |  |  |  |  |  |  |  |  |  |
| Net loss | $ | (6,479 | ) |  | $ | 737 |  |  | $ | (5,742 | ) |
| Changes in operating assets and liabilities, net |  |  |  |  |  |  |  |  |  |  |  |
| Accounts receivable |  | 12,950 |  |  |  | 3,656 |  |  |  | 16,606 |  |
| Inventories |  | (2,405 | ) |  |  | (907 | ) |  |  | (3,312 | ) |
| Prepaid and other assets |  | 1,562 |  |  |  | (97 | ) |  |  | 1,465 |  |
| Deferred distributors revenue, net of cost of sales to distributors |  | 3,412 |  |  |  | (3,412 | ) |  |  | — |  |
| Other current and long term liabilities |  | (842 | ) |  |  | 23 |  |  |  | (819 | ) |
| Net cash provided by operating activities |  | 9,574 |  |  |  | — |  |  |  | 9,574 |  |
| Cash flows from investing activities |  | (1,635 | ) |  |  | — |  |  |  | (1,635 | ) |
| Cash flows from financing activities |  | 166 |  |  |  | — |  |  |  | 166 |  |
| Foreign currency effect on cash |  | 38 |  |  |  | — |  |  |  | 38 |  |
| Net increase in cash and cash equivalents | $ | 8,143 |  |  | $ | — |  |  | $ | 8,143 |  |


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001564590-17-023316:notes:71]
[same as prior period, unchanged from 0001564590-17-008860:notes:50]

[0001564590-17-023316:notes:72]
Cash, Cash Equivalents and Short-term Investments

[0001564590-17-023316:notes:73]
The following is a summary of cash, cash equivalents and short-term investments (in thousands):

[0001564590-17-023316:notes:74]
|  |  | September 30, 2017 |  |  | June 30, 2017 |  |
| Cash |  | $ | 148,514 |  |  | $ | 126,159 |  |
| Cash equivalents (consisting of available-sale-securities) |  |  | 4,500 |  |  |  | 4,291 |  |
| Total cash and cash equivalents |  |  | 153,014 |  |  |  | 130,450 |  |
| Short-term investments |  |  | 1,050 |  |  |  | — |  |
| Total cash, cash equivalents and short-term investments |  | $ | 154,064 |  |  | $ | 130,450 |  |

[0001564590-17-023316:notes:75]
The Company considers highly liquid investments with maturities of three months or less at the date of purchase to be cash equivalents. Investments with original maturities greater than three months, but less than one year at the balance sheet date are classified as short-term investments. Short-term investments are recorded in “Prepaid expenses and other current assets” in the accompanying condensed consolidated balance sheets.

[0001564590-17-023316:notes:76]
Inventories

[0001564590-17-023316:notes:77]
The Company values its inventory at lower of cost or net realizable value. Cost is computed using standard cost, which approximates actual cost, on a first-in, first-out basis. The Company has established inventory allowances primarily determined by the demand of inventory or when conditions exist that suggest that inventory may be in excess of anticipated demand or is obsolete based upon assumptions about future demand. At the point of the loss recognition, a new, lower-cost basis for that inventory is established, and subsequent changes in facts and circumstances do not result in the restoration or increase in that newly established cost basis. Any written down or obsolete inventory subsequently sold has not had a material impact on gross margin for any of the periods disclosed.

[0001564590-17-023316:notes:78]
Inventories consist of the following (in thousands):

[0001564590-17-023316:notes:79]
|  |  | September 30, 2017 |  |  | June 30, 2017 |  |
|  |  |  |  |  |  | (As Adjusted) |  |
| Finished goods |  | $ | 57,515 |  |  | $ | 46,620 |  |
| Raw materials |  |  | 585 |  |  |  | 790 |  |
| Total Inventories |  | $ | 58,100 |  |  | $ | 47,410 |  |

[0001564590-17-023316:notes:80]
[same as prior period, unchanged from 0001564590-17-008860:notes:59]

[0001564590-17-023316:notes:81]
[same as prior period, unchanged from 0001564590-17-008860:notes:60]

[0001564590-17-023316:notes:82]
|  |  | September 30, 2017 |  |  | June 30, 2017 |  |
| Computer equipment |  | $ | 40,209 |  |  | $ | 34,716 |  |
| Purchased software |  |  | 12,961 |  |  |  | 11,785 |  |
| Office equipment, furniture and fixtures |  |  | 11,464 |  |  |  | 10,852 |  |
| Leasehold improvements |  |  | 27,167 |  |  |  | 23,046 |  |
| Total property and equipment |  |  | 91,801 |  |  |  | 80,399 |  |
| Less: accumulated depreciation and amortization |  |  | (53,174 | ) |  |  | (50,159 | ) |
| Property and equipment, net |  | $ | 38,627 |  |  | $ | 30,240 |  |

[0001564590-17-023316:notes:83]
[same as prior period, unchanged from 0001564590-17-008860:notes:62]

[0001564590-17-023316:notes:84]
[same as prior period, unchanged from 0001564590-17-008860:notes:63]

[0001564590-17-023316:notes:85]
|  |  | Weighted Average |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Remaining Amortization |  | Gross Carrying |  |  | Accumulated |  |  | Net Carrying |  |
|  |  | Period |  | Amount |  |  | Amortization |  |  | Amount |  |
| September 30, 2017 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Developed technology |  | 5.3 years |  | $ | 91,600 |  |  | $ | 44,395 |  |  | $ | 47,205 |  |
| Customer relationships |  | 2.9 years |  |  | 45,600 |  |  |  | 38,051 |  |  |  | 7,549 |  |
| Maintenance contracts |  | 1.1 years |  |  | 17,000 |  |  |  | 13,317 |  |  |  | 3,683 |  |
| Trademarks |  | 4.7 years |  |  | 7,500 |  |  |  | 3,057 |  |  |  | 4,443 |  |
| Backlogs |  | 0.2 years |  |  | 1,500 |  |  |  | 892 |  |  |  | 608 |  |
| License agreements |  | 6.2 years |  |  | 2,445 |  |  |  | 1,187 |  |  |  | 1,258 |  |
| Other intangibles |  | 2.4 years |  |  | 1,382 |  |  |  | 1,100 |  |  |  | 282 |  |
| Total intangibles, net with finite lives |  |  |  |  | 167,027 |  |  |  | 101,999 |  |  |  | 65,028 |  |
| In-process research and development, with indefinite life |  |  |  |  | 2,300 |  |  |  | — |  |  |  | 2,300 |  |
| Total intangibles, net |  |  |  | $ | 169,327 |  |  | $ | 101,999 |  |  | $ | 67,328 |  |

[0001564590-17-023316:notes:86]
|  |  | Weighted Average |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Remaining Amortization |  | Gross Carrying |  |  | Accumulated |  |  | Net Carrying |  |
|  |  | Period |  | Amount |  |  | Amortization |  |  | Amount |  |
| June 30, 2017 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Developed technology |  | 5.3 years |  | $ | 55,400 |  |  | $ | 42,689 |  |  | $ | 12,711 |  |
| Customer relationships |  | 3.3 years |  |  | 40,300 |  |  |  | 37,567 |  |  |  | 2,733 |  |
| Maintenance contracts |  | 1.3 years |  |  | 17,000 |  |  |  | 12,467 |  |  |  | 4,533 |  |
| Trademarks |  | 4.3 years |  |  | 5,100 |  |  |  | 2,846 |  |  |  | 2,254 |  |
| License agreements |  | 6.4 years |  |  | 2,445 |  |  |  | 1,120 |  |  |  | 1,325 |  |
| Other intangibles |  | 2.7 years |  |  | 1,382 |  |  |  | 1,001 |  |  |  | 381 |  |
| Total intangibles, net with finite lives |  |  |  |  | 121,627 |  |  |  | 97,690 |  |  |  | 23,937 |  |
| In-process research and development, with indefinite life |  |  |  |  | 1,400 |  |  |  | — |  |  |  | 1,400 |  |
| Total intangibles, net |  |  |  | $ | 123,027 |  |  | $ | 97,690 |  |  | $ | 25,337 |  |

[0001564590-17-023316:notes:87]
During the three months ended September 30, 2017, in-process research and development of $1.4 million was reclassified to developed technology upon completion of the project and is being amortized over its estimated useful life.

[0001564590-17-023316:notes:88]
[same as prior period, unchanged from 0001564590-17-008860:notes:66]

[0001564590-17-023316:notes:89]
|  |  | Three Months Ended |  |
|  |  | September 30, 2017 |  |  | September 30, 2016 |  |
| Amortization in “Cost of revenues: Product” |  | $ | 2,695 |  |  | $ | 3,498 |  |
| Amortization of intangibles |  |  | 1,614 |  |  |  | 4,142 |  |
| Total amortization |  | $ | 4,309 |  |  | $ | 7,640 |  |

[0001564590-17-023316:notes:90]
[same as prior period, unchanged from 0001564590-17-008860:notes:68]

[0001564590-17-023316:notes:91]
[same as prior period, unchanged from 0001564590-17-008860:notes:69]

[0001564590-17-023316:notes:92]
[same as prior period, unchanged from 0001564590-17-008860:notes:70]

[0001564590-17-023316:notes:93]
|  |  | September 30, 2017 |  |
| Balance as of June 30, 2017 |  | $ | 80,216 |  |
| Additions due to acquisition |  |  | 38,338 |  |
| Balance at end of period |  | $ | 118,554 |  |

[0001564590-17-023316:notes:94]
During the three months ended September 30, 2017, the Company completed the acquisition of certain assets and liabilities from Avaya resulting in an additional $38.3 million of goodwill.  See Note 2 for additional information related to the acquisition.

[0001564590-17-023316:notes:95]
Deferred Revenue

[0001564590-17-023316:notes:96]
The Company offers for sale to its customers, renewable support arrangements that range from one to five years as well as deferred revenue for professional and training services.

[0001564590-17-023316:notes:97]
[same as prior period, unchanged from 0001564590-17-008860:notes:83]

[0001564590-17-023316:notes:98]
[same as prior period, unchanged from 0001564590-17-008860:notes:84]

[0001564590-17-023316:notes:99]
|  |  | September 30, 2017 |  |  | June 30, 2017 |  |
| Current portion of long-term debt: |  |  |  |  |  |  |  |  |
| Term Loan |  | $ | 18,418 |  |  | $ | 12,444 |  |
| Less: unamortized debt issuance costs |  |  | (555 | ) |  |  | (164 | ) |
| Current portion of long-term debt |  | $ | 17,863 |  |  | $ | 12,280 |  |
| Long-term debt, less current portion: |  |  |  |  |  |  |  |  |
| Term Loan |  | $ | 141,202 |  |  | $ | 71,268 |  |
| Revolver |  |  | 10,000 |  |  |  | 10,000 |  |
| Less: unamortized debt issuance costs |  |  | (1,473 | ) |  |  | (846 | ) |
| Total long-term debt, less current portion |  |  | 149,729 |  |  |  | 80,422 |  |
| Total debt |  | $ | 167,592 |  |  | $ | 92,702 |  |

[0001564590-17-023316:notes:100]
In connection with the closing of Avaya Networking discussed in Note 2, the Company entered into the Second Amendment to the Amended and Restated Credit Agreement (“Second Amendment”), which amended the Amended and Restated Credit Agreement, dated as of October 28, 2016 (the “Credit Facility, as amended”), by and among the Company, as borrower, Silicon Valley Bank, as administrative agent and collateral agent, and lenders. Among other things, the Second Amendment (i) increased the amount of the available borrowing under the Credit Facility from $140.5 million to $243.7 million, composed of (a) the five-year term loan (“Term Loan”) in a principal amount of up to $183.7 million and (b) the five-year revolving credit facility (“Revolver”) in a principal amount of up to $60.0 million, (ii) extends the maturity date under the existing Term Loan and the termination date under the existing Revolver, (iii) provides for an uncommitted additional incremental loan facility in the principal amount of up to $50.0 million (“Incremental Facility”), and (iv) joins certain additional banks, financial institutions and institutional lenders as lenders pursuant to the terms of the Credit Facility, as amended.  On July 14, 2017, the Company borrowed an additional $80.0 million under the Term Loan which was used to fund the purchase of Avaya Networking.

[0001564590-17-023316:notes:101]
[same as prior period, unchanged from 0001564590-17-008860:notes:87]

[0001564590-17-023316:notes:102]
The Company had $0.9 million of outstanding letters of credit and $49.1 million of availability under the Revolver as of September 30, 2017.

[0001564590-17-023316:notes:103]
[same as prior period, unchanged from 0001564590-17-008860:notes:89]

[0001564590-17-023316:notes:104]
[same as prior period, unchanged from 0001564590-17-008860:notes:90]

[0001564590-17-023316:notes:105]
Upon issuance of a standard product warranty, the Company discloses and recognizes a liability for the obligations it assumes under the product warranty. The following table summarizes the activity related to the Company’s product warranty liability during the three months ended September 30, 2017 and 2016 (in thousands):

[0001564590-17-023316:notes:106]
|  |  | Three Months Ended |  |
|  |  | September 30, 2017 |  |  | September 30, 2016 |  |
|  |  |  |  |  |  | (as adjusted) |  |
| Balance beginning of period |  | $ | 10,584 |  |  | $ | 9,998 |  |
| Warranties assumed due to acquisition |  |  | 3,156 |  |  |  | — |  |
| New warranties issued |  |  | 2,272 |  |  |  | 928 |  |
| Warranty expenditures |  |  | (2,513 | ) |  |  | (1,909 | ) |
| Balance end of period |  | $ | 13,499 |  |  | $ | 9,017 |  |

[0001564590-17-023316:notes:107]
[same as prior period, unchanged from 0001564590-17-008860:notes:93]

[0001564590-17-023316:notes:108]
[same as prior period, unchanged from 0001564590-17-008860:notes:94]

[0001564590-17-023316:notes:109]
All advertising costs are expensed as incurred.  Advertising expenses for three months ended September 30, 2017 and 2016, were immaterial.

[0001564590-17-023316:notes:110]
[same as prior period, unchanged from 0001564590-17-008860:notes:96]

[0001564590-17-023316:notes:111]
[same as prior period, unchanged from 0001564590-17-008860:notes:97]

[0001564590-17-023316:notes:112]
[same as prior period, unchanged from 0001564590-17-008860:notes:98]

[0001564590-17-023316:notes:113]
[same as prior period, unchanged from 0001564590-17-008860:notes:99]

[0001564590-17-023316:notes:114]
|  |  | Three Months Ended |  |
|  |  | September 30, 2017 |  |  | September 30, 2016 |  |
|  |  |  |  |  |  | (As adjusted) |  |
| Westcon Group Inc. |  |  | 15% |  |  |  | 11% |  |
| Jenne Corporation |  |  | 14% |  |  |  | 16% |  |
| Tech Data Corporation |  |  | 11% |  |  |  | 17% |  |

[0001564590-17-023316:notes:115]
The following customers account for more than 10% of the Company’s accounts receivable outstanding as of September 30, 2017, Jenne Corporation 17%, Westcon Group 15% and Tech Data 13%.


## us-gaap:FairValueDisclosuresTextBlock

[0001564590-17-023316:notes:116]
[same as prior period, unchanged from 0001564590-17-008860:notes:102]

[0001564590-17-023316:notes:117]
[same as prior period, unchanged from 0001564590-17-008860:notes:103]

[0001564590-17-023316:notes:118]
[same as prior period, unchanged from 0001564590-17-008860:notes:104]

[0001564590-17-023316:notes:119]
[same as prior period, unchanged from 0001564590-17-008860:notes:105]

[0001564590-17-023316:notes:120]
[same as prior period, unchanged from 0001564590-17-008860:notes:106]

[0001564590-17-023316:notes:121]
[same as prior period, unchanged from 0001564590-17-008860:notes:107]

[0001564590-17-023316:notes:122]
| September 30, 2017 |  | Level 1 |  |  | Level 2 |  |  | Level 3 |  |  | Total |  |
| Assets |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Investments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 4,500 |  |  | $ | — |  |  | $ | — |  |  | $ | 4,500 |  |
| Marketable securities |  |  | 1,050 |  |  |  | — |  |  |  | — |  |  |  | 1,050 |  |
| Total assets measured at fair value |  | $ | 5,550 |  |  | $ | — |  |  | $ | — |  |  | $ | 5,550 |  |

[0001564590-17-023316:notes:123]
| June 30, 2017 |  | Level 1 |  |  | Level 2 |  |  | Level 3 |  |  | Total |  |
| Assets |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Investments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 4,291 |  |  | $ | — |  |  | $ | — |  |  | $ | 4,291 |  |
| Investment in non-marketable equity |  |  | — |  |  |  | — |  |  |  | 3,000 |  |  |  | 3,000 |  |
| Total assets measured at fair value |  | $ | 4,291 |  |  | $ | — |  |  | $ | 3,000 |  |  | $ | 7,291 |  |

[0001564590-17-023316:notes:124]
Level 1 investments:

[0001564590-17-023316:notes:125]
During the first quarter of fiscal 2017, pursuant to the sale of an investment in non-marketable equity securities, the Company received 41,685 shares of a company publicly traded on the London Stock Exchange.  As of September 30, 2017, the shares received have a fair value of $1.0 million. (See below, Level 3 investments)

[0001564590-17-023316:notes:126]
[same as prior period, unchanged from 0001564590-17-008860:notes:110]

[0001564590-17-023316:notes:127]
[same as prior period, unchanged from 0001564590-17-008860:notes:111]

[0001564590-17-023316:notes:128]
The fair value of the borrowings under the Credit Facility, as amended is estimated based on valuations provided by alternative pricing sources supported by observable inputs which is considered Level 2. Due to the short duration until maturity of the credit facility, the fair value approximates the face amount of the Company’s indebtedness of $169.6 million and $93.7 million as of September 30, 2017 and June 30, 2017, respectively. Such amounts are immaterial for all periods presented.

[0001564590-17-023316:notes:129]
Level 3 investments:

[0001564590-17-023316:notes:130]
Certain of the Company’s assets, including intangible assets and goodwill are measured at fair value on a non-recurring basis if impairment is indicated.

[0001564590-17-023316:notes:131]
As of June 30, 2017, the Company reflected its non-marketable equity investment as Level 3 in the fair value hierarchy as it is based on unobservable inputs that market participants would use in pricing this asset due to the absence of recent comparable market transactions and inherent lack of liquidity.  During fiscal 2015, the Company purchased a $3.0 million equity interest in a company that operates in the enterprise software platform industry.  The Company did not enter into any other transactions with the investee during fiscal 2017 or the first quarter of fiscal 2018.   During the three months ended September 30, 2017, the investee was acquired by a third party.  The Company received $6.8 million as consideration for its equity interest in the investee, including $5.4 million in cash and 65,937 shares with a market value of $1.4 million. During the first quarter of fiscal 2018, the Company received $5.8 million of the consideration, consisting of $4.9 million in cash and 41,685 shares with a market value of $0.9 million. The remainder of the consideration consisting of $0.5 million and $0.5 million of cash and shares, respectively, will remain in escrow for a period of 18 months for general representations and warranties. A gain of $3.8 million related to this sale was recorded in “Other income (expense), net” in the accompanying condensed consolidated statements of operations for the quarter ended September 30, 2017. The 41,685 shares received and held as of September 30, 2017 were considered Level 1 investments as these have quoted prices in active markets.

[0001564590-17-023316:notes:132]
There were no transfers of assets or liabilities between Level 2 and Level 3 during the first three months of fiscal year 2018 or 2017. There were no impairments recorded for the first three months of fiscal year 2018 or 2017.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001564590-17-023316:notes:133]
[same as prior period, unchanged from 0001564590-17-008860:notes:115]

[0001564590-17-023316:notes:134]
[same as prior period, unchanged from 0001564590-17-008860:notes:116]

[0001564590-17-023316:notes:135]
[same as prior period, unchanged from 0001564590-17-008860:notes:117]

[0001564590-17-023316:notes:136]
|  |  | September 30, 2017 |  |  | June 30, 2017 |  |
| 2014 Employee Stock Purchase Plan |  |  | 6,517 |  |  |  | 7,785 |  |
| Employee stock options and awards outstanding |  |  | 10,130 |  |  |  | 9,726 |  |
| 2013 Equity Incentive Plan shares available for grant |  |  | 5,353 |  |  |  | 7,629 |  |
| Total shares reserved for issuance |  |  | 22,000 |  |  |  | 25,140 |  |

[0001564590-17-023316:notes:137]
[same as prior period, unchanged from 0001564590-17-008860:notes:119]

[0001564590-17-023316:notes:138]
|  |  | Three Months Ended |  |
|  |  | September 30, 2017 |  |  | September 30, 2016 |  |
| Cost of product revenue |  | $ | 92 |  |  | $ | 68 |  |
| Cost of service revenue |  |  | 133 |  |  |  | 232 |  |
| Research and development |  |  | 1,051 |  |  |  | 1,141 |  |
| Sales and marketing |  |  | 1,643 |  |  |  | 1,062 |  |
| General and administrative |  |  | 1,884 |  |  |  | 972 |  |
| Total share-based compensation expense |  | $ | 4,803 |  |  | $ | 3,475 |  |

[0001564590-17-023316:notes:139]
During the three months ended September 30, 2017 and 2016, the Company did not capitalize any share-based compensation expense in inventory, as the amounts were immaterial.

[0001564590-17-023316:notes:140]
[same as prior period, unchanged from 0001564590-17-008860:notes:122]

[0001564590-17-023316:notes:141]
[same as prior period, unchanged from 0001564590-17-008860:notes:123]

[0001564590-17-023316:notes:142]
The following table summarizes stock award activity for the three months ended September 30, 2017 (in thousands, except grant date fair value):

[0001564590-17-023316:notes:143]
|  |  | Number of Shares |  |  | Weighted- Average Grant Date Fair Value |  |  | Aggregate Fair Market Value |  |
| Non-vested stock awards outstanding at June 30, 2017 |  |  | 6,664 |  |  | $ | 4.66 |  |  | $ | 61,440 |  |
| Granted |  |  | 2,094 |  |  |  | 10.55 |  |  |  |  |  |
| Vested |  |  | (1,223 | ) |  |  | 3.45 |  |  |  |  |  |
| Cancelled |  |  | (118 | ) |  |  | 4.72 |  |  |  |  |  |
| Non-vested stock awards outstanding at September 30, 2017 |  |  | 7,417 |  |  | $ | 6.53 |  |  | $ | 88,195 |  |

[0001564590-17-023316:notes:144]
The following table summarizes stock option activity for the three months ended September 30, 2017 (in thousands, except per share and contractual term):

[0001564590-17-023316:notes:145]
|  |  | Number of Shares |  |  | Weighted-Average Exercise Price Per Share |  |  | Weighted-Average Remaining Contractual Term (years) |  |  | Aggregate Intrinsic Value |  |
| Options outstanding at June 30, 2017 |  |  | 3,062 |  |  | $ | 4.06 |  |  |  | 4.19 |  |  | $ | 15,868 |  |
| Exercised |  |  | (347 | ) |  |  | 4.44 |  |  |  |  |  |  |  |  |  |
| Cancelled |  |  | (2 | ) |  |  | 5.58 |  |  |  |  |  |  |  |  |  |
| Options outstanding at September 30, 2017 |  |  | 2,713 |  |  | $ | 4.01 |  |  |  | 4.10 |  |  | $ | 21,478 |  |
| Vested and expected to vest at September 30, 2017 |  |  | 2,713 |  |  | $ | 4.01 |  |  |  | 4.10 |  |  | $ | 21,478 |  |
| Exercisable at September 30, 2017 |  |  | 2,129 |  |  | $ | 4.33 |  |  |  | 3.40 |  |  | $ | 16,090 |  |

[0001564590-17-023316:notes:146]
The fair value of each stock option grant under the 2013 Plan and 2005 Equity Incentive Plan is estimated on the date of grant using the Black-Scholes-Merton option valuation model with the weighted average assumptions noted in the following table.  The Company uses the Monte-Carlo simulation model to determine the fair value and the derived service period of stock awards with market conditions, on the date of the grant.  The expected term of options granted is derived from historical data on employee exercise and post-vesting employment termination behavior.  The risk-free rate is based upon the estimated life of the option and the U.S. Treasury yield curve in effect at the time of grant. Expected volatility is based on the historical volatility on the Company’s stock.

[0001564590-17-023316:notes:147]
The fair value of each restricted stock units (“RSUs”) grant with performance-based vesting criteria (“PSUs”) under the 2013 Plan is estimated on the date of grant using the Monte-Carlo simulation model to determine the fair value and the derived service period of stock awards with market conditions, on the date of the grant.

[0001564590-17-023316:notes:148]
During the first quarter of fiscal 2018, the Company approved the grant of 1,154,014 stock awards to the Company’s Executive Officers and 939,925 stock awards to other Company employees.  Fifty percent (50%) of the stock awards granted to executives, except the chief executive officer, were in the form of PSUs, with grant date fair values of $10.90, and fifty percent (50%) of the stock awards granted were in the form of service-based RSUs. The Company’s chief executive received sixty percent (60%) of his stock award grant in the form of PSUs, while forty percent (40%) were in the form of RSUs, with a grant date fair value of $10.90.  The RSUs vest from the original grant date as to one-third (1/3) on the one year anniversary and one-twelfth (1/12) each quarter thereafter, subject to continued service to the Company.

[0001564590-17-023316:notes:149]
For the PSUs referenced in the preceding paragraph, they are considered earned once the Company’s combined earnings per share equals or exceeds $0.32 for two consecutive quarters. (“FY18 Performance Threshold”).  Once the FY18 Performance Threshold is satisfied the PSUs shall vest with respect to the number of RSUs that have vested as of the date the FY18 Performance Threshold is satisfied and thereafter shall vest on the same schedule as the RSUs, subject to continued service to the Company.  If the FY18 Performance Threshold is not met by the third anniversary of the grant date the award is canceled.  In addition, the FY18 Performance Threshold shall be deemed satisfied upon the closing of a Change in Control (within the meaning of the Company’s 2013 Equity Incentive Plan) in the event the per share consideration received by the Company’s stockholders equals or exceeds $16.00 per share.

[0001564590-17-023316:notes:150]
During the quarter ended September 30, 2017, none of the PSU grants referenced above achieved their FY18 Performance Threshold.

[0001564590-17-023316:notes:151]
During the first quarter of fiscal 2017, the Company approved the grant of 680,000 stock awards to the Company’s Executive Officers and 1,878,420 stock awards to other Company employees.  Fifty percent (50%) of the stock awards granted were in the form of PSUs, with grant date fair values ranging from $3.02 to $3.09, and fifty percent (50%) of the stock awards granted were in the form of RSUs.   The RSUs vest from the original grant date as to one-third (1/3) on the one year anniversary and one-twelfth (1/12) each quarter thereafter, subject to continued service to the Company.

[0001564590-17-023316:notes:152]
The PSUs were considered earned once the Company’s stock price equaled or exceeded $5.00 per share for 30 consecutive trading days after January 1, 2017 (“FY17 Performance Threshold”).  Once the FY17 Performance Threshold goal was attainted the PSUs began to vest on the same schedule as the RSUs that were granted at the same time, subject to continued service to the Company.

[0001564590-17-023316:notes:153]
During the quarter ended March 31, 2017, all of the PSU grants referenced above achieved their FY17 Performance Threshold and as such, began vesting and will be released on the schedule as noted, subject to continued service to the Company.

[0001564590-17-023316:notes:154]
The fair value of each share purchase option under the Company’s Employee Stock Purchase Plan (“ESPP”) is estimated on the date of grant using the Black-Scholes-Merton option valuation model with the weighted average assumptions noted in the following table.  The expected term of the ESPP represents the term of the offering period of each option.  The risk-free rate is based upon the estimated life and on the U.S. Treasury yield curve in effect at the time of grant.  Expected volatility is based on the historical volatility on the Company’s stock.

[0001564590-17-023316:notes:155]
The weighted-average fair value of shares granted under the Company’s 2014 ESPP during the three months ended September 30, 2017 and 2016, was $2.41 and $1.00, respectively.  There were 1,267,930 and 1,103,599 shares issued under the Company’s 2014 ESPP during the three months ended September 30, 2017 and 2016, respectively.

[0001564590-17-023316:notes:156]
|  |  | Employee Stock Purchase Plan |  |
|  |  | Three Months Ended |  |
|  |  | September 30, 2017 |  |  | September 30, 2016 |  |
| Expected life |  | 0.50 years |  |  | 0.50 years |  |
| Risk-free interest rate |  |  | 1.15 | % |  |  | 0.40 | % |
| Volatility |  |  | 42 | % |  |  | 40 | % |
| Dividend yield |  |  | — | % |  |  | — | % |


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001564590-17-023316:notes:157]
[same as prior period, unchanged from 0001564590-17-008860:notes:137]

[0001564590-17-023316:notes:158]
No restructuring charges were recorded during the three months ended September 30, 2017 or 2016.

[0001564590-17-023316:notes:159]
Restructuring liabilities consisted of obligations pertaining to the estimated future obligations for non-cancelable lease payments, as well as severance and benefits obligations. The restructuring liabilities are recorded in “Other accrued liabilities” and “Other long-term liabilities” in the accompanying condensed consolidated balance sheets.

[0001564590-17-023316:notes:160]
In fiscal 2017, the Company announced a reduction-in-force.  The Company recorded $5.6 million in severance and benefits charges, net during the year ended June 30, 2017.  Cash payments of $0.6 million were paid during the first three months of fiscal 2018. The balance of cash payments are expected to be paid by the end of the second quarter of fiscal 2018.  The excess facilities payments will continue through fiscal year 2023.

[0001564590-17-023316:notes:161]
During fiscal 2016, the Company realigned its operations by abandoning excess facilities, primarily in San Jose, California; Salem, New Hampshire and Morrisville, North Carolina.  The fiscal 2016 restructuring was largely completed as of the end of the first quarter of fiscal 2018.

[0001564590-17-023316:notes:162]
Total restructuring and related liabilities consist of (in thousands):

[0001564590-17-023316:notes:163]
|  |  | Three months ended |  |
|  |  | September 30, 2017 |  |  | September 30, 2016 |  |
| Beginning balance |  | $ | 4,122 |  |  | $ | 4,644 |  |
| Period payments |  |  | (562 | ) |  |  | (508 | ) |
| Ending balance |  |  | 3,560 |  |  |  | 4,136 |  |
| Less: current portion included in other accrued liabilities |  |  | 1,877 |  |  |  | 1,754 |  |
| Restructuring accrual included in other long-term liabilities |  | $ | 1,683 |  |  | $ | 2,382 |  |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001564590-17-023316:notes:164]
| 9. | Commitments and Contingencies |

[0001564590-17-023316:notes:165]
Purchase Commitments

[0001564590-17-023316:notes:166]
The Company currently has arrangements with contract manufacturers and suppliers for the manufacture of its products. Those arrangements allow the contract manufactures to procure long lead-time component inventory based upon a rolling production forecast provided by the Company. The Company is obligated to purchase long lead-time component inventory that its contract manufacturer procures in accordance with the Company’s forecast, unless the Company gives notice of order cancellation outside of applicable component lead-times. As of September 30, 2017, the Company had non-cancelable commitments to purchase $115.1 million of such inventory.  As of September 30, 2017 the Company had non-cancelable software and maintenance support commitments to purchase $20.3 million of software and support services.

[0001564590-17-023316:notes:167]
Legal Proceedings

[0001564590-17-023316:notes:168]
The Company may from time to time be party to litigation arising in the course of its business, including, without limitation, allegations relating to commercial transactions, business relationships or intellectual property rights. Such claims, even if not meritorious, could result in the expenditure of significant financial and managerial resources. Litigation in general, and intellectual property and securities litigation in particular, can be expensive and disruptive to normal business operations. Moreover, the results of legal proceedings are difficult to predict.

[0001564590-17-023316:notes:169]
In accordance with applicable accounting guidance, the Company records accruals for certain of its outstanding legal proceedings, investigations or claims when it is probable that a liability will be incurred and the amount of loss can be reasonably estimated. The Company evaluates, at least on a quarterly basis, developments in legal proceedings, investigations or claims that could affect the amount of any accrual, as well as any developments that would result in a loss contingency to become both probable and reasonably estimable. When a loss contingency is not both probable and reasonably estimable, the Company does not record a loss accrual.  However, if the loss (or an additional loss in excess of any prior accrual) is at least a reasonable possibility and material, then the Company would disclose an estimate of the possible loss or range of loss, if such estimate can be made, or disclose that an estimate cannot be made. The assessment whether a loss is probable or a reasonable possibility, and whether the loss or a range of loss is estimable, involves a series of complex judgments about future events. Even if a loss is reasonably possible, the Company may not be able to estimate a range of possible loss, particularly where (i) the damages sought are substantial or indeterminate, (ii) the proceedings are in the early stages, or (iii) the matters involve novel or unsettled legal theories or a large number of parties. In such cases, there is considerable uncertainty regarding the ultimate resolution of such matters, including the amount of any possible loss, fine or penalty.  Accordingly, for current proceedings, except as noted below, the Company is currently unable to estimate any reasonably possible loss or range of possible loss.  However, an adverse resolution of one or more of such matters could have a material adverse effect on the Company's results of operations in a particular quarter or fiscal year.

[0001564590-17-023316:notes:170]
Brazilian Tax Assessment Matter

[0001564590-17-023316:notes:171]
On May 28, 2007, the Public Treasury Department of the State of Sao Paolo, Brazil (the “Tax Authority”) assessed our Brazilian subsidiary, Enterasys Networks do Brasil Ltda. (“Enterasys Brasil”), based on an alleged underpayment of taxes.  The Tax Authority also charged interest and penalties with respect to the assessment (collectively, the “ICMS Tax Assessment”).  The Tax Authority denied Enterasys Brasil the use of certain presumed tax credits granted by the State of Espirito Santo, Brazil under the terms of the FUNDAP program for the period from February 2003 to December 2004.  The value of the disallowed presumed tax credits is BRL 3.4 million (US $1.1 million), excluding interest and penalties. As of September 30, 2017, the total amount claimed by the Tax Authority—including accrued interest, penalties, and attorneys’ fees—is BRL 26.6 million (US $8.4 million).  All currency conversions in this Legal Proceedings section are as of September 30, 2017.

[0001564590-17-023316:notes:172]
Unable to resolve the matter at the administrative level, on October 1, 2014, Enterasys Brasil filed a lawsuit in the 11th Public Treasury Court of the Sao Paolo State Court of Justice (Judiciary District of Sao Paolo) to overturn or reduce the ICMS Tax Assessment. As part of this lawsuit, Enterasys Brasil requested a stay of execution, so that no tax foreclosure could be filed and no guarantee would be required until the court issued its final ruling.  On or about October 6, 2014, the court granted a preliminary injunction staying any execution on the assessment, but requiring that Enterasys Brasil deposit the assessed amount with the court.  Enterasys Brasil appealed this ruling and, on or about January 28, 2015, the appellate court ruled that no cash deposit (or guarantee) was required.  In a decision dated August 28, 2017, and published on October 3, 2017, the court determined that Enterasys Brasil’s claim is “well grounded,” but nonetheless validated the assessment and penalty imposed by the Tax Authority.   The court did rule, however, that the Tax Authority was charging an unlawfully high interest rate on the tax assessment and penalty amounts, and ordered the interest rate reduced to the maximum Federal rate. The August 28, 2017 decision, were it to become final, would require Enterasys Brasil to pay a total of BRL 16.6 million (US $5.2 million), including penalties, court costs, attorneys’ fees, and accrued interest as of September 30, 2017.  The Company believes the ICMS Tax Assessment against Enterasys Brasil is without merit, and expects to continue prosecuting vigorously its challenge to the assessment.  Enterasys Brasil has filed a motion for clarification and reconsideration, and, if the motion is denied, expects to appeal.

[0001564590-17-023316:notes:173]
Based on the currently available information, the Company believes the ultimate outcome of the ICMS Tax Assessment litigation will not have a material adverse effect on the Company's financial position or overall results of operations. However, due to the complexities and uncertainty surrounding the judicial process in Brazil and the nature of the claims asserted, there can be no assurance of a favorable outcome for Enterasys Brasil, which recorded an accrual of BRL 9.4 million (US $3.0 million) as of the date the Company acquired Enterasys Networks.

[0001564590-17-023316:notes:174]
The Company made a demand on April 11, 2014 for a defense from, and indemnification by, the former equity holder of Enterasys Networks, Inc. (“Seller”) in connection with the ICMS Tax Assessment. Seller agreed to assume the defense of the ICMS Tax Assessment on May 20, 2014. In addition, through the settlement of an indemnification-related lawsuit with the Seller on June 18, 2015, Seller agreed to continue to defend the Company with respect to the ICMS Tax Assessment and to indemnify the Company for losses related thereto subject to certain conditions. These conditions include the offsetting of foreign income tax benefits realized by the Company in connection with the acquisition of Enterasys.  Based upon current projections of the foreign income tax benefits to be realized, and the potential liability in the event of an adverse final judgment in the ICMS Tax Assessment litigation, the Company does not presently anticipate that any amounts under the indemnification will be due from the Seller in connection with the ICMS Tax Assessment.

[0001564590-17-023316:notes:175]
In re Extreme Networks, Inc. Securities Litigation

[0001564590-17-023316:notes:176]
On October 23 and 29, 2015, putative class action complaints alleging violations of securities laws were filed in the U.S. District Court for the Northern District of California against the Company and three of its former officers (Charles W. Berger, Kenneth B. Arola, and John T. Kurtzweil).  Subsequently, the cases were consolidated (In re Extreme Networks, Inc. Securities Litigation, No. 3:15-CY-04883-BLF).  Plaintiffs allege that defendants violated the securities laws by disseminating materially false and misleading statements and concealing material adverse facts regarding the Company’s financial condition, business operations and growth prospects. Plaintiffs seek unspecified damages on behalf of a purported class of investors who purchased the Company’s common stock from September 12, 2013 through April 9, 2015.  On June 28, 2016, the Court appointed a lead plaintiff.  On September 26, 2016, the lead plaintiff filed a consolidated complaint. On November 10, 2016, defendants filed a motion to dismiss, which the Court granted with leave to amend on April 27, 2017.  On June 2, 2017, the lead plaintiff filed an amended complaint, which, on July 10, 2017, defendants again moved to dismiss.  Defendants’ motion to dismiss currently is scheduled to be heard on December 14, 2017. The Company believes plaintiffs’ claims are without merit and intends to defend them vigorously.

[0001564590-17-023316:notes:177]
On February 18, 2016, a shareholder derivative case was filed in the Superior Court of California, Santa Clara County (Shaffer v. Kispert et al., No. 16 CV 291726).  The complaint names current and former officers and directors as defendants, and seeks recovery on behalf of the Company based on substantially the same allegations as the securities class action litigation described above.  The parties have agreed to stay the case pending further activities in the securities class action litigation, and the court signed a stipulation and order to that effect.

[0001564590-17-023316:notes:178]
XR Communications, LLC d/b/a Vivato Technologies, LLC v. Extreme Networks, Inc.

[0001564590-17-023316:notes:179]
On April 19, 2017, XR Communications, LLC (“XR”) (d/b/a Vivato Technologies) sued the Company in the Central District of California (XR Communications, LLC, dba Vivato Technologies v. Extreme Networks, Inc., No. 2:17-cv-2953-AG).  The operative Second Amended Complaint asserts infringement of U.S. Patent Nos. 7,062,296, 7,729,728, and 6,611,231 based on the Company’s manufacture, use, sale, offer for sale, and/or importation into the United States of certain access points and routers supporting multi-user, multiple-input, multiple-output technology. XR seeks unspecified damages, on-going royalties, pre- and post-judgment interest, and attorneys’ fees (but no injunction).  On July 24, 2017, the Company filed its answer.  In an order entered on October 23, 2017, the court scheduled a claim construction hearing for April 10, 2018, and ordered any trial of this matter to commence no earlier than March 19, 2019.  The Company believes the claims are without merit and intends to defend them vigorously.

[0001564590-17-023316:notes:180]
Indemnification Obligations

[0001564590-17-023316:notes:181]
Subject to certain limitations, the Company may be obligated to indemnify its current and former directors, officers and employees. These obligations arise under the terms of its certificate of incorporation, its bylaws, applicable contracts, and applicable law. The obligation to indemnify, where applicable, generally means that the Company is required to pay or reimburse, and in certain circumstances the Company has paid or reimbursed, the individuals' reasonable legal expenses and possibly damages and other liabilities incurred in connection with certain legal matters. For example, the Company currently is paying or reimbursing legal expenses being incurred by certain current and former officers and directors in connection with the shareholder litigation described above.  The Company also procures Directors and Officers insurance to help cover its defense and/or indemnification costs, although its ability to recover such costs through insurance is uncertain.  While it is not possible to estimate the maximum potential amount that could be owed under these indemnification agreements due to the Company’s limited history with prior indemnification claims, indemnification (including defense) costs could, in the future, have a material adverse effect on the Company’s consolidated financial position, results of operations and cash flows.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001564590-17-023316:notes:182]
[same as prior period, unchanged from 0001564590-17-008860:notes:167]

[0001564590-17-023316:notes:183]
For the three months ended September 30, 2017 and 2016, the Company recorded an income tax provision of $1.7 million and $0.9  million, respectively.

[0001564590-17-023316:notes:184]
The income tax provisions for the three months ended September 30, 2017 and 2016, consisted primarily of taxes on the income of the Company’s foreign subsidiaries as well as tax expense associated with the establishment of a U.S. deferred tax liability for amortizable goodwill resulting from the acquisition of Enterasys Networks, Inc., the WLAN Business and Avaya Networking. The income tax provisions for both fiscal years were calculated based on the actual results of operations for the three months ended September 30, 2017 and 2016, and therefore may not reflect the annual effective tax rate.

[0001564590-17-023316:notes:185]
[same as prior period, unchanged from 0001564590-17-008860:notes:170]

[0001564590-17-023316:notes:186]
The acquisition of Enterasys in October 2013 included a U.S. parent company as well as its wholly-owned domestic and foreign subsidiaries. The Company elected to treat this stock acquisition as an asset purchase by filing the required election forms under IRC Sec 338(h)(10).  Additionally, the Company completed asset purchases of the WLAN Business as well as the Avaya Networking in October 2016 and July 2017, respectively.  The Company has estimated the value of the intangible assets from these transactions and is amortizing the amounts over 15 years for tax purposes.  During the three months ended September 30, 2017 and 2016, the Company deducted $1.6 million and $1.1 million of tax amortization expense respectively, for each period related to capitalized goodwill resulting from these acquisitions. As of September 30, 2017, the Company recorded a deferred tax liability of $6.9 million related to this amortization which is not considered a future source of taxable income in evaluating the need for a valuation allowance against its deferred tax assets.

[0001564590-17-023316:notes:187]
The Company had $19.2 million of unrecognized tax benefits as of September 30, 2017.  The future impact of the unrecognized tax benefit of $19.2 million, if recognized, would result in adjustments to deferred tax assets and corresponding adjustments to the valuation allowance. The Company does not anticipate any events to occur during the next twelve months that would reduce the unrealized tax benefit as currently stated in the Company’s balance sheet.

[0001564590-17-023316:notes:188]
[same as prior period, unchanged from 0001564590-17-008860:notes:173]

[0001564590-17-023316:notes:189]
In general, the Company’s U.S. federal income tax returns are subject to examination by tax authorities for fiscal years 2001 forward due to net operating losses and the Company's state income tax returns are subject to examination for fiscal years 2000 forward due to net operating losses. The Company is currently under examination by the state of North Carolina for the fiscal years ended 2014, 2015 and 2016.


## us-gaap:EarningsPerShareTextBlock

[0001564590-17-023316:notes:190]
| 11. | Net Income (Loss) Per Share |

[0001564590-17-023316:notes:191]
[same as prior period, unchanged from 0001564590-17-008860:notes:176]

[0001564590-17-023316:notes:192]
The following table presents the calculation of net income (loss) per share of basic and diluted (in thousands, except per share data):

[0001564590-17-023316:notes:193]
|  |  | Three Months Ended |  |
|  |  | September 30, 2017 |  |  | September 30, 2016 |  |
|  |  |  |  |  |  | (As adjusted) |  |
| Net income (loss) |  | $ | 4,376 |  |  | $ | (5,742 | ) |
| Weighted-average shares used in per share - basic calculation |  |  | 112,241 |  |  |  | 105,955 |  |
| Effect of potentially dilutive shares: |  |  |  |  |  |  |  |  |
| Options to purchase common stock |  |  | 1,760 |  |  |  | — |  |
| Restricted stock units |  |  | 4,007 |  |  |  | — |  |
| Employee Stock Purchase Plan shares |  |  | 423 |  |  |  | — |  |
| Weighted-average shares used in per share - diluted calculation |  |  | 118,431 |  |  |  | 105,955 |  |
| Net income (loss) per share: |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.04 |  |  | $ | (0.05 | ) |
| Diluted |  | $ | 0.04 |  |  | $ | (0.05 | ) |

[0001564590-17-023316:notes:194]
The following securities were excluded from the computation of net income (loss) per diluted share of common stock for the periods presented as their effect would have been anti-dilutive (in thousands):

[0001564590-17-023316:notes:195]
|  |  | Three Months Ended |  |
|  |  | September 30, 2017 |  |  | September 30, 2016 |  |
| Options to purchase common stock |  |  | — |  |  |  | 3,715 |  |
| Restricted stock units |  |  | 496 |  |  |  | 1,635 |  |
| Employee Stock Purchase Plan shares |  |  | 204 |  |  |  | 201 |  |
| Total shares excluded |  |  | 700 |  |  |  | 5,551 |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001564590-17-023316:notes:196]
| 12. | Foreign Exchange Forward Contracts |

[0001564590-17-023316:notes:197]
The Company uses derivative financial instruments to manage exposures to foreign currency. The Company’s objective for holding derivatives is to use the most effective methods to minimize the impact of these exposures. The Company does not enter into derivatives for speculative or trading purposes. The fair value of the Company’s derivatives in a gain position are recorded in “Prepaid expenses and other current assets” and derivatives in a loss position are recorded in “Other accrued liabilities” in the accompanying condensed consolidated balance sheets. Changes in the fair value of derivatives are recorded in “Other income (expense), net” in the accompanying condensed consolidated statements of operations. The Company enters into foreign exchange forward contracts to mitigate the effect of gains and losses generated by foreign currency transactions related to certain operating expenses and re-measurement of certain assets and liabilities denominated in foreign currencies. These derivatives do not qualify as hedges.

[0001564590-17-023316:notes:198]
As of September 30, 2017, forward foreign currency contracts had a notional principal amount of $9.6 million and an immaterial unrealized loss. These contracts have maturities of less than 60 days. Changes in the fair value of these foreign exchange forward contracts are offset largely by re-measurement of the underlying assets and liabilities. As of September 30, 2016, the Company did not have any derivative instruments outstanding.

[0001564590-17-023316:notes:199]
Foreign currency transactions gains and losses from operations was loss of $0.6 million and $0.2 million for the three months ended September 30, 2017 and 2016, respectively.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001564590-17-023316:notes:200]
[same as prior period, unchanged from 0001564590-17-008860:notes:185]

[0001564590-17-023316:notes:201]
[same as prior period, unchanged from 0001564590-17-008860:notes:186]

[0001564590-17-023316:notes:202]
The Company attributes revenues to geographic regions and channels based on the customer's ship-to location as follows (in thousands):

[0001564590-17-023316:notes:203]
The Company’s long-lived assets are attributed to the geographic regions as follows (in thousands):

[0001564590-17-023316:notes:204]
| Long Lived Assets |  | September 30, 2017 |  |  | June 30, 2017 |  |
|  |  |  |  |  |  | (As adjusted) |  |
| Americas |  | $ | 113,901 |  |  | $ | 67,369 |  |
| EMEA |  |  | 11,412 |  |  |  | 8,998 |  |
| APAC |  |  | 8,166 |  |  |  | 4,275 |  |
| Total long lived assets |  | $ | 133,479 |  |  | $ | 80,642 |  |


## us-gaap:SubsequentEventsTextBlock

[0001564590-17-023316:notes:205]
14.Subsequent Event

[0001564590-17-023316:notes:206]
On October 27, 2017 (the “Brocade Closing Date”), the Company completed its acquisition of Brocade Communication Systems, Inc.’s (“Brocade”) switching, routing and analytics business (“Brocade SRA”), that had been announced on October 3, 2017. Under the terms and subject to the conditions of the Brocade Asset Purchase Agreement (“Brocade Purchase Agreement”), the Company acquired customers, employees, technology and other assets of Brocade SRA, as well as assumed certain contracts and other liabilities of Brocade SRA, for an upfront cash closing payment equal to $23.0 million, plus a deferred payment equal to $20.0 million to be paid $1 million per quarter for 20 quarters following the Brocade Closing Date, plus quarterly earn out payments equal to 50% of profits of Brocade SRA, with certain deductions per the terms of the Brocade Purchase Agreement for the five-year period commencing at the end of our first full fiscal quarter following the Brocade Closing Date. The Company is still evaluating the estimated consideration from the earn out provision.  In conjunction with the acquisition, Extreme paid a fee of $25.0 million to Broadcom, Inc. in October 2017, for the right to acquire the Brocade SRA business.

[0001564590-17-023316:notes:207]
The acquisition will be accounted for using the acquisition method of accounting whereby the acquired assets and liabilities of Brocade SRA will be recorded at their respective fair values and added to those of the Company including an amount for goodwill representing the difference between the acquisition consideration and the fair value of the identifiable net assets. Results of operations of Brocade SRA will be included in the Company’s operations beginning with the Brocade Closing Date, As of the date of filing this Form 10-Q, the initial purchase price allocation has not been prepared as there has not been sufficient time to complete the related activities.

[0001564590-17-023316:notes:208]
On October 26, 2017, the Company entered into the Third Amendment to the Credit Facility (the “Third Amendment”). Among other things, the Third Amendment (i) amends the negative covenant governing dispositions to increase the general dispositions basket for the fiscal year of the Company ending June 30, 2018, and (ii) amends certain definitions and provisions to update certain references to the Brocade Purchase Agreement (as defined above). On the Brocade Closing Date to partially fund the acquisition of the Brocade SRA acquisition, the Company drew $20.0 million on the Term Loan.
