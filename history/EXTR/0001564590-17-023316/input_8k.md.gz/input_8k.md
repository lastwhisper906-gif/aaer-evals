# EXTR 8-K — 0001564590-17-022235 filed 2017-11-07

## item codes, every 8-K on or before 2017-11-09

- 2017-11-07 0001564590-17-022235 — 2.02, 9.01
- 2017-11-03 0001193125-17-332828 — 9.01 — amendment of 0001193125-17-323879
- 2017-10-30 0001193125-17-323879 — 1.01, 2.01, 7.01, 9.01
- 2017-10-03 0001193125-17-302411 — 1.01, 9.01
- 2017-10-03 0001193125-17-301597 — 1.01, 1.02, 7.01, 9.01
- 2017-09-29 0001564590-17-019099 — 9.01 — amendment, the index does not say of what
- 2017-08-14 0001564590-17-017659 — 2.02, 9.01
- 2017-08-02 0001564590-17-014950 — 5.02
- 2017-07-18 0001564590-17-013557 — 1.01, 2.01, 2.03, 9.01
- 2017-06-05 0001564590-17-012126 — 3.03, 9.01
- 2017-05-03 0001564590-17-008378 — 2.02, 9.01
- 2017-03-30 0001193125-17-102344 — 1.01, 9.01
- 2017-03-07 0001193125-17-073306 — 1.01, 9.01
- 2017-02-21 0001193125-17-048182 — 5.02
- 2017-02-01 0001564590-17-000835 — 2.02, 9.01
- 2017-01-06 0001564590-17-000138 — 2.05
- 2016-11-21 0001564590-16-029539 — 5.07
- 2016-11-01 0001564590-16-026732 — 2.02, 9.01
- 2016-10-31 0001193125-16-752557 — 1.01, 2.01, 2.03
- 2016-09-15 0001193125-16-711097 — 1.01, 9.01
- 2016-08-03 0001564590-16-022347 — 2.02, 9.01
- 2016-05-19 0001564590-16-019720 — 5.02, 9.01
- 2016-05-09 0001564590-16-018660 — 3.03, 9.01
- 2016-04-27 0001564590-16-016754 — 2.02, 9.01
- 2016-02-24 0001564590-16-013189 — 8.01
- 2016-02-09 0001564590-16-012469 — 8.01
- 2016-01-28 0001564590-16-012054 — 2.02, 9.01
- 2015-11-17 0001078271-15-000136 — 5.07
- 2015-10-29 0001078271-15-000125 — 2.02, 9.01
- 2015-08-31 0001078271-15-000111 — 8.01, 9.01
- 2015-08-11 0001078271-15-000096 — 5.02
- 2015-08-06 0001078271-15-000093 — 2.02, 9.01
- 2015-06-30 0001078271-15-000089 — 1.01, 9.01
- 2015-05-20 0001078271-15-000077 — 2.05, 9.01
- 2015-05-19 0001078271-15-000075 — 3.03, 9.01
- 2015-05-06 0001078271-15-000050 — 2.02, 9.01
- 2015-05-04 0001078271-15-000048 — 5.02, 9.01
- 2015-04-29 0001078271-15-000038 — 5.02, 9.01
- 2015-04-21 0001078271-15-000034 — 5.02, 9.01
- 2015-04-09 0001078271-15-000032 — 2.02, 5.02, 9.01
- 2015-02-18 0001078271-15-000021 — 8.01
- 2015-02-17 0001078271-15-000019 — 5.02
- 2015-01-28 0001078271-15-000004 — 2.02, 9.01
- 2014-12-18 0001078271-14-000081 — 5.02, 9.01
- 2014-12-17 0001078271-14-000079 — 5.02
- 2014-11-20 0001078271-14-000075 — 1.01, 9.01
- 2014-11-17 0001078271-14-000073 — 5.07
- 2014-10-28 0001078271-14-000062 — 2.02, 9.01
- 2014-10-15 0001078271-14-000060 — 2.02, 9.01
- 2014-10-02 0001078271-14-000057 — 5.02, 9.01
- 2014-08-14 0001078271-14-000047 — 2.02, 9.01
- 2014-07-21 0001078271-14-000042 — 2.02, 9.01
- 2014-05-23 0001078271-14-000036 — 5.02, 9.01
- 2014-05-20 0001078271-14-000034 — 3.03, 9.01
- 2014-05-12 0001078271-14-000030 — 5.02
- 2014-05-08 0001078271-14-000022 — 5.02, 9.01
- 2014-05-07 0001078271-14-000018 — 2.02, 9.01 — amendment, the index does not say of what
- 2014-05-06 0001078271-14-000016 — 2.02, 9.01
- 2014-02-20 0001078271-14-000014 — 5.02, 9.01
- 2014-02-18 0001078271-14-000010 — 5.02
- 2014-02-05 0001078271-14-000006 — 2.02, 9.01
- 2014-01-13 0001104659-14-002030 — 9.01 — amendment of 0001078271-13-000058
- 2013-11-25 0001078271-13-000081 — 5.07
- 2013-11-07 0001078271-13-000064 — 5.02, 9.01
- 2013-11-04 0001078271-13-000060 — 2.02, 9.01
- 2013-11-01 0001078271-13-000058 — 1.01, 2.01, 2.03, 8.01, 9.01
- 2013-10-16 0001078271-13-000056 — 8.01, 9.01
- 2013-09-13 0001078271-13-000052 — 1.01, 8.01, 9.01
- 2013-08-23 0001078271-13-000044 — 5.02, 9.01
- 2013-08-02 0001078271-13-000042 — 5.02
- 2013-07-30 0001078271-13-000039 — 2.02, 9.01
- 2013-07-30 0001078271-13-000037 — 5.02, 9.01
- 2013-06-21 0001078271-13-000032 — 8.01
- 2013-05-01 0001078271-13-000018 — 5.02, 9.01
- 2013-04-30 0001078271-13-000015 — 2.02, 9.01
- 2013-03-01 0001078271-13-000010 — 8.01
- 2013-02-19 0001078271-13-000008 — 5.02
- 2013-01-30 0001078271-13-000004 — 2.02, 9.01
- 2013-01-07 0001078271-13-000002 — 1.01, 2.02, 2.03, 2.05, 9.01
- 2012-12-03 0001078271-12-000094 — 5.02, 5.07, 8.01
- 2012-10-31 0001078271-12-000071 — 2.02, 9.01
- 2012-10-19 0001078271-12-000069 — 1.01, 2.03, 9.01
- 2012-10-16 0001078271-12-000067 — 8.01
- 2012-10-01 0001193125-12-411392 — 5.02, 8.01, 9.01
- 2012-09-24 0001193125-12-401798 — 5.02, 9.01
- 2012-09-21 0001193125-12-399896 — 5.02, 9.01
- 2012-09-18 0001193125-12-394379 — 1.01, 5.02, 9.01
- 2012-09-12 0001193125-12-388591 — 8.01
- 2012-08-27 0001078271-12-000057 — 8.01
- 2012-08-03 0001078271-12-000041 — 7.01, 9.01
- 2012-08-01 0001078271-12-000039 — 2.02, 9.01
- 2012-07-25 0001078271-12-000037 — 8.01
- 2012-05-22 0001078271-12-000033 — 5.02, 9.01
- 2012-05-21 0001078271-12-000030 — 8.01
- 2012-05-09 0001078271-12-000028 — 5.02, 9.01
- 2012-05-02 0001078271-12-000023 — 2.02, 9.01
- 2012-04-30 0001078271-12-000020 — 3.03, 5.07, 9.01
- 2012-04-19 0001078271-12-000012 — 2.02, 5.02, 9.01
- 2012-03-12 0001078271-12-000010 — 5.02, 9.01
- 2012-02-24 0001078271-12-000008 — 8.01
- 2012-02-02 0001078271-12-000004 — 2.02, 9.01
- 2012-01-30 0001078271-12-000002 — 1.01
- 2011-12-01 0001078271-11-000104 — 8.01
- 2011-11-08 0001078271-11-000099 — 8.01
- 2011-11-02 0001078271-11-000094 — 2.02, 9.01
- 2011-10-24 0001078271-11-000089 — 8.01, 9.01
- 2011-10-11 0001078271-11-000085 — 8.01
- 2011-09-29 0001078271-11-000082 — 8.01
- 2011-09-15 0001078271-11-000070 — 5.02, 9.01
- 2011-08-11 0001078271-11-000058 — 8.01
- 2011-08-10 0001078271-11-000055 — 5.02
- 2011-08-08 0001078271-11-000045 — 5.02
- 2011-08-01 0001078271-11-000038 — 2.02, 9.01
- 2011-07-14 0001078271-11-000036 — 2.02, 2.05, 9.01
- 2011-07-12 0001078271-11-000034 — 8.01
- 2011-07-01 0001078271-11-000032 — 5.02
- 2011-06-16 0001078271-11-000030 — 8.01
- 2011-05-06 0001078271-11-000027 — 8.01, 9.01
- 2011-05-04 0001078271-11-000025 — 8.01
- 2011-04-28 0001078271-11-000020 — 2.02, 9.01
- 2011-04-27 0001078271-11-000018 — 3.03, 5.02, 5.03, 9.01
- 2011-04-11 0001078271-11-000016 — 2.02
- 2011-03-31 0001078271-11-000014 — 5.02, 5.03
- 2011-03-15 0001193125-11-066049 — 5.02, 9.01
- 2011-03-01 0001193125-11-052048 — 5.02, 9.01
- 2011-02-10 0001078271-11-000012 — 7.01, 9.01
- 2011-01-31 0001078271-11-000005 — 2.02, 5.02, 5.03, 9.01
- 2010-12-23 0001193125-10-287613 — 8.01
- 2010-12-17 0001193125-10-283495 — 5.03, 5.07, 8.01, 9.01
- 2010-11-10 0001193125-10-255861 — 4.01, 9.01
- 2010-11-01 0001193125-10-242706 — 2.02, 9.01
- 2010-10-14 0001193125-10-229518 — 1.01, 9.01
- 2010-10-06 0001193125-10-224863 — 5.02, 8.01
- 2010-09-29 0001193125-10-219705 — 1.01, 8.01
- 2010-09-08 0001193125-10-206782 — 5.02, 8.01, 9.01
- 2010-08-25 0001193125-10-196951 — 8.01
- 2010-08-09 0001193125-10-182573 — 7.01, 8.01, 9.01
- 2010-08-03 0001193125-10-175255 — 5.02, 8.01, 9.01
- 2010-08-02 0001193125-10-173697 — 2.02, 8.01, 9.01
- 2010-07-30 0001193125-10-172214 — 5.02, 8.01, 9.01
- 2010-07-22 0001193125-10-163896 — 8.01, 9.01
- 2010-07-20 0001193125-10-161832 — 5.02
- 2010-07-12 0001193125-10-157291 — 2.02, 9.01
- 2010-07-01 0001193125-10-152746 — 3.03, 9.01
- 2010-05-10 0001193125-10-114669 — 5.02, 9.01
- 2010-04-26 0001193125-10-093310 — 2.02, 9.01
- 2010-03-19 0001193125-10-061679 — 5.02, 9.01
- 2010-02-16 0001193125-10-032335 — 5.02
- 2010-02-01 0001193125-10-018202 — 2.02, 9.01
- 2010-01-29 0001193125-10-017165 — 5.02
- 2010-01-11 0001193125-10-004099 — 8.01
- 2009-10-26 0001193125-09-213846 — 2.02, 9.01 — amendment of 0001193125-09-213780
- 2009-10-26 0001193125-09-213780 — 2.02, 9.01
- 2009-10-23 0001193125-09-212871 — 2.05, 5.02, 8.01, 9.01
- 2009-10-05 0001193125-09-203522 — 2.02, 9.01
- 2009-08-04 0001193125-09-163799 — 5.02, 9.01
- 2009-07-31 0001193125-09-160772 — 5.02, 9.01
- 2009-07-30 0001193125-09-159578 — 2.02, 9.01
- 2009-07-20 0001193125-09-151500 — 5.02, 9.01
- 2009-07-08 0001193125-09-145840 — 5.02, 9.01
- 2009-05-12 0001193125-09-108340 — 5.02, 9.01
- 2009-04-23 0001193125-09-085849 — 2.02, 9.01
- 2009-03-26 0001193125-09-064502 — 2.05
- 2009-01-28 0001193125-09-013182 — 2.02, 9.01
- 2008-11-06 0001193125-08-227572 — 2.02, 9.01
- 2008-11-03 0001193125-08-222501 — 5.02
- 2008-08-11 0001193125-08-173590 — 5.02
- 2008-08-11 0001193125-08-172587 — 8.01, 9.01
- 2008-08-06 0001193125-08-167934 — 2.02, 9.01
- 2008-08-04 0001193125-08-164673 — 5.02, 9.01
- 2008-05-21 0001193125-08-119640 — 7.01, 9.01
- 2008-04-29 0001193125-08-095270 — 2.02, 9.01
- 2008-03-05 0001193125-08-047893 — 8.01
- 2008-02-19 0001193125-08-033702 — 5.02
- 2008-02-05 0001193125-08-019969 — 5.02
- 2008-01-30 0001193125-08-015378 — 2.02, 9.01
- 2007-12-27 0001193125-07-272178 — 5.03, 9.01
- 2007-10-29 0001193125-07-228368 — 2.02, 9.01
- 2007-10-25 0001193125-07-225906 — 5.02, 9.01
- 2007-10-19 0001193125-07-221578 — 5.02
- 2007-09-26 0001193125-07-207348 — 8.01
- 2007-08-07 0001193125-07-172810 — 2.02, 9.01
- 2007-08-06 0001193125-07-172147 — 5.02, 9.01
- 2007-08-06 0001193125-07-172134 — 3.01
- 2007-07-09 0001193125-07-151467 — 3.01, 9.01
- 2007-06-28 0001193125-07-145519 — 2.02, 9.01
- 2007-06-27 0001193125-07-143262 — 2.05, 3.01, 5.02
- 2007-05-18 0001193125-07-118804 — 3.01, 9.01
- 2007-05-02 0001193125-07-099280 — 2.02, 9.01
- 2007-03-29 0001193125-07-068815 — 5.02, 9.01
- 2007-02-22 0001193125-07-037181 — 3.01, 9.01
- 2007-02-08 0001193125-07-024194 — 5.02
- 2007-01-30 0001193125-07-016428 — 2.02, 9.01
- 2007-01-11 0001193125-07-004825 — 4.02, 9.01
- 2006-11-21 0001193125-06-240068 — 5.02, 9.01
- 2006-11-16 0001193125-06-237262 — 3.01, 9.01
- 2006-11-01 0001193125-06-220707 — 2.02, 9.01
- 2006-10-31 0001193125-06-219237 — 1.01, 1.02, 5.02, 5.03, 8.01, 9.01
- 2006-09-28 0001193125-06-198185 — 3.01, 9.01
- 2006-09-15 0001193125-06-191640 — 7.01, 9.01
- 2006-09-05 0001193125-06-185202 — 5.02, 9.01
- 2006-08-08 0001193125-06-165953 — 1.01, 2.02, 5.02, 9.01
- 2006-07-18 0001193125-06-148526 — 1.01
- 2006-07-10 0001193125-06-143989 — 5.02, 9.01
- 2006-05-16 0001193125-06-113698 — 5.02, 9.01
- 2006-05-01 0001193125-06-094919 — 2.02, 9.01
- 2006-04-26 0001193125-06-089397 — 1.01, 9.01
- 2006-04-07 0001193125-06-075723 — 2.02, 9.01
- 2006-02-13 0001193125-06-029073 — 1.01
- 2006-01-31 0001193125-06-016143 — 1.01
- 2006-01-30 0001193125-06-015165 — 2.02, 9.01
- 2005-12-08 0001193125-05-239157 — 1.01, 1.02, 9.01
- 2005-11-01 0001193125-05-213101 — 2.02, 9.01
- 2005-09-29 0001193125-05-193991 — 1.01, 2.02, 9.01 — amendment of 0001193125-05-162807
- 2005-08-09 0001193125-05-162807 — 1.01, 2.02, 9.01
- 2005-07-14 0001193125-05-142162 — 8.01
- 2005-06-28 0001193125-05-133050 — 1.01, 9.01
- 2005-04-18 0001193125-05-077946 — 2.02, 7.01, 9.01
- 2005-04-14 0001193125-05-076665 — 2.02, 7.01, 9.01
- 2005-01-25 0001193125-05-011466 — 2.02, 9.01
- 2004-12-07 0001193125-04-208693 — 3.01
- 2004-10-26 0001193125-04-178370 — 2.02, 9.01
- 2004-10-04 0001193125-04-166289 — 5.02, 9.01
- 2004-07-28 0001193125-04-126135 — 12, 7
- 2004-05-12 0001193125-04-086287 — 12
- 2004-04-21 0001193125-04-066557 — 12, 7
- 2004-01-22 0001193125-04-007359 — 12, 7
- 2003-12-18 0001193125-03-096351 — 5, 7
- 2003-11-04 0001193125-03-072069 — 5, 7
- 2003-10-24 0001193125-03-066551 — 12, 7
- 2003-07-25 0001193125-03-024087 — 7, 9
- 2003-04-11 0001012870-03-001706 — 7, 9
- 2003-04-08 0001021408-03-005743 — 7, 9
- 2003-01-07 0001012870-03-000039 — 5, 7
- 2002-04-29 0001012870-02-002003 — 5, 7
- 2002-02-20 0001012870-02-000792 — 5, 7
- 2001-12-13 0001012870-01-503160 — 5, 7
- 2001-11-30 0001012870-01-503010 — 5, 7
- 2001-11-02 0001012870-01-502580 — 5
- 2001-10-23 0001021408-01-508589 — 5, 7
- 2001-06-07 0001021408-01-501772 — 5, 7 — amendment of 0001021408-01-500975
- 2001-05-15 0001021408-01-501104 — 5 — amendment of 0001021408-01-500975
- 2001-05-14 0001021408-01-500975 — 5, 7
- 2001-04-06 0001012870-01-500065 — 5, 7

## late-filing notifications on or before 2017-11-09

- 2008-05-12 0001193125-08-111540 — NT 10-Q, for the period ended 2008-03-30
- 2007-05-10 0001193125-07-110075 — NT 10-Q, for the period ended 2007-04-01
- 2007-02-09 0001193125-07-025490 — NT 10-Q, for the period ended 2006-12-31
- 2006-11-13 0001193125-06-232090 — NT 10-Q, for the period ended 2006-10-01
- 2006-09-15 0001193125-06-191838 — NT 10-K, for the period ended 2006-07-02

## item 2.02 — earnings release, exhibit 99.1

[0001564590-17-022235:8k_2_02:1]
EX-99.1
2
extr-ex991_6.htm
EX-99.1

[0001564590-17-022235:8k_2_02:2]
extr-ex991_6.htm

[0001564590-17-022235:8k_2_02:3]
Exhibit 99.1

[0001564590-17-022235:8k_2_02:4]
FOR IMMEDIATE RELEASE

[0001564590-17-022235:8k_2_02:5]
| For more information, contact: |  |  |
| Investor Relations Laurie Little |  | Media Contact Ben Haber |
| 212/481-2050 |  | 617/624-3200 |
| extreme@tpr-ir.com |  | ExtremeUS@racepointglobal.com |

[0001564590-17-022235:8k_2_02:6]
Extreme Networks Reports First Quarter Fiscal Year 2018 Financial Results

[0001564590-17-022235:8k_2_02:7]
SAN JOSE, Calif., November 7, 2017 -- Extreme Networks, Inc. (“Extreme”) (Nasdaq: EXTR) today released financial results for its fiscal first quarter ended September 30, 2017.

[0001564590-17-022235:8k_2_02:8]
First Quarter Results:

[0001564590-17-022235:8k_2_02:9]
|  | • | First quarter revenue was $211.7 million, an increase of 73% year-over-year. |

[0001564590-17-022235:8k_2_02:10]
|  | • | GAAP gross margin for the first fiscal quarter was 53.1% and non-GAAP gross margin was 56.7%. |

[0001564590-17-022235:8k_2_02:11]
|  | • | GAAP operating margin for the first fiscal quarter was 2.1% and non-GAAP operating margin was 10.6%, an increase of 540 and 280 basis points, respectively, year-over-year. |

[0001564590-17-022235:8k_2_02:12]
|  | • | GAAP net income for the first fiscal quarter was $4.4 million, or $0.04 per diluted share. Non-GAAP net income was $18.6 million, or $0.16 per diluted share, an increase of $10.8 million and $0.09, respectively, year-over-year. |

[0001564590-17-022235:8k_2_02:13]
“Our first quarter results exceeded our expectations on both the top and bottom line, making this our tenth consecutive quarter of solid financial performance and a strong start to our fiscal year,” stated Ed Meyercord, President and CEO of Extreme Networks.  “We are especially pleased to report another consecutive quarter of organic growth primarily driven by our enterprise switching solutions and solid wireless performance that was above current industry growth rates. Our continued financial improvement, combined with our accretive acquisitions, continues to drive us toward our goal of greater than 15% operating margins by the end of fiscal 2018.”

[0001564590-17-022235:8k_2_02:14]
“With the completion of the acquisitions of the Avaya and Brocade campus and data center networking businesses, our teams are working hard to ensure a smooth transition for our new customers, partners and employees,” continued Meyercord. “The newly refreshed product and software portfolios we acquired positions us to expand our market share with cross-selling opportunities and increased penetration across our targeted verticals.  We believe our improved position as a Visionary in the 2017 Gartner Magic Quadrant for Wired and Wireless LAN Access Infrastructure compared to the previous year provides further evidence of the innovation and quality of our products and solutions, and supports our strategy of providing, end-to-end, networking solutions for enterprise customers from the access edge to the data center with 100% insourced customer service.”

[0001564590-17-022235:8k_2_02:15]
Recent Key Events:

[0001564590-17-022235:8k_2_02:16]
|  | • | Completed Acquisition of Brocade’s Data Center Business: Extreme announced the closing of its acquisition of Brocade Communications Systems, Inc.’s datacenter switching, routing and analytics business. This acquisition secures Extreme’s position as the third largest player in the enterprise networking market and includes the VDX, MLX, SLX, CES, CER, Workflow Composer, Automation Suites, and certain other data center related products that enhance Extreme’s data center technology portfolio. |

[0001564590-17-022235:8k_2_02:17]
|  | • | Industry Recognition: For the third consecutive year, Extreme has been positioned furthest to the right and this year, is also positioned highest to the top by Gartner, Inc. in the "Visionaries" quadrant of the Gartner Magic Quadrant1 for Wired and Wireless LAN Access Infrastructure. In addition, Extreme is rated in Gartner’s Peer Insights among 21 vendors in the Data Center Hardware Networking category. As of October 31, 2017, Extreme has an overall rating of 4.8 out of 5 based on 65 customer reviews. |

[0001564590-17-022235:8k_2_02:18]
|  | • | First Product Announcement Integrating Avaya’s Networking Technology: To address the time constraints and resources spent on managing complex networks, Extreme introduced its Secure Automated Campus™, a cost-effective alternative to outdated traditional networking solutions that delivers plug-and-play simplicity and true business agility. The solution combines Avaya's field-proven Fabric Connect infrastructure, Extreme's industry-leading Extreme Management Center ™ and Extreme's top-ranked support services to eliminate networking complexity, increase security and deliver increased visibility into the network. |

[0001564590-17-022235:8k_2_02:19]
|  | • | Introduced New WiNG Solution for Hospitality Deployments: Extreme announced its ExtremeWireless™ WiNG AP 7612 designed to support the specific needs of the hospitality industry. With the WiNG AP 7612, Extreme offers customers a solution with hotel-grade aesthetics, faster installation and application Quality of Service right at the AP. |

[0001564590-17-022235:8k_2_02:20]
| 1 | Gartner, Inc.: Magic Quadrant for the Wire and Wireless LAN Access Infrastructure, Tim Zimmerman, Christian Canales, Bill Menezes, October 17, 2017 |

[0001564590-17-022235:8k_2_02:21]
| Disclaimer: Gartner does not endorse any vendor, product or service depicted in its research publications, and does not advise technology users to select only those vendors with the highest ratings or other designation. Gartner research publications consist of the opinions of Gartner's research organization and should not be construed as statements of fact. Gartner disclaims all warranties, expressed or implied, with respect to this research, including any warranties of merchantability or fitness for a particular purpose. |  |

[0001564590-17-022235:8k_2_02:22]
| Disclaimer: Gartner Peer Insights reviews constitute the subjective opinions of individual end-users based on their own experiences, and do not represent the views of Gartner or its affiliates. |  |

[0001564590-17-022235:8k_2_02:23]
| Fiscal Q1 2018 Financial Metrics: |  |

[0001564590-17-022235:8k_2_02:24]
| (in millions, except percentages and per share information) |  |

[0001564590-17-022235:8k_2_02:25]
|  |  | Q1 FY'18 |  |  | Q1 FY'17 |  |  | Change |  |
|  |  |  |  |  |  | (As adjusted) |  |  |  |  |  |  |  |  |  |
| GAAP Results of Operations |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 164.8 |  |  | $ | 90.1 |  |  | $ | 74.7 |  |  |  | 83 | % |
| Service |  |  | 46.9 |  |  |  | 32.5 |  |  |  | 14.4 |  |  |  | 44 | % |
| Total Net Revenue |  | $ | 211.7 |  |  | $ | 122.6 |  |  | $ | 89.1 |  |  |  | 73 | % |
| Gross Margin |  |  | 53.1 | % |  |  | 53.7 | % |  | -60bps |  |  |  | (1 | )% |
| Operating Margin |  |  | 2.1 | % |  |  | (3.3 | )% |  | 540bps |  |  |  | 164 | % |
| Net Income (Loss) |  | $ | 4.4 |  |  | $ | (5.7 | ) |  | $ | 10.1 |  |  |  | 177 | % |
| Income (loss) per basic and diluted share |  | $ | 0.04 |  |  | $ | (0.05 | ) |  | $ | 0.09 |  |  |  | 180 | % |
| Non-GAAP Results of Operations |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 164.8 |  |  | $ | 90.1 |  |  | $ | 74.7 |  |  |  | 83 | % |
| Service |  |  | 46.9 |  |  |  | 32.6 |  |  |  | 14.3 |  |  |  | 44 | % |
| Total Net Revenue |  | $ | 211.7 |  |  | $ | 122.7 |  |  | $ | 89.0 |  |  |  | 73 | % |
| Gross Margin |  |  | 56.7 | % |  |  | 56.8 | % |  | -10bps |  |  | NM |  |
| Operating Margin |  |  | 10.6 | % |  |  | 7.8 | % |  | 280bps |  |  |  | 36 | % |
| Net Income |  | $ | 18.6 |  |  | $ | 7.8 |  |  | $ | 10.8 |  |  |  | 139 | % |
| Earnings per diluted share |  | $ | 0.16 |  |  | $ | 0.07 |  |  | $ | 0.09 |  |  |  | 129 | % |

[0001564590-17-022235:8k_2_02:26]
|  | • | With the adoption of new revenue recognition accounting guidance (“ASC 606”) in FY’18, we have adjusted prior periods. The impact of these adjustments are to the balance sheet and income statement, are noted with “as adjusted”. |

[0001564590-17-022235:8k_2_02:27]
|  | • | Cash and investments ended the quarter at $154.1 million, an increase of $22.6 million from the prior quarter and an increase of $50.8 million from the prior year. |

[0001564590-17-022235:8k_2_02:28]
|  | • | Accounts receivable balance ending Q1 was $116.5 million, with days sales outstanding (“DSO”) of 51. |

[0001564590-17-022235:8k_2_02:29]
|  | • | Q1 ending inventory was $58.1 million, an increase of $10.7 million from the prior quarter and an increase of $13.4 million from the prior year. |

[0001564590-17-022235:8k_2_02:30]
Business Outlook:

[0001564590-17-022235:8k_2_02:31]
For its second quarter of fiscal 2018 ending December 31, 2017, the Company is targeting revenue in a range of $236.0 million to $246.0 million.  GAAP gross margin is targeted between 52.5% and 54.1% and non-GAAP gross margin is targeted between 56.9% and 58.4%. Operating expenses are targeted to be between $158.9 million and $162.9 million on a GAAP basis and $117.5 million to $121.5 million on a non-GAAP basis. GAAP earnings are targeted to be between a net loss of $40.2 million to $35.0 million or a loss of $(0.35) to $(0.31) per basic share.  Non-GAAP earnings are targeted in a range of net income of $12.5 million to $17.0 million, or $0.10 to $0.14 per diluted share. The GAAP net loss targets are based on 113.9 million average outstanding shares and non-GAAP net income targets are based on an estimated 119.7 million average outstanding shares.  Included in the GAAP Guidance is a charge of $25.0 million which was paid to Broadcom to allow Extreme to acquire the datacenter assets directly from Brocade.  This $25.0 million was included in the total purchase consideration previously disclosed.

[0001564590-17-022235:8k_2_02:32]
The following table shows the GAAP to non-GAAP reconciliation for Q2 FY’18 guidance:

[0001564590-17-022235:8k_2_02:33]
|  | Gross Margin Rate |  |  | Operating Margin Rate |  |  | Earnings per Share |  |
| GAAP | 52.5% - 54.1% |  |  | (14.8)% - (12.1)% |  |  | $(0.35)-$(0.31) |  |
| Estimated adjustments for: |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of product intangibles |  | 2.1% |  |  |  | 3.7% |  |  | $ | 0.08 |  |
| Stock based compensation |  | 0.3% |  |  |  | 2.3% |  |  | $ | 0.05 |  |
| Amortization of non product intangibles |  | 0.4% |  |  |  | 2.3% |  |  | $ | 0.05 |  |
| Acquisition and integration costs |  | 1.5% |  |  |  | 13.0% |  |  | $ | 0.28 |  |
| Non-GAAP | 56.9% - 58.4% |  |  | 7.2% - 9.0% |  |  | $0.10 - $0.14 |  |

[0001564590-17-022235:8k_2_02:34]
The total of percentage rate changes may not equal the total change in all cases due to rounding.

[0001564590-17-022235:8k_2_02:35]
Conference Call:

[0001564590-17-022235:8k_2_02:36]
Extreme will host a conference call at 4:30 p.m. Eastern (1:30 p.m. Pacific) today to review the first fiscal quarter results as well as the second fiscal quarter 2018 business outlook, including significant factors and assumptions underlying the targets noted above. The conference call will be available to the public through a live audio web broadcast via the Internet at http://investor.extremenetworks.com and a replay of the call will be available on the website through November 7, 2018.  The conference call may also be heard by dialing 1 (877) 303-9826 / or international 1 (224) 357-2194. Supplemental financial information to be discussed during the conference call will be posted in the Investor Relations section of the Company's website www.extremenetworks.com including the non-GAAP reconciliation attached to this press release. The encore recording can be accessed by dialing 1 (855) 859-2056 /or international 1 (404) 537-3406   Conference ID # 98898524.

[0001564590-17-022235:8k_2_02:37]
About Extreme Networks:

[0001564590-17-022235:8k_2_02:38]
Extreme Networks, Inc. (EXTR) delivers software-driven networking solutions that help IT departments everywhere deliver the ultimate business outcome: stronger connections with customers, partners and employees. Wired to wireless, desktop to datacenter, on premise or through the cloud, we go to extreme measures for our customers in more than 80 countries, delivering 100% insourced call-in technical support to organizations large and small, including some of the world’s leading names in business, hospitality, retail, transportation and logistics, education, government, healthcare, and manufacturing. Founded in 1996, Extreme is headquartered in San Jose, California. For more information, visit Extreme's website or call 1-888-257-3000.

[0001564590-17-022235:8k_2_02:39]
Extreme Networks and the Extreme Networks logo, Extreme Management Center, ExtremeWireless, ExtremeWireless WiNG, Extreme Secure Automated Campus, ExtremeControl, ExtremeAnalytics, and ExtremeCloud are either trademarks or registered trademarks of Extreme Networks, Inc. in the United States and/or other countries.

[0001564590-17-022235:8k_2_02:40]
Non-GAAP Financial Measures:

[0001564590-17-022235:8k_2_02:41]
Extreme provides all financial information required in accordance with generally accepted accounting principles (“GAAP”). The Company is providing with this press release non-GAAP gross margins, non-GAAP operating expenses, non-GAAP net income and non-GAAP earnings per share. In preparing non-GAAP information, the Company has excluded, where applicable, the impact of share-based compensation, acquisition and integration costs, purchase accounting adjustments, acquired inventory

[0001564590-17-022235:8k_2_02:42]
adjustments, amortization of acquired intangibles and other income.  The Company believes that excluding these items provides both management and investors with additional insight into its current operations, the trends affecting the Company, the Company's marketplace performance, and the Company's ability to generate cash from operations. Please note the Company's non-GAAP measures may be different than those used by other companies. The additional non-GAAP financial information the Company presents should be considered in conjunction with, and not as a substitute for, the Company's GAAP financial information.

[0001564590-17-022235:8k_2_02:43]
The Company has provided a non-GAAP reconciliation of the results for the periods presented in this release, which are adjusted to exclude certain items as indicated.  These measures should only be used to evaluate the Company's results of operations in conjunction with the corresponding GAAP measures for comparable financial information and understanding of the Company's ongoing performance as a business. Extreme Networks uses both GAAP and non-GAAP measures to evaluate and manage its operations.

[0001564590-17-022235:8k_2_02:44]
Forward Looking Statements:

[0001564590-17-022235:8k_2_02:45]
More information about potential factors that could affect the Company's business and financial results is included in the Company’s filings with the Securities and Exchange Commission, including, without limitation, under the captions: "Management's Discussion and Analysis of Financial Condition and Results of Operations," and "Risk Factors".  Except as required under the U.S. federal securities laws and the rules and regulations of the U.S. Securities and Exchange Commission, Extreme Networks disclaims any obligation to update any forward-looking statements after the date of this release, whether as a result of new information, future events, developments, changes in assumptions or otherwise.

[0001564590-17-022235:8k_2_02:46]
EXTREME NETWORKS, INC.

[0001564590-17-022235:8k_2_02:47]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0001564590-17-022235:8k_2_02:48]
(In thousands)

[0001564590-17-022235:8k_2_02:49]
(Unaudited)

[0001564590-17-022235:8k_2_02:50]
|  |  | September 30, 2017 |  |  | June 30, 2017 |  |
|  |  |  |  |  |  | (As adjusted) |  |
| ASSETS |  |  |  |  |  |  |  |  |
| Current assets: |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 153,014 |  |  | $ | 130,450 |  |
| Accounts receivable, net of allowance for doubtful accounts of $1,685 at September 30, 2017 and $1,190 at June 30, 2017 |  |  | 116,500 |  |  |  | 93,115 |  |
| Inventories |  |  | 58,100 |  |  |  | 47,410 |  |
| Prepaid expenses and other current assets |  |  | 18,237 |  |  |  | 27,867 |  |
| Total current assets |  |  | 345,851 |  |  |  | 298,842 |  |
| Property and equipment, net |  |  | 38,627 |  |  |  | 30,240 |  |
| Intangible assets, net |  |  | 67,328 |  |  |  | 25,337 |  |
| Goodwill |  |  | 118,554 |  |  |  | 80,216 |  |
| Other assets |  |  | 27,524 |  |  |  | 25,065 |  |
| Total assets |  | $ | 597,884 |  |  | $ | 459,700 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |  |  |  |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |  |  |  |
| Current portion of long-term debt |  | $ | 17,863 |  |  | $ | 12,280 |  |
| Accounts payable |  |  | 50,567 |  |  |  | 31,587 |  |
| Accrued compensation and benefits |  |  | 38,810 |  |  |  | 42,662 |  |
| Accrued warranty |  |  | 13,499 |  |  |  | 10,584 |  |
| Deferred revenue, net |  |  | 90,705 |  |  |  | 79,048 |  |
| Other accrued liabilities |  |  | 52,335 |  |  |  | 37,044 |  |
| Total current liabilities |  |  | 263,779 |  |  |  | 213,205 |  |
| Deferred revenue, less current portion |  |  | 28,500 |  |  |  | 25,293 |  |
| Long-term debt, less current portion |  |  | 149,729 |  |  |  | 80,422 |  |
| Deferred income taxes |  |  | 7,204 |  |  |  | 6,576 |  |
| Other long-term liabilities |  |  | 13,235 |  |  |  | 8,526 |  |
| Commitments and contingencies |  |  | - |  |  |  | - |  |
| Stockholders’ equity |  |  | 135,437 |  |  |  | 125,678 |  |
| Total liabilities and stockholders’ equity |  | $ | 597,884 |  |  | $ | 459,700 |  |

[0001564590-17-022235:8k_2_02:51]
EXTREME NETWORKS, INC.

[0001564590-17-022235:8k_2_02:52]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS

[0001564590-17-022235:8k_2_02:53]
(In thousands, except per share amounts)

[0001564590-17-022235:8k_2_02:54]
(Unaudited)

[0001564590-17-022235:8k_2_02:55]
|  |  | Three Months Ended |  |
|  |  | September 30, 2017 |  |  | September 30, 2016 |  |
|  |  |  |  |  |  | (As adjusted) |  |
| Net revenues: |  |  |  |  |  |  |  |  |
| Product |  | $ | 164,774 |  |  | $ | 90,093 |  |
| Service |  |  | 46,941 |  |  |  | 32,511 |  |
| Total net revenues |  |  | 211,715 |  |  |  | 122,604 |  |
| Cost of revenues: |  |  |  |  |  |  |  |  |
| Product |  |  | 80,045 |  |  |  | 44,249 |  |
| Service |  |  | 19,289 |  |  |  | 12,469 |  |
| Total cost of revenues |  |  | 99,334 |  |  |  | 56,718 |  |
| Gross profit: |  |  |  |  |  |  |  |  |
| Product |  |  | 84,729 |  |  |  | 45,844 |  |
| Service |  |  | 27,652 |  |  |  | 20,042 |  |
| Total gross profit |  |  | 112,381 |  |  |  | 65,886 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |
| Research and development |  |  | 34,285 |  |  |  | 18,299 |  |
| Sales and marketing |  |  | 55,561 |  |  |  | 36,859 |  |
| General and administrative |  |  | 12,185 |  |  |  | 8,287 |  |
| Acquisition and integration costs |  |  | 4,244 |  |  |  | 2,321 |  |
| Amortization of intangibles |  |  | 1,614 |  |  |  | 4,142 |  |
| Total operating expenses |  |  | 107,889 |  |  |  | 69,908 |  |
| Operating income (loss) |  |  | 4,492 |  |  |  | (4,022 | ) |
| Interest income |  |  | 647 |  |  |  | 57 |  |
| Interest expense |  |  | (2,215 | ) |  |  | (647 | ) |
| Other income (expense), net |  |  | 3,127 |  |  |  | (223 | ) |
| Income (loss) before income taxes |  |  | 6,051 |  |  |  | (4,835 | ) |
| Provision for income taxes |  |  | 1,675 |  |  |  | 907 |  |
| Net income (loss) |  | $ | 4,376 |  |  | $ | (5,742 | ) |
| Basic and diluted net loss per share: |  |  |  |  |  |  |  |  |
| Net income (loss) per share - basic |  | $ | 0.04 |  |  | $ | (0.05 | ) |
| Net income (loss) per share - diluted |  | $ | 0.04 |  |  | $ | (0.05 | ) |
| Shares used in per share calculation - basic |  |  | 112,241 |  |  |  | 105,955 |  |
| Shares used in per share calculation - diluted |  |  | 118,431 |  |  |  | 105,955 |  |

[0001564590-17-022235:8k_2_02:56]
EXTREME NETWORKS, INC.

[0001564590-17-022235:8k_2_02:57]
CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS

[0001564590-17-022235:8k_2_02:58]
(In thousands)

[0001564590-17-022235:8k_2_02:59]
(Unaudited)

[0001564590-17-022235:8k_2_02:60]
|  |  | Three Months Ended |  |
|  |  | September 30, 2017 |  |  | September 30, 2016 |  |
| Net cash provided by operating activities |  | $ | 18,598 |  |  | $ | 9,574 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |
| Capital expenditures |  |  | (7,421 | ) |  |  | (1,635 | ) |
| Acquisitions |  |  | (68,047 | ) |  |  | - |  |
| Proceeds from sale of equity investment |  |  | 4,922 |  |  |  | - |  |
| Net cash used in investing activities |  |  | (70,546 | ) |  |  | (1,635 | ) |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |
| Borrowings under Term Loan |  |  | 80,000 |  |  |  | - |  |
| Loan fees on borrowings |  |  | (1,494 | ) |  |  |  |  |
| Repayments of debt |  |  | (4,093 | ) |  |  | (3,250 | ) |
| Proceeds from issuance of common stock, net of tax |  |  | 42 |  |  |  | 3,416 |  |
| Net cash provided by financing activities |  |  | 74,455 |  |  |  | 166 |  |
| Foreign currency effect on cash |  |  | 57 |  |  |  | 38 |  |
| Net increase in cash and cash equivalents |  |  | 22,564 |  |  |  | 8,143 |  |
| Cash and cash equivalents at beginning of period |  |  | 130,450 |  |  |  | 94,122 |  |
| Cash and cash equivalents at end of period |  | $ | 153,014 |  |  | $ | 102,265 |  |

[0001564590-17-022235:8k_2_02:61]
Extreme Networks, Inc.

[0001564590-17-022235:8k_2_02:62]
Non-GAAP Measures of Financial Performance

[0001564590-17-022235:8k_2_02:63]
To supplement the Company's consolidated financial statements presented in accordance with generally accepted accounting principles, ("GAAP"), Extreme Networks uses non-GAAP measures of certain components of financial performance.  These non-GAAP measures include non-GAAP net income, non-GAAP earnings per diluted share, non-GAAP gross margin, non-GAAP operating expenses and free cash flow.

[0001564590-17-022235:8k_2_02:64]
Reconciliation to the nearest GAAP measure of all historical non-GAAP measures included in this press release can be found in the tables included with this press release.  In this press release, Extreme Networks also presents its target for non-GAAP expenses, which is expenses less share-based compensation expense, acquisition and integration costs, purchase accounting adjustments, acquired inventory adjustments, amortization of acquired intangibles and other income.

[0001564590-17-022235:8k_2_02:65]
Non-GAAP measures presented in this press release are not in accordance with or alternative measures prepared in accordance with GAAP and may be different from non-GAAP measures used by other companies.  In addition, these non-GAAP measures are not based on any comprehensive set of accounting rules or principles.  Non-GAAP measures have limitations in that they do not reflect all of the amounts associated with Extreme Networks' results of operations as determined in accordance with GAAP.  These non-GAAP measures should only be used to evaluate Extreme Networks' results of operations in conjunction with the corresponding GAAP measures.

[0001564590-17-022235:8k_2_02:66]
Extreme believes these non-GAAP measures when shown in conjunction with the corresponding GAAP measures enhance investors' and management's overall understanding of the Company's current financial performance and the Company's prospects for the future, including cash flows available to pursue opportunities to enhance shareholder value.  In addition, because Extreme Networks has historically reported certain non-GAAP results to investors, the Company believes the inclusion of non-GAAP measures provides consistency in the Company's financial reporting.

[0001564590-17-022235:8k_2_02:67]
For its internal planning process, and as discussed further below, Extreme's management uses financial statements that do not include share-based compensation expense, acquisition and integration costs, purchase accounting adjustments, acquired inventory adjustment, amortization of intangibles and other income.  Extreme’s management also uses non-GAAP measures, in addition to the corresponding GAAP measures, in reviewing the Company's financial results.

[0001564590-17-022235:8k_2_02:68]
As described above, Extreme excludes the following items from one or more of its non-GAAP measures when applicable.

[0001564590-17-022235:8k_2_02:69]
Share-based compensation. This expense consists of expenses for stock options, restricted stock and employee stock purchases through its ESPP.  Extreme Networks excludes share-based compensation expenses from its non-GAAP measures primarily because they are non-cash expenses that the Company does not believe are reflective of ongoing cash requirement related to operating results. Extreme Networks expects to incur share-based compensation expenses in future periods.

[0001564590-17-022235:8k_2_02:70]
Acquisition and integration costs. Acquisition and integration costs consist of legal and professional fees related to the acquisition of a) Zebra Technologies Corporation’s wireless LAN business b) Avaya, Inc.’s networking assets, as well as the fabric-based secure networking solutions and network security solutions business of Avaya, Inc., and c) Brocade’s data center assets; Extreme Networks excludes these expenses since they result from an event that is outside the ordinary course of continuing operations.

[0001564590-17-022235:8k_2_02:71]
Purchase accounting adjustments.  Purchase accounting adjustments relating to deferred revenue consists of adjustments to the carrying value of deferred revenue.  We have recorded adjustments to the assumed deferred revenue to reflect only a fulfillment margin and thereby excluding the profit margin and revenue which would have been incurred had Extreme Networks entered into the service contract post-acquisition.

[0001564590-17-022235:8k_2_02:72]
Acquired inventory adjustments.   Purchase accounting adjustments relating to the mark up of acquired inventory to fair value less disposal costs.

[0001564590-17-022235:8k_2_02:73]
Amortization of acquired intangibles.  Amortization of acquired intangibles includes the monthly amortization expense of acquired intangible assets such as developed technology, customer relationships, trademarks and order backlog.  The amortization of the developed technology intangible is recorded in product cost of goods sold, while the amortization for the other intangibles are recorded in operating expenses.  Extreme Networks excludes these non-cash expenses since they result from an intangible asset and for which the period expense does not impact the operations of the business and are non-cash in nature.

[0001564590-17-022235:8k_2_02:74]
Other income. Other income consists of the gain on the sale of our equity investment in a private company.

[0001564590-17-022235:8k_2_02:75]
In addition to the non-GAAP measures discussed above, Extreme uses free cash flow as a measure of operating performance.  Free cash flow represents operating cash flows less net purchase of property and equipment on a GAAP basis.  Extreme considers free cash flows to be a liquidity measure that provides useful information to management and investors about the amount of cash generated by the business after the purchases of property and equipment, which can then be used to, among other things, invest in Extreme’s business, make strategic acquisitions, and strengthen the balance sheet.  A limitation of the utility of free cash flows as a measure of financial performance is that it does not represent the total increase or decrease in the Company's cash balance for the period.

[0001564590-17-022235:8k_2_02:76]
EXTREME NETWORKS, INC.

[0001564590-17-022235:8k_2_02:77]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS

[0001564590-17-022235:8k_2_02:78]
GAAP TO NON-GAAP RECONCILIATION

[0001564590-17-022235:8k_2_02:79]
(In thousands, except percentages and per share amounts)

[0001564590-17-022235:8k_2_02:80]
(Unaudited)

[0001564590-17-022235:8k_2_02:81]
| Non-GAAP Revenue | Three Months Ended |  |
|  | September 30, 2017 |  |  | September 30, 2016 |  |
|  |  |  |  |  | (As adjusted) |  |
| Revenue - GAAP Basis | $ | 211,715 |  |  | $ | 122,604 |  |
| Adjustments: |  |  |  |  |  |  |  |
| Purchase accounting adjustment |  | - |  |  |  | 133 |  |
| Revenue - Non-GAAP Basis | $ | 211,715 |  |  | $ | 122,737 |  |

[0001564590-17-022235:8k_2_02:82]
| Non-GAAP Gross Margin | Three Months Ended |  |
|  | September 30, 2017 |  |  | September 30, 2016 |  |
|  |  |  |  |  | (As adjusted) |  |
| Gross profit - GAAP Basis | $ | 112,381 |  |  | $ | 65,886 |  |
| Gross margin - GAAP Basis percentage |  | 53.1 | % |  |  | 53.7 | % |
| Adjustments: |  |  |  |  |  |  |  |
| Stock based compensation expense |  | 225 |  |  |  | 300 |  |
| Purchase accounting adjustments |  | - |  |  |  | 133 |  |
| Acquired inventory adjustments |  | 2,938 |  |  |  | - |  |
| Acquisition and integration costs |  | 1,846 |  |  |  | - |  |
| Amortization of intangibles |  | 2,564 |  |  |  | 3,417 |  |
| Total adjustments to GAAP gross profit | $ | 7,573 |  |  | $ | 3,850 |  |
| Gross profit - Non-GAAP | $ | 119,954 |  |  | $ | 69,736 |  |
| Gross margin - Non-GAAP percentage |  | 56.7 | % |  |  | 56.8 | % |

[0001564590-17-022235:8k_2_02:83]
| Non-GAAP Operating Income | Three Months Ended |  |
|  | September 30, 2017 |  |  | September 30, 2016 |  |
|  |  |  |  |  | (As adjusted) |  |
| GAAP operating income (loss) | $ | 4,492 |  |  | $ | (4,022 | ) |
| GAAP operating income (loss) percentage |  | 2.1 | % |  |  | (3.3 | )% |
| Adjustments: |  |  |  |  |  |  |  |
| Stock based compensation expense |  | 4,803 |  |  |  | 3,475 |  |
| Acquisition and integration costs |  | 6,090 |  |  |  | 2,321 |  |
| Acquired inventory adjustments |  | 2,938 |  |  |  | - |  |
| Amortization of intangibles |  | 4,178 |  |  |  | 7,559 |  |
| Purchase accounting adjustments |  | - |  |  |  | 133 |  |
| Executive transition costs |  | - |  |  |  | 34 |  |
| Litigation |  | - |  |  |  | 27 |  |
| Total adjustments to GAAP operating income (loss) | $ | 18,009 |  |  | $ | 13,549 |  |
| Non-GAAP operating income | $ | 22,501 |  |  | $ | 9,527 |  |
| Non-GAAP operating income percentage |  | 10.6 | % |  |  | 7.8 | % |

[0001564590-17-022235:8k_2_02:84]
| Non-GAAP Net Income | Three Months Ended |  |
|  | September 30, 2017 |  |  | September 30, 2016 |  |
|  |  |  |  |  | (As adjusted) |  |
| GAAP net income (loss) | $ | 4,376 |  |  | $ | (5,742 | ) |
| Adjustments: |  |  |  |  |  |  |  |
| Stock based compensation expense |  | 4,803 |  |  |  | 3,475 |  |
| Acquisition and integration costs |  | 6,090 |  |  |  | 2,321 |  |
| Amortization of intangibles |  | 4,178 |  |  |  | 7,559 |  |
| Acquired inventory adjustments |  | 2,938 |  |  |  | - |  |
| Purchase accounting adjustments |  | - |  |  |  | 133 |  |
| Executive transition costs |  | - |  |  |  | 34 |  |
| Litigation |  | - |  |  |  | 27 |  |
| Gain on sale of equity investment |  | (3,757 | ) |  |  | - |  |
| Total adjustments to GAAP net income (loss) | $ | 14,252 |  |  | $ | 13,549 |  |
| Non-GAAP net income | $ | 18,628 |  |  | $ | 7,807 |  |
| Earnings per share |  |  |  |  |  |  |  |
| Non-GAAP net income per share-diluted | $ | 0.16 |  |  | $ | 0.07 |  |
| Shares used in net income per share-diluted |  |  |  |  |  |  |  |
| Non-GAAP shares used |  | 118,431 |  |  |  | 107,275 |  |

[0001564590-17-022235:8k_2_02:85]
| Free Cash Flow | Three Months Ended |  |
|  | September 30, 2017 |  |  | September 30, 2016 |  |
|  |  |  |  |  | (As adjusted) |  |
| Cash flow provided by operations | $ | 18,598 |  |  | $ | 9,574 |  |
| Less: PP&E CapEx spending |  | (7,421 | ) |  | $ | (1,635 | ) |
| Total free cash flow | $ | 11,177 |  |  | $ | 7,939 |  |
