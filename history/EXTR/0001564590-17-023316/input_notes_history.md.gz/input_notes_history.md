# EXTR note change history — 0001564590-17-008860 → 0001564590-17-023316


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2017-11-09):
[0001564590-17-023316:note_history:1]
The Company currently has arrangements with contract manufacturers and suppliers for the manufacture of its products. Those arrangements allow the contract manufactures to procure long lead-time component inventory based upon a rolling production forecast provided by the Company. The Company is obligated to purchase long lead-time component inventory that its contract manufacturer procures in accordance with the Company’s forecast, unless the Company gives notice of order cancellation outside of applicable component lead-times. As of September 30, 2017, the Company had non-cancelable commitments to purchase $115.1 million of such inventory.  As of September 30, 2017 the Company had non-cancelable software and maintenance support commitments to purchase $20.3 million of software and support services.
  (was, 2017-05-04, similarity 0.977):
[0001564590-17-008860:note_history:1]
The Company currently has arrangements with contract manufacturers and suppliers for the manufacture of its products. Those arrangements allow the contract manufactures to procure long lead-time component inventory based upon a rolling production forecast provided by the Company. The Company is obligated to purchase long lead-time component inventory that its contract manufacturer procures in accordance with the Company’s forecast, unless the Company gives notice of order cancellation outside of applicable component lead-times. As of March 31, 2017, the Company had non-cancelable commitments to purchase $88.9 million of such inventory.  As of March 31, 2017 the Company had non-cancelable software and maintenance support commitments to purchase $22.8 of software and support services.

- changed (2017-11-09):
[0001564590-17-023316:note_history:2]
The Company may from time to time be party to litigation arising in the course of its business, including, without limitation, allegations relating to commercial transactions, business relationships or intellectual property rights. Such claims, even if not meritorious, could result in the expenditure of significant financial and managerial resources. Litigation in general, and intellectual property and securities litigation in particular, can be expensive and disruptive to normal business operations. Moreover, the results of legal proceedings are difficult to predict.
  (was, 2017-05-04, similarity 0.9991):
[0001564590-17-008860:note_history:2]
The Company may from time to time be party to litigation arising in the course of its business, including, without limitation, allegations relating to commercial transactions, business relationships or intellectual property rights. Such claims, even if not meritorious, could result in the expenditure of significant financial and managerial resources. Litigation in general and intellectual property and securities litigation in particular, can be expensive and disruptive to normal business operations. Moreover, the results of legal proceedings are difficult to predict.

- changed (2017-11-09):
[0001564590-17-023316:note_history:3]
Brazilian Tax Assessment Matter
  (was, 2017-05-04, similarity 0.9841):
[0001564590-17-008860:note_history:3]
Brazilian Tax Assessment Matters

- added (2017-11-09):
[0001564590-17-023316:note_history:4]
On May 28, 2007, the Public Treasury Department of the State of Sao Paolo, Brazil (the “Tax Authority”) assessed our Brazilian subsidiary, Enterasys Networks do Brasil Ltda. (“Enterasys Brasil”), based on an alleged underpayment of taxes.  The Tax Authority also charged interest and penalties with respect to the assessment (collectively, the “ICMS Tax Assessment”).  The Tax Authority denied Enterasys Brasil the use of certain presumed tax credits granted by the State of Espirito Santo, Brazil under the terms of the FUNDAP program for the period from February 2003 to December 2004.  The value of the disallowed presumed tax credits is BRL 3.4 million (US $1.1 million), excluding interest and penalties. As of September 30, 2017, the total amount claimed by the Tax Authority—including accrued interest, penalties, and attorneys’ fees—is BRL 26.6 million (US $8.4 million).  All currency conversions in this Legal Proceedings section are as of September 30, 2017.

- added (2017-11-09):
[0001564590-17-023316:note_history:5]
Unable to resolve the matter at the administrative level, on October 1, 2014, Enterasys Brasil filed a lawsuit in the 11th Public Treasury Court of the Sao Paolo State Court of Justice (Judiciary District of Sao Paolo) to overturn or reduce the ICMS Tax Assessment. As part of this lawsuit, Enterasys Brasil requested a stay of execution, so that no tax foreclosure could be filed and no guarantee would be required until the court issued its final ruling.  On or about October 6, 2014, the court granted a preliminary injunction staying any execution on the assessment, but requiring that Enterasys Brasil deposit the assessed amount with the court.  Enterasys Brasil appealed this ruling and, on or about January 28, 2015, the appellate court ruled that no cash deposit (or guarantee) was required.  In a decision dated August 28, 2017, and published on October 3, 2017, the court determined that Enterasys Brasil’s claim is “well grounded,” but nonetheless validated the assessment and penalty imposed by the Tax Authority.   The court did rule, however, that the Tax Authority was charging an unlawfully high interest rate on the tax assessment and penalty amounts, and ordered the interest rate reduced to the maximum Federal rate. The August 28, 2017 decision, were it to become final, would require Enterasys Brasil to pay a total of BRL 16.6 million (US $5.2 million), including penalties, court costs, attorneys’ fees, and accrued interest as of September 30, 2017.  The Company believes the ICMS Tax Assessment against Enterasys Brasil is without merit, and expects to continue prosecuting vigorously its challenge to the assessment.  Enterasys Brasil has filed a motion for clarification and reconsideration, and, if the motion is denied, expects to appeal.

- added (2017-11-09):
[0001564590-17-023316:note_history:6]
Based on the currently available information, the Company believes the ultimate outcome of the ICMS Tax Assessment litigation will not have a material adverse effect on the Company's financial position or overall results of operations. However, due to the complexities and uncertainty surrounding the judicial process in Brazil and the nature of the claims asserted, there can be no assurance of a favorable outcome for Enterasys Brasil, which recorded an accrual of BRL 9.4 million (US $3.0 million) as of the date the Company acquired Enterasys Networks.

- added (2017-11-09):
[0001564590-17-023316:note_history:7]
The Company made a demand on April 11, 2014 for a defense from, and indemnification by, the former equity holder of Enterasys Networks, Inc. (“Seller”) in connection with the ICMS Tax Assessment. Seller agreed to assume the defense of the ICMS Tax Assessment on May 20, 2014. In addition, through the settlement of an indemnification-related lawsuit with the Seller on June 18, 2015, Seller agreed to continue to defend the Company with respect to the ICMS Tax Assessment and to indemnify the Company for losses related thereto subject to certain conditions. These conditions include the offsetting of foreign income tax benefits realized by the Company in connection with the acquisition of Enterasys.  Based upon current projections of the foreign income tax benefits to be realized, and the potential liability in the event of an adverse final judgment in the ICMS Tax Assessment litigation, the Company does not presently anticipate that any amounts under the indemnification will be due from the Seller in connection with the ICMS Tax Assessment.

- added (2017-11-09):
[0001564590-17-023316:note_history:8]
On October 23 and 29, 2015, putative class action complaints alleging violations of securities laws were filed in the U.S. District Court for the Northern District of California against the Company and three of its former officers (Charles W. Berger, Kenneth B. Arola, and John T. Kurtzweil).  Subsequently, the cases were consolidated (In re Extreme Networks, Inc. Securities Litigation, No. 3:15-CY-04883-BLF).  Plaintiffs allege that defendants violated the securities laws by disseminating materially false and misleading statements and concealing material adverse facts regarding the Company’s financial condition, business operations and growth prospects. Plaintiffs seek unspecified damages on behalf of a purported class of investors who purchased the Company’s common stock from September 12, 2013 through April 9, 2015.  On June 28, 2016, the Court appointed a lead plaintiff.  On September 26, 2016, the lead plaintiff filed a consolidated complaint. On November 10, 2016, defendants filed a motion to dismiss, which the Court granted with leave to amend on April 27, 2017.  On June 2, 2017, the lead plaintiff filed an amended complaint, which, on July 10, 2017, defendants again moved to dismiss.  Defendants’ motion to dismiss currently is scheduled to be heard on December 14, 2017. The Company believes plaintiffs’ claims are without merit and intends to defend them vigorously.

- added (2017-11-09):
[0001564590-17-023316:note_history:9]
On February 18, 2016, a shareholder derivative case was filed in the Superior Court of California, Santa Clara County (Shaffer v. Kispert et al., No. 16 CV 291726).  The complaint names current and former officers and directors as defendants, and seeks recovery on behalf of the Company based on substantially the same allegations as the securities class action litigation described above.  The parties have agreed to stay the case pending further activities in the securities class action litigation, and the court signed a stipulation and order to that effect.

- added (2017-11-09):
[0001564590-17-023316:note_history:10]
On April 19, 2017, XR Communications, LLC (“XR”) (d/b/a Vivato Technologies) sued the Company in the Central District of California (XR Communications, LLC, dba Vivato Technologies v. Extreme Networks, Inc., No. 2:17-cv-2953-AG).  The operative Second Amended Complaint asserts infringement of U.S. Patent Nos. 7,062,296, 7,729,728, and 6,611,231 based on the Company’s manufacture, use, sale, offer for sale, and/or importation into the United States of certain access points and routers supporting multi-user, multiple-input, multiple-output technology. XR seeks unspecified damages, on-going royalties, pre- and post-judgment interest, and attorneys’ fees (but no injunction).  On July 24, 2017, the Company filed its answer.  In an order entered on October 23, 2017, the court scheduled a claim construction hearing for April 10, 2018, and ordered any trial of this matter to commence no earlier than March 19, 2019.  The Company believes the claims are without merit and intends to defend them vigorously.

- added (2017-11-09):
[0001564590-17-023316:note_history:11]
Subject to certain limitations, the Company may be obligated to indemnify its current and former directors, officers and employees. These obligations arise under the terms of its certificate of incorporation, its bylaws, applicable contracts, and applicable law. The obligation to indemnify, where applicable, generally means that the Company is required to pay or reimburse, and in certain circumstances the Company has paid or reimbursed, the individuals' reasonable legal expenses and possibly damages and other liabilities incurred in connection with certain legal matters. For example, the Company currently is paying or reimbursing legal expenses being incurred by certain current and former officers and directors in connection with the shareholder litigation described above.  The Company also procures Directors and Officers insurance to help cover its defense and/or indemnification costs, although its ability to recover such costs through insurance is uncertain.  While it is not possible to estimate the maximum potential amount that could be owed under these indemnification agreements due to the Company’s limited history with prior indemnification claims, indemnification (including defense) costs could, in the future, have a material adverse effect on the Company’s consolidated financial position, results of operations and cash flows.

- removed (2017-11-09):
[0001564590-17-008860:note_history:12]
Certain Brazilian tax authorities have made tax assessments against our Brazilian subsidiary, Enterasys Networks do Brazil Ltda., based on an alleged underpayment of taxes.  The tax authorities are also seeking interest and penalties with respect to such claims (collectively, the “ICMS Tax Assessments”).  The State of Sao Paolo, Brazil denied Enterasys Networks do Brazil Ltda. the use of certain tax credits granted by the State of Espirito Santo, Brazil under the terms of the FUNDAP program for the tax years of 2002 through 2009. The Company’s application to resolve the ICMS Tax Assessments at the administrative level of the Sao Paolo Tax Department under the amnesty relief program (Reference No 3.056.963-1) was denied in March, 2014, by the Sao Paolo Tax Administration.  All currency conversions in this Legal Proceedings section are as of March 31, 2017.  The value of the ICMS tax credits that were disallowed by the Sao Paolo Tax Administration is BRL 3.4 million (US $1.1 million), plus interest and penalties BRL 18.1 million (US $5.8 million).  Possible court fees are estimated to be BRL 4.2 million (US $1.3 million).  On January 10, 2014, the Company filed a lawsuit to overturn or reduce the ICMS Assessments, which lawsuit remains on-going. As part of this lawsuit, the Company made a request for a stay of execution, so that no tax foreclosure can be filed until a final ruling is made and no guarantee needs to be presented.  On or about October 6, 2014, the preliminary injunction was granted with regard to the stay of execution, and in response to an appeal on the guarantee requirement, the appellate court further ruled on or about January 28, 2015 that no cash deposit (or guarantee) need be made by the Company.

- removed (2017-11-09):
[0001564590-17-008860:note_history:13]
On or about June 18, 2014, the State of San Paolo notified Enterasys Networks do Brazil Ltda. that it intends to audit the records of such entity for tax years 2012 and 2013.  In addition, the Company received a similar notice in December 2015 with respect to an audit by the State of San Paolo of tax years 2011-2014. The audits covered the same or very similar issues as the ICMS Tax Assessments for tax years 2002-2009, however, the Company had changed its ICMS procedures effective May 2009. This audit was recently completed and in March 2017 the Company paid BRL 0.2 million (US $0.1 ) related to the audit.

- removed (2017-11-09):
[0001564590-17-008860:note_history:14]
Based on the currently available information, the Company believes the ultimate outcome of the above assessments will not have a material adverse effect on the Company's financial position or overall results of operations. The Company believes that the ICMS Tax Assessments against our Brazilian subsidiary are without merit and the Company is defending the claims vigorously. While the Company believes there is no legal basis for the alleged liability, due to the complexities and uncertainty surrounding the judicial process in Brazil and the nature of the claims asserted, it is unable to determine the likelihood of an unfavorable outcome against our Brazilian subsidiary and estimate the potential tax liability related to the ICMS Tax Assessments, if any, may be up to BRL 25.3 million (US $8.1 million).  The Company does not expect a final judicial determination for several years.  The Company believes BRL 9.4 million (US $3.0 million) is the best estimate within the range and has recorded an accrual as of the Acquisition Date of Enterasys Networks as such matter relates to the period before the acquisition.

- removed (2017-11-09):
[0001564590-17-008860:note_history:15]
The Company made a demand on April 11, 2014 for a defense from, and indemnification by, the former equity holder of Enterasys Networks (“Seller”) of the ICMS Tax Assessments. Seller agreed to assume the defense of the ICMS Tax Assessments on May 20, 2014. In addition, through the settlement of the Unify Indemnification Suit on June 18, 2015, Seller has agreed to continue to defend the Company with respect to the ICMS Tax Assessments and to indemnify the Company for losses related thereto subject to certain conditions. In addition, the Seller has agreed to indemnify the Company in connection with tax assessments up to a specified cap related to the 2012 and 2013 tax years subject to certain conditions.  These conditions include the offsetting of foreign income tax benefits realized by the Company in the connection with the acquisition of Enterasys.  Based upon current projections of the foreign income tax benefits to be realized, the Company does not anticipate that any amounts under the indemnification will be due from the Seller in connection with either the ICMS Tax Assessments or any potential tax assessments for tax years 2012 and 2013.

- removed (2017-11-09):
[0001564590-17-008860:note_history:16]
On October 23 and 29, 2015, complaints were filed alleging violations of securities laws in the U.S. District Court for the Northern District of California against the Company and three of its former officers (Charles W. Berger, Kenneth B. Arola, and John T. Kurtzweil).  Subsequently, the cases were consolidated.  Plaintiffs allege that defendants violated the securities laws by disseminating materially false and misleading statements and concealing material adverse facts regarding Extreme Networks' current financial condition and growth prospects. Plaintiffs seek damages of an unspecified amount on behalf of a class of investors who purchased the Company's common stock from September 12, 2013 through April 9, 2015.  On June 28, 2016, the court appointed a lead plaintiff.  On September 26, 2016, lead plaintiff filed a consolidated complaint. On November 10, 2016 defendants filed a motion to dismiss the complaint and on April 27, 2017, the case was dismissed by the court, with leave to amend the complaint.  Plaintiffs have until May 29, 2017, if they elect to file an amended complaint.

- removed (2017-11-09):
[0001564590-17-008860:note_history:17]
On February 18, 2016, a shareholder derivative case was filed in the Superior Court of California, Santa Clara County, Shaffer v. Kispert et al., No. 16 CV 291726.  The complaint names current and former officers and members of the Board of Directors as defendants and seeks recovery on behalf of the Company based on substantially the same allegations as the securities class action litigation described above.  The parties have agreed to stay the case pending further activities in the securities class action litigation, and the court signed a stipulation and order to that effect.

- removed (2017-11-09):
[0001564590-17-008860:note_history:18]
Plectrum, LLC v. Extreme Networks, Inc. Patent Infringement Suit

- removed (2017-11-09):
[0001564590-17-008860:note_history:19]
On February 27, 2017, the Company was served with a patent infringement complaint, dated February 2, 2017, and filed by Plectrum LLC in the U.S. District Court for the Eastern District of Texas.  The case is Plectrum LLC v. Extreme Networks, Inc., No. 4:17-cv-0079.  The complaint asserts infringement of U.S. Patent Nos. 5,978,951, 6,205,149, and 6,751,677.  The complaint asserts that the Company infringes based on its manufacture, use, sale, and/or offer for sale of the Company’s S-Series products and Summit Series Switch products.  Plectrum seeks an injunction and damages of an unspecified amount.  The Company has not yet responded to the complaint.

- removed (2017-11-09):
[0001564590-17-008860:note_history:20]
On April 19, 2017, XR Communications, LLC (“XR”) (d/b/a Vivato Technologies, LLC) sued Extreme in the Central District of California.   The complaint asserts infringement of U.S. Patent Nos. 7,062,296; 7,729,728; and 6,611,231. XR seeks damages of an unspecified amount and on-going royalties, but not an injunction. The Company has not yet responded to the complaint.  The Company believes the claims are without merit and intends to vigorously defend the claims.

- removed (2017-11-09):
[0001564590-17-008860:note_history:21]
Subject to certain limitations, the Company may be obligated to indemnify its current and former directors, officers and employees. These obligations arise under the terms of its certificate of incorporation, its bylaws, applicable contracts, and Delaware law. The obligation to indemnify, where applicable, generally means that the Company is required to pay or reimburse, and in certain circumstances the Company has paid or reimbursed, the individuals' reasonable legal expenses and possibly damages and other liabilities incurred in connection with these matters. It is not possible to estimate the maximum potential amount under these indemnification agreements due to the limited history of these claims. The cost to defend the Company and the named individuals could have a material adverse effect on its consolidated financial position, results of operations and cash flows in the future. Recovery of such costs under its director and officers’ insurance coverage is uncertain. As of March 31, 2017, the Company had no outstanding indemnification claims.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2017-11-09):
[0001564590-17-023316:note_history:22]
The unaudited condensed consolidated financial statements reflect all adjustments, consisting only of normal recurring adjustments that, in the opinion of management, are necessary for a fair presentation of the results of operations and cash flows for the interim periods presented and the financial condition of Extreme at September 30, 2017. The results of operations for the three months ended September 30, 2017 are not necessarily indicative of the results that may be expected for fiscal 2018 or any future periods.
  (was, 2017-05-04, similarity 0.6824):
[0001564590-17-008860:note_history:22]
The unaudited condensed consolidated financial statements reflect all adjustments, consisting only of normal recurring adjustments that, in the opinion of management, are necessary for a fair presentation of the results of operations and cash flows for the interim periods presented and the financial condition of Extreme at March 31, 2017  The results of operations for the three and nine months ended March 31, 2017 are not necessarily indicative of the results that may be expected for fiscal 2017 or any future periods.

- added (2017-11-09):
[0001564590-17-023316:note_history:23]
Effective July 1, 2017, the Company adopted the requirements of Accounting Standards Update (“ASU”) No. 2014-09, Revenue from Contracts with Customers. All amounts and disclosures set forth in this Form 10-Q have been updated to comply with the new standards, as indicated by the “as adjusted” footnote.

- changed (2017-11-09):
[0001564590-17-023316:note_history:24]
The Company uses a fiscal calendar year ending on June 30.  All references herein to “fiscal 2018” or “2018” represent the fiscal year ending June 30, 2018.  All references herein to “fiscal 2017” or “2017” represent the fiscal year ending June 30, 2017.
  (was, 2017-05-04, similarity 0.8496):
[0001564590-17-008860:note_history:24]
The Company uses a fiscal calendar year ending on June 30.  All references herein to "fiscal 2017" or "2017" represent the fiscal year ending June 30, 2017.  All references herein to "fiscal 2016" or "2016" represent the fiscal year ending June 30, 2016.


## us-gaap:SignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2017-11-09):
[0001564590-17-023316:note_history:25]
For a description of significant accounting policies, see Note 3, Summary of Significant Accounting Policies, to the consolidated financial statements included in the Company’s Annual Report on Form 10-K for the fiscal year ended June 30, 2017. Except for the following policy, there have been no material changes to the Company’s significant accounting policies since the filing of the Annual Report on Form 10-K.
  (was, 2017-05-04, similarity 0.9951):
[0001564590-17-008860:note_history:25]
For a description of significant accounting policies, see Note 3, Summary of Significant Accounting Policies, to the consolidated financial statements included in the Company's Annual Report on Form 10-K for the fiscal year ended June 30, 2016. Except for the following policy, there have been no material changes to the Company's significant accounting policies since the filing of the Annual Report on Form 10-K.

- added (2017-11-09):
[0001564590-17-023316:note_history:26]
Revenue Recognition

- added (2017-11-09):
[0001564590-17-023316:note_history:27]
The Company accounts for revenue in accordance with ASC Topic 606, Revenue from Contracts with Customers, which the Company adopted on July 1, 2017, using the retrospective method.  The Company derives the majority of its revenue from sales of its networking equipment, with the remaining revenue generated from service fees relating to maintenance contracts, professional services, and training for its products. The Company sells its products and maintenance contracts direct to customers and to partners in two distribution channels, or tiers. The first tier consists of a limited number of independent distributors that stock its products and sell primarily to resellers.  The second tier of the distribution channel consists of a non-stocking distributors and value-added resellers that sell directly to end-users.  Products and services may be sold separately or in bundled packages.

- added (2017-11-09):
[0001564590-17-023316:note_history:28]
The Company considers customer purchase orders, which in some cases are governed by master sales agreements, to be the contracts with a customer.  For each contract, the Company considers the promise to transfer products and services, each of which are distinct, to be the identified performance obligations. In determining the transaction price the Company evaluates whether the price is subject to refund or adjustment to determine the net consideration to which the Company expects to be entitled.

- added (2017-11-09):
[0001564590-17-023316:note_history:29]
For all of the Company’s sales and distribution channels, revenue is recognized when control of the product is transferred to the customer (i.e. when the Company’s performance obligation is satisfied), which typically occurs at shipment for product sales. Revenue from maintenance contracts is recognized over time as the Company’s performance obligations are satisfied. This is typically the contractual service period, which range from one to three years.  For product sales to value-added resellers of the Company, non-stocking distributors and end-user customers, the Company generally does not grant return privileges, except for defective products during the warranty period, nor does the Company grant pricing credits.  Sales incentives and other programs that the Company may make available to these customers are considered to be a form of variable consideration and the Company maintains estimated accruals and allowances using the expected value method. There were no material changes in the current period to the estimated transaction price for performance obligations which were satisfied or partially satisfied during previous periods.

- added (2017-11-09):
[0001564590-17-023316:note_history:30]
Sales to stocking distributors are made under terms allowing certain price adjustments and limited rights of return (known as “stock rotation”) of the Company’s products held in their inventory. Revenue from sales to distributors is recognized upon the transfer of control to the distributor.  Frequently, distributors need to sell at a price lower than the contractual distribution price in order to win business, and submit rebate requests for Company pre-approval prior to selling the product through at the discounted price.  At the time the distributor invoices its customer or soon thereafter, the distributor submits a rebate claim to the Company to adjust the distributor’s cost from the contractual price to the pre-approved lower price. After the Company verifies that the claim was pre-approved, a credit memo is issued to the distributor for the rebate claim. In determining the transaction price, the Company considers these rebate adjustments to be variable consideration. Such price adjustments are estimated using the expected value method based on an analysis of actual claims, at the distributor level over a trailing twelve month period of time considered adequate to account for current pricing and business trends. Stock rotation rights grant the distributor the ability to return certain specified amounts of inventory. Stock rotation adjustments are an additional form of variable consideration and are also estimated using the expected value method based on historical return rates. There were no material changes in the current period to the estimated variable consideration for performance obligations which were satisfied or partially satisfied during previous periods.

- added (2017-11-09):
[0001564590-17-023316:note_history:31]
Performance Obligations. A performance obligation is a promise in a contract to transfer a distinct good or service to the customer, and is the unit of account in ASC Topic 606. A contract’s transaction price is allocated to each distinct performance obligation and recognized as revenue when, or as, the performance obligation is satisfied.  Certain of the Company’s contracts have multiple performance obligations, as the promise to transfer individual goods or services is separately identifiable from other promises in the contracts and, therefore, is distinct.  For contracts with multiple performance obligations, the Company allocates the contract’s transaction price to each performance obligation based on its relative standalone selling price.  The stand-alone selling prices are determined based on the prices at which the Company separately sells these products.  For items that are not sold separately, the Company estimates the stand-alone selling prices using the best estimated selling price approach.

- added (2017-11-09):
[0001564590-17-023316:note_history:32]
The Company’s performance obligations are satisfied at a point in time or over time as work progresses.  Substantially all of the Company’s product sales revenues as reflected on the consolidated statements of operations for the three-month periods ended September 30, 2017, and 2016 are recognized at a point in time. Substantially all of the Company’s service revenue is recognized over time.  For revenue recognized over time, the Company uses an input measure, days elapsed, to measure progress.

- added (2017-11-09):
[0001564590-17-023316:note_history:33]
On September 30, 2017, the Company had $119.2 million of remaining performance obligations, which is comprised of deferred maintenance revenue and services not yet delivered.  The Company expects to recognize approximately 70 percent of its remaining performance obligations as revenue in fiscal 2018, an additional 18 percent by fiscal 2019 and the balance thereafter.

- added (2017-11-09):
[0001564590-17-023316:note_history:34]
Contract Balances. The timing of revenue recognition, billings and cash collections results in billed accounts receivable and deferred revenue on the consolidated balance sheet. Services provided under renewable support arrangements of the Company are billed in accordance with agreed-upon contractual terms, which are typically at periodic intervals (e.g., quarterly or annually).  The Company sometimes receives payments from its customers in advance of services being provided, resulting in deferred revenues.  These liabilities are reported on the consolidated balance sheet on a contract-by-contract basis at the end of each reporting period.

- added (2017-11-09):
[0001564590-17-023316:note_history:35]
Revenue recognized for the three month periods ended September 30, 2017 and 2016, that was included in the deferred revenue balance at the beginning of each year was $42.1 million and $37.2 million respectively.

- added (2017-11-09):
[0001564590-17-023316:note_history:36]
Contract Costs.  The Company recognizes the incremental costs of obtaining contracts as an expense when incurred if the amortization period of the assets that the Company otherwise would have recognized is one year or less.  These costs are included in selling and marketing expenses.  Management expects that commission fees paid to sales representative as a result of obtaining service contracts and contract renewals are recoverable and therefore the Company capitalized them as contract costs in the amount of $2.5 million and $2.3 million at September 30, 2017 and 2016, respectively.  Capitalized commission fees are amortized on a straight-line basis over the average period of service contracts of approximately three years, and are included in sales and marketing expenses.  Amortization recognized during the three-month period ended September 30, 2017 and September 30, 2016, was $0.4 million and $0.3 million, respectively.  There was no impairment loss in relation to the costs capitalized.

- added (2017-11-09):
[0001564590-17-023316:note_history:37]
Revenue by Category: The following table sets forth the Company’s revenue disaggregated by sales channel and geographic region based on the billing addresses of our customers (in thousands, unaudited):

- added (2017-11-09):
[0001564590-17-023316:note_history:38]
|  |  | Three Months Ended |  |
|  |  | September 30, 2017 |  |  | September 30, 2016 |  |
|  |  |  |  |  |  |  |  |  |  |  |  | (As adjusted) |  |
|  |  | Distributor |  | Direct |  | Total |  |  | Distributor |  | Direct |  | Total |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  | $ | 42,392 |  | $ | 50,990 |  | $ | 93,382 |  |  | $ | 26,991 |  | $ | 26,829 |  | $ | 53,820 |  |
| Other |  |  | 14,336 |  |  | 6,395 |  |  | 20,731 |  |  |  | 1,393 |  |  | 9,628 |  |  | 11,021 |  |
| Total Americas |  |  | 56,728 |  |  | 57,385 |  |  | 114,113 |  |  |  | 28,384 |  |  | 36,457 |  |  | 64,841 |  |
| EMEA: |  |  | 51,232 |  |  | 27,903 |  |  | 79,135 |  |  |  | 31,299 |  |  | 16,529 |  |  | 47,828 |  |
| APAC: |  |  | 3,264 |  |  | 15,203 |  |  | 18,467 |  |  |  | 1,452 |  |  | 8,483 |  |  | 9,935 |  |
| Total net revenues |  | $ | 111,224 |  | $ | 100,491 |  | $ | 211,715 |  |  | $ | 61,135 |  | $ | 61,469 |  | $ | 122,604 |  |

- removed (2017-11-09):
[0001564590-17-008860:note_history:39]
Business Combinations

- removed (2017-11-09):
[0001564590-17-008860:note_history:40]
The Company applies the acquisition method of accounting for business combinations. Under this method of accounting, all assets acquired and liabilities assumed are recorded at their respective fair values at the date of the completion of the transaction. Determining the fair value of assets acquired and liabilities assumed requires management’s judgment and often involves the use of significant estimates and assumptions, including assumptions with respect to future cash inflows and outflows, discount rates, intangibles and other asset lives, among other items.  Fair value is defined as the price that would be received to sell an asset or paid to transfer a liability in an orderly transaction between market participants at the measurement date (an exit price). Market participants are assumed to be buyers and sellers in the principal (most advantageous) market for the asset or liability. Additionally, fair value measurements for an asset assume the highest and best use of that asset by market participants. As a result, the Company may have been required to value the acquired assets at fair value measures that do not reflect its intended use of those assets. Use of different estimates and judgments could yield different results. Any excess of the purchase price over the fair value of the net assets acquired is recognized as goodwill.  Although the Company believes the assumptions and estimates it has made are reasonable and appropriate, they are based in part on historical experience and information that may be obtained from the management of the acquired company and are inherently uncertain. Unanticipated events and circumstances may occur that may affect the accuracy or validity of such assumptions, estimates or actual results.  As a result, during the measurement period, which may be up to one year from the acquisition date, the Company may record adjustments to the assets acquired and liabilities assumed with the corresponding offset to goodwill. Upon the conclusion of the measurement period or final determination of the values of assets acquired or liabilities assumed, whichever comes first, any subsequent adjustments are recorded to the Company's consolidated statements of operations.


## us-gaap:DebtPolicyTextBlock (debt) — matched_by: no_prior_note, score: 0.0

- added (2017-11-09):
[0001564590-17-023316:note_history:41]
Debt

- added (2017-11-09):
[0001564590-17-023316:note_history:42]
The Company’s debt is comprised of the following (in thousands):

- added (2017-11-09):
[0001564590-17-023316:note_history:43]
|  |  | September 30, 2017 |  |  | June 30, 2017 |  |
| Current portion of long-term debt: |  |  |  |  |  |  |  |  |
| Term Loan |  | $ | 18,418 |  |  | $ | 12,444 |  |
| Less: unamortized debt issuance costs |  |  | (555 | ) |  |  | (164 | ) |
| Current portion of long-term debt |  | $ | 17,863 |  |  | $ | 12,280 |  |
| Long-term debt, less current portion: |  |  |  |  |  |  |  |  |
| Term Loan |  | $ | 141,202 |  |  | $ | 71,268 |  |
| Revolver |  |  | 10,000 |  |  |  | 10,000 |  |
| Less: unamortized debt issuance costs |  |  | (1,473 | ) |  |  | (846 | ) |
| Total long-term debt, less current portion |  |  | 149,729 |  |  |  | 80,422 |  |
| Total debt |  | $ | 167,592 |  |  | $ | 92,702 |  |

- added (2017-11-09):
[0001564590-17-023316:note_history:44]
In connection with the closing of Avaya Networking discussed in Note 2, the Company entered into the Second Amendment to the Amended and Restated Credit Agreement (“Second Amendment”), which amended the Amended and Restated Credit Agreement, dated as of October 28, 2016 (the “Credit Facility, as amended”), by and among the Company, as borrower, Silicon Valley Bank, as administrative agent and collateral agent, and lenders. Among other things, the Second Amendment (i) increased the amount of the available borrowing under the Credit Facility from $140.5 million to $243.7 million, composed of (a) the five-year term loan (“Term Loan”) in a principal amount of up to $183.7 million and (b) the five-year revolving credit facility (“Revolver”) in a principal amount of up to $60.0 million, (ii) extends the maturity date under the existing Term Loan and the termination date under the existing Revolver, (iii) provides for an uncommitted additional incremental loan facility in the principal amount of up to $50.0 million (“Incremental Facility”), and (iv) joins certain additional banks, financial institutions and institutional lenders as lenders pursuant to the terms of the Credit Facility, as amended.  On July 14, 2017, the Company borrowed an additional $80.0 million under the Term Loan which was used to fund the purchase of Avaya Networking.

- added (2017-11-09):
[0001564590-17-023316:note_history:45]
Borrowings under the Term Loan bear interest, at our option, at a rate equal to either the LIBOR rate (subject to a 0.0% LIBOR floor), plus an applicable margin (currently 3.25% per annum based on a stated consolidated leverage ratio) or the adjusted base rate, plus an applicable margin (currently 1.25% per annum based on the Company’s consolidated leverage ratio).  Borrowings under the Revolver bear interest, at the Company’s option, at a rate equal to either the LIBOR rate (subject to a 0.0% LIBOR floor), plus an applicable margin (currently 3.25% per annum based on a stated consolidated leverage ratio) or the adjusted base rate, plus an applicable margin (currently 1.25% per annum based on a stated consolidated leverage ratio).  The Revolver has a commitment fee payable on the undrawn amount ranging from 0.375% to 0.50% per annum based upon a stated consolidated leverage ratio.

- added (2017-11-09):
[0001564590-17-023316:note_history:46]
The Company had $0.9 million of outstanding letters of credit and $49.1 million of availability under the Revolver as of September 30, 2017.


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2017-11-09):
[0001564590-17-023316:note_history:47]
|  |  | September 30, 2017 |  |  | June 30, 2017 |  |
| Current portion of long-term debt: |  |  |  |  |  |  |  |  |
| Term Loan |  | $ | 18,418 |  |  | $ | 12,444 |  |
| Less: unamortized debt issuance costs |  |  | (555 | ) |  |  | (164 | ) |
| Current portion of long-term debt |  | $ | 17,863 |  |  | $ | 12,280 |  |
| Long-term debt, less current portion: |  |  |  |  |  |  |  |  |
| Term Loan |  | $ | 141,202 |  |  | $ | 71,268 |  |
| Revolver |  |  | 10,000 |  |  |  | 10,000 |  |
| Less: unamortized debt issuance costs |  |  | (1,473 | ) |  |  | (846 | ) |
| Total long-term debt, less current portion |  |  | 149,729 |  |  |  | 80,422 |  |
| Total debt |  | $ | 167,592 |  |  | $ | 92,702 |  |

- removed (2017-11-09):
[0001564590-17-008860:note_history:48]
|  |  | March 31, 2017 |  |  | June 30, 2016 |  |
| Current portion of long-term debt: |  |  |  |  |  |  |  |  |
| Term Loan |  | $ | 11,149 |  |  | $ | 17,628 |  |
| Current portion of long-term debt |  | $ | 11,149 |  |  | $ | 17,628 |  |
| Long-term debt, less current portion: |  |  |  |  |  |  |  |  |
| Term Loan |  | $ | 73,775 |  |  | $ | 27,446 |  |
| Revolving Facility |  |  | 10,000 |  |  |  | 10,000 |  |
| Total long-term debt, less current portion |  |  | 83,775 |  |  |  | 37,446 |  |
| Total debt |  | $ | 94,924 |  |  | $ | 55,074 |  |


## us-gaap:RevenueRecognitionPolicyTextBlock (revenue_recognition_policy) — matched_by: no_prior_note, score: 0.0

- added (2017-11-09):
[0001564590-17-023316:note_history:49]
Revenue Recognition

- added (2017-11-09):
[0001564590-17-023316:note_history:50]
The Company accounts for revenue in accordance with ASC Topic 606, Revenue from Contracts with Customers, which the Company adopted on July 1, 2017, using the retrospective method.  The Company derives the majority of its revenue from sales of its networking equipment, with the remaining revenue generated from service fees relating to maintenance contracts, professional services, and training for its products. The Company sells its products and maintenance contracts direct to customers and to partners in two distribution channels, or tiers. The first tier consists of a limited number of independent distributors that stock its products and sell primarily to resellers.  The second tier of the distribution channel consists of a non-stocking distributors and value-added resellers that sell directly to end-users.  Products and services may be sold separately or in bundled packages.

- added (2017-11-09):
[0001564590-17-023316:note_history:51]
The Company considers customer purchase orders, which in some cases are governed by master sales agreements, to be the contracts with a customer.  For each contract, the Company considers the promise to transfer products and services, each of which are distinct, to be the identified performance obligations. In determining the transaction price the Company evaluates whether the price is subject to refund or adjustment to determine the net consideration to which the Company expects to be entitled.

- added (2017-11-09):
[0001564590-17-023316:note_history:52]
For all of the Company’s sales and distribution channels, revenue is recognized when control of the product is transferred to the customer (i.e. when the Company’s performance obligation is satisfied), which typically occurs at shipment for product sales. Revenue from maintenance contracts is recognized over time as the Company’s performance obligations are satisfied. This is typically the contractual service period, which range from one to three years.  For product sales to value-added resellers of the Company, non-stocking distributors and end-user customers, the Company generally does not grant return privileges, except for defective products during the warranty period, nor does the Company grant pricing credits.  Sales incentives and other programs that the Company may make available to these customers are considered to be a form of variable consideration and the Company maintains estimated accruals and allowances using the expected value method. There were no material changes in the current period to the estimated transaction price for performance obligations which were satisfied or partially satisfied during previous periods.

- added (2017-11-09):
[0001564590-17-023316:note_history:53]
Sales to stocking distributors are made under terms allowing certain price adjustments and limited rights of return (known as “stock rotation”) of the Company’s products held in their inventory. Revenue from sales to distributors is recognized upon the transfer of control to the distributor.  Frequently, distributors need to sell at a price lower than the contractual distribution price in order to win business, and submit rebate requests for Company pre-approval prior to selling the product through at the discounted price.  At the time the distributor invoices its customer or soon thereafter, the distributor submits a rebate claim to the Company to adjust the distributor’s cost from the contractual price to the pre-approved lower price. After the Company verifies that the claim was pre-approved, a credit memo is issued to the distributor for the rebate claim. In determining the transaction price, the Company considers these rebate adjustments to be variable consideration. Such price adjustments are estimated using the expected value method based on an analysis of actual claims, at the distributor level over a trailing twelve month period of time considered adequate to account for current pricing and business trends. Stock rotation rights grant the distributor the ability to return certain specified amounts of inventory. Stock rotation adjustments are an additional form of variable consideration and are also estimated using the expected value method based on historical return rates. There were no material changes in the current period to the estimated variable consideration for performance obligations which were satisfied or partially satisfied during previous periods.

- added (2017-11-09):
[0001564590-17-023316:note_history:54]
Performance Obligations. A performance obligation is a promise in a contract to transfer a distinct good or service to the customer, and is the unit of account in ASC Topic 606. A contract’s transaction price is allocated to each distinct performance obligation and recognized as revenue when, or as, the performance obligation is satisfied.  Certain of the Company’s contracts have multiple performance obligations, as the promise to transfer individual goods or services is separately identifiable from other promises in the contracts and, therefore, is distinct.  For contracts with multiple performance obligations, the Company allocates the contract’s transaction price to each performance obligation based on its relative standalone selling price.  The stand-alone selling prices are determined based on the prices at which the Company separately sells these products.  For items that are not sold separately, the Company estimates the stand-alone selling prices using the best estimated selling price approach.

- added (2017-11-09):
[0001564590-17-023316:note_history:55]
The Company’s performance obligations are satisfied at a point in time or over time as work progresses.  Substantially all of the Company’s product sales revenues as reflected on the consolidated statements of operations for the three-month periods ended September 30, 2017, and 2016 are recognized at a point in time. Substantially all of the Company’s service revenue is recognized over time.  For revenue recognized over time, the Company uses an input measure, days elapsed, to measure progress.

- added (2017-11-09):
[0001564590-17-023316:note_history:56]
On September 30, 2017, the Company had $119.2 million of remaining performance obligations, which is comprised of deferred maintenance revenue and services not yet delivered.  The Company expects to recognize approximately 70 percent of its remaining performance obligations as revenue in fiscal 2018, an additional 18 percent by fiscal 2019 and the balance thereafter.

- added (2017-11-09):
[0001564590-17-023316:note_history:57]
Contract Balances. The timing of revenue recognition, billings and cash collections results in billed accounts receivable and deferred revenue on the consolidated balance sheet. Services provided under renewable support arrangements of the Company are billed in accordance with agreed-upon contractual terms, which are typically at periodic intervals (e.g., quarterly or annually).  The Company sometimes receives payments from its customers in advance of services being provided, resulting in deferred revenues.  These liabilities are reported on the consolidated balance sheet on a contract-by-contract basis at the end of each reporting period.

- added (2017-11-09):
[0001564590-17-023316:note_history:58]
Revenue recognized for the three month periods ended September 30, 2017 and 2016, that was included in the deferred revenue balance at the beginning of each year was $42.1 million and $37.2 million respectively.

- added (2017-11-09):
[0001564590-17-023316:note_history:59]
Contract Costs.  The Company recognizes the incremental costs of obtaining contracts as an expense when incurred if the amortization period of the assets that the Company otherwise would have recognized is one year or less.  These costs are included in selling and marketing expenses.  Management expects that commission fees paid to sales representative as a result of obtaining service contracts and contract renewals are recoverable and therefore the Company capitalized them as contract costs in the amount of $2.5 million and $2.3 million at September 30, 2017 and 2016, respectively.  Capitalized commission fees are amortized on a straight-line basis over the average period of service contracts of approximately three years, and are included in sales and marketing expenses.  Amortization recognized during the three-month period ended September 30, 2017 and September 30, 2016, was $0.4 million and $0.3 million, respectively.  There was no impairment loss in relation to the costs capitalized.

- added (2017-11-09):
[0001564590-17-023316:note_history:60]
Revenue by Category: The following table sets forth the Company’s revenue disaggregated by sales channel and geographic region based on the billing addresses of our customers (in thousands, unaudited):

- added (2017-11-09):
[0001564590-17-023316:note_history:61]
|  |  | Three Months Ended |  |
|  |  | September 30, 2017 |  |  | September 30, 2016 |  |
|  |  |  |  |  |  |  |  |  |  |  |  | (As adjusted) |  |
|  |  | Distributor |  | Direct |  | Total |  |  | Distributor |  | Direct |  | Total |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  | $ | 42,392 |  | $ | 50,990 |  | $ | 93,382 |  |  | $ | 26,991 |  | $ | 26,829 |  | $ | 53,820 |  |
| Other |  |  | 14,336 |  |  | 6,395 |  |  | 20,731 |  |  |  | 1,393 |  |  | 9,628 |  |  | 11,021 |  |
| Total Americas |  |  | 56,728 |  |  | 57,385 |  |  | 114,113 |  |  |  | 28,384 |  |  | 36,457 |  |  | 64,841 |  |
| EMEA: |  |  | 51,232 |  |  | 27,903 |  |  | 79,135 |  |  |  | 31,299 |  |  | 16,529 |  |  | 47,828 |  |
| APAC: |  |  | 3,264 |  |  | 15,203 |  |  | 18,467 |  |  |  | 1,452 |  |  | 8,483 |  |  | 9,935 |  |
| Total net revenues |  | $ | 111,224 |  | $ | 100,491 |  | $ | 211,715 |  |  | $ | 61,135 |  | $ | 61,469 |  | $ | 122,604 |  |


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: no_prior_note, score: 0.0

- added (2017-11-09):
[0001564590-17-023316:note_history:62]
14.Subsequent Event

- added (2017-11-09):
[0001564590-17-023316:note_history:63]
On October 27, 2017 (the “Brocade Closing Date”), the Company completed its acquisition of Brocade Communication Systems, Inc.’s (“Brocade”) switching, routing and analytics business (“Brocade SRA”), that had been announced on October 3, 2017. Under the terms and subject to the conditions of the Brocade Asset Purchase Agreement (“Brocade Purchase Agreement”), the Company acquired customers, employees, technology and other assets of Brocade SRA, as well as assumed certain contracts and other liabilities of Brocade SRA, for an upfront cash closing payment equal to $23.0 million, plus a deferred payment equal to $20.0 million to be paid $1 million per quarter for 20 quarters following the Brocade Closing Date, plus quarterly earn out payments equal to 50% of profits of Brocade SRA, with certain deductions per the terms of the Brocade Purchase Agreement for the five-year period commencing at the end of our first full fiscal quarter following the Brocade Closing Date. The Company is still evaluating the estimated consideration from the earn out provision.  In conjunction with the acquisition, Extreme paid a fee of $25.0 million to Broadcom, Inc. in October 2017, for the right to acquire the Brocade SRA business.

- added (2017-11-09):
[0001564590-17-023316:note_history:64]
The acquisition will be accounted for using the acquisition method of accounting whereby the acquired assets and liabilities of Brocade SRA will be recorded at their respective fair values and added to those of the Company including an amount for goodwill representing the difference between the acquisition consideration and the fair value of the identifiable net assets. Results of operations of Brocade SRA will be included in the Company’s operations beginning with the Brocade Closing Date, As of the date of filing this Form 10-Q, the initial purchase price allocation has not been prepared as there has not been sufficient time to complete the related activities.

- added (2017-11-09):
[0001564590-17-023316:note_history:65]
On October 26, 2017, the Company entered into the Third Amendment to the Credit Facility (the “Third Amendment”). Among other things, the Third Amendment (i) amends the negative covenant governing dispositions to increase the general dispositions basket for the fiscal year of the Company ending June 30, 2018, and (ii) amends certain definitions and provisions to update certain references to the Brocade Purchase Agreement (as defined above). On the Brocade Closing Date to partially fund the acquisition of the Brocade SRA acquisition, the Company drew $20.0 million on the Term Loan.
