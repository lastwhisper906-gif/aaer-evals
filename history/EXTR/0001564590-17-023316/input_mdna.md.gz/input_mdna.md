# EXTR MD&A — 0001564590-17-023316


## mdna

[0001564590-17-023316:mdna:1]
[same as prior period, unchanged from 0001564590-17-008860:mdna:1]

[0001564590-17-023316:mdna:2]
[same as prior period, unchanged from 0001564590-17-008860:mdna:2]

[0001564590-17-023316:mdna:3]
We believe that understanding the following key developments is helpful to an understanding of our operating results for the fiscal quarter ended September 30, 2017.

[0001564590-17-023316:mdna:4]
[same as prior period, unchanged from 0001564590-17-008860:mdna:4]

[0001564590-17-023316:mdna:5]
Enterprise network administrators from the data center to the access layer need to respond to the rapid digital transformational trends of cloud, mobility, big data, social business and the ever-present need for network security.  Accelerators such as Internet of Things (“IoT”), artificial intelligence (“AI”), bring your own device (“BYOD”), machine learning, cognitive computing, and robotics add complexity to challenge the capabilities of traditional networks. Technology advances have a profound effect across the entire enterprise network by placing unprecedented demands on network administrators to enhance management capabilities, scalability, programmability, agility, and analytics of the enterprise networks they manage.

[0001564590-17-023316:mdna:6]
[same as prior period, unchanged from 0001564590-17-008860:mdna:6]

[0001564590-17-023316:mdna:7]
[same as prior period, unchanged from 0001564590-17-008860:mdna:7]

[0001564590-17-023316:mdna:8]
[same as prior period, unchanged from 0001564590-17-008860:mdna:8]

[0001564590-17-023316:mdna:9]
|  | • | The mobile workforce continues to proliferate. Employees expect high-quality and secure access to corporate resources in a BYOD world across a diversity of endpoints such as laptops, tablets, smart phones and wearables, whether they are within the corporate firewall or on-the-go. With ExtremeManagement, IT departments focus their investment decisions on this mobile workforce, taking a unified view of wireless access, from the campus core and the data center. Networking vendors offer end-to-end solutions that permit IT managers to meet employee expectations and to maximize IT return on investment. |

[0001564590-17-023316:mdna:10]
|  | • | Verticals such as healthcare, education, manufacturing, government, hospitality, which includes sports and entertainment venues and retail are connecting with their customers and guests beyond the network. These enterprises are investing in guest and location technologies that connect with their customers via their mobile devices over their WLAN. This allows them to obtain rich analytics for contextual marketing, which in turn, enables them to deliver a personalized brand experience. ExtremeGuest™ and ExtremeLocation™ have been built on cloud-based technology for simple implementation and fast release to market to better provide necessary insights into guest demographics and location-based analytics. |

[0001564590-17-023316:mdna:11]
|  | • | Growing usage of the cloud. Enterprises have migrated increasing numbers of applications and services to either private clouds or public clouds offered by third parties. In either case, the network infrastructure must adapt to this new dynamic environment. Intelligence and automation are key if enterprises are to derive maximum benefit from their cloud deployments. Ethernet speeds, scaling from 10 Gigabits per second (“G”) to 40G and even 100G, provide the infrastructure for both private and public clouds. In addition, there is growing interest in SDN approaches that may include technologies such as OpenFlow, OpenStack, and CloudStack for increased network agility. |

[0001564590-17-023316:mdna:12]
|  | • | Vendor consolidation is expected to continue. Consolidation of vendors within the enterprise network equipment market and between adjacent markets (storage, security, wireless & voice software and applications) continues to gain momentum. We identified this trend in 2013 with our acquisition of Enterasys. Further, we believe customers are demanding more end-to-end, integrated networking solutions. To address this demand, we acquired the WLAN Business of Zebra in October 2016, and Avaya’s fabric-based secure networking solutions and network security solutions business (“Avaya Networking”) in July 2017. |

[0001564590-17-023316:mdna:13]
[same as prior period, unchanged from 0001564590-17-008860:mdna:13]

[0001564590-17-023316:mdna:14]
[same as prior period, unchanged from 0001564590-17-008860:mdna:14]

[0001564590-17-023316:mdna:15]
|  | • | Data Center to access edge wired and wireless solutions. The addition of the WLAN Business and the Avaya Networking assets will allow Extreme to offer a complete, unified portfolio of software-driven network access solutions. We offer the latest in wireless access points for both outdoor and indoor use plus a complete line of switches for the Campus, Core and Data Center. |

[0001564590-17-023316:mdna:16]
|  | • | Multi-vendor management from a “single pane-of-glass”. Extreme’s Management Center (“EMC”) is a single unified management system that is designed to provide visibility, security, and control across the entire network. This can make the network easier to manage and troubleshoot, often with lower operating expenses. Extreme’s software can manage third-party vendors’ network devices, including Avaya Networking products, enabling our customers to potentially maximize device lifespan and protect investments. |

[0001564590-17-023316:mdna:17]
|  | • | Software-driven vertical solutions. Extreme’s software-driven solutions are designed to be easily adaptable to vertical solutions in industries such as healthcare, education, manufacturing, retail, transportation and logistics, government and hospitality. Extreme solutions are also designed to be well-suited for vertical-specific partners in these industries. |

[0001564590-17-023316:mdna:18]
|  | • | Application-aware Quality of Service (“QoS”) and analytics. Extreme has innovative analytic software that enables our customers to see application usage across the network and apply policies that maximize network capabilities. This allows our customers to improve the user experience. |

[0001564590-17-023316:mdna:19]
|  | • | Built-in identity and access control. ExtremeControl™, a network access control, and identity management solution is delivered with the wired and wireless hardware. This may reduce the need to add on expensive software or hardware that may require complex compatibility testing. |

[0001564590-17-023316:mdna:20]
|  | • | Easier policy assignment and SDN. ExtremeControl™ and ExtremeManagement™ software allow our customers to assign policy across the entire network. The SDN component adds versatility for implementing policies that increase network utilization. |

[0001564590-17-023316:mdna:21]
|  | • | 100% in-sourced tech support. ExtremeWorks™ delivers best in class customer support in the industry with 92% first call resolution through a 100% in-sourced support model. |

[0001564590-17-023316:mdna:22]
[same as prior period, unchanged from 0001564590-17-008860:mdna:23]

[0001564590-17-023316:mdna:23]
Acquisitions

[0001564590-17-023316:mdna:24]
Avaya Networking

[0001564590-17-023316:mdna:25]
On July 14, 2017 (“Avaya Closing Date”), we completed the acquisition of Avaya Inc’s. fabric-based secure networking solutions and network security solutions business (“Avaya Networking”), that had been announced on March 7, 2017, and funds were remitted to Avaya pursuant to the Avaya Purchase Agreement. We acquired customers, employees, technology and other assets, as well as assume contracts and other liabilities of Avaya Networking, for a purchase price of $79.8 million, including all adjustments.  Pursuant to certain ancillary agreements, Avaya will also provide us with access to certain technology related to Avaya

[0001564590-17-023316:mdna:26]
30

[0001564590-17-023316:mdna:27]
Networking, as well as transition services for a period of time following the Avaya Closing Date.   See Note 2. Business Combination for additional information.

[0001564590-17-023316:mdna:28]
The acquisition was accounted for using the acquisition method of accounting whereby the acquired assets and liabilities of the Avaya Networking is recorded at their respective fair values and added to those of ours including an amount for goodwill representing the difference between the acquisition consideration and the fair value of the identifiable net assets.  Results of operations of Avaya Networking are included in our operations beginning with the Avaya Closing Date.

[0001564590-17-023316:mdna:29]
During the fiscal quarter ended September 30, 2017, we recognized acquisition and integration costs of $2.9 million related to the Avaya Networking acquisition which is included in “Acquisition and integration costs” in the accompanying condensed consolidated statements of operations.

[0001564590-17-023316:mdna:30]
Brocade SRA

[0001564590-17-023316:mdna:31]
On October 27, 2017 (“Brocade Closing Date”), we completed our acquisition of Brocade Communication Systems, Inc.’s (“Brocade”) switching, routing and analytics business (“Brocade SRA”) that had been announced on October 3, 2017.  Upon the terms and subject to the conditions of the Brocade Asset Purchase Agreement, we acquired customers, employees, technology and other assets of Brocade SRA, as well as assumed certain contracts and other liabilities of Brocade SRA, for an upfront cash closing payment equal to $23.0 million, plus deferred payments equal to $20.0 million to be paid $1 million per quarter for 20 quarters following the Brocade Closing Date, plus quarterly earn out payments equal to 50% of profits of Brocade SRA for the five-year period commencing at the end of our first full fiscal quarter following the Brocade Closing Date. Pursuant to certain ancillary agreements, Brocade will also provide us with access to certain technology related to Brocade SRA, as well as transition services for a period of time following the Brocade Closing Date.  The acquisition will include the rights to have manufactured and to sell Brocade’s current SLX based solutions product portfolio, which launched in March 2017.  In conjunction with the acquisition, Extreme paid a fee of $25.0 million to Broadcom, Inc., for the right to acquire the Brocade SRA.  (See Item 1A Risk Factors)

[0001564590-17-023316:mdna:32]
During the three months ended September 30, 2017, we recognized acquisition costs of $1.3 million, which is included in “Acquisition and integration costs” in the accompanying condensed consolidated statements of operations related to the Brocade SRA acquisition.

[0001564590-17-023316:mdna:33]
[same as prior period, unchanged from 0001564590-17-008860:mdna:34]

[0001564590-17-023316:mdna:34]
During the first quarter of fiscal 2018, we achieved the following results:

[0001564590-17-023316:mdna:35]
|  | • | Net revenues of $211.7 million compared to $122.6 million in the first quarter of fiscal 2017. |

[0001564590-17-023316:mdna:36]
|  | • | Product revenues of $164.8 million compared to $90.1 million in the first quarter of fiscal 2017. |

[0001564590-17-023316:mdna:37]
|  | • | Service revenues of $46.9 million compared to $32.5 million in the first quarter of fiscal 2017. |

[0001564590-17-023316:mdna:38]
|  | • | Total gross margin of 53.1% of net revenues compared to 53.7% of net revenues in the first quarter of fiscal 2017. |

[0001564590-17-023316:mdna:39]
|  | • | Operating income of $4.5 million compared to operating loss $4.0 million in the first quarter of fiscal 2017. |

[0001564590-17-023316:mdna:40]
|  | • | Net income of $4.4 million compared to a net loss of $5.7 million in the first quarter of fiscal 2017. |

[0001564590-17-023316:mdna:41]
|  | • | Cash flow provided by operating activities of $18.6 million compared to $9.6 million in the first quarter of fiscal 2017. |

[0001564590-17-023316:mdna:42]
|  | • | Cash, cash equivalents and short-term investments of $154.1 million compared to $102.3 million as of June 30, 2017. |

[0001564590-17-023316:mdna:43]
[same as prior period, unchanged from 0001564590-17-008860:mdna:44]

[0001564590-17-023316:mdna:44]
[same as prior period, unchanged from 0001564590-17-008860:mdna:45]

[0001564590-17-023316:mdna:45]
|  |  | Three Months Ended |  |
|  |  | September 30, 2017 |  |  | September 30, 2016 |  |  | $ Change |  |  | % Change |  |
|  |  |  |  |  |  | (As adjusted) |  |  |  |  |  |  |  |  |  |
| Net Revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 164,774 |  |  | $ | 90,093 |  |  | $ | 74,681 |  |  |  | 82.9 | % |
| Percentage of net revenue |  |  | 77.8 | % |  |  | 73.5 | % |  |  |  |  |  |  |  |  |
| Service |  |  | 46,941 |  |  |  | 32,511 |  |  |  | 14,430 |  |  |  | 44.4 | % |
| Percentage of net revenue |  |  | 22.2 | % |  |  | 26.5 | % |  |  |  |  |  |  |  |  |
| Total net revenues |  | $ | 211,715 |  |  | $ | 122,604 |  |  | $ | 89,111 |  |  |  | 72.7 | % |

[0001564590-17-023316:mdna:46]
Product revenues increased $74.7 million or 82.9% for the three months ended September 30, 2017 as compared to the corresponding period of fiscal 2017.  The increase in product revenues for the three months of fiscal 2018 was attributable primarily to the acquisition of the WLAN Business in October 2016 and Avaya Networking in July 2017.

[0001564590-17-023316:mdna:47]
Service revenues increased $14.4 million, or 44.4% for the three months ended September 30, 2017, compared to the corresponding period of fiscal 2017. The increase in service revenue was due to the increased number of service contracts acquired as a result of the acquisition of the WLAN Business in October 2016 and Avaya Networking in July 2017.

[0001564590-17-023316:mdna:48]
[same as prior period, unchanged from 0001564590-17-008860:mdna:49]

[0001564590-17-023316:mdna:49]
|  |  | Three Months Ended |  |
|  |  | September 30, 2017 |  |  | September 30, 2016 |  |  | $ Change |  |  | % Change |  |
|  |  |  |  |  |  | (As adjusted) |  |  |  |  |  |  |  |  |  |
| Gross profit: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 84,729 |  |  | $ | 45,844 |  |  | $ | 38,885 |  |  |  | 84.8 | % |
| Percentage of product revenue |  |  | 51.4 | % |  |  | 50.9 | % |  |  |  |  |  |  |  |  |
| Service |  |  | 27,652 |  |  |  | 20,042 |  |  |  | 7,610 |  |  |  | 38.0 | % |
| Percentage of service revenue |  |  | 58.9 | % |  |  | 61.6 | % |  |  |  |  |  |  |  |  |
| Total gross profit |  | $ | 112,381 |  |  | $ | 65,886 |  |  | $ | 46,495 |  |  |  | 70.6 | % |
| Percentage of net revenue |  |  | 53.1 | % |  |  | 53.7 | % |  |  |  |  |  |  |  |  |

[0001564590-17-023316:mdna:50]
Product gross profit increased $38.9 million or 84.8% for three months ended September 30, 2017, as compared to the corresponding period in fiscal 2017, due primarily to the acquisition of the WLAN Business and Avaya Networking and the corresponding revenues attributed to those acquisitions, lower amortization of developed technology intangibles of $0.8 million and more favorable manufacturing costs due to cost reduction efforts.  The increases in product gross profit were partially offset by integration costs of $1.8 million primarily related to excess inventory charges related to the discontinuance of certain product lines due to the Avaya Networking acquisition, higher warranty charges of $1.7 million and increased royalty charges of $1.2 million.

[0001564590-17-023316:mdna:51]
Service gross profit increased $7.6 million or 38.0% for three months ended September 30, 2017, as compared to the corresponding period in fiscal 2017, primarily due to an increase in service revenue of $14.4 million related to the acquisition of the WLAN Business and Avaya Networking as a result of higher number of maintenance contracts.

[0001564590-17-023316:mdna:52]
[same as prior period, unchanged from 0001564590-17-008860:mdna:55]

[0001564590-17-023316:mdna:53]
[same as prior period, unchanged from 0001564590-17-008860:mdna:56]

[0001564590-17-023316:mdna:54]
|  |  | Three Months Ended |  |
|  |  | September 30, 2017 |  |  | September 30, 2016 |  |  | $ Change |  |  | % Change |  |
|  |  |  |  |  |  | (As adjusted) |  |  |  |  |  |  |  |  |  |
| Research and development |  | $ | 34,285 |  |  | $ | 18,299 |  |  | $ | 15,986 |  |  |  | 87.4 | % |
| Sales and marketing |  |  | 55,561 |  |  |  | 36,859 |  |  |  | 18,702 |  |  |  | 50.7 | % |
| General and administrative |  |  | 12,185 |  |  |  | 8,287 |  |  |  | 3,898 |  |  |  | 47.0 | % |
| Acquisition and integration costs |  |  | 4,244 |  |  |  | 2,321 |  |  |  | 1,923 |  |  |  | 82.9 | % |
| Amortization of intangibles |  |  | 1,614 |  |  |  | 4,142 |  |  |  | (2,528 | ) |  |  | (61.0 | )% |
| Total operating expenses |  | $ | 107,889 |  |  | $ | 69,908 |  |  | $ | 37,981 |  |  |  | 54.3 | % |

[0001564590-17-023316:mdna:55]
[same as prior period, unchanged from 0001564590-17-008860:mdna:58]

[0001564590-17-023316:mdna:56]
[same as prior period, unchanged from 0001564590-17-008860:mdna:59]

[0001564590-17-023316:mdna:57]
Research and development expenses increased by $16.0 million or 87.4% for the three months ended September 30, 2017, as compared to the corresponding period of fiscal 2017.  The increase in research and development expenses was due to higher personnel costs (which consists of compensation, benefits and non-cash stock based compensation) of $11.2 million due to increased headcount related to the acquisitions of the WLAN Business in October 2016 and Avaya Networking business in July 2017, $2.6 million in increased facility and information technology costs, $1.5 million in increased supplies and equipment costs and $0.4 million of travel and other costs, and $0.3 million in consulting and contract projects.

[0001564590-17-023316:mdna:58]
[same as prior period, unchanged from 0001564590-17-008860:mdna:62]

[0001564590-17-023316:mdna:59]
[same as prior period, unchanged from 0001564590-17-008860:mdna:63]

[0001564590-17-023316:mdna:60]
Sales and marketing expenses increased by $18.7 million or 50.7% for the three months ended September 30, 2017, as compared to the corresponding period of fiscal 2017 three months ended September 30, 2017 primarily as a result of the acquisitions of the WLAN Business in October 2016 and Avaya Networking in July 2017.  The increase consisted of higher personnel costs including benefits and non-cash stock compensation of $12.6 million, $2.4 million in additional professional fees, $2.2 million in travel, meeting and conference costs, and $1.6 million in increased facility and information technology costs.

[0001564590-17-023316:mdna:61]
[same as prior period, unchanged from 0001564590-17-008860:mdna:66]

[0001564590-17-023316:mdna:62]
[same as prior period, unchanged from 0001564590-17-008860:mdna:67]

[0001564590-17-023316:mdna:63]
General and administrative expenses increased by $3.9 million or 47.0% for the three months ended September 30, 2017 as compared to the corresponding period of fiscal 2017 primarily due to $2.2 million in higher compensation, benefits and non-cash stock based compensation, $1.1 million in higher professional fees, $0.4 million in higher bad debts provision, and $0.1 million in higher travel costs.

[0001564590-17-023316:mdna:64]
[same as prior period, unchanged from 0001564590-17-008860:mdna:70]

[0001564590-17-023316:mdna:65]
During the three months ended September 30, 2017 and 2016, we recorded $4.2 million and $2.3 million, respectively, of acquisition and integration costs.

[0001564590-17-023316:mdna:66]
For the three months ended September 30, 2017, we incurred $1.2 million of acquisition and $1.7 million of integration costs related to the acquisition of Avaya Networking on July 14, 2017, and $1.3 million of acquisition costs related to the future acquisition of Brocade SRA.

[0001564590-17-023316:mdna:67]
For the three months ended September 30, 2016, we incurred $2.3 million of acquisition costs consisting primarily of legal and accounting services associated with the acquisition of the WLAN Business.

[0001564590-17-023316:mdna:68]
[same as prior period, unchanged from 0001564590-17-008860:mdna:78]

[0001564590-17-023316:mdna:69]
During the three months ended September 30, 2017 and 2016, we recorded $1.6 million and $4.1 million, respectively of amortization expense as operating expenses in the condensed consolidated statements of operations.  The reduction was due to the acquired intangibles from the Enterasys acquisition becoming fully amortized.

[0001564590-17-023316:mdna:70]
[same as prior period, unchanged from 0001564590-17-008860:mdna:81]

[0001564590-17-023316:mdna:71]
During the three months ended September 30, 2017 and 2016, we recorded $2.2 million and $0.6 million, respectively, in interest expense.  The increase in interest expense was primarily in connection with the increased balance of our Credit Facility due to the acquisitions of the WLAN Business and Avaya Networking in October 2016 and July 2017.

[0001564590-17-023316:mdna:72]
Other Income (Expense), Net

[0001564590-17-023316:mdna:73]
During the three months ended September 30, 2017 and 2016, we recorded income of $3.1 million and expenses of $0.2 million, respectively, in other income (expense), net. The income for fiscal 2018 period was primarily driven by a gain of $3.8 million due to the sale of non-marketable equity investment.  The charge for fiscal 2017 period was primarily due to foreign exchange losses from the revaluation of certain assets and liabilities denominated in foreign currencies into U.S. Dollars.

[0001564590-17-023316:mdna:74]
[same as prior period, unchanged from 0001564590-17-008860:mdna:87]

[0001564590-17-023316:mdna:75]
For the three months ended September 30, 2017 and 2016, we recorded an income tax provision of $1.7 million and $0.9 million, respectively, which consisted primarily of taxes on the income of our foreign subsidiaries as well as tax expense associated with the establishment of a U.S. deferred tax liability for amortizable goodwill resulting from the acquisition of Enterasys, the WLAN Business and Avaya Networking.

[0001564590-17-023316:mdna:76]
[same as prior period, unchanged from 0001564590-17-008860:mdna:90]

[0001564590-17-023316:mdna:77]
[same as prior period, unchanged from 0001564590-17-008860:mdna:91]

[0001564590-17-023316:mdna:78]
As discussed in Part II, Item 7, “Management’s Discussion and Analysis of Financial Condition and Results of Operations” of our Annual Report on Form 10-K for the year ended June 30, 2017, we consider the following accounting policies to be the most critical in understanding the judgments that are involved in preparing our consolidated financial statements:

[0001564590-17-023316:mdna:79]
[same as prior period, unchanged from 0001564590-17-008860:mdna:93]

[0001564590-17-023316:mdna:80]
[same as prior period, unchanged from 0001564590-17-008860:mdna:94]

[0001564590-17-023316:mdna:81]
[same as prior period, unchanged from 0001564590-17-008860:mdna:95]

[0001564590-17-023316:mdna:82]
|  | • | Business Combinations |

[0001564590-17-023316:mdna:83]
[same as prior period, unchanged from 0001564590-17-008860:mdna:96]

[0001564590-17-023316:mdna:84]
[same as prior period, unchanged from 0001564590-17-008860:mdna:97]

[0001564590-17-023316:mdna:85]
Revenue Recognition

[0001564590-17-023316:mdna:86]
We account for revenue in accordance with ASC Topic 606, Revenue from Contracts with Customers, which we adopted on July 1, 2017, using the full retrospective method.  The adoption of this ASC, which we opted to early adopt pursuant to the guidance, requires us, among other things to restate prior periods to conform to current presentation and the adoption of ASC 606 is considered an accounting change. Under ASC 606 revenue is recognized when a customer obtains control of promised goods or services and is recognized at an amount that reflects the consideration expected to be received in exchange for such goods or services.

[0001564590-17-023316:mdna:87]
We derive the majority of our revenue from sales of our networking equipment, with the remaining revenue generated from service fees relating to maintenance contracts, professional services, and training for our products. We sell our products and maintenance contracts to partners in two distribution channels, or tiers. The first tier consists of a limited number of independent distributors that stock our products and sell primarily to resellers.  The second tier of the distribution channel consists of a non-stocking distributors and value-added resellers that sell directly to end-users.  Products and services may be sold separately or in bundled packages.

[0001564590-17-023316:mdna:88]
We consider customer purchase orders, which in some cases are governed by master sales agreements, to be the contracts with a customer. For each contract, we consider the promise to transfer products, each of which are distinct, to be the identified performance obligations. In determining the transaction price we evaluate whether the price is subject to refund or adjustment to determine the net consideration to which we expect to be entitled.

[0001564590-17-023316:mdna:89]
For all of our sales and distribution channels, revenue is recognized when control of the product is transferred to the customer (i.e. when our performance obligation is satisfied), which typically occurs at shipment for product sales.  For product sales to our value-added resellers, non-stocking distributors and end-user customers, we generally do not grant return privileges, except for defective products during the warranty period.  Sales incentives and other programs that we may make available to these customers are considered to be a form of variable consideration and we maintain estimated accruals and allowances using the expected value method.

[0001564590-17-023316:mdna:90]
Sales to stocking distributors are made under terms allowing certain price adjustments and limited rights of return (known as “stock rotation”) of the Company’s products held in their inventory. Revenue from sales to distributors is recognized upon the transfer of control to the distributor. Frequently, distributors need to sell at a price lower than the contractual distribution price in order to win business, and submits rebate requests for Company pre-approval prior to selling the product through at the discounted price. At the time the distributor invoices its customer or soon thereafter, the distributor submits a rebate claim to the Company to adjust the distributor’s cost from the contractual price to the pre-approved lower price. After the Company verifies that the claim was pre-approved, a credit memo is issued to the distributor for the rebate claim. In determining the transaction price, the Company considers these rebate adjustments to be variable consideration. Such price adjustments are estimated using the expected value method based on an analysis of actual claims, at the distributor level over a trailing twelve month period of time considered adequate to account for current pricing and business trends. Stock rotation rights grant the distributor the ability to return certain specified amounts of inventory. Stock rotation adjustments are an additional form of variable consideration and are also estimated using the expected value method based on historical return rates The Company did not experience significant differences in its estimates during the three months ended September 30, 2017.  For additional information, see Note 3, Summary of Significant Accounting Policies.

[0001564590-17-023316:mdna:91]
[same as prior period, unchanged from 0001564590-17-008860:mdna:104]

[0001564590-17-023316:mdna:92]
[same as prior period, unchanged from 0001564590-17-008860:mdna:105]

[0001564590-17-023316:mdna:93]
[same as prior period, unchanged from 0001564590-17-008860:mdna:106]

[0001564590-17-023316:mdna:94]
The following summarizes information regarding our cash, cash equivalents, short-term investments, and working capital (in thousands):

[0001564590-17-023316:mdna:95]
|  |  | September 30, 2017 |  |  | June 30, 2017 |  |
| Cash and cash equivalents |  | $ | 153,014 |  |  | $ | 130,450 |  |
| Short-term investments |  |  | 1,050 |  |  |  | — |  |
| Total cash, cash equivalent and short-term investments |  | $ | 154,064 |  |  | $ | 130,450 |  |
| Working capital |  | $ | 82,072 |  |  | $ | 85,637 |  |

[0001564590-17-023316:mdna:96]
As of September 30, 2017, our principal sources of liquidity consisted of cash, cash equivalents and short-term investments of $154.1 million, accounts receivable, net of $116.5 million and availability of borrowings from the five-year revolving credit facility (“Revolver”) of $49.1 million. Our principal uses of cash will include repayments of debt and related interest, purchase of finished goods inventory from our contract manufacturers, payroll, restructuring expenses and other operating expenses related to the development, marketing of our products and purchases of property and equipment. We believe that our $154.1 million of cash, cash equivalents and short-term investments at September 30, 2017, cash flows from operations along with the availability of borrowings from the Revolver will be sufficient to fund our principal uses of cash for at least the next 12 months.

[0001564590-17-023316:mdna:97]
On July 14, 2017, in connection with the closing of Avaya Networking, we entered into the Second Amendment to the Amended and Restated Credit Agreement (“Second Amendment”), which amends the Amended and Restated Credit Agreement, dated as of October 28, 2016 (as amended, the “Credit Facility”), by and among us, as borrower, Silicon Valley Bank, as administrative agent and collateral agent, and Lenders. Among other things, the Second Amendment (i) increased the amount of the available borrowing under the Credit Facility from $140.5 million to $243.7 million, consisted of (a) the five-year term loan (“Term Loan”) facilities in a principal amount of up to $183.7 million and (b) the Revolver  in a principal amount of up to $60.0 million, (ii) extends the maturity date under the existing Term Loan and the termination date under the existing Revolver until July 2022, (iii) provides for an uncommitted additional incremental loan facility in a principal amount of up to $50.0 million (“Incremental Facility”), and (iv) joins certain additional banks, financial institutions and institutional lenders as Lenders pursuant to the terms of the Credit Facility.  On July 14, 2017, we borrowed an additional $80.0 million under the Term Loan which was used to fund the purchase of Avaya Networking.

[0001564590-17-023316:mdna:98]
On October 26, 2017, we entered into the Third Amendment to the Credit Facility (the “Third Amendment  Among other things, the Third Amendment (i) amends the negative covenant governing dispositions to increase the general dispositions basket for our fiscal year ending June 30, 2018, and (ii) amends certain definitions and provisions to update certain references to the Brocade Purchase Agreement.  On October 27, 2017, we drew $20.0 million on the Term Loan to partially fund the acquisition of the Brocade SRA (see Note 14. Subsequent Events for additionally information).

[0001564590-17-023316:mdna:99]
Borrowings under the Term Loan bear interest, at our option, at a rate equal to either the LIBOR rate (subject to a 0.0% LIBOR floor), plus an applicable margin (currently 3.25% per annum) or the adjusted base rate, plus an applicable margin (currently 1.25% per annum).  Borrowings under the Revolver bear interest, at our option, at a rate equal to either the LIBOR rate, plus an applicable margin (currently 3.25% per annum) or the adjusted base rate, plus an applicable margin (currently 1.25% per annum based).  The Revolver has a commitment fee payable on the undrawn amount ranging from 0.375% to 0.50% per annum.

[0001564590-17-023316:mdna:100]
If not repaid earlier, the borrowings on the Revolver shall be repaid on the termination date. The Credit Facility is secured by substantially all of our assets and is jointly and severally guaranteed by us and certain of our subsidiaries.

[0001564590-17-023316:mdna:101]
The Credit Facility contains financial covenants that require us to maintain a minimum Consolidated Fixed Charge Coverage Ratio and a Consolidated Quick Ratio and a maximum Consolidated Leverage Ratio as well as several other financial and non-financial covenants and restrictions that limit our ability to incur additional indebtedness, create liens upon any of our property, merge, consolidate or sell all or substantially all of our assets, etc.  These covenants, are subject to certain exceptions.

[0001564590-17-023316:mdna:102]
The Credit Facility also includes customary events of default, including failure to pay principal, interest or fees when due, failure to comply with covenants, if any representation or warranty made by us is false or misleading in any material respect, certain insolvency or receivership events affecting us and our subsidiaries, the occurrence of certain material judgments, the occurrence of certain ERISA events, the invalidity of the loan documents or a change in control of us.  The amounts outstanding under the Credit Facility may be accelerated upon certain events of default. At September 30, 2017, we were in compliance with the covenants of the Second Amendment to the Credit Facility and they are not expected to impact our liquidity or capital resources.

[0001564590-17-023316:mdna:103]
[same as prior period, unchanged from 0001564590-17-008860:mdna:113]

[0001564590-17-023316:mdna:104]
[same as prior period, unchanged from 0001564590-17-008860:mdna:114]

[0001564590-17-023316:mdna:105]
|  |  | Three Months Ended |  |
|  |  | September 30, 2017 |  |  | September 30, 2016 |  |
|  |  |  |  |  |  | (As adjusted) |  |
| Net cash provided by operating activities |  | $ | 18,598 |  |  | $ | 9,574 |  |
| Net cash used in investing activities |  |  | (70,546 | ) |  |  | (1,635 | ) |
| Net cash provided by financing activities |  |  | 74,455 |  |  |  | 166 |  |
| Foreign currency effect on cash |  |  | 57 |  |  |  | 38 |  |
| Net increase in cash and cash equivalents |  | $ | 22,564 |  |  | $ | 8,143 |  |

[0001564590-17-023316:mdna:106]
[same as prior period, unchanged from 0001564590-17-008860:mdna:116]

[0001564590-17-023316:mdna:107]
Cash flows provided by operations in the three months ended September 30, 2017 were $18.6 million, including net income of $4.4 million and non-cash expenses of $10.4 million for items such as amortization of intangibles, stock-based compensation expense, depreciation and gain on sale of non-marketable equity investment as well as a decrease in inventory and increases in accounts

[0001564590-17-023316:mdna:108]
payable and deferred revenue.  This was partially offset by an increase in accounts receivable and decreases in accrued compensation and current and noncurrent liabilities.

[0001564590-17-023316:mdna:109]
Cash flows provided by operations in the three months ended September 30, 2016 were $9.6 million including non-cash expenses of $14.5 million such as amortization of intangibles, stock-based compensation expense and depreciation, combined with higher collections of accounts receivables during the quarter. This was partially offset by the current period’s net loss of $5.7 million along with increased use of cash in inventory, accounts payable and accrued compensation.

[0001564590-17-023316:mdna:110]
[same as prior period, unchanged from 0001564590-17-008860:mdna:120]

[0001564590-17-023316:mdna:111]
Cash flows used in investing activities in the three months ended September 30, 2017 and 2016, were $70.5 million and $1.6 million, respectively.  For the three months ended September 30, 2017, cash flows consisted of expenditures for acquisitions of $68.0 million consisting of $69.6 million for the Avaya Networking acquisition less receipt of $1.6 million as final settlement of a working capital adjustment related to the WLAN Business acquisition, $7.4 million of purchases of property and equipment and proceeds of $4.9 million related to the sale of non-marketable equity investment.  For the September 30, 2016, amounts consisted of purchases of property and equipment.

[0001564590-17-023316:mdna:112]
[same as prior period, unchanged from 0001564590-17-008860:mdna:122]

[0001564590-17-023316:mdna:113]
Cash flows provided by financing activities in the three months ended September 30, 2017 were $74.5 million, including new borrowings of $80.0 million to fund our acquisition of Avaya Networking, $4.9 million proceeds from issuance of shares of our common stock under our Employee Stock Purchase Plan (“ESPP”) and the exercise of stock options less $4.8 million of taxes paid on vested and released stock awards, partially offset by repayment of debt totaling $4.1 million and $1.5 million of loan fees incurred in connection with the Second Amendment of our Credit Facility.

[0001564590-17-023316:mdna:114]
Cash flows provided by financing activities in the three months ended September 30, 2016 were $0.2 million which consisted of $3.4 million proceeds from the issuance of shares of our common stock under our ESPP and the exercise of stock options, net of taxes paid on vested and released stock awards, offset by repayment of debt of $3.2 million.

[0001564590-17-023316:mdna:115]
[same as prior period, unchanged from 0001564590-17-008860:mdna:125]

[0001564590-17-023316:mdna:116]
Foreign currency effect on cash increased in the three months ended September 30, 2017, primarily due to changes in foreign currency exchange rates between the US Dollar and particularly the Brazilian Real, British Pound, Indian Rupee and the EURO.

[0001564590-17-023316:mdna:117]
Contractual Obligations OPEN

[0001564590-17-023316:mdna:118]
The following summarizes our contractual obligations as of September 30, 2017, and the effect such obligations are expected to have on our liquidity and cash flow in future periods (in thousands):

[0001564590-17-023316:mdna:119]
|  |  | Total |  |  | Less than 1 Year |  |  | 1-3 years |  |  | 3-5 years |  |  | More than 5 years |  |
| Contractual Obligations: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Debt obligations |  | $ | 169,616 |  |  | $ | 18,414 |  |  | $ | 61,392 |  |  | $ | 89,810 |  |  | $ | — |  |
| Interest on debt obligations |  |  | 21,289 |  |  |  | 6,653 |  |  |  | 10,362 |  |  |  | 4,274 |  |  |  | — |  |
| Non-cancellable inventory purchase commitments |  |  | 115,114 |  |  |  | 115,114 |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Non-cancellable purchase commitments |  |  | 20,250 |  |  |  | 5,000 |  |  |  | 10,750 |  |  |  | 4,500 |  |  |  | — |  |
| Non-cancellable operating lease obligations |  |  | 51,389 |  |  |  | 12,551 |  |  |  | 19,782 |  |  |  | 19,056 |  |  |  | — |  |
| Other liabilities |  |  | 881 |  |  |  | 184 |  |  |  | 368 |  |  |  | 329 |  |  |  | — |  |
| Total contractual cash obligations |  | $ | 378,539 |  |  | $ | 157,916 |  |  | $ | 102,654 |  |  | $ | 117,969 |  |  | $ | — |  |

[0001564590-17-023316:mdna:120]
Non-cancelable inventory purchase commitments represent the purchase of long lead-time component inventory that our contract manufacturers procure in accordance with our forecast. Inventory purchase commitments were $115.1 million as of   September 30, 2017. We expect to honor the inventory purchase commitments within the next 12 months.

[0001564590-17-023316:mdna:121]
[same as prior period, unchanged from 0001564590-17-008860:mdna:131]

[0001564590-17-023316:mdna:122]
[same as prior period, unchanged from 0001564590-17-008860:mdna:132]

[0001564590-17-023316:mdna:123]
[same as prior period, unchanged from 0001564590-17-008860:mdna:133]

[0001564590-17-023316:mdna:124]
[same as prior period, unchanged from 0001564590-17-008860:mdna:134]

[0001564590-17-023316:mdna:125]
We did not have any material commitments for capital expenditures as of September 30, 2017.

[0001564590-17-023316:mdna:126]
[same as prior period, unchanged from 0001564590-17-008860:mdna:136]

[0001564590-17-023316:mdna:127]
We did not have any off-balance sheet arrangements as of September 30, 2017.
