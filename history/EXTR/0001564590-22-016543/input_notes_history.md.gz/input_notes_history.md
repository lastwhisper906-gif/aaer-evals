# EXTR note change history — 0001564590-22-003010 → 0001564590-22-016543


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2022-04-29):
[0001564590-22-016543:note_history:1]
The Company currently has arrangements with contract manufacturers and suppliers for the manufacture of its products. Those arrangements allow the contract manufactures to procure long lead-time component inventory based upon a rolling production forecast provided by the Company. The Company is obligated to purchase long lead-time component inventory that its contract manufacturer procures in accordance with the forecast, unless the Company gives notice of order cancellation outside of applicable component lead-times. As of March 31, 2022, the Company had commitments to purchase $70.4 million of inventory.
  (was, 2022-01-28, similarity 0.9893):
[0001564590-22-003010:note_history:1]
The Company currently has arrangements with contract manufacturers and suppliers for the manufacture of its products. Those arrangements allow the contract manufactures to procure long lead-time component inventory based upon a rolling production forecast provided by the Company. The Company is obligated to purchase long lead-time component inventory that its contract manufacturer procures in accordance with the forecast, unless the Company gives notice of order cancellation outside of applicable component lead-times. As of December 31, 2021, the Company had commitments to purchase $53.2 million of inventory.

- added (2022-04-29):
[0001564590-22-016543:note_history:2]
royalties, pre- and post-judgment interest, and attorneys’ fees. The Court dismissed the case without prejudice on January 4, 2022 and on April 18, 2022, entered final judgment in favor of the Company.  XR has 30 days to file a notice of appeal.

- changed (2022-04-29):
[0001564590-22-016543:note_history:3]
On April 23, 2019, Orckit filed an extension of the patent infringement complaint against the Company and its Irish and German subsidiaries in the District Court in Dusseldorf, Germany. With this extension, Orckit alleges infringement of the German portion of a second patent (“EP ‘077”) based on the offer, distribution, use, possession and/or importation into Germany of certain network switches that the Company no longer sells in Germany. Orckit is seeking injunctive relief, accounting and sales information, and a declaration of liability for damages as well as costs of the lawsuit. On October 13, 2020, the Court issued an infringement decision against the Company and granted to Orckit the right to enforce the judgment against the Company, which Orckit has provided notification to the Company that it will enforce the judgment. In the rendering of account, Orckit was informed that the products at issue were in end of sale status prior to the filing of the EP‘077 complaint. The Company has appealed the infringement decision, and the matter is proceeding through the appellate process.
  (was, 2022-01-28, similarity 0.9991):
[0001564590-22-003010:note_history:3]
On April 23, 2019, Orckit filed an extension of the patent infringement complaint against the Company and its Irish and German subsidiaries in the District Court in Dusseldorf, Germany. With this extension, Orckit alleges infringement of the German portion of a second patent (“EP ‘077”) based on the offer, distribution, use, possession and/or importation into Germany of certain network switches that the Company no longer sells in Germany. Orckit is seeking injunctive relief, accounting and sales information, and a declaration of liability for damages as well as costs of the lawsuit. On October 13, 2020, the Court issued an infringement decision against the Company and granted to Orckit the right to enforce the judgment against the Company, which Orckit has provided notification to the Company that it will enforce the judgment. In the rendering of account, Orckit was informed that the products at issue were in end of sale status prior to the filing of the ‘077 complaint. The Company has appealed the infringement decision, and the matter is proceeding through the appellate process.

- changed (2022-04-29):
[0001564590-22-016543:note_history:4]
The Company filed a nullity action related to the EP ‘364 patent on May 3, 2018, and one related to the EP ‘077 patent on October 31, 2019, both in the Federal Patent Court in Munich. The court found the EP ‘364 patent to be valid and the Company has filed an appeal.  The case filed to seek to invalidate the EP ‘077 patent is proceeding, with a hearing to be held June 29, 2022.
  (was, 2022-01-28, similarity 0.945):
[0001564590-22-003010:note_history:4]
The Company filed a nullity action related to the EP ‘364 patent on May 3, 2018, and one related to the EP ‘077 patent on October 31, 2019, both in the Federal Patent Court in Munich. The court found the EP ‘364 patent to be valid and the Company has filed an appeal.  The case filed to seek to invalidate the EP ‘077 patent is proceeding.

- removed (2022-04-29):
[0001564590-22-003010:note_history:5]
royalties, pre- and post-judgment interest, and attorneys’ fees. The Court has dismissed the case with prejudice.  The deadline for XR to appeal the dismissal is February 3, 2022.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2022-04-29):
[0001564590-22-016543:note_history:6]
The unaudited condensed consolidated financial statements reflect all adjustments, consisting only of normal recurring adjustments that, in the opinion of management, are necessary for a fair presentation of the results of operations and cash flows for the interim periods presented and the financial condition of Extreme at March 31, 2022. The results of operations for the three and nine months ended March 31, 2022 are not necessarily indicative of the results that may be expected for fiscal 2022 or any future periods.
  (was, 2022-01-28, similarity 0.9404):
[0001564590-22-003010:note_history:6]
The unaudited condensed consolidated financial statements reflect all adjustments, consisting only of normal recurring adjustments that, in the opinion of management, are necessary for a fair presentation of the results of operations and cash flows for the interim periods presented and the financial condition of Extreme at December 31, 2021. The results of operations for the three and six months ended December 31, 2021 are not necessarily indicative of the results that may be expected for fiscal 2022 or any future periods.


## us-gaap:SignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2022-04-29):
[0001564590-22-016543:note_history:7]
In October 2021, the FASB issued ASU 2021-08, Business Combinations (Topic 805): Accounting for Contract Assets and Contract Liabilities from Contracts with Customers, which requires contract assets and contract liabilities acquired in a business combination to be recognized and measured by the acquirer on the acquisition date in accordance with ASC 606, Revenue from Contracts with Customers, as if it had originated the contracts. Under the current business combinations guidance, such assets and liabilities are recognized by the acquirer at fair value on the acquisition date. ASU 2021-08 is effective for annual periods beginning after December 15, 2022 and interim periods within those annual periods, with early adoption permitted, including adoption in an interim period. The Company elected to early adopt the standard in the quarter ended December 31, 2021 and retrospectively applied the standard to the acquisition that happened in the current fiscal year beginning July 1, 2021. The application of the guidance increased the deferred revenue balance acquired through the acquisition of Ipanema by $7.1 million as of the acquisition date.
  (was, 2022-01-28, similarity 0.9982):
[0001564590-22-003010:note_history:7]
In October 2021, the FASB issued ASU 2021-08, Business Combinations (Topic 805): Accounting for Contract Assets and Contract Liabilities from Contracts with Customers, which requires contract assets and contract liabilities acquired in a business combination to be recognized and measured by the acquirer on the acquisition date in accordance with ASC 606, Revenue from Contracts with Customers, as if it had originated the contracts. Under the current business combinations guidance, such assets and liabilities are recognized by the acquirer at fair value on the acquisition date. ASU 2021-08 is effective for annual periods beginning after December 15, 2022 and interim periods within those annual periods, with early adoption permitted, including adoption in an interim period. The Company has elected to early adopt the standard in the quarter ended December 31, 2021 and retrospectively applied the standard to the acquisition that happened in the current fiscal year beginning July 1, 2021. The application of the guidance increased the deferred revenue balance acquired through the acquisition of Ipanema by $7.1 million as of the acquisition date.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2022-04-29):
[0001564590-22-016543:note_history:8]
|  |  | March 31, 2022 |  |  | June 30, 2021 |  |
| Current portion of long-term debt: |  |  |  |  |  |  |  |  |
| Term Loan |  | $ | 33,250 |  |  | $ | 26,125 |  |
| Less: unamortized debt issuance costs |  |  | (2,305 | ) |  |  | (2,404 | ) |
| Current portion of long-term debt |  | $ | 30,945 |  |  | $ | 23,721 |  |
| Long-term debt, less current portion: |  |  |  |  |  |  |  |  |
| Term Loan |  | $ | 282,500 |  |  | $ | 320,625 |  |
| Less: unamortized debt issuance costs |  |  | (2,986 | ) |  |  | (4,760 | ) |
| Total long-term debt, less current portion |  |  | 279,514 |  |  |  | 315,865 |  |
| Total debt |  | $ | 310,459 |  |  | $ | 339,586 |  |
  (was, 2022-01-28, similarity 0.9877):
[0001564590-22-003010:note_history:8]
|  |  | December 31, 2021 |  |  | June 30, 2021 |  |
| Current portion of long-term debt: |  |  |  |  |  |  |  |  |
| Term Loan |  | $ | 30,875 |  |  | $ | 26,125 |  |
| Less: unamortized debt issuance costs |  |  | (2,333 | ) |  |  | (2,404 | ) |
| Current portion of long-term debt |  | $ | 28,542 |  |  | $ | 23,721 |  |
| Long-term debt, less current portion: |  |  |  |  |  |  |  |  |
| Term Loan |  | $ | 292,000 |  |  | $ | 320,625 |  |
| Less: unamortized debt issuance costs |  |  | (3,542 | ) |  |  | (4,760 | ) |
| Total long-term debt, less current portion |  |  | 288,458 |  |  |  | 315,865 |  |
| Total debt |  | $ | 317,000 |  |  | $ | 339,586 |  |

- changed (2022-04-29):
[0001564590-22-016543:note_history:9]
Financing costs incurred in connection with obtaining long-term financing are deferred and amortized over the term of the related indebtedness or credit agreement. During the year ended June 30, 2020, the Company incurred $10.5 million of deferred financing costs in conjunction with the 2019 Credit Agreement and $1.5 million of deferred financing costs from the amendments, and continues to amortize $1.6 million of debt issuance costs as of August 9, 2019 that were associated with the previous facility. The interest rate as of March 31, 2022 was 2.07% and as of March 31, 2021 was 4.60%.
  (was, 2022-01-28, similarity 0.9767):
[0001564590-22-003010:note_history:9]
Financing costs incurred in connection with obtaining long-term financing are deferred and amortized over the term of the related indebtedness or credit agreement. During the year ended June 30, 2020, the Company incurred $10.5 million of deferred financing costs in conjunction with the 2019 Credit Agreement and $1.5 million of deferred financing costs from the amendments, and continues to amortize $1.6 million of debt issuance costs as of August 9, 2019 that were associated with the previous facility. The interest rate as of December 31, 2021 was 1.86% and as of December 31, 2020 was 4.65%.

- added (2022-04-29):
[0001564590-22-016543:note_history:10]
Amortization of deferred financing costs included in “Interest expense” in the accompanying condensed consolidated statements of operations were $0.7 million each for the three months ended March 31, 2022 and 2021 and were $2.3 million each for the nine months ended March 31, 2022 and 2021.

- changed (2022-04-29):
[0001564590-22-016543:note_history:11]
During the fiscal year ended June 30, 2021, the Company repaid $55.0 million against its 2019 Revolving Facility’s outstanding balance of $55.0 million and had no remaining outstanding balance at March 31, 2022. The Company had $60.2 million of availability under the 2019 Revolving Facility as of March 31, 2022. During the nine months ended March 31, 2022, the Company made an additional payment of $12.0 million against its term loan facility.
  (was, 2022-01-28, similarity 0.8701):
[0001564590-22-003010:note_history:11]
During the fiscal year ended June 30, 2021, the Company repaid $55.0 million against its 2019 Revolving Facility’s outstanding balance of $55.0 million and had no remaining outstanding balance at December 31, 2021. The Company had $60.2 million of availability under the 2019 Revolving Facility as of December 31, 2021. During the six months ended December 31, 2021, the Company made an additional payment of $12.0 million against its term loan facility.

- changed (2022-04-29):
[0001564590-22-016543:note_history:12]
The Company had $14.8 million of outstanding letters of credit as of March 31, 2022.
  (was, 2022-01-28, similarity 0.9412):
[0001564590-22-003010:note_history:12]
The Company had $14.8 million of outstanding letters of credit as of December 31, 2021.

- removed (2022-04-29):
[0001564590-22-003010:note_history:13]
Amortization of deferred financing costs included in “Interest expense” in the accompanying condensed consolidated statements of operations totaled $0.7 million and $0.8 million for the three months ended December 31, 2021 and 2020, and totaled $1.5 million each for the six months ended December 31, 2021 and 2020.


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2022-04-29):
[0001564590-22-016543:note_history:14]
|  |  | March 31, 2022 |  |  | June 30, 2021 |  |
| Current portion of long-term debt: |  |  |  |  |  |  |  |  |
| Term Loan |  | $ | 33,250 |  |  | $ | 26,125 |  |
| Less: unamortized debt issuance costs |  |  | (2,305 | ) |  |  | (2,404 | ) |
| Current portion of long-term debt |  | $ | 30,945 |  |  | $ | 23,721 |  |
| Long-term debt, less current portion: |  |  |  |  |  |  |  |  |
| Term Loan |  | $ | 282,500 |  |  | $ | 320,625 |  |
| Less: unamortized debt issuance costs |  |  | (2,986 | ) |  |  | (4,760 | ) |
| Total long-term debt, less current portion |  |  | 279,514 |  |  |  | 315,865 |  |
| Total debt |  | $ | 310,459 |  |  | $ | 339,586 |  |
  (was, 2022-01-28, similarity 0.9877):
[0001564590-22-003010:note_history:14]
|  |  | December 31, 2021 |  |  | June 30, 2021 |  |
| Current portion of long-term debt: |  |  |  |  |  |  |  |  |
| Term Loan |  | $ | 30,875 |  |  | $ | 26,125 |  |
| Less: unamortized debt issuance costs |  |  | (2,333 | ) |  |  | (2,404 | ) |
| Current portion of long-term debt |  | $ | 28,542 |  |  | $ | 23,721 |  |
| Long-term debt, less current portion: |  |  |  |  |  |  |  |  |
| Term Loan |  | $ | 292,000 |  |  | $ | 320,625 |  |
| Less: unamortized debt issuance costs |  |  | (3,542 | ) |  |  | (4,760 | ) |
| Total long-term debt, less current portion |  |  | 288,458 |  |  |  | 315,865 |  |
| Total debt |  | $ | 317,000 |  |  | $ | 339,586 |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2022-04-29):
[0001564590-22-016543:note_history:15]
|  |  | Three Months Ended |  |
|  |  | March 31, 2022 |  |  | March 31, 2021 |  |
|  |  | Distributor |  | Direct |  | Total |  |  | Distributor |  | Direct |  | Total |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  | $ | 59,582 |  | $ | 60,852 |  | $ | 120,434 |  |  | $ | 54,873 |  | $ | 62,172 |  | $ | 117,045 |  |
| Other |  |  | 7,574 |  |  | 3,513 |  |  | 11,087 |  |  |  | 8,926 |  |  | 3,730 |  |  | 12,656 |  |
| Total Americas |  |  | 67,156 |  |  | 64,365 |  |  | 131,521 |  |  |  | 63,799 |  |  | 65,902 |  |  | 129,701 |  |
| EMEA |  |  | 101,980 |  |  | 36,844 |  |  | 138,824 |  |  |  | 65,210 |  |  | 34,127 |  |  | 99,337 |  |
| APAC |  |  | 40 |  |  | 15,123 |  |  | 15,163 |  |  |  | 3,569 |  |  | 20,793 |  |  | 24,362 |  |
| Total net revenues |  | $ | 169,176 |  | $ | 116,332 |  | $ | 285,508 |  |  | $ | 132,578 |  | $ | 120,822 |  | $ | 253,400 |  |
  (was, 2022-01-28, similarity 0.9665):
[0001564590-22-003010:note_history:15]
|  |  | Three Months Ended |  |
|  |  | December 31, 2021 |  |  | December 31, 2020 |  |
|  |  | Distributor |  | Direct |  | Total |  |  | Distributor |  | Direct |  | Total |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  | $ | 68,565 |  | $ | 68,585 |  | $ | 137,150 |  |  | $ | 46,506 |  | $ | 58,744 |  | $ | 105,250 |  |
| Other |  |  | 3,865 |  |  | 4,955 |  |  | 8,820 |  |  |  | 8,950 |  |  | 3,648 |  |  | 12,598 |  |
| Total Americas |  |  | 72,430 |  |  | 73,540 |  |  | 145,970 |  |  |  | 55,456 |  |  | 62,392 |  |  | 117,848 |  |
| EMEA |  |  | 68,934 |  |  | 42,128 |  |  | 111,062 |  |  |  | 69,602 |  |  | 34,220 |  |  | 103,822 |  |
| APAC |  |  | 5,034 |  |  | 18,867 |  |  | 23,901 |  |  |  | 2,793 |  |  | 17,665 |  |  | 20,458 |  |
| Total net revenues |  | $ | 146,398 |  | $ | 134,535 |  | $ | 280,933 |  |  | $ | 127,851 |  | $ | 114,277 |  | $ | 242,128 |  |

- changed (2022-04-29):
[0001564590-22-016543:note_history:16]
|  |  | Nine Months Ended |  |
|  |  | March 31, 2022 |  |  | March 31, 2021 |  |
|  |  | Distributor |  | Direct |  | Total |  |  | Distributor |  | Direct |  | Total |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  | $ | 184,215 |  | $ | 196,768 |  | $ | 380,983 |  |  | $ | 162,049 |  | $ | 178,263 |  | $ | 340,312 |  |
| Other |  |  | 19,238 |  |  | 11,835 |  |  | 31,073 |  |  |  | 26,117 |  |  | 11,468 |  |  | 37,585 |  |
| Total Americas |  |  | 203,453 |  |  | 208,603 |  |  | 412,056 |  |  |  | 188,166 |  |  | 189,731 |  |  | 377,897 |  |
| EMEA |  |  | 248,812 |  |  | 114,703 |  |  | 363,515 |  |  |  | 182,341 |  |  | 101,923 |  |  | 284,264 |  |
| APAC |  |  | 9,409 |  |  | 49,145 |  |  | 58,554 |  |  |  | 11,413 |  |  | 57,756 |  |  | 69,169 |  |
| Total net revenues |  | $ | 461,674 |  | $ | 372,451 |  | $ | 834,125 |  |  | $ | 381,920 |  | $ | 349,410 |  | $ | 731,330 |  |
  (was, 2022-01-28, similarity 0.9241):
[0001564590-22-003010:note_history:16]
|  |  | Six Months Ended |  |
|  |  | December 31, 2021 |  |  | December 31, 2020 |  |
|  |  | Distributor |  | Direct |  | Total |  |  | Distributor |  | Direct |  | Total |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  | $ | 124,633 |  | $ | 135,916 |  | $ | 260,549 |  |  | $ | 107,176 |  | $ | 116,091 |  | $ | 223,267 |  |
| Other |  |  | 11,664 |  |  | 8,322 |  |  | 19,986 |  |  |  | 17,191 |  |  | 7,738 |  |  | 24,929 |  |
| Total Americas |  |  | 136,297 |  |  | 144,238 |  |  | 280,535 |  |  |  | 124,367 |  |  | 123,829 |  |  | 248,196 |  |
| EMEA |  |  | 146,832 |  |  | 77,859 |  |  | 224,691 |  |  |  | 117,131 |  |  | 67,796 |  |  | 184,927 |  |
| APAC |  |  | 9,369 |  |  | 34,022 |  |  | 43,391 |  |  |  | 7,844 |  |  | 36,963 |  |  | 44,807 |  |
| Total net revenues |  | $ | 292,498 |  | $ | 256,119 |  | $ | 548,617 |  |  | $ | 249,342 |  | $ | 228,588 |  | $ | 477,930 |  |

- added (2022-04-29):
[0001564590-22-016543:note_history:17]
For the three months ended March 31, 2022 and 2021, the Company generated 18% and 11% of its revenues from the Netherlands. For the nine months ended March 31, 2022 and 2021, the Company generated 12% and 10% of its revenues from the Netherlands. No other foreign country accounted for 10% or more of revenue for the three and nine months ended March 31, 2022 or 2021.

- removed (2022-04-29):
[0001564590-22-003010:note_history:18]
For the six months ended December 31, 2021, the Company generated 10% of its revenues from the Netherlands. For the three months ended December 31, 2020, the Company generated 11% of its revenues from the Netherlands and 11% of its revenues from Germany. For the six months ended December 31, 2020, the Company generated 10% of its revenues from the Netherlands and 10% of its revenues from Germany. No other foreign country accounted for 10% or more of revenue for the three and six months ended December 31, 2021 or 2020.


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2022-04-29):
[0001564590-22-016543:note_history:19]
On March 31, 2022, the Company had $372.4 million of remaining performance obligations, which are primarily comprised of deferred maintenance and SaaS revenues. The Company expects to recognize approximately 21% of its deferred revenue as revenue in fiscal 2022, an additional 45% in fiscal 2023 and 34% of the balance thereafter.
  (was, 2022-01-28, similarity 0.9791):
[0001564590-22-003010:note_history:19]
On December 31, 2021, the Company had $373.2 million of remaining performance obligations, which are primarily comprised of deferred maintenance and SaaS revenues. The Company expects to recognize approximately 38% of its deferred revenue as revenue in fiscal 2022, an additional 34% in fiscal 2023 and 28% of the balance thereafter.

- changed (2022-04-29):
[0001564590-22-016543:note_history:20]
Revenue recognized for the three months ended March 31, 2022 and 2021 that was included in the deferred revenue balance at the beginning of each period was $77.3 million and $67.9 million, respectively. Revenue recognized for the nine months ended March 31, 2022 and 2021 that was included in the deferred revenue balance at the beginning of each period was $176.1 million and $158.7 million, respectively.
  (was, 2022-01-28, similarity 0.9194):
[0001564590-22-003010:note_history:20]
Revenue recognized for the three months ended December 31, 2021 and 2020 that was included in the deferred revenue balance at the beginning of each period was $81.9 million and $68.8 million, respectively. Revenue recognized for the six months ended December 31, 2021 and 2020 that was included in the deferred revenue balance at the beginning of each period was $132.5 million and $120.5 million, respectively.

- changed (2022-04-29):
[0001564590-22-016543:note_history:21]
Contract Costs. The Company recognizes the incremental costs of obtaining contracts as an expense when incurred if the amortization period of the assets that the Company otherwise would have recognized is one year or less.  Management expects that commission fees paid to sales representatives as a result of obtaining service and subscription contracts and contract renewals are recoverable and therefore the Company’s condensed consolidated balance sheets included capitalized balances in the amount of $14.8 million and $13.1 million at March 31, 2022 and June 30, 2021, respectively. Capitalized commission fees are amortized on a straight-line basis over the average period of service contracts of approximately three years, and are included in “Sales and marketing” in the accompanying condensed consolidated statements of operations. Amortization recognized during the three months ended March 31, 2022 and 2021, was $1.9 million and $1.4 million, respectively. Amortization recognized during the nine months ended March 31, 2022 and 2021, was $5.5 million and $3.9 million, respectively.
  (was, 2022-01-28, similarity 0.9565):
[0001564590-22-003010:note_history:21]
Contract Costs. The Company recognizes the incremental costs of obtaining contracts as an expense when incurred if the amortization period of the assets that the Company otherwise would have recognized is one year or less.  Management expects that commission fees paid to sales representatives as a result of obtaining service contracts and contract renewals are recoverable and therefore the Company’s condensed consolidated balance sheets included capitalized balances in the amount of $14.2 million and $13.1 million at December 31, 2021 and June 30, 2021, respectively. Capitalized commission fees are amortized on a straight-line basis over the average period of service contracts of approximately three years, and are included in “Sales and marketing” in the accompanying condensed consolidated statements of operations. Amortization recognized during the three months ended December 31, 2021 and 2020, was $1.8 million and $1.2 million, respectively. Amortization recognized during the six months ended December 31, 2021 and 2020, was $3.6 million and $2.5 million, respectively.

- changed (2022-04-29):
[0001564590-22-016543:note_history:22]
|  |  | Three Months Ended |  |
|  |  | March 31, 2022 |  |  | March 31, 2021 |  |
|  |  | Distributor |  | Direct |  | Total |  |  | Distributor |  | Direct |  | Total |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  | $ | 59,582 |  | $ | 60,852 |  | $ | 120,434 |  |  | $ | 54,873 |  | $ | 62,172 |  | $ | 117,045 |  |
| Other |  |  | 7,574 |  |  | 3,513 |  |  | 11,087 |  |  |  | 8,926 |  |  | 3,730 |  |  | 12,656 |  |
| Total Americas |  |  | 67,156 |  |  | 64,365 |  |  | 131,521 |  |  |  | 63,799 |  |  | 65,902 |  |  | 129,701 |  |
| EMEA |  |  | 101,980 |  |  | 36,844 |  |  | 138,824 |  |  |  | 65,210 |  |  | 34,127 |  |  | 99,337 |  |
| APAC |  |  | 40 |  |  | 15,123 |  |  | 15,163 |  |  |  | 3,569 |  |  | 20,793 |  |  | 24,362 |  |
| Total net revenues |  | $ | 169,176 |  | $ | 116,332 |  | $ | 285,508 |  |  | $ | 132,578 |  | $ | 120,822 |  | $ | 253,400 |  |
  (was, 2022-01-28, similarity 0.9665):
[0001564590-22-003010:note_history:22]
|  |  | Three Months Ended |  |
|  |  | December 31, 2021 |  |  | December 31, 2020 |  |
|  |  | Distributor |  | Direct |  | Total |  |  | Distributor |  | Direct |  | Total |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  | $ | 68,565 |  | $ | 68,585 |  | $ | 137,150 |  |  | $ | 46,506 |  | $ | 58,744 |  | $ | 105,250 |  |
| Other |  |  | 3,865 |  |  | 4,955 |  |  | 8,820 |  |  |  | 8,950 |  |  | 3,648 |  |  | 12,598 |  |
| Total Americas |  |  | 72,430 |  |  | 73,540 |  |  | 145,970 |  |  |  | 55,456 |  |  | 62,392 |  |  | 117,848 |  |
| EMEA |  |  | 68,934 |  |  | 42,128 |  |  | 111,062 |  |  |  | 69,602 |  |  | 34,220 |  |  | 103,822 |  |
| APAC |  |  | 5,034 |  |  | 18,867 |  |  | 23,901 |  |  |  | 2,793 |  |  | 17,665 |  |  | 20,458 |  |
| Total net revenues |  | $ | 146,398 |  | $ | 134,535 |  | $ | 280,933 |  |  | $ | 127,851 |  | $ | 114,277 |  | $ | 242,128 |  |

- changed (2022-04-29):
[0001564590-22-016543:note_history:23]
|  |  | Nine Months Ended |  |
|  |  | March 31, 2022 |  |  | March 31, 2021 |  |
|  |  | Distributor |  | Direct |  | Total |  |  | Distributor |  | Direct |  | Total |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  | $ | 184,215 |  | $ | 196,768 |  | $ | 380,983 |  |  | $ | 162,049 |  | $ | 178,263 |  | $ | 340,312 |  |
| Other |  |  | 19,238 |  |  | 11,835 |  |  | 31,073 |  |  |  | 26,117 |  |  | 11,468 |  |  | 37,585 |  |
| Total Americas |  |  | 203,453 |  |  | 208,603 |  |  | 412,056 |  |  |  | 188,166 |  |  | 189,731 |  |  | 377,897 |  |
| EMEA |  |  | 248,812 |  |  | 114,703 |  |  | 363,515 |  |  |  | 182,341 |  |  | 101,923 |  |  | 284,264 |  |
| APAC |  |  | 9,409 |  |  | 49,145 |  |  | 58,554 |  |  |  | 11,413 |  |  | 57,756 |  |  | 69,169 |  |
| Total net revenues |  | $ | 461,674 |  | $ | 372,451 |  | $ | 834,125 |  |  | $ | 381,920 |  | $ | 349,410 |  | $ | 731,330 |  |
  (was, 2022-01-28, similarity 0.9241):
[0001564590-22-003010:note_history:23]
|  |  | Six Months Ended |  |
|  |  | December 31, 2021 |  |  | December 31, 2020 |  |
|  |  | Distributor |  | Direct |  | Total |  |  | Distributor |  | Direct |  | Total |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  | $ | 124,633 |  | $ | 135,916 |  | $ | 260,549 |  |  | $ | 107,176 |  | $ | 116,091 |  | $ | 223,267 |  |
| Other |  |  | 11,664 |  |  | 8,322 |  |  | 19,986 |  |  |  | 17,191 |  |  | 7,738 |  |  | 24,929 |  |
| Total Americas |  |  | 136,297 |  |  | 144,238 |  |  | 280,535 |  |  |  | 124,367 |  |  | 123,829 |  |  | 248,196 |  |
| EMEA |  |  | 146,832 |  |  | 77,859 |  |  | 224,691 |  |  |  | 117,131 |  |  | 67,796 |  |  | 184,927 |  |
| APAC |  |  | 9,369 |  |  | 34,022 |  |  | 43,391 |  |  |  | 7,844 |  |  | 36,963 |  |  | 44,807 |  |
| Total net revenues |  | $ | 292,498 |  | $ | 256,119 |  | $ | 548,617 |  |  | $ | 249,342 |  | $ | 228,588 |  | $ | 477,930 |  |

- added (2022-04-29):
[0001564590-22-016543:note_history:24]
For the three months ended March 31, 2022 and 2021, the Company generated 18% and 11% of its revenues from the Netherlands. For the nine months ended March 31, 2022 and 2021, the Company generated 12% and 10% of its revenues from the Netherlands. No other foreign country accounted for 10% or more of revenue for the three and nine months ended March 31, 2022 or 2021.

- changed (2022-04-29):
[0001564590-22-016543:note_history:25]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | March 31, 2022 |  |  | March 31, 2021 |  |  | March 31, 2022 |  |  | March 31, 2021 |  |
| TD Synnex Corporation |  | 17% |  |  | 15% |  |  | 20% |  |  | 21% |  |
| Jenne Corporation |  | 20% |  |  | 16% |  |  | 17% |  |  | 14% |  |
| Westcon Group Inc. |  | 25% |  |  | 19% |  |  | 18% |  |  | 17% |  |
  (was, 2022-01-28, similarity 0.798):
[0001564590-22-003010:note_history:25]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | December 31, 2021 |  |  | December 31, 2020 |  |  | December 31, 2021 |  |  | December 31, 2020 |  |
| TD Synnex Corporation |  | 21% |  |  | 21% |  |  | 22% |  |  | 24% |  |
| Jenne Corporation |  | 18% |  |  | 11% |  |  | 16% |  |  | 13% |  |
| Westcon Group Inc. |  | 11% |  |  | 19% |  |  | 15% |  |  | 16% |  |

- changed (2022-04-29):
[0001564590-22-016543:note_history:26]
|  |  | March 31, 2022 |  |  | June 30, 2021 |  |
| TD Synnex Corporation |  | * |  |  | 19% |  |
| Jenne Corporation |  | 23% |  |  | 24% |  |
| Westcon Group Inc. |  | 29% |  |  | * |  |
| * Less than 10% of accounts receivable. |  |  |  |  |  |  |  |  |
  (was, 2022-01-28, similarity 0.8608):
[0001564590-22-003010:note_history:26]
|  |  | December 31, 2021 |  |  | June 30, 2021 |  |
| TD Synnex Corporation |  | 10% |  |  | 19% |  |
| Jenne Corporation |  | * |  |  | 24% |  |
| * Less than 10% of accounts receivable. |  |  |  |  |  |  |  |  |

- removed (2022-04-29):
[0001564590-22-003010:note_history:27]
For the six months ended December 31, 2021, the Company generated 10% of its revenues from the Netherlands. For the three months ended December 31, 2020, the Company generated 11% of its revenues from the Netherlands and 11% of its revenues from Germany. For the six months ended December 31, 2020, the Company generated 10% of its revenues from the Netherlands and 10% of its revenues from Germany. No other foreign country accounted for 10% or more of revenue for the three and six months ended December 31, 2021 or 2020.


## us-gaap:RevenueRecognitionPolicyTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2022-04-29):
[0001564590-22-016543:note_history:28]
On March 31, 2022, the Company had $372.4 million of remaining performance obligations, which are primarily comprised of deferred maintenance and SaaS revenues. The Company expects to recognize approximately 21% of its deferred revenue as revenue in fiscal 2022, an additional 45% in fiscal 2023 and 34% of the balance thereafter.
  (was, 2022-01-28, similarity 0.9791):
[0001564590-22-003010:note_history:28]
On December 31, 2021, the Company had $373.2 million of remaining performance obligations, which are primarily comprised of deferred maintenance and SaaS revenues. The Company expects to recognize approximately 38% of its deferred revenue as revenue in fiscal 2022, an additional 34% in fiscal 2023 and 28% of the balance thereafter.

- changed (2022-04-29):
[0001564590-22-016543:note_history:29]
Revenue recognized for the three months ended March 31, 2022 and 2021 that was included in the deferred revenue balance at the beginning of each period was $77.3 million and $67.9 million, respectively. Revenue recognized for the nine months ended March 31, 2022 and 2021 that was included in the deferred revenue balance at the beginning of each period was $176.1 million and $158.7 million, respectively.
  (was, 2022-01-28, similarity 0.9194):
[0001564590-22-003010:note_history:29]
Revenue recognized for the three months ended December 31, 2021 and 2020 that was included in the deferred revenue balance at the beginning of each period was $81.9 million and $68.8 million, respectively. Revenue recognized for the six months ended December 31, 2021 and 2020 that was included in the deferred revenue balance at the beginning of each period was $132.5 million and $120.5 million, respectively.

- changed (2022-04-29):
[0001564590-22-016543:note_history:30]
Contract Costs. The Company recognizes the incremental costs of obtaining contracts as an expense when incurred if the amortization period of the assets that the Company otherwise would have recognized is one year or less.  Management expects that commission fees paid to sales representatives as a result of obtaining service and subscription contracts and contract renewals are recoverable and therefore the Company’s condensed consolidated balance sheets included capitalized balances in the amount of $14.8 million and $13.1 million at March 31, 2022 and June 30, 2021, respectively. Capitalized commission fees are amortized on a straight-line basis over the average period of service contracts of approximately three years, and are included in “Sales and marketing” in the accompanying condensed consolidated statements of operations. Amortization recognized during the three months ended March 31, 2022 and 2021, was $1.9 million and $1.4 million, respectively. Amortization recognized during the nine months ended March 31, 2022 and 2021, was $5.5 million and $3.9 million, respectively.
  (was, 2022-01-28, similarity 0.9565):
[0001564590-22-003010:note_history:30]
Contract Costs. The Company recognizes the incremental costs of obtaining contracts as an expense when incurred if the amortization period of the assets that the Company otherwise would have recognized is one year or less.  Management expects that commission fees paid to sales representatives as a result of obtaining service contracts and contract renewals are recoverable and therefore the Company’s condensed consolidated balance sheets included capitalized balances in the amount of $14.2 million and $13.1 million at December 31, 2021 and June 30, 2021, respectively. Capitalized commission fees are amortized on a straight-line basis over the average period of service contracts of approximately three years, and are included in “Sales and marketing” in the accompanying condensed consolidated statements of operations. Amortization recognized during the three months ended December 31, 2021 and 2020, was $1.8 million and $1.2 million, respectively. Amortization recognized during the six months ended December 31, 2021 and 2020, was $3.6 million and $2.5 million, respectively.

- changed (2022-04-29):
[0001564590-22-016543:note_history:31]
|  |  | Three Months Ended |  |
|  |  | March 31, 2022 |  |  | March 31, 2021 |  |
|  |  | Distributor |  | Direct |  | Total |  |  | Distributor |  | Direct |  | Total |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  | $ | 59,582 |  | $ | 60,852 |  | $ | 120,434 |  |  | $ | 54,873 |  | $ | 62,172 |  | $ | 117,045 |  |
| Other |  |  | 7,574 |  |  | 3,513 |  |  | 11,087 |  |  |  | 8,926 |  |  | 3,730 |  |  | 12,656 |  |
| Total Americas |  |  | 67,156 |  |  | 64,365 |  |  | 131,521 |  |  |  | 63,799 |  |  | 65,902 |  |  | 129,701 |  |
| EMEA |  |  | 101,980 |  |  | 36,844 |  |  | 138,824 |  |  |  | 65,210 |  |  | 34,127 |  |  | 99,337 |  |
| APAC |  |  | 40 |  |  | 15,123 |  |  | 15,163 |  |  |  | 3,569 |  |  | 20,793 |  |  | 24,362 |  |
| Total net revenues |  | $ | 169,176 |  | $ | 116,332 |  | $ | 285,508 |  |  | $ | 132,578 |  | $ | 120,822 |  | $ | 253,400 |  |
  (was, 2022-01-28, similarity 0.9665):
[0001564590-22-003010:note_history:31]
|  |  | Three Months Ended |  |
|  |  | December 31, 2021 |  |  | December 31, 2020 |  |
|  |  | Distributor |  | Direct |  | Total |  |  | Distributor |  | Direct |  | Total |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  | $ | 68,565 |  | $ | 68,585 |  | $ | 137,150 |  |  | $ | 46,506 |  | $ | 58,744 |  | $ | 105,250 |  |
| Other |  |  | 3,865 |  |  | 4,955 |  |  | 8,820 |  |  |  | 8,950 |  |  | 3,648 |  |  | 12,598 |  |
| Total Americas |  |  | 72,430 |  |  | 73,540 |  |  | 145,970 |  |  |  | 55,456 |  |  | 62,392 |  |  | 117,848 |  |
| EMEA |  |  | 68,934 |  |  | 42,128 |  |  | 111,062 |  |  |  | 69,602 |  |  | 34,220 |  |  | 103,822 |  |
| APAC |  |  | 5,034 |  |  | 18,867 |  |  | 23,901 |  |  |  | 2,793 |  |  | 17,665 |  |  | 20,458 |  |
| Total net revenues |  | $ | 146,398 |  | $ | 134,535 |  | $ | 280,933 |  |  | $ | 127,851 |  | $ | 114,277 |  | $ | 242,128 |  |

- changed (2022-04-29):
[0001564590-22-016543:note_history:32]
|  |  | Nine Months Ended |  |
|  |  | March 31, 2022 |  |  | March 31, 2021 |  |
|  |  | Distributor |  | Direct |  | Total |  |  | Distributor |  | Direct |  | Total |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  | $ | 184,215 |  | $ | 196,768 |  | $ | 380,983 |  |  | $ | 162,049 |  | $ | 178,263 |  | $ | 340,312 |  |
| Other |  |  | 19,238 |  |  | 11,835 |  |  | 31,073 |  |  |  | 26,117 |  |  | 11,468 |  |  | 37,585 |  |
| Total Americas |  |  | 203,453 |  |  | 208,603 |  |  | 412,056 |  |  |  | 188,166 |  |  | 189,731 |  |  | 377,897 |  |
| EMEA |  |  | 248,812 |  |  | 114,703 |  |  | 363,515 |  |  |  | 182,341 |  |  | 101,923 |  |  | 284,264 |  |
| APAC |  |  | 9,409 |  |  | 49,145 |  |  | 58,554 |  |  |  | 11,413 |  |  | 57,756 |  |  | 69,169 |  |
| Total net revenues |  | $ | 461,674 |  | $ | 372,451 |  | $ | 834,125 |  |  | $ | 381,920 |  | $ | 349,410 |  | $ | 731,330 |  |
  (was, 2022-01-28, similarity 0.9241):
[0001564590-22-003010:note_history:32]
|  |  | Six Months Ended |  |
|  |  | December 31, 2021 |  |  | December 31, 2020 |  |
|  |  | Distributor |  | Direct |  | Total |  |  | Distributor |  | Direct |  | Total |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  | $ | 124,633 |  | $ | 135,916 |  | $ | 260,549 |  |  | $ | 107,176 |  | $ | 116,091 |  | $ | 223,267 |  |
| Other |  |  | 11,664 |  |  | 8,322 |  |  | 19,986 |  |  |  | 17,191 |  |  | 7,738 |  |  | 24,929 |  |
| Total Americas |  |  | 136,297 |  |  | 144,238 |  |  | 280,535 |  |  |  | 124,367 |  |  | 123,829 |  |  | 248,196 |  |
| EMEA |  |  | 146,832 |  |  | 77,859 |  |  | 224,691 |  |  |  | 117,131 |  |  | 67,796 |  |  | 184,927 |  |
| APAC |  |  | 9,369 |  |  | 34,022 |  |  | 43,391 |  |  |  | 7,844 |  |  | 36,963 |  |  | 44,807 |  |
| Total net revenues |  | $ | 292,498 |  | $ | 256,119 |  | $ | 548,617 |  |  | $ | 249,342 |  | $ | 228,588 |  | $ | 477,930 |  |

- added (2022-04-29):
[0001564590-22-016543:note_history:33]
For the three months ended March 31, 2022 and 2021, the Company generated 18% and 11% of its revenues from the Netherlands. For the nine months ended March 31, 2022 and 2021, the Company generated 12% and 10% of its revenues from the Netherlands. No other foreign country accounted for 10% or more of revenue for the three and nine months ended March 31, 2022 or 2021.

- removed (2022-04-29):
[0001564590-22-003010:note_history:34]
For the six months ended December 31, 2021, the Company generated 10% of its revenues from the Netherlands. For the three months ended December 31, 2020, the Company generated 11% of its revenues from the Netherlands and 11% of its revenues from Germany. For the six months ended December 31, 2020, the Company generated 10% of its revenues from the Netherlands and 10% of its revenues from Germany. No other foreign country accounted for 10% or more of revenue for the three and six months ended December 31, 2021 or 2020.
