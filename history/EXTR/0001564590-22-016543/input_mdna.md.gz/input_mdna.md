# EXTR MD&A — 0001564590-22-016543


## mdna

[0001564590-22-016543:mdna:1]
[same as prior period, unchanged from 0001564590-22-003010:mdna:1]

[0001564590-22-016543:mdna:2]
[same as prior period, unchanged from 0001564590-22-003010:mdna:2]

[0001564590-22-016543:mdna:3]
[same as prior period, unchanged from 0001564590-22-003010:mdna:3]

[0001564590-22-016543:mdna:4]
[same as prior period, unchanged from 0001564590-22-003010:mdna:4]

[0001564590-22-016543:mdna:5]
[same as prior period, unchanged from 0001564590-22-003010:mdna:5]

[0001564590-22-016543:mdna:6]
[same as prior period, unchanged from 0001564590-22-003010:mdna:6]

[0001564590-22-016543:mdna:7]
[same as prior period, unchanged from 0001564590-22-003010:mdna:7]

[0001564590-22-016543:mdna:8]
[same as prior period, unchanged from 0001564590-22-003010:mdna:8]

[0001564590-22-016543:mdna:9]
[same as prior period, unchanged from 0001564590-22-003010:mdna:9]

[0001564590-22-016543:mdna:10]
The global pandemic resulted in unprecedented change – from the physical footprint of offices, to supply chain operations, to how we connect. Organizations and workforces extend anywhere and everywhere.  IT leaders are now tasked with ensuring the global, hybrid workforce is functional and successful no matter where they are and ensure people can work wherever they want.

[0001564590-22-016543:mdna:11]
Extreme has recognized that the way we and our customers communicate has changed and has given rise to these distributed enterprise environments, or in other words, the Infinite Enterprise, which has three key tenets:

[0001564590-22-016543:mdna:12]
[same as prior period, unchanged from 0001564590-22-003010:mdna:12]

[0001564590-22-016543:mdna:13]
[same as prior period, unchanged from 0001564590-22-003010:mdna:13]

[0001564590-22-016543:mdna:14]
[same as prior period, unchanged from 0001564590-22-003010:mdna:14]

[0001564590-22-016543:mdna:15]
[same as prior period, unchanged from 0001564590-22-003010:mdna:15]

[0001564590-22-016543:mdna:16]
[same as prior period, unchanged from 0001564590-22-003010:mdna:16]

[0001564590-22-016543:mdna:17]
[same as prior period, unchanged from 0001564590-22-003010:mdna:17]

[0001564590-22-016543:mdna:18]
[same as prior period, unchanged from 0001564590-22-003010:mdna:18]

[0001564590-22-016543:mdna:19]
[same as prior period, unchanged from 0001564590-22-003010:mdna:19]

[0001564590-22-016543:mdna:20]
[same as prior period, unchanged from 0001564590-22-003010:mdna:20]

[0001564590-22-016543:mdna:21]
[same as prior period, unchanged from 0001564590-22-003010:mdna:21]

[0001564590-22-016543:mdna:22]
[same as prior period, unchanged from 0001564590-22-003010:mdna:22]

[0001564590-22-016543:mdna:23]
[same as prior period, unchanged from 0001564590-22-003010:mdna:23]

[0001564590-22-016543:mdna:24]
[same as prior period, unchanged from 0001564590-22-003010:mdna:24]

[0001564590-22-016543:mdna:25]
[same as prior period, unchanged from 0001564590-22-003010:mdna:25]

[0001564590-22-016543:mdna:26]
[same as prior period, unchanged from 0001564590-22-003010:mdna:26]

[0001564590-22-016543:mdna:27]
[same as prior period, unchanged from 0001564590-22-003010:mdna:27]

[0001564590-22-016543:mdna:28]
[same as prior period, unchanged from 0001564590-22-003010:mdna:28]

[0001564590-22-016543:mdna:29]
[same as prior period, unchanged from 0001564590-22-003010:mdna:29]

[0001564590-22-016543:mdna:30]
[same as prior period, unchanged from 0001564590-22-003010:mdna:30]

[0001564590-22-016543:mdna:31]
[same as prior period, unchanged from 0001564590-22-003010:mdna:31]

[0001564590-22-016543:mdna:32]
|  | o | Universal switches support fabric or traditional networking with a choice of cloud or on-premises (air-gapped or cloud connected) management. |

[0001564590-22-016543:mdna:33]
|  | o | Universal WiFi 6 APs support campus or distributed deployments with a choice of cloud or on-premises (air-gapped or cloud connected) management. |

[0001564590-22-016543:mdna:34]
[same as prior period, unchanged from 0001564590-22-003010:mdna:34]

[0001564590-22-016543:mdna:35]
[same as prior period, unchanged from 0001564590-22-003010:mdna:35]

[0001564590-22-016543:mdna:36]
[same as prior period, unchanged from 0001564590-22-003010:mdna:36]

[0001564590-22-016543:mdna:37]
[same as prior period, unchanged from 0001564590-22-003010:mdna:37]

[0001564590-22-016543:mdna:38]
[same as prior period, unchanged from 0001564590-22-003010:mdna:38]

[0001564590-22-016543:mdna:39]
[same as prior period, unchanged from 0001564590-22-003010:mdna:39]

[0001564590-22-016543:mdna:40]
[same as prior period, unchanged from 0001564590-22-003010:mdna:40]

[0001564590-22-016543:mdna:41]
[same as prior period, unchanged from 0001564590-22-003010:mdna:41]

[0001564590-22-016543:mdna:42]
[same as prior period, unchanged from 0001564590-22-003010:mdna:42]

[0001564590-22-016543:mdna:43]
[same as prior period, unchanged from 0001564590-22-003010:mdna:43]

[0001564590-22-016543:mdna:44]
[same as prior period, unchanged from 0001564590-22-003010:mdna:44]

[0001564590-22-016543:mdna:45]
[same as prior period, unchanged from 0001564590-22-003010:mdna:45]

[0001564590-22-016543:mdna:46]
[same as prior period, unchanged from 0001564590-22-003010:mdna:46]

[0001564590-22-016543:mdna:47]
[same as prior period, unchanged from 0001564590-22-003010:mdna:47]

[0001564590-22-016543:mdna:48]
During the third quarter of fiscal 2022, we achieved the following results:

[0001564590-22-016543:mdna:49]
|  | • | Net revenues of $285.5 million compared to $253.4 million in the third quarter of fiscal 2021. |

[0001564590-22-016543:mdna:50]
|  | • | Product revenues of $198.4 million compared to $176.3 million in the third quarter of fiscal 2021. |

[0001564590-22-016543:mdna:51]
|  | • | Service and subscription revenues of $87.1 million compared to $77.1 million in the third quarter of fiscal 2021. |

[0001564590-22-016543:mdna:52]
|  | • | Total gross margin of 56.5% of net revenues compared to 58.7% of net revenues in the third quarter of fiscal 2021. |

[0001564590-22-016543:mdna:53]
|  | • | Operating income of $17.3 million compared to $11.2 million in the third quarter of fiscal 2021. |

[0001564590-22-016543:mdna:54]
|  | • | Net income of $12.8 million compared to $3.5 million in the third quarter of fiscal 2021. |

[0001564590-22-016543:mdna:55]
During the first nine months of fiscal 2022, we reflected the following results:

[0001564590-22-016543:mdna:56]
|  | • | Cash flows provided by operating activities of $64.1 million compared to $87.5 million in the nine months ended March 31, 2021. |

[0001564590-22-016543:mdna:57]
|  | • | Cash of $166.6 million as of March 31, 2022 compared to $246.9 million as of June 30, 2021. |

[0001564590-22-016543:mdna:58]
[same as prior period, unchanged from 0001564590-22-003010:mdna:58]

[0001564590-22-016543:mdna:59]
[same as prior period, unchanged from 0001564590-22-003010:mdna:59]

[0001564590-22-016543:mdna:60]
[same as prior period, unchanged from 0001564590-22-003010:mdna:60]

[0001564590-22-016543:mdna:61]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |  |
|  |  | March 31, 2022 |  |  | March 31, 2021 |  |  | $ Change |  |  | % Change |  |  | March 31, 2022 |  |  | March 31, 2021 |  |  | $ Change |  |  | % Change |  |  |
| Net revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 198,373 |  |  | $ | 176,334 |  |  | $ | 22,039 |  |  |  | 12.5 | % |  | $ | 574,636 |  |  | $ | 503,575 |  |  | $ | 71,061 |  |  |  | 14.1 | % |  |
| Percentage of net revenues |  |  | 69.5 | % |  |  | 69.6 | % |  |  |  |  |  |  |  |  |  |  | 68.9 | % |  |  | 68.9 | % |  |  |  |  |  |  |  |  |  |
| Service and subscription |  |  | 87,135 |  |  |  | 77,066 |  |  |  | 10,069 |  |  |  | 13.1 | % |  |  | 259,489 |  |  |  | 227,755 |  |  |  | 31,734 |  |  |  | 13.9 | % |  |
| Percentage of net revenues |  |  | 30.5 | % |  |  | 30.4 | % |  |  |  |  |  |  |  |  |  |  | 31.1 | % |  |  | 31.1 | % |  |  |  |  |  |  |  |  |  |
| Total net revenues |  | $ | 285,508 |  |  | $ | 253,400 |  |  | $ | 32,108 |  |  |  | 12.7 | % |  | $ | 834,125 |  |  | $ | 731,330 |  |  | $ | 102,795 |  |  |  | 14.1 | % |  |

[0001564590-22-016543:mdna:62]
Product revenues increased $22.0 million or 12.5% for the three months ended March 31, 2022, as compared to the corresponding period of fiscal 2021. Product revenues increased $71.1million or 14.1% for the nine months ended March 31, 2022, as compared to the corresponding period of fiscal 2021. The product revenues increase was primarily due to stronger demand for our products and also due to the material slow-down in global demand during the corresponding period of fiscal 2021 due to the global outbreak of COVID-19.

[0001564590-22-016543:mdna:63]
Service and subscription revenues increased $10.1 million, or 13.1% for the three months ended March 31, 2022 as compared to the corresponding period in fiscal 2021. Service and subscription revenues increased $31.7 million, or 13.9% for the nine months ended March 31, 2022 as compared to the corresponding period in fiscal 2021. The increase in service and subscription revenues was primarily due to the growth in our subscription revenues and partially due to the acquisition of Ipanema.

[0001564590-22-016543:mdna:64]
[same as prior period, unchanged from 0001564590-22-003010:mdna:65]

[0001564590-22-016543:mdna:65]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |  |
|  |  | March 31, 2022 |  |  | March 31, 2021 |  |  | $ Change |  |  | % Change |  |  | March 31, 2022 |  |  | March 31, 2021 |  |  | $ Change |  |  | % Change |  |  |
| Gross profit: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 105,791 |  |  | $ | 99,892 |  |  | $ | 5,899 |  |  |  | 5.9 | % |  | $ | 310,177 |  |  | $ | 279,733 |  |  | $ | 30,444 |  |  |  | 10.9 | % |  |
| Percentage of product revenues |  |  | 53.3 | % |  |  | 56.6 | % |  |  |  |  |  |  |  |  |  |  | 54.0 | % |  |  | 55.5 | % |  |  |  |  |  |  |  |  |  |
| Service and subscription |  |  | 55,567 |  |  |  | 48,921 |  |  |  | 6,646 |  |  |  | 13.6 | % |  |  | 165,570 |  |  |  | 144,290 |  |  |  | 21,280 |  |  |  | 14.7 | % |  |
| Percentage of service and subscription revenues |  |  | 63.8 | % |  |  | 63.5 | % |  |  |  |  |  |  |  |  |  |  | 63.8 | % |  |  | 63.4 | % |  |  |  |  |  |  |  |  |  |
| Total gross profit |  | $ | 161,358 |  |  | $ | 148,813 |  |  | $ | 12,545 |  |  |  | 8.4 | % |  | $ | 475,747 |  |  | $ | 424,023 |  |  | $ | 51,724 |  |  |  | 12.2 | % |  |
| Percentage of net revenues |  |  | 56.5 | % |  |  | 58.7 | % |  |  |  |  |  |  |  |  |  |  | 57.0 | % |  |  | 58.0 | % |  |  |  |  |  |  |  |  |  |

[0001564590-22-016543:mdna:66]
Product gross profit increased $5.9 million or 5.9% for the three months ended March 31, 2022, as compared to the corresponding period in fiscal 2021. The increase in product gross profit was primarily due to increased revenues along with lower excess and obsolete inventory charges of $0.2 million and lower amortization of intangibles of $2.8 million due to certain intangibles being fully amortized, partially offset by higher product costs and higher distribution cost of $8.5 million primarily due to higher freight costs due to supply constraints.

[0001564590-22-016543:mdna:67]
Product gross profit increased $30.4 million or 10.9% for the nine months ended March 31, 2022, as compared to the corresponding period in fiscal 2021. The increase in product gross profit was primarily due to increased revenues along with lower excess and obsolete inventory charges of $2.6 million and lower amortization of intangibles of $6.7 million due to certain intangibles being fully amortized, partially offset by higher product costs and distribution cost of $13.1 million primarily due to higher freight costs due to supply constraints.

[0001564590-22-016543:mdna:68]
Service and subscription gross profit increased $6.6 million or 13.6% for the three months ended March 31, 2022, as compared to the corresponding period in fiscal 2021. Service and subscription gross profit increased $21.3 million or 14.7% for the nine months ended March 31, 2022, as compared to the corresponding period in fiscal 2021. The increases were primarily due to increased service and subscription revenues, partially offset by higher professional fees and increased cloud service costs.

[0001564590-22-016543:mdna:69]
[same as prior period, unchanged from 0001564590-22-003010:mdna:71]

[0001564590-22-016543:mdna:70]
[same as prior period, unchanged from 0001564590-22-003010:mdna:72]

[0001564590-22-016543:mdna:71]
|  |  | Three Months Ended |  | Nine Months Ended |  |
|  |  | March 31, 2022 |  |  | March 31, 2021 |  |  | $ Change |  |  | % Change |  | March 31, 2022 |  |  | March 31, 2021 |  |  | $ Change |  |  | % Change |  |
| Research and development |  | $ | 49,615 |  |  | $ | 48,909 |  |  | $ | 706 |  |  |  | 1.4 | % | $ | 145,461 |  |  | $ | 147,619 |  |  | $ | (2,158 | ) |  |  | (1.5 | )% |
| Sales and marketing |  |  | 72,840 |  |  |  | 70,898 |  |  |  | 1,942 |  |  |  | 2.7 | % |  | 213,932 |  |  |  | 201,955 |  |  |  | 11,977 |  |  |  | 5.9 | % |
| General and administrative |  |  | 17,714 |  |  |  | 16,023 |  |  |  | 1,691 |  |  |  | 10.6 | % |  | 52,594 |  |  |  | 48,844 |  |  |  | 3,750 |  |  |  | 7.7 | % |
| Acquisition and integration costs |  |  | 2,833 |  |  |  | — |  |  |  | 2,833 |  |  |  | 100.0 | % |  | 6,456 |  |  |  | 1,975 |  |  |  | 4,481 |  |  |  | 226.9 | % |
| Restructuring and related charges |  |  | 407 |  |  |  | 425 |  |  |  | (18 | ) |  |  | (4.2 | )% |  | 978 |  |  |  | 2,121 |  |  |  | (1,143 | ) |  |  | (53.9 | )% |
| Amortization of intangibles |  |  | 638 |  |  |  | 1,406 |  |  |  | (768 | ) |  |  | (54.6 | )% |  | 2,596 |  |  |  | 4,704 |  |  |  | (2,108 | ) |  |  | (44.8 | )% |
| Total operating expenses |  | $ | 144,047 |  |  | $ | 137,661 |  |  | $ | 6,386 |  |  |  | 4.6 | % | $ | 422,017 |  |  | $ | 407,218 |  |  | $ | 14,799 |  |  |  | 3.6 | % |

[0001564590-22-016543:mdna:72]
[same as prior period, unchanged from 0001564590-22-003010:mdna:74]

[0001564590-22-016543:mdna:73]
[same as prior period, unchanged from 0001564590-22-003010:mdna:75]

[0001564590-22-016543:mdna:74]
Research and development expenses increased by $0.7 million or 1.4% for the three months ended March 31, 2022, as compared to the corresponding period in fiscal 2021. The increase in research and development expenses was primarily due to a $0.6 million increase in personnel related costs, a $0.4 million increase in software licenses and engineering project costs, a $0.3 million increase in equipment related and other costs, partially offset by a $0.6 million decrease in facility and information technology costs.

[0001564590-22-016543:mdna:75]
Research and development expenses decreased by $2.2 million or 1.5% for the nine months ended March 31, 2022, as compared to the corresponding period in fiscal 2021. The decrease in research and development expenses was primarily due to a $2.7 million decrease in facility and information technology costs, a $1.4 million decrease in software licenses and engineering project costs and lower equipment related costs and a $0.5 million decrease in other costs, partially offset by a $2.4 million increase in personnel related costs.

[0001564590-22-016543:mdna:76]
[same as prior period, unchanged from 0001564590-22-003010:mdna:78]

[0001564590-22-016543:mdna:77]
[same as prior period, unchanged from 0001564590-22-003010:mdna:79]

[0001564590-22-016543:mdna:78]
Sales and marketing expenses increased by $1.9 million or 2.7% for the three months ended March 31, 2022, as compared to the corresponding period in fiscal 2021. The increase in sales and marketing expenses was primarily due to a $0.5 million increase in personnel costs primarily due to higher compensation and benefits costs, a $1.0 million increase in travel costs and a $0.7 million increase in marketing and facilities related costs, partially offset by a $0.2 million decrease in other expenses.

[0001564590-22-016543:mdna:79]
Sales and marketing expenses increased by $12.0 million or 5.9% for the nine months ended March 31, 2022, as compared to the corresponding period in fiscal 2021. The increase in sales and marketing expenses was primarily due to a $8.5 million increase in personnel costs due to higher compensation and benefits costs due to increase in headcount, a $3.1 million increase in travel costs and a $1.7 million increase in facilities related costs and other expenses primarily marketing and sales promotions costs, partially offset by a $0.7 million decrease in professional fees and a $0.8 million decrease in equipment related expenses.

[0001564590-22-016543:mdna:80]
[same as prior period, unchanged from 0001564590-22-003010:mdna:82]

[0001564590-22-016543:mdna:81]
[same as prior period, unchanged from 0001564590-22-003010:mdna:83]

[0001564590-22-016543:mdna:82]
General and administrative expenses increased by $1.7 million or 10.6% for the three months ended March 31, 2022, as compared to the corresponding period in fiscal 2021. The increase in general and administrative expenses was primarily due to a $0.9 million increase in personnel costs due to higher compensation and benefits cost, a $0.7 million increase in equipment related costs and a $0.5 million increase in travel costs, partially offset by a $0.2 million decrease in legal and professional fees and a $0.2 million decrease in facilities and related costs.

[0001564590-22-016543:mdna:83]
General and administrative expenses increased by $3.8 million or 7.7% for the nine months ended March 31, 2022, as compared to the corresponding period in fiscal 2021. The increase in general and administrative expense was primarily due to a $2.2 million increase in personnel costs primarily compensation expenses, a $1.2 million increase in equipment and software licensing costs and a $0.6 million increase in other expenses, primarily travel, partially offset by a $0.4 million decrease in other costs, primarily facilities and related costs.

[0001564590-22-016543:mdna:84]
[same as prior period, unchanged from 0001564590-22-003010:mdna:86]

[0001564590-22-016543:mdna:85]
During the three months ended March 31, 2022, we incurred acquisition and integration costs of $2.8 million. During the nine months ended March 31, 2022, we incurred $6.5 million of integration costs. Acquisition and integration costs for the three and nine months ended March 31, 2022 consisted primarily of professional fees for legal advisory services, system and product integrations, and financial and accounting services related to the acquisition of Ipanema.

[0001564590-22-016543:mdna:86]
During the three months ended March 31, 2021 we did not incur any acquisition and integration costs. During the nine months ended March 31, 2021, we incurred $2.0 million of acquisition and integration costs. Acquisition and integration costs for the nine months ended March 31, 2021 consisted primarily of additional professional fees for system integration and financial services related to the Aerohive acquisition.

[0001564590-22-016543:mdna:87]
[same as prior period, unchanged from 0001564590-22-003010:mdna:89]

[0001564590-22-016543:mdna:88]
For the three and nine months ended March 31, 2022, we recorded restructuring and related charges of $0.4 million and $1.0 million respectively, which primarily comprised of facility-related charges related to our previously impaired facilities.

[0001564590-22-016543:mdna:89]
For the three and nine months ended March 31, 2021, we recorded restructuring charges of $0.4 million and $2.1 million, respectively. We continued our cost reduction initiative began in the third quarter of fiscal 2020 and recorded related severance, benefits, and equipment relocation charges of less than $0.1 million and $1.2 million respectively, related to the 2020 Plan. In addition, we had facility-related charges of $0.3 million and $0.9 million, respectively, related to our previously impaired facilities.

[0001564590-22-016543:mdna:90]
[same as prior period, unchanged from 0001564590-22-003010:mdna:92]

[0001564590-22-016543:mdna:91]
During the three months ended March 31, 2022 and 2021, we recorded $0.6 million and $1.4 million, respectively, of operating expenses for amortization of intangibles. During the nine months ended March 31, 2022 and 2021, we recorded $2.6 million and $4.7 million, respectively, of operating expenses for amortization of intangibles. The decreases during the three and nine months ended March 31, 2022 were primarily due to lower amortization related to certain acquired intangibles from previous acquisitions becoming fully amortized.

[0001564590-22-016543:mdna:92]
[same as prior period, unchanged from 0001564590-22-003010:mdna:94]

[0001564590-22-016543:mdna:93]
During the three months ended March 31, 2022 and 2021, we recorded $2.8 million and $5.6 million, respectively, in interest expense.  During the nine months ended March 31, 2022 and 2021, we recorded $9.8 million and $18.3 million, respectively, in interest expense. The decrease in interest expense were primarily driven by lower average loan balances and lower average rates during the respective period under our Amended and Restated Credit Agreement (as amended, the “2019 Credit Agreement”), dated August 9, 2019, by and among us, as borrower, several banks and other financial institutions as Lenders, BMO Harris Bank N.A., as an issuing lender and swingline lender, Silicon Valley Bank, as an Issuing Lender, and Bank of Montreal, as administrative agent and collateral agent for the Lenders.

[0001564590-22-016543:mdna:94]
[same as prior period, unchanged from 0001564590-22-003010:mdna:96]

[0001564590-22-016543:mdna:95]
During the three months ended March 31, 2022 and 2021, we recorded other income, net of $0.1 million and $0.3 million, respectively. During the nine months ended March 31, 2022 and 2021, we recorded other income, net of $0.3 million and other expense, net of $1.6 million, respectively. The changes for the three and nine months ended March 31, 2022 were primarily due to foreign exchange impact from the revaluation of certain assets and liabilities denominated in foreign currencies into U.S. Dollars.

[0001564590-22-016543:mdna:96]
[same as prior period, unchanged from 0001564590-22-003010:mdna:98]

[0001564590-22-016543:mdna:97]
For the three months ended March 31, 2022 and 2021, we recorded an income tax provision of $1.9 million and $2.4 million. For the nine months ended March 31, 2022 and 2021, we recorded an income tax provision of $5.7 million and $5.6 million, respectively.

[0001564590-22-016543:mdna:98]
The income tax provisions for the three and nine months ended March 31, 2022 and 2021 consisted of (1) taxes on the income of our foreign subsidiaries, (2) foreign withholding taxes, (3) state taxes in jurisdictions where we have no remaining state net operating losses and (4) tax expense associated with the establishment of a U.S. deferred tax liability for amortizable goodwill resulting from the acquisition of Enterasys Networks, Inc., the WLAN Business, the Campus Fabric Business and the Data Center Business.

[0001564590-22-016543:mdna:99]
[same as prior period, unchanged from 0001564590-22-003010:mdna:101]

[0001564590-22-016543:mdna:100]
[same as prior period, unchanged from 0001564590-22-003010:mdna:102]

[0001564590-22-016543:mdna:101]
[same as prior period, unchanged from 0001564590-22-003010:mdna:103]

[0001564590-22-016543:mdna:102]
[same as prior period, unchanged from 0001564590-22-003010:mdna:104]

[0001564590-22-016543:mdna:103]
[same as prior period, unchanged from 0001564590-22-003010:mdna:105]

[0001564590-22-016543:mdna:104]
[same as prior period, unchanged from 0001564590-22-003010:mdna:106]

[0001564590-22-016543:mdna:105]
[same as prior period, unchanged from 0001564590-22-003010:mdna:107]

[0001564590-22-016543:mdna:106]
[same as prior period, unchanged from 0001564590-22-003010:mdna:108]

[0001564590-22-016543:mdna:107]
|  |  | March 31, 2022 |  |  | June 30, 2021 |  |
| Cash |  | $ | 166,566 |  |  | $ | 246,894 |  |

[0001564590-22-016543:mdna:108]
As of March 31, 2022, our principal sources of liquidity consisted of cash of $166.6 million and accounts receivable, net of $163.0 million, and available borrowings under our five-year 2019 Revolving Facility of $60.2 million. Our principal uses of cash include the purchase of finished goods inventory from our contract manufacturers, payroll and other operating expenses related to the development and marketing of our products, purchases of property and equipment, and repayments of debt and related interest. We believe that our $166.6 million of cash at March 31, 2022, our cash flow from operations, and the availability of borrowings from the 2019 Revolving Facility will be sufficient to fund our planned operations for at least the next 12 months.

[0001564590-22-016543:mdna:109]
On November 2, 2018, our Board of Directors announced that it had authorized management to repurchase up to $60.0 million of our shares of common stock for two years from the date of authorization, of which $15.0 million was used for repurchases in fiscal 2019 and $30.0 million was used for repurchases in fiscal 2020. In February 2020, our Board of Directors increased the authorization to repurchase by $40.0 million to $100.0 million and extended the period for repurchases for three years from February 5, 2020.  Purchases may be made from time to time in the open market or in privately negotiated transactions. The manner, timing and amount of any future purchases will be determined by our management based on their evaluation of market conditions, stock price, Extreme’s ongoing determination that it is the best use of available cash and other factors. The repurchase program does not obligate Extreme to acquire any shares of its common stock, may be suspended or terminated at any time without prior notice and will be subject to regulatory considerations. During the nine months ended March 31, 2022, we repurchased a total of 1,829,333 shares of common stock on the open market at a total cost of $25.0 million. As of March 31, 2022, we have $30.0 million available under our share repurchase program.

[0001564590-22-016543:mdna:110]
[same as prior period, unchanged from 0001564590-22-003010:mdna:112]

[0001564590-22-016543:mdna:111]
[same as prior period, unchanged from 0001564590-22-003010:mdna:113]

[0001564590-22-016543:mdna:112]
The 2019 Credit Agreement requires us to maintain certain minimum financial ratios at the end of each fiscal quarter. The 2019 Credit Agreement also includes covenants and restrictions that limit, among other things, our ability to incur additional indebtedness, create liens upon any of our property, merge, consolidate or sell all or substantially all of our assets. The 2019 Credit Agreement also includes customary events of default, which may result in acceleration of the outstanding balance.

[0001564590-22-016543:mdna:113]
Financial covenants under the 2019 Credit Agreement require us to maintain a minimum consolidated fixed charge and consolidated leverage ratio at the end of each fiscal quarter through maturity.  The 2019 Credit Agreement also includes covenants and restrictions that limit, among other things, our ability to incur additional indebtedness, create liens upon any of our property, merge, consolidate or sell all or substantially all of our assets.  The 2019 Credit Agreement also includes customary events of default which may result in acceleration of the outstanding balance.

[0001564590-22-016543:mdna:114]
On April 8, 2020, we entered into the First Amendment to waive certain terms and financial covenants of the 2019 Credit Agreement through July 31, 2020. On May 8, 2020, we entered into the Second Amendment which superseded the First Amendment and provided certain revised terms and financial covenants through March 31, 2021. Subsequent to March 31, 2021, the original terms and financial covenants under the 2019 Credit Agreement resumed in effect. The Second Amendment required us to maintain certain minimum cash requirement and certain financial metrics at the end of each fiscal quarter through March 31, 2021.  Under the terms of the Second Amendment, we were not permitted to exceed $55.0 million in our outstanding balance under the 2019 Revolving Facility, the applicable margin for Eurodollar rate was 4.5% and we were restricted from pursuing certain activities such as incurring additional debt, stock repurchases, making acquisitions or declaring a dividend, until we are in compliance with the original covenants of the 2019 Credit Agreement. On November 3, 2020, we and our lenders entered into the Third Amendment to increase the sublimit for letters of credit to $20.0 million. On December 8, 2020, we and our lenders entered into the Fourth Amendment to waive and amend certain terms and financial covenants within the 2019 Credit Agreement through March 31, 2021.

[0001564590-22-016543:mdna:115]
The Second Amendment provided for us to end the covenant Suspension Period early and revert to the covenants and interest rates per the original terms of the 2019 Credit Agreement dated August 9, 2019 by filing a Suspension Period Early Termination Notice and Covenant Certificate demonstrating compliance. For the twelve-month period ended March 31, 2021, our financial performance was in compliance with the original covenants defined in the 2019 Credit Agreement and as such we filed a Suspension Early Termination Notice and Covenant Certificate with the administration agent subsequent to filing our Quarterly Report on Form 10-Q for the period ended March 31, 2021. Returning to compliance with the covenants per the original terms of the 2019 Credit Agreement dated August 9, 2019, resulted in our Eurodollar loan spread decreasing from 4.5% during the suspension period to 2.75% and unused facility commitment fee decreasing from 0.4% to 0.35%, and the limitation on revolver borrowings being removed effective May 1, 2021 after filing of the certificate with the administrative agent.

[0001564590-22-016543:mdna:116]
[same as prior period, unchanged from 0001564590-22-003010:mdna:118]

[0001564590-22-016543:mdna:117]
[same as prior period, unchanged from 0001564590-22-003010:mdna:119]

[0001564590-22-016543:mdna:118]
|  |  | Nine Months Ended |  |
|  |  | March 31, 2022 |  |  | March 31, 2021 |  |
| Net cash provided by operating activities |  | $ | 64,055 |  |  | $ | 87,496 |  |
| Net cash used in investing activities |  |  | (80,647 | ) |  |  | (12,318 | ) |
| Net cash used in financing activities |  |  | (63,211 | ) |  |  | (66,381 | ) |
| Foreign currency effect on cash |  |  | (525 | ) |  |  | 470 |  |
| Net (decrease) increase in cash |  | $ | (80,328 | ) |  | $ | 9,267 |  |

[0001564590-22-016543:mdna:119]
[same as prior period, unchanged from 0001564590-22-003010:mdna:121]

[0001564590-22-016543:mdna:120]
[same as prior period, unchanged from 0001564590-22-003010:mdna:122]

[0001564590-22-016543:mdna:121]
Cash flows provided by operations in the nine months ended March 31, 2022, were $64.1 million, including our net income of $38.9 million and non-cash expenses of $79.1 million for items such as amortization of intangibles, share-based compensation, depreciation, reduction in carrying amount of right-of-use assets, deferred income taxes, and interest. Other sources of cash for the period included increases in accounts payable, deferred revenue and other current and long-term liabilities. This was partially offset by increases in accounts receivable, inventories, prepaid expenses and other current assets and decreases in accrued compensation and operating lease liabilities.

[0001564590-22-016543:mdna:122]
Cash flows provided by operations in the nine months ended March 31, 2021 were $87.5 million, including our net loss of $8.4 million and non-cash expenses of $89.0 million for items such as amortization of intangibles, share-based compensation, depreciation, reduction in carrying amount of right-of-use assets, deferred income taxes and imputed interest. Other sources of cash for the period included a decrease in inventory and increases in accounts payable, accrued compensation, and deferred revenues. This was partially offset by decreases in other current and long-term liabilities and operating lease liabilities and increases in accounts receivables and prepaid expenses and other current assets.

[0001564590-22-016543:mdna:123]
[same as prior period, unchanged from 0001564590-22-003010:mdna:125]

[0001564590-22-016543:mdna:124]
Cash flows used in investing activities in the nine months ended March 31, 2022 were $80.6 million primarily due to the payment of $69.5 million (net of cash acquired) for the acquisition of Ipanema and $11.1 million for the purchases of property and equipment.

[0001564590-22-016543:mdna:125]
Cash flows used in investing activities in the nine months ended March 31, 2021 were $12.3 million for the purchases of property and equipment.

[0001564590-22-016543:mdna:126]
[same as prior period, unchanged from 0001564590-22-003010:mdna:128]

[0001564590-22-016543:mdna:127]
Cash flows used in financing activities in the nine months ended March 31, 2022 were $63.2 million due primarily to debt repayments of $31.0 million, share repurchases of $25.0 million under our share repurchase program, payment of contingent consideration of $1.0 million, $3.0 million for deferred payments on acquisitions and $3.2 million for taxes paid on vested and released stock awards net of proceeds from the issuance of shares of our common stock under our Employee Stock Purchase Plan (“ESPP”) and exercise of stock options.

[0001564590-22-016543:mdna:128]
Cash flows used in financing activities in the nine months ended March 31, 2021 were $66.4 million due primarily to debt repayments of $69.3 million, payment of contingent consideration of $1.3 million, and $3.0 million for deferred payments on acquisitions. This was partially offset by $7.2 million of proceeds from the issuance of shares of our common stock under our ESPP and exercise of stock options, net of taxes paid on vested and released stock awards.

[0001564590-22-016543:mdna:129]
[same as prior period, unchanged from 0001564590-22-003010:mdna:131]

[0001564590-22-016543:mdna:130]
Foreign currency effect on cash decreased in the nine months ended March 31, 2022, primarily due to changes in foreign currency exchange rates between the U.S. Dollar and particularly the Indian Rupee, the UK Pound, and the EURO. Foreign currency effect on the cash increased in the nine months ended March 31, 2021, primarily due to changes in foreign currency exchange rates between the U.S. Dollar and particularly the Indian Rupee, the UK Pound, and the EURO.

[0001564590-22-016543:mdna:131]
[same as prior period, unchanged from 0001564590-22-003010:mdna:133]

[0001564590-22-016543:mdna:132]
The following summarizes our contractual obligations as of March 31, 2022, and the effect such obligations are expected to have on our liquidity and cash flow in future periods (in thousands):

[0001564590-22-016543:mdna:133]
|  |  | Payments due by Period |  |
|  |  | Total |  |  | Less than 1 Year |  |  | 1-3 years |  |  | 3-5 years |  |  | More than 5 years |  |
| Contractual obligations: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Debt obligations |  | $ | 315,750 |  |  | $ | 33,250 |  |  | $ | 282,500 |  |  | $ | — |  |  | $ | — |  |
| Interest on debt obligations |  |  | 15,309 |  |  |  | 7,447 |  |  |  | 7,862 |  |  |  | — |  |  |  | — |  |
| Unconditional purchase obligations |  |  | 70,368 |  |  |  | 70,368 |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Contractual commitments |  |  | 76,983 |  |  |  | 27,744 |  |  |  | 29,852 |  |  |  | 17,233 |  |  |  | 2,154 |  |
| Lease payments on operating leases |  |  | 43,141 |  |  |  | 4,802 |  |  |  | 23,697 |  |  |  | 10,225 |  |  |  | 4,417 |  |
| Deferred payments for an acquisition |  |  | 4,000 |  |  |  | 4,000 |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Other liabilities |  |  | 355 |  |  |  | 150 |  |  |  | 205 |  |  |  | — |  |  |  | — |  |
| Total contractual cash obligations |  | $ | 525,906 |  |  | $ | 147,761 |  |  | $ | 344,116 |  |  | $ | 27,458 |  |  | $ | 6,571 |  |

[0001564590-22-016543:mdna:134]
[same as prior period, unchanged from 0001564590-22-003010:mdna:136]

[0001564590-22-016543:mdna:135]
[same as prior period, unchanged from 0001564590-22-003010:mdna:137]

[0001564590-22-016543:mdna:136]
[same as prior period, unchanged from 0001564590-22-003010:mdna:138]

[0001564590-22-016543:mdna:137]
[same as prior period, unchanged from 0001564590-22-003010:mdna:139]

[0001564590-22-016543:mdna:138]
[same as prior period, unchanged from 0001564590-22-003010:mdna:140]

[0001564590-22-016543:mdna:139]
[same as prior period, unchanged from 0001564590-22-003010:mdna:141]

[0001564590-22-016543:mdna:140]
[same as prior period, unchanged from 0001564590-22-003010:mdna:142]

[0001564590-22-016543:mdna:141]
[same as prior period, unchanged from 0001564590-22-003010:mdna:143]

[0001564590-22-016543:mdna:142]
[same as prior period, unchanged from 0001564590-22-003010:mdna:144]

[0001564590-22-016543:mdna:143]
[same as prior period, unchanged from 0001564590-22-003010:mdna:145]

[0001564590-22-016543:mdna:144]
We did not have any material commitments for capital expenditures as of March 31, 2022.

[0001564590-22-016543:mdna:145]
[same as prior period, unchanged from 0001564590-22-003010:mdna:147]

[0001564590-22-016543:mdna:146]
We did not have any off-balance sheet arrangements as of March 31, 2022.
