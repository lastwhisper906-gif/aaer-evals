# EXTR notes — 0000950170-24-119570


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0000950170-24-119570:notes:1]
[same as prior period, unchanged from 0000950170-24-052140:notes:1]

[0000950170-24-119570:notes:2]
[same as prior period, unchanged from 0000950170-24-052140:notes:2]

[0000950170-24-119570:notes:3]
The unaudited condensed consolidated financial statements of Extreme included herein have been prepared under the rules and regulations of the Securities and Exchange Commission (“SEC”). Certain information and footnote disclosures normally included in financial statements prepared in accordance with U.S. generally accepted accounting principles have been condensed or omitted under such rules and regulations. The condensed consolidated balance sheet at June 30, 2024 was derived from audited financial statements as of that date but does not include all disclosures required by generally accepted accounting principles for complete financial statements. These interim financial statements and notes should be read in conjunction with the Company’s audited consolidated financial statements and notes thereto included in the Company’s Annual Report on Form 10-K for the fiscal year ended June 30, 2024.

[0000950170-24-119570:notes:4]
The unaudited condensed consolidated financial statements reflect all adjustments, consisting only of normal recurring adjustments that, in the opinion of management, are necessary for a fair presentation of the results of operations and cash flows for the interim periods presented and the financial condition of Extreme at September 30, 2024. The results of operations for the three months ended September 30, 2024 are not necessarily indicative of the results that may be expected for fiscal 2025 or any future periods.

[0000950170-24-119570:notes:5]
[same as prior period, unchanged from 0000950170-24-052140:notes:5]

[0000950170-24-119570:notes:6]
The Company uses a fiscal calendar year ending on June 30. All references herein to “fiscal 2025” represent the fiscal year ending June 30, 2025. All references herein to “fiscal 2024” represent the fiscal year ended June 30, 2024.

[0000950170-24-119570:notes:7]
[same as prior period, unchanged from 0000950170-24-052140:notes:7]

[0000950170-24-119570:notes:8]
[same as prior period, unchanged from 0000950170-24-052140:notes:8]

[0000950170-24-119570:notes:9]
[same as prior period, unchanged from 0000950170-24-052140:notes:9]

[0000950170-24-119570:notes:10]
[same as prior period, unchanged from 0000950170-24-052140:notes:10]

[0000950170-24-119570:notes:11]
[same as prior period, unchanged from 0000950170-24-052140:notes:11]


## us-gaap:SignificantAccountingPoliciesTextBlock

[0000950170-24-119570:notes:12]
[same as prior period, unchanged from 0000950170-24-052140:notes:12]

[0000950170-24-119570:notes:13]
For a description of significant accounting policies, see Note 2, Summary of Significant Accounting Policies, to the consolidated financial statements included in the Company’s Annual Report on Form 10-K for the fiscal year ended June 30, 2024. There have been no material changes to the Company’s significant accounting policies since the filing of the Annual Report on Form 10-K.

[0000950170-24-119570:notes:14]
Recently Adopted Accounting Pronouncements

[0000950170-24-119570:notes:15]
There were no recently adopted accounting standards which would have a material effect on our condensed consolidated financial statements and accompanying disclosures.

[0000950170-24-119570:notes:16]
Recently Issued Accounting Pronouncements Not Yet Adopted

[0000950170-24-119570:notes:17]
In November 2023, the Financial Accounting Standards Board (“FASB”) issued Accounting Standards Update (“ASU”) 2023-07, Segment Reporting (Topic 280): Improvements to Reportable Segment Disclosures to improve reportable segment disclosure requirements primarily through enhanced disclosures about significant segment expenses and information used to assess segment performance. All disclosure requirements of ASU 2023-07 are required for entities with a single reportable segment. ASU 2023-07 is effective for fiscal years beginning after December 15, 2023, and interim periods for fiscal years beginning after December 15, 2024, and should be applied on a retrospective basis to all periods presented. Early adoption is permitted. The Company is currently evaluating the impact of adopting ASU 2023-07 on its consolidated financial statements and related disclosures.

[0000950170-24-119570:notes:18]
In December 2023, the FASB issued ASU 2023-09, Income Taxes (Topic 740), Improvements to Income Tax Disclosures to enhance income tax disclosures primarily through changes in the rate reconciliation and income taxes paid information. ASU 2023-09 is effective for fiscal years beginning after December 15, 2024 on a prospective basis. Early adoption is permitted. The Company is currently evaluating the impact of adopting ASU 2023-09 on its consolidated financial statements and related disclosures.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0000950170-24-119570:notes:19]
[same as prior period, unchanged from 0000950170-24-052140:notes:19]

[0000950170-24-119570:notes:20]
The Company accounts for revenues in accordance with Accounting Standards Codification (“ASC”) 606, Revenue from Contracts with Customers. The Company derives the majority of its revenues from sales of its networking equipment, with the remaining revenues generated from sales of subscription and support, which primarily includes software subscriptions delivered as software as a service (“SaaS”) and additional revenues from maintenance contracts, professional services and training for its products. The Company sells its products, SaaS and maintenance contracts direct to customers and partners in two distribution channels, or tiers. The first tier consists of a limited number of independent distributors that stock the Company's products and sell primarily to resellers. The second tier of the distribution channel consists of non-stocking distributors and value-added resellers that sell directly to end-users. Products and subscription and support may be sold separately or in bundled packages.

[0000950170-24-119570:notes:21]
[same as prior period, unchanged from 0000950170-24-052140:notes:21]

[0000950170-24-119570:notes:22]
[same as prior period, unchanged from 0000950170-24-052140:notes:22]

[0000950170-24-119570:notes:23]
The Company’s performance obligations are satisfied at a point in time or over time as the customer receives and consumes the benefits provided. Substantially all of the Company’s product sales revenues are recognized at a point in time. Substantially all of the Company’s subscription and support revenues are recognized over time. For revenues recognized over time, the Company primarily uses an input measure, days elapsed, to measure progress.

[0000950170-24-119570:notes:24]
As of September 30, 2024, the Company had $576.9 million of remaining performance obligations, which primarily comprised deferred support and deferred SaaS subscription revenues. The Company expects to recognize approximately 43% of its deferred revenue as revenue in the remainder of fiscal 2025, an additional 28% in fiscal 2026, and the remaining 29% of the balance thereafter.

[0000950170-24-119570:notes:25]
[same as prior period, unchanged from 0000950170-24-052140:notes:25]

[0000950170-24-119570:notes:26]
Revenue recognized for the three months ended September 30, 2024 and 2023 that was included in the deferred revenue balance at the beginning of each period was $100.3 million and $89.7 million, respectively.

[0000950170-24-119570:notes:27]
Contract Costs. The Company recognizes the incremental costs of obtaining contracts as an expense when incurred if the amortization period of the assets that the Company otherwise would have recognized is one year or less. Management expects that commission fees paid to sales representatives as a result of obtaining subscription and support contracts and contract renewals are recoverable and therefore the Company’s condensed consolidated balance sheets included capitalized balances in the amount of $24.2 million and $24.7 million as of September 30, 2024 and June 30, 2024, respectively. Capitalized commissions are included within other assets in the condensed consolidated balance sheets. Capitalized commission fees are amortized on a straight-line basis over the average period of service contracts of approximately three years, and are included in “Sales and marketing” in the accompanying condensed consolidated statements of operations. Amortization recognized during the three months ended September 30, 2024 and 2023 was $3.0 million and $2.6 million, respectively.

[0000950170-24-119570:notes:28]
[same as prior period, unchanged from 0000950170-24-052140:notes:28]

[0000950170-24-119570:notes:29]
[same as prior period, unchanged from 0000950170-24-052140:notes:29]

[0000950170-24-119570:notes:30]
The Company operates in three geographic regions: Americas, EMEA (Europe, Middle East and Africa) and APAC (Asia Pacific). The following table sets forth the Company’s net revenues disaggregated by geographic region (in thousands):

[0000950170-24-119570:notes:31]
|  | Three Months Ended |  |
|  |  | September 30,2024 |  |  | September 30,2023 |  |
| Americas: |  |  |  |  |  |  |
| United States |  | $ | 153,253 |  |  | $ | 182,752 |  |
| Other |  |  | 12,182 |  |  |  | 12,897 |  |
| Total Americas |  |  | 165,435 |  |  |  | 195,649 |  |
| EMEA |  |  | 84,918 |  |  |  | 143,603 |  |
| APAC |  |  | 18,851 |  |  |  | 13,885 |  |
| Total net revenues |  | $ | 269,204 |  |  | $ | 353,137 |  |

[0000950170-24-119570:notes:32]
For the three months ended September 30, 2024, no foreign country accounted for 10% or more of the Company's net revenues. For the three months ended September 30, 2023, the Company generated 14% of its net revenues from the Netherlands. No other foreign country accounted for 10% or more of the Company's net revenues for the three months ended September 30, 2023.

[0000950170-24-119570:notes:33]
[same as prior period, unchanged from 0000950170-24-052140:notes:35]

[0000950170-24-119570:notes:34]
[same as prior period, unchanged from 0000950170-24-052140:notes:36]

[0000950170-24-119570:notes:35]
[same as prior period, unchanged from 0000950170-24-052140:notes:37]

[0000950170-24-119570:notes:36]
|  |  | Three Months Ended |
|  |  | September 30,2024 |  | September 30,2023 |
| TD Synnex Corporation |  | 22% |  | 18% |
| Jenne, Inc. |  | 21% |  | 27% |
| Westcon Group, Inc. |  | 15% |  | 25% |

[0000950170-24-119570:notes:37]
[same as prior period, unchanged from 0000950170-24-052140:notes:39]

[0000950170-24-119570:notes:38]
|  |  | September 30,2024 |  | June 30,2024 |
| Jenne, Inc. |  | 53% |  | 64% |
| ScanSource, Inc. |  | 11% |  | 11% |
| Exclusive Networks |  | 10% |  | * |
| * Less than 10% of accounts receivable |  |  |  |  |

[0000950170-24-119570:notes:39]
The majority of the Company's net accounts receivable balance with Jenne, Inc. as of September 30, 2024 is current and the Company expects to collect this balance by March 31, 2025.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0000950170-24-119570:notes:40]
[same as prior period, unchanged from 0000950170-24-052140:notes:41]

[0000950170-24-119570:notes:41]
[same as prior period, unchanged from 0000950170-24-052140:notes:42]

[0000950170-24-119570:notes:42]
[same as prior period, unchanged from 0000950170-24-052140:notes:43]

[0000950170-24-119570:notes:43]
[same as prior period, unchanged from 0000950170-24-052140:notes:44]

[0000950170-24-119570:notes:44]
|  |  | September 30,2024 |  |  | June 30,2024 |  |
| Cash |  | $ | 159,426 |  |  | $ | 153,483 |  |
| Cash equivalents |  |  | 120 |  |  |  | 3,216 |  |
| Total cash and cash equivalents |  | $ | 159,546 |  |  | $ | 156,699 |  |

[0000950170-24-119570:notes:45]
[same as prior period, unchanged from 0000950170-24-052140:notes:46]

[0000950170-24-119570:notes:46]
[same as prior period, unchanged from 0000950170-24-052140:notes:47]

[0000950170-24-119570:notes:47]
[same as prior period, unchanged from 0000950170-24-052140:notes:48]

[0000950170-24-119570:notes:48]
|  |  | September 30,2024 |  |  | June 30,2024 |  |
| Finished goods |  | $ | 92,227 |  |  | $ | 115,813 |  |
| Raw materials |  |  | 51,328 |  |  |  | 25,219 |  |
| Total inventories |  | $ | 143,555 |  |  | $ | 141,032 |  |

[0000950170-24-119570:notes:49]
[same as prior period, unchanged from 0000950170-24-052140:notes:50]

[0000950170-24-119570:notes:50]
[same as prior period, unchanged from 0000950170-24-052140:notes:51]

[0000950170-24-119570:notes:51]
|  |  | September 30,2024 |  |  | June 30,2024 |  |
| Computers and equipment |  | $ | 73,867 |  |  | $ | 77,224 |  |
| Purchased software |  |  | 52,866 |  |  |  | 60,717 |  |
| Office equipment, furniture and fixtures |  |  | 8,115 |  |  |  | 8,134 |  |
| Leasehold improvements |  |  | 53,506 |  |  |  | 47,880 |  |
| Total property and equipment |  |  | 188,354 |  |  |  | 193,955 |  |
| Less: accumulated depreciation and amortization |  |  | (153,961 | ) |  |  | (150,211 | ) |
| Property and equipment, net |  | $ | 34,393 |  |  | $ | 43,744 |  |

[0000950170-24-119570:notes:52]
[same as prior period, unchanged from 0000950170-24-052140:notes:53]

[0000950170-24-119570:notes:53]
[same as prior period, unchanged from 0000950170-24-052140:notes:54]

[0000950170-24-119570:notes:54]
[same as prior period, unchanged from 0000950170-24-052140:notes:55]

[0000950170-24-119570:notes:55]
[same as prior period, unchanged from 0000950170-24-052140:notes:56]

[0000950170-24-119570:notes:56]
[same as prior period, unchanged from 0000950170-24-052140:notes:57]

[0000950170-24-119570:notes:57]
|  |  | Three Months Ended |  |
|  |  | September 30,2024 |  |  | September 30,2023 |  |
| Balance at beginning of period |  | $ | 10,942 |  |  | $ | 12,322 |  |
| New warranties issued |  |  | 2,487 |  |  |  | 3,674 |  |
| Warranty expenditures |  |  | (3,190 | ) |  |  | (3,832 | ) |
| Balance at end of period |  | $ | 10,239 |  |  | $ | 12,164 |  |

[0000950170-24-119570:notes:58]
To facilitate sales of its products in the normal course of business, the Company indemnifies its resellers and end-user customers with respect to certain matters. The Company has agreed to hold the customer harmless against losses arising from intellectual property infringement or other claims made against certain parties. These agreements may limit the time within which an indemnification claim can be made and the amount of the claim. It is not possible to estimate the maximum potential amount under these indemnification agreements due to the limited history of prior indemnification claims and the unique facts and circumstances involved in each particular agreement. Historically, payments made by the Company under these agreements have not had a material impact on its operating results or financial position.

[0000950170-24-119570:notes:59]
[same as prior period, unchanged from 0000950170-24-052140:notes:60]

[0000950170-24-119570:notes:60]
[same as prior period, unchanged from 0000950170-24-052140:notes:61]


## us-gaap:FairValueDisclosuresTextBlock

[0000950170-24-119570:notes:61]
[same as prior period, unchanged from 0000950170-24-052140:notes:62]

[0000950170-24-119570:notes:62]
[same as prior period, unchanged from 0000950170-24-052140:notes:63]

[0000950170-24-119570:notes:63]
[same as prior period, unchanged from 0000950170-24-052140:notes:64]

[0000950170-24-119570:notes:64]
[same as prior period, unchanged from 0000950170-24-052140:notes:65]

[0000950170-24-119570:notes:65]
[same as prior period, unchanged from 0000950170-24-052140:notes:66]

[0000950170-24-119570:notes:66]
The following table presents the Company’s fair value hierarchy for its financial assets and liabilities measured at fair value on a recurring basis (in thousands):

[0000950170-24-119570:notes:67]
| September 30, 2024 |  | Level 1 |  |  | Level 2 |  |  | Level 3 |  |  | Total |  |
| Assets |  |  |  |  |  |  |  |  |  |  |  |  |
| Certificates of deposit |  | $ | — |  |  | $ | 120 |  |  | $ | — |  |  | $ | 120 |  |
| Foreign currency derivatives |  |  | — |  |  |  | 225 |  |  |  | — |  |  |  | 225 |  |
| Total assets measured at fair value |  | $ | — |  |  | $ | 345 |  |  | $ | — |  |  | $ | 345 |  |

[0000950170-24-119570:notes:68]
| June 30, 2024 |  | Level 1 |  |  | Level 2 |  |  | Level 3 |  |  | Total |  |
| Assets |  |  |  |  |  |  |  |  |  |  |  |  |
| Certificates of deposit |  | $ | — |  |  | $ | 3,216 |  |  | $ | — |  |  | $ | 3,216 |  |
| Foreign currency derivatives |  |  | — |  |  |  | 18 |  |  |  | — |  |  |  | 18 |  |
| Total assets measured at fair value |  | $ | — |  |  | $ | 3,234 |  |  | $ | — |  |  | $ | 3,234 |  |
| Liabilities |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency derivatives |  | $ | — |  |  | $ | 71 |  |  | $ | — |  |  | $ | 71 |  |
| Total liabilities measured at fair value |  | $ | — |  |  | $ | 71 |  |  | $ | — |  |  | $ | 71 |  |

[0000950170-24-119570:notes:69]
[same as prior period, unchanged from 0000950170-24-052140:notes:70]

[0000950170-24-119570:notes:70]
[same as prior period, unchanged from 0000950170-24-052140:notes:71]

[0000950170-24-119570:notes:71]
As of September 30, 2024 and June 30, 2024, the Company had investment in certificates of deposit of $0.1 million and $3.2 million, respectively, with maturity of three months at the date of purchase, which are recorded as cash equivalents in the condensed consolidated balance sheets. The Company considers these cash equivalents to be available-for-sale and, as of September 30, 2024 and June 30, 2024, their fair value approximated their amortized cost.

[0000950170-24-119570:notes:72]
As of September 30, 2024 and June 30, 2024, the Company had foreign exchange forward contracts that were not designated as hedging instruments with notional principal amounts of $42.6 million and $31.3 million, respectively. These contracts currently have maturities of 40 days or less. Changes in the fair value of these foreign exchange forward contracts not designated as hedging instruments are included in 'Other income (expense), net' in the condensed consolidated statements of operations. For the three months ended September 30, 2024 and 2023, the net gains and losses recorded in the condensed consolidated statement of operations from these contracts were net gains of $0.8 million and net losses of less than $0.1 million, respectively. As of September 30, 2024 and June 30, 2024, there were no outstanding foreign exchange forward contracts that were designated as hedging instruments. See Note 12, Derivatives and Hedging, for additional information.

[0000950170-24-119570:notes:73]
The fair value of borrowings under the 2023 Credit Agreement (as defined in Note 7) is estimated based on valuations provided by alternative pricing sources supported by observable inputs which is considered Level 2. Since the interest rate is variable in the 2023 Credit Agreement, the fair value approximates the face amount of the Company’s indebtedness of $187.5 million and $190.0 million as of September 30, 2024 and June 30, 2024, respectively.

[0000950170-24-119570:notes:74]
[same as prior period, unchanged from 0000950170-24-052140:notes:75]

[0000950170-24-119570:notes:75]
As of September 30, 2024 and June 30, 2024, the Company did not have any assets or liabilities that were considered Level 3. 
There were no transfers of assets or liabilities between Level 1, Level 2, or Level 3 during the three months ended September 30, 2024 and 2023. There were no impairments recorded for the three months ended September 30, 2024 and 2023.


## us-gaap:IntangibleAssetsDisclosureTextBlock

[0000950170-24-119570:notes:76]
[same as prior period, unchanged from 0000950170-24-052140:notes:77]

[0000950170-24-119570:notes:77]
[same as prior period, unchanged from 0000950170-24-052140:notes:78]

[0000950170-24-119570:notes:78]
[same as prior period, unchanged from 0000950170-24-052140:notes:79]

[0000950170-24-119570:notes:79]
|  |  | Weighted Average |  |  |  |  |  |  |  |  |  |
|  |  | Remaining Amortization |  | Gross Carrying |  |  | Accumulated |  |  | Net Carrying |  |
|  |  | Period |  | Amount |  |  | Amortization |  |  | Amount |  |
| September 30, 2024 |  |  |  |  |  |  |  |  |  |  |  |
| Developed technology |  | 3.0 years |  | $ | 169,801 |  |  | $ | 163,600 |  |  | $ | 6,201 |  |
| Customer relationships |  | 1.7 years |  |  | 64,739 |  |  |  | 61,338 |  |  |  | 3,401 |  |
| Trade names |  | 0.0 years |  |  | 10,700 |  |  |  | 10,700 |  |  |  | — |  |
| License agreements |  | 2.3 years |  |  | 1,282 |  |  |  | 1,122 |  |  |  | 160 |  |
| Total intangible assets, net* |  |  |  | $ | 246,522 |  |  | $ | 236,760 |  |  | $ | 9,762 |  |
| * The carrying amount of foreign intangible assets are affected by foreign currency translation |  |  |  |  |

[0000950170-24-119570:notes:80]
|  |  | Weighted Average |  |  |  |  |  |  |  |  |  |
|  |  | Remaining Amortization |  | Gross Carrying |  |  | Accumulated |  |  | Net Carrying |  |
|  |  | Period |  | Amount |  |  | Amortization |  |  | Amount |  |
| June 30, 2024 |  |  |  |  |  |  |  |  |  |  |  |
| Developed technology |  | 3.0 years |  | $ | 169,247 |  |  | $ | 162,708 |  |  | $ | 6,539 |  |
| Customer relationships |  | 2.0 years |  |  | 64,671 |  |  |  | 60,776 |  |  |  | 3,896 |  |
| Trade names |  | 0.0 years |  |  | 10,700 |  |  |  | 10,700 |  |  |  | — |  |
| License agreements |  | 2.4 years |  |  | 1,282 |  |  |  | 1,104 |  |  |  | 178 |  |
| Total intangible assets, net* |  |  |  | $ | 245,901 |  |  | $ | 235,288 |  |  | $ | 10,613 |  |
| * The carrying amount of foreign intangible assets are affected by foreign currency translation |  |  |  |  |

[0000950170-24-119570:notes:81]
[same as prior period, unchanged from 0000950170-24-052140:notes:82]

[0000950170-24-119570:notes:82]
|  |  | Three Months Ended |  |
|  |  | September 30,2024 |  |  | September 30,2023 |  |
| Amortization of intangible assets in “Total cost of revenues” |  | $ | 624 |  |  | $ | 1,433 |  |
| Amortization of intangible assets in “Total operating expenses” |  |  | 512 |  |  |  | 511 |  |
| Total amortization expense |  | $ | 1,136 |  |  | $ | 1,944 |  |

[0000950170-24-119570:notes:83]
[same as prior period, unchanged from 0000950170-24-052140:notes:84]

[0000950170-24-119570:notes:84]
[same as prior period, unchanged from 0000950170-24-052140:notes:85]

[0000950170-24-119570:notes:85]
|  |  | Amount |  |
| For the fiscal year ending June 30: |  |  |  |
| 2025 (the remainder of fiscal 2025) |  | $ | 3,432 |  |
| 2026 |  |  | 3,282 |  |
| 2027 |  |  | 1,470 |  |
| 2028 |  |  | 1,306 |  |
| 2029 |  |  | 272 |  |
| Total |  | $ | 9,762 |  |

[0000950170-24-119570:notes:86]
[same as prior period, unchanged from 0000950170-24-052140:notes:87]

[0000950170-24-119570:notes:87]
The Company had goodwill in the amount of $396.3 million and $393.7 million as of September 30, 2024 and June 30, 2024, respectively. The change in goodwill during the three months ended September 30, 2024 is due to foreign currency translation adjustments that are recorded as a component of accumulated other comprehensive loss.


## us-gaap:DebtDisclosureTextBlock

[0000950170-24-119570:notes:88]
7.
Debt

[0000950170-24-119570:notes:89]
The Company’s debt is comprised of the following (in thousands):

[0000950170-24-119570:notes:90]
|  |  | September 30,2024 |  |  | June 30,2024 |  |
| Current portion of long-term debt: |  |  |  |  |  |  |
| Term Loan |  | $ | 11,250 |  |  | $ | 10,000 |  |
| Less: unamortized debt issuance costs |  |  | (761 | ) |  |  | (674 | ) |
| Current portion of long-term debt |  | $ | 10,489 |  |  | $ | 9,326 |  |
| Long-term debt, less current portion: |  |  |  |  |  |  |
| Term Loan |  | $ | 176,250 |  |  | $ | 180,000 |  |
| Less: unamortized debt issuance costs |  |  | (1,819 | ) |  |  | (1,735 | ) |
| Total long-term debt, less current portion |  |  | 174,431 |  |  |  | 178,265 |  |
| Total debt |  | $ | 184,920 |  |  | $ | 187,591 |  |

[0000950170-24-119570:notes:91]
On August 9, 2019, the Company entered into an Amended and Restated Credit Agreement (the “2019 Credit Agreement”), by and among the Company, as borrower, several banks and other financial institutions as Lenders, BMO Harris Bank N.A., as an issuing lender and swingline lender, Silicon Valley Bank, as an Issuing Lender, and Bank of Montreal, as administrative agent and collateral agent for the Lenders which was subsequently amended during fiscal 2023.

[0000950170-24-119570:notes:92]
On June 22, 2023, the Company entered into a Second Amended and Restated Credit Agreement (the “2023 Credit Agreement”), by and among the Company, as borrower, BMO Harris Bank, N.A., as an issuing lender and swingline lender, Bank of America, N.A., JPMorgan Chase Bank, N.A., PNC Bank, National Association, and Wells Fargo Bank, National Association, as issuing lenders, the financial institutions or entities party thereto as lenders, and Bank of Montreal, as administrative agent and collateral agent, which amended and restated the 2019 Credit Agreement. The 2023 Credit Agreement provides for i) a $200.0 million first lien term loan facility in an aggregate principal amount (the “2023 Term Loan”), ii) a $150.0 million five-year revolving credit facility (the “2023 Revolving Facility”) and, iii) an uncommitted additional incremental loan facility in the principal amount of up to $100.0 million.

[0000950170-24-119570:notes:93]
Borrowings under the 2023 Credit Agreement bear interest, and at the Company’s election, the initial term loan may be made as either a base rate loan or a Secured Overnight Funding Rate (“SOFR”) loan. The applicable margin for base rate loans ranges from 1.00% to 1.75% per annum, and the applicable margin for SOFR loans ranges from 2.00% to 2.75%, in each case based on the Company’s consolidated leverage ratio. All SOFR loans are subject to a floor of 0.00% per annum and spread adjustment of 0.10% per annum. The Company paid other closing fees, arrangement fees, and administration fees associated with the 2023 Credit Agreement.

[0000950170-24-119570:notes:94]
The 2023 Credit Agreement requires the Company to maintain certain minimum financial ratios at the end of each fiscal quarter. The 2023 Credit Agreement also includes covenants and restrictions that limit, among other things, the Company’s ability to incur additional indebtedness, create liens upon any of its property, merge, consolidate or sell all or substantially all of its assets. The 2023 Credit Agreement also includes customary events of default which may result in acceleration of the outstanding balance.

[0000950170-24-119570:notes:95]
On August 14, 2024, the Company entered into an Amendment Number One to the 2023 Credit Agreement (the “Amended Credit Agreement”). Under the Amended Credit Agreement, the Company modified the definition of the consolidated EBITDA for the purposes of evaluating compliance with financial covenants under the 2023 Credit Agreement. The amended definition of consolidated EBITDA modifies the amount and type of add-backs that are allowable to better align with the Company's operations and activities. Further, the Amended Credit Agreement provides a waiver for the Company's compliance with the consolidated interest charge coverage ratio for each of the quarters ended June 30, 2024, September 30, 2024, and December 31, 2024.

[0000950170-24-119570:notes:96]
During the three months ended September 30, 2024, the Company was in compliance with all the terms and financial covenants of the Amended Credit Agreement.

[0000950170-24-119570:notes:97]
Financing costs incurred in connection with obtaining and modifying long-term financing are deferred and amortized over the term of the related indebtedness or credit agreement. Amortization of deferred financing costs are included in “Interest expense” in the accompanying condensed consolidated statements of operations. During the three months ended September 30, 2024, the Company capitalized approximately $0.7 million of debt cost related to the Amended Credit Agreement. The remaining unamortized debt issuance cost related to the prior arrangement and the newly capitalized costs will be amortized over the remaining term of the loan arrangement. Amortization of debt issuance costs included in “Interest expense”  were $0.3 million for each of the three months ended September 30, 2024 and 2023. The interest rate as of September 30, 2024 was 7.52% and as of September 30, 2023 was 7.45%.

[0000950170-24-119570:notes:98]
As of September 30, 2024, the Company did not have any outstanding balance against its 2023 Revolving Facility. The Company had $135.8 million of availability under the 2023 Revolving Facility as of September 30, 2024. During the three months ended September 30, 2024 and 2023, the Company did not make any additional payments against its term loan facility other than the scheduled payments per the terms of the Amended Credit Agreement.

[0000950170-24-119570:notes:99]
The Company had $14.2 million of outstanding letters of credit as of September 30, 2024.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000950170-24-119570:notes:100]
8.
Commitments and Contingencies

[0000950170-24-119570:notes:101]
Purchase Commitments

[0000950170-24-119570:notes:102]
The Company currently has arrangements with contract manufacturers and suppliers for the manufacture of its products. Those arrangements allow the contract manufacturers to procure long lead-time component inventory based upon a rolling production forecast provided by the Company. The Company is obligated to purchase long lead-time component inventory that its contract manufacturer procures in accordance with the forecast, unless the Company gives notice of order cancellation outside of applicable component lead-times. As of September 30, 2024, the Company had commitments to purchase $37.3 million of inventory.

[0000950170-24-119570:notes:103]
Legal Proceedings

[0000950170-24-119570:notes:104]
The Company may from time to time be party to litigation arising in the course of its business, including, without limitation, allegations relating to commercial transactions, business relationships, or intellectual property rights. Such claims, even if not meritorious, could result in the expenditure of significant financial and managerial resources. Litigation in general, and intellectual property litigation in particular, can be expensive and disruptive to normal business operations. Moreover, the results of legal proceedings are difficult to predict.

[0000950170-24-119570:notes:105]
In accordance with applicable accounting guidance, the Company records accruals for certain of its outstanding legal proceedings, investigations or claims when it is probable that a liability will be incurred, and the amount of loss can be reasonably estimated. The

[0000950170-24-119570:notes:106]
Company evaluates, at least on a quarterly basis, developments in legal proceedings, investigations or claims that could affect the amount of any accrual, as well as any developments that would result in a loss contingency to become both probable and reasonably estimable. When a loss contingency is not both probable and reasonably estimable, the Company does not record a loss accrual. However, if the loss (or an additional loss in excess of any prior accrual) is at least reasonably possible and material, then the Company would disclose an estimate of the possible loss or range of loss, if such estimate can be made, or disclose that an estimate cannot be made. The assessment whether a loss is probable or a reasonable possibility, and whether the loss or a range of loss is estimable, involves a series of complex judgments about future events. Even if a loss is reasonably possible, the Company may not be able to estimate a range of possible loss, particularly where (i) the damages sought are substantial or indeterminate, (ii) the proceedings are in the early stages, or (iii) the matters involve novel or unsettled legal theories or a large number of parties. In such cases, there is considerable uncertainty regarding the ultimate resolution of such matters, including the amount of any possible loss, fine or penalty. However, an adverse resolution of one or more of such matters could have a material adverse effect on the Company's results of operations in a particular quarter or fiscal year.

[0000950170-24-119570:notes:107]
Orckit IP, LLC v. Extreme Networks, Inc., Extreme Networks Ireland Ltd., and Extreme Networks GmbH

[0000950170-24-119570:notes:108]
On February 1, 2018, Orckit IP, LLC (“Orckit”) filed a patent infringement lawsuit against the Company and its Irish and German subsidiaries in the District Court in Dusseldorf, Germany. The lawsuit alleges direct and indirect infringement of the German portion of a patent (“EP ‘364”) based on the offer, distribution, use, possession and/or importation into Germany of certain network switches that are equipped with the ExtremeXOS operating system. Orckit is seeking injunctive relief, accounting, and an unspecified declaration of liability for damages and costs of the lawsuit. On January 28, 2020, the Court rendered a decision in the infringement case in favor of the Company. On October 17, 2024, Orckit informed the District Court in Dusseldorf, Germany of its intention to withdraw its complaint.

[0000950170-24-119570:notes:109]
On April 23, 2019, Orckit filed an extension of the patent infringement complaint against the Company and its Irish and German subsidiaries in the District Court in Dusseldorf, Germany. With this extension, Orckit alleges infringement of the German portion of a second patent (“EP ‘077”) based on the offer, distribution, use, possession and/or importation into Germany of certain network switches that the Company no longer sells in Germany. Orckit is seeking injunctive relief, accounting and sales information, and a declaration of liability for damages as well as costs of the lawsuit. On October 13, 2020, the Court issued an infringement decision against the Company and granted Orckit the right to enforce the judgment against the Company, which Orckit has provided notification to the Company that it will enforce the judgment. In the rendering of account, Orckit was informed that the products at issue were in end of sale status prior to the filing of the EP ‘077 complaint. The Company has appealed the infringement decision, and the matter is proceeding through the appellate process.

[0000950170-24-119570:notes:110]
The Company filed a nullity action related to the EP ‘364 patent on May 3, 2018, and one related to the EP ‘077 patent on October 31, 2019, both in the Federal Patent Court in Munich. The Federal Patent Court in Munich found the EP ‘364 patent to be valid and the Company filed an appeal, which was dismissed on October 12, 2023. On October 25, 2022 the Federal Patent Court in Munich issued an opinion partially invalidating the EP ‘077 patent and the Company and Orckit have filed appeals. An oral hearing has been set for December 10, 2024.

[0000950170-24-119570:notes:111]
SNMP Research, Inc. and SNMP Research International, Inc. v. Broadcom Inc., Brocade Communications Systems LLC, and Extreme Networks, Inc.

[0000950170-24-119570:notes:112]
On October 26, 2020, SNMP Research, Inc. and SNMP Research International, Inc. (collectively, “SNMP”) filed a lawsuit against the Company in the Eastern District of Tennessee for copyright infringement, alleging that the Company was not properly licensed to use its software. SNMP is seeking actual damages and profits attributed to the infringement, as well as equitable relief. The Company filed a motion to transfer the case to the Northern District of California. The motion to dismiss was denied in part and denied without prejudice in part. On March 2, 2023, SNMP filed an amended complaint adding claims against Extreme on additional products for copyright infringement, breach of contract, and fraud. On March 16, 2023, the Company filed a motion to dismiss, challenging multiple claims from the amended complaint, which was denied on January 30, 2024. On March 20, 2023, the Company filed a motion to refer questions to the U.S. Copyright Office on the invalidity of SNMP’s copyrights, which was denied on March 18, 2024. The trial date and all other dates were vacated and the court ordered mandatory mediation, which took place in September 2024.

[0000950170-24-119570:notes:113]
Mala Technologies Ltd. v. Extreme Networks GmbH, Extreme Networks Ireland Ops Ltd., and Extreme Networks, Inc.

[0000950170-24-119570:notes:114]
On April 15, 2021, Mala Technologies Ltd. (“Mala”) filed a patent infringement lawsuit against the Company and its Irish and German subsidiaries in the District Court in Dusseldorf, Germany. The lawsuit alleges indirect infringement of the German portion of a patent (“EP ‘498”) based on the offer and sale in Germany of certain network switches equipped with the ExtremeXOS operating system. Mala is seeking injunctive relief, accounting, and an unspecified declaration of liability for damages and costs of the lawsuit. On December 20, 2022, the trial court ruled that the Company did not infringe the EP ‘498 patent and dismissed Mala’s complaint entirely. Mala has filed an appeal and an oral hearing has been set for March 27, 2025.

[0000950170-24-119570:notes:115]
The Company filed a nullity complaint against EP ‘498 with the German Federal Patent Court on September 24, 2021 and a hearing date has been set for November 20, 2024.

[0000950170-24-119570:notes:116]
Steamfitters Local 449 Pension & Retirement Security Funds v. Extreme Networks, Inc., et al.

[0000950170-24-119570:notes:117]
On August 13, 2024, a putative securities class action (the “Class Action”) was filed in the United States District Court for the Northern District of California captioned Steamfitters Local 449 Pension & Retirement Security Funds v. Extreme Networks, Inc., et al., Case No. 5:24-cv-05102-TLT, naming the Company and certain of our current and former executive officers as defendants. The lawsuit is purportedly brought on behalf of purchasers of Extreme Networks securities between July 27, 2022 and January 30, 2024 (the “Class Period”). The complaint alleges claims under Sections 10(b) and 20(a) of the Securities Exchange Act of 1934, and Rule 10b-5 promulgated thereunder, based on allegedly false and misleading statements about our business and prospects during the Class Period. The lawsuit seeks unspecified damages. It is expected that the Court will select a lead plaintiff on or around January 7, 2025.

[0000950170-24-119570:notes:118]
Indemnification Obligations

[0000950170-24-119570:notes:119]
Subject to certain limitations, the Company may be obligated to indemnify its current and former directors, officers, and employees. These obligations arise under the terms of its certificate of incorporation, its bylaws, applicable contracts, and applicable law. The obligation to indemnify, where applicable, generally means that the Company is required to pay or reimburse, and in certain circumstances the Company has paid or reimbursed, the individuals’ reasonable legal expenses and possible damages and other liabilities incurred in connection with certain legal matters. The Company also procures Directors and Officers liability insurance to help cover its defense and/or indemnification costs, although its ability to recover such costs through insurance is uncertain.  While it is not possible to estimate the maximum potential amount that could be owed under these governing documents and agreements due to the Company’s limited history with prior indemnification claims, indemnification (including defense) costs could, in the future, have a material adverse effect on the Company’s consolidated financial position, results of operations and cash flows.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0000950170-24-119570:notes:120]
[same as prior period, unchanged from 0000950170-24-052140:notes:117]

[0000950170-24-119570:notes:121]
[same as prior period, unchanged from 0000950170-24-052140:notes:118]

[0000950170-24-119570:notes:122]
The Compensation Committee of the Board unanimously approved an amendment to the Extreme Networks, Inc. Amended and Restated 2013 Equity Incentive Plan (the “2013 Plan”) on September 14, 2023 to increase the maximum number of available shares by 2.3 million shares, which is pending ratification by the stockholders of the Company at the annual meeting of stockholders to be held on November 14, 2024.

[0000950170-24-119570:notes:123]
[same as prior period, unchanged from 0000950170-24-052140:notes:122]

[0000950170-24-119570:notes:124]
[same as prior period, unchanged from 0000950170-24-052140:notes:123]

[0000950170-24-119570:notes:125]
During the three months ended September 30, 2024, the Company did not repurchase any shares of its common stock.  During the three months ended September 30, 2023, the Company repurchased a total of 880,215 shares of its common stock on the open market at a total cost of $24.9 million with an average price of $28.28 per share. As of September 30, 2024, approximately $50.3 million remains available for share repurchases under the 2022 Repurchase Program.

[0000950170-24-119570:notes:126]
As a provision of the Inflation Reduction Act enacted in the U.S., the Company is subject to an excise tax on corporate stock repurchases, which is assessed as one percent of the fair market value of net corporate stock repurchases after December 31, 2022. The Company had no excise tax liability for fiscal 2024 and expects the impact of the excise tax on net corporate stock repurchases will not be material for fiscal 2025.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000950170-24-119570:notes:127]
[same as prior period, unchanged from 0000950170-24-052140:notes:126]

[0000950170-24-119570:notes:128]
[same as prior period, unchanged from 0000950170-24-052140:notes:127]

[0000950170-24-119570:notes:129]
[same as prior period, unchanged from 0000950170-24-052140:notes:128]

[0000950170-24-119570:notes:130]
|  |  | September 30,2024 |  |  | June 30,2024 |  |
| 2013 Equity Incentive Plan shares available for grant |  |  | 8,699 |  |  |  | 13,414 |  |
| Employee stock options and awards outstanding |  |  | 9,281 |  |  |  | 7,562 |  |
| 2014 Employee Stock Purchase Plan |  |  | 6,662 |  |  |  | 7,130 |  |
| Total shares reserved for issuance |  |  | 24,642 |  |  |  | 28,106 |  |

[0000950170-24-119570:notes:131]
[same as prior period, unchanged from 0000950170-24-052140:notes:130]

[0000950170-24-119570:notes:132]
[same as prior period, unchanged from 0000950170-24-052140:notes:131]

[0000950170-24-119570:notes:133]
|  |  | Three Months Ended |  |
|  |  | September 30,2024 |  |  | September 30,2023 |  |
| Cost of product revenues |  | $ | 618 |  |  | $ | 483 |  |
| Cost of subscription and support revenues |  |  | 689 |  |  |  | 866 |  |
| Research and development |  |  | 4,213 |  |  |  | 4,377 |  |
| Sales and marketing |  |  | 6,882 |  |  |  | 6,988 |  |
| General and administrative |  |  | 7,365 |  |  |  | 7,205 |  |
| Total share-based compensation expense |  | $ | 19,767 |  |  | $ | 19,919 |  |

[0000950170-24-119570:notes:134]
[same as prior period, unchanged from 0000950170-24-052140:notes:133]

[0000950170-24-119570:notes:135]
The following table summarizes stock option activity for the three months ended September 30, 2024 (in thousands, except per share amount and contractual term):

[0000950170-24-119570:notes:136]
|  |  | Number of Shares |  |  | Weighted-Average Exercise Price Per Share |  |  | Weighted-Average Remaining Contractual Term (years) |  |  | Aggregate Intrinsic Value |  |
| Options outstanding at June 30, 2024 |  |  | 1,073 |  |  | $ | 6.58 |  |  |  | 1.75 |  |  | $ | 7,376 |  |
| Granted |  |  | — |  |  |  | — |  |  |  |  |  |  |  |
| Exercised |  |  | (35 | ) |  |  | 6.40 |  |  |  |  |  |  |  |
| Canceled |  |  | — |  |  |  | — |  |  |  |  |  |  |  |
| Options outstanding at September 30, 2024 |  |  | 1,038 |  |  | $ | 6.58 |  |  |  | 1.52 |  |  | $ | 8,764 |  |
| Vested and expected to vest at September 30, 2024 |  |  | 1,038 |  |  | $ | 6.58 |  |  |  | 1.52 |  |  | $ | 8,764 |  |
| Exercisable at September 30, 2024 |  |  | 1,038 |  |  | $ | 6.58 |  |  |  | 1.52 |  |  | $ | 8,764 |  |

[0000950170-24-119570:notes:137]
The fair value of each stock option grant under the 2013 Plan is estimated on the date of grant using the Black-Scholes-Merton option valuation model. The expected term of options granted is derived from historical data on employee exercise and post-vesting employment termination behavior. The risk-free interest rate is based upon the estimated life of the option and the U.S. Treasury yield curve in effect at the time of grant. Expected volatility is based on the historical volatility on the Company’s stock. There were no stock options granted during the three months ended September 30, 2024 and 2023.

[0000950170-24-119570:notes:138]
[same as prior period, unchanged from 0000950170-24-052140:notes:137]

[0000950170-24-119570:notes:139]
[same as prior period, unchanged from 0000950170-24-052140:notes:138]

[0000950170-24-119570:notes:140]
The following table summarizes stock award activity for the three months ended September 30, 2024 (in thousands, except grant date fair value):

[0000950170-24-119570:notes:141]
|  |  | Number of Shares |  |  | Weighted- Average Grant Date Fair Value |  |  | Aggregate Fair Value |  |
| Non-vested stock awards outstanding at June 30, 2024 |  |  | 6,489 |  |  | $ | 22.65 |  |  |  |  |
| Granted |  |  | 3,903 |  |  |  | 15.85 |  |  |  |  |
| Released |  |  | (2,009 | ) |  |  | 20.84 |  |  |  |  |
| Canceled |  |  | (140 | ) |  |  | 24.80 |  |  |  |  |
| Non-vested stock awards outstanding at September 30, 2024 |  |  | 8,243 |  |  | $ | 19.95 |  |  | $ | 123,893 |  |
| Stock awards expected to vest at September 30, 2024 |  |  | 8,243 |  |  | $ | 19.95 |  |  | $ | 123,893 |  |

[0000950170-24-119570:notes:142]
The RSUs granted under the 2013 Plan vest over a period of time, generally one to three years, and are subject to participant's continued service to the Company. The stock awards granted during the three months ended September 30, 2024 included 1.1 million RSUs including the market condition awards discussed below to the named executive officers and directors.

[0000950170-24-119570:notes:143]
[same as prior period, unchanged from 0000950170-24-052140:notes:142]

[0000950170-24-119570:notes:144]
During the three months ended September 30, 2024 and 2023, the Compensation Committee of the Board granted 0.9 million and 0.7 million RSUs, respectively, with vesting based on market conditions (“MSU”) to certain of the Company’s executives. The MSUs granted during the three months ended September 30, 2024 were subject to total stockholder return ("TSR").  The MSUs granted during the three months ended September 30, 2023 included 0.4 million MSUs subject to TSR and 0.3 million MSUs subject to certain stock price targets.

[0000950170-24-119570:notes:145]
[same as prior period, unchanged from 0000950170-24-052140:notes:144]

[0000950170-24-119570:notes:146]
[same as prior period, unchanged from 0000950170-24-052140:notes:145]

[0000950170-24-119570:notes:147]
TSR is calculated based on the average closing price for the 30-trading days prior to the beginning and end of the performance periods. Performance is measured based on three periods, with the ability for up to one-third of target shares to vest after years one and two and the ability for up to the maximum of the full award to vest based on the full three-year TSR less any shares vested based on one- and two-year periods. Linear interpolation is used to determine the number of shares vested for achievement between target levels.

[0000950170-24-119570:notes:148]
The grant date fair value of each MSU was determined using the Monte Carlo simulation model. The weighted-average grant-date fair value of the TSR MSUs granted during the three months ended September 30, 2024 was $17.22 per share. The assumptions used in the Monte Carlo simulation included the expected volatility of 48%, risk-free interest rate of 3.86%, no expected dividend yield, expected term of three years and possible future stock prices over the performance period based on the historical stock and market prices. The weighted-average grant-date fair value of the TSR MSUs granted during the three months ended September 30, 2023 was $38.23 per share. The assumptions used in the Monte Carlo simulation included the expected volatility of 50%, risk-free interest rate of 4.59%, no expected dividend yield, expected term of three years, and possible future stock prices over the performance period based on the historical stock and market prices. The Company recognizes the expense related to these MSUs on a graded-vesting method over the estimated term.

[0000950170-24-119570:notes:149]
The stock price target MSUs vest upon the achievement of a certain stock price target over the defined performance period. The stock price target shall be deemed as achieved if the average closing stock price over any 30 consecutive trading days during the period from grant date through the third anniversary of the grant date equals or exceeds the price target of $41.38 for the initial performance period. Upon satisfaction of the initial stock price target, 50% of the target shares will vest on the third anniversary of the grant date and the remaining 50% will vest on the fourth anniversary of the grant date, subject to employees continued service through the applicable vesting dates. If the units are not earned on the last day of initial performance period, the units will remain outstanding and be eligible to be earned if the average closing stock price over any 30 consecutive trading days equals or exceeds the price target of $46.96.

[0000950170-24-119570:notes:150]
The grant date fair value of these stock price target MSUs was determined using the Monte Carlo simulation model. The weighted-average grant-date fair value of these stock price target MSUs granted during the three months ended September 30, 2023 was $28.80 per share. The assumptions used in the Monte Carlo simulation included the expected volatility of 63%, risk-free interest rate of 4.45%, no expected dividend yield, expected term of three years based on possible future stock prices over the performance period based on the historical stock prices. The Company recognizes the expense related to these MSUs on a graded-vesting method over the estimated term.

[0000950170-24-119570:notes:151]
On February 15, 2024 the Company modified certain terms and conditions of the stock price target MSU's for certain executive officers. Under the modified agreement, the stock price target over the initial and fourth year performance periods were revised to $23.00 and $26.00, respectively. All other contractual terms remained unchanged. The incremental compensation cost related to the modification was not material and will be recognized ratably over the remaining requisite service period.

[0000950170-24-119570:notes:152]
Employee Stock Purchase Plan

[0000950170-24-119570:notes:153]
[same as prior period, unchanged from 0000950170-24-052140:notes:150]

[0000950170-24-119570:notes:154]
There were 0.5 million and 0.5 million shares issued under the ESPP during the three months ended September 30, 2024 and 2023, respectively. The following assumptions were used to determine the grant-date fair values of the ESPP shares during the following periods:

[0000950170-24-119570:notes:155]
|  |  | Employee Stock Purchase Plan |  |
|  |  | Three Months Ended |  |
|  |  | September 30,2024 |  |  | September 30,2023 |  |
| Expected term |  | 0.5 years |  |  | 0.5 years |  |
| Risk-free interest rate |  |  | 5.04 | % |  |  | 5.54 | % |
| Volatility |  |  | 36 | % |  |  | 42 | % |
| Dividend yield |  |  | — | % |  |  | — | % |

[0000950170-24-119570:notes:156]
The weighted-average grant-date fair value of shares under the ESPP during the three months ended September 30, 2024 and 2023 was $3.74 and $8.09 per share, respectively.


## us-gaap:SegmentReportingDisclosureTextBlock

[0000950170-24-119570:notes:157]
[same as prior period, unchanged from 0000950170-24-052140:notes:154]

[0000950170-24-119570:notes:158]
[same as prior period, unchanged from 0000950170-24-052140:notes:155]

[0000950170-24-119570:notes:159]
See Note 3, Revenues, for the Company’s revenues by geographic region.

[0000950170-24-119570:notes:160]
[same as prior period, unchanged from 0000950170-24-052140:notes:157]

[0000950170-24-119570:notes:161]
|  |  | September 30,2024 |  |  | June 30,2024 |  |
| Americas |  | $ | 130,166 |  |  | $ | 136,745 |  |
| EMEA |  |  | 42,104 |  |  |  | 33,715 |  |
| APAC |  |  | 11,141 |  |  |  | 11,499 |  |
| Total long-lived assets |  | $ | 183,411 |  |  | $ | 181,959 |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000950170-24-119570:notes:162]
[same as prior period, unchanged from 0000950170-24-052140:notes:159]

[0000950170-24-119570:notes:163]
[same as prior period, unchanged from 0000950170-24-052140:notes:165]

[0000950170-24-119570:notes:164]
The Company uses derivative financial instruments to manage exposures to foreign currency risk that may or may not be designated as hedging instruments. The Company’s objective for holding derivatives is to use the most effective methods to minimize the impact of these exposures. The Company does not enter into derivatives for speculative or trading purposes. The Company enters into foreign exchange forward contracts to attempt to mitigate the effect of gains and losses generated by foreign currency transactions related to certain operating expenses and re-measurement of certain assets and liabilities denominated in foreign currencies.

[0000950170-24-119570:notes:165]
For foreign exchange forward contracts not designated as hedging instruments, the fair value of the Company’s derivatives in a gain position are recorded in “Prepaid expenses and other current assets” and derivatives in a loss position are recorded in “Other accrued liabilities” in the accompanying condensed consolidated balance sheets. Changes in the fair value of derivatives are recorded in “Other income (expense), net” in the accompanying condensed consolidated statements of operations. As of September 30, 2024 and June 30, 2024, foreign exchange forward contracts not designated as hedging instruments had a total notional principal amount of $42.6 million and $31.3 million, respectively. These contracts have maturities of 40 days or less. During the three months ended September 30, 2024 and 2023, the net gains and losses recorded in the condensed consolidated statement of operations from these contracts were net gains of $0.8 million and net losses of less than of $0.1 million, respectively. Changes in the fair value of these foreign exchange forward contracts are offset largely by remeasurement of the underlying assets and liabilities.

[0000950170-24-119570:notes:166]
There were no foreign exchange forward contracts that were designated as hedging instruments as of September 30, 2024 or June 30, 2024.
For the three months ended September 30, 2024 and 2023, the Company recognized foreign currency losses of $1.4 million and gains of $0.5 million, respectively, related to the change in fair value of foreign currency denominated assets and liabilities.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0000950170-24-119570:notes:167]
[same as prior period, unchanged from 0000950170-24-052140:notes:168]

[0000950170-24-119570:notes:168]
The Company recorded $1.3 million and $2.7 million of restructuring and related charges during the three months ended September 30, 2024 and 2023, respectively, which primarily related to the restructuring plans as noted below.

[0000950170-24-119570:notes:169]
During the three months ended September 30, 2024, the Company continued to incur additional charges related to the restructuring plans executed in prior years which primarily included severance and benefits costs and professional fees.

[0000950170-24-119570:notes:170]
During the third quarter of fiscal 2024, the Company executed a global reduction-in-force plan targeted towards the reorganization of the Company's research and development and sales and marketing functions to align the Company's workforce with its strategic priorities and to focus on specific geographies and industry segments with higher growth opportunities (the “Q3 2024 Plan”). During the three months ended September 30, 2024, the Company recorded restructuring charges of approximately $0.7 million related to the Q3 2024 Plan, which primarily consisted of severance and benefits expenses.

[0000950170-24-119570:notes:171]
During the second quarter of fiscal 2024, the Company executed a global reduction-in-force plan to rebalance its workforce to create greater efficiency and improve execution, in alignment with the Company's business and strategic priorities, while reducing its ongoing operating expenses to address reduced revenue and macro-economic conditions (the “Q2 2024 Plan”). During the three months ended September 30, 2024, the Company recorded restructuring charges of approximately $0.5 million related to the Q2 2024 Plan, which primarily consisted of employee severance and benefits expenses, legal and consulting fees.

[0000950170-24-119570:notes:172]
The Company expects to complete these ongoing restructuring plans by the end of fiscal year 2025 and expects to incur about $0.8 million in additional charges for the Q2 2024 Plan and the Q3 2024 Plan.

[0000950170-24-119570:notes:173]
During the third quarter of fiscal 2023, the Company initiated a restructuring plan to transform its business infrastructure and reduce its facilities footprint and the facilities related charges (the “2023 Plan”). As part of this project, the Company is moving engineering labs from its San Jose, California location to its Salem, New Hampshire location. This move is expected to help reduce the cost of operating the Company's labs. During the three months ended September 30, 2024, the Company recorded restructuring charges of approximately $0.1 million related to the 2023 Plan. The Company expects that the project will take about 3 to 6 months from September 30, 2024 to complete, and expects to incur charges of approximately $1.7 million throughout this period, primarily for asset disposals, contractor costs, and other fees.

[0000950170-24-119570:notes:174]
During the first quarter of fiscal 2024, the Company initiated a reduction-in-force plan to rebalance the workforce to create greater efficiency and improve execution in alignment with the Company's business and strategic priorities (the “Q1 2024 Plan”). It consisted primarily of workforce reduction to drive productivity in research and development, sales and marketing and provide efficiency across operations and general and administrative functions. During the three months ended September 30, 2023, the Company incurred charges of approximately $2.7 million related to the Q1 2024 Plan. As of June 30, 2024, the plan was completed.

[0000950170-24-119570:notes:175]
Restructuring liabilities are recorded in “Other accrued liabilities” in the accompanying condensed consolidated balance sheets. As of September 30, 2024 and 2023 the restructuring liability was $4.4 million and $0.9 million, respectively related to these restructuring plans.

[0000950170-24-119570:notes:176]
[same as prior period, unchanged from 0000950170-24-052140:notes:177]

[0000950170-24-119570:notes:177]
|  |  | Three Months Ended |  |
|  |  | September 30,2024 |  |  | September 30,2023 |  |
| Balance at beginning of period |  | $ | 11,469 |  |  | $ | — |  |
| Period charges |  |  | 1,573 |  |  |  | 2,776 |  |
| Period reversals |  |  | (296 | ) |  |  | (85 | ) |
| Period payments |  |  | (8,353 | ) |  |  | (1,766 | ) |
| Balance at end of period |  | $ | 4,393 |  |  | $ | 925 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0000950170-24-119570:notes:178]
[same as prior period, unchanged from 0000950170-24-052140:notes:179]

[0000950170-24-119570:notes:179]
For the three months ended September 30, 2024 and 2023, the Company recorded an income tax provision of $1.5 million and $4.6 million, respectively.

[0000950170-24-119570:notes:180]
The income tax provisions for the three months ended September 30, 2024 and 2023, consisted of (1) taxes on the income of the Company’s foreign subsidiaries, (2) state taxes in jurisdictions where the Company has no remaining state net operating losses (“NOLs”), (3) foreign withholding taxes, and (4) tax expense associated with the establishment of a U.S. deferred tax liability for amortizable goodwill resulting from the acquisition of Enterasys Networks, Inc., the wireless local area network business from Zebra Technologies Corporation, the Campus Fabric Business from Avaya and the Data Center Business from Brocade. In addition, the income tax provision for the three months ended September 30, 2023, includes US Federal income tax expense of $1.4 million. The interim

[0000950170-24-119570:notes:181]
income tax provisions for the three months ended September 30, 2024 and 2023 were calculated using the discrete effective tax rate method as allowed by ASC 740-270-30-18, Income Taxes – Interim Reporting. The discrete method is applied when the application of the estimated annual effective tax rate is impractical because it is not possible to reliably estimate the annual effective tax rate. The discrete method treats the year-to-date period as if it was the annual period and determines the income tax expense or benefit on that basis.  The Company believes that, at this time, the use of this discrete method is more appropriate than the annual effective tax rate method as (i) the estimated annual effective tax rate method is not reliable due to the high degree of uncertainty in estimating annual pretax earnings on a jurisdictional basis and (ii) the Company’s ongoing assessment that the recoverability of certain U.S. and Irish deferred tax assets is not more likely than not.

[0000950170-24-119570:notes:182]
[same as prior period, unchanged from 0000950170-24-052140:notes:183]

[0000950170-24-119570:notes:183]
The Company had $18.2 million of unrecognized tax benefits as of September 30, 2024. If fully recognized in the future, $0.2 million would impact the effective tax rate and $18.0 million would result in adjustments to deferred tax assets and corresponding adjustments to the valuation allowance with no impact to the effective tax rate. The Company does not anticipate any events to occur during the next twelve months that would materially reduce the unrealized tax benefit as currently stated in the Company’s condensed consolidated balance sheets.

[0000950170-24-119570:notes:184]
[same as prior period, unchanged from 0000950170-24-052140:notes:185]

[0000950170-24-119570:notes:185]
In general, the Company’s U.S. federal income tax returns are subject to examination by tax authorities for fiscal years 2004 forward due to NOLs and the Company’s state income tax returns are subject to examination for fiscal years 2005 and forward due to NOLs. The Company is currently under audit for income tax purposes in Germany for tax years ended June 30, 2019 through 2022.


## us-gaap:EarningsPerShareTextBlock

[0000950170-24-119570:notes:186]
[same as prior period, unchanged from 0000950170-24-052140:notes:187]

[0000950170-24-119570:notes:187]
Basic net income (loss) per share is calculated by dividing net income (loss) by the weighted-average number of shares of common stock outstanding during the period. Diluted net income (loss) per share is calculated by dividing net income (loss) by the weighted-average number of shares of common stock used in the basic net income (loss) per share calculation plus the dilutive effect of shares subject to repurchase, options and unvested RSUs.

[0000950170-24-119570:notes:188]
[same as prior period, unchanged from 0000950170-24-052140:notes:189]

[0000950170-24-119570:notes:189]
|  |  | Three Months Ended |  |
|  |  | September 30,2024 |  |  | September 30,2023 |  |
| Net income (loss) |  | $ | (10,504 | ) |  | $ | 28,676 |  |
| Weighted-average shares used in per share calculation – basic |  |  | 131,176 |  |  |  | 128,782 |  |
| Options to purchase common stock |  |  | — |  |  |  | 898 |  |
| Restricted stock units |  |  | — |  |  |  | 3,783 |  |
| Weighted-average shares used in per share calculation – diluted |  |  | 131,176 |  |  |  | 133,463 |  |
| Net income (loss) per share – basic and diluted |  |  |  |  |  |  |
| Net income (loss) per share – basic |  | $ | (0.08 | ) |  | $ | 0.22 |  |
| Net income (loss) per share – diluted |  | $ | (0.08 | ) |  | $ | 0.21 |  |

[0000950170-24-119570:notes:190]
[same as prior period, unchanged from 0000950170-24-052140:notes:191]

[0000950170-24-119570:notes:191]
|  |  | Three Months Ended |  |
|  |  | September 30,2024 |  |  | September 30,2023 |  |
| Options to purchase common stock |  |  | 1,063 |  |  |  | — |  |
| Restricted stock units |  |  | 5,423 |  |  |  | 1,071 |  |
| Employee Stock Purchase Plan shares |  |  | 376 |  |  |  | 267 |  |
| Total shares excluded |  |  | 6,862 |  |  |  | 1,338 |  |


## ecd:MtrlTermsOfTrdArrTextBlock

[0000950170-24-119570:notes:192]
On September 10, 2024, Katayoun ("Katy") Motiey, the Company's Chief Legal, Administrative & Sustainability Officer, adopted a Rule 10b5-1 trading arrangement that is intended to satisfy the affirmative defense conditions of Rule 10b5-1(c) for the sale of up to 37,000 shares of the Company's common stock until December 11, 2025.
