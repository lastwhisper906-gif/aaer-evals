# EXTR note change history — 0000950170-24-052140 → 0000950170-24-119570


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2024-10-31):
[0000950170-24-119570:note_history:1]
The Company currently has arrangements with contract manufacturers and suppliers for the manufacture of its products. Those arrangements allow the contract manufacturers to procure long lead-time component inventory based upon a rolling production forecast provided by the Company. The Company is obligated to purchase long lead-time component inventory that its contract manufacturer procures in accordance with the forecast, unless the Company gives notice of order cancellation outside of applicable component lead-times. As of September 30, 2024, the Company had commitments to purchase $37.3 million of inventory.
  (was, 2024-05-02, similarity 0.9885):
[0000950170-24-052140:note_history:1]
The Company currently has arrangements with contract manufacturers and suppliers for the manufacture of its products. Those arrangements allow the contract manufacturers to procure long lead-time component inventory based upon a rolling production forecast provided by the Company. The Company is obligated to purchase long lead-time component inventory that its contract manufacturer procures in accordance with the forecast, unless the Company gives notice of order cancellation outside of applicable component lead-times. As of March 31, 2024, the Company had commitments to purchase $51.5 million of inventory.

- added (2024-10-31):
[0000950170-24-119570:note_history:2]
In accordance with applicable accounting guidance, the Company records accruals for certain of its outstanding legal proceedings, investigations or claims when it is probable that a liability will be incurred, and the amount of loss can be reasonably estimated. The

- changed (2024-10-31):
[0000950170-24-119570:note_history:3]
Company evaluates, at least on a quarterly basis, developments in legal proceedings, investigations or claims that could affect the amount of any accrual, as well as any developments that would result in a loss contingency to become both probable and reasonably estimable. When a loss contingency is not both probable and reasonably estimable, the Company does not record a loss accrual. However, if the loss (or an additional loss in excess of any prior accrual) is at least reasonably possible and material, then the Company would disclose an estimate of the possible loss or range of loss, if such estimate can be made, or disclose that an estimate cannot be made. The assessment whether a loss is probable or a reasonable possibility, and whether the loss or a range of loss is estimable, involves a series of complex judgments about future events. Even if a loss is reasonably possible, the Company may not be able to estimate a range of possible loss, particularly where (i) the damages sought are substantial or indeterminate, (ii) the proceedings are in the early stages, or (iii) the matters involve novel or unsettled legal theories or a large number of parties. In such cases, there is considerable uncertainty regarding the ultimate resolution of such matters, including the amount of any possible loss, fine or penalty. However, an adverse resolution of one or more of such matters could have a material adverse effect on the Company's results of operations in a particular quarter or fiscal year.
  (was, 2024-05-02, similarity 0.9136):
[0000950170-24-052140:note_history:3]
In accordance with applicable accounting guidance, the Company records accruals for certain of its outstanding legal proceedings, investigations or claims when it is probable that a liability will be incurred, and the amount of loss can be reasonably estimated. The Company evaluates, at least on a quarterly basis, developments in legal proceedings, investigations or claims that could affect the amount of any accrual, as well as any developments that would result in a loss contingency to become both probable and reasonably estimable. When a loss contingency is not both probable and reasonably estimable, the Company does not record a loss accrual. However, if the loss (or an additional loss in excess of any prior accrual) is at least reasonably possible and material, then the Company would disclose an estimate of the possible loss or range of loss, if such estimate can be made, or disclose that an estimate cannot be made. The assessment whether a loss is probable or a reasonable possibility, and whether the loss or a range of loss is estimable, involves a series of complex judgments about future events. Even if a loss is reasonably possible, the Company may not be able to estimate a range of possible loss, particularly where (i) the damages sought are substantial or indeterminate, (ii) the proceedings are in the early stages, or (iii) the matters involve novel or unsettled legal theories or a large number of parties. In such cases, there is considerable uncertainty regarding the ultimate resolution of such matters, including the amount of any possible loss, fine or penalty. However, an adverse resolution of one or more of such matters could have a material adverse effect on the Company's results of operations in a particular quarter or fiscal year.

- changed (2024-10-31):
[0000950170-24-119570:note_history:4]
On February 1, 2018, Orckit IP, LLC (“Orckit”) filed a patent infringement lawsuit against the Company and its Irish and German subsidiaries in the District Court in Dusseldorf, Germany. The lawsuit alleges direct and indirect infringement of the German portion of a patent (“EP ‘364”) based on the offer, distribution, use, possession and/or importation into Germany of certain network switches that are equipped with the ExtremeXOS operating system. Orckit is seeking injunctive relief, accounting, and an unspecified declaration of liability for damages and costs of the lawsuit. On January 28, 2020, the Court rendered a decision in the infringement case in favor of the Company. On October 17, 2024, Orckit informed the District Court in Dusseldorf, Germany of its intention to withdraw its complaint.
  (was, 2024-05-02, similarity 0.8883):
[0000950170-24-052140:note_history:4]
On February 1, 2018, Orckit IP, LLC (“Orckit”) filed a patent infringement lawsuit against the Company and its Irish and German subsidiaries in the District Court in Dusseldorf, Germany. The lawsuit alleges direct and indirect infringement of the German portion of a patent (“EP ‘364”) based on the offer, distribution, use, possession and/or importation into Germany of certain network switches that are equipped with the ExtremeXOS operating system. Orckit is seeking injunctive relief, accounting, and an unspecified declaration of liability for damages and costs of the lawsuit. On January 28, 2020, the Court rendered a decision in the infringement case in favor of the Company. The matter is proceeding through the appellate process.

- changed (2024-10-31):
[0000950170-24-119570:note_history:5]
The Company filed a nullity action related to the EP ‘364 patent on May 3, 2018, and one related to the EP ‘077 patent on October 31, 2019, both in the Federal Patent Court in Munich. The Federal Patent Court in Munich found the EP ‘364 patent to be valid and the Company filed an appeal, which was dismissed on October 12, 2023. On October 25, 2022 the Federal Patent Court in Munich issued an opinion partially invalidating the EP ‘077 patent and the Company and Orckit have filed appeals. An oral hearing has been set for December 10, 2024.
  (was, 2024-05-02, similarity 0.9525):
[0000950170-24-052140:note_history:5]
The Company filed a nullity action related to the EP ‘364 patent on May 3, 2018, and one related to the EP ‘077 patent on October 31, 2019, both in the Federal Patent Court in Munich. The Federal Patent Court in Munich found the EP ‘364 patent to be valid and the Company filed an appeal, which was dismissed on October 12, 2023. On October 25, 2022 the Federal Patent Court in Munich issued an opinion partially invalidating the EP ‘077 patent and the Company and Orckit have filed appeals.

- changed (2024-10-31):
[0000950170-24-119570:note_history:6]
On October 26, 2020, SNMP Research, Inc. and SNMP Research International, Inc. (collectively, “SNMP”) filed a lawsuit against the Company in the Eastern District of Tennessee for copyright infringement, alleging that the Company was not properly licensed to use its software. SNMP is seeking actual damages and profits attributed to the infringement, as well as equitable relief. The Company filed a motion to transfer the case to the Northern District of California. The motion to dismiss was denied in part and denied without prejudice in part. On March 2, 2023, SNMP filed an amended complaint adding claims against Extreme on additional products for copyright infringement, breach of contract, and fraud. On March 16, 2023, the Company filed a motion to dismiss, challenging multiple claims from the amended complaint, which was denied on January 30, 2024. On March 20, 2023, the Company filed a motion to refer questions to the U.S. Copyright Office on the invalidity of SNMP’s copyrights, which was denied on March 18, 2024. The trial date and all other dates were vacated and the court ordered mandatory mediation, which took place in September 2024.
  (was, 2024-05-02, similarity 0.6358):
[0000950170-24-052140:note_history:6]
On October 26, 2020, SNMP Research, Inc. and SNMP Research International, Inc. (collectively, “SNMP”) filed a lawsuit against the Company in the Eastern District of Tennessee for copyright infringement, alleging that the Company was not properly licensed to use its software. SNMP is seeking actual damages and profits attributed to the infringement, as well as equitable relief. The Company filed a motion to transfer the case to the Northern District of California. The motion to dismiss was denied in part and denied without

- changed (2024-10-31):
[0000950170-24-119570:note_history:7]
On April 15, 2021, Mala Technologies Ltd. (“Mala”) filed a patent infringement lawsuit against the Company and its Irish and German subsidiaries in the District Court in Dusseldorf, Germany. The lawsuit alleges indirect infringement of the German portion of a patent (“EP ‘498”) based on the offer and sale in Germany of certain network switches equipped with the ExtremeXOS operating system. Mala is seeking injunctive relief, accounting, and an unspecified declaration of liability for damages and costs of the lawsuit. On December 20, 2022, the trial court ruled that the Company did not infringe the EP ‘498 patent and dismissed Mala’s complaint entirely. Mala has filed an appeal and an oral hearing has been set for March 27, 2025.
  (was, 2024-05-02, similarity 0.9328):
[0000950170-24-052140:note_history:7]
On April 15, 2021, Mala Technologies Ltd. (“Mala”) filed a patent infringement lawsuit against the Company and its Irish and German subsidiaries in the District Court in Dusseldorf, Germany. The lawsuit alleges indirect infringement of the German portion of a patent (“EP ‘498”) based on the offer and sale in Germany of certain network switches equipped with the ExtremeXOS operating system. Mala is seeking injunctive relief, accounting, and an unspecified declaration of liability for damages and costs of the lawsuit. On December 20, 2022, the trial court ruled that the Company did not infringe the EP ‘498 patent and dismissed Mala’s complaint entirely. Mala has filed an appeal and the matter is proceeding through the appellate process.

- added (2024-10-31):
[0000950170-24-119570:note_history:8]
Steamfitters Local 449 Pension & Retirement Security Funds v. Extreme Networks, Inc., et al.

- added (2024-10-31):
[0000950170-24-119570:note_history:9]
On August 13, 2024, a putative securities class action (the “Class Action”) was filed in the United States District Court for the Northern District of California captioned Steamfitters Local 449 Pension & Retirement Security Funds v. Extreme Networks, Inc., et al., Case No. 5:24-cv-05102-TLT, naming the Company and certain of our current and former executive officers as defendants. The lawsuit is purportedly brought on behalf of purchasers of Extreme Networks securities between July 27, 2022 and January 30, 2024 (the “Class Period”). The complaint alleges claims under Sections 10(b) and 20(a) of the Securities Exchange Act of 1934, and Rule 10b-5 promulgated thereunder, based on allegedly false and misleading statements about our business and prospects during the Class Period. The lawsuit seeks unspecified damages. It is expected that the Court will select a lead plaintiff on or around January 7, 2025.

- removed (2024-10-31):
[0000950170-24-052140:note_history:10]
prejudice in part. On March 2, 2023, SNMP filed an amended complaint adding claims against Extreme on additional products for copyright infringement, breach of contract, and fraud. On March 16, 2023, the Company filed a motion to dismiss, challenging multiple claims from the amended complaint, which was denied on January 30, 2024. On March 20, 2023, the Company filed a motion to refer questions to the U.S. Copyright Office on the invalidity of SNMP’s copyrights, which was denied on March 18, 2024. The trial date has been set for October 2024.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2024-10-31):
[0000950170-24-119570:note_history:11]
The unaudited condensed consolidated financial statements reflect all adjustments, consisting only of normal recurring adjustments that, in the opinion of management, are necessary for a fair presentation of the results of operations and cash flows for the interim periods presented and the financial condition of Extreme at September 30, 2024. The results of operations for the three months ended September 30, 2024 are not necessarily indicative of the results that may be expected for fiscal 2025 or any future periods.
  (was, 2024-05-02, similarity 0.6824):
[0000950170-24-052140:note_history:11]
The unaudited condensed consolidated financial statements reflect all adjustments, consisting only of normal recurring adjustments that, in the opinion of management, are necessary for a fair presentation of the results of operations and cash flows for the interim periods presented and the financial condition of Extreme at March 31, 2024. The results of operations for the three and nine months ended March 31, 2024 are not necessarily indicative of the results that may be expected for fiscal 2024 or any future periods.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2024-10-31):
[0000950170-24-119570:note_history:12]
|  |  | September 30,2024 |  |  | June 30,2024 |  |
| Current portion of long-term debt: |  |  |  |  |  |  |
| Term Loan |  | $ | 11,250 |  |  | $ | 10,000 |  |
| Less: unamortized debt issuance costs |  |  | (761 | ) |  |  | (674 | ) |
| Current portion of long-term debt |  | $ | 10,489 |  |  | $ | 9,326 |  |
| Long-term debt, less current portion: |  |  |  |  |  |  |
| Term Loan |  | $ | 176,250 |  |  | $ | 180,000 |  |
| Less: unamortized debt issuance costs |  |  | (1,819 | ) |  |  | (1,735 | ) |
| Total long-term debt, less current portion |  |  | 174,431 |  |  |  | 178,265 |  |
| Total debt |  | $ | 184,920 |  |  | $ | 187,591 |  |
  (was, 2024-05-02, similarity 0.9471):
[0000950170-24-052140:note_history:12]
|  |  | March 31,2024 |  |  | June 30,2023 |  |
| Current portion of long-term debt: |  |  |  |  |  |  |
| Term Loan |  | $ | 10,000 |  |  | $ | 10,000 |  |
| Revolving Facility |  |  | — |  |  |  | 25,000 |  |
| Less: unamortized debt issuance costs |  |  | (674 | ) |  |  | (674 | ) |
| Current portion of long-term debt |  | $ | 9,326 |  |  | $ | 34,326 |  |
| Long-term debt, less current portion: |  |  |  |  |  |  |
| Term Loan |  | $ | 182,500 |  |  | $ | 190,000 |  |
| Less: unamortized debt issuance costs |  |  | (1,903 | ) |  |  | (2,409 | ) |
| Total long-term debt, less current portion |  |  | 180,597 |  |  |  | 187,591 |  |
| Total debt |  | $ | 189,923 |  |  | $ | 221,917 |  |

- changed (2024-10-31):
[0000950170-24-119570:note_history:13]
On June 22, 2023, the Company entered into a Second Amended and Restated Credit Agreement (the “2023 Credit Agreement”), by and among the Company, as borrower, BMO Harris Bank, N.A., as an issuing lender and swingline lender, Bank of America, N.A., JPMorgan Chase Bank, N.A., PNC Bank, National Association, and Wells Fargo Bank, National Association, as issuing lenders, the financial institutions or entities party thereto as lenders, and Bank of Montreal, as administrative agent and collateral agent, which amended and restated the 2019 Credit Agreement. The 2023 Credit Agreement provides for i) a $200.0 million first lien term loan facility in an aggregate principal amount (the “2023 Term Loan”), ii) a $150.0 million five-year revolving credit facility (the “2023 Revolving Facility”) and, iii) an uncommitted additional incremental loan facility in the principal amount of up to $100.0 million.
  (was, 2024-05-02, similarity 0.887):
[0000950170-24-052140:note_history:13]
On June 22, 2023, the Company entered into a Second Amended and Restated Credit Agreement (the “2023 Credit Agreement”), by and among the Company, as borrower, BMO Harris Bank, N.A., as an issuing lender and swingline lender, Bank of America, N.A., JPMorgan Chase Bank, N.A., PNC Bank, National Association, and Wells Fargo Bank, National Association, as issuing lenders, the financial institutions or entities party thereto as lenders, and Bank of Montreal, as administrative agent and collateral agent, which amended and restated the 2019 Credit Agreement. The 2023 Credit Agreement provides for i) a $200.0 million first lien term loan facility in an aggregate principal amount (the “2023 Term Loan”), ii) a $150.0 million five-year revolving credit facility (the “2023 Revolving Facility”) and, iii) an uncommitted additional incremental loan facility in the principal amount of up to $100.0 million. On June 22, 2023, the Company borrowed $25.0 million against its $150.0 million revolving credit facility to refinance its debt. On July 7, 2023, the Company made a payment of $25.0 million to pay off the outstanding revolving credit balance.

- changed (2024-10-31):
[0000950170-24-119570:note_history:14]
The 2023 Credit Agreement requires the Company to maintain certain minimum financial ratios at the end of each fiscal quarter. The 2023 Credit Agreement also includes covenants and restrictions that limit, among other things, the Company’s ability to incur additional indebtedness, create liens upon any of its property, merge, consolidate or sell all or substantially all of its assets. The 2023 Credit Agreement also includes customary events of default which may result in acceleration of the outstanding balance.
  (was, 2024-05-02, similarity 0.8794):
[0000950170-24-052140:note_history:14]
The 2023 Credit Agreement requires the Company to maintain certain minimum financial ratios at the end of each fiscal quarter. The 2023 Credit Agreement also includes covenants and restrictions that limit, among other things, the Company’s ability to incur additional indebtedness, create liens upon any of its property, merge, consolidate or sell all or substantially all of its assets. The 2023 Credit Agreement also includes customary events of default which may result in acceleration of the outstanding balance. During the nine months ended March 31, 2024, the Company was in compliance with all the terms and financial covenants of the 2023 Credit Agreement.

- added (2024-10-31):
[0000950170-24-119570:note_history:15]
On August 14, 2024, the Company entered into an Amendment Number One to the 2023 Credit Agreement (the “Amended Credit Agreement”). Under the Amended Credit Agreement, the Company modified the definition of the consolidated EBITDA for the purposes of evaluating compliance with financial covenants under the 2023 Credit Agreement. The amended definition of consolidated EBITDA modifies the amount and type of add-backs that are allowable to better align with the Company's operations and activities. Further, the Amended Credit Agreement provides a waiver for the Company's compliance with the consolidated interest charge coverage ratio for each of the quarters ended June 30, 2024, September 30, 2024, and December 31, 2024.

- added (2024-10-31):
[0000950170-24-119570:note_history:16]
During the three months ended September 30, 2024, the Company was in compliance with all the terms and financial covenants of the Amended Credit Agreement.

- added (2024-10-31):
[0000950170-24-119570:note_history:17]
Financing costs incurred in connection with obtaining and modifying long-term financing are deferred and amortized over the term of the related indebtedness or credit agreement. Amortization of deferred financing costs are included in “Interest expense” in the accompanying condensed consolidated statements of operations. During the three months ended September 30, 2024, the Company capitalized approximately $0.7 million of debt cost related to the Amended Credit Agreement. The remaining unamortized debt issuance cost related to the prior arrangement and the newly capitalized costs will be amortized over the remaining term of the loan arrangement. Amortization of debt issuance costs included in “Interest expense”  were $0.3 million for each of the three months ended September 30, 2024 and 2023. The interest rate as of September 30, 2024 was 7.52% and as of September 30, 2023 was 7.45%.

- added (2024-10-31):
[0000950170-24-119570:note_history:18]
As of September 30, 2024, the Company did not have any outstanding balance against its 2023 Revolving Facility. The Company had $135.8 million of availability under the 2023 Revolving Facility as of September 30, 2024. During the three months ended September 30, 2024 and 2023, the Company did not make any additional payments against its term loan facility other than the scheduled payments per the terms of the Amended Credit Agreement.

- changed (2024-10-31):
[0000950170-24-119570:note_history:19]
The Company had $14.2 million of outstanding letters of credit as of September 30, 2024.
  (was, 2024-05-02, similarity 0.9351):
[0000950170-24-052140:note_history:19]
The Company had $14.5 million of outstanding letters of credit as of March 31, 2024.

- removed (2024-10-31):
[0000950170-24-052140:note_history:20]
Financing costs incurred in connection with obtaining long-term financing are deferred and amortized over the term of the related indebtedness or credit agreement. Amortization of deferred financing costs included in “Interest expense” in the accompanying condensed consolidated statements of operations were $0.3 million and $0.7 million for the three months ended March 31, 2024 and 2023, respectively, and were $0.8 million and $2.2 million for the nine months ended March 31, 2024 and 2023, respectively. The interest rate as of March 31, 2024 was 7.44% and as of March 31, 2023 was 5.97%.

- removed (2024-10-31):
[0000950170-24-052140:note_history:21]
As of March 31, 2024, the Company did not have any outstanding balance against its 2023 Revolving Facility. The Company had $135.5 million of availability under the 2023 Revolving Facility as of March 31, 2024. During the three and nine months ended March 31, 2024 the Company did not make any additional payments against its term loan facility other than the scheduled payments per the terms of the 2023 Credit Agreement. During the nine months ended March 31, 2023, the Company made an additional payment of $45.5 million, against its term loan facility under the 2019 Credit Agreement.


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2024-10-31):
[0000950170-24-119570:note_history:22]
|  |  | September 30,2024 |  |  | June 30,2024 |  |
| Current portion of long-term debt: |  |  |  |  |  |  |
| Term Loan |  | $ | 11,250 |  |  | $ | 10,000 |  |
| Less: unamortized debt issuance costs |  |  | (761 | ) |  |  | (674 | ) |
| Current portion of long-term debt |  | $ | 10,489 |  |  | $ | 9,326 |  |
| Long-term debt, less current portion: |  |  |  |  |  |  |
| Term Loan |  | $ | 176,250 |  |  | $ | 180,000 |  |
| Less: unamortized debt issuance costs |  |  | (1,819 | ) |  |  | (1,735 | ) |
| Total long-term debt, less current portion |  |  | 174,431 |  |  |  | 178,265 |  |
| Total debt |  | $ | 184,920 |  |  | $ | 187,591 |  |
  (was, 2024-05-02, similarity 0.9471):
[0000950170-24-052140:note_history:22]
|  |  | March 31,2024 |  |  | June 30,2023 |  |
| Current portion of long-term debt: |  |  |  |  |  |  |
| Term Loan |  | $ | 10,000 |  |  | $ | 10,000 |  |
| Revolving Facility |  |  | — |  |  |  | 25,000 |  |
| Less: unamortized debt issuance costs |  |  | (674 | ) |  |  | (674 | ) |
| Current portion of long-term debt |  | $ | 9,326 |  |  | $ | 34,326 |  |
| Long-term debt, less current portion: |  |  |  |  |  |  |
| Term Loan |  | $ | 182,500 |  |  | $ | 190,000 |  |
| Less: unamortized debt issuance costs |  |  | (1,903 | ) |  |  | (2,409 | ) |
| Total long-term debt, less current portion |  |  | 180,597 |  |  |  | 187,591 |  |
| Total debt |  | $ | 189,923 |  |  | $ | 221,917 |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2024-10-31):
[0000950170-24-119570:note_history:23]
The following table sets forth the Company’s net revenues disaggregated by geographic region (in thousands):
  (was, 2024-05-02, similarity 0.766):
[0000950170-24-052140:note_history:23]
The following table sets forth the Company’s net revenues disaggregated by sales channel and geographic region based on the billing addresses of its customers (in thousands):

- added (2024-10-31):
[0000950170-24-119570:note_history:24]
|  | Three Months Ended |  |
|  |  | September 30,2024 |  |  | September 30,2023 |  |
| Americas: |  |  |  |  |  |  |
| United States |  | $ | 153,253 |  |  | $ | 182,752 |  |
| Other |  |  | 12,182 |  |  |  | 12,897 |  |
| Total Americas |  |  | 165,435 |  |  |  | 195,649 |  |
| EMEA |  |  | 84,918 |  |  |  | 143,603 |  |
| APAC |  |  | 18,851 |  |  |  | 13,885 |  |
| Total net revenues |  | $ | 269,204 |  |  | $ | 353,137 |  |

- removed (2024-10-31):
[0000950170-24-052140:note_history:25]
|  |  | Three Months Ended |  |
|  |  | March 31,2024 |  |  | March 31,2023 |  |
|  |  | Distributor |  | Direct |  | Total |  |  | Distributor |  | Direct |  | Total |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  | $ | 52,543 |  | $ | 71,539 |  | $ | 124,082 |  |  | $ | 74,743 |  | $ | 64,337 |  | $ | 139,080 |  |
| Other |  |  | 5,934 |  |  | 4,357 |  |  | 10,291 |  |  |  | 14,079 |  |  | 4,523 |  |  | 18,602 |  |
| Total Americas |  |  | 58,477 |  |  | 75,896 |  |  | 134,373 |  |  |  | 88,822 |  |  | 68,860 |  |  | 157,682 |  |
| EMEA |  |  | 18,313 |  |  | 40,722 |  |  | 59,035 |  |  |  | 111,664 |  |  | 40,326 |  |  | 151,990 |  |
| APAC* |  |  | (1,464 | ) |  | 19,092 |  |  | 17,628 |  |  |  | 5,186 |  |  | 17,649 |  |  | 22,835 |  |
| Total net revenues |  | $ | 75,326 |  | $ | 135,710 |  | $ | 211,036 |  |  | $ | 205,672 |  | $ | 126,835 |  | $ | 332,507 |  |

- removed (2024-10-31):
[0000950170-24-052140:note_history:26]
|  |  | Nine Months Ended |  |
|  |  | March 31,2024 |  |  | March 31,2023 |  |
|  |  | Distributor |  | Direct |  | Total |  |  | Distributor |  | Direct |  | Total |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  | $ | 251,694 |  | $ | 204,689 |  | $ | 456,383 |  |  | $ | 245,852 |  | $ | 203,991 |  | $ | 449,843 |  |
| Other |  |  | 16,709 |  |  | 19,565 |  |  | 36,274 |  |  |  | 14,080 |  |  | 4,523 |  |  | 18,603 |  |
| Total Americas |  |  | 268,403 |  |  | 224,254 |  |  | 492,657 |  |  |  | 259,932 |  |  | 208,514 |  |  | 468,446 |  |
| EMEA |  |  | 184,706 |  |  | 128,537 |  |  | 313,243 |  |  |  | 285,066 |  |  | 120,482 |  |  | 405,548 |  |
| APAC |  |  | 7,510 |  |  | 47,140 |  |  | 54,650 |  |  |  | 14,627 |  |  | 59,923 |  |  | 74,550 |  |
| Total net revenues |  | $ | 460,619 |  | $ | 399,931 |  | $ | 860,550 |  |  | $ | 559,625 |  | $ | 388,919 |  | $ | 948,544 |  |

- removed (2024-10-31):
[0000950170-24-052140:note_history:27]
*The distributor revenue in the APAC region for the three months ended March 31, 2024 reflects a higher level of customer rebates for the distributors, resulting from higher sell-through to end users than the Company's product sales into these distributors.


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2024-10-31):
[0000950170-24-119570:note_history:28]
The Company accounts for revenues in accordance with Accounting Standards Codification (“ASC”) 606, Revenue from Contracts with Customers. The Company derives the majority of its revenues from sales of its networking equipment, with the remaining revenues generated from sales of subscription and support, which primarily includes software subscriptions delivered as software as a service (“SaaS”) and additional revenues from maintenance contracts, professional services and training for its products. The Company sells its products, SaaS and maintenance contracts direct to customers and partners in two distribution channels, or tiers. The first tier consists of a limited number of independent distributors that stock the Company's products and sell primarily to resellers. The second tier of the distribution channel consists of non-stocking distributors and value-added resellers that sell directly to end-users. Products and subscription and support may be sold separately or in bundled packages.
  (was, 2024-05-02, similarity 0.9985):
[0000950170-24-052140:note_history:28]
The Company accounts for revenues in accordance with Accounting Standards Codification (“ASC”) 606, Revenue from Contracts with Customers. The Company derives the majority of its revenues from sales of its networking equipment, with the remaining revenues generated from sales of subscription and support, which primarily includes software subscriptions delivered as software as a service (“SaaS”) and additional revenues from maintenance contracts, professional services and training for its products. The Company sells its products, SaaS and maintenance contracts direct to customers and to partners in two distribution channels, or tiers. The first tier consists of a limited number of independent distributors that stock the Company's products and sell primarily to resellers. The second tier of the distribution channel consists of non-stocking distributors and value-added resellers that sell directly to end-users. Products and subscription and support may be sold separately or in bundled packages.

- changed (2024-10-31):
[0000950170-24-119570:note_history:29]
The Company’s performance obligations are satisfied at a point in time or over time as the customer receives and consumes the benefits provided. Substantially all of the Company’s product sales revenues are recognized at a point in time. Substantially all of the Company’s subscription and support revenues are recognized over time. For revenues recognized over time, the Company primarily uses an input measure, days elapsed, to measure progress.
  (was, 2024-05-02, similarity 0.9887):
[0000950170-24-052140:note_history:29]
The Company’s performance obligations are satisfied at a point in time or over time as the customer receives and consumes the benefits provided. Substantially all of the Company’s product sales revenues are recognized at a point in time. Substantially all of the Company’s subscription and support revenues are recognized over time. For revenues recognized over time, the Company uses an input measure, days elapsed, to measure progress.

- added (2024-10-31):
[0000950170-24-119570:note_history:30]
As of September 30, 2024, the Company had $576.9 million of remaining performance obligations, which primarily comprised deferred support and deferred SaaS subscription revenues. The Company expects to recognize approximately 43% of its deferred revenue as revenue in the remainder of fiscal 2025, an additional 28% in fiscal 2026, and the remaining 29% of the balance thereafter.

- changed (2024-10-31):
[0000950170-24-119570:note_history:31]
Revenue recognized for the three months ended September 30, 2024 and 2023 that was included in the deferred revenue balance at the beginning of each period was $100.3 million and $89.7 million, respectively.
  (was, 2024-05-02, similarity 0.6444):
[0000950170-24-052140:note_history:31]
Revenue recognized for the three months ended March 31, 2024 and 2023 that was included in the deferred revenue balance at the beginning of each period was $95.9 million and $81.0 million, respectively. Revenue recognized for the nine months ended March 31, 2024 and 2023 that was included in the deferred revenue balance at the beginning of each period was $230.8 million and $193.7 million, respectively.

- changed (2024-10-31):
[0000950170-24-119570:note_history:32]
Contract Costs. The Company recognizes the incremental costs of obtaining contracts as an expense when incurred if the amortization period of the assets that the Company otherwise would have recognized is one year or less. Management expects that commission fees paid to sales representatives as a result of obtaining subscription and support contracts and contract renewals are recoverable and therefore the Company’s condensed consolidated balance sheets included capitalized balances in the amount of $24.2 million and $24.7 million as of September 30, 2024 and June 30, 2024, respectively. Capitalized commissions are included within other assets in the condensed consolidated balance sheets. Capitalized commission fees are amortized on a straight-line basis over the average period of service contracts of approximately three years, and are included in “Sales and marketing” in the accompanying condensed consolidated statements of operations. Amortization recognized during the three months ended September 30, 2024 and 2023 was $3.0 million and $2.6 million, respectively.
  (was, 2024-05-02, similarity 0.9278):
[0000950170-24-052140:note_history:32]
Contract Costs. The Company recognizes the incremental costs of obtaining contracts as an expense when incurred if the amortization period of the assets that the Company otherwise would have recognized is one year or less. Management expects that commission fees paid to sales representatives as a result of obtaining subscription and support contracts and contract renewals are recoverable and therefore the Company’s condensed consolidated balance sheets included capitalized balances in the amount of $22.7 million and $20.0 million at March 31, 2024 and June 30, 2023, respectively. Capitalized commissions are included within other assets in the condensed consolidated balance sheets. Capitalized commission fees are amortized on a straight-line basis over the average period of service contracts of approximately three and a half years, and are included in “Sales and marketing” in the accompanying condensed consolidated statements of operations. Amortization recognized during the three months ended March 31, 2024 and 2023 was $2.8 million and $2.3 million, respectively. Amortization recognized during the nine months ended March 31, 2024 and 2023 was $8.0 million and $6.7 million, respectively.

- changed (2024-10-31):
[0000950170-24-119570:note_history:33]
The Company operates in three geographic regions: Americas, EMEA (Europe, Middle East and Africa) and APAC (Asia Pacific). The following table sets forth the Company’s net revenues disaggregated by geographic region (in thousands):
  (was, 2024-05-02, similarity 0.8106):
[0000950170-24-052140:note_history:33]
The Company operates in three geographic regions: Americas, EMEA (Europe, Middle East and Africa) and APAC (Asia Pacific). The following table sets forth the Company’s net revenues disaggregated by sales channel and geographic region based on the billing addresses of its customers (in thousands):

- added (2024-10-31):
[0000950170-24-119570:note_history:34]
|  | Three Months Ended |  |
|  |  | September 30,2024 |  |  | September 30,2023 |  |
| Americas: |  |  |  |  |  |  |
| United States |  | $ | 153,253 |  |  | $ | 182,752 |  |
| Other |  |  | 12,182 |  |  |  | 12,897 |  |
| Total Americas |  |  | 165,435 |  |  |  | 195,649 |  |
| EMEA |  |  | 84,918 |  |  |  | 143,603 |  |
| APAC |  |  | 18,851 |  |  |  | 13,885 |  |
| Total net revenues |  | $ | 269,204 |  |  | $ | 353,137 |  |

- added (2024-10-31):
[0000950170-24-119570:note_history:35]
For the three months ended September 30, 2024, no foreign country accounted for 10% or more of the Company's net revenues. For the three months ended September 30, 2023, the Company generated 14% of its net revenues from the Netherlands. No other foreign country accounted for 10% or more of the Company's net revenues for the three months ended September 30, 2023.

- added (2024-10-31):
[0000950170-24-119570:note_history:36]
|  |  | Three Months Ended |
|  |  | September 30,2024 |  | September 30,2023 |
| TD Synnex Corporation |  | 22% |  | 18% |
| Jenne, Inc. |  | 21% |  | 27% |
| Westcon Group, Inc. |  | 15% |  | 25% |

- changed (2024-10-31):
[0000950170-24-119570:note_history:37]
|  |  | September 30,2024 |  | June 30,2024 |
| Jenne, Inc. |  | 53% |  | 64% |
| ScanSource, Inc. |  | 11% |  | 11% |
| Exclusive Networks |  | 10% |  | * |
| * Less than 10% of accounts receivable |  |  |  |  |
  (was, 2024-05-02, similarity 0.7556):
[0000950170-24-052140:note_history:37]
|  |  | March 31,2024 |  | June 30,2023 |
| Jenne, Inc. |  | 38% |  | 39% |
| TD Synnex Corporation |  | * |  | 10% |
| ScanSource, Inc. |  | * |  | 10% |
| * Less than 10% of accounts receivable |  |  |  |  |

- added (2024-10-31):
[0000950170-24-119570:note_history:38]
The majority of the Company's net accounts receivable balance with Jenne, Inc. as of September 30, 2024 is current and the Company expects to collect this balance by March 31, 2025.

- removed (2024-10-31):
[0000950170-24-052140:note_history:39]
On March 31, 2024, the Company had $558.3 million of remaining performance obligations, which primarily comprised deferred maintenance and deferred SaaS revenues. The Company expects to recognize approximately 18% of its deferred revenue as revenue in the remainder of fiscal 2024, an additional 42% in fiscal 2025, and 40% of the balance thereafter.

- removed (2024-10-31):
[0000950170-24-052140:note_history:40]
|  |  | Three Months Ended |  |
|  |  | March 31,2024 |  |  | March 31,2023 |  |
|  |  | Distributor |  | Direct |  | Total |  |  | Distributor |  | Direct |  | Total |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  | $ | 52,543 |  | $ | 71,539 |  | $ | 124,082 |  |  | $ | 74,743 |  | $ | 64,337 |  | $ | 139,080 |  |
| Other |  |  | 5,934 |  |  | 4,357 |  |  | 10,291 |  |  |  | 14,079 |  |  | 4,523 |  |  | 18,602 |  |
| Total Americas |  |  | 58,477 |  |  | 75,896 |  |  | 134,373 |  |  |  | 88,822 |  |  | 68,860 |  |  | 157,682 |  |
| EMEA |  |  | 18,313 |  |  | 40,722 |  |  | 59,035 |  |  |  | 111,664 |  |  | 40,326 |  |  | 151,990 |  |
| APAC* |  |  | (1,464 | ) |  | 19,092 |  |  | 17,628 |  |  |  | 5,186 |  |  | 17,649 |  |  | 22,835 |  |
| Total net revenues |  | $ | 75,326 |  | $ | 135,710 |  | $ | 211,036 |  |  | $ | 205,672 |  | $ | 126,835 |  | $ | 332,507 |  |

- removed (2024-10-31):
[0000950170-24-052140:note_history:41]
|  |  | Nine Months Ended |  |
|  |  | March 31,2024 |  |  | March 31,2023 |  |
|  |  | Distributor |  | Direct |  | Total |  |  | Distributor |  | Direct |  | Total |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  | $ | 251,694 |  | $ | 204,689 |  | $ | 456,383 |  |  | $ | 245,852 |  | $ | 203,991 |  | $ | 449,843 |  |
| Other |  |  | 16,709 |  |  | 19,565 |  |  | 36,274 |  |  |  | 14,080 |  |  | 4,523 |  |  | 18,603 |  |
| Total Americas |  |  | 268,403 |  |  | 224,254 |  |  | 492,657 |  |  |  | 259,932 |  |  | 208,514 |  |  | 468,446 |  |
| EMEA |  |  | 184,706 |  |  | 128,537 |  |  | 313,243 |  |  |  | 285,066 |  |  | 120,482 |  |  | 405,548 |  |
| APAC |  |  | 7,510 |  |  | 47,140 |  |  | 54,650 |  |  |  | 14,627 |  |  | 59,923 |  |  | 74,550 |  |
| Total net revenues |  | $ | 460,619 |  | $ | 399,931 |  | $ | 860,550 |  |  | $ | 559,625 |  | $ | 388,919 |  | $ | 948,544 |  |

- removed (2024-10-31):
[0000950170-24-052140:note_history:42]
*The distributor revenue in the APAC region for the three months ended March 31, 2024 reflects a higher level of customer rebates for the distributors, resulting from higher sell-through to end users than the Company's product sales into these distributors.

- removed (2024-10-31):
[0000950170-24-052140:note_history:43]
For the nine months ended March 31, 2024, the Company generated approximately 10% of its net revenues from the Netherlands. For the three and nine months ended March 31, 2023, the Company generated 17% and 12% of its net revenues from the Netherlands, respectively. No other foreign country accounted for 10% or more of its net revenues for the three and nine months ended March 31, 2024 and 2023.

- removed (2024-10-31):
[0000950170-24-052140:note_history:44]
|  |  | Three Months Ended |  | Nine Months Ended |
|  |  | March 31,2024 |  | March 31,2023 |  | March 31,2024 |  | March 31,2023 |
| TD Synnex Corporation |  | 22% |  | 19% |  | 21% |  | 19% |
| Westcon Group, Inc. |  | 13% |  | 25% |  | 17% |  | 20% |
| Jenne, Inc. |  | 12% |  | 15% |  | 22% |  | 14% |
| ScanSource, Inc. |  | 11% |  | * |  | * |  | * |
| * Less than 10% of revenue |  |  |  |  |  |  |  |  |


## us-gaap:RevenueRecognitionPolicyTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2024-10-31):
[0000950170-24-119570:note_history:45]
The Company’s performance obligations are satisfied at a point in time or over time as the customer receives and consumes the benefits provided. Substantially all of the Company’s product sales revenues are recognized at a point in time. Substantially all of the Company’s subscription and support revenues are recognized over time. For revenues recognized over time, the Company primarily uses an input measure, days elapsed, to measure progress.
  (was, 2024-05-02, similarity 0.9887):
[0000950170-24-052140:note_history:45]
The Company’s performance obligations are satisfied at a point in time or over time as the customer receives and consumes the benefits provided. Substantially all of the Company’s product sales revenues are recognized at a point in time. Substantially all of the Company’s subscription and support revenues are recognized over time. For revenues recognized over time, the Company uses an input measure, days elapsed, to measure progress.

- added (2024-10-31):
[0000950170-24-119570:note_history:46]
As of September 30, 2024, the Company had $576.9 million of remaining performance obligations, which primarily comprised deferred support and deferred SaaS subscription revenues. The Company expects to recognize approximately 43% of its deferred revenue as revenue in the remainder of fiscal 2025, an additional 28% in fiscal 2026, and the remaining 29% of the balance thereafter.

- changed (2024-10-31):
[0000950170-24-119570:note_history:47]
Revenue recognized for the three months ended September 30, 2024 and 2023 that was included in the deferred revenue balance at the beginning of each period was $100.3 million and $89.7 million, respectively.
  (was, 2024-05-02, similarity 0.6444):
[0000950170-24-052140:note_history:47]
Revenue recognized for the three months ended March 31, 2024 and 2023 that was included in the deferred revenue balance at the beginning of each period was $95.9 million and $81.0 million, respectively. Revenue recognized for the nine months ended March 31, 2024 and 2023 that was included in the deferred revenue balance at the beginning of each period was $230.8 million and $193.7 million, respectively.

- changed (2024-10-31):
[0000950170-24-119570:note_history:48]
Contract Costs. The Company recognizes the incremental costs of obtaining contracts as an expense when incurred if the amortization period of the assets that the Company otherwise would have recognized is one year or less. Management expects that commission fees paid to sales representatives as a result of obtaining subscription and support contracts and contract renewals are recoverable and therefore the Company’s condensed consolidated balance sheets included capitalized balances in the amount of $24.2 million and $24.7 million as of September 30, 2024 and June 30, 2024, respectively. Capitalized commissions are included within other assets in the condensed consolidated balance sheets. Capitalized commission fees are amortized on a straight-line basis over the average period of service contracts of approximately three years, and are included in “Sales and marketing” in the accompanying condensed consolidated statements of operations. Amortization recognized during the three months ended September 30, 2024 and 2023 was $3.0 million and $2.6 million, respectively.
  (was, 2024-05-02, similarity 0.9278):
[0000950170-24-052140:note_history:48]
Contract Costs. The Company recognizes the incremental costs of obtaining contracts as an expense when incurred if the amortization period of the assets that the Company otherwise would have recognized is one year or less. Management expects that commission fees paid to sales representatives as a result of obtaining subscription and support contracts and contract renewals are recoverable and therefore the Company’s condensed consolidated balance sheets included capitalized balances in the amount of $22.7 million and $20.0 million at March 31, 2024 and June 30, 2023, respectively. Capitalized commissions are included within other assets in the condensed consolidated balance sheets. Capitalized commission fees are amortized on a straight-line basis over the average period of service contracts of approximately three and a half years, and are included in “Sales and marketing” in the accompanying condensed consolidated statements of operations. Amortization recognized during the three months ended March 31, 2024 and 2023 was $2.8 million and $2.3 million, respectively. Amortization recognized during the nine months ended March 31, 2024 and 2023 was $8.0 million and $6.7 million, respectively.

- changed (2024-10-31):
[0000950170-24-119570:note_history:49]
The Company operates in three geographic regions: Americas, EMEA (Europe, Middle East and Africa) and APAC (Asia Pacific). The following table sets forth the Company’s net revenues disaggregated by geographic region (in thousands):
  (was, 2024-05-02, similarity 0.8106):
[0000950170-24-052140:note_history:49]
The Company operates in three geographic regions: Americas, EMEA (Europe, Middle East and Africa) and APAC (Asia Pacific). The following table sets forth the Company’s net revenues disaggregated by sales channel and geographic region based on the billing addresses of its customers (in thousands):

- added (2024-10-31):
[0000950170-24-119570:note_history:50]
|  | Three Months Ended |  |
|  |  | September 30,2024 |  |  | September 30,2023 |  |
| Americas: |  |  |  |  |  |  |
| United States |  | $ | 153,253 |  |  | $ | 182,752 |  |
| Other |  |  | 12,182 |  |  |  | 12,897 |  |
| Total Americas |  |  | 165,435 |  |  |  | 195,649 |  |
| EMEA |  |  | 84,918 |  |  |  | 143,603 |  |
| APAC |  |  | 18,851 |  |  |  | 13,885 |  |
| Total net revenues |  | $ | 269,204 |  |  | $ | 353,137 |  |

- added (2024-10-31):
[0000950170-24-119570:note_history:51]
For the three months ended September 30, 2024, no foreign country accounted for 10% or more of the Company's net revenues. For the three months ended September 30, 2023, the Company generated 14% of its net revenues from the Netherlands. No other foreign country accounted for 10% or more of the Company's net revenues for the three months ended September 30, 2023.

- removed (2024-10-31):
[0000950170-24-052140:note_history:52]
On March 31, 2024, the Company had $558.3 million of remaining performance obligations, which primarily comprised deferred maintenance and deferred SaaS revenues. The Company expects to recognize approximately 18% of its deferred revenue as revenue in the remainder of fiscal 2024, an additional 42% in fiscal 2025, and 40% of the balance thereafter.

- removed (2024-10-31):
[0000950170-24-052140:note_history:53]
|  |  | Three Months Ended |  |
|  |  | March 31,2024 |  |  | March 31,2023 |  |
|  |  | Distributor |  | Direct |  | Total |  |  | Distributor |  | Direct |  | Total |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  | $ | 52,543 |  | $ | 71,539 |  | $ | 124,082 |  |  | $ | 74,743 |  | $ | 64,337 |  | $ | 139,080 |  |
| Other |  |  | 5,934 |  |  | 4,357 |  |  | 10,291 |  |  |  | 14,079 |  |  | 4,523 |  |  | 18,602 |  |
| Total Americas |  |  | 58,477 |  |  | 75,896 |  |  | 134,373 |  |  |  | 88,822 |  |  | 68,860 |  |  | 157,682 |  |
| EMEA |  |  | 18,313 |  |  | 40,722 |  |  | 59,035 |  |  |  | 111,664 |  |  | 40,326 |  |  | 151,990 |  |
| APAC* |  |  | (1,464 | ) |  | 19,092 |  |  | 17,628 |  |  |  | 5,186 |  |  | 17,649 |  |  | 22,835 |  |
| Total net revenues |  | $ | 75,326 |  | $ | 135,710 |  | $ | 211,036 |  |  | $ | 205,672 |  | $ | 126,835 |  | $ | 332,507 |  |

- removed (2024-10-31):
[0000950170-24-052140:note_history:54]
|  |  | Nine Months Ended |  |
|  |  | March 31,2024 |  |  | March 31,2023 |  |
|  |  | Distributor |  | Direct |  | Total |  |  | Distributor |  | Direct |  | Total |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  | $ | 251,694 |  | $ | 204,689 |  | $ | 456,383 |  |  | $ | 245,852 |  | $ | 203,991 |  | $ | 449,843 |  |
| Other |  |  | 16,709 |  |  | 19,565 |  |  | 36,274 |  |  |  | 14,080 |  |  | 4,523 |  |  | 18,603 |  |
| Total Americas |  |  | 268,403 |  |  | 224,254 |  |  | 492,657 |  |  |  | 259,932 |  |  | 208,514 |  |  | 468,446 |  |
| EMEA |  |  | 184,706 |  |  | 128,537 |  |  | 313,243 |  |  |  | 285,066 |  |  | 120,482 |  |  | 405,548 |  |
| APAC |  |  | 7,510 |  |  | 47,140 |  |  | 54,650 |  |  |  | 14,627 |  |  | 59,923 |  |  | 74,550 |  |
| Total net revenues |  | $ | 460,619 |  | $ | 399,931 |  | $ | 860,550 |  |  | $ | 559,625 |  | $ | 388,919 |  | $ | 948,544 |  |

- removed (2024-10-31):
[0000950170-24-052140:note_history:55]
*The distributor revenue in the APAC region for the three months ended March 31, 2024 reflects a higher level of customer rebates for the distributors, resulting from higher sell-through to end users than the Company's product sales into these distributors.

- removed (2024-10-31):
[0000950170-24-052140:note_history:56]
For the nine months ended March 31, 2024, the Company generated approximately 10% of its net revenues from the Netherlands. For the three and nine months ended March 31, 2023, the Company generated 17% and 12% of its net revenues from the Netherlands, respectively. No other foreign country accounted for 10% or more of its net revenues for the three and nine months ended March 31, 2024 and 2023.
