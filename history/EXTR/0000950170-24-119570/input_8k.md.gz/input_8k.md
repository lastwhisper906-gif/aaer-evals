# EXTR 8-K — 0000950170-24-118589 filed 2024-10-30

## item codes, every 8-K on or before 2024-10-31

- 2024-10-30 0000950170-24-118589 — 2.02, 9.01
- 2024-08-07 0000950170-24-092273 — 2.02, 9.01
- 2024-05-01 0000950170-24-050891 — 2.02, 9.01
- 2024-01-31 0000950170-24-009144 — 2.02, 9.01
- 2024-01-08 0001193125-24-004497 — 5.02
- 2024-01-08 0000950170-24-002958 — 2.02, 9.01
- 2023-11-09 0000950170-23-062050 — 5.03, 5.07, 9.01
- 2023-11-01 0000950170-23-057125 — 2.02, 9.01
- 2023-08-02 0000950170-23-036775 — 2.02, 9.01
- 2023-06-23 0000950170-23-029645 — 1.01, 2.03, 9.01
- 2023-06-09 0000950170-23-027267 — 5.03, 9.01
- 2023-04-26 0000950170-23-014563 — 2.02, 9.01
- 2023-04-24 0001193125-23-113052 — 5.02, 9.01
- 2023-01-25 0001564590-23-000756 — 5.02, 9.01
- 2023-01-25 0001564590-23-000754 — 2.02, 9.01
- 2022-11-18 0001564590-22-038036 — 5.03, 5.07, 9.01
- 2022-10-27 0001564590-22-035354 — 2.02, 9.01
- 2022-10-12 0001193125-22-261213 — 8.01
- 2022-07-27 0001564590-22-026574 — 2.02, 9.01
- 2022-04-27 0001564590-22-015866 — 2.02, 9.01
- 2022-01-27 0001564590-22-002568 — 2.02, 9.01
- 2021-11-05 0001564590-21-054934 — 5.07
- 2021-11-02 0001564590-21-053306 — 2.02, 9.01
- 2021-09-22 0001564590-21-048585 — 4.01, 9.01
- 2021-08-10 0001564590-21-043098 — 1.01
- 2021-07-28 0001564590-21-038470 — 2.02, 9.01
- 2021-05-18 0001564590-21-028693 — 1.01, 3.03, 9.01
- 2021-04-28 0001564590-21-021102 — 2.02, 9.01
- 2021-02-09 0001564590-21-005000 — 2.02, 9.01
- 2021-01-27 0001564590-21-002633 — 2.02, 9.01
- 2020-11-06 0001564590-20-051993 — 5.07
- 2020-10-28 0001564590-20-048160 — 2.02, 9.01
- 2020-10-08 0001564590-20-046117 — 2.02, 9.01
- 2020-09-11 0001564590-20-043260 — 4.01, 9.01
- 2020-08-05 0001564590-20-036431 — 2.02, 9.01
- 2020-06-01 0001564590-20-027850 — 3.03, 9.01
- 2020-05-11 0001564590-20-024216 — 2.02, 9.01
- 2020-04-08 0001564590-20-015927 — 2.02, 8.01, 9.01
- 2020-02-25 0001193125-20-047202 — 8.01, 9.01
- 2020-01-29 0001564590-20-002375 — 2.02, 9.01
- 2020-01-29 0001193125-20-017673 — 5.02, 9.01
- 2019-11-08 0001193125-19-288358 — 5.07
- 2019-10-30 0001564590-19-038508 — 2.02, 9.01
- 2019-10-25 0001564590-19-037908 — 9.01 — amendment of 0001193125-19-217553
- 2019-10-18 0001193125-19-269734 — 7.01, 9.01
- 2019-08-30 0001193125-19-235271 — 5.02 — amendment of 0001193125-19-229280
- 2019-08-26 0001193125-19-229280 — 5.02, 9.01
- 2019-08-09 0001193125-19-217553 — 1.01, 2.01, 2.03, 9.01
- 2019-07-31 0001564590-19-027208 — 2.02, 9.01
- 2019-06-26 0001193125-19-181938 — 1.01, 2.05, 9.01
- 2019-05-01 0001564590-19-014567 — 2.02, 9.01
- 2019-01-29 0001564590-19-001270 — 2.02, 9.01
- 2019-01-25 0001564590-19-001157 — 8.01, 9.01
- 2018-11-20 0001193125-18-331450 — 5.02, 9.01
- 2018-11-15 0001564590-18-029683 — 5.07
- 2018-11-02 0001564590-18-026372 — 2.02, 8.01, 9.01
- 2018-09-19 0001193125-18-276766 — 5.02
- 2018-08-08 0001564590-18-020191 — 2.02, 9.01
- 2018-06-05 0001564590-18-015067 — 3.03, 9.01
- 2018-05-08 0001564590-18-011817 — 2.02, 9.01
- 2018-05-07 0001564590-18-011264 — 1.01, 1.02, 2.03, 9.01
- 2018-02-06 0001564590-18-001403 — 2.02, 2.05, 9.01
- 2018-02-01 0001564590-18-001166 — 5.02
- 2018-01-12 0001564590-18-000462 — 9.01 — amendment of 0001193125-17-323879
- 2017-11-15 0001564590-17-023847 — 5.07
- 2017-11-07 0001564590-17-022235 — 2.02, 9.01
- 2017-11-03 0001193125-17-332828 — 9.01 — amendment of 0001193125-17-323879
- 2017-10-30 0001193125-17-323879 — 1.01, 2.01, 7.01, 9.01
- 2017-10-03 0001193125-17-302411 — 1.01, 9.01
- 2017-10-03 0001193125-17-301597 — 1.01, 1.02, 7.01, 9.01
- 2017-09-29 0001564590-17-019099 — 9.01 — amendment, the index does not say of what
- 2017-08-14 0001564590-17-017659 — 2.02, 9.01
- 2017-08-02 0001564590-17-014950 — 5.02
- 2017-07-18 0001564590-17-013557 — 1.01, 2.01, 2.03, 9.01
- 2017-06-05 0001564590-17-012126 — 3.03, 9.01
- 2017-05-03 0001564590-17-008378 — 2.02, 9.01
- 2017-03-30 0001193125-17-102344 — 1.01, 9.01
- 2017-03-07 0001193125-17-073306 — 1.01, 9.01
- 2017-02-21 0001193125-17-048182 — 5.02
- 2017-02-01 0001564590-17-000835 — 2.02, 9.01
- 2017-01-06 0001564590-17-000138 — 2.05
- 2016-11-21 0001564590-16-029539 — 5.07
- 2016-11-01 0001564590-16-026732 — 2.02, 9.01
- 2016-10-31 0001193125-16-752557 — 1.01, 2.01, 2.03
- 2016-09-15 0001193125-16-711097 — 1.01, 9.01
- 2016-08-03 0001564590-16-022347 — 2.02, 9.01
- 2016-05-19 0001564590-16-019720 — 5.02, 9.01
- 2016-05-09 0001564590-16-018660 — 3.03, 9.01
- 2016-04-27 0001564590-16-016754 — 2.02, 9.01
- 2016-02-24 0001564590-16-013189 — 8.01
- 2016-02-09 0001564590-16-012469 — 8.01
- 2016-01-28 0001564590-16-012054 — 2.02, 9.01
- 2015-11-17 0001078271-15-000136 — 5.07
- 2015-10-29 0001078271-15-000125 — 2.02, 9.01
- 2015-08-31 0001078271-15-000111 — 8.01, 9.01
- 2015-08-11 0001078271-15-000096 — 5.02
- 2015-08-06 0001078271-15-000093 — 2.02, 9.01
- 2015-06-30 0001078271-15-000089 — 1.01, 9.01
- 2015-05-20 0001078271-15-000077 — 2.05, 9.01
- 2015-05-19 0001078271-15-000075 — 3.03, 9.01
- 2015-05-06 0001078271-15-000050 — 2.02, 9.01
- 2015-05-04 0001078271-15-000048 — 5.02, 9.01
- 2015-04-29 0001078271-15-000038 — 5.02, 9.01
- 2015-04-21 0001078271-15-000034 — 5.02, 9.01
- 2015-04-09 0001078271-15-000032 — 2.02, 5.02, 9.01
- 2015-02-18 0001078271-15-000021 — 8.01
- 2015-02-17 0001078271-15-000019 — 5.02
- 2015-01-28 0001078271-15-000004 — 2.02, 9.01
- 2014-12-18 0001078271-14-000081 — 5.02, 9.01
- 2014-12-17 0001078271-14-000079 — 5.02
- 2014-11-20 0001078271-14-000075 — 1.01, 9.01
- 2014-11-17 0001078271-14-000073 — 5.07
- 2014-10-28 0001078271-14-000062 — 2.02, 9.01
- 2014-10-15 0001078271-14-000060 — 2.02, 9.01
- 2014-10-02 0001078271-14-000057 — 5.02, 9.01
- 2014-08-14 0001078271-14-000047 — 2.02, 9.01
- 2014-07-21 0001078271-14-000042 — 2.02, 9.01
- 2014-05-23 0001078271-14-000036 — 5.02, 9.01
- 2014-05-20 0001078271-14-000034 — 3.03, 9.01
- 2014-05-12 0001078271-14-000030 — 5.02
- 2014-05-08 0001078271-14-000022 — 5.02, 9.01
- 2014-05-07 0001078271-14-000018 — 2.02, 9.01 — amendment, the index does not say of what
- 2014-05-06 0001078271-14-000016 — 2.02, 9.01
- 2014-02-20 0001078271-14-000014 — 5.02, 9.01
- 2014-02-18 0001078271-14-000010 — 5.02
- 2014-02-05 0001078271-14-000006 — 2.02, 9.01
- 2014-01-13 0001104659-14-002030 — 9.01 — amendment of 0001078271-13-000058
- 2013-11-25 0001078271-13-000081 — 5.07
- 2013-11-07 0001078271-13-000064 — 5.02, 9.01
- 2013-11-04 0001078271-13-000060 — 2.02, 9.01
- 2013-11-01 0001078271-13-000058 — 1.01, 2.01, 2.03, 8.01, 9.01
- 2013-10-16 0001078271-13-000056 — 8.01, 9.01
- 2013-09-13 0001078271-13-000052 — 1.01, 8.01, 9.01
- 2013-08-23 0001078271-13-000044 — 5.02, 9.01
- 2013-08-02 0001078271-13-000042 — 5.02
- 2013-07-30 0001078271-13-000039 — 2.02, 9.01
- 2013-07-30 0001078271-13-000037 — 5.02, 9.01
- 2013-06-21 0001078271-13-000032 — 8.01
- 2013-05-01 0001078271-13-000018 — 5.02, 9.01
- 2013-04-30 0001078271-13-000015 — 2.02, 9.01
- 2013-03-01 0001078271-13-000010 — 8.01
- 2013-02-19 0001078271-13-000008 — 5.02
- 2013-01-30 0001078271-13-000004 — 2.02, 9.01
- 2013-01-07 0001078271-13-000002 — 1.01, 2.02, 2.03, 2.05, 9.01
- 2012-12-03 0001078271-12-000094 — 5.02, 5.07, 8.01
- 2012-10-31 0001078271-12-000071 — 2.02, 9.01
- 2012-10-19 0001078271-12-000069 — 1.01, 2.03, 9.01
- 2012-10-16 0001078271-12-000067 — 8.01
- 2012-10-01 0001193125-12-411392 — 5.02, 8.01, 9.01
- 2012-09-24 0001193125-12-401798 — 5.02, 9.01
- 2012-09-21 0001193125-12-399896 — 5.02, 9.01
- 2012-09-18 0001193125-12-394379 — 1.01, 5.02, 9.01
- 2012-09-12 0001193125-12-388591 — 8.01
- 2012-08-27 0001078271-12-000057 — 8.01
- 2012-08-03 0001078271-12-000041 — 7.01, 9.01
- 2012-08-01 0001078271-12-000039 — 2.02, 9.01
- 2012-07-25 0001078271-12-000037 — 8.01
- 2012-05-22 0001078271-12-000033 — 5.02, 9.01
- 2012-05-21 0001078271-12-000030 — 8.01
- 2012-05-09 0001078271-12-000028 — 5.02, 9.01
- 2012-05-02 0001078271-12-000023 — 2.02, 9.01
- 2012-04-30 0001078271-12-000020 — 3.03, 5.07, 9.01
- 2012-04-19 0001078271-12-000012 — 2.02, 5.02, 9.01
- 2012-03-12 0001078271-12-000010 — 5.02, 9.01
- 2012-02-24 0001078271-12-000008 — 8.01
- 2012-02-02 0001078271-12-000004 — 2.02, 9.01
- 2012-01-30 0001078271-12-000002 — 1.01
- 2011-12-01 0001078271-11-000104 — 8.01
- 2011-11-08 0001078271-11-000099 — 8.01
- 2011-11-02 0001078271-11-000094 — 2.02, 9.01
- 2011-10-24 0001078271-11-000089 — 8.01, 9.01
- 2011-10-11 0001078271-11-000085 — 8.01
- 2011-09-29 0001078271-11-000082 — 8.01
- 2011-09-15 0001078271-11-000070 — 5.02, 9.01
- 2011-08-11 0001078271-11-000058 — 8.01
- 2011-08-10 0001078271-11-000055 — 5.02
- 2011-08-08 0001078271-11-000045 — 5.02
- 2011-08-01 0001078271-11-000038 — 2.02, 9.01
- 2011-07-14 0001078271-11-000036 — 2.02, 2.05, 9.01
- 2011-07-12 0001078271-11-000034 — 8.01
- 2011-07-01 0001078271-11-000032 — 5.02
- 2011-06-16 0001078271-11-000030 — 8.01
- 2011-05-06 0001078271-11-000027 — 8.01, 9.01
- 2011-05-04 0001078271-11-000025 — 8.01
- 2011-04-28 0001078271-11-000020 — 2.02, 9.01
- 2011-04-27 0001078271-11-000018 — 3.03, 5.02, 5.03, 9.01
- 2011-04-11 0001078271-11-000016 — 2.02
- 2011-03-31 0001078271-11-000014 — 5.02, 5.03
- 2011-03-15 0001193125-11-066049 — 5.02, 9.01
- 2011-03-01 0001193125-11-052048 — 5.02, 9.01
- 2011-02-10 0001078271-11-000012 — 7.01, 9.01
- 2011-01-31 0001078271-11-000005 — 2.02, 5.02, 5.03, 9.01
- 2010-12-23 0001193125-10-287613 — 8.01
- 2010-12-17 0001193125-10-283495 — 5.03, 5.07, 8.01, 9.01
- 2010-11-10 0001193125-10-255861 — 4.01, 9.01
- 2010-11-01 0001193125-10-242706 — 2.02, 9.01
- 2010-10-14 0001193125-10-229518 — 1.01, 9.01
- 2010-10-06 0001193125-10-224863 — 5.02, 8.01
- 2010-09-29 0001193125-10-219705 — 1.01, 8.01
- 2010-09-08 0001193125-10-206782 — 5.02, 8.01, 9.01
- 2010-08-25 0001193125-10-196951 — 8.01
- 2010-08-09 0001193125-10-182573 — 7.01, 8.01, 9.01
- 2010-08-03 0001193125-10-175255 — 5.02, 8.01, 9.01
- 2010-08-02 0001193125-10-173697 — 2.02, 8.01, 9.01
- 2010-07-30 0001193125-10-172214 — 5.02, 8.01, 9.01
- 2010-07-22 0001193125-10-163896 — 8.01, 9.01
- 2010-07-20 0001193125-10-161832 — 5.02
- 2010-07-12 0001193125-10-157291 — 2.02, 9.01
- 2010-07-01 0001193125-10-152746 — 3.03, 9.01
- 2010-05-10 0001193125-10-114669 — 5.02, 9.01
- 2010-04-26 0001193125-10-093310 — 2.02, 9.01
- 2010-03-19 0001193125-10-061679 — 5.02, 9.01
- 2010-02-16 0001193125-10-032335 — 5.02
- 2010-02-01 0001193125-10-018202 — 2.02, 9.01
- 2010-01-29 0001193125-10-017165 — 5.02
- 2010-01-11 0001193125-10-004099 — 8.01
- 2009-10-26 0001193125-09-213846 — 2.02, 9.01 — amendment of 0001193125-09-213780
- 2009-10-26 0001193125-09-213780 — 2.02, 9.01
- 2009-10-23 0001193125-09-212871 — 2.05, 5.02, 8.01, 9.01
- 2009-10-05 0001193125-09-203522 — 2.02, 9.01
- 2009-08-04 0001193125-09-163799 — 5.02, 9.01
- 2009-07-31 0001193125-09-160772 — 5.02, 9.01
- 2009-07-30 0001193125-09-159578 — 2.02, 9.01
- 2009-07-20 0001193125-09-151500 — 5.02, 9.01
- 2009-07-08 0001193125-09-145840 — 5.02, 9.01
- 2009-05-12 0001193125-09-108340 — 5.02, 9.01
- 2009-04-23 0001193125-09-085849 — 2.02, 9.01
- 2009-03-26 0001193125-09-064502 — 2.05
- 2009-01-28 0001193125-09-013182 — 2.02, 9.01
- 2008-11-06 0001193125-08-227572 — 2.02, 9.01
- 2008-11-03 0001193125-08-222501 — 5.02
- 2008-08-11 0001193125-08-173590 — 5.02
- 2008-08-11 0001193125-08-172587 — 8.01, 9.01
- 2008-08-06 0001193125-08-167934 — 2.02, 9.01
- 2008-08-04 0001193125-08-164673 — 5.02, 9.01
- 2008-05-21 0001193125-08-119640 — 7.01, 9.01
- 2008-04-29 0001193125-08-095270 — 2.02, 9.01
- 2008-03-05 0001193125-08-047893 — 8.01
- 2008-02-19 0001193125-08-033702 — 5.02
- 2008-02-05 0001193125-08-019969 — 5.02
- 2008-01-30 0001193125-08-015378 — 2.02, 9.01
- 2007-12-27 0001193125-07-272178 — 5.03, 9.01
- 2007-10-29 0001193125-07-228368 — 2.02, 9.01
- 2007-10-25 0001193125-07-225906 — 5.02, 9.01
- 2007-10-19 0001193125-07-221578 — 5.02
- 2007-09-26 0001193125-07-207348 — 8.01
- 2007-08-07 0001193125-07-172810 — 2.02, 9.01
- 2007-08-06 0001193125-07-172147 — 5.02, 9.01
- 2007-08-06 0001193125-07-172134 — 3.01
- 2007-07-09 0001193125-07-151467 — 3.01, 9.01
- 2007-06-28 0001193125-07-145519 — 2.02, 9.01
- 2007-06-27 0001193125-07-143262 — 2.05, 3.01, 5.02
- 2007-05-18 0001193125-07-118804 — 3.01, 9.01
- 2007-05-02 0001193125-07-099280 — 2.02, 9.01
- 2007-03-29 0001193125-07-068815 — 5.02, 9.01
- 2007-02-22 0001193125-07-037181 — 3.01, 9.01
- 2007-02-08 0001193125-07-024194 — 5.02
- 2007-01-30 0001193125-07-016428 — 2.02, 9.01
- 2007-01-11 0001193125-07-004825 — 4.02, 9.01
- 2006-11-21 0001193125-06-240068 — 5.02, 9.01
- 2006-11-16 0001193125-06-237262 — 3.01, 9.01
- 2006-11-01 0001193125-06-220707 — 2.02, 9.01
- 2006-10-31 0001193125-06-219237 — 1.01, 1.02, 5.02, 5.03, 8.01, 9.01
- 2006-09-28 0001193125-06-198185 — 3.01, 9.01
- 2006-09-15 0001193125-06-191640 — 7.01, 9.01
- 2006-09-05 0001193125-06-185202 — 5.02, 9.01
- 2006-08-08 0001193125-06-165953 — 1.01, 2.02, 5.02, 9.01
- 2006-07-18 0001193125-06-148526 — 1.01
- 2006-07-10 0001193125-06-143989 — 5.02, 9.01
- 2006-05-16 0001193125-06-113698 — 5.02, 9.01
- 2006-05-01 0001193125-06-094919 — 2.02, 9.01
- 2006-04-26 0001193125-06-089397 — 1.01, 9.01
- 2006-04-07 0001193125-06-075723 — 2.02, 9.01
- 2006-02-13 0001193125-06-029073 — 1.01
- 2006-01-31 0001193125-06-016143 — 1.01
- 2006-01-30 0001193125-06-015165 — 2.02, 9.01
- 2005-12-08 0001193125-05-239157 — 1.01, 1.02, 9.01
- 2005-11-01 0001193125-05-213101 — 2.02, 9.01
- 2005-09-29 0001193125-05-193991 — 1.01, 2.02, 9.01 — amendment of 0001193125-05-162807
- 2005-08-09 0001193125-05-162807 — 1.01, 2.02, 9.01
- 2005-07-14 0001193125-05-142162 — 8.01
- 2005-06-28 0001193125-05-133050 — 1.01, 9.01
- 2005-04-18 0001193125-05-077946 — 2.02, 7.01, 9.01
- 2005-04-14 0001193125-05-076665 — 2.02, 7.01, 9.01
- 2005-01-25 0001193125-05-011466 — 2.02, 9.01
- 2004-12-07 0001193125-04-208693 — 3.01
- 2004-10-26 0001193125-04-178370 — 2.02, 9.01
- 2004-10-04 0001193125-04-166289 — 5.02, 9.01
- 2004-07-28 0001193125-04-126135 — 12, 7
- 2004-05-12 0001193125-04-086287 — 12
- 2004-04-21 0001193125-04-066557 — 12, 7
- 2004-01-22 0001193125-04-007359 — 12, 7
- 2003-12-18 0001193125-03-096351 — 5, 7
- 2003-11-04 0001193125-03-072069 — 5, 7
- 2003-10-24 0001193125-03-066551 — 12, 7
- 2003-07-25 0001193125-03-024087 — 7, 9
- 2003-04-11 0001012870-03-001706 — 7, 9
- 2003-04-08 0001021408-03-005743 — 7, 9
- 2003-01-07 0001012870-03-000039 — 5, 7
- 2002-04-29 0001012870-02-002003 — 5, 7
- 2002-02-20 0001012870-02-000792 — 5, 7
- 2001-12-13 0001012870-01-503160 — 5, 7
- 2001-11-30 0001012870-01-503010 — 5, 7
- 2001-11-02 0001012870-01-502580 — 5
- 2001-10-23 0001021408-01-508589 — 5, 7
- 2001-06-07 0001021408-01-501772 — 5, 7 — amendment of 0001021408-01-500975
- 2001-05-15 0001021408-01-501104 — 5 — amendment of 0001021408-01-500975
- 2001-05-14 0001021408-01-500975 — 5, 7
- 2001-04-06 0001012870-01-500065 — 5, 7

## late-filing notifications on or before 2024-10-31

- 2008-05-12 0001193125-08-111540 — NT 10-Q, for the period ended 2008-03-30
- 2007-05-10 0001193125-07-110075 — NT 10-Q, for the period ended 2007-04-01
- 2007-02-09 0001193125-07-025490 — NT 10-Q, for the period ended 2006-12-31
- 2006-11-13 0001193125-06-232090 — NT 10-Q, for the period ended 2006-10-01
- 2006-09-15 0001193125-06-191838 — NT 10-K, for the period ended 2006-07-02

## item 2.02 — earnings release, exhibit 99.1

[0000950170-24-118589:8k_2_02:1]
EX-99.1
2
extr-ex99_1.htm
EX-99.1

[0000950170-24-118589:8k_2_02:2]
EX-99.1

[0000950170-24-118589:8k_2_02:3]
Exhibit 99.1

[0000950170-24-118589:8k_2_02:4]
| For more information, contact: |  |  |  |  |  |  |
| Investor Relations |  |  |  | Media Contact |  |
| Stan Kovler |  |  |  | Amy Aylward |
| 919/595-4196 |  |  |  | 603/952-5138 |  |
| Investor_relations@extremenetworks.com |  |  |  | pr@extremenetworks.com |

[0000950170-24-118589:8k_2_02:5]
Extreme Networks Reports First Quarter Fiscal Year 2025 Financial Results

[0000950170-24-118589:8k_2_02:6]
Beats Revenue and EPS Guidance

[0000950170-24-118589:8k_2_02:7]
Sequential Revenue Growth Drives Margin Improvement and Cash Flow

[0000950170-24-118589:8k_2_02:8]
Morrisville, NC, October 30, 2024 -- Extreme Networks, Inc. (“Extreme”) (Nasdaq: EXTR) today released financial results for its first quarter ended September 30, 2024.

[0000950170-24-118589:8k_2_02:9]
"Our first quarter results highlight the early stages of market recovery and upside from projects that closed earlier than anticipated. Extreme's differentiated enterprise networking solutions continue to resonate with customers and drive competitive wins. The strength of our cloud management platform, enhanced with our advanced AI tools, is evidenced by growth in SaaS ARR, which is up 23 percent year over year. The combination of our cloud, with our truly unique enterprise campus fabric, provides unmatched network performance, resiliency, security benefits, and operating efficiencies. This is why Extreme wins in highly competitive situations," said Ed Meyercord, President and Chief Executive Officer.

[0000950170-24-118589:8k_2_02:10]
"We expect continued sequential growth in the second quarter and revenue growth for the full year, based on the size and quality of our funnel of opportunities. We anticipate further market share gains as a result of our technology differentiation and changes in the competitive environment." concluded Meyercord.

[0000950170-24-118589:8k_2_02:11]
Kevin Rhodes, Executive Vice President and Chief Financial Officer stated, "The revenue upside in the first quarter, coupled with sequential improvement in gross margin, demonstrated the operating leverage in our model. We expect continued improving operating margins and cash flow generation during this fiscal year based on the ongoing recovery in revenue and prudent management of our expenses."

[0000950170-24-118589:8k_2_02:12]
Fiscal First Quarter Results:

[0000950170-24-118589:8k_2_02:13]
•
Revenue $269.2 million, down 23.8% year-over-year, and up 4.9% quarter-over-quarter

[0000950170-24-118589:8k_2_02:14]
•
SaaS ARR $174.1 million, up 23.4% year-over-year, and up 4.3% quarter-over-quarter

[0000950170-24-118589:8k_2_02:15]
•
GAAP Loss per share $0.08, compared to GAAP diluted EPS $0.21 last year and GAAP Loss per share $0.42 last quarter

[0000950170-24-118589:8k_2_02:16]
•
Non-GAAP diluted EPS $0.17, compared to $0.35 last year and non-GAAP Loss per share $0.08 last quarter

[0000950170-24-118589:8k_2_02:17]
•
GAAP gross margin 63.0% compared to 60.3% last year and 44.7% last quarter

[0000950170-24-118589:8k_2_02:18]
•
Non-GAAP gross margin 63.7% compared to 61.1% last year and 45.4% last quarter

[0000950170-24-118589:8k_2_02:19]
•
GAAP operating loss margin 1.8% compared to GAAP operating profit margin 10.2% last year and GAAP operating loss margin 19.1% last quarter

[0000950170-24-118589:8k_2_02:20]
•
Non-GAAP operating profit margin 12.4% compared to 17.7% last year and Non-GAAP operating loss margin 4.6% last quarter

[0000950170-24-118589:8k_2_02:21]
Liquidity:

[0000950170-24-118589:8k_2_02:22]
•
Q1 ending cash balance was $159.5 million, an increase of $2.8 million from the end of Q4 2024 and a decrease of $64.9 million from the end of Q1 in the prior year.

[0000950170-24-118589:8k_2_02:23]
•
Q1 net debt was $28.0 million, a decrease of $5.3 million from net debt of $33.3 million at the end of Q4 2024 and a decrease of $54.9 million from net cash of $26.9 million at the end of Q1 in the prior year.

[0000950170-24-118589:8k_2_02:24]
•
During Q1, we generated net cash flow from operations of $18.6 million and had free cash flow of $11.7 million.

[0000950170-24-118589:8k_2_02:25]
Recent Key Highlights:

[0000950170-24-118589:8k_2_02:26]
•
Earlier this week, Extreme announced new features in ExtremeCloud™ Universal ZTNA, our combined identity-based application and network access solution. Universal ZTNA combines the best of remote and on-site network access security by unifying cloud network access control and zero trust network access in a single, easy-to-use SaaS offering. The solution boosts productivity for IT teams, reduces time spent troubleshooting and helps organizations easily identify and secure network and application access based on identity-level privileges – eliminating the need for additional user security platforms.

[0000950170-24-118589:8k_2_02:27]
•
Texas Tech University upgraded its data center and edge network with Extreme’s Universal hardware, ExtremeCloud IQ, and Fabric, benefitting from simplified management and enhanced security to meet growing demands for online resources, testing, and classroom technology.

[0000950170-24-118589:8k_2_02:28]
•
Several NFL Clubs, including the Green Bay Packers, Houston Texans and Minnesota Vikings, selected Extreme to improve fan experiences, streamline operations and leverage analytics to improve game-day experiences. These clubs have deployed 6 GHz Wi-Fi to create a backbone of high-speed connectivity to power services such as mobile ticketing, concessions, sports betting and biometrics.

[0000950170-24-118589:8k_2_02:29]
•
The National Institutes for Quantum Science and Technology (QST) and the Photon Science Innovation Center (PhoSIC) leveraged Extreme’s Universal switches and Fabric to build a network for a large-scale research facility in Japan. Fabric enables the various organizations and companies using the facility to easily access data and resources, while improving security through network segmentation.

[0000950170-24-118589:8k_2_02:30]
•
ASDA Stores, a large supermarket and petrol retailer in the United Kingdom, known for its strong online presence, ongoing store upgrades, community focus, and innovative shopping experiences, has selected Extreme to transform its retail operations. ASDA Stores is deploying Extreme Wireless and ExtremeCloud IQ solutions across 29 distribution centers to support improved wireless connectivity for employees and simplified network management for its IT team, improving operational efficiencies and automating manual tasks to improve customer experiences. These initiatives are part of ASDA's plans to improve its stores and services following its expansion to over 1,000 locations in the UK and Northern Ireland.

[0000950170-24-118589:8k_2_02:31]
Fiscal Q1 2025 Financial Metrics:

[0000950170-24-118589:8k_2_02:32]
(in millions, except percentages and per share information)

[0000950170-24-118589:8k_2_02:33]
|  |  | GAAP Results |  |
|  |  | Three Months Ended |  |
|  |  | September 30,2024 |  |  | September 30,2023 |  |  | Change |  |
| Product |  | $ | 162.3 |  |  | $ | 253.5 |  |  | $ | (91.2 | ) |
| Subscription and support |  |  | 106.9 |  |  |  | 99.6 |  |  |  | 7.3 |  |
| Total net revenue |  | $ | 269.2 |  |  | $ | 353.1 |  |  | $ | (83.9 | ) |
| Gross margin |  |  | 63.0 | % |  |  | 60.3 | % |  |  | 2.7 | % |
| Operating margin |  |  | (1.8 | )% |  |  | 10.2 | % |  |  | (11.9 | )% |
| Net income (loss) |  | $ | (10.5 | ) |  | $ | 28.7 |  |  | $ | (39.2 | ) |
| Net income (loss) per diluted share |  | $ | (0.08 | ) |  | $ | 0.21 |  |  | $ | (0.29 | ) |

[0000950170-24-118589:8k_2_02:34]
|  |  | Non-GAAP Results |  |
|  |  | Three Months Ended |  |
|  |  | September 30,2024 |  |  | September 30,2023 |  |  | Change |  |
| Product |  | $ | 162.3 |  |  | $ | 253.5 |  |  | $ | (91.2 | ) |
| Subscription and support |  |  | 106.9 |  |  |  | 99.6 |  |  |  | 7.3 |  |
| Total net revenue |  | $ | 269.2 |  |  | $ | 353.1 |  |  | $ | (83.9 | ) |
| Gross margin |  |  | 63.7 | % |  |  | 61.1 | % |  |  | 2.6 | % |
| Operating margin |  |  | 12.4 | % |  |  | 17.7 | % |  |  | (5.3 | )% |
| Net income (loss) |  | $ | 22.4 |  |  | $ | 46.5 |  |  | $ | (24.1 | ) |
| Net income (loss) per diluted share |  | $ | 0.17 |  |  | $ | 0.35 |  |  | $ | (0.18 | ) |

[0000950170-24-118589:8k_2_02:35]
Extreme uses the non-GAAP free cash flow metric as a measure of operating performance. Free cash flow represents GAAP net cash provided by (used in) operating activities, less purchases of property, plant and equipment.  Extreme considers free cash flow to be useful information for management and investors regarding the amount of cash generated by the business after the purchases of property, plant and equipment, which can then be used to, among other things, invest in Extreme’s business, make strategic acquisitions, and strengthen the balance sheet. A limitation of the utility of this non-GAAP free cash flow metric as a measure of financial performance is that it does not represent the total increase or decrease in the Company's cash balance for the period. The following table shows non-GAAP free cash flow calculation (in millions):

[0000950170-24-118589:8k_2_02:36]
| Free Cash Flow | Three Months Ended |  |
|  | September 30,2024 |  |  | September 30,2023 |  |
| Cash flow provided by operations | $ | 18.6 |  |  | $ | 75.6 |  |
| Less: Property and equipment capital expenditures |  | (6.9 | ) |  |  | (4.3 | ) |
| Total free cash flow | $ | 11.7 |  |  | $ | 71.3 |  |

[0000950170-24-118589:8k_2_02:37]
SaaS ARR: Extreme uses SaaS annual recurring revenue (“SaaS ARR”) to identify the annual recurring revenue of ExtremeCloud IQ and other subscription revenue, based on the annualized value of quarterly subscription revenue and term-based licenses. We believe that SaaS ARR is an important metric because it is driven by our ability to acquire new customers and to maintain and expand our relationships with existing customers. SaaS ARR should be viewed independently of revenue or deferred revenue that are accounted for under U.S. GAAP. SaaS ARR does not have a standardized meaning and therefore may not be comparable to similarly titled measures presented by other companies. SaaS ARR is not intended to be a replacement for forecasts of revenue.

[0000950170-24-118589:8k_2_02:38]
Gross Debt: Gross debt is defined as long-term debt and the current portion of long-term debt as shown on the balance sheet plus unamortized debt issuance costs, if any.

[0000950170-24-118589:8k_2_02:39]
Net Cash (Debt) is defined as cash and cash equivalents minus gross debt, as shown in the table below (in millions):

[0000950170-24-118589:8k_2_02:40]
| Cash and cash equivalents |  |  | Gross debt |  |  | Net cash (debt) |  |
| $ | 159.5 |  |  | $ | 187.5 |  |  | $ | (28.0 | ) |

[0000950170-24-118589:8k_2_02:41]
Business Outlook:

[0000950170-24-118589:8k_2_02:42]
For its second quarter of fiscal 2025, ending December 31, 2024, the Company is targeting:

[0000950170-24-118589:8k_2_02:43]
| (in millions, except percentages and per share information) | Low-End |  |  | High-End |  |
| FQ2'25 Guidance – GAAP |  |  |  |  |  |
| Total net revenue | $ | 273.0 |  |  | $ | 283.0 |  |
| Gross margin |  | 62.2 | % |  |  | 63.2 | % |
| Operating margin |  | (1.1 | )% |  |  | 1.4 | % |
| Earnings (Loss) per share | $ | (0.07 | ) |  | $ | (0.01 | ) |
| Shares outstanding used in calculating GAAP EPS |  | 132.3 |  |  |  | 132.3 |  |
| FQ2'25 Guidance – Non-GAAP |  |  |  |  |  |
| Total net revenue | $ | 273.0 |  |  | $ | 283.0 |  |
| Gross margin |  | 63.0 | % |  |  | 64.0 | % |
| Operating margin |  | 11.3 | % |  |  | 13.4 | % |
| Earnings per share | $ | 0.16 |  |  | $ | 0.20 |  |
| Diluted Shares outstanding used in calculating non-GAAP EPS |  | 133.1 |  |  |  | 133.1 |  |

[0000950170-24-118589:8k_2_02:44]
The following table shows the GAAP to non-GAAP reconciliation for Q2 FY'25 guidance:

[0000950170-24-118589:8k_2_02:45]
|  | FQ2'25 |  |
|  | Gross Margin |  | Operating Margin |  | Earnings (Loss) per Share |  |
| GAAP | 62.2% - 63.2% |  | (1.1%) - 1.4% |  | ($0.07) - ($0.01) |  |
| Estimated adjustments for: |  |  |  |  |  |  |
| Share-based compensation | 0.6% |  | 7.9% - 8.3% |  | 0.17 |  |
| Amortization of product intangibles | 0.2% |  | 0.2% |  | 0.01 |  |
| Amortization of non-product intangibles | — |  | 0.2% |  | — |  |
| Restructuring and related charges | — |  | 0.2% |  | 0.01 |  |
| Litigation charges | — |  | 1.1% |  | 0.02 |  |
| System transition cost | — |  | 2.4% |  | 0.05 |  |
| Tax adjustment | — |  | — |  | (0.05) - (0.03) |  |
| Non-GAAP | 63.0% - 64.0% |  | 11.3% - 13.4% |  | $0.16-$0.20 |  |

[0000950170-24-118589:8k_2_02:46]
The total of percentage rate changes may not equal the total change in all cases due to rounding.

[0000950170-24-118589:8k_2_02:47]
For the full year fiscal 2025, ending June 30, 2025, the Company is targeting (in millions):

[0000950170-24-118589:8k_2_02:48]
|  | Low-End |  |  | High-End |  |
| FY'25 Guidance |  |  |  |  |  |
| Total net revenue | $ | 1,117.0 |  |  | $ | 1,137.0 |  |

[0000950170-24-118589:8k_2_02:49]
Conference Call:

[0000950170-24-118589:8k_2_02:50]
Extreme will host a conference call at 8:00 a.m. Eastern (5:00 a.m. Pacific) today to review the first quarter results of fiscal 2025 as well as the business outlook for the second quarter of fiscal 2025 ending December 31, 2024, including significant factors and assumptions underlying the targets noted above. The conference call will be available to the public through a live audio web broadcast via the internet at http://investor.extremenetworks.com and a replay of the call will be available on the website for at least 7 days following the call. To access the call, please go to this link (Extreme Networks Q1'25 Earnings Registration and you will be provided with dial in details. If you would like to participate in the Q&A, please register here:  Registration Link [Q&A]. To avoid delays, we encourage participants to dial into the conference call fifteen minutes ahead of the scheduled start time.

[0000950170-24-118589:8k_2_02:51]
About Extreme:

[0000950170-24-118589:8k_2_02:52]
Extreme Networks, Inc. (EXTR) creates networking experiences that enable all of us to advance. We push the boundaries of technology leveraging the powers of machine learning, artificial intelligence, analytics, and automation. Tens of thousands customers globally trust our end-to-end, cloud-driven networking solutions and rely on our top-rated services and support to accelerate their digital transformation efforts and deliver progress like never before. For more information, visit Extreme's website at https://www.extremenetworks.com/ or LinkedIn, YouTube, Twitter, Facebook or Instagram

[0000950170-24-118589:8k_2_02:53]
Extreme Networks, ExtremeCloud, and the Extreme Networks logo, are trademarks of Extreme Networks, Inc. or its subsidiaries in the United States and/or other countries. Other trademarks shown herein are the property of their respective owners.

[0000950170-24-118589:8k_2_02:54]
Non-GAAP Financial Measures:

[0000950170-24-118589:8k_2_02:55]
Extreme provides all financial information required in accordance with U.S. generally accepted accounting principles (“GAAP”). The Company is providing with this press release non-GAAP gross profit, non-GAAP gross margin, non-GAAP operating margin, non-GAAP operating income (loss), non-GAAP net income (loss), non-GAAP net income (loss) per diluted share, net cash (debt) and non-GAAP free cash flow. In preparing non-GAAP information, the Company has excluded, where applicable, the impact of share-based compensation, amortization of intangibles, restructuring charges, system transition costs, litigation charges, debt refinancing charges and the tax effect of non-GAAP adjustments.  The Company believes that excluding these items provides both management and investors with additional insight into its current operations, the trends affecting the Company, the Company's marketplace performance, and the Company's ability to generate cash from operations. Please note the Company’s non-GAAP measures may be different than those used by other companies. The additional non-GAAP financial information the Company presents should be considered in conjunction with, and not as a substitute for, the Company’s GAAP financial information.

[0000950170-24-118589:8k_2_02:56]
The Company has provided a non-GAAP reconciliation of the results for the periods presented in this release, which are adjusted to exclude certain items as indicated.  These measures should only be used to evaluate the Company's results of operations in conjunction with the corresponding GAAP measures for comparable financial information and understanding of the Company’s ongoing performance as a business. Extreme uses both GAAP and non-GAAP measures to evaluate and manage its operations.

[0000950170-24-118589:8k_2_02:57]
Forward-Looking Statements:

[0000950170-24-118589:8k_2_02:58]
For more information about factors that could cause actual results and other future events to differ materially from those suggested or indicated by such forward-looking statements, see “Management's Discussion and Analysis of Financial Condition and Results of Operations” and “Risk Factors” included in the Company’s Annual Report on Form 10-K for the year ended June 30, 2024, and other documents of the Company on file with the Securities and Exchange Commission (available at www.sec.gov).  As a result of these risks and others, actual results could vary significantly from those anticipated in this press release, and the Company’s financial condition and results of operations could be materially adversely affected. Except as required under the U.S. federal securities laws and the rules and regulations of the Securities and Exchange Commission, Extreme disclaims any obligation to update any forward-looking statements after the date of this release, whether as a result of new information, future events, developments, changes in assumptions or otherwise.

[0000950170-24-118589:8k_2_02:59]
###

[0000950170-24-118589:8k_2_02:60]
EXTREME NETWORKS, INC.

[0000950170-24-118589:8k_2_02:61]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0000950170-24-118589:8k_2_02:62]
(In thousands, except per share amounts)

[0000950170-24-118589:8k_2_02:63]
(Unaudited)

[0000950170-24-118589:8k_2_02:64]
|  |  | September 30,2024 |  |  | June 30,2024 |  |
| ASSETS |  |  |  |  |  |  |
| Current assets: |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 159,546 |  |  | $ | 156,699 |  |
| Accounts receivable, net |  |  | 97,213 |  |  |  | 89,518 |  |
| Inventories |  |  | 143,555 |  |  |  | 141,032 |  |
| Prepaid expenses and other current assets |  |  | 76,453 |  |  |  | 79,677 |  |
| Total current assets |  |  | 476,767 |  |  |  | 466,926 |  |
| Property and equipment, net |  |  | 34,393 |  |  |  | 43,744 |  |
| Operating lease right-of-use assets, net |  |  | 43,561 |  |  |  | 44,145 |  |
| Goodwill |  |  | 396,345 |  |  |  | 393,709 |  |
| Intangible assets, net |  |  | 9,762 |  |  |  | 10,613 |  |
| Other assets |  |  | 95,695 |  |  |  | 83,457 |  |
| Total assets |  | $ | 1,056,523 |  |  | $ | 1,042,594 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |  |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |  |
| Accounts payable |  | $ | 65,769 |  |  | $ | 51,423 |  |
| Accrued compensation and benefits |  |  | 45,533 |  |  |  | 42,064 |  |
| Accrued warranty |  |  | 10,239 |  |  |  | 10,942 |  |
| Current portion of deferred revenue |  |  | 304,785 |  |  |  | 306,114 |  |
| Current portion of long-term debt, net of unamortized debt issuance costs of $761 and $674, respectively |  |  | 10,489 |  |  |  | 9,326 |  |
| Current portion, operating lease liabilities |  |  | 11,045 |  |  |  | 10,547 |  |
| Other accrued liabilities |  |  | 78,549 |  |  |  | 87,172 |  |
| Total current liabilities |  |  | 526,409 |  |  |  | 517,588 |  |
| Deferred revenue, less current portion |  |  | 272,092 |  |  |  | 268,909 |  |
| Long-term debt, less current portion, net of unamortized debt issuance costs of $1,819 and $1,735, respectively |  |  | 174,431 |  |  |  | 178,265 |  |
| Operating lease liabilities, less current portion |  |  | 40,137 |  |  |  | 41,466 |  |
| Deferred income taxes |  |  | 8,073 |  |  |  | 7,978 |  |
| Other long-term liabilities |  |  | 2,660 |  |  |  | 3,106 |  |
| Commitments and contingencies |  |  |  |  |  |  |
| Stockholders’ equity: |  |  |  |  |  |  |
| Convertible preferred stock, $0.001 par value, issuable in series, 2,000 shares authorized; none issued |  |  | — |  |  |  | — |  |
| Common stock, $0.001 par value, 750,000 shares authorized; 150,265 and 148,503 shares issued, respectively; 132,046 and 130,284 shares outstanding, respectively |  |  | 150 |  |  |  | 149 |  |
| Additional paid-in-capital |  |  | 1,234,220 |  |  |  | 1,220,379 |  |
| Accumulated other comprehensive loss |  |  | (11,382 | ) |  |  | (15,483 | ) |
| Accumulated deficit |  |  | (952,466 | ) |  |  | (941,962 | ) |
| Treasury stock at cost, 18,219 and 18,219 shares, respectively |  |  | (237,801 | ) |  |  | (237,801 | ) |
| Total stockholders’ equity |  |  | 32,721 |  |  |  | 25,282 |  |
| Total liabilities and stockholders’ equity |  | $ | 1,056,523 |  |  | $ | 1,042,594 |  |

[0000950170-24-118589:8k_2_02:65]
EXTREME NETWORKS, INC.

[0000950170-24-118589:8k_2_02:66]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS

[0000950170-24-118589:8k_2_02:67]
(In thousands, except per share amounts)

[0000950170-24-118589:8k_2_02:68]
(Unaudited)

[0000950170-24-118589:8k_2_02:69]
|  |  | Three Months Ended |  |
|  |  | September 30,2024 |  |  | September 30,2023 |  |
| Net revenues: |  |  |  |  |  |  |
| Product |  | $ | 162,284 |  |  | $ | 253,483 |  |
| Subscription and support |  |  | 106,920 |  |  |  | 99,654 |  |
| Total net revenues |  |  | 269,204 |  |  |  | 353,137 |  |
| Cost of revenues: |  |  |  |  |  |  |
| Product |  |  | 69,402 |  |  |  | 108,536 |  |
| Subscription and support |  |  | 30,295 |  |  |  | 31,665 |  |
| Total cost of revenues |  |  | 99,697 |  |  |  | 140,201 |  |
| Gross profit: |  |  |  |  |  |  |
| Product |  |  | 92,882 |  |  |  | 144,947 |  |
| Subscription and support |  |  | 76,625 |  |  |  | 67,989 |  |
| Total gross profit |  |  | 169,507 |  |  |  | 212,936 |  |
| Operating expenses: |  |  |  |  |  |  |
| Research and development |  |  | 54,451 |  |  |  | 58,016 |  |
| Sales and marketing |  |  | 81,383 |  |  |  | 91,920 |  |
| General and administrative |  |  | 36,601 |  |  |  | 23,873 |  |
| Restructuring and related charges |  |  | 1,277 |  |  |  | 2,717 |  |
| Amortization of intangible assets |  |  | 512 |  |  |  | 511 |  |
| Total operating expenses |  |  | 174,224 |  |  |  | 177,037 |  |
| Operating income (loss) |  |  | (4,717 | ) |  |  | 35,899 |  |
| Interest income |  |  | 846 |  |  |  | 1,226 |  |
| Interest expense |  |  | (4,422 | ) |  |  | (4,318 | ) |
| Other income (expense), net |  |  | (721 | ) |  |  | 432 |  |
| Income (loss) before income taxes |  |  | (9,014 | ) |  |  | 33,239 |  |
| Provision for income taxes |  |  | 1,490 |  |  |  | 4,563 |  |
| Net income (loss) |  | $ | (10,504 | ) |  | $ | 28,676 |  |
| Basic and diluted income (loss) per share: |  |  |  |  |  |  |
| Net income (loss) per share – basic |  | $ | (0.08 | ) |  | $ | 0.22 |  |
| Net income (loss) per share – diluted |  | $ | (0.08 | ) |  | $ | 0.21 |  |
| Shares used in per share calculation – basic |  |  | 131,176 |  |  |  | 128,782 |  |
| Shares used in per share calculation – diluted |  |  | 131,176 |  |  |  | 133,463 |  |

[0000950170-24-118589:8k_2_02:70]
EXTREME NETWORKS, INC.

[0000950170-24-118589:8k_2_02:71]
CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS

[0000950170-24-118589:8k_2_02:72]
(In thousands)

[0000950170-24-118589:8k_2_02:73]
(Unaudited)

[0000950170-24-118589:8k_2_02:74]
|  |  | Three Months Ended |  |
|  |  | September 30,2024 |  |  | September 30,2023 |  |
| Cash flows from operating activities: |  |  |  |  |  |  |
| Net income (loss) |  | $ | (10,504 | ) |  | $ | 28,676 |  |
| Adjustments to reconcile net income (loss) to net cash provided by operating activities: |  |  |  |  |  |  |
| Depreciation |  |  | 3,941 |  |  |  | 4,865 |  |
| Amortization of intangible assets |  |  | 1,136 |  |  |  | 1,944 |  |
| Reduction in carrying amount of right-of-use asset |  |  | 2,449 |  |  |  | 2,931 |  |
| Provision for credit losses |  |  | 14 |  |  |  | 75 |  |
| Share-based compensation |  |  | 19,767 |  |  |  | 19,919 |  |
| Deferred income taxes |  |  | 39 |  |  |  | (65 | ) |
| Provision for excess and obsolete inventory(1) |  |  | (624 | ) |  |  | 13,485 |  |
| Non-cash interest expense |  |  | 282 |  |  |  | 266 |  |
| Other |  |  | 746 |  |  |  | (144 | ) |
| Changes in operating assets and liabilities: |  |  |  |  |  |  |
| Accounts receivable, net |  |  | (7,709 | ) |  |  | 50,459 |  |
| Inventories(1) |  |  | (8,669 | ) |  |  | (25,431 | ) |
| Prepaid expenses and other assets |  |  | 3,096 |  |  |  | (6,841 | ) |
| Accounts payable |  |  | 14,492 |  |  |  | (20,097 | ) |
| Accrued compensation and benefits |  |  | 2,844 |  |  |  | (19,488 | ) |
| Operating lease liabilities |  |  | (2,757 | ) |  |  | (3,297 | ) |
| Deferred revenue |  |  | 3,823 |  |  |  | 21,978 |  |
| Other current and long-term liabilities |  |  | (3,781 | ) |  |  | 6,400 |  |
| Net cash provided by operating activities |  |  | 18,585 |  |  |  | 75,635 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |
| Capital expenditures |  |  | (6,916 | ) |  |  | (4,314 | ) |
| Net cash used in investing activities |  |  | (6,916 | ) |  |  | (4,314 | ) |
| Cash flows from financing activities: |  |  |  |  |  |  |
| Net payments on revolving facility |  |  | — |  |  |  | (25,000 | ) |
| Payments on debt obligations |  |  | (2,500 | ) |  |  | (2,500 | ) |
| Payments on debt financing costs |  |  | (695 | ) |  |  | — |  |
| Repurchase of common stock |  |  | — |  |  |  | (24,889 | ) |
| Payments for tax withholdings, net of proceeds from issuance of common stock |  |  | (5,926 | ) |  |  | (29,072 | ) |
| Net cash used in financing activities |  |  | (9,121 | ) |  |  | (81,461 | ) |
| Foreign currency effect on cash and cash equivalents |  |  | 299 |  |  |  | (252 | ) |
| Net increase (decrease) in cash and cash equivalents |  |  | 2,847 |  |  |  | (10,392 | ) |
| Cash and cash equivalents at beginning of period |  |  | 156,699 |  |  |  | 234,826 |  |
| Cash and cash equivalents at end of period |  | $ | 159,546 |  |  | $ | 224,434 |  |
| (1) The prior period amounts have been reclassified to conform to the current period presentation |  |  |  |  |  |  |

[0000950170-24-118589:8k_2_02:75]
Extreme Networks, Inc.

[0000950170-24-118589:8k_2_02:76]
Non-GAAP Measures of Financial Performance

[0000950170-24-118589:8k_2_02:77]
To supplement the Company's consolidated financial statements presented in accordance with U.S. generally accepted accounting principles (“GAAP”), Extreme uses non-GAAP measures of certain components of financial performance.  These non-GAAP measures include non-GAAP gross profit, non-GAAP gross margin, non-GAAP operating margin, non-GAAP operating income (loss), non-GAAP net income (loss), non-GAAP net income (loss) per diluted share, net cash (debt) and non-GAAP free cash flow.

[0000950170-24-118589:8k_2_02:78]
Reconciliation to the nearest GAAP measure of all historical non-GAAP measures included in this press release can be found in the tables included with this press release.

[0000950170-24-118589:8k_2_02:79]
Non-GAAP measures presented in this press release are not in accordance with or alternative measures prepared in accordance with GAAP and may be different from non-GAAP measures used by other companies.  In addition, these non-GAAP measures are not based on any comprehensive set of accounting rules or principles.  Non-GAAP measures have limitations in that they do not reflect all of the amounts associated with Extreme’s results of operations as determined in accordance with GAAP.  These non-GAAP measures should only be used to evaluate Extreme’s results of operations in conjunction with the corresponding GAAP measures.

[0000950170-24-118589:8k_2_02:80]
Extreme believes these non-GAAP measures, when shown in conjunction with the corresponding GAAP measures, enhance investors' and management's overall understanding of the Company's current financial performance and the Company's prospects for the future, including cash flows available to pursue opportunities to enhance stockholder value.  In addition, because Extreme has historically reported certain non-GAAP results to investors, the Company believes the inclusion of non-GAAP measures provides consistency in the Company's financial reporting.

[0000950170-24-118589:8k_2_02:81]
For its internal planning process, and as discussed further below, Extreme's management uses financial statements that do not include share-based compensation expense, amortization of intangibles, restructuring charges, system transition costs, litigation charges, debt refinancing charges and the tax effect of non-GAAP adjustments.  Extreme’s management also uses non-GAAP measures, in addition to the corresponding GAAP measures, in reviewing the Company's financial results.

[0000950170-24-118589:8k_2_02:82]
As described above, Extreme excludes the following items from one or more of its non-GAAP measures when applicable.

[0000950170-24-118589:8k_2_02:83]
Share-based compensation. Consists of associated expenses for stock options, restricted stock awards and the Company’s Employee Stock Purchase Plan.  Extreme excludes share-based compensation expenses from its non-GAAP measures primarily because they are non-cash expenses that the Company does not believe are reflective of ongoing cash requirement related to its operating results. Extreme expects to incur share-based compensation expenses in future periods.

[0000950170-24-118589:8k_2_02:84]
Amortization of intangibles. Amortization of intangibles includes the monthly amortization expense of intangible assets such as developed technology, customer relationships, trademarks and order backlog.  The amortization of the developed technology and order backlog are recorded in cost of goods sold, while the amortization for the other intangibles is recorded in operating expenses.  Extreme excludes these expenses since they result from an intangible asset and for which the period expense does not impact the operations of the business and are non-cash in nature.

[0000950170-24-118589:8k_2_02:85]
Restructuring charges. Restructuring charges consist of severance costs for employees, asset disposal costs and other charges related to excess facilities that do not provide economic benefit to our future operations. Extreme excludes restructuring expenses since they result from events that occur outside of the ordinary course of continuing operations.

[0000950170-24-118589:8k_2_02:86]
System transition costs. System transition costs consist of costs related to direct and incremental costs incurred in connection with our multi-phase transition of our customer relationship management solution and our configure, price, quote solution. Extreme excludes these costs because we believe that these costs do not reflect future operating expenses and will be inconsistent in amount and frequency, making it difficult to contribute to a meaningful evaluation of our operating performance.

[0000950170-24-118589:8k_2_02:87]
Litigation charges. Litigation charges consist of estimated settlement and related legal expenses for a non-recurring pending litigation.

[0000950170-24-118589:8k_2_02:88]
Debt refinancing charges. Debt refinancing charges consist of costs that were not capitalizable and are included in other income (expense), that occurred in conjunction with the amendment related to our outstanding credit facility.

[0000950170-24-118589:8k_2_02:89]
Tax effect of non-GAAP adjustments. We calculate our non-GAAP provision for income taxes in accordance with the SEC guidance on non-GAAP Financial Measures Compliance and Disclosure Interpretation. We have assumed our U.S. federal and state net operating losses would have been fully consumed by the historical non-GAAP financial adjustments, eliminating the need for a full valuation allowance against our U.S. deferred tax assets which, consequently, enables our use of research and development tax credits. The non-GAAP tax provision consists of current and deferred income tax expense commensurate with the non-GAAP measure of profitability using our blended U.S. statutory tax rate of 24.6%.

[0000950170-24-118589:8k_2_02:90]
The non-GAAP provision for income taxes has typically been and is currently higher than the GAAP provision given the Company has a valuation allowance against its US and a portion of its Irish deferred tax assets due to historical losses. Once these valuation allowances are released, the non-GAAP and the GAAP provision for income taxes will be more closely aligned.

[0000950170-24-118589:8k_2_02:91]
Over the next year, our cash taxes will be driven by US federal and state taxes and the tax expense of our foreign subsidiaries, which amounts have not historically been significant, with the exception of the Company’s Indian subsidiary which performs research and development activities, as well as the Company’s Irish trading subsidiaries.

[0000950170-24-118589:8k_2_02:92]
EXTREME NETWORKS, INC.

[0000950170-24-118589:8k_2_02:93]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS

[0000950170-24-118589:8k_2_02:94]
GAAP TO NON-GAAP RECONCILIATION

[0000950170-24-118589:8k_2_02:95]
(In thousands, except percentages and per share amounts)

[0000950170-24-118589:8k_2_02:96]
(Unaudited)

[0000950170-24-118589:8k_2_02:97]
| Revenues | Three Months Ended |  |
|  | September 30,2024 |  |  | September 30,2023 |  |  | June 30, 2024 |  |
| Revenues – GAAP | $ | 269,204 |  |  | $ | 353,137 |  |  | $ | 256,653 |  |

[0000950170-24-118589:8k_2_02:98]
| Non-GAAP Gross Margin | Three Months Ended |  |
|  | September 30,2024 |  |  | September 30,2023 |  |  | June 30, 2024 |  |
| Gross profit – GAAP | $ | 169,507 |  |  | $ | 212,936 |  |  | $ | 114,624 |  |
| Gross margin – GAAP percentage |  | 63.0 | % |  |  | 60.3 | % |  |  | 44.7 | % |
| Adjustments: |  |  |  |  |  |  |  |  |
| Share-based compensation expense, Product |  | 618 |  |  |  | 483 |  |  |  | 547 |  |
| Share-based compensation expense, Subscription and support |  | 689 |  |  |  | 866 |  |  |  | 700 |  |
| Amortization of intangibles, Product |  | 606 |  |  |  | 1,144 |  |  |  | 594 |  |
| Amortization of intangibles, Subscription and support |  | — |  |  |  | 272 |  |  |  | — |  |
| Total adjustments to GAAP gross profit | $ | 1,913 |  |  | $ | 2,765 |  |  | $ | 1,841 |  |
| Gross profit – non-GAAP | $ | 171,420 |  |  | $ | 215,701 |  |  | $ | 116,465 |  |
| Gross margin – non-GAAP percentage |  | 63.7 | % |  |  | 61.1 | % |  |  | 45.4 | % |

[0000950170-24-118589:8k_2_02:99]
| Non-GAAP Operating Margin | Three Months Ended |  |
|  | September 30,2024 |  |  | September 30,2023 |  |  | June 30, 2024 |  |
| GAAP operating income (loss) | $ | (4,717 | ) |  | $ | 35,899 |  |  | $ | (48,948 | ) |
| GAAP operating margin |  | (1.8 | )% |  |  | 10.2 | % |  |  | (19.1 | )% |
| Adjustments: |  |  |  |  |  |  |  |  |
| Share-based compensation expense, cost of revenues |  | 1,307 |  |  |  | 1,349 |  |  |  | 1,247 |  |
| Share-based compensation expense, R&D |  | 4,213 |  |  |  | 4,377 |  |  |  | 3,648 |  |
| Share-based compensation expense, S&M |  | 6,882 |  |  |  | 6,988 |  |  |  | 6,318 |  |
| Share-based compensation expense, G&A |  | 7,365 |  |  |  | 7,205 |  |  |  | 6,841 |  |
| Restructuring and related charges |  | 1,277 |  |  |  | 2,717 |  |  |  | 10,009 |  |
| Litigation charges |  | 10,715 |  |  |  | 1,460 |  |  |  | 5,127 |  |
| System transition costs |  | 5,345 |  |  |  | 569 |  |  |  | 2,816 |  |
| Amortization of intangibles |  | 1,118 |  |  |  | 1,927 |  |  |  | 1,104 |  |
| Total adjustments to GAAP operating income (loss) | $ | 38,222 |  |  | $ | 26,592 |  |  | $ | 37,110 |  |
| Non-GAAP operating income (loss) | $ | 33,505 |  |  | $ | 62,491 |  |  | $ | (11,838 | ) |
| Non-GAAP operating margin |  | 12.4 | % |  |  | 17.7 | % |  |  | (4.6 | )% |

[0000950170-24-118589:8k_2_02:100]
| Non-GAAP Net Income (Loss) | Three Months Ended |  |
|  | September 30,2024 |  |  | September 30,2023 |  |  | June 30, 2024 |  |
| GAAP net income (loss) | $ | (10,504 | ) |  | $ | 28,676 |  |  | $ | (54,203 | ) |
| Adjustments: |  |  |  |  |  |  |  |  |
| Share-based compensation expense |  | 19,767 |  |  |  | 19,919 |  |  |  | 18,054 |  |
| Restructuring and related charges |  | 1,277 |  |  |  | 2,717 |  |  |  | 10,009 |  |
| Litigation charges |  | 10,715 |  |  |  | 1,460 |  |  |  | 5,127 |  |
| System transition costs |  | 5,345 |  |  |  | 569 |  |  |  | 2,816 |  |
| Amortization of intangibles |  | 1,118 |  |  |  | 1,927 |  |  |  | 1,104 |  |
| Debt refinancing charges, Other income (expense) |  | 79 |  |  |  | — |  |  |  | — |  |
| Tax effect of non-GAAP adjustments |  | (5,398 | ) |  |  | (8,728 | ) |  |  | 7,230 |  |
| Total adjustments to GAAP net income (loss) | $ | 32,903 |  |  | $ | 17,864 |  |  | $ | 44,340 |  |
| Non-GAAP net income (loss) | $ | 22,399 |  |  | $ | 46,540 |  |  | $ | (9,863 | ) |
| Earnings (Loss) per share |  |  |  |  |  |  |  |  |
| GAAP net income (loss) per share – diluted | $ | (0.08 | ) |  | $ | 0.21 |  |  | $ | (0.42 | ) |
| Non-GAAP net income (loss) per share – diluted | $ | 0.17 |  |  | $ | 0.35 |  |  | $ | (0.08 | ) |
| Shares used in net income (loss) per share – diluted: |  |  |  |  |  |  |  |  |
| GAAP Shares used in per share calculation – basic |  | 131,176 |  |  |  | 128,782 |  |  |  | 130,093 |  |
| Potentially dilutive equity awards |  | 1,103 |  |  |  | 4,681 |  |  |  | — |  |
| GAAP and Non-GAAP shares used in per share calculation – diluted |  | 132,279 |  |  |  | 133,463 |  |  |  | 130,093 |  |
