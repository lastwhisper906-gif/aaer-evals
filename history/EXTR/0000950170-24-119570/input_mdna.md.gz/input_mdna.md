# EXTR MD&A — 0000950170-24-119570


## mdna

[0000950170-24-119570:mdna:1]
[same as prior period, unchanged from 0000950170-24-052140:mdna:1]

[0000950170-24-119570:mdna:2]
[same as prior period, unchanged from 0000950170-24-052140:mdna:2]

[0000950170-24-119570:mdna:3]
[same as prior period, unchanged from 0000950170-24-052140:mdna:3]

[0000950170-24-119570:mdna:4]
Extreme Networks, Inc. (“Extreme” or “Company”) is a leading provider of cloud networking solutions and industry leading services and support. Extreme designs, develops, and manufactures wired, wireless, and software-defined wide area-network (“SD-WAN”) infrastructure equipment, software and cloud-based network management solutions. The Company’s cloud solution is a single platform that offers unified network management of wireless access points, switches, and SD-WAN. It leverages machine learning, Artificial Intelligence for Information Technology Operations (“AIOps”) and analytics to help customers deliver secure connectivity at the edge of the network, speed cloud deployments, and uncover actionable insights to save time, lower costs and streamline operations.

[0000950170-24-119570:mdna:5]
Extreme has been pushing the boundaries of networking technology since 1996, driven by a higher purpose of helping our customers connect beyond the network. Extreme’s cloud networking technologies provide flexibility and scalability in deployment, management, and licensing of networks globally. Our global footprint provides service to some of the world’s leading names in business, hospitality, retail, transportation and logistics, education, government, healthcare, manufacturing and service providers. We derive all our revenues from the sale of our networking equipment, software subscriptions, and related maintenance contracts.

[0000950170-24-119570:mdna:6]
[same as prior period, unchanged from 0000950170-24-052140:mdna:6]

[0000950170-24-119570:mdna:7]
Enterprises across every industry are going through unprecedented changes, such as leading digital initiatives, migrating their workloads to cloud-based environments, modernizing applications, finding new ways to leverage generative AI (“GenAI”) technology, and adopting to a distributed workforce. In order to accomplish this, they are adopting new Information Technology (“IT”) delivery models and applications that require fundamental network alterations and enhancements spanning from the access edge to the data center. As networks become more complex and more distributed in nature, we believe IT teams in every industry will need more control and better insights than ever before to ensure secure, distributed connectivity and comprehensive centralized visibility. Networking is mission critical and touches all elements of how services are delivered to customers, employees, students, and patients. Managing networks from cloud-based applications where customers can run their entire end-to-end networks, from wired or wireless infrastructure to SD-WAN, while ensuring full IT management of the business becomes critical. In addition, Machine Learning (“ML”) and GenAI technologies have the potential to vastly improve the network experience in today's world by collating large data sets to increase accuracy and derive resolutions to improve the operation of the network. When ML and GenAI are applied with cloud-driven networking and automation, administrators can quickly scale to provide productivity, availability, accessibility, manageability, security, and speed, regardless of the distribution of the network.

[0000950170-24-119570:mdna:8]
[same as prior period, unchanged from 0000950170-24-052140:mdna:8]

[0000950170-24-119570:mdna:9]
[same as prior period, unchanged from 0000950170-24-052140:mdna:9]

[0000950170-24-119570:mdna:10]
[same as prior period, unchanged from 0000950170-24-052140:mdna:10]

[0000950170-24-119570:mdna:11]
As enterprises continue to migrate increasing numbers of applications and services to either private clouds or public clouds offered by third parties and to adopt new IT delivery models and applications, they are required to make fundamental network alterations and enhancements spanning from device access points (“APs”) to the network core. In either case, the network infrastructure must adapt to this new dynamic environment. Intelligence and automation are key if enterprises are to derive maximum benefit from their cloud deployments. With automation applications becoming increasingly critical in manufacturing, warehousing, logistics, healthcare and other key industries, we believe this will continue to create demand for networking technology to serve as a foundation to run these services.

[0000950170-24-119570:mdna:12]
[same as prior period, unchanged from 0000950170-24-052140:mdna:12]

[0000950170-24-119570:mdna:13]
[same as prior period, unchanged from 0000950170-24-052140:mdna:13]

[0000950170-24-119570:mdna:14]
We estimate the total addressable market for our Enterprise Networking solutions consisting of cloud networking, wireless local area networks (“WLAN”), data center networking, ethernet switching, campus local area networks (“LAN”), SD-WAN solutions and management, automation, and elements of the Secure Access Services Edge (“SASE”) market to be over $47 billion, and growing at approximately 13% annually over the next five years. This comprises over $36 billion for networking and infrastructure spanning enterprise and service provider (largely 5G) applications, and $11 billion for networking cloud and security software, which is expected to grow to $31 billion by 2028.

[0000950170-24-119570:mdna:15]
[same as prior period, unchanged from 0000950170-24-052140:mdna:15]

[0000950170-24-119570:mdna:16]
[same as prior period, unchanged from 0000950170-24-052140:mdna:16]

[0000950170-24-119570:mdna:17]
Customers recognize that Extreme offers the simplest and easiest to manage, end-to-end enterprise networking platform in the industry. Our One Network, One Cloud, One Extreme solution, enhanced with our AI Ops capabilities, excels relative to the complex and high total cost of ownership solutions of our competitors. This framework remains a competitive differentiator, particularly at a time when major competitors have created complexity with disjointed solutions and uncertainty in their long-term rationalization of products and solutions. We are focused on helping customers find new ways to deliver better outcomes such as increased IT productivity, reduced operating expenses, or securing their business. Our sole focus on networking allows us to offer a differentiated and integrated portfolio and a clear roadmap to meet customers’ needs.

[0000950170-24-119570:mdna:18]
Cloud networking management allows customers to gain real-time visibility and insights into areas such as application usage, location and workflow patterns across their environment, helping to inform strategic business decisions and create personalized experiences. Customers benefit from visibility, control, and reduced time to resolution. This is the cornerstone of our One Network, One Cloud, One Extreme vision. Subscription services allow us to deliver more value over time to this installed base. Our flexibility in delivering management, AI, security and other capabilities to customers both on premises and in the cloud gives them much more value than our competitors. We have one license per device and compared to the complicated offerings of our competitors, this is a very differentiated value proposition. Extreme’s broad product, solutions, and technology portfolio supports these tenets and continues to innovate and evolve them to help businesses succeed.

[0000950170-24-119570:mdna:19]
[same as prior period, unchanged from 0000950170-24-052140:mdna:19]

[0000950170-24-119570:mdna:20]
[same as prior period, unchanged from 0000950170-24-052140:mdna:20]

[0000950170-24-119570:mdna:21]
[same as prior period, unchanged from 0000950170-24-052140:mdna:21]

[0000950170-24-119570:mdna:22]
[same as prior period, unchanged from 0000950170-24-052140:mdna:22]

[0000950170-24-119570:mdna:23]
[same as prior period, unchanged from 0000950170-24-052140:mdna:23]

[0000950170-24-119570:mdna:24]
[same as prior period, unchanged from 0000950170-24-052140:mdna:24]

[0000950170-24-119570:mdna:25]
[same as prior period, unchanged from 0000950170-24-052140:mdna:25]

[0000950170-24-119570:mdna:26]
•
Provide a differentiated end-to-end cloud architecture. Cloud networking is estimated to be an $11 billion segment of the networking market comprising cloud managed services and cloud-managed products, which are largely WLAN access points and ethernet switches, growing at 14% annually over the next five years, according to data from the 650 Group, Gartner, IDC, and Dell'Oro. Cloud management technology has evolved significantly over the past decade. We believe we deliver a combination of innovation, reliability, and security with the leading end-to-end cloud management platform powered by ML and AI that spans from the Internet of Things (“IoT”) edge to the enterprise data center. Key characteristics of our cloud architecture include:

[0000950170-24-119570:mdna:27]
[same as prior period, unchanged from 0000950170-24-052140:mdna:27]

[0000950170-24-119570:mdna:28]
[same as prior period, unchanged from 0000950170-24-052140:mdna:28]

[0000950170-24-119570:mdna:29]
o
Consumption Flexibility: Offer a range of financing and network purchase options. Our value-based subscription tiers provide customers with flexibility to grow, as well as offer pool-able and portable licenses that can be transferred between products (e.g. access points and switches) at one fixed price.

[0000950170-24-119570:mdna:30]
[same as prior period, unchanged from 0000950170-24-052140:mdna:30]

[0000950170-24-119570:mdna:31]
[same as prior period, unchanged from 0000950170-24-052140:mdna:31]

[0000950170-24-119570:mdna:32]
[same as prior period, unchanged from 0000950170-24-052140:mdna:32]

[0000950170-24-119570:mdna:33]
•
Highest value of cloud management subscriptions. ExtremeCloud IQ provides unified cloud-native management driven by AI and ML for wireless access points, network switches, and SD-WAN solutions. It features intuitive configuration workflows, real-time and historical monitoring, comprehensive troubleshooting, and integrated network applications for Extreme customers. The innovative ML technologies of ExtremeCloud IQ analyze and interpret millions of network and user data points, from the edge to the data center, to power actionable business and IT insights. The platform streamlines operations by delivering new levels of network automation and intelligence. The ExtremeCloud IQ Pilot license tier streamlines every aspect of network management from deployment and maintenance to problem resolution. The Pilot license includes key capabilities for guest management, WIPS, and location services with associated services: ExtremeGuest, ExtremeAirDefense, and ExtremeLocation.

[0000950170-24-119570:mdna:34]
[same as prior period, unchanged from 0000950170-24-052140:mdna:36]

[0000950170-24-119570:mdna:35]
[same as prior period, unchanged from 0000950170-24-052140:mdna:34]

[0000950170-24-119570:mdna:36]
[same as prior period, unchanged from 0000950170-24-052140:mdna:35]

[0000950170-24-119570:mdna:37]
•
Additional AI Capabilities. The ExtremeCloud IQ CoPilot license tier is an add-on to the Pilot license tier. It includes all the capabilities of the ExtremeCloud Pilot and Navigator license tiers. CoPilot serves as more than a centralized point of management with AIOps, Digital Twin and other enhancements to network management and automation. It is a trusted digital advisor for your Extreme cloud-managed Wi-Fi networks that proactively reduces risk and provides the fastest time to the best experience. This includes advanced anomaly detection and capabilities to ensure the user experience of wireless and wired devices.

[0000950170-24-119570:mdna:38]
[same as prior period, unchanged from 0000950170-24-052140:mdna:37]

[0000950170-24-119570:mdna:39]
[same as prior period, unchanged from 0000950170-24-052140:mdna:38]

[0000950170-24-119570:mdna:40]
[same as prior period, unchanged from 0000950170-24-052140:mdna:39]

[0000950170-24-119570:mdna:41]
[same as prior period, unchanged from 0000950170-24-052140:mdna:40]

[0000950170-24-119570:mdna:42]
•
AI is a dynamic tool  and is leveraged to drive productivity across our company and to offer security and GenAI solutions to our customers. Extreme’s journey in AI began in 2020 with the advent of machine learning and purpose-built AI. We then introduced Co-Pilot AIOps in 2022 to further enhance network performance and troubleshooting. Today we have the next exciting chapter – Extreme AI Expert – a GenAI  solution that will help optimize networks, provide better design, improve mean time to resolution for technical issues, and create cost savings in the overall design and implementation of networks. We are utilizing AI to improve mean time to resolution for customers, both through our AIOps offerings as well as internal use of Extreme AI Expert. We announced a technology preview of our Extreme AI Expert showcasing its ability to speed up documentation searches and resolution of network performance issues. This allows our customers to optimize their network performance and make it easier to focus on value-added activities.

[0000950170-24-119570:mdna:43]
There are several ways customers will be able to leverage our AI in the future:

[0000950170-24-119570:mdna:44]
o
Knowledge queries provide the ability to answer any question in context (i.e., role, application, conversation). Questions are answered with Extreme’s product documentation, GTAC knowledge base and selected training, and best practices material.

[0000950170-24-119570:mdna:45]
o
Intelligent Queries are answered with customer network data from multiple applications (ExtremeCloud IQ, SD-WAN, etc.). User Manuals, Release Notes, How to Guides, EOSL, EOL, Licensing, Service Contracts ,and Company information.

[0000950170-24-119570:mdna:46]
o
“What-If” Queries give the ability for the system to work autonomously and optimize itself based on business key performance indicators ("KPIs"). These scenarios work on an on-demand, scheduled, or always-on basis. Predictive and scenario questions that are answered apply further processing to the network data, anomaly detections, pattern recognition, root cause analysis, predictive analytics and network optimization.

[0000950170-24-119570:mdna:47]
[same as prior period, unchanged from 0000950170-24-052140:mdna:41]

[0000950170-24-119570:mdna:48]
•
Offer a frictionless experience for secure hybrid work. Our layered security approach is managed from one cloud and secure by design. We offer tightly integrated security with network fabric and infrastructure.

[0000950170-24-119570:mdna:49]
o
We launched ExtremeCloud Universal ZTNA, the first network security offering to integrate network, application, and device security within a single solution. By combining Cloud Network Access Control ("NAC") and Zero Trust Network Authentication ("ZTNA") into a single, easy-to-use SaaS offering, we help customers ensure unified observability, frictionless user experiences and a consistent security policy for applications and devices and supports secure hybrid work use cases for customers. As the VPN market transitions to ZTNA, the proliferation of individual applications, each with their own policy and dashboard, is adding complexity and expense for enterprise customers. We expect the broadening of our security offering to drive significant traction for our business with growth opportunities.

[0000950170-24-119570:mdna:50]
o
Extreme’s unique and highly differentiated fabric makes it simple to orchestrate applications and policy across the entire campus, from the core to the wireless edge, and across the wide area network. We bring enhanced security, the

[0000950170-24-119570:mdna:51]
ability to segment networks and zero touch provisioning, thus eliminating confusion, complexity and the need for additional IT staff. This is in stark contrast to our competitors’ fabric solutions, which were designed for service provider and data center networks and not meant for the campus.

[0000950170-24-119570:mdna:52]
o
Extreme AirDefense delivers intrusion detection and prevention capabilities across the wireless portfolio.

[0000950170-24-119570:mdna:53]
[same as prior period, unchanged from 0000950170-24-052140:mdna:42]

[0000950170-24-119570:mdna:54]
[same as prior period, unchanged from 0000950170-24-052140:mdna:43]

[0000950170-24-119570:mdna:55]
[same as prior period, unchanged from 0000950170-24-052140:mdna:44]

[0000950170-24-119570:mdna:56]
•
Expand Wi-Fi technology leadership. Wireless is today’s network access method of choice, and every business must deal with scale, density and BYOD challenges. The network edge landscape is changing as the explosion of mobile and IoT devices increases the demand for high-performance, transparent, and always-on wired to wireless edge services. The unified access layer requires distributed intelligent components to ensure that access control and resiliency of business services are available across the entire infrastructure and manageable from a single console. We are at a technology inflection point with the pending migration from Wi-Fi 6 solutions to 6 GHz Wi-Fi (Wi-Fi 6E and Wi-Fi 7), focused on providing more efficient access to the broad array of connected devices. We believe we have the industry’s broadest 6 GHz indoor and outdoor wireless portfolio, providing intelligence and security for wired/wireless networks by leveraging our cloud architecture, end-to-end fabric services, Universal ZTNA, and AIOps management platform with Explainable ML insights.

[0000950170-24-119570:mdna:57]
[same as prior period, unchanged from 0000950170-24-052140:mdna:46]

[0000950170-24-119570:mdna:58]
[same as prior period, unchanged from 0000950170-24-052140:mdna:47]

[0000950170-24-119570:mdna:59]
[same as prior period, unchanged from 0000950170-24-052140:mdna:48]

[0000950170-24-119570:mdna:60]
[same as prior period, unchanged from 0000950170-24-052140:mdna:49]

[0000950170-24-119570:mdna:61]
[same as prior period, unchanged from 0000950170-24-052140:mdna:51]

[0000950170-24-119570:mdna:62]
During the first quarter of fiscal 2025, we achieved the following results:

[0000950170-24-119570:mdna:63]
•
Net revenues of $269.2 million compared to $353.1 million in the first quarter of fiscal 2023.

[0000950170-24-119570:mdna:64]
•
Product revenues of $162.3 million compared to $253.5 million in the first quarter of fiscal 2023.

[0000950170-24-119570:mdna:65]
•
Subscription and support revenues of $106.9 million compared to $99.7 million in the first quarter of fiscal 2023.

[0000950170-24-119570:mdna:66]
•
Total gross margin of 63.0% of net revenues compared to 60.3% of net revenues in the first quarter of fiscal 2023.

[0000950170-24-119570:mdna:67]
•
Operating loss of $4.7 million compared to operating income of $35.9 million in the first quarter of fiscal 2023.

[0000950170-24-119570:mdna:68]
•
Net loss of $10.5 million compared to net income of $28.7 million in the first quarter of fiscal 2023.

[0000950170-24-119570:mdna:69]
During the first three months of fiscal 2025, we reflected the following results:

[0000950170-24-119570:mdna:70]
•
Cash flows provided by operating activities of $18.6 million compared to $75.6 million in the three months ended September 30, 2023.

[0000950170-24-119570:mdna:71]
•
Cash and cash equivalents of $159.5 million as of September 30, 2024 compared to $156.7 million as of June 30, 2024.

[0000950170-24-119570:mdna:72]
[same as prior period, unchanged from 0000950170-24-052140:mdna:62]

[0000950170-24-119570:mdna:73]
[same as prior period, unchanged from 0000950170-24-052140:mdna:63]

[0000950170-24-119570:mdna:74]
|  |  | Three Months Ended |
|  |  | September 30,2024 |  | September 30,2023 |  | $Change |  | %Change |
| Net revenues: |  |  |  |  |  |  |  |  |
| Product |  | $162,284 |  | $253,483 |  | $(91,199) |  | (36.0)% |
| Percentage of net revenues |  | 60.3% |  | 71.8% |  |  |  |  |
| Subscription and support |  | 106,920 |  | 99,654 |  | 7,266 |  | 7.3 % |
| Percentage of net revenues |  | 39.7% |  | 28.2% |  |  |  |  |
| Total net revenues |  | $269,204 |  | $353,137 |  | $(83,933) |  | (23.8)% |

[0000950170-24-119570:mdna:75]
We generate product revenues primarily from sales of our networking equipment. We derive subscription and support revenues primarily from sales of our subscription and support offerings which includes SaaS offerings, maintenance contracts, professional services and training for our products.

[0000950170-24-119570:mdna:76]
Product revenues decreased $91.2 million or 36.0% for the three months ended September 30, 2024 as compared to the corresponding period in fiscal 2024. The decrease in product revenues was primarily driven by lower bookings, shipments and lower channel sell-through caused by current macroeconomic conditions.

[0000950170-24-119570:mdna:77]
Subscription and support revenues increased $7.3 million or 7.3% for the three months ended September 30, 2024 as compared to the corresponding period in fiscal 2024. The increase in subscription and support revenues was primarily due to the continued growth in our subscription business.

[0000950170-24-119570:mdna:78]
[same as prior period, unchanged from 0000950170-24-052140:mdna:68]

[0000950170-24-119570:mdna:79]
|  |  | Three Months Ended |
|  |  | September 30,2024 |  | September 30,2023 |  | $Change |  | %Change |
| Gross profit: |  |  |  |  |  |  |  |  |
| Product |  | $92,882 |  | $144,947 |  | $(52,065) |  | (35.9)% |
| Percentage of product revenues |  | 57.2% |  | 57.2% |  |  |  |  |
| Subscription and support |  | 76,625 |  | 67,989 |  | 8,636 |  | 12.7 % |
| Percentage of subscription and support revenues |  | 71.7% |  | 68.2% |  |  |  |  |
| Total gross profit |  | $169,507 |  | $212,936 |  | $(43,429) |  | (20.4)% |
| Percentage of net revenues |  | 63.0% |  | 60.3% |  |  |  |  |

[0000950170-24-119570:mdna:80]
Product gross profit decreased $52.1 million or 35.9% for the three months ended September 30, 2024 as compared to the corresponding period in fiscal 2024. The decrease in product gross profit was primarily due to lower product revenues, partially offset by lower reserves for excess and obsolete inventory, lower intangible asset amortization due to certain intangible assets being fully amortized, lower distribution costs due to lower shipments and lower warranty reserves.

[0000950170-24-119570:mdna:81]
Subscription and support gross profit increased $8.6 million or 12.7% for the three months ended September 30, 2024 as compared to the corresponding period in fiscal 2024. The increase in subscription and support gross profit was primarily due to increased subscription and support revenues as well as lower personnel costs partially offset by increased subscription costs.

[0000950170-24-119570:mdna:82]
[same as prior period, unchanged from 0000950170-24-052140:mdna:72]

[0000950170-24-119570:mdna:83]
[same as prior period, unchanged from 0000950170-24-052140:mdna:73]

[0000950170-24-119570:mdna:84]
|  |  | Three Months Ended |
|  |  | September 30,2024 |  | September 30,2023 |  | $Change |  | %Change |
| Research and development |  | 54,451 |  | $58,016 |  | $(3,565) |  | (6.1)% |
| Sales and marketing |  | 81,383 |  | 91,920 |  | (10,537) |  | (11.5)% |
| General and administrative |  | 36,601 |  | 23,873 |  | 12,728 |  | 53.3 % |
| Restructuring and related charges |  | 1,277 |  | 2,717 |  | (1,440) |  | (53.0)% |
| Amortization of intangible assets |  | 512 |  | 511 |  | 1 |  | 0.2 % |
| Total operating expenses |  | 174,224 |  | $177,037 |  | $(2,813) |  | (1.6)% |

[0000950170-24-119570:mdna:85]
[same as prior period, unchanged from 0000950170-24-052140:mdna:75]

[0000950170-24-119570:mdna:86]
[same as prior period, unchanged from 0000950170-24-052140:mdna:76]

[0000950170-24-119570:mdna:87]
Research and development expenses decreased by $3.6 million or 6.1% for the three months ended September 30, 2024 as compared to the corresponding period in fiscal 2024. The decrease in research and development expenses was primarily due to a $2.7 million decrease in personnel costs due to lower compensation and benefits costs and a $2.6 million decrease in contractor costs partially offset by a $0.7 million increase in engineering project costs, a $0.7 million increase in information technology and facilities costs, and $0.4 million increase in other expenses primarily recruiting and professional fees.

[0000950170-24-119570:mdna:88]
[same as prior period, unchanged from 0000950170-24-052140:mdna:79]

[0000950170-24-119570:mdna:89]
[same as prior period, unchanged from 0000950170-24-052140:mdna:80]

[0000950170-24-119570:mdna:90]
Sales and marketing expenses decreased by $10.5 million or 11.5% for the three months ended September 30, 2024 as compared to the corresponding period in fiscal 2024. The decrease in sales and marketing expenses was primarily due to a $9.2 million decrease in personnel costs primarily due to lower headcount, a $1.0 million decrease in travel costs and a $0.3 million decrease in professional fees.

[0000950170-24-119570:mdna:91]
[same as prior period, unchanged from 0000950170-24-052140:mdna:83]

[0000950170-24-119570:mdna:92]
[same as prior period, unchanged from 0000950170-24-052140:mdna:84]

[0000950170-24-119570:mdna:93]
General and administrative expenses increased by $12.7 million or 53.3% for the three months ended September 30, 2024 as compared to the corresponding period in fiscal 2024. The increase in general and administrative expenses was primarily due to a $9.3 million increase in litigation charges due to an additional accrual for an ongoing litigation matter and a $4.8 million increase in system transition costs, partially offset by a $1.4 million decrease in equipment related expenses primarily due to lower depreciation and software maintenance costs.

[0000950170-24-119570:mdna:94]
[same as prior period, unchanged from 0000950170-24-052140:mdna:90]

[0000950170-24-119570:mdna:95]
For the three months ended September 30, 2024, we recorded restructuring and related charges of $1.3 million, which primarily consisted of additional severance and benefits costs and professional services fees associated with the reduction-in-force actions related to the “Q2 2024 Plan”, and "Q3 2024 Plan", each as described in Note 13, Restructuring and Related Charges, in Notes to the Condensed Consolidated Financial Statements included elsewhere in this Report.

[0000950170-24-119570:mdna:96]
For the three months ended September 30, 2023, we recorded restructuring and related charges of $2.7 million, which primarily consisted of costs associated with the headcount reduction related to the reduction-in-force plan executed during the first quarter in fiscal 2024.

[0000950170-24-119570:mdna:97]
[same as prior period, unchanged from 0000950170-24-052140:mdna:93]

[0000950170-24-119570:mdna:98]
During the three months ended September 30, 2024 and 2023, we recorded $0.5 million of operating expenses for each period related to the amortization of intangible assets.

[0000950170-24-119570:mdna:99]
[same as prior period, unchanged from 0000950170-24-052140:mdna:96]

[0000950170-24-119570:mdna:100]
During the three months ended September 30, 2024 and 2023, we recorded $0.8 million and $1.2 million, respectively, in interest income. The decrease in interest income was primarily related to the lower interest earned on our cash accounts due to lower cash and cash equivalents balances held during the first quarter in fiscal 2025.

[0000950170-24-119570:mdna:101]
[same as prior period, unchanged from 0000950170-24-052140:mdna:99]

[0000950170-24-119570:mdna:102]
During the three months ended September 30, 2024 and 2023, we recorded $4.4 million and $4.3 million, respectively, in interest expense. The increase in interest expense was primarily due to higher average rates under the Amended Credit Agreement, as defined below.

[0000950170-24-119570:mdna:103]
[same as prior period, unchanged from 0000950170-24-052140:mdna:102]

[0000950170-24-119570:mdna:104]
During the three months ended September 30, 2024 and 2023, we recorded other expense, net of $0.7 million and other income, net of $0.4 million, respectively. The other income (expense), net for each period primarily related to the foreign exchange impact from the revaluation of certain assets and liabilities denominated in foreign currencies into U.S. Dollars.

[0000950170-24-119570:mdna:105]
[same as prior period, unchanged from 0000950170-24-052140:mdna:105]

[0000950170-24-119570:mdna:106]
For the three months ended September 30, 2024 and 2023, we recorded income tax provision of $1.5 million and $4.6 million, respectively.

[0000950170-24-119570:mdna:107]
The income tax provisions for the three months ended September 30, 2024 and 2023 consisted of (1) taxes on the income of our foreign subsidiaries, (2) state taxes in jurisdictions where we have no remaining state net operating losses, (3) foreign withholding taxes, and (4) tax expense associated with the establishment of a U.S. deferred tax liability for amortizable goodwill resulting from the acquisition of Enterasys Networks, Inc., the WLAN business from Zebra Technologies Corporation, the Campus Fabric Business from Avaya LLC and the Data Center Business from Brocade Communications System. In addition, the income tax provision (benefit) for the three months ended September 30, 2023 includes U.S. federal income tax expense of $1.4 million.

[0000950170-24-119570:mdna:108]
[same as prior period, unchanged from 0000950170-24-052140:mdna:109]

[0000950170-24-119570:mdna:109]
[same as prior period, unchanged from 0000950170-24-052140:mdna:110]

[0000950170-24-119570:mdna:110]
As discussed in Part II, Item 7, “Management’s Discussion and Analysis of Financial Condition and Results of Operations” of our Annual Report on Form 10-K for the year ended June 30, 2024, we consider the following accounting policies to be the most critical in understanding the judgments that are involved in preparing our consolidated financial statements:

[0000950170-24-119570:mdna:111]
[same as prior period, unchanged from 0000950170-24-052140:mdna:112]

[0000950170-24-119570:mdna:112]
[same as prior period, unchanged from 0000950170-24-052140:mdna:113]

[0000950170-24-119570:mdna:113]
[same as prior period, unchanged from 0000950170-24-052140:mdna:114]

[0000950170-24-119570:mdna:114]
[same as prior period, unchanged from 0000950170-24-052140:mdna:115]

[0000950170-24-119570:mdna:115]
[same as prior period, unchanged from 0000950170-24-052140:mdna:116]

[0000950170-24-119570:mdna:116]
|  |  | September 30,2024 |  |  | June 30,2024 |  |
| Cash and cash equivalents |  | $ | 159,546 |  |  | $ | 156,699 |  |

[0000950170-24-119570:mdna:117]
As of September 30, 2024, our principal sources of liquidity consisted of cash and cash equivalents of $159.5 million, accounts receivable, net of $97.2 million, and available borrowings under our 2023 Revolving Facility of $135.8 million. Our principal uses of cash include the purchase of finished goods inventory from our contract manufacturers, payroll and other operating expenses related to the development and marketing of our products, purchases of property and equipment, and repayments of debt and related interest and share repurchases. We believe that our $159.5 million of cash and cash equivalents at September 30, 2024, our cash flow from operations and the availability of borrowings from the 2023 Revolving Facility will be sufficient to fund our planned operations for at least the next 12 months and into the foreseeable future.

[0000950170-24-119570:mdna:118]
On May 18, 2022, our Board of Directors (the “Board”) authorized management to repurchase up to $200.0 million shares of our common stock over a three-year period commencing July 1, 2022 (as amended, the "2022 Repurchase Program"). A maximum of $25.0 million may be repurchased in any quarter. On November 17, 2022, the Board increased the authorization to repurchase in any quarter from $25.0 million per quarter to $50.0 million per quarter. Purchases may be made from time to time in the open market or pursuant to 10b5-1 plan. The manner, timing and amount of any future purchases will be determined by our management based on their evaluation of market conditions, stock price, Extreme’s ongoing determination that it is the best use of available cash and other factors. The 2022 Repurchase Program does not obligate us to acquire any shares of its common stock, may be suspended or terminated at any time without prior notice and will be subject to regulatory considerations. During the three months ended September 30, 2024, the Company did not repurchase any shares of its common stock. As of September 30, 2024, the Company had $50.3 million available under the 2022 Repurchase Program.

[0000950170-24-119570:mdna:119]
On August 9, 2019, we entered into an Amended and Restated Credit Agreement (the “2019 Credit Agreement”), by and among Extreme, as borrower, several banks and other financial institutions as Lenders, BMO Harris Bank N.A., as an issuing lender and swingline lender, Silicon Valley Bank, as an Issuing Lender, and Bank of Montreal, as administrative agent and collateral agent for the Lenders.

[0000950170-24-119570:mdna:120]
On June 22, 2023, we entered into the Second Amended and Restated Credit Agreement (the “2023 Credit Agreement”) by and among Extreme, as borrower, BMO Harris Bank, N.A., as an issuing lender and swingline lender, Bank of America, N.A., JPMorgan Chase Bank, N.A., PNC Bank, National Association and Wells Fargo Bank, National Association, as issuing lenders, the financial institutions or entities party thereto as lenders, and Bank of Montreal, as an administrative agent and collateral agent, which amended and restated the 2019 Credit Agreement. The 2023 Credit Agreement provides for i) a $200.0 million first lien term loan facility in an aggregate principal amount (the “Term Facility”), ii) a $150.0 million five-year revolving credit facility (the “2023 Revolving Facility”) and iii) an uncommitted additional incremental loan facility in the principal amount of up to $100.0 million plus an unlimited amount that is subject to pro forma compliance with a specified Consolidated Leverage Ratio tests. We may use the proceeds of the loans for working capital and general corporate purposes.

[0000950170-24-119570:mdna:121]
[same as prior period, unchanged from 0000950170-24-052140:mdna:121]

[0000950170-24-119570:mdna:122]
The 2023 Credit Agreement requires us to maintain certain minimum financial ratios at the end of each fiscal quarter. The 2023 Credit Agreement also includes covenants and restrictions that limit, among other things, our ability to incur additional indebtedness, create liens upon any of its property, merge, consolidate or sell all or substantially all of its assets. The 2023 Credit Agreement also includes customary events of default which may result in acceleration of the outstanding balance.

[0000950170-24-119570:mdna:123]
On August 14, 2024, we entered into an Amendment Number One to the 2023 Credit Agreement the “Amended Credit Agreement." Under the Amended Credit Agreement, we modified the definition of the consolidated EBITDA for the purposes of evaluating compliance with financial covenants under the 2023 Credit Agreement. The amended definition of consolidated EBITDA modifies the amount and type of add-backs that are allowable to better align with our operations and activities.

[0000950170-24-119570:mdna:124]
During the three months ended September 30, 2024, the Company was in compliance with the modified terms and financial covenants under the Amended Credit Agreement.

[0000950170-24-119570:mdna:125]
[same as prior period, unchanged from 0000950170-24-052140:mdna:124]

[0000950170-24-119570:mdna:126]
[same as prior period, unchanged from 0000950170-24-052140:mdna:125]

[0000950170-24-119570:mdna:127]
|  |  | Three Months Ended |  |
|  |  | September 30,2024 |  |  | September 30,2023 |  |
| Net cash provided by operating activities |  | $ | 18,585 |  |  | $ | 75,635 |  |
| Net cash used in investing activities |  |  | (6,916 | ) |  |  | (4,314 | ) |
| Net cash used in financing activities |  |  | (9,121 | ) |  |  | (81,461 | ) |
| Foreign currency effect on cash and cash equivalents |  |  | 299 |  |  |  | (252 | ) |
| Net increase (decrease) in cash and cash equivalents |  | $ | 2,847 |  |  | $ | (10,392 | ) |

[0000950170-24-119570:mdna:128]
[same as prior period, unchanged from 0000950170-24-052140:mdna:127]

[0000950170-24-119570:mdna:129]
Cash flows provided by operations in the three months ended September 30, 2024 were $18.6 million, including our net loss of $10.5 million and non-cash expenses of $27.8 million for items such as amortization of intangible assets, share-based compensation, depreciation, reduction in carrying amount of right-of-use assets, deferred income taxes, provision for excess and obsolete inventory and interest. Other sources of cash for the period included a decrease in prepaid expenses and other assets and increases in accounts payable, deferred revenue and accrued compensation and benefits. This was partially offset by increases in accounts receivable, inventories as well as decreases in operating lease liabilities and other liabilities.

[0000950170-24-119570:mdna:130]
Cash flows provided by operations in the three months ended September 30, 2023 were $75.6 million, including our net income of $28.7 million and non-cash expenses of $43.3 million for items such as amortization of intangible assets, share-based compensation, depreciation, reduction in carrying amount of right-of-use assets, deferred income taxes, provision for excess or obsolete  and interest. Other sources of cash for the period included a decrease in accounts receivable, and an increase in deferred revenue and other accrued liabilities. This was partially offset by increases in inventories, prepaid and other assets and decreases in accounts payable, accrued compensation, operating lease liabilities and other current and long-term liabilities.

[0000950170-24-119570:mdna:131]
[same as prior period, unchanged from 0000950170-24-052140:mdna:130]

[0000950170-24-119570:mdna:132]
Cash flows used in investing activities in the three months ended September 30, 2024 were $6.9 million for the purchases of property and equipment.

[0000950170-24-119570:mdna:133]
Cash flows used in investing activities in the three months ended September 30, 2023 were $4.3 million for the purchases of property and equipment.

[0000950170-24-119570:mdna:134]
[same as prior period, unchanged from 0000950170-24-052140:mdna:133]

[0000950170-24-119570:mdna:135]
Cash flows used in financing activities in the three months ended September 30, 2024 were $9.1 million primarily due to a payment of $5.9 million for taxes paid on vested and released stock awards net of proceeds from the issuance of shares of our common stock under our Employee Stock Purchase Plan (“ESPP”) and exercise of stock options, a payment of $0.7 million for debt financing costs related to the Amended Credit Agreement, and a debt repayment of $2.5 million.

[0000950170-24-119570:mdna:136]
Cash flows used in financing activities in the three months ended September 30, 2023 were $81.5 million primarily due to payment of $29.1 million for taxes paid on vested and released stock awards net of proceeds from the issuance of shares of our common stock under our ESPP, a $25.0 million payment against our revolving facility, share repurchase of $24.9 million under our share repurchase program and debt repayment of $2.5 million.

[0000950170-24-119570:mdna:137]
[same as prior period, unchanged from 0000950170-24-052140:mdna:136]

[0000950170-24-119570:mdna:138]
Foreign currency effect on cash and cash equivalents increased in the three months ended September 30, 2024, primarily due to changes in foreign currency exchange rates between the U.S. Dollar and particularly the Indian Rupee, the UK Pound and the Euro.

[0000950170-24-119570:mdna:139]
[same as prior period, unchanged from 0000950170-24-052140:mdna:138]

[0000950170-24-119570:mdna:140]
As of September 30, 2024, we had contractual obligations resulting from our debt arrangement, agreements to purchase goods and services in the ordinary course of business and obligations under our operating lease arrangements.

[0000950170-24-119570:mdna:141]
Our debt obligations relate to amounts owed under our Amended Credit Agreement. As of September 30, 2024, we had $187.5 million of debt outstanding, which is payable on quarterly installments through our fiscal year 2028. We are subject to interest on our debt obligations and unused commitment fee. See Note 7, Debt, in the Notes to Condensed Consolidated Financial Statements in this Report for additional information regarding our debt obligations.

[0000950170-24-119570:mdna:142]
Our unconditional purchase obligations represent the purchase of long lead-time component inventory that our contract manufacturers procure in accordance with our forecast. We expect to honor the inventory purchase commitments within the next 12 months. As of September 30, 2024, we had non-cancelable commitments to purchase $37.3 million of inventory. See Note 8, Commitments and Contingencies, in the Notes to Condensed Consolidated Financial Statements for additional information regarding our purchase obligations.

[0000950170-24-119570:mdna:143]
We have contractual commitments to our suppliers which represent commitments for future services. As of September 30, 2024, we had contractual commitments of $23.7 million that are due through our fiscal year 2027.

[0000950170-24-119570:mdna:144]
We lease facilities under operating lease arrangements at various locations that expire at various dates through our fiscal year 2033. As of September 30, 2024, the value of our obligations under operating leases was $60.6 million.

[0000950170-24-119570:mdna:145]
[same as prior period, unchanged from 0000950170-24-052140:mdna:144]

[0000950170-24-119570:mdna:146]
We did not have any material commitments for capital expenditures as of September 30, 2024.

[0000950170-24-119570:mdna:147]
[same as prior period, unchanged from 0000950170-24-052140:mdna:146]

[0000950170-24-119570:mdna:148]
We did not have any off-balance sheet arrangements as of September 30, 2024.
