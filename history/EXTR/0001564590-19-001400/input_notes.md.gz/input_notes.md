# EXTR notes — 0001564590-19-001400


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0001564590-19-001400:notes:1]
[same as prior period, unchanged from 0001564590-18-026529:notes:1]

[0001564590-19-001400:notes:2]
[same as prior period, unchanged from 0001564590-18-026529:notes:2]

[0001564590-19-001400:notes:3]
[same as prior period, unchanged from 0001564590-18-026529:notes:3]

[0001564590-19-001400:notes:4]
The unaudited condensed consolidated financial statements reflect all adjustments, consisting only of normal recurring adjustments that, in the opinion of management, are necessary for a fair presentation of the results of operations and cash flows for the interim periods presented and the financial condition of Extreme at December 31, 2018. The results of operations for the three and six months ended December 31, 2018 are not necessarily indicative of the results that may be expected for fiscal 2019 or any future periods.

[0001564590-19-001400:notes:5]
[same as prior period, unchanged from 0001564590-18-026529:notes:5]

[0001564590-19-001400:notes:6]
[same as prior period, unchanged from 0001564590-18-026529:notes:6]

[0001564590-19-001400:notes:7]
[same as prior period, unchanged from 0001564590-18-026529:notes:7]

[0001564590-19-001400:notes:8]
[same as prior period, unchanged from 0001564590-18-026529:notes:8]

[0001564590-19-001400:notes:9]
[same as prior period, unchanged from 0001564590-18-026529:notes:9]

[0001564590-19-001400:notes:10]
[same as prior period, unchanged from 0001564590-18-026529:notes:10]

[0001564590-19-001400:notes:11]
[same as prior period, unchanged from 0001564590-18-026529:notes:11]


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001564590-19-001400:notes:12]
| 2. | Summary of Significant Accounting Policies |

[0001564590-19-001400:notes:13]
[same as prior period, unchanged from 0001564590-18-026529:notes:32]

[0001564590-19-001400:notes:14]
Recently Adopted Accounting Pronouncements

[0001564590-19-001400:notes:15]
In January 2016, the Financial Accounting Standards Board (“FASB”) issued ASU No. 2016-01, Recognition and Measurement of Financial Assets and Financial Liabilities, which provides guidance for the recognition, measurement, presentation, and disclosure of financial assets and liabilities. The guidance was adopted effective July 1, 2018 and the Company reclassified a $0.5 million unrealized gain, net of tax, related to its available-for-sale investments from accumulated other comprehensive loss to accumulated deficit as a cumulative-effect adjustment in the accompanying condensed consolidated balance sheets.  Future changes in fair value will be included in earnings in each period.

[0001564590-19-001400:notes:16]
In August 2016, the FASB issued ASU 2016-15, Classification of Certain Cash Receipts and Cash Payments to provide guidance on the classification of eight cash flow issues in order to reduce diversity in practice.  The Company adopted the new guidance effective July 1, 2018. The amendments in this update have been applied on a retrospective transition method to each period presented. The adoption of this guidance did not have a material effect on the Company’s presentation of cash flows.

[0001564590-19-001400:notes:17]
In October 2016, the FASB issued ASU 2016-16, Income Taxes (Topic 740) - Intra-Entity Transfers of Assets Other Than Inventory, which requires an entity to recognize the income tax consequences of an intra-entity transfer of an asset other than inventory when the transfer occurs. Historically GAAP had prohibited the recognition of current and deferred income taxes for an intra-entity asset transfer until the asset has been sold outside the consolidated group.  The new guidance is effective for interim and annual reporting periods beginning after December 15, 2017. The Company adopted ASU 2016-16 effective July 1, 2018 on a modified retrospective basis. The adoption of this guidance did not have a material effect on the Company’s financial statements.

[0001564590-19-001400:notes:18]
In May 2017, the FASB issued ASU 2017-09, Compensation—Stock Compensation (Topic 718): Scope of Modification Accounting, which amends the scope of modification accounting for share-based payment arrangements and provides guidance on the types of changes to the terms or conditions of share-based payment awards to which an entity would be required to apply modification accounting under Topic 718.  Specifically, an entity would not apply modification accounting if the fair value, vesting conditions, and classification of the awards are the same immediately before and after the modification. The Company adopted this guidance effective July 1, 2018, on a prospective basis.  The adoption of this guidance did not have a material effect on the Company’s financial statements.

[0001564590-19-001400:notes:19]
Recently Issued Accounting Pronouncements

[0001564590-19-001400:notes:20]
In February 2016, the FASB issued ASU No. 2016-02, Leases (Topic 842), which requires the identification of arrangements that should be accounted for as leases by lessees. In general, for lease arrangements exceeding a twelve-month term, these arrangements must now be recognized as assets and liabilities on the balance sheet of the lessee. Under Topic 842, a right-of-use asset and lease obligation will be recorded for all leases, whether operating or financing, while the statement of operations will reflect lease expense for operating leases and amortization/interest expense for financing leases. The balance sheet amount recorded for existing leases at the date of adoption of Topic 842 must be calculated using the applicable incremental borrowing rate at the date of adoption. In addition, Topic 842 is applied on the modified retrospective method through a cumulative-effect adjustment directly to retained earnings as of the beginning of the period of adoption. The Company is currently assessing the impact that adopting this new accounting standard will have on its consolidated financial statements and footnote disclosures.  The Company believes that Topic 842 will have a material impact on its financial position, as a result of recognizing right-of-use assets and lease liabilities on its consolidated balance sheets. In addition, in December 2018, the FASB issued ASU No. 2018-20, Leases (Topic 842), which includes narrow-scope improvements for lessors to increase transparency and comparability about leasing transactions. The Company continues to evaluate the impact these new standards will have on its condensed consolidated statement of operations and statement of cash flows. This guidance will become effective for the Company beginning with its fiscal year 2020, beginning on July 1, 2019.

[0001564590-19-001400:notes:21]
In August 2017, the FASB issued ASU 2017-12, Derivatives and Hedging (Topic 815): Targeted Improvements to Accounting for Hedging Activities, which is intended to allow companies to better align risk management activities and financial reporting for hedging relationships through changes to both the designation and measurement guidance for qualifying hedging relationships and the presentation of hedge results by expanding and refining hedge accounting for both nonfinancial and financial risk components and aligning the recognition and presentation of the effects of the hedging instrument and the hedged item in the financial statements. In addition, in October 2018, the FASB issued ASU 2018-16, Derivatives and Hedging (Topic 815), which amends Topic 815 to add the overnight index swap (OIS) rate based on the secured overnight financing rate as a fifth U.S. benchmark interest rate. These standards are effective for interim and annual reporting periods beginning after December 15, 2018. The Company is continuing to evaluate the accounting, transition and disclosure requirements of these standards, but does not believe it will have a material impact on the Company’s financial statements upon adoption. This guidance is effective for the Company beginning with its fiscal year 2020, beginning on July 1, 2019.

[0001564590-19-001400:notes:22]
In February 2018, the FASB issued ASU 2018-02, Income Statement - Reporting Comprehensive Income (Topic 220), this standard that allows the reclassification from AOCI to retained earnings for stranded tax effects resulting from the 2017 Tax Cuts and Jobs Act ("Tax Reform Act"). The amount of the reclassification is the effect of the change in the U.S. federal corporate income tax rate on the gross deferred tax amounts and related valuation allowances related to items remaining in AOCI. This standard is effective for fiscal years beginning after December 15, 2018, and interim periods within those fiscal years. Early adoption is permitted, including adoption in any interim period, for reporting periods for which financial statements have not yet been issued. The new standard is to be applied either in the period of adoption or retrospectively to each period (or periods) in which the effects of the change in the income tax rate in the Tax Reform Act are recognized. Management is currently evaluating implementation options and impact on the Company's financial statements and related disclosures.  This guidance is effective for the Company beginning with its fiscal year 2020, beginning on July 1, 2019.

[0001564590-19-001400:notes:23]
In August 2018, the FASB issued ASU 2018-13, Fair Value Measurement (Topic 820), which removes, modifies and adds various disclosure requirements around the topic in order to clarify and improve the cost-benefit nature of disclosures. For example, disclosures around transfers between fair value hierarchy levels will be removed and further detail around changes in unrealized gains and losses for the period and unobservable inputs determining Level 3 fair value measurements will be added. This standard is effective for interim and annual reporting periods beginning after December 15, 2019, and early adoption is permitted. The Company is currently evaluating the impact the new standard will have on its condensed consolidated financial statements. This guidance is effective for the Company beginning with its fiscal year 2021, beginning on July 1, 2020.

[0001564590-19-001400:notes:24]
In August 2018, the FASB issued ASU 2018-15, Intangibles - Goodwill and Other - Internal-Use Software (Subtopic 350-40), which aligns the requirements for capitalizing implementation costs incurred in a service contract hosting arrangement with those of developing or obtaining internal-use software. This standard is effective for interim and annual reporting periods beginning after December 15, 2019, and early adoption is permitted. The Company is currently evaluating the impact the new standard will have on its condensed consolidated financial statements. This guidance is effective for the Company beginning with its fiscal year 2021, beginning on July 1, 2020.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001564590-19-001400:notes:25]
| 3. | Revenues |

[0001564590-19-001400:notes:26]
The Company accounts for revenue in accordance with ASC Topic 606, Revenue from Contracts with Customers, which the Company adopted on July 1, 2017, using the retrospective method.  The Company derives the majority of its revenue from sales of its networking equipment, with the remaining revenue generated from service fees primarily relating to maintenance contracts with additional revenues from professional services, and training for its products. The Company sells its products and maintenance contracts direct to customers and to partners in two distribution channels, or tiers. The first tier consists of a limited number of independent distributors that stock its products and sell primarily to resellers.  The second tier of the distribution channel consists of a non-stocking distributors and value-added resellers that sell directly to end-users.  Products and services may be sold separately or in bundled packages.

[0001564590-19-001400:notes:27]
[same as prior period, unchanged from 0001564590-18-026529:notes:46]

[0001564590-19-001400:notes:28]
Performance Obligations. A performance obligation is a promise in a contract to transfer a distinct good or service to the customer and is the unit of account in Topic 606. A contract’s transaction price is allocated to each distinct performance obligation and recognized as revenue when, or as, the performance obligation is satisfied.  Certain of the Company’s contracts have multiple performance obligations, as the promise to transfer individual goods or services is separately identifiable from other promises in the contracts and, therefore, is distinct.  For contracts with multiple performance obligations, the Company allocates the contract’s transaction price to each performance obligation based on its relative standalone selling price.  The stand-alone selling prices are determined based on the prices at which the Company separately sells these products.  For items that are not sold separately, the Company estimates the stand-alone selling prices using the best estimated selling price approach.

[0001564590-19-001400:notes:29]
The Company’s performance obligations are satisfied at a point in time or over time as work progresses.  Substantially all of the Company’s product sales revenues as reflected on the condensed consolidated statements of operations for the three and six months ended December 31, 2018 and 2017 are recognized at a point in time. Substantially all of the Company’s service revenue is recognized over time.  For revenue recognized over time, the Company uses an input measure, days elapsed, to measure progress.

[0001564590-19-001400:notes:30]
On December 31, 2018, the Company had $186.1 million of remaining performance obligations, which is comprised of deferred maintenance revenue and services not yet delivered.  The Company expects to recognize approximately 48 percent of its remaining performance obligations as revenue in fiscal 2019, an additional 35 percent in fiscal 2020 and 17 percent of the balance thereafter.

[0001564590-19-001400:notes:31]
[same as prior period, unchanged from 0001564590-18-026529:notes:50]

[0001564590-19-001400:notes:32]
Revenue recognized for the three months ended December 31, 2018 and 2017 that was included in the deferred revenue balance at the beginning of each period was $59.9 million and $36.9 million, respectively. Revenue recognized for the six months ended December 31, 2018 and 2017 that was included in the deferred revenue balance at the beginning of each period was $88.8 million and $52.9 million, respectively.

[0001564590-19-001400:notes:33]
Contract Costs. The Company recognizes the incremental costs of obtaining contracts as an expense when incurred if the amortization period of the assets that the Company otherwise would have recognized is one year or less.  Management expects that commission fees paid to sales representative as a result of obtaining service contracts and contract renewals are recoverable and therefore the Company’s capitalized balances in the amount of $5.3 million and $3.2 million at December 31, 2018 and 2017, respectively.  Capitalized commission fees are amortized on a straight-line basis over the average period of service contracts of approximately three years, and are included in “Sales and marketing” in the accompanying condensed consolidated statements of operations.  Amortization recognized during the three months ended December 31, 2018 and 2017, was $0.7 million and $0.5 million, respectively.  Amortization recognized during the six months ended December 31, 2018 and 2017 was $1.4 million and $0.9 million, respectively. There was no impairment loss in relation to the costs capitalized.

[0001564590-19-001400:notes:34]
[same as prior period, unchanged from 0001564590-18-026529:notes:53]

[0001564590-19-001400:notes:35]
[same as prior period, unchanged from 0001564590-18-026529:notes:54]

[0001564590-19-001400:notes:36]
[same as prior period, unchanged from 0001564590-18-026529:notes:55]

[0001564590-19-001400:notes:37]
|  |  | Three Months Ended |  |
|  |  | December 31, 2018 |  |  | December 31, 2017 |  |
|  |  | Distributor |  | Direct |  | Total |  |  | Distributor |  | Direct |  | Total |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  | $ | 44,141 |  | $ | 55,326 |  | $ | 99,467 |  |  | $ | 56,269 |  | $ | 54,559 |  | $ | 110,828 |  |
| Other |  |  | 8,269 |  |  | 5,380 |  |  | 13,649 |  |  |  | 1,155 |  |  | 5,698 |  |  | 6,853 |  |
| Total Americas |  |  | 52,410 |  |  | 60,706 |  |  | 113,116 |  |  |  | 57,424 |  |  | 60,257 |  |  | 117,681 |  |
| EMEA |  |  | 79,876 |  |  | 32,773 |  |  | 112,649 |  |  |  | 55,956 |  |  | 33,624 |  |  | 89,580 |  |
| APAC |  |  | 4,767 |  |  | 22,148 |  |  | 26,915 |  |  |  | 5,131 |  |  | 18,731 |  |  | 23,862 |  |
| Total net revenues |  | $ | 137,053 |  | $ | 115,627 |  | $ | 252,680 |  |  | $ | 118,511 |  | $ | 112,612 |  | $ | 231,123 |  |

[0001564590-19-001400:notes:38]
|  |  | Six Months Ended |  |
|  |  | December 31, 2018 |  |  | December 31, 2017 |  |
|  |  | Distributor |  | Direct |  | Total |  |  | Distributor |  | Direct |  | Total |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  | $ | 100,883 |  | $ | 115,262 |  | $ | 216,145 |  |  | $ | 98,661 |  | $ | 105,549 |  | $ | 204,210 |  |
| Other |  |  | 12,762 |  |  | 10,904 |  |  | 23,666 |  |  |  | 15,491 |  |  | 12,093 |  |  | 27,584 |  |
| Total Americas |  |  | 113,645 |  |  | 126,166 |  |  | 239,811 |  |  |  | 114,152 |  |  | 117,642 |  |  | 231,794 |  |
| EMEA |  |  | 141,207 |  |  | 63,611 |  |  | 204,818 |  |  |  | 107,188 |  |  | 61,527 |  |  | 168,715 |  |
| APAC: |  |  | 7,116 |  |  | 40,821 |  |  | 47,937 |  |  |  | 8,395 |  |  | 33,934 |  |  | 42,329 |  |
| Total net revenues |  | $ | 261,968 |  | $ | 230,598 |  | $ | 492,566 |  |  | $ | 229,735 |  | $ | 213,103 |  | $ | 442,838 |  |

[0001564590-19-001400:notes:39]
[same as prior period, unchanged from 0001564590-18-026529:notes:57]

[0001564590-19-001400:notes:40]
[same as prior period, unchanged from 0001564590-18-026529:notes:58]

[0001564590-19-001400:notes:41]
[same as prior period, unchanged from 0001564590-18-026529:notes:59]

[0001564590-19-001400:notes:42]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | December 31, 2018 |  |  | December 31, 2017 |  |  | December 31, 2018 |  |  | December 31, 2017 |  |
| Tech Data Corporation |  | 22% |  |  | 12% |  |  | 19% |  |  | 12% |  |
| Westcon Group Inc. |  | 15% |  |  | 14% |  |  | 14% |  |  | 15% |  |
| Jenne Corporation |  | 12% |  |  | * |  |  | 12% |  |  | 10% |  |

[0001564590-19-001400:notes:43]
[same as prior period, unchanged from 0001564590-18-026529:notes:61]

[0001564590-19-001400:notes:44]
|  |  | December 31, 2018 |  |  | June 30, 2018 |  |
| Westcon Group Inc. |  | 23% |  |  | * |  |
| Tech Data Corporation |  | 22% |  |  | 17% |  |
| Jenne Corporation |  | * |  |  | 13% |  |
| * Less than 10% of accounts receivable |  |  |  |  |  |  |  |  |


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001564590-19-001400:notes:45]
4. Business Combinations

[0001564590-19-001400:notes:46]
[same as prior period, unchanged from 0001564590-18-026529:notes:13]

[0001564590-19-001400:notes:47]
[same as prior period, unchanged from 0001564590-18-026529:notes:14]

[0001564590-19-001400:notes:48]
[same as prior period, unchanged from 0001564590-18-026529:notes:15]

[0001564590-19-001400:notes:49]
[same as prior period, unchanged from 0001564590-18-026529:notes:16]

[0001564590-19-001400:notes:50]
|  |  | Final Allocation |  |
| Accounts receivables |  | $ | 33,488 |  |
| Inventories |  |  | 19,934 |  |
| Prepaid expenses and other current assets |  |  | 988 |  |
| Property and equipment | (a) |  | 20,220 |  |
| Other assets |  |  | 4,734 |  |
| Accounts payable and accrued expenses |  |  | (16,494 | ) |
| Deferred revenue |  |  | (33,025 | ) |
| Net tangible assets acquired |  |  | 29,845 |  |
| Identifiable intangible assets |  |  | 32,800 |  |
| Goodwill | (a) |  | 21,692 |  |
| Total intangible assets acquired |  |  | 54,492 |  |
| Total net assets acquired |  | $ | 84,337 |  |

[0001564590-19-001400:notes:51]
|  | (a) | Includes an adjustment after the measurement period to record $1.3 million of additional property and equipment acquired at an international location. |

[0001564590-19-001400:notes:52]
[same as prior period, unchanged from 0001564590-18-026529:notes:18]

[0001564590-19-001400:notes:53]
[same as prior period, unchanged from 0001564590-18-026529:notes:19]

[0001564590-19-001400:notes:54]
[same as prior period, unchanged from 0001564590-18-026529:notes:20]

[0001564590-19-001400:notes:55]
[same as prior period, unchanged from 0001564590-18-026529:notes:21]

[0001564590-19-001400:notes:56]
[same as prior period, unchanged from 0001564590-18-026529:notes:22]

[0001564590-19-001400:notes:57]
[same as prior period, unchanged from 0001564590-18-026529:notes:23]

[0001564590-19-001400:notes:58]
[same as prior period, unchanged from 0001564590-18-026529:notes:24]

[0001564590-19-001400:notes:59]
[same as prior period, unchanged from 0001564590-18-026529:notes:25]

[0001564590-19-001400:notes:60]
[same as prior period, unchanged from 0001564590-18-026529:notes:26]

[0001564590-19-001400:notes:61]
The unaudited pro forma financial information for the three and six months ended December 31, 2017, combines the historical results for Extreme for those periods, which include the results of the Data Center Business and CF Business subsequent to the acquisition date, with their historical results up to the acquisition date.

[0001564590-19-001400:notes:62]
Pro forma results of operations from the Data Center Business, CF Business and Campus Fabric Business acquisitions included in the pro forma results of operations for the three and six months ended December 31, 2017, have not been adjusted for the adoption of Topic 606 because the Company determined it is impractical to estimate the impact of the adoption.

[0001564590-19-001400:notes:63]
[same as prior period, unchanged from 0001564590-18-026529:notes:29]

[0001564590-19-001400:notes:64]
|  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | December 31, 2017 |  |  | December 31, 2017 |  |
| Net revenues |  | $ | 252,532 |  |  | $ | 537,040 |  |
| Net income (loss) |  | $ | 1,152 |  |  | $ | (7,622 | ) |
| Net income (loss) per share - basic |  | $ | 0.01 |  |  | $ | (0.07 | ) |
| Net income (loss) per share - diluted |  | $ | 0.01 |  |  | $ | (0.07 | ) |
| Shares used in per share calculation - basic |  |  | 113,621 |  |  |  | 112,931 |  |
| Shares used in per share calculation - diluted |  |  | 119,656 |  |  |  | 112,931 |  |


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001564590-19-001400:notes:65]
[same as prior period, unchanged from 0001564590-18-026529:notes:63]

[0001564590-19-001400:notes:66]
Cash and Marketable Securities

[0001564590-19-001400:notes:67]
The following is a summary of cash and marketable securities (in thousands):

[0001564590-19-001400:notes:68]
|  |  | December 31, 2018 |  |  | June 30, 2018 |  |
| Cash |  | $ | 140,643 |  |  | $ | 121,139 |  |
| Marketable securities (consisting of available-for-sale securities) |  |  | 428 |  |  |  | 1,459 |  |
| Total cash and marketable securities |  | $ | 141,071 |  |  | $ | 122,598 |  |

[0001564590-19-001400:notes:69]
Marketable equity securities are recorded in “Prepaid expense and other current assets” in the accompanying condensed consolidated balance sheets as these securities are publicly-traded with readily determinable values. Marketable equity securities are classified as available-for-sale and reported at fair value with unrealized gains and losses included in “Other (expense) income, net” in the accompanying condensed consolidated statements of operations.

[0001564590-19-001400:notes:70]
[same as prior period, unchanged from 0001564590-18-026529:notes:68]

[0001564590-19-001400:notes:71]
The Company values its inventory at lower of cost or net realizable value. Cost is computed using standard cost, which approximates actual cost, on a first-in, first-out basis. The Company has established inventory allowances when conditions exist that suggest that inventory may be in excess of anticipated demand or is obsolete based upon assumptions about future demand. At the point of the loss recognition, a new, lower-cost basis for that inventory is established, and subsequent changes in facts and circumstances do not result in the restoration or increase in that newly established cost basis. Any written down or obsolete inventory subsequently sold has not had a material impact on gross margin for any of the periods presented.

[0001564590-19-001400:notes:72]
[same as prior period, unchanged from 0001564590-18-026529:notes:70]

[0001564590-19-001400:notes:73]
|  |  | December 31, 2018 |  |  | June 30, 2018 |  |
| Finished goods |  | $ | 44,179 |  |  | $ | 49,393 |  |
| Raw materials |  |  | 14,118 |  |  |  | 14,474 |  |
| Total Inventories |  | $ | 58,297 |  |  | $ | 63,867 |  |

[0001564590-19-001400:notes:74]
[same as prior period, unchanged from 0001564590-18-026529:notes:72]

[0001564590-19-001400:notes:75]
[same as prior period, unchanged from 0001564590-18-026529:notes:73]

[0001564590-19-001400:notes:76]
|  |  | December 31, 2018 |  |  | June 30, 2018 |  |
| Computers and equipment |  | $ | 70,121 |  |  | $ | 60,677 |  |
| Purchased software |  |  | 22,968 |  |  |  | 21,389 |  |
| Office equipment, furniture and fixtures |  |  | 11,564 |  |  |  | 14,980 |  |
| Leasehold improvements |  |  | 51,167 |  |  |  | 50,070 |  |
| Total property and equipment |  |  | 155,820 |  |  |  | 147,116 |  |
| Less: accumulated depreciation and amortization |  |  | (81,321 | ) |  |  | (68,597 | ) |
| Property and equipment, net |  | $ | 74,499 |  |  | $ | 78,519 |  |

[0001564590-19-001400:notes:77]
[same as prior period, unchanged from 0001564590-18-026529:notes:82]

[0001564590-19-001400:notes:78]
Deferred revenue represents amounts for (i) deferred maintenance and support revenue and (ii) other deferred revenue including professional services and training when the revenue recognition criteria have not been met.

[0001564590-19-001400:notes:79]
[same as prior period, unchanged from 0001564590-18-026529:notes:92]

[0001564590-19-001400:notes:80]
The Company’s standard hardware warranty period is typically 12 months from the date of shipment to end-users and 90 days for software. For certain products, the Company offers a limited lifetime hardware warranty commencing on the date of shipment from the Company and ending five (5) years following the Company’s announcement of the end of sale of such product. Upon shipment of products to its customers, the Company estimates expenses for the cost to repair or replace products that may be returned under warranty and accrue a liability in cost of product revenue for this amount. The determination of the Company’s warranty requirements is based on actual historical experience with the product or product family, estimates of repair and replacement costs and any product warranty problems that are identified after shipment.  The Company estimates and adjusts these accruals at each balance sheet date in accordance with changes in these factors.

[0001564590-19-001400:notes:81]
The following table summarizes the activity related to the Company’s product warranty liability during the three and six months ended December 31, 2018 and 2017 (in thousands):

[0001564590-19-001400:notes:82]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | December 31, 2018 |  |  | December 31, 2017 |  |  | December 31, 2018 |  |  | December 31, 2017 |  |
| Balance beginning of period |  | $ | 12,601 |  |  | $ | 13,499 |  |  | $ | 12,807 |  |  | $ | 10,584 |  |
| Warranties assumed due to acquisitions |  |  | — |  |  |  | 526 |  |  |  | — |  |  |  | 3,682 |  |
| New warranties issued |  |  | 4,145 |  |  |  | 1,657 |  |  |  | 7,867 |  |  |  | 3,929 |  |
| Warranty expenditures |  |  | (3,938 | ) |  |  | (2,672 | ) |  |  | (7,866 | ) |  |  | (5,185 | ) |
| Balance end of period |  | $ | 12,808 |  |  | $ | 13,010 |  |  | $ | 12,808 |  |  | $ | 13,010 |  |

[0001564590-19-001400:notes:83]
[same as prior period, unchanged from 0001564590-18-026529:notes:96]

[0001564590-19-001400:notes:84]
[same as prior period, unchanged from 0001564590-18-026529:notes:97]

[0001564590-19-001400:notes:85]
[same as prior period, unchanged from 0001564590-18-026529:notes:98]

[0001564590-19-001400:notes:86]
|  |  | December 31, 2018 |  |  | June 30, 2018 |  |
| Acquisition related deferred payments, less current portion |  | $ | 11,442 |  |  | $ | 13,251 |  |
| Contingent consideration obligations, less current portion |  |  | 4,095 |  |  |  | 4,898 |  |
| Other contractual obligations, less current portion |  |  | 29,647 |  |  |  | 31,200 |  |
| Other |  |  | 15,527 |  |  |  | 9,751 |  |
| Total other long-term liabilities |  | $ | 60,711 |  |  | $ | 59,100 |  |

[0001564590-19-001400:notes:87]
[same as prior period, unchanged from 0001564590-18-026529:notes:102]

[0001564590-19-001400:notes:88]
[same as prior period, unchanged from 0001564590-18-026529:notes:103]


## us-gaap:FairValueDisclosuresTextBlock

[0001564590-19-001400:notes:89]
[same as prior period, unchanged from 0001564590-18-026529:notes:104]

[0001564590-19-001400:notes:90]
[same as prior period, unchanged from 0001564590-18-026529:notes:105]

[0001564590-19-001400:notes:91]
[same as prior period, unchanged from 0001564590-18-026529:notes:106]

[0001564590-19-001400:notes:92]
[same as prior period, unchanged from 0001564590-18-026529:notes:107]

[0001564590-19-001400:notes:93]
[same as prior period, unchanged from 0001564590-18-026529:notes:108]

[0001564590-19-001400:notes:94]
The following table presents the Company’s fair value hierarchy for its financial assets and liabilities measured at fair value on a

[0001564590-19-001400:notes:95]
recurring basis (in thousands):

[0001564590-19-001400:notes:96]
| December 31, 2018 |  | Level 1 |  |  | Level 2 |  |  | Level 3 |  |  | Total |  |
| Assets |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Investments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Marketable securities |  | $ | 428 |  |  | $ | — |  |  | $ | — |  |  | $ | 428 |  |
| Total assets measured at fair value |  | $ | 428 |  |  | $ | — |  |  | $ | — |  |  | $ | 428 |  |
| Liabilities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Acquisition-related contingent consideration obligations |  | $ | — |  |  | $ | — |  |  | $ | 8,649 |  |  | $ | 8,649 |  |
| Total liabilities measured at fair value |  | $ | — |  |  | $ | — |  |  | $ | 8,649 |  |  | $ | 8,649 |  |

[0001564590-19-001400:notes:97]
[same as prior period, unchanged from 0001564590-18-026529:notes:111]

[0001564590-19-001400:notes:98]
[same as prior period, unchanged from 0001564590-18-026529:notes:112]

[0001564590-19-001400:notes:99]
The Company holds an investment in marketable equity securities which is classified as available-for-sale marketable securities at Level 1 as the investments have readily determinable fair value (see below, Level 3 investments). An unrealized holding gain on the investments of $0.5 million as of June 30, 2018 was reclassified from accumulated other comprehensive loss to accumulated deficit on July 1, 2018 upon the adoption of ASU 2016-01 (see Note 3)..

[0001564590-19-001400:notes:100]
[same as prior period, unchanged from 0001564590-18-026529:notes:114]

[0001564590-19-001400:notes:101]
[same as prior period, unchanged from 0001564590-18-026529:notes:115]

[0001564590-19-001400:notes:102]
The fair value of the borrowings under the Credit Agreement is estimated based on valuations provided by alternative pricing sources supported by observable inputs which is considered Level 2.  Due to the short duration until maturity of the Credit Agreement, the fair value approximates the face amount of the Company’s indebtedness of $185.3 million and $200.0 million as of December 31, 2018 and June 30, 2018, respectively.

[0001564590-19-001400:notes:103]
[same as prior period, unchanged from 0001564590-18-026529:notes:117]

[0001564590-19-001400:notes:104]
[same as prior period, unchanged from 0001564590-18-026529:notes:118]

[0001564590-19-001400:notes:105]
At June 30, 2018, the Company reflected a liability for contingent consideration related to a certain acquisition completed in fiscal 2018. The fair value measurement of the contingent consideration obligation is determined using Level 3 inputs. These fair value measurements represent Level 3 measurements as they are based on significant inputs not observable in the market. Significant judgment is employed in determining the appropriateness of these assumptions as of the acquisition date and for each subsequent period.  Accordingly, changes in assumptions could have a material impact on the amount of contingent consideration expense the Company records in any given period.  Changes in the value of the contingent consideration obligations would be recorded in general and administrative expenses in the accompanying condensed consolidated statements of operations.

[0001564590-19-001400:notes:106]
[same as prior period, unchanged from 0001564590-18-026529:notes:120]

[0001564590-19-001400:notes:107]
|  |  | Six Months Ended |  |
|  |  | December 31, 2018 |  |
| Beginning balance |  | $ | 12,749 |  |
| Payments |  |  | (4,222 | ) |
| Accretion on discount |  |  | 122 |  |
| Ending balance |  | $ | 8,649 |  |

[0001564590-19-001400:notes:108]
There were no transfers of assets or liabilities between Level 2 and Level 3 during the three and six months ended December 31, 2018 or 2017. There were no impairments recorded for the three and six months ended December 31, 2018 or 2017.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001564590-19-001400:notes:109]
7.Goodwill and Intangible Assets

[0001564590-19-001400:notes:110]
The following table reflects the changes in the carrying amount of goodwill (in thousands):

[0001564590-19-001400:notes:111]
|  |  | December 31, 2018 |  |
| Balance as of June 30, 2018 |  | $ | 139,082 |  |
| Changes due to additional property and equipment acquired (See Note 4) |  |  | (1,283 | ) |
| Balance at end of period |  | $ | 137,799 |  |

[0001564590-19-001400:notes:112]
The following tables summarize the components of gross and net intangible asset balances (dollars in thousands):

[0001564590-19-001400:notes:113]
|  |  | Weighted Average |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Remaining Amortization |  | Gross Carrying |  |  | Accumulated |  |  | Net Carrying |  |
|  |  | Period |  | Amount |  |  | Amortization |  |  | Amount |  |
| December 31, 2018 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Developed technology |  | 2.8 years |  | $ | 117,000 |  |  | $ | 67,888 |  |  | $ | 49,112 |  |
| Customer relationships |  | 2.5 years |  |  | 51,639 |  |  |  | 42,522 |  |  |  | 9,117 |  |
| Maintenance contracts |  | 0.1 years |  |  | 17,000 |  |  |  | 17,000 |  |  |  | - |  |
| Trade names |  | 2.9 years |  |  | 9,100 |  |  |  | 4,871 |  |  |  | 4,229 |  |
| License agreements |  | 5.6 years |  |  | 2,232 |  |  |  | 1,313 |  |  |  | 919 |  |
| Other intangibles |  | 1.1 years |  |  | 1,382 |  |  |  | 1,215 |  |  |  | 167 |  |
| Total intangibles, net |  |  |  | $ | 198,353 |  |  | $ | 134,809 |  |  | $ | 63,544 |  |

[0001564590-19-001400:notes:114]
|  |  | Weighted Average |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Remaining Amortization |  | Gross Carrying |  |  | Accumulated |  |  | Net Carrying |  |
|  |  | Period |  | Amount |  |  | Amortization |  |  | Amount |  |
| June 30, 2018 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Developed technology |  | 3.3 years |  | $ | 117,000 |  |  | $ | 58,299 |  |  | $ | 58,701 |  |
| Customer relationships |  | 3.0 years |  |  | 51,639 |  |  |  | 40,634 |  |  |  | 11,005 |  |
| Maintenance contracts |  | 0.3 years |  |  | 17,000 |  |  |  | 15,866 |  |  |  | 1,134 |  |
| Trade names |  | 3.4 years |  |  | 9,100 |  |  |  | 4,141 |  |  |  | 4,959 |  |
| Backlogs |  | — years |  |  | 1,800 |  |  |  | 1,800 |  |  |  | — |  |
| License agreements |  | 5.8 years |  |  | 2,445 |  |  |  | 1,390 |  |  |  | 1,055 |  |
| Other intangibles |  | 1.6 years |  |  | 1,382 |  |  |  | 1,144 |  |  |  | 238 |  |
| Total intangibles, net |  |  |  | $ | 200,366 |  |  | $ | 123,274 |  |  | $ | 77,092 |  |

[0001564590-19-001400:notes:115]
The amortization expense of intangibles for the periods presented is summarized below (in thousands):

[0001564590-19-001400:notes:116]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | December 31, 2018 |  |  | December 31, 2017 |  |  | December 31, 2018 |  |  | December 31, 2017 |  |
| Amortization in “Cost of revenues: Product” |  | $ | 4,904 |  |  | $ | 3,866 |  |  | $ | 9,836 |  |  | $ | 6,663 |  |
| Amortization of intangibles in "Operations" |  |  | 1,575 |  |  |  | 2,746 |  |  |  | 3,716 |  |  |  | 4,360 |  |
| Total amortization |  | $ | 6,479 |  |  | $ | 6,612 |  |  | $ | 13,552 |  |  | $ | 11,023 |  |

[0001564590-19-001400:notes:117]
The amortization expense that is recognized in “Cost of revenues: Product” is comprised of amortization for developed technology, license agreements and other intangibles.


## us-gaap:DebtDisclosureTextBlock

[0001564590-19-001400:notes:118]
8.Debt

[0001564590-19-001400:notes:119]
The Company’s debt is comprised of the following (in thousands):

[0001564590-19-001400:notes:120]
|  |  | December 31, 2018 |  |  | June 30, 2018 |  |
| Current portion of long-term debt: |  |  |  |  |  |  |  |  |
| Term Loan |  | $ | 9,500 |  |  | $ | 9,500 |  |
| Less: unamortized debt issuance costs |  |  | (491 | ) |  |  | (493 | ) |
| Current portion of long-term debt |  | $ | 9,009 |  |  | $ | 9,007 |  |
| Long-term debt, less current portion: |  |  |  |  |  |  |  |  |
| Term Loan |  | $ | 175,750 |  |  | $ | 180,500 |  |
| Revolving Facility |  |  | — |  |  |  | 10,000 |  |
| Less: unamortized debt issuance costs |  |  | (1,504 | ) |  |  | (1,751 | ) |
| Total long-term debt, less current portion |  |  | 174,246 |  |  |  | 188,749 |  |
| Total debt |  | $ | 183,255 |  |  | $ | 197,756 |  |

[0001564590-19-001400:notes:121]
On May 1, 2018, the Company entered into a Credit Agreement (the “Credit Agreement”), by and among the Company, as borrower, BMO Harris Bank N.A., as an issuing lender and swingline lender, Bank of Montreal, as administrative and collateral agent, and the financial institutions or entities that are a party thereto as lenders.  The Credit Agreement provides for i) a $40 million five-year revolving credit facility (the “New Revolving Facility”) ii) a $190 million five-year term loan (the “New Term Loan”) and iii) an uncommitted additional incremental loan facility in the principal amount of up to $100 million (“New Incremental Facility”).  On May 1, 2018, the Company borrowed $200 million under the Credit Agreement to pay off existing debt and for general corporate purposes.

[0001564590-19-001400:notes:122]
Borrowings under the Credit Agreement will bear interest, at the Company’s election, as of May 1, 2018, at a rate per annum equal to LIBOR plus 1.50% to 2.75%, or the adjusted base rate plus 0.50% to 1.75%, based on the Company’s consolidated leverage ratio.  In addition, the Company is required to pay a commitment fee of between 0.25% and 0.40% quarterly (currently 0.35%) on the unused portion of the New Revolving Facility, also based on the Company’s consolidated leverage ratio.  Principal installments are payable on the New Term Loan in varying percentages quarterly starting September 30, 2018 and to the extent not previously paid, all outstanding balances are to be paid at maturity.  The Credit Agreement is secured by substantially all of the Company’s assets.

[0001564590-19-001400:notes:123]
The Credit Agreement requires the Company to maintain certain minimum financial ratios at the end of each fiscal quarter. The Credit Agreement also includes covenants and restrictions that limit, among other things, the Company’s ability to incur additional indebtedness, create liens upon any of its property, merge, consolidate or sell all or substantially all of its assets. The Credit Agreement also includes customary events of default which may result in acceleration of the outstanding balance.

[0001564590-19-001400:notes:124]
Financing costs incurred in connection with obtaining long-term financing are deferred and amortized over the term of the Credit Agreement.  Amortization of deferred financing costs included in “Interest expense” in the accompanying condensed consolidated statements of operations totaled $0.2 million for each of the three months ended December 31, 2018 and 2017 and totaled $0.3 million for each of the six months ended December 31, 2018 and 2017, respectively.

[0001564590-19-001400:notes:125]
The Company had $39.0 million of availability under the New Revolving Facility as of December 31, 2018.  The Company had $1.0 million of outstanding letters of credit as of December 31, 2018.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001564590-19-001400:notes:126]
9.Commitments and Contingencies

[0001564590-19-001400:notes:127]
Purchase Commitments

[0001564590-19-001400:notes:128]
The Company currently has arrangements with contract manufacturers and suppliers for the manufacture of its products. Those arrangements allow the contract manufactures to procure long lead-time component inventory based upon a rolling production forecast provided by the Company. The Company is obligated to purchase long lead-time component inventory that its contract manufacturer procures in accordance with the Company’s forecast, unless the Company gives notice of order cancellation outside of applicable component lead-times. As of December 31, 2018, the Company had commitments to purchase $172.6 million of such inventory.  As of December 31, 2018, the Company had commitments to purchase $111.6 million of software and new product support services.

[0001564590-19-001400:notes:129]
Legal Proceedings

[0001564590-19-001400:notes:130]
The Company may from time to time be party to litigation arising in the course of its business, including, without limitation, allegations relating to commercial transactions, business relationships or intellectual property rights. Such claims, even if not meritorious, could result in the expenditure of significant financial and managerial resources. Litigation in general, and intellectual property and securities litigation in particular, can be expensive and disruptive to normal business operations. Moreover, the results of legal proceedings are difficult to predict.

[0001564590-19-001400:notes:131]
In accordance with applicable accounting guidance, the Company records accruals for certain of its outstanding legal proceedings, investigations or claims when it is probable that a liability will be incurred and the amount of loss can be reasonably estimated.  The Company evaluates, at least on a quarterly basis, developments in legal proceedings, investigations or claims that could affect the amount of any accrual, as well as any developments that would result in a loss contingency to become both probable and reasonably estimable.  When a loss contingency is not both probable and reasonably estimable, the Company does not record a loss accrual.  However, if the loss (or an additional loss in excess of any prior accrual) is at least a reasonable possibility and material, then the Company would disclose an estimate of the possible loss or range of loss, if such estimate can be made, or disclose that an estimate cannot be made.  The assessment whether a loss is probable or a reasonable possibility, and whether the loss or a range of loss is estimable, involves a series of complex judgments about future events.  Even if a loss is reasonably possible, the Company may not be able to estimate a range of possible loss, particularly where (i) the damages sought are substantial or indeterminate, (ii) the proceedings are in the early stages, or (iii) the matters involve novel or unsettled legal theories or a large number of parties. In such cases, there is considerable uncertainty regarding the ultimate resolution of such matters, including the amount of any possible loss, fine or penalty.  Accordingly, for current proceedings, except as noted below, the Company is currently unable to estimate any reasonably possible loss or range of possible loss.  However, an adverse resolution of one or more of such matters could have a material adverse effect on the Company's results of operations in a particular quarter or fiscal year.

[0001564590-19-001400:notes:132]
Brazilian Tax Assessment Matter

[0001564590-19-001400:notes:133]
On May 28, 2007, the Public Treasury Department of the State of Sao Paolo, Brazil (the “Tax Authority”) assessed the Company’s Brazilian subsidiary, Enterasys Networks do Brasil Ltda. (“Enterasys Brasil”), based on an alleged underpayment of taxes.  The Tax Authority also charged interest and penalties with respect to the assessment (collectively, the “ICMS Tax Assessment”).  The Tax Authority denied Enterasys Brasil the use of certain presumed tax credits granted by the State of Espirito Santo, Brazil under the terms of the FUNDAP program for the period from February 2003 to December 2004.  The value of the disallowed presumed tax credits is BRL 3.4 million (USD $0.8 million), excluding interest and penalties. All currency conversions in this Legal Proceedings section are as of December 31, 2018.

[0001564590-19-001400:notes:134]
Unable to resolve the matter at the administrative level, on October 1, 2014, Enterasys Brasil filed a lawsuit in the 11th Public Treasury Court of the Sao Paolo State Court of Justice (Judiciary District of Sao Paolo) to overturn or reduce the ICMS Tax Assessment. As part of this lawsuit, Enterasys Brasil requested a stay of execution, so that no tax foreclosure could be filed and no guarantee would be required until the court issued its final ruling.  On or about October 6, 2014, the court granted a preliminary injunction staying any execution on the assessment, but requiring that Enterasys Brasil deposit the assessed amount with the court.  Enterasys Brasil appealed this ruling and, on or about January 28, 2015, the appellate court ruled that no cash deposit (or guarantee) was required.  In a decision dated August 28, 2017, and published on October 3, 2017, the court validated the assessment and penalty imposed by the Tax Authority but ruled that the Tax Authority was charging an unlawfully high interest rate on the tax assessment and penalty amounts and ordered the interest rate reduced to the maximum Federal rate. The August 28, 2017 decision, were it to become final, would require Enterasys Brasil to pay a total of BRL 19.6 million (USD $4.8 million), which includes penalties, court costs, attorneys’ fees, and accrued interest as of December 31, 2018.  The Company believes the ICMS Tax Assessment against Enterasys Brasil is without merit and has appealed the lower court’s decision.  The appellate court ruled that no cash deposit (or guarantee) is required during the pendency of the appeal.

[0001564590-19-001400:notes:135]
Based on the currently available information, the Company believes the ultimate outcome of the ICMS Tax Assessment litigation will not have a material adverse effect on the Company's financial position or overall results of operations. However, due to the complexities and uncertainty surrounding the judicial process in Brazil and the nature of the claims asserted, there can be no assurance of a favorable outcome for Enterasys Brasil, which recorded an accrual of BRL 9.4 million (USD $2.3 million) as of the date the Company acquired Enterasys Networks.

[0001564590-19-001400:notes:136]
The Company made a demand on April 11, 2014 for a defense from, and indemnification by, the former equity holder of Enterasys Networks, Inc. (“Seller”) in connection with the ICMS Tax Assessment. Seller agreed to assume the defense of the ICMS Tax Assessment on May 20, 2014. In addition, through the settlement of an indemnification-related lawsuit with the Seller on June 18, 2015, Seller agreed to continue to defend the Company with respect to the ICMS Tax Assessment and to indemnify the Company for losses related thereto subject to certain conditions. These conditions include the offsetting of foreign income tax benefits realized by the Company in connection with the acquisition of Enterasys.  Based upon current projections of the foreign income tax benefits to be realized, and the potential liability in the event of an adverse final judgment in the ICMS Tax Assessment litigation, the Company does not presently anticipate that any amounts under the indemnification will be due from the Seller in connection with the ICMS Tax Assessment.

[0001564590-19-001400:notes:137]
In re Extreme Networks, Inc. Securities Litigation

[0001564590-19-001400:notes:138]
On October 23 and 29, 2015, punitive class action complaints alleging violations of securities laws were filed in the U.S. District Court for the Northern District of California against the Company and three of its former officers (Charles W. Berger, Kenneth B. Arola, and John T. Kurtzweil).  Subsequently, the cases were consolidated (In re Extreme Networks, Inc. Securities Litigation, No. 3:15-CY-04883-BLF).  Plaintiffs allege that defendants violated the securities laws by disseminating materially false and misleading statements and concealing material adverse facts regarding the Company’s financial condition, business operations and growth prospects. Plaintiffs seek unspecified damages on behalf of a purported class of investors who purchased the Company’s common stock from September 12, 2013 through April 9, 2015.  On June 28, 2016, the Court appointed a lead plaintiff.  On September 26, 2016, the lead plaintiff filed a consolidated complaint. On November 10, 2016, defendants filed a motion to dismiss, which the Court granted with leave to amend on April 27, 2017.  On June 2, 2017, the lead plaintiff filed an amended complaint, which, on July 10, 2017, defendants again moved to dismiss.  In a March 21, 2018 Order (the “March 2018 Order”), the Court granted in part and denied in part the defendants’ motion. The March 2018 Order narrowed the scope of the case, but allowed certain claims to proceed.  The parties have agreed to settle the litigation.   On November 30, 2018, plaintiffs filed an unopposed motion for preliminary approval of the settlement, and on December 6, 2018, Extreme filed a statement of non-opposition.  The motion presently is set for hearing on April 25, 2019

[0001564590-19-001400:notes:139]
On February 18, 2016, a shareholder derivative case was filed in the Superior Court of California, Santa Clara County (Shaffer v. Kispert et al., No. 16 CV 291726).  The complaint names current and former officers and directors as defendants, and seeks recovery on behalf of the Company based on substantially the same allegations as the securities class action litigation described above.  As a result of the March 2018 Order, the stipulated stay of the derivative litigation ended.  The parties have agreed to settle the litigation.  On November 26, 2018, plaintiff filed an unopposed motion for preliminary approval of the settlement, and on December 6, 2018, Extreme filed a statement of non-opposition. On January 18, 2019 the Court entered an order granting preliminary approval of the settlement and approving the notice to shareholders. The Court set the final approval hearing for May 3, 2019.

[0001564590-19-001400:notes:140]
XR Communications, LLC d/b/a Vivato Technologies v. Extreme Networks, Inc. Patent Infringement Suit

[0001564590-19-001400:notes:141]
On April 19, 2017, XR Communications, LLC (“XR”) (d/b/a Vivato Technologies) filed a patent infringement lawsuit against the Company in the Central District of California (XR Communications, LLC, dba Vivato Technologies v. Extreme Networks, Inc., No. 2:17-cv-2953-AG).  The operative Second Amended Complaint asserts infringement of U.S. Patent Nos. 7,062,296, 7,729,728, and 6,611,231 based on the Company’s manufacture, use, sale, offer for sale, and/or importation into the United States of certain access points and routers supporting multi-user, multiple-input, multiple-output technology. XR seeks unspecified damages, on-going royalties, pre- and post-judgment interest, and attorneys’ fees (but no injunction).  In orders dated April 10 and May 22, 2018, the Court stayed the case pending a resolution by the Patent Trial and Appeal Board (“PTAB”) of inter partes review (IPR) petitions filed by several defendants in other XR-related patent lawsuits challenging the validity of the asserted patents.  The PTAB has now instituted IPR proceedings as to all three patents and all patent claims asserted in the litigation. Given the stay, the Court took off calendar all previously scheduled events (including a Markman hearing and potential trial date). During a status conference on October 22, 2018, the Court continued the stay and set a status conference for February 11, 2019. The Company believes the claims are without merit and intends to defend them vigorously.

[0001564590-19-001400:notes:142]
Orckit IP, LLC v. Extreme Networks, Inc., Extreme Networks Ireland Ltd., and Extreme Networks GmbH

[0001564590-19-001400:notes:143]
On February 1, 2018, Orckit IP, LLC (“Orckit”) filed a patent infringement lawsuit against the Company and its Irish and German subsidiaries in the District Court in Dusseldorf, Germany.  The lawsuit alleges direct and indirect infringement of the German portion of European Patent EP 1 958 364 B1 based on the offer, distribution, use, possession and/or importation into Germany of certain network switches equipped with the ExtremeXOS operating system.  Orckit is seeking injunctive relief, an accounting, and an unspecified declaration of liability for damages and costs of the lawsuit.  On May 3, 2018, Extreme Networks GmbH filed a separate nullity action in the Federal Patent Court in Munich, seeking to invalidate the asserted patents, and on May 4, 2018, the defendants answered the complaint, denying any infringement and seeking a stay of the action pending the conclusion of the nullity action.  The Company believes the claims are without merit and intends to defend them vigorously.

[0001564590-19-001400:notes:144]
Indemnification Obligations

[0001564590-19-001400:notes:145]
Subject to certain limitations, the Company may be obligated to indemnify its current and former directors, officers and employees. These obligations arise under the terms of its certificate of incorporation, its bylaws, applicable contracts, and applicable law. The obligation to indemnify, where applicable, generally means that the Company is required to pay or reimburse, and in certain circumstances the Company has paid or reimbursed, the individuals' reasonable legal expenses and possibly damages and other liabilities incurred in connection with certain legal matters. For example, the Company currently is paying or reimbursing legal expenses being incurred by certain current and former officers and directors in connection with the shareholder litigation described above.  The Company also procures Directors and Officers insurance to help cover its defense and/or indemnification costs, although its ability to recover such costs through insurance is uncertain.  While it is not possible to estimate the maximum potential amount that could be owed under these indemnification agreements due to the Company’s limited history with prior indemnification claims, indemnification (including defense) costs could, in the future, have a material adverse effect on the Company’s consolidated financial position, results of operations and cash flows. As of December 31, 2018, the Company has the outstanding indemnification claims described above.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001564590-19-001400:notes:146]
10.Stockholders’ Equity

[0001564590-19-001400:notes:147]
Stockholders’ Rights Agreement

[0001564590-19-001400:notes:148]
On April 26, 2012, the Company entered into an Amended and Restated Rights Agreement between the Company and Computershare Shareholder Services LLC as the rights agent (the “Restated Rights Plan”). The Restated Rights Plan governs the terms of each right (“Right”) that has been issued with respect to each share of common stock of Extreme Networks. Each Right initially represents the right to purchase one one-thousandth of a share of the Company’s Preferred Stock. The Restated Rights Plan replaces in its entirety the Rights Agreement, dated as of April 27, 2001, as subsequently amended, between the Company and Mellon Investor Services LLC (the “Prior Rights Plan”).

[0001564590-19-001400:notes:149]
The Company’s Board of Directors (“the Board”) adopted the Restated Rights Plan to preserve the value of deferred tax assets, including net operating loss carry forwards of the Company, with respect to its ability to fully use its tax benefits to offset future income which may be limited if the Company experiences an “ownership change” for purposes of Section 382 of the Internal Revenue Code of 1986 as a result of ordinary buying and selling of its common stock. Following its review of the terms of the plan, the Board decided it was necessary and in the best interests of the Company and its stockholders to enter into the Restated Rights Plan. The Restated Rights Plan incorporates the Prior Rights Plan and the amendments thereto into a single agreement and extended the term of the Prior Rights Plan to April 30, 2013.  Each year since 2013 the Board and stockholders have approved an amendment providing for a one-year extension of the term of the Restated Rights Plan.  The Board unanimously approved an amendment to the Restated Rights Plan on May 9, 2018 to extend the Restated Rights Plan through May 31, 2019 which was ratified by the stockholders of the Company at the Company’s annual shareholders meeting held on November 8, 2018.

[0001564590-19-001400:notes:150]
Employee Stock Purchase Plan

[0001564590-19-001400:notes:151]
Our Board of Directors unanimously approved an amendment to the 2014 Employee Stock Purchase Plan to increase the maximum number of shares that will be available for sale thereunder by 7,500,000 shares which was ratified by the stockholders of the Company at the annual meeting of stockholders held on November 8, 2018.

[0001564590-19-001400:notes:152]
Common Stock Repurchases

[0001564590-19-001400:notes:153]
On November 2, 2018, the Company announced that the Board had authorized management to repurchase up to $60.0 million of the Company’s common stock for two years from the date of authorization. Purchases may be made from time to time in the open market or in privately negotiated transactions.  A maximum of $35.0 million of the Company’s common stock may be repurchased in any calendar year.

[0001564590-19-001400:notes:154]
The following table summarizes the Company's shares repurchases under its stock repurchase program (in thousands, except per share amounts):

[0001564590-19-001400:notes:155]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | December 31, 2018 |  |  | December 31, 2018 |  |
| Total number of shares repurchased |  |  | 2,366 |  |  |  | 2,366 |  |
| Average price paid per share |  | $ | 6.34 |  |  | $ | 6.34 |  |
| Dollar value of shares repurchased |  | $ | 15,000 |  |  | $ | 15,000 |  |
| Dollar value of shares that may yet be repurchased under program |  | $ | 45,000 |  |  | $ | 45,000 |  |


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001564590-19-001400:notes:156]
11.Employee Benefit Plans

[0001564590-19-001400:notes:157]
[same as prior period, unchanged from 0001564590-18-026529:notes:124]

[0001564590-19-001400:notes:158]
[same as prior period, unchanged from 0001564590-18-026529:notes:125]

[0001564590-19-001400:notes:159]
|  |  | December 31, 2018 |  |  | June 30, 2018 |  |
| 2013 Equity Incentive Plan shares available for grant |  |  | 7,558 |  |  |  | 9,957 |  |
| Employee stock options and awards outstanding |  |  | 11,577 |  |  |  | 12,060 |  |
| 2014 Employee Stock Purchase Plan |  |  | 4,084 |  |  |  | 5,365 |  |
| Total shares reserved for issuance |  |  | 23,219 |  |  |  | 27,382 |  |

[0001564590-19-001400:notes:160]
[same as prior period, unchanged from 0001564590-18-026529:notes:127]

[0001564590-19-001400:notes:161]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | December 31, 2018 |  |  | December 31, 2017 |  |  | December 31, 2018 |  |  | December 31, 2017 |  |
| Cost of product revenue |  | $ | 217 |  |  | $ | 134 |  |  | $ | 395 |  |  | $ | 226 |  |
| Cost of service revenue |  |  | 677 |  |  |  | 296 |  |  |  | 1,022 |  |  |  | 429 |  |
| Research and development |  |  | 2,797 |  |  |  | 1,829 |  |  |  | 5,139 |  |  |  | 2,880 |  |
| Sales and marketing |  |  | 2,983 |  |  |  | 2,699 |  |  |  | 5,342 |  |  |  | 4,342 |  |
| General and administrative |  |  | 2,026 |  |  |  | 2,067 |  |  |  | 3,627 |  |  |  | 3,951 |  |
| Total share-based compensation expense |  | $ | 8,700 |  |  | $ | 7,025 |  |  | $ | 15,525 |  |  | $ | 11,828 |  |

[0001564590-19-001400:notes:162]
During the three and six months ended December 31, 2018 or 2017, the Company did not capitalize any share-based compensation expense in inventory, as the amounts were immaterial.

[0001564590-19-001400:notes:163]
[same as prior period, unchanged from 0001564590-18-026529:notes:130]

[0001564590-19-001400:notes:164]
Stock awards may be granted under the 2013 Equity Incentive Plan (the “2013 Plan”) on terms approved by the Compensation Committee of the Board. Stock awards generally provide for the issuance of restricted stock units (“RSUs”) including performance or market-based RSUs which vest over a fixed period of time or based upon the satisfaction of certain performance criteria.  The Company uses the straight-line method for expense attribution, and beginning with fiscal 2017, the Company does not estimate forfeitures, but accounts for them as incurred.

[0001564590-19-001400:notes:165]
The following table summarizes stock award activity for the six months ended December 31, 2018 (in thousands, except grant date fair value):

[0001564590-19-001400:notes:166]
|  |  | Number of Shares |  |  | Weighted- Average Grant Date Fair Value |  |  | Aggregate Fair Market Value |  |
| Non-vested stock awards outstanding at June 30, 2018 |  |  | 7,764 |  |  | $ | 8.60 |  |  | $ | 61,804 |  |
| Granted |  |  | 4,042 |  |  |  | 6.40 |  |  |  |  |  |
| Released |  |  | (2,271 | ) |  |  | 7.75 |  |  |  |  |  |
| Cancelled |  |  | (738 | ) |  |  | 8.66 |  |  |  |  |  |
| Non-vested stock awards outstanding at December 31, 2018 |  |  | 8,797 |  |  | $ | 7.80 |  |  | $ | 53,661 |  |

[0001564590-19-001400:notes:167]
The following table summarizes stock option activity for the six months ended December 31, 2018 (in thousands, except per share and contractual term):

[0001564590-19-001400:notes:168]
|  |  | Number of Shares |  |  | Weighted-Average Exercise Price Per Share |  |  | Weighted-Average Remaining Contractual Term (years) |  |  | Aggregate Intrinsic Value |  |
| Options outstanding at June 30, 2018 |  |  | 2,193 |  |  | $ | 3.88 |  |  |  | 2.90 |  |  | $ | 8,996 |  |
| Granted |  |  | 852 |  |  |  | 6.40 |  |  |  |  |  |  |  |  |  |
| Exercised |  |  | (178 | ) |  |  | 3.56 |  |  |  |  |  |  |  |  |  |
| Cancelled |  |  | (87 | ) |  |  | 6.01 |  |  |  |  |  |  |  |  |  |
| Options outstanding at December 31, 2018 |  |  | 2,780 |  |  | $ | 4.60 |  |  |  | 3.70 |  |  | $ | 4,414 |  |
| Vested and expected to vest at December 31, 2018 |  |  | 2,780 |  |  | $ | 4.60 |  |  |  | 3.70 |  |  | $ | 4,414 |  |
| Exercisable at December 31, 2018 |  |  | 1,962 |  |  | $ | 3.94 |  |  |  | 2.53 |  |  | $ | 4,234 |  |

[0001564590-19-001400:notes:169]
[same as prior period, unchanged from 0001564590-18-026529:notes:136]

[0001564590-19-001400:notes:170]
The fair value of each RSU grant with performance-based vesting criteria (“PSUs”) under the 2013 Plan is estimated on the date of grant using the Monte-Carlo simulation model to determine the fair value and the derived service period of stock awards with market conditions, on the date of the grant.

[0001564590-19-001400:notes:171]
During the second quarter of fiscal 2019, the Company approved the grant of 705,009 stock awards, including 357,142 stock awards to its Chief Financial Officer, and 347,867 stock awards to its other employees. During the first quarter of fiscal 2019, the Company approved the grant of 1,269,800 stock awards to its vice president level employees or above (“VPs”), which includes 278,000 stock awards to its Executive Officers. The Company also approved 2,067,074 stock awards to its other employees.  Fifty percent (50%) of the stock awards granted to the VPs and the chief executive officer, were in the form of PSUs, with grant date fair values of $6.40, and fifty percent (50%) of the stock awards granted were in the form of service-based RSUs.  The RSUs vest from the original grant date as to one-third (1/3) on the one-year anniversary and one-twelfth (1/12) each quarter thereafter, subject to continued service to the Company. No PSUs were granted during the second quarter of fiscal 2018.

[0001564590-19-001400:notes:172]
[same as prior period, unchanged from 0001564590-18-026529:notes:139]

[0001564590-19-001400:notes:173]
During the six months ended December 31, 2018, the Performance Thresholds were not achieved for fiscal 2018 or fiscal 2019.

[0001564590-19-001400:notes:174]
[same as prior period, unchanged from 0001564590-18-026529:notes:140]

[0001564590-19-001400:notes:175]
[same as prior period, unchanged from 0001564590-18-026529:notes:141]

[0001564590-19-001400:notes:176]
[same as prior period, unchanged from 0001564590-18-026529:notes:142]

[0001564590-19-001400:notes:177]
No PSUs were granted during the second quarter of fiscal 2019.

[0001564590-19-001400:notes:178]
[same as prior period, unchanged from 0001564590-18-026529:notes:143]

[0001564590-19-001400:notes:179]
[same as prior period, unchanged from 0001564590-18-026529:notes:144]

[0001564590-19-001400:notes:180]
There were no shares granted under the ESPP during the three months ended December 31, 2018 and 2017. There were 1,280,708 and 1,267,930 shares issued under the ESPP during the six months ended December 31, 2018 and 2017, respectively.  The following assumptions were used to calculate the fair value of shares granted under the ESPP during the following periods:

[0001564590-19-001400:notes:181]
|  |  | Employee Stock Purchase Plan |  |
|  |  | Six Months Ended |  |
|  |  | December 31, 2018 |  |  | December 31, 2017 |  |
| Expected life |  | 0.5 years |  |  | 0.5 years |  |
| Risk-free interest rate |  |  | 2.20 | % |  |  | 1.15 | % |
| Volatility |  |  | 63 | % |  |  | 42 | % |
| Dividend yield |  |  | — | % |  |  | — | % |

[0001564590-19-001400:notes:182]
The weighted-average fair value of shares granted under the ESPP during the six months ended December 31, 2018 and 2017 was $2.73 and $2.41, respectively.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001564590-19-001400:notes:183]
| 12. | Information about Segments of Geographic Areas |

[0001564590-19-001400:notes:184]
[same as prior period, unchanged from 0001564590-18-026529:notes:200]

[0001564590-19-001400:notes:185]
See Note 3 Net Revenues for the Company’s revenues by geographic regions and channel based on the customer’s ship-to location.

[0001564590-19-001400:notes:186]
[same as prior period, unchanged from 0001564590-18-026529:notes:202]

[0001564590-19-001400:notes:187]
| Long-lived Assets |  | December 31, 2018 |  |  | June 30, 2018 |  |
| Americas |  | $ | 142,580 |  |  | $ | 178,251 |  |
| EMEA |  |  | 36,384 |  |  |  | 15,106 |  |
| APAC |  |  | 12,249 |  |  |  | 9,896 |  |
| Total long-lived assets |  | $ | 191,213 |  |  | $ | 203,253 |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001564590-19-001400:notes:188]
| 13. | Foreign Exchange Forward Contracts |

[0001564590-19-001400:notes:189]
[same as prior period, unchanged from 0001564590-18-026529:notes:196]

[0001564590-19-001400:notes:190]
As of December 31, 2018, the Company did not have any forward foreign currency contracts. As of December 31, 2017 forward foreign currency contracts had a notional principal amount of $1.5 million and an immaterial unrealized gain. These contracts typically have maturities of less than 90 days. Changes in the fair value of these foreign exchange forward contracts are offset largely by re-measurement of the underlying assets and liabilities.

[0001564590-19-001400:notes:191]
Foreign currency transactions losses from operations was less than $0.1 million and $0.6 million for the three months ended December 31, 2018 and 2017, respectively.  Foreign currency transactions gains and losses from operations was a gain of $0.2 million and a loss of $1.1 million for the six months ended December 31, 2018 and 2017, respectively.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001564590-19-001400:notes:192]
14.Restructuring Charges, net of reversals

[0001564590-19-001400:notes:193]
[same as prior period, unchanged from 0001564590-18-026529:notes:149]

[0001564590-19-001400:notes:194]
The Company recorded $0.5 million and $1.3 million of restructuring charges, net of reversals during the three and six months ended December 31, 2018, respectively, associated with a reduction-in-force in the fourth quarter of fiscal 2018 and additional excess facilities obligations.

[0001564590-19-001400:notes:195]
Cash payments of $4.7 million were paid during the first six months of fiscal 2019.  The balance of the severance and benefits obligations are expected to be paid by the end of fiscal 2019.  The excess facilities obligations will continue through fiscal year 2023.

[0001564590-19-001400:notes:196]
[same as prior period, unchanged from 0001564590-18-026529:notes:152]

[0001564590-19-001400:notes:197]
|  |  | Excess Facilities |  |  | Severance Benefits |  |  | Total |  |
| Balance as of June 30, 2018 |  | $ | 1,797 |  |  | $ | 4,658 |  |  | $ | 6,455 |  |
| Period charges |  |  | 104 |  |  |  | 1,524 |  |  |  | 1,628 |  |
| Period reversals |  |  | — |  |  |  | (346 | ) |  |  | (346 | ) |
| Period payments |  |  | (101 | ) |  |  | (4,569 | ) |  |  | (4,670 | ) |
| Balance as of December 31, 2018 |  | $ | 1,800 |  |  | $ | 1,267 |  |  | $ | 3,067 |  |
| Less: current portion included in Other accrued liabilities |  |  |  |  |  |  |  |  |  |  | 1,830 |  |
| Restructuring accrual included in Other long-term liabilities |  |  |  |  |  |  |  |  |  | $ | 1,237 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0001564590-19-001400:notes:198]
15.Income Taxes

[0001564590-19-001400:notes:199]
For the three months ended December 31, 2018 and 2017, the Company recorded an income tax benefit of $5.3 million and $1.6 million, respectively. For the six months ended December 31, 2018 and 2017, the Company recorded a tax benefit of $3.9 million and a tax provision of $0.1 million, respectively.

[0001564590-19-001400:notes:200]
The income tax provisions for the three months ended December 31, 2018 and 2017, consisted of (1) taxes on the income of the Company’s foreign subsidiaries, (2) tax expense associated with the establishment of a U.S. deferred tax liability for amortizable goodwill resulting from the acquisition of Enterasys Networks, Inc., the WLAN Business, the Campus Fabric Business the Data Center Business, (3) foreign withholding taxes and (4) state taxes in jurisdictions where the Company has no available state Net Operating Losses (“NOLs”).

[0001564590-19-001400:notes:201]
The tax provision for the three months ended December 31, 2018, is offset by a tax benefit of $2.6 million resulting from the release of a valuation allowance for the Company’s Australian NOLs given consistent and sufficient profitability following the recent acquisitions as well as a tax benefit of $4.7 million for the release of valuation allowance given changes introduced by recently enacted U.S. tax legislation as discussed below.  This legislation changed the U.S. NOL rules to afford an indefinite carryforward period for NOLs generated in tax years beginning after December 31, 2017.  In evaluating the realizability of Deferred Tax Assets (“DTAs”), historically the Company was unable to consider the Deferred Tax Liability (“DTL”) related to amortizable goodwill as a source of future income for reversing deductible differences with fixed lives.  The change to the NOL rules creates an indefinite lived DTA and as such the indefinite lived DTL related to goodwill can now be viewed as a source of income for the newly created indefinite lived DTA.  These two indefinite lived items can now be netted in determining the amount of valuation allowance needed.

[0001564590-19-001400:notes:202]
The tax provision for the three months ended December 31, 2017, is offset by a tax benefit of $2.5 million resulting from the reduction of the U.S. Federal tax rate from 35% to 21% applied to the Company’s deferred tax liability related to amortizable goodwill as required by the U.S. tax legislation discussed below. The income tax provisions for both fiscal years were calculated based on the actual results of operations for the three months ended December 31, 2018 and 2017, respectively and therefore may not reflect the annual effective tax rate.

[0001564590-19-001400:notes:203]
The income tax benefit and provision for the six months ended December 31. 2018 and 2017, respectively consisted primarily of taxes on the income of the Company’s foreign subsidiaries as well as tax expense associated with the establishment of a U.S. deferred tax liability for amortizable goodwill resulting from the acquisition of Enterasys Networks, Inc., the WLAN Business, the Campus Fabric Business and the Data Center Business.  The income tax provision for the six months ended December 31, 2018 was offset by the two valuation allowance releases referenced above.  The income tax provision for the six months ended December 31, 2017 is offset by a tax benefit of $2.5 million resulting from U.S. tax legislation which reduced the corporate federal tax rate from 35% to 21%.  As a result of this change, the Company recognized a tax benefit associated with the revaluation of the Company’s deferred tax liability related to amortizable goodwill to reflect the lower statutory tax rate.

[0001564590-19-001400:notes:204]
[same as prior period, unchanged from 0001564590-18-026529:notes:177]

[0001564590-19-001400:notes:205]
[same as prior period, unchanged from 0001564590-18-026529:notes:178]

[0001564590-19-001400:notes:206]
The TCJA moves the U.S. from a global taxation regime to a modified territorial regime.  Under the territorial regime, the company’s foreign earnings will generally not be subject to tax in the US.  As part of transitioning to this new regime, U.S. companies were required to pay tax on historical earnings generated offshore that have not been repatriated to the U.S. (“Transition Tax”).  The Company has determined there was no incremental tax provision related to the Transition Tax given the Company’s ability to utilize existing tax attributes to offset the impact of the deemed repatriation.

[0001564590-19-001400:notes:207]
The TCJA makes broad and complex changes to the U.S. tax code, and in certain instances, lacks clarity and is subject to interpretation until additional U.S. Treasury guidance is issued. Certain guidance has been released during the second quarter of the Company’s Fiscal year ended June 30, 2019 and has been incorporated into the Company’s related computations.   On December 22, 2017, the SEC issued guidance under Staff Accounting Bulletin No. 118, Income Tax Accounting Implications of the Tax Cuts and Jobs Act (“SAB 118”), which allows registrants to record provisional amounts during a one year “measurement period” similar to that used when accounting for business combinations.  However, the measurement period was deemed to have ended earlier when the registrant has obtained, prepared and analyzed the information necessary to finalize its accounting.  During the measurement period, impacts of the law are expected to be recorded at the time a reasonable estimate for all or a portion of the effects can be made, and provisional amounts can be recognized and adjusted as information becomes available, prepared or analyzed. SAB 118 summarizes a three-step process to be applied at each reporting period to account for and qualitatively disclose: (1) the effects of the change in tax law for which accounting is complete; (2) provisional amounts (or adjustments to provisional amounts) for the effects of the tax law where accounting is not complete, but that a reasonable estimate has been determined; and (3) a reasonable estimate cannot yet be made and therefore taxes are reflected in accordance with law prior to the enactment of the TCJA. The measurement period ended in the Company’s fiscal quarter ended December 31, 2018 and the Company has finalized all related adjustments.

[0001564590-19-001400:notes:208]
Amounts recorded pursuant to Tax Reform and the provisions of SAB 118 relate to the reduction in the U.S. federal tax rate to 21 percent, which resulted in the Company reporting an income tax benefit of $2.5 million in the fiscal year ended June 30, 2018 to remeasure deferred tax liabilities associated with indefinitely lived intangible assets that will reverse at the new 21% rate. Absent this deferred tax liability, the Company has historically been in a net deferred tax asset position that is offset by a full valuation allowance.  The Transition Tax introduced by TCJA has been calculated to be zero for the Company given existing tax attributes that were utilized to offset the calculated liability. As discussed below, during the quarter ended December 31, 2018 the Company completed its evaluation of whether to treat global intangible low-taxed income (“GILTI”) as a component of tax expense in the period in which it is incurred or as a component of deferred income taxes.  In conjunction with this determination and the completion of schedule the reversal of deferred tax assets and liabilities the Company has reduced the valuation allowance level by $4.7 million to reflect the introduction of an indefinite carryforward period for NOLs expected to be generated in tax years beginning after December 31, 2017 once deferred tax assets reverse. With respect to provisions of the TCJA effective for the Company’s fiscal year ended 2019, the Company anticipates several new provisions will impact tax provisions in future periods including limitations on the deductibility of interest expense and certain executive compensation, a minimum tax on certain foreign earnings (i.e., GILTI).  The GILTI provisions require the Company to include in its U.S. income tax return foreign subsidiary earnings in excess of an allowable return on the foreign subsidiary’s tangible assets. Based on initial assessment and interpretation of the new provision, the Company expects that it will be subject to incremental U.S. tax on GILTI income beginning in fiscal 2019. The Company has elected to account for GILTI tax as a component of tax expense in the period in which it is incurred. The Base Erosion and Anti-Abuse Tax (“BEAT”) provisions in the Tax Reform Act eliminate the deduction of certain base-erosion payments made to related foreign corporations and impose a minimum tax if greater than regular tax.  There is a reasonable amount of uncertainty surrounding the interpretation of this new provision, however, based on initial assessment and a reasonable interpretation of the new provision, the Company expects that it will not be subject to the incremental U.S. tax on BEAT income beginning in fiscal 2019, due to a realignment of the Company’s international structure.

[0001564590-19-001400:notes:209]
In the three months ended September 30, 2018, the Company adopted ASU 2016-16, Intra-Entity Transfers of Assets Other Than Inventory, which requires an entity to recognize the income tax consequences of an intra-entity transfer of an asset at the time the transfer occurs.  Historically, GAAP has prohibited the recognition of current and deferred income taxes for an intra-entity asset transfer until the asset had been sold outside the consolidated group.  Effective as of July 1, 2018, the Company adopted ASU 2016-16 on a modified retrospective basis which requires an adjustment of the cumulative-effect of the adoption to retained earnings.  However, the adjustment was immaterial to the financial statements and no such adjustment was necessary.  As a result of adoption, the income tax consequences of future intra-entity transfer of assets will be recognized in earnings in each period rather than be deferred until the assets leave the consolidated group.  In the three months ended September 30, 2018, the Company recognized a deferred tax asset relating to a transfer of certain assets from the US parent company to its wholly-owned Irish subsidiary of $3.7 million, which was fully offset by the establishment of a valuation allowance resulting in no impact to Company’s statement of operations.

[0001564590-19-001400:notes:210]
The Company has provided a full valuation allowance against all its U.S. federal and state deferred tax assets as well as a portion of the deferred tax assets in Ireland. A valuation allowance is determined by assessing both negative and positive evidence to determine whether it is “more likely than not” that the deferred tax assets are recoverable; such assessment is required on a jurisdiction by jurisdiction basis.  The Company's inconsistent earnings in recent periods, including a cumulative loss over the last three years, coupled with its difficulty in forecasting future revenue trends as well as the cyclical nature of its business represent sufficient negative evidence to require a full valuation allowance against its U.S. federal and state net deferred tax assets as well as the above mentioned foreign jurisdictions.  This valuation allowance will be evaluated periodically and can be reversed partially or in whole if business results and the economic environment have sufficiently improved to support realization of some or all of the Company's deferred tax assets.

[0001564590-19-001400:notes:211]
The acquisition of Enterasys in October 2013 included a U.S. parent company as well as its wholly-owned foreign subsidiaries. The Company elected to treat this stock acquisition as an asset purchase by filing the required election forms under IRC Sec 338(h)(10).  In addition, the Company completed asset purchases of the WLAN Business, the Campus Fabric Business and the Data Center Business in October 2016, July 2017 and October 2017, respectively.  The Company has estimated the value of the intangible assets from these transactions and is amortizing the amounts over 15 years for tax purposes.  During the three and six months ended December 31, 2018, the Company deducted $1.8 million and $4.1 million of tax amortization expense respectively, for each period related to capitalized goodwill resulting from these acquisitions. As of December 31, 2018, the Company recorded a deferred tax liability of $6.4 million related to this goodwill amortization which now can be partially considered a future source of taxable income in evaluating the need for a valuation allowance against its deferred tax assets.

[0001564590-19-001400:notes:212]
The Company had $17.5 million of unrecognized tax benefits as of December 31, 2018.  The future impact of the unrecognized tax benefit of $17.5 million, if recognized, would result in adjustments to deferred tax assets and corresponding adjustments to the valuation allowance. The Company does not anticipate any events to occur during the next twelve months that would reduce the unrealized tax benefit as currently stated in the Company’s balance sheet.

[0001564590-19-001400:notes:213]
[same as prior period, unchanged from 0001564590-18-026529:notes:187]

[0001564590-19-001400:notes:214]
In general, the Company’s U.S. federal income tax returns are subject to examination by tax authorities for fiscal years 2001 forward due to net operating losses and the Company's state income tax returns are subject to examination for fiscal years 2000 forward due to net operating losses. The Company recently settled an examination by the state of North Carolina for fiscal years ended 2014, 2015 and 2016. The settlement resulted in an immaterial payment to the state to close all three years.


## us-gaap:EarningsPerShareTextBlock

[0001564590-19-001400:notes:215]
16.Net Loss Per Share

[0001564590-19-001400:notes:216]
[same as prior period, unchanged from 0001564590-18-026529:notes:190]

[0001564590-19-001400:notes:217]
[same as prior period, unchanged from 0001564590-18-026529:notes:191]

[0001564590-19-001400:notes:218]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | December 31, 2018 |  |  | December 31, 2017 |  |  | December 31, 2018 |  |  | December 31, 2017 |  |
| Net loss |  | $ | 7,199 |  |  | $ | (31,923 | ) |  | $ | (1,866 | ) |  | $ | (27,547 | ) |
| Weighted-average shares used in per share calculation - basic |  |  | 117,544 |  |  |  | 113,621 |  |  |  | 117,456 |  |  |  | 112,931 |  |
| Effect of potentially dilutive shares: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Options to purchase common stock |  |  | 657 |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Restricted stock units |  |  | 1,129 |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Employee Stock Purchase Plan shares |  |  | 214 |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Weighted-average shares used in per share calculation - diluted |  |  | 119,544 |  |  |  | 113,621 |  |  |  | 117,456 |  |  |  | 112,931 |  |
| Net income (loss) per share - basic |  | $ | 0.06 |  |  | $ | (0.28 | ) |  | $ | (0.02 | ) |  | $ | (0.24 | ) |
| Net income (loss) per share - diluted |  | $ | 0.06 |  |  | $ | (0.28 | ) |  | $ | (0.02 | ) |  | $ | (0.24 | ) |

[0001564590-19-001400:notes:219]
[same as prior period, unchanged from 0001564590-18-026529:notes:193]

[0001564590-19-001400:notes:220]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | December 31, 2018 |  |  | December 31, 2017 |  |  | December 31, 2018 |  |  | December 31, 2017 |  |
| Options to purchase common stock |  |  | 781 |  |  |  | 2,622 |  |  |  | 543 |  |  |  | 2,781 |  |
| Restricted stock units |  |  | 6,341 |  |  |  | 7,950 |  |  |  | 1,369 |  |  |  | 7,162 |  |
| Employee Stock Purchase Plan shares |  |  | 1,286 |  |  |  | 834 |  |  |  | 1,286 |  |  |  | 906 |  |
| Total shares excluded |  |  | 8,408 |  |  |  | 11,406 |  |  |  | 3,198 |  |  |  | 10,849 |  |
