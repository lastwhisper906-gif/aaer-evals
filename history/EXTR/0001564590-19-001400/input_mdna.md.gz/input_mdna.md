# EXTR MD&A — 0001564590-19-001400


## mdna

[0001564590-19-001400:mdna:1]
[same as prior period, unchanged from 0001564590-18-026529:mdna:1]

[0001564590-19-001400:mdna:2]
[same as prior period, unchanged from 0001564590-18-026529:mdna:2]

[0001564590-19-001400:mdna:3]
The following discussion is based upon our consolidated financial statements included elsewhere in this Report, which have been prepared in accordance with U.S. generally accepted accounting principles (“U.S. GAAP”).  In the course of operating our business, we routinely make decisions as to the timing of the payment of invoices, the collection of receivables, the manufacturing and shipment of products, the fulfillment of orders, the purchase of supplies, and the building of inventory and service parts, among other matters. Each of these decisions has some impact on the financial results for any given period.  In making these decisions, we consider various factors including contractual obligations, customer satisfaction, competition, internal and external financial targets and expectations, and financial planning objectives. For further information about our critical accounting policies and estimates, see “Critical Accounting Policies and Estimates” section included in this “Management's Discussion and Analysis of Financial Condition and Results of Operations.”

[0001564590-19-001400:mdna:4]
Extreme Networks, Inc., together with its subsidiaries (collectively referred to as “Extreme” and as “we”, “us” and “our”) is a leading provider of network infrastructure equipment and software and offers related maintenance contracts for extended warranty and maintenance to our enterprise, data center and service provider customers.  We were incorporated in California in May 1996 and reincorporated in Delaware in March 1999.  Our corporate headquarters are located in San Jose, California. We derive substantially all of our revenue from the sale of our networking equipment and related maintenance contracts.

[0001564590-19-001400:mdna:5]
[same as prior period, unchanged from 0001564590-18-026529:mdna:5]

[0001564590-19-001400:mdna:6]
[same as prior period, unchanged from 0001564590-18-026529:mdna:6]

[0001564590-19-001400:mdna:7]
A trend affecting the Enterprise Network Equipment market is the continued adoption of the cloud-managed enterprise WLAN in the enterprise market. Hybrid cloud is a cloud computing environment which uses a mix of on-premises, private cloud and third-party, public cloud services with orchestration between the two platforms.

[0001564590-19-001400:mdna:8]
We believe that understanding the following key developments is helpful to an understanding of our operating results for the fiscal quarter ended December 31, 2018.

[0001564590-19-001400:mdna:9]
[same as prior period, unchanged from 0001564590-18-026529:mdna:9]

[0001564590-19-001400:mdna:10]
[same as prior period, unchanged from 0001564590-18-026529:mdna:10]

[0001564590-19-001400:mdna:11]
|  | • | Access Point: A wireless access point, or more generally just access point (“AP”), is a networking hardware device that allows a Wi-Fi device to connect to a wired network. (Source: Industry term) |

[0001564590-19-001400:mdna:12]
[same as prior period, unchanged from 0001564590-18-026529:mdna:12]

[0001564590-19-001400:mdna:13]
[same as prior period, unchanged from 0001564590-18-026529:mdna:13]

[0001564590-19-001400:mdna:14]
|  | • | Campus Network: A campus network, or campus area network, or corporate area network (“CAN”) is a computer network made up of an interconnection of local area networks (“LANs”) within a limited geographical area, such as a college campus, company campus, hospital, hotel, convention center or sports venue. |

[0001564590-19-001400:mdna:15]
[same as prior period, unchanged from 0001564590-18-026529:mdna:15]

[0001564590-19-001400:mdna:16]
[same as prior period, unchanged from 0001564590-18-026529:mdna:16]

[0001564590-19-001400:mdna:17]
[same as prior period, unchanged from 0001564590-18-026529:mdna:17]

[0001564590-19-001400:mdna:18]
|  | • | Data Center Fabric technologies: Also known as IP Fabric, is the basic topology of how a network is laid out and connected to switch traffic on a data or circuit-switched network. |

[0001564590-19-001400:mdna:19]
[same as prior period, unchanged from 0001564590-18-026529:mdna:19]

[0001564590-19-001400:mdna:20]
|  | • | Fabric Attach: Extreme’s Fabric Attach (“FA”) fundamentally introduces autonomic/automatic attachment to network services for end users IoT devices to a network infrastructure. Fabric Attach and Fabric Connect are key building blocks of the Extreme Fabric architecture. |

[0001564590-19-001400:mdna:21]
|  | • | Fabric Connect: Fabric Connect is an extended implementation of the IEEE/IEFT standards for Shortest Path Bridging (“SPB”). It offers a full-service network virtualization technology that combines the best of Ethernet and the best of IP using a single network protocol instead of the multiple required for competitive solutions. |

[0001564590-19-001400:mdna:22]
[same as prior period, unchanged from 0001564590-18-026529:mdna:22]

[0001564590-19-001400:mdna:23]
[same as prior period, unchanged from 0001564590-18-026529:mdna:23]

[0001564590-19-001400:mdna:24]
[same as prior period, unchanged from 0001564590-18-026529:mdna:24]

[0001564590-19-001400:mdna:25]
[same as prior period, unchanged from 0001564590-18-026529:mdna:25]

[0001564590-19-001400:mdna:26]
29

[0001564590-19-001400:mdna:27]
[same as prior period, unchanged from 0001564590-18-026529:mdna:26]

[0001564590-19-001400:mdna:28]
[same as prior period, unchanged from 0001564590-18-026529:mdna:29]

[0001564590-19-001400:mdna:29]
[same as prior period, unchanged from 0001564590-18-026529:mdna:30]

[0001564590-19-001400:mdna:30]
[same as prior period, unchanged from 0001564590-18-026529:mdna:31]

[0001564590-19-001400:mdna:31]
[same as prior period, unchanged from 0001564590-18-026529:mdna:32]

[0001564590-19-001400:mdna:32]
|  | • | Workflow Composer: Extreme’s event-driven automation tool that allows for customizable workflows and automation to drive provisioning, configuration, and troubleshooting actions in a multi-vendor environment |

[0001564590-19-001400:mdna:33]
[same as prior period, unchanged from 0001564590-18-026529:mdna:33]

[0001564590-19-001400:mdna:34]
[same as prior period, unchanged from 0001564590-18-026529:mdna:34]

[0001564590-19-001400:mdna:35]
[same as prior period, unchanged from 0001564590-18-026529:mdna:35]

[0001564590-19-001400:mdna:36]
[same as prior period, unchanged from 0001564590-18-026529:mdna:36]

[0001564590-19-001400:mdna:37]
[same as prior period, unchanged from 0001564590-18-026529:mdna:37]

[0001564590-19-001400:mdna:38]
[same as prior period, unchanged from 0001564590-18-026529:mdna:38]

[0001564590-19-001400:mdna:39]
[same as prior period, unchanged from 0001564590-18-026529:mdna:39]

[0001564590-19-001400:mdna:40]
[same as prior period, unchanged from 0001564590-18-026529:mdna:41]

[0001564590-19-001400:mdna:41]
[same as prior period, unchanged from 0001564590-18-026529:mdna:42]

[0001564590-19-001400:mdna:42]
[same as prior period, unchanged from 0001564590-18-026529:mdna:70]

[0001564590-19-001400:mdna:43]
[same as prior period, unchanged from 0001564590-18-026529:mdna:43]

[0001564590-19-001400:mdna:44]
[same as prior period, unchanged from 0001564590-18-026529:mdna:44]

[0001564590-19-001400:mdna:45]
[same as prior period, unchanged from 0001564590-18-026529:mdna:45]

[0001564590-19-001400:mdna:46]
[same as prior period, unchanged from 0001564590-18-026529:mdna:46]

[0001564590-19-001400:mdna:47]
[same as prior period, unchanged from 0001564590-18-026529:mdna:47]

[0001564590-19-001400:mdna:48]
[same as prior period, unchanged from 0001564590-18-026529:mdna:48]

[0001564590-19-001400:mdna:49]
[same as prior period, unchanged from 0001564590-18-026529:mdna:49]

[0001564590-19-001400:mdna:50]
[same as prior period, unchanged from 0001564590-18-026529:mdna:50]

[0001564590-19-001400:mdna:51]
[same as prior period, unchanged from 0001564590-18-026529:mdna:51]

[0001564590-19-001400:mdna:52]
|  | ➣ | We announced our 802.11ac Wave 2 wireless offering in late 2015 and plans to continue to advance our wireless portfolio of indoor and outdoor access points, supported by the January 2019, announcement of our Wi-Fi 6 (802.11ax) portfolio of access points. |

[0001564590-19-001400:mdna:53]
[same as prior period, unchanged from 0001564590-18-026529:mdna:53]

[0001564590-19-001400:mdna:54]
We are focused on delivering end-to-end IP networking solutions for today’s enterprise environments. From wireless and wired access technologies, through the campus, core and into the datacenter, Extreme is developing solutions to deliver outstanding business outcomes for our customers.  Leveraging a unified management approach, both on premise and in the cloud, we continue to accelerate adoption and delivery of new technologies in support of emerging trends in enterprise networking.

[0001564590-19-001400:mdna:55]
[same as prior period, unchanged from 0001564590-18-026529:mdna:55]

[0001564590-19-001400:mdna:56]
[same as prior period, unchanged from 0001564590-18-026529:mdna:56]

[0001564590-19-001400:mdna:57]
[same as prior period, unchanged from 0001564590-18-026529:mdna:57]

[0001564590-19-001400:mdna:58]
[same as prior period, unchanged from 0001564590-18-026529:mdna:58]

[0001564590-19-001400:mdna:59]
[same as prior period, unchanged from 0001564590-18-026529:mdna:59]

[0001564590-19-001400:mdna:60]
|  | • | Focus on being nimble and responsive to customers and partners, we call this “Customer-Driven Networking™.” We work with our customers to deliver software-driven solutions from the enterprise edge to the cloud that are agile, adaptive, and secure to enable digital transformation for our customers. We help our customers move beyond just “keeping the lights on”, so they can think strategically and innovate. By allowing customers to access critical decision-making intelligence, we are able reduce their daily tactical work, so they can spend their time on learning and understanding how to innovate their business with IT. |

[0001564590-19-001400:mdna:61]
[same as prior period, unchanged from 0001564590-18-026529:mdna:61]

[0001564590-19-001400:mdna:62]
[same as prior period, unchanged from 0001564590-18-026529:mdna:62]

[0001564590-19-001400:mdna:63]
[same as prior period, unchanged from 0001564590-18-026529:mdna:63]

[0001564590-19-001400:mdna:64]
|  | • | Enable IoT without additional IT resources. In a recent IoT IT infrastructure survey, enterprise IT decision makers across industry verticals indicated their preference to opt for their existing wireless connectivity infrastructure to support IoT devices. These preferences will place unprecedented demand on network administrators to enhance management capabilities, scalability and programmability of the enterprise networks they manage without additional IT resources. Extreme introduced the Defender for IoT in mid-2018, to address the growing concern of connected things, providing centralized visibility and management and enable IT to analyze traffic flows and pinpoint anomalies. The solution works with the Extreme Fabric Connect solution or over third-party networks to protect IoT devices and is ideal for healthcare environments. |

[0001564590-19-001400:mdna:65]
[same as prior period, unchanged from 0001564590-18-026529:mdna:65]

[0001564590-19-001400:mdna:66]
[same as prior period, unchanged from 0001564590-18-026529:mdna:66]

[0001564590-19-001400:mdna:67]
[same as prior period, unchanged from 0001564590-18-026529:mdna:67]

[0001564590-19-001400:mdna:68]
[same as prior period, unchanged from 0001564590-18-026529:mdna:68]

[0001564590-19-001400:mdna:69]
[same as prior period, unchanged from 0001564590-18-026529:mdna:69]

[0001564590-19-001400:mdna:70]
|  | • | Extend switching and routing technology leadership. Our technological leadership is based on innovative switching, routing and wireless products, the depth and focus of our market experience and our operating systems - the software that runs on all of our hardware platforms. Our products reduce operating expenses for our customers and enable a more flexible and dynamic network environment that will help them meet the upcoming demands of IoT, mobile, and cloud, etc. Furthermore, our network operating systems, our primary merchant silicon vendor, and select manufacturing partners permit us to leverage our engineering investment. We have invested in engineering resources to create leading-edge technologies to increase the performance and functionality of our products, and as a direct result, the value of our solution to our current and future customers. We look for maximum synergies from our engineering investment in our targeted verticals. |

[0001564590-19-001400:mdna:71]
32

[0001564590-19-001400:mdna:72]
[same as prior period, unchanged from 0001564590-18-026529:mdna:72]

[0001564590-19-001400:mdna:73]
[same as prior period, unchanged from 0001564590-18-026529:mdna:73]

[0001564590-19-001400:mdna:74]
[same as prior period, unchanged from 0001564590-18-026529:mdna:74]

[0001564590-19-001400:mdna:75]
[same as prior period, unchanged from 0001564590-18-026529:mdna:75]

[0001564590-19-001400:mdna:76]
[same as prior period, unchanged from 0001564590-18-026529:mdna:76]

[0001564590-19-001400:mdna:77]
[same as prior period, unchanged from 0001564590-18-026529:mdna:77]

[0001564590-19-001400:mdna:78]
|  | • | Expand market penetration by targeting high-growth market segments. Within the Campus, we focus on the mobile user and connected devices, leveraging our automation capabilities and tracking WLAN growth. Our Data Center approach leverages our product portfolio to address the needs of public and private Cloud Data Center providers. Within the Campus we also target the high-growth physical security market, converging technologies such as Internet Protocol (“IP”) video across a common Ethernet infrastructure in conjunction with technology partners. |

[0001564590-19-001400:mdna:79]
[same as prior period, unchanged from 0001564590-18-026529:mdna:79]

[0001564590-19-001400:mdna:80]
[same as prior period, unchanged from 0001564590-18-026529:mdna:80]

[0001564590-19-001400:mdna:81]
[same as prior period, unchanged from 0001564590-18-026529:mdna:81]

[0001564590-19-001400:mdna:82]
During the second quarter of fiscal 2019, we reflected the following results:

[0001564590-19-001400:mdna:83]
|  | • | Net revenues of $252.7 million compared to $231.1 million in the second quarter of fiscal 2018. |

[0001564590-19-001400:mdna:84]
|  | • | Product revenue of $189.6 million compared to $174.9 million in the second quarter of fiscal 2018. |

[0001564590-19-001400:mdna:85]
|  | • | Service revenue of $63.1 million compared to $56.3 million in the second quarter of fiscal 2018. |

[0001564590-19-001400:mdna:86]
|  | • | Total gross margin of 55.9% of net revenues compared to 55.8% of net revenues in the second quarter of fiscal 2018. |

[0001564590-19-001400:mdna:87]
|  | • | Operating income of $4.8 million compared to an operating loss of $31.1 million in the second quarter of fiscal 2018. |

[0001564590-19-001400:mdna:88]
|  | • | Net income of $7.2 million compared to a net loss of $31.9 million in the second quarter of fiscal 2018. |

[0001564590-19-001400:mdna:89]
33

[0001564590-19-001400:mdna:90]
During the first six months of fiscal 2019, we reflected the following results:

[0001564590-19-001400:mdna:91]
|  | • | Cash flow provided by operating activities of $61.6 million compared to $14.2 million in the six months ended December 31, 2017. Cash, cash equivalents and marketable securities of $141.1 million compared to $122.6 million as of June 30, 2018. |

[0001564590-19-001400:mdna:92]
[same as prior period, unchanged from 0001564590-18-026529:mdna:90]

[0001564590-19-001400:mdna:93]
[same as prior period, unchanged from 0001564590-18-026529:mdna:91]

[0001564590-19-001400:mdna:94]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | December 31, 2018 |  |  | December 31, 2017 |  |  | $ Change |  |  | % Change |  |  | December 31, 2018 |  |  | December 31, 2017 |  |  | $ Change |  |  | % Change |  |
| Net Revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 189,567 |  |  | $ | 174,850 |  |  | $ | 14,717 |  |  |  | 8.4 | % |  | $ | 367,287 |  |  | $ | 339,624 |  |  | $ | 27,663 |  |  |  | 8.1 | % |
| Percentage of net revenue |  |  | 75.0 | % |  |  | 75.7 | % |  |  |  |  |  |  |  |  |  |  | 74.6 | % |  |  | 76.7 | % |  |  |  |  |  |  |  |  |
| Service |  |  | 63,113 |  |  |  | 56,273 |  |  |  | 6,840 |  |  |  | 12.2 | % |  |  | 125,279 |  |  |  | 103,214 |  |  |  | 22,065 |  |  |  | 21.4 | % |
| Percentage of net revenue |  |  | 25.0 | % |  |  | 24.3 | % |  |  |  |  |  |  |  |  |  |  | 25.4 | % |  |  | 23.3 | % |  |  |  |  |  |  |  |  |
| Total net revenues |  | $ | 252,680 |  |  | $ | 231,123 |  |  | $ | 21,557 |  |  |  | 9.3 | % |  | $ | 492,566 |  |  | $ | 442,838 |  |  | $ | 49,728 |  |  |  | 11.2 | % |

[0001564590-19-001400:mdna:95]
Product revenue increased $14.7 million or 8.4% for the three months ended December 31, 2018 and increased $27.7 million or 8.1% for the six months ended December 31, 2018 as compared to the corresponding periods of fiscal 2018.  The increase in product revenues for both periods of fiscal 2019 were attributable to a full period of sales of the Data Center Business and increased sales in EMEA.

[0001564590-19-001400:mdna:96]
Service revenue increased $6.8 million, or 12.2% for the three months ended December 31, 2018 and increased $22.1 million or 21.4% as compared to the corresponding periods of fiscal 2018.  The increase in service revenue was driven primarily by a higher number of maintenance contracts related to the Data Center Business acquisition.

[0001564590-19-001400:mdna:97]
[same as prior period, unchanged from 0001564590-18-026529:mdna:95]

[0001564590-19-001400:mdna:98]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | December 31, 2018 |  |  | December 31, 2017 |  |  | $ Change |  |  | % Change |  |  | December 31, 2018 |  |  | December 31, 2017 |  |  | $ Change |  |  | % Change |  |
| Gross profit: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 103,080 |  |  | $ | 96,378 |  |  | $ | 6,702 |  |  |  | 7.0 | % |  | $ | 197,257 |  |  | $ | 181,107 |  |  | $ | 16,150 |  |  |  | 8.9 | % |
| Percentage of product revenue |  |  | 54.4 | % |  |  | 55.1 | % |  |  |  |  |  |  |  |  |  |  | 53.7 | % |  |  | 53.3 | % |  |  |  |  |  |  |  |  |
| Service |  |  | 38,219 |  |  |  | 32,608 |  |  |  | 5,611 |  |  |  | 17.2 | % |  |  | 76,113 |  |  |  | 60,260 |  |  |  | 15,853 |  |  |  | 26.3 | % |
| Percentage of service revenue |  |  | 60.6 | % |  |  | 57.9 | % |  |  |  |  |  |  |  |  |  |  | 60.8 | % |  |  | 58.4 | % |  |  |  |  |  |  |  |  |
| Total gross profit |  | $ | 141,299 |  |  | $ | 128,986 |  |  | $ | 12,313 |  |  |  | 9.5 | % |  | $ | 273,370 |  |  | $ | 241,367 |  |  | $ | 32,003 |  |  |  | 13.3 | % |
| Percentage of net revenues |  |  | 55.9 | % |  |  | 55.8 | % |  |  |  |  |  |  |  |  |  |  | 55.5 | % |  |  | 54.5 | % |  |  |  |  |  |  |  |  |

[0001564590-19-001400:mdna:99]
Product gross profit increased $6.7 million or 7.0% for the three months ended December 31, 2018 as compared to the corresponding period in fiscal 2018. Increases in product gross profit were primarily due to higher revenue levels and higher intangible amortization expenses of $1.0 million. These increases were partially reduced by increased distribution costs of $2.9 million, warranty charges of $2.7 million and additional operations costs of $1.5 million mainly driven by higher personnel costs due to additional headcount.

[0001564590-19-001400:mdna:100]
Product gross profit increased $16.2 million or 8.9% for the six months ended December 31, 2018 as compared to the corresponding period in fiscal 2018.  Increases in product gross profit were primarily due to higher revenue levels and to a lesser extent, lower production costs.  These increases were offset by higher distribution costs of $6.2 million, amortization of developed technology intangibles due to the acquisition of the Campus Fabric and Data Center Businesses of $3.2 million warranty charges of $4.5 million and additional operations costs of $3.2 million mainly driven by higher personnel costs due to additional headcount.

[0001564590-19-001400:mdna:101]
Service gross profit increased $5.6 million and $15.9 million or 17.2% and 26.3% for the three and six months ended December 31, 2018, respectively, as compared to the corresponding periods in fiscal 2018.  The increases were primarily due to a higher number of maintenance contracts related to the acquisition of the Data Center Business, partially offset by higher service material costs and personnel costs due to increased headcount to support acquired contracts.

[0001564590-19-001400:mdna:102]
[same as prior period, unchanged from 0001564590-18-026529:mdna:99]

[0001564590-19-001400:mdna:103]
[same as prior period, unchanged from 0001564590-18-026529:mdna:100]

[0001564590-19-001400:mdna:104]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | December 31, 2018 |  |  | December 31, 2017 |  |  | $ Change |  |  | % Change |  |  | December 31, 2018 |  |  | December 31, 2017 |  |  | $ Change |  |  | % Change |  |
| Research and development |  | $ | 52,204 |  |  | $ | 45,907 |  |  | $ | 6,297 |  |  |  | 13.7 | % |  | $ | 103,445 |  |  | $ | 80,192 |  |  | $ | 23,253 |  |  |  | 29.0 | % |
| Sales and marketing |  |  | 68,342 |  |  |  | 65,659 |  |  |  | 2,683 |  |  |  | 4.1 | % |  |  | 135,924 |  |  |  | 121,220 |  |  |  | 14,704 |  |  |  | 12.1 | % |
| General and administrative |  |  | 13,886 |  |  |  | 11,669 |  |  |  | 2,217 |  |  |  | 19.0 | % |  |  | 26,657 |  |  |  | 23,854 |  |  |  | 2,803 |  |  |  | 11.8 | % |
| Acquisition and integration costs, net of bargain purchase gain |  |  | 67 |  |  |  | 34,115 |  |  |  | (34,048 | ) |  |  | (99.8 | )% |  |  | 2,613 |  |  |  | 38,359 |  |  |  | (35,746 | ) |  |  | (93.2 | )% |
| Restructuring charges, net of reversals |  |  | 474 |  |  |  | — |  |  |  | 474 |  |  | N/A |  |  |  | 1,282 |  |  |  | — |  |  |  | 1,282 |  |  | N/A |  |
| Amortization of intangibles |  |  | 1,575 |  |  |  | 2,746 |  |  |  | (1,171 | ) |  |  | (42.6 | )% |  |  | 3,716 |  |  |  | 4,360 |  |  |  | (644 | ) |  |  | (14.8 | )% |
| Total operating expenses |  | $ | 136,548 |  |  | $ | 160,096 |  |  | $ | (23,548 | ) |  |  | (14.7 | )% |  | $ | 273,637 |  |  | $ | 267,985 |  |  | $ | 5,652 |  |  |  | 2.1 | % |

[0001564590-19-001400:mdna:105]
[same as prior period, unchanged from 0001564590-18-026529:mdna:102]

[0001564590-19-001400:mdna:106]
[same as prior period, unchanged from 0001564590-18-026529:mdna:103]

[0001564590-19-001400:mdna:107]
Research and development expenses increased by $6.3 million or 13.7% for the three months ended December 31, 2018 as compared to the corresponding period of fiscal 2018.  The increase in research and development expenses was due to higher personnel costs of $2.9 million due to increased headcount related to the acquisition of the Data Center Business, $1.7 million in increased facility and information technology costs, $1.2 million in increased supplies and equipment costs and $3.6 million in increased software royalty costs.  The quarterly expenses were partially offset by a $3.1 million reduction in contractor and professional fees.

[0001564590-19-001400:mdna:108]
Research and development expenses increased by $23.3 million or 29.0% for the six months ended December 31, 2018, as compared to the corresponding period of fiscal 2018.  The increase in research and development expenses was due to higher personnel costs of $10.6 million due to increased headcount related to the acquisition of the Data Center Business, $4.1 million in increased facility and information technology costs, $2.2 million in increased supplies and equipment costs and $6.8 million in increased software royalty costs, which was partially offset by a $0.4 million reduction in contractor and professional fees.

[0001564590-19-001400:mdna:109]
[same as prior period, unchanged from 0001564590-18-026529:mdna:105]

[0001564590-19-001400:mdna:110]
[same as prior period, unchanged from 0001564590-18-026529:mdna:106]

[0001564590-19-001400:mdna:111]
Sales and marketing expenses increased by $2.7 million or 4.1% for the three months ended December 31, 2018, as compared to the corresponding period of fiscal 2018, primarily as a result of the acquisition of the Data Center Business.  The increase consisted of higher personnel costs of $2.0 million and $1.0 million in increased software, supplies and equipment costs, partially offset by a $0.3 million reduction in travel, marketing, meeting and conference costs.

[0001564590-19-001400:mdna:112]
Sales and marketing expenses increased by $14.7 million or 12.1% for the six months ended December 31, 2018, as compared to the corresponding period of fiscal 2018, primarily as a result of the acquisition of the Data Center Business.  The increase consisted of higher personnel costs of $12.1 million, $2.0 million in increased software, supplies and equipment costs, $0.3 million in increased travel, marketing, meeting and conference costs and $0.3 million in increased facility and information technology costs.

[0001564590-19-001400:mdna:113]
[same as prior period, unchanged from 0001564590-18-026529:mdna:108]

[0001564590-19-001400:mdna:114]
[same as prior period, unchanged from 0001564590-18-026529:mdna:109]

[0001564590-19-001400:mdna:115]
General and administrative expenses increased by $2.2 million or 19.0% for the three months ended December 31, 2018, as compared to the corresponding period of fiscal 2018, primarily due to $1.7 million in higher personnel costs, $0.6 million in professional fees and $0.4 million in higher facility and information technology costs. This was partially offset by a $0.3 million reduction in the bad debt provision and a $0.2 million reduction in other costs.

[0001564590-19-001400:mdna:116]
General and administrative expenses increased by $2.8 million or 11.8% for six months ended December 31, 2018, as compared to the corresponding period of fiscal 2018, primarily due to $2.4 million in higher personnel costs and $0.7 million in higher facility and information technology costs, partially offset by a $0.3 million reduction in the bad debt provision.

[0001564590-19-001400:mdna:117]
Acquisition and Integration Costs, Net of Bargain Purchase Gain

[0001564590-19-001400:mdna:118]
During the three and six months ended December 31, 2018, we incurred $0.1 million and $2.6 million, respectively, of operating integration costs related to the acquisitions of the Campus Fabric and Data Center Businesses.

[0001564590-19-001400:mdna:119]
For the three months ended December 31, 2017, we incurred $4.6 million of acquisition and $1.9 million of integration costs related to the acquisition of the Campus Fabric Business and $30.3 million of acquisition and $2.2 million of integration costs related to the acquisition of the Data Center Business. The Data Center Business acquisition costs included a $25.0 million consent fee paid to Broadcom, to terminate a previous asset purchase agreement entered into by us to purchase the Data Center Business from Broadcom, in anticipation of Broadcom’s acquisition of Brocade. The fee was paid to Broadcom to allow us to buy the Data Center Business directly from Brocade. Included in Acquisition and integration costs is a gain on bargain purchase of $4.9 million related to the acquisition of the capital financing business (“CF Business”).

[0001564590-19-001400:mdna:120]
For the six months ended December 31, 2017, we incurred $5.9 million of acquisition and $3.4 million of integration costs related to the acquisition of the Campus Fabric Business and $31.6 million of acquisition and $2.2 million of integration costs related to the acquisition of the Data Center Business. We also recorded a gain on bargain purchase of $4.9 million related to the acquisition of the CF Business.

[0001564590-19-001400:mdna:121]
[same as prior period, unchanged from 0001564590-18-026529:mdna:114]

[0001564590-19-001400:mdna:122]
For the three and six months ended December 31, 2018, we recorded restructuring charges of $0.5 million and $1.3 million, respectively, associated with a reduction-in-force in the fourth quarter of fiscal 2018 and additional excess facility charges.

[0001564590-19-001400:mdna:123]
[same as prior period, unchanged from 0001564590-18-026529:mdna:116]

[0001564590-19-001400:mdna:124]
During the three months ended December 31, 2018 and 2017, we recorded $1.6 million and $2.7 million, respectively, of amortization expense as operating expenses and in the accompanying condensed consolidated statements of operations.  The decrease was mainly due to amortization related to the acquired intangibles from the Enterasys acquisition becoming fully amortized.

[0001564590-19-001400:mdna:125]
During the six months ended December 31, 2018 and 2017, we recorded $3.7 million and $4.4 million, respectively, of amortization expense as operating expenses in the accompanying condensed consolidated statements of operations.  The decrease was mainly due to amortization related to the acquired intangibles from the Enterasys acquisition becoming fully amortized.

[0001564590-19-001400:mdna:126]
[same as prior period, unchanged from 0001564590-18-026529:mdna:118]

[0001564590-19-001400:mdna:127]
During the three months ended December 31, 2018 and 2017, we recorded $3.1 million and $2.5 million, respectively, in interest expense.  The increase in interest expense was due to higher outstanding loan balances and other charges on our Credit Agreement as compared to the corresponding period of fiscal 2018, as well as additional imputed interest charges associated with various long-term contracts.

[0001564590-19-001400:mdna:128]
During the six months ended December 31, 2018 and 2017, we recorded $6.6 million and $4.7 million, respectively, in interest expense.  The increase in interest expense was due to higher outstanding loan balances and other charges on of our Credit Agreement as compared to the corresponding period of fiscal 2018, as well as additional imputed interest charges associated with various long-term contracts.

[0001564590-19-001400:mdna:129]
[same as prior period, unchanged from 0001564590-18-026529:mdna:120]

[0001564590-19-001400:mdna:130]
During the three months ended December 31, 2018 and 2017, we recorded an expense of $0.4 million and $0.6 million, respectively, in other income (expense), net.  The expense for the three months ended December 31, 2018 was primarily due to losses on equity investments.  The expense for the three months ended December 31, 2017 was primarily due to foreign exchange gains and losses from the revaluation of certain assets and liabilities denominated in foreign currencies into U.S. Dollars.

[0001564590-19-001400:mdna:131]
During the six months ended December 31, 2018 and 2017, we recorded income of $0.1 million and $2.5 million, respectively, in other income (expense), net. For fiscal 2019, the income was primarily due to foreign exchange gains and losses from the revaluation of certain assets and liabilities denominated in foreign currencies into U.S. Dollars partially offset by losses on equity investments. For fiscal 2018, other income (expense), net was primarily driven by a gain of $3.8 million related to the sale of a non-marketable equity investment, partially offset by foreign exchange losses.

[0001564590-19-001400:mdna:132]
[same as prior period, unchanged from 0001564590-18-026529:mdna:122]

[0001564590-19-001400:mdna:133]
For the three months ended December 31, 2018 and 2017, we recorded an income tax benefit of $5.3 million and $1.6 million, respectively.  The three month periods ended December 31, 2018 and 2017 tax benefits included a provisions for income taxes for the following items: 1) taxes on the income of our foreign subsidiaries, 2) tax expense associated with the establishment of a U.S. deferred tax liability for amortizable goodwill resulting from the acquisition of Enterasys Networks, Inc., the WLAN, Campus Fabric and Data Center Businesses, 3) foreign withholding taxes, and 4) state taxes in jurisdictions where we do not have state net operating loss (NOL) carryforwards available.  The tax provision for the three months ended December 31, 2018 was offset by a tax benefit of $2.6 million resulting from the release of a valuation allowance for our Australian subsidiary’s NOLs given that entity’s consistent and sufficient profitability following recent acquisitions.  Additionally, we recorded a tax benefit of $4.7 million for the release of valuation allowances due to changes introduced by US tax legislation signed in December 2017 as discussed below.  This legislation changed the US NOL rules to afford an indefinite carryforward period for NOLs generated in tax years beginning after December 31, 2017.  In evaluating the realizability of Deferred Tax Assets (“DTAs”), historically the Company was unable to consider the Deferred Tax Liability (“DTL”) related to amortizable goodwill as a source of future income for reversing deductible differences with fixed lives.  The change to the NOL rules creates an indefinite lived DTA and as such the indefinite lived DTL related to goodwill can now be viewed as a source of income for the newly created indefinite lived DTA.  These two indefinite lived items can now be netted in determining the amount of valuation allowance needed.

[0001564590-19-001400:mdna:134]
For the three months ended December 31, 2017, we recorded a tax provision for the various items as outlined above in the amount of $0.9 million, offset by a tax benefit of $2.5 million resulting from U.S. tax legislation which reduced the corporate federal tax rate from 35% to 21%.  As a result of this change, we recognized a tax benefit associated with the revaluation of our deferred tax liability related to amortizable goodwill to reflect the lower statutory tax rate.

[0001564590-19-001400:mdna:135]
For the six months ended December 31, 2018 and 2017 we recorded a tax benefit of $3.9 million and a tax provision of $0.1 million, respectively, which consisted primarily of tax provisions on the income of our foreign subsidiaries as well as tax expense associated with the establishment of a U.S. deferred tax liability for amortizable goodwill resulting from the acquisitions of Enterasys Networks, Inc., the WLAN, Campus Fabric and Data Center Businesses.  The income tax provision for the six months ended December 31, 2018 and 2017, were offset by the valuation allowance releases and revaluation of our deferred tax liability related to the amortizable goodwill referenced above.

[0001564590-19-001400:mdna:136]
On December 22, 2017, the President of the United States signed and enacted into law H.R. 1, the Tax Cuts and Jobs Act (“TCJA”), which, except for certain provisions, was effective for tax years beginning on or after January 1, 2018. As a fiscal year taxpayer, we were not subject to the majority of the tax law provisions until fiscal year 2019; however, there were certain significant items of impact that were recognized in fiscal year 2018.  Because a change in tax law is accounted for in the period of enactment, the effects of the TCJA, a tax benefit of $2.5 million, was reflected in the second quarter of fiscal 2018. An additional impact has been reflected in the second quarter of fiscal year 2019 in the amount of $4.7 million relating to a valuation allowance release in conjunction with the finalization of evaluating the impacts of the TCJA change pursuant to SAB 118. See Note 15 to the condensed consolidated financial statements which includes a detailed discussion of the various provisions of the new U.S. tax legislation.

[0001564590-19-001400:mdna:137]
[same as prior period, unchanged from 0001564590-18-026529:mdna:125]

[0001564590-19-001400:mdna:138]
[same as prior period, unchanged from 0001564590-18-026529:mdna:126]

[0001564590-19-001400:mdna:139]
[same as prior period, unchanged from 0001564590-18-026529:mdna:127]

[0001564590-19-001400:mdna:140]
[same as prior period, unchanged from 0001564590-18-026529:mdna:128]

[0001564590-19-001400:mdna:141]
[same as prior period, unchanged from 0001564590-18-026529:mdna:129]

[0001564590-19-001400:mdna:142]
[same as prior period, unchanged from 0001564590-18-026529:mdna:130]

[0001564590-19-001400:mdna:143]
There have been no changes to our critical accounting policies since the filing of our last Annual Report on Form 10-K.

[0001564590-19-001400:mdna:144]
[same as prior period, unchanged from 0001564590-18-026529:mdna:132]

[0001564590-19-001400:mdna:145]
See Note 2 of the accompanying condensed consolidated financial statements for a full description of new accounting pronouncements, including the respective expected dates of adoption and effects on results of operations and financial condition.

[0001564590-19-001400:mdna:146]
[same as prior period, unchanged from 0001564590-18-026529:mdna:134]

[0001564590-19-001400:mdna:147]
[same as prior period, unchanged from 0001564590-18-026529:mdna:135]

[0001564590-19-001400:mdna:148]
|  |  | December 31, 2018 |  |  | June 30, 2018 |  |
| Cash |  | $ | 140,643 |  |  | $ | 121,139 |  |
| Marketable securities |  |  | 428 |  |  |  | 1,459 |  |
| Total cash and marketable securities |  | $ | 141,071 |  |  | $ | 122,598 |  |
| Working capital |  | $ | 71,369 |  |  | $ | 68,041 |  |

[0001564590-19-001400:mdna:149]
As of December 31, 2018, our principal sources of liquidity consisted of cash, cash equivalents and marketable securities of $141.1million, accounts receivable, net of $144.9 million and availability of borrowings from our five-year New Revolving Facility of $39.0 million. Our principal uses of cash include the purchase of finished goods inventory from our contract manufacturers, payroll and other operating expenses related to the development and marketing of our products, purchases of property and equipment, stock repurchase program and repayments of debt and related interest. We believe that our $141.1 million of cash and marketable securities at December 31, 2018 and the availability of borrowings from the New Revolving Facility will be sufficient to fund our principal uses of cash for at least the next 12 months.

[0001564590-19-001400:mdna:150]
On November 2, 2018, our Board of Directors announced that it had authorized management to repurchase up to $60.0 million of its common stock for two years from the date of authorization, of which $15.0 million was used for repurchases in the second quarter of fiscal 2019.  Purchases may be made from time to time in the open market or in privately negotiated transactions. The manner, timing and amount of any future purchases will be determined by the Company's management based on their evaluation of market conditions, stock price, Extreme’s ongoing determination that it is the best use of available cash and other factors. The repurchase program does not obligate Extreme to acquire any common stock, may be suspended or terminated at any time without prior notice and will be subject to regulatory considerations. During the three months ended December 31, 2018, we repurchased 2.4 million shares at an aggregate cost of $15.0 million.

[0001564590-19-001400:mdna:151]
On May 1, 2018, we entered into a Credit Agreement (the “Credit Agreement”), BMO Harris Bank N.A., as an issuing lender and swingline lender, Bank of Montreal, as administrative and collateral agent, and the financial institutions or entities that are a party thereto as lenders.  The Credit Agreement provides for i) a $40 million five-year revolving credit facility (the “New Revolving Facility”), ii) a $190 million five-year term loan (the “New Term Loan”) and, iii) an uncommitted additional incremental loan facility in the principal amount of up to $100 million (“New Incremental Facility”).  On May 1, 2018, we borrowed $200 million under the Credit Agreement.

[0001564590-19-001400:mdna:152]
Borrowings under the Credit Agreement will bear interest, at our election, as of May 1, 2018, at a rate per annum equal to LIBOR plus 1.50% to 2.75%, or the adjusted base rate plus 0.50% to 1.75%, based on our consolidated leverage ratio. In addition, we are required to pay a commitment fee of between 0.25% and 0.40% quarterly (currently 0.35%) on the unused portion of the New Revolving Facility, also based on our consolidated leverage ratio.  Principal installments are payable on the New Term Loan in varying percentages quarterly starting September 30, 2018 and to the extent not previously paid, all outstanding balances are to be paid at maturity. The obligations under the Credit Agreement is secured by substantially all of our assets.

[0001564590-19-001400:mdna:153]
Financial covenants under the Credit Agreement require us to maintain a minimum consolidated fixed charge and consolidated leverage ratio at the end of each fiscal quarter through maturity.  The Credit Agreement also includes covenants and restrictions that limit, among other things, our ability to incur additional indebtedness, create liens upon any of our property, merge, consolidate or sell all or substantially all of our assets.  The Credit Agreement also includes customary events of default which may result in acceleration of the outstanding balance.  At December 31, 2018, we were in compliance with the covenants of the Credit Agreement.

[0001564590-19-001400:mdna:154]
[same as prior period, unchanged from 0001564590-18-026529:mdna:142]

[0001564590-19-001400:mdna:155]
[same as prior period, unchanged from 0001564590-18-026529:mdna:143]

[0001564590-19-001400:mdna:156]
|  |  | Six Months Ended |  |
|  |  | December 31, 2018 |  |  | December 31, 2017 |  |
| Net cash provided by operating activities |  | $ | 61,611 |  |  | $ | 14,248 |  |
| Net cash used in investing activities |  |  | (10,413 | ) |  |  | (105,968 | ) |
| Net cash (used in) provided by financing activities |  |  | (31,329 | ) |  |  | 88,284 |  |
| Foreign currency effect on cash |  |  | (365 | ) |  |  | 94 |  |
| Net increase (decrease) in cash |  | $ | 19,504 |  |  | $ | (3,342 | ) |

[0001564590-19-001400:mdna:157]
[same as prior period, unchanged from 0001564590-18-026529:mdna:145]

[0001564590-19-001400:mdna:158]
Cash flows provided by operations in the six months ended December 31, 2018 were $61.6 million, including our net loss of $1.9 million and non-cash expenses of $38.4 million for items such as amortization of intangibles, stock-based compensation, depreciation, deferred income taxes and imputed interest.  Other sources of cash for the current quarter included a decrease in accounts receivables, inventories and increases in deferred revenues. This was partially offset by decreases in accounts payable, accrued compensation and other current and long-term liabilities, and increases in prepaid expenses and other current assets.

[0001564590-19-001400:mdna:159]
Cash flows provided by operations in the six months ended December 31, 2017 were $14.2 million, including net loss of $27.5 million and non-cash expenses of $23.1 million for items such as amortization of intangibles, stock-based compensation, depreciation, deferred income taxes, gain on bargain purchase and gain on sale of non-marketable equity investment as well as increases in accounts payable, accrued compensation, deferred revenue and other current and long-term liabilities and a decrease in prepaid expenses and other assets. This was partially offset by increases in accounts receivable and inventories.

[0001564590-19-001400:mdna:160]
[same as prior period, unchanged from 0001564590-18-026529:mdna:148]

[0001564590-19-001400:mdna:161]
Cash flows used in investing activities in the six months ended December 31, 2018 were $10.4 million which consisted of purchases of property and equipment of $11.1 million partially offset by proceeds of $0.7 million related to the sale of investments.

[0001564590-19-001400:mdna:162]
Cash flows used in investing activities in the six months ended December 31, 2017 were $106.0 million which consisted of expenditures for acquisitions of $97.6 million consisting of $69.6 million for the acquisition of the Campus Fabric Business and $29.5 million for the acquisition of the Data Center Business, less receipt of $1.6 million as final settlement of a working capital adjustment related to the WLAN Business acquisition, purchases of property and equipment of $13.3 million and proceeds of $4.9 million related to the sale of non-marketable equity investment.

[0001564590-19-001400:mdna:163]
[same as prior period, unchanged from 0001564590-18-026529:mdna:151]

[0001564590-19-001400:mdna:164]
Cash flows used in financing activities in the six months ended December 31, 2018 were $31.3 million consisting of repayments of debt totaling $14.8 million, contingent consideration of $3.9 million, and $2.0 million for deferred payments on acquisitions.  This was partially offset by $5.0 million of proceeds from the issuance of shares of our common stock under our Employee Stock Purchase Plan (“ESPP”), the exercise of stock options and net of taxes paid on vested and released stock awards.

[0001564590-19-001400:mdna:165]
Cash flows used in financing activities for the period also included repurchasing of our common shares valued at $15.0 million during the six months ended December 31, 2018, in accordance with our approved share repurchase plan. The share repurchases were executed through open market purchases, and future share repurchases may be completed through the combination of individually negotiated transactions, accelerated share buyback, and/or open market purchases. As of December 31, 2018, we have $45.0 million available under our share repurchase plan. Our Credit Facility does not contain any restrictions on the amount of borrowings that can be used to make share repurchases, as long as we are in compliance with our financial and non-financial covenants.

[0001564590-19-001400:mdna:166]
Cash flows provided by financing activities in the six months ended December 31, 2017 were $88.3 million, including new borrowings of $100.0 million to fund our acquisitions of the Campus Fabric Business and the Data Center Business, $5.6 million proceeds from issuance of shares of our common stock under our 2014 Employee Stock Purchase Plan and the exercise of stock options less $7.1 million of taxes paid on vested and released stock awards, partially offset by repayments of debt totaling $8.7 million and $1.5 million of loan fees incurred in connection with the Second Amendment of our Credit Facility.

[0001564590-19-001400:mdna:167]
[same as prior period, unchanged from 0001564590-18-026529:mdna:154]

[0001564590-19-001400:mdna:168]
Foreign currency effect on cash decreased in the six months ended December 31, 2018 and 2017, primarily due to changes in foreign currency exchange rates between the U.S. Dollar and particularly the Brazilian Real, Indian Rupee and the EURO.

[0001564590-19-001400:mdna:169]
[same as prior period, unchanged from 0001564590-18-026529:mdna:156]

[0001564590-19-001400:mdna:170]
The following summarizes our contractual obligations as of December 31, 2018, and the effect such obligations are expected to have on our liquidity and cash flow in future periods (in thousands):

[0001564590-19-001400:mdna:171]
|  |  | Total |  |  | Less than 1 Year |  |  | 1-3 years |  |  | 3-5 years |  |
| Contractual Obligations: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Debt obligations |  | $ | 185,250 |  |  | $ | 9,500 |  |  | $ | 26,125 |  |  | $ | 149,625 |  |
| Interest on debt obligations |  |  | 32,142 |  |  |  | 9,192 |  |  |  | 16,720 |  |  |  | 6,230 |  |
| Inventory purchase commitments |  |  | 172,597 |  |  |  | 172,597 |  |  |  | — |  |  |  | — |  |
| Contractual commitments |  |  | 111,625 |  |  |  | 29,375 |  |  |  | 47,000 |  |  |  | 35,250 |  |
| Non-cancellable operating lease obligations |  |  | 95,939 |  |  |  | 19,160 |  |  |  | 34,895 |  |  |  | 41,884 |  |
| Deferred payments for an acquisition |  |  | 17,000 |  |  |  | 4,000 |  |  |  | 8,000 |  |  |  | 5,000 |  |
| Contingent consideration for an acquisition |  |  | 8,649 |  |  |  | 4,068 |  |  |  | 4,581 |  |  |  | — |  |
| Other liabilities |  |  | 485 |  |  |  | 137 |  |  |  | 273 |  |  |  | 75 |  |
| Total contractual cash obligations |  | $ | 623,687 |  |  | $ | 248,029 |  |  | $ | 137,594 |  |  | $ | 238,064 |  |

[0001564590-19-001400:mdna:172]
The contractual obligations referenced above are more specifically defined as follows:

[0001564590-19-001400:mdna:173]
[same as prior period, unchanged from 0001564590-18-026529:mdna:160]

[0001564590-19-001400:mdna:174]
Inventory purchase commitments represent the purchase of long lead-time component inventory that our contract manufacturers procure in accordance with our forecast. We expect to honor the inventory purchase commitments within the next 12 months.

[0001564590-19-001400:mdna:175]
Contractual commitments to suppliers for future services.

[0001564590-19-001400:mdna:176]
[same as prior period, unchanged from 0001564590-18-026529:mdna:163]

[0001564590-19-001400:mdna:177]
[same as prior period, unchanged from 0001564590-18-026529:mdna:164]

[0001564590-19-001400:mdna:178]
[same as prior period, unchanged from 0001564590-18-026529:mdna:165]

[0001564590-19-001400:mdna:179]
[same as prior period, unchanged from 0001564590-18-026529:mdna:166]

[0001564590-19-001400:mdna:180]
[same as prior period, unchanged from 0001564590-18-026529:mdna:167]

[0001564590-19-001400:mdna:181]
We did not have any material commitments for capital expenditures as of December 31, 2018.

[0001564590-19-001400:mdna:182]
[same as prior period, unchanged from 0001564590-18-026529:mdna:169]

[0001564590-19-001400:mdna:183]
We did not have any off-balance sheet arrangements as of December 31, 2018.
