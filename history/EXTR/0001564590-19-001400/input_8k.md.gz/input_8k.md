# EXTR 8-K — 0001564590-19-001270 filed 2019-01-29

## item codes, every 8-K on or before 2019-01-30

- 2019-01-29 0001564590-19-001270 — 2.02, 9.01
- 2019-01-25 0001564590-19-001157 — 8.01, 9.01
- 2018-11-20 0001193125-18-331450 — 5.02, 9.01
- 2018-11-15 0001564590-18-029683 — 5.07
- 2018-11-02 0001564590-18-026372 — 2.02, 8.01, 9.01
- 2018-09-19 0001193125-18-276766 — 5.02
- 2018-08-08 0001564590-18-020191 — 2.02, 9.01
- 2018-06-05 0001564590-18-015067 — 3.03, 9.01
- 2018-05-08 0001564590-18-011817 — 2.02, 9.01
- 2018-05-07 0001564590-18-011264 — 1.01, 1.02, 2.03, 9.01
- 2018-02-06 0001564590-18-001403 — 2.02, 2.05, 9.01
- 2018-02-01 0001564590-18-001166 — 5.02
- 2018-01-12 0001564590-18-000462 — 9.01 — amendment of 0001193125-17-323879
- 2017-11-15 0001564590-17-023847 — 5.07
- 2017-11-07 0001564590-17-022235 — 2.02, 9.01
- 2017-11-03 0001193125-17-332828 — 9.01 — amendment of 0001193125-17-323879
- 2017-10-30 0001193125-17-323879 — 1.01, 2.01, 7.01, 9.01
- 2017-10-03 0001193125-17-302411 — 1.01, 9.01
- 2017-10-03 0001193125-17-301597 — 1.01, 1.02, 7.01, 9.01
- 2017-09-29 0001564590-17-019099 — 9.01 — amendment, the index does not say of what
- 2017-08-14 0001564590-17-017659 — 2.02, 9.01
- 2017-08-02 0001564590-17-014950 — 5.02
- 2017-07-18 0001564590-17-013557 — 1.01, 2.01, 2.03, 9.01
- 2017-06-05 0001564590-17-012126 — 3.03, 9.01
- 2017-05-03 0001564590-17-008378 — 2.02, 9.01
- 2017-03-30 0001193125-17-102344 — 1.01, 9.01
- 2017-03-07 0001193125-17-073306 — 1.01, 9.01
- 2017-02-21 0001193125-17-048182 — 5.02
- 2017-02-01 0001564590-17-000835 — 2.02, 9.01
- 2017-01-06 0001564590-17-000138 — 2.05
- 2016-11-21 0001564590-16-029539 — 5.07
- 2016-11-01 0001564590-16-026732 — 2.02, 9.01
- 2016-10-31 0001193125-16-752557 — 1.01, 2.01, 2.03
- 2016-09-15 0001193125-16-711097 — 1.01, 9.01
- 2016-08-03 0001564590-16-022347 — 2.02, 9.01
- 2016-05-19 0001564590-16-019720 — 5.02, 9.01
- 2016-05-09 0001564590-16-018660 — 3.03, 9.01
- 2016-04-27 0001564590-16-016754 — 2.02, 9.01
- 2016-02-24 0001564590-16-013189 — 8.01
- 2016-02-09 0001564590-16-012469 — 8.01
- 2016-01-28 0001564590-16-012054 — 2.02, 9.01
- 2015-11-17 0001078271-15-000136 — 5.07
- 2015-10-29 0001078271-15-000125 — 2.02, 9.01
- 2015-08-31 0001078271-15-000111 — 8.01, 9.01
- 2015-08-11 0001078271-15-000096 — 5.02
- 2015-08-06 0001078271-15-000093 — 2.02, 9.01
- 2015-06-30 0001078271-15-000089 — 1.01, 9.01
- 2015-05-20 0001078271-15-000077 — 2.05, 9.01
- 2015-05-19 0001078271-15-000075 — 3.03, 9.01
- 2015-05-06 0001078271-15-000050 — 2.02, 9.01
- 2015-05-04 0001078271-15-000048 — 5.02, 9.01
- 2015-04-29 0001078271-15-000038 — 5.02, 9.01
- 2015-04-21 0001078271-15-000034 — 5.02, 9.01
- 2015-04-09 0001078271-15-000032 — 2.02, 5.02, 9.01
- 2015-02-18 0001078271-15-000021 — 8.01
- 2015-02-17 0001078271-15-000019 — 5.02
- 2015-01-28 0001078271-15-000004 — 2.02, 9.01
- 2014-12-18 0001078271-14-000081 — 5.02, 9.01
- 2014-12-17 0001078271-14-000079 — 5.02
- 2014-11-20 0001078271-14-000075 — 1.01, 9.01
- 2014-11-17 0001078271-14-000073 — 5.07
- 2014-10-28 0001078271-14-000062 — 2.02, 9.01
- 2014-10-15 0001078271-14-000060 — 2.02, 9.01
- 2014-10-02 0001078271-14-000057 — 5.02, 9.01
- 2014-08-14 0001078271-14-000047 — 2.02, 9.01
- 2014-07-21 0001078271-14-000042 — 2.02, 9.01
- 2014-05-23 0001078271-14-000036 — 5.02, 9.01
- 2014-05-20 0001078271-14-000034 — 3.03, 9.01
- 2014-05-12 0001078271-14-000030 — 5.02
- 2014-05-08 0001078271-14-000022 — 5.02, 9.01
- 2014-05-07 0001078271-14-000018 — 2.02, 9.01 — amendment, the index does not say of what
- 2014-05-06 0001078271-14-000016 — 2.02, 9.01
- 2014-02-20 0001078271-14-000014 — 5.02, 9.01
- 2014-02-18 0001078271-14-000010 — 5.02
- 2014-02-05 0001078271-14-000006 — 2.02, 9.01
- 2014-01-13 0001104659-14-002030 — 9.01 — amendment of 0001078271-13-000058
- 2013-11-25 0001078271-13-000081 — 5.07
- 2013-11-07 0001078271-13-000064 — 5.02, 9.01
- 2013-11-04 0001078271-13-000060 — 2.02, 9.01
- 2013-11-01 0001078271-13-000058 — 1.01, 2.01, 2.03, 8.01, 9.01
- 2013-10-16 0001078271-13-000056 — 8.01, 9.01
- 2013-09-13 0001078271-13-000052 — 1.01, 8.01, 9.01
- 2013-08-23 0001078271-13-000044 — 5.02, 9.01
- 2013-08-02 0001078271-13-000042 — 5.02
- 2013-07-30 0001078271-13-000039 — 2.02, 9.01
- 2013-07-30 0001078271-13-000037 — 5.02, 9.01
- 2013-06-21 0001078271-13-000032 — 8.01
- 2013-05-01 0001078271-13-000018 — 5.02, 9.01
- 2013-04-30 0001078271-13-000015 — 2.02, 9.01
- 2013-03-01 0001078271-13-000010 — 8.01
- 2013-02-19 0001078271-13-000008 — 5.02
- 2013-01-30 0001078271-13-000004 — 2.02, 9.01
- 2013-01-07 0001078271-13-000002 — 1.01, 2.02, 2.03, 2.05, 9.01
- 2012-12-03 0001078271-12-000094 — 5.02, 5.07, 8.01
- 2012-10-31 0001078271-12-000071 — 2.02, 9.01
- 2012-10-19 0001078271-12-000069 — 1.01, 2.03, 9.01
- 2012-10-16 0001078271-12-000067 — 8.01
- 2012-10-01 0001193125-12-411392 — 5.02, 8.01, 9.01
- 2012-09-24 0001193125-12-401798 — 5.02, 9.01
- 2012-09-21 0001193125-12-399896 — 5.02, 9.01
- 2012-09-18 0001193125-12-394379 — 1.01, 5.02, 9.01
- 2012-09-12 0001193125-12-388591 — 8.01
- 2012-08-27 0001078271-12-000057 — 8.01
- 2012-08-03 0001078271-12-000041 — 7.01, 9.01
- 2012-08-01 0001078271-12-000039 — 2.02, 9.01
- 2012-07-25 0001078271-12-000037 — 8.01
- 2012-05-22 0001078271-12-000033 — 5.02, 9.01
- 2012-05-21 0001078271-12-000030 — 8.01
- 2012-05-09 0001078271-12-000028 — 5.02, 9.01
- 2012-05-02 0001078271-12-000023 — 2.02, 9.01
- 2012-04-30 0001078271-12-000020 — 3.03, 5.07, 9.01
- 2012-04-19 0001078271-12-000012 — 2.02, 5.02, 9.01
- 2012-03-12 0001078271-12-000010 — 5.02, 9.01
- 2012-02-24 0001078271-12-000008 — 8.01
- 2012-02-02 0001078271-12-000004 — 2.02, 9.01
- 2012-01-30 0001078271-12-000002 — 1.01
- 2011-12-01 0001078271-11-000104 — 8.01
- 2011-11-08 0001078271-11-000099 — 8.01
- 2011-11-02 0001078271-11-000094 — 2.02, 9.01
- 2011-10-24 0001078271-11-000089 — 8.01, 9.01
- 2011-10-11 0001078271-11-000085 — 8.01
- 2011-09-29 0001078271-11-000082 — 8.01
- 2011-09-15 0001078271-11-000070 — 5.02, 9.01
- 2011-08-11 0001078271-11-000058 — 8.01
- 2011-08-10 0001078271-11-000055 — 5.02
- 2011-08-08 0001078271-11-000045 — 5.02
- 2011-08-01 0001078271-11-000038 — 2.02, 9.01
- 2011-07-14 0001078271-11-000036 — 2.02, 2.05, 9.01
- 2011-07-12 0001078271-11-000034 — 8.01
- 2011-07-01 0001078271-11-000032 — 5.02
- 2011-06-16 0001078271-11-000030 — 8.01
- 2011-05-06 0001078271-11-000027 — 8.01, 9.01
- 2011-05-04 0001078271-11-000025 — 8.01
- 2011-04-28 0001078271-11-000020 — 2.02, 9.01
- 2011-04-27 0001078271-11-000018 — 3.03, 5.02, 5.03, 9.01
- 2011-04-11 0001078271-11-000016 — 2.02
- 2011-03-31 0001078271-11-000014 — 5.02, 5.03
- 2011-03-15 0001193125-11-066049 — 5.02, 9.01
- 2011-03-01 0001193125-11-052048 — 5.02, 9.01
- 2011-02-10 0001078271-11-000012 — 7.01, 9.01
- 2011-01-31 0001078271-11-000005 — 2.02, 5.02, 5.03, 9.01
- 2010-12-23 0001193125-10-287613 — 8.01
- 2010-12-17 0001193125-10-283495 — 5.03, 5.07, 8.01, 9.01
- 2010-11-10 0001193125-10-255861 — 4.01, 9.01
- 2010-11-01 0001193125-10-242706 — 2.02, 9.01
- 2010-10-14 0001193125-10-229518 — 1.01, 9.01
- 2010-10-06 0001193125-10-224863 — 5.02, 8.01
- 2010-09-29 0001193125-10-219705 — 1.01, 8.01
- 2010-09-08 0001193125-10-206782 — 5.02, 8.01, 9.01
- 2010-08-25 0001193125-10-196951 — 8.01
- 2010-08-09 0001193125-10-182573 — 7.01, 8.01, 9.01
- 2010-08-03 0001193125-10-175255 — 5.02, 8.01, 9.01
- 2010-08-02 0001193125-10-173697 — 2.02, 8.01, 9.01
- 2010-07-30 0001193125-10-172214 — 5.02, 8.01, 9.01
- 2010-07-22 0001193125-10-163896 — 8.01, 9.01
- 2010-07-20 0001193125-10-161832 — 5.02
- 2010-07-12 0001193125-10-157291 — 2.02, 9.01
- 2010-07-01 0001193125-10-152746 — 3.03, 9.01
- 2010-05-10 0001193125-10-114669 — 5.02, 9.01
- 2010-04-26 0001193125-10-093310 — 2.02, 9.01
- 2010-03-19 0001193125-10-061679 — 5.02, 9.01
- 2010-02-16 0001193125-10-032335 — 5.02
- 2010-02-01 0001193125-10-018202 — 2.02, 9.01
- 2010-01-29 0001193125-10-017165 — 5.02
- 2010-01-11 0001193125-10-004099 — 8.01
- 2009-10-26 0001193125-09-213846 — 2.02, 9.01 — amendment of 0001193125-09-213780
- 2009-10-26 0001193125-09-213780 — 2.02, 9.01
- 2009-10-23 0001193125-09-212871 — 2.05, 5.02, 8.01, 9.01
- 2009-10-05 0001193125-09-203522 — 2.02, 9.01
- 2009-08-04 0001193125-09-163799 — 5.02, 9.01
- 2009-07-31 0001193125-09-160772 — 5.02, 9.01
- 2009-07-30 0001193125-09-159578 — 2.02, 9.01
- 2009-07-20 0001193125-09-151500 — 5.02, 9.01
- 2009-07-08 0001193125-09-145840 — 5.02, 9.01
- 2009-05-12 0001193125-09-108340 — 5.02, 9.01
- 2009-04-23 0001193125-09-085849 — 2.02, 9.01
- 2009-03-26 0001193125-09-064502 — 2.05
- 2009-01-28 0001193125-09-013182 — 2.02, 9.01
- 2008-11-06 0001193125-08-227572 — 2.02, 9.01
- 2008-11-03 0001193125-08-222501 — 5.02
- 2008-08-11 0001193125-08-173590 — 5.02
- 2008-08-11 0001193125-08-172587 — 8.01, 9.01
- 2008-08-06 0001193125-08-167934 — 2.02, 9.01
- 2008-08-04 0001193125-08-164673 — 5.02, 9.01
- 2008-05-21 0001193125-08-119640 — 7.01, 9.01
- 2008-04-29 0001193125-08-095270 — 2.02, 9.01
- 2008-03-05 0001193125-08-047893 — 8.01
- 2008-02-19 0001193125-08-033702 — 5.02
- 2008-02-05 0001193125-08-019969 — 5.02
- 2008-01-30 0001193125-08-015378 — 2.02, 9.01
- 2007-12-27 0001193125-07-272178 — 5.03, 9.01
- 2007-10-29 0001193125-07-228368 — 2.02, 9.01
- 2007-10-25 0001193125-07-225906 — 5.02, 9.01
- 2007-10-19 0001193125-07-221578 — 5.02
- 2007-09-26 0001193125-07-207348 — 8.01
- 2007-08-07 0001193125-07-172810 — 2.02, 9.01
- 2007-08-06 0001193125-07-172147 — 5.02, 9.01
- 2007-08-06 0001193125-07-172134 — 3.01
- 2007-07-09 0001193125-07-151467 — 3.01, 9.01
- 2007-06-28 0001193125-07-145519 — 2.02, 9.01
- 2007-06-27 0001193125-07-143262 — 2.05, 3.01, 5.02
- 2007-05-18 0001193125-07-118804 — 3.01, 9.01
- 2007-05-02 0001193125-07-099280 — 2.02, 9.01
- 2007-03-29 0001193125-07-068815 — 5.02, 9.01
- 2007-02-22 0001193125-07-037181 — 3.01, 9.01
- 2007-02-08 0001193125-07-024194 — 5.02
- 2007-01-30 0001193125-07-016428 — 2.02, 9.01
- 2007-01-11 0001193125-07-004825 — 4.02, 9.01
- 2006-11-21 0001193125-06-240068 — 5.02, 9.01
- 2006-11-16 0001193125-06-237262 — 3.01, 9.01
- 2006-11-01 0001193125-06-220707 — 2.02, 9.01
- 2006-10-31 0001193125-06-219237 — 1.01, 1.02, 5.02, 5.03, 8.01, 9.01
- 2006-09-28 0001193125-06-198185 — 3.01, 9.01
- 2006-09-15 0001193125-06-191640 — 7.01, 9.01
- 2006-09-05 0001193125-06-185202 — 5.02, 9.01
- 2006-08-08 0001193125-06-165953 — 1.01, 2.02, 5.02, 9.01
- 2006-07-18 0001193125-06-148526 — 1.01
- 2006-07-10 0001193125-06-143989 — 5.02, 9.01
- 2006-05-16 0001193125-06-113698 — 5.02, 9.01
- 2006-05-01 0001193125-06-094919 — 2.02, 9.01
- 2006-04-26 0001193125-06-089397 — 1.01, 9.01
- 2006-04-07 0001193125-06-075723 — 2.02, 9.01
- 2006-02-13 0001193125-06-029073 — 1.01
- 2006-01-31 0001193125-06-016143 — 1.01
- 2006-01-30 0001193125-06-015165 — 2.02, 9.01
- 2005-12-08 0001193125-05-239157 — 1.01, 1.02, 9.01
- 2005-11-01 0001193125-05-213101 — 2.02, 9.01
- 2005-09-29 0001193125-05-193991 — 1.01, 2.02, 9.01 — amendment of 0001193125-05-162807
- 2005-08-09 0001193125-05-162807 — 1.01, 2.02, 9.01
- 2005-07-14 0001193125-05-142162 — 8.01
- 2005-06-28 0001193125-05-133050 — 1.01, 9.01
- 2005-04-18 0001193125-05-077946 — 2.02, 7.01, 9.01
- 2005-04-14 0001193125-05-076665 — 2.02, 7.01, 9.01
- 2005-01-25 0001193125-05-011466 — 2.02, 9.01
- 2004-12-07 0001193125-04-208693 — 3.01
- 2004-10-26 0001193125-04-178370 — 2.02, 9.01
- 2004-10-04 0001193125-04-166289 — 5.02, 9.01
- 2004-07-28 0001193125-04-126135 — 12, 7
- 2004-05-12 0001193125-04-086287 — 12
- 2004-04-21 0001193125-04-066557 — 12, 7
- 2004-01-22 0001193125-04-007359 — 12, 7
- 2003-12-18 0001193125-03-096351 — 5, 7
- 2003-11-04 0001193125-03-072069 — 5, 7
- 2003-10-24 0001193125-03-066551 — 12, 7
- 2003-07-25 0001193125-03-024087 — 7, 9
- 2003-04-11 0001012870-03-001706 — 7, 9
- 2003-04-08 0001021408-03-005743 — 7, 9
- 2003-01-07 0001012870-03-000039 — 5, 7
- 2002-04-29 0001012870-02-002003 — 5, 7
- 2002-02-20 0001012870-02-000792 — 5, 7
- 2001-12-13 0001012870-01-503160 — 5, 7
- 2001-11-30 0001012870-01-503010 — 5, 7
- 2001-11-02 0001012870-01-502580 — 5
- 2001-10-23 0001021408-01-508589 — 5, 7
- 2001-06-07 0001021408-01-501772 — 5, 7 — amendment of 0001021408-01-500975
- 2001-05-15 0001021408-01-501104 — 5 — amendment of 0001021408-01-500975
- 2001-05-14 0001021408-01-500975 — 5, 7
- 2001-04-06 0001012870-01-500065 — 5, 7

## late-filing notifications on or before 2019-01-30

- 2008-05-12 0001193125-08-111540 — NT 10-Q, for the period ended 2008-03-30
- 2007-05-10 0001193125-07-110075 — NT 10-Q, for the period ended 2007-04-01
- 2007-02-09 0001193125-07-025490 — NT 10-Q, for the period ended 2006-12-31
- 2006-11-13 0001193125-06-232090 — NT 10-Q, for the period ended 2006-10-01
- 2006-09-15 0001193125-06-191838 — NT 10-K, for the period ended 2006-07-02

## item 2.02 — earnings release, exhibit 99.1

[0001564590-19-001270:8k_2_02:1]
EX-99.1
2
extr-ex991_6.htm
EX-99.1

[0001564590-19-001270:8k_2_02:2]
extr-ex991_6.htm

[0001564590-19-001270:8k_2_02:3]
Exhibit 99.1

[0001564590-19-001270:8k_2_02:4]
FOR IMMEDIATE RELEASE

[0001564590-19-001270:8k_2_02:5]
| For more information, contact: |  |  |
| Investor Relations Stan Kovler |  | Media Contact Christi Nicolacopoulos |
| 919/595-4196 |  | 603/952-5005 |
| Investor_relations@extremenetworks.com |  | pr@extremenetworks.com |

[0001564590-19-001270:8k_2_02:6]
Extreme Networks Reports Second Quarter Fiscal Year 2019 Financial Results

[0001564590-19-001270:8k_2_02:7]
SAN JOSE, Calif., January 29, 2019 -- Extreme Networks, Inc. (“Extreme”) (Nasdaq: EXTR) today released financial results for its fiscal second quarter ended December 31, 2018.

[0001564590-19-001270:8k_2_02:8]
Fiscal Second Quarter Results:

[0001564590-19-001270:8k_2_02:9]
|  | • | Revenue $252.7 million, up 9% year-over-year and up 5% quarter-over-quarter. |

[0001564590-19-001270:8k_2_02:10]
|  | • | GAAP gross margin 55.9% compared to 55.8%, in Q2 last year. |

[0001564590-19-001270:8k_2_02:11]
|  | • | Non-GAAP gross margin 58.2% compared to 59.4%, in Q2 last year. |

[0001564590-19-001270:8k_2_02:12]
|  | • | GAAP operating margin 1.9% compared to (13.5)%, in Q2 last year. |

[0001564590-19-001270:8k_2_02:13]
|  | • | Non-GAAP operating margin 8.0%, compared to 8.8%, in Q2 last year. |

[0001564590-19-001270:8k_2_02:14]
|  | • | Free Cash Flow* $23.6 million before share buyback and $8.6 million after share buyback. |

[0001564590-19-001270:8k_2_02:15]
“We are pleased to report revenue above the high-end of our guidance range and demonstrate sequential growth. Our results were driven by cross-selling and the adoption of our Smart OmniEdge, Automated Campus, and Agile Data Center solutions pillars that make up our end to end software-driven solutions across geographies and industry verticals.  We also saw a modest increase in demand during the quarter as a result of our November 1st price increase. Separately, we reaffirmed our commitment to accretive use of our cash by completing $15 million worth of our share repurchase program during the quarter,” stated Ed Meyercord, President and CEO of Extreme Networks.

[0001564590-19-001270:8k_2_02:16]
Executive Vice President and CFO Rémi Thomas added, “We are reaffirming our outlook for FY19 to exceed $1 billion in revenue. Following the strong cash flow resulting from exceptional linearity during the quarter and some forward buying that drove outperformance of our second quarter results, we expect our revenue and gross margin for the third quarter to be comparable to our second quarter results. We continue to target improving our net cash position throughout the fiscal year and are in a solid position for growth and continued long-term gross margin improvement.”

[0001564590-19-001270:8k_2_02:17]
Meyercord concluded, “Looking ahead, our strong roadmap and improved execution, combined with the digital transformation initiatives we are undertaking internally, will enable us to drive productivity and operational efficiencies in the second half of our fiscal year. We look forward to an in-depth review of our vision, strategy and operating initiatives at our Investor Day conference on February 13, 2019.”

[0001564590-19-001270:8k_2_02:18]
Recent Key Highlights:

[0001564590-19-001270:8k_2_02:19]
|  | • | University of Central Arkansas required a strong, secure network infrastructure to fully support plans for its Arkansas Coding Academy and to achieve their goal of being a “Technology First |

[0001564590-19-001270:8k_2_02:20]
|  |  | University”. The university selected Extreme Automated Campus™ solutions, including Extreme Fabric Connect™ and Extreme Cloud Appliance, to implement a complete networking solution for their campus of 124 buildings, spread across 356 acres, populated by 11,350 students and 16 NCAA Division I varsity teams. Extreme management, control and analytics software have streamlined network management for the UCA IT team, eliminating strain and the potential for errors. |

[0001564590-19-001270:8k_2_02:21]
|  | • | The City of Memphis (Tennessee), the 22nd largest US city by land area and with over 8,000 city employees, selected Extreme’s switching, management and analytics technology, part of its Automated Campus™ solution, as well as Extreme Professional Services, to power its new Smart City infrastructure. Initial deployments will enable AI-powered IP camera implementations at 27 community centers to provide real-time anomaly detection and will eventually extend to other parts of the community, including police, fire and highway departments as the city continues its digital transformation. The City valued Extreme’s Fabric Connect™ technology, which allows for network segmentation for secure user and device access. |

[0001564590-19-001270:8k_2_02:22]
|  | • | University of Pittsburgh Athletics Department, part of the ACC Conference, deployed Extreme’s Smart OmniEdge™ solutions to provide wireless connectivity in its 12,000-seat arena that hosts men's and women's basketball and volleyball, along with concerts and other events. Extreme’s switching and mobility technology, and control software, supported by ExtremeWorks™ maintenance services, provide the intelligence, security and adaptability required to improve the fan experience, and provide a platform for new fan engagement applications and virtual reality experiences during events. |

[0001564590-19-001270:8k_2_02:23]
|  | • | Chicago Cubs, the 2016 World Series baseball champions, deployed Extreme’s Smart OmniEdge solution at Wrigley Field to expand Wi-Fi capacity into new areas of the stadium. Extreme technology is supporting Project 1060, a multi-phase renovation project on the 104-year-old ballpark, which is the second-oldest ballpark in professional baseball. Technology deployed includes access points, switching, Extreme Management Center™ software, control and analytics applications. Extreme is also providing maintenance support and professional services. |

[0001564590-19-001270:8k_2_02:24]
|  | • | Forsyth County School District is the 7th largest K-12 school district in Georgia serving 38 schools, 49,200 students, and is the largest employer in its county with over 4,100 full-time employees and 1,500 substitutes. Forsyth schools deployed Extreme Automated Campus and Smart OmniEdge solutions, including wireless, switching, Extreme Management Center software and control applications, along with professional services, that allow just 2 network engineers to support 100,000 unique devices simultaneously across 42 locations. With an Extreme-powered network, Forsyth can accommodate an influx of nearly 1,500 students a year and remain one of the most forward-looking school systems in the country, offering a full virtual academy and remote classes to minimize days off due to inclement weather, as well as VR/AR, robotics, STEM initiatives, online testing with wireless student devices, and an eSports program. |

[0001564590-19-001270:8k_2_02:25]
|  | • | Extreme Networks launched new hardware and software in Extreme's Agile Data Center™ solution that provide organizations with the tools they need to embrace cross-domain IT automation, management, visibility and analytics in any vendor environment. New SLX 9030 leaf switches, designed for enhanced Top of Rack switching, and the SLX 9640 router for scalable, |

[0001564590-19-001270:8k_2_02:26]
|  |  | high performance border routing and data center interconnect (DCI), strengthen an already robust and comprehensive portfolio. |

[0001564590-19-001270:8k_2_02:27]
|  | • | Extreme Networks, Inc was named November 2018 Gartner Peer Insights Customers’ Choice for Wired and Wireless LAN Access Infrastructure.* Gartner defines Wired and Wireless LAN access infrastructure vendors as those supplying wired and wireless networking hardware and software that enables devices to connect to the enterprise wired LAN or Wi-Fi network. The Gartner Peer Insights Customers' Choice distinction is based on feedback and ratings from end-user professionals who have experience purchasing, implementing and/or using the product or service. Users praised our advanced technology, ease of implementation and our customer support in the latest Peer Insights ranking. |

[0001564590-19-001270:8k_2_02:28]
* Gartner Peer Insights Customers' Choice constitute the subjective opinions of individual end-user reviews, ratings, and data applied against a documented methodology; they neither represent the views of, nor constitute an endorsement by, Gartner or its affiliates.

[0001564590-19-001270:8k_2_02:29]
The Gartner Report(s) described herein, (the "Gartner Report(s)") represent(s) research opinion or viewpoints published, as part of a syndicated subscription service, by Gartner, Inc. ("Gartner"), and are not representations of fact. Each Gartner Report speaks as of its original publication date (and not as of the date of this press release) and the opinions expressed in the Gartner Report(s) are subject to change without notice.

[0001564590-19-001270:8k_2_02:30]
Fiscal Q2 2019 Financial Metrics:

[0001564590-19-001270:8k_2_02:31]
(in millions, except percentages ad per share information)

[0001564590-19-001270:8k_2_02:32]
|  |  | Q2 FY'19 |  |  | Q2 FY'18 |  |  | Change |  |
| GAAP Results of Operations |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 189.6 |  |  | $ | 174.8 |  |  | $ | 14.8 |  |  |  | 8 | % |
| Service |  |  | 63.1 |  |  |  | 56.3 |  |  |  | 6.8 |  |  |  | 12 | % |
| Total Net Revenue |  | $ | 252.7 |  |  | $ | 231.1 |  |  | $ | 21.6 |  |  |  | 9 | % |
| Gross Margin |  |  | 55.9 | % |  |  | 55.8 | % |  | 10 bps |  |  | - |  |
| Operating Margin |  |  | 1.9 | % |  |  | (13.5 | )% |  | 1538 bps |  |  | - |  |
| Net Income (Loss) |  | $ | 7.2 |  |  | $ | (31.9 | ) |  | $ | 39.1 |  |  | - |  |
| Income (Loss) per diluted share |  | $ | 0.06 |  |  | $ | (0.28 | ) |  | $ | 0.34 |  |  | - |  |
| Non-GAAP Results of Operations |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 189.6 |  |  | $ | 174.8 |  |  | $ | 14.8 |  |  |  | 8 | % |
| Service |  |  | 63.1 |  |  |  | 56.3 |  |  |  | 6.8 |  |  |  | 12 | % |
| Total Net Revenue |  | $ | 252.7 |  |  | $ | 231.1 |  |  | $ | 21.6 |  |  |  | 9 | % |
| Gross Margin |  |  | 58.2 | % |  |  | 59.4 | % |  | -120 bps |  |  | - |  |
| Operating Margin |  |  | 8.0 | % |  |  | 8.8 | % |  | -80 bps |  |  | - |  |
| Net Income |  | $ | 15.5 |  |  | $ | 16.4 |  |  | $ | (0.9 | ) |  |  | (6 | )% |
| Income per diluted share |  | $ | 0.13 |  |  | $ | 0.14 |  |  | $ | (0.01 | ) |  |  | (7 | )% |

[0001564590-19-001270:8k_2_02:33]
|  | • | Cash and investments ended the quarter at $141.1 million. This was flat from Q1 and an increase of $12.9 million from Q2 last year, driven primarily by higher cash collections from the acquisition of the Campus Fabric and Data Center businesses. |

[0001564590-19-001270:8k_2_02:34]
|  | • | Accounts receivable balance ending Q2 was $144.9 million, with days sales outstanding of 53. |

[0001564590-19-001270:8k_2_02:35]
|  | • | Q2 ending inventory was $58.3 million, an increase of $2.7 million from Q1 and a decrease of $25.1 million from Q2 last year. |

[0001564590-19-001270:8k_2_02:36]
|  | • | Q2 ending debt was $185.3 million, a decrease of $2.3 million from Q1 and an increase of $2.2 million from Q2 last year. Net Debt** decreased to $44.6 million from $47.5 million from Q1. |

[0001564590-19-001270:8k_2_02:37]
Business Outlook:

[0001564590-19-001270:8k_2_02:38]
For its third quarter of fiscal 2019, ending March 31, 2019, the Company is targeting revenue in a range of $247.0 million to $257.0 million.  GAAP gross margin is targeted between 55.2% and 57.3% and non-GAAP gross margin is targeted between 57.5% and 59.5%. Operating expenses are targeted to be between $139.7 million and $143.0 million on a GAAP basis and $129.9 million to $133.2 million on a non-GAAP basis. GAAP earnings are targeted to be between a net loss of $8.3 million to $0.7 million or $0.07 to $0.01 per basis share.  Non-GAAP net income earnings are targeted in a range of $7.2 million to $14.9 million, or $0.06 to $0.13 per diluted share. The GAAP and non-GAAP per share targets are based on 117.1 million and 119.6 million weighted shares outstanding, respectively.

[0001564590-19-001270:8k_2_02:39]
The following table shows the GAAP to non-GAAP reconciliation for Q3 FY’19 guidance:

[0001564590-19-001270:8k_2_02:40]
|  | Gross Margin Rate |  |  | Operating Margin Rate |  |  | Earnings per Share |  |
| GAAP | 55.2% - 57.3% |  |  | (1.3)% - 1.7% |  |  | ($0.07) - ($0.01) |  |
| Estimated adjustments for: |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of product intangibles | 1.9% |  |  | 1.9% |  |  | $ | 0.04 |  |
| Stock based compensation | 0.4% |  |  | 3.5% |  |  | $ | 0.07 |  |
| Amortization of non product intangibles | - |  |  | 0.8% |  |  | $ | 0.02 |  |
| Non-GAAP | 57.5% - 59.5% |  |  | 4.9% - 7.7% |  |  | $0.06 - $0.13 |  |

[0001564590-19-001270:8k_2_02:41]
The total of percentage rate changes may not equal the total change in all cases due to rounding.

[0001564590-19-001270:8k_2_02:42]
*Free Cash Flow is defined as Operating Cash Flow – Capex

[0001564590-19-001270:8k_2_02:43]
**Net Debt is defined as Cash and Equivalents – Total Long-Term Debt

[0001564590-19-001270:8k_2_02:44]
Conference Call:

[0001564590-19-001270:8k_2_02:45]
Extreme will host a conference call at 8:30 a.m. Eastern (5:30 a.m. Pacific) today to review the second fiscal quarter results as well as the business outlook for third fiscal quarter ending March 31, 2019, including significant factors and assumptions underlying the targets noted above. The conference call will be available to the public through a live audio web broadcast via the internet at http://investor.extremenetworks.com and a replay of the call will be available on the website through February 5, 2019.  The conference call may also be heard by dialing 1(877) 303-9826 or international 1 (224) 357-2194. Supplemental financial information to be discussed during the conference call will be posted in the Investor Relations section of the Company's website www.extremenetworks.com including the non-GAAP reconciliation attached to this press release. The encore recording can be accessed by

[0001564590-19-001270:8k_2_02:46]
dialing 1 (855) 859-2056 or international 1 (404) 537-3406. Conference ID # 6482218. The encore recording will be available for 7 days following the call.

[0001564590-19-001270:8k_2_02:47]
About Extreme Networks:

[0001564590-19-001270:8k_2_02:48]
Extreme Networks, Inc. (EXTR) delivers software-driven solutions from the enterprise edge to the cloud that are agile, adaptive, and secure to enable digital transformation. Our 100% in-sourced services and support are number one in the industry. Even with 30,000 customers globally, including half of the Fortune 50 and some of the world's leading names in business, hospitality, retail, transportation and logistics, education, government, healthcare and manufacturing, we remain nimble and responsive to ensure customer and partner success. We call this Customer-Driven Networking™. Founded in 1996, Extreme is headquartered in San Jose, California. For more information, visit Extreme's  website or call 1-888-257-3000.

[0001564590-19-001270:8k_2_02:49]
Extreme Networks and the Extreme Networks logo are either trademarks or registered trademarks of Extreme Networks, Inc. in the United States and/or other countries.

[0001564590-19-001270:8k_2_02:50]
Non-GAAP Financial Measures:

[0001564590-19-001270:8k_2_02:51]
Extreme provides all financial information required in accordance with generally accepted accounting principles (“GAAP”). The Company is providing with this press release non-GAAP gross margins, non-GAAP operating margins, non-GAAP operating expenses, non-GAAP net income and non-GAAP earnings per share. In preparing non-GAAP information, the Company has excluded, where applicable, the impact of share-based compensation, acquisition and integration costs, acquired inventory adjustments, amortization of acquired intangibles, restructuring charges, gain on sale of equity investment and income tax.  The Company believes that excluding these items provides both management and investors with additional insight into its current operations, the trends affecting the Company, the Company's marketplace performance, and the Company's ability to generate cash from operations. Please note the Company's non-GAAP measures may be different than those used by other companies. The additional non-GAAP financial information the Company presents should be considered in conjunction with, and not as a substitute for, the Company's GAAP financial information.

[0001564590-19-001270:8k_2_02:52]
The Company has provided a non-GAAP reconciliation of the results for the periods presented in this release, which are adjusted to exclude certain items as indicated.  These measures should only be used to evaluate the Company's results of operations in conjunction with the corresponding GAAP measures for comparable financial information and understanding of the Company's ongoing performance as a business. Extreme Networks uses both GAAP and non-GAAP measures to evaluate and manage its operations.

[0001564590-19-001270:8k_2_02:53]
Forward Looking Statements:

[0001564590-19-001270:8k_2_02:54]
to achieve targeted revenues and forecasted demand from end customers; a highly competitive business environment for network switching equipment; our effectiveness in controlling expenses; the possibility that we might experience delays in the development or introduction of new technology and products; customer response to our new technology and products; risks related to pending or future litigation; and a dependency on third parties for certain components and for the manufacturing of our products.

[0001564590-19-001270:8k_2_02:55]
More information about potential factors that could affect the Company's business and financial results are described in "Management's Discussion and Analysis of Financial Condition and Results of Operations" and "Risk Factors" included in the Company’s Quarterly Report on Form 10-Q for the three months ended September 30, 2018 and Annual Report on Form 10-K for the year ended June 30, 2018 and other documents of the Company on file with the Securities and Exchange Commission (available at www.sec.gov).  Except as required under the U.S. federal securities laws and the rules and regulations of the U.S. Securities and Exchange Commission, Extreme Networks disclaims any obligation to update any forward-looking statements after the date of this release, whether as a result of new information, future events, developments, changes in assumptions or otherwise.

[0001564590-19-001270:8k_2_02:56]
EXTREME NETWORKS, INC.

[0001564590-19-001270:8k_2_02:57]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0001564590-19-001270:8k_2_02:58]
(In thousands)

[0001564590-19-001270:8k_2_02:59]
(Unaudited)

[0001564590-19-001270:8k_2_02:60]
|  |  | December 31, 2018 |  |  | June 30, 2018 |  |
| ASSETS |  |  |  |  |  |  |  |  |
| Current assets: |  |  |  |  |  |  |  |  |
| Cash |  | $ | 140,643 |  |  | $ | 121,139 |  |
| Accounts receivable, net of allowance for doubtful accounts of $1,678 at December 31, 2018 and $1,478 at June 30, 2018 |  |  | 144,909 |  |  |  | 212,423 |  |
| Inventories |  |  | 58,297 |  |  |  | 63,867 |  |
| Prepaid expenses and other current assets |  |  | 39,088 |  |  |  | 30,484 |  |
| Total current assets |  |  | 382,937 |  |  |  | 427,913 |  |
| Property and equipment, net |  |  | 74,499 |  |  |  | 78,519 |  |
| Intangible assets, net |  |  | 63,544 |  |  |  | 77,092 |  |
| Goodwill |  |  | 137,799 |  |  |  | 139,082 |  |
| Other assets |  |  | 53,170 |  |  |  | 47,642 |  |
| Total assets |  | $ | 711,949 |  |  | $ | 770,248 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |  |  |  |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |  |  |  |
| Current portion of long-term debt |  | $ | 9,009 |  |  | $ | 9,007 |  |
| Accounts payable |  |  | 34,977 |  |  |  | 75,689 |  |
| Accrued compensation and benefits |  |  | 46,500 |  |  |  | 50,351 |  |
| Accrued warranty |  |  | 12,808 |  |  |  | 12,807 |  |
| Deferred revenue, net |  |  | 138,239 |  |  |  | 130,865 |  |
| Other accrued liabilities |  |  | 70,035 |  |  |  | 81,153 |  |
| Total current liabilities |  |  | 311,568 |  |  |  | 359,872 |  |
| Deferred revenue, less current portion |  |  | 47,854 |  |  |  | 43,660 |  |
| Long-term debt, less current portion |  |  | 174,246 |  |  |  | 188,749 |  |
| Deferred income taxes |  |  | 1,699 |  |  |  | 6,135 |  |
| Other long-term liabilities |  |  | 60,711 |  |  |  | 59,100 |  |
| Commitments and contingencies |  |  | — |  |  |  | — |  |
| Stockholders’ equity: |  |  |  |  |  |  |  |  |
| Convertible preferred stock, $.001 par value, issuable in series, 2,000 shares authorized; none issued |  |  | — |  |  |  | — |  |
| Common stock, $.001 par value, 750,000 shares authorized; 119,089 and 116,124 shares issued, respectively; 116,723 and 116,124 shares outstanding, respectively |  |  | 119 |  |  |  | 116 |  |
| Additional paid-in-capital |  |  | 962,924 |  |  |  | 942,397 |  |
| Accumulated other comprehensive loss |  |  | (2,725 | ) |  |  | (1,703 | ) |
| Accumulated deficit |  |  | (829,447 | ) |  |  | (828,078 | ) |
| Treasury stock at cost: 2,366 and 0 shares, respectively |  |  | (15,000 | ) |  |  | — |  |
| Stockholders’ equity |  |  | 115,871 |  |  |  | 112,732 |  |
| Total liabilities and stockholders’ equity |  | $ | 711,949 |  |  | $ | 770,248 |  |

[0001564590-19-001270:8k_2_02:61]
EXTREME NETWORKS, INC.

[0001564590-19-001270:8k_2_02:62]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS

[0001564590-19-001270:8k_2_02:63]
(In thousands, except per share amounts)

[0001564590-19-001270:8k_2_02:64]
(Unaudited)

[0001564590-19-001270:8k_2_02:65]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | December 31, 2018 |  |  | December 31, 2017 |  |  | December 31, 2018 |  |  | December 31, 2017 |  |
| Net revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 189,567 |  |  | $ | 174,850 |  |  | $ | 367,287 |  |  | $ | 339,624 |  |
| Service |  |  | 63,113 |  |  |  | 56,273 |  |  |  | 125,279 |  |  |  | 103,214 |  |
| Total net revenues |  |  | 252,680 |  |  |  | 231,123 |  |  |  | 492,566 |  |  |  | 442,838 |  |
| Cost of revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  |  | 86,487 |  |  |  | 78,472 |  |  |  | 170,030 |  |  |  | 158,517 |  |
| Service |  |  | 24,894 |  |  |  | 23,665 |  |  |  | 49,166 |  |  |  | 42,954 |  |
| Total cost of revenues |  |  | 111,381 |  |  |  | 102,137 |  |  |  | 219,196 |  |  |  | 201,471 |  |
| Gross profit: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  |  | 103,080 |  |  |  | 96,378 |  |  |  | 197,257 |  |  |  | 181,107 |  |
| Service |  |  | 38,219 |  |  |  | 32,608 |  |  |  | 76,113 |  |  |  | 60,260 |  |
| Total gross profit |  |  | 141,299 |  |  |  | 128,986 |  |  |  | 273,370 |  |  |  | 241,367 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Research and development |  |  | 52,204 |  |  |  | 45,907 |  |  |  | 103,445 |  |  |  | 80,192 |  |
| Sales and marketing |  |  | 68,342 |  |  |  | 65,659 |  |  |  | 135,924 |  |  |  | 121,220 |  |
| General and administrative |  |  | 13,886 |  |  |  | 11,669 |  |  |  | 26,657 |  |  |  | 23,854 |  |
| Acquisition and integration costs, net of bargain purchase gain |  |  | 67 |  |  |  | 34,115 |  |  |  | 2,613 |  |  |  | 38,359 |  |
| Restructuring charges, net of reversals |  |  | 474 |  |  |  | — |  |  |  | 1,282 |  |  |  | — |  |
| Amortization of intangibles |  |  | 1,575 |  |  |  | 2,746 |  |  |  | 3,716 |  |  |  | 4,360 |  |
| Total operating expenses |  |  | 136,548 |  |  |  | 160,096 |  |  |  | 273,637 |  |  |  | 267,985 |  |
| Operating income (loss) |  |  | 4,751 |  |  |  | (31,110 | ) |  |  | (267 | ) |  |  | (26,618 | ) |
| Interest income |  |  | 643 |  |  |  | 717 |  |  |  | 1,037 |  |  |  | 1,364 |  |
| Interest expense |  |  | (3,066 | ) |  |  | (2,504 | ) |  |  | (6,592 | ) |  |  | (4,719 | ) |
| Other (expense) income, net |  |  | (399 | ) |  |  | (643 | ) |  |  | 88 |  |  |  | 2,484 |  |
| Income (loss) before income taxes |  |  | 1,929 |  |  |  | (33,540 | ) |  |  | (5,734 | ) |  |  | (27,489 | ) |
| (Benefit ) provision for income taxes |  |  | (5,270 | ) |  |  | (1,617 | ) |  |  | (3,868 | ) |  |  | 58 |  |
| Net income (loss) |  | $ | 7,199 |  |  | $ | (31,923 | ) |  | $ | (1,866 | ) |  | $ | (27,547 | ) |
| Basic and diluted net (loss) income per share: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income (loss) per share - basic |  | $ | 0.06 |  |  | $ | (0.28 | ) |  | $ | (0.02 | ) |  | $ | (0.24 | ) |
| Net income (loss) per share - diluted |  | $ | 0.06 |  |  | $ | (0.28 | ) |  | $ | (0.02 | ) |  | $ | (0.24 | ) |
| Shares used in per share calculation - basic |  |  | 117,544 |  |  |  | 113,621 |  |  |  | 117,456 |  |  |  | 112,931 |  |
| Shares used in per share calculation - diluted |  |  | 119,544 |  |  |  | 113,621 |  |  |  | 117,456 |  |  |  | 112,931 |  |

[0001564590-19-001270:8k_2_02:66]
EXTREME NETWORKS, INC.

[0001564590-19-001270:8k_2_02:67]
CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS

[0001564590-19-001270:8k_2_02:68]
(In thousands)

[0001564590-19-001270:8k_2_02:69]
(Unaudited)

[0001564590-19-001270:8k_2_02:70]
|  |  | Six Months Ended |  |
|  |  | December 31, 2018 |  |  | December 31, 2017 |  |
| Cash flows from operating activities: |  |  |  |  |  |  |  |  |
| Net loss |  | $ | (1,866 | ) |  | $ | (27,547 | ) |
| Adjustments to reconcile net loss to net cash provided by operating activities: |  |  |  |  |  |  |  |  |
| Depreciation |  |  | 13,476 |  |  |  | 8,093 |  |
| Amortization of intangible assets |  |  | 13,552 |  |  |  | 11,023 |  |
| Provision for doubtful accounts |  |  | 861 |  |  |  | 1,180 |  |
| Stock-based compensation |  |  | 15,525 |  |  |  | 11,828 |  |
| Deferred income taxes |  |  | (6,516 | ) |  |  | (2,135 | ) |
| Unrealized/realized (gain) loss on equity investment |  |  | 274 |  |  |  | (3,757 | ) |
| Realized gain on sale of non-marketable equity investment |  |  | - |  |  |  | (4,920 | ) |
| Non-cash interest |  |  | 1,532 |  |  |  | 510 |  |
| Other non-cash items |  |  | (344 | ) |  |  | 1,308 |  |
| Changes in operating assets and liabilities, net of acquisitions |  |  |  |  |  |  |  |  |
| Accounts receivable |  |  | 66,568 |  |  |  | (11,188 | ) |
| Inventories |  |  | 5,570 |  |  |  | (449 | ) |
| Prepaid expenses and other assets |  |  | (12,390 | ) |  |  | 1,188 |  |
| Accounts payable |  |  | (40,050 | ) |  |  | 17,547 |  |
| Accrued compensation and benefits |  |  | (3,851 | ) |  |  | 3,734 |  |
| Deferred revenue |  |  | 11,568 |  |  |  | 4,446 |  |
| Other current and long-term liabilities |  |  | (2,298 | ) |  |  | 3,387 |  |
| Net cash provided by operating activities |  |  | 61,611 |  |  |  | 14,248 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |
| Capital expenditures |  |  | (11,140 | ) |  |  | (13,309 | ) |
| Business acquisitions |  |  | — |  |  |  | (97,581 | ) |
| Proceeds from sale of investment |  |  | 727 |  |  |  | 4,922 |  |
| Net cash used in investing activities |  |  | (10,413 | ) |  |  | (105,968 | ) |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |
| Borrowings under Term Loan |  |  | — |  |  |  | 100,000 |  |
| Loan fees on borrowings |  |  | (545 | ) |  |  | (1,494 | ) |
| Repayments of debt |  |  | (14,750 | ) |  |  | (8,686 | ) |
| Repurchase of stock |  |  | (15,000 | ) |  |  | — |  |
| Proceeds from issuance of common stock, net of tax withholding |  |  | 5,005 |  |  |  | (1,536 | ) |
| Capital lease financing |  |  | (183 | ) |  |  | — |  |
| Contingent consideration obligations |  |  | (3,856 | ) |  |  | — |  |
| Deferred payments on an acquisition |  |  | (2,000 | ) |  |  | — |  |
| Net cash (used in) provided by financing activities |  |  | (31,329 | ) |  |  | 88,284 |  |
| Foreign currency effect on cash |  |  | (365 | ) |  |  | 94 |  |
| Net increase (decrease) in cash |  |  | 19,504 |  |  |  | (3,342 | ) |
| Cash and cash equivalents at beginning of period |  |  | 121,139 |  |  |  | 130,450 |  |
| Cash and cash equivalents at end of period |  | $ | 140,643 |  |  | $ | 127,108 |  |

[0001564590-19-001270:8k_2_02:71]
Extreme Networks, Inc.

[0001564590-19-001270:8k_2_02:72]
Non-GAAP Measures of Financial Performance

[0001564590-19-001270:8k_2_02:73]
To supplement the Company's consolidated financial statements presented in accordance with generally accepted accounting principles, ("GAAP"), Extreme Networks uses non-GAAP measures of certain components of financial performance.  These non-GAAP measures include non-GAAP net income, non-GAAP earnings per diluted share, non-GAAP gross margin, non-GAAP operating expenses and free cash flow.

[0001564590-19-001270:8k_2_02:74]
Reconciliation to the nearest GAAP measure of all historical non-GAAP measures included in this press release can be found in the tables included with this press release.  In this press release, Extreme Networks also presents its target for non-GAAP expenses, which is expenses less share-based compensation expense, acquisition and integration costs, acquired inventory adjustments, restructuring charges, amortization of acquired intangibles, gain on sale of equity investment and income tax.

[0001564590-19-001270:8k_2_02:75]
Non-GAAP measures presented in this press release are not in accordance with or alternative measures prepared in accordance with GAAP and may be different from non-GAAP measures used by other companies.  In addition, these non-GAAP measures are not based on any comprehensive set of accounting rules or principles.  Non-GAAP measures have limitations in that they do not reflect all of the amounts associated with Extreme Networks' results of operations as determined in accordance with GAAP.  These non-GAAP measures should only be used to evaluate Extreme Networks' results of operations in conjunction with the corresponding GAAP measures.

[0001564590-19-001270:8k_2_02:76]
Extreme believes these non-GAAP measures when shown in conjunction with the corresponding GAAP measures to enhance investors' and management's overall understanding of the Company's current financial performance and the Company's prospects for the future, including cash flows available to pursue opportunities to enhance shareholder value.  In addition, because Extreme Networks has historically reported certain non-GAAP results to investors, the Company believes the inclusion of non-GAAP measures provides consistency in the Company's financial reporting.

[0001564590-19-001270:8k_2_02:77]
For its internal planning process, and as discussed further below, Extreme's management uses financial statements that do not include share-based compensation expense, acquisition and integration costs, acquired inventory adjustment, amortization of intangibles, restructuring charges, gain on sale of equity investment and income tax.  Extreme’s management also uses non-GAAP measures, in addition to the corresponding GAAP measures, in reviewing the Company's financial results.

[0001564590-19-001270:8k_2_02:78]
As described above, Extreme excludes the following items from one or more of its non-GAAP measures when applicable.

[0001564590-19-001270:8k_2_02:79]
Share-based compensation. This expense consists of expenses for stock options, restricted stock and employee stock purchases through its ESPP.  Extreme Networks excludes share-based compensation expenses from its non-GAAP measures primarily because they are non-cash expenses that the Company does not believe are reflective of ongoing cash requirement related to operating results. Extreme Networks expects to incur share-based compensation expenses in future periods.

[0001564590-19-001270:8k_2_02:80]
Acquisition and integration costs. Acquisition and integration costs consist of legal and professional fees related to the acquisition of a) Campus Fabric business, b) Data Center business and c) the bargain

[0001564590-19-001270:8k_2_02:81]
purchase gain for the capital financing business; Extreme Networks excludes these expenses since they result from an event that is outside the ordinary course of continuing operations.

[0001564590-19-001270:8k_2_02:82]
Acquired inventory adjustments.   Purchase accounting adjustments relating to the mark up of acquired inventory to fair value less disposal costs.

[0001564590-19-001270:8k_2_02:83]
Amortization of acquired intangibles.  Amortization of acquired intangibles includes the monthly amortization expense of acquired intangible assets such as developed technology, customer relationships, trademarks and order backlog.  The amortization of the developed technology intangible is recorded in product cost of goods sold, while the amortization for the other intangibles are recorded in operating expenses.  Extreme Networks excludes these non-cash expenses since they result from an intangible asset and for which the period expense does not impact the operations of the business and are non-cash in nature.

[0001564590-19-001270:8k_2_02:84]
Restructuring expenses. Restructuring expenses primarily consist of severance costs for employees which have no benefit to continuing operations and accrued lease costs pertaining to the estimated future obligations for non-cancelable lease payments related to excess facilities. Extreme Networks excludes restructuring expenses since they result from events that often occur outside of the ordinary course of continuing operations.

[0001564590-19-001270:8k_2_02:85]
Gain on sale of equity investment.  The gain on the sale of an equity investment refers to a third party acquisition that acquired a business entity in which the Company had an equity investment.

[0001564590-19-001270:8k_2_02:86]
Income tax.   Income tax adjustments relate to the tax impact of reducing the US tax rate applied to deferred tax items pursuant to the recently enacted US tax legislation, the tax benefit resulting from the impairment of a lease acquired from Avaya in Canada and the impact of our Australian valuation allowance.

[0001564590-19-001270:8k_2_02:87]
In addition to the non-GAAP measures discussed above, Extreme uses free cash flow as a measure of operating performance.  Free cash flow represents operating cash flows less net purchase of property and equipment on a GAAP basis.  Extreme considers free cash flows to be a liquidity measure that provides useful information to management and investors about the amount of cash generated by the business after the purchases of property and equipment, which can then be used to, among other things, invest in Extreme’s business, make strategic acquisitions, and strengthen the balance sheet.  A limitation of the utility of free cash flows as a measure of financial performance is that it does not represent the total increase or decrease in the Company's cash balance for the period.

[0001564590-19-001270:8k_2_02:88]
EXTREME NETWORKS, INC.

[0001564590-19-001270:8k_2_02:89]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS

[0001564590-19-001270:8k_2_02:90]
GAAP TO NON-GAAP RECONCILIATION

[0001564590-19-001270:8k_2_02:91]
(In thousands, except percentages and per share amounts)

[0001564590-19-001270:8k_2_02:92]
(Unaudited)

[0001564590-19-001270:8k_2_02:93]
| Non-GAAP Revenue | Three Months Ended |  |  | Six Months Ended |  |
|  | December 31, 2018 |  |  | December 31, 2017 |  |  | December 31, 2018 |  |  | December 31, 2017 |  |
| Revenue - GAAP Basis | $ | 252,680 |  |  | $ | 231,123 |  |  | $ | 492,566 |  |  | $ | 442,838 |  |
| Revenue - Non-GAAP Basis | $ | 252,680 |  |  | $ | 231,123 |  |  | $ | 492,566 |  |  | $ | 442,838 |  |

[0001564590-19-001270:8k_2_02:94]
| Non-GAAP Gross Margin | Three Months Ended |  |  | Six Months Ended |  |
|  | December 31, 2018 |  |  | December 31, 2017 |  |  | December 31, 2018 |  |  | December 31, 2017 |  |
| Gross profit - GAAP Basis | $ | 141,299 |  |  | $ | 128,986 |  |  | $ | 273,370 |  |  | $ | 241,367 |  |
| Gross margin - GAAP Basis percentage |  | 55.9 | % |  |  | 55.8 | % |  |  | 55.5 | % |  |  | 54.5 | % |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Stock based compensation expense |  | 894 |  |  |  | 430 |  |  |  | 1,417 |  |  |  | 655 |  |
| Acquired inventory adjustments |  | — |  |  |  | 1,249 |  |  |  | — |  |  |  | 4,187 |  |
| Acquisition and integration costs |  | — |  |  |  | 2,672 |  |  |  | 1,755 |  |  |  | 4,518 |  |
| Amortization of intangibles |  | 4,800 |  |  |  | 3,964 |  |  |  | 9,732 |  |  |  | 6,528 |  |
| Total adjustments to GAAP gross profit | $ | 5,694 |  |  | $ | 8,315 |  |  | $ | 12,904 |  |  | $ | 15,888 |  |
| Gross profit - Non-GAAP | $ | 146,993 |  |  | $ | 137,301 |  |  | $ | 286,274 |  |  | $ | 257,255 |  |
| Gross margin - Non-GAAP percentage |  | 58.2 | % |  |  | 59.4 | % |  |  | 58.1 | % |  |  | 58.1 | % |

[0001564590-19-001270:8k_2_02:95]
| Non-GAAP Operating Income | Three Months Ended |  |  | Six Months Ended |  |
|  | December 31, 2018 |  |  | December 31, 2017 |  |  | December 31, 2018 |  |  | December 31, 2017 |  |
| GAAP operating income (loss) | $ | 4,751 |  |  | $ | (31,110 | ) |  | $ | (267 | ) |  | $ | (26,618 | ) |
| GAAP operating income (loss) percentage |  | 1.9 | % |  |  | (13.5 | )% |  |  | (.1 | )% |  |  | (6.0 | )% |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Stock based compensation expense |  | 894 |  |  |  | 430 |  |  |  | 1,417 |  |  |  | 655 |  |
| Stock based compensation expense, R&D |  | 2,797 |  |  |  | 1,829 |  |  |  | 5,139 |  |  |  | 2,880 |  |
| Stock based compensation expense, S&M |  | 2,983 |  |  |  | 2,699 |  |  |  | 5,342 |  |  |  | 4,342 |  |
| Stock based compensation expense, G&A |  | 2,026 |  |  |  | 2,067 |  |  |  | 3,627 |  |  |  | 3,951 |  |
| Acquisition and integration costs |  | — |  |  |  | 36,787 |  |  |  | 4,368 |  |  |  | 42,877 |  |
| Restructuring charge, net of reversal |  | 474 |  |  |  | — |  |  |  | 1,282 |  |  |  | — |  |
| Acquired inventory adjustments |  | — |  |  |  | 1,249 |  |  |  | — |  |  |  | 4,187 |  |
| Litigation |  | — |  |  |  | (365 | ) |  |  | — |  |  |  | (365 | ) |
| Amortization of intangibles |  | 6,375 |  |  |  | 6,710 |  |  |  | 13,448 |  |  |  | 10,888 |  |
| Total adjustments to GAAP operating income (loss) | $ | 15,549 |  |  | $ | 51,406 |  |  | $ | 34,623 |  |  | $ | 69,415 |  |
| Non-GAAP operating income | $ | 20,300 |  |  | $ | 20,296 |  |  | $ | 34,356 |  |  | $ | 42,797 |  |
| Non-GAAP operating income percentage |  | 8.0 | % |  |  | 8.8 | % |  |  | 7.0 | % |  |  | 9.7 | % |

[0001564590-19-001270:8k_2_02:96]
| Non-GAAP Net Income | Three Months Ended |  |  | Six Months Ended |  |
|  | December 31, 2018 |  |  | December 31, 2017 |  |  | December 31, 2018 |  |  | December 31, 2017 |  |
| GAAP net income (loss) | $ | 7,199 |  |  | $ | (31,923 | ) |  | $ | (1,866 | ) |  | $ | (27,547 | ) |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Stock based compensation expense |  | 8,700 |  |  |  | 7,025 |  |  |  | 15,525 |  |  |  | 11,828 |  |
| Acquisition and integration costs |  | — |  |  |  | 36,787 |  |  |  | 4,368 |  |  |  | 42,877 |  |
| Restructuring charge, net of reversal |  | 474 |  |  |  | — |  |  |  | 1,282 |  |  |  | — |  |
| Acquired inventory adjustments |  | — |  |  |  | 1,249 |  |  |  | — |  |  |  | 4,187 |  |
| Litigation |  | — |  |  |  | (365 | ) |  |  | — |  |  |  | (365 | ) |
| Amortization of intangibles |  | 6,375 |  |  |  | 6,710 |  |  |  | 13,448 |  |  |  | 10,888 |  |
| Gain on sale of equity investment |  | — |  |  |  | — |  |  |  | — |  |  |  | (3,757 | ) |
| Income tax |  | (7,290 | ) |  |  | (3,102 | ) |  |  | (7,770 | ) |  |  | (3,102 | ) |
| Total adjustments to GAAP net (loss) income | $ | 8,259 |  |  | $ | 48,304 |  |  | $ | 26,853 |  |  | $ | 62,556 |  |
| Non-GAAP net income | $ | 15,458 |  |  | $ | 16,381 |  |  | $ | 24,987 |  |  | $ | 35,009 |  |
| Earnings per share |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Non-GAAP net income per share-diluted | $ | 0.13 |  |  | $ | 0.14 |  |  | $ | 0.21 |  |  | $ | 0.29 |  |
| Shares used in net income per share-diluted |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Non-GAAP shares used |  | 119,544 |  |  |  | 119,646 |  |  |  | 119,893 |  |  |  | 119,038 |  |

[0001564590-19-001270:8k_2_02:97]
| Free Cash Flow | Three Months Ended |  |  | Six Months Ended |  |
|  | December 31, 2018 |  |  | December 31, 2017 |  |  | December 31, 2018 |  |  | December 31, 2017 |  |
| Cash flow provided by (used in) operations | $ | 27,281 |  |  | $ | (4,350 | ) |  | $ | 61,611 |  |  | $ | 14,248 |  |
| Less: PP&E CapEx spending |  | (3,723 | ) |  |  | (5,888 | ) |  |  | (11,140 | ) |  |  | (13,309 | ) |
| Total free cash flow | $ | 23,558 |  |  | $ | (10,238 | ) |  | $ | 50,471 |  |  | $ | 939 |  |
