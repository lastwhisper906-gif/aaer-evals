# EXTR note change history — 0000950170-23-058245 → 0000950170-24-009819


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2024-02-01):
[0000950170-24-009819:note_history:1]
The Company currently has arrangements with contract manufacturers and suppliers for the manufacture of its products. Those arrangements allow the contract manufacturers to procure long lead-time component inventory based upon a rolling production forecast provided by the Company. The Company is obligated to purchase long lead-time component inventory that its contract manufacturer procures in accordance with the forecast, unless the Company gives notice of order cancellation outside of applicable component lead-times. As of December 31, 2023, the Company had commitments to purchase $92.1 million of inventory.
  (was, 2023-11-02, similarity 0.9942):
[0000950170-23-058245:note_history:1]
The Company currently has arrangements with contract manufacturers and suppliers for the manufacture of its products. Those arrangements allow the contract manufacturers to procure long lead-time component inventory based upon a rolling production forecast provided by the Company. The Company is obligated to purchase long lead-time component inventory that its contract manufacturer procures in accordance with the forecast, unless the Company gives notice of order cancellation outside of applicable component lead-times. As of September 30, 2023, the Company had commitments to purchase $94.7 million of inventory.

- changed (2024-02-01):
[0000950170-24-009819:note_history:2]
The Company may from time to time be party to litigation arising in the course of its business, including, without limitation, allegations relating to commercial transactions, business relationships, or intellectual property rights. Such claims, even if not meritorious, could result in the expenditure of significant financial and managerial resources. Litigation in general, and intellectual property litigation in particular, can be expensive and disruptive to normal business operations. Moreover, the results of legal proceedings are difficult to predict.
  (was, 2023-11-02, similarity 0.9892):
[0000950170-23-058245:note_history:2]
The Company may from time to time be party to litigation arising in the course of its business, including, without limitation, allegations relating to commercial transactions, business relationships or intellectual property rights. Such claims, even if not meritorious, could result in the expenditure of significant financial and managerial resources. Litigation in general, and intellectual property in particular, can be expensive and disruptive to normal business operations. Moreover, the results of legal proceedings are difficult to predict.

- changed (2024-02-01):
[0000950170-24-009819:note_history:3]
On October 26, 2020, SNMP Research, Inc. and SNMP Research International, Inc. (collectively, “SNMP”) filed a lawsuit against the Company in the Eastern District of Tennessee for copyright infringement, alleging that the Company was not properly licensed to use its software.  SNMP is seeking actual damages and profits attributed to the infringement, as well as equitable relief. The Company filed a motion to transfer the case to the Northern District of California. The motion to dismiss was denied in part and denied without
  (was, 2023-11-02, similarity 0.6975):
[0000950170-23-058245:note_history:3]
On October 26, 2020, SNMP Research, Inc. and SNMP Research International, Inc. (collectively, “SNMP”) filed a lawsuit against the Company in the Eastern District of Tennessee for copyright infringement, alleging that the Company was not properly licensed to use its software.  SNMP is seeking actual damages and profits attributed to the infringement, as well as equitable relief. The Company filed a motion to transfer the case to the Northern District of California. The motion to dismiss was denied in part and denied without prejudice in part. On March 2, 2023, SNMP filed an amended complaint adding claims against Extreme on additional products for copyright infringement, breach of contract, and fraud. On March 16, 2023, the Company filed a motion to dismiss, challenging multiple claims from the amended complaint. On March 20, 2023, the Company filed a motion to refer questions to the US Copyright Office on the invalidity of SNMP’s copyrights. The trial date has been set for October 2024.

- added (2024-02-01):
[0000950170-24-009819:note_history:4]
prejudice in part. On March 2, 2023, SNMP filed an amended complaint adding claims against Extreme on additional products for copyright infringement, breach of contract, and fraud. On March 16, 2023, the Company filed a motion to dismiss, challenging multiple claims from the amended complaint. On March 20, 2023, the Company filed a motion to refer questions to the US Copyright Office on the invalidity of SNMP’s copyrights. The trial date has been set for October 2024.

- changed (2024-02-01):
[0000950170-24-009819:note_history:5]
Subject to certain limitations, the Company may be obligated to indemnify its current and former directors, officers, and employees. These obligations arise under the terms of its certificate of incorporation, its bylaws, applicable contracts, and applicable law. The obligation to indemnify, where applicable, generally means that the Company is required to pay or reimburse, and in certain circumstances the Company has paid or reimbursed, the individuals’ reasonable legal expenses and possible damages and other liabilities incurred in connection with certain legal matters. The Company also procures Directors and Officers liability insurance to help cover its defense and/or indemnification costs, although its ability to recover such costs through insurance is uncertain.  While it is not possible to estimate the maximum potential amount that could be owed under these governing documents and agreements due to the Company’s limited history with prior indemnification claims, indemnification (including defense) costs could, in the future, have a material adverse effect on the Company’s consolidated financial position, results of operations and cash flows.
  (was, 2023-11-02, similarity 0.9996):
[0000950170-23-058245:note_history:5]
Subject to certain limitations, the Company may be obligated to indemnify its current and former directors, officers and employees. These obligations arise under the terms of its certificate of incorporation, its bylaws, applicable contracts, and applicable law. The obligation to indemnify, where applicable, generally means that the Company is required to pay or reimburse, and in certain circumstances the Company has paid or reimbursed, the individuals’ reasonable legal expenses and possible damages and other liabilities incurred in connection with certain legal matters. The Company also procures Directors and Officers liability insurance to help cover its defense and/or indemnification costs, although its ability to recover such costs through insurance is uncertain.  While it is not possible to estimate the maximum potential amount that could be owed under these governing documents and agreements due to the Company’s limited history with prior indemnification claims, indemnification (including defense) costs could, in the future, have a material adverse effect on the Company’s consolidated financial position, results of operations and cash flows.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2024-02-01):
[0000950170-24-009819:note_history:6]
Extreme Networks, Inc., together with its subsidiaries (collectively referred to as “Extreme” or the “Company”), is a leader in providing software-driven networking solutions for enterprise customers. The Company conducts its sales and marketing activities on a worldwide basis through distributors, resellers, and the Company’s field sales organization. Extreme was incorporated in California in 1996 and reincorporated in Delaware in 1999.
  (was, 2023-11-02, similarity 0.9988):
[0000950170-23-058245:note_history:6]
Extreme Networks, Inc., together with its subsidiaries (collectively referred to as “Extreme” or the “Company”), is a leader in providing software-driven networking solutions for enterprise customers. The Company conducts its sales and marketing activities on a worldwide basis through distributors, resellers and the Company’s field sales organization. Extreme was incorporated in California in 1996 and reincorporated in Delaware in 1999.

- changed (2024-02-01):
[0000950170-24-009819:note_history:7]
The unaudited condensed consolidated financial statements reflect all adjustments, consisting only of normal recurring adjustments that, in the opinion of management, are necessary for a fair presentation of the results of operations and cash flows for the interim periods presented and the financial condition of Extreme at December 31, 2023. The results of operations for the three and six months ended December 31, 2023 are not necessarily indicative of the results that may be expected for fiscal 2024 or any future periods.
  (was, 2023-11-02, similarity 0.775):
[0000950170-23-058245:note_history:7]
The unaudited condensed consolidated financial statements reflect all adjustments, consisting only of normal recurring adjustments that, in the opinion of management, are necessary for a fair presentation of the results of operations and cash flows for the interim periods presented and the financial condition of Extreme at September 30, 2023. The results of operations for the three months ended September 30, 2023 are not necessarily indicative of the results that may be expected for fiscal 2024 or any future periods.

- changed (2024-02-01):
[0000950170-24-009819:note_history:8]
The Company predominantly uses the United States Dollar as its functional currency. The functional currency for certain of its foreign subsidiaries is the local currency. For those subsidiaries that operate in a local functional currency environment, all assets and liabilities are translated to United States Dollars at current month end rates of exchange and revenues, and expenses are translated using the monthly average rate.
  (was, 2023-11-02, similarity 0.9988):
[0000950170-23-058245:note_history:8]
The Company predominantly uses the United States Dollar as its functional currency. The functional currency for certain of its foreign subsidiaries is the local currency. For those subsidiaries that operate in a local functional currency environment, all assets and liabilities are translated to United States Dollars at current month end rates of exchange and revenues and expenses are translated using the monthly average rate.


## us-gaap:SignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2024-02-01):
[0000950170-24-009819:note_history:9]
There were no recently adopted accounting standards which would have a material effect on our condensed consolidated financial statements and accompanying disclosures.
  (was, 2023-11-02, similarity 0.664):
[0000950170-23-058245:note_history:9]
There were no recently adopted accounting standards which would have a material effect on our condensed consolidated financial statements and accompanying disclosures, and no recently issued accounting standards that are expected to have a material impact on our condensed consolidated financial statements and accompanying disclosures.

- added (2024-02-01):
[0000950170-24-009819:note_history:10]
Recently Issued Accounting Pronouncements Not Yet Adopted

- added (2024-02-01):
[0000950170-24-009819:note_history:11]
In November 2023, the Financial Accounting Standards Board (“FASB”) issued Accounting Standards Update (“ASU”) 2023-07, Segment Reporting (Topic 280): Improvements to Reportable Segment Disclosures to improve reportable segment disclosure requirements primarily through enhanced disclosures about significant segment expenses and information used to assess segment performance. All disclosure requirements of ASU 2023-07 are required for entities with a single reportable segment. ASU 2023-07 is effective for fiscal years beginning after December 15, 2023, and interim periods for fiscal years beginning after December 15, 2024, and should be applied on a retrospective basis to all periods presented. Early adoption is permitted. The Company is currently evaluating the impact of adopting ASU 2023-07 on its consolidated financial statements and related disclosures.

- added (2024-02-01):
[0000950170-24-009819:note_history:12]
In December 2023, the FASB issued ASU 2023-09, Income Taxes (Topic 740), Improvements to Income Tax Disclosures to enhance income tax disclosures primarily through changes in the rate reconciliation and income taxes paid information. ASU 2023-09 is effective for fiscal years beginning after December 15, 2024 on a prospective basis. Early adoption is permitted. The Company is currently evaluating the impact of adopting ASU 2023-09 on its consolidated financial statements and related disclosures.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2024-02-01):
[0000950170-24-009819:note_history:13]
|  |  | December 31,2023 |  |  | June 30,2023 |  |
| Current portion of long-term debt: |  |  |  |  |  |  |
| Term Loan |  | $ | 10,000 |  |  | $ | 10,000 |  |
| Revolving Facility |  |  | — |  |  |  | 25,000 |  |
| Less: unamortized debt issuance costs |  |  | (675 | ) |  |  | (674 | ) |
| Current portion of long-term debt |  | $ | 9,325 |  |  | $ | 34,326 |  |
| Long-term debt, less current portion: |  |  |  |  |  |  |
| Term Loan |  | $ | 185,000 |  |  | $ | 190,000 |  |
| Less: unamortized debt issuance costs |  |  | (2,069 | ) |  |  | (2,409 | ) |
| Total long-term debt, less current portion |  |  | 182,931 |  |  |  | 187,591 |  |
| Total debt |  | $ | 192,256 |  |  | $ | 221,917 |  |
  (was, 2023-11-02, similarity 0.9938):
[0000950170-23-058245:note_history:13]
|  |  | September 30,2023 |  |  | June 30,2023 |  |
| Current portion of long-term debt: |  |  |  |  |  |  |
| Term Loan |  | $ | 10,000 |  |  | $ | 10,000 |  |
| Revolving Facility |  |  | — |  |  |  | 25,000 |  |
| Less: unamortized debt issuance costs |  |  | (675 | ) |  |  | (674 | ) |
| Current portion of long-term debt |  | $ | 9,325 |  |  | $ | 34,326 |  |
| Long-term debt, less current portion: |  |  |  |  |  |  |
| Term Loan |  | $ | 187,500 |  |  | $ | 190,000 |  |
| Less: unamortized debt issuance costs |  |  | (2,239 | ) |  |  | (2,409 | ) |
| Total long-term debt, less current portion |  |  | 185,261 |  |  |  | 187,591 |  |
| Total debt |  | $ | 194,586 |  |  | $ | 221,917 |  |

- changed (2024-02-01):
[0000950170-24-009819:note_history:14]
On June 22, 2023, the Company entered into a Second Amended and Restated Credit Agreement (the “2023 Credit Agreement”), by and among the Company, as borrower, BMO Harris Bank, N.A., as an issuing lender and swingline lender, Bank of America, N.A., JPMorgan Chase Bank, N.A., PNC Bank, National Association, and Wells Fargo Bank, National Association, as issuing lenders, the financial institutions or entities party thereto as lenders, and Bank of Montreal, as administrative agent and collateral agent, which amended and restated the 2019 Credit Agreement. The 2023 Credit Agreement provides for i) a $200.0 million first lien term loan facility in an aggregate principal amount (the “2023 Term Loan”), ii) a $150.0 million five-year revolving credit facility (the “2023 Revolving Facility”) and, iii) an uncommitted additional incremental loan facility in the principal amount of up to $100.0 million. On June 22, 2023, the Company borrowed $25.0 million against its $150.0 million revolving credit facility to refinance its debt. On July 7, 2023, the Company made a payment of $25.0 million to pay off the outstanding revolving credit balance.
  (was, 2023-11-02, similarity 0.9995):
[0000950170-23-058245:note_history:14]
On June 22, 2023, the Company entered into a Second Amended and Restated Credit Agreement (the “2023 Credit Agreement”), by and among the Company, as borrower, BMO Harris Bank, N.A., as an issuing lender and swingline lender, Bank of America, N.A., JPMorgan Chase Bank, N.A., PNC Bank, National Association and Wells Fargo Bank, National Association, as issuing lenders, the financial institutions or entities party thereto as lenders, and Bank of Montreal, as administrative agent and collateral agent, which amended and restated the 2019 Credit Agreement. The 2023 Credit Agreement provides for i) a $200.0 million first lien term loan facility in an aggregate principal amount (the “2023 Term Loan”), ii) a $150.0 million five-year revolving credit facility (the “2023 Revolving Facility”) and, iii) an uncommitted additional incremental loan facility in the principal amount of up to $100.0 million. On June 22, 2023, the Company borrowed $25.0 million against its $150.0 million revolving credit facility to refinance its debt. On July 7, 2023 the Company made a payment of $25.0 million to pay off the outstanding revolving credit balance.

- changed (2024-02-01):
[0000950170-24-009819:note_history:15]
The 2023 Credit Agreement requires the Company to maintain certain minimum financial ratios at the end of each fiscal quarter. The 2023 Credit Agreement also includes covenants and restrictions that limit, among other things, the Company’s ability to incur additional indebtedness, create liens upon any of its property, merge, consolidate or sell all or substantially all of its assets. The 2023 Credit Agreement also includes customary events of default which may result in acceleration of the outstanding balance. During the six months ended December 31, 2023, the Company was in compliance with all the terms and financial covenants of the 2023 Credit Agreement.
  (was, 2023-11-02, similarity 0.9669):
[0000950170-23-058245:note_history:15]
The 2023 Credit Agreement requires the Company to maintain certain minimum financial ratios at the end of each fiscal quarter. The 2023 Credit Agreement also includes covenants and restrictions that limit, among other things, the Company’s ability to incur additional indebtedness, create liens upon any of its property, merge, consolidate or sell all or substantially all of its assets. The 2023 Credit Agreement also includes customary events of default which may result in acceleration of the outstanding balance. During the three months ended September 30, 2023, the Company was in compliance with all the terms and financial covenants of the 2023 Credit Agreement.

- changed (2024-02-01):
[0000950170-24-009819:note_history:16]
Financing costs incurred in connection with obtaining long-term financing are deferred and amortized over the term of the related indebtedness or credit agreement. Amortization of deferred financing costs included in “Interest expense” in the accompanying condensed consolidated statements of operations were $0.3 million and $0.7 million for the three months ended December 31, 2023 and 2022, respectively, and were $0.5 million and $1.5 million for the six months ended December 31, 2023 and 2022, respectively. The interest rate as of December 31, 2023 was 7.46% and as of December 31, 2022 was 5.50%.
  (was, 2023-11-02, similarity 0.8897):
[0000950170-23-058245:note_history:16]
Financing costs incurred in connection with obtaining long-term financing are deferred and amortized over the term of the related indebtedness or credit agreement. Amortization of deferred financing costs included in “Interest expense” in the accompanying condensed consolidated statements of operations were $0.3 million and $0.7 million for the three months ended September 30, 2023 and 2022, respectively. The interest rate as of September 30, 2023 was 7.45% and as of September 30, 2022 was 4.50%.

- changed (2024-02-01):
[0000950170-24-009819:note_history:17]
As of December 31, 2023, the Company did not have any outstanding balance against its 2023 Revolving Facility’s outstanding balance. The Company had $135.5 million of availability under the 2023 Revolving Facility as of December 31, 2023. During the three and six months ended December 31, 2023 the Company did not make any additional payments against its term loan facility other than the scheduled payments per the terms of the 2023 Credit Agreement. During the six months ended December 31, 2022, the Company made an additional payment of $30.0 million, against its term loan facility under the 2023 Credit Agreement.
  (was, 2023-11-02, similarity 0.8683):
[0000950170-23-058245:note_history:17]
As of September 30, 2023, the Company did not have any outstanding balance against its 2023 Revolving Facility’s outstanding balance. The Company had $135.5 million of availability under the 2023 Revolving Facility as of September 30, 2023. During the three months ended September 30, 2023 the Company did not make any additional payments against its term loan facility other than the scheduled payments per the terms of the 2023 Credit Agreement. During the three months ended September 30, 2022 the Company made an additional payment of $30.0 million, against its term loan facility under the 2019 Credit Agreement.

- changed (2024-02-01):
[0000950170-24-009819:note_history:18]
The Company had $14.5 million of outstanding letters of credit as of December 31, 2023.
  (was, 2023-11-02, similarity 0.9682):
[0000950170-23-058245:note_history:18]
The Company had $14.5 million of outstanding letters of credit as of September 30, 2023.


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2024-02-01):
[0000950170-24-009819:note_history:19]
|  |  | December 31,2023 |  |  | June 30,2023 |  |
| Current portion of long-term debt: |  |  |  |  |  |  |
| Term Loan |  | $ | 10,000 |  |  | $ | 10,000 |  |
| Revolving Facility |  |  | — |  |  |  | 25,000 |  |
| Less: unamortized debt issuance costs |  |  | (675 | ) |  |  | (674 | ) |
| Current portion of long-term debt |  | $ | 9,325 |  |  | $ | 34,326 |  |
| Long-term debt, less current portion: |  |  |  |  |  |  |
| Term Loan |  | $ | 185,000 |  |  | $ | 190,000 |  |
| Less: unamortized debt issuance costs |  |  | (2,069 | ) |  |  | (2,409 | ) |
| Total long-term debt, less current portion |  |  | 182,931 |  |  |  | 187,591 |  |
| Total debt |  | $ | 192,256 |  |  | $ | 221,917 |  |
  (was, 2023-11-02, similarity 0.9938):
[0000950170-23-058245:note_history:19]
|  |  | September 30,2023 |  |  | June 30,2023 |  |
| Current portion of long-term debt: |  |  |  |  |  |  |
| Term Loan |  | $ | 10,000 |  |  | $ | 10,000 |  |
| Revolving Facility |  |  | — |  |  |  | 25,000 |  |
| Less: unamortized debt issuance costs |  |  | (675 | ) |  |  | (674 | ) |
| Current portion of long-term debt |  | $ | 9,325 |  |  | $ | 34,326 |  |
| Long-term debt, less current portion: |  |  |  |  |  |  |
| Term Loan |  | $ | 187,500 |  |  | $ | 190,000 |  |
| Less: unamortized debt issuance costs |  |  | (2,239 | ) |  |  | (2,409 | ) |
| Total long-term debt, less current portion |  |  | 185,261 |  |  |  | 187,591 |  |
| Total debt |  | $ | 194,586 |  |  | $ | 221,917 |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2024-02-01):
[0000950170-24-009819:note_history:20]
The following table sets forth the Company’s net revenues disaggregated by sales channel and geographic region based on the billing addresses of its customers (in thousands):
  (was, 2023-11-02, similarity 0.9884):
[0000950170-23-058245:note_history:20]
The following table sets forth the Company’s revenues disaggregated by sales channel and geographic region based on the billing addresses of its customers (in thousands):

- changed (2024-02-01):
[0000950170-24-009819:note_history:21]
|  |  | Three Months Ended |  |
|  |  | December 31,2023 |  |  | December 31,2022 |  |
|  |  | Distributor |  | Direct |  | Total |  |  | Distributor |  | Direct |  | Total |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  | $ | 81,350 |  | $ | 68,199 |  | $ | 149,549 |  |  | $ | 70,963 |  | $ | 66,630 |  | $ | 137,593 |  |
| Other |  |  | 8,244 |  |  | 4,842 |  |  | 13,086 |  |  |  | 10,807 |  |  | 4,614 |  |  | 15,421 |  |
| Total Americas |  |  | 89,594 |  |  | 73,041 |  |  | 162,635 |  |  |  | 81,770 |  |  | 71,244 |  |  | 153,014 |  |
| EMEA |  |  | 64,082 |  |  | 46,523 |  |  | 110,605 |  |  |  | 97,147 |  |  | 40,903 |  |  | 138,050 |  |
| APAC |  |  | 8,864 |  |  | 14,273 |  |  | 23,137 |  |  |  | 7,403 |  |  | 19,881 |  |  | 27,284 |  |
| Total net revenues |  | $ | 162,540 |  | $ | 133,837 |  | $ | 296,377 |  |  | $ | 186,320 |  | $ | 132,028 |  | $ | 318,348 |  |
  (was, 2023-11-02, similarity 0.9886):
[0000950170-23-058245:note_history:21]
|  |  | Three Months Ended |  |
|  |  | September 30,2023 |  |  | September 30,2022 |  |
|  |  | Distributor |  | Direct |  | Total |  |  | Distributor |  | Direct |  | Total |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  | $ | 117,801 |  | $ | 64,951 |  | $ | 182,752 |  |  | $ | 73,314 |  | $ | 64,312 |  | $ | 137,626 |  |
| Other |  |  | 2,531 |  |  | 10,366 |  |  | 12,897 |  |  |  | 16,025 |  |  | 4,098 |  |  | 20,123 |  |
| Total Americas |  |  | 120,332 |  |  | 75,317 |  |  | 195,649 |  |  |  | 89,339 |  |  | 68,410 |  |  | 157,749 |  |
| EMEA |  |  | 102,311 |  |  | 41,292 |  |  | 143,603 |  |  |  | 76,256 |  |  | 39,253 |  |  | 115,509 |  |
| APAC |  |  | 111 |  |  | 13,774 |  |  | 13,885 |  |  |  | 2,038 |  |  | 22,393 |  |  | 24,431 |  |
| Total net revenues |  | $ | 222,754 |  | $ | 130,383 |  | $ | 353,137 |  |  | $ | 167,633 |  | $ | 130,056 |  | $ | 297,689 |  |

- added (2024-02-01):
[0000950170-24-009819:note_history:22]
|  |  | Six Months Ended |  |
|  |  | December 31,2023 |  |  | December 31,2022 |  |
|  |  | Distributor |  | Direct |  | Total |  |  | Distributor |  | Direct |  | Total |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  | $ | 199,151 |  | $ | 133,150 |  | $ | 332,301 |  |  | $ | 144,277 |  | $ | 130,942 |  | $ | 275,219 |  |
| Other |  |  | 10,775 |  |  | 15,208 |  |  | 25,983 |  |  |  | 26,832 |  |  | 8,712 |  |  | 35,544 |  |
| Total Americas |  |  | 209,926 |  |  | 148,358 |  |  | 358,284 |  |  |  | 171,109 |  |  | 139,654 |  |  | 310,763 |  |
| EMEA |  |  | 166,393 |  |  | 87,815 |  |  | 254,208 |  |  |  | 173,403 |  |  | 80,156 |  |  | 253,559 |  |
| APAC |  |  | 8,975 |  |  | 28,047 |  |  | 37,022 |  |  |  | 9,441 |  |  | 42,274 |  |  | 51,715 |  |
| Total net revenues |  | $ | 385,294 |  | $ | 264,220 |  | $ | 649,514 |  |  | $ | 353,953 |  | $ | 262,084 |  | $ | 616,037 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- added (2024-02-01):
[0000950170-24-009819:note_history:23]
The Company accounts for revenues in accordance with Accounting Standards Codification (“ASC”) 606, Revenue from Contracts with Customers. The Company derives the majority of its revenues from sales of its networking equipment, with the remaining revenues generated from sales of subscription and support, which primarily includes software subscriptions delivered as software as a service (“SaaS”) and additional revenues from maintenance contracts, professional services and training for its products. The Company sells its products,  SaaS, and maintenance contracts direct to customers and to partners in two distribution channels, or tiers. The first tier consists of a limited number of independent distributors that stock the Company's products and sell primarily to resellers. The second tier of the distribution channel consists of non-stocking distributors and value-added resellers that sell directly to end-users. Products and subscription and support may be sold separately or in bundled packages.

- changed (2024-02-01):
[0000950170-24-009819:note_history:24]
Performance Obligations. A performance obligation is a promise in a contract to transfer a distinct good or service to the customer and is the unit of account in ASC 606. A contract’s transaction price is allocated to each distinct performance obligation and recognized as revenue when, or as, the performance obligation is satisfied. Certain of the Company’s contracts have multiple performance obligations, as the promise to transfer individual goods or services is separately identifiable from other promises in the contracts and, therefore, is distinct. For contracts with multiple performance obligations, the Company allocates the contract’s transaction price to each performance obligation based on its relative standalone selling price. The stand-alone selling prices are determined based on the prices at which the Company separately sells these products. For items that are not sold separately, the Company estimates the stand-alone selling prices using other observable inputs.
  (was, 2023-11-02, similarity 0.997):
[0000950170-23-058245:note_history:24]
Performance Obligations. A performance obligation is a promise in a contract to transfer a distinct good or service to the customer and is the unit of account in Topic 606. A contract’s transaction price is allocated to each distinct performance obligation and recognized as revenue when, or as, the performance obligation is satisfied. Certain of the Company’s contracts have multiple performance obligations, as the promise to transfer individual goods or services is separately identifiable from other promises in the contracts and, therefore, is distinct. For contracts with multiple performance obligations, the Company allocates the contract’s transaction price to each performance obligation based on its relative standalone selling price. The stand-alone selling prices are determined based on the prices at which the Company separately sells these products. For items that are not sold separately, the Company estimates the stand-alone selling prices using other observable inputs.

- changed (2024-02-01):
[0000950170-24-009819:note_history:25]
On December 31, 2023, the Company had $548.2 million of remaining performance obligations, which primarily comprised deferred maintenance and deferred SaaS revenues. The Company expects to recognize approximately 32% of its deferred revenue as revenue in the remainder of fiscal 2024, an additional 34% in fiscal 2025, and 34% of the balance thereafter.
  (was, 2023-11-02, similarity 0.9792):
[0000950170-23-058245:note_history:25]
On September 30, 2023, the Company had $525.4 million of remaining performance obligations, which are primarily comprised of deferred maintenance and deferred SaaS revenues. The Company expects to recognize approximately 46% of its deferred revenue as revenue in the remainder of fiscal 2024, an additional 26% in fiscal 2025 and 28% of the balance thereafter.

- changed (2024-02-01):
[0000950170-24-009819:note_history:26]
Revenue recognized for the three months ended December 31, 2023 and 2022 that was included in the deferred revenue balance at the beginning of each period was $105.7 million and $83.9 million, respectively. Revenue recognized for the six months ended December 31, 2023 and 2022 that was included in the deferred revenue balance at the beginning of each period was $172.0 million and $145.7 million, respectively.
  (was, 2023-11-02, similarity 0.6597):
[0000950170-23-058245:note_history:26]
Revenue recognized for the three months ended September 30, 2023 and 2022 that was included in the deferred revenue balance at the beginning of each period was $89.7 million and $80.0 million, respectively.

- changed (2024-02-01):
[0000950170-24-009819:note_history:27]
Contract Costs. The Company recognizes the incremental costs of obtaining contracts as an expense when incurred if the amortization period of the assets that the Company otherwise would have recognized is one year or less. Management expects that commission fees paid to sales representatives as a result of obtaining subscription and support contracts and contract renewals are recoverable and therefore the Company’s condensed consolidated balance sheets included capitalized balances in the amount of $22.2 million and $20.0 million at December 31, 2023 and June 30, 2023, respectively. Capitalized commissions are included within other assets in the condensed consolidated balance sheets. Capitalized commission fees are amortized on a straight-line basis over the average period of service contracts of approximately three years, and are included in “Sales and marketing” in the accompanying condensed consolidated statements of operations. Amortization recognized during the three months ended December 31, 2023 and 2022 was $2.7 million and $2.2 million, respectively. Amortization recognized during the six months ended December 31, 2023 and 2022 was $5.2 million and $4.3 million, respectively.
  (was, 2023-11-02, similarity 0.9412):
[0000950170-23-058245:note_history:27]
Contract Costs. The Company recognizes the incremental costs of obtaining contracts as an expense when incurred if the amortization period of the assets that the Company otherwise would have recognized is one year or less. Management expects that commission fees paid to sales representatives as a result of obtaining subscription and support contracts and contract renewals are recoverable and therefore the Company’s condensed consolidated balance sheets included capitalized balances in the amount of $21.3 million and $20.0 million at September 30, 2023 and June 30, 2023, respectively. Capitalized commissions are included within other assets in the condensed consolidated balance sheets. Capitalized commission fees are amortized on a straight-line basis over the average period of service contracts of approximately three years, and are included in “Sales and marketing” in the accompanying condensed consolidated statements of operations. Amortization recognized during the three months ended September 30, 2023 and 2022, was $2.6 million and $2.1 million, respectively.

- changed (2024-02-01):
[0000950170-24-009819:note_history:28]
The Company operates in three geographic regions: Americas, EMEA (Europe, Middle East and Africa) and APAC (Asia Pacific). The following table sets forth the Company’s net revenues disaggregated by sales channel and geographic region based on the billing addresses of its customers (in thousands):
  (was, 2023-11-02, similarity 0.9932):
[0000950170-23-058245:note_history:28]
The Company operates in three geographic regions: Americas, EMEA (Europe, Middle East and Africa) and APAC (Asia Pacific). The following table sets forth the Company’s revenues disaggregated by sales channel and geographic region based on the billing addresses of its customers (in thousands):

- changed (2024-02-01):
[0000950170-24-009819:note_history:29]
|  |  | Three Months Ended |  |
|  |  | December 31,2023 |  |  | December 31,2022 |  |
|  |  | Distributor |  | Direct |  | Total |  |  | Distributor |  | Direct |  | Total |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  | $ | 81,350 |  | $ | 68,199 |  | $ | 149,549 |  |  | $ | 70,963 |  | $ | 66,630 |  | $ | 137,593 |  |
| Other |  |  | 8,244 |  |  | 4,842 |  |  | 13,086 |  |  |  | 10,807 |  |  | 4,614 |  |  | 15,421 |  |
| Total Americas |  |  | 89,594 |  |  | 73,041 |  |  | 162,635 |  |  |  | 81,770 |  |  | 71,244 |  |  | 153,014 |  |
| EMEA |  |  | 64,082 |  |  | 46,523 |  |  | 110,605 |  |  |  | 97,147 |  |  | 40,903 |  |  | 138,050 |  |
| APAC |  |  | 8,864 |  |  | 14,273 |  |  | 23,137 |  |  |  | 7,403 |  |  | 19,881 |  |  | 27,284 |  |
| Total net revenues |  | $ | 162,540 |  | $ | 133,837 |  | $ | 296,377 |  |  | $ | 186,320 |  | $ | 132,028 |  | $ | 318,348 |  |
  (was, 2023-11-02, similarity 0.9886):
[0000950170-23-058245:note_history:29]
|  |  | Three Months Ended |  |
|  |  | September 30,2023 |  |  | September 30,2022 |  |
|  |  | Distributor |  | Direct |  | Total |  |  | Distributor |  | Direct |  | Total |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  | $ | 117,801 |  | $ | 64,951 |  | $ | 182,752 |  |  | $ | 73,314 |  | $ | 64,312 |  | $ | 137,626 |  |
| Other |  |  | 2,531 |  |  | 10,366 |  |  | 12,897 |  |  |  | 16,025 |  |  | 4,098 |  |  | 20,123 |  |
| Total Americas |  |  | 120,332 |  |  | 75,317 |  |  | 195,649 |  |  |  | 89,339 |  |  | 68,410 |  |  | 157,749 |  |
| EMEA |  |  | 102,311 |  |  | 41,292 |  |  | 143,603 |  |  |  | 76,256 |  |  | 39,253 |  |  | 115,509 |  |
| APAC |  |  | 111 |  |  | 13,774 |  |  | 13,885 |  |  |  | 2,038 |  |  | 22,393 |  |  | 24,431 |  |
| Total net revenues |  | $ | 222,754 |  | $ | 130,383 |  | $ | 353,137 |  |  | $ | 167,633 |  | $ | 130,056 |  | $ | 297,689 |  |

- added (2024-02-01):
[0000950170-24-009819:note_history:30]
|  |  | Six Months Ended |  |
|  |  | December 31,2023 |  |  | December 31,2022 |  |
|  |  | Distributor |  | Direct |  | Total |  |  | Distributor |  | Direct |  | Total |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  | $ | 199,151 |  | $ | 133,150 |  | $ | 332,301 |  |  | $ | 144,277 |  | $ | 130,942 |  | $ | 275,219 |  |
| Other |  |  | 10,775 |  |  | 15,208 |  |  | 25,983 |  |  |  | 26,832 |  |  | 8,712 |  |  | 35,544 |  |
| Total Americas |  |  | 209,926 |  |  | 148,358 |  |  | 358,284 |  |  |  | 171,109 |  |  | 139,654 |  |  | 310,763 |  |
| EMEA |  |  | 166,393 |  |  | 87,815 |  |  | 254,208 |  |  |  | 173,403 |  |  | 80,156 |  |  | 253,559 |  |
| APAC |  |  | 8,975 |  |  | 28,047 |  |  | 37,022 |  |  |  | 9,441 |  |  | 42,274 |  |  | 51,715 |  |
| Total net revenues |  | $ | 385,294 |  | $ | 264,220 |  | $ | 649,514 |  |  | $ | 353,953 |  | $ | 262,084 |  | $ | 616,037 |  |

- added (2024-02-01):
[0000950170-24-009819:note_history:31]
For the three months ended December 31, 2023, the Company generated 10% of its net revenues from Germany. For the six months ended December 31, 2023, the Company generated approximately 11% of its net revenues from the Netherlands. For the three months ended December 31, 2022, the Company generated 11% and 10% of its net revenues from the Netherlands and Germany, respectively. For the six months ended December 31, 2022, the Company generated 10% of its net revenues from each of the Netherlands and Germany. No other foreign country accounted for 10% or more of its net revenues for the three and six months ended December 31, 2023 and 2022.

- changed (2024-02-01):
[0000950170-24-009819:note_history:32]
|  |  | Three Months Ended |  | Six Months Ended |
|  |  | December 31,2023 |  | December 31,2022 |  | December 31,2023 |  | December 31,2022 |
| Jenne, Inc. |  | 23% |  | 13% |  | 25% |  | 13% |
| Westcon Group, Inc. |  | 10% |  | 19% |  | 18% |  | 17% |
| TD Synnex Corporation |  | 24% |  | 17% |  | 21% |  | 18% |
| ScanSource, Inc. |  | * |  | 11% |  | * |  | * |
| * Less than 10% of revenue |  |  |  |  |  |  |  |  |
  (was, 2023-11-02, similarity 0.6272):
[0000950170-23-058245:note_history:32]
|  |  | Three Months Ended |
|  |  | September 30,2023 |  | September 30,2022 |
| Jenne, Inc. |  | 27% |  | 13% |
| Westcon Group, Inc. |  | 25% |  | 15% |
| TD Synnex Corporation |  | 18% |  | 19% |

- changed (2024-02-01):
[0000950170-24-009819:note_history:33]
|  |  | December 31,2023 |  | June 30,2023 |
| Jenne, Inc. |  | 52% |  | 39% |
| TD Synnex Corporation |  | * |  | 10% |
| ScanSource, Inc. |  | * |  | 10% |
| Ingram Micro |  | 10% |  | * |
| * Less than 10% of accounts receivable |  |  |  |  |
  (was, 2023-11-02, similarity 0.9114):
[0000950170-23-058245:note_history:33]
|  |  | September 30,2023 |  | June 30,2023 |
| Jenne, Inc. |  | 75% |  | 39% |
| TD Synnex Corporation |  | * |  | 10% |
| ScanSource, Inc. |  | * |  | 10% |
| * Less than 10% of accounts receivable |  |  |  |  |

- changed (2024-02-01):
[0000950170-24-009819:note_history:34]
The Company's net accounts receivable balance with Jenne, Inc. as of December 31, 2023 is current and the Company expects to collect the majority of this balance by March 31, 2024.
  (was, 2023-11-02, similarity 0.8655):
[0000950170-23-058245:note_history:34]
The majority of the Company's net accounts receivable balance with Jenne, Inc. as of September 30, 2023 is current and the Company expects to collect this balance by December 31, 2023.

- removed (2024-02-01):
[0000950170-23-058245:note_history:35]
The Company accounts for revenues in accordance with ASU 2014-09, Revenue from Contracts with Customers (Topic 606). The Company derives the majority of its revenues from sales of its networking equipment, with the remaining revenues generated from sales of subscription and support, which primarily includes software subscriptions delivered as software as a service (“SaaS”) and additional revenues from maintenance contracts, professional services and training for its products. The Company sells its products,  SaaS, and

- removed (2024-02-01):
[0000950170-23-058245:note_history:36]
maintenance contracts direct to customers and to partners in two distribution channels, or tiers. The first tier consists of a limited number of independent distributors that stock its products and sell primarily to resellers. The second tier of the distribution channel consists of non-stocking distributors and value-added resellers that sell directly to end-users. Products and subscription and support may be sold separately or in bundled packages.

- removed (2024-02-01):
[0000950170-23-058245:note_history:37]
For the three months ended September 30, 2023, the Company generated 14% of its revenues from the Netherlands. No other foreign country accounted for 10% or more of its revenue for the three months ended September 30, 2023. For the three months ended September 30, 2022, no foreign country accounted for 10% or more of its revenue.


## us-gaap:RevenueRecognitionPolicyTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2024-02-01):
[0000950170-24-009819:note_history:38]
Performance Obligations. A performance obligation is a promise in a contract to transfer a distinct good or service to the customer and is the unit of account in ASC 606. A contract’s transaction price is allocated to each distinct performance obligation and recognized as revenue when, or as, the performance obligation is satisfied. Certain of the Company’s contracts have multiple performance obligations, as the promise to transfer individual goods or services is separately identifiable from other promises in the contracts and, therefore, is distinct. For contracts with multiple performance obligations, the Company allocates the contract’s transaction price to each performance obligation based on its relative standalone selling price. The stand-alone selling prices are determined based on the prices at which the Company separately sells these products. For items that are not sold separately, the Company estimates the stand-alone selling prices using other observable inputs.
  (was, 2023-11-02, similarity 0.997):
[0000950170-23-058245:note_history:38]
Performance Obligations. A performance obligation is a promise in a contract to transfer a distinct good or service to the customer and is the unit of account in Topic 606. A contract’s transaction price is allocated to each distinct performance obligation and recognized as revenue when, or as, the performance obligation is satisfied. Certain of the Company’s contracts have multiple performance obligations, as the promise to transfer individual goods or services is separately identifiable from other promises in the contracts and, therefore, is distinct. For contracts with multiple performance obligations, the Company allocates the contract’s transaction price to each performance obligation based on its relative standalone selling price. The stand-alone selling prices are determined based on the prices at which the Company separately sells these products. For items that are not sold separately, the Company estimates the stand-alone selling prices using other observable inputs.

- changed (2024-02-01):
[0000950170-24-009819:note_history:39]
On December 31, 2023, the Company had $548.2 million of remaining performance obligations, which primarily comprised deferred maintenance and deferred SaaS revenues. The Company expects to recognize approximately 32% of its deferred revenue as revenue in the remainder of fiscal 2024, an additional 34% in fiscal 2025, and 34% of the balance thereafter.
  (was, 2023-11-02, similarity 0.9792):
[0000950170-23-058245:note_history:39]
On September 30, 2023, the Company had $525.4 million of remaining performance obligations, which are primarily comprised of deferred maintenance and deferred SaaS revenues. The Company expects to recognize approximately 46% of its deferred revenue as revenue in the remainder of fiscal 2024, an additional 26% in fiscal 2025 and 28% of the balance thereafter.

- changed (2024-02-01):
[0000950170-24-009819:note_history:40]
Revenue recognized for the three months ended December 31, 2023 and 2022 that was included in the deferred revenue balance at the beginning of each period was $105.7 million and $83.9 million, respectively. Revenue recognized for the six months ended December 31, 2023 and 2022 that was included in the deferred revenue balance at the beginning of each period was $172.0 million and $145.7 million, respectively.
  (was, 2023-11-02, similarity 0.6597):
[0000950170-23-058245:note_history:40]
Revenue recognized for the three months ended September 30, 2023 and 2022 that was included in the deferred revenue balance at the beginning of each period was $89.7 million and $80.0 million, respectively.

- changed (2024-02-01):
[0000950170-24-009819:note_history:41]
Contract Costs. The Company recognizes the incremental costs of obtaining contracts as an expense when incurred if the amortization period of the assets that the Company otherwise would have recognized is one year or less. Management expects that commission fees paid to sales representatives as a result of obtaining subscription and support contracts and contract renewals are recoverable and therefore the Company’s condensed consolidated balance sheets included capitalized balances in the amount of $22.2 million and $20.0 million at December 31, 2023 and June 30, 2023, respectively. Capitalized commissions are included within other assets in the condensed consolidated balance sheets. Capitalized commission fees are amortized on a straight-line basis over the average period of service contracts of approximately three years, and are included in “Sales and marketing” in the accompanying condensed consolidated statements of operations. Amortization recognized during the three months ended December 31, 2023 and 2022 was $2.7 million and $2.2 million, respectively. Amortization recognized during the six months ended December 31, 2023 and 2022 was $5.2 million and $4.3 million, respectively.
  (was, 2023-11-02, similarity 0.9412):
[0000950170-23-058245:note_history:41]
Contract Costs. The Company recognizes the incremental costs of obtaining contracts as an expense when incurred if the amortization period of the assets that the Company otherwise would have recognized is one year or less. Management expects that commission fees paid to sales representatives as a result of obtaining subscription and support contracts and contract renewals are recoverable and therefore the Company’s condensed consolidated balance sheets included capitalized balances in the amount of $21.3 million and $20.0 million at September 30, 2023 and June 30, 2023, respectively. Capitalized commissions are included within other assets in the condensed consolidated balance sheets. Capitalized commission fees are amortized on a straight-line basis over the average period of service contracts of approximately three years, and are included in “Sales and marketing” in the accompanying condensed consolidated statements of operations. Amortization recognized during the three months ended September 30, 2023 and 2022, was $2.6 million and $2.1 million, respectively.

- changed (2024-02-01):
[0000950170-24-009819:note_history:42]
The Company operates in three geographic regions: Americas, EMEA (Europe, Middle East and Africa) and APAC (Asia Pacific). The following table sets forth the Company’s net revenues disaggregated by sales channel and geographic region based on the billing addresses of its customers (in thousands):
  (was, 2023-11-02, similarity 0.9932):
[0000950170-23-058245:note_history:42]
The Company operates in three geographic regions: Americas, EMEA (Europe, Middle East and Africa) and APAC (Asia Pacific). The following table sets forth the Company’s revenues disaggregated by sales channel and geographic region based on the billing addresses of its customers (in thousands):

- changed (2024-02-01):
[0000950170-24-009819:note_history:43]
|  |  | Three Months Ended |  |
|  |  | December 31,2023 |  |  | December 31,2022 |  |
|  |  | Distributor |  | Direct |  | Total |  |  | Distributor |  | Direct |  | Total |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  | $ | 81,350 |  | $ | 68,199 |  | $ | 149,549 |  |  | $ | 70,963 |  | $ | 66,630 |  | $ | 137,593 |  |
| Other |  |  | 8,244 |  |  | 4,842 |  |  | 13,086 |  |  |  | 10,807 |  |  | 4,614 |  |  | 15,421 |  |
| Total Americas |  |  | 89,594 |  |  | 73,041 |  |  | 162,635 |  |  |  | 81,770 |  |  | 71,244 |  |  | 153,014 |  |
| EMEA |  |  | 64,082 |  |  | 46,523 |  |  | 110,605 |  |  |  | 97,147 |  |  | 40,903 |  |  | 138,050 |  |
| APAC |  |  | 8,864 |  |  | 14,273 |  |  | 23,137 |  |  |  | 7,403 |  |  | 19,881 |  |  | 27,284 |  |
| Total net revenues |  | $ | 162,540 |  | $ | 133,837 |  | $ | 296,377 |  |  | $ | 186,320 |  | $ | 132,028 |  | $ | 318,348 |  |
  (was, 2023-11-02, similarity 0.9886):
[0000950170-23-058245:note_history:43]
|  |  | Three Months Ended |  |
|  |  | September 30,2023 |  |  | September 30,2022 |  |
|  |  | Distributor |  | Direct |  | Total |  |  | Distributor |  | Direct |  | Total |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  | $ | 117,801 |  | $ | 64,951 |  | $ | 182,752 |  |  | $ | 73,314 |  | $ | 64,312 |  | $ | 137,626 |  |
| Other |  |  | 2,531 |  |  | 10,366 |  |  | 12,897 |  |  |  | 16,025 |  |  | 4,098 |  |  | 20,123 |  |
| Total Americas |  |  | 120,332 |  |  | 75,317 |  |  | 195,649 |  |  |  | 89,339 |  |  | 68,410 |  |  | 157,749 |  |
| EMEA |  |  | 102,311 |  |  | 41,292 |  |  | 143,603 |  |  |  | 76,256 |  |  | 39,253 |  |  | 115,509 |  |
| APAC |  |  | 111 |  |  | 13,774 |  |  | 13,885 |  |  |  | 2,038 |  |  | 22,393 |  |  | 24,431 |  |
| Total net revenues |  | $ | 222,754 |  | $ | 130,383 |  | $ | 353,137 |  |  | $ | 167,633 |  | $ | 130,056 |  | $ | 297,689 |  |

- added (2024-02-01):
[0000950170-24-009819:note_history:44]
|  |  | Six Months Ended |  |
|  |  | December 31,2023 |  |  | December 31,2022 |  |
|  |  | Distributor |  | Direct |  | Total |  |  | Distributor |  | Direct |  | Total |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  | $ | 199,151 |  | $ | 133,150 |  | $ | 332,301 |  |  | $ | 144,277 |  | $ | 130,942 |  | $ | 275,219 |  |
| Other |  |  | 10,775 |  |  | 15,208 |  |  | 25,983 |  |  |  | 26,832 |  |  | 8,712 |  |  | 35,544 |  |
| Total Americas |  |  | 209,926 |  |  | 148,358 |  |  | 358,284 |  |  |  | 171,109 |  |  | 139,654 |  |  | 310,763 |  |
| EMEA |  |  | 166,393 |  |  | 87,815 |  |  | 254,208 |  |  |  | 173,403 |  |  | 80,156 |  |  | 253,559 |  |
| APAC |  |  | 8,975 |  |  | 28,047 |  |  | 37,022 |  |  |  | 9,441 |  |  | 42,274 |  |  | 51,715 |  |
| Total net revenues |  | $ | 385,294 |  | $ | 264,220 |  | $ | 649,514 |  |  | $ | 353,953 |  | $ | 262,084 |  | $ | 616,037 |  |

- added (2024-02-01):
[0000950170-24-009819:note_history:45]
For the three months ended December 31, 2023, the Company generated 10% of its net revenues from Germany. For the six months ended December 31, 2023, the Company generated approximately 11% of its net revenues from the Netherlands. For the three months ended December 31, 2022, the Company generated 11% and 10% of its net revenues from the Netherlands and Germany, respectively. For the six months ended December 31, 2022, the Company generated 10% of its net revenues from each of the Netherlands and Germany. No other foreign country accounted for 10% or more of its net revenues for the three and six months ended December 31, 2023 and 2022.

- removed (2024-02-01):
[0000950170-23-058245:note_history:46]
For the three months ended September 30, 2023, the Company generated 14% of its revenues from the Netherlands. No other foreign country accounted for 10% or more of its revenue for the three months ended September 30, 2023. For the three months ended September 30, 2022, no foreign country accounted for 10% or more of its revenue.


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: no_current_note, score: 0.0

- removed (2024-02-01):
[0000950170-23-058245:note_history:47]
16. Subsequent Events

- removed (2024-02-01):
[0000950170-23-058245:note_history:48]
In October 2023, the Company initiated an additional global reduction-in-force plan to rebalance the workforce to create greater efficiency and improve execution in alignment with our business and strategic priorities while reducing its operating expenses (the “2024 Plan”). The Company is currently evaluating the timing and impact of this reduction-in-force on the Company's business, financial condition and results of operations for the year ending June 30, 2024.
