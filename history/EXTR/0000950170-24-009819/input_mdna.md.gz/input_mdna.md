# EXTR MD&A — 0000950170-24-009819


## mdna

[0000950170-24-009819:mdna:1]
[same as prior period, unchanged from 0000950170-23-058245:mdna:1]

[0000950170-24-009819:mdna:2]
[same as prior period, unchanged from 0000950170-23-058245:mdna:2]

[0000950170-24-009819:mdna:3]
The following discussion is based upon our unaudited condensed consolidated financial statements included elsewhere in this Report. In the course of operating our business, we routinely make decisions as to the timing of the payment of invoices, the collection of receivables, the manufacturing and shipment of products, the fulfillment of orders, the purchase of supplies, and the building of inventory and service parts, among other matters. Each of these decisions has some impact on the financial results for any given period. In making these decisions, we consider various factors, including contractual obligations, customer satisfaction, competition, internal and external financial targets and expectations, and financial planning objectives. For further information about our critical accounting policies and estimates, see the “Critical Accounting Policies and Estimates” section included in this “Management's Discussion and Analysis of Financial Condition and Results of Operations.”

[0000950170-24-009819:mdna:4]
Extreme Networks, Inc. (“Extreme” or “Company”) is a leading provider of cloud networking solutions and industry leading services and support. Extreme designs, develops, and manufactures wired, wireless, and software-defined wide area-network (“SD-WAN”) infrastructure equipment, software and cloud-based management solutions. The Company’s cloud solution is a single platform that offers unified network management of wireless access points, switches, and SD-WAN. It leverages machine learning, Artificial Intelligence for IT Operations and analytics to help customers deliver secure connectivity at the edge of the network, speed cloud deployments, and uncover actionable insights to save time, lower costs and streamline operations. Extreme is currently managing more than two and a half million devices in the cloud.

[0000950170-24-009819:mdna:5]
[same as prior period, unchanged from 0000950170-23-058245:mdna:5]

[0000950170-24-009819:mdna:6]
[same as prior period, unchanged from 0000950170-23-058245:mdna:6]

[0000950170-24-009819:mdna:7]
[same as prior period, unchanged from 0000950170-23-058245:mdna:7]

[0000950170-24-009819:mdna:8]
As the edge of the network continues to expand, our customers are managing more endpoints which comes with a host of challenges. This continued expansion creates issues such as a higher risk of cyberattacks and a need for more bandwidth as a result of an increase in applications running across the network.

[0000950170-24-009819:mdna:9]
Network complexity manifests itself in the form of more endpoints to manage, more applications to monitor, and more services that rely on the network for service delivery and enablement. When performance suffers, and the tug on internal systems and IT staff becomes more intense, technology is often being overworked. Resolving network problems expeditiously and identifying their root cause can improve organizational productivity and result in higher performance of operations.

[0000950170-24-009819:mdna:10]
We believe that the network has never been more vital than it is today. As administrators grapple with more data, coming from more places, more connected devices, and more Software-as-a-Service (“SaaS”) based applications, the cloud is fundamental to managing and maintaining a modern network. Traditional network offerings are not well-suited to fulfill enterprise expectations for rapid delivery of new services, more flexible business models, real-time response, and massive scalability.

[0000950170-24-009819:mdna:11]
As enterprises continue to migrate increasing numbers of applications and services to either private clouds or public clouds offered by third parties and to adopt new IT delivery models and applications, they are required to make fundamental network alterations and enhancements spanning from device access points (“AP”) to the network core. In either case, the network infrastructure must adapt to this new dynamic environment. Intelligence and automation are key if enterprises are to derive maximum benefit from their cloud deployments. With automation applications becoming increasingly critical in manufacturing, warehousing, logistics, healthcare and other key industries, we believe these changes will continue to create demand for networking technology to serve as a foundation to run these services.

[0000950170-24-009819:mdna:12]
[same as prior period, unchanged from 0000950170-23-058245:mdna:12]

[0000950170-24-009819:mdna:13]
We believe Extreme will continue to benefit from the use of its technology to manage distributed campus network architecture centrally from the cloud. Extreme has blended a dynamic fabric attach architecture that delivers simplicity for moves and changes at the edge of the network together with corporate-wide role-based policy. This enables customers to migrate to new cloud managed switching, Wi-Fi, and SD-WAN, agnostic of the existing switching or wireless equipment they already have installed. In the end, we expect these customers to see lower operating and capital expenditures, lower subscription costs, lower overall cost of ownership, and more flexibility along with a more resilient network.

[0000950170-24-009819:mdna:14]
We estimate the total addressable market for our Enterprise Networking solutions consisting of cloud networking, wireless local area networks (“WLAN”), data center networking, ethernet switching, campus local area networks (“LAN”), SD-WAN solutions and management, automation, and elements of the Secure Access Services Edge (“SASE”) market to be over $47 billion, and growing at approximately 12% annually over the next five years. This comprises over $35 billion for networking, infrastructure spanning enterprise and service provider (largely 5G) applications, a $4 billion SD-WAN market, and we also participate in $8 billion of the served addressable market for networking software.

[0000950170-24-009819:mdna:15]
[same as prior period, unchanged from 0000950170-23-058245:mdna:15]

[0000950170-24-009819:mdna:16]
[same as prior period, unchanged from 0000950170-23-058245:mdna:16]

[0000950170-24-009819:mdna:17]
[same as prior period, unchanged from 0000950170-23-058245:mdna:17]

[0000950170-24-009819:mdna:18]
Cloud networking management allows customers to gain real-time visibility and insights into areas such as application usage, location and workflow patterns across their environment, helping to inform strategic business decisions and create personalized experiences. Customers benefit from visibility, control, and reduced time to resolution. This is the cornerstone of our One Network, One Cloud, One Extreme vision.

[0000950170-24-009819:mdna:19]
[same as prior period, unchanged from 0000950170-23-058245:mdna:19]

[0000950170-24-009819:mdna:20]
[same as prior period, unchanged from 0000950170-23-058245:mdna:20]

[0000950170-24-009819:mdna:21]
[same as prior period, unchanged from 0000950170-23-058245:mdna:21]

[0000950170-24-009819:mdna:22]
[same as prior period, unchanged from 0000950170-23-058245:mdna:22]

[0000950170-24-009819:mdna:23]
[same as prior period, unchanged from 0000950170-23-058245:mdna:23]

[0000950170-24-009819:mdna:24]
[same as prior period, unchanged from 0000950170-23-058245:mdna:24]

[0000950170-24-009819:mdna:25]
[same as prior period, unchanged from 0000950170-23-058245:mdna:25]

[0000950170-24-009819:mdna:26]
•
Provide a differentiated end-to-end cloud architecture.  Cloud networking is estimated to be a $8 billion segment of the networking market comprised of cloud managed services and cloud-managed products, which are largely WLAN access points and ethernet switches, growing at 14% annually over the next five years, according to data from the 650 Group. Cloud management technology has evolved significantly over the past decade. We believe we deliver a combination of innovation, reliability, and security with the leading end-to-end cloud management platform powered by ML and AI that spans from the Internet of Things (“IoT”) edge to the enterprise data center. Key characteristics of our cloud architecture include:

[0000950170-24-009819:mdna:27]
[same as prior period, unchanged from 0000950170-23-058245:mdna:27]

[0000950170-24-009819:mdna:28]
[same as prior period, unchanged from 0000950170-23-058245:mdna:28]

[0000950170-24-009819:mdna:29]
[same as prior period, unchanged from 0000950170-23-058245:mdna:29]

[0000950170-24-009819:mdna:30]
[same as prior period, unchanged from 0000950170-23-058245:mdna:30]

[0000950170-24-009819:mdna:31]
[same as prior period, unchanged from 0000950170-23-058245:mdna:31]

[0000950170-24-009819:mdna:32]
[same as prior period, unchanged from 0000950170-23-058245:mdna:32]

[0000950170-24-009819:mdna:33]
[same as prior period, unchanged from 0000950170-23-058245:mdna:33]

[0000950170-24-009819:mdna:34]
[same as prior period, unchanged from 0000950170-23-058245:mdna:34]

[0000950170-24-009819:mdna:35]
[same as prior period, unchanged from 0000950170-23-058245:mdna:35]

[0000950170-24-009819:mdna:36]
[same as prior period, unchanged from 0000950170-23-058245:mdna:36]

[0000950170-24-009819:mdna:37]
[same as prior period, unchanged from 0000950170-23-058245:mdna:37]

[0000950170-24-009819:mdna:38]
[same as prior period, unchanged from 0000950170-23-058245:mdna:38]

[0000950170-24-009819:mdna:39]
[same as prior period, unchanged from 0000950170-23-058245:mdna:39]

[0000950170-24-009819:mdna:40]
[same as prior period, unchanged from 0000950170-23-058245:mdna:40]

[0000950170-24-009819:mdna:41]
[same as prior period, unchanged from 0000950170-23-058245:mdna:41]

[0000950170-24-009819:mdna:42]
•
Enable a common fabric to simplify and automate the network.  Fabric technologies virtualize the network infrastructure (decoupling network services from physical connectivity) which enables network services to be turned up faster, with lower likelihood of error. They make the underlying network much easier to design, implement, manage, and troubleshoot.

[0000950170-24-009819:mdna:43]
•
End-to-End Portfolio. Our cloud-driven solutions provide visibility, control, and strategic intelligence from the edge to the data center, across networks and applications. Our solutions include wired switching, wireless switching, wireless access points, WLAN controllers, routers, and an extensive portfolio of software applications that deliver AI-enhanced access control, network and application analytics, as well as network management. All can be managed, assessed and controlled from a single pane of glass on premises or from the cloud.

[0000950170-24-009819:mdna:44]
[same as prior period, unchanged from 0000950170-23-058245:mdna:44]

[0000950170-24-009819:mdna:45]
•
Extend switching and routing technology leadership.  Our technological leadership is based on innovative switching, routing and wireless products, the depth and focus of our market experience, and our operating systems- the software that runs on all of our networking products. Our products reduce operating expenses for our customers and enable a more flexible and dynamic network environment that will help them meet the upcoming demands of IoT, mobile, and cloud.

[0000950170-24-009819:mdna:46]
•
Expand Wi-Fi technology leadership. Wireless is today’s network access method of choice, and every business must deal with scale, density, and BYOD challenges. Wired and wireless networks are changing as the explosion of mobile and IoT devices increase the demand for high-performance, transparent, and always-on wired to wireless services. The unified access layer requires distributed intelligent components to ensure that access control and resiliency of business services are available across the entire infrastructure and manageable from a single console. We are at a technology inflection point with the pending migration from Wi-Fi 6 solutions to 6 GHz Wi-Fi (Wi-Fi 6E and Wi-Fi 7), focused on providing more efficient access to the broad array of connected devices. We believe we have the industry’s broadest 6 GHz indoor and outdoor wireless portfolio, providing intelligence and security for wired/wireless networks by leveraging our cloud architecture, end-to-end fabric services, UZTNA policy enforcement, and AIOps management platform with Explainable ML insights.

[0000950170-24-009819:mdna:47]
•
Offer a superior quality of experience. Our network-powered application analytics provide actionable business insights by capturing and analyzing context-based data about the network and applications to deliver meaningful intelligence about applications, users, locations, and devices. With an easy-to-comprehend dashboard, our applications help businesses turn their network into a strategic business asset that helps executives make faster and more effective decisions.

[0000950170-24-009819:mdna:48]
[same as prior period, unchanged from 0000950170-23-058245:mdna:48]

[0000950170-24-009819:mdna:49]
[same as prior period, unchanged from 0000950170-23-058245:mdna:49]

[0000950170-24-009819:mdna:50]
•
Maintain and extend our strategic relationships. We have established strategic relationships with a number of industry-leading vendors to both provide increased and enhanced routes to market, and collaboratively develop unique solutions.

[0000950170-24-009819:mdna:51]
[same as prior period, unchanged from 0000950170-23-058245:mdna:51]

[0000950170-24-009819:mdna:52]
[same as prior period, unchanged from 0000950170-23-058245:mdna:52]

[0000950170-24-009819:mdna:53]
During the second quarter of fiscal 2024, we achieved the following results:

[0000950170-24-009819:mdna:54]
•
Net revenues of $296.4 million compared to $318.3 million in the second quarter of fiscal 2023.

[0000950170-24-009819:mdna:55]
•
Product revenues of $186.6 million compared to $223.4 million in the second quarter of fiscal 2023.

[0000950170-24-009819:mdna:56]
•
Subscription and support revenues of $109.8 million compared to $94.9 million in the second quarter of fiscal 2023.

[0000950170-24-009819:mdna:57]
•
Total gross margin of 61.9% of net revenues compared to 57.1% of net revenues in the second quarter of fiscal 2023.

[0000950170-24-009819:mdna:58]
•
Operating income of $10.3 million compared to $23.4 million in the second quarter of fiscal 2023.

[0000950170-24-009819:mdna:59]
•
Net income of $4.0 million compared to $17.9 million in the second quarter of fiscal 2023.

[0000950170-24-009819:mdna:60]
During the first six months of fiscal 2024, we reflected the following results:

[0000950170-24-009819:mdna:61]
•
Cash flows provided by operating activities of $109.9 million compared to $120.3 million in the six months ended December 31, 2022.

[0000950170-24-009819:mdna:62]
•
Cash and cash equivalents of $221.4 million as of December 31, 2023 compared to $234.8 million as of June 30, 2023.

[0000950170-24-009819:mdna:63]
[same as prior period, unchanged from 0000950170-23-058245:mdna:62]

[0000950170-24-009819:mdna:64]
[same as prior period, unchanged from 0000950170-23-058245:mdna:63]

[0000950170-24-009819:mdna:65]
|  |  | Three Months Ended |  | Six Months Ended |
|  |  | December 31,2023 |  | December 31,2022 |  | $Change |  | %Change |  | December 31,2023 |  | December 31,2022 |  | $Change |  | %Change |
| Net revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $186,611 |  | $223,445 |  | $(36,834) |  | (16.5)% |  | $440,094 |  | $429,721 |  | $10,373 |  | 2.4 % |
| Percentage of net revenues |  | 63.0% |  | 70.2% |  |  |  |  |  | 67.8% |  | 69.8% |  |  |  |  |
| Subscription and support |  | 109,766 |  | 94,903 |  | 14,863 |  | 15.7 % |  | 209,420 |  | 186,316 |  | 23,104 |  | 12.4 % |
| Percentage of net revenues |  | 37.0% |  | 29.8% |  |  |  |  |  | 32.2% |  | 30.2% |  |  |  |  |
| Total net revenues |  | $296,377 |  | $318,348 |  | $(21,971) |  | (6.9)% |  | $649,514 |  | $616,037 |  | $33,477 |  | 5.4 % |

[0000950170-24-009819:mdna:66]
Product revenue is generated primarily from sales of our networking equipment. Subscription and support revenue is derived primarily from sales of our subscription and support offerings which includes SaaS offerings, maintenance contracts, professional services and training for its products. Prior to fiscal 2024, subscription and support revenue was referred to as “service and subscription revenue,” however, the composition of subscription and support revenue has not been modified.

[0000950170-24-009819:mdna:67]
Product revenues decreased $36.8 million or 16.5% for the three months ended December 31, 2023 as compared to the corresponding period in fiscal 2023. The decrease in product revenues was primarily driven by lower bookings and shipments as well as elongated sales cycles in the channel caused by current macroeconomic conditions. Product revenues increased $10.4 million or 2.4% for the six months ended December 31, 2023 as compared to the corresponding period in fiscal 2023. The increase in product revenues was primarily due to strong demand for our products and higher shipments of prior period backlog resulting from the easing of supply chain constraints in the first quarter of fiscal 2024.

[0000950170-24-009819:mdna:68]
Subscription and support revenues increased $14.9 million or 15.7% for the three months ended December 31, 2023 as compared to the corresponding period in fiscal 2023. Subscription and support revenues increased $23.1 million or 12.4% for the six months ended December 31, 2023 as compared to the corresponding period in fiscal 2023. The increases in subscription and support revenues were primarily due to the continued growth in our subscription business.

[0000950170-24-009819:mdna:69]
[same as prior period, unchanged from 0000950170-23-058245:mdna:68]

[0000950170-24-009819:mdna:70]
|  |  | Three Months Ended |  | Six Months Ended |
|  |  | December 31,2023 |  | December 31,2022 |  | $Change |  | %Change |  | December 31,2023 |  | December 31,2022 |  | $Change |  | %Change |
| Gross profit: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $105,118 |  | $119,858 |  | $(14,740) |  | (12.3)% |  | $250,065 |  | $226,371 |  | $23,694 |  | 10.5 % |
| Percentage of product revenues |  | 56.3% |  | 53.6% |  |  |  |  |  | 56.8% |  | 52.7% |  |  |  |  |
| Subscription and support |  | 78,252 |  | 61,797 |  | 16,455 |  | 26.6 % |  | 146,241 |  | 121,992 |  | 24,249 |  | 19.9 % |
| Percentage of subscription and support revenues |  | 71.3% |  | 65.1% |  |  |  |  |  | 69.8% |  | 65.5% |  |  |  |  |
| Total gross profit |  | $183,370 |  | $181,655 |  | $1,715 |  | 0.9% |  | $396,306 |  | $348,363 |  | $47,943 |  | 13.8 % |
| Percentage of net revenues |  | 61.9% |  | 57.1% |  |  |  |  |  | 61.0% |  | 56.5% |  |  |  |  |

[0000950170-24-009819:mdna:71]
Product gross profit decreased $14.7 million or 12.3% for the three months ended December 31, 2023 as compared to the corresponding period in fiscal 2023. The decrease in product gross profit was primarily driven by lower product revenues, partially offset by lower intangible asset amortization due to certain intangible assets being fully amortized and favorable purchase price variance and lower distribution costs due to easing of supply chain constraints.

[0000950170-24-009819:mdna:72]
Product gross profit increased $23.7 million or 10.5% for the six months ended December 31, 2023 as compared to the corresponding period in fiscal 2023. The increase in product gross profit was primarily due to higher product revenues along with lower amortization of intangible assets due to certain intangible assets being fully amortized, favorable purchase price variance and distribution costs due to easing of supply chain constraints and lower warranty reserve partially offset by higher reserves for excess and obsolete inventory.

[0000950170-24-009819:mdna:73]
Subscription and support gross profit increased $16.5 million or 26.6% for the three months ended December 31, 2023 as compared to the corresponding period in fiscal 2023.  Subscription and support gross profit increased $24.2 million or 19.9% for the six months ended December 31, 2023 as compared to the corresponding period in fiscal 2023. The increases in subscription and support gross profits were primarily due to increased subscription and support revenues as well as lower personnel costs.

[0000950170-24-009819:mdna:74]
[same as prior period, unchanged from 0000950170-23-058245:mdna:72]

[0000950170-24-009819:mdna:75]
[same as prior period, unchanged from 0000950170-23-058245:mdna:73]

[0000950170-24-009819:mdna:76]
|  |  | Three Months Ended |  | Six Months Ended |
|  |  | December 31,2023 |  | December 31,2022 |  | $Change |  | %Change |  | December 31,2023 |  | December 31,2022 |  | $Change |  | %Change |
| Research and development |  | $52,833 |  | $52,618 |  | $215 |  | 0.4 % |  | $110,849 |  | $103,607 |  | $7,242 |  | 7.0 % |
| Sales and marketing |  | 85,154 |  | 80,538 |  | 4,616 |  | 5.7 % |  | 177,074 |  | 158,920 |  | 18,154 |  | 11.4 % |
| General and administrative |  | 25,384 |  | 24,085 |  | 1,299 |  | 5.4 % |  | 49,257 |  | 42,632 |  | 6,625 |  | 15.5 % |
| Acquisition and integration costs |  | — |  | — |  | — |  | — |  | — |  | 390 |  | (390) |  | (100.0)% |
| Restructuring and related charges |  | 9,174 |  | 476 |  | 8,698 |  | 1,827.3 % |  | 11,891 |  | 957 |  | 10,934 |  | 1,142.5 % |
| Amortization of intangible assets |  | 509 |  | 504 |  | 5 |  | 1.0 % |  | 1,020 |  | 1,027 |  | (7) |  | (0.7)% |
| Total operating expenses |  | $173,054 |  | $158,221 |  | $14,833 |  | 9.4 % |  | $350,091 |  | $307,533 |  | $42,558 |  | 13.8 % |

[0000950170-24-009819:mdna:77]
[same as prior period, unchanged from 0000950170-23-058245:mdna:75]

[0000950170-24-009819:mdna:78]
[same as prior period, unchanged from 0000950170-23-058245:mdna:76]

[0000950170-24-009819:mdna:79]
Research and development expenses increased by $0.2 million or 0.4% for the three months ended December 31, 2023 as compared to the corresponding period in fiscal 2023. The increase in research and development expenses was primarily due to a $2.3 million increase in contractor costs, partially offset by a $1.0 million decrease in personnel costs, a $0.4 million decrease in information technology and facility related expenses, a $0.3 million decrease in equipment related costs, and a $0.4 million decrease in engineering project costs and other costs.

[0000950170-24-009819:mdna:80]
Research and development expenses increased by $7.2 million or 7.0% for the six months ended December 31, 2023 as compared to the corresponding period in fiscal 2023. The increase in research and development expenses was primarily due to a $4.3 million increase in personnel related costs due to higher salaries and benefits costs due to increased headcount during the prior periods and higher share-based compensation, a $4.0 million increase in contractor costs, partially offset by a $0.8 million decrease in engineering project costs and a $0.3 million decrease in information technology and facility related expenses.

[0000950170-24-009819:mdna:81]
[same as prior period, unchanged from 0000950170-23-058245:mdna:78]

[0000950170-24-009819:mdna:82]
[same as prior period, unchanged from 0000950170-23-058245:mdna:79]

[0000950170-24-009819:mdna:83]
Sales and marketing expenses increased by $4.6 million or 5.7% for the three months ended December 31, 2023 as compared to the corresponding period in fiscal 2023. The increase in sales and marketing expenses was primarily due to a $3.0 million increase in sales promotions and marketing related expenses, a $1.3 million increase in personnel costs due to higher salaries and benefits costs, and a $0.2 million increase in travel expenses.

[0000950170-24-009819:mdna:84]
Sales and marketing expenses increased by $18.2 million or 11.4% for the six months ended December 31, 2023 as compared to the corresponding period in fiscal 2023. The increase in sales and marketing expenses was primarily due to a $11.7 million increase in personnel costs due to higher salaries and benefits costs due to increased headcount during the prior periods and higher share-based compensation, a $5.5 million increase in sales promotions and marketing related expenses, a $0.5 million increase in professional fees, a $0.3 million in equipment related costs, and a $0.2 million increase in information technology and facility related expenses.

[0000950170-24-009819:mdna:85]
[same as prior period, unchanged from 0000950170-23-058245:mdna:81]

[0000950170-24-009819:mdna:86]
[same as prior period, unchanged from 0000950170-23-058245:mdna:82]

[0000950170-24-009819:mdna:87]
General and administrative expenses increased by $1.3 million or 5.4% for the three months ended December 31, 2023 as compared to the corresponding period in fiscal 2023. The increase in general and administrative expenses was primarily due to a $1.0 million increase in professional fees and a $0.3 million increase in software licensing and maintenance costs.

[0000950170-24-009819:mdna:88]
General and administrative expenses increased by $6.6 million or 15.5% for the six months ended December 31, 2023 as compared to the corresponding period in fiscal 2023. The increase in general and administrative expenses was primarily due to a $2.8 million increase in personnel costs due to higher compensation and benefits costs primarily related to share-based compensation, a $3.6 million increase in professional fees including increase in legal costs related to litigations and preliminary costs associated with transition of our business systems and a $0.2 million increase in other costs.

[0000950170-24-009819:mdna:89]
[same as prior period, unchanged from 0000950170-23-058245:mdna:84]

[0000950170-24-009819:mdna:90]
During the three months ended December 31, 2023 and 2022, we did not incur any acquisition and integration costs.

[0000950170-24-009819:mdna:91]
During the six months ended December 31, 2023, we did not incur any acquisition and integration costs. During the six months ended December 31, 2022, we incurred acquisition and integration costs of $0.4 million, which primarily consisted of professional fees and certain compensation charges related to the acquisition of Ipanema Tech SAS.

[0000950170-24-009819:mdna:92]
[same as prior period, unchanged from 0000950170-23-058245:mdna:87]

[0000950170-24-009819:mdna:93]
For the three and six months ended December 31, 2023, we recorded restructuring and related charges of $9.2 million and $11.9 million, which primarily consisted of severance and benefits costs associated with the reduction-in-force actions related to the “Q1 2024 Plan” and the “Q2 2024 plan,” each as described in Note 13, Restructuring and Related Charges, in Notes to the Condensed Consolidated Financial Statements included elsewhere in this Report.

[0000950170-24-009819:mdna:94]
For the three and six months ended December 31, 2022, we recorded restructuring charges of $0.5 million and $1.0 million, respectively, which primarily consisted of facility-related charges related to our previously impaired facilities.

[0000950170-24-009819:mdna:95]
[same as prior period, unchanged from 0000950170-23-058245:mdna:90]

[0000950170-24-009819:mdna:96]
During the three months ended December 31, 2023 and 2022, we recorded $0.5 million of operating expenses for each period related to the amortization of intangible assets.

[0000950170-24-009819:mdna:97]
During the six months ended December 31, 2023 and 2022, we recorded $1.0 million of operating expenses for each period related to the amortization of intangible assets.

[0000950170-24-009819:mdna:98]
[same as prior period, unchanged from 0000950170-23-058245:mdna:92]

[0000950170-24-009819:mdna:99]
During the three months ended December 31, 2023 and 2022, we recorded $1.4 million and $0.9 million, respectively, in interest income. The increase in interest income is primarily due to higher interest earned on our cash balance due to rising interest rates.

[0000950170-24-009819:mdna:100]
During the six months ended December 31, 2023 and 2022, we recorded $2.7 million and $1.3 million, respectively, in interest income. The increase in interest income is primarily due to higher interest earned on our cash balance due to rising interest rates.

[0000950170-24-009819:mdna:101]
[same as prior period, unchanged from 0000950170-23-058245:mdna:94]

[0000950170-24-009819:mdna:102]
During the three months ended December 31, 2023 and 2022, we recorded $4.3 million and $3.9 million, respectively, in interest expense. The increase in interest expense was primarily due to higher average rates under the new 2023 Credit Agreement.

[0000950170-24-009819:mdna:103]
During the six months ended December 31, 2023 and 2022, we recorded $8.6 million and $7.7 million, respectively, in interest expense. The increase in interest expense was primarily due to higher average rates under the new 2023 Credit Agreement.

[0000950170-24-009819:mdna:104]
Other Income (Expense), Net

[0000950170-24-009819:mdna:105]
During the three months ended December 31, 2023 and 2022, we recorded other expense, net of $0.4 million and other income, net of $0.1 million, respectively. The other income (expense), net for each period primarily related to the foreign exchange impact from the revaluation of certain assets and liabilities denominated in foreign currencies into U.S. Dollars.

[0000950170-24-009819:mdna:106]
During the six months ended December 31, 2023 and 2022, we recorded other income, net of less than $0.1 million and $0.5 million, respectively. The other income, net for each period primarily related to the foreign exchange impact from the revaluation of certain assets and liabilities denominated in foreign currencies into U.S. Dollars.

[0000950170-24-009819:mdna:107]
[same as prior period, unchanged from 0000950170-23-058245:mdna:98]

[0000950170-24-009819:mdna:108]
For the three months ended December 31, 2023 and 2022, we recorded income tax provision of $3.1 million and $2.6 million, respectively.

[0000950170-24-009819:mdna:109]
For the six months ended December 31, 2023 and 2022, we recorded income tax provision of $7.6 million and $4.4 million, respectively.

[0000950170-24-009819:mdna:110]
The income tax provisions for the three and six months ended December 31, 2023 and 2022 consisted of (1) taxes on the income of our foreign subsidiaries, (2) state taxes in jurisdictions where we have no remaining state net operating losses, (3) foreign withholding taxes, and (4) tax expense associated with the establishment of a U.S. deferred tax liability for amortizable goodwill resulting from the acquisition of Enterasys Networks, Inc., the WLAN business from Zebra Technologies Corporation, the Campus Fabric Business from Avaya LLC and the Data Center Business from Brocade Communications System. In addition, the income tax provision for the three and six months ended December 31, 2023 includes U.S. federal income tax of $0.2 million and $1.6 million, respectively.

[0000950170-24-009819:mdna:111]
[same as prior period, unchanged from 0000950170-23-058245:mdna:101]

[0000950170-24-009819:mdna:112]
Our unaudited condensed consolidated financial statements and the related notes included elsewhere in this Report are prepared in accordance with accounting principles generally accepted in the United States. Certain information and footnote disclosures normally included in financial statements prepared in accordance with U.S. generally accepted accounting principles have been condensed or omitted under SEC rules and regulations. The preparation of these unaudited condensed consolidated financial statements requires us to make estimates and assumptions that affect the reported amounts of assets, liabilities, revenue, costs and expenses, and related disclosures. We base our estimates on historical experience and on various other assumptions that we believe to be reasonable under the circumstances. In many instances, we could have reasonably used different accounting estimates, and in other instances changes in the accounting estimates are reasonably likely to occur from period to period. Accordingly, actual results could differ significantly from the estimates made by our management. On an ongoing basis, we evaluate our estimates and assumptions. To the extent that there are material differences between these estimates and actual results, our future financial statement presentation, financial condition, results of operations, and cash flows will be affected.

[0000950170-24-009819:mdna:113]
[same as prior period, unchanged from 0000950170-23-058245:mdna:103]

[0000950170-24-009819:mdna:114]
[same as prior period, unchanged from 0000950170-23-058245:mdna:104]

[0000950170-24-009819:mdna:115]
[same as prior period, unchanged from 0000950170-23-058245:mdna:105]

[0000950170-24-009819:mdna:116]
[same as prior period, unchanged from 0000950170-23-058245:mdna:106]

[0000950170-24-009819:mdna:117]
[same as prior period, unchanged from 0000950170-23-058245:mdna:107]

[0000950170-24-009819:mdna:118]
[same as prior period, unchanged from 0000950170-23-058245:mdna:108]

[0000950170-24-009819:mdna:119]
|  |  | December 31,2023 |  |  | June 30,2023 |  |
| Cash and cash equivalents |  | $ | 221,403 |  |  | $ | 234,826 |  |

[0000950170-24-009819:mdna:120]
As of December 31, 2023, our principal sources of liquidity consisted of cash and cash equivalents of $221.4 million, accounts receivable, net of $112.0 million, and available borrowings under our five-year 2023 Revolving Facility of $135.5 million. Our principal uses of cash include the purchase of finished goods inventory from our contract manufacturers, payroll and other operating expenses related to the development and marketing of our products, purchases of property and equipment, and repayments of debt and related interest and share repurchases. We believe that our $221.4 million of cash and cash equivalents at December 31, 2023, our cash flow from operations and the availability of borrowings from the 2023 Revolving Facility will be sufficient to fund our planned operations for at least the next 12 months and into the foreseeable future.

[0000950170-24-009819:mdna:121]
On May 18, 2022, our Board of Directors (the “Board”) authorized management to repurchase up to $200.0 million shares of our common stock over a three-year period commencing July 1, 2022. A maximum of $25.0 million may be repurchased in any quarter. On November 17, 2022, the Board increased the authorization to repurchase in any quarter from $25.0 million per quarter to $50.0 million per quarter. Purchases may be made from time to time in the open market or pursuant to 10b5-1 plan. The manner, timing and amount of any future purchases will be determined by our management based on their evaluation of market conditions, stock price, Extreme’s ongoing determination that it is the best use of available cash and other factors. The repurchase program does not obligate us to acquire any shares of its common stock, may be suspended or terminated at any time without prior notice and will be subject to regulatory considerations. During the three months ended December 31, 2023, the Company repurchased 1,485,005 shares of its common stock on the open market at a total cost of $25.0 million with an average price of $16.81 per share. During the six months ended December 31, 2023, the Company repurchased a total of 2,365,220 shares of its common stock on the open market at a total cost of $49.9 million with an average price of $21.08 per share. As of December 31, 2023, we had $50.3 million available under our share repurchase program.

[0000950170-24-009819:mdna:122]
On August 9, 2019, we entered into an Amended and Restated Credit Agreement (the “2019 Credit Agreement”), by and among Extreme, as borrower, several banks and other financial institutions as Lenders, BMO Harris Bank N.A., as an issuing lender and swingline lender, Silicon Valley Bank, as an Issuing Lender, and Bank of Montreal, as administrative agent and collateral agent for the Lenders. On June 22, 2023, we entered into the Second Amended and Restated Credit Agreement (the “2023 Credit Agreement”) by and among Extreme, as borrower, BMO Harris Bank, N.A., as an issuing lender and swingline lender, Bank of America, N.A., JPMorgan Chase Bank, N.A., PNC Bank, National Association and Wells Fargo Bank, National Association, as issuing lenders, the financial institutions or entities party thereto as lenders, and Bank of Montreal, as an administrative agent and collateral agent, which amended and restated the 2019 Credit Agreement. The 2023 Credit Agreement provides for i) a $200.0 million first lien term loan facility in an aggregate principal amount (the “Term Facility”), ii) a $150.0 million five-year revolving credit facility (the “ 2023 Revolving Facility”) and iii) an uncommitted additional incremental loan facility in the principal amount of up to $100.0 million plus an unlimited amount that is subject to pro forma compliance with a specified Consolidated Leverage Ratio tests. We may use proceeds of the loans for working capital and general corporate purposes. On June 22, 2023, we borrowed $25.0 million against the 2023 Revolving Facility, which was subsequently paid off on July 7, 2023.

[0000950170-24-009819:mdna:123]
At our election, the initial term loan (the “Initial Term Loan”) under the 2023 Credit Agreement may be made as either a base rate loan or a Secured Overnight Financing Data Rate loan (“SOFR loan”). The applicable margin for base rate loans ranges from 1.00% to 1.75% per annum, and the applicable margin for SOFR loans ranges from 2.00% to 2.75%, in each case based on the Company’s Consolidated Leverage Ratio. All SOFR loans are subject to a floor of 0.00% per annum and spread adjustment of 0.10% per annum. We also agreed to pay other closing fees, arrangement fees, and administration fees.

[0000950170-24-009819:mdna:124]
The 2023 Credit Agreement requires us to maintain certain minimum financial ratios at the end of each fiscal quarter. The 2023 Credit Agreement also includes covenants and restrictions that limit, among other things, our ability to incur additional indebtedness, create liens upon any of its property, merge, consolidate or sell all or substantially all of its assets. The 2023 Credit Agreement also includes customary events of default which may result in acceleration of the outstanding balance.

[0000950170-24-009819:mdna:125]
During the three and six months ended December 31, 2023, we were in compliance with all the original terms and financial covenants under the 2023 Credit Agreement.

[0000950170-24-009819:mdna:126]
[same as prior period, unchanged from 0000950170-23-058245:mdna:116]

[0000950170-24-009819:mdna:127]
[same as prior period, unchanged from 0000950170-23-058245:mdna:117]

[0000950170-24-009819:mdna:128]
|  |  | Six Months Ended |  |
|  |  | December 31,2023 |  |  | December 31,2022 |  |
| Net cash provided by operating activities |  | $ | 109,865 |  |  | $ | 120,337 |  |
| Net cash used in investing activities |  |  | (9,955 | ) |  |  | (6,271 | ) |
| Net cash used in financing activities |  |  | (113,242 | ) |  |  | (105,611 | ) |
| Foreign currency effect on cash and cash equivalents |  |  | (91 | ) |  |  | (456 | ) |
| Net increase (decrease) in cash and cash equivalents |  | $ | (13,423 | ) |  | $ | 7,999 |  |

[0000950170-24-009819:mdna:129]
[same as prior period, unchanged from 0000950170-23-058245:mdna:119]

[0000950170-24-009819:mdna:130]
Cash flows provided by operations in the six months ended December 31, 2023 were $109.9 million, including our net income of $32.7 million and non-cash expenses of $57.4 million for items such as amortization of intangible assets, share-based compensation, depreciation, reduction in carrying amount of right-of-use assets, deferred income taxes, and interest. Other sources of cash for the period included a decrease in accounts receivable, and increases in deferred revenue and other current and long-term liabilities. This was partially offset by increases in inventories and prepaid expenses and other assets as well as decreases in accounts payable and accrued compensation and benefits.

[0000950170-24-009819:mdna:131]
Cash flows provided by operations in the six months ended December 31, 2022 were $120.3 million, including our net income of $30.5 million and non-cash expenses of $50.3 million for items such as amortization of intangible assets, share-based compensation, depreciation, reduction in carrying amount of right-of-use assets, deferred income taxes and interest. Other sources of cash for the period included a decrease in accounts receivable and increases in accounts payable, accrued compensation and deferred revenue. This was partially offset by increases in inventories, prepaid expenses and other current assets, and decreases in operating lease liabilities and other current and long-term liabilities.

[0000950170-24-009819:mdna:132]
[same as prior period, unchanged from 0000950170-23-058245:mdna:122]

[0000950170-24-009819:mdna:133]
Cash flows used in investing activities in the six months ended December 31, 2023 were $10.0 million for the purchases of property and equipment.

[0000950170-24-009819:mdna:134]
Cash flows used in investing activities in the six months ended December 31, 2022 were $6.3 million for the purchases of property and equipment.

[0000950170-24-009819:mdna:135]
[same as prior period, unchanged from 0000950170-23-058245:mdna:125]

[0000950170-24-009819:mdna:136]
Cash flows used in financing activities in the six months ended December 31, 2023 were $113.2 million primarily due to payment of $33.4 million for taxes paid on vested and released stock awards net of proceeds from the issuance of shares of our common stock under our Employee Stock Purchase Plan ("ESPP") and exercise of stock options, share repurchase of $49.9 million under our share repurchase program, a $25.0 million payment against our revolving facility, and debt repayment of $5.0 million.

[0000950170-24-009819:mdna:137]
Cash flows used in financing activities in the six months ended December 31, 2022 were $105.6 million primarily due to debt repayments of $46.6 million, $2.0 million for deferred payments on acquisitions, share repurchase of $49.8 million under our share repurchase program, and $7.2 million for taxes paid on vested and released stock awards net of proceeds from the issuance of shares of our common stock under our ESPP.

[0000950170-24-009819:mdna:138]
[same as prior period, unchanged from 0000950170-23-058245:mdna:128]

[0000950170-24-009819:mdna:139]
Foreign currency effect on cash and cash equivalents decreased in the six months ended December 31, 2023, primarily due to changes in foreign currency exchange rates between the U.S. Dollar and particularly the Indian Rupee, the UK Pound and the Euro.

[0000950170-24-009819:mdna:140]
[same as prior period, unchanged from 0000950170-23-058245:mdna:130]

[0000950170-24-009819:mdna:141]
As of December 31, 2023, we had contractual obligations resulting from our debt arrangement, agreements to purchase goods and services in the ordinary course of business and obligations under our operating lease arrangements.

[0000950170-24-009819:mdna:142]
Our debt obligations relate to amounts owed under our 2023 Credit Agreement. As of December 31, 2023, we had $195.0 million of debt outstanding which is payable on quarterly installments through our fiscal year 2028. We are subject to interest on our debt obligations and unused commitment fee. See Note 7, Debt, in the Notes to Condensed Consolidated Financial Statements in this Report for additional information regarding our debt obligations.

[0000950170-24-009819:mdna:143]
Our unconditional purchase obligations represent the purchase of long lead-time component inventory that our contract manufacturers procure in accordance with our forecast. We expect to honor the inventory purchase commitments within the next 12 months. As of December 31, 2023, we had non-cancelable commitments to purchase $92.1 million of inventory. See Note 8, Commitments and Contingencies, in the Notes to Condensed Consolidated Financial Statements for additional information regarding our purchase obligations.

[0000950170-24-009819:mdna:144]
We have contractual commitments to our suppliers which represent commitments for future services. As of December 31, 2023, we had contractual commitments of $30.2 million that are due through our fiscal year 2027.

[0000950170-24-009819:mdna:145]
We lease facilities under operating lease arrangements at various locations that expire at various dates through our fiscal year 2033. As of December 31, 2023, the value of our obligations under operating leases was $65.7 million.

[0000950170-24-009819:mdna:146]
[same as prior period, unchanged from 0000950170-23-058245:mdna:136]

[0000950170-24-009819:mdna:147]
We did not have any material commitments for capital expenditures as of December 31, 2023.

[0000950170-24-009819:mdna:148]
[same as prior period, unchanged from 0000950170-23-058245:mdna:138]

[0000950170-24-009819:mdna:149]
We did not have any off-balance sheet arrangements as of December 31, 2023.
