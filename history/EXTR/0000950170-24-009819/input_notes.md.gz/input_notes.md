# EXTR notes — 0000950170-24-009819


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0000950170-24-009819:notes:1]
[same as prior period, unchanged from 0000950170-23-058245:notes:1]

[0000950170-24-009819:notes:2]
Extreme Networks, Inc., together with its subsidiaries (collectively referred to as “Extreme” or the “Company”), is a leader in providing software-driven networking solutions for enterprise customers. The Company conducts its sales and marketing activities on a worldwide basis through distributors, resellers, and the Company’s field sales organization. Extreme was incorporated in California in 1996 and reincorporated in Delaware in 1999.

[0000950170-24-009819:notes:3]
[same as prior period, unchanged from 0000950170-23-058245:notes:3]

[0000950170-24-009819:notes:4]
The unaudited condensed consolidated financial statements reflect all adjustments, consisting only of normal recurring adjustments that, in the opinion of management, are necessary for a fair presentation of the results of operations and cash flows for the interim periods presented and the financial condition of Extreme at December 31, 2023. The results of operations for the three and six months ended December 31, 2023 are not necessarily indicative of the results that may be expected for fiscal 2024 or any future periods.

[0000950170-24-009819:notes:5]
[same as prior period, unchanged from 0000950170-23-058245:notes:5]

[0000950170-24-009819:notes:6]
[same as prior period, unchanged from 0000950170-23-058245:notes:6]

[0000950170-24-009819:notes:7]
[same as prior period, unchanged from 0000950170-23-058245:notes:7]

[0000950170-24-009819:notes:8]
[same as prior period, unchanged from 0000950170-23-058245:notes:8]

[0000950170-24-009819:notes:9]
The Company predominantly uses the United States Dollar as its functional currency. The functional currency for certain of its foreign subsidiaries is the local currency. For those subsidiaries that operate in a local functional currency environment, all assets and liabilities are translated to United States Dollars at current month end rates of exchange and revenues, and expenses are translated using the monthly average rate.

[0000950170-24-009819:notes:10]
[same as prior period, unchanged from 0000950170-23-058245:notes:10]

[0000950170-24-009819:notes:11]
[same as prior period, unchanged from 0000950170-23-058245:notes:11]


## us-gaap:SignificantAccountingPoliciesTextBlock

[0000950170-24-009819:notes:12]
[same as prior period, unchanged from 0000950170-23-058245:notes:12]

[0000950170-24-009819:notes:13]
[same as prior period, unchanged from 0000950170-23-058245:notes:13]

[0000950170-24-009819:notes:14]
Recently Adopted Accounting Pronouncements

[0000950170-24-009819:notes:15]
There were no recently adopted accounting standards which would have a material effect on our condensed consolidated financial statements and accompanying disclosures.

[0000950170-24-009819:notes:16]
Recently Issued Accounting Pronouncements Not Yet Adopted

[0000950170-24-009819:notes:17]
In November 2023, the Financial Accounting Standards Board (“FASB”) issued Accounting Standards Update (“ASU”) 2023-07, Segment Reporting (Topic 280): Improvements to Reportable Segment Disclosures to improve reportable segment disclosure requirements primarily through enhanced disclosures about significant segment expenses and information used to assess segment performance. All disclosure requirements of ASU 2023-07 are required for entities with a single reportable segment. ASU 2023-07 is effective for fiscal years beginning after December 15, 2023, and interim periods for fiscal years beginning after December 15, 2024, and should be applied on a retrospective basis to all periods presented. Early adoption is permitted. The Company is currently evaluating the impact of adopting ASU 2023-07 on its consolidated financial statements and related disclosures.

[0000950170-24-009819:notes:18]
In December 2023, the FASB issued ASU 2023-09, Income Taxes (Topic 740), Improvements to Income Tax Disclosures to enhance income tax disclosures primarily through changes in the rate reconciliation and income taxes paid information. ASU 2023-09 is effective for fiscal years beginning after December 15, 2024 on a prospective basis. Early adoption is permitted. The Company is currently evaluating the impact of adopting ASU 2023-09 on its consolidated financial statements and related disclosures.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0000950170-24-009819:notes:19]
[same as prior period, unchanged from 0000950170-23-058245:notes:16]

[0000950170-24-009819:notes:20]
The Company accounts for revenues in accordance with Accounting Standards Codification (“ASC”) 606, Revenue from Contracts with Customers. The Company derives the majority of its revenues from sales of its networking equipment, with the remaining revenues generated from sales of subscription and support, which primarily includes software subscriptions delivered as software as a service (“SaaS”) and additional revenues from maintenance contracts, professional services and training for its products. The Company sells its products,  SaaS, and maintenance contracts direct to customers and to partners in two distribution channels, or tiers. The first tier consists of a limited number of independent distributors that stock the Company's products and sell primarily to resellers. The second tier of the distribution channel consists of non-stocking distributors and value-added resellers that sell directly to end-users. Products and subscription and support may be sold separately or in bundled packages.

[0000950170-24-009819:notes:21]
[same as prior period, unchanged from 0000950170-23-058245:notes:19]

[0000950170-24-009819:notes:22]
Performance Obligations. A performance obligation is a promise in a contract to transfer a distinct good or service to the customer and is the unit of account in ASC 606. A contract’s transaction price is allocated to each distinct performance obligation and recognized as revenue when, or as, the performance obligation is satisfied. Certain of the Company’s contracts have multiple performance obligations, as the promise to transfer individual goods or services is separately identifiable from other promises in the contracts and, therefore, is distinct. For contracts with multiple performance obligations, the Company allocates the contract’s transaction price to each performance obligation based on its relative standalone selling price. The stand-alone selling prices are determined based on the prices at which the Company separately sells these products. For items that are not sold separately, the Company estimates the stand-alone selling prices using other observable inputs.

[0000950170-24-009819:notes:23]
[same as prior period, unchanged from 0000950170-23-058245:notes:21]

[0000950170-24-009819:notes:24]
On December 31, 2023, the Company had $548.2 million of remaining performance obligations, which primarily comprised deferred maintenance and deferred SaaS revenues. The Company expects to recognize approximately 32% of its deferred revenue as revenue in the remainder of fiscal 2024, an additional 34% in fiscal 2025, and 34% of the balance thereafter.

[0000950170-24-009819:notes:25]
[same as prior period, unchanged from 0000950170-23-058245:notes:23]

[0000950170-24-009819:notes:26]
Revenue recognized for the three months ended December 31, 2023 and 2022 that was included in the deferred revenue balance at the beginning of each period was $105.7 million and $83.9 million, respectively. Revenue recognized for the six months ended December 31, 2023 and 2022 that was included in the deferred revenue balance at the beginning of each period was $172.0 million and $145.7 million, respectively.

[0000950170-24-009819:notes:27]
Contract Costs. The Company recognizes the incremental costs of obtaining contracts as an expense when incurred if the amortization period of the assets that the Company otherwise would have recognized is one year or less. Management expects that commission fees paid to sales representatives as a result of obtaining subscription and support contracts and contract renewals are recoverable and therefore the Company’s condensed consolidated balance sheets included capitalized balances in the amount of $22.2 million and $20.0 million at December 31, 2023 and June 30, 2023, respectively. Capitalized commissions are included within other assets in the condensed consolidated balance sheets. Capitalized commission fees are amortized on a straight-line basis over the average period of service contracts of approximately three years, and are included in “Sales and marketing” in the accompanying condensed consolidated statements of operations. Amortization recognized during the three months ended December 31, 2023 and 2022 was $2.7 million and $2.2 million, respectively. Amortization recognized during the six months ended December 31, 2023 and 2022 was $5.2 million and $4.3 million, respectively.

[0000950170-24-009819:notes:28]
[same as prior period, unchanged from 0000950170-23-058245:notes:26]

[0000950170-24-009819:notes:29]
[same as prior period, unchanged from 0000950170-23-058245:notes:27]

[0000950170-24-009819:notes:30]
The Company operates in three geographic regions: Americas, EMEA (Europe, Middle East and Africa) and APAC (Asia Pacific). The following table sets forth the Company’s net revenues disaggregated by sales channel and geographic region based on the billing addresses of its customers (in thousands):

[0000950170-24-009819:notes:31]
|  |  | Three Months Ended |  |
|  |  | December 31,2023 |  |  | December 31,2022 |  |
|  |  | Distributor |  | Direct |  | Total |  |  | Distributor |  | Direct |  | Total |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  | $ | 81,350 |  | $ | 68,199 |  | $ | 149,549 |  |  | $ | 70,963 |  | $ | 66,630 |  | $ | 137,593 |  |
| Other |  |  | 8,244 |  |  | 4,842 |  |  | 13,086 |  |  |  | 10,807 |  |  | 4,614 |  |  | 15,421 |  |
| Total Americas |  |  | 89,594 |  |  | 73,041 |  |  | 162,635 |  |  |  | 81,770 |  |  | 71,244 |  |  | 153,014 |  |
| EMEA |  |  | 64,082 |  |  | 46,523 |  |  | 110,605 |  |  |  | 97,147 |  |  | 40,903 |  |  | 138,050 |  |
| APAC |  |  | 8,864 |  |  | 14,273 |  |  | 23,137 |  |  |  | 7,403 |  |  | 19,881 |  |  | 27,284 |  |
| Total net revenues |  | $ | 162,540 |  | $ | 133,837 |  | $ | 296,377 |  |  | $ | 186,320 |  | $ | 132,028 |  | $ | 318,348 |  |

[0000950170-24-009819:notes:32]
|  |  | Six Months Ended |  |
|  |  | December 31,2023 |  |  | December 31,2022 |  |
|  |  | Distributor |  | Direct |  | Total |  |  | Distributor |  | Direct |  | Total |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  | $ | 199,151 |  | $ | 133,150 |  | $ | 332,301 |  |  | $ | 144,277 |  | $ | 130,942 |  | $ | 275,219 |  |
| Other |  |  | 10,775 |  |  | 15,208 |  |  | 25,983 |  |  |  | 26,832 |  |  | 8,712 |  |  | 35,544 |  |
| Total Americas |  |  | 209,926 |  |  | 148,358 |  |  | 358,284 |  |  |  | 171,109 |  |  | 139,654 |  |  | 310,763 |  |
| EMEA |  |  | 166,393 |  |  | 87,815 |  |  | 254,208 |  |  |  | 173,403 |  |  | 80,156 |  |  | 253,559 |  |
| APAC |  |  | 8,975 |  |  | 28,047 |  |  | 37,022 |  |  |  | 9,441 |  |  | 42,274 |  |  | 51,715 |  |
| Total net revenues |  | $ | 385,294 |  | $ | 264,220 |  | $ | 649,514 |  |  | $ | 353,953 |  | $ | 262,084 |  | $ | 616,037 |  |

[0000950170-24-009819:notes:33]
For the three months ended December 31, 2023, the Company generated 10% of its net revenues from Germany. For the six months ended December 31, 2023, the Company generated approximately 11% of its net revenues from the Netherlands. For the three months ended December 31, 2022, the Company generated 11% and 10% of its net revenues from the Netherlands and Germany, respectively. For the six months ended December 31, 2022, the Company generated 10% of its net revenues from each of the Netherlands and Germany. No other foreign country accounted for 10% or more of its net revenues for the three and six months ended December 31, 2023 and 2022.

[0000950170-24-009819:notes:34]
[same as prior period, unchanged from 0000950170-23-058245:notes:31]

[0000950170-24-009819:notes:35]
[same as prior period, unchanged from 0000950170-23-058245:notes:32]

[0000950170-24-009819:notes:36]
[same as prior period, unchanged from 0000950170-23-058245:notes:33]

[0000950170-24-009819:notes:37]
|  |  | Three Months Ended |  | Six Months Ended |
|  |  | December 31,2023 |  | December 31,2022 |  | December 31,2023 |  | December 31,2022 |
| Jenne, Inc. |  | 23% |  | 13% |  | 25% |  | 13% |
| Westcon Group, Inc. |  | 10% |  | 19% |  | 18% |  | 17% |
| TD Synnex Corporation |  | 24% |  | 17% |  | 21% |  | 18% |
| ScanSource, Inc. |  | * |  | 11% |  | * |  | * |
| * Less than 10% of revenue |  |  |  |  |  |  |  |  |

[0000950170-24-009819:notes:38]
[same as prior period, unchanged from 0000950170-23-058245:notes:35]

[0000950170-24-009819:notes:39]
|  |  | December 31,2023 |  | June 30,2023 |
| Jenne, Inc. |  | 52% |  | 39% |
| TD Synnex Corporation |  | * |  | 10% |
| ScanSource, Inc. |  | * |  | 10% |
| Ingram Micro |  | 10% |  | * |
| * Less than 10% of accounts receivable |  |  |  |  |

[0000950170-24-009819:notes:40]
The Company's net accounts receivable balance with Jenne, Inc. as of December 31, 2023 is current and the Company expects to collect the majority of this balance by March 31, 2024.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0000950170-24-009819:notes:41]
[same as prior period, unchanged from 0000950170-23-058245:notes:38]

[0000950170-24-009819:notes:42]
Cash and Cash Equivalents

[0000950170-24-009819:notes:43]
[same as prior period, unchanged from 0000950170-23-058245:notes:40]

[0000950170-24-009819:notes:44]
[same as prior period, unchanged from 0000950170-23-058245:notes:41]

[0000950170-24-009819:notes:45]
|  |  | December 31,2023 |  |  | June 30,2023 |  |
| Cash |  | $ | 211,526 |  |  | $ | 227,675 |  |
| Cash equivalents |  |  | 9,877 |  |  |  | 7,151 |  |
| Total cash and cash equivalents |  | $ | 221,403 |  |  | $ | 234,826 |  |

[0000950170-24-009819:notes:46]
[same as prior period, unchanged from 0000950170-23-058245:notes:43]

[0000950170-24-009819:notes:47]
[same as prior period, unchanged from 0000950170-23-058245:notes:44]

[0000950170-24-009819:notes:48]
[same as prior period, unchanged from 0000950170-23-058245:notes:45]

[0000950170-24-009819:notes:49]
|  |  | December 31,2023 |  |  | June 30,2023 |  |
| Finished goods |  | $ | 124,668 |  |  | $ | 78,180 |  |
| Raw materials |  |  | 27,853 |  |  |  | 10,844 |  |
| Total inventories |  | $ | 152,521 |  |  | $ | 89,024 |  |

[0000950170-24-009819:notes:50]
[same as prior period, unchanged from 0000950170-23-058245:notes:47]

[0000950170-24-009819:notes:51]
[same as prior period, unchanged from 0000950170-23-058245:notes:48]

[0000950170-24-009819:notes:52]
|  |  | December 31,2023 |  |  | June 30,2023 |  |
| Computers and equipment |  | $ | 83,633 |  |  | $ | 81,612 |  |
| Purchased software |  |  | 54,378 |  |  |  | 51,444 |  |
| Office equipment, furniture and fixtures |  |  | 9,002 |  |  |  | 8,899 |  |
| Leasehold improvements |  |  | 51,563 |  |  |  | 48,943 |  |
| Total property and equipment |  |  | 198,576 |  |  |  | 190,898 |  |
| Less: accumulated depreciation and amortization |  |  | (150,978 | ) |  |  | (144,450 | ) |
| Property and equipment, net |  | $ | 47,598 |  |  | $ | 46,448 |  |

[0000950170-24-009819:notes:53]
[same as prior period, unchanged from 0000950170-23-058245:notes:50]

[0000950170-24-009819:notes:54]
[same as prior period, unchanged from 0000950170-23-058245:notes:51]

[0000950170-24-009819:notes:55]
[same as prior period, unchanged from 0000950170-23-058245:notes:52]

[0000950170-24-009819:notes:56]
The majority of the Company’s hardware products are shipped with either a one-year warranty or a limited lifetime warranty, and software products receive a 90-day warranty. Upon shipment of products to its customers, the Company estimates expenses for the cost to repair or replace products that may be returned under warranty and accrues a liability in cost of product revenues for this amount. The determination of the Company’s warranty requirements is based on actual historical experience with the product or product family, estimates of repair and replacement costs, and any product warranty problems that are identified after shipment. The Company estimates and adjusts these accruals at each balance sheet date in accordance with changes in these factors.

[0000950170-24-009819:notes:57]
[same as prior period, unchanged from 0000950170-23-058245:notes:54]

[0000950170-24-009819:notes:58]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | December 31,2023 |  |  | December 31,2022 |  |  | December 31,2023 |  |  | December 31,2022 |  |
| Balance beginning of period |  | $ | 12,164 |  |  | $ | 11,522 |  |  | $ | 12,322 |  |  | $ | 10,852 |  |
| New warranties issued |  |  | 2,777 |  |  |  | 3,807 |  |  |  | 6,451 |  |  |  | 7,815 |  |
| Warranty expenditures |  |  | (3,544 | ) |  |  | (3,509 | ) |  |  | (7,376 | ) |  |  | (6,847 | ) |
| Balance end of period |  | $ | 11,397 |  |  | $ | 11,820 |  |  | $ | 11,397 |  |  | $ | 11,820 |  |

[0000950170-24-009819:notes:59]
[same as prior period, unchanged from 0000950170-23-058245:notes:56]

[0000950170-24-009819:notes:60]
[same as prior period, unchanged from 0000950170-23-058245:notes:57]

[0000950170-24-009819:notes:61]
The Company may be subject to concentration of credit risk as a result of certain financial instruments consisting of accounts receivable. See Note 3, Revenues, for the Company’s accounts receivable concentration. The Company does not invest an amount exceeding 10% of its combined cash in the securities of any one obligor or maker, except for obligations of the United States government, obligations of United States government agencies, and money market accounts.


## us-gaap:FairValueDisclosuresTextBlock

[0000950170-24-009819:notes:62]
[same as prior period, unchanged from 0000950170-23-058245:notes:59]

[0000950170-24-009819:notes:63]
[same as prior period, unchanged from 0000950170-23-058245:notes:60]

[0000950170-24-009819:notes:64]
[same as prior period, unchanged from 0000950170-23-058245:notes:61]

[0000950170-24-009819:notes:65]
[same as prior period, unchanged from 0000950170-23-058245:notes:62]

[0000950170-24-009819:notes:66]
[same as prior period, unchanged from 0000950170-23-058245:notes:63]

[0000950170-24-009819:notes:67]
The following table presents the Company’s fair value hierarchy for its financial assets and liabilities measured at fair value on a recurring basis at December 31, 2023 and June 30, 2023 (in thousands):

[0000950170-24-009819:notes:68]
| December 31, 2023 |  | Level 1 |  |  | Level 2 |  |  | Level 3 |  |  | Total |  |
| Assets |  |  |  |  |  |  |  |  |  |  |  |  |
| Certificates of deposit |  | $ | — |  |  | $ | 9,877 |  |  | $ | — |  |  | $ | 9,877 |  |
| Foreign currency derivatives |  |  | — |  |  |  | 133 |  |  |  | — |  |  |  | 133 |  |
| Total assets measured at fair value |  | $ | — |  |  | $ | 10,010 |  |  | $ | — |  |  | $ | 10,010 |  |

[0000950170-24-009819:notes:69]
[same as prior period, unchanged from 0000950170-23-058245:notes:66]

[0000950170-24-009819:notes:70]
The Company’s financial instruments consist of cash, accounts receivable, accounts payable, and accrued liabilities. The Company states accounts receivable, accounts payable, and accrued liabilities at their carrying value, which approximates fair value due to the short time to the expected receipt or payment.

[0000950170-24-009819:notes:71]
The Company's level 2 assets consist of certificates of deposit and derivative instruments. Certificates of deposit do not have regular market pricing and are considered Level 2. The fair value of derivative instruments under the Company’s foreign exchange forward contracts are estimated based on valuations provided by alternative pricing sources supported by observable inputs, which is considered Level 2.

[0000950170-24-009819:notes:72]
As of December 31, 2023 and June 30, 2023, the Company had investment in certificates of deposit of $9.9 million and $7.2 million, respectively, with maturity of three months at the date of purchase, which are recorded as cash equivalents in the condensed consolidated balance sheets. The Company considers these cash equivalents to be available-for-sale and, as of December 31, 2023 and June 30, 2023, their fair value approximated their amortized cost.

[0000950170-24-009819:notes:73]
As of December 31, 2023 and June 30, 2023, the Company had foreign exchange forward contracts that were not designated as hedging instruments with notional principal amounts of $15.6 million and $3.4 million, respectively. These contracts currently have maturities of 40 days or less. Changes in the fair value of these foreign exchange forward contracts not designated as hedging instruments are included in other income, net in the condensed consolidated statements of operations. For the three months ended December 31, 2023 and 2022, there were net gains of $0.4 million and $0.1 million, respectively. For the six months ended December 31, 2023 and 2022, there were net gains of $0.3 million and net losses of $0.4 million, respectively. As of December 31, 2023 and June 30, 2023, there were no outstanding foreign exchange forward contracts that were designated as hedging instruments. See Note 12, Derivatives and Hedging, for additional information.

[0000950170-24-009819:notes:74]
The fair value of borrowings under the 2023 Credit Agreement (as defined in Note 7) is estimated based on valuations provided by alternative pricing sources supported by observable inputs which is considered Level 2. Since the interest rate is variable in the 2023 Credit Agreement, the fair value approximates the face amount of the Company’s indebtedness of $195.0 million and $225.0 million as of December 31, 2023 and June 30, 2023, respectively.

[0000950170-24-009819:notes:75]
Certain of the Company’s assets, including intangible assets and goodwill, are measured at fair value on a non-recurring basis if impairment is indicated.

[0000950170-24-009819:notes:76]
As of December 31, 2023 and June 30, 2023, the Company did not have any assets or liabilities that were considered Level 3. 
There were no transfers of assets or liabilities between Level 1, Level 2, and Level 3 during the three and six months ended December 31, 2023 and 2022. There were no impairments recorded for the three and six months ended December 31, 2023 and 2022.


## us-gaap:IntangibleAssetsDisclosureTextBlock

[0000950170-24-009819:notes:77]
[same as prior period, unchanged from 0000950170-23-058245:notes:75]

[0000950170-24-009819:notes:78]
[same as prior period, unchanged from 0000950170-23-058245:notes:76]

[0000950170-24-009819:notes:79]
[same as prior period, unchanged from 0000950170-23-058245:notes:77]

[0000950170-24-009819:notes:80]
|  |  | Weighted Average |  |  |  |  |  |  |  |  |  |
|  |  | Remaining Amortization |  | Gross Carrying |  |  | Accumulated |  |  | Net Carrying |  |
|  |  | Period |  | Amount |  |  | Amortization |  |  | Amount |  |
| December 31, 2023 |  |  |  |  |  |  |  |  |  |  |  |
| Developed technology |  | 4.1 years |  | $ | 169,646 |  |  | $ | 161,690 |  |  | $ | 7,956 |  |
| Customer relationships |  | 2.9 years |  |  | 64,721 |  |  |  | 59,787 |  |  |  | 4,934 |  |
| Trade names |  | 0 years |  |  | 10,700 |  |  |  | 10,700 |  |  |  | — |  |
| License agreements |  | 2.9 years |  |  | 2,445 |  |  |  | 2,231 |  |  |  | 214 |  |
| Total intangible assets, net* |  |  |  | $ | 247,512 |  |  | $ | 234,408 |  |  | $ | 13,104 |  |
| * The carrying amount of foreign intangible assets are affected by foreign currency translation |  |  |  |  |

[0000950170-24-009819:notes:81]
[same as prior period, unchanged from 0000950170-23-058245:notes:79]

[0000950170-24-009819:notes:82]
[same as prior period, unchanged from 0000950170-23-058245:notes:80]

[0000950170-24-009819:notes:83]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | December 31,2023 |  |  | December 31,2022 |  |  | December 31,2023 |  |  | December 31,2022 |  |
| Amortization of intangible assets in “Total cost of revenues” |  | $ | 611 |  |  | $ | 3,220 |  |  | $ | 2,044 |  |  | $ | 6,825 |  |
| Amortization of intangible assets in “Total operating expenses” |  |  | 509 |  |  |  | 504 |  |  |  | 1,020 |  |  |  | 1,027 |  |
| Total amortization expense |  | $ | 1,120 |  |  | $ | 3,724 |  |  | $ | 3,064 |  |  | $ | 7,852 |  |

[0000950170-24-009819:notes:84]
[same as prior period, unchanged from 0000950170-23-058245:notes:82]

[0000950170-24-009819:notes:85]
[same as prior period, unchanged from 0000950170-23-058245:notes:83]

[0000950170-24-009819:notes:86]
|  |  | Amount |  |
| For the fiscal year ending June 30: |  |  |  |
| 2024 (the remainder of fiscal 2024) |  | $ | 2,585 |  |
| 2025 |  |  | 4,414 |  |
| 2026 |  |  | 3,165 |  |
| 2027 |  |  | 1,418 |  |
| 2028 |  |  | 1,259 |  |
| Thereafter |  |  | 263 |  |
| Total |  | $ | 13,104 |  |

[0000950170-24-009819:notes:87]
[same as prior period, unchanged from 0000950170-23-058245:notes:85]

[0000950170-24-009819:notes:88]
The Company had Goodwill in the amount of $395.6 million and $394.8 million as of December 31, 2023 and June 30, 2023, respectively. The change in goodwill during the six months ended December 31, 2023 is due to foreign currency translation adjustment that is recorded as a component of accumulated other comprehensive loss.


## us-gaap:DebtDisclosureTextBlock

[0000950170-24-009819:notes:89]
7.
Debt

[0000950170-24-009819:notes:90]
The Company’s debt is comprised of the following (in thousands):

[0000950170-24-009819:notes:91]
|  |  | December 31,2023 |  |  | June 30,2023 |  |
| Current portion of long-term debt: |  |  |  |  |  |  |
| Term Loan |  | $ | 10,000 |  |  | $ | 10,000 |  |
| Revolving Facility |  |  | — |  |  |  | 25,000 |  |
| Less: unamortized debt issuance costs |  |  | (675 | ) |  |  | (674 | ) |
| Current portion of long-term debt |  | $ | 9,325 |  |  | $ | 34,326 |  |
| Long-term debt, less current portion: |  |  |  |  |  |  |
| Term Loan |  | $ | 185,000 |  |  | $ | 190,000 |  |
| Less: unamortized debt issuance costs |  |  | (2,069 | ) |  |  | (2,409 | ) |
| Total long-term debt, less current portion |  |  | 182,931 |  |  |  | 187,591 |  |
| Total debt |  | $ | 192,256 |  |  | $ | 221,917 |  |

[0000950170-24-009819:notes:92]
On August 9, 2019, the Company entered into an Amended and Restated Credit Agreement (the “2019 Credit Agreement”), by and among the Company, as borrower, several banks and other financial institutions as Lenders, BMO Harris Bank N.A., as an issuing lender and swingline lender, Silicon Valley Bank, as an Issuing Lender, and Bank of Montreal, as administrative agent and collateral agent for the Lenders which was subsequently amended during fiscal 2023.

[0000950170-24-009819:notes:93]
On June 22, 2023, the Company entered into a Second Amended and Restated Credit Agreement (the “2023 Credit Agreement”), by and among the Company, as borrower, BMO Harris Bank, N.A., as an issuing lender and swingline lender, Bank of America, N.A., JPMorgan Chase Bank, N.A., PNC Bank, National Association, and Wells Fargo Bank, National Association, as issuing lenders, the financial institutions or entities party thereto as lenders, and Bank of Montreal, as administrative agent and collateral agent, which amended and restated the 2019 Credit Agreement. The 2023 Credit Agreement provides for i) a $200.0 million first lien term loan facility in an aggregate principal amount (the “2023 Term Loan”), ii) a $150.0 million five-year revolving credit facility (the “2023 Revolving Facility”) and, iii) an uncommitted additional incremental loan facility in the principal amount of up to $100.0 million. On June 22, 2023, the Company borrowed $25.0 million against its $150.0 million revolving credit facility to refinance its debt. On July 7, 2023, the Company made a payment of $25.0 million to pay off the outstanding revolving credit balance.

[0000950170-24-009819:notes:94]
Borrowings under the 2023 Credit Agreement bear interest, and at the Company’s election, the initial term loan may be made as either a base rate loan or a Secured Overnight Funding Rate (“SOFR”) loan. The applicable margin for base rate loans ranges from 1.00% to 1.75% per annum, and the applicable margin for SOFR loans ranges from 2.00% to 2.75%, in each case based on the Company’s consolidated leverage ratio. All SOFR loans are subject to a floor of 0.00% per annum and spread adjustment of 0.10% per annum. The Company paid other closing fees, arrangement fees, and administration fees associated with the 2023 Credit Agreement.

[0000950170-24-009819:notes:95]
The 2023 Credit Agreement requires the Company to maintain certain minimum financial ratios at the end of each fiscal quarter. The 2023 Credit Agreement also includes covenants and restrictions that limit, among other things, the Company’s ability to incur additional indebtedness, create liens upon any of its property, merge, consolidate or sell all or substantially all of its assets. The 2023 Credit Agreement also includes customary events of default which may result in acceleration of the outstanding balance. During the six months ended December 31, 2023, the Company was in compliance with all the terms and financial covenants of the 2023 Credit Agreement.

[0000950170-24-009819:notes:96]
Financing costs incurred in connection with obtaining long-term financing are deferred and amortized over the term of the related indebtedness or credit agreement. Amortization of deferred financing costs included in “Interest expense” in the accompanying condensed consolidated statements of operations were $0.3 million and $0.7 million for the three months ended December 31, 2023 and 2022, respectively, and were $0.5 million and $1.5 million for the six months ended December 31, 2023 and 2022, respectively. The interest rate as of December 31, 2023 was 7.46% and as of December 31, 2022 was 5.50%.

[0000950170-24-009819:notes:97]
As of December 31, 2023, the Company did not have any outstanding balance against its 2023 Revolving Facility’s outstanding balance. The Company had $135.5 million of availability under the 2023 Revolving Facility as of December 31, 2023. During the three and six months ended December 31, 2023 the Company did not make any additional payments against its term loan facility other than the scheduled payments per the terms of the 2023 Credit Agreement. During the six months ended December 31, 2022, the Company made an additional payment of $30.0 million, against its term loan facility under the 2023 Credit Agreement.

[0000950170-24-009819:notes:98]
The Company had $14.5 million of outstanding letters of credit as of December 31, 2023.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000950170-24-009819:notes:99]
8.
Commitments and Contingencies

[0000950170-24-009819:notes:100]
Purchase Commitments

[0000950170-24-009819:notes:101]
The Company currently has arrangements with contract manufacturers and suppliers for the manufacture of its products. Those arrangements allow the contract manufacturers to procure long lead-time component inventory based upon a rolling production forecast provided by the Company. The Company is obligated to purchase long lead-time component inventory that its contract manufacturer procures in accordance with the forecast, unless the Company gives notice of order cancellation outside of applicable component lead-times. As of December 31, 2023, the Company had commitments to purchase $92.1 million of inventory.

[0000950170-24-009819:notes:102]
Legal Proceedings

[0000950170-24-009819:notes:103]
The Company may from time to time be party to litigation arising in the course of its business, including, without limitation, allegations relating to commercial transactions, business relationships, or intellectual property rights. Such claims, even if not meritorious, could result in the expenditure of significant financial and managerial resources. Litigation in general, and intellectual property litigation in particular, can be expensive and disruptive to normal business operations. Moreover, the results of legal proceedings are difficult to predict.

[0000950170-24-009819:notes:104]
In accordance with applicable accounting guidance, the Company records accruals for certain of its outstanding legal proceedings, investigations or claims when it is probable that a liability will be incurred, and the amount of loss can be reasonably estimated. The Company evaluates, at least on a quarterly basis, developments in legal proceedings, investigations or claims that could affect the amount of any accrual, as well as any developments that would result in a loss contingency to become both probable and reasonably estimable. When a loss contingency is not both probable and reasonably estimable, the Company does not record a loss accrual. However, if the loss (or an additional loss in excess of any prior accrual) is at least reasonably possible and material, then the Company would disclose an estimate of the possible loss or range of loss, if such estimate can be made, or disclose that an estimate cannot be made. The assessment whether a loss is probable or a reasonable possibility, and whether the loss or a range of loss is estimable, involves a series of complex judgments about future events. Even if a loss is reasonably possible, the Company may not be able to estimate a range of possible loss, particularly where (i) the damages sought are substantial or indeterminate, (ii) the proceedings are in the early stages, or (iii) the matters involve novel or unsettled legal theories or a large number of parties. In such cases, there is considerable uncertainty regarding the ultimate resolution of such matters, including the amount of any possible loss, fine or penalty.  However, an adverse resolution of one or more of such matters could have a material adverse effect on the Company's results of operations in a particular quarter or fiscal year.

[0000950170-24-009819:notes:105]
Orckit IP, LLC v. Extreme Networks, Inc., Extreme Networks Ireland Ltd., and Extreme Networks GmbH

[0000950170-24-009819:notes:106]
On February 1, 2018, Orckit IP, LLC (“Orckit”) filed a patent infringement lawsuit against the Company and its Irish and German subsidiaries in the District Court in Dusseldorf, Germany. The lawsuit alleges direct and indirect infringement of the German portion of a patent (“EP ‘364”) based on the offer, distribution, use, possession and/or importation into Germany of certain network switches that are equipped with the ExtremeXOS operating system. Orckit is seeking injunctive relief, accounting, and an unspecified declaration of liability for damages and costs of the lawsuit. On January 28, 2020, the Court rendered a decision in the infringement case in favor of the Company. The matter is proceeding through the appellate process.

[0000950170-24-009819:notes:107]
On April 23, 2019, Orckit filed an extension of the patent infringement complaint against the Company and its Irish and German subsidiaries in the District Court in Dusseldorf, Germany. With this extension, Orckit alleges infringement of the German portion of a second patent (“EP ‘077”) based on the offer, distribution, use, possession and/or importation into Germany of certain network switches that the Company no longer sells in Germany. Orckit is seeking injunctive relief, accounting and sales information, and a declaration of liability for damages as well as costs of the lawsuit. On October 13, 2020, the Court issued an infringement decision against the Company and granted Orckit the right to enforce the judgment against the Company, which Orckit has provided notification to the Company that it will enforce the judgment. In the rendering of account, Orckit was informed that the products at issue were in end of sale status prior to the filing of the EP ‘077 complaint. The Company has appealed the infringement decision, and the matter is proceeding through the appellate process.

[0000950170-24-009819:notes:108]
The Company filed a nullity action related to the EP ‘364 patent on May 3, 2018, and one related to the EP ‘077 patent on October 31, 2019, both in the Federal Patent Court in Munich. The Federal Patent Court in Munich found the EP ‘364 patent to be valid and the Company filed an appeal, which was dismissed on October 12, 2023. On October 25, 2022 the Federal Patent Court in Munich issued an opinion partially invalidating the EP ‘077 patent and the Company and Orckit have filed appeals.

[0000950170-24-009819:notes:109]
SNMP Research, Inc. and SNMP Research International, Inc. v. Broadcom Inc., Brocade Communications Systems LLC, and Extreme Networks, Inc.

[0000950170-24-009819:notes:110]
On October 26, 2020, SNMP Research, Inc. and SNMP Research International, Inc. (collectively, “SNMP”) filed a lawsuit against the Company in the Eastern District of Tennessee for copyright infringement, alleging that the Company was not properly licensed to use its software.  SNMP is seeking actual damages and profits attributed to the infringement, as well as equitable relief. The Company filed a motion to transfer the case to the Northern District of California. The motion to dismiss was denied in part and denied without

[0000950170-24-009819:notes:111]
prejudice in part. On March 2, 2023, SNMP filed an amended complaint adding claims against Extreme on additional products for copyright infringement, breach of contract, and fraud. On March 16, 2023, the Company filed a motion to dismiss, challenging multiple claims from the amended complaint. On March 20, 2023, the Company filed a motion to refer questions to the US Copyright Office on the invalidity of SNMP’s copyrights. The trial date has been set for October 2024.

[0000950170-24-009819:notes:112]
Mala Technologies Ltd. v. Extreme Networks GmbH, Extreme Networks Ireland Ops Ltd., and Extreme Networks, Inc.

[0000950170-24-009819:notes:113]
On April 15, 2021, Mala Technologies Ltd. (“Mala”) filed a patent infringement lawsuit against the Company and its Irish and German subsidiaries in the District Court in Dusseldorf, Germany.  The lawsuit alleges indirect infringement of the German portion of a patent (“EP ‘498”) based on the offer and sale in Germany of certain network switches equipped with the ExtremeXOS operating system.  Mala is seeking injunctive relief, accounting, and an unspecified declaration of liability for damages and costs of the lawsuit. On December 20, 2022, the trial court ruled that the Company did not infringe the EP ‘498 patent and dismissed Mala’s complaint entirely. Mala has filed an appeal and the matter is proceeding through the appellate process.

[0000950170-24-009819:notes:114]
The Company filed a nullity complaint against EP ‘498 with the German Federal Patent Court on September 24, 2021 and a hearing date has been set for November 20, 2024.

[0000950170-24-009819:notes:115]
Indemnification Obligations

[0000950170-24-009819:notes:116]
Subject to certain limitations, the Company may be obligated to indemnify its current and former directors, officers, and employees. These obligations arise under the terms of its certificate of incorporation, its bylaws, applicable contracts, and applicable law. The obligation to indemnify, where applicable, generally means that the Company is required to pay or reimburse, and in certain circumstances the Company has paid or reimbursed, the individuals’ reasonable legal expenses and possible damages and other liabilities incurred in connection with certain legal matters. The Company also procures Directors and Officers liability insurance to help cover its defense and/or indemnification costs, although its ability to recover such costs through insurance is uncertain.  While it is not possible to estimate the maximum potential amount that could be owed under these governing documents and agreements due to the Company’s limited history with prior indemnification claims, indemnification (including defense) costs could, in the future, have a material adverse effect on the Company’s consolidated financial position, results of operations and cash flows.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0000950170-24-009819:notes:117]
[same as prior period, unchanged from 0000950170-23-058245:notes:114]

[0000950170-24-009819:notes:118]
[same as prior period, unchanged from 0000950170-23-058245:notes:115]

[0000950170-24-009819:notes:119]
The Compensation Committee of the Board unanimously approved an amendment to the Extreme Networks, Inc. Amended and Restated 2013 Equity Incentive Plan (the “2013 Plan”) on September 14, 2023 to increase the maximum number of available shares by 5.0 million shares. The amendment was approved by the stockholders of the Company at the annual meeting of stockholders held on November 8, 2023.

[0000950170-24-009819:notes:120]
[same as prior period, unchanged from 0000950170-23-058245:notes:117]

[0000950170-24-009819:notes:121]
[same as prior period, unchanged from 0000950170-23-058245:notes:118]

[0000950170-24-009819:notes:122]
[same as prior period, unchanged from 0000950170-23-058245:notes:119]

[0000950170-24-009819:notes:123]
On May 18, 2022, the Company announced the Board had authorized management to repurchase up to $200.0 million shares of the Company’s common stock over a three-year period commencing July 1, 2022 (as amended, the “2022 Repurchase Program”). Initially, under the 2022 Repurchase Program, a maximum of $25.0 million of shares was authorized to be repurchased in any quarter; however, on November 17, 2022, the Board increased the authorization to repurchase shares in any quarter from up to $25.0 million of shares per quarter to up to $50.0 million of shares per quarter. Purchases may be made from time to time in the open market or pursuant to a 10b5-1 plan.

[0000950170-24-009819:notes:124]
During the three months ended December 31, 2023, the Company repurchased 1,485,005 shares of its common stock on the open market at a total cost of $25.0 million with an average price of $16.81 per share. During the six months ended December 31, 2023, the Company repurchased a total of 2,365,220 shares of its common stock on the open market at a total cost of $49.9 million with an average price of $21.08 per share. During the three and six months ended December 31, 2022, the Company repurchased a total of 2,578,175 shares of its common stock on the open market at a total cost of $49.8 million with an average price of $19.32 per share. As of December 31, 2023, approximately $50.3 million remains available for share repurchases under the 2022 Repurchase Program.

[0000950170-24-009819:notes:125]
[same as prior period, unchanged from 0000950170-23-058245:notes:123]


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000950170-24-009819:notes:126]
[same as prior period, unchanged from 0000950170-23-058245:notes:124]

[0000950170-24-009819:notes:127]
[same as prior period, unchanged from 0000950170-23-058245:notes:125]

[0000950170-24-009819:notes:128]
[same as prior period, unchanged from 0000950170-23-058245:notes:126]

[0000950170-24-009819:notes:129]
|  |  | December 31,2023 |  |  | June 30,2023 |  |
| 2013 Equity Incentive Plan shares available for grant |  |  | 12,634 |  |  |  | 9,995 |  |
| Employee stock options and awards outstanding |  |  | 8,875 |  |  |  | 10,038 |  |
| 2014 Employee Stock Purchase Plan |  |  | 7,948 |  |  |  | 8,467 |  |
| Total shares reserved for issuance |  |  | 29,457 |  |  |  | 28,500 |  |

[0000950170-24-009819:notes:130]
[same as prior period, unchanged from 0000950170-23-058245:notes:128]

[0000950170-24-009819:notes:131]
[same as prior period, unchanged from 0000950170-23-058245:notes:129]

[0000950170-24-009819:notes:132]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | December 31,2023 |  |  | December 31,2022 |  |  | December 31,2023 |  |  | December 31,2022 |  |
| Cost of product revenues |  | $ | 464 |  |  | $ | 499 |  |  | $ | 947 |  |  | $ | 873 |  |
| Cost of subscription and support revenues |  |  | 749 |  |  |  | 966 |  |  |  | 1,615 |  |  |  | 1,638 |  |
| Research and development |  |  | 4,435 |  |  |  | 3,962 |  |  |  | 8,812 |  |  |  | 7,052 |  |
| Sales and marketing |  |  | 7,535 |  |  |  | 5,910 |  |  |  | 14,523 |  |  |  | 10,549 |  |
| General and administrative |  |  | 7,774 |  |  |  | 6,059 |  |  |  | 14,979 |  |  |  | 11,073 |  |
| Total share-based compensation expense |  | $ | 20,957 |  |  | $ | 17,396 |  |  | $ | 40,876 |  |  | $ | 31,185 |  |

[0000950170-24-009819:notes:133]
[same as prior period, unchanged from 0000950170-23-058245:notes:131]

[0000950170-24-009819:notes:134]
The following table summarizes stock option activity for the six months ended December 31, 2023 (in thousands, except per share amount and contractual term):

[0000950170-24-009819:notes:135]
|  |  | Number of Shares |  |  | Weighted-Average Exercise Price Per Share |  |  | Weighted-Average Remaining Contractual Term (years) |  |  | Aggregate Intrinsic Value |  |
| Options outstanding at June 30, 2023 |  |  | 1,187 |  |  | $ | 6.56 |  |  |  | 2.70 |  |  | $ | 23,136 |  |
| Granted |  |  | — |  |  |  | — |  |  |  |  |  |  |  |
| Exercised |  |  | (57 | ) |  |  | 6.40 |  |  |  |  |  |  |  |
| Canceled |  |  | — |  |  |  | — |  |  |  |  |  |  |  |
| Options outstanding at December 31, 2023 |  |  | 1,130 |  |  | $ | 6.57 |  |  |  | 2.22 |  |  | $ | 12,513 |  |
| Vested and expected to vest at December 31, 2023 |  |  | 1,130 |  |  | $ | 6.57 |  |  |  | 2.22 |  |  | $ | 12,513 |  |
| Exercisable at December 31, 2023 |  |  | 1,130 |  |  | $ | 6.57 |  |  |  | 2.22 |  |  | $ | 12,513 |  |

[0000950170-24-009819:notes:136]
The fair value of each stock option grant under the 2013 Plan is estimated on the date of grant using the Black-Scholes-Merton option valuation model. The expected term of options granted is derived from historical data on employee exercise and post-vesting employment termination behavior. The risk-free interest rate is based upon the estimated life of the option and the U.S. Treasury yield curve in effect at the time of grant. Expected volatility is based on the historical volatility on the Company’s stock. There were no stock options granted during the six months ended December 31, 2023 and 2022.

[0000950170-24-009819:notes:137]
[same as prior period, unchanged from 0000950170-23-058245:notes:136]

[0000950170-24-009819:notes:138]
[same as prior period, unchanged from 0000950170-23-058245:notes:137]

[0000950170-24-009819:notes:139]
The following table summarizes stock award activity for the six months ended December 31, 2023 (in thousands, except grant date fair value):

[0000950170-24-009819:notes:140]
|  |  | Number of Shares |  |  | Weighted- Average Grant Date Fair Value |  |  | Aggregate Fair Value |  |
| Non-vested stock awards outstanding at June 30, 2023 |  |  | 8,851 |  |  | $ | 14.25 |  |  |  |  |
| Granted |  |  | 3,553 |  |  |  | 29.30 |  |  |  |  |
| Released |  |  | (4,114 | ) |  |  | 12.57 |  |  |  |  |
| Canceled |  |  | (545 | ) |  |  | 17.51 |  |  |  |  |
| Non-vested stock awards outstanding at December 31, 2023 |  |  | 7,745 |  |  | $ | 21.81 |  |  | $ | 168,918 |  |
| Stock awards expected to vest at December 31, 2023 |  |  | 7,745 |  |  | $ | 21.81 |  |  | $ | 168,918 |  |

[0000950170-24-009819:notes:141]
The RSUs granted under the 2013 Plan vest over a period of time, generally one to three years, and are subject to participant's continued service to the Company. The stock awards granted during the six months ended December 31, 2023 included 0.6 million RSUs including the market condition awards discussed below to the named executive officers and directors.

[0000950170-24-009819:notes:142]
[same as prior period, unchanged from 0000950170-23-058245:notes:141]

[0000950170-24-009819:notes:143]
During the six months ended December 31, 2023 and 2022, the Compensation Committee of the Board granted 0.8 million and 1.0 million RSUs, respectively, with vesting based on market conditions (“MSU”) to certain of the Company’s executive officers. The MSUs granted during the six months ended December 31, 2023 included 0.5 million MSUs subject to total shareholder return (“TSR”) and 0.3 million MSUs subject to certain stock price targets. The MSUs granted during the six months ended December 31, 2022 were subject to TSR.

[0000950170-24-009819:notes:144]
[same as prior period, unchanged from 0000950170-23-058245:notes:143]

[0000950170-24-009819:notes:145]
[same as prior period, unchanged from 0000950170-23-058245:notes:144]

[0000950170-24-009819:notes:146]
[same as prior period, unchanged from 0000950170-23-058245:notes:145]

[0000950170-24-009819:notes:147]
The grant date fair value of each MSU was determined using the Monte Carlo simulation model. The weighted-average grant-date fair value of the TSR MSUs granted during the six months ended December 31, 2023 was $34.09 per share. The assumptions used in the Monte Carlo simulation included the expected volatility of 50%, risk-free interest rate of 4.48%, no expected dividend yield, expected term of three years and possible future stock prices over the performance period based on the historical stock and market prices. The weighted-average grant-date fair value of the TSR MSUs granted during the six months ended December 31, 2022 was $16.57 per share. The assumptions used in the Monte Carlo simulation included the expected volatility of 67%, risk-free interest rate of 3.12%, no expected dividend yield, expected term of three years, and possible future stock prices over the performance period based on the historical stock and market prices. The Company recognizes the expense related to these MSUs on a graded-vesting method over the estimated term.

[0000950170-24-009819:notes:148]
[same as prior period, unchanged from 0000950170-23-058245:notes:147]

[0000950170-24-009819:notes:149]
The grant date fair value of these stock price target MSUs was determined using the Monte Carlo simulation model. The weighted-average grant-date fair value of these stock price target MSUs granted during the six months ended December 31, 2023 was $28.80 per share. The assumptions used in the Monte Carlo simulation included the expected volatility of 63%, risk-free interest rate of 4.45%, no expected dividend yield, expected term of three years based on possible future stock prices over the performance period based on the historical stock prices. The Company recognizes the expense related to these MSUs on a graded-vesting method over the estimated term.

[0000950170-24-009819:notes:150]
[same as prior period, unchanged from 0000950170-23-058245:notes:149]

[0000950170-24-009819:notes:151]
There were 0.5 million and 0.7 million shares issued under the ESPP during the six months ended December 31, 2023 and 2022, respectively. The following assumptions were used to determine the grant-date fair values of the ESPP shares during the following periods:

[0000950170-24-009819:notes:152]
|  |  | Employee Stock Purchase Plan |  |
|  |  | Six Months Ended |  |
|  |  | December 31,2023 |  |  | December 31,2022 |  |
| Expected term |  | 0.5 years |  |  | 0.5 years |  |
| Risk-free interest rate |  |  | 5.54 | % |  |  | 3.12 | % |
| Volatility |  |  | 42 | % |  |  | 60 | % |
| Dividend yield |  |  | — | % |  |  | — | % |

[0000950170-24-009819:notes:153]
The weighted-average grant-date fair value of shares under the ESPP during the six months ended December 31, 2023 and 2022 was $8.09 and $4.38 per share, respectively.


## us-gaap:SegmentReportingDisclosureTextBlock

[0000950170-24-009819:notes:154]
[same as prior period, unchanged from 0000950170-23-058245:notes:153]

[0000950170-24-009819:notes:155]
[same as prior period, unchanged from 0000950170-23-058245:notes:154]

[0000950170-24-009819:notes:156]
[same as prior period, unchanged from 0000950170-23-058245:notes:155]

[0000950170-24-009819:notes:157]
[same as prior period, unchanged from 0000950170-23-058245:notes:156]

[0000950170-24-009819:notes:158]
|  |  | December 31,2023 |  |  | June 30,2023 |  |
| Americas |  | $ | 140,161 |  |  | $ | 124,375 |  |
| EMEA |  |  | 37,335 |  |  |  | 35,175 |  |
| APAC |  |  | 11,313 |  |  |  | 11,244 |  |
| Total long-lived assets |  | $ | 188,809 |  |  | $ | 170,794 |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000950170-24-009819:notes:159]
[same as prior period, unchanged from 0000950170-23-058245:notes:158]

[0000950170-24-009819:notes:160]
[same as prior period, unchanged from 0000950170-23-058245:notes:159]

[0000950170-24-009819:notes:161]
[same as prior period, unchanged from 0000950170-23-058245:notes:160]

[0000950170-24-009819:notes:162]
At the inception date of the derivative contract, the Company performs an assessment of these contracts and has designated these contracts as cash flow hedges. Interest rate swaps designated as cash flow hedges involve the receipt of variable-rate amounts from a counterparty in exchange for the Company making fixed-rate payments over the life of the agreement without exchange of the underlying notional amount. The Company also formally assesses, both at the hedge’s inception and on an ongoing basis, by performing qualitative and quantitative assessments of whether the derivatives that are used in hedging transactions are highly effective in offsetting changes in cash flow of hedged items. Changes in the fair value of a derivative that is qualified, designated and highly effective as a cash flow

[0000950170-24-009819:notes:163]
hedge are recorded in other comprehensive income (loss). When it is determined that a derivative is not highly effective as a hedge or that it has ceased to be a highly effective hedge, the Company discontinues hedge accounting prospectively. In accordance with ASC 815 Derivatives and Hedging, the Company may prospectively discontinue the hedge accounting for an existing hedge if the applicable criteria are no longer met, the derivative instrument expires, is sold, terminated or exercised or if the Company removes the designation of the respective cash flow hedge. In those circumstances, the net gain or loss remains in “Accumulated other comprehensive loss” and is reclassified into earnings in the same period or periods during which the hedged forecasted transaction affects earnings, unless the forecasted transaction is no longer probable in which case the net gain or loss is reclassified into earnings immediately.

[0000950170-24-009819:notes:164]
During the fiscal year ended June 30, 2020, the Company entered into multiple interest rate swap contracts, designated as cash flow hedges, to hedge the variability of cash flows in interest payments associated with the Company’s various tranches of floating-rate debt. As of December 31, 2023, the Company did not have any outstanding interest rate swaps contracts. As of December 31, 2022, the notional amount of these interest rate swaps was $75.0 million, and had maturity dates through April 2023. As of December 31, 2022, these contracts had unrealized gains of $0.8 million, and were recorded in “Accumulated other comprehensive loss” with the associated asset in “Prepaid expenses and other current assets”, in the condensed consolidated balance sheets. Cash flows associated with periodic settlements of interest rate swaps are classified as operating activities in the condensed consolidated statement of cash flows. Realized gains and losses are recognized as they accrue in interest expense. Amounts reported in “Accumulated other comprehensive loss” related to these cash flow hedges are reclassified to interest expense over the life of the swap contracts.

[0000950170-24-009819:notes:165]
[same as prior period, unchanged from 0000950170-23-058245:notes:163]

[0000950170-24-009819:notes:166]
[same as prior period, unchanged from 0000950170-23-058245:notes:164]

[0000950170-24-009819:notes:167]
For foreign exchange forward contracts not designated as hedging instruments, the fair value of the Company’s derivatives in a gain position are recorded in “Prepaid expenses and other current assets” and derivatives in a loss position are recorded in “Other accrued liabilities” in the accompanying condensed consolidated balance sheets. Changes in the fair value of derivatives are recorded in “Other income (expense), net” in the accompanying condensed consolidated statements of operations. As of December 31, 2023 and 2022, foreign exchange forward contracts not designated as hedging instruments had a total notional principal amount of $15.6 million and $11.1 million, respectively. These contracts have maturities of 40 days or less. During the three months ended December 31, 2023 and 2022, the net gains and losses recorded in the condensed consolidated statement of operations from these contracts were net gains of  $0.4 million and $0.1 million, respectively. During the six months ended December 31, 2023 and 2022 the net gains and losses recorded in the condensed consolidated statement of operations were net gains of $0.3 million and net losses of $0.4 million, respectively. Changes in the fair value of these foreign exchange forward contracts are offset largely by remeasurement of the underlying assets and liabilities. 
For the three months ended December 31, 2023 and 2022, the Company recognized total foreign currency losses of $0.7 million and total foreign currency gains of less than $0.1 million, respectively, and for the six months ended December 31, 2023 and 2022, the Company recognized total foreign currency losses of $0.3 million and total foreign currency gains of $0.8 million, respectively, related to the change in fair value of foreign currency denominated assets and liabilities.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0000950170-24-009819:notes:168]
[same as prior period, unchanged from 0000950170-23-058245:notes:166]

[0000950170-24-009819:notes:169]
The Company recorded $9.2 million and $11.9 million of restructuring and related charges during the three and six months ended December 31, 2023, respectively, which primarily related to the restructuring plans as noted below.

[0000950170-24-009819:notes:170]
During the second quarter of fiscal 2024, the Company executed a global reduction-in-force plan to rebalance its workforce to create greater efficiency and improve execution, in alignment with the Company's business and strategic priorities, while reducing its ongoing operating expenses to address reduced revenue and macro-economic conditions (the “Q2 2024 Plan”). During the three months ended December 31, 2023, the Company recorded restructuring charges of approximately $8.8 million related to the Q2 2024 Plan, which primarily consisted of severance and benefits expenses. The Company expects to complete this Plan by the end of fiscal 2024 and expects to incur an additional $4.5 million in charges by the end of fiscal 2024.

[0000950170-24-009819:notes:171]
During the first quarter of fiscal 2024, the Company initiated a reduction-in-force plan to rebalance the workforce to create greater efficiency and improve execution in alignment with the Company's business and strategic priorities (the “Q1 2024 Plan”). It consisted primarily of workforce reduction to drive productivity in research and development, sales and marketing and provide efficiency across operations and general & administrative functions. During the three and six months ended December 31, 2023, the Company incurred charges of approximately $0.2 million and $2.9 million, respectively related to the Q1 2024 Plan. As of December 31, 2023, the plan is substantially completed.

[0000950170-24-009819:notes:172]
During the third quarter of fiscal 2023, the Company initiated a restructuring plan to transform its business infrastructure and reduce its facilities footprint and the facilities related charges (the “2023 Plan”). As part of this project, the Company is moving engineering labs from its San Jose, California location to its Salem, New Hampshire location. This move is expected to help reduce the cost of operating the Company's labs. During the three months and six months ended December 31, 2023, the Company incurred restructuring charges of approximately $0.2 million primarily for move costs. The Company expects that the project will take about 9 to 12 months from December 31, 2023 to complete, and expects to incur charges of approximately $10.0 million throughout this period, primarily for asset disposals, contractor costs, severance, relocation, and other non-recurring fees.

[0000950170-24-009819:notes:173]
The Company recorded $0.5 million and $1.0 million of restructuring and related charges during the three and six months ended December 31, 2022, which primarily included additional facilities expenses related to previously impaired facilities.

[0000950170-24-009819:notes:174]
Restructuring liabilities are recorded in “Other accrued liabilities” in the accompanying condensed consolidated balance sheets. As of December 31, 2023, the restructuring liability was $6.2 million, which primarily related to the Q2 2024 Plan.


## us-gaap:IncomeTaxDisclosureTextBlock

[0000950170-24-009819:notes:175]
[same as prior period, unchanged from 0000950170-23-058245:notes:172]

[0000950170-24-009819:notes:176]
For the three months ended December 31, 2023 and 2022, the Company recorded an income tax provision of $3.1 million and $2.6 million, respectively. For the six months ended December 31, 2023 and 2022, the Company recorded an income tax provision of $7.6 million and $4.4 million, respectively.

[0000950170-24-009819:notes:177]
The income tax provisions for the three and six months ended December 31, 2023 and 2022, consisted of (1) taxes on the income of the Company’s foreign subsidiaries, (2) state taxes in jurisdictions where the Company has no remaining state net operating losses (“NOLs”), (3) foreign withholding taxes, and (4) tax expense associated with the establishment of a U.S. deferred tax liability for amortizable goodwill resulting from the acquisition of Enterasys Networks, Inc., the wireless local area network business from Zebra Technologies Corporation, the Campus Fabric Business from Avaya and the Data Center Business from Brocade. In addition, the tax provision for the three and six months ended December 31, 2023, includes US Federal income tax of $0.2 million and $1.6 million, respectively. The interim income tax provisions for the three and six months ended December 31, 2023 and 2022 were calculated using the discrete effective tax rate method as allowed by ASC 740-270-30-18, Income Taxes – Interim Reporting. The discrete method is applied when the application of the estimated annual effective tax rate is impractical because it is not possible to reliably estimate the annual effective tax rate. The discrete method treats the year-to-date period as if it was the annual period and determines the income tax expense or benefit on that basis.  The Company believes that, at this time, the use of this discrete method is more appropriate than the annual effective tax rate method as (i) the estimated annual effective tax rate method is not reliable due to the high degree of uncertainty in estimating annual pretax earnings on a jurisdictional basis and (ii) the Company’s ongoing assessment that the recoverability of certain U.S. and Irish deferred tax assets is not more likely than not.

[0000950170-24-009819:notes:178]
[same as prior period, unchanged from 0000950170-23-058245:notes:175]

[0000950170-24-009819:notes:179]
The Company had $18.3 million of unrecognized tax benefits as of December 31, 2023. If fully recognized in the future, $0.2 million would impact the effective tax rate and $18.1 million would result in adjustments to deferred tax assets and corresponding adjustments to the valuation allowance with no impact to the effective tax rate. The Company does not anticipate any events to occur during the next twelve months that would materially reduce the unrealized tax benefit as currently stated in the Company’s condensed consolidated balance sheets.

[0000950170-24-009819:notes:180]
[same as prior period, unchanged from 0000950170-23-058245:notes:178]

[0000950170-24-009819:notes:181]
[same as prior period, unchanged from 0000950170-23-058245:notes:179]


## us-gaap:EarningsPerShareTextBlock

[0000950170-24-009819:notes:182]
[same as prior period, unchanged from 0000950170-23-058245:notes:180]

[0000950170-24-009819:notes:183]
[same as prior period, unchanged from 0000950170-23-058245:notes:181]

[0000950170-24-009819:notes:184]
[same as prior period, unchanged from 0000950170-23-058245:notes:182]

[0000950170-24-009819:notes:185]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | December 31,2023 |  |  | December 31,2022 |  |  | December 31,2023 |  |  | December 31,2022 |  |
| Net income |  | $ | 3,988 |  |  | $ | 17,931 |  |  | $ | 32,664 |  |  | $ | 30,516 |  |
| Weighted-average shares used in per share calculation – basic |  |  | 128,987 |  |  |  | 130,465 |  |  |  | 128,885 |  |  |  | 130,377 |  |
| Options to purchase common stock |  |  | 757 |  |  |  | 717 |  |  |  | 836 |  |  |  | 635 |  |
| Restricted stock units |  |  | 1,579 |  |  |  | 3,164 |  |  |  | 2,951 |  |  |  | 2,760 |  |
| Employee Stock Purchase Plan shares |  |  | 191 |  |  |  | 107 |  |  |  | 114 |  |  |  | 61 |  |
| Weighted-average shares used in per share calculation – diluted |  |  | 131,514 |  |  |  | 134,453 |  |  |  | 132,786 |  |  |  | 133,833 |  |
| Net income per share – basic and diluted |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income per share – basic |  | $ | 0.03 |  |  | $ | 0.14 |  |  | $ | 0.25 |  |  | $ | 0.23 |  |
| Net income per share – diluted |  | $ | 0.03 |  |  | $ | 0.13 |  |  | $ | 0.25 |  |  | $ | 0.23 |  |

[0000950170-24-009819:notes:186]
[same as prior period, unchanged from 0000950170-23-058245:notes:184]

[0000950170-24-009819:notes:187]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | December 31,2023 |  |  | December 31,2022 |  |  | December 31,2023 |  |  | December 31,2022 |  |
| Restricted stock units |  |  | 2,336 |  |  |  | 437 |  |  |  | 1,623 |  |  |  | 306 |  |
| Employee Stock Purchase Plan shares |  |  | 560 |  |  |  | 678 |  |  |  | 445 |  |  |  | 529 |  |
| Total shares excluded |  |  | 2,896 |  |  |  | 1,115 |  |  |  | 2,068 |  |  |  | 835 |  |


## ecd:MtrlTermsOfTrdArrTextBlock

[0000950170-24-009819:notes:188]
On November 6, 2023, Ingrid J. Burton, a member of the Company's board of directors, terminated a Rule 10b5-1 trading arrangement that was intended to satisfy the affirmative defense conditions of Rule 10b5-1(c) and originally adopted on August 30, 2023 for the sale of up to 5,000 shares of the Company’s common stock until August 30, 2024.

[0000950170-24-009819:notes:189]
On December 8, 2023, Joe Vitalone, the Company’s former Chief Revenue Officer terminated a Rule 10b5-1 trading arrangement that was intended to satisfy the affirmative defense conditions of Rule 10b5-1(c) and originally adopted on May 26, 2023 for the sale of up to 70,402 shares of the Company's common stock until July 31, 2024.
