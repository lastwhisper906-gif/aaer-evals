# EXTR notes — 0001078271-15-000127


## extr:DeferredRevenueRollForwardTableTextBlock

[0001078271-15-000127:notes:1]
[same as prior period, unchanged from 0001078271-15-000052:notes:1]

[0001078271-15-000127:notes:2]
|  | Three Months Ended |
|  | September 30, 2015 |  | September 30, 2014 |
| Balance beginning of period | $ | 87,441 |  |  | $ | 89,657 |  |
| New support arrangements | 27,046 |  |  | 28,539 |  |
| Recognition of support revenue | (29,232 | ) |  | (31,184 | ) |
| Balance end of period | 85,255 |  |  | 87,012 |  |
| Less: current portion | 63,310 |  |  | 65,044 |  |
| Non-current deferred revenue | $ | 21,945 |  |  | $ | 21,968 |  |


## extr:ScheduleOfDeferredDistributorsRevenueTableTextBlock

[0001078271-15-000127:notes:3]
[same as prior period, unchanged from 0001078271-15-000052:notes:3]

[0001078271-15-000127:notes:4]
|  | September 30, 2015 |  | June 30, 2015 |
| Deferred distributors revenue | $ | 44,625 |  |  | $ | 53,366 |  |
| Deferred cost of sales to distributors | (10,649 | ) |  | (12,491 | ) |
| Deferred distributors revenue, net of cost of sales to distributors | $ | 33,976 |  |  | $ | 40,875 |  |


## extr:SharesReservedForInsuranceTableTextBlock

[0001078271-15-000127:notes:5]
As of September 30, 2015, the Company had reserved for issuance (in thousands):

[0001078271-15-000127:notes:6]
|  | September 30, 2015 |  | June 30, 2015 |
| 2014 Employee Stock Purchase Plan | 11,000 |  |  | 12,000 |  |
| Employee stock options and awards outstanding | 14,617 |  |  | 15,273 |  |
| Employee stock options and awards available for grant | 4,767 |  |  | 5,450 |  |
| Total shares reserved for issuance | 30,384 |  |  | 32,723 |  |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001078271-15-000127:notes:7]
Commitments and Contingencies

[0001078271-15-000127:notes:8]
Purchase Commitments

[0001078271-15-000127:notes:9]
The Company currently has arrangements with contract manufacturers and suppliers for the manufacture of its products. The arrangements allow them to procure long lead-time component inventory based upon a rolling production forecast provided by the Company. The Company is obligated to the purchase of long lead-time component inventory that its contract manufacturer procures in accordance with the forecast, unless the Company gives notice of order cancellation outside of applicable component lead-times.  As of September 30, 2015, the Company had non-cancelable commitments to purchase $72.5 million of such inventory.

[0001078271-15-000127:notes:10]
Legal Proceedings

[0001078271-15-000127:notes:11]
The Company may from time to time be party to litigation arising in the course of its business, including, without limitation, allegations relating to commercial transactions, business relationships or intellectual property rights. Such claims, even if not meritorious, could result in the expenditure of significant financial and managerial resources. Litigation in general and intellectual property and securities litigation in particular, can be expensive and disruptive to normal business operations. Moreover, the results of legal proceedings are difficult to predict.

[0001078271-15-000127:notes:12]
In accordance with applicable accounting guidance, the Company records accruals for certain of its outstanding legal proceedings, investigations or claims when it is probable that a liability will be incurred and the amount of loss can be reasonably estimated. The Company evaluates, at least on a quarterly basis, developments in legal proceedings, investigations or claims that could affect the amount of any accrual, as well as any developments that would result in a loss contingency to become both probable and reasonably estimable. When a loss contingency is not both probable and reasonably estimable, the Company does not record a loss accrual.  However, if the loss (or an additional loss in excess of any prior accrual) is at least a reasonable possibility and material, then the Company would disclose an estimate of the possible loss or range of loss, if such estimate can be made, or disclose that an estimate cannot be made. The assessment whether a loss is probable or a reasonable possibility, and whether the loss or a range of loss is estimable, involves a series of complex judgments about future events. Even if a loss is reasonably possible, the Company may not be able to estimate a range of possible loss, particularly where (i) the damages sought are substantial or indeterminate, (ii) the proceedings are in the early stages, or (iii) the matters involve novel or unsettled legal theories or a large number of parties. In such cases, there is considerable uncertainty regarding the ultimate resolution of such matters, including the amount of any possible loss, fine or penalty.  Accordingly, for current proceedings, except as noted below, the Company is currently unable to estimate any reasonably possible loss or range of possible loss.  However, an adverse resolution of one or more of such matters could have a material adverse effect on the Company's results of operations in a particular quarter or fiscal year.

[0001078271-15-000127:notes:13]
2002 - 2009 ICMS Tax Assessment Matters

[0001078271-15-000127:notes:14]
The State of Sao Paolo (Brazil) denied Enterasys Networks do Brazil Ltda. the use of certain credits derived from the State of Espirito Santo under the terms of the FUNDAP scheme for the tax years of 2002 through 2009.  Enterasys’ application to resolve the ICMS Tax Assessments at the administrative level of the Sao Paolo Tax Department under the amnesty relief program (Reference No 3.056.963-1) was denied in March, 2014, by the Sao Paolo Tax Administration.  The value of the ICMS tax credits that were disallowed by the Sao Paolo Tax Administration is approximately BR 3,433,914 (or approximately US $0.9 million), plus interest and penalties (that are currently estimated to be approximately US $4.1 million).  Possible court fees are estimated to be BR 3,952,598 (or approximately US $1.0 million). On January 10, 2014, Enterasys filed a lawsuit to overturn or reduce the assessment, which lawsuit remains on-going.  As part of this lawsuit, Enterasys made a request for a stay of execution, so that no tax foreclosure can be filed until a final ruling is made and no guarantee needs to be presented.  On or about October 6, 2014, the preliminary injunction was granted with regard to the stay of execution, and in response to an appeal on the guarantee requirement, the appellant court further ruled on or about January 28, 2015 that no cash deposit (or guarantee) need be made by Enterasys.

[0001078271-15-000127:notes:15]
Given the preliminary nature of the lawsuit, it is premature to assess the likelihood of a particular final outcome.  Based on the currently available information, the Company believes the ultimate outcome of this audit will not have material adverse effect on the Company's financial position or overall results of operations.  The range of the potential total tax liability related to these matters is estimated to be from US $0 million to US $6.0 million, of which the Company believes US $4.3 million is the best estimate within the range and has recorded an accrual as of the Acquisition Date of Enterasys as such matter relates to the period before the acquisition.

[0001078271-15-000127:notes:16]
Extreme made a demand on April 11, 2014 for a defense from, and indemnification by, Seller of these 2002-2009 ICMS Tax Assessment matters.  Seller agreed to assume the defense of these 2002-2009 ICMS Tax Assessment Matters on May 20, 2014.  In addition, through the settlement of the Unify Indemnification Suit on June 18, 2015, Seller has agreed to continue to defend Extreme in this matter and to indemnify Extreme for losses related thereto subject to certain conditions.  These conditions relate to offsetting of foreign income tax benefits realized by the Company in the connection with the acquisition of Enterasys.  Based upon current projections of the foreign income tax benefits to be realized, the Company does not anticipated that any amounts under the indemnification will be due.

[0001078271-15-000127:notes:17]
Hong vs Extreme

[0001078271-15-000127:notes:18]
On October 23, 2015, a complaint was filed for violations of securities laws in the U.S. District Court for the Northern District of California in the name of Jui-Yang Hong, Individually and on behalf of all others similarly situated, against the Company, and named defendants Charles W. Berger, Kenneth B. Arola, and John T. Kurtzweil.  Plaintiff alleges that defendants violated the securities laws by disseminating materially false and misleading statements and concealing material adverse facts regarding Extreme Networks' current financial condition and growth prospects. Plaintiffs seek damages of an unspecified amount.  The Company intends to vigorously defend the suit.

[0001078271-15-000127:notes:19]
Indemnification Obligations

[0001078271-15-000127:notes:20]
Subject to certain limitations, the Company may be obligated to indemnify its current and former directors, officers and employees. These obligations arise under the terms of its certificate of incorporation, its bylaws, applicable contracts, and Delaware and California law. The obligation to indemnify, where applicable, generally means that the Company is required to pay or reimburse, and in certain circumstances the Company has paid or reimbursed, the individuals' reasonable legal expenses and possibly damages and other liabilities incurred in connection with these matters. It is not possible to estimate the maximum potential amount under these indemnification agreements due to the limited history of these claims. The cost to defend the Company and the named individuals could have a material adverse effect on its consolidated financial position, results of operations and cash flows in the future. Recovery of such costs under its directors and officers’ insurance coverage is uncertain. As of September 30, 2015, the Company had no outstanding indemnification claims.


## us-gaap:DeferredRevenueByArrangementDisclosureTextBlock

[0001078271-15-000127:notes:21]
[same as prior period, unchanged from 0001078271-15-000052:notes:37]

[0001078271-15-000127:notes:22]
|  | September 30, 2015 |  | June 30, 2015 |
| Deferred services | $ | 85,255 |  |  | $ | 87,441 |  |
| Deferred product and other revenue | 10,402 |  |  | 12,341 |  |
| Total deferred revenue | 95,657 |  |  | 99,782 |  |
| Less: current portion | 73,712 |  |  | 76,551 |  |
| Non-current deferred revenue, net | $ | 21,945 |  |  | $ | 23,231 |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001078271-15-000127:notes:23]
[same as prior period, unchanged from 0001078271-15-000052:notes:39]

[0001078271-15-000127:notes:24]
The Company from time to time enters into foreign exchange forward contracts to mitigate the effect of gains and losses generated by the foreign currency forecasted transactions related to certain operating expenses and re-measurement of certain assets and liabilities denominated in foreign currencies. These derivatives do not qualify as hedges.  Changes in the fair value of these foreign exchange forward contracts are offset largely by re-measurement of the underlying assets and liabilities.  At September 30, 2015, we did not have any forward foreign currency contracts.

[0001078271-15-000127:notes:25]
Foreign currency transaction gains and losses from operations was a gain of $1.2 million for the three months ended September 30, 2015, and a loss of $0.4 million for the three months ended September 30, 2014.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001078271-15-000127:notes:26]
[same as prior period, unchanged from 0001078271-15-000052:notes:42]

[0001078271-15-000127:notes:27]
Shares reserved for issuance

[0001078271-15-000127:notes:28]
[same as prior period, unchanged from 0001078271-15-000052:notes:44]

[0001078271-15-000127:notes:29]
|  | Three Months Ended |
|  | September 30, 2015 |  | September 30, 2014 |
| Cost of product revenue | $ | 296 |  |  | $ | 283 |  |
| Cost of service revenue | 367 |  |  | 291 |  |
| Research and development | 1,629 |  |  | 1,644 |  |
| Sales and marketing | 1,428 |  |  | 1,557 |  |
| General and administrative | 951 |  |  | 1,038 |  |
| Total share-based compensation expense | $ | 4,671 |  |  | $ | 4,813 |  |

[0001078271-15-000127:notes:30]
During the three months ended September 30, 2015 and 2014, the Company did not capitalize any share-based compensation expense in inventory, as the amounts were immaterial.

[0001078271-15-000127:notes:31]
[same as prior period, unchanged from 0001078271-15-000052:notes:47]

[0001078271-15-000127:notes:32]
Stock awards may be granted under the 2013 Plan on terms approved by the Board of Directors. Stock awards generally provide for the issuance of restricted stock units which vests over a fixed period.

[0001078271-15-000127:notes:33]
The following table summarizes stock award activity for the three months ended September 30, 2015 (in thousands, except grant date fair value):

[0001078271-15-000127:notes:34]
|  | Number ofShares(000’s) |  | Weighted-Average Grant-Date Fair Value |  | Aggregate Fair Market Value ($000's) |
| Non-vested stock awards outstanding at June 30, 2015 | 4,597 |  |  | $ | 3.82 |  |  |  |
| Granted | 2,291 |  |  | $ | 2.94 |  |  |  |
| Vested | (44 | ) |  | $ | 2.67 |  |  | $ | 118 |  |
| Cancelled | (187 | ) |  | $ | 4.55 |  |  |  |
| Non-vested stock awards outstanding at September 30, 2015 | 6,657 |  |  | $ | 3.51 |  |  |  |

[0001078271-15-000127:notes:35]
The following table summarizes stock option activity under all plans for the three months ended September 30, 2015 (in thousands, except per share and contractual term):

[0001078271-15-000127:notes:36]
|  | Number ofShares(000’s) |  | Weighted-AverageExercise PricePer Share |  | Weighted-AverageRemainingContractualTerm (years) |  | AggregateIntrinsic Value(000’s) |
| Options outstanding at June 30, 2015 | 10,604 |  |  | $ | 4.03 |  |  | 3.79 |  | $ | 410 |  |
| Granted | — |  |  | $ | — |  |  |  |  |  |
| Exercised | (24 | ) |  | $ | 2.36 |  |  |  |  |  |
| Cancelled | (2,620 | ) |  | $ | 3.70 |  |  |  |  |  |
| Options outstanding at September 30, 2015 | 7,960 |  |  | $ | 4.14 |  |  | 4.62 |  | $ | 1,484 |  |
| Exercisable at September 30, 2015 | 4,713 |  |  | $ | 4.17 |  |  | 3.31 |  | $ | 582 |  |
| Vested and expected to vest at September 30, 2015 | 7,516 |  |  | $ | 4.14 |  |  | 4.49 |  | $ | 1,381 |  |

[0001078271-15-000127:notes:37]
The weighted-average grant-date fair value of options granted during the three months ended September 30, 2014 was $2.39. There were no options granted during the three months ended September 30, 2015. The weighted-average fair value of shares purchased under the Company’s 2014 ESPP and the 1999 ESPP during the three months ended September 30, 2015 and 2014, was $1.97 and $1.50, respectively.

[0001078271-15-000127:notes:38]
The Company uses the straight-line method for expense attribution, and the Company estimates forfeitures and only recognizes expense for those shares expected to vest.  The Company’s estimated forfeiture rate for fiscal 2016 is based on the Company’s historical forfeiture experience and is 13% for non-executives and 19% for executives.

[0001078271-15-000127:notes:39]
The fair value of each stock option grant under the Company's 2013 Plan and 2005 Plan is estimated on the date of grant using the Black-Scholes-Merton option valuation model with the weighted average assumptions noted in the following table. The Company uses the Monte-Carlo simulation model to determine the fair value and the derived service period of grants with market conditions, on the date of the grant.  The expected term of options granted is derived from historical data on employee exercise and post-vesting employment termination behavior.  The risk-free rate is based upon the estimated life of the option and is based on the U.S. Treasury yield curve in effect at the time of grant. Expected volatility is based on a blended rate of the implied volatilities from traded options on the Company’s stock and historical volatility on the Company’s stock.

[0001078271-15-000127:notes:40]
The fair value of each share purchase option under the Company's 2014 ESPP and 1999 ESPP is estimated on the date of grant using the Black-Scholes-Merton option valuation model with the weighted average assumptions noted in the following table. The expected term of the 2014 ESPP and the 1999 ESPP represents the term of the offering period of each option.  The risk-free rate is based upon the estimated life and is based on the U.S. Treasury yield curve in effect at the time of grant.  Expected volatility is based on a blended rate of the implied volatilities from traded options and historical volatility on the Company’s stock.

[0001078271-15-000127:notes:41]
|  | Stock Option Plans |  | Employee Stock Purchase Plans |
|  | Three Months Ended |  | Three Months Ended |
|  | September 30, 2015 |  | September 30, 2014 |  | September 30, 2015 |  | September 30, 2014 |
| Expected life | 0.0 years |  | 5.0 years |  | 1.25 years |  | 0.25 years |
| Risk-free interest rate | — | % |  | 1.52 | % |  | 0.29 | % |  | 0.02 | % |
| Volatility | — | % |  | 54 | % |  | 58 | % |  | 53 | % |
| Dividend yield | — | % |  | — | % |  | — | % |  | — | % |


## us-gaap:EarningsPerSharePolicyTextBlock

[0001078271-15-000127:notes:42]
Dilutive earnings per share is calculated by dividing net earnings by the weighted average number of common shares used in the basic earnings per share calculation plus the dilutive effect of shares subject to repurchase, options, warrants and unvested restricted stock.


## us-gaap:EarningsPerShareTextBlock

[0001078271-15-000127:notes:43]
[same as prior period, unchanged from 0001078271-15-000052:notes:64]

[0001078271-15-000127:notes:44]
Basic earnings per share is calculated by dividing net earnings by the weighted average number of common shares outstanding during the period. Dilutive earnings per share is calculated by dividing net earnings by the weighted average number of common shares used in the basic earnings per share calculation plus the dilutive effect of shares subject to repurchase, options, warrants and unvested restricted stock.

[0001078271-15-000127:notes:45]
[same as prior period, unchanged from 0001078271-15-000052:notes:65]

[0001078271-15-000127:notes:46]
|  | Three Months Ended |
|  | September 30, 2015 |  |  | September 30, 2014 |  |
| Net loss | $ | (11,526 | ) |  | $ | (19,330 | ) |
| Weighted-average shares used in per share calculation – basic and diluted | 100,985 |  |  | 97,314 |  |
| Net loss per share – basic and diluted | $ | (0.11 | ) |  | $ | (0.20 | ) |

[0001078271-15-000127:notes:47]
[same as prior period, unchanged from 0001078271-15-000052:notes:67]

[0001078271-15-000127:notes:48]
|  | September 30, 2015 |  |  | September 30, 2014 |
| Options to purchase common stock | 8,301 |  |  | 6,866 |  |
| Restricted stock units | 6,657 |  |  | 1,765 |  |
| Employee Stock Purchase Plan shares | 147 |  |  | 216 |  |


## us-gaap:FairValueDisclosuresTextBlock

[0001078271-15-000127:notes:49]
[same as prior period, unchanged from 0001078271-15-000052:notes:69]

[0001078271-15-000127:notes:50]
A three-tier fair value hierarchy is utilized to prioritize the inputs used in measuring fair value. The hierarchy gives the highest priority to quoted prices in active markets (Level 1) and the lowest priority to unobservable inputs (Level 3).  The three levels are defined as follows:

[0001078271-15-000127:notes:51]
•Level 1 Inputs - unadjusted quoted prices in active markets for identical assets or liabilities;

[0001078271-15-000127:notes:52]
•Level 2 Inputs - quoted prices for similar assets and liabilities in active markets or inputs that are observable for the asset or liability, either directly or indirectly through market corroboration, for substantially the full term of the financial instrument; and

[0001078271-15-000127:notes:53]
•Level 3 Inputs - unobservable inputs reflecting the Company's own assumptions in measuring the asset or liability at fair value.

[0001078271-15-000127:notes:54]
The Company did not hold any financial liabilities that required measurement at fair value on a recurring basis.  The following table presents the Company’s fair value hierarchy for its financial assets measured at fair value on a recurring basis (in thousands):

[0001078271-15-000127:notes:55]
| September 30, 2015 | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| Assets |  |  |  |  |  |  |  |
| Investments: |  |  |  |  |  |  |  |
| Money market funds | $ | 4,768 |  |  | $ | — |  |  | $ | — |  |  | $ | 4,768 |  |
| Total | $ | 4,768 |  |  | $ | — |  |  | $ | — |  |  | $ | 4,768 |  |

[0001078271-15-000127:notes:56]
| June 30, 2015 | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| Assets |  |  |  |  |  |  |  |
| Investments: |  |  |  |  |  |  |  |
| Money market funds | $ | 4,770 |  |  | $ | — |  |  | $ | — |  |  | $ | 4,770 |  |
| Total | $ | 4,770 |  |  | $ | — |  |  | $ | — |  |  | $ | 7,770 |  |

[0001078271-15-000127:notes:57]
Level 2 investments: the Company includes U.S. government and sovereign obligations, most government agency securities, investment-grade corporate bonds, and state, municipal and provincial obligations for which quoted prices are available as Level 2.  There were no transfers of assets or liabilities between Level 1 and Level 2 during the fiscal years 2016 or 2015.

[0001078271-15-000127:notes:58]
The fair value of the borrowings under the Senior Secured Credit Facility, as amended is estimated based on valuations provided by alternative pricing sources supported by observable inputs which is considered Level 2.  Due to the short duration until maturity of the credit facility, the fair value approximates the carrying amount  of the Company’s total long-term indebtedness, including current portion of  $65.3 million and $66.9 million as of September 30 and June 30, 2015, respectively.

[0001078271-15-000127:notes:59]
Level 3 investments: The Company does not hold any level 3 investments.

[0001078271-15-000127:notes:60]
Certain of the Company's assets, including intangible assets and goodwill are measured at fair value on a non-recurring basis if impairment is indicated.  There were no impairments recorded for the three months ended September 30, 2015 or 2014.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001078271-15-000127:notes:61]
[same as prior period, unchanged from 0001078271-15-000052:notes:83]

[0001078271-15-000127:notes:62]
For the three months ended September 30, 2015 and 2014, the Company recorded an income tax provision of $0.9 million and $1.0 million, respectively.

[0001078271-15-000127:notes:63]
The income tax provisions for the three months ended September 30, 2015 and 2014, consisted primarily of taxes on the income of our foreign subsidiaries as well as tax expense associated with the establishment of a U.S. deferred tax liability for amortizable goodwill resulting from the acquisition of Enterasys Networks, Inc. The income tax provisions for both fiscal years were calculated based on the actual results of operations for the three months ended September 30, 2015 and 2014, and therefore may not reflect the annual effective tax rate.

[0001078271-15-000127:notes:64]
The Company has provided a full valuation allowance against all of its U.S. federal and state deferred tax assets as well as the deferred tax assets in Australia, Brazil, Japan and Singapore.   A valuation allowance is determined by assessing both negative and positive evidence to determine whether it is “more likely than not” that the deferred tax assets are recoverable; such assessment is required on a jurisdiction by jurisdiction basis. The Company's inconsistent earnings in recent periods, including a cumulative loss over the last three years, coupled with its difficulty in forecasting future revenue trends as well as the cyclical nature of its business represent sufficient negative evidence to require a full valuation allowance against its U.S. federal and state net deferred tax assets as well as the above mentioned foreign jurisdictions. This valuation allowance will be evaluated periodically and can be reversed partially or in whole if business results and the economic environment have sufficiently improved to support realization of some or all of the Company's deferred tax assets.

[0001078271-15-000127:notes:65]
The acquisition of Enterasys included a U.S. parent company as well as its wholly-owned domestic and foreign subsidiaries.  The Company has elected to treat this stock acquisition as an asset purchase by filing the required election forms under IRC Sec 338(h)(10).  The Company has estimated the value of the intangible assets from this transaction and is amortizing the amount over 15 years for tax purposes.  During the three months ended September 30, 2015, the Company deducted $1.1 million of tax amortization expense related to capitalized goodwill.  As of September 30, 2015, the Company recorded a deferred tax liability of $3.2 million related to this amortization which is not considered a future source of taxable income in evaluating the need for a valuation allowance against our deferred tax assets.

[0001078271-15-000127:notes:66]
The Company had $11.4 million of unrecognized tax benefits as of September 30, 2015. The future impact of the unrecognized tax benefit of $11.4 million, if recognized, would result in adjustments to deferred tax assets and corresponding adjustments to the valuation allowance. The Company does not anticipate any events to occur during the next twelve months that would reduce the unrealized tax benefit as currently stated in the Company’s balance sheet.

[0001078271-15-000127:notes:67]
The Company’s policy is to accrue interest and penalties related to the underpayment of income taxes as a component of tax expense in the Condensed Consolidated Statements of Operations.

[0001078271-15-000127:notes:68]
[same as prior period, unchanged from 0001078271-15-000052:notes:90]


## us-gaap:InvestmentPolicyTextBlock

[0001078271-15-000127:notes:69]
The Company considers highly liquid investments with maturities of three months or less at the date of purchase to be cash equivalents.  Investments with original maturities of greater than three months, but less than one year at the balance sheet date are classified as Short-term investments.


## us-gaap:NewAccountingPronouncementsAndChangesInAccountingPrinciplesTextBlock

[0001078271-15-000127:notes:70]
Recently Issued Accounting Pronouncements

[0001078271-15-000127:notes:71]
For a description of recently issued accounting pronouncements, see Note 4, Recently Issued Accounting Pronouncements, to the consolidated financial statements included in the Company's Annual report on Form 10-K for the fiscal year ended June 30, 2015. There have been no new accounting pronouncements issued that materially effect the Company's financial statements since the filing of the Annual report on Form 10-K.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0001078271-15-000127:notes:72]
Description of Business and Basis of Presentation

[0001078271-15-000127:notes:73]
Extreme Networks, Inc. (“Extreme Networks” or “the Company”) is a leading provider of network infrastructure equipment and markets its products primarily to business, governmental, health care, service provider, and educational customers with a focus on large corporate enterprises and metropolitan service providers on a global basis. The Company conducts its sales and marketing activities on a worldwide basis through distributors, resellers and the Company’s field sales organization. Extreme Networks was incorporated in California in 1996 and reincorporated in Delaware in 1999.

[0001078271-15-000127:notes:74]
The unaudited condensed consolidated financial statements of Extreme Networks included herein have been prepared under the rules and regulations of the Securities and Exchange Commission (“SEC”). Certain information and footnote disclosures normally included in financial statements prepared in accordance with generally accepted accounting principles have been condensed or omitted under such rules and regulations.  The condensed consolidated balance sheet at June 30, 2015 was derived from audited financial statements as of that date but does not include all disclosures required by generally accepted accounting principles for complete financial statements. These interim financial statements and notes should be read in conjunction with the Company’s audited consolidated financial statements and notes thereto included in the Company’s Annual Report on Form 10-K for the fiscal year ended June 30, 2015.

[0001078271-15-000127:notes:75]
The unaudited condensed consolidated financial statements reflect all adjustments, consisting only of normal recurring adjustments that, in the opinion of management, are necessary for a fair presentation of the results of operations and cash flows for the interim periods presented and the financial condition of Extreme Networks at September 30, 2015.  The results of operations for the three months ended September 30, 2015 are not necessarily indicative of the results that may be expected for fiscal 2016 or any future periods.

[0001078271-15-000127:notes:76]
Fiscal Year

[0001078271-15-000127:notes:77]
The Company uses a fiscal calendar year ending on June 30.  All references herein to "fiscal 2016" or "2016" represent the fiscal year ending June 30, 2016.

[0001078271-15-000127:notes:78]
Principles of Consolidation

[0001078271-15-000127:notes:79]
The consolidated financial statements include the accounts of Extreme Networks and its wholly-owned subsidiaries. All inter-company accounts and transactions have been eliminated.

[0001078271-15-000127:notes:80]
Accounting Estimates

[0001078271-15-000127:notes:81]
The preparation of financial statements and related disclosures in conformity with accounting principles generally accepted in the United States requires management to make estimates and assumptions that affect the amounts reported in the financial statements and accompanying notes. Estimates are used for, but are not limited to, the accounting for the allowances for doubtful accounts and sales returns, determining the fair value of acquired assets and assumed liabilities, estimated selling prices, inventory valuation and purchase commitments, depreciation and amortization, impairment of long-lived assets including goodwill, warranty accruals, restructuring liabilities, measurement of share-based compensation costs and income taxes. Actual results could differ materially from these estimates.

[0001078271-15-000127:notes:82]
The Company predominantly uses the United States Dollar as its functional currency. The functional currency for certain of its foreign subsidiaries is the local currency. For those subsidiaries that operate in a local currency functional environment, all assets and liabilities are translated to United States Dollars at current month end rates of exchange; and revenue and expenses are translated using the monthly average rate.

[0001078271-15-000127:notes:83]
Certain balances included in the consolidated statements of cash flows related to restructuring liabilities for prior periods have been reclassified to conform to the current period presentation.  In the consolidated statement of cash flows, the changes in operating assets and liabilities for Other long-term liabilities includes the changes in restructuring liabilities and other accrued liabilities which were previously disclosed separately.


## us-gaap:PropertyPlantAndEquipmentTextBlock

[0001078271-15-000127:notes:84]
Property and equipment consist of the following (in thousands):

[0001078271-15-000127:notes:85]
|  | September 30, 2015 |  | June 30, 2015 |
| Computer equipment | $ | 32,304 |  |  | $ | 32,753 |  |
| Purchased software | 5,531 |  |  | 5,425 |  |
| Office equipment, furniture and fixtures | 11,027 |  |  | 10,908 |  |
| Leasehold improvements | 22,871 |  |  | 24,293 |  |
|  | 71,733 |  |  | 73,379 |  |
| Less: accumulated depreciation and amortization | (36,139 | ) |  | (33,517 | ) |
| Property and equipment, net | $ | 35,594 |  |  | $ | 39,862 |  |


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001078271-15-000127:notes:86]
Restructuring Charges

[0001078271-15-000127:notes:87]
As of September 30, 2015, restructuring liabilities were $5.7 million and consisted of obligations for severance benefits, contract termination and other expenses. The short-term restructuring liability is recorded in "Other accrued liabilities" and the long-term restructuring liability is recorded in "Other long-term liabilities" in the consolidated balance sheets.  During the three months ended September 30, 2015, the Company recorded restructuring charges of $5.6 million and applied payments to the liability of $4.4 million.    Included in the restructuring charges were offsets for future sub-leasing income.  The Company has estimated the sub-lease income based on its existing leases agreement, as well the real estate market conditions at the respective locations.  The Company also factored  into its estimate the time for a sub-lease tenant to enter into an agreement and complete any improvements.  The Company will reevaluate any sub-lease income on a regular basis and adjust the accrual as necessary if and when facts should change.

[0001078271-15-000127:notes:88]
Fiscal 2015 Restructuring

[0001078271-15-000127:notes:89]
During the fourth quarter of fiscal 2015, we reduced costs through targeted restructuring activities intended to reduce operating costs and realign our organization in the current competitive environment.  We initiated a plan to reduce our worldwide headcount by more than 225 employees, primarily in sales and marketing, as well as research and development, consolidate specific global administrative functions, and shift certain operating costs to lower cost regions, among other actions.

[0001078271-15-000127:notes:90]
Phase Two

[0001078271-15-000127:notes:91]
During the first quarter of fiscal 2016, we continued our initiative to realign our operations with a second phase by abandoning excess facilities, primarily in San Jose California; Salem, New Hampshire and Shannon, Ireland. The abandoned facilities represented approximately 27% of the floor space at these locations and included general office and warehouse space.  There may be additional abandonments of excess facilities in future periods as we further align our organization to our business and operational needs.

[0001078271-15-000127:notes:92]
During the first quarter fiscal of 2016, in conjunction with the exiting of facilities noted above, the Company accelerated depreciation of leasehold improvements in the amount of $1.3 million.  This charge is reflected in "Restructuring charge, net of reversals"  in the consolidated statement of operations.

[0001078271-15-000127:notes:93]
As of September 30, 2015, the Company had restructuring liabilities of $5.7 million related to the fiscal 2015 restructuring, the severance benefits and other portions of the accrual are planned to be paid by the end of the second quarter of fiscal 2016. The excess facilities accrual payments will continue through fiscal year 2023, due to the length of agreements.

[0001078271-15-000127:notes:94]
Restructuring liabilities consist of (in thousands):

[0001078271-15-000127:notes:95]
|  | Excess Facilities |  | Severance Benefits |  | Other |  | Total |
| Balance as of June 30, 2015 | $ | — |  |  | $ | 5,737 |  |  | $ | 117 |  |  | $ | 5,854 |  |
| Period charges | 5,409 |  |  | 321 |  |  | 178 |  |  | 5,908 |  |
| Period reversals | — |  |  | (235 | ) |  | (70 | ) |  | (305 | ) |
| Non cash adjustments | (1,344 | ) |  | — |  |  | — |  |  | (1,344 | ) |
| Period payments | (42 | ) |  | (4,207 | ) |  | (125 | ) |  | (4,374 | ) |
| Balance as of September 30, 2015 | $ | 4,023 |  |  | $ | 1,616 |  |  | $ | 100 |  |  | $ | 5,739 |  |
| Less: current portion recorded in Other accrued liabilities |  |  |  |  |  |  | (3,629 | ) |
| Restructuring accrual included in Other long-term liabilities |  |  |  |  |  |  | $ | 2,110 |  |


## us-gaap:ScheduleOfAccountsPayableAndAccruedLiabilitiesTableTextBlock

[0001078271-15-000127:notes:96]
The following are the components of other accrued liabilities (in thousands):

[0001078271-15-000127:notes:97]
|  | September 30, 2015 |  | June 30, 2015 |
| Accrued general and administrative costs | $ | 4,216 |  |  | $ | 1,204 |  |
| Restructuring | 3,629 |  |  | 5,854 |  |
| Other accrued liabilities | 19,534 |  |  | 25,565 |  |
| Total other accrued liabilities | $ | 27,379 |  |  | $ | 32,623 |  |


## us-gaap:ScheduleOfCashCashEquivalentsAndShortTermInvestmentsTableTextBlock

[0001078271-15-000127:notes:98]
ummary of cash and available-for-sale securities (in thousands):

[0001078271-15-000127:notes:99]
|  | September 30, 2015 |  | June 30, 2015 |
| Cash | $ | 77,257 |  |  | $ | 71,455 |  |
| Cash equivalents | $ | 4,768 |  |  | $ | 4,770 |  |
| Total available-for-sale | $ | 4,768 |  |  | $ | 4,770 |  |
| Total cash, cash equivalents and available for sale securities | $ | 82,025 |  |  | $ | 76,225 |  |


## us-gaap:ScheduleOfDebtTableTextBlock

[0001078271-15-000127:notes:100]
The Company's debt is comprised of the following:

[0001078271-15-000127:notes:101]
|  | September 30, 2015 |  | June 30, 2015 |
| Current portion of long-term debt: |  |  |  |
| Term Loan | $ | 13,000 |  |  | $ | 11,375 |  |
| Current portion of long-term debt | $ | 13,000 |  |  | $ | 11,375 |  |
| Long-term debt, less current portion: |  |  |  |
| Term Loan | $ | 42,250 |  |  | $ | 45,500 |  |
| Revolving Facility | 10,000 |  |  | 10,000 |  |
| Total long-term debt, less current portion | 52,250 |  |  | 55,500 |  |
| Total debt | $ | 65,250 |  |  | $ | 66,875 |  |


## us-gaap:ScheduleOfFiniteLivedIntangibleAssetsTableTextBlock

[0001078271-15-000127:notes:102]
The following tables summarize the components of gross and net intangible asset balances (in thousands):

[0001078271-15-000127:notes:103]
|  | Weighted Average Remaining Amortization Period |  | Gross Carrying Amount |  | Accumulated Amortization |  | Net Carrying Amount |
| September 30, 2015 |  |  |  |  |  |  |  |
| Developed technology | 0.9 years |  | $ | 48,000 |  |  | $ | 32,486 |  |  | $ | 15,514 |  |
| Customer relationships | 1.0 years |  | 37,000 |  |  | 23,639 |  |  | 13,361 |  |
| Maintenance contracts | 3.0 years |  | 17,000 |  |  | 6,517 |  |  | 10,483 |  |
| Trademarks | 1.0 years |  | 2,500 |  |  | 1,597 |  |  | 903 |  |
| Order backlog | 0.0 years |  | 7,400 |  |  | 7,292 |  |  | 108 |  |
| License agreements | 9.9 years |  | 3,596 |  |  | 1,392 |  |  | 2,204 |  |
| Other intangibles | 4.2 years |  | 1,762 |  |  | 1,094 |  |  | 668 |  |
| Total intangibles, net |  |  | $ | 117,258 |  |  | $ | 74,017 |  |  | $ | 43,241 |  |

[0001078271-15-000127:notes:104]
|  | Weighted Average Remaining Amortization Period |  | Gross Carrying Amount |  | Accumulated Amortization |  | Net Carrying Amount |
| June 30, 2015 |  |  |  |  |  |  |  |
| Developed technology | 1.2 years |  | $ | 48,000 |  |  | $ | 28,194 |  |  | $ | 19,806 |  |
| Customer relationships | 1.3 years |  | 37,000 |  |  | 20,556 |  |  | 16,444 |  |
| Maintenance contracts | 3.3 years |  | 17,000 |  |  | 5,667 |  |  | 11,333 |  |
| Trademarks | 1.3 years |  | 2,500 |  |  | 1,389 |  |  | 1,111 |  |
| Order backlog | 0.3 years |  | 7,400 |  |  | 6,967 |  |  | 433 |  |
| License agreements | 10.2 years |  | 10,924 |  |  | 8,620 |  |  | 2,304 |  |
| Other intangibles | 3.8 years |  | 2,684 |  |  | 1,983 |  |  | 701 |  |
| Total intangibles, net |  |  | $ | 125,508 |  |  | $ | 73,376 |  |  | $ | 52,132 |  |


## us-gaap:ScheduleOfInventoryCurrentTableTextBlock

[0001078271-15-000127:notes:105]
The following is a summary of our inventory by category (in thousands):

[0001078271-15-000127:notes:106]
|  | September 30, 2015 |  | June 30, 2015 |
| Finished goods | $ | 59,373 |  |  | $ | 55,301 |  |
| Raw materials | 2,306 |  |  | 2,713 |  |
| Total Inventory | $ | 61,679 |  |  | $ | 58,014 |  |


## us-gaap:ScheduleOfProductWarrantyLiabilityTableTextBlock

[0001078271-15-000127:notes:107]
The following table summarizes the activity related to the Company’s product warranty liability during the three months ended September 30, 2015 and 2014:

[0001078271-15-000127:notes:108]
|  | Three Months Ended |
|  | September 30, 2015 |  | September 30, 2014 |
| Accrued warranty beginning of period | $ | 8,676 |  |  | $ | 7,551 |  |
| New warranties issued | 2,564 |  |  | 2,265 |  |
| Warranty expenditures | (1,996 | ) |  | (1,927 | ) |
| Accrued warranty end of period | $ | 9,244 |  |  | $ | 7,889 |  |


## us-gaap:ScheduleOfRevenueFromExternalCustomersAttributedToForeignCountriesByGeographicAreaTextBlock

[0001078271-15-000127:notes:109]
[same as prior period, unchanged from 0001078271-15-000052:notes:111]

[0001078271-15-000127:notes:110]
|  | Three Months Ended |
| Net Revenues: | September 30, 2015 |  | September 30, 2014 |
| Americas: |  |  |  |
| United States | $ | 56,343 |  |  | $ | 58,488 |  |
| Other | 5,843 |  |  | 7,341 |  |
| Total Americas | 62,186 |  |  | 65,829 |  |
| EMEA | 51,026 |  |  | 53,934 |  |
| APAC | 11,369 |  |  | 16,511 |  |
| Total net revenues | $ | 124,581 |  |  | $ | 136,274 |  |


## us-gaap:ScheduleOfSegmentReportingInformationBySegmentTextBlock

[0001078271-15-000127:notes:111]
| Long Lived Assets: | September 30, 2015 |  | September 30, 2014 |
| Americas | $ | 80,829 |  |  | $ | 98,500 |  |
| EMEA | 25,259 |  |  | 41,900 |  |
| APAC | 2,597 |  |  | — |  |
| Total long lived assets | $ | 108,685 |  |  | $ | 140,400 |  |


## us-gaap:SchedulesOfConcentrationOfRiskByRiskFactorTextBlock

[0001078271-15-000127:notes:112]
The following table sets forth major customers accounting for 10% or more of our net revenue:

[0001078271-15-000127:notes:113]
|  | Three Months Ended |
|  | September 30, 2015 |  | September 30, 2014 |
| Westcon Group Inc. | 16% |  | 13% |
| Techdata | 12% |  | 14% |
| Jenne | 11% |  | * |
| * Less than 10% of net revenue |  |  |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001078271-15-000127:notes:114]
[same as prior period, unchanged from 0001078271-15-000052:notes:116]

[0001078271-15-000127:notes:115]
The Company operates in one segment, the development and marketing of network infrastructure equipment. The Company conducts business globally and is managed geographically. Revenue is attributed to a geographical area based on the location of its customers. The Company operates in three geographical areas: Americas, which includes the United States, Canada, Mexico, Central America and South America; EMEA, which includes Europe, Russia, Middle East and Africa; and APAC which includes Asia Pacific, South Asia, India, Australia and Japan.


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001078271-15-000127:notes:116]
[same as prior period, unchanged from 0001078271-15-000052:notes:118]

[0001078271-15-000127:notes:117]
For a description of significant accounting policies, see Note 3, Summary of Significant Accounting Policies, to the consolidated financial statements included in the Company's Annual report on Form 10-K for the fiscal year ended June 30, 2015. There have been no material changes to the Company's significant accounting policies since the filing of the Annual report on Form 10-K.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001078271-15-000127:notes:118]
[same as prior period, unchanged from 0001078271-15-000052:notes:120]

[0001078271-15-000127:notes:119]
Cash and Cash Equivalents

[0001078271-15-000127:notes:120]
The following is a summary of cash and available-for-sale securities (in thousands):

[0001078271-15-000127:notes:121]
Inventory Valuation

[0001078271-15-000127:notes:122]
The Company's inventory balances as of September 30 and June 30, 2015 were $61.7 million and $58.0 million, respectively. The Company values its inventory at lower of cost or market.  Cost is computed using standard cost, which approximates actual cost, on a first-in, first-out basis.  The Company has established inventory allowances primarily determined by the age of inventory or when conditions exist that suggest that inventory may be in excess of anticipated demand or is obsolete based upon assumptions about future demand.  At the point of the loss recognition, a new, lower-cost basis for that inventory is established, and subsequent changes in facts and circumstances do not result in the restoration or increase in that newly established cost basis.  Any written down or obsolete inventory subsequently sold has not had a material impact on gross margin for any of the periods disclosed.

[0001078271-15-000127:notes:123]
Property and Equipment, Net

[0001078271-15-000127:notes:124]
Intangibles

[0001078271-15-000127:notes:125]
Amortization expense for the three months ended September 30, 2015 and 2014, was $8.9 million and $9.0 million, respectively.  Of the total amount recognized, $4.4 million and $4.5 million is included in "Cost of revenues for products" on the consolidated statements of operations in the respectively periods, while the remainder of the amortization expense is included in "Amortization of intangibles" on the consolidated statement of operations.  The amortization expense that is recognized in "Cost of revenues for products" is comprised of amortization for developed technology, license agreements and other intangibles.

[0001078271-15-000127:notes:126]
Other Accrued Liabilities

[0001078271-15-000127:notes:127]
[same as prior period, unchanged from 0001078271-15-000052:notes:124]

[0001078271-15-000127:notes:128]
[same as prior period, unchanged from 0001078271-15-000052:notes:125]

[0001078271-15-000127:notes:129]
The Company offers for sale to its customers, renewable support arrangements that range from one to five years.  Deferred support revenue is included within deferred revenue, net within the services category above.  The change in the Company’s deferred support revenue balance in relation to these arrangements was as follows (in thousands):

[0001078271-15-000127:notes:130]
[same as prior period, unchanged from 0001078271-15-000052:notes:127]

[0001078271-15-000127:notes:131]
The Company records revenue from its distributors on a sell-through basis, recording deferred revenue and deferred cost of sales associated with all sales transactions to its distributors in “Deferred distributors revenue, net of cost of sales to distributors” in the liability section of its condensed consolidated balance sheet. The amount shown as “Deferred distributors revenue, net of cost of sales to distributors” represents the deferred gross profit on sales to distributors based on contractual pricing.

[0001078271-15-000127:notes:132]
[same as prior period, unchanged from 0001078271-15-000052:notes:129]

[0001078271-15-000127:notes:133]
During fiscal 2015, the Company amended its credit agreement which provides for a five-year revolving credit facility for up to $50.0 million (the “Revolving Facility”) and a $65 million five-year term loan (the “Term Loan”) and together with the Revolving Facility (the “Senior Secured Credit Facilities, as amended”).

[0001078271-15-000127:notes:134]
The Senior Secured Credit Facilities, as amended contains, among others, certain financial covenants that require the Company to maintain defined minimum financial ratios which may limit the Company’s availability to borrowings under the Revolving Facility. As of September 30, 2015, the Company had $37.4 million of availability under the Revolving Facility and is in compliance with its covenants.

[0001078271-15-000127:notes:135]
The Company had $1.0 million of outstanding letters of credit as of September 30, 2015.

[0001078271-15-000127:notes:136]
[same as prior period, unchanged from 0001078271-15-000052:notes:133]

[0001078271-15-000127:notes:137]
Networking products may contain undetected hardware or software errors when new products or new versions or updates of existing products are released to the marketplace. In the past, we had experienced such errors in connection with products and product updates.  The Company’s standard hardware warranty period is typically 12 months from the date of shipment to end-users and 90 days for software. For certain access products, the Company offers a limited lifetime hardware warranty commencing on the date of shipment from the Company and ending five (5) years following the Company’s announcement of the end of sale of such product. Upon shipment of products to its customers, the Company estimates expenses for the cost to repair or replace products that may be returned under warranty and accrue a liability in cost of product revenue for this amount. The determination of the Company’s warranty requirements is based on actual historical experience with the product or product family, estimates of repair and replacement costs and any product warranty problems that are identified after shipment. The Company estimates and adjusts these accruals at each balance sheet date in accordance with changes in these factors.

[0001078271-15-000127:notes:138]
Upon issuance of a standard product warranty, the Company discloses and recognizes a liability for the obligations it assumes under the product warranty.   The following table summarizes the activity related to the Company’s product warranty liability during the three months ended September 30, 2015 and 2014:

[0001078271-15-000127:notes:139]
In the normal course of business to facilitate sales of its products, the Company indemnifies its resellers and end-user customers with respect to certain matters. The Company has agreed to hold the customer harmless against losses arising from a breach of intellectual property infringement or other claims made against certain parties. These agreements may limit the time within which an indemnification claim can be made and the amount of the claim. It is not possible to estimate the maximum potential amount under these indemnification agreements due to the limited history of prior indemnification claims and the unique facts and circumstances involved in each particular agreement.  Historically, payments made by the Company under these agreements have not had a material impact on its operating results or financial position.

[0001078271-15-000127:notes:140]
Advertising

[0001078271-15-000127:notes:141]
Cooperative advertising expenses are recorded as marketing expenses to the extent that an advertising benefit separate from the revenue transaction can be identified and the cash paid does not exceed the fair value of that advertising benefit received. Cooperative advertising obligations with customers are accrued and the costs expensed at the time the related revenue is recognized. If the Company does not meet the criteria for recognizing such cooperative advertising obligations as marketing expense, the costs are recorded as a reduction of revenue.  All other advertising costs are expensed as incurred.  Advertising expenses for the three months ended September 30, 2015 and 2014, were immaterial.

[0001078271-15-000127:notes:142]
[same as prior period, unchanged from 0001078271-15-000052:notes:136]

[0001078271-15-000127:notes:143]
The Company may be subject to concentration of credit risk as a result of certain financial instruments consisting of accounts receivable and short-term investments.  The Company does not invest an amount exceeding 10% of its combined cash or cash equivalents in the securities of any one obligor or maker, except for obligations of the United States government, obligations of United States government agencies and money market accounts.

[0001078271-15-000127:notes:144]
The Company performs ongoing credit evaluations of its customers and generally does not require collateral in exchange for credit.
