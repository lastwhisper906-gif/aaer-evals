# EXTR MD&A — 0001078271-15-000127


## mdna

[0001078271-15-000127:mdna:1]
[same as prior period, unchanged from 0001078271-15-000052:mdna:1]

[0001078271-15-000127:mdna:2]
[same as prior period, unchanged from 0001078271-15-000052:mdna:2]

[0001078271-15-000127:mdna:3]
We believe that understanding the following key developments is helpful to an understanding of our operating results for the fiscal quarter ended September 30, 2015.

[0001078271-15-000127:mdna:4]
We are a leading provider of network infrastructure equipment and offer related services contracts for extended warranty and maintenance to our enterprise, data center and service provider customers.  We are a networking industry leader with more than 20,000 customers. We were incorporated in California in May 1996, and reincorporated in Delaware in March 1999.  Our corporate headquarters are located in San Jose, California. Substantially all of our revenue is derived from the sale of our networking equipment and related service contracts.

[0001078271-15-000127:mdna:5]
We believe we will set the standard for the networking industry with a strategic focus on three principles:

[0001078271-15-000127:mdna:6]
| • | Highly scaled and differentiated products and solutions: Our combined product portfolio spans data center networking, switching and routing, Software-Defined Networking ("SDN"), wired and wireless LAN access, network management with analytics and integrated security features. This broader solutions portfolio can be leveraged to better serve existing and new customers. We intend to increase research and development to accelerate our vision for high-performance, modular, open networking. |

[0001078271-15-000127:mdna:7]
| • | Leading customer service and support: We are working to augment our current outsourced support model by integrating Enterasys' in-sourced expertise, building on Enterasys' award-winning heritage and strong commitment to exceptional customer experience. The Company's expanded global network of channel partners and distributors will benefit from expanded services and support capabilities. |

[0001078271-15-000127:mdna:8]
| • | Strong Channels and Strategic Partners: Our focus is to leverage the capabilities of the combined Company and expand existing partnerships with Ericsson, as well as continue to add new strategic partnerships in the future. Additionally, we will increase our focus on partnering with distributors and channel partners globally. The goal is to develop and enhance relationships that grow revenue and profits for the Company and our alliance and channel partners. At the same time, we are investing in infrastructure to make doing business with the Company easier and more efficient. |

[0001078271-15-000127:mdna:9]
Impact of the Global Economic Developments

[0001078271-15-000127:mdna:10]
We operate in three regions: Americas, which includes the United States, Canada, Mexico, Central America and South America; EMEA, which includes Europe, Middle East, and Africa; and APAC which includes Asia Pacific, South Asia, Japan and Australia. Sales in APAC and some European countries have continued to be impacted as a result of the soft global economy. We believe that conservative purchasing patterns and delays or cancellation of IT infrastructure plans in the face of continued uncertainty regarding the global economy, may continue to negatively impact overall demand for networking solutions, including Ethernet equipment.  Additionally, the continuation of the strong U.S. Dollar compared to most other currency, particularly on a year over year basis, has contributed to the conservative purchasing trends in many international locations.

[0001078271-15-000127:mdna:11]
We have taken, and plan to continue to take, other steps to manage our business in the current economic environment. For example, we have managed from time to time our contingent work force, consolidation of office locations, reduced travel and other discretionary spending, realigned our product portfolio and organization to grow revenue and operating income, and controlled all hiring activities.

[0001078271-15-000127:mdna:12]
Increasing Demand for Bandwidth

[0001078271-15-000127:mdna:13]
We believe that the continued increase in demand for bandwidth will, over time, drive future demand for high performance Ethernet solutions. Wide-spread adoption of electronic communications in all aspects of our lives, proliferation of next generation converged mobile devices and deployment of triple-play services to residences and businesses alike, continues to generate demand for greater network performance across broader geographic locations. In parallel to these transformational forces within society and the community at large, the accelerating adoption of internet and intranet “cloud” solutions within business enterprises is enabling organizations to offer greater business scalability to improve efficiency and through more effective operations, improve profitability. In order to realize the benefits of these developments, customers require additional bandwidth and high performance from their network infrastructure at affordable prices. We are seeing the initial indications that the Ethernet segment of the networking equipment market will return to growth as enterprise, data center and carrier customers continue to recognize the performance and operating cost benefits of Ethernet technology.

[0001078271-15-000127:mdna:14]
Expanding Product Portfolio

[0001078271-15-000127:mdna:15]
We believe that continued success in our marketplace is dependent upon a variety of factors that includes, but is not limited to, our ability to design, develop and distribute new and enhanced products employing leading-edge technology. New software and hardware introductions during fiscal 2015 included a Summit X770 switch supporting industry's highest density performing top of rack switching, Purview - a network-powered application analytics and optimization solution, identiFi 38xx WiFi Access Points supporting 802.11ac, SDN 2.0 - an open, standards-based (based on OpenDaylight) and comprehensive SDN solution, 100GbE support for the BDX8 and NetSight 6.0 a consolidated management across the expanded portfolio. ​

[0001078271-15-000127:mdna:16]
Industry Developments

[0001078271-15-000127:mdna:17]
The market for network infrastructure equipment is highly competitive and dominated by a few large companies. The current economic climate has further driven consolidation of vendors within the Ethernet networking market and with vendors from adjacent markets, including storage, security, wireless and voice applications. We believe that the underpinning technology for all of these adjacent markets is Ethernet.  As a result, independent Ethernet switch vendors are being acquired or merged with larger, adjacent market vendors to enable them to deliver complete and broad solutions.  As an independent Ethernet switch vendor, we must provide products that, when combined with the products of our large strategic partners, create compelling solutions for end-user customers.  Our acquisition of Enterasys gives us a larger market share and presence and an opportunity to create complementary solutions for our customers. Our approach is to focus on the intelligence and automation layer that spans our hardware products and that facilitates end-to-end solutions, as opposed to positioning Extreme Networks as a low-cost-vendor with point products.  Lower overall market growth has also created an environment of declining margins due to increased competition between the remaining vendors in this space. During the last year, overall Ethernet port counts have grown, while industry revenues have decreased, signaling a decline in average selling price per port. Our product life cycle and operational cost reduction efforts are therefore even more critical for margin preservation.

[0001078271-15-000127:mdna:18]
[same as prior period, unchanged from 0001078271-15-000052:mdna:55]

[0001078271-15-000127:mdna:19]
During the first quarter of fiscal 2016, we achieved the following results:

[0001078271-15-000127:mdna:20]
| • | Net revenues of $124.6 million compared to $136.3 million in the first quarter of fiscal 2015. |

[0001078271-15-000127:mdna:21]
| • | Product revenues of $91.4 million compared to $102.7 million in the first second quarter of fiscal 2015. |

[0001078271-15-000127:mdna:22]
| • | Service revenues of $33.2 million compared to $33.6 million in the first quarter of fiscal 2015. |

[0001078271-15-000127:mdna:23]
| • | Total gross margin of 52% of net revenues compared to 52% of net revenues in the first quarter of fiscal 2015. |

[0001078271-15-000127:mdna:24]
| • | Operating loss of $10.8 million compared to $17.2 million in the first quarter of fiscal 2015. |

[0001078271-15-000127:mdna:25]
| • | Net loss of $11.5 million compared to $19.3 million in the first quarter of fiscal 2015. |

[0001078271-15-000127:mdna:26]
| • | Cash flow provided by operating activities of $6.5 million in the three months ended September 30, 2015 compared to cash flow used in operating activities of $1.6 million in the three months ended September 30, 2014. |

[0001078271-15-000127:mdna:27]
| • | Cash and cash equivalents increased by $5.8 million to $82.0 million as of September 30, 2015 from $76.2 million as of June 30, 2015, primarily due to increased proceeds from cash provided by operations offset by repayment of debt. |

[0001078271-15-000127:mdna:28]
We operate in three regions: Americas, which includes the United States, Canada, Mexico, Central America and South America; EMEA, which includes Europe, Russia, Middle East, and Africa; and APAC which includes Asia Pacific, South Asia, India, and Australia.

[0001078271-15-000127:mdna:29]
The following table presents the total net revenue geographically for the three months ended September 30, 2015 and September 30, 2014 (dollars in thousands):

[0001078271-15-000127:mdna:30]
|  | Three Months Ended |
| Net Revenues | September 30, 2015 |  | September 30, 2014 |  | $Change |  | %Change |
| Americas: |  |  |  |  |  |  |  |
| United States | $ | 56,343 |  |  | $ | 58,488 |  |  | $ | (2,145 | ) |  | (3.7 | )% |
| Other | 5,843 |  |  | 7,341 |  |  | (1,498 | ) |  | (20.4 | )% |
| Total Americas | 62,186 |  |  | 65,829 |  |  | (3,643 | ) |  | (5.5 | )% |
| Percentage of net revenue | 50.0 | % |  | 48.3 | % |  |  |  |  |
| EMEA | 51,026 |  |  | 53,934 |  |  | (2,908 | ) |  | (5.4 | )% |
| Percentage of net revenue | 41.0 | % |  | 39.6 | % |  |  |  |  |
| APAC | 11,369 |  |  | 16,511 |  |  | (5,142 | ) |  | (31.1 | )% |
| Percentage of net revenue | 9.1 | % |  | 12.1 | % |  |  |  |  |
| Total net revenues | $ | 124,581 |  |  | $ | 136,274 |  |  | $ | (11,693 | ) |  | (8.6 | )% |

[0001078271-15-000127:mdna:31]
[same as prior period, unchanged from 0001078271-15-000052:mdna:68]

[0001078271-15-000127:mdna:32]
The following table presents net product and service revenue for the three months ended September 30, 2015 and September 30, 2014, (dollars in thousands):

[0001078271-15-000127:mdna:33]
|  | Three Months Ended |
|  | September 30, 2015 |  | September 30, 2014 |  | $Change |  | %Change |
| Net Revenues: |  |  |  |  |  |  |  |
| Product | $ | 91,381 |  |  | $ | 102,672 |  |  | $ | (11,291 | ) |  | (11.0 | )% |
| Percentage of net revenue | 73.4 | % |  | 75.3 | % |  |  |  |  |
| Service | 33,200 |  |  | 33,602 |  |  | (402 | ) |  | (1.2 | )% |
| Percentage of net revenue | 26.7 | % |  | 24.7 | % |  |  |  |  |
| Total net revenues | $ | 124,581 |  |  | $ | 136,274 |  |  | $ | (11,693 | ) |  | (8.6 | )% |

[0001078271-15-000127:mdna:34]
Product revenue decreased $11.3 million or 11.0% in the first quarter of fiscal 2016 compared to the corresponding period of fiscal 2015. In the first quarter of fiscal 2016, the Company experienced a decrease in shipments due to the global financial uncertainty, continuing strong U.S. Dollar and increased price competition.

[0001078271-15-000127:mdna:35]
Service revenue decreased $0.4 million in the first quarter of fiscal 2016 compared to the corresponding period of fiscal 2015 including lower purchase accounting charges related to deferred service revenues of $0.4 million in first quarter of fiscal 2016 to $0.4 million as compared to $0.8 million in the first quarter of fiscal 2015.

[0001078271-15-000127:mdna:36]
22

[0001078271-15-000127:mdna:37]
[same as prior period, unchanged from 0001078271-15-000052:mdna:75]

[0001078271-15-000127:mdna:38]
The following table presents the product and service revenue gross profit and the respective gross profit percentages for the three months ended September 30, 2015 and 2014 (dollars in thousands):

[0001078271-15-000127:mdna:39]
|  | Three Months Ended |
|  | September 30, 2015 |  | September 30, 2014 |  | $Change |  | %Change |
| Gross profit: |  |  |  |  |  |  |  |
| Product | $ | 44,447 |  |  | $ | 48,647 |  |  | $ | (4,200 | ) |  | (8.6 | )% |
| Percentage of product revenue | 48.6 | % |  | 47.4 | % |  |  |  |  |
| Service | 20,671 |  |  | 21,880 |  |  | (1,209 | ) |  | (5.5 | )% |
| Percentage of service revenue | 62.3 | % |  | 65.1 | % |  |  |  |  |
| Total gross profit | $ | 65,118 |  |  | $ | 70,527 |  |  | $ | (5,409 | ) |  | (7.7 | )% |
| Percentage of net revenue | 52.3 | % |  | 51.8 | % |  |  |  |  |

[0001078271-15-000127:mdna:40]
Product gross profit decreased $4.2 million in the first quarter of fiscal 2016 as compared to the corresponding period in fiscal 2015.  Gross profit was impacted during the first quarter of fiscal 2016 by a decrease in product revenue of $11.3 million and higher distribution expenses as compared to the corresponding period of fiscal 2015 offset by lower overhead costs due in part to the reduction in force ("RIF") during the fourth quarter of fiscal 2015 and lower royalties on older product which have been discontinued.

[0001078271-15-000127:mdna:41]
Service gross profit decreased to $20.7 million in the first quarter of fiscal 2016 from $21.9 million in the first quarter of fiscal 2015 due to excess inventory charges of $1.1 million combined with lower service revenues of $0.4 million partial offset by lower purchase accounting charges of $0.4 million  related to deferred service revenues in first quarter of fiscal 2016, as compared to the first quarter of fiscal 2015.

[0001078271-15-000127:mdna:42]
[same as prior period, unchanged from 0001078271-15-000052:mdna:85]

[0001078271-15-000127:mdna:43]
[same as prior period, unchanged from 0001078271-15-000052:mdna:86]

[0001078271-15-000127:mdna:44]
|  | Three Months Ended |
|  | September 30, 2015 |  | September 30, 2014 |  | $Change |  | %Change |
| Research and development | $ | 20,268 |  |  | $ | 23,347 |  |  | $ | (3,079 | ) |  | (13.2 | )% |
| Sales and marketing | 36,062 |  |  | 44,779 |  |  | (8,717 | ) |  | (19.5 | )% |
| General and administrative | 9,176 |  |  | 11,074 |  |  | (1,898 | ) |  | (17.1 | )% |
| Acquisition and integration costs | 338 |  |  | 4,058 |  |  | (3,720 | ) |  | (91.7 | )% |
| Restructuring charge, net of reversals | 5,603 |  |  | — |  |  | 5,603 |  |  | N/A |  |
| Amortization of intangibles | 4,467 |  |  | 4,467 |  |  | — |  |  | — | % |
| Total operating expenses | $ | 75,914 |  |  | $ | 87,725 |  |  | $ | (11,811 | ) |  | (13.5 | )% |
| Operating loss | $ | (10,796 | ) |  | $ | (17,198 | ) |  | $ | 6,402 |  |  | 37.2 | % |

[0001078271-15-000127:mdna:45]
[same as prior period, unchanged from 0001078271-15-000052:mdna:88]

[0001078271-15-000127:mdna:46]
[same as prior period, unchanged from 0001078271-15-000052:mdna:89]

[0001078271-15-000127:mdna:47]
Research and development expenses decreased by $3.1 million, or 13.2% three months ended September 30, 2015 as compared to the corresponding periods of fiscal 2015. The decreases in research and development expenses were due to lower personnel costs of $2.4 million as a result of the RIF during the fourth quarter of fiscal 2015, and travel and entertainment of $0.1 million.

[0001078271-15-000127:mdna:48]
[same as prior period, unchanged from 0001078271-15-000052:mdna:93]

[0001078271-15-000127:mdna:49]
[same as prior period, unchanged from 0001078271-15-000052:mdna:94]

[0001078271-15-000127:mdna:50]
Sales and marketing expenses decreased by $8.7 million, or 19.5% for the three months ended September 30, 2015 as compared to the corresponding periods of fiscal 2015.  The decreases in sales and marketing expenses were primarily due to   lower

[0001078271-15-000127:mdna:51]
personnel costs of $5.3 million as a result of the RIF during the fourth quarter of fiscal 2015, travel and entertainment of $1.2 million, rent expense of $0.4 million and professional services of $0.3 million.

[0001078271-15-000127:mdna:52]
[same as prior period, unchanged from 0001078271-15-000052:mdna:97]

[0001078271-15-000127:mdna:53]
General and administrative expenses decreased by $1.9 million, or 17.1% for the three months ended September 30, 2015 as compared to the corresponding period of fiscal 2015.  The decrease in general and administrative expenses was due to lower   personnel costs of $0.7 million as a result of the RIF during the fourth quarter of fiscal 2015, professional services of  $0.8 million and rent expense of $0.4 million, partially offset by lower bad debt expense of $0.3 million.

[0001078271-15-000127:mdna:54]
[same as prior period, unchanged from 0001078271-15-000052:mdna:101]

[0001078271-15-000127:mdna:55]
Acquisition and integration costs include those costs that we have incurred only as result of the acquisition of Enterasys and related subsequent integration of the two companies.

[0001078271-15-000127:mdna:56]
During the three months ended September 30, 2015 and 2014, we recorded $0.3 million and $4.1 million, respectively of integration costs primarily for IT, warehouse, and sales integration and severance costs.

[0001078271-15-000127:mdna:57]
Restructuring Charges

[0001078271-15-000127:mdna:58]
During the three months ended September 30, 2015, we recorded $5.6 million in restructuring charges, primarily in excess facilities, net of future sub-lease income.  There were no restructuring charges during the corresponding period in fiscal 2015.  During the first quarter of fiscal 2016, we continued our initiative to realign our operations with a second phase by abandoning excess facilities, primarily in San Jose California; Salem, New Hampshire and Shannon, Ireland. The abandoned facilities represented approximately 27% of our original space, and included general office and warehouse space.  There may be additional activities in abandonments of excess facilities in future periods as we further align our organization to our business and operational needs.

[0001078271-15-000127:mdna:59]
In conjunction with the restructuring activity we accelerated depreciation of leasehold improvements in the amount of $1.3 million, which is included in the total restructuring charge noted above

[0001078271-15-000127:mdna:60]
[same as prior period, unchanged from 0001078271-15-000052:mdna:104]

[0001078271-15-000127:mdna:61]
During the three months ended September 30, 2015 and 2014, we recorded $4.5 million and $4.5 million, respectively of amortization expense.

[0001078271-15-000127:mdna:62]
[same as prior period, unchanged from 0001078271-15-000052:mdna:106]

[0001078271-15-000127:mdna:63]
During the three months ended September 30, 2015 and 2014 we recorded $0.8 million and $0.8 million, respectively in interest expense.

[0001078271-15-000127:mdna:64]
Other Income (Expense), Net

[0001078271-15-000127:mdna:65]
During the three months ended September 30, 2015 and 2014 we recorded $1.0 million of gains and $0.4 million of losses, respectively in other income (expense), net.  The increase was primarily due to foreign exchange gains from the revaluation of certain assets and liabilities denominated in foreign currencies into U.S. Dollars.

[0001078271-15-000127:mdna:66]
[same as prior period, unchanged from 0001078271-15-000052:mdna:111]

[0001078271-15-000127:mdna:67]
For the three months ended September 30, 2015 and 2014, we recorded an income tax provision of $0.9 million and $1.0 million, respectively.

[0001078271-15-000127:mdna:68]
The income tax provisions for the three months ended September 30, 2015 and 2014 consisted primarily of taxes on the income of our foreign subsidiaries as well as tax expense associated with the establishment of a U.S. deferred tax liability for amortizable goodwill resulting from the acquisition of Enterasys.

[0001078271-15-000127:mdna:69]
[same as prior period, unchanged from 0001078271-15-000052:mdna:12]

[0001078271-15-000127:mdna:70]
[same as prior period, unchanged from 0001078271-15-000052:mdna:13]

[0001078271-15-000127:mdna:71]
As discussed in Part II, Item 7, “Management's Discussion and Analysis of Financial Condition and Results of Operations” of our Annual Report on Form 10-K for the year ended June 30, 2015, we consider the following accounting policies to be the most critical in understanding the judgments that are involved in preparing our consolidated financial statements:

[0001078271-15-000127:mdna:72]
[same as prior period, unchanged from 0001078271-15-000052:mdna:15]

[0001078271-15-000127:mdna:73]
[same as prior period, unchanged from 0001078271-15-000052:mdna:17]

[0001078271-15-000127:mdna:74]
[same as prior period, unchanged from 0001078271-15-000052:mdna:18]

[0001078271-15-000127:mdna:75]
| • | Restructuring Charges |

[0001078271-15-000127:mdna:76]
[same as prior period, unchanged from 0001078271-15-000052:mdna:21]

[0001078271-15-000127:mdna:77]
[same as prior period, unchanged from 0001078271-15-000052:mdna:22]

[0001078271-15-000127:mdna:78]
[same as prior period, unchanged from 0001078271-15-000052:mdna:23]

[0001078271-15-000127:mdna:79]
[same as prior period, unchanged from 0001078271-15-000052:mdna:24]

[0001078271-15-000127:mdna:80]
[same as prior period, unchanged from 0001078271-15-000052:mdna:25]

[0001078271-15-000127:mdna:81]
|  | September 30, 2015 |  | June 30, 2015 |
| Cash and cash equivalent | $ | 82,025 |  |  | $ | 76,225 |  |
| Total cash and investments | $ | 82,025 |  |  | $ | 76,225 |  |
| Working capital | $ | 6,621 |  |  | $ | 2,564 |  |

[0001078271-15-000127:mdna:82]
As of September 30, 2015, our principal sources of liquidity consisted of cash and cash equivalents of $82.0 million, accounts receivable, net of $60.3 million and availability of borrowings from the Revolving Facility of $37.4 million.  Our principal uses of cash will include repayments of debt and related interest, purchase of finished goods inventory from our contract manufacturers, payroll, restructuring expenses and other operating expenses related to the development, marketing of our products and purchases of property and equipment.  We believe that our $82.0 million of cash and cash equivalents at September 30, 2015, cash flows from operations along with the availability of borrowings from the Revolving Facility will be sufficient to fund our principal uses of cash for at least the next 12 months.

[0001078271-15-000127:mdna:83]
The Senior Secured Credit Facilities, as amended, contain financial covenants that require us to maintain a minimum Consolidated Fixed Charge Coverage Ratio and Consolidated Quick Ratio and a maximum Consolidated Leverage Ratio and other financial and non-financial covenants and restrictions that limit our ability to incur additional indebtedness, create liens upon any of our property, merge, consolidate or sell all or substantially all of our assets, etc.

[0001078271-15-000127:mdna:84]
The Senior Secured Credit Facilities, as amended, also include customary events of default, including failure to pay principal, interest or fees when due, failure to comply with covenants, if any representation or warranty made by us is false or misleading in any material respect, certain insolvency or receivership events affecting Extreme and its subsidiaries, the occurrence of certain material judgments, the occurrence of certain ERISA events, the invalidity of the loan documents or a change in control of our Company.  The amounts outstanding under the Senior Secured Credit Facilities, as amended, may be accelerated upon certain events of default. We are in compliance and expect to remain in compliance with the covenants of the Senior Secured Credit Facilities, as amended, and they are not expected to impact our liquidity or capital resources.

[0001078271-15-000127:mdna:85]
[same as prior period, unchanged from 0001078271-15-000052:mdna:31]

[0001078271-15-000127:mdna:86]
[same as prior period, unchanged from 0001078271-15-000052:mdna:32]

[0001078271-15-000127:mdna:87]
|  | Three Months Ended |
|  | September 30, 2015 |  | September 30, 2014 |
| Net cash provided by operating activities | $ | 6,526 |  |  | $ | 1,632 |  |
| Net cash used in investing activities | (633 | ) |  | (1,036 | ) |
| Net cash provided by financing activities | 230 |  |  | 925 |  |
| Foreign currency effect on cash | (323 | ) |  | (644 | ) |
| Net increase in cash and cash equivalents | $ | 5,800 |  |  | $ | 877 |  |

[0001078271-15-000127:mdna:88]
Net Cash Provided By Operating Activities

[0001078271-15-000127:mdna:89]
Cash flows provided by operations in the three months ending September 30, 2015 was $6.5 million was generated from non-cash expenses such as amortization of intangibles, stock-based compensation expense and depreciation as well as decreases

[0001078271-15-000127:mdna:90]
in accounts receivables and was partially offset by the current period's net loss along with increases in inventories and decreases in accounts payable, accrued compensation and deferred revenues.

[0001078271-15-000127:mdna:91]
Cash flows provided by operations in the three months ending September 30, 2014, was $1.6 million.  The prior year's net loss was primarily offset by non-cash expenses such as amortization of intangibles, stock-based compensation expense and depreciation.  Accounts receivables decreased due to lower revenue during the quarter combined with higher collections. Inventories decreased due to the timing of inventory receipts to bring inventory levels in line with the near term demand.  Such increases in cash inflows were offset by decreases in accounts payables primarily due to the timing of payments.

[0001078271-15-000127:mdna:92]
Net Cash Used In Investing Activities

[0001078271-15-000127:mdna:93]
Cash flow used in investing activities in the three months ending September 30, 2015 was $0.6 million, comprised of purchases of property and equipment.

[0001078271-15-000127:mdna:94]
Cash flow used in investing activities in the three months ending September 30, 2014, was $1.0 million comprised of $2.8 million used to purchase property and equipment offset by proceeds of $2.0 million from the maturities of investments.

[0001078271-15-000127:mdna:95]
Net Cash Provided By Financing Activities

[0001078271-15-000127:mdna:96]
Cash flow provided by financing activities in the three months ending September 30, 2015 was $0.2 million, comprised of $1.9 million proceeds from the issuance of shares of our common stock under the ESPP and the exercise of stock options, net of taxes paid on vested and released stock awards offset by $1.6 million of cash used for repayment of debt.

[0001078271-15-000127:mdna:97]
Cash flow provided by financing activities in the three months ending September 30, 2014, was $0.9 million, comprised of a draw on the Revolving Facility of $24.0 million, $1.7 million proceeds from the exercise of stock options and issuance of shares of our common stock under the ESPP, net of taxes paid on vested and released stock awards offset by $24.8 million of cash used for repayment of debt.

[0001078271-15-000127:mdna:98]
[same as prior period, unchanged from 0001078271-15-000052:mdna:43]

[0001078271-15-000127:mdna:99]
Foreign currency effect on cash increased in the three months ending September 30, 2015, primarily due to changes in foreign currency exchange rates between US Dollar and particularly the Brazilian Real, Swedish Krona, Indian Rupee and Australian Dollar.

[0001078271-15-000127:mdna:100]
[same as prior period, unchanged from 0001078271-15-000052:mdna:45]

[0001078271-15-000127:mdna:101]
The following summarizes our contractual obligations at September 30, 2015, and the effect such obligations are expected to have on our liquidity and cash flow in future periods (in thousands):

[0001078271-15-000127:mdna:102]
|  | Total |  | Less than 1 Year |  | 1-3 years |  | 3-5 years |  | More than 5 years |
| Contractual Obligations: |  |  |  |  |  |  |  |  |  |
| Debt obligations | $ | 65,250 |  |  | $ | 13,000 |  |  | $ | 36,563 |  |  | $ | 15,687 |  |  | $ | — |  |
| Interest on debt obligations | 4,742 |  |  | 2,174 |  |  | 2,519 |  |  | 49 |  |  | — |  |
| Non-cancellable inventory purchase commitments | 72,532 |  |  | 72,532 |  |  | — |  |  | — |  |  | — |  |
| Non-cancellable operating lease obligations | 61,084 |  |  | 10,373 |  |  | 18,143 |  |  | 14,910 |  |  | 17,658 |  |
| Other liabilities | 5,854 |  |  | 5,075 |  |  | 763 |  |  | 16 |  |  | — |  |
| Total contractual cash obligations | $ | 209,462 |  |  | $ | 103,154 |  |  | $ | 57,988 |  |  | $ | 30,662 |  |  | $ | 17,658 |  |

[0001078271-15-000127:mdna:103]
Non-cancelable inventory purchase commitments represent the purchase of long lead-time component inventory that our contract manufacturers procure in accordance with our forecast. Inventory purchase commitments were $72.5 million as of September 30, 2015.  We expect to honor the inventory purchase commitments within the next 12 months.

[0001078271-15-000127:mdna:104]
Non-cancelable operating lease obligations represent base rents and operating expense obligations to landlords for facilities we occupy at various locations.

[0001078271-15-000127:mdna:105]
Other liabilities include the Company's commitments towards debt related fees and specific arrangements other than inventory.

[0001078271-15-000127:mdna:106]
[same as prior period, unchanged from 0001078271-15-000052:mdna:51]

[0001078271-15-000127:mdna:107]
We did not have any material commitments for capital expenditures as of September 30, 2015.

[0001078271-15-000127:mdna:108]
[same as prior period, unchanged from 0001078271-15-000052:mdna:53]

[0001078271-15-000127:mdna:109]
We did not have any off-balance sheet arrangements as of September 30, 2015.
