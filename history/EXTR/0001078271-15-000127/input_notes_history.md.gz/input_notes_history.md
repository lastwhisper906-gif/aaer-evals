# EXTR note change history — 0001078271-15-000052 → 0001078271-15-000127


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2015-11-02):
[0001078271-15-000127:note_history:1]
The Company currently has arrangements with contract manufacturers and suppliers for the manufacture of its products. The arrangements allow them to procure long lead-time component inventory based upon a rolling production forecast provided by the Company. The Company is obligated to the purchase of long lead-time component inventory that its contract manufacturer procures in accordance with the forecast, unless the Company gives notice of order cancellation outside of applicable component lead-times.  As of September 30, 2015, the Company had non-cancelable commitments to purchase $72.5 million of such inventory.
  (was, 2015-05-07, similarity 0.9696):
[0001078271-15-000052:note_history:1]
The Company currently has arrangements with contract manufacturers and suppliers for the manufacture of its products. The arrangements allow them to procure long lead-time component inventory based upon a rolling production forecast provided by the Company. The Company is obligated to the purchase of long lead-time component inventory that its contract manufacturer procures in accordance with the forecast, unless the Company gives notice of order cancellation outside of applicable component lead-times. The Company had non-cancelable commitments to purchase $100.7 million of such inventory as of March 31, 2015.

- changed (2015-11-02):
[0001078271-15-000127:note_history:2]
2002 - 2009 ICMS Tax Assessment Matters
  (was, 2015-05-07, similarity 0.9):
[0001078271-15-000052:note_history:2]
ICMS Tax Assessment Matters

- changed (2015-11-02):
[0001078271-15-000127:note_history:3]
The State of Sao Paolo (Brazil) denied Enterasys Networks do Brazil Ltda. the use of certain credits derived from the State of Espirito Santo under the terms of the FUNDAP scheme for the tax years of 2002 through 2009.  Enterasys’ application to resolve the ICMS Tax Assessments at the administrative level of the Sao Paolo Tax Department under the amnesty relief program (Reference No 3.056.963-1) was denied in March, 2014, by the Sao Paolo Tax Administration.  The value of the ICMS tax credits that were disallowed by the Sao Paolo Tax Administration is approximately BR 3,433,914 (or approximately US $0.9 million), plus interest and penalties (that are currently estimated to be approximately US $4.1 million).  Possible court fees are estimated to be BR 3,952,598 (or approximately US $1.0 million). On January 10, 2014, Enterasys filed a lawsuit to overturn or reduce the assessment, which lawsuit remains on-going.  As part of this lawsuit, Enterasys made a request for a stay of execution, so that no tax foreclosure can be filed until a final ruling is made and no guarantee needs to be presented.  On or about October 6, 2014, the preliminary injunction was granted with regard to the stay of execution, and in response to an appeal on the guarantee requirement, the appellant court further ruled on or about January 28, 2015 that no cash deposit (or guarantee) need be made by Enterasys.
  (was, 2015-05-07, similarity 0.9696):
[0001078271-15-000052:note_history:3]
The State of Sao Paolo (Brazil) denied Enterasys Networks do Brazil Ltda. the use of certain credits derived from the State of Espirito Santo under the terms of the FUNDAP scheme for the tax years of 2002 through 2009.  Enterasys’ application to resolve the ICMS Tax Assessments at the administrative level of the Sao Paolo Tax Department under the amnesty relief program (Reference No 3.056.963-1) was denied in March, 2014, by the Sao Paolo Tax Administration.  The value of the ICMS tax credits that were disallowed by the Sao Paolo Tax Administration is approximately BR 3,443,914 (or approximately US $1.5 million), plus interest and penalties (that are currently estimated to be approximately US $9.0 million).  On January 10, 2014, Enterasys filed a lawsuit to overturn or reduce the assessment, which lawsuit remains on-going.  As part of this lawsuit, Enterasys made a request for a stay of execution, so that no tax foreclosure can be filed until a final ruling is made and no guarantee needs to be presented.  On or about October 6, 2014, the preliminary injunction was granted with regard to the stay of execution, and in response to an appeal on the guarantee requirement, the appellant court further ruled on or about January 28, 2015 that no cash deposit (or guarantee) need be made by Enterasys.

- changed (2015-11-02):
[0001078271-15-000127:note_history:4]
Given the preliminary nature of the lawsuit, it is premature to assess the likelihood of a particular final outcome.  Based on the currently available information, the Company believes the ultimate outcome of this audit will not have material adverse effect on the Company's financial position or overall results of operations.  The range of the potential total tax liability related to these matters is estimated to be from US $0 million to US $6.0 million, of which the Company believes US $4.3 million is the best estimate within the range and has recorded an accrual as of the Acquisition Date of Enterasys as such matter relates to the period before the acquisition.
  (was, 2015-05-07, similarity 0.9925):
[0001078271-15-000052:note_history:4]
Given the preliminary nature of the lawsuit, it is premature to assess the likelihood of a particular final outcome.  Based on the currently available information, the Company believes the ultimate outcome of this audit will not have material adverse effect on the Company's financial position or overall trends in results of operations.  The range of the potential total tax liability related to these matters is estimated to be from US $0 million to US $9.0 million, of which the Company believes US $4.3 million is the best estimate within the range and has recorded an accrual as of the acquisition date of Enterasys as such matter relates to the period before the acquisition.

- added (2015-11-02):
[0001078271-15-000127:note_history:5]
Extreme made a demand on April 11, 2014 for a defense from, and indemnification by, Seller of these 2002-2009 ICMS Tax Assessment matters.  Seller agreed to assume the defense of these 2002-2009 ICMS Tax Assessment Matters on May 20, 2014.  In addition, through the settlement of the Unify Indemnification Suit on June 18, 2015, Seller has agreed to continue to defend Extreme in this matter and to indemnify Extreme for losses related thereto subject to certain conditions.  These conditions relate to offsetting of foreign income tax benefits realized by the Company in the connection with the acquisition of Enterasys.  Based upon current projections of the foreign income tax benefits to be realized, the Company does not anticipated that any amounts under the indemnification will be due.

- added (2015-11-02):
[0001078271-15-000127:note_history:6]
Hong vs Extreme

- added (2015-11-02):
[0001078271-15-000127:note_history:7]
On October 23, 2015, a complaint was filed for violations of securities laws in the U.S. District Court for the Northern District of California in the name of Jui-Yang Hong, Individually and on behalf of all others similarly situated, against the Company, and named defendants Charles W. Berger, Kenneth B. Arola, and John T. Kurtzweil.  Plaintiff alleges that defendants violated the securities laws by disseminating materially false and misleading statements and concealing material adverse facts regarding Extreme Networks' current financial condition and growth prospects. Plaintiffs seek damages of an unspecified amount.  The Company intends to vigorously defend the suit.

- added (2015-11-02):
[0001078271-15-000127:note_history:8]
Indemnification Obligations

- added (2015-11-02):
[0001078271-15-000127:note_history:9]
Subject to certain limitations, the Company may be obligated to indemnify its current and former directors, officers and employees. These obligations arise under the terms of its certificate of incorporation, its bylaws, applicable contracts, and Delaware and California law. The obligation to indemnify, where applicable, generally means that the Company is required to pay or reimburse, and in certain circumstances the Company has paid or reimbursed, the individuals' reasonable legal expenses and possibly damages and other liabilities incurred in connection with these matters. It is not possible to estimate the maximum potential amount under these indemnification agreements due to the limited history of these claims. The cost to defend the Company and the named individuals could have a material adverse effect on its consolidated financial position, results of operations and cash flows in the future. Recovery of such costs under its directors and officers’ insurance coverage is uncertain. As of September 30, 2015, the Company had no outstanding indemnification claims.

- removed (2015-11-02):
[0001078271-15-000052:note_history:10]
Litigation

- removed (2015-11-02):
[0001078271-15-000052:note_history:11]
Commonwealth of Kentucky

- removed (2015-11-02):
[0001078271-15-000052:note_history:12]
On or about February 3, 2014, a class action lawsuit was filed in the Commonwealth of Kentucky against Enterasys Networks, Inc. and two other defendants.  The complaint alleges that Enterasys and its subcontractor, TJL Information Technologies, Inc., d.b.a. Unbridled Information Technologies (“Subcontractor”), violated Kentucky’s wage and hour laws and failed to pay the prevailing wage in violation of the Kentucky State Prevailing Wage Act (the “Act”) on various public works projects for a number of Kentucky government agencies since January 2010.  Plaintiffs also allege common law actions for quantum merit and unjust enrichment and they seek monetary damages, costs, expenses and attorney fees, although there was no quantified amount identified.  One of the defendants, Integrated Facility Systems, LLC (“IFS”), has also filed a cross-claim against Enterasys.  The Company denies the claims and filed answers to both the complaint and cross-claim on April 16, 2014.  In addition, the Company filed a cross-claim for indemnity against IFS.

- removed (2015-11-02):
[0001078271-15-000052:note_history:13]
Plaintiffs filed a first amended complaint on September 26, 2014, in which they named Commonwealth of Kentucky’s Office of Technology under the State’s Finance and Administration Cabinet (“COT”) as a defendant.  The Company filed an answer to the Plaintiffs’ first amended complaint on October 10, 2014. COT then filed a motion to dismiss COT as a defendant in this lawsuit and the court granted COT’s motion. Plaintiffs filed a motion for Summary Judgment/Adjudication on the issue of whether the work performed by the defendants constitutes “construction” under the Act, which was denied on February 26, 2015.  Given the preliminary nature of the lawsuit, it is premature to assess the likelihood of a particular outcome.

- removed (2015-11-02):
[0001078271-15-000052:note_history:14]
Unify U.S. Holdings, Inc. (formerly known as Enterprise Networks Holdings, Inc.).

- removed (2015-11-02):
[0001078271-15-000052:note_history:15]
On or about April 8, 2015, Company filed a lawsuit against Unify U.S. Holdings, Inc. (formerly known as Enterprise Networks Holdings, Inc.) (“Seller”) for breach of, and indemnification by Seller under, the purchase agreement, between Seller and Company, for Company’s purchase of Enterasys Networks, Inc. and its subsidiaries (the “Purchase Agreement”).  The complaint alleges numerous claims for indemnification resulting from Seller’s violations of certain clauses in the Purchase Agreement and Seller’s failure to make accurate and proper disclosures as required by the Purchase Agreement.  The Company was compelled to file this action to perfect and preserve the Company’s right to indemnification by Seller under the Purchase Agreement.  Although the Company’s complaint has not quantified the amount being sought, the complaint seeks, among other things, monetary damages, costs, expenses and attorney fees in connection with each of the claims.  Given the preliminary nature of the lawsuit, it is premature to assess the likelihood of a particular or final outcome.

- removed (2015-11-02):
[0001078271-15-000052:note_history:16]
Wetro LAN LLC

- removed (2015-11-02):
[0001078271-15-000052:note_history:17]
On Mar 23, 2015, Wetro LAN LLC (Wetro), a non-practicing entity, filed a complaint against Extreme in the Eastern District of Texas asserting infringement of United States Patent No. 6,795,918 (the “ ‘918 Patent”). Wetro alleges that Extreme “makes, uses, provides, offers for sale, and sells their product entitled Extreme Networks- Altitude 4700 Series Access Points and similarly situated wireless routers” and thereby has infringed the 918 Patent. Wetro sued a number of other technology companies in January and February 2015 for the same patent.  Indications at the USPTO are that the 918 Patent has expired, limiting potential damages including all future damages in the case.  Wetro seeks monetary damages, although the complaint seeks no quantified amount.  Given the preliminary nature of the lawsuit, it is premature to assess the likelihood of a particular or final outcome.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2015-11-02):
[0001078271-15-000127:note_history:18]
Description of Business and Basis of Presentation
  (was, 2015-05-07, similarity 0.6):
[0001078271-15-000052:note_history:18]
Basis of Presentation

- added (2015-11-02):
[0001078271-15-000127:note_history:19]
Extreme Networks, Inc. (“Extreme Networks” or “the Company”) is a leading provider of network infrastructure equipment and markets its products primarily to business, governmental, health care, service provider, and educational customers with a focus on large corporate enterprises and metropolitan service providers on a global basis. The Company conducts its sales and marketing activities on a worldwide basis through distributors, resellers and the Company’s field sales organization. Extreme Networks was incorporated in California in 1996 and reincorporated in Delaware in 1999.

- changed (2015-11-02):
[0001078271-15-000127:note_history:20]
The unaudited condensed consolidated financial statements of Extreme Networks included herein have been prepared under the rules and regulations of the Securities and Exchange Commission (“SEC”). Certain information and footnote disclosures normally included in financial statements prepared in accordance with generally accepted accounting principles have been condensed or omitted under such rules and regulations.  The condensed consolidated balance sheet at June 30, 2015 was derived from audited financial statements as of that date but does not include all disclosures required by generally accepted accounting principles for complete financial statements. These interim financial statements and notes should be read in conjunction with the Company’s audited consolidated financial statements and notes thereto included in the Company’s Annual Report on Form 10-K for the fiscal year ended June 30, 2015.
  (was, 2015-05-07, similarity 0.9682):
[0001078271-15-000052:note_history:20]
The unaudited condensed consolidated financial statements of Extreme Networks, Inc. (referred to as the “Company” or “Extreme Networks”) included herein have been prepared under the rules and regulations of the Securities and Exchange Commission (“SEC”). Certain information and footnote disclosures normally included in financial statements prepared in accordance with generally accepted accounting principles have been condensed or omitted under such rules and regulations. The condensed consolidated balance sheet at June 30, 2014 was derived from audited financial statements as of that date but does not include all disclosures required by generally accepted accounting principles for complete financial statements. These interim financial statements and notes should be read in conjunction with the Company’s audited consolidated financial statements and notes thereto included in the Company’s Annual Report on Form 10-K for the fiscal year ended June 30, 2014.

- changed (2015-11-02):
[0001078271-15-000127:note_history:21]
The unaudited condensed consolidated financial statements reflect all adjustments, consisting only of normal recurring adjustments that, in the opinion of management, are necessary for a fair presentation of the results of operations and cash flows for the interim periods presented and the financial condition of Extreme Networks at September 30, 2015.  The results of operations for the three months ended September 30, 2015 are not necessarily indicative of the results that may be expected for fiscal 2016 or any future periods.
  (was, 2015-05-07, similarity 0.786):
[0001078271-15-000052:note_history:21]
The unaudited condensed consolidated financial statements reflect all adjustments, consisting only of normal recurring adjustments that, in the opinion of management, are necessary for a fair presentation of the results of operations and cash flows for the interim periods presented and the financial condition of Extreme Networks at March 31, 2015.

- added (2015-11-02):
[0001078271-15-000127:note_history:22]
Fiscal Year

- added (2015-11-02):
[0001078271-15-000127:note_history:23]
The Company uses a fiscal calendar year ending on June 30.  All references herein to "fiscal 2016" or "2016" represent the fiscal year ending June 30, 2016.

- added (2015-11-02):
[0001078271-15-000127:note_history:24]
Principles of Consolidation

- added (2015-11-02):
[0001078271-15-000127:note_history:25]
The consolidated financial statements include the accounts of Extreme Networks and its wholly-owned subsidiaries. All inter-company accounts and transactions have been eliminated.

- added (2015-11-02):
[0001078271-15-000127:note_history:26]
Accounting Estimates

- added (2015-11-02):
[0001078271-15-000127:note_history:27]
The preparation of financial statements and related disclosures in conformity with accounting principles generally accepted in the United States requires management to make estimates and assumptions that affect the amounts reported in the financial statements and accompanying notes. Estimates are used for, but are not limited to, the accounting for the allowances for doubtful accounts and sales returns, determining the fair value of acquired assets and assumed liabilities, estimated selling prices, inventory valuation and purchase commitments, depreciation and amortization, impairment of long-lived assets including goodwill, warranty accruals, restructuring liabilities, measurement of share-based compensation costs and income taxes. Actual results could differ materially from these estimates.

- added (2015-11-02):
[0001078271-15-000127:note_history:28]
The Company predominantly uses the United States Dollar as its functional currency. The functional currency for certain of its foreign subsidiaries is the local currency. For those subsidiaries that operate in a local currency functional environment, all assets and liabilities are translated to United States Dollars at current month end rates of exchange; and revenue and expenses are translated using the monthly average rate.

- added (2015-11-02):
[0001078271-15-000127:note_history:29]
Certain balances included in the consolidated statements of cash flows related to restructuring liabilities for prior periods have been reclassified to conform to the current period presentation.  In the consolidated statement of cash flows, the changes in operating assets and liabilities for Other long-term liabilities includes the changes in restructuring liabilities and other accrued liabilities which were previously disclosed separately.

- removed (2015-11-02):
[0001078271-15-000052:note_history:30]
The results of operations for the three and nine months ended March 31, 2015 are not necessarily indicative of the results that may be expected for fiscal 2015 or any future periods.


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2015-11-02):
[0001078271-15-000127:note_history:31]
The Company's debt is comprised of the following:
  (was, 2015-05-07, similarity 0.8673):
[0001078271-15-000052:note_history:31]
The Company's debt is comprised of the following (in thousands):

- changed (2015-11-02):
[0001078271-15-000127:note_history:32]
|  | September 30, 2015 |  | June 30, 2015 |
| Current portion of long-term debt: |  |  |  |
| Term Loan | $ | 13,000 |  |  | $ | 11,375 |  |
| Current portion of long-term debt | $ | 13,000 |  |  | $ | 11,375 |  |
| Long-term debt, less current portion: |  |  |  |
| Term Loan | $ | 42,250 |  |  | $ | 45,500 |  |
| Revolving Facility | 10,000 |  |  | 10,000 |  |
| Total long-term debt, less current portion | 52,250 |  |  | 55,500 |  |
| Total debt | $ | 65,250 |  |  | $ | 66,875 |  |
  (was, 2015-05-07, similarity 0.7838):
[0001078271-15-000052:note_history:32]
|  |  | March 31, 2015 |  | June 30, 2014 |
| Current portion of long-term debt: |  |  |  |  |
| Term Loan |  | $ | 9,750 |  |  | $ | 5,688 |  |
| Revolving Facility |  | — |  |  | 24,000 |  |
| Current portion of long-term debt |  | $ | 9,750 |  |  | $ | 29,688 |  |
| Long-term debt, less current portion: |  |  |  |  |
| Term Loan |  | $ | 48,750 |  |  | $ | 56,875 |  |
| Revolving Facility |  | 10,000 |  |  | 35,000 |  |
| Total long-term debt, less current portion |  | 58,750 |  |  | 91,875 |  |
| Total debt |  | $ | 68,500 |  |  | $ | 121,563 |  |
