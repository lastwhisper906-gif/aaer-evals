# EXTR 8-K — 0001078271-15-000125 filed 2015-10-29

## item codes, every 8-K on or before 2015-11-02

- 2015-10-29 0001078271-15-000125 — 2.02, 9.01
- 2015-08-31 0001078271-15-000111 — 8.01, 9.01
- 2015-08-11 0001078271-15-000096 — 5.02
- 2015-08-06 0001078271-15-000093 — 2.02, 9.01
- 2015-06-30 0001078271-15-000089 — 1.01, 9.01
- 2015-05-20 0001078271-15-000077 — 2.05, 9.01
- 2015-05-19 0001078271-15-000075 — 3.03, 9.01
- 2015-05-06 0001078271-15-000050 — 2.02, 9.01
- 2015-05-04 0001078271-15-000048 — 5.02, 9.01
- 2015-04-29 0001078271-15-000038 — 5.02, 9.01
- 2015-04-21 0001078271-15-000034 — 5.02, 9.01
- 2015-04-09 0001078271-15-000032 — 2.02, 5.02, 9.01
- 2015-02-18 0001078271-15-000021 — 8.01
- 2015-02-17 0001078271-15-000019 — 5.02
- 2015-01-28 0001078271-15-000004 — 2.02, 9.01
- 2014-12-18 0001078271-14-000081 — 5.02, 9.01
- 2014-12-17 0001078271-14-000079 — 5.02
- 2014-11-20 0001078271-14-000075 — 1.01, 9.01
- 2014-11-17 0001078271-14-000073 — 5.07
- 2014-10-28 0001078271-14-000062 — 2.02, 9.01
- 2014-10-15 0001078271-14-000060 — 2.02, 9.01
- 2014-10-02 0001078271-14-000057 — 5.02, 9.01
- 2014-08-14 0001078271-14-000047 — 2.02, 9.01
- 2014-07-21 0001078271-14-000042 — 2.02, 9.01
- 2014-05-23 0001078271-14-000036 — 5.02, 9.01
- 2014-05-20 0001078271-14-000034 — 3.03, 9.01
- 2014-05-12 0001078271-14-000030 — 5.02
- 2014-05-08 0001078271-14-000022 — 5.02, 9.01
- 2014-05-07 0001078271-14-000018 — 2.02, 9.01 — amendment, the index does not say of what
- 2014-05-06 0001078271-14-000016 — 2.02, 9.01
- 2014-02-20 0001078271-14-000014 — 5.02, 9.01
- 2014-02-18 0001078271-14-000010 — 5.02
- 2014-02-05 0001078271-14-000006 — 2.02, 9.01
- 2014-01-13 0001104659-14-002030 — 9.01 — amendment of 0001078271-13-000058
- 2013-11-25 0001078271-13-000081 — 5.07
- 2013-11-07 0001078271-13-000064 — 5.02, 9.01
- 2013-11-04 0001078271-13-000060 — 2.02, 9.01
- 2013-11-01 0001078271-13-000058 — 1.01, 2.01, 2.03, 8.01, 9.01
- 2013-10-16 0001078271-13-000056 — 8.01, 9.01
- 2013-09-13 0001078271-13-000052 — 1.01, 8.01, 9.01
- 2013-08-23 0001078271-13-000044 — 5.02, 9.01
- 2013-08-02 0001078271-13-000042 — 5.02
- 2013-07-30 0001078271-13-000039 — 2.02, 9.01
- 2013-07-30 0001078271-13-000037 — 5.02, 9.01
- 2013-06-21 0001078271-13-000032 — 8.01
- 2013-05-01 0001078271-13-000018 — 5.02, 9.01
- 2013-04-30 0001078271-13-000015 — 2.02, 9.01
- 2013-03-01 0001078271-13-000010 — 8.01
- 2013-02-19 0001078271-13-000008 — 5.02
- 2013-01-30 0001078271-13-000004 — 2.02, 9.01
- 2013-01-07 0001078271-13-000002 — 1.01, 2.02, 2.03, 2.05, 9.01
- 2012-12-03 0001078271-12-000094 — 5.02, 5.07, 8.01
- 2012-10-31 0001078271-12-000071 — 2.02, 9.01
- 2012-10-19 0001078271-12-000069 — 1.01, 2.03, 9.01
- 2012-10-16 0001078271-12-000067 — 8.01
- 2012-10-01 0001193125-12-411392 — 5.02, 8.01, 9.01
- 2012-09-24 0001193125-12-401798 — 5.02, 9.01
- 2012-09-21 0001193125-12-399896 — 5.02, 9.01
- 2012-09-18 0001193125-12-394379 — 1.01, 5.02, 9.01
- 2012-09-12 0001193125-12-388591 — 8.01
- 2012-08-27 0001078271-12-000057 — 8.01
- 2012-08-03 0001078271-12-000041 — 7.01, 9.01
- 2012-08-01 0001078271-12-000039 — 2.02, 9.01
- 2012-07-25 0001078271-12-000037 — 8.01
- 2012-05-22 0001078271-12-000033 — 5.02, 9.01
- 2012-05-21 0001078271-12-000030 — 8.01
- 2012-05-09 0001078271-12-000028 — 5.02, 9.01
- 2012-05-02 0001078271-12-000023 — 2.02, 9.01
- 2012-04-30 0001078271-12-000020 — 3.03, 5.07, 9.01
- 2012-04-19 0001078271-12-000012 — 2.02, 5.02, 9.01
- 2012-03-12 0001078271-12-000010 — 5.02, 9.01
- 2012-02-24 0001078271-12-000008 — 8.01
- 2012-02-02 0001078271-12-000004 — 2.02, 9.01
- 2012-01-30 0001078271-12-000002 — 1.01
- 2011-12-01 0001078271-11-000104 — 8.01
- 2011-11-08 0001078271-11-000099 — 8.01
- 2011-11-02 0001078271-11-000094 — 2.02, 9.01
- 2011-10-24 0001078271-11-000089 — 8.01, 9.01
- 2011-10-11 0001078271-11-000085 — 8.01
- 2011-09-29 0001078271-11-000082 — 8.01
- 2011-09-15 0001078271-11-000070 — 5.02, 9.01
- 2011-08-11 0001078271-11-000058 — 8.01
- 2011-08-10 0001078271-11-000055 — 5.02
- 2011-08-08 0001078271-11-000045 — 5.02
- 2011-08-01 0001078271-11-000038 — 2.02, 9.01
- 2011-07-14 0001078271-11-000036 — 2.02, 2.05, 9.01
- 2011-07-12 0001078271-11-000034 — 8.01
- 2011-07-01 0001078271-11-000032 — 5.02
- 2011-06-16 0001078271-11-000030 — 8.01
- 2011-05-06 0001078271-11-000027 — 8.01, 9.01
- 2011-05-04 0001078271-11-000025 — 8.01
- 2011-04-28 0001078271-11-000020 — 2.02, 9.01
- 2011-04-27 0001078271-11-000018 — 3.03, 5.02, 5.03, 9.01
- 2011-04-11 0001078271-11-000016 — 2.02
- 2011-03-31 0001078271-11-000014 — 5.02, 5.03
- 2011-03-15 0001193125-11-066049 — 5.02, 9.01
- 2011-03-01 0001193125-11-052048 — 5.02, 9.01
- 2011-02-10 0001078271-11-000012 — 7.01, 9.01
- 2011-01-31 0001078271-11-000005 — 2.02, 5.02, 5.03, 9.01
- 2010-12-23 0001193125-10-287613 — 8.01
- 2010-12-17 0001193125-10-283495 — 5.03, 5.07, 8.01, 9.01
- 2010-11-10 0001193125-10-255861 — 4.01, 9.01
- 2010-11-01 0001193125-10-242706 — 2.02, 9.01
- 2010-10-14 0001193125-10-229518 — 1.01, 9.01
- 2010-10-06 0001193125-10-224863 — 5.02, 8.01
- 2010-09-29 0001193125-10-219705 — 1.01, 8.01
- 2010-09-08 0001193125-10-206782 — 5.02, 8.01, 9.01
- 2010-08-25 0001193125-10-196951 — 8.01
- 2010-08-09 0001193125-10-182573 — 7.01, 8.01, 9.01
- 2010-08-03 0001193125-10-175255 — 5.02, 8.01, 9.01
- 2010-08-02 0001193125-10-173697 — 2.02, 8.01, 9.01
- 2010-07-30 0001193125-10-172214 — 5.02, 8.01, 9.01
- 2010-07-22 0001193125-10-163896 — 8.01, 9.01
- 2010-07-20 0001193125-10-161832 — 5.02
- 2010-07-12 0001193125-10-157291 — 2.02, 9.01
- 2010-07-01 0001193125-10-152746 — 3.03, 9.01
- 2010-05-10 0001193125-10-114669 — 5.02, 9.01
- 2010-04-26 0001193125-10-093310 — 2.02, 9.01
- 2010-03-19 0001193125-10-061679 — 5.02, 9.01
- 2010-02-16 0001193125-10-032335 — 5.02
- 2010-02-01 0001193125-10-018202 — 2.02, 9.01
- 2010-01-29 0001193125-10-017165 — 5.02
- 2010-01-11 0001193125-10-004099 — 8.01
- 2009-10-26 0001193125-09-213846 — 2.02, 9.01 — amendment of 0001193125-09-213780
- 2009-10-26 0001193125-09-213780 — 2.02, 9.01
- 2009-10-23 0001193125-09-212871 — 2.05, 5.02, 8.01, 9.01
- 2009-10-05 0001193125-09-203522 — 2.02, 9.01
- 2009-08-04 0001193125-09-163799 — 5.02, 9.01
- 2009-07-31 0001193125-09-160772 — 5.02, 9.01
- 2009-07-30 0001193125-09-159578 — 2.02, 9.01
- 2009-07-20 0001193125-09-151500 — 5.02, 9.01
- 2009-07-08 0001193125-09-145840 — 5.02, 9.01
- 2009-05-12 0001193125-09-108340 — 5.02, 9.01
- 2009-04-23 0001193125-09-085849 — 2.02, 9.01
- 2009-03-26 0001193125-09-064502 — 2.05
- 2009-01-28 0001193125-09-013182 — 2.02, 9.01
- 2008-11-06 0001193125-08-227572 — 2.02, 9.01
- 2008-11-03 0001193125-08-222501 — 5.02
- 2008-08-11 0001193125-08-173590 — 5.02
- 2008-08-11 0001193125-08-172587 — 8.01, 9.01
- 2008-08-06 0001193125-08-167934 — 2.02, 9.01
- 2008-08-04 0001193125-08-164673 — 5.02, 9.01
- 2008-05-21 0001193125-08-119640 — 7.01, 9.01
- 2008-04-29 0001193125-08-095270 — 2.02, 9.01
- 2008-03-05 0001193125-08-047893 — 8.01
- 2008-02-19 0001193125-08-033702 — 5.02
- 2008-02-05 0001193125-08-019969 — 5.02
- 2008-01-30 0001193125-08-015378 — 2.02, 9.01
- 2007-12-27 0001193125-07-272178 — 5.03, 9.01
- 2007-10-29 0001193125-07-228368 — 2.02, 9.01
- 2007-10-25 0001193125-07-225906 — 5.02, 9.01
- 2007-10-19 0001193125-07-221578 — 5.02
- 2007-09-26 0001193125-07-207348 — 8.01
- 2007-08-07 0001193125-07-172810 — 2.02, 9.01
- 2007-08-06 0001193125-07-172147 — 5.02, 9.01
- 2007-08-06 0001193125-07-172134 — 3.01
- 2007-07-09 0001193125-07-151467 — 3.01, 9.01
- 2007-06-28 0001193125-07-145519 — 2.02, 9.01
- 2007-06-27 0001193125-07-143262 — 2.05, 3.01, 5.02
- 2007-05-18 0001193125-07-118804 — 3.01, 9.01
- 2007-05-02 0001193125-07-099280 — 2.02, 9.01
- 2007-03-29 0001193125-07-068815 — 5.02, 9.01
- 2007-02-22 0001193125-07-037181 — 3.01, 9.01
- 2007-02-08 0001193125-07-024194 — 5.02
- 2007-01-30 0001193125-07-016428 — 2.02, 9.01
- 2007-01-11 0001193125-07-004825 — 4.02, 9.01
- 2006-11-21 0001193125-06-240068 — 5.02, 9.01
- 2006-11-16 0001193125-06-237262 — 3.01, 9.01
- 2006-11-01 0001193125-06-220707 — 2.02, 9.01
- 2006-10-31 0001193125-06-219237 — 1.01, 1.02, 5.02, 5.03, 8.01, 9.01
- 2006-09-28 0001193125-06-198185 — 3.01, 9.01
- 2006-09-15 0001193125-06-191640 — 7.01, 9.01
- 2006-09-05 0001193125-06-185202 — 5.02, 9.01
- 2006-08-08 0001193125-06-165953 — 1.01, 2.02, 5.02, 9.01
- 2006-07-18 0001193125-06-148526 — 1.01
- 2006-07-10 0001193125-06-143989 — 5.02, 9.01
- 2006-05-16 0001193125-06-113698 — 5.02, 9.01
- 2006-05-01 0001193125-06-094919 — 2.02, 9.01
- 2006-04-26 0001193125-06-089397 — 1.01, 9.01
- 2006-04-07 0001193125-06-075723 — 2.02, 9.01
- 2006-02-13 0001193125-06-029073 — 1.01
- 2006-01-31 0001193125-06-016143 — 1.01
- 2006-01-30 0001193125-06-015165 — 2.02, 9.01
- 2005-12-08 0001193125-05-239157 — 1.01, 1.02, 9.01
- 2005-11-01 0001193125-05-213101 — 2.02, 9.01
- 2005-09-29 0001193125-05-193991 — 1.01, 2.02, 9.01 — amendment of 0001193125-05-162807
- 2005-08-09 0001193125-05-162807 — 1.01, 2.02, 9.01
- 2005-07-14 0001193125-05-142162 — 8.01
- 2005-06-28 0001193125-05-133050 — 1.01, 9.01
- 2005-04-18 0001193125-05-077946 — 2.02, 7.01, 9.01
- 2005-04-14 0001193125-05-076665 — 2.02, 7.01, 9.01
- 2005-01-25 0001193125-05-011466 — 2.02, 9.01
- 2004-12-07 0001193125-04-208693 — 3.01
- 2004-10-26 0001193125-04-178370 — 2.02, 9.01
- 2004-10-04 0001193125-04-166289 — 5.02, 9.01
- 2004-07-28 0001193125-04-126135 — 12, 7
- 2004-05-12 0001193125-04-086287 — 12
- 2004-04-21 0001193125-04-066557 — 12, 7
- 2004-01-22 0001193125-04-007359 — 12, 7
- 2003-12-18 0001193125-03-096351 — 5, 7
- 2003-11-04 0001193125-03-072069 — 5, 7
- 2003-10-24 0001193125-03-066551 — 12, 7
- 2003-07-25 0001193125-03-024087 — 7, 9
- 2003-04-11 0001012870-03-001706 — 7, 9
- 2003-04-08 0001021408-03-005743 — 7, 9
- 2003-01-07 0001012870-03-000039 — 5, 7
- 2002-04-29 0001012870-02-002003 — 5, 7
- 2002-02-20 0001012870-02-000792 — 5, 7
- 2001-12-13 0001012870-01-503160 — 5, 7
- 2001-11-30 0001012870-01-503010 — 5, 7
- 2001-11-02 0001012870-01-502580 — 5
- 2001-10-23 0001021408-01-508589 — 5, 7
- 2001-06-07 0001021408-01-501772 — 5, 7 — amendment of 0001021408-01-500975
- 2001-05-15 0001021408-01-501104 — 5 — amendment of 0001021408-01-500975
- 2001-05-14 0001021408-01-500975 — 5, 7
- 2001-04-06 0001012870-01-500065 — 5, 7

## late-filing notifications on or before 2015-11-02

- 2008-05-12 0001193125-08-111540 — NT 10-Q, for the period ended 2008-03-30
- 2007-05-10 0001193125-07-110075 — NT 10-Q, for the period ended 2007-04-01
- 2007-02-09 0001193125-07-025490 — NT 10-Q, for the period ended 2006-12-31
- 2006-11-13 0001193125-06-232090 — NT 10-Q, for the period ended 2006-10-01
- 2006-09-15 0001193125-06-191838 — NT 10-K, for the period ended 2006-07-02

## item 2.02 — earnings release, exhibit 99.1

[0001078271-15-000125:8k_2_02:1]
EX-99.1
2
extr8kq116ex991.htm
EARNINGS PRESS RELEASE

[0001078271-15-000125:8k_2_02:2]
Exhibit

[0001078271-15-000125:8k_2_02:3]
FOR IMMEDIATE RELEASE

[0001078271-15-000125:8k_2_02:4]
| For more information, contact: |  |  |
| Investor Relations |  | Media Contact |
| 408/579-3456 |  | 617/624-3231 |
| fyoshino@extremenetworks.com |  | ExtremeUS@racepointglobal.com |

[0001078271-15-000125:8k_2_02:5]
Extreme Networks Reports First Quarter Fiscal Year 2016 Financial Results

[0001078271-15-000125:8k_2_02:6]
Q1 GAAP Revenue of $124.6 million & Non-GAAP Revenue of $125.0 million

[0001078271-15-000125:8k_2_02:7]
Q1 GAAP EPS Loss of $0.11 & Non-GAAP EPS Income of $0.07

[0001078271-15-000125:8k_2_02:8]
SAN JOSE, Calif., October 29, 2015 -- Extreme Networks, Inc. (Nasdaq: EXTR) today released financial results for the first quarter ended September 30, 2015.  First quarter GAAP revenue was $124.6 million and non-GAAP revenue was $125.0 million.  GAAP net loss for the first fiscal quarter was $11.5 million, or $0.11 per basic share, and non-GAAP net income was $6.7 million, or $0.07 per diluted share.

[0001078271-15-000125:8k_2_02:9]
“Fiscal 2016 is off to a good start with solid execution in the US and Europe and a nice rebound in Latin

[0001078271-15-000125:8k_2_02:10]
America,” stated Ed Meyercord, president and CEO of Extreme Networks.   “We made excellent progress with our solutions-based selling initiatives and the expense actions taken last quarter are producing increased operating margins and profitability,” said Meyercord.  “While our E-Rate revenue in the first quarter was lower than originally anticipated and our inside sales got off to a slow start, we expect these initiatives to deliver stronger contributions in future quarters.”

[0001078271-15-000125:8k_2_02:11]
Meyercord continued, “Over the past six months, our management team, employees and partners have come together and are aligned with our new vision and software-driven strategy.  I am pleased with how well they have executed the numerous operating initiatives to transform Extreme into a customer driven company.”

[0001078271-15-000125:8k_2_02:12]
Recent Key Events:

[0001078271-15-000125:8k_2_02:13]
| • | Extreme Networks announced the appointment of John Kispert to chairman of the board of directors, effective Aug. 25, 2015. |

[0001078271-15-000125:8k_2_02:14]
| • | Extreme Networks was positioned the furthest for Completeness of Vision in the Visionaries quadrant of the September 2015 Gartner Magic Quadrant for Wired and Wireless LAN Access Infrastructure. For the second consecutive year, the company was also recognized by Gartner, Inc. in the top five of all 14 vendors across six capabilities use cases in the September 2015 Gartner Critical Capabilities Report for Wired and Wireless LAN Access Infrastructure report. The Use Cases include: Enterprise Unified Wired and WLAN Access, Enterprise Wired-Only Connectivity, Enterprise Wireless-Only Connectivity, SMB and/or Mall or Remote Branch Office, Voice Over WLAN and IaaS or Managed Service. (1) |

[0001078271-15-000125:8k_2_02:15]
| • | Extreme Networks joined the VMware NSX™ partner ecosystem to enable interoperability between the Extreme Summit® x670-G2 and Summit x770 series switches and the VMware NSX network virtualization platform. |

[0001078271-15-000125:8k_2_02:16]
| • | Extreme Networks unveiled the latest simple, fast and smart IdentiFiTM wireless solution, which includes support for IEEE 802.11r & k standards, the AP3801 802.11ac access point, new C35 IdentiFi appliance and VMWare virtual appliance. |

[0001078271-15-000125:8k_2_02:17]
| • | Extreme Networks partnered with Axis Communications for the second consecutive year to provide a state of the art high density Wi-Fi network at the Little League World Series. |

[0001078271-15-000125:8k_2_02:18]
| • | Extreme Networks’ Bob Gault was honored as one of the most influential vendor executives in the midmarket by CRN, an award that recognizes leadership, strategic thinking and solution excellence. Over the last year, Bob was also named one of the 50 Most Influential Leaders on CRN’s annual Channel Chiefs listing and one of the Top 50 Channel Influencers by The VAR Guy. |

[0001078271-15-000125:8k_2_02:19]
| • | Extreme Networks continued to showcase customer momentum across the global education, healthcare, manufacturing, sports and entertainment, government and financial services markets. Notable Customer wins include the Chicago Cubs, Jefferson County Public Schools, SK Telecom, Christiana Care Health System, Skywalker Sound, a Lucasfilm company, Process Automation within Schneider Electric’s Industry Business, and Middle Tennessee State University. |

[0001078271-15-000125:8k_2_02:20]
(1)    Gartner does not endorse any vendor, product or service depicted in its research publications, and does not advise technology users to select only those vendors with the highest ratings or other designation. Gartner research publications consist of the opinions of Gartner's research organization and should not be construed as statements of fact. Gartner disclaims all warranties, expressed or implied, with respect to this research, including any warranties of merchantability or fitness for a particular purpose.

[0001078271-15-000125:8k_2_02:21]
Fiscal Q1 2016 Financial Metrics:

[0001078271-15-000125:8k_2_02:22]
|  |  | First Quarter |  |  |  |  |
|  |  | (in millions, except per share amounts and percentages) |  |  |  |  |
|  |  | (unaudited) |  |  |  |  |
|  |  | 2016 |  | 2015 |  | Change |
| GAAP Net Revenue |  |  |  |  |  |  |  |  |
| Product |  | $ | 91.4 |  |  | $ | 102.7 |  |  | $ | (11.3 | ) |  | (11 | )% |
| Service |  | $ | 33.2 |  |  | $ | 33.6 |  |  | $ | (0.4 | ) |  | (1 | )% |
| Total Net Revenue |  | $ | 124.6 |  |  | $ | 136.3 |  |  | $ | (11.7 | ) |  | (9 | )% |
| Gross Margin |  | 52.3 | % |  | 51.8 | % |  | 0.5 | % |  | 1 | % |
| Operating Loss |  | (8.7 | )% |  | (12.6 | )% |  | 3.9 | % |  | 31 | % |
| Net Loss |  | $ | (11.5 | ) |  | $ | (19.3 | ) |  | $ | 7.8 |  |  | 40 | % |
| Loss per basic share |  | $ | (0.11 | ) |  | $ | (0.20 | ) |  | $ | 0.09 |  |  | 45 | % |
| Non-GAAP Net Revenue |  |  |  |  |  |  |  |  |
| Product |  | $ | 91.4 |  |  | $ | 102.7 |  |  | $ | (11.3 | ) |  | (11 | )% |
| Service |  | $ | 33.6 |  |  | $ | 34.4 |  |  | $ | (0.8 | ) |  | (2 | )% |
| Total Net Revenue |  | $ | 125.0 |  |  | $ | 137.1 |  |  | $ | (12.1 | ) |  | (9 | )% |
| Gross Margin |  | 55.2 | % |  | 55.6 | % |  | (0.4 | )% |  | (1 | )% |
| Operating Margin |  | 6.0 | % |  | 0.9 | % |  | 5.1 | % |  | 567 | % |
| Net Income (Loss) |  | $ | 6.7 |  |  | $ | (0.9 | ) |  | $ | 7.6 |  |  | 844 | % |
| Earnings (Loss) per diluted share |  | $ | 0.07 |  |  | $ | (0.01 | ) |  | $ | 0.08 |  |  | 800 | % |

[0001078271-15-000125:8k_2_02:23]
| • | Cash and investments ended the quarter at $82.0 million, as compared to $76.2 million from the prior quarter. |

[0001078271-15-000125:8k_2_02:24]
| • | Accounts receivable balance ending Q1 was $60.3 million, with days sales outstanding (DSO) of 45. |

[0001078271-15-000125:8k_2_02:25]
| • | Inventory ending Q1 was $61.7 million, an increase of $3.7 million from the prior quarter. |

[0001078271-15-000125:8k_2_02:26]
Business Outlook:

[0001078271-15-000125:8k_2_02:27]
For its second quarter of fiscal 2016 ending December 31, 2015, the Company is targeting GAAP revenue in a range of $129.6 million to $139.6 million with non-GAAP revenue in a range of $130 million to $140 million. GAAP gross margin is targeted between 51.0% and 52.0% and non-GAAP gross margin targeted between 54.7% and 55.7%. Operating expenses are targeted to be between $74.5 million and $77.0 million on a GAAP basis and $62.5 million to $65.0 million on a non-GAAP basis. GAAP net loss is targeted to be between $7.0 million to $11.0 million, or $0.07 to $0.11 per share.  Non-GAAP earnings are targeted in a range of a net income of $6.5 million to $10.5 million, or $0.06 to $0.10 per diluted share. The GAAP and non-GAAP net income (loss) targets are based on an estimated 102 million and 104 million average outstanding shares, respectively. Targeted non-GAAP earnings exclude expenses related to stock-based compensation expense, the amortization of acquired intangibles, acquisition and integration related expenses, restructuring expenses and the purchase accounting adjustment related to deferred service revenue.

[0001078271-15-000125:8k_2_02:28]
Conference Call:

[0001078271-15-000125:8k_2_02:29]
Extreme Networks will host a conference call at 4:30 p.m. Eastern (1:30 p.m. Pacific) today to review the first fiscal quarter results and second fiscal quarter 2016 business outlook, including significant factors and assumptions underlying the targets noted above. The conference call will be available to the public through a live audio web broadcast via the Internet at http://investor.extremenetworks.com and a replay of the call will be available on the website through October 28, 2016.  The conference call may also be heard by dialing 1-877-303-9826 (international callers dial 1-224-357-2194). Supplemental financial information to be discussed during the conference call will be posted in the Investor Relations section of the Company's website www.extremenetworks.com including the non-GAAP reconciliation attached to this press release. The encore recording can be accessed by dialing (855) 859-2056 /or international 1 (404) 537-3406; Conference ID #:49772270.

[0001078271-15-000125:8k_2_02:30]
About Extreme Networks:

[0001078271-15-000125:8k_2_02:31]
Extreme Networks, Inc. (EXTR) delivers software-driven networking solutions that help IT departments everywhere deliver the ultimate business outcome: stronger connections with customers, partners and employees. Wired to wireless, desktop to datacenter, we go to extreme measures for our 20,000-plus customers in more than 80 countries, delivering 100% insourced support to organizations large and small, including some of the world’s leading names in business, education, government, healthcare, manufacturing and hospitality. Founded in 1996, Extreme is headquartered in San Jose, California. For more information, visit Extreme's website or call 1-888-257-3000.

[0001078271-15-000125:8k_2_02:32]
Extreme Networks and the Extreme Networks logo, ExtremeXOS, Identifi, and Summit are either trademarks or registered trademarks of Extreme Networks, Inc. in the United States and/or other countries. All other names are the property of their respective owners.

[0001078271-15-000125:8k_2_02:33]
Non-GAAP Financial Measures:

[0001078271-15-000125:8k_2_02:34]
Extreme Networks provides all financial information required in accordance with generally accepted accounting principles (GAAP). The Company is providing with this press release non-GAAP revenue, non-GAAP gross margins, non-GAAP operating expenses, and non-GAAP income/(loss) per share. In preparing non-GAAP information, the Company has excluded, where applicable, the impact of acquisition and integration costs, purchase accounting adjustments, amortization of acquired intangibles, restructuring

[0001078271-15-000125:8k_2_02:35]
charges, share-based compensation and overhead adjustments.  The Company believes that excluding these items provides both management and investors with additional insight into its current operations, the trends affecting the Company, the Company's marketplace performance, and the Company's ability to generate cash from operations. Please note that the Company's non-GAAP measures may be different than those used by other companies. The additional non-GAAP financial information the Company presents should be considered in conjunction with, and not as a substitute for, the Company's GAAP financial information.  The Company has provided a non-GAAP reconciliation of the results for the periods presented in this release, which are adjusted to exclude certain items as indicated.  These measures should only be used to evaluate the Company's results of operations in conjunction with the corresponding GAAP measures for comparable financial information and understanding of the Company's ongoing performance as a business. Extreme Networks uses both GAAP and non-GAAP measures to evaluate and manage its operations.

[0001078271-15-000125:8k_2_02:36]
Forward Looking Statements:

[0001078271-15-000125:8k_2_02:37]
More information about potential factors that could affect the Company's business and financial results is included in the Company’s filings with the Securities and Exchange Commission, including, without limitation, under the captions: "Management's Discussion and Analysis of Financial Condition and Results of Operations," and "Risk Factors".  Except as required under the U.S. federal securities laws and the rules and regulations of the SEC, Extreme Networks disclaims any obligation to update any forward-looking statements after the date of this release, whether as a result of new information, future events, developments, changes in assumptions or otherwise.

[0001078271-15-000125:8k_2_02:38]
EXTREME NETWORKS, INC.

[0001078271-15-000125:8k_2_02:39]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0001078271-15-000125:8k_2_02:40]
(In thousands, except share and per share amounts)

[0001078271-15-000125:8k_2_02:41]
(Unaudited)

[0001078271-15-000125:8k_2_02:42]
|  | September 30, 2015 |  | June 30, 2015 |
| ASSETS |  |  |  |
| Current assets: |  |  |  |
| Cash and cash equivalents | $ | 82,025 |  |  | $ | 76,225 |  |
| Accounts receivable, net of allowances of $2,876 at September 30, 2015 and $2,396 at June 30, 2015 | 60,330 |  |  | 92,737 |  |
| Inventories | 61,679 |  |  | 58,014 |  |
| Deferred income taxes | 696 |  |  | 760 |  |
| Prepaid expenses and other current assets | 10,510 |  |  | 10,258 |  |
| Total current assets | 215,240 |  |  | 237,994 |  |
| Property and equipment, net | 35,594 |  |  | 39,862 |  |
| Intangible assets, net | 43,241 |  |  | 52,132 |  |
| Goodwill | 70,877 |  |  | 70,877 |  |
| Other assets | 28,535 |  |  | 27,795 |  |
| Total assets | $ | 393,487 |  |  | $ | 428,660 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |  |  |  |
| Current liabilities: |  |  |  |
| Current portion of long-term debt | $ | 13,000 |  |  | $ | 11,375 |  |
| Accounts payable | 29,933 |  |  | 40,135 |  |
| Accrued compensation and benefits | 21,375 |  |  | 25,195 |  |
| Accrued warranty | 9,244 |  |  | 8,676 |  |
| Deferred revenue, net | 73,712 |  |  | 76,551 |  |
| Deferred distributors revenue, net of cost of sales to distributors | 33,976 |  |  | 40,875 |  |
| Other accrued liabilities | 27,379 |  |  | 32,623 |  |
| Total current liabilities | 208,619 |  |  | 235,430 |  |
| Deferred revenue, less current portion | 21,945 |  |  | 23,231 |  |
| Long-term debt, less current portion | 52,250 |  |  | 55,500 |  |
| Deferred income taxes | 3,224 |  |  | 2,979 |  |
| Other long-term liabilities | 9,078 |  |  | 7,285 |  |
| Commitments and contingencies |  |  |  |
| Stockholders’ equity | 98,371 |  |  | 104,235 |  |
| Total liabilities and stockholders’ equity | $ | 393,487 |  |  | $ | 428,660 |  |

[0001078271-15-000125:8k_2_02:43]
EXTREME NETWORKS, INC.

[0001078271-15-000125:8k_2_02:44]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS

[0001078271-15-000125:8k_2_02:45]
(In thousands, except per share amounts)

[0001078271-15-000125:8k_2_02:46]
(Unaudited)

[0001078271-15-000125:8k_2_02:47]
|  | Three Months Ended |
|  | September 30, 2015 |  | September 30, 2014 |
| Net revenues: |  |  |  |
| Product | $ | 91,381 |  |  | $ | 102,672 |  |
| Service | 33,200 |  |  | 33,602 |  |
| Total net revenues | 124,581 |  |  | 136,274 |  |
| Cost of revenues: |  |  |  |
| Product | 46,934 |  |  | 54,025 |  |
| Service | 12,529 |  |  | 11,722 |  |
| Total cost of revenues | 59,463 |  |  | 65,747 |  |
| Gross profit: |  |  |  |
| Product | 44,447 |  |  | 48,647 |  |
| Service | 20,671 |  |  | 21,880 |  |
| Total gross profit | 65,118 |  |  | 70,527 |  |
| Operating expenses: |  |  |  |
| Research and development | 20,268 |  |  | 23,347 |  |
| Sales and marketing | 36,062 |  |  | 44,779 |  |
| General and administrative | 9,176 |  |  | 11,074 |  |
| Acquisition and integration costs | 338 |  |  | 4,058 |  |
| Restructuring charge, net of reversals | 5,603 |  |  | — |  |
| Amortization of intangibles | 4,467 |  |  | 4,467 |  |
| Total operating expenses | 75,914 |  |  | 87,725 |  |
| Operating loss | (10,796 | ) |  | (17,198 | ) |
| Interest income | 27 |  |  | 146 |  |
| Interest expense | (826 | ) |  | (836 | ) |
| Other expense, net | 967 |  |  | (434 | ) |
| Loss before income taxes | (10,628 | ) |  | (18,322 | ) |
| Provision for income taxes | 898 |  |  | 1,008 |  |
| Net loss | $ | (11,526 | ) |  | $ | (19,330 | ) |
| Basic and diluted net loss per share: |  |  |  |
| Net loss per share - basic | $ | (0.11 | ) |  | $ | (0.20 | ) |
| Net loss per share - diluted | $ | (0.11 | ) |  | $ | (0.20 | ) |
| Shares used in per share calculation - basic | 100,985 |  |  | 97,314 |  |
| Shares used in per share calculation - diluted | 100,985 |  |  | 97,314 |  |

[0001078271-15-000125:8k_2_02:48]
=

[0001078271-15-000125:8k_2_02:49]
EXTREME NETWORKS, INC.

[0001078271-15-000125:8k_2_02:50]
CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS

[0001078271-15-000125:8k_2_02:51]
(In thousands)

[0001078271-15-000125:8k_2_02:52]
(Unaudited)

[0001078271-15-000125:8k_2_02:53]
|  | Three Months Ended |
|  | September 30, 2015 |  | September 30, 2014 |
| Net cash provided by operating activities | $ | 6,526 |  |  | $ | 1,632 |  |
| Cash flows from investing activities: |  |  |  |
| Capital expenditures | (633 | ) |  | (2,784 | ) |
| Purchases of investments | — |  |  | 2,000 |  |
| Purchases of intangible assets | — |  |  | (252 | ) |
| Net cash used in investing activities | (633 | ) |  | (1,036 | ) |
| Cash flows from financing activities: |  |  |  |
| Borrowings under Revolving Facility | — |  |  | 24,000 |  |
| Repayment of debt | (1,625 | ) |  | (24,813 | ) |
| Proceeds from issuance of common stock | 1,855 |  |  | 1,738 |  |
| Net cash provided by financing activities | 230 |  |  | 925 |  |
| Foreign currency effect on cash | (323 | ) |  | (644 | ) |
| Net increase in cash and cash equivalents | 5,800 |  |  | 877 |  |
| Cash and cash equivalents at beginning of period | 76,225 |  |  | 73,190 |  |
| Cash and cash equivalents at end of period | $ | 82,025 |  |  | $ | 74,067 |  |

[0001078271-15-000125:8k_2_02:54]
Extreme Networks, Inc.

[0001078271-15-000125:8k_2_02:55]
Non-GAAP Measures of Financial Performance

[0001078271-15-000125:8k_2_02:56]
To supplement the Company's consolidated financial statements presented in accordance with generally accepted accounting principles, ("GAAP"), Extreme Networks uses non-GAAP measures of certain components of financial performance.  These non-GAAP measures include non-GAAP net income, non-GAAP earnings per diluted share, non-GAAP gross margin, non-GAAP operating expenses and free cash flow.

[0001078271-15-000125:8k_2_02:57]
Reconciliation to the nearest GAAP measure of all historical non-GAAP measures included in this press release can be found in the tables included with this press release.  In this press release, Extreme Networks also presents its target for non-GAAP expenses, which is expenses less stock based compensation expense, acquisition and integration costs, purchase accounting adjustments, amortization of intangibles, restructuring expenses and overhead adjustments.

[0001078271-15-000125:8k_2_02:58]
Non-GAAP measures presented in this press release are not in accordance with or alternative measures prepared in accordance with GAAP and may be different from non-GAAP measures used by other companies.  In addition, these non-GAAP measures are not based on any comprehensive set of accounting rules or principles.  Non-GAAP measures have limitations in that they do not reflect all of the amounts associated with Extreme Networks' results of operations as determined in accordance with GAAP.  These non-GAAP measures should only be used to evaluate Extreme Networks' results of operations in conjunction with the corresponding GAAP measures.

[0001078271-15-000125:8k_2_02:59]
Extreme Networks believes that these non-GAAP measures when shown in conjunction with the corresponding GAAP measures enhance investors' and management's overall understanding of the Company's current financial performance and the Company's prospects for the future, including cash flows available to pursue opportunities to enhance shareholder value.  In addition, because Extreme Networks has historically reported certain non-GAAP results to investors, the Company believes that the inclusion of non-GAAP measures provides consistency in the Company's financial reporting.

[0001078271-15-000125:8k_2_02:60]
For its internal planning process, and as discussed further below, Extreme Networks' management uses financial statements that do not include stock-based compensation expense, acquisition and integration costs, purchase accounting adjustments, amortization of  intangibles, restructuring expenses and overhead adjustments.  Extreme Networks' management also uses non-GAAP measures, in addition to the corresponding GAAP measures, in reviewing the Company's financial results.

[0001078271-15-000125:8k_2_02:61]
As described above, Extreme Networks excludes the following items from one or more of its non-GAAP measures when applicable.

[0001078271-15-000125:8k_2_02:62]
Stock based compensation expense. This expense consists of expenses for stock options, restricted stock and employee stock purchases through its ESPP.  Extreme Networks excludes stock based compensation expenses from its non-GAAP measures primarily because they are non-cash expenses that the Company does not believe are reflective of ongoing cash requirement related to operating results. Extreme Networks expects to incur stock-based compensation expenses in future periods.

[0001078271-15-000125:8k_2_02:63]
Acquisition and integration costs. Acquisition and integration costs primarily consist of legal and professional fees, severance costs, and other expenses related to the acquisition and integration of Enterasys Inc.  Extreme Networks excludes these expenses since they result from an event that is outside the ordinary course of continuing operations.

[0001078271-15-000125:8k_2_02:64]
Amortization of intangibles.  Amortization of intangibles includes the monthly amortization expense of acquired intangible assets such as developed technology, customer relationships, trademarks and order backlog.  The amortization of the developed technology intangible is recorded in product cost of goods sold, while the amortization for the other intangibles are recorded in operating expenses.  Extreme Networks excludes these non-cash expenses since they result from an intangible asset and for which the period expense does not impact the operations of the business.

[0001078271-15-000125:8k_2_02:65]
Purchase accounting adjustments relating to deferred revenue.  Purchase accounting adjustments relating to deferred revenue consists of adjustments to the carrying value of deferred revenue.  We have recorded adjustments to the assumed deferred revenue to reflect only a fulfillment margin and thereby excluding the profit margin and revenue which would have been incurred had Extreme Networks entered into the service contract post-acquisition.

[0001078271-15-000125:8k_2_02:66]
Restructuring expenses. Restructuring expenses primarily consists of cash severance and termination benefits. Extreme Networks excludes restructuring expenses since they result from events that often occur outside of the ordinary course of continuing operations. Extreme Networks expects to incur restructuring expenses in future periods.

[0001078271-15-000125:8k_2_02:67]
In addition to the non-GAAP measures discussed above, Extreme Networks uses free cash flow as a measure of operating performance.  Free cash flow represents operating cash flows less net purchase of property and equipment on a GAAP basis.  Extreme Networks considers free cash flows to be a liquidity measure that provides useful information to management and investors about the amount of cash generated by the business after the purchases of property and equipment, which can then be used to, among other things, invest in Extreme Networks business, make strategic acquisitions, and strengthen the balance sheet.  A limitation of the utility of free cash flows as a measure of financial performance is that it does not represent the total increase or decrease in the Company's cash balance for the period.

[0001078271-15-000125:8k_2_02:68]
EXTREME NETWORKS, INC.

[0001078271-15-000125:8k_2_02:69]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS

[0001078271-15-000125:8k_2_02:70]
GAAP TO NON-GAAP RECONCILIATION

[0001078271-15-000125:8k_2_02:71]
(In thousands, except per share amounts)

[0001078271-15-000125:8k_2_02:72]
(Unaudited)

[0001078271-15-000125:8k_2_02:73]
| Non-GAAP Revenue | Three Months Ended |
|  | September 30, 2015 |  | September 30, 2014 |
| Revenue - GAAP Basis | $ | 124,581 |  |  | $ | 136,274 |  |
| Adjustments: |  |  |  |
| Purchase accounting adjustments | 377 |  |  | 766 |  |
| Revenue - Non-GAAP Basis | $ | 124,958 |  |  | $ | 137,040 |  |
| Non-GAAP Gross Margin | Three Months Ended |
|  | September 30, 2015 |  | September 30, 2014 |
| Gross profit - GAAP Basis | $ | 65,118 |  |  | $ | 70,527 |  |
| Gross margin - GAAP Basis percentage | 52.3 | % |  | 51.8 | % |
| Adjustments: |  |  |  |
| Stock based compensation expense | 663 |  |  | 574 |  |
| Purchase accounting adjustments | 377 |  |  | 766 |  |
| Amortization of intangibles | 4,292 |  |  | 4,292 |  |
| Service inventory overhead capitalization | (1,493 | ) |  | — |  |
| Gross profit - Non-GAAP Basis | $ | 68,957 |  |  | $ | 76,159 |  |
| Gross margin - Non-GAAP Basis percentage | 55.2 | % |  | 55.6 | % |
| Non-GAAP Operating Income | Three Months Ended |
|  | September 30, 2015 |  | September 30, 2014 |
| GAAP operating loss | $ | (10,796 | ) |  | $ | (17,198 | ) |
| GAAP operating loss income percentage | (8.7 | )% |  | (12.6 | )% |
| Adjustments: |  |  |  |
| Stock based compensation expense | 4,671 |  |  | 4,813 |  |
| Acquisition and integration costs | 338 |  |  | 4,058 |  |
| Restructuring charge, net of reversal | 5,603 |  |  | — |  |
| Amortization of intangibles | 8,759 |  |  | 8,759 |  |
| Purchase accounting adjustments | 377 |  |  | 766 |  |
| Service inventory overhead capitalization | (1,493 | ) |  | — |  |
| Total adjustments to GAAP operating income | $ | 18,255 |  |  | $ | 18,396 |  |
| Non-GAAP operating income | $ | 7,459 |  |  | $ | 1,198 |  |
| Non-GAAP operating income percentage | 6.0 | % |  | 0.9 | % |

[0001078271-15-000125:8k_2_02:74]
| Non-GAAP Net Income | Three Months Ended |
|  | September 30, 2015 |  | September 30, 2014 |
| GAAP net loss | $ | (11,526 | ) |  | $ | (19,330 | ) |
| Adjustments: |  |  |  |
| Stock based compensation expense | 4,671 |  |  | 4,813 |  |
| Acquisition and integration costs | 338 |  |  | 4,058 |  |
| Restructuring charge, net of reversal | 5,603 |  |  | — |  |
| Amortization of intangibles | 8,759 |  |  | 8,759 |  |
| Purchase accounting adjustments | 377 |  |  | 766 |  |
| Service inventory overhead capitalization | (1,493 | ) |  | — |  |
| Total adjustments to GAAP net income | $ | 18,255 |  |  | $ | 18,396 |  |
| Non-GAAP net income (loss) | $ | 6,729 |  |  | $ | (934 | ) |
| Earnings per share |  |  |  |
| Non-GAAP diluted net income (loss) per share | $ | 0.07 |  |  | $ | (0.01 | ) |
| Shares used in diluted net income (loss) per share calculation | 103,195 |  |  | 97,314 |  |
| Free Cash Flow | Three Months Ended |
|  | September 30, 2015 |  | September 30, 2014 |
| Cash flow provided by operations | $ | 6,526 |  |  | $ | 1,632 |  |
| Less: PP&E CapEx spending | (633 | ) |  | (2,784 | ) |
| Total free cash flow | $ | 5,893 |  |  | $ | (1,152 | ) |
