# EXTR notes — 0001078271-12-000073


## us-gaap:AvailableForSaleSecuritiesContinuousUnrealizedLossPositionFairValueTableTextBlock

[0001078271-12-000073:notes:1]
The following table presents the Company’s investments’ gross unrealized losses and fair values, aggregated by investment category and length of time that individual securities have been in a continuous unrealized loss position.

[0001078271-12-000073:notes:2]
|  | Less than 12 months |  | 12 months or more |  | Total |
|  | Fair Value |  | UnrealizedLosses |  | Fair Value |  | UnrealizedLosses |  | Fair Value |  | UnrealizedLosses |
| September 30, 2012 |  |  |  |  |  |  |  |  |  |  |  |
| U.S. corporate debt securities | $ | 5,111 |  |  | $ | (6 | ) |  | $ | — |  |  | $ | — |  |  | $ | 5,111 |  |  | $ | (6 | ) |
| U.S. government agency securities | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| U.S. municipal bonds | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
|  | $ | 5,111 |  |  | $ | (6 | ) |  | $ | — |  |  | $ | — |  |  | $ | 5,111 |  |  | $ | (6 | ) |


## us-gaap:AvailableForSaleSecuritiesTextBlock

[0001078271-12-000073:notes:3]
Available-for-Sale Securities

[0001078271-12-000073:notes:4]
The following is a summary of available-for-sale securities (in thousands):

[0001078271-12-000073:notes:5]
|  | AmortizedCost |  | Fair Value |  | UnrealizedHoldingGains |  | UnrealizedHoldingLosses |
| September 30, 2012 |  |  |  |  |  |  |  |
| Money market funds | $ | 71,580 |  |  | $ | 71,580 |  |  | $ | — |  |  | $ | — |  |
| U.S. corporate debt securities | 91,537 |  |  | 91,883 |  |  | 352 |  |  | (6 | ) |
| U.S. government agency securities | 11,251 |  |  | 11,256 |  |  | 5 |  |  | — |  |
| U.S. municipal bonds | 2,743 |  |  | 2,753 |  |  | 10 |  |  | — |  |
|  | $ | 177,111 |  |  | $ | 177,472 |  |  | $ | 367 |  |  | $ | (6 | ) |
| Classified as: |  |  |  |  |  |  |  |
| Cash equivalents | $ | 71,580 |  |  | $ | 71,580 |  |  | $ | — |  |  | $ | — |  |
| Short-term investments | 40,701 |  |  | 40,827 |  |  | 126 |  |  | — |  |
| Marketable securities | 64,830 |  |  | 65,065 |  |  | 241 |  |  | (6 | ) |
|  | $ | 177,111 |  |  | $ | 177,472 |  |  | $ | 367 |  |  | $ | (6 | ) |
| June 30, 2012 |  |  |  |  |  |  |  |
| Money market funds | $ | 36,141 |  |  | $ | 36,141 |  |  | $ | — |  |  | $ | — |  |
| U.S. corporate debt securities | 84,882 |  |  | 84,949 |  |  | 148 |  |  | (81 | ) |
| U.S. government agency securities | 11,241 |  |  | 11,234 |  |  | 3 |  |  | (10 | ) |
| U.S. municipal bonds | 2,738 |  |  | 2,736 |  |  | — |  |  | (2 | ) |
|  | $ | 135,002 |  |  | $ | 135,060 |  |  | $ | 151 |  |  | $ | (93 | ) |
| Classified as: |  |  |  |  |  |  |  |
| Cash equivalents | $ | 36,141 |  |  | $ | 36,141 |  |  | $ | — |  |  | $ | — |  |
| Short-term investments | 23,311 |  |  | 23,358 |  |  | 48 |  |  | (1 | ) |
| Marketable securities | 75,550 |  |  | 75,561 |  |  | 103 |  |  | (92 | ) |
|  | $ | 135,002 |  |  | $ | 135,060 |  |  | $ | 151 |  |  | $ | (93 | ) |

[0001078271-12-000073:notes:6]
The amortized cost and estimated fair value of available-for-sale investments in debt securities at September 30, 2012, by contractual maturity, were as follows (in thousands):

[0001078271-12-000073:notes:7]
|  | AmortizedCost |  | FairValue |
| Due in 1 year or less | $ | 40,701 |  |  | $ | 40,828 |  |
| Due in 1-2 years | 35,353 |  |  | 35,443 |  |
| Due in 2-5 years | 29,477 |  |  | 29,621 |  |
| Due in more than 5 years | — |  |  | — |  |
| Total investments in available for sale debt securities | $ | 105,531 |  |  | $ | 105,892 |  |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001078271-12-000073:notes:8]
Commitments and Contingencies

[0001078271-12-000073:notes:9]
Purchase Commitments

[0001078271-12-000073:notes:10]
The Company currently has arrangements with contract manufacturers and suppliers for the manufacture of its products. The arrangements allow them to procure long lead-time component inventory based upon a rolling production forecast provided by the Company. The Company is obligated to the purchase of long lead-time component inventory that its contract manufacturer procures in accordance with the forecast, unless the Company gives notice of order cancellation outside of applicable component lead-times. As of September 30, 2012, the Company had non-cancelable commitments to purchase approximately $31.1 million of such inventory.

[0001078271-12-000073:notes:11]
Legal Proceedings

[0001078271-12-000073:notes:12]
The Company may from time to time be party to litigation arising in the course of its business, including, without limitation, allegations relating to commercial transactions, business relationships or intellectual property rights. Such claims, even if not meritorious, could result in the expenditure of significant financial and managerial resources. Litigation in general, and intellectual property and securities litigation in particular, can be expensive and disruptive to normal business operations. Moreover, the results of legal proceedings are difficult to predict.

[0001078271-12-000073:notes:13]
In accordance with applicable accounting guidance, the Company records accruals for certain of its outstanding legal proceedings, investigations or claims when it is probable that a liability will be incurred and the amount of loss can be reasonably estimated. The Company evaluates, at least on a quarterly basis, developments in legal proceedings, investigations or claims that could affect the amount of any accrual, as well as any developments that would result in a loss contingency to become both probable and reasonably estimable. When a loss contingency is not both probable and reasonably estimable, the Company does not record a loss accrual.  However, if the loss (or an additional loss in excess of any prior accrual) is at least a reasonable possibility and material, then the Company would disclose an estimate of the possible loss or range of loss, if such estimate can be made, or disclose that an estimate cannot be made. The assessment whether a loss is probable or a reasonable possibility, and whether the loss or a range of loss is estimable, involves a series of complex judgments about future events. Even if a loss is reasonably possible, the Company may not be able to estimate a range of possible loss, particularly where (i) the damages sought are substantial or indeterminate, (ii) the proceedings are in the early stages, or (iii) the matters involve novel or unsettled legal theories or a large number of parties. In such cases, there is considerable uncertainty regarding the ultimate resolution of such matters, including the amount of any possible loss, fine or penalty.  Accordingly, for current proceedings, the Company is currently unable to estimate any reasonably possible loss or range of possible loss.  However, an adverse resolution of one or more of such matters could have a material adverse effect on the Company's results of operations in a particular quarter or fiscal year.

[0001078271-12-000073:notes:14]
Intellectual Property Litigation

[0001078271-12-000073:notes:15]
Enterasys Networks

[0001078271-12-000073:notes:16]
On April 20, 2007, the Company filed suit against Enterasys Networks in the United States District Court for the Western District of Wisconsin, Civil Action No. 07-C-0229-C. The complaint alleged willful infringement of U.S. Patents Nos. 6,104,700, 6,678,248, and 6,859,438, and sought injunctive relief against Enterasys' continuing sale of infringing goods and monetary damages. Enterasys responded to the complaint on May 30, 2007, and also filed counterclaims alleging infringement of three U.S. patents owned by Enterasys. On April 9, 2008, the Court dismissed Enterasys' counterclaims on one of its patents with prejudice. On May 5, 2008, the Court granted the Company's motion for summary judgment, finding that it does not infringe Enterasys' two remaining patents and dismissing all of Enterasys' remaining counterclaims with prejudice. On May 30, 2008, a jury found that Enterasys infringed all three of the Company's patents and awarded it damages in the amount of $0.2 million. The Court also ruled in the Company's favor on Enterasys' challenge to the validity of the Company's patents. On October 29, 2008, the Court denied Enterasys' post-trial motion for judgment as a matter of law, and granted Extreme Network's motion for a permanent injunction against Enterasys. The injunction order permanently enjoins Enterasys from manufacturing, using, offering to sell, selling in the U.S. and importing into the U.S. the Enterasys products accused of infringing Extreme Network's three patents. On March 16, 2009, the Court also denied Enterasys' motion for a new trial, but granted Enterasys' motion for a stay of the injunction pending appeal. On April 17, 2009, Enterasys filed its notice of appeal and on May 1, 2009, the Company filed its cross appeal. On September 30, 2010, the U.S. Court of Appeals for the Federal Circuit upheld the jury verdict of infringement by Enterasys of the Company's patents and the Districts Court's summary judgment of non-infringement by the Company of Enterasys' '727 patent. The Federal Circuit reversed the judgment of non-infringement by the Company of Enterasys '181 patent, holding that the District Court Judge applied an incorrect claim construction and reversed the District Court's denial of the Company's request for attorneys' fees as premature.  On November 4, 2011, a jury returned a verdict of non-infringement by the Company of the '181 patent and found the patent to be valid. Both parties filed post-trial motions, including motions for a new trial, for judgment as a matter of law and for attorneys fees, all of which the Court denied on July 11, 2012. Enterasys did not file a notice of appeal by the August 10, 2012 deadline.  Consequently, the judgment of non-infringement in favor of the Company in the second trial is final. During the fourth quarter of fiscal 2012, Enterasys paid the Company $0.6 million related to the judgment.  Of this amount, $0.2 million was for damages and interest and $0.4 million was reimbursement of costs from the first trial.

[0001078271-12-000073:notes:17]
On June 21, 2005, Enterasys filed suit against Extreme and Foundry Networks, Inc. (“Foundry”) in the United States District Court for the District of Massachusetts, Civil Action No. 05-11298 DPW. The complaint alleges willful infringement of U.S. Patent Nos. 5,251,205; 5,390,173; 6,128,665; 6,147,995; 6,539,022; and 6,560,236, and seeks: a) a judgment that the Company willfully infringes each of the patents; (b) a permanent injunction from infringement, inducement of infringement and contributory infringement of each of the six patents; (c) damages and a “reasonable royalty” to be determined at trial; (d) treble damages; (e) attorneys' fees, costs and interest; and (f) equitable relief at the Court's discretion. Petitions for reexamination were filed challenging five of the patents at issue to the U.S. Patent and Trademark Office, and a stay of the case was entered. Following the reexamination proceedings, Enterasys withdrew its allegations of infringement as to two of the patents, U.S. Patent Nos. 6,539,022 and 6,560,236. The stay was lifted on May 21, 2010, and the Court held claim construction hearings in December 2010. Fact discovery is ongoing. No trial date has been set. The Company intends to defend the lawsuit vigorously, but, due to the inherent uncertainties of litigation, it cannot predict the ultimate outcome of the matter at this time.

[0001078271-12-000073:notes:18]
Chrimar Systems

[0001078271-12-000073:notes:19]
On October 31, 2011, Chrimar Systems, Inc. dba CMS Technologies, and Chrimar Holding Company filed suit against the Company, Cisco Systems, Inc., and Cisco Consumer Products LLC. Cisco-Linksys LLC, Hewlett-Packard Company, 3Com Corporation and Avaya, Inc. in the United States District Court for the District of Delaware, Civil Action No. 11-1050 (the "Delaware action").  The complaint alleges infringement of U.S. Patent No. 7,457,250.   The Delaware action has been stayed pursuant to 28 USC Section 1659(a) pending final determination of the International Trade Commission action described below, based on the fact that the allegations in both cases relate to the same patent.

[0001078271-12-000073:notes:20]
On November 1, 2011, Chrimar filed a complaint with the International Trade Commission, pursuant to Section 337 of the Tariff Act of 1930, as amended, alleging that the Company imports into the United States, sells for importation and/or sells within the United States after importation of products and/or systems infringing U.S. Patent No. 7,457,250 patent, the same patent asserted in the Delaware action.  On December 2, 2011, the International Trade Commission instituted an investigation of these allegations (the "ITC action").  The complaint in the ITC action seeks a permanent order excluding from entry into the United States all infringing articles that are manufactured, imported or sold by the Company that infringe U.S. Patent No. 7,457,250. On July 20, 2012, Chrimar filed a motion to withdraw its complaint in the ITC and the motion was granted on August 1, 2012 by the presiding administrative law judge.  The ALJ's decision is pending review by the ITC Commissioners.

[0001078271-12-000073:notes:21]
During the fourth quarter of the fiscal 2012, the Company engaged in settlement discussions with Chrimar Systems Inc.  As part of the negotiations the Company determined that it is reasonably possible that a range of loss could be between $0.3 million and $1.4 million which is dependent on a number of factors including whether mutually acceptable settlement terms can be reached. This matter was still pending as of September 30, 2012.

[0001078271-12-000073:notes:22]
Reefedge Networks

[0001078271-12-000073:notes:23]
On September 17, 2012, Reefedge Networks, LLC filed suit against the Company in the United States District Court for the District of Delaware, Civil Action No. 12-1148. The complaint alleges wrongful use, making, selling, and/or offering to sell products that infringe U.S. Patent Nos. 6,633.761; 6,975,864; and 7,197,308 and seeks unspecified monetary damages and a permanent injunction for products originating from a single supplier to which the Company has submitted an indemnification request. Given the preliminary nature of the claims, it is premature to assess the likelihood of a particular outcome.  No answer has been filed, and the Company plans to vigorously defend itself.

[0001078271-12-000073:notes:24]
Indemnification Obligations

[0001078271-12-000073:notes:25]
Subject to certain limitations, the Company may be obligated to indemnify its current and former directors, officers and employees. These obligations arise under the terms of its certificate of incorporation, its bylaws, applicable contracts, and Delaware and California law. The obligation to indemnify, where applicable, generally means that the Company is required to pay or reimburse, and in certain circumstances the Company has paid or reimbursed, the individuals' reasonable legal expenses and possibly damages and other liabilities incurred in connection with these matters. It is not possible to estimate the maximum potential amount under these indemnification agreements due to the limited history of these claims. The cost to defend the Company and the named individuals could have a material adverse effect on its consolidated financial position, results of operations and cash flows in the future. Recovery of such costs under its directors and officers insurance coverage is uncertain.


## us-gaap:DeferredRevenueByArrangementDisclosureTextBlock

[0001078271-12-000073:notes:26]
The following table summarizes deferred revenue, net at September 30, 2012 and June 30, 2012, respectively (in thousands):

[0001078271-12-000073:notes:27]
|  | September 30, 2012 |  | June 30, 2012 |
| Deferred services | $ | 35,863 |  |  | $ | 37,708 |  |
| Deferred product: |  |  |  |
| Deferred revenue | 1,798 |  |  | 2,236 |  |
| Deferred cost of sales | (370 | ) |  | (616 | ) |
| Deferred product revenue, net | 1,428 |  |  | 1,620 |  |
| Balance at end of period | 37,291 |  |  | 39,328 |  |
| Less: current portion | 30,007 |  |  | 31,769 |  |
| Non-current deferred revenue, net | $ | 7,284 |  |  | $ | 7,559 |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001078271-12-000073:notes:28]
[same as prior period, unchanged from 0001078271-12-000025:notes:22]

[0001078271-12-000073:notes:29]
The Company uses derivative financial instruments to manage exposures to foreign currency. The Company’s objective for holding derivatives is to use the most effective methods to minimize the impact of these exposures. The Company does not enter into derivatives for speculative or trading purposes. The Company records all derivatives on the balance sheet as Other Assets, Net at fair value. Changes in the fair value of derivatives are recognized in earnings as Other Income (Expense). The Company enters into foreign exchange forward contracts to mitigate the effect of gains and losses generated by the foreign currency forecasted transactions related to certain operating expenses and re-measurement of certain assets and liabilities denominated in Japanese Yen, the Euro, the Swedish Krona, the Indian Rupee and the British Pound. These derivatives do not qualify as hedges. At September 30, 2012, these forward foreign currency contracts had a notional principal amount of $12.0 million and an immaterial unrealized loss on foreign exchange contracts. These contracts have maturities of less than 60 days. Changes in the fair value of these foreign exchange forward contracts are offset largely by re-measurement of the underlying assets and liabilities.

[0001078271-12-000073:notes:30]
Foreign currency transaction gains and losses from operations were a loss of $0.3 million for the three months ended September 30, 2012, and an immaterial gain for the three months ended October 2, 2011.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001078271-12-000073:notes:31]
Share-based Compensation

[0001078271-12-000073:notes:32]
Share-based compensation expense recognized in the condensed consolidated financial statements by line item caption is as follows (in thousands):

[0001078271-12-000073:notes:33]
|  | Three Months Ended |
|  | September 30, 2012 |  | October 2, 2011 |
| Cost of product revenue | $ | 174 |  |  | $ | 156 |  |
| Cost of service revenue | 159 |  |  | 114 |  |
| Research and development | 432 |  |  | 472 |  |
| Sales and marketing | 727 |  |  | 496 |  |
| General and administrative | 676 |  |  | 657 |  |
| Total share-based compensation expense | $ | 2,168 |  |  | $ | 1,895 |  |

[0001078271-12-000073:notes:34]
During the three months ended September 30, 2012 and October 2, 2011, the Company did not capitalize any stock-based compensation expense in inventory, as the amounts were immaterial. The income tax benefit for share-based compensation expense was immaterial in each of the three months ended September 30, 2012 and October 2, 2011.

[0001078271-12-000073:notes:35]
The weighted-average grant-date per share fair value of options granted during the three months ended September 30, 2012 and October 2, 2011 were $1.85 and $1.66, respectively. The weighted-average estimated per share fair value of shares purchased under the Company’s 1999 Employee Stock Purchase Plan (“ESPP”) during the three months ended September 30, 2012 and October 2, 2011 were $0.87 and $0.96, respectively.

[0001078271-12-000073:notes:36]
The following table summarizes stock option activity under all plans for the three months ended September 30, 2012:

[0001078271-12-000073:notes:37]
|  | Number ofShares(000’s) |  | Weighted-AverageExercise PricePer Share |  | Weighted-AverageRemainingContractualTerm (years) |  | AggregateIntrinsic Value(000’s) |
| Options outstanding at June 30, 2012 | 9,006 |  |  | $ | 3.68 |  |  |  |  |  |
| Granted | 779 |  |  | $ | 3.41 |  |  |  |  |  |
| Exercised | (202 | ) |  | $ | 2.94 |  |  |  |  | $ | 120 |  |
| Canceled | (461 | ) |  | $ | 3.78 |  |  |  |  |  |
| Options outstanding at September 30, 2012 | 9,122 |  |  | $ | 3.67 |  |  | 4.95 |  |  | $ | 1,752 |  |
| Exercisable at September 30, 2012 | 5,672 |  |  | $ | 3.88 |  |  | 4.34 |  |  | $ | 1,412 |  |
| Vested and expected to vest at September 30, 2012 | 8,803 |  |  | $ | 3.68 |  |  | 4.90 |  |  | $ | 1,733 |  |

[0001078271-12-000073:notes:38]
Stock Awards

[0001078271-12-000073:notes:39]
Stock awards may be granted under the 2005 Plan on terms approved by the Board of Directors. Stock awards generally provide for the issuance of restricted stock which vests over a fixed period.

[0001078271-12-000073:notes:40]
The following table summarizes stock award activity for the three months ended September 30, 2012:

[0001078271-12-000073:notes:41]
|  | Number ofShares(000’s) |  | Weighted-Average Grant-Date Fair Value |  | Aggregate Fair Market Value ($000's) |
| Non-vested stock outstanding at June 30, 2012 | 1,078 |  |  | $ | 2.35 |  |  |  |
| Granted | 832 |  |  | $ | 3.32 |  |  |  |
| Vested | (450 | ) |  | $ | 3.31 |  |  | $ | 1,488 |  |
| Cancelled | (40 | ) |  | $ | 3.19 |  |  |  |
| Non-vested stock outstanding at September 30, 2012 | 1,420 |  |  | $ | 2.59 |  |  |  |

[0001078271-12-000073:notes:42]
The fair value of each option award and share purchase option under the Company's ESPP is estimated on the date of grant using the Black-Scholes-Merton option valuation model with the weighted average assumptions noted in the following table. The expected term of options granted is derived from historical data on employee exercise and post-vesting employment termination behavior. The expected term of ESPP represents the contractual life of the ESPP purchase period. The risk-free rate based upon the estimated life of the option and ESPP is based on the U.S. Treasury yield curve in effect at the time of grant. Expected volatility is based on both the implied volatilities from traded options on the Company’s stock and historical volatility on the Company’s stock.

[0001078271-12-000073:notes:43]
|  | Stock Option Plan |  | Employee Stock Purchase Plan |
|  | Three Months Ended |  | Three Months Ended |
|  | September 30, 2012 |  | October 2, 2011 |  | September 30, 2012 |  | October 2, 2011 |
| Expected life | 5 yrs |  |  | 5 yrs |  |  | 0.25 yrs |  |  | 0.25 yrs |  |
| Risk-free interest rate | 0.90 | % |  | 1.09 | % |  | 0.06 | % |  | 0.04 | % |
| Volatility | 66 | % |  | 59 | % |  | 69 | % |  | 62 | % |
| Dividend yield | 0.0 | % |  | 0.0 | % |  | 0.0 | % |  | 0.0 | % |

[0001078271-12-000073:notes:44]
[same as prior period, unchanged from 0001078271-12-000025:notes:37]


## us-gaap:EarningsPerSharePolicyTextBlock

[0001078271-12-000073:notes:45]
Basic earnings per share is calculated by dividing net income by the weighted average number of common shares outstanding during the period, less shares subject to repurchase, and excludes any dilutive effects of options, warrants and unvested restricted stock. Dilutive earnings per share is calculated by dividing net income by the weighted average number of common shares used in the basic earnings per share calculation plus the dilutive effect of shares subject to repurchase, options, warrants and unvested restricted stock.

[0001078271-12-000073:notes:46]
Potentially dilutive common shares from employee incentive plans are determined by applying the treasury stock method to the assumed exercise of outstanding stock options, the assumed vesting of outstanding restricted stock units, and the assumed issuance of common stock under the stock purchase plan. Weighted stock options outstanding with an exercise price higher than the Company's average stock price for the periods presented are excluded from the calculation of diluted net income per share since the effect of including them would have been anti-dilutive due to the net income position of the Company during the periods presented.


## us-gaap:EarningsPerShareTextBlock

[0001078271-12-000073:notes:47]
Net Income Per Share

[0001078271-12-000073:notes:48]
Basic earnings per share is calculated by dividing net income by the weighted average number of common shares outstanding during the period, less shares subject to repurchase, and excludes any dilutive effects of options, warrants and unvested restricted stock. Dilutive earnings per share is calculated by dividing net income by the weighted average number of common shares used in the basic earnings per share calculation plus the dilutive effect of shares subject to repurchase, options, warrants and unvested restricted stock. The following table presents the calculation of basic and diluted net income per share (in thousands, except per share data):

[0001078271-12-000073:notes:49]
|  | Three Months Ended |
|  | September 30, 2012 |  | October 2, 2011 |
| Net income | $ | 12,915 |  |  | $ | 1,583 |  |
| Weighted-average shares used in per share calculation – basic | 94,738 |  |  | 92,768 |  |
| Incremental shares using the treasury stock method: |  |  |  |
| Stock options | 356 |  |  | 316 |  |
| Restricted stock units | 294 |  |  | 820 |  |
| Employee Stock Purchase Plan | 111 |  |  | 151 |  |
| Weighted -average share used in per share calculation – diluted | 95,499 |  |  | 94,055 |  |
| Net income per share – basic | 0.14 |  |  | 0.02 |  |
| Net income per share – diluted | 0.14 |  |  | 0.02 |  |

[0001078271-12-000073:notes:50]
Potentially dilutive common shares from employee incentive plans are determined by applying the treasury stock method to the assumed exercise of outstanding stock options, the assumed vesting of outstanding restricted stock units, and the assumed issuance of common stock under the stock purchase plan. Weighted stock options outstanding with an exercise price higher than the Company's average stock price for the periods presented are excluded from the calculation of diluted net income per share since the effect of including them would have been anti-dilutive due to the net income position of the Company during the periods presented. For the three months ended September 30, 2012 and October 2, 2011, the Company excluded 7.1 million and 8.7 million outstanding weighted average stock options, respectively, from the calculation of diluted earnings per common share because they would have been anti-dilutive.


## us-gaap:FairValueDisclosuresTextBlock

[0001078271-12-000073:notes:51]
Fair Value Measurements

[0001078271-12-000073:notes:52]
The Company measures certain financial assets and liabilities at fair value on a recurring basis, including cash equivalents, available-for-sale securities, trading securities and foreign currency derivatives. Fair value is measured based on a fair value hierarchy following three levels of inputs, of which the first two are considered observable and the last unobservable:

[0001078271-12-000073:notes:53]
| • Level 1 |  |  | Quoted prices in active markets for identical assets or liabilities; |
| • Level 2 |  |  | Inputs other than Level 1 that are observable, either directly or indirectly, such as quoted prices for similar assets or liabilities; quoted prices in markets that are not active; or other inputs that are observable or can be corroborated by observable market data for substantially the full term of the assets or liabilities; and |
| • Level 3 |  |  | Unobservable inputs that are supported by little or no market activity and that are significant to the fair value of the assets or liabilities. |

[0001078271-12-000073:notes:54]
The following table presents the Company’s fair value hierarchy for its financial assets and liabilities measured at fair value on a recurring basis:

[0001078271-12-000073:notes:55]
| September 30, 2012 | Level 1 |  | Level 2 |  | Level 3 |  | Total |
|  | (In thousands) |
| Assets |  |  |  |  |  |  |  |
| Investments: |  |  |  |  |  |  |  |
| Municipal bonds | $ | — |  |  | $ | 2,753 |  |  | $ | — |  |  | $ | 2,753 |  |
| Federal agency notes | — |  |  | 11,256 |  |  | — |  |  | 11,256 |  |
| Money market funds | 71,580 |  |  | — |  |  | — |  |  | 71,580 |  |
| Corporate notes/bonds | — |  |  | 91,883 |  |  | — |  |  | 91,883 |  |
| Total | $ | 71,580 |  |  | $ | 105,892 |  |  | $ | — |  |  | $ | 177,472 |  |
| Liabilities |  |  |  |  |  |  |  |
| Foreign currency forward contracts | $ | — |  |  | $ | 16 |  |  | $ | — |  |  | $ | 16 |  |
| Total | $ | — |  |  | $ | 16 |  |  | $ | — |  |  | $ | 16 |  |

[0001078271-12-000073:notes:56]
| June 30, 2012 | Level 1 |  | Level 2 |  | Level 3 |  | Total |
|  | (In thousands) |
| Assets |  |  |  |  |  |  |  |
| Investments: |  |  |  |  |  |  |  |
| Municipal bonds | $ | — |  |  | $ | 2,736 |  |  | $ | — |  |  | $ | 2,736 |  |
| Federal agency notes | — |  |  | 11,234 |  |  | — |  |  | 11,234 |  |
| Money market funds | 36,141 |  |  | — |  |  | — |  |  | 36,141 |  |
| Corporate notes/bonds | — |  |  | 84,949 |  |  | — |  |  | 84,949 |  |
| Foreign currency forward contracts | — |  |  | 179 |  |  | — |  |  | 179 |  |
| Total | $ | 36,141 |  |  | $ | 99,098 |  |  | $ | — |  |  | $ | 135,239 |  |

[0001078271-12-000073:notes:57]
Level 2 investment valuations are based on inputs such as quoted market prices of similar instruments, dealer quotations or valuations provided by alternative pricing sources supported by observable inputs. These generally include U.S. government and sovereign obligations, most government agency securities, investment-grade corporate bonds, and state, municipal and provincial obligations. As of September 30, 2012 and June 30, 2012, the Company had no assets or liabilities classified within Level 3. There were no transfers of assets or liabilities between Level 1 and Level 2 during the three months ended September 30, 2012 and October 2, 2011.


## us-gaap:ImpairmentOrDisposalOfLongLivedAssetsPolicyTextBlock

[0001078271-12-000073:notes:58]
Long-Lived Assets

[0001078271-12-000073:notes:59]
Long-lived assets include property and equipment, intangible assets, and service inventory.  Property and equipment, and intangible assets are reviewed for impairment whenever events or changes in circumstances indicate that the carrying amount of such assets or asset groups may not be recoverable. If such facts and circumstances exist, the Company assesses the recoverability of these assets by comparing the projected undiscounted net cash flows associated with the related asset or group of assets over their remaining lives against their respective carrying amounts. Impairments, if any, are based on the excess of the carrying amount over the fair value of those assets. The Company reduces the carrying value of service inventory to net realizable value based on excess and obsolete inventories which are primarily determined by age of inventory and future demand forecasts.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001078271-12-000073:notes:60]
[same as prior period, unchanged from 0001078271-12-000025:notes:43]

[0001078271-12-000073:notes:61]
The Company recorded an income tax provision of $0.6 million and $0.5 million for the first quarter of fiscal 2013 and first quarter of fiscal 2012, respectively.

[0001078271-12-000073:notes:62]
The income tax provision for the first quarter of fiscal 2013 consisted primarily of taxes on foreign income and U.S. state income taxes. The income tax provision for the first quarter of fiscal 2012 consisted primarily of taxes on foreign income and U.S. state income taxes. The income tax provisions for both quarters were calculated based on the results of operations for the three months ended September 30, 2012 and October 2, 2011, and may not reflect the annual effective rate.

[0001078271-12-000073:notes:63]
The Company recognizes deferred tax assets and liabilities based on the differences between the financial statement carrying amounts and the tax bases of assets and liabilities. Significant management judgment is required in determining the Company's deferred tax assets and liabilities and any valuation allowance recorded against the Company's net deferred tax assets. The Company makes an assessment of the likelihood that the Company's net deferred tax assets will be recovered from future taxable income, and to the extent that recovery is not believed to be likely, a valuation allowance is established.

[0001078271-12-000073:notes:64]
The Company has a full valuation allowance against its U.S. net deferred tax assets. The valuation allowance was calculated by assessing both negative and positive evidence when measuring the need for a valuation allowance. Evidence, such as operating results during the most recent three year period was given more weight than our expectations of future profitability, which are inherently uncertain.  Our U.S. losses during those periods represented sufficient negative evidence to require a full valuation allowance against our U.S. federal and state net deferred tax assets.  This valuation allowance will be evaluated periodically and can be reversed partially or totally if business results have sufficiently improved to support realization of the Company's U.S. deferred tax assets.

[0001078271-12-000073:notes:65]
The sale of the Company's buildings and land in Santa Clara, California during the quarter ended September 30, 2012 resulted in a tax loss that increased the amount of the Company's deferred tax assets with a corresponding increase to the related valuation allowance.

[0001078271-12-000073:notes:66]
The Company had $25.8 million of unrecognized tax benefits as of September 30, 2012. The future impact of the unrecognized tax benefit of $25.8 million, if recognized, is as follows: approximately $0.5 million would impact the effective tax rate, and approximately $25.3 million would result in adjustments to deferred tax assets and corresponding adjustments to the valuation allowance. It is reasonably possible that the amount of unrealized tax benefit could decrease by approximately $0.2 million during the next twelve months due to the expiration of the statute of limitations in certain foreign jurisdictions.

[0001078271-12-000073:notes:67]
Estimated interest and penalties related to the underpayment of income taxes are classified as a component of tax expense in the Consolidated Statement of Operations and were immaterial for the quarter ended September 30, 2012. Accrued interest and penalties were approximately $80,000 and $0.2 million as of September 30, 2012 and October 2, 2011, respectively.

[0001078271-12-000073:notes:68]
In general, the Company's U.S. federal income tax returns are subject to examination by tax authorities for fiscal years 1998 forward due to net operating losses and the Company's state income tax returns are subject to examination for fiscal years 2001 forward due to net operating losses.


## us-gaap:InventoryPolicyTextBlock

[0001078271-12-000073:notes:69]
Inventories

[0001078271-12-000073:notes:70]
Inventory is stated at the lower of cost or market. Cost is computed using standard cost, which approximates actual cost, on a first-in, first-out basis. The Company reduces the carrying value of inventory to net realizable value based on excess and obsolete inventories which are primarily determined by age of inventory and future demand forecasts. At the point of the loss recognition, a new, lower-cost basis for that inventory is established, and subsequent changes in facts and circumstances do not result in the restoration or increase in that newly established cost basis. Any written down or obsolete inventory subsequently sold has not had a material impact on gross profit for any of the periods disclosed.


## us-gaap:InvestmentPolicyTextBlock

[0001078271-12-000073:notes:71]
The Company considers highly liquid investments with maturities of three months or less at the date of purchase to be cash equivalents. Investments with maturities of greater than three months, but less than one year at the balance sheet date are classified as Short Term Investments. Investments with maturities of greater than one year at balance sheet date are classified as Marketable Securities. Except for direct obligations of the United States government, securities issued by agencies of the United States government, and money market funds, the Company diversifies its investments by limiting its holdings with any individual issuer.

[0001078271-12-000073:notes:72]
Investments include available-for-sale investment-grade debt securities that the Company carries at fair value. The Company accumulates unrealized gains and losses on the Company's available-for-sale debt securities, net of tax, in accumulated other comprehensive income in the stockholders' equity section of its balance sheets. Such an unrealized gain or loss does not reduce net income for the applicable accounting period. If the fair value of an available-for-sale debt instrument is less than its amortized cost basis, an other-than-temporary impairment is triggered in circumstances where (1) the Company intends to sell the instrument, (2) it is more likely than not that the Company will be required to sell the instrument before recovery of its amortized cost basis, or (3) the Company does not expect to recover the entire amortized cost basis of the instrument (that is, a credit loss exists). If the Company intends to sell or it is more likely than not that the Company will be required to sell the available-for-sale debt instrument before recovery of its amortized cost basis, the Company recognizes an other-than-temporary impairment in earnings equal to the entire difference between the debt instruments' amortized cost basis and its fair value. For available-for-sale debt instruments that are considered other-than-temporarily impaired due to the existence of a credit loss, if the Company does not intend to sell and it is not more likely than not that the Company will be required to sell the instrument before recovery of its remaining amortized cost basis (amortized cost basis less any current-period credit loss), the Company separates the amount of the impairment into the amount that is credit related and the amount due to all other factors. The credit loss component is recognized in earnings and is the difference between the debt instrument's amortized cost basis and the present value of its expected future cash flows. The remaining difference between the debt instrument's fair value and the present value of future expected cash flows is due to factors that are not credit related and is recognized in other comprehensive income.

[0001078271-12-000073:notes:73]
The Company determines the basis of the cost of a security sold or the amount reclassified out of accumulated other comprehensive income into earnings using the specific identification method. During the three months ended September 30, 2012 and October 2, 2011, realized gains or losses recognized on the sale of investments were not significant. As of September 30, 2012, three out of sixty-three investment securities had unrealized losses. The unrealized gains / (losses) on the Company’s investments were caused by interest rate fluctuations. Substantially all of the Company’s available-for-sale investments are investment grade government and corporate debt securities that have maturities of less than three years. The Company does not intend to sell the investments and it is not more likely than not that the Company will be required to sell the investments before recovery of its amortized costs.


## us-gaap:NewAccountingPronouncementsAndChangesInAccountingPrinciplesTextBlock

[0001078271-12-000073:notes:74]
Recently Issued Accounting Pronouncements

[0001078271-12-000073:notes:75]
In June 2011, the FASB issued ASU 2011-05, Comprehensive Income (Topic 220): Presentation of Comprehensive Income. ASU 2011-05 requires one of two alternatives for presenting comprehensive income and eliminates the option to report other comprehensive income and its components as a part of the Consolidated Statements of Stockholders' Equity. Additionally, ASU 2011-05 requires presentation on the face of the financial statements reclassification adjustments for items that are reclassified from other comprehensive income to net income in the statement(s) where the components of net income and the components of other comprehensive income are presented. The requirement related to the reclassification adjustments from other comprehensive income to net income was deferred in December 2011, as a result of the issuance of ASU 2011-12, Deferral of the Effective Date for Amendments to the Presentation of Reclassifications of Items Out of Accumulated Other Comprehensive Income in Accounting Standards Update 2011-05 (Topic 220). The amendments in ASU 2011-05, as amended by ASU 2011-12, do not change the items that must be reported in other comprehensive income or when an item of other comprehensive income must be reclassified to net income. ASU 2011-05, as amended by ASU 2011-12 is effective for fiscal years and interim periods within those years beginning after December 15, 2011 and is to be applied retrospectively. The Company adopted ASU 2011-05 in the quarter ended September 30, 2012.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0001078271-12-000073:notes:76]
[same as prior period, unchanged from 0001078271-12-000025:notes:50]

[0001078271-12-000073:notes:77]
The unaudited condensed consolidated financial statements of Extreme Networks, Inc. (referred to as the “Company” or “Extreme Networks”) included herein have been prepared under the rules and regulations of the Securities and Exchange Commission (“SEC”). Certain information and footnote disclosures normally included in financial statements prepared in accordance with generally accepted accounting principles have been condensed or omitted under such rules and regulations. The condensed consolidated balance sheet at September 30, 2012 was derived from audited financial statements as of that date but does not include all disclosures required by generally accepted accounting principles for complete financial statements. These interim financial statements and notes should be read in conjunction with the Company’s audited consolidated financial statements and notes thereto included in the Company’s Annual Report on Form 10-K for the fiscal year ended June 30, 2012.

[0001078271-12-000073:notes:78]
The unaudited condensed consolidated financial statements reflect all adjustments, consisting only of normal recurring adjustments that, in the opinion of management, are necessary for a fair presentation of the results of operations and cash flows for the interim periods presented and the financial condition of Extreme Networks at September 30, 2012. The results of operations for the three months ended September 30, 2012 are not necessarily indicative of the results that may be expected for fiscal 2013 or any future periods.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001078271-12-000073:notes:79]
Restructuring Charges

[0001078271-12-000073:notes:80]
In the three months ended September 30, 2012, the Company had an immaterial adjustment to restructuring expense related to expenses incurred in connection with restructuring initiatives implemented in fiscal 2012.  Restructuring expense was approximately $1.0 million in the three months ended October 2, 2011. As of September 30, 2012, restructuring liabilities were $0.3 million, primarily comprised of termination benefits.


## us-gaap:RevenueRecognitionPolicyTextBlock

[0001078271-12-000073:notes:81]
Revenue Recognition

[0001078271-12-000073:notes:82]
The Company's revenue is primarily derived from sales of networking products, which are tangible products containing software and non-software components that function together to deliver the tangible product's essential functionality. In addition to tangible products, the Company's sales arrangements may include other deliverables such as standalone software licenses, or service offerings.  For multiple deliverable arrangements, the Company recognizes revenue in accordance with the accounting standard for multiple deliverable revenue arrangements, which provides guidance on whether multiple deliverables exist, how deliverables in an arrangement should be separated, and how consideration should be allocated. Software revenue recognition guidance is applied to the sales of the Company's standalone software products, including software upgrades and software that is not essential to the functionality of the hardware with which it is sold.

[0001078271-12-000073:notes:83]
Pursuant to the guidance of the accounting standard for multiple deliverable revenue arrangements, when the Company's sales arrangements contain multiple elements, such as products, software licenses, maintenance agreements, or professional services, the Company determines the standalone selling price for each element based on a selling price hierarchy. The application of the multiple deliverable revenue accounting standard does not change the units of accounting for the Company's multiple element arrangements. Under the selling price hierarchy, the selling price for each deliverable is based on the Company's vendor-specific objective evidence (“VSOE”), which is determined by a substantial majority of the Company's historical standalone sales transactions for a product or service falling within a narrow range. If VSOE is not available due to a lack of standalone sales transactions or lack of pricing within a narrow range, then third party evidence (“TPE”), as determined by the standalone pricing of competitive vendor products in similar markets, is used, if available. TPE typically is difficult to establish due to the proprietary differences of competitive products and difficulty in obtaining reliable competitive standalone pricing information. When neither VSOE nor TPE is available, the Company determines its best estimate of standalone selling price (“ESP”) for a product or service and does so by considering several factors including, but not limited to, the 12-month historical median sales price, sales channel, geography, gross margin objective, competitive product pricing, and product life cycle. In consideration of all relevant pricing factors, the Company applies management judgment to determine the Company's best estimate of selling price through consultation with and formal approval by the Company's management for all products and services for which neither VSOE nor TPE is available. Generally the standalone selling price of services is determined using VSOE and the standalone selling price of other deliverables is determined by using ESP. The Company regularly reviews VSOE, TPE and ESP for all of its products and services and maintains internal controls over the establishment and updates of these estimates.

[0001078271-12-000073:notes:84]
In accordance with the software revenue recognition accounting standard, the Company continues to recognize revenue for software using the residual method for its sale of standalone software products, including optional software upgrades and other software that is not essential to the functionality of the hardware with which it is sold. After allocation of the relative selling price to each element of the arrangement, the Company recognizes revenue in accordance with the Company's policies for product, software, and service revenue recognition.


## us-gaap:ScheduleOfCashCashEquivalentsAndShortTermInvestmentsTableTextBlock

[0001078271-12-000073:notes:85]
Cash, Cash Equivalents, Short-Term Investments and Marketable Securities

[0001078271-12-000073:notes:86]
Summary of Cash and Available-for-Sale Securities (in thousands)

[0001078271-12-000073:notes:87]
|  | September 30, 2012 |  | June 30, 2012 |
| Cash | $ | 25,132 |  |  | $ | 18,455 |  |
| Cash equivalents | $ | 71,580 |  |  | $ | 36,141 |  |
| Short-term investments | 40,827 |  |  | 23,358 |  |
| Marketable securities | 65,065 |  |  | 75,561 |  |
| Total available-for-sale | $ | 177,472 |  |  | $ | 135,060 |  |
| Total cash and available for sale securities | $ | 202,604 |  |  | $ | 153,515 |  |


## us-gaap:ScheduleOfExpectedAmortizationExpenseTableTextBlock

[0001078271-12-000073:notes:88]
Amortization expense expected to be recorded for each of the next five years is as follows (in thousands):

[0001078271-12-000073:notes:89]
| For the fiscal year ending: |  |
| Remaining for fiscal 2013 | $ | 1,044 |  |
| 2014 | 916 |  |
| 2015 | 549 |  |
| 2016 | 375 |  |
| 2017 | 302 |  |
| Thereafter | 1,817 |  |
| Total | $ | 5,003 |  |


## us-gaap:ScheduleOfIntangibleAssetsAndGoodwillTableTextBlock

[0001078271-12-000073:notes:90]
The following tables summarize the components of gross and net intangible asset balances (in thousands):

[0001078271-12-000073:notes:91]
|  | Weighted Average Remaining Amortization Period |  | Gross Carrying Amount |  | Accumulated Amortization |  | Net Carrying Amount |
| September 30, 2012 |  |  |  |  |  |  |  |
| Patents | 7.4 years |  | $ | 1,800 |  |  | $ | 740 |  |  | $ | 1,060 |  |
| License Agreements | 9.6 years |  | 10,157 |  |  | 6,542 |  |  | 3,615 |  |
| Other Intangibles | 3.0 years |  | 659 |  |  | 331 |  |  | 328 |  |
|  |  |  | $ | 12,616 |  |  | $ | 7,613 |  |  | $ | 5,003 |  |

[0001078271-12-000073:notes:92]
|  | Weighted Average Remaining Amortization Period |  | Gross Carrying Amount |  | Accumulated Amortization |  | Net Carrying Amount |
| June 30, 2012 |  |  |  |  |  |  |  |
| Patents | 7.4 years |  | $ | 1,800 |  |  | $ | 669 |  |  | $ | 1,131 |  |
| License Agreements | 9.3 years |  | 10,158 |  |  | 6,231 |  |  | 3,927 |  |
| Other Intangibles | 0.3 years |  | 324 |  |  | 276 |  |  | 48 |  |
|  |  |  | $ | 12,282 |  |  | $ | 7,176 |  |  | $ | 5,106 |  |


## us-gaap:ScheduleOfInventoryCurrentTableTextBlock

[0001078271-12-000073:notes:93]
Inventories at September 30, 2012 and June 30, 2012, respectively, were (in thousands):

[0001078271-12-000073:notes:94]
|  | September 30, 2012 |  | June 30, 2012 |
| Inventory | $ | 25,267 |  |  | $ | 27,964 |  |
| Less: Excess and Obsolete Inventory | 2,513 |  |  | 1,355 |  |
| Inventory, net | $ | 22,754 |  |  | $ | 26,609 |  |

[0001078271-12-000073:notes:95]
The Company holds service inventory to support customers who have purchased long term service contracts with a hardware replacement element.

[0001078271-12-000073:notes:96]
|  | September 30, 2012 |  | June 30, 2012 |
| Service Inventory | $ | 12,992 |  |  | $ | 13,109 |  |
| Less: Excess and Obsolete Inventory | 4,947 |  |  | 5,074 |  |
| Service Inventory, Net | $ | 8,045 |  |  | $ | 8,035 |  |


## us-gaap:ScheduleOfProductWarrantyLiabilityTableTextBlock

[0001078271-12-000073:notes:97]
The following table summarizes the activity related to the Company’s product warranty liability during the three months ended September 30, 2012 and October 2, 2011:

[0001078271-12-000073:notes:98]
|  | Three Months Ended |
|  | September 30, 2012 |  | October 2, 2011 |
| Balance beginning of period | $ | 2,871 |  |  | $ | 2,640 |  |
| New warranties issued | 1,561 |  |  | 1,648 |  |
| Warranty expenditures | (1,461 | ) |  | (1,586 | ) |
| Balance end of period | $ | 2,971 |  |  | $ | 2,702 |  |


## us-gaap:ScheduleOfRevenueFromExternalCustomersAttributedToForeignCountriesByGeographicAreaTextBlock

[0001078271-12-000073:notes:99]
The Company attributes revenues to geographic regions primarily based on the customer's ship-to location. Information regarding geographic areas is as follows (in thousands):

[0001078271-12-000073:notes:100]
|  | Three Months Ended |
| Net Revenues: | September 30, 2012 |  | October 2, 2011 |
| Americas: |  |  |  |
| United States | $ | 25,204 |  |  | $ | 25,803 |  |
| Other | 9,779 |  |  | 8,202 |  |
| Total Americas | 34,983 |  |  | 34,005 |  |
| EMEA | 28,519 |  |  | 29,480 |  |
| APAC | 12,625 |  |  | 15,409 |  |
| Total net revenues | $ | 76,127 |  |  | $ | 78,894 |  |


## us-gaap:SchedulesOfConcentrationOfRiskByRiskFactorTextBlock

[0001078271-12-000073:notes:101]
The following table sets forth major customers accounting for 10% or more of our net revenue. The amounts for the three months ended October 2, 2011 have been revised to correct previously disclosed amounts:

[0001078271-12-000073:notes:102]
|  |  | Three Months Ended |
|  |  | September 30, 2012 |  | October 2, 2011 |
| Westcon Group Inc. |  | 15 | % |  | 16 | % |
| Scansource, Inc. |  | 12 | % |  | 15 | % |
| Ericsson AB |  | * |  |  | 13 | % |
| Tech Data Corporation |  | 10 | % |  | 10 | % |
| * Less than 10% of revenue |  |  |  |  |

[0001078271-12-000073:notes:103]
The following table sets forth major customers accounting for 10% or more of our accounts receivable balance:

[0001078271-12-000073:notes:104]
|  |  | September 30, 2012 |  | June 30, 2012 |
| Ericsson AB |  | 16 | % |  | 21 | % |
| Scansource Inc. |  | 11 | % |  | * |  |
| Westcon Group Inc. |  | 10 | % |  | 16 | % |
| * Less than 10% of accounts receivable |  |  |  |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001078271-12-000073:notes:105]
[same as prior period, unchanged from 0001078271-12-000025:notes:59]

[0001078271-12-000073:notes:106]
[same as prior period, unchanged from 0001078271-12-000025:notes:60]

[0001078271-12-000073:notes:107]
The Company operates in one segment, the development and marketing of network infrastructure equipment. The Company conducts business globally and is managed geographically. Revenue is attributed to a geographical area based on the location of the customers. The Company operates in three geographical areas: Americas, which includes the United States, Canada, Mexico, Central America and South America; EMEA, which includes Europe, Middle East and Africa; and APAC which includes Asia Pacific, South Asia and Japan.

[0001078271-12-000073:notes:108]
Substantially all of the Company’s assets were attributable to North America operations at September 30, 2012 and October 2, 2011.


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001078271-12-000073:notes:109]
Summary of Significant Accounting Policies


## us-gaap:SubsequentEventsTextBlock

[0001078271-12-000073:notes:110]
Subsequent Events

[0001078271-12-000073:notes:111]
On October 1, 2012, the Company announced that the Board of Directors authorized a share repurchase program for a maximum of $75 million to be purchased in the open market as and when deemed appropriate by the Company's management, in accordance with applicable U.S. securities laws and subject to limitations under the Internal Revenue Code in order to preserve the Company's net operating loss position.  No purchases have been made as of the date of this filing.

[0001078271-12-000073:notes:112]
On October 15, 2012, the Company entered into an agreement to lease approximately 56,218 square feet of space in Morrisville, North Carolina.  The lease commences on January 1, 2013 and will continue for an initial term of 7.8 years that expires on October 30, 2020.  The annual rent will be approximately $1.2 million in the initial year, increasing to approximately $1.4 million in the final year of the lease. The Company has two options to renew the lease for 5 years each.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001078271-12-000073:notes:113]
Balance Sheet Accounts

[0001078271-12-000073:notes:114]
On September 11, 2012, the Company completed the sale of its campus and accompanying 16 acres of land in Santa Clara, California for net cash proceeds of approximately $44.7 million. On September 12, 2012, the Company entered into an agreement with the buyer, whereby the Company will lease three of the four buildings comprising the campus, under a cancellable lease arrangement expiring on January 31, 2013 for one building and on August 31, 2014 for the remaining two buildings. The lease is terminable by the Company upon 30 days notice at any time before August 31, 2014. As of September 30, 2012, future minimum rent payments under the lease were $1.1 million for the remainder of fiscal 2013, $5.5 million in fiscal 2014 and $1.0 million in fiscal 2015.

[0001078271-12-000073:notes:115]
During the quarter ended September 30, 2012, the Company realized a gain of $11.7 million in connection with the sale of its campus, of which approximately $0.1 million was deferred and will be recognized ratable over the lease term expiring on January 31, 2013.

[0001078271-12-000073:notes:116]
Intangible Assets

[0001078271-12-000073:notes:117]
Amortization expense was $0.4 million and $0.5 million for the three months ended September 30, 2012 and October 2, 2011, respectively.  Amortization expense expected to be recorded for each of the next five years is as follows (in thousands):

[0001078271-12-000073:notes:118]
Service Inventory

[0001078271-12-000073:notes:119]
Deferred Revenue, Net

[0001078271-12-000073:notes:120]
Deferred revenue, net represents amounts for (i) deferred services revenue (support arrangements, professional services and training), and (ii) deferred product revenue net of the related cost of revenue when the revenue recognition criteria have not been met. The following table summarizes deferred revenue, net at September 30, 2012 and June 30, 2012, respectively (in thousands):

[0001078271-12-000073:notes:121]
The Company offers for sale to its customers renewable support arrangements, including extended warranty contracts, that range from one to five years. Deferred support revenue is included within deferred revenue, net within the Services category above. The change in the Company’s deferred support revenue balance in relation to these arrangements was as follows (in thousands):

[0001078271-12-000073:notes:122]
|  | Three Months Ended |
|  | September 30, 2012 |  | October 2, 2011 |
| Balance beginning of period | $ | 37,461 |  |  | $ | 35,802 |  |
| New support arrangements | 12,537 |  |  | 14,600 |  |
| Recognition of support revenue | (14,337 | ) |  | (14,672 | ) |
| Balance end of period | 35,661 |  |  | 35,730 |  |
| Less: current portion | 28,377 |  |  | 28,176 |  |
| Non-current deferred revenue | $ | 7,284 |  |  | $ | 7,554 |  |

[0001078271-12-000073:notes:123]
Deferred Distributors Revenue, Net of Cost of Sales to Distributors

[0001078271-12-000073:notes:124]
The Company records revenue from its distributors on a sell-through basis, recording deferred revenue and deferred cost of sales associated with all sales transactions to its distributors in “Deferred distributors revenue, net of cost of sales to distributors” in the liability section of its consolidated balance sheet.  When the Company ships products to its distributors, legal title to the products passes to its distributors, and a legally enforceable obligation is created for the distributors to pay on a current basis.  Therefore, the Company records a trade receivable at the contractual discount to the list selling price and relieves inventory for the cost of goods shipped to the distributor.

[0001078271-12-000073:notes:125]
The amount shown as “Total deferred distributors revenue, net of cost of sales to distributors” represents the deferred gross margin on sales to distributors based on contractual pricing.  Distributors purchase products from the Company at a contractual discount based on geographic region and resell the Company's products at a very broad range of individually negotiated price points depending on competitive factors and other market conditions.  A portion of the deferred revenue balance represents an amount of the distributors' original purchase price that will be remitted back to the distributors after resale transactions are reported to the Company. Therefore, the amount of gross margin the Company will recognize in future periods from distributor sales will be less than the deferred amount recorded for the original sale to the distributor as a result of the price concessions negotiated at the time of sell-through. The wide range and variability of negotiated price credits granted to distributors do not allow the Company to accurately estimate the portion of the balance in the deferred revenue that will be credited to the distributors in the future. Therefore, the Company does not reduce deferred revenue by anticipated future price credits; instead, price credits are recorded against revenue and accounts receivable when incurred, which is generally at the time the distributor sells the product.

[0001078271-12-000073:notes:126]
The following table summarizes deferred distributors revenue, net of cost of sales to distributors at September 30, 2012 and June 30, 2012, respectively (in thousands):

[0001078271-12-000073:notes:127]
|  | September 30, 2012 |  | June 30, 2012 |
| Deferred revenue | $ | 20,737 |  |  | $ | 20,361 |  |
| Deferred cost of Sales | (4,985 | ) |  | (5,042 | ) |
| Total deferred distributors revenue, net of cost of sales to distributors | $ | 15,752 |  |  | $ | 15,319 |  |

[0001078271-12-000073:notes:128]
Guarantees and Product Warranties

[0001078271-12-000073:notes:129]
Upon issuance of a standard product warranty, the Company discloses and recognizes a liability for the obligation it assumes under the warranty. The following table summarizes the activity related to the Company’s product warranty liability during the three months ended September 30, 2012 and October 2, 2011:

[0001078271-12-000073:notes:130]
The Company’s standard hardware warranty period is typically 12 months from the date of shipment to end-users and 90 days for software. For certain access products, the Company offers a limited lifetime hardware warranty commencing on the date of shipment from the Company and ending five (5) years following the Company’s announcement of the end of sale of such product. Upon shipment of products to its customers, the Company estimates expenses for the cost to repair or replace products that may be returned under warranty and accrue a liability in cost of product revenue for this amount. The determination of the Company’s warranty requirements is based on actual historical experience with the product or product family, estimates of repair and replacement costs and any product warranty problems that are identified after shipment. The Company estimates and adjusts these accruals at each balance sheet date in accordance with changes in these factors.

[0001078271-12-000073:notes:131]
In the normal course of business to facilitate sales of its products, the Company indemnifies its resellers and end-user customers with respect to certain matters. The Company has agreed to hold the customer harmless against losses arising from a breach of intellectual property infringement or other claims made against certain parties. These agreements may limit the time within which an indemnification claim can be made and the amount of the claim. It is not possible to estimate the maximum potential amount under these indemnification agreements due to the limited history of prior indemnification claims and the unique facts and circumstances involved in each particular agreement. Historically, payments made by the Company under these agreements have not had a material impact on its operating results or financial position.

[0001078271-12-000073:notes:132]
Concentrations

[0001078271-12-000073:notes:133]
The Company may be subject to concentration of credit risk as a result of certain financial instruments consisting principally of marketable investments and accounts receivable. The Company has placed its investments with high-credit quality issuers. The Company does not invest an amount exceeding 10% of its combined cash, cash equivalents, short-term investments and marketable securities in the securities of any one obligor or maker, except for obligations of the United States government, obligations of United States government agencies and money market accounts.

[0001078271-12-000073:notes:134]
The Company performs ongoing credit evaluations of its customers and generally does not require collateral in exchange for credit.

[0001078271-12-000073:notes:135]
Retirement of Treasury Stock

[0001078271-12-000073:notes:136]
During the quarter ended September 30, 2012, the Company retired 39,631,836 shares of treasury stock. These retired shares are now included in the Company's authorized but unissued shares.  The retired shares had a carrying value of approximately $149.7 million, and upon the formal retirement of the shares, the Company reduced par value by approximately $0.1 million and additional paid-in capital by approximately $149.7 million.
