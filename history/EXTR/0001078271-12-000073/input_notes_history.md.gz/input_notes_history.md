# EXTR note change history — 0001078271-12-000025 → 0001078271-12-000073


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2012-11-01):
[0001078271-12-000073:note_history:1]
Commitments and Contingencies
  (was, 2012-05-04, similarity 0.7576):
[0001078271-12-000025:note_history:1]
Commitments, Contingencies and Leases

- changed (2012-11-01):
[0001078271-12-000073:note_history:2]
The Company currently has arrangements with contract manufacturers and suppliers for the manufacture of its products. The arrangements allow them to procure long lead-time component inventory based upon a rolling production forecast provided by the Company. The Company is obligated to the purchase of long lead-time component inventory that its contract manufacturer procures in accordance with the forecast, unless the Company gives notice of order cancellation outside of applicable component lead-times. As of September 30, 2012, the Company had non-cancelable commitments to purchase approximately $31.1 million of such inventory.
  (was, 2012-05-04, similarity 0.9596):
[0001078271-12-000025:note_history:2]
The Company currently has arrangements with contract manufacturers and suppliers for the manufacture of its products. The arrangements allow them to procure long lead-time component inventory on the Company’s behalf based upon a rolling production forecast provided by it. The Company is obligated to the purchase of long lead-time component inventory that its contract manufacturer procures in accordance with the forecast, unless the Company gives notice of order cancellation outside of applicable component lead-times. As of April 1, 2012, the Company had non-cancelable commitments to purchase approximately $40.2 million of such inventory.

- added (2012-11-01):
[0001078271-12-000073:note_history:3]
Enterasys Networks

- changed (2012-11-01):
[0001078271-12-000073:note_history:4]
On April 20, 2007, the Company filed suit against Enterasys Networks in the United States District Court for the Western District of Wisconsin, Civil Action No. 07-C-0229-C. The complaint alleged willful infringement of U.S. Patents Nos. 6,104,700, 6,678,248, and 6,859,438, and sought injunctive relief against Enterasys' continuing sale of infringing goods and monetary damages. Enterasys responded to the complaint on May 30, 2007, and also filed counterclaims alleging infringement of three U.S. patents owned by Enterasys. On April 9, 2008, the Court dismissed Enterasys' counterclaims on one of its patents with prejudice. On May 5, 2008, the Court granted the Company's motion for summary judgment, finding that it does not infringe Enterasys' two remaining patents and dismissing all of Enterasys' remaining counterclaims with prejudice. On May 30, 2008, a jury found that Enterasys infringed all three of the Company's patents and awarded it damages in the amount of $0.2 million. The Court also ruled in the Company's favor on Enterasys' challenge to the validity of the Company's patents. On October 29, 2008, the Court denied Enterasys' post-trial motion for judgment as a matter of law, and granted Extreme Network's motion for a permanent injunction against Enterasys. The injunction order permanently enjoins Enterasys from manufacturing, using, offering to sell, selling in the U.S. and importing into the U.S. the Enterasys products accused of infringing Extreme Network's three patents. On March 16, 2009, the Court also denied Enterasys' motion for a new trial, but granted Enterasys' motion for a stay of the injunction pending appeal. On April 17, 2009, Enterasys filed its notice of appeal and on May 1, 2009, the Company filed its cross appeal. On September 30, 2010, the U.S. Court of Appeals for the Federal Circuit upheld the jury verdict of infringement by Enterasys of the Company's patents and the Districts Court's summary judgment of non-infringement by the Company of Enterasys' '727 patent. The Federal Circuit reversed the judgment of non-infringement by the Company of Enterasys '181 patent, holding that the District Court Judge applied an incorrect claim construction and reversed the District Court's denial of the Company's request for attorneys' fees as premature.  On November 4, 2011, a jury returned a verdict of non-infringement by the Company of the '181 patent and found the patent to be valid. Both parties filed post-trial motions, including motions for a new trial, for judgment as a matter of law and for attorneys fees, all of which the Court denied on July 11, 2012. Enterasys did not file a notice of appeal by the August 10, 2012 deadline.  Consequently, the judgment of non-infringement in favor of the Company in the second trial is final. During the fourth quarter of fiscal 2012, Enterasys paid the Company $0.6 million related to the judgment.  Of this amount, $0.2 million was for damages and interest and $0.4 million was reimbursement of costs from the first trial.
  (was, 2012-05-04, similarity 0.8607):
[0001078271-12-000025:note_history:4]
On April 20, 2007, the Company filed suit against Enterasys Networks in the United States District Court for the Western District of Wisconsin, Civil Action No. 07-C-0229-C. The complaint alleged willful infringement of U.S. Patents Nos. 6,104,700, 6,678,248, and 6,859,438, and sought injunctive relief against Enterasys' continuing sale of infringing goods and monetary damages. Enterasys responded to the complaint on May 30, 2007, and also filed counterclaims alleging infringement of three U.S. patents owned by Enterasys. On April 9, 2008, the Court dismissed Enterasys' counterclaims on one of its patents with prejudice. On May 5, 2008, the Court granted the Company's motion for summary judgment, finding that it does not infringe Enterasys' two remaining patents and dismissing all of Enterasys' remaining counterclaims with prejudice. On May 30, 2008, a jury found that Enterasys infringed all three of the Company's patents and awarded it damages in the amount of $0.2 million. The Court also ruled in the Company's favor on Enterasys' challenge to the validity of the Company's patents. On October 29, 2008, the Court denied Enterasys' post-trial motion for judgment as a matter of law, and granted Extreme Network's motion for a permanent injunction against Enterasys. The injunction order permanently enjoins Enterasys from manufacturing, using, offering to sell, selling in the U.S. and importing into the U.S. the Enterasys products accused of infringing Extreme Network's three patents. On March 16, 2009, the Court also denied Enterasys' motion for a new trial, but granted Enterasys' motion for a stay of the injunction pending appeal. On April 17, 2009, Enterasys filed its notice of appeal and on May 1, 2009, the Company filed its cross appeal. On September 30, 2010, the U.S. Court of Appeals for the Federal Circuit upheld the jury verdict of infringement by Enterasys of the Company's patents and the Districts Court's summary judgment of non-infringement by the Company of Enterasys' '727 patent. The Federal Circuit reversed the judgment of non-infringement by the Company of Enterasys '181 patent, holding that the District Court Judge applied an incorrect claim construction and reversed the District Court's denial of the Company's request for attorneys' fees as premature.  On November 4, 2011, a jury returned a verdict of non-infringement by the Company of the '181 patent and found the patent to be valid. Post trial motions are pending.  The Company intends to defend the lawsuit vigorously, but, due to the inherent uncertainties of litigation, it cannot predict the ultimate outcome of the matter at this time.

- added (2012-11-01):
[0001078271-12-000073:note_history:5]
Chrimar Systems

- changed (2012-11-01):
[0001078271-12-000073:note_history:6]
On October 31, 2011, Chrimar Systems, Inc. dba CMS Technologies, and Chrimar Holding Company filed suit against the Company, Cisco Systems, Inc., and Cisco Consumer Products LLC. Cisco-Linksys LLC, Hewlett-Packard Company, 3Com Corporation and Avaya, Inc. in the United States District Court for the District of Delaware, Civil Action No. 11-1050 (the "Delaware action").  The complaint alleges infringement of U.S. Patent No. 7,457,250.   The Delaware action has been stayed pursuant to 28 USC Section 1659(a) pending final determination of the International Trade Commission action described below, based on the fact that the allegations in both cases relate to the same patent.
  (was, 2012-05-04, similarity 0.8736):
[0001078271-12-000025:note_history:6]
On October 31, 2011, Chrimar Systems, Inc. dba CMS Technologies, and Chrimar Holding Company filed suit against the Company, Cisco Systems, Inc., Cisco Consumer Products LLC. Cisco-Linksys LLC, Hewlett-Packard Company, 3Com Corporation and Avaya, Inc. in the United States District Court for the District of Delaware, Civil Action No. 11-1050 ("the Delaware action").  The complaint alleges infringement of U.S. Patent No. 7,457,250.   The Delaware action has been stayed pursuant to 28 USC Section 1659(a) pending final determination of the International Trade Commission action described below, based on the fact that the allegations in both cases relate to the same patent.  The Company intends to defend the lawsuit vigorously, but, due to the inherent uncertainties of litigation, it cannot predict the ultimate outcome of the matter at this time.

- changed (2012-11-01):
[0001078271-12-000073:note_history:7]
On November 1, 2011, Chrimar filed a complaint with the International Trade Commission, pursuant to Section 337 of the Tariff Act of 1930, as amended, alleging that the Company imports into the United States, sells for importation and/or sells within the United States after importation of products and/or systems infringing U.S. Patent No. 7,457,250 patent, the same patent asserted in the Delaware action.  On December 2, 2011, the International Trade Commission instituted an investigation of these allegations (the "ITC action").  The complaint in the ITC action seeks a permanent order excluding from entry into the United States all infringing articles that are manufactured, imported or sold by the Company that infringe U.S. Patent No. 7,457,250. On July 20, 2012, Chrimar filed a motion to withdraw its complaint in the ITC and the motion was granted on August 1, 2012 by the presiding administrative law judge.  The ALJ's decision is pending review by the ITC Commissioners.
  (was, 2012-05-04, similarity 0.7556):
[0001078271-12-000025:note_history:7]
On November 1, 2011, Chrimar filed a complaint with the International Trade Commission, pursuant to Section 337 of the Tariff Act of 1930, as amended, alleging that the Company imports into the United States, sells for importation and/or sells within the United States after importation of products and/or systems infringing U.S. Patent No. 7,457,250 patent, the same patent asserted in the Delaware action.  On December 2, 2011, the International Trade Commission instituted an investigation of these allegations ("the ITC action").  The complaint in the ITC action seeks a permanent order excluding from entry into the United States all infringing articles that are manufactured, imported or sold by the Company that infringe U.S. Patent No. 7,457,250.  A hearing has been set at the International Trade Commission on August 27-31, 2012.The Company intends to defend the ITC action vigorously, but, due to the inherent uncertainties of litigation, it cannot predict the ultimate outcome of the matter at this time.

- added (2012-11-01):
[0001078271-12-000073:note_history:8]
During the fourth quarter of the fiscal 2012, the Company engaged in settlement discussions with Chrimar Systems Inc.  As part of the negotiations the Company determined that it is reasonably possible that a range of loss could be between $0.3 million and $1.4 million which is dependent on a number of factors including whether mutually acceptable settlement terms can be reached. This matter was still pending as of September 30, 2012.

- added (2012-11-01):
[0001078271-12-000073:note_history:9]
Reefedge Networks

- added (2012-11-01):
[0001078271-12-000073:note_history:10]
On September 17, 2012, Reefedge Networks, LLC filed suit against the Company in the United States District Court for the District of Delaware, Civil Action No. 12-1148. The complaint alleges wrongful use, making, selling, and/or offering to sell products that infringe U.S. Patent Nos. 6,633.761; 6,975,864; and 7,197,308 and seeks unspecified monetary damages and a permanent injunction for products originating from a single supplier to which the Company has submitted an indemnification request. Given the preliminary nature of the claims, it is premature to assess the likelihood of a particular outcome.  No answer has been filed, and the Company plans to vigorously defend itself.

- changed (2012-11-01):
[0001078271-12-000073:note_history:11]
Subject to certain limitations, the Company may be obligated to indemnify its current and former directors, officers and employees. These obligations arise under the terms of its certificate of incorporation, its bylaws, applicable contracts, and Delaware and California law. The obligation to indemnify, where applicable, generally means that the Company is required to pay or reimburse, and in certain circumstances the Company has paid or reimbursed, the individuals' reasonable legal expenses and possibly damages and other liabilities incurred in connection with these matters. It is not possible to estimate the maximum potential amount under these indemnification agreements due to the limited history of these claims. The cost to defend the Company and the named individuals could have a material adverse effect on its consolidated financial position, results of operations and cash flows in the future. Recovery of such costs under its directors and officers insurance coverage is uncertain.
  (was, 2012-05-04, similarity 0.999):
[0001078271-12-000025:note_history:11]
Subject to certain limitations, the Company may be obligated to indemnify its current and former directors, officers and employees. These obligations arise under the terms of its certificate of incorporation, its bylaws, applicable contracts, and Delaware and California law. The obligation to indemnify, where applicable, generally means that the Company is required to pay or reimburse, and in certain circumstances the Company has paid or reimbursed, the individuals’ reasonable legal expenses and possibly damages and other liabilities incurred in connection with these matters. It is not possible to estimate the maximum potential amount under these indemnification agreements due to the limited history of these claims. The cost to defend the Company and the named individuals could have a material adverse effect on its consolidated financial position, results of operations and cash flows in the future. Recovery of such costs under its directors and officers insurance coverage is uncertain.

- removed (2012-11-01):
[0001078271-12-000025:note_history:12]
Other Legal Matters

- removed (2012-11-01):
[0001078271-12-000025:note_history:13]
Beginning on July 6, 2001, purported securities fraud class action complaints were filed in the United States District Court for the Southern District of New York. The cases were consolidated and the litigation is now captioned as In re Extreme Networks, Inc. Initial Public Offering Securities Litigation, Civ. No. 01-6143 (SAS) (S.D.N.Y.), related to In re Initial Public Offering Securities Litigation, 21 MC 92 (SAS) (S.D.N.Y.). The operative amended complaint names us as defendants; six of the Company's present and former officers and/or directors, including its former CEO; and several investment banking firms that served as underwriters of its initial public offering and October 1999 secondary offering. The complaint alleges liability under Sections 11 and 15 of the Securities Act of 1933 and Sections 10(b) and 20(a) of the Securities Exchange Act of 1934, on the grounds that the registration statement for the offerings did not disclose that: (1) the underwriters had agreed to allow certain customers to purchase shares in the offerings in exchange for excess commissions paid to the underwriters; and (2) the underwriters had arranged for certain customers to purchase additional shares in the aftermarket at predetermined prices. Similar allegations were made in other lawsuits challenging over 300 other initial public offerings and follow-on offerings conducted in 1999 and 2000. The cases were consolidated for pretrial purposes. The parties to the lawsuits have reached a settlement, which was approved by the Court on October 6, 2009. Extreme Networks is not required to make any cash payments in the settlement. The Court subsequently entered a final judgment of dismissal. Certain objectors appealed the judgment. Subsequently, the District Court ruled that all objectors lacked standing to appeal.  One of the objectors appealed that ruling.  In January 2012, the Court dismissed the pending appeal and the case has concluded.  The Company has no financial liability associated with the settlement.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2012-11-01):
[0001078271-12-000073:note_history:14]
The unaudited condensed consolidated financial statements of Extreme Networks, Inc. (referred to as the “Company” or “Extreme Networks”) included herein have been prepared under the rules and regulations of the Securities and Exchange Commission (“SEC”). Certain information and footnote disclosures normally included in financial statements prepared in accordance with generally accepted accounting principles have been condensed or omitted under such rules and regulations. The condensed consolidated balance sheet at September 30, 2012 was derived from audited financial statements as of that date but does not include all disclosures required by generally accepted accounting principles for complete financial statements. These interim financial statements and notes should be read in conjunction with the Company’s audited consolidated financial statements and notes thereto included in the Company’s Annual Report on Form 10-K for the fiscal year ended June 30, 2012.
  (was, 2012-05-04, similarity 0.9911):
[0001078271-12-000025:note_history:14]
The unaudited condensed consolidated financial statements of Extreme Networks, Inc. (referred to as the “Company” or “Extreme Networks”) included herein have been prepared under the rules and regulations of the Securities and Exchange Commission (“SEC”). Certain information and footnote disclosures normally included in financial statements prepared in accordance with generally accepted accounting principles have been condensed or omitted under such rules and regulations. The condensed consolidated balance sheet at July 3, 2011 was derived from audited financial statements as of that date but does not include all disclosures required by generally accepted accounting principles for complete financial statements. These interim financial statements and notes should be read in conjunction with the Company’s audited consolidated financial statements and notes thereto included in the Company’s Annual Report on Form 10-K for the fiscal year ended July 3, 2011.

- changed (2012-11-01):
[0001078271-12-000073:note_history:15]
The unaudited condensed consolidated financial statements reflect all adjustments, consisting only of normal recurring adjustments that, in the opinion of management, are necessary for a fair presentation of the results of operations and cash flows for the interim periods presented and the financial condition of Extreme Networks at September 30, 2012. The results of operations for the three months ended September 30, 2012 are not necessarily indicative of the results that may be expected for fiscal 2013 or any future periods.
  (was, 2012-05-04, similarity 0.6879):
[0001078271-12-000025:note_history:15]
The unaudited condensed consolidated financial statements reflect all adjustments, consisting only of normal recurring adjustments that, in the opinion of management, are necessary for a fair presentation of the results of operations and cash flows for the interim periods presented and the financial condition of Extreme Networks at April 1, 2012. The results of operations for the three and nine months ended April 1, 2012 are not necessarily indicative of the results that may be expected for fiscal 2012 or any future periods.

- removed (2012-11-01):
[0001078271-12-000025:note_history:16]
Reclassification

- removed (2012-11-01):
[0001078271-12-000025:note_history:17]
The Company made conforming changes to its previously reported Statement of Cash Flows for the nine months ended March 27, 2011, which resulted in an increase of $4.1 million to the previously reported cash flows provided by operating activities, an increase of $4.6 million to the previously reported cash flows used in investing activities, and an increase of $0.5 million to the previously reported cash flows provided by financing activities.  These revisions had no effect on previously reported Statements of Operations or Stockholders' Equity and were not material to the Company's financial statements taken as a whole.


## us-gaap:SignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2012-11-01):
[0001078271-12-000073:note_history:18]
Summary of Significant Accounting Policies
  (was, 2012-05-04, similarity 0.9302):
[0001078271-12-000025:note_history:18]
Summary of Significant Accounting Principles

- added (2012-11-01):
[0001078271-12-000073:note_history:19]
The Company's revenue is primarily derived from sales of networking products, which are tangible products containing software and non-software components that function together to deliver the tangible product's essential functionality. In addition to tangible products, the Company's sales arrangements may include other deliverables such as standalone software licenses, or service offerings.  For multiple deliverable arrangements, the Company recognizes revenue in accordance with the accounting standard for multiple deliverable revenue arrangements, which provides guidance on whether multiple deliverables exist, how deliverables in an arrangement should be separated, and how consideration should be allocated. Software revenue recognition guidance is applied to the sales of the Company's standalone software products, including software upgrades and software that is not essential to the functionality of the hardware with which it is sold.

- changed (2012-11-01):
[0001078271-12-000073:note_history:20]
Pursuant to the guidance of the accounting standard for multiple deliverable revenue arrangements, when the Company's sales arrangements contain multiple elements, such as products, software licenses, maintenance agreements, or professional services, the Company determines the standalone selling price for each element based on a selling price hierarchy. The application of the multiple deliverable revenue accounting standard does not change the units of accounting for the Company's multiple element arrangements. Under the selling price hierarchy, the selling price for each deliverable is based on the Company's vendor-specific objective evidence (“VSOE”), which is determined by a substantial majority of the Company's historical standalone sales transactions for a product or service falling within a narrow range. If VSOE is not available due to a lack of standalone sales transactions or lack of pricing within a narrow range, then third party evidence (“TPE”), as determined by the standalone pricing of competitive vendor products in similar markets, is used, if available. TPE typically is difficult to establish due to the proprietary differences of competitive products and difficulty in obtaining reliable competitive standalone pricing information. When neither VSOE nor TPE is available, the Company determines its best estimate of standalone selling price (“ESP”) for a product or service and does so by considering several factors including, but not limited to, the 12-month historical median sales price, sales channel, geography, gross margin objective, competitive product pricing, and product life cycle. In consideration of all relevant pricing factors, the Company applies management judgment to determine the Company's best estimate of selling price through consultation with and formal approval by the Company's management for all products and services for which neither VSOE nor TPE is available. Generally the standalone selling price of services is determined using VSOE and the standalone selling price of other deliverables is determined by using ESP. The Company regularly reviews VSOE, TPE and ESP for all of its products and services and maintains internal controls over the establishment and updates of these estimates.
  (was, 2012-05-04, similarity 0.8505):
[0001078271-12-000025:note_history:20]
Under the accounting standards for multiple-element revenue arrangements, when the Company's sales arrangements contain multiple elements, such as products, software licenses, maintenance agreements, and/or professional services, the Company determines the standalone selling price for each element based on a selling price hierarchy. Under the selling price hierarchy, the selling price for each deliverable is based on the Company's vendor-specific objective evidence (“VSOE”), which is determined by a substantial majority of the Company's historical standalone sales transactions for a product or service falling within a narrow range. If VSOE is not available due to a lack of standalone sales transactions or lack of pricing within a narrow range, then third party evidence (“TPE”), as determined by the standalone pricing of competitive vendor products in similar markets, is used, if available. TPE typically is difficult to establish due to the proprietary differences of competitive products and difficulty in obtaining reliable competitive standalone pricing information. When neither VSOE nor TPE is available, the Company determines its best estimate of standalone selling price (“ESP”) for a product or service and does so by considering several factors including, but not limited to, the 12-month historical median sales price, sales channels, geography, gross margin objectives, competitive product pricing, and product lifecycle. In consideration of all relevant pricing factors, the Company applies management judgment to determine the Company's best estimate of selling price through consultation with and formal approval by the Company's management for all products and services for which neither VSOE nor TPE is available. Generally the standalone selling price of services is determined using VSOE and the standalone selling price of other deliverables is determined by using ESP. The Company regularly reviews VSOE, TPE and ESP for all of its products and services and maintains internal controls over the establishment and updates of these estimates.

- changed (2012-11-01):
[0001078271-12-000073:note_history:21]
In accordance with the software revenue recognition accounting standard, the Company continues to recognize revenue for software using the residual method for its sale of standalone software products, including optional software upgrades and other software that is not essential to the functionality of the hardware with which it is sold. After allocation of the relative selling price to each element of the arrangement, the Company recognizes revenue in accordance with the Company's policies for product, software, and service revenue recognition.
  (was, 2012-05-04, similarity 0.9061):
[0001078271-12-000025:note_history:21]
Under software revenue recognition accounting standards, the Company continues to recognize revenue for software using the residual method for its sale of standalone software products, including software upgrades, and for the sale of software that is not essential to the functionality of the hardware with which it is sold. After allocation of the relative selling price to each element of the arrangement, the Company recognizes revenue in accordance with the Company's policies for product, software, and service revenue recognition.

- removed (2012-11-01):
[0001078271-12-000025:note_history:22]
The Company derives the majority of its revenue from sales of its networking equipment and from service fees related to maintenance service contracts, professional services, and training for its products. The Company defers recognition of revenue on all sales to its stocking distributors until the distributors sell the product, as evidenced by monthly “sales-out” reports that the distributors provide.  The Company generally recognizes product revenue from its value-added resellers, non-stocking distributors and end-user customers at the time of shipment, provided that persuasive evidence of an arrangement exists, delivery has occurred, the price of the product is fixed or determinable, and collection of the sales proceeds is reasonably assured. In instances where the criteria for revenue recognition are not met, revenue is deferred until all criteria have been met.  Revenue from service obligations under service contracts is deferred and recognized on a straight-line basis over the contractual service period. Service contracts typically range from one to two years.

- removed (2012-11-01):
[0001078271-12-000025:note_history:23]
Available-for-Sale Securities

- removed (2012-11-01):
[0001078271-12-000025:note_history:24]
The following is a summary of available-for-sale securities (in thousands):

- removed (2012-11-01):
[0001078271-12-000025:note_history:25]
|  | AmortizedCost |  | Fair Value |  | UnrealizedHoldingGains |  | UnrealizedHoldingLosses |
| April 1, 2012 |  |  |  |  |  |  |  |
| Money market funds | $ | 33,310 |  |  | $ | 33,310 |  |  | $ | — |  |  | $ | — |  |
| U.S. corporate debt securities | 82,952 |  |  | 83,134 |  |  | 262 |  |  | (80 | ) |
| U.S. government agency securities | 7,997 |  |  | 7,989 |  |  | 2 |  |  | (10 | ) |
| U.S. municipal bonds | 2,802 |  |  | 2,803 |  |  | 1 |  |  | — |  |
|  | $ | 127,061 |  |  | $ | 127,236 |  |  | $ | 265 |  |  | $ | (90 | ) |
| Classified as: |  |  |  |  |  |  |  |
| Cash equivalents | $ | 33,310 |  |  | $ | 33,310 |  |  | $ | — |  |  | $ | — |  |
| Short-term investments | 22,261 |  |  | 22,349 |  |  | 88 |  |  | — |  |
| Marketable securities | 71,490 |  |  | 71,577 |  |  | 177 |  |  | (90 | ) |
|  | $ | 127,061 |  |  | $ | 127,236 |  |  | $ | 265 |  |  | $ | (90 | ) |

- removed (2012-11-01):
[0001078271-12-000025:note_history:26]
|  | AmortizedCost |  | Fair Value |  | UnrealizedHoldingGains |  | UnrealizedHoldingLosses |
| July 3, 2011 |  |  |  |  |  |  |  |
| Money market funds | $ | 30,405 |  |  | $ | 30,405 |  |  | $ | — |  |  | $ | — |  |
| U.S. corporate debt securities | 89,004 |  |  | 89,249 |  |  | 287 |  |  | (43 | ) |
| U.S. government agency securities | 7,746 |  |  | 7,756 |  |  | 13 |  |  | (3 | ) |
|  | $ | 127,155 |  |  | $ | 127,410 |  |  | $ | 300 |  |  | $ | (46 | ) |
| Classified as: |  |  |  |  |  |  |  |
| Cash equivalents | $ | 30,405 |  |  | $ | 30,405 |  |  | $ | — |  |  | $ | — |  |
| Short-term investments | 41,245 |  |  | 41,357 |  |  | 114 |  |  | (1 | ) |
| Marketable securities | 55,505 |  |  | 55,648 |  |  | 186 |  |  | (45 | ) |
|  | $ | 127,155 |  |  | $ | 127,410 |  |  | $ | 300 |  |  | $ | (46 | ) |

- removed (2012-11-01):
[0001078271-12-000025:note_history:27]
The amortized cost and estimated fair value of available-for-sale investments in debt securities at April 1, 2012, by contractual maturity, were as follows (in thousands):

- removed (2012-11-01):
[0001078271-12-000025:note_history:28]
|  | AmortizedCost |  | FairValue |
| Due in 1 year or less | $ | 22,261 |  |  | $ | 22,349 |  |
| Due in 1-2 years | 52,594 |  |  | 52,662 |  |
| Due in 2-5 years | 18,896 |  |  | 18,915 |  |
| Due in more than 5 years | — |  |  | — |  |
| Total investments in available for sale debt securities | $ | 93,751 |  |  | $ | 93,926 |  |

- removed (2012-11-01):
[0001078271-12-000025:note_history:29]
The Company considers highly liquid investments with maturities of three months or less at the date of purchase to be cash equivalents. Investments with maturities of greater than three months, but less than one year at the balance sheet date are classified as Short Term Investments. Investments with maturities of greater than one year at balance sheet date are classified as Marketable Securities. Except for direct obligations of the United States government, securities issued by agencies of the United States government, and money market funds, the Company diversifies its investments by limiting its holdings with any individual issuer.

- removed (2012-11-01):
[0001078271-12-000025:note_history:30]
Investments include available-for-sale investment-grade debt securities that the Company carries at fair value. The Company accumulates unrealized gains and losses on the Company’s available-for-sale debt securities, net of tax, in accumulated other comprehensive income in the stockholders’ equity section of its balance sheets. Such an unrealized gain or loss does not reduce net income for the applicable accounting period. If the fair value of an available-for-sale debt instrument is less than its amortized cost basis, an other-than-temporary impairment is triggered in circumstances where (1) the Company intends to sell the instrument, (2) it is more likely than not that the Company will be required to sell the instrument before recovery of its amortized cost basis, or (3) the Company does not expect to recover the entire amortized cost basis of the instrument (that is, a credit loss exists). If the Company intends to sell or it is more likely than not that the Company will be required to sell the available-for-sale debt instrument before recovery of its amortized cost basis, the Company recognizes an other-than-temporary impairment in earnings equal to the entire difference between the debt instruments’ amortized cost basis and its fair value. For available-for-sale debt instruments that are considered other-than-temporarily impaired due to the existence of a credit loss, if the Company does not intend to sell and it is not more likely than not that the Company will be required to sell the instrument before recovery of its remaining amortized cost basis (amortized cost basis less any current-period credit loss), the Company separates the amount of the impairment into the amount that is credit related and the amount due to all other factors. The credit loss component is recognized in earnings and is the difference between the debt instrument’s amortized cost basis and the present value of its expected future cash flows. The remaining difference between the debt instrument’s fair value and the present value of future expected cash flows is due to factors that are not credit related and is recognized in other comprehensive income. As of April 1, 2012 and July 3, 2011, the Company did not have any other-than-temporary impairment of its investment securities.

- removed (2012-11-01):
[0001078271-12-000025:note_history:31]
The following table presents the Company’s investments’ gross unrealized losses and fair values, aggregated by investment category and length of time that individual securities have been in a continuous unrealized loss position.

- removed (2012-11-01):
[0001078271-12-000025:note_history:32]
|  | Less than 12 months |  | 12 months or more |  | Total |
|  | Fair Value |  | UnrealizedLosses |  | Fair Value |  | UnrealizedLosses |  | Fair Value |  | UnrealizedLosses |
| April 1, 2012: |  |  |  |  |  |  |  |  |  |  |  |
| U.S. corporate debt securities | $ | 23,384 |  |  | $ | (80 | ) |  | $ | — |  |  | $ | — |  |  | $ | 23,384 |  |  | $ | (80 | ) |
| U.S. government agency securities | $ | 4,246 |  |  | $ | (10 | ) |  | $ | — |  |  | $ | — |  |  | $ | 4,246 |  |  | $ | (10 | ) |
|  | $ | 27,630 |  |  | $ | (90 | ) |  | $ | — |  |  | $ | — |  |  | $ | 27,630 |  |  | $ | (90 | ) |

- removed (2012-11-01):
[0001078271-12-000025:note_history:33]
The Company determines the basis of the cost of a security sold or the amount reclassified out of accumulated other comprehensive income into earnings using the specific identification method. During the three and nine months ended April 1, 2012 and March 27, 2011, realized gains or losses recognized on the sale of investments were not significant. As of April 1, 2012, there were eighteen out of fifty-two investment securities that had unrealized losses. The unrealized gains / (losses) on the Company’s investments were caused by interest rate fluctuations. Substantially all of the Company’s available-for-sale investments are investment grade government and corporate debt securities that have maturities of less than 3 years.

- removed (2012-11-01):
[0001078271-12-000025:note_history:34]
Fair Value of Financial Instruments

- removed (2012-11-01):
[0001078271-12-000025:note_history:35]
The Company recognizes certain financial instruments at fair value on a recurring basis. The following table presents the Company’s fair value hierarchy for those instruments:

- removed (2012-11-01):
[0001078271-12-000025:note_history:36]
| April 1, 2012: | Level 1 |  | Level 2 |  | Total |
|  |  |  | (In thousands) |  |  |
| Assets |  |  |  |  |  |
| Investments: |  |  |  |  |  |
| Municipal bonds | $ | — |  |  | $ | 2,803 |  |  | $ | 2,803 |  |
| Federal agency notes | — |  |  | 7,989 |  |  | 7,989 |  |
| Money market funds | 33,310 |  |  | — |  |  | 33,310 |  |
| Corporate notes/bonds | — |  |  | 83,134 |  |  | 83,134 |  |
| Total | 33,310 |  |  | 93,926 |  |  | 127,236 |  |
| Liabilities |  |  |  |  |  |
| Foreign currency forward contracts | — |  |  | (13 | ) |  | (13 | ) |
| Total | $ | — |  |  | $ | (13 | ) |  | $ | (13 | ) |
| July 3, 2011: | Level 1 |  | Level 2 |  | Total |
|  |  |  | (In thousands) |  |  |
| Assets |  |  |  |  |  |
| Investments: |  |  |  |  |  |
| Federal agency notes | $ | — |  |  | $ | 7,756 |  |  | $ | 7,756 |  |
| Money market funds | 30,405 |  |  | — |  |  | 30,405 |  |
| Corporate notes/bonds | — |  |  | 89,248 |  |  | 89,248 |  |
| Total | 30,405 |  |  | 97,004 |  |  | 127,409 |  |
| Liabilities |  |  |  |  |  |
| Foreign currency forward contracts | — |  |  | 37 |  |  | 37 |  |
| Total | $ | — |  |  | $ | 37 |  |  | $ | 37 |  |

- removed (2012-11-01):
[0001078271-12-000025:note_history:37]
Level 2 investment valuations are based on inputs such as quoted market prices, dealer quotations or valuations provided by alternative pricing sources supported by observable inputs. These generally include U.S. government and sovereign obligations, most government agency securities, investment-grade corporate bonds, and state, municipal and provincial obligations. As of April 1, 2012 and July 3, 2011, the Company had no assets or liabilities classified within Level 3. There were no transfers  of assets or liabilities between Level 1 and Level 2 during the three and nine months ended April 1, 2012 and March 27, 2011.

- removed (2012-11-01):
[0001078271-12-000025:note_history:38]
Inventory, Net

- removed (2012-11-01):
[0001078271-12-000025:note_history:39]
Inventory is stated at the lower of cost or market. Cost is computed using standard cost, which approximates actual cost, on a first-in, first-out basis. The Company reduces the carrying value of inventory based on excess and obsolete inventories which are primarily determined by age of inventory and future demand forecasts. At the point of the loss recognition, a new, lower-cost basis for that inventory is established, and subsequent changes in facts and circumstances do not result in the restoration or increase in that newly established cost basis. Any written down or obsolete inventory subsequently sold has not had a material impact on gross profit for any of the periods disclosed. Inventories at April 1, 2012 and July 3, 2011, respectively, were (in thousands):

- removed (2012-11-01):
[0001078271-12-000025:note_history:40]
|  | April 1, 2012 |  | July 3, 2011 |
| Inventory, gross | $ | 24,245 |  |  | $ | 26,487 |  |
| Less: Write down for excess and obsolete inventory | 976 |  |  | 4,904 |  |
| Inventory, net | $ | 23,269 |  |  | $ | 21,583 |  |

- removed (2012-11-01):
[0001078271-12-000025:note_history:41]
Long-lived assets

- removed (2012-11-01):
[0001078271-12-000025:note_history:42]
Long-lived assets include property and equipment, intangible assets, and service inventory which the Company holds to support customers who have purchased service contracts with a hardware replacement element.   Long-lived assets are reviewed for impairment whenever events or changes in circumstances indicate that the carrying amount of such assets or asset groups may not be recoverable. If such facts and circumstances exist, the Company assesses the recoverability of the long-lived assets by comparing the projected undiscounted net cash flows associated with the related asset or group of assets over their remaining lives against their respective carrying amounts. Impairments, if any, are based on the excess of the carrying amount over the fair value of those assets. There was no impairment of long-lived assets during the three and nine months ended April 1, 2012 and March 27, 2011.

- removed (2012-11-01):
[0001078271-12-000025:note_history:43]
On September 23, 2010, the Company entered into an Option Agreement with Trumark Companies LLC (“Trumark”), under which the Company granted Trumark an option (the “Option”) to purchase half of its corporate headquarters campus in Santa Clara, California (First Property), at a price of $24.0 million. On January 25, 2012, Company entered into a new Option Agreement with Trumark, under which it granted Trumark an option to purchase the remaining portion of the Company's corporate campus (Second Property), at a price of $24.5 million.  Under the agreements, Trumark will have until December 18, 2012 and December 28, 2012 to exercise the options to purchase the First Property and the Second Property, respectively, and may extend the option if they make certain payments to the Company. As of April 1, 2012, the Company had received option payments totaling $2.0 million from Trumark, which were classified as a deferred gain and included in other current liabilities on the condensed consolidated balance sheet.

- removed (2012-11-01):
[0001078271-12-000025:note_history:44]
In January 2012, the Company classified the First Property as “assets held for sale” on the condensed consolidated balance at a net book value of $17.1 million, which was the lesser of the fair value (less cost to sell) or carrying amount of the assets, and ceased recognizing depreciation expense on the assets. As of April 1, 2012, the Second Property, with a net book value of $16.1 million, remains classified as “assets held for use” due to certain unresolved contingencies that may delay the completion date of this transaction, including the Company's execution of an agreement with Trumark to lease back the Second Property.

- removed (2012-11-01):
[0001078271-12-000025:note_history:45]
Intangible assets

- removed (2012-11-01):
[0001078271-12-000025:note_history:46]
The following tables summarize the components of gross and net intangible asset balances (in thousands):

- removed (2012-11-01):
[0001078271-12-000025:note_history:47]
|  | Weighted Average Remaining Amortization Period |  | Gross Carrying Amount |  | Accumulated Amortization |  | Net Carrying Amount |
| April 1, 2012: |  |  |  |  |  |  |  |
| Patents | 7.5 years |  | $ | 1,800 |  |  | $ | 598 |  |  | $ | 1,202 |  |
| License Agreements | 6.5 years |  | 8,926 |  |  | 5,908 |  |  | 3,018 |  |
| Other Intangibles | 0.5 years |  | 324 |  |  | 253 |  |  | 71 |  |
|  |  |  | $ | 11,050 |  |  | $ | 6,759 |  |  | $ | 4,291 |  |

- removed (2012-11-01):
[0001078271-12-000025:note_history:48]
|  | Weighted Average Remaining Amortization Period |  | Gross Carrying Amount |  | Accumulated Amortization |  | Net Carrying Amount |
| July 3, 2011: |  |  |  |  |  |  |  |
| Patents | 7.7 years |  | $ | 1,800 |  |  | $ | 387 |  |  | $ | 1,413 |  |
| License Agreements | 6.5 years |  | 8,140 |  |  | 4,788 |  |  | 3,352 |  |
| Other Intangibles | 1.2 years |  | 324 |  |  | 183 |  |  | 141 |  |
|  |  |  | $ | 10,264 |  |  | $ | 5,358 |  |  | $ | 4,906 |  |

- removed (2012-11-01):
[0001078271-12-000025:note_history:49]
Amortization expense was $0.4 million and $0.5 million for the three months ended April 1, 2012 and March 27, 2011, respectively. Amortization expense was $1.4 million and $1.6 million for the nine months ended April 1, 2012 and March 27, 2011, respectively. Amortization expense expected to be recorded for each of the next five years is as follows (in thousands):

- removed (2012-11-01):
[0001078271-12-000025:note_history:50]
| For the fiscal year ending: |  |
| Remaining in fiscal 2012 | $ | 382 |  |
| 2013 | 1,306 |  |
| 2014 | 675 |  |
| 2015 | 364 |  |
| 2016 | 275 |  |
| Thereafter | 1,289 |  |
| Total | $ | 4,291 |  |

- removed (2012-11-01):
[0001078271-12-000025:note_history:51]
Deferred Revenue, Net

- removed (2012-11-01):
[0001078271-12-000025:note_history:52]
Deferred revenue, net represents amounts for (i) deferred services revenue (support arrangements, professional services and training), and (ii) deferred product revenue net of the related cost of revenues when the revenue recognition criteria have not been met. Product revenue includes shipments to end-users and value-add resellers. The following table summarizes deferred revenue, net at April 1, 2012 and July 3, 2011, respectively (in thousands):

- removed (2012-11-01):
[0001078271-12-000025:note_history:53]
|  | April 1, 2012 |  | July 3, 2011 |
| Deferred services | $ | 38,417 |  |  | $ | 36,025 |  |
| Deferred product |  |  |  |
| Deferred revenue | 2,045 |  |  | 1,984 |  |
| Deferred cost of sales | (699 | ) |  | (1,036 | ) |
| Deferred product revenue, net | 1,346 |  |  | 948 |  |
| Balance at end of period | 39,763 |  |  | 36,973 |  |
| Less: current portion | 32,134 |  |  | 29,613 |  |
| Non-current deferred revenue, net | $ | 7,629 |  |  | $ | 7,360 |  |

- removed (2012-11-01):
[0001078271-12-000025:note_history:54]
The Company offers support arrangements, including extended warranty contracts, to its customers that range generally from one to two years. Deferred support revenue is included within deferred revenue, net within the deferred services category above. The change in the Company’s deferred support revenue balance in relation to these arrangements was as follows (in thousands):

- removed (2012-11-01):
[0001078271-12-000025:note_history:55]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 1, 2012 |  | March 27, 2011 |  | April 1, 2012 |  | March 27, 2011 |
| Balance beginning of period | $ | 37,416 |  |  | $ | 38,872 |  |  | $ | 35,802 |  |  | $ | 36,193 |  |
| New support arrangements | 15,115 |  |  | 12,231 |  |  | 45,675 |  |  | 43,961 |  |
| Recognition of support revenue | (14,364 | ) |  | (14,137 | ) |  | (43,310 | ) |  | (43,188 | ) |
| Balance end of period | 38,167 |  |  | 36,966 |  |  | 38,167 |  |  | 36,966 |  |
| Less current portion | 30,538 |  |  | 30,175 |  |  | 30,538 |  |  | 30,175 |  |
| Non-current deferred revenue | $ | 7,629 |  |  | $ | 6,791 |  |  | $ | 7,629 |  |  | $ | 6,791 |  |

- removed (2012-11-01):
[0001078271-12-000025:note_history:56]
Deferred Distributors Revenue, Net of Deferred Cost of Sales to Distributors

- removed (2012-11-01):
[0001078271-12-000025:note_history:57]
At the time of shipment to distributors, the Company records a trade receivable at the contractual discount to list selling price since there is a legally enforceable obligation from the distributor to pay it currently for product delivered, the Company relieves inventory for the carrying value of goods shipped since legal title has passed to the distributor, and the Company records deferred revenue and deferred cost of sales in “Deferred distributors revenue, net of deferred cost of sales to distributors” in the liability section of its consolidated balance sheets. The following table summarizes deferred distributors revenue, net of deferred cost of sales to distributors at April 1, 2012 and July 3, 2011, respectively (in thousands):

- removed (2012-11-01):
[0001078271-12-000025:note_history:58]
|  | April 1, 2012 |  | July 3, 2011 |
| Deferred revenue | $ | 23,376 |  |  | $ | 22,454 |  |
| Deferred cost of sales | (5,408 | ) |  | (5,902 | ) |
| Total deferred distributors revenue, net of deferred cost of sales to distributors | $ | 17,968 |  |  | $ | 16,552 |  |

- removed (2012-11-01):
[0001078271-12-000025:note_history:59]
Guarantees and Product Warranties

- removed (2012-11-01):
[0001078271-12-000025:note_history:60]
The Company's standard hardware warranty period is typically 12 months from the date of shipment to end-users. For certain access products, the Company offers a lifetime hardware warranty commencing on the date of shipment from the Company and ending five years following the Company's announcement of the end of sale of such product. The following table summarizes the activity related to the Company’s product warranty liability during the three and nine months ended April 1, 2012 and March 27, 2011, respectively (in thousands):

- removed (2012-11-01):
[0001078271-12-000025:note_history:61]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 1, 2012 |  | March 27, 2011 |  | April 1, 2012 |  | March 27, 2011 |
| Balance beginning of period | $ | 2,651 |  |  | $ | 2,811 |  |  | $ | 2,640 |  |  | $ | 3,169 |  |
| New warranties issued | 1,556 |  |  | 1,369 |  |  | 4,793 |  |  | 4,313 |  |
| Warranty expenditures | (1,365 | ) |  | (1,672 | ) |  | (4,591 | ) |  | (4,974 | ) |
| Balance end of period | $ | 2,842 |  |  | $ | 2,508 |  |  | $ | 2,842 |  |  | $ | 2,508 |  |

- removed (2012-11-01):
[0001078271-12-000025:note_history:62]
In the normal course of business to facilitate sales of the Company's products, the Company indemnifies the Company's resellers and end-user customers with respect to certain matters. The Company has agreed to hold the customer harmless against losses arising from intellectual property infringement or other claims made against certain parties. These agreements may limit the time within which an indemnification claim can be made and the amount of the claim. It is not possible to estimate the maximum potential amount under these indemnification agreements due to the limited history of prior indemnification claims and the unique facts and circumstances involved in each particular agreement. Historically, payments made by the Company under these agreements have not had a material impact on the Company's operating results or financial position.

- removed (2012-11-01):
[0001078271-12-000025:note_history:63]
Other Accrued Liabilities

- removed (2012-11-01):
[0001078271-12-000025:note_history:64]
The following are the components of other accrued liabilities (in thousands):

- removed (2012-11-01):
[0001078271-12-000025:note_history:65]
|  | April 1, 2012 |  | July 3, 2011 |
| Accrued income taxes | $ | 731 |  |  | $ | 897 |  |
| Accrued general and administrative costs | 1,927 |  |  | 5,373 |  |
| Accrued research and development costs | 737 |  |  | 1,734 |  |
| Accrued in-transit inventory and freight | 1,723 |  |  | 2,777 |  |
| Accrued marketing development funds | 2,143 |  |  | 2,492 |  |
| Deferred gain on planned sale of buildings | 2,003 |  |  | — |  |
| Other accrued liabilities | 3,031 |  |  | 5,777 |  |
| Total | $ | 12,295 |  |  | $ | 19,050 |  |


## us-gaap:RevenueRecognitionPolicyTextBlock (revenue_recognition_policy) — matched_by: no_prior_note, score: 0.0

- added (2012-11-01):
[0001078271-12-000073:note_history:66]
Revenue Recognition

- added (2012-11-01):
[0001078271-12-000073:note_history:67]
The Company's revenue is primarily derived from sales of networking products, which are tangible products containing software and non-software components that function together to deliver the tangible product's essential functionality. In addition to tangible products, the Company's sales arrangements may include other deliverables such as standalone software licenses, or service offerings.  For multiple deliverable arrangements, the Company recognizes revenue in accordance with the accounting standard for multiple deliverable revenue arrangements, which provides guidance on whether multiple deliverables exist, how deliverables in an arrangement should be separated, and how consideration should be allocated. Software revenue recognition guidance is applied to the sales of the Company's standalone software products, including software upgrades and software that is not essential to the functionality of the hardware with which it is sold.

- added (2012-11-01):
[0001078271-12-000073:note_history:68]
Pursuant to the guidance of the accounting standard for multiple deliverable revenue arrangements, when the Company's sales arrangements contain multiple elements, such as products, software licenses, maintenance agreements, or professional services, the Company determines the standalone selling price for each element based on a selling price hierarchy. The application of the multiple deliverable revenue accounting standard does not change the units of accounting for the Company's multiple element arrangements. Under the selling price hierarchy, the selling price for each deliverable is based on the Company's vendor-specific objective evidence (“VSOE”), which is determined by a substantial majority of the Company's historical standalone sales transactions for a product or service falling within a narrow range. If VSOE is not available due to a lack of standalone sales transactions or lack of pricing within a narrow range, then third party evidence (“TPE”), as determined by the standalone pricing of competitive vendor products in similar markets, is used, if available. TPE typically is difficult to establish due to the proprietary differences of competitive products and difficulty in obtaining reliable competitive standalone pricing information. When neither VSOE nor TPE is available, the Company determines its best estimate of standalone selling price (“ESP”) for a product or service and does so by considering several factors including, but not limited to, the 12-month historical median sales price, sales channel, geography, gross margin objective, competitive product pricing, and product life cycle. In consideration of all relevant pricing factors, the Company applies management judgment to determine the Company's best estimate of selling price through consultation with and formal approval by the Company's management for all products and services for which neither VSOE nor TPE is available. Generally the standalone selling price of services is determined using VSOE and the standalone selling price of other deliverables is determined by using ESP. The Company regularly reviews VSOE, TPE and ESP for all of its products and services and maintains internal controls over the establishment and updates of these estimates.

- added (2012-11-01):
[0001078271-12-000073:note_history:69]
In accordance with the software revenue recognition accounting standard, the Company continues to recognize revenue for software using the residual method for its sale of standalone software products, including optional software upgrades and other software that is not essential to the functionality of the hardware with which it is sold. After allocation of the relative selling price to each element of the arrangement, the Company recognizes revenue in accordance with the Company's policies for product, software, and service revenue recognition.


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: no_prior_note, score: 0.0

- added (2012-11-01):
[0001078271-12-000073:note_history:70]
Subsequent Events

- added (2012-11-01):
[0001078271-12-000073:note_history:71]
On October 1, 2012, the Company announced that the Board of Directors authorized a share repurchase program for a maximum of $75 million to be purchased in the open market as and when deemed appropriate by the Company's management, in accordance with applicable U.S. securities laws and subject to limitations under the Internal Revenue Code in order to preserve the Company's net operating loss position.  No purchases have been made as of the date of this filing.

- added (2012-11-01):
[0001078271-12-000073:note_history:72]
On October 15, 2012, the Company entered into an agreement to lease approximately 56,218 square feet of space in Morrisville, North Carolina.  The lease commences on January 1, 2013 and will continue for an initial term of 7.8 years that expires on October 30, 2020.  The annual rent will be approximately $1.2 million in the initial year, increasing to approximately $1.4 million in the final year of the lease. The Company has two options to renew the lease for 5 years each.
