# EXTR MD&A — 0001078271-12-000073


## mdna

[0001078271-12-000073:mdna:1]
Item 2. Management’s Discussion and Analysis of Financial Condition and Results of Operations

[0001078271-12-000073:mdna:2]
[same as prior period, unchanged from 0001078271-12-000025:mdna:2]

[0001078271-12-000073:mdna:3]
[same as prior period, unchanged from 0001078271-12-000025:mdna:3]

[0001078271-12-000073:mdna:4]
[same as prior period, unchanged from 0001078271-12-000025:mdna:4]

[0001078271-12-000073:mdna:5]
[same as prior period, unchanged from 0001078271-12-000025:mdna:5]

[0001078271-12-000073:mdna:6]
[same as prior period, unchanged from 0001078271-12-000025:mdna:6]

[0001078271-12-000073:mdna:7]
We believe that continued success in our marketplace is dependent upon a variety of factors that includes, but is not limited to, our ability to design, develop and distribute new and enhanced products employing leading-edge technology.

[0001078271-12-000073:mdna:8]
[same as prior period, unchanged from 0001078271-12-000025:mdna:8]

[0001078271-12-000073:mdna:9]
During the first quarter of fiscal 2013, we achieved the following results:

[0001078271-12-000073:mdna:10]
| • | Net revenues of $76.1 million compared to net revenues of $78.9 million in the first quarter of fiscal 2012. |

[0001078271-12-000073:mdna:11]
| • | Product revenues of $61.1 million compared to product revenues of $63.2 million in the first quarter of fiscal 2012. |

[0001078271-12-000073:mdna:12]
| • | Service revenues of $15.0 million compared to service revenues of $15.7 million in the first quarter of fiscal 2012. |

[0001078271-12-000073:mdna:13]
| • | Total gross margin of 52.5% of net revenues (including share-based compensation expense of $0.2 million), compared to total gross margin of 55.2% of net revenues in the first quarter of fiscal 2012. |

[0001078271-12-000073:mdna:14]
| • | Operating income of $13.6 million (including gain on the sale of facilities of $11.5 million) compared to operating income of $1.8 million in the first quarter of fiscal 2012. |

[0001078271-12-000073:mdna:15]
| • | Net income of $12.9 million (including share-based compensation expense of $2.2 million and gain on the sale of facilities of $11.5 million) compared to net income of $1.6 million in the first quarter of fiscal 2012. |

[0001078271-12-000073:mdna:16]
| • | Cash flow provided by operating activities of $7.1 million compared to cash flow used in operating activities of $3.9 million in the first quarter of fiscal 2012. |

[0001078271-12-000073:mdna:17]
| • | Cash and cash equivalents, short-term investments and marketable securities increased by $49.1 million to $202.6 million from $153.5 million as of June 30, 2012, primarily due to cash provided by operating and investing activities, including the sale of buildings and land. |

[0001078271-12-000073:mdna:18]
We operate in three regions: Americas, which includes the United States, Canada, Mexico, Central America and South America; EMEA, which includes Europe, Middle East, and Africa; and APAC which includes Asia Pacific, South Asia and Japan. The following table presents the total net revenue geographically for the three months ended September 30, 2012 and October 2, 2011, respectively (dollars in thousands):

[0001078271-12-000073:mdna:19]
|  | Three Months Ended |
| Net Revenue | September 30, 2012 |  | October 2, 2011 |  | $Change |  | %Change |
| Americas: |  |  |  |  |  |  |  |
| United States | $ | 25,204 |  |  | $ | 25,803 |  |  | $ | (599 | ) |  | (2.3 | )% |
| Other | 9,779 |  |  | 8,202 |  |  | 1,577 |  |  | 19.2 | % |
| Total Americas | 34,983 |  |  | 34,005 |  |  | 978 |  |  | 2.9 | % |
| Percentage of net revenue | 46.0 | % |  | 43.1 | % |  |  |  |  |
| EMEA | 28,519 |  |  | 29,480 |  |  | (961 | ) |  | (3.3 | )% |
| Percentage of net revenue | 37.5 | % |  | 37.4 | % |  |  |  |  |
| APAC | 12,625 |  |  | 15,409 |  |  | (2,784 | ) |  | (18.1 | )% |
| Percentage of net revenue | 16.6 | % |  | 19.5 | % |  |  |  |  |
| Total net revenues | $ | 76,127 |  |  | $ | 78,894 |  |  | $ | (2,767 | ) |  | (3.5 | )% |

[0001078271-12-000073:mdna:20]
[same as prior period, unchanged from 0001078271-12-000025:mdna:23]

[0001078271-12-000073:mdna:21]
The following table presents net product and service revenue for the three months ended September 30, 2012 and October 2, 2011, respectively (dollars in thousands):

[0001078271-12-000073:mdna:22]
|  | Three Months Ended |
|  | September 30, 2012 |  | October 2, 2011 |  | $Change |  | %Change |
| Net Revenue: |  |  |  |  |  |  |  |
| Product | $ | 61,119 |  |  | $ | 63,213 |  |  | $ | (2,094 | ) |  | (3.3 | )% |
| Percentage of net revenue | 80.3 | % |  | 80.1 | % |  |  |  |  |
| Service | 15,008 |  |  | 15,681 |  |  | (673 | ) |  | (4.3 | )% |
| Percentage of net revenue | 19.7 | % |  | 19.9 | % |  |  |  |  |
| Total net revenue | $ | 76,127 |  |  | $ | 78,894 |  |  | $ | (2,767 | ) |  | (3.5 | )% |

[0001078271-12-000073:mdna:23]
Product revenue decreased by $2.1 million or 3.3% in the three months ended September 30, 2012 compared to the corresponding period of fiscal 2012 primarily due to lower sales volume to our customers in the APAC region. From a country perspective, we experienced lower sales volume to enterprise customers and service providers in China and Japan in the first quarter of fiscal 2013, compared to the first quarter last year, partly due to longer sales cycle.

[0001078271-12-000073:mdna:24]
Service revenue decreased by $0.7 million in the three months ended September 30, 2012 compared to the corresponding period of fiscal 2012. Service revenue in the first quarter of fiscal 2012 included one-time revenue of approximately $1.2 million from a customer in the APAC region.

[0001078271-12-000073:mdna:25]
Cost of Revenue and Gross Profit

[0001078271-12-000073:mdna:26]
The following table presents the gross profit on product and service revenue and the gross profit percentage of net

[0001078271-12-000073:mdna:27]
revenue for the fiscal years 2012, 2011 and 2010 (dollars in thousands):

[0001078271-12-000073:mdna:28]
|  | Three Months Ended |
|  | September 30, 2012 |  | October 2, 2011 |  | $Change |  | %Change |
| Gross profit: |  |  |  |  |  |  |  |
| Product | $ | 30,643 |  |  | $ | 33,735 |  |  | $ | (3,092 | ) |  | (9.2 | )% |
| Percentage of product revenue | 50.1 | % |  | 53.4 | % |  |  |  |  |
| Service | 9,332 |  |  | 9,801 |  |  | (469 | ) |  | (4.8 | )% |
| Percentage of service revenue | 62.2 | % |  | 62.5 | % |  |  |  |  |
| Total gross profit | $ | 39,975 |  |  | $ | 43,536 |  |  | $ | (3,561 | ) |  | (8.2 | )% |
| Percentage of net revenue | 52.5 | % |  | 55.2 | % |  |  |  |  |

[0001078271-12-000073:mdna:29]
Cost of product revenue includes costs of materials, amounts paid to third-party contract manufacturers, costs related to warranty obligations, charges for excess and obsolete inventory, royalties under technology license agreements, and internal costs associated with manufacturing overhead, including management, manufacturing engineering, quality assurance, development of test plans, and document control. We outsource substantially all of our manufacturing and supply chain management operations, and we conduct quality assurance, manufacturing engineering, document control and distribution at our facilities in Santa Clara, California, China, and Taiwan. Accordingly, a significant portion of our cost of product revenue consists of payments to our primary contract manufacturer, Alpha Networks, located in Hsinchu, Taiwan. In addition, we OEM our wireless product line from Motorola.

[0001078271-12-000073:mdna:30]
Product gross profit decreased slightly in the three months ended September 30, 2012 as compared to the corresponding period of fiscal 2012. Product gross margin declined to 50.1% from 53.4%, primary due to unfavorable product mix, an increase in charges for excess and obsolete inventory and, to a lesser extent, higher sales discounts and rebates.

[0001078271-12-000073:mdna:31]
Our cost of service revenue consists primarily of labor, overhead, repair and freight costs and the cost of spares used in providing support under customer service contracts. Service gross profit and gross margin were flat in the three months ended September 30, 2012 as compared to the corresponding period of fiscal 2012.

[0001078271-12-000073:mdna:32]
[same as prior period, unchanged from 0001078271-12-000025:mdna:38]

[0001078271-12-000073:mdna:33]
[same as prior period, unchanged from 0001078271-12-000025:mdna:39]

[0001078271-12-000073:mdna:34]
|  | Three Months Ended |
|  | September 30, 2012 |  | October 2, 2011 |  | $Change |  | %Change |
| Research and development | $ | 10,566 |  |  | $ | 12,408 |  |  | $ | (1,842 | ) |  | (14.8 | )% |
| Sales and marketing | 22,027 |  |  | 22,121 |  |  | (94 | ) |  | (0.4 | )% |
| General and administrative | 5,357 |  |  | 6,270 |  |  | (913 | ) |  | (14.6 | )% |
| Restructuring charge (credit), net of reversal | (10 | ) |  | 955 |  |  | (965 | ) |  | (101.0 | )% |
| Gain on sale of campus | (11,537 | ) |  | — |  |  | (11,537 | ) |  | 100.0 | % |
| Total operating expenses | $ | 26,403 |  |  | $ | 41,754 |  |  | $ | (15,351 | ) |  | (36.8 | )% |
| Operating income | $ | 13,572 |  |  | 1,782 |  |  | $ | 11,790 |  |  | 661.6 | % |

[0001078271-12-000073:mdna:35]
[same as prior period, unchanged from 0001078271-12-000025:mdna:41]

[0001078271-12-000073:mdna:36]
|  | Three Months Ended |
|  | September 30, 2012 |  | October 2, 2011 |
| Research and development | 13.9 | % |  | 15.7 | % |
| Sales and marketing | 28.9 | % |  | 28.0 | % |
| General and administrative | 7.0 | % |  | 8.0 | % |
| Restructuring charge (credit), net of reversal | — | % |  | 1.2 | % |
| Gain on sale of campus | (15.2 | )% |  | — | % |
| Total operating expenses | 34.6 | % |  | 52.9 | % |
| Operating income | 17.8 | % |  | 2.3 | % |

[0001078271-12-000073:mdna:37]
[same as prior period, unchanged from 0001078271-12-000025:mdna:46]

[0001078271-12-000073:mdna:38]
Research and development expenses consist primarily of salaries and related personnel expenses, consultant fees and prototype expenses related to the design, development, and testing of our products. Research and development expenses in the three months ended September 30, 2012 decreased by $1.8 million, or 15%, compared to the corresponding period of fiscal 2012. The decrease in research and development expenses was primarily attributable to lower spending on engineering project expenses, due to variability in the timing of planned spending on new product development projects.

[0001078271-12-000073:mdna:39]
[same as prior period, unchanged from 0001078271-12-000025:mdna:43]

[0001078271-12-000073:mdna:40]
Sales and marketing expenses consist of salaries, commissions and related expenses for personnel engaged in marketing and sales functions, as well as trade shows and promotional expenses.

[0001078271-12-000073:mdna:41]
Sales and marketing expenses in the three months ended September 30, 2012 decreased by $0.1 million, or 0.4%, compared to the corresponding period of fiscal 2012. The decrease in sales and marketing expenses was primarily due to lower personnel expenses and commissions, partially offset by increased spending on marketing programs.

[0001078271-12-000073:mdna:42]
[same as prior period, unchanged from 0001078271-12-000025:mdna:50]

[0001078271-12-000073:mdna:43]
General and administrative expenses in the three months ended September 30, 2012 decreased by $0.9 million, or 15%, compared to the corresponding period of fiscal 2012. The decrease in general and administrative expenses was primarily due to a decrease of $1.1 million in legal expenses attributable to the resolution of certain legal matters.

[0001078271-12-000073:mdna:44]
Restructuring Charge (Credit), Net of Reversal

[0001078271-12-000073:mdna:45]
Restructuring charges in the three months ended September 30, 2012 decreased by $1.0 million compared to the corresponding period of fiscal 2012.  The decrease in restructuring charges was primarily due to the fact we have expensed substantially all of the costs associated with the restructuring initiatives implemented in fiscal 2012. We did not have any restructuring activity in the first quarter of fiscal 2013. As of September 30, 2012, we had $0.3 million of restructuring liabilities remaining, which we anticipate paying by the end of fiscal 2013.

[0001078271-12-000073:mdna:46]
Gain on Campus Sale

[0001078271-12-000073:mdna:47]
During the quarter ended September 30, 2012, we completed the sale of our campus and accompanying 16 acres of land in Santa Clara, California for net cash proceeds of approximately $44.7 million. We realized a gain of $11.7 million in connection with this transaction, of which approximately $0.1 million was deferred and will be recognized on a ratable basis through January 31, 2013.

[0001078271-12-000073:mdna:48]
Other Income (Expense), net

[0001078271-12-000073:mdna:49]
Other expense, net in the three months ended September 30, 2012 increased by approximately $0.4 million compared to the corresponding period of fiscal 2012. The increase in other expense, net was primarily due to losses from the revaluation of certain assets and liabilities denominated in foreign currencies into U.S. dollars.

[0001078271-12-000073:mdna:50]
Provision for Income Taxes

[0001078271-12-000073:mdna:51]
We recorded an income tax provision of $0.6 million and an income tax provision of $0.5 million for the first quarter of fiscal 2013 and first quarter of fiscal 2012, respectively. The income tax provision for the first quarter of fiscal 2013 consisted primarily of taxes on foreign income and U.S. state income taxes. The income tax provision for the first quarter of fiscal 2012 consisted primarily of taxes on foreign income and U.S. state income taxes.  The income tax provisions for both quarters were

[0001078271-12-000073:mdna:52]
calculated based on the results of operations for the three months ended September 30, 2012 and October 2, 2011, and may not reflect the annual effective rate.

[0001078271-12-000073:mdna:53]
We have provided a full valuation allowance for our U.S. net deferred tax assets after assessing both negative and positive evidence when measuring the need for a valuation allowance. For the current quarter, evidence such as operating losses during the most recent three-year period was given more weight than our expectations of future profitability which are inherently uncertain.  Accordingly, we believe that there is sufficient negative evidence to maintain a full valuation allowance against our U.S. federal and state net deferred tax assets. This valuation allowance will be evaluated periodically and can be reversed partially or totally if business results have sufficiently improved to support realization of our U.S. deferred tax assets.

[0001078271-12-000073:mdna:54]
The sale of our buildings and land in Santa Clara, California during the quarter ended September 30, 2012 resulted in a tax loss that increased the amount of our deferred tax assets with a corresponding increase to the related valuation allowance.

[0001078271-12-000073:mdna:55]
[same as prior period, unchanged from 0001078271-12-000025:mdna:65]

[0001078271-12-000073:mdna:56]
[same as prior period, unchanged from 0001078271-12-000025:mdna:66]

[0001078271-12-000073:mdna:57]
As discussed in Part II, Item 7, “Management's Discussion and Analysis of Financial Condition and Results of Operations” of our Annual Report on Form 10-K for the year ended June 30, 2012, we consider the following accounting policies to be the most critical in understanding the judgments that are involved in preparing our consolidated financial statements:

[0001078271-12-000073:mdna:58]
[same as prior period, unchanged from 0001078271-12-000025:mdna:68]

[0001078271-12-000073:mdna:59]
[same as prior period, unchanged from 0001078271-12-000025:mdna:69]

[0001078271-12-000073:mdna:60]
[same as prior period, unchanged from 0001078271-12-000025:mdna:70]

[0001078271-12-000073:mdna:61]
[same as prior period, unchanged from 0001078271-12-000025:mdna:71]

[0001078271-12-000073:mdna:62]
[same as prior period, unchanged from 0001078271-12-000025:mdna:72]

[0001078271-12-000073:mdna:63]
[same as prior period, unchanged from 0001078271-12-000025:mdna:73]

[0001078271-12-000073:mdna:64]
[same as prior period, unchanged from 0001078271-12-000025:mdna:74]

[0001078271-12-000073:mdna:65]
| • | Legal Contingencies |

[0001078271-12-000073:mdna:66]
[same as prior period, unchanged from 0001078271-12-000025:mdna:76]

[0001078271-12-000073:mdna:67]
[same as prior period, unchanged from 0001078271-12-000025:mdna:79]

[0001078271-12-000073:mdna:68]
[same as prior period, unchanged from 0001078271-12-000025:mdna:80]

[0001078271-12-000073:mdna:69]
|  | September 30, 2012 |  | June 30, 2012 |
| Cash and cash equivalent | $ | 96,712 |  |  | $ | 54,596 |  |
| Short-term investments | 40,827 |  |  | 23,358 |  |
| Marketable securities | 65,065 |  |  | 75,561 |  |
| Total cash and investments | $ | 202,604 |  |  | $ | 153,515 |  |
| Working capital | $ | 116,378 |  |  | $ | 72,361 |  |

[0001078271-12-000073:mdna:70]
As of September 30, 2012, our principal sources of liquidity consisted of cash, cash equivalents and investments of $202.6 million and net accounts receivable of $34.7 million. Historically, our principal uses of cash have consisted of the purchase of finished goods inventory from our contract manufacturers, payroll and other operating expenses related to the development and marketing of our products and purchases of property and equipment. We believe that our $202.6 million of cash and cash equivalents and investments at September 30, 2012 will be sufficient to fund our operating requirements for at least the next 12 months.

[0001078271-12-000073:mdna:71]
[same as prior period, unchanged from 0001078271-12-000025:mdna:84]

[0001078271-12-000073:mdna:72]
[same as prior period, unchanged from 0001078271-12-000025:mdna:85]

[0001078271-12-000073:mdna:73]
|  | Three Months Ended |
|  | September 30, 2012 |  | October 2, 2011 |
| Net cash provided by (used in) operating activities | $ | 7,052 |  |  | $ | (3,944 | ) |
| Net cash provided by (used in) investing activities | $ | 34,031 |  |  | $ | (1,629 | ) |
| Net cash provided by financing activities | $ | 593 |  |  | $ | 620 |  |
| Foreign currency effect on cash | $ | 440 |  |  | $ | (805 | ) |
| Net increase (decrease) in cash and cash equivalents | $ | 42,116 |  |  | $ | (5,758 | ) |

[0001078271-12-000073:mdna:74]
Net Cash Provided by Operating Activities

[0001078271-12-000073:mdna:75]
Cash flows from operations increased by $11.0 million in the three months ended September 30, 2012 compared to the corresponding quarter of fiscal 2012, primarily due to purposeful reduction of inventory spending to bring inventory levels in line with the anticipated near-term demand for our products, and increased cash collections attributable to timing of cash receipts from customers.

[0001078271-12-000073:mdna:76]
Net Cash Provided by Investing Activities

[0001078271-12-000073:mdna:77]
Cash flow provided by investing activities in the three months ended September 30, 2012 was $34.0 million, comprised of $42.7 million of proceeds from the sale of buildings and land in Santa Clara California, offset by $7.1 million used to purchase investment securities and $1.6 million used to purchase property and equipment.

[0001078271-12-000073:mdna:78]
[same as prior period, unchanged from 0001078271-12-000025:mdna:91]

[0001078271-12-000073:mdna:79]
Cash flow provided by financing activities in the three months ended September 30, 2012 was $0.6 million, comprised of proceeds from the exercise of stock options and purchases of shares of our common stock under the ESPP, offset by taxes paid on vested and released stock awards.

[0001078271-12-000073:mdna:80]
[same as prior period, unchanged from 0001078271-12-000025:mdna:93]

[0001078271-12-000073:mdna:81]
Non-cancelable inventory purchase commitments represent the purchase of long lead-time component inventory that our contract manufacturers procure in accordance with our forecast. Inventory purchase commitments were $31.1 million as of September 30, 2012, a decrease of $7.7 million from $38.8 million as of June 30, 2012. We expect to honor the inventory purchase commitments within the next 12 months.

[0001078271-12-000073:mdna:82]
We did not have any material commitments for capital expenditures as of September 30, 2012. Other non-cancelable purchase commitments represent OEM and technology agreements.

[0001078271-12-000073:mdna:83]
As of September 30, 2012, we had $0.5 million of income tax liabilities for which we are unable to reasonably estimate the timing of settlement.

[0001078271-12-000073:mdna:84]
[same as prior period, unchanged from 0001078271-12-000025:mdna:96]

[0001078271-12-000073:mdna:85]
We did not have any off-balance sheet arrangements as of September 30, 2012.
