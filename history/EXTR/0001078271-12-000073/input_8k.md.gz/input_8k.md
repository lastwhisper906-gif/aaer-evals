# EXTR 8-K — 0001078271-12-000071 filed 2012-10-31

## item codes, every 8-K on or before 2012-11-01

- 2012-10-31 0001078271-12-000071 — 2.02, 9.01
- 2012-10-19 0001078271-12-000069 — 1.01, 2.03, 9.01
- 2012-10-16 0001078271-12-000067 — 8.01
- 2012-10-01 0001193125-12-411392 — 5.02, 8.01, 9.01
- 2012-09-24 0001193125-12-401798 — 5.02, 9.01
- 2012-09-21 0001193125-12-399896 — 5.02, 9.01
- 2012-09-18 0001193125-12-394379 — 1.01, 5.02, 9.01
- 2012-09-12 0001193125-12-388591 — 8.01
- 2012-08-27 0001078271-12-000057 — 8.01
- 2012-08-03 0001078271-12-000041 — 7.01, 9.01
- 2012-08-01 0001078271-12-000039 — 2.02, 9.01
- 2012-07-25 0001078271-12-000037 — 8.01
- 2012-05-22 0001078271-12-000033 — 5.02, 9.01
- 2012-05-21 0001078271-12-000030 — 8.01
- 2012-05-09 0001078271-12-000028 — 5.02, 9.01
- 2012-05-02 0001078271-12-000023 — 2.02, 9.01
- 2012-04-30 0001078271-12-000020 — 3.03, 5.07, 9.01
- 2012-04-19 0001078271-12-000012 — 2.02, 5.02, 9.01
- 2012-03-12 0001078271-12-000010 — 5.02, 9.01
- 2012-02-24 0001078271-12-000008 — 8.01
- 2012-02-02 0001078271-12-000004 — 2.02, 9.01
- 2012-01-30 0001078271-12-000002 — 1.01
- 2011-12-01 0001078271-11-000104 — 8.01
- 2011-11-08 0001078271-11-000099 — 8.01
- 2011-11-02 0001078271-11-000094 — 2.02, 9.01
- 2011-10-24 0001078271-11-000089 — 8.01, 9.01
- 2011-10-11 0001078271-11-000085 — 8.01
- 2011-09-29 0001078271-11-000082 — 8.01
- 2011-09-15 0001078271-11-000070 — 5.02, 9.01
- 2011-08-11 0001078271-11-000058 — 8.01
- 2011-08-10 0001078271-11-000055 — 5.02
- 2011-08-08 0001078271-11-000045 — 5.02
- 2011-08-01 0001078271-11-000038 — 2.02, 9.01
- 2011-07-14 0001078271-11-000036 — 2.02, 2.05, 9.01
- 2011-07-12 0001078271-11-000034 — 8.01
- 2011-07-01 0001078271-11-000032 — 5.02
- 2011-06-16 0001078271-11-000030 — 8.01
- 2011-05-06 0001078271-11-000027 — 8.01, 9.01
- 2011-05-04 0001078271-11-000025 — 8.01
- 2011-04-28 0001078271-11-000020 — 2.02, 9.01
- 2011-04-27 0001078271-11-000018 — 3.03, 5.02, 5.03, 9.01
- 2011-04-11 0001078271-11-000016 — 2.02
- 2011-03-31 0001078271-11-000014 — 5.02, 5.03
- 2011-03-15 0001193125-11-066049 — 5.02, 9.01
- 2011-03-01 0001193125-11-052048 — 5.02, 9.01
- 2011-02-10 0001078271-11-000012 — 7.01, 9.01
- 2011-01-31 0001078271-11-000005 — 2.02, 5.02, 5.03, 9.01
- 2010-12-23 0001193125-10-287613 — 8.01
- 2010-12-17 0001193125-10-283495 — 5.03, 5.07, 8.01, 9.01
- 2010-11-10 0001193125-10-255861 — 4.01, 9.01
- 2010-11-01 0001193125-10-242706 — 2.02, 9.01
- 2010-10-14 0001193125-10-229518 — 1.01, 9.01
- 2010-10-06 0001193125-10-224863 — 5.02, 8.01
- 2010-09-29 0001193125-10-219705 — 1.01, 8.01
- 2010-09-08 0001193125-10-206782 — 5.02, 8.01, 9.01
- 2010-08-25 0001193125-10-196951 — 8.01
- 2010-08-09 0001193125-10-182573 — 7.01, 8.01, 9.01
- 2010-08-03 0001193125-10-175255 — 5.02, 8.01, 9.01
- 2010-08-02 0001193125-10-173697 — 2.02, 8.01, 9.01
- 2010-07-30 0001193125-10-172214 — 5.02, 8.01, 9.01
- 2010-07-22 0001193125-10-163896 — 8.01, 9.01
- 2010-07-20 0001193125-10-161832 — 5.02
- 2010-07-12 0001193125-10-157291 — 2.02, 9.01
- 2010-07-01 0001193125-10-152746 — 3.03, 9.01
- 2010-05-10 0001193125-10-114669 — 5.02, 9.01
- 2010-04-26 0001193125-10-093310 — 2.02, 9.01
- 2010-03-19 0001193125-10-061679 — 5.02, 9.01
- 2010-02-16 0001193125-10-032335 — 5.02
- 2010-02-01 0001193125-10-018202 — 2.02, 9.01
- 2010-01-29 0001193125-10-017165 — 5.02
- 2010-01-11 0001193125-10-004099 — 8.01
- 2009-10-26 0001193125-09-213846 — 2.02, 9.01 — amendment of 0001193125-09-213780
- 2009-10-26 0001193125-09-213780 — 2.02, 9.01
- 2009-10-23 0001193125-09-212871 — 2.05, 5.02, 8.01, 9.01
- 2009-10-05 0001193125-09-203522 — 2.02, 9.01
- 2009-08-04 0001193125-09-163799 — 5.02, 9.01
- 2009-07-31 0001193125-09-160772 — 5.02, 9.01
- 2009-07-30 0001193125-09-159578 — 2.02, 9.01
- 2009-07-20 0001193125-09-151500 — 5.02, 9.01
- 2009-07-08 0001193125-09-145840 — 5.02, 9.01
- 2009-05-12 0001193125-09-108340 — 5.02, 9.01
- 2009-04-23 0001193125-09-085849 — 2.02, 9.01
- 2009-03-26 0001193125-09-064502 — 2.05
- 2009-01-28 0001193125-09-013182 — 2.02, 9.01
- 2008-11-06 0001193125-08-227572 — 2.02, 9.01
- 2008-11-03 0001193125-08-222501 — 5.02
- 2008-08-11 0001193125-08-173590 — 5.02
- 2008-08-11 0001193125-08-172587 — 8.01, 9.01
- 2008-08-06 0001193125-08-167934 — 2.02, 9.01
- 2008-08-04 0001193125-08-164673 — 5.02, 9.01
- 2008-05-21 0001193125-08-119640 — 7.01, 9.01
- 2008-04-29 0001193125-08-095270 — 2.02, 9.01
- 2008-03-05 0001193125-08-047893 — 8.01
- 2008-02-19 0001193125-08-033702 — 5.02
- 2008-02-05 0001193125-08-019969 — 5.02
- 2008-01-30 0001193125-08-015378 — 2.02, 9.01
- 2007-12-27 0001193125-07-272178 — 5.03, 9.01
- 2007-10-29 0001193125-07-228368 — 2.02, 9.01
- 2007-10-25 0001193125-07-225906 — 5.02, 9.01
- 2007-10-19 0001193125-07-221578 — 5.02
- 2007-09-26 0001193125-07-207348 — 8.01
- 2007-08-07 0001193125-07-172810 — 2.02, 9.01
- 2007-08-06 0001193125-07-172147 — 5.02, 9.01
- 2007-08-06 0001193125-07-172134 — 3.01
- 2007-07-09 0001193125-07-151467 — 3.01, 9.01
- 2007-06-28 0001193125-07-145519 — 2.02, 9.01
- 2007-06-27 0001193125-07-143262 — 2.05, 3.01, 5.02
- 2007-05-18 0001193125-07-118804 — 3.01, 9.01
- 2007-05-02 0001193125-07-099280 — 2.02, 9.01
- 2007-03-29 0001193125-07-068815 — 5.02, 9.01
- 2007-02-22 0001193125-07-037181 — 3.01, 9.01
- 2007-02-08 0001193125-07-024194 — 5.02
- 2007-01-30 0001193125-07-016428 — 2.02, 9.01
- 2007-01-11 0001193125-07-004825 — 4.02, 9.01
- 2006-11-21 0001193125-06-240068 — 5.02, 9.01
- 2006-11-16 0001193125-06-237262 — 3.01, 9.01
- 2006-11-01 0001193125-06-220707 — 2.02, 9.01
- 2006-10-31 0001193125-06-219237 — 1.01, 1.02, 5.02, 5.03, 8.01, 9.01
- 2006-09-28 0001193125-06-198185 — 3.01, 9.01
- 2006-09-15 0001193125-06-191640 — 7.01, 9.01
- 2006-09-05 0001193125-06-185202 — 5.02, 9.01
- 2006-08-08 0001193125-06-165953 — 1.01, 2.02, 5.02, 9.01
- 2006-07-18 0001193125-06-148526 — 1.01
- 2006-07-10 0001193125-06-143989 — 5.02, 9.01
- 2006-05-16 0001193125-06-113698 — 5.02, 9.01
- 2006-05-01 0001193125-06-094919 — 2.02, 9.01
- 2006-04-26 0001193125-06-089397 — 1.01, 9.01
- 2006-04-07 0001193125-06-075723 — 2.02, 9.01
- 2006-02-13 0001193125-06-029073 — 1.01
- 2006-01-31 0001193125-06-016143 — 1.01
- 2006-01-30 0001193125-06-015165 — 2.02, 9.01
- 2005-12-08 0001193125-05-239157 — 1.01, 1.02, 9.01
- 2005-11-01 0001193125-05-213101 — 2.02, 9.01
- 2005-09-29 0001193125-05-193991 — 1.01, 2.02, 9.01 — amendment of 0001193125-05-162807
- 2005-08-09 0001193125-05-162807 — 1.01, 2.02, 9.01
- 2005-07-14 0001193125-05-142162 — 8.01
- 2005-06-28 0001193125-05-133050 — 1.01, 9.01
- 2005-04-18 0001193125-05-077946 — 2.02, 7.01, 9.01
- 2005-04-14 0001193125-05-076665 — 2.02, 7.01, 9.01
- 2005-01-25 0001193125-05-011466 — 2.02, 9.01
- 2004-12-07 0001193125-04-208693 — 3.01
- 2004-10-26 0001193125-04-178370 — 2.02, 9.01
- 2004-10-04 0001193125-04-166289 — 5.02, 9.01
- 2004-07-28 0001193125-04-126135 — 12, 7
- 2004-05-12 0001193125-04-086287 — 12
- 2004-04-21 0001193125-04-066557 — 12, 7
- 2004-01-22 0001193125-04-007359 — 12, 7
- 2003-12-18 0001193125-03-096351 — 5, 7
- 2003-11-04 0001193125-03-072069 — 5, 7
- 2003-10-24 0001193125-03-066551 — 12, 7
- 2003-07-25 0001193125-03-024087 — 7, 9
- 2003-04-11 0001012870-03-001706 — 7, 9
- 2003-04-08 0001021408-03-005743 — 7, 9
- 2003-01-07 0001012870-03-000039 — 5, 7
- 2002-04-29 0001012870-02-002003 — 5, 7
- 2002-02-20 0001012870-02-000792 — 5, 7
- 2001-12-13 0001012870-01-503160 — 5, 7
- 2001-11-30 0001012870-01-503010 — 5, 7
- 2001-11-02 0001012870-01-502580 — 5
- 2001-10-23 0001021408-01-508589 — 5, 7
- 2001-06-07 0001021408-01-501772 — 5, 7 — amendment of 0001021408-01-500975
- 2001-05-15 0001021408-01-501104 — 5 — amendment of 0001021408-01-500975
- 2001-05-14 0001021408-01-500975 — 5, 7
- 2001-04-06 0001012870-01-500065 — 5, 7

## late-filing notifications on or before 2012-11-01

- 2008-05-12 0001193125-08-111540 — NT 10-Q, for the period ended 2008-03-30
- 2007-05-10 0001193125-07-110075 — NT 10-Q, for the period ended 2007-04-01
- 2007-02-09 0001193125-07-025490 — NT 10-Q, for the period ended 2006-12-31
- 2006-11-13 0001193125-06-232090 — NT 10-Q, for the period ended 2006-10-01
- 2006-09-15 0001193125-06-191838 — NT 10-K, for the period ended 2006-07-02

## item 2.02 — earnings release, exhibit 99.1

[0001078271-12-000071:8k_2_02:1]
EX-99.1
2
ex99-1q113earningsrelease.htm
PRESS RELEASE

[0001078271-12-000071:8k_2_02:2]
Ex 99-1 Q1'13 Earnings Release

[0001078271-12-000071:8k_2_02:3]
FOR IMMEDIATE RELEASE

[0001078271-12-000071:8k_2_02:4]
| For more information, contact: |  |  |
| Extreme Networks |  |  |
| Investor Relations |  | Public Relations |
| 408/579-3030 |  | 408/579-3483 |
| investor_relations@extremenetworks.com |  | gcross@extremenetworks.com |

[0001078271-12-000071:8k_2_02:5]
Extreme Networks Reports First Quarter and Fiscal Year 2013 Financial Results

[0001078271-12-000071:8k_2_02:6]
SANTA CLARA, Calif., October 31, 2012 /PRNewswire/ -- Extreme Networks, Inc. (Nasdaq: EXTR) today announced revenue of $76.1 million for its first quarter of fiscal 2013 ending September 30, 2012. This represents a 3.5% decrease compared to revenue of $78.9 million reported for the first quarter of fiscal 2012 and a 13.1% decrease compared to the fourth quarter of fiscal 2012. GAAP net income for the first quarter was $12.9 million, or $0.14 per diluted share, an increase year-over-year compared to GAAP net income of $1.6 million, or $0.02 per diluted share, for the first quarter of fiscal 2012. On a non-GAAP basis, net income for the first quarter of fiscal 2013 was $3.5 million, or $0.04 per diluted share, compared to non-GAAP net income for the first quarter of fiscal 2012 of $4.4 million, or $0.05 per diluted share.

[0001078271-12-000071:8k_2_02:7]
“Q1 results were in-line with our targets and we are encouraged by customer and partner response related to our strategy and products released earlier in the calendar year,” stated Oscar Rodriguez, President and CEO of Extreme Networks.  “Our goal is to grow revenues while continually refining our cost structure and enhancing our selling efforts to deliver superior products that we believe provide both a technology and cost advantage for both new and existing customers.”

[0001078271-12-000071:8k_2_02:8]
Q1 2013 Financial Metrics:

[0001078271-12-000071:8k_2_02:9]
|  |  | First Quarter |  |  |  |  |
|  |  | (in millions, except per share amounts and percentages) |  |  |  |  |
|  |  | (unaudited) |  |  |  |  |
|  |  | 2013 |  | 2012 |  | Change |
| Net Revenue |  |  |  |  |  |  |  |  |
| Product |  | $ | 61.1 |  |  | $ | 63.2 |  |  | $ | (2.1 | ) |  | (3 | )% |
| Service |  | $ | 15.0 |  |  | $ | 15.7 |  |  | $ | (0.7 | ) |  | (4 | )% |
| Total Net Revenue |  | $ | 76.1 |  |  | $ | 78.9 |  |  | $ | (2.8 | ) |  | (4 | )% |
| GAAP |  |  |  |  |  |  |  |  |
| Gross Margin |  | 53 | % |  | 55 | % |  | (2 | )% |  |  |
| Operating Margin/Loss |  | 18 | % |  | 2 | % |  | 16 | % |  |  |
| Net Income |  | $ | 12.9 |  |  | $ | 1.6 |  |  | $ | 11.3 |  |  |  |
| Earnings per diluted share |  | $ | 0.14 |  |  | $ | 0.02 |  |  | $ | 0.12 |  |  |  |
| Non-GAAP |  |  |  |  |  |  |  |  |
| Gross Margin |  | 53 | % |  | 56 | % |  | (3 | )% |  |  |
| Operating Margin |  | 6 | % |  | 6 | % |  | — | % |  |  |
| Net Income |  | $ | 3.5 |  |  | $ | 4.4 |  |  | $ | (0.9 | ) |  |  |
| Earnings per diluted share |  | $ | 0.04 |  |  | $ | 0.05 |  |  | $ | (0.01 | ) |  |  |

[0001078271-12-000071:8k_2_02:10]
| • | Gross margin for Q1 was 53% and included $1.5 million or two points of gross margin and $0.02 per diluted share for the write off of excess and obsolete inventory related to wireless products. |

[0001078271-12-000071:8k_2_02:11]
| • | The company completed the sale of its Santa Clara buildings and land for $46 million and recorded a gain on the sale of the facilities of $11.6 million which was recorded as a reduction to GAAP operating expenses and was excluded from non-GAAP operating expenses, non-GAAP net income and non-GAAP earnings per diluted share. |

[0001078271-12-000071:8k_2_02:12]
| • | Cash and investments ended the quarter at $202.6 million, as compared to $153.5 million from Q4 of fiscal 2012. The cash increase includes $42.7 million from the sale of the Santa Clara headquarters campus and $5.5 million of free cash flow. |

[0001078271-12-000071:8k_2_02:13]
| • | Accounts receivable balance ending Q1 was $34.7 million, a (net) decrease of $6.5 million from Q4 of fiscal 2012, with days sales outstanding (DSO) of 41, a decrease of 1 day from Q4 of fiscal 2012. |

[0001078271-12-000071:8k_2_02:14]
| • | Inventory ending Q1 was $22.8 million, a (net) decrease of $3.9 million from Q4 of fiscal 2012 and represents 57 days of inventory (DOI), a decrease of 15 days from Q4 of fiscal 2012. |

[0001078271-12-000071:8k_2_02:15]
Recent Business Highlights:

[0001078271-12-000071:8k_2_02:16]
| • | Nancy Shemwell joined the company's management team as executive vice president of Global Sales. |

[0001078271-12-000071:8k_2_02:17]
| • | Extreme Networks BlackDiamond® X8 switch is was certified by Superna™, which has been authorized by VCE to provide Vblock system certifications, to locally cluster Vblock systems to enable VMware Vmotion capabilities and provide Disaster Recovery and Avoidance over Ethernet. |

[0001078271-12-000071:8k_2_02:18]
| • | 10G Ethernet port bookings increased 180% over the last 12 months, while total market growth for 10G Ethernet ports is estimated by Dell'Oro to grow at 66% in calendar year 2012. |

[0001078271-12-000071:8k_2_02:19]
| • | An initial $75 million share repurchase plan was announced which represents the initial capital authorization for the next three years and will be reviewed at least annually by the Board of Directors. This will be funded from cash on hand. |

[0001078271-12-000071:8k_2_02:20]
Business Outlook:

[0001078271-12-000071:8k_2_02:21]
For its second quarter of fiscal 2013 ending December 31, 2012, the company is targeting revenue in a range of $78 million to $85 million with GAAP and non-GAAP gross margin targeted to be 55% +/-. Operating expenses are targeted to increase by $2.0 million to $3.0 million on a GAAP basis and by $2.5 million to $3.5 million on a non-GAAP basis. GAAP net income is targeted at $2.5 million to $4.0 million, or $0.02 to $0.05 per diluted share. Non-GAAP net income is targeted in a range of $4.0 million to $6.5 million, or $0.04 to $0.07 per diluted share. The GAAP and non-GAAP net income targets are based on an estimated 96 million +/- diluted weighted average shares. Targeted non-GAAP earnings exclude expenses related to stock-based compensation expense.

[0001078271-12-000071:8k_2_02:22]
Financial Model Goals:

[0001078271-12-000071:8k_2_02:23]
The company is targeting a quarterly financial model with the goal of achieving non-GAAP gross margins of 56% +/- and for non-GAAP operating income of 10% +/-, at a revenue level in the low $80 million range by the end of fiscal 2013.  To help achieve this goal, the company intends to focus on growing its revenue with higher performing and lower cost products as well as further realigning its operating cost structure around this set of products.

[0001078271-12-000071:8k_2_02:24]
The schedules attached to this release are an integral part of the release.

[0001078271-12-000071:8k_2_02:25]
Conference Call:

[0001078271-12-000071:8k_2_02:26]
Extreme Networks will host a conference call at 5:00 p.m. Eastern (2:00 p.m. Pacific) today to review the highlights of the first fiscal quarter 2013 business outlook, including significant factors and assumptions underlying the targets noted above. The conference call will be available to the public through a live audio web broadcast via the Internet at http://investor.extremenetworks.com and a replay of the call will be available on the website through November 13th, 2012.  The conference call may also be heard by dialing 1-877-303-9826 (international callers' dial 1-224-357 2194). Supplemental financial information to be discussed during the conference call will be posted in the Investor Relations section of the company's website www.extremenetworks.com including the non-GAAP reconciliation attached to this press release.

[0001078271-12-000071:8k_2_02:27]
About Extreme Networks:

[0001078271-12-000071:8k_2_02:28]
Extreme Networks is a technology leader in high-performance Ethernet switching for cloud, data center and mobile networks.  Based in Santa Clara, CA, Extreme Networks has more than 6,000 customers in over 50 countries.  Extreme Networks is a trademark or registered trademark of Extreme Networks, Inc. in the United States and/or other countries.

[0001078271-12-000071:8k_2_02:29]
For additional product and company information, please refer to www.extremenetworks.com.

[0001078271-12-000071:8k_2_02:30]
Non-GAAP Financial Measures:

[0001078271-12-000071:8k_2_02:31]
Extreme Networks provides all financial information required in accordance with generally accepted accounting principles (GAAP). To supplement its consolidated financial statements presented in accordance with GAAP, the company is also providing with this press release non-GAAP net income/(loss) and non-GAAP operating income/(loss). In preparing non-GAAP information, the company has excluded, where applicable, the impact of restructuring charges, share-based compensation and litigation settlements.  The company believes that excluding these items provides both management and investors with additional insight into its current operations, the trends affecting the company and the company's marketplace performance. In particular, management finds it useful to exclude these items in order to more readily correlate the company's operating activities with the company's ability to generate cash from operations. Accordingly, management uses these non-GAAP measures, along with the comparable GAAP information, in evaluating the company's historical performance and in planning its future business activities. Please note that the company's non-GAAP measures may be different than those used by other companies. The additional non-GAAP financial information the company presents should be considered in conjunction with, and not as a substitute for, the company's financial information presented in accordance with GAAP.  The company has provided a non-GAAP reconciliation of the Condensed Consolidated Statement of Operations for the periods presented in this release, which are adjusted to exclude restructuring charges, share-based compensation expense and litigation settlements for these periods. These measures should only be used to evaluate the company's results of operations in

[0001078271-12-000071:8k_2_02:32]
conjunction with the corresponding GAAP measures for comparable financial information and understanding of the company's ongoing performance as a business. Extreme Networks uses both GAAP and non-GAAP measures to evaluate and manage its operations.

[0001078271-12-000071:8k_2_02:33]
Forward Looking Statements:

[0001078271-12-000071:8k_2_02:34]
Actual results, including with respect to the company's financial targets and general business prospects, could differ materially due to a number of factors, including the risk that the company may not obtain sufficient orders to achieve targeted revenues for the company's products and services given both increasing price competition in key network switching equipment markets and the need to align the company's cost structure to meet the company's financial goals; the company's effectiveness in controlling expenses, the risk that it or its distributors and other channel partners are not able to develop and expand customer bases and accurately anticipate demand from end customers, which can result in increased inventory and reduced orders as it experiences wide fluctuations in supply and demand; the risk that its results will suffer if it is  unable to balance fluctuations in customer demand and capacity; risks associated with the ramp-up of production of its new products and its entry into new business channels different from those in which it has historically operated; the risk that it may experience production delays that preclude it from shipping sufficient quantities to meet customer orders or that result in higher production costs and lower margins; ongoing uncertainty in global economic conditions, infrastructure development or customer demand that could negatively affect product demand, collectability of receivables and other related matters as consumers and businesses may defer purchases or payments, or default on payments; its ability to complete development and commercialization of products under development, such as its pipeline of new network switches and related software; its ability to lower costs; risks resulting from the concentration of business among few customers, including the risk that customers may reduce or cancel orders or fail to honor purchase commitments; the rapid development of new technology and competing products that may impair demand or render its products obsolete; the potential lack of customer acceptance for new products; and risks associated with ongoing litigation; a dependency on third parties for certain components and for the manufacturing of the company's products. More information about potential factors that could affect the company's business and financial results is included in its filings with the Securities and Exchange Commission, including, without limitation, under the captions: “Management's Discussion and Analysis of Financial Condition and Results of Operations,” and “Risk Factors,” which are on file with the Securities and Exchange Commission. Except as required under the U.S. federal securities laws and the rules and regulations of the SEC, Extreme Networks disclaims any obligation to update any forward-looking statements after the date of this release, whether as a result of new information, future events, developments, changes in assumptions or otherwise.

[0001078271-12-000071:8k_2_02:35]
EXTREME NETWORKS, INC.

[0001078271-12-000071:8k_2_02:36]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0001078271-12-000071:8k_2_02:37]
(In thousands, except share and per share amounts)

[0001078271-12-000071:8k_2_02:38]
|  | September 30, 2012 |  | June 30, 2012 |
|  | (unaudited) |  | (1) |
| ASSETS |  |  |  |
| Current assets: |  |  |  |
| Cash and cash equivalents | $ | 96,712 |  |  | $ | 54,596 |  |
| Short-term investments | 40,827 |  |  | 23,358 |  |
| Accounts receivable, net of allowances of $1,199 at September 30, 2012 and $1,646 at June 30, 2012 | 34,706 |  |  | 41,166 |  |
| Inventories, net | 22,754 |  |  | 26,609 |  |
| Deferred income taxes | 494 |  |  | 644 |  |
| Prepaid expenses and other current assets, net | 5,778 |  |  | 5,655 |  |
| Assets held for sale | — |  |  | 17,081 |  |
| Total current assets | 201,271 |  |  | 169,109 |  |
| Property and equipment, net | 9,214 |  |  | 25,180 |  |
| Marketable securities | 65,065 |  |  | 75,561 |  |
| Intangible assets | 5,003 |  |  | 5,106 |  |
| Other assets, net | 9,360 |  |  | 9,634 |  |
| Total assets | $ | 289,913 |  |  | $ | 284,590 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |  |  |  |
| Current liabilities: |  |  |  |
| Accounts payable | $ | 11,820 |  |  | $ | 19,437 |  |
| Accrued compensation and benefits | 11,564 |  |  | 13,409 |  |
| Restructuring liabilities | 347 |  |  | 463 |  |
| Accrued warranty | 2,971 |  |  | 2,871 |  |
| Deferred revenue, net | 30,007 |  |  | 31,769 |  |
| Deferred distributors revenue, net of deferred cost of sales to distributors | 15,752 |  |  | 15,319 |  |
| Other accrued liabilities | 12,432 |  |  | 13,480 |  |
| Total current liabilities | 84,893 |  |  | 96,748 |  |
| Deferred revenue, less current portion | 7,284 |  |  | 7,559 |  |
| Other long-term liabilities | 890 |  |  | 643 |  |
| Commitments and contingencies |  |  |  |
| Stockholders’ equity | 196,846 |  |  | 179,640 |  |
| Total liabilities and stockholders’ equity | $ | 289,913 |  |  | $ | 284,590 |  |

[0001078271-12-000071:8k_2_02:39]
(1) The information in this column is derived from the company's consolidated balance sheet included in the company's Annual Report on Form 10-K for the year ended June 30, 2012.

[0001078271-12-000071:8k_2_02:40]
EXTREME NETWORKS, INC.

[0001078271-12-000071:8k_2_02:41]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS

[0001078271-12-000071:8k_2_02:42]
(In thousands, except per share amounts)

[0001078271-12-000071:8k_2_02:43]
|  | Three Months Ended |
|  | September 30, 2012 |  | October 2, 2011 |
|  | (unaudited) |  | (unaudited) |
| Net revenues: |  |  |  |
| Product | $ | 61,119 |  |  | $ | 63,213 |  |
| Service | 15,008 |  |  | 15,681 |  |
| Total net revenues | 76,127 |  |  | 78,894 |  |
| Cost of revenues: |  |  |  |
| Product | 30,476 |  |  | 29,478 |  |
| Service | 5,676 |  |  | 5,880 |  |
| Total cost of revenues | 36,152 |  |  | 35,358 |  |
| Gross profit: |  |  |  |
| Product | 30,643 |  |  | 33,735 |  |
| Service | 9,332 |  |  | 9,801 |  |
| Total gross profit | 39,975 |  |  | 43,536 |  |
| Operating expenses: |  |  |  |
| Research and development | 10,566 |  |  | 12,408 |  |
| Sales and marketing | 22,027 |  |  | 22,121 |  |
| General and administrative | 5,357 |  |  | 6,270 |  |
| Gain on sale of facilities | (11,537 | ) |  | — |  |
| Restructuring charge (credit), net of reversals | (10 | ) |  | 955 |  |
| Total operating expenses | 26,403 |  |  | 41,754 |  |
| Operating income | 13,572 |  |  | 1,782 |  |
| Interest income | 269 |  |  | 293 |  |
| Interest expense | (1 | ) |  | (37 | ) |
| Other income (expense) | (348 | ) |  | 57 |  |
| Income before income taxes | 13,492 |  |  | 2,095 |  |
| Provision for income taxes | 577 |  |  | 512 |  |
| Net income | $ | 12,915 |  |  | $ | 1,583 |  |
| Basic and diluted net income (loss) per share: |  |  |  |
| Net income per share - basic | $ | 0.14 |  |  | $ | 0.02 |  |
| Net income per share - diluted | $ | 0.14 |  |  | $ | 0.02 |  |
| Shares used in per share calculation - basic | 94,738 |  |  | 92,768 |  |
| Shares used in per share calculation - diluted | 95,499 |  |  | 94,055 |  |

[0001078271-12-000071:8k_2_02:44]
EXTREME NETWORKS, INC.

[0001078271-12-000071:8k_2_02:45]
CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS

[0001078271-12-000071:8k_2_02:46]
(In thousands)

[0001078271-12-000071:8k_2_02:47]
|  | Three Months Ended |
|  | September 30, 2012 |  | October 2, 2011 |
|  | (unaudited) |  | (unaudited) |
| Net cash provided by (used in) operating activities | $ | 7,052 |  |  | $ | (3,944 | ) |
| Cash flows provided by (used in) investing activities: |  |  |  |
| Capital expenditures | (1,562 | ) |  | (748 | ) |
| Purchases of investments | (7,066 | ) |  | (21,096 | ) |
| Proceeds from maturities of investments and marketable securities | — |  |  | 10,300 |  |
| Proceeds from sales of investments and marketable securities | — |  |  | 9,915 |  |
| Proceeds from sales of facilities | 42,659 |  |  | — |  |
| Net cash provided by (used in) investing activities | 34,031 |  |  | (1,629 | ) |
| Cash flows provided by financing activities: |  |  |  |
| Proceeds from issuance of common stock | 593 |  |  | 620 |  |
| Net cash provided by financing activities | 593 |  |  | 620 |  |
| Foreign currency effect on cash | 440 |  |  | (805 | ) |
| Net increase (decrease) in cash and cash equivalents | 42,116 |  |  | (5,758 | ) |
| Cash and cash equivalents at beginning of period | 54,596 |  |  | 49,972 |  |
| Cash and cash equivalents at end of period | $ | 96,712 |  |  | $ | 44,214 |  |

[0001078271-12-000071:8k_2_02:48]
Extreme Networks, Inc.

[0001078271-12-000071:8k_2_02:49]
Non-GAAP Measures of Financial Performance

[0001078271-12-000071:8k_2_02:50]
To supplement the company's consolidated financial statements presented in accordance with generally accepted accounting principles, or GAAP, Extreme Networks uses non-GAAP measure of certain components of financial performance.  These non-GAAP measures include non-GAAP net income, non-GAAP earnings per diluted share, non-GAAP gross margin, non-GAAP operating expenses and free cash flow.

[0001078271-12-000071:8k_2_02:51]
Reconciliation to the nearest GAAP measure of all historical non-GAAP measures included in this press release can be found in the tables included with this press release.  In this press release, Extreme Networks also presents its target for non-GAAP expenses, which is expenses less stock based compensation expense, litigation settlements, restructuring expenses and gains related to the sale of the Santa Clara campus.

[0001078271-12-000071:8k_2_02:52]
Non-GAAP measures presented in this press release are not in accordance with or an alternative measures prepared in accordance with GAAP and may be different from non-GAAP measures used by other companies.  In addition these, non-GAAP measures are not based on any comprehensive set of accounting rules or principles.  Non-GAAP measures have limitations in that they do not reflect all of the amounts associated with Extreme Networks' results of operations as determined in accordance with GAAP.  These non-GAAP measures should only be used to evaluate Extreme Networks' results of operations in conjunction with the corresponding GAAP measures.

[0001078271-12-000071:8k_2_02:53]
Extreme Networks believes that these non-GAAP measures when shown in conjunction with the corresponding GAAP measures enhance investors' and management's overall understanding of the company's current financial performance and the company's prospects for the future, including cash flows available for the future, including cash flows available to pursue opportunities to enhance shareholder value.  In addition, because Extreme Networks has historically reported certain non-GAAP results to investors, the company believes that the inclusion of non-GAAP measures provides consistency in the company's financial reporting.

[0001078271-12-000071:8k_2_02:54]
For its internal planning process, and as discussed further below, Extreme Network's management uses financial statements that do not include stock-based compensation expense, litigation settlement expenses, restructuring expenses or gains related to the sale of the Santa Clara campus.   Extreme Networks' management also uses non-GAAP measures, in addition to the corresponding GAAP measures, in reviewing the company's financial results.

[0001078271-12-000071:8k_2_02:55]
As described above, Extreme Networks excludes the following items from one or more of its non-GAAP measures when applicable.

[0001078271-12-000071:8k_2_02:56]
Stock based compensation expense. This expense consists of expenses for stock options, restricted stock and employee stock purchases through its ESPP.  Extreme Networks excludes stock based compensation expenses from its non-GAAP measures primarily because they are non-cash expenses that the company does not believe are reflective of ongoing operating results.

[0001078271-12-000071:8k_2_02:57]
Restructuring expenses. Restructuring expense primarily consist of cash severance and termination benefits. Extreme Networks excludes restructuring expenses since they result from events that often occur outside of the ordinary course of continuing operations.

[0001078271-12-000071:8k_2_02:58]
Gains related to the sale of the Santa Clara Campus.  The one-time net gain related to the sale of the Santa Clara campus consist of the gross proceeds of the sale less the expenses directly related to the sale such as commissions, closing costs and legal fees.  Extreme Networks excludes this gain because it is a one-time event and does not believe that the gain is reflective of ongoing operations.

[0001078271-12-000071:8k_2_02:59]
Extreme Networks expects to incur stock-based compensation expenses in future periods.  In addition to the non-GAAP measures discussed above, Extreme Networks also uses free cash flow as a measure of operating performance.  Free cash flow represents operating cash flows less net purchase of property and equipment.  Extreme Networks considers free cash flows to be a liquidity measure that provides useful information to management and investors about the amount of cash generated by the business after the purchases of property and equipment, which can then be used to, among other things, invest in Extreme Networks business, make strategic acquisitions, strengthen the balance sheet and repurchase stock.  A limitation of the utility of free cash slows as a measure of financial performance is that it does not represent the total increases or decrease in the company's cash balance for the period.

[0001078271-12-000071:8k_2_02:60]
EXTREME NETWORKS, INC.

[0001078271-12-000071:8k_2_02:61]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS

[0001078271-12-000071:8k_2_02:62]
GAAP TO NON-GAAP RECONCILIATION

[0001078271-12-000071:8k_2_02:63]
(In thousands, except per share amounts)

[0001078271-12-000071:8k_2_02:64]
(Unaudited)

[0001078271-12-000071:8k_2_02:65]
| Non-GAAP Gross Margin | Three Months Ended |
|  | September 30, 2012 |  | October 2, 2011 |
| Gross profit - GAAP Basis | $ | 39,975 |  |  | $ | 43,536 |  |
| Gross margin - GAAP Basis percentage | 53 | % |  | 55 | % |
| Adjustments: |  |  |  |
| Stock based compensation expense | $ | 333 |  |  | $ | 270 |  |
| Gross profit - Non-GAAP Basis | $ | 40,308 |  |  | $ | 43,806 |  |
| Gross margin - Non-GAAP Basis percentage | 53 | % |  | 56 | % |
| Non-GAAP Operating Income | Three Months Ended |
|  | September 30, 2012 |  | October 2, 2011 |
| GAAP operating income | $ | 13,572 |  |  | $ | 1,782 |  |
| GAAP operating income percentage | 18 | % |  | 2 | % |
| Adjustments: |  |  |  |
| Stock based compensation expense | $ | 2,168 |  |  | $ | 1,895 |  |
| Gain on sale of facilities | $ | (11,537 | ) |  | $ | — |  |
| Restructuring charge (credit), net of reversals | $ | (10 | ) |  | $ | 955 |  |
| Total adjustments to GAAP operating income | $ | (9,379 | ) |  | $ | 2,850 |  |
| Non-GAAP operating income | $ | 4,193 |  |  | $ | 4,632 |  |
| Non-GAAP operating income percentage | 6 | % |  | 6 | % |
| Non-GAAP Net Income | Three Months Ended |
|  | September 30, 2012 |  | October 2, 2011 |
| GAAP net income | $ | 12,915 |  |  | $ | 1,583 |  |
| Adjustments: |  |  |  |
| Stock based compensation expense | $ | 2,168 |  |  | $ | 1,895 |  |
| Gain on sale of facilities | $ | (11,537 | ) |  | $ | — |  |
| Restructuring charge (credit), net of reversals | $ | (10 | ) |  | $ | 955 |  |
| Total adjustments to GAAP net income | $ | (9,379 | ) |  | $ | 2,850 |  |
| Non-GAAP net income | $ | 3,536 |  |  | $ | 4,433 |  |
| Earnings per share |  |  |  |
| Non-GAAP diluted net income per share | $ | 0.04 |  |  | $ | 0.05 |  |
| Shares used in diluted net income per share calculation | 95,499 |  |  | 94,055 |  |

[0001078271-12-000071:8k_2_02:66]
| Free Cash Flow | Three Months Ended |
|  | September 30, 2012 |  | October 2, 2011 |
| Cash flow provided by (used in) operations | $ | 7,052 |  |  | $ | (3,944 | ) |
| Add: PP&E CapEx spending | $ | (1,562 | ) |  | $ | (748 | ) |
| Total free cash flow | $ | 5,490 |  |  | $ | (4,692 | ) |
