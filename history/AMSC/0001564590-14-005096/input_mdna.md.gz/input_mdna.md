# AMSC MD&A — 0001564590-14-005096


## mdna

[0001564590-14-005096:mdna:1]
[same as prior period, unchanged from 0001564590-14-003115:mdna:1]

[0001564590-14-005096:mdna:2]
27

[0001564590-14-005096:mdna:3]
ability to license such patents or other proprietary rights; Our technology and products could infringe intellectual property rights of others, which may require costly litigation and, if we are not successful, could cause us to pay substantial damages and disrupt our business; We have filed a demand for arbitration and other lawsuits against our former largest customer, Sinovel, regarding amounts we contend are overdue. We cannot be certain as to the outcome of these proceedings; We have been named as a party in various legal proceedings, and we may be named in additional litigation, all of which will require significant management time and attention, result in significant legal expenses and may result in an unfavorable outcome, which could have a material adverse effect on our business, operating results and financial condition; Our common stock has experienced, and may continue to experience, significant market price and volume fluctuations, which may prevent our stockholders from selling our common stock at a profit and could lead to costly litigation against us that could divert our management’s attention. These and the important factors discussed under the caption “Risk Factors” in Part 1. Item 1A of our Form 10-K for the fiscal year ended March 31, 2014, among others, could cause actual results to differ materially from those indicated by forward-looking statements made herein and presented elsewhere by management from time to time. Any such forward-looking statements represent management’s estimates as of the date of this Quarterly Report on Form 10-Q. While we may elect to update such forward-looking statements at some point in the future, we disclaim any obligation to do so, even if subsequent events cause our views to change. These forward-looking statements should not be relied upon as representing our views as of any date subsequent to the date of this Quarterly Report on Form 10-Q.

[0001564590-14-005096:mdna:4]
[same as prior period, unchanged from 0001564590-14-003115:mdna:3]

[0001564590-14-005096:mdna:5]
[same as prior period, unchanged from 0001564590-14-003115:mdna:4]

[0001564590-14-005096:mdna:6]
[same as prior period, unchanged from 0001564590-14-003115:mdna:5]

[0001564590-14-005096:mdna:7]
[same as prior period, unchanged from 0001564590-14-003115:mdna:6]

[0001564590-14-005096:mdna:8]
[same as prior period, unchanged from 0001564590-14-003115:mdna:7]

[0001564590-14-005096:mdna:9]
[same as prior period, unchanged from 0001564590-14-003115:mdna:8]

[0001564590-14-005096:mdna:10]
[same as prior period, unchanged from 0001564590-14-003115:mdna:9]

[0001564590-14-005096:mdna:11]
[same as prior period, unchanged from 0001564590-14-003115:mdna:10]

[0001564590-14-005096:mdna:12]
[same as prior period, unchanged from 0001564590-14-003115:mdna:11]

[0001564590-14-005096:mdna:13]
28

[0001564590-14-005096:mdna:14]
[same as prior period, unchanged from 0001564590-14-003115:mdna:12]

[0001564590-14-005096:mdna:15]
We have experienced recurring operating losses and as of September 30, 2014, had an accumulated deficit of $895.3 million. In addition, we have experienced recurring negative operating cash flows. At September 30, 2014, we had cash and cash equivalents of $34.7 million. Cash used in operations for the six months ended September 30, 2014 was $11.4 million.  On August 29, 2014, the Arbitration Tribunal for the ICC International Court of Arbitration (the “ICC Court”) found us liable for damages in our breach of contract arbitration against Ghodawat Energy Pvt Ltd (“Ghodawat”) and awarded Ghodawat approximately €8.3 million (approximately $10.6 million) plus interest of 5.33%, which accrues from the date of award.  We are exploring our options with respect to this award, but intend to defend vigorously against the enforcement of this award.  See Part II, Item 1, “Legal Proceedings” for further information.  As of September 30, 2014, there was approximately $17.1 million of availability under our ATM arrangement.  Sales of common stock under the ATM may be made from time to time, at our discretion, in order to enhance liquidity.  In addition, we are actively seeking to sell our minority investment in Tres Amigas, LLC, a Delaware limited liability company (“Tres Amigas”).  We no longer believe our investment in Blade Dynamics is recoverable and therefore fully impaired our remaining investment in Blade Dynamics Ltd. (“Blade Dynamics”) during the three months ended September 30, 2014. There can be no assurance that we will be able to sell these investments on commercially reasonable terms or at all.

[0001564590-14-005096:mdna:16]
In response to the Sinovel situation discussed below and challenging market conditions, particularly in the wind power market, from April 1, 2011 through the date of this filing, we have reduced our global workforce substantially.  In addition, we plan to consolidate certain of our office locations.  These workforce reductions and planned office reductions are expected to lower operating costs and enhance liquidity.

[0001564590-14-005096:mdna:17]
Our cash requirements depend on numerous factors, including the timing and amount of the arbitration award liability ultimately paid, successful completion of our product development activities, our ability to commercialize our Resilient Electric Grid (“REG”) and degaussing system solutions, rate of customer and market adoption of our products, collecting receivables according to established terms, and the continued availability of U.S. government funding during the product development phase in our Superconductors business. Significant deviations to our business plan with regard to these factors, which are important drivers to our business, could have a material adverse effect on our operating performance, financial condition, and future business prospects. We expect to pursue the expansion of our operations through internal growth, diversification of our customer base, and potential strategic alliances. See below for a discussion of liquidity and capital resources.

[0001564590-14-005096:mdna:18]
[same as prior period, unchanged from 0001564590-14-003115:mdna:16]

[0001564590-14-005096:mdna:19]
[same as prior period, unchanged from 0001564590-14-003115:mdna:17]

[0001564590-14-005096:mdna:20]
We cannot provide any assurance as to the outcome of these legal actions. For more information about these legal proceedings, see Part II, Item 1, “Legal Proceedings.”

[0001564590-14-005096:mdna:21]
[same as prior period, unchanged from 0001564590-14-003115:mdna:19]

[0001564590-14-005096:mdna:22]
The preparation of the unaudited condensed consolidated financial statements requires that we make estimates and judgments that affect the reported amounts of assets, liabilities, revenues and expenses, and related disclosure of contingent assets and liabilities. We base our estimates on historical experience and various other assumptions that are believed to be reasonable under the circumstances, the results of which form the basis for making judgments about the carrying values of assets and liabilities that are not readily apparent from other sources. Actual results may differ under different assumptions or conditions. There were no significant changes in the critical accounting policies during the six months ended September 30, 2014 that were disclosed in our Form 10-K for fiscal 2013, which ended on March 31, 2014.

[0001564590-14-005096:mdna:23]
[same as prior period, unchanged from 0001564590-14-003115:mdna:21]

[0001564590-14-005096:mdna:24]
Three and six months ended September 30, 2014 compared to the three and six months ended September 30, 2013

[0001564590-14-005096:mdna:25]
[same as prior period, unchanged from 0001564590-14-003115:mdna:23]

[0001564590-14-005096:mdna:26]
Total revenues decreased by 48% and 49% to $12.5 million and $24.2 million for the three and six months ended September 30, 2014, respectively, compared to $24.2 million and $47.3 million for the three and six months ended September 30, 2013, respectively. Our revenues are summarized as follows (in thousands):

[0001564590-14-005096:mdna:27]
|  | Three Months Ended September 30, |  |  | Six months ended September 30, |  |
|  | 2014 |  |  | 2013 |  |  | 2014 |  |  | 2013 |  |
| Revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Wind | $ | 7,462 |  |  | $ | 14,691 |  |  | $ | 15,113 |  |  | $ | 29,392 |  |
| Grid |  | 4,993 |  |  |  | 9,490 |  |  |  | 9,038 |  |  |  | 17,875 |  |
| Total | $ | 12,455 |  |  | $ | 24,181 |  |  | $ | 24,151 |  |  | $ | 47,267 |  |

[0001564590-14-005096:mdna:28]
Our Wind business unit accounted for 60% and 63% of total revenues for the three and six months ended September 30, 2014, respectively compared to 61% and 62% for the three and six months ended September 30, 2013, respectively. Revenues in the Wind business unit decreased 49% to $7.5 million and $15.1 million in the three and six months ended September 30, 2014, from $14.7 million and $29.4 million in the three and six months ended September 30, 2013, respectively. Wind business unit revenues during the three and six months ended September 30, 2014 decreased primarily due to lower revenues from customers in China.

[0001564590-14-005096:mdna:29]
Our Grid business unit accounted for 40% and 37% of total revenues for the three and six months ended September 30, 2014, respectively, compared to 39% and 38% for the three and six months ended September 30, 2013, respectively. Our Grid business unit revenues decreased 47% and 49% to $5.0 million and $9.0 million in the three and six months ended September 30, 2014, respectively, from $9.5 million and $17.9 million in the three and six months ended September 30, 2013, respectively. Grid business unit revenues decreased in the three and six months ended September 30, 2014 primarily due to lower D-VAR system revenues and lower Superconductors revenue due to lower revenues from customers in Korea.

[0001564590-14-005096:mdna:30]
Project HYDRA is a project with Consolidated Edison, Inc. which is being partially funded by the Department of Homeland Security (“DHS”). DHS is expected to invest up to a total of $29.0 million in the development of a new HTS power grid technology called Resilient Electric Grid systems. This fault current limiting cable system is designed to utilize customized Amperium® HTS wires, and ancillary controls to deliver more power through the grid while also being able to suppress power surges that can disrupt service. DHS has now committed 100% of the total expected funding for this project. Consolidated Edison and Southwire Company are our subcontractors on this project. We recorded $0.4 million and $0.6 million of revenue on this project for the three and six month periods ended September 30, 2014, respectively, compared to $1.0 million and $1.1 million for the three and six months ended September 30, 2013, respectively.

[0001564590-14-005096:mdna:31]
The following table sets forth customers who represented 10% or more of our total revenues for the three and six months ended September 30, 2014 and 2013:

[0001564590-14-005096:mdna:32]
|  | Three months ended September 30, |  |  | Six months ended September 30, |  |
|  | 2014 |  |  | 2013 |  |  | 2014 |  |  | 2013 |  |
| INOX Wind Limited |  | 48 | % |  |  | 27 | % |  |  | 48 | % |  |  | 21 | % |
| RES American Construction, Inc |  | 16 | % |  |  | — | % |  | <10 | % |  |  | — | % |
| Beijing JINGCHENG New Energy Co., Ltd |  | — | % |  |  | 28 | % |  | <10 | % |  |  | 31 | % |

[0001564590-14-005096:mdna:33]
[same as prior period, unchanged from 0001564590-14-003115:mdna:31]

[0001564590-14-005096:mdna:34]
Cost of revenues was $13.8 million and $25.9 million for the three and six months ended September 30, 2014, respectively, compared to $22.6 million and $40.6 million for the three and six months ended September 30, 2013, respectively. Gross margin was (10.6%) and (7.1%) for the three and six months ended September 30, 2014, respectively, compared to 6.5% and 14.1% for the three and six months ended September 30, 2013, respectively. The decrease in gross margin for the three and six months ended September 30, 2014 as compared to the same periods in fiscal 2013 was primarily due to lower fixed cost absorption due to lower revenues as well as 100% margin revenue in the prior year.

[0001564590-14-005096:mdna:35]
[same as prior period, unchanged from 0001564590-14-003115:mdna:34]

[0001564590-14-005096:mdna:36]
[same as prior period, unchanged from 0001564590-14-003115:mdna:35]

[0001564590-14-005096:mdna:37]
[same as prior period, unchanged from 0001564590-14-003115:mdna:36]

[0001564590-14-005096:mdna:38]
|  | Three months ended September 30, |  |  | Six months ended September 30, |  |
|  | 2014 |  |  | 2013 |  |  | 2014 |  |  | 2013 |  |
| R&D expenses per consolidated statements of operations | $ | 3,078 |  |  | $ | 3,083 |  |  | $ | 6,198 |  |  | $ | 6,110 |  |
| R&D expenditures reclassified as cost of revenues |  | 1,825 |  |  |  | 3,009 |  |  |  | 3,900 |  |  |  | 4,935 |  |
| R&D expenditures offset by cost-sharing funding |  | 9 |  |  |  | 117 |  |  |  | 36 |  |  |  | 199 |  |
| Aggregated R&D expenses | $ | 4,912 |  |  | $ | 6,209 |  |  | $ | 10,134 |  |  | $ | 11,244 |  |

[0001564590-14-005096:mdna:39]
R&D expenses (exclusive of amounts classified as cost of revenues and amounts offset by cost-sharing funding) were flat in the three months ended September 30, 2014, and increased by 1% to $6.2 million for the six months ended September 30, 2014, from $6.1 million for the six months ended September 30, 2013.   The increase in R&D expenses in the six months ended September 30, 2014, was driven primarily by cost of living adjustments on salaries.  The decreases in R&D expenditures reclassified to cost of revenue was a result of decreased activity under government funded contracts in our Grid business unit compared to the prior year period.  Aggregated R&D expenses, which include amounts classified as cost of revenues, and amounts offset by cost-sharing funding decreased 21% and 10% to $4.9 million and $10.1 million for the three and six months ended September 30, 2014, respectively, from $6.2 million and $11.2 million for the three and six months ended September 30, 2013 respectively.

[0001564590-14-005096:mdna:40]
[same as prior period, unchanged from 0001564590-14-003115:mdna:39]

[0001564590-14-005096:mdna:41]
[same as prior period, unchanged from 0001564590-14-003115:mdna:40]

[0001564590-14-005096:mdna:42]
SG&A expenses decreased by 7% and 18% to $8.0 million and $16.0 million in the three and six months ended September 30, 2014, respectively, from $8.7 million and $19.5 million in the three and six months ended September 30, 2013, respectively. The decreases in SG&A expenses were due primarily to the realization of savings from cost reduction actions that were implemented in prior periods as well as a reduction in audit and legal costs.

[0001564590-14-005096:mdna:43]
Arbitration award expense

[0001564590-14-005096:mdna:44]
We recorded an arbitration award expense of $10.2 million in the three months ended September 30, 2014 following a decision by the ICC Court on August 29, 2014, finding us liable for damages under a breach of contract proceeding against Ghodawat.

[0001564590-14-005096:mdna:45]
[same as prior period, unchanged from 0001564590-14-003115:mdna:42]

[0001564590-14-005096:mdna:46]
We recorded amortization expense related to our core technology and know-how, trade names and trademark intangible assets of less than $0.1 million and $0.1 million in the three and six months ended September 30, 2014 and $0.1 million and $0.2 million in the three and six months ended September 30, 2013, respectively.

[0001564590-14-005096:mdna:47]
31

[0001564590-14-005096:mdna:48]
[same as prior period, unchanged from 0001564590-14-003115:mdna:44]

[0001564590-14-005096:mdna:49]
We recorded $3.7 million and $4.9 million of restructuring and impairment charges in the three and six months ended September 30, 2014, respectively. We recorded restructuring and impairment charges of $0.8 million in both the three and six months ended September 30, 2013. The amount in the three months ended September 30, 2014 consists primarily of an impairment charge of $3.5 million on our minority investment in Blade Dynamics.  The impairment charge followed an analysis in which we determined that this investment is not recoverable due to a dilutive financing which resulted in the loss of certain of our shareholder rights, as well as certain operational issues in the company.  The amounts in the three months ended September 30, 2013 consist primarily of employee severance and benefit costs.

[0001564590-14-005096:mdna:50]
[same as prior period, unchanged from 0001564590-14-003115:mdna:46]

[0001564590-14-005096:mdna:51]
[same as prior period, unchanged from 0001564590-14-003115:mdna:47]

[0001564590-14-005096:mdna:52]
|  | Three months ended September 30, |  |  | Six months ended September 30, |  |
|  | 2014 |  |  | 2013 |  |  | 2014 |  |  | 2013 |  |
| Operating loss: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Wind | $ | (14,611 | ) |  | $ | (2,449 | ) |  | $ | (18,091 | ) |  | $ | (4,274 | ) |
| Grid |  | (6,559 | ) |  |  | (5,750 | ) |  |  | (12,966 | ) |  |  | (10,618 | ) |
| Unallocated corporate expenses |  | (5,230 | ) |  |  | (2,829 | ) |  |  | (8,010 | ) |  |  | (4,985 | ) |
| Total | $ | (26,400 | ) |  | $ | (11,028 | ) |  | $ | (39,067 | ) |  | $ | (19,877 | ) |

[0001564590-14-005096:mdna:53]
Our Wind segment generated operating losses of $14.6 million and $18.1 million in the three and six months ended September 30, 2014, respectively, compared to operating losses of $2.4 million and $4.3 million in the three and six months ended September 30, 2013, respectively. The increases in Wind business unit operating losses were primarily due to the aforementioned arbitration award expense as well as lower revenues as previously discussed.

[0001564590-14-005096:mdna:54]
The operating loss in our Grid segment increased to $6.6 million and $13.0 million in the three and six months ended September 30, 2014, respectively, compared to $5.8 million and $10.6 million in the three and six months ended September 30, 2013, respectively. The increases in the Grid business unit operating losses were primarily due to lower revenue, as previously discussed.

[0001564590-14-005096:mdna:55]
Unallocated corporate expenses primarily include stock-based compensation expense of $1.5 million and $3.1 million, and restructuring and impairment charges of $3.7 million and $4.9 million, for the three and six months ended September 30, 2014, respectively.  Unallocated corporate expenses primarily consist of stock-based compensation expense of $2.2 million and $4.3 million, for the three and six months ended September 30, 2013, respectively, and restructuring and impairment charges of $0.8 million for each of the three and six months ended September 30, 2013, respectively.

[0001564590-14-005096:mdna:56]
[same as prior period, unchanged from 0001564590-14-003115:mdna:52]

[0001564590-14-005096:mdna:57]
The change in fair value of derivatives and warrants resulted in gains of $0.8 million in both the three and six months ended September 30, 2014, respectively, compared to gains of $0.9 million and $1.4 million for the three and six months ended September 30, 2013, respectively. The changes were primarily driven by a lower stock price, which is a key valuation metric and by the extinguishment of the derivative liability associated with our convertible note in the prior year.

[0001564590-14-005096:mdna:58]
[same as prior period, unchanged from 0001564590-14-003115:mdna:54]

[0001564590-14-005096:mdna:59]
Interest expense, net, was $0.5 million and $1.0 million in the three and six months ended September 30, 2014, respectively, compared to $3.5 million and $5.6 million in the three and six months ended September 30, 2013, respectively. The decreases in interest expense, net were due primarily to the extinguishment of the convertible note in March 2014.

[0001564590-14-005096:mdna:60]
Other income (expense), net

[0001564590-14-005096:mdna:61]
Other income, net, was $0.7 million and $0.6 million in the three and six months ended September 30, 2014, respectively, compared to other expense, net, of $0.6 million in both the three and six months ended September 30, 2013.   The increases in other income, net are primarily related to foreign currency gains, particularly in the three months ended September 30, 2014.

[0001564590-14-005096:mdna:62]
[same as prior period, unchanged from 0001564590-14-003115:mdna:58]

[0001564590-14-005096:mdna:63]
Income tax expense was $0.1 million and $0.2 million in the three and six months ended September 30, 2014, respectively, compared to $0.3 million and $0.4 million in the three and six months ended September 30, 2013, respectively. Income tax expense in both periods was primarily due to income taxes in foreign jurisdictions.

[0001564590-14-005096:mdna:64]
[same as prior period, unchanged from 0001564590-14-003115:mdna:60]

[0001564590-14-005096:mdna:65]
[same as prior period, unchanged from 0001564590-14-003115:mdna:61]

[0001564590-14-005096:mdna:66]
We define non-GAAP net loss as net loss before stock-based compensation, arbitration award expense, amortization of acquisition-related intangibles, restructuring and impairment charges, Sinovel litigation, consumption of zero cost-basis inventory, changes in fair value of derivatives and warrants, non-cash interest expense, and the other non-cash or unusual, net of any tax effects related to these items, indicated in the table below. We believe non-GAAP net loss assists management and investors in comparing our performance across reporting periods on a consistent basis by excluding these non-cash or non-recurring charges that we do not believe are indicative of our core operating performance. We also regard non-GAAP net loss as a useful measure of operating performance which more closely aligns net loss with cash used in/provided by continuing operations. In addition, we use non-GAAP net loss as a factor in evaluating management’s performance when determining incentive compensation and to evaluate the effectiveness of our business strategies. A reconciliation of non-GAAP to GAAP net loss is set forth in the table below (in thousands, except per share data):

[0001564590-14-005096:mdna:67]
|  | Three months ended September 30, |  |  | Six months ended September 30, |
|  | 2014 |  |  | 2013 |  |  | 2014 |  |  | 2013 |  |  |
| Net loss | $ | (25,423 | ) |  | $ | (14,623 | ) |  | $ | (38,939 | ) |  | $ | (25,135 | ) |  |
| Stock-based compensation |  | 1,518 |  |  |  | 2,152 |  |  |  | 3,099 |  |  |  | 4,287 |  |  |
| Arbitration award expense |  | 10,188 |  |  |  | - |  |  |  | 10,188 |  |  |  | - |  |  |
| Amortization of acquisition-related intangibles |  | 39 |  |  |  | 82 |  |  |  | 79 |  |  |  | 164 |  |  |
| Restructuring and impairment charges |  | 3,731 |  |  |  | 751 |  |  |  | 4,909 |  |  |  | 764 |  |  |
| Sinovel litigation |  | - |  |  |  | (5 | ) |  |  | - |  |  |  | (7 | ) |  |
| Consumption of zero cost-basis inventory |  | (1,195 | ) |  |  | (1,319 | ) |  |  | (2,567 | ) |  |  | (2,493 | ) |  |
| Change in fair value of derivatives and warrants |  | (795 | ) |  |  | (886 | ) |  |  | (760 | ) |  |  | (1,355 | ) |  |
| Non-cash interest expense |  | 154 |  |  |  | 3,093 |  |  |  | 343 |  |  |  | 4,765 |  |  |
| Non-GAAP net loss | $ | (11,783 | ) |  | $ | (10,755 | ) |  | $ | (23,648 | ) |  | $ | (19,010 | ) |  |
| Non-GAAP loss per share | $ | (0.14 | ) |  | $ | (0.18 | ) |  | $ | (0.30 | ) |  | $ | (0.32 | ) |  |
| Weighted average shares outstanding - basic and diluted |  | 81,471 |  |  |  | 61,116 |  |  |  | 79,590 |  |  |  | 59,712 |  |  |

[0001564590-14-005096:mdna:68]
We incurred non-GAAP net losses of $11.8 million and $23.6 million or $0.14 and $0.30 per share, for the three and six months ended September 30, 2014, respectively, compared to non-GAAP net losses of $10.8 million and $19.0 million, or $0.18 and $0.32 per share, for the three and six months ended September 30, 2013, respectively. The increases in non-GAAP net loss were driven primarily by the increased operating losses in our business units excluding the arbitration award expense, which is part of the operating loss in our Wind segment for the three and six months ended September 30, 2014.

[0001564590-14-005096:mdna:69]
33

[0001564590-14-005096:mdna:70]
[same as prior period, unchanged from 0001564590-14-003115:mdna:65]

[0001564590-14-005096:mdna:71]
At September 30, 2014, we had cash, cash equivalents, and restricted cash of $38.2 million, compared to $49.4 million at March 31, 2014, a decrease of $11.2 million. Our cash and cash equivalents, and restricted cash are summarized as follows (in thousands):

[0001564590-14-005096:mdna:72]
|  | September 30, |  |  | March 31, |  |
|  | 2014 |  |  | 2014 |  |
| Cash and cash equivalents | $ | 34,679 |  |  | $ | 43,114 |  |
| Restricted cash |  | 3,525 |  |  |  | 6,307 |  |
| Total cash, cash equivalents, and restricted cash | $ | 38,204 |  |  | $ | 49,421 |  |

[0001564590-14-005096:mdna:73]
For the six months ended September 30, 2014, net cash used in operating activities was $11.4 million compared to $14.8 million for the six months ended September 30, 2013. The decrease in net cash used in operations was due primarily to cash generated from changes in operating asset and liability accounts, during the six months ended September 30, 2014.

[0001564590-14-005096:mdna:74]
For the six months ended September 30, 2014, net cash provided by investing activities was $2.3 million, compared to $3.4 million for the six months ended September 30, 2013. The decrease in net cash provided by investing activities for the six months ended September 30, 2014 was driven primarily by a net change in restricted cash.

[0001564590-14-005096:mdna:75]
For the six months ended September 30, 2014, net cash provided by financing activities was $0.8 million compared to net cash used in financing activities of $2.3 million in the six months ended September 30, 2013. The decrease in net cash used in financing activities was primarily due to net proceeds from the issuance of common stock under the ATM, during the six months ended September 30, 2014, partially offset by higher amounts repaid for debt.  The ATM arrangement was not in place during the same period in the prior year.

[0001564590-14-005096:mdna:76]
At September 30, 2014, we had $3.4 million of restricted cash included in current assets, and $0.1 million of restricted cash included in long-term assets. These amounts included in restricted cash primarily represent deposits to secure letters of credit for various supply contracts. These deposits are held in interest bearing accounts.

[0001564590-14-005096:mdna:77]
We have experienced recurring operating losses and as of September 30, 2014, had an accumulated deficit of $895.3 million. In addition, we have experienced recurring negative operating cash flows. At September 30, 2014 we had cash and cash equivalents of $34.7 million.  On August 29, 2014, the ICC Court found us liable for damages in our breach of contract proceeding against Ghodowat and awarded Ghodawat approximately €8.3 million (approximately $10.6 million) plus interest of 5.33%, which accrues from the date of the award.  We are exploring our options with respect to this award, but intend to defend vigorously against the enforcement of this award.  As of September 30, 2014, there was approximately $17.1 million of availability under our ATM arrangement.  Sales of common stock under the ATM may be made from time to time at our discretion, in order to enhance liquidity.  In addition, we are actively seeking to sell our minority investment in Tres Amigas.  We no longer believe our remaining investment in Blade Dynamics is recoverable and have fully impaired our investment in Blade Dynamics during the three months ended September 30, 2014.  There can be no assurance that we will be able to sell these investments on commercially reasonable terms or at all.

[0001564590-14-005096:mdna:78]
[same as prior period, unchanged from 0001564590-14-003115:mdna:73]

[0001564590-14-005096:mdna:79]
[same as prior period, unchanged from 0001564590-14-003115:mdna:74]

[0001564590-14-005096:mdna:80]
The Term Loans are secured by substantially all of our existing and future assets, including a mortgage on real property owned by our wholly owned subsidiary, ASC Devens LLC, and located at 64 Jackson Road, Devens, Massachusetts. The Term Loans contain certain covenants that restrict our ability to, among other things, incur or assume certain debt, merge or consolidate, materially change the nature of our business, make certain investments, acquire or dispose of certain assets, make guaranties or grant liens on our assets, make certain loans, advances or investments, declare dividends or make distributions or enter into transactions with affiliates. In addition, the Term Loans contain a covenant which requires us to maintain a minimum unrestricted cash balance (“Minimum Threshold”) in the United States of at least $15.0 million at the inception of the New Term Loan.  The Minimum Threshold will be reduced by $2.5 million for every $5.0 million of net proceeds from the sale of our common stock after November 15, 2013, including those under the ATM, to an amount not lower than $7.5 million or the outstanding combined principal balances of the Term Loans, whichever is lower.  As of September 30, 2014 the Minimum Threshold was $9.8 million.  The events of default under the Term Loans include, but are not limited to, failure to pay amounts due, breaches of covenants, bankruptcy events, cross defaults under other material indebtedness and the occurrence of a material adverse effect and/or change in control. In the case of a continuing event of default, the lender may, among other remedies, declare due all unpaid principal amounts outstanding and any accrued but unpaid interest and foreclose on all collateral granted to the lender as security under the Term Loans.

[0001564590-14-005096:mdna:81]
We believe we are in and expect to remain in compliance with the covenants and restrictions under the Term Loans as of the date of this Quarterly Report on Form 10-Q. If we fail to stay in compliance with our covenants or experience some other event of default, we may be forced to repay the outstanding principal of the Term Loans.

[0001564590-14-005096:mdna:82]
On November 15, 2013, we entered into an ATM arrangement, pursuant to which, we may, at our discretion, sell up to $30.0 million of our common stock through our sales agent, MLV.  Sales of common stock made under the ATM are made on the NASDAQ Global Market under our previously filed and currently effective Registration Statement on Form S-3 (File No. 333-191153) by means of ordinary brokers’ transactions at market prices. Additionally, under the terms of the ATM, we may also sell shares of our common stock through MLV, on the NASDAQ Global Market or otherwise, at negotiated prices or at prices related to the prevailing market price. Under the terms of the ATM, MLV may not engage in any proprietary trading or trading as principal for MLV’s own account. MLV uses its commercially reasonable efforts to sell our common stock from time to time, based upon the our instructions (including any price, time or size limits or other customary parameters or conditions we may impose). We pay MLV a commission of up to 3% of the gross proceeds from the sale of shares of our common stock under the ATM. We have also agreed to provide MLV with customary indemnification rights. The offering of common stock pursuant to the ATM will terminate upon the earlier of the sale of all of the common stock subject to the ATM or the termination of the ATM by us or MLV. Either party may terminate the ATM at its sole discretion at any time upon written notice to the other party.  During the three months ended September 30, 2014, we received net proceeds of $3.7 million, including sales commissions and offering expenses, from sales of approximately 2.1 million shares of our common stock at an average sales price of approximately $1.75 per share under the ATM.  As of September 30, 2014, we have approximately $17.1 million of remaining availability under the ATM.

[0001564590-14-005096:mdna:83]
We expect to require additional capital, either from sales under the ATM or other sources to fund our operations, including the arbitrations award liability, capital expenditures and scheduled cash payments under our debt obligations through September 30, 2015. Our plans include, and our liquidity is highly dependent on, our ability to increase revenues and control our operating costs, our ability to utilize the ATM to raise additional capital or raise capital from other sources, and our ability to maintain compliance with the covenants and restrictions on our debt obligations (or obtain waivers from our lender in the event of non-compliance).

[0001564590-14-005096:mdna:84]
Our cash requirements depend on numerous factors, including the timing and amount of the arbitration award liability ultimately paid, successful completion of our product development activities, our ability to commercialize our REG and degaussing system solutions, rate of customer and market adoption of our products, collecting receivables according to established terms, and the continued availability of U.S. government funding during the product development phase in our Superconductors business. Significant deviations to our business plan with regard to these factors, which are important drivers to our business, could have a material adverse effect on our operating performance, financial condition, and future business prospects. We expect to pursue the expansion of our operations through internal growth, diversification of our customer base, and potential strategic alliances.

[0001564590-14-005096:mdna:85]
Legal Proceedings

[0001564590-14-005096:mdna:86]
We are involved in legal and administrative proceedings and claims of various types. See Part II, Item 1, “Legal Proceedings,” for additional information. We record a liability in our consolidated financial statements for these matters when a loss is known or considered probable and the amount can be reasonably estimated. We review these estimates each accounting period as additional information is known and adjust the loss provision when appropriate. If a matter is both probable to result in liability and the amounts of loss can be reasonably estimated, we estimate and disclose the possible loss or range of loss. If the loss is not probable or cannot be reasonably estimated, a liability is not recorded in our consolidated financial statements.

[0001564590-14-005096:mdna:87]
[same as prior period, unchanged from 0001564590-14-003115:mdna:82]

[0001564590-14-005096:mdna:88]
[same as prior period, unchanged from 0001564590-14-003115:mdna:83]

[0001564590-14-005096:mdna:89]
[same as prior period, unchanged from 0001564590-14-003115:mdna:84]

[0001564590-14-005096:mdna:90]
[same as prior period, unchanged from 0001564590-14-003115:mdna:85]

[0001564590-14-005096:mdna:91]
[same as prior period, unchanged from 0001564590-14-003115:mdna:86]

[0001564590-14-005096:mdna:92]
In May 2014, the FASB and the International Accounting Standards Board (IASB) issued, ASU Revenue from Contracts with Customers 2014-09 (Topic 606). The guidance substantially converges final standards on revenue recognition between the FASB and IASB providing a framework on addressing revenue recognition issues and, upon its effective date, replaces almost all exiting revenue recognition guidance, including industry-specific guidance, in current U.S. generally accepted accounting principles.  The ASU is effective for annual reporting periods beginning after December 15, 2016.  We are currently evaluating the impact of adopting ASU 2014-09 to determine the impact, if any, it may have on our current practices.

[0001564590-14-005096:mdna:93]
In July 2014, the FASB issued ASU 2014-12, Compensation – Stock Compensation (Topic 718): Accounting for Share Based Payments When the Terms of an Award Provide that a Performance Target Could be Achieved after the Requisite Service Period.    To account for such awards, a reporting entity should apply existing guidance in FASB Accounting Standards Codification Topic 718, Compensation – Stock Compensation, as it relates to awards with performance conditions that affect vesting.  As such, the performance target should not be reflected in estimating the grant-date fair value of the award. This ASU is effective for annual reporting periods and interim periods, within those annual periods beginning after December 15, 2015.  We are currently evaluating the impact of adopting ASU 2014-12 to determine the impact, if any, it may have on our current practices.

[0001564590-14-005096:mdna:94]
In August 2014, the FASB issued ASU 2014-13, Consolidation (Topic 810): Measuring the Financial Assets and Financial Liabilities of a Consolidated Collateralized Financing Entity.  The new standard applies to reporting entities that are required to consolidate a collateralized financing entity under the variable interest entities subsection of subtopic 810-10.  This ASU is effective for annual reporting periods ending after December 15, 2016, and interim periods within annual periods beginning after December 15, 2016.  We are currently evaluating the impact of adopting ASU 2014-13 to determine the impact, but currently do not believe there will be an impact on our consolidated results of operations, financial condition, or cash flow.

[0001564590-14-005096:mdna:95]
In August 2014, the FASB issued ASU 2014-15, Presentation of Financial Statements – Going Concern (Subtopic 205-40): Disclosure of Uncertainties About an Entity’s Ability to Continue as a Going Concern.  The new standard explicitly requires the assessment at interim and annual periods, and provides management with its own disclosure guidance. This ASU is effective for annual reporting periods and interim periods, within those annual periods ending after December 15, 2016.  We are currently evaluating the impact of adopting ASU 2014-15 to determine the impact, if any, it may have on our current practices.
