# AMSC notes — 0001564590-14-005096


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001564590-14-005096:notes:1]
[same as prior period, unchanged from 0001564590-14-003115:notes:1]

[0001564590-14-005096:notes:2]
The Company accounts for its stock-based compensation at fair value. The following table summarizes stock-based compensation expense by financial statement line item for the three and six months ended September 30, 2014 and 2013 (in thousands):

[0001564590-14-005096:notes:3]
|  | Three months ended September 30, |  |  | Six months ended September 30, |  |
|  | 2014 |  |  | 2013 |  |  | 2014 |  |  | 2013 |  |
| Cost of revenues | $ | 194 |  |  | $ | 224 |  |  | $ | 346 |  |  | $ | 429 |  |
| Research and development |  | 521 |  |  |  | 585 |  |  |  | 1,000 |  |  |  | 1,159 |  |
| Selling, general and administrative |  | 803 |  |  |  | 1,343 |  |  |  | 1,753 |  |  |  | 2,699 |  |
| Total | $ | 1,518 |  |  | $ | 2,152 |  |  | $ | 3,099 |  |  | $ | 4,287 |  |

[0001564590-14-005096:notes:4]
During the six months ended September 30, 2014, the Company granted 1,000,000 stock options, and 3,192,502 restricted stock awards. During the six months ended September 30, 2013, the Company granted approximately 831,000 stock options, 400,000 time-based restricted stock awards, 362,000 performance-based restricted stock awards, and issued 212,000 shares of common stock in-lieu of cash bonuses and severance payments issued. The stock options vest generally over 3-5 years, and the time-based restricted stock awards vest generally over three years. For options and awards that vest upon the passage of time, expense is being recorded over the vesting period.  Performance-based restricted stock awards are expensed over the requisite service period based on probability of achievement.

[0001564590-14-005096:notes:5]
The estimated fair value of the Company’s stock-based awards, less expected annual forfeitures, is amortized over the awards’ service period. The total unrecognized compensation cost for unvested outstanding stock options was $1.8 million at September 30, 2014. This expense will be recognized over a weighted average expense period of approximately 3.0 years. The total unrecognized compensation cost for unvested outstanding restricted stock was $4.6 million at September 30, 2014. This expense will be recognized over a weighted-average expense period of approximately 1.6 years.

[0001564590-14-005096:notes:6]
The weighted-average assumptions used in the Black-Scholes valuation model for stock options granted during the three and six months ended September 30, 2014 and 2013 are as follows:

[0001564590-14-005096:notes:7]
|  | Three months ended September 30, |  |  | Six months ended September 30, |  |
|  | 2014 |  | 2013 |  |  | 2014 |  |  | 2013 |  |
| Expected volatility | N/A |  |  | 75.4 | % |  |  | 85.5 | % |  |  | 75.1 | % |
| Risk-free interest rate | N/A |  |  | 1.7 | % |  |  | 1.9 | % |  |  | 1.7 | % |
| Expected life (years) | N/A |  |  | 5.8 |  |  |  | 5.8 |  |  |  | 5.9 |  |
| Dividend yield | N/A |  | None |  |  | None |  |  | None |  |

[0001564590-14-005096:notes:8]
[same as prior period, unchanged from 0001564590-14-003115:notes:8]


## us-gaap:EarningsPerShareTextBlock

[0001564590-14-005096:notes:9]
[same as prior period, unchanged from 0001564590-14-003115:notes:9]

[0001564590-14-005096:notes:10]
Basic net loss per share (“EPS”) is computed by dividing net loss by the weighted-average number of common shares outstanding for the period. Where applicable, diluted EPS is computed by dividing the net loss by the weighted-average number of common shares and dilutive common equivalent shares outstanding during the period, calculated using the treasury stock method. Common equivalent shares include the effect of restricted stock, exercise of stock options and warrants and contingently issuable shares. For each of the three and six months ended September 30, 2014, 7.4 million shares were not included in the calculation of diluted EPS as they were considered anti-dilutive, of which 3.9 million relate to unexercised stock options, and 3.5 million relate to the issuance of warrants. For each of the three and six months ended September 30, 2013, 9.7 million shares were not included in the calculation of diluted EPS as they were considered anti-dilutive, of which 3.2 million relate to unvested stock options, 3.2 million relate to the issue of warrants and 3.3 million shares related to the convertible feature of the Company’s unsecured, senior convertible note (the “Exchanged Note”).

[0001564590-14-005096:notes:11]
The following table reconciles the numerators and denominators of the earnings per share calculation for the three and six months ended September 30, 2014 and 2013 (in thousands, except per share data):

[0001564590-14-005096:notes:12]
|  | Three months ended September 30, |  |  | Six months ended September 30, |  |
|  | 2014 |  |  | 2013 |  |  | 2014 |  |  | 2013 |  |
| Numerator: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net loss | $ | (25,423 | ) |  | $ | (14,623 | ) |  | $ | (38,939 | ) |  | $ | (25,135 | ) |
| Denominator: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Weighted-average shares of common stock outstanding |  | 83,048 |  |  |  | 62,787 |  |  |  | 80,876 |  |  |  | 61,583 |  |
| Weighted-average shares subject to repurchase |  | (1,577 | ) |  |  | (1,671 | ) |  |  | (1,286 | ) |  |  | (1,871 | ) |
| Shares used in per-share calculation ― basic |  | 81,471 |  |  |  | 61,116 |  |  |  | 79,590 |  |  |  | 59,712 |  |
| Shares used in per-share calculation ― diluted |  | 81,471 |  |  |  | 61,116 |  |  |  | 79,590 |  |  |  | 59,712 |  |
| Net loss per share ― basic | $ | (0.31 | ) |  | $ | (0.24 | ) |  | $ | (0.49 | ) |  | $ | (0.42 | ) |
| Net loss per share ― diluted | $ | (0.31 | ) |  | $ | (0.24 | ) |  | $ | (0.49 | ) |  | $ | (0.42 | ) |


## us-gaap:FairValueDisclosuresTextBlock

[0001564590-14-005096:notes:13]
[same as prior period, unchanged from 0001564590-14-003115:notes:13]

[0001564590-14-005096:notes:14]
[same as prior period, unchanged from 0001564590-14-003115:notes:14]

[0001564590-14-005096:notes:15]
[same as prior period, unchanged from 0001564590-14-003115:notes:15]

[0001564590-14-005096:notes:16]
The Company provides a gross presentation of activity within Level 3 measurement roll-forward and details of transfers in and out of Level 1 and 2 measurements.  A change in the hierarchy of an investment from its current level is reflected in the period during which the pricing methodology of such investment changes.  Disclosure of the transfer of securities from Level 1 to Level 2 or Level 3 is made in the event that the related security is significant to total cash and investments.  The Company did not have any transfers of assets and liabilities between Level 1 and Level 3 of the fair value measurement hierarchy during the three or six months ended September 30, 2014.

[0001564590-14-005096:notes:17]
[same as prior period, unchanged from 0001564590-14-003115:notes:17]

[0001564590-14-005096:notes:18]
The following table provides the assets and liabilities carried at fair value, measured as of September 30, 2014 and March 31, 2014 (in thousands):

[0001564590-14-005096:notes:19]
|  | Total |  |  | Quoted Prices in |  |  | Significant Other |  |  | Significant |  |
|  | Carrying |  |  | Active Markets |  |  | Observable Inputs |  |  | Unobservable Inputs |  |
|  | Value |  |  | (Level 1) |  |  | (Level 2) |  |  | (Level 3) |  |
| September 30, 2014: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash equivalents | $ | 20,185 |  |  | $ | 20,185 |  |  | $ | - |  |  | $ | - |  |
| Derivative liabilities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Warrants | $ | 1,841 |  |  | $ | - |  |  | $ | - |  |  | $ | 1,841 |  |
|  | Total |  |  | Quoted Prices in |  |  | Significant Other |  |  | Significant |  |
|  | Carrying |  |  | Active Markets |  |  | Observable Inputs |  |  | Unobservable Inputs |  |
|  | Value |  |  | (Level 1) |  |  | (Level 2) |  |  | (Level 3) |  |
| March 31, 2014: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash equivalents | $ | 17,675 |  |  | $ | 17,675 |  |  | $ | - |  |  | $ | - |  |
| Derivative liabilities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Warrants | $ | 2,601 |  |  | $ | - |  |  | $ | - |  |  | $ | 2,601 |  |

[0001564590-14-005096:notes:20]
[same as prior period, unchanged from 0001564590-14-003115:notes:20]

[0001564590-14-005096:notes:21]
|  |  |  |  |  | Warrants |  |
| April 1, 2014 |  |  |  |  | $ | 2,601 |  |
| Mark to market adjustment |  |  |  |  |  | (760 | ) |
| Balance at September 30, 2014 |  |  |  |  | $ | 1,841 |  |
|  | Derivative |  |  |  |  |  |
|  | Liability |  |  | Warrants |  |
| April 1, 2013 | $ | 529 |  |  | $ | 3,633 |  |
| Warrant issuance with Senior Secured Term Loan |  | - |  |  |  | 315 |  |
| Mark to market adjustment |  | (525 | ) |  |  | (1,347 | ) |
| Extinguishment of derivative liability |  | (4 | ) |  |  | - |  |
| Balance at March 31, 2014 | $ | - |  |  | $ | 2,601 |  |

[0001564590-14-005096:notes:22]
The following table provides the assets and liabilities measured at fair value on a non-recurring basis, as of September 30, 2014 and March 31, 2014 (in thousands).  During the three months ended September 30, 2014 the following asset was determined to be no longer recoverable and was fully impaired.  See note 14, “Minority Investments” for further details:

[0001564590-14-005096:notes:23]
|  | Total |  |  | Quoted Prices in |  |  | Significant Other |  |  | Significant |  |
|  | Carrying |  |  | Active Markets |  |  | Observable Inputs |  |  | Unobservable Inputs |  |
|  | Value |  |  | (Level 1) |  |  | (Level 2) |  |  | (Level 3) |  |
| September 30, 2014: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Investment in unconsolidated entity – Blade Dynamics | $ | - |  |  | $ | - |  |  | $ | - |  |  | $ | - |  |
| March 31, 2014: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Investment in unconsolidated entity – Blade Dynamics | $ | 3,690 |  |  | $ | - |  |  | $ | - |  |  | $ | 3,690 |  |

[0001564590-14-005096:notes:24]
[same as prior period, unchanged from 0001564590-14-003115:notes:24]

[0001564590-14-005096:notes:25]
[same as prior period, unchanged from 0001564590-14-003115:notes:25]

[0001564590-14-005096:notes:26]
[same as prior period, unchanged from 0001564590-14-003115:notes:26]

[0001564590-14-005096:notes:27]
[same as prior period, unchanged from 0001564590-14-003115:notes:27]

[0001564590-14-005096:notes:28]
In April 2012, the Company entered into a Securities Purchase Agreement (the “Purchase Agreement”) with Capital Ventures International (“CVI”), an affiliate of Heights Capital Management, under which the Company issued a $25.0 million, 7% convertible note (the “Initial Note”).  In December 2012, the Company entered into an agreement with CVI pursuant to which it exchanged the Initial Note for the Exchanged Note.  The Exchanged Note was extinguished as of March 31, 2014.  The Company had identified all of the derivatives (“Derivative Liability”) associated with the extinguished Exchanged Note which include holder change of control redemption rights, issuer optional redemption rights, sale redemption rights and a feature to convert the Exchanged Note into equity at the holder’s option.  The Derivative Liability was subject to revaluation at each balance sheet date, and any change in fair value was recorded as a change in fair value in derivatives and warrants until its expiration.  The Company relied on assumptions in a lattice model to determine the fair value of Derivative Liability.  The Company had valued the Derivative Liability within Level 3 of the valuation hierarchy.  (See Note 10, “Debt,” for further discussion of the Exchanged Note, Derivative Liability and valuation assumptions used.)

[0001564590-14-005096:notes:29]
[same as prior period, unchanged from 0001564590-14-003115:notes:29]

[0001564590-14-005096:notes:30]
Warrants were issued in conjunction with the Purchase Agreement with CVI, and the Term Loans. (See Note 10, “Debt,” and Note 11 “Warrants and Derivative Liabilities,” for additional information.) These warrants are subject to revaluation at each balance sheet date, and any change in fair value will be recorded as a change in fair value in derivatives and warrants until the earlier of their exercise or expiration.

[0001564590-14-005096:notes:31]
The Company relies on various assumptions in a lattice model to determine the fair value of warrants. The Company has valued the warrants within Level 3 of the valuation hierarchy. (See Note 11, “Warrants and Derivative Liabilities,” for a discussion of the warrants and the valuation assumptions used.)

[0001564590-14-005096:notes:32]
[same as prior period, unchanged from 0001564590-14-003115:notes:32]

[0001564590-14-005096:notes:33]
[same as prior period, unchanged from 0001564590-14-003115:notes:33]

[0001564590-14-005096:notes:34]
During the three months ended September 30, 2014, the Company determined that as a result of a dilutive financing which resulted in the Company losing certain of its shareholder rights, as well as certain operational issues and adverse changes to the potential sale scenarios previously considered, its investment in Blade Dynamics was no longer recoverable and therefore recorded an impairment charge of $3.5 million.


## us-gaap:LoansNotesTradeAndOtherReceivablesDisclosureTextBlock

[0001564590-14-005096:notes:35]
[same as prior period, unchanged from 0001564590-14-003115:notes:34]

[0001564590-14-005096:notes:36]
Accounts receivable at September 30, 2014 and March 31, 2014 consisted of the following (in thousands):

[0001564590-14-005096:notes:37]
|  | September 30, |  |  | March 31, |  |
|  | 2014 |  |  | 2014 |  |
| Accounts receivable (billed) | $ | 8,410 |  |  | $ | 6,113 |  |
| Accounts receivable (unbilled) |  | 1,279 |  |  |  | 1,459 |  |
| Less: Allowance for doubtful accounts |  | (16 | ) |  |  | (16 | ) |
| Accounts receivable, net | $ | 9,673 |  |  | $ | 7,556 |  |


## us-gaap:InventoryDisclosureTextBlock

[0001564590-14-005096:notes:38]
[same as prior period, unchanged from 0001564590-14-003115:notes:37]

[0001564590-14-005096:notes:39]
Inventory at September 30, 2014 and March 31, 2014 consisted of the following (in thousands):

[0001564590-14-005096:notes:40]
|  | September 30, |  |  | March 31, |  |
|  | 2014 |  |  | 2014 |  |
| Raw materials | $ | 6,936 |  |  | $ | 3,304 |  |
| Work-in-process |  | 6,073 |  |  |  | 4,047 |  |
| Finished goods |  | 8,750 |  |  |  | 10,275 |  |
| Deferred program costs |  | 2,701 |  |  |  | 3,068 |  |
| Net inventory | $ | 24,460 |  |  | $ | 20,694 |  |

[0001564590-14-005096:notes:41]
The Company recorded inventory write-downs of $0.6 million and less than $0.1 million for the three months ended September 30, 2014 and 2013, respectively.  The Company recorded inventory write-downs of $1.3 million and $0.2 million for the six months ended September 30, 2014 and 2013, respectively.  These write downs were based on evaluating its inventory on hand for excess quantities and obsolescence.

[0001564590-14-005096:notes:42]
Deferred program costs as of September 30, 2014 and March 31, 2014 primarily represent costs incurred on programs accounted for under contract accounting where the Company needs to complete development programs before revenue and costs will be recognized.


## us-gaap:AccountsPayableAndAccruedLiabilitiesDisclosureTextBlock

[0001564590-14-005096:notes:43]
[same as prior period, unchanged from 0001564590-14-003115:notes:42]

[0001564590-14-005096:notes:44]
Accounts payable and accrued expenses at September 30, 2014 and March 31, 2014 consisted of the following (in thousands):

[0001564590-14-005096:notes:45]
|  | September 30, |  |  | March 31, |  |
|  | 2014 |  |  | 2014 |  |
| Accounts payable | $ | 7,063 |  |  | $ | 1,749 |  |
| Accrued inventories in-transit |  | 1,330 |  |  |  | 212 |  |
| Accrued miscellaneous expenses |  | 4,424 |  |  |  | 6,076 |  |
| Accrued outside services |  | 3,026 |  |  |  | 3,716 |  |
| Accrued subcontractor program costs |  | 60 |  |  |  | 290 |  |
| Accrued compensation |  | 4,070 |  |  |  | 5,939 |  |
| Income taxes payable |  | 197 |  |  |  | 173 |  |
| Accrued adverse purchase commitments |  | - |  |  |  | 402 |  |
| Accrued warranty |  | 3,367 |  |  |  | 3,207 |  |
| Total | $ | 23,537 |  |  | $ | 21,764 |  |

[0001564590-14-005096:notes:46]
[same as prior period, unchanged from 0001564590-14-003115:notes:45]

[0001564590-14-005096:notes:47]
[same as prior period, unchanged from 0001564590-14-003115:notes:46]

[0001564590-14-005096:notes:48]
|  | Three months ended September 30, |  |  | Six months ended September 30, |  |
|  | 2014 |  |  | 2013 |  |  | 2014 |  |  | 2013 |  |
| Balance at beginning of period | $ | 2,855 |  |  | $ | 2,787 |  |  | $ | 3,207 |  |  | $ | 2,709 |  |
| Change in accruals for warranties during the period |  | 974 |  |  |  | 342 |  |  |  | 903 |  |  |  | 493 |  |
| Settlements during the period |  | (462 | ) |  |  | (60 | ) |  |  | (743 | ) |  |  | (133 | ) |
| Balance at end of period | $ | 3,367 |  |  | $ | 3,069 |  |  | $ | 3,367 |  |  | $ | 3,069 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0001564590-14-005096:notes:49]
[same as prior period, unchanged from 0001564590-14-003115:notes:48]

[0001564590-14-005096:notes:50]
For the three and six months ended September 30, 2014, the Company recorded income tax expense of $0.1 million and $0.2 million, respectively.  For the three and six months ended September 30, 2013, the Company recorded income tax expense of $0.3 million and $0.4 million, respectively.  Income tax expense was primarily due to income taxes in the Company’s foreign jurisdictions.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001564590-14-005096:notes:51]
[same as prior period, unchanged from 0001564590-14-003115:notes:50]

[0001564590-14-005096:notes:52]
[same as prior period, unchanged from 0001564590-14-003115:notes:51]

[0001564590-14-005096:notes:53]
During the years ended March 31, 2014 and March 31, 2013, the Company undertook restructuring activities, approved by the Board of Directors, in order to reorganize its global operations, streamline various functions of the business, and reduce its global workforce to better reflect the demand for its products.  During the year ended March 31, 2014, the Company undertook a plan to consolidate its Grid manufacturing activities in its Devens, Massachusetts facility and close its facility in Middleton, Wisconsin.  In addition, the Company is establishing a new Wind manufacturing facility in Romania and as a result reduced the headcount in its operation in China to a level necessary to support demand from its Chinese customers.  The Company also undertook a workforce reduction in July 2013, reducing its workforce by approximately 7%, impacting primarily selling, engineering and general and administrative functions.  The Company recorded restructuring charges for severance and other costs of approximately $0.3 million and $1.4 million during the three and six months ended September 30, 2014, respectively.  During the six months ended September 30, 2013, the Company incurred restructuring costs of approximately $0.8 million. From April 1, 2011 through September 30, 2014, the Company’s various restructuring activities resulted in a substantial reduction of its global workforce. Remaining unpaid amounts under these restructuring activities are expected to be paid by August 31, 2015.

[0001564590-14-005096:notes:54]
[same as prior period, unchanged from 0001564590-14-003115:notes:53]

[0001564590-14-005096:notes:55]
|  | Severance pay |  |  | Facility Exit and |  |  |  |  |  |
| Six months ended September 30, 2014: | and benefits |  |  | Relocation costs |  |  | Total |  |
| Accrued restructuring balance at April 1, 2014 | $ | 844 |  |  | $ | - |  |  | $ | 844 |  |
| Charges to operations |  | 632 |  |  |  | 814 |  |  |  | 1,445 |  |
| Cash payments |  | (696 | ) |  |  | (814 | ) |  |  | (1,509 | ) |
| Accrued restructuring balance at September 30, 2014 | $ | 780 |  |  | $ | - |  |  | $ | 780 |  |
| Six months ended September 30, 2013: |  |  |  |  |  |  |  |  |  |  |  |
| Accrued restructuring at April 1, 2013 | $ | 145 |  |  | $ | 54 |  |  | $ | 199 |  |
| Charges to operations |  | 751 |  |  |  | 13 |  |  |  | 764 |  |
| Cash payments |  | (599 | ) |  |  | (37 | ) |  |  | (636 | ) |
| Non-cash/miscellaneous reductions |  | (166 | ) |  |  | (30 | ) |  |  | (196 | ) |
| Accrued restructuring balance at September 30, 2013 | $ | 131 |  |  | $ | - |  |  | $ | 131 |  |

[0001564590-14-005096:notes:56]
[same as prior period, unchanged from 0001564590-14-003115:notes:55]


## us-gaap:DebtDisclosureTextBlock

[0001564590-14-005096:notes:57]
10. Debt

[0001564590-14-005096:notes:58]
Senior Convertible Note

[0001564590-14-005096:notes:59]
On April 4, 2012, the Company entered into the Purchase Agreement with CVI and completed a private placement of the Initial Note. After fees and expenses, the net proceeds of the Initial Note were $23.2 million. The Initial Note had an initial conversion price of $4.85 per share, representing a premium of approximately 20% over AMSC’s closing price on April 3, 2012. The Initial Note was payable in monthly installments beginning four months from issuance and ending on October 4, 2014. Monthly payments were payable in cash or the Company’s common stock at the option of the Company, subject to certain trading volume, stock price and other conditions. CVI could elect to defer receipt of monthly installment payments at its option. Any deferred installment payments would continue to accrue interest. The Company registered 10,262,311 shares of common stock which could be used as payment for principal and interest in lieu of cash for resale under the Securities Act of 1933, as amended (the “Securities Act”) as required under a Registration Rights Agreement with CVI.

[0001564590-14-005096:notes:60]
The Company accounted for the Initial Note as an instrument that has the characteristics of a debt host contract containing several embedded derivative features that would require bifurcation and separate accounting as a derivative instrument pursuant to the provisions of ASC Topic 815 – Derivatives and Hedging (ASC 815). The Company elected not to use the fair value option for the aggregate amount of the Initial Note and recorded the liability at its stated value on the date of issuance with no changes in fair value reported in subsequent periods. The Company valued these derivatives at $3.8 million upon issuance of the Initial Note. (See Note 11, “Warrants and Derivative Liabilities,” for additional information regarding derivative liabilities.)

[0001564590-14-005096:notes:61]
In conjunction with the Initial Note, CVI received a warrant to purchase approximately 3.1 million additional shares of common stock exercisable at a strike price of $5.45 per share, subject to adjustment, until October 4, 2017. Due to certain adjustment provisions within the warrant, it qualified for liability accounting and had a fair value of $7.0 million upon issuance. The Company recorded the value as a debt discount and a warrant liability. (See Note 11, “Warrants and Derivative Liabilities,” for additional information regarding the warrant.)

[0001564590-14-005096:notes:62]
On December 20, 2012, the Company entered into an Amendment and Exchange Agreement, (the “Amendment”) with CVI, which amended the Purchase Agreement. Pursuant to the Amendment, the Company and CVI exchanged the Initial Note for the Exchanged Note. At the time of the exchange, the Exchanged Note had the same principal amount and accrued interest as the Initial Note. The Exchanged Note was convertible into the Company’s common stock and had the same scheduled monthly installment payments as the Initial Note. The Exchanged Note provided the Company with additional flexibility to make monthly installment payments in shares of the Company’s common stock. The Company retained the ability to repay the Exchanged Note in cash.

[0001564590-14-005096:notes:63]
The Company assessed the changes in the Exchanged Note and accounted for it as a modification of the Initial Note. Therefore, the Company determined the incremental value of the derivative instruments, as a result of the Exchanged Note, as having a reduced conversion price. As a result of the re-valuation, the Company recorded a $0.5 million increase in the value of the derivative liability and additional debt discount. At the modification date, the value of the derivative liability was $1.5 million. The total debt discount, including the embedded derivatives in the Initial Note, the incremental value of embedded derivatives in the Exchanged Note, warrant and legal and origination costs of $13.1 million was amortized into interest expense over the term of the Exchanged Note using the effective interest method. Under this method, interest expense was recognized each period until the debt instruments reached maturity. Given that the maturity of the Exchanged Note was accelerated due to prepayment, the amortization was accelerated.

[0001564590-14-005096:notes:64]
On October 9, 2013, the Company entered into a Second Amendment and Warrant Exchange Agreement (the “Second Amendment”) with CVI. The Second Amendment further amended the Purchase Agreement, as amended by the Amendment (collectively, the “Amended Purchase Agreement”), that the Company previously entered into with CVI.

[0001564590-14-005096:notes:65]
Pursuant to the Second Amendment, the Company and/or CVI waived certain provisions of the Amended Purchase Agreement and amended certain provisions of the Exchanged Note and exchanged the warrant (the “Original Warrant”) for a new warrant (the Exchanged Warrant”) with a reduced exercise price of $2.61 per share of common stock.

[0001564590-14-005096:notes:66]
The Company assessed the changes to the Exchanged Note included in the Second Amendment and accounted for it as a modification of the Exchanged Note. Therefore, the Company determined the incremental value of the derivative instruments, as a result of the Second Amendment, specifically the Exchanged Warrant. (See Note 11 “Warrants and Derivative Liabilities” for discussion of the valuation of the Exchanged Warrant.)

[0001564590-14-005096:notes:67]
During the three and six months ended September 30, 2013, the Company recorded non-cash interest expense for amortization of the debt discount related to the convertible notes of $1.2 million and $2.7 million, respectively.

[0001564590-14-005096:notes:68]
Provided certain equity conditions were met, the Company could elect to repay principal and interest in shares of the Company’s common stock. If the Company elected to make a payment in shares of the Company’s common stock, the number of shares issued was determined by dividing the amount of such payment by 85% of the lessor of the average volume-weighted average price (“VWAP”) of the 10 consecutive days immediately preceding the payment date or the VWAP price on the day preceding the payment date (the “Market Price”). The Company recorded the difference between the closing price of its common stock on the day preceding the payment date and the Market Price as a discount on the fair value of its shares. During both the three and six months ended September 30, 2013, the Company recorded $1.8 million of non-cash interest expense related to installment payments made by issuing the Company’s common stock at a discount.

[0001564590-14-005096:notes:69]
On March 2, 2014, the Company entered into an Exchange Agreement with CVI, pursuant to which the Company exchanged the Exchanged Note for approximately 6.6 million shares of common stock and extinguished the debt.  As a result of this transaction, the Company recorded a loss on the extinguishment of debt of $5.2 million during the three months ended March 31, 2014.

[0001564590-14-005096:notes:70]
Senior Secured Term Loans

[0001564590-14-005096:notes:71]
On June 5, 2012, the Company entered into the Term Loan with Hercules, under which the Company borrowed $10.0 million. After the closing fees and expenses, the net proceeds to the Company were $9.7 million. The Term Loan bears an interest rate equal to 11% plus the percentage, if any, by which the prime rate as reported by The Wall Street Journal exceeds 3.75%. The Company made interest-only payments from July 1, 2012 through October 31, 2012, after which the Company began repaying the Term Loan in equal monthly installments ending on December 1, 2014. In addition, Hercules received a warrant (the “First Warrant”) to purchase 139,276 shares of common stock, exercisable at an initial strike price of $3.59 per share, subject to adjustment, until December 5, 2017. Due to certain adjustment provisions within the warrant, it qualified for liability accounting and the fair value of $0.4 million was recorded upon issuance, which the Company recorded as a debt discount and a warrant liability.  The Company will pay an end of term fee of $0.5 million upon the earlier of maturity or prepayment of the loan. The Company has accrued the term fee and recorded a corresponding amount into the debt discount. In addition, the Company incurred $0.3 million of legal and origination costs in the year ended March 31, 2013, which have been recorded as a debt discount. The total debt discount including the First Warrant, end of term fee and legal and origination costs of $1.2 million is being amortized into interest expense over the term of the Term Loan using the effective interest method. Under this method, interest expense is recognized each period until the debt instrument reaches maturity. During the three and six months ended September 30, 2014, the Company recorded non-cash interest expense for amortization of the debt discount related to the Term Loan of less than $0.1 million and $0.1 million, respectively.  During the three and six months ended September 30, 2013, the Company recorded non-cash interest expense for amortization of the debt discount related to the Term Loan of $0.1 million and $0.3 million, respectively.

[0001564590-14-005096:notes:72]
On November 15, 2013, the Company amended the Term Loan with Hercules and entered into the New Term Loan, borrowing an additional $10.0 million. After closing fees and expenses, the net proceeds to the Company for the New Term Loan were $9.8 million.  The New Term Loan also bears the same interest rate as the Term Loan.  The Company made interest-only payments from December 1, 2013 to May 31, 2014.  If the Company achieved certain revenue targets for the six-month period ending March 31, 2014, interest only payments would continue through August 31, 2014.  The Company did not meet these revenue targets.  As a result, the Company is repaying the New Term Loan in equal monthly installments ending on November 1, 2016.  Hercules received a warrant (the “Second Warrant”) to purchase 256,410 shares of common stock, exercisable at an initial strike price of $1.95 per share, subject to adjustment, until May 15, 2019.  In addition, the exercise price of the First Warrant was reduced to $1.95 per share.  (See Note 11, “Warrants and Derivative Liabilities,” for a discussion on both warrants and the valuation assumptions used.) The Company will pay an end of term fee of $0.5 million upon the earlier of maturity or prepayment of the New Term Loan. The Company has accrued the end of term fee and recorded a corresponding amount into the debt discount.  The New Term Loan includes a mandatory prepayment feature which allows Hercules the right to use any of the Company’s net proceeds from specified asset dispositions greater than $1.0 million in a calendar year to pay off any outstanding accrued interest and principal balance on the New Term Loan.  The Company determined the fair value to be de-minimis for this feature. In addition, the Company incurred $0.2 million of legal and origination costs in the three months ended December 31, 2013, which have been recorded as a debt discount. The total debt discount including the Second Warrant, end of term fee and legal and origination costs of $1.0 million is being amortized into interest expense over the term of the New Term Loan using the effective interest method. If the maturity of either of the term loans is accelerated because of prepayment, then the amortization will be accelerated. During the three and six months ended September 30, 2014, the Company recorded non-cash interest expense for amortization of the debt discount related to the New Term Loan of $0.1 million and $0.2 million, respectively.

[0001564590-14-005096:notes:73]
The Term Loans are secured by substantially all of the Company’s existing and future assets, including a mortgage on real property owned by the Company’s wholly-owned subsidiary, ASC Devens LLC, and located at 64 Jackson Road, Devens, Massachusetts.  The Term Loans contain certain covenants that restrict the Company’s ability to, among other things, incur or assume certain debt, merge or consolidate, materially change the nature of the Company’s business, make certain investments, acquire or dispose of certain assets, make guaranties or grant liens on its assets, make certain loans, advances or investments, declare dividends or make distributions or enter into transactions with affiliates. In addition, there is a covenant that requires the Company to maintain a minimum unrestricted cash balance (the “Minimum Threshold”) in the United States of at least $15.0 million at the inception of the New Term Loan.  The Minimum Threshold will be reduced by $2.5 million for every $5.0 million of net proceeds from the sale of its common stock after November 15, 2013, including those under the ATM, to an amount not lower than $7.5 million or the outstanding combined principal balances of the Term Loans, whichever is lower.  As of September 30, 2014, the Minimum Threshold was $9.8 million.  The events of default under the Term Loans include, but are not limited to, failure to pay amounts due, breaches of covenants, bankruptcy events, cross defaults under other material indebtedness and the occurrence of a material adverse effect and/or change in control. In the case of a continuing event of default, Hercules may, among other remedies, declare due all unpaid principal amounts outstanding and any accrued but unpaid interest and foreclose on all collateral granted to Hercules as security under the Term Loans.

[0001564590-14-005096:notes:74]
Although the Company believes that it is in and expects to remain in compliance with the covenants and restrictions under the Term Loans as of the date of this Quarterly Report on Form 10-Q, there can be no assurance that the Company will continue to be in compliance.

[0001564590-14-005096:notes:75]
Interest expense on the Term Loans for the three and six months ended September 30, 2014, was $0.5 million and $1.0 million, respectively, which included $0.2 million and $0.3 million, respectively, of non-cash interest expense related to the amortization of the debt discount on the Term Loans.  Interest expense on the Exchanged Note and Term Loans for the three and six months ended September 30, 2013, was $3.5 million and $5.6 million, respectively, which included $3.1 million and $4.8 million, respectively, of non-cash interest expense related to the amortization of the debt discount on the Exchanged Note and Term Loans and payment of the Exchanged Note in Company common stock at a discount.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001564590-14-005096:notes:76]
[same as prior period, unchanged from 0001564590-14-003115:notes:75]

[0001564590-14-005096:notes:77]
[same as prior period, unchanged from 0001564590-14-003115:notes:76]

[0001564590-14-005096:notes:78]
On April 4, 2012, the Company entered into the Purchase Agreement with CVI. The Purchase Agreement included the Original Warrant to purchase 3,094,060 shares of the Company’s common stock. The warrant is exercisable at any time on or after the date that is six months after the issuance of the warrant and entitles CVI to purchase shares of the Company’s common stock for a period of five years from the initial date the warrant becomes exercisable at a price equal to $5.45 per share, subject to certain price-based and other anti-dilution adjustments. On October 9, 2013, the Company amended the Purchase Agreement with CVI (the “Amendment”). Pursuant to the Amendment, the Company exchanged the Original Warrant for the Exchanged Warrant, with a reduced exercise price of $2.61 per share of common stock. Other than the reduced exercise price, the Exchanged Warrant has the same terms and conditions as the Original Warrant.  As a result of the sales of common stock under the ATM (See Note 12, “Stockholders’ Equity”, for further discussion of the ATM), and other issuances, during the three months ended September 30, 2014, the exercise price of the Exchanged Warrant was reduced to $2.55 per share.  The Exchanged Warrant may not be exercised if, after giving effect to the conversion, CVI together with its affiliates would beneficially own in excess of 4.99% of the Company’s common stock. This percentage may be raised to any other percentage not in excess of 9.99% at the option of CVI, upon at least 61-days prior notice to the Company, or lowered to any other percentage, at the option of CVI, at any time.

[0001564590-14-005096:notes:79]
[same as prior period, unchanged from 0001564590-14-003115:notes:78]

[0001564590-14-005096:notes:80]
[same as prior period, unchanged from 0001564590-14-003115:notes:79]

[0001564590-14-005096:notes:81]
[same as prior period, unchanged from 0001564590-14-003115:notes:80]

[0001564590-14-005096:notes:82]
|  | September 30, |  |  | June 30, |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Fiscal Year 14 | 2014 |  |  | 2014 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Risk-free interest rate |  | 1.07 | % |  |  | 0.98 | % |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Expected annual dividend yield |  | — | % |  |  | — | % |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Expected volatility |  | 76.20 | % |  |  | 83.50 | % |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Term (years) | 3.01 |  |  | 3.26 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Fair value | $1.5 million |  |  | $2.3 million |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  |  |  |  |  |  |  |  | Post-modification |  |  | Pre-modification |  |  |  |  |  |  |  |  |  |  |  |  |
|  | March 31, |  |  | December 31, |  |  | October 9, |  |  | October 9, |  |  | September 30, |  |  | June 30, |  | March 31, |  |
| Fiscal Year 13 | 2014 |  |  | 2013 |  |  | 2013 |  |  | 2013 |  |  | 2013 |  |  | 2013 |  | 2013 |  |
| Risk-free interest rate |  | 1.11 | % |  |  | 1.17 | % |  |  | 1.05 | % |  |  | 1.05 | % |  |  | 1.02 | % |  |  | 1.13 | % |  | 0.67 | % |
| Expected annual dividend yield |  | — | % |  |  | — | % |  |  | — | % |  |  | — | % |  |  | — | % |  |  | — | % |  | — | % |
| Expected volatility |  | 80.99 | % |  |  | 75.60 | % |  |  | 71.45 | % |  |  | 71.45 | % |  |  | 71.98 | % |  |  | 71.90 | % |  | 71.74 | % |
| Term (years) | 3.51 |  |  | 3.76 |  |  | 3.99 |  |  | 3.99 |  |  |  | 4.01 |  |  |  | 4.27 |  |  | 4.51 |  |
| Fair value | $ 2.2 million |  |  | $ 2.2 million |  |  | $ 3.2 million |  |  | $ 2.2 million |  |  | $ 2.5 million |  |  | $ 3.0 million |  | $ 3.4 million |  |

[0001564590-14-005096:notes:83]
The Company recorded net gains, resulting from the decrease in the fair value of the Exchanged Warrant, of $0.8 million and $0.5 million to change in fair value of derivatives and warrants in the three months ended September 30, 2014, and 2013, respectively.  The Company recorded net gains, resulting from the decrease in the fair value of the Exchanged Warrant, of $0.7 million and $0.9 million to change in fair value of derivatives and warrants in the six months ended September 30, 2014, and 2013, respectively.

[0001564590-14-005096:notes:84]
[same as prior period, unchanged from 0001564590-14-003115:notes:83]

[0001564590-14-005096:notes:85]
[same as prior period, unchanged from 0001564590-14-003115:notes:84]

[0001564590-14-005096:notes:86]
[same as prior period, unchanged from 0001564590-14-003115:notes:85]

[0001564590-14-005096:notes:87]
On March 2, 2014, the Company entered into an Exchange Agreement with CVI, pursuant to which the Company exchanged the Exchanged Note for approximately 6.6 million shares of common stock, in full satisfaction of all amounts owed under the Exchanged Note, including any accrued interest.  In addition, the Company extinguished the remaining value for the derivative liability identified with the Exchanged Note and any unamortized debt discount.

[0001564590-14-005096:notes:88]
[same as prior period, unchanged from 0001564590-14-003115:notes:87]

[0001564590-14-005096:notes:89]
|  | March 31, |  | December 31, |  |  | September 30, |  |  | June 30, |  | March 31, |  |
| Fiscal Year 13 | 2014 |  | 2013 |  |  | 2013 |  |  | 2013 |  | 2013 |  |
| Principal outstanding (000's) | $ — |  | $ | 10,411 |  |  | $ | 10,411 |  |  | $ | 14,389 |  | $ | 15,380 |  |
| Stock price | N/A |  | $ | 1.64 |  |  | $ | 2.34 |  |  | $ | 2.64 |  | $ | 2.67 |  |
| Percentage volume condition met | — % |  |  | 87.20 | % |  |  | 80.20 | % |  |  | 87.50 | % |  | 80.50 | % |
| Expected volatility | — % |  |  | 68.63 | % |  |  | 66.26 | % |  |  | 65.80 | % |  | 66.91 | % |
| Risk free rate | — % |  |  | 0.12 | % |  |  | 0.10 | % |  |  | 0.21 | % |  | 0.20 | % |
| Bond yield | — % |  |  | 16.50 | % |  |  | 15.50 | % |  |  | 16.70 | % |  | 16.50 | % |
| Recovery rate | — % |  |  | 35.00 | % |  |  | 35.00 | % |  |  | 37.00 | % |  | 30.00 | % |
| Redeemable | N/A |  | yes |  |  | yes |  |  | yes |  | yes |  |
| Total time (years) | — |  |  | 0.75 |  |  |  | 1.00 |  |  |  | 1.26 |  |  | 1.51 |  |
| Dilution effect | N/A |  | yes |  |  | yes |  |  | yes |  | yes |  |
| Fair value | $ — |  | $ — |  |  | $ 0.2 million |  |  | $ 0.5 million |  | $ 0.5 million |  |
| Fair value as a percent of par | — % |  |  | 0.02 | % |  |  | 0.70 | % |  |  | 3.3 | % |  | 3.4 | % |

[0001564590-14-005096:notes:90]
[same as prior period, unchanged from 0001564590-14-003115:notes:89]

[0001564590-14-005096:notes:91]
The Company recorded net gains, resulting from the decrease in the fair value of the derivative, of $0.3 million to change in fair value of derivatives and warrants in each of the three and six months ended September 30, 2013.

[0001564590-14-005096:notes:92]
[same as prior period, unchanged from 0001564590-14-003115:notes:91]

[0001564590-14-005096:notes:93]
On June 5, 2012, the Company entered into the Loan and Security Agreement with Hercules. (See Note 10, “Debt,” for additional information regarding the Loan and Security Agreement.) In conjunction with this agreement, the Company issued the First Warrant to purchase 139,276 shares of the Company’s common stock. The First Warrant is exercisable at any time after its issuance and expires on December 5, 2017, at a price equal to $3.59 per share subject to certain price-based and other anti-dilution adjustments.  The exercise price was reduced to $1.95 per share in conjunction with entering into the New Term Loan.  An anti-dilution adjustment resulted in a reduction to the exercise price to $1.94 per share as of September 30, 2014.

[0001564590-14-005096:notes:94]
[same as prior period, unchanged from 0001564590-14-003115:notes:93]

[0001564590-14-005096:notes:95]
[same as prior period, unchanged from 0001564590-14-003115:notes:94]

[0001564590-14-005096:notes:96]
|  | September 30, |  |  | June 30, |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Fiscal Year 14 | 2014 |  |  | 2014 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Risk-free interest rate |  | 1.13 | % |  |  | 1.04 | % |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Expected annual dividend yield |  | — | % |  |  | — | % |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Expected volatility |  | 78.30 | % |  |  | 82.75 | % |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Term (years) |  | 3.18 |  |  |  | 3.43 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Fair value | $ 0.1 million |  |  | $ 0.1 million |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  |  |  |  |  |  |  |  | Post-modification |  |  | Pre-modification |  |  |  |  |  |  |  |  |  |  |  |  |
|  | March 31, |  |  | December 31, |  |  | November 15, |  |  | November 15, |  |  | September 30, |  |  | June 30, |  | March 31, |  |
| Fiscal Year 13 | 2014 |  |  | 2013 |  |  | 2013 |  |  | 2013 |  |  | 2013 |  |  | 2013 |  | 2013 |  |
| Risk-free interest rate |  | 1.18 | % |  |  | 1.24 | % |  |  | 1.00 | % |  |  | 1.00 | % |  |  | 1.09 | % |  |  | 1.20 | % |  | 0.70 | % |
| Expected annual dividend yield |  | — | % |  |  | — | % |  |  | — | % |  |  | — | % |  |  | — | % |  |  | — | % |  | — | % |
| Expected volatility |  | 80.73 | % |  |  | 74.79 | % |  |  | 72.64 | % |  |  | 72.64 | % |  |  | 72.10 | % |  |  | 72.30 | % |  | 72.01 | % |
| Term (years) |  | 3.68 |  |  |  | 3.93 |  |  |  | 4.05 |  |  |  | 4.05 |  |  |  | 4.18 |  |  |  | 4.43 |  |  | 4.68 |  |
| Fair value | $ 0.1 million |  |  | $ 0.1 million |  |  | $ 0.1 million |  |  | $ 0.1 million |  |  | $ 0.2 million |  |  | $ 0.2 million |  | $ 0.2 million |  |

[0001564590-14-005096:notes:97]
The Company recorded no change in fair value of derivatives and warrants during either of the three or six month periods ended September 30, 2014 and 2013 due to nominal fair value fluctuation.

[0001564590-14-005096:notes:98]
[same as prior period, unchanged from 0001564590-14-003115:notes:97]

[0001564590-14-005096:notes:99]
On November 15, 2013, the Company amended the Loan and Security Agreement with Hercules and entered into the New Term Loan. (See Note 10, “Debt,” for additional information regarding the New Term Loan.) In conjunction with this agreement, the Company issued the Second Warrant to purchase 256,410 shares of the Company’s common stock. The Second Warrant is exercisable at any time after its issuance and expires on May 15, 2019, at a price equal to $1.95 per share subject to certain price-based and other anti-dilution adjustments.  An anti-dilution adjustment resulted in a reduction to the exercise price to $1.94 per share as of September 30, 2014.

[0001564590-14-005096:notes:100]
[same as prior period, unchanged from 0001564590-14-003115:notes:99]

[0001564590-14-005096:notes:101]
[same as prior period, unchanged from 0001564590-14-003115:notes:100]

[0001564590-14-005096:notes:102]
|  | September 30, |  |  | June 30, |  |  |  |  |  |
| Fiscal Year 14 | 2014 |  |  | 2014 |  |  |  |  |  |
| Risk-free interest rate |  | 1.65 | % |  |  | 1.57 | % |  |  |  |  |
| Expected annual dividend yield |  | — | % |  |  | — | % |  |  |  |  |
| Expected volatility |  | 78.10 | % |  |  | 80.00 | % |  |  |  |  |
| Term (years) |  | 4.62 |  |  |  | 4.87 |  |  |  |  |  |
| Fair value | $ 0.2 million |  |  | $ 0.3 million |  |  |  |  |  |
|  |  |  |  |  |  |  |  |  | New Issuance |  |
|  | March 31, |  |  | December 31, |  |  | November 15, |  |
| Fiscal Year 13 | 2014 |  |  | 2013 |  |  | 2013 |  |
| Risk-free interest rate |  | 1.76 | % |  |  | 1.89 | % |  |  | 1.55 | % |
| Expected annual dividend yield |  | — | % |  |  | — | % |  |  | — | % |
| Expected volatility |  | 79.73 | % |  |  | 80.37 | % |  |  | 76.97 | % |
| Term (years) |  | 5.12 |  |  |  | 5.37 |  |  |  | 5.49 |  |
| Fair value | $ 0.3 million |  |  | $ 0.3 million |  |  | $ 0.3 million |  |

[0001564590-14-005096:notes:103]
The Company recorded a decrease in the fair value of the Second Warrant resulting in a gain of $0.1 million in each of the three and six months ended September 30, 2014.

[0001564590-14-005096:notes:104]
[same as prior period, unchanged from 0001564590-14-003115:notes:103]


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001564590-14-005096:notes:105]
12. Stockholders’ Equity

[0001564590-14-005096:notes:106]
On November 15, 2013, the Company entered into an ATM arrangement, pursuant to which, the Company may, at its discretion, sell up to $30.0 million of the Company’s common stock through its sales agent, MLV.   Sales of common stock made under the ATM are made on The NASDAQ Global Market under the Company’s previously filed and currently effective Registration Statement on Form S-3 (File No. 333-191153) by means of ordinary brokers’ transactions at market prices. Additionally, under the terms of the ATM, the Company may also sell shares of its common stock through MLV, on The NASDAQ Global Select Market or otherwise, at negotiated prices or at prices related to the prevailing market price. Under the terms of the ATM, MLV may not engage in any proprietary trading or trading as principal for MLV’s own account. MLV uses its commercially reasonable efforts to sell the Company’s common stock from time to time, based upon the Company’s instructions (including any price, time or size limits or other customary parameters or conditions the Company may impose). The Company pays MLV a commission of up to 3% of the gross proceeds from the sale of shares of its common stock under the ATM. The Company has also agreed to provide MLV with customary indemnification rights. The offering of common stock pursuant to the ATM will terminate upon the earlier of the sale of all of the common stock subject to the ATM or the termination of the ATM by the Company or MLV. Either party may terminate the ATM at its sole discretion at any time upon written notice to the other party.

[0001564590-14-005096:notes:107]
During the three months ended September 30, 2014, the Company received net proceeds of $3.7 million, including sales commissions and offering expenses, from sales of approximately 2.1 million shares of its common stock at an average sales price of approximately $1.75 per share under the ATM.  As of September 30, 2014, the Company has approximately $17.1 million of remaining availability under the ATM.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001564590-14-005096:notes:108]
13. Commitments and Contingencies

[0001564590-14-005096:notes:109]
Commitments

[0001564590-14-005096:notes:110]
Purchase Commitments

[0001564590-14-005096:notes:111]
The Company periodically enters into non-cancelable purchase contracts in order to ensure the availability of materials to support production of its products. Purchase commitments represent enforceable and legally binding agreements with suppliers to purchase goods or services. The Company periodically assesses the need to provide for impairment on these purchase contracts and record a loss on purchase commitments when required. As of September 30, 2014, the Company had paid the remaining adverse purchase commitment liability.

[0001564590-14-005096:notes:112]
Legal Contingencies

[0001564590-14-005096:notes:113]
From time to time, the Company is involved in legal and administrative proceedings and claims of various types. The Company records a liability in its consolidated financial statements for these matters when a loss is known or considered probable and the amount can be reasonably estimated. The Company reviews these estimates each accounting period as additional information is known and adjusts the loss provision when appropriate. If a matter is both probable to result in a liability and the amounts of loss can be reasonably estimated, the Company estimates and discloses the possible loss or range of loss. If the loss is not probable or cannot be reasonably estimated, a liability is not recorded in its consolidated financial statements.

[0001564590-14-005096:notes:114]
Ghodawat, a company registered in India carrying on the business of wind power development, lodged a Request for Arbitration with the ICC Court on May 12, 2011 and named AMSC Windtec GmbH (“AMSC Austria”) as the Respondent. Under the Request for Arbitration, Ghodawat alleged that AMSC Austria breached an agreement dated March 19, 2008 pursuant to which AMSC Austria granted a license to Ghodawat to manufacture, use, sell, market, erect, commission and maintain certain wind turbines using its technical information and wind turbine design (the “License Agreement”). Under the Request for Arbitration, Ghodawat’s claims in this arbitration amounted to approximately €18 million ($24 million).  AMSC Austria submitted counterclaims under the License Agreement against Ghodawat in the amount of approximately €6 million ($8 million).  On August 29, 2014, the ICC Court ruled that AMSC Austria was liable for damages and awarded Ghodawat approximately €8.3 million (approximately $10.6 million), which includes reimbursement of legal costs and associated expenses.  Interest on this amount will accrue at a rate of 5.33% from the date of award.  The Company had recorded a loss contingency of $0.5 million based on its assessment of probable losses on this claim in a prior period.  As a result of the arbitration award liability, the Company recorded a charge of $10.2 million during the three months ended September 30, 2014.

[0001564590-14-005096:notes:115]
Between April 6, 2011 and May 12, 2011, seven putative securities class action complaints were filed against the Company and two of its officers in the United States District Court for the District of Massachusetts (the “Court”); one complaint additionally asserted claims against the underwriters who participated in its November 12, 2010 securities offering. On June 7, 2011, the Court consolidated these actions under the caption Lenartz v. American Superconductor Corporation, et al., Docket No. 1:11-cv-10582-WGY. On August 31, 2011, Lead Plaintiff, the Plumbers and Pipefitters National Pension Fund, filed a consolidated amended complaint against the Company, its officers and directors, and the underwriters who participated in its November 12, 2010 securities offering, asserting claims under sections 10(b) and 20(a) of the Securities Exchange Act of 1934, as amended (the “Exchange Act”) and Rule 10b-5 promulgated under the Exchange Act, as well as under sections 11, 12(a)(2) and 15 of the Securities Act.  On November 19, 2013, the Company entered into a Stipulation and Agreement of Settlement (the “Stipulation”), which resolved the claims asserted against the Company, certain of its current and former officers and directors, and the underwriters. The terms of the Stipulation provided, among other things, a settlement payment by the Company of $10.0 million, $8.2 million of which was to be funded by the Company’s insurers and $1.8 million of which was paid through the issuance of 944,882 shares of its common stock (the “Settlement Shares”). In the event that the value of the Settlement Shares (as calculated under the Stipulation) decreased as of the effective date of the settlement, the Company was required to make a cash payment for the difference in value.  The effective date of the Stipulation was June 5, 2014 (the “Effective Date”).  Pursuant to the terms of the Stipulation, (i) on June 11, 2014, the Company made a cash payment of approximately $0.5 million for the decrease in value of the Settlement Shares (as calculated under the Stipulation) as of the Effective Date, and (ii) on June 18, 2014, the Company issued the Settlement Shares.  The issuance of the Settlement Shares was exempt from registration pursuant to Section 3(a)(10) of the Securities Act.  The aforementioned payments by the Company represented the final amounts to be paid to the plaintiffs under the Stipulation.

[0001564590-14-005096:notes:116]
Between May 4, 2011 and June 17, 2011, four putative shareholder derivative complaints were filed against the Company (as a nominal defendant) and certain of its directors in the Court. On July 5, 2011, the Court consolidated three of these actions under the caption In re American Superconductor Corporation Derivative Litigation, Docket No. 1:11-cv-10784-WGY. On June 1, 2011, the plaintiff in the fourth action, Marlborough Family Revocable Trust v. Yurek, et al., moved to voluntarily dismiss its complaint and refiled its complaint in Superior Court for the Commonwealth of Massachusetts, Middlesex County. On September 7, 2011, the Marlborough action and another putative shareholder derivative complaint filed in Superior Court for the Commonwealth of Massachusetts were consolidated. That consolidated matter was captioned In re American Superconductor Corporation Shareholder Derivative Litigation, Docket No. 11-1961. On January 12, 2012, an additional shareholder derivative complaint was filed in the Court of Chancery for the State of Delaware. That matter was captioned Krasnoff v. Budhraja, et al., Docket No. 7171. On February 4, 2014, the Company entered into a Stipulation and Agreement of Settlement (the “Derivative Stipulation”) to settle In re American Superconductor Corporation Derivative Litigation, In re American Superconductor Corporation Shareholder Derivative Litigation, and Krasnoff v. Budhraja, et al., (together, the “Derivative Actions”).  The Derivative Stipulation provided for, among other things, (a) a release of all claims relating to the Derivative Actions for the Company, the individual defendants, who are all current or former officers and directors of the Company, and the plaintiffs; (b) a requirement that the Company pay to plaintiffs’ counsel $475,000 for fees and expenses, which was fully funded by the Company’s insurers; and (c) certain additions to the Company’s corporate governance policies. The terms of the Derivative Stipulation were subject to approval by the Court following notice to stockholders. By order entered May 8, 2014, the Court approved the terms of the Derivative Stipulation and issued a final judgment dismissing In re American Superconductor Corporation Derivative Litigation.  Pursuant to the terms of the Derivative Stipulation, the Company and the plaintiffs subsequently jointly sought and obtained dismissal of In re American Superconductor Corporation Shareholder Derivative Litigation, and Krasnoff v. Budhraja, et al. The effective date of the settlement was June 10, 2014.

[0001564590-14-005096:notes:117]
On September 13, 2011, the Company commenced a series of legal actions in China against Sinovel Wind Group Co. Ltd. (“Sinovel”). The Company’s Chinese subsidiary, Suzhou AMSC Superconductor Co. Ltd., filed a claim for arbitration with the Beijing Arbitration Commission in accordance with the terms of the Company’s supply contracts with Sinovel. The case is captioned (2011) Jing Zhong An Zi No. 0963. On March 31, 2011, Sinovel refused to accept contracted shipments of 1.5 megawatt, (“MW”) and 3 MW wind turbine core electrical components and spare parts that the Company was prepared to deliver. The Company alleges that these actions constitute material breaches of its contracts because Sinovel did not give it notice that it intended to delay deliveries as required under the contracts. Moreover, the Company alleges that Sinovel has refused to pay past due amounts for prior shipments of core electrical components and spare parts. The Company is seeking compensation for past product shipments and retention (including interest) in the amount of approximately RMB 485 million ($76 million) due to Sinovel’s breaches of its contracts. The Company is also seeking specific performance of its existing contracts as well as reimbursement of all costs and reasonable expenses with respect to the arbitration. The value of the undelivered components under the existing contracts, including the deliveries refused by Sinovel in March 2011, amounts to approximately RMB 4.6 billion ($720 million).

[0001564590-14-005096:notes:118]
On October 8, 2011, Sinovel filed with the Beijing Arbitration Commission an application under the caption (2011) Jing Zhong An Zi No. 0963, for a counterclaim against the Company for breach of the same contracts under which the Company filed its original arbitration claim. Sinovel claimed, among other things, that the goods supplied by the Company do not conform to the standards specified in the contracts and claimed damages in the amount of approximately RMB 370 million ($58 million). On October 17, 2011, Sinovel filed with the Beijing Arbitration Commission a request for change of counterclaim to increase its damage claim to approximately RMB 1 billion ($157 million). On December 22, 2011, Sinovel filed with the Beijing Arbitration Commission an additional request for change of counterclaim to increase its damages claim to approximately RMB 1.2 billion ($190 million). On February 27, 2012, Sinovel filed with the Beijing Arbitration Commission an application under the caption (2012) Jing Zhong An Zi No. 0157, against the Company for breach of the same contracts under which the Company filed its original arbitration claim. Sinovel claimed, among other things, that the goods supplied by the Company do not conform to the standards specified in the contracts and claimed damages in the amount of approximately RMB 105 million ($17 million). The Company believes that Sinovel’s claims are without merit and it intends to defend these actions vigorously. Since the proceedings in this matter are in relatively early stages, the Company cannot reasonably estimate possible losses or range of losses at this time.

[0001564590-14-005096:notes:119]
The Company also submitted a civil action application to the Beijing No. 1 Intermediate People’s Court under the caption (2011) Yi Zhong Min Chu Zi No. 15524, against Sinovel for software copyright infringement on September 13, 2011. The application alleges Sinovel’s unauthorized use of portions of the Company’s wind turbine control software source code developed for Sinovel’s 1.5MW wind turbines and the binary code, or upper layer, of the Company’s software for the PM3000 power converters in 1.5MW wind turbines. In July 2011, a former employee of the Company’s Austrian subsidiary was arrested in Austria on charges of economic espionage and fraudulent manipulation of data. In September 2011, the former employee pled guilty to the charges, and was imprisoned. As a result of the Company’s internal investigation and a criminal investigation conducted by Austrian authorities, the Company believes that this former employee was contracted by Sinovel through an intermediary while employed by the Company and improperly obtained and transferred to Sinovel portions of its wind turbine control software source code developed for Sinovel’s 1.5MW wind turbines. Moreover, the Company believes the former employee illegally used source code to develop for Sinovel a software modification to circumvent the encryption and remove technical protection measures on the Company’s PM3000 power converters in 1.5MW wind turbines in the field. The Company is seeking a cease and desist order with respect to the unauthorized copying, installation and use of its software, monetary damages of approximately RMB 38 million ($6 million) for its economic losses and reimbursement of all costs and reasonable expenses. The Beijing No. 1 Intermediate People’s Court accepted the case, which was necessary in order for the case to proceed. In November 2011, Sinovel filed a motion to remove this case from the Beijing No. 1 Intermediate People’s Court and transfer the matter to the Beijing Arbitration Commission. On February 14, 2012, the court denied Sinovel’s motion to remove the case. On February 21, 2012, Sinovel filed an appeal of the Beijing No. 1 Intermediate People’s Court decision to the Beijing Higher People’s Court. On April 25, 2012, the Beijing Higher People’s Court issued a final Civil Ruling which supports the Beijing No.1 Intermediate People’s Court’s civil ruling and rejected Sinovel’s appeal. Sinovel filed an appeal of the Beijing Higher People’s Court’s decision with China’s Supreme People’s Court. A hearing regarding this appeal was held at the Chinese Supreme People’s Court on October 26, 2012. On November 23, 2012, China’s Supreme People’s Court issued a Civil Ruling, holding that (1) it will conduct a re-trial of Sinovel’s appeal, and (2) the lower court’s decision will be stayed pending the re-trial. China’s Supreme People’s Court conducted a re-trial of Sinovel’s appeal on May 29, 2013.  On January 26, 2014, the Supreme People’s Court ruled to uphold the Beijing Higher People’s Court ruling that the dispute shall be heard by the court.  On September 15, 2014, the Beijing No. 1 Intermediate People’s Court held its first substantive hearing in the Beijing case.  At the hearing, the parties presented evidence, reviewed claims, and answered questions from the court.  The Company is awaiting a decision from the Beijing No. 1 Intermediate People’s Court.

[0001564590-14-005096:notes:120]
The Company submitted a civil action application to the Beijing Higher People’s Court against Sinovel and certain of its employees for trade secret infringement on September 13, 2011 under the caption (2011) Gao Min Chu Zi No. 4193. The application alleges the defendants’ unauthorized use of portions of the Company’s wind turbine control software source code developed for Sinovel’s 1.5MW wind turbines as described above with respect to the Copyright Action. The Company is seeking monetary damages of RMB 2.9 billion ($453 million) for the trade secret infringement as well as reimbursement of all costs and reasonable expenses. The Beijing Higher People’s Court accepted the case, which was necessary in order for the case to proceed. On December 22, 2011, the Beijing Higher People’s Court transferred this case to the Beijing No. 1 Intermediate People’s Court under the caption (2011) Gao Min Chu Zi No. 4193. On June 7, 2012, the Company received an Acceptance Notice from the Beijing No.1 Intermediate People’s Court under the caption (2012) Yi Zhong Min Chu Zi No.6833. In August 2012, Sinovel filed a motion to remove this case from the Beijing No. 1 Intermediate People’s Court and transfer the matter to the Beijing Arbitration Commission. On February 24, 2014, the Beijing No. 1 Intermediate People’s Court denied Sinovel’s motion to remove and transfer the case.  On March 13, 2014, Sinovel filed an appeal of the Beijing No. 1 Intermediate People’s Court decision to the Beijing Higher People’s Court.  On August 7, 2014, the Beijing Higher People’s Court upheld the Beijing No.1 Intermediate Court’s decision and rejected Sinovel’s appeal regarding the jurisdiction opposition.  The Company is currently awaiting notice from the Beijing No. 1 Intermediate People’s Court regarding the first hearing date.

[0001564590-14-005096:notes:121]
On September 16, 2011, the Company filed a civil copyright infringement complaint in the Hainan Province No. 1 Intermediate People’s Court against Dalian Guotong Electric Co. Ltd. (“Guotong”), a supplier of power converter products to Sinovel, and Huaneng Hainan Power, Inc. (“Huaneng”), a wind farm operator that has purchased Sinovel wind turbines containing Guotong power converter products. The case is captioned (2011) Hainan Yi Zhong Min Chu Zi No. 62. The application alleges that the Company’s PM1000 converters in certain Sinovel wind turbines have been replaced by converters produced by Guotong. Because the Guotong converters are being used in wind turbines containing the Company’s wind turbine control software, the Company believes that its copyrighted software is being infringed. The Company is seeking a cease and desist order with respect to the unauthorized use of its software, monetary damages of RMB 1.2 million ($0.2 million) for its economic losses (with respect to Guotong only) and reimbursement of all costs and reasonable expenses. The court has accepted the case, which was necessary in order for the case to proceed. In addition, upon the request of the defendant Huaneng, Sinovel has been added by the court to this case as a defendant and Huaneng has been released from this case. In December 2011, Sinovel filed a jurisdiction opposition motion requesting dismissal by the Hainan Province No. 1 Intermediate People’s Court, saying the case should be governed by the Beijing Arbitration Commission. On February 3, 2012, the Company received the Civil Ruling from the court, which granted Sinovel’s motion, and dismissed the entire case. The Company appealed the court’s ruling to the Hainan Higher Court, which on April 5, 2012 upheld the decision of the Hainan Province No. 1 Intermediate People’s Court. On April 9, 2012, the Company filed an appeal of the Hainan Higher Court’s decision with China’s Supreme People’s Court. China’s Supreme People’s Court accepted the appeal on May 23, 2012. The case is captioned, (2012) Min Shen Zi No. 630. On December 20, 2012, China’s Supreme People’s Court issued a Civil ruling, holding that (1) it will conduct a re-trial of the Company’s appeal and (2) the lower court’s decision will be stayed pending the re-trial. China’s Supreme People’s Court conducted a re-trial of Sinovel’s appeal on May 29, 2013.  On January 26, 2014, the Supreme People’s Court revoked Hainan No. 1 Intermediate People’s Court and Hainan Higher People’s Court rulings and ruled that the case shall be heard by the Hainan No. 1 Intermediate People’s Court.  The Hainan No. 1 Intermediate People’s Court accepted the case under the caption (2014) Hainan Yi Zhong Min San Chu Zi No. 1. On October 21, 2014, the Hainan No. 1 Intermediate People’s Court changed the caption of this case to (2014) Hainan Yi Zhong Zhi Min Chu Zi No. 2, and scheduled the first hearing date to be held on November 18, 2014.

[0001564590-14-005096:notes:122]
Other

[0001564590-14-005096:notes:123]
The Company enters into long-term construction contracts with customers that require the Company to obtain performance bonds. The Company is required to deposit an amount equivalent to some or all the face amount of the performance bonds into an escrow account until the termination of the bond. When the performance conditions are met, amounts deposited as collateral for the performance bonds are returned to the Company. In addition, the Company has various contractual arrangements in which minimum quantities of goods or services have been committed to be purchased on an annual basis.

[0001564590-14-005096:notes:124]
As of September 30, 2014 the Company had $3.4 million of restricted cash included in current assets, and $0.1 million of restricted cash included in long-term assets. These amounts included in restricted cash represent deposits to secure letters of credit for various supply contracts. These deposits are held in interest bearing accounts.

[0001564590-14-005096:notes:125]
The Company had an unused, unsecured line of credit consisting of €2.7 million (approximately $3.4 million) in Austria as of September 30, 2014.


## us-gaap:EquityMethodInvestmentsDisclosureTextBlock

[0001564590-14-005096:notes:126]
[same as prior period, unchanged from 0001564590-14-003115:notes:125]

[0001564590-14-005096:notes:127]
[same as prior period, unchanged from 0001564590-14-003115:notes:126]

[0001564590-14-005096:notes:128]
The Company made an investment in Tres Amigas, focused on providing the first common interconnection of America’s three power grids to help the country achieve its renewable energy goals and facilitate the smooth, reliable and efficient transfer of green power from region to region.  The Company’s original investment in Tres Amigas was $5.4 million.  As of September 30, 2014, the Company holds a 26% ownership interest in Tres Amigas.

[0001564590-14-005096:notes:129]
The Company has determined that Tres Amigas is a variable interest entity (“VIE”) and that the Company is not the primary beneficiary of the VIE.  Therefore, the Company has not consolidated Tres Amigas as of September 30, 2014.  The investment is carried at acquisition cost, plus the Company’s equity in undistributed earnings or losses.  The Company’s maximum exposure to loss is limited to the Company’s recorded investment in this VIE.  The Company’s investment in Tres Amigas is included in other assets on the consolidated balance sheet and the equity in undistributed losses of Tres Amigas is included in other expense, net, on the unaudited condensed consolidated statements of operations.

[0001564590-14-005096:notes:130]
The net investment activity for the six months ended September 30, 2014 is as follows (in thousands):

[0001564590-14-005096:notes:131]
| Balance at April 1, 2014 | $ | 1,845 |  |
| Minority interest in net losses |  | (410 | ) |
| Balance at September 30, 2014 | $ | 1,435 |  |

[0001564590-14-005096:notes:132]
[same as prior period, unchanged from 0001564590-14-003115:notes:131]

[0001564590-14-005096:notes:133]
The Company has acquired (through its Austrian subsidiary), a minority ownership position in Blade Dynamics, a designer and manufacturer of advanced wind turbine blades based on proprietary materials and structural technologies.  The Company’s original investment was for $8.0 million in cash. As of September 30, 2014, the Company holds a 19% ownership interest in Blade Dynamics.

[0001564590-14-005096:notes:134]
[same as prior period, unchanged from 0001564590-14-003115:notes:133]

[0001564590-14-005096:notes:135]
[same as prior period, unchanged from 0001564590-14-003115:notes:134]

[0001564590-14-005096:notes:136]
During the three months ended September 30, 2014, the Company determined that as a result of dilutive financing which resulted in the Company losing certain of its shareholder rights, as well as certain operational issues and adverse changes to the potential sale scenarios previously considered, its investment in Blade Dynamics was no longer recoverable and therefore recorded an impairment charge of $3.5 million.

[0001564590-14-005096:notes:137]
| Balance at April 1, 2014 | $ | 3,690 |  |
| Net foreign exchange rate impact |  | (226 | ) |
| Impairment |  | (3,464 | ) |
| Balance at September 30, 2014 | $ | - |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001564590-14-005096:notes:138]
[same as prior period, unchanged from 0001564590-14-003115:notes:136]

[0001564590-14-005096:notes:139]
[same as prior period, unchanged from 0001564590-14-003115:notes:137]

[0001564590-14-005096:notes:140]
[same as prior period, unchanged from 0001564590-14-003115:notes:138]

[0001564590-14-005096:notes:141]
[same as prior period, unchanged from 0001564590-14-003115:notes:139]

[0001564590-14-005096:notes:142]
[same as prior period, unchanged from 0001564590-14-003115:notes:140]

[0001564590-14-005096:notes:143]
|  | Three months ended September 30, |  |  | Six months ended September 30, |  |
|  | 2014 |  |  | 2013 |  |  | 2014 |  |  | 2013 |  |
| Revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Wind | $ | 7,462 |  |  | $ | 14,691 |  |  | $ | 15,113 |  |  | $ | 29,392 |  |
| Grid |  | 4,993 |  |  |  | 9,490 |  |  |  | 9,038 |  |  |  | 17,875 |  |
| Total | $ | 12,455 |  |  | $ | 24,181 |  |  | $ | 24,151 |  |  | $ | 47,267 |  |

[0001564590-14-005096:notes:144]
|  | Three months ended September 30, |  |  | Six months ended September 30, |  |
|  | 2014 |  |  | 2013 |  |  | 2014 |  |  | 2013 |  |
| Operating loss: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Wind | $ | (14,611 | ) |  | $ | (2,449 | ) |  | $ | (18,091 | ) |  | $ | (4,274 | ) |
| Grid |  | (6,559 | ) |  |  | (5,750 | ) |  |  | (12,966 | ) |  |  | (10,618 | ) |
| Unallocated corporate expenses |  | (5,230 | ) |  |  | (2,829 | ) |  |  | (8,010 | ) |  |  | (4,985 | ) |
| Total | $ | (26,400 | ) |  | $ | (11,028 | ) |  | $ | (39,067 | ) |  | $ | (19,877 | ) |

[0001564590-14-005096:notes:145]
[same as prior period, unchanged from 0001564590-14-003115:notes:143]

[0001564590-14-005096:notes:146]
Unallocated corporate expenses primarily consist of stock-based compensation expense of $1.5 million and $3.1 million, and restructuring and impairment charges of $3.7 million and $4.9 million, for the three and six months ended September 30, 2014, respectively. Unallocated corporate expenses primarily consist of stock-based compensation expense of $2.2 million and $4.3 million, respectively, for the three and six months ended September 30, 2013, as well as restructuring and impairment charges of $0.8 million for each of the three and six months ended September 30, 2013, respectively.

[0001564590-14-005096:notes:147]
[same as prior period, unchanged from 0001564590-14-003115:notes:145]

[0001564590-14-005096:notes:148]
|  | September 30, |  |  | March 31, |  |
|  | 2014 |  |  | 2014 |  |
| Wind | $ | 47,569 |  |  | $ | 36,701 |  |
| Grid |  | 44,779 |  |  |  | 54,342 |  |
| Corporate assets |  | 63,499 |  |  |  | 77,466 |  |
| Total | $ | 155,847 |  |  | $ | 168,509 |  |

[0001564590-14-005096:notes:149]
The following table sets forth customers who represented 10% or more of the Company’s total revenues for the three and six months ended September 30, 2014 and 2013:

[0001564590-14-005096:notes:150]
|  | Three months ended September 30, |  |  | Six months ended September 30, |  |
|  | 2014 |  |  | 2013 |  |  | 2014 |  |  | 2013 |  |
| INOX Wind Limited |  | 48 | % |  |  | 27 | % |  |  | 48 | % |  |  | 21 | % |
| RES American Construction, Inc |  | 16 | % |  |  | — | % |  | <10 | % |  |  | — | % |
| Beijing JINGCHENG New Energy Co., Ltd |  | — | % |  |  | 28 | % |  | <10 | % |  |  | 31 | % |


## us-gaap:NewAccountingPronouncementsAndChangesInAccountingPrinciplesTextBlock

[0001564590-14-005096:notes:151]
16. Recent Accounting Pronouncements

[0001564590-14-005096:notes:152]
In May 2014, the FASB and the International Accounting Standards Board (IASB) issued ASU 2014-09, ASU Revenue from Contracts with Customers (Topic 606), The guidance substantially converges final standards on revenue recognition between the FASB and IASB providing a framework on addressing revenue recognition issues and, upon its effective date, replaces almost all exiting revenue recognition guidance, including industry-specific guidance, in current U.S. generally accepted accounting principles.  The ASU is effective for annual reporting periods beginning after December 15, 2016.  The Company is currently evaluating the impact of adopting ASU 2014-09 to determine the impact, if any, it may have on its current practices.

[0001564590-14-005096:notes:153]
In July 2014, the FASB issued ASU 2014-12, Compensation – Stock Compensation (Topic 718): Accounting for Share Based Payments When the Terms of an Award Provide that a Performance Target could be Achieved after the Requisite Service Period.    To account for such awards, a reporting entity should apply existing guidance in FASB Accounting Standards Codification Topic 718, Compensation – Stock Compensation, as it relates to awards with performance conditions that affect vesting.  As such, the performance target should not be reflected in estimating the grant-date fair value of the award. This ASU is effective for annual reporting periods and interim periods, within those annual periods beginning after December 15, 2015.  The Company is currently evaluating the impact of adopting ASU 2014-12 to determine the impact, if any, it may have on its current practices.

[0001564590-14-005096:notes:154]
In August 2014, the FASB issued ASU 2014-13, Consolidation (Topic 810): Measuring the Financial Assets and Financial Liabilities of a Consolidated Collateralized Financing Entity.  The new standard applies to reporting entities that are required to consolidate a collaterized financing entity under the variable interest entities subtopic 810-10. This ASU is effective for annual reporting periods ending after December 15, 2016, and interim periods within annual periods beginning after December 15, 2016.  The Company is currently evaluating the impact of adopting ASU 2014-13 to determine the impact, but currently does not believe there will be an impact on its consolidated results of operations, financial condition, or cash flow.

[0001564590-14-005096:notes:155]
In August 2014, the FASB issued ASU 2014-15, Presentation of Financial Statements – Going Concern (Subtopic 205-40): Disclosure of Uncertainties About an Entity’s Ability to Continue as a Going Concern.  The new standard explicitly requires the assessment at interim and annual periods, and provides management with its own disclosure guidance.  This ASU is effective for annual reporting periods and interim periods, within those annual periods ending after December 15, 2016.  The Company is currently evaluating the impact of adopting ASU 2014-15 to determine the impact, if any; it may have on its current practices.


## us-gaap:SubsequentEventsTextBlock

[0001564590-14-005096:notes:156]
17. Subsequent Events

[0001564590-14-005096:notes:157]
The Company has performed an evaluation of subsequent events through the time of filing this Quarterly Report on Form 10-Q with the SEC, and has determined that there are no such events that are required to be disclosed.
