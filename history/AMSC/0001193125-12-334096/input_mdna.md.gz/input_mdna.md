# AMSC MD&A — 0001193125-12-334096


## mdna

[0001193125-12-334096:mdna:1]
[same as prior period, unchanged from 0001193125-12-048929:mdna:1]

[0001193125-12-334096:mdna:2]
acceptable cost and quality levels would substantially limit our future revenue and profit potential; third parties have or may acquire patents that cover the materials, processes and
technologies we use or may use in the future to manufacture our Amperium products, and our success depends on our ability to license such patents or other proprietary rights; our technology and products could infringe intellectual property rights of
others, which may require costly litigation and, if we are not successful, could cause us to pay substantial damages and disrupt our business; we have filed a demand for arbitration and other lawsuits against our former largest customer, Sinovel,
regarding amounts we contend are overdue. We cannot be certain as to the outcome of these proceedings; we have been named as a party to purported stockholder class actions and stockholder derivative complaints, and we may be named in additional
litigation, all of which will require significant management time and attention, result in significant legal expenses and may result in an unfavorable outcome, which could have a material adverse effect on our business, operating results and
financial condition; our 7% convertible note contains warrants and provisions that could limit our ability to repay the note in shares of common stock and should the note be repaid in stock, shareholders could experience significant dilution; our
common stock has experienced, and may continue to experience, significant market price and volume fluctuations, which may prevent our stockholders from selling our common stock at a profit and could lead to costly litigation against us that could
divert our management’s attention. These and the important factors discussed under the caption “Risk Factors” in Part II. Item 1A and Part 1. Item 1A of our Form 10-K for the fiscal year ended March 31, 2012,
among others, could cause actual results to differ materially from those indicated by forward-looking statements made herein and presented elsewhere by management from time to time. Any such forward-looking statements represent management’s
estimates as of the date of this Quarterly Report on Form 10-Q. While we may elect to update such forward-looking statements at some point in the future, we disclaim any obligation to do so, even if subsequent events cause our views to change. These
forward-looking statements should not be relied upon as representing our views as of any date subsequent to the date of this Quarterly Report on Form 10-Q.

[0001193125-12-334096:mdna:3]
American Superconductor®, Amperium®, AMSC®, D-VAR®, PowerModuleTM, PQ-IVR®, SeaTitanTM, Gridtec SolutionsTM, Windtec SolutionsTM and Smarter, Cleaner Better EnergyTM are trademarks or registered trademarks of American Superconductor
Corporation or its subsidiaries. We reserve all of our rights with respect to our trademarks or registered trademarks regardless of whether they are so designated in this Quarterly Report on Form 10-Q by an ® or TM symbol. All other brand names, product names, trademarks or service marks appearing in this Quarterly Report on
Form 10-Q are the property of their respective holders.

[0001193125-12-334096:mdna:4]
[same as prior period, unchanged from 0001193125-12-048929:mdna:5]

[0001193125-12-334096:mdna:5]
American Superconductor Corporation was founded in 1987. We are a leading provider of megawatt-scale solutions that lower the cost of wind
power and enhance the performance of the power grid. In the wind power market, we enable manufacturers to field wind turbines through our advanced engineering, support services and power electronics products. In the power grid market, we enable
electric utilities and renewable energy project developers to connect, transmit and distribute power through our transmission planning services and power electronics and superconductor-based products. Our wind and power grid products and services
provide exceptional reliability, security, efficiency and affordability to our customers.

[0001193125-12-334096:mdna:6]
Our wind and power grid solutions
help to improve energy efficiency, alleviate power grid capacity constraints and increase the adoption of renewable energy generation. Demand for our solutions is driven by the growing needs for renewable sources of electricity, such as wind and
solar energy, and for modernized smart grids that improve power reliability and quality. Concerns about these factors have led to increased spending by corporations as well as supportive government regulations and initiatives on local, state,
national and global levels, including renewable portfolio standards, tax incentives and international treaties.

[0001193125-12-334096:mdna:7]
We
manufacture products using two proprietary core technologies: PowerModule™ programmable power electronic converters and our Amperium™ HTS wires. These technologies and our system-level solutions are protected by a broad and deep
intellectual property portfolio consisting of hundreds of patents and licenses worldwide.

[0001193125-12-334096:mdna:8]
We operate our business under two
market-facing business units: Wind and Grid. We believe this market-centric structure enables us to more effectively anticipate and meet the needs of wind turbine manufacturers, power generation project developers and electric utilities.

[0001193125-12-334096:mdna:9]
[same as prior period, unchanged from 0001193125-12-048929:mdna:10]

[0001193125-12-334096:mdna:10]
[same as prior period, unchanged from 0001193125-12-048929:mdna:11]

[0001193125-12-334096:mdna:11]
Our fiscal year begins on April 1 and ends on March 31. This document refers to fiscal 2012,
which is defined as the period beginning on April 1, 2012 and concluding on March 31, 2013. The first quarter of fiscal 2012 began on April 1, 2012 and concluded on June 30, 2012.

[0001193125-12-334096:mdna:12]
On April 4, 2012 we completed a private placement of $25.0 million of senior convertible notes (the “Convertible Notes”)
with an affiliate of Heights Capital Management. On June 5, 2012, we entered into a $10.0 million Loan and Security Agreement (“Term Loan”) with Hercules Technology Growth Capital. See Liquidity and Capital Resources for further
discussion of these debt arrangements.

[0001193125-12-334096:mdna:13]
Our cash requirements depend on numerous factors, including managing our adverse
purchase commitments, maintaining compliance with the covenants and restrictions in our debt agreements, successful completion of our product development activities, ability to commercialize our product prototypes, rate of customer and market
adoption of our products, collecting receivables according to established terms, and the continued availability of United States government funding during the product development phase. Significant deviations to our business plan with regard to
these factors, which are important drivers to our business, could have a material adverse effect on our operating performance, financial condition, and future business prospects. We expect to pursue the expansion of our operations through internal
growth, diversification of our customer base, and potential strategic alliances. See below for a discussion of liquidity and capital resources.

[0001193125-12-334096:mdna:14]
During March 2011, we engaged in discussions with Sinovel, formerly our largest customer, regarding the acceptance of its scheduled shipments, outstanding receivables, and the delivery of a custom
solution desired by Sinovel for low voltage ride through (“LVRT”) that required a modification to our existing LVRT design. The custom design required modified software and additional hardware. Toward the end of March, Sinovel
requested that we provide them with the additional hardware without additional cost. On March 31, 2011, we proposed to Sinovel that we would provide the additional hardware without additional cost if Sinovel would accept the scheduled
shipments. Sinovel rejected this proposal due to what we were told was excess inventory of our components. Since Sinovel did not give us the requisite notice under our contracts that they intended to delay deliveries, we believe that these
actions constitute material breaches of our contracts.

[0001193125-12-334096:mdna:15]
As of the date of this filing, we have not received payment from
Sinovel for any outstanding receivables nor have we been notified as to when, if ever, Sinovel will accept contracted shipments that were scheduled for delivery after March 31, 2011. Additionally, based in part upon evidence obtained through an
internal investigation and a criminal investigation conducted by Austrian authorities regarding the actions of a former employee of our Austrian subsidiary, we believe that Sinovel illegally obtained and used our intellectual property in violation
of civil and criminal intellectual property laws. In July 2011, a former employee of our Austrian subsidiary was arrested in Austria on charges of economic espionage and fraudulent manipulation of data. In September 2011, the former employee pled
guilty to the charges, and was imprisoned. The evidence presented during the court hearing showed that this former employee was contracted by Sinovel through an intermediary while employed by us and improperly obtained and transferred to Sinovel
portions of our wind turbine control software source code developed for Sinovel’s 1.5MW wind turbines. Except for portions of this 1.5MW wind turbine software, we do not believe that the source code for any other turbines, such as the 3MW, 5MW
and 6MW wind turbines that were designed by and co-developed with us have been transferred to Sinovel. Moreover, we believe the evidence shows this former employee illegally used source code to develop for Sinovel a software modification to
circumvent the encryption and remove technical protection measures on the PM3000 power converters in 1.5MW wind turbines in the field. We believe that only the binary code, or upper layer, of the PM3000 software developed to circumvent the
encryption and remove technical protection measures was transferred to Sinovel. We do not believe that any PM3000 source code was transferred to Sinovel. These actions potentially enable Sinovel to deploy, independent of us, wind turbine control
software, including a low voltage ride through solution, on all of its 1.5MW wind turbines in the field. In addition, by having the wind turbine control source code, Sinovel could potentially modify the source code to allow the use of core
electrical components, including power converters, from other manufacturers.

[0001193125-12-334096:mdna:16]
On September 13, 2011, we commenced a
series of legal actions in China against Sinovel. We filed a claim for arbitration in Beijing, China to compel Sinovel to pay us for past product shipments and to accept all contracted but not yet delivered core electrical components and spare parts
under all existing contracts with us. The arbitration claim was filed with the Beijing Arbitration Commission in accordance with the terms of our supply contracts with Sinovel. We also filed civil and criminal complaints against Sinovel.

[0001193125-12-334096:mdna:17]
We cannot provide any assurance as to the outcome of these legal actions. See Part II,
Item 1. Legal Proceedings below for additional information regarding these legal proceedings.

[0001193125-12-334096:mdna:18]
Critical Accounting Policies and
Estimates

[0001193125-12-334096:mdna:19]
The preparation of the unaudited condensed consolidated financial statements requires that we make estimates
and judgments that affect the reported amounts of assets, liabilities, revenues and expenses, and related disclosure of contingent assets and liabilities. We base our estimates on historical experience and various other assumptions that are believed
to be reasonable under the circumstances, the results of which form the basis for making judgments about the carrying values of assets and liabilities that are not readily apparent from other sources. Actual results may differ under different
assumptions or conditions. Except as stated below, there were no significant changes in the critical accounting policies during the three months ended June 30, 2012 that were disclosed in our Form 10-K for fiscal 2011, which ended on
March 31, 2012.

[0001193125-12-334096:mdna:20]
Fair Value of Financial Instruments

[0001193125-12-334096:mdna:21]
Our financial instruments consist principally of cash and cash equivalents, marketable securities, accounts receivable, accounts payable,
accrued expenses, derivatives, warrants, convertible notes and a term loan. The estimated fair values have been determined through information obtained from market sources and management estimates. The carrying amounts of these instruments
approximate fair value. We have identified all of the derivatives associated with the Convertible Notes which include put rights to require the investor to acquire an additional $15.0 million convertible note and additional warrant, holder change of
control redemption rights, issuer optional redemption rights, sale redemption rights and a right to make payment in the form of stock rather than cash if certain equity conditions are met. The derivative liability is subject to revaluation at each
balance sheet date, and any change in fair value will be recorded as a change in fair value in other income (expense) until the earlier of their exercise or expiration of the derivatives associated with the Convertible Notes. We rely on assumptions
in a lattice model to determine the fair value of the derivative liability. We have appropriately valued the derivative liability within Level 3 of the valuation hierarchy. Warrants were issued in conjunction with the Convertible Notes and Term
Loan. These warrants are subject to revaluation at each balance sheet date, and any change in fair value will be recorded as a change in fair value in other income (expense) until the earlier of the warrants’ exercise or expiration. We rely on
assumptions used in a Black-Scholes model to determine the fair value of the warrants. We have appropriately valued the warrants within Level 3 of the valuation hierarchy.

[0001193125-12-334096:mdna:22]
[same as prior period, unchanged from 0001193125-12-048929:mdna:23]

[0001193125-12-334096:mdna:23]
Three months ended June 30, 2012 compared to the
three ended June 30, 2011

[0001193125-12-334096:mdna:24]
[same as prior period, unchanged from 0001193125-12-048929:mdna:27]

[0001193125-12-334096:mdna:25]
Total revenues increased by 217% to $28.7 million for the three months ended June 30, 2012, compared to $9.1 million for the three months ended June 30, 2011. Our revenues are summarized as
follows (in thousands):

[0001193125-12-334096:mdna:26]
|  |  | Three months endedJune 30, |  |
|  |  | 2012 |  |  | 2011 |  |
| Revenues: |  |  |  |  |  |  |  |  |
| Wind |  | $ | 16,511 |  |  | $ | 4,262 |  |
| Grid |  |  | 12,205 |  |  |  | 4,796 |  |
| Total |  | $ | 28,716 |  |  | $ | 9,058 |  |

[0001193125-12-334096:mdna:27]
Our Wind business unit accounted for 57% of total revenues for the three months ended June 30, 2012,
compared to 47% for the three months ended June 30, 2011. Revenues in the Wind business unit increased 287% to $16.5 million in the three months ended June 30, 2012 from $4.3 million in the three months ended June 30, 2011. Wind
business unit revenues increased primarily due to increased shipments of electrical control systems to customers in China and India.

[0001193125-12-334096:mdna:28]
Our Grid business unit accounted for 43% of total revenues for the three months ended June 30, 2012, compared to 53% for the three months ended June 30, 2011. Our Grid business unit revenues
increased 155% to $12.2 million in the three months ended June 30, 2012 from $4.8 million for the three months ended June 30, 2011. Grid business unit revenues increased primarily due to increased D-VAR revenues.

[0001193125-12-334096:mdna:29]
Revenues from significant government-funded contracts are summarized as follows (in
thousands):

[0001193125-12-334096:mdna:30]
|  |  |  |  |  |  |  |  | Revenue Earned for the ThreeMonths Ended June 30, |  |
|  |  |  |  |  | Revenue earned |  |  |
| Project name |  | Expected totalcontract value |  |  | throughJune 30, 2012 |  |  | 2012 |  |  | 2011 |  |
| HYDRA 1 & 2 |  | $ | 29,043 |  |  | $ | 12,480 |  |  | $ | 322 |  |  | $ | 411 |  |
| LIPA I and II |  |  | 40,141 |  |  |  | 40,007 |  |  |  | 29 |  |  |  | 1,309 |  |
| DOE-FCL |  |  | 7,898 |  |  |  | 7,384 |  |  |  | 135 |  |  |  | 232 |  |
| Total |  | $ | 77,082 |  |  | $ | 59,871 |  |  | $ | 486 |  |  | $ | 1,952 |  |

[0001193125-12-334096:mdna:31]
These significant projects represented 4% and 41% of the Grid business unit revenues for the three months
ended June 30, 2012 and 2011, respectively.

[0001193125-12-334096:mdna:32]
Project HYDRA is a project with Consolidated Edison,
Inc. which is being partially funded by the Department of Homeland Security (“DHS”). DHS is expected to invest up to a total of $29.0 million in the development of a new HTS power grid technology called FaultBlocker™ cable systems.
FaultBlockerTM cable systems are designed to utilize
customized Amperium™ HTS wires, and ancillary controls to deliver more power through the grid while also being able to suppress power surges that can disrupt service. On June 29, 2012, DHS committed an additional $3.3 million in funding on
Project HYDRA. Of the total $29.0 million in funding expected from DHS, it has committed funding of $18.9 million to us as of June 30, 2012. Consolidated Edison and Southwire Company are our subcontractors on this project.

[0001193125-12-334096:mdna:33]
LIPA II is a project to install an HTS power cable using our Amperium™ wire for the Long Island Power Authority. DOE-FCL is a
project to develop and demonstrate a transmission voltage SuperLimiter fault current limiter (“FCL”).

[0001193125-12-334096:mdna:34]
The following
table sets forth customers who represented 10% or more of our total revenues for the three months ended June 30, 2012 and 2011:

[0001193125-12-334096:mdna:35]
|  |  | Three months endedJune 30, |  |
|  |  | 2012 |  |  | 2011 |  |
| Beijing JINGCHENG New Energy Co., Ltd. |  |  | 19 | % |  |  | — |  |
| Karara Mining Ltd. |  |  | 15 | % |  |  | — |  |
| INOX Wind Limited. |  |  | 15 | % |  |  | — |  |
| Department of Energy |  |  | — |  |  |  | 17 | % |
| Doosan Heavy Industries & Construction Co Ltd. |  |  | — |  |  |  | 15 | % |
| Shenyang Blower Works Group Wind Power Co., Ltd. |  |  | — |  |  |  | 13 | % |

[0001193125-12-334096:mdna:36]
[same as prior period, unchanged from 0001193125-12-048929:mdna:40]

[0001193125-12-334096:mdna:37]
Cost of revenues was $17.0 million for each of the three months ended June 30, 2012 and 2011. Gross margin was 41.1% and (87.2%) for the three months ended June 30, 2012 and 2011,
respectively. The increase in gross margin for the three months ended June 30, 2012 as compared to the same period in fiscal 2011 was primarily due to settlements of certain adverse purchase order liabilities resulting in a benefit to cost of
revenues of $7.3 million in the three months ended June 30, 2012 as well as higher revenues, which included approximately $3 million of revenue from Chinese customers representing payment for past shipments for which revenue is being recognized
upon cash collection. Costs associated with this revenue were recorded in prior periods.

[0001193125-12-334096:mdna:38]
Operating Expenses

[0001193125-12-334096:mdna:39]
[same as prior period, unchanged from 0001193125-12-048929:mdna:43]

[0001193125-12-334096:mdna:40]
A portion of our R&D expenditures related to
externally funded development contracts has been classified as cost of revenues (rather than as R&D expenses). Additionally, a portion of R&D expenses was offset by cost-sharing funding. Our R&D expenditures are summarized as follows (in
thousands):

[0001193125-12-334096:mdna:41]
|  |  | Three months endedJune 30, |  |
|  |  | 2012 |  |  | 2011 |  |
| R&D expenses per unaudited condensed consolidated statements of operations |  | $ | 3,910 |  |  | $ | 8,136 |  |
| R&D expenditures reclassified as cost of revenues |  |  | 2,860 |  |  |  | 4,040 |  |
| R&D expenditures offset by cost-sharing funding |  |  | 94 |  |  |  | 34 |  |
| Aggregated R&D expenses |  | $ | 6,864 |  |  | $ | 12,210 |  |

[0001193125-12-334096:mdna:42]
R&D expenses (exclusive of amounts classified as cost of revenues and amounts offset by cost-sharing
funding) decreased by 52% to $3.9 million for the three months ended June 30, 2012 from $8.1 million for the three months ended June 30, 2011. The decrease in R&D expenses was driven primarily by the realization of cost reduction
actions that were implemented in fiscal 2011. The decrease in R&D expenditures reclassified to costs of revenue was a result of decreased activity under license and development contracts for wind turbine designs compared to the prior year.
Aggregated R&D expenses, which include amounts classified as cost of revenues and amounts offset by cost-sharing funding, decreased 44% to $6.9 million for the three months ended June 30, 2012 compared to $12.2 million for the three
months ended June 30, 2011.

[0001193125-12-334096:mdna:43]
We present aggregated R&D, which is a non-GAAP measure, because we believe this
presentation provides useful information on our aggregate R&D spending and because R&D expenses as reported on the unaudited condensed consolidated statements of income have been, and may in the future be, subject to significant fluctuations
solely as a result of changes in the level of externally funded contract development work, resulting in significant changes in the amount of the costs recorded as costs of revenues rather than as R&D expenses, as discussed above.

[0001193125-12-334096:mdna:44]
[same as prior period, unchanged from 0001193125-12-048929:mdna:48]

[0001193125-12-334096:mdna:45]
SG&A expenses decreased by 37% to $13.8 million in the three months ended June 30, 2012, from $22.0 million in the three months ended June 30, 2011. The decrease in SG&A expenses was due
primarily to the realization of cost reductions actions that were implemented in fiscal 2011 and costs associated with the severance of our former chief executive officer during the three months ended June 30, 2011, which did not recur.

[0001193125-12-334096:mdna:46]
[same as prior period, unchanged from 0001193125-12-048929:mdna:53]

[0001193125-12-334096:mdna:47]
We recorded amortization expense related to our core technology and know-how, trade names and trademark intangible assets of $0.1 million and $0.3 million in the three months ended June 30, 2012 and
2011, respectively. These intangible assets are primarily as a result of our Windtec acquisition.

[0001193125-12-334096:mdna:48]
Restructuring

[0001193125-12-334096:mdna:49]
We recorded restructuring and impairment charges of $0.1 million in the three months ended June 30, 2012. These amounts consist
primarily of employee severance and benefit costs related to our restructuring plan.

[0001193125-12-334096:mdna:50]
[same as prior period, unchanged from 0001193125-12-048929:mdna:57]

[0001193125-12-334096:mdna:51]
Our operating (loss) income is summarized as follows (in thousands):

[0001193125-12-334096:mdna:52]
|  |  | Three months endedJune 30, |  |
|  |  | 2012 |  |  | 2011 |  |
| Wind |  | $ | 1,301 |  |  | $ | (24,370 | ) |
| Grid |  |  | (5,343 | ) |  |  | (10,552 | ) |
| Unallocated corporate expenses |  |  | (2,086 | ) |  |  | (3,405 | ) |
| Total |  | $ | (6,128 | ) |  | $ | (38,327 | ) |

[0001193125-12-334096:mdna:53]
Our Wind segment generated operating income of $1.3 million in the three months ended
June 30, 2012, compared to an operating loss of $24.4 million in the three months ended June 30, 2011. The increase in Wind business unit operating income was primarily due to the settlement of certain adverse purchase order liabilities
and the realization of cost reductions which were implemented in fiscal 2011 as well as the increased revenue for the 2012 quarter.

[0001193125-12-334096:mdna:54]
The operating loss of our Grid segment decreased to $5.3 million in the three months ended June 30, 2012, compared to $10.6 million in the three months ended June 30, 2011. The decrease in Grid
business unit operating loss was primarily due to lower operating expenses as a result of the reductions in force and reduced discretionary spending, partially offset by increased D-VAR revenues.

[0001193125-12-334096:mdna:55]
Unallocated corporate expenses also include stock-based compensation expense of $2.0 million and $3.5 million for the three months ended
June 30, 2012 and 2011, respectively.

[0001193125-12-334096:mdna:56]
Change in fair value of derivatives and warrants

[0001193125-12-334096:mdna:57]
As a result of our completed debt financings during the three months ended June 30, 2012, we recognized a liability for derivative
features embedded within the financing agreements, including the convertible feature of the Convertible Note and warrants issued in conjunction with the Convertible Note and Term Loan. We are required to value the derivative liabilities and warrants
at fair value each quarter and recognize a gain or loss on the change in fair value of these instruments.

[0001193125-12-334096:mdna:58]
The fair value of
the derivative liabilities and warrants increased by $2.4 million and resulted in an expense to our consolidated statement of operations. The primary driver of the expense was the increase in our stock price from the inception of the debt agreements
to June 30, 2012.

[0001193125-12-334096:mdna:59]
[same as prior period, unchanged from 0001193125-12-048929:mdna:64]

[0001193125-12-334096:mdna:60]
Interest expense, net, was $2.7 million in the three months ended June 30, 2012, compared to interest income of $0.2 million for the three months ended June 30, 2011. The increase in interest
expense was due to the debt financings completed during the three months ended June 30, 2012.

[0001193125-12-334096:mdna:61]
[same as prior period, unchanged from 0001193125-12-048929:mdna:66]

[0001193125-12-334096:mdna:62]
Other income, net, was $0.1 million in the three months ended June 30, 2012 compared to $0.6 million for the
three months ended June 30, 2011. The decrease in other income, net primarily relates to an increase in losses on minority interest investments of $0.4 million.

[0001193125-12-334096:mdna:63]
[same as prior period, unchanged from 0001193125-12-048929:mdna:68]

[0001193125-12-334096:mdna:64]
In the three months ended June 30, 2012, we
recorded an income tax benefit of $0.8 million compared to income tax expense of $0.2 million in the three months ended June 30, 2011. The decrease in income tax expense was primarily due to a refund of Chinese income taxes.

[0001193125-12-334096:mdna:65]
[same as prior period, unchanged from 0001193125-12-048929:mdna:70]

[0001193125-12-334096:mdna:66]
Generally, a non-GAAP financial measure is a numerical measure of a company’s performance, financial position or cash flow that
either excludes or includes amounts that are not normally excluded or included in the most directly comparable measure calculated and presented in accordance with GAAP. The non-GAAP measures included in this Form 10-Q, however, should be considered
in addition to, and not as a substitute for or superior to the comparable measure prepared in accordance with GAAP.

[0001193125-12-334096:mdna:67]
29

[0001193125-12-334096:mdna:68]
We define non-GAAP net (loss) income as net (loss) income before amortization of
acquisition-related intangibles, restructuring and impairments, stock-based compensation, change in fair value of derivative liabilities and warrants, non-cash interest expense, other unusual charges and any tax effects related to these items. We
believe non-GAAP net (loss) income assists management and investors in comparing our performance across reporting periods on a consistent basis by excluding these non-cash or non-recurring charges that we do not believe are indicative of our core
operating performance. We also regard non-GAAP net (loss) income as a useful measure of operating performance which more closely aligns net (loss) income with cash used in/provided by continuing operations. In addition, we use non-GAAP net (loss)
income as a factor in evaluating management’s performance when determining incentive compensation and to evaluate the effectiveness of our business strategies. A reconciliation of non-GAAP to GAAP net (loss) income is set forth in the table
below (in thousands, except per share data):

[0001193125-12-334096:mdna:69]
|  |  | Three months ended June 30, |  |
|  |  | 2012 |  |  | 2011 |  |
| Net loss |  | $ | (10,275 | ) |  | $ | (37,679 | ) |
| Adverse purchase commitment (recoveries) losses, net |  |  | (7,301 | ) |  |  | 1,071 |  |
| Stock-based compensation |  |  | 1,994 |  |  |  | 3,466 |  |
| Amortization of acquisition-related intangibles |  |  | 81 |  |  |  | 304 |  |
| Restructuring and impairment charges |  |  | 128 |  |  |  | — |  |
| Executive severance |  |  | — |  |  |  | 2,066 |  |
| Sinovel litigation |  |  | 120 |  |  |  | — |  |
| Consumption of zero cost-basis inventory |  |  | 387 |  |  |  | — |  |
| Change in fair value of derivatives and warrants |  |  | 2,388 |  |  |  |  |  |
| Non-cash interest expense |  |  | 2,282 |  |  |  |  |  |
| Non-GAAP net loss |  | $ | (10,196 | ) |  | $ | (30,772 | ) |
| Non-GAAP loss earnings per share |  | $ | (0.20 | ) |  | $ | (0.61 | ) |
| Weighted average shares outstanding * |  |  | 51,191 |  |  |  | 50,709 |  |

[0001193125-12-334096:mdna:70]
[same as prior period, unchanged from 0001193125-12-048929:mdna:74]

[0001193125-12-334096:mdna:71]
We incurred a non-GAAP net loss of ($10.2) million or ($0.20) per share, for the three months ended June 30, 2012, compared to a non-GAAP net loss of ($30.8) million, or ($0.61) per share, for the
three months ended June 30, 2011. The decrease in the non-GAAP net loss was driven primarily by the factors that resulted in a lower net loss, including higher revenues, improved gross margin and lower operating expenses.

[0001193125-12-334096:mdna:72]
[same as prior period, unchanged from 0001193125-12-048929:mdna:76]

[0001193125-12-334096:mdna:73]
At June 30, 2012, we had cash, cash equivalents, marketable securities and restricted cash of $87.1 million, compared to $66.2 million at March 31, 2012, an increase of $20.9 million. Our cash
and cash equivalents, marketable securities and restricted cash are summarized as follows (in thousands):

[0001193125-12-334096:mdna:74]
|  |  | June 30,2012 |  |  | March 31,2012 |  |
| Cash and cash equivalents |  | $ | 60,487 |  |  | $ | 46,279 |  |
| Marketable securities |  |  | 5,209 |  |  |  | 5,304 |  |
| Restricted cash |  |  | 21,451 |  |  |  | 14,626 |  |
| Total cash, cash equivalents, marketable securities and restricted cash |  | $ | 87,147 |  |  | $ | 66,209 |  |

[0001193125-12-334096:mdna:75]
With respect to the unaudited condensed consolidated statement of cash flows, for the three months ended
June 30, 2012, net cash used in operating activities was $11.6 million compared to $57.8 million for the three months ended June 30, 2011. The decrease in net cash used in operations is due primarily to a decrease in net loss, adjusted for
non-cash items of $22.3 million and a decrease in cash used for working capital of $23.9 million.

[0001193125-12-334096:mdna:76]
For the three months ended
June 30, 2012, net cash used in investing activities was $6.8 million compared to net cash provided by investing activities of $59.8 million for the three months ended June 30, 2011. The decrease in net cash provided by investing
activities for the three months ended June 30, 2012 was driven primarily by a decrease in the proceeds from the maturity of marketable securities of $90.7 million and an increase in restricted cash of $3.1 million, partially offset by a
decrease in capital expenditures of $4.4 million, and the $20.6 million advance payment to The Switch, and the additional minority investment in Tres Amigas of $1.8 million during the three months ended June 30, 2011, which did not recur.

[0001193125-12-334096:mdna:77]
For the three months ended June 30, 2012, net cash provided by financing activities was
$32.9 million compared to $4.4 million in the three months ended June 30, 2011. The increase in net cash provided by financing activities is primarily due to the net proceeds from our financings during the period ended June 30, 2012 of
$32.9 million, partially offset by a payment on borrowings under a line of credit of $4.6 million during the three months ended June 30, 2011.

[0001193125-12-334096:mdna:78]
At June 30, 2012, we had $16.7 million of restricted cash included in current assets, and $4.8 million of restricted cash included in long-term assets. These amounts included in restricted cash
represent deposits to secure letters of credit for various supply contracts and are held in interest bearing accounts. We are working with our inventory suppliers to delay cash settlements and to reduce the gross liability associated with our
adverse purchase commitments, which is approximately $17.5 million as of June 30, 2012. During the quarter ending June 30, 2012, we agreed to settle adverse purchase commitments with certain of our vendors. In conjunction with these
settlements, we agreed to provide letters of credit and bank guarantees in the amount of approximately $9.0 million with expirations through January 31, 2013. The letters of credit and bank guarantees were secured with cash collateral of $8.5
million and resulted in a reduction of our adverse purchase commitments liability of $7.3 million.

[0001193125-12-334096:mdna:79]
As of June 30, 2012,
we had three performance bonds in support of customer contracts. The total value of the outstanding performance bonds is $3.5 million with expiration dates through March 2014. In the event that the payment is made in accordance with the requirements
of any of these performance bonds, we would record the payment as an offset to revenue.

[0001193125-12-334096:mdna:80]
On April 4, 2012, we completed a
private placement of $25.0 million of Convertible Notes. The Convertible Notes bear interest of 7% and have an initial conversion price of $4.85 per share. The Convertible Notes are payable in monthly installments beginning four months from issuance
and ending on October 4, 2014. Monthly payments are payable in cash or common stock at our option, subject to certain trading volume, stock price and other conditions. The Convertible Notes contain certain covenants and restrictions, including,
among others, that for so long as the Convertible Notes are outstanding, we will not incur any indebtedness (other than permitted indebtedness under the Convertible Notes), permit liens on our properties (other than permitted liens under the
Convertible Notes), make payments on junior securities or make dividends. The Convertible Notes also contain limitations on the transfer of certain assets. Events of default under the Convertible Notes include failure to pay principal or interest as
due on the Convertible Notes, failure to deliver registered shares of common stock upon the holders request for conversion of part or all of the Convertible Notes, failure to maintain our common stock eligible for trading on defined markets, cross
defaults to other material indebtedness, receipt of uninsured judgments against us in excess of defined limits and other administrative covenants, as defined in the Convertible Notes and related documentation. Upon an event of default, the holders
may require us to redeem all or any portion of the outstanding principal amount of the Convertible Notes in cash plus a penalty specified in the agreement. In addition, if we fail to maintain an effective registration statement covering common stock
to be used in settling obligations under the Convertible Notes, we will be required to pay a penalty specified in the agreement.

[0001193125-12-334096:mdna:81]
On June 5, 2012, we entered into a Loan and Security Agreement with Hercules Technology Growth Capital, under which we borrowed $10.0 million. The Term Loan bears interest at a floating per annum
rate equal to 11% plus the percentage, if any, by which the prime rate exceeds 3.75%. We will make interest only payments beginning July 1, 2012 and continuing through October 1, 2012, after which we will repay the Term Loan in equal
monthly installments ending on December 1, 2014. The Term Loan contains certain covenants that restrict our ability to, among other things, incur or assume certain debt, merge or consolidate, materially change the nature of our business, make
certain investments, acquire or dispose of certain assets, make guaranties or grant liens on its assets, make certain loans, advances or investments, declare dividends or make distributions or enter into transactions with affiliates. In addition,
the Term Loan contains a covenant which requirements us to maintain a minimum unrestricted cash balance in the United States of at least $10.0 million at the inception of the Term Loan, which will decrease starting November 1, 2012 and monthly
thereafter by the amount of principal paid. The events of default under the Term Loan include, but are not limited to, failure to pay amounts due, breaches of covenants, bankruptcy events, cross defaults under other material indebtedness and the
occurrence of a material adverse effect and/or change in control. In the case of a continuing event of default, the Lender may, among other remedies, declare due all unpaid principal amounts outstanding and any accrued but unpaid interest and
foreclose on all collateral granted to the Lender as security under the Term Loan.

[0001193125-12-334096:mdna:82]
Although we are in and expect to remain in
compliance with covenants and restrictions on the Convertible Notes and Term Loan as of the date of this Quarterly Report on Form 10-Q, there can no assurance that we will continue to be in compliance. If we fail to stay in compliance with our
covenants or suffer some other event of default, we may be forced to repay the outstanding principle of one or both of our debt obligations. In the case of the Convertible Note, such an event of default would also include the requirement to pay a
penalty as defined in the agreement. Should this occur, our liquidity would be adversely affected.

[0001193125-12-334096:mdna:83]
At June 30, 2012, we had cash, cash equivalents, and marketable securities of $65.7
million. We experienced a substantial decline in revenues, incurred a net loss of $136.8 million and used $141.0 million of cash for operations during the fiscal year ended March 31, 2012. As a result, we reduced our global workforce by
approximately 50% and consolidated certain business operations in three locations to reduce facility costs. As of June 30, 2012, we had a global workforce of approximately 430 persons.

[0001193125-12-334096:mdna:84]
We expect that our cost reduction efforts and anticipated revenue growth will result in a substantial reduction in cash used for
operations during the fiscal year ended March 31, 2013. We plan to closely monitor our expenses and if required, expect to further reduce operating costs and capital spending to enhance liquidity.

[0001193125-12-334096:mdna:85]
We believe that our available cash, together with additional reductions in operating costs and capital expenditures that we expect to
make if necessary, will be sufficient to fund our operations, capital expenditures and any scheduled cash payments under our debt obligations through June 30, 2013. Our liquidity is highly dependent on our ability to profitably grow revenues,
successfully manage adverse purchase commitments, fund and maintain compliance with the covenants and restrictions on our debt obligations, and raise additional capital, as required. We may seek additional financing however; there can be no
assurance that financing will be available on commercially acceptable terms or at all.

[0001193125-12-334096:mdna:86]
Legal Proceedings

[0001193125-12-334096:mdna:87]
We are involved in legal and administrative proceedings and claims of various types. See Part II, Item 1, “Legal
Proceedings,” for additional information. We record a liability in our consolidated financial statements for these matters when a loss is known or considered probable and the amount can be reasonably estimated. We review these estimates each
accounting period as additional information is known and adjust the loss provision when appropriate. If a matter is both probable to result in liability and the amounts of loss can be reasonably estimated, we estimate and disclose the possible loss
or range of loss. If the loss is not probable or cannot be reasonably estimated, a liability is not recorded in its consolidated financial statements.

[0001193125-12-334096:mdna:88]
[same as prior period, unchanged from 0001193125-12-048929:mdna:97]

[0001193125-12-334096:mdna:89]
[same as prior period, unchanged from 0001193125-12-048929:mdna:98]

[0001193125-12-334096:mdna:90]
[same as prior period, unchanged from 0001193125-12-048929:mdna:99]

[0001193125-12-334096:mdna:91]
In addition, we have various contractual arrangements in which minimum quantities of goods or services have been committed to
be purchased on an annual basis.

[0001193125-12-334096:mdna:92]
[same as prior period, unchanged from 0001193125-12-048929:mdna:101]

[0001193125-12-334096:mdna:93]
In June 2011, the FASB issued Accounting Standards Update (ASU) No. 2011-05, Comprehensive Income (Topic 220): Presentation of
Comprehensive Income. ASU 2011-05 requires entities to present net income and other comprehensive income in either a single continuous statement or in two separate, but consecutive, statements of net income and other comprehensive income. ASU
2011-05 is effective for fiscal years and interim periods beginning after December 15, 2011. We early adopted ASU 2011-05 and it did not have a material impact on our consolidated results of operations, financial condition, or cash flows.

[0001193125-12-334096:mdna:94]
In September 2011, the FASB issued Accounting Standards Update No. 2011-08, Intangibles — Goodwill and
Other (Topic 350). ASU 2011-08 allows entities to first assess qualitatively whether it is necessary to perform the two-step goodwill impairment test. If an entity believes, as a result of its qualitative assessment, that it is more likely than
not that the fair value of a reporting unit is less than its carrying amount, the quantitative two-step goodwill impairment test is required. An entity has the unconditional option to bypass the qualitative assessment and proceed directly to
performing the first step of the goodwill impairment test. ASU 2011-08 is effective for our first quarter of fiscal 2013 but is eligible for early adoption. We do not believe adoption of this standard will have an impact on our consolidated results
of operations, financial condition, or cash flows.

[0001193125-12-334096:mdna:95]
In December 2011, the FASB issued Accounting Standards Update No. 2011-11, Balance
Sheet (Topic 210)-Disclosures about Offsetting Assets and Liabilities (ASU 2011-11). The update requires entities to disclose information about offsetting and related arrangements of financial instruments and derivative instruments. ASU 2011-11
is effective for our first quarter of fiscal 2014. We are currently evaluating the impact of adopting ASU 2011-11, but currently believe there will be no significant impact on our consolidated results of operations, financial condition, or cash
flows.

[0001193125-12-334096:mdna:96]
We do not believe that other recently issued accounting pronouncements will have a material impact on our financial
statements.

[0001193125-12-334096:mdna:97]
[same as prior period, unchanged from 0001193125-12-048929:mdna:105]
