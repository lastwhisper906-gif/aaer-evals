# AMSC 8-K — 0001193125-12-330534 filed 2012-08-02

## item codes, every 8-K on or before 2012-08-03

- 2012-08-02 0001193125-12-330534 — 2.02, 9.01
- 2012-07-27 0001193125-12-318790 — 5.02, 5.07, 9.01
- 2012-06-06 0001193125-12-261030 — 1.01, 2.02, 2.03, 3.02, 5.02, 9.01
- 2012-05-09 0001193125-12-222210 — 5.02
- 2012-04-20 0001193125-12-172045 — 8.01
- 2012-04-13 0001193125-12-162694 — 2.02, 8.01, 9.01
- 2012-04-04 0001193125-12-149102 — 1.01, 2.02, 2.03, 3.02, 9.01
- 2012-02-09 0001193125-12-048009 — 2.02, 9.01
- 2012-02-06 0001193125-12-041344 — 5.07 — amendment of 0000950123-11-102495
- 2011-12-08 0000950123-11-102495 — 5.07
- 2011-11-29 0000950123-11-100822 — 2.05
- 2011-11-09 0000950123-11-096775 — 2.02, 9.01
- 2011-10-31 0000950123-11-093390 — 1.02, 9.01
- 2011-10-07 0000950123-11-089221 — 8.01
- 2011-10-03 0000950123-11-088315 — 7.01
- 2011-09-23 0000950123-11-086288 — 2.02, 9.01
- 2011-09-15 0000950123-11-084585 — 7.01
- 2011-09-06 0000950123-11-082736 — 7.01
- 2011-08-18 0000950123-11-078526 — 3.01, 7.01, 9.01
- 2011-08-11 0000950123-11-075905 — 5.02
- 2011-08-11 0000950123-11-075904 — 2.02, 2.05, 9.01
- 2011-07-11 0000950123-11-064934 — 2.02, 4.02, 9.01
- 2011-06-30 0000950123-11-063287 — 1.01, 3.02, 9.01
- 2011-06-21 0000950123-11-060491 — 3.01, 7.01, 9.01
- 2011-06-13 0000950123-11-058656 — 1.01, 9.01
- 2011-05-24 0000950123-11-053517 — 5.02, 9.01
- 2011-04-05 0001299933-11-001020 — 2.02, 9.01
- 2011-03-15 0000950123-11-025580 — 5.02
- 2011-03-14 0000950123-11-025205 — 1.01, 3.02, 9.01
- 2011-02-01 0001299933-11-000333 — 2.02, 9.01
- 2010-11-12 0000950123-10-104604 — 8.01, 9.01
- 2010-11-08 0000950123-10-102424 — 8.01, 9.01
- 2010-11-02 0001299933-10-003878 — 2.02, 9.01
- 2010-09-15 0000950123-10-086373 — 1.01, 9.01 — amendment, the index does not say of what
- 2010-08-06 0000950123-10-074362 — 5.07
- 2010-07-29 0001299933-10-002860 — 2.02, 9.01
- 2010-05-17 0000950123-10-050424 — 1.01, 9.01
- 2010-05-14 0001299933-10-001972 — 5.02
- 2010-05-13 0001299933-10-001943 — 2.02, 9.01
- 2010-02-08 0001299933-10-000506 — 8.01
- 2010-02-02 0001299933-10-000386 — 2.02, 9.01
- 2009-12-15 0001299933-09-004928 — 5.02
- 2009-10-29 0001299933-09-004267 — 2.02, 9.01
- 2009-08-12 0001193125-09-173026 — 5.02, 9.01
- 2009-07-30 0001193125-09-158842 — 1.01, 2.02, 9.01
- 2009-05-15 0001193125-09-113158 — 5.02
- 2009-05-14 0001193125-09-110619 — 2.02, 9.01
- 2009-04-20 0001193125-09-082590 — 5.02
- 2009-02-03 0001193125-09-016992 — 2.02, 9.01
- 2009-01-22 0001193125-09-009777 — 2.02, 9.01
- 2008-11-04 0001193125-08-223730 — 2.02, 9.01
- 2008-08-11 0001193125-08-173616 — 8.01
- 2008-08-07 0001193125-08-170325 — 8.01
- 2008-08-05 0001193125-08-165888 — 2.02, 9.01
- 2008-06-11 0001193125-08-132049 — 1.01, 9.01
- 2008-05-20 0001193125-08-119372 — 5.02, 9.01
- 2008-05-08 0001193125-08-107052 — 2.02, 9.01
- 2008-01-31 0001193125-08-016233 — 2.02, 9.01
- 2008-01-30 0001193125-08-015494 — 5.03, 9.01
- 2007-11-01 0001193125-07-231866 — 2.02, 9.01
- 2007-10-31 0001193125-07-231225 — 2.05
- 2007-10-29 0001193125-07-228284 — 5.03, 9.01
- 2007-09-27 0001193125-07-208950 — 5.02
- 2007-08-09 0001193125-07-176553 — 2.02, 9.01
- 2007-08-07 0001193125-07-173829 — 1.01, 5.02, 9.01
- 2007-07-02 0001193125-07-148303 — 5.02, 9.01
- 2007-06-20 0001193125-07-139068 — 8.01, 9.01
- 2007-06-14 0001193125-07-135550 — 9.01 — amendment of 0001193125-07-005297
- 2007-06-14 0001193125-07-135340 — 5.02
- 2007-05-24 0001193125-07-122148 — 2.02, 9.01
- 2007-03-30 0001193125-07-070154 — 2.05, 9.01
- 2007-03-23 0001193125-07-062978 — 9.01 — amendment of 0001193125-07-005297
- 2007-02-01 0001193125-07-017883 — 2.02, 9.01
- 2007-01-11 0001193125-07-005297 — 2.01, 9.01
- 2006-12-05 0001181431-06-067500 — 5.02
- 2006-11-29 0001193125-06-243360 — 1.01, 3.02, 9.01
- 2006-11-02 0001193125-06-221464 — 2.02, 9.01
- 2006-09-21 0001193125-06-194526 — 5.02
- 2006-08-08 0001193125-06-164819 — 2.02, 9.01
- 2006-08-02 0001193125-06-159113 — 1.01, 9.01
- 2006-07-28 0001193125-06-156172 — 1.01
- 2006-06-26 0001193125-06-135913 — 1.01, 3.03, 9.01
- 2006-05-11 0001193125-06-108489 — 2.02, 9.01
- 2006-05-05 0001193125-06-102270 — 1.01, 9.01
- 2006-05-01 0001193125-06-094941 — 2.02, 2.06, 9.01
- 2006-02-24 0001193125-06-038281 — 5.02, 9.01
- 2006-02-02 0001181431-06-007665 — 2.02, 9.01
- 2005-11-09 0001181431-05-060304 — 2.02, 9.01
- 2005-08-04 0001181431-05-044420 — 2.02, 9.01
- 2005-07-28 0001193125-05-151272 — 5.02, 9.01
- 2005-06-14 0001193125-05-125148 — 5.02, 9.01
- 2005-05-12 0001181431-05-027410 — 2.02, 9.01
- 2005-05-10 0001193125-05-102795 — 1.01
- 2005-04-05 0001181431-05-020680 — 1.01, 2.02, 3.02, 9.01
- 2005-02-03 0001181431-05-006678 — 2.02, 9.01
- 2004-11-09 0001181431-04-051381 — 2.02, 9.01 — amendment, the index does not say of what
- 2004-11-04 0001181431-04-050706 — 2.02, 9.01
- 2004-10-15 0001193125-04-172458 — 1.01, 9.01
- 2004-08-05 0001193125-04-132162 — 12
- 2004-05-13 0001193125-04-086853 — 12
- 2004-02-05 0001193125-04-015060 — 12
- 2003-11-06 0001193125-03-074000 — 12
- 2003-09-26 0001193125-03-054624 — 5
- 2003-08-06 0001193125-03-029666 — 12
- 2003-05-14 0000927016-03-002619 — 9
- 2002-12-31 0000927016-02-006114 — 5
- 2000-01-24 0000927016-00-000150 — 5, 7
- 1998-11-02 0000950135-98-005625 — 5, 7
- 1998-03-24 0000950135-98-001743 — 5, 7
- 1997-09-05 0000950135-97-003729 — 5, 7
- 1997-06-23 0000950135-97-002785 — 1 — amendment of 0000950135-97-001972
- 1997-04-23 0000950135-97-001972 — 2, 7

## late-filing notifications on or before 2012-08-03

- 2011-08-10 0000950123-11-075677 — NT 10-Q, for the period ended 2011-06-30
- 2011-05-31 0000950123-11-055465 — NT 10-K, for the period ended 2011-03-31

## item 2.02 — earnings release, exhibit 99.1

[0001193125-12-330534:8k_2_02:1]
EX-99.1
2
d389748dex991.htm
EX-99.1

[0001193125-12-330534:8k_2_02:2]
EX-99.1

[0001193125-12-330534:8k_2_02:3]
Exhibit 99.1

[0001193125-12-330534:8k_2_02:4]
AMSC Reports First Quarter

[0001193125-12-330534:8k_2_02:5]
Financial Results

[0001193125-12-330534:8k_2_02:6]
Company exceeds financial guidance and

[0001193125-12-330534:8k_2_02:7]
posts solid year-over-year growth

[0001193125-12-330534:8k_2_02:8]
Devens, MA – August 2, 2012 – AMSC (NASDAQ: AMSC), a global solutions provider serving wind and grid leaders, today reported financial results for its first quarter of fiscal year
2012 ended June 30, 2012.

[0001193125-12-330534:8k_2_02:9]
Revenues for the first quarter of fiscal 2012 were $28.7 million, which compares with $9.1 million for the
first quarter of fiscal 2011. The year-over-year increase was driven by strong growth in the company’s Wind and Grid reporting segments.

[0001193125-12-330534:8k_2_02:10]
For the first quarter of fiscal 2012, AMSC reported a net loss of $10.3 million, or $0.20 per share. This figure includes a non-cash benefit of
approximately $7.3 million for the settlement of adverse purchase commitments with certain vendors as well as a $2.4 million non-cash “mark-to-market” charge driven by the re-valuation of the derivative liability and warrants associated
with the company’s recently completed debt financings. For the first quarter of fiscal 2011, AMSC’s net loss was $37.7 million, or $0.74 per share.

[0001193125-12-330534:8k_2_02:11]
The company’s non-GAAP net loss for the first quarter of fiscal 2012 was $10.2 million, or $0.20 per share. This compares with a non-GAAP net loss of $30.8 million, or $0.61 per share, for the first
quarter of fiscal 2011. Please refer to the financial table below for a reconciliation of GAAP to non-GAAP results.

[0001193125-12-330534:8k_2_02:12]
AMSC’s cash, cash
equivalents, marketable securities and restricted cash at June 30, 2012 totaled $87.1 million. This compares with $66.2 million as of March 31, 2012. The increase in cash, cash equivalents, marketable securities and restricted cash was
driven by the financings that were completed and announced in the first quarter of fiscal 2012.

[0001193125-12-330534:8k_2_02:13]
The company’s total backlog as of
June 30, 2012 was approximately $269 million. This compares with approximately $291 million as of March 31, 2012 and $225 million as of June 30, 2011.

[0001193125-12-330534:8k_2_02:14]
“AMSC continues to meet its financial objectives, delivering a strong year-over-year revenue increase and net loss reduction in the first fiscal quarter,” said AMSC President and Chief Executive
Officer Daniel P. McGahn. “With key contributions coming from China, Korea and India in our Wind segment and Australia and Romania in our Grid segment, our revenue streams remained diverse and well balanced. This, coupled with the cost
reduction initiatives that were put into place in past quarters, enabled us to once again improve our bottom-line performance while minimizing cash usage.”

[0001193125-12-330534:8k_2_02:15]
Looking Forward

[0001193125-12-330534:8k_2_02:16]
“We expect our second-quarter revenues to be relatively flat year over year before growth returns in the second half of our fiscal year,” said McGahn. “For fiscal year 2012 as a whole, we
continue to focus on maintaining our strong track record of execution and are committed to driving year-over-year growth while prudently managing our expenses and our cash as we work toward sustainable profits and positive cash flows.”

[0001193125-12-330534:8k_2_02:17]
For the quarter ending September 30, 2012, AMSC expects that its revenues will exceed $20 million. AMSC expects that its net loss for
the second quarter of fiscal 2012 will be less than $22 million, or $0.43 per share. This guidance assumes no impact from mark-to-market adjustments related to the derivative liability and warrants. AMSC expects that its non-GAAP net loss for the
second quarter of fiscal 2012 will be less than $17 million, or $0.33 per share. AMSC estimates that it will have more than $70 million in cash, cash equivalents, marketable securities and restricted cash on September 30, 2012.

[0001193125-12-330534:8k_2_02:18]
Conference Call Reminder

[0001193125-12-330534:8k_2_02:19]
In conjunction
with this announcement, AMSC management will participate in a conference call with investors beginning at 10:00 a.m. Eastern Time today to discuss the company’s results and its business outlook. Those who wish to listen to the live or archived
conference call webcast should visit the “Investors” section of the company’s website at http://www.amsc.com/investors. The live call also can be accessed by dialing 719-325-2486 and using conference ID 1467837.

[0001193125-12-330534:8k_2_02:20]
About AMSC (NASDAQ: AMSC)

[0001193125-12-330534:8k_2_02:21]
AMSC
generates the ideas, technologies and solutions that meet the world’s demand for smarter, cleaner … better energy. Through its Windtec™ Solutions, AMSC enables manufacturers to launch best-in-class wind turbines quickly, effectively
and profitably. Through its Gridtec™ Solutions, AMSC provides the engineering planning services and advanced grid systems that optimize network reliability, efficiency and performance. The company’s solutions are now powering gigawatts of
renewable energy globally and enhancing the performance and reliability of power networks in more than a dozen countries. Founded in 1987, AMSC is headquartered near Boston, Massachusetts with operations in Asia, Australia, Europe and North America.
For more information, please visit www.amsc.com.

[0001193125-12-330534:8k_2_02:22]
AMSC, Windtec and Gridtec are trademarks or registered trademarks of American
Superconductor Corporation. All other brand names, product names, trademarks or service marks belong to their respective holders.

[0001193125-12-330534:8k_2_02:23]
reduce our revenue and lower or eliminate our profit; we may acquire additional complementary businesses
or technologies, which may require us to incur substantial costs for which we may never realize the anticipated benefits; many of our customers outside of the United States are, either directly or indirectly, related to governmental entities, and we
could be adversely affected by violations of the United States Foreign Corrupt Practices Act and similar worldwide anti-bribery laws outside the United States; we have limited experience in marketing and selling our superconductor products and
system-level solutions, and our failure to effectively market and sell our products and solutions could lower our revenue and cash flow; we have a history of operating losses, and we may incur additional losses in the future; our operating results
may fluctuate significantly from quarter to quarter and may fall below expectations in any particular fiscal quarter; we may require additional funding in the future and may be unable to raise capital when needed; our new debt obligations include
certain covenants and other events of default—should we not comply with the covenants or incur an event of default, we may be required to repay our debt obligations in cash, which could have an adverse effect on our liquidity; we have recorded
a liability for adverse purchase commitments with certain of our vendors—should we be required to settle these liabilities in cash, our liquidity could be adversely affected; if we fail to maintain proper and effective internal controls over
financial reporting, our ability to produce accurate and timely financial statements could be impaired and may lead investors and other users to lose confidence in our financial data; we may be required to issue performance bonds or provide letters
of credit, which restricts our ability to access any cash used as collateral for the bonds or letters of credit; changes in exchange rates could adversely affect our results from operations; growth of the wind energy market depends largely on the
availability and size of government subsidies and economic incentives; we depend on sales to customers in China, and global conditions could negatively affect our operating results or limit our ability to expand our operations outside of China;
changes in China’s political, social, regulatory and economic environment may affect our financial performance; our products face intense competition, which could limit our ability to acquire or retain customers; our international operations
are subject to risks that we do not face in the United States, which could have an adverse effect on our operating results; adverse changes in domestic and global economic conditions could adversely affect our operating results; we may be unable to
adequately prevent disclosure of trade secrets and other proprietary information; our patents may not provide meaningful protection for our technology, which could result in us losing some or all of our market position; the commercial uses of
superconductor products are limited today, and a widespread commercial market for our products may not develop; there are a number of technological challenges that must be successfully addressed before our superconductor products can gain widespread
commercial acceptance, and our inability to address such technological challenges could adversely affect our ability to acquire customers for our products; we have not manufactured our Amperium wire in commercial quantities, and a failure to
manufacture our Amperium wire in commercial quantities at acceptable cost and quality levels would substantially limit our future revenue and profit potential; third parties have or may acquire patents that cover the materials, processes and
technologies we use or may use in the future to manufacture our Amperium products, and our success depends on our ability to license such patents or other proprietary rights; our technology and products could infringe intellectual property rights of
others, which may require costly litigation and, if we are not successful, could cause us to pay substantial damages and disrupt our business; we have filed a demand for arbitration and other lawsuits against our former largest customer, Sinovel,
regarding amounts we contend are overdue—we cannot be certain as to the outcome of these proceedings; we have been named as a party to purported stockholder class actions and stockholder derivative complaints, and we may be named in additional
litigation, all of which will require significant management time and attention, result in significant legal expenses and may result in an unfavorable outcome, which could have a material adverse effect on our business, operating results and
financial condition; our 7% convertible note contains warrants and provisions that could limit our ability to repay the note in shares of common stock and should the note be repaid in stock, shareholders could experience significant dilution; our
common stock has experienced, and may continue to experience, significant market price and volume fluctuations, which may prevent our stockholders from selling our common stock at a profit and could lead to costly litigation against us that could
divert our management’s attention. Reference is made to many of these factors and others in the “Risk Factors” section of the company’s most recent quarterly or annual report filed with the Securities and Exchange Commission. In
addition, any forward-looking statements included in this release represent the company’s expectations as of the date of this release. While the company anticipates that subsequent events and developments may cause the company’s views to
change, the company specifically disclaims any obligation to update these forward-looking statements. These forward-looking statements should not be relied upon as representing the company’s views as of any date subsequent to the date of this
release.

[0001193125-12-330534:8k_2_02:24]
UNAUDITED CONSOLIDATED STATEMENTS OF OPERATIONS

[0001193125-12-330534:8k_2_02:25]
(In thousands, except per share data)

[0001193125-12-330534:8k_2_02:26]
|  |  | Three months endedJune 30, |  |
|  |  | 2012 |  |  | 2011 |  |
| Revenues: |  |  |  |  |  |  |  |  |
| Wind |  | $ | 16,511 |  |  | $ | 4,262 |  |
| Grid |  |  | 12,205 |  |  |  | 4,796 |  |
| Total revenues |  |  | 28,716 |  |  |  | 9,058 |  |
| Cost of revenues |  |  | 16,926 |  |  |  | 16,955 |  |
| Gross profit (loss) |  |  | 11,790 |  |  |  | (7,897 | ) |
| Operating expenses: |  |  |  |  |  |  |  |  |
| Research and development |  |  | 3,910 |  |  |  | 8,136 |  |
| Selling, general and administrative |  |  | 13,799 |  |  |  | 21,990 |  |
| Restructuring and impairments |  |  | 128 |  |  |  | — |  |
| Amortization of acquisition related intangibles |  |  | 81 |  |  |  | 304 |  |
| Total operating expenses |  |  | 17,918 |  |  |  | 30,430 |  |
| Operating loss |  |  | (6,128 | ) |  |  | (38,327 | ) |
| Change in fair value of derivatives and warrants |  |  | (2,388 | ) |  |  | — |  |
| Interest (expense) income, net |  |  | (2,718 | ) |  |  | 241 |  |
| Other income, net |  |  | 123 |  |  |  | 566 |  |
| Loss before income tax expense |  |  | (11,111 | ) |  |  | (37,520 | ) |
| Income tax (gain) expense |  |  | (836 | ) |  |  | 159 |  |
| Net loss |  | $ | (10,275 | ) |  | $ | (37,679 | ) |
| Net loss per common share |  |  |  |  |  |  |  |  |
| Basic |  | $ | (0.20 | ) |  | $ | (0.74 | ) |
| Diluted |  | $ | (0.20 | ) |  | $ | (0.74 | ) |
| Weighted average number of common shares outstanding |  |  |  |  |  |  |  |  |
| Basic |  |  | 51,191 |  |  |  | 50,709 |  |
| Diluted |  |  | 51,191 |  |  |  | 50,709 |  |

[0001193125-12-330534:8k_2_02:27]
UNAUDITED CONSOLIDATED BALANCE SHEETS

[0001193125-12-330534:8k_2_02:28]
(In thousands)

[0001193125-12-330534:8k_2_02:29]
|  |  | June 30,2012 |  |  | March 31,2012 |  |
| ASSETS |  |  |  |  |  |  |  |  |
| Current assets: |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 60,487 |  |  | $ | 46,279 |  |
| Marketable securities |  |  | 5,209 |  |  |  | 5,304 |  |
| Accounts receivable, net |  |  | 13,558 |  |  |  | 18,999 |  |
| Inventory |  |  | 28,699 |  |  |  | 29,256 |  |
| Prepaid expenses and other current assets |  |  | 30,261 |  |  |  | 31,444 |  |
| Restricted cash |  |  | 16,684 |  |  |  | 12,086 |  |
| Deferred tax assets |  |  | 203 |  |  |  | 203 |  |
| Total current assets |  |  | 155,101 |  |  |  | 143,571 |  |
| Property, plant and equipment, net |  |  | 87,676 |  |  |  | 90,828 |  |
| Intangibles, net |  |  | 3,455 |  |  |  | 3,772 |  |
| Restricted cash |  |  | 4,767 |  |  |  | 2,540 |  |
| Deferred tax assets |  |  | 3,129 |  |  |  | 3,129 |  |
| Other assets |  |  | 10,050 |  |  |  | 11,216 |  |
| Total assets |  | $ | 264,178 |  |  | $ | 255,056 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |  |  |  |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |  |  |  |
| Accounts payable and accrued expenses |  | $ | 30,850 |  |  | $ | 37,582 |  |
| Note payable, current portion, net of discount of $707 as of June 30, 2012 |  |  | 2,370 |  |  |  | — |  |
| Current portion of convertible note, net of discount of $7,055 as of June 30, 2012 |  |  | 1,278 |  |  |  | — |  |
| Derivative liability |  |  | 13,565 |  |  |  | — |  |
| Adverse purchase commitments |  |  | 17,516 |  |  |  | 25,894 |  |
| Deferred revenue |  |  | 15,390 |  |  |  | 19,718 |  |
| Deferred tax liabilities |  |  | 3,129 |  |  |  | 3,129 |  |
| Total current liabilities |  |  | 84,098 |  |  |  | 86,323 |  |
| Note Payable, net of current portion and discount of $392 as of June 30, 2012 |  |  | 6,531 |  |  |  | — |  |
| Convertible note net of current portion and discount of $3,282 as of June 30, 2012 |  |  | 13,385 |  |  |  | — |  |
| Deferred revenue |  |  | 1,681 |  |  |  | 1,558 |  |
| Deferred tax liabilities |  |  | 203 |  |  |  | 203 |  |
| Other liabilities |  |  | 1,865 |  |  |  | 2,093 |  |
| Total liabilities |  |  | 107,763 |  |  |  | 90,177 |  |
| Stockholders’ equity: |  |  |  |  |  |  |  |  |
| Common stock |  |  | 522 |  |  |  | 520 |  |
| Additional paid-in capital |  |  | 899,612 |  |  |  | 896,603 |  |
| Treasury stock |  |  | (307 | ) |  |  | (271 | ) |
| Accumulated other comprehensive loss |  |  | 863 |  |  |  | 2,027 |  |
| Accumulated deficit |  |  | (744,275 | ) |  |  | (734,000 | ) |
| Total stockholders’ equity |  |  | 156,415 |  |  |  | 164,879 |  |
| Total liabilities and stockholders’ equity |  | $ | 264,178 |  |  | $ | 255,056 |  |

[0001193125-12-330534:8k_2_02:30]
UNAUDITED CONSOLIDATED STATEMENTS OF CASH FLOWS

[0001193125-12-330534:8k_2_02:31]
(In thousands)

[0001193125-12-330534:8k_2_02:32]
|  |  | Three Months endedJune 30, |  |
|  |  | 2012 |  |  | 2011 |  |
| Cash flows from operating activities: |  |  |  |  |  |  |  |  |
| Net (loss) income |  | $ | (10,275 | ) |  | $ | (37,679 | ) |
| Adjustments to reconcile net (loss) income to net cash (used in) provided by operations: |  |  |  |  |  |  |  |  |
| Depreciation and amortization |  |  | 3,344 |  |  |  | 3,242 |  |
| Stock-based compensation expense |  |  | 1,994 |  |  |  | 3,466 |  |
| Restructuring charges, net of payments |  |  | (39 | ) |  |  | — |  |
| Provision for excess and obsolete inventory |  |  | 250 |  |  |  | 413 |  |
| Adverse purchase commitment losses (recoveries), net |  |  | (7,301 | ) |  |  | 1,071 |  |
| Loss on minority interest investments |  |  | 812 |  |  |  | — |  |
| Change in fair value of derivatives and warrants |  |  | 2,388 |  |  |  | — |  |
| Non-cash interest expense |  |  | 2,282 |  |  |  | — |  |
| Other non-cash items |  |  | 200 |  |  |  | 827 |  |
| Changes in operating asset and liability accounts: |  |  |  |  |  |  |  |  |
| Accounts receivable |  |  | 4,132 |  |  |  | 670 |  |
| Inventory |  |  | 136 |  |  |  | (5,324 | ) |
| Prepaid expenses and other current assets |  |  | 848 |  |  |  | (7,812 | ) |
| Accounts payable and accrued expenses |  |  | (6,449 | ) |  |  | (19,732 | ) |
| Deferred revenue |  |  | (3,913 | ) |  |  | 3,084 |  |
| Net cash provided by (used in) operating activities |  |  | (11,591 | ) |  |  | (57,774 | ) |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |
| Net cash (used in) provided by investing activities |  |  | (6,846 | ) |  |  | 59,753 |  |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |
| Net cash provided by financing activities |  |  | 32,925 |  |  |  | 4,376 |  |
| Effect of exchange rate changes on cash and cash equivalents |  |  | (280 | ) |  |  | 747 |  |
| Net increase in cash and cash equivalents |  |  | 14,208 |  |  |  | 7,102 |  |
| Cash and cash equivalents at beginning of period |  |  | 46,279 |  |  |  | 123,783 |  |
| Cash and cash equivalents at end of period |  | $ | 60,487 |  |  | $ | 130,885 |  |

[0001193125-12-330534:8k_2_02:33]
RECONCILIATION OF GAAP NET INCOME (LOSS) TO NON-GAAP NET INCOME (LOSS)

[0001193125-12-330534:8k_2_02:34]
(In thousands, except per share data)

[0001193125-12-330534:8k_2_02:35]
|  |  | Three months ended June 30, |  |
|  |  | 2012 |  |  | 2011 |  |
| Net (loss) income |  | $ | (10,275 | ) |  | $ | (37,679 | ) |
| Adverse purchase commitment (recoveries) losses, net |  |  | (7,301 | ) |  |  | 1,071 |  |
| Stock-based compensation |  |  | 1,994 |  |  |  | 3,466 |  |
| Amortization of acquisition-related intangibles |  |  | 81 |  |  |  | 304 |  |
| Restructuring and impairment charges |  |  | 128 |  |  |  | — |  |
| Executive severance |  |  | — |  |  |  | 2,066 |  |
| Sinovel litigation |  |  | 120 |  |  |  | — |  |
| Consumption of zero cost-basis inventory |  |  | 387 |  |  |  | — |  |
| Change in fair value of derivatives and warrants |  |  | 2,388 |  |  |  | — |  |
| Non-cash interest expense |  |  | 2,282 |  |  |  | — |  |
| Non-GAAP net (loss) income |  | $ | (10,196 | ) |  | $ | (30,772 | ) |
| Non-GAAP (loss) earnings per share |  | $ | (0.20 | ) |  | $ | (0.61 | ) |
| Weighted average shares outstanding * |  |  | 51,191 |  |  |  | 50,709 |  |
| * Diluted shares are used for periods where net income is generated. |  |  |  |  |  |  |  |  |

[0001193125-12-330534:8k_2_02:36]
| Reconciliation of Forecast GAAP Net Loss to Non-GAAP Net Loss |  |
| (In millions, except per share data) |  |
|  |  | Three monthsendingSeptember 30, 2012 |  |
| Net loss |  | $ | (22.0 | ) |
| Amortization of acquisition-related intangibles |  |  | 0.1 |  |
| Stock-based compensation |  |  | 2.5 |  |
| Non-cash interest expense |  |  | 2.4 |  |
| Non-GAAP net loss |  | $ | (17.0 | ) |
| Non-GAAP net loss per share |  | $ | (0.33 | ) |
| Shares outstanding |  |  | 51.5 |  |

[0001193125-12-330534:8k_2_02:37]
Note: Non-GAAP net income (loss) is defined by the company as net income (loss) before adverse purchase commitments
(recoveries) losses, net; stock-based compensation; amortization of acquisition-related intangibles; restructuring and impairment charges; executive severance; Sinovel litigation costs; margin on zero cost-basis accounting; non-cash interest
expense; change in fair value of derivative liability and warrants and other unusual charges; net of any tax effects related to these items. The company believes non-GAAP net income (loss) assists management and investors in comparing the
company’s performance across reporting periods on a consistent basis by excluding these non-cash or non-recurring charges that it does not believe are indicative of its core operating performance. The company also regards non-GAAP net income
(loss) as a useful measure of operating performance and cash flow to complement operating income, net income (loss) and other GAAP financial performance measures. In addition, the company uses non-GAAP net (loss) income as a factor in evaluating
management’s performance when determining incentive compensation and to evaluate the effectiveness of its business strategies.

[0001193125-12-330534:8k_2_02:38]
Generally, a non-GAAP financial measure is a numerical measure of a company’s performance, financial
position or cash flow that either excludes or includes amounts that are not normally excluded or included in the most directly comparable measure calculated and presented in accordance with GAAP. The non-GAAP measures included in this release,
however, should be considered in addition to, and not as a substitute for or superior to, operating income, cash flows, or other measures of financial performance prepared in accordance with GAAP. A reconciliation of non-GAAP to GAAP net income is
set forth in the table above.

[0001193125-12-330534:8k_2_02:39]
AMSC Contact:

[0001193125-12-330534:8k_2_02:40]
Jason Fredette

[0001193125-12-330534:8k_2_02:41]
Phone: 978-842-3177

[0001193125-12-330534:8k_2_02:42]
Email: jason.fredette@amsc.com
