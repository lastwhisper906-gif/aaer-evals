# AMSC notes — 0001193125-12-334096


## amsc:ScheduleOfBusinessSegmentAssetsTextBlock

[0001193125-12-334096:notes:1]
|  |  | June 30, |  | March 31, |
|  |  | 2012 |  | 2012 |
| Wind | $ | 66,598 | $ | 70,054 |
| Grid |  | 82,006 |  | 89,091 |
| Corporate assets |  | 115,574 |  | 95,911 |
| Total | $ | 264,178 | $ | 255,056 |


## amsc:ScheduleOfBusinessSegmentOperatingResultsTextBlock

[0001193125-12-334096:notes:2]
|  |  | Three months ended |
|  |  | June 30, |
|  |  | 2012 |  | 2011 |
| Revenues: |  |  |  |  |
| Wind | $ | 16,511 | $ | 4,262 |
| Grid |  | 12,205 |  | 4,796 |
| Total | $ | 28,716 | $ | 9,058 |

[0001193125-12-334096:notes:3]
|  |  | Three months ended |  |
|  |  | June 30, |  |
|  |  | 2012 |  |  | 2011 |  |
| Operating (loss) income: |  |  |  |  |  |  |
| Wind | $ | 1,301 |  | $ | (24,370 | ) |
| Grid |  | (5,343 | ) |  | (10,552 | ) |
| Unallocated corporate expenses |  | (2,086 | ) |  | (3,405 | ) |
| Total | $ | (6,128 | ) | $ | (38,327 | ) |


## amsc:ScheduleOfLiabilitiesMeasuredAtFairValueTableTextBlock

[0001193125-12-334096:notes:4]
|  |  | Derivative Liability |  | Warrants |
| April 1, 2012 | $ | — | $ | — |
| Valuation of derivative liability |  | 3,779 |  | — |
| Warrant issuance with Senior Convertible Notes |  | — |  | 7,018 |
| Warrant issuance with Senior Secured Term Loan |  | — |  | 380 |
| Mark to market adjustment |  | 757 |  | 1,631 |
| Balance at June 30, 2012 | $ | 4,536 | $ | 9,029 |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001193125-12-334096:notes:5]
12. Commitments and Contingencies

[0001193125-12-334096:notes:6]
Commitments

[0001193125-12-334096:notes:7]
Purchase Commitments

[0001193125-12-334096:notes:8]
The Company periodically enters into non-cancelable purchase contracts in order to ensure the availability of materials to support production of its products. Purchase commitments represent enforceable and legally binding agreements with suppliers to purchase goods or services. The Company periodically assesses the need to provide for impairment on these purchase contracts and record a loss on purchase commitments when required. As of June 30, 2012, the Company recorded a liability for adverse purchase commitments of $17.5 million. During the three months ended June 30, 2012, the Company adjusted its accrual for adverse purchase commitments by $7.3 million due to settlements with certain vendors.

[0001193125-12-334096:notes:9]
During the fourth quarter of the year ended March 31, 2012, several vendors notified the Company that they had suffered losses as a result of procuring safety stock in anticipation of receiving future purchase orders or contracts from the Company and subsequently three vendors have filed suits through the Chinese legal system seeking payment for inventories held to be delivered under purchase orders and safety stock. The Company has accrued outstanding adverse purchase commitments based on legally binding contracts and purchase orders that were placed with its vendors for parts with no future demand. The vendor claims for safety stock were not supported by valid purchase orders or valid executed contracts and are not considered part of the adverse purchase commitment liability. The claims for safety stock have not been accrued as of June 30, 2012. The Company has determined that although it believes that there is no legally enforceable contract for safety stock and will continue to defend its legal position that it does not owe amounts for safety stock, that it is reasonably possible that a case may be made against the Company under certain situations. As the loss is reasonably possible but not probable, the Company has not accounted for the loss. The Company has determined that the range for this potential loss is between $0 and $4 million.

[0001193125-12-334096:notes:10]
Contingencies

[0001193125-12-334096:notes:11]
From time to time, the Company is involved in legal and administrative proceedings and claims of various types. The Company records a liability in its consolidated financial statements for these matters when a loss is known or considered probable and the amount can be reasonably estimated. The Company reviews these estimates each accounting period as additional information is known and adjusts the loss provision when appropriate. If a matter is both probable to result in liability and the amounts of loss can be reasonably estimated, the Company estimates and discloses the possible loss or range of loss. If the loss is not probable or cannot be reasonably estimated, a liability is not recorded in its consolidated financial statements.

[0001193125-12-334096:notes:12]
Between April 6, 2011 and May 12, 2011, seven putative securities class action complaints were filed against the Company and two of its officers in the United States District Court for the District of Massachusetts; one complaint additionally asserted claims against the underwriters who participated in our November 12, 2010 securities offering. On June 7, 2011, the United States District Court for the District of Massachusetts consolidated these actions under the caption Lenartz v. American Superconductor Corporation, et al., Docket No. 1:11-cv-10582-WGY. On August 31, 2011, Lead Plaintiff, the Plumbers and Pipefitters National Pension Fund, filed a consolidated amended complaint against the Company, its officers and directors, and the underwriters who participated in our November 12, 2010 securities offering, asserting claims under sections 10(b) and 20(a) of the Securities Exchange Act of 1934 and Rule 10b-5 promulgated under the Securities Exchange Act of 1934 (the "Exchange Act"), as well as under sections 11, 12(a)(2) and 15 of the Securities Act of 1933 (the "Securities Act"). The complaint alleges that during the relevant class period, the Company and its officers omitted to state material facts and made materially false and misleading statements relating to, among other things, its projected and recognized revenues and earnings, as well as its relationship with Sinovel Wind Group Co., Ltd. that artificially inflated the value of the Company's stock price. The complaint further alleges that the Company's November 12, 2010 securities offering contained untrue statements of material facts and omitted to state material facts required to be stated therein. The plaintiffs seek unspecified damages, rescindment of the Company's November 12, 2010 securities offering, and an award of costs and expenses, including attorney's fees. All defendants moved to dismiss the consolidated amended complaint. On December 16, 2011, the district court issued a summary order declining to dismiss the Securities Act claims against the Company and its officers, and taking under advisement the motion to dismiss the Exchange Act claims against the Company and its officers and the motion to dismiss the Securities Act claims made against the underwriters. On July 26, 2012, the district court dismissed the Exchange Act claims against the Company and its officers and denied the motion to dismiss the Securities Act claims made against the underwriters.

[0001193125-12-334096:notes:13]
Between May 4, 2011 and June 17, 2011, four putative shareholder derivative complaints were filed against the Company (as a nominal defendant) and certain of its directors in the United States District Court for the District of Massachusetts. On July 5, 2011, the District Court consolidated three of these actions, and that matter is now captioned In re American Superconductor Corporation Derivative Litigation, Docket No. 1:11-cv-10784-WGY. On June 1, 2011, the plaintiff in the fourth action, Marlborough Family Revocable Trust v. Yurek, et al., moved to voluntarily dismiss its complaint and refiled its complaint in Superior Court for the Commonwealth of Massachusetts, Middlesex County. On September 7, 2011, the Marlborough action and another putative shareholder derivative complaint filed in Superior Court for the Commonwealth of Massachusetts were consolidated. That consolidated matter is captioned Marlborough Family Revocable Trust v. Yurek, et al., Docket No. 11-1961. On January 12, 2012, an additional shareholder derivative complaint was filed in the Court of Chancery for the State of Delaware. That matter is captioned Krasnoff v. Budhraja, et al., Docket No. 7171. The allegations of the derivative complaints mirror the allegations made in the putative class action complaints described above. The plaintiffs purport to assert claims against the director defendants for breach of fiduciary duty, abuse of control, gross mismanagement, unjust enrichment and corporate waste. The plaintiffs seek unspecified damages on behalf of the Company, as well as an award of costs and expenses, including attorney's fees.

[0001193125-12-334096:notes:14]
With respect to the above referenced litigation matters, an estimate of loss or range of loss cannot be made. There are numerous factors that make it difficult to meaningfully estimate possible loss or range of loss at this stage of these litigation matters, including that: the proceedings are in relatively early stages, there are significant factual and legal issues to be resolved, information obtained or rulings made during the lawsuits could affect the methodology for calculation of rescission and the related statutory interest rate. In addition, with respect to claims where damages are the requested relief, no amount of loss or damages has been specified. Therefore, the Company is unable at this time to estimate possible losses. The Company believes that these litigations are without merit, and it intends to defend these actions vigorously. Therefore no adjustment has been made to the financial statements to reflect the outcome of these uncertainties.

[0001193125-12-334096:notes:15]
On September 13, 2011, the Company commenced a series of legal actions in China against Sinovel Wind Group Co. Ltd. ("Sinovel"). The Company's Chinese subsidiary, Suzhou AMSC Superconductor Co. Ltd., filed a claim for arbitration with the Beijing Arbitration Commission in accordance with the terms of the Company's supply contracts with Sinovel. The case is captioned (2011) Jin Zhong An Zi No. 0963. On March 31, 2011, Sinovel refused to accept contracted shipments of 1.5 megawatt (MW) and 3 MW wind turbine core electrical components and spare parts that the Company was prepared to deliver. The Company alleges that these actions constitute material breaches of its contracts because Sinovel did not give it notice that it intended to delay deliveries as required under the contracts. Moreover, the Company alleges that Sinovel has refused to pay past due amounts for prior shipments of core electrical components and spare parts. The Company is seeking compensation for past product shipments and retention (including interest) in the amount of approximately RMB 485 million ($76 million) due to Sinovel's breaches of its contracts. The Company is also seeking specific performance of our existing contracts as well as reimbursement of all costs and reasonable expenses with respect to the arbitration. The value of the undelivered components under the existing contracts, including the deliveries refused by Sinovel in March 2011, amounts to approximately RMB 4.6 billion ($720 million).

[0001193125-12-334096:notes:16]
On October 8, 2011, Sinovel filed with the Beijing Arbitration Commission an application under the caption (2011) Jing Zhong An Zi No. 0963, for a counterclaim against the Company for breach of the same contracts under which the Company filed its original arbitration claim. Sinovel claimed, among other things, that the goods supplied by the Company do not conform to the standards specified in the contracts and claimed damages in the amount of approximately RMB 370 million ($58 million). On October 17, 2011, Sinovel filed with the Beijing Arbitration Commission a request for change of counterclaim to increase its damage claim to approximately RMB 1 billion ($157 million). On December 22, 2011, Sinovel filed with the Beijing Arbitration Commission an additional request for change of counterclaim to increase its damages claim to approximately RMB 1.2 billion ($190 million). On February 27, 2012, Sinovel filed with the Beijing Arbitration Commission an application under the caption (2012) Jing Zhong An Zi No. 0157, against the Company for breach of the same contracts under which the Company filed its original arbitration claim. Sinovel claimed, among other things, that the goods supplied by the Company do not conform to the standards specified in the contracts and claimed damages in the amount of approximately RMB 105 million ($17 million). The Company believes that Sinovel's claims are without merit and it intends to defend these actions vigorously. Since the proceedings in this matter are in relatively early stages, the Company cannot reasonably estimate possible losses or range of losses at this time.

[0001193125-12-334096:notes:17]
The Company also submitted a civil action application to the Beijing No. 1 Intermediate People's Court under the caption (2011) Yi Zhong Min Chu Zi No. 15524, against Sinovel for software copyright infringement on September 13, 2011. The application alleges Sinovel's unauthorized use of portions of the Company's wind turbine control software source code developed for Sinovel's 1.5MW wind turbines and the binary code, or upper layer, of the Company's software for the PM3000 power converters in 1.5MW wind turbines. In July 2011, a former employee of the Company's Austrian subsidiary was arrested in Austria on charges of economic espionage and fraudulent manipulation of data. In September 2011, the former employee pled guilty to the charges, and was imprisoned. As a result of the Company's internal investigation and a criminal investigation conducted by Austrian authorities, the Company believes that this former employee was contracted by Sinovel through an intermediary while employed by the Company and improperly obtained and transferred to Sinovel portions of its wind turbine control software source code developed for Sinovel's 1.5MW wind turbines. Moreover, the Company believes the former employee illegally used source code to develop for Sinovel a software modification to circumvent the encryption and remove technical protection measures on the Company's PM3000 power converters in 1.5MW wind turbines in the field. The Company is seeking a cease and desist order with respect to the unauthorized copying, installation and use of its software, monetary damages of approximately RMB 38 million ($6 million) for our economic losses and reimbursement of all costs and reasonable expenses. The No. 1 Intermediate People's Court accepted the case, which was necessary in order for the case to proceed. In November 2011, Sinovel filed a motion to remove this case from the Beijing No. 1 Intermediate People's Court and transfer the matter to the Beijing Arbitration Commission. On February 14, 2012, the court denied Sinovel's motion to remove the case. On February 21, 2012, Sinovel filed an appeal of the Beijing No. 1 Intermediate People's Court decision to the Beijing Higher People's Court. On April 25, 2012, the Beijing Higher People's Court issued a final Civil Ruling which supports the Beijing No.1 Intermediate People's Court's civil ruling and rejected Sinovel's appeal. Sinovel has filed an appeal of the Beijing Higher People's Court's decision with China's Supreme People's Court. On June 18, 2012, Sinovel filed a new motion to remove this case from the Beijing No. 1 Intermediate People's Court to the court located in Gansu Province.

[0001193125-12-334096:notes:18]
The Company submitted a civil action application to the Beijing Higher People's Court against Sinovel and certain of its employees for trade secret infringement on September 13, 2011 under the caption (2011) Gao Min Chu Zi No. 4193. The application alleges the defendants' unauthorized use of portions of the Company's wind turbine control software source code developed for Sinovel's 1.5MW wind turbines as described above with respect to the Copyright Action. The Company is seeking monetary damages of RMB 2.9 billion ($453 million) for the trade secret infringement as well as reimbursement of all costs and reasonable expenses. The Beijing Higher People's Court accepted the case, which was necessary in order for the case to proceed. On December 22, 2011, the Beijing Higher People's Court transferred this case to the Beijing No. 1 Intermediate People's Court under the caption (2011) Gao Min Chu Zi No. 4193. On June 7, 2012, the Company received an Acceptance Notice from the Beijing No.1 Intermediate People's Court under the caption (2012) Yi Zhong Min Chu Zi No.6833. The Company is currently awaiting notice from the Beijing No. 1 Intermediate People's Court regarding the first hearing date.

[0001193125-12-334096:notes:19]
On September 16, 2011, the Company filed a civil copyright infringement complaint in the Hainan Province No. 1 Intermediate People's Court against Dalian Guotong Electric Co. Ltd. ("Guotong"), a supplier of power converter products to Sinovel, and Huaneng Hainan Power, Inc. ("Huaneng"), a wind farm operator that has purchased Sinovel wind turbines containing Guotong power converter products. The case is captioned (2011) Hainan Yi Zhong Min Chu Zi No. 62. The application alleges that the Company's PM1000 converters in certain Sinovel wind turbines have been replaced by converters produced by Guotong. Because the Guotong converters are being used in wind turbines containing the Company's wind turbine control software, the Company believes that its copyrighted software is being infringed. The Company is seeking a cease and desist order with respect to the unauthorized use of its software, monetary damages of RMB 1.2 million ($0.2 million) for its economic losses (with respect to Guotong only) and reimbursement of all costs and reasonable expenses. The court has accepted the case, which was necessary in order for the case to proceed. In addition, upon the request of the defendant Huaneng, Sinovel has been added by the court to this case as a defendant and Huaneng has been released from this case. In December 2011, Sinovel filed a jurisdiction opposition motion requesting dismissal by the Hainan Province No. 1 Intermediate People's Court, saying the case should be governed by the Beijing Arbitration Commission. On February 3, 2012, the Company received the Civil Ruling from the court, which granted Sinovel's motion, and dismissed the entire case. The Company appealed the court's ruling to the Hainan Higher Court, which on April 5, 2012 upheld the decision of the Hainan Province No. 1 Intermediate People's Court. On April 9, 2012, the Company filed an appeal of the Hainan Higher Court's decision with China's Supreme People's Court. The Supreme Court accepted the appeal on May 23, 2012. The case is captioned, (2012) Min Shen Zi No. 630.

[0001193125-12-334096:notes:20]
Ghodawat Energy Pvt Ltd ("Ghodawat"), a company registered in India carrying on the business of wind power development, lodged a Request for Arbitration with the Secretariat of the ICC International Court of Arbitration on May 12, 2011 and named AMSC Windtec GmbH ("AMSC Austria") as the Respondent. Under the Request for Arbitration, Ghodawat alleges that AMSC Austria breached an agreement dated March 19, 2008 pursuant to which AMSC Austria granted a license to Ghodawat to manufacture, use, sell, market, erect, commission and maintain certain wind turbines using its technical information and wind turbine design (the "License Agreement"). Under the Request for Arbitration, Ghodawat's claims in this arbitration amount to approximately €18 million ($24 million). AMSC Austria filed an Answer to Request for Arbitration and Counterclaim ("Answer and Counterclaim"), in which AMSC Austria denied Ghodawat's claims in their entirety. AMSC Austria has also submitted counterclaims under the License Agreement against Ghodawat in the amount of approximately €6 million ($9 million). Ghodawat has filed a Reply to Answer to Request for Arbitration and Counterclaim in which it denies AMSC Austria's counterclaims. The arbitration proceedings are currently ongoing. The Company has recorded a loss contingency based on its assessment of probable losses on this claim; however this amount is immaterial to its consolidated financial statements.

[0001193125-12-334096:notes:21]
Other

[0001193125-12-334096:notes:22]
The Company enters into long-term construction contracts with customers that require the Company to obtain performance bonds. The Company is required to deposit an amount equivalent to some or all the face amount of the performance bonds into an escrow account until the termination of the bond. When the performance conditions are met, amounts deposited as collateral for the performance bonds are returned to the Company. In addition, the Company has various contractual arrangements in which minimum quantities of goods or services have been committed to be purchased on an annual basis.

[0001193125-12-334096:notes:23]
At June 30, 2012, the Company had $16.7 million of restricted cash included in current assets, and $4.8 million of restricted cash included in long-term assets. These amounts included in restricted cash represent deposits to secure letters of credit for various supply contracts. These deposits are held in interest bearing accounts. The Company is working with its inventory suppliers to delay cash settlements and to reduce the gross liability associated with its adverse purchase commitments. During the quarter ending June 30, 2012, the Company agreed to settle adverse purchase commitments with certain of its vendors. In conjunction with these settlements, the Company agreed to provide letters of credit and bank guarantees in the amount of approximately $9.0 million with expirations through January 31, 2013. The letters of credit and bank guarantees were secured with cash collateral of $8.5 million and resulted in a reduction of its adverse purchase commitments liability of $7.3 million recorded in the three months ended June 30, 2012.

[0001193125-12-334096:notes:24]
As of June 30, 2012, the Company had three performance bonds in support of customer contracts. The total value of the outstanding performance bonds is $3.5 million with expiration dates through March 2014. In the event that the payment is made in accordance with the requirements of any of these performance bonds, the Company would record the payment as an offset to revenue.


## us-gaap:DebtDisclosureTextBlock

[0001193125-12-334096:notes:25]
10. Debt

[0001193125-12-334096:notes:26]
Senior Convertible Notes

[0001193125-12-334096:notes:27]
On April 4, 2012, the Company entered into a Securities Purchase Agreement and completed a private placement of $25.0 million of 7% senior convertible notes with Capital Ventures International ("CVI"), an affiliate of Heights Capital Management. After fees and expenses, the net proceeds were $23.2 million. The Convertible Notes have an initial conversion price of $4.85 per share, representing a premium of approximately 20% over AMSC's closing price on April 3, 2012. The Convertible Notes are payable in monthly installments beginning four months from issuance and ending on October 4, 2014. Monthly payments are payable in cash or common stock at the option of the Company, subject to certain trading volume, stock price and other conditions. The Company registered 10,262,311 shares of common stock which may be used as payment for principal and interest in lieu of cash for resale under the Securities Act as required under a Registration Rights Agreement with CVI.

[0001193125-12-334096:notes:28]
The Company has accounted for the Convertible Notes as an instrument that has the characteristics of a debt host contract containing several embedded derivative features that would require bifurcation and separate accounting as a derivative instrument pursuant to the provisions of ASC 815. The Company elected not to use the fair value option for the payable of $25M and will record the liability at the stated value under the loan agreement on the date of issuance with no changes in fair value reported in subsequent periods.

[0001193125-12-334096:notes:29]
The Company has identified the following derivatives associated with the Convertible Notes: put rights to require the investor to acquire an additional $15.0 million convertible note and additional warrant; holder change of control redemption rights; issuer optional redemption rights; sale redemption rights and a right to make payment in the form of the stock rather than cash if certain equity conditions are met. The Company valued these derivatives at $3.8 million upon issuance and recorded the value as a debt discount and a derivative liability. See Note 11, "Warrants and Derivative Liabilities", for additional information regarding derivative liabilities.

[0001193125-12-334096:notes:30]
In addition, CVI received a warrant to purchase approximately 3.1 million additional shares of common stock exercisable at a strike price of $5.45 per share, subject to adjustment, until October 4, 2017. Due to certain adjustment provisions within the warrant, it qualified for liability accounting and had a fair value of $7.0 million upon issuance. The Company recorded the value as a debt discount and a warrant liability. See Note 11, "Warrants and Derivative Liabilities", for additional information regarding the warrant.

[0001193125-12-334096:notes:31]
The process of valuing financial and derivative instruments utilizes facts and circumstances as of the measurement date as well as certain inputs, assumptions, and judgments that may affect the estimated fair value of the instruments. Upon issuance of the Convertible Notes, the Company determined the initial carrying value of the Convertible Notes to be $25.0 million. In addition, the Company also incurred $1.8 million of legal and origination costs as of the three months ended June 30, 2012, which have been recorded as a discount on the Convertible Notes. The total debt discount, including the embedded derivatives, warrant and legal and origination costs of $12.6 million is being amortized into interest expense over the term of the Convertible Notes using the effective interest method. Under this method, interest expense is recognized each period until the debt instruments reach maturity. If the maturity of the Convertible Notes is accelerated because of prepayment, then the amortization will be accelerated. During the quarter ended June 30, 2012, the Company recorded non-cash interest expense for amortization of the debt discount related to the Convertible Notes of $2.2 million.

[0001193125-12-334096:notes:32]
The Convertible Notes contain certain covenants and restrictions, including, among others, that for so long as the Convertible Notes are outstanding, the Company will not incur any indebtedness (other than permitted indebtedness under the Convertible Notes), permit liens on its properties (other than permitted liens under the Convertible Notes), make payments on junior securities or make dividends. The Convertible Notes also contain limitations on the transfer of certain assets. Events of default under the Convertible Notes include failure to pay principal or interest as due on the Convertible Notes, failure to deliver registered shares of common stock upon the holders request for conversion of part or all of the Convertible Notes, failure to maintain the Company's common stock eligible for trading on defined markets, cross defaults to other material indebtedness, receipt of uninsured judgments against the Company in excess of defined limits and other administrative covenants, as defined in the Convertible Notes and related documentation. Upon an event of default, the holders may require the Company to redeem all or any portion of the outstanding principal amount of the Convertible Notes in cash plus a penalty as specified in the agreement. Also, if the Company fails to maintain an effective registration statement covering common stock to be used in settling obligations under the Convertible Notes, the Company will be required to pay a penalty as specified in the agreement.

[0001193125-12-334096:notes:33]
In addition, subject to certain conditions contained in the definitive agreements, on October 4, 2012, the Company may issue an additional $15 million aggregate principal amount of convertible notes and warrant to the same investor.

[0001193125-12-334096:notes:34]
Senior Secured Term Loan

[0001193125-12-334096:notes:35]
On June 5, 2012, the Company entered into a Term Loan with Hercules Technology Growth Capital ("Hercules"), under which the Company borrowed $10.0 million (the "Term Loan"). After the closing fees and expenses, the net proceeds to the Company were $9.7 million. The Term Loan bears an interest rate equal to 11% plus the percentage, if any, in which the prime rate as reported by The Wall Street Journal exceeds 3.75%. The Company will make interest only payments beginning July 1, 2012 and continuing through October 1, 2012, after which the Company will repay the loan in equal monthly installments ending on December 1, 2014. The Term Loan is secured by substantially all of the Company's existing and future assets. In addition, Hercules received a warrant to purchase approximately 139,000 shares of common stock, exercisable at an initial strike price of $3.59 per share, subject to adjustment, until December 5, 2017. Due to certain adjustment provisions within the warrant, it qualified for liability accounting and the fair value of $0.4 million was recorded upon issuance, which the Company recorded as a debt discount and a warrant liability. See Note 11, "Warrants and Derivative Liabilities", for a discussion on warrants and the valuation assumptions used. The Company will pay an end of term fee of $0.5 million upon the earlier of maturity or prepayment of the loan. The Company has accrued this as of the three months ended June 30, 2012 and recorded a corresponding amount into the debt discount. In addition, the Company incurred $0.3 million of legal and origination costs in the three months ended June 30, 2012, which have been recorded as a debt discount. The total debt discount including the warrant, end of term fee and legal and origination costs of $1.2 million is being amortized into interest expense over the term of the Term Loan using the effective interest method. Under this method, interest expense is recognized each period until the debt instrument reaches maturity. If the maturity of the Term Loan is accelerated because of prepayment, then the amortization will be accelerated. During the quarter ended June 30, 2012, the Company recorded non-cash interest expense for amortization of the debt discount related to the Term Loan of $0.1 million.

[0001193125-12-334096:notes:36]
The Term Loan contains certain covenants that restrict the Company's ability to, among other things, incur or assume certain debt, merge or consolidate, materially change the nature of our business, make certain investments, acquire or dispose of certain assets, make guaranties or grant liens on its assets, make certain loans, advances or investments, declare dividends or make distributions or enter into transactions with affiliates. In addition, the Term Loan contains a covenant which requirements the Company to maintain a minimum unrestricted cash balance in the United States of at least $10.0 million at the inception of the Term Loan, which will decrease starting November 1, 2012 and monthly thereafter by the amount of principal paid. The events of default under the Term Loan include, but are not limited to, failure to pay amounts due, breaches of covenants, bankruptcy events, cross defaults under other material indebtedness and the occurrence of a material adverse effect and/or change in control. In the case of a continuing event of default, the Lender may, among other remedies, declare due all unpaid principal amounts outstanding and any accrued but unpaid interest and foreclose on all collateral granted to the Lender as security under the Term Loan.

[0001193125-12-334096:notes:37]
Although the Company is in compliance with the covenants and restrictions under the Convertible Notes and Term Loan as of the date of this Interim Report on Form 10-Q, there can no assurance that the Company will be in compliance.

[0001193125-12-334096:notes:38]
Interest expense on the Convertible Notes and Term Loan for the three month period ended June 30, 2012 was $2.8 million, which included non-cash interest expense related to the amortization of the debt discount on the Convertible Notes and Term Loan for the three months ended June 30, 2012 of $2.3 million.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001193125-12-334096:notes:39]
11. Warrants and Derivative Liabilities

[0001193125-12-334096:notes:40]
On April 4, 2012, the Company entered into a Securities Purchase Agreement as described in Note 10, which included a warrant to purchase 3.1 million shares of the Company's common stock. The warrant is exercisable at any time on or after the date that is six months after the issuance of the warrant and entitles CVI to purchase shares of the Company's common stock for a period of five years from the initial date the warrant becomes exercisable at a price equal to $5.45 per share, subject to certain price-based and other anti-dilution adjustments. The warrant may not be exercised if, after giving effect to the conversion, CVI together with its affiliates would beneficially own in excess of 4.99% of the Company's common stock. This percentage may be raised to any other percentage not in excess of 9.99% at the option of the holder of the warrant, upon at least 61-days' prior notice to the Company, or lowered to any other percentage, at the option of CVI, at any time.

[0001193125-12-334096:notes:41]
The Company accounts for the warrant as a liability due to certain adjustment provisions within the warrant, which requires that it be recorded at fair value. The warrant is subject to revaluation at each balance sheet date and any change in fair value will be recorded as a change in fair value in other income (expense) until the earlier of expiration or its exercise at which time the warrant liability will be reclassified to equity. The Company used the Black-Scholes option pricing model to calculate the fair value of the warrant, using the following assumptions:

[0001193125-12-334096:notes:42]
|  | April 4, |  | June 30, |  |
|  | 2012 |  | 2012 |  |
| Risk-free interest rate | 1.19 | % | 0.77 | % |
| Expected annual dividend yield | 0.0 | % | 0.0 | % |
| Expected volatility | 80.0 | % | 80.84 | % |
| Term | 5.5 years |  | 5.28 years |  |
| Fair Value | $7.0 million |  | $8.5 million |  |

[0001193125-12-334096:notes:43]
The Company recorded the change in the fair value of the CVI warrant of $1.5 million to change in fair value of derivatives and warrants in the three months ended June 30, 2012.

[0001193125-12-334096:notes:44]
The Company determined certain embedded derivatives issued with the Convertible Notes required accounting as a liability, which requires they be accounted for as a standalone liability subject to revaluation at each balance sheet date with changes in fair value recorded as change in fair value of derivatives and warrants until the earlier of exercise or expiration.

[0001193125-12-334096:notes:45]
The Company calculated the fair value of the derivative liabilities bifurcated from the Convertible Notes (see Note 10, "Debt") utilizing an integrated lattice model. The lattice model is an option pricing model that involves the construction of a binomial tree to show the different paths that the underlying asset may take over the option's life. A lattice model can take into account expected changes in various parameters such as volatility over the life of the options, providing more accurate estimates of option prices than the Black-Scholes model. Following is a summary of the key assumptions used to value the convertible note derivative feature:

[0001193125-12-334096:notes:46]
|  | April 4, |  | June 30, |  |
|  | 2012 |  | 2012 |  |
| Expected Volatility | 75.0 | % | 71.0 | % |
| Risk Free Rate | 0.44 | % | 0.33 | % |
| Bond Yield | 15.0 | % | 16.0 | % |
| Recovery Rate | 30.0 | % | 30.0 | % |
| Redeemable | yes |  | yes |  |
| Total Time (years) | 2.5 |  | 2.28 |  |
| Dilution Effect | yes |  | yes |  |
| Indicated Percent of Par | 117.0 | % | 121.0 | % |
| Fair Value | $3.7 million |  | $4.5 million |  |

[0001193125-12-334096:notes:47]
The expected volatility rate was estimated based on an equal weighting of the historical volatility of the Company's common stock and the implied volatility of the Company's traded options. To determine the risk-free interest rate an interpolated rate was used based on the two and three year United States Treasury rates. The bond yield was estimated by comparing comparable corporate debt and yield information. The recovery rate of the Convertible Note was estimated by reviewing historical corporate debt that went into default. The bond is redeemable by the Company at any point after the one-year anniversary of the grant date provided certain provisions within the note. The total time is based on the actual contractual terms, 30 months. It was determined that there is a dilution effect based on the Company's ability to make payments in shares of common stock.

[0001193125-12-334096:notes:48]
The Company recorded the change in the fair value of the derivative liabilities of $0.8 million to changes in fair value of derivatives and warrants in the three months ended June 30, 2012.

[0001193125-12-334096:notes:49]
On June 5, 2012, the Company entered into a Loan and Security Agreement with Hercules (see Note 10, "Debt", for additional information regarding the Loan and Security Agreement). In conjunction with this agreement, the Company issued a warrant to purchase approximately 139,000 shares of the Company's common stock. The warrant is exercisable at any time after the issuance of the warrant and entitles Hercules to purchase shares of the Company's common stock for a period of five and half years from the initial date the warrant becomes exercisable at a price equal to $3.59 per share subject to certain price-based and other anti-dilution adjustments.

[0001193125-12-334096:notes:50]
The Company accounts for the warrant as a liability due to certain provisions within the warrant, which requires that it be recorded at fair value. The warrant is subject to revaluation at each balance sheet date and any change in fair value will be recorded as changes in fair value of derivatives and warrant until the earlier of expiration or its exercise at which time the warrant liability will be reclassified to equity. The Company calculated the fair value of the warrant using the Black-Scholes option pricing model to value the warrant, using the following assumptions:

[0001193125-12-334096:notes:51]
|  | June 5, |  | June 30, |  |
|  | 2012 |  | 2012 |  |
| Risk-free interest rate | 0.77 | % | 0.80 | % |
| Expected annual dividend yield | 0.0 | % | 0.0 | % |
| Expected volatility | 79.9 | % | 80.32 | % |

[0001193125-12-334096:notes:52]
|  | June 5, | June 30, |
|  | 2012 | 2012 |
| Term | 5.5 years | 5.44 years |
| Fair Value | $0.4 million | $0.5 million |

[0001193125-12-334096:notes:53]
The company prepared their estimates for the assumptions used to determine the fair value of the warrants issued in conjunction with both the Convertible Note and Term Loan utilizing the respective terms of the warrants with similar inputs under the Black Scholes valuation method more fully described in Note 2.

[0001193125-12-334096:notes:54]
The company recorded the change in the fair value of the Hercules warrant of $0.1 million to changes in fair value of derivatives and warrants in the three months ended June 30, 2012.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001193125-12-334096:notes:55]
[same as prior period, unchanged from 0001193125-12-048929:notes:32]

[0001193125-12-334096:notes:56]
The Company accounts for its stock-based compensation at fair value. The following table summarizes stock-based compensation expense by financial statement line item for the three months ended June 30, 2012 and 2011 (in thousands):

[0001193125-12-334096:notes:57]
|  |  | Three months ended |
|  |  | June 30, |
|  |  | 2012 |  | 2011 |
| Cost of revenues | $ | 170 | $ | 329 |
| Research and development |  | 562 |  | 660 |
| Selling, general and administrative |  | 1,262 |  | 2,477 |
| Total | $ | 1,994 | $ | 3,466 |

[0001193125-12-334096:notes:58]
During the three months ended June 30, 2012, the Company granted approximately 427,000 stock options and issued 214,886 shares of common stock in-lieu of cash bonuses, which vested immediately, to employees under the 2007 Stock Incentive Plan. The Company recorded the issuance of stock in-lieu of bonuses as a non-cash issuance of stock to settle liabilities in the unaudited consolidated condensed statement of cash flows. The options granted vest upon the passage of time, generally 3 years. For awards that vest upon the passage of time, expense is being recorded over the vesting period.

[0001193125-12-334096:notes:59]
The estimated fair value of the Company's stock-based awards, less expected annual forfeitures, is amortized over the awards' service period. The total unrecognized compensation cost for unvested outstanding stock options was $6.9 million for the three months ended June 30, 2012. This expense will be recognized over a weighted average expense period of approximately 2.4 years. The total unrecognized compensation cost for unvested outstanding restricted stock was $4.2 million for the three months ended June 30, 2012. This expense will be recognized over a weighted average expense period of approximately 1.6 years.

[0001193125-12-334096:notes:60]
The weighted-average assumptions used in the Black-Scholes valuation model for stock options granted during the three months ended June 30, 2012 and 2011 are as follows:

[0001193125-12-334096:notes:61]
|  | Three months ended |
|  | June 30, |
|  | 2012 | 2011 |
| Expected volatility | 72.0 | % | 67.5 | % |
| Risk-free interest rate | 0.9 | % | 1.9 | % |
| Expected life (years) | 5.9 |  | 5.9 |  |
| Dividend yield | None |  | None |  |

[0001193125-12-334096:notes:62]
The expected volatility rate was estimated based on an equal weighting of the historical volatility of the Company's common stock and the implied volatility of the Company's traded options. The expected term was estimated based on an analysis of the Company's historical experience of exercise, cancellation, and expiration patterns. The risk-free interest rate is based on the average of the five and seven year United States Treasury rates.


## us-gaap:EarningsPerShareTextBlock

[0001193125-12-334096:notes:63]
[same as prior period, unchanged from 0001193125-12-048929:notes:39]

[0001193125-12-334096:notes:64]
Basic net (loss) income per share ("EPS") is computed by dividing net (loss) income by the weighted-average number of common shares outstanding for the period. Where applicable, diluted EPS is computed by dividing the net (loss) income by the weighted-average number of common shares and dilutive common equivalent shares outstanding during the period, calculated using the treasury stock method. Common equivalent shares include the effect of restricted stock, exercise of stock options and warrants and contingently issuable shares. For the three months ended June 30, 2012, 6.3 million shares were not included in the calculation of diluted EPS as they were considered anti-dilutive, of which 3.1 million relate to unvested stock options and 3.2 million relate to the issuance of warrants. For the three months ended June 30, 2011, 3.0 million shares of unvested stock options were not included in the calculation of diluted EPS as they were considered anti-dilutive.

[0001193125-12-334096:notes:65]
The following table reconciles the numerators and denominators of the earnings per share calculation for the three months ended June 30, 2012 and 2011 (in thousands, except per share data):

[0001193125-12-334096:notes:66]
|  |  | Three months ended June 30, |  |
|  |  | 2012 |  |  | 2011 |  |
| Numerator: |  |  |  |  |  |  |
| Net loss | $ | (10,275 | ) | $ | (37,679 | ) |
| Denominator: |  |  |  |  |  |  |
| Weighted-average shares of common stock outstanding |  | 51,997 |  |  | 51,172 |  |
| Weighted-average shares subject to repurchase |  | (806 | ) |  | (463 | ) |
| Shares used in per-share calculation basic |  | 51,191 |  |  | 50,709 |  |
| Shares used in per-share calculation diluted |  | 51,191 |  |  | 50,709 |  |
| Net loss per share basic | $ | (0.20 | ) | $ | (0.74 | ) |
| Net loss per share diluted | $ | (0.20 | ) | $ | (0.74 | ) |


## us-gaap:EquityMethodInvestmentsDisclosureTextBlock

[0001193125-12-334096:notes:67]
13. Equity Investments

[0001193125-12-334096:notes:68]
[same as prior period, unchanged from 0001193125-12-048929:notes:43]

[0001193125-12-334096:notes:69]
On October 9, 2009, the Company made an investment in Tres Amigas LLC, a Delaware limited liability company ("Tres Amigas"), focused on providing the first common interconnection of America's three power grids to help the country achieve its renewable energy goals and facilitate the smooth, reliable and efficient transfer of green power from region to region, for $1.8 million, consisting of $0.8 million in cash and $1.0 million in AMSC common stock. On January 6, 2011 and May 20, 2011, the Company increased its minority position in Tres Amigas by investing an additional $1.8 million in cash on each date. As of June 30, 2012, the Company holds a 26% ownership interest in Tres Amigas.

[0001193125-12-334096:notes:70]
The Company's investment in Tres Amigas is included in other assets on the consolidated balance sheet and the equity in undistributed losses of Tres Amigas is included in other income, net, on the consolidated statements of operations.

[0001193125-12-334096:notes:71]
The net investment activity for the three months ended June 30, 2012 is as follows (in thousands):

[0001193125-12-334096:notes:72]
| Balance at April 1, 2012 | $ | 3,859 |  |
| Minority interest in net losses |  | (227 | ) |
| Balance at June 30, 2012 | $ | 3,632 |  |

[0001193125-12-334096:notes:73]
[same as prior period, unchanged from 0001193125-12-048929:notes:48]

[0001193125-12-334096:notes:74]
On August 12, 2010, the Company acquired (through its Austrian subsidiary), a minority ownership position in Blade Dynamics Ltd. ("Blade Dynamics"), a designer and manufacturer of advanced wind turbine blades based on proprietary materials and structural technologies, for $8.0 million in cash. As of June 30, 2012, the Company holds a 25% ownership interest in Blade Dynamics.

[0001193125-12-334096:notes:75]
The Company has determined that Blade Dynamics is a variable interest entity ("VIE") and that the Company is not the primary beneficiary of the VIE. Therefore, the Company has not consolidated Blade Dynamics as of June 30, 2012. The investment is carried at the acquisition cost, plus the Company's equity in undistributed earnings or losses. The Company's maximum exposure to loss is limited to the Company's recorded investment in this VIE. The Company's investment in Blade Dynamics is included in other assets on the consolidated balance sheet and the equity in undistributed losses of Blade Dynamics is included in other income, net, on the consolidated statements of operations.

[0001193125-12-334096:notes:76]
| Balance at April 1, 2012 | $ | 6,083 |  |
| Minority interest in net losses |  | (584 | ) |
| Net foreign exchange rate impact |  | (350 | ) |
| Balance at June 30, 2012 | $ | 5,149 |  |


## us-gaap:FairValueAssetsAndLiabilitiesMeasuredOnRecurringBasisGainLossIncludedInEarningsTextBlock

[0001193125-12-334096:notes:77]
|  |  | Total |  | Quoted Prices in |  | Significant Other |  | Significant |
|  |  | Carrying |  | Active Markets |  | Observable Inputs |  | Unobservable Inputs |
|  |  | Value |  | (Level 1) |  | (Level 2) |  | (Level 3) |
| June 30, 2012: |  |  |  |  |  |  |  |  |
| Assets: |  |  |  |  |  |  |  |  |
| Cash equivalents | $ | 40,387 | $ | 40,387 | $ | — | $ | — |
| Short-term commercial paper |  | 5,209 |  | — |  | 5,209 |  | — |
| Liabilities: |  |  |  |  |  |  |  |  |
| Derivative liability | $ | 4,536 | $ | — | $ | — | $ | 4,536 |
| Warrants |  | 9,029 |  | — |  | — |  | 9,029 |

[0001193125-12-334096:notes:78]
|  |  | Total |  | Quoted Prices in |  | Using Significant Other |  | Using Significant |
|  |  | Carrying |  | Active Markets |  | Observable Inputs |  | Unobservable Inputs |
|  |  | Value |  | (Level 1) |  | (Level 2) |  | (Level 3) |
| March 31, 2012: |  |  |  |  |  |  |  |  |
| Assets: |  |  |  |  |  |  |  |  |
| Cash equivalents | $ | 23,485 | $ | 23,485 | $ | — | $ | — |
| Short-term commercial paper |  | 5,304 |  | — |  | 5,304 |  | — |


## us-gaap:FairValueDisclosuresTextBlock

[0001193125-12-334096:notes:79]
[same as prior period, unchanged from 0001193125-12-048929:notes:53]

[0001193125-12-334096:notes:80]
In January 2010, the Financial Accounting Standards Board ("FASB") issued guidance related to disclosures of fair value measurements. The guidance requires gross presentation of activity within the Level 3 measurement roll-forward and details of transfers in and out of Level 1 and 2 measurements. It also clarifies two existing disclosure requirements on the level of disaggregation of fair value measurements and disclosures on inputs and valuation techniques. A change in the hierarchy of an investment from its current level will be reflected in the period during which the pricing methodology of such investment changes. Disclosure of the transfer of securities from Level 1 to Level 2 or Level 3 will be made in the event that the related security is significant to total cash and investments. The Company did not have any transfers of assets and liabilities between Level 1, Level 2 and Level 3 of the fair value measurement hierarchy during the three months ended June 30, 2012.

[0001193125-12-334096:notes:81]
[same as prior period, unchanged from 0001193125-12-048929:notes:54]

[0001193125-12-334096:notes:82]
[same as prior period, unchanged from 0001193125-12-048929:notes:55]

[0001193125-12-334096:notes:83]
[same as prior period, unchanged from 0001193125-12-048929:notes:56]

[0001193125-12-334096:notes:84]
[same as prior period, unchanged from 0001193125-12-048929:notes:57]

[0001193125-12-334096:notes:85]
[same as prior period, unchanged from 0001193125-12-048929:notes:58]

[0001193125-12-334096:notes:86]
The following table provides the assets carried at fair value, measured as of June 30, 2012 and March 31, 2012 (in thousands):

[0001193125-12-334096:notes:87]
The table below reflects the activity for the Company's major classes of liabilities measured at fair value for the period ended June 30, 2012 (in thousands).

[0001193125-12-334096:notes:88]
[same as prior period, unchanged from 0001193125-12-048929:notes:61]

[0001193125-12-334096:notes:89]
[same as prior period, unchanged from 0001193125-12-048929:notes:62]

[0001193125-12-334096:notes:90]
[same as prior period, unchanged from 0001193125-12-048929:notes:63]

[0001193125-12-334096:notes:91]
[same as prior period, unchanged from 0001193125-12-048929:notes:64]

[0001193125-12-334096:notes:92]
[same as prior period, unchanged from 0001193125-12-048929:notes:65]

[0001193125-12-334096:notes:93]
Derivative Liability

[0001193125-12-334096:notes:94]
The Company has identified all of the derivatives ("Derivative Liability") associated with the Convertible Notes which include put rights to require the investor to acquire an additional $15.0 million convertible note and additional warrants, holder change of control redemption rights, issuer optional redemption rights, sale redemption rights and a right to make payment in the form of stock rather than cash if certain equity conditions are met. The Derivative Liability is subject to revaluation at each balance sheet date, and any change in fair value will be recorded as a change in fair value in other income (expense) until the earlier of its exercise or expiration. The Company relies on assumptions in a lattice model to determine the fair value of Derivative Liability. The Company has appropriately valued the Derivative Liability within Level 3 of the valuation hierarchy. See Note 10, "Debt", for discussion on the Convertible Notes, Derivative Liability and valuation assumptions used.

[0001193125-12-334096:notes:95]
Warrants

[0001193125-12-334096:notes:96]
Warrants were issued in conjunction with the Convertible Notes and the Term Loan. See Note 10, "Debt", for additional information on warrants. These warrants are subject to revaluation at each balance sheet date, and any change in fair value will be recorded as a change in fair value in other income (expense) until the earlier of their exercise or expiration.

[0001193125-12-334096:notes:97]
The Company relies on assumptions used in a Black-Scholes model to determine the fair value of warrants. The Company has appropriately valued the warrants within Level 3 of the valuation hierarchy. See Note 11, "Warrants and Derivative Liabilities", for a discussion of the warrants and the valuation assumptions used.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001193125-12-334096:notes:98]
[same as prior period, unchanged from 0001193125-12-048929:notes:68]

[0001193125-12-334096:notes:99]
For the three months ended June 30, 2012 and 2011, the Company recorded an income tax benefit of $0.8 million and income tax expense of $0.2 million, respectively. The income tax benefit for the three months ended June 30, 2012, was primarily due to a refund of Chinese income taxes of $0.9 million. The Company has provided a valuation allowance against all deferred tax assets as of June 30, 2012, as it is more likely than not that its deferred tax assets are not currently realizable due to the net operating losses incurred by the Company since its inception.


## us-gaap:InventoryDisclosureTextBlock

[0001193125-12-334096:notes:100]
[same as prior period, unchanged from 0001193125-12-048929:notes:71]

[0001193125-12-334096:notes:101]
The components of inventory at June 30, 2012 and March 31, 2012 are as follows (in thousands):

[0001193125-12-334096:notes:102]
|  |  | June 30, |  | March 31, |
|  |  | 2012 |  | 2012 |
| Raw materials | $ | 10,117 | $ | 9,962 |
| Work-in-process |  | 3,749 |  | 2,390 |
| Finished goods |  | 12,893 |  | 14,438 |
| Deferred program costs |  | 1,940 |  | 2,466 |
| Net inventory | $ | 28,699 | $ | 29,256 |

[0001193125-12-334096:notes:103]
For the three months ended June 30, 2012, the Company recorded an inventory write-down of approximately $0.3 million based on evaluating its ending inventory on hand for excess quantities and obsolescence.

[0001193125-12-334096:notes:104]
Deferred program costs as of June 30, 2012 and March 31 2012 primarily represent costs incurred on D-VAR turnkey projects and programs accounted for under contract accounting where the Company needs to complete development programs before revenue and costs will be recognized, respectively.


## us-gaap:LoansNotesTradeAndOtherReceivablesDisclosureTextBlock

[0001193125-12-334096:notes:105]
5. Accounts Receivable

[0001193125-12-334096:notes:106]
Accounts receivable at June 30, 2012 and March 31, 2012 consisted of the following (in thousands):

[0001193125-12-334096:notes:107]
|  |  | June 30, |  |  | March 31, |  |
|  |  | 2012 |  |  | 2012 |  |
| Accounts receivable (billed) | $ | 11,442 |  | $ | 16,240 |  |
| Accounts receivable (unbilled) |  | 2,168 |  |  | 2,811 |  |
| Less: Allowance for doubtful accounts |  | (52 | ) |  | (52 | ) |
| Accounts receivable, net | $ | 13,558 |  | $ | 18,999 |  |


## us-gaap:NewAccountingPronouncementsAndChangesInAccountingPrinciplesTextBlock

[0001193125-12-334096:notes:108]
15. Recent Accounting Pronouncements

[0001193125-12-334096:notes:109]
In June 2011, the FASB issued Accounting Standards Update (ASU) No. 2011-05, Comprehensive Income (Topic 220): Presentation of Comprehensive Income. ASU 2011-05 requires entities to present net income and other comprehensive income in either a single continuous statement or in two separate, but consecutive, statements of net income and other comprehensive income. ASU 2011-05 is effective for fiscal years and interim periods beginning after December 15, 2011. The Company early adopted ASU 2011-05 and it did not have a material impact on the Company's consolidated results of operations, financial condition, or cash flows.

[0001193125-12-334096:notes:110]
In September 2011, the FASB issued Accounting Standards Update No. 2011-08, Intangibles — Goodwill and Other (Topic 350). ASU 2011-08 allows entities to first assess qualitatively whether it is necessary to perform the two-step goodwill impairment test. If an entity believes, as a result of its qualitative assessment, that it is more likely than not that the fair value of a reporting unit is less than its carrying amount, the quantitative two-step goodwill impairment test is required. An entity has the unconditional option to bypass the qualitative assessment and proceed directly to performing the first step of the goodwill impairment test. ASU 2011-08 is effective for our first quarter of fiscal 2013 but is eligible for early adoption. The Company does not believe adoption of this standard will have an impact on its consolidated results of operations, financial condition, or cash flows.

[0001193125-12-334096:notes:111]
In December 2011, the FASB issued Accounting Standards Update No. 2011-11, Balance Sheet (Topic 210)-Disclosures about Offsetting Assets and Liabilities (ASU 2011-11). The update requires entities to disclose information about offsetting and related arrangements of financial instruments and derivative instruments. ASU 2011-11 is effective for our first quarter of fiscal 2014. The Company is currently evaluating the impact of adopting ASU 2011-11, but currently does not believe there will be a significant impact on its consolidated results of operations, financial condition, or cash flows.

[0001193125-12-334096:notes:112]
The Company does not believe that other recently issued accounting pronouncements will have a material impact on its financial statements.


## us-gaap:ProductWarrantyDisclosureTextBlock

[0001193125-12-334096:notes:113]
[same as prior period, unchanged from 0001193125-12-048929:notes:86]

[0001193125-12-334096:notes:114]
The Company generally provides a one to three year warranty on its products, commencing upon installation. A provision is recorded upon revenue recognition to cost of revenues for estimated warranty expense based on historical experience.

[0001193125-12-334096:notes:115]
[same as prior period, unchanged from 0001193125-12-048929:notes:88]

[0001193125-12-334096:notes:116]
|  |  | Three months ended |  |
|  |  | June 30, |  |
|  |  | 2012 |  |  | 2011 |  |
| Balance at beginning of period | $ | 5,896 |  | $ | 7,907 |  |
| Accruals for warranties during the period |  | (167 | ) |  | (405 | ) |
| Settlements during the period |  | (229 | ) |  | (168 | ) |
| Balance at end of period | $ | 5,500 |  | $ | 7,334 |  |


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001193125-12-334096:notes:117]
9. Restructuring

[0001193125-12-334096:notes:118]
The Company accounts for charges resulting from operational restructuring actions in accordance with ASC Topic 420, Exit or Disposal Cost Obligations ("ASC 420") and ASC Topic 712, Compensation—Nonretirement Postemployment Benefits ("ASC 712"). In accounting for these obligations, the Company is required to make assumptions related to the amounts of employee severance, benefits, and related costs and the time period over which leased facilities will remain vacant, sublease terms, sublease rates and discount rates. Estimates and assumptions are based on the best information available at the time the obligation arises. These estimates are reviewed and revised as facts and circumstances dictate; changes in these estimates could have a material effect on the amount accrued on the consolidated balance sheet.

[0001193125-12-334096:notes:119]
During the year ended March 31, 2012, the Company initiated restructuring activities in order to reorganize global operations, streamline various functions of the business, and reduce its global workforce to better reflect the demand for its products. These activities resulted in the reduction of its global workforce by approximately 50%. During the three months ended June 30, 2012, the Company incurred restructuring costs of $0.1 million. These additional charges were paid as of June 30, 2012 and the remaining balance of accrued restructuring is expected to be paid through March 2013.

[0001193125-12-334096:notes:120]
The following table presents restructuring charges and cash payments (in thousands):

[0001193125-12-334096:notes:121]
|  |  | Severance pay |  |  | Facility |  |  |  |  |
|  |  | and benefits |  |  | exit costs |  |  | Total |  |
| Accrued restructuring balance at April 1, 2012 | $ | 680 |  | $ | 294 |  | $ | 974 |  |
| Charges to operations |  | 167 |  |  | (39 | ) |  | 128 |  |
| Cash payments |  | (269 | ) |  | (255 | ) |  | (524 | ) |
| Accrued restructuring balance at June 30, 2012 | $ | 578 |  | $ | - |  | $ | 578 |  |

[0001193125-12-334096:notes:122]
All restructuring charges discussed above are included within restructuring and impairments in the Company's unaudited condensed consolidated statements of operations. The Company includes accrued restructuring within accounts payable and accrued expenses in the unaudited condensed consolidated balance sheets.


## us-gaap:ScheduleOfRevenueByMajorCustomersByReportingSegmentsTableTextBlock

[0001193125-12-334096:notes:123]
|  | Three months ended |
|  | June 30, |
|  | 2012 | 2011 |
| Beijing JINGCHENG New Energy Co., Ltd. | 19 | % | - |  |
| Karara Mining Ltd. | 15 | % | - |  |
| INOX Wind Limited. | 15 | % | - |  |
| Department of Energy | - |  | 17 | % |
| Doosan Heavy Industries & Construction Co Ltd. | - |  | 15 | % |
| Shenyang Blower Works Group Wind Power Co.,Ltd. | - |  | 13 | % |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001193125-12-334096:notes:124]
14. Business Segments

[0001193125-12-334096:notes:125]
The Company reported its financial results in two reportable business segments: Wind and Grid.

[0001193125-12-334096:notes:126]
Through its Windtec Solutions, the Wind business segment enables manufacturers to field wind turbines with exceptional power output, reliability and affordability. The Company licenses its highly engineered wind turbine designs, provides extensive customer support services and supplies advanced power electronics and control systems to wind turbine manufactures. Its design portfolio includes a broad range of drive trains and power ratings up to 10 megawatts. The Company believes its advanced engineering capabilities, ranging from bearings to advanced synchronous generators to blades, enables it to provide its partners with highly-optimized wind turbine platforms. Furthermore, these designs and support services typically lead to sales of its power electronics and software-based control systems, which are designed for optimized performance, efficiency and grid compatibility.

[0001193125-12-334096:notes:127]
Through its Gridtec Solutions, the Grid business segment enables electric utilities and renewable energy project developers to connect, transmit and distribute power with exceptional efficiency, reliability and affordability. The Company provides transmission planning services that allow it to identify power grid congestion, poor power quality and other risks, which help the Company determine how its solutions can improve network performance. These services often lead to sales of grid interconnection solutions for wind farms and solar power plants, power quality systems and transmission and distribution cable systems.

[0001193125-12-334096:notes:128]
[same as prior period, unchanged from 0001193125-12-048929:notes:115]

[0001193125-12-334096:notes:129]
The accounting policies of the business segments are the same as those for the consolidated Company. The Company's business segments have been determined in accordance with the Company's internal management structure, which is organized based on operating activities. The Company evaluates performance based upon several factors, of which the primary financial measures are segment revenues and segment operating (loss) income. The disaggregated financial results of the segments reflect allocation of certain functional expense categories consistent with the basis and manner in which Company management internally disaggregates financial information for the purpose of assisting in making internal operating decisions. In addition, certain corporate expenses which the Company does not believe are specifically attributable or allocable to either of the two business segments have been excluded from the segment operating income.

[0001193125-12-334096:notes:130]
Unallocated corporate expenses primarily consist of stock-based compensation expense of $2.0 million and $3.5 million for the three months ended June 30, 2012 and 2011, respectively.

[0001193125-12-334096:notes:131]
[same as prior period, unchanged from 0001193125-12-048929:notes:119]

[0001193125-12-334096:notes:132]
The following table sets forth customers who represented 10% or more of the Company's total revenues for the three months ended June 30, 2012 and 2011:


## us-gaap:SubsequentEventsTextBlock

[0001193125-12-334096:notes:133]
16. Subsequent Events

[0001193125-12-334096:notes:134]
The Company has evaluated all subsequent events through the time of filing this Quarterly Report on Form 10-Q with the SEC, per the requirements of ASC Topic 855 and has determined that there are no events to report.
