# AMSC notes — 0001628280-18-013770


## us-gaap:AccountsPayableAndAccruedLiabilitiesDisclosureTextBlock

[0001628280-18-013770:notes:1]
[same as prior period, unchanged from 0001628280-18-009847:notes:1]

[0001628280-18-013770:notes:2]
Accounts payable and accrued expenses at September 30, 2018 and March 31, 2018 consisted of the following (in thousands):

[0001628280-18-013770:notes:3]
|  | September 30, 2018 |  | March 31, 2018 |
| Accounts payable | $ | 3,934 |  |  | $ | 3,096 |  |
| Accrued inventories in-transit | 411 |  |  | 1,207 |  |
| Accrued other miscellaneous expenses | 2,836 |  |  | 2,412 |  |
| Advanced deposits | 890 |  |  | — |  |
| Accrued compensation | 3,424 |  |  | 3,605 |  |
| Income taxes payable | 2,049 |  |  | 536 |  |
| Accrued warranty | 1,760 |  |  | 1,769 |  |
| Total | $ | 15,304 |  |  | $ | 12,625 |  |

[0001628280-18-013770:notes:4]
[same as prior period, unchanged from 0001628280-18-009847:notes:4]

[0001628280-18-013770:notes:5]
[same as prior period, unchanged from 0001628280-18-009847:notes:5]

[0001628280-18-013770:notes:6]
|  | Three months ended September 30, |  | Six months ended September 30, |
|  | 2018 |  | 2017 |  | 2018 |  | 2017 |
| Balance at beginning of period | $ | 1,752 |  |  | $ | 2,026 |  |  | $ | 1,769 |  |  | $ | 2,344 |  |
| Change in accruals for warranties during the period | 213 |  |  | 86 |  |  | 317 |  |  | 127 |  |
| Settlements during the period | (205 | ) |  | (260 | ) |  | (326 | ) |  | (619 | ) |
| Balance at end of period | $ | 1,760 |  |  | $ | 1,852 |  |  | $ | 1,760 |  |  | $ | 1,852 |  |


## us-gaap:BasisOfAccountingPolicyPolicyTextBlock

[0001628280-18-013770:notes:7]
These unaudited condensed consolidated financial statements of the Company have been prepared on a going concern basis in accordance with United States generally accepted accounting principles (“GAAP”) and the Securities and Exchange Commission’s (“SEC”) instructions to Form 10-Q. The going concern basis of presentation assumes that the Company will continue operations and will be able to realize its assets and discharge its liabilities and commitments in the normal course of business. Certain information and footnote disclosures normally included in the financial statements prepared in accordance with GAAP have been condensed or omitted pursuant to those instructions. The year-end condensed balance sheet data was derived from audited financial statements but does not include all disclosures required by GAAP. The unaudited condensed consolidated financial statements, in the opinion of management, reflect all adjustments (consisting of normal recurring adjustments) necessary for a fair statement of the results for the interim periods ended September 30, 2018 and 2017 and the financial position at September 30, 2018; however, these results are not necessarily indicative of results which may be expected for the full year. The interim condensed consolidated financial statements, and notes thereto, should be read in conjunction with the audited consolidated financial statements for the year ended March 31, 2018, and notes thereto, included in the Company’s annual report on Form 10-K for the year ended March 31, 2018 filed with the Securities and Exchange Commission on June 6, 2018.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001628280-18-013770:notes:8]
[same as prior period, unchanged from 0001628280-18-009847:notes:8]

[0001628280-18-013770:notes:9]
[same as prior period, unchanged from 0001628280-18-009847:notes:9]

[0001628280-18-013770:notes:10]
[same as prior period, unchanged from 0001628280-18-009847:notes:10]

[0001628280-18-013770:notes:11]
The results of ITC's operations, which were not significant from the date of acquisition until September 30, 2018, are included in the Company’s consolidated results from the date of Acquisition of September 25, 2017, through September 30, 2018. Assuming the Acquisition had occurred on April 1, 2017, the impact on the consolidated results of the Company would not have been significant.

[0001628280-18-013770:notes:12]
[same as prior period, unchanged from 0001628280-18-009847:notes:12]

[0001628280-18-013770:notes:13]
[same as prior period, unchanged from 0001628280-18-009847:notes:13]

[0001628280-18-013770:notes:14]
The Company did not identify any triggering events in the six months ended September 30, 2018, that would require interim impairment testing of goodwill.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001628280-18-013770:notes:15]
Commitments and Contingencies

[0001628280-18-013770:notes:16]
Legal Contingencies

[0001628280-18-013770:notes:17]
From time to time, the Company is involved in legal and administrative proceedings and claims of various types. The Company records a liability in its consolidated financial statements for these matters when a loss is known or considered probable and the amount can be reasonably estimated. The Company reviews these estimates each accounting period as additional information is known and adjusts the loss provision when appropriate. If a matter is both probable to result in a liability and the amounts of loss can be reasonably estimated, the Company estimates and discloses the possible loss or range of loss to the extent necessary to make the consolidated financial statements not misleading. If the loss is not probable or cannot be reasonably estimated, a liability is not recorded in its consolidated financial statements.

[0001628280-18-013770:notes:18]
On July 3, 2018, the Company, AMSC China and AMSC Austria entered into the Settlement Agreement with Sinovel. The Settlement Agreement settles the litigation and arbitration proceedings between the Company and Sinovel listed on Schedule 2 of the Settlement Agreement (the “Proceedings”), and any other civil claims, counterclaims, causes of action, rights and obligations directly or indirectly relating to the subject matters of the Proceedings and the contracts between the Company and Sinovel listed on Schedules 1 and 4 of the Settlement Agreement (the “Contracts”), subject to the exception described in Section 1.1 of the Settlement Agreement.  The Settlement Agreement was filed as Exhibit 10.1 to the Company’s Form 8-K filed with the Securities and Exchange Commission on July 9, 2018.

[0001628280-18-013770:notes:19]
Under the terms of the Settlement Agreement, Sinovel has agreed to pay AMSC China an aggregate cash amount in RMB equivalent to $57.5 million, consisting of two installments. Sinovel paid the first installment of $32.5 million on July 4, 2018, and has agreed to the Second Payment of $25.0 million within ten (10) months after the District Court delivers the first sentence against Sinovel in the criminal case entitled United States v. Sinovel Wind Co., Ltd., Case Number 3:13-cr-00084-jdp. On July 6, 2018, the District Court delivered such sentence, and therefore the Second Payment is due by May 6, 2019. Mr. Wenyuan Wei, former Sinovel chairman and a current Sinovel shareholder, has delivered a letter of guarantee (the “Guarantee”) to the Company for the Second Payment should Sinovel fail to make such payment by the Second Payment Due Date.

[0001628280-18-013770:notes:20]
In addition, pursuant to the terms of the Settlement Agreement, the Company and AMSC Austria have granted Sinovel a non-exclusive license for certain AMSC intellectual property to be used solely in Sinovel’s doubly fed wind turbines (the “License”). AMSC has agreed not to sue Sinovel, Sinovel’s power converter suppliers or Sinovel’s customers for use of the technology covered by the License. In the event that Sinovel or Mr. Wei does not make the Second Payment by the Second Payment Due Date, the Settlement Agreement provides that the License will terminate.

[0001628280-18-013770:notes:21]
The Company and Sinovel have submitted withdrawal applications to terminate the Proceedings to the relevant Chinese courts and the Beijing Arbitration Commission. Subject to the Company and Sinovel complying with the terms of the Settlement Agreement, the Company and Sinovel have agreed not to re-institute any of the Proceedings. In addition, the Company and Sinovel have agreed to a mutual release and covenant not to sue covering all subject matters of the Proceedings and Contracts, effective upon the completion of the Second Payment.

[0001628280-18-013770:notes:22]
The Company first considered the Settlement under ASC 606 to determine if the arrangement qualified for revenue accounting under ASC 606.  As Sinovel is not considered a customer that the Company is supplying goods or services to under ordinary terms, and the Settlement was a negotiation intended to release claims by both parties rather than for the procurement of product or services, the proceeds from the Settlement will not be treated as revenue and will be reported as other income, net of direct expenses, separately in Operating Income (Expense).  The Second Payment will be recorded in a similar manner when received.

[0001628280-18-013770:notes:23]
Other

[0001628280-18-013770:notes:24]
The Company enters into long-term construction contracts with customers that require the Company to obtain performance bonds. The Company is required to deposit an amount equivalent to some or all the face amount of the performance bonds into an escrow account until the termination of the bond. When the performance conditions are met, amounts deposited as collateral for the performance bonds are returned to the Company. In addition, the Company has various contractual arrangements in which minimum quantities of goods or services have been committed to be purchased on an annual basis.

[0001628280-18-013770:notes:25]
As of September 30, 2018, the Company had $0.2 million of restricted cash included in long-term assets. These amounts included in restricted cash primarily represent deposits to secure letters of credit for various supply contracts. These deposits are held in interest bearing accounts.


## us-gaap:ContractWithCustomerAssetAndLiabilityTableTextBlock

[0001628280-18-013770:notes:26]
[same as prior period, unchanged from 0001628280-18-009847:notes:25]

[0001628280-18-013770:notes:27]
|  | Unbilled AR |  | Deferred Program Costs |  | Contract Liabilities |
| Beginning balance as of March 31, 2018 | $ | 3,016 |  |  | $ | 2,567 |  |  | $ | 21,937 |  |
| Impact of adoption of ASC 606 | — |  |  | (1,599 | ) |  | (2,657 | ) |
| Increases for costs incurred to fulfill performance obligations | — |  |  | 1,267 |  |  | — |  |
| Increase (decrease) due to customer billings | (7,886 | ) |  | — |  |  | 7,828 |  |
| Decrease due to cost recognition on completed performance obligations | — |  |  | (1,033 | ) |  | — |  |
| Increase (decrease) due to recognition of revenue based on transfer of control of performance obligations | 7,439 |  |  | (9 | ) |  | (8,296 | ) |
| Other changes and FX impact | (19 | ) |  | 24 |  |  | (864 | ) |
| Ending balance as of September 30, 2018 | $ | 2,550 |  |  | $ | 1,217 |  |  | $ | 17,948 |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001628280-18-013770:notes:28]
[same as prior period, unchanged from 0001628280-18-009847:notes:27]

[0001628280-18-013770:notes:29]
The Company accounts for its warrants and contingent consideration as liabilities due to certain adjustment provisions within the instruments, which require that they be recorded at fair value. The warrants are subject to revaluation at each balance sheet date and any change in fair value is recorded as a change in fair value of warrants until the earlier of its expiration or its exercise at which time the warrant liability will be reclassified to equity. The Company calculated the fair value of the warrants utilizing an integrated lattice model.  See Note 6, "Fair Value Measurements", for further discussion.

[0001628280-18-013770:notes:30]
[same as prior period, unchanged from 0001628280-18-009847:notes:29]

[0001628280-18-013770:notes:31]
The Company issued Hercules warrants to purchase 13,927 shares of common stock (the “First Warrant”) and 25,641 shares of common stock (the “Second Warrant”) in conjunction with prior term loans that have been repaid in full.  On December 19, 2014, the Company entered into a second amendment to the Loan and Security Agreement with Hercules (the "Hercules Second Amendment").  In conjunction with the Hercules Second Amendment, the Company issued Hercules a warrant to purchase 58,823 shares of the Company’s common stock (the "Hercules Second Amendment")which replaced the First Warrant and the Second Warrant.  The Hercules Warrant is exercisable at any time after its issuance at an exercise price of $7.85 per share, subject to certain price-based and other anti-dilution adjustments, including the equity offering in May 2017, the acquisition of ITC with common stock in September 2017 and sales of common stock under the ATM entered into in January 2017, and expires on June 30, 2020.  This warrant had a fair value of $0.1 million as of September 30, 2018 and March 31, 2018.

[0001628280-18-013770:notes:32]
[same as prior period, unchanged from 0001628280-18-009847:notes:31]

[0001628280-18-013770:notes:33]
[same as prior period, unchanged from 0001628280-18-009847:notes:32]

[0001628280-18-013770:notes:34]
[same as prior period, unchanged from 0001628280-18-009847:notes:33]

[0001628280-18-013770:notes:35]
| Fiscal Year 18 | September 30, 2018 | June 30, 2018 |
| Risk-free interest rate | 2.62% | 2.40% |
| Expected annual dividend yield | — | — |
| Expected volatility | 63.66% | 67.40% |
| Term (years) | 1.12 | 1.37 |
| Fair value | $1.3 million | $1.6 million |

[0001628280-18-013770:notes:36]
| Fiscal Year 17 | March 31, 2018 |  | December 31, 2017 |  | September 30, 2017 |  | June 30, 2017 |  | March 31, 2017 |
| Risk-free interest rate | 2.20% |  | 1.87% |  | 1.49% |  | 1.44% |  | 1.41% |
| Expected annual dividend yield | — |  | — |  | — |  | — |  | — |
| Expected volatility | 65.86% |  | 65.86% |  | 65.64% |  | 67.21% |  | 66.53% |
| Term (years) | 1.62 |  | 1.87 |  | 2.12 |  | 2.37 |  | 2.62 |
| Fair value | $1.1 million |  | $0.4 million |  | $0.8 million |  | $0.9 million |  | $1.8 million |

[0001628280-18-013770:notes:37]
The Company recorded a net gain of $0.3 million and a net loss of $0.2 million resulting from the changes in the fair value of the November 2014 Warrant during the three and six months ended September 30, 2018, respectively.  The Company recorded net gains of $0.1 million and $1.0 million, resulting from the decrease in the fair value of the November 2014 Warrant during the three and six months ended September 30, 2017, respectively.


## us-gaap:DisaggregationOfRevenueTableTextBlock

[0001628280-18-013770:notes:38]
[same as prior period, unchanged from 0001628280-18-009847:notes:37]

[0001628280-18-013770:notes:39]
|  | Three Months Ended September 30, 2018 |  | Six Months Ended September 30, 2018 |
| Product Line: | Grid |  | Wind |  | Grid |  | Wind |
| Equipment and systems | $ | 5,503 |  |  | $ | 7,219 |  |  | $ | 12,957 |  |  | $ | 10,711 |  |
| Services and technology development | 2,066 |  |  | 88 |  |  | 3,541 |  |  | 274 |  |
| Total | $ | 7,569 |  |  | $ | 7,307 |  |  | $ | 16,498 |  |  | $ | 10,985 |  |
| Region: |  |  |  |  |  |  |  |
| Americas | $ | 5,052 |  |  | $ | 24 |  |  | $ | 12,548 |  |  | $ | 47 |  |
| Asia Pacific | 2,308 |  |  | 7,278 |  |  | 3,115 |  |  | 10,873 |  |
| EMEA | 209 |  |  | 5 |  |  | 835 |  |  | 65 |  |
| Total | $ | 7,569 |  |  | $ | 7,307 |  |  | $ | 16,498 |  |  | $ | 10,985 |  |


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001628280-18-013770:notes:40]
[same as prior period, unchanged from 0001628280-18-009847:notes:39]

[0001628280-18-013770:notes:41]
The Company accounts for its stock-based compensation at fair value. The following table summarizes stock-based compensation expense by financial statement line item for the three and six months ended September 30, 2018 and 2017 (in thousands):

[0001628280-18-013770:notes:42]
|  | Three months ended September 30, |  | Six months ended September 30, |
|  | 2018 |  | 2017 |  | 2018 |  | 2017 |
| Cost of revenues | $ | 50 |  |  | $ | 23 |  |  | $ | 90 |  |  | $ | 59 |  |
| Research and development | 70 |  |  | 61 |  |  | 121 |  |  | 110 |  |
| Selling, general and administrative | 705 |  |  | 394 |  |  | 1,399 |  |  | 1,063 |  |
| Total | $ | 825 |  |  | $ | 478 |  |  | $ | 1,610 |  |  | $ | 1,232 |  |

[0001628280-18-013770:notes:43]
The Company issued 37,075 shares of immediately vested common stock and 413,000 shares of restricted stock awards during the six months ended September 30, 2018, and issued 37,140 shares of immediately vested common stock and 795,500 shares of restricted stock awards during the six months ended September 30, 2017.  These restricted stock awards generally vest over 2-3 years.  Awards for restricted stock include both time-based and performance-based awards.  For options and restricted stock awards that vest upon the passage of time, expense is being recorded over the vesting period.  Performance-based awards are expensed over the requisite service period based on probability of achievement.  In addition, the Company issued 16,667 restricted stock units under the 2007 Stock Incentive Plan during the six months ended September 30, 2017, each of which represents the right to receive one share of common stock in connection with a severance agreement entered into with one of the Company's former executive officers. These restricted stock units vested and were settled in shares of common stock on the eighth day after receipt of an irrevocable release.

[0001628280-18-013770:notes:44]
The estimated fair value of the Company’s stock-based awards, less expected annual forfeitures, is amortized over the awards’ service period. The total unrecognized compensation cost for unvested outstanding stock options was $0.1 million at September 30, 2018. This expense will be recognized over a weighted average expense period of approximately 0.5 years. The total unrecognized compensation cost for unvested outstanding restricted stock was $3.6 million at September 30, 2018. This expense will be recognized over a weighted-average expense period of approximately 1.9 years.

[0001628280-18-013770:notes:45]
The Company did not grant any stock options during the three and six months ended September 30, 2018 or 2017.


## us-gaap:EarningsPerShareTextBlock

[0001628280-18-013770:notes:46]
Computation of Net Income (Loss) per Common Share

[0001628280-18-013770:notes:47]
Basic net income (loss) per share (“EPS”) is computed by dividing net income (loss) by the weighted-average number of common shares outstanding for the period. Where applicable, diluted EPS is computed by dividing the net income (loss) by the weighted-average number of common shares and dilutive common equivalent shares outstanding during the period, calculated using the treasury stock method. Common equivalent shares include the effect of restricted stock, exercise of stock options and warrants and contingently issuable shares. For the three months ended September 30, 2018, 1.6 million shares were not included in the calculation of diluted EPS as they were considered anti-dilutive, of which 0.3 million relate to outstanding stock options, 0.9 million relate to outstanding warrants and 0.4 million relate to outstanding awards.  For the six months ended September 30, 2018, 1.4 million shares were not included in the calculation of diluted EPS as they were considered anti-dilutive, of which 0.2 million relate to outstanding stock options, 0.9 million relate to outstanding warrants and 0.3 million relate to outstanding awards.  For the three and six months ended September 30, 2017, 1.5 million shares were not included in the calculation of diluted EPS as they were considered anti-dilutive, of which 0.3 million relate to outstanding stock options, and 1.2 million relate to outstanding warrants.

[0001628280-18-013770:notes:48]
The following table reconciles the numerators and denominators of the earnings per share calculation for the three and six months ended September 30, 2018 and 2017 (in thousands, except per share data):

[0001628280-18-013770:notes:49]
|  | Three months ended September 30, |  | Six months ended September 30, |
|  | 2018 |  | 2017 |  | 2018 |  | 2017 |
| Numerator: |  |  |  |  |  |  |  |
| Net income (loss) | $ | 22,558 |  |  | $ | (7,281 | ) |  | $ | 17,821 |  |  | $ | (22,533 | ) |
| Denominator: |  |  |  |  |  |  |  |
| Weighted-average shares of common stock outstanding | 21,252 |  |  | 19,531 |  |  | 21,126 |  |  | 18,316 |  |
| Weighted-average shares subject to repurchase | (939 | ) |  | (471 | ) |  | (886 | ) |  | (391 | ) |
| Shares used in per-share calculation ― basic | 20,313 |  |  | 19,060 |  |  | 20,240 |  |  | 17,925 |  |
| Shares used in per-share calculation ― diluted | 20,581 |  |  | 19,060 |  |  | 20,560 |  |  | 17,925 |  |
| Net income (loss) per share ― basic | $ | 1.11 |  |  | $ | (0.38 | ) |  | $ | 0.88 |  |  | $ | (1.26 | ) |
| Net income (loss) per share ― diluted | $ | 1.10 |  |  | $ | (0.38 | ) |  | $ | 0.87 |  |  | $ | (1.26 | ) |


## us-gaap:FairValueDisclosuresTextBlock

[0001628280-18-013770:notes:50]
[same as prior period, unchanged from 0001628280-18-009847:notes:49]

[0001628280-18-013770:notes:51]
[same as prior period, unchanged from 0001628280-18-009847:notes:50]

[0001628280-18-013770:notes:52]
[same as prior period, unchanged from 0001628280-18-009847:notes:51]

[0001628280-18-013770:notes:53]
The Company provides a gross presentation of activity within Level 3 measurement roll-forward and details of transfers in and out of Level 1 and 2 measurements.  A change in the hierarchy of an investment from its current level is reflected in the period during which the pricing methodology of such investment changes.  Disclosure of the transfer of securities from Level 1 to Level 2 or Level 3 is made in the event that the related security is significant to total cash and investments.  The Company did not have any transfers of assets and liabilities from Level 1, Level 2 or Level 3 of the fair value measurement hierarchy during the six months ended September 30, 2018.

[0001628280-18-013770:notes:54]
[same as prior period, unchanged from 0001628280-18-009847:notes:53]

[0001628280-18-013770:notes:55]
The following table provides the assets and liabilities carried at fair value on a recurring basis, measured as of September 30, 2018 and March 31, 2018 (in thousands):

[0001628280-18-013770:notes:56]
|  | TotalCarryingValue |  | Quoted Prices inActive Markets(Level 1) |  | Significant OtherObservable Inputs(Level 2) |  | SignificantUnobservable Inputs(Level 3) |
| September 30, 2018: |  |  |  |  |  |  |  |
| Assets: |  |  |  |  |  |  |  |
| Cash equivalents | $ | 46,841 |  |  | $ | 46,841 |  |  | $ | — |  |  | $ | — |  |
| Derivative liabilities: |  |  |  |  |  |  |  |
| Warrants | 1,399 |  |  | — |  |  | — |  |  | 1,399 |  |

[0001628280-18-013770:notes:57]
[same as prior period, unchanged from 0001628280-18-009847:notes:56]

[0001628280-18-013770:notes:58]
[same as prior period, unchanged from 0001628280-18-009847:notes:57]

[0001628280-18-013770:notes:59]
|  | Warrants |
| April 1, 2018 | $ | 1,217 |  |
| Mark to market adjustment | 182 |  |
| Balance at September 30, 2018 | $ | 1,399 |  |

[0001628280-18-013770:notes:60]
|  | Warrants |  | Acquisition Contingent Consideration |
| April 1, 2017 | $ | 1,923 |  |  | $ | — |  |
| Issuance of contingent consideration | — |  |  | 571 |  |
| Mark to market adjustment | (1,069 | ) |  | (201 | ) |
| Balance at September 30, 2017 | $ | 854 |  |  | $ | 370 |  |

[0001628280-18-013770:notes:61]
[same as prior period, unchanged from 0001628280-18-009847:notes:60]

[0001628280-18-013770:notes:62]
[same as prior period, unchanged from 0001628280-18-009847:notes:61]

[0001628280-18-013770:notes:63]
[same as prior period, unchanged from 0001628280-18-009847:notes:62]

[0001628280-18-013770:notes:64]
[same as prior period, unchanged from 0001628280-18-009847:notes:63]

[0001628280-18-013770:notes:65]
[same as prior period, unchanged from 0001628280-18-009847:notes:64]

[0001628280-18-013770:notes:66]
[same as prior period, unchanged from 0001628280-18-009847:notes:65]

[0001628280-18-013770:notes:67]
Contingent Consideration

[0001628280-18-013770:notes:68]
Contingent consideration relates to a make whole payment provision set forth in the stock purchase agreement ("SPA") for the acquisition of ITC that requires the Company to guarantee the purchase price of the acquisition should the aggregate proceeds of the resale of AMSC shares sold by selling stockholders during the first 90 days after the effectiveness of the resale registration statement be less than the agreed upon purchase price for such AMSC shares (per the terms of the SPA) sold during such 90 day period. See Note 13, "Warrants and Derivative Liabilities" and Note 5, “Acquisition and Related Goodwill” for further discussion. The Company relied on a Black Scholes option pricing method to determine the fair value of the contingent consideration on the date of acquisition. All of the stock related to this liability was sold as of December 5, 2017 and the amount of the make whole payment provided for in the SPA was calculated to be $0.7 million, and subsequently paid on January 5, 2018.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001628280-18-013770:notes:69]
[same as prior period, unchanged from 0001628280-18-009847:notes:66]

[0001628280-18-013770:notes:70]
The Company recorded an income tax expense of $3.0 million in each of the three and six months ended September 30, 2018.  The Company recorded income tax benefit of $0.2 million and $0.1 million in the three and six months ended September 30, 2017.

[0001628280-18-013770:notes:71]
On December 22, 2017, the Tax Cuts and Jobs Act of 2017 (the “Act”) was signed into law. ASC Topic 740 requires deferred tax assets and liabilities to be measured using the enacted rate for the period in which they are expected to reverse.   Accordingly, the new 21% U.S. Federal corporate tax rate was used to measure the U.S. deferred tax assets and liabilities that will reverse in future periods. The Company's deferred tax attributes are generally subject to a full valuation allowance in the U.S. and thus, this adjustment to the attributes did not impact the tax provision.  In addition, the new legislation includes a one-time transition tax in which all foreign earnings are deemed to be repatriated to the U.S. and taxable at specified rates included within the Act. The Company reviewed the accumulated foreign earnings aggregated across all non U.S. subsidiaries, net of foreign deficits.  The Company believes it is in an aggregate net foreign deficit position for U.S. tax purposes and therefore not liable for the transition tax.  The SEC staff issued Staff Accounting Bulletin No. 118, which provides guidance for companies that have not completed their accounting for the income tax effects of the Act in the period of enactment, allowing for a measurement period of up to one year after the enactment date to finalize the recording of the related tax impacts.  The Company made reasonable estimates and does not anticipate significant revisions to the accounting for the tax impact of the Act, but has not completed the accounting for the tax effects of the Act at September 30, 2018.  The Company will continue to assess its provision for income taxes as future guidance is issued, but does not currently anticipate significant revisions will be necessary. The ultimate impact may differ from the Company's provisional estimates, possibly materially, due to additional analysis, changes in interpretations and assumptions the Company has made, additional regulatory guidance that may be used and actions the Company may take as a result of the Act. The accounting is expected to be complete within the one year measurement period in accordance with the measurement period guidance outlined in Staff Accounting Bulletin No. 118.

[0001628280-18-013770:notes:72]
Accounting for income taxes requires a two-step approach to recognizing and measuring uncertain tax positions.  The first step is to evaluate the tax position for recognition by determining if, based on the technical merits, it is more likely than not the position will be sustained upon audit, including resolution of related appeals or litigation processes, if any.  The second step is to measure the tax benefit as the largest amount that is more than 50% likely to be realized upon ultimate settlement.  The Company re-evaluates these uncertain tax positions on a quarterly basis.  The evaluation is based on factors including, but not limited to, changes in facts or circumstances, changes in tax law, effectively settled issues under audit and new audit activity.  Any changes in these factors could result in the recognition of a tax benefit or an additional charge to the tax provision.  The Company did not identify any uncertain tax positions in the six months ended September 30, 2018 and did not have any gross unrecognized tax benefits as of March 31, 2018.


## us-gaap:InventoryDisclosureTextBlock

[0001628280-18-013770:notes:73]
[same as prior period, unchanged from 0001628280-18-009847:notes:70]

[0001628280-18-013770:notes:74]
Inventory, net of reserves, at September 30, 2018 and March 31, 2018 consisted of the following (in thousands):

[0001628280-18-013770:notes:75]
|  | September 30, 2018 |  | March 31, 2018 |
| Raw materials | $ | 5,996 |  |  | $ | 7,526 |  |
| Work-in-process | 2,306 |  |  | 920 |  |
| Finished goods | 6,716 |  |  | 8,767 |  |
| Deferred program costs | 1,217 |  |  | 2,567 |  |
| Net inventory | $ | 16,235 |  |  | $ | 19,780 |  |

[0001628280-18-013770:notes:76]
The Company recorded inventory write-downs of $0.4 million and $0.1 million for the three months ended September 30, 2018 and 2017, respectively.  The Company recorded inventory write-downs of $0.5 million and $0.4 million for the six months ended September 30, 2018 and 2017, respectively.  These write downs were based on evaluating its inventory on hand for excess quantities and obsolescence.

[0001628280-18-013770:notes:77]
Deferred program costs as of September 30, 2018 and March 31, 2018 primarily represent costs incurred on programs where the Company needs to complete performance obligations before the related revenue and costs will be recognized.


## us-gaap:LoansNotesTradeAndOtherReceivablesDisclosureTextBlock

[0001628280-18-013770:notes:78]
[same as prior period, unchanged from 0001628280-18-009847:notes:75]

[0001628280-18-013770:notes:79]
Accounts receivable at September 30, 2018 and March 31, 2018 consisted of the following (in thousands):

[0001628280-18-013770:notes:80]
|  | September 30, 2018 |  | March 31, 2018 |
| Accounts receivable (billed) | $ | 5,072 |  |  | $ | 4,403 |  |
| Accounts receivable (unbilled) | 2,550 |  |  | 3,016 |  |
| Less: Allowance for doubtful accounts | — |  |  | (54 | ) |
| Accounts receivable, net | $ | 7,622 |  |  | $ | 7,365 |  |

[0001628280-18-013770:notes:81]
[same as prior period, unchanged from 0001628280-18-009847:notes:78]

[0001628280-18-013770:notes:82]
[same as prior period, unchanged from 0001628280-18-009847:notes:79]

[0001628280-18-013770:notes:83]
The note receivable was discounted to its present value of $5.7 million utilizing a discount rate of 6%, which was based on management’s assessment of what an appropriate loan at current market rates would be. The $0.3 million discount was recorded as an offset to the long term portion of the note receivable, and is being amortized to interest income over the term of the note. In addition, the resulting gain of $0.1 million from the sale of the Devens property which was deferred previously was recorded as a component of the cumulative effect of an accounting change upon the adoption of ASU 2017-05 which was issued as a part of ASU 2014-09.  This gain was recorded as an offset to the opening accumulated deficit.

[0001628280-18-013770:notes:84]
Note receivable as of September 30, 2018 and March 31, 2018 consisted of the following (in thousands):

[0001628280-18-013770:notes:85]
| Current assets | September 30, 2018 |  | March 31, 2018 |
| Note receivable, current | $ | 3,000 |  |  | $ | 3,000 |  |
| Total current note receivable | $ | 3,000 |  |  | $ | 3,000 |  |
| Long term assets |  |  |  |
| Note receivable, long term | $ | 3,000 |  |  | $ | 3,000 |  |
| Note receivable discount | (224 | ) |  | (336 | ) |
| Deferred gain on sale | — |  |  | (105 | ) |
| Total long term note receivable | $ | 2,776 |  |  | $ | 2,559 |  |


## us-gaap:NewAccountingPronouncementsAndChangesInAccountingPrinciplesTextBlock

[0001628280-18-013770:notes:86]
Recent Accounting Pronouncements

[0001628280-18-013770:notes:87]
In May 2014, the Financial Accounting Standards Board (“FASB”) and the International Accounting Standards Board ("IASB") issued, ASU 2014-09, Revenue from Contracts with Customers (Topic 606). The guidance substantially converges final standards on revenue recognition between the FASB and IASB providing a framework on addressing revenue recognition issues and, upon its effective date, replaces almost all existing revenue recognition guidance, including industry-specific guidance, in current U.S. generally accepted accounting principles. The FASB has subsequently issued multiple amendments to ASU 2014-09 which are all effective for annual reporting periods beginning after December 15, 2017.

[0001628280-18-013770:notes:88]
As of April 1, 2018, the Company has adopted ASU 2014-09 and its amendments, reported the impact in its consolidated financial statements, and implemented changes to its business processes, systems and controls to support revenue recognition and the related disclosures under this ASU.  The Company’s assessment included a detailed review of representative contracts from each of the Company’s revenue streams and a comparison of its historical accounting policies and practices to the new standard. The Company adopted the new standards retrospectively with the cumulative effect of initially applying the guidance recognized at the date of initial application (the modified retrospective transition method) to all existing contracts that have remaining obligations as of April 1, 2018.  Accordingly, the Company has elected to retroactively adjust only those contracts that do not meet the definition of a complete contract at the date of the initial application.  This guidance will lead to recognizing certain revenue transactions sooner than in the past on certain contracts, as the Company will need to estimate the revenue it will be entitled to upon contract completion, and later on other contracts, such as Consulting and Statement of Work transactions, due to the lack of an enforceable right to payment for performance obligations satisfied over time. There are no changes in the accounting for its largest revenue stream which includes Inox Wind as its primary customer.  Across other revenue streams such as D-VAR® Equipment and D-VAR® Turnkey, the timing of revenue recognition will be affected for multiple types of contracts, primarily multiple performance obligation contracts in its Grid business unit, but those differences did not have a material impact on its consolidated financial statements.  The adjustment to opening accumulated deficit was not significant in the period commencing on April 1, 2018.  Additionally, the adoption of this new standard is not expected to have any tax impact on the consolidated financial statements. As part of this analysis, the Company evaluated its information technology capabilities and systems, and did not incur significant information technology costs to modify systems currently in place.

[0001628280-18-013770:notes:89]
In January 2016, the FASB issued ASU 2016-01, Financial Instruments-Overall (Subtopic 825-10): Recognition and Measurement of Financial Assets and Financial Liabilities.  The amendments in ASU 2016-01 will enhance the reporting model for financial instruments to provide users of financial statements with more decision-useful information. This ASU is effective for annual reporting periods beginning after December 15, 2017, and interim periods within those fiscal years.  The Company adopted ASU 2016-01 effective April 1, 2018 and noted no significant impact to its consolidated financial statements.

[0001628280-18-013770:notes:90]
In February 2016, the FASB issued ASU 2016-02, Leases (Topic 842). The guidance in this ASU supersedes the leasing guidance in Topic 840, Leases. Under the new guidance, lessees are required to recognize lease assets and lease liabilities on the balance sheet for all leases with terms longer than 12 months. Leases will be classified as either finance or operating, with classification affecting the pattern of expense recognition in the income statement.  This ASU and its amendments are effective for fiscal years beginning after December 15, 2018, including interim periods within those fiscal years.

[0001628280-18-013770:notes:91]
| • | In July 2018, the FASB issued ASU 2018-10, Codification improvements to Topic 842, Leases. The amendments in ASU 2018-10 provide more clarification in regards to the application and requirements of ASU 2016-02. |

[0001628280-18-013770:notes:92]
| • | In July 2018, the FASB issued ASU 2018-11, Topic 842, Leases - Targeted improvements. The amendments in ASU 2018-11 provide for the option to adopt the standard prospectively and recognize a cumulative-effect adjustment to the opening balance of retained earnings as well as offer a new practical expedient that will allow the Company to elect, by class of underlying asset, to not separate non-lease and lease components in certain circumstances and instead to account for those components as a single item. |

[0001628280-18-013770:notes:93]
The Company is currently evaluating the provisions of ASU 2016-02 and its amendments, and assessing the impact the adoption of this guidance will have on its financial position, results of operations and disclosures.  This process has included identifying the implementation team, applying the revised definition of a lease per ASC 842 to existing agreements, and from that information, creating a preliminary population.  This population includes agreements identified from the following sources: existing leases under ASC 840, general ledger activity from recurring vendors and information reported from a survey provided to key individuals within the Company. The Company intends to make the policy election to exclude all leases shorter than 12 months from the recognition of the recording of the right of use ("ROU") asset and related liabilities.  The Company expects to elect the package of three practical expedients in regards to all leases that commenced before the effective date as well as the practical expedient that allows the use of hindsight in determining lease term.  The Company anticipates the adoption of this guidance will result in certain changes to its financial statements to add the related asset and liability accounts for all of its operating leases. The Company will continue to assess its agreements for any other impacts that may result from the adoption of this standard. During the second half of fiscal 2018, the Company plans to finalize its population of leases including the classification of type of lease for each of those agreements and assess its current controls, as well as identify and implement any changes that may be necessary to comply with the provisions of ASU 2016-02, which will be effective on April 1, 2019.

[0001628280-18-013770:notes:94]
The Company is required to adopt the new standards in the first quarter of fiscal 2019 and expects to do so using the modified retrospective transition method, which will impact all leases existing at, or entered into after the period of adoption.  For all leases existing at the time of adoption the Company will recognize a cumulative effect adjustment to its opening balance of retained earnings as of April 1, 2019.  The Company is still evaluating the final impact of this adoption method on its consolidated financial statements.

[0001628280-18-013770:notes:95]
In June 2016, the FASB issued ASU 2016-13, Financial Instruments-Credit Losses (Topic 326): Measurement of Credit Losses on Financial Instruments.  The amendments in ASU 2016-13 will provide more decision-useful information about the expected credit losses on financial instruments and other commitments to extend credit held by a reporting entity at each reporting date. The ASU is effective for annual reporting periods beginning after December 15, 2019, including interim periods within that year.  The Company is currently evaluating the impact, if any, the adoption of ASU 2016-13 may have on its consolidated financial statements.

[0001628280-18-013770:notes:96]
In 2016, the FASB issued the following two ASU's on Statement of Cash Flows (Topic 230).  Both amendments are effective for annual reporting periods beginning after December 15, 2017, including interim periods within that year.

[0001628280-18-013770:notes:97]
| • | In August 2016, the FASB issued ASU 2016-15, Statement of Cash Flows (Topic 230): Classification of Certain Cash Receipts and Cash Payments. The amendments in ASU 2016-15 provide more guidance towards the classification of multiple different types of cash flows in order to reduce the diversity in reporting across entities. |

[0001628280-18-013770:notes:98]
| • | In November 2016, the FASB issued ASU 2016-18, Statement of Cash Flows (Topic 230): Restricted Cash. The amendments in ASU 2016-18 explain the change during the period in the total of cash, cash equivalents, and amounts generally described as restricted cash or restricted cash equivalents. Therefore, amounts generally described as restricted cash and restricted cash equivalents should be included with cash and cash equivalents when reconciling the beginning-of-period and end-of-period total amounts shown on the statement of cash flows. |

[0001628280-18-013770:notes:99]
The Company adopted ASU 2016-15 and ASU 2016-18 effective April 1, 2018 and noted no significant impact to its consolidated financial statements.

[0001628280-18-013770:notes:100]
In October 2016, the FASB issued ASU 2016-16, Income Taxes (Topic 740): Intra-Entity Transfers of Assets Other Than Inventory.  The amendments in ASU 2016-16 will improve the accounting for the income tax consequences of intra-entity transfers of assets other than inventory. The ASU is effective for annual reporting periods beginning after December 15, 2017, including interim periods within that year.  The Company adopted ASU 2016-16 effective April 1, 2018 and noted no significant impact to its consolidated financial statements.

[0001628280-18-013770:notes:101]
In February 2017, the FASB issued ASU 2017-05, Other Income - Gains and Losses from the Derecognition of Non-financial Assets (Subtopic 610-20).  The amendments in ASU 2017-05 clarify the scope of Subtopic 610-20, Other Income-Gains and Losses from the Derecognition of Non-financial Assets, and to add guidance for partial sales of non-financial assets. Subtopic 610-20, which was issued in May 2014 as a part of ASU No. 2014-09, Revenue from Contracts with Customers (Topic 606), provides guidance for recognizing gains and losses from the transfer of non-financial assets in contracts with non-customers.  The Company adopted ASU 2017-05 effective April 1, 2018 and adjusted the opening balance of accumulated deficit for $0.1 million for recognition of the deferred gain on the sale of the 64 Jackson Road building that occurred on March 28, 2018.

[0001628280-18-013770:notes:102]
In May 2017, the FASB issued ASU 2017-09, Compensation - Stock Compensation (Subtopic 718) Scope of Modification Accounting.  The amendments in ASU 2017-09 provide clarity and reduce both (1) diversity in practice and (2) cost and complexity when applying the guidance in Topic 718, Compensation—Stock Compensation, to a change to the terms or conditions of a share-based payment award.  The ASU is effective for annual reporting periods beginning after December 15, 2017, including interim periods within those periods. The Company adopted ASU 2017-09 effective April 1, 2018 and noted no significant impact to its consolidated financial statements.

[0001628280-18-013770:notes:103]
In July 2017, the FASB issued ASU 2017-11, Earnings per Share (Topic 260), Distinguishing Liabilities from Equity (Topic   480), and Derivatives and Hedging (Topic 815).  The amendments in ASU 2017-11 provide guidance for freestanding equity-linked financial instruments, such as warrants and conversion options in convertible debt or preferred stock, and should no longer be accounted for as a derivative liability at fair value as a result of the existence of a down round feature.  The ASU is effective for annual reporting periods beginning after December 15, 2018, including interim periods within those periods. The Company is currently evaluating the impact the adoption of ASU 2017-11 and does not expect a significant impact on its consolidated financial statements, primarily due to the put option feature which requires continued liability classification under ASC 480.

[0001628280-18-013770:notes:104]
In August 2017, the FASB issued ASU 2017-12, Derivatives and Hedging (Topic 815): Targeted Improvements to Accounting for Hedging Activities.  The amendments in ASU 2017-12 provide improved financial reporting of hedging relationships to better portray the economic results of an entity’s risk management activities in its financial statements. In addition, the amendments in this update make certain targeted improvements to simplify the application of the hedge accounting guidance.  The ASU is effective for annual reporting periods beginning after December 15, 2018, including interim periods within those periods. The Company is currently evaluating the impact the adoption of ASU 2017-12 may have on its consolidated financial statements.

[0001628280-18-013770:notes:105]
In June 2018, the FASB issued ASU 2018-07, Compensation - Stock Compensation (Topic 718): Improvements to Non-Employee Share Based Payment Accounting.  The amendments in ASU 2018-07 provide for the simplification of the measurement of share-based payment transactions for acquiring goods and services from non-employees.  The ASU is effective for annual reporting periods beginning after December 15, 2018, including interim periods within those periods. The Company is currently evaluating the impact of the adoption of ASU 2018-07 and does not expect it to have a significant impact on its consolidated financial statements.

[0001628280-18-013770:notes:106]
In August 2018, the FASB issued ASU 2018-13, Fair Value Measurement (Topic 820): Changes to the Disclosure Requirements for Fair Value Measurement.  The amendments in ASU 2018-13 provide for increased effectiveness of the disclosures made around fair value measurements while including consideration for costs and benefits.  The ASU is effective for annual reporting periods beginning after December 15, 2019, including interim periods within those periods. The Company is currently evaluating the impact the adoption of ASU 2018-13 may have on its consolidated financial statements.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0001628280-18-013770:notes:107]
[same as prior period, unchanged from 0001628280-18-009847:notes:102]

[0001628280-18-013770:notes:108]
[same as prior period, unchanged from 0001628280-18-009847:notes:103]

[0001628280-18-013770:notes:109]
[same as prior period, unchanged from 0001628280-18-009847:notes:104]

[0001628280-18-013770:notes:110]
[same as prior period, unchanged from 0001628280-18-009847:notes:105]

[0001628280-18-013770:notes:111]
The Company has experienced recurring operating losses and as of September 30, 2018, the Company had an accumulated deficit of $970.5 million. In addition, the Company has experienced recurring negative operating cash flows.  At September 30, 2018, the Company had cash and cash equivalents of $56.2 million, with no outstanding debt other than ordinary trade payables. Cash provided by operations for the six months ended September 30, 2018 was $23.6 million.  The current period results include the net gain received from the first installment of the Sinovel settlement of $28.7 million in the three month period ended September 30, 2018.

[0001628280-18-013770:notes:112]
From April 1, 2011 through the date of this filing, the Company has reduced its global workforce substantially.  As of September 30, 2018, the Company had a global workforce of 225 persons.  The Company plans to closely monitor its expenses and, if required, expects to further reduce operating costs and capital spending to enhance liquidity.

[0001628280-18-013770:notes:113]
Over the last several years, the Company has entered into several debt and equity financing arrangements in order to raise capital.  Since April 1, 2012, the Company has generated aggregate cash flows from financing activities of $84.9 million.  Included in this amount are proceeds of approximately $17.0 million after deducting underwriting discounts and commissions and offering expenses payable by the Company, from the Company's equity offering completed on May 10, 2017, which includes the subsequent exercise by the underwriters of their option in full to purchase additional shares.  The Company terminated its At Market Issuance Sales Agreement ("ATM") with FBR Capital Markets & Co. in conjunction with this equity offering.  See Note 14 “Stockholders' Equity” for further discussion of these financing arrangements.

[0001628280-18-013770:notes:114]
On July 3, 2018, the Company and its wholly-owned subsidiaries Suzhou AMSC Superconductor Co. Ltd. (“AMSC China”) and AMSC Austria GMBH (“AMSC Austria”) entered into a settlement agreement (the “Settlement Agreement”) with Sinovel Wind Group Co., Ltd. (“Sinovel”). The Settlement Agreement settles the litigation and arbitration proceedings between the Company and Sinovel, as further described in Note 15 “Commitments and Contingencies".  Under the terms of the Settlement Agreement, Sinovel has agreed to pay AMSC China an aggregate cash amount in Renminbi ("RMB") equivalent to $57.5 million, consisting of two installments. Sinovel paid the first installment of $32.5 million on July 4, 2018, which was repatriated to the Company during the six months ended September 30, 2018, and has agreed to pay the second installment of $25.0 million (the “Second Payment”) within ten (10) months after the U.S. District Court for the Western District of Wisconsin (the “District Court”) delivers the first sentence against Sinovel in the criminal case entitled United States v. Sinovel Wind Co., Ltd., Case Number 3:13-cr-00084-jdp. On July 6, 2018, the District Court delivered such sentence, and therefore the Second Payment is due by May 6, 2019 (the “Second Payment Due Date”).

[0001628280-18-013770:notes:115]
On February 1, 2018, ASC Devens LLC (the "Seller"), a wholly-owned subsidiary of the Company, entered into a Purchase and Sale Agreement (the “PSA”) with 64 Jackson, LLC (the “Purchaser”) and Stewart Title Guaranty Company (“Escrow Agent”), to effectuate the sale of certain real property located at 64 Jackson Road, Devens, Massachusetts, including the building that had served as the Company’s headquarters (collectively, the “Property”), in exchange for total consideration of $23.0 million, composed of (i) cash consideration of $17.0 million, and (ii) a $6.0 million subordinated secured commercial promissory note payable to the Company (the "Seller Note"). Subsequently, the Seller, the Purchaser and Jackson 64 MGI, LLC (“Assignee”) entered into an Assignment of Purchase and Sale Agreement (the “Assignment Agreement”), pursuant to which the Purchaser assigned all of its rights and interests in the PSA to the Assignee and the Assignee agreed to assume all of the Purchaser’s obligations and liabilities under the PSA. The transaction closed on March 28, 2018, at which time the Company received, from the Assignee, cash consideration, net of certain agreed upon closing costs, of $16.9 million, and the Seller Note at an interest rate of 1.96%. The Seller Note is secured by a subordinated second mortgage on the Property and a subordinated second assignment of leases and rents.

[0001628280-18-013770:notes:116]
In December 2015, the Company entered into a set of strategic agreements valued at approximately $210.0 million with Inox Wind Ltd. (“Inox” or "Inox Wind"), which includes a multi-year supply contract pursuant to which the Company will supply electrical control systems to Inox and a license agreement allowing Inox to manufacture a limited number of electrical control systems.  After Inox purchases the specified number of electrical control systems required under the terms of the supply contract, Inox agreed that the Company will continue as Inox’s preferred supplier and Inox will be required to purchase from the Company a majority of its electrical control systems requirements for an additional three-year period.

[0001628280-18-013770:notes:117]
The Company believes that based on the information presented above and its quarterly management assessment, it has sufficient liquidity to fund its operations and capital expenditures for the next twelve months following the issuance of the financial statements for the three and six months ended September 30, 2018. The Company’s liquidity is highly dependent on its ability to increase revenues, including its ability to collect revenues under its agreements with Inox, its ability to control its operating costs, and its ability to raise additional capital, if necessary. There can be no assurance that the Company will be able to continue to raise additional capital, on favorable terms or at all, from other sources or execute on any other means of improving liquidity described above.


## us-gaap:PropertyPlantAndEquipmentDisclosureTextBlock

[0001628280-18-013770:notes:118]
[same as prior period, unchanged from 0001628280-18-009847:notes:113]

[0001628280-18-013770:notes:119]
The cost and accumulated depreciation of property and equipment at September 30, 2018 and March 31, 2018 are as follows (in thousands):

[0001628280-18-013770:notes:120]
|  | September 30, 2018 |  | March 31, 2018 |
| Construction in progress - equipment | 597 |  |  | 654 |  |
| Equipment and software | 45,797 |  |  | 72,760 |  |
| Furniture and fixtures | 1,307 |  |  | 1,878 |  |
| Leasehold improvements | 1,838 |  |  | 1,426 |  |
| Property, plant and equipment, gross | 49,539 |  |  | 76,718 |  |
| Less accumulated depreciation | (38,957 | ) |  | (64,205 | ) |
| Property, plant and equipment, net | $ | 10,582 |  |  | $ | 12,513 |  |

[0001628280-18-013770:notes:121]
Depreciation expense was $1.1 million and $3.2 million for the three months ended September 30, 2018 and 2017, respectively.  Depreciation expense was $2.1 million and $7.5 million for the six months ended September 30, 2018 and 2017, respectively.   Included in depreciation expense for the three and six months ended September 30, 2017 is $1.6 million and $4.1 million, respectively, of accelerated depreciation recorded to cost of revenues related to revised estimates of the remaining useful lives of certain pieces of manufacturing equipment. Construction in progress - equipment primarily includes capital investments in the Company's newly leased facility in Ayer, Massachusetts.


## us-gaap:ReconciliationOfAssetsFromSegmentToConsolidatedTextBlock

[0001628280-18-013770:notes:122]
Total assets for the two business segments as of September 30, 2018 and March 31, 2018 are as follows (in thousands):

[0001628280-18-013770:notes:123]
|  | September 30, 2018 |  | March 31, 2018 |
| Wind | $ | 12,278 |  |  | $ | 16,790 |  |
| Grid | 35,077 |  |  | 37,012 |  |
| Corporate assets | 58,150 |  |  | 34,373 |  |
| Total | $ | 105,505 |  |  | $ | 88,175 |  |


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001628280-18-013770:notes:124]
[same as prior period, unchanged from 0001628280-18-009847:notes:119]

[0001628280-18-013770:notes:125]
[same as prior period, unchanged from 0001628280-18-009847:notes:120]

[0001628280-18-013770:notes:126]
The $0.4 million charged to operations in the six months ended September 30, 2018 is related to exit costs incurred for the move of the Company's corporate office.

[0001628280-18-013770:notes:127]
On April 3, 2017, the Board of Directors approved a plan to reduce the Company’s global workforce by approximately 8%, effective April 4, 2017.  The purpose of the workforce reduction was to reduce operating expenses to better align with the Company’s current revenues. Included in the $1.3 million severance pay, charged to operations in the six months ended September 30, 2017, is $0.5 million of severance pay for one of the Company's former executive officers pursuant to the terms of a severance agreement dated June 30, 2017.  Under the terms of the severance agreement, the Company's former executive officer is entitled to 18 months of his base salary, which is expected to be paid by December 31, 2018. From and after January 1, 2018, the Company, at its discretion, may settle any remaining unpaid cash severance owed to its former executive officer through the issuance of a number of immediately vested shares of the Company’s common stock, determined by multiplying the remaining unpaid cash severance owed by 120%, and then dividing by the closing stock price per share of the Company's common stock as of the last business day prior to the issuance of the shares.

[0001628280-18-013770:notes:128]
[same as prior period, unchanged from 0001628280-18-009847:notes:123]

[0001628280-18-013770:notes:129]
The following table presents restructuring charges and cash payments for the six months ended September 30, 2018 and 2017(in thousands):

[0001628280-18-013770:notes:130]
|  | Severance pay |  | Facility exit and |  |  |
|  | and benefits |  | Relocation costs |  | Total |
| Accrued restructuring balance at April 1, 2018 | $ | 262 |  |  | $ | 173 |  |  | $ | 435 |  |
| Charges to operations | — |  |  | 403 |  |  | 403 |  |
| Cash payments | (173 | ) |  | (576 | ) |  | (749 | ) |
| Accrued restructuring balance at September 30, 2018 | $ | 89 |  |  | $ | — |  |  | $ | 89 |  |

[0001628280-18-013770:notes:131]
|  | Severance pay |  | Facility exit and |  |  |
|  | and benefits |  | Relocation costs |  | Total |
| Accrued restructuring balance at April 1, 2017 | $ | — |  |  | $ | — |  |  | $ | — |  |
| Charges to operations | 1,328 |  |  | — |  |  | 1,328 |  |
| Cash payments | (746 | ) |  | — |  |  | (746 | ) |
| Accrued restructuring balance at September 30, 2017 | $ | 582 |  |  | $ | — |  |  | $ | 582 |  |

[0001628280-18-013770:notes:132]
[same as prior period, unchanged from 0001628280-18-009847:notes:127]


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001628280-18-013770:notes:133]
[same as prior period, unchanged from 0001628280-18-009847:notes:128]

[0001628280-18-013770:notes:134]
On April 1, 2018, the Company adopted Accounting Standards Codification ("ASC") 606, Revenue from Contracts with Customers, and all the related amendments and applied it to all contracts that were not completed as of April 1, 2018 using the modified retrospective method. The Company recognized the cumulative effect of initially applying the new revenue standard as an adjustment of less than $0.1 million to the opening balance of accumulated deficit. Prior period amounts have not been restated and continue to be reported under the accounting standards in effect for those periods.

[0001628280-18-013770:notes:135]
The adoption of this guidance has led to recognizing certain revenue transactions sooner than in the past on certain contracts, as the Company will need to estimate the revenue it will be entitled to upon contract completion, and later on other contracts, such as Consulting and Statement of Work transactions, due to the lack of an enforceable right to payment for performance obligations satisfied over time, specifically in the technology product line.  The Company does not expect a material impact to its consolidated statements of operations on an ongoing basis from the adoption of the new standard.

[0001628280-18-013770:notes:136]
In addition, the FASB issued Accounting Standards Update ("ASU") 2017-05, Other Income - Gains and Losses from the Derecognition of Non-financial Assets (Subtopic 610-20), in February 2017, to amend ASC 610-20, Other Income - Gains and Losses from the Derecognition of Non-financial Assets (issued at the same time as ASC 606), which provides a model for the measurement and recognition of gains and losses on the sale of non-financial assets, such as property and equipment, including real estate. As a result of adopting ASU 2017-05 on April 1, 2018, the Company recognized an adjustment to the opening balance of accumulated deficit for the deferred gain from the March 28, 2018 sale of the Company's former headquarters in Devens, Massachusetts in the amount of $0.1 million.

[0001628280-18-013770:notes:137]
[same as prior period, unchanged from 0001628280-18-009847:notes:132]

[0001628280-18-013770:notes:138]
|  | March 31, 2018 |  | Opening Adjustment |  | April 1, 2018 |
| Assets: |  |  |  |  |  |
| Accounts Receivable | $ | 7,365 |  |  | $ | (678 | ) |  | $ | 6,687 |  |
| Inventory | 19,780 |  |  | (1,599 | ) |  | 18,181 |  |
| Prepaid expenses and other current assets | 2,947 |  |  | 2,277 |  |  | 5,224 |  |
| Notes receivable, long term portion | 2,559 |  |  | 105 |  |  | 2,664 |  |
| Liabilities and Stockholders' Equity: |  |  |  |  |  |
| Accounts payable and accrued expenses | $ | (12,625 | ) |  | $ | (2,729 | ) |  | $ | (15,354 | ) |
| Deferred revenue | (13,483 | ) |  | 2,657 |  |  | (10,826 | ) |
| Accumulated deficit | $ | (988,333 | ) |  | $ | (33 | ) |  | $ | (988,366 | ) |

[0001628280-18-013770:notes:139]
Included in the opening adjustment are reclassifications for accounts receivable, deferred program costs and deferred revenue for previous balances related to agreements that no longer meet the definition of a customer contract under ASC 606.  The impact of adoption on the Company’s opening balances and for the three and six months ended September 30, 2018, in all financial statement line items impacted by ASC 606 was immaterial from the amount that would have been reported under the previous guidance.

[0001628280-18-013770:notes:140]
The Company’s revenues in its Grid segment are derived primarily through transmitting and distributing power, providing planning services that allow it to identify power grid needs and risks, and developing ship protection systems for the U.S. Navy. The Company’s revenues in its Wind segment are derived primarily through supplying advanced power electronics and control systems, licensing our highly engineered wind turbine designs, and providing extensive customer support services to wind turbine manufacturers.  The Company records revenue based on a five-step model in accordance with ASC 606. For its customer contracts, the Company identifies the performance obligations, determines the transaction price, allocates the contract transaction price to the performance obligations, and recognizes the revenue when (or as) control of goods or services is transferred to the customer.  As of September 30, 2018, 87% of revenue was recognized at the point in time when control transferred to the customer, with the remainder being recognized over time.

[0001628280-18-013770:notes:141]
In the Company's equipment and system product line, each contract with a customer summarizes each product sold to a customer, which typically represent distinct performance obligations.  A contract's transaction price is allocated to each distinct performance obligation using the respective standalone selling price which is determined primarily using the cost plus expected margin approach and recognized as revenue when, or as, the performance obligation is satisfied. The majority of the Company’s product sales transfer control to the customer in line with the contracted delivery terms and revenue is recorded at the point in time when products are transferred to the freight forwarder, as the Company has determined that this is the point in time that control transfers to the customer.

[0001628280-18-013770:notes:142]
In the Company's service and technology development product line, there are several different types of transactions but each of them begins with a contract with a customer that summarizes each product sold to a customer, which typically represents distinct performance obligations.  The technology development transactions are primarily for activities that have no alternative use and for which a profit can be expected throughout the life of the contract.  In these cases, the revenue is recognized over time, but in the instances where the profit cannot be assured throughout the entire contract then the revenue is recognized at a point in time.   Each contract's transaction price is allocated to each distinct performance obligation using the respective standalone selling price which is determined primarily using the cost plus expected margin approach.  The ongoing service transactions are for service contracts that provide benefit to the customer simultaneously as the Company performs its obligations, and therefore this revenue is recognized ratably over time throughout the effective period of these contracts.  The transaction prices on these contracts are allocated based on an adjusted market approach which is re-assessed annually for reasonableness.  The field service transactions include contracts for delivery of goods and completion of services made at the customer's requests, which are not deemed satisfied until the work has been completed and/or the requested goods have been delivered, so all of this revenue is recognized at the point in time when the control changes, and at allocated prices based on the adjusted market approach driven by standard price lists. The royalty transactions are related to certain contract terms on transactions in the Company's equipment and systems product line based on activity as specified in the contracts.  The transaction prices of these agreements are calculated based on an adjusted market approach as specified in the contract.  The Company reports royalty revenue for usage-based royalties when the sales have occurred.  In circumstances when collectability is not assured and a contract does not exist under ASC 606, revenue is deferred until a non-refundable payment has been received for substantially all the amount that is due and there are no further remaining performance obligations.

[0001628280-18-013770:notes:143]
[same as prior period, unchanged from 0001628280-18-009847:notes:138]

[0001628280-18-013770:notes:144]
[same as prior period, unchanged from 0001628280-18-009847:notes:139]

[0001628280-18-013770:notes:145]
[same as prior period, unchanged from 0001628280-18-009847:notes:140]

[0001628280-18-013770:notes:146]
[same as prior period, unchanged from 0001628280-18-009847:notes:141]

[0001628280-18-013770:notes:147]
[same as prior period, unchanged from 0001628280-18-009847:notes:142]

[0001628280-18-013770:notes:148]
As of September 30, 2018 and March 31, 2018, the Company’s contract assets and liabilities primarily relate to the timing differences between cash received from a customer in connection with contractual rights to invoicing and the timing of revenue recognition following completion of performance obligations. The Company's accounts receivable balance is made up entirely of customer contract related balances.  Changes in the Company’s contract assets, which are included in “Unbilled AR” and "Deferred program costs" (see Note 7, “Accounts Receivable” and Note 8, "Inventory" for a reconciliation to the condensed consolidated balance sheet) and contract liabilities, which are included in the current portion and long term portion of “deferred revenue” in the Company’s condensed consolidated balance sheets, are as follows:

[0001628280-18-013770:notes:149]
The Company’s remaining performance obligations represent the unrecognized revenue value of the Company’s contractual commitments. The Company’s performance obligations may vary significantly each reporting period based on the timing of major new contractual commitments. As of September 30, 2018, the Company had outstanding performance obligations on existing contracts under ASC 606 to be recognized in the next twelve months of approximately $52.5 million.  There are also approximately $7.1 million of outstanding performance obligations to be recognized over a period of thirteen to sixty months.  The remaining performance obligations are subject to customer actions and therefore the timing of revenue recognition cannot be reasonably estimated.  The twelve month performance obligations include anticipated shipments to Inox based on the twelve month rolling forecast provided by Inox on the multi-year supply contract. The quantities specified in any forecast provided by Inox related to the multi-year supply contract are firm and irrevocable for the first three months of a twelve month rolling forecast. The timing of the performance obligations beyond the Inox twelve month provided forecast are not determinable and therefore are not included in the total remaining performance obligations.

[0001628280-18-013770:notes:150]
The following table sets forth customers who represented 10% or more of the Company’s total revenues for the three and six months ended September 30, 2018 and 2017:

[0001628280-18-013770:notes:151]
|  | Reportable |  | Three months ended September 30, |  | Six months ended September 30, |
|  | Segment |  | 2018 |  | 2017 |  | 2018 |  | 2017 |
| Inox Wind Limited | Wind |  | 45 | % |  | 46 | % |  | 36 | % |  | 35 | % |
| Vestas | Grid |  | 11 | % |  | — | % |  | 23 | % |  | — | % |
| Quanta Power | Grid |  | 12 | % |  | — | % |  | <10% |  |  | — | % |
| U.S. Navy | Grid |  | <10% |  |  | — | % |  | <10% |  |  | 16 | % |
| YMC Inc. | Grid |  | — | % |  | 15 | % |  | — | % |  | <10% |  |


## us-gaap:ScheduleOfSegmentReportingInformationBySegmentTextBlock

[0001628280-18-013770:notes:152]
[same as prior period, unchanged from 0001628280-18-009847:notes:147]

[0001628280-18-013770:notes:153]
|  | Three months ended September 30, |  | Six months ended September 30, |
|  | 2018 |  | 2017 |  | 2018 |  | 2017 |
| Revenues: |  |  |  |  |  |  |  |
| Wind | $ | 7,307 |  |  | $ | 5,554 |  |  | $ | 10,985 |  |  | $ | 7,831 |  |
| Grid | 7,569 |  |  | 5,495 |  |  | 16,498 |  |  | 12,140 |  |
| Total | $ | 14,876 |  |  | $ | 11,049 |  |  | $ | 27,483 |  |  | $ | 19,971 |  |

[0001628280-18-013770:notes:154]
|  | Three months ended September 30, |  | Six months ended September 30, |
|  | 2018 |  | 2017 |  | 2018 |  | 2017 |
| Operating profit/(loss): |  |  |  |  |  |  |  |
| Wind | $ | 28,515 |  |  | $ | (1,440 | ) |  | $ | 27,150 |  |  | $ | (5,873 | ) |
| Grid | (2,870 | ) |  | (6,100 | ) |  | (5,537 | ) |  | (14,268 | ) |
| Unallocated corporate expenses | (918 | ) |  | (265 | ) |  | (2,013 | ) |  | (2,358 | ) |
| Total | $ | 24,727 |  |  | $ | (7,805 | ) |  | $ | 19,600 |  |  | $ | (22,499 | ) |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001628280-18-013770:notes:155]
[same as prior period, unchanged from 0001628280-18-009847:notes:150]

[0001628280-18-013770:notes:156]
[same as prior period, unchanged from 0001628280-18-009847:notes:151]

[0001628280-18-013770:notes:157]
[same as prior period, unchanged from 0001628280-18-009847:notes:152]

[0001628280-18-013770:notes:158]
[same as prior period, unchanged from 0001628280-18-009847:notes:153]

[0001628280-18-013770:notes:159]
The accounting policies of the business segments are the same as those for the consolidated Company. The Company’s business segments have been determined in accordance with the Company’s internal management structure, which is organized based on operating activities. The Company evaluates performance based upon several factors, of which the primary financial measures are segment revenues and segment operating profit (loss). The disaggregated financial results of the segments reflect allocation of certain functional expense categories consistent with the basis and manner in which Company management internally disaggregates financial information for the purpose of assisting in making internal operating decisions. In addition, certain corporate expenses which the Company does not believe are specifically attributable or allocable to either of the two business segments have been excluded from the segment operating profit (loss).

[0001628280-18-013770:notes:160]
Unallocated corporate expenses primarily consist of stock-based compensation expense of $0.8 million and $0.5 million, and restructuring charges of $0.1 million and less than $0.1 million, included in the three months ended September 30, 2018 and 2017, respectively.  Unallocated corporate expenses primarily consist of stock-based compensation expense of $1.6 million and $1.2 million and restructuring charges of $0.4 million and $1.3 million, included in the six months ended September 30, 2018 and 2017, respectively, as well as a gain for the change in fair value of the contingent consideration of $0.2 million in each of the three and six months ended September 30, 2017.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001628280-18-013770:notes:161]
[same as prior period, unchanged from 0001628280-18-009847:notes:156]

[0001628280-18-013770:notes:162]
[same as prior period, unchanged from 0001628280-18-009847:notes:157]

[0001628280-18-013770:notes:163]
On May 5, 2017, the Company entered into an underwriting agreement with Oppenheimer & Co. Inc., as representative of several underwriters named therein, relating to the issuance and sale (the "Offering") of 4.0 million shares of the Company's common stock at a public offering price of $4.00 per share. The net proceeds to the Company from the Offering were approximately $14.7 million, after deducting underwriting discounts and commissions and offering expenses payable by the Company. The Offering closed on May 10, 2017. In addition, the Company granted the underwriters a 30-day option (the “Option”) to purchase up to an additional 600,000 shares of common stock at the same public offering price.  On May 24, 2017, the underwriters notified the Company that they had exercised their Option in full.  The net proceeds to the Company from the Option were approximately $2.3 million, after deducting underwriting discounts and commissions and offering expenses payable by the Company.  The total net proceeds to the Company from the Offering and the Option were approximately $17.0 million, after deducting underwriting discounts and commissions and offering expenses payable by the Company. The Option closed on May 26, 2017. In conjunction with the equity offering, the Company terminated a previous At Market Issuance Sales Agreement ("ATM) with FBR Capital Markets & Co. where the Company could, at its discretion, sell up to $10.0 million of the Company's common stock.


## us-gaap:SubsequentEventsTextBlock

[0001628280-18-013770:notes:164]
Subsequent Events

[0001628280-18-013770:notes:165]
The Company has performed an evaluation of subsequent events through the time of filing this Quarterly Report on Form 10-Q with the SEC and has determined that there are no such events to report.
