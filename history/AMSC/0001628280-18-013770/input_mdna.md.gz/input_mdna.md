# AMSC MD&A — 0001628280-18-013770


## mdna

[0001628280-18-013770:mdna:1]
[same as prior period, unchanged from 0001628280-18-009847:mdna:1]

[0001628280-18-013770:mdna:2]
American Superconductor®, Amperium®, AMSC®, D-VAR®, PowerModule™, D-VAR® VVO, PQ-IVR®, SeaTitan™, Gridtec Solutions™, Windtec Solutions™ and Smarter, Cleaner...Better Energy™ are trademarks or registered trademarks of American Superconductor Corporation or our subsidiaries. We reserve all of our rights with respect to our trademarks or registered

[0001628280-18-013770:mdna:3]
trademarks regardless of whether they are so designated in this Quarterly Report on Form 10-Q by an ® or ™ symbol. All other brand names, product names, trademarks or service marks appearing in this Quarterly Report on Form 10-Q are the property of their respective holders.

[0001628280-18-013770:mdna:4]
[same as prior period, unchanged from 0001628280-18-009847:mdna:4]

[0001628280-18-013770:mdna:5]
[same as prior period, unchanged from 0001628280-18-009847:mdna:5]

[0001628280-18-013770:mdna:6]
[same as prior period, unchanged from 0001628280-18-009847:mdna:6]

[0001628280-18-013770:mdna:7]
We manufacture products using two proprietary core technologies: PowerModule™ programmable power electronic converters and our Amperium® high temperature superconductor (“HTS”) wires. These technologies and our system-level solutions are protected by a broad and deep intellectual property portfolio consisting of hundreds of patents and licenses worldwide.

[0001628280-18-013770:mdna:8]
[same as prior period, unchanged from 0001628280-18-009847:mdna:8]

[0001628280-18-013770:mdna:9]
[same as prior period, unchanged from 0001628280-18-009847:mdna:9]

[0001628280-18-013770:mdna:10]
[same as prior period, unchanged from 0001628280-18-009847:mdna:10]

[0001628280-18-013770:mdna:11]
[same as prior period, unchanged from 0001628280-18-009847:mdna:11]

[0001628280-18-013770:mdna:12]
On July 3, 2018, we and our wholly-owned subsidiaries Suzhou AMSC Superconductor Co. Ltd. (“AMSC China”) and AMSC Austria GMBH (“AMSC Austria”) entered into a settlement agreement (the “Settlement Agreement”) with Sinovel Wind Group Co., Ltd. (“Sinovel”). The Settlement Agreement settles the litigation and arbitration proceedings between us and Sinovel listed on Schedule 2 of the Settlement Agreement (the “Proceedings”), and any other civil claims, counterclaims, causes of action, rights and obligations directly or indirectly relating to the subject matters of the Proceedings and the contracts between us and Sinovel listed on Schedules 1 and 4 of the Settlement Agreement (the “Contracts”), subject to the exception described in Section 1.1 of the Settlement Agreement. The Settlement Agreement was filed as Exhibit 10.1 to the Company’s Form 8-K filed with the Securities and Exchange Commission on July 9, 2018. Under the terms of the Settlement Agreement, Sinovel agreed to pay AMSC China an aggregate cash amount in Renminbi ("RMB") equivalent to $57.5 million, consisting of two installments. Sinovel paid the first installment of $32.5 million on July 4, 2018, and has agreed to pay the second installment of $25.0 million (the “Second Payment”) within ten (10) months after the U.S. District Court for the Western District of Wisconsin (the “District Court”) delivers

[0001628280-18-013770:mdna:13]
the first sentence against Sinovel in the criminal case entitled United States v. Sinovel Wind Co., Ltd., Case Number 3:13-cr-00084-jdp. On July 6, 2018, the District Court delivered such sentence, and therefore the Second Payment is due by May 6, 2019 (the "Second Payment Due Date"). Mr. Wenyuan Wei, former Sinovel chairman and a current Sinovel shareholder, has delivered a letter of guarantee to us for the Second Payment should Sinovel fail to make such payment by the Second Payment Due Date.

[0001628280-18-013770:mdna:14]
In addition, pursuant to the terms of the Settlement Agreement, we and AMSC Austria have granted Sinovel a non-exclusive license for certain of our intellectual property to be used solely in Sinovel’s doubly fed wind turbines (the “License”). We have agreed not to sue Sinovel, Sinovel’s power converter suppliers or Sinovel’s customers for use of the technology covered by the License. In the event that Sinovel or Mr. Wei does not make the Second Payment by the Second Payment Due Date, the Settlement Agreement provides that the License will terminate.  See Note 15 “Commitments and Contingencies” for additional information on the terms of the Settlement Agreement.

[0001628280-18-013770:mdna:15]
[same as prior period, unchanged from 0001628280-18-009847:mdna:16]

[0001628280-18-013770:mdna:16]
[same as prior period, unchanged from 0001628280-18-009847:mdna:17]

[0001628280-18-013770:mdna:17]
The preparation of the unaudited condensed consolidated financial statements requires that we make estimates and judgments that affect the reported amounts of assets, liabilities, revenues and expenses, and related disclosure of contingent assets and liabilities. We base our estimates on historical experience and various other assumptions that are believed to be reasonable under the circumstances, the results of which form the basis for making judgments about the carrying values of assets and liabilities that are not readily apparent from other sources. Actual results may differ under different assumptions or conditions.  During the six months ended September 30, 2018, we adopted ASU 2014-09, which provides for new requirements in regards to revenue recognition.  See Note 2, "Revenue Recognition" for further details.  Aside from the adoption of ASU 2014-09, there were no significant changes in the critical accounting policies that were disclosed in our Form 10-K for fiscal 2017, which ended on March 31, 2018.

[0001628280-18-013770:mdna:18]
[same as prior period, unchanged from 0001628280-18-009847:mdna:19]

[0001628280-18-013770:mdna:19]
Three and six months ended September 30, 2018 compared to the three and six months ended September 30, 2017

[0001628280-18-013770:mdna:20]
[same as prior period, unchanged from 0001628280-18-009847:mdna:21]

[0001628280-18-013770:mdna:21]
Total revenues increased 35% and 38% to $14.9 million and $27.5 million for the three and six months ended September 30, 2018, compared to $11.0 million and $20.0 million for the three and six months ended September 30, 2017.  Our revenues are summarized as follows (in thousands):

[0001628280-18-013770:mdna:22]
|  | Three months ended September 30, |  | Six months ended September 30, |
|  | 2018 |  | 2017 |  | 2018 |  | 2017 |
| Revenues: |  |  |  |  |  |  |  |  |  |
| Wind | $ | 7,307 |  |  | $ | 5,554 |  |  | $ | 10,985 |  |  | $ | 7,831 |  |
| Grid | 7,569 |  |  | 5,495 |  |  | 16,498 |  |  | 12,140 |  |
| Total | $ | 14,876 |  |  | $ | 11,049 |  |  | $ | 27,483 |  |  | $ | 19,971 |  |

[0001628280-18-013770:mdna:23]
Our Wind business unit accounted for 49% and 40% of total revenues for the three and six months ended September 30, 2018, compared to 50% and 39% for the three and six months ended September 30, 2017.  Revenues in the Wind business unit increased 32% and 40% to $7.3 million and $11.0 million in the three and six months ended September 30, 2018, from $5.6 million and $7.8 million in the three and six months ended September 30, 2017. Wind business unit revenues increased due to increased ECS shipments to Inox during the 2018 periods. Inox has been active in the new central and state government auction regime in India and has over 900 MW of orders from the first four SECI central government auctions, and 50 MW from the Maharashtra state government auction. However, we cannot predict if and how successful Inox will be in executing on these orders or in obtaining new orders under the new central and state auction regime. Any failure by Inox to succeed under this regime, or any delay in Inox’s ability to deliver its wind turbines, could result in fewer ECS shipments to Inox.

[0001628280-18-013770:mdna:24]
Our Grid business unit accounted for 51% and 60% of total revenues for the three and six months ended September 30, 2018, compared to 50% and 61% for the three and six months ended September 30, 2017.  Our Grid business unit revenues

[0001628280-18-013770:mdna:25]
increased 38% and 36% to $7.6 million and $16.5 million in the three and six months ended September 30, 2018, from $5.5 million and $12.1 million in the three and six months ended September 30, 2017.  Grid business unit revenues increased primarily due to higher D-VAR system revenues.

[0001628280-18-013770:mdna:26]
The following table sets forth customers who represented 10% or more of our total revenues for the three and six months ended September 30, 2018 and 2017:

[0001628280-18-013770:mdna:27]
|  | Reportable | Three months ended September 30, |  | Six months ended September 30, |
|  | Segment | 2018 |  | 2017 |  | 2018 |  | 2017 |
| Inox Wind Limited | Wind | 45 | % |  | 46 | % |  | 36 | % |  | 35 | % |
| Vestas | Grid | 11 | % |  | — | % |  | 23 | % |  | — | % |
| Quanta Power | Grid | 12 | % |  | — | % |  | <10% |  |  | — | % |
| U.S. Navy | Grid | <10% |  |  | — | % |  | <10% |  |  | 16 | % |
| YMC Inc. | Grid | — | % |  | 15 | % |  | — | % |  | <10% |  |

[0001628280-18-013770:mdna:28]
[same as prior period, unchanged from 0001628280-18-009847:mdna:28]

[0001628280-18-013770:mdna:29]
Cost of revenues increased by 4% to $11.3 million for the three months ended September 30, 2018, compared to $10.8 million for the three months ended September 30, 2017. Cost of revenues decreased by 17% to $20.0 million for the six months ended September 30, 2018, compared to $24.2 million for the six months ended September 30, 2017.  Gross margin was 24% for the three months ended September 30, 2018, compared to 2% for the three months ended September 30, 2017.  Gross margin was 27% for the six months ended September 30, 2018, compared to (21)% for the six months ended September 30, 2017.  The increases in gross margin in both the three and six month periods were due to increased revenues, a more favorable product mix, lower depreciation and reduced fixed factory overhead.

[0001628280-18-013770:mdna:30]
[same as prior period, unchanged from 0001628280-18-009847:mdna:30]

[0001628280-18-013770:mdna:31]
[same as prior period, unchanged from 0001628280-18-009847:mdna:31]

[0001628280-18-013770:mdna:32]
R&D expenses decreased in the three and six months ended September 30, 2018 by 23% and 10% to $2.3 million and $5.1 million from $3.0 million and $5.7 million for the three and six months ended September 30, 2017.  The decreases in R&D expenses were primarily due to decreased compensation expense.

[0001628280-18-013770:mdna:33]
[same as prior period, unchanged from 0001628280-18-009847:mdna:33]

[0001628280-18-013770:mdna:34]
SG&A expenses decreased by 3% and 4% to $5.2 million and $11.0 million in the three and six months ended September 30, 2018, from $5.3 million and $11.5 million in the three and six months ended September 30, 2017. The decrease in SG&A expenses was due primarily to reduced overall compensation expense.

[0001628280-18-013770:mdna:35]
Gain on Sinovel settlement

[0001628280-18-013770:mdna:36]
We recorded a gain of $28.7 million, net of legal and other direct costs, in each of the three and six months ended September 30, 2018 as a result of the receipt of the first payment from Sinovel required by the Settlement Agreement in July 2018.

[0001628280-18-013770:mdna:37]
[same as prior period, unchanged from 0001628280-18-009847:mdna:35]

[0001628280-18-013770:mdna:38]
We recorded amortization expense related to our core technology and know-how, trade names and trademark intangible assets of $0.1 million and $0.2 million in the three and six months ended September 30, 2018, and less than $0.1 million in each of the three and six months ended September 30, 2017.

[0001628280-18-013770:mdna:39]
[same as prior period, unchanged from 0001628280-18-009847:mdna:37]

[0001628280-18-013770:mdna:40]
We recorded $0.1 million and $0.4 million for facility exit costs in the three and six months ended September 30, 2018 as a result of the move of the corporate office that was announced as part of our April 4, 2017 approved restructuring plan.  We recorded a restructuring charge of $1.3 million for severance costs in the six months ended September 30, 2017 as a result of the reduction in force also announced on April 4, 2017. Included in the $1.3 million severance pay charged to operations in the six months ended September 30, 2017, is $0.5 million of severance pay for one of our former executive officers pursuant to the terms of a severance agreement dated June 30, 2017.  Under the terms of the severance agreement, our former executive officer is entitled

[0001628280-18-013770:mdna:41]
to eighteen months of his base salary, which is expected to be paid by December 31, 2018.  From and after January 1, 2018, at our discretion, we may settle any remaining unpaid cash severance owed to our former executive officer through the issuance of a number of immediately vested shares of our common stock, determined by multiplying the remaining unpaid cash severance owed by 120%, and then dividing by the closing stock price per share of our common stock as of the last business day prior to the issuance of the shares.

[0001628280-18-013770:mdna:42]
Operating profit/(loss)

[0001628280-18-013770:mdna:43]
Our operating profit/(loss) is summarized as follows (in thousands):

[0001628280-18-013770:mdna:44]
|  | Three months ended September 30, |  | Six months ended September 30, |
|  | 2018 |  | 2017 |  | 2018 |  | 2017 |
| Operating profit/(loss): |  |  |  |  |  |  |  |
| Wind | $ | 28,515 |  |  | $ | (1,440 | ) |  | $ | 27,150 |  |  | $ | (5,873 | ) |
| Grid | (2,870 | ) |  | (6,100 | ) |  | (5,537 | ) |  | (14,268 | ) |
| Unallocated corporate expenses | (918 | ) |  | (265 | ) |  | (2,013 | ) |  | (2,358 | ) |
| Total | $ | 24,727 |  |  | $ | (7,805 | ) |  | $ | 19,600 |  |  | $ | (22,499 | ) |

[0001628280-18-013770:mdna:45]
Our Wind segment generated operating income of $28.5 million and $27.1 million in the three and six months ended September 30, 2018, compared to losses of $1.4 million and $5.9 million in the three and six months ended September 30, 2017. The increase in the Wind business unit operating income was due primarily to the receipt of the first payment from Sinovel required by the Settlement Agreement in July 2018 as well as increased shipments of ECS to Inox.

[0001628280-18-013770:mdna:46]
Our Grid segment generated operating losses of $2.9 million and $5.5 million in the three and six months ended September 30, 2018, compared to losses of $6.1 million and $14.3 million in the three and six months ended September 30, 2017.  The decrease in the Grid business unit operating losses was due primarily to increased D-VAR revenues, a more favorable product mix, lower depreciation and lower operating expenses compared to the prior year period.

[0001628280-18-013770:mdna:47]
Unallocated corporate expenses primarily consist of stock-based compensation expense of $0.8 million and $0.5 million, and restructuring charges of $0.1 million and less than $0.1 million, included in the three months ended September 30, 2018 and 2017, respectively.  Unallocated corporate expenses primarily consist of stock-based compensation expense of $1.6 million and $1.2 million and restructuring charges of $0.4 million and $1.3 million included in the six months ended September 30, 2018 and 2017, respectively, as well as a gain for the change in fair value of contingent consideration of $0.2 million in each of the three and six months ended September 30, 2017.

[0001628280-18-013770:mdna:48]
[same as prior period, unchanged from 0001628280-18-009847:mdna:45]

[0001628280-18-013770:mdna:49]
The change in fair value of warrants resulted in a gain of $0.3 million and loss of $0.2 million in the three and six months ended September 30, 2018, compared to a gain of $0.1 million and $1.1 million in the three and six months ended September 30, 2017.  The change in the fair value was primarily driven by changes in stock price, which is a key valuation metric.

[0001628280-18-013770:mdna:50]
Interest income, net

[0001628280-18-013770:mdna:51]
Interest income, net, was $0.2 million and $0.4 million in the three and six months ended September 30, 2018, compared to $0.1 million and less than $0.1 million in the three and six months ended September 30, 2017. The increase in interest income was primarily related to imputed interest earned in relation to the outstanding note receivable for the sale of the 64 Jackson Road building.

[0001628280-18-013770:mdna:52]
[same as prior period, unchanged from 0001628280-18-009847:mdna:49]

[0001628280-18-013770:mdna:53]
Other income (expense), net, was income of $0.3 million and $0.9 million in the three and six months ended September 30, 2018, compared to expense of $0.8 million and $2.2 million in the three and six months ended September 30, 2017.  The increase in other income, net, during the three and six months ended September 30, 2018, was primarily driven by higher foreign currency gains.

[0001628280-18-013770:mdna:54]
[same as prior period, unchanged from 0001628280-18-009847:mdna:51]

[0001628280-18-013770:mdna:55]
Income tax expense was $3.0 million in the three and six months ended September 30, 2018, compared to income tax benefit of $0.2 million and $0.1 million in the three and six months ended September 30, 2017. The increase in income tax expense was primarily due to the repayment of previously reserved intercompany trade balances due to AMSC Austria from AMSC China, and a dividend paid by AMSC Austria to us in the three months ended September 30, 2018 following the Sinovel settlement.

[0001628280-18-013770:mdna:56]
[same as prior period, unchanged from 0001628280-18-009847:mdna:53]

[0001628280-18-013770:mdna:57]
[same as prior period, unchanged from 0001628280-18-009847:mdna:54]

[0001628280-18-013770:mdna:58]
We define non-GAAP net loss as net loss before stock-based compensation, gain on Sinovel settlement, amortization of acquisition-related intangibles, changes in fair value of warrants and contingent consideration, non-cash interest expense, tax effect of adjustments, and the other non-cash or unusual charges, indicated in the table below. We believe non-GAAP net loss assists management and investors in comparing our performance across reporting periods on a consistent basis by excluding these non-cash or non-recurring charges that we do not believe are indicative of our core operating performance. A reconciliation of GAAP to non-GAAP net loss is set forth in the table below (in thousands, except per share data):

[0001628280-18-013770:mdna:59]
|  | Three months ended September 30, |  | Six months ended September 30, |
|  | 2018 |  | 2017 |  | 2018 |  | 2017 |
| Net income (loss) | $ | 22,558 |  |  | $ | (7,281 | ) |  | $ | 17,821 |  |  | $ | (22,533 | ) |
| Sale of minority investments | — |  |  | (951 | ) |  | — |  |  | (951 | ) |
| Stock-based compensation | 825 |  |  | 478 |  |  | 1,610 |  |  | 1,232 |  |
| (Gain) on Sinovel settlement, net | (28,720 | ) |  | — |  |  | (28,720 | ) |  | — |  |
| Amortization of acquisition-related intangibles | 85 |  |  | — |  |  | 170 |  |  | 13 |  |
| Change in fair value of warrants and contingent consideration | (282 | ) |  | (346 | ) |  | 182 |  |  | (1,270 | ) |
| Non-cash interest expense | — |  |  | — |  |  | — |  |  | 19 |  |
| Tax effect of adjustments | 2,829 |  |  | 114 |  |  | 2,829 |  |  | 123 |  |
| Non-GAAP net loss | $ | (2,705 | ) |  | $ | (7,986 | ) |  | $ | (6,108 | ) |  | $ | (23,367 | ) |
| Non-GAAP net loss per share - basic | $ | (0.13 | ) |  | $ | (0.42 | ) |  | $ | (0.30 | ) |  | $ | (1.30 | ) |
| Non-GAAP net loss per share - diluted | $ | (0.13 | ) |  | $ | (0.42 | ) |  | $ | (0.30 | ) |  | $ | (1.30 | ) |
| Weighted average shares outstanding - basic | 20,313 |  |  | 19,060 |  |  | 20,240 |  |  | 17,925 |  |
| Weighted average shares outstanding - diluted | 20,313 |  |  | 19,060 |  |  | 20,240 |  |  | 17,925 |  |

[0001628280-18-013770:mdna:60]
We incurred non-GAAP net losses of $2.7 million and $6.1 million or $0.13 and $0.30 per share, for the three and six months ended September 30, 2018, compared to non-GAAP net losses of $8.0 million and $23.4 million or $0.42 and $1.30 per share for the three and six months ended September 30, 2017. The decrease in non-GAAP net loss was driven primarily by an increase in net income driven by higher revenues.

[0001628280-18-013770:mdna:61]
We define non-GAAP operating cash flow as operating cash flow before: the gain on Sinovel settlement (net of legal fees and expenses); tax effect of adjustments; and other unusual cash flows or items. We believe non-GAAP operating cash flow assists management and investors in comparing our operating cash flow across reporting periods on a consistent basis by excluding these non-recurring cash items that it does not believe are indicative of our core operating cash flow. A reconciliation of GAAP to non-GAAP operating cash flow is set forth in the table below (in thousands, except per share data).

[0001628280-18-013770:mdna:62]
30

[0001628280-18-013770:mdna:63]
|  | Three months ending |
|  | September 30, 2018 |
| Operating cash flow | $30,481 |
| Sinovel settlement (net of legal fees and expenses) | (30,336 | ) |
| Tax effect of adjustments | 1,247 |  |
| Non-GAAP operating cash flow | $1,392 |

[0001628280-18-013770:mdna:64]
[same as prior period, unchanged from 0001628280-18-009847:mdna:58]

[0001628280-18-013770:mdna:65]
We have experienced recurring operating losses and as of September 30, 2018 had an accumulated deficit of $970.5 million. In addition, although we generated positive operating cash flows in the six month period ended September 30, 2018, we have historically experienced recurring negative operating cash flows. Although our sales to Inox increased in the six months ended September 30, 2018 compared to the six months ended September 30, 2017, we cannot predict if and how successful Inox will be in executing on SECI orders or in obtaining additional orders under the new central and state auction regime. Any failure by Inox to succeed under this regime, or any delay in Inox’s ability to deliver its wind turbines, could result in fewer ECS shipments to Inox.

[0001628280-18-013770:mdna:66]
Our cash requirements depend on numerous factors, including whether Inox is successful under the new central and state auction regime as noted above, our ability to collect the Second Payment from Sinovel, the successful completion of our product development activities, our ability to commercialize our Resilient Electric Grid (“REG”) and ship protection system solutions, the rate of customer and market adoption of our products, collecting receivables according to established terms, and the continued availability of U.S. government funding during the product development phase of our superconductor-based products.  We continue to closely monitor our expenses and, if required, expect to further reduce our operating and capital spending to enhance liquidity.

[0001628280-18-013770:mdna:67]
As of September 30, 2018, we had cash, cash equivalents, and restricted cash of $56.3 million, compared to $34.2 million as of March 31, 2018, an increase of $22.1 million.  As of September 30, 2018, we had approximately $5.9 million of cash, cash equivalents, and restricted cash in foreign bank accounts.  Our cash and cash equivalents, and restricted cash are summarized as follows (in thousands):

[0001628280-18-013770:mdna:68]
|  | September 30, 2018 |  | March 31,2018 |
| Cash and cash equivalents | $ | 56,169 |  |  | $ | 34,084 |  |
| Restricted cash | 165 |  |  | 165 |  |
| Total cash, cash equivalents, and restricted cash | $ | 56,334 |  |  | $ | 34,249 |  |

[0001628280-18-013770:mdna:69]
For the six months ended September 30, 2018, net cash provided by operating activities was $23.6 million compared to $13.5 million of net cash used for the six months ended September 30, 2017. The increase in net cash provided by operations was due primarily to the receipt of the first payment from the Sinovel settlement.

[0001628280-18-013770:mdna:70]
For the six months ended September 30, 2018, net cash used in investing activities was $0.4 million, compared to net cash provided by investing activities of $0.5 million for the six months ended September 30, 2017. The decrease in net cash provided by investing activities was due primarily to the proceeds from the sale of minority interest in the prior year period which did not occur in the current year period.

[0001628280-18-013770:mdna:71]
For the six months ended September 30, 2018, net cash used in financing activities was $0.3 million compared to net cash provided by financing activities of $15.2 million in the six months ended September 30, 2017. The decrease in net cash provided by financing activities was primarily due to net proceeds of $17.0 million from the issuance of 4.6 million shares of common stock in May 2017, with no such equity offering in the current year period.

[0001628280-18-013770:mdna:72]
As of September 30, 2018, we had $0.2 million of restricted cash included in long-term assets. These amounts included in restricted cash primarily represent deposits to secure letters of credit for various supply contracts. These deposits are held in interest bearing accounts.

[0001628280-18-013770:mdna:73]
[same as prior period, unchanged from 0001628280-18-009847:mdna:70]

[0001628280-18-013770:mdna:74]
Legal Proceedings

[0001628280-18-013770:mdna:75]
We are involved in legal and administrative proceedings and claims of various types. See Part II, Item 1, “Legal Proceedings,” for additional information. We record a liability in our consolidated financial statements for these matters when a loss is known or considered probable and the amount can be reasonably estimated. We review these estimates each accounting period as additional information is known and adjust the loss provision when appropriate. If a matter is both probable to result in liability and the amounts of loss can be reasonably estimated, we estimate and disclose the possible loss or range of loss to the extent necessary to make the consolidated financial statements not misleading. If the loss is not probable or cannot be reasonably estimated, a liability is not recorded in our consolidated financial statements.

[0001628280-18-013770:mdna:76]
[same as prior period, unchanged from 0001628280-18-009847:mdna:73]

[0001628280-18-013770:mdna:77]
[same as prior period, unchanged from 0001628280-18-009847:mdna:74]

[0001628280-18-013770:mdna:78]
[same as prior period, unchanged from 0001628280-18-009847:mdna:75]

[0001628280-18-013770:mdna:79]
[same as prior period, unchanged from 0001628280-18-009847:mdna:76]

[0001628280-18-013770:mdna:80]
[same as prior period, unchanged from 0001628280-18-009847:mdna:77]

[0001628280-18-013770:mdna:81]
In May 2014, the Financial Accounting Standards Board (“FASB”) and the International Accounting Standards Board ("IASB") issued Accounting Standards Update ("ASU") 2014-09, Revenue from Contracts with Customers (Topic 606). The guidance substantially converges final standards on revenue recognition between the FASB and IASB providing a framework on addressing revenue recognition issues and, upon its effective date, replaces almost all existing revenue recognition guidance, including industry-specific guidance, in current U.S. generally accepted accounting principles. The FASB has subsequently issued the following multiple amendments to ASU 2014-09 which are all effective for annual reporting periods beginning after December 15, 2017.

[0001628280-18-013770:mdna:82]
As of April 1, 2018, we have adopted ASU 2014-09 and its amendments, reported the impact in our consolidated financial statements, and implemented changes to our business processes, systems and controls to support revenue recognition and the related disclosures under this ASU.  Our assessment included a detailed review of representative contracts from each of our revenue streams and a comparison of our historical accounting policies and practices to the new standard. We adopted the new standards retrospectively with the cumulative effect of initially applying the guidance recognized at the date of initial application (the modified retrospective transition method) to all existing contracts that have remaining obligations as of April 1, 2018.  Accordingly, we have elected to retroactively adjust only those contracts that do not meet the definition of a complete contract at the date of the initial application.  This guidance will lead to recognizing certain revenue transactions sooner than in the past on certain contracts, as we will need to estimate the revenue we will be entitled to upon contract completion, and later on other contracts, such as Consulting and Statement of Work transactions, due to the lack of an enforceable right to payment for performance obligations satisfied over time. There are no changes in the accounting for our largest revenue stream which includes Inox Wind Ltd as our primary customer.  Across other revenue streams such as D-VAR® Equipment and D-VAR® Turnkey, the timing of revenue recognition will be affected for multiple types of contracts, primarily multiple performance obligation contracts in our Grid business unit, but those differences did not have a material impact on our consolidated financial statements.  The adjustment to opening retained earnings was not significant for the period commencing on April 1, 2018.  Additionally, the adoption of this new standard is not expected to have any tax impact on the consolidated financial statements. As part of this analysis, we evaluated our information technology capabilities and systems, and did not incur significant information technology costs to modify systems currently in place.

[0001628280-18-013770:mdna:83]
In January 2016, the FASB issued ASU 2016-01, Financial Instruments-Overall (Subtopic 825-10): Recognition and Measurement of Financial Assets and Financial Liabilities.  The amendments in ASU 2016-01 enhance the reporting model for financial instruments to provide users of financial statements with more decision-useful information. This ASU is effective for annual reporting periods beginning after December 15, 2017, and interim periods within those fiscal years.  We adopted ASU 2016-01 effective April 1, 2018 and noted no significant impact to our consolidated financial statements.

[0001628280-18-013770:mdna:84]
In February 2016, the FASB issued ASU 2016-02, Leases (Topic 842). The guidance in this ASU supersedes the leasing guidance in Topic 840, Leases. Under the new guidance, lessees are required to recognize lease assets and lease liabilities on the balance sheet for all leases with terms longer than 12 months. Leases will be classified as either finance or operating, with classification affecting the pattern of expense recognition in the income statement.  This ASU and its amendments are effective for fiscal years beginning after December 15, 2018, including interim periods within those fiscal years.

[0001628280-18-013770:mdna:85]
| • | In July 2018, the FASB issued ASU 2018-10, Codification improvements to Topic 842, Leases. The amendments in ASU 2018-10 provide more clarification in regards to the application and requirements of ASU 2016-02. |

[0001628280-18-013770:mdna:86]
| • | In July 2018, the FASB issued ASU 2018-11, Topic 842, Leases - Targeted improvements. The amendments in ASU 2018-11 provide for the option to adopt the standard prospectively and recognize a cumulative-effect adjustment to the opening balance of retained earnings as well as offer a new practical expedient that will allow us to elect, by class of underlying asset, to not separate non-lease and lease components in certain circumstances and instead to account for those components as a single item. |

[0001628280-18-013770:mdna:87]
We are currently evaluating the provisions of ASU 2016-02 and its amendments, and assessing the impact the adoption of this guidance will have on our financial position, results of operations and disclosures.  This process has included identifying the implementation team, applying the revised definition of a lease per Accounting Standards Codification ("ASC") 842 to existing agreements and, from that information, creating a preliminary population.  This population includes agreements identified from the following sources: existing leases under ASC 840, general ledger activity from recurring vendors and information reported from a survey provided to key individuals within the company. We intend to make the policy election to exclude all leases shorter than 12 months from the recognition of the recording of the right of use ("ROU") asset and related liabilities.  We expect to elect the package of three practical expedients in regards to all leases that commenced before the effective date as well as the practical expedient that allows the use of hindsight in determining lease term.  We anticipate the adoption of this guidance will result in certain changes to our financial statements to add the related asset and liability accounts for all of our operating leases. We will continue to assess our agreements for any other impacts that may result from the adoption of this standard. During the second half of fiscal 2018, we plan to finalize our population of leases including the classification of type of lease for each of those agreements and assess our current controls, as well as identify and implement any changes that may be necessary to comply with the provisions of ASU 2016-02, which will be effective on April 1, 2019.

[0001628280-18-013770:mdna:88]
We are required to adopt the new standards in the first quarter of fiscal 2019 and expect to do so using the modified retrospective transition method, which will impact all leases existing at, or entered into after the period of adoption.  For all leases existing at the time of adoption we will recognize a cumulative effect adjustment to the opening balance of retained earnings as of April 1, 2019. We are still evaluating the final impact of this adoption method on our consolidated financial statements.

[0001628280-18-013770:mdna:89]
In June 2016, the FASB issued ASU 2016-13, Financial Instruments-Credit Losses (Topic 326): Measurement of Credit Losses on Financial Instruments.  The amendments in ASU 2016-13 provide more decision-useful information about the expected credit losses on financial instruments and other commitments to extend credit held by a reporting entity at each reporting date. The ASU is effective for annual reporting periods beginning after December 15, 2019, including interim periods within that year.  We are currently evaluating the impact, if any, the adoption of ASU 2016-13 may have on our consolidated financial statements.

[0001628280-18-013770:mdna:90]
[same as prior period, unchanged from 0001628280-18-009847:mdna:85]

[0001628280-18-013770:mdna:91]
| • | In August 2016, the FASB issued ASU 2016-15, Statement of Cash Flows (Topic 230): Classification of Certain Cash Receipts and Cash Payments. The amendments in ASU 2016-15 provide more guidance towards the classification of multiple different types of cash flows in order to reduce the diversity in reporting across entities. |

[0001628280-18-013770:mdna:92]
| • | In November 2016, the FASB issued ASU 2016-18, Statement of Cash Flows (Topic 230): Restricted Cash. The amendments in ASU 2016-18 explain the change during the period in the total of cash, cash equivalents, and amounts generally described as restricted cash or restricted cash equivalents. Therefore, amounts generally described as restricted cash and restricted cash equivalents should be included with cash and cash equivalents when reconciling the beginning-of-period and end-of-period total amounts shown on the statement of cash flows. |

[0001628280-18-013770:mdna:93]
[same as prior period, unchanged from 0001628280-18-009847:mdna:97]

[0001628280-18-013770:mdna:94]
We adopted ASU 2016-15 and ASU 2016-18 effective April 1, 2018 and noted no significant impact to our consolidated financial statements.

[0001628280-18-013770:mdna:95]
In October 2016, the FASB issued ASU 2016-16, Income Taxes (Topic 740): Intra-Entity Transfers of Assets Other Than Inventory.  The amendments in ASU 2016-16 improve the accounting for the income tax consequences of intra-entity transfers of assets other than inventory. The ASU is effective for annual reporting periods beginning after December 15, 2017, including interim periods within that year.  We adopted of ASU 2016-16 effective April 1, 2018 and noted no significant impact to our consolidated financial statements.

[0001628280-18-013770:mdna:96]
In February 2017, the FASB issued ASU 2017-05, Other Income - Gains and Losses from the Derecognition of Non-financial Assets (Subtopic 610-20).  The amendments in ASU 2017-05 clarify the scope of Subtopic 610-20, Other Income-Gains and Losses from the Derecognition of Non-financial Assets, and to add guidance for partial sales of non-financial assets. Subtopic 610-20, which was issued in May 2014 as a part of ASU No. 2014-09, Revenue from Contracts with Customers (Topic 606), provides guidance for recognizing gains and losses from the transfer of non-financial assets in contracts with non-customers.  We adopted ASU 2017-05 effective April 1, 2018 and adjusted the opening balance of accumulated deficit for $0.1 million for recognition of the deferred gain on the sale of the 64 Jackson Road building that occurred on March 28, 2018.

[0001628280-18-013770:mdna:97]
In May 2017, the FASB issued ASU 2017-09, Compensation - Stock Compensation (Subtopic 718) Scope of Modification Accounting.  The amendments in ASU 2017-09 provide clarity and reduce both (1) diversity in practice and (2) cost and complexity when applying the guidance in Topic 718, Compensation—Stock Compensation, to a change to the terms or conditions of a share-based payment award.  The ASU is effective for annual reporting periods beginning after December 15, 2017, including interim periods within those periods. We adopted ASU 2017-09 effective April 1, 2018 and noted no significant impact to our consolidated financial statements.

[0001628280-18-013770:mdna:98]
In July 2017, the FASB issued ASU 2017-11, Earnings per Share (Topic 260), Distinguishing Liabilities from Equity (Topic   480), and Derivatives and Hedging (Topic 815).  The amendments in ASU 2017-11 provide guidance for freestanding equity-linked financial instruments, such as warrants and conversion options in convertible debt or preferred stock, and should no longer be accounted for as a derivative liability at fair value as a result of the existence of a down round feature.  The ASU is effective for annual reporting periods beginning after December 15, 2018, including interim periods within those periods. We are currently evaluating the impact the adoption of ASU 2017-11 and do not expect a significant impact on our consolidated financial statements, primarily due to the put option feature which requires continued liability classification under ASC 840.

[0001628280-18-013770:mdna:99]
In August 2017, the FASB issued ASU 2017-12, Derivatives and Hedging (Topic 815): Targeted Improvements to Accounting for Hedging Activities.  The amendments in ASU 2017-12 provide improved financial reporting of hedging relationships to better portray the economic results of an entity’s risk management activities in its financial statements. In addition, the amendments in this update make certain targeted improvements to simplify the application of the hedge accounting guidance.  The ASU is effective for annual reporting periods beginning after December 15, 2018, including interim periods within those periods. We are currently evaluating the impact the adoption of ASU 2017-12 may have on our consolidated financial statements.

[0001628280-18-013770:mdna:100]
In June 2018, the FASB issued ASU 2018-07, Compensation - Stock Compensation (Topic 718): Improvements to Non-Employee Share Based Payment Accounting.  The amendments in ASU 2018-07 provide for the simplification of the measurement of share-based payment transactions for acquiring goods and services from non-employees.  The ASU is effective for annual reporting periods beginning after December 15, 2018, including interim periods within those periods. We are currently evaluating the impact the adoption of ASU 2018-07 and do not expect it to have a significant impact on our consolidated financial statements.

[0001628280-18-013770:mdna:101]
In August 2018, the FASB issued ASU 2018-13, Fair Value Measurement (Topic 820): Changes to the Disclosure Requirements for Fair Value Measurement.  The amendments in ASU 2018-13 provide for increased effectiveness of the disclosures made around fair value measurements while including consideration for costs and benefits.  The ASU is effective for annual reporting periods beginning after December 15, 2019, including interim periods within those periods. We are currently evaluating the impact the adoption of ASU 2018-13 may have on our consolidated financial statements.

[0001628280-18-013770:mdna:102]
We do not believe that, outside of those disclosed here, there are any other recently issued accounting pronouncements that will have a material impact on our consolidated financial statements.
