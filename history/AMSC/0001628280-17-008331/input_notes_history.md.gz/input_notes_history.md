# AMSC note change history — 0001628280-17-000901 → 0001628280-17-008331


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2017-08-08):
[0001628280-17-008331:note_history:1]
As of June 30, 2017, the Company had $0.1 million of restricted cash included in current assets and $0.2 million of restricted cash included in long-term assets. These amounts included in restricted cash primarily represent deposits to secure letters of credit for various supply contracts. These deposits are held in interest bearing accounts.
  (was, 2017-02-06, similarity 0.9821):
[0001628280-17-000901:note_history:1]
As of December 31, 2016, the Company had $0.8 million of restricted cash included in current assets and $0.1 million of restricted cash included in long-term assets. These amounts included in restricted cash primarily represent deposits to secure letters of credit for various supply contracts. These deposits are held in interest bearing accounts.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2017-08-08):
[0001628280-17-008331:note_history:2]
These unaudited condensed consolidated financial statements of the Company have been prepared on a going concern basis in accordance with United States generally accepted accounting principles (“GAAP”) and the Securities and Exchange Commission’s (“SEC”) instructions to Form 10-Q. The going concern basis of presentation assumes that the Company will continue operations and will be able to realize its assets and discharge its liabilities and commitments in the normal course of business. Certain information and footnote disclosures normally included in the financial statements prepared in accordance with GAAP have been condensed or omitted pursuant to those instructions. The year-end condensed balance sheet data was derived from audited financial statements but does not include all disclosures required by GAAP. The unaudited condensed consolidated financial statements, in the opinion of management, reflect all adjustments (consisting of normal recurring adjustments) necessary for a fair statement of the results for the interim periods ended June 30, 2017 and 2016 and the financial position at June 30, 2017.
  (was, 2017-02-06, similarity 0.9892):
[0001628280-17-000901:note_history:2]
These unaudited condensed consolidated financial statements of the Company have been prepared on a going concern basis in accordance with United States generally accepted accounting principles (“GAAP”) and the Securities and Exchange Commission’s (“SEC”) instructions to Form 10-Q. The going concern basis of presentation assumes that the Company will continue operations and will be able to realize its assets and discharge its liabilities and commitments in the normal course of business. Certain information and footnote disclosures normally included in the financial statements prepared in accordance with GAAP have been condensed or omitted pursuant to those instructions. The year-end condensed balance sheet data was derived from audited financial statements but does not include all disclosures required by GAAP. The unaudited condensed consolidated financial statements, in the opinion of management, reflect all adjustments (consisting of normal recurring adjustments) necessary for a fair statement of the results for the interim periods ended December 31, 2016 and 2015 and the financial position at December 31, 2016.

- changed (2017-08-08):
[0001628280-17-008331:note_history:3]
The Company has experienced recurring operating losses and as of June 30, 2017, the Company had an accumulated deficit of $970.8 million. In addition, the Company has experienced recurring negative operating cash flows.  At June 30, 2017, the Company had cash and cash equivalents of $37.5 million. Cash used in operations for the three months ended June 30, 2017 was $5.4 million.
  (was, 2017-02-06, similarity 0.8985):
[0001628280-17-000901:note_history:3]
The Company has experienced recurring operating losses and as of December 31, 2016, the Company had an accumulated deficit of $948.6 million. In addition, the Company has experienced recurring negative operating cash flows.  At December 31, 2016, the Company had cash and cash equivalents of $25.1 million. Cash used in operations for the nine months ended December 31, 2016 was $10.5 million.

- added (2017-08-08):
[0001628280-17-008331:note_history:4]
From April 1, 2011 through the date of this filing, the Company has reduced its global workforce substantially, including a restructuring action announced on April 4, 2017 which led to a $1.3 million restructuring charge in the three months ended June 30, 2017.  See Note 13 "Restructuring" for further discussion of this action.  The Company has taken actions to consolidate certain business operations to reduce facility costs.  As of June 30, 2017, the Company had a global workforce of 326 persons.  The Company plans to closely monitor its expenses and, if required, expects to further reduce operating costs and capital spending to enhance liquidity.

- added (2017-08-08):
[0001628280-17-008331:note_history:5]
Over the last several years, the Company has entered into several debt and equity financing arrangements in order to enhance liquidity.  Since April 1, 2012, the Company has generated aggregate cash flows from financing activities of $85.0 million.  Included in this amount are proceeds of approximately $17.0 million after deducting underwriting discounts and commissions and offering expenses payable by the Company, from the Company's equity offering completed on May 10, 2017, which includes the subsequent exercise by the underwriters of their option in full to purchase additional shares.  The Company terminated its At Market Issuance Sales Agreement ("ATM") with FBR Capital Markets & Co in conjunction with this equity offering.  See Note 12 “Stockholders Equity” for further discussion of these financing arrangements.

- added (2017-08-08):
[0001628280-17-008331:note_history:6]
In December 2015, the Company entered into a set of strategic agreements valued at approximately $210.0 million with Inox Wind Ltd. (“Inox”), which includes a multi-year supply contract pursuant to which the Company will supply electric control systems to Inox and a license agreement allowing Inox to manufacture a limited number of electrical control systems.  After Inox purchases the specified number of electrical control systems required under the terms of the supply contract, Inox agreed that the Company will continue as Inox’s preferred supplier and Inox will be required to purchase from the Company a majority of its electric control systems requirements for an additional three-year period.

- added (2017-08-08):
[0001628280-17-008331:note_history:7]
The Company believes based on the information presented above, and its quarterly management assessment, that it has sufficient liquidity to fund its operations and capital expenditures for the next twelve months following the issuance of the financial statements for the three months ended June 30, 2017. The Company’s liquidity is highly dependent on its ability to increase revenues, its ability to control its operating costs, and its ability to raise additional capital, if necessary. There can be no assurance that the Company will be able to continue to raise additional capital from other sources or execute on any other means of improving liquidity described above.

- removed (2017-08-08):
[0001628280-17-000901:note_history:8]
From April 1, 2011 through the date of this filing, the Company has reduced its global workforce substantially.  The Company has taken actions to consolidate certain business operations to reduce facility costs.  As of December 31, 2016, the Company had a global workforce of 366 persons.  The Company plans to closely monitor its expenses and, if required, expects to further reduce operating costs and capital spending to enhance liquidity.

- removed (2017-08-08):
[0001628280-17-000901:note_history:9]
Over the last several years, the Company has entered into several debt and equity financing arrangements in order to enhance liquidity.  Since April 1, 2012, the Company has generated aggregate cash flows from financing activities of $67.3 million.  This amount includes proceeds from an April 2015 equity offering, which generated net proceeds of approximately $22.3 million, after deducting underwriting discounts and commissions and estimated offering expenses payable by the Company.  See Note 9, “Debt”, and Note 11 “Stockholders Equity” for further discussion of these financing arrangements. The Company believes that it is in compliance with the covenants and restrictions included in the agreements governing its debt arrangements as of December 31, 2016.

- removed (2017-08-08):
[0001628280-17-000901:note_history:10]
In December 2015, the Company entered into a set of strategic agreements valued at approximately $210.0 million with Inox Wind Ltd. (“Inox”), which includes a multi-year supply contract pursuant to which the Company will supply electric control systems to Inox and a license agreement allowing Inox to manufacture a limited number of electrical control systems over the following three to four years.  After this initial three to four year period, Inox agreed that the Company will continue as Inox’s preferred supplier and Inox will be required to purchase from the Company a majority of its electric control systems requirements for an additional three-year period.  These agreements are expected to provide a foundation for the business as the Company pursues its longer-term objectives.

- removed (2017-08-08):
[0001628280-17-000901:note_history:11]
On March 11, 2016, the Company sold 100% of its minority share investment in Tres Amigas LLC ("Tres Amigas") to an investor for $0.6 million.  The Company received $0.3 million according to the terms of the purchase agreement upon closing, which was recorded as a gain during the three months ended March 31, 2016.  The final $0.3 million was received and recorded as a gain during the third quarter of fiscal 2016.  See Note 13, “Minority Investments”, for further information about such investment.

- removed (2017-08-08):
[0001628280-17-000901:note_history:12]
The Company believes it has sufficient liquidity to fund its operations, capital expenditures and scheduled cash payments under its debt obligations for the next twelve months. The Company’s liquidity is highly dependent on its ability to increase revenues, its ability to control its operating costs, its ability to maintain compliance with the covenants and restrictions on its debt obligations (or obtain waivers from its lender in the event of non-compliance), and its ability to raise additional capital, if necessary. There can be no assurance that the Company will be able to continue to raise additional capital from other sources or execute on any other means of improving liquidity described above.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2017-08-08):
[0001628280-17-008331:note_history:13]
On December 19, 2014, the Company entered into a second amendment to its Loan and Security Agreement with Hercules (the “Hercules Second Amendment”) and entered into a new term loan, borrowing an additional $1.5 million (the “Term Loan C”).  After closing fees and expenses, the net proceeds to the Company for the Term Loan C were $1.4 million. The Company made interest only payments at an interest rate of 11% through March 16, 2017 when the interest rate was increased to 11.25%, until maturity on June 1, 2017, when Term Loan C was repaid in its entirety.

- changed (2017-08-08):
[0001628280-17-008331:note_history:14]
Hercules received warrants to purchase 13,927 shares of common stock (the “First Warrant”) and 25,641 shares of common stock (the “Second Warrant”) in conjunction with prior term loans that have been repaid in full.  Due to certain adjustment provisions within the warrants, they qualified for liability accounting.  The fair value of the warrants, $0.4 million and $0.2 million, respectively, was recorded upon issuance to debt discount and a warrant liability. In conjunction with the Hercules Second Amendment, the First Warrant and Second Warrant were cancelled and replaced with the issuance of a new warrant (the “Hercules Warrant”) to purchase 58,823 shares of common stock at an exercise price of $11.00 per share, subject to adjustment.  The Hercules Warrant expires on June 30, 2020.  See Note 11, “Warrants and Derivative Liabilities”, for a discussion on the Hercules Warrant and the valuation assumptions used.
  (was, 2017-02-06, similarity 0.9594):
[0001628280-17-000901:note_history:14]
Hercules received warrants to purchase 13,927 shares of common stock (the “First Warrant”) and 25,641 shares of common stock (the “Second Warrant”) in conjunction with a prior term loan which has been repaid in full and the Term Loan B.  Due to certain adjustment provisions within the warrants, they qualified for liability accounting.  The fair value of the warrants, $0.4 million and $0.2 million, respectively, was recorded upon issuance to debt discount and a warrant liability. In conjunction with the Hercules Second Amendment, the First Warrant and Second Warrant were cancelled and replaced with the issuance of a new warrant (the “Hercules Warrant”) to purchase 58,823 shares of common stock at an exercise price of $11.00 per share, subject to adjustment.  The Hercules Warrant expires on June 30, 2020.  See Note 10, “Warrants and Derivative Liabilities”, for a discussion on the Hercules Warrant and the valuation assumptions used.

- added (2017-08-08):
[0001628280-17-008331:note_history:15]
During the three months ended June 30, 2016, the Company recorded non-cash interest expense for amortization of the debt discount related to a prior term loan of less than $0.1 million.  Under Term Loan C, the total debt discount, including the Hercules Warrant, end of term fee and legal and origination costs of $0.3 million was amortized into interest expense over the term of the Term Loan C using the effective interest method.  During each of the three months ended June 30, 2017 and 2016, the Company recorded non-cash interest expense for amortization of the debt discount related to the Term Loan C of less than $0.1 million.

- changed (2017-08-08):
[0001628280-17-008331:note_history:16]
Interest expense on the Term Loans for the three months ended June 30, 2017 and 2016, was less than $0.1 million and $0.2 million, respectively, each of which included less than $0.1 million of non-cash interest expense related to the amortization of the debt discount on the respective Term Loans.
  (was, 2017-02-06, similarity 0.6285):
[0001628280-17-000901:note_history:16]
Interest expense on the Term Loans for the three months ended December 31, 2016 and 2015, was $0.1 million and $0.2 million, respectively, each of which included less than $0.1 million of non-cash interest expense related to the amortization of the debt discount on the respective Term Loans.  Interest expense on the Term Loans for the nine months ended December 31, 2016 and 2015, was $0.3 million and $0.8 million, respectively, each of which included $0.1 million and $0.3 million, respectively, of non-cash interest expense related to the amortization of the debt discount on the respective Term Loans

- removed (2017-08-08):
[0001628280-17-000901:note_history:17]
On November 15, 2013, the Company amended its existing Loan and Security Agreement with Hercules and entered into a new term loan (the “Term Loan B”), borrowing $10.0 million. After closing fees and expenses, the net proceeds to the Company for the Term Loan B were $9.8 million.  The Term Loan B bears an interest rate of 11% plus the percentage, if any, by which the prime rate as reported by the Wall Street Journal exceeds 3.75%.  The Company repaid the Term Loan B in equal monthly installments ending on November 1, 2016, when the loan was repaid in full.  The Company paid an end of term fee of $0.5 million upon the maturity of the Term Loan B, which had been accrued at inception of the loan with a corresponding amount recorded into the debt discount.  In addition, the Company incurred $0.2 million of legal and origination costs at inception of the loan, which have been recorded as a debt discount.

- removed (2017-08-08):
[0001628280-17-000901:note_history:18]
On December 19, 2014, the Company entered into a second amendment with Hercules (the “Hercules Second Amendment”) and entered into a new term loan, borrowing an additional $1.5 million (the “Term Loan C”).  After closing fees and expenses, the net proceeds to the Company for the Term Loan C were $1.4 million.  The Term Loan B and Term Loan C are collectively referred to as the “Term Loans”.  The Term Loan C also bears the same interest rate as the Term Loan B.  The Company will make interest only payments until maturity on June 1, 2017, when the loan is scheduled to be repaid in its entirety.  The maturity date of the Term Loan C was extended from March 1, 2017 to June 1, 2017 due to the Company’s April 2015 equity offering which raised more than $10 million in new capital before December 31, 2015.  The Company will pay an end of term fee of approximately $0.1 million upon earlier of maturity or prepayment of the Term Loan C.  The Company has accrued the end of term fee and recorded a corresponding amount in the debt discount.  The Term Loan C includes the same mandatory prepayment feature as the Term Loan B.   The Company determined the fair value to be de-minimus for this feature.  In addition, the Company incurred approximately $0.1 million of legal and origination costs at inception of the loan, which have been recorded as a debt discount.

- removed (2017-08-08):
[0001628280-17-000901:note_history:19]
Under Term Loan B, the total debt discount including the Hercules Warrant, end of term fee and legal and origination costs of $1.0 million was amortized into interest expense over the term of the Term Loan B using the effective interest method.  During both the three and nine months ended December 31, 2016, the Company recorded non-cash interest expense for amortization of the debt discount related to the Term Loan B of less than $0.1 million.  During both the three and nine months ended December 31, 2015, the Company recorded non-cash interest expense for amortization of the debt discount related to the Term Loan B of $0.2 million  Under Term Loan C, the total debt discount, including the Hercules Warrant, end of term fee and legal and origination costs of $0.3 million is being amortized into interest expense over the term of the Term Loan C using the effective interest method.  During both the three and nine months ended December 31, 2016 and 2015, the Company recorded non-cash interest expense for amortization of the debt discount related to the Term Loan C of less than $0.1 million.

- removed (2017-08-08):
[0001628280-17-000901:note_history:20]
The Term Loans are secured by substantially all of the Company’s existing and future assets, including a mortgage on real property owned by the Company’s wholly-owned subsidiary, ASC Devens LLC, and located at 64 Jackson Road, Devens, Massachusetts.  The Term Loans contain certain covenants that restrict the Company’s ability to, among other things, incur or assume certain debt, merge or consolidate, materially change the nature of the Company’s business, make certain investments, acquire or dispose of certain assets, make guarantees or grant liens on its assets, make certain loans, advances or investments, declare dividends or make distributions or enter into transactions with affiliates. In addition, there is a covenant that requires the Company to maintain a minimum unrestricted cash balance (the “Minimum Threshold”) in the United States.  As a result of the Company’s April 2015 equity offering, the Minimum Threshold was reduced to the lesser of $2.0 million or the aggregate outstanding principal balance of the Term Loans.  As of December 31, 2016, the Minimum Threshold was $1.5 million.  The events of default under the Term Loans include, but are not limited to, failure to pay amounts due, breaches of covenants, bankruptcy events, cross defaults under other material indebtedness and the occurrence of a material adverse effect and/or change in control. In the case of a continuing event of default, Hercules may, among other remedies, declare due all unpaid principal amounts outstanding and any accrued but unpaid interest and foreclose on all collateral granted to Hercules as security under the Term Loans.

- removed (2017-08-08):
[0001628280-17-000901:note_history:21]
Although the Company believes that it is in compliance with the covenants and restrictions under the Term Loans as of December 31, 2016, there can be no assurance that the Company will continue to be in compliance.


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: tag_name, score: 1.0

- changed (2017-08-08):
[0001628280-17-008331:note_history:22]
The Company has performed an evaluation of subsequent events through the time of filing this Quarterly Report on Form 10-Q with the SEC, and has determined that there are no such events to report.
  (was, 2017-02-06, similarity 0.7928):
[0001628280-17-000901:note_history:22]
As of the time of filing this Quarterly Report on Form 10-Q with the SEC, and has determined that there are no other such events to report.

- removed (2017-08-08):
[0001628280-17-000901:note_history:23]
On January 27, 2017, the Company entered into an At Market Issuance Sales Agreement ("ATM") with FBR Capital Markets & Co ("FBR") under which the Company may, at its discretion, sell up to $10.0 million of its shares of common stock through FBR.  FBR has agreed to use its commercially reasonable efforts to sell the Company’s common stock from time to time, based upon the Company’s instructions (including any price, time or size limits or other customary parameters or conditions the Company may impose).  Sales under the ATM, if any, would be made pursuant to the prospectus supplement dated January 27, 2017, which supplements the prospectus dated October 1, 2014, included in the shelf registration statement that AMSC filed with the Securities and Exchange Commission (“SEC”) on September 19, 2014.
