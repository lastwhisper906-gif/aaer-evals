# AMSC MD&A — 0001628280-17-008331


## mdna

[0001628280-17-008331:mdna:1]
[same as prior period, unchanged from 0001628280-17-000901:mdna:1]

[0001628280-17-008331:mdna:2]
American Superconductor®, Amperium®, AMSC®, D-VAR®, PowerModule™, D-VAR® VVO, PQ-IVR®, SeaTitan™, Gridtec Solutions™, Windtec Solutions™ and Smarter, Cleaner... Better Energy™ are trademarks or registered trademarks of American Superconductor Corporation or our subsidiaries. We reserve all of our rights with respect to our trademarks or registered trademarks regardless of whether they are so designated in this Quarterly Report on Form 10-Q by an ® or ™ symbol. All other brand names, product names, trademarks or service marks appearing in this Quarterly Report on Form 10-Q are the property of their respective holders.

[0001628280-17-008331:mdna:3]
[same as prior period, unchanged from 0001628280-17-000901:mdna:4]

[0001628280-17-008331:mdna:4]
We are a leading provider of megawatt-scale solutions that lower the cost of wind power and enhance the performance of the power grid. In the wind power market, we enable manufacturers to field highly competitive wind turbines through our advanced power electronics products, engineering, and support services. In the power grid market, we enable electric utilities and renewable

[0001628280-17-008331:mdna:5]
energy project developers to connect, transmit and distribute power through our transmission planning services and power electronics and superconductor-based products. Our wind and power grid products and services provide exceptional reliability, security, efficiency and affordability to our customers.

[0001628280-17-008331:mdna:6]
[same as prior period, unchanged from 0001628280-17-000901:mdna:6]

[0001628280-17-008331:mdna:7]
[same as prior period, unchanged from 0001628280-17-000901:mdna:7]

[0001628280-17-008331:mdna:8]
[same as prior period, unchanged from 0001628280-17-000901:mdna:8]

[0001628280-17-008331:mdna:9]
[same as prior period, unchanged from 0001628280-17-000901:mdna:9]

[0001628280-17-008331:mdna:10]
| • | Grid. Through our Gridtec Solutions™, our Grid business segment enables electric utilities and renewable energy project developers to connect, transmit and distribute power with exceptional efficiency, reliability, security and affordability. We provide transmission planning services that allow us to identify power grid congestion, poor power quality, and other risks, which help us determine how our solutions can improve network performance. These services often lead to sales of our grid interconnection solutions for wind farms and solar power plants, power quality systems and transmission and distribution cable systems. We also sell ship protection products to the U.S. Navy through our Grid business segment. |

[0001628280-17-008331:mdna:11]
Our fiscal year begins on April 1 and ends on March 31. When we refer to a particular fiscal year, we are referring to the fiscal year beginning on April 1 of that same year. For example, fiscal 2017 refers to the fiscal year beginning on April 1, 2017. Other fiscal years follow similarly.

[0001628280-17-008331:mdna:12]
[same as prior period, unchanged from 0001628280-17-000901:mdna:18]

[0001628280-17-008331:mdna:13]
The preparation of the unaudited condensed consolidated financial statements requires that we make estimates and judgments that affect the reported amounts of assets, liabilities, revenues and expenses, and related disclosure of contingent assets and liabilities. We base our estimates on historical experience and various other assumptions that are believed to be reasonable under the circumstances, the results of which form the basis for making judgments about the carrying values of assets and liabilities that are not readily apparent from other sources. Actual results may differ under different assumptions or conditions.  During the three months ended June 30, 2017 there were no significant changes in the critical accounting policies that were disclosed in our Form 10-K for fiscal 2016, which ended on March 31, 2017.

[0001628280-17-008331:mdna:14]
[same as prior period, unchanged from 0001628280-17-000901:mdna:20]

[0001628280-17-008331:mdna:15]
Three months ended June 30, 2017 compared to the three months ended June 30, 2016

[0001628280-17-008331:mdna:16]
[same as prior period, unchanged from 0001628280-17-000901:mdna:22]

[0001628280-17-008331:mdna:17]
Total revenues decreased 33% to $8.9 million for the three months ended June 30, 2017, compared to $13.3 million for the three months ended June 30, 2016.  Our revenues are summarized as follows (in thousands):

[0001628280-17-008331:mdna:18]
22

[0001628280-17-008331:mdna:19]
|  | Three months ended June 30, |
|  | 2017 |  | 2016 |
| Revenues: |  |  |  |  |
| Wind | $ | 2,278 |  |  | $ | 5,675 |  |
| Grid | 6,645 |  |  | 7,670 |  |
| Total | $ | 8,923 |  |  | $ | 13,345 |  |

[0001628280-17-008331:mdna:20]
Our Wind business unit accounted for 26% of total revenues for the three months ended June 30, 2017, compared to 43% for the three months ended June 30, 2016.  Revenues in the Wind business unit decreased 60% to $2.3 million in the three months ended June 30, 2017, from $5.7 million in the three months ended June 30, 2016. Wind business unit revenues in the three months ended June 30, 2017 decreased due primarily to fewer ECS shipments to Inox.  This resulted from what we believe, based on our discussions with Inox, to be a temporary demand dislocation caused by the reaction in certain states in India to a recent national wind energy auction that resulted in a record-low power purchase tariff.

[0001628280-17-008331:mdna:21]
Our Grid business unit accounted for 74% of total revenues for the three months ended June 30, 2017, compared to 57% for the three months ended June 30, 2016. Our Grid business unit revenues decreased 13% to $6.6 million in the three months ended June 30, 2017, from $7.7 million in the three months ended June 30, 2016. Grid business unit revenues in the three months ended June 30, 2017 decreased primarily due to lower D-VAR system revenues than in the prior year period, partially offset by higher revenue from the U.S. Navy.

[0001628280-17-008331:mdna:22]
The following table sets forth customers who represented 10% or more of our total revenues for the three months ended June 30, 2017 and 2016:

[0001628280-17-008331:mdna:23]
|  | Three months ended June 30, |
|  | 2017 |  | 2016 |
| INOX Wind Limited | 22 | % |  | 27 | % |
| U.S. Navy | 35 | % |  | — | % |
| Reed & Reed Inc. | <10% |  |  | 17 | % |
| Essential Energy | <10% |  |  | 13 | % |
| XJ Group Corporation | — | % |  | 12 | % |

[0001628280-17-008331:mdna:24]
[same as prior period, unchanged from 0001628280-17-000901:mdna:30]

[0001628280-17-008331:mdna:25]
Cost of revenues increased by 7% to $13.4 million for the three months ended June 30, 2017, compared to $12.5 million for the three months ended June 30, 2016. Gross margin was (50.3)% for the three months ended June 30, 2017, compared to 6.5% for the three months ended June 30, 2016. The decrease in the gross margin for the three months ended June 30, 2017 was due to decreased revenue as discussed above, along with a more favorable product mix in the prior year period, as well as an increase to cost of revenues of approximately of $2.5 million due to accelerated depreciation related to revised estimates of the remaining useful lives on certain pieces of manufacturing equipment.

[0001628280-17-008331:mdna:26]
[same as prior period, unchanged from 0001628280-17-000901:mdna:32]

[0001628280-17-008331:mdna:27]
[same as prior period, unchanged from 0001628280-17-000901:mdna:33]

[0001628280-17-008331:mdna:28]
R&D expenses decreased by 8% to $2.7 million for the three months ended June 30, 2017, from $3.0 million for the three months ended June 30, 2016.  The decrease in the three months ended June 30, 2017 is primarily due to lower overall compensation expense due to decreased headcount.

[0001628280-17-008331:mdna:29]
[same as prior period, unchanged from 0001628280-17-000901:mdna:35]

[0001628280-17-008331:mdna:30]
SG&A expenses decreased by 15% to $6.1 million in the three months ended June 30, 2017, from $7.2 million in the three months ended June 30, 2016. The decrease in SG&A expenses in the three months ended June 30, 2017 was due primarily to reduced overall compensation expense as noted above.

[0001628280-17-008331:mdna:31]
[same as prior period, unchanged from 0001628280-17-000901:mdna:39]

[0001628280-17-008331:mdna:32]
We recorded amortization expense related to our core technology and know-how, trade names and trademark intangible assets of less than $0.1 million in each of the three months ended June 30, 2017 and 2016.

[0001628280-17-008331:mdna:33]
Restructuring

[0001628280-17-008331:mdna:34]
We recorded a restructuring charge of $1.3 million for severance costs in the three months ended June 30, 2017 as a result of the reduction in force announced on April 4, 2017. Included in the $1.3 million severance pay, charged to operations in the three months ended June 30, 2017, is $0.5 million of severance pay for one of our former executive officers pursuant to the terms of a severance agreement dated as of June 30, 2017.  Under the terms of the severance agreement, our former executive officer is entitled to eighteen months of his base salary, which is expected to be paid by December 31, 2018.  From and after January 1, 2018, at our discretion, we may settle any remaining unpaid cash severance owed to our former executive officer through the issuance of a number of immediately vested shares of our common stock, determined by multiplying the remaining unpaid cash severance owed by 120%, and then dividing by the closing stock price per share of our common stock as of the last business day prior to the issuance of the shares.

[0001628280-17-008331:mdna:35]
[same as prior period, unchanged from 0001628280-17-000901:mdna:41]

[0001628280-17-008331:mdna:36]
[same as prior period, unchanged from 0001628280-17-000901:mdna:42]

[0001628280-17-008331:mdna:37]
|  | Three months ended June 30, |
|  | 2017 |  | 2016 |
| Operating (loss) profit: |  |  |  |
| Wind | $ | (4,433 | ) |  | $ | (3,030 | ) |
| Grid | (8,167 | ) |  | (5,315 | ) |
| Unallocated corporate expenses | (2,093 | ) |  | (999 | ) |
| Total | $ | (14,693 | ) |  | $ | (9,344 | ) |

[0001628280-17-008331:mdna:38]
Our Wind segment generated an operating loss of $4.4 million in the three months ended June 30, 2017, compared to $3.0 million in the three months ended June 30, 2016. The increase in the Wind business unit operating loss in the three months ended June 30, 2017 was due primarily to lower shipments to Inox as previously discussed.

[0001628280-17-008331:mdna:39]
Our Grid segment generated an operating loss of $8.2 million in the three months ended June 30, 2017, compared to $5.3 million in the three months ended June 30, 2016.  The increase in the Grid business unit operating loss in the three months ended June 30, 2017 was due primarily to increased cost of revenues related to accelerated depreciation related to revised estimates of the useful lives of certain pieces of manufacturing equipment and lower D-VAR system revenues.

[0001628280-17-008331:mdna:40]
Unallocated corporate expenses primarily consist of stock-based compensation expense of $0.8 million and $1.0 million in the three months ended June 30, 2017 and 2016, respectively.  Additionally, a restructuring charge of $1.3 million primarily for severance costs as a result of the restructuring action announced on April 4, 2017 is included in unallocated corporate expenses for the three months ended June 30, 2017.

[0001628280-17-008331:mdna:41]
[same as prior period, unchanged from 0001628280-17-000901:mdna:47]

[0001628280-17-008331:mdna:42]
The change in fair value of derivatives and warrants resulted in a gain of $0.9 million in the three months ended June 30, 2017, compared to a loss of $0.7 million in the three months ended June 30, 2016.  The change in the fair value was primarily driven by changes in stock price, which is a key valuation metric.

[0001628280-17-008331:mdna:43]
[same as prior period, unchanged from 0001628280-17-000901:mdna:51]

[0001628280-17-008331:mdna:44]
Interest expense, net, was less than $0.1 million in the three months ended June 30, 2017, compared to $0.1 million in the three months ended June 30, 2016. The decrease was related to lower interest expense due to the maturity of both of our term loans with Hercules Technology Growth Capital, Inc. (“Hercules”).  Our Term Loan B matured in November 2016, and our Term Loan C matured in June 2017.

[0001628280-17-008331:mdna:45]
Other (expense) income, net

[0001628280-17-008331:mdna:46]
Other expense, net, was $1.4 million in the three months ended June 30, 2017, compared to other income, net, of $0.1 million in the three months ended June 30, 2016.  The increase in other expense, net during the three months ended June 30, 2017, was primarily driven by higher foreign currency losses.

[0001628280-17-008331:mdna:47]
[same as prior period, unchanged from 0001628280-17-000901:mdna:55]

[0001628280-17-008331:mdna:48]
Income tax expense was $0.1 million in the three months ended June 30, 2017, compared to income tax expense of $0.3 million in the three months ended June 30, 2016. The decrease in income tax expense during the three months ended June 30, 2017 was primarily due to lower taxes in our foreign jurisdictions.

[0001628280-17-008331:mdna:49]
[same as prior period, unchanged from 0001628280-17-000901:mdna:57]

[0001628280-17-008331:mdna:50]
[same as prior period, unchanged from 0001628280-17-000901:mdna:58]

[0001628280-17-008331:mdna:51]
We define non-GAAP net loss as net loss before stock-based compensation, amortization of acquisition-related intangibles, consumption of zero cost-basis inventory, changes in fair value of derivatives and warrants, non-cash interest expense, tax effect of adjustments, and the other non-cash or unusual charges, indicated in the table below. We believe non-GAAP net loss assists management and investors in comparing our performance across reporting periods on a consistent basis by excluding these non-cash or non-recurring charges that we do not believe are indicative of our core operating performance. A reconciliation of GAAP to non-GAAP net loss is set forth in the table below (in thousands, except per share data):

[0001628280-17-008331:mdna:52]
|  | Three months ended June 30, |
|  | 2017 |  | 2016 |
| Net loss | $ | (15,252 | ) |  | $ | (10,355 | ) |
| Stock-based compensation | 754 |  |  | 999 |  |
| Amortization of acquisition-related intangibles | 13 |  |  | 39 |  |
| Consumption of zero cost-basis inventory | (57 | ) |  | (158 | ) |
| Change in fair value of derivatives and warrants | (925 | ) |  | 678 |  |
| Non-cash interest expense | 19 |  |  | 56 |  |
| Tax effect of adjustments | 9 |  |  | 25 |  |
| Non-GAAP net loss | $ | (15,439 | ) |  | $ | (8,716 | ) |
| Non-GAAP net loss per share | $ | (0.92 | ) |  | $ | (0.64 | ) |
| Weighted average shares outstanding - basic and diluted | 16,778 |  |  | 13,676 |  |

[0001628280-17-008331:mdna:53]
We incurred non-GAAP net losses of $15.4 million or $0.92 per share for the three months ended June 30, 2017, compared to non-GAAP net losses of $8.7 million or $0.64 per share for the three months ended June 30, 2016. The increase in non-GAAP net loss in the three month period ended June 30, 2017 was driven primarily by an increase in net loss as previously discussed.

[0001628280-17-008331:mdna:54]
[same as prior period, unchanged from 0001628280-17-000901:mdna:62]

[0001628280-17-008331:mdna:55]
We have experienced recurring operating losses and as of June 30, 2017, had an accumulated deficit of $970.8 million. In addition, we have experienced recurring negative operating cash flows and our Wind segment revenues decreased substantially in the three months ended June 30, 2017 compared to the prior year period. From April 1, 2011 through the date of this filing, we have reduced our global workforce substantially, including an 8% reduction in force, primarily affecting employees in our Devens, Massachusetts facility, effective April 4, 2017. We incurred restructuring charges of $1.3 million in cash severance expenses in the fiscal quarter ended June 30, 2017 in connection with the workforce reduction. We plan to closely monitor our expenses and, if required, expect to further reduce operating costs and capital spending to enhance liquidity.

[0001628280-17-008331:mdna:56]
Our cash requirements depend on numerous factors, including if and when the Inox demand dislocation is resolved, the successful completion of our product development activities, our ability to commercialize our Resilient Electric Grid (“REG”)

[0001628280-17-008331:mdna:57]
25

[0001628280-17-008331:mdna:58]
and ship protection system solutions, rate of customer and market adoption of our products, collecting receivables according to established terms, and the continued availability of U.S. government funding during the product development phase of our Superconductors-based products.

[0001628280-17-008331:mdna:59]
At June 30, 2017, we had cash, cash equivalents, and restricted cash of $37.7 million, compared to $27.7 million at March 31, 2017, an increase of $10.0 million. Our cash and cash equivalents, and restricted cash are summarized as follows (in thousands):

[0001628280-17-008331:mdna:60]
|  | June 30, 2017 |  | March 31,2017 |
| Cash and cash equivalents | $ | 37,477 |  |  | $ | 26,784 |  |
| Restricted cash | 265 |  |  | 960 |  |
| Total cash, cash equivalents, and restricted cash | $ | 37,742 |  |  | $ | 27,744 |  |

[0001628280-17-008331:mdna:61]
As of June 30, 2017, we had approximately $6.5 million of cash, cash equivalents, and restricted cash in foreign bank accounts, with a majority of this cash located in Europe.  The increase in total cash, cash equivalents, and restricted cash was due primarily to cash received from the May 2017 equity offering. See further discussion below.

[0001628280-17-008331:mdna:62]
For the three months ended June 30, 2017, net cash used in operating activities was $5.4 million compared to $2.1 million of cash used for the three months ended June 30, 2016. The increase in net cash used in operations was due primarily to an increased operating loss, and less cash collections from Inox, partially offset by usage of inventory.

[0001628280-17-008331:mdna:63]
For the three months ended June 30, 2017, net cash provided by investing activities was $0.6 million, compared to net cash used of $0.3 million for the three months ended June 30, 2016. The increase in net cash provided by investing activities was due primarily to a decrease in restricted cash as well as less fixed asset purchases compared to the prior year period.

[0001628280-17-008331:mdna:64]
For the three months ended June 30, 2017, net cash provided by financing activities was $15.1 million compared to net cash used in financing activities of $1.5 million in the three months ended June 30, 2016. The increase in net cash provided by financing activities was primarily due to net proceeds of $17.0 million from the issuance of 4.6 million shares of common stock in May 2017, with no such equity offering in the prior year period.  See the discussion regarding the May 2017 equity offering below.

[0001628280-17-008331:mdna:65]
At June 30, 2017, we had $0.1 million of restricted cash included in current assets and $0.2 million of restricted cash included in long-term assets. These amounts included in restricted cash primarily represent deposits to secure letters of credit for various supply contracts. These deposits are held in interest bearing accounts.

[0001628280-17-008331:mdna:66]
On December 19, 2014, we amended our Loan and Security Agreement (the "Term Loan") with Hercules and entered into a new term loan (the “Term Loan C”), borrowing $1.5 million (our prior $10.0 million term loan with Hercules was repaid in full at maturity on November 1, 2016).  After closing fees and expenses, the net proceeds from the Term Loan C were $1.4 million.  We made interest only payments on the Term Loan C until maturity on June 1, 2017, when the loan was repaid in its entirety.

[0001628280-17-008331:mdna:67]
On May 5, 2017, we entered into an underwriting agreement relating to the issuance and sale (the "Offering") of up to 4.0 million shares of our common stock at a public offering price of $4.00 per share and granted a 30-day option (the "Option") to the underwriters to purchase up to an additional 600,000 shares of common stock at the public offering price. The net proceeds to us from the Offering were approximately $14.7 million, after deducting underwriting discounts and commissions and offering expenses payable by us.  On May 24, 2017, the underwriters notified us that they had exercised in full their Option to purchase an additional 600,000 shares of common stock in connection with the Offering.   The net proceeds to us from the Option were approximately $2.3 million, after deducting underwriting discounts and commissions and offering expenses payable by us.  The total net proceeds to us during the three months ended June 30, 2017 from the Offering and Option were approximately $17.0 million, after deducting underwriting discounts and commissions and offering expenses payable by us.  The Company terminated its At Market Issuance Sales Agreement with FBR Capital Markets & Co in conjunction with the Offering.  In addition, in December 2015, we entered into a set of strategic agreements valued at approximately $210.0 million with Inox.  These agreements are expected to provide a foundation for the business as we pursue our longer-term objectives.

[0001628280-17-008331:mdna:68]
We believe we have sufficient available liquidity to fund our operations and capital expenditures for the next twelve months. In addition, we may seek to raise additional capital, which could be in the form of loans, convertible debt or equity, to fund our operating requirements and capital expenditures.  Our liquidity is highly dependent on our ability to increase revenues, control our operating costs, and our ability to raise additional capital, if necessary.  There can be no assurance that we will be able to raise additional capital, or execute on any other means of improving our liquidity as described above.

[0001628280-17-008331:mdna:69]
Legal Proceedings

[0001628280-17-008331:mdna:70]
We are involved in legal and administrative proceedings and claims of various types. See Part II, Item 1, “Legal Proceedings,” for additional information. We record a liability in our consolidated financial statements for these matters when a loss is known or considered probable and the amount can be reasonably estimated. We review these estimates each accounting period as additional information is known and adjust the loss provision when appropriate. If a matter is both probable to result in liability and the amounts of loss can be reasonably estimated, we estimate and disclose the possible loss or range of loss to the extent necessary to make the consolidated financial statements not misleading. If the loss is not probable or cannot be reasonably estimated, a liability is not recorded in our consolidated financial statements.

[0001628280-17-008331:mdna:71]
[same as prior period, unchanged from 0001628280-17-000901:mdna:78]

[0001628280-17-008331:mdna:72]
[same as prior period, unchanged from 0001628280-17-000901:mdna:79]

[0001628280-17-008331:mdna:73]
[same as prior period, unchanged from 0001628280-17-000901:mdna:80]

[0001628280-17-008331:mdna:74]
[same as prior period, unchanged from 0001628280-17-000901:mdna:81]

[0001628280-17-008331:mdna:75]
[same as prior period, unchanged from 0001628280-17-000901:mdna:82]

[0001628280-17-008331:mdna:76]
In May 2014, the Financial Accounting Standards Board (“FASB”) and the International Accounting Standards Board (IASB) issued ASU 2014-09, Revenue from Contracts with Customers (Topic 606). The guidance substantially converges final standards on revenue recognition between the FASB and IASB providing a framework on addressing revenue recognition issues and, upon its effective date, replaces almost all existing revenue recognition guidance, including industry-specific guidance, in current U.S. generally accepted accounting principles. The FASB has subsequently issued the following amendments to ASU 2014-09 which are all effective for annual reporting periods beginning after December 15, 2017.

[0001628280-17-008331:mdna:77]
•In March 2016, the FASB issued ASU No. 2016-08, Revenue from Contracts with Customers (Topic 606): Principal versus Agent Considerations, which clarifies the implementation guidance on principal versus agent considerations.

[0001628280-17-008331:mdna:78]
•In April 2016, the FASB issued ASU No. 2016-10, Revenue from Contracts with Customers (Topic 606): Identifying Performance Obligations and Licensing, which clarifies certain aspects of identifying performance obligations and licensing implementation guidance.

[0001628280-17-008331:mdna:79]
•In May 2016, the FASB issued ASU No. 2016-12, Revenue from Contracts with Customers (Topic 606): Narrow- Scope Improvements and Practical Expedients related to disclosures of remaining performance obligations, as well as other amendments to guidance on collectability, non-cash consideration and the presentation of sales and other similar taxes collected from customers.

[0001628280-17-008331:mdna:80]
•In December 2016, the FASB issued ASU No. 2016-20, Technical Corrections and Improvements to Topic 606, Revenue from Contracts with Customers, which amends certain narrow aspects of the guidance issued in ASU 2014-09 including guidance related to the disclosure of remaining performance obligations and prior-period performance obligations, as well as other amendments to the guidance on loan guarantee fees, contract costs, refund liabilities, advertising costs and the clarification of certain examples.

[0001628280-17-008331:mdna:81]
We are currently evaluating the provisions of ASU 2014-09 and its amendments, and assessing the impact the adoption of this guidance will have on our financial position, results of operations and disclosures.  We anticipate the adoption of this guidance will result in certain changes in the identification of deliverables in our contracts and allocation of transaction price.  We are required to adopt the new standards in the first quarter of fiscal 2018 and expect to do so retrospectively with the cumulative effect of initially applying the guidance recognized at the date of initial application (the cumulative catch-up transition method). We are still evaluating the final impact of this adoption method on our consolidated financial statements.

[0001628280-17-008331:mdna:82]
In January 2016, the FASB issued ASU 2016-01, Financial Instruments-Overall (Subtopic 825-10): Recognition and Measurement of Financial Assets and Financial Liabilities.  The amendments in ASU 2016-01 enhance the reporting model for

[0001628280-17-008331:mdna:83]
27

[0001628280-17-008331:mdna:84]
financial instruments to provide users of financial statements with more decision-useful information. This ASU is effective for annual reporting periods beginning after December 15, 2017, and interim periods within those fiscal years.  We are currently evaluating the impact, if any, the adoption of ASU 2016-01 may have on our consolidated financial statements.

[0001628280-17-008331:mdna:85]
In February 2016, the FASB issued ASU 2016-02, Leases (Topic 842). The guidance in this ASU supersedes the leasing guidance in Topic 840, Leases. Under the new guidance, lessees are required to recognize lease assets and lease liabilities on the balance sheet for all leases with terms longer than 12 months. Leases will be classified as either finance or operating, with classification affecting the pattern of expense recognition in the income statement. This ASU is effective for fiscal years beginning after December 15, 2019, including interim periods within those fiscal years. A modified retrospective transition approach is required for lessees for capital and operating leases existing at, or entered into after, the beginning of the earliest comparative period presented in the financial statements, with certain practical expedients available. We are currently evaluating the effects adoption of this guidance will have on our consolidated financial statements.

[0001628280-17-008331:mdna:86]
In June 2016, the FASB issued ASU 2016-13, Financial Instruments-Credit Losses (Topic 326): Measurement of Credit Losses on Financial Instruments.  The amendments in ASU 2016-13 provide more decision useful information about the expected credit losses on financial instruments and other commitments to extend credit held by a reporting entity at each reporting date. The ASU is effective for annual reporting periods beginning after December 15, 2019, including interim periods within that year.  We are currently evaluating the impact, if any, the adoption of ASU 2016-13 may have on our consolidated financial statements.

[0001628280-17-008331:mdna:87]
In 2016, the FASB issued the following two ASU's on Statement of Cash Flows (Topic 230).  Both amendments are effective for annual reporting periods beginning after December 15, 2017, including interim periods within that year.

[0001628280-17-008331:mdna:88]
•In August 2016, the FASB issued ASU 2016-15, Statement of Cash Flows (Topic 230): Classification of Certain Cash Receipts and Cash Payments.  The amendments in ASU 2016-15 provide more guidance towards the classification of multiple different types of cash flows in order to reduce the diversity in reporting across entities.

[0001628280-17-008331:mdna:89]
•In November 2016, the FASB issued ASU 2016-18, Statement of Cash Flows (Topic 230): Restricted Cash.  The amendments in ASU 2016-18 explain the change during the period in the total of cash, cash equivalents, and amounts generally described as restricted cash or restricted cash equivalents. Therefore, amounts generally described as restricted cash and restricted cash equivalents should be included with cash and cash equivalents when reconciling the beginning-of-period and end-of-period total amounts shown on the statement of cash flows.

[0001628280-17-008331:mdna:90]
We are currently evaluating the impact, if any, the adoption of ASU 2016-15 and ASU 2016-18 may have on our consolidated financial statements.

[0001628280-17-008331:mdna:91]
In October 2016, the FASB issued ASU 2016-16, Income Taxes (Topic 740): Intra-Entity Transfers of Assets Other Than Inventory.  The amendments in ASU 2016-16 improve the accounting for the income tax consequences of intra-entity transfers of assets other than inventory. The ASU is effective for annual reporting periods beginning after December 15, 2017, including interim periods within that year.  We are currently evaluating the impact, if any, the adoption of ASU 2016-16 may have on our consolidated financial statements.

[0001628280-17-008331:mdna:92]
In January 2017, the FASB issued ASU 2017-01, Business Combinations.  The amendments in ASU 2017-01 clarify the definition of a business with the objective of adding guidance to assist entities with evaluating whether transactions should be accounted for as acquisitions (or disposals) of assets or businesses. The ASU is effective for annual reporting periods beginning after December 15, 2017, including interim periods within those periods.  We are currently evaluating the impact the adoption of ASU 2017-01 may have on our consolidated financial statements.

[0001628280-17-008331:mdna:93]
In January 2017, the FASB issued ASU 2017-03, Accounting Changes and Error Corrections (Topic 250) and Investments - Equity Method and Joint Ventures.  The amendments in ASU 2017-03 provide additional detail surrounding disclosures required related to adoption of new pronouncements. The ASU is effective for the periods of each related pronouncement.  We are currently evaluating the impact the adoption of ASU 2017-03 may have on our consolidated financial statements.

[0001628280-17-008331:mdna:94]
In February 2017, the FASB issued ASU 2017-05, Other Income - Gains and Losses from the Derecognition of Non-financial Assets (Subtopic 610-20).  The amendments in ASU 2017-05 clarify the scope of Subtopic 610-20, Other Income-Gains and Losses from the Derecognition of Non-financial Assets, and to add guidance for partial sales of non-financial assets. Subtopic 610-20, which was issued in May 2014 as a part of Accounting Standards Update No. 2014-09, Revenue from Contracts with Customers (Topic 606), provides guidance for recognizing gains and losses from the transfer of non-financial assets in contracts with non-customers.  We are currently evaluating the impact the adoption of ASU 2017-05 may have on our consolidated financial statements.

[0001628280-17-008331:mdna:95]
In May 2017, the FASB issued ASU 2017-09, Compensation - Stock Compensation (Subtopic 718) Scope of Modification Accounting.  The amendments in ASU 2017-09 provide clarity and reduce both (1) diversity in practice and (2) cost and complexity when applying the guidance in Topic 718, Compensation—Stock Compensation, to a change to the terms or conditions of a share-based payment award.  The ASU is effective for annual reporting periods beginning after December 15, 2017, including interim periods within those periods. We are currently evaluating the impact the adoption of ASU 2017-09 may have on our consolidated financial statements.

[0001628280-17-008331:mdna:96]
In July 2017, the FASB issued ASU 2017-11, Earnings per Share (Topic 260), Distinguishing Liabilities from Equity (Topic   480), and Derivatives and Hedging (Topic 815).  The amendments in ASU 2017-11 provide guidance for freestanding equity-linked financial instruments, such as warrants and conversion options in convertible debt or preferred stock, and should no longer be accounted for as a derivative liability at fair value as a result of the existence of a down round feature.  The ASU is effective for annual reporting periods beginning after December 15, 2018, including interim periods within those periods. We are currently evaluating the impact the adoption of ASU 2017-11 may have on our consolidated financial statements.

[0001628280-17-008331:mdna:97]
We do not believe that other recently issued accounting pronouncements will have a material impact on our consolidated financial statements.
