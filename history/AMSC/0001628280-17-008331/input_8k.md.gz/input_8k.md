# AMSC 8-K — 0001628280-17-008329 filed 2017-08-08

## item codes, every 8-K on or before 2017-08-08

- 2017-08-08 0001628280-17-008329 — 2.02, 9.01
- 2017-08-01 0001628280-17-007765 — 5.02, 5.07
- 2017-07-03 0001193125-17-221140 — 5.02, 9.01
- 2017-05-26 0001193125-17-185503 — 8.01, 9.01
- 2017-05-25 0001628280-17-005914 — 2.02, 9.01 — amendment of 0001628280-17-005884
- 2017-05-25 0001628280-17-005884 — 2.02, 9.01
- 2017-05-10 0001193125-17-165924 — 8.01, 9.01
- 2017-05-09 0001193125-17-164273 — 5.02
- 2017-05-04 0001193125-17-158639 — 1.02, 8.01
- 2017-04-26 0001193125-17-139493 — 2.02, 9.01
- 2017-04-04 0001193125-17-109748 — 2.05, 5.02, 9.01
- 2017-02-06 0001628280-17-000899 — 2.02, 9.01
- 2017-01-27 0001193125-17-021808 — 1.01, 2.02, 9.01
- 2016-11-02 0001628280-16-020598 — 2.02, 9.01
- 2016-09-16 0001193125-16-712301 — 5.02
- 2016-08-23 0001193125-16-688767 — 8.01
- 2016-08-09 0001628280-16-018763 — 2.02, 9.01
- 2016-08-02 0001193125-16-668417 — 5.02, 5.07, 9.01
- 2016-05-31 0001564590-16-020114 — 2.02, 9.01
- 2016-05-18 0001193125-16-594515 — 5.02
- 2016-03-08 0001193125-16-496113 — 1.01
- 2016-02-09 0001193125-16-454775 — 2.02, 9.01
- 2015-12-17 0001193125-15-405566 — 1.01
- 2015-11-03 0001193125-15-363413 — 2.02, 9.01
- 2015-08-31 0001193125-15-307558 — 1.01
- 2015-08-05 0001193125-15-277824 — 2.02, 9.01
- 2015-07-31 0001193125-15-273009 — 5.07
- 2015-06-26 0001193125-15-237190 — 5.02
- 2015-06-09 0001193125-15-218028 — 8.01
- 2015-05-28 0001193125-15-202933 — 2.02, 9.01
- 2015-04-28 0001193125-15-153319 — 8.01, 9.01
- 2015-04-23 0001193125-15-144123 — 2.02, 8.01, 9.01
- 2015-04-23 0001193125-15-143608 — 8.01
- 2015-04-10 0001193125-15-126160 — 8.01
- 2015-03-24 0001193125-15-103436 — 5.03, 9.01
- 2015-03-18 0001193125-15-097034 — 5.07
- 2015-02-05 0001193125-15-034499 — 2.02, 9.01
- 2015-01-29 0001193125-15-024629 — 2.02, 9.01
- 2015-01-21 0001193125-15-016287 — 3.01, 8.01
- 2015-01-06 0001193125-15-002902 — 5.02
- 2014-12-22 0001193125-14-450591 — 1.01, 2.03, 3.02, 9.01
- 2014-11-13 0001193125-14-410207 — 1.01, 9.01
- 2014-11-07 0001193125-14-402383 — 1.02, 7.01, 9.01
- 2014-11-06 0001193125-14-399779 — 2.02, 9.01
- 2014-10-01 0001193125-14-360072 — 2.02, 8.01, 9.01
- 2014-09-04 0001193125-14-331411 — 8.01
- 2014-08-21 0001193125-14-317133 — 1.01
- 2014-08-06 0001193125-14-298306 — 5.02, 5.07, 9.01
- 2014-08-05 0001193125-14-294647 — 2.02, 9.01
- 2014-07-16 0001193125-14-269902 — 8.01
- 2014-06-23 0001193125-14-244592 — 3.02, 8.01
- 2014-06-05 0001193125-14-226459 — 2.02, 9.01
- 2014-06-05 0001193125-14-226457 — 1.01, 9.01
- 2014-03-19 0001193125-14-106558 — 2.05
- 2014-03-03 0001193125-14-078917 — 1.01, 3.02, 9.01
- 2014-02-28 0001193125-14-077480 — 8.01, 9.01
- 2014-02-06 0001193125-14-037960 — 2.02, 8.01, 9.01
- 2013-11-20 0001193125-13-447829 — 3.02, 8.01
- 2013-11-18 0001193125-13-444697 — 1.01, 2.03, 3.02, 9.01
- 2013-11-07 0001193125-13-431705 — 2.02, 9.01
- 2013-10-09 0001193125-13-395362 — 1.01, 2.03, 3.02, 9.01
- 2013-09-25 0001193125-13-378481 — 5.02, 9.01
- 2013-08-21 0001193125-13-341566 — 4.01, 9.01
- 2013-08-07 0001193125-13-323082 — 2.02, 9.01
- 2013-08-02 0001193125-13-317278 — 5.02, 5.07
- 2013-06-14 0001193125-13-258758 — 2.02, 9.01
- 2013-04-01 0001193125-13-136714 — 2.02, 8.01, 9.01
- 2013-02-20 0001193125-13-067218 — 5.02, 9.01
- 2013-02-14 0001193125-13-060131 — 1.01, 9.01
- 2013-02-11 0001193125-13-048784 — 2.02, 9.01
- 2013-01-08 0001193125-13-006861 — 5.02, 9.01
- 2012-12-21 0001193125-12-511592 — 1.01, 2.03, 3.02, 9.01
- 2012-11-28 0001193125-12-483317 — 2.05, 5.02, 7.01, 9.01
- 2012-11-06 0001193125-12-453359 — 2.02, 9.01
- 2012-08-02 0001193125-12-330534 — 2.02, 9.01
- 2012-07-27 0001193125-12-318790 — 5.02, 5.07, 9.01
- 2012-06-06 0001193125-12-261030 — 1.01, 2.02, 2.03, 3.02, 5.02, 9.01
- 2012-05-09 0001193125-12-222210 — 5.02
- 2012-04-20 0001193125-12-172045 — 8.01
- 2012-04-13 0001193125-12-162694 — 2.02, 8.01, 9.01
- 2012-04-04 0001193125-12-149102 — 1.01, 2.02, 2.03, 3.02, 9.01
- 2012-02-09 0001193125-12-048009 — 2.02, 9.01
- 2012-02-06 0001193125-12-041344 — 5.07 — amendment of 0000950123-11-102495
- 2011-12-08 0000950123-11-102495 — 5.07
- 2011-11-29 0000950123-11-100822 — 2.05
- 2011-11-09 0000950123-11-096775 — 2.02, 9.01
- 2011-10-31 0000950123-11-093390 — 1.02, 9.01
- 2011-10-07 0000950123-11-089221 — 8.01
- 2011-10-03 0000950123-11-088315 — 7.01
- 2011-09-23 0000950123-11-086288 — 2.02, 9.01
- 2011-09-15 0000950123-11-084585 — 7.01
- 2011-09-06 0000950123-11-082736 — 7.01
- 2011-08-18 0000950123-11-078526 — 3.01, 7.01, 9.01
- 2011-08-11 0000950123-11-075905 — 5.02
- 2011-08-11 0000950123-11-075904 — 2.02, 2.05, 9.01
- 2011-07-11 0000950123-11-064934 — 2.02, 4.02, 9.01
- 2011-06-30 0000950123-11-063287 — 1.01, 3.02, 9.01
- 2011-06-21 0000950123-11-060491 — 3.01, 7.01, 9.01
- 2011-06-13 0000950123-11-058656 — 1.01, 9.01
- 2011-05-24 0000950123-11-053517 — 5.02, 9.01
- 2011-04-05 0001299933-11-001020 — 2.02, 9.01
- 2011-03-15 0000950123-11-025580 — 5.02
- 2011-03-14 0000950123-11-025205 — 1.01, 3.02, 9.01
- 2011-02-01 0001299933-11-000333 — 2.02, 9.01
- 2010-11-12 0000950123-10-104604 — 8.01, 9.01
- 2010-11-08 0000950123-10-102424 — 8.01, 9.01
- 2010-11-02 0001299933-10-003878 — 2.02, 9.01
- 2010-09-15 0000950123-10-086373 — 1.01, 9.01 — amendment, the index does not say of what
- 2010-08-06 0000950123-10-074362 — 5.07
- 2010-07-29 0001299933-10-002860 — 2.02, 9.01
- 2010-05-17 0000950123-10-050424 — 1.01, 9.01
- 2010-05-14 0001299933-10-001972 — 5.02
- 2010-05-13 0001299933-10-001943 — 2.02, 9.01
- 2010-02-08 0001299933-10-000506 — 8.01
- 2010-02-02 0001299933-10-000386 — 2.02, 9.01
- 2009-12-15 0001299933-09-004928 — 5.02
- 2009-10-29 0001299933-09-004267 — 2.02, 9.01
- 2009-08-12 0001193125-09-173026 — 5.02, 9.01
- 2009-07-30 0001193125-09-158842 — 1.01, 2.02, 9.01
- 2009-05-15 0001193125-09-113158 — 5.02
- 2009-05-14 0001193125-09-110619 — 2.02, 9.01
- 2009-04-20 0001193125-09-082590 — 5.02
- 2009-02-03 0001193125-09-016992 — 2.02, 9.01
- 2009-01-22 0001193125-09-009777 — 2.02, 9.01
- 2008-11-04 0001193125-08-223730 — 2.02, 9.01
- 2008-08-11 0001193125-08-173616 — 8.01
- 2008-08-07 0001193125-08-170325 — 8.01
- 2008-08-05 0001193125-08-165888 — 2.02, 9.01
- 2008-06-11 0001193125-08-132049 — 1.01, 9.01
- 2008-05-20 0001193125-08-119372 — 5.02, 9.01
- 2008-05-08 0001193125-08-107052 — 2.02, 9.01
- 2008-01-31 0001193125-08-016233 — 2.02, 9.01
- 2008-01-30 0001193125-08-015494 — 5.03, 9.01
- 2007-11-01 0001193125-07-231866 — 2.02, 9.01
- 2007-10-31 0001193125-07-231225 — 2.05
- 2007-10-29 0001193125-07-228284 — 5.03, 9.01
- 2007-09-27 0001193125-07-208950 — 5.02
- 2007-08-09 0001193125-07-176553 — 2.02, 9.01
- 2007-08-07 0001193125-07-173829 — 1.01, 5.02, 9.01
- 2007-07-02 0001193125-07-148303 — 5.02, 9.01
- 2007-06-20 0001193125-07-139068 — 8.01, 9.01
- 2007-06-14 0001193125-07-135550 — 9.01 — amendment of 0001193125-07-005297
- 2007-06-14 0001193125-07-135340 — 5.02
- 2007-05-24 0001193125-07-122148 — 2.02, 9.01
- 2007-03-30 0001193125-07-070154 — 2.05, 9.01
- 2007-03-23 0001193125-07-062978 — 9.01 — amendment of 0001193125-07-005297
- 2007-02-01 0001193125-07-017883 — 2.02, 9.01
- 2007-01-11 0001193125-07-005297 — 2.01, 9.01
- 2006-12-05 0001181431-06-067500 — 5.02
- 2006-11-29 0001193125-06-243360 — 1.01, 3.02, 9.01
- 2006-11-02 0001193125-06-221464 — 2.02, 9.01
- 2006-09-21 0001193125-06-194526 — 5.02
- 2006-08-08 0001193125-06-164819 — 2.02, 9.01
- 2006-08-02 0001193125-06-159113 — 1.01, 9.01
- 2006-07-28 0001193125-06-156172 — 1.01
- 2006-06-26 0001193125-06-135913 — 1.01, 3.03, 9.01
- 2006-05-11 0001193125-06-108489 — 2.02, 9.01
- 2006-05-05 0001193125-06-102270 — 1.01, 9.01
- 2006-05-01 0001193125-06-094941 — 2.02, 2.06, 9.01
- 2006-02-24 0001193125-06-038281 — 5.02, 9.01
- 2006-02-02 0001181431-06-007665 — 2.02, 9.01
- 2005-11-09 0001181431-05-060304 — 2.02, 9.01
- 2005-08-04 0001181431-05-044420 — 2.02, 9.01
- 2005-07-28 0001193125-05-151272 — 5.02, 9.01
- 2005-06-14 0001193125-05-125148 — 5.02, 9.01
- 2005-05-12 0001181431-05-027410 — 2.02, 9.01
- 2005-05-10 0001193125-05-102795 — 1.01
- 2005-04-05 0001181431-05-020680 — 1.01, 2.02, 3.02, 9.01
- 2005-02-03 0001181431-05-006678 — 2.02, 9.01
- 2004-11-09 0001181431-04-051381 — 2.02, 9.01 — amendment, the index does not say of what
- 2004-11-04 0001181431-04-050706 — 2.02, 9.01
- 2004-10-15 0001193125-04-172458 — 1.01, 9.01
- 2004-08-05 0001193125-04-132162 — 12
- 2004-05-13 0001193125-04-086853 — 12
- 2004-02-05 0001193125-04-015060 — 12
- 2003-11-06 0001193125-03-074000 — 12
- 2003-09-26 0001193125-03-054624 — 5
- 2003-08-06 0001193125-03-029666 — 12
- 2003-05-14 0000927016-03-002619 — 9
- 2002-12-31 0000927016-02-006114 — 5
- 2000-01-24 0000927016-00-000150 — 5, 7
- 1998-11-02 0000950135-98-005625 — 5, 7
- 1998-03-24 0000950135-98-001743 — 5, 7
- 1997-09-05 0000950135-97-003729 — 5, 7
- 1997-06-23 0000950135-97-002785 — 1 — amendment of 0000950135-97-001972
- 1997-04-23 0000950135-97-001972 — 2, 7

## late-filing notifications on or before 2017-08-08

- 2011-08-10 0000950123-11-075677 — NT 10-Q, for the period ended 2011-06-30
- 2011-05-31 0000950123-11-055465 — NT 10-K, for the period ended 2011-03-31

## item 2.02 — earnings release, exhibit 99.1

[0001628280-17-008329:8k_2_02:1]
EX-99.1
2
amsc20170630ex991.htm
EXHIBIT 99.1

[0001628280-17-008329:8k_2_02:2]
Exhibit

[0001628280-17-008329:8k_2_02:3]
AMSC Reports First Quarter Fiscal 2017 Financial Results and Provides Business Outlook

[0001628280-17-008329:8k_2_02:4]
Company to host conference call tomorrow, August 9 at 10:00 am ET

[0001628280-17-008329:8k_2_02:5]
Devens, MA – August 8, 2017 – AMSC (NASDAQ: AMSC), a global solutions provider serving wind and power grid industry leaders, today reported financial results for its first quarter of fiscal 2017 ended June 30, 2017.

[0001628280-17-008329:8k_2_02:6]
Revenues for the first quarter of fiscal 2017 were $8.9 million, compared with $13.3 million for the same period of fiscal 2016. Revenues in both the Wind and Grid segments decreased year-over-year.

[0001628280-17-008329:8k_2_02:7]
AMSC’s net loss for the first quarter of fiscal 2017 increased to $15.3 million, or $0.91 per share, from $10.4 million, or $0.76 per share, for the same period of fiscal 2016. The Company’s non-GAAP net loss for the first quarter of fiscal 2017 was $15.4 million, or $0.92 per share, compared with a non-GAAP net loss of $8.7 million, or $0.64 per share, in the same period of fiscal 2016. Please refer to the financial table below for a reconciliation of GAAP to non-GAAP results.

[0001628280-17-008329:8k_2_02:8]
Cash, cash equivalents and restricted cash on June 30, 2017 totaled $37.7 million, compared with $27.7 million at March 31, 2017.

[0001628280-17-008329:8k_2_02:9]
“Our financial performance in the first quarter was at the top of our expected range,” said Daniel P. McGahn, President and CEO, AMSC. “We remain focused on executing on our objectives for the fiscal year. We understand the changing dynamics of the Indian wind market. We believe that our Wind and Grid segments revenues will improve in the second half of fiscal 2017.”

[0001628280-17-008329:8k_2_02:10]
Business Outlook

[0001628280-17-008329:8k_2_02:11]
For the second quarter ending September 30, 2017, AMSC expects that its revenues will be in the range of $9.0 million to $13.0 million. The Company’s net loss for the second quarter of fiscal 2017 is expected to be less than $14.0 million, or $0.73 per share.  The Company's non-GAAP net loss (as defined below) is expected to be less than $13.5 million, or $0.70 per share. The Company expects a cash burn of $7.0 million to $8.0 million in the second quarter of fiscal 2017.

[0001628280-17-008329:8k_2_02:12]
Conference Call Reminder

[0001628280-17-008329:8k_2_02:13]
| AMSC Reports Q1FY17 Results |  | Page 2 |

[0001628280-17-008329:8k_2_02:14]
In conjunction with this announcement, AMSC management will participate in a conference call with investors beginning at 10:00 a.m. Eastern Time on Wednesday, August 9 to discuss the Company’s financial results and business outlook. Those who wish to listen to the live or archived conference call webcast should visit the “Investors” section of the Company’s website at http://www.amsc.com/investors. The live call also can be accessed by dialing 866-548-4713 and using conference ID 2754180.

[0001628280-17-008329:8k_2_02:15]
About AMSC (NASDAQ: AMSC)

[0001628280-17-008329:8k_2_02:16]
AMSC generates the ideas, technologies and solutions that meet the world’s demand for smarter, cleaner … better energy™. Through its Windtec™ Solutions, AMSC provides wind turbine electronic controls and systems, designs and engineering services that reduce the cost of wind energy. Through its Gridtec™ Solutions, AMSC provides the engineering planning services and advanced grid systems that optimize network reliability, efficiency and performance. The Company’s solutions are now powering gigawatts of renewable energy globally and are enhancing the performance and reliability of power networks in more than a dozen countries. Founded in 1987, AMSC is headquartered near Boston, Massachusetts with operations in Asia, Australia, Europe and North America. For more information, please visit www.amsc.com.

[0001628280-17-008329:8k_2_02:17]
AMSC, Windtec, Gridtec, and Smarter, Cleaner … Better Energy are trademarks or registered trademarks of American Superconductor Corporation. All other brand names, product names, trademarks or service marks belong to their respective holders.

[0001628280-17-008329:8k_2_02:18]
Forward-Looking Statements

[0001628280-17-008329:8k_2_02:19]
| AMSC Reports Q1FY17 Results |  | Page 3 |

[0001628280-17-008329:8k_2_02:20]
UNAUDITED CONSOLIDATED STATEMENTS OF OPERATIONS

[0001628280-17-008329:8k_2_02:21]
(In thousands, except per share data)

[0001628280-17-008329:8k_2_02:22]
|  | Three months endedJune 30, |
|  | 2017 |  | 2016 |
| Revenues |  |  |  |
| Wind | $ | 2,278 |  |  | $ | 5,675 |  |
| Grid | 6,645 |  |  | 7,670 |  |
| Total revenues | 8,923 |  |  | 13,345 |  |
| Cost of revenues | 13,409 |  |  | 12,482 |  |
| Gross (loss)/profit | (4,486 | ) |  | 863 |  |
| Operating expenses: |  |  |  |
| Research and development | 2,717 |  |  | 2,952 |  |
| Selling, general and administrative | 6,138 |  |  | 7,216 |  |
| Amortization of acquisition related intangibles | 13 |  |  | 39 |  |
| Restructuring | 1,339 |  |  | — |  |
| Total operating expenses | 10,207 |  |  | 10,207 |  |
| Operating loss | (14,693 | ) |  | (9,344 | ) |
| Change in fair value of derivatives and warrants | 925 |  |  | (678 | ) |
| Interest expense, net | (10 | ) |  | (135 | ) |
| Other (expense) income, net | (1,374 | ) |  | 126 |  |
| Loss before income tax expense | (15,152 | ) |  | (10,031 | ) |
| Income tax expense | 100 |  |  | 324 |  |
| Net loss | $ | (15,252 | ) |  | $ | (10,355 | ) |
| Net loss per common share |  |  |  |
| Basic | $ | (0.91 | ) |  | $ | (0.76 | ) |
| Diluted | $ | (0.91 | ) |  | $ | (0.76 | ) |
| Weighted average number of common shares outstanding |  |  |  |
| Basic | 16,778 |  |  | 13,676 |  |
| Diluted | 16,778 |  |  | 13,676 |  |

[0001628280-17-008329:8k_2_02:23]
| AMSC Reports Q1FY17 Results |  | Page 4 |

[0001628280-17-008329:8k_2_02:24]
UNAUDITED CONSOLIDATED BALANCE SHEET

[0001628280-17-008329:8k_2_02:25]
(In thousands, except per share data)

[0001628280-17-008329:8k_2_02:26]
|  | June 30, 2017 |  | March 31, 2017 |
| ASSETS |  |  |  |
| Current assets: |  |  |  |
| Cash and cash equivalents | $ | 37,477 |  |  | $ | 26,784 |  |
| Accounts receivable, net | 7,752 |  |  | 7,956 |  |
| Inventory | 15,639 |  |  | 17,462 |  |
| Prepaid expenses and other current assets | 3,303 |  |  | 2,703 |  |
| Restricted cash | 100 |  |  | 795 |  |
| Total current assets | 64,271 |  |  | 55,700 |  |
| Property, plant and equipment, net | 39,282 |  |  | 43,438 |  |
| Intangibles, net | 192 |  |  | 301 |  |
| Restricted cash | 165 |  |  | 165 |  |
| Deferred tax assets | 426 |  |  | 407 |  |
| Other assets | 267 |  |  | 233 |  |
| Total assets | $ | 104,603 |  |  | $ | 100,244 |  |
| LIABILITIES AND STOCKHOLDERS' EQUITY |  |  |  |
| Current liabilities: |  |  |  |
| Accounts payable and accrued expenses | $ | 14,020 |  |  | $ | 14,490 |  |
| Note payable, current portion, net of discount of $19 as of March 31, 2017 | — |  |  | 1,481 |  |
| Derivative liabilities | 998 |  |  | 1,923 |  |
| Deferred revenue | 17,685 |  |  | 14,323 |  |
| Total current liabilities | 32,703 |  |  | 32,217 |  |
| Deferred revenue | 8,249 |  |  | 7,631 |  |
| Deferred tax liabilities | 125 |  |  | 125 |  |
| Other liabilities | 209 |  |  | 45 |  |
| Total liabilities | 41,286 |  |  | 40,018 |  |
| Stockholders' equity: |  |  |  |
| Common stock | 193 |  |  | 147 |  |
| Additional paid-in capital | 1,035,261 |  |  | 1,017,510 |  |
| Treasury stock | (1,645 | ) |  | (1,371 | ) |
| Accumulated other comprehensive income (loss) | 317 |  |  | (503 | ) |
| Accumulated deficit | (970,809 | ) |  | (955,557 | ) |
| Total stockholders' equity | 63,317 |  |  | 60,226 |  |
| Total liabilities and stockholders' equity | $ | 104,603 |  |  | $ | 100,244 |  |

[0001628280-17-008329:8k_2_02:27]
| AMSC Reports Q1FY17 Results |  | Page 5 |

[0001628280-17-008329:8k_2_02:28]
UNAUDITED CONSOLIDATED STATEMENTS OF CASH FLOWS

[0001628280-17-008329:8k_2_02:29]
(In thousands)

[0001628280-17-008329:8k_2_02:30]
|  | Three months endedJune 30, |
|  | 2017 |  | 2016 |
| Cash flows from operating activities: |  |  |  |
| Net loss | $ | (15,252 | ) |  | $ | (10,355 | ) |
| Adjustments to reconcile net loss to net cash used in operations: |  |  |  |
| Depreciation and amortization | 4,345 |  |  | 1,871 |  |
| Stock-based compensation expense | 754 |  |  | 999 |  |
| Provision for excess and obsolete inventory | 250 |  |  | 272 |  |
| Change in fair value of derivatives and warrants | (925 | ) |  | 678 |  |
| Non-cash interest expense | 19 |  |  | 56 |  |
| Other non-cash items | 718 |  |  | (307 | ) |
| Changes in operating asset and liability accounts: |  |  |  |
| Accounts receivable | 319 |  |  | 12,192 |  |
| Inventory | 1,719 |  |  | (10,750 | ) |
| Prepaid expenses and other current assets | (273 | ) |  | 1,555 |  |
| Accounts payable and accrued expenses | (404 | ) |  | 1,650 |  |
| Deferred revenue | 3,300 |  |  | 79 |  |
| Net cash used in operating activities | (5,430 | ) |  | (2,060 | ) |
| Cash flows from investing activities: |  |  |  |
| Net cash provided by/(used in) investing activities | 606 |  |  | (271 | ) |
| Cash flows from financing activities: |  |  |  |
| Net cash provided by/(used in) financing activities | 15,105 |  |  | (1,461 | ) |
| Effect of exchange rate changes on cash and cash equivalents | 412 |  |  | (327 | ) |
| Net increase/(decrease) in cash and cash equivalents | 10,693 |  |  | (4,119 | ) |
| Cash and cash equivalents at beginning of year | 26,784 |  |  | 39,330 |  |
| Cash and cash equivalents at end of year | $ | 37,477 |  |  | $ | 35,211 |  |

[0001628280-17-008329:8k_2_02:31]
| AMSC Reports Q1FY17 Results |  | Page 6 |

[0001628280-17-008329:8k_2_02:32]
RECONCILIATION OF GAAP NET INCOME (LOSS) TO NON-GAAP NET INCOME (LOSS)

[0001628280-17-008329:8k_2_02:33]
(In thousands, except per share data)

[0001628280-17-008329:8k_2_02:34]
|  | Three Months EndedJune 30, |
|  | 2017 |  | 2016 |
| Net loss | $ | (15,252 | ) |  | $ | (10,355 | ) |
| Stock-based compensation | 754 |  |  | 999 |  |
| Amortization of acquisition-related intangibles | 13 |  |  | 39 |  |
| Consumption of zero cost-basis inventory | (57 | ) |  | (158 | ) |
| Change in fair value of derivatives and warrants | (925 | ) |  | 678 |  |
| Non-cash interest expense | 19 |  |  | 56 |  |
| Tax effect of adjustments | 9 |  |  | $ | 25 |  |
| Non-GAAP net loss | $ | (15,439 | ) |  | $ | (8,716 | ) |
| Non-GAAP net loss per share | $ | (0.92 | ) |  | $ | (0.64 | ) |
| Weighted average shares outstanding - basic and diluted | 16,778 |  |  | 13,676 |  |

[0001628280-17-008329:8k_2_02:35]
Reconciliation of Forecast GAAP Net Loss to Non-GAAP Net Loss

[0001628280-17-008329:8k_2_02:36]
(In thousands, except per share data)

[0001628280-17-008329:8k_2_02:37]
|  | Three months ending |
| September 30, 2017 |
| Net loss | $(14,000) |
| Stock-based compensation | 700 |  |
| Amortization of acquisition-related intangibles | 13 |  |
| Consumption of zero-cost inventory | (200 | ) |
| Tax effect of adjustments | 32 |  |
| Non-GAAP net loss | $(13,455) |
| Non-GAAP net loss per share | $(0.70) |
| Shares outstanding | 19,100 |  |

[0001628280-17-008329:8k_2_02:38]
Note: Non-GAAP net loss is defined by the Company as net loss before stock-based compensation; amortization of acquisition-related intangibles; consumption of zero cost-basis inventory; non-cash interest expense; change in fair value of derivatives and warrants; tax effect of adjustments; and other unusual charges. The Company believes non-GAAP net loss assists management and investors in comparing the Company’s performance across reporting periods on a consistent basis by excluding these non-cash, non-recurring or other charges that it does not believe are indicative of its core operating performance. The Company is not able to provide the change in fair value of derivatives and warrants on a forward-looking basis without unreasonable efforts because the calculation for that change is primarily driven by the closing price and volatility of the Company's stock at the end of each fiscal quarter, which cannot be reasonably estimated at this time.  The Company does not expect to adjust GAAP net loss for non-cash interest expense in future quarters due to the repayment of the Company’s term loan during the first quarter of fiscal 2017.  Actual non-GAAP net loss for the fiscal quarter ending September 30, 2017, including the above adjustments, may differ materially from those forecasted in the table above.

[0001628280-17-008329:8k_2_02:39]
Generally, a non-GAAP financial measure is a numerical measure of a company's performance, financial position or cash flow that either excludes or includes amounts that are not normally excluded or included in the most directly comparable measure calculated and presented in accordance with GAAP. The non-GAAP measures included in this release, however, should be considered in addition to, and not as a substitute for or superior to, operating income, cash flows, or other measures of financial performance prepared in accordance with GAAP. A reconciliation of GAAP to non-GAAP net loss is set forth in the table above.

[0001628280-17-008329:8k_2_02:40]
| AMSC Reports Q1FY17 Results |  | Page 7 |

[0001628280-17-008329:8k_2_02:41]
AMSC Contact:

[0001628280-17-008329:8k_2_02:42]
Brion D. Tanous

[0001628280-17-008329:8k_2_02:43]
AMSC Investor Relations

[0001628280-17-008329:8k_2_02:44]
Phone: 424-634-8592

[0001628280-17-008329:8k_2_02:45]
Email: Brion.Tanous@amsc.com
