# AMSC notes — 0001628280-17-008331


## us-gaap:AccountsPayableAndAccruedLiabilitiesDisclosureTextBlock

[0001628280-17-008331:notes:1]
[same as prior period, unchanged from 0001628280-17-000901:notes:1]

[0001628280-17-008331:notes:2]
Accounts payable and accrued expenses at June 30, 2017 and March 31, 2017 consisted of the following (in thousands):

[0001628280-17-008331:notes:3]
|  | June 30, 2017 |  | March 31, 2017 |
| Accounts payable | $ | 1,800 |  |  | $ | 3,207 |  |
| Accrued inventories in-transit | 709 |  |  | 313 |  |
| Accrued other miscellaneous expenses | 2,032 |  |  | 2,240 |  |
| Accrued restructuring | 751 |  |  | — |  |
| Accrued compensation | 5,333 |  |  | 5,042 |  |
| Income taxes payable | 1,369 |  |  | 1,344 |  |
| Accrued warranty | 2,026 |  |  | 2,344 |  |
| Total | $ | 14,020 |  |  | $ | 14,490 |  |

[0001628280-17-008331:notes:4]
[same as prior period, unchanged from 0001628280-17-000901:notes:4]

[0001628280-17-008331:notes:5]
[same as prior period, unchanged from 0001628280-17-000901:notes:5]

[0001628280-17-008331:notes:6]
|  | Three months ended June 30, |
|  | 2017 |  | 2016 |
| Balance at beginning of period | $ | 2,344 |  |  | $ | 3,601 |  |
| Change in accruals for warranties during the period | 41 |  |  | 101 |  |
| Settlements during the period | (359 | ) |  | (928 | ) |
| Balance at end of period | $ | 2,026 |  |  | $ | 2,774 |  |


## us-gaap:BasisOfAccountingPolicyPolicyTextBlock

[0001628280-17-008331:notes:7]
These unaudited condensed consolidated financial statements of the Company have been prepared on a going concern basis in accordance with United States generally accepted accounting principles (“GAAP”) and the Securities and Exchange Commission’s (“SEC”) instructions to Form 10-Q. The going concern basis of presentation assumes that the Company will continue operations and will be able to realize its assets and discharge its liabilities and commitments in the normal course of business. Certain information and footnote disclosures normally included in the financial statements prepared in accordance with GAAP have been condensed or omitted pursuant to those instructions. The year-end condensed balance sheet data was derived from audited financial statements but does not include all disclosures required by GAAP. The unaudited condensed consolidated financial statements, in the opinion of management, reflect all adjustments (consisting of normal recurring adjustments) necessary for a fair statement of the results for the interim periods ended June 30, 2017 and 2016 and the financial position at June 30, 2017.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001628280-17-008331:notes:8]
Commitments and Contingencies

[0001628280-17-008331:notes:9]
Legal Contingencies

[0001628280-17-008331:notes:10]
From time to time, the Company is involved in legal and administrative proceedings and claims of various types. The Company records a liability in its consolidated financial statements for these matters when a loss is known or considered probable and the amount can be reasonably estimated. The Company reviews these estimates each accounting period as additional information is known and adjusts the loss provision when appropriate. If a matter is both probable to result in a liability and the amounts of loss can be reasonably estimated, the Company estimates and discloses the possible loss or range of loss to the extent necessary to make the consolidated financial statements not misleading. If the loss is not probable or cannot be reasonably estimated, a liability is not recorded in its consolidated financial statements.

[0001628280-17-008331:notes:11]
On September 13, 2011, the Company commenced a series of legal actions in China against Sinovel Wind Group Co. Ltd. (“Sinovel”). The Company’s Chinese subsidiary, Suzhou AMSC Superconductor Co. Ltd., filed a claim for arbitration with the Beijing Arbitration Commission in accordance with the terms of the Company’s supply contracts with Sinovel. The case is captioned (2011) Jing Zhong An Zi No. 963.  The Company alleges that Sinovel committed various material breaches of its contracts with the Company and Sinovel has refused to pay past due amounts for prior shipments of core electrical components and spare parts. The Company is seeking compensation for past product shipments and retention (including interest) in the amount of approximately RMB 485 million (approximately $72 million) due to Sinovel’s breaches of its contracts. The Company is also seeking specific performance of its existing contracts as well as reimbursement of all costs and reasonable expenses with respect to the arbitration. The value of the undelivered components under the existing contracts, including the deliveries refused by Sinovel in March 2011, amounts to approximately RMB 4.6 billion (approximately $679 million).

[0001628280-17-008331:notes:12]
On October 8, 2011, Sinovel filed with the Beijing Arbitration Commission an application under the caption (2011) Jing Zhong An Zi No. 963, for a counterclaim against the Company for breach of the same contracts under which the Company filed its original arbitration claim. Sinovel claims, among other things, that the goods supplied by the Company do not conform to the standards specified in the contracts and claims damages in the amount of approximately RMB 1.2 billion (approximately $177 million) upon Sinovel’s requests for change of counterclaim. On February 27, 2012, Sinovel filed with the Beijing Arbitration Commission an application under the caption (2012) Jing Zhong An Zi No. 157, against the Company for breach of the same contracts under which the Company filed its original arbitration claim. Sinovel claims, among other things, that the goods supplied by the Company do not conform to the standards specified in the contracts and claims damages in the amount of approximately RMB 105 million (approximately $15 million). The Company believes that Sinovel’s claims are without merit and it intends to defend these actions vigorously. Since the proceedings in this matter are still in the early technical review phase, the Company cannot reasonably estimate possible losses or range of losses at this time.

[0001628280-17-008331:notes:13]
Other

[0001628280-17-008331:notes:14]
The Company enters into long-term construction contracts with customers that require the Company to obtain performance bonds. The Company is required to deposit an amount equivalent to some or all the face amount of the performance bonds into an escrow account until the termination of the bond. When the performance conditions are met, amounts deposited as collateral for the performance bonds are returned to the Company. In addition, the Company has various contractual arrangements in which minimum quantities of goods or services have been committed to be purchased on an annual basis.

[0001628280-17-008331:notes:15]
As of June 30, 2017, the Company had $0.1 million of restricted cash included in current assets and $0.2 million of restricted cash included in long-term assets. These amounts included in restricted cash primarily represent deposits to secure letters of credit for various supply contracts. These deposits are held in interest bearing accounts.


## us-gaap:DebtDisclosureTextBlock

[0001628280-17-008331:notes:16]
Debt

[0001628280-17-008331:notes:17]
Senior Secured Term Loans

[0001628280-17-008331:notes:18]
On December 19, 2014, the Company entered into a second amendment to its Loan and Security Agreement with Hercules (the “Hercules Second Amendment”) and entered into a new term loan, borrowing an additional $1.5 million (the “Term Loan C”).  After closing fees and expenses, the net proceeds to the Company for the Term Loan C were $1.4 million. The Company made interest only payments at an interest rate of 11% through March 16, 2017 when the interest rate was increased to 11.25%, until maturity on June 1, 2017, when Term Loan C was repaid in its entirety.

[0001628280-17-008331:notes:19]
Hercules received warrants to purchase 13,927 shares of common stock (the “First Warrant”) and 25,641 shares of common stock (the “Second Warrant”) in conjunction with prior term loans that have been repaid in full.  Due to certain adjustment provisions within the warrants, they qualified for liability accounting.  The fair value of the warrants, $0.4 million and $0.2 million, respectively, was recorded upon issuance to debt discount and a warrant liability. In conjunction with the Hercules Second Amendment, the First Warrant and Second Warrant were cancelled and replaced with the issuance of a new warrant (the “Hercules Warrant”) to purchase 58,823 shares of common stock at an exercise price of $11.00 per share, subject to adjustment.  The Hercules Warrant expires on June 30, 2020.  See Note 11, “Warrants and Derivative Liabilities”, for a discussion on the Hercules Warrant and the valuation assumptions used.

[0001628280-17-008331:notes:20]
During the three months ended June 30, 2016, the Company recorded non-cash interest expense for amortization of the debt discount related to a prior term loan of less than $0.1 million.  Under Term Loan C, the total debt discount, including the Hercules Warrant, end of term fee and legal and origination costs of $0.3 million was amortized into interest expense over the term of the Term Loan C using the effective interest method.  During each of the three months ended June 30, 2017 and 2016, the Company recorded non-cash interest expense for amortization of the debt discount related to the Term Loan C of less than $0.1 million.

[0001628280-17-008331:notes:21]
Interest expense on the Term Loans for the three months ended June 30, 2017 and 2016, was less than $0.1 million and $0.2 million, respectively, each of which included less than $0.1 million of non-cash interest expense related to the amortization of the debt discount on the respective Term Loans.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001628280-17-008331:notes:22]
[same as prior period, unchanged from 0001628280-17-000901:notes:25]

[0001628280-17-008331:notes:23]
[same as prior period, unchanged from 0001628280-17-000901:notes:26]

[0001628280-17-008331:notes:24]
On April 4, 2012, the Company entered into a Purchase Agreement with Capital Ventures International ("CVI"). The Purchase Agreement included a warrant to purchase 309,406 shares of the Company’s common stock (the “Original Warrant”).  Pursuant to an exchange in October 2013, the Original Warrant was exchanged for a new warrant (the “Exchanged Warrant”).  The Exchanged Warrant is exercisable at any time on or after the date that is six months after the issuance of the Original Warrant until its expiration on October 4, 2017.  The Exchanged Warrant entitles CVI to purchase shares of the Company’s common stock for a period of five years from the date the Original Warrant becomes exercisable at an exercise price equal to $12.83 per share, subject to certain price-based and other anti-dilution adjustments. The Exchanged Warrant may not be exercised if, after giving effect to the conversion, CVI together with its affiliates, would beneficially own in excess of 4.99% of the Company’s common stock. This percentage may be raised to any other percentage not in excess of 9.99% at the option of CVI, upon at least 61-days prior notice to the Company, or lowered to any other percentage, at the option of CVI, at any time.

[0001628280-17-008331:notes:25]
[same as prior period, unchanged from 0001628280-17-000901:notes:28]

[0001628280-17-008331:notes:26]
[same as prior period, unchanged from 0001628280-17-000901:notes:29]

[0001628280-17-008331:notes:27]
[same as prior period, unchanged from 0001628280-17-000901:notes:30]

[0001628280-17-008331:notes:28]
| Fiscal Year 17 | June 30, 2017 |
| Risk-free interest rate | 1.05% |
| Expected annual dividend yield | — |
| Expected volatility | 78.25% |
| Term (years) | 0.26 |
| Fair value | $— |

[0001628280-17-008331:notes:29]
| Fiscal Year 16 | March 31,2017 |  | December 31,2016 |  | September 30,2016 |  | June 30,2016 |  | March 31,2016 |
| Risk-free interest rate | 0.91% |  | 0.56% |  | 0.59% |  | 0.48% |  | 0.66% |
| Expected annual dividend yield | — |  | — |  | — |  | — |  | — |
| Expected volatility | 44.12% |  | 58.04% |  | 70.50% |  | 76.30% |  | 76.76% |
| Term (years) | 0.51 |  | 0.76 |  | 1.01 |  | 1.26 |  | 1.51 |
| Fair value | $— |  | $0.1 million |  | $0.2 million |  | $0.4 million |  | $0.4 million |

[0001628280-17-008331:notes:30]
The Company recorded no change in the fair value of the Exchanged Warrant during the three months ended June 30, 2017 and 2016, respectively.

[0001628280-17-008331:notes:31]
[same as prior period, unchanged from 0001628280-17-000901:notes:34]

[0001628280-17-008331:notes:32]
On December 19, 2014, the Company entered into the Hercules Second Amendment.  See Note 10, “Debt” for additional information.  In conjunction with the agreement, the Company issued the Hercules Warrant to purchase 58,823 shares of the Company’s common stock.  The Hercules Warrant is exercisable at any time after its issuance at an exercise price of $8.02 per share, subject to certain price-based and other anti-dilution adjustments, and expires on June 30, 2020.  The Company accounts for the Hercules Warrant as a liability due to certain provisions within the warrant.  The Hercules Warrant is subject to revaluation at each balance sheet date and any change in fair value is recorded as a change in fair value of derivatives and warrants until the earlier of its expiration or its exercise, at which time the warrant liability will be reclassified to equity.

[0001628280-17-008331:notes:33]
[same as prior period, unchanged from 0001628280-17-000901:notes:37]

[0001628280-17-008331:notes:34]
| Fiscal Year 17 | June 30, 2017 |
| Risk-free interest rate | 1.58% |
| Expected annual dividend yield | — |
| Expected volatility | 67.76% |
| Term (years) | 2.97 |
| Fair value | $0.1 million |

[0001628280-17-008331:notes:35]
| Fiscal Year 16 | March 31,2017 |  | December 31,2016 |  | September 30,2016 |  | June 30,2016 |  | March 31,2016 |
| Risk-free interest rate | 1.55% |  | 1.57% |  | 0.97% |  | 0.86% |  | 1.08% |
| Expected annual dividend yield | — |  | — |  | — |  | — |  | — |
| Expected volatility | 66.51% |  | 67.28% |  | 67.98% |  | 68.34% |  | 70.25% |
| Term (years) | 3.25 |  | 3.50 |  | 3.75 |  | 4.00 |  | 4.25 |
| Fair value | $0.2 million |  | $0.2 million |  | $0.2 million |  | $0.3 million |  | $0.2 million |

[0001628280-17-008331:notes:36]
The Company recorded a net gain, resulting from a decrease of less than $0.1 million in fair value of derivatives and warrants during the three months ended June 30, 2017 and a net loss, resulting from an increase in the fair value of the Hercules Warrant of less than $0.1 million during the three months ended June 30, 2016.

[0001628280-17-008331:notes:37]
[same as prior period, unchanged from 0001628280-17-000901:notes:41]

[0001628280-17-008331:notes:38]
On November 13, 2014, the Company completed an offering of 909,090 units of the Company’s common stock with Hudson Bay Capital. Each unit consisted of one share of the Company’s common stock and 0.9 of a warrant to purchase one share of common stock, or a warrant to purchase in the aggregate 818,181 shares (the “November 2014 Warrant”).  The November 2014 Warrant is exercisable at any time, at an exercise price equal to $7.98 per share, subject to certain price-based and other anti-dilution adjustments, and expires on November 13, 2019.  The Company accounts for the November 2014 Warrant as a liability due to certain provisions within the warrant.  The November 2014 Warrant is subject to revaluation at each balance sheet date and any change in fair value is recorded as a change in fair value of derivatives and warrants until the earlier of its expiration or its exercise, at which time the warrant liability will be reclassified to equity.

[0001628280-17-008331:notes:39]
[same as prior period, unchanged from 0001628280-17-000901:notes:44]

[0001628280-17-008331:notes:40]
| Fiscal Year 17 | June 30, 2017 |
| Risk-free interest rate | 1.44% |
| Expected annual dividend yield | — |
| Expected volatility | 67.21% |
| Term (years) | 2.37 |
| Fair value | $0.9 million |

[0001628280-17-008331:notes:41]
| Fiscal Year 16 | March 31,2017 |  | December 31,2016 |  | September 30,2016 |  | June 30,2016 |  | March 31,2016 |
| Risk-free interest rate | 1.41% |  | 1.43% |  | 0.93% |  | 0.77% |  | 0.98% |
| Expected annual dividend yield | — |  | — |  | — |  | — |  | — |
| Expected volatility | 66.53% |  | 69.31% |  | 68.96% |  | 70.01% |  | 69.88% |
| Term (years) | 2.62 |  | 2.87 |  | 3.12 |  | 3.37 |  | 3.62 |
| Fair value | $1.8 million |  | $2.3 million |  | $2.3 million |  | $3.2 million |  | $2.6 million |

[0001628280-17-008331:notes:42]
The Company recorded a net gain of $0.9 million resulting from a decrease in the fair value of the November 2014 Warrant in the three months ended June 30, 2017 and a net loss, resulting from an increase in the fair value of the November 2014 Warrant of $0.6 million in the three months ended June 30, 2016.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001628280-17-008331:notes:43]
[same as prior period, unchanged from 0001628280-17-000901:notes:49]

[0001628280-17-008331:notes:44]
The Company accounts for its stock-based compensation at fair value. The following table summarizes stock-based compensation expense by financial statement line item for the three months ended June 30, 2017 and 2016 (in thousands):

[0001628280-17-008331:notes:45]
|  | Three months ended June 30, |
|  | 2017 |  | 2016 |
| Cost of revenues | $ | 36 |  |  | $ | 50 |  |
| Research and development | 49 |  |  | 30 |  |
| Selling, general and administrative | 669 |  |  | 919 |  |
| Total | $ | 754 |  |  | $ | 999 |  |

[0001628280-17-008331:notes:46]
The Company issued 33,487 shares of immediately vested common stock during the three months ended June 30, 2017, and 25,000 shares of immediately vested common stock and 136,000 restricted stock awards during the three months ended June 30, 2016.  These restricted stock awards generally vest over 2-3 years.  Awards for restricted stock include both time-based and performance-based awards.  For options and awards that vest upon the passage of time, expense is being recorded over the vesting period.  Performance-based awards are expensed over the requisite service period based on probability of achievement.  In addition, the Company issued 16,667 restricted stock units under the 2007 Stock Incentive Plan during the three months ended June 30, 2017, each of which represents the right to receive one share of common stock in connection with a severance agreement entered into with one of our former executive officers. These restricted stock units vested and were settled in shares of common stock on the eighth day after receipt of an irrevocable release.

[0001628280-17-008331:notes:47]
The estimated fair value of the Company’s stock-based awards, less expected annual forfeitures, is amortized over the awards’ service period. The total unrecognized compensation cost for unvested outstanding stock options was $0.4 million at June 30, 2017. This expense will be recognized over a weighted average expense period of approximately 1.7 years. The total unrecognized compensation cost for unvested outstanding restricted stock was $1.3 million at June 30, 2017. This expense will be recognized over a weighted-average expense period of approximately 1.4 years.

[0001628280-17-008331:notes:48]
The Company did not grant any stock options during the three months ended June 30, 2017 or 2016.


## us-gaap:EarningsPerShareTextBlock

[0001628280-17-008331:notes:49]
[same as prior period, unchanged from 0001628280-17-000901:notes:57]

[0001628280-17-008331:notes:50]
Basic net loss per share (“EPS”) is computed by dividing net loss by the weighted-average number of common shares outstanding for the period. Where applicable, diluted EPS is computed by dividing the net loss by the weighted-average number of common shares and dilutive common equivalent shares outstanding during the period, calculated using the treasury stock method. Common equivalent shares include the effect of restricted stock, exercise of stock options and warrants and contingently issuable shares. For the three months ended June 30, 2017, 1.5 million shares were not included in the calculation of diluted EPS as they were considered anti-dilutive, of which 0.3 million relate to outstanding stock options, and 1.2 million relate to outstanding warrants.  For the three months ended June 30, 2016, 1.6 million shares were not included in the calculation of diluted EPS as they were considered anti-dilutive, of which 0.4 million relate to outstanding stock options, and 1.2 million relate to outstanding warrants.

[0001628280-17-008331:notes:51]
The following table reconciles the numerators and denominators of the earnings per share calculation for the three months ended June 30, 2017 and 2016 (in thousands, except per share data):

[0001628280-17-008331:notes:52]
|  | Three months ended June 30, |
|  | 2017 |  | 2016 |
| Numerator: |  |  |  |
| Net loss | $ | (15,252 | ) |  | $ | (10,355 | ) |
| Denominator: |  |  |  |
| Weighted-average shares of common stock outstanding | 17,089 |  |  | 14,132 |  |
| Weighted-average shares subject to repurchase | (311 | ) |  | (456 | ) |
| Shares used in per-share calculation ― basic | 16,778 |  |  | 13,676 |  |
| Shares used in per-share calculation ― diluted | 16,778 |  |  | 13,676 |  |
| Net loss per share ― basic | $ | (0.91 | ) |  | $ | (0.76 | ) |
| Net loss per share ― diluted | $ | (0.91 | ) |  | $ | (0.76 | ) |


## us-gaap:FairValueDisclosuresTextBlock

[0001628280-17-008331:notes:53]
[same as prior period, unchanged from 0001628280-17-000901:notes:66]

[0001628280-17-008331:notes:54]
[same as prior period, unchanged from 0001628280-17-000901:notes:67]

[0001628280-17-008331:notes:55]
[same as prior period, unchanged from 0001628280-17-000901:notes:68]

[0001628280-17-008331:notes:56]
The Company provides a gross presentation of activity within Level 3 measurement roll-forward and details of transfers in and out of Level 1 and 2 measurements.  A change in the hierarchy of an investment from its current level is reflected in the period during which the pricing methodology of such investment changes.  Disclosure of the transfer of securities from Level 1 to Level 2 or Level 3 is made in the event that the related security is significant to total cash and investments.  The Company did not have any transfers of assets and liabilities from Level 1 and Level 2 to Level 3 of the fair value measurement hierarchy during the three months ended June 30, 2017.

[0001628280-17-008331:notes:57]
[same as prior period, unchanged from 0001628280-17-000901:notes:70]

[0001628280-17-008331:notes:58]
The following table provides the assets and liabilities carried at fair value on a recurring basis, measured as of June 30, 2017 and March 31, 2017 (in thousands):

[0001628280-17-008331:notes:59]
|  | TotalCarryingValue |  | Quoted Prices inActive Markets(Level 1) |  | Significant OtherObservable Inputs(Level 2) |  | SignificantUnobservable Inputs(Level 3) |
| June 30, 2017: |  |  |  |  |  |  |  |
| Assets: |  |  |  |  |  |  |  |
| Cash equivalents | $ | 27,334 |  |  | $ | 27,334 |  |  | $ | — |  |  | $ | — |  |
| Derivative liabilities: |  |  |  |  |  |  |  |
| Warrants | $ | 998 |  |  | $ | — |  |  | $ | — |  |  | $ | 998 |  |

[0001628280-17-008331:notes:60]
|  | TotalCarryingValue |  | Quoted Prices inActive Markets(Level 1) |  | Significant OtherObservable Inputs(Level 2) |  | SignificantUnobservable Inputs(Level 3) |
| March 31, 2017: |  |  |  |  |  |  |  |
| Assets: |  |  |  |  |  |  |  |
| Cash equivalents | $ | 14,105 |  |  | $ | 14,105 |  |  | $ | — |  |  | $ | — |  |
| Derivative liabilities: |  |  |  |  |  |  |  |
| Warrants | $ | 1,923 |  |  | $ | — |  |  | $ | — |  |  | $ | 1,923 |  |

[0001628280-17-008331:notes:61]
[same as prior period, unchanged from 0001628280-17-000901:notes:74]

[0001628280-17-008331:notes:62]
|  | Warrants |
| April 1, 2017 | $ | 1,923 |  |
| Mark to market adjustment | (925 | ) |
| Balance at June 30, 2017 | $ | 998 |  |

[0001628280-17-008331:notes:63]
|  | Warrants |
| April 1, 2016 | $ | 3,227 |  |
| Mark to market adjustment | (1,304 | ) |
| Balance at March 31, 2017 | $ | 1,923 |  |

[0001628280-17-008331:notes:64]
[same as prior period, unchanged from 0001628280-17-000901:notes:77]

[0001628280-17-008331:notes:65]
[same as prior period, unchanged from 0001628280-17-000901:notes:78]

[0001628280-17-008331:notes:66]
[same as prior period, unchanged from 0001628280-17-000901:notes:79]

[0001628280-17-008331:notes:67]
[same as prior period, unchanged from 0001628280-17-000901:notes:80]

[0001628280-17-008331:notes:68]
Warrants were issued in conjunction with a Securities Purchase Agreement (the “Purchase Agreement”) with Capital Ventures International (“CVI”) in April 2012, an equity offering to Hudson Bay Capital in November 2014, and a Loan and Security Agreement with Hercules Technology Growth Capital, Inc. (“Hercules”) in June 2012 and through subsequent amendments. See Note 10, “Debt,” and Note 11 “Warrants and Derivative Liabilities,” for additional information. These warrants are subject to revaluation at each balance sheet date, and any change in fair value will be recorded as a change in fair value in derivatives and warrants until the earlier of their exercise or expiration.

[0001628280-17-008331:notes:69]
The Company relies on various assumptions in a lattice model to determine the fair value of warrants. The Company has valued the warrants within Level 3 of the valuation hierarchy. See Note 11, “Warrants and Derivative Liabilities,” for a discussion of the warrants and the valuation assumptions used.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001628280-17-008331:notes:70]
[same as prior period, unchanged from 0001628280-17-000901:notes:83]

[0001628280-17-008331:notes:71]
The Company recorded an income tax expense of $0.1 million and $0.3 million in the three months ended June 30, 2017, and 2016, respectively.

[0001628280-17-008331:notes:72]
Accounting for income taxes requires a two-step approach to recognizing and measuring uncertain tax positions.  The first step is to evaluate the tax position for recognition by determining if, based on the technical merits, it is more likely than not the position will be sustained upon audit, including resolution of related appeals or litigation processes, if any.  The second step is to measure the tax benefit as the largest amount that is more than 50% likely to be realized upon ultimate settlement.  The Company re-evaluates these uncertain tax positions on a quarterly basis.  The evaluation is based on factors including, but not limited to, changes in facts or circumstances, changes in tax law, effectively settled issues under audit and new audit activity.  Any changes in these factors could result in the recognition of a tax benefit or an additional charge to the tax provision.  The Company did not identify any uncertain tax positions in the three months ended June 30, 2017 and did not have any gross unrecognized tax benefits as of March 31, 2017.


## us-gaap:InventoryDisclosureTextBlock

[0001628280-17-008331:notes:73]
[same as prior period, unchanged from 0001628280-17-000901:notes:86]

[0001628280-17-008331:notes:74]
Inventory at June 30, 2017 and March 31, 2017 consisted of the following (in thousands):

[0001628280-17-008331:notes:75]
|  | June 30, 2017 |  | March 31, 2017 |
| Raw materials | $ | 6,026 |  |  | $ | 4,263 |  |
| Work-in-process | 819 |  |  | 426 |  |
| Finished goods | 6,485 |  |  | 8,016 |  |
| Deferred program costs | 2,309 |  |  | 4,757 |  |
| Net inventory | $ | 15,639 |  |  | $ | 17,462 |  |

[0001628280-17-008331:notes:76]
The Company recorded inventory write-downs of $0.3 million for each of the three months ended June 30, 2017 and 2016.  These write downs were based on evaluating its inventory on hand for excess quantities and obsolescence.

[0001628280-17-008331:notes:77]
Deferred program costs as of June 30, 2017 and March 31, 2017 primarily represent costs incurred on programs accounted for under contract accounting where the Company needs to complete development milestones before revenue and costs will be recognized.


## us-gaap:LoansNotesTradeAndOtherReceivablesDisclosureTextBlock

[0001628280-17-008331:notes:78]
[same as prior period, unchanged from 0001628280-17-000901:notes:91]

[0001628280-17-008331:notes:79]
Accounts receivable at June 30, 2017 and March 31, 2017 consisted of the following (in thousands):

[0001628280-17-008331:notes:80]
|  | June 30, 2017 |  | March 31, 2017 |
| Accounts receivable (billed) | $ | 6,661 |  |  | $ | 7,436 |  |
| Accounts receivable (unbilled) | 1,145 |  |  | 574 |  |
| Less: Allowance for doubtful accounts | (54 | ) |  | (54 | ) |
| Accounts receivable, net | $ | 7,752 |  |  | $ | 7,956 |  |


## us-gaap:NewAccountingPronouncementsAndChangesInAccountingPrinciplesTextBlock

[0001628280-17-008331:notes:81]
Recent Accounting Pronouncements

[0001628280-17-008331:notes:82]
In May 2014, the Financial Accounting Standards Board (“FASB”) and the International Accounting Standards Board (IASB) issued, ASU 2014-09, Revenue from Contracts with Customers (Topic 606). The guidance substantially converges final standards on revenue recognition between the FASB and IASB providing a framework on addressing revenue recognition issues and, upon its effective date, replaces almost all existing revenue recognition guidance, including industry-specific guidance, in current U.S. generally accepted accounting principles. The FASB has subsequently issued the following amendments to ASU 2014-09 which are all effective for annual reporting periods beginning after December 15, 2017.

[0001628280-17-008331:notes:83]
| • | In March 2016, the FASB issued ASU No. 2016-08, Revenue from Contracts with Customers (Topic 606): Principal versus Agent Considerations, which clarifies the implementation guidance on principal versus agent considerations. |

[0001628280-17-008331:notes:84]
| • | In April 2016, the FASB issued ASU No. 2016-10, Revenue from Contracts with Customers (Topic 606): Identifying Performance Obligations and Licensing, which clarifies certain aspects of identifying performance obligations and licensing implementation guidance. |

[0001628280-17-008331:notes:85]
| • | In May 2016, the FASB issued ASU No. 2016-12, Revenue from Contracts with Customers (Topic 606): Narrow- Scope Improvements and Practical Expedients related to disclosures of remaining performance obligations, as well as other amendments to guidance on collectability, non-cash consideration and the presentation of sales and other similar taxes collected from customers. |

[0001628280-17-008331:notes:86]
| • | In December 2016, the FASB issued ASU No. 2016-20, Technical Corrections and Improvements to Topic 606, Revenue from Contracts with Customers, which amends certain narrow aspects of the guidance issued in ASU 2014-09 including guidance related to the disclosure of remaining performance obligations and prior-period performance obligations, as well as other amendments to the guidance on loan guarantee fees, contract costs, refund liabilities, advertising costs and the clarification of certain examples. |

[0001628280-17-008331:notes:87]
The Company is currently evaluating the provisions of ASU 2014-09 and its amendments, and assessing the impact the adoption of this guidance will have on its financial position, results of operations and disclosures.  The Company anticipates the adoption of this guidance will result in certain changes in the identification of deliverables in its contracts and allocation of transaction price. The Company is required to adopt the new standards in the first quarter of fiscal 2018 and expects to do so retrospectively with the cumulative effect of initially applying the guidance recognized at the date of initial application (the cumulative catch-up transition method). The Company is still evaluating the final impact of this adoption method on it's  consolidated financial statements.

[0001628280-17-008331:notes:88]
In January 2016, the FASB issued ASU 2016-01, Financial Instruments-Overall (Subtopic 825-10): Recognition and Measurement of Financial Assets and Financial Liabilities.  The amendments in ASU 2016-01 will enhance the reporting model for financial instruments to provide users of financial statements with more decision-useful information. This ASU is effective for annual reporting periods beginning after December 15, 2017, and interim periods within those fiscal years.  The Company is currently evaluating the impact, if any, the adoption of ASU 2016-01 may have on its consolidated financial statements.

[0001628280-17-008331:notes:89]
In February 2016, the FASB issued ASU 2016-02, Leases (Topic 842). The guidance in this ASU supersedes the leasing guidance in Topic 840, Leases. Under the new guidance, lessees are required to recognize lease assets and lease liabilities on the balance sheet for all leases with terms longer than 12 months. Leases will be classified as either finance or operating, with classification affecting the pattern of expense recognition in the income statement. This ASU is effective for fiscal years beginning after December 15, 2019, including interim periods within those fiscal years. A modified retrospective transition approach is required for lessees for capital and operating leases existing at, or entered into after, the beginning of the earliest comparative period presented in the financial statements, with certain practical expedients available. The Company is currently evaluating the effects adoption of this guidance will have on its consolidated financial statements.

[0001628280-17-008331:notes:90]
In June 2016, the FASB issued ASU 2016-13, Financial Instruments-Credit Losses (Topic 326): Measurement of Credit Losses on Financial Instruments.  The amendments in ASU 2016-13 will provide more decision useful information about the expected credit losses on financial instruments and other commitments to extend credit held by a reporting entity at each reporting date. The ASU is effective for annual reporting periods beginning after December 15, 2019, including interim periods within that year.  The Company is currently evaluating the impact, if any, the adoption of ASU 2016-13 may have on its consolidated financial statements.

[0001628280-17-008331:notes:91]
In 2016, the FASB issued the following two ASU's on Statement of Cash Flows (Topic 230).  Both amendments are effective for annual reporting periods beginning after December 15, 2017, including interim periods within that year.

[0001628280-17-008331:notes:92]
| • | In August 2016, the FASB issued ASU 2016-15, Statement of Cash Flows (Topic 230): Classification of Certain Cash Receipts and Cash Payments. The amendments in ASU 2016-15 will provide more guidance towards the classification of multiple different types of cash flows in order to reduce the diversity in reporting across entities. |

[0001628280-17-008331:notes:93]
| • | In November 2016, the FASB issued ASU 2016-18, Statement of Cash Flows (Topic 230): Restricted Cash. The amendments in ASU 2016-18 will explain the change during the period in the total of cash, cash equivalents, and amounts generally described as restricted cash or restricted cash equivalents. Therefore, amounts generally described as restricted cash and restricted cash equivalents should be included with cash and cash equivalents when reconciling the beginning-of-period and end-of-period total amounts shown on the statement of cash flows. |

[0001628280-17-008331:notes:94]
The Company is currently evaluating the impact, if any, the adoption of ASU 2016-15 and ASU 2016-18 may have on its consolidated financial statements.

[0001628280-17-008331:notes:95]
In October 2016, the FASB issued ASU 2016-16, Income Taxes (Topic 740): Intra-Entity Transfers of Assets Other Than Inventory.  The amendments in ASU 2016-16 will improve the accounting for the income tax consequences of intra-entity transfers of assets other than inventory. The ASU is effective for annual reporting periods beginning after December 15, 2017, including interim periods within that year.  The Company is currently evaluating the impact, if any, the adoption of ASU 2016-16 may have on its consolidated financial statements.

[0001628280-17-008331:notes:96]
In January 2017, the FASB issued ASU 2017-01, Business Combinations.  The amendments in ASU 2017-01 will clarify the definition of a business with the objective of adding guidance to assist entities with evaluating whether transactions should be accounted for as acquisitions (or disposals) of assets or businesses. The ASU is effective for annual reporting periods beginning after December 15, 2017, including interim periods within those periods.  The Company is currently evaluating the impact the adoption of ASU 2017-01 may have on its consolidated financial statements.

[0001628280-17-008331:notes:97]
In January 2017, the FASB issued ASU 2017-03, Accounting Changes and Error Corrections (Topic 250) and Investments - Equity Method and Joint Ventures.  The amendments in ASU 2017-03 provide additional detail surrounding disclosures required related to adoption of new pronouncements. The ASU is effective for the periods of each related pronouncement.  The Company is currently evaluating the impact the adoption of ASU 2017-03 may have on its consolidated financial statements.

[0001628280-17-008331:notes:98]
In February 2017, the FASB issued ASU 2017-05, Other Income - Gains and Losses from the Derecognition of Non-financial Assets (Subtopic 610-20).  The amendments in ASU 2017-05 clarify the scope of Subtopic 610-20, Other Income-Gains and Losses from the Derecognition of Non-financial Assets, and to add guidance for partial sales of non-financial assets. Subtopic 610-20, which was issued in May 2014 as a part of Accounting Standards Update No. 2014-09, Revenue from Contracts with Customers (Topic 606), provides guidance for recognizing gains and losses from the transfer of non-financial assets in contracts with non-customers.  The Company is currently evaluating the impact the adoption of ASU 2017-05 may have on its consolidated financial statements.

[0001628280-17-008331:notes:99]
In May 2017, the FASB issued ASU 2017-09, Compensation - Stock Compensation (Subtopic 718) Scope of Modification Accounting.  The amendments in ASU 2017-09 provide clarity and reduce both (1) diversity in practice and (2) cost and complexity when applying the guidance in Topic 718, Compensation—Stock Compensation, to a change to the terms or conditions of a share-based payment award.  The ASU is effective for annual reporting periods beginning after December 15, 2017, including interim periods within those periods. The Company is currently evaluating the impact the adoption of ASU 2017-09 may have on its consolidated financial statements.

[0001628280-17-008331:notes:100]
In July 2017, the FASB issued ASU 2017-11, Earnings per Share (Topic 260), Distinguishing Liabilities from Equity (Topic   480), and Derivatives and Hedging (Topic 815).  The amendments in ASU 2017-11 provide guidance for freestanding equity-linked financial instruments, such as warrants and conversion options in convertible debt or preferred stock, and should no longer be accounted for as a derivative liability at fair value as a result of the existence of a down round feature.  The ASU is effective for annual reporting periods beginning after December 15, 2018, including interim periods within those periods. The Company is currently evaluating the impact the adoption of ASU 2017-11 may have on its consolidated financial statements.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0001628280-17-008331:notes:101]
[same as prior period, unchanged from 0001628280-17-000901:notes:114]

[0001628280-17-008331:notes:102]
[same as prior period, unchanged from 0001628280-17-000901:notes:115]

[0001628280-17-008331:notes:103]
[same as prior period, unchanged from 0001628280-17-000901:notes:116]

[0001628280-17-008331:notes:104]
[same as prior period, unchanged from 0001628280-17-000901:notes:117]

[0001628280-17-008331:notes:105]
The Company has experienced recurring operating losses and as of June 30, 2017, the Company had an accumulated deficit of $970.8 million. In addition, the Company has experienced recurring negative operating cash flows.  At June 30, 2017, the Company had cash and cash equivalents of $37.5 million. Cash used in operations for the three months ended June 30, 2017 was $5.4 million.

[0001628280-17-008331:notes:106]
From April 1, 2011 through the date of this filing, the Company has reduced its global workforce substantially, including a restructuring action announced on April 4, 2017 which led to a $1.3 million restructuring charge in the three months ended June 30, 2017.  See Note 13 "Restructuring" for further discussion of this action.  The Company has taken actions to consolidate certain business operations to reduce facility costs.  As of June 30, 2017, the Company had a global workforce of 326 persons.  The Company plans to closely monitor its expenses and, if required, expects to further reduce operating costs and capital spending to enhance liquidity.

[0001628280-17-008331:notes:107]
Over the last several years, the Company has entered into several debt and equity financing arrangements in order to enhance liquidity.  Since April 1, 2012, the Company has generated aggregate cash flows from financing activities of $85.0 million.  Included in this amount are proceeds of approximately $17.0 million after deducting underwriting discounts and commissions and offering expenses payable by the Company, from the Company's equity offering completed on May 10, 2017, which includes the subsequent exercise by the underwriters of their option in full to purchase additional shares.  The Company terminated its At Market Issuance Sales Agreement ("ATM") with FBR Capital Markets & Co in conjunction with this equity offering.  See Note 12 “Stockholders Equity” for further discussion of these financing arrangements.

[0001628280-17-008331:notes:108]
In December 2015, the Company entered into a set of strategic agreements valued at approximately $210.0 million with Inox Wind Ltd. (“Inox”), which includes a multi-year supply contract pursuant to which the Company will supply electric control systems to Inox and a license agreement allowing Inox to manufacture a limited number of electrical control systems.  After Inox purchases the specified number of electrical control systems required under the terms of the supply contract, Inox agreed that the Company will continue as Inox’s preferred supplier and Inox will be required to purchase from the Company a majority of its electric control systems requirements for an additional three-year period.

[0001628280-17-008331:notes:109]
The Company believes based on the information presented above, and its quarterly management assessment, that it has sufficient liquidity to fund its operations and capital expenditures for the next twelve months following the issuance of the financial statements for the three months ended June 30, 2017. The Company’s liquidity is highly dependent on its ability to increase revenues, its ability to control its operating costs, and its ability to raise additional capital, if necessary. There can be no assurance that the Company will be able to continue to raise additional capital from other sources or execute on any other means of improving liquidity described above.


## us-gaap:PropertyPlantAndEquipmentDisclosureTextBlock

[0001628280-17-008331:notes:110]
Property, Plant and Equipment

[0001628280-17-008331:notes:111]
The cost and accumulated depreciation of property and equipment at June 30, 2017 and March 31, 2017 are as follows (in thousands):

[0001628280-17-008331:notes:112]
|  | June 30, 2017 |  | March 31, 2017 |
| Land | $ | 3,643 |  |  | $ | 3,643 |  |
| Construction in progress - equipment | 471 |  |  | 601 |  |
| Buildings | 34,549 |  |  | 34,549 |  |
| Equipment and software | 73,345 |  |  | 73,445 |  |
| Furniture and fixtures | 1,185 |  |  | 1,201 |  |
| Leasehold improvements | 1,907 |  |  | 2,442 |  |
| Property, plant and equipment, gross | 115,100 |  |  | 115,881 |  |
| Less accumulated depreciation | (75,818 | ) |  | (72,443 | ) |
| Property, plant and equipment, net | $ | 39,282 |  |  | $ | 43,438 |  |

[0001628280-17-008331:notes:113]
Depreciation expense was $4.2 million and $1.7 million for the three months ended June 30, 2017 and 2016, respectively.  Included in depreciation expense for the three months ended June 30, 2017 is $2.5 million of accelerated depreciation recorded to cost of goods sold related to revised estimates of the remaining useful lives of certain pieces of manufacturing equipment.


## us-gaap:ReconciliationOfAssetsFromSegmentToConsolidatedTextBlock

[0001628280-17-008331:notes:114]
Total assets for the two business segments as of June 30, 2017 and March 31, 2017 are as follows (in thousands):

[0001628280-17-008331:notes:115]
|  | June 30, 2017 |  | March 31, 2017 |
| Wind | $ | 17,162 |  |  | $ | 18,346 |  |
| Grid | 26,811 |  |  | 31,060 |  |
| Corporate assets | 60,630 |  |  | 50,838 |  |
| Total | $ | 104,603 |  |  | $ | 100,244 |  |


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001628280-17-008331:notes:116]
Restructuring

[0001628280-17-008331:notes:117]
The Company accounts for charges resulting from operational restructuring actions in accordance with ASC Topic 420, Exit or Disposal Cost Obligations (“ASC 420”) and ASC Topic 712, Compensation—Nonretirement Postemployment Benefits(“ASC 712”). In accounting for these obligations, the Company is required to make assumptions related to the amounts of employee severance, benefits, and related costs and the time period over which leased facilities will remain vacant, sublease terms, sublease rates and discount rates. Estimates and assumptions are based on the best information available at the time the obligation arises. These estimates are reviewed and revised as facts and circumstances dictate; changes in these estimates could have a material effect on the amount accrued on the consolidated balance sheet.

[0001628280-17-008331:notes:118]
On April 3, 2017, the Board of Directors approved a plan to reduce the Company’s global workforce by approximately 8%, effective April 4, 2017.  The purpose of the workforce reduction was to reduce operating expenses to better align with the Company’s current revenues. Included in the $1.3 million severance pay, charged to operations in the three months ended June 30, 2017, is $0.5 million of severance pay for one of the Company's former executive officers pursuant to the terms of a severance agreement dated as of June 30, 2017.  Under the terms of the severance agreement, the Company's former executive officer is entitled to 18 months of his base salary, which is expected to be paid by December 31, 2018. From and after January 1, 2018, the Company, at its discretion, may settle any remaining unpaid cash severance owed to its former executive officer through the issuance of a number of immediately vested shares of the Company’s common stock, determined by multiplying the remaining unpaid cash severance owed by 120%, and then dividing by the closing stock price per share of the Company's common stock as of the last business day prior to the issuance of the shares.

[0001628280-17-008331:notes:119]
All amounts related to these restructuring activities are expected to be paid by December 31, 2018.

[0001628280-17-008331:notes:120]
The following table presents restructuring charges and cash payments for the three months ended June 30, 2017 (in thousands):

[0001628280-17-008331:notes:121]
|  | Severance pay |
|  | and benefits |
| Accrued restructuring balance at April 1, 2017 | $ | — |  |
| Charges to operations | 1,339 |  |
| Cash payments | (423 | ) |
| Accrued restructuring balance at June 30, 2017 | $ | 916 |  |

[0001628280-17-008331:notes:122]
All restructuring charges discussed above are included within restructuring in the Company’s unaudited condensed consolidated statements of operations. The Company includes $0.7 million of accrued restructuring within accounts payable and accrued expenses and the remaining $0.2 million long term portion is included within other liabilities in the Company's unaudited condensed consolidated balance sheets.


## us-gaap:ScheduleOfRevenueByMajorCustomersByReportingSegmentsTableTextBlock

[0001628280-17-008331:notes:123]
The following table sets forth customers who represented 10% or more of the Company’s total revenues for the three months ended June 30, 2017 and 2016:

[0001628280-17-008331:notes:124]
|  | Three months ended June 30, |
|  | 2017 |  | 2016 |
| INOX Wind Limited | 22 | % |  | 27 | % |
| U.S. Navy | 35 | % |  | — | % |
| Reed & Reed Inc. | <10% |  |  | 17 | % |
| Essential Energy | <10% |  |  | 13 | % |
| XJ Group Corporation | — | % |  | 12 | % |


## us-gaap:ScheduleOfSegmentReportingInformationBySegmentTextBlock

[0001628280-17-008331:notes:125]
[same as prior period, unchanged from 0001628280-17-000901:notes:128]

[0001628280-17-008331:notes:126]
|  | Three months ended June 30, |
|  | 2017 |  | 2016 |
| Revenues: |  |  |  |
| Wind | $ | 2,278 |  |  | $ | 5,675 |  |
| Grid | 6,645 |  |  | 7,670 |  |
| Total | $ | 8,923 |  |  | $ | 13,345 |  |

[0001628280-17-008331:notes:127]
|  | Three months ended June 30, |
|  | 2017 |  | 2016 |
| Operating (loss) profit: |  |  |  |
| Wind | $ | (4,433 | ) |  | $ | (3,030 | ) |
| Grid | (8,167 | ) |  | (5,315 | ) |
| Unallocated corporate expenses | (2,093 | ) |  | (999 | ) |
| Total | $ | (14,693 | ) |  | $ | (9,344 | ) |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001628280-17-008331:notes:128]
[same as prior period, unchanged from 0001628280-17-000901:notes:131]

[0001628280-17-008331:notes:129]
[same as prior period, unchanged from 0001628280-17-000901:notes:132]

[0001628280-17-008331:notes:130]
[same as prior period, unchanged from 0001628280-17-000901:notes:133]

[0001628280-17-008331:notes:131]
[same as prior period, unchanged from 0001628280-17-000901:notes:134]

[0001628280-17-008331:notes:132]
[same as prior period, unchanged from 0001628280-17-000901:notes:135]

[0001628280-17-008331:notes:133]
Unallocated corporate expenses primarily consist of stock-based compensation expense of $0.8 million and $1.0 million in the three months ended June 30, 2017 and 2016, respectively.  Additionally a restructuring charge of $1.3 million is included in the three months ended June 30, 2017.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001628280-17-008331:notes:134]
[same as prior period, unchanged from 0001628280-17-000901:notes:137]

[0001628280-17-008331:notes:135]
Equity Offerings

[0001628280-17-008331:notes:136]
On May 5, 2017, the Company entered into an underwriting agreement with Oppenheimer & Co. Inc., as representative of several underwriters named therein, relating to the issuance and sale (the "Offering") of 4.0 million shares of the Company's common stock at a public offering price of $4.00 per share. The net proceeds to the Company from the Offering were approximately $14.7 million, after deducting underwriting discounts and commissions and offering expenses payable by the Company. The Offering closed on May 10, 2017. In addition, the Company granted the underwriters a 30-day option (the “Option”) to purchase up to an additional 600,000 shares of common stock at the public offering price.  On May 24, 2017, the underwriters notified the Company that they had exercised in full, their Option.  The net proceeds to the Company from the Option were approximately $2.3 million, after deducting underwriting discounts and commissions and offering expenses payable by the Company.   The total net proceeds to the Company from the Offering and the Option were approximately $17.0 million, after deducting underwriting discounts and commissions and offering expenses payable by the Company. The Option closed on May 26, 2017.

[0001628280-17-008331:notes:137]
ATM Arrangement

[0001628280-17-008331:notes:138]
On January 27, 2017, the Company entered into an At Market Issuance Sales Agreement ("ATM"), pursuant to which, the Company could, at its discretion, sell up to $10.0 million of the Company’s common stock through its sales agent, FBR Capital Markets & Co. ("FBR"). Sales of common stock made under the ATM were made pursuant to the prospectus supplement dated January 27, 2017, which supplements the prospectus dated October 1, 2014, included in the shelf registration statement that AMSC filed with the SEC on September 19, 2014.

[0001628280-17-008331:notes:139]
During the year ended March 31, 2017, the Company received net proceeds of $2.5 million, from sales of approximately 379,693 shares of its common stock at an average sales price of approximately $6.79 per share under the ATM.  No sales of the Company's common stock were made under the ATM after March 31, 2017.  On May 4, 2017, the Company provided to FBR a notice of termination of the ATM.


## us-gaap:SubsequentEventsTextBlock

[0001628280-17-008331:notes:140]
Subsequent Events

[0001628280-17-008331:notes:141]
The Company has performed an evaluation of subsequent events through the time of filing this Quarterly Report on Form 10-Q with the SEC, and has determined that there are no such events to report.
