# AMSC notes — 0001437749-26-018542


## cyd:CybersecurityRiskManagementProcessesForAssessingIdentifyingAndManagingThreatsTextBlock

[0001437749-26-018542:notes:1]
| Item 1C. | CYBERSECURITY |

[0001437749-26-018542:notes:2]
Overview

[0001437749-26-018542:notes:3]
Our IT Systems and Confidential Information  may be subject to cybersecurity threats. Our business, like others within the energy technologies industry, is faced with growing cybersecurity threats as we increasingly rely on digital technologies across our business, some of which are managed by third-party service providers on whom we rely to help us collect, host or process information.

[0001437749-26-018542:notes:4]
We recognize the significance of these threats, sometimes referred to as hacking, cybersecurity fraud, and cyberattacks, and maintain processes and procedures designed to protect our IT Systems and Confidential Information from unauthorized access. However, there can be no assurance that a cyber-attack would timely be detected or thwarted. To date, we are not aware of any material cybersecurity incidents that have materially affected or are reasonably likely to materially affect us, and we have not incurred significant operating expenses related to cybersecurity incidents. For more information on risks related to cybersecurity, please see the section titled “Risk Factors” included under Item 1A of this Annual Report on Form 10-K.

[0001437749-26-018542:notes:5]
Risk Management and Strategy

[0001437749-26-018542:notes:6]
Our cybersecurity risk management program includes operational, technical and physical controls designed to protect against and respond timely to cybersecurity threats. To address evolving cybersecurity risks and corresponding regulations, our policies and procedures are benchmarked to industry, regulatory and cybersecurity frameworks (including the National Institute of Standards and Technology). This does not imply that we meet any particular technical standards, specifications, or requirements, only that we  may use industry, regulatory, and cybersecurity frameworks as a guide to help us identify, assess, and manage cybersecurity risks relevant to our business.

[0001437749-26-018542:notes:7]
Our cybersecurity risk management program is integrated into our overall risk management program, and shares common methodologies, reporting channels and governance processes that apply across the risk management program to other legal, compliance, strategic, operational, and financial risk areas.

[0001437749-26-018542:notes:8]
Management has engaged third-party vendors to assist in monitoring our cybersecurity risk management programs and identifying and responding to any incidents. Additionally, third-party vendors are routinely engaged to evaluate how effectively management as a whole manages cybersecurity risk. This includes annual testing of our incident response plan through tabletop exercises and simulations to ensure readiness as well as penetration testing and security assessments. We also utilize third-party cybersecurity vendors to assess our protections against identified vulnerabilities, and we have implemented a third-party risk management process for key service providers, based on our assessment of their criticality to our operations.

[0001437749-26-018542:notes:9]
We have developed cybersecurity training for employees concerning cybersecurity risk.  This training provides information on security awareness and phishing simulations.  All employees are required to attend periodic cybersecurity training. On a regular basis, our IT team shares news and articles related to cybersecurity awareness with all employees.

[0001437749-26-018542:notes:10]
Our cybersecurity risk assessment is performed annually and includes external and internal penetration testing performed by third party vendors to test for vulnerabilities in the Company’s environment.

[0001437749-26-018542:notes:11]
We have not identified risks from known cybersecurity threats, including as a result of any prior cybersecurity incidents, that have materially affected us, including our operations, business strategy, results of operations, or financial condition. We face risks from cybersecurity threats that, if realized, are reasonably likely to materially affect us, including our operations, business strategy, results of operations, or financial condition. See "Risk Factors – Our business and operations may be materially adversely impacted in the event of a failure or security breach of our or any critical third parties' IT Systems or Confidential Information."


## cyd:CybersecurityRiskBoardOfDirectorsOversightTextBlock

[0001437749-26-018542:notes:12]
Governance

[0001437749-26-018542:notes:13]
The Board of Directors has delegated the oversight of risks from cybersecurity threats to the Audit Committee, which has delegated authority to the Chief Financial Officer to oversee the Company’s day-to-day cybersecurity risk management, including prevention, detection and responding to cybersecurity incidents.

[0001437749-26-018542:notes:14]
The Audit Committee is updated at least annually by the CFO on the status of cybersecurity matters. Contemporaneous reporting is provided where deemed necessary to the Audit Committee and to the full Board of Directors on significant cyber events including response, legal obligations, and outreach and notification to regulators and third parties.

[0001437749-26-018542:notes:15]
The Director, Global Information Technology and Financial Systems (the “IT Director”), works closely with our Director, IT Operations, Security and Compliance, who serves as our Chief Information Security Officer (the "CISO") and leads an internal team that works directly with our third-party vendors to manage our cybersecurity risk management program and activities. The internal team monitors our information systems for cybersecurity threats, reviews cybersecurity incidents, analyzes emerging threats, and develops and implements risk mitigation strategies. The CISO has over 25 years of progressive experience in information technology in both publicly traded and private companies. Under our CFO’s authority, the IT Director periodically reports on the cybersecurity program to our executive leadership team, including by providing the team with updates on cybersecurity threats and incidents, the status of ongoing projects and initiatives, performance metrics, and additional cybersecurity topics. On an annual basis, both the IT Director and the CISO review the results of the current state of cybersecurity risk management, including the results of our cybersecurity risk assessment and any action plan to address any identified vulnerabilities.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0001437749-26-018542:notes:16]
1. Nature of the Business and Operations and Liquidity

[0001437749-26-018542:notes:17]
Nature of the Business and Operations

[0001437749-26-018542:notes:18]
American Superconductor Corporation (together with its subsidiaries, “AMSC®” or the “Company”) was founded on  April 9, 1987. The Company is a leading provider of power control solutions that harmonize an increasingly complex energy system and enable customers to scale their operations without added complexity or size. The Company’s system level products leverage its proprietary “smart materials” and “smart software and controls” to provide enhanced resiliency and improved performance of megawatt-scale power flow.

[0001437749-26-018542:notes:19]
These consolidated financial statements of the Company have been prepared on a going concern basis in accordance with United States generally accepted accounting principles (“GAAP”) and the Securities and Exchange Commission’s (“SEC”) instructions to Form 10-K. Certain prior period amounts were reclassified to conform to the presentation in the current period. The going concern basis of presentation assumes that the Company will continue operations and will be able to realize its assets and discharge its liabilities and commitments in the normal course of business. All significant intercompany accounts and transactions are eliminated in consolidation. Investments in entities in which we do not have a controlling interest are accounted for under the equity method of accounting.

[0001437749-26-018542:notes:20]
Liquidity

[0001437749-26-018542:notes:21]
The Company’s primary sources of liquidity are internally generated cash provided by operating activities, our cash and cash equivalents on hand, along with access to capital markets. The Company believes that these sources of liquidity are sufficient to meet both its short-term and reasonably foreseeable long-term requirements and obligations. At  March 31, 2026, the Company had cash and cash equivalents of $140.7 million. Cash provided by operations for the year ended  March 31, 2026 was $23.1 million.

[0001437749-26-018542:notes:22]
On  December 5, 2025 (the "Comtrafo Acquisition Date"), the Company entered into a Stock Exchange Agreement (the "Stock Exchange Agreement") with the selling stockholders named therein (the "Stockholders"). Pursuant to the terms of the Stock Exchange Agreement, Mardin Participações Ltda., an entity incorporated in Brazil (“AMSC Brazil”) and the Company's wholly-owned subsidiary, directly or indirectly, purchased all of the issued and outstanding shares of Comtrafo Indústria de Transformadores Elétricos S.A. ("Comtrafo") (collectively, the "Comtrafo Acquisition") for (a) (i) 300 million Brazilian Real in cash; and (b) 2,417,142 restricted shares of our common stock, $0.01 par value per share (the "AMSC Shares") that were paid and issued, respectively, at closing. In addition, pursuant to certain additional real property agreements, AMSC Brazil through Comtrafo purchased certain real estate assets and transportation assets of Comtrafo for 155.6 million Brazilian Real and 13.4 million Brazilian Real, respectively, in cash. Additionally, AMSC Brazil has agreed to pay the Stockholders up to an additional 382.5 million Brazilian Real in cash (the "Earnout") upon the achievement of specified earnings before interest, taxes, depreciation, and amortization ("EBITDA") objectives during the three years following the closing. On  May 15, 2026, pursuant to the terms of the Stock Exchange Agreement, Comtrafo purchased a certain real estate asset from the selling stockholders that Comtrafo was leasing and using for administrative and manufacturing operations for 37.2 million Brazilian Real in cash. Comtrafo is a Brazil-based manufacturer of large power and distribution transformers primarily for utility customers and also for industrial customers.

[0001437749-26-018542:notes:23]
In  June 2025, we completed an offering of 4,743,750 shares of our common stock at a public offering price of $28.00 per share under our Registration Statement on Form S-3. We received aggregate net proceeds of approximately $124.6 million after deducting underwriting discounts and commissions and offering expenses.

[0001437749-26-018542:notes:24]
On  August 1, 2024 (the "Acquisition Date"), the Company entered into a Stock Purchase Agreement (the “Stock Purchase Agreement”) with the selling stockholders named therein. Pursuant to the terms of the Stock Purchase Agreement and concurrently with entering into such agreement, the Company acquired all of the issued and outstanding shares of Megatran Industries, Inc. ("Megatran") (the "Acquisition"), for aggregate consideration in an amount equal to $61.4 million (the “Purchase Price”), which consideration amount was subject to various adjustments set forth in the Stock Purchase Agreement (including those described below) and consisted of: (a) (i) $25.0 million, minus (ii) the Indebtedness (as defined in the Stock Purchase Agreement) outstanding as of immediately prior to the closing, minus (iii) Company Expenses (as defined in the Stock Purchase Agreement) (collectively, the “Cash Purchase Price”); (b) a number of restricted shares (rounded up or down to the nearest whole share, as applicable) (the “Company Shares”) of the Company’s common stock, $.01 par value per share equal to the quotient obtained by dividing (x) $31.4 million (the “Share Purchase Price”) by (y) the closing price per share of common stock on the Nasdaq Global Select Market on the last trading day immediately preceding the Acquisition Date; and (c) an additional cash payment equal to $5.0 million, as adjusted pursuant to Sections 5.6(c), (d), and (f) of the Stock Purchase Agreement (the “Additional Cash Purchase Price”). Megatran is now a wholly-owned subsidiary of the Company and, together with its wholly-owned subsidiaries and affiliates, is operated and reported as a component of its Grid business segment. On the Acquisition Date, the Company paid to Megatran's selling stockholders $25.0 million in cash on hand, and 1,297,600 restricted shares of common stock. On  September 23, 2024, the Company paid $3.3 million to the selling stockholders, which was calculated based on the agreed upon formula set forth in the Stock Purchase Agreement. As of  March 31, 2025, there are no remaining obligations to the selling stockholders of Megatran. Throughout the financial statements and related footnotes, this is referred to as the "acquisition of NWL".

[0001437749-26-018542:notes:25]
In  January 2024, we filed a shelf registration statement on Form S-3 that will expire three years from the date on which it was declared effective,  March 15, 2027 (the “Form S-3”). The Form S-3 allows us to offer and sell from time-to-time up to $250 million of common stock, debt securities, warrants or units comprised of any combination of these securities. The Form S-3 is intended to provide us flexibility to conduct registered sales of our securities, subject to market conditions, in order to fund our future capital needs. The terms of any future offering under the Form S-3 will be established at the time of such offering and will be described in a prospectus supplement filed with the SEC prior to the completion of any such offering.

[0001437749-26-018542:notes:26]
In  August 2024, the Company filed an automatically-effective shelf registration statement on Form S-3 that will expire no later than  August 12, 2027 (the “Second Form S-3”). The Second Form S-3 allows the Company to offer and sell from time-to-time unspecified amounts of common stock, debt securities, warrants or units comprised of any combination of these securities and allows certain selling stockholders to offer and sell from time-to-time common stock. The Second Form S-3 assisted the Megatran selling stockholders in the resale of their common stock and registers Comtrafo selling stockholder's AMSC shares, and is intended to provide the Company flexibility to conduct registered sales of its securities, subject to market conditions, in order to fund its future capital needs. The terms of any future offering under the Second Form S-3 will be established at the time of such offering and will be described in a prospectus supplement filed with the SEC prior to the completion of any such offering.

[0001437749-26-018542:notes:27]
The Company believes that based on the information presented above and its annual management assessment, it has sufficient liquidity to fund its operations and capital expenditures for at least the next
    twelve months following the issuance of the consolidated financial statements for the year ended
     March 31, 2026. The impact of global sources of instability on the global financing markets
     may reduce the Company's ability to raise additional capital, if necessary, which could negatively impact the Company's liquidity.  There can be
    no assurance that the Company will be able to continue to raise additional capital, on favorable terms or at all, from other sources or execute on any other means of improving liquidity described above.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001437749-26-018542:notes:28]
2. Acquisition

[0001437749-26-018542:notes:29]
Acquisition of Comtrafo

[0001437749-26-018542:notes:30]
On  December 5, 2025, the Company entered into the Stock Exchange Agreement with the selling stockholders named therein. Pursuant to the terms of the Stock Exchange Agreement and concurrently with entering into such agreement, AMSC Brazil, the Company's wholly-owned subsidiary, directly or indirectly acquired all of the issued and outstanding shares of capital stock of Comtrafo. Additionally, the Company has agreed to pay the selling stockholders of the Comtrafo Acquisition an additional amount up to an additional 382.5 million Brazilian Real of cash upon the achievement of specified EBITDA objectives during the three years following the Comtrafo Acquisition Date. This contingent consideration is recorded as a liability based on a Monte Carlo simulation to determine fair value at the time of issuance. Comtrafo is a Brazil-based manufacturer of large power and distribution transformers primarily for utility customers and also for industrial customers. The acquisition will expand the Company's global footprint into Latin America.

[0001437749-26-018542:notes:31]
The Comtrafo Acquisition has been accounted for under the purchase method of accounting in accordance with ASC 805, Business Combinations. The Company allocated the purchase price on a preliminary basis using the information available as of  December 5, 2025 to the assets acquired and liabilities assumed at their estimated fair values as of the date of acquisition. Due to the timing of the completion of the acquisition, the purchase price and related allocation are preliminary and could be revised as a result of adjustments made to the purchase price, and revisions of provisional estimates of fair values of deferred taxes, contingent consideration and intangible asset balances. Changes to the purchase price allocation could be significant. The purchase price allocation will be finalized within the measurement period of up to one year from the acquisition. The excess of the purchase price paid by the Company over the estimated fair value of net assets acquired has been recorded as goodwill.

[0001437749-26-018542:notes:32]
The total purchase price of approximately $202.9 million includes the fair value of the Company's common stock issued at closing, contingent consideration and cash paid, as follows (in millions except share data and per share):

[0001437749-26-018542:notes:33]
| Cash payments |  | $ | 88.3 |  |
| Issuance of 2,417,142 shares of Company’s common stock |  |  | 79.8 |  |
| Contingent consideration |  |  | 34.8 |  |
| Total consideration |  | $ | 202.9 |  |

[0001437749-26-018542:notes:34]
At the Comtrafo Acquisition Date, in addition to the $88.3 million cash, the Company valued the Company's common stock at $33.01 per share, which was the opening price on that date. Comtrafo Acquisition costs of $1.2 million were included in selling, general, and administrative ("SG&A") for the fiscal year ended  March 31, 2026.

[0001437749-26-018542:notes:35]
During the quarter ended  March 31, 2026 the Company determined adjustments were required to the opening balance sheet to correct immaterial errors in the allocation and recording of the purchase price reflected in the table below. The debt was subsequently paid in the quarter ended  March 31, 2026 and the restricted cash balance was released in the quarter ended  March 31, 2026. The following table summarizes the allocation of the purchase price based on the estimated fair values of the assets acquired and liabilities assumed and related deferred income taxes in connection with the Comtrafo Acquisition as of the Comtrafo Acquisition Date as previously reported in the period ended  December 31, 2025 and after the adjustments for the immaterial errors recorded in the quarter ended  March 31, 2026 (in millions):

[0001437749-26-018542:notes:36]
|  |  | December 05, 2025 Allocation of Purchase Price as Initially Reported |  |  | Adjustments |  |  | December 05, 2025 Allocation of Purchase Price as Corrected |  |
| Cash and cash equivalents |  | $ | 16.2 |  |  | $ | (3.4 | ) |  | $ | 12.8 |  |
| Restricted cash |  |  | - |  |  |  | 3.4 |  |  | $ | 3.4 |  |
| Prepaid expenses and other current assets |  |  | 6.7 |  |  |  | (1.1 | ) |  | $ | 5.6 |  |
| Accounts receivable |  |  | 4.1 |  |  |  | 2.4 |  |  | $ | 6.5 |  |
| Inventory |  |  | 28.4 |  |  |  | 0.2 |  |  | $ | 28.6 |  |
| Property, plant and equipment |  |  | 50.3 |  |  |  | (0.4 | ) |  | $ | 49.9 |  |
| Deferred tax asset |  |  | 4.1 |  |  |  | - |  |  | $ | 4.1 |  |
| Accounts payable and accrued expenses |  |  | (10.2 | ) |  |  | 1.1 |  |  | $ | (9.1 | ) |
| Debt, current and long-term |  |  | (8.8 | ) |  |  | - |  |  | $ | (8.8 | ) |
| Deferred revenue |  |  | (19.8 | ) |  |  | (3.5 | ) |  | $ | (23.3 | ) |
| Net tangible assets/(liabilities) |  |  | 71.0 |  |  |  | (1.3 | ) |  | $ | 69.7 |  |
| Backlog |  |  | 1.8 |  |  |  | 0.8 |  |  | $ | 2.6 |  |
| Customer relationships |  |  | 7.7 |  |  |  | 0.2 |  |  | $ | 7.9 |  |
| Net identifiable intangible assets/(liabilities) |  |  | 9.5 |  |  |  | 1.0 |  |  | $ | 10.5 |  |
| Goodwill |  |  | 122.2 |  |  |  | 0.5 |  |  | $ | 122.7 |  |
| Total purchase consideration |  | $ | 202.7 |  |  | $ | 0.2 |  |  | $ | 202.9 |  |

[0001437749-26-018542:notes:37]
Based on further review by management, a measurement period adjustment of $0.4 million was recorded to increase accounts receivable and reduce deferred tax assets by $3.0 million with an offsetting increase to goodwill, increasing the total goodwill to $125.3 million.

[0001437749-26-018542:notes:38]
The fair value of the financial assets acquired includes receivables with a fair value of $6.9 million. The gross amount due is $10.5 million, of which $3.6 million is expected to be uncollectible. The Company adjusted the fair value for receivables that exceeded a year.

[0001437749-26-018542:notes:39]
Inventory includes a $1.5 million adjustment to step-up the inventory balance to fair value consistent with the purchase price allocation. The fair value was determined based on the estimated selling price of the inventory, less the remaining manufacturing and selling cost and a normal profit margin on those manufacturing and selling efforts. The inventory step-up adjustment increased cost of revenue $0.8 million in the fiscal year ended  March 31, 2026, as the inventory was sold.

[0001437749-26-018542:notes:40]
Backlog of $2.6 million was evaluated using the multi period excess earnings method under the income approach. The contracts do not provide for any guarantees to source all future requirements from the Company. The amortization method being utilized is economic consumption estimated over a sixteen-month period with the expense being allocated to cost of revenues.

[0001437749-26-018542:notes:41]
Customer relationships of $7.9 million relate to customers currently under contract and was based on a multi period excess earnings method under the income approach. The method of amortization being utilized is the economic consumption over 5 years with the expense being allocated to SG&A.

[0001437749-26-018542:notes:42]
Goodwill represents the value associated with the acquired workforce and expected synergies related to the business combination of the two companies. Goodwill resulting from the Comtrafo Acquisition was assigned to the Company's Grid segment. Goodwill recognized in the Comtrafo Acquisition is not deductible for tax purposes. The $1.1 million of deferred tax asset is primarily related to net operating losses and basis difference of inventory, offset by basis difference of intangibles and property, plant, and equipment.

[0001437749-26-018542:notes:43]
Acquisition of NWL

[0001437749-26-018542:notes:44]
On  August 1, 2024, the Company acquired all of the issued and outstanding shares of capital stock of Megatran. Megatran's wholly-owned subsidiary, NWL, Inc. ("NWL"), is a U.S.-based global provider of engineered power conversion solutions for demanding industrial and military applications.

[0001437749-26-018542:notes:45]
The Acquisition has been accounted for under the purchase method of accounting in accordance with ASC 805, Business Combinations. The Company allocated the purchase price to the assets acquired and liabilities assumed at their estimated fair values as of the Acquisition Date. The excess of the purchase price paid by the Company over the estimated fair value of net assets acquired has been recorded as goodwill.

[0001437749-26-018542:notes:46]
The total purchase price of approximately $61.4 million includes the fair value of shares of the Company’s common stock issued at closing, and cash paid, as follows (in millions except shares):

[0001437749-26-018542:notes:47]
| Cash payments |  | $ | 30.0 |  |
| Issuance of 1,297,600 shares of Company’s common stock |  |  | 31.4 |  |
| Total consideration |  | $ | 61.4 |  |

[0001437749-26-018542:notes:48]
At the Acquisition Date, in addition to the $30.0 million cash, the Company valued the Company’s common stock, using $24.16 per share, which was the closing price on the day prior to the day that the Company acquired Megatran. Acquisition costs of $1.1 million were included in SG&A for the fiscal year ended  March 31, 2025.

[0001437749-26-018542:notes:49]
The following table summarizes the allocation of the purchase price based on the estimated fair values of the assets acquired and liabilities assumed and related deferred income taxes in connection with the Acquisition as of the Acquisition Date and reflective of measurement period adjustments (in millions):

[0001437749-26-018542:notes:50]
| Cash and cash equivalents |  | $ | 0.4 |  |
| Equity-method investments |  |  | 1.2 |  |
| Prepaid expenses and other current assets |  |  | 1.7 |  |
| Accounts receivable |  |  | 16.1 |  |
| Inventory |  |  | 23.1 |  |
| Property, plant, and equipment |  |  | 28.4 |  |
| Accounts payable and accrued expenses |  |  | (5.6 | ) |
| Deferred revenue |  |  | (5.0 | ) |
| Deferred tax liability |  |  | (5.6 | ) |
| Net tangible assets/(liabilities) |  |  | 54.7 |  |
| Backlog |  |  | 0.7 |  |
| Customer relationships |  |  | 1.3 |  |
| Net identifiable intangible assets |  |  | 2.0 |  |
| Goodwill |  |  | 4.7 |  |
| Total purchase consideration |  | $ | 61.4 |  |

[0001437749-26-018542:notes:51]
The fair value of the financial assets acquired includes receivables with a fair value of $16.1 million. The gross amount due is $16.9 million, of which $0.8 million is expected to be uncollectible.

[0001437749-26-018542:notes:52]
Inventory includes a $0.7 million adjustment to step up the inventory balance to fair value consistent with the purchase price allocation. The fair value was determined based on the estimated selling price of the inventory, less the remaining manufacturing and selling cost and a normal profit margin on those manufacturing and selling efforts. The inventory step up adjustment increased cost of revenue $0.7 million for the fiscal year ended  March 31, 2025 as the inventory was sold.

[0001437749-26-018542:notes:53]
Backlog of $0.7 million was evaluated using the multi period excess earnings method under the income approach. The contracts with customers do not provide for any guarantees to source all future requirements from the Company. The amortization method being utilized is economic consumption estimated over an eight-month period with the expense being allocated to cost of revenues.

[0001437749-26-018542:notes:54]
Customer relationships of $1.3 million relates to customers currently under contract and was determined based on a multi period excess earnings method under the income approach. The method of amortization being utilized is straight line over 10 years, as the results were not materially different from the economic consumption method, with the expense being allocated to SG&A.

[0001437749-26-018542:notes:55]
Goodwill represents the value associated with the acquired workforce and expected synergies related to the business combination of the two companies. Goodwill resulting from the Acquisition was assigned to the Company’s Grid business segment. Goodwill recognized in the Acquisition is not deductible for tax purposes. The Company has finalized its purchase price allocation for the NWL Acquisition, and there were no changes to net assets and goodwill recorded by the Company as of  August 1, 2025.

[0001437749-26-018542:notes:56]
Pro forma Operating Results (Unaudited)

[0001437749-26-018542:notes:57]
The pro forma consolidated statement of operations for the fiscal years ended  March 31, 2026 and 2025 presented as if the acquisitions of Comtrafo and NWL had occurred on  April 1, 2024, is unaudited and is as follows:

[0001437749-26-018542:notes:58]
|  |  | Fiscal year ended March 31, |  |
|  |  | 2026 |  |  | 2025 |  |
| Net Revenue |  | $ | 333,821 |  |  | $ | 300,661 |  |
| Operating income (loss) |  |  | 20,109 |  |  |  | 6,459 |  |
| Net income |  | $ | 139,474 |  |  | $ | 14,611 |  |
| Net income per common share |  |  |  |  |  |  |  |  |
| Basic |  | $ | 3.13 |  |  | $ | 0.37 |  |
| Diluted |  | $ | 3.06 |  |  | $ | 0.36 |  |
| Shares – basic |  |  | 44,594 |  |  |  | 39,844 |  |
| Shares – diluted |  |  | 45,551 |  |  |  | 40,572 |  |

[0001437749-26-018542:notes:59]
The pro forma amounts include the historical operating results of the Company, NWL, and Comtrafo with appropriate adjustments that give effect to acquisition related costs, income taxes, intangible amortization resulting from the Acquisitions and certain conforming accounting policies of the Company. The pro forma amounts are not necessarily indicative of the operating results that would have occurred if the Acquisitions and related transactions had been completed at the beginning of the applicable periods presented. In addition, the pro forma amounts are not necessarily indicative of operating results in future periods.

[0001437749-26-018542:notes:60]
In the consolidated results for the fiscal year ended  March 31, 2026, Comtrafo and AMSC Brazil's operations are included in the Company's consolidated results from the Acquisition Date of  December 5, 2025. Comtrafo and AMSC Brazil contributed $21.9 million of revenue and $3.2 million in net loss for the Company for the fiscal year ended  March 31, 2026. Amortization expense of $1.7 million is included for the fiscal year ended  March 31, 2026, as a result of the Comtrafo acquired intangible assets. In addition, $0.8 million for the step-up basis assigned to acquired inventory was charged to cost of revenues for the fiscal year ended  March 31, 2026. AMSC Brazil includes a $4.2 million loss for the change in fair value on the contingent consideration in the fiscal year ended  March 31, 2026.


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001437749-26-018542:notes:61]
3. Summary of Significant Accounting Policies

[0001437749-26-018542:notes:62]
Basis of Consolidation

[0001437749-26-018542:notes:63]
The consolidated financial statements include the accounts of the Company and its wholly-owned subsidiaries. All significant intercompany balances and transactions are eliminated.

[0001437749-26-018542:notes:64]
Use of Estimates

[0001437749-26-018542:notes:65]
The preparation of financial statements in conformity with GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities, disclosure of contingent assets and liabilities at the date of the financial statements and the reported amounts of revenue and expenses during the reporting period. The Company bases its estimates on historical experience and various other factors believed to be reasonable under the circumstances, the results of which form the basis for making judgments about the carrying value of assets and liabilities that are not readily apparent from other sources. On an ongoing basis, the Company evaluates its estimates, including those considered significant related to revenue recognition, goodwill, business combinations, tax reserves, and deferred tax assets. Provisions for depreciation are based on their estimated useful lives using the straight-line method. Some of these estimates can be subjective and complex and, consequently, actual results  may differ from these estimates under different assumptions or conditions. While for any given estimate or assumption made by the Company’s management there  may be other estimates or assumptions that are reasonable, the Company believes that, given the current facts and circumstances, it is unlikely that applying any such other reasonable estimate or assumption would materially impact the financial statements.

[0001437749-26-018542:notes:66]
Cash Equivalents

[0001437749-26-018542:notes:67]
Cash equivalents consist of highly liquid instruments with maturities of three months or less that are regarded as high quality, low risk investments and are measured using such inputs as quoted prices, and are classified within Level 1 of the valuation hierarchy. Cash equivalents consist principally of certificates of deposits and money market accounts, and are classified within Level 2 of the valuation hierarchy.

[0001437749-26-018542:notes:68]
Accounts Receivable

[0001437749-26-018542:notes:69]
Accounts receivable consist of amounts owed by commercial companies and government agencies. Accounts receivable are stated net of allowances for credit losses. The Company’s accounts receivable relate principally to a limited number of customers. As of  March 31, 2026, Irving Shipbuilding accounted for approximately 10% of the Company's accounts receivable balance, with no other customers accounting for greater than 10% of the balance. As of  March 31, 2025, Innomotics, LLC accounted for approximately 22% of the Company's accounts receivable balance, with no other customers accounting for greater than 10% of the balance. Changes in the financial condition or operations of the Company’s customers  may result in delayed payments or non-payments which would adversely impact its cash flows from operating activities and/or its results of operations. As such, the Company  may require collateral, advanced payment or other security based upon the customer history and/or creditworthiness. In determining the allowance for credit losses, the Company evaluates the collectability of accounts receivable based primarily on the probability of recoverability based on historical collection and write-off experience, the age of past due receivables, specific customer circumstances, and current economic trends. The Company has not recorded a material allowance for credit losses as of each of the fiscal years ended  March 31, 2026 and 2025. If the financial condition of the Company’s customers were to deteriorate, resulting in an impairment of their ability to make payment, additional allowances  may be required. Failure to accurately estimate the losses for credit losses and ensure that payments are received on a timely basis could have a material adverse effect on the Company’s business, financial condition, results of operations, and cash flows.

[0001437749-26-018542:notes:70]
Inventory

[0001437749-26-018542:notes:71]
Inventories include material, direct labor and related manufacturing overhead, and are stated at the lower of cost, determined on a first-in, first-out basis, or net realizable value determined as the estimated selling prices in the ordinary course of business, less reasonably predictable costs of completion, disposal and transportation for certain inventories and the moving average weighted costing method for others. The Company records inventory when it takes delivery and title to the product according to the terms of each supply contract.

[0001437749-26-018542:notes:72]
Program costs  may be deferred and recorded as inventory on contracts on which costs are incurred in excess of approved contractual amounts and/or funding, if future recovery of the costs is deemed probable.

[0001437749-26-018542:notes:73]
At each balance sheet date, the Company evaluates its ending inventories for excess quantities and obsolescence. Inventories that management considers excess or obsolete are reserved. Management considers forecasted demand in relation to the inventory on hand, competitiveness of product offerings, market conditions and product life cycles when determining excess and obsolescence and net realizable value adjustments. Once inventory is written down and a new cost basis is established, it is not written back up if demand increases.

[0001437749-26-018542:notes:74]
For the fiscal years ended  March 31, 2026 and 2025, the Company recorded inventory reserves of approximately $3.5 million and $1.5 million, respectively, based on evaluating its ending inventory on hand for excess quantities and obsolescence.

[0001437749-26-018542:notes:75]
Leases

[0001437749-26-018542:notes:76]
The Company determines whether a contract is or contains a lease at inception of a contract. The Company defines a lease as a contract, or part of a contract, that conveys the right to control the use of identified property or equipment (an identified asset) for a period of time in exchange for consideration. Control over the use of the identified asset means that the Company has both the right to obtain substantially all of the economic benefits from the use of the asset and the right to direct the use of the asset.

[0001437749-26-018542:notes:77]
Leases include all agreements in which the Company obtains control of a physical asset.  Leases are captured on the balance sheet as both a right of use asset and associated lease liability and are valued based on the commencement of the Company's control of the asset, after being discounted by its incremental borrowing rate. The Company's lease portfolio is made up primarily of real estate leases for its various offices, but also include items such as vehicles, IT equipment and other miscellaneous tools and equipment needed for manufacturing. The Company's incremental borrowing rate was determined through an analysis to identify what rates it could obtain if the Company were to secure external financing for similar transactions, and includes considerations of both the market and its current credit ratings. An analysis is performed annually, or upon execution of any individually material agreement, to ensure that the rates being applied to newly acquired leases are still accurate.

[0001437749-26-018542:notes:78]
All of the Company's leases are classified as operating leases, and therefore the expense is captured in operating loss from operations each period.

[0001437749-26-018542:notes:79]
The Company has elected to exclude all leases of less than twelve months from the balance sheet presentation. The Company has also elected a policy in which the Company will not segregate lease components from non-lease components, so in the event the Company executes an agreement which includes a non-lease component its asset and liability recorded to the balance sheet will include the value of that non-lease component as well.  This policy will be applied to all classifications of leases.

[0001437749-26-018542:notes:80]
Property, Plant and Equipment

[0001437749-26-018542:notes:81]
Property, plant and equipment are carried at cost less accumulated depreciation and amortization. The Company accounts for depreciation and amortization using the straight-line method to allocate the cost of property, plant and equipment over their estimated useful lives as follows:

[0001437749-26-018542:notes:82]
| Asset Classification |  | Estimated Useful Life in Years |  |
| Building |  | 40 |  |
| Equipment and software |  | 3-10 |  |
| Furniture and fixtures |  | 3-5 |  |
| Leasehold improvements |  | Shorter of the estimated useful life or the remaining lease term |  |

[0001437749-26-018542:notes:83]
Expenditures for maintenance and repairs are expensed as incurred. Upon retirement or other disposition of assets, the costs and related accumulated depreciation are eliminated from the accounts and the resulting gain or loss is reflected in operating expenses.

[0001437749-26-018542:notes:84]
Valuation of Long-Lived Assets

[0001437749-26-018542:notes:85]
The Company reviews the carrying value of its long-lived assets or asset group that is held and used, including intangible assets subject to amortization, for impairment whenever events and circumstances indicate that the carrying value of the assets  may not be recoverable. Under the held and used approach, the asset or asset group to be tested for impairment should represent the lowest level for which identifiable cash flows are largely independent of the cash flows of other groups of assets and liabilities. The Company evaluates its long-lived assets whenever events or circumstances suggest that the carrying amount of an asset or group of assets  may not be recoverable from the estimated undiscounted future cash flows.

[0001437749-26-018542:notes:86]
There were no impairment indicators identified during the fiscal years ended  March 31, 2026 and 2025 or 2024.

[0001437749-26-018542:notes:87]
Goodwill

[0001437749-26-018542:notes:88]
Goodwill represents the excess of cost over net assets of acquired businesses that are consolidated. The Company performs its annual assessment of goodwill on  February 28th of each fiscal year and whenever events or changes in circumstances or a triggering event indicate that the carrying amount  may not be recoverable. Determining whether a triggering event has occurred often involves significant judgment from management. An entity is permitted to first assess qualitatively whether it is necessary to perform a goodwill impairment test. The quantitative impairment test is required only if the entity concludes that it is more likely than not that a reporting unit’s fair value is less than its carrying amount. The Company determines the fair value of a reporting unit, using a methodology which combines an income approach, using a discounted cash flow method, with a market approach. In evaluating whether it is more likely than not that the fair value of a reporting unit is less than its carrying amount, an entity should consider the totality of all relevant events or circumstances that affect the fair value or carrying amount of a reporting unit.  If the carrying value of a reporting unit exceeds the reporting unit’s fair value, then an impairment charge is recognized reducing the goodwill by the excess of the carrying amount over the fair value, not to exceed the total amount of the goodwill allocated to that reporting unit. See Note 5, "Goodwill" for further information and discussion.

[0001437749-26-018542:notes:89]
The Company performed its annual assessment of goodwill on  February 28, 2026, using both qualitative and quantitative analyses and determined that there was no impairment to goodwill.

[0001437749-26-018542:notes:90]
Revenue Recognition

[0001437749-26-018542:notes:91]
Revenue contracts are defined as an arrangement that creates enforceable rights and obligations of both parties where collection of the contract price is deemed probable. The Company records revenue based on a five-step model which includes confirmation of contract existence, identifying the performance obligations, determining the transaction price, allocating the contract transaction price to the performance obligations, and recognizing the revenue when (or as) control of goods or services is transferred to the customer. The transfer of control  can occur at the time of delivery, installation or post-installation where applicable.

[0001437749-26-018542:notes:92]
The Company's product segment line includes certain contracts which do not meet the requirements of an exchange transaction and therefore do not fall within the scope of Accounting Standards Codification ("ASC") 606.

[0001437749-26-018542:notes:93]
For certain arrangements, such as contracts to perform research and development, prototype development contracts and certain customized product sales, the Company records revenues using the over-time method, measured by the relationship of costs incurred to total estimated contract costs. Over-time revenue recognition accounting is predominantly used on certain turnkey power systems installations for electric utilities and long-term prototype development contracts with the U.S. government. The Company follows this method when any of the three following criteria are met: when the customer receives the benefits as they are performed, control transfers to the customer as the work is performed, or there is no alternative use to the Company and there is an enforceable right to payment through the life of the contract. However, the ability to reliably estimate total costs at completion is challenging, especially on long-term prototype development contracts, and could result in future changes in contract estimates. For contracts where reasonably dependable estimates of the revenues and costs cannot be made, the Company follows the point in time method. In addition, some contracts contain an element of variable consideration, including liquidated damages and/or penalties, which requires payment to the customer in the event that delivery timelines or milestones are not met. The Company estimates the total consideration payable by the customer when the contracts contain variable consideration provisions, based on the most likely amount anticipated to be recognized for transferring the promised goods or services. As a result, the Company  may constrain revenue to the extent that a significant reversal in the amount of cumulative revenue recognized will not occur until the uncertainty associated with the variable consideration is subsequently resolved.

[0001437749-26-018542:notes:94]
The Company enters into sales arrangements that  may provide for multiple performance obligations to a customer. Sales of certain products  may include extended warranty and support or service packages, and at times include performance bonds. As these contracts progress, the Company continually assesses the probability of a payout from the performance bond. Should the Company determine that such a payout is likely, the Company would record a liability. The Company would reduce revenue to the extent a liability is recorded. In addition, the Company enters into licensing arrangements that include training services.

[0001437749-26-018542:notes:95]
Performance obligations are separated into more than one unit of accounting when (1) the delivered element(s) have value to the customer on a stand-alone basis, and (2) the Company's promise to transfer the goods or services to the customer is separately identifiable from other promises in the contract.  In general, revenues are separated between the different product shipments which have stand-alone value, and the various services to be provided. Revenue for product shipments is generally recognized at a point in time where control of the product is transferred to the customer, while revenues for the services are generally recognized over the period of performance. The Company identifies all goods and/or services that are to be delivered separately under a sales arrangement and allocates the transaction price to each distinct performance obligation using the respective standalone selling price ("SSP") which is determined primarily using the cost plus expected margin approach for products and a relief from royalty method for licenses.  Revenue allocated to each performance obligation is recognized when, or as, the performance obligation is satisfied. The Company reviews SSP and the related margins at least annually. The Company has elected to recognize revenue based on the as invoiced practical expedient if there is a right to consideration from a customer in an amount that corresponds directly with the value of the Company's performance.

[0001437749-26-018542:notes:96]
The Company’s license agreements provide either for the payment of contractually determined paid-up front license fees or milestone based payments in consideration for the grant of rights to manufacture and/or sell products using its patented technologies or know-how. Some of these agreements provide for the release of the licensee from past and future intellectual property infringement claims. When the Company can determine that it has no further obligations other than the grant of the license and that the Company has fully transferred the technology know-how, the Company recognizes the revenue under a point in time model. In other license arrangements, the Company  may also agree to provide training services to transfer the technology know-how. In these arrangements, the Company has determined that the licenses have no standalone value to the customer and are not separable from training services as the Company can only fully transfer the technology know-how through the training component. Accordingly, the Company accounts for these arrangements as a single unit of accounting, and recognizes revenue over the period of its performance using the over-time method. Costs for these arrangements are expensed as incurred.

[0001437749-26-018542:notes:97]
Existing customers are subject to ongoing credit evaluations based on payment history and other factors. If it is determined that collectability of any portion of the contract value is not probable, an analysis of variable consideration will be performed using either the most likely amount or expected value method to determine the amount of revenue that must be constrained until the scenario causing the variability has been resolved. For contractual arrangements that involve variable consideration, the Company recognizes revenue for these amounts upon reaching the constraining event successfully. The Company does not generally provide for extended payment terms or provide its customers with a right of return.

[0001437749-26-018542:notes:98]
Infrequently, the Company receives requests from customers to hold product being purchased from us for a valid business purpose. The Company recognizes revenues for such arrangements provided the transaction meets, at a minimum, the following criteria: a valid business purpose for the arrangement exists; risk of ownership of the purchased product has been transferred to the buyer; there is a fixed delivery date that is reasonable and consistent with the buyer’s business purpose; the product is ready for shipment; there are no continuing performance obligation in regards to the purchased product and these products have been segregated from the Company's inventories and cannot be used to fill other orders received. During the fiscal year ended  March 31, 2026, revenues included $7.9 million from such held transactions. During the fiscal year ended  March 31, 2025 and 2024 there were no such held transactions.

[0001437749-26-018542:notes:99]
The Company has elected to record taxes collected from customers on a net basis and does not include tax amounts in revenue or costs of revenue.

[0001437749-26-018542:notes:100]
The Company’s contract assets and liabilities primarily relate to the timing differences between cash received from a customer in connection with contractual rights to invoicing and the timing of revenue recognition following completion of performance obligations. The Company's accounts receivable balance is made up entirely of customer contract related balances.

[0001437749-26-018542:notes:101]
Business Acquisitions

[0001437749-26-018542:notes:102]
The Company accounts for acquisitions using the purchase method of accounting in accordance with ASC 805, Business Combinations. The purchase price for each acquisition is allocated to the assets acquired and liabilities assumed based on their estimated fair values at the date of acquisition. Intangible assets, if identified, are also recorded at fair value.  The excess purchase price over the estimated fair value of the net assets acquired is recorded as goodwill.

[0001437749-26-018542:notes:103]
Determining the fair value of certain assets and liabilities assumed is judgmental in nature and often involves the use of significant estimates and assumptions as well as the use of specialists as needed.

[0001437749-26-018542:notes:104]
The consideration for its acquisitions  may include future payments that are contingent upon the occurrence of a particular event. The Company records a contingent consideration obligation for such contingent consideration payments at fair value on the acquisition date. The Company estimates the fair value of contingent consideration obligations through valuation models that incorporate probability adjusted assumptions related to the achievement of the milestones and the likelihood of making related payments, refer to Note 13 for further information regarding valuation methodology and assumptions. Each period the Company revalues the contingent consideration obligations associated with the acquisition to fair value and records changes in the fair value within the operating expenses in its consolidated statements of operations. Increases or decreases in the fair value of the contingent consideration obligations can result from changes in assumed revenue risk premium and volatility, as well as changes in the stock price and assumed probability with respect to the attainment of certain financial and operational metrics, among others. Significant judgment is employed in determining these assumptions as of the acquisition date and for each subsequent period. Accordingly, future business and economic conditions, as well as changes in any of the assumptions described above, can materially impact the fair value of contingent consideration recorded at each reporting period.

[0001437749-26-018542:notes:105]
Product Warranty

[0001437749-26-018542:notes:106]
Warranty obligations are incurred in connection with the sale of the Company’s products. The Company provides assurance-type warranties on all product sales for a term of typically one to three years, and extended service-type warranties at the customers’ option for an additional term ranging up to four additional years. The Company accrues for the estimated warranty costs for assurance warranties at the time of sale based on historical warranty experience plus any known or expected changes in warranty exposure. For all extended service-type warranties, the Company recognizes the revenue ratably over time during the effective period of the service.  The costs incurred to provide for these warranty obligations are estimated and recorded as an accrued liability at the time of sale. Future warranty costs are estimated based on historical performance rates and related costs to repair given products. The accounting estimate related to product warranty involves judgment in determining future estimated warranty costs. Should actual performance rates or repair costs differ from estimates, revision to the estimated warranty liability would be required.

[0001437749-26-018542:notes:107]
Research and Development Costs

[0001437749-26-018542:notes:108]
Research and development costs are expensed as incurred.

[0001437749-26-018542:notes:109]
Income Taxes

[0001437749-26-018542:notes:110]
The Company’s provision (benefit) for income taxes is comprised of a current and a deferred portion. The current income (benefit) tax provision is calculated as the estimated taxes payable or refundable on tax returns for the current fiscal year. The deferred income tax provision is calculated for the estimated future tax effects attributable to temporary differences and carry-forwards using expected tax rates in effect in the years during which the differences are expected to reverse.

[0001437749-26-018542:notes:111]
Deferred income taxes are recognized for the tax consequences in future fiscal years of differences between the tax bases of assets and liabilities and their financial reporting amounts at each fiscal year end based on enacted tax laws and statutory tax rates applicable to the periods in which the differences are expected to affect taxable income. Valuation allowances are established when necessary to reduce net deferred tax assets to the amount expected to be realized. As of  March 31, 2026, the company recorded a $118.4 million non-cash income tax benefit related to the release of a substantial portion of its valuation allowance against deferred income tax assets. This was based on the Company's evaluation of the positive evidence, including cumulative net income position over the three year period ended  March 31, 2026, revenue growth, current profitability, expectations regarding future forecasted income, and negative evidence, including uncertainty in economic and political environments from industry competition and dependence on government contracts. The Company has provided a valuation allowance against certain of its U.S. deferred income tax assets and a full valuation allowance on its Poland deferred income tax assets since the Company believes that it is more likely than not that these deferred tax assets are not currently realizable due to uncertainty around profitability to fully utilize these deferred tax assets in the future.

[0001437749-26-018542:notes:112]
Accounting for income taxes requires a two-step approach to recognizing and measuring uncertain tax positions. The first step is to evaluate the tax position for recognition by determining if, based on the technical merits, it is more likely than not that the position will be sustained upon audit, including resolution of related appeals or litigation processes, if any. The second step is to measure the tax benefit as the largest amount that is more than 50% likely of being realized upon ultimate settlement. The Company reevaluates these uncertain tax positions on a quarterly basis. This evaluation is based on factors including, but not limited to, changes in facts or circumstances, changes in tax law, effectively settled issues under audit and new audit activity. Any changes in these factors could result in the recognition of a tax benefit or an additional charge to the tax provision. The Company includes interest and penalties related to gross unrecognized tax benefits within the provision for income taxes. See Note 14, “Income Taxes,” for further information regarding its income tax assumptions and expenses.

[0001437749-26-018542:notes:113]
Stock-Based Compensation

[0001437749-26-018542:notes:114]
The Company accounts for stock-based payment transactions using a fair value-based method and recognizes the related expense in the results of operations.

[0001437749-26-018542:notes:115]
Stock-based compensation is estimated at the grant date based on the fair value of the award and is recognized as expense over the requisite service period of the award. The fair value of restricted stock awards is determined by reference to the fair market value of the Company’s common stock on the date of grant. The Company uses the Black-Scholes option pricing model to estimate the fair value of option awards with service and performance conditions. For awards with service conditions only, the Company recognizes compensation cost on a straight-line basis over the requisite service/vesting period. For awards with performance conditions, estimates of compensation cost are made based on the probable outcome of the performance conditions. The cumulative effect of changes in the probability outcomes are recorded in the period in which the changes occur.

[0001437749-26-018542:notes:116]
Determining the appropriate fair value model and related assumptions requires judgment, including estimating stock price volatilities of the Company’s common stock and expected terms. The expected volatility rates are estimated based on historical and implied volatilities of the Company’s common stock. The expected term represents the average time that the options that vest are expected to be outstanding based on the vesting provisions and the Company’s historical exercise, cancellation and expiration patterns.

[0001437749-26-018542:notes:117]
The Company estimates pre-vesting forfeitures when recognizing compensation expense based on historical and forward-looking factors. Changes in estimated forfeiture rates and differences between estimated forfeiture rates and actual experience  may result in significant, unanticipated increases or decreases in stock-based compensation expense from period to period. The termination of employment of certain employees who hold large numbers of stock-based awards  may also have a significant, unanticipated impact on forfeiture experience and, therefore, on stock-based compensation expense. The Company will update these assumptions on at least an annual basis and on an interim basis if significant changes to the assumptions are warranted.

[0001437749-26-018542:notes:118]
The Company accounts for share-based payments made to non-employees in the same manner as other share-based payments for employees, with the measurement being based on the fair value at the grant date. The non-employee share based payments will be included within the Company's stock compensation currently reported.

[0001437749-26-018542:notes:119]
Equity Method Investments

[0001437749-26-018542:notes:120]
The Company treats the equity investment in the consolidated financial statements under the equity method. Equity method investments are equity securities in entities we do not control but over which we have the ability to exercise significant influence. These investments are accounted for under the equity method of accounting in accordance with ASC 323, Investments — Equity Method and Joint Ventures. Equity method investments are measured at cost minus impairment, if any, plus or minus the Company’s share of an investee’s income or loss, less distributions received.

[0001437749-26-018542:notes:121]
Computation of Net Income (Loss) per Common Share

[0001437749-26-018542:notes:122]
Basic net income (loss) per share (“EPS”) is computed by dividing net income (loss) by the weighted-average number of common shares outstanding for the period. Diluted EPS is computed in periods of net income, by dividing the net loss by the weighted-average number of common shares and dilutive common equivalent shares outstanding during the period, calculated using the treasury stock method. Common equivalent shares include the effect of restricted stock, exercise of stock options and warrants and contingently issuable shares. For the fiscal years ended  March 31, 2026, common equivalent shares of 428,111 were not included in the calculation of diluted EPS as they were considered antidilutive. Of these, 427,380 were shares of performance-based restricted stock where the contingency was not met, and 731 were awards that were considered anti-dilutive. For the fiscal year ended  March 31, 2025, common equivalent shares of 468,815 were not included in the calculation of diluted EPS as they were considered antidilutive. Of these, 468,652 were shares of performance-based restricted stock where the contingency was not met, and 163 relate to shares associated with the derivative liability for which the contingency had not yet been met. For the fiscal year ended  March 31, 2024, common equivalent shares of 809,949 were not included in the calculation of diluted EPS as they were considered antidilutive. Of these, 509,949 were shares of performance-based restricted stock where the contingency was not met, and 300,000 relate to share associated with the derivative liability for which the contingency has not yet been met. The following table reconciles the numerators and denominators of the EPS calculation for the fiscal years ended  March 31, 2026, 2025, and 2024 (in thousands except per share amounts):

[0001437749-26-018542:notes:123]
|  |  | Fiscal year ended March 31, |  |
|  |  | 2026 |  |  | 2025 |  |  | 2024 |  |
| Numerator: |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income (loss) |  | $ | 133,809 |  |  | $ | 6,033 |  |  | $ | (11,111 | ) |
| Denominator: |  |  |  |  |  |  |  |  |  |  |  |  |
| Weighted-average shares of common stock outstanding |  |  | 44,877 |  |  |  | 38,457 |  |  |  | 31,277 |  |
| Weighted-average shares subject to repurchase |  |  | (1,932 | ) |  |  | (1,467 | ) |  |  | (1,452 | ) |
| Shares used in per-share calculation ― basic |  |  | 42,945 |  |  |  | 36,990 |  |  |  | 29,825 |  |
| Shares used in per-share calculation ― diluted |  |  | 43,902 |  |  |  | 37,718 |  |  |  | 29,825 |  |
| Net income (loss) per share ― basic |  | $ | 3.12 |  |  | $ | 0.16 |  |  | $ | (0.37 | ) |
| Net income (loss) per share ― diluted |  | $ | 3.05 |  |  | $ | 0.16 |  |  | $ | (0.37 | ) |

[0001437749-26-018542:notes:124]
Foreign Currency Translation

[0001437749-26-018542:notes:125]
The functional currency of all the Company’s foreign subsidiaries is the U.S. dollar, except for AMSC Austria (euro), AMSC Brazil and Comtrafo (Real), for which the local currencies are the functional currency. The assets and liabilities of AMSC Austria, AMSC Brazil and Comtrafo are translated into U.S. dollars at the exchange rate in effect at the balance sheet date and income and expense items are translated at average rates for the period. Cumulative translation adjustments are excluded from net loss and shown as a separate component of stockholders’ equity. Net foreign currency gains and losses are included in other expense, net on the consolidated statements of operations and were net losses of $1.1 million, $0.7 million, and $0.7 million for the fiscal years ended  March 31, 2026, 2025, and 2024, respectively. The Company has no restrictions on the foreign exchange activities of its foreign subsidiaries, including the payment of dividends and other distributions.

[0001437749-26-018542:notes:126]
Risks and Uncertainties

[0001437749-26-018542:notes:127]
The preparation of financial statements in conformity with GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities and disclosures of contingent assets and liabilities at the date of the financial statements and the reported amounts of revenues and expenses during the reporting period. Actual results could materially differ from those estimates and would impact future results of operations and cash flows.

[0001437749-26-018542:notes:128]
The Company invests its available cash in high credit, quality financial instruments and invests primarily in investment-grade marketable securities, including, but not limited to, government obligations and money market funds.

[0001437749-26-018542:notes:129]
Several of the Company’s government contracts are being funded incrementally, and as such, are subject to the future authorization, appropriation, and availability of government funding. The Company has a history of successfully obtaining financing under incrementally-funded contracts with the U.S. government and it expects to continue to obtain additional contract modifications in the year ending  March 31, 2027 and beyond as incremental funding is authorized and appropriated by the government.

[0001437749-26-018542:notes:130]
Contingencies

[0001437749-26-018542:notes:131]
From time to time, the Company  may be involved in legal and administrative proceedings and claims of various types. The Company records a liability in its consolidated financial statements for these matters when a loss is known or considered probable and the amount can be reasonably estimated. Management reviews these estimates in each accounting period as additional information is known and adjusts the loss provision when appropriate. If the loss is not probable or cannot be reasonably estimated, a liability is not recorded in the consolidated financial statements. If, with respect to a matter, it is not both probable to result in liability and the amount of loss cannot be reasonably estimated, an estimate of possible loss or range of loss is disclosed unless such an estimate cannot be made. The Company does not recognize gain contingencies until they are realized. Legal costs incurred in connection with loss contingencies are expensed as incurred. See Note 18, “Commitments and Contingencies,” for further information.

[0001437749-26-018542:notes:132]
Disclosure of Fair Value of Financial Instruments

[0001437749-26-018542:notes:133]
The Company’s financial instruments consist principally of cash and cash equivalents, restricted cash, accounts receivable, accounts payable, accrued expenses, and contingent consideration. The carrying amounts of cash and cash equivalents, restricted cash, accounts receivable, short-term debt, accounts payable, and accrued expenses due to their short nature approximate fair value at  March 31, 2026 and 2025. The estimated fair values have been determined through information obtained from market sources and management estimates. Changes in fair value are recorded to other income (expense), net. The fair value for the contingent consideration is estimated using a Monte Carlo simulation and subject to revaluation at each balance sheet date. The Company classifies the estimates used to fair value these instruments as Level 3 inputs. See Note 6, “Fair Value Measurements” for a full discussion on fair value measurements.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001437749-26-018542:notes:134]
4. Revenue Recognition

[0001437749-26-018542:notes:135]
The Company’s revenues in its Grid segment are derived primarily through enabling the transmission and distribution of power, providing planning services that allow it to identify power grid needs and risks, and developing ship protection systems for the U.S. Navy. The Company’s revenues in its Wind segment are derived primarily through supplying advanced power electronics and control systems, licensing its highly engineered wind turbine designs, and providing extensive customer support services to wind turbine manufacturers. The Company records revenue based on a five-step model in accordance with ASC 606. For its customer contracts, the Company identifies the performance obligations, determines the transaction price, allocates the contract transaction price to the performance obligations, and recognizes the revenue when (or as) control of goods or services is transferred to the customer. For the fiscal year ended  March 31, 2026, 89% of revenue was recognized at the point in time when control transferred to the customer, with the remainder being recognized over time. For the fiscal year ended  March 31, 2025, 88% of revenue was recognized at the point in time when control transferred to the customer, with the remainder being recognized over time. For the fiscal year ended  March 31, 2024, 80% of revenue was recognized at the point in time when control transferred to the customer, with the remainder being recognized over time.

[0001437749-26-018542:notes:136]
In the Company's product sales, each contract with a customer summarizes each product sold to a customer, which typically represents distinct performance obligations. A contract's transaction price is allocated to each distinct performance obligation using the respective standalone selling price which is determined primarily using the cost plus expected margin approach and recognized as revenue when, or as, the performance obligation is satisfied. The majority of the Company’s product sales transfer control to the customer in line with the contracted delivery terms and revenue is recorded at the point in time when title and risk transfer to the customer, which is primarily upon delivery, as the Company has determined that this is the point in time that control transfers to the customer. For the fiscal year ended  March 31, 2026, 93% of revenue was recognized related to the sales of product, with the remainder being recognized based on the performance of services. For the fiscal year ended  March 31, 2025, 94% of revenue was recognized related to the sales of product, with the remainder being recognized based on the performance of services. For the fiscal year ended  March 31, 2024, 92% of revenue was recognized related to the sales of product, with the remainder being recognized on the performance of services.

[0001437749-26-018542:notes:137]
Included in the Company's performance of services, there are several different types of transactions and each begins with a contract with a customer that summarizes each product sold to a customer, which typically represents distinct performance obligations. Included in the business segment line there are technology development transactions that are primarily for activities that have no alternative use and for which a profit can be expected throughout the life of the contract. In these cases, the revenue is recognized over time, but in the instances where the profit cannot be assured throughout the entire contract then the revenue is recognized at a point in time. Each contract's transaction price is allocated to each distinct performance obligation using the respective standalone selling price which is determined primarily using the cost plus expected margin approach. The ongoing service transactions are for service contracts that provide benefit to the customer simultaneously as the Company performs its obligations, and therefore this revenue is recognized ratably over time throughout the effective period of these contracts. The transaction prices on these contracts are allocated based on an adjusted market approach which is re-assessed annually for reasonableness. The field service transactions include contracts for delivery of goods and completion of services made at the customer's requests, which are not deemed satisfied until the work has been completed and/or the requested goods have been delivered, so all of this revenue is recognized at the point in time when the control changes, and at allocated prices based on the adjusted market approach driven by standard price lists. The royalty transactions are related to certain contract terms on transactions in the Company's equipment and systems product line based on activity as specified in the contracts. The transaction prices of these agreements are calculated based on an adjusted market approach as specified in the contract. The Company reports royalty revenue for usage-based royalties when the sales have occurred. In circumstances when collectability is not assured and a contract does not exist under ASC 606, revenue is deferred until a non-refundable payment has been received for substantially all the amount that is due and there are no further remaining performance obligations.

[0001437749-26-018542:notes:138]
The Company's service contracts can include a purchase order from a customer for specific goods in which each item is a distinct performance obligation satisfied at a point in time at which control of the goods is transferred to the customer. This transfer occurs based on the contracted delivery terms or when the requested service work has been completed. The transaction price for these goods is allocated based on the adjusted market approach considering similar transactions under similar circumstances. Service contracts are also derived from ongoing maintenance contracts and extended service-type warranty contracts. In these transactions, the Company is contracted to provide an ongoing service over a specified period of time. As the customer is consuming the benefits as the service is being provided the revenue is recognized over time ratably.

[0001437749-26-018542:notes:139]
The Company’s policy is not to accept volume discounts, product returns, or rebates and allowances within its contracts. In the event a contract was approved with any of these terms, it would be evaluated for variable consideration, estimated and recorded as a reduction of revenue in the same period the related product revenue was recorded.

[0001437749-26-018542:notes:140]
The Company provides assurance-type warranties on all product sales for a term of typically one to three years, and extended service-type warranties are available for purchase at the customer's option for an additional term ranging up to four additional years. The Company accrues for the estimated warranty costs for assurance warranties at the time of sale based on historical warranty experience plus any known or expected changes in warranty exposure. For all extended service-type warranties, the Company recognizes the revenue ratably over time during the effective period of the services.

[0001437749-26-018542:notes:141]
The Company records revenue net of sales tax, value added tax, excise tax and other taxes collected concurrent with revenue-producing activities. The Company has elected to recognize the cost for freight and shipping when control over the products sold passes to customers and revenue is recognized. The Company has elected to recognize incremental costs of obtaining a contract as expense when incurred except in contracts where the amortization period would exceed twelve months. As of  March 31, 2026 and 2025, the Company's capitalized incremental contract costs were not material. The Company has elected not to adjust the promised amount of consideration for the effects of a significant financing component if the period of financing is twelve months or less. The Company has elected to recognize revenue based on the as invoiced practical expedient if there is a right to consideration from a customer in an amount that corresponds directly with the value of the Company's performance.

[0001437749-26-018542:notes:142]
The Company’s contracts with customers do not typically include extended payment terms and  may include milestone billing over the life of the contract. Payment terms vary by contract type and type of customer and generally range from 30 to 60 days from delivery.

[0001437749-26-018542:notes:143]
Following the Comtrafo Acquisition, the Company re-assessed the disaggregated revenue disclosure and determined that segment revenue by product line is no longer a meaningful disclosure. Driven by the change in the overall business landscape following the Comtrafo Acquisition, the Company has determined an increased breakout of segment revenue by region provides more meaningful insight to our overall financial position.

[0001437749-26-018542:notes:144]
The following tables disaggregate the Company’s revenue by shipment destination (in thousands):

[0001437749-26-018542:notes:145]
|  |  |  | Year Ended |  |
|  | Reportable |  | March 31, |  |
|  | Segment |  | 2026 |  |  | 2025 |  |  | 2024 |  |
| Region: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| North America | Grid |  | $ | 174,103 |  |  | $ | 169,104 |  |  | $ | 104,423 |  |
| South America | Grid |  |  | 23,819 |  |  |  | 782 |  |  |  | 2,613 |  |
| Asia Pacific | Grid |  |  | 41,050 |  |  |  | 7,392 |  |  |  | 9,768 |  |
| EMEA | Grid |  |  | 12,345 |  |  |  | 9,892 |  |  |  | 5,261 |  |
| Total | Grid |  | $ | 251,317 |  |  | $ | 187,170 |  |  | $ | 122,065 |  |
| Region: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| North America | Wind |  | $ | 16 |  |  | $ | 2 |  |  | $ | 102 |  |
| South America | Wind |  |  | — |  |  |  | — |  |  |  | — |  |
| Asia Pacific | Wind |  |  | 47,668 |  |  |  | 35,608 |  |  |  | 23,404 |  |
| EMEA | Wind |  |  | 154 |  |  |  | 38 |  |  |  | 68 |  |
| Total |  | $ | 47,838 |  |  | $ | 35,648 |  |  | $ | 23,574 |  |

[0001437749-26-018542:notes:146]
As of  March 31, 2026 and  March 31, 2025, the Company’s contract assets and liabilities primarily relate to the timing differences between cash received from a customer in connection with contractual rights to invoicing and the timing of revenue recognition following completion of performance obligations. The Company's accounts receivable balance is made up entirely of customer contract related balances. Changes in the Company’s contract assets, which are included in “Unbilled accounts receivable” and “Deferred program costs” (see Note 7, “Accounts Receivable” and Note 8, “Inventory” for a reconciliation to the consolidated balance sheets) and "Contract liabilities", which are included in the current portion and long term portion of “Deferred revenue” in the Company’s consolidated balance sheets, are as follows (in thousands):

[0001437749-26-018542:notes:147]
|  |  | Unbilled AR |  |  | Deferred Program Costs |  |  | Contract Liabilities |  |
| Beginning balance as of March 31, 2025 |  | $ | 6,376 |  |  | $ | 5,756 |  |  | $ | 76,133 |  |
| Increases for balances acquired |  |  | — |  |  |  | — |  |  |  | 19,783 |  |
| Increases for costs incurred to fulfill performance obligations |  |  | — |  |  |  | 38,803 |  |  |  | — |  |
| Increase (decrease) due to customer billings |  |  | (22,332 | ) |  |  | — |  |  |  | 114,307 |  |
| Decrease due to cost recognition on completed performance obligations |  |  | — |  |  |  | (37,022 | ) |  |  | — |  |
| Increase (decrease) due to recognition of revenue based on transfer of control of performance obligations |  |  | 30,868 |  |  |  | — |  |  |  | (117,899 | ) |
| Other changes and foreign currency exchange impact |  |  | (37 | ) |  |  | 42 |  |  |  | 1,007 |  |
| Ending balance as of March 31, 2026 |  | $ | 14,875 |  |  | $ | 7,579 |  |  | $ | 93,331 |  |

[0001437749-26-018542:notes:148]
|  |  | Unbilled AR |  |  | Deferred Program Costs |  |  | Contract Liabilities |  |
| Beginning balance as of March 31, 2024 |  | $ | 6,150 |  |  | $ | 2,523 |  |  | $ | 57,829 |  |
| Increases for balances acquired |  |  | — |  |  |  | — |  |  |  | 5,049 |  |
| Increases for costs incurred to fulfill performance obligations |  |  | — |  |  |  | 16,363 |  |  |  | — |  |
| Increase (decrease) due to customer billings |  |  | (8,754 | ) |  |  | — |  |  |  | 120,533 |  |
| Decrease due to cost recognition on completed performance obligations |  |  | — |  |  |  | (13,131 | ) |  |  | — |  |
| Increase (decrease) due to recognition of revenue based on transfer of control of performance obligations |  |  | 8,981 |  |  |  | — |  |  |  | (107,211 | ) |
| Other changes and foreign currency exchange impact |  |  | (1 | ) |  |  | 1 |  |  |  | (67 | ) |
| Ending balance as of March 31, 2025 |  | $ | 6,376 |  |  | $ | 5,756 |  |  | $ | 76,133 |  |

[0001437749-26-018542:notes:149]
The Company’s remaining performance obligations represent the unrecognized revenue value of the Company’s contractual commitments. The Company’s performance obligations  may vary significantly each reporting period based on the timing of major new contractual commitments. As of  March 31, 2026, the Company had outstanding performance obligations on existing contracts under ASC 606 to be recognized in the next twelve months of approximately $282.4 million. There are also approximately $97.1 million of outstanding performance obligations to be recognized over a period of thirteen to sixty months. The remaining performance obligations are subject to customer actions and therefore the timing of revenue recognition cannot be reasonably estimated.

[0001437749-26-018542:notes:150]
The following table sets forth customers who represented 10% or more of the Company’s total revenues for the years ended  March 31, 2026, 2025 and 2024:

[0001437749-26-018542:notes:151]
|  |  |  | Year Ended |  |
|  | Reportable |  | March 31, |  |
|  | Segment |  | 2026 |  |  | 2025 |  |  | 2024 |  |
| Inox Wind Limited | Wind |  |  | 15 | % |  |  | 14 | % |  |  | 13 | % |
| Fuji Bridex Pte Ltd | Grid |  |  | 10 | % |  | <10% |  |  | <10% |  |


## us-gaap:GoodwillDisclosureTextBlock

[0001437749-26-018542:notes:152]
5. Goodwill

[0001437749-26-018542:notes:153]
The guidance under ASC 805-30, Business Combinations, provides for the recognition of goodwill on the acquisition date measured as the excess of the aggregate consideration transferred over the net of the acquisition date amounts of net assets acquired and liabilities assumed. The Company's goodwill balance relates to the Comtrafo acquisition in fiscal 2025, the NWL acquisition in fiscal 2024, the Neeltran acquisition in fiscal 2021, the NEPSI acquisition in fiscal 2020, and Infinia Technology Corporation acquisition in fiscal 2017 and is reported in the Grid business segment.

[0001437749-26-018542:notes:154]
Goodwill represents the difference between the purchase price and the fair value of the identifiable tangible and intangible net assets when accounted for using the purchase method of accounting. Goodwill is not amortized but reviewed for impairment. Goodwill is reviewed annually on  February 28th and whenever events or changes in circumstances indicate that the carrying value of the goodwill might not be recoverable. Goodwill increased by $125.3 million during the fiscal year ended  March 31, 2026, related to the Comtrafo acquisition. Changes in the Company's goodwill are as follows (in thousands):

[0001437749-26-018542:notes:155]
|  |  | Goodwill |  |
| March 31, 2025 |  | $ | 48,164 |  |
| Balance acquired – Comtrafo |  |  | 122,620 |  |
| Measurement period adjustment |  |  | 2,674 |  |
| FX impact |  |  | 1,918 |  |
| March 31, 2026 |  | $ | 175,376 |  |

[0001437749-26-018542:notes:156]
The Company performed its annual assessment of goodwill on  February 28, 2026 and determined that there was no impairment to goodwill.


## us-gaap:FairValueDisclosuresTextBlock

[0001437749-26-018542:notes:157]
6. Fair Value Measurements

[0001437749-26-018542:notes:158]
A valuation hierarchy for disclosure of the inputs to valuation used to measure fair value has been established. This hierarchy prioritizes the inputs into three broad levels as follows:

[0001437749-26-018542:notes:159]
| Level 1 | - | Inputs are unadjusted quoted prices in active markets for identical assets or liabilities that the Company has the ability to access at the measurement date. |
| Level 2 | - | Inputs include quoted prices for similar assets and liabilities in active markets, quoted prices for identical or similar assets or liabilities in markets that are not active, inputs other than quoted prices that are observable for the asset or liability, and inputs that are derived principally from or corroborated by observable market data by correlation or other means (market corroborated inputs). |
| Level 3 | - | Unobservable inputs that reflect the Company’s assumptions that market participants would use in pricing the asset or liability. The Company develops these inputs based on the best information available, including its own data. |

[0001437749-26-018542:notes:160]
The Company provides a gross presentation of activity within Level 3 measurement roll-forward and details of transfers in and out of Level 1 and 2 measurements.  A change in the hierarchy of an investment from its current level is reflected in the period during which the pricing methodology of such investment changes.  Disclosure of the transfer of securities from Level 1 to Level 2 or Level 3 is made in the event that the related security is significant to total cash and investments.  The Company did not have any transfers of assets and liabilities from Level 1, Level 2 or Level 3 of the fair value measurement hierarchy during the year ended  March 31, 2026.

[0001437749-26-018542:notes:161]
A financial asset’s or liability’s classification within the hierarchy is determined based on the lowest level input that is significant to the fair value measurement.

[0001437749-26-018542:notes:162]
Valuation Techniques

[0001437749-26-018542:notes:163]
Cash equivalents consist of highly liquid instruments with maturities of three months or less that are regarded as high quality, low risk investments and are measured using such inputs as quoted prices, and are classified within Level 1 of the valuation hierarchy. Cash equivalents consist principally of money market accounts.

[0001437749-26-018542:notes:164]
Short-term Cash Instruments

[0001437749-26-018542:notes:165]
Short-term cash instruments consist of highly liquid instruments with maturities of three months or less that are regarded as high quality, low risk investments and are measured using such inputs as quoted prices in markets that are not active, and are classified within Level 2 of the valuation hierarchy. Short-term cash instruments consist principally of certificates of deposits.

[0001437749-26-018542:notes:166]
Contingent Consideration

[0001437749-26-018542:notes:167]
Contingent consideration relates to the earnout payment set forth in the Stock Exchange Agreement governing the acquisition of Comtrafo that provides the selling stockholders  may receive an additional sum of cash upon the achievement of certain specified earnings before interest, taxes, depreciation, and amortization ("EBITDA") objectives during the three years following the Comtrafo Acquisition Date. See Note 13, "Contingent Consideration" for further discussion. The Company relied on a Monte Carlo method to determine the fair value of the contingent consideration on the closing of the acquisition of Comtrafo and continues to revalue the fair value of the contingent consideration using the same method at each subsequent balance sheet date until the contingencies are resolved and the cash to be paid is determined, with the change in fair value recorded in the current period operating loss. For the period ended  March 31, 2026, the change in fair value was $4.2 million. Contingent consideration is classified within Level 3 of the valuation hierarchy.

[0001437749-26-018542:notes:168]
The following table provides the assets and liabilities carried at fair value on a recurring basis, measured as of  March 31, 2026 and 2025 (in thousands):

[0001437749-26-018542:notes:169]
|  |  | Total Carrying Value |  |  | Quoted Prices in Active Markets (Level 1) |  |  | Significant Other Observable Inputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |
| March 31, 2026: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash equivalents |  | $ | 101,525 |  |  | $ | 101,525 |  |  | $ | — |  |  | $ | — |  |
| Short-term cash instruments |  | $ | 1,278 |  |  | $ | — |  |  | $ | 1,278 |  |  | $ | — |  |
| Current liabilities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Contingent Consideration |  | $ | 12,808 |  |  | $ | — |  |  | $ | — |  |  | $ | 12,808 |  |
| Long-term liabilities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Contingent Consideration |  | $ | 26,721 |  |  | $ | — |  |  | $ | — |  |  | $ | 26,721 |  |

[0001437749-26-018542:notes:170]
|  |  | Total Carrying Value |  |  | Quoted Prices in Active Markets (Level 1) |  |  | Significant Other Observable Inputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |
| March 31, 2025: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash equivalents |  | $ | 51,230 |  |  | $ | 51,230 |  |  | $ | — |  |  | $ | — |  |
| Short-term cash instruments |  | $ | 1,404 |  |  | $ | — |  |  | $ | 1,404 |  |  | $ | — |  |

[0001437749-26-018542:notes:171]
The table below reflects the activity for the Company’s contingent consideration liability measured at fair value on a recurring basis (in thousands):

[0001437749-26-018542:notes:172]
|  |  | Comtrafo Acquisition Contingent Consideration |  |
| Balance at March 31, 2025 |  | $ | — |  |
| Issuance of contingent consideration |  |  | 34,815 |  |
| Change in fair value |  |  | 4,171 |  |
| FX Impact |  |  | 543 |  |
| Balance at March 31, 2026 |  | $ | 39,529 |  |


## amsc:AccountsReceivableTextBlock

[0001437749-26-018542:notes:173]
7. Accounts Receivable

[0001437749-26-018542:notes:174]
Accounts receivable at  March 31, 2026 and  March 31, 2025 consisted of the following (in thousands):

[0001437749-26-018542:notes:175]
|  |  | March 31, 2026 |  |  | March 31, 2025 |  |
| Accounts receivable (billed) |  | $ | 54,506 |  |  | $ | 39,810 |  |
| Accounts receivable (unbilled) |  |  | 14,875 |  |  |  | 6,376 |  |
| Accounts receivable |  | $ | 69,381 |  |  | $ | 46,186 |  |


## us-gaap:InventoryDisclosureTextBlock

[0001437749-26-018542:notes:176]
8. Inventory

[0001437749-26-018542:notes:177]
Inventory, net of reserves, at  March 31, 2026 and  March 31, 2025 consisted of the following (in thousands):

[0001437749-26-018542:notes:178]
|  |  | March 31, 2026 |  |  | March 31, 2025 |  |
| Raw materials |  | $ | 54,247 |  |  | $ | 35,892 |  |
| Work-in-process |  |  | 26,873 |  |  |  | 19,633 |  |
| Finished goods |  |  | 15,049 |  |  |  | 9,888 |  |
| Deferred program costs |  |  | 7,579 |  |  |  | 5,756 |  |
| Inventory |  | $ | 103,748 |  |  | $ | 71,169 |  |

[0001437749-26-018542:notes:179]
The Company recorded inventory write-downs of $3.5 million, $1.5 million, and $2.0 million for the fiscal years ended  March 31, 2026, 2025, and 2024 respectively. These write-downs were based on the Company's evaluation on its inventory on hand for excess quantities and obsolescence.

[0001437749-26-018542:notes:180]
Deferred program costs as of  March 31, 2026 and  March 31, 2025 primarily represent costs incurred on programs where the Company needs to complete performance obligations before the related revenue and costs will be recognized.


## us-gaap:PropertyPlantAndEquipmentDisclosureTextBlock

[0001437749-26-018542:notes:181]
9. Property, Plant and Equipment

[0001437749-26-018542:notes:182]
The cost and accumulated depreciation of property, plant and equipment at  March 31, 2026 and 2025 are as follows (in thousands):

[0001437749-26-018542:notes:183]
|  |  | March 31, 2026 |  |  | March 31, 2025 |  |
| Land |  | $ | 37,770 |  |  | $ | 22,650 |  |
| Construction in progress - equipment |  |  | 1,482 |  |  |  | 1,371 |  |
| Buildings |  |  | 30,989 |  |  |  | 7,528 |  |
| Equipment and software |  |  | 60,030 |  |  |  | 47,774 |  |
| Furniture and fixtures |  |  | 1,940 |  |  |  | 1,672 |  |
| Leasehold improvements |  |  | 8,276 |  |  |  | 7,969 |  |
| Property, plant and equipment, gross |  |  | 140,487 |  |  |  | 88,964 |  |
| Less accumulated depreciation |  |  | (50,712 | ) |  |  | (50,392 | ) |
| Property, plant and equipment, net |  | $ | 89,775 |  |  | $ | 38,572 |  |

[0001437749-26-018542:notes:184]
Depreciation expense was $4.4 million, $3.1 million, and $2.3 million for the fiscal years ended  March 31, 2026, 2025, and 2024 respectively. The increase in land, building, and equipment and software relates to the property added as part of the Comtrafo Acquisition.


## us-gaap:IntangibleAssetsDisclosureTextBlock

[0001437749-26-018542:notes:185]
10. Intangible Assets

[0001437749-26-018542:notes:186]
Intangible assets at  March 31, 2026 and 2025 consisted of the following (in thousands):

[0001437749-26-018542:notes:187]
|  |  | 2026 |  |  | 2025 |  |  |  |  |
|  |  | Gross Amount |  |  | Accumulated Amortization |  |  | Net Book Value |  |  | Gross Amount |  |  | Accumulated Amortization |  |  | Net Book Value |  |  | Estimated Useful Life |  |
| Backlog |  |  | 4,008 |  |  |  | (2,038 | ) |  |  | 1,970 |  |  |  | 1,381 |  |  |  | (1,381 | ) |  |  | — |  |  | 2 |  |
| Trade names and trademarks |  |  | 1,800 |  |  |  | — |  |  |  | 1,800 |  |  |  | 1,800 |  |  |  | — |  |  |  | 1,800 |  |  | Indefinite |  |
| Customer relationships |  |  | 18,920 |  |  |  | (9,795 | ) |  |  | 9,126 |  |  |  | 10,880 |  |  |  | (7,901 | ) |  |  | 2,980 |  |  | 5-10 |  |
| Core technology and know-how |  |  | 5,970 |  |  |  | (5,317 | ) |  |  | 653 |  |  |  | 5,970 |  |  |  | (4,834 | ) |  |  | 1,136 |  |  | 5-10 |  |
| Intangible assets |  | $ | 30,698 |  |  | $ | (17,150 | ) |  | $ | 13,548 |  |  | $ | 20,031 |  |  | $ | (14,116 | ) |  | $ | 5,916 |  |  |  |  |

[0001437749-26-018542:notes:188]
The Company recorded intangible amortization expense of $3.0 million, $2.4 million, and $2.2 million for the fiscal years ended  March 31, 2026, 2025, and 2024 respectively. Included in these figures is $0.6 million for the fiscal year ended  March 31, 2026, $0.7 million for the fiscal year ended  March 31, 2025 and less than $0.1 million for the fiscal year ended  March 31, 2024 related to intangible amortization related to backlog that is reported in cost of revenues.

[0001437749-26-018542:notes:189]
Expected future amortization expense related to intangible assets is as follows (in thousands):

[0001437749-26-018542:notes:190]
| Fiscal years ending March 31, |  | Total |  |
| 2027 |  | $ | 3,812 |  |
| 2028 |  |  | 3,443 |  |
| 2029 |  |  | 2,133 |  |
| 2030 |  |  | 1,208 |  |
| 2031 |  |  | 724 |  |
| Thereafter |  |  | 428 |  |
| Total |  | $ | 11,748 |  |

[0001437749-26-018542:notes:191]
The Company's intangible assets relate entirely to the Grid business segment operations in the United States and Brazil. The following table summarizes the Company's intangibles by geography (in thousands):

[0001437749-26-018542:notes:192]
|  |  | March 31, 2026 |  |  | March 31, 2025 |  |
| Intangible assets by geography: |  |  |  |  |  |  |  |  |
| U.S. |  | $ | 4,567 |  |  | $ | 5,916 |  |
| Brazil |  |  | 8,980 |  |  |  | — |  |
| Total |  | $ | 13,548 |  |  | $ | 5,916 |  |


## us-gaap:EquityMethodInvestmentsDisclosureTextBlock

[0001437749-26-018542:notes:193]
11. Equity-Method Investments

[0001437749-26-018542:notes:194]
Investment in NWL Pacific Inc. Co., LTD

[0001437749-26-018542:notes:195]
The Company has a 50% ownership in NWL Pacific Inc. Co., LTD ("NWL Pacific"). The investment represents the Company's interest in NWL Pacific. The investment is a joint venture in South Korea established on  May 12, 1998.

[0001437749-26-018542:notes:196]
The Company treats the equity investment in the consolidated financial statements under the equity method. Equity method investments are equity securities in entities the Company does not control but over which it has the ability to exercise significant influence. These investments are accounted for under the equity method of accounting in accordance with ASC 323, Investments — Equity Method and Joint Ventures. Equity method investments are measured at cost minus impairment, if any, plus or minus the Company’s share of an investee’s income or loss, less distributions received. As of  March 31, 2026 and 2025 the Company did not have material accounts receivable nor accounts payable balances with NWL Pacific.

[0001437749-26-018542:notes:197]
The tables below present the summarized financial information from the Acquisition Date through  March 31, 2026, as provided to the Company by the investee, for the unconsolidated company (in thousands):

[0001437749-26-018542:notes:198]
|  |  | Fiscal year ended March 31, |  |  | Fiscal year ended March 31, |  |
|  |  | 2026 |  |  | 2025 |  |
| Net Revenue |  | $ | 7,293 |  |  | $ | 3,702 |  |
| Gross Profit |  |  | 3,037 |  |  |  | 1,483 |  |
| Income from operations |  |  | 1,194 |  |  |  | 490 |  |
| Net income |  |  | 1,102 |  |  |  | 474 |  |

[0001437749-26-018542:notes:199]
|  |  | Balance at March 31, |  |  | Balance at March 31, |  |
|  |  | 2026 |  |  | 2025 |  |
| Current Assets |  | $ | 5,278 |  |  | $ | 5,423 |  |
| Noncurrent Assets |  |  | 577 |  |  |  | 377 |  |
| Current Liabilities |  |  | 1,986 |  |  |  | 2,336 |  |
| Noncurrent Liabilities |  |  | 38 |  |  |  | 42 |  |


## us-gaap:AccountsPayableAndAccruedLiabilitiesDisclosureTextBlock

[0001437749-26-018542:notes:200]
12. Accounts Payable and Accrued Expenses

[0001437749-26-018542:notes:201]
Accounts payable and accrued expenses at  March 31, 2026 and  March 31, 2025 consisted of the following (in thousands):

[0001437749-26-018542:notes:202]
|  |  | March 31, 2026 |  |  | March 31, 2025 |  |
| Accounts payable |  | $ | 13,015 |  |  | $ | 6,733 |  |
| Accrued inventories in-transit |  |  | 1,104 |  |  |  | 2,111 |  |
| Accrued other miscellaneous expenses |  |  | 5,769 |  |  |  | 3,697 |  |
| Advanced deposits |  |  | 3,491 |  |  |  | 1,267 |  |
| Accrued compensation |  |  | 15,518 |  |  |  | 13,418 |  |
| Income taxes payable |  |  | 641 |  |  |  | 305 |  |
| Accrued product warranty |  |  | 4,684 |  |  |  | 3,033 |  |
| Accrued commissions |  |  | 2,323 |  |  |  | 1,718 |  |
| Total |  | $ | 46,545 |  |  | $ | 32,282 |  |

[0001437749-26-018542:notes:203]
The Company generally provides a one to three year warranty on its products, commencing upon delivery or installation where applicable. A provision is recorded upon revenue recognition to cost of revenues for estimated warranty expense based on historical experience.

[0001437749-26-018542:notes:204]
Product warranty activity was as follows (in thousands):

[0001437749-26-018542:notes:205]
|  |  | Fiscal Years Ended March 31, |  |
|  |  | 2026 |  |  | 2025 |  |
| Balance at beginning of period |  | $ | 3,033 |  |  | $ | 2,363 |  |
| Acquired warranty obligations |  |  | 450 |  |  |  | 637 |  |
| Provisions for warranties during the period |  |  | 2,672 |  |  |  | 1,641 |  |
| Settlements during the period |  |  | (1,471 | ) |  |  | (1,608 | ) |
| Balance at end of period |  | $ | 4,684 |  |  | $ | 3,033 |  |


## amsc:BusinessCombinationContingentConsiderationTextBlock

[0001437749-26-018542:notes:206]
13. Contingent Consideration

[0001437749-26-018542:notes:207]
NEPSI Contingent Consideration

[0001437749-26-018542:notes:208]
On  October 1, 2020 (the "NEPSI Acquisition Date"), the Company entered into a Stock Purchase Agreement (the "NEPSI Stock Purchase Agreement") with the selling stockholders named therein. Pursuant to the terms of the NEPSI Stock Purchase Agreement and concurrently with entering into such agreement, the Company acquired all of the issued and outstanding (i) shares of capital stock of NEPSI, and (ii) membership interests of Northeast Power Realty, LLC, a New York limited liability company, which holds the real property that serves as NEPSI's headquarters (the "NEPSI Acquisition"). NEPSI is a U.S.-based global provider of medium-voltage metal-enclosed power capacitor banks and harmonic filter banks for use on electric power systems. NEPSI is a wholly-owned subsidiary of the Company and is operated by its Grid business segment. The purchase price was $26.0 million in cash and 873,657 restricted shares of common stock of the Company. As part of the transaction, the selling stockholders were entitled to receive up to an additional 1,000,000 shares of common stock of the Company upon the achievement of certain specified revenue objectives during varying periods of up to four years following closing of the NEPSI Acquisition. During the year ended  March 31, 2024, the Company issued 399,999 shares of common stock and cash in lieu of a fractional share of common stock, related to the achievement of specified revenue objectives in connection with the NEPSI Acquisition. One specified revenue objective, which would have earned the selling stockholders 300,000 shares of Company common stock, was not achieved. NEPSI recognized revenues in excess of $120.0 million during the four years after the NEPSI Acquisition Date. As a result, during the quarter ended  September 30, 2024, the Company issued 300,000 shares of common stock of the Company to the selling stockholders, following certification of the achievement of the specified earnout revenue objective. As of  September 30, 2024, the Company had settled all outstanding contingent consideration under the NEPSI Stock Purchase Agreement.

[0001437749-26-018542:notes:209]
The Company evaluated the NEPSI Acquisition earnout payment set forth in the NEPSI Stock Purchase Agreement, which was expected to require settlement in the Company's common stock, and determined the contingent consideration qualified for liability classification and derivative treatment under ASC 815, Derivatives and Hedging. As a result, for the periods in which the Company had outstanding contingent consideration, the fair value of the contingent consideration was remeasured and the resulting gain or loss was recognized in operating expenses until the share amount was fixed.

[0001437749-26-018542:notes:210]
The following is a summary of the key assumptions used in a Monte Carlo simulation to calculate the fair value of the contingent consideration related to the NEPSI Acquisition:

[0001437749-26-018542:notes:211]
| Fiscal Year 2025 |  | June 30, 2024 |  |
| Revenue risk premium |  |  | 5.50 | % |
| Revenue volatility |  |  | 27.5 | % |
| Stock Price |  | $ | 23.39 |  |
| Payment delay (days) |  |  | 80 |  |
| Fair value (millions) |  | $ | 7.0 |  |

[0001437749-26-018542:notes:212]
During the fiscal year ended  March 31, 2025, the Company issued 300,000 shares of common stock related to the achievement of specified revenue objectives at a fair value of $6.5 million. The Company recorded no loss for the increase in the fair value of the contingent consideration in the fiscal year ended  March 31, 2026. The Company recorded a loss of $3.4 million for the increase in the fair value of the contingent consideration in the fiscal year ended  March 31, 2025.

[0001437749-26-018542:notes:213]
NWL Contingent Consideration

[0001437749-26-018542:notes:214]
On  August 1, 2024, the Company entered into the Stock Purchase Agreement with the selling stockholders of NWL named therein. Pursuant to the terms of the Stock Purchase Agreement and concurrently with entering into such agreement, the Company acquired all of the issued and outstanding shares of Megatran for aggregate consideration in an amount equal to $61.4 million which consideration amount was subject to various adjustments set forth in the Stock Purchase Agreement. The value of the contingent consideration to make the sellers whole was determined to be de minimis at the time of the Acquisition. On  September 23, 2024, the Company paid $3.3 million to the selling stockholders, which was calculated based on the agreed upon formula set forth in the Stock Purchase Agreement. This amount is reflected as the change in fair value of this contingent consideration in the fiscal year ended  March 31, 2025. As of  September 30, 2024, there were no remaining obligations to the selling stockholders of NWL.

[0001437749-26-018542:notes:215]
Comtrafo Contingent Consideration

[0001437749-26-018542:notes:216]
On  December 5, 2025, the Company entered into the Stock Exchange Agreement with the selling stockholders named therein. Pursuant to the terms of the Stock Exchange Agreement, the Company has agreed to pay the selling stockholders of the Comtrafo Acquisition an additional amount in cash upon the achievement of specified EBITDA objectives during the three years following the Comtrafo Acquisition Date. The Company evaluated the Comtrafo Acquisition earnout payment set forth in the Comtrafo Stock Exchange Agreement (See Note 2, "Acquisitions" for further details), which will require settlement in cash, and determined the contingent consideration qualified for liability classification. As a result, for each period, the fair value of the contingent consideration will be remeasured, and the resulting gain or loss will be recognized until the cash amount is fixed.

[0001437749-26-018542:notes:217]
Following is a summary of the key assumptions used in a Monte Carlo simulation to calculate the fair value of contingent consideration related to the Comtrafo Acquisition:

[0001437749-26-018542:notes:218]
|  |  | March 31, |  |  | December 31, |  |  | December 05, |  |
| Fiscal Year 2025 |  | 2026 |  |  | 2025 |  |  | 2025 |  |
| EBITDA Risk Premium (continuous) |  |  | 1.40 | % |  |  | 2.10 | % |  |  | 2.10 | % |
| EBITDA Volatility |  |  | 25.0 | % |  |  | 25.0 | % |  |  | 25.0 | % |
| Credit Spread (semiannual) |  |  | 1.9 | % |  |  | 1.9 | % |  |  | 1.9 | % |
| EBITDA discount rate |  |  | 14.7 | % |  |  | 15.0 | % |  |  | 15.0 | % |
| Payment delay (days) |  |  | 89 |  |  |  | 89 |  |  |  | 89 |  |
| Fair value (millions) |  | $ | 39.5 |  |  | $ | 34.8 |  |  | $ | 34.8 |  |

[0001437749-26-018542:notes:219]
The Company performed an analysis on the change in fair value through  March 31, 2026 and recorded a loss from the change in fair value of the contingent consideration for the fiscal year ended  March 31, 2026 of $4.2 million.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001437749-26-018542:notes:220]
14. Income Taxes

[0001437749-26-018542:notes:221]
Income (loss) before income taxes for the fiscal years ended  March 31, 2026, 2025 and 2024 are provided in the table as follows (in thousands):

[0001437749-26-018542:notes:222]
|  |  | Fiscal years ended March 31, |  |
|  |  | 2026 |  |  | 2025 |  |  | 2024 |  |
| Income (loss) from continuing operations before income tax expense (benefit) |  |  |  |  |  |  |  |  |  |  |  |  |
| U.S. |  | $ | 18,641 |  |  | $ | 1,882 |  |  | $ | (11,503 | ) |
| Foreign |  |  | (1,893 | ) |  |  | 484 |  |  |  | 701 |  |
| Total |  | $ | 16,748 |  |  | $ | 2,366 |  |  | $ | (10,802 | ) |

[0001437749-26-018542:notes:223]
The components of income tax expense (benefit) consist of the following (in thousands):

[0001437749-26-018542:notes:224]
|  |  | Fiscal years ended March 31, |  |
|  |  | 2026 |  |  | 2025 |  |  | 2024 |  |
| Current provision |  |  |  |  |  |  |  |  |  |  |  |  |
| Federal |  | $ | 36 |  |  | $ | 305 |  |  | $ | 150 |  |
| State |  |  | 1,017 |  |  |  | 222 |  |  |  | — |  |
| Foreign |  |  | 569 |  |  |  | 110 |  |  |  | 94 |  |
| Total current |  |  | 1,622 |  |  |  | 637 |  |  |  | 244 |  |
| Deferred provision (benefit) |  |  |  |  |  |  |  |  |  |  |  |  |
| Federal |  |  | (116,947 | ) |  |  | (4,259 | ) |  |  | 56 |  |
| State |  |  | (1,418 | ) |  |  | (13 | ) |  |  | — |  |
| Foreign |  |  | (318 | ) |  |  | (32 | ) |  |  | 9 |  |
| Total deferred |  |  | (118,683 | ) |  |  | (4,304 | ) |  |  | 65 |  |
| Income tax expense (benefit) |  | $ | (117,061 | ) |  | $ | (3,667 | ) |  | $ | 309 |  |

[0001437749-26-018542:notes:225]
As further described in Note 3, Summary of Significant Accounting Policies, the Company has elected to prospectively adopt the guidance in ASU 2023-09. The following table is a reconciliation of the Company's effective income tax rate to the statutory income tax rate for the fiscal year ended  March 31, 2026 in accordance with the guidance in ASU 2023-09:

[0001437749-26-018542:notes:226]
|  |  | Fiscal year ended March 31, |  |
|  |  | 2026 |  |
| U.S. Federal Statutory Income Tax (benefit) at 21% |  |  | (21.0 | %) |
| Domestic Federal |  |  |  |  |
| Tax Credits |  |  | (0.4 | %) |
| Non Taxable or Non Deductible Items |  |  |  |  |
| Stock Compensation |  |  | 22.6 | % |
| Excess Officer Compensation |  |  | (30.6 | %) |
| Transaction Costs |  |  | (1.6 | %) |
| Other |  |  | 0.6 | % |
| Changes in Valuation Allowance |  |  | 730.1 | % |
| Cross Border |  |  |  |  |
| Global intangible low-tax income |  |  | (1.5 | %) |
| Other |  |  | (0.1 | %) |
| Other reconciling items |  |  |  |  |
| Other |  |  | 1.0 | % |
| Domestic State and local income taxes, net of federal effect |  |  | 3.6 | % |
| Foreign Tax effects |  |  |  |  |
| Brazil |  |  |  |  |
| Fair value adjustment for Contingent Liability |  |  | (8.5 | %) |
| Statutory income tax rate differential |  |  | 2.4 | % |
| Other |  |  | 1.2 | % |
| Other foreign jurisdictions |  |  | 1.0 | % |
| Worldwide Changes in unrecognized tax benefits |  |  | 0.0 | % |
| Effective income tax rate |  |  | 698.8 | % |

[0001437749-26-018542:notes:227]
The following table is a reconciliation of the Company's effective income tax rate to the statutory federal income tax for the fiscal years ended  March 31, 2025 and 2024 in accordance with the guidance prior to the adoption of ASU 2023-09:

[0001437749-26-018542:notes:228]
|  |  | Fiscal years ended March 31, |  |
|  |  | 2025 |  |  | 2024 |  |
| Statutory Federal Income tax rate |  |  | (21 | %) |  |  | (21 | %) |
| State income taxes, net of federal benefit |  |  | 35 | % |  |  | 7 | % |
| Foreign income tax rate differential |  |  | 2 | % |  |  | 2 | % |
| Stock options |  |  | 54 | % |  |  | 0 | % |
| Research and development tax credit |  |  | 0 | % |  |  | 4 | % |
| Mark to market adjustment on contingent consideration |  |  | (59 | %) |  |  | 10 | % |
| Nondeductible expenses |  |  | (12 | %) |  |  | 0 | % |
| Valuation allowance |  |  | 231 | % |  |  | (60 | %) |
| NOL and capital loss expiration |  |  | (10 | %) |  |  | 58 | % |
| Other |  |  | (4 | %) |  |  | 4 | % |
| Withholding Taxes |  |  | (16 | %) |  |  | 0 | % |
| 162(m) |  |  | (43 | %) |  |  | 0 | % |
| Effective income tax rate |  |  | 157 | % |  |  | 4 | % |

[0001437749-26-018542:notes:229]
For the fiscal year ended  March 31, 2026, the Company paid income taxes, net of refunds received as follows:

[0001437749-26-018542:notes:230]
|  |  | Fiscal years ended March 31, |  |
|  |  | 2026 |  |
| Income taxes paid, net of refunds: |  |  |  |  |
| U.S Federal |  | $ | 36 |  |
| U.S. State and Local |  |  |  |  |
| Pennsylvania |  |  | 425 |  |
| Connecticut |  |  | 77 |  |
| Other states |  |  | 90 |  |
| Foreign |  |  |  |  |
| Austria |  |  | 52 |  |
| Other foreign |  |  | 26 |  |
| Total |  | $ | 706 |  |

[0001437749-26-018542:notes:231]
The following is a summary of the principal components of the Company’s deferred tax assets and liabilities at  March 31, 2026 and 2025 (in thousands):

[0001437749-26-018542:notes:232]
|  |  | March 31, 2026 |  |  | March 31, 2025 |  |
| Deferred tax assets: |  |  |  |  |  |  |  |  |
| Net operating loss carryforwards |  | $ | 144,497 |  |  | $ | 150,703 |  |
| Research and development and other tax credit carryforwards |  |  | 12,163 |  |  |  | 12,605 |  |
| Capitalized research and development costs |  |  | 4,762 |  |  |  | 5,787 |  |
| Accruals and reserves |  |  | 13,695 |  |  |  | 8,148 |  |
| Fixed assets and intangible assets |  |  | 9 |  |  |  | 398 |  |
| Other |  |  | 2,080 |  |  |  | 2,459 |  |
| Gross deferred tax assets |  |  | 177,206 |  |  |  | 180,100 |  |
| Valuation allowance |  |  | (45,005 | ) |  |  | (171,674 | ) |
| Total deferred tax assets |  |  | 132,201 |  |  |  | 8,426 |  |
| Deferred tax liabilities: |  |  |  |  |  |  |  |  |
| Amortization of fixed assets and intangibles |  |  | (11,191 | ) |  |  | (7,127 | ) |
| Other |  |  | (1,536 | ) |  |  | (1,716 | ) |
| Total deferred tax liabilities |  |  | (12,727 | ) |  |  | (8,843 | ) |
| Net deferred tax assets (liabilities) |  | $ | 119,474 |  |  | $ | (417 | ) |

[0001437749-26-018542:notes:233]
The above deferred tax balances are recorded on the consolidated balance sheet as follows:

[0001437749-26-018542:notes:234]
|  |  | March 31, 2026 |  |
| Deferred tax assets |  |  | 119,474 |  |
| Deferred tax liabilities |  |  | - |  |
| Net deferred tax assets (liabilities) |  |  | 119,474 |  |

[0001437749-26-018542:notes:235]
On a quarterly basis, the Company reassesses the valuation allowance on deferred income tax assets, weighing positive and negative evidence to assess the recoverability of the deferred tax assets. During the fiscal year ended  March 31, 2026, the Company recorded a net $118.4 million non-cash income tax benefit related to the release of a substantial portion of its valuation allowance against U.S. deferred tax assets. This was based on the Company's evaluation of the positive evidence, including cumulative income position over the previous three-years, revenue growth, current profitability, expectations regarding future forecasted income, and negative evidence, including uncertainty in economic and political environments from industry competition and dependence on government contracts. This release of the valuation allowance resulted in the recognition of a deferred tax asset and a corresponding increase to income tax benefit in the current period, the effect of which is an increase in reported net income.

[0001437749-26-018542:notes:236]
After consideration of all the available evidence, both positive and negative, the Company has determined that a $45.0 million valuation allowance at  March 31, 2026 is necessary to reduce the U.S. deferred tax assets to the deferred tax assets to the amount that will more likely than not be realized which is a $126.7 million decrease from the $171.7 million valuation allowance as of  March 31, 2025. As of  March 31, 2026, the Company provides a valuation allowance against certain deferred tax assets in the U.S. and Poland.

[0001437749-26-018542:notes:237]
At  March 31, 2026, the Company had aggregate net operating loss carryforwards in the U.S. for federal and state income tax purposes of approximately $624.8 million and $173.7 million, respectively, which expire in the years ending  March 31, 2026 through 2042. For U.S. federal tax purpose, approximately $73.0 million of federal net operating losses have an indefinite carryforward period. Research and development and other tax credit carryforwards amounting to approximately $10.6 million and $2.0 million are available to offset federal and state income taxes, respectively, and will expire in the years ending through 2042.

[0001437749-26-018542:notes:238]
As of  March 31, 2026, AMSC Brazil has aggregate net operating loss carryforwards of approximately $7.9 million, which have an indefinite carryforward period. As of  March 31, 2026, AMSC Poland has aggregate net operating loss carryforwards of approximately $0.4 million, which will begin to expire  March 31, 2030.

[0001437749-26-018542:notes:239]
Under the Tax Cuts and Jobs Act of 2017, taxpayers are required to capitalize and amortize expenses related for research and experimental as classified under Section 174 beginning in 2022. Amortization recovery for such costs are five years for domestic expenditures and fifteen for foreign expenditures. As of  March 31, 2026, the Company had approximately $35.6 million of research and experimental expenses that had been capitalized under Section 174 with a remaining basis of $21.2 million for U.S. Federal purposes.

[0001437749-26-018542:notes:240]
On  July 4, 2025, the reconciliation bill, commonly referred to as the One Big Beautiful Bill ("OBBB") was signed into law, which includes a broad range of tax reform provisions that  may affect a company's financial results. The OBBB allows an elective deduction for domestic research and development (R&D), a reinstatement of elective 100% first-year bonus depreciation, and a more favorable tax rate on Foreign derived deduction eligible income and income from non-U.S. subsidiaries (Net CFC Tested Income), among other provisions. The Company has performed an evaluation of the impact of the OBBB on the Company's effective tax rate and deferred tax assets in fiscal year 2025 and future periods. Based on this evaluation, the tax reform provisions do not have a material impact on the Company's consolidated financial statements and related disclosures for the fiscal year ended  March 31, 2026. We will continue to assess the implications of the OBBB, and our tax provision  may be further impacted as additional guidance from the U.S department of the Treasury is released.

[0001437749-26-018542:notes:241]
Section
    382 of the U.S. Internal Revenue Code of
    1986, as amended (the “IRC”), provides limits on the extent to which a corporation that has undergone an ownership change (as defined) can utilize any net operating loss ("NOL") and general business tax credit carryforwards it
     may have. The Company updated its ownership change study through 
     March 31, 2026 to determine whether Section
    382 could limit the use of its carryforwards in this manner. After completing this study, the Company has concluded that the limitation will
    not have a material impact on its ability to utilize its NOL carryforwards.  If there were material ownership changes subsequent to the study, such changes could limit the Company's ability to utilize its NOL carryforwards.

[0001437749-26-018542:notes:242]
The total amount of undistributed foreign earnings available to be repatriated at  March 31, 2026 was $5.5 million resulting in the recording of a $0.4 million deferred tax liability for foreign withholding taxes.

[0001437749-26-018542:notes:243]
Accounting for income taxes requires a two-step approach to recognizing and measuring uncertain tax positions. The first step is to evaluate the tax position for recognition by determining if, based on the technical merits, it is more likely than not that the position will be sustained upon audit, including resolution of related appeals or litigation processes, if any. The second step is to measure the tax benefit as the largest amount that is more than 50% likely of being realized upon ultimate settlement. The Company reevaluates these uncertain tax positions on a quarterly basis. This evaluation is based on factors including, but not limited to, changes in facts or circumstances, changes in tax law, effectively settled issues under audit and new audit activity. Any changes in these factors could result in the recognition of a tax benefit or an additional charge to the tax provision. The Company did not identify any uncertain tax positions at  March 31, 2026. The Company did not have any gross unrecognized tax benefits at  March 31, 2026, 2025, or 2024.

[0001437749-26-018542:notes:244]
There were no reversals of uncertain tax positions in the fiscal years ended  March 31, 2026, 2025 and 2024.

[0001437749-26-018542:notes:245]
The Company accounts for interest and penalties related to uncertain tax positions as part of its provision for federal and state income taxes. Any unrecognized tax benefits, if recognized, would favorably affect its effective tax rate in any future period. The Company does not expect that the amounts of unrecognized benefits will change significantly within the next twelve months.

[0001437749-26-018542:notes:246]
The Company conducts business globally and, as a result, its subsidiaries file income tax returns in the U.S. federal jurisdiction and various state and foreign jurisdictions. Major tax jurisdictions include the U.S., Austria, and Brazil. All U.S. income tax filings for fiscal years ended  March 31, 1996 through 2026 remain open and subject to examination.

[0001437749-26-018542:notes:247]
All fiscal years from the fiscal year ended  March 31, 2024 through 2026 remain open and subject to examination in Austria. Tax filings in Romania for the fiscal years ended  March 31, 2021 through 2026 remain open and subject to examination. Tax filings in Poland for tax years 2022 through  March 31, 2026 remain open and subject to examination. Tax filings in Brazil for the tax years 2020 through  March 31, 2026 remain open and subject to examination.


## us-gaap:DebtDisclosureTextBlock

[0001437749-26-018542:notes:248]
15. Debt

[0001437749-26-018542:notes:249]
As part of the Comtrafo Acquisition, the Company identified three debt agreements that Comtrafo had entered into prior to the Comtrafo Acquisition Date. The debt agreements totaling $8.8 million were subsequently paid off during the fiscal year ended  March 31, 2026.


## us-gaap:LesseeOperatingLeasesTextBlock

[0001437749-26-018542:notes:250]
16. Leases

[0001437749-26-018542:notes:251]
Operating Leases

[0001437749-26-018542:notes:252]
All significant lease arrangements are recognized at lease commencement. Operating lease right–of-use assets and lease liabilities are recognized at commencement. The operating lease right-of-use asset includes any lease payments related to initial direct cost and prepayments and excludes any lease incentives. Lease expense is recognized on a straight-line basis over the lease term. The Company enters into a variety of operating lease agreements through the normal course of its business, but primarily real estate leases to support its operations. The real estate lease agreements generally provide for fixed minimum rental payments and the payment of real estate taxes and insurance. Many of these real estate leases have one or more renewal options that allow the Company, at its discretion, to renew the lease for varying periods up to five years or to terminate the lease. Only renewal options or termination rights that the Company believed were likely to be exercised were included in the lease calculations.

[0001437749-26-018542:notes:253]
The Company also enters into leases for vehicles, IT equipment and service agreements, and other leases related to its manufacturing operations that are also included in the right-of-use assets and lease liability accounts if they are for a term of longer than twelve months. However, many of these leases are either short-term in nature or immaterial. The Company has made the policy election to exclude short-term leases from the consolidated balance sheets.

[0001437749-26-018542:notes:254]
Supplemental balance sheet information related to leases at  March 31, 2026 and 2025 are as follows (in thousands):

[0001437749-26-018542:notes:255]
|  |  | March 31, 2026 |  |  | March 31, 2025 |  |
| Leases: |  |  |  |  |  |  |  |  |
| Right-of-use assets - Operating |  |  | 3,897 |  |  |  | 3,829 |  |
| Total right-of-use assets |  | $ | 3,897 |  |  | $ | 3,829 |  |
| Lease liabilities - ST Operating |  |  | 1,238 |  |  |  | 685 |  |
| Lease liabilities - LT Operating |  |  | 2,762 |  |  |  | 2,684 |  |
| Total lease liabilities |  | $ | 4,000 |  |  | $ | 3,369 |  |
| Weighted-average remaining lease term |  |  | 4.26 |  |  |  | 4.94 |  |
| Weighted-average discount rate |  |  | 14.13 | % |  |  | 14.94 | % |

[0001437749-26-018542:notes:256]
The Company did not incur any finance lease costs and the costs related to the Company's operating leases for the fiscal years ended  March 31, 2026 and 2025, are as follows (in thousands):

[0001437749-26-018542:notes:257]
|  |  | Fiscal year ended |  |  | Fiscal year ended |  |  | Fiscal year ended |  |
|  |  | March 31, 2026 |  |  | March 31, 2025 |  |  | March 31, 2024 |  |
| Operating Leases: |  |  |  |  |  |  |  |  |  |  |  |  |
| Operating lease costs - fixed |  |  | $ 1,690 |  |  |  | $ 1,453 |  |  |  | $ 1,023 |  |
| Operating lease costs - variable |  |  | 181 |  |  |  | 119 |  |  |  | 158 |  |
| Short-term lease costs |  |  | 167 |  |  |  | 153 |  |  |  | 149 |  |
| Total lease costs |  |  | $ 2,038 |  |  |  | $ 1,725 |  |  |  | $ 1,330 |  |

[0001437749-26-018542:notes:258]
The Company’s estimated minimum future lease obligations under the Company's leases are as follows:

[0001437749-26-018542:notes:259]
|  |  | Operating Leases |  |
| Year ended March 31, |  |  |  |  |
| 2027 |  | $ | 1,696 |  |
| 2028 |  |  | 1,443 |  |
| 2029 |  |  | 612 |  |
| 2030 |  |  | 423 |  |
| 2031 |  |  | 322 |  |
| Thereafter |  |  | 944 |  |
| Total minimum lease payments |  |  | 5,440 |  |
| Less: interest |  |  | (1,439 | ) |
| Present value of lease liabilities |  | $ | 4,000 |  |


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001437749-26-018542:notes:260]
17. Stockholders’ Equity

[0001437749-26-018542:notes:261]
Stock-Based Compensation Plans

[0001437749-26-018542:notes:262]
As of  March 31, 2026, the Company had two active stock plans: the Amended and Restated 2007 Director Stock Plan, as amended (the “2007 Director Plan”) and the 2022 Stock Incentive Plan, as amended and restated (the "2022 Plan"). On  August 2, 2024, the Company's stockholders approved amendments to the 2022 Plan and amendments to the Company's 2007 Director Plan. The amendment to the 2022 Plan increased the total number of shares of common stock authorized for issuance under the 2022 Plan from 1,150,000 shares to 4,400,000 shares of common stock. The amendment to the 2007 Director Plan increased the total number of shares of common stock authorized for issuance under the 2007 Director Plan from 430,000 shares to 580,000 shares.

[0001437749-26-018542:notes:263]
The 2022 Plan provides for the grant of incentive stock options intended to qualify under Section 422 of the IRC of 1986 nonstatutory stock options, stock appreciation rights, restricted stock, restricted stock units and other stock-based awards. In the case of options, the exercise price is no less than the fair market value of the common stock, as determined by (or in a manner approved by) the Board of Directors, on the date of grant. The contractual life of options is generally 10 years. Options generally vest over a 3-5 year period while restricted stock generally vests over a 3 year period. The 2022 Plan replaced the Company’s 2007 Stock Incentive Plan, as amended (the “2007 Plan”). No further awards are granted under the 2007 Plan following effectiveness of the 2022 Plan; however, the terms and conditions of the 2007 Plan continue to govern any outstanding awards granted thereunder.

[0001437749-26-018542:notes:264]
The 2007 Director Plan provides for the grant of nonstatutory stock options and stock awards to members of the Board of Directors who are not also employees of the Company ("outside directors"). Under the terms of the 2007 Director Plan, each outside director is granted an option to purchase shares of common stock with an aggregate grant date value equal to $40,000 upon his or her initial election to the Board with an exercise price equal to the fair market value of the Company’s common stock on the date of the grant. These options vest in equal annual installments over a two-year period. In addition, each outside director is granted an award of shares of common stock on the third business day following the last day of each fiscal year with an aggregate value equal to $100,000 using the closing price of the Company's common stock two business days following the last day of each fiscal year, subject to proration for any partial fiscal year of service.

[0001437749-26-018542:notes:265]
As of  March 31, 2026, the 2022 Plan had 1,537,412 shares available for future issuance, and the 2007 Director Plan had 238,289 shares available for future issuance. Additionally, any shares which are subject to awards previously granted under the 2007 Plan that are forfeited or lapse unexercised and which following the effectiveness of the 2022 Plan are not issued under the 2007 Plan will become available for issuance under the 2022 Plan.

[0001437749-26-018542:notes:266]
The components of stock-based compensation for the fiscal years ended  March 31, 2026, 2025 and 2024 were as follows (in thousands):

[0001437749-26-018542:notes:267]
|  |  | Fiscal years ended March 31, |  |
|  |  | 2026 |  |  | 2025 |  |  | 2024 |  |
| Stock options |  | $ | 17 |  |  | $ | 8 |  |  | $ | 40 |  |
| Restricted stock and stock awards |  |  | 15,794 |  |  |  | 7,732 |  |  |  | 4,563 |  |
| Employee stock purchase plan |  |  | 57 |  |  |  | 54 |  |  |  | 49 |  |
| Total stock-based compensation expense |  | $ | 15,869 |  |  | $ | 7,794 |  |  | $ | 4,652 |  |

[0001437749-26-018542:notes:268]
The estimated fair value of the Company’s stock-based awards, less expected annual forfeitures, is amortized over the awards’ service period. The total unrecognized compensation cost for unvested outstanding restricted stock was $21.5 million as of  March 31, 2026. This expense will be recognized over a weighted-average expense period of approximately 1.6 years.

[0001437749-26-018542:notes:269]
The following table summarizes stock-based compensation expense by financial statement line item for the fiscal years ended  March 31, 2026, 2025, and 2024 (in thousands):

[0001437749-26-018542:notes:270]
|  |  | Fiscal years ended March 31, |  |
|  |  | 2026 |  |  | 2025 |  |  | 2024 |  |
| Cost of revenues |  | $ | 1,138 |  |  | $ | 536 |  |  | $ | 293 |  |
| Research and development |  |  | 2,192 |  |  |  | 1,132 |  |  |  | 627 |  |
| Selling, general and administrative |  |  | 12,539 |  |  |  | 6,126 |  |  |  | 3,732 |  |
| Total |  | $ | 15,869 |  |  | $ | 7,794 |  |  | $ | 4,652 |  |

[0001437749-26-018542:notes:271]
The following table summarizes the information concerning currently outstanding and exercisable employee and non-employee options:

[0001437749-26-018542:notes:272]
|  |  | Options / Shares |  |  | Weighted-Average Exercise Price |  |  | Weighted-Average Remaining Contractual Term |  |  | Aggregate Intrinsic Value (thousands) |  |
| Outstanding at March 31, 2025 |  |  | 36,206 |  |  | $ | 6.94 |  |  |  |  |  |  |  |  |  |
| Granted |  |  | 2,112 |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Exercised |  |  | (9,703 | ) |  |  |  |  |  |  |  |  |  |  |  |  |
| Canceled/forfeited |  |  | — |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Outstanding at March 31, 2026 |  |  | 28,615 |  |  | $ | 8.49 |  |  |  | 5.8 |  |  | $ | 726 |  |
| Exercisable at March 31, 2026 |  |  | 26,503 |  |  | $ | 6.99 |  |  |  | 5.5 |  |  | $ | 712 |  |
| Fully vested and expected to vest at March 31, 2026 |  |  | 28,560 |  |  | $ | 8.46 |  |  |  | 5.8 |  |  | $ | 725 |  |

[0001437749-26-018542:notes:273]
The Company issued 887,000 and 872,500 shares of restricted stock during the fiscal years ended  March 31, 2026 and 2025, respectively. The Company issued 39,445 and 19,200 shares of immediately vested common stock during the fiscal years ended  March 31, 2026 and 2025, respectively. These restricted stock awards generally vest over 2-3 years. Awards of restricted stock include both time-based and performance-based awards. For time-based restricted stock awards, expense is being recorded over the vesting period. Performance-based restricted stock awards are expensed over the requisite service period based on probability of achievement.

[0001437749-26-018542:notes:274]
The Company granted 2,112 stock options during the fiscal year ended  March 31, 2026 and no stock options during the fiscal year ended  March 31, 2025. The stock options granted during the fiscal year ended  March 31, 2026 will vest over 2 years. The estimated fair value of the Company's stock-based awards, less expected annual forfeitures, is amortized over the awards' service period. There were less than $0.1 million of unrecognized compensation costs for unvested stock options as of  March 31, 2026. This expense will be recognized over a period of approximately 1.2 years.

[0001437749-26-018542:notes:275]
The weighted average assumptions used in the Black Scholes valuation model for stock options granted during the fiscal year ended  March 31, 2026 are as follows:

[0001437749-26-018542:notes:276]
|  |  | Fiscal Year Ended March 31, |  |
|  |  | 2026 |  |
| Expected volatility |  |  | 74.01 | % |
| Risk-free interest rate |  |  | 4.19 | % |
| Expected life (years) |  |  | 6.31 |  |
| Dividend yield |  | None |  |

[0001437749-26-018542:notes:277]
The following table summarizes the restricted stock activity for the year ended  March 31, 2026:

[0001437749-26-018542:notes:278]
|  |  | Shares |  |  | Weighted Average Grant Date Fair Value |  |  | Intrinsic Aggregate Value (thousands) |  |
| Outstanding at March 31, 2025 |  |  | 1,790,153 |  |  | $ | 13.82 |  |  |  |  |  |
| Granted |  |  | 926,445 |  |  |  | 23.79 |  |  |  |  |  |
| Vested |  |  | (821,707 | ) |  |  | 10.79 |  |  |  |  |  |
| Forfeited |  |  | — |  |  |  | — |  |  |  |  |  |
| Outstanding at March 31, 2026 |  |  | 1,894,891 |  |  | $ | 20.00 |  |  | $ | 64,142 |  |

[0001437749-26-018542:notes:279]
The total fair value of restricted stock that was granted during the fiscal years ended  March 31, 2026 and 2025 was $22.1 million and $19.6 million, respectively. The total fair value of restricted stock that vested during the fiscal years ended  March 31, 2026 and 2025 was $24.3 million and $10.7 million, respectively.

[0001437749-26-018542:notes:280]
There were 310,000 performance-based restricted shares awarded during the fiscal year ended  March 31, 2026 for which the performance conditions are deemed probable to be met and the expense is being recorded over a three-year vesting period. There were 250,000 performance-based restricted shares awarded during the fiscal year ended  March 31, 2025 for which the performance conditions are deemed probable to be met and the expense is being recorded over a three-year vesting period.

[0001437749-26-018542:notes:281]
The remaining shares awarded vest upon the passage of time. For awards that vest upon the passage of time, expense is being recorded over the vesting period.

[0001437749-26-018542:notes:282]
Employee Stock Purchase Plan

[0001437749-26-018542:notes:283]
The Company maintains the 2000 Employee Stock Purchase Plan, as amended (the "ESPP") which provides employees with the opportunity to purchase shares of common stock at a price equal to the fair market value of the common stock at the end of the offering period, less a 15% purchase discount. As of  March 31, 2026, the ESPP had 39,977 shares available for future issuance. The Company recognized $0.1 million of compensation expense for each of the fiscal years ended  March 31, 2026, 2025, and 2024 related to the ESPP.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001437749-26-018542:notes:284]
18. Commitments and Contingencies

[0001437749-26-018542:notes:285]
Purchase Commitments

[0001437749-26-018542:notes:286]
The Company periodically enters into non-cancelable purchase contracts in order to ensure the availability of materials to support production of its products. Purchase commitments represent enforceable and legally binding agreements with suppliers to purchase goods or services. The Company periodically assesses the need to provide for impairment on these purchase contracts and records a loss on purchase commitments when required.

[0001437749-26-018542:notes:287]
Lease Commitments

[0001437749-26-018542:notes:288]
During the fiscal years ended  March 31, 2026, 2025, and 2024 all lease costs were recorded in selling, general and administrative expense.  See Note 16, "Leases" for further details.

[0001437749-26-018542:notes:289]
Legal Contingencies

[0001437749-26-018542:notes:290]
From time to time, the Company is involved in legal and administrative proceedings and claims of various types. The Company records a liability in its consolidated financial statements for these matters when a loss is known or considered probable and the amount can be reasonably estimated. The Company reviews these estimates each accounting period as additional information is known and adjusts the loss provision when appropriate. If a matter is both probable to result in a liability and the amounts of loss can be reasonably estimated, the Company estimates and discloses the possible loss or range of loss to the extent necessary to make the consolidated financial statements not misleading. If the loss is not probable or cannot be reasonably estimated, a liability is not recorded in its consolidated financial statements.

[0001437749-26-018542:notes:291]
Other

[0001437749-26-018542:notes:292]
The Company enters into long-term construction contracts with customers that require the Company to obtain performance bonds. The Company is required to deposit an amount equivalent to some or all the face amount of the performance bonds into an escrow account until the termination of the bond. When the performance conditions are met, amounts deposited as collateral for the performance bonds are returned to the Company. In addition, the Company has various contractual arrangements in which minimum quantities of goods or services have been committed to be purchased on an annual basis.

[0001437749-26-018542:notes:293]
AMSC Brazil, through Comtrafo, purchased additional real estate within the twelve months following the Comtrafo Acquisition Date for 37.2 million Brazilian Real in cash upon successful re-zoning classification of such real estate.

[0001437749-26-018542:notes:294]
As of  March 31, 2026, the Company had $3.3 million of restricted cash included in long-term assets and $3.5 million of restricted cash included in current assets. As of  March 31, 2025, the Company had $4.3 million of restricted cash included in long term assets and $1.6 million of restricted cash included in current assets. These amounts included in restricted cash primarily represent deposits to secure letters of credit for various supply contracts and long-term projects or collateral deposits. These deposits are held in interest bearing accounts.


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0001437749-26-018542:notes:295]
19. Employee Benefit Plans

[0001437749-26-018542:notes:296]
The Company has implemented a defined contribution plan (the “Plan”) under Section 401(k) of the IRC. Any contributions made by the Company to the Plan are discretionary. The Company has a stock match program under which the Company matched, in the form of Company common stock, 100% up to 5% of eligible contributions. The Company recorded expenses of $1.9 million, $1.2 million and $0.6 million in the fiscal years ended  March 31, 2026, 2025, and 2024 respectively, and recorded corresponding charges to additional paid-in capital related to this program.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001437749-26-018542:notes:297]
20. Business Segments

[0001437749-26-018542:notes:298]
The Company reports its financial results in two reportable business segments: Grid and Wind. In accordance with ASC 280, Segment Reporting, the Company has identified two operating segments. The Company's operating segments reflect the way in which internally-reported financial information is used to make decisions and allocate resources.

[0001437749-26-018542:notes:299]
Through the Company’s power grid offerings, the Grid business segment enables electric utilities, industrial facilities, and renewable energy project developers to connect, transmit and distribute smarter, cleaner and better power through its transmission planning services, power electronics, and superconductor-based systems. The sales process is enabled by transmission planning services that allow it to identify power grid congestion, poor power quality and other risks, which helps the Company determine how its solutions can improve network performance. These services often lead to sales of grid interconnection solutions for wind farms and solar power plants, power quality systems, and transmission and distribution cable systems. The Company also sells ship protection products to the U.S. Navy through its Grid business segment.

[0001437749-26-018542:notes:300]
Through the Company’s wind power offerings, the Wind business segment enables manufacturers to field highly competitive wind turbines through its advanced power electronics and control system products, engineered designs, and support services. The Company supplies advanced power electronics and control systems, licenses its highly engineered wind turbine designs, and provides extensive customer support services to wind turbine manufacturers. The Company’s design portfolio includes a broad range of drive trains and power ratings of 2 megawatts ("MWs") and higher. The Company provides a broad range of power electronics and software-based control systems that are highly integrated and designed for optimized performance, efficiency, and grid compatibility.

[0001437749-26-018542:notes:301]
AMSC’s Chief Executive Officer Daniel McGahn is the chief operating decision maker. The chief operating decision maker uses segment operating income (loss) to allocate resources (including employees, property, and financial or capital resources) for each segment predominantly in the annual budget and forecasting process. The chief operating decision maker considers budget-to-actual variances on a monthly basis for segment operating income (loss) when making decisions about allocating capital and personnel to the segments. The chief operating decision maker also uses segment operating income or loss to assess the performance for each segment by comparing the results and return on assets of each segment with one another and in the compensation of certain employees.

[0001437749-26-018542:notes:302]
The following tables (i) summarize total sales by segment and (ii) reconcile each segment's sales to their respective segment operating income, including segment operating expenses, for each of the fiscal years ended  March 31, 2026, 2025, and 2024 (in thousands):

[0001437749-26-018542:notes:303]
|  |  | Fiscal Year Ended March 31, 2026 |  |
|  |  | Grid |  |  | Wind |  |  | Unallocated |  |  | Total |  |
| Segment operating income: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Revenues |  | $ | 251,317 |  |  | $ | 47,838 |  |  | $ | — |  |  | $ | 299,155 |  |
| Less (a) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Segment other operating expenses (b) |  |  | 242,849 |  |  |  | 40,689 |  |  |  | 4,171 |  |  |  | 287,710 |  |
| Segment operating income (loss) |  | $ | 8,468 |  |  | $ | 7,149 |  |  | $ | (4,171 | ) |  | $ | 11,445 |  |

[0001437749-26-018542:notes:304]
(a) The significant expense categories and amounts align with the segment-level information that is regularly provided to the chief operating decision maker.

[0001437749-26-018542:notes:305]
(b) Segment other operating expense includes cost of sales, research and development expense, selling general, and administrative expense, amortization of acquisition related intangibles, and gain/loss on contingent consideration.

[0001437749-26-018542:notes:306]
|  |  | Fiscal Year Ended March 31, 2025 |  |
|  |  | Grid |  |  | Wind |  |  | Unallocated |  |  | Total |  |
| Segment operating income: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Revenues |  | $ | 187,170 |  |  | $ | 35,648 |  |  | $ | — |  |  | $ | 222,818 |  |
| Less (a) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Segment other operating expenses (b) |  |  | 185,358 |  |  |  | 31,856 |  |  |  | 6,681 |  |  |  | 223,895 |  |
| Segment operating income (loss) |  | $ | 1,812 |  |  | $ | 3,792 |  |  | $ | (6,681 | ) |  | $ | (1,077 | ) |

[0001437749-26-018542:notes:307]
|  |  | Fiscal Year Ended March 31, 2024 |  |
|  |  | Grid |  |  | Wind |  |  | Unallocated |  |  | Total |  |
| Segment operating income: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Revenues |  | $ | 122,065 |  |  | $ | 23,574 |  |  | $ | — |  |  | $ | 145,639 |  |
| Less (a) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Segment other operating expenses (b) |  |  | 128,974 |  |  |  | 23,125 |  |  |  | 4,908 |  |  |  | 157,007 |  |
| Segment operating income (loss) |  | $ | (6,909 | ) |  | $ | 449 |  |  | $ | (4,908 | ) |  | $ | (11,368 | ) |

[0001437749-26-018542:notes:308]
Unallocated corporate expenses consist of a loss on contingent consideration of $4.2 million, $6.7 million and $4.9 million in the fiscal years ended  March 31, 2026, 2025 and 2024, respectively.

[0001437749-26-018542:notes:309]
The reconciliation of segment operating income (loss) to consolidated income (loss) before income taxes for the fiscal years ended  March 31, 2026, 2025, and 2024 is as follows (in thousands):

[0001437749-26-018542:notes:310]
|  |  | Fiscal Years Ended March 31, |  |
|  |  | 2026 |  |  | 2025 |  |  | 2024 |  |
| Operating income (loss): |  | $ | 11,445 |  |  | $ | (1,077 | ) |  | $ | (11,368 | ) |
| Interest income, net |  |  | 6,356 |  |  |  | 3,708 |  |  |  | 1,302 |  |
| Other expense |  |  | (1,053 | ) |  |  | (265 | ) |  |  | (736 | ) |
| Income (loss) before taxes |  | $ | 16,748 |  |  | $ | 2,366 |  |  | $ | (10,802 | ) |

[0001437749-26-018542:notes:311]
Depreciation and amortization expense by segment for the years ended  March 31, 2026, 2025, and 2024 is as follows (in thousands):

[0001437749-26-018542:notes:312]
|  |  | Fiscal Years Ended March 31, |  |
|  |  | 2026 |  |  | 2025 |  |  | 2024 |  |
| Grid |  | $ | 7,253 |  |  | $ | 5,468 |  |  | $ | 4,407 |  |
| Wind |  |  | 133 |  |  |  | 92 |  |  |  | 87 |  |
| Total |  | $ | 7,386 |  |  | $ | 5,560 |  |  | $ | 4,494 |  |

[0001437749-26-018542:notes:313]
Total assets for the two business segments as of  March 31, 2026 and  March 31, 2025 are as follows (in thousands):

[0001437749-26-018542:notes:314]
|  |  | March 31, 2026 |  |  | March 31, 2025 |  |
| Grid |  | $ | 574,195 |  |  | $ | 211,520 |  |
| Wind |  |  | 17,572 |  |  |  | 13,697 |  |
| Corporate assets |  |  | 147,714 |  |  |  | 85,304 |  |
| Total |  | $ | 739,481 |  |  | $ | 310,521 |  |

[0001437749-26-018542:notes:315]
The accounting policies of the business segments are the same as those for the consolidated Company. The Company’s business segments have been determined in accordance with the Company’s internal management structure, which is organized based on operating activities. The Company evaluates performance based upon several factors, of which the primary financial measures are segment revenues and segment operating loss. The disaggregated financial results of the segments reflect allocation of certain functional expense categories consistent with the basis and manner in which Company management internally disaggregates financial information for the purpose of assisting in making internal operating decisions.

[0001437749-26-018542:notes:316]
Geographic information about property, plant and equipment associated with particular regions is as follows (in thousands):

[0001437749-26-018542:notes:317]
|  |  | March 31, |  |
|  |  | 2026 |  |  | 2025 |  |
| North America |  | $ | 36,521 |  |  | $ | 37,426 |  |
| Europe |  |  | 1,722 |  |  |  | 1,097 |  |
| Asia Pacific |  |  | 38 |  |  |  | 49 |  |
| South America |  |  | 51,494 |  |  |  | — |  |
| Total |  | $ | 89,775 |  |  | $ | 38,572 |  |


## us-gaap:NewAccountingPronouncementsAndChangesInAccountingPrinciplesTextBlock

[0001437749-26-018542:notes:318]
21. Recent Accounting Pronouncements

[0001437749-26-018542:notes:319]
In  December 2023, the FASB issued ASU 2023-09, Income Taxes (Topic 740): Improvements to Income Tax Disclosures. The amendments in ASU 2023-09 address investor requests for more transparency about income tax information through improvements to income tax disclosures primarily related to the rate reconciliation and income taxes paid information. Following the release of ASU 2023-09 in  December 2023, the effective date will be annual reporting periods beginning after  December 15, 2024. As of  March 31, 2025, the Company has adopted ASU 2023-09 and made the required disclosures, and noted no other material impact on its consolidated financial statements.

[0001437749-26-018542:notes:320]
In  March 2024, the FASB issued ASU 2024-02, Codification Improvements—Amendments to Remove References to the Concepts Statements. The amendments in ASU 2024-02 contain amendments to the Codification that remove references to various FASB Concepts Statements. Following the release of ASU 2024-02 in  March 2024, the effective date will be annual reporting periods beginning after  December 15, 2024. As of  March 31, 2026, the Company has adopted ASU 2024-02 and noted no other material impact on its consolidated financial statements.

[0001437749-26-018542:notes:321]
In  November 2024, the FASB issued ASU 2024-03, Income Statement—Reporting Comprehensive Income—Expense Disaggregation Disclosures. The amendments in ASU 2024-03 address investor requests for more disclosure of disaggregated financial reporting information about expenses presented in the income statement. Following the release of ASU 2024-03 in  November 2024, the effective date will be annual reporting periods beginning after  December 15, 2026. The Company is evaluating the impact on its consolidated financial statements.

[0001437749-26-018542:notes:322]
In  July 2025, the FASB issued ASU 2025-05, Financial Instruments—Credit Losses. The amendments in ASU 2025-05 contain updates to how entities are permitted to estimate expected credit losses for accounts receivable and contract assets. Following the release of ASU 2025-05 in  July 2024, the effective date will be annual reporting periods beginning after  December 15, 2025. As of  April 1, 2025, the Company early adopted ASU 2025-05 and noted no material impact on its consolidated financial statements.

[0001437749-26-018542:notes:323]
In  November 2025, the FASB issued ASU 2025-08, Financial Instruments — Credit Losses: Purchased Loans. The amendments in ASU 2025-08 requires that loans acquired without credit deterioration and deemed “seasoned” will be considered purchased seasoned loans and accounted for using the gross-up approach at acquisition. Following the release of ASU 2025-08 in  November 2025, the effective date will be annual reporting periods beginning after  December 15, 2026. As of  April 1, 2025, the Company early adopted ASU2025-08 and noted no material impact on its consolidated financial statements.


## us-gaap:SubsequentEventsTextBlock

[0001437749-26-018542:notes:324]
22. Subsequent Events

[0001437749-26-018542:notes:325]
The Company has performed an evaluation of subsequent events through the time of filing this Annual Report on Form 10-K with the SEC,  On  May 15, 2026, pursuant to the terms of the Stock Exchange Agreement, Comtrafo purchased a certain real estate asset from the selling stockholders that Comtrafo was leasing and using for administrative and manufacturing operations for 37.2 million Brazilian Real in cash. Other than the above, management has determined that there are no such events to report.


## ecd:MtrlTermsOfTrdArrTextBlock

[0001437749-26-018542:notes:326]
| Item 9B. | OTHER INFORMATION |

[0001437749-26-018542:notes:327]
(a) None.

[0001437749-26-018542:notes:328]
(b) During the three months ended  March 31, 2026, no director or officer of the Company adopted or terminated a "Rule 10b5-1 trading arrangement" or "non Rule 10b5-1 trading arrangement," as each term is defined in Item 408(a) of Regulation S-K, except for the following:

[0001437749-26-018542:notes:329]
On  February 26, 2026, Daniel P. McGahn, Chairman, President, and Chief Executive Officer modified an existing Rule 10b5-1 trading arrangement intended to satisfy the affirmative defense conditions of Rule 10b5-1(c) under the Exchange Act. As modified, the trading plan covers up to 241,282 shares of the Company's common stock and remains in effect until the earlier of (i)  August 14, 2026, or (ii) the date on which all shares under the arrangement are sold.
