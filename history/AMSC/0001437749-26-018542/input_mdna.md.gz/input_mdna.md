# AMSC MD&A — 0001437749-26-018542


## mdna

[0001437749-26-018542:mdna:1]
| Item 7. | MANAGEMENT'S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS |

[0001437749-26-018542:mdna:2]
Executive Overview

[0001437749-26-018542:mdna:3]
Guided by a belief in the power of next, we are a leading provider of power control solutions that apply innovation and creativity to address today’s challenges and enable a more resilient and sustainable energy future. Driven by our purpose “to power progress,” we integrate future-facing technologies to balance the growing global demand for power with the need for reliable, and efficient power delivery. Our advanced grid systems, engineering services, power electronics, software controls, and superconductor-based solutions help the traditional and renewable energy sectors, electric utilities, the materials and mining sector, industrial facilities, and other critical infrastructure operators optimize network reliability, improve power quality, alleviate grid constraints, and scale operations without added complexity or size.

[0001437749-26-018542:mdna:4]
We also deliver ship protection and power management solutions that enhance fleet efficiency, survivability, and operational readiness for the U.S. Navy and allied fleets. In the wind power market, we provide advanced electrical control systems, engineering, and support services that help manufacturers lower the cost of wind energy and improve turbine performance. Beyond these markets, we provide industrial process, environmental and emission control capabilities that support operational efficiency across the broader energy infrastructure. Across our businesses, our solutions are helping optimize power networks, strengthen naval capabilities, and support gigawatts of renewable energy generation worldwide as governments and industries continue investing in more resilient, secure, and sustainable power systems.

[0001437749-26-018542:mdna:5]
We operate our business under two market-facing business segments: Grid and Wind. We believe this market centric structure enables us to more effectively anticipate and meet the needs of power generators, power utilities, industrial manufacturers, the military and renewable energy companies.

[0001437749-26-018542:mdna:6]
|  | • | Grid. Our Grid business segment enables electric utilities, industrial facilities, and traditional and renewable energy project developers to connect, transmit, transform and distribute power with exceptional efficiency, reliability, security and affordability. We provide transmission planning services that allow us to identify power grid congestion, poor power quality, and other risks, which help us determine how our solutions can improve network performance. These services often lead to sales of our grid interconnection solutions for wind farms and solar power plants, power quality systems and transmission and distribution cable systems. We also sell critical shipyard infrastructure power solutions, ship power supplies and ship protection products to U.S. and allied Navies through our Grid business segment. |

[0001437749-26-018542:mdna:7]
|  | • | Wind. Our Wind business segment enables manufacturers to field wind turbines with exceptional power output, reliability and affordability. We supply advanced power electronics and control systems, license our highly engineered wind turbine designs, and provide extensive customer support services to wind turbine manufacturers. Our design portfolio includes a broad range of drivetrains and power ratings of 2 megawatts ("MWs") and higher. We provide a broad range of power electronics and software-based control systems that are highly integrated and designed for optimized performance, efficiency, and grid compatibility. |

[0001437749-26-018542:mdna:8]
Our fiscal year begins on April 1 and ends on March 31. When we refer to a particular fiscal year, we are referring to the fiscal year that began on April 1 of that same year. For example, fiscal 2025 refers to the fiscal year that began on April 1, 2025. Other fiscal years follow similarly.

[0001437749-26-018542:mdna:9]
Changes in macroeconomic conditions arising from various reasons, such as the ongoing wars between Russia and Ukraine, and in the Middle East, tariffs, trade restrictions and resulting trade conflicts, labor force availability, sourcing, material delays and global supply chain disruptions could have a material adverse effect on our business, financial condition and results of operations.

[0001437749-26-018542:mdna:10]
On December 5, 2025 (the "Comtrafo Acquisition Date"), we entered into a Stock Exchange Agreement (the "Stock Exchange Agreement") with the selling stockholders named therein. Pursuant to the terms of the Stock Exchange Agreement, Mardin Participações Ltda., an entity incorporated in Brazil (“AMSC Brazil”) and our wholly-owned subsidiary, directly or indirectly, purchased all of the issued and outstanding shares of Comtrafo Indústria de Transformadores Elétricos S.A. ("Comtrafo") (the "Comtrafo Acquisition") for (a) (i) 300.0 million Brazilian Real in cash; and (b) 2,417,142 restricted shares of our common stock, $0.01 par value per share (the "AMSC Shares") that were paid and issued, respectively, at closing. In addition, pursuant to certain additional real property agreements, AMSC Brazil through Comtrafo purchased certain real estate assets and transportation assets of Comtrafo for 155.6 million Brazilian Real and 13.4 million Brazilian Real, respectively, in cash. Additionally, AMSC Brazil has agreed to pay the selling stockholders up to an additional 382.5 million Brazilian Real in cash (the "Earnout") upon the achievement of specified earnings before interest, taxes, depreciation, and amortization ("EBITDA") objectives during the three years following the closing. On May 15, 2026, pursuant to the terms of the Stock Exchange Agreement, Comtrafo purchased a certain real estate asset from the selling stockholders that Comtrafo was leasing and using for administrative and manufacturing operations for 37.2 million Brazilian Real in cash. Comtrafo is a Brazil-based manufacturer of large power and distribution transformers primarily for utility customers and also for industrial customers.

[0001437749-26-018542:mdna:11]
On August 1, 2024, we entered into a Stock Purchase Agreement (the “Stock Purchase Agreement”) with the selling stockholders named therein. Pursuant to the terms of the Stock Purchase Agreement and concurrently with entering into such agreement, we acquired all of the issued and outstanding shares of Megatran, Industries, Inc. ("Megatran"), for aggregate consideration in an amount equal to $61.4 million, as may be adjusted pursuant to the Stock Purchase Agreement (the “Purchase Price”), including a cash payment after closing of $5.0 million, as adjusted pursuant to Sections 5.6(c), (d), and (f) of the Stock Purchase Agreement (the “Additional Cash Purchase Price”). At closing, we paid to Megatran's selling stockholders $25.0 million in cash on hand, and 1,297,600 restricted shares of our common stock. On September 23, 2024, we paid the Additional Cash Purchase Price to the selling stockholders, which was calculated based on the agreed upon formula set forth in the Stock Purchase Agreement, in the amount of $8.3 million which includes the Additional Cash Purchase Price and the make whole payment. Megatran's wholly-owned subsidiary, NWL, Inc. (together with Megatran, "NWL"), is a U.S.-based global provider of engineered power conversion solutions for demanding industrial and military applications.  As a result of this transaction, Megatran became a wholly-owned subsidiary and is operated by our Grid business segment. We refer to this transaction as the "acquisition of NWL".

[0001437749-26-018542:mdna:12]
Results of Operations

[0001437749-26-018542:mdna:13]
A discussion regarding our financial condition and results of operations for the year ended March 31, 2026 compared to the year ended March 31, 2025 is presented below. A discussion regarding our financial condition and results of operations for year ended  March 31, 2025 compared to March 31, 2024 is included under "Management's Discussion and Analysis of Financial Condition and Results of Operations" in our Annual Report on Form 10-K for the year ended March 31, 2025 filed with the SEC on May 21, 2025.

[0001437749-26-018542:mdna:14]
Fiscal Years Ended March 31, 2026 and March 31, 2025

[0001437749-26-018542:mdna:15]
Revenues

[0001437749-26-018542:mdna:16]
Total revenues increased by 34% to $299.2 million in fiscal 2025 from $222.8 million in fiscal 2024. Our revenues are summarized as follows (in thousands):

[0001437749-26-018542:mdna:17]
|  |  | Fiscal Years Ended March 31, |  |
|  |  | 2026 |  |  | 2025 |  |
| Revenues: |  |  |  |  |  |  |  |  |
| Grid |  | $ | 251,317 |  |  | $ | 187,170 |  |
| Wind |  |  | 47,838 |  |  |  | 35,648 |  |
| Total |  | $ | 299,155 |  |  | $ | 222,818 |  |

[0001437749-26-018542:mdna:18]
Revenues in our Grid business segment are derived from our D-VAR product sales, Northeast Power Systems, Inc. ("NEPSI") product sales, Neeltran, Inc. ("Neeltran") product sales, NWL product sales, Comtrafo product sales, HTS wire sales, ship protection systems ("SPS"), government-sponsored electric utility projects and other prototype development contracts. We also engineer, install and commission our products on a turnkey-basis for some customers. The Grid business segment accounted for 84% of total revenues in both fiscal 2025 and 2024. Grid revenues increased 34% to $251.3 million in fiscal 2025 from $187.2 million in fiscal 2024. The increase in revenues was driven by higher new energy power systems revenues, higher ship protection systems revenues, and the contribution from the acquisition of Comtrafo in fiscal 2025.

[0001437749-26-018542:mdna:19]
Revenues in our Wind business segment are derived from wind turbine electrical control systems and core components, wind turbine license and development contracts, service contracts and consulting arrangements. Our Wind business segment accounted for 16% of total revenues in both fiscal 2025 and 2024. Revenues in the Wind business segment increased 34% to $47.8 million in fiscal 2025 from $35.6 million in fiscal 2024. The increase over the prior year period was driven by additional shipments of electrical control systems ("ECS") in fiscal 2025.

[0001437749-26-018542:mdna:20]
Cost of Revenues and Gross Margin

[0001437749-26-018542:mdna:21]
Cost of revenues increased by 29% to $207.8 million in fiscal 2025, compared to $161.0 million in fiscal 2024. Gross margin increased to 31% in fiscal 2025 from 28% in fiscal 2024. Cost of revenues include total amortization expense of $0.6 million in the fiscal year ended March 31, 2026 as a result of Comtrafo acquired backlog intangible assets. In addition, $0.8 million related to a fair value adjustment for the step-up basis assigned to acquired inventory to properly reflect the fair value in purchase accounting was charged to cost of revenues in the fiscal year ended March 31, 2026. The increase in gross margin in fiscal 2025 was due to higher revenues and a beneficial product mix in the Grid and Wind business segments.

[0001437749-26-018542:mdna:22]
Operating Expenses

[0001437749-26-018542:mdna:23]
Research and development

[0001437749-26-018542:mdna:24]
Research and development (“R&D”) expenses increased by 38% to $15.7 million, or 5% of revenue in fiscal 2025, compared to $11.4 million, or 5% of revenue, in fiscal 2024. The increase in R&D expenses is primarily a result of additional compensation and stock compensation expenses in fiscal 2025.

[0001437749-26-018542:mdna:25]
Selling, general, and administrative

[0001437749-26-018542:mdna:26]
Selling, general and administrative (“SG&A”) expenses increased by 34% to $57.6 million, or 19% of revenue in fiscal 2025 from $43.1 million, or 19% of revenue, in fiscal 2024. The increase in SG&A expenses is primarily a result of the addition of Comtrafo operating expenses and additional compensation and stock compensation expenses in fiscal 2025.

[0001437749-26-018542:mdna:27]
Amortization of acquisition related intangibles

[0001437749-26-018542:mdna:28]
We recorded $2.4 million in fiscal 2025 and $1.7 million in fiscal 2024 in amortization expense related to our core technology and know-how, customer relationships, and other intangible assets. The increase in amortization expense is primarily a result of additional amortization related to the Comtrafo acquisition.

[0001437749-26-018542:mdna:29]
Change in fair value of contingent consideration

[0001437749-26-018542:mdna:30]
The change in fair value of our contingent consideration for the earnout payment on the acquisition of Comtrafo resulted in a loss of $
   4.2 million from an increase in fair value of the contingent consideration in fiscal
   2025.

[0001437749-26-018542:mdna:31]
The change in fair value of our contingent consideration for the earnout payment on the acquisition of NEPSI resulted in a loss of $3.4 million resulting from an increase in fair value in fiscal 2024. During fiscal 2024, we issued 300,000 shares of our common stock to the selling stockholders following certification of the achievement of specified earnout revenue objectives. We also recorded a $3.3 million payment relating to the acquisition of NWL, as a payment to settle the remaining obligations after the acquisition.

[0001437749-26-018542:mdna:32]
Operating income (loss)

[0001437749-26-018542:mdna:33]
Our operating income (loss) is summarized as follows (in thousands):

[0001437749-26-018542:mdna:34]
|  |  | Fiscal Years Ended March 31, |  |
|  |  | 2026 |  |  | 2025 |  |
| Operating income (loss): |  |  |  |  |  |  |  |  |
| Grid |  | $ | 8,468 |  |  | $ | 1,812 |  |
| Wind |  |  | 7,149 |  |  |  | 3,792 |  |
| Unallocated corporate expenses |  |  | (4,171 | ) |  |  | (6,681 | ) |
| Total |  | $ | 11,445 |  |  | $ | (1,077 | ) |

[0001437749-26-018542:mdna:35]
Our Grid business segment generated operating income of $8.5 million in fiscal 2025 and $1.8 million in fiscal 2024. The improvement in the Grid business segment operating income was due to higher revenues and improved gross margins in fiscal 2025.

[0001437749-26-018542:mdna:36]
The Wind segment generated operating income of $7.1 million in fiscal 2025 and $3.8 million in fiscal 2024. The increase in the Wind business segment operating income was due to higher revenues and improved gross margins in fiscal 2025.

[0001437749-26-018542:mdna:37]
Unallocated corporate expenses consisted of a loss on contingent consideration of $4.2 million in fiscal 2025 and $6.7 million in fiscal 2024.

[0001437749-26-018542:mdna:38]
Interest income, net

[0001437749-26-018542:mdna:39]
Interest income, net was $6.4 million in fiscal 2025 compared to $3.7 million for fiscal 2024. The increase in interest income, net, was primarily due to higher cash balances generating additional interest income in fiscal 2025.

[0001437749-26-018542:mdna:40]
Other expense, net

[0001437749-26-018542:mdna:41]
Other expense, net was $1.1 million in fiscal 2025, compared to $0.3 million in fiscal 2024. The increase in other expense, net was driven by unfavorable fluctuations in foreign exchange rates, resulting in translation losses.

[0001437749-26-018542:mdna:42]
Income Taxes

[0001437749-26-018542:mdna:43]
We recorded an income tax benefit of $117.1 million in fiscal 2025, compared to $3.7 million in fiscal 2024. The net impact to income tax is primarily a result of a non-cash tax benefit from the release of the majority of our valuation allowance against deferred tax assets due to a change in facts and circumstances that impact our conclusion on realizability of such assets.

[0001437749-26-018542:mdna:44]
Net income

[0001437749-26-018542:mdna:45]
Net income was $133.8 million in fiscal 2025, compared to $6.0 million in fiscal 2024. The improvement in net income was driven primarily by the non-cash tax benefit from the release of the majority of our valuation allowance against deferred tax assets, higher revenues and improved gross margins in fiscal 2025.

[0001437749-26-018542:mdna:46]
Please refer to the “Risk Factors” section in Part I, Item 1A, for a discussion of certain factors that may affect our future results of operations and financial condition.

[0001437749-26-018542:mdna:47]
Non-GAAP Financial Measure - Non-GAAP Net Income and Non-GAAP Net Income Per Share

[0001437749-26-018542:mdna:48]
Generally, a non-GAAP financial measure is a numerical measure of a company’s performance, financial position or cash flow that either excludes or includes amounts that are not normally excluded or included in the most directly comparable measure calculated and presented in accordance with generally accepted accounting principles in the United States (“GAAP”). The non-GAAP measures included in this Form 10-K, however, should be considered in addition to, and not as a substitute for or superior to the comparable measure prepared in accordance with GAAP.

[0001437749-26-018542:mdna:49]
We define non-GAAP net income as net income (loss) before stock-based compensation, amortization of acquisition-related intangibles, change in fair value of contingent consideration, acquisition costs, and other non-cash or unusual charges. We believe non-GAAP net income assists management and investors in comparing our performance across reporting periods on a consistent basis by excluding these non-cash charges and other items that we do not believe are indicative of our core operating performance. In addition, we use non-GAAP net income as a factor to evaluate the effectiveness of our business strategies. A reconciliation of GAAP net income to non-GAAP net income (loss) is set forth in the table below (in thousands, except per share data):

[0001437749-26-018542:mdna:50]
|  |  | Year ended March 31, |  |
|  |  | 2026 |  |  | 2025 |  |  | 2024 |  |
| Net income (loss) |  | $ | 133,809 |  |  | $ | 6,033 |  |  | $ | (11,111 | ) |
| Stock-based compensation |  |  | 15,869 |  |  |  | 7,794 |  |  |  | 4,652 |  |
| Amortization of acquisition-related intangibles |  |  | 3,024 |  |  |  | 2,433 |  |  |  | 2,158 |  |
| Change in fair value of contingent consideration |  |  | 4,171 |  |  |  | 6,682 |  |  |  | 4,922 |  |
| Acquisition costs |  |  | 1,243 |  |  |  | 1,095 |  |  |  | — |  |
| Non-GAAP net income |  | $ | 158,116 |  |  | $ | 24,037 |  |  | $ | 621 |  |
| Non-GAAP net income per share - basic |  | $ | 3.68 |  |  | $ | 0.65 |  |  | $ | 0.02 |  |
| Non-GAAP net income per share - diluted |  | $ | 3.60 |  |  | $ | 0.64 |  |  | $ | 0.02 |  |
| Weighted average shares outstanding - basic |  |  | 42,945 |  |  |  | 36,990 |  |  |  | 29,825 |  |
| Weighted average shares outstanding - diluted |  |  | 43,902 |  |  |  | 37,718 |  |  |  | 30,909 |  |

[0001437749-26-018542:mdna:51]
Non-GAAP net income was $158.1 million, or $3.68 per share, for fiscal 2025, compared to $24.0 million, or $0.65 per share, for fiscal 2024 and $0.6 million, or $0.02 per share, for fiscal 2023. The improvement in non-GAAP net income in fiscal 2025 compared to fiscal 2024 was due primarily to the non-cash tax benefit from the release of the majority of our valuation allowance against deferred income tax assets, and improved operating margin in the Wind and Grid business segments.

[0001437749-26-018542:mdna:52]
Liquidity and Capital Resources

[0001437749-26-018542:mdna:53]
The Company’s primary sources of liquidity are internally generated cash provided by operating activities, our cash and cash equivalents on hand, along with access to capital markets. The Company believes that these sources of liquidity provide adequate liquidity to meet both its short-term and reasonably foreseeable long-term requirements and obligations. At March 31, 2026, we had cash, cash equivalents and restricted cash of $147.6 million, compared to $85.4 million at March 31, 2025, an increase of $62.2 million. As of March 31, 2026, we had approximately $17.8 million in cash, cash equivalents and restricted cash in foreign bank accounts. Our cash, cash equivalents and restricted cash are summarized as follows (in thousands):

[0001437749-26-018542:mdna:54]
|  |  | March 31, 2026 |  |  | March 31, 2025 |  |
| Cash and cash equivalents |  | $ | 140,693 |  |  | $ | 79,494 |  |
| Restricted cash |  |  | 6,860 |  |  |  | 5,887 |  |
| Total cash, cash equivalents and restricted cash |  | $ | 147,553 |  |  | $ | 85,381 |  |

[0001437749-26-018542:mdna:55]
42

[0001437749-26-018542:mdna:56]
Net cash provided by operating activities was $23.1 million, $28.3 million and $2.1 million in fiscal 2025, 2024, and 2023, respectively. The decrease in net cash provided by operations in fiscal 2025 compared to fiscal 2024 was due primarily to changes in deferred revenue and accounts receivable, offset by changes in accounts payable and accrued expenses, deferred income taxes, changes in fair value of contingent consideration and stock-based compensation expense. The increase in net cash provided by operations in fiscal 2024 compared to fiscal 2023 was driven primarily by higher gross margins, favorable changes in accounts payable and accrued expenses, relief of deferred revenues, increased non-cash expenses like stock compensation, depreciation and amortization, and change in fair value of contingent consideration, offset by decreased cash collections, increased prepaid balances, and change in deferred income taxes.

[0001437749-26-018542:mdna:57]
Net cash used in investing activities was $77.1 million, $35.2 million, and $1.0 million in fiscal 2025, 2024, and 2023, respectively. The increase in net cash used in investing activities in fiscal 2025 compared to fiscal 2024 was primarily due to cash paid for the Comtrafo acquisition in the current fiscal year. The increase in net cash used in investing activities in fiscal 2024 compared to fiscal 2023 was due primarily to cash paid for the acquisition of NWL.

[0001437749-26-018542:mdna:58]
Net cash provided by financing activities was $116.1 million compared to less than $0.1 million and $65.4 million in fiscal 2025, 2024, and 2023, respectively. The increase in cash provided by financing activities in fiscal 2025 compared to fiscal 2024 was primarily related to net proceeds received from an equity offering in June 2025. The decrease in cash provided by financing activities in fiscal 2024 compared to fiscal 2023 was primarily related to net proceeds received from an equity offering in fiscal 2023, while the company had no equity offerings in fiscal 2024.

[0001437749-26-018542:mdna:59]
At March 31, 2026, we had $3.3 million of restricted cash included in long-term assets and $3.5 million of restricted cash in current assets. At March 31, 2025, we had $4.3 million of restricted cash included in long-term assets and $1.6 million of restricted cash in current assets. These amounts included in restricted cash primarily represent collateral deposits to secure surety bonds and letters of credit for various customer contracts. These deposits are held in interest bearing accounts.

[0001437749-26-018542:mdna:60]
On the Comtrafo Acquisition Date, we entered into the Stock Exchange Agreement with the selling stockholders. Pursuant to the terms of the Stock Exchange Agreement, AMSC Brazil, directly or indirectly, purchased all of the issued and outstanding shares of Comtrafo for (a) (i) 300.0 million Brazilian Real in cash; and (b) AMSC Shares that were paid and issued, respectively, at closing. In addition, pursuant to certain additional real property agreements, AMSC Brazil through Comtrafo purchased certain real estate assets and transportation assets of Comtrafo for 155.6 million Brazilian Real and 13.4 million Brazilian Real, respectively, in cash. Additionally, AMSC Brazil has agreed to pay the Stockholders the Earnout upon the achievement of specified EBITDA objectives during the three years following the closing. Comtrafo is a Brazil-based manufacturer of large power and distribution transformers primarily for utility customers and also for industrial customers.

[0001437749-26-018542:mdna:61]
In June 2025, we completed an offering of 4,743,750 shares of our common stock at a public offering price of $28.00 per share under our Registration Statement on Form S-3. We received aggregate net proceeds of approximately $124.6 million after deducting underwriting discounts and commissions and offering expenses.

[0001437749-26-018542:mdna:62]
On August 1, 2024, we entered into the Stock Purchase Agreement with the selling stockholders named therein. Pursuant to the terms of the Stock Purchase Agreement and concurrently with entering into such agreement, we acquired all of the issued and outstanding shares of Megatran, for the purchase price of $61.4 million, which consideration amount was subject to various adjustments set forth in the Stock Purchase Agreement (including those described below) and consisted of: (a) (i) $25.0 million, minus (ii) the Indebtedness (as defined in the Stock Purchase Agreement) outstanding as of immediately prior to the closing, minus (iii) Company Expenses (as defined in the Stock Purchase Agreement); (b) a number of restricted shares (rounded up or down to the nearest whole share, as applicable) of our common stock equal to the quotient obtained by dividing (x) $31.4 million by (y) the closing price per share of our common stock on the Nasdaq Global Select Market on the last trading day immediately preceding the Acquisition Date; and (c) an additional cash payment equal to $5.0 million, as adjusted pursuant to Sections 5.6(c), (d), and (f) of the Stock Purchase Agreement. Megatran is now a wholly-owned subsidiary of the Company and, together with its wholly-owned subsidiaries and affiliates, is operated and reported as a component of its Grid business segment. On September 23, 2024, the Company paid $3.3 million to the selling stockholders, which was calculated based on the agreed upon formula set forth in the Stock Purchase Agreement. As of March 31, 2025, there are no remaining obligations to the selling stockholders of Megatran.

[0001437749-26-018542:mdna:63]
In January 2024, we filed a shelf registration statement on Form S-3 that will expire three years from the date on which it was declared effective, March 15, 2027 (the “Form S-3”). The Form S-3 allows us to offer and sell from time-to-time up to $250 million of common stock, debt securities, warrants or units comprised of any combination of these securities. The Form S-3 is intended to provide us flexibility to conduct registered sales of our securities, subject to market conditions, in order to fund our future capital needs. The terms of any future offering under the Form S-3 will be established at the time of such offering and will be described in a prospectus supplement filed with the SEC prior to the completion of any such offering.

[0001437749-26-018542:mdna:64]
In August 2024, the Company filed an automatically-effective shelf registration statement on Form S-3 that will expire no later than August 12, 2027 (the “Second Form S-3”). The Second Form S-3 allows the Company to offer and sell from time-to-time unspecified amounts of common stock, debt securities, warrants or units comprised of any combination of these securities and allows certain selling stockholders to offer and sell from time-to-time common stock. The Second Form S-3 assisted the Megatran selling stockholders in the resale of their common stock and register the Comtrafo selling stockholder's AMSC shares, and is intended to provide the Company flexibility to conduct registered sales of its securities, subject to market conditions, in order to fund its future capital needs. The terms of any future offering under the Second Form S-3 will be established at the time of such offering and will be described in a prospectus supplement filed with the SEC prior to the completion of any such offering.

[0001437749-26-018542:mdna:65]
We are a party to many contractual obligations involving commitments to make payments to third parties. These obligations impact our short-term and long-term liquidity and capital resource needs. Certain contractual obligations are reflected on the consolidated balance sheet as of March 31, 2026, while others are considered future commitments. We have various contractual arrangements, under which we have committed to purchase certain minimum quantities of goods or services on an annual basis. For information regarding our other contractual obligations, refer to Note 13, "Contingent Consideration," Note 16, "Leases", and Note 18, "Commitments and Contingencies" to our consolidated financial statements included elsewhere in this Annual Report on Form 10-K.

[0001437749-26-018542:mdna:66]
We believe we have sufficient available liquidity to fund our operations and capital expenditures for at least the next twelve months. We may seek to raise additional capital, which could be in the form of loans, convertible debt or equity, to fund our operating requirements and capital expenditures. There can be no assurance that we will be able to raise additional capital on favorable terms or at all or execute on any other means of improving our liquidity as described above. Additionally, the impact of global sources of instability, including tariffs, trade restrictions and resulting trade conflicts, the ongoing wars between Russia and Ukraine and in the Middle East, instability of financial institutions and political instability in the United States, on the global financial markets may reduce our ability to raise additional capital, if necessary, which could negatively impact our liquidity. In addition, the current interest rate environment may affect the cost and availability of debt financing for future acquisitions or other capital needs. While we funded our recent acquisitions primarily with cash on hand and equity, we may seek to use debt financing for future transactions, and higher interest rates could increase the cost of such financing or make certain transactions less attractive.

[0001437749-26-018542:mdna:67]
Legal Proceedings

[0001437749-26-018542:mdna:68]
From time to time, we are involved in legal and administrative proceedings and claims of various types. We record a liability in our consolidated financial statements for these matters when a loss is known or considered probable and the amount can be reasonably estimated. We review these estimates each accounting period as additional information is known and adjust the loss provision when appropriate. If a matter is both probable to result in liability and the amounts of loss can be reasonably estimated, we estimate and disclose the possible loss or range of loss to the extent necessary to make the consolidated financial statements not misleading. If the loss is not probable or cannot be reasonably estimated, a liability is not recorded in our consolidated financial statements.

[0001437749-26-018542:mdna:69]
Recent Accounting Pronouncements

[0001437749-26-018542:mdna:70]
In December 2023, the FASB issued ASU 2023-09, Income Taxes (Topic 740): Improvements to Income Tax Disclosures. The amendments in ASU 2023-09 address investor requests for more transparency about income tax information through improvements to income tax disclosures primarily related to the rate reconciliation and income taxes paid information. Following the release of ASU 2023-09 in December 2023, the effective date will be annual reporting periods beginning after December 15, 2024. As of March 31, 2026, we have adopted ASU 2023-09, made the required disclosures, and noted no other material impact on our consolidated financial statements.

[0001437749-26-018542:mdna:71]
In March 2024, the FASB issued ASU 2024-02, Codification Improvements—Amendments to Remove References to the Concepts Statements. The amendments in ASU 2024-02 contain amendments to the Codification that remove references to various FASB Concepts Statements. Following the release of ASU 2024-02 in March 2024, the effective date will be annual reporting periods beginning after December 15, 2024. As of March 31, 2026, we have adopted ASU 2024-02 and noted no other material impact on our consolidated financial statements.

[0001437749-26-018542:mdna:72]
In November 2024, the FASB issued ASU 2024-03, Income Statement—Reporting Comprehensive Income—Expense Disaggregation Disclosures. The amendments in ASU 2024-03 address investor requests for more disclosure of disaggregated financial reporting information about expenses presented in the income statement. Following the release of ASU 2024-03 in November 2024, the effective date will be annual reporting periods beginning after December 15, 2026. We are evaluating the impact on our consolidated financial statements.

[0001437749-26-018542:mdna:73]
In July 2025, the FASB issued ASU 2025-05, Financial Instruments—Credit Losses. The amendments in ASU 2025-05 contain updates to how entities are permitted to estimate expected credit losses for accounts receivable and contract assets. Following the release of ASU 2025-05 in July 2024, the effective date will be annual reporting periods beginning after December 15, 2025. As of April 1, 2025, we early adopted ASU 2025-05 and noted no material impact on our consolidated financial statements.

[0001437749-26-018542:mdna:74]
In November 2025, the FASB issued ASU 2025-08, Financial Instruments — Credit Losses: Purchased Loans. The amendments in ASU 2025-08 requires that loans acquired without credit deterioration and deemed “seasoned” will be considered purchased seasoned loans and accounted for using the gross-up approach at acquisition. Following the release of ASU 2025-08 in November 2025, the effective date will be annual reporting periods beginning after December 15, 2026. As of April 1, 2025, we early adopted ASU 2025-08 and noted no material impact on our consolidated financial statements.

[0001437749-26-018542:mdna:75]
We do not believe that, outside of those disclosed here, there are any other recently issued accounting pronouncements that will have a material impact on our consolidated financial statements.

[0001437749-26-018542:mdna:76]
Critical Accounting Policies and Estimates

[0001437749-26-018542:mdna:77]
The preparation of the consolidated financial statements requires that we make estimates and judgments that affect the reported amounts of assets, liabilities, revenues and expenses, and related disclosure of contingent assets and liabilities. We base our estimates on historical experience and various other assumptions that are believed to be reasonable under the circumstances, the results of which form the basis for making judgments about the carrying values of assets and liabilities that are not readily apparent from other sources. Actual results may differ under different assumptions or conditions. Our accounting policies that involve the most significant judgments and estimates are as follows:

[0001437749-26-018542:mdna:78]
Revenue recognition

[0001437749-26-018542:mdna:79]
For certain arrangements, such as contracts to perform research and development, prototype development contracts and certain customized product sales, we record revenues using the over-time method, measured by the relationship of costs incurred to total estimated contract costs. Over-time revenue recognition accounting is predominantly used on certain turnkey power systems installations for electric utilities and long-term prototype development contracts with the U.S. government.

[0001437749-26-018542:mdna:80]
Significant judgement is required to estimate the total expected costs for projects that typically have a timeline of 12-24 months. Any increase or decrease in estimated costs to complete a performance obligation without a corresponding change to the contract price could impact the calculation of cumulative revenue to date and gross profit on the project. Factors that may result in a change to our estimate include delays in manufacturing, unforeseen engineering problems, the performance of subcontractors and material suppliers, among others.

[0001437749-26-018542:mdna:81]
We have a long history of working with multiple types of projects and preparing cost estimates, and we rely on the expertise of key personnel to prepare what we believe are reasonable best estimates given available facts and circumstances. Due to the nature of the work involved, however, judgment is involved to estimate the total costs to complete, and the amounts estimated could have a material impact on the revenue we recognize in each accounting period. We cannot estimate unforeseen events and circumstances which may result in actual results being materially different from previous estimates.

[0001437749-26-018542:mdna:82]
See Note 4, “Revenue Recognition,” for additional information.

[0001437749-26-018542:mdna:83]
Business Acquisitions

[0001437749-26-018542:mdna:84]
We account for acquisitions using the purchase method of accounting in accordance with Accounting Standards Codification ("ASC") 805, Business Combinations. The purchase price for each acquisition is allocated to the assets acquired and liabilities assumed based on their estimated fair values at the date of acquisition. The excess purchase price over the estimated fair value of the net assets acquired and liabilities assumed is recorded as goodwill. Intangible assets, if identified, are also recorded.

[0001437749-26-018542:mdna:85]
Determining the fair value of certain assets and liabilities assumed is judgmental in nature and often involves the use of significant estimates and assumptions as well as the use of specialists as needed. The Company utilizes management estimates and an independent third-party valuation firm to assist in determining the fair values of assets acquired, including intangible assets and liabilities assumed. The primary intangible assets acquired include customer relationship. Intangible assets are initially valued using a methodology commensurate with the intended use of the asset. The fair value of customer relationships is measured using the multi-period excess earnings method (“MPEEM”). The basis for future sales projections for both the MPEEM and RFR are based on internal revenue forecasts which the Company believes represents reasonable market participant assumptions. The future cash flows are discounted using an applicable discount rate. The key uncertainties in the calculations, as applicable, are assumptions used in developing estimates of future cash flows, including revenue growth and expense forecasts, assumed customer attrition rates, as well as perceived risks associated with those forecasts in determining the discount rate. There is inherent uncertainty in forecasted cash flows and therefore, actual results may differ and could result in a subsequent impairment charge of acquired intangibles and/or goodwill.

[0001437749-26-018542:mdna:86]
The consideration for our acquisitions may include future payments that are contingent upon the occurrence of a particular event. We record a contingent consideration obligation for such contingent consideration payments at fair value on the acquisition date. We estimate the fair value of contingent consideration obligations through valuation models that incorporate probability adjusted assumptions related to the achievement of the milestones, the likelihood of making related payments, the EBITDA volatility, and the discount rate. Significant judgment is employed in determining these assumptions as of the acquisition date and for each subsequent period. Accordingly, future business and economic conditions, as well as changes in any of the assumptions described above, can materially impact the fair value of contingent consideration recorded at each reporting period.

[0001437749-26-018542:mdna:87]
Goodwill

[0001437749-26-018542:mdna:88]
Goodwill represents the excess of cost over net assets of acquired businesses that are consolidated. We perform our annual assessment of goodwill on February 28th of each fiscal year and whenever events or changes in circumstances or a triggering event indicate that the carrying amount may not be recoverable. Circumstances that could trigger an impairment test include, but are not limited to, a significant adverse change in the business climate or legal factors, an adverse action or assessment by a regulator, or unanticipated competition. The Company may first assess qualitative factors to determine whether it is necessary to perform the quantitative goodwill impairment test, or the Company can bypass the qualitative assessment and proceed directly to the quantitative test. The quantitative goodwill impairment test requires the Company to estimate and compare the fair value of the reporting unit with its carrying value. We determine the fair value of a reporting unit, using a methodology which combines an income approach, using a discounted cash flow method, with a market approach. The income approach includes estimates and assumptions about revenue growth rates, EBITDA and discount rates, discounted by an estimated weighted-average cost of capital derived from other publicly traded companies that are similar but not identical from an operational and economic standpoint. These estimates are based on historical experiences, our projects of future operating activity and our weighted-average cost of capital. A significant change in events, circumstances or any of these assumptions could adversely affect these estimates, which could result in an impairment.

[0001437749-26-018542:mdna:89]
We performed our annual assessment of goodwill on February 28, 2026 including a quantitative assessment of our goodwill balance acquired from our acquisition of Neeltran, and a qualitative assessment of all other reporting units goodwill, and determined that there was no impairment to goodwill. See Note 5, “Goodwill,” for further information regarding our goodwill valuation assumptions.

[0001437749-26-018542:mdna:90]
Income taxes

[0001437749-26-018542:mdna:91]
Our provision for income taxes is comprised of a current and a deferred portion. The current income tax provision is calculated as the estimated taxes payable or refundable on tax returns for the current fiscal year. The deferred income tax provision is calculated for the estimated future tax effects attributable to temporary differences and carryforwards using expected tax rates in effect in the years during which the differences are expected to reverse. All deferred tax assets and liabilities are presented as non-current in the consolidated balance sheets.

[0001437749-26-018542:mdna:92]
We regularly assess our ability to realize our deferred tax assets. Assessments of the realization of deferred tax assets require that management consider all available evidence, both positive and negative, and make significant judgments about many factors, including the amount and likelihood of future taxable income. As of March 31, 2026, the Company recorded a $118.4 million non-cash income tax benefit related to the release of a substantial portion of its valuation allowance against deferred tax assets. This was based on the Company's evaluation of the positive evidence, including cumulative income position over the three year period ended March 31, 2026, revenue growth, current profitability, expectations regarding future forecasted income, and negative evidence, including uncertainty in economic and political environments from industry competition and dependence on government contracts. This release of the valuation allowance resulted in the recognition of a deferred tax asset and a corresponding increase to income tax benefit in fiscal 2025, the effect of which is an increase in reported net income.

[0001437749-26-018542:mdna:93]
Accounting for income taxes requires a two-step approach to recognizing and measuring uncertain tax positions. The first step is to evaluate the tax position for recognition by determining if, based on the technical merits, it is more likely than not that the position will be sustained upon audit, including resolution of related appeals or litigation processes, if any. The second step is to measure the tax benefit as the largest amount that is more than 50% likely of being realized upon ultimate settlement. We reevaluate these uncertain tax positions on a quarterly basis. This evaluation is based on factors including, but not limited to, changes in facts or circumstances, changes in tax law, effectively settled issues under audit and new audit activity. Any changes in these factors could result in the recognition of a tax benefit or an additional charge to the tax provision. See Note 14, “Income Taxes,” of our consolidated financial statements for further information regarding our income tax assumptions and expenses.
