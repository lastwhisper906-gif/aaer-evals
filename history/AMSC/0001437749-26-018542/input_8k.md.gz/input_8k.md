# AMSC 8-K — 0001437749-26-018539 filed 2026-05-27

## item codes, every 8-K on or before 2026-05-27

- 2026-05-27 0001437749-26-018539 — 2.02, 9.01
- 2026-02-17 0001437749-26-004349 — 9.01 — amendment of 0001193125-25-314153
- 2026-02-04 0001437749-26-002977 — 2.02, 9.01
- 2025-12-23 0001193125-25-330930 — 8.01, 9.01
- 2025-12-10 0001193125-25-314153 — 1.01, 2.01, 3.02, 8.01, 9.01
- 2025-11-05 0001437749-25-033344 — 2.02, 9.01
- 2025-07-30 0001437749-25-023965 — 2.02, 9.01
- 2025-07-29 0001437749-25-023783 — 5.07, 9.01
- 2025-06-11 0001193125-25-139243 — 8.01, 9.01
- 2025-05-21 0001437749-25-017983 — 2.02, 5.02, 9.01
- 2025-02-05 0001437749-25-002901 — 2.02, 5.03, 9.01
- 2024-10-30 0001437749-24-032617 — 2.02, 9.01
- 2024-08-13 0001193125-24-199141 — 8.01, 9.01
- 2024-08-06 0001437749-24-024924 — 9.01 — amendment of 0001193125-24-193425
- 2024-08-06 0001437749-24-024881 — 2.02, 9.01
- 2024-08-05 0001193125-24-193965 — 5.02, 5.07, 9.01
- 2024-08-05 0001193125-24-193425 — 1.01, 2.01, 8.01, 9.01
- 2024-05-29 0001437749-24-018599 — 2.02, 5.02, 9.01
- 2024-01-31 0001193125-24-020938 — 8.01, 9.01
- 2024-01-24 0001437749-24-002040 — 2.02, 9.01
- 2023-11-01 0001437749-23-029749 — 2.02, 9.01
- 2023-08-11 0001437749-23-023329 — 5.07
- 2023-08-09 0001437749-23-022786 — 2.02, 9.01
- 2023-06-21 0001193125-23-171201 — 5.02, 9.01
- 2023-05-31 0001437749-23-016264 — 2.02, 9.01
- 2023-02-01 0001437749-23-002268 — 2.02, 9.01
- 2022-11-01 0001437749-22-025365 — 2.02, 9.01
- 2022-08-05 0001193125-22-213651 — 5.02, 5.07, 9.01
- 2022-08-03 0001437749-22-018628 — 2.02, 9.01
- 2022-06-10 0001437749-22-014780 — 5.02, 9.01
- 2022-06-01 0001437749-22-014033 — 2.02, 9.01
- 2022-02-02 0001437749-22-002207 — 2.02, 9.01
- 2021-11-08 0001437749-21-025697 — 2.02, 9.01
- 2021-08-04 0001437749-21-018522 — 2.02, 9.01
- 2021-08-02 0001193125-21-233260 — 5.07
- 2021-06-02 0001437749-21-013955 — 2.02, 9.01
- 2021-05-25 0001437749-21-013279 — 5.02, 9.01
- 2021-05-21 0001193125-21-168626 — 8.01, 9.01
- 2021-05-10 0001193125-21-156251 — 1.01, 9.01
- 2021-02-26 0001193125-21-060434 — 8.01, 9.01
- 2021-02-03 0001437749-21-001859 — 2.02, 9.01
- 2021-02-01 0001437749-21-001681 — 5.03, 9.01
- 2020-12-14 0001437749-20-025291 — 9.01 — amendment, the index does not say of what
- 2020-11-04 0001437749-20-022520 — 2.02, 9.01
- 2020-10-26 0001193125-20-276900 — 8.01, 9.01
- 2020-10-05 0001437749-20-020735 — 2.02
- 2020-10-05 0001437749-20-020734 — 1.01, 2.01, 3.02, 9.01
- 2020-10-02 0001437749-20-020660 — 8.01
- 2020-09-16 0001437749-20-019767 — 8.01
- 2020-08-05 0001437749-20-016665 — 2.02, 5.07, 9.01
- 2020-06-02 0001437749-20-012274 — 2.02, 9.01
- 2020-05-27 0001437749-20-011837 — 5.02, 9.01
- 2020-02-05 0001437749-20-001788 — 2.02, 9.01
- 2019-11-05 0001437749-19-021590 — 2.02, 9.01
- 2019-08-06 0001437749-19-015631 — 2.02, 9.01
- 2019-08-06 0001193125-19-214189 — 5.02, 5.07, 9.01
- 2019-06-05 0001437749-19-011476 — 2.02, 5.02, 9.01
- 2019-05-24 0001437749-19-010833 — 5.02
- 2019-02-05 0001628280-19-000964 — 2.02, 8.01, 9.01
- 2018-11-06 0001628280-18-013765 — 2.02, 9.01
- 2018-10-31 0001628280-18-013204 — 1.01
- 2018-08-01 0001628280-18-010196 — 5.07
- 2018-07-31 0001628280-18-009846 — 2.02, 9.01
- 2018-07-09 0001193125-18-214745 — 1.01, 9.01
- 2018-07-03 0001628280-18-009075 — 5.02, 9.01
- 2018-06-14 0001628280-18-007877 — 5.02
- 2018-06-06 0001628280-18-007643 — 2.02, 9.01
- 2018-04-10 0001628280-18-004141 — 5.02
- 2018-04-03 0001628280-18-003952 — 2.01, 9.01
- 2018-02-05 0001628280-18-000989 — 2.02, 9.01
- 2018-02-01 0001628280-18-000826 — 1.01, 9.01
- 2017-11-07 0001628280-17-011076 — 2.02, 9.01
- 2017-09-26 0001628280-17-009444 — 3.02, 8.01
- 2017-08-08 0001628280-17-008329 — 2.02, 9.01
- 2017-08-01 0001628280-17-007765 — 5.02, 5.07
- 2017-07-03 0001193125-17-221140 — 5.02, 9.01
- 2017-05-26 0001193125-17-185503 — 8.01, 9.01
- 2017-05-25 0001628280-17-005914 — 2.02, 9.01 — amendment of 0001628280-17-005884
- 2017-05-25 0001628280-17-005884 — 2.02, 9.01
- 2017-05-10 0001193125-17-165924 — 8.01, 9.01
- 2017-05-09 0001193125-17-164273 — 5.02
- 2017-05-04 0001193125-17-158639 — 1.02, 8.01
- 2017-04-26 0001193125-17-139493 — 2.02, 9.01
- 2017-04-04 0001193125-17-109748 — 2.05, 5.02, 9.01
- 2017-02-06 0001628280-17-000899 — 2.02, 9.01
- 2017-01-27 0001193125-17-021808 — 1.01, 2.02, 9.01
- 2016-11-02 0001628280-16-020598 — 2.02, 9.01
- 2016-09-16 0001193125-16-712301 — 5.02
- 2016-08-23 0001193125-16-688767 — 8.01
- 2016-08-09 0001628280-16-018763 — 2.02, 9.01
- 2016-08-02 0001193125-16-668417 — 5.02, 5.07, 9.01
- 2016-05-31 0001564590-16-020114 — 2.02, 9.01
- 2016-05-18 0001193125-16-594515 — 5.02
- 2016-03-08 0001193125-16-496113 — 1.01
- 2016-02-09 0001193125-16-454775 — 2.02, 9.01
- 2015-12-17 0001193125-15-405566 — 1.01
- 2015-11-03 0001193125-15-363413 — 2.02, 9.01
- 2015-08-31 0001193125-15-307558 — 1.01
- 2015-08-05 0001193125-15-277824 — 2.02, 9.01
- 2015-07-31 0001193125-15-273009 — 5.07
- 2015-06-26 0001193125-15-237190 — 5.02
- 2015-06-09 0001193125-15-218028 — 8.01
- 2015-05-28 0001193125-15-202933 — 2.02, 9.01
- 2015-04-28 0001193125-15-153319 — 8.01, 9.01
- 2015-04-23 0001193125-15-144123 — 2.02, 8.01, 9.01
- 2015-04-23 0001193125-15-143608 — 8.01
- 2015-04-10 0001193125-15-126160 — 8.01
- 2015-03-24 0001193125-15-103436 — 5.03, 9.01
- 2015-03-18 0001193125-15-097034 — 5.07
- 2015-02-05 0001193125-15-034499 — 2.02, 9.01
- 2015-01-29 0001193125-15-024629 — 2.02, 9.01
- 2015-01-21 0001193125-15-016287 — 3.01, 8.01
- 2015-01-06 0001193125-15-002902 — 5.02
- 2014-12-22 0001193125-14-450591 — 1.01, 2.03, 3.02, 9.01
- 2014-11-13 0001193125-14-410207 — 1.01, 9.01
- 2014-11-07 0001193125-14-402383 — 1.02, 7.01, 9.01
- 2014-11-06 0001193125-14-399779 — 2.02, 9.01
- 2014-10-01 0001193125-14-360072 — 2.02, 8.01, 9.01
- 2014-09-04 0001193125-14-331411 — 8.01
- 2014-08-21 0001193125-14-317133 — 1.01
- 2014-08-06 0001193125-14-298306 — 5.02, 5.07, 9.01
- 2014-08-05 0001193125-14-294647 — 2.02, 9.01
- 2014-07-16 0001193125-14-269902 — 8.01
- 2014-06-23 0001193125-14-244592 — 3.02, 8.01
- 2014-06-05 0001193125-14-226459 — 2.02, 9.01
- 2014-06-05 0001193125-14-226457 — 1.01, 9.01
- 2014-03-19 0001193125-14-106558 — 2.05
- 2014-03-03 0001193125-14-078917 — 1.01, 3.02, 9.01
- 2014-02-28 0001193125-14-077480 — 8.01, 9.01
- 2014-02-06 0001193125-14-037960 — 2.02, 8.01, 9.01
- 2013-11-20 0001193125-13-447829 — 3.02, 8.01
- 2013-11-18 0001193125-13-444697 — 1.01, 2.03, 3.02, 9.01
- 2013-11-07 0001193125-13-431705 — 2.02, 9.01
- 2013-10-09 0001193125-13-395362 — 1.01, 2.03, 3.02, 9.01
- 2013-09-25 0001193125-13-378481 — 5.02, 9.01
- 2013-08-21 0001193125-13-341566 — 4.01, 9.01
- 2013-08-07 0001193125-13-323082 — 2.02, 9.01
- 2013-08-02 0001193125-13-317278 — 5.02, 5.07
- 2013-06-14 0001193125-13-258758 — 2.02, 9.01
- 2013-04-01 0001193125-13-136714 — 2.02, 8.01, 9.01
- 2013-02-20 0001193125-13-067218 — 5.02, 9.01
- 2013-02-14 0001193125-13-060131 — 1.01, 9.01
- 2013-02-11 0001193125-13-048784 — 2.02, 9.01
- 2013-01-08 0001193125-13-006861 — 5.02, 9.01
- 2012-12-21 0001193125-12-511592 — 1.01, 2.03, 3.02, 9.01
- 2012-11-28 0001193125-12-483317 — 2.05, 5.02, 7.01, 9.01
- 2012-11-06 0001193125-12-453359 — 2.02, 9.01
- 2012-08-02 0001193125-12-330534 — 2.02, 9.01
- 2012-07-27 0001193125-12-318790 — 5.02, 5.07, 9.01
- 2012-06-06 0001193125-12-261030 — 1.01, 2.02, 2.03, 3.02, 5.02, 9.01
- 2012-05-09 0001193125-12-222210 — 5.02
- 2012-04-20 0001193125-12-172045 — 8.01
- 2012-04-13 0001193125-12-162694 — 2.02, 8.01, 9.01
- 2012-04-04 0001193125-12-149102 — 1.01, 2.02, 2.03, 3.02, 9.01
- 2012-02-09 0001193125-12-048009 — 2.02, 9.01
- 2012-02-06 0001193125-12-041344 — 5.07 — amendment of 0000950123-11-102495
- 2011-12-08 0000950123-11-102495 — 5.07
- 2011-11-29 0000950123-11-100822 — 2.05
- 2011-11-09 0000950123-11-096775 — 2.02, 9.01
- 2011-10-31 0000950123-11-093390 — 1.02, 9.01
- 2011-10-07 0000950123-11-089221 — 8.01
- 2011-10-03 0000950123-11-088315 — 7.01
- 2011-09-23 0000950123-11-086288 — 2.02, 9.01
- 2011-09-15 0000950123-11-084585 — 7.01
- 2011-09-06 0000950123-11-082736 — 7.01
- 2011-08-18 0000950123-11-078526 — 3.01, 7.01, 9.01
- 2011-08-11 0000950123-11-075905 — 5.02
- 2011-08-11 0000950123-11-075904 — 2.02, 2.05, 9.01
- 2011-07-11 0000950123-11-064934 — 2.02, 4.02, 9.01
- 2011-06-30 0000950123-11-063287 — 1.01, 3.02, 9.01
- 2011-06-21 0000950123-11-060491 — 3.01, 7.01, 9.01
- 2011-06-13 0000950123-11-058656 — 1.01, 9.01
- 2011-05-24 0000950123-11-053517 — 5.02, 9.01
- 2011-04-05 0001299933-11-001020 — 2.02, 9.01
- 2011-03-15 0000950123-11-025580 — 5.02
- 2011-03-14 0000950123-11-025205 — 1.01, 3.02, 9.01
- 2011-02-01 0001299933-11-000333 — 2.02, 9.01
- 2010-11-12 0000950123-10-104604 — 8.01, 9.01
- 2010-11-08 0000950123-10-102424 — 8.01, 9.01
- 2010-11-02 0001299933-10-003878 — 2.02, 9.01
- 2010-09-15 0000950123-10-086373 — 1.01, 9.01 — amendment, the index does not say of what
- 2010-08-06 0000950123-10-074362 — 5.07
- 2010-07-29 0001299933-10-002860 — 2.02, 9.01
- 2010-05-17 0000950123-10-050424 — 1.01, 9.01
- 2010-05-14 0001299933-10-001972 — 5.02
- 2010-05-13 0001299933-10-001943 — 2.02, 9.01
- 2010-02-08 0001299933-10-000506 — 8.01
- 2010-02-02 0001299933-10-000386 — 2.02, 9.01
- 2009-12-15 0001299933-09-004928 — 5.02
- 2009-10-29 0001299933-09-004267 — 2.02, 9.01
- 2009-08-12 0001193125-09-173026 — 5.02, 9.01
- 2009-07-30 0001193125-09-158842 — 1.01, 2.02, 9.01
- 2009-05-15 0001193125-09-113158 — 5.02
- 2009-05-14 0001193125-09-110619 — 2.02, 9.01
- 2009-04-20 0001193125-09-082590 — 5.02
- 2009-02-03 0001193125-09-016992 — 2.02, 9.01
- 2009-01-22 0001193125-09-009777 — 2.02, 9.01
- 2008-11-04 0001193125-08-223730 — 2.02, 9.01
- 2008-08-11 0001193125-08-173616 — 8.01
- 2008-08-07 0001193125-08-170325 — 8.01
- 2008-08-05 0001193125-08-165888 — 2.02, 9.01
- 2008-06-11 0001193125-08-132049 — 1.01, 9.01
- 2008-05-20 0001193125-08-119372 — 5.02, 9.01
- 2008-05-08 0001193125-08-107052 — 2.02, 9.01
- 2008-01-31 0001193125-08-016233 — 2.02, 9.01
- 2008-01-30 0001193125-08-015494 — 5.03, 9.01
- 2007-11-01 0001193125-07-231866 — 2.02, 9.01
- 2007-10-31 0001193125-07-231225 — 2.05
- 2007-10-29 0001193125-07-228284 — 5.03, 9.01
- 2007-09-27 0001193125-07-208950 — 5.02
- 2007-08-09 0001193125-07-176553 — 2.02, 9.01
- 2007-08-07 0001193125-07-173829 — 1.01, 5.02, 9.01
- 2007-07-02 0001193125-07-148303 — 5.02, 9.01
- 2007-06-20 0001193125-07-139068 — 8.01, 9.01
- 2007-06-14 0001193125-07-135550 — 9.01 — amendment of 0001193125-07-005297
- 2007-06-14 0001193125-07-135340 — 5.02
- 2007-05-24 0001193125-07-122148 — 2.02, 9.01
- 2007-03-30 0001193125-07-070154 — 2.05, 9.01
- 2007-03-23 0001193125-07-062978 — 9.01 — amendment of 0001193125-07-005297
- 2007-02-01 0001193125-07-017883 — 2.02, 9.01
- 2007-01-11 0001193125-07-005297 — 2.01, 9.01
- 2006-12-05 0001181431-06-067500 — 5.02
- 2006-11-29 0001193125-06-243360 — 1.01, 3.02, 9.01
- 2006-11-02 0001193125-06-221464 — 2.02, 9.01
- 2006-09-21 0001193125-06-194526 — 5.02
- 2006-08-08 0001193125-06-164819 — 2.02, 9.01
- 2006-08-02 0001193125-06-159113 — 1.01, 9.01
- 2006-07-28 0001193125-06-156172 — 1.01
- 2006-06-26 0001193125-06-135913 — 1.01, 3.03, 9.01
- 2006-05-11 0001193125-06-108489 — 2.02, 9.01
- 2006-05-05 0001193125-06-102270 — 1.01, 9.01
- 2006-05-01 0001193125-06-094941 — 2.02, 2.06, 9.01
- 2006-02-24 0001193125-06-038281 — 5.02, 9.01
- 2006-02-02 0001181431-06-007665 — 2.02, 9.01
- 2005-11-09 0001181431-05-060304 — 2.02, 9.01
- 2005-08-04 0001181431-05-044420 — 2.02, 9.01
- 2005-07-28 0001193125-05-151272 — 5.02, 9.01
- 2005-06-14 0001193125-05-125148 — 5.02, 9.01
- 2005-05-12 0001181431-05-027410 — 2.02, 9.01
- 2005-05-10 0001193125-05-102795 — 1.01
- 2005-04-05 0001181431-05-020680 — 1.01, 2.02, 3.02, 9.01
- 2005-02-03 0001181431-05-006678 — 2.02, 9.01
- 2004-11-09 0001181431-04-051381 — 2.02, 9.01 — amendment, the index does not say of what
- 2004-11-04 0001181431-04-050706 — 2.02, 9.01
- 2004-10-15 0001193125-04-172458 — 1.01, 9.01
- 2004-08-05 0001193125-04-132162 — 12
- 2004-05-13 0001193125-04-086853 — 12
- 2004-02-05 0001193125-04-015060 — 12
- 2003-11-06 0001193125-03-074000 — 12
- 2003-09-26 0001193125-03-054624 — 5
- 2003-08-06 0001193125-03-029666 — 12
- 2003-05-14 0000927016-03-002619 — 9
- 2002-12-31 0000927016-02-006114 — 5
- 2000-01-24 0000927016-00-000150 — 5, 7
- 1998-11-02 0000950135-98-005625 — 5, 7
- 1998-03-24 0000950135-98-001743 — 5, 7
- 1997-09-05 0000950135-97-003729 — 5, 7
- 1997-06-23 0000950135-97-002785 — 1 — amendment of 0000950135-97-001972
- 1997-04-23 0000950135-97-001972 — 2, 7

## late-filing notifications on or before 2026-05-27

- 2011-08-10 0000950123-11-075677 — NT 10-Q, for the period ended 2011-06-30
- 2011-05-31 0000950123-11-055465 — NT 10-K, for the period ended 2011-03-31

## item 2.02 — earnings release, exhibit 99.1

[0001437749-26-018539:8k_2_02:1]
EX-99.1
2
ex_919739.htm
EXHIBIT 99.1

[0001437749-26-018539:8k_2_02:2]
ex_919739.htm

[0001437749-26-018539:8k_2_02:3]
Exhibit 99.1

[0001437749-26-018539:8k_2_02:4]
AMSC Reports Fourth Quarter and Fiscal Year 2025 Financial Results and Business Outlook

[0001437749-26-018539:8k_2_02:5]
Business Highlights:

[0001437749-26-018539:8k_2_02:6]
• Full year revenue surges 34% year-over-year to recent record of $299.2 million

[0001437749-26-018539:8k_2_02:7]
• 12-month backlog expands nearly 40% year-over-year to approximately $280 million

[0001437749-26-018539:8k_2_02:8]
Company to host conference call tomorrow, May 28 at 10:00 am ET

[0001437749-26-018539:8k_2_02:9]
Ayer, MA – May 27, 2026 – AMSC (Nasdaq: AMSC), a leading provider of power control solutions that harmonize an increasingly complex energy system and enable customers to scale their operations without added complexity or size, today reported financial results for its fourth quarter and fiscal year ended March 31, 2026 ("fiscal 2025").

[0001437749-26-018539:8k_2_02:10]
Revenues for the fourth quarter of fiscal 2025 were $86.4 million compared with $66.7 million for the same period of fiscal 2024. The year-over-year increase was driven by strong organic growth within our Grid and Wind businesses along with the contributions from the acquisition of Comtrafo.

[0001437749-26-018539:8k_2_02:11]
AMSC’s net income for the fourth quarter of fiscal 2025 was $4.5 million, or $0.10 per share, compared to net income of $1.2 million, or $0.03 per share, for the same period of fiscal 2024. The Company’s non-GAAP net income for the fourth quarter of fiscal 2025 was $14.1 million, or $0.31 per share, compared with a non-GAAP net income of $4.8 million, or $0.13 per share, in the same period of fiscal 2024. Please refer to the financial table below for a reconciliation of GAAP to non-GAAP results.

[0001437749-26-018539:8k_2_02:12]
Revenues for fiscal 2025 were $299.2 million as compared to $222.8 million in fiscal 2024. The year-over-year increase was driven by higher Grid and Wind revenues than in the prior fiscal year along with the contribution from the acquisition of Comtrafo.

[0001437749-26-018539:8k_2_02:13]
AMSC reported net income for fiscal 2025 of $133.8 million, or $3.12 per share, compared to a net income of $6.0 million, or $0.16 per share in fiscal 2024, driven primarily by a non-cash tax benefit from the release of the majority of the Company's valuation allowance against deferred tax assets. The Company's non-GAAP net income for fiscal 2025 was $158.1 million, or $3.68 per share, compared with non-GAAP net income of $24.0 million, or $0.65 per share, for fiscal 2024. Please refer to the financial table below for a reconciliation of GAAP to non-GAAP results.

[0001437749-26-018539:8k_2_02:14]
Cash, cash equivalents and restricted cash on March 31, 2026 totaled $147.6 million.

[0001437749-26-018539:8k_2_02:15]
"AMSC delivered record quarterly and full-year results, reflecting exceptional strategic and operational execution," said Daniel P. McGahn, Chairman, President and CEO of AMSC. "We delivered a strong fourth quarter, with revenue up 30% year-over-year to over $86 million. For the full year, revenue grew 34% to nearly $300 million, driven primarily by 25% organic growth and supported by our recent acquisition to capture utility and industrial demand in Latin America. Fourth quarter orders approached $100 million, led by the traditional energy sector and surging data center demand within the utility market. We ended the year with our 12-month backlog up nearly 40% year-over-year to approximately $280 million. These results demonstrate our expanded addressable market and disciplined operational execution. We enter fiscal 2026 with a steadfast focus on powering progress and driving long-term success for AMSC customers."

[0001437749-26-018539:8k_2_02:16]
| AMSC Reports Q4FY25 Results | Page 2 |

[0001437749-26-018539:8k_2_02:17]
Business Outlook

[0001437749-26-018539:8k_2_02:18]
For the first quarter ending June 30, 2026, AMSC expects that its revenues will exceed $85.0 million. The Company’s net income for the first quarter of fiscal 2026 is expected to exceed $3.0 million, or $0.07 per share, excluding the impact from any changes in contingent consideration. The Company's non-GAAP net income (as defined below) is expected to exceed $8.0 million, or $0.17 per share.

[0001437749-26-018539:8k_2_02:19]
Conference Call Reminder

[0001437749-26-018539:8k_2_02:20]
In conjunction with this announcement, AMSC management will participate in a conference call with investors beginning at 10:00 a.m. Eastern Time on Thursday, May 28, 2026, to discuss the Company’s financial results and business outlook. Those who wish to listen to the live or archived conference call webcast should visit the “Investors” section of the Company’s website at https://ir.amsc.com. The live call can be accessed by dialing 1-844-481-2802 or 1-412-317-0675 and asking to join the AMSC call. A replay of the call may be accessed 2 hours following the call by dialing 1-855-669-9658 and using conference passcode 1468055.

[0001437749-26-018539:8k_2_02:21]
About AMSC (Nasdaq: AMSC)

[0001437749-26-018539:8k_2_02:22]
Guided by a belief in the power of next, AMSC is a leading provider of power controls solutions that apply innovation and creativity to address today's challenges and enable a more resilient and sustainable energy future. Driven by the purpose "to power progress," the Company integrates future-facing technologies to balance the global demand for clean energy with reliable, efficient power delivery. AMSC delivers advanced grid systems and engineering services to optimize network reliability, provides ship protection and power management solutions to enhance fleet efficiency and safety, and supplies electronic controls and designs that reduce wind energy costs. Beyond these systems, the Company provides capabilities in industrial process and control alongside environmental and emission control to ensure operational efficiency across the entire energy infrastructure. The Company's solutions are optimizing power network, increasing the safety of navy fleets, and powering gigawatts of renewable energy globally. Founded in 1987, AMSC is headquarters near Boston, Massachusetts with operations in Asia, Australia, Brazil, Europe, and North America. For more information, please visit www.amsc.com.

[0001437749-26-018539:8k_2_02:23]
© 2026 AMSC, AMSC, American Superconductor, Comtrafo, Neeltran, NEPSI and NWL are trademarks or registered trademarks of American Superconductor Corporation. All other brand names, product names, trademarks or service marks belong to their respective holders.

[0001437749-26-018539:8k_2_02:24]
| AMSC Reports Q4FY25 Results | Page 3 |

[0001437749-26-018539:8k_2_02:25]
Forward-Looking Statements

[0001437749-26-018539:8k_2_02:26]
| AMSC Reports Q4FY25 Results | Page 4 |

[0001437749-26-018539:8k_2_02:27]
UNAUDITED CONSOLIDATED STATEMENTS OF OPERATIONS

[0001437749-26-018539:8k_2_02:28]
(In thousands, except per share data)

[0001437749-26-018539:8k_2_02:29]
|  |  | Three Months Ended |  |  | Twelve Months Ended |  |
|  |  | March 31, |  |  | March 31, |  |
|  |  | 2026 |  |  | 2025 |  |  | 2026 |  |  | 2025 |  |
| Revenues |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Grid |  | $ | 73,701 |  |  | $ | 55,592 |  |  | $ | 251,317 |  |  | $ | 187,170 |  |
| Wind |  |  | 12,705 |  |  |  | 11,063 |  |  |  | 47,838 |  |  |  | 35,648 |  |
| Total revenues |  |  | 86,406 |  |  |  | 66,655 |  |  |  | 299,155 |  |  |  | 222,818 |  |
| Cost of revenues |  |  | 62,807 |  |  |  | 48,964 |  |  |  | 207,776 |  |  |  | 160,964 |  |
| Gross margin |  |  | 23,600 |  |  |  | 17,691 |  |  |  | 91,379 |  |  |  | 61,854 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Research and development |  |  | 4,167 |  |  |  | 3,493 |  |  |  | 15,744 |  |  |  | 11,425 |  |
| Selling, general and administrative |  |  | 14,596 |  |  |  | 12,101 |  |  |  | 57,647 |  |  |  | 43,091 |  |
| Amortization of acquisition related intangibles |  |  | 1,187 |  |  |  | 444 |  |  |  | 2,371 |  |  |  | 1,733 |  |
| Change in fair value of contingent consideration |  |  | 4,171 |  |  |  | — |  |  |  | 4,171 |  |  |  | 6,682 |  |
| Total operating expenses |  |  | 24,122 |  |  |  | 16,038 |  |  |  | 79,934 |  |  |  | 62,931 |  |
| Operating income (loss) |  |  | (522 | ) |  |  | 1,653 |  |  |  | 11,445 |  |  |  | (1,077 | ) |
| Interest income, net |  |  | 1,158 |  |  |  | 807 |  |  |  | 6,356 |  |  |  | 3,708 |  |
| Other expense, net |  |  | (1,110 | ) |  |  | (49 | ) |  |  | (1,053 | ) |  |  | (265 | ) |
| Income (loss) before income tax (benefit) expense |  |  | (474 | ) |  |  | 2,411 |  |  |  | 16,748 |  |  |  | 2,366 |  |
| Income tax (benefit) expense |  |  | (5,004 | ) |  |  | 1,204 |  |  |  | (117,061 | ) |  |  | (3,667 | ) |
| Net income |  | $ | 4,530 |  |  | $ | 1,207 |  |  | $ | 133,809 |  |  | $ | 6,033 |  |
| Net income per common share |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  |  | 0.10 |  |  |  | 0.03 |  |  |  | 3.12 |  |  |  | 0.16 |  |
| Diluted |  |  | 0.10 |  |  |  | 0.03 |  |  |  | 3.05 |  |  |  | 0.16 |  |
| Weighted average number of common shares outstanding |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  |  | 45,723 |  |  |  | 37,672 |  |  |  | 42,945 |  |  |  | 36,990 |  |
| Diluted |  |  | 46,733 |  |  |  | 38,516 |  |  |  | 43,902 |  |  |  | 37,718 |  |

[0001437749-26-018539:8k_2_02:30]
| AMSC Reports Q4FY25 Results | Page 5 |

[0001437749-26-018539:8k_2_02:31]
CONSOLIDATED BALANCE SHEET

[0001437749-26-018539:8k_2_02:32]
(In thousands, except per share data)

[0001437749-26-018539:8k_2_02:33]
|  |  | March 31, |  |  | March 31, |  |
|  |  | 2026 |  |  | 2025 |  |
| ASSETS |  |  |  |  |  |  |  |  |
| Current assets: |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 140,693 |  |  | $ | 79,494 |  |
| Accounts receivable, net |  |  | 69,381 |  |  |  | 46,186 |  |
| Inventory, net |  |  | 103,748 |  |  |  | 71,169 |  |
| Prepaid expenses and other current assets |  |  | 14,367 |  |  |  | 8,055 |  |
| Restricted cash |  |  | 3,548 |  |  |  | 1,613 |  |
| Total current assets |  |  | 331,737 |  |  |  | 206,517 |  |
| Property, plant and equipment, net |  |  | 89,775 |  |  |  | 38,572 |  |
| Intangibles, net |  |  | 13,548 |  |  |  | 5,916 |  |
| Right-of-use assets |  |  | 3,897 |  |  |  | 3,829 |  |
| Goodwill |  |  | 175,376 |  |  |  | 48,164 |  |
| Restricted cash |  |  | 3,312 |  |  |  | 4,274 |  |
| Deferred tax assets |  |  | 119,474 |  |  |  | 1,178 |  |
| Equity-method Investments |  |  | 1,333 |  |  |  | 1,113 |  |
| Other assets |  |  | 1,029 |  |  |  | 958 |  |
| Total assets |  | $ | 739,481 |  |  | $ | 310,521 |  |
| LIABILITIES AND STOCKHOLDERS' EQUITY |  |  |  |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |  |  |  |
| Accounts payable and accrued expenses |  | $ | 46,545 |  |  | $ | 32,282 |  |
| Lease liability, current portion |  |  | 1,238 |  |  |  | 685 |  |
| Contingent consideration, current portion |  |  | 12,808 |  |  |  | — |  |
| Deferred revenue, current portion |  |  | 77,936 |  |  |  | 66,797 |  |
| Total current liabilities |  |  | 138,527 |  |  |  | 99,764 |  |
| Deferred revenue, long term portion |  |  | 15,395 |  |  |  | 9,336 |  |
| Lease liability, long term portion |  |  | 2,762 |  |  |  | 2,684 |  |
| Deferred tax liabilities |  |  | — |  |  |  | 1,595 |  |
| Contingent consideration, long term portion |  |  | 26,721 |  |  |  | — |  |
| Other liabilities |  |  | 629 |  |  |  | 28 |  |
| Total liabilities |  |  | 184,034 |  |  |  | 113,407 |  |
| Stockholders' equity: |  |  |  |  |  |  |  |  |
| Common stock, $0.01 par value, 75,000,000 shares authorized; 48,035,691 and 39,887,536 shares issued and 47,632,340 and 39,484,185 shares outstanding at March 31, 2026 and 2025, respectively |  |  | 480 |  |  |  | 399 |  |
| Additional paid-in capital |  |  | 1,481,476 |  |  |  | 1,259,540 |  |
| Treasury stock, at cost, 403,351 at March 31, 2026 and 2025 |  |  | (3,765 | ) |  |  | (3,765 | ) |
| Accumulated other comprehensive income |  |  | 4,072 |  |  |  | 1,565 |  |
| Accumulated deficit |  |  | (926,816 | ) |  |  | (1,060,625 | ) |
| Total stockholders' equity |  |  | 555,447 |  |  |  | 197,114 |  |
| Total liabilities and stockholders' equity |  | $ | 739,481 |  |  | $ | 310,521 |  |

[0001437749-26-018539:8k_2_02:34]
| AMSC Reports Q4FY25 Results | Page 6 |

[0001437749-26-018539:8k_2_02:35]
CONSOLIDATED STATEMENTS OF CASH FLOWS

[0001437749-26-018539:8k_2_02:36]
(In thousands)

[0001437749-26-018539:8k_2_02:37]
|  |  | Year Ended March 31, |  |
|  |  | 2026 |  |  | 2025 |  |
| Cash flows from operating activities: |  |  |  |  |  |  |  |  |
| Net income |  | $ | 133,809 |  |  | $ | 6,033 |  |
| Adjustments to reconcile net income to net cash provided by operations: |  |  |  |  |  |  |  |  |
| Depreciation and amortization |  |  | 7,386 |  |  |  | 5,560 |  |
| Stock-based compensation expense |  |  | 15,869 |  |  |  | 7,794 |  |
| Provision for excess and obsolete inventory |  |  | 3,497 |  |  |  | 1,532 |  |
| Amortization of operating lease right-of-use assets |  |  | 1,068 |  |  |  | 976 |  |
| Deferred income taxes |  |  | (118,683 | ) |  |  | (4,304 | ) |
| Earnings (loss) from equity method investments |  |  | (220 | ) |  |  | 132 |  |
| Change in fair value of contingent consideration |  |  | 4,171 |  |  |  | 6,682 |  |
| Other non-cash items |  |  | 316 |  |  |  | (587 | ) |
| Unrealized foreign exchange gain on cash and cash equivalents |  |  | (2 | ) |  |  | (41 | ) |
| Changes in operating asset and liability accounts: |  |  |  |  |  |  |  |  |
| Accounts receivable |  |  | (16,292 | ) |  |  | (3,213 | ) |
| Inventory |  |  | (6,961 | ) |  |  | (7,707 | ) |
| Prepaid expenses and other current assets |  |  | (598 | ) |  |  | 543 |  |
| Operating leases |  |  | (503 | ) |  |  | (1,563 | ) |
| Accounts payable and accrued expenses |  |  | 7,142 |  |  |  | 3,209 |  |
| Deferred revenue |  |  | (6,851 | ) |  |  | 13,239 |  |
| Net cash provided by operating activities |  |  | 23,148 |  |  |  | 28,285 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |
| Purchases of property, plant and equipment |  |  | (4,888 | ) |  |  | (2,415 | ) |
| Cash paid to settle NWL contingent consideration liability |  |  | — |  |  |  | (3,278 | ) |
| Cash paid for acquisition, net of cash acquired |  |  | (72,096 | ) |  |  | (29,577 | ) |
| Change in other assets |  |  | (98 | ) |  |  | 64 |  |
| Net cash used in investing activities |  |  | (77,082 | ) |  |  | (35,206 | ) |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |
| Repurchase of treasury stock |  |  | — |  |  |  | (126 | ) |
| Repayment of debt |  |  | (8,809 | ) |  |  | (25 | ) |
| Cash paid related to registration of common stock shares |  |  | — |  |  |  | (148 | ) |
| Proceeds from public equity offering, net of offering expenses |  |  | 124,501 |  |  |  | — |  |
| Proceeds from exercise of employee stock options and ESPP |  |  | 391 |  |  |  | 307 |  |
| Net cash provided by financing activities |  |  | 116,082 |  |  |  | 8 |  |
| Effect of exchange rate changes on cash, cash equivalents and restricted cash |  |  | 24 |  |  |  | 14 |  |
| Net (decrease) increase in cash, cash equivalents and restricted cash |  |  | 62,172 |  |  |  | (6,899 | ) |
| Cash, cash equivalents and restricted cash at beginning of year |  |  | 85,381 |  |  |  | 92,280 |  |
| Cash, cash equivalents and restricted cash at end of year |  | $ | 147,553 |  |  | $ | 85,381 |  |

[0001437749-26-018539:8k_2_02:38]
| AMSC Reports Q4FY25 Results | Page 7 |

[0001437749-26-018539:8k_2_02:39]
RECONCILIATION OF GAAP NET INCOME TO NON-GAAP NET INCOME

[0001437749-26-018539:8k_2_02:40]
(In thousands, except per share data)

[0001437749-26-018539:8k_2_02:41]
|  |  | Three Months Ended March 31, |  |  | Year Ended March 31, |  |
|  |  | 2026 |  |  | 2025 |  |  | 2026 |  |  | 2025 |  |
| Net income |  | $ | 4,530 |  |  | $ | 1,207 |  |  | $ | 133,809 |  |  | $ | 6,033 |  |
| Stock-based compensation |  |  | 3,755 |  |  |  | 2,855 |  |  |  | 15,869 |  |  |  | 7,794 |  |
| Amortization of acquisition-related intangibles |  |  | 1,732 |  |  |  | 706 |  |  |  | 3,024 |  |  |  | 2,433 |  |
| Change in fair value of contingent consideration |  |  | 4,171 |  |  |  | — |  |  |  | 4,171 |  |  |  | 6,682 |  |
| Acquisition costs |  |  | (43 | ) |  |  | — |  |  |  | 1,243 |  |  |  | 1,095 |  |
| Non-GAAP net income |  |  | 14,145 |  |  |  | 4,768 |  |  |  | 158,116 |  |  |  | 24,037 |  |
| Non-GAAP net income per share - basic |  | $ | 0.31 |  |  | $ | 0.13 |  |  | $ | 3.68 |  |  | $ | 0.65 |  |
| Non-GAAP net income per share - diluted |  | $ | 0.30 |  |  | $ | 0.12 |  |  | $ | 3.60 |  |  | $ | 0.64 |  |
| Weighted average shares outstanding - basic |  |  | 45,723 |  |  |  | 37,672 |  |  |  | 42,945 |  |  |  | 36,990 |  |
| Weighted average shares outstanding - diluted |  |  | 46,733 |  |  |  | 38,516 |  |  |  | 43,902 |  |  |  | 37,718 |  |

[0001437749-26-018539:8k_2_02:42]
Reconciliation of Forecast GAAP Net Income to Non-GAAP Net Income

[0001437749-26-018539:8k_2_02:43]
(In millions, except per share data)

[0001437749-26-018539:8k_2_02:44]
|  |  | Three months ending |  |
|  |  | June 30, 2026 |  |
| Net income |  | $ | 3.0 |  |
| Stock-based compensation |  |  | 4.2 |  |
| Amortization of acquisition-related intangibles |  |  | 0.8 |  |
| Non-GAAP net income |  | $ | 8.0 |  |
| Non-GAAP net income per share |  | $ | 0.17 |  |
| Shares outstanding |  |  | 46.0 |  |

[0001437749-26-018539:8k_2_02:45]
| AMSC Reports Q4FY25 Results | Page 8 |

[0001437749-26-018539:8k_2_02:46]
Note: Non-GAAP net income is defined by the Company as net income before; stock-based compensation; amortization of acquisition-related intangibles; change in fair value of contingent consideration; acquisition costs; other non-cash or unusual charges, and the tax effect of adjustments calculated at the relevant rate for our non-GAAP metric. The Company believes non-GAAP net income and non-GAAP net income per share assist management and investors in comparing the Company’s performance across reporting periods on a consistent basis by excluding these non-cash, non-recurring or other charges that it does not believe are indicative of its core operating performance. Actual GAAP and non-GAAP net income and net income per share for the fiscal quarter ending June 30, 2026, including the above adjustments, may differ materially from those forecasted in the table above, including as a result of changes in the fair value of contingent consideration.

[0001437749-26-018539:8k_2_02:47]
Generally, a non-GAAP financial measure is a numerical measure of a company's performance, financial position or cash flow that either excludes or includes amounts that are not normally excluded or included in the most directly comparable measure calculated and presented in accordance with GAAP. The non-GAAP measures included in this release, however, should be considered in addition to, and not as a substitute for or superior to, net income or other measures of financial performance prepared in accordance with GAAP. A reconciliation of GAAP to non-GAAP net income is set forth in the table above. Non-GAAP net income per share is defined as non-GAAP net income divided by shares outstanding.

[0001437749-26-018539:8k_2_02:48]
AMSC Contacts

[0001437749-26-018539:8k_2_02:49]
Investor Relations Contact:

[0001437749-26-018539:8k_2_02:50]
Carolyn Capaccio, CFA

[0001437749-26-018539:8k_2_02:51]
(212) 838-3777

[0001437749-26-018539:8k_2_02:52]
Email: amscIR@allianceadvisors.com

[0001437749-26-018539:8k_2_02:53]
AMSC Director, Communications:

[0001437749-26-018539:8k_2_02:54]
Nicol Golez

[0001437749-26-018539:8k_2_02:55]
Phone: (978) 399-8344

[0001437749-26-018539:8k_2_02:56]
Email: Nicol.Golez@amsc.com

[0001437749-26-018539:8k_2_02:57]
Public Relations Contact:

[0001437749-26-018539:8k_2_02:58]
RooneyPartners

[0001437749-26-018539:8k_2_02:59]
Joe Luongo

[0001437749-26-018539:8k_2_02:60]
(914) 906-5903

[0001437749-26-018539:8k_2_02:61]
Email: jluongo@rooneypartners.com
