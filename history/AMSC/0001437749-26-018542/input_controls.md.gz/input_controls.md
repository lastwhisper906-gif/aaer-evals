# AMSC 10-K controls and the auditor's report


## auditors_report

[0001437749-26-018542:auditors_report:1]
Report of Independent Registered Public Accounting Firm

[0001437749-26-018542:auditors_report:2]
To the Stockholders and the Board of Directors of American Superconductor Corporation

[0001437749-26-018542:auditors_report:3]
Opinion on the Financial Statements

[0001437749-26-018542:auditors_report:4]
We have audited the accompanying consolidated balance sheets of American Superconductor Corporation and its subsidiaries (the Company) as of March 31, 2026 and 2025, the related consolidated statements of operations, comprehensive income (loss), stockholders’ equity and cash flows for each of the three years in the period ended March 31, 2026, and the related notes to the consolidated financial statements and schedules (collectively, the financial statements). In our opinion, the financial statements present fairly, in all material respects, the financial position of the Company as of March 31, 2026 and 2025, and the results of its operations and its cash flows for each of the three years in the period ended March 31, 2026, in conformity with accounting principles generally accepted in the United States of America.

[0001437749-26-018542:auditors_report:5]
We have also audited, in accordance with the standards of the Public Company Accounting Oversight Board (United States) (PCAOB), the Company’s internal control over financial reporting as of March 31, 2026, based on criteria established in Internal Control—Integrated Framework issued by the Committee of Sponsoring Organizations of the Treadway Commission in 2013. Our report dated May 27, 2026, expressed an opinion that the Company had not maintained effective internal control over financial reporting as of March 31, 2026, based on criteria established in Internal Control—Integrated Framework issued by the Committee of Sponsoring Organizations of the Treadway Commission in 2023.

[0001437749-26-018542:auditors_report:6]
Basis for Opinion

[0001437749-26-018542:auditors_report:7]
These financial statements are the responsibility of the Company’s management. Our responsibility is to express an opinion on the Company’s financial statements based on our audits. We are a public accounting firm registered with the PCAOB and are required to be independent with respect to the Company in accordance with U.S. federal securities laws and the applicable rules and regulations of the Securities and Exchange Commission and the PCAOB.

[0001437749-26-018542:auditors_report:8]
We conducted our audits in accordance with the standards of the PCAOB. Those standards require that we plan and perform the audit to obtain reasonable assurance about whether the financial statements are free of material misstatement, whether due to error or fraud. Our audits included performing procedures to assess the risks of material misstatement of the financial statements, whether due to error or fraud, and performing procedures that respond to those risks. Such procedures included examining, on a test basis, evidence regarding the amounts and disclosures in the financial statements. Our audits also included evaluating the accounting principles used and significant estimates made by management, as well as evaluating the overall presentation of the financial statements. We believe that our audits provide a reasonable basis for our opinion.

[0001437749-26-018542:auditors_report:9]
Critical Audit Matters

[0001437749-26-018542:auditors_report:10]
The critical audit matters communicated below are matters arising from the current period audit of the financial statements that were communicated or required to be communicated to the audit committee and that: (1) relate to accounts or disclosures that are material to the financial statements and (2) involved our especially challenging, subjective or complex judgments. The communication of critical audit matters does not alter in any way our opinion on the financial statements, taken as a whole, and we are not, by communicating the critical audit matters below, providing separate opinions on the critical audit matters or on the accounts or disclosures to which they relate.

[0001437749-26-018542:auditors_report:11]
47

[0001437749-26-018542:auditors_report:12]
Over-Time Revenue Recognition

[0001437749-26-018542:auditors_report:13]
As described in Notes 3 and 4 of the consolidated financial statements, for certain arrangements, such as contracts to perform research and development, prototype development contracts and certain customized product sales, the Company records revenues using the over-time method, measured by the relationship of costs incurred to total estimated contract costs. The ability to reliably estimate total estimated contract costs is challenging, especially on long-term prototype development contracts, and may require significant analysis and judgments by management to determine the appropriate amount of revenue to recognize.

[0001437749-26-018542:auditors_report:14]
We identified revenue recognition pertaining to customer contracts satisfied over-time as a critical audit matter as there are significant judgments exercised by management in determining total estimated contract costs used in determining revenue recognition. Given the high degree of management judgment involved in various cost estimates that are used in the revenue calculations, the audit effort required to evaluate management’s judgments in determining revenue recognition for the Company’s contracts was extensive and required a high degree of auditor judgment.

[0001437749-26-018542:auditors_report:15]
Our audit procedures related to revenue recognition included the following, among others:

[0001437749-26-018542:auditors_report:16]
|  | ● | We obtained an understanding of the relevant internal controls related to revenue recognition and tested the design and operating effectiveness of those internal controls including management’s review control over the assumptions and key inputs used to recognize over-time revenue. |

[0001437749-26-018542:auditors_report:17]
|  | ● | We selected a sample of contracts with customers and related revenue transactions and performed the following audit procedures: |

[0001437749-26-018542:auditors_report:18]
|  | o | Obtained customer contract, customer change orders (as applicable), related invoices, purchase orders, and management revenue recognition analysis for each testing selection, to evaluate if relevant contractual terms and transaction price were appropriately considered by management and conclusions on revenue recognition method were in accordance with the relevant accounting guidance. |
|  | o | Assessed the validity of data used in the model for completeness and accuracy by comparing selected items from the underlying budget to the source information used to develop the contract budget and agreeing, on a sample basis, costs incurred to source documents. |

[0001437749-26-018542:auditors_report:19]
|  | o | Evaluated management’s estimations of total contract cost by assessing actual costs to date against projections made throughout the course of the contract term. |

[0001437749-26-018542:auditors_report:20]
Valuation of Certain Intangible Assets and Contingent Consideration in Business Combination

[0001437749-26-018542:auditors_report:21]
As described in Note 2 of the consolidated financial statements, the Company completed the acquisition of Comtrafo Indústria de Transformadores Elétricos S.A. ("Comtrafo") on December 5, 2025, for total consideration of $202.9 million. The Company accounted for this transaction under the acquisition method of accounting for business combinations. Accordingly, the total consideration paid was allocated to the assets acquired and liabilities assumed based on their respective fair values, including identified intangible assets of $10.5 million and resulting goodwill of $125.3 million. Of the identified intangible assets acquired, the most significant included a customer relationship intangible asset of $7.9 million. The Company estimated the fair value of the customer relationship intangible asset using the multi-period excess earnings method, which required management to make significant estimates and assumptions related to revenue growth and expense forecasts, customer attrition rates, and the selection of discount rates. In addition, as described in Notes 2 and 13 of the consolidated financial statements, the total consideration included contingent consideration in the form of a seller earnout payment with a fair value of $34.8 million at the acquisition date. The Company estimated the fair value of the contingent consideration upon acquisition using a valuation model that incorporates probability adjusted assumptions that required the use of a management third-party specialist as well as required management to make significant estimates and assumptions related to forecasted earnings before interest, taxes, depreciation, and amortization (EBITDA), EBITDA volatility and discount rate.

[0001437749-26-018542:auditors_report:22]
We identified the valuation of the customer relationship intangible asset and contingent consideration as a critical audit matter because of the significant estimates and assumptions management used in the fair value determination. Auditing management’s forecasted revenue growth and expenses, customer attrition rates, and selection of the discount rate related to the customer relationship intangible asset and forecast of future EBITDA, EBITDA volatility, and the selection of the discount rate along with the complexity of the valuation model related to the contingent consideration required a high degree of auditor judgment and an increased extent of effort when performing audit procedures, including the use of our valuation specialists.

[0001437749-26-018542:auditors_report:23]
Our audit procedures related to the determination of the fair value of the customer relationship intangible asset and contingent consideration, included the following, among others:

[0001437749-26-018542:auditors_report:24]
|  | ● | We evaluated the reasonableness of management’s revenue growth and expenses forecasts and customer attrition rates for the customer relationship intangible asset and forecasted EBITDA and probabilities of achieving these metrics for contingent consideration by comparing the projections to historical results as well as industry benchmarks. |

[0001437749-26-018542:auditors_report:25]
|  | ● | With the assistance of our valuation specialists, we: |

[0001437749-26-018542:auditors_report:26]
|  | o | Evaluated the reasonableness of the Company’s valuation methodologies and verified the accuracy of the calculations in the customer relationship and contingent consideration models, including the performance of corroborating calculations. |
|  | o | Tested the source information underlying the determination of the discount rates and verified the accuracy of the calculations. |

[0001437749-26-018542:auditors_report:27]
|  | o | Evaluated the appropriateness of the approach taken to determine the discount rate and performed a corroborative calculation on the components of the discount rate and compared that analysis to the discount rate selected by management. |

[0001437749-26-018542:auditors_report:28]
Realizability of Deferred Tax Assets

[0001437749-26-018542:auditors_report:29]
As described in Notes 3 and 14 to the consolidated financial statements, as of March 31, 2026, the Company’s deferred tax assets, before valuation allowance, were $177.2 million, and during the year ended March 31, 2026, the Company recorded a deferred tax benefit of $118.4 million related to the reduction of a previously established valuation allowance against deferred tax assets. The Company assesses the likelihood that its deferred tax assets will be realizable from the generation of future taxable income and, to the extent it believes, based upon the weight of available evidence, that it is more likely than not that all or a portion of the deferred tax assets will not be realized, a valuation allowance is established through a charge to income tax expense. In making the determination of the realizability of deferred tax assets and the need for a valuation allowance, management analyzes all available positive and negative evidence, including estimates of projected future taxable income, and recent financial results.

[0001437749-26-018542:auditors_report:30]
We identified the Company’s evaluation of the realizability of deferred tax assets as a critical audit matter because of the significant assumptions and judgments used by management in considering all positive and negative evidence, including projections of future taxable income. Auditing management’s assumptions and judgments regarding the realizability of the Company’s deferred tax assets involved a high degree of auditor judgment and increased audit effort, including the use of our income tax professionals, due to the impact these assumptions and judgments have on the valuation allowance analysis.

[0001437749-26-018542:auditors_report:31]
Our audit procedures related to the estimates and assumptions used in the Company’s evaluation of the realizability of deferred tax assets included the following, among others:

[0001437749-26-018542:auditors_report:32]
|  | ● | We obtained an understanding of the relevant internal controls related to the realizability of deferred tax assets and tested the design and operating effectiveness of those internal controls including management’s evaluation of the positive and negative evidence such as projections of future taxable income. |

[0001437749-26-018542:auditors_report:33]
|  | ● | We tested the completeness and accuracy of the underlying data used by management in developing the projections of future taxable income and confirmed consistency with projections used and assumptions utilized in other areas of the audit. |

[0001437749-26-018542:auditors_report:34]
|  | ● | With the assistance of our income tax professionals, we evaluated the reasonableness of the Company’s projections of future taxable income, including the taxable income by tax jurisdiction, by comparing the projections to historical results and comparing management's prior forecasts to historical results. |

[0001437749-26-018542:auditors_report:35]
RSM US LLP

[0001437749-26-018542:auditors_report:36]
We have served as the Company's auditor since 2013.

[0001437749-26-018542:auditors_report:37]
Boston, Massachusetts

[0001437749-26-018542:auditors_report:38]
May 27, 2026

[0001437749-26-018542:auditors_report:39]
48

[0001437749-26-018542:auditors_report:40]
AMERICAN SUPERCONDUCTOR CORPORATION


## item_9a

[0001437749-26-018542:item_9a:1]
| Item 9A. | CONTROLS AND PROCEDURES |

[0001437749-26-018542:item_9a:2]
Evaluation of Disclosure Controls and Procedures

[0001437749-26-018542:item_9a:3]
Our management, with the participation of our Chief Executive Officer and Chief Financial Officer, evaluated the effectiveness of our disclosure controls and procedures as of March 31, 2026. The term “disclosure controls and procedures,” as defined in Rules 13a-15(e) and 15d-15(e) under the Exchange Act, means controls and other procedures of a company that are designed to ensure that information required to be disclosed by a company in the reports that it files or submits under the Exchange Act is recorded, processed, summarized and reported, within the time periods specified in the SEC’s rules and forms. Disclosure controls and procedures include, without limitation, controls and procedures designed to ensure that information required to be disclosed by a company in the reports that it files or submits under the Exchange Act is accumulated and communicated to the company’s management, including its principal executive and principal financial officers, as appropriate, to allow timely decisions regarding required disclosure. Management recognizes that any controls and procedures, no matter how well designed and operated, can provide only reasonable assurance of achieving their objectives and management necessarily applies its judgment in evaluating the cost-benefit relationship of possible controls and procedures.

[0001437749-26-018542:item_9a:4]
In making this evaluation, our management considered the material weakness in our internal control over financial reporting described below. Based on such evaluation, our Chief Executive Officer and Chief Financial Officer have concluded that our disclosure controls and procedures were not effective at the reasonable assurance level as of March 31, 2026, due to the material weakness in our internal control over financial reporting.

[0001437749-26-018542:item_9a:5]
Material Weakness

[0001437749-26-018542:item_9a:6]
A material weakness is a deficiency, or a combination of deficiencies, in internal control over financial reporting such that there is a reasonable possibility that a material misstatement of the annual or interim financial statements will not be prevented or detected on a timely basis. During the fourth quarter of fiscal 2025, in connection with the preparation of our financial statements for this Annual Report on Form 10-K, management identified the following material weakness: We did not maintain effective internal controls over preparation and review of the initial purchase accounting  and the continuing fair value accounting associated with the Comtrafo Acquisition to ensure the accurate and timely reporting of our financial results related to this acquisition. Specifically, errors went undetected in amounts initially recorded to the opening balance sheet due to controls not operating at the appropriate level of precision during management's review process which could have led to a reasonable possibility of material misstatement to account balances or disclosures.

[0001437749-26-018542:item_9a:7]
Notwithstanding the material weakness, we believe that our financial statements contained in this Annual Report on Form 10-K fairly present our financial position, results of operations and cash flows for the periods covered by this report in all material respects.

[0001437749-26-018542:item_9a:8]
Our management, with the oversight of our audit committee, has initiated steps and plans to take additional measures to remediate the underlying causes of the material weakness, which we currently believe will be primarily through the development and implementation of new levels of precision of management review controls around business acquisitions.

[0001437749-26-018542:item_9a:9]
Management’s Report on Internal Control over Financial Reporting

[0001437749-26-018542:item_9a:10]
Management is responsible for establishing and maintaining adequate internal control over our financial reporting. Internal control over financial reporting is defined in Rules 13a–15(f) and 15d–15(f) under the Exchange Act as a process designed by, or under the supervision of, a company’s chief executive officer and chief financial officer, and effected by the board of directors, management and other personnel, to provide reasonable assurance regarding the reliability of financial reporting and the preparation of financial statements for external purposes in accordance with generally accepted accounting principles, and includes those policies and procedures that:

[0001437749-26-018542:item_9a:11]
(1) Pertain to the maintenance of records that, in reasonable detail, accurately and fairly reflect the transactions and dispositions of assets;

[0001437749-26-018542:item_9a:12]
(2) Provide reasonable assurance that transactions are recorded as necessary to permit preparation of financial statements in accordance with generally accepted accounting principles, and that receipts and expenditures are being made only in accordance with authorizations of management and directors; and

[0001437749-26-018542:item_9a:13]
(3) Provide reasonable assurance regarding prevention or timely detection of unauthorized acquisition, use or disposition of assets that could have a material effect on the financial statements.

[0001437749-26-018542:item_9a:14]
Under the supervision and with the participation of our management, including our Chief Executive Officer and Chief Financial Officer, an evaluation was conducted of the effectiveness of our internal control over financial reporting as of March 31, 2026 based on the Committee of Sponsoring Organizations of the Treadway Commission’s Internal Control – Integrated Framework (2013 Edition). Based on this evaluation, management concluded that our internal control over financial reporting was not effective as of March 31, 2026, due to the material weakness described above. Our evaluation excluded the acquisition of Comtrafo Indústria de Transformadores Elétricos S.A. (referred to as “Comtrafo”), which was acquired on December 5, 2025. Our Consolidated Statement of Operations for the year ended March 31, 2026, included net loss of approximately $3.2 million and our Consolidated Balance Sheet as of March 31, 2026, included total assets of approximately $249.5 million attributable to the Comtrafo acquisition. In accordance with guidance issued by the Securities and Exchange Commission, companies are allowed to exclude acquisitions from their assessment of internal control over financial reporting during the first year subsequent to the acquisition while integrating the acquired operations.

[0001437749-26-018542:item_9a:15]
The effectiveness of our internal control over financial reporting as of March 31, 2026 has been audited by RSM US LLP, an independent registered public accounting firm, as stated in their report which is included herein.

[0001437749-26-018542:item_9a:16]
Changes in Internal Control over Financial Reporting

[0001437749-26-018542:item_9a:17]
During the fiscal year ended March 31, 2026, we completed the process of incorporating the internal controls of NWL into our internal control over financial reporting and extending our Section 404 compliance program under the Sarbanes-Oxley Act of 2002 and the applicable rules and regulations under such act to include the NWL Acquisition. Other than the foregoing, there were no changes to our internal control over financial reporting (as defined in Rules 13a-15(f) and 15d-15(f) under the Exchange Act) during the fiscal quarter ended March 31, 2026 that have materially affected, or are reasonably likely to materially affect, our internal control over financial reporting.

[0001437749-26-018542:item_9a:18]
87

[0001437749-26-018542:item_9a:19]
Report of Independent Registered Public Accounting Firm

[0001437749-26-018542:item_9a:20]
To the Stockholders and the Board of Directors of American Superconductor Corporation

[0001437749-26-018542:item_9a:21]
Opinion on the Internal Control Over Financial Reporting

[0001437749-26-018542:item_9a:22]
We have audited American Superconductor Corporation's (the Company) internal control over financial reporting as of March 31, 2026, based on criteria established in Internal Control — Integrated Framework issued by the Committee of Sponsoring Organizations of the Treadway Commission in 2013. In our opinion, because of the effect of the material weakness described below on the achievement of the objectives of the control criteria, the Company has not maintained effective internal control over financial reporting as of March 31, 2026, based on criteria established in Internal Control — Integrated Framework issued by the Committee of Sponsoring Organizations of the Treadway Commission in 2013.

[0001437749-26-018542:item_9a:23]
We have also audited, in accordance with the standards of the Public Company Accounting Oversight Board (United States) (PCAOB), the consolidated financial statements of the Company and our report dated May 27, 2026, expressed an unqualified opinion.

[0001437749-26-018542:item_9a:24]
A material weakness is a deficiency, or a combination of deficiencies, in internal control over financial reporting, such that there is a reasonable possibility that a material misstatement of the company's annual or interim financial statements will not be prevented or detected on a timely basis. The following material weakness has been identified and included in management's assessment. The Company did not maintain effective internal controls over the preparation and review of the initial purchase accounting and the continuing fair value accounting associated with the Comtrafo Indústria de Transformadores Elétricos S.A. ("Comtrafo") acquisition to ensure the accurate and timely reporting of the Company’s financial results related to this acquisition due to controls over the acquisition not operating at the appropriate level of precision. This material weakness was considered in determining the nature, timing and extent of audit tests applied in our audit of the fiscal 2025 financial statements, and this report does not affect our report dated May 27, 2026, on those financial statements.

[0001437749-26-018542:item_9a:25]
As described in Management’s Report on Internal Control over Financial Reporting, management has excluded Comtrafo from its assessment of internal control over financial reporting as of March 31, 2026, because it was acquired by the Company in a business combination in fiscal 2025. We have also excluded Comtrafo from our audit of internal control over financial reporting as of March 31, 2026. Comtrafo is a wholly owned subsidiary which contributed a loss of $3.2 million to the consolidated statement of operations for the year-ended March 31, 2026 and $249.5 million of total assets attributable to the consolidated balance sheet as of March 31, 2026.

[0001437749-26-018542:item_9a:26]
Basis for Opinion

[0001437749-26-018542:item_9a:27]
The Company’s management is responsible for maintaining effective internal control over financial reporting and for its assessment of the effectiveness of internal control over financial reporting in the accompanying Management’s Report on Internal Control over Financial Reporting. Our responsibility is to express an opinion on the Company’s internal control over financial reporting based on our audit. We are a public accounting firm registered with the PCAOB and are required to be independent with respect to the Company in accordance with U.S. federal securities laws and the applicable rules and regulations of the Securities and Exchange Commission and the PCAOB.

[0001437749-26-018542:item_9a:28]
We conducted our audit in accordance with the standards of the PCAOB. Those standards require that we plan and perform the audit to obtain reasonable assurance about whether effective internal control over financial reporting was maintained in all material respects. Our audit included obtaining an understanding of internal control over financial reporting, assessing the risk that a material weakness exists, and testing and evaluating the design and operating effectiveness of internal control based on the assessed risk. Our audit also included performing such other procedures as we considered necessary in the circumstances. We believe that our audit provides a reasonable basis for our opinion.

[0001437749-26-018542:item_9a:29]
Definition and Limitations of Internal Control Over Financial Reporting

[0001437749-26-018542:item_9a:30]
A company's internal control over financial reporting is a process designed to provide reasonable assurance regarding the reliability of financial reporting and the preparation of financial statements for external purposes in accordance with generally accepted accounting principles. A company's internal control over financial reporting includes those policies and procedures that (1) pertain to the maintenance of records that, in reasonable detail, accurately and fairly reflect the transactions and dispositions of the assets of the company; (2) provide reasonable assurance that transactions are recorded as necessary to permit preparation of financial statements in accordance with generally accepted accounting principles, and that receipts and expenditures of the company are being made only in accordance with authorizations of management and directors of the company; and (3) provide reasonable assurance regarding prevention or timely detection of unauthorized acquisition, use or disposition of the company's assets that could have a material effect on the financial statements.

[0001437749-26-018542:item_9a:31]
Because of its inherent limitations, internal control over financial reporting may not prevent or detect misstatements. Also, projections of any evaluation of effectiveness to future periods are subject to the risk that controls may become inadequate because of changes in conditions, or that the degree of compliance with the policies or procedures may deteriorate.

[0001437749-26-018542:item_9a:32]
/s/ RSM US LLP

[0001437749-26-018542:item_9a:33]
Boston, Massachusetts

[0001437749-26-018542:item_9a:34]
May 27, 2026

[0001437749-26-018542:item_9a:35]
88
