# AMSC MD&A — 0001437749-25-033351


## mdna

[0001437749-25-033351:mdna:1]
[same as prior period, unchanged from 0001437749-25-023968:mdna:1]

[0001437749-25-033351:mdna:2]
[same as prior period, unchanged from 0001437749-25-023968:mdna:2]

[0001437749-25-033351:mdna:3]
[same as prior period, unchanged from 0001437749-25-023968:mdna:3]

[0001437749-25-033351:mdna:4]
[same as prior period, unchanged from 0001437749-25-023968:mdna:4]

[0001437749-25-033351:mdna:5]
[same as prior period, unchanged from 0001437749-25-023968:mdna:5]

[0001437749-25-033351:mdna:6]
[same as prior period, unchanged from 0001437749-25-023968:mdna:6]

[0001437749-25-033351:mdna:7]
[same as prior period, unchanged from 0001437749-25-023968:mdna:7]

[0001437749-25-033351:mdna:8]
[same as prior period, unchanged from 0001437749-25-023968:mdna:8]

[0001437749-25-033351:mdna:9]
[same as prior period, unchanged from 0001437749-25-023968:mdna:9]

[0001437749-25-033351:mdna:10]
[same as prior period, unchanged from 0001437749-25-023968:mdna:10]

[0001437749-25-033351:mdna:11]
Changes in macroeconomic conditions arising from various reasons, such as the ongoing war between Russia and Ukraine, tariffs, trade restrictions and resulting trade conflicts, labor force availability, sourcing, material delays and global supply chain disruptions, could have a material adverse effect on our business, financial condition and results of operations.

[0001437749-25-033351:mdna:12]
[same as prior period, unchanged from 0001437749-25-023968:mdna:12]

[0001437749-25-033351:mdna:13]
[same as prior period, unchanged from 0001437749-25-023968:mdna:13]

[0001437749-25-033351:mdna:14]
[same as prior period, unchanged from 0001437749-25-023968:mdna:14]

[0001437749-25-033351:mdna:15]
[same as prior period, unchanged from 0001437749-25-023968:mdna:15]

[0001437749-25-033351:mdna:16]
[same as prior period, unchanged from 0001437749-25-023968:mdna:16]

[0001437749-25-033351:mdna:17]
Three and six months ended September 30, 2025, compared to the three and six months ended September 30, 2024

[0001437749-25-033351:mdna:18]
[same as prior period, unchanged from 0001437749-25-023968:mdna:18]

[0001437749-25-033351:mdna:19]
Total revenues increased 21% to $65.9 million for the three months ended September 30, 2025 and total revenues increased 46% to $138.2 million for the six months ended September 30, 2025 compared to $54.5 million and $94.8 for the three and six months ended September 30, 2024, respectively. Our revenues are summarized as follows (in thousands):

[0001437749-25-033351:mdna:20]
|  |  | Three Months Ended September 30, |  |  | Six Months Ended September 30, |  |
|  |  | 2025 |  |  | 2024 |  |  | 2025 |  |  | 2024 |  |
| Revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Grid |  | $ | 54,342 |  |  | $ | 46,936 |  |  | $ | 114,429 |  |  | $ | 79,272 |  |
| Wind |  |  | 11,520 |  |  |  | 7,535 |  |  |  | 23,791 |  |  |  | 15,489 |  |
| Total |  | $ | 65,862 |  |  | $ | 54,471 |  |  | $ | 138,220 |  |  | $ | 94,761 |  |

[0001437749-25-033351:mdna:21]
Our Grid business segment accounted for 83% of total revenues for both the three and six months ended September 30, 2025, compared to 86% and 84% for the three and six months ended September 30, 2024, respectively. Our Grid business segment revenues increased 16% to $54.3 million in the three months ended September 30, 2025, from $46.9 million in the three months ended September 30, 2024. Our Grid business segment revenues increased 44% to $114.4 million in the six months ended September 30, 2025, from $79.3 million in the six months ended September 30, 2024. The increase in the Grid business segment revenues in the three and six months ended September 30, 2025, compared to the three and six months ended September 30, 2024 was driven by the acquisition of NWL, increased shipments of new energy power systems, and additional ship protection systems revenues than in the prior year periods.

[0001437749-25-033351:mdna:22]
Our Wind business segment accounted for 17% of total revenues for both the three and six months ended September 30, 2025, compared to 14% and 16% for the three and six months ended September 30, 2024, respectively. Revenues in the Wind business segment increased 53% to $11.5 million in the three months ended September 30, 2025, from $7.5 million in the three months ended September 30, 2024. Revenues in the Wind business segment increased 54% to $23.8 million in the six months ended September 30, 2025, from $15.5 million in the six months ended September 30, 2024. The increase during the three and six months ended September 30, 2025, compared to the three and six months ended September 30, 2024, was driven by additional shipments of electrical control systems ("ECS").

[0001437749-25-033351:mdna:23]
[same as prior period, unchanged from 0001437749-25-023968:mdna:23]

[0001437749-25-033351:mdna:24]
Cost of revenues increased by 17% to $45.4 million for the three months ended September 30, 2025, compared to $38.9 million for the three months ended September 30, 2024. Cost of revenues increased by 39% to $93.3 million for the six months ended September 30, 2025, compared to $66.9 million for the six months ended September 30, 2024. Gross margin was 31% and 33% for the three and six months ended September 30, 2025, respectively, compared to 29% for both the three and six months ended September 30, 2024. The increase in gross margin in the three and six months ended September 30, 2025 was due to higher revenues, a favorable product mix and favorable impacts across the business due to pricing increases across our product lines.

[0001437749-25-033351:mdna:25]
[same as prior period, unchanged from 0001437749-25-023968:mdna:25]

[0001437749-25-033351:mdna:26]
[same as prior period, unchanged from 0001437749-25-023968:mdna:26]

[0001437749-25-033351:mdna:27]
Research and development ("R&D") expenses increased 41% in the three months ended September 30, 2025, to $3.7 million from $2.6 million in the three months ended September 30, 2024. R&D expenses increased 63% in the six months ended September 30, 2025, to $8.0 million from $4.9 million in the six months ended September 30, 2024. The increase in the three and six months ended September 30, 2025 was driven primarily by the addition of NWL R&D expenses, higher overall compensation expense and additional stock-based compensation expense.

[0001437749-25-033351:mdna:28]
[same as prior period, unchanged from 0001437749-25-023968:mdna:28]

[0001437749-25-033351:mdna:29]
Selling, general and administrative ("SG&A") expenses increased 27% in the three months ended September 30, 2025, to $13.4 million from $10.5 million in the three ended September 30, 2024. SG&A expenses increased 42% in the six months ended September 30, 2025, to $27.6 million from $19.4 million in the six months ended September 30, 2024. The increase in SG&A expense in the three and six months ended September 30, 2025 was driven primarily by the addition of NWL SG&A expenses, higher overall compensation expense and additional stock-based compensation expense.

[0001437749-25-033351:mdna:30]
[same as prior period, unchanged from 0001437749-25-023968:mdna:30]

[0001437749-25-033351:mdna:31]
We recorded amortization expense related to our core technology and know-how and customer relationships of $0.3 million in the three months ended September 30, 2025, and $0.4 million in the three months ended September 30, 2024. We recorded amortization expense related to our core technology and know-how and customer relationships of $0.7 million in the six months ended September 30, 2025, and $0.8 million in the six months ended September 30, 2024. The decrease in amortization expense in the three and six months ended September 30, 2025 is a result of using the economic consumption method as the basis to amortize the acquired customer relationship intangible assets from Northeast Power Systems, Inc. ("NEPSI") and Neeltran, Inc.

[0001437749-25-033351:mdna:32]
[same as prior period, unchanged from 0001437749-25-023968:mdna:32]

[0001437749-25-033351:mdna:33]
The change in fair value of our contingent consideration for the earnout payment on the acquisition of NEPSI resulted in a gain of $0.5 million from a decrease in fair value and a loss of $3.4 million resulting from an increase in fair value in the three and six months ended September 30, 2024, respectively. During the three and six months ended September 30, 2024, we issued 300,000 shares of common stock of the Company to the selling stockholders following certification of the achievement of specified earnout revenue objectives. There was no activity in the three and six months ended September 30, 2025 as the contingent consideration was settled during the prior fiscal year.

[0001437749-25-033351:mdna:34]
[same as prior period, unchanged from 0001437749-25-023968:mdna:34]

[0001437749-25-033351:mdna:35]
[same as prior period, unchanged from 0001437749-25-023968:mdna:35]

[0001437749-25-033351:mdna:36]
|  |  | Three Months Ended September 30, |  |  | Six Months Ended September 30, |  |
|  |  | 2025 |  |  | 2024 |  |  | 2025 |  |  | 2024 |  |
| Operating income (loss): |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Grid |  | $ | 1,278 |  |  | $ | 1,570 |  |  | $ | 5,435 |  |  | $ | 1,333 |  |
| Wind |  |  | 1,687 |  |  |  | 439 |  |  |  | 3,175 |  |  |  | 1,306 |  |
| Unallocated corporate expenses |  |  | — |  |  |  | (2,762 | ) |  |  | — |  |  |  | (6,682 | ) |
| Total |  | $ | 2,965 |  |  | $ | (753 | ) |  | $ | 8,610 |  |  | $ | (4,043 | ) |

[0001437749-25-033351:mdna:37]
Our Grid business segment generated operating income of $1.3 million and $5.4 million in the three and six months ended September 30, 2025, respectively, compared to an operating income of $1.6 million and $1.3 million in the three and six months ended September 30, 2024, respectively. The decrease in the Grid business segment operating income in the three months ended September 30, 2025 was due to higher overall compensation expense and higher stock comp expense. The improvement in the Grid business segment operating income in the six months ended September 30, 2025 was due to higher revenues and gross margins.

[0001437749-25-033351:mdna:38]
Our Wind business segment generated operating income of $1.7 million and $3.2 million in the three and six months ended September 30, 2025, respectively, compared to operating income of $0.4 million and $1.3 million in the three and six months ended September 30, 2024, respectively. The increase in the Wind business segment operating income in the three and six months ended September 30, 2025 was due to higher revenues and gross margins from increased sales of ECS units.

[0001437749-25-033351:mdna:39]
Unallocated corporate expenses included a net loss on contingent consideration of $2.8 million and $6.7 million in the three and six months ended September 30, 2024, respectively.

[0001437749-25-033351:mdna:40]
[same as prior period, unchanged from 0001437749-25-023968:mdna:40]

[0001437749-25-033351:mdna:41]
Interest income, net, was $2.3 million and $3.2 million in the three and six months ended September 30, 2025, respectively, compared to $1.0 million and $2.1 million in the three and six months ended September 30, 2024, respectively. The increase in interest income, net, in the three and six months ended September 30, 2025 was due to higher cash balances primarily generated from the public offering completed in June 2025.

[0001437749-25-033351:mdna:42]
Other expense, net

[0001437749-25-033351:mdna:43]
Other expense, net, was $0.4 million and less than $0.1 million in the three and six months ended September 30, 2025, respectively, compared to $0.3 million and $0.5 million in the three and six months ended September 30, 2024, respectively. The increase in other expense, net, during the three months ended September 30, 2025, compared to the three months ended September 30, 2024 was driven by unfavorable fluctuations in foreign currencies. The improvement in other expense, net, during the six months ended September 30, 2025, compared to the six months ended September 30, 2024, was driven by the impacts of favorable fluctuations in foreign currencies and gain on earnings from our NWL Pacific joint venture during the periods.

[0001437749-25-033351:mdna:44]
[same as prior period, unchanged from 0001437749-25-023968:mdna:44]

[0001437749-25-033351:mdna:45]
Income tax expense was $0.1 million and $0.3 million in the three and six months ended September 30, 2025, respectively, compared to income tax benefit of $5.0 million and $4.8 million in the three and six months ended September 30, 2024, respectively. The increase in income tax expense was a result of the release of the valuation allowance due to the recording of the deferred tax liability from the acquisition of Megatran in the prior year.

[0001437749-25-033351:mdna:46]
Net income

[0001437749-25-033351:mdna:47]
Net income was $4.8 million and $11.5 million in the three and six months ended September 30, 2025, respectively, compared to $4.9 million and $2.4 million in the three and six months ended September 30, 2024, respectively. The decrease in net income for the three months ended September 30, 2025 was driven primarily by the benefit of release of the valuation allowance due to the recording of the deferred tax liability from the acquisition of Megatran in the prior year. The improvement in net income for the six months ended September 30, 2025 was driven primarily by increased revenues and gross margins.

[0001437749-25-033351:mdna:48]
[same as prior period, unchanged from 0001437749-25-023968:mdna:48]

[0001437749-25-033351:mdna:49]
[same as prior period, unchanged from 0001437749-25-023968:mdna:49]

[0001437749-25-033351:mdna:50]
We define non-GAAP net income as net income before stock-based compensation, acquisition costs, amortization of acquisition-related intangibles, change in fair value of contingent consideration, and other non-cash or unusual charges. We believe non-GAAP net income assists management and investors in comparing our performance across reporting periods on a consistent basis by excluding these non-cash charges and other items that we do not believe are indicative of our core operating performance. In addition, we use non-GAAP net income as a factor to evaluate the effectiveness of our business strategies. A reconciliation of GAAP to non-GAAP net income is set forth in the table below (in thousands, except per share data):

[0001437749-25-033351:mdna:51]
|  |  | Three Months Ended September 30, |  |  | Six Months Ended September 30, |  |
|  |  | 2025 |  |  | 2024 |  |  | 2025 |  |  | 2024 |  |
| Net income |  | $ | 4,750 |  |  | $ | 4,887 |  |  | $ | 11,474 |  |  | $ | 2,363 |  |
| Stock-based compensation |  |  | 3,766 |  |  |  | 843 |  |  |  | 8,292 |  |  |  | 2,072 |  |
| Acquisition costs |  |  | — |  |  |  | 850 |  |  |  | — |  |  |  | 1,080 |  |
| Amortization of acquisition-related intangibles |  |  | 337 |  |  |  | 608 |  |  |  | 674 |  |  |  | 1,020 |  |
| Change in fair value of contingent consideration |  |  | — |  |  |  | 2,762 |  |  |  | — |  |  |  | 6,682 |  |
| Non-GAAP net income |  | $ | 8,853 |  |  | $ | 9,950 |  |  | $ | 20,440 |  |  | $ | 13,217 |  |
| Non-GAAP net income per share - basic |  | $ | 0.20 |  |  | $ | 0.27 |  |  | $ | 0.50 |  |  | $ | 0.36 |  |
| Non-GAAP net income per share - diluted |  | $ | 0.20 |  |  | $ | 0.27 |  |  | $ | 0.49 |  |  | $ | 0.36 |  |
| Weighted average shares outstanding - basic |  |  | 43,242 |  |  |  | 36,952 |  |  |  | 41,070 |  |  |  | 36,317 |  |
| Weighted average shares outstanding - diluted |  |  | 44,210 |  |  |  | 37,499 |  |  |  | 41,988 |  |  |  | 36,951 |  |

[0001437749-25-033351:mdna:52]
We generated non-GAAP net income of $8.9 million and $20.4 million, or $0.20 and $0.50 per share, for the three and six months ended September 30, 2025, respectively, compared to a non-GAAP net income of $10.0 million and $13.2 million, or $0.27 and $0.36 per share, for the three and six months ended September 30, 2024, respectively. For the three months ended September 30, 2025, the decrease in non-GAAP net income was a result of the release of the valuation allowance due to the recording of the deferred tax liability from the acquisition of Megatran in the prior year, partially offset by higher revenues and gross margins. The improvement in the non-GAAP net income for the six months ended September 30, 2025, was due to higher revenues and gross margins.

[0001437749-25-033351:mdna:53]
[same as prior period, unchanged from 0001437749-25-023968:mdna:53]

[0001437749-25-033351:mdna:54]
[same as prior period, unchanged from 0001437749-25-023968:mdna:54]

[0001437749-25-033351:mdna:55]
The Company’s primary sources of liquidity are internally generated cash provided by operating activities, our cash and cash equivalents on hand, along with access to capital markets, including through our currently effective Registration Statements on Form S-3. We believe that these sources of liquidity are sufficient to meet both our short-term and reasonably foreseeable long-term requirements and obligations. As of September 30, 2025, we had cash and cash equivalents of $212.9 million.

[0001437749-25-033351:mdna:56]
[same as prior period, unchanged from 0001437749-25-023968:mdna:56]

[0001437749-25-033351:mdna:57]
[same as prior period, unchanged from 0001437749-25-023968:mdna:57]

[0001437749-25-033351:mdna:58]
As of September 30, 2025, we had cash, cash equivalents and restricted cash of $218.8 million, compared to $85.4 million as of March 31, 2025, an increase of $133.4 million. As of September 30, 2025, we had $3.4 million in cash, cash equivalents, and restricted cash in foreign bank accounts. Our cash, cash equivalents, and restricted cash are summarized as follows (in thousands):

[0001437749-25-033351:mdna:59]
|  |  | September 30, 2025 |  |  | March 31, 2025 |  |
| Cash and cash equivalents |  | $ | 212,891 |  |  | $ | 79,494 |  |
| Restricted cash |  |  | 5,865 |  |  |  | 5,887 |  |
| Total cash, cash equivalents, and restricted cash |  | $ | 218,756 |  |  | $ | 85,381 |  |

[0001437749-25-033351:mdna:60]
For the six months ended September 30, 2025, net cash provided by operating activities was $10.6 million, compared to $16.1 million for the six months ended September 30, 2024. The decrease in cash flows provided by operating activities in the six months ended September 30, 2025 was due primarily to changes in deferred revenue, offset by change in accounts payable and accrued expenses, accounts receivable, deferred income taxes, and stock-based compensation expense.

[0001437749-25-033351:mdna:61]
For the six months ended September 30, 2025, net cash used in investing activities was $2.1 million, compared to $33.5 million for the six months ended September 30, 2024. The decrease in net cash used in investing activities was primarily due to cash paid for the NWL acquisition and related contingent consideration in the prior year.

[0001437749-25-033351:mdna:62]
For the six months ended September 30, 2025, net cash provided by financing activities was $124.8 million compared to cash used in financing activities of $0.1 million for the six months ended September 30, 2024. The increase in net cash provided by financing activities was due to the equity raise in June 2025.

[0001437749-25-033351:mdna:63]
As of September 30, 2025, we had $3.0 million of restricted cash included in long-term assets and $2.9 million of restricted cash included in current assets. At March 31, 2025, we had $4.3 million of restricted cash included in long-term assets and $1.6 million of restricted cash in current assets. These amounts included in restricted cash primarily represent collateral deposits to secure surety bonds and letters of credit for various customer contracts. These deposits are held in interest bearing accounts.

[0001437749-25-033351:mdna:64]
We are a party to many contractual obligations involving commitments to make payments to third parties. These obligations impact our short-term and long-term liquidity and capital resource needs. Certain contractual obligations are reflected on the condensed consolidated balance sheet as of September 30, 2025, while others are considered future commitments. We have various contractual arrangements, under which we have committed to purchase certain minimum quantities of goods or services on an annual basis. For information regarding our other contractual obligations, refer to Note 14, "Contingent Consideration," Note 15, "Leases" and Note 16, "Commitments and Contingencies" to our condensed consolidated financial statements included elsewhere in this Quarterly Report on Form 10-Q. There have been no material changes to our contractual obligations from those disclosed in our Annual Report on Form 10-K for the fiscal year ended March 31, 2025.

[0001437749-25-033351:mdna:65]
We believe we have sufficient available liquidity to fund our operations and capital expenditures for the next twelve months. We raised $124.6 million, net of offering expenses, through an equity raise in June 2025. In addition, we may seek to raise additional capital, which could be in the form of loans, convertible debt or equity, to fund our operating requirements and capital expenditures. There can be no assurance that we will be able to raise additional capital on favorable terms or at all or execute on any other means of improving our liquidity as described above.  Additionally, the impact of global sources of instability, including the ongoing war between Russia and Ukraine, tariffs, trade restrictions and resulting trade conflicts, instability of financial institutions and political instability in the United States, on the global financial markets may reduce our ability to raise additional capital, if necessary, which could negatively impact our liquidity.

[0001437749-25-033351:mdna:66]
Legal Proceedings

[0001437749-25-033351:mdna:67]
[same as prior period, unchanged from 0001437749-25-023968:mdna:67]

[0001437749-25-033351:mdna:68]
[same as prior period, unchanged from 0001437749-25-023968:mdna:68]

[0001437749-25-033351:mdna:69]
In December 2023, the FASB issued ASU 2023-09, 
    Income Taxes (Topic 740): Improvements to Income Tax Disclosures. The amendments in ASU 2023-09 address investor requests for more transparency about income tax information through improvements to income tax disclosures primarily related to the rate reconciliation and income taxes paid information. Following the release of ASU 2023-09 in December 2023, the effective date was annual reporting periods beginning after December 15, 2024. As of
    September 30, 2025, we are evaluating the impact on our consolidated financial statements.

[0001437749-25-033351:mdna:70]
In March 2024, the FASB issued ASU 2024-02, Codification Improvements—Amendments to Remove References to the Concepts Statements. The amendments in ASU 2024-02 contain amendments to the Codification that remove references to various FASB Concepts Statements. Following the release of ASU 2024-02 in March 2024, the effective date was annual reporting periods beginning after December 15, 2024. As of September 30, 2025, we are evaluating the impact on our consolidated financial statements.

[0001437749-25-033351:mdna:71]
In November 2024, the FASB issued ASU 2024-03, Income Statement—Reporting Comprehensive Income—Expense Disaggregation Disclosures. The amendments in ASU 2024-03 address investor requests for more disclosure of disaggregated financial reporting information about expenses presented in the income statement. Following the release of ASU 2024-03 in November 2024, the effective date will be annual reporting periods beginning after December 15, 2026. As of September 30, 2025, we are evaluating the impact on our consolidated financial statements.

[0001437749-25-033351:mdna:72]
We do not believe that, outside of those disclosed here, there are any other recently issued accounting pronouncements that will have a material impact on our condensed consolidated financial statements.
