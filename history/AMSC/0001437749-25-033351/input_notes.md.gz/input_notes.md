# AMSC notes — 0001437749-25-033351


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0001437749-25-033351:notes:1]
[same as prior period, unchanged from 0001437749-25-023968:notes:1]

[0001437749-25-033351:notes:2]
[same as prior period, unchanged from 0001437749-25-023968:notes:2]

[0001437749-25-033351:notes:3]
[same as prior period, unchanged from 0001437749-25-023968:notes:3]

[0001437749-25-033351:notes:4]
These unaudited condensed consolidated financial statements of the Company have been prepared on a going concern basis in accordance with United States generally accepted accounting principles (“GAAP”) and the Securities and Exchange Commission’s (“SEC”) instructions to Form 10-Q. All significant intercompany accounts and transactions are eliminated in consolidation. Investments in entities in which we do not have a controlling interest are accounted for under the equity method of accounting. The going concern basis of presentation assumes that the Company will continue operations and will be able to realize its assets and discharge its liabilities and commitments in the normal course of business. Certain information and footnote disclosures normally included in the condensed consolidated financial statements prepared in accordance with GAAP have been omitted pursuant to those instructions. The year-end balance sheet data was derived from audited financial statements but does not include all disclosures required by GAAP. The unaudited condensed consolidated financial statements, in the opinion of management, reflect all adjustments (consisting of normal recurring adjustments) necessary for a fair statement of the results for the interim periods ended  September 30, 2025 and 2024, and the financial position at  September 30, 2025; however, these results are not necessarily indicative of results which  may be expected for the full year. The interim condensed consolidated financial statements, and notes thereto, should be read in conjunction with the audited condensed consolidated financial statements for the year ended  March 31, 2025, and notes thereto, included in the Company’s Annual Report on Form 10-K for the year ended  March 31, 2025 filed with the SEC on  May 21, 2025.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001437749-25-033351:notes:5]
[same as prior period, unchanged from 0001437749-25-023968:notes:5]

[0001437749-25-033351:notes:6]
[same as prior period, unchanged from 0001437749-25-023968:notes:6]

[0001437749-25-033351:notes:7]
[same as prior period, unchanged from 0001437749-25-023968:notes:7]

[0001437749-25-033351:notes:8]
[same as prior period, unchanged from 0001437749-25-023968:notes:8]

[0001437749-25-033351:notes:9]
[same as prior period, unchanged from 0001437749-25-023968:notes:9]

[0001437749-25-033351:notes:10]
[same as prior period, unchanged from 0001437749-25-023968:notes:10]

[0001437749-25-033351:notes:11]
[same as prior period, unchanged from 0001437749-25-023968:notes:11]

[0001437749-25-033351:notes:12]
[same as prior period, unchanged from 0001437749-25-023968:notes:12]

[0001437749-25-033351:notes:13]
[same as prior period, unchanged from 0001437749-25-023968:notes:13]

[0001437749-25-033351:notes:14]
[same as prior period, unchanged from 0001437749-25-023968:notes:14]

[0001437749-25-033351:notes:15]
[same as prior period, unchanged from 0001437749-25-023968:notes:15]

[0001437749-25-033351:notes:16]
[same as prior period, unchanged from 0001437749-25-023968:notes:16]

[0001437749-25-033351:notes:17]
[same as prior period, unchanged from 0001437749-25-023968:notes:17]

[0001437749-25-033351:notes:18]
Goodwill represents the value associated with the acquired workforce and expected synergies related to the business combination of the two companies. Goodwill resulting from the NWL Acquisition was assigned to the Company’s Grid business segment. Goodwill recognized in the NWL Acquisition is not deductible for tax purposes.

[0001437749-25-033351:notes:19]
[same as prior period, unchanged from 0001437749-25-023968:notes:19]

[0001437749-25-033351:notes:20]
The unaudited pro forma condensed consolidated statement of operations for the three and six months ended  September 30, 2024 presented as if the NWL Acquisition had occurred on  April 1, 2024, is as follows:

[0001437749-25-033351:notes:21]
|  |  | Three Months Ended September 30, 2024 |  |  | Six Months Ended September 30, 2024 |  |
| Net Revenue |  | $ | 58,722 |  |  | $ | 118,032 |  |
| Operating income (loss) |  |  | 81 |  |  |  | (4,079 | ) |
| Net income (loss) |  | $ | 635 |  |  | $ | (2,748 | ) |
| Net income per common share |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.02 |  |  | $ | (0.07 | ) |
| Diluted |  | $ | 0.02 |  |  | $ | (0.07 | ) |
| Shares - basic |  |  | 37,404 |  |  |  | 37,189 |  |
| Shares - diluted |  |  | 37,950 |  |  |  | 37,189 |  |

[0001437749-25-033351:notes:22]
[same as prior period, unchanged from 0001437749-25-023968:notes:22]

[0001437749-25-033351:notes:23]
NWL contributed $16.4 million of revenue and $2.0 million in net income for the Company for the three months ended  September 30, 2025. NWL contributed $34.1 million of revenue and $4.5 million in net income for the Company for the six months ended  September 30, 2025. Amortization expense of less than $0.1 million and $0.1 million is included in the three and six months ended  September 30, 2025, respectively, as a result of the acquired intangible assets from the NWL Acquisition.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001437749-25-033351:notes:24]
[same as prior period, unchanged from 0001437749-25-023968:notes:24]

[0001437749-25-033351:notes:25]
The Company’s revenues in its Grid segment are derived primarily through enabling the transmission and distribution of power, providing planning services that allow it to identify power grid needs and risks, and developing ship protection systems for the U.S. Navy. The Company’s revenues in its Wind segment are derived primarily through supplying advanced power electronics and control systems, licensing its highly engineered wind turbine designs, and providing extensive customer support services to wind turbine manufacturers. The Company records revenue based on a five-step model in accordance with Accounting Standards Codification ("ASC") 606. For its customer contracts, the Company identifies the performance obligations, determines the transaction price, allocates the contract transaction price to the performance obligations, and recognizes the revenue when (or as) control of goods or services is transferred to the customer. For both the three and six months ended  September 30, 2025, 90% of revenue was recognized at the point in time when control transferred to the customer, with the remainder being recognized over time. For the three and six months ended  September 30, 2024, 90% and 89%, respectively, of revenue was recognized at the point in time when control transferred to the customer, with the remainder being recognized over time.

[0001437749-25-033351:notes:26]
[same as prior period, unchanged from 0001437749-25-023968:notes:26]

[0001437749-25-033351:notes:27]
[same as prior period, unchanged from 0001437749-25-023968:notes:27]

[0001437749-25-033351:notes:28]
[same as prior period, unchanged from 0001437749-25-023968:notes:28]

[0001437749-25-033351:notes:29]
[same as prior period, unchanged from 0001437749-25-023968:notes:29]

[0001437749-25-033351:notes:30]
[same as prior period, unchanged from 0001437749-25-023968:notes:30]

[0001437749-25-033351:notes:31]
Infrequently, the Company receives requests from customers to hold product being purchased from us for a valid business purpose. The Company recognizes revenues for such arrangements provided the transaction meets, at a minimum, the following criteria: the reason for the bill-and-hold arrangement must be substantive; the product must be identified separately as belonging to the customer; the product currently must be ready for physical transfer to the customer; the entity cannot have the ability to use the product or to direct it to another customer. Revenue for the three and six months ended  September 30, 2025 included $7.9 million from such held transactions. There were no such transactions for the three and six months ended  September 30, 2024.

[0001437749-25-033351:notes:32]
The Company records revenue net of sales tax, value added tax, excise tax and other taxes collected concurrent with revenue-producing activities. The Company has elected to recognize the cost for freight and shipping when control over the products sold passes to customers and revenue is recognized. The Company has elected to recognize incremental costs of obtaining a contract as expense when incurred except in contracts where the amortization period would exceed twelve months. As of  September 30, 2025 and  March 31, 2025, the Company's capitalized incremental contract costs were not material. The Company has elected not to adjust the promised amount of consideration for the effects of a significant financing component if the period of financing is twelve months or less. The Company has elected to recognize revenue based on the as invoiced practical expedient if there is a right to consideration from a customer in an amount that corresponds directly with the value of the Company's performance.

[0001437749-25-033351:notes:33]
[same as prior period, unchanged from 0001437749-25-023968:notes:32]

[0001437749-25-033351:notes:34]
[same as prior period, unchanged from 0001437749-25-023968:notes:33]

[0001437749-25-033351:notes:35]
|  |  | Three Months Ended September 30, 2025 |  |  | Six Months Ended September 30, 2025 |  |
| Product Line: |  | Grid |  |  | Wind |  |  | Grid |  |  | Wind |  |
| Equipment and systems |  | $ | 49,951 |  |  | $ | 11,223 |  |  | $ | 105,574 |  |  | $ | 23,103 |  |
| Services and technology development |  |  | 4,391 |  |  |  | 297 |  |  |  | 8,855 |  |  |  | 688 |  |
| Total |  | $ | 54,342 |  |  | $ | 11,520 |  |  | $ | 114,429 |  |  | $ | 23,791 |  |
| Region: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas |  | $ | 47,400 |  |  | $ | 16 |  |  | $ | 85,421 |  |  | $ | 16 |  |
| Asia Pacific |  |  | 4,026 |  |  |  | 11,425 |  |  |  | 22,329 |  |  |  | 23,696 |  |
| EMEA |  |  | 2,916 |  |  |  | 79 |  |  |  | 6,679 |  |  |  | 79 |  |
| Total |  | $ | 54,342 |  |  | $ | 11,520 |  |  | $ | 114,429 |  |  | $ | 23,791 |  |

[0001437749-25-033351:notes:36]
|  |  | Three Months Ended September 30, 2024 |  |  | Six Months Ended September 30, 2024 |  |
| Product Line: |  | Grid |  |  | Wind |  |  | Grid |  |  | Wind |  |
| Equipment and systems |  | $ | 43,747 |  |  | $ | 7,166 |  |  | $ | 74,452 |  |  | $ | 14,591 |  |
| Services and technology development |  |  | 3,189 |  |  |  | 369 |  |  |  | 4,820 |  |  |  | 898 |  |
| Total |  | $ | 46,936 |  |  | $ | 7,535 |  |  | $ | 79,272 |  |  | $ | 15,489 |  |
| Region: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas |  | $ | 43,479 |  |  | $ | 1 |  |  | $ | 73,957 |  |  | $ | 1 |  |
| Asia Pacific |  |  | 790 |  |  |  | 7,531 |  |  |  | 1,989 |  |  |  | 15,483 |  |
| EMEA |  |  | 2,667 |  |  |  | 3 |  |  |  | 3,326 |  |  |  | 5 |  |
| Total |  | $ | 46,936 |  |  | $ | 7,535 |  |  | $ | 79,272 |  |  | $ | 15,489 |  |

[0001437749-25-033351:notes:37]
As of  September 30, 2025 and 2024, the Company’s contract assets and liabilities primarily relate to the timing differences between cash received from a customer in connection with contractual rights to invoicing and the timing of revenue recognition following completion of performance obligations. The Company's accounts receivable balance is made up entirely of customer contract related balances. Changes in the Company’s contract assets, which are included in “Unbilled accounts receivable” and “Deferred program costs” (see Note 8, “Accounts Receivable” and Note 9, “Inventory” for a reconciliation to the condensed consolidated balance sheets) and "Contract liabilities", which are included in the current portion and long-term portion of "Deferred revenue" in the Company’s condensed consolidated balance sheets, are as follows (in thousands):

[0001437749-25-033351:notes:38]
|  |  | Unbilled Accounts Receivable |  |  | Deferred Program Costs |  |  | Contract Liabilities |  |
| Beginning balance as of March 31, 2025 |  | $ | 6,376 |  |  | $ | 5,756 |  |  | $ | 76,133 |  |
| Increases for costs incurred to fulfill performance obligations |  |  | — |  |  |  | 15,934 |  |  |  | — |  |
| Increase (decrease) due to customer billings |  |  | (10,269 | ) |  |  | — |  |  |  | 47,765 |  |
| Decrease due to cost recognition on completed performance obligations |  |  | — |  |  |  | (16,718 | ) |  |  | — |  |
| Increase (decrease) due to recognition of revenue based on transfer of control of performance obligations |  |  | 12,207 |  |  |  | — |  |  |  | (61,496 | ) |
| Other changes and FX impact |  |  | 13 |  |  |  | 46 |  |  |  | 988 |  |
| Ending balance as of September 30, 2025 |  | $ | 8,327 |  |  | $ | 5,018 |  |  | $ | 63,390 |  |

[0001437749-25-033351:notes:39]
|  |  | Unbilled Accounts Receivable |  |  | Deferred Program Costs |  |  | Contract Liabilities |  |
| Beginning balance as of March 31, 2024 |  | $ | 6,150 |  |  | $ | 2,523 |  |  | $ | 57,829 |  |
| Increase for balances acquired |  |  | — |  |  |  | — |  |  |  | 5,049 |  |
| Increases for costs incurred to fulfill performance obligations |  |  | — |  |  |  | 4,866 |  |  |  | — |  |
| Increase (decrease) due to customer billings |  |  | (6,241 | ) |  |  | — |  |  |  | 70,133 |  |
| Decrease due to cost recognition on completed performance obligations |  |  | — |  |  |  | (2,553 | ) |  |  | — |  |
| Increase (decrease) due to recognition of revenue based on transfer of control of performance obligations |  |  | 4,607 |  |  |  | — |  |  |  | (52,084 | ) |
| Other changes and FX impact |  |  | 7 |  |  |  | 12 |  |  |  | 344 |  |
| Ending balance as of September 30, 2024 |  | $ | 4,523 |  |  | $ | 4,848 |  |  | $ | 81,271 |  |

[0001437749-25-033351:notes:40]
The Company’s remaining performance obligations represent the unrecognized revenue value of the Company’s contractual commitments. The Company’s performance obligations  may vary significantly each reporting period based on the timing of major new contractual commitments. As of  September 30, 2025, the Company had outstanding performance obligations on existing contracts under ASC 606 to be recognized in the next twelve months of approximately $209.5 million. There are also approximately $78.2 million of outstanding performance obligations to be recognized over a period of thirteen to sixty months. The remaining performance obligations are subject to customer actions and therefore the timing of revenue recognition cannot be reasonably estimated.

[0001437749-25-033351:notes:41]
The following table sets forth customers who represented 10% or more of the Company’s total revenues for the three and six months ended  September 30, 2025, and 2024:

[0001437749-25-033351:notes:42]
|  |  |  | Three Months Ended |  |  | Six Months Ended |  |
|  | Reportable |  | September 30, |  |  | September 30, |  |
|  | Segment |  | 2025 |  |  | 2024 |  |  | 2025 |  |  | 2024 |  |
| Inox Wind Limited | Wind |  |  | 16 | % |  |  | 12 | % |  |  | 16 | % |  |  | 14 | % |
| Anovion LLC | Grid |  |  | 12 | % |  | <10 | % |  | <10 | % |  | <10 | % |
| Fuji Bridex Pte Ltd | Grid |  | <10 | % |  | <10 | % |  |  | 13 | % |  | <10 | % |


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001437749-25-033351:notes:43]
[same as prior period, unchanged from 0001437749-25-023968:notes:42]

[0001437749-25-033351:notes:44]
The Company accounts for its stock-based compensation at fair value. The following table summarizes stock-based compensation expense by financial statement line item for the three and six months ended  September 30, 2025, and 2024 (in thousands):

[0001437749-25-033351:notes:45]
|  |  | Three Months Ended September 30, |  |  | Six Months Ended September 30, |  |
|  |  | 2025 |  |  | 2024 |  |  | 2025 |  |  | 2024 |  |
| Cost of revenues |  | $ | 266 |  |  | $ | 39 |  |  | $ | 605 |  |  | $ | 97 |  |
| Research and development |  |  | 511 |  |  |  | 113 |  |  |  | 1,199 |  |  |  | 256 |  |
| Selling, general and administrative |  |  | 2,989 |  |  |  | 691 |  |  |  | 6,488 |  |  |  | 1,719 |  |
| Total |  | $ | 3,766 |  |  | $ | 843 |  |  | $ | 8,292 |  |  | $ | 2,072 |  |

[0001437749-25-033351:notes:46]
The Company issued 7,000 shares and 887,000 shares of restricted stock during the three and six months ended  September 30, 2025, respectively. The Company issued no shares and 39,445 shares of immediately vested common stock during the three and six months ended  September 30, 2025, respectively. The Company issued 817,500 shares and 842,500 shares of restricted stock during the three and six months ended  September 30, 2024, respectively. The Company issued no shares and 19,200 shares of immediately vested common stock during the three and six months ended  September 30, 2024, respectively. These restricted stock awards generally vest over 2-3 years. Awards for restricted stock include both time-based and performance-based awards. For options and restricted stock awards that vest upon the passage of time, expense is being recorded over the vesting period. Performance-based awards are expensed over the requisite service period based on probability of achievement.

[0001437749-25-033351:notes:47]
The Company granted no stock options and 2,112 stock options during the three and six months ended  September 30, 2025, respectively. The Company granted no stock options during the three and six months ended  September 30, 2024. The stock options granted during the six months ended  September 30, 2025 will vest over 2 years. The estimated fair value of the Company’s stock-based awards, less expected annual forfeitures, is amortized over the awards’ service period. There were less than $0.1 million of unrecognized compensation costs for unvested stock options as of  September 30, 2025. This expense will be recognized over a weighted average period of approximately 1.7 years. The total unrecognized compensation cost for unvested outstanding restricted stock was $28.4 million as of  September 30, 2025. This expense will be recognized over a weighted-average expense period of approximately 1.9 years.

[0001437749-25-033351:notes:48]
The weighted average assumptions used in the Black Scholes valuation model for stock options granted during the six months ended  September 30, 2025 are as follows:

[0001437749-25-033351:notes:49]
|  |  | Six Months Ended September 30, |  |
|  |  | 2025 |  |
| Expected volatility |  |  | 74.01 | % |
| Risk-free interest rate |  |  | 4.19 | % |
| Expected life (years) |  |  | 6.31 |  |
| Dividend yield |  | None |  |


## us-gaap:EarningsPerShareTextBlock

[0001437749-25-033351:notes:50]
5. Computation of Net Income per Share of Common Stock

[0001437749-25-033351:notes:51]
Basic net income per share (“EPS”) is computed by dividing net income by the weighted-average number of common shares outstanding for the period. Where applicable, diluted EPS is computed by dividing the net income by the weighted-average number of common shares and dilutive common equivalent shares outstanding during the period, calculated using the treasury stock method. Common equivalent shares include the effect of restricted stock, exercise of stock options and warrants and contingently issuable shares. Stock options and warrants that are out-of-the-money with exercise prices greater than the average market price of the underlying common shares and shares of performance-based restricted stock where the contingency was not met are excluded from the computation of diluted EPS as the effect of their inclusion would be anti-dilutive. For the three months ended  September 30, 2025, 553,740 shares were not included in the calculation of diluted EPS. Of these, 553,334 were shares of performance-based restricted stock where the contingency was not met and 406 shares relate to outstanding stock options that were considered anti-dilutive. For the six months ended  September 30, 2025, 514,535 shares were not included in the calculation of diluted EPS. Of these, 513,926 were shares of performance-based restricted stock where the contingency was not met and 609 shares relate to outstanding stock options that were considered anti-dilutive. For the three months ended  September 30, 2024, 535,001 shares were not included in the calculation of diluted EPS. Of these, 526,333 were shares of performance-based restricted stock where the contingency was not met. Of the remaining shares, 652 shares relate to outstanding stock awards that were considered anti-dilutive, and 8,016 shares related to ESPP shares and were excluded as they were considered anti-dilutive. For the six months ended  September 30, 2024, 479,341 shares were not included in the calculation of diluted EPS. Of these, 469,667 were shares of performance-based restricted stock where the contingency was not met. Of the remaining shares, 326 shares relate to outstanding stock awards that were considered anti-dilutive, and 9,348 shares related to ESPP shares and were excluded as they were considered anti-dilutive.

[0001437749-25-033351:notes:52]
The following table reconciles the numerators and denominators of the earnings per share calculation for the three and six months ended  September 30, 2025, and 2024 (in thousands, except per share data):

[0001437749-25-033351:notes:53]
|  |  | Three Months Ended September 30, |  |  | Six Months Ended September 30, |  |
|  |  | 2025 |  |  | 2024 |  |  | 2025 |  |  | 2024 |  |
| Numerator: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income |  | $ | 4,750 |  |  | $ | 4,887 |  |  | $ | 11,474 |  |  | $ | 2,363 |  |
| Denominator: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Weighted-average shares of common stock outstanding |  |  | 45,170 |  |  |  | 37,931 |  |  |  | 43,028 |  |  |  | 37,463 |  |
| Weighted-average shares subject to repurchase |  |  | (1,928 | ) |  |  | (979 | ) |  |  | (1,958 | ) |  |  | (1,146 | ) |
| Shares used in per-share calculation ― basic |  |  | 43,242 |  |  |  | 36,952 |  |  |  | 41,070 |  |  |  | 36,317 |  |
| Shares used in per-share calculation ― diluted |  |  | 44,210 |  |  |  | 37,499 |  |  |  | 41,988 |  |  |  | 36,951 |  |
| Net income per share ― basic |  | $ | 0.11 |  |  | $ | 0.13 |  |  | $ | 0.28 |  |  | $ | 0.07 |  |
| Net income per share ― diluted |  | $ | 0.11 |  |  | $ | 0.13 |  |  | $ | 0.27 |  |  | $ | 0.06 |  |


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001437749-25-033351:notes:54]
[same as prior period, unchanged from 0001437749-25-023968:notes:53]

[0001437749-25-033351:notes:55]
[same as prior period, unchanged from 0001437749-25-023968:notes:54]

[0001437749-25-033351:notes:56]
Goodwill represents the difference between the purchase price and the fair value of the identifiable tangible and intangible net assets when accounted for using the purchase method of accounting. Goodwill is not amortized but reviewed for impairment. The Company's goodwill balance relates to the NWL Acquisition in fiscal 2024, the acquisition of Neeltran, Inc. in fiscal 2021, the Northeast Power Systems, Inc. ("NEPSI") acquisition in fiscal 2020, and the acquisition of Infinia Technology Corporation in fiscal 2017 and is reported in the Grid business segment. Goodwill is reviewed annually on  February 28th and whenever events or changes in circumstances indicate that the carrying value of the goodwill might not be recoverable. Goodwill increased by $4.7 million during the fiscal year ended  March 31, 2025, related to the NWL Acquisition. There were no changes to Goodwill during the six months ended  September 30, 2025.

[0001437749-25-033351:notes:57]
The Company did not identify any triggers to assess impairment in the three and six months ended  September 30, 2025 or 2024.

[0001437749-25-033351:notes:58]
[same as prior period, unchanged from 0001437749-25-023968:notes:57]

[0001437749-25-033351:notes:59]
Intangible assets at  September 30, 2025 and  March 31, 2025 consisted of the following (in thousands):

[0001437749-25-033351:notes:60]
|  |  | September 30, 2025 |  |  | March 31, 2025 |  |  |  |  |  |
|  |  | Gross Amount |  |  | Accumulated Amortization |  |  | Net Book Value |  |  | Gross Amount |  |  | Accumulated Amortization |  |  | Net Book Value |  |  | Estimated Useful Life |  |
| Backlog |  |  | 1,381 |  |  |  | (1,381 | ) |  |  | — |  |  |  | 1,381 |  |  |  | (1,381 | ) |  |  | — |  |  |  | 2 |  |
| Trade name and trademarks |  |  | 1,800 |  |  |  | — |  |  |  | 1,800 |  |  |  | 1,800 |  |  |  | — |  |  |  | 1,800 |  |  | Indefinite |  |
| Customer relationships |  |  | 10,880 |  |  |  | (8,332 | ) |  |  | 2,548 |  |  |  | 10,880 |  |  |  | (7,901 | ) |  |  | 2,980 |  |  |  | 7-10 |  |
| Core technology and know-how |  |  | 5,970 |  |  |  | (5,076 | ) |  |  | 894 |  |  |  | 5,970 |  |  |  | (4,834 | ) |  |  | 1,136 |  |  |  | 5-10 |  |
| Intangible assets |  | $ | 20,031 |  |  | $ | (14,789 | ) |  | $ | 5,242 |  |  | $ | 20,031 |  |  | $ | (14,116 | ) |  | $ | 5,916 |  |  |  |  |  |

[0001437749-25-033351:notes:61]
The Company recorded intangible amortization expense related to customer relationship and core technology and know-how of $0.3 million and $0.7 million in the three and six months ended  September 30, 2025, respectively. The Company recorded intangible amortization expense related to customer relationship and core technology and know-how of $0.4 million and $0.8 million in the three and six months ended  September 30, 2024.

[0001437749-25-033351:notes:62]
[same as prior period, unchanged from 0001437749-25-023968:notes:61]

[0001437749-25-033351:notes:63]
| Years ending March 31, |  | Total |  |
| 2026 (remaining) |  |  | 674 |  |
| 2027 |  |  | 1,213 |  |
| 2028 |  |  | 671 |  |
| 2029 |  |  | 201 |  |
| 2030 |  |  | 128 |  |
| Thereafter |  |  | 555 |  |
| Total |  | $ | 3,442 |  |

[0001437749-25-033351:notes:64]
[same as prior period, unchanged from 0001437749-25-023968:notes:63]


## us-gaap:FairValueDisclosuresTextBlock

[0001437749-25-033351:notes:65]
[same as prior period, unchanged from 0001437749-25-023968:notes:64]

[0001437749-25-033351:notes:66]
[same as prior period, unchanged from 0001437749-25-023968:notes:65]

[0001437749-25-033351:notes:67]
[same as prior period, unchanged from 0001437749-25-023968:notes:66]

[0001437749-25-033351:notes:68]
The Company provides a gross presentation of activity within Level 3 measurement roll-forward and details of transfers in and out of Level 1 and 2 measurements. A change in the hierarchy of an investment from its current level is reflected in the period during which the pricing methodology of such investment changes. Disclosure of the transfer of securities from Level 1 to Level 2 or Level 3 is made in the event that the related security is significant to total cash and investments. The Company did not have any transfers of assets and liabilities from Level 1, Level 2 or Level 3 of the fair value measurement hierarchy during the three or six months ended  September 30, 2025.

[0001437749-25-033351:notes:69]
[same as prior period, unchanged from 0001437749-25-023968:notes:68]

[0001437749-25-033351:notes:70]
[same as prior period, unchanged from 0001437749-25-023968:notes:69]

[0001437749-25-033351:notes:71]
[same as prior period, unchanged from 0001437749-25-023968:notes:70]

[0001437749-25-033351:notes:72]
[same as prior period, unchanged from 0001437749-25-023968:notes:71]

[0001437749-25-033351:notes:73]
[same as prior period, unchanged from 0001437749-25-023968:notes:72]

[0001437749-25-033351:notes:74]
[same as prior period, unchanged from 0001437749-25-023968:notes:73]

[0001437749-25-033351:notes:75]
The following table provides the assets and liabilities carried at fair value on a recurring basis, measured as of  September 30, 2025 and  March 31, 2025 (in thousands):

[0001437749-25-033351:notes:76]
|  |  | Total Carrying Value |  |  | Quoted Prices in Active Markets (Level 1) |  |  | Significant Other Observable Inputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |
| September 30, 2025: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash equivalents |  | $ | 177,543 |  |  | $ | 177,543 |  |  | $ | — |  |  | $ | — |  |
| Short-term cash instruments |  | $ | 1,351 |  |  | $ | — |  |  | $ | 1,351 |  |  | $ | — |  |

[0001437749-25-033351:notes:77]
[same as prior period, unchanged from 0001437749-25-023968:notes:76]


## amsc:AccountsReceivableTextBlock

[0001437749-25-033351:notes:78]
[same as prior period, unchanged from 0001437749-25-023968:notes:77]

[0001437749-25-033351:notes:79]
Accounts receivable at  September 30, 2025 and  March 31, 2025 consisted of the following (in thousands):

[0001437749-25-033351:notes:80]
|  |  | September 30, 2025 |  |  | March 31, 2025 |  |
| Accounts receivable (billed) |  | $ | 31,543 |  |  | $ | 39,810 |  |
| Accounts receivable (unbilled) |  |  | 8,327 |  |  |  | 6,376 |  |
| Accounts receivable |  | $ | 39,870 |  |  | $ | 46,186 |  |


## us-gaap:InventoryDisclosureTextBlock

[0001437749-25-033351:notes:81]
[same as prior period, unchanged from 0001437749-25-023968:notes:80]

[0001437749-25-033351:notes:82]
Inventory, net of reserves, at  September 30, 2025 and  March 31, 2025 consisted of the following (in thousands):

[0001437749-25-033351:notes:83]
|  |  | September 30, 2025 |  |  | March 31, 2025 |  |
| Raw materials |  | $ | 37,803 |  |  | $ | 35,892 |  |
| Work-in-process |  |  | 25,842 |  |  |  | 19,633 |  |
| Finished goods |  |  | 6,794 |  |  |  | 9,888 |  |
| Deferred program costs |  |  | 5,018 |  |  |  | 5,756 |  |
| Net inventory |  | $ | 75,457 |  |  | $ | 71,169 |  |

[0001437749-25-033351:notes:84]
The Company recorded inventory write-downs of $1.1 million and $0.3 million for the three months ended  September 30, 2025 and 2024, respectively. The Company recorded inventory write-downs of $1.8 million and $0.8 million for the six months ended  September 30, 2025 and 2024, respectively. These write-downs were based on the Company's evaluation of its inventory on hand for excess quantities and obsolescence.

[0001437749-25-033351:notes:85]
Deferred program costs as of  September 30, 2025 and  March 31, 2025 primarily represent costs incurred on programs where the Company needs to complete performance obligations before the related revenue and costs will be recognized.


## us-gaap:PropertyPlantAndEquipmentDisclosureTextBlock

[0001437749-25-033351:notes:86]
[same as prior period, unchanged from 0001437749-25-023968:notes:85]

[0001437749-25-033351:notes:87]
The cost and accumulated depreciation of property, plant and equipment at  September 30, 2025 and  March 31, 2025 are as follows (in thousands):

[0001437749-25-033351:notes:88]
|  |  | September 30, 2025 |  |  | March 31, 2025 |  |
| Land |  | $ | 22,650 |  |  | $ | 22,650 |  |
| Construction in progress – equipment |  |  | 601 |  |  |  | 1,371 |  |
| Buildings |  |  | 7,986 |  |  |  | 7,528 |  |
| Equipment and software |  |  | 49,969 |  |  |  | 47,774 |  |
| Furniture and fixtures |  |  | 1,728 |  |  |  | 1,672 |  |
| Leasehold improvements |  |  | 8,256 |  |  |  | 7,969 |  |
| Property, plant and equipment, gross |  |  | 91,190 |  |  |  | 88,964 |  |
| Less accumulated depreciation |  |  | (52,234 | ) |  |  | (50,392 | ) |
| Property, plant and equipment, net |  | $ | 38,956 |  |  | $ | 38,572 |  |

[0001437749-25-033351:notes:89]
Depreciation expense was $0.9 million and $0.8 million for the three months ended  September 30, 2025 and 2024, respectively. Depreciation expense was $1.8 million and $1.4 million for the six months ended  September 30, 2025 and 2024, respectively.


## us-gaap:EquityMethodInvestmentsDisclosureTextBlock

[0001437749-25-033351:notes:90]
[same as prior period, unchanged from 0001437749-25-023968:notes:89]

[0001437749-25-033351:notes:91]
[same as prior period, unchanged from 0001437749-25-023968:notes:90]

[0001437749-25-033351:notes:92]
[same as prior period, unchanged from 0001437749-25-023968:notes:91]

[0001437749-25-033351:notes:93]
The Company treats the equity investment in the condensed consolidated financial statements under the equity method. Equity method investments are equity securities in entities the Company does not control but over which it has the ability to exercise significant influence. These investments are accounted for under the equity method of accounting in accordance with ASC 323, Investments — Equity Method and Joint Ventures. Equity method investments are measured at cost minus impairment, if any, plus or minus the Company’s share of an investee’s income or loss, less distributions received. As of  September 30, 2025 the Company did not have material accounts receivable nor accounts payable balances with NWL Pacific. The Company's investment in NWL Pacific was $1.5 million and $1.1 million as of  September 30, 2025 and  March 31, 2025, respectively.

[0001437749-25-033351:notes:94]
[same as prior period, unchanged from 0001437749-25-023968:notes:93]

[0001437749-25-033351:notes:95]
|  |  | Three Months Ended September 30, |  |  | Six Months Ended September 30, |  |
|  |  | 2025 |  |  | 2025 |  |
| Net revenue |  | $ | 1,087 |  |  | $ | 3,686 |  |
| Gross profit |  |  | 494 |  |  |  | 1,654 |  |
| Income from operation |  |  | 98 |  |  |  | 755 |  |
| Net income |  | $ | 122 |  |  | $ | 867 |  |


## us-gaap:AccountsPayableAndAccruedLiabilitiesDisclosureTextBlock

[0001437749-25-033351:notes:96]
[same as prior period, unchanged from 0001437749-25-023968:notes:95]

[0001437749-25-033351:notes:97]
Accounts payable and accrued expenses at  September 30, 2025 and  March 31, 2025 consisted of the following (in thousands):

[0001437749-25-033351:notes:98]
|  |  | September 30, 2025 |  |  | March 31, 2025 |  |
| Accounts payable |  | $ | 7,404 |  |  | $ | 6,733 |  |
| Accrued inventories in-transit |  |  | 3,343 |  |  |  | 2,111 |  |
| Accrued other miscellaneous expenses |  |  | 4,435 |  |  |  | 3,600 |  |
| Accrued contract loss |  |  | 111 |  |  |  | 97 |  |
| Advanced deposits |  |  | 4,495 |  |  |  | 1,267 |  |
| Accrued compensation |  |  | 9,902 |  |  |  | 13,418 |  |
| Income taxes payable |  |  | 455 |  |  |  | 305 |  |
| Accrued product warranty |  |  | 3,334 |  |  |  | 3,033 |  |
| Accrued commissions |  |  | 1,200 |  |  |  | 1,718 |  |
| Total |  | $ | 34,679 |  |  | $ | 32,282 |  |

[0001437749-25-033351:notes:99]
[same as prior period, unchanged from 0001437749-25-023968:notes:98]

[0001437749-25-033351:notes:100]
[same as prior period, unchanged from 0001437749-25-023968:notes:99]

[0001437749-25-033351:notes:101]
|  |  | Three Months Ended September 30, |  |  | Six Months Ended September 30, |  |
|  |  | 2025 |  |  | 2024 |  |  | 2025 |  |  | 2024 |  |
| Balance at beginning of period |  | $ | 3,240 |  |  | $ | 2,542 |  |  | $ | 3,033 |  |  | $ | 2,363 |  |
| Acquired warranty obligations |  |  | — |  |  |  | 637 |  |  |  | — |  |  |  | 637 |  |
| Provisions for warranties during the period |  |  | 520 |  |  |  | 298 |  |  |  | 1,069 |  |  |  | 774 |  |
| Settlements during the period |  |  | (426 | ) |  |  | (367 | ) |  |  | (768 | ) |  |  | (664 | ) |
| Balance at end of period |  | $ | 3,334 |  |  | $ | 3,110 |  |  | $ | 3,334 |  |  | $ | 3,110 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0001437749-25-033351:notes:102]
[same as prior period, unchanged from 0001437749-25-023968:notes:101]

[0001437749-25-033351:notes:103]
The Company recorded income tax expense of $0.1 million and $0.3 million for the three and six months ended  September 30, 2025, respectively, and income tax benefit of $5.0 million and $4.8 million for the three and six months ended  September 30, 2024, respectively.

[0001437749-25-033351:notes:104]
On  July 4, 2025, the reconciliation bill, commonly referred to as the One Big Beautiful Bill ("OBBB") was signed into law, which includes a broad range of tax reform provisions that  may affect the company's financial results. The OBBB allows an elective deduction for domestic Research and Development (R&D), a reinstatement of elective 100% first-year bonus depreciation, and a more favorable tax rate on Foreign-derived Deduction Eligible Income and income from non-U.S. subsidiaries (Net CFC Tested Income), among other provisions. The Company has performed an initial evaluation of the impact of the OBBB on the Company's effective tax rate and deferred tax assets in 2025 and future periods. Based on this initial evaluation, the Company believes the tax reform provisions will not have a material impact on the Company’s consolidated financial statements and related disclosures.  We will continue to assess the implications of the OBBB, and our tax provision  may be further impacted as additional guidance from the U.S. Department of the Treasury is released.

[0001437749-25-033351:notes:105]
Accounting for income taxes requires a two-step approach to recognizing and measuring uncertain tax positions. The first step is to evaluate the tax position for recognition by determining if, based on the technical merits, it is more likely than not the position will be sustained upon audit, including resolution of related appeals or litigation processes, if any. The second step is to measure the tax benefit as the largest amount that is more than 50% likely to be realized upon ultimate settlement. The Company re-evaluates these uncertain tax positions on a quarterly basis. The evaluation is based on factors including, but not limited to, changes in facts or circumstances, changes in tax law, effectively settled issues under audit and new audit activity. Any changes in these factors could result in the recognition of a tax benefit or an additional charge to the tax provision. The Company did not identify any uncertain tax positions in the six months ended  September 30, 2025 and did not have any gross unrecognized tax benefits as of  September 30, 2025.

[0001437749-25-033351:notes:106]
On a quarterly basis, the Company reassesses the valuation allowance on deferred income tax assets, weighing positive and negative evidence to assess the recoverability of the deferred tax assets. As of  September 30, 2025, the Company continues to maintain a valuation allowance to reduce the U.S. federal and state deferred tax assets to the amount that will more likely than not be realized. Given the Company’s positive trend in earnings, the Company will assess during fiscal year 2025 whether sufficient positive evidence will exist to allow the Company to reach a conclusion that some or all of the U.S. valuation allowance will no longer be needed. A release of the valuation allowance would result in the recognition of deferred tax assets and a corresponding decrease to income tax expense in the period the release is recorded, the effect of which would be an increase in reported net income.


## amsc:BusinessCombinationContingentConsiderationTextBlock

[0001437749-25-033351:notes:107]
[same as prior period, unchanged from 0001437749-25-023968:notes:106]

[0001437749-25-033351:notes:108]
[same as prior period, unchanged from 0001437749-25-023968:notes:107]

[0001437749-25-033351:notes:109]
[same as prior period, unchanged from 0001437749-25-023968:notes:108]

[0001437749-25-033351:notes:110]
[same as prior period, unchanged from 0001437749-25-023968:notes:109]

[0001437749-25-033351:notes:111]
[same as prior period, unchanged from 0001437749-25-023968:notes:110]

[0001437749-25-033351:notes:112]
[same as prior period, unchanged from 0001437749-25-023968:notes:111]

[0001437749-25-033351:notes:113]
[same as prior period, unchanged from 0001437749-25-023968:notes:112]

[0001437749-25-033351:notes:114]
[same as prior period, unchanged from 0001437749-25-023968:notes:113]

[0001437749-25-033351:notes:115]
The Company did not record any activity related to contingent consideration in the three and six months ended  September 30, 2025 as the liability was settled in the prior fiscal year. The Company recorded a gain resulting from the decrease in fair value of $0.5 million and a loss of $3.4 million resulting from the increases in the fair value of the contingent consideration in the three and six months ended  September 30, 2024, respectively.


## us-gaap:LesseeOperatingLeasesTextBlock

[0001437749-25-033351:notes:116]
[same as prior period, unchanged from 0001437749-25-023968:notes:115]

[0001437749-25-033351:notes:117]
[same as prior period, unchanged from 0001437749-25-023968:notes:116]

[0001437749-25-033351:notes:118]
[same as prior period, unchanged from 0001437749-25-023968:notes:117]

[0001437749-25-033351:notes:119]
[same as prior period, unchanged from 0001437749-25-023968:notes:118]

[0001437749-25-033351:notes:120]
Supplemental balance sheet information related to leases at  September 30, 2025, and  March 31, 2025 are as follows (in thousands):

[0001437749-25-033351:notes:121]
|  |  | September 30, 2025 |  |  | March 31, 2025 |  |
| Leases: |  |  |  |  |  |  |  |  |
| Right-of-use assets – Operating |  | $ | 3,789 |  |  | $ | 3,829 |  |
| Total right-of-use assets |  |  | 3,789 |  |  |  | 3,829 |  |
| Lease liabilities – ST Operating |  | $ | 968 |  |  | $ | 685 |  |
| Lease liabilities – LT Operating |  |  | 2,681 |  |  |  | 2,684 |  |
| Total lease liabilities |  | $ | 3,649 |  |  | $ | 3,369 |  |
| Weighted-average remaining lease term |  |  | 4.60 |  |  |  | 4.94 |  |
| Weighted-average discount rate |  |  | 14.58 | % |  |  | 14.94 | % |

[0001437749-25-033351:notes:122]
The costs related to the Company's operating leases for the three and six months ended  September 30, 2025 and 2024, are as follows (in thousands):

[0001437749-25-033351:notes:123]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | September 30, 2025 |  |  | September 30, 2025 |  |
| Operating Leases: |  |  |  |  |  |  |  |  |
| Operating lease costs – fixed |  | $ | 421 |  |  | $ | 834 |  |
| Operating lease costs – variable |  |  | 45 |  |  |  | 91 |  |
| Short-term lease costs |  |  | 42 |  |  |  | 83 |  |
| Total lease costs |  | $ | 508 |  |  | $ | 1,008 |  |

[0001437749-25-033351:notes:124]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | September 30, 2024 |  |  | September 30, 2024 |  |
| Operating Leases: |  |  |  |  |  |  |  |  |
| Operating lease costs – fixed |  | $ | 336 |  |  | $ | 645 |  |
| Operating lease costs – variable |  |  | 45 |  |  |  | 91 |  |
| Short-term lease costs |  |  | 39 |  |  |  | 78 |  |
| Total lease costs |  | $ | 420 |  |  | $ | 814 |  |

[0001437749-25-033351:notes:125]
[same as prior period, unchanged from 0001437749-25-023968:notes:124]

[0001437749-25-033351:notes:126]
|  |  | Leases |  |
| Year ending March 31, |  |  |  |  |
| 2026 (remaining) |  | $ | 693 |  |
| 2027 |  |  | 1,555 |  |
| 2028 |  |  | 1,003 |  |
| 2029 |  |  | 396 |  |
| 2030 |  |  | 326 |  |
| Thereafter |  |  | 1,227 |  |
| Total minimum lease payments |  |  | 5,200 |  |
| Less: interest |  |  | (1,551 | ) |
| Present value of lease liabilities |  | $ | 3,649 |  |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001437749-25-033351:notes:127]
16. Commitments and Contingencies

[0001437749-25-033351:notes:128]
Legal Contingencies

[0001437749-25-033351:notes:129]
From time to time, the Company is involved in legal and administrative proceedings and claims of various types. The Company records a liability in its condensed consolidated financial statements for these matters when a loss is known or considered probable and the amount can be reasonably estimated. The Company reviews these estimates each accounting period as additional information is known and adjusts the loss provision when appropriate. If a matter is both probable to result in a liability and the amounts of loss can be reasonably estimated, the Company estimates and discloses the possible loss or range of loss to the extent necessary to make the condensed consolidated financial statements not misleading. If the loss is not probable or cannot be reasonably estimated, a liability is not recorded in its condensed consolidated financial statements.

[0001437749-25-033351:notes:130]
Other

[0001437749-25-033351:notes:131]
The Company enters into long-term construction contracts with customers that require the Company to obtain performance bonds. The Company is required to deposit an amount equivalent to some or all the face amount of the performance bonds into an escrow account until the termination of the bond. When the performance conditions are met, amounts deposited as collateral for the performance bonds are returned to the Company. In addition, the Company has various contractual arrangements in which minimum quantities of goods or services have been committed to be purchased on an annual basis.

[0001437749-25-033351:notes:132]
As of  September 30, 2025, the Company had $3.0 million of restricted cash included in long-term assets and $2.9 million of restricted cash included in current assets. As of  March 31, 2025, the Company had $4.3 million of restricted cash included in long term assets and $1.6 million of restricted cash included in current assets. These amounts included in restricted cash primarily represent deposits to secure letters of credit for various supply contracts and long-term projects or collateral deposits. These deposits are held in interest bearing accounts.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001437749-25-033351:notes:133]
[same as prior period, unchanged from 0001437749-25-023968:notes:132]

[0001437749-25-033351:notes:134]
[same as prior period, unchanged from 0001437749-25-023968:notes:133]

[0001437749-25-033351:notes:135]
[same as prior period, unchanged from 0001437749-25-023968:notes:134]

[0001437749-25-033351:notes:136]
[same as prior period, unchanged from 0001437749-25-023968:notes:135]

[0001437749-25-033351:notes:137]
[same as prior period, unchanged from 0001437749-25-023968:notes:136]

[0001437749-25-033351:notes:138]
The following tables (i) summarize total sales by segment and (ii) reconcile each segment's sales to their respective segment operating income, including segment operating expenses, for each of the three and six months ended  September 30, 2025 and 2024 (in thousands):

[0001437749-25-033351:notes:139]
|  |  | Three Months Ended September 30, 2025 |  |  | Six Months Ended September 30, 2025 |  |
|  |  | Grid |  |  | Wind |  |  | Unallocated |  |  | Total |  |  | Grid |  |  | Wind |  |  | Unallocated |  |  | Total |  |
| Segment operating income: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Revenues |  | $ | 54,342 |  |  | $ | 11,520 |  |  | $ | - |  |  | $ | 65,862 |  |  | $ | 114,429 |  |  | $ | 23,791 |  |  | $ | - |  |  | $ | 138,220 |  |
| Less (a) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Segment other operating expenses (b) |  |  | 53,064 |  |  |  | 9,833 |  |  |  | - |  |  |  | 62,897 |  |  |  | 108,994 |  |  |  | 20,616 |  |  |  | - |  |  |  | 129,610 |  |
| Segment operating income |  | $ | 1,278 |  |  | $ | 1,687 |  |  | $ | - |  |  | $ | 2,965 |  |  | $ | 5,435 |  |  | $ | 3,175 |  |  | $ | - |  |  | $ | 8,610 |  |

[0001437749-25-033351:notes:140]
[same as prior period, unchanged from 0001437749-25-023968:notes:139]

[0001437749-25-033351:notes:141]
[same as prior period, unchanged from 0001437749-25-023968:notes:140]

[0001437749-25-033351:notes:142]
|  |  | Three Months Ended September 30, 2024 |  |  | Six Months Ended September 30, 2024 |  |
|  |  | Grid |  |  | Wind |  |  | Unallocated |  |  | Total |  |  | Grid |  |  | Wind |  |  | Unallocated |  |  | Total |  |
| Segment operating income: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Revenues |  | $ | 46,936 |  |  | $ | 7,535 |  |  | $ | - |  |  | $ | 54,471 |  |  | $ | 79,272 |  |  | $ | 15,489 |  |  | $ | - |  |  | $ | 94,761 |  |
| Less (a) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Segment other operating expenses (b) |  |  | 45,366 |  |  |  | 7,096 |  |  |  | 2,762 |  |  |  | 55,224 |  |  |  | 77,939 |  |  |  | 14,183 |  |  |  | 6,682 |  |  |  | 98,804 |  |
| Segment operating income (loss) |  | $ | 1,570 |  |  | $ | 439 |  |  | $ | (2,762 | ) |  | $ | (753 | ) |  | $ | 1,333 |  |  | $ | 1,306 |  |  | $ | (6,682 | ) |  | $ | (4,043 | ) |

[0001437749-25-033351:notes:143]
[same as prior period, unchanged from 0001437749-25-023968:notes:142]

[0001437749-25-033351:notes:144]
Unallocated corporate expenses included a net loss on contingent consideration $2.8 million and $6.7 million in the three and six months ended  September 30, 2024, respectively.

[0001437749-25-033351:notes:145]
The reconciliation of segment operating income (loss) to consolidated income (loss) before income taxes for the three and six months ended  September 30, 2025 and 2024 is as follows (in thousands):

[0001437749-25-033351:notes:146]
|  |  | Three Months Ended September 30, |  |  | Six Months Ended September 30, 2025 |  |
|  |  | 2025 |  |  | 2024 |  |  | 2025 |  |  | 2024 |  |
| Operating income (loss): |  | $ | 2,965 |  |  | $ | (753 | ) |  | $ | 8,610 |  |  | $ | (4,043 | ) |
| Interest income, net |  |  | 2,269 |  |  |  | 979 |  |  |  | 3,201 |  |  | $ | 2,099 |  |
| Other expense, net |  |  | (367 | ) |  |  | (329 | ) |  |  | (21 | ) |  |  | (489 | ) |
| Income (loss) before income tax expense (benefit) |  | $ | 4,867 |  |  | $ | (103 | ) |  | $ | 11,790 |  |  | $ | (2,433 | ) |

[0001437749-25-033351:notes:147]
Depreciation and amortization expense by segment for the three and six months ended  September 30, 2025 and 2024 is as follows (in thousands):

[0001437749-25-033351:notes:148]
|  |  | Three Months Ended September 30, |  |  | Six Months Ended September 30, 2025 |  |
|  |  | 2025 |  |  | 2024 |  |  | 2025 |  |  | 2024 |  |
| Grid |  | $ | 1,266 |  |  | $ | 1,376 |  |  | $ | 2,468 |  |  | $ | 2,363 |  |
| Wind |  |  | 31 |  |  |  | 11 |  |  |  | 57 |  |  | $ | 32 |  |
| Total |  | $ | 1,297 |  |  | $ | 1,387 |  |  | $ | 2,525 |  |  | $ | 2,395 |  |

[0001437749-25-033351:notes:149]
[same as prior period, unchanged from 0001437749-25-023968:notes:148]

[0001437749-25-033351:notes:150]
Total assets for the two business segments as of  September 30, 2025 and  March 31, 2025, are as follows (in thousands):

[0001437749-25-033351:notes:151]
|  |  | September 30, 2025 |  |  | March 31, 2025 |  |
| Grid |  | $ | 209,101 |  |  | $ | 211,520 |  |
| Wind |  |  | 17,665 |  |  |  | 13,697 |  |
| Corporate assets |  |  | 218,837 |  |  |  | 85,304 |  |
| Total |  | $ | 445,603 |  |  | $ | 310,521 |  |


## us-gaap:NewAccountingPronouncementsAndChangesInAccountingPrinciplesTextBlock

[0001437749-25-033351:notes:152]
18. Recent Accounting Pronouncements

[0001437749-25-033351:notes:153]
In  December 2023, the FASB issued ASU 2023-09, Income Taxes (Topic 740): Improvements to Income Tax Disclosures. The amendments in ASU 2023-09 address investor requests for more transparency about income tax information through improvements to income tax disclosures primarily related to the rate reconciliation and income taxes paid information. Following the release of ASU 2023-09 in  December 2023, the effective date was annual reporting periods beginning after  December 15, 2024. As of  September 30, 2025, the Company is evaluating the impact on its consolidated financial statements.

[0001437749-25-033351:notes:154]
In  March 2024, the FASB issued ASU 2024-02, Codification Improvements—Amendments to Remove References to the Concepts Statements. The amendments in ASU 2024-02 contain amendments to the Codification that remove references to various FASB Concepts Statements. Following the release of ASU 2024-02 in  March 2024, the effective date was annual reporting periods beginning after  December 15, 2024. As of  September 30, 2025, the Company is evaluating the impact on its consolidated financial statements.

[0001437749-25-033351:notes:155]
In  November 2024, the FASB issued ASU 2024-03, Income Statement—Reporting Comprehensive Income—Expense Disaggregation Disclosures. The amendments in ASU 2024-03 address investor requests for more disclosure of disaggregated financial reporting information about expenses presented in the income statement. Following the release of ASU 2024-03 in  November 2024, the effective date will be annual reporting periods beginning after  December 15, 2026. As of  September 30, 2025, the Company is evaluating the impact on its consolidated financial statements.


## us-gaap:SubsequentEventsTextBlock

[0001437749-25-033351:notes:156]
19. Subsequent Events

[0001437749-25-033351:notes:157]
The Company has performed an evaluation of subsequent events through the time of filing this Quarterly Report on Form 10-Q with the SEC and has determined that there are no such events to report.


## ecd:MtrlTermsOfTrdArrTextBlock

[0001437749-25-033351:notes:158]
| ITEM 5. | OTHER INFORMATION |

[0001437749-25-033351:notes:159]
(a) None

[0001437749-25-033351:notes:160]
(b) None

[0001437749-25-033351:notes:161]
(c) On   August 15, 2025, Daniel P. McGahn, Chairman, President and Chief Executive Officer, adopted a Rule 10b5-1 trading arrangement that is intended to satisfy the affirmative defense of Rule 10b5-1(c) for the sale of up to 111,205 shares of the Company’s common stock until the earlier of (i)   August 14, 2026, or (ii) the date in which all shares under the trading arrangement are sold.

[0001437749-25-033351:notes:162]
On   August 15, 2025, John W. Kosiba, Jr., Senior Vice President, Chief Financial Officer and Treasurer, adopted a Rule 10b5-1 trading arrangement that is intended to satisfy the affirmative defense of Rule 10b5-1(c) for the sale of up to 48,512 shares of the Company’s common stock until the earlier of (i)   August 14, 2026, or (ii) the date in which all shares under the trading arrangement are sold.
