# AMSC notes — 0001628280-18-000993


## us-gaap:AccountsPayableAndAccruedLiabilitiesDisclosureTextBlock

[0001628280-18-000993:notes:1]
[same as prior period, unchanged from 0001628280-17-011077:notes:1]

[0001628280-18-000993:notes:2]
Accounts payable and accrued expenses at December 31, 2017 and March 31, 2017 consisted of the following (in thousands):

[0001628280-18-000993:notes:3]
|  | December 31, 2017 |  | March 31, 2017 |
| Accounts payable | $ | 5,626 |  |  | $ | 3,207 |  |
| Accrued inventories in-transit | 505 |  |  | 313 |  |
| Accrued other miscellaneous expenses | 2,326 |  |  | 2,240 |  |
| Accrued restructuring | 394 |  |  | — |  |
| Accrued compensation | 3,792 |  |  | 5,042 |  |
| Income taxes payable | 1,372 |  |  | 1,344 |  |
| Accrued warranty | 1,471 |  |  | 2,344 |  |
| Total | $ | 15,486 |  |  | $ | 14,490 |  |

[0001628280-18-000993:notes:4]
[same as prior period, unchanged from 0001628280-17-011077:notes:4]

[0001628280-18-000993:notes:5]
[same as prior period, unchanged from 0001628280-17-011077:notes:5]

[0001628280-18-000993:notes:6]
|  | Three months ended December 31, |  | Nine months ended December 31, |
|  | 2017 |  | 2016 |  | 2017 |  | 2016 |
| Balance at beginning of period | $ | 1,852 |  |  | $ | 2,694 |  |  | $ | 2,344 |  |  | $ | 3,601 |  |
| Change in accruals for warranties during the period | 25 |  |  | 591 |  |  | 152 |  |  | 1,009 |  |
| Settlements during the period | (406 | ) |  | (608 | ) |  | (1,025 | ) |  | (1,933 | ) |
| Balance at end of period | $ | 1,471 |  |  | $ | 2,677 |  |  | $ | 1,471 |  |  | $ | 2,677 |  |


## us-gaap:BasisOfAccountingPolicyPolicyTextBlock

[0001628280-18-000993:notes:7]
These unaudited condensed consolidated financial statements of the Company have been prepared on a going concern basis in accordance with United States generally accepted accounting principles (“GAAP”) and the Securities and Exchange Commission’s (“SEC”) instructions to Form 10-Q. The going concern basis of presentation assumes that the Company will continue operations and will be able to realize its assets and discharge its liabilities and commitments in the normal course of business. Certain information and footnote disclosures normally included in the financial statements prepared in accordance with GAAP have been condensed or omitted pursuant to those instructions. The year-end condensed balance sheet data was derived from audited financial statements but does not include all disclosures required by GAAP. The unaudited condensed consolidated financial statements, in the opinion of management, reflect all adjustments (consisting of normal recurring adjustments) necessary for a fair statement of the results for the interim periods ended December 31, 2017 and 2016 and the financial position at December 31, 2017; however, these results are not necessarily indicative of results which may be expected for the full year. The interim condensed consolidated financial statements, and notes thereto, should be read in conjunction with the audited consolidated financial statements for the year ended March 31, 2017, and notes thereto, included in the Company’s annual report on Form 10-K for the year ended March 31, 2017 filed with the Securities and Exchange Commission on May 25, 2017


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001628280-18-000993:notes:8]
[same as prior period, unchanged from 0001628280-17-011077:notes:8]

[0001628280-18-000993:notes:9]
[same as prior period, unchanged from 0001628280-17-011077:notes:9]

[0001628280-18-000993:notes:10]
[same as prior period, unchanged from 0001628280-17-011077:notes:10]

[0001628280-18-000993:notes:11]
Pursuant to the terms of the stock purchase agreement ("SPA"), the Company acquired all of the issued and outstanding shares of ITC (the "ITC Shares") from the selling stockholders, for a purchase price of approximately $3.8 million consisting of $0.1 million in cash and 884,890 shares of the Company’s common stock (the "AMSC Shares"), $0.01 par value per share at a per share price of $4.02 on the acquisition date.  Under the terms of the SPA, the Company was obligated to file a registration statement (the "Resale Registration Statement") covering the resale of the AMSC Shares by the selling stockholders no later than 10 business days following the closing of the Acquisition, and to use commercially reasonable efforts to cause the Resale Registration Statement to be declared effective by the SEC as soon as practicable thereafter. Additionally, the Company agreed to pay the selling stockholders in cash (the "Make Whole Payment"), if any, equal to (x) an amount equal to (i) the price per AMSC Share pursuant to the terms of the SPA, multiplied by (ii) the number of AMSC Shares sold by the selling stockholders during the first 90 days after the effectiveness of the Resale Registration Statement, minus (y) the aggregate sales proceeds received by the Selling Stockholders from the sale of any AMSC Shares during the first 90 days after the effectiveness of the Resale Registration Statement.  The Resale Registration Statement was declared effective on October 23, 2017.  The contingent liability related to the Make Whole Payment was determined under a fair value option based pricing model to be $0.6 million on September 25, 2017 and was subsequently reassessed at each period end until the final amount due of $0.7 million as of December 31, 2017 was determined according to the agreed upon formula.  See Note 5 "Fair Value Measurements" and Note 12 "Warrants and Derivative Liabilities" for further discussion regarding the valuation of this liability. On January 5, 2018, the Company settled the Make Whole Payment to the selling stockholders in the amount of $0.7 million.

[0001628280-18-000993:notes:12]
ITC was integrated into the Company's Grid business unit. The Acquisition has been accounted for under the purchase method of accounting in accordance with ASU 805, Business Combinations. The Company allocated the purchase price to the assets acquired and liabilities assumed at their estimated fair values as of the date of Acquisition.  The Company estimated the fair value of the intangible assets at $3.4 million, which consisted of core-technology and know-how, working capital of $0.2 million and property, plant and equipment of less than $0.1 million. A long-term deferred tax liability of $1.1 million was recorded for the differing book and tax basis of the ITC assets and liabilities.  Provisional amounts have been recorded for the related tax activity as of December 31, 2017. Final adjustments are expected to be made during the fourth quarter of fiscal 2017.

[0001628280-18-000993:notes:13]
The following table summarizes the consideration paid for ITC and the amounts of the assets acquired and liabilities assumed recognized at the acquisition date, as well as the fair value at the acquisition date (in millions):

[0001628280-18-000993:notes:14]
[same as prior period, unchanged from 0001628280-17-011077:notes:14]

[0001628280-18-000993:notes:15]
At the Acquisition date, the Company valued the Acquisition at $4.2 million (excluding Acquisition costs), using a value of $4.02 per share, which was the closing price of the Company's common stock on the date of Acquisition plus $0.1 million in cash and including $0.6 million of contingent consideration for the Make Whole Payment valued as of the closing date.  Acquisition costs of less than $0.1 million were recorded in selling, general and administrative costs.

[0001628280-18-000993:notes:16]
The results of ITC's operations, which were not significant from the date of acquisition until December 31, 2017, are included in the Company’s consolidated results from the date of Acquisition of September 25, 2017, for the three and nine months ended December 31, 2017. Assuming the Acquisition had occurred on April 1, 2017 and 2016, the impact on the consolidated results of the Company would not have been significant.

[0001628280-18-000993:notes:17]
[same as prior period, unchanged from 0001628280-17-011077:notes:17]

[0001628280-18-000993:notes:18]
At the time of the Acquisition, the Company allocated the purchase price to the assets acquired and liabilities assumed at their estimated fair values as of the date of Acquisition. The excess of the purchase price paid by the Company over the estimated fair value of net assets acquired of $1.7 million has been recorded as goodwill in the Company's Grid segment. Goodwill represents the value associated with the acquired workforce and synergies related to the merger of the two companies.

[0001628280-18-000993:notes:19]
[same as prior period, unchanged from 0001628280-17-011077:notes:19]

[0001628280-18-000993:notes:20]
[same as prior period, unchanged from 0001628280-17-011077:notes:20]

[0001628280-18-000993:notes:21]
The Company early adopted ASU 2017-04 as of September 30, 2017.  The Company will perform an annual impairment assessment on goodwill, unless events occur in the interim periods to indicate impairment may have occurred.  The Company did not identify any triggering events in the period between the date of Acquisition and December 31, 2017, which would require subsequent interim testing of goodwill.  As such, the Company expects to perform its annual goodwill impairment test during the fourth quarter of fiscal 2017.  The Company will compare the fair value of its reporting unit to its carrying value. If the carrying value of the net assets assigned to the reporting unit exceeds the fair value of the reporting unit, then the Company would record an impairment loss equal to the difference.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001628280-18-000993:notes:22]
Commitments and Contingencies

[0001628280-18-000993:notes:23]
Legal Contingencies

[0001628280-18-000993:notes:24]
From time to time, the Company is involved in legal and administrative proceedings and claims of various types. The Company records a liability in its consolidated financial statements for these matters when a loss is known or considered probable and the amount can be reasonably estimated. The Company reviews these estimates each accounting period as additional information is known and adjusts the loss provision when appropriate. If a matter is both probable to result in a liability and the amounts of loss can be reasonably estimated, the Company estimates and discloses the possible loss or range of loss to the extent necessary to make the consolidated financial statements not misleading. If the loss is not probable or cannot be reasonably estimated, a liability is not recorded in its consolidated financial statements.

[0001628280-18-000993:notes:25]
On September 13, 2011, the Company commenced a series of legal actions in China against Sinovel Wind Group Co. Ltd. (“Sinovel”). The Company’s Chinese subsidiary, Suzhou AMSC Superconductor Co. Ltd., filed a claim for arbitration with the Beijing Arbitration Commission in accordance with the terms of the Company’s supply contracts with Sinovel. The case is captioned (2011) Jing Zhong An Zi No. 963.  The Company alleges that Sinovel committed various material breaches of its contracts with the Company and Sinovel has refused to pay past due amounts for prior shipments of core electrical components and spare parts. The Company is seeking compensation for past product shipments and retention (including interest) in the amount of approximately RMB 485 million (approximately $75 million) due to Sinovel’s breaches of its contracts. The Company is also seeking specific performance of its existing contracts as well as reimbursement of all costs and reasonable expenses with respect to the arbitration. The value of the undelivered components under the existing contracts, including the deliveries refused by Sinovel in March 2011, amounts to approximately RMB 4.6 billion (approximately $707 million).

[0001628280-18-000993:notes:26]
On October 8, 2011, Sinovel filed with the Beijing Arbitration Commission an application under the caption (2011) Jing Zhong An Zi No. 963, for a counterclaim against the Company for breach of the same contracts under which the Company filed its original arbitration claim. Sinovel claims, among other things, that the goods supplied by the Company do not conform to the standards specified in the contracts and claims damages in the amount of approximately RMB 1.2 billion (approximately $184 million) upon Sinovel’s requests for change of counterclaim. On February 27, 2012, Sinovel filed with the Beijing Arbitration Commission an application under the caption (2012) Jing Zhong An Zi No. 157, against the Company for breach of the same contracts under which the Company filed its original arbitration claim. Sinovel claims, among other things, that the goods supplied by the Company do not conform to the standards specified in the contracts and claims damages in the amount of approximately RMB 105 million (approximately $16 million). The Company believes that Sinovel’s claims are without merit and it intends to defend these actions vigorously. Since the proceedings in this matter are still in the early technical review phase, the Company cannot reasonably estimate possible losses or range of losses at this time.

[0001628280-18-000993:notes:27]
Other

[0001628280-18-000993:notes:28]
The Company enters into long-term construction contracts with customers that require the Company to obtain performance bonds. The Company is required to deposit an amount equivalent to some or all the face amount of the performance bonds into an escrow account until the termination of the bond. When the performance conditions are met, amounts deposited as collateral for the performance bonds are returned to the Company. In addition, the Company has various contractual arrangements in which minimum quantities of goods or services have been committed to be purchased on an annual basis.

[0001628280-18-000993:notes:29]
As of December 31, 2017, the Company had $0.2 million of restricted cash included in long-term assets. These amounts included in restricted cash primarily represent deposits to secure letters of credit for various supply contracts. These deposits are held in interest bearing accounts.

[0001628280-18-000993:notes:30]
During the nine months ended December 31, 2017, the Company received $1.0 million related to the achievement of certain milestones following the previous sale of the Company's minority interest in Blade Dynamics Limited.

[0001628280-18-000993:notes:31]
On September 25, 2017, the Company acquired ITC for a purchase price of approximately $3.8 million, consisting of $0.1 million in cash and the AMSC Shares. The Company paid certain selling stockholders the Make Whole Payment given that the value of the AMSC Shares sold was less than the agreed upon purchase price.  The amount of this payment, which was made on January 5, 2018, was $0.7 million and settled the related contingent liability. See Note 4, “Acquisitions and Related Goodwill” for further discussion.


## us-gaap:DebtDisclosureTextBlock

[0001628280-18-000993:notes:32]
Debt

[0001628280-18-000993:notes:33]
Senior Secured Term Loans

[0001628280-18-000993:notes:34]
On December 19, 2014, the Company entered into a second amendment to its Loan and Security Agreement with Hercules (the “Hercules Second Amendment”) and entered into a new term loan, borrowing an additional $1.5 million (the “Term Loan C”).  After closing fees and expenses, the net proceeds to the Company for the Term Loan C were $1.4 million. The Company made interest only payments at an interest rate of 11% through March 16, 2017 when the interest rate was increased to 11.25%, until maturity on June 1, 2017, when Term Loan C was repaid in its entirety.

[0001628280-18-000993:notes:35]
Hercules received warrants to purchase 13,927 shares of common stock (the “First Warrant”) and 25,641 shares of common stock (the “Second Warrant”) in conjunction with prior term loans that have been repaid in full.  Due to certain adjustment provisions within the warrants, they qualified for liability accounting.  The fair value of the warrants, $0.4 million and $0.2 million, respectively, was recorded upon issuance to debt discount and a warrant liability. In conjunction with the Hercules Second Amendment, the First Warrant and Second Warrant were canceled and replaced with the issuance of a new warrant (the “Hercules Warrant”) to purchase 58,823 shares of common stock at an exercise price of $7.85 per share, subject to certain price-based and other anti-dilution adjustments.  The Hercules Warrant expires on June 30, 2020.  See Note 12, “Warrants and Derivative Liabilities”, for a discussion on the Hercules Warrant and the valuation assumptions used.

[0001628280-18-000993:notes:36]
The Company recorded no interest expense for the three months ended December 31, 2017 and less than $0.1 million for the three months ended December 31, 2016.  Included in the prior year period was less than $0.1 million of non-cash interest expense related to the amortization of the debt discount on the respective term loans.  Interest expense on the Term Loans for the nine months ended December 31, 2017 and 2016, was less than $0.1 million and $0.3 million, respectively.  Included in the nine months ended December 31, 2017 and 2016 were less than $0.1 million and $0.1 million, respectively, of non-cash interest expense related to the amortization of debt discount on the respective Term Loans.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001628280-18-000993:notes:37]
[same as prior period, unchanged from 0001628280-17-011077:notes:35]

[0001628280-18-000993:notes:38]
The Company accounts for its warrants and contingent consideration as liabilities due to certain adjustment provisions within the instruments, which require that they be recorded at fair value. The warrants are subject to revaluation at each balance sheet date and any change in fair value is recorded as a change in fair value of warrants until the earlier of its expiration or its exercise at which time the warrant liability will be reclassified to equity. The Company calculated the fair value of the warrants utilizing an integrated lattice model.  The contingent consideration is subject to revaluation at each balance sheet date and any change in fair value is recorded as a change in fair value of contingent consideration until the earlier of its settlement or expiration. The Company determined the fair value of the contingent consideration utilizing a Black Scholes option pricing method upon acquisition and as of September 30, 2017.  As of December 31, 2017, the actual amount due for the contingent consideration was determined according to the stated formula in the agreement.  See Note 5, "Fair Value Measurements", for further discussion.

[0001628280-18-000993:notes:39]
[same as prior period, unchanged from 0001628280-17-011077:notes:37]

[0001628280-18-000993:notes:40]
[same as prior period, unchanged from 0001628280-17-011077:notes:38]

[0001628280-18-000993:notes:41]
[same as prior period, unchanged from 0001628280-17-011077:notes:39]

[0001628280-18-000993:notes:42]
| Fiscal Year 17 | September 30, 2017 |  | June 30, 2017 |
| Risk-free interest rate | 1.05% |  | 1.05% |
| Expected annual dividend yield | — |  | — |
| Expected volatility | 77.95% |  | 78.25% |
| Term (years) | 0.01 |  | 0.26 |
| Fair value | $— |  | $— |

[0001628280-18-000993:notes:43]
[same as prior period, unchanged from 0001628280-17-011077:notes:41]

[0001628280-18-000993:notes:44]
The Company recorded no change in the fair value of the Exchanged Warrant during the three and nine months ended December 31, 2017.  The Company recorded net gains of $0.1 million and $0.3 million resulting from a decrease in the fair value of the Exchanged Warrant in each of the three and nine months ended December 31, 2016, respectively.

[0001628280-18-000993:notes:45]
[same as prior period, unchanged from 0001628280-17-011077:notes:43]

[0001628280-18-000993:notes:46]
[same as prior period, unchanged from 0001628280-17-011077:notes:44]

[0001628280-18-000993:notes:47]
[same as prior period, unchanged from 0001628280-17-011077:notes:45]

[0001628280-18-000993:notes:48]
| Fiscal Year 17 | December 31, 2017 |  | September 30, 2017 |  | June 30, 2017 |
| Risk-free interest rate | 1.98% |  | 1.56% |  | 1.58% |
| Expected annual dividend yield | — |  | — |  | — |
| Expected volatility | 69.11% |  | 63.97% |  | 67.76% |
| Term (years) | 2.46 |  | 2.72 |  | 2.97 |
| Fair value | $0.1 million |  | $0.1 million |  | $0.1 million |

[0001628280-18-000993:notes:49]
[same as prior period, unchanged from 0001628280-17-011077:notes:47]

[0001628280-18-000993:notes:50]
The Company recorded no change and a net gain of $0.1 million, resulting from decreases in the fair value of the Hercules Warrant during the three and nine months ended December 31, 2017, respectively.  The Company recorded no change in the fair value of the Hercules Warrant during the three and nine months ended December 31, 2016.

[0001628280-18-000993:notes:51]
[same as prior period, unchanged from 0001628280-17-011077:notes:49]

[0001628280-18-000993:notes:52]
[same as prior period, unchanged from 0001628280-17-011077:notes:50]

[0001628280-18-000993:notes:53]
[same as prior period, unchanged from 0001628280-17-011077:notes:51]

[0001628280-18-000993:notes:54]
| Fiscal Year 17 | December 31, 2017 |  | September 30, 2017 |  | June 30, 2017 |
| Risk-free interest rate | 1.87% |  | 1.49% |  | 1.44% |
| Expected annual dividend yield | — |  | — |  | — |
| Expected volatility | 65.86% |  | 65.64% |  | 67.21% |
| Term (years) | 1.87 |  | 2.12 |  | 2.37 |
| Fair value | $0.4 million |  | $0.8 million |  | $0.9 million |

[0001628280-18-000993:notes:55]
[same as prior period, unchanged from 0001628280-17-011077:notes:53]

[0001628280-18-000993:notes:56]
The Company recorded net gains of $0.4 million and $1.4 million, resulting from decreases in the fair value of the November 2014 Warrant during the three and nine months ended December 31, 2017, respectively.  The Company recorded no change and a net gain of $0.3 million, resulting from the decrease in the fair value of the November 2014 Warrant in the three and nine months ended December 31, 2016, respectively.

[0001628280-18-000993:notes:57]
[same as prior period, unchanged from 0001628280-17-011077:notes:55]

[0001628280-18-000993:notes:58]
The Company evaluated the ITC acquisition Make Whole Payment set forth in the SPA (see Note 5, "Fair Value Measurements" for further details), which ultimately required net settlement cash, and determined the contingent consideration qualified for liability classification and derivative treatment under ASC 815.  As a result, for each period the fair value of the contingent consideration was remeasured and the resulting gain or loss was recognized in operating expenses.

[0001628280-18-000993:notes:59]
[same as prior period, unchanged from 0001628280-17-011077:notes:57]

[0001628280-18-000993:notes:60]
| Fiscal Year 17 | September 30, 2017 |  | September 25, 2017 |
| Risk-free interest rate | 1.09% |  | 1.09% |
| Expected annual dividend yield | — |  | — |
| Expected volatility | 66.54% |  | 65.71% |
| Term (years) | 0.31 |  | 0.32 |
| Fair value | $0.4 million |  | $0.6 million |

[0001628280-18-000993:notes:61]
All of the stock related to this liability was sold as of December 5, 2017 and the amount of the Make Whole Payment was calculated to be $0.7 million, and subsequently paid on January 5, 2018.  As such, no fair value estimate using a Black Scholes model was needed as the liability was recorded at the known settlement value for the period ending December 31, 2017.  The Company recorded net losses of $0.3 million and $0.1 million resulting from increases in the fair value of the contingent consideration in the three and nine months ended December 31, 2017, respectively.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001628280-18-000993:notes:62]
[same as prior period, unchanged from 0001628280-17-011077:notes:60]

[0001628280-18-000993:notes:63]
The Company accounts for its stock-based compensation at fair value. The following table summarizes stock-based compensation expense by financial statement line item for the three and nine months ended December 31, 2017 and 2016 (in thousands):

[0001628280-18-000993:notes:64]
|  | Three months ended December 31, |  | Nine months ended December 31, |
|  | 2017 |  | 2016 |  | 2017 |  | 2016 |
| Cost of revenues | $ | 39 |  |  | $ | 40 |  |  | $ | 98 |  |  | $ | 139 |  |
| Research and development | 184 |  |  | 61 |  |  | 294 |  |  | 153 |  |
| Selling, general and administrative | 660 |  |  | 512 |  |  | 1,723 |  |  | 1,974 |  |
| Total | $ | 883 |  |  | $ | 613 |  |  | $ | 2,115 |  |  | $ | 2,266 |  |

[0001628280-18-000993:notes:65]
The Company issued 37,140 shares of immediately vested common stock and 800,500 shares of restricted stock awards during the nine months ended December 31, 2017, and issued 35,000 shares of immediately vested common stock, and granted 126,000 restricted stock awards during the nine months ended December 31, 2016.  These restricted stock awards generally vest over 2-3 years.  Awards for restricted stock include both time-based and performance-based awards.  For options and awards that vest upon the passage of time, expense is being recorded over the vesting period.  Performance-based awards are expensed over the requisite service period based on probability of achievement.  In addition, the Company issued 16,667 restricted stock units under the 2007 Stock Incentive Plan during the nine months ended December 31, 2017, each of which represents the right to receive one share of common stock in connection with a severance agreement entered into with one of the Company's former executive officers. These restricted stock units vested and were settled in shares of common stock on the eighth day after receipt of an irrevocable release.

[0001628280-18-000993:notes:66]
The estimated fair value of the Company’s stock-based awards, less expected annual forfeitures, is amortized over the awards’ service period. The total unrecognized compensation cost for unvested outstanding stock options was $0.3 million at December 31, 2017. This expense will be recognized over a weighted average expense period of approximately 1.2 years. The total unrecognized compensation cost for unvested outstanding restricted stock was $2.8 million at December 31, 2017. This expense will be recognized over a weighted-average expense period of approximately 2.0 years.

[0001628280-18-000993:notes:67]
The Company did not grant any stock options during the three and nine months ended December 31, 2017.  During the nine months ended December 31, 2016, the Company granted 9,703 stock options.  These options will vest over 2 years.  The weighted average assumptions used in the Black Scholes valuation model for stock options granted during the nine months ended December 31, 2016 are as follows:

[0001628280-18-000993:notes:68]
|  | December 31, 2017 |  | December 31, 2016 |
| Expected volatility | N/A |  | 67.6 | % |
| Risk-free interest rate | N/A |  | 1.3 | % |
| Expected life (years) | N/A |  | 5.7 |  |
| Dividend yield | N/A |  | None |  |


## us-gaap:EarningsPerShareTextBlock

[0001628280-18-000993:notes:69]
[same as prior period, unchanged from 0001628280-17-011077:notes:67]

[0001628280-18-000993:notes:70]
Basic net loss per share (“EPS”) is computed by dividing net loss by the weighted-average number of common shares outstanding for the period. Where applicable, diluted EPS is computed by dividing the net loss by the weighted-average number of common shares and dilutive common equivalent shares outstanding during the period, calculated using the treasury stock method. Common equivalent shares include the effect of restricted stock, exercise of stock options and warrants and contingently issuable shares. For the three and nine months ended December 31, 2017, 1.2 million shares were not included in the calculation of diluted EPS as they were considered anti-dilutive, of which 0.3 million relate to outstanding stock options, and 0.9 million relate to outstanding warrants.  For the three and nine months ended December 31, 2016, 1.6 million shares were not included in the calculation of diluted EPS as they were considered anti-dilutive, of which 0.4 million relate to outstanding stock options, and 1.2 million relate to outstanding warrants.

[0001628280-18-000993:notes:71]
The following table reconciles the numerators and denominators of the earnings per share calculation for the three and nine months ended December 31, 2017 and 2016 (in thousands, except per share data):

[0001628280-18-000993:notes:72]
|  | Three months ended December 31, |  | Nine months ended December 31, |
|  | 2017 |  | 2016 |  | 2017 |  | 2016 |
| Numerator: |  |  |  |  |  |  |  |
| Net loss | $ | (4,248 | ) |  | $ | (2,768 | ) |  | $ | (26,782 | ) |  | $ | (20,448 | ) |
| Denominator: |  |  |  |  |  |  |  |
| Weighted-average shares of common stock outstanding | 20,889 |  |  | 14,203 |  |  | 19,189 |  |  | 14,175 |  |
| Weighted-average shares subject to repurchase | (940 | ) |  | (411 | ) |  | (575 | ) |  | (429 | ) |
| Shares used in per-share calculation ― basic | 19,949 |  |  | 13,792 |  |  | 18,614 |  |  | 13,746 |  |
| Shares used in per-share calculation ― diluted | 19,949 |  |  | 13,792 |  |  | 18,614 |  |  | 13,746 |  |
| Net loss per share ― basic | $ | (0.21 | ) |  | $ | (0.20 | ) |  | $ | (1.44 | ) |  | $ | (1.49 | ) |
| Net loss per share ― diluted | $ | (0.21 | ) |  | $ | (0.20 | ) |  | $ | (1.44 | ) |  | $ | (1.49 | ) |


## us-gaap:FairValueDisclosuresTextBlock

[0001628280-18-000993:notes:73]
[same as prior period, unchanged from 0001628280-17-011077:notes:71]

[0001628280-18-000993:notes:74]
[same as prior period, unchanged from 0001628280-17-011077:notes:72]

[0001628280-18-000993:notes:75]
[same as prior period, unchanged from 0001628280-17-011077:notes:73]

[0001628280-18-000993:notes:76]
The Company provides a gross presentation of activity within Level 3 measurement roll-forward and details of transfers in and out of Level 1 and 2 measurements.  A change in the hierarchy of an investment from its current level is reflected in the period during which the pricing methodology of such investment changes.  Disclosure of the transfer of securities from Level 1 to Level 2 or Level 3 is made in the event that the related security is significant to total cash and investments.  The Company did not have any transfers of assets and liabilities from Level 1, but did transfer $0.7 million related to the contingent liability from Level 3 to Level 2 of the fair value measurement hierarchy during the three and nine months ended December 31, 2017.  The fair value calculation at December 31, 2017 was based on actual observable stock price inputs following the sale of all of the related shares, in place of the Company's assumptions which had been used in the prior period.

[0001628280-18-000993:notes:77]
[same as prior period, unchanged from 0001628280-17-011077:notes:75]

[0001628280-18-000993:notes:78]
The following table provides the assets and liabilities carried at fair value on a recurring basis, measured as of December 31, 2017 and March 31, 2017 (in thousands):

[0001628280-18-000993:notes:79]
|  | TotalCarryingValue |  | Quoted Prices inActive Markets(Level 1) |  | Significant OtherObservable Inputs(Level 2) |  | SignificantUnobservable Inputs(Level 3) |
| December 31, 2017: |  |  |  |  |  |  |  |
| Assets: |  |  |  |  |  |  |  |
| Cash equivalents | $ | 17,944 |  |  | $ | 17,944 |  |  | $ | — |  |  | $ | — |  |
| Derivative liabilities: |  |  |  |  |  |  |  |
| Acquisition contingent consideration | $ | 687 |  |  | $ | — |  |  | $ | 687 |  |  | $ | — |  |
| Warrants | 455 |  |  | — |  |  | — |  |  | 455 |  |
| Total derivative liabilities | $ | 1,142 |  |  | $ | — |  |  | $ | 687 |  |  | $ | 455 |  |

[0001628280-18-000993:notes:80]
[same as prior period, unchanged from 0001628280-17-011077:notes:78]

[0001628280-18-000993:notes:81]
[same as prior period, unchanged from 0001628280-17-011077:notes:79]

[0001628280-18-000993:notes:82]
|  | Warrants |  | Acquisition Contingent Consideration |
| April 1, 2017 | $ | 1,923 |  |  | $ | — |  |
| Issuance of contingent consideration | — |  |  | 571 |  |
| Mark to market adjustment | (1,468 | ) |  | 71 |  |
| Settlement fees | — |  |  | 45 |  |
| Balance at December 31, 2017 | $ | 455 |  |  | $ | 687 |  |

[0001628280-18-000993:notes:83]
[same as prior period, unchanged from 0001628280-17-011077:notes:81]

[0001628280-18-000993:notes:84]
[same as prior period, unchanged from 0001628280-17-011077:notes:82]

[0001628280-18-000993:notes:85]
[same as prior period, unchanged from 0001628280-17-011077:notes:83]

[0001628280-18-000993:notes:86]
[same as prior period, unchanged from 0001628280-17-011077:notes:84]

[0001628280-18-000993:notes:87]
[same as prior period, unchanged from 0001628280-17-011077:notes:85]

[0001628280-18-000993:notes:88]
[same as prior period, unchanged from 0001628280-17-011077:notes:86]

[0001628280-18-000993:notes:89]
[same as prior period, unchanged from 0001628280-17-011077:notes:87]

[0001628280-18-000993:notes:90]
Contingent consideration relates to the Make Whole Provision set forth in the SPA that requires the Company to guarantee the purchase price of the acquisition should the aggregate proceeds of the resale of AMSC Shares sold by selling stockholders during the first 90 days after the effectiveness of the Resale Registration Statement be less than the agreed upon purchase price for such AMSC Shares (per the terms of the SPA) sold during such 90 day period.  See Note 12, "Warrants and Derivative Liabilities" and Note 4, “Acquisition and Related Goodwill” for further discussion.  The Company relied on a Black Scholes option pricing method to determine the fair value of the contingent consideration on the date of acquisition and continued to revalue the fair value of the contingent consideration at each subsequent balance sheet date until the final settlement date, with the change in fair value recorded in the current period operating loss.  This liability was settled on January 5, 2018.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001628280-18-000993:notes:91]
[same as prior period, unchanged from 0001628280-17-011077:notes:89]

[0001628280-18-000993:notes:92]
The Company recorded income tax expenses of $0.6 million and $0.5 million in the three and nine months ended December 31, 2017, respectively.  The Company recorded income tax benefit of $0.1 million and expense of $1.0 million in the three and nine months ended December 31, 2016, respectively.

[0001628280-18-000993:notes:93]
As a result of purchase accounting for the acquired intangible assets in the ITC acquisition, the Company recorded a deferred tax liability of $1.1 million for the difference in book and tax basis.  As a result, the Company was able to benefit additional deferred tax assets and therefore released a corresponding valuation allowance of $1.1 million during the nine months ended December 31, 2017.  Goodwill recognized in the acquisition is not deductible for tax purposes.

[0001628280-18-000993:notes:94]
Section 382 of the U.S. Internal Revenue Code of 1986, as amended (the “IRC”), provides limits on the extent to which a corporation that has undergone an ownership change (as defined in the IRC) can utilize any net operating loss ("NOL") and general business tax credit carryforwards it may have. The Company conducted a study as a result of the Company's May 2017 equity offering to determine whether Section 382 could limit the use of its carryforwards in this manner.  After completing this study, the Company has concluded that the limitation will not have a material impact on its ability to utilize its NOL carryforwards.  If there were material ownership changes subsequent to the study, such changes could limit the Company's ability to utilize its NOL carryforwards. The Company increased its NOL’s by $0.3 million due to acquired losses in the nine months ended December 31, 2017 from ITC. The Company conducted a study on the acquired NOL and concluded that the limitations under Section 382 will not have a material impact on its ability to utilize its NOL carryforwards.

[0001628280-18-000993:notes:95]
On December 22, 2017, the Tax Cuts and Jobs Act of 2017 (“tax reform”) was signed into law. ASC Topic 740 requires deferred tax assets and liabilities to be measured using the enacted rate for the period in which they are expected to reverse. The tax reform was enacted as of December 22, 2017.  Accordingly, the new 21% U.S. Federal corporate tax rate was used to measure the U.S. deferred tax assets and liabilities that will reverse in future periods. The Company's reduction to its net U.S. deferred tax asset was offset by a corresponding reduction to its valuation allowance. In addition, the new legislation includes a transition tax in which all foreign earnings are deemed to be repatriated to the U.S. and taxable at specified rates included within the tax reform. The Company is in the process of calculating the impact of the transition tax.  The analysis is complex and encompasses many years.  The Company is working with its foreign subsidiaries and their local tax service providers to gather historical information, including historical tax returns, in order to complete the calculation. Pursuant to Staff Accounting Bulletin No. 118, the Company's measurement period for the tax impact of the tax law changes is still open. At this time, the Company does not anticipate a material impact due to the transition tax, and the Company anticipates completing the analysis under ASC Topic 740 by March 31, 2018, at which time the Company expects to be in a position to book any required adjustments for any transition tax impact. The Company does not anticipate any other material tax exposure due to the tax reform at this time.

[0001628280-18-000993:notes:96]
Accounting for income taxes requires a two-step approach to recognizing and measuring uncertain tax positions.  The first step is to evaluate the tax position for recognition by determining if, based on the technical merits, it is more likely than not the position will be sustained upon audit, including resolution of related appeals or litigation processes, if any.  The second step is to measure the tax benefit as the largest amount that is more than 50% likely to be realized upon ultimate settlement.  The Company re-evaluates these uncertain tax positions on a quarterly basis.  The evaluation is based on factors including, but not limited to, changes in facts or circumstances, changes in tax law, effectively settled issues under audit and new audit activity.  Any changes in these factors could result in the recognition of a tax benefit or an additional charge to the tax provision.  The Company did not identify any uncertain tax positions in the nine months ended December 31, 2017 and did not have any gross unrecognized tax benefits as of March 31, 2017.


## us-gaap:InventoryDisclosureTextBlock

[0001628280-18-000993:notes:97]
[same as prior period, unchanged from 0001628280-17-011077:notes:94]

[0001628280-18-000993:notes:98]
Inventory at December 31, 2017 and March 31, 2017 consisted of the following (in thousands):

[0001628280-18-000993:notes:99]
|  | December 31, 2017 |  | March 31, 2017 |
| Raw materials | $ | 5,544 |  |  | $ | 4,263 |  |
| Work-in-process | 1,626 |  |  | 426 |  |
| Finished goods | 7,931 |  |  | 8,016 |  |
| Deferred program costs | 2,028 |  |  | 4,757 |  |
| Net inventory | $ | 17,129 |  |  | $ | 17,462 |  |

[0001628280-18-000993:notes:100]
The Company recorded inventory write-downs of $0.1 million and $0.4 million for the three and nine months ended December 31, 2017.  The Company recorded inventory write-downs of $0.4 million and $1.1 million for the three and nine months ended December 31, 2016.  These write downs were based on evaluating its inventory on hand for excess quantities and obsolescence.

[0001628280-18-000993:notes:101]
Deferred program costs as of December 31, 2017 and March 31, 2017 primarily represent costs incurred on programs accounted for under contract accounting where the Company needs to complete development milestones before revenue and costs will be recognized.


## us-gaap:LoansNotesTradeAndOtherReceivablesDisclosureTextBlock

[0001628280-18-000993:notes:102]
[same as prior period, unchanged from 0001628280-17-011077:notes:99]

[0001628280-18-000993:notes:103]
Accounts receivable at December 31, 2017 and March 31, 2017 consisted of the following (in thousands):

[0001628280-18-000993:notes:104]
|  | December 31, 2017 |  | March 31, 2017 |
| Accounts receivable (billed) | $ | 10,379 |  |  | $ | 7,436 |  |
| Accounts receivable (unbilled) | 1,727 |  |  | 574 |  |
| Less: Allowance for doubtful accounts | (54 | ) |  | (54 | ) |
| Accounts receivable, net | $ | 12,052 |  |  | $ | 7,956 |  |


## us-gaap:NewAccountingPronouncementsAndChangesInAccountingPrinciplesTextBlock

[0001628280-18-000993:notes:105]
Recent Accounting Pronouncements

[0001628280-18-000993:notes:106]
In May 2014, the Financial Accounting Standards Board (“FASB”) and the International Accounting Standards Board ("IASB") issued, ASU 2014-09, Revenue from Contracts with Customers (Topic 606). The guidance substantially converges final standards on revenue recognition between the FASB and IASB providing a framework on addressing revenue recognition issues and, upon its effective date, replaces almost all existing revenue recognition guidance, including industry-specific guidance, in current U.S. generally accepted accounting principles. The FASB has subsequently issued the following amendments to ASU 2014-09 which are all effective for annual reporting periods beginning after December 15, 2017.

[0001628280-18-000993:notes:107]
| • | In March 2016, the FASB issued ASU No. 2016-08, Revenue from Contracts with Customers (Topic 606): Principal versus Agent Considerations, which clarifies the implementation guidance on principal versus agent considerations. |

[0001628280-18-000993:notes:108]
| • | In April 2016, the FASB issued ASU No. 2016-10, Revenue from Contracts with Customers (Topic 606): Identifying Performance Obligations and Licensing, which clarifies certain aspects of identifying performance obligations and licensing implementation guidance. |

[0001628280-18-000993:notes:109]
| • | In May 2016, the FASB issued ASU No. 2016-12, Revenue from Contracts with Customers (Topic 606): Narrow- Scope Improvements and Practical Expedients related to disclosures of remaining performance obligations, as well as other amendments to guidance on collectability, non-cash consideration and the presentation of sales and other similar taxes collected from customers. |

[0001628280-18-000993:notes:110]
| • | In December 2016, the FASB issued ASU No. 2016-20, Technical Corrections and Improvements to Topic 606, Revenue from Contracts with Customers, which amends certain narrow aspects of the guidance issued in ASU 2014-09 including guidance related to the disclosure of remaining performance obligations and prior-period performance obligations, as well as other amendments to the guidance on loan guarantee fees, contract costs, refund liabilities, advertising costs and the clarification of certain examples. |

[0001628280-18-000993:notes:111]
As of December 31, 2017, the Company has made significant progress towards completing its assessment of the potential effects of ASU 2014-09 and its amendments on its consolidated financial statements, and is actively assessing the potential effects on business processes, systems and controls to support revenue recognition and the related disclosures under this ASU.  The Company’s assessment includes a detailed review of representative contracts from each of the Company’s revenue streams and a comparison of its historical accounting policies and practices to the new standard. The Company is required to adopt the new standards on April 1, 2018, and expects to do so retrospectively with the cumulative effect of initially applying the guidance recognized at the date of initial application (the modified retrospective transition method).  Additionally, this guidance could lead to recognizing certain revenue transactions sooner than in the past on certain contracts, as the Company will need to estimate the revenue it will be entitled to upon contract completion, and later on other contracts, due to lack of an enforceable right to payment for performance obligations satisfied over time.  The Company's preliminary assessment of this adoption method supports the determination that there are no expected changes in the accounting for its largest revenue stream which includes Inox Wind Limited as its primary customer.  Across other revenue streams the timing of revenue recognition could be affected for multiple types of contracts, primarily multiple element contracts in its grid business unit, but those differences are not expected to have a material impact on its consolidated financial statements.  However, the Company's assessment is not yet finalized and is subject to change.  Additionally, the Company is currently evaluating any tax implications the adoption of this new standard may have on the consolidated financial statements. As part of this analysis, the Company is evaluating its information technology capabilities and systems, and does not expect to incur significant information technology costs to modify systems currently in place.

[0001628280-18-000993:notes:112]
During the fourth quarter of fiscal 2017, the Company plans to assess its current revenue controls, and identify and implement any changes that may be necessary to comply with its new revenue policies and the provisions of ASU 2014-09, which will be effective for the Company as of April 1, 2018.

[0001628280-18-000993:notes:113]
In January 2016, the FASB issued ASU 2016-01, Financial Instruments-Overall (Subtopic 825-10): Recognition and Measurement of Financial Assets and Financial Liabilities.  The amendments in ASU 2016-01 will enhance the reporting model for financial instruments to provide users of financial statements with more decision-useful information. This ASU is effective for annual reporting periods beginning after December 15, 2017, and interim periods within those fiscal years.  The Company does not expect any significant changes to the consolidated financial statement results with the adoption of ASU 2016-01.

[0001628280-18-000993:notes:114]
In February 2016, the FASB issued ASU 2016-02, Leases (Topic 842). The guidance in this ASU supersedes the leasing guidance in Topic 840, Leases. Under the new guidance, lessees are required to recognize lease assets and lease liabilities on the balance sheet for all leases with terms longer than 12 months. Leases will be classified as either finance or operating, with classification affecting the pattern of expense recognition in the income statement. This ASU is effective for fiscal years beginning after December 15, 2019, including interim periods within those fiscal years. A modified retrospective transition approach is required for lessees for capital and operating leases existing at, or entered into after, the beginning of the earliest comparative period presented in the financial statements, with certain practical expedients available. The Company is currently evaluating the effects adoption of this guidance will have on its consolidated financial statements.

[0001628280-18-000993:notes:115]
In June 2016, the FASB issued ASU 2016-13, Financial Instruments-Credit Losses (Topic 326): Measurement of Credit Losses on Financial Instruments.  The amendments in ASU 2016-13 will provide more decision-useful information about the expected credit losses on financial instruments and other commitments to extend credit held by a reporting entity at each reporting date. The ASU is effective for annual reporting periods beginning after December 15, 2019, including interim periods within that year.  The Company is currently evaluating the impact, if any, the adoption of ASU 2016-13 may have on its consolidated financial statements.

[0001628280-18-000993:notes:116]
In 2016, the FASB issued the following two ASU's on Statement of Cash Flows (Topic 230).  Both amendments are effective for annual reporting periods beginning after December 15, 2017, including interim periods within that year.

[0001628280-18-000993:notes:117]
| • | In August 2016, the FASB issued ASU 2016-15, Statement of Cash Flows (Topic 230): Classification of Certain Cash Receipts and Cash Payments. The amendments in ASU 2016-15 will provide more guidance towards the classification of multiple different types of cash flows in order to reduce the diversity in reporting across entities. |

[0001628280-18-000993:notes:118]
| • | In November 2016, the FASB issued ASU 2016-18, Statement of Cash Flows (Topic 230): Restricted Cash. The amendments in ASU 2016-18 will explain the change during the period in the total of cash, cash equivalents, and amounts generally described as restricted cash or restricted cash equivalents. Therefore, amounts generally described as restricted cash and restricted cash equivalents should be included with cash and cash equivalents when reconciling the beginning-of-period and end-of-period total amounts shown on the statement of cash flows. |

[0001628280-18-000993:notes:119]
The Company does not expect any significant changes to the consolidated financial statement results with the adoption of ASU 2016-15 and ASU 2016-18.

[0001628280-18-000993:notes:120]
In October 2016, the FASB issued ASU 2016-16, Income Taxes (Topic 740): Intra-Entity Transfers of Assets Other Than Inventory.  The amendments in ASU 2016-16 will improve the accounting for the income tax consequences of intra-entity transfers of assets other than inventory. The ASU is effective for annual reporting periods beginning after December 15, 2017, including interim periods within that year.  The Company does not anticipate any significant changes to the consolidated financial statement results with the adoption of ASU 2016-16.

[0001628280-18-000993:notes:121]
In January 2017, the FASB issued ASU 2017-01, Business Combinations.  The amendments in ASU 2017-01 will clarify the definition of a business with the objective of adding guidance to assist entities with evaluating whether transactions should be accounted for as acquisitions (or disposals) of assets or businesses. The ASU is effective for annual reporting periods beginning after December 15, 2017, including interim periods within those periods.  The Company adopted ASU 2017-01 effective September 30, 2017, following the Acquisition of ITC.  The Company considered these amendments in its decision to record the combination of the entities as an acquisition of a business.  See Note 4, "Acquisition and Related Goodwill", for further details.  These impacts have been included in the consolidated financial statements.

[0001628280-18-000993:notes:122]
In January 2017, the FASB issued ASU 2017-03, Accounting Changes and Error Corrections (Topic 250) and Investments - Equity Method and Joint Ventures.  The amendments in ASU 2017-03 provide additional detail surrounding disclosures required related to adoption of new pronouncements. The ASU is effective for the periods of each related pronouncement.  The Company is currently evaluating the impact the adoption of ASU 2017-03 may have on its consolidated financial statements.

[0001628280-18-000993:notes:123]
In January 2017, the FASB issued ASU 2017-04, Intangibles—Goodwill and Other (Topic 350): Simplifying the Test for Goodwill Impairment.  The amendments in ASU 2017-04 eliminated the prior requirement to perform procedures to determine the fair value at the impairment testing date of an entity's assets and liabilities (including unrecognized assets and liabilities) following the procedure that would be required in determining the fair value of assets acquired and liabilities assumed in a business combination.  Under the new guidelines an entity should perform its annual, or interim, goodwill impairment test by comparing the fair value of a reporting unit with its carrying amount. An entity should recognize an impairment charge for the amount by which the carrying amount exceeds the reporting unit’s fair value.  The ASU is effective for annual reporting periods beginning after December 15, 2019.  Early adoption is permitted for interim or annual goodwill impairment tests performed on testing dates after January 1, 2017.  Following the Acquisition of ITC, the Company performed an analysis and determined that the transaction included a portion of goodwill.  The Company has accounted for that value on its balance sheet as of December 31, 2017.  See Note 4, "Acquisition and Related Goodwill" for further details.  The Company adopted ASU 2017-04 effective September 30, 2017, and determined there were no triggering events requiring further impairment analysis at this time. The Company expects to perform its annual impairment test during the fourth quarter of fiscal 2017.

[0001628280-18-000993:notes:124]
In February 2017, the FASB issued ASU 2017-05, Other Income - Gains and Losses from the Derecognition of Non-financial Assets (Subtopic 610-20).  The amendments in ASU 2017-05 clarify the scope of Subtopic 610-20, Other Income-Gains and Losses from the Derecognition of Non-financial Assets, and to add guidance for partial sales of non-financial assets. Subtopic 610-20, which was issued in May 2014 as a part of Accounting Standards Update No. 2014-09, Revenue from Contracts with Customers (Topic 606), provides guidance for recognizing gains and losses from the transfer of non-financial assets in contracts with non-customers.  The Company does not expect any significant changes to the consolidated financial statement results with  the adoption of ASU 2017-05.

[0001628280-18-000993:notes:125]
In May 2017, the FASB issued ASU 2017-09, Compensation - Stock Compensation (Subtopic 718) Scope of Modification Accounting.  The amendments in ASU 2017-09 provide clarity and reduce both (1) diversity in practice and (2) cost and complexity when applying the guidance in Topic 718, Compensation—Stock Compensation, to a change to the terms or conditions of a share-based payment award.  The ASU is effective for annual reporting periods beginning after December 15, 2017, including interim periods within those periods. The Company does not expect any significant changes to the consolidated financial statement results with the adoption of ASU 2017-09.

[0001628280-18-000993:notes:126]
In July 2017, the FASB issued ASU 2017-11, Earnings per Share (Topic 260), Distinguishing Liabilities from Equity (Topic   480), and Derivatives and Hedging (Topic 815).  The amendments in ASU 2017-11 provide guidance for freestanding equity-linked financial instruments, such as warrants and conversion options in convertible debt or preferred stock, and should no longer be accounted for as a derivative liability at fair value as a result of the existence of a down round feature.  The ASU is effective for annual reporting periods beginning after December 15, 2018, including interim periods within those periods. The Company is currently evaluating the impact the adoption of ASU 2017-11 may have on its consolidated financial statements.

[0001628280-18-000993:notes:127]
In August 2017, the FASB issued ASU 2017-12, Derivatives and Hedging (Topic 815): Targeted Improvements to Accounting for Hedging Activities.  The amendments in ASU 2017-12 provide improved financial reporting of hedging relationships to better portray the economic results of an entity’s risk management activities in its financial statements. In addition, the amendments in this update make certain targeted improvements to simplify the application of the hedge accounting guidance.  The ASU is effective for annual reporting periods beginning after December 15, 2018, including interim periods within those periods. The Company is currently evaluating the impact the adoption of ASU 2017-12 may have on its consolidated financial statements.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0001628280-18-000993:notes:128]
[same as prior period, unchanged from 0001628280-17-011077:notes:124]

[0001628280-18-000993:notes:129]
[same as prior period, unchanged from 0001628280-17-011077:notes:125]

[0001628280-18-000993:notes:130]
[same as prior period, unchanged from 0001628280-17-011077:notes:126]

[0001628280-18-000993:notes:131]
These unaudited condensed consolidated financial statements of the Company have been prepared on a going concern basis in accordance with United States generally accepted accounting principles (“GAAP”) and the Securities and Exchange Commission’s (“SEC”) instructions to Form 10-Q. The going concern basis of presentation assumes that the Company will continue operations and will be able to realize its assets and discharge its liabilities and commitments in the normal course of business. Certain information and footnote disclosures normally included in the financial statements prepared in accordance with GAAP have been condensed or omitted pursuant to those instructions. The year-end condensed balance sheet data was derived from audited financial statements but does not include all disclosures required by GAAP. The unaudited condensed consolidated financial statements, in the opinion of management, reflect all adjustments (consisting of normal recurring adjustments) necessary for a fair statement of the results for the interim periods ended December 31, 2017 and 2016 and the financial position at December 31, 2017; however, these results are not necessarily indicative of results which may be expected for the full year. The interim condensed consolidated financial statements, and notes thereto, should be read in conjunction with the audited consolidated financial statements for the year ended March 31, 2017, and notes thereto, included in the Company’s annual report on Form 10-K for the year ended March 31, 2017 filed with the Securities and Exchange Commission on May 25, 2017.

[0001628280-18-000993:notes:132]
[same as prior period, unchanged from 0001628280-17-011077:notes:127]

[0001628280-18-000993:notes:133]
The Company has experienced recurring operating losses and as of December 31, 2017, the Company had an accumulated deficit of $982.3 million. In addition, the Company has experienced recurring negative operating cash flows.  At December 31, 2017, the Company had cash and cash equivalents of $22.1 million, with no outstanding debt other than ordinary trade payables. Cash used in operations for the nine months ended December 31, 2017 was $20.2 million.

[0001628280-18-000993:notes:134]
From April 1, 2011 through the date of this filing, the Company has reduced its global workforce substantially, including a restructuring action announced on April 4, 2017 which led to a $1.3 million restructuring charge in the nine months ended December 31, 2017.  See Note 15 "Restructuring" for further discussion of this action.  The Company has taken actions to consolidate certain business operations to reduce facility costs.  As of December 31, 2017, the Company had a global workforce of 275 persons.  The Company plans to closely monitor its expenses and, if required, expects to further reduce operating costs and capital spending to enhance liquidity.

[0001628280-18-000993:notes:135]
[same as prior period, unchanged from 0001628280-17-011077:notes:130]

[0001628280-18-000993:notes:136]
In December 2015, the Company entered into a set of strategic agreements valued at approximately $210.0 million with Inox Wind Ltd. (“Inox” or "Inox Wind"), which includes a multi-year supply contract pursuant to which the Company will supply electric control systems to Inox and a license agreement allowing Inox to manufacture a limited number of electrical control systems.  After Inox purchases the specified number of electrical control systems required under the terms of the supply contract, Inox agreed that the Company will continue as Inox’s preferred supplier and Inox will be required to purchase from the Company a majority of its electric control systems requirements for an additional three-year period.

[0001628280-18-000993:notes:137]
The Company believes that based on the information presented above and its quarterly management assessment, it has sufficient liquidity to fund its operations and capital expenditures for the next twelve months following the issuance of the financial statements for the nine months ended December 31, 2017. The Company’s liquidity is highly dependent on its ability to increase revenues, its ability to control its operating costs, and its ability to raise additional capital, if necessary. There can be no assurance that the Company will be able to continue to raise additional capital from other sources or execute on any other means of improving liquidity described above.


## us-gaap:PropertyPlantAndEquipmentDisclosureTextBlock

[0001628280-18-000993:notes:138]
[same as prior period, unchanged from 0001628280-17-011077:notes:133]

[0001628280-18-000993:notes:139]
The cost and accumulated depreciation of property and equipment at December 31, 2017 and March 31, 2017 are as follows (in thousands):

[0001628280-18-000993:notes:140]
|  | December 31, 2017 |  | March 31, 2017 |
| Land | $ | 3,643 |  |  | $ | 3,643 |  |
| Construction in progress - equipment | 2,160 |  |  | 601 |  |
| Buildings | 34,549 |  |  | 34,549 |  |
| Equipment and software | 72,566 |  |  | 73,445 |  |
| Furniture and fixtures | 1,048 |  |  | 1,201 |  |
| Leasehold improvements | 498 |  |  | 2,442 |  |
| Property, plant and equipment, gross | 114,464 |  |  | 115,881 |  |
| Less accumulated depreciation | (77,780 | ) |  | (72,443 | ) |
| Property, plant and equipment, net | $ | 36,684 |  |  | $ | 43,438 |  |

[0001628280-18-000993:notes:141]
Depreciation expense was $1.4 million and $8.9 million for the three and nine months ended December 31, 2017.  Depreciation expense was $1.7 million and $5.2 million for the three and nine months ended December 31, 2016.  Included in depreciation expense for the nine months ended December 31, 2017 is $4.1 million of accelerated depreciation recorded to cost of revenues related to revised estimates of the remaining useful lives of certain pieces of manufacturing equipment. Construction in progress - equipment primarily includes capital investments in the Company's newly leased facility in Ayer, Massachusetts.


## us-gaap:ReconciliationOfAssetsFromSegmentToConsolidatedTextBlock

[0001628280-18-000993:notes:142]
Total assets for the two business segments as of December 31, 2017 and March 31, 2017 are as follows (in thousands):

[0001628280-18-000993:notes:143]
|  | December 31, 2017 |  | March 31, 2017 |
| Wind | $ | 15,303 |  |  | $ | 18,346 |  |
| Grid | 36,165 |  |  | 31,060 |  |
| Corporate assets | 45,303 |  |  | 50,838 |  |
| Total | $ | 96,771 |  |  | $ | 100,244 |  |


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001628280-18-000993:notes:144]
[same as prior period, unchanged from 0001628280-17-011077:notes:139]

[0001628280-18-000993:notes:145]
[same as prior period, unchanged from 0001628280-17-011077:notes:140]

[0001628280-18-000993:notes:146]
On April 3, 2017, the Board of Directors approved a plan to reduce the Company’s global workforce by approximately 8%, effective April 4, 2017.  The purpose of the workforce reduction was to reduce operating expenses to better align with the Company’s current revenues. Included in the $1.3 million severance pay, charged to operations in the nine months ended December 31, 2017, is $0.5 million of severance pay for one of the Company's former executive officers pursuant to the terms of a severance agreement dated June 30, 2017.  Under the terms of the severance agreement, the Company's former executive officer is entitled to 18 months of his base salary, which is expected to be paid by December 31, 2018. From and after January 1, 2018, the Company, at its discretion, may settle any remaining unpaid cash severance owed to its former executive officer through the issuance of a number of immediately vested shares of the Company’s common stock, determined by multiplying the remaining unpaid cash severance owed by 120%, and then dividing by the closing stock price per share of the Company's common stock as of the last business day prior to the issuance of the shares.

[0001628280-18-000993:notes:147]
[same as prior period, unchanged from 0001628280-17-011077:notes:142]

[0001628280-18-000993:notes:148]
The following table presents restructuring charges and cash payments for the nine months ended December 31, 2017 (in thousands):

[0001628280-18-000993:notes:149]
|  | Severance pay |
|  | and benefits |
| Accrued restructuring balance at April 1, 2017 | $ | — |  |
| Charges to operations | 1,328 |  |
| Cash payments | (934 | ) |
| Accrued restructuring balance at December 31, 2017 | $ | 394 |  |

[0001628280-18-000993:notes:150]
All restructuring charges discussed above are included within restructuring in the Company’s unaudited condensed consolidated statements of operations. The Company includes accrued restructuring within accounts payable and accrued expenses.


## us-gaap:ScheduleOfRevenueByMajorCustomersByReportingSegmentsTableTextBlock

[0001628280-18-000993:notes:151]
The following table sets forth customers who represented 10% or more of the Company’s total revenues for the three and nine months ended December 31, 2017 and 2016:

[0001628280-18-000993:notes:152]
|  | Three months ended December 31, |  | Nine months ended December 31, |
|  | 2017 |  | 2016 |  | 2017 |  | 2016 |
| Inox Wind Limited | 15 | % |  | 66 | % |  | 27 | % |  | 58 | % |
| Vestas Middle East S.L.U. | 27 | % |  | — | % |  | 11 | % |  | — | % |
| SSE Generation Ltd. | 17 | % |  | — | % |  | <10% |  |  | — | % |
| Hidalgo Wind Farm LLC | <10% |  |  | 17 | % |  | <10% |  |  | <10% |  |


## us-gaap:ScheduleOfSegmentReportingInformationBySegmentTextBlock

[0001628280-18-000993:notes:153]
[same as prior period, unchanged from 0001628280-17-011077:notes:148]

[0001628280-18-000993:notes:154]
|  | Three months ended December 31, |  | Nine months ended December 31, |
|  | 2017 |  | 2016 |  | 2017 |  | 2016 |
| Revenues: |  |  |  |  |  |  |  |
| Wind | $ | 2,633 |  |  | $ | 18,248 |  |  | $ | 10,465 |  |  | $ | 36,822 |  |
| Grid | 12,300 |  |  | 8,900 |  |  | 24,439 |  |  | 22,178 |  |
| Total | $ | 14,933 |  |  | $ | 27,148 |  |  | $ | 34,904 |  |  | $ | 59,000 |  |

[0001628280-18-000993:notes:155]
|  | Three months ended December 31, |  | Nine months ended December 31, |
|  | 2017 |  | 2016 |  | 2017 |  | 2016 |
| Operating loss: |  |  |  |  |  |  |  |
| Wind | $ | (1,684 | ) |  | $ | 1,044 |  |  | $ | (7,557 | ) |  | $ | (3,220 | ) |
| Grid | (1,011 | ) |  | (4,491 | ) |  | (15,279 | ) |  | (15,068 | ) |
| Unallocated corporate expenses | (1,156 | ) |  | (613 | ) |  | (3,514 | ) |  | (2,266 | ) |
| Total | $ | (3,851 | ) |  | $ | (4,060 | ) |  | $ | (26,350 | ) |  | $ | (20,554 | ) |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001628280-18-000993:notes:156]
[same as prior period, unchanged from 0001628280-17-011077:notes:151]

[0001628280-18-000993:notes:157]
[same as prior period, unchanged from 0001628280-17-011077:notes:152]

[0001628280-18-000993:notes:158]
Through the Company’s Windtec Solutions, the Wind business segment enables manufacturers to field wind turbines with exceptional power output, reliability and affordability. The Company supplies advanced power electronics and control systems, licenses its highly engineered wind turbine designs, and provides extensive customer support services to wind turbine manufacturers. The Company’s design portfolio includes a broad range of drive trains and power ratings of 2 megawatts ("MWs") and higher. The Company provides a broad range of power electronics and software-based control systems that are highly integrated and designed for optimized performance, efficiency, and grid compatibility.

[0001628280-18-000993:notes:159]
[same as prior period, unchanged from 0001628280-17-011077:notes:154]

[0001628280-18-000993:notes:160]
[same as prior period, unchanged from 0001628280-17-011077:notes:155]

[0001628280-18-000993:notes:161]
Unallocated corporate expenses primarily consist of stock-based compensation expense of $0.9 million and $0.6 million in the three months ended December 31, 2017 and 2016, respectively.  Unallocated corporate expenses primarily consist of stock-based compensation expense of $2.1 million and $2.3 million in the nine months ended December 31, 2017 and 2016, respectively.  Additionally, a restructuring charge of $1.3 million is included in the nine months ended December 31, 2017, as well as losses for the change in fair value of the contingent consideration of $0.3 million and $0.1 million in the three and nine months ended December 31, 2017.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001628280-18-000993:notes:162]
[same as prior period, unchanged from 0001628280-17-011077:notes:157]

[0001628280-18-000993:notes:163]
[same as prior period, unchanged from 0001628280-17-011077:notes:158]

[0001628280-18-000993:notes:164]
On May 5, 2017, the Company entered into an underwriting agreement with Oppenheimer & Co. Inc., as representative of several underwriters named therein, relating to the issuance and sale (the "Offering") of 4.0 million shares of the Company's common stock at a public offering price of $4.00 per share. The net proceeds to the Company from the Offering were approximately $14.7 million, after deducting underwriting discounts and commissions and offering expenses payable by the Company. The Offering closed on May 10, 2017. In addition, the Company granted the underwriters a 30-day option (the “Option”) to purchase up to an additional 600,000 shares of common stock at the public offering price.  On May 24, 2017, the underwriters notified the Company that they had exercised their Option in full.  The net proceeds to the Company from the Option were approximately $2.3 million, after deducting underwriting discounts and commissions and offering expenses payable by the Company.  The total net proceeds to the Company from the Offering and the Option were approximately $17.0 million, after deducting underwriting discounts and commissions and offering expenses payable by the Company. The Option closed on May 26, 2017.

[0001628280-18-000993:notes:165]
[same as prior period, unchanged from 0001628280-17-011077:notes:160]

[0001628280-18-000993:notes:166]
[same as prior period, unchanged from 0001628280-17-011077:notes:161]

[0001628280-18-000993:notes:167]
[same as prior period, unchanged from 0001628280-17-011077:notes:162]

[0001628280-18-000993:notes:168]
[same as prior period, unchanged from 0001628280-17-011077:notes:163]

[0001628280-18-000993:notes:169]
[same as prior period, unchanged from 0001628280-17-011077:notes:164]


## us-gaap:SubsequentEventsTextBlock

[0001628280-18-000993:notes:170]
Subsequent Events

[0001628280-18-000993:notes:171]
On February 1, 2018, ASC Devens, LLC (the “Seller”), a wholly owned subsidiary of American Superconductor Corporation (the “Company”), entered into a Purchase and Sale Agreement (the “PSA”) with 64 Jackson LLC (the “Purchaser”) and Stewart Title Guaranty Company (“Escrow Agent”), pursuant to which the Seller has agreed to sell to the Purchaser certain real property located at 64 Jackson Road, Devens, Massachusetts, as described in the PSA, including the building that has served as the Company’s headquarters (collectively, the “Property”), in exchange for total consideration of $23.0 million, which is composed of (i) cash consideration of $17.0 million, and (ii) a $6.0 million subordinated secured commercial promissory note payable to the Seller (the “Seller Note”) at an interest rate equal to the short-term applicable federal rate then in effect at closing (the “Transaction”). The cash consideration includes a deposit of $500,000 (the “First Deposit”), which the Purchaser has agreed to deposit with the Escrow Agent within three business days after the execution of the PSA, and a second deposit (together with the First Deposit, the “Deposit”) of $500,000, which the Purchaser has agreed to deposit with the Escrow Agent on February 15, 2018, provided that the Seller has not terminated the PSA by that date. The PSA contains customary representations, warranties and covenants of the Seller and the Purchaser.  The Transaction is anticipated to close on March 30, 2018.  Pursuant to the PSA, at closing, the Escrow Agent has agreed to deliver the Deposit to the Seller, and Purchaser has agreed to deliver the remaining cash consideration and the Seller Note to the Seller. The closing of the Transaction is not contingent on any due diligence investigations (other than title), permitting, or financing, however, there is no guarantee that the Transaction will close in the timeframe the Company expects, or at all.

[0001628280-18-000993:notes:172]
According to the Seller Note, the form of which is attached as Exhibit B to the PSA, $3,000,000 in principal, together with all accrued interest, is due and payable to the Seller on March 31, 2019, and $3,000,000 in principal, together with all accrued interest, is due and payable to the Seller on March 31, 2020, provided that, if the Purchaser sells the Property, all unpaid principal and accrued interest must be repaid in full.

[0001628280-18-000993:notes:173]
The Company has performed an evaluation of subsequent events through the time of filing this Quarterly Report on Form 10-Q with the SEC and has determined that other than those disclosed above, there are no such events to report.
