# AMSC MD&A — 0001628280-18-000993


## mdna

[0001628280-18-000993:mdna:1]
[same as prior period, unchanged from 0001628280-17-011077:mdna:1]

[0001628280-18-000993:mdna:2]
[same as prior period, unchanged from 0001628280-17-011077:mdna:2]

[0001628280-18-000993:mdna:3]
[same as prior period, unchanged from 0001628280-17-011077:mdna:3]

[0001628280-18-000993:mdna:4]
We are a leading provider of megawatt-scale solutions that lower the cost of wind power and enhance the performance of the power grid. In the wind power market, we enable manufacturers to field highly competitive wind turbines through our advanced

[0001628280-18-000993:mdna:5]
power electronics products, engineering, and support services. In the power grid market, we enable electric utilities and renewable energy project developers to connect, transmit and distribute power through our transmission planning services and power electronics and superconductor-based products. Our wind and power grid products and services provide exceptional reliability, security, efficiency and affordability to our customers.

[0001628280-18-000993:mdna:6]
[same as prior period, unchanged from 0001628280-17-011077:mdna:6]

[0001628280-18-000993:mdna:7]
[same as prior period, unchanged from 0001628280-17-011077:mdna:7]

[0001628280-18-000993:mdna:8]
[same as prior period, unchanged from 0001628280-17-011077:mdna:8]

[0001628280-18-000993:mdna:9]
[same as prior period, unchanged from 0001628280-17-011077:mdna:9]

[0001628280-18-000993:mdna:10]
[same as prior period, unchanged from 0001628280-17-011077:mdna:10]

[0001628280-18-000993:mdna:11]
[same as prior period, unchanged from 0001628280-17-011077:mdna:11]

[0001628280-18-000993:mdna:12]
[same as prior period, unchanged from 0001628280-17-011077:mdna:12]

[0001628280-18-000993:mdna:13]
Pursuant to a stock purchase agreement (the “SPA”), we acquired all of the issued and outstanding shares of ITC (the “ITC Shares”) for a purchase price of approximately $3.8 million, consisting of $0.1 million in cash and 884,890 shares of our common stock, par value $0.01 per share (the “AMSC Shares”).  Under the terms of the SPA, we were obligated to file a registration statement (the “Resale Registration Statement”) covering the resale of the AMSC Shares by certain selling stockholders (the “Selling Stockholders”) no later than 10 business days following the closing of the Acquisition, and to use commercially reasonable efforts to cause the Resale Registration Statement to be declared effective by the Securities and Exchange Commission (“SEC”) as soon as practicable thereafter. Additionally, we agreed to pay the Selling Stockholders an amount in cash (the “Make Whole Payment”), if any, equal to (x) an amount equal to (i) the price per AMSC Share pursuant to the terms of the SPA, multiplied by (ii) the number of  AMSC Shares sold by Selling Stockholders during the first 90 days after the effectiveness of the Resale Registration Statement, minus (y) the aggregate sales proceeds received by the Selling Stockholders from the sale of any AMSC Shares during the first 90 days after the effectiveness of the Resale Registration Statement.  The Resale Registration Statement was declared effective on October 23, 2017.  The contingent liability related to the Make Whole Payment was determined under a fair value option based pricing model to be $0.6 million on September 25, 2017 and was subsequently reassessed at each period end until the final amount of $0.7 million  as of December 31, 2017 was determined according to the formula per the agreement.  See Note 5 "Fair Value Measurements" and Note 12 "Warrants and Derivative Liabilities" for further discussion regarding the

[0001628280-18-000993:mdna:14]
27

[0001628280-18-000993:mdna:15]
valuation of this liability. On January 5, 2018 we issued the Make Whole Payment to the selling stockholders in the amount of $0.7 million and settled the contingent liability.

[0001628280-18-000993:mdna:16]
We valued the Acquisition at $4.2 million (excluding Acquisition costs), using a value of $4.02 per share, which represents the closing price of our common stock on the closing date of the Acquisition plus $0.1 million in cash and $0.6 million contingent consideration for the Make Whole Payment valued as of the closing date.  As a result of this transaction, ITC became a wholly-owned subsidiary and was integrated into our Grid business unit.

[0001628280-18-000993:mdna:17]
The results of ITC's operations are included in our consolidated results and our Grid segment reporting from the date of acquisition, September 25, 2017.  Assuming the Acquisition had occurred on April 1, 2017 and 2016, the impact on our consolidated results would not have been significant.

[0001628280-18-000993:mdna:18]
On December 22, 2017, the Tax Cuts and Jobs Act of 2017 (“tax reform”) was signed into law. ASC Topic 740 requires deferred tax assets and liabilities to be measured using the enacted rate for the period in which they are expected to reverse. The tax reform was enacted as of December 22, 2017.  Accordingly, the new 21% U.S. Federal corporate tax rate was used to measure the U.S. deferred tax assets and liabilities that will reverse in future periods. Our reduction to our net U.S. deferred tax asset was offset by a corresponding reduction to our valuation allowance. In addition, the new legislation includes a transition tax in which all foreign earnings are deemed to be repatriated to the U.S. and taxable at specified rates included within the tax reform. We are in the process of calculating the impact of the transition tax.  The analysis is complex and encompasses many years.  We are working with our foreign subsidiaries and their local tax service providers to gather historical information, including historical tax returns, in order to complete the calculation. Pursuant to Staff Accounting Bulletin No. 118, our measurement period for the tax impact of the tax law changes is still open. At this time, we do not anticipate a material impact due to the transition tax, and we anticipate completing the accounting under ASC Topic 740 by March 31, 2018, at which time we expect to be in a position to book any required adjustments for any transition tax impact We do not anticipate any other material tax exposure due to the tax reform at this time.

[0001628280-18-000993:mdna:19]
[same as prior period, unchanged from 0001628280-17-011077:mdna:17]

[0001628280-18-000993:mdna:20]
The preparation of the unaudited condensed consolidated financial statements requires that we make estimates and judgments that affect the reported amounts of assets, liabilities, revenues and expenses, and related disclosure of contingent assets and liabilities. We base our estimates on historical experience and various other assumptions that are believed to be reasonable under the circumstances, the results of which form the basis for making judgments about the carrying values of assets and liabilities that are not readily apparent from other sources. Actual results may differ under different assumptions or conditions.  During the nine months ended December 31, 2017, we adopted ASU 2017-04, which provides for changes to the annual impairment testing of goodwill.  See Note 4, "Acquisition and Related Goodwill" for further details.  Aside from the adoption of ASU 2017-04, there were no significant changes in the critical accounting policies that were disclosed in our Form 10-K for fiscal 2016, which ended on March 31, 2017.

[0001628280-18-000993:mdna:21]
[same as prior period, unchanged from 0001628280-17-011077:mdna:19]

[0001628280-18-000993:mdna:22]
Three and nine months ended December 31, 2017 compared to the three and nine months ended December 31, 2016

[0001628280-18-000993:mdna:23]
[same as prior period, unchanged from 0001628280-17-011077:mdna:21]

[0001628280-18-000993:mdna:24]
Total revenues decreased 45% and 41% to $14.9 million and $34.9 million for the three and nine months ended December 31, 2017, respectively, compared to $27.1 million and $59.0 million for the three and nine months ended December 31, 2016, respectively.  Our revenues are summarized as follows (in thousands):

[0001628280-18-000993:mdna:25]
|  | Three months ended December 31, |  | Nine months ended December 31, |
|  | 2017 |  | 2016 |  | 2017 |  | 2016 |
| Revenues: |  |  |  |  |  |  |  |  |  |
| Wind | $ | 2,633 |  |  | $ | 18,248 |  |  | $ | 10,465 |  |  | $ | 36,822 |  |
| Grid | 12,300 |  |  | 8,900 |  |  | 24,439 |  |  | 22,178 |  |
| Total | $ | 14,933 |  |  | $ | 27,148 |  |  | $ | 34,904 |  |  | $ | 59,000 |  |

[0001628280-18-000993:mdna:26]
Our Wind business unit accounted for 18% and 30% of total revenues for the three and nine months ended December 31, 2017, respectively, compared to 67% and 62% for the three and nine months ended December 31, 2016, respectively.  Revenues in the Wind business unit decreased 86% and 72% to $2.6 million and $10.5 million in the three and nine months ended December 31, 2017, respectively, from $18.2 million and $36.8 million in the three and nine months ended December 31, 2016, respectively.

[0001628280-18-000993:mdna:27]
Wind business unit revenues in the three months ended December 31, 2017 decreased due to a lack of ECS shipments to Inox during the period, partially offset by increased license revenues. Wind business unit revenues in the nine months ended December 31, 2017 decreased primarily due to fewer shipments to Inox, partially offset by increased license revenues in the three month period as discussed above.  We believe this reduction in demand has been caused by the transition in India from a local fixed tariff policy regime to a central and state government auction regime, which has had an adverse impact on the Wind industry in India.   We cannot predict if and when this demand dislocation will be resolved.

[0001628280-18-000993:mdna:28]
Our Grid business unit accounted for 82% and 70% of total revenues for the three and nine months ended December 31, 2017, respectively, compared to 33% and 38% for the three and nine months ended December 31, 2016, respectively. Our Grid business unit revenues increased 38% and 10% to $12.3 million and $24.4 million in the three and nine months ended December 31, 2017, respectively, from $8.9 million and $22.2 million in the three and nine months ended December 31, 2016, respectively.  Grid business unit revenues in the three months ended December 31, 2017 increased primarily due to higher D-VAR system revenues.  Grid business unit revenues in the nine months ended December 31, 2017 increased primarily due to higher D-VAR system revenues, as well as higher revenue from the U.S. Navy.

[0001628280-18-000993:mdna:29]
The following table sets forth customers who represented 10% or more of our total revenues for the three and nine months ended December 31, 2017 and 2016:

[0001628280-18-000993:mdna:30]
|  | Three months ended December 31, |  | Nine months ended December 31, |
|  | 2017 |  | 2016 |  | 2017 |  | 2016 |
| Inox Wind Limited | 15 | % |  | 66 | % |  | 27 | % |  | 58 | % |
| Vestas Middle East S.L.U. | 27 | % |  | — | % |  | 11 | % |  | — | % |
| SSE Generation Ltd. | 17 | % |  | — | % |  | <10% |  |  | — | % |
| Hidalgo Wind Farm LLC | <10% |  |  | 17 | % |  | <10% |  |  | <10% |  |

[0001628280-18-000993:mdna:31]
[same as prior period, unchanged from 0001628280-17-011077:mdna:28]

[0001628280-18-000993:mdna:32]
Cost of revenues decreased by 55% to $9.9 million for the three months ended December 31, 2017, compared to $22.1 million for the three months ended December 31, 2016. Gross margin was 34% for the three months ended December 31, 2017, compared to 19% for the three months ended December 31, 2016. The increase in the gross margin for the three months ended December 31, 2017 was due to increased royalty revenue and a more favorable product mix in the current year period.

[0001628280-18-000993:mdna:33]
Cost of revenues decreased by 33% to $34.1 million for the nine months ended December 31, 2017, compared to $51.0 million for the nine months ended December 31, 2016. Gross margin was 2% for the nine months ended December 31, 2017, compared to 14% for the nine months ended December 31, 2016. The decrease in the gross margin for the nine months ended December 31, 2017 was due primarily to the reduction in demand from Inox as discussed above.

[0001628280-18-000993:mdna:34]
[same as prior period, unchanged from 0001628280-17-011077:mdna:30]

[0001628280-18-000993:mdna:35]
[same as prior period, unchanged from 0001628280-17-011077:mdna:31]

[0001628280-18-000993:mdna:36]
R&D expenses decreased in three and nine months ended December 31, 2017 by 1% to $3.0 million and $8.7 million from $3.0 million and $8.8 million for the three and nine months ended December 31, 2016.  The decrease in R&D expenses in the three and nine months ended December 31, 2017 as compared to the prior year periods was primarily due to reduced compensation expense.

[0001628280-18-000993:mdna:37]
[same as prior period, unchanged from 0001628280-17-011077:mdna:33]

[0001628280-18-000993:mdna:38]
SG&A expenses decreased by 10% and 14% to $5.5 million and $17.0 million in the three and nine months ended December 31, 2017, from $6.1 million and $19.6 million in the three and nine months ended December 31, 2016. The decreases in SG&A expenses in the three and nine months ended December 31, 2017 were due primarily to reduced overall compensation expense and the reduced use of outside service providers.

[0001628280-18-000993:mdna:39]
[same as prior period, unchanged from 0001628280-17-011077:mdna:35]

[0001628280-18-000993:mdna:40]
We recorded amortization expense related to our core technology and know-how, trade names and trademark intangible assets of less than $0.1 million in each of the three months ended December 31, 2017 and 2016.  We recorded amortization expense related to our core technology and know-how, trade names and trademark intangible assets of less than $0.1 million and $0.1 million in the nine months ended December 31, 2017 and 2016, respectively.

[0001628280-18-000993:mdna:41]
[same as prior period, unchanged from 0001628280-17-011077:mdna:37]

[0001628280-18-000993:mdna:42]
The change in fair value of our contingent consideration for the Make Whole Payment on the ITC Acquisition resulted in a loss of $0.3 million and $0.1 million in the three and nine months ended December 31, 2017. The change in the fair value was primarily driven by the change in stock price, which is a key valuation metric.

[0001628280-18-000993:mdna:43]
[same as prior period, unchanged from 0001628280-17-011077:mdna:39]

[0001628280-18-000993:mdna:44]
We recorded a restructuring charge of $1.3 million for severance costs in the nine months ended December 31, 2017 as a result of the reduction in force announced on April 4, 2017. Included in the $1.3 million severance pay, charged to operations in the nine months ended December 31, 2017, is $0.5 million of severance pay for one of our former executive officers pursuant to the terms of a severance agreement dated June 30, 2017.  Under the terms of the severance agreement, our former executive officer is entitled to eighteen months of his base salary, which is expected to be paid by December 31, 2018.  From and after January 1, 2018, at our discretion, we may settle any remaining unpaid cash severance owed to our former executive officer through the issuance of a number of immediately vested shares of our common stock, determined by multiplying the remaining unpaid cash severance owed by 120%, and then dividing by the closing stock price per share of our common stock as of the last business day prior to the issuance of the shares.

[0001628280-18-000993:mdna:45]
[same as prior period, unchanged from 0001628280-17-011077:mdna:41]

[0001628280-18-000993:mdna:46]
[same as prior period, unchanged from 0001628280-17-011077:mdna:42]

[0001628280-18-000993:mdna:47]
|  | Three months ended December 31, |  | Nine months ended December 31, |
|  | 2017 |  | 2016 |  | 2017 |  | 2016 |
| Operating loss: |  |  |  |  |  |  |  |
| Wind | $ | (1,684 | ) |  | $ | 1,044 |  |  | $ | (7,557 | ) |  | $ | (3,220 | ) |
| Grid | (1,011 | ) |  | (4,491 | ) |  | (15,279 | ) |  | (15,068 | ) |
| Unallocated corporate expenses | (1,156 | ) |  | (613 | ) |  | (3,514 | ) |  | (2,266 | ) |
| Total | $ | (3,851 | ) |  | $ | (4,060 | ) |  | $ | (26,350 | ) |  | $ | (20,554 | ) |

[0001628280-18-000993:mdna:48]
Our Wind segment generated operating losses of $1.7 million and $7.6 million in the three and nine months ended December 31, 2017, respectively, compared to a profit of $1.0 million and loss of $3.2 million in the three and nine months ended December 31, 2016, respectively. The increase in the Wind business unit operating losses in the three months ended December 31, 2017 was due primarily to a lack of ECS shipments to Inox, offset partially by increased license revenue as previously discussed.   The increase in the Wind business unit operating loss in the nine months ended December 31, 2017 was due primarily to fewer ECS shipments to Inox, partially offset by increased license revenue, as previously discussed.

[0001628280-18-000993:mdna:49]
Our Grid segment generated operating losses of $1.0 million and $15.3 million in the three and nine months ended December 31, 2017, respectively, compared to $4.5 million and $15.1 million in the three and nine months ended December 31, 2016, respectively.  The decrease in the Grid business unit operating loss in the three months ended December 31, 2017 was due primarily to increased D-VAR revenues compared to the prior year period.  The increase in Grid business unit operating loss in the nine months ended December 31, 2017 was due primarily to $4.1 million of accelerated depreciation related to revised estimates of the useful lives of certain pieces of manufacturing equipment.

[0001628280-18-000993:mdna:50]
Unallocated corporate expenses primarily consist of stock-based compensation expense of $0.9 million and $2.1 million for the three and nine months ended December 31, 2017, respectively, and $0.6 million and $2.3 million in the three and nine months ended December 31, 2016, respectively.  Additionally, a restructuring charge of $1.3 million, primarily for severance costs as a result of the restructuring action announced on April 4, 2017, is included in unallocated corporate expenses for the nine months ended December 31, 2017, as well as losses of $0.3 million and $0.1 million for the change in fair value of the contingent consideration in the three and nine months ended December 31, 2017, respectively.

[0001628280-18-000993:mdna:51]
[same as prior period, unchanged from 0001628280-17-011077:mdna:47]

[0001628280-18-000993:mdna:52]
The change in fair value of warrants resulted in gains of $0.4 million and $1.5 million in the three and nine months ended December 31, 2017, respectively, compared to gains of $0.1 million and $0.7 million in the three and nine months ended

[0001628280-18-000993:mdna:53]
30

[0001628280-18-000993:mdna:54]
December 31, 2016, respectively.  The change in the fair value was primarily driven by changes in stock price, which is a key valuation metric.

[0001628280-18-000993:mdna:55]
[same as prior period, unchanged from 0001628280-17-011077:mdna:49]

[0001628280-18-000993:mdna:56]
Interest income (expense), net, was income of     less than $0.1 million in each of the three and nine months ended December 31, 2017, respectively, compared to expense of $0.1 million and $0.3 million in the three and nine months ended December 31, 2016, respectively. The decrease in interest expense was related to lower interest due to the maturity of both of our term loans with Hercules Technology Growth Capital, Inc. (“Hercules”).  Our Term Loan B matured in November 2016, and our Term Loan C matured in June 2017.

[0001628280-18-000993:mdna:57]
Other (expense) income, net

[0001628280-18-000993:mdna:58]
Other (expense) income, net, was expense of $0.3 million and $2.4 million in the three and nine months ended December 31, 2017, respectively, compared to income of $0.9 million and $0.5 million in the three and nine months ended December 31, 2016, respectively.  The increase in other expense, net, during the three and nine months ended December 31, 2017, was primarily driven by higher foreign currency losses.

[0001628280-18-000993:mdna:59]
[same as prior period, unchanged from 0001628280-17-011077:mdna:53]

[0001628280-18-000993:mdna:60]
Income tax expense was $0.6 million and $0.5 million in the three and nine months ended December 31, 2017, respectively, compared to income tax benefit of $0.1 million and expense of $1.0 million in the three and nine months ended December 31, 2016, respectively. The decrease in income tax expense during the nine months ended December 31, 2017 was primarily due to the release of valuation allowances of $1.1 million in the nine months ended December 31, 2017 as a result of the deferred tax liability purchase adjustment recorded as a result of the ITC Acquisition, for the difference in tax basis on the ITC net assets acquired.

[0001628280-18-000993:mdna:61]
[same as prior period, unchanged from 0001628280-17-011077:mdna:55]

[0001628280-18-000993:mdna:62]
[same as prior period, unchanged from 0001628280-17-011077:mdna:56]

[0001628280-18-000993:mdna:63]
[same as prior period, unchanged from 0001628280-17-011077:mdna:57]

[0001628280-18-000993:mdna:64]
|  | Three months ended December 31, |  | Nine months ended December 31, |
|  | 2017 |  | 2016 |  | 2017 |  | 2016 |
| Net loss | $ | (4,248 | ) |  | $ | (2,768 | ) |  | $ | (26,782 | ) |  | $ | (20,448 | ) |
| Sale of minority investments | — |  |  | (325 | ) |  | (951 | ) |  | (325 | ) |
| Stock-based compensation | 883 |  |  | 613 |  |  | 2,115 |  |  | 2,266 |  |
| Amortization of acquisition-related intangibles | 85 |  |  | 39 |  |  | 98 |  |  | 118 |  |
| Consumption of zero cost-basis inventory | (118 | ) |  | (478 | ) |  | (514 | ) |  | (1,118 | ) |
| Change in fair value of warrants and contingent consideration | (126 | ) |  | (101 | ) |  | (1,397 | ) |  | (667 | ) |
| Non-cash interest expense | — |  |  | 30 |  |  | 19 |  |  | 127 |  |
| Tax effect of adjustments | 19 |  |  | 77 |  |  | 142 |  |  | 179 |  |
| Non-GAAP net loss | $ | (3,505 | ) |  | $ | (2,913 | ) |  | $ | (27,270 | ) |  | $ | (19,868 | ) |
| Non-GAAP net loss per share | $ | (0.18 | ) |  | $ | (0.21 | ) |  | $ | (1.46 | ) |  | $ | (1.45 | ) |
| Weighted average shares outstanding - basic and diluted | 19,949 |  |  | 13,792 |  |  | 18,614 |  |  | 13,746 |  |

[0001628280-18-000993:mdna:65]
We incurred non-GAAP net losses of $3.5 million or $0.18 per share, and $27.3 million or $1.46 per share, for the three and nine months ended December 31, 2017, compared to non-GAAP net losses of $2.9 million or $0.21 per share, and $19.9 million or $1.45 per share for the three and nine months ended December 31, 2016. The increases in non-GAAP net loss in both the three and nine month period ended December 31, 2017 were driven primarily by an increase in net loss, as previously discussed, and an adjustment for the sale of our minority investment in Blade Dynamics Limited, partially offset by decreased consumption of zero cost basis inventory and the gain resulting from the decreased value of the warrants and contingent consideration on the ITC acquisition in the three and nine months ended December 31, 2017.

[0001628280-18-000993:mdna:66]
[same as prior period, unchanged from 0001628280-17-011077:mdna:60]

[0001628280-18-000993:mdna:67]
We have experienced recurring operating losses and as of December 31, 2017 had an accumulated deficit of $982.3 million. In addition, we have experienced recurring negative operating cash flows and our Wind segment revenues decreased substantially in the nine months ended December 31, 2017 compared to the prior year period due to decreased demand from Inox. We cannot predict if and when this demand dislocation will be resolved.  From April 1, 2011 through the date of this filing, we have reduced our global workforce substantially, including an 8% reduction in force, primarily affecting employees in our Devens, Massachusetts facility, effective April 4, 2017. We incurred restructuring charges of $1.3 million in cash severance expenses in the nine months ended December 31, 2017 in connection with the workforce reduction.  We are currently moving our manufacturing and administrative operations from our facility in Devens, Massachusetts to a nearby, smaller-scale leased building in Ayer, Massachusetts, which is anticipated to reduce operating costs.

[0001628280-18-000993:mdna:68]
[same as prior period, unchanged from 0001628280-17-011077:mdna:62]

[0001628280-18-000993:mdna:69]
As of December 31, 2017, we had cash, cash equivalents, and restricted cash of $22.3 million, compared to $27.7 million as of March 31, 2017, a decrease of $5.5 million.  Our cash and cash equivalents, and restricted cash are summarized as follows (in thousands):

[0001628280-18-000993:mdna:70]
|  | December 31, 2017 |  | March 31,2017 |
| Cash and cash equivalents | $ | 22,113 |  |  | $ | 26,784 |  |
| Restricted cash | 165 |  |  | 960 |  |
| Total cash, cash equivalents, and restricted cash | $ | 22,278 |  |  | $ | 27,744 |  |

[0001628280-18-000993:mdna:71]
As of December 31, 2017, we had approximately $1.4 million of cash, cash equivalents, and restricted cash in foreign bank accounts, with a majority of this cash located in Europe.

[0001628280-18-000993:mdna:72]
32

[0001628280-18-000993:mdna:73]
For the nine months ended December 31, 2017, net cash used in operating activities was $20.2 million compared to $10.5 million of cash used for the nine months ended December 31, 2016. The increase in net cash used in operations was due primarily to an increased operating loss, and less cash collections from Inox, partially offset by usage of inventory.

[0001628280-18-000993:mdna:74]
For the nine months ended December 31, 2017, net cash used in investing activities was $0.3 million, compared to net cash provided by investing activities of $0.4 million for the nine months ended December 31, 2016. The increase in net cash used in investing activities was due primarily to increased purchases of property, plant and equipment related to the Devens facility move, partially offset by proceeds received from the final payment due from Blade Dynamics as well as releases of restricted cash in the nine months ended December 31, 2017.

[0001628280-18-000993:mdna:75]
For the nine months ended December 31, 2017, net cash provided by financing activities was $15.2 million compared to net cash used in financing activities of $3.7 million in the nine months ended December 31, 2016. The increase in net cash provided by financing activities was primarily due to net proceeds of $17.0 million from the issuance of 4.6 million shares of common stock in May 2017, with no such equity offering in the prior year period.  See the discussion regarding the May 2017 equity offering below.

[0001628280-18-000993:mdna:76]
As of December 31, 2017, we had $0.2 million of restricted cash included in long-term assets. These amounts included in restricted cash primarily represent deposits to secure letters of credit for various supply contracts. These deposits are held in interest bearing accounts.

[0001628280-18-000993:mdna:77]
[same as prior period, unchanged from 0001628280-17-011077:mdna:71]

[0001628280-18-000993:mdna:78]
[same as prior period, unchanged from 0001628280-17-011077:mdna:72]

[0001628280-18-000993:mdna:79]
[same as prior period, unchanged from 0001628280-17-011077:mdna:73]

[0001628280-18-000993:mdna:80]
Legal Proceedings

[0001628280-18-000993:mdna:81]
We are involved in legal and administrative proceedings and claims of various types. See Part II, Item 1, “Legal Proceedings,” for additional information. We record a liability in our consolidated financial statements for these matters when a loss is known or considered probable and the amount can be reasonably estimated. We review these estimates each accounting period as additional information is known and adjust the loss provision when appropriate. If a matter is both probable to result in liability and the amounts of loss can be reasonably estimated, we estimate and disclose the possible loss or range of loss to the extent necessary to make the consolidated financial statements not misleading. If the loss is not probable or cannot be reasonably estimated, a liability is not recorded in our consolidated financial statements.

[0001628280-18-000993:mdna:82]
[same as prior period, unchanged from 0001628280-17-011077:mdna:77]

[0001628280-18-000993:mdna:83]
[same as prior period, unchanged from 0001628280-17-011077:mdna:78]

[0001628280-18-000993:mdna:84]
[same as prior period, unchanged from 0001628280-17-011077:mdna:79]

[0001628280-18-000993:mdna:85]
[same as prior period, unchanged from 0001628280-17-011077:mdna:80]

[0001628280-18-000993:mdna:86]
[same as prior period, unchanged from 0001628280-17-011077:mdna:81]

[0001628280-18-000993:mdna:87]
In May 2014, the Financial Accounting Standards Board (“FASB”) and the International Accounting Standards Board (IASB) issued ASU 2014-09, Revenue from Contracts with Customers (Topic 606). The guidance substantially converges final standards on revenue recognition between the FASB and IASB providing a framework on addressing revenue recognition issues and, upon its effective date, replaces almost all existing revenue recognition guidance, including industry-specific guidance, in current U.S. generally accepted accounting principles. The FASB has subsequently issued the following amendments to ASU 2014-09 which are all effective for annual reporting periods beginning after December 15, 2017.

[0001628280-18-000993:mdna:88]
•In March 2016, the FASB issued ASU No. 2016-08, Revenue from Contracts with Customers (Topic 606): Principal versus Agent Considerations, which clarifies the implementation guidance on principal versus agent considerations.

[0001628280-18-000993:mdna:89]
•In April 2016, the FASB issued ASU No. 2016-10, Revenue from Contracts with Customers (Topic 606): Identifying Performance Obligations and Licensing, which clarifies certain aspects of identifying performance obligations and licensing implementation guidance.

[0001628280-18-000993:mdna:90]
•In May 2016, the FASB issued ASU No. 2016-12, Revenue from Contracts with Customers (Topic 606): Narrow- Scope Improvements and Practical Expedients related to disclosures of remaining performance obligations, as well as other amendments to guidance on collectability, non-cash consideration and the presentation of sales and other similar taxes collected from customers.

[0001628280-18-000993:mdna:91]
•In December 2016, the FASB issued ASU No. 2016-20, Technical Corrections and Improvements to Topic 606, Revenue from Contracts with Customers, which amends certain narrow aspects of the guidance issued in ASU 2014-09 including guidance related to the disclosure of remaining performance obligations and prior-period performance obligations, as well as other amendments to the guidance on loan guarantee fees, contract costs, refund liabilities, advertising costs and the clarification of certain examples.

[0001628280-18-000993:mdna:92]
As of December 31, 2017, we have made significant progress towards completing our assessment of the potential effects of ASU 2049-09 and its amendments on our consolidated financial statements, and are actively assessing the potential effects on business processes, systems and controls to support revenue recognition and the related disclosures under this ASU. Our assessment includes a detailed review of representative contracts from each of our revenue streams and a comparison of its historical accounting policies and practices to the new standard. We are required to adopt the new standards on April 1, 2018, and expect to do so retrospectively with the cumulative effect of initially applying the guidance recognized at the date of initial application (the modified retrospective transition method).  Additionally, this guidance could lead to recognizing certain revenue transactions sooner than in the past on certain contracts, as we will need to estimate the revenue we will be entitled to upon contract completion, and later on other contracts, due to lack of an enforceable right to payment for performance obligations satisfied over time.  Our preliminary assessment of this adoption method supports the determination that there are no expected changes in the accounting for our largest revenue stream which includes Inox Wind Limited as the primary customer.  Across other revenue streams the timing of revenue recognition could be affected for multiple types of contracts, primarily multiple element contracts in our grid business unit, but those differences are not expected to have a material impact on our consolidated financial statements.  However, our assessment is not yet finalized and is subject to change.  Additionally, we are currently evaluating any tax implications the adoption of this new standard may have on the consolidated financial statements. As part of this analysis, we are evaluating our information technology capabilities and systems, and do not expect to incur significant information technology costs to modify systems currently in place.

[0001628280-18-000993:mdna:93]
During the fourth quarter of fiscal 2017 we plan to assess our current revenue controls, and identify and implement any changes that may be necessary to comply with our new revenue policies and the provisions of ASU 2014-09, which will be effective for us as of April 1, 2018.

[0001628280-18-000993:mdna:94]
In January 2016, the FASB issued ASU 2016-01, Financial Instruments-Overall (Subtopic 825-10): Recognition and Measurement of Financial Assets and Financial Liabilities.  The amendments in ASU 2016-01 enhance the reporting model for financial instruments to provide users of financial statements with more decision-useful information. This ASU is effective for

[0001628280-18-000993:mdna:95]
annual reporting periods beginning after December 15, 2017, and interim periods within those fiscal years.  We do not expect any significant changes to the consolidated financial statement results with the adoption of ASU 2016-01.

[0001628280-18-000993:mdna:96]
In February 2016, the FASB issued ASU 2016-02, Leases (Topic 842). The guidance in this ASU supersedes the leasing guidance in Topic 840, Leases. Under the new guidance, lessees are required to recognize lease assets and lease liabilities on the balance sheet for all leases with terms longer than 12 months. Leases will be classified as either finance or operating, with classification affecting the pattern of expense recognition in the income statement. This ASU is effective for fiscal years beginning after December 15, 2019, including interim periods within those fiscal years. A modified retrospective transition approach is required for lessees for capital and operating leases existing at, or entered into after, the beginning of the earliest comparative period presented in the financial statements, with certain practical expedients available. We are currently evaluating the effects adoption of this guidance will have on our consolidated financial statements.

[0001628280-18-000993:mdna:97]
In June 2016, the FASB issued ASU 2016-13, Financial Instruments-Credit Losses (Topic 326): Measurement of Credit Losses on Financial Instruments.  The amendments in ASU 2016-13 provide more decision-useful information about the expected credit losses on financial instruments and other commitments to extend credit held by a reporting entity at each reporting date. The ASU is effective for annual reporting periods beginning after December 15, 2019, including interim periods within that year.  We are currently evaluating the impact, if any, the adoption of ASU 2016-13 may have on our consolidated financial statements.

[0001628280-18-000993:mdna:98]
[same as prior period, unchanged from 0001628280-17-011077:mdna:92]

[0001628280-18-000993:mdna:99]
•In August 2016, the FASB issued ASU 2016-15, Statement of Cash Flows (Topic 230): Classification of Certain Cash Receipts and Cash Payments.  The amendments in ASU 2016-15 provide more guidance towards the classification of multiple different types of cash flows in order to reduce the diversity in reporting across entities.

[0001628280-18-000993:mdna:100]
•In November 2016, the FASB issued ASU 2016-18, Statement of Cash Flows (Topic 230): Restricted Cash.  The amendments in ASU 2016-18 explain the change during the period in the total of cash, cash equivalents, and amounts generally described as restricted cash or restricted cash equivalents. Therefore, amounts generally described as restricted cash and restricted cash equivalents should be included with cash and cash equivalents when reconciling the beginning-of-period and end-of-period total amounts shown on the statement of cash flows.

[0001628280-18-000993:mdna:101]
We do not expect any significant changes to the consolidated financial statement results with the adoption of ASU 2016-15 and ASU 2016-18.

[0001628280-18-000993:mdna:102]
In October 2016, the FASB issued ASU 2016-16, Income Taxes (Topic 740): Intra-Entity Transfers of Assets Other Than Inventory.  The amendments in ASU 2016-16 improve the accounting for the income tax consequences of intra-entity transfers of assets other than inventory. The ASU is effective for annual reporting periods beginning after December 15, 2017, including interim periods within that year.  We do not anticipate any significant changes to our consolidated financial statements with the adoption of ASU 2016-16.

[0001628280-18-000993:mdna:103]
In January 2017, the FASB issued ASU 2017-01, Business Combinations.  The amendments in ASU 2017-01 clarify the definition of a business with the objective of adding guidance to assist entities with evaluating whether transactions should be accounted for as acquisitions (or disposals) of assets or businesses. The ASU is effective for annual reporting periods beginning after December 15, 2017, including interim periods within those periods.  We adopted ASU 2017-01 effective September 30, 2017, following the acquisition of ITC.  We considered these amendments in our decision to record the combination of the entities as an Acquisition.  See Note 4, "Acquisitions and Related Goodwill", for further details.  These impacts have been included in the consolidated financial statements.

[0001628280-18-000993:mdna:104]
In January 2017, the FASB issued ASU 2017-03, Accounting Changes and Error Corrections (Topic 250) and Investments - Equity Method and Joint Ventures.  The amendments in ASU 2017-03 provide additional detail surrounding disclosures required related to adoption of new pronouncements. The ASU is effective for the periods of each related pronouncement.  We are currently evaluating the impact the adoption of ASU 2017-03 may have on our consolidated financial statements.

[0001628280-18-000993:mdna:105]
In January 2017, the FASB issued ASU 2017-04, Intangibles—Goodwill and Other (Topic 350): Simplifying the Test for Goodwill Impairment.  The amendments in ASU 2017-04 eliminated the prior requirement to perform procedures to determine the fair value at the impairment testing date of an entity's assets and liabilities (including unrecognized assets and liabilities) following the procedure that would be required in determining the fair value of assets acquired and liabilities assumed in a business combination.  Under the new guidelines an entity should perform its annual, or interim, goodwill impairment test by comparing the fair value of a reporting unit with its carrying amount. An entity should recognize an impairment charge for the amount by

[0001628280-18-000993:mdna:106]
which the carrying amount exceeds the reporting unit’s fair value.  The ASU is effective for annual reporting periods beginning after December 15, 2019.  Early adoption is permitted for interim or annual goodwill impairment tests performed on testing dates after January 1, 2017.  Following the Acquisition of ITC, we performed an analysis and determined that the transaction included a portion of goodwill.  We have accounted for that value on our balance sheet as of December 31, 2017.  See Note 4, "Acquisitions and Related Goodwill" for further details.  Given the results of our analysis, we adopted ASU 2017-04 effective September 30, 2017, and determined there were no triggering events requiring further impairment analysis at this time. The Company expects to perform its annual impairment test during the fourth quarter of fiscal 2017.

[0001628280-18-000993:mdna:107]
In February 2017, the FASB issued ASU 2017-05, Other Income - Gains and Losses from the Derecognition of Non-financial Assets (Subtopic 610-20).  The amendments in ASU 2017-05 clarify the scope of Subtopic 610-20, Other Income-Gains and Losses from the Derecognition of Non-financial Assets, and to add guidance for partial sales of non-financial assets. Subtopic 610-20, which was issued in May 2014 as a part of Accounting Standards Update No. 2014-09, Revenue from Contracts with Customers (Topic 606), provides guidance for recognizing gains and losses from the transfer of non-financial assets in contracts with non-customers.  We do not expect any significant changes to the consolidated financial statement results with the adoption of ASU 2017-05.

[0001628280-18-000993:mdna:108]
In May 2017, the FASB issued ASU 2017-09, Compensation - Stock Compensation (Subtopic 718) Scope of Modification Accounting.  The amendments in ASU 2017-09 provide clarity and reduce both (1) diversity in practice and (2) cost and complexity when applying the guidance in Topic 718, Compensation—Stock Compensation, to a change to the terms or conditions of a share-based payment award.  The ASU is effective for annual reporting periods beginning after December 15, 2017, including interim periods within those periods. We do not expect any significant changes to the consolidated financial statement results with the adoption of ASU 2017-09.

[0001628280-18-000993:mdna:109]
In July 2017, the FASB issued ASU 2017-11, Earnings per Share (Topic 260), Distinguishing Liabilities from Equity (Topic   480), and Derivatives and Hedging (Topic 815).  The amendments in ASU 2017-11 provide guidance for freestanding equity-linked financial instruments, such as warrants and conversion options in convertible debt or preferred stock, and should no longer be accounted for as a derivative liability at fair value as a result of the existence of a down round feature.  The ASU is effective for annual reporting periods beginning after December 15, 2018, including interim periods within those periods. We are currently evaluating the impact the adoption of ASU 2017-11 may have on our consolidated financial statements.

[0001628280-18-000993:mdna:110]
In August 2017, the FASB issued ASU 2017-12, Derivatives and Hedging (Topic 815): Targeted Improvements to Accounting for Hedging Activities.  The amendments in ASU 2017-12 provide improved financial reporting of hedging relationships to better portray the economic results of an entity’s risk management activities in its financial statements. In addition, the amendments in this update make certain targeted improvements to simplify the application of the hedge accounting guidance.  The ASU is effective for annual reporting periods beginning after December 15, 2018, including interim periods within those periods. We are currently evaluating the impact the adoption of ASU 2017-12 may have on our consolidated financial statements.

[0001628280-18-000993:mdna:111]
We do not believe that outside of those disclosed here, there are any other recently issued accounting pronouncements will have a material impact on our consolidated financial statements.
