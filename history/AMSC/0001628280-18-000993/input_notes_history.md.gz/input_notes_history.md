# AMSC note change history — 0001628280-17-011077 → 0001628280-18-000993


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2018-02-05):
[0001628280-18-000993:note_history:1]
As of December 31, 2017, the Company had $0.2 million of restricted cash included in long-term assets. These amounts included in restricted cash primarily represent deposits to secure letters of credit for various supply contracts. These deposits are held in interest bearing accounts.
  (was, 2017-11-07, similarity 0.9874):
[0001628280-17-011077:note_history:1]
As of September 30, 2017, the Company had $0.2 million of restricted cash included in long-term assets. These amounts included in restricted cash primarily represent deposits to secure letters of credit for various supply contracts. These deposits are held in interest bearing accounts.

- added (2018-02-05):
[0001628280-18-000993:note_history:2]
During the nine months ended December 31, 2017, the Company received $1.0 million related to the achievement of certain milestones following the previous sale of the Company's minority interest in Blade Dynamics Limited.

- added (2018-02-05):
[0001628280-18-000993:note_history:3]
On September 25, 2017, the Company acquired ITC for a purchase price of approximately $3.8 million, consisting of $0.1 million in cash and the AMSC Shares. The Company paid certain selling stockholders the Make Whole Payment given that the value of the AMSC Shares sold was less than the agreed upon purchase price.  The amount of this payment, which was made on January 5, 2018, was $0.7 million and settled the related contingent liability. See Note 4, “Acquisitions and Related Goodwill” for further discussion.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2018-02-05):
[0001628280-18-000993:note_history:4]
These unaudited condensed consolidated financial statements of the Company have been prepared on a going concern basis in accordance with United States generally accepted accounting principles (“GAAP”) and the Securities and Exchange Commission’s (“SEC”) instructions to Form 10-Q. The going concern basis of presentation assumes that the Company will continue operations and will be able to realize its assets and discharge its liabilities and commitments in the normal course of business. Certain information and footnote disclosures normally included in the financial statements prepared in accordance with GAAP have been condensed or omitted pursuant to those instructions. The year-end condensed balance sheet data was derived from audited financial statements but does not include all disclosures required by GAAP. The unaudited condensed consolidated financial statements, in the opinion of management, reflect all adjustments (consisting of normal recurring adjustments) necessary for a fair statement of the results for the interim periods ended December 31, 2017 and 2016 and the financial position at December 31, 2017; however, these results are not necessarily indicative of results which may be expected for the full year. The interim condensed consolidated financial statements, and notes thereto, should be read in conjunction with the audited consolidated financial statements for the year ended March 31, 2017, and notes thereto, included in the Company’s annual report on Form 10-K for the year ended March 31, 2017 filed with the Securities and Exchange Commission on May 25, 2017.
  (was, 2017-11-07, similarity 0.8258):
[0001628280-17-011077:note_history:4]
These unaudited condensed consolidated financial statements of the Company have been prepared on a going concern basis in accordance with United States generally accepted accounting principles (“GAAP”) and the Securities and Exchange Commission’s (“SEC”) instructions to Form 10-Q. The going concern basis of presentation assumes that the Company will continue operations and will be able to realize its assets and discharge its liabilities and commitments in the normal course of business. Certain information and footnote disclosures normally included in the financial statements prepared in accordance with GAAP have been condensed or omitted pursuant to those instructions. The year-end condensed balance sheet data was derived from audited financial statements but does not include all disclosures required by GAAP. The unaudited condensed consolidated financial statements, in the opinion of management, reflect all adjustments (consisting of normal recurring adjustments) necessary for a fair statement of the results for the interim periods ended September 30, 2017 and 2016 and the financial position at September 30, 2017.

- changed (2018-02-05):
[0001628280-18-000993:note_history:5]
The Company has experienced recurring operating losses and as of December 31, 2017, the Company had an accumulated deficit of $982.3 million. In addition, the Company has experienced recurring negative operating cash flows.  At December 31, 2017, the Company had cash and cash equivalents of $22.1 million, with no outstanding debt other than ordinary trade payables. Cash used in operations for the nine months ended December 31, 2017 was $20.2 million.
  (was, 2017-11-07, similarity 0.7497):
[0001628280-17-011077:note_history:5]
The Company has experienced recurring operating losses and as of September 30, 2017, the Company had an accumulated deficit of $978.1 million. In addition, the Company has experienced recurring negative operating cash flows.  At September 30, 2017, the Company had cash and cash equivalents of $30.3 million, with no outstanding debt. Cash used in operations for the six months ended September 30, 2017 was $13.5 million.

- changed (2018-02-05):
[0001628280-18-000993:note_history:6]
From April 1, 2011 through the date of this filing, the Company has reduced its global workforce substantially, including a restructuring action announced on April 4, 2017 which led to a $1.3 million restructuring charge in the nine months ended December 31, 2017.  See Note 15 "Restructuring" for further discussion of this action.  The Company has taken actions to consolidate certain business operations to reduce facility costs.  As of December 31, 2017, the Company had a global workforce of 275 persons.  The Company plans to closely monitor its expenses and, if required, expects to further reduce operating costs and capital spending to enhance liquidity.
  (was, 2017-11-07, similarity 0.9614):
[0001628280-17-011077:note_history:6]
From April 1, 2011 through the date of this filing, the Company has reduced its global workforce substantially, including a restructuring action announced on April 4, 2017 which led to a $1.3 million restructuring charge in the six months ended September 30, 2017.  See Note 15 "Restructuring" for further discussion of this action.  The Company has taken actions to consolidate certain business operations to reduce facility costs.  As of September 30, 2017, the Company had a global workforce of 321 persons.  The Company plans to closely monitor its expenses and, if required, expects to further reduce operating costs and capital spending to enhance liquidity.

- changed (2018-02-05):
[0001628280-18-000993:note_history:7]
In December 2015, the Company entered into a set of strategic agreements valued at approximately $210.0 million with Inox Wind Ltd. (“Inox” or "Inox Wind"), which includes a multi-year supply contract pursuant to which the Company will supply electric control systems to Inox and a license agreement allowing Inox to manufacture a limited number of electrical control systems.  After Inox purchases the specified number of electrical control systems required under the terms of the supply contract, Inox agreed that the Company will continue as Inox’s preferred supplier and Inox will be required to purchase from the Company a majority of its electric control systems requirements for an additional three-year period.
  (was, 2017-11-07, similarity 0.9893):
[0001628280-17-011077:note_history:7]
In December 2015, the Company entered into a set of strategic agreements valued at approximately $210.0 million with Inox Wind Ltd. (“Inox”), which includes a multi-year supply contract pursuant to which the Company will supply electric control systems to Inox and a license agreement allowing Inox to manufacture a limited number of electrical control systems.  After Inox purchases the specified number of electrical control systems required under the terms of the supply contract, Inox agreed that the Company will continue as Inox’s preferred supplier and Inox will be required to purchase from the Company a majority of its electric control systems requirements for an additional three-year period.

- changed (2018-02-05):
[0001628280-18-000993:note_history:8]
The Company believes that based on the information presented above and its quarterly management assessment, it has sufficient liquidity to fund its operations and capital expenditures for the next twelve months following the issuance of the financial statements for the nine months ended December 31, 2017. The Company’s liquidity is highly dependent on its ability to increase revenues, its ability to control its operating costs, and its ability to raise additional capital, if necessary. There can be no assurance that the Company will be able to continue to raise additional capital from other sources or execute on any other means of improving liquidity described above.
  (was, 2017-11-07, similarity 0.9686):
[0001628280-17-011077:note_history:8]
The Company believes that based on the information presented above and its quarterly management assessment, it has sufficient liquidity to fund its operations and capital expenditures for the next twelve months following the issuance of the financial statements for the six months ended September 30, 2017. The Company’s liquidity is highly dependent on its ability to increase revenues, its ability to control its operating costs, and its ability to raise additional capital, if necessary. There can be no assurance that the Company will be able to continue to raise additional capital from other sources or execute on any other means of improving liquidity described above.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2018-02-05):
[0001628280-18-000993:note_history:9]
The Company recorded no interest expense for the three months ended December 31, 2017 and less than $0.1 million for the three months ended December 31, 2016.  Included in the prior year period was less than $0.1 million of non-cash interest expense related to the amortization of the debt discount on the respective term loans.  Interest expense on the Term Loans for the nine months ended December 31, 2017 and 2016, was less than $0.1 million and $0.3 million, respectively.  Included in the nine months ended December 31, 2017 and 2016 were less than $0.1 million and $0.1 million, respectively, of non-cash interest expense related to the amortization of debt discount on the respective Term Loans.

- removed (2018-02-05):
[0001628280-17-011077:note_history:10]
Interest expense on the Term Loans for the three months ended September 30, 2017 and 2016, was less than $0.1 million.  Included in both periods was less than $0.1 million of non-cash interest expense related to the amortization of the debt discount on the respective Term Loans.  Interest expense on the Term Loans for the six months ended September 30, 2017 and 2016, was less than $0.1 million and $0.3 million, respectively.  Included in both periods was less than $0.1 million of non-cash interest expense related to the amortization of debt discount on the respective Term Loans.


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: tag_name, score: 1.0

- added (2018-02-05):
[0001628280-18-000993:note_history:11]
On February 1, 2018, ASC Devens, LLC (the “Seller”), a wholly owned subsidiary of American Superconductor Corporation (the “Company”), entered into a Purchase and Sale Agreement (the “PSA”) with 64 Jackson LLC (the “Purchaser”) and Stewart Title Guaranty Company (“Escrow Agent”), pursuant to which the Seller has agreed to sell to the Purchaser certain real property located at 64 Jackson Road, Devens, Massachusetts, as described in the PSA, including the building that has served as the Company’s headquarters (collectively, the “Property”), in exchange for total consideration of $23.0 million, which is composed of (i) cash consideration of $17.0 million, and (ii) a $6.0 million subordinated secured commercial promissory note payable to the Seller (the “Seller Note”) at an interest rate equal to the short-term applicable federal rate then in effect at closing (the “Transaction”). The cash consideration includes a deposit of $500,000 (the “First Deposit”), which the Purchaser has agreed to deposit with the Escrow Agent within three business days after the execution of the PSA, and a second deposit (together with the First Deposit, the “Deposit”) of $500,000, which the Purchaser has agreed to deposit with the Escrow Agent on February 15, 2018, provided that the Seller has not terminated the PSA by that date. The PSA contains customary representations, warranties and covenants of the Seller and the Purchaser.  The Transaction is anticipated to close on March 30, 2018.  Pursuant to the PSA, at closing, the Escrow Agent has agreed to deliver the Deposit to the Seller, and Purchaser has agreed to deliver the remaining cash consideration and the Seller Note to the Seller. The closing of the Transaction is not contingent on any due diligence investigations (other than title), permitting, or financing, however, there is no guarantee that the Transaction will close in the timeframe the Company expects, or at all.

- added (2018-02-05):
[0001628280-18-000993:note_history:12]
According to the Seller Note, the form of which is attached as Exhibit B to the PSA, $3,000,000 in principal, together with all accrued interest, is due and payable to the Seller on March 31, 2019, and $3,000,000 in principal, together with all accrued interest, is due and payable to the Seller on March 31, 2020, provided that, if the Purchaser sells the Property, all unpaid principal and accrued interest must be repaid in full.

- changed (2018-02-05):
[0001628280-18-000993:note_history:13]
The Company has performed an evaluation of subsequent events through the time of filing this Quarterly Report on Form 10-Q with the SEC and has determined that other than those disclosed above, there are no such events to report.
  (was, 2017-11-07, similarity 0.9194):
[0001628280-17-011077:note_history:13]
The Company has performed an evaluation of subsequent events through the time of filing this Quarterly Report on Form 10-Q with the SEC and has determined that there are no such events to report.
