# AMSC MD&A — 0001628280-17-011077


## mdna

[0001628280-17-011077:mdna:1]
[same as prior period, unchanged from 0001628280-17-008331:mdna:1]

[0001628280-17-011077:mdna:2]
American Superconductor®, Amperium®, AMSC®, D-VAR®, PowerModule™, D-VAR® VVO, PQ-IVR®, SeaTitan™, Gridtec Solutions™, Windtec Solutions™ and Smarter, Cleaner...Better Energy™ are trademarks or registered trademarks of American Superconductor Corporation or our subsidiaries. We reserve all of our rights with respect to our trademarks or registered trademarks regardless of whether they are so designated in this Quarterly Report on Form 10-Q by an ® or ™ symbol. All other brand names, product names, trademarks or service marks appearing in this Quarterly Report on Form 10-Q are the property of their respective holders.

[0001628280-17-011077:mdna:3]
[same as prior period, unchanged from 0001628280-17-008331:mdna:3]

[0001628280-17-011077:mdna:4]
[same as prior period, unchanged from 0001628280-17-008331:mdna:4]

[0001628280-17-011077:mdna:5]
[same as prior period, unchanged from 0001628280-17-008331:mdna:5]

[0001628280-17-011077:mdna:6]
[same as prior period, unchanged from 0001628280-17-008331:mdna:6]

[0001628280-17-011077:mdna:7]
[same as prior period, unchanged from 0001628280-17-008331:mdna:7]

[0001628280-17-011077:mdna:8]
[same as prior period, unchanged from 0001628280-17-008331:mdna:8]

[0001628280-17-011077:mdna:9]
[same as prior period, unchanged from 0001628280-17-008331:mdna:9]

[0001628280-17-011077:mdna:10]
[same as prior period, unchanged from 0001628280-17-008331:mdna:10]

[0001628280-17-011077:mdna:11]
[same as prior period, unchanged from 0001628280-17-008331:mdna:11]

[0001628280-17-011077:mdna:12]
On September 25, 2017, we acquired Infinia Technology Corporation (“ITC”) for approximately $3.8 million as described below (the “Acquisition”).  Located in Richmond, Washington, ITC is a technology firm founded in 2009 specializing in the design, development and commercialization of cryo-coolers for a wide range of applications.

[0001628280-17-011077:mdna:13]
Pursuant to a stock purchase agreement (the “SPA”), we acquired all of the issued and outstanding shares of ITC (the “ITC Shares”) for a purchase price of approximately $3.8 million, consisting of $0.1 million in cash and 884,890 shares of our common stock, par value $0.01 per share (the “AMSC Shares”).  Under the terms of the SPA, we were obligated to file a registration statement (the “Resale Registration Statement”) covering the resale of the AMSC Shares by certain selling stockholders (the “Selling Stockholders”) no later than 10 business days following the closing of the Acquisition, and to use commercially reasonable efforts to cause the Resale Registration Statement to be declared effective by the Securities and Exchange Commission (“SEC”) as soon as practicable thereafter. Additionally, we agreed to pay the Selling Stockholders an amount in cash (the “Make Whole Payment”), if any, equal to (x) an amount equal to (i) the price per AMSC Share pursuant to the terms of the SPA, multiplied by (ii) the number of  AMSC Shares sold by Selling Stockholders during the first 90 days after the effectiveness of the Resale Registration Statement, minus (y) the aggregate sales proceeds received by the Selling Stockholders from the sale of any AMSC Shares during the first 90 days after the effectiveness of the Resale Registration Statement.  The Resale Registration Statement was declared effective on October 23, 2017.  We have granted a security interest in the ITC Shares to the Selling Stockholders to secure our obligation to make any Make Whole Payment.

[0001628280-17-011077:mdna:14]
We valued the Acquisition at $4.2 million (excluding Acquisition costs), using a value of $4.02 per share, which represents the closing price of our common stock on the closing date of the Acquisition plus $0.1 million in cash and $0.6 million contingent

[0001628280-17-011077:mdna:15]
consideration for the Make Whole Payment valued as of the closing date.  As a result of this transaction, ITC became a wholly-owned subsidiary and was integrated into our Grid business unit.

[0001628280-17-011077:mdna:16]
The results of ITC's operations are included in our consolidated results and our Grid segment reporting from the date of acquisition, September 25, 2017. Assuming the Acquisition had occurred on April 1, 2017 and 2016, the impact on our consolidated results would not have been significant.

[0001628280-17-011077:mdna:17]
[same as prior period, unchanged from 0001628280-17-008331:mdna:12]

[0001628280-17-011077:mdna:18]
The preparation of the unaudited condensed consolidated financial statements requires that we make estimates and judgments that affect the reported amounts of assets, liabilities, revenues and expenses, and related disclosure of contingent assets and liabilities. We base our estimates on historical experience and various other assumptions that are believed to be reasonable under the circumstances, the results of which form the basis for making judgments about the carrying values of assets and liabilities that are not readily apparent from other sources. Actual results may differ under different assumptions or conditions.  During the six months ended September 30, 2017, we adopted ASU 2017-04, which provides for changes to the annual impairment testing of goodwill.  See Note 4, "Acquisition and Related Goodwill" for further details.  Aside from the adoption of ASU 2017-04, there were no significant changes in the critical accounting policies that were disclosed in our Form 10-K for fiscal 2016, which ended on March 31, 2017.

[0001628280-17-011077:mdna:19]
[same as prior period, unchanged from 0001628280-17-008331:mdna:14]

[0001628280-17-011077:mdna:20]
Three and six months ended September 30, 2017 compared to the three and six months ended September 30, 2016

[0001628280-17-011077:mdna:21]
[same as prior period, unchanged from 0001628280-17-008331:mdna:16]

[0001628280-17-011077:mdna:22]
Total revenues decreased 40% and 37% to $11.0 million and $20.0 million for the three and six months ended September 30, 2017, respectively, compared to $18.5 million and $31.9 million for the three and six months ended September 30, 2016, respectively.  Our revenues are summarized as follows (in thousands):

[0001628280-17-011077:mdna:23]
|  | Three months ended September 30, |  | Six months ended September 30, |
|  | 2017 |  | 2016 |  | 2017 |  | 2016 |
| Revenues: |  |  |  |  |  |  |  |  |  |
| Wind | $ | 5,554 |  |  | $ | 12,898 |  |  | $ | 7,831 |  |  | $ | 18,573 |  |
| Grid | 5,495 |  |  | 5,609 |  |  | 12,140 |  |  | 13,279 |  |
| Total | $ | 11,049 |  |  | $ | 18,507 |  |  | $ | 19,971 |  |  | $ | 31,852 |  |

[0001628280-17-011077:mdna:24]
Our Wind business unit accounted for 50% and 39% of total revenues for the three and six months ended September 30, 2017, respectively, compared to 70% and 58% for the three and six months ended September 30, 2016, respectively.  Revenues in the Wind business unit decreased 57% and 58% to $5.6 million and $7.8 million in the three and six months ended September 30, 2017, respectively, from $12.9 million and $18.6 million in the three and six months ended September 30, 2016, respectively. Wind business unit revenues in the three and six months ended September 30, 2017 decreased due primarily to fewer ECS shipments to Inox.  This resulted from what we believe, based on our discussions with Inox, to be a temporary demand dislocation caused by the reaction in certain states in India to a recent national wind energy auction that resulted in a record-low power purchase tariff.

[0001628280-17-011077:mdna:25]
Our Grid business unit accounted for 50% and 61% of total revenues for the three and six months ended September 30, 2017, respectively, compared to 30% and 42% for the three and six months ended September 30, 2016, respectively. Our Grid business unit revenues decreased 2% to $5.5 million and decreased 9% to $12.1 million in the three and six months ended September 30, 2017, respectively, from $5.6 million and $13.3 million in the three and six months ended September 30, 2016, respectively.  Grid business unit revenues in the three and six months ended September 30, 2017 decreased primarily due to lower D-VAR system revenues than in the prior year period, partially offset, in the six months ended September, 30, 2017, by higher revenue from the U.S. Navy.

[0001628280-17-011077:mdna:26]
The following table sets forth customers who represented 10% or more of our total revenues for the three and six months ended September 30, 2017 and 2016:

[0001628280-17-011077:mdna:27]
|  | Three months ended September 30, | Six months ended September 30, |
|  | 2017 |  | 2016 | 2017 |  | 2016 |
| INOX Wind Limited | 46 | % |  | 68 | % | 35 | % |  | 51 | % |
| U.S. Navy | — | % |  | — | % | 16 | % |  | — | % |
| YMC Inc. | 15 | % |  | — | % | <10% |  |  | — | % |

[0001628280-17-011077:mdna:28]
[same as prior period, unchanged from 0001628280-17-008331:mdna:24]

[0001628280-17-011077:mdna:29]
Cost of revenues decreased by 34% and 16% to $10.8 million and $24.2 million for the three and six months ended September 30, 2017, compared to $16.4 million and $28.9 million for the three and six months ended September 30, 2016. Gross margin was 2% and (21)% for the three and six months ended September 30, 2017, compared to 11% and 9% for the three and six months ended September 30, 2016. The decreases in the gross margin for the three and six months ended September 30, 2017 were due to decreased revenue as discussed above, partially offset by a more favorable product mix in the current year period.

[0001628280-17-011077:mdna:30]
[same as prior period, unchanged from 0001628280-17-008331:mdna:26]

[0001628280-17-011077:mdna:31]
[same as prior period, unchanged from 0001628280-17-008331:mdna:27]

[0001628280-17-011077:mdna:32]
R&D expenses increased by 3% and decreased by 3% to $3.0 million and $5.7 million for the three and six months ended September 30, 2017, from $2.9 million and $5.8 million for the three and six months ended September 30, 2016.  The increase in R&D expenses in the three months ended September 30, 2017 as compared to the prior year period was primarily due to lower research and development subsidy credits, partially offset by lower compensation expense. The decrease in R&D expenses for the six month period ended September 30, 2017 compared to the prior year period was primarily due to lower compensation expense.

[0001628280-17-011077:mdna:33]
[same as prior period, unchanged from 0001628280-17-008331:mdna:29]

[0001628280-17-011077:mdna:34]
SG&A expenses decreased by 16% and 15% to $5.3 million and $11.5 million in the three and six months ended September 30, 2017, from $6.3 million and $13.6 million in the three and six months ended September 30, 2016. The decreases in SG&A expenses in the three and six months ended September 30, 2017 were due primarily to reduced overall compensation expense.

[0001628280-17-011077:mdna:35]
[same as prior period, unchanged from 0001628280-17-008331:mdna:31]

[0001628280-17-011077:mdna:36]
We recorded amortization expense related to our core technology and know-how, trade names and trademark intangible assets of less than $0.1 million in each of the three and six months ended September 30, 2017 and 2016.

[0001628280-17-011077:mdna:37]
Change in fair value of contingent consideration

[0001628280-17-011077:mdna:38]
The change in fair value of our contingent consideration for the Make Whole Payment on the ITC Acquisition resulted in a gain of $0.2 million in the three and six months ended September 30, 2017. The change in the fair value was primarily driven by the change in stock price, which is a key valuation metric.

[0001628280-17-011077:mdna:39]
[same as prior period, unchanged from 0001628280-17-008331:mdna:33]

[0001628280-17-011077:mdna:40]
We recorded a restructuring charge of $1.3 million for severance costs in the six months ended September 30, 2017 as a result of the reduction in force announced on April 4, 2017. Included in the $1.3 million severance pay, charged to operations in the six months ended September 30, 2017, is $0.5 million of severance pay for one of our former executive officers pursuant to the terms of a severance agreement dated June 30, 2017.  Under the terms of the severance agreement, our former executive officer is entitled to eighteen months of his base salary, which is expected to be paid by December 31, 2018.  From and after January 1, 2018, at our discretion, we may settle any remaining unpaid cash severance owed to our former executive officer through the issuance of a number of immediately vested shares of our common stock, determined by multiplying the remaining unpaid cash severance owed by 120%, and then dividing by the closing stock price per share of our common stock as of the last business day prior to the issuance of the shares.

[0001628280-17-011077:mdna:41]
[same as prior period, unchanged from 0001628280-17-008331:mdna:35]

[0001628280-17-011077:mdna:42]
[same as prior period, unchanged from 0001628280-17-008331:mdna:36]

[0001628280-17-011077:mdna:43]
|  | Three months ended September 30, |  | Six months ended September 30, |
|  | 2017 |  | 2016 |  | 2017 |  | 2016 |
| Operating loss: |  |  |  |  |  |  |  |
| Wind | $ | (1,440 | ) |  | $ | (1,235 | ) |  | $ | (5,873 | ) |  | $ | (4,264 | ) |
| Grid | (6,100 | ) |  | (5,262 | ) |  | (14,268 | ) |  | (10,577 | ) |
| Unallocated corporate expenses | (265 | ) |  | (653 | ) |  | (2,358 | ) |  | (1,653 | ) |
| Total | $ | (7,805 | ) |  | $ | (7,150 | ) |  | $ | (22,499 | ) |  | $ | (16,494 | ) |

[0001628280-17-011077:mdna:44]
Our Wind segment generated an operating loss of $1.4 million and $5.9 million in the three and six months ended September 30, 2017, compared to $1.2 million and $4.3 million in the three and six months ended September 30, 2016. The increases in the Wind business unit operating loss in the three and six months ended September 30, 2017 were due primarily to fewer ECS shipments to Inox as previously discussed.

[0001628280-17-011077:mdna:45]
Our Grid segment generated an operating loss of $6.1 million and $14.3 million in the three and six months ended September 30, 2017, compared to $5.3 million and $10.6 million in the three and six months ended September 30, 2016.  The increases in the Grid business unit operating loss in the three and six months ended September 30, 2017 were due primarily to  $1.6 million and $4.1 million, respectively, of accelerated depreciation related to revised estimates of the useful lives of certain pieces of manufacturing equipment, and lower D-VAR system revenues.

[0001628280-17-011077:mdna:46]
Unallocated corporate expenses primarily consist of stock-based compensation expense of $0.5 million and $1.2 million for the three and six months ended September 30, 2017, respectively, and $0.7 million and $1.7 million in the three and six months ended September 30, 2016, respectively.  Additionally, a restructuring charge of $1.3 million, primarily for severance costs as a result of the restructuring action announced on April 4, 2017, is included in unallocated corporate expenses for the six months ended September 30, 2017, as well as a gain for the change in fair value of the contingent consideration of $0.2 million in the three and six months ended September 30, 2017.

[0001628280-17-011077:mdna:47]
Change in fair value of warrants

[0001628280-17-011077:mdna:48]
The change in fair value of warrants resulted in gains of $0.1 million and $1.1 million in the three and six months ended September 30, 2017, compared to gains of $1.2 million and $0.6 million in the three and six months ended September 30, 2016.  The change in the fair value was primarily driven by changes in stock price, which is a key valuation metric.

[0001628280-17-011077:mdna:49]
Interest income (expense), net

[0001628280-17-011077:mdna:50]
Interest income (expense), net, was income of     less than $0.1 million in each of the three and six months ended September 30, 2017, compared to expense of $0.1 million and $0.2 million in the three and six months ended September 30, 2016. The decrease was related to lower interest expense due to the maturity of both of our term loans with Hercules Technology Growth Capital, Inc. (“Hercules”).  Our Term Loan B matured in November 2016, and our Term Loan C matured in June 2017.

[0001628280-17-011077:mdna:51]
Other expense, net

[0001628280-17-011077:mdna:52]
Other expense, net, was $0.8 million and $2.2 million in the three and six months ended September 30, 2017, compared to other expense, net, of $0.5 million and $0.4 million in the three and six months ended September 30, 2016.  The increase in other expense, net, during the three and six months ended September 30, 2017, was primarily driven by higher foreign currency losses.

[0001628280-17-011077:mdna:53]
[same as prior period, unchanged from 0001628280-17-008331:mdna:47]

[0001628280-17-011077:mdna:54]
Income tax benefit was $0.2 million and $0.1 million in the three and six months ended September 30, 2017, compared to income tax expense of $0.8 million and $1.1 million in the three and six months ended September 30, 2016. The decrease in income tax expense during the six months ended September 30, 2017 was primarily due to the release of valuation allowances of $1.1 million in the three months ended September 30, 2017 as a result of the deferred tax liability purchase adjustment recorded as a result of the ITC Acquisition, for the difference in tax basis on the ITC net assets acquired.

[0001628280-17-011077:mdna:55]
[same as prior period, unchanged from 0001628280-17-008331:mdna:49]

[0001628280-17-011077:mdna:56]
[same as prior period, unchanged from 0001628280-17-008331:mdna:50]

[0001628280-17-011077:mdna:57]
We define non-GAAP net loss as net loss before sale of minority investments, stock-based compensation, amortization of acquisition-related intangibles, consumption of zero cost-basis inventory, changes in fair value of warrants and contingent consideration, non-cash interest expense, tax effect of adjustments, and the other non-cash or unusual charges, indicated in the table below. We believe non-GAAP net loss assists management and investors in comparing our performance across reporting periods on a consistent basis by excluding these non-cash or non-recurring charges that we do not believe are indicative of our core operating performance. A reconciliation of GAAP to non-GAAP net loss is set forth in the table below (in thousands, except per share data):

[0001628280-17-011077:mdna:58]
|  | Three months ended September 30, | Six months ended September 30, |
|  | 2017 |  | 2016 | 2017 |  | 2016 |
| Net loss | $ | (7,281 | ) |  | $ | (7,325 | ) | $ | (22,533 | ) |  | $ | (17,680 | ) |
| Sale of minority investments | (951 | ) |  | — |  | (951 | ) |  | — |  |
| Stock-based compensation | 478 |  |  | 653 |  | 1,232 |  |  | 1,653 |  |
| Amortization of acquisition-related intangibles | — |  |  | 39 |  | 13 |  |  | 78 |  |
| Consumption of zero cost-basis inventory | (340 | ) |  | (482 | ) | (396 | ) |  | (640 | ) |
| Change in fair value of warrants and contingent consideration | (346 | ) |  | (1,244 | ) | (1,270 | ) |  | (567 | ) |
| Non-cash interest expense | — |  |  | 42 |  | 19 |  |  | 98 |  |
| Tax effect of adjustments | 114 |  |  | 77 |  | 123 |  |  | 102 |  |
| Non-GAAP net loss | $ | (8,326 | ) |  | $ | (8,240 | ) | $ | (23,763 | ) |  | $ | (16,956 | ) |
| Non-GAAP net loss per share | $ | (0.44 | ) |  | $ | (0.60 | ) | $ | (1.33 | ) |  | $ | (1.24 | ) |
| Weighted average shares outstanding - basic and diluted | 19,060 |  |  | 13,769 |  | 17,925 |  |  | 13,723 |  |

[0001628280-17-011077:mdna:59]
We incurred non-GAAP net losses of $8.3 million or $0.44 per share, and $23.8 million or $1.33 per share, for the three and six months ended September 30, 2017, compared to non-GAAP net losses of $8.2 million or $0.60 per share, and $17.0 million or $1.24 per share for the three and six months ended September 30, 2016. The increase in non-GAAP net loss in both the three and six month period ended September 30, 2017 was driven primarily by an increase in net loss as previously discussed, and an adjustment for the sale of our minority investment in Blade Dynamics, partially offset by the gain resulting from the decreased value of the warrants and contingent consideration on the ITC acquisition in the three months ended September 30, 2017.

[0001628280-17-011077:mdna:60]
[same as prior period, unchanged from 0001628280-17-008331:mdna:54]

[0001628280-17-011077:mdna:61]
We have experienced recurring operating losses and as of September 30, 2017 had an accumulated deficit of $978.1 million. In addition, we have experienced recurring negative operating cash flows and our Wind segment revenues decreased substantially in the six months ended September 30, 2017 compared to the prior year period. From April 1, 2011 through the date of this filing, we have reduced our global workforce substantially, including an 8% reduction in force, primarily affecting employees in our Devens, Massachusetts facility, effective April 4, 2017. We incurred restructuring charges of $1.3 million in cash severance expenses in the six months ended September 30, 2017 in connection with the workforce reduction. We plan to closely monitor our expenses and, if required, expect to further reduce operating costs and capital spending to enhance liquidity.

[0001628280-17-011077:mdna:62]
Our cash requirements depend on numerous factors, including if and when the Inox demand dislocation is resolved, the successful completion of our product development activities, our ability to commercialize our Resilient Electric Grid (“REG”) and ship protection system solutions, rate of customer and market adoption of our products, collecting receivables according to established terms, and the continued availability of U.S. government funding during the product development phase of our Superconductors-based products.

[0001628280-17-011077:mdna:63]
At September 30, 2017, we had cash, cash equivalents, and restricted cash of $30.5 million, compared to $27.7 million at March 31, 2017, an increase of $2.7 million.  The increase in total cash, cash equivalents, and restricted cash was due primarily

[0001628280-17-011077:mdna:64]
to cash received from the May 2017 equity offering. See further discussion below.  Our cash and cash equivalents, and restricted cash are summarized as follows (in thousands):

[0001628280-17-011077:mdna:65]
|  | September 30, 2017 |  | March 31,2017 |
| Cash and cash equivalents | $ | 30,320 |  |  | $ | 26,784 |  |
| Restricted cash | 165 |  |  | 960 |  |
| Total cash, cash equivalents, and restricted cash | $ | 30,485 |  |  | $ | 27,744 |  |

[0001628280-17-011077:mdna:66]
As of September 30, 2017, we had approximately $3.1 million of cash, cash equivalents, and restricted cash in foreign bank accounts, with a majority of this cash located in Europe.

[0001628280-17-011077:mdna:67]
For the six months ended September 30, 2017, net cash used in operating activities was $13.5 million compared to $10.9 million of cash used for the six months ended September 30, 2016. The increase in net cash used in operations was due primarily to an increased operating loss, and less cash collections from Inox, partially offset by usage of inventory.

[0001628280-17-011077:mdna:68]
For the six months ended September 30, 2017, net cash provided by investing activities was $1.3 million, compared to net cash used in investing activities of $0.4 million for the six months ended September 30, 2016. The increase in net cash used in investing activities was due primarily to the additional cash received related to the achievement of certain milestones following the previous sale of our minority interest in Blade Dynamics and the decrease in restricted cash.

[0001628280-17-011077:mdna:69]
For the six months ended September 30, 2017, net cash provided by financing activities was $15.2 million compared to net cash used in financing activities of $2.5 million in the six months ended September 30, 2016. The increase in net cash provided by financing activities was primarily due to net proceeds of $17.0 million from the issuance of 4.6 million shares of common stock in May 2017, with no such equity offering in the prior year period.  See the discussion regarding the May 2017 equity offering below.

[0001628280-17-011077:mdna:70]
At September 30, 2017, we had $0.2 million of restricted cash included in long-term assets. These amounts included in restricted cash primarily represent deposits to secure letters of credit for various supply contracts. These deposits are held in interest bearing accounts.

[0001628280-17-011077:mdna:71]
[same as prior period, unchanged from 0001628280-17-008331:mdna:66]

[0001628280-17-011077:mdna:72]
On May 5, 2017, we entered into an underwriting agreement relating to the issuance and sale (the "Offering") of up to 4.0 million shares of our common stock at a public offering price of $4.00 per share and granted a 30-day option (the "Option") to the underwriters to purchase up to an additional 600,000 shares of common stock at the public offering price. The net proceeds to us from the Offering were approximately $14.7 million, after deducting underwriting discounts and commissions and offering expenses payable by us.  On May 24, 2017, the underwriters notified us that they had exercised in full their Option to purchase an additional 600,000 shares of common stock in connection with the Offering.   The net proceeds to us from the Option were approximately $2.3 million, after deducting underwriting discounts and commissions and offering expenses payable by us.  The total net proceeds to us during the three months ended June 30, 2017 from the Offering and Option were approximately $17.0 million, after deducting underwriting discounts and commissions and offering expenses payable by us.  The Company terminated its At Market Issuance Sales Agreement with FBR Capital Markets & Co in conjunction with the Offering.  In addition, in December 2015, we entered into a set of strategic agreements valued at approximately $210.0 million with Inox.

[0001628280-17-011077:mdna:73]
[same as prior period, unchanged from 0001628280-17-008331:mdna:68]

[0001628280-17-011077:mdna:74]
Legal Proceedings

[0001628280-17-011077:mdna:75]
We are involved in legal and administrative proceedings and claims of various types. See Part II, Item 1, “Legal Proceedings,” for additional information. We record a liability in our consolidated financial statements for these matters when a loss is known

[0001628280-17-011077:mdna:76]
or considered probable and the amount can be reasonably estimated. We review these estimates each accounting period as additional information is known and adjust the loss provision when appropriate. If a matter is both probable to result in liability and the amounts of loss can be reasonably estimated, we estimate and disclose the possible loss or range of loss to the extent necessary to make the consolidated financial statements not misleading. If the loss is not probable or cannot be reasonably estimated, a liability is not recorded in our consolidated financial statements.

[0001628280-17-011077:mdna:77]
[same as prior period, unchanged from 0001628280-17-008331:mdna:71]

[0001628280-17-011077:mdna:78]
[same as prior period, unchanged from 0001628280-17-008331:mdna:72]

[0001628280-17-011077:mdna:79]
[same as prior period, unchanged from 0001628280-17-008331:mdna:73]

[0001628280-17-011077:mdna:80]
[same as prior period, unchanged from 0001628280-17-008331:mdna:74]

[0001628280-17-011077:mdna:81]
[same as prior period, unchanged from 0001628280-17-008331:mdna:75]

[0001628280-17-011077:mdna:82]
In May 2014, the Financial Accounting Standards Board (“FASB”) and the International Accounting Standards Board (IASB) issued ASU 2014-09, Revenue from Contracts with Customers (Topic 606). The guidance substantially converges final standards on revenue recognition between the FASB and IASB providing a framework on addressing revenue recognition issues and, upon its effective date, replaces almost all existing revenue recognition guidance, including industry-specific guidance, in current U.S. generally accepted accounting principles. The FASB has subsequently issued the following amendments to ASU 2014-09 which are all effective for annual reporting periods beginning after December 15, 2017.

[0001628280-17-011077:mdna:83]
•In March 2016, the FASB issued ASU No. 2016-08, Revenue from Contracts with Customers (Topic 606): Principal versus Agent Considerations, which clarifies the implementation guidance on principal versus agent considerations.

[0001628280-17-011077:mdna:84]
•In April 2016, the FASB issued ASU No. 2016-10, Revenue from Contracts with Customers (Topic 606): Identifying Performance Obligations and Licensing, which clarifies certain aspects of identifying performance obligations and licensing implementation guidance.

[0001628280-17-011077:mdna:85]
•In May 2016, the FASB issued ASU No. 2016-12, Revenue from Contracts with Customers (Topic 606): Narrow- Scope Improvements and Practical Expedients related to disclosures of remaining performance obligations, as well as other amendments to guidance on collectability, non-cash consideration and the presentation of sales and other similar taxes collected from customers.

[0001628280-17-011077:mdna:86]
•In December 2016, the FASB issued ASU No. 2016-20, Technical Corrections and Improvements to Topic 606, Revenue from Contracts with Customers, which amends certain narrow aspects of the guidance issued in ASU 2014-09 including guidance related to the disclosure of remaining performance obligations and prior-period performance obligations, as well as other amendments to the guidance on loan guarantee fees, contract costs, refund liabilities, advertising costs and the clarification of certain examples.

[0001628280-17-011077:mdna:87]
We are currently evaluating the provisions of ASU 2014-09 and its amendments, and assessing the impact the adoption of this guidance will have on our financial position, results of operations and disclosures.  This process has included analyzing the current contract portfolio, comparing our current contract policies and accounting to the requirements of the new standard and identifying the differences.  We anticipate the adoption of this guidance will result in certain changes in the identification of deliverables in our contracts and allocation of transaction price.  These multiple element contracts are primarily entered into under the Grid business unit.  Additionally, this guidance could lead to recognizing certain revenue transactions sooner than in the past, on certain contracts, as we will need to estimate the revenue we will be entitled to upon contract completion, and later on other contracts, due to lack of an enforceable right to payment for performance obligations satisfied over time.  We will continue to assess our contracts for any other impacts that may result.  During the second half of fiscal 2017, we plan to assess our current revenue controls, and identify and implement any changes that may be necessary to comply with our new revenue policies and the provisions of ASU 2014-09, which will be in place as of April 1, 2018.

[0001628280-17-011077:mdna:88]
We are required to adopt the new standards in the first quarter of fiscal 2018 and expect to do so retrospectively with the cumulative effect of initially applying the guidance recognized at the date of initial application (the modified retrospective transition method). We are still evaluating the final impact of this adoption method on our consolidated financial statements.

[0001628280-17-011077:mdna:89]
In January 2016, the FASB issued ASU 2016-01, Financial Instruments-Overall (Subtopic 825-10): Recognition and Measurement of Financial Assets and Financial Liabilities.  The amendments in ASU 2016-01 enhance the reporting model for financial instruments to provide users of financial statements with more decision-useful information. This ASU is effective for annual reporting periods beginning after December 15, 2017, and interim periods within those fiscal years.  We are currently evaluating the impact, if any, the adoption of ASU 2016-01 may have on our consolidated financial statements.

[0001628280-17-011077:mdna:90]
In February 2016, the FASB issued ASU 2016-02, Leases (Topic 842). The guidance in this ASU supersedes the leasing guidance in Topic 840, Leases. Under the new guidance, lessees are required to recognize lease assets and lease liabilities on the balance sheet for all leases with terms longer than 12 months. Leases will be classified as either finance or operating, with classification affecting the pattern of expense recognition in the income statement. This ASU is effective for fiscal years beginning after December 15, 2019, including interim periods within those fiscal years. A modified retrospective transition approach is required for lessees for capital and operating leases existing at, or entered into after, the beginning of the earliest comparative period presented in the financial statements, with certain practical expedients available. We are currently evaluating the effects adoption of this guidance will have on our consolidated financial statements.

[0001628280-17-011077:mdna:91]
In June 2016, the FASB issued ASU 2016-13, Financial Instruments-Credit Losses (Topic 326): Measurement of Credit Losses on Financial Instruments.  The amendments in ASU 2016-13 provide more decision useful information about the expected credit losses on financial instruments and other commitments to extend credit held by a reporting entity at each reporting date. The ASU is effective for annual reporting periods beginning after December 15, 2019, including interim periods within that year.  We are currently evaluating the impact, if any, the adoption of ASU 2016-13 may have on our consolidated financial statements.

[0001628280-17-011077:mdna:92]
[same as prior period, unchanged from 0001628280-17-008331:mdna:87]

[0001628280-17-011077:mdna:93]
•In August 2016, the FASB issued ASU 2016-15, Statement of Cash Flows (Topic 230): Classification of Certain Cash Receipts and Cash Payments.  The amendments in ASU 2016-15 provide more guidance towards the classification of multiple different types of cash flows in order to reduce the diversity in reporting across entities.

[0001628280-17-011077:mdna:94]
•In November 2016, the FASB issued ASU 2016-18, Statement of Cash Flows (Topic 230): Restricted Cash.  The amendments in ASU 2016-18 explain the change during the period in the total of cash, cash equivalents, and amounts generally described as restricted cash or restricted cash equivalents. Therefore, amounts generally described as restricted cash and restricted cash equivalents should be included with cash and cash equivalents when reconciling the beginning-of-period and end-of-period total amounts shown on the statement of cash flows.

[0001628280-17-011077:mdna:95]
We are currently evaluating the impact, if any, the adoption of ASU 2016-15 and ASU 2016-18 may have on our consolidated financial statements.

[0001628280-17-011077:mdna:96]
In October 2016, the FASB issued ASU 2016-16, Income Taxes (Topic 740): Intra-Entity Transfers of Assets Other Than Inventory.  The amendments in ASU 2016-16 improve the accounting for the income tax consequences of intra-entity transfers of assets other than inventory. The ASU is effective for annual reporting periods beginning after December 15, 2017, including interim periods within that year.  We are currently evaluating the impact, if any, the adoption of ASU 2016-16 may have on our consolidated financial statements.

[0001628280-17-011077:mdna:97]
In January 2017, the FASB issued ASU 2017-01, Business Combinations.  The amendments in ASU 2017-01 clarify the definition of a business with the objective of adding guidance to assist entities with evaluating whether transactions should be accounted for as acquisitions (or disposals) of assets or businesses. The ASU is effective for annual reporting periods beginning after December 15, 2017, including interim periods within those periods.  We adopted ASU 2017-01 effective September 30, 2017, following the acquisition of ITC.  We considered these amendments in our decision to record the combination of the entities as an Acquisition.  See Note 4, "Acquisitions and Related Goodwill",  for further details.  These impacts have been included in the consolidated financial statements.

[0001628280-17-011077:mdna:98]
In January 2017, the FASB issued ASU 2017-03, Accounting Changes and Error Corrections (Topic 250) and Investments - Equity Method and Joint Ventures.  The amendments in ASU 2017-03 provide additional detail surrounding disclosures required related to adoption of new pronouncements. The ASU is effective for the periods of each related pronouncement.  We are currently evaluating the impact the adoption of ASU 2017-03 may have on our consolidated financial statements.

[0001628280-17-011077:mdna:99]
In January 2017, the FASB issued ASU 2017-04, Intangibles—Goodwill and Other (Topic 350): Simplifying the Test for Goodwill Impairment.  The amendments in ASU 2017-04 eliminated the prior requirement to perform procedures to determine the fair value at the impairment testing date of an entity's assets and liabilities (including unrecognized assets and liabilities) following the procedure that would be required in determining the fair value of assets acquired and liabilities assumed in a business combination.  Under the new guidelines an entity should perform its annual, or interim, goodwill impairment test by comparing the fair value of a reporting unit with its carrying amount. An entity should recognize an impairment charge for the amount by which the carrying amount exceeds the reporting unit’s fair value.  The ASU is effective for annual reporting periods beginning after December 15, 2019.  Early adoption is permitted for interim or annual goodwill impairment tests performed on testing dates after January 1, 2017.  Following the Acquisition of ITC, we performed an analysis and determined that the transaction included a portion of goodwill.  We have accounted for that value on our balance sheet as of September 30, 2017.  See Note 4, "Acquisitions and Related Goodwill" for further details.  Given the results of our analysis, we adopted ASU 2017-04 effective September 30, 2017, and determined there were no triggering events requiring further impairment analysis at this time. The Company expects to perform its annual impairment test during the fourth quarter of fiscal 2017.

[0001628280-17-011077:mdna:100]
In February 2017, the FASB issued ASU 2017-05, Other Income - Gains and Losses from the Derecognition of Non-financial Assets (Subtopic 610-20).  The amendments in ASU 2017-05 clarify the scope of Subtopic 610-20, Other Income-Gains and Losses from the Derecognition of Non-financial Assets, and to add guidance for partial sales of non-financial assets. Subtopic 610-20, which was issued in May 2014 as a part of Accounting Standards Update No. 2014-09, Revenue from Contracts with Customers (Topic 606), provides guidance for recognizing gains and losses from the transfer of non-financial assets in contracts with non-customers.  We are currently evaluating the impact the adoption of ASU 2017-05 may have on our consolidated financial statements.

[0001628280-17-011077:mdna:101]
In May 2017, the FASB issued ASU 2017-09, Compensation - Stock Compensation (Subtopic 718) Scope of Modification Accounting.  The amendments in ASU 2017-09 provide clarity and reduce both (1) diversity in practice and (2) cost and complexity when applying the guidance in Topic 718, Compensation—Stock Compensation, to a change to the terms or conditions of a share-based payment award.  The ASU is effective for annual reporting periods beginning after December 15, 2017, including interim periods within those periods. We are currently evaluating the impact the adoption of ASU 2017-09 may have on our consolidated financial statements.

[0001628280-17-011077:mdna:102]
In July 2017, the FASB issued ASU 2017-11, Earnings per Share (Topic 260), Distinguishing Liabilities from Equity (Topic   480), and Derivatives and Hedging (Topic 815).  The amendments in ASU 2017-11 provide guidance for freestanding equity-linked financial instruments, such as warrants and conversion options in convertible debt or preferred stock, and should no longer be accounted for as a derivative liability at fair value as a result of the existence of a down round feature.  The ASU is effective for annual reporting periods beginning after December 15, 2018, including interim periods within those periods. We are currently evaluating the impact the adoption of ASU 2017-11 may have on our consolidated financial statements.

[0001628280-17-011077:mdna:103]
We do not believe that other recently issued accounting pronouncements will have a material impact on our consolidated financial statements.
