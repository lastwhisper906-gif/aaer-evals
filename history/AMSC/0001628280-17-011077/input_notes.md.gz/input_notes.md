# AMSC notes — 0001628280-17-011077


## us-gaap:AccountsPayableAndAccruedLiabilitiesDisclosureTextBlock

[0001628280-17-011077:notes:1]
[same as prior period, unchanged from 0001628280-17-008331:notes:1]

[0001628280-17-011077:notes:2]
Accounts payable and accrued expenses at September 30, 2017 and March 31, 2017 consisted of the following (in thousands):

[0001628280-17-011077:notes:3]
|  | September 30, 2017 |  | March 31, 2017 |
| Accounts payable | $ | 4,089 |  |  | $ | 3,207 |  |
| Accrued inventories in-transit | 86 |  |  | 313 |  |
| Accrued other miscellaneous expenses | 1,628 |  |  | 2,240 |  |
| Accrued restructuring | 493 |  |  | — |  |
| Accrued compensation | 3,674 |  |  | 5,042 |  |
| Income taxes payable | 2,194 |  |  | 1,344 |  |
| Accrued warranty | 1,852 |  |  | 2,344 |  |
| Total | $ | 14,016 |  |  | $ | 14,490 |  |

[0001628280-17-011077:notes:4]
[same as prior period, unchanged from 0001628280-17-008331:notes:4]

[0001628280-17-011077:notes:5]
[same as prior period, unchanged from 0001628280-17-008331:notes:5]

[0001628280-17-011077:notes:6]
|  | Three months ended September 30, |  | Six months ended September 30, |
|  | 2017 |  | 2016 |  | 2017 |  | 2016 |
| Balance at beginning of period | $ | 2,026 |  |  | $ | 2,774 |  |  | $ | 2,344 |  |  | $ | 3,601 |  |
| Change in accruals for warranties during the period | 86 |  |  | 316 |  |  | 127 |  |  | 417 |  |
| Settlements during the period | (260 | ) |  | (396 | ) |  | (619 | ) |  | (1,324 | ) |
| Balance at end of period | $ | 1,852 |  |  | $ | 2,694 |  |  | $ | 1,852 |  |  | $ | 2,694 |  |


## us-gaap:BasisOfAccountingPolicyPolicyTextBlock

[0001628280-17-011077:notes:7]
These unaudited condensed consolidated financial statements of the Company have been prepared on a going concern basis in accordance with United States generally accepted accounting principles (“GAAP”) and the Securities and Exchange Commission’s (“SEC”) instructions to Form 10-Q. The going concern basis of presentation assumes that the Company will continue operations and will be able to realize its assets and discharge its liabilities and commitments in the normal course of business. Certain information and footnote disclosures normally included in the financial statements prepared in accordance with GAAP have been condensed or omitted pursuant to those instructions. The year-end condensed balance sheet data was derived from audited financial statements but does not include all disclosures required by GAAP. The unaudited condensed consolidated financial statements, in the opinion of management, reflect all adjustments (consisting of normal recurring adjustments) necessary for a fair statement of the results for the interim periods ended September 30, 2017 and 2016 and the financial position at September 30, 2017.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001628280-17-011077:notes:8]
Acquisition and Related Goodwill

[0001628280-17-011077:notes:9]
Acquisition of Infinia Technology Corporation

[0001628280-17-011077:notes:10]
On September 25, 2017, the Company acquired Infinia Technology Corporation ("ITC") for approximately $3.8 million as described below (the "Acquisition").  Located in Richmond, Washington, ITC is a technology firm founded in 2009 specializing in the design, development and commercialization of cryo-coolers for a wide range of applications.

[0001628280-17-011077:notes:11]
Pursuant to the terms of the stock purchase agreement ("SPA"), the Company acquired all of the issued and outstanding shares of ITC (the "ITC Shares") from the selling stockholders, for a purchase price of approximately $3.8 million consisting of $0.1 million in cash and 884,890 shares of the Company’s common stock (the "AMSC Shares"), $0.01 par value per share at a per share price of $4.02 on the acquisition date.  Under the terms of the SPA, the Company was obligated to file a registration statement (the "Resale Registration Statement") covering the resale of the AMSC Shares by the selling stockholders no later than 10 business days following the closing of the Acquisition, and to use commercially reasonable efforts to cause the Resale Registration Statement to be declared effective by the SEC as soon as practicable thereafter. Additionally, the Company agreed to pay the selling stockholders in cash (the "Make Whole Payment"), if any, equal to (x) an amount equal to (i) the price per AMSC Share pursuant to the terms of the SPA, multiplied by (ii) the number of AMSC Shares sold by the selling stockholders during the first 90 days after the effectiveness of the Resale Registration Statement, minus (y) the aggregate sales proceeds received by the Selling Stockholders from the sale of any AMSC Shares during the first 90 days after the effectiveness of the Resale Registration Statement.  The Resale Registration Statement was declared effective on October 23, 2017.  The Company has granted a security interest in the ITC Shares to the selling stockholders to secure the Company’s obligation to make any Make Whole Payment. The contingent liability related to the Make Whole Payment was determined under a fair value option based pricing model to be $0.6 million on September 25, 2017.

[0001628280-17-011077:notes:12]
ITC was integrated into the Company's Grid business unit. The Acquisition has been accounted for under the purchase method of accounting in accordance with ASU 805, Business Combinations. The Company allocated the purchase price to the assets acquired and liabilities assumed at their estimated fair values as of the date of Acquisition.  The Company estimated the fair value of the intangible assets at $3.4 million, which consisted of core-technology and know-how, working capital of  $0.2 million and property, plant and equipment of less than $0.1 million. A long-term deferred tax liability of $1.1 million was recorded for the differing book and tax basis of the ITC assets and liabilities.  Provisional amounts have been recorded for the related tax activity as of September 30, 2017. Final adjustments are expected to be made during the third quarter of fiscal 2017.

[0001628280-17-011077:notes:13]
The following table summarizes the consideration paid for ITC and the amounts of the assets acquired and liabilities assumed recognized at the acquisition date, as well as the fair value at the acquisition date of ITC at September 25, 2017 (in millions):

[0001628280-17-011077:notes:14]
|  | September 25, 2017 |
| Consideration |  |
| Cash | $ | 0.1 |  |
| Equity (884,890 shares of common stock at $4.02 per share) | 3.6 |  |
| Contingent consideration | 0.6 |  |
| Total Consideration | $ | 4.3 |  |
| Recognized amounts of identifiable assets acquired and liabilities assumed |  |
| Core technology and know-how | $ | 3.4 |  |
| Working capital | 0.2 |  |
| Property, plant and equipment | 0.0 |  |
| Total identifiable net assets | $ | 3.6 |  |
| Long-term deferred tax liability | 1.1 |  |
| Goodwill allocated | $ | 1.7 |  |

[0001628280-17-011077:notes:15]
The Company valued the Acquisition at $4.2 million (excluding Acquisition costs), using a value of $4.02 per share, which was the closing price of the Company's common stock on the date of Acquisition plus $0.1 million in cash and $0.6 million of contingent consideration for the Make Whole Payment valued as of the closing date.  Acquisition costs of less than $0.1 million were recorded in selling, general and administrative costs.

[0001628280-17-011077:notes:16]
The results of ITC's operations, which were not significant from the date of acquisition until September 30, 2017, are included in the Company’s consolidated results from the date of Acquisition of September 25, 2017, for the three and six months ended September 30, 2017. Assuming the Acquisition had occurred on April 1, 2017 and 2016, the impact on the consolidated results of the Company would not have been significant.

[0001628280-17-011077:notes:17]
Goodwill

[0001628280-17-011077:notes:18]
At the time of the Acquisition, the Company allocated the purchase price to the assets acquired and liabilities assumed at their estimated fair values as of the date of Acquisition. The excess of the purchase price of $1.7 million paid by the Company over the estimated fair value of net assets acquired has been recorded as goodwill in the Company's Grid segment. Goodwill represents the value associated with the acquired workforce and synergies related to the merger of the two companies.

[0001628280-17-011077:notes:19]
The guidance under ASC 805-30 provides for the recognition of goodwill on the Acquisition date measured as the excess of the aggregate consideration transferred over the net of the Acquisition date amounts of net assets acquired and liabilities assumed.  The fair value of the contingent consideration included in the total consideration transferred was determined using the Black Scholes pricing model, and all other consideration transferred was calculated using its observable market fair value. The tangible net assets acquired fair value was based on observable market fair value. The acquired intangible asset fair value was determined using discounted cash flows under an excess in earnings model.

[0001628280-17-011077:notes:20]
Goodwill represents the difference between the purchase price and the fair value of the identifiable tangible and intangible net assets when accounted for using the purchase method of accounting. Goodwill is not amortized, but reviewed for impairment. Goodwill is reviewed annually, and whenever events or changes in circumstances indicate that the carrying value of the goodwill might not be recoverable.

[0001628280-17-011077:notes:21]
The Company early adopted ASU 2017-04 as of September 30, 2017.  The Company will perform an annual impairment assessment on goodwill, unless events occur in the interim periods to indicate impairment may have occurred.  The Company did not identify any triggering events in the period between the date of Acquisition and September 30, 2017, which would require subsequent interim testing of goodwill.  As such, the Company expects to perform its annual goodwill impairment test during the fourth fiscal quarter of 2017.  The Company will compare the fair value of its reporting unit to its carrying value. If the carrying value of the net assets assigned to the reporting unit exceeds the fair value of the reporting unit, then the Company would record an impairment loss equal to the difference.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001628280-17-011077:notes:22]
Commitments and Contingencies

[0001628280-17-011077:notes:23]
Legal Contingencies

[0001628280-17-011077:notes:24]
From time to time, the Company is involved in legal and administrative proceedings and claims of various types. The Company records a liability in its consolidated financial statements for these matters when a loss is known or considered probable and the amount can be reasonably estimated. The Company reviews these estimates each accounting period as additional information is known and adjusts the loss provision when appropriate. If a matter is both probable to result in a liability and the amounts of loss can be reasonably estimated, the Company estimates and discloses the possible loss or range of loss to the extent necessary to make the consolidated financial statements not misleading. If the loss is not probable or cannot be reasonably estimated, a liability is not recorded in its consolidated financial statements.

[0001628280-17-011077:notes:25]
On September 13, 2011, the Company commenced a series of legal actions in China against Sinovel Wind Group Co. Ltd. (“Sinovel”). The Company’s Chinese subsidiary, Suzhou AMSC Superconductor Co. Ltd., filed a claim for arbitration with the Beijing Arbitration Commission in accordance with the terms of the Company’s supply contracts with Sinovel. The case is captioned (2011) Jing Zhong An Zi No. 963.  The Company alleges that Sinovel committed various material breaches of its contracts with the Company and Sinovel has refused to pay past due amounts for prior shipments of core electrical components and spare parts. The Company is seeking compensation for past product shipments and retention (including interest) in the amount of approximately RMB 485 million (approximately $73 million) due to Sinovel’s breaches of its contracts. The Company is also seeking specific performance of its existing contracts as well as reimbursement of all costs and reasonable expenses with respect to the arbitration. The value of the undelivered components under the existing contracts, including the deliveries refused by Sinovel in March 2011, amounts to approximately RMB 4.6 billion (approximately $691 million).

[0001628280-17-011077:notes:26]
On October 8, 2011, Sinovel filed with the Beijing Arbitration Commission an application under the caption (2011) Jing Zhong An Zi No. 963, for a counterclaim against the Company for breach of the same contracts under which the Company filed its original arbitration claim. Sinovel claims, among other things, that the goods supplied by the Company do not conform to the standards specified in the contracts and claims damages in the amount of approximately RMB 1.2 billion (approximately $180 million) upon Sinovel’s requests for change of counterclaim. On February 27, 2012, Sinovel filed with the Beijing Arbitration Commission an application under the caption (2012) Jing Zhong An Zi No. 157, against the Company for breach of the same contracts under which the Company filed its original arbitration claim. Sinovel claims, among other things, that the goods supplied by the Company do not conform to the standards specified in the contracts and claims damages in the amount of approximately RMB 105 million (approximately $16 million). The Company believes that Sinovel’s claims are without merit and it intends to defend these actions vigorously. Since the proceedings in this matter are still in the early technical review phase, the Company cannot reasonably estimate possible losses or range of losses at this time.

[0001628280-17-011077:notes:27]
Other

[0001628280-17-011077:notes:28]
The Company enters into long-term construction contracts with customers that require the Company to obtain performance bonds. The Company is required to deposit an amount equivalent to some or all the face amount of the performance bonds into an escrow account until the termination of the bond. When the performance conditions are met, amounts deposited as collateral for the performance bonds are returned to the Company. In addition, the Company has various contractual arrangements in which minimum quantities of goods or services have been committed to be purchased on an annual basis.

[0001628280-17-011077:notes:29]
As of September 30, 2017, the Company had $0.2 million of restricted cash included in long-term assets. These amounts included in restricted cash primarily represent deposits to secure letters of credit for various supply contracts. These deposits are held in interest bearing accounts.


## us-gaap:DebtDisclosureTextBlock

[0001628280-17-011077:notes:30]
Debt

[0001628280-17-011077:notes:31]
Senior Secured Term Loans

[0001628280-17-011077:notes:32]
On December 19, 2014, the Company entered into a second amendment to its Loan and Security Agreement with Hercules (the “Hercules Second Amendment”) and entered into a new term loan, borrowing an additional $1.5 million (the “Term Loan C”).  After closing fees and expenses, the net proceeds to the Company for the Term Loan C were $1.4 million. The Company made interest only payments at an interest rate of 11% through March 16, 2017 when the interest rate was increased to 11.25%, until maturity on June 1, 2017, when Term Loan C was repaid in its entirety.

[0001628280-17-011077:notes:33]
Hercules received warrants to purchase 13,927 shares of common stock (the “First Warrant”) and 25,641 shares of common stock (the “Second Warrant”) in conjunction with prior term loans that have been repaid in full.  Due to certain adjustment provisions within the warrants, they qualified for liability accounting.  The fair value of the warrants, $0.4 million and $0.2 million, respectively, was recorded upon issuance to debt discount and a warrant liability. In conjunction with the Hercules Second Amendment, the First Warrant and Second Warrant were canceled and replaced with the issuance of a new warrant (the “Hercules Warrant”) to purchase 58,823 shares of common stock at an exercise price of $7.85 per share, subject to certain price-based and other anti-dilution adjustments.  The Hercules Warrant expires on June 30, 2020.  See Note 12, “Warrants and Derivative Liabilities”, for a discussion on the Hercules Warrant and the valuation assumptions used.

[0001628280-17-011077:notes:34]
Interest expense on the Term Loans for the three months ended September 30, 2017 and 2016, was less than $0.1 million.  Included in both periods was less than $0.1 million of non-cash interest expense related to the amortization of the debt discount on the respective Term Loans.  Interest expense on the Term Loans for the six months ended September 30, 2017 and 2016, was less than $0.1 million and $0.3 million, respectively.  Included in both periods was less than $0.1 million of non-cash interest expense related to the amortization of debt discount on the respective Term Loans.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001628280-17-011077:notes:35]
[same as prior period, unchanged from 0001628280-17-008331:notes:22]

[0001628280-17-011077:notes:36]
The Company accounts for its warrants and contingent consideration as liabilities due to certain adjustment provisions within the instruments, which require that they be recorded at fair value. The warrants are subject to revaluation at each balance sheet date and any change in fair value is recorded as a change in fair value of warrants until the earlier of its expiration or its exercise at which time the warrant liability will be reclassified to equity. The Company calculated the fair value of the warrants utilizing an integrated lattice model.  The contingent consideration is subject to revaluation at each balance sheet date and any change in fair value is recorded as a change in fair value of contingent consideration until the earlier of its settlement or expiration. The Company determined the fair value of the contingent consideration utilizing a Black Scholes option pricing method.  See Note 5, "Fair Value Measurements", for further discussion.

[0001628280-17-011077:notes:37]
[same as prior period, unchanged from 0001628280-17-008331:notes:23]

[0001628280-17-011077:notes:38]
On April 4, 2012, the Company entered into a Purchase Agreement with Capital Ventures International ("CVI"). The Purchase Agreement included a warrant to purchase 309,406 shares of the Company’s common stock (the “Original Warrant”).  Pursuant to an exchange in October 2013, the Original Warrant was exchanged for a new warrant (the “Exchanged Warrant”).  The Exchanged Warrant expired on October 4, 2017.

[0001628280-17-011077:notes:39]
[same as prior period, unchanged from 0001628280-17-008331:notes:27]

[0001628280-17-011077:notes:40]
| Fiscal Year 17 | September 30, 2017 | June 30, 2017 |
| Risk-free interest rate | 1.05% | 1.05% |
| Expected annual dividend yield | — | — |
| Expected volatility | 77.95% | 78.25% |
| Term (years) | 0.01 | 0.26 |
| Fair value | $— | $— |

[0001628280-17-011077:notes:41]
[same as prior period, unchanged from 0001628280-17-008331:notes:29]

[0001628280-17-011077:notes:42]
The Company recorded no change in the fair value of the Exchanged Warrant during the three and six months ended September 30, 2017.  The Company recorded net gains of $0.2 million resulting from a decrease in the fair value of the Exchanged Warrant in each of the three and six months ended September 30, 2016, respectively.

[0001628280-17-011077:notes:43]
[same as prior period, unchanged from 0001628280-17-008331:notes:31]

[0001628280-17-011077:notes:44]
On December 19, 2014, the Company entered into the Hercules Second Amendment.  See Note 11, “Debt” for additional information.  In conjunction with the agreement, the Company issued the Hercules Warrant to purchase 58,823 shares of the Company’s common stock.  The Hercules Warrant is exercisable at any time after its issuance at an exercise price of $7.85 per share, subject to certain price-based and other anti-dilution adjustments, and expires on June 30, 2020.

[0001628280-17-011077:notes:45]
[same as prior period, unchanged from 0001628280-17-008331:notes:33]

[0001628280-17-011077:notes:46]
| Fiscal Year 17 | September 30, 2017 | June 30, 2017 |
| Risk-free interest rate | 1.56% | 1.58% |
| Expected annual dividend yield | — | — |
| Expected volatility | 63.97% | 67.76% |
| Term (years) | 2.72 | 2.97 |
| Fair value | $0.1 million | $0.1 million |

[0001628280-17-011077:notes:47]
[same as prior period, unchanged from 0001628280-17-008331:notes:35]

[0001628280-17-011077:notes:48]
The Company recorded no change, and a net gain, resulting from a decrease of $0.1 million in the fair value of the Hercules Warrant during the three and six months ended September 30, 2017, respectively.  The Company recorded a net loss and a net gain, resulting from an increase and a decrease in the fair value of the Hercules Warrant of less than $0.1 million during the three and six months ended September 30, 2016, respectively.

[0001628280-17-011077:notes:49]
[same as prior period, unchanged from 0001628280-17-008331:notes:37]

[0001628280-17-011077:notes:50]
On November 13, 2014, the Company completed an offering of 909,090 units of the Company’s common stock with Hudson Bay Capital. Each unit consisted of one share of the Company’s common stock and 0.9 of a warrant to purchase one share of common stock, or a warrant to purchase in the aggregate 818,181 shares (the “November 2014 Warrant”).  The November 2014 Warrant is exercisable at any time, at an exercise price equal to $7.81 per share, subject to certain price-based and other anti-dilution adjustments, and expires on November 13, 2019.

[0001628280-17-011077:notes:51]
[same as prior period, unchanged from 0001628280-17-008331:notes:39]

[0001628280-17-011077:notes:52]
| Fiscal Year 17 | September 30, 2017 | June 30, 2017 |
| Risk-free interest rate | 1.49% | 1.44% |
| Expected annual dividend yield | — | — |
| Expected volatility | 65.64% | 67.21% |
| Term (years) | 2.12 | 2.37 |
| Fair value | $0.8 million | $0.9 million |

[0001628280-17-011077:notes:53]
[same as prior period, unchanged from 0001628280-17-008331:notes:41]

[0001628280-17-011077:notes:54]
The Company recorded a net gain of $0.1 million and $1.0 million resulting from a decrease in the fair value of the November 2014 Warrant in the three and six months ended September 30, 2017, respectively.  The Company recorded net gains, resulting from decreases in the fair value of the November 2014 Warrant of $0.9 million and $0.3 million in the three and six months ended September 30, 2016.

[0001628280-17-011077:notes:55]
Contingent Consideration

[0001628280-17-011077:notes:56]
The Company evaluated the ITC acquisition make whole payment set forth in the SPA (see Note 5, "Fair Value Measurements" for further details), which may require net settlement cash, and determined the contingent consideration qualified for liability classification and derivative treatment under ASC 815.  As a result, for each period the fair value of the contingent consideration will be remeasured and the resulting gain or loss will be recognized in operating expenses until the liability is settled.

[0001628280-17-011077:notes:57]
Following is a summary of the key assumptions used to calculate the fair value of the contingent consideration related to the ITC acquisition:

[0001628280-17-011077:notes:58]
| Fiscal Year 17 | September 30, 2017 | September 25, 2017 |
| Risk-free interest rate | 1.09% | 1.09% |
| Expected annual dividend yield | — | — |
| Expected volatility | 66.54% | 65.71% |
| Term (years) | 0.31 | 0.32 |
| Fair value | $0.4 million | $0.6 million |

[0001628280-17-011077:notes:59]
The Company recorded a net gain of $0.2 million resulting from a decrease in the fair value of the contingent consideration in the three and six months ended September 30, 2017.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001628280-17-011077:notes:60]
[same as prior period, unchanged from 0001628280-17-008331:notes:43]

[0001628280-17-011077:notes:61]
The Company accounts for its stock-based compensation at fair value. The following table summarizes stock-based compensation expense by financial statement line item for the three and six months ended September 30, 2017 and 2016 (in thousands):

[0001628280-17-011077:notes:62]
|  | Three months ended September 30, |  | Six months ended September 30, |
|  | 2017 |  | 2016 |  | 2017 |  | 2016 |
| Cost of revenues | $ | 23 |  |  | $ | 49 |  |  | $ | 59 |  |  | $ | 99 |  |
| Research and development | 61 |  |  | 62 |  |  | 110 |  |  | 92 |  |
| Selling, general and administrative | 394 |  |  | 542 |  |  | 1,063 |  |  | 1,462 |  |
| Total | $ | 478 |  |  | $ | 653 |  |  | $ | 1,232 |  |  | $ | 1,653 |  |

[0001628280-17-011077:notes:63]
The Company issued 37,140 shares of immediately vested common stock and 795,500 shares of restricted stock awards during the six months ended September 30, 2017, and issued 35,000 shares of immediately vested common stock, and granted 126,000 restricted stock awards during the six months ended September 30, 2016.  These restricted stock awards generally vest over 2-3 years.  Awards for restricted stock include both time-based and performance-based awards.  For options and awards that vest upon the passage of time, expense is being recorded over the vesting period.  Performance-based awards are expensed over the requisite service period based on probability of achievement.  In addition, the Company issued 16,667 restricted stock units under the 2007 Stock Incentive Plan during the six months ended September 30, 2017, each of which represents the right to receive one share of common stock in connection with a severance agreement entered into with one of the Company's former executive officers. These restricted stock units vested and were settled in shares of common stock on the eighth day after receipt of an irrevocable release.

[0001628280-17-011077:notes:64]
The estimated fair value of the Company’s stock-based awards, less expected annual forfeitures, is amortized over the awards’ service period. The total unrecognized compensation cost for unvested outstanding stock options was $0.3 million at September 30, 2017. This expense will be recognized over a weighted average expense period of approximately 1.5 years. The total unrecognized compensation cost for unvested outstanding restricted stock was $3.6 million at September 30, 2017. This expense will be recognized over a weighted-average expense period of approximately 2.1 years.

[0001628280-17-011077:notes:65]
The Company did not grant any stock options during the three and six months ended September 30, 2017.  During the six months ended September 30, 2016, the Company granted 9,703 stock options.  These options will vest over 2 years.  The weighted average assumptions used in the Black Scholes valuation model for stock options granted during the six months ended September 30, 2016 are as follows:.

[0001628280-17-011077:notes:66]
|  | September 30, 2017 |  | September 30, 2016 |  | September 30, 2017 |  | September 30, 2016 |
| Expected volatility | N/A |  | 67.6 | % |  | N/A |  | 67.6 | % |
| Risk-free interest rate | N/A |  | 1.3 | % |  | N/A |  | 1.3 | % |
| Expected life (years) | N/A |  | 5.7 |  |  | N/A |  | 5.7 |  |
| Dividend yield | N/A |  | None |  |  | N/A |  | None |  |


## us-gaap:EarningsPerShareTextBlock

[0001628280-17-011077:notes:67]
[same as prior period, unchanged from 0001628280-17-008331:notes:49]

[0001628280-17-011077:notes:68]
Basic net loss per share (“EPS”) is computed by dividing net loss by the weighted-average number of common shares outstanding for the period. Where applicable, diluted EPS is computed by dividing the net loss by the weighted-average number of common shares and dilutive common equivalent shares outstanding during the period, calculated using the treasury stock method. Common equivalent shares include the effect of restricted stock, exercise of stock options and warrants and contingently issuable shares. For the three and six months ended September 30, 2017, 1.5 million shares were not included in the calculation of diluted EPS as they were considered anti-dilutive, of which 0.3 million relate to outstanding stock options, and 1.2 million relate to outstanding warrants.  For the three and six months ended September 30, 2016, 1.6 million shares were not included in the calculation of diluted EPS as they were considered anti-dilutive, of which 0.4 million relate to outstanding stock options, and 1.2 million relate to outstanding warrants.

[0001628280-17-011077:notes:69]
The following table reconciles the numerators and denominators of the earnings per share calculation for the three and six months ended September 30, 2017 and 2016 (in thousands, except per share data):

[0001628280-17-011077:notes:70]
|  | Three months ended September 30, |  | Six months ended September 30, |
|  | 2017 |  | 2016 |  | 2017 |  | 2016 |
| Numerator: |  |  |  |  |  |  |  |
| Net loss | $ | (7,281 | ) |  | $ | (7,325 | ) |  | $ | (22,533 | ) |  | $ | (17,680 | ) |
| Denominator: |  |  |  |  |  |  |  |
| Weighted-average shares of common stock outstanding | 19,531 |  |  | 14,190 |  |  | 18,316 |  |  | 14,161 |  |
| Weighted-average shares subject to repurchase | (471 | ) |  | (421 | ) |  | (391 | ) |  | (438 | ) |
| Shares used in per-share calculation ― basic | 19,060 |  |  | 13,769 |  |  | 17,925 |  |  | 13,723 |  |
| Shares used in per-share calculation ― diluted | 19,060 |  |  | 13,769 |  |  | 17,925 |  |  | 13,723 |  |
| Net loss per share ― basic | $ | (0.38 | ) |  | $ | (0.53 | ) |  | $ | (1.26 | ) |  | $ | (1.29 | ) |
| Net loss per share ― diluted | $ | (0.38 | ) |  | $ | (0.53 | ) |  | $ | (1.26 | ) |  | $ | (1.29 | ) |


## us-gaap:FairValueDisclosuresTextBlock

[0001628280-17-011077:notes:71]
[same as prior period, unchanged from 0001628280-17-008331:notes:53]

[0001628280-17-011077:notes:72]
[same as prior period, unchanged from 0001628280-17-008331:notes:54]

[0001628280-17-011077:notes:73]
[same as prior period, unchanged from 0001628280-17-008331:notes:55]

[0001628280-17-011077:notes:74]
The Company provides a gross presentation of activity within Level 3 measurement roll-forward and details of transfers in and out of Level 1 and 2 measurements.  A change in the hierarchy of an investment from its current level is reflected in the period during which the pricing methodology of such investment changes.  Disclosure of the transfer of securities from Level 1 to Level 2 or Level 3 is made in the event that the related security is significant to total cash and investments.  The Company did not have any transfers of assets and liabilities from Level 1 and Level 2 to Level 3 of the fair value measurement hierarchy during the three and six months ended September 30, 2017.

[0001628280-17-011077:notes:75]
[same as prior period, unchanged from 0001628280-17-008331:notes:57]

[0001628280-17-011077:notes:76]
The following table provides the assets and liabilities carried at fair value on a recurring basis, measured as of September 30, 2017 and March 31, 2017 (in thousands):

[0001628280-17-011077:notes:77]
|  | TotalCarryingValue |  | Quoted Prices inActive Markets(Level 1) |  | Significant OtherObservable Inputs(Level 2) |  | SignificantUnobservable Inputs(Level 3) |
| September 30, 2017: |  |  |  |  |  |  |  |
| Assets: |  |  |  |  |  |  |  |
| Cash equivalents | $ | 24,392 |  |  | $ | 24,392 |  |  | $ | — |  |  | $ | — |  |
| Derivative liabilities: |  |  |  |  |  |  |  |
| Acquisition contingent consideration | $ | 370 |  |  | $ | — |  |  | $ | — |  |  | $ | 370 |  |
| Warrants | 854 |  |  | — |  |  | — |  |  | 854 |  |
| Total derivative liabilities | $ | 1,224 |  |  | $ | — |  |  | $ | — |  |  | $ | 1,224 |  |

[0001628280-17-011077:notes:78]
[same as prior period, unchanged from 0001628280-17-008331:notes:60]

[0001628280-17-011077:notes:79]
[same as prior period, unchanged from 0001628280-17-008331:notes:61]

[0001628280-17-011077:notes:80]
|  | Warrants |  | Acquisition Contingent Consideration |
| April 1, 2017 | $ | 1,923 |  |  | $ | — |  |
| Issuance of contingent consideration | — |  |  | 571 |  |
| Mark to market adjustment | (1,069 | ) |  | (201 | ) |
| Balance at September 30, 2017 | $ | 854 |  |  | $ | 370 |  |

[0001628280-17-011077:notes:81]
[same as prior period, unchanged from 0001628280-17-008331:notes:63]

[0001628280-17-011077:notes:82]
[same as prior period, unchanged from 0001628280-17-008331:notes:64]

[0001628280-17-011077:notes:83]
[same as prior period, unchanged from 0001628280-17-008331:notes:65]

[0001628280-17-011077:notes:84]
[same as prior period, unchanged from 0001628280-17-008331:notes:66]

[0001628280-17-011077:notes:85]
[same as prior period, unchanged from 0001628280-17-008331:notes:67]

[0001628280-17-011077:notes:86]
Warrants were issued in conjunction with a Securities Purchase Agreement (the “Purchase Agreement”) with Capital Ventures International (“CVI”) in April 2012, an equity offering to Hudson Bay Capital in November 2014, and a Loan and Security Agreement with Hercules Technology Growth Capital, Inc. (“Hercules”) in June 2012 and through subsequent amendments. See Note 11, “Debt,” and Note 12 “Warrants and Derivative Liabilities,” for additional information. These warrants are subject to revaluation at each balance sheet date, and any change in fair value will be recorded as a change in fair value in derivatives and warrants until the earlier of their exercise or expiration.

[0001628280-17-011077:notes:87]
The Company relies on various assumptions in a lattice model to determine the fair value of warrants. The Company has valued the warrants within Level 3 of the valuation hierarchy. See Note 12, “Warrants and Derivative Liabilities,” for a discussion of the warrants and the valuation assumptions used.

[0001628280-17-011077:notes:88]
Contingent consideration relates to a make whole payment provision set forth in the SPA that requires the Company to guarantee the purchase price of the acquisition should the aggregate proceeds of the resale of AMSC shares sold by selling stockholders during the first 90 days after the effectiveness of the Resale Registration Statement be less than the agreed upon purchase price for such AMSC Shares (per the terms of the SPA) sold during such 90 day period.  See Note 12, "Warrants and Derivative Liabilities" and Note 4, “Acquisition and Related Goodwill” for further discussion.  The Company relied on a Black Scholes option pricing method to determine the fair value of the contingent consideration on the date of acquisition and will continue to revalue the fair value of the contingent consideration at each subsequent balance sheet date until the final settlement date, with the change in fair value recorded in the current period operating loss.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001628280-17-011077:notes:89]
[same as prior period, unchanged from 0001628280-17-008331:notes:70]

[0001628280-17-011077:notes:90]
The Company recorded income tax benefits of $0.2 million and $0.1 million in the three and six months ended September 30, 2017.  The Company recorded income tax expenses of $0.8 million and $1.1 million in the three and six months ended September 30, 2016, respectively.

[0001628280-17-011077:notes:91]
As a result of purchase accounting for the acquired intangible assets in the ITC acquisition, the Company recorded a deferred tax liability of $1.1 million for the difference in book and tax basis.  As a result, the Company was able to benefit additional deferred tax assets and therefore released a corresponding valuation allowance of $1.1 million during the three months ended September 30, 2017.  Goodwill recognized in the acquisition is not deductible for tax purposes.

[0001628280-17-011077:notes:92]
Section 382 of the U.S. Internal Revenue Code of 1986, as amended (the “IRC”), provides limits on the extent to which a corporation that has undergone an ownership change (as defined in the IRC) can utilize any net operating loss ("NOL") and general business tax credit carryforwards it may have. The Company conducted a study as a result of the Company's May 2017 equity offering to determine whether Section 382 could limit the use of its carryforwards in this manner.  After completing this study, the Company has concluded that the limitation will not have a material impact on its ability to utilize its NOL carryforwards.  If there were material ownership changes subsequent to the study, such changes could limit the Company's ability to utilize its NOL carryforwards. The Company increased its NOL’s by $0.3 million due to acquired losses in the three months ended September 30, 2017 from ITC. Utilization of these losses by the Company will need further evaluation and may be subject to annual limitations under Section 382.

[0001628280-17-011077:notes:93]
Accounting for income taxes requires a two-step approach to recognizing and measuring uncertain tax positions.  The first step is to evaluate the tax position for recognition by determining if, based on the technical merits, it is more likely than not the position will be sustained upon audit, including resolution of related appeals or litigation processes, if any.  The second step is to measure the tax benefit as the largest amount that is more than 50% likely to be realized upon ultimate settlement.  The Company re-evaluates these uncertain tax positions on a quarterly basis.  The evaluation is based on factors including, but not limited to, changes in facts or circumstances, changes in tax law, effectively settled issues under audit and new audit activity.  Any changes in these factors could result in the recognition of a tax benefit or an additional charge to the tax provision.  The Company did not identify any uncertain tax positions in the six months ended September 30, 2017 and did not have any gross unrecognized tax benefits as of March 31, 2017.


## us-gaap:InventoryDisclosureTextBlock

[0001628280-17-011077:notes:94]
[same as prior period, unchanged from 0001628280-17-008331:notes:73]

[0001628280-17-011077:notes:95]
Inventory at September 30, 2017 and March 31, 2017 consisted of the following (in thousands):

[0001628280-17-011077:notes:96]
|  | September 30, 2017 |  | March 31, 2017 |
| Raw materials | $ | 5,776 |  |  | $ | 4,263 |  |
| Work-in-process | 1,010 |  |  | 426 |  |
| Finished goods | 6,543 |  |  | 8,016 |  |
| Deferred program costs | 2,654 |  |  | 4,757 |  |
| Net inventory | $ | 15,983 |  |  | $ | 17,462 |  |

[0001628280-17-011077:notes:97]
The Company recorded inventory write-downs of $0.1 million and $0.4 million for the three and six months ended September 30, 2017.  The Company recorded inventory write-downs of $0.4 million and $0.7 million for the three and six months ended September 30, 2016.  These write downs were based on evaluating its inventory on hand for excess quantities and obsolescence.

[0001628280-17-011077:notes:98]
Deferred program costs as of September 30, 2017 and March 31, 2017 primarily represent costs incurred on programs accounted for under contract accounting where the Company needs to complete development milestones before revenue and costs will be recognized.


## us-gaap:LoansNotesTradeAndOtherReceivablesDisclosureTextBlock

[0001628280-17-011077:notes:99]
[same as prior period, unchanged from 0001628280-17-008331:notes:78]

[0001628280-17-011077:notes:100]
Accounts receivable at September 30, 2017 and March 31, 2017 consisted of the following (in thousands):

[0001628280-17-011077:notes:101]
|  | September 30, 2017 |  | March 31, 2017 |
| Accounts receivable (billed) | $ | 7,620 |  |  | $ | 7,436 |  |
| Accounts receivable (unbilled) | 627 |  |  | 574 |  |
| Less: Allowance for doubtful accounts | (54 | ) |  | (54 | ) |
| Accounts receivable, net | $ | 8,193 |  |  | $ | 7,956 |  |


## us-gaap:NewAccountingPronouncementsAndChangesInAccountingPrinciplesTextBlock

[0001628280-17-011077:notes:102]
Recent Accounting Pronouncements

[0001628280-17-011077:notes:103]
In May 2014, the Financial Accounting Standards Board (“FASB”) and the International Accounting Standards Board ("IASB") issued, ASU 2014-09, Revenue from Contracts with Customers (Topic 606). The guidance substantially converges final standards on revenue recognition between the FASB and IASB providing a framework on addressing revenue recognition issues and, upon its effective date, replaces almost all existing revenue recognition guidance, including industry-specific guidance, in current U.S. generally accepted accounting principles. The FASB has subsequently issued the following amendments to ASU 2014-09 which are all effective for annual reporting periods beginning after December 15, 2017.

[0001628280-17-011077:notes:104]
| • | In March 2016, the FASB issued ASU No. 2016-08, Revenue from Contracts with Customers (Topic 606): Principal versus Agent Considerations, which clarifies the implementation guidance on principal versus agent considerations. |

[0001628280-17-011077:notes:105]
| • | In April 2016, the FASB issued ASU No. 2016-10, Revenue from Contracts with Customers (Topic 606): Identifying Performance Obligations and Licensing, which clarifies certain aspects of identifying performance obligations and licensing implementation guidance. |

[0001628280-17-011077:notes:106]
| • | In May 2016, the FASB issued ASU No. 2016-12, Revenue from Contracts with Customers (Topic 606): Narrow- Scope Improvements and Practical Expedients related to disclosures of remaining performance obligations, as well as other amendments to guidance on collectability, non-cash consideration and the presentation of sales and other similar taxes collected from customers. |

[0001628280-17-011077:notes:107]
| • | In December 2016, the FASB issued ASU No. 2016-20, Technical Corrections and Improvements to Topic 606, Revenue from Contracts with Customers, which amends certain narrow aspects of the guidance issued in ASU 2014-09 including guidance related to the disclosure of remaining performance obligations and prior-period performance obligations, as well as other amendments to the guidance on loan guarantee fees, contract costs, refund liabilities, advertising costs and the clarification of certain examples. |

[0001628280-17-011077:notes:108]
The Company is currently evaluating the provisions of ASU 2014-09 and its amendments, and assessing the impact the adoption of this guidance will have on its financial position, results of operations and disclosures.  This process has included analyzing the current contract portfolio, comparing the Company's current contract policies and accounting to the requirements of the new standard and identifying the differences.  The Company anticipates the adoption of this guidance will result in certain changes in the identification of deliverables in its contracts and allocation of transaction price.  The timing of revenue recognition could also be different than under the current guidance.  These multiple element contracts are primarily entered into under the grid business unit.  Additionally, this guidance could lead to recognizing certain revenue transactions sooner than in the past on certain contracts, as the Company will need to estimate the revenue it will be entitled to upon contract completion, and later on other contracts, due to lack of an enforceable right to payment for performance obligations satisfied over time.  The Company will continue to assess its contracts for any other impacts that may result.  During the second half of fiscal 2017 the Company plans to assess its current revenue controls, and identify and implement any changes that may be necessary to comply with its new revenue policies and the provisions of ASU 2014-09, which will be in place as of April 1, 2018.

[0001628280-17-011077:notes:109]
The Company is required to adopt the new standards in the first quarter of fiscal 2018 and expects to do so retrospectively with the cumulative effect of initially applying the guidance recognized at the date of initial application (the modified retrospective transition method). The Company is still evaluating the final impact of this adoption method on its consolidated financial statements.

[0001628280-17-011077:notes:110]
In January 2016, the FASB issued ASU 2016-01, Financial Instruments-Overall (Subtopic 825-10): Recognition and Measurement of Financial Assets and Financial Liabilities.  The amendments in ASU 2016-01 will enhance the reporting model for financial instruments to provide users of financial statements with more decision-useful information. This ASU is effective for annual reporting periods beginning after December 15, 2017, and interim periods within those fiscal years.  The Company is currently evaluating the impact, if any, the adoption of ASU 2016-01 may have on its consolidated financial statements.

[0001628280-17-011077:notes:111]
In February 2016, the FASB issued ASU 2016-02, Leases (Topic 842). The guidance in this ASU supersedes the leasing guidance in Topic 840, Leases. Under the new guidance, lessees are required to recognize lease assets and lease liabilities on the balance sheet for all leases with terms longer than 12 months. Leases will be classified as either finance or operating, with classification affecting the pattern of expense recognition in the income statement. This ASU is effective for fiscal years beginning after December 15, 2019, including interim periods within those fiscal years. A modified retrospective transition approach is required for lessees for capital and operating leases existing at, or entered into after, the beginning of the earliest comparative period presented in the financial statements, with certain practical expedients available. The Company is currently evaluating the effects adoption of this guidance will have on its consolidated financial statements.

[0001628280-17-011077:notes:112]
In June 2016, the FASB issued ASU 2016-13, Financial Instruments-Credit Losses (Topic 326): Measurement of Credit Losses on Financial Instruments.  The amendments in ASU 2016-13 will provide more decision useful information about the expected credit losses on financial instruments and other commitments to extend credit held by a reporting entity at each reporting date. The ASU is effective for annual reporting periods beginning after December 15, 2019, including interim periods within that year.  The Company is currently evaluating the impact, if any, the adoption of ASU 2016-13 may have on its consolidated financial statements.

[0001628280-17-011077:notes:113]
In 2016, the FASB issued the following two ASU's on Statement of Cash Flows (Topic 230).  Both amendments are effective for annual reporting periods beginning after December 15, 2017, including interim periods within that year.

[0001628280-17-011077:notes:114]
| • | In August 2016, the FASB issued ASU 2016-15, Statement of Cash Flows (Topic 230): Classification of Certain Cash Receipts and Cash Payments. The amendments in ASU 2016-15 will provide more guidance towards the classification of multiple different types of cash flows in order to reduce the diversity in reporting across entities. |

[0001628280-17-011077:notes:115]
| • | In November 2016, the FASB issued ASU 2016-18, Statement of Cash Flows (Topic 230): Restricted Cash. The amendments in ASU 2016-18 will explain the change during the period in the total of cash, cash equivalents, and amounts generally described as restricted cash or restricted cash equivalents. Therefore, amounts generally described as restricted cash and restricted cash equivalents should be included with cash and cash equivalents when reconciling the beginning-of-period and end-of-period total amounts shown on the statement of cash flows. |

[0001628280-17-011077:notes:116]
The Company is currently evaluating the impact, if any, the adoption of ASU 2016-15 and ASU 2016-18 may have on its consolidated financial statements.

[0001628280-17-011077:notes:117]
In October 2016, the FASB issued ASU 2016-16, Income Taxes (Topic 740): Intra-Entity Transfers of Assets Other Than Inventory.  The amendments in ASU 2016-16 will improve the accounting for the income tax consequences of intra-entity transfers of assets other than inventory. The ASU is effective for annual reporting periods beginning after December 15, 2017, including interim periods within that year.  The Company is currently evaluating the impact, if any, the adoption of ASU 2016-16 may have on its consolidated financial statements.

[0001628280-17-011077:notes:118]
In January 2017, the FASB issued ASU 2017-01, Business Combinations.  The amendments in ASU 2017-01 will clarify the definition of a business with the objective of adding guidance to assist entities with evaluating whether transactions should be accounted for as acquisitions (or disposals) of assets or businesses. The ASU is effective for annual reporting periods beginning after December 15, 2017, including interim periods within those periods.  The Company adopted ASU 2017-01 effective September 30, 2017, following the Acquisition of ITC.  The Company considered these amendments in its decision to record the combination of the entities as an acquisition of a business.  See Note 4, "Acquisition and Related Goodwill", for further details.  These impacts have been included in the consolidated financial statements.

[0001628280-17-011077:notes:119]
In January 2017, the FASB issued ASU 2017-03, Accounting Changes and Error Corrections (Topic 250) and Investments - Equity Method and Joint Ventures.  The amendments in ASU 2017-03 provide additional detail surrounding disclosures required related to adoption of new pronouncements. The ASU is effective for the periods of each related pronouncement.  The Company is currently evaluating the impact the adoption of ASU 2017-03 may have on its consolidated financial statements.

[0001628280-17-011077:notes:120]
In January 2017, the FASB issued ASU 2017-04, Intangibles—Goodwill and Other (Topic 350): Simplifying the Test for Goodwill Impairment.  The amendments in ASU 2017-04 eliminated the prior requirement to perform procedures to determine the fair value at the impairment testing date of an entity's assets and liabilities (including unrecognized assets and liabilities) following the procedure that would be required in determining the fair value of assets acquired and liabilities assumed in a business combination.  Under the new guidelines an entity should perform its annual, or interim, goodwill impairment test by comparing the fair value of a reporting unit with its carrying amount. An entity should recognize an impairment charge for the amount by which the carrying amount exceeds the reporting unit’s fair value.  The ASU is effective for annual reporting periods beginning after December 15, 2019.  Early adoption is permitted for interim or annual goodwill impairment tests performed on testing dates after January 1, 2017.  Following the Acquisition of ITC, the Company performed an analysis and determined that the transaction included a portion of goodwill.  The Company has accounted for that value on its balance sheet as of September 30, 2017.  See Note 4, "Acquisition and Related Goodwill" for further details.  The Company adopted ASU 2017-04 effective September 30, 2017, and determined there were no triggering events requiring further impairment analysis at this time. The Company expects to perform its annual impairment test during the fourth quarter of fiscal 2017.

[0001628280-17-011077:notes:121]
In February 2017, the FASB issued ASU 2017-05, Other Income - Gains and Losses from the Derecognition of Non-financial Assets (Subtopic 610-20).  The amendments in ASU 2017-05 clarify the scope of Subtopic 610-20, Other Income-Gains and Losses from the Derecognition of Non-financial Assets, and to add guidance for partial sales of non-financial assets. Subtopic 610-20, which was issued in May 2014 as a part of Accounting Standards Update No. 2014-09, Revenue from Contracts with Customers (Topic 606), provides guidance for recognizing gains and losses from the transfer of non-financial assets in contracts with non-customers.  The Company is currently evaluating the impact the adoption of ASU 2017-05 may have on its consolidated financial statements.

[0001628280-17-011077:notes:122]
In May 2017, the FASB issued ASU 2017-09, Compensation - Stock Compensation (Subtopic 718) Scope of Modification Accounting.  The amendments in ASU 2017-09 provide clarity and reduce both (1) diversity in practice and (2) cost and complexity when applying the guidance in Topic 718, Compensation—Stock Compensation, to a change to the terms or conditions of a share-based payment award.  The ASU is effective for annual reporting periods beginning after December 15, 2017, including interim periods within those periods. The Company is currently evaluating the impact the adoption of ASU 2017-09 may have on its consolidated financial statements.

[0001628280-17-011077:notes:123]
In July 2017, the FASB issued ASU 2017-11, Earnings per Share (Topic 260), Distinguishing Liabilities from Equity (Topic   480), and Derivatives and Hedging (Topic 815).  The amendments in ASU 2017-11 provide guidance for freestanding equity-linked financial instruments, such as warrants and conversion options in convertible debt or preferred stock, and should no longer be accounted for as a derivative liability at fair value as a result of the existence of a down round feature.  The ASU is effective for annual reporting periods beginning after December 15, 2018, including interim periods within those periods. The Company is currently evaluating the impact the adoption of ASU 2017-11 may have on its consolidated financial statements.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0001628280-17-011077:notes:124]
[same as prior period, unchanged from 0001628280-17-008331:notes:101]

[0001628280-17-011077:notes:125]
[same as prior period, unchanged from 0001628280-17-008331:notes:102]

[0001628280-17-011077:notes:126]
[same as prior period, unchanged from 0001628280-17-008331:notes:103]

[0001628280-17-011077:notes:127]
[same as prior period, unchanged from 0001628280-17-008331:notes:104]

[0001628280-17-011077:notes:128]
The Company has experienced recurring operating losses and as of September 30, 2017, the Company had an accumulated deficit of $978.1 million. In addition, the Company has experienced recurring negative operating cash flows.  At September 30, 2017, the Company had cash and cash equivalents of $30.3 million, with no outstanding debt. Cash used in operations for the six months ended September 30, 2017 was $13.5 million.

[0001628280-17-011077:notes:129]
From April 1, 2011 through the date of this filing, the Company has reduced its global workforce substantially, including a restructuring action announced on April 4, 2017 which led to a $1.3 million restructuring charge in the six months ended September 30, 2017.  See Note 15 "Restructuring" for further discussion of this action.  The Company has taken actions to consolidate certain business operations to reduce facility costs.  As of September 30, 2017, the Company had a global workforce of 321 persons.  The Company plans to closely monitor its expenses and, if required, expects to further reduce operating costs and capital spending to enhance liquidity.

[0001628280-17-011077:notes:130]
Over the last several years, the Company has entered into equity financing arrangements in order to enhance liquidity.  Since April 1, 2012, the Company has generated aggregate cash flows from financing activities of $85.1 million.  Included in this amount are proceeds of approximately $17.0 million after deducting underwriting discounts and commissions and offering expenses payable by the Company, from the Company's equity offering completed on May 10, 2017, which includes the subsequent exercise by the underwriters of their option in full to purchase additional shares.  The Company terminated its At Market Issuance Sales Agreement ("ATM") with FBR Capital Markets & Co. in conjunction with this equity offering.  See Note 13 “Stockholder's Equity” for further discussion of these financing arrangements.

[0001628280-17-011077:notes:131]
[same as prior period, unchanged from 0001628280-17-008331:notes:108]

[0001628280-17-011077:notes:132]
The Company believes that based on the information presented above and its quarterly management assessment, it has sufficient liquidity to fund its operations and capital expenditures for the next twelve months following the issuance of the financial statements for the six months ended September 30, 2017. The Company’s liquidity is highly dependent on its ability to increase revenues, its ability to control its operating costs, and its ability to raise additional capital, if necessary. There can be no assurance that the Company will be able to continue to raise additional capital from other sources or execute on any other means of improving liquidity described above.


## us-gaap:PropertyPlantAndEquipmentDisclosureTextBlock

[0001628280-17-011077:notes:133]
[same as prior period, unchanged from 0001628280-17-008331:notes:110]

[0001628280-17-011077:notes:134]
The cost and accumulated depreciation of property and equipment at September 30, 2017 and March 31, 2017 are as follows (in thousands):

[0001628280-17-011077:notes:135]
|  | September 30, 2017 |  | March 31, 2017 |
| Land | $ | 3,643 |  |  | $ | 3,643 |  |
| Construction in progress - equipment | 606 |  |  | 601 |  |
| Buildings | 34,549 |  |  | 34,549 |  |
| Equipment and software | 73,798 |  |  | 73,445 |  |
| Furniture and fixtures | 1,154 |  |  | 1,201 |  |
| Leasehold improvements | 1,912 |  |  | 2,442 |  |
| Property, plant and equipment, gross | 115,662 |  |  | 115,881 |  |
| Less accumulated depreciation | (79,224 | ) |  | (72,443 | ) |
| Property, plant and equipment, net | $ | 36,438 |  |  | $ | 43,438 |  |

[0001628280-17-011077:notes:136]
Depreciation expense was $3.2 million and $7.5 million for the three and six months ended September 30, 2017.  Depreciation expense was $1.7 million and $3.5 million for the three and six months ended September 30, 2016.  Included in depreciation expense for the three and six months ended September 30, 2017 is $1.6 million and $4.1 million, respectively, of accelerated depreciation recorded to cost of revenues related to revised estimates of the remaining useful lives of certain pieces of manufacturing equipment.


## us-gaap:ReconciliationOfAssetsFromSegmentToConsolidatedTextBlock

[0001628280-17-011077:notes:137]
Total assets for the two business segments as of September 30, 2017 and March 31, 2017 are as follows (in thousands):

[0001628280-17-011077:notes:138]
|  | September 30, 2017 |  | March 31, 2017 |
| Wind | $ | 17,328 |  |  | $ | 18,346 |  |
| Grid | 30,052 |  |  | 31,060 |  |
| Corporate assets | 53,168 |  |  | 50,838 |  |
| Total | $ | 100,548 |  |  | $ | 100,244 |  |


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001628280-17-011077:notes:139]
[same as prior period, unchanged from 0001628280-17-008331:notes:116]

[0001628280-17-011077:notes:140]
The Company accounts for charges resulting from operational restructuring actions in accordance with ASC Topic 420, Exit or Disposal Cost Obligations (“ASC 420”) and ASC Topic 712, Compensation—Nonretirement Postemployment Benefits (“ASC 712”). In accounting for these obligations, the Company is required to make assumptions related to the amounts of employee severance, benefits, and related costs and the time period over which leased facilities will remain vacant, sublease terms, sublease rates and discount rates. Estimates and assumptions are based on the best information available at the time the obligation arises. These estimates are reviewed and revised as facts and circumstances dictate; changes in these estimates could have a material effect on the amount accrued on the consolidated balance sheet.

[0001628280-17-011077:notes:141]
On April 3, 2017, the Board of Directors approved a plan to reduce the Company’s global workforce by approximately 8%, effective April 4, 2017.  The purpose of the workforce reduction was to reduce operating expenses to better align with the Company’s current revenues. Included in the $1.3 million severance pay, charged to operations in the six months ended September 30, 2017, is $0.5 million of severance pay for one of the Company's former executive officers pursuant to the terms of a severance agreement dated June 30, 2017.  Under the terms of the severance agreement, the Company's former executive officer is entitled to 18 months of his base salary, which is expected to be paid by December 31, 2018. From and after January 1, 2018, the Company, at its discretion, may settle any remaining unpaid cash severance owed to its former executive officer through the issuance of a number of immediately vested shares of the Company’s common stock, determined by multiplying the remaining unpaid cash severance owed by 120%, and then dividing by the closing stock price per share of the Company's common stock as of the last business day prior to the issuance of the shares.

[0001628280-17-011077:notes:142]
[same as prior period, unchanged from 0001628280-17-008331:notes:119]

[0001628280-17-011077:notes:143]
The following table presents restructuring charges and cash payments for the six months ended September 30, 2017 (in thousands):

[0001628280-17-011077:notes:144]
|  | Severance pay |
|  | and benefits |
| Accrued restructuring balance at April 1, 2017 | $ | — |  |
| Charges to operations | 1,328 |  |
| Cash payments | (746 | ) |
| Accrued restructuring balance at September 30, 2017 | $ | 582 |  |

[0001628280-17-011077:notes:145]
All restructuring charges discussed above are included within restructuring in the Company’s unaudited condensed consolidated statements of operations. The Company includes $0.5 million of accrued restructuring within accounts payable and accrued expenses and the remaining $0.1 million long term portion is included within other liabilities in the Company's unaudited condensed consolidated balance sheets.


## us-gaap:ScheduleOfRevenueByMajorCustomersByReportingSegmentsTableTextBlock

[0001628280-17-011077:notes:146]
The following table sets forth customers who represented 10% or more of the Company’s total revenues for the three and six months ended September 30, 2017 and 2016:

[0001628280-17-011077:notes:147]
|  | Three months ended September 30, |  | Six months ended September 30, |
|  | 2017 |  | 2016 |  | 2017 |  | 2016 |
| INOX Wind Limited | 46 | % |  | 68 | % |  | 35 | % |  | 51 | % |
| U.S. Navy | — | % |  | — | % |  | 16 | % |  | — | % |
| YMC Inc. | 15 | % |  | — | % |  | <10% |  |  | — | % |


## us-gaap:ScheduleOfSegmentReportingInformationBySegmentTextBlock

[0001628280-17-011077:notes:148]
[same as prior period, unchanged from 0001628280-17-008331:notes:125]

[0001628280-17-011077:notes:149]
|  | Three months ended September 30, | Six months ended September 30, |
|  | 2017 |  | 2016 | 2017 |  | 2016 |
| Revenues: |  |  |  |  |  |  |
| Wind | $ | 5,554 |  |  | $ | 12,898 |  | $ | 7,831 |  |  | $ | 18,573 |  |
| Grid | 5,495 |  |  | 5,609 |  | 12,140 |  |  | 13,279 |  |
| Total | $ | 11,049 |  |  | $ | 18,507 |  | $ | 19,971 |  |  | $ | 31,852 |  |

[0001628280-17-011077:notes:150]
|  | Three months ended September 30, |  | Six months ended September 30, |
|  | 2017 |  | 2016 |  | 2017 |  | 2016 |
| Operating loss: |  |  |  |  |  |  |  |
| Wind | $ | (1,440 | ) |  | $ | (1,235 | ) |  | $ | (5,873 | ) |  | $ | (4,264 | ) |
| Grid | (6,100 | ) |  | (5,262 | ) |  | (14,268 | ) |  | (10,577 | ) |
| Unallocated corporate expenses | (265 | ) |  | (653 | ) |  | (2,358 | ) |  | (1,653 | ) |
| Total | $ | (7,805 | ) |  | $ | (7,150 | ) |  | $ | (22,499 | ) |  | $ | (16,494 | ) |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001628280-17-011077:notes:151]
[same as prior period, unchanged from 0001628280-17-008331:notes:128]

[0001628280-17-011077:notes:152]
[same as prior period, unchanged from 0001628280-17-008331:notes:129]

[0001628280-17-011077:notes:153]
[same as prior period, unchanged from 0001628280-17-008331:notes:130]

[0001628280-17-011077:notes:154]
[same as prior period, unchanged from 0001628280-17-008331:notes:131]

[0001628280-17-011077:notes:155]
[same as prior period, unchanged from 0001628280-17-008331:notes:132]

[0001628280-17-011077:notes:156]
Unallocated corporate expenses primarily consist of stock-based compensation expense of $0.5 million and $0.7 million in the three months ended September 30, 2017 and 2016, respectively.  Unallocated corporate expenses primarily consist of stock-based compensation expense of $1.2 million and $1.7 million in the six months ended September 30, 2017 and 2016, respectively.  Additionally, a restructuring charge of $1.3 million is included in the six months ended September 30, 2017, as well as a gain for the change in fair value of the contingent consideration of $0.2 million in the three and six months ended September 30, 2017.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001628280-17-011077:notes:157]
[same as prior period, unchanged from 0001628280-17-008331:notes:134]

[0001628280-17-011077:notes:158]
[same as prior period, unchanged from 0001628280-17-008331:notes:135]

[0001628280-17-011077:notes:159]
On May 5, 2017, the Company entered into an underwriting agreement with Oppenheimer & Co. Inc., as representative of several underwriters named therein, relating to the issuance and sale (the "Offering") of 4.0 million shares of the Company's common stock at a public offering price of $4.00 per share. The net proceeds to the Company from the Offering were approximately $14.7 million, after deducting underwriting discounts and commissions and offering expenses payable by the Company. The Offering closed on May 10, 2017. In addition, the Company granted the underwriters a 30-day option (the “Option”) to purchase up to an additional 600,000 shares of common stock at the public offering price.  On May 24, 2017, the underwriters notified the Company that they had exercised in full, their Option.  The net proceeds to the Company from the Option were approximately $2.3 million, after deducting underwriting discounts and commissions and offering expenses payable by the Company.  The total net proceeds to the Company from the Offering and the Option were approximately $17.0 million, after deducting underwriting discounts and commissions and offering expenses payable by the Company. The Option closed on May 26, 2017.

[0001628280-17-011077:notes:160]
[same as prior period, unchanged from 0001628280-17-008331:notes:137]

[0001628280-17-011077:notes:161]
[same as prior period, unchanged from 0001628280-17-008331:notes:138]

[0001628280-17-011077:notes:162]
[same as prior period, unchanged from 0001628280-17-008331:notes:139]

[0001628280-17-011077:notes:163]
Stock Purchase Agreement

[0001628280-17-011077:notes:164]
On September 25, 2017, the Company entered into the SPA with ITC.  The purchase price was approximately $3.8 million, consisting of 884,890 AMSC Shares and $0.1 million in cash. See Note 4, “Acquisition and Related Goodwill” for further discussion.


## us-gaap:SubsequentEventsTextBlock

[0001628280-17-011077:notes:165]
Subsequent Events

[0001628280-17-011077:notes:166]
The Company has performed an evaluation of subsequent events through the time of filing this Quarterly Report on Form 10-Q with the SEC and has determined that there are no such events to report.
