# AMSC note change history — 0001628280-17-008331 → 0001628280-17-011077


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2017-11-07):
[0001628280-17-011077:note_history:1]
As of September 30, 2017, the Company had $0.2 million of restricted cash included in long-term assets. These amounts included in restricted cash primarily represent deposits to secure letters of credit for various supply contracts. These deposits are held in interest bearing accounts.
  (was, 2017-08-08, similarity 0.8791):
[0001628280-17-008331:note_history:1]
As of June 30, 2017, the Company had $0.1 million of restricted cash included in current assets and $0.2 million of restricted cash included in long-term assets. These amounts included in restricted cash primarily represent deposits to secure letters of credit for various supply contracts. These deposits are held in interest bearing accounts.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2017-11-07):
[0001628280-17-011077:note_history:2]
These unaudited condensed consolidated financial statements of the Company have been prepared on a going concern basis in accordance with United States generally accepted accounting principles (“GAAP”) and the Securities and Exchange Commission’s (“SEC”) instructions to Form 10-Q. The going concern basis of presentation assumes that the Company will continue operations and will be able to realize its assets and discharge its liabilities and commitments in the normal course of business. Certain information and footnote disclosures normally included in the financial statements prepared in accordance with GAAP have been condensed or omitted pursuant to those instructions. The year-end condensed balance sheet data was derived from audited financial statements but does not include all disclosures required by GAAP. The unaudited condensed consolidated financial statements, in the opinion of management, reflect all adjustments (consisting of normal recurring adjustments) necessary for a fair statement of the results for the interim periods ended September 30, 2017 and 2016 and the financial position at September 30, 2017.
  (was, 2017-08-08, similarity 0.9883):
[0001628280-17-008331:note_history:2]
These unaudited condensed consolidated financial statements of the Company have been prepared on a going concern basis in accordance with United States generally accepted accounting principles (“GAAP”) and the Securities and Exchange Commission’s (“SEC”) instructions to Form 10-Q. The going concern basis of presentation assumes that the Company will continue operations and will be able to realize its assets and discharge its liabilities and commitments in the normal course of business. Certain information and footnote disclosures normally included in the financial statements prepared in accordance with GAAP have been condensed or omitted pursuant to those instructions. The year-end condensed balance sheet data was derived from audited financial statements but does not include all disclosures required by GAAP. The unaudited condensed consolidated financial statements, in the opinion of management, reflect all adjustments (consisting of normal recurring adjustments) necessary for a fair statement of the results for the interim periods ended June 30, 2017 and 2016 and the financial position at June 30, 2017.

- changed (2017-11-07):
[0001628280-17-011077:note_history:3]
The Company has experienced recurring operating losses and as of September 30, 2017, the Company had an accumulated deficit of $978.1 million. In addition, the Company has experienced recurring negative operating cash flows.  At September 30, 2017, the Company had cash and cash equivalents of $30.3 million, with no outstanding debt. Cash used in operations for the six months ended September 30, 2017 was $13.5 million.
  (was, 2017-08-08, similarity 0.7282):
[0001628280-17-008331:note_history:3]
The Company has experienced recurring operating losses and as of June 30, 2017, the Company had an accumulated deficit of $970.8 million. In addition, the Company has experienced recurring negative operating cash flows.  At June 30, 2017, the Company had cash and cash equivalents of $37.5 million. Cash used in operations for the three months ended June 30, 2017 was $5.4 million.

- added (2017-11-07):
[0001628280-17-011077:note_history:4]
From April 1, 2011 through the date of this filing, the Company has reduced its global workforce substantially, including a restructuring action announced on April 4, 2017 which led to a $1.3 million restructuring charge in the six months ended September 30, 2017.  See Note 15 "Restructuring" for further discussion of this action.  The Company has taken actions to consolidate certain business operations to reduce facility costs.  As of September 30, 2017, the Company had a global workforce of 321 persons.  The Company plans to closely monitor its expenses and, if required, expects to further reduce operating costs and capital spending to enhance liquidity.

- changed (2017-11-07):
[0001628280-17-011077:note_history:5]
Over the last several years, the Company has entered into equity financing arrangements in order to enhance liquidity.  Since April 1, 2012, the Company has generated aggregate cash flows from financing activities of $85.1 million.  Included in this amount are proceeds of approximately $17.0 million after deducting underwriting discounts and commissions and offering expenses payable by the Company, from the Company's equity offering completed on May 10, 2017, which includes the subsequent exercise by the underwriters of their option in full to purchase additional shares.  The Company terminated its At Market Issuance Sales Agreement ("ATM") with FBR Capital Markets & Co. in conjunction with this equity offering.  See Note 13 “Stockholder's Equity” for further discussion of these financing arrangements.
  (was, 2017-08-08, similarity 0.8378):
[0001628280-17-008331:note_history:5]
Over the last several years, the Company has entered into several debt and equity financing arrangements in order to enhance liquidity.  Since April 1, 2012, the Company has generated aggregate cash flows from financing activities of $85.0 million.  Included in this amount are proceeds of approximately $17.0 million after deducting underwriting discounts and commissions and offering expenses payable by the Company, from the Company's equity offering completed on May 10, 2017, which includes the subsequent exercise by the underwriters of their option in full to purchase additional shares.  The Company terminated its At Market Issuance Sales Agreement ("ATM") with FBR Capital Markets & Co in conjunction with this equity offering.  See Note 12 “Stockholders Equity” for further discussion of these financing arrangements.

- added (2017-11-07):
[0001628280-17-011077:note_history:6]
The Company believes that based on the information presented above and its quarterly management assessment, it has sufficient liquidity to fund its operations and capital expenditures for the next twelve months following the issuance of the financial statements for the six months ended September 30, 2017. The Company’s liquidity is highly dependent on its ability to increase revenues, its ability to control its operating costs, and its ability to raise additional capital, if necessary. There can be no assurance that the Company will be able to continue to raise additional capital from other sources or execute on any other means of improving liquidity described above.

- removed (2017-11-07):
[0001628280-17-008331:note_history:7]
From April 1, 2011 through the date of this filing, the Company has reduced its global workforce substantially, including a restructuring action announced on April 4, 2017 which led to a $1.3 million restructuring charge in the three months ended June 30, 2017.  See Note 13 "Restructuring" for further discussion of this action.  The Company has taken actions to consolidate certain business operations to reduce facility costs.  As of June 30, 2017, the Company had a global workforce of 326 persons.  The Company plans to closely monitor its expenses and, if required, expects to further reduce operating costs and capital spending to enhance liquidity.

- removed (2017-11-07):
[0001628280-17-008331:note_history:8]
The Company believes based on the information presented above, and its quarterly management assessment, that it has sufficient liquidity to fund its operations and capital expenditures for the next twelve months following the issuance of the financial statements for the three months ended June 30, 2017. The Company’s liquidity is highly dependent on its ability to increase revenues, its ability to control its operating costs, and its ability to raise additional capital, if necessary. There can be no assurance that the Company will be able to continue to raise additional capital from other sources or execute on any other means of improving liquidity described above.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2017-11-07):
[0001628280-17-011077:note_history:9]
Hercules received warrants to purchase 13,927 shares of common stock (the “First Warrant”) and 25,641 shares of common stock (the “Second Warrant”) in conjunction with prior term loans that have been repaid in full.  Due to certain adjustment provisions within the warrants, they qualified for liability accounting.  The fair value of the warrants, $0.4 million and $0.2 million, respectively, was recorded upon issuance to debt discount and a warrant liability. In conjunction with the Hercules Second Amendment, the First Warrant and Second Warrant were canceled and replaced with the issuance of a new warrant (the “Hercules Warrant”) to purchase 58,823 shares of common stock at an exercise price of $7.85 per share, subject to certain price-based and other anti-dilution adjustments.  The Hercules Warrant expires on June 30, 2020.  See Note 12, “Warrants and Derivative Liabilities”, for a discussion on the Hercules Warrant and the valuation assumptions used.
  (was, 2017-08-08, similarity 0.9747):
[0001628280-17-008331:note_history:9]
Hercules received warrants to purchase 13,927 shares of common stock (the “First Warrant”) and 25,641 shares of common stock (the “Second Warrant”) in conjunction with prior term loans that have been repaid in full.  Due to certain adjustment provisions within the warrants, they qualified for liability accounting.  The fair value of the warrants, $0.4 million and $0.2 million, respectively, was recorded upon issuance to debt discount and a warrant liability. In conjunction with the Hercules Second Amendment, the First Warrant and Second Warrant were cancelled and replaced with the issuance of a new warrant (the “Hercules Warrant”) to purchase 58,823 shares of common stock at an exercise price of $11.00 per share, subject to adjustment.  The Hercules Warrant expires on June 30, 2020.  See Note 11, “Warrants and Derivative Liabilities”, for a discussion on the Hercules Warrant and the valuation assumptions used.

- added (2017-11-07):
[0001628280-17-011077:note_history:10]
Interest expense on the Term Loans for the three months ended September 30, 2017 and 2016, was less than $0.1 million.  Included in both periods was less than $0.1 million of non-cash interest expense related to the amortization of the debt discount on the respective Term Loans.  Interest expense on the Term Loans for the six months ended September 30, 2017 and 2016, was less than $0.1 million and $0.3 million, respectively.  Included in both periods was less than $0.1 million of non-cash interest expense related to the amortization of debt discount on the respective Term Loans.

- removed (2017-11-07):
[0001628280-17-008331:note_history:11]
During the three months ended June 30, 2016, the Company recorded non-cash interest expense for amortization of the debt discount related to a prior term loan of less than $0.1 million.  Under Term Loan C, the total debt discount, including the Hercules Warrant, end of term fee and legal and origination costs of $0.3 million was amortized into interest expense over the term of the Term Loan C using the effective interest method.  During each of the three months ended June 30, 2017 and 2016, the Company recorded non-cash interest expense for amortization of the debt discount related to the Term Loan C of less than $0.1 million.

- removed (2017-11-07):
[0001628280-17-008331:note_history:12]
Interest expense on the Term Loans for the three months ended June 30, 2017 and 2016, was less than $0.1 million and $0.2 million, respectively, each of which included less than $0.1 million of non-cash interest expense related to the amortization of the debt discount on the respective Term Loans.


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: tag_name, score: 1.0

- changed (2017-11-07):
[0001628280-17-011077:note_history:13]
The Company has performed an evaluation of subsequent events through the time of filing this Quarterly Report on Form 10-Q with the SEC and has determined that there are no such events to report.
  (was, 2017-08-08, similarity 0.9974):
[0001628280-17-008331:note_history:13]
The Company has performed an evaluation of subsequent events through the time of filing this Quarterly Report on Form 10-Q with the SEC, and has determined that there are no such events to report.
