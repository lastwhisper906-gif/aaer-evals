# AMSC MD&A — 0001437749-25-002900


## mdna

[0001437749-25-002900:mdna:1]
[same as prior period, unchanged from 0001437749-24-032618:mdna:1]

[0001437749-25-002900:mdna:2]
[same as prior period, unchanged from 0001437749-24-032618:mdna:2]

[0001437749-25-002900:mdna:3]
[same as prior period, unchanged from 0001437749-24-032618:mdna:3]

[0001437749-25-002900:mdna:4]
[same as prior period, unchanged from 0001437749-24-032618:mdna:4]

[0001437749-25-002900:mdna:5]
[same as prior period, unchanged from 0001437749-24-032618:mdna:5]

[0001437749-25-002900:mdna:6]
[same as prior period, unchanged from 0001437749-24-032618:mdna:6]

[0001437749-25-002900:mdna:7]
We operate our business under two market-facing business segments: Grid and Wind. We believe this market-centric structure enables us to more effectively anticipate and meet the needs of power generation project developers, the Navy's ship protection systems, electric utilities and wind turbine manufacturers.

[0001437749-25-002900:mdna:8]
[same as prior period, unchanged from 0001437749-24-032618:mdna:8]

[0001437749-25-002900:mdna:9]
[same as prior period, unchanged from 0001437749-24-032618:mdna:9]

[0001437749-25-002900:mdna:10]
[same as prior period, unchanged from 0001437749-24-032618:mdna:10]

[0001437749-25-002900:mdna:11]
Changes in macroeconomic conditions arising from various reasons, such as the ongoing wars between Russia and Ukraine and Israel and Hamas, labor force availability, sourcing, material delays and global supply chain disruptions, could have a material adverse effect on our business, financial condition and results of operations.

[0001437749-25-002900:mdna:12]
In February 2023, we completed the process of determining and verifying our eligibility and amount of payroll tax credits known as the Employee Retention Credit (“ERC”) under the CARES Act which Congress enacted as part of the Taxpayer Certainty and Disaster Tax Relief Act of 2020. This resulted in filing certain amended payroll tax forms for eligible quarters in 2020 and 2021, which, in the aggregate, totaled $3.3 million. We recognized a receivable in prepaid expenses and other current assets and a benefit to cost of revenues and operating expenses in the quarter ended March 31, 2023. In the year ended March 31, 2024, we received $3.0 million in payments for the initial claims that were processed. The remaining balance is expected to be received during fiscal 2025.

[0001437749-25-002900:mdna:13]
[same as prior period, unchanged from 0001437749-24-032618:mdna:13]

[0001437749-25-002900:mdna:14]
On August 1, 2024, we entered into a Stock Purchase Agreement (the “Stock Purchase Agreement”) with the selling stockholders named therein. Pursuant to the terms of the Stock Purchase Agreement and concurrently with entering into such agreement, we acquired all of the issued and outstanding shares of Megatran, for aggregate consideration in an amount equal to $61.4 million, as may be adjusted pursuant to the Stock Purchase Agreement (the “Purchase Price”), including a cash payment after closing of $5.0 million, as adjusted pursuant to Sections 5.6(c), (d), and (f) of the Stock Purchase Agreement (the “Additional Cash Purchase Price”). At closing, we paid to Megatran's selling stockholders $25.0 million in cash on hand, and 1,297,600 restricted shares of our common stock. On September 23, 2024, we paid the Additional Cash Purchase Price to the selling stockholders, which was calculated based on the agreed upon formula set forth in the Stock Purchase Agreement, in the amount of $8.3 million which includes the Additional Cash Purchase Price and the make whole payment. Megatran's wholly-owned subsidiary, NWL, Inc. ("NWL"), is a U.S.-based global provider of engineered power conversion solutions for demanding industrial and military applications.  As a result of this transaction, Megatran became a wholly-owned subsidiary and is operated by our Grid business segment.

[0001437749-25-002900:mdna:15]
[same as prior period, unchanged from 0001437749-24-032618:mdna:15]

[0001437749-25-002900:mdna:16]
[same as prior period, unchanged from 0001437749-24-032618:mdna:16]

[0001437749-25-002900:mdna:17]
[same as prior period, unchanged from 0001437749-24-032618:mdna:17]

[0001437749-25-002900:mdna:18]
[same as prior period, unchanged from 0001437749-24-032618:mdna:18]

[0001437749-25-002900:mdna:19]
[same as prior period, unchanged from 0001437749-24-032618:mdna:19]

[0001437749-25-002900:mdna:20]
Three and nine months ended December 31, 2024, compared to the three and nine months ended December 31, 2023

[0001437749-25-002900:mdna:21]
[same as prior period, unchanged from 0001437749-24-032618:mdna:21]

[0001437749-25-002900:mdna:22]
Total revenues increased 56% to $61.4 million for the three months ended December 31, 2024 and total revenues increased 51% to $156.2 million for the nine months ended December 31, 2024, compared to $39.4 million and $103.6 million for the three and nine months ended December 31, 2023, respectively. Our revenues are summarized as follows (in thousands):

[0001437749-25-002900:mdna:23]
|  |  | Three Months Ended December 31, |  |  | Nine Months Ended December 31, |  |
|  |  | 2024 |  |  | 2023 |  |  | 2024 |  |  | 2023 |  |
| Revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Grid |  | $ | 52,306 |  |  | $ | 33,603 |  |  | $ | 131,578 |  |  | $ | 87,854 |  |
| Wind |  |  | 9,097 |  |  |  | 5,750 |  |  |  | 24,585 |  |  |  | 15,757 |  |
| Total |  | $ | 61,403 |  |  | $ | 39,353 |  |  | $ | 156,163 |  |  | $ | 103,611 |  |

[0001437749-25-002900:mdna:24]
Our Grid business segment accounted for 85% and 84% of total revenues for the three and nine months ended December 31, 2024, respectively, compared to 85% for each of the three and nine months ended December 31, 2023. Our Grid business segment revenues increased 56% to $52.3 million in the three months ended December 31, 2024, from $33.6 million in the three months ended December 31, 2023. Our Grid business segment revenues increased 50% to $131.6 million in the nine months ended December 31, 2024, from $87.9 million in the nine months ended December 31, 2023. The increase in the Grid business segment revenues in the three and nine months ended December 31, 2024, compared to the three and nine months ended December 31, 2023 was primarily driven by the acquisition of Megatran and increased shipments of new energy power systems than in the prior year periods.

[0001437749-25-002900:mdna:25]
Our Wind business segment accounted for 15% and 16% of total revenues for the three and nine months ended December 31, 2024, respectively, compared to 15% for each of the three and nine months ended December 31, 2023. Revenues in the Wind business segment increased 58% and 56% to $9.1 million and $24.6 million in the three and nine months ended December 31, 2024, respectively, from $5.8 million and $15.8 million in the three and nine months ended December 31, 2023, respectively. The increase during the three and nine months ended December 31, 2024, compared to the three and nine months ended December 31, 2023, was driven by additional shipments of electrical control systems ("ECS") at increased prices.

[0001437749-25-002900:mdna:26]
[same as prior period, unchanged from 0001437749-24-032618:mdna:26]

[0001437749-25-002900:mdna:27]
Cost of revenues increased by 53% to $45.1 million for the three months ended December 31, 2024, compared to $29.4 million for the three months ended December 31, 2023. Cost of revenues increased by 42% to $112.0 million for the nine months ended December 31, 2024, compared to $78.8 million for the nine months ended December 31, 2023. Gross margin was 27% and 28% for the three and nine months ended December 31, 2024, respectively, compared to 25% and 24% for the three and nine months ended December 31, 2023, respectively. Cost of revenues includes total amortization expense of $0.3 million and $0.4 million in the three and nine months ended December 31, 2024, as a result of the Megatran acquired backlog intangible assets. In addition, a charge of $0.4 million and $0.7 million related to a fair value adjustment of approximately for the step-up basis assigned to acquired inventory to properly reflect the fair value in purchase accounting was charged to cost of revenues in the three and nine months ended December 31, 2024, when the inventory sold. The increase in gross margin in the three and nine months ended December 31, 2024 was due to higher revenues, a favorable product mix and favorable impacts across the business due to pricing increases across our product lines.

[0001437749-25-002900:mdna:28]
[same as prior period, unchanged from 0001437749-24-032618:mdna:28]

[0001437749-25-002900:mdna:29]
[same as prior period, unchanged from 0001437749-24-032618:mdna:29]

[0001437749-25-002900:mdna:30]
Research and development ("R&D") expenses increased 36% and 39% in the three and nine months ended December 31, 2024, respectively, to $3.0 million and $7.9 million from $2.2 million and $5.7 million in the three and nine months ended December 31, 2023, respectively. The increase in the three and nine months ended December 31, 2024 was driven primarily by the addition of Megatran R&D expenses, higher overall compensation expense and additional stock-based compensation expense.

[0001437749-25-002900:mdna:31]
[same as prior period, unchanged from 0001437749-24-032618:mdna:31]

[0001437749-25-002900:mdna:32]
Selling, general and administrative ("SG&A") expenses increased 48% and 31% in the three and nine months ended December 31, 2024, respectively, to $11.6 million and $31.0 million from $7.8 million and $23.6 million in the three and nine months ended December 31, 2023, respectively. The increase in SG&A expense in the three months ended December 31, 2024 was driven primarily by the addition of Megatran SG&A expenses, higher overall compensation expense and additional stock-based compensation expense. The increase in the nine months ended December 31, 2024 was due to the addition of Megatran SG&A expenses, higher overall compensation expense, additional stock-based compensation expense, and higher acquisition costs.

[0001437749-25-002900:mdna:33]
[same as prior period, unchanged from 0001437749-24-032618:mdna:33]

[0001437749-25-002900:mdna:34]
We recorded amortization expense related to our core technology and know-how, customer relationships, and other intangible assets of $0.4 million and $1.3 million in the three and nine months ended December 31, 2024, respectively, and $0.5 million and $1.6 million in the three and nine months ended December 31, 2023, respectively. The decrease in amortization expense is a result of using the economic consumption method as the basis to amortize the acquired customer relationship intangible assets from Northeast Power Systems, Inc. ("NEPSI") and Neeltran.

[0001437749-25-002900:mdna:35]
[same as prior period, unchanged from 0001437749-24-032618:mdna:35]

[0001437749-25-002900:mdna:36]
The change in fair value of our contingent consideration for the earnout payment on the acquisition of NEPSI resulted in a loss of $3.4 million resulting from an increase in fair value in the nine months ended December 31, 2024. During the three months ended September 30, 2024, we issued 300,000 shares of common stock of the Company to the selling stockholders following certification of the achievement of specified earnout revenue objectives. We recorded the above noted changes, compared to losses of $0.9 million and $3.1 million in the three and nine months ended December 31, 2023, respectively. We also recorded a $3.3 million payment relating to the Megatran acquisition, as a payment to settle the remaining obligations after the acquisition. The value of this contingent consideration was de minimis at the Acquisition Date and the resulting change in fair value was recorded in September during the nine months ended December 31, 2024.

[0001437749-25-002900:mdna:37]
[same as prior period, unchanged from 0001437749-24-032618:mdna:38]

[0001437749-25-002900:mdna:38]
[same as prior period, unchanged from 0001437749-24-032618:mdna:39]

[0001437749-25-002900:mdna:39]
|  |  | Three Months Ended December 31, |  |  | Nine Months Ended December 31, |  |
|  |  | 2024 |  |  | 2023 |  |  | 2024 |  |  | 2023 |  |
| Operating income (loss): |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Grid |  | $ | 2,819 |  |  | $ | 268 |  |  | $ | 6,014 |  |  | $ | (2,383 | ) |
| Wind |  |  | 1,362 |  |  |  | 286 |  |  |  | 2,877 |  |  |  | (112 | ) |
| Unallocated corporate expenses |  |  | (2,866 | ) |  |  | (1,992 | ) |  |  | (11,621 | ) |  |  | (6,646 | ) |
| Total |  | $ | 1,315 |  |  | $ | (1,438 | ) |  | $ | (2,730 | ) |  | $ | (9,141 | ) |

[0001437749-25-002900:mdna:40]
Our Grid business segment generated operating income of $2.8 million and $6.0 million in the three and nine months ended December 31, 2024, respectively, compared to operating income of $0.3 million and operating loss of $2.4 million in the three and nine months ended December 31, 2023, respectively. The increase in the Grid business segment operating income in the three and nine months ended December 31, 2024 was due to higher revenues and gross margins in part due to a favorable product mix.

[0001437749-25-002900:mdna:41]
Our Wind business segment generated operating income of $1.4 million and $2.9 million in the three and nine months ended December 31, 2024, respectively, compared to operating income of $0.3 million and operating loss of $0.1 million in the three and nine months ended December 31, 2023, respectively. The improvement in the Wind business segment operating income in the three and nine months ended December 31, 2024 was due to higher revenues and gross margins from increased sales of ECS units.

[0001437749-25-002900:mdna:42]
Unallocated corporate expenses included net losses on contingent consideration of $6.7 million in the nine months ended December 31, 2024, and net losses on contingent consideration of $0.9 million and $3.1 million in the three and nine months ended December 31, 2023, respectively. Additionally, unallocated corporate expenses consisted of stock-based compensation expense of $2.9 million and $4.9 million in the three and nine months ended December 31, 2024, respectively, and $1.1 million and $3.6 million in the three and nine months ended December 31, 2023, respectively.

[0001437749-25-002900:mdna:43]
[same as prior period, unchanged from 0001437749-24-032618:mdna:44]

[0001437749-25-002900:mdna:44]
Interest income, net, was $0.8 million and $2.9 million in the three and nine months ended December 31, 2024, respectively, compared to $0.2 million and $0.5 million in the three and nine months ended December 31, 2023, respectively. The increase in interest income, net, in the three and nine months ended December 31, 2024 was due to higher cash balances.

[0001437749-25-002900:mdna:45]
Other income (expense), net

[0001437749-25-002900:mdna:46]
Other income, net, was $0.3 million and other expense, net was $0.2 million in the three and nine months ended December 31, 2024, respectively, compared to other expense, net of $0.3 million and $0.6 million in the three and nine months ended December 31, 2023, respectively. The decrease in other expense, net, during the three and nine months ended December 31, 2024, compared to the three and nine months ended December 31, 2023, was driven by the impacts of favorable fluctuations in foreign currencies and gain on earnings from NWL Pacific during the periods.

[0001437749-25-002900:mdna:47]
[same as prior period, unchanged from 0001437749-24-032618:mdna:48]

[0001437749-25-002900:mdna:48]
Income tax benefit was $0.1 million and $4.9 million in the three and nine months ended December 31, 2024, respectively. Income tax expense was $0.1 million and $0.3 million in the three and nine months ended December 31, 2023, respectively. The net improvement to income tax benefit for the three and nine months ended December 31, 2024 was a result of the release of the valuation allowance due to the recording of the deferred tax liability from the acquisition of Megatran.

[0001437749-25-002900:mdna:49]
[same as prior period, unchanged from 0001437749-24-032618:mdna:50]

[0001437749-25-002900:mdna:50]
Net income was $2.5 million and $4.8 million in the three and nine months ended December 31, 2024, respectively, compared to net losses of $1.6 million and $9.5 million in the three and nine months ended December 31, 2023, respectively. The improvement in net income was driven primarily by increased revenues and gross margins as well as the release of a partial valuation allowance against the deferred tax liability recorded as a result of the Megatran acquisition.

[0001437749-25-002900:mdna:51]
[same as prior period, unchanged from 0001437749-24-032618:mdna:52]

[0001437749-25-002900:mdna:52]
[same as prior period, unchanged from 0001437749-24-032618:mdna:53]

[0001437749-25-002900:mdna:53]
[same as prior period, unchanged from 0001437749-24-032618:mdna:54]

[0001437749-25-002900:mdna:54]
|  |  | Three Months Ended December 31, |  |  | Nine Months Ended December 31, |  |
|  |  | 2024 |  |  | 2023 |  |  | 2024 |  |  | 2023 |  |
| Net income (loss) |  | $ | 2,465 |  |  | $ | (1,649 | ) |  | $ | 4,828 |  |  | $ | (9,532 | ) |
| Stock-based compensation |  |  | 2,861 |  |  |  | 1,140 |  |  |  | 4,933 |  |  |  | 3,608 |  |
| Acquisition costs |  |  | 15 |  |  |  | — |  |  |  | 1,095 |  |  |  | — |  |
| Amortization of acquisition-related intangibles |  |  | 706 |  |  |  | 538 |  |  |  | 1,727 |  |  |  | 1,620 |  |
| Change in fair value of contingent consideration |  |  | — |  |  |  | 852 |  |  |  | 6,682 |  |  |  | 3,052 |  |
| Non-GAAP net income (loss) |  | $ | 6,047 |  |  | $ | 881 |  |  | $ | 19,265 |  |  | $ | (1,252 | ) |
| Non-GAAP net income (loss) per share - basic |  | $ | 0.16 |  |  | $ | 0.03 |  |  | $ | 0.52 |  |  | $ | (0.04 | ) |
| Non-GAAP net income (loss) per share - diluted |  | $ | 0.16 |  |  | $ | 0.03 |  |  | $ | 0.51 |  |  | $ | (0.04 | ) |
| Weighted average shares outstanding - basic |  |  | 37,661 |  |  |  | 29,092 |  |  |  | 36,766 |  |  |  | 28,728 |  |
| Weighted average shares outstanding - diluted |  |  | 38,463 |  |  |  | 29,428 |  |  |  | 37,457 |  |  |  | 28,728 |  |

[0001437749-25-002900:mdna:55]
We incurred non-GAAP net income of $6.0 million and $19.3 million, or $0.16 and $0.52 per share, for the three and nine months ended December 31, 2024, respectively, compared to a non-GAAP net income of $0.9 million and a non-GAAP net loss of $1.3 million, or $0.03 and $(0.04) per share, for the three and nine months ended December 31, 2023, respectively. The improvement in the non-GAAP net income (loss) for the three and nine months ended December 31, 2024 was due to higher revenues and gross margins.

[0001437749-25-002900:mdna:56]
[same as prior period, unchanged from 0001437749-24-032618:mdna:57]

[0001437749-25-002900:mdna:57]
[same as prior period, unchanged from 0001437749-24-032618:mdna:58]

[0001437749-25-002900:mdna:58]
We have experienced recurring operating losses and, as of December 31, 2024, had an accumulated deficit of $1,061.8 million.

[0001437749-25-002900:mdna:59]
[same as prior period, unchanged from 0001437749-24-032618:mdna:60]

[0001437749-25-002900:mdna:60]
[same as prior period, unchanged from 0001437749-24-032618:mdna:61]

[0001437749-25-002900:mdna:61]
[same as prior period, unchanged from 0001437749-24-032618:mdna:62]

[0001437749-25-002900:mdna:62]
As described above, on August 1, 2024, we acquired all of the issued and outstanding shares of Megatran, for aggregate consideration in an amount equal to $61.4 million (the “Purchase Price”), which consideration amount was subject to various adjustments set forth in the Stock Purchase Agreement (including those described below) and consisted of: (a) (i) $25.0 million, minus (ii) the Indebtedness (as defined in the Stock Purchase Agreement) outstanding as of immediately prior to the closing, minus (iii) Company Expenses (as defined in the Stock Purchase Agreement) (collectively, the “Cash Purchase Price”); (b) a number of restricted shares (rounded up or down to the nearest whole share, as applicable) (the “Company Shares”) of our common stock equal to the quotient obtained by dividing (x) $31.4 million by (y) the closing price per share of Common Stock on the Nasdaq Global Select Market on the last trading day immediately preceding August 1, 2024; and (c) an additional cash payment equal to $5.0 million, as adjusted pursuant to Sections 5.6(c), (d), and (f) of the Stock Purchase Agreement. Megatran is now a wholly-owned subsidiary of the Company and, together with its wholly-owned subsidiaries and affiliates, is operated and reported as a component of its Grid business segment. On September 23, 2024, the Company paid the Additional Cash Purchase Price to the selling stockholders, which was calculated based on the agreed upon formula, in the amount of $8.3 million.

[0001437749-25-002900:mdna:63]
In August 2024, we filed an automatically-effective shelf registration statement on Form S-3 that will expire no later than August 12, 2027 (the “Second Form S-3”). The Second Form S-3 allows us to offer and sell from time-to-time common stock, debt securities, warrants or units comprised of any combination of these securities and allows certain selling stockholders to offer and sell from time-to-time common stock. The Second Form S-3 assisted the Megatran selling stockholders in the resale of their common stock and is intended to provide us flexibility to conduct registered sales of our securities, subject to market conditions, in order to fund our future capital needs. The terms of any future offering under the Second Form S-3 will be established at the time of such offering and will be described in a prospectus supplement filed with the SEC prior to the completion of any such offering.

[0001437749-25-002900:mdna:64]
As of December 31, 2024, we had cash, cash equivalents and restricted cash of $80.0 million, compared to $92.3 million as of March 31, 2024, a decrease of $12.3 million. As of December 31, 2024, we had $3.2 million in cash, cash equivalents, and restricted cash in foreign bank accounts. Our cash, cash equivalents, and restricted cash are summarized as follows (in thousands):

[0001437749-25-002900:mdna:65]
|  |  | December 31, 2024 |  |  | March 31, 2024 |  |
| Cash and cash equivalents |  | $ | 75,203 |  |  | $ | 90,522 |  |
| Restricted cash |  |  | 4,837 |  |  |  | 1,758 |  |
| Total cash, cash equivalents, and restricted cash |  | $ | 80,040 |  |  | $ | 92,280 |  |

[0001437749-25-002900:mdna:66]
For the nine months ended December 31, 2024, net cash provided by operating activities was $22.0 million, compared to cash used in operations of $0.1 million for the nine months ended December 31, 2023. The increase in cash flows provided by operating activities in the nine months ended December 31, 2024 was due primarily to increased net income, decrease in cash spent on accounts payable and accrued expenses, and increased deferred revenue, offset by an increase in accounts receivable, and cash spent on inventory purchases, prepaid expenses, and operating leases.

[0001437749-25-002900:mdna:67]
For the nine months ended December 31, 2024, net cash used in investing activities was $34.1 million, compared to $0.6 million for the nine months ended December 31, 2023. The increase in net cash used in investing activities was primarily due to cash paid for the acquisition of Megatran.

[0001437749-25-002900:mdna:68]
For the nine months ended December 31, 2024, net cash used in financing activities was $0.1 million compared to net cash provided by financing activities of $0.1 million for the nine months ended December 31, 2023. The decrease was due to the repurchase of common stock in connection with employee tax obligations upon the vesting of stock awards, offset by proceeds related to our ESPP.

[0001437749-25-002900:mdna:69]
As of December 31, 2024, we had $3.5 million of restricted cash included in long-term assets and $1.3 million of restricted cash included in current assets. At March 31, 2024, we had $1.3 million of restricted cash included in long-term assets and $0.5 million of restricted cash in current assets. These amounts included in restricted cash primarily represent collateral deposits to secure surety bonds and letters of credit for various customer contracts. These deposits are held in interest bearing accounts.

[0001437749-25-002900:mdna:70]
We are a party to many contractual obligations involving commitments to make payments to third parties. These obligations impact our short-term and long-term liquidity and capital resource needs. Certain contractual obligations are reflected on the condensed consolidated balance sheet as of December 31, 2024, while others are considered future commitments. We have various contractual arrangements, under which we have committed to purchase certain minimum quantities of goods or services on an annual basis. For information regarding our other contractual obligations, refer to Note 15, "Contingent Consideration," Note 16, "Debt," Note 17, "Leases" and Note 18, "Commitments and Contingencies" to our condensed consolidated financial statements included elsewhere in this Quarterly Report on Form 10-Q.

[0001437749-25-002900:mdna:71]
We believe we have sufficient available liquidity to fund our operations and capital expenditures for the next twelve months. We raised $65.2 million, net of offering expenses, through an equity raise in February 2024. In addition, we may seek to raise additional capital, which could be in the form of loans, convertible debt or equity, to fund our operating requirements and capital expenditures. Our liquidity is highly dependent on our ability to increase revenues, control our operating costs, and raise additional capital, if necessary. There can be no assurance that we will be able to raise additional capital on favorable terms or at all or execute on any other means of improving our liquidity as described above.  Additionally, the impact of global sources of instability, including the ongoing wars between Russia and Ukraine and Israel and Hamas, instability of financial institutions and political instability in the United States, on the global financial markets may reduce our ability to raise additional capital, if necessary, which could negatively impact our liquidity. We also continue to closely monitor our expenses and, if required, we intend to reduce our operating and capital spending to enhance liquidity.

[0001437749-25-002900:mdna:72]
Legal Proceedings

[0001437749-25-002900:mdna:73]
[same as prior period, unchanged from 0001437749-24-032618:mdna:74]

[0001437749-25-002900:mdna:74]
[same as prior period, unchanged from 0001437749-24-032618:mdna:75]

[0001437749-25-002900:mdna:75]
In November 2023, the FASB issued ASU 2023-07, Segment Reporting (Topic 280): Improvements to Reportable Segment Disclosures. The amendments in ASU 2023-07 improve the disclosures about a public entity’s reportable segments and address requests from investors for additional, more detailed information about a reportable segment’s expenses. Following the release of ASU 2023-07 in November 2023, the effective date will be annual reporting periods beginning after December 15, 2023. As of December 31, 2024, we are evaluating the impact on our condensed consolidated financial statements.

[0001437749-25-002900:mdna:76]
In December 2023, the FASB issued ASU 2023-09, Income Taxes (Topic 740): Improvements to Income Tax Disclosures. The amendments in ASU 2023-09 address investor requests for more transparency about income tax information through improvements to income tax disclosures primarily related to the rate reconciliation and income taxes paid information. Following the release of ASU 2023-09 in December 2023, the effective date will be annual reporting periods beginning after December 15, 2024. As of December 31, 2024, we are evaluating the impact on our condensed consolidated financial statements.

[0001437749-25-002900:mdna:77]
In March 2024, the FASB issued ASU 2024-02, Codification Improvements—Amendments to Remove References to the Concepts Statements. The amendments in ASU 2024-02 contain amendments to the Codification that remove references to various FASB Concepts Statements. Following the release of ASU 2024-02 in March 2024, the effective date will be annual reporting periods beginning after December 15, 2024. As of December 31, 2024, we are evaluating the impact on our condensed consolidated financial statements.

[0001437749-25-002900:mdna:78]
In November 2024, the FASB issued ASU 2024-03, Income Statement—Reporting Comprehensive Income—Expense Disaggregation Disclosures. The amendments in ASU 2024-03 address investor requests for more disclosure of disaggregated financial reporting information about expenses presented in the income statement. Following the release of ASU 2024-03 in November 2024, the effective date will be annual reporting periods beginning after December 15, 2026. As of December 31, 2024, we are evaluating the impact on our condensed consolidated financial statements.

[0001437749-25-002900:mdna:79]
We do not believe that, outside of those disclosed here, there are any other recently issued accounting pronouncements that will have a material impact on our condensed consolidated financial statements.
