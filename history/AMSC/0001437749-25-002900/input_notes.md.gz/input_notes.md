# AMSC notes — 0001437749-25-002900


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0001437749-25-002900:notes:1]
[same as prior period, unchanged from 0001437749-24-032618:notes:1]

[0001437749-25-002900:notes:2]
[same as prior period, unchanged from 0001437749-24-032618:notes:2]

[0001437749-25-002900:notes:3]
[same as prior period, unchanged from 0001437749-24-032618:notes:3]

[0001437749-25-002900:notes:4]
These unaudited condensed consolidated financial statements of the Company have been prepared on a going concern basis in accordance with United States generally accepted accounting principles (“GAAP”) and the Securities and Exchange Commission’s (“SEC”) instructions to Form 10-Q. Certain prior period amounts were reclassified to conform to the presentation in the current period. All significant intercompany accounts and transactions are eliminated in consolidation. Investments in entities in which we do not have a controlling interest are accounted for under the equity method of accounting. The going concern basis of presentation assumes that the Company will continue operations and will be able to realize its assets and discharge its liabilities and commitments in the normal course of business. Certain information and footnote disclosures normally included in the condensed consolidated financial statements prepared in accordance with GAAP have been omitted pursuant to those instructions. The year-end balance sheet data was derived from audited financial statements but does not include all disclosures required by GAAP. The unaudited condensed consolidated financial statements, in the opinion of management, reflect all adjustments (consisting of normal recurring adjustments) necessary for a fair statement of the results for the interim periods ended  December 31, 2024 and 2023 and the financial position at  December 31, 2024; however, these results are not necessarily indicative of results which  may be expected for the full year. The interim condensed consolidated financial statements, and notes thereto, should be read in conjunction with the audited condensed consolidated financial statements for the year ended  March 31, 2024, and notes thereto, included in the Company’s Annual Report on Form 10-K for the year ended  March 31, 2024 filed with the SEC on  May 29, 2024.

[0001437749-25-002900:notes:5]
[same as prior period, unchanged from 0001437749-24-032618:notes:5]

[0001437749-25-002900:notes:6]
The Company has historically experienced recurring operating losses and as of  December 31, 2024, the Company had an accumulated deficit of $1,061.8 million. In addition, the Company has historically experienced recurring negative operating cash flows. At  December 31, 2024, the Company had cash and cash equivalents of $75.2 million. Cash provided by operations for the nine months ended  December 31, 2024 was $22.0 million.

[0001437749-25-002900:notes:7]
In  January 2024, the Company filed a shelf registration statement on Form S-3 that will expire three years from the date on which it was declared effective,  March 15, 2027 (the “First Form S-3”). The First Form S-3 allows the Company to offer and sell from time-to-time up to $250 million of common stock, debt securities, warrants or units comprised of any combination of these securities, with $250 million available for future offerings as of  December 31, 2024. The First Form S-3 is intended to provide the Company flexibility to conduct registered sales of its securities, subject to market conditions, in order to fund its future capital needs. The terms of any future offering under the First Form S-3 will be established at the time of such offering and will be described in a prospectus supplement filed with the SEC prior to the completion of any such offering.

[0001437749-25-002900:notes:8]
[same as prior period, unchanged from 0001437749-24-032618:notes:8]

[0001437749-25-002900:notes:9]
On  August 1, 2024 (the "Acquisition Date"), the Company entered into a Stock Purchase Agreement (the “Stock Purchase Agreement”) with the selling stockholders named therein. Pursuant to the terms of the Stock Purchase Agreement and concurrently with entering into such agreement, the Company acquired all of the issued and outstanding shares of Megatran Industries, Inc. ("Megatran") (the "Acquisition"), for aggregate consideration in an amount equal to $61.4 million (the “Purchase Price”), which consideration amount was subject to various adjustments set forth in the Stock Purchase Agreement (including those described below) and consisted of: (a) (i) $25.0 million, minus (ii) the Indebtedness (as defined in the Stock Purchase Agreement) outstanding as of immediately prior to the closing, minus (iii) Company Expenses (as defined in the Stock Purchase Agreement) (collectively, the “Cash Purchase Price”); (b) a number of restricted shares (rounded up or down to the nearest whole share, as applicable) (the “Company Shares”) of the Company’s common stock, $.01 par value per share (“Common Stock”) equal to the quotient obtained by dividing (x) $31.4 million (the “Share Purchase Price”) by (y) the closing price per share of Common Stock on the Nasdaq Global Select Market on the last trading day immediately preceding the Acquisition Date; and (c) an additional cash payment equal to $5.0 million, as adjusted pursuant to Sections 5.6(c), (d), and (f) of the Stock Purchase Agreement (the “Additional Cash Purchase Price”). Megatran is now a wholly-owned subsidiary of the Company and, together with its wholly-owned subsidiaries and affiliates, is operated and reported as a component of its Grid business segment. On  September 23, 2024, the Company paid $3.3 million to the selling stockholders, which was calculated based on the agreed upon formula set forth in the Stock Purchase Agreement. This amount is reflected as the change in fair value of this contingent consideration in the nine months ended  December 31, 2024. As of  December 31, 2024, there are no remaining obligations to the selling stockholders of Megatran.

[0001437749-25-002900:notes:10]
In  August 2024, the Company filed an automatically-effective shelf registration statement on Form S-3 that will expire no later than  August 12, 2027 (the “Second Form S-3”). The Second Form S-3 allows the Company to offer and sell from time-to-time unspecified amounts of common stock, debt securities, warrants or units comprised of any combination of these securities and allows certain selling stockholders to offer and sell from time-to-time common stock. The Second Form S-3 assisted the Megatran selling stockholders in the resale of their common stock and is intended to provide the Company flexibility to conduct registered sales of its securities, subject to market conditions, in order to fund its future capital needs. The terms of any future offering under the Second Form S-3 will be established at the time of such offering and will be described in a prospectus supplement filed with the SEC prior to the completion of any such offering.

[0001437749-25-002900:notes:11]
Changes in macroeconomic conditions arising from various reasons, such as the ongoing wars between Russia and Ukraine and Israel and Hamas, labor force availability, sourcing, material delays and global supply chain disruptions could have a material adverse effect on the Company’s business, financial condition and results of operations.

[0001437749-25-002900:notes:12]
The Company believes that based on the information presented above and its quarterly management assessment, it has sufficient liquidity to fund its operations and capital expenditures for the next twelve months following the issuance of the unaudited condensed consolidated financial statements for the nine months ended  December 31, 2024. The Company’s liquidity is highly dependent on its ability to increase revenues, its ability to control its operating costs, and its ability to raise additional capital, if necessary. The impact of global sources of instability, including the wars between Russia and Ukraine and Israel and Hamas, on the global financing markets  may reduce the Company's ability to raise additional capital, if necessary, which could negatively impact the Company's liquidity.  There can be no assurance that the Company will be able to continue to raise additional capital, on favorable terms or at all, from other sources or execute on any other means of improving liquidity described above.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001437749-25-002900:notes:13]
[same as prior period, unchanged from 0001437749-24-032618:notes:13]

[0001437749-25-002900:notes:14]
[same as prior period, unchanged from 0001437749-24-032618:notes:14]

[0001437749-25-002900:notes:15]
[same as prior period, unchanged from 0001437749-24-032618:notes:15]

[0001437749-25-002900:notes:16]
Pursuant to the Stock Purchase Agreement, the Company acquired all of the issued and outstanding shares of Megatran, for aggregate consideration in an amount equal to $61.4 million, which consideration amount was subject to various adjustments set forth in the Stock Purchase Agreement (including those described below) and consisted of: (a) (i) $25.0 million, minus (ii) the Indebtedness (as defined in the Stock Purchase Agreement) outstanding as of immediately prior to the closing, minus (iii) Company Expenses (as defined in the Stock Purchase Agreement); (b) a number of restricted shares (rounded up or down to the nearest whole share, as applicable) of Common Stock equal to the quotient obtained by dividing (x) $31.4 million by (y) the closing price per share of Common Stock on the Nasdaq Global Select Market on the last trading day immediately preceding the Acquisition Date; and (c) an additional cash payment equal to $5.0 million, as adjusted pursuant to Sections 5.6(c), (d), and (f) of the Stock Purchase Agreement. Megatran is now a wholly-owned subsidiary of the Company and, together with its wholly-owned subsidiaries and affiliates, is operated and reported as a component of its Grid business segment. On  September 23, 2024, the Company paid $3.3 million to the selling stockholders, which was calculated based on the agreed upon formula set forth in the Stock Purchase Agreement. This amount is reflected as the change in fair value of this contingent consideration in the nine months ended  December 31, 2024. As of  December 31, 2024, there are no remaining obligations to the selling stockholders of Megatran.

[0001437749-25-002900:notes:17]
[same as prior period, unchanged from 0001437749-24-032618:notes:17]

[0001437749-25-002900:notes:18]
[same as prior period, unchanged from 0001437749-24-032618:notes:18]

[0001437749-25-002900:notes:19]
[same as prior period, unchanged from 0001437749-24-032618:notes:19]

[0001437749-25-002900:notes:20]
At the Acquisition Date, in addition to the $30.0 million cash, the Company valued the Company’s common stock, using $24.16 per share, which was the closing price on the day prior to the day that the Company acquired Megatran. Acquisition costs of less than $0.1 million and $1.1 million were included in selling, general and administrative ("SG&A") for the three and nine months ended  December 31, 2024, respectively.

[0001437749-25-002900:notes:21]
The following table summarizes the allocation of the purchase price based on the estimated fair values of the assets acquired and liabilities assumed and related deferred income taxes in connection with the Acquisition as of the Acquisition Date (in millions):

[0001437749-25-002900:notes:22]
[same as prior period, unchanged from 0001437749-24-032618:notes:22]

[0001437749-25-002900:notes:23]
[same as prior period, unchanged from 0001437749-24-032618:notes:23]

[0001437749-25-002900:notes:24]
Inventory includes a $0.7 million adjustment to step up the inventory balance to fair value consistent with the purchase price allocation. The fair value was determined based on the estimated selling price of the inventory, less the remaining manufacturing and selling cost and a normal profit margin on those manufacturing and selling efforts. The inventory step up adjustment increased cost of revenue $0.4 million and $0.7 million in the three and nine months ended  December 31, 2024, respectively, as the inventory was sold.

[0001437749-25-002900:notes:25]
[same as prior period, unchanged from 0001437749-24-032618:notes:25]

[0001437749-25-002900:notes:26]
[same as prior period, unchanged from 0001437749-24-032618:notes:26]

[0001437749-25-002900:notes:27]
Goodwill represents the value associated with the acquired workforce and expected synergies related to the business combination of the two companies. Goodwill resulting from the Acquisition was assigned to the Company’s Grid business segment. Goodwill recognized in the Acquisition is not deductible for tax purposes. This purchase price allocation is preliminary and has not been finalized as the analysis on the assets and liabilities acquired, primarily the tax related liability  may require further adjustments to our purchase accounting that could result in a measurement period adjustment that would impact the Company's reported net assets and goodwill as of  August 1, 2024. Material changes, if any, to the preliminary allocation summarized above will be reported once the related uncertainties are resolved, but no later than  August 1, 2025. The $6.4 million of deferred tax liability is primarily related to basis difference of property, plant, and equipment.

[0001437749-25-002900:notes:28]
[same as prior period, unchanged from 0001437749-24-032618:notes:28]

[0001437749-25-002900:notes:29]
The unaudited pro forma condensed consolidated statement of operations for the three and nine months ended  December 31, 2024 and 2023 presented as if the Acquisition had occurred on  April 1, 2023, is as follows:

[0001437749-25-002900:notes:30]
|  |  | Three Months Ended December 31, |  |  | Nine Months Ended December 31, |  |
|  |  | 2024 |  |  | 2023 |  |  | 2024 |  |  | 2023 |  |
| Net Revenue |  | $ | 61,403 |  |  | $ | 58,874 |  |  | $ | 179,435 |  |  | $ | 158,789 |  |
| Operating income (loss) |  |  | 1,577 |  |  |  | 116 |  |  |  | (502 | ) |  |  | (7,077 | ) |
| Net income (loss) |  | $ | 2,728 |  |  | $ | 668 |  |  | $ | 1,922 |  |  | $ | 35 |  |
| Net income (loss) per common share |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.07 |  |  | $ | 0.02 |  |  | $ | 0.05 |  |  | $ | - |  |
| Diluted |  | $ | 0.07 |  |  | $ | 0.02 |  |  | $ | 0.05 |  |  | $ | - |  |
| Shares - basic |  |  | 37,661 |  |  |  | 30,390 |  |  |  | 37,347 |  |  |  | 30,026 |  |
| Shares - diluted |  |  | 38,463 |  |  |  | 30,726 |  |  |  | 38,037 |  |  |  | 30,405 |  |

[0001437749-25-002900:notes:31]
[same as prior period, unchanged from 0001437749-24-032618:notes:31]

[0001437749-25-002900:notes:32]
In the unaudited consolidated results for the three and nine months ended  December 31, 2024, Megatran’s operations are included in the Company’s consolidated results from the date of Acquisition of  August 1, 2024. Megatran contributed $18.3 million of revenue and $1.9 million in net income for the Company for the three months ended  December 31, 2024. Megatran contributed $32.4 million of revenue and $3.9 million in net income for the Company for the nine months ended  December 31, 2024. Amortization expense of $0.3 million and $0.5 million is included in the three and nine months ended  December 31, 2024, respectively, as a result of the Megatran acquired intangible assets. In addition, $0.4 million and $0.7 million for the step-up basis assigned to acquired inventory was charged to cost of revenues in the three and nine months ended  December 31, 2024, respectively.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001437749-25-002900:notes:33]
[same as prior period, unchanged from 0001437749-24-032618:notes:33]

[0001437749-25-002900:notes:34]
The Company’s revenues in its Grid business segment are derived primarily through enabling the transmission and distribution of power, providing planning services that allow it to identify power grid needs and risks, and developing ship protection systems for the U.S. Navy. The Company’s revenues in its Wind business segment are derived primarily through supplying advanced power electronics and control systems, licensing its highly engineered wind turbine designs, and providing extensive customer support services to wind turbine manufacturers. The Company records revenue based on a five-step model in accordance with Accounting Standards Codification ("ASC") 606. For its customer contracts, the Company identifies the performance obligations, determines the transaction price, allocates the contract transaction price to the performance obligations, and recognizes the revenue when (or as) control of goods or services is transferred to the customer. For the three and nine months ended  December 31, 2024, 87% and 88% of revenue, respectively, was recognized at the point in time when control transferred to the customer, with the remainder being recognized over time. For the three and nine months ended  December 31, 2023, 85% and 80% of revenue, respectively, was recognized at the point in time when control transferred to the customer, with the remainder being recognized over time.

[0001437749-25-002900:notes:35]
[same as prior period, unchanged from 0001437749-24-032618:notes:35]

[0001437749-25-002900:notes:36]
[same as prior period, unchanged from 0001437749-24-032618:notes:36]

[0001437749-25-002900:notes:37]
[same as prior period, unchanged from 0001437749-24-032618:notes:37]

[0001437749-25-002900:notes:38]
[same as prior period, unchanged from 0001437749-24-032618:notes:38]

[0001437749-25-002900:notes:39]
[same as prior period, unchanged from 0001437749-24-032618:notes:39]

[0001437749-25-002900:notes:40]
The Company records revenue net of sales tax, value added tax, excise tax and other taxes collected concurrent with revenue-producing activities. The Company has elected to recognize the cost for freight and shipping when control over the products sold passes to customers and revenue is recognized. The Company has elected to recognize incremental costs of obtaining a contract as expense when incurred except in contracts where the amortization period would exceed twelve months. As of  December 31, 2024 and  March 31, 2024, the Company's capitalized incremental contract costs were not material. The Company has elected not to adjust the promised amount of consideration for the effects of a significant financing component if the period of financing is twelve months or less.  The Company has elected to recognize revenue based on the as invoiced practical expedient if there is a right to consideration from a customer in an amount that corresponds directly with the value of the Company's performance.

[0001437749-25-002900:notes:41]
[same as prior period, unchanged from 0001437749-24-032618:notes:41]

[0001437749-25-002900:notes:42]
[same as prior period, unchanged from 0001437749-24-032618:notes:42]

[0001437749-25-002900:notes:43]
|  |  | Three Months Ended December 31, 2024 |  |  | Nine Months Ended December 31, 2024 |  |
| Product Line: |  | Grid |  |  | Wind |  |  | Grid |  |  | Wind |  |
| Equipment and systems |  | $ | 48,979 |  |  | $ | 8,768 |  |  | $ | 123,431 |  |  | $ | 23,357 |  |
| Services and technology development |  |  | 3,327 |  |  |  | 329 |  |  |  | 8,147 |  |  |  | 1,228 |  |
| Total |  | $ | 52,306 |  |  | $ | 9,097 |  |  | $ | 131,578 |  |  | $ | 24,585 |  |
| Region: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas |  | $ | 47,737 |  |  | $ | — |  |  | $ | 121,696 |  |  | $ | 1 |  |
| Asia Pacific |  |  | 2,293 |  |  |  | 9,080 |  |  |  | 4,280 |  |  |  | 24,562 |  |
| EMEA |  |  | 2,276 |  |  |  | 17 |  |  |  | 5,602 |  |  |  | 22 |  |
| Total |  | $ | 52,306 |  |  | $ | 9,097 |  |  | $ | 131,578 |  |  | $ | 24,585 |  |

[0001437749-25-002900:notes:44]
|  |  | Three Months Ended December 31, 2023 |  |  | Nine Months Ended December 31, 2023 |  |
| Product Line: |  | Grid |  |  | Wind |  |  | Grid |  |  | Wind |  |
| Equipment and systems |  | $ | 31,210 |  |  | $ | 4,983 |  |  | $ | 81,181 |  |  | $ | 13,844 |  |
| Services and technology development |  |  | 2,393 |  |  |  | 767 |  |  |  | 6,673 |  |  |  | 1,913 |  |
| Total |  | $ | 33,603 |  |  | $ | 5,750 |  |  | $ | 87,854 |  |  | $ | 15,757 |  |
| Region: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas |  | $ | 26,782 |  |  | $ | 45 |  |  | $ | 74,640 |  |  | $ | 102 |  |
| Asia Pacific |  |  | 3,704 |  |  |  | 5,660 |  |  |  | 8,832 |  |  |  | 15,587 |  |
| EMEA |  |  | 3,117 |  |  |  | 45 |  |  |  | 4,382 |  |  |  | 68 |  |
| Total |  | $ | 33,603 |  |  | $ | 5,750 |  |  | $ | 87,854 |  |  | $ | 15,757 |  |

[0001437749-25-002900:notes:45]
As of  December 31, 2024 and 2023, the Company’s contract assets and liabilities primarily relate to the timing differences between cash received from a customer in connection with contractual rights to invoicing and the timing of revenue recognition following completion of performance obligations. The Company's accounts receivable balance is made up entirely of customer contract related balances. Changes in the Company’s contract assets, which are included in “Unbilled accounts receivable” and “Deferred program costs” (see Note 8, “Accounts Receivable” and Note 9, “Inventory” for a reconciliation to the condensed consolidated balance sheets) and "Contract liabilities", which are included in the current portion and long-term portion of "Deferred revenue" in the Company’s condensed consolidated balance sheets, are as follows (in thousands):

[0001437749-25-002900:notes:46]
|  |  | Unbilled Accounts Receivable |  |  | Deferred Program Costs |  |  | Contract Liabilities |  |
| Beginning balance as of March 31, 2024 |  | $ | 6,150 |  |  | $ | 2,523 |  |  | $ | 57,829 |  |
| Increase for balance acquired |  |  | — |  |  |  | — |  |  |  | 5,049 |  |
| Increases for costs incurred to fulfill performance obligations |  |  | — |  |  |  | 10,876 |  |  |  | — |  |
| Increase (decrease) due to customer billings |  |  | (7,139 | ) |  |  | — |  |  |  | 96,400 |  |
| Decrease due to cost recognition on completed performance obligations |  |  | — |  |  |  | (6,133 | ) |  |  | — |  |
| Increase (decrease) due to recognition of revenue based on transfer of control of performance obligations |  |  | 6,120 |  |  |  | — |  |  |  | (75,410 | ) |
| Other changes and FX impact |  |  | (18 | ) |  |  | (11 | ) |  |  | (540 | ) |
| Ending balance as of December 31, 2024 |  | $ | 5,113 |  |  | $ | 7,255 |  |  | $ | 83,328 |  |

[0001437749-25-002900:notes:47]
|  |  | Unbilled Accounts Receivable |  |  | Deferred Program Costs |  |  | Contract Liabilities |  |
| Beginning balance as of March 31, 2023 |  | $ | 9,958 |  |  | $ | 2,136 |  |  | $ | 50,760 |  |
| Increases for costs incurred to fulfill performance obligations |  |  | — |  |  |  | 2,714 |  |  |  | — |  |
| Increase (decrease) due to customer billings |  |  | (18,354 | ) |  |  | — |  |  |  | 55,018 |  |
| Decrease due to cost recognition on completed performance obligations |  |  | — |  |  |  | (3,518 | ) |  |  | — |  |
| Increase (decrease) due to recognition of revenue based on transfer of control of performance obligations |  |  | 12,969 |  |  |  | — |  |  |  | (46,190 | ) |
| Other changes and FX impact |  |  | 15 |  |  |  | 5 |  |  |  | 155 |  |
| Ending balance as of December 31, 2023 |  | $ | 4,588 |  |  | $ | 1,337 |  |  | $ | 59,743 |  |

[0001437749-25-002900:notes:48]
The Company’s remaining performance obligations represent the unrecognized revenue value of the Company’s contractual commitments. The Company’s performance obligations  may vary significantly each reporting period based on the timing of major new contractual commitments. As of  December 31, 2024, the Company had outstanding performance obligations on existing contracts under ASC 606 to be recognized in the next twelve months of approximately $204.2 million. There are also approximately $96.6 million of outstanding performance obligations to be recognized over a period of thirteen to sixty months. The remaining performance obligations are subject to customer actions and therefore the timing of revenue recognition cannot be reasonably estimated.

[0001437749-25-002900:notes:49]
The following table sets forth customers who represented 10% or more of the Company’s total revenues for the three and nine months ended  December 31, 2024 and 2023:

[0001437749-25-002900:notes:50]
|  |  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  | Reportable |  | December 31, |  |  | December 31, |  |
|  | Segment |  | 2024 |  |  | 2023 |  |  | 2024 |  |  | 2023 |  |
| Inox Wind Limited | Wind |  |  | 10 | % |  |  | 11 | % |  |  | 13 | % |  |  | 12 | % |
| Innomotics LLC | Grid |  |  | 14 | % |  |  | <10% |  |  |  | <10% |  |  |  | <10% |  |


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001437749-25-002900:notes:51]
[same as prior period, unchanged from 0001437749-24-032618:notes:51]

[0001437749-25-002900:notes:52]
The Company accounts for its stock-based compensation at fair value. The following table summarizes stock-based compensation expense by financial statement line item for the three and nine months ended  December 31, 2024 and 2023 (in thousands):

[0001437749-25-002900:notes:53]
|  |  | Three Months Ended December 31, |  |  | Nine Months Ended December 31, |  |
|  |  | 2024 |  |  | 2023 |  |  | 2024 |  |  | 2023 |  |
| Cost of revenues |  | $ | 211 |  |  | $ | 62 |  |  | $ | 309 |  |  | $ | 230 |  |
| Research and development |  |  | 442 |  |  |  | 158 |  |  |  | 697 |  |  |  | 469 |  |
| Selling, general and administrative |  |  | 2,208 |  |  |  | 920 |  |  |  | 3,927 |  |  |  | 2,909 |  |
| Total |  | $ | 2,861 |  |  | $ | 1,140 |  |  | $ | 4,933 |  |  | $ | 3,608 |  |

[0001437749-25-002900:notes:54]
The Company issued 30,000 shares and 872,500 shares of restricted stock during the three and nine months ended  December 31, 2024, respectively. The Company issued no shares and 19,200 shares of immediately vested common stock during the three and nine months ended  December 31, 2024, respectively. The Company issued no shares and 681,500 shares of restricted stock during the three and nine months ended  December 31, 2023, respectively. No shares of immediately vested common stock were issued during the three months ended  December 31, 2023 and 53,675 shares of immediately vested common stock were issued during the nine months ended  December 31, 2023. These restricted stock awards generally vest over 2-3 years. Awards for restricted stock include both time-based and performance-based awards. For options and restricted stock awards that vest upon the passage of time, expense is being recorded over the vesting period. Performance-based awards are expensed over the requisite service period based on probability of achievement.

[0001437749-25-002900:notes:55]
The estimated fair value of the Company’s stock-based awards, less expected annual forfeitures, is amortized over the awards’ service period. There were no unrecognized compensation costs for unvested stock options as of  December 31, 2024. The total unrecognized compensation cost for unvested outstanding restricted stock was $18.2 million as of  December 31, 2024. This expense will be recognized over a weighted-average expense period of approximately 1.6 years.

[0001437749-25-002900:notes:56]
The Company granted no stock options during the three and nine months ended  December 31, 2024 and 2023.


## us-gaap:EarningsPerShareTextBlock

[0001437749-25-002900:notes:57]
[same as prior period, unchanged from 0001437749-24-032618:notes:57]

[0001437749-25-002900:notes:58]
Basic net income (loss) per share (“EPS”) is computed by dividing net income (loss) by the weighted-average number of common shares outstanding for the period. Where applicable, diluted EPS is computed by dividing the net income by the weighted-average number of common shares and dilutive common equivalent shares outstanding during the period, calculated using the treasury stock method. Common equivalent shares include the effect of restricted stock, exercise of stock options and warrants and contingently issuable shares. Stock options and warrants that are out-of-the-money with exercise prices greater than the average market price of the underlying common shares and shares of performance-based restricted stock where the contingency was not met are excluded from the computation of diluted EPS as the effect of their inclusion would be anti-dilutive. For the three months ended  December 31, 2024, 475,971 shares were not included in the calculation of diluted EPS. Of these, 475,971 were shares of performance-based restricted stock where the contingency was not met. For the nine months ended  December 31, 2024, 471,985 shares were not included in the calculation of diluted EPS. Of these, 471,768 were shares of performance-based restricted stock where the contingency was not met. 217 shares relate to outstanding stock awards that were considered anti-dilutive. For each of the three and nine months ended  December 31, 2023, 336,206 shares were not included in the calculation of diluted EPS. Of these, 300,000 relate to shares associated with the contingent consideration derivative liability for which the contingency had not yet been met, and 36,206 relate to outstanding stock options as they were considered anti-dilutive.

[0001437749-25-002900:notes:59]
The following table reconciles the numerators and denominators of the earnings per share calculation for the three and nine months ended  December 31, 2024 and 2023 (in thousands, except per share data):

[0001437749-25-002900:notes:60]
|  |  | Three Months Ended December 31, |  |  | Nine Months Ended December 31, |  |
|  |  | 2024 |  |  | 2023 |  |  | 2024 |  |  | 2023 |  |
| Numerator: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income (loss) |  | $ | 2,465 |  |  | $ | (1,649 | ) |  | $ | 4,828 |  |  | $ | (9,532 | ) |
| Denominator: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Weighted-average shares of common stock outstanding |  |  | 39,450 |  |  |  | 30,547 |  |  |  | 38,127 |  |  |  | 30,180 |  |
| Weighted-average shares subject to repurchase |  |  | (1,789 | ) |  |  | (1,455 | ) |  |  | (1,361 | ) |  |  | (1,452 | ) |
| Shares used in per-share calculation ― basic |  |  | 37,661 |  |  |  | 29,092 |  |  |  | 36,766 |  |  |  | 28,728 |  |
| Shares used in per-share calculation ― diluted |  |  | 38,463 |  |  |  | 29,092 |  |  |  | 37,457 |  |  |  | 28,728 |  |
| Net income (loss) per share ― basic |  | $ | 0.07 |  |  | $ | (0.06 | ) |  | $ | 0.13 |  |  | $ | (0.33 | ) |
| Net income (loss) per share ― diluted |  | $ | 0.06 |  |  | $ | (0.06 | ) |  | $ | 0.13 |  |  | $ | (0.33 | ) |


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001437749-25-002900:notes:61]
[same as prior period, unchanged from 0001437749-24-032618:notes:61]

[0001437749-25-002900:notes:62]
[same as prior period, unchanged from 0001437749-24-032618:notes:62]

[0001437749-25-002900:notes:63]
[same as prior period, unchanged from 0001437749-24-032618:notes:63]

[0001437749-25-002900:notes:64]
|  |  | Goodwill |  |
| March 31, 2024 |  | $ | 43,471 |  |
| Megatran Acquisition |  |  | 5,479 |  |
| December 31, 2024 |  | $ | 48,950 |  |

[0001437749-25-002900:notes:65]
The Company did not record impairment in the three and nine months ended  December 31, 2024.

[0001437749-25-002900:notes:66]
[same as prior period, unchanged from 0001437749-24-032618:notes:66]

[0001437749-25-002900:notes:67]
Intangible assets at  December 31, 2024 and  March 31, 2024 consisted of the following (in thousands):

[0001437749-25-002900:notes:68]
|  |  | December 31, 2024 |  |  | March 31, 2024 |  |  |  |  |  |
|  |  | Gross Amount |  |  | Accumulated Amortization |  |  | Net Book Value |  |  | Gross Amount |  |  | Accumulated Amortization |  |  | Net Book Value |  |  | Estimated Useful Life |  |
| Backlog |  |  | 1,381 |  |  |  | (1,118 | ) |  |  | 263 |  |  |  | 681 |  |  |  | (681 | ) |  |  | — |  |  |  | 2 |  |
| Trade name and trademarks |  |  | 1,800 |  |  |  | 0 |  |  |  | 1,800 |  |  |  | 1,800 |  |  |  | — |  |  |  | 1,800 |  |  | Indefinite |  |
| Customer relationships |  |  | 10,880 |  |  |  | (7,577 | ) |  |  | 3,303 |  |  |  | 9,600 |  |  |  | (6,649 | ) |  |  | 2,951 |  |  |  | 7-10 |  |
| Core technology and know-how |  |  | 5,970 |  |  |  | (4,714 | ) |  |  | 1,256 |  |  |  | 5,970 |  |  |  | (4,352 | ) |  |  | 1,618 |  |  |  | 5-10 |  |
| Intangible assets |  | $ | 20,031 |  |  | $ | (13,409 | ) |  | $ | 6,622 |  |  | $ | 18,051 |  |  | $ | (11,682 | ) |  | $ | 6,369 |  |  |  |  |  |

[0001437749-25-002900:notes:69]
The Company recorded intangible amortization expense related to customer relationship and core technology and know-how of $0.4 million and $1.3 million in the three and nine months ended  December 31, 2024, respectively. The Company recorded intangible amortization expense related to customer relationship and core technology and know-how of $0.5 million and $1.6 million in the three and nine months ended  December 31, 2023, respectively. The Company recorded $0.3 million and $0.4 million of intangible amortization in cost of revenue related to backlog during the three and nine  months ended  December 31, 2024, respectively. The Company recorded no amortization expense related to backlog during the three months ended  December 31, 2023 and less than $0.1 million related to backlog was reported in cost of revenues during the nine months ended  December 31, 2023.

[0001437749-25-002900:notes:70]
[same as prior period, unchanged from 0001437749-24-032618:notes:70]

[0001437749-25-002900:notes:71]
| Years ending March 31, |  | Total |  |
| 2025 (remaining) |  |  | 706 |  |
| 2026 |  |  | 1,349 |  |
| 2027 |  |  | 1,213 |  |
| 2028 |  |  | 671 |  |
| 2029 |  |  | 201 |  |
| Thereafter |  |  | 682 |  |
| Total |  | $ | 4,822 |  |

[0001437749-25-002900:notes:72]
[same as prior period, unchanged from 0001437749-24-032618:notes:72]


## us-gaap:FairValueDisclosuresTextBlock

[0001437749-25-002900:notes:73]
[same as prior period, unchanged from 0001437749-24-032618:notes:73]

[0001437749-25-002900:notes:74]
[same as prior period, unchanged from 0001437749-24-032618:notes:74]

[0001437749-25-002900:notes:75]
[same as prior period, unchanged from 0001437749-24-032618:notes:75]

[0001437749-25-002900:notes:76]
The Company provides a gross presentation of activity within Level 3 measurement roll-forward and details of transfers in and out of Level 1 and 2 measurements. A change in the hierarchy of an investment from its current level is reflected in the period during which the pricing methodology of such investment changes. Disclosure of the transfer of securities from Level 1 to Level 2 or Level 3 is made in the event that the related security is significant to total cash and investments. The Company did not have any transfers of assets and liabilities from Level 1, Level 2 or Level 3 of the fair value measurement hierarchy during the three or nine months ended  December 31, 2024.

[0001437749-25-002900:notes:77]
[same as prior period, unchanged from 0001437749-24-032618:notes:77]

[0001437749-25-002900:notes:78]
[same as prior period, unchanged from 0001437749-24-032618:notes:78]

[0001437749-25-002900:notes:79]
[same as prior period, unchanged from 0001437749-24-032618:notes:79]

[0001437749-25-002900:notes:80]
[same as prior period, unchanged from 0001437749-24-032618:notes:80]

[0001437749-25-002900:notes:81]
[same as prior period, unchanged from 0001437749-24-032618:notes:81]

[0001437749-25-002900:notes:82]
Contingent consideration related to the earnout payment set forth in the NEPSI Stock Purchase Agreement governing the acquisition of NEPSI provided that the selling stockholders  may have received up to an additional 1,000,000 shares of common stock of the Company upon the achievement of certain specified revenue objectives over varying periods of up to four years following the NEPSI acquisition date which must have occurred by  September 30, 2024. Contingent consideration related to the make whole payment set forth in the Megatran Stock Purchase Agreement provided that the selling stockholders would be made whole for any costs or taxes as a result of the orderly distribution process. We classified contingent consideration related to certain acquisitions within level 3 of the fair value hierarchy because the fair value is derived using significant unobservable inputs, which include revenue risk premium and revenue volatility. See Note 15, "Contingent Consideration" for further discussion. As of  September 30, 2024, the Company had settled all outstanding contingent consideration.

[0001437749-25-002900:notes:83]
The following table provides the assets and liabilities carried at fair value on a recurring basis, measured as of  December 31, 2024 and  March 31, 2024 (in thousands):

[0001437749-25-002900:notes:84]
|  |  | Total Carrying Value |  |  | Quoted Prices in Active Markets (Level 1) |  |  | Significant Other Observable Inputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |
| December 31, 2024: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash equivalents |  | $ | 52,495 |  |  | $ | 52,495 |  |  | $ | — |  |  | $ | — |  |

[0001437749-25-002900:notes:85]
[same as prior period, unchanged from 0001437749-24-032618:notes:85]

[0001437749-25-002900:notes:86]
[same as prior period, unchanged from 0001437749-24-032618:notes:86]

[0001437749-25-002900:notes:87]
|  |  | NEPSI Acquisition Contingent Consideration |  |  | Megatran Acquisition Contingent Consideration |  |
| Balance at March 31, 2023 |  | $ | 1,270 |  |  | $ | — |  |
| Change in fair value |  |  | 3,052 |  |  |  | — |  |
| Settlement of contingent consideration |  |  | (3,092 | ) |  |  | — |  |
| Balance at December 31, 2023 |  | $ | 1,230 |  |  | $ | — |  |
| Balance at March 31, 2024 |  | $ | 3,100 |  |  | $ | — |  |
| Change in fair value |  |  | 3,404 |  |  |  | 3,278 |  |
| Settlement of contingent consideration |  |  | (6,504 | ) |  |  | (3,278 | ) |
| Balance at December 31, 2024 |  | $ | — |  |  | $ | — |  |


## amsc:AccountsReceivableTextBlock

[0001437749-25-002900:notes:88]
[same as prior period, unchanged from 0001437749-24-032618:notes:88]

[0001437749-25-002900:notes:89]
Accounts receivable at  December 31, 2024 and  March 31, 2024 consisted of the following (in thousands):

[0001437749-25-002900:notes:90]
|  |  | December 31, 2024 |  |  | March 31, 2024 |  |
| Accounts receivable (billed) |  | $ | 39,022 |  |  | $ | 20,175 |  |
| Accounts receivable (unbilled) |  |  | 5,113 |  |  |  | 6,150 |  |
| Accounts receivable |  | $ | 44,135 |  |  | $ | 26,325 |  |


## us-gaap:InventoryDisclosureTextBlock

[0001437749-25-002900:notes:91]
[same as prior period, unchanged from 0001437749-24-032618:notes:91]

[0001437749-25-002900:notes:92]
Inventory, net of reserves, at  December 31, 2024 and  March 31, 2024 consisted of the following (in thousands):

[0001437749-25-002900:notes:93]
|  |  | December 31, 2024 |  |  | March 31, 2024 |  |
| Raw materials |  | $ | 38,013 |  |  | $ | 20,622 |  |
| Work-in-process |  |  | 23,513 |  |  |  | 14,872 |  |
| Finished goods |  |  | 5,807 |  |  |  | 3,840 |  |
| Deferred program costs |  |  | 7,255 |  |  |  | 2,523 |  |
| Net inventory |  | $ | 74,588 |  |  | $ | 41,857 |  |

[0001437749-25-002900:notes:94]
The Company recorded inventory write-downs of $0.4 million and $0.5 million for the three months ended  December 31, 2024 and 2023, respectively. The Company recorded inventory write-downs of $1.2 million and $1.5 million for the nine months ended  December 31, 2024 and 2023, respectively. These write-downs were based on the Company's evaluation of its inventory on hand for excess quantities and obsolescence.

[0001437749-25-002900:notes:95]
Deferred program costs as of  December 31, 2024 and  March 31, 2024 primarily represent costs incurred on programs where the Company needs to complete performance obligations before the related revenue and costs will be recognized.


## amsc:PrepaidAndOtherCurrentAssetsTextBlock

[0001437749-25-002900:notes:96]
[same as prior period, unchanged from 0001437749-24-032618:notes:96]

[0001437749-25-002900:notes:97]
[same as prior period, unchanged from 0001437749-24-032618:notes:97]

[0001437749-25-002900:notes:98]
[same as prior period, unchanged from 0001437749-24-032618:notes:98]

[0001437749-25-002900:notes:99]
The Company recorded a $3.3 million receivable in prepaid expenses and other current assets and a benefit of $1.8 million to cost of revenues, $0.8 million to selling, general, and administrative and $0.7 million to research and development in the fiscal year ended  March 31, 2023 for the ERC that was expected to be received based on the amended filings. During the year ended  March 31, 2024, the Company received $3.0 million for the initial claims that were processed. During the nine months ended  December 31, 2024, the Company did not receive any cash for the remaining $0.3 million balance of initial claims that were processed. The remaining balance is expected to be received during fiscal 2025.


## us-gaap:PropertyPlantAndEquipmentDisclosureTextBlock

[0001437749-25-002900:notes:100]
[same as prior period, unchanged from 0001437749-24-032618:notes:100]

[0001437749-25-002900:notes:101]
The cost and accumulated depreciation of property, plant and equipment at  December 31, 2024 and  March 31, 2024 are as follows (in thousands):

[0001437749-25-002900:notes:102]
|  |  | December 31, 2024 |  |  | March 31, 2024 |  |
| Land |  | $ | 22,650 |  |  | $ | 980 |  |
| Construction in progress – equipment |  |  | 758 |  |  |  | 226 |  |
| Buildings |  |  | 7,524 |  |  |  | 5,416 |  |
| Equipment and software |  |  | 48,123 |  |  |  | 44,095 |  |
| Furniture and fixtures |  |  | 1,650 |  |  |  | 1,526 |  |
| Leasehold improvements |  |  | 7,823 |  |  |  | 6,990 |  |
| Property, plant and equipment, gross |  |  | 88,528 |  |  |  | 59,233 |  |
| Less accumulated depreciation |  |  | (50,138 | ) |  |  | (48,372 | ) |
| Property, plant and equipment, net |  | $ | 38,390 |  |  | $ | 10,861 |  |

[0001437749-25-002900:notes:103]
Depreciation expense was $0.9 million and $0.6 million for the three months ended  December 31, 2024 and 2023, respectively. Depreciation expense was $2.3 million and $1.7 million for the nine months ended  December 31, 2024 and 2023, respectively. The increase in land relates to the property added as part of the Megatran Acquisition.


## us-gaap:EquityMethodInvestmentsDisclosureTextBlock

[0001437749-25-002900:notes:104]
[same as prior period, unchanged from 0001437749-24-032618:notes:104]

[0001437749-25-002900:notes:105]
[same as prior period, unchanged from 0001437749-24-032618:notes:105]

[0001437749-25-002900:notes:106]
[same as prior period, unchanged from 0001437749-24-032618:notes:106]

[0001437749-25-002900:notes:107]
The Company treats the equity investment in the condensed consolidated financial statements under the equity method. Equity method investments are equity securities in entities the Company does not control but over which it has the ability to exercise significant influence. These investments are accounted for under the equity method of accounting in accordance with ASC 323, Investments — Equity Method and Joint Ventures. Equity method investments are measured at cost minus impairment, if any, plus or minus the Company’s share of an investee’s income or loss, less distributions received. As of  December 31, 2024 the Company did not have material accounts receivable nor accounts payable balances with NWL Pacific.

[0001437749-25-002900:notes:108]
The tables below present the summarized financial information from the date of acquisition through  December 31, 2024, as provided to the Company by the investee, for the unconsolidated company (in thousands):

[0001437749-25-002900:notes:109]
|  |  | Three Months Ended December 31, |  |  | Nine Months Ended December 31, |  |
|  |  | 2024 |  |  | 2024 |  |
| Net Revenue |  | $ | 1,368 |  |  | $ | 2,225 |  |
| Gross Profit |  |  | 492 |  |  |  | 800 |  |
| Income from operation |  |  | 161 |  |  |  | 318 |  |
| Net income |  | $ | 152 |  |  | $ | 299 |  |


## us-gaap:AccountsPayableAndAccruedLiabilitiesDisclosureTextBlock

[0001437749-25-002900:notes:110]
[same as prior period, unchanged from 0001437749-24-032618:notes:110]

[0001437749-25-002900:notes:111]
Accounts payable and accrued expenses at  December 31, 2024 and  March 31, 2024 consisted of the following (in thousands):

[0001437749-25-002900:notes:112]
|  |  | December 31, 2024 |  |  | March 31, 2024 |  |
| Accounts payable |  | $ | 4,130 |  |  | $ | 4,476 |  |
| Accrued inventories in-transit |  |  | 3,308 |  |  |  | 539 |  |
| Accrued other miscellaneous expenses |  |  | 3,602 |  |  |  | 2,366 |  |
| Accrued contract loss |  |  | 97 |  |  |  | 97 |  |
| Advanced deposits |  |  | 2,892 |  |  |  | 2,270 |  |
| Accrued compensation |  |  | 10,688 |  |  |  | 10,326 |  |
| Income taxes payable |  |  | 181 |  |  |  | 346 |  |
| Accrued product warranty |  |  | 3,043 |  |  |  | 2,363 |  |
| Accrued commissions |  |  | 1,484 |  |  |  | 1,452 |  |
| Total |  | $ | 29,425 |  |  | $ | 24,235 |  |

[0001437749-25-002900:notes:113]
[same as prior period, unchanged from 0001437749-24-032618:notes:113]

[0001437749-25-002900:notes:114]
[same as prior period, unchanged from 0001437749-24-032618:notes:114]

[0001437749-25-002900:notes:115]
|  |  | Three Months Ended December 31, |  |  | Nine Months Ended December 31, |  |
|  |  | 2024 |  |  | 2023 |  |  | 2024 |  |  | 2023 |  |
| Balance at beginning of period |  | $ | 3,110 |  |  | $ | 1,892 |  |  | $ | 2,363 |  |  | $ | 2,638 |  |
| Acquired warranty obligations |  |  | — |  |  |  | — |  |  |  | 637 |  |  |  | — |  |
| Provisions for warranties during the period |  |  | 348 |  |  |  | 360 |  |  |  | 1,122 |  |  |  | 1,212 |  |
| Settlements during the period |  |  | (415 | ) |  |  | (221 | ) |  |  | (1,079 | ) |  |  | (1,819 | ) |
| Balance at end of period |  | $ | 3,043 |  |  | $ | 2,031 |  |  | $ | 3,043 |  |  | $ | 2,031 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0001437749-25-002900:notes:116]
[same as prior period, unchanged from 0001437749-24-032618:notes:116]

[0001437749-25-002900:notes:117]
The Company recorded income tax benefit of $0.1 million and $4.9 million in the three and nine months ended  December 31, 2024, respectively, and income tax expense of $0.1 million $0.3 million in the three and nine months ended  December 31, 2023, respectively.

[0001437749-25-002900:notes:118]
As a result of a difference in book and tax basis related to the intangible assets acquired in the Acquisition (see Note 2, "Acquisition"), the Company recorded a deferred tax liability of $6.4 million. As a result, the Company was able to benefit from additional deferred tax assets and therefore released a corresponding valuation allowance of $5.2 million during the nine months ended  December 31, 2024. The purchase price allocation is preliminary and has not been finalized as the analysis on the assets and liabilities acquired, primarily the tax related liability,  may require further adjustments to the Company's purchase accounting that could result in measurement period adjustments that would impact the Company's reported net assets and goodwill as of  August 1, 2024. Material changes, if any, to the preliminary allocation summarized in Note 2, "Acquisition" will be reported once the related uncertainties are resolved, but no later than  August 1, 2025.  Goodwill recognized in the Acquisition, is not deductible for tax purposes.

[0001437749-25-002900:notes:119]
Accounting for income taxes requires a two-step approach to recognizing and measuring uncertain tax positions. The first step is to evaluate the tax position for recognition by determining if, based on the technical merits, it is more likely than not the position will be sustained upon audit, including resolution of related appeals or litigation processes, if any. The second step is to measure the tax benefit as the largest amount that is more than 50% likely to be realized upon ultimate settlement. The Company re-evaluates these uncertain tax positions on a quarterly basis. The evaluation is based on factors including, but not limited to, changes in facts or circumstances, changes in tax law, effectively settled issues under audit and new audit activity. Any changes in these factors could result in the recognition of a tax benefit or an additional charge to the tax provision. The Company did not identify any uncertain tax positions in the nine months ended  December 31, 2024 and did not have any gross unrecognized tax benefits as of  December 31, 2024.


## amsc:BusinessCombinationContingentConsiderationTextBlock

[0001437749-25-002900:notes:120]
[same as prior period, unchanged from 0001437749-24-032618:notes:120]

[0001437749-25-002900:notes:121]
[same as prior period, unchanged from 0001437749-24-032618:notes:121]

[0001437749-25-002900:notes:122]
On  October 1, 2020 (the "NEPSI Acquisition Date"), the Company entered into a Stock Purchase Agreement (the "NEPSI Stock Purchase Agreement") with the selling stockholders named therein. Pursuant to the terms of the NEPSI Stock Purchase Agreement and concurrently with entering into such agreement, the Company acquired all of the issued and outstanding (i) shares of capital stock of NEPSI, and (ii) membership interests of Northeast Power Realty, LLC, a New York limited liability company, which holds the real property that serves as NEPSI's headquarters (the "NEPSI Acquisition"). NEPSI is a U.S.-based global provider of medium-voltage metal-enclosed power capacitor banks and harmonic filter banks for use on electric power systems. NEPSI is a wholly-owned subsidiary of the Company and is operated by its Grid business segment. The purchase price was $26.0 million in cash and 873,657 restricted shares of common stock of the Company. As part of the transaction, the selling stockholders were entitled to receive up to an additional 1,000,000 shares of common stock of the Company upon the achievement of certain specified revenue objectives during varying periods of up to four years following closing of the NEPSI Acquisition. During the year ended  March 31, 2024, the Company issued 399,999 shares of common stock and cash in lieu of a fractional share of common stock, related to the achievement of specified revenue objectives in connection with the NEPSI Acquisition. NEPSI recognized revenues in excess of $120.0 million during the four years after the NEPSI Acquisition Date. As a result, during the quarter ended  September 30, 2024, the Company issued 300,000 shares of common stock of the Company to the selling stockholders, following certification of the achievement of the specified earnout revenue objective. As of  September 30, 2024, the Company had settled all outstanding contingent consideration under the NEPSI Stock Purchase Agreement.

[0001437749-25-002900:notes:123]
The Company evaluated the NEPSI Acquisition earnout payment set forth in the NEPSI Stock Purchase Agreement, which was expected to require settlement in the Company's common stock, and determined the contingent consideration qualified for liability classification and derivative treatment under ASC 815, Derivatives and Hedging. As a result, for the periods in which the Company had outstanding contingent consideration, the fair value of the contingent consideration was remeasured and the resulting gain or loss was recognized in operating expenses until the share amount is fixed.

[0001437749-25-002900:notes:124]
[same as prior period, unchanged from 0001437749-24-032618:notes:124]

[0001437749-25-002900:notes:125]
On  August 1, 2024, the Company entered into a Stock Purchase Agreement with the selling stockholders of Megatran named therein. Pursuant to the terms of the Stock Purchase Agreement and concurrently with entering into such agreement, the Company acquired all of the issued and outstanding shares of Megatran for aggregate consideration in an amount equal to $61.4 million which consideration amount was subject to various adjustments set forth in the Stock Purchase Agreement. The value of the contingent consideration to make the sellers whole was determined to be de minimis at the time of the Acquisition. On  September 23, 2024, the Company paid $3.3 million to the selling stockholders, which was calculated based on the agreed upon formula set forth in the Stock Purchase Agreement. This amount is reflected as the change in fair value of this contingent consideration in the three and six months ended  September 30, 2024. As of  September 30, 2024, there were no remaining obligations to the selling stockholders of Megatran.

[0001437749-25-002900:notes:126]
[same as prior period, unchanged from 0001437749-24-032618:notes:126]

[0001437749-25-002900:notes:127]
[same as prior period, unchanged from 0001437749-24-032618:notes:127]

[0001437749-25-002900:notes:128]
During the nine months ended  December 31, 2024, the Company issued 300,000 shares of common stock related to the achievement of specified revenue objectives at a fair value of $6.5 million. The Company recorded a loss of $3.4 million resulting from the increases in the fair value of the contingent consideration in the nine months ended  December 31, 2024. The Company recorded losses of $0.9 million and $3.1 million resulting from the increases in the fair value of the contingent consideration in the three and nine months ended  December 31, 2023, respectively.


## us-gaap:DebtDisclosureTextBlock

[0001437749-25-002900:notes:129]
16. Debt

[0001437749-25-002900:notes:130]
As part of the acquisition of Neeltran, the Company identified four equipment financing agreements that Neeltran had entered into prior to the acquisition of Neeltran on  May 6, 2021. The Company did not have a current debt balance as of  December 31, 2024 and had a balance of less than $0.1 million as of  March 31, 2024.


## us-gaap:LesseeOperatingLeasesTextBlock

[0001437749-25-002900:notes:131]
[same as prior period, unchanged from 0001437749-24-032618:notes:131]

[0001437749-25-002900:notes:132]
[same as prior period, unchanged from 0001437749-24-032618:notes:132]

[0001437749-25-002900:notes:133]
[same as prior period, unchanged from 0001437749-24-032618:notes:133]

[0001437749-25-002900:notes:134]
[same as prior period, unchanged from 0001437749-24-032618:notes:134]

[0001437749-25-002900:notes:135]
[same as prior period, unchanged from 0001437749-24-032618:notes:135]

[0001437749-25-002900:notes:136]
As of  December 31, 2024, the right-of-use asset related to the finance lease is fully amortized, and is included in the property and equipment, net on the Company's condensed consolidated balance sheet.

[0001437749-25-002900:notes:137]
[same as prior period, unchanged from 0001437749-24-032618:notes:137]

[0001437749-25-002900:notes:138]
Supplemental balance sheet information related to leases at  December 31, 2024, and  March 31, 2024 are as follows (in thousands):

[0001437749-25-002900:notes:139]
|  |  | December 31, 2024 |  |  | March 31, 2024 |  |
| Leases: |  |  |  |  |  |  |  |  |
| Right-of-use assets – Operating |  | $ | 4,050 |  |  | $ | 2,557 |  |
| Total right-of-use assets |  |  | 4,050 |  |  |  | 2,557 |  |
| Lease liabilities – ST Operating |  | $ | 675 |  |  | $ | 716 |  |
| Lease liabilities – LT Operating |  |  | 2,725 |  |  |  | 1,968 |  |
| Total lease liabilities |  | $ | 3,400 |  |  | $ | 2,684 |  |
| Weighted-average remaining lease term |  |  | 5.04 |  |  |  | 3.49 |  |
| Weighted-average discount rate |  |  | 14.81 | % |  |  | 9.83 | % |

[0001437749-25-002900:notes:140]
The costs related to the Company's finance lease are not material. The costs related to the Company's operating leases for the three and nine months ended  December 31, 2024 and 2023 are as follows (in thousands):

[0001437749-25-002900:notes:141]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | December 31, 2024 |  |  | December 31, 2024 |  |
| Operating Leases: |  |  |  |  |  |  |  |  |
| Operating lease costs – fixed |  | $ | 407 |  |  | $ | 1,052 |  |
| Operating lease costs – variable |  |  | 21 |  |  |  | 110 |  |
| Short-term lease costs |  |  | 38 |  |  |  | 116 |  |
| Total lease costs |  | $ | 466 |  |  | $ | 1,278 |  |

[0001437749-25-002900:notes:142]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | December 31, 2023 |  |  | December 31, 2023 |  |
| Operating Leases: |  |  |  |  |  |  |  |  |
| Operating lease costs – fixed |  | $ | 303 |  |  | $ | 817 |  |
| Operating lease costs – variable |  |  | 39 |  |  |  | 119 |  |
| Short-term lease costs |  |  | 37 |  |  |  | 111 |  |
| Total lease costs |  | $ | 379 |  |  | $ | 1,047 |  |

[0001437749-25-002900:notes:143]
[same as prior period, unchanged from 0001437749-24-032618:notes:143]

[0001437749-25-002900:notes:144]
|  |  | Leases |  |
| Year ending March 31, |  |  |  |  |
| 2025 (remaining) |  | $ | 210 |  |
| 2026 |  |  | 1,005 |  |
| 2027 |  |  | 1,317 |  |
| 2028 |  |  | 793 |  |
| 2029 |  |  | 383 |  |
| Thereafter |  |  | 1,497 |  |
| Total minimum lease payments |  |  | 5,205 |  |
| Less: interest |  |  | (1,805 | ) |
| Present value of lease liabilities |  | $ | 3,400 |  |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001437749-25-002900:notes:145]
18. Commitments and Contingencies

[0001437749-25-002900:notes:146]
Legal Contingencies

[0001437749-25-002900:notes:147]
From time to time, the Company is involved in legal and administrative proceedings and claims of various types. The Company records a liability in its condensed consolidated financial statements for these matters when a loss is known or considered probable and the amount can be reasonably estimated. The Company reviews these estimates each accounting period as additional information is known and adjusts the loss provision when appropriate. If a matter is both probable to result in a liability and the amounts of loss can be reasonably estimated, the Company estimates and discloses the possible loss or range of loss to the extent necessary to make the condensed consolidated financial statements not misleading. If the loss is not probable or cannot be reasonably estimated, a liability is not recorded in its condensed consolidated financial statements.

[0001437749-25-002900:notes:148]
Other

[0001437749-25-002900:notes:149]
The Company enters into long-term construction contracts with customers that require the Company to obtain performance bonds. The Company is required to deposit an amount equivalent to some or all the face amount of the performance bonds into an escrow account until the termination of the bond. When the performance conditions are met, amounts deposited as collateral for the performance bonds are returned to the Company. In addition, the Company has various contractual arrangements in which minimum quantities of goods or services have been committed to be purchased on an annual basis.

[0001437749-25-002900:notes:150]
As of  December 31, 2024, the Company had $3.5 million of restricted cash included in long-term assets and $1.3 million of restricted cash included in current assets. As of  March 31, 2024, the Company had $1.3 million of restricted cash included in long term assets and $0.5 million of restricted cash included in current assets. These amounts included in restricted cash primarily represent deposits to secure letters of credit for various supply contracts and long-term projects or collateral deposits. These deposits are held in interest bearing accounts.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001437749-25-002900:notes:151]
[same as prior period, unchanged from 0001437749-24-032618:notes:151]

[0001437749-25-002900:notes:152]
The Company reports its financial results in two reportable business segments: Grid and Wind. In accordance with ASC 280, Segment Reporting, the Company aggregates five operating segments into the Grid reporting business segment for financial reporting purposes due to their similar operating and financial characteristics. The Company's operating segments reflect the way in which internally-reported financial information is used to make decisions and allocate resources.

[0001437749-25-002900:notes:153]
[same as prior period, unchanged from 0001437749-24-032618:notes:153]

[0001437749-25-002900:notes:154]
[same as prior period, unchanged from 0001437749-24-032618:notes:154]

[0001437749-25-002900:notes:155]
[same as prior period, unchanged from 0001437749-24-032618:notes:155]

[0001437749-25-002900:notes:156]
|  |  | Three Months Ended December 31, |  |  | Nine Months Ended December 31, |  |
|  |  | 2024 |  |  | 2023 |  |  | 2024 |  |  | 2023 |  |
| Revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Grid |  | $ | 52,306 |  |  | $ | 33,603 |  |  | $ | 131,578 |  |  | $ | 87,854 |  |
| Wind |  |  | 9,097 |  |  |  | 5,750 |  |  |  | 24,585 |  |  |  | 15,757 |  |
| Total |  | $ | 61,403 |  |  | $ | 39,353 |  |  | $ | 156,163 |  |  | $ | 103,611 |  |

[0001437749-25-002900:notes:157]
|  |  | Three Months Ended December 31, |  |  | Nine Months Ended December 31, |  |
|  |  | 2024 |  |  | 2023 |  |  | 2024 |  |  | 2023 |  |
| Operating income (loss): |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Grid |  | $ | 2,819 |  |  | $ | 268 |  |  | $ | 6,014 |  |  | $ | (2,383 | ) |
| Wind |  |  | 1,362 |  |  |  | 286 |  |  |  | 2,877 |  |  |  | (112 | ) |
| Unallocated corporate expenses |  |  | (2,866 | ) |  |  | (1,992 | ) |  |  | (11,621 | ) |  |  | (6,646 | ) |
| Total |  | $ | 1,315 |  |  | $ | (1,438 | ) |  | $ | (2,730 | ) |  | $ | (9,141 | ) |

[0001437749-25-002900:notes:158]
The accounting policies of the business segments are the same as those for the consolidated Company. The Company’s business segments have been determined in accordance with the Company’s internal management structure, which is organized based on operating activities. The Company evaluates performance based upon several factors, of which the primary financial measures are segment revenues and segment operating income (loss). The disaggregated financial results of the segments reflect allocation of certain functional expense categories consistent with the basis and manner in which Company management internally disaggregates financial information for the purpose of assisting in making internal operating decisions. In addition, certain corporate expenses which the Company does not believe are specifically attributable or allocable to either of the two business segments have been excluded from the segment operating income (loss).

[0001437749-25-002900:notes:159]
Unallocated corporate expenses consisted of net losses resulting from activity relating to both the NEPSI earnout and the Megatran make whole payment which resulted in $6.7 million in increases in the fair value of contingent consideration in the nine months ended  December 31, 2024. Unallocated corporate expenses consisted of a loss on contingent consideration of $0.9 million and $3.1 million in the three and nine months ended  December 31, 2023, respectively. Additionally, unallocated corporate expenses consisted of stock-based compensation expense of $2.9 million and $4.9 million in the three and nine months ended  December 31, 2024, respectively, and $1.1 million and $3.6 million in the three and nine months ended  December 31, 2023, respectively.

[0001437749-25-002900:notes:160]
Total assets for the two business segments as of  December 31, 2024 and  March 31, 2024, are as follows (in thousands):

[0001437749-25-002900:notes:161]
|  |  | December 31, 2024 |  |  | March 31, 2024 |  |
| Grid |  | $ | 212,583 |  |  | $ | 125,878 |  |
| Wind |  |  | 17,729 |  |  |  | 14,733 |  |
| Corporate assets |  |  | 79,966 |  |  |  | 92,160 |  |
| Total |  | $ | 310,278 |  |  | $ | 232,771 |  |


## us-gaap:NewAccountingPronouncementsAndChangesInAccountingPrinciplesTextBlock

[0001437749-25-002900:notes:162]
20. Recent Accounting Pronouncements

[0001437749-25-002900:notes:163]
In  November 2023, the FASB issued ASU 2023-07, Segment Reporting (Topic 280): Improvements to Reportable Segment Disclosures. The amendments in ASU 2023-07 improve the disclosures about a public entity’s reportable segments and address requests from investors for additional, more detailed information about a reportable segment’s expenses. Following the release of ASU 2023-07 in  November 2023, the effective date will be annual reporting periods beginning after  December 15, 2023. As of  December 31, 2024, the Company is evaluating the impact on its condensed consolidated financial statements.

[0001437749-25-002900:notes:164]
In  December 2023, the FASB issued ASU 2023-09, Income Taxes (Topic 740): Improvements to Income Tax Disclosures. The amendments in ASU 2023-09 address investor requests for more transparency about income tax information through improvements to income tax disclosures primarily related to the rate reconciliation and income taxes paid information. Following the release of ASU 2023-09 in  December 2023, the effective date will be annual reporting periods beginning after  December 15, 2024. As of  December 31, 2024, the Company is evaluating the impact on its condensed consolidated financial statements.

[0001437749-25-002900:notes:165]
In  March 2024, the FASB issued ASU 2024-02, Codification Improvements—Amendments to Remove References to the Concepts Statements. The amendments in ASU 2024-02 contain amendments to the Codification that remove references to various FASB Concepts Statements. Following the release of ASU 2024-02 in  March 2024, the effective date will be annual reporting periods beginning after  December 15, 2024. As of  December 31, 2024, the Company is evaluating the impact on its condensed consolidated financial statements.

[0001437749-25-002900:notes:166]
In  November 2024, the FASB issued ASU 2024-03, Income Statement—Reporting Comprehensive Income—Expense Disaggregation Disclosures. The amendments in ASU 2024-03 address investor requests for more disclosure of disaggregated financial reporting information about expenses presented in the income statement. Following the release of ASU 2024-03 in  November 2024, the effective date will be annual reporting periods beginning after  December 15, 2026. As of  December 31, 2024, the Company is evaluating the impact on its condensed consolidated financial statements.


## us-gaap:SubsequentEventsTextBlock

[0001437749-25-002900:notes:167]
21. Subsequent Events

[0001437749-25-002900:notes:168]
The Company has performed an evaluation of subsequent events through the time of filing this Quarterly Report on Form 10-Q with the SEC and has determined that there are no such events to report.
