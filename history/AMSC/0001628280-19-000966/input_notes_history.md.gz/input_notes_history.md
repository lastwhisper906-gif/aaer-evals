# AMSC note change history — 0001628280-18-013770 → 0001628280-19-000966


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2019-02-05):
[0001628280-19-000966:note_history:1]
As of December 31, 2018, the Company had $0.2 million of restricted cash included in long-term assets. These amounts included in restricted cash primarily represent deposits to secure letters of credit for various supply contracts. These deposits are held in interest bearing accounts.
  (was, 2018-11-06, similarity 0.9874):
[0001628280-18-013770:note_history:1]
As of September 30, 2018, the Company had $0.2 million of restricted cash included in long-term assets. These amounts included in restricted cash primarily represent deposits to secure letters of credit for various supply contracts. These deposits are held in interest bearing accounts.

- removed (2019-02-05):
[0001628280-18-013770:note_history:2]
On July 3, 2018, the Company, AMSC China and AMSC Austria entered into the Settlement Agreement with Sinovel. The Settlement Agreement settles the litigation and arbitration proceedings between the Company and Sinovel listed on Schedule 2 of the Settlement Agreement (the “Proceedings”), and any other civil claims, counterclaims, causes of action, rights and obligations directly or indirectly relating to the subject matters of the Proceedings and the contracts between the Company and Sinovel listed on Schedules 1 and 4 of the Settlement Agreement (the “Contracts”), subject to the exception described in Section 1.1 of the Settlement Agreement.  The Settlement Agreement was filed as Exhibit 10.1 to the Company’s Form 8-K filed with the Securities and Exchange Commission on July 9, 2018.

- removed (2019-02-05):
[0001628280-18-013770:note_history:3]
Under the terms of the Settlement Agreement, Sinovel has agreed to pay AMSC China an aggregate cash amount in RMB equivalent to $57.5 million, consisting of two installments. Sinovel paid the first installment of $32.5 million on July 4, 2018, and has agreed to the Second Payment of $25.0 million within ten (10) months after the District Court delivers the first sentence against Sinovel in the criminal case entitled United States v. Sinovel Wind Co., Ltd., Case Number 3:13-cr-00084-jdp. On July 6, 2018, the District Court delivered such sentence, and therefore the Second Payment is due by May 6, 2019. Mr. Wenyuan Wei, former Sinovel chairman and a current Sinovel shareholder, has delivered a letter of guarantee (the “Guarantee”) to the Company for the Second Payment should Sinovel fail to make such payment by the Second Payment Due Date.

- removed (2019-02-05):
[0001628280-18-013770:note_history:4]
In addition, pursuant to the terms of the Settlement Agreement, the Company and AMSC Austria have granted Sinovel a non-exclusive license for certain AMSC intellectual property to be used solely in Sinovel’s doubly fed wind turbines (the “License”). AMSC has agreed not to sue Sinovel, Sinovel’s power converter suppliers or Sinovel’s customers for use of the technology covered by the License. In the event that Sinovel or Mr. Wei does not make the Second Payment by the Second Payment Due Date, the Settlement Agreement provides that the License will terminate.

- removed (2019-02-05):
[0001628280-18-013770:note_history:5]
The Company and Sinovel have submitted withdrawal applications to terminate the Proceedings to the relevant Chinese courts and the Beijing Arbitration Commission. Subject to the Company and Sinovel complying with the terms of the Settlement Agreement, the Company and Sinovel have agreed not to re-institute any of the Proceedings. In addition, the Company and Sinovel have agreed to a mutual release and covenant not to sue covering all subject matters of the Proceedings and Contracts, effective upon the completion of the Second Payment.

- removed (2019-02-05):
[0001628280-18-013770:note_history:6]
The Company first considered the Settlement under ASC 606 to determine if the arrangement qualified for revenue accounting under ASC 606.  As Sinovel is not considered a customer that the Company is supplying goods or services to under ordinary terms, and the Settlement was a negotiation intended to release claims by both parties rather than for the procurement of product or services, the proceeds from the Settlement will not be treated as revenue and will be reported as other income, net of direct expenses, separately in Operating Income (Expense).  The Second Payment will be recorded in a similar manner when received.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2019-02-05):
[0001628280-19-000966:note_history:7]
These unaudited condensed consolidated financial statements of the Company have been prepared on a going concern basis in accordance with United States generally accepted accounting principles (“GAAP”) and the Securities and Exchange Commission’s (“SEC”) instructions to Form 10-Q. The going concern basis of presentation assumes that the Company will continue operations and will be able to realize its assets and discharge its liabilities and commitments in the normal course of business. Certain information and footnote disclosures normally included in the financial statements prepared in accordance with GAAP have been condensed or omitted pursuant to those instructions. The year-end condensed balance sheet data was derived from audited financial statements but does not include all disclosures required by GAAP. The unaudited condensed consolidated financial statements, in the opinion of management, reflect all adjustments (consisting of normal recurring adjustments) necessary for a fair statement of the results for the interim periods ended December 31, 2018 and 2017 and the financial position at December 31, 2018; however, these results are not necessarily indicative of results which may be expected for the full year. The interim condensed consolidated financial statements, and notes thereto, should be read in conjunction with the audited consolidated financial statements for the year ended March 31, 2018, and notes thereto, included in the Company’s annual report on Form 10-K for the year ended March 31, 2018 filed with the Securities and Exchange Commission on June 6, 2018.
  (was, 2018-11-06, similarity 0.9955):
[0001628280-18-013770:note_history:7]
These unaudited condensed consolidated financial statements of the Company have been prepared on a going concern basis in accordance with United States generally accepted accounting principles (“GAAP”) and the Securities and Exchange Commission’s (“SEC”) instructions to Form 10-Q. The going concern basis of presentation assumes that the Company will continue operations and will be able to realize its assets and discharge its liabilities and commitments in the normal course of business. Certain information and footnote disclosures normally included in the financial statements prepared in accordance with GAAP have been condensed or omitted pursuant to those instructions. The year-end condensed balance sheet data was derived from audited financial statements but does not include all disclosures required by GAAP. The unaudited condensed consolidated financial statements, in the opinion of management, reflect all adjustments (consisting of normal recurring adjustments) necessary for a fair statement of the results for the interim periods ended September 30, 2018 and 2017 and the financial position at September 30, 2018; however, these results are not necessarily indicative of results which may be expected for the full year. The interim condensed consolidated financial statements, and notes thereto, should be read in conjunction with the audited consolidated financial statements for the year ended March 31, 2018, and notes thereto, included in the Company’s annual report on Form 10-K for the year ended March 31, 2018 filed with the Securities and Exchange Commission on June 6, 2018.

- changed (2019-02-05):
[0001628280-19-000966:note_history:8]
The Company has experienced recurring operating losses and as of December 31, 2018, the Company had an accumulated deficit of $953.2 million. In addition, the Company has experienced recurring negative operating cash flows.  At December 31, 2018, the Company had cash and cash equivalents of $80.0 million, with no outstanding debt other than ordinary trade payables. Cash provided by operations for the nine months ended December 31, 2018 was $47.8 million.  The current period results include the net gain received from the first and second installments of the Sinovel settlement of $53.7 million in the nine month period ended December 31, 2018.
  (was, 2018-11-06, similarity 0.8795):
[0001628280-18-013770:note_history:8]
The Company has experienced recurring operating losses and as of September 30, 2018, the Company had an accumulated deficit of $970.5 million. In addition, the Company has experienced recurring negative operating cash flows.  At September 30, 2018, the Company had cash and cash equivalents of $56.2 million, with no outstanding debt other than ordinary trade payables. Cash provided by operations for the six months ended September 30, 2018 was $23.6 million.  The current period results include the net gain received from the first installment of the Sinovel settlement of $28.7 million in the three month period ended September 30, 2018.

- added (2019-02-05):
[0001628280-19-000966:note_history:9]
On July 3, 2018, the Company and its wholly-owned subsidiaries Suzhou AMSC Superconductor Co. Ltd. (“AMSC China”) and AMSC Austria GMBH (“AMSC Austria”) entered into a settlement agreement (the “Settlement Agreement”) with Sinovel Wind Group Co., Ltd. (“Sinovel”). The Settlement Agreement settles the litigation and arbitration proceedings between the Company and Sinovel.  Under the terms of the Settlement Agreement, Sinovel agreed to pay AMSC China an aggregate cash amount in Renminbi (“RMB”) equivalent to $57.5 million, consisting of two installments. Sinovel paid the first installment of the RMB equivalent of $32.5 million on July 4, 2018, which was repatriated to the Company during the nine months ended December 31, 2018, and paid the second installment of the RMB equivalent of $25.0 million on December 27, 2018.

- changed (2019-02-05):
[0001628280-19-000966:note_history:10]
On February 1, 2018, ASC Devens LLC (the “Seller”), a wholly-owned subsidiary of the Company, entered into a Purchase and Sale Agreement (the “PSA”) with 64 Jackson, LLC (the “Purchaser”) and Stewart Title Guaranty Company (“Escrow Agent”), to effectuate the sale of certain real property located at 64 Jackson Road, Devens, Massachusetts, including the building that had served as the Company’s headquarters (collectively, the “Property”), in exchange for total consideration of $23.0 million, composed of (i) cash consideration of $17.0 million, and (ii) a $6.0 million subordinated secured commercial promissory note payable to the Company (the “Seller Note”). Subsequently, the Seller, the Purchaser and Jackson 64 MGI, LLC (“Assignee”) entered into an Assignment of Purchase and Sale Agreement (the “Assignment Agreement”), pursuant to which the Purchaser assigned all of its rights and interests in the PSA to the Assignee and the Assignee agreed to assume all of the Purchaser’s obligations and liabilities under the PSA. The transaction closed on March 28, 2018, at which time the Company received, from the Assignee, cash consideration, net of certain agreed upon closing costs, of $16.9 million, and the Seller Note at an interest rate of 1.96%. The Seller Note is secured by a subordinated second mortgage on the Property and a subordinated second assignment of leases and rents.
  (was, 2018-11-06, similarity 0.7195):
[0001628280-18-013770:note_history:10]
On February 1, 2018, ASC Devens LLC (the "Seller"), a wholly-owned subsidiary of the Company, entered into a Purchase and Sale Agreement (the “PSA”) with 64 Jackson, LLC (the “Purchaser”) and Stewart Title Guaranty Company (“Escrow Agent”), to effectuate the sale of certain real property located at 64 Jackson Road, Devens, Massachusetts, including the building that had served as the Company’s headquarters (collectively, the “Property”), in exchange for total consideration of $23.0 million, composed of (i) cash consideration of $17.0 million, and (ii) a $6.0 million subordinated secured commercial promissory note payable to the Company (the "Seller Note"). Subsequently, the Seller, the Purchaser and Jackson 64 MGI, LLC (“Assignee”) entered into an Assignment of Purchase and Sale Agreement (the “Assignment Agreement”), pursuant to which the Purchaser assigned all of its rights and interests in the PSA to the Assignee and the Assignee agreed to assume all of the Purchaser’s obligations and liabilities under the PSA. The transaction closed on March 28, 2018, at which time the Company received, from the Assignee, cash consideration, net of certain agreed upon closing costs, of $16.9 million, and the Seller Note at an interest rate of 1.96%. The Seller Note is secured by a subordinated second mortgage on the Property and a subordinated second assignment of leases and rents.

- changed (2019-02-05):
[0001628280-19-000966:note_history:11]
In December 2015, the Company entered into a set of strategic agreements valued at approximately $210.0 million with Inox Wind Ltd. (“Inox” or “Inox Wind”), which includes a multi-year supply contract pursuant to which the Company will supply electrical control systems to Inox and a license agreement allowing Inox to manufacture a limited number of electrical control systems.  After Inox purchases the specified number of electrical control systems required under the terms of the supply contract, Inox agreed that the Company will continue as Inox’s preferred supplier and Inox will be required to purchase from the Company a majority of its electrical control systems requirements for an additional three-year period.
  (was, 2018-11-06, similarity 0.9846):
[0001628280-18-013770:note_history:11]
In December 2015, the Company entered into a set of strategic agreements valued at approximately $210.0 million with Inox Wind Ltd. (“Inox” or "Inox Wind"), which includes a multi-year supply contract pursuant to which the Company will supply electrical control systems to Inox and a license agreement allowing Inox to manufacture a limited number of electrical control systems.  After Inox purchases the specified number of electrical control systems required under the terms of the supply contract, Inox agreed that the Company will continue as Inox’s preferred supplier and Inox will be required to purchase from the Company a majority of its electrical control systems requirements for an additional three-year period.

- changed (2019-02-05):
[0001628280-19-000966:note_history:12]
The Company believes that based on the information presented above and its quarterly management assessment, it has sufficient liquidity to fund its operations and capital expenditures for the next twelve months following the issuance of the financial statements for the three and nine months ended December 31, 2018. The Company’s liquidity is highly dependent on its ability to increase revenues, including its ability to collect revenues under its agreements with Inox, its ability to control its operating costs, and its ability to raise additional capital, if necessary. There can be no assurance that the Company will be able to continue to raise additional capital, on favorable terms or at all, from other sources or execute on any other means of improving liquidity described above.
  (was, 2018-11-06, similarity 0.9732):
[0001628280-18-013770:note_history:12]
The Company believes that based on the information presented above and its quarterly management assessment, it has sufficient liquidity to fund its operations and capital expenditures for the next twelve months following the issuance of the financial statements for the three and six months ended September 30, 2018. The Company’s liquidity is highly dependent on its ability to increase revenues, including its ability to collect revenues under its agreements with Inox, its ability to control its operating costs, and its ability to raise additional capital, if necessary. There can be no assurance that the Company will be able to continue to raise additional capital, on favorable terms or at all, from other sources or execute on any other means of improving liquidity described above.

- removed (2019-02-05):
[0001628280-18-013770:note_history:13]
From April 1, 2011 through the date of this filing, the Company has reduced its global workforce substantially.  As of September 30, 2018, the Company had a global workforce of 225 persons.  The Company plans to closely monitor its expenses and, if required, expects to further reduce operating costs and capital spending to enhance liquidity.

- removed (2019-02-05):
[0001628280-18-013770:note_history:14]
Over the last several years, the Company has entered into several debt and equity financing arrangements in order to raise capital.  Since April 1, 2012, the Company has generated aggregate cash flows from financing activities of $84.9 million.  Included in this amount are proceeds of approximately $17.0 million after deducting underwriting discounts and commissions and offering expenses payable by the Company, from the Company's equity offering completed on May 10, 2017, which includes the subsequent exercise by the underwriters of their option in full to purchase additional shares.  The Company terminated its At Market Issuance Sales Agreement ("ATM") with FBR Capital Markets & Co. in conjunction with this equity offering.  See Note 14 “Stockholders' Equity” for further discussion of these financing arrangements.

- removed (2019-02-05):
[0001628280-18-013770:note_history:15]
On July 3, 2018, the Company and its wholly-owned subsidiaries Suzhou AMSC Superconductor Co. Ltd. (“AMSC China”) and AMSC Austria GMBH (“AMSC Austria”) entered into a settlement agreement (the “Settlement Agreement”) with Sinovel Wind Group Co., Ltd. (“Sinovel”). The Settlement Agreement settles the litigation and arbitration proceedings between the Company and Sinovel, as further described in Note 15 “Commitments and Contingencies".  Under the terms of the Settlement Agreement, Sinovel has agreed to pay AMSC China an aggregate cash amount in Renminbi ("RMB") equivalent to $57.5 million, consisting of two installments. Sinovel paid the first installment of $32.5 million on July 4, 2018, which was repatriated to the Company during the six months ended September 30, 2018, and has agreed to pay the second installment of $25.0 million (the “Second Payment”) within ten (10) months after the U.S. District Court for the Western District of Wisconsin (the “District Court”) delivers the first sentence against Sinovel in the criminal case entitled United States v. Sinovel Wind Co., Ltd., Case Number 3:13-cr-00084-jdp. On July 6, 2018, the District Court delivered such sentence, and therefore the Second Payment is due by May 6, 2019 (the “Second Payment Due Date”).


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2019-02-05):
[0001628280-19-000966:note_history:16]
|  | Three Months Ended December 31, 2018 |  | Nine Months Ended December 31, 2018 |
| Product Line: | Grid |  | Wind |  | Grid |  | Wind |
| Equipment and systems | $ | 4,614 |  |  | $ | 7,215 |  |  | $ | 17,571 |  |  | $ | 17,925 |  |
| Services and technology development | 2,212 |  |  | 93 |  |  | 5,754 |  |  | 368 |  |
| Total | $ | 6,826 |  |  | $ | 7,308 |  |  | $ | 23,325 |  |  | $ | 18,293 |  |
| Region: |  |  |  |  |  |  |  |
| Americas | $ | 3,771 |  |  | $ | 36 |  |  | $ | 16,319 |  |  | $ | 82 |  |
| Asia Pacific | 2,815 |  |  | 7,263 |  |  | 5,930 |  |  | 18,136 |  |
| EMEA | 240 |  |  | 9 |  |  | 1,076 |  |  | 75 |  |
| Total | $ | 6,826 |  |  | $ | 7,308 |  |  | $ | 23,325 |  |  | $ | 18,293 |  |
  (was, 2018-11-06, similarity 0.9809):
[0001628280-18-013770:note_history:16]
|  | Three Months Ended September 30, 2018 |  | Six Months Ended September 30, 2018 |
| Product Line: | Grid |  | Wind |  | Grid |  | Wind |
| Equipment and systems | $ | 5,503 |  |  | $ | 7,219 |  |  | $ | 12,957 |  |  | $ | 10,711 |  |
| Services and technology development | 2,066 |  |  | 88 |  |  | 3,541 |  |  | 274 |  |
| Total | $ | 7,569 |  |  | $ | 7,307 |  |  | $ | 16,498 |  |  | $ | 10,985 |  |
| Region: |  |  |  |  |  |  |  |
| Americas | $ | 5,052 |  |  | $ | 24 |  |  | $ | 12,548 |  |  | $ | 47 |  |
| Asia Pacific | 2,308 |  |  | 7,278 |  |  | 3,115 |  |  | 10,873 |  |
| EMEA | 209 |  |  | 5 |  |  | 835 |  |  | 65 |  |
| Total | $ | 7,569 |  |  | $ | 7,307 |  |  | $ | 16,498 |  |  | $ | 10,985 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2019-02-05):
[0001628280-19-000966:note_history:17]
On April 1, 2018, the Company adopted Accounting Standards Codification (“ASC”) 606, Revenue from Contracts with Customers, and all the related amendments and applied it to all contracts that were not completed as of April 1, 2018 using the modified retrospective method. The Company recognized the cumulative effect of initially applying the new revenue standard as an adjustment of less than $0.1 million to the opening balance of accumulated deficit. Prior period amounts have not been restated and continue to be reported under the accounting standards in effect for those periods.
  (was, 2018-11-06, similarity 0.9912):
[0001628280-18-013770:note_history:17]
On April 1, 2018, the Company adopted Accounting Standards Codification ("ASC") 606, Revenue from Contracts with Customers, and all the related amendments and applied it to all contracts that were not completed as of April 1, 2018 using the modified retrospective method. The Company recognized the cumulative effect of initially applying the new revenue standard as an adjustment of less than $0.1 million to the opening balance of accumulated deficit. Prior period amounts have not been restated and continue to be reported under the accounting standards in effect for those periods.

- changed (2019-02-05):
[0001628280-19-000966:note_history:18]
In addition, the FASB issued Accounting Standards Update (“ASU”) 2017-05, Other Income - Gains and Losses from the Derecognition of Non-financial Assets (Subtopic 610-20), in February 2017, to amend ASC 610-20, Other Income - Gains and Losses from the Derecognition of Non-financial Assets (issued at the same time as ASC 606), which provides a model for the measurement and recognition of gains and losses on the sale of non-financial assets, such as property and equipment, including real estate. As a result of adopting ASU 2017-05 on April 1, 2018, the Company recognized an adjustment to the opening balance of accumulated deficit for the deferred gain from the March 28, 2018 sale of the Company's former headquarters in Devens, Massachusetts in the amount of $0.1 million.
  (was, 2018-11-06, similarity 0.9933):
[0001628280-18-013770:note_history:18]
In addition, the FASB issued Accounting Standards Update ("ASU") 2017-05, Other Income - Gains and Losses from the Derecognition of Non-financial Assets (Subtopic 610-20), in February 2017, to amend ASC 610-20, Other Income - Gains and Losses from the Derecognition of Non-financial Assets (issued at the same time as ASC 606), which provides a model for the measurement and recognition of gains and losses on the sale of non-financial assets, such as property and equipment, including real estate. As a result of adopting ASU 2017-05 on April 1, 2018, the Company recognized an adjustment to the opening balance of accumulated deficit for the deferred gain from the March 28, 2018 sale of the Company's former headquarters in Devens, Massachusetts in the amount of $0.1 million.

- changed (2019-02-05):
[0001628280-19-000966:note_history:19]
Included in the opening adjustment are reclassifications for accounts receivable, deferred program costs and deferred revenue for previous balances related to agreements that no longer meet the definition of a customer contract under ASC 606.  The impact of adoption on the Company’s opening balances and for the three and nine months ended December 31, 2018, in all financial statement line items impacted by ASC 606 was immaterial from the amount that would have been reported under the previous guidance.
  (was, 2018-11-06, similarity 0.9576):
[0001628280-18-013770:note_history:19]
Included in the opening adjustment are reclassifications for accounts receivable, deferred program costs and deferred revenue for previous balances related to agreements that no longer meet the definition of a customer contract under ASC 606.  The impact of adoption on the Company’s opening balances and for the three and six months ended September 30, 2018, in all financial statement line items impacted by ASC 606 was immaterial from the amount that would have been reported under the previous guidance.

- added (2019-02-05):
[0001628280-19-000966:note_history:20]
The Company’s revenues in its Grid segment are derived primarily through enabling the transmission and distribution of power, providing planning services that allow it to identify power grid needs and risks, and developing ship protection systems for the U.S. Navy. The Company’s revenues in its Wind segment are derived primarily through supplying advanced power electronics and control systems, licensing our highly engineered wind turbine designs, and providing extensive customer support services to wind turbine manufacturers.  The Company records revenue based on a five-step model in accordance with ASC 606. For its customer contracts, the Company identifies the performance obligations, determines the transaction price, allocates the contract transaction price to the performance obligations, and recognizes the revenue when (or as) control of goods or services is transferred to the customer.  As of December 31, 2018, 87% of revenue was recognized at the point in time when control transferred to the customer, with the remainder being recognized over time.

- changed (2019-02-05):
[0001628280-19-000966:note_history:21]
|  | Three Months Ended December 31, 2018 |  | Nine Months Ended December 31, 2018 |
| Product Line: | Grid |  | Wind |  | Grid |  | Wind |
| Equipment and systems | $ | 4,614 |  |  | $ | 7,215 |  |  | $ | 17,571 |  |  | $ | 17,925 |  |
| Services and technology development | 2,212 |  |  | 93 |  |  | 5,754 |  |  | 368 |  |
| Total | $ | 6,826 |  |  | $ | 7,308 |  |  | $ | 23,325 |  |  | $ | 18,293 |  |
| Region: |  |  |  |  |  |  |  |
| Americas | $ | 3,771 |  |  | $ | 36 |  |  | $ | 16,319 |  |  | $ | 82 |  |
| Asia Pacific | 2,815 |  |  | 7,263 |  |  | 5,930 |  |  | 18,136 |  |
| EMEA | 240 |  |  | 9 |  |  | 1,076 |  |  | 75 |  |
| Total | $ | 6,826 |  |  | $ | 7,308 |  |  | $ | 23,325 |  |  | $ | 18,293 |  |
  (was, 2018-11-06, similarity 0.9809):
[0001628280-18-013770:note_history:21]
|  | Three Months Ended September 30, 2018 |  | Six Months Ended September 30, 2018 |
| Product Line: | Grid |  | Wind |  | Grid |  | Wind |
| Equipment and systems | $ | 5,503 |  |  | $ | 7,219 |  |  | $ | 12,957 |  |  | $ | 10,711 |  |
| Services and technology development | 2,066 |  |  | 88 |  |  | 3,541 |  |  | 274 |  |
| Total | $ | 7,569 |  |  | $ | 7,307 |  |  | $ | 16,498 |  |  | $ | 10,985 |  |
| Region: |  |  |  |  |  |  |  |
| Americas | $ | 5,052 |  |  | $ | 24 |  |  | $ | 12,548 |  |  | $ | 47 |  |
| Asia Pacific | 2,308 |  |  | 7,278 |  |  | 3,115 |  |  | 10,873 |  |
| EMEA | 209 |  |  | 5 |  |  | 835 |  |  | 65 |  |
| Total | $ | 7,569 |  |  | $ | 7,307 |  |  | $ | 16,498 |  |  | $ | 10,985 |  |

- changed (2019-02-05):
[0001628280-19-000966:note_history:22]
As of December 31, 2018 and March 31, 2018, the Company’s contract assets and liabilities primarily relate to the timing differences between cash received from a customer in connection with contractual rights to invoicing and the timing of revenue recognition following completion of performance obligations. The Company's accounts receivable balance is made up entirely of customer contract related balances.  Changes in the Company’s contract assets, which are included in “Unbilled AR” and “Deferred program costs” (see Note 7, “Accounts Receivable” and Note 8, “Inventory” for a reconciliation to the condensed consolidated balance sheet) and contract liabilities, which are included in the current portion and long term portion of “deferred revenue” in the Company’s condensed consolidated balance sheets, are as follows:
  (was, 2018-11-06, similarity 0.9182):
[0001628280-18-013770:note_history:22]
As of September 30, 2018 and March 31, 2018, the Company’s contract assets and liabilities primarily relate to the timing differences between cash received from a customer in connection with contractual rights to invoicing and the timing of revenue recognition following completion of performance obligations. The Company's accounts receivable balance is made up entirely of customer contract related balances.  Changes in the Company’s contract assets, which are included in “Unbilled AR” and "Deferred program costs" (see Note 7, “Accounts Receivable” and Note 8, "Inventory" for a reconciliation to the condensed consolidated balance sheet) and contract liabilities, which are included in the current portion and long term portion of “deferred revenue” in the Company’s condensed consolidated balance sheets, are as follows:

- changed (2019-02-05):
[0001628280-19-000966:note_history:23]
|  | Unbilled AR |  | Deferred Program Costs |  | Contract Liabilities |
| Beginning balance as of March 31, 2018 | $ | 3,016 |  |  | $ | 2,567 |  |  | $ | 21,937 |  |
| Impact of adoption of ASC 606 | — |  |  | (1,599 | ) |  | (2,657 | ) |
| Increases for costs incurred to fulfill performance obligations | — |  |  | 1,461 |  |  | — |  |
| Increase (decrease) due to customer billings | (11,063 | ) |  | — |  |  | 11,167 |  |
| Decrease due to cost recognition on completed performance obligations | — |  |  | (1,132 | ) |  | — |  |
| Increase (decrease) due to recognition of revenue based on transfer of control of performance obligations | 9,722 |  |  | (9 | ) |  | (11,345 | ) |
| Other changes and FX impact | (53 | ) |  | 8 |  |  | (1,040 | ) |
| Ending balance as of December 31, 2018 | $ | 1,622 |  |  | $ | 1,296 |  |  | $ | 18,062 |  |
  (was, 2018-11-06, similarity 0.9952):
[0001628280-18-013770:note_history:23]
|  | Unbilled AR |  | Deferred Program Costs |  | Contract Liabilities |
| Beginning balance as of March 31, 2018 | $ | 3,016 |  |  | $ | 2,567 |  |  | $ | 21,937 |  |
| Impact of adoption of ASC 606 | — |  |  | (1,599 | ) |  | (2,657 | ) |
| Increases for costs incurred to fulfill performance obligations | — |  |  | 1,267 |  |  | — |  |
| Increase (decrease) due to customer billings | (7,886 | ) |  | — |  |  | 7,828 |  |
| Decrease due to cost recognition on completed performance obligations | — |  |  | (1,033 | ) |  | — |  |
| Increase (decrease) due to recognition of revenue based on transfer of control of performance obligations | 7,439 |  |  | (9 | ) |  | (8,296 | ) |
| Other changes and FX impact | (19 | ) |  | 24 |  |  | (864 | ) |
| Ending balance as of September 30, 2018 | $ | 2,550 |  |  | $ | 1,217 |  |  | $ | 17,948 |  |

- changed (2019-02-05):
[0001628280-19-000966:note_history:24]
The Company’s remaining performance obligations represent the unrecognized revenue value of the Company’s contractual commitments. The Company’s performance obligations may vary significantly each reporting period based on the timing of major new contractual commitments. As of December 31, 2018, the Company had outstanding performance obligations on existing contracts under ASC 606 to be recognized in the next twelve months of approximately $36.8 million.  There are also approximately $12.9 million of outstanding performance obligations to be recognized over a period of thirteen to sixty months.  The remaining performance obligations are subject to customer actions and therefore the timing of revenue recognition cannot be reasonably estimated.  The twelve month performance obligations include anticipated shipments to Inox based on the twelve month rolling forecast provided by Inox on the multi-year supply contract. The quantities specified in any forecast provided by Inox related to the multi-year supply contract are firm and irrevocable for the first three months of a twelve month rolling forecast. The timing of the performance obligations beyond the Inox twelve month provided forecast are not determinable and therefore are not included in the total remaining performance obligations.
  (was, 2018-11-06, similarity 0.9973):
[0001628280-18-013770:note_history:24]
The Company’s remaining performance obligations represent the unrecognized revenue value of the Company’s contractual commitments. The Company’s performance obligations may vary significantly each reporting period based on the timing of major new contractual commitments. As of September 30, 2018, the Company had outstanding performance obligations on existing contracts under ASC 606 to be recognized in the next twelve months of approximately $52.5 million.  There are also approximately $7.1 million of outstanding performance obligations to be recognized over a period of thirteen to sixty months.  The remaining performance obligations are subject to customer actions and therefore the timing of revenue recognition cannot be reasonably estimated.  The twelve month performance obligations include anticipated shipments to Inox based on the twelve month rolling forecast provided by Inox on the multi-year supply contract. The quantities specified in any forecast provided by Inox related to the multi-year supply contract are firm and irrevocable for the first three months of a twelve month rolling forecast. The timing of the performance obligations beyond the Inox twelve month provided forecast are not determinable and therefore are not included in the total remaining performance obligations.

- changed (2019-02-05):
[0001628280-19-000966:note_history:25]
The following table sets forth customers who represented 10% or more of the Company’s total revenues for the three and nine months ended December 31, 2018 and 2017:
  (was, 2018-11-06, similarity 0.9677):
[0001628280-18-013770:note_history:25]
The following table sets forth customers who represented 10% or more of the Company’s total revenues for the three and six months ended September 30, 2018 and 2017:

- added (2019-02-05):
[0001628280-19-000966:note_history:26]
|  | Reportable |  | Three Months EndedDecember 31, |  | Nine Months EndedDecember 31, |
|  | Segment |  | 2018 |  | 2017 |  | 2018 |  | 2017 |
| Inox Wind Limited | Wind |  | 47 | % |  | 15 | % |  | 40 | % |  | 27 | % |
| Vestas | Grid |  | <10 % |  |  | 27 | % |  | 15 | % |  | 11 | % |
| SSE Generation Ltd. | Grid |  | <10 % |  |  | 17 | % |  | <10 % |  |  | <10 % |  |
| Fuji Bridex Pte Ltd | Grid |  | 17 | % |  | — | % |  | <10 % |  |  | — | % |

- removed (2019-02-05):
[0001628280-18-013770:note_history:27]
The Company’s revenues in its Grid segment are derived primarily through transmitting and distributing power, providing planning services that allow it to identify power grid needs and risks, and developing ship protection systems for the U.S. Navy. The Company’s revenues in its Wind segment are derived primarily through supplying advanced power electronics and control systems, licensing our highly engineered wind turbine designs, and providing extensive customer support services to wind turbine manufacturers.  The Company records revenue based on a five-step model in accordance with ASC 606. For its customer contracts, the Company identifies the performance obligations, determines the transaction price, allocates the contract transaction price to the performance obligations, and recognizes the revenue when (or as) control of goods or services is transferred to the customer.  As of September 30, 2018, 87% of revenue was recognized at the point in time when control transferred to the customer, with the remainder being recognized over time.

- removed (2019-02-05):
[0001628280-18-013770:note_history:28]
|  | Reportable |  | Three months ended September 30, |  | Six months ended September 30, |
|  | Segment |  | 2018 |  | 2017 |  | 2018 |  | 2017 |
| Inox Wind Limited | Wind |  | 45 | % |  | 46 | % |  | 36 | % |  | 35 | % |
| Vestas | Grid |  | 11 | % |  | — | % |  | 23 | % |  | — | % |
| Quanta Power | Grid |  | 12 | % |  | — | % |  | <10% |  |  | — | % |
| U.S. Navy | Grid |  | <10% |  |  | — | % |  | <10% |  |  | 16 | % |
| YMC Inc. | Grid |  | — | % |  | 15 | % |  | — | % |  | <10% |  |
