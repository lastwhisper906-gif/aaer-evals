# AMSC 8-K — 0001628280-19-000964 filed 2019-02-05

## item codes, every 8-K on or before 2019-02-05

- 2019-02-05 0001628280-19-000964 — 2.02, 8.01, 9.01
- 2018-11-06 0001628280-18-013765 — 2.02, 9.01
- 2018-10-31 0001628280-18-013204 — 1.01
- 2018-08-01 0001628280-18-010196 — 5.07
- 2018-07-31 0001628280-18-009846 — 2.02, 9.01
- 2018-07-09 0001193125-18-214745 — 1.01, 9.01
- 2018-07-03 0001628280-18-009075 — 5.02, 9.01
- 2018-06-14 0001628280-18-007877 — 5.02
- 2018-06-06 0001628280-18-007643 — 2.02, 9.01
- 2018-04-10 0001628280-18-004141 — 5.02
- 2018-04-03 0001628280-18-003952 — 2.01, 9.01
- 2018-02-05 0001628280-18-000989 — 2.02, 9.01
- 2018-02-01 0001628280-18-000826 — 1.01, 9.01
- 2017-11-07 0001628280-17-011076 — 2.02, 9.01
- 2017-09-26 0001628280-17-009444 — 3.02, 8.01
- 2017-08-08 0001628280-17-008329 — 2.02, 9.01
- 2017-08-01 0001628280-17-007765 — 5.02, 5.07
- 2017-07-03 0001193125-17-221140 — 5.02, 9.01
- 2017-05-26 0001193125-17-185503 — 8.01, 9.01
- 2017-05-25 0001628280-17-005914 — 2.02, 9.01 — amendment of 0001628280-17-005884
- 2017-05-25 0001628280-17-005884 — 2.02, 9.01
- 2017-05-10 0001193125-17-165924 — 8.01, 9.01
- 2017-05-09 0001193125-17-164273 — 5.02
- 2017-05-04 0001193125-17-158639 — 1.02, 8.01
- 2017-04-26 0001193125-17-139493 — 2.02, 9.01
- 2017-04-04 0001193125-17-109748 — 2.05, 5.02, 9.01
- 2017-02-06 0001628280-17-000899 — 2.02, 9.01
- 2017-01-27 0001193125-17-021808 — 1.01, 2.02, 9.01
- 2016-11-02 0001628280-16-020598 — 2.02, 9.01
- 2016-09-16 0001193125-16-712301 — 5.02
- 2016-08-23 0001193125-16-688767 — 8.01
- 2016-08-09 0001628280-16-018763 — 2.02, 9.01
- 2016-08-02 0001193125-16-668417 — 5.02, 5.07, 9.01
- 2016-05-31 0001564590-16-020114 — 2.02, 9.01
- 2016-05-18 0001193125-16-594515 — 5.02
- 2016-03-08 0001193125-16-496113 — 1.01
- 2016-02-09 0001193125-16-454775 — 2.02, 9.01
- 2015-12-17 0001193125-15-405566 — 1.01
- 2015-11-03 0001193125-15-363413 — 2.02, 9.01
- 2015-08-31 0001193125-15-307558 — 1.01
- 2015-08-05 0001193125-15-277824 — 2.02, 9.01
- 2015-07-31 0001193125-15-273009 — 5.07
- 2015-06-26 0001193125-15-237190 — 5.02
- 2015-06-09 0001193125-15-218028 — 8.01
- 2015-05-28 0001193125-15-202933 — 2.02, 9.01
- 2015-04-28 0001193125-15-153319 — 8.01, 9.01
- 2015-04-23 0001193125-15-144123 — 2.02, 8.01, 9.01
- 2015-04-23 0001193125-15-143608 — 8.01
- 2015-04-10 0001193125-15-126160 — 8.01
- 2015-03-24 0001193125-15-103436 — 5.03, 9.01
- 2015-03-18 0001193125-15-097034 — 5.07
- 2015-02-05 0001193125-15-034499 — 2.02, 9.01
- 2015-01-29 0001193125-15-024629 — 2.02, 9.01
- 2015-01-21 0001193125-15-016287 — 3.01, 8.01
- 2015-01-06 0001193125-15-002902 — 5.02
- 2014-12-22 0001193125-14-450591 — 1.01, 2.03, 3.02, 9.01
- 2014-11-13 0001193125-14-410207 — 1.01, 9.01
- 2014-11-07 0001193125-14-402383 — 1.02, 7.01, 9.01
- 2014-11-06 0001193125-14-399779 — 2.02, 9.01
- 2014-10-01 0001193125-14-360072 — 2.02, 8.01, 9.01
- 2014-09-04 0001193125-14-331411 — 8.01
- 2014-08-21 0001193125-14-317133 — 1.01
- 2014-08-06 0001193125-14-298306 — 5.02, 5.07, 9.01
- 2014-08-05 0001193125-14-294647 — 2.02, 9.01
- 2014-07-16 0001193125-14-269902 — 8.01
- 2014-06-23 0001193125-14-244592 — 3.02, 8.01
- 2014-06-05 0001193125-14-226459 — 2.02, 9.01
- 2014-06-05 0001193125-14-226457 — 1.01, 9.01
- 2014-03-19 0001193125-14-106558 — 2.05
- 2014-03-03 0001193125-14-078917 — 1.01, 3.02, 9.01
- 2014-02-28 0001193125-14-077480 — 8.01, 9.01
- 2014-02-06 0001193125-14-037960 — 2.02, 8.01, 9.01
- 2013-11-20 0001193125-13-447829 — 3.02, 8.01
- 2013-11-18 0001193125-13-444697 — 1.01, 2.03, 3.02, 9.01
- 2013-11-07 0001193125-13-431705 — 2.02, 9.01
- 2013-10-09 0001193125-13-395362 — 1.01, 2.03, 3.02, 9.01
- 2013-09-25 0001193125-13-378481 — 5.02, 9.01
- 2013-08-21 0001193125-13-341566 — 4.01, 9.01
- 2013-08-07 0001193125-13-323082 — 2.02, 9.01
- 2013-08-02 0001193125-13-317278 — 5.02, 5.07
- 2013-06-14 0001193125-13-258758 — 2.02, 9.01
- 2013-04-01 0001193125-13-136714 — 2.02, 8.01, 9.01
- 2013-02-20 0001193125-13-067218 — 5.02, 9.01
- 2013-02-14 0001193125-13-060131 — 1.01, 9.01
- 2013-02-11 0001193125-13-048784 — 2.02, 9.01
- 2013-01-08 0001193125-13-006861 — 5.02, 9.01
- 2012-12-21 0001193125-12-511592 — 1.01, 2.03, 3.02, 9.01
- 2012-11-28 0001193125-12-483317 — 2.05, 5.02, 7.01, 9.01
- 2012-11-06 0001193125-12-453359 — 2.02, 9.01
- 2012-08-02 0001193125-12-330534 — 2.02, 9.01
- 2012-07-27 0001193125-12-318790 — 5.02, 5.07, 9.01
- 2012-06-06 0001193125-12-261030 — 1.01, 2.02, 2.03, 3.02, 5.02, 9.01
- 2012-05-09 0001193125-12-222210 — 5.02
- 2012-04-20 0001193125-12-172045 — 8.01
- 2012-04-13 0001193125-12-162694 — 2.02, 8.01, 9.01
- 2012-04-04 0001193125-12-149102 — 1.01, 2.02, 2.03, 3.02, 9.01
- 2012-02-09 0001193125-12-048009 — 2.02, 9.01
- 2012-02-06 0001193125-12-041344 — 5.07 — amendment of 0000950123-11-102495
- 2011-12-08 0000950123-11-102495 — 5.07
- 2011-11-29 0000950123-11-100822 — 2.05
- 2011-11-09 0000950123-11-096775 — 2.02, 9.01
- 2011-10-31 0000950123-11-093390 — 1.02, 9.01
- 2011-10-07 0000950123-11-089221 — 8.01
- 2011-10-03 0000950123-11-088315 — 7.01
- 2011-09-23 0000950123-11-086288 — 2.02, 9.01
- 2011-09-15 0000950123-11-084585 — 7.01
- 2011-09-06 0000950123-11-082736 — 7.01
- 2011-08-18 0000950123-11-078526 — 3.01, 7.01, 9.01
- 2011-08-11 0000950123-11-075905 — 5.02
- 2011-08-11 0000950123-11-075904 — 2.02, 2.05, 9.01
- 2011-07-11 0000950123-11-064934 — 2.02, 4.02, 9.01
- 2011-06-30 0000950123-11-063287 — 1.01, 3.02, 9.01
- 2011-06-21 0000950123-11-060491 — 3.01, 7.01, 9.01
- 2011-06-13 0000950123-11-058656 — 1.01, 9.01
- 2011-05-24 0000950123-11-053517 — 5.02, 9.01
- 2011-04-05 0001299933-11-001020 — 2.02, 9.01
- 2011-03-15 0000950123-11-025580 — 5.02
- 2011-03-14 0000950123-11-025205 — 1.01, 3.02, 9.01
- 2011-02-01 0001299933-11-000333 — 2.02, 9.01
- 2010-11-12 0000950123-10-104604 — 8.01, 9.01
- 2010-11-08 0000950123-10-102424 — 8.01, 9.01
- 2010-11-02 0001299933-10-003878 — 2.02, 9.01
- 2010-09-15 0000950123-10-086373 — 1.01, 9.01 — amendment, the index does not say of what
- 2010-08-06 0000950123-10-074362 — 5.07
- 2010-07-29 0001299933-10-002860 — 2.02, 9.01
- 2010-05-17 0000950123-10-050424 — 1.01, 9.01
- 2010-05-14 0001299933-10-001972 — 5.02
- 2010-05-13 0001299933-10-001943 — 2.02, 9.01
- 2010-02-08 0001299933-10-000506 — 8.01
- 2010-02-02 0001299933-10-000386 — 2.02, 9.01
- 2009-12-15 0001299933-09-004928 — 5.02
- 2009-10-29 0001299933-09-004267 — 2.02, 9.01
- 2009-08-12 0001193125-09-173026 — 5.02, 9.01
- 2009-07-30 0001193125-09-158842 — 1.01, 2.02, 9.01
- 2009-05-15 0001193125-09-113158 — 5.02
- 2009-05-14 0001193125-09-110619 — 2.02, 9.01
- 2009-04-20 0001193125-09-082590 — 5.02
- 2009-02-03 0001193125-09-016992 — 2.02, 9.01
- 2009-01-22 0001193125-09-009777 — 2.02, 9.01
- 2008-11-04 0001193125-08-223730 — 2.02, 9.01
- 2008-08-11 0001193125-08-173616 — 8.01
- 2008-08-07 0001193125-08-170325 — 8.01
- 2008-08-05 0001193125-08-165888 — 2.02, 9.01
- 2008-06-11 0001193125-08-132049 — 1.01, 9.01
- 2008-05-20 0001193125-08-119372 — 5.02, 9.01
- 2008-05-08 0001193125-08-107052 — 2.02, 9.01
- 2008-01-31 0001193125-08-016233 — 2.02, 9.01
- 2008-01-30 0001193125-08-015494 — 5.03, 9.01
- 2007-11-01 0001193125-07-231866 — 2.02, 9.01
- 2007-10-31 0001193125-07-231225 — 2.05
- 2007-10-29 0001193125-07-228284 — 5.03, 9.01
- 2007-09-27 0001193125-07-208950 — 5.02
- 2007-08-09 0001193125-07-176553 — 2.02, 9.01
- 2007-08-07 0001193125-07-173829 — 1.01, 5.02, 9.01
- 2007-07-02 0001193125-07-148303 — 5.02, 9.01
- 2007-06-20 0001193125-07-139068 — 8.01, 9.01
- 2007-06-14 0001193125-07-135550 — 9.01 — amendment of 0001193125-07-005297
- 2007-06-14 0001193125-07-135340 — 5.02
- 2007-05-24 0001193125-07-122148 — 2.02, 9.01
- 2007-03-30 0001193125-07-070154 — 2.05, 9.01
- 2007-03-23 0001193125-07-062978 — 9.01 — amendment of 0001193125-07-005297
- 2007-02-01 0001193125-07-017883 — 2.02, 9.01
- 2007-01-11 0001193125-07-005297 — 2.01, 9.01
- 2006-12-05 0001181431-06-067500 — 5.02
- 2006-11-29 0001193125-06-243360 — 1.01, 3.02, 9.01
- 2006-11-02 0001193125-06-221464 — 2.02, 9.01
- 2006-09-21 0001193125-06-194526 — 5.02
- 2006-08-08 0001193125-06-164819 — 2.02, 9.01
- 2006-08-02 0001193125-06-159113 — 1.01, 9.01
- 2006-07-28 0001193125-06-156172 — 1.01
- 2006-06-26 0001193125-06-135913 — 1.01, 3.03, 9.01
- 2006-05-11 0001193125-06-108489 — 2.02, 9.01
- 2006-05-05 0001193125-06-102270 — 1.01, 9.01
- 2006-05-01 0001193125-06-094941 — 2.02, 2.06, 9.01
- 2006-02-24 0001193125-06-038281 — 5.02, 9.01
- 2006-02-02 0001181431-06-007665 — 2.02, 9.01
- 2005-11-09 0001181431-05-060304 — 2.02, 9.01
- 2005-08-04 0001181431-05-044420 — 2.02, 9.01
- 2005-07-28 0001193125-05-151272 — 5.02, 9.01
- 2005-06-14 0001193125-05-125148 — 5.02, 9.01
- 2005-05-12 0001181431-05-027410 — 2.02, 9.01
- 2005-05-10 0001193125-05-102795 — 1.01
- 2005-04-05 0001181431-05-020680 — 1.01, 2.02, 3.02, 9.01
- 2005-02-03 0001181431-05-006678 — 2.02, 9.01
- 2004-11-09 0001181431-04-051381 — 2.02, 9.01 — amendment, the index does not say of what
- 2004-11-04 0001181431-04-050706 — 2.02, 9.01
- 2004-10-15 0001193125-04-172458 — 1.01, 9.01
- 2004-08-05 0001193125-04-132162 — 12
- 2004-05-13 0001193125-04-086853 — 12
- 2004-02-05 0001193125-04-015060 — 12
- 2003-11-06 0001193125-03-074000 — 12
- 2003-09-26 0001193125-03-054624 — 5
- 2003-08-06 0001193125-03-029666 — 12
- 2003-05-14 0000927016-03-002619 — 9
- 2002-12-31 0000927016-02-006114 — 5
- 2000-01-24 0000927016-00-000150 — 5, 7
- 1998-11-02 0000950135-98-005625 — 5, 7
- 1998-03-24 0000950135-98-001743 — 5, 7
- 1997-09-05 0000950135-97-003729 — 5, 7
- 1997-06-23 0000950135-97-002785 — 1 — amendment of 0000950135-97-001972
- 1997-04-23 0000950135-97-001972 — 2, 7

## late-filing notifications on or before 2019-02-05

- 2011-08-10 0000950123-11-075677 — NT 10-Q, for the period ended 2011-06-30
- 2011-05-31 0000950123-11-055465 — NT 10-K, for the period ended 2011-03-31

## item 2.02 — earnings release, exhibit 99.1

[0001628280-19-000964:8k_2_02:1]
EX-99.1
2
amsc20181231ex991.htm
EXHIBIT 99.1

[0001628280-19-000964:8k_2_02:2]
Exhibit

[0001628280-19-000964:8k_2_02:3]
AMSC Reports Third Quarter Fiscal 2018 Financial Results and Provides Business Outlook

[0001628280-19-000964:8k_2_02:4]
Company to host conference call tomorrow, February 6 at 10:00 am ET

[0001628280-19-000964:8k_2_02:5]
Ayer, MA – February 5, 2019 – AMSC (Nasdaq: AMSC), a global solutions provider serving wind and power grid industry leaders, today reported financial results for its third quarter of fiscal 2018 ended December 31, 2018.

[0001628280-19-000964:8k_2_02:6]
Revenues for the third quarter of fiscal 2018 were $14.1 million, compared with $14.9 million for the same period of fiscal 2017. The year-over-year change was driven by lower Grid segment revenues, partially offset by higher Wind segment revenues versus the year ago period.

[0001628280-19-000964:8k_2_02:7]
AMSC’s net income for the third quarter of fiscal 2018 was $17.3 million, or $0.85 per share, compared to a net loss of $4.2 million, or $0.21 per share, for the same period of fiscal 2017. The Company’s non-GAAP net loss for the third quarter of fiscal 2018 was $2.3 million, or $0.11 per share, compared with a non-GAAP net loss of $3.4 million, or $0.17 per share, in the same period of fiscal 2017. Please refer to the financial table below for a reconciliation of GAAP to non-GAAP results.

[0001628280-19-000964:8k_2_02:8]
Cash, cash equivalents and restricted cash on December 31, 2018 totaled $80.2 million, compared with $56.3 million at September 30, 2018. The cash balance as of the end of the third quarter of fiscal 2018 included $25 million of cash proceeds received from the final payment required under the settlement agreement with Sinovel. Operating cash flow in the third quarter, excluding the final payment from the Sinovel settlement, was $0.9 million. Please refer to the financial table below for a reconciliation of GAAP to non-GAAP results.

[0001628280-19-000964:8k_2_02:9]
“During the third quarter we generated nearly $1 million in operating cash flow. We also received the final payment from our legal settlement,” said Daniel P. McGahn, Chairman, President and CEO, AMSC. “Our strong balance sheet is anticipated to put us on a path towards predictable revenues and growth over the long-term. We expect to complete our goals for this fiscal year and further diversify and grow our revenue.”

[0001628280-19-000964:8k_2_02:10]
| AMSC Reports Q3FY18 Results |  | Page 2 |

[0001628280-19-000964:8k_2_02:11]
Business Outlook

[0001628280-19-000964:8k_2_02:12]
For the fourth quarter ending March 31, 2019, AMSC expects that its revenues will be in the range of $14 million to $16 million.  The Company’s net loss for the fourth quarter of fiscal 2018 is expected not to exceed $6 million, or $0.29 per share.  The Company's non-GAAP net loss (as defined below) is expected not to exceed $5 million, or $0.24 per share.  The Company expects operating cash flow, exclusive of any legal fees and tax payments related to the final Sinovel settlement payment, to be a burn of $2 million to $4 million in the fourth quarter of fiscal 2018.  Please see below for a reconciliation of forecast GAAP operating cash flow to non-GAAP operating cash flow.   The Company expects cash, cash equivalents and restricted cash on March 31, 2019, to be no less than $76 million.

[0001628280-19-000964:8k_2_02:13]
Conference Call Reminder

[0001628280-19-000964:8k_2_02:14]
In conjunction with this announcement, AMSC management will participate in a conference call with investors beginning at 10:00 a.m. Eastern Time on Wednesday, February 6, 2019, to discuss the Company’s financial results and business outlook. Those who wish to listen to the live or archived conference call webcast should visit the “Investors” section of the Company’s website at http://www.amsc.com/investors. The live call also can be accessed by dialing (888) 220-8451 and using conference ID 8537690. A replay of the call may be accessed 3 hours following the call by dialing (888) 203-1112 and using conference ID 8537690.

[0001628280-19-000964:8k_2_02:15]
About AMSC (Nasdaq: AMSC)

[0001628280-19-000964:8k_2_02:16]
AMSC generates the ideas, technologies and solutions that meet the world’s demand for smarter, cleaner … better energy™. Through its Windtec™ Solutions, AMSC provides wind turbine electronic controls and systems, designs and engineering services that reduce the cost of wind energy. Through its Gridtec™ Solutions, AMSC provides the engineering planning services and advanced grid systems that optimize network reliability, efficiency and performance. The Company’s solutions are now powering gigawatts of renewable energy globally and are enhancing the performance and reliability of power networks in more than a dozen countries. Founded in 1987, AMSC is headquartered near Boston, Massachusetts with operations in Asia, Australia, Europe and North America. For more information, please visit www.amsc.com.

[0001628280-19-000964:8k_2_02:17]
AMSC, Windtec, Gridtec, and Smarter, Cleaner … Better Energy are trademarks or registered trademarks of American Superconductor Corporation. All other brand names, product names, trademarks or service marks belong to their respective holders.

[0001628280-19-000964:8k_2_02:18]
Forward-Looking Statements

[0001628280-19-000964:8k_2_02:19]
| AMSC Reports Q3FY18 Results |  | Page 3 |

[0001628280-19-000964:8k_2_02:20]
damage our business and prospects; We rely upon third-party suppliers for the components and sub-assemblies of many of our Wind and Grid products, making us vulnerable to supply shortages and price fluctuations, which could harm our business; Failure to achieve expected savings following the move of our former Devens, Massachusetts manufacturing facility could adversely impact our financial performance;  We may not realize all of the sales expected from our backlog of orders and contracts; Our success depends upon the commercial use of high temperature superconductor products, which is currently limited, and a widespread commercial market for our products may not develop; Growth of the wind energy market depends largely on the availability and size of government subsidies, economic incentives and legislative programs designed to support the growth of wind energy; Our contracts with the U.S. government are subject to audit, modification or termination by the U.S. government and include certain other provisions in favor of the government, and additional funding of such contracts may not be approved by the U.S. Congress; Tax reform in the U.S. may negatively affect our operating results; We have operations in and depend on sales in emerging markets, including India, and global conditions could negatively affect our operating results or limit our ability to expand our operations outside of these markets; Our business and operations would be adversely impacted in the event of a failure or security breach of our information technology infrastructure; If we fail to maintain proper and effective internal control over financial reporting, our ability to produce accurate and timely financial statements could be impaired and may lead investors and other users to lose confidence in our financial data; We face risks related to our intellectual property; We face risks related to our legal proceedings; We face risks relating to our settlement with Sinovel; and the important factors discussed under the caption "Risk Factors" in Part 1. Item 1A of our Form 10-K for the fiscal year ended March 31, 2018, Part II. Item 1A of our Quarterly Report on Form 10-Q for the quarter ended December 31, 2018, and our other reports filed with the SEC. These important factors, among others, could cause actual results to differ materially from those indicated by forward-looking statements made herein and presented elsewhere by management from time to time. Any such forward-looking statements represent management's estimates as of the date of this press release. While we may elect to update such forward-looking statements at some point in the future, we disclaim any obligation to do so, even if subsequent events cause our views to change. These forward-looking statements should not be relied upon as representing our views as of any date subsequent to the date of this press release.

[0001628280-19-000964:8k_2_02:21]
| AMSC Reports Q3FY18 Results |  | Page 4 |

[0001628280-19-000964:8k_2_02:22]
UNAUDITED CONSOLIDATED STATEMENTS OF OPERATIONS

[0001628280-19-000964:8k_2_02:23]
(In thousands, except per share data)

[0001628280-19-000964:8k_2_02:24]
|  | Three Months EndedDecember 31, |  | Nine Months EndedDecember 31, |
|  | 2018 |  | 2017 |  | 2018 |  | 2017 |
| Revenues |  |  |  |  |  |  |  |
| Wind | $ | 7,308 |  |  | $ | 2,633 |  |  | $ | 18,293 |  |  | $ | 10,465 |  |
| Grid | 6,826 |  |  | 12,300 |  |  | 23,325 |  |  | 24,439 |  |
| Total revenues | 14,134 |  |  | 14,933 |  |  | 41,618 |  |  | 34,904 |  |
| Cost of revenues | 10,398 |  |  | 9,917 |  |  | 30,364 |  |  | 34,103 |  |
| Gross margin | 3,736 |  |  | 5,016 |  |  | 11,254 |  |  | 801 |  |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | 2,470 |  |  | 3,023 |  |  | 7,573 |  |  | 8,690 |  |
| Selling, general and administrative | 5,347 |  |  | 5,486 |  |  | 16,308 |  |  | 16,964 |  |
| Amortization of acquisition-related intangibles | 85 |  |  | 85 |  |  | 255 |  |  | 98 |  |
| Change in fair value of contingent consideration | — |  |  | 272 |  |  | — |  |  | 71 |  |
| Restructuring | 47 |  |  | 1 |  |  | 450 |  |  | 1,328 |  |
| (Gain) on Sinovel settlement, net | (24,978 | ) |  | — |  |  | (53,698 | ) |  | — |  |
| Total operating (income) expenses | (17,029 | ) |  | 8,867 |  |  | (29,112 | ) |  | 27,151 |  |
| Operating income (loss) | 20,765 |  |  | (3,851 | ) |  | 40,366 |  |  | (26,350 | ) |
| Change in fair value of warrants | (2,475 | ) |  | 399 |  |  | (2,658 | ) |  | 1,468 |  |
| Gain on sale of minority interest | 127 |  |  | — |  |  | 127 |  |  | 951 |  |
| Interest income, net | 336 |  |  | 49 |  |  | 769 |  |  | 94 |  |
| Other income (expense), net | 124 |  |  | (279 | ) |  | 1,058 |  |  | (2,449 | ) |
| Income (loss) before income tax expense | 18,877 |  |  | (3,682 | ) |  | 39,662 |  |  | (26,286 | ) |
| Income tax expense | 1,584 |  |  | 566 |  |  | 4,548 |  |  | 496 |  |
| Net income (loss) | $ | 17,293 |  |  | $ | (4,248 | ) |  | $ | 35,114 |  |  | $ | (26,782 | ) |
| Net loss per common share |  |  |  |  |  |  |  |
| Basic | $ | 0.85 |  |  | $ | (0.21 | ) |  | $ | 1.73 |  |  | $ | (1.44 | ) |
| Diluted | $ | 0.83 |  |  | $ | (0.21 | ) |  | $ | 1.71 |  |  | $ | (1.44 | ) |
| Weighted average number of common shares outstanding |  |  |  |  |  |  |  |
| Basic | 20,419 |  |  | 19,949 |  |  | 20,300 |  |  | 18,614 |  |
| Diluted | 20,864 |  |  | 19,949 |  |  | 20,538 |  |  | 18,614 |  |

[0001628280-19-000964:8k_2_02:25]
| AMSC Reports Q3FY18 Results |  | Page 5 |

[0001628280-19-000964:8k_2_02:26]
UNAUDITED CONSOLIDATED BALANCE SHEET

[0001628280-19-000964:8k_2_02:27]
(In thousands, except per share data)

[0001628280-19-000964:8k_2_02:28]
|  | December 31, 2018 |  | March 31, 2018 |
| ASSETS |  |  |  |
| Current assets: |  |  |  |
| Cash and cash equivalents | $ | 80,042 |  |  | $ | 34,084 |  |
| Accounts receivable, net | 8,055 |  |  | 7,365 |  |
| Inventory | 14,006 |  |  | 19,780 |  |
| Note receivable, current portion | 3,000 |  |  | 3,000 |  |
| Prepaid expenses and other current assets | 4,091 |  |  | 2,947 |  |
| Total current assets | 109,194 |  |  | 67,176 |  |
| Property, plant and equipment, net | 9,808 |  |  | 12,513 |  |
| Intangibles, net | 2,975 |  |  | 3,230 |  |
| Note receivable, long term portion, net of discount of $168 as of December 31, 2018 and net of discount of $336 and deferred gain of $105 as of March 31, 2018 | 2,832 |  |  | 2,559 |  |
| Goodwill | 1,719 |  |  | 1,719 |  |
| Restricted cash | 165 |  |  | 165 |  |
| Deferred tax assets | 1,438 |  |  | 542 |  |
| Other assets | 373 |  |  | 271 |  |
| Total assets | $ | 128,504 |  |  | $ | 88,175 |  |
| LIABILITIES AND STOCKHOLDERS' EQUITY |  |  |  |
| Current liabilities: |  |  |  |
| Accounts payable and accrued expenses | $ | 17,681 |  |  | $ | 12,625 |  |
| Derivative liabilities | 3,875 |  |  | 1,217 |  |
| Deferred revenue, current portion | 9,929 |  |  | 13,483 |  |
| Total current liabilities | 31,485 |  |  | 27,325 |  |
| Deferred revenue, long term portion | 8,133 |  |  | 8,454 |  |
| Deferred tax liabilities | 110 |  |  | 110 |  |
| Other liabilities | 97 |  |  | 57 |  |
| Total liabilities | 39,825 |  |  | 35,946 |  |
| Stockholders' equity: |  |  |  |
| Common stock | 217 |  |  | 211 |  |
| Additional paid-in capital | 1,043,815 |  |  | 1,041,113 |  |
| Treasury stock | (2,101 | ) |  | (1,645 | ) |
| Accumulated other comprehensive (loss) income | (65 | ) |  | 883 |  |
| Accumulated deficit | (953,187 | ) |  | (988,333 | ) |
| Total stockholders' equity | 88,679 |  |  | 52,229 |  |
| Total liabilities and stockholders' equity | $ | 128,504 |  |  | $ | 88,175 |  |

[0001628280-19-000964:8k_2_02:29]
| AMSC Reports Q3FY18 Results |  | Page 6 |

[0001628280-19-000964:8k_2_02:30]
UNAUDITED CONSOLIDATED STATEMENTS OF CASH FLOWS

[0001628280-19-000964:8k_2_02:31]
(In thousands)

[0001628280-19-000964:8k_2_02:32]
|  | Nine Months EndedDecember 31, |
|  | 2018 |  | 2017 |
| Cash flows from operating activities: |  |  |  |
| Net income (loss) | $ | 35,114 |  |  | $ | (26,782 | ) |
| Adjustments to reconcile net income (loss) to net cash used in operations: |  |  |  |
| Depreciation and amortization | 3,455 |  |  | 9,239 |  |
| Stock-based compensation expense | 2,402 |  |  | 2,115 |  |
| Provision for excess and obsolete inventory | 686 |  |  | 415 |  |
| (Gain) on sale of minority interest | (127 | ) |  | (951 | ) |
| Change in fair value of warrants and contingent consideration | 2,658 |  |  | (1,397 | ) |
| Non-cash interest (income) expense | (168 | ) |  | 19 |  |
| Other non-cash items | (1,692 | ) |  | 81 |  |
| Changes in operating asset and liability accounts: |  |  |  |
| Accounts receivable | (724 | ) |  | (3,576 | ) |
| Inventory | 3,320 |  |  | 180 |  |
| Prepaid expenses and other current assets | (1,380 | ) |  | 647 |  |
| Accounts payable and accrued expenses | 4,603 |  |  | 638 |  |
| Deferred revenue | (361 | ) |  | (862 | ) |
| Net cash provided by/(used in) operating activities | 47,786 |  |  | (20,234 | ) |
| Cash flows from investing activities: |  |  |  |
| Net cash provided by/(used in) investing activities | (650 | ) |  | (1,056 | ) |
| Cash flows from financing activities: |  |  |  |
| Net cash provided by/(used in) financing activities | (385 | ) |  | 15,188 |  |
| Effect of exchange rate changes on cash | (792 | ) |  | 636 |  |
| Net increase in cash, cash equivalents and restricted cash | 45,959 |  |  | (5,466 | ) |
| Cash, cash equivalents and restricted cash at beginning of period | 34,248 |  |  | 27,744 |  |
| Cash, cash equivalents and restricted cash at end of period | $ | 80,207 |  |  | $ | 22,278 |  |

[0001628280-19-000964:8k_2_02:33]
| AMSC Reports Q3FY18 Results |  | Page 7 |

[0001628280-19-000964:8k_2_02:34]
RECONCILIATION OF GAAP NET INCOME (LOSS) TO NON-GAAP NET LOSS

[0001628280-19-000964:8k_2_02:35]
(In thousands, except per share data)

[0001628280-19-000964:8k_2_02:36]
|  | Three Months EndedDecember 31, |  | Nine Months EndedDecember 31, |
|  | 2018 |  | 2017 |  | 2018 |  | 2017 |
| Net income (loss) | $ | 17,293 |  |  | $ | (4,248 | ) |  | $ | 35,114 |  |  | $ | (26,782 | ) |
| Sale of minority investments | (127 | ) |  | — |  |  | (127 | ) |  | (951 | ) |
| Stock-based compensation | 792 |  |  | 883 |  |  | 2,402 |  |  | 2,115 |  |
| (Gain) on Sinovel settlement, net | (24,978 | ) |  | — |  |  | (53,698 | ) |  | — |  |
| Amortization of acquisition-related intangibles | 85 |  |  | 85 |  |  | 255 |  |  | 98 |  |
| Changes in fair value of warrants and contingent consideration | 2,475 |  |  | (126 | ) |  | 2,658 |  |  | (1,397 | ) |
| Non-cash interest expense | — |  |  | — |  |  | — |  |  | 19 |  |
| Tax effect of adjustments | 2,163 |  |  | 19 |  |  | 4,991 |  |  | 142 |  |
| Non-GAAP net loss | $ | (2,297 | ) |  | $ | (3,387 | ) |  | $ | (8,405 | ) |  | $ | (26,756 | ) |
| Non-GAAP net loss per share - basic | $ | (0.11 | ) |  | $ | (0.17 | ) |  | $ | (0.41 | ) |  | $ | (1.44 | ) |
| Weighted average shares outstanding - basic | 20,419 |  |  | 19,949 |  |  | 20,300 |  |  | 18,614 |  |

[0001628280-19-000964:8k_2_02:37]
RECONCILIATION OF GAAP OPERATING CASH FLOW TO NON-GAAP OPERATING CASH FLOW

[0001628280-19-000964:8k_2_02:38]
(In thousands)

[0001628280-19-000964:8k_2_02:39]
|  | Three months ending |  | Nine months ending |
|  | December 31, 2018 |  | December 31, 2018 |
| Operating cash flow | $24,191 |  | $47,786 |
| Sinovel settlement (net of legal fees and expenses) | (24,388 | ) |  | (54,724 | ) |
| Tax effect of adjustments | 1,130 |  |  | 2,377 |  |
| Non-GAAP operating cash flow | $933 |  | $(4,561) |

[0001628280-19-000964:8k_2_02:40]
Reconciliation of Forecast GAAP Net Loss to Non-GAAP Net Loss

[0001628280-19-000964:8k_2_02:41]
(In millions, except per share data)

[0001628280-19-000964:8k_2_02:42]
|  | Three months ending |
| March 31, 2019 |
| Net loss | $(6) |
| Stock-based compensation | 1 |  |
| Amortization of acquisition-related intangibles | — |  |
| (Gain) on Sinovel settlement, net | — |  |
| Tax effect of adjustments | — |  |
| Non-GAAP net loss | $(5) |
| Non-GAAP net loss per share | $(0.24) |
| Shares outstanding | 21 |  |

[0001628280-19-000964:8k_2_02:43]
| AMSC Reports Q3FY18 Results |  | Page 8 |

[0001628280-19-000964:8k_2_02:44]
Reconciliation of Forecast GAAP Operating Cash Flow to Non-GAAP Operating Cash Flow

[0001628280-19-000964:8k_2_02:45]
(In millions)

[0001628280-19-000964:8k_2_02:46]
|  | Three months ending |
|  | March 31, 2019 |
| Operating cash flow | $(6) |
| Sinovel settlement (net of legal fees and expenses) | 2 |  |
| Non-GAAP operating cash flow | $(4) |

[0001628280-19-000964:8k_2_02:47]
Note: Non-GAAP net loss is defined by the Company as net income (loss) before; sale of minority investments; stock-based compensation; gain on Sinovel settlement, net, amortization of acquisition-related intangibles; changes in fair value of warrants and contingent consideration;  non-cash interest expense; tax effect of adjustments; and other unusual charges or items. The Company believes non-GAAP net loss assists management and investors in comparing the Company’s performance across reporting periods on a consistent basis by excluding these non-cash, non-recurring or other charges that it does not believe are indicative of its core operating performance. The Company is not able to provide the change in fair value of warrants on a forward-looking basis without unreasonable efforts because the calculation for that change is primarily driven by the closing price and volatility of the Company's stock at the end of each fiscal quarter, which cannot be reasonably estimated at this time, and therefore the Company's non-GAAP net loss guidance does not include the impact from any change in fair value of warrants.  Actual non-GAAP net loss for the fiscal quarter ending March 31, 2019, including the above adjustments, may differ materially from those forecasted in the table above.

[0001628280-19-000964:8k_2_02:48]
Non-GAAP operating cash flow is defined by the Company as operating cash flow before: Sinovel settlement (net of legal fees and expenses); tax effect of adjustments; and other unusual cash flows or items. The Company believes non-GAAP operating cash flow assists management and investors in comparing the Company’s operating cash flow across reporting periods on a consistent basis by excluding these  non-recurring cash items that it does not believe are indicative of its core operating cash flow. Actual non-GAAP operating cash flow for the fiscal quarter ending March 31, 2019, including the above adjustments, may differ materially from that forecasted in the table above.

[0001628280-19-000964:8k_2_02:49]
Generally, a non-GAAP financial measure is a numerical measure of a company's performance, financial position or cash flow that either excludes or includes amounts that are not normally excluded or included in the most directly comparable measure calculated and presented in accordance with GAAP. The non-GAAP measures included in this release, however, should be considered in addition to, and not as a substitute for or superior to, operating income, cash flows, or other measures of financial performance prepared in accordance with GAAP. A reconciliation of GAAP to non-GAAP net loss is set forth in the table above.

[0001628280-19-000964:8k_2_02:50]
AMSC Contacts

[0001628280-19-000964:8k_2_02:51]
Investor Relations Contact:

[0001628280-19-000964:8k_2_02:52]
LHA Investor Relations

[0001628280-19-000964:8k_2_02:53]
Sanjay M. Hurry

[0001628280-19-000964:8k_2_02:54]
(212) 838-3777

[0001628280-19-000964:8k_2_02:55]
amscIR@lhai.com

[0001628280-19-000964:8k_2_02:56]
Public Relations Contact:

[0001628280-19-000964:8k_2_02:57]
RooneyPartners LLC

[0001628280-19-000964:8k_2_02:58]
Bob Cavosi

[0001628280-19-000964:8k_2_02:59]
646-638-9891

[0001628280-19-000964:8k_2_02:60]
rcavosi@rooneyco.com

[0001628280-19-000964:8k_2_02:61]
AMSC Communications Manager:

[0001628280-19-000964:8k_2_02:62]
Nicol Golez

[0001628280-19-000964:8k_2_02:63]
Phone: 978-399-8344

[0001628280-19-000964:8k_2_02:64]
Email: Nicol.Golez@amsc.com
