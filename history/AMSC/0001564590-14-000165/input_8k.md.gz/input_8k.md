# AMSC 8-K — 0001193125-14-037960 filed 2014-02-06

## item codes, every 8-K on or before 2014-02-06

- 2014-02-06 0001193125-14-037960 — 2.02, 8.01, 9.01
- 2013-11-20 0001193125-13-447829 — 3.02, 8.01
- 2013-11-18 0001193125-13-444697 — 1.01, 2.03, 3.02, 9.01
- 2013-11-07 0001193125-13-431705 — 2.02, 9.01
- 2013-10-09 0001193125-13-395362 — 1.01, 2.03, 3.02, 9.01
- 2013-09-25 0001193125-13-378481 — 5.02, 9.01
- 2013-08-21 0001193125-13-341566 — 4.01, 9.01
- 2013-08-07 0001193125-13-323082 — 2.02, 9.01
- 2013-08-02 0001193125-13-317278 — 5.02, 5.07
- 2013-06-14 0001193125-13-258758 — 2.02, 9.01
- 2013-04-01 0001193125-13-136714 — 2.02, 8.01, 9.01
- 2013-02-20 0001193125-13-067218 — 5.02, 9.01
- 2013-02-14 0001193125-13-060131 — 1.01, 9.01
- 2013-02-11 0001193125-13-048784 — 2.02, 9.01
- 2013-01-08 0001193125-13-006861 — 5.02, 9.01
- 2012-12-21 0001193125-12-511592 — 1.01, 2.03, 3.02, 9.01
- 2012-11-28 0001193125-12-483317 — 2.05, 5.02, 7.01, 9.01
- 2012-11-06 0001193125-12-453359 — 2.02, 9.01
- 2012-08-02 0001193125-12-330534 — 2.02, 9.01
- 2012-07-27 0001193125-12-318790 — 5.02, 5.07, 9.01
- 2012-06-06 0001193125-12-261030 — 1.01, 2.02, 2.03, 3.02, 5.02, 9.01
- 2012-05-09 0001193125-12-222210 — 5.02
- 2012-04-20 0001193125-12-172045 — 8.01
- 2012-04-13 0001193125-12-162694 — 2.02, 8.01, 9.01
- 2012-04-04 0001193125-12-149102 — 1.01, 2.02, 2.03, 3.02, 9.01
- 2012-02-09 0001193125-12-048009 — 2.02, 9.01
- 2012-02-06 0001193125-12-041344 — 5.07 — amendment of 0000950123-11-102495
- 2011-12-08 0000950123-11-102495 — 5.07
- 2011-11-29 0000950123-11-100822 — 2.05
- 2011-11-09 0000950123-11-096775 — 2.02, 9.01
- 2011-10-31 0000950123-11-093390 — 1.02, 9.01
- 2011-10-07 0000950123-11-089221 — 8.01
- 2011-10-03 0000950123-11-088315 — 7.01
- 2011-09-23 0000950123-11-086288 — 2.02, 9.01
- 2011-09-15 0000950123-11-084585 — 7.01
- 2011-09-06 0000950123-11-082736 — 7.01
- 2011-08-18 0000950123-11-078526 — 3.01, 7.01, 9.01
- 2011-08-11 0000950123-11-075905 — 5.02
- 2011-08-11 0000950123-11-075904 — 2.02, 2.05, 9.01
- 2011-07-11 0000950123-11-064934 — 2.02, 4.02, 9.01
- 2011-06-30 0000950123-11-063287 — 1.01, 3.02, 9.01
- 2011-06-21 0000950123-11-060491 — 3.01, 7.01, 9.01
- 2011-06-13 0000950123-11-058656 — 1.01, 9.01
- 2011-05-24 0000950123-11-053517 — 5.02, 9.01
- 2011-04-05 0001299933-11-001020 — 2.02, 9.01
- 2011-03-15 0000950123-11-025580 — 5.02
- 2011-03-14 0000950123-11-025205 — 1.01, 3.02, 9.01
- 2011-02-01 0001299933-11-000333 — 2.02, 9.01
- 2010-11-12 0000950123-10-104604 — 8.01, 9.01
- 2010-11-08 0000950123-10-102424 — 8.01, 9.01
- 2010-11-02 0001299933-10-003878 — 2.02, 9.01
- 2010-09-15 0000950123-10-086373 — 1.01, 9.01 — amendment, the index does not say of what
- 2010-08-06 0000950123-10-074362 — 5.07
- 2010-07-29 0001299933-10-002860 — 2.02, 9.01
- 2010-05-17 0000950123-10-050424 — 1.01, 9.01
- 2010-05-14 0001299933-10-001972 — 5.02
- 2010-05-13 0001299933-10-001943 — 2.02, 9.01
- 2010-02-08 0001299933-10-000506 — 8.01
- 2010-02-02 0001299933-10-000386 — 2.02, 9.01
- 2009-12-15 0001299933-09-004928 — 5.02
- 2009-10-29 0001299933-09-004267 — 2.02, 9.01
- 2009-08-12 0001193125-09-173026 — 5.02, 9.01
- 2009-07-30 0001193125-09-158842 — 1.01, 2.02, 9.01
- 2009-05-15 0001193125-09-113158 — 5.02
- 2009-05-14 0001193125-09-110619 — 2.02, 9.01
- 2009-04-20 0001193125-09-082590 — 5.02
- 2009-02-03 0001193125-09-016992 — 2.02, 9.01
- 2009-01-22 0001193125-09-009777 — 2.02, 9.01
- 2008-11-04 0001193125-08-223730 — 2.02, 9.01
- 2008-08-11 0001193125-08-173616 — 8.01
- 2008-08-07 0001193125-08-170325 — 8.01
- 2008-08-05 0001193125-08-165888 — 2.02, 9.01
- 2008-06-11 0001193125-08-132049 — 1.01, 9.01
- 2008-05-20 0001193125-08-119372 — 5.02, 9.01
- 2008-05-08 0001193125-08-107052 — 2.02, 9.01
- 2008-01-31 0001193125-08-016233 — 2.02, 9.01
- 2008-01-30 0001193125-08-015494 — 5.03, 9.01
- 2007-11-01 0001193125-07-231866 — 2.02, 9.01
- 2007-10-31 0001193125-07-231225 — 2.05
- 2007-10-29 0001193125-07-228284 — 5.03, 9.01
- 2007-09-27 0001193125-07-208950 — 5.02
- 2007-08-09 0001193125-07-176553 — 2.02, 9.01
- 2007-08-07 0001193125-07-173829 — 1.01, 5.02, 9.01
- 2007-07-02 0001193125-07-148303 — 5.02, 9.01
- 2007-06-20 0001193125-07-139068 — 8.01, 9.01
- 2007-06-14 0001193125-07-135550 — 9.01 — amendment of 0001193125-07-005297
- 2007-06-14 0001193125-07-135340 — 5.02
- 2007-05-24 0001193125-07-122148 — 2.02, 9.01
- 2007-03-30 0001193125-07-070154 — 2.05, 9.01
- 2007-03-23 0001193125-07-062978 — 9.01 — amendment of 0001193125-07-005297
- 2007-02-01 0001193125-07-017883 — 2.02, 9.01
- 2007-01-11 0001193125-07-005297 — 2.01, 9.01
- 2006-12-05 0001181431-06-067500 — 5.02
- 2006-11-29 0001193125-06-243360 — 1.01, 3.02, 9.01
- 2006-11-02 0001193125-06-221464 — 2.02, 9.01
- 2006-09-21 0001193125-06-194526 — 5.02
- 2006-08-08 0001193125-06-164819 — 2.02, 9.01
- 2006-08-02 0001193125-06-159113 — 1.01, 9.01
- 2006-07-28 0001193125-06-156172 — 1.01
- 2006-06-26 0001193125-06-135913 — 1.01, 3.03, 9.01
- 2006-05-11 0001193125-06-108489 — 2.02, 9.01
- 2006-05-05 0001193125-06-102270 — 1.01, 9.01
- 2006-05-01 0001193125-06-094941 — 2.02, 2.06, 9.01
- 2006-02-24 0001193125-06-038281 — 5.02, 9.01
- 2006-02-02 0001181431-06-007665 — 2.02, 9.01
- 2005-11-09 0001181431-05-060304 — 2.02, 9.01
- 2005-08-04 0001181431-05-044420 — 2.02, 9.01
- 2005-07-28 0001193125-05-151272 — 5.02, 9.01
- 2005-06-14 0001193125-05-125148 — 5.02, 9.01
- 2005-05-12 0001181431-05-027410 — 2.02, 9.01
- 2005-05-10 0001193125-05-102795 — 1.01
- 2005-04-05 0001181431-05-020680 — 1.01, 2.02, 3.02, 9.01
- 2005-02-03 0001181431-05-006678 — 2.02, 9.01
- 2004-11-09 0001181431-04-051381 — 2.02, 9.01 — amendment, the index does not say of what
- 2004-11-04 0001181431-04-050706 — 2.02, 9.01
- 2004-10-15 0001193125-04-172458 — 1.01, 9.01
- 2004-08-05 0001193125-04-132162 — 12
- 2004-05-13 0001193125-04-086853 — 12
- 2004-02-05 0001193125-04-015060 — 12
- 2003-11-06 0001193125-03-074000 — 12
- 2003-09-26 0001193125-03-054624 — 5
- 2003-08-06 0001193125-03-029666 — 12
- 2003-05-14 0000927016-03-002619 — 9
- 2002-12-31 0000927016-02-006114 — 5
- 2000-01-24 0000927016-00-000150 — 5, 7
- 1998-11-02 0000950135-98-005625 — 5, 7
- 1998-03-24 0000950135-98-001743 — 5, 7
- 1997-09-05 0000950135-97-003729 — 5, 7
- 1997-06-23 0000950135-97-002785 — 1 — amendment of 0000950135-97-001972
- 1997-04-23 0000950135-97-001972 — 2, 7

## late-filing notifications on or before 2014-02-06

- 2011-08-10 0000950123-11-075677 — NT 10-Q, for the period ended 2011-06-30
- 2011-05-31 0000950123-11-055465 — NT 10-K, for the period ended 2011-03-31

## item 2.02 — earnings release, exhibit 99.1

[0001193125-14-037960:8k_2_02:1]
EX-99.1
2
d671687dex991.htm
EX-99.1

[0001193125-14-037960:8k_2_02:2]
EX-99.1

[0001193125-14-037960:8k_2_02:3]
Exhibit 99.1

[0001193125-14-037960:8k_2_02:4]
AMSC Reports Fiscal Third Quarter 2013 Financial Results

[0001193125-14-037960:8k_2_02:5]
Devens, MA – February 6, 2014 – AMSC (NASDAQ: AMSC), a global solutions provider serving wind and power grid industry
leaders, today reported financial results for its fiscal third quarter ended December 31, 2013.

[0001193125-14-037960:8k_2_02:6]
Revenues for the third quarter of fiscal
2013 were $20.6 million, compared with $17.4 million for the same period of fiscal 2012. The year-over-year growth is due to higher revenues in the Company’s Wind segment, primarily from customers in India and China. Wind revenue growth was
partially offset by lower revenues in the Company’s Grid segment due to lower D-VAR® revenues.

[0001193125-14-037960:8k_2_02:7]
AMSC’s net loss for the third quarter of fiscal 2013 narrowed to $8.4 million, or $0.14 per share, compared with a net loss of $20.1 million, or $0.38
per share, for the same period of fiscal 2012.

[0001193125-14-037960:8k_2_02:8]
The Company’s non-GAAP net loss for the third quarter of fiscal 2013 was $5.7 million, or $0.09 per
share, compared with a non-GAAP net loss of $13.5 million, or $0.26 per share, for the third quarter of fiscal 2012. Please refer to the financial table below for a reconciliation of GAAP to non-GAAP results.

[0001193125-14-037960:8k_2_02:9]
Cash, cash equivalents, and restricted cash at December 31, 2013 totaled $41.7 million, compared with $32.8 million as of September 30, 2013. The
sequential increase was driven primarily by financing activities conducted during the quarter, including a new $10.0 million senior term loan and $3.3 million in net proceeds after deducting sales commissions and offering expenses from the issuance
of approximately 2.4 million shares of common stock at an average sale price of $1.51 per share under the At-the-Market (ATM) equity financing that was put in place in November 2013.

[0001193125-14-037960:8k_2_02:10]
“I’m pleased with our performance in the third fiscal quarter. We increased revenues and cash, reduced our net loss, operating expenses, and cash
burn year-over-year. We are managing our costs and our cash,” said Daniel P. McGahn, AMSC President and CEO.

[0001193125-14-037960:8k_2_02:11]
McGahn continued, “The long-term
prospects in our key markets are promising, but we continue to anticipate challenges in the near term. Given the strategic cost-cutting measures we have taken over the past year, we have reduced our annualized operating expenses and net loss and we
have achieved a slower cash burn. We are focused on achieving positive net cash flows on a quarterly basis. We believe this will occur by the end of fiscal year 2014.”

[0001193125-14-037960:8k_2_02:12]
Financial Guidance

[0001193125-14-037960:8k_2_02:13]
For the fourth fiscal quarter ending
March 31, 2014, AMSC expects that its revenues will exceed $16 million and that its net loss will be less than $16 million, or $0.24 per share. This forecast excludes any impact from mark-to-market adjustments related to the Company’s
derivative liability and warrants. AMSC expects that its non-GAAP net loss for its fourth quarter of fiscal 2013 will be less than $12 million, or $0.18 per share. AMSC expects to have more than $38 million in cash, cash equivalents and restricted
cash on March 31, 2014. This forecast does not assume any proceeds from the ATM in the fourth fiscal quarter.

[0001193125-14-037960:8k_2_02:14]
| AMSC Reports Q3 Results |  | Page 2 |

[0001193125-14-037960:8k_2_02:15]
Conference Call Reminder

[0001193125-14-037960:8k_2_02:16]
In conjunction with this announcement, AMSC management will host a conference call with investors beginning at 10:00 a.m. Eastern Time today to discuss the
Company’s results and its business outlook. To listen to the live or archived conference call webcast please visit the “Investors” section of the Company’s website at http://www.amsc.com/investors. The live call also can
be accessed by dialing 785-830-1923 and using conference ID 8185757.

[0001193125-14-037960:8k_2_02:17]
About AMSC (NASDAQ: AMSC)

[0001193125-14-037960:8k_2_02:18]
AMSC generates the ideas, technologies and solutions that meet the world’s demand for smarter, cleaner … better energy™. Through its
Windtec™ Solutions, AMSC provides wind turbine electronic controls and systems, designs and engineering services that reduce the cost of wind energy. Through its Gridtec™ Solutions, AMSC provides the engineering planning services and
advanced grid systems that optimize network reliability, efficiency and performance. The Company’s solutions are now powering gigawatts of renewable energy globally and are enhancing the performance and reliability of power networks in more
than a dozen countries. Founded in 1987, AMSC is headquartered near Boston, Massachusetts with operations in Asia, Australia, Europe and North America. For more information, please visit www.amsc.com.

[0001193125-14-037960:8k_2_02:19]
AMSC, Windtec, Gridtec, and Smarter, Cleaner … Better Energy are trademarks or registered trademarks of American Superconductor Corporation. All other
brand names, product names, trademarks or service marks belong to their respective holders.

[0001193125-14-037960:8k_2_02:20]
There are a number of important factors that could materially impact the value of our common stock or cause actual results to differ materially from those
indicated by such forward-looking statements. Such factors include: We have experienced recurring operating losses and recurring negative cash flows from operations which raise substantial doubt about our ability to continue as a going concern. This
substantial doubt has resulted in a qualified opinion from our auditors with an explanatory paragraph regarding our ability to continue as a going concern. We believe this opinion may have an adverse effect on our customer and supplier
relationships; our success in addressing the wind energy market is dependent on the manufacturers that license our designs; we may not realize all of the sales expected from our backlog of orders and contracts; our business and operations would be
adversely impacted in the event of a failure or security breach of our information technology infrastructure; our success is dependent upon attracting and retaining qualified personnel and our inability to do so could significantly damage our
business and prospects; we rely upon third-party suppliers for the components and subassemblies of many of our Wind and Grid products, making us vulnerable to supply shortages and price fluctuations, which could harm our business; many of our
revenue opportunities are dependent upon subcontractors and other business collaborators; if we fail to implement our business strategy successfully, our financial performance could be harmed; problems with product quality or product performance may
cause us to incur warranty expenses and may damage our market reputation and prevent us from achieving increased sales and market share; new regulations related to conflict-free minerals may force us to incur significant additional expenses; our
contracts with the U. S. government are subject to audit, modification or termination by the U.S. government and include certain other provisions in favor of the government; the continued funding of such contracts remains subject to annual
congressional appropriation which, if not approved, could reduce our revenue and lower or eliminate our profit; we may acquire additional complementary businesses or technologies, which may require us to incur substantial costs for which we may
never realize the anticipated benefits; many of our customers outside of the United States are, either directly or indirectly, related to

[0001193125-14-037960:8k_2_02:21]
| AMSC Reports Q3 Results |  | Page 3 |

[0001193125-14-037960:8k_2_02:22]
governmental entities, and we could be adversely affected by violations of the United States Foreign Corrupt Practices Act and similar worldwide anti-bribery laws outside the United States; we
have limited experience in marketing and selling our superconductor products and system-level solutions, and our failure to effectively market and sell our products and solutions could lower our revenue and cash flow; we have experienced recurring
losses from operations and negative operating cash flow; these factors raise substantial doubt regarding our ability to continue as a going concern; we have a history of operating losses, and we may incur additional losses in the future; our
operating results may fluctuate significantly from quarter to quarter and may fall below expectations in any particular fiscal quarter; we may require additional funding in the future and may be unable to raise capital when needed; our debt
obligations include certain covenants and other events of default;. Should we not comply with the covenants or incur an event of default, we may be required to repay our debt obligations in cash, which could have an adverse effect on our liquidity;
if we fail to maintain proper and effective internal controls over financial reporting, our ability to produce accurate and timely financial statements could be impaired and may lead investors and other users to lose confidence in our financial
data; we may be required to issue performance bonds or provide letters of credit, which restricts our ability to access any cash used as collateral for the bonds or letters of credit; changes in exchange rates could adversely affect our results from
operations; growth of the wind energy market depends largely on the availability and size of government subsidies and economic incentives; we depend on sales to customers in China and India, and global conditions could negatively affect our
operating results or limit our ability to expand our operations outside of these countries; changes in China’s or India’s political, social, regulatory and economic environment may affect our financial performance; our products face
intense competition, which could limit our ability to acquire or retain customers; our international operations are subject to risks that we do not face in the United States, which could have an adverse effect on our operating results; adverse
changes in domestic and global economic conditions could adversely affect our operating results; we may be unable to adequately prevent disclosure of trade secrets and other proprietary information; our patents may not provide meaningful protection
for our technology, which could result in us losing some or all of our market position; the commercial uses of superconductor products are limited today, and a widespread commercial market for our products may not develop; there are a number of
technological challenges that must be successfully addressed before our superconductor products can gain widespread commercial acceptance, and our inability to address such technological challenges could adversely affect our ability to acquire
customers for our products; we have not manufactured our Amperium wire in commercial quantities, and a failure to manufacture our Amperium wire in commercial quantities at acceptable cost and quality levels would substantially limit our future
revenue and profit potential; third parties have or may acquire patents that cover the materials, processes and technologies we use or may use in the future to manufacture our Amperium products, and our success depends on our ability to license such
patents or other proprietary rights; our technology and products could infringe intellectual property rights of others, which may require costly litigation and, if we are not successful, could cause us to pay substantial damages and disrupt our
business; we have filed a demand for arbitration and other lawsuits against our former largest customer, Sinovel, regarding amounts we contend are overdue. We cannot be certain as to the outcome of these proceedings; we have been named as a party to
purported stockholder class actions and stockholder derivative complaints, and we may be named in additional litigation, all of which will require significant management time and attention, result in significant legal expenses and may result in an
unfavorable outcome, which could have a material adverse effect on our business, operating results and financial condition; our 7% convertible note contains warrants and provisions that could limit our ability to repay the note in shares of common
stock and should the note be repaid in stock, shareholders could experience significant dilution; our common stock has experienced, and may continue to experience, significant market price and volume fluctuations, which may prevent our stockholders
from selling our common stock at a profit and could lead to costly litigation against us that could divert our management’s attention. These and the important factors discussed under the caption “Risk Factors” in Part 1. Item 1A
of our Form 10-K for the fiscal year ended March 31, 2013, and our other reports filed with the SEC, among others, could cause actual results to differ materially from those indicated by forward-looking statements made herein and presented
elsewhere by management from time to time. Any such forward-looking statements represent management’s estimates as of the date of this press release. While we may elect to update such forward-looking statements at some point in the future, we
disclaim any obligation to do so, even if subsequent events cause our views to change. These forward-looking statements should not be relied upon as representing our views as of any date subsequent to the date of this press release.

[0001193125-14-037960:8k_2_02:23]
| AMSC Reports Q3 Results |  | Page 4 |

[0001193125-14-037960:8k_2_02:24]
UNAUDITED CONSOLIDATED STATEMENTS OF OPERATIONS

[0001193125-14-037960:8k_2_02:25]
(In thousands, except per share data)

[0001193125-14-037960:8k_2_02:26]
|  |  | Three months endedDecember 31, |  |  | Nine months endedDecember 31, |  |
|  |  | 2013 |  |  | 2012 |  |  | 2013 |  |  | 2012 |  |
| Revenues |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Wind |  | $ | 13,545 |  |  | $ | 6,808 |  |  | $ | 42,937 |  |  | $ | 35,321 |  |
| Grid |  |  | 7,018 |  |  |  | 10,609 |  |  |  | 24,893 |  |  |  | 31,679 |  |
| Total Revenues |  |  | 20,563 |  |  |  | 17,417 |  |  |  | 67,830 |  |  |  | 67,000 |  |
| Cost of revenues |  |  | 15,863 |  |  |  | 16,533 |  |  |  | 56,461 |  |  |  | 53,843 |  |
| Gross profit |  |  | 4,700 |  |  |  | 884 |  |  |  | 11,369 |  |  |  | 13,157 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Research and development |  |  | 2,951 |  |  |  | 3,948 |  |  |  | 9,061 |  |  |  | 11,480 |  |
| Selling, general and administrative |  |  | 8,232 |  |  |  | 10,769 |  |  |  | 27,741 |  |  |  | 36,304 |  |
| Restructuring and impairments |  |  | 108 |  |  |  | 6,702 |  |  |  | 872 |  |  |  | 6,845 |  |
| Amortization of acquisition related intangibles |  |  | 84 |  |  |  | 81 |  |  |  | 247 |  |  |  | 242 |  |
| Total operating expenses |  |  | 11,375 |  |  |  | 21,500 |  |  |  | 37,921 |  |  |  | 54,871 |  |
| Operating loss |  |  | (6,675 | ) |  |  | (20,616 | ) |  |  | (26,552 | ) |  |  | (41,714 | ) |
| Change in fair value of derivatives and warrants |  |  | 535 |  |  |  | 5,217 |  |  |  | 1,890 |  |  |  | 6,114 |  |
| Interest expense, net |  |  | (1,634 | ) |  |  | (4,553 | ) |  |  | (7,250 | ) |  |  | (10,191 | ) |
| Other expense, net |  |  | (341 | ) |  |  | (109 | ) |  |  | (908 | ) |  |  | (1,252 | ) |
| Loss before income tax expense |  |  | (8,115 | ) |  |  | (20,061 | ) |  |  | (32,820 | ) |  |  | (47,043 | ) |
| Income tax (benefit) expense |  |  | 302 |  |  |  | 74 |  |  |  | 733 |  |  |  | (683 | ) |
| Net loss |  | $ | (8,417 | ) |  | $ | (20,135 | ) |  | $ | (33,553 | ) |  | $ | (46,360 | ) |
| Net loss per common share |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | (0.14 | ) |  | $ | (0.38 | ) |  | $ | (0.55 | ) |  | $ | (0.89 | ) |
| Diluted |  | $ | (0.14 | ) |  | $ | (0.38 | ) |  | $ | (0.55 | ) |  | $ | (0.89 | ) |
| Weighted average number of common shares outstanding |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  |  | 62,309 |  |  |  | 52,792 |  |  |  | 60,578 |  |  |  | 51,966 |  |
| Diluted |  |  | 62,309 |  |  |  | 52,792 |  |  |  | 60,578 |  |  |  | 51,966 |  |

[0001193125-14-037960:8k_2_02:27]
| AMSC Reports Q3 Results |  | Page 5 |

[0001193125-14-037960:8k_2_02:28]
UNAUDITED CONSOLIDATED BALANCE SHEETS

[0001193125-14-037960:8k_2_02:29]
(In thousands)

[0001193125-14-037960:8k_2_02:30]
|  |  | December 31,2013 |  |  | March 31,2013 |  |
| ASSETS |  |  |  |  |  |  |  |  |
| Current assets: |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 35,394 |  |  | $ | 39,243 |  |
| Accounts receivable, net |  |  | 8,525 |  |  |  | 18,864 |  |
| Inventory |  |  | 25,167 |  |  |  | 33,473 |  |
| Prepaid expenses and other current assets |  |  | 19,538 |  |  |  | 22,469 |  |
| Restricted cash |  |  | 1,405 |  |  |  | 6,136 |  |
| Total current assets |  |  | 90,029 |  |  |  | 120,185 |  |
| Property, plant and equipment, net |  |  | 67,163 |  |  |  | 74,626 |  |
| Intangibles, net |  |  | 2,147 |  |  |  | 2,749 |  |
| Restricted cash |  |  | 4,901 |  |  |  | 4,820 |  |
| Deferred tax assets |  |  | 5,421 |  |  |  | 5,354 |  |
| Other assets |  |  | 8,710 |  |  |  | 9,020 |  |
| Total assets |  | $ | 178,371 |  |  | $ | 216,754 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |  |  |  |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |  |  |  |
| Accounts payable and accrued expenses |  | $ | 23,503 |  |  | $ | 30,138 |  |
| Note payable, current portion, net of discount of $677 as of December 31, 2013 and $458 as of March 31, 2013 |  |  | 6,272 |  |  |  | 4,158 |  |
| Current portion of convertible note, net of discount of $1,287 as of December 31, 2013 and $4,289 as of March 31, 2013 |  |  | 9,125 |  |  |  | 4,610 |  |
| Derivative liability |  |  | 2,587 |  |  |  | 4,162 |  |
| Adverse purchase commitments |  |  | 429 |  |  |  | 1,440 |  |
| Deferred revenue |  |  | 10,023 |  |  |  | 29,805 |  |
| Deferred tax liabilities |  |  | 5,440 |  |  |  | 5,444 |  |
| Total current liabilities |  |  | 57,379 |  |  |  | 79,757 |  |
| Note Payable, net of current portion and discount of $384 as of December 31, 2013 and $95 as of March 31, 2013 |  |  | 7,283 |  |  |  | 3,367 |  |
| Convertible note, net of discount of $600 as of March 31, 2013 |  |  | — |  |  |  | 5,881 |  |
| Deferred revenue |  |  | 1,318 |  |  |  | 1,340 |  |
| Other liabilities |  |  | 1,179 |  |  |  | 1,291 |  |
| Total liabilities |  |  | 67,159 |  |  |  | 91,636 |  |
| Stockholders’ equity: |  |  |  |  |  |  |  |  |
| Common stock |  |  | 673 |  |  |  | 603 |  |
| Additional paid-in capital |  |  | 942,466 |  |  |  | 923,847 |  |
| Treasury stock |  |  | (370 | ) |  |  | (313 | ) |
| Accumulated other comprehensive loss |  |  | 2,127 |  |  |  | 1,112 |  |
| Accumulated deficit |  |  | (833,684 | ) |  |  | (800,131 | ) |
| Total stockholders’ equity |  |  | 111,212 |  |  |  | 125,118 |  |
| Total liabilities and stockholders’ equity |  | $ | 178,371 |  |  | $ | 216,754 |  |

[0001193125-14-037960:8k_2_02:31]
| AMSC Reports Q3 Results |  | Page 6 |

[0001193125-14-037960:8k_2_02:32]
UNAUDITED CONSOLIDATED STATEMENTS OF CASH FLOWS

[0001193125-14-037960:8k_2_02:33]
(In thousands)

[0001193125-14-037960:8k_2_02:34]
|  |  | Nine months ended December 31, |  |
|  |  | 2013 |  |  | 2012 |  |
| Cash flows from operating activities: |  |  |  |  |  |  |  |  |
| Net loss |  | $ | (33,553 | ) |  | $ | (46,360 | ) |
| Adjustments to reconcile net (loss) income to net cash (used in) provided by operations: |  |  |  |  |  |  |  |  |
| Depreciation and amortization |  |  | 8,052 |  |  |  | 10,143 |  |
| Stock-based compensation expense |  |  | 7,328 |  |  |  | 5,968 |  |
| Restructuring charges, net of payments |  |  | 167 |  |  |  | 261 |  |
| Impairment of long-lived and intangible assets |  |  | — |  |  |  | 4,507 |  |
| Provision for excess and obsolete inventory |  |  | 287 |  |  |  | 957 |  |
| Adverse purchase commitment recoveries, net |  |  | — |  |  |  | (8,428 | ) |
| Loss on minority interest investments |  |  | 789 |  |  |  | 1,914 |  |
| Change in fair value of derivatives and warrants |  |  | (1,890 | ) |  |  | (6,114 | ) |
| Non-cash interest expense |  |  | 5,902 |  |  |  | 8,404 |  |
| Other non-cash items |  |  | 1,181 |  |  |  | 1,790 |  |
| Changes in operating asset and liability accounts: |  |  |  |  |  |  |  |  |
| Accounts receivable |  |  | 10,414 |  |  |  | 6,085 |  |
| Inventory |  |  | 8,682 |  |  |  | (8,173 | ) |
| Prepaid expenses and other current assets |  |  | 3,462 |  |  |  | 4,699 |  |
| Accounts payable and accrued expenses |  |  | (8,612 | ) |  |  | (20,330 | ) |
| Deferred revenue |  |  | (20,575 | ) |  |  | 3,986 |  |
| Net cash used in operating activities |  |  | (18,366 | ) |  |  | (40,691 | ) |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |
| Net cash provided by investing activities |  |  | 4,398 |  |  |  | 4,691 |  |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |
| Net cash provided by financing activities |  |  | 9,750 |  |  |  | 32,262 |  |
| Effect of exchange rate changes on cash and cash equivalents |  |  | 369 |  |  |  | (84 | ) |
| Net decrease in cash and cash equivalents |  |  | (3,849 | ) |  |  | (3,822 | ) |
| Cash and cash equivalents at beginning of year |  |  | 39,243 |  |  |  | 46,279 |  |
| Cash and cash equivalents at end of period |  | $ | 35,394 |  |  | $ | 42,457 |  |

[0001193125-14-037960:8k_2_02:35]
| AMSC Reports Q3 Results |  | Page 7 |

[0001193125-14-037960:8k_2_02:36]
RECONCILIATION OF GAAP NET INCOME (LOSS) TO NON-GAAP NET INCOME (LOSS)

[0001193125-14-037960:8k_2_02:37]
(In thousands, except per share data)

[0001193125-14-037960:8k_2_02:38]
|  |  | Three months ended December 31, |  |  | Nine months ended December 31, |  |
|  |  | 2013 |  |  | 2012 |  |  | 2013 |  |  | 2012 |  |
| Net loss |  | $ | (8,417 | ) |  | $ | (20,135 | ) |  | $ | (33,553 | ) |  | $ | (46,360 | ) |
| Adverse purchase commitment recoveries, net |  |  | — |  |  |  | (119 | ) |  |  | — |  |  |  | (8,428 | ) |
| Stock-based compensation |  |  | 3,040 |  |  |  | 1,929 |  |  |  | 7,328 |  |  |  | 5,968 |  |
| Amortization of acquisition-related intangibles |  |  | 84 |  |  |  | 81 |  |  |  | 247 |  |  |  | 242 |  |
| Restructuring and impairment charges |  |  | 108 |  |  |  | 6,702 |  |  |  | 872 |  |  |  | 6,845 |  |
| Sinovel litigation |  |  | — |  |  |  | (12 | ) |  |  | (7 | ) |  |  | 411 |  |
| Consumption of zero cost-basis inventory |  |  | (1,142 | ) |  |  | (602 | ) |  |  | (3,635 | ) |  |  | (1,389 | ) |
| Change of fair value of derivatives and warrants |  |  | (535 | ) |  |  | (5,217 | ) |  |  | (1,890 | ) |  |  | (6,114 | ) |
| Non-cash interest expense |  |  | 1,137 |  |  |  | 3,867 |  |  |  | 5,902 |  |  |  | 8,404 |  |
| Non-GAAP net loss |  | $ | (5,725 | ) |  | $ | (13,506 | ) |  | $ | (24,736 | ) |  | $ | (40,421 | ) |
| Non-GAAP loss per share |  | $ | (0.09 | ) |  | $ | (0.26 | ) |  | $ | (0.41 | ) |  | $ | (0.78 | ) |
| Weighted average shares outstanding |  |  | 62,309 |  |  |  | 52,792 |  |  |  | 60,578 |  |  |  | 51,966 |  |

[0001193125-14-037960:8k_2_02:39]
RECONCILIATION OF FORECAST GAAP NET LOSS TO NON-GAAP NET LOSS

[0001193125-14-037960:8k_2_02:40]
(In millions, except per share data)

[0001193125-14-037960:8k_2_02:41]
|  |  | Three months endingMarch 31, 2014 |  |
| Net loss |  | $ | (16.0 | ) |
| Amortization of acquisition-related intangibles |  |  | 0.1 |  |
| Stock-based compensation |  |  | 3.5 |  |
| Non-cash interest expense |  |  | 1.5 |  |
| Consumption of zero-cost inventory |  |  | (1.1 | ) |
| Non-GAAP net loss |  | $ | (12.0 | ) |
| Non-GAAP net loss per share |  | $ | (0.18 | ) |
| Weighted average shares outstanding |  |  | 68.0 |  |

[0001193125-14-037960:8k_2_02:42]
Note: Non-GAAP net loss is defined by the company as net loss before adverse purchase commitments (recoveries) losses, net;
stock-based compensation; amortization of acquisition-related intangibles; restructuring and impairment charges; Sinovel litigation costs; consumption of zero cost-basis inventory; non-cash interest expense; change in fair value of derivatives and
warrants and other unusual charges; net of any tax effects related to these items. The company believes non-GAAP net loss assists management and investors in comparing the company’s performance across reporting periods on a consistent basis by
excluding these non-cash or other non-recurring charges that it does not believe are indicative of its core operating performance. The company also regards non-GAAP net loss as a useful measure of operating performance and cash flow to

[0001193125-14-037960:8k_2_02:43]
| AMSC Reports Q3 Results |  | Page 8 |

[0001193125-14-037960:8k_2_02:44]
complement operating loss, net loss and other GAAP financial performance measures. In addition, the company uses non-GAAP net loss as a factor in evaluating management’s performance when
determining incentive compensation and to evaluate the effectiveness of its business strategies.

[0001193125-14-037960:8k_2_02:45]
Generally, a non-GAAP financial measure is a
numerical measure of a company’s performance, financial position or cash flow that either excludes or includes amounts that are not normally excluded or included in the most directly comparable measure calculated and presented in accordance
with GAAP. The non-GAAP measures included in this release, however, should be considered in addition to, and not as a substitute for or superior to, operating income, cash flows, or other measures of financial performance prepared in accordance with
GAAP. A reconciliation of non-GAAP to GAAP net loss is set forth in the table above.

[0001193125-14-037960:8k_2_02:46]
AMSC Contact:

[0001193125-14-037960:8k_2_02:47]
Kerry Farrell

[0001193125-14-037960:8k_2_02:48]
Phone: 978-842-3247

[0001193125-14-037960:8k_2_02:49]
Email: kerry.farrell@amsc.com
