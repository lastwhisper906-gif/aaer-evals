# AMSC MD&A — 0001564590-14-000165


## mdna

[0001564590-14-000165:mdna:1]
[same as prior period, unchanged from 0001564590-13-001183:mdna:1]

[0001564590-14-000165:mdna:2]
market position; the commercial uses of superconductor products are limited today, and a widespread commercial market for our products may not develop; there are a number of technological challenges that must be successfully addressed before our superconductor products can gain widespread commercial acceptance, and our inability to address such technological challenges could adversely affect our ability to acquire customers for our products; we have not manufactured our Amperium wire in commercial quantities, and a failure to manufacture our Amperium wire in commercial quantities at acceptable cost and quality levels would substantially limit our future revenue and profit potential; third parties have or may acquire patents that cover the materials, processes and technologies we use or may use in the future to manufacture our Amperium products, and our success depends on our ability to license such patents or other proprietary rights; our technology and products could infringe intellectual property rights of others, which may require costly litigation and, if we are not successful, could cause us to pay substantial damages and disrupt our business; we have filed a demand for arbitration and other lawsuits against our former largest customer, Sinovel, regarding amounts we contend are overdue. We cannot be certain as to the outcome of these proceedings; we have been named as a party to purported stockholder class actions and stockholder derivative complaints, and we may be named in additional litigation, all of which will require significant management time and attention, result in significant legal expenses and may result in an unfavorable outcome, which could have a material adverse effect on our business, operating results and financial condition; our 7% convertible note contains warrants and provisions that could limit our ability to repay the note in shares of common stock and should the note be repaid in stock, shareholders could experience significant dilution; our common stock has experienced, and may continue to experience, significant market price and volume fluctuations, which may prevent our stockholders from selling our common stock at a profit and could lead to costly litigation against us that could divert our management’s attention. These and the important factors discussed under the caption “Risk Factors” in Part 1. Item 1A of our Form 10-K for the fiscal year ended March 31, 2013, among others, could cause actual results to differ materially from those indicated by forward-looking statements made herein and presented elsewhere by management from time to time. Any such forward-looking statements represent management’s estimates as of the date of this Quarterly Report on Form 10-Q. While we may elect to update such forward-looking statements at some point in the future, we disclaim any obligation to do so, even if subsequent events cause our views to change. These forward-looking statements should not be relied upon as representing our views as of any date subsequent to the date of this Quarterly Report on Form 10-Q.

[0001564590-14-000165:mdna:3]
[same as prior period, unchanged from 0001564590-13-001183:mdna:3]

[0001564590-14-000165:mdna:4]
[same as prior period, unchanged from 0001564590-13-001183:mdna:4]

[0001564590-14-000165:mdna:5]
[same as prior period, unchanged from 0001564590-13-001183:mdna:5]

[0001564590-14-000165:mdna:6]
[same as prior period, unchanged from 0001564590-13-001183:mdna:6]

[0001564590-14-000165:mdna:7]
[same as prior period, unchanged from 0001564590-13-001183:mdna:7]

[0001564590-14-000165:mdna:8]
[same as prior period, unchanged from 0001564590-13-001183:mdna:23]

[0001564590-14-000165:mdna:9]
[same as prior period, unchanged from 0001564590-13-001183:mdna:9]

[0001564590-14-000165:mdna:10]
| — | Wind. Through our Windtec Solutions, our Wind business segment enables manufacturers to field wind turbines with exceptional power output, reliability and affordability. We supply advanced power electronics and control systems, license our highly engineered wind turbine designs, and provide extensive customer support services to wind turbine manufacturers. Our design portfolio includes a broad range of drive trains and power ratings. We provide a broad range of power electronics and software-based control systems that are highly integrated and redesigned for optimized performance, efficiency, and grid compatibility. |

[0001564590-14-000165:mdna:11]
| — | Grid. Through our Gridtec Solutions, our Grid business segment enables electric utilities and renewable energy project developers to connect, transmit and distribute power with exceptional efficiency, reliability and affordability. We provide transmission planning services that allow us to identify power grid congestion, poor power quality and other risks, which help us determine how our solutions can improve network performance. These services often lead to sales of grid interconnection solutions for wind farms and solar power plants, power quality systems and transmission and distribution cable systems. |

[0001564590-14-000165:mdna:12]
[same as prior period, unchanged from 0001564590-13-001183:mdna:12]

[0001564590-14-000165:mdna:13]
On April 4, 2012, we completed a private placement of a $25.0 million senior convertible note (the “Initial Note”) with Capital Ventures International (“CVI”), an affiliate of Heights Capital Management. On December 20, 2012, we entered into an Amendment and Exchange Agreement (the “Amendment”) with CVI, pursuant to which we exchanged the Initial Note for a new unsecured, senior convertible note (the “Exchanged Note”), which had the same principal amount and accrued interest as the Initial Note at the time of the exchange. On October 9, 2013, we entered into a Second Amendment and Warrant Exchange Agreement (the “Second Amendment”) with CVI which (i) waived certain provisions of the Amended Purchase Agreement, (ii) amended certain provisions of the Exchanged Note, and (iii) exchanged the warrant for a new warrant (the “Exchanged Warrant”), with a reduced exercise price of $2.61 per share of common stock. Other than the reduced exercise price, the Exchanged Warrant has the same terms and conditions as the original warrant. On June 5, 2012, we entered into a $10.0 million Loan and Security Agreement (“Term Loan”) with Hercules Technology Growth Capital, Inc. (“Hercules”).  On November 15, 2013, we amended the Term Loan with Hercules and entered into a new term loan (“New Term Loan”), borrowing an additional $10.0 million. In addition, on November 15, 2013, we entered into an At Market Sales Arrangement (“ATM”) under which we may, at our discretion, sell up to $30.0 million of shares of our common stock (before expenses) through our sales agent, MLV & Co. LLC (“MLV”).  See Liquidity and Capital Resources below for further discussion of these financing arrangements.

[0001564590-14-000165:mdna:14]
We have experienced recurring operating losses and as of December 31, 2013, had an accumulated deficit of $833.7 million. In addition, we have experienced recurring negative operating cash flows, which have resulted in a reduction of our cash balance. These factors raise substantial doubt regarding our ability to continue as a going concern. Our financial statements do not include any adjustments that might result from the outcome of this uncertainty. At December 31, 2013, we had cash and cash equivalents of $35.4 million. Cash used in operations for the nine months ended December 31, 2013 was $18.4 million.

[0001564590-14-000165:mdna:15]
In order for us to continue operations beyond the next twelve months and be able to discharge our liabilities and commitments in the normal course of business, we need to increase sales through executing our strategy to broaden our customer base, enter new markets, and commercialize our superconductor product line. Otherwise, we may need to further reduce operating expenses in line with business conditions in order to decrease the amount of cash used in operations.  We intend to continue to work with the holder of our convertible note in order to maintain the ability to make monthly amortization payments on the convertible note in shares of common stock. In addition, we are actively seeking to sell our minority investments in Tres Amigas and Blade Dynamics and have engaged a financial advisor to assist with that effort. There can be no assurance that we will be able to sell one or both of these investments on commercially reasonable terms or at all.  In addition, we maintain the ability to sell shares of our common stock under the ATM at our discretion to enhance liquidity.

[0001564590-14-000165:mdna:16]
In response to the Sinovel situation discussed below and challenging market conditions, particularly in the wind power market, from April 1, 2011 through the date of this filing, the Company has substantially reduced its global workforce. These workforce reductions are expected to lower operating costs and enhance liquidity.

[0001564590-14-000165:mdna:17]
[same as prior period, unchanged from 0001564590-13-001183:mdna:18]

[0001564590-14-000165:mdna:18]
[same as prior period, unchanged from 0001564590-13-001183:mdna:19]

[0001564590-14-000165:mdna:19]
[same as prior period, unchanged from 0001564590-13-001183:mdna:20]

[0001564590-14-000165:mdna:20]
[same as prior period, unchanged from 0001564590-13-001183:mdna:21]

[0001564590-14-000165:mdna:21]
We cannot provide any assurance as to the outcome of these legal actions. For more information about these legal proceedings, see Part II, Item 1, “Legal Proceedings.”

[0001564590-14-000165:mdna:22]
34

[0001564590-14-000165:mdna:23]
[same as prior period, unchanged from 0001564590-13-001183:mdna:24]

[0001564590-14-000165:mdna:24]
The preparation of the unaudited condensed consolidated financial statements requires that we make estimates and judgments that affect the reported amounts of assets, liabilities, revenues and expenses, and related disclosure of contingent assets and liabilities. We base our estimates on historical experience and various other assumptions that are believed to be reasonable under the circumstances, the results of which form the basis for making judgments about the carrying values of assets and liabilities that are not readily apparent from other sources. Actual results may differ under different assumptions or conditions. There were no significant changes in the critical accounting policies during the nine months ended December 31, 2013 that were disclosed in our Form 10-K for fiscal 2012, which ended on March 31, 2013.

[0001564590-14-000165:mdna:25]
[same as prior period, unchanged from 0001564590-13-001183:mdna:26]

[0001564590-14-000165:mdna:26]
Three and nine months ended December 31, 2013 compared to the three and nine months ended December 31, 2012

[0001564590-14-000165:mdna:27]
[same as prior period, unchanged from 0001564590-13-001183:mdna:28]

[0001564590-14-000165:mdna:28]
Total revenues increased by 18% and 1% to $20.6 million and $67.8 million, respectively, for the three and nine months ended December 31, 2013, respectively, compared to $17.4 million and $67.0 million for the three and nine months ended December 31, 2012, respectively. Our revenues are summarized as follows (in thousands):

[0001564590-14-000165:mdna:29]
|  | Three months ended |  |  | Nine months ended |  |
|  | December 31, |  |  | December 31, |  |
|  | 2013 |  |  | 2012 |  |  | 2013 |  |  | 2012 |  |
| Revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Wind | $ | 13,545 |  |  | $ | 6,808 |  |  | $ | 42,937 |  |  | $ | 35,321 |  |
| Grid |  | 7,018 |  |  |  | 10,609 |  |  |  | 24,893 |  |  |  | 31,679 |  |
| Total | $ | 20,563 |  |  | $ | 17,417 |  |  | $ | 67,830 |  |  | $ | 67,000 |  |

[0001564590-14-000165:mdna:30]
Our Wind business unit accounted for 66% and 63% of total revenues for the three and nine months ended December 31, 2013, respectively, compared to 39% and 53% for the three and nine months ended December 31, 2012, respectively. Revenues in the Wind business unit increased 99% and 22% to $13.5 million and $42.9 million in the three and nine months ended December 31, 2013, respectively, from $6.8 million and $35.3 million in the three and nine months ended December 31, 2012, respectively. Wind business unit revenues during the three and nine months ended December 31, 2013 increased primarily due to higher revenues from customers in both India and China, partially offset by lower revenues in Korea.

[0001564590-14-000165:mdna:31]
Our Grid business unit accounted for 34% and 37% of total revenues for the three and nine months ended December 31, 2013, respectively, compared to 61% and 47% for the three and nine months ended December 31, 2012. Our Grid business unit revenues decreased 34% and 21% to $7.0 million and $24.9 million in the three and nine months ended December 31, 2013, respectively, from $10.6 million and $31.7 million in the three and nine months ended December 31, 2012, respectively. Grid business unit revenues decreased in the three months ended December 31, 2013 primarily due to lower D-VAR system revenues as a result of a large project in the UK in the prior year period.  Grid business unit revenues decreased in the nine months ended December 31, 2013 primarily due to lower D-VAR revenues from Australian and UK customers.

[0001564590-14-000165:mdna:32]
Project HYDRA is a project with Consolidated Edison, Inc. which is being partially funded by the Department of Homeland Security (“DHS”). DHS is expected to invest up to a total of $29.0 million in the development of a new HTS power grid technology called Resilient Electric Grid systems. This fault current limiting cable system is designed to utilize customized Amperium® HTS wires, and ancillary controls to deliver more power through the grid while also being able to suppress power surges that can disrupt service. On July 8, 2013, DHS committed the additional $8.6 million in funding on Project HYDRA. DHS has now committed 100% of the total expected funding for this project. Consolidated Edison and Southwire Company are our subcontractors on this project. We recorded $0.5 million and $1.6 million of revenue on this project for the three and nine months ended December 31, 2013, respectively, and $0.5 million and $1.7 million for the three and nine months ended December 31, 2012, respectively.

[0001564590-14-000165:mdna:33]
35

[0001564590-14-000165:mdna:34]
The following table sets forth customers who represented 10% or more of our total revenues for the three and nine months ended December 31, 2013 and 2012:

[0001564590-14-000165:mdna:35]
|  | Three months ended |  |  | Nine months ended |  |
|  | December 31, |  |  | December 31, |  |
|  | 2013 |  |  | 2012 |  |  | 2013 |  |  | 2012 |  |
| INOX Wind Limited |  | 35 | % |  |  | 19 | % |  |  | 25 | % |  |  | 17 | % |
| CSR Zhuzhou Institute Co., Ltd |  | 18 | % |  | — | % |  | <10 | % |  | <10 | % |
| Beijing JINGCHENG New Energy Co., Ltd. | <10 | % |  | <10 | % |  |  | 22 | % |  |  | 17 | % |
| CG Power Solutions UK Ltd | — | % |  |  | 21 | % |  | <10 | % |  | <10 | % |
| E.ON Climate & Renewables | <10 | % |  |  | 19 | % |  | <10 | % |  | <10 | % |

[0001564590-14-000165:mdna:36]
[same as prior period, unchanged from 0001564590-13-001183:mdna:36]

[0001564590-14-000165:mdna:37]
Cost of revenues were $15.9 million and $56.5 million for the three and nine months ended December 31, 2013, respectively, compared to $16.5 million and $53.8 million for the three and nine months ended December 31, 2012, respectively. Gross margin was 22.9% and 16.8% for the three and nine months ended December 31, 2013, respectively, compared to 5.1% and 19.6% for the three and nine months ended December 31, 2012, respectively. The increase in gross margin for the three months ended December 31, 2013 as compared to the same period in fiscal 2012 was primarily due to increased revenues from certain Chinese customers which included amounts for which revenue is recorded at the time of payment, whereas the associated costs were recorded in a prior period, and increased consumption of previously written off inventory in the current year period. The decrease in gross margin for the nine months ended December 31, 2013 was primarily due to non-recurring settlements of certain adverse purchase order liabilities resulting in a benefit to cost of revenues of $8.4 million in the prior year period.

[0001564590-14-000165:mdna:38]
[same as prior period, unchanged from 0001564590-13-001183:mdna:38]

[0001564590-14-000165:mdna:39]
[same as prior period, unchanged from 0001564590-13-001183:mdna:39]

[0001564590-14-000165:mdna:40]
[same as prior period, unchanged from 0001564590-13-001183:mdna:40]

[0001564590-14-000165:mdna:41]
|  | Three months ended |  |  | Nine months ended |  |
|  | December 31, |  |  | December 31, |  |
|  | 2013 |  |  | 2012 |  |  | 2013 |  |  | 2012 |  |
| R&D expenses per condensed consolidated statements of operations | $ | 2,951 |  |  | $ | 3,948 |  |  | $ | 9,061 |  |  | $ | 11,480 |  |
| R&D expenditures reclassified as cost of revenues |  | 2,740 |  |  |  | 3,044 |  |  |  | 7,675 |  |  |  | 10,184 |  |
| R&D expenditures offset by cost-sharing funding |  | 80 |  |  |  | 40 |  |  |  | 279 |  |  |  | 144 |  |
| Aggregated R&D expenses | $ | 5,771 |  |  | $ | 7,032 |  |  | $ | 17,015 |  |  | $ | 21,808 |  |

[0001564590-14-000165:mdna:42]
R&D expenses (exclusive of amounts classified as cost of revenues and amounts offset by cost-sharing funding) decreased by 25% and 21% to $3.0 million and $9.1 million for the three and nine months ended December 31, 2013, respectively, from $3.9 million and $11.5 million for the three and nine months ended December 31, 2012, respectively. The decreases in R&D expenses were driven primarily by the realization of savings from cost reduction actions that were implemented in fiscal 2012. The decreases in R&D expenditures reclassified to costs of revenue were a result of decreased activity under license and development contracts for wind turbine designs compared to the prior year periods. Aggregated R&D expenses, which include amounts classified as cost of revenues and amounts offset by cost-sharing funding, decreased 18% and 22% to $5.8 million and $17.0 million for the three and nine months ended December 31, 2013, respectively, from $7.0 million and $21.8 million for the three and nine months ended December 31, 2012, respectively.

[0001564590-14-000165:mdna:43]
[same as prior period, unchanged from 0001564590-13-001183:mdna:43]

[0001564590-14-000165:mdna:44]
[same as prior period, unchanged from 0001564590-13-001183:mdna:44]

[0001564590-14-000165:mdna:45]
SG&A expenses decreased by 24% each to $8.2 million and $27.7 million in the three and nine months ended December 31, 2013, respectively, from $10.8 million and $36.3 million in the three and nine months ended December 31, 2012, respectively. The decreases in SG&A expenses were due primarily to the realization of savings from cost reductions actions that were implemented in fiscal 2012 as well as a reduction in legal costs.

[0001564590-14-000165:mdna:46]
[same as prior period, unchanged from 0001564590-13-001183:mdna:46]

[0001564590-14-000165:mdna:47]
We recorded amortization expense related to our core technology and know-how, trade names and trademark intangible assets of $0.1 million and $0.2 million in the three and nine month periods ended December 31, 2013, respectively, compared to $0.1 million and $0.2 million in the three and nine month periods ended December 31, 2012, respectively.

[0001564590-14-000165:mdna:48]
Restructuring and Impairments

[0001564590-14-000165:mdna:49]
We recorded $0.1 million and $0.9 million of restructuring charges in the three and nine months ended December 31, 2013, respectively. We recorded restructuring and impairment charges of $6.7 million and $6.8 million in the three and nine months ended December 31, 2012, respectively. The amounts in the three and nine months ended December 31, 2013 consist primarily of employee severance and benefit costs related to our reduction in force undertaken in July 2013. The amounts in the three and nine months ended December 31, 2012 consist primarily of a long-lived asset impairment charge of $4.5 million recorded in the three months ended December 31, 2012, as well as employee severance and benefit costs of $2.2 million and $2.3 million in the three and nine months ended December 31, 2012, respectively related to our restructuring actions.

[0001564590-14-000165:mdna:50]
[same as prior period, unchanged from 0001564590-13-001183:mdna:50]

[0001564590-14-000165:mdna:51]
[same as prior period, unchanged from 0001564590-13-001183:mdna:51]

[0001564590-14-000165:mdna:52]
|  | Three months ended |  |  | Nine months ended |  |
|  | December 31, |  |  | December 31, |  |
|  | 2013 |  |  | 2012 |  |  | 2013 |  |  | 2012 |  |
| Operating (loss) income: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Wind | $ | 1,067 |  |  | $ | (5,365 | ) |  | $ | (3,207 | ) |  | $ | (10,514 | ) |
| Grid |  | (4,670 | ) |  |  | (6,705 | ) |  |  | (15,287 | ) |  |  | (18,620 | ) |
| Unallocated corporate expenses |  | (3,072 | ) |  |  | (8,546 | ) |  |  | (8,058 | ) |  |  | (12,580 | ) |
| Total | $ | (6,675 | ) |  | $ | (20,616 | ) |  | $ | (26,552 | ) |  | $ | (41,714 | ) |

[0001564590-14-000165:mdna:53]
Our Wind segment generated an operating profit of $1.1 million and an operating loss of $3.2 million in the three and nine months ended December 31, 2013, respectively, compared to operating losses of $5.4 million and $10.5 million in the three and nine months ended December 31, 2012, respectively. The decreases in Wind business unit operating losses were primarily due to higher gross profit in the three and nine months ended December 31, 2013, due to higher revenues from certain Chinese customers recorded at 100% gross margin as previously discussed and lower operating expenses as a result of cost reduction efforts during fiscal 2012 and 2013, and for the nine month period, partially offset by a gain from the settlement of certain adverse purchase order liabilities in the prior year.

[0001564590-14-000165:mdna:54]
The operating losses in our Grid segment decreased to $4.7 million and $15.3 million in the three and nine months ended December 31, 2013, respectively, compared to $6.7 million and $18.6 million in the three and nine months ended December 31, 2012, respectively. The decreases in the Grid business unit operating losses were primarily due to lower operating expenses in the three and nine months ended December 31, 2013, as a result of our cost reduction actions, partially offset by lower D-VAR revenue, as previously discussed.

[0001564590-14-000165:mdna:55]
Unallocated corporate expenses primarily include stock-based compensation expense of $3.0 million and $7.3 million, and restructuring and impairment charges of $0.1 and $0.9 million, for the three and nine months ended December 31, 2013, respectively.  Unallocated corporate expenses primarily consist of stock-based compensation expense of $1.9 million and $6.0 million, respectively, and restructuring and impairment charges of $6.7 million and $6.8 million, respectively, for the three and nine months ended December 31, 2012, respectively.

[0001564590-14-000165:mdna:56]
[same as prior period, unchanged from 0001564590-13-001183:mdna:56]

[0001564590-14-000165:mdna:57]
The change in fair value of derivatives and warrants resulted in gains of $0.5 million and $1.9 million in the three and nine months ended December 31, 2013, respectively, compared to gains of $5.2 million and $6.1 million for the three and nine months ended December 31, 2012, respectively. The changes were primarily driven by a lower reduction in our stock price during the three and nine months ended December 31, 2013, compared to the same periods in fiscal 2012, which is a key valuation variable, as well as a reduction in the principal outstanding on the convertible note due to payments to the note holder in shares of common stock.

[0001564590-14-000165:mdna:58]
[same as prior period, unchanged from 0001564590-13-001183:mdna:58]

[0001564590-14-000165:mdna:59]
Interest expense, net, was $1.6 million and $7.3 million in the three and nine months ended December 31, 2013, respectively, compared to $4.6 million and $10.2 million in the three and nine months ended December 31, 2012, respectively. The decreases in interest expense were due primarily to lower non-cash interest expense as a result of lower debt discount amortization compared to prior year periods. In addition, there was non-cash interest expense of $1.3 million in the three months ended December 31, 2012 resulting from the discount available to CVI on stock used to settle principal and interest on the convertible note. There were no debt payments made in stock and no discount recorded to non-cash interest expense during the three months ended December 31, 2013.

[0001564590-14-000165:mdna:60]
[same as prior period, unchanged from 0001564590-13-001183:mdna:60]

[0001564590-14-000165:mdna:61]
Other expense, net, was $0.3 million and $0.9 million in the three and nine months ended December 31, 2013, respectively, compared to $0.1 million and $1.3 million in the three and nine months ended December 31, 2012, respectively. For the three months ended December 31, 2013 and 2012, the increase in other expense, net was primarily due to proceeds of $0.5 million from a sale of a non-operating asset received during the three months ended December 31, 2012, partially offset by lower minority interest recorded from our investment in Blade Dynamics, as we no longer meet the criteria to account for our investment under the equity method.  For the nine months ended December 31, 2013 and 2012, the decrease in other expense, net, was driven primarily by lower minority interest as discussed above.

[0001564590-14-000165:mdna:62]
[same as prior period, unchanged from 0001564590-13-001183:mdna:62]

[0001564590-14-000165:mdna:63]
In the three and nine months ended December 31, 2013, we recorded an income tax expense of $0.3 million and $0.7 million, respectively, compared to income tax expense of $0.1 million and a benefit of $0.7 million in the three and nine months ended December 31, 2012, respectively. The increases in income tax expense were primarily due to increased income taxes in foreign jurisdictions as well as, with respect to the nine months ended December 31, 2013, withholding taxes for repatriation of funds from certain foreign jurisdictions. The income tax benefit for the nine months ended December 31, 2012 was due primarily to a refund of Chinese income taxes.

[0001564590-14-000165:mdna:64]
[same as prior period, unchanged from 0001564590-13-001183:mdna:64]

[0001564590-14-000165:mdna:65]
[same as prior period, unchanged from 0001564590-13-001183:mdna:65]

[0001564590-14-000165:mdna:66]
We define non-GAAP net loss as net loss before adverse purchase commitment (recoveries) losses, net, stock-based compensation, amortization of acquisition-related intangibles, restructuring and impairment charges, Sinovel litigation, consumption of zero cost-basis inventory, changes in fair value of derivatives and warrants, non-cash interest expense, and the other non-cash or unusual items indicated in the table below. We believe non-GAAP net loss assists management and investors in comparing our performance across reporting periods on a consistent basis by excluding these non-cash or non-recurring charges that we do not believe are indicative of our core operating performance. We also regard non-GAAP net loss as a useful measure of operating performance which more closely aligns net loss with cash used in/provided by continuing operations. In addition, we use non-GAAP net loss as a factor in evaluating management’s performance when determining incentive compensation and to evaluate the effectiveness of our business strategies. A reconciliation of non-GAAP to GAAP net loss is set forth in the table below (in thousands, except per share data):

[0001564590-14-000165:mdna:67]
|  | Three months ended December 31, |  |  | Nine months ended December 31, |  |
|  | 2013 |  |  | 2012 |  |  | 2013 |  |  | 2012 |  |
| Net loss | $ | (8,417 | ) |  | $ | (20,135 | ) |  | $ | (33,553 | ) |  | $ | (46,360 | ) |
| Adverse purchase commitment (recoveries) losses, net |  | - |  |  |  | (119 | ) |  |  | - |  |  |  | (8,428 | ) |
| Stock-based compensation |  | 3,040 |  |  |  | 1,929 |  |  |  | 7,328 |  |  |  | 5,968 |  |
| Amortization of acquisition-related intangibles |  | 84 |  |  |  | 81 |  |  |  | 247 |  |  |  | 242 |  |
| Restructuring and impairment charges |  | 108 |  |  |  | 6,702 |  |  |  | 872 |  |  |  | 6,845 |  |
| Sinovel litigation |  | - |  |  |  | (12 | ) |  |  | (7 | ) |  |  | 411 |  |
| Consumption of zero cost-basis inventory |  | (1,142 | ) |  |  | (602 | ) |  |  | (3,635 | ) |  |  | (1,389 | ) |
| Change in fair value of derivatives and warrants |  | (535 | ) |  |  | (5,217 | ) |  |  | (1,890 | ) |  |  | (6,114 | ) |
| Non-cash interest expense |  | 1,137 |  |  |  | 3,867 |  |  |  | 5,902 |  |  |  | 8,404 |  |
| Non-GAAP net loss | $ | (5,725 | ) |  | $ | (13,506 | ) |  | $ | (24,736 | ) |  | $ | (40,421 | ) |
| Non-GAAP loss per share | $ | (0.09 | ) |  | $ | (0.26 | ) |  | $ | (0.41 | ) |  | $ | (0.78 | ) |
| Weighted average shares outstanding |  | 62,309 |  |  |  | 52,792 |  |  |  | 60,578 |  |  |  | 51,966 |  |

[0001564590-14-000165:mdna:68]
We incurred a non-GAAP net loss of $5.7 million and $24.7 million or $0.09 and $0.41 per share, for the three and nine months ended December 31, 2013, respectively, compared to a non-GAAP net loss of $13.5 million and $40.4 million, or $0.26 and $0.78 per share, for the three and nine months ended December 31, 2012, respectively. The decreases in the non-GAAP net loss were driven primarily by lower net losses as a result of cost reductions undertaken in fiscal 2012 and 2013 partially offset by a decrease in adverse purchase commitment recovery from the prior year and lower gains resulting from the change in fair value of derivatives and warrants.

[0001564590-14-000165:mdna:69]
[same as prior period, unchanged from 0001564590-13-001183:mdna:94]

[0001564590-14-000165:mdna:70]
[same as prior period, unchanged from 0001564590-13-001183:mdna:69]

[0001564590-14-000165:mdna:71]
At December 31, 2013, we had cash, cash equivalents, and restricted cash of $41.7 million, compared to $50.2 million at March 31, 2013, a decrease of $8.5 million. Our cash and cash equivalents, and restricted cash are summarized as follows (in thousands):

[0001564590-14-000165:mdna:72]
|  | December 31, |  |  | March 31, |  |
|  | 2013 |  |  | 2013 |  |
| Cash and cash equivalents | $ | 35,394 |  |  | $ | 39,243 |  |
| Restricted cash |  | 6,306 |  |  |  | 10,956 |  |
| Total cash, cash equivalents, marketable securities and restricted cash | $ | 41,700 |  |  | $ | 50,199 |  |

[0001564590-14-000165:mdna:73]
With respect to the unaudited condensed consolidated statement of cash flows, for the nine months ended December 31, 2013, net cash used in operating activities was $18.4 million compared to $40.7 million for the nine months ended December 31, 2012. The decrease in net cash used in operations is due primarily to a lower net loss, net of non-cash adjustments, as well as less cash used for changes in operating asset and liability accounts.

[0001564590-14-000165:mdna:74]
For the nine months ended December 31, 2013, net cash provided by investing activities was $4.4 million, compared to $4.7 million for the nine months ended December 31, 2012. The decrease in net cash provided by investing activities for the nine months ended December 31, 2013 was driven primarily by proceeds from maturity of marketable securities during the nine months ended December 31, 2012, partially offset by the net reduction in restricted cash during the nine months ended December 31, 2013.

[0001564590-14-000165:mdna:75]
For the nine months ended December 31, 2013, net cash provided by financing activities was $9.8 million compared to $32.3 million cash provided by financing activities in the nine months ended December 31, 2012. The decrease in net cash provided by financing activities is primarily due lower proceeds from the issuance of debt during the nine months ended December 31, 2013.

[0001564590-14-000165:mdna:76]
At December 31, 2013, we had $1.4 million of restricted cash included in current assets, and $4.9 million of restricted cash included in long-term assets. These amounts included in restricted cash primarily represent deposits to secure letters of credit for various supply contracts. These deposits are held in interest bearing accounts.

[0001564590-14-000165:mdna:77]
We have experienced recurring operating losses and as of December 31, 2013, had an accumulated deficit of $833.7 million. In addition, we have experienced recurring negative operating cash flows, which have resulted in a decrease in our cash balance. These factors raise substantial doubt regarding our ability to continue as a going concern. Our financial statements do not include any adjustments that might result from this outcome of this uncertainty. At December 31, 2013 we had cash and cash equivalents of $35.4 million. Cash used in operations for the nine months ended December 31, 2013, was $18.4 million.

[0001564590-14-000165:mdna:78]
[same as prior period, unchanged from 0001564590-13-001183:mdna:78]

[0001564590-14-000165:mdna:79]
40

[0001564590-14-000165:mdna:80]
[same as prior period, unchanged from 0001564590-13-001183:mdna:79]

[0001564590-14-000165:mdna:81]
| · | Allowed us to convert, subject to the satisfaction of certain conditions set forth in the Exchanged Note, (a) at least $2.5 million of the approximately $5.3 million installment amount payable with respect to the January 2013 installment date (including approximately $4.2 million of deferred installment amounts from the period September 4, 2012 to December 3, 2012) into shares of our common stock (on December 21, 2012 we converted $3.8 million in deferred installment amount principal and interest and issued 1,715,443 shares of common stock), and (b) the balance of the January 2013 installment amount in equal amounts on each of the February and March 2013 installment dates; |

[0001564590-14-000165:mdna:82]
| · | Reduced the price failure equity condition with respect to a particular date of determination from $2.50 to $1.00; |

[0001564590-14-000165:mdna:83]
| · | Reduced the aggregate daily dollar trading volume equity condition required for at least 25 of the 30 consecutive trading days immediately preceding a date of determination from $1,500,000 to $850,000 per trading day. In addition, if the aggregate daily dollar trading volume is between $50,000 and $850,000, we may still convert into common stock a portion of an installment amount payable with respect to an installment date equal to the quotient of (x) the aggregate daily dollar trading volume, divided by (y) $850,000; |

[0001564590-14-000165:mdna:84]
| · | Increased CVI’s beneficial ownership limitation under the Exchanged Note from 4.99% to 9.99%; and |

[0001564590-14-000165:mdna:85]
| · | Reduced the conversion price, from $4.85 per share of our common stock to $3.19 per share of our common stock, subject to certain price-based and other anti-dilution adjustments. |

[0001564590-14-000165:mdna:86]
On October 9, 2013, we entered into a Second Amendment and Warrant Exchange Agreement (the “Second Amendment”) with CVI. The Second Amendment further amended the Securities Purchase Agreement, as amended by the First Amendment and Exchange Agreement dated December 20, 2012 (collectively, the “Amended Purchase Agreement”), that we previously entered into with CVI.

[0001564590-14-000165:mdna:87]
Pursuant to the Second Amendment, we and/or CVI (i) waived certain provisions of the Amended Purchase Agreement, and (ii) amended certain provisions of the Exchanged Note, specifically,

[0001564590-14-000165:mdna:88]
| — | CVI waived its rights under the Amended Purchase Agreement to participate in (i) specific types of offerings that may be conducted by the Company with respect to our currently effective Registration Statement on Form S-3 (Registration No. 333-191153), and (ii) the issuance of shares of common stock in connection with any settlement of currently outstanding litigation involving us; |

[0001564590-14-000165:mdna:89]
| — | we and CVI amended the Exchanged Note: |

[0001564590-14-000165:mdna:90]
| — | to increase the period during which CVI is allowed to accelerate payment in shares of common stock at the then current installment date conversion price from such installment date until the trading day before the next installment notice due date to the entire period from such installment date until the trading day before the next installment date; |

[0001564590-14-000165:mdna:91]
| — | to increase the aggregate outstanding principal amount under the definition of “permitted senior indebtedness” from $10 million to $15 million; and |

[0001564590-14-000165:mdna:92]
| — | we and CVI exchanged the Original Warrant for a new Warrant with a reduced exercise price of $2.61 per share of common stock. |

[0001564590-14-000165:mdna:93]
On June 5, 2012, we entered into the Term Loan with Hercules, under which we borrowed $10.0 million. After the closing fees and expenses, the net proceeds were $9.7 million. The Term Loan bears an interest rate equal to 11% plus the percentage, if any, in which the prime rate as reported by The Wall Street Journal exceeds 3.75%. We made interest only payments from July 1, 2012 through October 31, 2012, after which we began paying the Term Loan in equal monthly installments ending on December 1, 2014.

[0001564590-14-000165:mdna:94]
[same as prior period, unchanged from 0001564590-13-001183:mdna:109]

[0001564590-14-000165:mdna:95]
On November 15, 2013, we amended the Term Loan with Hercules and entered into the New Term Loan (collectively with the Term Loan, the “Term Loans”), borrowing an additional $10.0 million. After closing fees and expenses, we received net proceeds of $9.8 million.  The New Term Loan also bears the same interest rate as the Term Loan.  We are making interest-only payments from December 1, 2013 to May 31, 2014.  If we achieve certain revenue targets for the six-month period ending March 31, 2014, interest only payments will continue through August 31, 2014.  Once the interest-only period ends, we will repay the New Term Loan in equal monthly installments ending on November 1, 2016.

[0001564590-14-000165:mdna:96]
The Term Loans are secured by substantially all of our existing and future assets, including a mortgage on real property owned by our wholly owned subsidiary, ASC Devens LLC, and located at 64 Jackson Road, Devens, Massachusetts. The Term Loans contain certain covenants that restrict our ability to, among other things, incur or assume certain debt, merge or consolidate, materially change the nature of our business, make certain investments, acquire or dispose of certain assets, make guaranties or grant liens on its assets, make certain loans, advances or investments, declare dividends or make distributions or enter into transactions with affiliates. In addition, the Term Loans contain a covenant which requires us to maintain a minimum unrestricted cash balance in the United States of at least $15.0 million at the inception of the New Term Loan.  This amount will be reduced by $2.5 million for every $5.0 million of net proceeds from the sale of our common stock after November 15, 2013, including those under the ATM, to an amount not lower than $7.5 million or the outstanding combined principal balances of the Term Loans, whichever is lower.  The events of default under the Term Loans include, but are not limited to, failure to pay amounts due, breaches of covenants, bankruptcy events, cross defaults under other material indebtedness and the occurrence of a material adverse effect and/or change in control. In the case of a continuing event of default, the lender may, among other remedies, declare due all unpaid principal amounts outstanding and any accrued but unpaid interest and foreclose on all collateral granted to the lender as security under the Term Loans.

[0001564590-14-000165:mdna:97]
We believe we are in and expect to remain in compliance with the covenants and restrictions under the Exchanged Note and the Term Loans as of the date of this Quarterly Report on Form 10-Q. If we fail to stay in compliance with our covenants or experience some other event of default, we may be forced to repay the outstanding principal of one or both of our debt obligations. In the case of the Exchanged Note, such an event of default would also include the requirement to pay a penalty as defined in the agreement. Should this occur, our liquidity would be adversely affected.

[0001564590-14-000165:mdna:98]
On November 15, 2013, we entered into an ATM arrangement, pursuant to which, we may, at our discretion, sell up to $30.0 million our common stock through our sales agent, MLV.   Sales of common stock made under the ATM are made on the NASDAQ Global Market under our previously filed and currently effective Registration Statement on Form S-3 (File No. 333-191153) by means of ordinary brokers’ transactions at market prices. Additionally, under the terms of the ATM, we may also sell shares of our common stock through MLV, on the NASDAQ Global Market or otherwise, at negotiated prices or at prices related to the prevailing market price. Under the terms of the ATM, MLV may not engage in any proprietary trading or trading as principal for MLV’s own account. MLV uses its commercially reasonable efforts to sell our common stock from time to time, based upon the our instructions (including any price, time or size limits or other customary parameters or conditions we may impose). We pay MLV a commission of up to 3% of the gross proceeds from the sale of shares of our common stock under the ATM. We have also agreed to provide MLV with customary indemnification rights. The offering of common stock pursuant to the ATM will terminate upon the earlier of the sale of all of the common stock subject to the ATM and the termination of the ATM by us or MLV. Either party may terminate the ATM its sole discretion at any time upon written notice to the other party.  During the three months ended December 31, 2013, we received net proceeds of $3.3 million, including sales commissions and offering expenses, from sales of approximately 2.4 million shares of our common stock at an average sales price of approximately $1.51 per share under the ATM.

[0001564590-14-000165:mdna:99]
In order for us to continue operations beyond the next twelve months and be able to discharge our liabilities and commitments in the normal course of business, we need to increase sales through executing our strategy to broaden our customer base, enter new markets, and commercialize our superconductor product line. Otherwise, we may need to further reduce operating expenses in line with business conditions in order to decrease the amount of cash used in operations. We intend to continue to work with the holder of our convertible note in order to maintain the ability to make monthly amortization payments on the convertible note in shares of common stock. In addition, we are actively seeking to sell our minority investments in Tres Amigas and Blade Dynamics and have recently engaged a financial advisor to assist with that effort.  In addition, we maintain the ability to sell shares of our common stock under the ATM at our discretion to enhance liquidity.

[0001564590-14-000165:mdna:100]
We must successfully execute on our plans to improve operating performance discussed above, raise additional capital either through the sale of one or both of its minority investments, or through the sale of shares of our common stock at our discretion under the ATM, and maintain the ability to pay monthly installment payments under the Exchanged Note in shares of common stock to ensure that we have sufficient cash to fund our operations, capital expenditures and scheduled cash payments under our debt obligations through December 31, 2014. Our ability to pay required monthly installment payments under the Exchanged Note in equity instead of cash is based on certain stock price and trading volume conditions that are outside of our control. If one or both of these equity conditions are not met (absent a waiver from the lender), we may be required to make required monthly installment payments in cash. As of the date of this Quarterly Report on Form 10-Q, we have only made payments to the lender in shares of common stock and as a result the principal balance has been reduced by $14.6 million to $10.4 million through December 31, 2013. If we fail one or both of the equity conditions, we can still make required payments in stock if the lender agrees to waive our compliance with the relevant equity conditions, which it has done in the past. There is no assurance that the lender will provide any waivers in the future.  Our liquidity is highly dependent on the factors discussed above and our ability to maintain compliance with the covenants and restrictions on our debt obligations (or obtain waivers from our lenders in the event of non-compliance).  There can be no assurance that we will be able to raise additional capital or sell one or both of these investments on commercially reasonable terms or at all.

[0001564590-14-000165:mdna:101]
Legal Proceedings

[0001564590-14-000165:mdna:102]
We are involved in legal and administrative proceedings and claims of various types. See Part II, Item 1, “Legal Proceedings,” for additional information. We record a liability in our consolidated financial statements for these matters when a loss is known or considered probable and the amount can be reasonably estimated. We review these estimates each accounting period as additional information is known and adjust the loss provision when appropriate. If a matter is both probable to result in liability and the amounts of loss can be reasonably estimated, we estimate and disclose the possible loss or range of loss. If the loss is not probable or cannot be reasonably estimated, a liability is not recorded in its consolidated financial statements.

[0001564590-14-000165:mdna:103]
[same as prior period, unchanged from 0001564590-13-001183:mdna:98]

[0001564590-14-000165:mdna:104]
[same as prior period, unchanged from 0001564590-13-001183:mdna:99]

[0001564590-14-000165:mdna:105]
[same as prior period, unchanged from 0001564590-13-001183:mdna:100]

[0001564590-14-000165:mdna:106]
[same as prior period, unchanged from 0001564590-13-001183:mdna:101]

[0001564590-14-000165:mdna:107]
[same as prior period, unchanged from 0001564590-13-001183:mdna:102]

[0001564590-14-000165:mdna:108]
In January 2013, the FASB issued Accounting Standards Update No. 2013-01, Balance Sheet (Topic 210): Clarifying the Scope of Disclosures about Offsetting Assets and Liabilities (ASU 2013-01). The main objective in developing this update is to address implementation issues about the scope of Accounting Standards Update No. 2011-11, Balance Sheet (Topic 210): Disclosures about Offsetting Assets and Liabilities. The update requires entities to disclose information about offsetting and related arrangements of financial instruments and derivative instruments. ASU 2013-01 is effective for our first quarter of fiscal 2013.  We adopted ASU 2013-01 and it did not have a material impact on our consolidated results of operations, financial condition, or cash flow.

[0001564590-14-000165:mdna:109]
In February 2013, the FASB issued Accounting Standards Update No. 2013-02, Comprehensive Income (Topic 220): Reporting of Amounts Reclassified Out of Accumulated Other Comprehensive Income (ASU 2013-02). The amendments of this ASU require an entity to provide information about the amounts reclassified out of accumulated other comprehensive income (“AOCI”) by component. In addition, an entity is required to present, either on the face of the statement where net income (loss) is presented or in the notes, significant amounts reclassified out of AOCI by the respective line items of net income but only if the amount reclassified is required under U.S. GAAP to be reclassified to net income in its entirety in the same reporting period. For other amounts that are not required under U.S. GAAP to be reclassified in their entirety to net income, an entity is required to cross-reference to other disclosures required under U.S. GAAP that provide additional detail about those amounts. ASU 2013-02 is effective for fiscal years and interim periods beginning after December 15, 2012. We adopted ASU 2013-02 and it did not have a material impact on our consolidated results of operations, financial condition, or cash flows.

[0001564590-14-000165:mdna:110]
In March 2013, the FASB issued Accounting Standards Update No. 2013-05, Foreign Currency Matters (Topic 830): Parent’s Accounting for the Cumulative Translation Adjustment upon Derecognition of Certain Subsidiaries or Groups of Assets within a Foreign Entity or of an Investment in a Foreign Entity (ASU 2013-05). The objective of the amendments in this update is to resolve the diversity in practice about whether Subtopic 810-10, Consolidation—Overall, or Subtopic 830-30, Foreign Currency Matters—Translation of Financial Statements, applies to the release of the cumulative translation adjustment into net income when a parent either sells a part or all of its investment in a foreign entity or no longer holds a controlling financial interest in a subsidiary or group of assets that is a nonprofit activity or a business (other than a sale of in substance real estate or conveyance of oil and gas mineral rights) within a foreign entity. In addition, the amendments in this update resolve the diversity in practice for the treatment of business combinations achieved in involving a foreign entity. ASU 2013-05 is effective for fiscal years and interim periods beginning after December 15, 2013. We are currently evaluating the impact of ASU 2013-05, but currently do not believe there will be a significant impact on our consolidated results of operations, financial condition, or cash flows.

[0001564590-14-000165:mdna:111]
In June 2013, the FASB issued ASU 2013-07, Liquidation Basis of Accounting, to require entities to begin preparing financial statements on a liquidation basis when liquidation is imminent. The guidance requires liquidation accounting when liquidation is imminent, unless an entity is outside the scope of the guidance or it is following a liquidation plan established at its inception. The guidance says liquidation is imminent when either, the party or parties with the authority to approve a liquidation plan do so or other forces (e.g., involuntary bankruptcy) impose a plan for liquidation, and the likelihood that the entity will return from liquidation is remote. The guidance also requires entities using the liquidation basis of accounting to measure their assets at the amount they expect to collect upon sale and liabilities are not remeasured to reflect any anticipation that the entity will be legally released from the obligation. ASU 2013-07 is effective for annual periods beginning after December 15, 2013. We are currently evaluating the impact of adopting ASU 2013-07, but currently do not believe there will be an impact on our consolidated results of operations, financial condition, or cash flows.

[0001564590-14-000165:mdna:112]
In September 2013, the FASB issued ASU 2013-11, Income Taxes (Topic 740): Presentation of an Unrecognized Tax Benefit When a Net Operating Loss Carryforward, a Similar Tax Loss, or a Tax Credit Carryforward Exists. The guidance states that an unrecognized tax benefit, or a portion of an unrecognized tax benefit, should be presented in the financial statements as a reduction to a deferred tax asset for a net operating loss carryforward, a similar tax loss, or a tax credit carryforward, except as follows. To the extent a net operating loss carryforward, a similar tax loss, or a tax credit carryforward is not available at the reporting date under the tax law of the applicable jurisdiction to settle any additional income taxes that would result from the disallowance of a tax position or the tax law of the applicable jurisdiction does not require the entity to use, and the entity does not intend to use, the deferred tax asset for such purpose, the unrecognized tax benefit should be presented in the financial statements as a liability and should not be combined with deferred tax assets. This ASU applies to all entities that have unrecognized tax benefits when a net operating loss carryforward, a similar tax loss, or a tax credit carryforward exists at the reporting date. The amendments in this ASU are effective for fiscal years, and interim periods within those years, beginning after December 15, 2013. We are currently evaluating the impact of adopting ASU 2013-11, but currently do not believe there will be an impact on our consolidated results of operations, financial condition, or cash flow

[0001564590-14-000165:mdna:113]
We do not believe that other recently issued accounting pronouncements will have a material impact on our financial statements.

[0001564590-14-000165:mdna:114]
44
