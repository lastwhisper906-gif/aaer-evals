# AMSC notes — 0001564590-14-000165


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001564590-14-000165:notes:1]
[same as prior period, unchanged from 0001564590-13-001183:notes:1]

[0001564590-14-000165:notes:2]
The Company accounts for its stock-based compensation at fair value. The following table summarizes stock-based compensation expense by financial statement line item for the three and nine months ended December 31, 2013 and 2012 (in thousands):

[0001564590-14-000165:notes:3]
|  | Three months ended |  |  | Nine months ended |  |
|  | December 31, |  |  | December 31, |  |
|  | 2013 |  |  | 2012 |  |  | 2013 |  |  | 2012 |  |
| Cost of revenues | $ | 330 |  |  | $ | 135 |  |  | $ | 758 |  |  | $ | 518 |  |
| Research and development |  | 913 |  |  |  | 627 |  |  |  | 2,073 |  |  |  | 1,781 |  |
| Selling, general and administrative |  | 1,797 |  |  |  | 1,167 |  |  |  | 4,497 |  |  |  | 3,669 |  |
| Total | $ | 3,040 |  |  | $ | 1,929 |  |  | $ | 7,328 |  |  | $ | 5,968 |  |

[0001564590-14-000165:notes:4]
During the nine months ended December 31, 2013, the Company granted approximately 831,000 stock options, 1,307,000 restricted stock awards, 362,000 shares of performance-based restricted stock awards and issued 212,000 shares of common stock in-lieu of cash bonuses and severance payments to employees under the 2007 Stock Incentive Plan. The shares issued in-lieu of cash bonuses vested immediately.  The shares issued in lieu of severance vested on the eighth day after receipt of an irrevocable release.  The options and restricted stock awards granted vest upon the passage of time, generally 3 years. For options and awards that vest upon the passage of time, expense is being recorded over the vesting period.  Performance-based restricted stock awards are expensed over the requisite service period.

[0001564590-14-000165:notes:5]
The estimated fair value of the Company’s stock-based awards, less expected annual forfeitures, is amortized over the awards’ service period. The total unrecognized compensation cost for unvested outstanding stock options was $2.6 million at December 31, 2013. This expense will be recognized over a weighted average expense period of approximately 1.8 years. The total unrecognized compensation cost for unvested outstanding restricted stock was $4.5 million at December 31, 2013. This expense will be recognized over a weighted-average expense period of approximately 0.7 years.

[0001564590-14-000165:notes:6]
The weighted-average assumptions used in the Black-Scholes valuation model for stock options granted during the three and nine months ended December 31, 2013 and 2012 are as follows:

[0001564590-14-000165:notes:7]
|  | Three months ended |  |  | Nine months ended |  |
|  | December 31, |  |  | December 31, |  |
|  | 2013 |  |  | 2012 |  |  | 2013 |  |  | 2012 |  |
| Expected volatility |  | N/A |  |  |  | 72.4 | % |  |  | 75.1 | % |  |  | 72.0 | % |
| Risk-free interest rate |  | N/A |  |  |  | 1.0 | % |  |  | 1.7 | % |  |  | 0.9 | % |
| Expected life (years) |  | N/A |  |  |  | 5.9 |  |  |  | 5.9 |  |  | 5.9 |  |
| Dividend yield |  | N/A |  |  | None |  |  | None |  |  | None |  |

[0001564590-14-000165:notes:8]
The expected volatility rate was estimated based on an equal weighting of the historical volatility of the Company’s common stock and the implied volatility of the Company’s traded options. The expected term was estimated based on an analysis of the Company’s historical experience of exercise, cancellation, and expiration patterns. The risk-free interest rate is based on the average of the five and seven year United States Treasury rates.  There were no stock options granted during the three months ended December 31, 2013.


## us-gaap:EarningsPerShareTextBlock

[0001564590-14-000165:notes:9]
[same as prior period, unchanged from 0001564590-13-001183:notes:9]

[0001564590-14-000165:notes:10]
Basic net loss per share (“EPS”) is computed by dividing net loss by the weighted-average number of common shares outstanding for the period. Where applicable, diluted EPS is computed by dividing the net loss by the weighted-average number of common shares and dilutive common equivalent shares outstanding during the period, calculated using the treasury stock method. Common equivalent shares include the effect of restricted stock, exercise of stock options and warrants and contingently issuable shares. For each of the three and nine months ended December 31, 2013, 10.1 million shares were not included in the calculation of diluted EPS as they were considered anti-dilutive, of which 3.2 million relate to unvested stock options, 3.5 million relate to the issuance of warrants, and 3.4 million shares relate to the convertible feature of the Company’s Exchanged Note. For the three and nine months ended December 31, 2012, 11.8 million shares were not included in the calculation of diluted EPS as they were considered anti-dilutive, of which 2.9 million relate to unvested stock options, 3.2 million relate to the issue of warrants and 5.7 million shares related to the convertible feature of the Company’s Exchanged Note.

[0001564590-14-000165:notes:11]
The following table reconciles the numerators and denominators of the earnings per share calculation for the three and nine months ended December 31, 2013 and 2012 (in thousands, except per share data):

[0001564590-14-000165:notes:12]
|  | Three months ended December 31, |  | Nine months ended December 31, |  |
|  | 2013 |  |  | 2012 |  |  |  | 2013 |  |  | 2012 |  |
| Numerator: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net loss | $ | (8,417 | ) |  | $ | (20,135 | ) |  |  | $ | (33,553 | ) |  | $ | (46,360 | ) |
| Denominator: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Weighted-average shares of common stock outstanding |  | 64,442 |  |  |  | 53,745 |  |  |  |  | 62,256 |  |  |  | 52,558 |  |
| Weighted-average shares subject to repurchase |  | (2,133 | ) |  |  | (953 | ) |  |  |  | (1,678 | ) |  |  | (592 | ) |
| Shares used in per-share calculation ― basic |  | 62,309 |  |  |  | 52,792 |  |  |  |  | 60,578 |  |  |  | 51,966 |  |
| Shares used in per-share calculation ― diluted |  | 62,309 |  |  |  | 52,792 |  |  |  |  | 60,578 |  |  |  | 51,966 |  |
| Net loss per share ― basic | $ | (0.14 | ) |  | $ | (0.38 | ) |  |  | $ | (0.55 | ) |  | $ | (0.89 | ) |
| Net loss per share ― diluted | $ | (0.14 | ) |  | $ | (0.38 | ) |  |  | $ | (0.55 | ) |  | $ | (0.89 | ) |


## us-gaap:FairValueDisclosuresTextBlock

[0001564590-14-000165:notes:13]
[same as prior period, unchanged from 0001564590-13-001183:notes:13]

[0001564590-14-000165:notes:14]
In January 2010, the Financial Accounting Standards Board (“FASB”) issued guidance related to disclosures of fair value measurements. The guidance requires gross presentation of activity within the Level 3 measurement roll-forward and details of transfers in and out of Level 1 and 2 measurements. It also clarifies two existing disclosure requirements on the level of disaggregation of fair value measurements and disclosures on inputs and valuation techniques. A change in the hierarchy of an investment from its current level will be reflected in the period during which the pricing methodology of such investment changes. Disclosure of the transfer of securities from Level 1 to Level 2 or Level 3 will be made in the event that the related security is significant to total cash and investments. The Company did not have any transfers of assets and liabilities between Level 1, Level 2 and Level 3 of the fair value measurement hierarchy during the three months ended December 31, 2013.

[0001564590-14-000165:notes:15]
[same as prior period, unchanged from 0001564590-13-001183:notes:15]

[0001564590-14-000165:notes:16]
[same as prior period, unchanged from 0001564590-13-001183:notes:16]

[0001564590-14-000165:notes:17]
[same as prior period, unchanged from 0001564590-13-001183:notes:17]

[0001564590-14-000165:notes:18]
The following table provides the assets carried at fair value, measured as of December 31, 2013 and March 31, 2013 (in thousands):

[0001564590-14-000165:notes:19]
|  | Total |  |  | Quoted Prices in |  |  | Significant Other |  |  | Significant |  |
|  | Carrying |  |  | Active Markets |  |  | Observable Inputs |  |  | Unobservable Inputs |  |
|  | Value |  |  | (Level 1) |  |  | (Level 2) |  |  | (Level 3) |  |
| December 31, 2013: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash equivalents | $ | 12,671 |  |  | $ | 12,671 |  |  | $ | - |  |  | $ | - |  |
| Liabilities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Derivative liability | $ | - |  |  | $ | - |  |  | $ | - |  |  | $ | - |  |
| Warrants |  | 2,587 |  |  |  | - |  |  |  | - |  |  |  | 2,587 |  |

[0001564590-14-000165:notes:20]
|  | Total |  |  | Quoted Prices in |  |  | Significant Other |  |  | Significant |  |
|  | Carrying |  |  | Active Markets |  |  | Observable Inputs |  |  | Unobservable Inputs |  |
|  | Value |  |  | (Level 1) |  |  | (Level 2) |  |  | (Level 3) |  |
| March 31, 2013: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash equivalents | $ | 18,649 |  |  | $ | 18,649 |  |  | $ | - |  |  | $ | - |  |
| Liabilities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Derivative liability | $ | 529 |  |  | $ | - |  |  | $ | - |  |  | $ | 529 |  |
| Warrants |  | 3,633 |  |  |  | - |  |  |  | - |  |  |  | 3,633 |  |

[0001564590-14-000165:notes:21]
The table below reflects the activity for the Company’s major classes of liabilities measured at fair value (in thousands):

[0001564590-14-000165:notes:22]
|  | Derivative |  |  |  |  |  |
|  | Liability |  |  | Warrants |  |
| April 1, 2012 |  |  |  |  |  |  |  |
| Valuation of original derivative liability | $ | 3,779 |  |  | $ | - |  |
| Warrant issuance with Senior Convertible Note |  | - |  |  |  | 7,018 |  |
| Warrant issuance with Senior Secured Term Loan |  | - |  |  |  | 380 |  |
| Valuation of derivative liability attributable to modification |  | 542 |  |  |  | - |  |
| Mark to market adjustment |  | (3,297 | ) |  |  | (2,817 | ) |
| Balance at December 31, 2012 | $ | 1,024 |  |  | $ | 4,581 |  |
| Mark to market adjustment |  | (495 | ) |  |  | (948 | ) |
| Balance at March 31, 2013 | $ | 529 |  |  | $ | 3,633 |  |

[0001564590-14-000165:notes:23]
|  | Derivative |  |  |  |  |  |
|  | Liability |  |  | Warrants |  |
| April 1, 2013 | $ | 529 |  |  | $ | 3,633 |  |
| Warrant issuance with Senior Secured Term Loan |  | - |  |  |  | 315 |  |
| Mark to market adjustment |  | (529 | ) |  |  | (1,361 | ) |
| Balance at December 31, 2013 | $ | - |  |  | $ | 2,587 |  |

[0001564590-14-000165:notes:24]
[same as prior period, unchanged from 0001564590-13-001183:notes:24]

[0001564590-14-000165:notes:25]
[same as prior period, unchanged from 0001564590-13-001183:notes:25]

[0001564590-14-000165:notes:26]
[same as prior period, unchanged from 0001564590-13-001183:notes:26]

[0001564590-14-000165:notes:27]
[same as prior period, unchanged from 0001564590-13-001183:notes:27]

[0001564590-14-000165:notes:28]
The Company has identified all of the derivatives (“Derivative Liability”) associated with the Exchanged Note which include put rights to require the investor to acquire an additional $15.0 million convertible note and additional warrants, holder change of control redemption rights, issuer optional redemption rights, sale redemption rights and a right to make payment in the form of stock rather than cash if certain equity conditions are met. The Derivative Liability is subject to revaluation at each balance sheet date, and any change in fair value will be recorded as a change in fair value of derivatives and warrants until the earlier of its exercise or expiration. The Company relies on assumptions in a lattice model to determine the fair value of the Derivative Liability. The Company has appropriately valued the Derivative Liability within Level 3 of the valuation hierarchy. (See Note 10, “Debt”, for discussion on the Exchanged Note, Derivative Liability and valuation assumptions used.)

[0001564590-14-000165:notes:29]
[same as prior period, unchanged from 0001564590-13-001183:notes:29]

[0001564590-14-000165:notes:30]
Warrants were issued in conjunction with the Initial Note and the Term Loans. (See Note 10, “Debt”, for additional information on warrants.) These warrants are subject to revaluation at each balance sheet date, and any change in fair value will be recorded as a change in fair value of derivatives and warrants until the earlier of their exercise or expiration.

[0001564590-14-000165:notes:31]
[same as prior period, unchanged from 0001564590-13-001183:notes:31]


## us-gaap:LoansNotesTradeAndOtherReceivablesDisclosureTextBlock

[0001564590-14-000165:notes:32]
[same as prior period, unchanged from 0001564590-13-001183:notes:32]

[0001564590-14-000165:notes:33]
Accounts receivable at December 31, 2013 and March 31, 2013 consisted of the following (in thousands):

[0001564590-14-000165:notes:34]
|  |  | December 31, |  |  | March 31, |  |
|  |  | 2013 |  |  | 2013 |  |
| Accounts receivable (billed) |  | $ | 7,551 |  |  | $ | 17,222 |  |
| Accounts receivable (unbilled) |  |  | 990 |  |  |  | 1,642 |  |
| Less: Allowance for doubtful accounts |  |  | (16 | ) |  |  | - |  |
| Accounts receivable, net |  | $ | 8,525 |  |  | $ | 18,864 |  |


## us-gaap:InventoryDisclosureTextBlock

[0001564590-14-000165:notes:35]
[same as prior period, unchanged from 0001564590-13-001183:notes:35]

[0001564590-14-000165:notes:36]
The components of inventory at December 31, 2013 and March 31, 2013 are as follows (in thousands):

[0001564590-14-000165:notes:37]
|  | December 31, |  |  | March 31, |  |
|  | 2013 |  |  | 2013 |  |
| Raw materials | $ | 6,532 |  |  | $ | 5,966 |  |
| Work-in-process |  | 2,706 |  |  |  | 3,427 |  |
| Finished goods |  | 12,888 |  |  |  | 21,655 |  |
| Deferred program costs |  | 3,041 |  |  |  | 2,425 |  |
| Net inventory | $ | 25,167 |  |  | $ | 33,473 |  |

[0001564590-14-000165:notes:38]
The Company recorded inventory write-downs of $0.1 million and $0.5 million for the three months ended December 31, 2013 and 2012, respectively. The Company recorded inventory write-downs of $0.3 million and $1.0 million for the nine months ended December 31, 2013 and 2012, respectively. These write downs were based on evaluating its ending inventory on hand for excess quantities and obsolescence.

[0001564590-14-000165:notes:39]
Deferred program costs as of December 31, 2013 and March 31, 2013 primarily represent costs incurred on programs accounted for under contract accounting where the Company needs to complete development programs before revenue and costs will be recognized, respectively.


## us-gaap:AccountsPayableAndAccruedLiabilitiesDisclosureTextBlock

[0001564590-14-000165:notes:40]
[same as prior period, unchanged from 0001564590-13-001183:notes:40]

[0001564590-14-000165:notes:41]
[same as prior period, unchanged from 0001564590-13-001183:notes:41]

[0001564590-14-000165:notes:42]
|  | December 31, |  |  | March 31, |  |
|  | 2013 |  |  | 2013 |  |
| Accounts payable | $ | 5,178 |  |  | $ | 7,146 |  |
| Accrued miscellaneous expenses |  | 6,024 |  |  |  | 9,142 |  |
| Accrued outside services |  | 4,167 |  |  |  | 2,251 |  |
| Accrued subcontractor program costs |  | 290 |  |  |  | 2,442 |  |
| Accrued compensation |  | 4,369 |  |  |  | 6,315 |  |
| Income taxes payable |  | 148 |  |  |  | 133 |  |
| Accrued warranty |  | 3,327 |  |  |  | 2,709 |  |
| Total | $ | 23,503 |  |  | $ | 30,138 |  |

[0001564590-14-000165:notes:43]
[same as prior period, unchanged from 0001564590-13-001183:notes:43]

[0001564590-14-000165:notes:44]
[same as prior period, unchanged from 0001564590-13-001183:notes:44]

[0001564590-14-000165:notes:45]
|  | Three months ended |  |  | Nine months ended |  |
|  | December 31, |  |  | December 31, |  |
|  | 2013 |  |  | 2012 |  |  | 2013 |  |  | 2012 |  |
| Balance at beginning of period | $ | 3,069 |  |  | $ | 4,792 |  |  | $ | 2,709 |  |  | $ | 5,896 |  |
| Change in accruals for warranties during the period |  | 273 |  |  |  | (627 | ) |  |  | 767 |  |  |  | (1,178 | ) |
| Settlements during the period |  | (15 | ) |  |  | (147 | ) |  |  | (149 | ) |  |  | (700 | ) |
| Balance at end of period | $ | 3,327 |  |  | $ | 4,018 |  |  | $ | 3,327 |  |  | $ | 4,018 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0001564590-14-000165:notes:46]
[same as prior period, unchanged from 0001564590-13-001183:notes:46]

[0001564590-14-000165:notes:47]
For the three and nine months ended December 31, 2013, the Company recorded income tax expense of $0.3 million and $0.7 million, respectively. For the three and nine months ended December 31, 2012, the Company recorded income tax expense of $0.1 million and an income tax benefit of $0.7 million, respectively. For the three months ended December 31, 2013 and 2012, respectively, income tax expense was primarily due to income taxes in the Company’s foreign jurisdictions.  In addition, income tax expense for the nine months ended December 31, 2013 included withholding taxes for repatriation of funds from certain foreign jurisdictions.  The income tax benefit for the nine months ended December 31, 2012, was primarily due to a refund of Chinese income taxes of $0.9 million.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001564590-14-000165:notes:48]
[same as prior period, unchanged from 0001564590-13-001183:notes:48]

[0001564590-14-000165:notes:49]
[same as prior period, unchanged from 0001564590-13-001183:notes:49]

[0001564590-14-000165:notes:50]
During the years ended March 31, 2013 and March 31, 2012, the Company undertook restructuring activities, approved by the Board of Directors, in order to reorganize its global operations, streamline various functions of the business, and reduce its global workforce to better reflect the demand for its products. The Company undertook an additional workforce reduction in July 2013, reducing its workforce by approximately 7%, impacting primarily selling, engineering and general and administrative functions. The Company recorded restructuring charges for severance and other costs of approximately $0.1 million and $0.9 million during the three and nine months ended December 31, 2013. From April 1, 2011 through December 31, 2013, these activities resulted in a substantial reduction of its global workforce. During the three and nine months ended December 31, 2012, the Company incurred restructuring costs of $6.7 million and $6.8 million, respectively. The costs related to the Company’s restructuring activities have been paid as of December 31, 2013.

[0001564590-14-000165:notes:51]
[same as prior period, unchanged from 0001564590-13-001183:notes:51]

[0001564590-14-000165:notes:52]
|  | Severance pay |  |  | Facility |  |  |  |  |  |
| Nine months ended December 31, 2013 | and benefits |  |  | exit costs |  |  | Total |  |
| Accrued restructuring balance at April 1, 2013 | $ | 145 |  |  | $ | 54 |  |  | $ | 199 |  |
| Charges to operations |  | 849 |  |  |  | 23 |  |  |  | 872 |  |
| Cash payments |  | (821 | ) |  |  | (37 | ) |  |  | (858 | ) |
| Other adjustments |  | (173 | ) |  |  | (40 | ) |  |  | (213 | ) |
| Accrued restructuring balance at December 31, 2013 | $ | - |  |  | $ | - |  |  | $ | - |  |
| Nine months ended December 31, 2012 |  |  |  |  |  |  |  |  |
| Accrued restructuring balance at April 1, 2012 | $ | 680 |  |  | $ | 294 |  |  | $ | 974 |  |
| Charges to operations |  | 2,377 |  |  |  | (39 | ) |  |  | 2,338 |  |
| Cash payments |  | (1,673 | ) |  |  | (255 | ) |  |  | (1,928 | ) |
| Accrued restructuring balance at December 31, 2012 | $ | 1,384 |  |  | $ | - |  |  | $ | 1,384 |  |

[0001564590-14-000165:notes:53]
[same as prior period, unchanged from 0001564590-13-001183:notes:53]


## us-gaap:DebtDisclosureTextBlock

[0001564590-14-000165:notes:54]
10. Debt

[0001564590-14-000165:notes:55]
Senior Convertible Note

[0001564590-14-000165:notes:56]
On April 4, 2012, the Company entered into a Securities Purchase Agreement with Capital Ventures International (“CVI”), an affiliate of Heights Capital Management (the “Purchase Agreement”) and completed a private placement of the Initial Note, a 7% unsecured senior convertible note. After fees and expenses, the net proceeds of the Initial Note were $23.2 million. The Initial Note had an initial conversion price of $4.85 per share, representing a premium of approximately 20% over AMSC’s closing price on April 3, 2012. The Initial Note was payable in monthly installments beginning four months from issuance and ending on October 4, 2014. Monthly payments were payable in cash or the Company’s common stock at the option of the Company, subject to certain trading volume, stock price and other conditions. CVI could have also elected to defer receipt of monthly installment payments at its option. Any deferred installment payments would have continued to accrue interest. The Company registered 10,262,311 shares of common stock which may be used as payment for principal and interest in lieu of cash for resale under the Securities Act as required under a Registration Rights Agreement with CVI.

[0001564590-14-000165:notes:57]
The Company accounted for the Initial Note as an instrument that has the characteristics of a debt host contract containing several embedded derivative features that would require bifurcation and separate accounting as a derivative instrument pursuant to the provisions of ASC 815. The Company elected not to use the fair value option for the aggregate amount of the Exchanged Note and recorded the liability at its stated value on the date of issuance with no changes in fair value reported in subsequent periods.

[0001564590-14-000165:notes:58]
The Company has identified the following derivatives associated with the Initial Note: holder change of control redemption rights; issuer optional redemption rights; sale redemption rights and a feature to convert the Initial Note into equity at the holder’s option. The Company valued these derivatives at $3.8 million upon issuance of the Initial Note. (See Note 11, “Warrants and Derivative Liabilities,” for additional information regarding derivative liabilities.)

[0001564590-14-000165:notes:59]
In conjunction with the Initial Note, CVI received a warrant to purchase approximately 3.1 million additional shares of common stock exercisable at a strike price of $5.45 per share, subject to adjustment, until October 4, 2017. Due to certain adjustment provisions within the warrant, it qualified for liability accounting and had a fair value of $7.0 million upon issuance. The Company recorded the value as a debt discount and a warrant liability. (See Note 11, “Warrants and Derivative Liabilities,” for additional information regarding the warrant.)

[0001564590-14-000165:notes:60]
The process of valuing financial and derivative instruments utilizes facts and circumstances as of the measurement date as well as certain inputs, assumptions, and judgments that may affect the estimated fair value of the instruments. Upon issuance of the Initial Note, the Company determined the initial carrying value of the Initial Note to be $25.0 million. In addition, the Company also incurred $1.8 million of legal and origination costs as of the year ended March 31, 2013, which have been recorded as a discount on the Initial Note.

[0001564590-14-000165:notes:61]
On December 20, 2012, the Company entered into an Amendment and Exchange Agreement, (the “First Amendment”) with CVI, which amended the Purchase Agreement. Pursuant to the First Amendment, the Company and CVI exchanged the Initial Note for the Exchanged Note. At the time of the exchange, the Exchanged Note had the same principal amount and accrued interest as the Initial Note. The Exchanged Note is convertible into the Company’s common stock and has the same scheduled monthly installment payments as the Initial Note. The Exchanged Note provides the Company with additional flexibility to make monthly installment payments in shares of the Company’s common stock. The Company retains the ability to repay the Exchanged Note in cash. Specifically, the amendments to the Exchanged Note:

[0001564590-14-000165:notes:62]
| — | Allowed the Company to convert, subject to the satisfaction of certain conditions set forth in the Exchanged Note, (a) at least $2.5 million of the approximately $5.3 million installment amount payable with respect to the January 2013 installment date (including approximately $4.2 million of deferred installment amounts from the period September 4, 2012 to December 3, 2012) into shares of the Company’s common stock (on December 21, 2012 the Company converted $3.8 million in deferred installment amount principal and interest and issued 1,715,443 shares of common stock), and (b) the balance of the January 2013 installment amount in equal amounts on each of the February and March 2013 installment dates; |

[0001564590-14-000165:notes:63]
| — | Reduced the price failure equity condition with respect to a particular date of determination from $2.50 to $1.00; |

[0001564590-14-000165:notes:64]
| — | Reduced the aggregate daily dollar trading volume equity condition required for at least 25 of the 30 consecutive trading days immediately preceding a date of determination from $1,500,000 to $850,000 per trading day. In addition, if the aggregate daily dollar trading volume is between $50,000 and $850,000, the Company may still convert into common stock a portion of an installment amount payable with respect to an installment date equal to the quotient of (x) the aggregate daily dollar trading volume, divided by (y) $850,000; |

[0001564590-14-000165:notes:65]
| — | Increased CVI’s beneficial ownership limitation under the Exchanged Note from 4.99% to 9.99%; and |

[0001564590-14-000165:notes:66]
| — | Reduced the conversion price, from $4.85 per share of the Company’s common stock to $3.19 per share of the Company’s common stock, subject to certain price-based and other anti-dilution adjustments. |

[0001564590-14-000165:notes:67]
The Company assessed the changes in the Exchanged Note and accounted for it as a modification of the Initial Note. Therefore, the Company determined the incremental value of the derivative instruments, as a result of the Exchanged Note having a reduced conversion price. As a result of the re-valuation, the Company recorded a $0.5 million increase in the value of the derivative liability and additional debt discount. At the modification date, the value of the derivative liability was $1.5 million. The total debt discount, including the embedded derivatives in the Initial Note, the incremental value of embedded derivatives in the Exchanged Note, warrant and legal and origination costs of $13.1 million is being amortized into interest expense over the term of the Exchanged Note using the effective interest method. Under this method, interest expense is recognized each period until the debt instruments reach maturity. If the maturity of the Exchanged Note is accelerated because of prepayment, then the amortization will be accelerated.

[0001564590-14-000165:notes:68]
On October 9, 2013, the Company entered into a Second Amendment and Warrant Exchange Agreement (the “Second Amendment”) with CVI. The Second Amendment further amended the Securities Purchase Agreement, as amended by the First Amendment (collectively, the “Amended Purchase Agreement”), that the Company previously entered into with CVI.

[0001564590-14-000165:notes:69]
Pursuant to the Second Amendment, the Company and/or CVI waived certain provisions of the Amended Purchase Agreement and amended certain provisions of the Exchanged Note, specifically:

[0001564590-14-000165:notes:70]
| — | CVI waived its rights under the Amended Purchase Agreement to participate in (i) specific types of offerings that may be conducted by the Company with respect to the Company’s currently effective Registration Statement on Form S-3 (Registration No. 333-191153), and (ii) the issuance of shares of common stock in connection with any settlement of currently outstanding litigation involving the Company; |

[0001564590-14-000165:notes:71]
| — | the Company and CVI amended the Exchanged Note: |

[0001564590-14-000165:notes:72]
| — | to increase the period during which CVI is allowed to accelerate payment in shares of common stock at the then current installment date conversion price from such installment date until the trading day before the next installment notice due date to the entire period from such installment date until the trading day before the next installment date; |

[0001564590-14-000165:notes:73]
| — | to increase the aggregate outstanding principal amount under the definition of “permitted senior indebtedness” from $10.0 million to $15.0 million; and |

[0001564590-14-000165:notes:74]
| — | the Company and CVI exchanged the warrant (the “Original Warrant”) for a new warrant (the “Exchanged Warrant”) with a reduced exercise price of $2.61 per share of common stock. |

[0001564590-14-000165:notes:75]
The Company assessed the changes to the Exchanged Note included in the Second Amendment and accounted for it as a modification of the Exchanged Note.  Therefore, the Company determined the incremental value of the derivative instruments, as a result of the Second Amendment, specifically the Exchanged Warrant.  See Note 11 “Warrants and Derivative Liabilities” for discussion of the valuation of the Exchanged Warrant.

[0001564590-14-000165:notes:76]
During the three and nine months ended December 31, 2013, the Company recorded non-cash interest expense for amortization of the debt discount related to the Exchanged Note of $0.9 million and $3.6 million, respectively. During the three and nine months ended December 31, 2012, the Company recorded non-cash interest expense for amortization of the debt discount related to the Exchanged Note of $2.2 million and $6.4 million, respectively.

[0001564590-14-000165:notes:77]
Provided certain equity conditions are met, the Company may elect to repay principal and interest in shares of the Company’s common stock. If the Company elects to make a payment in shares of the Company’s common stock, the number of shares to be issued is determined by dividing the amount of such payment by 85% of the lessor of the average volume-weighted average price (“VWAP”) of the 10 consecutive days immediately preceding the payment date or the VWAP price on the day preceding the payment date (the “Market Price”). The Company records the difference between the closing price of its common stock on the day preceding the payment date and the Market Price as a discount on the fair value of its shares. During the three months ended December 31, 2013, the Company made no payments in stock.  During the nine months ended December 31, 2013, the Company recorded $1.8 million of non-cash interest expense related to installment payments made by issuing the Company’s common stock at a discount, compared to $1.5 million during the three and nine months ended December 31, 2012.

[0001564590-14-000165:notes:78]
The Exchanged Note and the Amended Purchase Agreement contain certain covenants and restrictions, including, among others, that for so long as the Exchanged Note is outstanding, the Company will not incur any indebtedness (other than permitted indebtedness under the Exchanged Note), permit liens on its properties (other than permitted liens under the Exchanged Note), make payments on junior securities or declare dividends. The Exchanged Note also contains limitations on the transfer of certain assets. Events of default under the Exchanged Note include failure to pay principal or interest as due on the Exchanged Note, failure to deliver registered shares of common stock upon the holders request for conversion of part or all of the Exchanged Note, failure to maintain the Company’s common stock eligible for trading on defined markets, cross defaults to other material indebtedness, receipt of uninsured judgments against the Company in excess of defined limits and other administrative covenants, including the Term Loan discussed below, as defined in the Exchanged Note and related documentation. Upon an event of default, the holders may require the Company to redeem all or any portion of the outstanding principal amount of the Exchanged Note in cash plus a penalty as specified in the agreement. Also, if the Company fails to maintain an effective registration statement covering common stock to be used in settling obligations under the Exchanged Note, the Company will be required to pay a penalty as specified in the agreement.

[0001564590-14-000165:notes:79]
Senior Secured Term Loans

[0001564590-14-000165:notes:80]
On June 5, 2012, the Company entered into a Term Loan with Hercules Technology Growth Capital, Inc. (“Hercules”), under which the Company borrowed $10.0 million. After the closing fees and expenses, the net proceeds to the Company were $9.7 million. The Term Loan bears an interest rate equal to 11% plus the percentage, if any, by which the prime rate as reported by The Wall Street Journal exceeds 3.75%. The Company made interest-only payments from July 1, 2012 through October 31, 2012, after which the Company began repaying the Term Loan in equal monthly installments ending on December 1, 2014. In addition, Hercules received a warrant (the “First Warrant”) to purchase 139,276 shares of common stock, exercisable at an initial strike price of $3.59 per share, subject to adjustment, until December 5, 2017. Due to certain adjustment provisions within the warrant, it qualified for liability accounting and the fair value of $0.4 million was recorded upon issuance, which the Company recorded as a debt discount and a warrant liability.  The Company will pay an end of term fee of $0.5 million upon the earlier of maturity or prepayment of the loan. The Company has accrued the term fee and recorded a corresponding amount into the debt discount. In addition, the Company incurred $0.3 million of legal and origination costs in the year ended March 31, 2013, which have been recorded as a debt discount. The total debt discount including the First Warrant, end of term fee and legal and origination costs of $1.2 million is being amortized into interest expense over the term of the Term Loan using the effective interest method. Under this method, interest expense is recognized each period until the debt instrument reaches maturity. During the three and nine months ended December 31, 2013, the Company recorded non-cash interest expense for amortization of the debt discount related to the Term Loan of $0.1 million and $0.4 million, respectively. During the three and nine months ended December 31, 2012, the Company recorded non-cash interest expense for amortization of the debt discount related to the Term Loan of $0.2 million and $0.5 million, respectively.

[0001564590-14-000165:notes:81]
On November 15, 2013, the Company amended the Term Loan with Hercules and entered into a New Term Loan (collectively with the Term Loan, the “Term Loans”), borrowing an additional $10.0 million. After closing fees and expenses, the net proceeds to the Company for the New Term Loan were $9.8 million.  The New Term Loan also bears the same interest rate as the Term Loan.  The Company is making interest-only payments from December 1, 2013 to May 31, 2014.  If the Company achieves certain revenue targets for the six-month period ending March 31, 2014, interest only payments will continue through August 31, 2014.  Once the interest-only period ends, the Company will repay the New Term Loan in equal monthly installments ending on November 1, 2016.  Hercules received a warrant (the “Second Warrant”) to purchase 256,410 shares of common stock, exercisable at an initial strike price of $1.95 per share, subject to adjustment, until May 15, 2019.  In addition, the exercise price of the First Warrant was reduced to $1.95 per share.  (See Note 11, “Warrants and Derivative Liabilities,” for a discussion on both warrants and the valuation assumptions used.) The Company will pay an end of term fee of $0.5 million upon the earlier of maturity or prepayment of the New Term Loan. The Company has accrued the end of term fee and recorded a corresponding amount into the debt discount.  The New Term Loan includes a mandatory prepayment feature which allows Hercules the right to use any of the Company’s net proceeds from specified asset dispositions greater than $1.0 million in a calendar year to pay off any outstanding accrued interest and principal balance on the New Term Loan.  The Company determined the fair value to be de-minimis for this feature. In addition, the Company incurred $0.2 million of legal and origination costs in the three months ended December 31, 2013, which have been recorded as a debt discount. The total debt discount including the Second Warrant, end of term fee and legal and origination costs of $1.0 million is being amortized into interest expense over the term of the New Term Loan using the effective interest method. If the maturity of either of the term loans is accelerated because of prepayment, then the amortization will be accelerated. During the three months ended December 31, 2013, the Company recorded non-cash interest expense for amortization of the debt discount related to the New Term Loan of $0.1 million.

[0001564590-14-000165:notes:82]
The Term Loans are secured by substantially all of the Company’s existing and future assets, including a mortgage on real property owned by the Company’s wholly-owned subsidiary, ASC Devens LLC, and located at 64 Jackson Road, Devens, Massachusetts.  The Term Loans contain certain covenants that restrict the Company’s ability to, among other things, incur or assume certain debt, merge or consolidate, materially change the nature of the Company’s business, make certain investments, acquire or dispose of certain assets, make guaranties or grant liens on its assets, make certain loans, advances or investments, declare dividends or make distributions or enter into transactions with affiliates. In addition, there is a covenant that requires the Company to maintain a minimum unrestricted cash balance in the United States of at least $15.0 million at the inception of the New Term Loan.  This amount will be reduced by $2.5 million for every $5.0 million of net proceeds from the sale of its common stock after November 15, 2013, including those under the ATM, to an amount not lower than $7.5 million or the outstanding combined principal balances of the Term Loans, whichever is lower.  The events of default under the Term Loans include, but are not limited to, failure to pay amounts due, breaches of covenants, bankruptcy events, cross defaults under other material indebtedness and the occurrence of a material adverse effect and/or change in control. In the case of a continuing event of default, Hercules may, among other remedies, declare due all unpaid principal amounts outstanding and any accrued but unpaid interest and foreclose on all collateral granted to Hercules as security under the Term Loans.

[0001564590-14-000165:notes:83]
Although the Company believes that it is in and expects to remain in compliance with the covenants and restrictions under the Exchanged Note and Term Loans as of the date of this Quarterly Report on Form 10-Q, there can be no assurance that the Company will continue to be in compliance.

[0001564590-14-000165:notes:84]
Interest expense on the Exchanged Note and Term Loans for the three and nine months ended December 31, 2013 was $1.6 million and $7.2 million, respectively, which included $1.1 million and $5.9 million, respectively, of non-cash interest expense related to the amortization of the debt discount on the Exchanged Note and Term Loans and payment of the Exchanged Note in Company common stock at a discount. Interest expense on the Exchanged Note and Term Loan for the three and nine months ended December 31, 2012 was $4.6 million, and $10.3 million, respectively, which included $3.9 million and $8.4 million, of non-cash interest expense related to the amortization of the debt discount on the Exchanged Note and Term Loan, respectively.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001564590-14-000165:notes:85]
[same as prior period, unchanged from 0001564590-13-001183:notes:81]

[0001564590-14-000165:notes:86]
[same as prior period, unchanged from 0001564590-13-001183:notes:82]

[0001564590-14-000165:notes:87]
On April 4, 2012, the Company entered into the Purchase Agreement for the Initial Note and on December 20, 2012, the Company entered into the First Amendment pursuant to which it exchanged the Initial Note for the Exchanged Note (See Note 10, “Debt” for further discussion). The Initial Note included a warrant to purchase 3,094,060 shares of the Company’s common stock. The warrant is exercisable at any time on or after the date that is six months after the issuance of the warrant and entitles CVI to purchase shares of the Company’s common stock for a period of five years from the initial date the warrant becomes exercisable at a price equal to $5.45 per share, subject to certain price-based and other anti-dilution adjustments. On October 9, 2013, the Company entered into the Second Amendment with CVI. Pursuant to the Second Amendment, the Company exchanged the Original Warrant for the Exchanged Warrant, with a reduced exercise price of $2.61 per share of common stock. Other than the reduced exercise price, the Exchanged Warrant has the same terms and conditions as the Original Warrant. The Company recorded a charge of approximately $1.0 million for the increase in fair value of the Exchanged Warrant resulting from the Second Amendment on the warrant liability during the three months ending December 31, 2013.  As a result of the sales of common stock under the ATM (See Note 12, “Stockholders’ Equity”, for further discussion of the ATM) during the three months ended December 31, 2013, the exercise price of the Exchanged Warrant was reduced to $2.59 per share.  The Exchanged Warrant may not be exercised if, after giving effect to the conversion, CVI together with its affiliates would beneficially own in excess of 4.99% of the Company’s common stock. This percentage may be raised to any other percentage not in excess of 9.99% at the option of CVI, upon at least 61-days prior notice to the Company, or lowered to any other percentage, at the option of CVI, at any time.

[0001564590-14-000165:notes:88]
The Company calculated the fair value of the derivative liabilities, (See Note 10, “Debt” for further discussion), and warrants utilizing an integrated lattice model. The lattice model is an option pricing model that involves the construction of a binomial tree to show the different paths that the underlying asset may take over the option’s life. A lattice model can take into account expected changes in various parameters such as volatility over the life of the options, providing more accurate estimates of option prices than the Black-Scholes model.

[0001564590-14-000165:notes:89]
[same as prior period, unchanged from 0001564590-13-001183:notes:85]

[0001564590-14-000165:notes:90]
[same as prior period, unchanged from 0001564590-13-001183:notes:86]

[0001564590-14-000165:notes:91]
|  |  |  |  |  | Post-modification |  |  | Pre-modification |  |  |  |  |  |  |  |
|  | December 31, |  |  | October 9, |  | October 9, |  |  | September 30, |  |  | June 30, |  |
| Fiscal Year 13 | 2013 |  |  | 2013 |  | 2013 |  |  | 2013 |  |  | 2013 |  |
| Risk-free interest rate |  | 1.17 | % |  |  | 1.05 | % |  |  | 1.05 | % |  |  | 1.02 | % |  |  | 1.13 | % |
| Expected annual dividend yield |  | — | % |  |  | — | % |  |  | — | % |  |  | — | % |  |  | — | % |
| Expected volatility |  | 75.6 | % |  |  | 71.5 | % |  |  | 71.5 | % |  |  | 72.0 | % |  |  | 71.9 | % |
| Term (years) |  | 3.76 |  |  |  | 3.99 |  |  |  | 3.99 |  |  |  | 4.01 |  |  |  | 4.27 |  |
| Fair value | $ | 2.2 million |  |  | $ | 3.2 million |  |  | $ | 2.2 million |  |  | $ | 2.5 million |  |  | $ | 3.0 million |  |
|  | March 31, |  |  | December 31, |  |  | September 30, |  |  | June 30, |  |  | April 4, |  |
| Fiscal Year 12 | 2013 |  |  | 2012 |  |  | 2012 |  |  | 2012 |  |  | 2012 |  |
| Risk-free interest rate |  | 0.67 | % |  |  | 0.75 | % |  |  | 0.63 | % |  |  | 0.77 | % |  |  | 1.19 | % |
| Expected annual dividend yield |  | — | % |  |  | — | % |  |  | — | % |  |  | — | % |  |  | — | % |
| Expected volatility |  | 71.7 | % |  |  | 80.6 | % |  |  | 80.9 | % |  |  | 80.8 | % |  |  | 80.0 | % |
| Term (years) |  | 4.51 |  |  |  | 4.76 |  |  |  | 5.01 |  |  |  | 5.28 |  |  |  | 5.50 |  |
| Fair value | $ | 3.4 million |  |  | $ | 4.4 million |  |  | $ | 7.1 million |  |  | $ | 8.6 million |  |  | $ | 7.0 million |  |

[0001564590-14-000165:notes:92]
The Company recorded a net gain, resulting from the decrease in the fair value of the Exchanged Warrant, including the impact of the modification, of $0.3 million and $1.2 million to change in fair value of derivatives and warrants in the three and nine months ended December 31, 2013, respectively. The Company recorded net gains of $2.7 million and $2.6 million in the three and nine months ended December 31, 2012, respectively.

[0001564590-14-000165:notes:93]
[same as prior period, unchanged from 0001564590-13-001183:notes:91]

[0001564590-14-000165:notes:94]
[same as prior period, unchanged from 0001564590-13-001183:notes:92]

[0001564590-14-000165:notes:95]
The terms of the December 2012 debt modification with CVI reduced the conversion price of the Initial Note from $4.85 per share to $3.19 per share in the Exchanged Note. As a result the Company revalued these derivatives pre- and post-modification and recorded the difference of $0.5 million as a debt discount and a derivative liability. (See Note 10, “Debt,” for further discussion.)   As a result of the sales of common stock under the ATM (See Note 12, “Stockholders’ Equity”, for further discussion of the ATM) during the three months ended December 31, 2013, the conversion price of the Exchanged Note was reduced to $3.15 per share.

[0001564590-14-000165:notes:96]
[same as prior period, unchanged from 0001564590-13-001183:notes:94]

[0001564590-14-000165:notes:97]
|  | December 31, |  |  | September 30, |  |  | June 30, |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Fiscal Year 13 | 2013 |  |  | 2013 |  |  | 2013 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Principal outstanding (000's) | $ | 10,411 |  |  | $ | 10,411 |  |  | $ | 14,389 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Stock price | $ | 1.64 |  |  | $ | 2.34 |  |  | $ | 2.64 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Percentage volume condition met |  | 87.2 | % |  |  | 80.2 | % |  |  | 87.5 | % |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Expected volatility |  | 68.6 | % |  |  | 66.3 | % |  |  | 65.8 | % |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Risk free rate |  | 0.12 | % |  |  | 0.10 | % |  |  | 0.21 | % |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Bond yield |  | 16.5 | % |  |  | 15.5 | % |  |  | 16.7 | % |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Recovery rate |  | 35.0 | % |  |  | 35.0 | % |  |  | 37.0 | % |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Redeemable | yes |  |  | yes |  |  | yes |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Total time (years) |  | 0.75 |  |  |  | 1.00 |  |  |  | 1.26 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Dilution effect | yes |  |  | yes |  |  | yes |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Fair value | $ — |  |  | $ 0.2 million |  |  | $ 0.5 million |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Fair value as a percent of par |  | 0.02 | % |  |  | 0.7 | % |  |  | 3.3 | % |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  |  |  |  |  |  |  |  | Post-modification |  |  | Pre-modification |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  | March 31, |  |  | December 31, |  |  | December 20, |  |  | December 20, |  |  | September 30, |  |  | June 30, |  |  | April 4, |  |
| Fiscal Year 12 | 2013 |  |  | 2012 |  |  | 2012 |  |  | 2012 |  |  | 2012 |  |  | 2012 |  |  | 2012 |  |
| Principal outstanding (000's) | $ | 15,380 |  |  | $ | 20,944 |  |  | $ | 20,944 |  |  | $ | 24,074 |  |  | $ | 24,074 |  |  | $ | 25,000 |  |  | $ | 25,000 |  |
| Stock price | $ | 2.67 |  |  | $ | 2.62 |  |  | $ | 2.95 |  |  | $ | 2.95 |  |  | $ | 4.15 |  |  | $ | 4.68 |  |  | $ | 3.97 |  |
| Percentage volume condition met |  | 80.5 | % |  |  | 94.5 | % |  |  | 94.9 | % |  |  | 28.6 | % |  |  | 51.0 | % |  |  | 75.2 | % |  |  | 85.9 | % |
| Expected volatility |  | 66.9 | % |  |  | 73.5 | % |  |  | 72.5 | % |  |  | 72.5 | % |  |  | 70.0 | % |  |  | 71.0 | % |  |  | 75.0 | % |
| Risk free rate |  | 0.20 | % |  |  | 0.23 | % |  |  | 0.25 | % |  |  | 0.25 | % |  |  | 0.23 | % |  |  | 0.33 | % |  |  | 0.44 | % |
| Bond yield |  | 16.5 | % |  |  | 16.5 | % |  |  | 16.5 | % |  |  | 16.5 | % |  |  | 15.0 | % |  |  | 16.0 | % |  |  | 15.0 | % |
| Recovery rate |  | 30.0 | % |  |  | 30.0 | % |  |  | 30.0 | % |  |  | 30.0 | % |  |  | 30.0 | % |  |  | 30.0 | % |  |  | 30.0 | % |
| Redeemable |  | yes |  |  |  | yes |  |  |  | yes |  |  |  | yes |  |  |  | yes |  |  |  | yes |  |  |  | yes |  |
| Total time (years) |  | 1.51 |  |  |  | 1.76 |  |  |  | 1.79 |  |  |  | 1.79 |  |  |  | 2.01 |  |  |  | 2.28 |  |  |  | 2.50 |  |
| Dilution effect |  | yes |  |  |  | yes |  |  |  | yes |  |  |  | yes |  |  |  | yes |  |  |  | yes |  |  |  | yes |  |
| Fair value |  | $ 0.5 million |  |  |  | $ 1.0 million |  |  |  | $ 1.5 million |  |  |  | $ 0.9 million |  |  |  | $ 2.8 million |  |  |  | $ 4.5 million |  |  |  | $ 3.8 million |  |
| Fair value as a percent of par |  | 3.4 | % |  |  | 4.9 | % |  |  | 7.1 | % |  |  | 3.9 | % |  |  | 11.4 | % |  |  | 17.9 | % |  |  | 15.1 | % |

[0001564590-14-000165:notes:98]
[same as prior period, unchanged from 0001564590-13-001183:notes:97]

[0001564590-14-000165:notes:99]
The Company recorded the decrease in the fair value of the derivative liabilities of $0.2 million and $0.5 million as a gain to changes in fair value of derivatives and warrants in the three and nine months ended December 31, 2013, and similarly, gains of $2.3 million and $3.3 million in the three and nine months ended December 31, 2012, respectively.

[0001564590-14-000165:notes:100]
Senior Secured Term Loan – First Warrant

[0001564590-14-000165:notes:101]
On June 5, 2012, the Company entered into the Loan and Security Agreement with Hercules. (See Note 10, “Debt,” for additional information regarding the Loan and Security Agreement.) In conjunction with this agreement, the Company issued the First Warrant to purchase 139,276 shares of the Company’s common stock. The First Warrant is exercisable at any time after its issuance and expires on December 5, 2017, at a price equal to $3.59 per share subject to certain price-based and other anti-dilution adjustments.  The exercise price was reduced to $1.95 per share in conjunction with entering into the New Term Loan.

[0001564590-14-000165:notes:102]
The Company accounts for the First Warrant as a liability due to certain provisions within the warrant, which requires that it be recorded at fair value. The First Warrant is subject to revaluation at each balance sheet date and any change in fair value will be recorded as changes in fair value of derivatives and warrants until the earlier of expiration or its exercise at which time the warrant liability will be reclassified to equity.

[0001564590-14-000165:notes:103]
Following is a summary of the key assumptions used to calculate the fair value of the First Warrant:

[0001564590-14-000165:notes:104]
|  |  |  |  |  | Post-modification |  |  | Pre-modification |  |  |  |  |  |  |  |  |  |
|  | December 31, |  |  | November 15, |  |  | November 15, |  |  | September 30, |  |  | June 30, |  |
| Fiscal Year 13 | 2013 |  |  | 2013 |  |  | 2013 |  |  | 2013 |  |  | 2013 |  |
| Risk-free interest rate |  | 1.24 | % |  |  | 1.00 | % |  |  | 1.00 | % |  |  | 1.09 | % |  |  | 1.20 | % |
| Expected annual dividend yield | — | % |  | — | % |  | — | % |  | — | % |  | — | % |
| Expected volatility |  | 74.79 | % |  |  | 72.64 | % |  |  | 72.64 | % |  |  | 72.10 | % |  |  | 72.30 | % |
| Term (years) |  | 3.93 |  |  |  | 4.05 |  |  |  | 4.05 |  |  |  | 4.18 |  |  |  | 4.43 |  |
| Fair value | $ 0.1 million |  |  | $ 0.1 million |  |  | $ 0.1 million |  |  | $ 0.2 million |  |  | $ 0.2 million |  |
|  | March 31, |  |  | December 31, |  |  | September 30, |  |  | June 30, |  |  | June 5, |  |
| Fiscal Year 12 | 2013 |  |  | 2012 |  |  | 2012 |  |  | 2012 |  |  | 2012 |  |
| Risk-free interest rate |  | 0.70 | % |  |  | 0.75 | % |  |  | 0.64 | % |  |  | 0.80 | % |  |  | 0.77 | % |
| Expected annual dividend yield | — | % |  | — | % |  | — | % |  | — | % |  | — | % |
| Expected volatility |  | 72.01 | % |  |  | 80.14 | % |  |  | 81.18 | % |  |  | 80.32 | % |  |  | 79.99 | % |
| Term (years) |  | 4.68 |  |  |  | 4.93 |  |  |  | 5.18 |  |  |  | 5.44 |  |  |  | 5.50 |  |
| Fair value | $ 0.2 million |  |  | $ 0.2 million |  |  | $ 0.4 million |  |  | $ 0.5 million |  |  | $ 0.4 million |  |

[0001564590-14-000165:notes:105]
The Company recorded a decrease in the fair value of the First Warrant resulting in a gain of less than $0.1 million during the three and nine months ended December 31, 2013. The Company recorded a decrease in the fair value of $0.2 million as a gain to change in fair value of derivatives and warrants during the three and nine months ended December 31, 2012.

[0001564590-14-000165:notes:106]
Senior Secured Term Loan – Second Warrant

[0001564590-14-000165:notes:107]
On November 15, 2013, the Company amended the Loan and Security Agreement with Hercules and entered into the New Term Loan. (See Note 10, “Debt,” for additional information regarding the New Term Loan.) In conjunction with this agreement, the Company issued the Second Warrant to purchase 256,410 shares of the Company’s common stock. The Second Warrant is exercisable at any time after its issuance and expires on May 15, 2019, at a price equal to $1.95 per share subject to certain price-based and other anti-dilution adjustments.

[0001564590-14-000165:notes:108]
The Company accounts for the Second Warrant as a liability due to certain provisions within the warrant, which requires that it be recorded at fair value. The Second Warrant is subject to revaluation at each balance sheet date and any change in fair value will be recorded as changes in fair value of derivatives and warrants until the earlier of expiration or its exercise at which time the warrant liability will be reclassified to equity.

[0001564590-14-000165:notes:109]
Following is a summary of the key assumptions used to calculate the fair value of the Second Warrant:

[0001564590-14-000165:notes:110]
|  |  |  |  |  | New Issuance |  |
|  | December 31, |  |  | November 15, |  |
| Fiscal Year 13 | 2013 |  |  | 2013 |  |
| Risk-free interest rate |  | 1.89 | % |  |  | 1.55 | % |
| Expected annual dividend yield | — | % |  | — | % |
| Expected volatility |  | 80.37 | % |  |  | 76.97 | % |
| Term (years) |  | 5.37 |  |  |  | 5.49 |  |
| Fair value | $ 0.3 million |  |  | $ 0.3 million |  |

[0001564590-14-000165:notes:111]
The Company recorded a decrease in the fair value of the Second Warrant resulting in a gain of less than $0.1 million during the three months ended December 31, 2013.

[0001564590-14-000165:notes:112]
The Company prepared its estimates for the assumptions used to determine the fair value of the warrants issued in conjunction with both the Exchanged Note and Term Loans utilizing the respective terms of the warrants with similar inputs, as described above.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001564590-14-000165:notes:113]
12.Stockholders’ Equity

[0001564590-14-000165:notes:114]
On November 15, 2013, the Company entered into an ATM arrangement, pursuant to which, the Company may, at its discretion, sell up to $30.0 million of the Company’s common stock through its sales agent, MLV & Co. LLC (“MLV”).   Sales of common stock made under the ATM are made on The NASDAQ Global Market under the Company’s previously filed and currently effective Registration Statement on Form S-3 (File No. 333-191153) by means of ordinary brokers’ transactions at market prices. Additionally, under the terms of the ATM, the Company may also sell shares of its common stock through MLV, on The NASDAQ Global Market or otherwise, at negotiated prices or at prices related to the prevailing market price. Under the terms of the ATM, MLV may not engage in any proprietary trading or trading as principal for MLV’s own account. MLV uses its commercially reasonable efforts to sell the Company’s common stock from time to time, based upon the Company’s instructions (including any price, time or size limits or other customary parameters or conditions the Company may impose). The Company pays MLV a commission of up to 3% of the gross proceeds from the sale of shares of its common stock under the ATM. The Company has also agreed to provide MLV with customary indemnification rights. The offering of common stock pursuant to the ATM will terminate upon the earlier of the sale of all of the common stock subject to the ATM or the termination of the ATM by the Company or MLV. Either party may terminate the ATM at its sole discretion at any time upon written notice to the other party.

[0001564590-14-000165:notes:115]
During the three months ended December 31, 2013, the Company received net proceeds of $3.3 million, including sales commissions and offering expenses, from sales of approximately 2.4 million shares of its common stock at an average sales price of approximately $1.51 per share under the ATM.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001564590-14-000165:notes:116]
13. Commitments and Contingencies

[0001564590-14-000165:notes:117]
Commitments

[0001564590-14-000165:notes:118]
Purchase Commitments

[0001564590-14-000165:notes:119]
The Company periodically enters into non-cancelable purchase contracts in order to ensure the availability of materials to support production of its products. Purchase commitments represent enforceable and legally binding agreements with suppliers to purchase goods or services. The Company periodically assesses the need to provide for impairment on these purchase contracts and record a loss on purchase commitments when required. As of December 31, 2013, the Company reported a liability for adverse purchase commitments of $0.4 million. During the three and nine months ended December 31, 2013, the Company reduced its accrual for adverse purchase commitments by $0.5 million and $1.0 million, respectively, due to payments to certain vendors.

[0001564590-14-000165:notes:120]
Legal Contingencies

[0001564590-14-000165:notes:121]
From time to time, the Company is involved in legal and administrative proceedings and claims of various types. The Company records a liability in its consolidated financial statements for these matters when a loss is known or considered probable and the amount can be reasonably estimated. The Company reviews these estimates each accounting period as additional information is known and adjusts the loss provision when appropriate. If a matter is both probable to result in a liability and the amounts of loss can be reasonably estimated, the Company estimates and discloses the possible loss or range of loss. If the loss is not probable or cannot be reasonably estimated, a liability is not recorded in its consolidated financial statements.

[0001564590-14-000165:notes:122]
Between April 6, 2011 and May 12, 2011, seven putative securities class action complaints were filed against the Company and two of its officers in the United States District Court for the District of Massachusetts; one complaint additionally asserted claims against the underwriters who participated in our November 12, 2010 securities offering. On June 7, 2011, the United States District Court for the District of Massachusetts (the “Court”) consolidated these actions under the caption Lenartz v. American Superconductor Corporation, et al., Docket No. 1:11-cv-10582-WGY. On August 31, 2011, Lead Plaintiff, the Plumbers and Pipefitters National Pension Fund, filed a consolidated amended complaint against the Company, its officers and directors, and the underwriters who participated in our November 12, 2010 securities offering, asserting claims under sections 10(b) and 20(a) of the Securities Exchange Act of 1934 (the “Exchange Act”) and Rule 10b-5 promulgated under the Exchange Act, as well as under sections 11, 12(a)(2) and 15 of the Securities Act of 1933 (the “Securities Act”). The complaint alleges that during the relevant class period, the Company and its officers omitted to state material facts and made materially false and misleading statements relating to, among other things, its projected and recognized revenues and earnings, as well as its relationship with Sinovel Wind Group Co., Ltd. that artificially inflated the value of the Company’s stock price. The complaint further alleges that the Company’s November 12, 2010 securities offering contained untrue statements of material facts and omitted to state material facts required to be stated therein. The plaintiffs seek unspecified damages, rescindment of the Company’s November 12, 2010 securities offering, and an award of costs and expenses, including attorney’s fees. All defendants moved to dismiss the consolidated amended complaint. On December 16, 2011, the district court issued a summary order declining to dismiss the Securities Act claims against the Company and its officers, and taking under advisement the motion to dismiss the Exchange Act claims against the Company and its officers and the motion to dismiss the Securities Act claims made against the underwriters. On July 26, 2012, the district court dismissed the Exchange Act claims against the Company and its officers and denied the motion to dismiss the Securities Act claims made against the underwriters. On May 17, 2013, the parties informed the district court that they had reached a settlement in principle, and requested a 30-day stay of the proceedings while the specific terms of the settlement continue to be negotiated. On November 19, 2013, the Company entered into a Stipulation and Agreement of Settlement (the “Stipulation”), which will resolve the claims asserted against the Company, certain of its current and former officers and directors, and the underwriters. The terms of the Stipulation provide, among other things, a settlement payment by the Company of $10.0 million, $8.2 million of which will be funded by the Company’s insurers and $1.8 million of which is expected to be paid through the issuance of 944,882 shares of its common stock (the “Settlement Shares”). In the event that the value of the Settlement Shares (as calculated under the Stipulation) decreases as of the effective date of the settlement, the Company is required to make a cash payment for the difference in value. As of March 31, 2013, the Company established a reserve for the anticipated cost to settle this class action litigation. The terms of the Stipulation are subject to approval by the Court following notice to all class members. The issuance of the Settlement Shares is expected to be exempt from registration pursuant to Section 3(a)(10) of the Securities Act of 1933, as amended.  Based on the Company’s assessment of the probable losses on this claim, the Company has recorded a loss contingency of $1.8 million as of December 31, 2013.

[0001564590-14-000165:notes:123]
Between May 4, 2011 and June 17, 2011, four putative shareholder derivative complaints were filed against the Company (as a nominal defendant) and certain of its directors in the United States District Court for the District of Massachusetts. On July 5, 2011, the District Court consolidated three of these actions, and that matter is now captioned In re American Superconductor Corporation Derivative Litigation, Docket No. 1:11-cv-10784-WGY. On June 1, 2011, the plaintiff in the fourth action, Marlborough Family Revocable Trust v. Yurek, et al., moved to voluntarily dismiss its complaint and refiled its complaint in Superior Court for the Commonwealth of Massachusetts, Middlesex County. On September 7, 2011, the Marlborough action and another putative shareholder derivative complaint filed in Superior Court for the Commonwealth of Massachusetts were consolidated. That consolidated matter is captioned In re American Superconductor Corporation Shareholder Derivative Litigation, Docket No. 11-1961. On January 12, 2012, an additional shareholder derivative complaint was filed in the Court of Chancery for the State of Delaware. That matter is captioned Krasnoff v. Budhraja, et al., Docket No. 7171. The allegations of the derivative complaints mirror the allegations made in the putative class action complaints described above. The plaintiffs purport to assert claims against the director defendants for breach of fiduciary duty, abuse of control, gross mismanagement, unjust enrichment and corporate waste.  On February 4, 2014, the Company entered into a Stipulation and Agreement of Settlement (the “Derivative Stipulation”) to settle In re American Superconductor Corporation Derivative Litigation, In re American Superconductor Corporation Shareholder Derivative Litigation, and Krasnoff v. Budhraja, et al., (together, the “Derivative Actions”). The Derivative Actions named certain current and former directors and officers of the Company as defendants. The current and former directors and officers named as individual defendants have denied expressly and continue to deny each and all of the claims and contentions alleged against them, and neither the individual defendants nor the Company have admitted any fault, wrongdoing or concession of liability in connection with the terms of the Derivative Stipulation. The Derivative Stipulation will be filed with the Court within five business days of February 4, 2014. The Derivative Stipulation provides for, among other things, (a) a release of all claims relating to the Derivative Actions for the Company, the individual defendants, who are all current or former officers and directors of the Company, and the plaintiffs; (b) a requirement that the Company pay to plaintiffs’ counsel $475,000.00 for fees and expenses, which will be fully funded by the Company’s insurers; and (c) certain additions to the Company’s corporate governance policies, many of which have already been implemented. The Derivative Stipulation remains subject to preliminary and final approval by the Court and certain other conditions, including notice to stockholders. At this time, there can be no assurance that the Derivative Stipulation will receive the required approvals or that the settlement will become final.  Based on the Company’s assessment that the probable losses on this claim are insignificant, no loss contingency was recorded as of December 31, 2013.

[0001564590-14-000165:notes:124]
On September 13, 2011, the Company commenced a series of legal actions in China against Sinovel Wind Group Co. Ltd. (“Sinovel”). The Company’s Chinese subsidiary, Suzhou AMSC Superconductor Co. Ltd., filed a claim for arbitration with the Beijing Arbitration Commission in accordance with the terms of the Company’s supply contracts with Sinovel. The case is captioned (2011) Jing Zhong An Zi No. 0963. On March 31, 2011, Sinovel refused to accept contracted shipments of 1.5 megawatt, (“MW”) and 3 MW wind turbine core electrical components and spare parts that the Company was prepared to deliver. The Company alleges that these actions constitute material breaches of its contracts because Sinovel did not give it notice that it intended to delay deliveries as required under the contracts. Moreover, the Company alleges that Sinovel has refused to pay past due amounts for prior shipments of core electrical components and spare parts. The Company is seeking compensation for past product shipments and retention (including interest) in the amount of approximately RMB 485 million ($76 million) due to Sinovel’s breaches of its contracts. The Company is also seeking specific performance of our existing contracts as well as reimbursement of all costs and reasonable expenses with respect to the arbitration. The value of the undelivered components under the existing contracts, including the deliveries refused by Sinovel in March 2011, amounts to approximately RMB 4.6 billion ($720 million).

[0001564590-14-000165:notes:125]
On October 8, 2011, Sinovel filed with the Beijing Arbitration Commission an application under the caption (2011) Jing Zhong An Zi No. 0963, for a counterclaim against the Company for breach of the same contracts under which the Company filed its original arbitration claim. Sinovel claimed, among other things, that the goods supplied by the Company do not conform to the standards specified in the contracts and claimed damages in the amount of approximately RMB 370 million ($58 million). On October 17, 2011, Sinovel filed with the Beijing Arbitration Commission a request for change of counterclaim to increase its damage claim to approximately RMB 1 billion ($157 million). On December 22, 2011, Sinovel filed with the Beijing Arbitration Commission an additional request for change of counterclaim to increase its damages claim to approximately RMB 1.2 billion ($190 million). On February 27, 2012, Sinovel filed with the Beijing Arbitration Commission an application under the caption (2012) Jing Zhong An Zi No. 0157, against the Company for breach of the same contracts under which the Company filed its original arbitration claim. Sinovel claimed, among other things, that the goods supplied by the Company do not conform to the standards specified in the contracts and claimed damages in the amount of approximately RMB 105 million ($17 million). The Company believes that Sinovel’s claims are without merit and it intends to defend these actions vigorously. Since the proceedings in this matter are in relatively early stages, the Company cannot reasonably estimate possible losses or range of losses at this time.

[0001564590-14-000165:notes:126]
The Company also submitted a civil action application to the Beijing No. 1 Intermediate People’s Court under the caption (2011) Yi Zhong Min Chu Zi No. 15524, against Sinovel for software copyright infringement on September 13, 2011. The application alleges Sinovel’s unauthorized use of portions of the Company’s wind turbine control software source code developed for Sinovel’s 1.5MW wind turbines and the binary code, or upper layer, of the Company’s software for the PM3000 power converters in 1.5MW wind turbines. In July 2011, a former employee of the Company’s Austrian subsidiary was arrested in Austria on charges of economic espionage and fraudulent manipulation of data. In September 2011, the former employee pled guilty to the charges, and was imprisoned. As a result of the Company’s internal investigation and a criminal investigation conducted by Austrian authorities, the Company believes that this former employee was contracted by Sinovel through an intermediary while employed by the Company and improperly obtained and transferred to Sinovel portions of its wind turbine control software source code developed for Sinovel’s 1.5MW wind turbines. Moreover, the Company believes the former employee illegally used source code to develop for Sinovel a software modification to circumvent the encryption and remove technical protection measures on the Company’s PM3000 power converters in 1.5MW wind turbines in the field. The Company is seeking a cease and desist order with respect to the unauthorized copying, installation and use of its software, monetary damages of approximately RMB 38 million ($6 million) for our economic losses and reimbursement of all costs and reasonable expenses. The Beijing No. 1 Intermediate People’s Court accepted the case, which was necessary in order for the case to proceed. In November 2011, Sinovel filed a motion to remove this case from the Beijing No. 1 Intermediate People’s Court and transfer the matter to the Beijing Arbitration Commission. On February 14, 2012, the court denied Sinovel’s motion to remove the case. On February 21, 2012, Sinovel filed an appeal of the Beijing No. 1 Intermediate People’s Court decision to the Beijing Higher People’s Court. On April 25, 2012, the Beijing Higher People’s Court issued a final Civil Ruling which supports the Beijing No.1 Intermediate People’s Court’s civil ruling and rejected Sinovel’s appeal. Sinovel filed an appeal of the Beijing Higher People’s Court’s decision with China’s Supreme People’s Court. A hearing regarding this appeal was held at the Chinese Supreme People’s Court on October 26, 2012. On November 23, 2012, China’s Supreme People’s Court issued a Civil Ruling, holding that (1) it will conduct a re-trial of Sinovel’s appeal, and (2) the lower court’s decision will be stayed pending the re-trial. China’s Supreme People’s Court conducted a re-trial of Sinovel’s appeal on May 29, 2013.

[0001564590-14-000165:notes:127]
Sinovel filed a new motion on June 18, 2012, to remove this case from the Beijing No. 1 Intermediate People’s Court to the court located in Gansu Province. On October 19, 2012, the court disallowed Sinovel’s motion due to its late filing.

[0001564590-14-000165:notes:128]
The Company submitted a civil action application to the Beijing Higher People’s Court against Sinovel and certain of its employees for trade secret infringement on September 13, 2011 under the caption (2011) Gao Min Chu Zi No. 4193. The application alleges the defendants’ unauthorized use of portions of the Company’s wind turbine control software source code developed for Sinovel’s 1.5MW wind turbines as described above with respect to the Copyright Action. The Company is seeking monetary damages of RMB 2.9 billion ($453 million) for the trade secret infringement as well as reimbursement of all costs and reasonable expenses. The Beijing Higher People’s Court accepted the case, which was necessary in order for the case to proceed. On December 22, 2011, the Beijing Higher People’s Court transferred this case to the Beijing No. 1 Intermediate People’s Court under the caption (2011) Gao Min Chu Zi No. 4193. On June 7, 2012, the Company received an Acceptance Notice from the Beijing No.1 Intermediate People’s Court under the caption (2012) Yi Zhong Min Chu Zi No.6833. The Company is currently awaiting notice from the Beijing No. 1 Intermediate People’s Court regarding the first hearing date. In August 2012, Sinovel filed a motion to remove this case from the Beijing No. 1 Intermediate People’s Court and transfer the matter to the Beijing Arbitration Commission.

[0001564590-14-000165:notes:129]
On September 16, 2011, the Company filed a civil copyright infringement complaint in the Hainan Province No. 1 Intermediate People’s Court against Dalian Guotong Electric Co. Ltd. (“Guotong”), a supplier of power converter products to Sinovel, and Huaneng Hainan Power, Inc. (“Huaneng”), a wind farm operator that has purchased Sinovel wind turbines containing Guotong power converter products. The case is captioned (2011) Hainan Yi Zhong Min Chu Zi No. 62. The application alleges that the Company’s PM1000 converters in certain Sinovel wind turbines have been replaced by converters produced by Guotong. Because the Guotong converters are being used in wind turbines containing the Company’s wind turbine control software, the Company believes that its copyrighted software is being infringed. The Company is seeking a cease and desist order with respect to the unauthorized use of its software, monetary damages of RMB 1.2 million ($0.2 million) for its economic losses (with respect to Guotong only) and reimbursement of all costs and reasonable expenses. The court has accepted the case, which was necessary in order for the case to proceed. In addition, upon the request of the defendant Huaneng, Sinovel has been added by the court to this case as a defendant and Huaneng has been released from this case. In December 2011, Sinovel filed a jurisdiction opposition motion requesting dismissal by the Hainan Province No. 1 Intermediate People’s Court, saying the case should be governed by the Beijing Arbitration Commission. On February 3, 2012, the Company received the Civil Ruling from the court, which granted Sinovel’s motion, and dismissed the entire case. The Company appealed the court’s ruling to the Hainan Higher Court, which on April 5, 2012 upheld the decision of the Hainan Province No. 1 Intermediate People’s Court. On April 9, 2012, the Company filed an appeal of the Hainan Higher Court’s decision with China’s Supreme People’s Court. China’s Supreme People’s Court accepted the appeal on May 23, 2012. The case is captioned, (2012) Min Shen Zi No. 630. On December 20, 2012, China’s Supreme People’s Court issued a Civil ruling, holding that (1) it will conduct a re-trial of the Company’s appeal and (2) the lower court’s decision will be stayed pending the re-trial. China’s Supreme People’s Court conducted a re-trial of Sinovel’s appeal on May 29, 2013.

[0001564590-14-000165:notes:130]
Ghodawat Energy Pvt Ltd (“Ghodawat”), a company registered in India carrying on the business of wind power development, lodged a Request for Arbitration with the Secretariat of the ICC International Court of Arbitration on May 12, 2011 and named AMSC Windtec GmbH (“AMSC Austria”) as the Respondent. Under the Request for Arbitration, Ghodawat alleges that AMSC Austria breached an agreement dated March 19, 2008 pursuant to which AMSC Austria granted a license to Ghodawat to manufacture, use, sell, market, erect, commission and maintain certain wind turbines using its technical information and wind turbine design (the “License Agreement”). Under the Request for Arbitration, Ghodawat’s claims in this arbitration amount to approximately €18 million ($24 million). AMSC Austria filed an Answer to Request for Arbitration and Counterclaim (“Answer and Counterclaim”), in which AMSC Austria denied Ghodawat’s claims in their entirety. AMSC Austria has also submitted counterclaims under the License Agreement against Ghodawat in the amount of approximately €6 million ($9 million). Ghodawat has filed a Reply to Answer to Request for Arbitration and Counterclaim in which it denies AMSC Austria’s counterclaims. On June 3, 2013, the final oral submissions’ hearing was conducted and the Company believes it will take several months for the Tribunal to render a decision. The Company has recorded a loss contingency based on its assessment of probable losses on this claim; however this amount of loss contingency that has been recorded is immaterial to its consolidated financial statements.

[0001564590-14-000165:notes:131]
Other

[0001564590-14-000165:notes:132]
The Company enters into long-term construction contracts with customers that require the Company to obtain performance bonds. The Company is required to deposit an amount equivalent to some or all the face amount of the performance bonds into an escrow account until the termination of the bond. When the performance conditions are met, amounts deposited as collateral for the performance bonds are returned to the Company. In addition, the Company has various contractual arrangements in which minimum quantities of goods or services have been committed to be purchased on an annual basis.

[0001564590-14-000165:notes:133]
As of December 31, 2013 the Company had $1.4 million of restricted cash included in current assets, and $4.9 million of restricted cash included in long-term assets. These amounts included in restricted cash represent deposits to secure letters of credit for various supply contracts. These deposits are held in interest bearing accounts.

[0001564590-14-000165:notes:134]
As of December 31, 2013, the Company had one performance bond in support of customer contracts. The total value of the outstanding performance bond is $0.2 million with an expiration date of March 2014. In the event that the payment is made in accordance with the requirements of any of these performance bonds, the Company would record the payment as an offset to revenue.

[0001564590-14-000165:notes:135]
The Company had an unused, unsecured line of credit consisting of €2.7 million (approximately $3.7 million) in Austria as of December 31, 2013.


## us-gaap:EquityMethodInvestmentsDisclosureTextBlock

[0001564590-14-000165:notes:136]
14. Minority Investments

[0001564590-14-000165:notes:137]
Investment in Tres Amigas LLC

[0001564590-14-000165:notes:138]
On October 9, 2009, the Company made an investment in Tres Amigas LLC, a Delaware limited liability company (“Tres Amigas”), focused on providing the first common interconnection of America’s three power grids to help the country achieve its renewable energy goals and facilitate the smooth, reliable and efficient transfer of green power from region to region, for $1.8 million, consisting of $0.8 million in cash and $1.0 million in AMSC common stock. On January 6, 2011 and May 20, 2011, the Company increased its minority position in Tres Amigas by investing an additional $1.8 million in cash on each date. As of December 31, 2013, the Company holds a 26% ownership interest in Tres Amigas.

[0001564590-14-000165:notes:139]
The Company has determined that Tres Amigas is a variable interest entity (“VIE”) and that the Company is not the primary beneficiary of the VIE.  Therefore, the Company has not consolidated Tres Amigas as of December 31, 2013.  The investment is carried at acquisition cost, plus the Company’s equity in undistributed earnings or losses.  The Company’s maximum exposure to loss is limited to the Company’s recorded investment in this VIE.  The Company’s investment in Tres Amigas is included in other assets on the consolidated balance sheet and the equity in undistributed losses of Tres Amigas is included in other expense, net, on the unaudited condensed consolidated statements of operations.

[0001564590-14-000165:notes:140]
The net investment activity for the nine months ended December 31, 2013 is as follows (in thousands):

[0001564590-14-000165:notes:141]
| Balance at April 1, 2013 | $ | 2,853 |  |
| Minority interest in net losses |  | (789 | ) |
| Balance at December 31, 2013 | $ | 2,064 |  |

[0001564590-14-000165:notes:142]
[same as prior period, unchanged from 0001564590-13-001183:notes:132]

[0001564590-14-000165:notes:143]
On August 12, 2010, the Company acquired (through its Austrian subsidiary), a minority ownership position in Blade Dynamics Ltd. (“Blade Dynamics”), a designer and manufacturer of advanced wind turbine blades based on proprietary materials and structural technologies, for $8.0 million in cash. As of December 31, 2013, the Company holds a 19% ownership interest in Blade Dynamics.

[0001564590-14-000165:notes:144]
[same as prior period, unchanged from 0001564590-13-001183:notes:134]

[0001564590-14-000165:notes:145]
| Balance at April 1, 2013 | $ | 4,611 |  |
| Net foreign exchange rate impact |  | 342 |  |
| Balance at December 31, 2013 | $ | 4,953 |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001564590-14-000165:notes:146]
15. Business Segments

[0001564590-14-000165:notes:147]
[same as prior period, unchanged from 0001564590-13-001183:notes:137]

[0001564590-14-000165:notes:148]
Through its Windtec Solutions, the Wind business segment enables manufacturers to field wind turbines with highly competitive power output, reliability and affordability. The Company supplies advanced power electronics and control systems, licenses its highly engineered wind turbine designs, and provides extensive customer support services to wind turbine manufacturers. Its design portfolio includes a broad range of drive trains and power ratings. It provides a broad range of power electronics and software-based control systems that are highly integrated and designed for optimized performance, efficiency, and grid compatibility.

[0001564590-14-000165:notes:149]
[same as prior period, unchanged from 0001564590-13-001183:notes:139]

[0001564590-14-000165:notes:150]
[same as prior period, unchanged from 0001564590-13-001183:notes:140]

[0001564590-14-000165:notes:151]
|  | Three months ended |  |  | Nine months ended |  |
|  | December 31, |  |  | December 31, |  |
|  | 2013 |  |  | 2012 |  |  | 2013 |  |  | 2012 |  |
| Revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Wind | $ | 13,545 |  |  | $ | 6,808 |  |  | $ | 42,937 |  |  | $ | 35,321 |  |
| Grid |  | 7,018 |  |  |  | 10,609 |  |  |  | 24,893 |  |  |  | 31,679 |  |
| Total | $ | 20,563 |  |  | $ | 17,417 |  |  | $ | 67,830 |  |  | $ | 67,000 |  |

[0001564590-14-000165:notes:152]
|  | Three months ended |  |  | Nine months ended |  |
|  | December 31, |  |  | December 31, |  |
|  | 2013 |  |  | 2012 |  |  | 2013 |  |  | 2012 |  |
| Operating (loss) income: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Wind | $ | 1,067 |  |  | $ | (5,365 | ) |  | $ | (3,207 | ) |  | $ | (10,514 | ) |
| Grid |  | (4,670 | ) |  |  | (6,705 | ) |  |  | (15,287 | ) |  |  | (18,620 | ) |
| Unallocated corporate expenses |  | (3,072 | ) |  |  | (8,546 | ) |  |  | (8,058 | ) |  |  | (12,580 | ) |
| Total | $ | (6,675 | ) |  | $ | (20,616 | ) |  | $ | (26,552 | ) |  | $ | (41,714 | ) |

[0001564590-14-000165:notes:153]
[same as prior period, unchanged from 0001564590-13-001183:notes:143]

[0001564590-14-000165:notes:154]
Unallocated corporate expenses primarily consist of stock-based compensation expense of $3.0 million and $7.3 million, and restructuring and impairment charges of $0.1 million and $0.9 million, for the three and nine months ended December 31, 2013, respectively. Unallocated corporate expenses primarily consist of stock-based compensation expense of $1.9 million and $6.0 million, respectively, and restructuring and impairment charges of $6.7 million and $6.8 million, respectively, for the three and nine months ended December 31, 2012, respectively.

[0001564590-14-000165:notes:155]
[same as prior period, unchanged from 0001564590-13-001183:notes:145]

[0001564590-14-000165:notes:156]
|  | December 31, |  |  | March 31, |  |
|  | 2013 |  |  | 2013 |  |
| Wind | $ | 52,351 |  |  | $ | 67,111 |  |
| Grid |  | 58,354 |  |  |  | 72,800 |  |
| Corporate assets |  | 67,666 |  |  |  | 76,843 |  |
| Total | $ | 178,371 |  |  | $ | 216,754 |  |

[0001564590-14-000165:notes:157]
The following table sets forth customers who represented 10% or more of the Company’s total revenues for the three and nine months ended December 31, 2013 and 2012:

[0001564590-14-000165:notes:158]
|  | Three months ended |  |  | Nine months ended |  |
|  | December 31, |  |  | December 31, |  |
|  | 2013 |  |  | 2012 |  |  | 2013 |  |  | 2012 |  |
| INOX Wind Limited |  | 35 | % |  |  | 19 | % |  |  | 25 | % |  |  | 17 | % |
| CSR Zhuzhou Institute Co., Ltd |  | 18 | % |  | — | % |  | <10 | % |  | <10 | % |
| Beijing JINGCHENG New Energy Co., Ltd. | <10 | % |  | <10 | % |  |  | 22 | % |  |  | 17 | % |
| CG Power Solutions UK Ltd | — | % |  |  | 21 | % |  | <10 | % |  | <10 | % |
| E.ON Climate & Renewables | <10 | % |  |  | 19 | % |  | <10 | % |  | <10 | % |


## us-gaap:NewAccountingPronouncementsAndChangesInAccountingPrinciplesTextBlock

[0001564590-14-000165:notes:159]
16. Recent Accounting Pronouncements

[0001564590-14-000165:notes:160]
In January 2013, the Financial Accounting Standards Board (FASB) issued Accounting Standards Update (ASU) No. 2013-01, Balance Sheet (Topic 210): Clarifying the Scope of Disclosures about Offsetting Assets and Liabilities (ASU 2013-01). The main objective in developing this update is to address implementation issues about the scope of Accounting Standards Update No. 2011-11, Balance Sheet (Topic 210): Disclosures about Offsetting Assets and Liabilities. The update requires entities to disclose information about offsetting and related arrangements of financial instruments and derivative instruments. ASU 2013-01 is effective for our first quarter of fiscal 2013. The Company adopted ASU 2013-01 and it did not have a material impact on the Company’s consolidated results of operations, financial condition, or cash flows.

[0001564590-14-000165:notes:161]
In February 2013, the FASB issued ASU No. 2013-02, Comprehensive Income (Topic 220): Reporting of Amounts Reclassified Out of Accumulated Other Comprehensive Income (ASU 2013-02). The amendments of this ASU require an entity to provide information about the amounts reclassified out of accumulated other comprehensive income (“AOCI”) by component. In addition, an entity is required to present, either on the face of the statement where net income (loss) is presented or in the notes, significant amounts reclassified out of AOCI by the respective line items of net income but only if the amount reclassified is required under U.S. GAAP to be reclassified to net income in its entirety in the same reporting period. For other amounts that are not required under U.S. GAAP to be reclassified in their entirety to net income, an entity is required to cross-reference to other disclosures required under U.S. GAAP that provide additional detail about those amounts. ASU 2013-02 is effective for fiscal years and interim periods beginning after December 15, 2012. The Company adopted ASU 2013-02 and it did not have a material impact on the Company’s consolidated results of operations, financial condition, or cash flows.

[0001564590-14-000165:notes:162]
In March 2013, the FASB issued ASU No. 2013-05, Foreign Currency Matters (Topic 830): Parent’s Accounting for the Cumulative Translation Adjustment upon Derecognition of Certain Subsidiaries or Groups of Assets within a Foreign Entity or of an Investment in a Foreign Entity (ASU 2013-05). The objective of the amendments in this update is to resolve the diversity in practice about whether Subtopic 810-10, Consolidation—Overall, or Subtopic 830-30, Foreign Currency Matters—Translation of Financial Statements, applies to the release of the cumulative translation adjustment into net income when a parent either sells a part or all of its investment in a foreign entity or no longer holds a controlling financial interest in a subsidiary or group of assets that is a nonprofit activity or a business (other than a sale of in substance real estate or conveyance of oil and gas mineral rights) within a foreign entity. In addition, the amendments in this Update resolve the diversity in practice for the treatment of business combinations achieved in involving a foreign entity. ASU 2013-05 is effective for fiscal years and interim periods beginning after December 15, 2013. The Company is currently evaluating the impact of ASU 2013-05, but currently does not believe there will be a significant impact on the Company’s consolidated results of operations, financial condition, or cash flows.

[0001564590-14-000165:notes:163]
In June 2013, the FASB issued ASU 2013-07, Liquidation Basis of Accounting, to require entities to begin preparing financial statements on a liquidation basis when liquidation is imminent. The guidance requires liquidation accounting when liquidation is imminent, unless an entity is outside the scope of the guidance or it is following a liquidation plan established at its inception. The guidance says liquidation is imminent when either, the party or parties with the authority to approve a liquidation plan do so or other forces (e.g., involuntary bankruptcy) impose a plan for liquidation, and the likelihood that the entity will return from liquidation is remote. The guidance also requires entities using the liquidation basis of accounting to measure their assets at the amount they expect to collect upon sale and liabilities are not remeasured to reflect any anticipation that the entity will be legally released from the obligation. ASU 2013-07 is effective for annual periods beginning after December 15, 2013. The Company is currently evaluating the impact of adopting ASU 2013-07, but currently does not believe there will be an impact on its consolidated results of operations, financial condition, or cash flows.

[0001564590-14-000165:notes:164]
In September 2013, the FASB issued ASU 2013-11, Income Taxes (Topic 740): Presentation of an Unrecognized Tax Benefit When a Net Operating Loss Carryforward, a Similar Tax Loss, or a Tax Credit Carryforward Exists. The guidance states that an unrecognized tax benefit, or a portion of an unrecognized tax benefit, should be presented in the financial statements as a reduction to a deferred tax asset for a net operating loss carryforward, a similar tax loss, or a tax credit carryforward, except as follows. To the extent a net operating loss carryforward, a similar tax loss, or a tax credit carryforward is not available at the reporting date under the tax law of the applicable jurisdiction to settle any additional income taxes that would result from the disallowance of a tax position or the tax law of the applicable jurisdiction does not require the entity to use, and the entity does not intend to use, the deferred tax asset for such purpose, the unrecognized tax benefit should be presented in the financial statements as a liability and should not be combined with deferred tax assets. This ASU applies to all entities that have unrecognized tax benefits when a net operating loss carryforward, a similar tax loss, or a tax credit carryforward exists at the reporting date. The amendments in this ASU are effective for fiscal years, and interim periods within those years, beginning after December 15, 2013. The Company is currently evaluating the impact of adopting ASU 2013-11, but currently does not believe there will be an impact on its consolidated results of operations, financial condition, or cash flow.

[0001564590-14-000165:notes:165]
The Company does not believe that other recently issued accounting pronouncements will have a material impact on its financial statements.


## us-gaap:SubsequentEventsTextBlock

[0001564590-14-000165:notes:166]
17. Subsequent Events

[0001564590-14-000165:notes:167]
The Company has performed an evaluation of subsequent events through the time of filing this Quarterly Report on Form 10-Q with the SEC, and has determined that there are no such events that are required to be disclosed.
