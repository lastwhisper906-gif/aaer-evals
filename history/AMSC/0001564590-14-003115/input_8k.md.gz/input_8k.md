# AMSC 8-K — 0001193125-14-294647 filed 2014-08-05

## item codes, every 8-K on or before 2014-08-05

- 2014-08-05 0001193125-14-294647 — 2.02, 9.01
- 2014-07-16 0001193125-14-269902 — 8.01
- 2014-06-23 0001193125-14-244592 — 3.02, 8.01
- 2014-06-05 0001193125-14-226459 — 2.02, 9.01
- 2014-06-05 0001193125-14-226457 — 1.01, 9.01
- 2014-03-19 0001193125-14-106558 — 2.05
- 2014-03-03 0001193125-14-078917 — 1.01, 3.02, 9.01
- 2014-02-28 0001193125-14-077480 — 8.01, 9.01
- 2014-02-06 0001193125-14-037960 — 2.02, 8.01, 9.01
- 2013-11-20 0001193125-13-447829 — 3.02, 8.01
- 2013-11-18 0001193125-13-444697 — 1.01, 2.03, 3.02, 9.01
- 2013-11-07 0001193125-13-431705 — 2.02, 9.01
- 2013-10-09 0001193125-13-395362 — 1.01, 2.03, 3.02, 9.01
- 2013-09-25 0001193125-13-378481 — 5.02, 9.01
- 2013-08-21 0001193125-13-341566 — 4.01, 9.01
- 2013-08-07 0001193125-13-323082 — 2.02, 9.01
- 2013-08-02 0001193125-13-317278 — 5.02, 5.07
- 2013-06-14 0001193125-13-258758 — 2.02, 9.01
- 2013-04-01 0001193125-13-136714 — 2.02, 8.01, 9.01
- 2013-02-20 0001193125-13-067218 — 5.02, 9.01
- 2013-02-14 0001193125-13-060131 — 1.01, 9.01
- 2013-02-11 0001193125-13-048784 — 2.02, 9.01
- 2013-01-08 0001193125-13-006861 — 5.02, 9.01
- 2012-12-21 0001193125-12-511592 — 1.01, 2.03, 3.02, 9.01
- 2012-11-28 0001193125-12-483317 — 2.05, 5.02, 7.01, 9.01
- 2012-11-06 0001193125-12-453359 — 2.02, 9.01
- 2012-08-02 0001193125-12-330534 — 2.02, 9.01
- 2012-07-27 0001193125-12-318790 — 5.02, 5.07, 9.01
- 2012-06-06 0001193125-12-261030 — 1.01, 2.02, 2.03, 3.02, 5.02, 9.01
- 2012-05-09 0001193125-12-222210 — 5.02
- 2012-04-20 0001193125-12-172045 — 8.01
- 2012-04-13 0001193125-12-162694 — 2.02, 8.01, 9.01
- 2012-04-04 0001193125-12-149102 — 1.01, 2.02, 2.03, 3.02, 9.01
- 2012-02-09 0001193125-12-048009 — 2.02, 9.01
- 2012-02-06 0001193125-12-041344 — 5.07 — amendment of 0000950123-11-102495
- 2011-12-08 0000950123-11-102495 — 5.07
- 2011-11-29 0000950123-11-100822 — 2.05
- 2011-11-09 0000950123-11-096775 — 2.02, 9.01
- 2011-10-31 0000950123-11-093390 — 1.02, 9.01
- 2011-10-07 0000950123-11-089221 — 8.01
- 2011-10-03 0000950123-11-088315 — 7.01
- 2011-09-23 0000950123-11-086288 — 2.02, 9.01
- 2011-09-15 0000950123-11-084585 — 7.01
- 2011-09-06 0000950123-11-082736 — 7.01
- 2011-08-18 0000950123-11-078526 — 3.01, 7.01, 9.01
- 2011-08-11 0000950123-11-075905 — 5.02
- 2011-08-11 0000950123-11-075904 — 2.02, 2.05, 9.01
- 2011-07-11 0000950123-11-064934 — 2.02, 4.02, 9.01
- 2011-06-30 0000950123-11-063287 — 1.01, 3.02, 9.01
- 2011-06-21 0000950123-11-060491 — 3.01, 7.01, 9.01
- 2011-06-13 0000950123-11-058656 — 1.01, 9.01
- 2011-05-24 0000950123-11-053517 — 5.02, 9.01
- 2011-04-05 0001299933-11-001020 — 2.02, 9.01
- 2011-03-15 0000950123-11-025580 — 5.02
- 2011-03-14 0000950123-11-025205 — 1.01, 3.02, 9.01
- 2011-02-01 0001299933-11-000333 — 2.02, 9.01
- 2010-11-12 0000950123-10-104604 — 8.01, 9.01
- 2010-11-08 0000950123-10-102424 — 8.01, 9.01
- 2010-11-02 0001299933-10-003878 — 2.02, 9.01
- 2010-09-15 0000950123-10-086373 — 1.01, 9.01 — amendment, the index does not say of what
- 2010-08-06 0000950123-10-074362 — 5.07
- 2010-07-29 0001299933-10-002860 — 2.02, 9.01
- 2010-05-17 0000950123-10-050424 — 1.01, 9.01
- 2010-05-14 0001299933-10-001972 — 5.02
- 2010-05-13 0001299933-10-001943 — 2.02, 9.01
- 2010-02-08 0001299933-10-000506 — 8.01
- 2010-02-02 0001299933-10-000386 — 2.02, 9.01
- 2009-12-15 0001299933-09-004928 — 5.02
- 2009-10-29 0001299933-09-004267 — 2.02, 9.01
- 2009-08-12 0001193125-09-173026 — 5.02, 9.01
- 2009-07-30 0001193125-09-158842 — 1.01, 2.02, 9.01
- 2009-05-15 0001193125-09-113158 — 5.02
- 2009-05-14 0001193125-09-110619 — 2.02, 9.01
- 2009-04-20 0001193125-09-082590 — 5.02
- 2009-02-03 0001193125-09-016992 — 2.02, 9.01
- 2009-01-22 0001193125-09-009777 — 2.02, 9.01
- 2008-11-04 0001193125-08-223730 — 2.02, 9.01
- 2008-08-11 0001193125-08-173616 — 8.01
- 2008-08-07 0001193125-08-170325 — 8.01
- 2008-08-05 0001193125-08-165888 — 2.02, 9.01
- 2008-06-11 0001193125-08-132049 — 1.01, 9.01
- 2008-05-20 0001193125-08-119372 — 5.02, 9.01
- 2008-05-08 0001193125-08-107052 — 2.02, 9.01
- 2008-01-31 0001193125-08-016233 — 2.02, 9.01
- 2008-01-30 0001193125-08-015494 — 5.03, 9.01
- 2007-11-01 0001193125-07-231866 — 2.02, 9.01
- 2007-10-31 0001193125-07-231225 — 2.05
- 2007-10-29 0001193125-07-228284 — 5.03, 9.01
- 2007-09-27 0001193125-07-208950 — 5.02
- 2007-08-09 0001193125-07-176553 — 2.02, 9.01
- 2007-08-07 0001193125-07-173829 — 1.01, 5.02, 9.01
- 2007-07-02 0001193125-07-148303 — 5.02, 9.01
- 2007-06-20 0001193125-07-139068 — 8.01, 9.01
- 2007-06-14 0001193125-07-135550 — 9.01 — amendment of 0001193125-07-005297
- 2007-06-14 0001193125-07-135340 — 5.02
- 2007-05-24 0001193125-07-122148 — 2.02, 9.01
- 2007-03-30 0001193125-07-070154 — 2.05, 9.01
- 2007-03-23 0001193125-07-062978 — 9.01 — amendment of 0001193125-07-005297
- 2007-02-01 0001193125-07-017883 — 2.02, 9.01
- 2007-01-11 0001193125-07-005297 — 2.01, 9.01
- 2006-12-05 0001181431-06-067500 — 5.02
- 2006-11-29 0001193125-06-243360 — 1.01, 3.02, 9.01
- 2006-11-02 0001193125-06-221464 — 2.02, 9.01
- 2006-09-21 0001193125-06-194526 — 5.02
- 2006-08-08 0001193125-06-164819 — 2.02, 9.01
- 2006-08-02 0001193125-06-159113 — 1.01, 9.01
- 2006-07-28 0001193125-06-156172 — 1.01
- 2006-06-26 0001193125-06-135913 — 1.01, 3.03, 9.01
- 2006-05-11 0001193125-06-108489 — 2.02, 9.01
- 2006-05-05 0001193125-06-102270 — 1.01, 9.01
- 2006-05-01 0001193125-06-094941 — 2.02, 2.06, 9.01
- 2006-02-24 0001193125-06-038281 — 5.02, 9.01
- 2006-02-02 0001181431-06-007665 — 2.02, 9.01
- 2005-11-09 0001181431-05-060304 — 2.02, 9.01
- 2005-08-04 0001181431-05-044420 — 2.02, 9.01
- 2005-07-28 0001193125-05-151272 — 5.02, 9.01
- 2005-06-14 0001193125-05-125148 — 5.02, 9.01
- 2005-05-12 0001181431-05-027410 — 2.02, 9.01
- 2005-05-10 0001193125-05-102795 — 1.01
- 2005-04-05 0001181431-05-020680 — 1.01, 2.02, 3.02, 9.01
- 2005-02-03 0001181431-05-006678 — 2.02, 9.01
- 2004-11-09 0001181431-04-051381 — 2.02, 9.01 — amendment, the index does not say of what
- 2004-11-04 0001181431-04-050706 — 2.02, 9.01
- 2004-10-15 0001193125-04-172458 — 1.01, 9.01
- 2004-08-05 0001193125-04-132162 — 12
- 2004-05-13 0001193125-04-086853 — 12
- 2004-02-05 0001193125-04-015060 — 12
- 2003-11-06 0001193125-03-074000 — 12
- 2003-09-26 0001193125-03-054624 — 5
- 2003-08-06 0001193125-03-029666 — 12
- 2003-05-14 0000927016-03-002619 — 9
- 2002-12-31 0000927016-02-006114 — 5
- 2000-01-24 0000927016-00-000150 — 5, 7
- 1998-11-02 0000950135-98-005625 — 5, 7
- 1998-03-24 0000950135-98-001743 — 5, 7
- 1997-09-05 0000950135-97-003729 — 5, 7
- 1997-06-23 0000950135-97-002785 — 1 — amendment of 0000950135-97-001972
- 1997-04-23 0000950135-97-001972 — 2, 7

## late-filing notifications on or before 2014-08-05

- 2011-08-10 0000950123-11-075677 — NT 10-Q, for the period ended 2011-06-30
- 2011-05-31 0000950123-11-055465 — NT 10-K, for the period ended 2011-03-31

## item 2.02 — earnings release, exhibit 99.1

[0001193125-14-294647:8k_2_02:1]
EX-99.1
2
d767614dex991.htm
EX-99.1

[0001193125-14-294647:8k_2_02:2]
EX-99.1

[0001193125-14-294647:8k_2_02:3]
Exhibit 99.1

[0001193125-14-294647:8k_2_02:4]
AMSC Reports First Quarter

[0001193125-14-294647:8k_2_02:5]
Fiscal 2014 Financial Results and Provides Business Outlook

[0001193125-14-294647:8k_2_02:6]
Company to host conference call today at 10:00 am ET

[0001193125-14-294647:8k_2_02:7]
Devens, MA – August 5, 2014 – AMSC (NASDAQ: AMSC), a global solutions provider serving wind and power grid industry leaders, today
reported financial results for its first quarter of fiscal 2014 ended June 30, 2014.

[0001193125-14-294647:8k_2_02:8]
Revenues for the first quarter of fiscal 2014 were $11.7
million, compared with $23.1 million for the same period of fiscal 2013. The year over year decrease in revenues was due primarily to lower D-VAR revenues in the Company’s Grid segment and lower revenues in the Company’s Wind segment due
to lower revenue from customers in China.

[0001193125-14-294647:8k_2_02:9]
AMSC’s net loss for the first quarter of fiscal 2014 increased to $13.5 million, or $0.17 per share, from
$10.5 million, or $0.18 per share, for the same period of fiscal 2013.

[0001193125-14-294647:8k_2_02:10]
The Company’s non-GAAP net loss for the first quarter of fiscal 2014 was
$11.9 million, or $0.15 per share, compared with a non-GAAP net loss of $8.1 million, or $0.14 per share, in the same period of fiscal 2013. Please refer to the financial table below for a reconciliation of GAAP to non-GAAP results.

[0001193125-14-294647:8k_2_02:11]
Cash, cash equivalents, and restricted cash at June 30, 2014 totaled $42.8 million, compared with $49.4 million at March 31, 2014. During the first
quarter of fiscal 2014, the Company received net proceeds under its At-Market Sales Facility (ATM), after deducting sales commissions, of $1.2 million from the issuance of approximately 800,000 shares of common stock at an average sales price of
$1.63 per share.

[0001193125-14-294647:8k_2_02:12]
“We are focused on building the foundation required for growth in 2015 and beyond. At the same time, we have maintained the fiscal
discipline to control our expenses,” said Daniel P. McGahn, President and CEO, AMSC. “In June, we announced a major order from Inox Wind for turbine electrical control systems (ECS). In July, we announced a contract with the Department of
Homeland Security to deploy AMSC’s Resilient Electric Grid System into an urban electric grid in the United States. ComEd, Chicago’s electric utility, agreed to be a lead utility in this program. We believe that these developments position
us for growth in 2015 and beyond.”

[0001193125-14-294647:8k_2_02:13]
Business Outlook

[0001193125-14-294647:8k_2_02:14]
For the second quarter ending September 30, 2014, AMSC expects that its revenues will be flat to slightly higher sequentially. The Company’s net loss
for the second quarter of fiscal 2014 is expected to be less than $15.5 million, or $0.19 per share. A less favorable product mix is expected to result in a sequentially higher net loss. AMSC expects that its non-GAAP net loss (as defined below) for
the second quarter of fiscal 2014 will be less than $13.0 million, or $0.16 per share. For the full fiscal year 2014, the Company continues to expect revenues to be down slightly compared to fiscal 2013.

[0001193125-14-294647:8k_2_02:15]
| AMSC Reports Q1 Results |  | Page 2 |

[0001193125-14-294647:8k_2_02:16]
Conference Call Reminder

[0001193125-14-294647:8k_2_02:17]
In conjunction with this announcement, AMSC management will participate in a conference call with investors beginning at 10:00 a.m. Eastern Time today to
discuss the Company’s results and its business outlook. Those who wish to listen to the live or archived conference call webcast should visit the “Investors” section of the Company’s website at
http://www.amsc.com/investors. The live call also can be accessed by dialing 785-830-7980 and using conference ID 1872553.

[0001193125-14-294647:8k_2_02:18]
About AMSC
(NASDAQ: AMSC)

[0001193125-14-294647:8k_2_02:19]
AMSC generates the ideas, technologies and solutions that meet the world’s demand for smarter, cleaner … better
energy™. Through its Windtec™ Solutions, AMSC provides wind turbine electronic controls and systems, designs and engineering services that reduce the cost of wind energy. Through its Gridtec™ Solutions, AMSC provides the engineering
planning services and advanced grid systems that optimize network reliability, efficiency and performance. The Company’s solutions are now powering gigawatts of renewable energy globally and are enhancing the performance and reliability of
power networks in more than a dozen countries. Founded in 1987, AMSC is headquartered near Boston, Massachusetts with operations in Asia, Australia, Europe and North America. For more information, please visit www.amsc.com.

[0001193125-14-294647:8k_2_02:20]
AMSC, Windtec, Gridtec, and Smarter, Cleaner … Better Energy are trademarks or registered trademarks of American Superconductor Corporation. All other
brand names, product names, trademarks or service marks belong to their respective holders.

[0001193125-14-294647:8k_2_02:21]
Forward-Looking Statements

[0001193125-14-294647:8k_2_02:22]
| AMSC Reports Q1 Results |  | Page 3 |

[0001193125-14-294647:8k_2_02:23]
subcontractors and other business collaborators; If we fail to implement our business strategy successfully, our financial performance could be harmed; Problems with product quality or product
performance may cause us to incur warranty expenses and may damage our market reputation and prevent us from achieving increased sales and market share; New regulations related to conflict-free minerals may force us to incur significant additional
expenses; Our contracts with the U.S. government are subject to audit, modification or termination by the U.S. government and include certain other provisions in favor of the government. The continued funding of such contracts remains subject to
annual congressional appropriation which, if not approved, could reduce our revenue and lower or eliminate our profit; Many of our customers outside of the United States are, either directly or indirectly, related to governmental entities, and we
could be adversely affected by violations of the United States Foreign Corrupt Practices Act and similar worldwide anti-bribery laws outside the United States; We have limited experience in marketing and selling our superconductor products and
system-level solutions, and our failure to effectively market and sell our products and solutions could lower our revenue and cash flow; We may acquire additional complementary businesses or technologies, which may require us to incur substantial
costs for which we may never realize the anticipated benefits; Our success depends upon the commercial use of high temperature superconductor (HTS) products, which is currently limited, and a widespread commercial market for our products may not
develop; Growth of the wind energy market depends largely on the availability and size of government subsidies and economic incentives; We have operations in and depend on sales in emerging markets, including China and India, and global conditions
could negatively affect our operating results or limit our ability to expand our operations outside of these countries. Changes in China’s or India’s political, social, regulatory and economic environment may affect our financial
performance; Our products face intense competition, which could limit our ability to acquire or retain customers; Our international operations are subject to risks that we do not face in the United States, which could have an adverse effect on our
operating results; Adverse changes in domestic and global economic conditions could adversely affect our operating results; We may be unable to adequately prevent disclosure of trade secrets and other proprietary information; Our patents may not
provide meaningful protection for our technology, which could result in us losing some or all of our market position; There are a number of technological challenges that must be successfully addressed before our superconductor products can gain
widespread commercial acceptance, and our inability to address such technological challenges could adversely affect our ability to acquire customers for our products; We have not manufactured our Amperium wire in commercial quantities, and a failure
to manufacture our Amperium wire in commercial quantities at acceptable cost and quality levels would substantially limit our future revenue and profit potential; Third parties have or may acquire patents that cover the materials, processes and
technologies we use or may use in the future to manufacture our Amperium products, and our success depends on our ability to license such patents or other proprietary rights; Our technology and products could infringe intellectual property rights of
others, which may require costly litigation and, if we are not successful, could cause us to pay substantial damages and disrupt our business; We have filed a demand for arbitration and other lawsuits against our former largest customer, Sinovel,
regarding amounts we contend are overdue. We cannot be certain as to the outcome of these proceedings; We have been named as a party in various legal proceedings, and we may be named in additional litigation, all of which will require significant
management time and attention, result in significant legal expenses and may result in an unfavorable outcome, which could have a material adverse effect on our business, operating results and financial condition; Our common stock has experienced,
and may continue to experience, significant market price and volume fluctuations, which may prevent our stockholders from selling our common stock at a profit and could lead to costly litigation against us that could divert our management’s
attention.

[0001193125-14-294647:8k_2_02:24]
These and the important factors discussed under the caption “Risk Factors” in Part 1. Item 1A of our Form 10-K for the
fiscal year ended March 31, 2014, and our other reports filed with the SEC, among others, could cause actual results to differ materially from those indicated by forward-looking statements made herein and presented elsewhere by management from
time to time. Any such forward-looking statements represent management’s estimates as of the date of this press release. While we may elect to update such forward-looking statements at some point in the future, we disclaim any obligation to do
so, even if subsequent events cause our views to change. These forward-looking statements should not be relied upon as representing our views as of any date subsequent to the date of this press release.

[0001193125-14-294647:8k_2_02:25]
| AMSC Reports Q1 Results |  | Page 4 |

[0001193125-14-294647:8k_2_02:26]
UNAUDITED CONSOLIDATED STATEMENTS OF OPERATIONS

[0001193125-14-294647:8k_2_02:27]
(In thousands, except per share data)

[0001193125-14-294647:8k_2_02:28]
|  |  | Three months ended |  |
|  |  | June 30, |  |
|  |  | 2014 |  |  | 2013 |  |
| Revenues |  |  |  |  |  |  |  |  |
| Wind |  | $ | 7,650 |  |  | $ | 14,701 |  |
| Grid |  |  | 4,046 |  |  |  | 8,385 |  |
| Total Revenues |  |  | 11,696 |  |  |  | 23,086 |  |
| Cost of revenues |  |  | 12,087 |  |  |  | 17,987 |  |
| Gross (loss) profit |  |  | (391 | ) |  |  | 5,099 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |
| Research and development |  |  | 3,120 |  |  |  | 3,027 |  |
| Selling, general and administrative |  |  | 7,938 |  |  |  | 10,827 |  |
| Restructuring and impairments |  |  | 1,179 |  |  |  | 13 |  |
| Amortization of acquisition related intangibles |  |  | 39 |  |  |  | 82 |  |
| Total operating expenses |  |  | 12,276 |  |  |  | 13,949 |  |
| Operating loss |  |  | (12,667 | ) |  |  | (8,850 | ) |
| Change in fair value of derivatives and warrants |  |  | (35 | ) |  |  | 469 |  |
| Interest expense, net |  |  | (535 | ) |  |  | (2,111 | ) |
| Other (expense) income, net |  |  | (152 | ) |  |  | 69 |  |
| Loss before income tax expense |  |  | (13,389 | ) |  |  | (10,423 | ) |
| Income tax expense |  |  | 128 |  |  |  | 90 |  |
| Net loss |  | $ | (13,517 | ) |  | $ | (10,513 | ) |
| Net loss per common share |  |  |  |  |  |  |  |  |
| Basic |  | $ | (0.17 | ) |  | $ | (0.18 | ) |
| Diluted |  | $ | (0.17 | ) |  | $ | (0.18 | ) |
| Weighted average number of common shares outstanding |  |  |  |  |  |  |  |  |
| Basic |  |  | 77,688 |  |  |  | 58,300 |  |
| Diluted |  |  | 77,688 |  |  |  | 58,300 |  |

[0001193125-14-294647:8k_2_02:29]
| AMSC Reports Q1 Results |  | Page 5 |

[0001193125-14-294647:8k_2_02:30]
UNAUDITED CONSOLIDATED BALANCE SHEETS

[0001193125-14-294647:8k_2_02:31]
(In thousands)

[0001193125-14-294647:8k_2_02:32]
|  |  | June 30, |  |  | March 31, |  |
|  |  | 2014 |  |  | 2014 |  |
| ASSETS |  |  |  |  |  |  |  |  |
| Current assets: |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 36,624 |  |  | $ | 43,114 |  |
| Accounts receivable, net |  |  | 10,290 |  |  |  | 7,556 |  |
| Inventory |  |  | 19,408 |  |  |  | 20,694 |  |
| Prepaid expenses and other current assets |  |  | 8,544 |  |  |  | 9,004 |  |
| Restricted cash |  |  | 6,099 |  |  |  | 2,913 |  |
| Total current assets |  |  | 80,965 |  |  |  | 83,281 |  |
| Property, plant and equipment, net |  |  | 62,516 |  |  |  | 64,574 |  |
| Intangibles, net |  |  | 1,851 |  |  |  | 1,995 |  |
| Restricted cash |  |  | 100 |  |  |  | 3,394 |  |
| Deferred tax assets |  |  | 7,724 |  |  |  | 7,724 |  |
| Other assets |  |  | 7,402 |  |  |  | 7,541 |  |
| Total assets |  | $ | 160,558 |  |  | $ | 168,509 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |  |  |  |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |  |  |  |
| Accounts payable and accrued expenses |  | $ | 19,037 |  |  | $ | 21,764 |  |
| Note payable, current portion, net of discount of $447 as of June 30, 2014 and $555 as of March 31, 2014 |  |  | 5,906 |  |  |  | 6,240 |  |
| Derivative liabilities |  |  | 2,636 |  |  |  | 2,601 |  |
| Deferred revenue |  |  | 14,519 |  |  |  | 9,456 |  |
| Deferred tax liabilities |  |  | 7,759 |  |  |  | 7,761 |  |
| Total current liabilities |  |  | 49,857 |  |  |  | 47,822 |  |
| Note Payable, net of current portion and discount of $205 as of June 30, 2014 and $287 as of March 31, 2014 |  |  | 5,461 |  |  |  | 6,380 |  |
| Deferred revenue |  |  | 1,755 |  |  |  | 990 |  |
| Other liabilities |  |  | 1,023 |  |  |  | 1,058 |  |
| Total liabilities |  |  | 58,096 |  |  |  | 56,250 |  |
| Stockholders’ equity: |  |  |  |  |  |  |  |  |
| Common stock |  |  | 816 |  |  |  | 789 |  |
| Additional paid-in capital |  |  | 970,553 |  |  |  | 966,390 |  |
| Treasury stock |  |  | (739 | ) |  |  | (370 | ) |
| Accumulated other comprehensive loss |  |  | 1,738 |  |  |  | 1,839 |  |
| Accumulated deficit |  |  | (869,906 | ) |  |  | (856,389 | ) |
| Total stockholders’ equity |  |  | 102,462 |  |  |  | 112,259 |  |
| Total liabilities and stockholders’ equity |  | $ | 160,558 |  |  | $ | 168,509 |  |

[0001193125-14-294647:8k_2_02:33]
| AMSC Reports Q1 Results |  | Page 6 |

[0001193125-14-294647:8k_2_02:34]
UNAUDITED CONSOLIDATED STATEMENTS OF CASH FLOWS

[0001193125-14-294647:8k_2_02:35]
(In thousands)

[0001193125-14-294647:8k_2_02:36]
|  |  | Three months ended June 30, |  |
|  |  | 2014 |  |  | 2013 |  |
| Cash flows from operating activities: |  |  |  |  |  |  |  |  |
| Net loss |  | $ | (13,517 | ) |  | $ | (10,513 | ) |
| Adjustments to reconcile net loss to net cash used in operations: |  |  |  |  |  |  |  |  |
| Depreciation and amortization |  |  | 2,475 |  |  |  | 2,655 |  |
| Stock-based compensation expense |  |  | 1,581 |  |  |  | 2,135 |  |
| Non-cash portion of restructuring charges |  |  | (44 | ) |  |  | (27 | ) |
| Provision for excess and obsolete inventory |  |  | 649 |  |  |  | 160 |  |
| Loss on minority interest investments |  |  | 202 |  |  |  | 248 |  |
| Change in fair value of derivatives and warrants |  |  | 35 |  |  |  | (469 | ) |
| Non-cash interest expense |  |  | 190 |  |  |  | 1,672 |  |
| Other non-cash items |  |  | 93 |  |  |  | 686 |  |
| Changes in operating asset and liability accounts: |  |  |  |  |  |  |  |  |
| Accounts receivable |  |  | (2,741 | ) |  |  | 8,111 |  |
| Inventory |  |  | 623 |  |  |  | 2,861 |  |
| Prepaid expenses and other current assets |  |  | 441 |  |  |  | (1,151 | ) |
| Accounts payable and accrued expenses |  |  | (1,344 | ) |  |  | (5,464 | ) |
| Deferred revenue |  |  | 5,851 |  |  |  | (10,211 | ) |
| Net cash used in operating activities |  |  | (5,506 | ) |  |  | (9,307 | ) |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |
| Net cash (used in) provided by investing activities |  |  | (267 | ) |  |  | 3,774 |  |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |
| Net cash used in financing activities |  |  | (633 | ) |  |  | (1,211 | ) |
| Effect of exchange rate changes on cash and cash equivalents |  |  | (84 | ) |  |  | 109 |  |
| Net decrease in cash and cash equivalents |  |  | (6,490 | ) |  |  | (6,635 | ) |
| Cash and cash equivalents at beginning of year |  |  | 43,114 |  |  |  | 39,243 |  |
| Cash and cash equivalents at end of period |  | $ | 36,624 |  |  | $ | 32,608 |  |

[0001193125-14-294647:8k_2_02:37]
| AMSC Reports Q1 Results |  | Page 7 |

[0001193125-14-294647:8k_2_02:38]
RECONCILIATION OF GAAP NET INCOME (LOSS) TO NON-GAAP NET INCOME (LOSS)

[0001193125-14-294647:8k_2_02:39]
(In thousands, except per share data)

[0001193125-14-294647:8k_2_02:40]
|  |  | Three months ended June 30, |  |
|  |  | 2014 |  |  | 2013 |  |
| Net loss |  | $ | (13,517 | ) |  | $ | (10,513 | ) |
| Stock-based compensation |  |  | 1,581 |  |  |  | 2,135 |  |
| Amortization of acquisition-related intangibles |  |  | 39 |  |  |  | 82 |  |
| Restructuring and impairment charges |  |  | 1,179 |  |  |  | 13 |  |
| Sinovel litigation |  |  | — |  |  |  | 107 |  |
| Consumption of zero cost-basis inventory |  |  | (1,372 | ) |  |  | (1,174 | ) |
| Change of fair value of derivatives and warrants |  |  | 35 |  |  |  | (469 | ) |
| Non-cash interest expense |  |  | 190 |  |  |  | 1,672 |  |
| Non-GAAP net loss |  | $ | (11,865 | ) |  | $ | (8,147 | ) |
| Non-GAAP loss per share |  | $ | (0.15 | ) |  | $ | (0.14 | ) |
| Weighted average shares outstanding |  |  | 77,688 |  |  |  | 58,300 |  |

[0001193125-14-294647:8k_2_02:41]
RECONCILIATION OF FORECAST GAAP NET LOSS TO NON-GAAP NET LOSS

[0001193125-14-294647:8k_2_02:42]
(In millions, except per share data)

[0001193125-14-294647:8k_2_02:43]
|  |  | Three months endingSeptember 30, 2014 |  |
| Net loss |  | $ | (15.5 | ) |
| Stock-based compensation |  |  | 2.2 |  |
| Restructuring and impairment charges |  |  | 1.0 |  |
| Non-cash interest expense |  |  | 0.2 |  |
| Consumption of zero-cost inventory |  |  | (0.9 | ) |
| Non-GAAP net loss |  | $ | (13.0 | ) |
| Non-GAAP net loss per share |  | $ | (0.16 | ) |
| Shares outstanding |  |  | 80.0 |  |

[0001193125-14-294647:8k_2_02:44]
Note: Non-GAAP net loss is defined by the Company as net loss before stock-based compensation; amortization of
acquisition-related intangibles; restructuring and impairment charges; Sinovel litigation costs; consumption of zero cost-basis inventory; non-cash interest expense; change in fair value of derivatives and warrants, and other unusual charges, net of
any tax effects related to these items. The Company believes non-GAAP net loss assists management and investors in comparing the Company’s performance across reporting periods on a consistent basis by excluding these non-cash, non-recurring or
other charges that it does not believe are indicative of its core operating performance. The Company also regards non-GAAP net loss as a useful measure of operating performance to complement operating loss, net loss and other GAAP financial
performance measures. In addition, the Company uses non-GAAP net loss as a factor in evaluating management’s performance when determining incentive compensation and to evaluate the effectiveness of its business strategies.

[0001193125-14-294647:8k_2_02:45]
| AMSC Reports Q1 Results |  | Page 8 |

[0001193125-14-294647:8k_2_02:46]
Generally, a non-GAAP financial measure is a numerical measure of a company’s performance, financial
position or cash flow that either excludes or includes amounts that are not normally excluded or included in the most directly comparable measure calculated and presented in accordance with GAAP. The non-GAAP measures included in this release,
however, should be considered in addition to, and not as a substitute for or superior to, operating income, cash flows, or other measures of financial performance prepared in accordance with GAAP. A reconciliation of non-GAAP to GAAP net loss is set
forth in the table above.

[0001193125-14-294647:8k_2_02:47]
AMSC Contact:

[0001193125-14-294647:8k_2_02:48]
Kerry
Farrell

[0001193125-14-294647:8k_2_02:49]
Phone: 978-842-3247

[0001193125-14-294647:8k_2_02:50]
Email: kerry.farrell @ amsc.com
