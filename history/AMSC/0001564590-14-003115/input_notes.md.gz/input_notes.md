# AMSC notes — 0001564590-14-003115


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001564590-14-003115:notes:1]
[same as prior period, unchanged from 0001564590-14-000165:notes:1]

[0001564590-14-003115:notes:2]
The Company accounts for its stock-based compensation at fair value. The following table summarizes stock-based compensation expense by financial statement line item for the three months ended June 30, 2014 and 2013 (in thousands):

[0001564590-14-003115:notes:3]
|  | Three months ended June 30, |  |
|  | 2014 |  |  | 2013 |  |
| Cost of revenues | $ | 153 |  |  | $ | 205 |  |
| Research and development |  | 479 |  |  |  | 575 |  |
| Selling, general and administrative |  | 949 |  |  |  | 1,355 |  |
| Total | $ | 1,581 |  |  | $ | 2,135 |  |

[0001564590-14-003115:notes:4]
During the three months ended June 30, 2014, the Company granted 1,000,000 stock options, and 972,336 restricted stock awards. There were 314,765 stock options granted during the three months ended June 30, 2013. These stock options vest over 5 years, and the restricted stock awards vest over one year. For options and awards that vest upon the passage of time, expense is being recorded over the vesting period.  Performance-based restricted stock awards are expensed over the requisite service period.

[0001564590-14-003115:notes:5]
The estimated fair value of the Company’s stock-based awards, less expected annual forfeitures, is amortized over the awards’ service period. The total unrecognized compensation cost for unvested outstanding stock options was $2.3 million at June 30, 2014. This expense will be recognized over a weighted average expense period of approximately 3.1 years. The total unrecognized compensation cost for unvested outstanding restricted stock was $2.1 million at June 30, 2014. This expense will be recognized over a weighted-average expense period of approximately 1.0 years.

[0001564590-14-003115:notes:6]
The weighted-average assumptions used in the Black-Scholes valuation model for stock options granted during the three months ended June 30, 2014 and 2013 are as follows:

[0001564590-14-003115:notes:7]
|  | Three months ended June 30, |  |
|  | 2014 |  |  | 2013 |  |
| Expected volatility |  | 85.5 | % |  |  | 74.6 | % |
| Risk-free interest rate |  | 1.9 | % |  |  | 1.7 | % |
| Expected life (years) |  | 5.8 |  |  |  | 5.9 |  |
| Dividend yield |  | None |  |  |  | None |  |

[0001564590-14-003115:notes:8]
The expected volatility rate was estimated based on an equal weighting of the historical volatility of the Company’s common stock and the implied volatility of the Company’s traded options. The expected term was estimated based on an analysis of the Company’s historical experience of exercise, cancellation, and expiration patterns. The risk-free interest rate is based on the average of the five and seven year United States Treasury rates.


## us-gaap:EarningsPerShareTextBlock

[0001564590-14-003115:notes:9]
[same as prior period, unchanged from 0001564590-14-000165:notes:9]

[0001564590-14-003115:notes:10]
Basic net loss per share (“EPS”) is computed by dividing net loss by the weighted-average number of common shares outstanding for the period. Where applicable, diluted EPS is computed by dividing the net loss by the weighted-average number of common shares and dilutive common equivalent shares outstanding during the period, calculated using the treasury stock method. Common equivalent shares include the effect of restricted stock, exercise of stock options and warrants and contingently issuable shares. For the three months ended June 30, 2014, 7.4 million shares were not included in the calculation of diluted EPS as they were considered anti-dilutive, of which 3.9 million relate to unexercised stock options, and 3.5 million relate to the issuance of warrants. For the three months ended June 30, 2013, 10.6 million shares were not included in the calculation of diluted EPS as they were considered anti-dilutive, of which 2.9 million relate to unvested stock options, 3.2 million relate to the issue of warrants and 4.5 million shares related to the convertible feature of the Company’s unsecured, senior convertible note (the “Exchanged Note”).

[0001564590-14-003115:notes:11]
The following table reconciles the numerators and denominators of the earnings per share calculation for the three months ended June 30, 2014 and 2013 (in thousands, except per share data):

[0001564590-14-003115:notes:12]
|  | Three months ended June 30, |  |
|  | 2014 |  |  |  | 2013 |  |
| Numerator: |  |  |  |  |  |  |  |  |
| Net loss | $ | (13,517 | ) |  | $ |  | (10,513 | ) |
| Denominator: |  |  |  |  |  |  |  |  |
| Weighted-average shares of common stock outstanding |  | 79,619 |  |  |  |  | 60,463 |  |
| Weighted-average shares subject to repurchase |  | (1,931 | ) |  |  |  | (2,163 | ) |
| Shares used in per-share calculation ― basic |  | 77,688 |  |  |  |  | 58,300 |  |
| Shares used in per-share calculation ― diluted |  | 77,688 |  |  |  |  | 58,300 |  |
| Net loss per share ― basic | $ | (0.17 | ) |  | $ |  | (0.18 | ) |
| Net loss per share ― diluted | $ | (0.17 | ) |  | $ |  | (0.18 | ) |


## us-gaap:FairValueDisclosuresTextBlock

[0001564590-14-003115:notes:13]
[same as prior period, unchanged from 0001564590-14-000165:notes:13]

[0001564590-14-003115:notes:14]
[same as prior period, unchanged from 0001564590-14-000165:notes:15]

[0001564590-14-003115:notes:15]
[same as prior period, unchanged from 0001564590-14-000165:notes:16]

[0001564590-14-003115:notes:16]
The Company provides a gross presentation of activity within Level 3 measurement roll-forward and details of transfers in and out of Level 1 and 2 measurements.  A change in the hierarchy of an investment from its current level is reflected in the period during which the pricing methodology of such investment changes.  Disclosure of the transfer of securities from Level 1 to Level 2 or Level 3 is made in the event that the related security is significant to total cash and investments.  The Company did not have any transfers of assets and liabilities between Level 1 and Level 3 of the fair value measurement hierarchy during the three months ended June 30, 2014.

[0001564590-14-003115:notes:17]
[same as prior period, unchanged from 0001564590-14-000165:notes:17]

[0001564590-14-003115:notes:18]
The following table provides the assets and liabilities carried at fair value, measured as of June 30, 2014 and March 31, 2014 (in thousands):

[0001564590-14-003115:notes:19]
|  | Total |  |  | Quoted Prices in |  |  | Significant Other |  |  | Significant |  |
|  | Carrying |  |  | Active Markets |  |  | Observable Inputs |  |  | Unobservable Inputs |  |
|  | Value |  |  | (Level 1) |  |  | (Level 2) |  |  | (Level 3) |  |
| June 30, 2014: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash equivalents | $ | 22,180 |  |  | $ | 22,180 |  |  | $ | - |  |  | $ | - |  |
| Derivative liabilities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Warrants | $ | 2,636 |  |  | $ | - |  |  | $ | - |  |  | $ | 2,636 |  |
|  | Total |  |  | Quoted Prices in |  |  | Significant Other |  |  | Significant |  |
|  | Carrying |  |  | Active Markets |  |  | Observable Inputs |  |  | Unobservable Inputs |  |
|  | Value |  |  | (Level 1) |  |  | (Level 2) |  |  | (Level 3) |  |
| March 31, 2014: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash equivalents | $ | 17,675 |  |  | $ | 17,675 |  |  | $ | - |  |  | $ | - |  |
| Derivative liabilities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Warrants | $ | 2,601 |  |  | $ | - |  |  | $ | - |  |  | $ | 2,601 |  |

[0001564590-14-003115:notes:20]
[same as prior period, unchanged from 0001564590-14-000165:notes:21]

[0001564590-14-003115:notes:21]
|  |  |  |  |  | Warrants |  |
| April 1, 2014 |  |  |  |  | $ | 2,601 |  |
| Mark to market adjustment |  |  |  |  |  | 35 |  |
| Balance at June 30, 2014 |  |  |  |  | $ | 2,636 |  |
|  | Derivative |  |  |  |  |  |
|  | Liability |  |  | Warrants |  |
| April 1, 2013 | $ | 529 |  |  | $ | 3,633 |  |
| Warrant issuance with Senior Secured Term Loan |  | - |  |  |  | 315 |  |
| Mark to market adjustment |  | (525 | ) |  |  | (1,347 | ) |
| Extinguishment of derivative liability |  | (4 | ) |  |  | - |  |
| Balance at March 31, 2014 | $ | - |  |  | $ | 2,601 |  |

[0001564590-14-003115:notes:22]
The following table provides the assets and liabilities measured at fair value on a non-recurring basis, as of March 31, 2014 (in thousands).  As no indicators of impairment existed during the current quarter, there were no assets to be measured at fair value on a non-recurring basis as of June 30, 2014.

[0001564590-14-003115:notes:23]
|  | Total |  |  | Quoted Prices in |  |  | Significant Other |  |  | Significant |  |
|  | Carrying |  |  | Active Markets |  |  | Observable Inputs |  |  | Unobservable Inputs |  |
|  | Value |  |  | (Level 1) |  |  | (Level 2) |  |  | (Level 3) |  |
| March 31, 2014: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Investment in unconsolidated entity – Blade Dynamics | $ | 3,690 |  |  | $ | - |  |  | $ | - |  |  | $ | 3,690 |  |

[0001564590-14-003115:notes:24]
[same as prior period, unchanged from 0001564590-14-000165:notes:24]

[0001564590-14-003115:notes:25]
[same as prior period, unchanged from 0001564590-14-000165:notes:25]

[0001564590-14-003115:notes:26]
[same as prior period, unchanged from 0001564590-14-000165:notes:26]

[0001564590-14-003115:notes:27]
[same as prior period, unchanged from 0001564590-14-000165:notes:27]

[0001564590-14-003115:notes:28]
In April 2012, the Company entered into a Securities Purchase Agreement (the “Purchase Agreement”) with Capital Ventures International (“CVI”), an affiliate of Heights Capital Management, under which the Company issued a $25.0 million, 7% convertible note (the “Initial Note”).  In December 2012, the Company entered into an agreement with CVI pursuant to which it exchanged the Initial Note for the Exchanged Note.  The Exchanged Note was extinguished as of March 31, 2014.  The Company had identified all of the derivatives (“Derivative Liability”) associated with the extinguished Exchanged Note which include holder change of control redemption rights, issuer optional redemption rights, sale redemption rights and a feature to convert the Exchanged Note into equity at the holder’s option.  The Derivative Liability was subject to revaluation at each balance sheet date, and any change in fair value was recorded as a change in fair value in derivatives and warrants until its expiration.  The Company relied on assumptions in a lattice model to determine the fair value of Derivative Liability.  The Company had appropriately valued the Derivative Liability within Level 3 of the valuation hierarchy.  (See Note 10, “Debt,” for further discussion of the Exchanged Note, Derivative Liability and valuation assumptions used.)

[0001564590-14-003115:notes:29]
[same as prior period, unchanged from 0001564590-14-000165:notes:29]

[0001564590-14-003115:notes:30]
Warrants were issued in conjunction with the Purchase Agreement with CVI, and the Term Loan. (See Note 10, “Debt,” and Note 11 “Warrants and Derivative Liabilities,” for additional information.) These warrants are subject to revaluation at each balance sheet date, and any change in fair value will be recorded as a change in fair value in derivatives and warrants until the earlier of their exercise or expiration.

[0001564590-14-003115:notes:31]
The Company relies on various assumptions in a lattice model to determine the fair value of warrants. The Company has appropriately valued the warrants within Level 3 of the valuation hierarchy. (See Note 11, “Warrants and Derivative Liabilities,” for a discussion of the warrants and the valuation assumptions used.)

[0001564590-14-003115:notes:32]
Minority Investment

[0001564590-14-003115:notes:33]
The Company accounts for the minority investment in Blade Dynamics on a cost basis (See Note 14, “Minority Investments”).  During the year ended March 31, 2014, the Company determined that as a result of its efforts to sell its investment in Blade Dynamics, certain indicators of impairment existed which required the Company to perform further analysis. Based on analysis which included potential sale scenarios of the investment, the Company recorded an impairment charge of approximately $1.3 million and reported the investment at its estimated fair value in the fourth quarter ended March 31, 2014.


## us-gaap:LoansNotesTradeAndOtherReceivablesDisclosureTextBlock

[0001564590-14-003115:notes:34]
[same as prior period, unchanged from 0001564590-14-000165:notes:32]

[0001564590-14-003115:notes:35]
Accounts receivable at June 30, 2014 and March 31, 2014 consisted of the following (in thousands):

[0001564590-14-003115:notes:36]
|  | June 30, |  |  | March 31, |  |
|  | 2014 |  |  | 2014 |  |
| Accounts receivable (billed) | $ | 9,650 |  |  | $ | 6,113 |  |
| Accounts receivable (unbilled) |  | 656 |  |  |  | 1,459 |  |
| Less: Allowance for doubtful accounts |  | (16 | ) |  |  | (16 | ) |
| Accounts receivable, net | $ | 10,290 |  |  | $ | 7,556 |  |


## us-gaap:InventoryDisclosureTextBlock

[0001564590-14-003115:notes:37]
[same as prior period, unchanged from 0001564590-14-000165:notes:35]

[0001564590-14-003115:notes:38]
Inventory at June 30, 2014 and March 31, 2014 consisted of the following (in thousands):

[0001564590-14-003115:notes:39]
|  | June 30, |  |  | March 31, |  |
|  | 2014 |  |  | 2014 |  |
| Raw materials | $ | 5,101 |  |  | $ | 3,304 |  |
| Work-in-process |  | 2,471 |  |  |  | 4,047 |  |
| Finished goods |  | 9,147 |  |  |  | 10,275 |  |
| Deferred program costs |  | 2,689 |  |  |  | 3,068 |  |
| Net inventory | $ | 19,408 |  |  | $ | 20,694 |  |

[0001564590-14-003115:notes:40]
The Company recorded inventory write-downs of $0.6 million and $0.2 million for the three months ended June 30, 2014 and 2013, respectively. These write downs were based on evaluating its ending inventory on hand for excess quantities and obsolescence.

[0001564590-14-003115:notes:41]
Deferred program costs as of June 30, 2014 and March 31, 2014 primarily represent costs incurred on programs accounted for under contract accounting where the Company needs to complete development programs before revenue and costs will be recognized.


## us-gaap:AccountsPayableAndAccruedLiabilitiesDisclosureTextBlock

[0001564590-14-003115:notes:42]
[same as prior period, unchanged from 0001564590-14-000165:notes:40]

[0001564590-14-003115:notes:43]
Accounts payable and accrued expenses at June 30, 2014 and March 31, 2014 consisted of the following (in thousands):

[0001564590-14-003115:notes:44]
|  | June 30, |  |  | March 31, |  |
|  | 2014 |  |  | 2014 |  |
| Accounts payable | $ | 2,554 |  |  | $ | 1,749 |  |
| Accrued inventories in-transit |  | 1,509 |  |  |  | 212 |  |
| Accrued miscellaneous expenses |  | 4,801 |  |  |  | 6,076 |  |
| Accrued outside services |  | 3,272 |  |  |  | 3,716 |  |
| Accrued subcontractor program costs |  | 288 |  |  |  | 290 |  |
| Accrued compensation |  | 3,155 |  |  |  | 5,939 |  |
| Income taxes payable |  | 200 |  |  |  | 173 |  |
| Accrued adverse purchase commitments |  | 403 |  |  |  | 402 |  |
| Accrued warranty |  | 2,855 |  |  |  | 3,207 |  |
| Total | $ | 19,037 |  |  | $ | 21,764 |  |

[0001564590-14-003115:notes:45]
[same as prior period, unchanged from 0001564590-14-000165:notes:43]

[0001564590-14-003115:notes:46]
[same as prior period, unchanged from 0001564590-14-000165:notes:44]

[0001564590-14-003115:notes:47]
|  | Three Months Ended |  |
|  | June 30, |  |
|  | 2014 |  |  | 2013 |  |
| Balance at beginning of period | $ | 3,207 |  |  | $ | 2,709 |  |
| Change in accruals for warranties during the period |  | (72 | ) |  |  | 152 |  |
| Settlements during the period |  | (280 | ) |  |  | (74 | ) |
| Balance at end of period | $ | 2,855 |  |  | $ | 2,787 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0001564590-14-003115:notes:48]
[same as prior period, unchanged from 0001564590-14-000165:notes:46]

[0001564590-14-003115:notes:49]
For both of the three months ended June 30, 2014 and 2013, the Company recorded income tax expense of $0.1 million.  Income tax expense was primarily due to income taxes in the Company’s foreign jurisdictions.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001564590-14-003115:notes:50]
[same as prior period, unchanged from 0001564590-14-000165:notes:48]

[0001564590-14-003115:notes:51]
[same as prior period, unchanged from 0001564590-14-000165:notes:49]

[0001564590-14-003115:notes:52]
During the years ended March 31, 2014 and March 31, 2013, the Company undertook restructuring activities, approved by the Board of Directors, in order to reorganize its global operations, streamline various functions of the business, and reduce its global workforce to better reflect the demand for its products.  During the year ended March 31, 2014, the Company undertook a plan to consolidate its Grid manufacturing activities in its Devens, Massachusetts facility and close its facility in Middleton, Wisconsin.  In addition, the Company is establishing a new Wind manufacturing facility in Romania and as a result reduced the headcount in its operation in China to a level necessary to support demand from its Chinese customers.  The Company also undertook a workforce reduction in July 2013, reducing its workforce by approximately 7%, impacting primarily selling, engineering and general and administrative functions.  The Company recorded restructuring charges for severance and other costs of approximately $1.2 million during the three months ended June 30, 2014.  During the three months ended June 30, 2013, the Company incurred restructuring costs of less than $0.1 million. From April 1, 2011 through June 30, 2014, the Company’s various restructuring activities resulted in a substantial reduction of its global workforce. Remaining unpaid amounts under these restructuring activities are expected to be paid by August 31, 2015.

[0001564590-14-003115:notes:53]
[same as prior period, unchanged from 0001564590-14-000165:notes:51]

[0001564590-14-003115:notes:54]
|  | Severance pay |  |  | Facility Exit and |  |  |  |  |  |
| Three months ended June 30, 2014: | and benefits |  |  | Relocation costs |  |  | Total |  |
| Accrued restructuring balance at April 1, 2014 | $ | 844 |  |  | $ | - |  |  | $ | 844 |  |
| Charges to operations |  | 690 |  |  |  | 489 |  |  |  | 1,179 |  |
| Cash payments |  | (589 | ) |  |  | (489 | ) |  |  | (1,078 | ) |
| Accrued restructuring balance at June 30, 2014 | $ | 945 |  |  | $ | - |  |  | $ | 945 |  |
| Three months ended June 30, 2013: |  |  |  |  |  |  |  |  |  |  |  |
| Accrued restructuring at April 1, 2013 | $ | 145 |  |  | $ | 54 |  |  | $ | 199 |  |
| Charges to operations |  | 40 |  |  |  | - |  |  |  | 40 |  |
| Cash payments |  | (107 | ) |  |  | (18 | ) |  |  | (125 | ) |
| Non-cash/miscellaneous reductions |  | (20 | ) |  |  | (18 | ) |  |  | (38 | ) |
| Accrued restructuring balance at June 30, 2013 | $ | 58 |  |  | $ | 18 |  |  | $ | 76 |  |

[0001564590-14-003115:notes:55]
[same as prior period, unchanged from 0001564590-14-000165:notes:53]


## us-gaap:DebtDisclosureTextBlock

[0001564590-14-003115:notes:56]
10. Debt

[0001564590-14-003115:notes:57]
Senior Convertible Note

[0001564590-14-003115:notes:58]
On April 4, 2012, the Company entered into the Purchase Agreement with CVI and completed a private placement of the Initial Note. After fees and expenses, the net proceeds of the Initial Note were $23.2 million. The Initial Note had an initial conversion price of $4.85 per share, representing a premium of approximately 20% over AMSC’s closing price on April 3, 2012. The Initial Note was payable in monthly installments beginning four months from issuance and ending on October 4, 2014. Monthly payments were payable in cash or the Company’s common stock at the option of the Company, subject to certain trading volume, stock price and other conditions. CVI could elect to defer receipt of monthly installment payments at its option. Any deferred installment payments would continue to accrue interest. The Company registered 10,262,311 shares of common stock which could be used as payment for principal and interest in lieu of cash for resale under the Securities Act of 1933, as amended (the “Securities Act”) as required under a Registration Rights Agreement with CVI.

[0001564590-14-003115:notes:59]
The Company accounted for the Initial Note as an instrument that has the characteristics of a debt host contract containing several embedded derivative features that would require bifurcation and separate accounting as a derivative instrument pursuant to the provisions of ASC Topic 815 – Derivatives and Hedging (ASC 815). The Company elected not to use the fair value option for the aggregate amount of the Initial Note and recorded the liability at its stated value on the date of issuance with no changes in fair value reported in subsequent periods. The Company valued these derivatives at $3.8 million upon issuance of the Initial Note. (See Note 11, “Warrants and Derivative Liabilities,” for additional information regarding derivative liabilities.)

[0001564590-14-003115:notes:60]
In conjunction with the Initial Note, CVI received a warrant to purchase approximately 3.1 million additional shares of common stock exercisable at a strike price of $5.45 per share, subject to adjustment, until October 4, 2017. Due to certain adjustment provisions within the warrant, it qualified for liability accounting and had a fair value of $7.0 million upon issuance. The Company recorded the value as a debt discount and a warrant liability. (See Note 11, “Warrants and Derivative Liabilities,” for additional information regarding the warrant.)

[0001564590-14-003115:notes:61]
On December 20, 2012, the Company entered into an Amendment and Exchange Agreement, (the “Amendment”) with CVI, which amended the Purchase Agreement. Pursuant to the Amendment, the Company and CVI exchanged the Initial Note for the Exchanged Note. At the time of the exchange, the Exchanged Note had the same principal amount and accrued interest as the Initial Note. The Exchanged Note was convertible into the Company’s common stock and had the same scheduled monthly installment payments as the Initial Note. The Exchanged Note provided the Company with additional flexibility to make monthly installment payments in shares of the Company’s common stock. The Company retained the ability to repay the Exchanged Note in cash.

[0001564590-14-003115:notes:62]
The Company assessed the changes in the Exchanged Note and accounted for it as a modification of the Initial Note. Therefore, the Company determined the incremental value of the derivative instruments, as a result of the Exchanged Note, as having a reduced conversion price. As a result of the re-valuation, the Company recorded a $0.5 million increase in the value of the derivative liability and additional debt discount. At the modification date, the value of the derivative liability was $1.5 million. The total debt discount, including the embedded derivatives in the Initial Note, the incremental value of embedded derivatives in the Exchanged Note, warrant and legal and origination costs of $13.1 million was amortized into interest expense over the term of the Exchanged Note using the effective interest method. Under this method, interest expense was recognized each period until the debt instruments reached maturity. Given that the maturity of the Exchanged Note was accelerated due to prepayment, the amortization was accelerated.

[0001564590-14-003115:notes:63]
On October 9, 2013, the Company entered into a Second Amendment and Warrant Exchange Agreement (the “Second Amendment”) with CVI. The Second Amendment further amended the Purchase Agreement, as amended by the First Amendment (collectively, the “Amended Purchase Agreement”), that the Company previously entered into with CVI.

[0001564590-14-003115:notes:64]
Pursuant to the Second Amendment, the Company and/or CVI waived certain provisions of the Amended Purchase Agreement and amended certain provisions of the Exchanged Note and exchanged the warrant (the “Original Warrant”) for a new warrant (the Exchanged Warrant”) with a reduced exercise price of $2.61 per share of common stock.

[0001564590-14-003115:notes:65]
The Company assessed the changes to the Exchanged Note included in the Second Amendment and accounted for it as a modification of the Exchanged Note. Therefore, the Company determined the incremental value of the derivative instruments, as a result of the Second Amendment, specifically the Exchanged Warrant. See Note 11 “Warrants and Derivative Liabilities” for discussion of the valuation of the Exchanged Warrant.

[0001564590-14-003115:notes:66]
During the three months ended June 30, 2013, the Company recorded non-cash interest expense for amortization of the debt discount related to the convertible notes of $1.5 million.

[0001564590-14-003115:notes:67]
Provided certain equity conditions were met, the Company could elect to repay principal and interest in shares of the Company’s common stock. If the Company elected to make a payment in shares of the Company’s common stock, the number of shares issued was determined by dividing the amount of such payment by 85% of the lessor of the average volume-weighted average price (“VWAP”) of the 10 consecutive days immediately preceding the payment date or the VWAP price on the day preceding the payment date (the “Market Price”). The Company recorded the difference between the closing price of its common stock on the day preceding the payment date and the Market Price as a discount on the fair value of its shares. During the three months ended June 30, 2013, the Company recorded $0.1 million of non-cash interest expense related to installment payments made by issuing the Company’s common stock at a discount.

[0001564590-14-003115:notes:68]
On March 2, 2014, the Company entered into an Exchange Agreement with CVI, pursuant to which the Company exchanged the Exchanged Note for approximately 6.6 million shares of common stock and extinguished the debt.  As a result of this transaction, the Company recorded a loss on the extinguishment of debt of $5.2 million during the three months ended March 31, 2014.

[0001564590-14-003115:notes:69]
Senior Secured Term Loans

[0001564590-14-003115:notes:70]
On June 5, 2012, the Company entered into a Term Loan with Hercules Technology Growth Capital, Inc. (“Hercules”), under which the Company borrowed $10.0 million. After the closing fees and expenses, the net proceeds to the Company were $9.7 million. The Term Loan bears an interest rate equal to 11% plus the percentage, if any, by which the prime rate as reported by The Wall Street Journal exceeds 3.75%. The Company made interest-only payments from July 1, 2012 through October 31, 2012, after which the Company began repaying the Term Loan in equal monthly installments ending on December 1, 2014. The Term Loan is secured by substantially all of the Company’s existing and future assets, including a mortgage on real property owned by the Company’s wholly-owned subsidiary, ASC Devens LLC, and located at 64 Jackson Road, Devens, Massachusetts. In addition, Hercules received a warrant (the “First Warrant”) to purchase 139,276 shares of common stock, exercisable at an initial strike price of $3.59 per share, subject to adjustment, until December 5, 2017. Due to certain adjustment provisions within the warrant, it qualified for liability accounting and the fair value of $0.4 million was recorded upon issuance, which the Company recorded as a debt discount and a warrant liability.  The Company will pay an end of term fee of $0.5 million upon the earlier of maturity or prepayment of the loan. The Company has accrued the term fee and recorded a corresponding amount into the debt discount. In addition, the Company incurred $0.3 million of legal and origination costs in the year ended March 31, 2013, which have been recorded as a debt discount. The total debt discount including the First Warrant, end of term fee and legal and origination costs of $1.2 million is being amortized into interest expense over the term of the Term Loan using the effective interest method. Under this method, interest expense is recognized each period until the debt instrument reaches maturity. During the three months ended June 30, 2014 and 2013, the Company recorded non-cash interest expense for amortization of the debt discount related to the Term Loan of $0.1 million and $0.1 million, respectively.

[0001564590-14-003115:notes:71]
On November 15, 2013, the Company amended the Term Loan with Hercules and entered into a New Term Loan (collectively with the Term Loan, the “Term Loans”), borrowing an additional $10.0 million. After closing fees and expenses, the net proceeds to the Company for the New Term Loan were $9.8 million.  The New Term Loan also bears the same interest rate as the Term Loan.  The Company made interest-only payments from December 1, 2013 to May 31, 2014.  If the Company achieved certain revenue targets for the six-month period ending March 31, 2014, interest only payments would continue through August 31, 2014.  The Company did not meet these revenue targets.  As a result, the Company is repaying the New Term Loan in equal monthly installments ending on November 1, 2016.  Hercules received a warrant (the “Second Warrant”) to purchase 256,410 shares of common stock, exercisable at an initial strike price of $1.95 per share, subject to adjustment, until May 15, 2019.  In addition, the exercise price of the First Warrant was reduced to $1.95 per share.  (See Note 11, “Warrants and Derivative Liabilities,” for a discussion on both warrants and the valuation assumptions used.) The Company will pay an end of term fee of $0.5 million upon the earlier of maturity or prepayment of the New Term Loan. The Company has accrued the end of term fee and recorded a corresponding amount into the debt discount.  The New Term Loan includes a mandatory prepayment feature which allows Hercules the right to use any of the Company’s net proceeds from specified asset dispositions greater than $1.0 million in a calendar year to pay off any outstanding accrued interest and principal balance on the New Term Loan.  The Company determined the fair value to be de-minimis for this feature. In addition, the Company incurred $0.2 million of legal and origination costs in the three months ended December 31, 2013, which have been recorded as a debt discount. The total debt discount including the Second Warrant, end of term fee and legal and origination costs of $1.0 million is being amortized into interest expense over the term of the New Term Loan using the effective interest method. If the maturity of either of the term loans is accelerated because of prepayment, then the amortization will be accelerated. During the three months ended June 30, 2014, the Company recorded non-cash interest expense for amortization of the debt discount related to the New Term Loan of $0.1 million.

[0001564590-14-003115:notes:72]
The Term Loans are secured by substantially all of the Company’s existing and future assets, including a mortgage on real property owned by the Company’s wholly-owned subsidiary, ASC Devens LLC, and located at 64 Jackson Road, Devens, Massachusetts.  The Term Loans contain certain covenants that restrict the Company’s ability to, among other things, incur or assume certain debt, merge or consolidate, materially change the nature of the Company’s business, make certain investments, acquire or dispose of certain assets, make guaranties or grant liens on its assets, make certain loans, advances or investments, declare dividends or make distributions or enter into transactions with affiliates. In addition, there is a covenant that requires the Company to maintain a minimum unrestricted cash balance (the “Minimum Threshold”) in the United States of at least $15.0 million at the inception of the New Term Loan.  The Minimum Threshold will be reduced by $2.5 million for every $5.0 million of net proceeds from the sale of its common stock after November 15, 2013, including those under the ATM, to an amount not lower than $7.5 million or the outstanding combined principal balances of the Term Loans, whichever is lower.  As of June 30, 2014, the Minimum Threshold was $12.5 million.  The events of default under the Term Loans include, but are not limited to, failure to pay amounts due, breaches of covenants, bankruptcy events, cross defaults under other material indebtedness and the occurrence of a material adverse effect and/or change in control. In the case of a continuing event of default, Hercules may, among other remedies, declare due all unpaid principal amounts outstanding and any accrued but unpaid interest and foreclose on all collateral granted to Hercules as security under the Term Loans.

[0001564590-14-003115:notes:73]
Although the Company believes that it is in and expects to remain in compliance with the covenants and restrictions under the Term Loans as of the date of this Quarterly Report on Form 10-Q, there can be no assurance that the Company will continue to be in compliance.

[0001564590-14-003115:notes:74]
Interest expense on the Exchanged Note and Term Loans for the three months ended June 30, 2014 and 2013, was $0.5 million and $2.1 million, respectively, which included $0.2 million and $1.7 million, respectively, of non-cash interest expense related to the amortization of the debt discount on the Exchanged Note and Term Loans and payment of the Exchanged Note in Company common stock at a discount.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001564590-14-003115:notes:75]
[same as prior period, unchanged from 0001564590-14-000165:notes:85]

[0001564590-14-003115:notes:76]
[same as prior period, unchanged from 0001564590-14-000165:notes:86]

[0001564590-14-003115:notes:77]
On April 4, 2012, the Company entered into the Purchase Agreement with CVI. The Purchase Agreement included the Original Warrant to purchase 3,094,060 shares of the Company’s common stock. The warrant is exercisable at any time on or after the date that is six months after the issuance of the warrant and entitles CVI to purchase shares of the Company’s common stock for a period of five years from the initial date the warrant becomes exercisable at a price equal to $5.45 per share, subject to certain price-based and other anti-dilution adjustments. On October 9, 2013, the Company amended the Purchase Agreement with CVI (the “Amendment”). Pursuant to the Amendment, the Company exchanged the Original Warrant for the Exchanged Warrant, with a reduced exercise price of $2.61 per share of common stock. Other than the reduced exercise price, the Exchanged Warrant has the same terms and conditions as the Original Warrant.  As a result of the sales of common stock under the ATM (See Note 12, “Stockholders’ Equity”, for further discussion of the ATM), and other issuances, during the three months ended June 30, 2014, the exercise price of the Exchanged Warrant was reduced to $2.57 per share.  The Exchanged Warrant may not be exercised if, after giving effect to the conversion, CVI together with its affiliates would beneficially own in excess of 4.99% of the Company’s common stock. This percentage may be raised to any other percentage not in excess of 9.99% at the option of CVI, upon at least 61-days prior notice to the Company, or lowered to any other percentage, at the option of CVI, at any time.

[0001564590-14-003115:notes:78]
The Company calculated the fair value of the derivative liabilities, (see Note 4, “Fair Value Measurements”, and Note 10, “Debt” for further discussion), and warrants utilizing an integrated lattice model. The lattice model is an option pricing model that involves the construction of a binomial tree to show the different paths that the underlying asset may take over the option’s life. A lattice model can take into account expected changes in various parameters such as volatility over the life of the options, providing more accurate estimates of option prices than the Black-Scholes model.

[0001564590-14-003115:notes:79]
The Company accounts for the warrant as a liability due to certain adjustment provisions within the warrant, which requires that it be recorded at fair value. The warrant is subject to revaluation at each balance sheet date and any change in fair value will be recorded as a change in fair value of derivatives and warrants until the earlier of expiration or its exercise at which time the warrant liability will be reclassified to equity.

[0001564590-14-003115:notes:80]
[same as prior period, unchanged from 0001564590-14-000165:notes:90]

[0001564590-14-003115:notes:81]
|  | June 30, |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Fiscal Year 14 | 2014 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Risk-free interest rate |  | 0.98 | % |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Expected annual dividend yield |  | — | % |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Expected volatility |  | 83.50 | % |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Term (years) | 3.26 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Fair value | $2.3 million |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  |  |  |  |  |  |  |  | Post-modification |  |  | Pre-modification |  |  |  |  |  |  |  |  |  |  |  |  |
|  | March 31, |  |  | December 31, |  |  | October 9, |  |  | October 9, |  |  | September 30, |  |  | June 30, |  | March 31, |  |
| Fiscal Year 13 | 2014 |  |  | 2013 |  |  | 2013 |  |  | 2013 |  |  | 2013 |  |  | 2013 |  | 2013 |  |
| Risk-free interest rate |  | 1.11 | % |  |  | 1.17 | % |  |  | 1.05 | % |  |  | 1.05 | % |  |  | 1.02 | % |  |  | 1.13 | % |  | 0.67 | % |
| Expected annual dividend yield |  | — | % |  |  | — | % |  |  | — | % |  |  | — | % |  |  | — | % |  |  | — | % |  | — | % |
| Expected volatility |  | 80.99 | % |  |  | 75.60 | % |  |  | 71.50 | % |  |  | 71.50 | % |  |  | 72.00 | % |  |  | 71.90 | % |  | 71.70 | % |
| Term (years) | 3.51 |  |  | 3.76 |  |  | 3.99 |  |  | 3.99 |  |  |  | 4.01 |  |  |  | 4.27 |  |  | 4.51 |  |
| Fair value | $ 2.2 million |  |  | $ 2.2 million |  |  | $ 3.2 million |  |  | $ 2.2 million |  |  | $ 2.5 million |  |  | $ 3.0 million |  | $ 3.4 million |  |

[0001564590-14-003115:notes:82]
The Company recorded a net loss, resulting from the increase in the fair value of the Exchanged Warrant, of $0.1 million compared to a net gain, resulting from the decrease in fair value of $0.4 million to change in fair value of derivatives and warrants in the three months ended June 30, 2014, and 2013, respectively.

[0001564590-14-003115:notes:83]
Convertible Note Derivative Liability

[0001564590-14-003115:notes:84]
[same as prior period, unchanged from 0001564590-14-000165:notes:94]

[0001564590-14-003115:notes:85]
The terms of the December 2012 Amendment with CVI provided for, among other things, the exchange of the Initial Note for the Exchanged Note and reduced the conversion price of the Initial Note from $4.85 per share to $3.19 per share in the Exchanged Note.  As a result of the sales of common stock under the ATM (See Note 12, “Stockholders’ Equity”, for further discussion of the ATM) the conversion price of the Exchanged Note was further reduced to $3.10 per share.

[0001564590-14-003115:notes:86]
On March 2, 2014, the Company entered into an Exchange Agreement with CVI, pursuant to which the Company exchanged the Exchanged Note for approximately 6.6 million shares of common stock, in full satisfaction of all amounts owed under the Exchanged Note, including any accrued interest.  In addition, the Company exchanged the remaining value for the derivative liability identified with the Exchanged Note and any unamortized debt discount.

[0001564590-14-003115:notes:87]
[same as prior period, unchanged from 0001564590-14-000165:notes:96]

[0001564590-14-003115:notes:88]
|  | March 31, |  | December 31, |  |  | September 30, |  |  | June 30, |  | March 31, |  |
| Fiscal Year 13 | 2014 |  | 2013 |  |  | 2013 |  |  | 2013 |  | 2013 |  |
| Principal outstanding (000's) | $ | — |  | $ |  | 10,411 |  |  | $ |  | 10,411 |  |  | $ |  | 14,389 |  | $ |  | 15,380 |  |
| Stock price |  | N/A |  | $ |  | 1.64 |  |  | $ |  | 2.34 |  |  | $ |  | 2.64 |  | $ |  | 2.67 |  |
| Percentage volume condition met |  | — % |  |  |  | 87.20 | % |  |  |  | 80.20 | % |  |  |  | 87.50 | % |  |  | 80.50 | % |
| Expected volatility |  | — % |  |  |  | 68.60 | % |  |  |  | 66.30 | % |  |  |  | 65.80 | % |  |  | 66.90 | % |
| Risk free rate |  | — % |  |  |  | 0.12 | % |  |  |  | 0.10 | % |  |  |  | 0.21 | % |  |  | 0.20 | % |
| Bond yield |  | — % |  |  |  | 16.50 | % |  |  |  | 15.50 | % |  |  |  | 16.70 | % |  |  | 16.50 | % |
| Recovery rate |  | — % |  |  |  | 35.00 | % |  |  |  | 35.00 | % |  |  |  | 37.00 | % |  |  | 30.00 | % |
| Redeemable |  | N/A |  |  | yes |  |  |  | yes |  |  |  | yes |  |  | yes |  |
| Total time (years) |  | — |  |  |  | 0.75 |  |  |  |  | 1.00 |  |  |  |  | 1.26 |  |  |  | 1.51 |  |
| Dilution effect |  | N/A |  |  | yes |  |  |  | yes |  |  |  | yes |  |  | yes |  |
| Fair value | $ | — |  | $ | — |  |  | $ | 0.2 million |  |  | $ | 0.5 million |  | $ | 0.5 million |  |
| Fair value as a percent of par |  | — % |  |  |  | 0.02 | % |  |  |  | 0.70 | % |  |  |  | 3.3 | % |  |  | 3.4 | % |

[0001564590-14-003115:notes:89]
[same as prior period, unchanged from 0001564590-14-000165:notes:98]

[0001564590-14-003115:notes:90]
The Company recorded no change in fair value of derivatives and warrants in the three months ended June 30, 2013.

[0001564590-14-003115:notes:91]
[same as prior period, unchanged from 0001564590-14-000165:notes:100]

[0001564590-14-003115:notes:92]
On June 5, 2012, the Company entered into the Loan and Security Agreement with Hercules. (See Note 10, “Debt,” for additional information regarding the Loan and Security Agreement.) In conjunction with this agreement, the Company issued the First Warrant to purchase 139,276 shares of the Company’s common stock. The First Warrant is exercisable at any time after its issuance and expires on December 5, 2017, at a price equal to $3.59 per share subject to certain price-based and other anti-dilution adjustments.  The exercise price was reduced to $1.95 per share in conjunction with entering into the New Term Loan.  An anti-dilution adjustment resulted in a reduction to the exercise price to $1.94 per share as of June 30, 2014.

[0001564590-14-003115:notes:93]
[same as prior period, unchanged from 0001564590-14-000165:notes:102]

[0001564590-14-003115:notes:94]
[same as prior period, unchanged from 0001564590-14-000165:notes:103]

[0001564590-14-003115:notes:95]
|  | June 30, |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Fiscal Year 14 | 2014 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Risk-free interest rate |  | 1.04 | % |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Expected annual dividend yield |  | — | % |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Expected volatility |  | 82.75 | % |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Term (years) |  | 3.43 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Fair value | $ 0.1 million |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  |  |  |  |  |  |  |  | Post-modification |  |  | Pre-modification |  |  |  |  |  |  |  |  |  |  |  |  |
|  | March 31, |  |  | December 31, |  |  | November 15, |  |  | November 15, |  |  | September 30, |  |  | June 30, |  | March 31, |  |
| Fiscal Year 13 | 2014 |  |  | 2013 |  |  | 2013 |  |  | 2013 |  |  | 2013 |  |  | 2013 |  | 2013 |  |
| Risk-free interest rate |  | 1.18 | % |  |  | 1.24 | % |  |  | 1.00 | % |  |  | 1.00 | % |  |  | 1.09 | % |  |  | 1.20 | % |  | 0.70 | % |
| Expected annual dividend yield |  | — | % |  |  | — | % |  |  | — | % |  |  | — | % |  |  | — | % |  |  | — | % |  | — | % |
| Expected volatility |  | 80.73 | % |  |  | 74.79 | % |  |  | 72.64 | % |  |  | 72.64 | % |  |  | 72.10 | % |  |  | 72.30 | % |  | 72.01 | % |
| Term (years) |  | 3.68 |  |  |  | 3.93 |  |  |  | 4.05 |  |  |  | 4.05 |  |  |  | 4.18 |  |  |  | 4.43 |  |  | 4.68 |  |
| Fair value | $ 0.1 million |  |  | $ 0.1 million |  |  | $ 0.1 million |  |  | $ 0.1 million |  |  | $ 0.2 million |  |  | $ 0.2 million |  | $ 0.2 million |  |

[0001564590-14-003115:notes:96]
The Company recorded no change in fair value of derivatives and warrants during either of the three month periods ended June 30, 2014 and 2013.

[0001564590-14-003115:notes:97]
[same as prior period, unchanged from 0001564590-14-000165:notes:106]

[0001564590-14-003115:notes:98]
On November 15, 2013, the Company amended the Loan and Security Agreement with Hercules and entered into the New Term Loan. (See Note 10, “Debt,” for additional information regarding the New Term Loan.) In conjunction with this agreement, the Company issued the Second Warrant to purchase 256,410 shares of the Company’s common stock. The Second Warrant is exercisable at any time after its issuance and expires on May 15, 2019, at a price equal to $1.95 per share subject to certain price-based and other anti-dilution adjustments.  An anti-dilution adjustment resulted in a reduction to the exercise price to $1.94 per share as of June 30, 2014.

[0001564590-14-003115:notes:99]
[same as prior period, unchanged from 0001564590-14-000165:notes:108]

[0001564590-14-003115:notes:100]
[same as prior period, unchanged from 0001564590-14-000165:notes:109]

[0001564590-14-003115:notes:101]
|  | June 30, |  |  |  |  |  |  |  |  |  |
| Fiscal Year 14 | 2014 |  |  |  |  |  |  |  |  |  |
| Risk-free interest rate |  | 1.57 | % |  |  |  |  |  |  |  |  |
| Expected annual dividend yield |  | — | % |  |  |  |  |  |  |  |  |
| Expected volatility |  | 80.00 | % |  |  |  |  |  |  |  |  |
| Term (years) |  | 4.87 |  |  |  |  |  |  |  |  |  |
| Fair value | $ 0.3 million |  |  |  |  |  |  |  |  |  |
|  |  |  |  |  |  |  |  |  | New Issuance |  |
|  | March 31, |  |  | December 31, |  |  | November 15, |  |
| Fiscal Year 13 | 2014 |  |  | 2013 |  |  | 2013 |  |
| Risk-free interest rate |  | 1.76 | % |  |  | 1.89 | % |  |  | 1.55 | % |
| Expected annual dividend yield |  | — | % |  |  | — | % |  |  | — | % |
| Expected volatility |  | 79.73 | % |  |  | 80.37 | % |  |  | 76.97 | % |
| Term (years) |  | 5.12 |  |  |  | 5.37 |  |  |  | 5.49 |  |
| Fair value | $ 0.3 million |  |  | $ 0.3 million |  |  | $ 0.3 million |  |

[0001564590-14-003115:notes:102]
The Company recorded an increase in the fair value of the First Warrant and the Second Warrant resulting in a loss of less than $0.1 million during the three months ended June 30, 2014.

[0001564590-14-003115:notes:103]
[same as prior period, unchanged from 0001564590-14-000165:notes:112]


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001564590-14-003115:notes:104]
[same as prior period, unchanged from 0001564590-14-000165:notes:113]

[0001564590-14-003115:notes:105]
On November 15, 2013, the Company entered into an ATM arrangement, pursuant to which, the Company may, at its discretion, sell up to $30.0 million of the Company’s common stock through its sales agent, MLV.   Sales of common stock made under the ATM are made on The NASDAQ Global Market under the Company’s previously filed and currently effective Registration Statement on Form S-3 (File No. 333-191153) by means of ordinary brokers’ transactions at market prices. Additionally, under the terms of the ATM, the Company may also sell shares of its common stock through MLV, on The NASDAQ Global Market or otherwise, at negotiated prices or at prices related to the prevailing market price. Under the terms of the ATM, MLV may not engage in any proprietary trading or trading as principal for MLV’s own account. MLV uses its commercially reasonable efforts to sell the Company’s common stock from time to time, based upon the Company’s instructions (including any price, time or size limits or other customary parameters or conditions the Company may impose). The Company pays MLV a commission of up to 3% of the gross proceeds from the sale of shares of its common stock under the ATM. The Company has also agreed to provide MLV with customary indemnification rights. The offering of common stock pursuant to the ATM will terminate upon the earlier of the sale of all of the common stock subject to the ATM or the termination of the ATM by the Company or MLV. Either party may terminate the ATM at its sole discretion at any time upon written notice to the other party.

[0001564590-14-003115:notes:106]
During the three months ended June 30, 2014, the Company received net proceeds of $1.2 million, including sales commissions and offering expenses, from sales of approximately 0.8 million shares of its common stock at an average sales price of approximately $1.63 per share under the ATM.  As of June 30, 2014, the Company has approximately $20.8 million of remaining availability under the ATM.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001564590-14-003115:notes:107]
13. Commitments and Contingencies

[0001564590-14-003115:notes:108]
Commitments

[0001564590-14-003115:notes:109]
Purchase Commitments

[0001564590-14-003115:notes:110]
The Company periodically enters into non-cancelable purchase contracts in order to ensure the availability of materials to support production of its products. Purchase commitments represent enforceable and legally binding agreements with suppliers to purchase goods or services. The Company periodically assesses the need to provide for impairment on these purchase contracts and record a loss on purchase commitments when required. As of June 30, 2014, the Company reported a liability for adverse purchase commitments of $0.4 million. During the three months ended June 30, 2014 there was no material change to the accrual for adverse purchase commitments.

[0001564590-14-003115:notes:111]
Legal Contingencies

[0001564590-14-003115:notes:112]
From time to time, the Company is involved in legal and administrative proceedings and claims of various types. The Company records a liability in its consolidated financial statements for these matters when a loss is known or considered probable and the amount can be reasonably estimated. The Company reviews these estimates each accounting period as additional information is known and adjusts the loss provision when appropriate. If a matter is both probable to result in a liability and the amounts of loss can be reasonably estimated, the Company estimates and discloses the possible loss or range of loss. If the loss is not probable or cannot be reasonably estimated, a liability is not recorded in its consolidated financial statements.

[0001564590-14-003115:notes:113]
Between April 6, 2011 and May 12, 2011, seven putative securities class action complaints were filed against the Company and two of its officers in the United States District Court for the District of Massachusetts (the “Court”); one complaint additionally asserted claims against the underwriters who participated in its November 12, 2010 securities offering. On June 7, 2011, the Court consolidated these actions under the caption Lenartz v. American Superconductor Corporation, et al., Docket No. 1:11-cv-10582-WGY. On August 31, 2011, Lead Plaintiff, the Plumbers and Pipefitters National Pension Fund, filed a consolidated amended complaint against the Company, its officers and directors, and the underwriters who participated in its November 12, 2010 securities offering, asserting claims under sections 10(b) and 20(a) of the Securities Exchange Act of 1934, as amended (the “Exchange Act”) and Rule 10b-5 promulgated under the Exchange Act, as well as under sections 11, 12(a)(2) and 15 of the Securities Act. The complaint alleged that during the relevant class period, the Company and its officers omitted to state material facts and made materially false and misleading statements relating to, among other things, its projected and recognized revenues and earnings, as well as its relationship with Sinovel Wind Group Co., Ltd. that artificially inflated the value of the Company’s stock price. The complaint further alleged that the Company’s November 12, 2010 securities offering contained untrue statements of material facts and omitted to state material facts required to be stated therein. The plaintiffs sought unspecified damages, rescindment of the Company’s November 12, 2010 securities offering, and an award of costs and expenses, including attorney’s fees. All defendants moved to dismiss the consolidated amended complaint. On December 16, 2011, the Court issued a summary order declining to dismiss the Securities Act claims against the Company and its officers, and taking under advisement the motion to dismiss the Exchange Act claims against the Company and its officers and the motion to dismiss the Securities Act claims made against the underwriters. On July 26, 2012, the district court dismissed the Exchange Act claims against the Company and its officers and denied the motion to dismiss the Securities Act claims made against the underwriters. On May 17, 2013, the parties informed the Court that they had reached a settlement in principle, and requested a 30-day stay of the proceedings while the specific terms of the settlement continue to be negotiated. On November 19, 2013, the Company entered into a Stipulation and Agreement of Settlement (the “Stipulation”), which resolved the claims asserted against the Company, certain of its current and former officers and directors, and the underwriters. The terms of the Stipulation provided, among other things, a settlement payment by the Company of $10.0 million, $8.2 million of which was to be funded by the Company’s insurers and $1.8 million of which was paid through the issuance of 944,882 shares of its common stock (the “Settlement Shares”). In the event that the value of the Settlement Shares (as calculated under the Stipulation) decreased as of the effective date of the settlement, the Company was required to make a cash payment for the difference in value.  By a Final Judgment and Order of Dismissal with Prejudice entered on May 5, 2014, the Court approved the terms of the Stipulation and dismissed this private securities class action litigation.  In addition, the Court found that (i) the terms and conditions of the proposed issuance of the Settlement Shares are fair to those who receive these securities, and (ii) the terms and conditions of, and the procedures for, the proposed issuance of the Settlement Shares are fair.  The effective date of the Stipulation was June 5, 2014 (the “Effective Date”).  Pursuant to the terms of the Stipulation, (i) on June 11, 2014, the Company made a cash payment of approximately $0.5 million for the decrease in value of the Settlement Shares (as calculated under the Stipulation) as of the Effective Date, and (ii) on June 18, 2014, the Company issued the Settlement Shares.  The issuance of the Settlement Shares was exempt from registration pursuant to Section 3(a)(10) of the Securities Act.  The aforementioned payments by the Company represented the final amounts to be paid to the plaintiffs under the Stipulation.

[0001564590-14-003115:notes:114]
Between May 4, 2011 and June 17, 2011, four putative shareholder derivative complaints were filed against the Company (as a nominal defendant) and certain of its directors in the Court. On July 5, 2011, the Court consolidated three of these actions under the caption In re American Superconductor Corporation Derivative Litigation, Docket No. 1:11-cv-10784-WGY. On June 1, 2011, the plaintiff in the fourth action, Marlborough Family Revocable Trust v. Yurek, et al., moved to voluntarily dismiss its complaint and refiled its complaint in Superior Court for the Commonwealth of Massachusetts, Middlesex County. On September 7, 2011, the Marlborough action and another putative shareholder derivative complaint filed in Superior Court for the Commonwealth of Massachusetts were consolidated. That consolidated matter was captioned In re American Superconductor Corporation Shareholder Derivative Litigation, Docket No. 11-1961. On January 12, 2012, an additional shareholder derivative complaint was filed in the Court of Chancery for the State of Delaware. That matter was captioned Krasnoff v. Budhraja, et al., Docket No. 7171. The allegations of the derivative complaints mirrored the allegations made in the putative class action complaints described above. The plaintiffs purported to assert claims against the director defendants for breach of fiduciary duty, abuse of control, gross mismanagement, unjust enrichment and corporate waste.  On February 4, 2014, the Company entered into a Stipulation and Agreement of Settlement (the “Derivative Stipulation”) to settle In re American Superconductor Corporation Derivative Litigation, In re American Superconductor Corporation Shareholder Derivative Litigation, and Krasnoff v. Budhraja, et al., (together, the “Derivative Actions”). The Derivative Actions named certain current and former directors and officers of the Company as defendants. The current and former directors and officers named as individual defendants have denied expressly and continue to deny each and all of the claims and contentions alleged against them, and neither the individual defendants nor the Company have admitted any fault, wrongdoing or concession of liability in connection with the terms of the Derivative Stipulation. The Derivative Stipulation provided for, among other things, (a) a release of all claims relating to the Derivative Actions for the Company, the individual defendants, who are all current or former officers and directors of the Company, and the plaintiffs; (b) a requirement that the Company pay to plaintiffs’ counsel $475,000 for fees and expenses, which was fully funded by the Company’s insurers; and (c) certain additions to the Company’s corporate governance policies. The terms of the Derivative Stipulation were subject to approval by the Court following notice to stockholders. By order entered May 8, 2014, the Court approved the terms of the Derivative Stipulation and issued a final judgment dismissing In re American Superconductor Corporation Derivative Litigation.  Pursuant to the terms of the Derivative Stipulation, the Company and the plaintiffs subsequently jointly sought and obtained dismissal of In re American Superconductor Corporation Shareholder Derivative Litigation, and Krasnoff v. Budhraja, et al. The effective date of the settlement was June 10, 2014.

[0001564590-14-003115:notes:115]
On September 13, 2011, the Company commenced a series of legal actions in China against Sinovel Wind Group Co. Ltd. (“Sinovel”). The Company’s Chinese subsidiary, Suzhou AMSC Superconductor Co. Ltd., filed a claim for arbitration with the Beijing Arbitration Commission in accordance with the terms of the Company’s supply contracts with Sinovel. The case is captioned (2011) Jing Zhong An Zi No. 0963. On March 31, 2011, Sinovel refused to accept contracted shipments of 1.5 megawatt, (“MW”) and 3 MW wind turbine core electrical components and spare parts that the Company was prepared to deliver. The Company alleges that these actions constitute material breaches of its contracts because Sinovel did not give it notice that it intended to delay deliveries as required under the contracts. Moreover, the Company alleges that Sinovel has refused to pay past due amounts for prior shipments of core electrical components and spare parts. The Company is seeking compensation for past product shipments and retention (including interest) in the amount of approximately RMB 485 million ($76 million) due to Sinovel’s breaches of its contracts. The Company is also seeking specific performance of its existing contracts as well as reimbursement of all costs and reasonable expenses with respect to the arbitration. The value of the undelivered components under the existing contracts, including the deliveries refused by Sinovel in March 2011, amounts to approximately RMB 4.6 billion ($720 million).

[0001564590-14-003115:notes:116]
On October 8, 2011, Sinovel filed with the Beijing Arbitration Commission an application under the caption (2011) Jing Zhong An Zi No. 0963, for a counterclaim against the Company for breach of the same contracts under which the Company filed its original arbitration claim. Sinovel claimed, among other things, that the goods supplied by the Company do not conform to the standards specified in the contracts and claimed damages in the amount of approximately RMB 370 million ($58 million). On October 17, 2011, Sinovel filed with the Beijing Arbitration Commission a request for change of counterclaim to increase its damage claim to approximately RMB 1 billion ($157 million). On December 22, 2011, Sinovel filed with the Beijing Arbitration Commission an additional request for change of counterclaim to increase its damages claim to approximately RMB 1.2 billion ($190 million). On February 27, 2012, Sinovel filed with the Beijing Arbitration Commission an application under the caption (2012) Jing Zhong An Zi No. 0157, against the Company for breach of the same contracts under which the Company filed its original arbitration claim. Sinovel claimed, among other things, that the goods supplied by the Company do not conform to the standards specified in the contracts and claimed damages in the amount of approximately RMB 105 million ($17 million). The Company believes that Sinovel’s claims are without merit and it intends to defend these actions vigorously. Since the proceedings in this matter are in relatively early stages, the Company cannot reasonably estimate possible losses or range of losses at this time.

[0001564590-14-003115:notes:117]
The Company also submitted a civil action application to the Beijing No. 1 Intermediate People’s Court under the caption (2011) Yi Zhong Min Chu Zi No. 15524, against Sinovel for software copyright infringement on September 13, 2011. The application alleges Sinovel’s unauthorized use of portions of the Company’s wind turbine control software source code developed for Sinovel’s 1.5MW wind turbines and the binary code, or upper layer, of the Company’s software for the PM3000 power converters in 1.5MW wind turbines. In July 2011, a former employee of the Company’s Austrian subsidiary was arrested in Austria on charges of economic espionage and fraudulent manipulation of data. In September 2011, the former employee pled guilty to the charges, and was imprisoned. As a result of the Company’s internal investigation and a criminal investigation conducted by Austrian authorities, the Company believes that this former employee was contracted by Sinovel through an intermediary while employed by the Company and improperly obtained and transferred to Sinovel portions of its wind turbine control software source code developed for Sinovel’s 1.5MW wind turbines. Moreover, the Company believes the former employee illegally used source code to develop for Sinovel a software modification to circumvent the encryption and remove technical protection measures on the Company’s PM3000 power converters in 1.5MW wind turbines in the field. The Company is seeking a cease and desist order with respect to the unauthorized copying, installation and use of its software, monetary damages of approximately RMB 38 million ($6 million) for its economic losses and reimbursement of all costs and reasonable expenses. The Beijing No. 1 Intermediate People’s Court accepted the case, which was necessary in order for the case to proceed. In November 2011, Sinovel filed a motion to remove this case from the Beijing No. 1 Intermediate People’s Court and transfer the matter to the Beijing Arbitration Commission. On February 14, 2012, the court denied Sinovel’s motion to remove the case. On February 21, 2012, Sinovel filed an appeal of the Beijing No. 1 Intermediate People’s Court decision to the Beijing Higher People’s Court. On April 25, 2012, the Beijing Higher People’s Court issued a final Civil Ruling which supports the Beijing No.1 Intermediate People’s Court’s civil ruling and rejected Sinovel’s appeal. Sinovel filed an appeal of the Beijing Higher People’s Court’s decision with China’s Supreme People’s Court. A hearing regarding this appeal was held at the Chinese Supreme People’s Court on October 26, 2012. On November 23, 2012, China’s Supreme People’s Court issued a Civil Ruling, holding that (1) it will conduct a re-trial of Sinovel’s appeal, and (2) the lower court’s decision will be stayed pending the re-trial. China’s Supreme People’s Court conducted a re-trial of Sinovel’s appeal on May 29, 2013.  On January 26, 2014, the Supreme People’s Court ruled to uphold the Beijing Higher People’s Court ruling that the dispute shall be heard by the court.  The Company will now await a hearing date from the Beijing No. 1 Intermediate People’s Court.

[0001564590-14-003115:notes:118]
The Company submitted a civil action application to the Beijing Higher People’s Court against Sinovel and certain of its employees for trade secret infringement on September 13, 2011 under the caption (2011) Gao Min Chu Zi No. 4193. The application alleges the defendants’ unauthorized use of portions of the Company’s wind turbine control software source code developed for Sinovel’s 1.5MW wind turbines as described above with respect to the Copyright Action. The Company is seeking monetary damages of RMB 2.9 billion ($453 million) for the trade secret infringement as well as reimbursement of all costs and reasonable expenses. The Beijing Higher People’s Court accepted the case, which was necessary in order for the case to proceed. On December 22, 2011, the Beijing Higher People’s Court transferred this case to the Beijing No. 1 Intermediate People’s Court under the caption (2011) Gao Min Chu Zi No. 4193. On June 7, 2012, the Company received an Acceptance Notice from the Beijing No.1 Intermediate People’s Court under the caption (2012) Yi Zhong Min Chu Zi No.6833. The Company is currently awaiting notice from the Beijing No. 1 Intermediate People’s Court regarding the first hearing date. In August 2012, Sinovel filed a motion to remove this case from the Beijing No. 1 Intermediate People’s Court and transfer the matter to the Beijing Arbitration Commission. On February 24, 2014, the Beijing No. 1 Intermediate People’s Court denied Sinovel’s motion to remove the case.  On March 13, 2014, Sinovel filed an appeal of the Beijing No. 1 Intermediate People’s Court decision to the Beijing Higher People’s Court.  The Company is currently awaiting the final decision from the Beijing Higher People’s Court regarding the jurisdiction opposition issue.

[0001564590-14-003115:notes:119]
On September 16, 2011, the Company filed a civil copyright infringement complaint in the Hainan Province No. 1 Intermediate People’s Court against Dalian Guotong Electric Co. Ltd. (“Guotong”), a supplier of power converter products to Sinovel, and Huaneng Hainan Power, Inc. (“Huaneng”), a wind farm operator that has purchased Sinovel wind turbines containing Guotong power converter products. The case is captioned (2011) Hainan Yi Zhong Min Chu Zi No. 62. The application alleges that the Company’s PM1000 converters in certain Sinovel wind turbines have been replaced by converters produced by Guotong. Because the Guotong converters are being used in wind turbines containing the Company’s wind turbine control software, the Company believes that its copyrighted software is being infringed. The Company is seeking a cease and desist order with respect to the unauthorized use of its software, monetary damages of RMB 1.2 million ($0.2 million) for its economic losses (with respect to Guotong only) and reimbursement of all costs and reasonable expenses. The court has accepted the case, which was necessary in order for the case to proceed. In addition, upon the request of the defendant Huaneng, Sinovel has been added by the court to this case as a defendant and Huaneng has been released from this case. In December 2011, Sinovel filed a jurisdiction opposition motion requesting dismissal by the Hainan Province No. 1 Intermediate People’s Court, saying the case should be governed by the Beijing Arbitration Commission. On February 3, 2012, the Company received the Civil Ruling from the court, which granted Sinovel’s motion, and dismissed the entire case. The Company appealed the court’s ruling to the Hainan Higher Court, which on April 5, 2012 upheld the decision of the Hainan Province No. 1 Intermediate People’s Court. On April 9, 2012, the Company filed an appeal of the Hainan Higher Court’s decision with China’s Supreme People’s Court. China’s Supreme People’s Court accepted the appeal on May 23, 2012. The case is captioned, (2012) Min Shen Zi No. 630. On December 20, 2012, China’s Supreme People’s Court issued a Civil ruling, holding that (1) it will conduct a re-trial of the Company’s appeal and (2) the lower court’s decision will be stayed pending the re-trial. China’s Supreme People’s Court conducted a re-trial of Sinovel’s appeal on May 29, 2013.  On January 26, 2014, the Supreme People’s Court revoked Hainan No. 1 Intermediate People’s Court and Hainan Higher People’s Court rulings and ruled that the case shall be heard by the Hainan No. 1 Intermediate People’s Court.  The Hainan No. 1 Intermediate People’s Court accepted the case under the caption (2014) Hainan Yi Zhong Min San Chu Zi No. 1.

[0001564590-14-003115:notes:120]
Ghodawat Energy Pvt Ltd (“Ghodawat”), a company registered in India carrying on the business of wind power development, lodged a Request for Arbitration with the Secretariat of the ICC International Court of Arbitration (the “ICC Court”) on May 12, 2011 and named AMSC Windtec GmbH (“AMSC Austria”) as the Respondent. Under the Request for Arbitration, Ghodawat alleges that AMSC Austria breached an agreement dated March 19, 2008 pursuant to which AMSC Austria granted a license to Ghodawat to manufacture, use, sell, market, erect, commission and maintain certain wind turbines using its technical information and wind turbine design (the “License Agreement”). Under the Request for Arbitration, Ghodawat’s claims in this arbitration amount to approximately €18 million ($24 million). AMSC Austria filed an Answer to Request for Arbitration and Counterclaim (“Answer and Counterclaim”), in which AMSC Austria denied Ghodawat’s claims in their entirety. AMSC Austria has also submitted counterclaims under the License Agreement against Ghodawat in the amount of approximately €6 million ($8 million). Ghodawat has filed a Reply to Answer to Request for Arbitration and Counterclaim in which it denies AMSC Austria’s counterclaims. On June 3, 2013, the final oral submissions’ hearing was conducted.  The final award is pending and the ICC Court has extended the time limit for the Tribunal to render a final award on a number of occasions.  The Company expects that the award will be issued in 2014; however, it cannot assure you that the issuance of the award will not be delayed.  The Company has recorded a loss contingency based on its assessment of probable losses on this claim; however, this amount is immaterial to its consolidated financial statements.

[0001564590-14-003115:notes:121]
Other

[0001564590-14-003115:notes:122]
The Company enters into long-term construction contracts with customers that require the Company to obtain performance bonds. The Company is required to deposit an amount equivalent to some or all the face amount of the performance bonds into an escrow account until the termination of the bond. When the performance conditions are met, amounts deposited as collateral for the performance bonds are returned to the Company. In addition, the Company has various contractual arrangements in which minimum quantities of goods or services have been committed to be purchased on an annual basis.

[0001564590-14-003115:notes:123]
As of June 30, 2014 the Company had $6.1 million of restricted cash included in current assets, and $0.1 million of restricted cash included in long-term assets. These amounts included in restricted cash represent deposits to secure letters of credit for various supply contracts. These deposits are held in interest bearing accounts.

[0001564590-14-003115:notes:124]
The Company had an unused, unsecured line of credit consisting of €2.7 million (approximately $3.7 million) in Austria as of June 30, 2014.


## us-gaap:EquityMethodInvestmentsDisclosureTextBlock

[0001564590-14-003115:notes:125]
[same as prior period, unchanged from 0001564590-14-000165:notes:136]

[0001564590-14-003115:notes:126]
[same as prior period, unchanged from 0001564590-14-000165:notes:137]

[0001564590-14-003115:notes:127]
The Company made an investment in Tres Amigas LLC, a Delaware limited liability company (“Tres Amigas”), focused on providing the first common interconnection of America’s three power grids to help the country achieve its renewable energy goals and facilitate the smooth, reliable and efficient transfer of green power from region to region.  The Company’s original investment in Tres Amigas was $5.4 million.  As of June 30, 2014, the Company holds a 26% ownership interest in Tres Amigas.

[0001564590-14-003115:notes:128]
The Company has determined that Tres Amigas is a variable interest entity (“VIE”) and that the Company is not the primary beneficiary of the VIE.  Therefore, the Company has not consolidated Tres Amigas as of June 30, 2014.  The investment is carried at acquisition cost, plus the Company’s equity in undistributed earnings or losses.  The Company’s maximum exposure to loss is limited to the Company’s recorded investment in this VIE.  The Company’s investment in Tres Amigas is included in other assets on the consolidated balance sheet and the equity in undistributed losses of Tres Amigas is included in other expense, net, on the unaudited condensed consolidated statements of operations.

[0001564590-14-003115:notes:129]
The net investment activity for the three months ended June 30, 2014 is as follows (in thousands):

[0001564590-14-003115:notes:130]
| Balance at April 1, 2014 | $ | 1,845 |  |
| Minority interest in net losses |  | (202 | ) |
| Balance at June 30, 2014 | $ | 1,643 |  |

[0001564590-14-003115:notes:131]
[same as prior period, unchanged from 0001564590-14-000165:notes:142]

[0001564590-14-003115:notes:132]
The Company has acquired (through its Austrian subsidiary), a minority ownership position in Blade Dynamics Ltd. (“Blade Dynamics”), a designer and manufacturer of advanced wind turbine blades based on proprietary materials and structural technologies.  The Company’s original investment was for $8.0 million in cash. As of June 30, 2014, the Company holds a 19% ownership interest in Blade Dynamics.

[0001564590-14-003115:notes:133]
The investment is carried at the acquisition cost, plus the Company’s equity in undistributed earnings or losses, through December 1, 2012, the date which the company no longer reports undistributed earnings or losses. The Company’s investment in Blade Dynamics is included in other assets on the unaudited condensed consolidated balance sheet and the equity in undistributed losses of Blade Dynamics is included in other expense, net, on the unaudited condensed consolidated statements of operations.

[0001564590-14-003115:notes:134]
During the year ended March 31, 2014, the Company determined that as a result of its efforts to sell its investment in Blade Dynamics, certain indicators of impairment existed which required the Company to perform further analysis.  As a result of this analysis, the Company recorded an impairment charge for approximately $1.3 million.

[0001564590-14-003115:notes:135]
| Balance at April 1, 2014 | $ | 3,690 |  |
| Net foreign exchange rate impact |  | (29 | ) |
| Balance at June 30, 2014 | $ | 3,661 |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001564590-14-003115:notes:136]
[same as prior period, unchanged from 0001564590-14-000165:notes:146]

[0001564590-14-003115:notes:137]
The Company reports its financial results in two reportable business segments: Wind and Grid.

[0001564590-14-003115:notes:138]
Through its Windtec Solutions, the Wind business segment enables manufacturers to field wind turbines with highly competitive power output, reliability and affordability. The Company supplies advanced power electronics and control systems, licenses its highly engineered wind turbine designs, and provides extensive customer support services to wind turbine manufacturers. Its design portfolio includes a broad range of drive trains and power ratings of 2 MWs and higher. It provides a broad range of power electronics and software-based control systems that are highly integrated and designed for optimized performance, efficiency, and grid compatibility.

[0001564590-14-003115:notes:139]
[same as prior period, unchanged from 0001564590-14-000165:notes:149]

[0001564590-14-003115:notes:140]
[same as prior period, unchanged from 0001564590-14-000165:notes:150]

[0001564590-14-003115:notes:141]
|  | For the Three Months Ended June 30, |  |
|  | 2014 |  |  | 2013 |  |
| Revenues: |  |  |  |  |  |  |  |
| Wind | $ | 7,650 |  |  | $ | 14,701 |  |
| Grid |  | 4,046 |  |  |  | 8,385 |  |
| Total | $ | 11,696 |  |  | $ | 23,086 |  |

[0001564590-14-003115:notes:142]
|  | For the Three Months Ended June 30, |  |
|  | 2014 |  |  | 2013 |  |
| Operating loss: |  |  |  |  |  |  |  |
| Wind | $ | (3,480 | ) |  | $ | (1,825 | ) |
| Grid |  | (6,407 | ) |  |  | (4,869 | ) |
| Unallocated corporate expenses |  | (2,780 | ) |  |  | (2,156 | ) |
| Total | $ | (12,667 | ) |  | $ | (8,850 | ) |

[0001564590-14-003115:notes:143]
The accounting policies of the business segments are the same as those for the consolidated Company. The Company’s business segments have been determined in accordance with the Company’s internal management structure, which is organized based on operating activities. The Company evaluates performance based upon several factors, of which the primary financial measures are segment revenues and segment operating loss. The disaggregated financial results of the segments reflect allocation of certain functional expense categories consistent with the basis and manner in which Company management internally disaggregates financial information for the purpose of assisting in making internal operating decisions. In addition, certain corporate expenses which the Company does not believe are specifically attributable or allocable to either of the two business segments have been excluded from the segment operating loss.

[0001564590-14-003115:notes:144]
Unallocated corporate expenses primarily consist of stock-based compensation expense of $1.6 million, and restructuring charges of $1.2 million, for the three months ended June 30, 2014. Unallocated corporate expenses primarily consist of stock-based compensation expense of $2.1 million for the three months ended June 30, 2013.

[0001564590-14-003115:notes:145]
[same as prior period, unchanged from 0001564590-14-000165:notes:155]

[0001564590-14-003115:notes:146]
|  | June 30, |  |  | March 31, |  |
|  | 2014 |  |  | 2014 |  |
| Wind | $ | 44,814 |  |  | $ | 36,701 |  |
| Grid |  | 47,403 |  |  |  | 54,342 |  |
| Corporate assets |  | 68,341 |  |  |  | 77,466 |  |
| Total | $ | 160,558 |  |  | $ | 168,509 |  |

[0001564590-14-003115:notes:147]
The following table sets forth customers who represented 10% or more of the Company’s total revenues for the three months ended June 30, 2014 and 2013:

[0001564590-14-003115:notes:148]
|  | Three months ended |  |
|  | June 30, |  |
|  | 2014 |  |  | 2013 |  |
| INOX Wind Limited |  | 48 | % |  |  | 15 | % |
| Beijing JINGCHENG New Energy Co., Ltd |  | <10 | % |  |  | 35 | % |


## us-gaap:NewAccountingPronouncementsAndChangesInAccountingPrinciplesTextBlock

[0001564590-14-003115:notes:149]
16. Recent Accounting Pronouncements

[0001564590-14-003115:notes:150]
In January 2013, the FASB issued Accounting Standards Update No. 2013-01, Balance Sheet (Topic 210): Clarifying the Scope of Disclosures about Offsetting Assets and Liabilities (ASU 2013-01). The main objective in developing this update is to address implementation issues about the scope of Accounting Standards Update No. 2011-11, Balance Sheet (Topic 210): Disclosures about Offsetting Assets and Liabilities. The update requires entities to disclose information about offsetting and related arrangements of financial instruments and derivative instruments. ASU 2013-01 is effective for the Company’s first quarter of fiscal 2014. The Company adopted ASU 2013-01 in the first quarter of fiscal 2014, and there was no significant effect on its consolidated results of operations, financial condition, or cash flows.

[0001564590-14-003115:notes:151]
In May 2014, the FASB and the International Accounting Standards Board (IASB) issued, ASU Revenue from Contracts with Customers 2014-09 (Topic 606), The guidance substantially converges final standards on revenue recognition between the FASB and IASB providing a framework on addressing revenue recognition issues and, upon its effective date, replaces almost all exiting revenue recognition guidance, including industry-specific guidance, in current U.S. generally accepted accounting principles.  The ASU is effective for annual reporting periods beginning after December 15, 2016.  The Company is currently evaluating the impact of adopting ASU 2014-09 to determine the impact, if any, it may have on its current practices.

[0001564590-14-003115:notes:152]
In July 2014, the FASB issued ASU 2014-12, Compensation – Stock Compensation (Topic 718): Accounting for Share Based Payments When the Terms of an Award Provide that a Performance Target could be Achieved after the Requisite Service Period.    To account for such awards, a reporting entity should apply existing guidance in FASB Accounting Standards Codification Topic 718, Compensation – Stock Compensation, as it relates to awards with performance conditions that affect vesting.  As such, the performance target should not be reflected in estimating the grant-date fair value of the award. This ASU is effective for annual reporting periods and interim periods, within those annual periods beginning after December 15, 2015.  The Company is currently evaluating the impact of adopting ASU 2014-12 to determine the impact, if any, it may have on its current practices.

[0001564590-14-003115:notes:153]
The Company does not believe that other recently issued accounting pronouncements will have a material impact on its financial statements.


## us-gaap:SubsequentEventsTextBlock

[0001564590-14-003115:notes:154]
17. Subsequent Events

[0001564590-14-003115:notes:155]
The Company has performed an evaluation of subsequent events through the time of filing this Quarterly Report on Form 10-Q with the SEC, and has determined that there are no such events that are required to be disclosed.
