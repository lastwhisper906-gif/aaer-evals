# AMSC MD&A — 0001564590-14-003115


## mdna

[0001564590-14-003115:mdna:1]
[same as prior period, unchanged from 0001564590-14-000165:mdna:1]

[0001564590-14-003115:mdna:2]
manufactured our Amperium wire in commercial quantities, and a failure to manufacture our Amperium wire in commercial quantities at acceptable cost and quality levels would substantially limit our future revenue and profit potential; Third parties have or may acquire patents that cover the materials, processes and technologies we use or may use in the future to manufacture our Amperium products, and our success depends on our ability to license such patents or other proprietary rights; Our technology and products could infringe intellectual property rights of others, which may require costly litigation and, if we are not successful, could cause us to pay substantial damages and disrupt our business; We have filed a demand for arbitration and other lawsuits against our former largest customer, Sinovel, regarding amounts we contend are overdue. We cannot be certain as to the outcome of these proceedings; We have been named as a party in various legal proceedings, and we may be named in additional litigation, all of which will require significant management time and attention, result in significant legal expenses and may result in an unfavorable outcome, which could have a material adverse effect on our business, operating results and financial condition; Our common stock has experienced, and may continue to experience, significant market price and volume fluctuations, which may prevent our stockholders from selling our common stock at a profit and could lead to costly litigation against us that could divert our management’s attention. These and the important factors discussed under the caption “Risk Factors” in Part 1. Item 1A of our Form 10-K for the fiscal year ended March 31, 2014, among others, could cause actual results to differ materially from those indicated by forward-looking statements made herein and presented elsewhere by management from time to time. Any such forward-looking statements represent management’s estimates as of the date of this Quarterly Report on Form 10-Q. While we may elect to update such forward-looking statements at some point in the future, we disclaim any obligation to do so, even if subsequent events cause our views to change. These forward-looking statements should not be relied upon as representing our views as of any date subsequent to the date of this Quarterly Report on Form 10-Q.

[0001564590-14-003115:mdna:3]
American Superconductor®, Amperium®, AMSC®, D-VAR®, PowerModuleTM, PQ-IVR®, SeaTitanTM, Gridtec SolutionsTM, Windtec SolutionsTM and Smarter, Cleaner... Better EnergyTM are trademarks or registered trademarks of American Superconductor Corporation or our subsidiaries. We reserve all of our rights with respect to our trademarks or registered trademarks regardless of whether they are so designated in this Quarterly Report on Form 10-Q by an ® or TM symbol. All other brand names, product names, trademarks or service marks appearing in this Quarterly Report on Form 10-Q are the property of their respective holders.

[0001564590-14-003115:mdna:4]
[same as prior period, unchanged from 0001564590-14-000165:mdna:4]

[0001564590-14-003115:mdna:5]
[same as prior period, unchanged from 0001564590-14-000165:mdna:5]

[0001564590-14-003115:mdna:6]
Our wind and power grid solutions help to improve energy efficiency, alleviate power grid capacity constraints and increase the adoption of renewable energy generation. Demand for our solutions is driven by the growing needs for renewable sources of electricity, such as wind and solar energy, and for modernized smart grids that improve power reliability, security and quality. Concerns about these factors have led to increased spending by corporations as well as supportive government regulations and initiatives on local, state, national and global levels, including renewable portfolio standards, tax incentives and international treaties.

[0001564590-14-003115:mdna:7]
[same as prior period, unchanged from 0001564590-14-000165:mdna:7]

[0001564590-14-003115:mdna:8]
[same as prior period, unchanged from 0001564590-14-000165:mdna:9]

[0001564590-14-003115:mdna:9]
[same as prior period, unchanged from 0001564590-14-000165:mdna:10]

[0001564590-14-003115:mdna:10]
| — | Grid. Through our Gridtec Solutions, our Grid business segment enables electric utilities and renewable energy project developers to connect, transmit and distribute power with exceptional efficiency, reliability, security and affordability. We provide transmission planning services that allow us to identify power grid congestion, poor power quality and other risks, which help us determine how our solutions can improve network performance. These services often lead to sales of grid interconnection solutions for wind farms and solar power plants, power quality systems and transmission and distribution cable systems. |

[0001564590-14-003115:mdna:11]
Our fiscal year begins on April 1 and ends on March 31. When we refer to a particular fiscal year, we are referring to the fiscal year beginning on April 1 of that same year. For example, fiscal 2014 refers to the fiscal year beginning on April 1, 2014. Other fiscal years follow similarly.

[0001564590-14-003115:mdna:12]
On June 5, 2012 we entered into a $10.0 million Loan and Security Agreement (“Term Loan”) with Hercules Technology Growth Capital, Inc. (“Hercules”).  On November 15, 2013, we amended the Term Loan with Hercules and entered into a new term loan (“New Term Loan”), borrowing an additional $10.0 million.  In addition, on November 15, 2013, we entered into an At Market Sales Arrangement (“ATM”) under which we may, at our discretion, sell up to $30.0 million of shares of our common stock (before expenses) through our sales agent, MLV & Co. LLC (“MLV”).  See Liquidity and Capital Resources below for further discussion of these financing arrangements.

[0001564590-14-003115:mdna:13]
We have experienced recurring operating losses and as of June 30, 2014, had an accumulated deficit of $869.9 million. In addition, we have experienced recurring negative operating cash flows. At June 30, 2014, we had cash and cash equivalents of $36.6 million. Cash used in operations for the three months ended June 30, 2014 was $5.5 million.  As of June 30, 2014, there was approximately $20.8 million of availability under our ATM arrangement.  Sales of common stock under the ATM may be made from time to time, at our discretion, in order to enhance liquidity.  In addition, we are actively seeking to sell our minority investments in Tres Amigas and Blade Dynamics and have engaged a financial advisor to assist with that effort. There can be no assurance that we will be able to sell one or both of these investments on commercially reasonable terms or at all.

[0001564590-14-003115:mdna:14]
In response to the Sinovel situation discussed below and challenging market conditions, particularly in the wind power market, from April 1, 2011 through the date of this filing, we have reduced our global workforce substantially.  In addition, we plan to consolidate certain of our office locations.  These workforce reductions and planned office reductions are expected to lower operating costs and enhance liquidity.

[0001564590-14-003115:mdna:15]
Our cash requirements depend on numerous factors, including the successful completion of our product development activities, our ability to commercialize our Resilient Electric Grid (“REG”) and degaussing system solutions, rate of customer and market adoption of our products, collecting receivables according to established terms, and the continued availability of U.S. government funding during the product development phase in our Superconductors business. Significant deviations to our business plan with regard to these factors, which are important drivers to our business, could have a material adverse effect on our operating performance, financial condition, and future business prospects. We expect to pursue the expansion of our operations through internal growth, diversification of our customer base, and potential strategic alliances. See below for a discussion of liquidity and capital resources.

[0001564590-14-003115:mdna:16]
On March 31, 2011, Sinovel Wind Group Co., Ltd. (“Sinovel”) refused to accept contracted scheduled shipments with a revenue value of approximately $65.2 million. In addition, as of March 31, 2011, we had approximately $62.0 million of receivables (excluding value-added tax) outstanding from Sinovel. As of the date of this filing, we have not received payment from Sinovel for these outstanding receivables that are now past due, nor have we been notified as to when, if ever, they will accept contracted shipments that were scheduled for delivery after March 31, 2011. No payment has been received from Sinovel since early March 2011. Because Sinovel did not give us notice that it intended to delay deliveries as required under the contracts, we believe that these actions constitute material breaches of our contracts. Additionally, we believe that Sinovel illegally obtained and used our intellectual property in violation of civil and criminal intellectual property laws.

[0001564590-14-003115:mdna:17]
[same as prior period, unchanged from 0001564590-14-000165:mdna:20]

[0001564590-14-003115:mdna:18]
We cannot provide any assurance as to the outcome of these legal actions. For more information about these legal proceedings, see Part II, Item 1, “Legal Proceedings.”

[0001564590-14-003115:mdna:19]
[same as prior period, unchanged from 0001564590-14-000165:mdna:23]

[0001564590-14-003115:mdna:20]
The preparation of the unaudited condensed consolidated financial statements requires that we make estimates and judgments that affect the reported amounts of assets, liabilities, revenues and expenses, and related disclosure of contingent assets and liabilities. We base our estimates on historical experience and various other assumptions that are believed to be reasonable under the circumstances, the results of which form the basis for making judgments about the carrying values of assets and liabilities that are not readily apparent from other sources. Actual results may differ under different assumptions or conditions. There were no significant changes in the critical accounting policies during the three months ended June 30, 2014 that were disclosed in our Form 10-K for fiscal 2013, which ended on March 31, 2014.

[0001564590-14-003115:mdna:21]
[same as prior period, unchanged from 0001564590-14-000165:mdna:25]

[0001564590-14-003115:mdna:22]
Three months ended June 30, 2014 compared to the three months ended June 30, 2013

[0001564590-14-003115:mdna:23]
[same as prior period, unchanged from 0001564590-14-000165:mdna:27]

[0001564590-14-003115:mdna:24]
Total revenues decreased by 49% to $11.7 million for the three months ended June 30, 2014, compared to $23.1 million for the three months ended June 30, 2013. Our revenues are summarized as follows (in thousands):

[0001564590-14-003115:mdna:25]
|  | Three Months Ended June 30, |  |
|  | 2014 |  |  | 2013 |  |
| Revenues: |  |  |  |  |  |  |  |
| Wind | $ | 7,650 |  |  | $ | 14,701 |  |
| Grid |  | 4,046 |  |  |  | 8,385 |  |
| Total | $ | 11,696 |  |  | $ | 23,086 |  |

[0001564590-14-003115:mdna:26]
Our Wind business unit accounted for 65% of total revenues for the three months ended June 30, 2014, compared to 64% for the three months ended June 30, 2013. Revenues in the Wind business unit decreased 48% to $7.7 million in the three months ended June 30, 2014, from $14.7 million in the three months ended June 30, 2013. Wind business unit revenues during the three months ended June 30, 2014 decreased primarily due to lower revenues from customers in China, partially offset by higher revenues from Inox Wind Limited in India.

[0001564590-14-003115:mdna:27]
Our Grid business unit accounted for 35% of total revenues for the three months ended June 30, 2014, compared to 36% for the three months ended June 30, 2013. Our Grid business unit revenues decreased 52% to $4.0 million in the three months ended June 30, 2014, from $8.4 million in the three months ended June 30, 2013. Grid business unit revenues decreased in the three months ended June 30, 2014 primarily due to lower D-VAR system revenues.

[0001564590-14-003115:mdna:28]
Project HYDRA is a project with Consolidated Edison, Inc. which is being partially funded by the Department of Homeland Security (“DHS”). DHS is expected to invest up to a total of $29.0 million in the development of a new HTS power grid technology called Resilient Electric Grid systems. This fault current limiting cable system is designed to utilize customized Amperium® HTS wires, and ancillary controls to deliver more power through the grid while also being able to suppress power surges that can disrupt service. DHS has now committed 100% of the total expected funding for this project. Consolidated Edison and Southwire Company are our subcontractors on this project. We recorded $0.2 million of revenue on this project for both the three month periods ended June 30, 2014, and 2013, respectively.

[0001564590-14-003115:mdna:29]
The following table sets forth customers who represented 10% or more of our total revenues for the three months ended June 30, 2014 and 2013:

[0001564590-14-003115:mdna:30]
|  | Three months ended |  |
|  | June 30, |  |
|  | 2014 |  |  | 2013 |  |
| INOX Wind Limited |  | 48 | % |  |  | 15 | % |
| Beijing JINGCHENG New Energy Co., Ltd | <10 | % |  |  | 35 | % |

[0001564590-14-003115:mdna:31]
[same as prior period, unchanged from 0001564590-14-000165:mdna:36]

[0001564590-14-003115:mdna:32]
Cost of revenues were $12.1 million for the three months ended June 30, 2014, compared to $18.0 million for the three months ended June 30, 2013. Gross margin was (3.3%) and 22.1% for the three months ended June 30, 2014, and 2013, respectively. The

[0001564590-14-003115:mdna:33]
decrease in gross margin for the three months ended June 30, 2014 as compared to the same period in fiscal 2013 was primarily due to 100% margin revenue in the prior year.

[0001564590-14-003115:mdna:34]
[same as prior period, unchanged from 0001564590-14-000165:mdna:38]

[0001564590-14-003115:mdna:35]
[same as prior period, unchanged from 0001564590-14-000165:mdna:39]

[0001564590-14-003115:mdna:36]
[same as prior period, unchanged from 0001564590-14-000165:mdna:40]

[0001564590-14-003115:mdna:37]
|  | Three Months Ended |  |
|  | June 30, |  |
|  | 2014 |  |  | 2013 |  |
| R&D expenses per consolidated statements of operations | $ | 3,120 |  |  | $ | 3,027 |  |
| R&D expenditures reclassified as cost of revenues |  | 2,075 |  |  |  | 1,926 |  |
| R&D expenditures offset by cost-sharing funding |  | 26 |  |  |  | 82 |  |
| Aggregated R&D expenses | $ | 5,221 |  |  | $ | 5,035 |  |

[0001564590-14-003115:mdna:38]
R&D expenses (exclusive of amounts classified as cost of revenues and amounts offset by cost-sharing funding) increased by 3% to $3.1 million for the three months ended June 30, 2014, from $3.0 million for the three months ended June 30, 2013. The increase in R&D expenses was driven primarily by cost of living adjustments on salaries. The increase in R&D expenditures reclassified to cost of revenue was a result of increased activity under government funded contracts in our Grid business unit compared to the prior year period. Aggregated R&D expenses, which include amounts classified as cost of revenues and amounts offset by cost-sharing funding, increased 4% to $5.2 million for the three months ended June 30, 2014, from $5.0 million for the three months ended June 30, 2013.

[0001564590-14-003115:mdna:39]
We present aggregated R&D, which is a non-GAAP measure, because we believe this presentation provides useful information on our aggregate R&D spending and because R&D expenses as reported on the unaudited condensed consolidated statements of income have been, and may in the future be, subject to significant fluctuations solely as a result of changes in the level of externally funded contract development work, resulting in significant changes in the amount of the costs recorded as cost of revenues rather than as R&D expenses, as discussed above.

[0001564590-14-003115:mdna:40]
[same as prior period, unchanged from 0001564590-14-000165:mdna:44]

[0001564590-14-003115:mdna:41]
SG&A expenses decreased by 27% to $7.9 million in the three months ended June 30, 2014, from $10.8 million in the three months ended June 30, 2013. The decrease in SG&A expenses was due primarily to the realization of savings from cost reduction actions that were implemented in prior periods as well as a reduction in audit and legal costs.

[0001564590-14-003115:mdna:42]
[same as prior period, unchanged from 0001564590-14-000165:mdna:46]

[0001564590-14-003115:mdna:43]
We recorded amortization expense related to our core technology and know-how, trade names and trademark intangible assets of less than $0.1 million in the three months ended June 30, 2014, compared to $0.1 million in the three months ended June 30, 2013.

[0001564590-14-003115:mdna:44]
[same as prior period, unchanged from 0001564590-14-000165:mdna:48]

[0001564590-14-003115:mdna:45]
We recorded $1.2 million of restructuring charges in the three months ended June 30, 2014. We recorded restructuring charges of less than $0.1 million in the three months ended June 30, 2013. The amounts in the three months ended June 30, 2014 consist primarily of employee severance and benefit costs related to the consolidation of the Grid manufacturing operations in the United States and a reduction in force in our operation in China, which was sized to meet expected demand from Chinese customers.  The amounts in the three months ended June 30, 2013 consist primarily of employee severance and benefit costs.

[0001564590-14-003115:mdna:46]
[same as prior period, unchanged from 0001564590-14-000165:mdna:50]

[0001564590-14-003115:mdna:47]
[same as prior period, unchanged from 0001564590-14-000165:mdna:51]

[0001564590-14-003115:mdna:48]
|  | Three Months Ended |  |
|  | June 30, |  |
|  | 2014 |  |  | 2013 |  |
| Operating loss: |  |  |  |  |  |  |  |
| Wind | $ | (3,480 | ) |  | $ | (1,825 | ) |
| Grid |  | (6,407 | ) |  |  | (4,869 | ) |
| Unallocated corporate expenses |  | (2,780 | ) |  |  | (2,156 | ) |
| Total | $ | (12,667 | ) |  | $ | (8,850 | ) |

[0001564590-14-003115:mdna:49]
Our Wind segment generated an operating loss of $3.5 million in the three months ended June 30, 2014, compared to an operating loss of $1.8 million in the three months ended June 30, 2013. The increase in Wind business unit operating loss was primarily due to lower revenues as previously discussed.

[0001564590-14-003115:mdna:50]
The operating loss in our Grid segment increased to $6.4 million in the three months ended June 30, 2014, compared to $4.9 million in the three months ended June 30, 2013. The increase in the Grid business unit operating loss was primarily due to lower D-VAR revenue, as previously discussed.

[0001564590-14-003115:mdna:51]
Unallocated corporate expenses primarily include stock-based compensation expense of $1.6 million, and restructuring charges of $1.2 million, for the three months ended June 30, 2014.  Unallocated corporate expenses primarily consist of stock-based compensation expense of $2.1 million for the three months ended June 30, 2013.

[0001564590-14-003115:mdna:52]
[same as prior period, unchanged from 0001564590-14-000165:mdna:56]

[0001564590-14-003115:mdna:53]
The change in fair value of derivatives and warrants resulted in a loss of less than $0.1 million in the three months ended June 30, 2014, compared to a gain of $0.5 million for the three months ended June 30, 2013. The changes were primarily driven by the extinguishment of the derivative liability associated with our convertible note and a decrease in value of our outstanding warrants in the prior year.

[0001564590-14-003115:mdna:54]
[same as prior period, unchanged from 0001564590-14-000165:mdna:58]

[0001564590-14-003115:mdna:55]
Interest expense, net, was $0.5 million in the three months ended June 30, 2014, compared to $2.1 million in the three months ended June 30, 2013. The decrease in interest expense was due primarily to the extinguishment of the convertible note in March 2014.

[0001564590-14-003115:mdna:56]
Other (expense) income, net

[0001564590-14-003115:mdna:57]
Other expense, net, was $0.2 million in the three months ended June 30, 2014, compared to other income, net, of $0.1 million in the three months ended June 30, 2013.   The increase in other expense is primarily related to the effect of the fluctuation in foreign currency.

[0001564590-14-003115:mdna:58]
[same as prior period, unchanged from 0001564590-14-000165:mdna:62]

[0001564590-14-003115:mdna:59]
In both the three months ended June 30, 2014 and 2013, we recorded an income tax expense of $0.1 million, respectively. Income tax expense in both periods was primarily due to income taxes in foreign jurisdictions.

[0001564590-14-003115:mdna:60]
[same as prior period, unchanged from 0001564590-14-000165:mdna:64]

[0001564590-14-003115:mdna:61]
[same as prior period, unchanged from 0001564590-14-000165:mdna:65]

[0001564590-14-003115:mdna:62]
We define non-GAAP net loss as net loss before stock-based compensation, amortization of acquisition-related intangibles, restructuring and impairment charges, Sinovel litigation, consumption of zero cost-basis inventory, changes in fair value of derivatives and warrants, non-cash interest expense, and the other non-cash or unusual, net of any tax effects related to these items, indicated in the table below. We believe non-GAAP net loss assists management and investors in comparing our performance across reporting periods on a consistent basis by excluding these non-cash or non-recurring charges that we do not believe are indicative of our core operating performance. We also regard non-GAAP net loss as a useful measure of operating performance which more closely aligns net loss with cash used in/provided by continuing operations. In addition, we use non-GAAP net loss as a factor in evaluating management’s performance when determining incentive compensation and to evaluate the effectiveness of our business strategies. A reconciliation of non-GAAP to GAAP net loss is set forth in the table below (in thousands, except per share data):

[0001564590-14-003115:mdna:63]
|  | Three months ended June 30, |  |  |
|  | 2014 |  |  | 2013 |  |  |
| Net loss | $ | (13,517 | ) |  | $ | (10,513 | ) |  |
| Stock-based compensation |  | 1,581 |  |  |  | 2,135 |  |  |
| Amortization of acquisition-related intangibles |  | 39 |  |  |  | 82 |  |  |
| Restructuring and impairment charges |  | 1,179 |  |  |  | 13 |  |  |
| Sinovel litigation |  | - |  |  |  | 107 |  |  |
| Consumption of zero cost-basis inventory |  | (1,372 | ) |  |  | (1,174 | ) |  |
| Change in fair value of derivatives and warrants |  | 35 |  |  |  | (469 | ) |  |
| Non-cash interest expense |  | 190 |  |  |  | 1,672 |  |  |
| Non-GAAP net loss | $ | (11,865 | ) |  | $ | (8,147 | ) |  |
| Non-GAAP loss per share | $ | (0.15 | ) |  | $ | (0.14 | ) |  |
| Weighted average shares outstanding - basic and diluted |  | 77,688 |  |  |  | 58,300 |  |  |

[0001564590-14-003115:mdna:64]
We incurred a non-GAAP net loss of $11.9 million or $0.15 per share, for the three months ended June 30, 2014 compared to a non-GAAP net loss of $8.1 million, or $0.14 per share, for the three months ended June 30, 2013. The increase in the non-GAAP net loss was driven primarily by the increased net losses as a result of decreased overall revenue.  In addition, higher restructuring charges were mostly offset by lower non-cash interest expense as a result of the extinguishment of the convertible note.

[0001564590-14-003115:mdna:65]
[same as prior period, unchanged from 0001564590-14-000165:mdna:70]

[0001564590-14-003115:mdna:66]
At June 30, 2014, we had cash, cash equivalents, and restricted cash of $42.8 million, compared to $49.4 million at March 31, 2014, a decrease of $6.6 million. Our cash and cash equivalents, and restricted cash are summarized as follows (in thousands):

[0001564590-14-003115:mdna:67]
|  | June 30, |  |  | March 31, |  |
|  | 2014 |  |  | 2014 |  |
| Cash and cash equivalents | $ | 36,624 |  |  | $ | 43,114 |  |
| Restricted cash |  | 6,199 |  |  |  | 6,307 |  |
| Total cash, cash equivalents, and restricted cash | $ | 42,823 |  |  | $ | 49,421 |  |

[0001564590-14-003115:mdna:68]
For the three months ended June 30, 2014, net cash used in operating activities was $5.5 million compared to $9.3 million for the three months ended June 30, 2013. The decrease in net cash used in operations was due primarily to cash generated from changes in operating asset and liability accounts during the three months ended June 30, 2014, compared to a use of cash from changes in these accounts for the three months ended June 30, 2013.

[0001564590-14-003115:mdna:69]
For the three months ended June 30, 2014, net cash used in investing activities was $0.3 million, compared to net cash provided by investing activities of $3.8 million for the three months ended June 30, 2013. The decrease in net cash provided by investing activities for the three months ended June 30, 2014 was driven primarily by a net change in restricted cash.

[0001564590-14-003115:mdna:70]
For the three months ended June 30, 2014, net cash used in financing activities was $0.6 million compared to $1.2 million in the three months ended June 30, 2013. The decrease in net cash used in financing activities was primarily due to net proceeds from the issuance of common stock under the ATM, during the three months ended June 30, 2014.  The ATM arrangement was not in place during the same period in the prior year.

[0001564590-14-003115:mdna:71]
At June 30, 2014, we had $6.1 million of restricted cash included in current assets, and $0.1 million of restricted cash included in long-term assets. These amounts included in restricted cash primarily represent deposits to secure letters of credit for various supply contracts. These deposits are held in interest bearing accounts.

[0001564590-14-003115:mdna:72]
We have experienced recurring operating losses and as of June 30, 2014, had an accumulated deficit of $869.9 million. In addition, we have experienced recurring negative operating cash flows. At June 30, 2014 we had cash and cash equivalents of $36.6 million.  As of June 30, 2014, there was approximately $20.8 million of availability under our ATM arrangement.  Sales of common stock under the ATM may be made from time to time at our discretion, in order to enhance liquidity.  In addition, we are actively seeking to sell our minority investments in Tres Amigas and Blade Dynamics and have engaged a financial advisor to assist with that effort.  There can be no assurance that we will be able to sell one or both of these investments on commercially reasonable terms or at all.

[0001564590-14-003115:mdna:73]
[same as prior period, unchanged from 0001564590-14-000165:mdna:93]

[0001564590-14-003115:mdna:74]
On November 15, 2013, we amended the Term Loan with Hercules and entered into the New Term Loan (collectively with the Term Loan, the “Term Loans”), borrowing an additional $10.0 million. After closing fees and expenses, we received net proceeds of $9.8 million.  The New Term Loan also bears the same interest rate as the Term Loan.  We made interest-only payments from December 1, 2013 to May 31, 2014.  If we achieved certain revenue targets for the six-month period ending March 31, 2014, interest only payments would continue through August 31, 2014.  We did not meet these revenue targets.  As a result, we are repaying the New Term Loan in equal monthly installments ending on November 1, 2016.

[0001564590-14-003115:mdna:75]
The Term Loans are secured by substantially all of our existing and future assets, including a mortgage on real property owned by our wholly owned subsidiary, ASC Devens LLC, and located at 64 Jackson Road, Devens, Massachusetts. The Term Loans contain certain covenants that restrict our ability to, among other things, incur or assume certain debt, merge or consolidate, materially change the nature of our business, make certain investments, acquire or dispose of certain assets, make guaranties or grant liens on our assets, make certain loans, advances or investments, declare dividends or make distributions or enter into transactions with affiliates. In addition, the Term Loans contain a covenant which requires us to maintain a minimum unrestricted cash balance (“Minimum Threshold”) in the United States of at least $15.0 million at the inception of the New Term Loan.  The Minimum Threshold will be reduced by $2.5 million for every $5.0 million of net proceeds from the sale of our common stock after November 15, 2013, including those under the ATM, to an amount not lower than $7.5 million or the outstanding combined principal balances of the Term Loans, whichever is lower.  As of June 30, 2014 the Minimum Threshold was $12.5 million.  The events of default under the Term Loans include, but are not limited to, failure to pay amounts due, breaches of covenants, bankruptcy events, cross defaults under other material indebtedness and the occurrence of a material adverse effect and/or change in control. In the case of a continuing event of default, the lender may, among other remedies, declare due all unpaid principal amounts outstanding and any accrued but unpaid interest and foreclose on all collateral granted to the lender as security under the Term Loans.

[0001564590-14-003115:mdna:76]
We believe we are in and expect to remain in compliance with the covenants and restrictions under the Term Loans as of the date of this Quarterly Report on Form 10-Q. If we fail to stay in compliance with our covenants or experience some other event of default, we may be forced to repay the outstanding principal of the Term Loans.

[0001564590-14-003115:mdna:77]
On November 15, 2013, we entered into an ATM arrangement, pursuant to which, we may, at our discretion, sell up to $30.0 million of our common stock through our sales agent, MLV.  Sales of common stock made under the ATM are made on the NASDAQ Global Market under our previously filed and currently effective Registration Statement on Form S-3 (File No. 333-191153) by means of ordinary brokers’ transactions at market prices. Additionally, under the terms of the ATM, we may also sell shares of our common stock through MLV, on the NASDAQ Global Market or otherwise, at negotiated prices or at prices related to the prevailing market price. Under the terms of the ATM, MLV may not engage in any proprietary trading or trading as principal for MLV’s own account. MLV uses its commercially reasonable efforts to sell our common stock from time to time, based upon the our instructions (including any price, time or size limits or other customary parameters or conditions we may impose). We pay MLV a commission of up to 3% of the gross proceeds from the sale of shares of our common stock under the ATM. We have also agreed to provide MLV with customary indemnification rights. The offering of common stock pursuant to the ATM will terminate upon the earlier of the sale of all of the common stock subject to the ATM or the termination of the ATM by us or MLV. Either party may terminate the ATM at its sole discretion at any time upon written notice to the other party.  During the three months ended June 30, 2014, we received net proceeds of $1.2 million, including sales commissions and offering expenses, from sales of approximately 0.8 million shares of our common stock at an average sales price of approximately $1.63 per share under the ATM.  As of June 30, 2014, we have approximately $20.8 million of remaining availability under the ATM.

[0001564590-14-003115:mdna:78]
We believe we have sufficient available liquidity to fund our operations, capital expenditures and scheduled cash payments under our debt obligations through June 30, 2015. Our liquidity is highly dependent on our ability to increase revenues and control our operating costs, our ability to utilize the ATM to raise additional capital at our discretion, and our ability to maintain compliance with the covenants and restrictions on our debt obligations (or obtain waivers from our lender in the event of non-compliance).

[0001564590-14-003115:mdna:79]
Our cash requirements depend on numerous factors, including the successful completion of our product development activities, our ability to commercialize our REG and degaussing system solutions, rate of customer and market adoption of our products, collecting receivables according to established terms, and the continued availability of U.S. government funding during the product development phase in our Superconductors business. Significant deviations to our business plan with regard to these factors, which are important drivers to our business, could have a material adverse effect on our operating performance, financial condition, and future business prospects. We expect to pursue the expansion of our operations through internal growth, diversification of our customer base, and potential strategic alliances.

[0001564590-14-003115:mdna:80]
Legal Proceedings

[0001564590-14-003115:mdna:81]
We are involved in legal and administrative proceedings and claims of various types. See Part II, Item 1, “Legal Proceedings,” for additional information. We record a liability in our consolidated financial statements for these matters when a loss is known or considered probable and the amount can be reasonably estimated. We review these estimates each accounting period as additional information is known and adjust the loss provision when appropriate. If a matter is both probable to result in liability and the amounts of loss can be reasonably estimated, we estimate and disclose the possible loss or range of loss. If the loss is not probable or cannot be reasonably estimated, a liability is not recorded in our consolidated financial statements.

[0001564590-14-003115:mdna:82]
[same as prior period, unchanged from 0001564590-14-000165:mdna:103]

[0001564590-14-003115:mdna:83]
[same as prior period, unchanged from 0001564590-14-000165:mdna:104]

[0001564590-14-003115:mdna:84]
[same as prior period, unchanged from 0001564590-14-000165:mdna:105]

[0001564590-14-003115:mdna:85]
[same as prior period, unchanged from 0001564590-14-000165:mdna:106]

[0001564590-14-003115:mdna:86]
[same as prior period, unchanged from 0001564590-14-000165:mdna:107]

[0001564590-14-003115:mdna:87]
In January 2013, the FASB issued Accounting Standards Update No. 2013-01, Balance Sheet (Topic 210): Clarifying the Scope of Disclosures about Offsetting Assets and Liabilities (ASU 2013-01). The main objective in developing this update is to address implementation issues about the scope of Accounting Standards Update No. 2011-11, Balance Sheet (Topic 210): Disclosures about Offsetting Assets and Liabilities. The update requires entities to disclose information about offsetting and related arrangements of financial instruments and derivative instruments. ASU 2013-01 is effective for our first quarter of fiscal 2014. We adopted ASU 2013-01 in the first quarter of fiscal 2014, and there was no significant effect on our consolidated results of operations, financial condition, or cash flows.

[0001564590-14-003115:mdna:88]
In May 2014, the FASB and the International Accounting Standards Board (IASB) issued, ASU Revenue from Contracts with Customers 2014-09 (Topic 606). The guidance substantially converges final standards on revenue recognition between the FASB and IASB providing a framework on addressing revenue recognition issues and, upon its effective date, replaces almost all exiting revenue recognition guidance, including industry-specific guidance, in current U.S. generally accepted accounting principles.  The ASU is effective for annual reporting periods beginning after December 15, 2016.  We are currently evaluating the impact of adopting ASU 2014-09 to determine the impact, if any, it may have on our current practices.

[0001564590-14-003115:mdna:89]
In July 2014, the FASB issued ASU 2014-12, Compensation – Stock Compensation (Topic 718): Accounting for Share Based Payments When the Terms of an Award Provide that a Performance Target Could be Achieved after the Requisite Service Period.    To account for such awards, a reporting entity should apply existing guidance in FASB Accounting Standards Codification Topic 718, Compensation – Stock Compensation, as it relates to awards with performance conditions that affect vesting.  As such, the performance target should not be reflected in estimating the grant-date fair value of the award. This ASU is effective for annual reporting periods and interim periods, within those annual periods beginning after December 15, 2015.  We are currently evaluating the impact of adopting ASU 2014-12 to determine the impact, if any, it may have on our current practices.

[0001564590-14-003115:mdna:90]
We do not believe that other recently issued accounting pronouncements will have a material impact on our financial statements.

[0001564590-14-003115:mdna:91]
[same as prior period, unchanged from 0001564590-14-000165:mdna:33]
