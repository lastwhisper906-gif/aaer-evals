# AMSC MD&A — 0001564590-15-006142


## mdna

[0001564590-15-006142:mdna:1]
[same as prior period, unchanged from 0001564590-15-000491:mdna:1]

[0001564590-15-006142:mdna:2]
25

[0001564590-15-006142:mdna:3]
largest customer, Sinovel, regarding amounts we contend are overdue. We cannot be certain as to the outcome of these proceedings; We have been named as a party in various legal proceedings, and we may be named in additional litigation, all of which will require significant management time and attention, result in significant legal expenses and may result in an unfavorable outcome, which could have a material adverse effect on our business, operating results and financial condition; and our common stock has experienced, and may continue to experience, significant market price and volume fluctuations, which may prevent our stockholders from selling our common stock at a profit and could lead to costly litigation against us that could divert our management’s attention.  These and the important factors discussed under the caption “Risk Factors” in Part 1. Item 1A of our Form 10-K for the fiscal year ended March 31, 2015, among others, could cause actual results to differ materially from those indicated by forward-looking statements made herein and presented elsewhere by management from time to time. Any such forward-looking statements represent management’s estimates as of the date of this Quarterly Report on Form 10-Q. While we may elect to update such forward-looking statements at some point in the future, we disclaim any obligation to do so, even if subsequent events cause our views to change. These forward-looking statements should not be relied upon as representing our views as of any date subsequent to the date of this Quarterly Report on Form 10-Q.

[0001564590-15-006142:mdna:4]
[same as prior period, unchanged from 0001564590-15-000491:mdna:3]

[0001564590-15-006142:mdna:5]
[same as prior period, unchanged from 0001564590-15-000491:mdna:4]

[0001564590-15-006142:mdna:6]
[same as prior period, unchanged from 0001564590-15-000491:mdna:5]

[0001564590-15-006142:mdna:7]
[same as prior period, unchanged from 0001564590-15-000491:mdna:6]

[0001564590-15-006142:mdna:8]
We manufacture products using two proprietary core technologies: PowerModule programmable power electronic converters and our Amperium high temperature superconductor (“HTS”) wires. These technologies and our system-level solutions are protected by a broad and deep intellectual property portfolio consisting of hundreds of patents and licenses worldwide.

[0001564590-15-006142:mdna:9]
[same as prior period, unchanged from 0001564590-15-000491:mdna:8]

[0001564590-15-006142:mdna:10]
| ● | Wind. Through our Windtec SolutionsTM, our Wind business segment enables manufacturers to field wind turbines with exceptional power output, reliability and affordability. We supply advanced power electronics and control systems, license our highly engineered wind turbine designs, and provide extensive customer support services to wind turbine manufacturers. Our design portfolio includes a broad range of drive trains and power ratings of 2 megawatts (“MW”) and higher. We provide a broad range of power electronics and software-based control systems that are highly integrated and designed for optimized performance, efficiency, and grid compatibility. |

[0001564590-15-006142:mdna:11]
| ● | Grid. Through our Gridtec SolutionsTM, our Grid business segment enables electric utilities and renewable energy project developers to connect, transmit and distribute power with exceptional efficiency, reliability, security and affordability. We provide transmission planning services that allow us to identify power grid congestion, poor power quality, and other risks, which help us determine how our solutions can improve network performance. These services often lead to sales of our grid interconnection solutions for wind farms and solar power plants, power quality systems and transmission and distribution cable systems. We also sell ship protection products to the U.S. Navy through our Grid business segment. |

[0001564590-15-006142:mdna:12]
Our fiscal year begins on April 1 and ends on March 31. When we refer to a particular fiscal year, we are referring to the fiscal year beginning on April 1 of that same year. For example, fiscal 2015 refers to the fiscal year beginning on April 1, 2015. Other fiscal years follow similarly.

[0001564590-15-006142:mdna:13]
26

[0001564590-15-006142:mdna:14]
On March 24, 2015, we effected a 1-for-10 reverse stock split on our common stock.  Trading of our common stock reflected the reverse stock split beginning March 25, 2015.  Unless otherwise indicated, all historical references to shares of common stock, shares of restricted stock, restricted units, shares underlying stock options, warrants or calculations that use common stock for per share financial reporting have been adjusted for comparative purposes to reflect the impact of the 1-for-10 reverse stock split as if it had occurred at the beginning of the earliest period presented.

[0001564590-15-006142:mdna:15]
We have experienced recurring operating losses and as of June 30, 2015, had an accumulated deficit of $914.2 million. In addition, we have experienced recurring negative operating cash flows. At June 30, 2015, we had cash and cash equivalents of $38.6 million. Cash used in operations for the three months ended June 30, 2015 was $3.0 million.

[0001564590-15-006142:mdna:16]
Over the last several years, we have entered into several debt and equity financing arrangements in order to enhance liquidity.  Since April 1, 2012, we generated aggregate cash flows from financing activities of $74.0 million.  This amount includes proceeds from our April 2015 equity offering, which generated net proceeds of approximately $22.3 million, after deducting underwriting discounts and commissions and estimated offering expenses.  See Note 10, “Debt”, and Note 12 “Stockholders Equity” for further discussion of these financing arrangements. We believe that we are in compliance with the covenants and restrictions included in the agreements governing our debt arrangements as of June 30, 2015.

[0001564590-15-006142:mdna:17]
[same as prior period, unchanged from 0001564590-15-000491:mdna:21]

[0001564590-15-006142:mdna:18]
[same as prior period, unchanged from 0001564590-15-000491:mdna:22]

[0001564590-15-006142:mdna:19]
We cannot provide any assurance as to the outcome of these legal actions. For more information about these legal proceedings, see Part II, Item 1, “Legal Proceedings.”

[0001564590-15-006142:mdna:20]
Our cash requirements depend on numerous factors, including the successful completion of our product development activities, our ability to commercialize our Resilient Electric Grid (“REG”) and ship protection system solutions, rate of customer and market adoption of our products, collecting receivables according to established terms, and the continued availability of U.S. government funding during the product development phase of our Superconductors based products. In addition we are focused on achieving certain operational objectives.  During the first quarter of fiscal 2015, we achieved one of our objectives by announcing that Washington D.C.’s Pepco is conducting a deployment study of our REG system.  During the first half of fiscal 2015, we expect to receive a large wind order for our electrical control systems, and additional new orders for our D-VAR systems.  In the longer term, we expect to have a decision on moving to the manufacturing and construction phase of Project REG and we expect to receive additional business from the U.S. Navy.  Significant deviations to our business plan with regard to these factors and events, which are important drivers to our business, could have a material adverse effect on our operating performance, financial condition, and future business prospects. We expect to pursue the expansion of our operations through internal growth, diversification of our customer base, and potential strategic alliances. See below for a discussion of liquidity and capital resources.

[0001564590-15-006142:mdna:21]
We no longer believe our investments in Tres Amigas, LLC, a Delaware limited liability Company (“Tres Amigas”) or Blade Dynamics Ltd. (“Blade Dynamics”) are recoverable.  We fully impaired our remaining investments in Tres Amigas during the three months ended June 30, 2015 and Blade Dynamics during the three months ended September 30, 2014. (See Note 14, “Minority Investments”, for further information about such investments).

[0001564590-15-006142:mdna:22]
[same as prior period, unchanged from 0001564590-15-000491:mdna:25]

[0001564590-15-006142:mdna:23]
The preparation of the unaudited condensed consolidated financial statements requires that we make estimates and judgments that affect the reported amounts of assets, liabilities, revenues and expenses, and related disclosure of contingent assets and liabilities. We base our estimates on historical experience and various other assumptions that are believed to be reasonable under the circumstances, the results of which form the basis for making judgments about the carrying values of assets and liabilities that are not readily apparent from other sources. Actual results may differ under different assumptions or conditions. There were no significant changes in the critical accounting policies during the three months ended June 30, 2015 that were disclosed in our Form 10-K for fiscal 2014, which ended on March 31, 2015.

[0001564590-15-006142:mdna:24]
[same as prior period, unchanged from 0001564590-15-000491:mdna:27]

[0001564590-15-006142:mdna:25]
Three months ended June 30, 2015 compared to the three months ended June 30, 2014

[0001564590-15-006142:mdna:26]
[same as prior period, unchanged from 0001564590-15-000491:mdna:29]

[0001564590-15-006142:mdna:27]
Total revenues increased 103% to $23.7 million for the three months ended June 30, 2015, compared to $11.7 million for the three months ended June 30, 2014.  Our revenues are summarized as follows (in thousands):

[0001564590-15-006142:mdna:28]
|  | Three months ended June 30, |  |
|  | 2015 |  |  | 2014 |  |
| Revenues: |  |  |  |  |  |  |  |
| Wind | $ | 18,164 |  |  | $ | 7,650 |  |
| Grid |  | 5,559 |  |  |  | 4,046 |  |
| Total | $ | 23,723 |  |  | $ | 11,696 |  |

[0001564590-15-006142:mdna:29]
Our Wind business unit accounted for 77% of total revenues for the three months ended June 30, 2015, compared to 65% for the three months ended June 30, 2014. Revenues in the Wind business unit increased 137% to $18.2 million in the three months ended June 30, 2015, from $7.7 million in the three months ended June 30, 2014. Wind business unit revenues during the three months ended June 30, 2015 increased primarily due to higher volume of sales to Inox Wind Limited (“Inox”) in India and Beijing JINGCHENG New Energy (“JCNE”) in China.

[0001564590-15-006142:mdna:30]
Our Grid business unit accounted for 23% of total revenues for the three months ended June 30, 2015, compared to 35% for the three months ended June 30, 2014. Our Grid business unit revenues increased 37% to $5.6 million in the three months ended June 30, 2015, from $4.0 million in the three months ended June 30, 2014. Grid business unit revenues increased in the three months ended June 30, 2015 primarily due to higher D-VAR system revenues, partially offset by lower HTS wire sales.

[0001564590-15-006142:mdna:31]
Revenues from Project HYDRA and Project REG represented 11% and 5% of our Grid business unit’s revenue for the three months ended June 30, 2015 and 2014, respectively.  Our revenues for these projects are derived by funding from the Department of Homeland Security (“DHS”).  Project HYDRA is a project with Consolidated Edison, Inc. (“ConEd”) to demonstrate our REG product in ConEd’s electric grid.  Project REG is a project with Commonwealth Edison, Inc. (“ComEd”) to permanently install our REG product in ComEd’s electric grid.  This fault current limiting cable system is designed to utilize customized Amperium® HTS wire, and ancillary controls to deliver more power through the grid while also being able to suppress power surges that can disrupt service. DHS has committed 100% of the total expected funding of $29.0 million for Project HYDRA.  Under Project REG, DHS is expected to invest up to $60.0 million to enable the deployment of the REG system in Chicago’s electric grid.  We are currently working on the first phase of the project which among other things, will result in the creation of a detailed deployment plan.  Funding of $1.5 million for this phase of the project has been committed by DHS.  The second phase of the project involves the delivery of the REG system and the associated construction and deployment of the system in ComEd’s grid.  We will not begin this phase of the project until all parties agree to proceed.  There can be no assurance that all parties will agree to proceed with the project.

[0001564590-15-006142:mdna:32]
The following table sets forth customers who represented 10% or more of our total revenues for the three months ended June 30, 2015 and 2014:

[0001564590-15-006142:mdna:33]
|  | Three months ended June 30, |  |
|  | 2015 |  |  | 2014 |  |
| INOX Wind Limited |  | 47 | % |  |  | 48% |  |
| Beijing JINGCHENG New Energy Co., Ltd |  | 25 | % |  | <10% |  |
| M.A. Mortenson Company |  | 11 | % |  | — % |  |

[0001564590-15-006142:mdna:34]
[same as prior period, unchanged from 0001564590-15-000491:mdna:37]

[0001564590-15-006142:mdna:35]
Cost of revenues increased by 70% to $20.5 million for the three months ended June 30, 2015, compared to $12.1 million for the three months ended June 30, 2014. Gross margin was 13.6% for the three months ended June 30, 2015, compared to (3.3)% for the three months ended June 30, 2014. The increase in gross margin for the three months ended June 30, 2015 as compared to the same period in fiscal 2014 was primarily due to higher revenues and a more favorable product mix due primarily to higher Wind royalty revenues in the three months ending June 30, 2015.

[0001564590-15-006142:mdna:36]
[same as prior period, unchanged from 0001564590-15-000491:mdna:39]

[0001564590-15-006142:mdna:37]
[same as prior period, unchanged from 0001564590-15-000491:mdna:40]

[0001564590-15-006142:mdna:38]
[same as prior period, unchanged from 0001564590-15-000491:mdna:41]

[0001564590-15-006142:mdna:39]
|  | Three months ended June 30, |  |
|  | 2015 |  |  | 2014 |  |
| R&D expenses per consolidated statements of operations | $ | 3,162 |  |  | $ | 3,120 |  |
| R&D expenditures reclassified as cost of revenues |  | 1,560 |  |  |  | 2,075 |  |
| R&D expenditures offset by cost-sharing funding |  | 47 |  |  |  | 26 |  |
| Aggregated R&D expenses | $ | 4,769 |  |  | $ | 5,221 |  |

[0001564590-15-006142:mdna:40]
R&D expenses (exclusive of amounts classified as cost of revenues and amounts offset by cost-sharing funding) increased by 1% to $3.2 million for the three months ended June 30, 2015, from $3.1 million for the three months ended June 30, 2014.  The increases in R&D expenses for the three months ended June 30, 2015 were driven primarily by increased spending in our Grid segment on new product development.  The decreases in R&D expenditures reclassified to cost of revenue was a result of decreased activity under government funded contracts in our Grid business unit compared to the prior year period.  Aggregated R&D expenses, which include amounts classified as cost of revenues and amounts offset by cost-sharing funding decreased 9% to $4.8 million for the three months ended June 30, 2015, from $5.2 million for the three months ended June 30, 2014.

[0001564590-15-006142:mdna:41]
[same as prior period, unchanged from 0001564590-15-000491:mdna:44]

[0001564590-15-006142:mdna:42]
[same as prior period, unchanged from 0001564590-15-000491:mdna:45]

[0001564590-15-006142:mdna:43]
SG&A expenses decreased by 5% to $7.5 million in the three months ended June 30, 2015, from $7.9 million in the three months ended June 30, 2014. The decreases in SG&A expenses were due primarily to the realization of savings from cost reduction actions that were implemented in prior periods as well as a reduction in stock compensation and legal costs.

[0001564590-15-006142:mdna:44]
[same as prior period, unchanged from 0001564590-15-000491:mdna:49]

[0001564590-15-006142:mdna:45]
We recorded amortization expense related to our core technology and know-how, trade names and trademark intangible assets of less than $0.1 million in both the three months ended June 30, 2015 and 2014.

[0001564590-15-006142:mdna:46]
[same as prior period, unchanged from 0001564590-15-000491:mdna:51]

[0001564590-15-006142:mdna:47]
We recorded an impairment charge of $0.7 million in the three months ended June 30, 2015 to fully impair our investment in Tres Amigas as our investment is no longer deemed recoverable. We recorded a restructuring charge of $1.2 million in the three months ended June 30, 2014. This amount consists primarily of employee severance and benefits costs related to the consolidation of Grid manufacturing operations in the United States and a reduction in force in our operation in China, which is being sized to meet expected demand from our Chinese customers.

[0001564590-15-006142:mdna:48]
Operating income (loss)

[0001564590-15-006142:mdna:49]
Our operating income (loss) is summarized as follows (in thousands):

[0001564590-15-006142:mdna:50]
|  | Three months ended June 30, |  |
|  | 2015 |  |  | 2014 |  |
| Operating income (loss): |  |  |  |  |  |  |  |
| Wind | $ | 127 |  |  | $ | (3,480 | ) |
| Grid |  | (6,508 | ) |  |  | (6,407 | ) |
| Unallocated corporate expenses |  | (1,876 | ) |  |  | (2,780 | ) |
| Total | $ | (8,257 | ) |  | $ | (12,667 | ) |

[0001564590-15-006142:mdna:51]
Our Wind segment generated an operating profit of $0.1 million in the three months ended June 30, 2015, compared to an operating loss of $3.5 million in the three months ended June 30, 2014. The increase in Wind business unit operating profit during the three months ended June 30, 2015 was due primarily to increased revenues for shipments to Inox in India and JCNE in China as well as a favorable revenue mix as a result of higher royalty revenues in the three months ended June 30, 2015.

[0001564590-15-006142:mdna:52]
The operating loss in our Grid segment increased to $6.5 million in the three months ended June 30, 2015, compared to $6.4 million in the three months ended June 30, 2014. The increase in the Grid business unit operating loss was driven primarily by lower gross margin as a result of the deferral of certain D-VAR project revenues while the associated costs were expensed as incurred.

[0001564590-15-006142:mdna:53]
Unallocated corporate expenses primarily include stock-based compensation expense of $1.1 million and an impairment charge of $0.7 million, for the three months ended June 30, 2015.  Unallocated corporate expenses primarily consist of stock-based compensation expense of $1.6 million, and restructuring charges of $1.2 million for the three months ended June 30, 2014.

[0001564590-15-006142:mdna:54]
[same as prior period, unchanged from 0001564590-15-000491:mdna:59]

[0001564590-15-006142:mdna:55]
The change in fair value of derivatives and warrants resulted in a gain of $0.8 million in the three months ended June 30, 2015, compared to a loss of less than $0.1 million for the three months ended June 30, 2014. The increase in the gain was primarily driven by a lower stock price, which is a key valuation metric.

[0001564590-15-006142:mdna:56]
[same as prior period, unchanged from 0001564590-15-000491:mdna:61]

[0001564590-15-006142:mdna:57]
Interest expense, net, was $0.3 million in the three months ended June 30, 2015, compared to $0.5 million in the three months ended June 30, 2014. The decrease in interest expense was due primarily to the maturity of one of our term loans with Hercules Technology Growth Capital, Inc. (“Hercules”) in December 2014.

[0001564590-15-006142:mdna:58]
Other expense, net

[0001564590-15-006142:mdna:59]
Other expense, net, was $0.8 million in the three months ended June 30, 2015, compared to $0.2 million in the three months ended June 30, 2014.  The increase in other expense, net was primarily related to foreign currency losses due to the strengthening of the Euro versus the U.S. Dollar in the three months ended June 30, 2015 and our minority interest in the losses of Tres Amigas.

[0001564590-15-006142:mdna:60]
[same as prior period, unchanged from 0001564590-15-000491:mdna:66]

[0001564590-15-006142:mdna:61]
Income tax expense was $0.6 million in the three months ended June 30, 2015, compared to $0.1 million in the three months ended June 30, 2014. Income tax expense in both periods was primarily due to income taxes in foreign jurisdictions.

[0001564590-15-006142:mdna:62]
[same as prior period, unchanged from 0001564590-15-000491:mdna:68]

[0001564590-15-006142:mdna:63]
[same as prior period, unchanged from 0001564590-15-000491:mdna:69]

[0001564590-15-006142:mdna:64]
We define non-GAAP net loss as net loss before stock-based compensation, amortization of acquisition-related intangibles, restructuring and impairment charges, consumption of zero cost-basis inventory, changes in fair value of derivatives and warrants, non-cash interest expense, and the other non-cash or unusual charges, net of any tax effects related to these items, indicated in the table below. We believe non-GAAP net loss assists management and investors in comparing our performance across reporting periods on a consistent basis by excluding these non-cash or non-recurring charges that we do not believe are indicative of our core operating performance. We also regard non-GAAP net loss as a useful measure of operating performance which more closely aligns net loss with cash used in/provided by continuing operations. In addition, we use non-GAAP net loss as a factor in evaluating management’s performance when determining incentive compensation and to evaluate the effectiveness of our business strategies. A reconciliation of non-GAAP to GAAP net loss is set forth in the table below (in thousands, except per share data):

[0001564590-15-006142:mdna:65]
|  | Three months ended June 30, |  |
|  | 2015 |  |  | 2014 |  |
| Net loss | $ | (9,121 | ) |  | $ | (13,517 | ) |
| Stock-based compensation |  | 1,128 |  |  |  | 1,581 |  |
| Amortization of acquisition-related intangibles |  | 39 |  |  |  | 39 |  |
| Restructuring and impairment charges |  | 741 |  |  |  | 1,179 |  |
| Consumption of zero cost-basis inventory |  | (846 | ) |  |  | (1,372 | ) |
| Change in fair value of derivatives and warrants |  | (800 | ) |  |  | 35 |  |
| Non-cash interest expense |  | 111 |  |  |  | 190 |  |
| Non-GAAP net loss | $ | (8,748 | ) |  | $ | (11,865 | ) |
| Non-GAAP loss per share | $ | (0.72 | ) |  | $ | (1.53 | ) |
| Weighted average shares outstanding - basic and diluted |  | 12,111 |  |  |  | 7,769 |  |

[0001564590-15-006142:mdna:66]
We incurred a non-GAAP net loss of $8.7 million or $0.72 per share, for the three months ended June 30, 2015, compared to a non-GAAP net loss of $11.9 million, or $1.53 per share, for the three months ended June 30, 2014. The decrease in non-GAAP net loss was driven primarily by higher revenues in both of our business units, including higher royalty revenues in our Wind segment as previously discussed.

[0001564590-15-006142:mdna:67]
[same as prior period, unchanged from 0001564590-15-000491:mdna:73]

[0001564590-15-006142:mdna:68]
At June 30, 2015, we had cash, cash equivalents, and restricted cash of $42.6 million, compared to $24.5 million at March 31, 2015, an increase of $18.1 million. Our cash and cash equivalents, and restricted cash are summarized as follows (in thousands):

[0001564590-15-006142:mdna:69]
|  | June 30, |  |  | March 31, |  |
|  | 2015 |  |  | 2015 |  |
| Cash and cash equivalents | $ | 38,561 |  |  | $ | 20,490 |  |
| Restricted cash |  | 4,064 |  |  |  | 4,059 |  |
| Total cash, cash equivalents, and restricted cash | $ | 42,625 |  |  | $ | 24,549 |  |

[0001564590-15-006142:mdna:70]
For the three months ended June 30, 2015, net cash used in operating activities was $3.0 million compared to $5.5 million for the three months ended June 30, 2014. The decrease in net cash used in operations was due primarily to lower net loss driven by higher revenues and a decrease in cash used from changes in operating asset and liability accounts during the three months ended June 30, 2015 compared to the three months ended June 30, 2014 driven primarily by decreases in accounts receivable and inventory in the three months ended June 30, 2015.

[0001564590-15-006142:mdna:71]
For the three months ended June 30, 2015, net cash used in investing activities was $0.1 million, compared to $0.3 million for the three months ended June 30, 2014. The decrease in net cash used in investing was due primarily to an increase in cash generated by changes in other assets, as well as a decrease in purchases of property plant and equipment.

[0001564590-15-006142:mdna:72]
For the three months ended June 30, 2015, net cash provided by financing activities was $21.2 million compared to net cash used by financing activities of $0.6 million in the three months ended June 30, 2014. The increase in net cash provided by financing activities was primarily due to net proceeds of $22.3 million from the issuance of 4.0 million shares of common stock on April 29, 2015.

[0001564590-15-006142:mdna:73]
At June 30, 2015, we had $3.3 million of restricted cash included in current assets, and $0.8 million of restricted cash included in long-term assets. These amounts included in restricted cash primarily represent deposits to secure letters of credit for various supply contracts. These deposits are held in interest bearing accounts.

[0001564590-15-006142:mdna:74]
On June 5, 2012, we entered into a Loan and Security Agreement (the “Term Loan”) with Hercules, under which we borrowed $10.0 million. After the closing fees and expenses, the net proceeds were $9.7 million. The Term Loan bears an interest rate equal to 11% plus the percentage, if any, in which the prime rate as reported by The Wall Street Journal exceeds 3.75%. We made interest only payments from July 1, 2012 through October 31, 2012, after which we began paying the Term Loan in equal monthly installments ending on December 1, 2014, when the loan was repaid in full.

[0001564590-15-006142:mdna:75]
On November 15, 2013, we amended the Term Loan with Hercules and entered into a new term loan (the “New Term Loan B”), borrowing an additional $10.0 million. After closing fees and expenses, we received net proceeds of $9.8 million. The New Term Loan B also bears the same interest rate as the Term Loan. We made interest-only payments from December 1, 2013 to May 31, 2014. If we achieved certain revenue targets for the six-month period ending March 31, 2014, interest only payments would continue through August 31, 2014. We did not achieve the revenue required to extend this interest only period.  Beginning June 1, 2014, we began making payments on the New Term Loan B in equal monthly installments which will end on November 1, 2016.

[0001564590-15-006142:mdna:76]
On December 19, 2014, we entered into an amendment with Hercules (the “Hercules Second Amendment”) and entered into a new term loan (the “New Term Loan C”), borrowing an additional $1.5 million (we collectively refer to the Term Loan, the New Term Loan B, and New Term Loan C as the “Term Loans”).  After closing fees and expenses, the net proceeds from the New Term Loan C were $1.4 million.  The New Term Loan C also bears the same interest rate as the other Term Loans.  We will make interest only payments until maturity on June 1, 2017, when the loan is scheduled to be repaid in its entirety.  The maturity date of the New Term Loan C was extended from March 1, 2017 to June 1, 2017 due to our April 2015 equity offering which raised more than $10 million in new capital before December 31, 2015 (see discussion below).

[0001564590-15-006142:mdna:77]
The Term Loans are secured by substantially all of our existing and future assets, including a mortgage on real property owned by our wholly-owned subsidiary, ASC Devens LLC, and located at 64 Jackson Road, Devens, Massachusetts.  The Term Loans contain certain covenants that restrict our ability to, among other things, incur or assume certain debt, merge or consolidate, materially change the nature of our business, make certain investments, acquire or dispose of certain assets, make guaranties or grant liens on our assets, make certain loans, advances or investments, declare dividends or make distributions or enter into transactions with affiliates. In addition, there is a covenant that requires us to maintain a minimum unrestricted cash balance (the “Minimum Threshold”) in the United States.  As part of the Hercules Second Amendment, this Minimum Threshold was amended to be the lower of $5.0 million or the aggregate outstanding principal balance of the Term Loans.  As a result of the April 2015 offering (see discussion below), the Minimum Threshold was reduced to the lesser of $2.0 million or the aggregate outstanding principal balance of the Term Loans.  As of June 30, 2015, the Minimum Threshold was $2.0 million.  The events of default under the Term Loans include, but are not limited to, failure to pay amounts due, breaches of covenants, bankruptcy events, cross defaults under other material indebtedness and the occurrence of a material adverse effect and/or change in control. In the case of a continuing event of default, Hercules may, among other remedies, declare due all unpaid principal amounts outstanding and any accrued but unpaid interest and foreclose on all collateral granted to Hercules as security under the Term Loans.

[0001564590-15-006142:mdna:78]
We believe we are in and expect to remain in compliance with the covenants and restrictions under the Term Loans as of the date of this Quarterly Report on Form 10-Q. If we fail to stay in compliance with our covenants or experience some other event of default, we may be forced to repay the outstanding principal on the Term Loans.

[0001564590-15-006142:mdna:79]
On November 15, 2013, we entered into an ATM arrangement, pursuant to which, we were able to, at our discretion, sell up to $30.0 million of our common stock through our sales agent, MLV & Co. LLC (“MLV”).  Sales of common stock made under the ATM were made on the Nasdaq Global Select Market under our previously filed and currently effective Registration Statement on Form S-3 (File No. 333-191153) by means of ordinary brokers’ transactions at market prices. We paid MLV a commission of up to 3% of the gross proceeds from the sale of shares of our common stock under the ATM.  We also agreed to provide MLV with customary indemnification rights.  During the three months ended June 30, 2014, we received net proceeds of $1.2 million, including sales commissions and offering expenses from the sale of 76,434 shares of our common stock at an average sales price of $16.31 per share.  We terminated the ATM arrangement on November 5, 2014.

[0001564590-15-006142:mdna:80]
On November 13, 2014, we completed an equity offering, under which we sold 909,090 units of our common stock at $11.00 per unit to Hudson Bay Capital.  Each unit consisted of one share of common stock and 0.90 of a warrant to purchase one share of common stock, or a warrant to purchase in the aggregate 818,181 shares of common stock.  After the underwriting discount and estimated offering expenses, we received net proceeds from the offering of approximately $9.1 million.

[0001564590-15-006142:mdna:81]
We have experienced recurring operating losses and as of June 30, 2015, had an accumulated deficit of $914.2 million. In addition, we have experienced recurring negative operating cash flows. At June 30, 2015 we had cash and cash equivalents of $38.6 million, as compared to cash used in operations of $3.0 million for the three months ended June 30, 2015. On April 29, 2015 we completed an equity offering which raised net proceeds of $22.3 million after deducting underwriting discounts and commissions and estimated offering expenses payable by us from the sale of 4.0 million shares of our common stock at a public offering price of $6.00 per share.

[0001564590-15-006142:mdna:82]
We believe we have sufficient available liquidity to fund our operations, capital expenditures and scheduled cash payments under our debt obligations for the next twelve months. Our liquidity is highly dependent on our ability to increase revenues, control our operating costs, and our ability to maintain compliance with the covenants and restrictions on our debt obligations (or obtain waivers from our lender in the event of non-compliance), and our ability to raise additional capital, if necessary.  There can be no assurance that we will be able to continue to raise additional capital from other sources or execute on any other means of improving our liquidity as described above.

[0001564590-15-006142:mdna:83]
Legal Proceedings

[0001564590-15-006142:mdna:84]
We are involved in legal and administrative proceedings and claims of various types. See Part II, Item 1, “Legal Proceedings,” for additional information. We record a liability in our consolidated financial statements for these matters when a loss is known or considered probable and the amount can be reasonably estimated. We review these estimates each accounting period as additional information is known and adjust the loss provision when appropriate. If a matter is both probable to result in liability and the amounts of loss can be reasonably estimated, we estimate and disclose the possible loss or range of loss. If the loss is not probable or cannot be reasonably estimated, a liability is not recorded in our consolidated financial statements.

[0001564590-15-006142:mdna:85]
[same as prior period, unchanged from 0001564590-15-000491:mdna:93]

[0001564590-15-006142:mdna:86]
[same as prior period, unchanged from 0001564590-15-000491:mdna:94]

[0001564590-15-006142:mdna:87]
[same as prior period, unchanged from 0001564590-15-000491:mdna:95]

[0001564590-15-006142:mdna:88]
[same as prior period, unchanged from 0001564590-15-000491:mdna:96]

[0001564590-15-006142:mdna:89]
[same as prior period, unchanged from 0001564590-15-000491:mdna:97]

[0001564590-15-006142:mdna:90]
In May 2014, the FASB and the International Accounting Standards Board (IASB) issued, ASU Revenue from Contracts with Customers 2014-09 (Topic 606). The guidance substantially converges final standards on revenue recognition between the FASB and IASB providing a framework on addressing revenue recognition issues and, upon its effective date, replaces almost all existing revenue recognition guidance, including industry-specific guidance, in current U.S. generally accepted accounting principles.  The ASU is effective for annual reporting periods beginning after December 15, 2017.  We are currently evaluating the impact of adopting ASU 2014-09 to determine the impact, if any, it may have on our current practices.

[0001564590-15-006142:mdna:91]
In July 2014, the FASB issued ASU 2014-12, Compensation – Stock Compensation (Topic 718): Accounting for Share Based Payments When the Terms of an Award Provide that a Performance Target Could be Achieved after the Requisite Service Period.    To account for such awards, a reporting entity should apply existing guidance in FASB Accounting Standards Codification Topic 718, Compensation – Stock Compensation, as it relates to awards with performance conditions that affect vesting.  As such, the performance target should not be reflected in estimating the grant-date fair value of the award. This ASU is effective for annual reporting periods and interim periods, within those annual periods beginning after December 15, 2015.  We are currently evaluating the impact of adopting ASU 2014-12 to determine the impact, if any, it may have on our current practices.

[0001564590-15-006142:mdna:92]
In August 2014, the FASB issued ASU 2014-15, Presentation of Financial Statements – Going Concern (Subtopic 205-40): Disclosure of Uncertainties About an Entity’s Ability to Continue as a Going Concern.  The new standard explicitly requires the assessment at interim and annual periods, and provides management with its own disclosure guidance. This ASU is effective for annual reporting periods and interim periods, within those annual periods ending after December 15, 2016.  We are currently evaluating the impact of ASU 2014-15, if any, may have on our current practices.

[0001564590-15-006142:mdna:93]
In April 2015, the FASB issued ASU 2015-03 Interest—Imputation of Interest (Subtopic 835-30): Simplifying the Presentation of Debt Issuance Costs.  The amendments in ASU 2015-03 require an entity to present debt issuance costs on the balance sheet as a direct deduction from the related debt liability as opposed to an asset. Amortization of the costs will continue to be reported as interest expense. This ASU is effective for annual reporting periods beginning after December 15, 2015, and interim periods within those fiscal years.  We are currently evaluating the impact of adopting ASU 2015-03 to determine the impact, but currently do not believe there will be an impact on our consolidated results of operations, financial condition, or cash flow.

[0001564590-15-006142:mdna:94]
In June 2015, the FASB issued ASU 2015-10 Technical Corrections and Improvements.  The amendments in ASU 2015-10 will clarify and correct some of the difference that arose between original guidance from FASB, EITF and other sources, and the translation into the new Codification. This ASU is effective for annual reporting periods beginning after December 15, 2015, and interim periods within those fiscal years.  We are currently evaluating the impact of adopting ASU 2015-10 to determine the impact, but currently do not believe there will be an impact on our consolidated results of operations, financial condition, or cash flow.
