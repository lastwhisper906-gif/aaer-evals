# AMSC notes — 0001564590-15-006142


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001564590-15-006142:notes:1]
[same as prior period, unchanged from 0001564590-15-000491:notes:1]

[0001564590-15-006142:notes:2]
The Company accounts for its stock-based compensation at fair value. The following table summarizes stock-based compensation expense by financial statement line item for the three months ended June 30, 2015 and 2014 (in thousands):

[0001564590-15-006142:notes:3]
|  | Three months ended June 30, |  |
|  | 2015 |  |  | 2014 |  |
| Cost of revenues | $ | 97 |  |  | $ | 153 |  |
| Research and development |  | 196 |  |  |  | 479 |  |
| Selling, general and administrative |  | 835 |  |  |  | 949 |  |
| Total | $ | 1,128 |  |  | $ | 1,581 |  |

[0001564590-15-006142:notes:4]
During the three months ended June 30, 2015, the Company granted 364,695 restricted stock awards.  These awards generally vest over 3 years.  During the three months ended June 30, 2014, the Company granted approximately 100,000 stock options and 97,233 restricted stock awards.  The stock options vest over 5 years, and the restricted stock awards vest over one year. For options and awards that vest upon the passage of time, expense is being recorded over the vesting period.  Performance-based restricted stock awards are expensed over the requisite service period based on probability of achievement.

[0001564590-15-006142:notes:5]
The estimated fair value of the Company’s stock-based awards, less expected annual forfeitures, is amortized over the awards’ service period. The total unrecognized compensation cost for unvested outstanding stock options was $1.0 million at June 30, 2015. This expense will be recognized over a weighted average expense period of approximately 2.8 years. The total unrecognized compensation cost for unvested outstanding restricted stock was $3.9 million at June 30, 2015. This expense will be recognized over a weighted-average expense period of approximately 2.5 years.

[0001564590-15-006142:notes:6]
The weighted-average assumptions used in the Black-Scholes valuation model for stock options granted during the three months ended June 30, 2015 and 2014 are as follows:

[0001564590-15-006142:notes:7]
|  | Three months ended June 30, |  |
|  | 2015 |  | 2014 |  |
| Expected volatility | N/A |  |  | 85.5 | % |
| Risk-free interest rate | N/A |  |  | 1.9 | % |
| Expected life (years) | N/A |  |  | 5.8 |  |
| Dividend yield | None |  | None |  |

[0001564590-15-006142:notes:8]
[same as prior period, unchanged from 0001564590-15-000491:notes:8]


## us-gaap:EarningsPerShareTextBlock

[0001564590-15-006142:notes:9]
[same as prior period, unchanged from 0001564590-15-000491:notes:9]

[0001564590-15-006142:notes:10]
Basic net loss per share (“EPS”) is computed by dividing net loss by the weighted-average number of common shares outstanding for the period. Where applicable, diluted EPS is computed by dividing the net loss by the weighted-average number of common shares and dilutive common equivalent shares outstanding during the period, calculated using the treasury stock method. Common equivalent shares include the effect of restricted stock, exercise of stock options and warrants and contingently issuable shares. For the three months ended June 30, 2015, 1.6 million shares were not included in the calculation of diluted EPS as they were considered anti-dilutive, of which 0.4 million relate to unexercised stock options, and 1.2 million relate to outstanding warrants. For the three months ended June 30, 2014, 0.7 million shares were not included in the calculation of diluted EPS as they were considered anti-dilutive, of which 0.4 million relate to unvested stock options, and 0.3 million relate to outstanding warrants.

[0001564590-15-006142:notes:11]
The following table reconciles the numerators and denominators of the earnings per share calculation for the three months ended June 30, 2015 and 2014 (in thousands, except per share data):

[0001564590-15-006142:notes:12]
|  | Three months ended June 30, |  |
|  | 2015 |  |  |  | 2014 |  |
| Numerator: |  |  |  |  |  |  |  |  |
| Net loss |  | (9,121 | ) |  | $ |  | (13,517 | ) |
| Denominator: |  |  |  |  |  |  |  |  |
| Weighted-average shares of common stock outstanding |  | 12,312 |  |  |  |  | 7,962 |  |
| Weighted-average shares subject to repurchase |  | (201 | ) |  |  |  | (193 | ) |
| Shares used in per-share calculation ― basic |  | 12,111 |  |  |  |  | 7,769 |  |
| Shares used in per-share calculation ― diluted |  | 12,111 |  |  |  |  | 7,769 |  |
| Net loss per share ― basic |  | (0.75 | ) |  | $ |  | (1.74 | ) |
| Net loss per share ― diluted |  | (0.75 | ) |  | $ |  | (1.74 | ) |


## us-gaap:FairValueDisclosuresTextBlock

[0001564590-15-006142:notes:13]
[same as prior period, unchanged from 0001564590-15-000491:notes:13]

[0001564590-15-006142:notes:14]
[same as prior period, unchanged from 0001564590-15-000491:notes:14]

[0001564590-15-006142:notes:15]
[same as prior period, unchanged from 0001564590-15-000491:notes:15]

[0001564590-15-006142:notes:16]
The Company provides a gross presentation of activity within Level 3 measurement roll-forward and details of transfers in and out of Level 1 and 2 measurements.  A change in the hierarchy of an investment from its current level is reflected in the period during which the pricing methodology of such investment changes.  Disclosure of the transfer of securities from Level 1 to Level 2 or Level 3 is made in the event that the related security is significant to total cash and investments.  The Company did not have any transfers of assets and liabilities from Level 1 and Level 2 to Level 3 of the fair value measurement hierarchy during the three months ended June 30, 2015.

[0001564590-15-006142:notes:17]
[same as prior period, unchanged from 0001564590-15-000491:notes:17]

[0001564590-15-006142:notes:18]
The following table provides the assets and liabilities carried at fair value on a recurring basis, measured as of June 30, 2015 and March 31, 2015 (in thousands):

[0001564590-15-006142:notes:19]
|  | Total |  |  | Quoted Prices in |  |  | Significant Other |  |  | Significant |  |
|  | Carrying |  |  | Active Markets |  |  | Observable Inputs |  |  | Unobservable Inputs |  |
|  | Value |  |  | (Level 1) |  |  | (Level 2) |  |  | (Level 3) |  |
| June 30, 2015: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash equivalents | $ | 26,010 |  |  | $ | 26,010 |  |  | $ | - |  |  | $ | - |  |
| Derivative liabilities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Warrants | $ | 2,198 |  |  | $ | - |  |  | $ | - |  |  | $ | 2,198 |  |
|  | Total |  |  | Quoted Prices in |  |  | Significant Other |  |  | Significant |  |
|  | Carrying |  |  | Active Markets |  |  | Observable Inputs |  |  | Unobservable Inputs |  |
|  | Value |  |  | (Level 1) |  |  | (Level 2) |  |  | (Level 3) |  |
| March 31, 2015: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash equivalents | $ | 12,519 |  |  | $ | 12,519 |  |  | $ | - |  |  | $ | - |  |
| Derivative liabilities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Warrants | $ | 2,999 |  |  | $ | - |  |  | $ | - |  |  | $ | 2,999 |  |

[0001564590-15-006142:notes:20]
The table below reflects the activity for the Company’s major classes of liabilities measured at fair value on a recurring basis (in thousands):

[0001564590-15-006142:notes:21]
|  |  |  | Warrants |  |
| April 1, 2015 |  |  | $ | 2,999 |  |
| Mark to market adjustment |  |  |  | (801 | ) |
| Balance at June 30, 2015 |  |  | $ | 2,198 |  |
|  |  |  | Warrants |  |
| April 1, 2014 |  |  | $ | 2,601 |  |
| Warrant issuance with equity offering |  |  |  | 4,255 |  |
| Warrant issuance with senior secured term loan |  |  |  | 106 |  |
| Mark to market adjustment |  |  |  | (3,963 | ) |
| Balance at March 31, 2015 |  |  | $ | 2,999 |  |

[0001564590-15-006142:notes:22]
The following table provides the assets and liabilities measured at fair value on a non-recurring basis, as of June 30, 2015.  During the three months ended June 30, 2015 the Company’s investment in Tres Amigas was determined to be no longer recoverable and was fully impaired.  See note 14, “Minority Investments” for further details:

[0001564590-15-006142:notes:23]
|  | Total |  |  | Quoted Prices in |  | Significant Other |  | Significant |  |
|  | Carrying |  |  | Active Markets |  | Observable Inputs |  | Unobservable Inputs |  |
|  | Value |  |  | (Level 1) |  | (Level 2) |  | (Level 3) |  |
| June 30, 2015: |  |  |  |  |  |  |  |  |  |  |  |
| Assets: |  |  |  |  |  |  |  |  |  |  |  |
| Investment in unconsolidated entity – Tres Amigas | $ | - |  |  | $ |  | $ |  | $ | - |  |

[0001564590-15-006142:notes:24]
[same as prior period, unchanged from 0001564590-15-000491:notes:24]

[0001564590-15-006142:notes:25]
[same as prior period, unchanged from 0001564590-15-000491:notes:25]

[0001564590-15-006142:notes:26]
[same as prior period, unchanged from 0001564590-15-000491:notes:26]

[0001564590-15-006142:notes:27]
[same as prior period, unchanged from 0001564590-15-000491:notes:29]

[0001564590-15-006142:notes:28]
Warrants were issued in conjunction with a Securities Purchase Agreement (the “Purchase Agreement”) with Capital Ventures International (“CVI”), an equity offering to Hudson Bay Capital in November 2014, and a Loan and Security Agreement with Hercules Technology Growth Capital, Inc. (“Hercules”). (See Note 10, “Debt,” and Note 11 “Warrants and Derivative Liabilities,” for additional information.) These warrants are subject to revaluation at each balance sheet date, and any change in fair value will be recorded as a change in fair value in derivatives and warrants until the earlier of their exercise or expiration.

[0001564590-15-006142:notes:29]
[same as prior period, unchanged from 0001564590-15-000491:notes:31]

[0001564590-15-006142:notes:30]
[same as prior period, unchanged from 0001564590-15-000491:notes:32]

[0001564590-15-006142:notes:31]
The Company accounts for the minority investment in Tres Amigas on the equity basis (See Note 14, “Minority Investments”).  During the three months ended June 30, 2015, the Company determined that as a result of delays in Tres Amigas securing financing for the project as well as the Company’s projected recovery of its investment based on recent adverse market indicators for potential sales of the Company’s share of the investment, that its investment in Tres Amigas was no longer recoverable and therefore recorded an impairment charge of $0.7 million.


## us-gaap:LoansNotesTradeAndOtherReceivablesDisclosureTextBlock

[0001564590-15-006142:notes:32]
[same as prior period, unchanged from 0001564590-15-000491:notes:35]

[0001564590-15-006142:notes:33]
Accounts receivable at June 30, 2015 and March 31, 2015 consisted of the following (in thousands):

[0001564590-15-006142:notes:34]
|  | June 30, |  |  | March 31, |  |
|  | 2015 |  |  | 2015 |  |
| Accounts receivable (billed) | $ | 6,601 |  |  | $ | 8,946 |  |
| Accounts receivable (unbilled) |  | 1,944 |  |  |  | 987 |  |
| Less: Allowance for doubtful accounts |  | (54 | ) |  |  | (54 | ) |
| Accounts receivable, net | $ | 8,491 |  |  | $ | 9,879 |  |


## us-gaap:InventoryDisclosureTextBlock

[0001564590-15-006142:notes:35]
[same as prior period, unchanged from 0001564590-15-000491:notes:38]

[0001564590-15-006142:notes:36]
Inventory at June 30, 2015 and March 31, 2015 consisted of the following (in thousands):

[0001564590-15-006142:notes:37]
|  | June 30, |  |  | March 31, |  |
|  | 2015 |  |  | 2015 |  |
| Raw materials | $ | 8,018 |  |  | $ | 9,411 |  |
| Work-in-process |  | 1,092 |  |  |  | 2,117 |  |
| Finished goods |  | 6,286 |  |  |  | 7,487 |  |
| Deferred program costs |  | 1,684 |  |  |  | 1,581 |  |
| Net inventory | $ | 17,080 |  |  | $ | 20,596 |  |

[0001564590-15-006142:notes:38]
The Company recorded inventory write-downs of $0.6 million for each of the three months ended June 30, 2015 and 2014.  These write downs were based on evaluating its inventory on hand for excess quantities and obsolescence.

[0001564590-15-006142:notes:39]
Deferred program costs as of June 30, 2015 and March 31, 2015 primarily represent costs incurred on programs accounted for under contract accounting where the Company needs to complete development milestones before revenue and costs will be recognized.


## us-gaap:AccountsPayableAndAccruedLiabilitiesDisclosureTextBlock

[0001564590-15-006142:notes:40]
[same as prior period, unchanged from 0001564590-15-000491:notes:43]

[0001564590-15-006142:notes:41]
Accounts payable and accrued expenses at June 30, 2015 and March 31, 2015 consisted of the following (in thousands):

[0001564590-15-006142:notes:42]
|  | June 30, |  |  | March 31, |  |
|  | 2015 |  |  | 2015 |  |
| Accounts payable | $ | 6,613 |  |  | $ | 7,062 |  |
| Accrued inventories in-transit |  | 964 |  |  |  | 1,127 |  |
| Accrued miscellaneous expenses |  | 2,969 |  |  |  | 2,695 |  |
| Accrued outside services |  | 684 |  |  |  | 582 |  |
| Accrued compensation |  | 3,545 |  |  |  | 5,937 |  |
| Income taxes payable |  | 526 |  |  |  | 278 |  |
| Accrued warranty |  | 3,344 |  |  |  | 3,934 |  |
| Total | $ | 18,645 |  |  | $ | 21,615 |  |

[0001564590-15-006142:notes:43]
[same as prior period, unchanged from 0001564590-15-000491:notes:46]

[0001564590-15-006142:notes:44]
[same as prior period, unchanged from 0001564590-15-000491:notes:47]

[0001564590-15-006142:notes:45]
|  | Three months ended |  |
|  | June 30, |  |
|  | 2015 |  |  | 2014 |  |
| Balance at beginning of period | $ | 3,934 |  |  | $ | 3,207 |  |
| Change in accruals for warranties during the period |  | (5 | ) |  |  | (72 | ) |
| Settlements during the period |  | (585 | ) |  |  | (280 | ) |
| Balance at end of period | $ | 3,344 |  |  | $ | 2,855 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0001564590-15-006142:notes:46]
[same as prior period, unchanged from 0001564590-15-000491:notes:49]

[0001564590-15-006142:notes:47]
The Company recorded income tax expense of $0.6 million and $0.1 million for the three months ended June 30, 2015, and 2014, respectively.  Income tax expense was primarily due to income taxes in the Company’s foreign jurisdictions.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001564590-15-006142:notes:48]
[same as prior period, unchanged from 0001564590-15-000491:notes:51]

[0001564590-15-006142:notes:49]
[same as prior period, unchanged from 0001564590-15-000491:notes:52]

[0001564590-15-006142:notes:50]
During the years ended March 31, 2015 and 2014, the Company undertook restructuring activities, approved by the Board of Directors, in order to reorganize its global operations, streamline various functions of the business, and reduce its global workforce to better reflect the demand for its products.  During the year ended March 31, 2014, the Company undertook a plan to consolidate its Grid manufacturing activities in its Devens, Massachusetts facility and close its facility in Middleton, Wisconsin which was completed during the year ended March 31, 2015.  In addition, the Company established a new Wind manufacturing facility in Romania and as a result reduced the headcount in its operation in China.  The Company is maintaining its headcount in China at a level necessary to support demand from its Chinese customers.  The Company recorded restructuring charges for severance and other costs of approximately $1.2 million during the three months ended June 30, 2014, primarily associated with the consolidation of the Company’s Grid manufacturing activities in the United States.  From April 1, 2011 through June 30, 2015, the Company’s various restructuring activities resulted in a substantial reduction of its global workforce. Remaining unpaid amounts under these restructuring activities are expected to be paid by August 31, 2015.

[0001564590-15-006142:notes:51]
[same as prior period, unchanged from 0001564590-15-000491:notes:54]

[0001564590-15-006142:notes:52]
|  | Severance pay |  |  | Facility exit and |  |  |  |  |  |
| Three months ended June 30, 2015 | and benefits |  |  | Relocation costs |  |  | Total |  |
| Accrued restructuring balance at April 1, 2015 | $ | 180 |  |  | $ | - |  |  | $ | 180 |  |
| Cash payments |  | (162 | ) |  |  | - |  |  |  | (162 | ) |
| Accrued restructuring balance at June 30, 2015 | $ | 18 |  |  | $ | - |  |  | $ | 18 |  |
|  | Severance pay |  |  | Facility exit and |  |  |  |  |  |
| Three months ended June 30, 2014 | and benefits |  |  | Relocation costs |  |  | Total |  |
| Accrued restructuring balance at April 1, 2014 | $ | 844 |  |  | $ | - |  |  | $ | 844 |  |
| Charges to operations |  | 690 |  |  |  | 489 |  |  |  | 1,179 |  |
| Cash payments |  | (589 | ) |  |  | (489 | ) |  |  | (1,078 | ) |
| Accrued restructuring balance at June 30, 2014 | $ | 945 |  |  | $ | - |  |  | $ | 945 |  |

[0001564590-15-006142:notes:53]
[same as prior period, unchanged from 0001564590-15-000491:notes:56]


## us-gaap:DebtDisclosureTextBlock

[0001564590-15-006142:notes:54]
10. Debt

[0001564590-15-006142:notes:55]
On June 5, 2012, the Company entered into a Loan and Security Agreement with Hercules, (the “Term Loan”), under which the Company borrowed $10.0 million. After the closing fees and expenses, the net proceeds to the Company were $9.7 million. The Term Loan bears an interest rate equal to 11% plus the percentage, if any, by which the prime rate as reported by The Wall Street Journal exceeds 3.75%. The Company made interest-only payments from July 1, 2012 through October 31, 2012, after which the Company began repaying the Term Loan in equal monthly installments ending on December 1, 2014, when the loan was repaid in full. In addition, Hercules received a warrant (the “First Warrant”) to purchase 13,927 shares of common stock, exercisable at an initial strike price of $35.90 per share, subject to adjustment, until December 5, 2017. Due to certain adjustment provisions within the warrant, it qualified for liability accounting and the fair value of $0.4 million was recorded upon issuance, which the Company recorded as a debt discount and a warrant liability.  The total debt discount including the First Warrant, end of term fee and legal and origination costs of $1.2 million was amortized into interest expense over the term of the Term Loan using the effective interest method. Under this method, interest expense was recognized each period until the debt instrument reached maturity. During the three months ended June 30, 2014, the Company recorded non-cash interest expense for amortization of the debt discount related to the Term Loan of $0.1 million.

[0001564590-15-006142:notes:56]
On November 15, 2013, the Company amended the Term Loan with Hercules and entered into a new term loan (the “New Term Loan B”), borrowing an additional $10.0 million. After closing fees and expenses, the net proceeds to the Company for the New Term Loan B were $9.8 million.  The New Term Loan B bears the same interest rate as the Term Loan.  The Company is repaying the New Term Loan B in equal monthly installments ending on November 1, 2016.  The principal balance of the New Term Loan B is approximately $5.7 million as of June 30, 2015.  Hercules received a warrant (the “Second Warrant”) to purchase 25,641 shares of common stock, exercisable at an initial strike price of $19.50 per share, subject to adjustment, until May 15, 2019.  In addition, the exercise price of the First Warrant was reduced to $19.50 per share.  (See Note 11, “Warrants and Derivative Liabilities,” for a discussion on both warrants and the valuation assumptions used.) The Company will pay an end of term fee of $0.5 million upon the earlier of maturity or prepayment of the New Term Loan B. The Company has accrued the end of term fee and recorded a corresponding amount into the debt discount.  The New Term Loan B includes a mandatory prepayment feature which allows Hercules the right to use any of the Company’s net proceeds from specified asset dispositions greater than $1.0 million in a calendar year to pay off any outstanding accrued interest and principal balance on the New Term Loan B.  The Company determined the fair value to be deminimis for this feature. In addition, the Company incurred $0.2 million of legal and origination costs in the three months ended December 31, 2013, which have been recorded as a debt discount. The total debt discount including the Second Warrant, end of term fee and legal and origination costs of $1.0 million is being amortized into interest expense over the term of the New Term Loan B using the effective interest method. During both the three months ended June 30, 2015 and 2014 the Company recorded non-cash interest expense for amortization of the debt discount related to the New Term Loan B of $0.1 million.

[0001564590-15-006142:notes:57]
On December 19, 2014, the Company entered into an amendment with Hercules (the “Hercules Second Amendment”) and entered into a new term loan (the “New Term Loan C”), borrowing an additional $1.5 million.  After closing fees and expenses, the net proceeds to the Company for the New Term Loan C were $1.4 million.  The Term Loan, New Term Loan B and New Term Loan C are collectively referred to as the “Term Loans”.  The New Term Loan C also bears the same interest rate as the other Term Loans.  The Company will make interest only payments until maturity on June 1, 2017, when the loan is scheduled to be repaid in its entirety.  The maturity date of the New Term Loan C was extended from March 1, 2017 to June 1, 2017 due to the Company’s April 2015 equity offering which raised more than $10 million in new capital before December 31, 2015.  In conjunction with the Hercules Second Amendment, the First and Second Warrants were cancelled and replaced with the issuance of a new warrant (the “Warrant”) to purchase 58,823 shares of common stock at an exercise price of $11.00 per share, subject to adjustment.  The Warrant expires on June 30, 2020.  (See Note 11, “Warrants and Derivative Liabilities”, for a discussion on the Warrant and the valuation assumptions used.)  The Company will pay an end of term fee of approximately $0.1 million upon earlier of maturity or prepayment of the New Term Loan C.  The Company has accrued the end of term fee and recorded a corresponding amount in the debt discount.  The New Term Loan C includes the same mandatory prepayment feature as the New Term Loan B.   The Company determined the fair value to be de-minimus for this feature.  In addition, the Company incurred approximately $0.1 million of legal and origination costs in the three months ended December 31, 2014, which have been recorded as a debt discount.  The total debt discount, including the Warrant, end of term fee and legal and origination costs of $0.3 million is being amortized into interest expense over the term of the New Term Loan C using the effective interest method.  During the three months ended June 30, 2015, the Company recorded non-cash interest expense for amortization of the debt discount related to the New Term Loan C of less than $0.1 million.  If the maturity of any of the Term Loans is accelerated because of prepayment, then the amortization will be accelerated.

[0001564590-15-006142:notes:58]
The Term Loans are secured by substantially all of the Company’s existing and future assets, including a mortgage on real property owned by the Company’s wholly-owned subsidiary, ASC Devens LLC, and located at 64 Jackson Road, Devens, Massachusetts.  The Term Loans contain certain covenants that restrict the Company’s ability to, among other things, incur or assume certain debt, merge or consolidate, materially change the nature of the Company’s business, make certain investments, acquire or dispose of certain assets, make guaranties or grant liens on its assets, make certain loans, advances or investments, declare dividends or make distributions or enter into transactions with affiliates. In addition, there is a covenant that requires the Company to maintain a minimum unrestricted cash balance (the “Minimum Threshold”) in the United States.  As part of the Hercules Second Amendment, this Minimum Threshold was amended to be the lower of $5.0 million or the aggregate outstanding principal balance of the Term Loans.  As a result of the Company’s April 2015 equity offering, the Minimum Threshold was reduced to the lesser of $2.0 million or the aggregate outstanding principal balance of the Term Loans.  As of June 30, 2015 the Minimum Threshold was $2.0 million.  The events of default under the Term Loans include, but are not limited to, failure to pay amounts due, breaches of covenants, bankruptcy events, cross defaults under other material indebtedness and the occurrence of a material adverse effect and/or change in control. In the case of a continuing event of default, Hercules may, among other remedies, declare due all unpaid principal amounts outstanding and any accrued but unpaid interest and foreclose on all collateral granted to Hercules as security under the Term Loans.

[0001564590-15-006142:notes:59]
Although the Company believes that it is in and expects to remain in compliance with the covenants and restrictions under the Term Loans as of June 30, 2015, there can be no assurance that the Company will continue to be in compliance.

[0001564590-15-006142:notes:60]
Interest expense on the Term Loans for the three months ended June 30, 2015, and 2014, was $0.3 million, and $0.5 million, respectively, which included $0.1 million and $0.2 million, respectively, of non-cash interest expense related to the amortization of the debt discount on the Term Loans.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001564590-15-006142:notes:61]
[same as prior period, unchanged from 0001564590-15-000491:notes:77]

[0001564590-15-006142:notes:62]
[same as prior period, unchanged from 0001564590-15-000491:notes:78]

[0001564590-15-006142:notes:63]
On April 4, 2012, the Company entered into the Purchase Agreement with CVI. The Purchase Agreement included a warrant (the “Original Warrant”) to purchase 309,406 shares of the Company’s common stock. The Original Warrant is exercisable at any time on or after the date that is six months after the issuance of the Original Warrant and entitles CVI to purchase shares of the Company’s common stock for a period of five years from the initial date the original warrant becomes exercisable at an initial exercise price equal to $54.50 per share, subject to certain price-based and other anti-dilution adjustments. On October 9, 2013, the Company amended the Purchase Agreement with CVI (the “Amendment”). Pursuant to the Amendment, the Company exchanged the Original Warrant for a new warrant (the “Exchanged Warrant”), with a reduced exercise price of $26.10 per share of common stock. Other than the reduced exercise price, the Exchanged Warrant has the same terms and conditions as the Original Warrant.  As a result of the sales of common stock under an At Market Sales Arrangement (“ATM”) and the 909,090 units, each consisting of one share of common stock and 0.90 of a warrant to purchase one share of common stock, sold to Hudson Bay Capital during the three months ended December 31, 2014, the exercise price of the Exchanged Warrant was further reduced to $22.10 per share.  As a result of the April 2015 equity offering (see Note 12, “Stockholders Equity”), the exercise price of the Exchanged Warrant was further reduced to $15.94 per share.  The Exchanged Warrant may not be exercised if, after giving effect to the conversion, CVI together with its affiliates, would beneficially own in excess of 4.99% of the Company’s common stock. This percentage may be raised to any other percentage not in excess of 9.99% at the option of CVI, upon at least 61-days prior notice to the Company, or lowered to any other percentage, at the option of CVI, at any time.

[0001564590-15-006142:notes:64]
The Company calculated the fair value of the Exchanged Warrant, (see Note 4, “Fair Value Measurements” for further discussion), utilizing an integrated lattice model. The lattice model is an option pricing model that involves the construction of a binomial tree to show the different paths that the underlying asset may take over the option’s life. A lattice model can take into account expected changes in various parameters such as volatility over the life of the options, providing more accurate estimates of option prices than the Black-Scholes model.

[0001564590-15-006142:notes:65]
The Company accounts for the Exchanged Warrant as a liability due to certain adjustment provisions within the warrant, which requires that it be recorded at fair value. The Exchanged Warrant is subject to revaluation at each balance sheet date and any change in fair value is recorded as a change in fair value of derivatives and warrants until the earlier of its expiration or its exercise at which time the warrant liability will be reclassified to equity.

[0001564590-15-006142:notes:66]
Following is a summary of the key assumptions used to calculate the fair value of the Exchanged Warrant:

[0001564590-15-006142:notes:67]
|  | June 30, |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Fiscal Year 15 | 2015 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Risk-free interest rate |  | 0.74 | % |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Expected annual dividend yield |  | — | % |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Expected volatility |  | 71.61 | % |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Term (years) | 2.26 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Fair value | $0.2 million |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  | March 31, |  |  | December 31, |  |  | September 30, |  |  | June 30, |  |  | March 31, |  |
| Fiscal Year 14 | 2015 |  |  | 2014 |  |  | 2014 |  |  | 2014 |  |  | 2014 |  |
| Risk-free interest rate |  | 0.73 | % |  |  | 1.00 | % |  |  | 1.07 | % |  |  | 0.98 | % |  |  | 1.11 | % |
| Expected annual dividend yield |  | — | % |  |  | — | % |  |  | — | % |  |  | — | % |  |  | — | % |
| Expected volatility |  | 70.42 | % |  |  | 72.38 | % |  |  | 76.20 | % |  |  | 83.50 | % |  |  | 80.99 | % |
| Term (years) | 2.51 |  |  | 2.76 |  |  | 3.01 |  |  | 3.26 |  |  | 3.51 |  |
| Fair value | $0.3 million |  |  | $0.5 million |  |  | $1.5 million |  |  | $2.3 million |  |  | $ 2.2 million |  |

[0001564590-15-006142:notes:68]
The Company recorded a net gain, resulting from the decrease in the fair value of the Exchanged Warrant, of $0.1 million to change in fair value of derivatives and warrants during the three months ended June 30, 2015.  The Company recorded a net loss resulting from the increase in the fair value of the Exchanged Warrant of $0.1 million to the change in fair value of derivatives and warrants during the three months ended June 30, 2014.

[0001564590-15-006142:notes:69]
[same as prior period, unchanged from 0001564590-15-000491:notes:93]

[0001564590-15-006142:notes:70]
On June 5, 2012, the Company entered into the Loan and Security Agreement with Hercules. (See Note 10, “Debt,” for additional information regarding the Loan and Security Agreement.) In conjunction with this agreement, the Company issued the First Warrant to purchase 13,927 shares of the Company’s common stock. The First Warrant was exercisable at any time after its issuance and had an expiration date of December 5, 2017, at an initial exercise price equal to $35.90 per share subject to certain price-based and other anti-dilution adjustments.  The exercise price was reduced to $19.50 per share in conjunction with entering into the New Term Loan B.  An anti-dilution adjustment from the sale of 909,090 units, each consisting of one share of common stock and 0.90 of a warrant to purchase one share of common stock, to Hudson Bay Capital (See Note 12, “Stockholders Equity”), resulted in a reduction of the exercise price to $17.00 per share on November 13, 2014.  The Hercules Second Amendment resulted in the cancellation of the First Warrant on December 19, 2014.

[0001564590-15-006142:notes:71]
The Company accounted for the First Warrant as a liability due to certain provisions within the warrant. The First Warrant was subject to revaluation at each balance sheet date and any change in fair value was recorded as a change in fair value of derivatives and warrants until the warrant was cancelled on December 19, 2014.

[0001564590-15-006142:notes:72]
[same as prior period, unchanged from 0001564590-15-000491:notes:96]

[0001564590-15-006142:notes:73]
|  |  |  |  |  | Pre-Exchange |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  | December 31, |  |  | December 19, |  |  | September 30, |  |  | June 30, |  |  | March 31, |  |
| Fiscal Year 14 | 2014 |  |  | 2014 |  |  | 2014 |  |  | 2014 |  |  | 2014 |  |
| Risk-free interest rate |  | — | % |  |  | 1.10 | % |  |  | 1.13 | % |  |  | 1.04 | % |  |  | 1.18 | % |
| Expected annual dividend yield |  | — | % |  |  | — | % |  |  | — | % |  |  | — | % |  |  | — | % |
| Expected volatility |  | — | % |  |  | 67.01 | % |  |  | 78.30 | % |  |  | 82.75 | % |  |  | 80.73 | % |
| Term (years) | — |  |  |  | 2.96 |  |  |  | 3.18 |  |  |  | 3.43 |  |  |  | 3.68 |  |
| Fair value | — |  |  | $ 0.1 million |  |  | $ 0.1 million |  |  | $ 0.1 million |  |  | $ 0.1 million |  |

[0001564590-15-006142:notes:74]
The Company recorded no change in the fair value of the First Warrant during the three month period ended June 30, 2014.

[0001564590-15-006142:notes:75]
[same as prior period, unchanged from 0001564590-15-000491:notes:99]

[0001564590-15-006142:notes:76]
On November 15, 2013, the Company amended the Loan and Security Agreement with Hercules and entered into the New Term Loan B. (See Note 10, “Debt,” for additional information regarding the New Term Loan B.) In conjunction with this agreement, the Company issued the Second Warrant to purchase 25,641 shares of the Company’s common stock. The Second Warrant was exercisable at any time after its issuance at an initial exercise price equal to $19.50 per share subject to certain price-based and other anti-dilution adjustments and had an expiration date of May 15, 2019.  An anti-dilution adjustment due to the sale of 909,090 units, each consisting of one share of common stock and 0.90 of a warrant to purchase one share of common stock, to Hudson Bay Capital (See Note 12, “Stockholders Equity”), resulted in a reduction of the exercise price to $17.00 per share, on November 13, 2014.  The Hercules Second Amendment resulted in the cancellation of the Second Warrant on December 19, 2014.

[0001564590-15-006142:notes:77]
The Company accounted for the Second Warrant as a liability due to certain provisions within the warrant. The Second Warrant was subject to revaluation at each balance sheet date and any change in fair value was recorded as a change in fair value of derivatives and warrants until the warrant was cancelled on December 19, 2014.

[0001564590-15-006142:notes:78]
[same as prior period, unchanged from 0001564590-15-000491:notes:102]

[0001564590-15-006142:notes:79]
|  |  |  |  |  | Pre-Exchange |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  | December 31, |  |  | December 19, |  |  | September 30, |  |  | June 30, |  |  | March 31, |  |
| Fiscal Year 14 | 2014 |  |  | 2014 |  |  | 2014 |  |  | 2014 |  |  | 2014 |  |
| Risk-free interest rate |  | — | % |  |  | 1.65 | % |  |  | 1.65 | % |  |  | 1.57 | % |  |  | 1.76 | % |
| Expected annual dividend yield |  | — | % |  |  | — | % |  |  | — | % |  |  | — | % |  |  | — | % |
| Expected volatility |  | — | % |  |  | 71.82 | % |  |  | 78.10 | % |  |  | 80.00 | % |  |  | 79.73 | % |
| Term (years) | — |  |  |  | 4.41 |  |  |  | 4.62 |  |  |  | 4.87 |  |  |  | 5.12 |  |
| Fair value | — |  |  | $0.1 million |  |  | $ 0.2 million |  |  | $ 0.3 million |  |  | $ 0.3 million |  |

[0001564590-15-006142:notes:80]
The Company recorded no change in the fair value of the Second Warrant during the three months ended June 30, 2014.

[0001564590-15-006142:notes:81]
[same as prior period, unchanged from 0001564590-15-000491:notes:106]

[0001564590-15-006142:notes:82]
On December 19, 2014, the Company entered into the Hercules Second Amendment and entered into the New Term Loan C. (See Note 10, “Debt” for additional information regarding the New Term Loan C).  In conjunction with the agreement, the Company cancelled the First and Second Warrants, and reissued the Warrant to purchase 58,823 shares of the Company’s common stock.  The Warrant is exercisable at any time after its issuance at an initial exercise price of $11.00 per share, subject to certain price-based and other anti-dilution adjustments, and expires on June 30, 2020.  As a result of the equity offering on April 29, 2015, (See Note 12, “Stockholders Equity”) the exercise price of the Warrant was reduced to $9.41 per share.

[0001564590-15-006142:notes:83]
The Company accounts for the Warrant as a liability due to certain provisions within the Warrant.  The Warrant is subject to revaluation at each balance sheet date and any change in fair value is recorded as a change in fair value of derivatives and warrants until the earlier of its expiration or its exercise, at which time the warrant liability will be reclassified to equity.

[0001564590-15-006142:notes:84]
[same as prior period, unchanged from 0001564590-15-000491:notes:109]

[0001564590-15-006142:notes:85]
|  | June 30, |  |  |  |  |  |  |  |  |  |
| Fiscal Year 15 | 2015 |  |  |  |  |  |  |  |  |  |
| Risk-free interest rate |  | 1.63 | % |  |  |  |  |  |  |  |  |
| Expected annual dividend yield |  | — | % |  |  |  |  |  |  |  |  |
| Expected volatility |  | 72.57 | % |  |  |  |  |  |  |  |  |
| Term (years) |  | 5.00 |  |  |  |  |  |  |  |  |  |
| Fair value | $0.2 million |  |  |  |  |  |  |  |  |  |
|  |  |  |  |  |  |  |  |  | New Issuance |  |
|  | March 31, |  |  | December 31, |  |  | December 19, |  |
| Fiscal Year 14 | 2015 |  |  | 2014 |  |  | 2014 |  |
| Risk-free interest rate |  | 1.41 | % |  |  | 1.73 | % |  |  | 1.74 | % |
| Expected annual dividend yield |  | — | % |  |  | — | % |  |  | — | % |
| Expected volatility |  | 74.60 | % |  |  | 77.43 | % |  |  | 70.26 | % |
| Term (years) |  | 5.25 |  |  |  | 5.50 |  |  |  | 5.53 |  |
| Fair value | $0.2 million |  |  | $0.2 million |  |  | $0.2 million |  |

[0001564590-15-006142:notes:86]
The Company recorded a minimal change in the fair value of the Warrant to change in fair value of derivatives and warrants, resulting in a gain of less than $0.1 million in the three months ended June 30, 2015.

[0001564590-15-006142:notes:87]
[same as prior period, unchanged from 0001564590-15-000491:notes:112]

[0001564590-15-006142:notes:88]
On November 13, 2014, the Company completed an offering of approximately 909,090  units of the Company’s common stock with Hudson Bay Capital.  (See Note 12, “Stockholder’s Equity”, for further information).  Each unit consisted of one share of the Company’s common stock and 0.9 of a warrant to purchase one share of common stock, or a warrant to purchase in the aggregate 818,181 shares (the “November 2014 Warrant”).  The November 2014 Warrant is exercisable at any time, at an initial exercise price equal to $11.00 per share, subject to certain price-based and other anti-dilution adjustments, and expires on November 13, 2019.  As a result of the April 2015 equity offering, the exercise price of the November 2014 Warrant was reduced to $9.41 per share.

[0001564590-15-006142:notes:89]
The Company accounts for the November 2014 Warrant as a liability due to certain provisions within the warrant.  The November 2014 Warrant is subject to revaluation at each balance sheet date and any change in fair value is recorded as a change in fair value of derivatives and warrants until the earlier of its expiration or its exercise, at which time the warrant liability will be reclassified to equity.

[0001564590-15-006142:notes:90]
[same as prior period, unchanged from 0001564590-15-000491:notes:115]

[0001564590-15-006142:notes:91]
|  | June 30, |  |  |  |  |  |  |  |  |  |
| Fiscal Year 15 | 2015 |  |  |  |  |  |  |  |  |  |
| Risk-free interest rate |  | 1.44 | % |  |  |  |  |  |  |  |  |
| Expected annual dividend yield |  | — | % |  |  |  |  |  |  |  |  |
| Expected volatility |  | 74.18 | % |  |  |  |  |  |  |  |  |
| Term (years) |  | 4.37 |  |  |  |  |  |  |  |  |  |
| Fair value | $1.8 million |  |  |  |  |  |  |  |  |  |
|  |  |  |  |  |  |  |  |  | New Issuance |  |
|  | March 31, |  |  | December 31, |  |  | November 13, |  |
| Fiscal Year 14 | 2015 |  |  | 2014 |  |  | 2014 |  |
| Risk-free interest rate |  | 1.28 | % |  |  | 1.61 | % |  |  | 1.64 | % |
| Expected annual dividend yield |  | — | % |  |  | — | % |  |  | — | % |
| Expected volatility |  | 75.96 | % |  |  | 78.00 | % |  |  | 72.86 | % |
| Term (years) |  | 4.62 |  |  |  | 4.87 |  |  |  | 5.00 |  |
| Fair value | $2.5 million |  |  | $3.2 million |  |  | $4.3 million |  |

[0001564590-15-006142:notes:92]
The Company recorded a decrease in the fair value of the November 2014 Warrant, resulting in a gain of $0.7 million in the three months ended June 30, 2015.

[0001564590-15-006142:notes:93]
[same as prior period, unchanged from 0001564590-15-000491:notes:105]


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001564590-15-006142:notes:94]
[same as prior period, unchanged from 0001564590-15-000491:notes:118]

[0001564590-15-006142:notes:95]
On November 15, 2013, the Company entered into an ATM arrangement, pursuant to which, the Company was able to, at its discretion, sell up to $30.0 million of the Company’s common stock through its sales agent, MLV.   Sales of common stock made under the ATM were made on The Nasdaq Global Select Market under the Company’s previously filed and currently effective Registration Statement on Form S-3 (File No. 333-191153) by means of ordinary brokers’ transactions at market prices. Additionally, under the terms of the ATM, the Company was also able to sell shares of its common stock through MLV, on The Nasdaq Global Select Market or otherwise, at negotiated prices or at prices related to the prevailing market price. The Company paid MLV a commission of up to 3% of the gross proceeds from the sale of shares of its common stock under the ATM.  The Company also agreed to provide MLV with customary indemnification rights.

[0001564590-15-006142:notes:96]
During the three months ended June 30, 2014, the Company received net proceeds of $1.2 million, including sales commissions and offering expenses, from sales of approximately 76,434 shares of its common stock at an average sales price of approximately $16.31 per share under the ATM.  On November 5, 2014, the Company terminated its ATM arrangement.

[0001564590-15-006142:notes:97]
On November 13, 2014, the Company completed an equity offering to Hudson Bay Capital, under which the Company sold approximately 909,090 units of its common stock at $11.00 per share.  Each unit consisted of one share of common stock and 0.9 of a warrant to purchase one share of common stock, or a warrant to purchase approximately 818,181 shares of common stock.  (See Note 11, “Warrants and Derivative Liabilities”, for further information regarding the warrant).  After underwriting, commissions and expenses, the Company received net proceeds from the offering of approximately $9.1 million.  The Company allocated the net proceeds first to the fair value of the warrants as determined under a lattice model on November 13, 2014 (See Note 11, “Warrants and Derivative Liabilities,” for a discussion on both warrants and the valuation assumptions used) with the residual fair value allocated to the common stock. Costs of the offering were allocated to other (expense) income and equity based on the relative fair value of the warrants and common stock, respectively.

[0001564590-15-006142:notes:98]
On April 29, 2015, the Company completed an equity offering with Cowen and Company, LLC, under which the Company sold approximately 4.0 million shares of its common stock at an offering price of $6.00 per share.  After underwriting, commissions and expenses, the Company received net proceeds from the offering of approximately $22.3 million.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001564590-15-006142:notes:99]
13. Commitments and Contingencies

[0001564590-15-006142:notes:100]
Legal Contingencies

[0001564590-15-006142:notes:101]
From time to time, the Company is involved in legal and administrative proceedings and claims of various types. The Company records a liability in its consolidated financial statements for these matters when a loss is known or considered probable and the amount can be reasonably estimated. The Company reviews these estimates each accounting period as additional information is known and adjusts the loss provision when appropriate. If a matter is both probable to result in a liability and the amounts of loss can be reasonably estimated, the Company estimates and discloses the possible loss or range of loss. If the loss is not probable or cannot be reasonably estimated, a liability is not recorded in its consolidated financial statements.

[0001564590-15-006142:notes:102]
Ghodawat, a company registered in India carrying on the business of wind power development, lodged a Request for Arbitration with the ICC Court on May 12, 2011 and named the Company’s wholly-owned Austrain subsidiary, AMSC Austria GmbH (“AMSC Austria”) as the Respondent. Under the Request for Arbitration, Ghodawat alleged that AMSC Austria breached an agreement dated March 19, 2008 pursuant to which AMSC Austria granted a license to Ghodawat to manufacture, use, sell, market, erect, commission and maintain certain wind turbines using its technical information and wind turbine design (the “License Agreement”). Under the Request for Arbitration, Ghodawat’s claims in this arbitration amounted to approximately €18 million ($24 million).  AMSC Austria submitted counterclaims under the License Agreement against Ghodawat in the amount of approximately €6 million ($8 million).  On August 29, 2014, the ICC Court ruled that AMSC Austria was liable for damages and awarded Ghodawat approximately €8.3 million, which includes reimbursement of legal costs and associated expenses.  Interest on this amount accrued at a rate of 5.33% from the date of award until settlement.  The Company had recorded a loss contingency of $0.5 million based on its assessment of probable losses on this claim in a prior period.  As a result of the arbitration award liability, the Company recorded a charge of $10.2 million during the three months ended September 30, 2014.

[0001564590-15-006142:notes:103]
On February 4, 2015, AMSC Austria entered into a Settlement Agreement with Ghodawat, which provided for, among other things, (i) a payment by AMSC Austria to Ghodawat of €7.45 million, and (ii) upon payment by AMSC Austria to Ghodawat, the full settlement of any and all disputes and claims between the parties (including their respective parent and affiliated companies), in particular relating to or arising out of the award.  The Company paid the settlement amount during the fourth quarter of fiscal 2014.  As a result of this agreement, the Company reversed a portion of the accrued arbitration liability and recorded a gain of approximately $1.2 million in the fourth quarter of fiscal 2014.  The Company’s insurer, Catlin Specialty Insurance Company (“Catlin”) sought and received a ruling from the Massachusetts Superior Court that coverage does not apply to the arbitration award liability.  On January 14, 2015, the Company and AMSC Austria entered into a Settlement Agreement and Release with Catlin, which provided for, among other things, (i) the Company’s and AMSC Austria’s release of all claims against Catlin relating to the arbitration award liability and (ii) Catlin’s release of all claims against the Company and AMSC Austria relating to approximately $2.3 million reimbursed to date under the insurance policy for expenses incurred in connection with the arbitration proceedings.  As a result of the settlement with Catlin, in the fourth quarter of fiscal 2014, the Company reversed an accrual of approximately $2.2 million for expenses previously reimbursed by Catlin under the policy.

[0001564590-15-006142:notes:104]
On September 13, 2011, the Company commenced a series of legal actions in China against Sinovel Wind Group Co. Ltd. (“Sinovel”). The Company’s Chinese subsidiary, Suzhou AMSC Superconductor Co. Ltd., filed a claim for arbitration with the Beijing Arbitration Commission in accordance with the terms of the Company’s supply contracts with Sinovel. The case is captioned (2011) Jing Zhong An Zi No. 0963. On March 31, 2011, Sinovel refused to accept contracted shipments of 1.5 megawatt, (“MW”) and 3 MW wind turbine core electrical components and spare parts that the Company was prepared to deliver. The Company alleges that these actions constitute material breaches of its contracts because Sinovel did not give it notice that it intended to delay deliveries as required under the contracts. Moreover, the Company alleges that Sinovel has refused to pay past due amounts for prior shipments of core electrical components and spare parts. The Company is seeking compensation for past product shipments and retention (including interest) in the amount of approximately RMB 485 million ($76 million) due to Sinovel’s breaches of its contracts. The Company is also seeking specific performance of its existing contracts as well as reimbursement of all costs and reasonable expenses with respect to the arbitration. The value of the undelivered components under the existing contracts, including the deliveries refused by Sinovel in March 2011, amounts to approximately RMB 4.6 billion ($720 million).

[0001564590-15-006142:notes:105]
On October 8, 2011, Sinovel filed with the Beijing Arbitration Commission an application under the caption (2011) Jing Zhong An Zi No. 0963, for a counterclaim against the Company for breach of the same contracts under which the Company filed its original arbitration claim. Sinovel claimed, among other things, that the goods supplied by the Company do not conform to the standards specified in the contracts and claimed damages in the amount of approximately RMB 370 million ($58 million). On October 17, 2011, Sinovel filed with the Beijing Arbitration Commission a request for change of counterclaim to increase its damage claim to approximately RMB 1 billion ($157 million). On December 22, 2011, Sinovel filed with the Beijing Arbitration Commission an additional request for change of counterclaim to increase its damages claim to approximately RMB 1.2 billion ($190 million). On February 27, 2012, Sinovel filed with the Beijing Arbitration Commission an application under the caption (2012) Jing Zhong An Zi No. 0157, against the Company for breach of the same contracts under which the Company filed its original arbitration claim. Sinovel claimed, among other things, that the goods supplied by the Company do not conform to the standards specified in the contracts and claimed damages in the amount of approximately RMB 105 million ($17 million). The Company believes that Sinovel’s claims are without merit and it intends to defend these actions vigorously. Since the proceedings in this matter are still in the early technical review phase, the Company cannot reasonably estimate possible losses or range of losses at this time.

[0001564590-15-006142:notes:106]
The Company also submitted a civil action application to the Beijing No. 1 Intermediate People’s Court under the caption (2011) Yi Zhong Min Chu Zi No. 15524, against Sinovel for software copyright infringement on September 13, 2011. The application alleges Sinovel’s unauthorized use of portions of the Company’s wind turbine control software source code developed for Sinovel’s 1.5MW wind turbines and the binary code, or upper layer, of the Company’s software for the PM3000 power converters in 1.5MW wind turbines. In July 2011, a former employee of the Company’s Austrian subsidiary was arrested in Austria on charges of economic espionage and fraudulent manipulation of data. In September 2011, the former employee pled guilty to the charges, and was imprisoned. As a result of the Company’s internal investigation and a criminal investigation conducted by Austrian authorities, the Company believes that this former employee was contracted by Sinovel through an intermediary while employed by the Company and improperly obtained and transferred to Sinovel portions of its wind turbine control software source code developed for Sinovel’s 1.5MW wind turbines. Moreover, the Company believes the former employee illegally used source code to develop for Sinovel a software modification to circumvent the encryption and remove technical protection measures on the Company’s PM3000 power converters in 1.5MW wind turbines in the field. The Company is seeking a cease and desist order with respect to the unauthorized copying, installation and use of its software, monetary damages of approximately RMB 38 million ($6 million) for its economic losses and reimbursement of all costs and reasonable expenses. The Beijing No. 1 Intermediate People’s Court accepted the case, which was necessary in order for the case to proceed. In November 2011, Sinovel filed a motion to remove this case from the Beijing No. 1 Intermediate People’s Court and transfer the matter to the Beijing Arbitration Commission. On February 14, 2012, the court denied Sinovel’s motion to remove the case. On February 21, 2012, Sinovel filed an appeal of the Beijing No. 1 Intermediate People’s Court decision to the Beijing Higher People’s Court. On April 25, 2012, the Beijing Higher People’s Court issued a final Civil Ruling which supports the Beijing No.1 Intermediate People’s Court’s civil ruling and rejected Sinovel’s appeal. Sinovel filed an appeal of the Beijing Higher People’s Court’s decision with China’s Supreme People’s Court. A hearing regarding this appeal was held at the Chinese Supreme People’s Court on October 26, 2012. On November 23, 2012, China’s Supreme People’s Court issued a Civil Ruling, holding that (1) it will conduct a re-trial of Sinovel’s appeal, and (2) the lower court’s decision will be stayed pending the re-trial. China’s Supreme People’s Court conducted a re-trial of Sinovel’s appeal on May 29, 2013.  On January 26, 2014, the Supreme People’s Court ruled to uphold the Beijing Higher People’s Court ruling that the dispute shall be heard by the court.  On September 15, 2014, the Beijing No. 1 Intermediate People’s Court held its first substantive hearing in the Beijing case.  At the hearing, the parties presented evidence, reviewed claims, and answered questions from the court.  On April 24, 2015, the Company received notification from the Beijing No. 1 Intermediate People’s Court that it dismissed the case for what it cited was a lack of evidence.  On May 6, 2015, the Company filed an appeal of the Beijing No. 1 Intermediate People’s Court decision to dismiss the case with the Beijing Higher People’s Court.

[0001564590-15-006142:notes:107]
The Company submitted a civil action application to the Beijing Higher People’s Court against Sinovel and certain of its employees for trade secret infringement on September 13, 2011 under the caption (2011) Gao Min Chu Zi No. 4193. The application alleges the defendants’ unauthorized use of portions of the Company’s wind turbine control software source code developed for Sinovel’s 1.5MW wind turbines as described above with respect to the Copyright Action. The Company is seeking monetary damages of RMB 2.9 billion ($453 million) for the trade secret infringement as well as reimbursement of all costs and reasonable expenses. The Beijing Higher People’s Court accepted the case, which was necessary in order for the case to proceed. On December 22, 2011, the Beijing Higher People’s Court transferred this case to the Beijing No. 1 Intermediate People’s Court under the caption (2011) Gao Min Chu Zi No. 4193. On June 7, 2012, the Company received an Acceptance Notice from the Beijing No.1 Intermediate People’s Court under the caption (2012) Yi Zhong Min Chu Zi No.6833. In August 2012, Sinovel filed a motion to remove this case from the Beijing No. 1 Intermediate People’s Court and transfer the matter to the Beijing Arbitration Commission. On February 24, 2014, the Beijing No. 1 Intermediate People’s Court denied Sinovel’s motion to remove and transfer the case.  On March 13, 2014, Sinovel filed an appeal of the Beijing No. 1 Intermediate People’s Court decision to the Beijing Higher People’s Court.  On August 7, 2014, the Beijing Higher People’s Court upheld the Beijing No.1 Intermediate Court’s decision and rejected Sinovel’s appeal regarding the jurisdiction opposition.  The Beijing No. 1 Intermediate Court held its first substantive hearing on May 11, 2015.  On June 15, 2015, the Company submitted a request for the withdrawal of its complaint to the Beijing No. 1 Intermediate Court.  On June 16, 2015, the Beijing No. 1 Intermediate Court granted its request.  The Company immediately filed a civil action application to the Beijing Intellectual Property Court against the same parties and seeking the same amount of monetary damages for trade secret infringement on June 16, 2015 under the caption (2015) Jin Zhi Min Chu Zi No. 1135.  The Company is currently awaiting notice from the Beijing Intellectual Property Court regarding the first hearing date.

[0001564590-15-006142:notes:108]
On September 16, 2011, the Company filed a civil copyright infringement complaint in the Hainan Province No. 1 Intermediate People’s Court against Dalian Guotong Electric Co. Ltd. (“Guotong”), a supplier of power converter products to Sinovel, and Huaneng Hainan Power, Inc. (“Huaneng”), a wind farm operator that has purchased Sinovel wind turbines containing Guotong power converter products. The case is captioned (2011) Hainan Yi Zhong Min Chu Zi No. 62. The application alleges that the Company’s PM1000 converters in certain Sinovel wind turbines have been replaced by converters produced by Guotong. Because the Guotong converters are being used in wind turbines containing the Company’s wind turbine control software, the Company believes that its copyrighted software is being infringed. The Company is seeking a cease and desist order with respect to the unauthorized use of its software, monetary damages of RMB 1.2 million ($0.2 million) for its economic losses (with respect to Guotong only) and reimbursement of all costs and reasonable expenses. The court has accepted the case, which was necessary in order for the case to proceed. In addition, upon the request of the defendant Huaneng, Sinovel has been added by the court to this case as a defendant and Huaneng has been released from this case. In December 2011, Sinovel filed a jurisdiction opposition motion requesting dismissal by the Hainan Province No. 1 Intermediate People’s Court, saying the case should be governed by the Beijing Arbitration Commission. On February 3, 2012, the Company received the Civil Ruling from the court, which granted Sinovel’s motion, and dismissed the entire case. The Company appealed the court’s ruling to the Hainan Higher Court, which on April 5, 2012 upheld the decision of the Hainan Province No. 1 Intermediate People’s Court. On April 9, 2012, the Company filed an appeal of the Hainan Higher Court’s decision with China’s Supreme People’s Court. China’s Supreme People’s Court accepted the appeal on May 23, 2012. The case is captioned, (2012) Min Shen Zi No. 630. On December 20, 2012, China’s Supreme People’s Court issued a Civil ruling, holding that (1) it will conduct a re-trial of the Company’s appeal and (2) the lower court’s decision will be stayed pending the re-trial. China’s Supreme People’s Court conducted a re-trial of Sinovel’s appeal on May 29, 2013.  On January 26, 2014, the Supreme People’s Court revoked Hainan No. 1 Intermediate People’s Court and Hainan Higher People’s Court rulings and ruled that the case shall be heard by the Hainan No. 1 Intermediate People’s Court.  The Hainan No. 1 Intermediate People’s Court accepted the case under the caption (2014) Hainan Yi Zhong Min San Chu Zi No. 1. On October 21, 2014, the Hainan No. 1 Intermediate People’s Court changed the caption of this case to (2014) Hainan Yi Zhong Zhi Min Chu Zi No. 2.  On November 18, 2014, the Hainan No. 1 Intermediate People’s Court held its first substantive hearing in the Hainan case.    At the hearing, the parties presented evidence, reviewed claims, and answered questions from the court.  On June 3, 2015, the Company received notification from the Hainan No. 1 Intermediate People’s Court that it dismissed the case for what it cited was a lack of evidence.  On June 18, 2015, the Company filed an appeal of the Hainan No. 1 Intermediate People’s Court decision to dismiss the case with the Hainan Higher People’s Court.

[0001564590-15-006142:notes:109]
Other

[0001564590-15-006142:notes:110]
The Company enters into long-term construction contracts with customers that require the Company to obtain performance bonds. The Company is required to deposit an amount equivalent to some or all the face amount of the performance bonds into an escrow account until the termination of the bond. When the performance conditions are met, amounts deposited as collateral for the performance bonds are returned to the Company. In addition, the Company has various contractual arrangements in which minimum quantities of goods or services have been committed to be purchased on an annual basis.

[0001564590-15-006142:notes:111]
As of June 30, 2015 the Company had $3.3 million of restricted cash included in current assets and $0.8 million of restricted cash included in long-term assets. These amounts included in restricted cash primarily represent deposits to secure letters of credit for various supply contracts. These deposits are held in interest bearing accounts.


## us-gaap:EquityMethodInvestmentsDisclosureTextBlock

[0001564590-15-006142:notes:112]
[same as prior period, unchanged from 0001564590-15-000491:notes:140]

[0001564590-15-006142:notes:113]
[same as prior period, unchanged from 0001564590-15-000491:notes:141]

[0001564590-15-006142:notes:114]
The Company made an investment in Tres Amigas, focused on providing the first common interconnection of America’s three power grids to help the country achieve its renewable energy goals and facilitate the smooth, reliable and efficient transfer of green power from region to region.  The Company’s original investment in Tres Amigas was $5.4 million.  As of June 30, 2015, the Company holds a 26% ownership interest in Tres Amigas.

[0001564590-15-006142:notes:115]
The Company has determined that Tres Amigas is a variable interest entity (“VIE”) and that the Company is not the primary beneficiary of the VIE.  Therefore, the Company has not consolidated Tres Amigas as of June 30, 2015.  The investment was carried at acquisition cost, plus the Company’s equity in undistributed earnings or losses.  The Company’s maximum exposure to loss was limited to the Company’s recorded investment in this VIE.  The Company’s investment in Tres Amigas was included in other assets on the consolidated balance sheet and the equity in undistributed losses of Tres Amigas is included in other expense, net, on the unaudited condensed consolidated statements of operations.  During the three months ended June 30, 2015, the Company determined that as a result of delays in Tres Amigas securing financing for the project, as well as the Company’s expectation that its investment would not be recoverable based on recent adverse market indicators for potential sales of the Company’s share of the investment, that its investment in Tres Amigas required further analysis for other-than-temporary impairment.  The Company recorded an impairment charge of $0.7 million to fully impair this investment in the three months ended June 30, 2015.

[0001564590-15-006142:notes:116]
The net investment activity for the nine months ended June 30, 2015 is as follows (in thousands):

[0001564590-15-006142:notes:117]
| Balance at April 1, 2015 | $ | 1,102 |  |
| Minority interest in net losses |  | (356 | ) |
| Impairment |  | (746 | ) |
| Balance at June 30, 2015 | $ | - |  |

[0001564590-15-006142:notes:118]
[same as prior period, unchanged from 0001564590-15-000491:notes:146]

[0001564590-15-006142:notes:119]
The Company has acquired (through its Austrian subsidiary), a minority ownership position in Blade Dynamics, a designer and manufacturer of advanced wind turbine blades based on proprietary materials and structural technologies.  The Company’s original investment was for $8.0 million in cash. As of June 30, 2015, the Company holds a 12% ownership interest in Blade Dynamics.

[0001564590-15-006142:notes:120]
The investment was carried at the acquisition cost, plus the Company’s equity in undistributed earnings or losses, through December 1, 2012, the date which the company no longer reported undistributed earnings or losses. The Company’s investment in Blade Dynamics was included in other assets on the unaudited condensed consolidated balance sheet and the equity in undistributed losses of Blade Dynamics was included in other expense, net, on the unaudited condensed consolidated statements of operations.

[0001564590-15-006142:notes:121]
During the three months ended September 30, 2014, the Company determined that as a result of dilutive financing which resulted in the Company losing certain of its shareholder rights, as well as certain operational issues and adverse changes to the potential sale scenarios previously considered, its investment in Blade Dynamics was no longer recoverable and therefore recorded an impairment charge of $3.5 million to fully impair this asset.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001564590-15-006142:notes:122]
[same as prior period, unchanged from 0001564590-15-000491:notes:152]

[0001564590-15-006142:notes:123]
[same as prior period, unchanged from 0001564590-15-000491:notes:153]

[0001564590-15-006142:notes:124]
Through the Company’s Windtec Solutions, the Wind business segment enables manufacturers to field wind turbines with exceptional power output, reliability and affordability. The Company supplies advanced power electronics and control systems, licenses its highly engineered wind turbine designs, and provides extensive customer support services to wind turbine manufacturers. The Company’s design portfolio includes a broad range of drive trains and power ratings of 2 MWs and higher. The Company provides a broad range of power electronics and software-based control systems that are highly integrated and designed for optimized performance, efficiency, and grid compatibility.

[0001564590-15-006142:notes:125]
Through the Company’s Gridtec Solutions, the Grid business segment enables electric utilities and renewable energy project developers to connect, transmit and distribute power with exceptional efficiency, reliability and affordability. The sales process is enabled by transmission planning services that allow it to identify power grid congestion, poor power quality and other risks, which helps the Company determine how its solutions can improve network performance. These services often lead to sales of grid interconnection solutions for wind farms and solar power plants, power quality systems, and transmission and distribution cable systems.  The Company also sells ship protection products to the U.S. Navy through its Grid business segment.

[0001564590-15-006142:notes:126]
[same as prior period, unchanged from 0001564590-15-000491:notes:156]

[0001564590-15-006142:notes:127]
|  | Three months ended June 30, |  |
|  | 2015 |  |  | 2014 |  |
| Revenues: |  |  |  |  |  |  |  |
| Wind | $ | 18,164 |  |  | $ | 7,650 |  |
| Grid |  | 5,559 |  |  |  | 4,046 |  |
| Total | $ | 23,723 |  |  | $ | 11,696 |  |

[0001564590-15-006142:notes:128]
|  | Three months ended June 30, |  |
|  | 2015 |  |  | 2014 |  |
| Operating income (loss): |  |  |  |  |  |  |  |
| Wind | $ | 127 |  |  | $ | (3,480 | ) |
| Grid |  | (6,508 | ) |  |  | (6,407 | ) |
| Unallocated corporate expenses |  | (1,876 | ) |  |  | (2,780 | ) |
| Total | $ | (8,257 | ) |  | $ | (12,667 | ) |

[0001564590-15-006142:notes:129]
The accounting policies of the business segments are the same as those for the consolidated Company. The Company’s business segments have been determined in accordance with the Company’s internal management structure, which is organized based on operating activities. The Company evaluates performance based upon several factors, of which the primary financial measures are segment revenues and segment operating loss. The disaggregated financial results of the segments reflect allocation of certain functional expense categories consistent with the basis and manner in which Company management internally disaggregates financial information for the purpose of assisting in making internal operating decisions. In addition, certain corporate expenses which the Company does not believe are specifically attributable or allocable to either of the two business segments have been excluded from the segment operating income (loss).

[0001564590-15-006142:notes:130]
Unallocated corporate expenses primarily consist of stock-based compensation expense of $1.1 million and an impairment charge of $0.7 million, for the three months ended June 30, 2015. Unallocated corporate expenses primarily consist of stock-based compensation expense of $1.6 million, as well as restructuring and impairment charges of $1.2 million, for the three months ended June 30, 2014.

[0001564590-15-006142:notes:131]
Total assets for the two business segments as of June 30, 2015 and March 31, 2015 are as follows (in thousands):

[0001564590-15-006142:notes:132]
|  | June 30, |  |  | March 31, |  |
|  | 2015 |  |  | 2015 |  |
| Wind | $ | 35,227 |  |  | $ | 41,947 |  |
| Grid |  | 40,440 |  |  |  | 42,482 |  |
| Corporate assets |  | 67,248 |  |  |  | 49,396 |  |
| Total | $ | 142,915 |  |  | $ | 133,825 |  |

[0001564590-15-006142:notes:133]
The following table sets forth customers who represented 10% or more of the Company’s total revenues for the three months ended June 30, 2015 and 2014:

[0001564590-15-006142:notes:134]
|  | Three months ended June 30, |  |
|  | 2015 |  |  | 2014 |  |
| INOX Wind Limited |  | 47 | % |  |  | 48% |  |
| Beijing JINGCHENG New Energy Co., Ltd |  | 25 | % |  | <10% |  |
| M.A. Mortenson Company |  | 11 | % |  | — % |  |


## us-gaap:NewAccountingPronouncementsAndChangesInAccountingPrinciplesTextBlock

[0001564590-15-006142:notes:135]
16. Recent Accounting Pronouncements

[0001564590-15-006142:notes:136]
In May 2014, the FASB and the International Accounting Standards Board (IASB) issued ASU 2014-09, ASU Revenue from Contracts with Customers (Topic 606), The guidance substantially converges final standards on revenue recognition between the FASB and IASB providing a framework on addressing revenue recognition issues and, upon its effective date, replaces almost all existing revenue recognition guidance, including industry-specific guidance, in current U.S. generally accepted accounting principles.  The ASU is effective for annual reporting periods beginning after December 15, 2017.  The Company is currently evaluating the impact of adopting ASU 2014-09 to determine the impact, if any, it may have on its current practices.

[0001564590-15-006142:notes:137]
In July 2014, the FASB issued ASU 2014-12, Compensation – Stock Compensation (Topic 718): Accounting for Share Based Payments When the Terms of an Award Provide that a Performance Target could be Achieved after the Requisite Service Period.    To account for such awards, a reporting entity should apply existing guidance in FASB Accounting Standards Codification Topic 718, Compensation – Stock Compensation, as it relates to awards with performance conditions that affect vesting.  As such, the performance target should not be reflected in estimating the grant-date fair value of the award. This ASU is effective for annual reporting periods and interim periods, within those annual periods beginning after December 15, 2015.  The Company is currently evaluating the impact of adopting ASU 2014-12 to determine the impact, if any, it may have on its current practices.

[0001564590-15-006142:notes:138]
In August 2014, the FASB issued ASU 2014-15, Presentation of Financial Statements – Going Concern (Subtopic 205-40): Disclosure of Uncertainties About an Entity’s Ability to Continue as a Going Concern.  The new standard explicitly requires the assessment at interim and annual periods, and provides management with its own disclosure guidance.  This ASU is effective for annual reporting periods and interim periods, within those annual periods ending after December 15, 2016.  The Company is currently evaluating the impact of ASU 2014-15, if any, may have on its current practices.

[0001564590-15-006142:notes:139]
In April 2015, the FASB issued ASU 2015-03 Interest—Imputation of Interest (Subtopic 835-30): Simplifying the Presentation of Debt Issuance Costs.  The amendments in ASU 2015-03 require an entity to present debt issuance costs on the balance sheet as a direct deduction from the related debt liability as opposed to an asset. Amortization of the costs will continue to be reported as interest expense. This ASU is effective for annual reporting periods beginning after December 15, 2015, and interim periods within those fiscal years.  The Company is currently evaluating the impact of adopting ASU 2015-03 to determine the impact, but currently does not believe there will be an impact on its consolidated results of operations, financial condition, or cash flow.

[0001564590-15-006142:notes:140]
In June 2015, the FASB issued ASU 2015-10 Technical Corrections and Improvements.  The amendments in ASU 2015-10 will clarify and correct some of the difference that arose between original guidance from FASB, EITF and other sources, and the translation into the new Codification. This ASU is effective for annual reporting periods beginning after December 15, 2015, and interim periods within those fiscal years.  The Company is currently evaluating the impact of adopting ASU 2015-10 to determine the impact, but currently does not believe there will be an impact on its consolidated results of operations, financial condition, or cash flow.


## us-gaap:SubsequentEventsTextBlock

[0001564590-15-006142:notes:141]
17. Subsequent Events

[0001564590-15-006142:notes:142]
The Company has performed an evaluation of subsequent events through the time of filing this Quarterly Report on Form 10-Q with the SEC, and has determined that there are no such events, other than those previously disclosed, that are required to be disclosed.
