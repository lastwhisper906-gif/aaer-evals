# AMSC 8-K — 0001193125-15-277824 filed 2015-08-05

## item codes, every 8-K on or before 2015-08-05

- 2015-08-05 0001193125-15-277824 — 2.02, 9.01
- 2015-07-31 0001193125-15-273009 — 5.07
- 2015-06-26 0001193125-15-237190 — 5.02
- 2015-06-09 0001193125-15-218028 — 8.01
- 2015-05-28 0001193125-15-202933 — 2.02, 9.01
- 2015-04-28 0001193125-15-153319 — 8.01, 9.01
- 2015-04-23 0001193125-15-144123 — 2.02, 8.01, 9.01
- 2015-04-23 0001193125-15-143608 — 8.01
- 2015-04-10 0001193125-15-126160 — 8.01
- 2015-03-24 0001193125-15-103436 — 5.03, 9.01
- 2015-03-18 0001193125-15-097034 — 5.07
- 2015-02-05 0001193125-15-034499 — 2.02, 9.01
- 2015-01-29 0001193125-15-024629 — 2.02, 9.01
- 2015-01-21 0001193125-15-016287 — 3.01, 8.01
- 2015-01-06 0001193125-15-002902 — 5.02
- 2014-12-22 0001193125-14-450591 — 1.01, 2.03, 3.02, 9.01
- 2014-11-13 0001193125-14-410207 — 1.01, 9.01
- 2014-11-07 0001193125-14-402383 — 1.02, 7.01, 9.01
- 2014-11-06 0001193125-14-399779 — 2.02, 9.01
- 2014-10-01 0001193125-14-360072 — 2.02, 8.01, 9.01
- 2014-09-04 0001193125-14-331411 — 8.01
- 2014-08-21 0001193125-14-317133 — 1.01
- 2014-08-06 0001193125-14-298306 — 5.02, 5.07, 9.01
- 2014-08-05 0001193125-14-294647 — 2.02, 9.01
- 2014-07-16 0001193125-14-269902 — 8.01
- 2014-06-23 0001193125-14-244592 — 3.02, 8.01
- 2014-06-05 0001193125-14-226459 — 2.02, 9.01
- 2014-06-05 0001193125-14-226457 — 1.01, 9.01
- 2014-03-19 0001193125-14-106558 — 2.05
- 2014-03-03 0001193125-14-078917 — 1.01, 3.02, 9.01
- 2014-02-28 0001193125-14-077480 — 8.01, 9.01
- 2014-02-06 0001193125-14-037960 — 2.02, 8.01, 9.01
- 2013-11-20 0001193125-13-447829 — 3.02, 8.01
- 2013-11-18 0001193125-13-444697 — 1.01, 2.03, 3.02, 9.01
- 2013-11-07 0001193125-13-431705 — 2.02, 9.01
- 2013-10-09 0001193125-13-395362 — 1.01, 2.03, 3.02, 9.01
- 2013-09-25 0001193125-13-378481 — 5.02, 9.01
- 2013-08-21 0001193125-13-341566 — 4.01, 9.01
- 2013-08-07 0001193125-13-323082 — 2.02, 9.01
- 2013-08-02 0001193125-13-317278 — 5.02, 5.07
- 2013-06-14 0001193125-13-258758 — 2.02, 9.01
- 2013-04-01 0001193125-13-136714 — 2.02, 8.01, 9.01
- 2013-02-20 0001193125-13-067218 — 5.02, 9.01
- 2013-02-14 0001193125-13-060131 — 1.01, 9.01
- 2013-02-11 0001193125-13-048784 — 2.02, 9.01
- 2013-01-08 0001193125-13-006861 — 5.02, 9.01
- 2012-12-21 0001193125-12-511592 — 1.01, 2.03, 3.02, 9.01
- 2012-11-28 0001193125-12-483317 — 2.05, 5.02, 7.01, 9.01
- 2012-11-06 0001193125-12-453359 — 2.02, 9.01
- 2012-08-02 0001193125-12-330534 — 2.02, 9.01
- 2012-07-27 0001193125-12-318790 — 5.02, 5.07, 9.01
- 2012-06-06 0001193125-12-261030 — 1.01, 2.02, 2.03, 3.02, 5.02, 9.01
- 2012-05-09 0001193125-12-222210 — 5.02
- 2012-04-20 0001193125-12-172045 — 8.01
- 2012-04-13 0001193125-12-162694 — 2.02, 8.01, 9.01
- 2012-04-04 0001193125-12-149102 — 1.01, 2.02, 2.03, 3.02, 9.01
- 2012-02-09 0001193125-12-048009 — 2.02, 9.01
- 2012-02-06 0001193125-12-041344 — 5.07 — amendment of 0000950123-11-102495
- 2011-12-08 0000950123-11-102495 — 5.07
- 2011-11-29 0000950123-11-100822 — 2.05
- 2011-11-09 0000950123-11-096775 — 2.02, 9.01
- 2011-10-31 0000950123-11-093390 — 1.02, 9.01
- 2011-10-07 0000950123-11-089221 — 8.01
- 2011-10-03 0000950123-11-088315 — 7.01
- 2011-09-23 0000950123-11-086288 — 2.02, 9.01
- 2011-09-15 0000950123-11-084585 — 7.01
- 2011-09-06 0000950123-11-082736 — 7.01
- 2011-08-18 0000950123-11-078526 — 3.01, 7.01, 9.01
- 2011-08-11 0000950123-11-075905 — 5.02
- 2011-08-11 0000950123-11-075904 — 2.02, 2.05, 9.01
- 2011-07-11 0000950123-11-064934 — 2.02, 4.02, 9.01
- 2011-06-30 0000950123-11-063287 — 1.01, 3.02, 9.01
- 2011-06-21 0000950123-11-060491 — 3.01, 7.01, 9.01
- 2011-06-13 0000950123-11-058656 — 1.01, 9.01
- 2011-05-24 0000950123-11-053517 — 5.02, 9.01
- 2011-04-05 0001299933-11-001020 — 2.02, 9.01
- 2011-03-15 0000950123-11-025580 — 5.02
- 2011-03-14 0000950123-11-025205 — 1.01, 3.02, 9.01
- 2011-02-01 0001299933-11-000333 — 2.02, 9.01
- 2010-11-12 0000950123-10-104604 — 8.01, 9.01
- 2010-11-08 0000950123-10-102424 — 8.01, 9.01
- 2010-11-02 0001299933-10-003878 — 2.02, 9.01
- 2010-09-15 0000950123-10-086373 — 1.01, 9.01 — amendment, the index does not say of what
- 2010-08-06 0000950123-10-074362 — 5.07
- 2010-07-29 0001299933-10-002860 — 2.02, 9.01
- 2010-05-17 0000950123-10-050424 — 1.01, 9.01
- 2010-05-14 0001299933-10-001972 — 5.02
- 2010-05-13 0001299933-10-001943 — 2.02, 9.01
- 2010-02-08 0001299933-10-000506 — 8.01
- 2010-02-02 0001299933-10-000386 — 2.02, 9.01
- 2009-12-15 0001299933-09-004928 — 5.02
- 2009-10-29 0001299933-09-004267 — 2.02, 9.01
- 2009-08-12 0001193125-09-173026 — 5.02, 9.01
- 2009-07-30 0001193125-09-158842 — 1.01, 2.02, 9.01
- 2009-05-15 0001193125-09-113158 — 5.02
- 2009-05-14 0001193125-09-110619 — 2.02, 9.01
- 2009-04-20 0001193125-09-082590 — 5.02
- 2009-02-03 0001193125-09-016992 — 2.02, 9.01
- 2009-01-22 0001193125-09-009777 — 2.02, 9.01
- 2008-11-04 0001193125-08-223730 — 2.02, 9.01
- 2008-08-11 0001193125-08-173616 — 8.01
- 2008-08-07 0001193125-08-170325 — 8.01
- 2008-08-05 0001193125-08-165888 — 2.02, 9.01
- 2008-06-11 0001193125-08-132049 — 1.01, 9.01
- 2008-05-20 0001193125-08-119372 — 5.02, 9.01
- 2008-05-08 0001193125-08-107052 — 2.02, 9.01
- 2008-01-31 0001193125-08-016233 — 2.02, 9.01
- 2008-01-30 0001193125-08-015494 — 5.03, 9.01
- 2007-11-01 0001193125-07-231866 — 2.02, 9.01
- 2007-10-31 0001193125-07-231225 — 2.05
- 2007-10-29 0001193125-07-228284 — 5.03, 9.01
- 2007-09-27 0001193125-07-208950 — 5.02
- 2007-08-09 0001193125-07-176553 — 2.02, 9.01
- 2007-08-07 0001193125-07-173829 — 1.01, 5.02, 9.01
- 2007-07-02 0001193125-07-148303 — 5.02, 9.01
- 2007-06-20 0001193125-07-139068 — 8.01, 9.01
- 2007-06-14 0001193125-07-135550 — 9.01 — amendment of 0001193125-07-005297
- 2007-06-14 0001193125-07-135340 — 5.02
- 2007-05-24 0001193125-07-122148 — 2.02, 9.01
- 2007-03-30 0001193125-07-070154 — 2.05, 9.01
- 2007-03-23 0001193125-07-062978 — 9.01 — amendment of 0001193125-07-005297
- 2007-02-01 0001193125-07-017883 — 2.02, 9.01
- 2007-01-11 0001193125-07-005297 — 2.01, 9.01
- 2006-12-05 0001181431-06-067500 — 5.02
- 2006-11-29 0001193125-06-243360 — 1.01, 3.02, 9.01
- 2006-11-02 0001193125-06-221464 — 2.02, 9.01
- 2006-09-21 0001193125-06-194526 — 5.02
- 2006-08-08 0001193125-06-164819 — 2.02, 9.01
- 2006-08-02 0001193125-06-159113 — 1.01, 9.01
- 2006-07-28 0001193125-06-156172 — 1.01
- 2006-06-26 0001193125-06-135913 — 1.01, 3.03, 9.01
- 2006-05-11 0001193125-06-108489 — 2.02, 9.01
- 2006-05-05 0001193125-06-102270 — 1.01, 9.01
- 2006-05-01 0001193125-06-094941 — 2.02, 2.06, 9.01
- 2006-02-24 0001193125-06-038281 — 5.02, 9.01
- 2006-02-02 0001181431-06-007665 — 2.02, 9.01
- 2005-11-09 0001181431-05-060304 — 2.02, 9.01
- 2005-08-04 0001181431-05-044420 — 2.02, 9.01
- 2005-07-28 0001193125-05-151272 — 5.02, 9.01
- 2005-06-14 0001193125-05-125148 — 5.02, 9.01
- 2005-05-12 0001181431-05-027410 — 2.02, 9.01
- 2005-05-10 0001193125-05-102795 — 1.01
- 2005-04-05 0001181431-05-020680 — 1.01, 2.02, 3.02, 9.01
- 2005-02-03 0001181431-05-006678 — 2.02, 9.01
- 2004-11-09 0001181431-04-051381 — 2.02, 9.01 — amendment, the index does not say of what
- 2004-11-04 0001181431-04-050706 — 2.02, 9.01
- 2004-10-15 0001193125-04-172458 — 1.01, 9.01
- 2004-08-05 0001193125-04-132162 — 12
- 2004-05-13 0001193125-04-086853 — 12
- 2004-02-05 0001193125-04-015060 — 12
- 2003-11-06 0001193125-03-074000 — 12
- 2003-09-26 0001193125-03-054624 — 5
- 2003-08-06 0001193125-03-029666 — 12
- 2003-05-14 0000927016-03-002619 — 9
- 2002-12-31 0000927016-02-006114 — 5
- 2000-01-24 0000927016-00-000150 — 5, 7
- 1998-11-02 0000950135-98-005625 — 5, 7
- 1998-03-24 0000950135-98-001743 — 5, 7
- 1997-09-05 0000950135-97-003729 — 5, 7
- 1997-06-23 0000950135-97-002785 — 1 — amendment of 0000950135-97-001972
- 1997-04-23 0000950135-97-001972 — 2, 7

## late-filing notifications on or before 2015-08-05

- 2011-08-10 0000950123-11-075677 — NT 10-Q, for the period ended 2011-06-30
- 2011-05-31 0000950123-11-055465 — NT 10-K, for the period ended 2011-03-31

## item 2.02 — earnings release, exhibit 99.1

[0001193125-15-277824:8k_2_02:1]
EX-99.1
2
d94380dex991.htm
EX-99.1

[0001193125-15-277824:8k_2_02:2]
EX-99.1

[0001193125-15-277824:8k_2_02:3]
Exhibit 99.1

[0001193125-15-277824:8k_2_02:4]
AMSC Reports First Quarter Fiscal 2015 Financial Results and Provides Business Outlook

[0001193125-15-277824:8k_2_02:5]
Company to host conference call today at 10:00 am ET

[0001193125-15-277824:8k_2_02:6]
Devens, MA – August 5, 2015 – AMSC (NASDAQ: AMSC), a global solutions provider serving wind and power grid industry leaders, today
reported financial results for its first quarter of fiscal 2015 ended June 30, 2015.

[0001193125-15-277824:8k_2_02:7]
Revenues for the first quarter of fiscal 2015 were $23.7
million, compared with $11.7 million for the same period of fiscal 2014. The year over year increase in revenues was due to increases in both the Company’s Wind and Grid segments.

[0001193125-15-277824:8k_2_02:8]
AMSC’s net loss for the first quarter of fiscal 2015 decreased to $9.1 million, or $0.75 per share, from $13.5 million, or $1.74 per share, for the same
period of fiscal 2014.

[0001193125-15-277824:8k_2_02:9]
The Company’s non-GAAP net loss for the first quarter of fiscal 2015 was $8.7 million, or $0.72 per share, compared with a
non-GAAP net loss of $11.9 million, or $1.53 per share, in the same period of fiscal 2014. Please refer to the financial table below for a reconciliation of GAAP to non-GAAP results.

[0001193125-15-277824:8k_2_02:10]
Cash, cash equivalents, and restricted cash at June 30, 2015 totaled $42.6 million, compared with $24.5 million at March 31, 2015. The increase is
due primarily to proceeds received from an equity offering undertaken by the Company during the first fiscal quarter of 2015.

[0001193125-15-277824:8k_2_02:11]
“In the first fiscal
quarter, we demonstrated financial progress, more than doubling revenues year over year and significantly improving gross margins,” said Daniel P. McGahn, President and CEO, AMSC. “We started off the fiscal year by announcing that
Eversource Energy, the electric utility in Boston, MA, is conducting a deployment study of the REG system, $9 million in D-VAR® system orders, and a contract from the U.S. Navy for ship
protection equipment. In the second fiscal quarter, we continued to develop our REG pipeline, as demonstrated by our announcement that Pepco, the electric utility in Washington DC, is undertaking a deployment study of the REG system.”

[0001193125-15-277824:8k_2_02:12]
Business Outlook

[0001193125-15-277824:8k_2_02:13]
For the second quarter ending
September 30, 2015, AMSC expects that its revenues will be in the range of $18 million to $20 million. The Company’s net loss for the second quarter of fiscal 2015 is expected to be less than $8.5 million, or $0.62 per share. AMSC expects
that its non-GAAP net loss (as defined below) for the second quarter of fiscal 2015 will be less than $9.0 million, or $0.65 per share.

[0001193125-15-277824:8k_2_02:14]
| AMSC Reports Q1FY15 Results |  | Page 2 |

[0001193125-15-277824:8k_2_02:15]
Conference Call Reminder

[0001193125-15-277824:8k_2_02:16]
In conjunction with this announcement, AMSC management will participate in a conference call with investors beginning at 10:00 a.m. Eastern Time today to
discuss the Company’s results and its business outlook. Those who wish to listen to the live or archived conference call webcast should visit the “Investors” section of the Company’s website at
http://www.amsc.com/investors. The live call also can be accessed by dialing 785-424-1670 and using conference ID 2698667.

[0001193125-15-277824:8k_2_02:17]
About AMSC
(NASDAQ: AMSC)

[0001193125-15-277824:8k_2_02:18]
AMSC generates the ideas, technologies and solutions that meet the world’s demand for smarter, cleaner … better
energy™. Through its Windtec™ Solutions, AMSC provides wind turbine electronic controls and systems, designs and engineering services that reduce the cost of wind energy. Through its Gridtec™ Solutions, AMSC provides the engineering
planning services and advanced grid systems that optimize network reliability, efficiency and performance. The Company’s solutions are now powering gigawatts of renewable energy globally and are enhancing the performance and reliability of
power networks in more than a dozen countries. Founded in 1987, AMSC is headquartered near Boston, Massachusetts with operations in Asia, Australia, Europe and North America. For more information, please visit www.amsc.com.

[0001193125-15-277824:8k_2_02:19]
AMSC, Windtec, Gridtec, and Smarter, Cleaner … Better Energy are trademarks or registered trademarks of American Superconductor Corporation. All other
brand names, product names, trademarks or service marks belong to their respective holders.

[0001193125-15-277824:8k_2_02:20]
Forward-Looking Statements

[0001193125-15-277824:8k_2_02:21]
| AMSC Reports Q1FY15 Results |  | Page 3 |

[0001193125-15-277824:8k_2_02:22]
additional expenses; Our contracts with the U.S. government are subject to audit, modification or termination by the U.S. government and include certain other provisions in favor of the
government. The continued funding of such contracts remains subject to annual congressional appropriation which, if not approved, could reduce our revenue and lower or eliminate our profit; Many of our customers outside of the United States,
particularly in China, are, either directly or indirectly, related to governmental entities, and we could be adversely affected by violations of the United States Foreign Corrupt Practices Act and similar worldwide anti-bribery laws outside the
United States; We have limited experience in marketing and selling our superconductor products and system-level solutions, and our failure to effectively market and sell our products and solutions could lower our revenue and cash flow; We may
acquire additional complementary businesses or technologies, which may require us to incur substantial costs for which we may never realize the anticipated benefits; Our success depends upon the commercial use of high temperature superconductor
(HTS) products, which is currently limited, and a widespread commercial market for our products may not develop; Growth of the wind energy market depends largely on the availability and size of government subsidies and economic incentives; We have
operations in and depend on sales in emerging markets, including India and China, and global conditions could negatively affect our operating results or limit our ability to expand our operations outside of these countries. Changes in India’s
or China’s political, social, regulatory and economic environment may affect our financial performance; Our products face intense competition, which could limit our ability to acquire or retain customers; Our international operations are
subject to risks that we do not face in the United States, which could have an adverse effect on our operating results; Adverse changes in domestic and global economic conditions could adversely affect our operating results; We may be unable to
adequately prevent disclosure of trade secrets and other proprietary information; Our patents may not provide meaningful protection for our technology, which could result in us losing some or all of our market position; There are a number of
technological challenges that must be successfully addressed before our superconductor products can gain widespread commercial acceptance, and our inability to address such technological challenges could adversely affect our ability to acquire
customers for our products; Third parties have or may acquire patents that cover the materials, processes and technologies we use or may use in the future to manufacture our Amperium products, and our success depends on our ability to license such
patents or other proprietary rights; Our technology and products could infringe intellectual property rights of others, which may require costly litigation and, if we are not successful, could cause us to pay substantial damages and disrupt our
business; We have filed a demand for arbitration and other lawsuits against our former largest customer, Sinovel, regarding amounts we contend are overdue. We cannot be certain as to the outcome of these proceedings; We have been named as a party in
various legal proceedings, and we may be named in additional litigation, all of which will require significant management time and attention, result in significant legal expenses and may result in an unfavorable outcome, which could have a material
adverse effect on our business, operating results and financial condition; and Our common stock has experienced, and may continue to experience, significant market price and volume fluctuations, which may prevent our stockholders from selling our
common stock at a profit and could lead to costly litigation against us that could divert our management’s attention.

[0001193125-15-277824:8k_2_02:23]
These and the important
factors discussed under the caption “Risk Factors” in Part 1. Item 1A of our Form 10-K for the fiscal year ended March 31, 2015, and our other reports filed with the SEC, among others, could cause actual results to differ
materially from those indicated by forward-looking statements made herein and presented elsewhere by management from time to time. Any such forward-looking statements represent management’s estimates as of the date of this press release. While
we may elect to update such forward-looking statements at some point in the future, we disclaim any obligation to do so, even if subsequent events cause our views to change. These forward-looking statements should not be relied upon as representing
our views as of any date subsequent to the date of this press release.

[0001193125-15-277824:8k_2_02:24]
| AMSC Reports Q1FY15 Results |  | Page 4 |

[0001193125-15-277824:8k_2_02:25]
UNAUDITED CONSOLIDATED STATEMENTS OF OPERATIONS

[0001193125-15-277824:8k_2_02:26]
(In thousands, except per share data)

[0001193125-15-277824:8k_2_02:27]
|  |  | Three months ended |  |
|  |  | June 30, |  |
|  |  | 2015 |  |  | 2014 |  |
| Revenues |  |  |  |  |  |  |  |  |
| Wind |  | $ | 18,164 |  |  | $ | 7,650 |  |
| Grid |  |  | 5,559 |  |  |  | 4,046 |  |
| Total Revenues |  |  | 23,723 |  |  |  | 11,696 |  |
| Cost of revenues |  |  | 20,503 |  |  |  | 12,087 |  |
| Gross profit (loss) |  |  | 3,220 |  |  |  | (391 | ) |
| Operating expenses: |  |  |  |  |  |  |  |  |
| Research and development |  |  | 3,162 |  |  |  | 3,120 |  |
| Selling, general and administrative |  |  | 7,535 |  |  |  | 7,938 |  |
| Restructuring and impairments |  |  | 741 |  |  |  | 1,179 |  |
| Amortization of acquisition related intangibles |  |  | 39 |  |  |  | 39 |  |
| Total operating expenses |  |  | 11,477 |  |  |  | 12,276 |  |
| Operating loss |  |  | (8,257 | ) |  |  | (12,667 | ) |
| Change in fair value of derivatives and warrants |  |  | 800 |  |  |  | (35 | ) |
| Interest expense, net |  |  | (318 | ) |  |  | (535 | ) |
| Other expense, net |  |  | (772 | ) |  |  | (152 | ) |
| Loss before income tax expense |  |  | (8,547 | ) |  |  | (13,389 | ) |
| Income tax expense |  |  | 574 |  |  |  | 128 |  |
| Net loss |  | $ | (9,121 | ) |  | $ | (13,517 | ) |
| Net loss per common share |  |  |  |  |  |  |  |  |
| Basic |  | $ | (0.75 | ) |  | $ | (1.74 | ) |
| Diluted |  | $ | (0.75 | ) |  | $ | (1.74 | ) |
| Weighted average number of common shares outstanding |  |  |  |  |  |  |  |  |
| Basic |  |  | 12,111 |  |  |  | 7,769 |  |
| Diluted |  |  | 12,111 |  |  |  | 7,769 |  |

[0001193125-15-277824:8k_2_02:28]
| AMSC Reports Q1FY15 Results |  | Page 5 |

[0001193125-15-277824:8k_2_02:29]
UNAUDITED CONSOLIDATED BALANCE SHEETS

[0001193125-15-277824:8k_2_02:30]
(In thousands)

[0001193125-15-277824:8k_2_02:31]
|  |  | June 30, |  |  | March 31, |  |
|  |  | 2015 |  |  | 2015 |  |
| ASSETS |  |  |  |  |  |  |  |  |
| Current assets: |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 38,561 |  |  | $ | 20,490 |  |
| Accounts receivable, net |  |  | 8,491 |  |  |  | 9,879 |  |
| Inventory |  |  | 17,080 |  |  |  | 20,596 |  |
| Prepaid expenses and other current assets |  |  | 9,726 |  |  |  | 10,764 |  |
| Restricted cash |  |  | 3,269 |  |  |  | 2,822 |  |
| Total current assets |  |  | 77,127 |  |  |  | 64,551 |  |
| Property, plant and equipment, net |  |  | 54,421 |  |  |  | 56,097 |  |
| Intangibles, net |  |  | 1,280 |  |  |  | 1,422 |  |
| Restricted cash |  |  | 795 |  |  |  | 1,236 |  |
| Deferred tax assets |  |  | 7,766 |  |  |  | 7,766 |  |
| Other assets |  |  | 1,526 |  |  |  | 2,753 |  |
| Total assets |  | $ | 142,915 |  |  | $ | 133,825 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |  |  |  |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |  |  |  |
| Accounts payable and accrued expenses |  | $ | 18,645 |  |  | $ | 21,615 |  |
| Note payable, current portion, net of discount of $190 as of June 30, 2015 and $244 as of March 31, 2015 |  |  | 3,810 |  |  |  | 3,756 |  |
| Derivative liabilities |  |  | 2,198 |  |  |  | 2,999 |  |
| Deferred revenue |  |  | 9,388 |  |  |  | 11,019 |  |
| Deferred tax liabilities |  |  | 7,843 |  |  |  | 7,843 |  |
| Total current liabilities |  |  | 41,884 |  |  |  | 47,232 |  |
| Note Payable, net of current portion and discount of $233 as of June 30, 2015 and $290 as of March 31, 2015 |  |  | 2,934 |  |  |  | 3,877 |  |
| Deferred revenue |  |  | 3,387 |  |  |  | 2,756 |  |
| Other liabilities |  |  | 90 |  |  |  | 67 |  |
| Total liabilities |  |  | 48,295 |  |  |  | 53,932 |  |
| Stockholders’ equity: |  |  |  |  |  |  |  |  |
| Common stock |  |  | 140 |  |  |  | 96 |  |
| Additional paid-in capital |  |  | 1,009,393 |  |  |  | 985,921 |  |
| Treasury stock |  |  | (869 | ) |  |  | (771 | ) |
| Accumulated other comprehensive income (loss) |  |  | (122 | ) |  |  | (308 | ) |
| Accumulated deficit |  |  | (914,166 | ) |  |  | (905,045 | ) |
| Total stockholders’ equity |  |  | 94,620 |  |  |  | 79,893 |  |
| Total liabilities and stockholders’ equity |  | $ | 142,915 |  |  | $ | 133,825 |  |

[0001193125-15-277824:8k_2_02:32]
| AMSC Reports Q1FY15 Results |  | Page 6 |

[0001193125-15-277824:8k_2_02:33]
UNAUDITED CONSOLIDATED STATEMENTS OF CASH FLOWS

[0001193125-15-277824:8k_2_02:34]
(In thousands)

[0001193125-15-277824:8k_2_02:35]
|  |  | Three months ended June 30, |  |
|  |  | 2015 |  |  | 2014 |  |
| Cash flows from operating activities: |  |  |  |  |  |  |  |  |
| Net loss |  | $ | (9,121 | ) |  | $ | (13,517 | ) |
| Adjustments to reconcile net loss to net cash used in operations: |  |  |  |  |  |  |  |  |
| Depreciation and amortization |  |  | 2,028 |  |  |  | 2,475 |  |
| Stock-based compensation expense |  |  | 1,128 |  |  |  | 1,581 |  |
| Impairment of long lived assets |  |  | 746 |  |  |  | — |  |
| Provision for excess and obsolete inventory |  |  | 602 |  |  |  | 649 |  |
| Write-off prepaid taxes |  |  | 820 |  |  |  | — |  |
| Loss on minority interest investments |  |  | 356 |  |  |  | 202 |  |
| Change in fair value of derivatives and warrants |  |  | (800 | ) |  |  | 35 |  |
| Non-cash interest expense |  |  | 111 |  |  |  | 190 |  |
| Other non-cash items |  |  | 553 |  |  |  | 49 |  |
| Changes in operating asset and liability accounts: |  |  |  |  |  |  |  |  |
| Accounts receivable |  |  | 1,414 |  |  |  | (2,741 | ) |
| Inventory |  |  | 2,968 |  |  |  | 623 |  |
| Prepaid expenses and other current assets |  |  | 271 |  |  |  | 441 |  |
| Accounts payable and accrued expenses |  |  | (3,024 | ) |  |  | (1,344 | ) |
| Deferred revenue |  |  | (1,087 | ) |  |  | 5,851 |  |
| Net cash used in operating activities |  |  | (3,035 | ) |  |  | (5,506 | ) |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |
| Net cash used in investing activities |  |  | (64 | ) |  |  | (267 | ) |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |
| Net cash provided by (used in) financing activities |  |  | 21,183 |  |  |  | (633 | ) |
| Effect of exchange rate changes on cash and cash equivalents |  |  | (13 | ) |  |  | (84 | ) |
| Net increase/(decrease) in cash and cash equivalents |  |  | 18,071 |  |  |  | (6,490 | ) |
| Cash and cash equivalents at beginning of year |  |  | 20,490 |  |  |  | 43,114 |  |
| Cash and cash equivalents at end of period |  | $ | 38,561 |  |  | $ | 36,624 |  |

[0001193125-15-277824:8k_2_02:36]
| AMSC Reports Q1FY15 Results |  | Page 7 |

[0001193125-15-277824:8k_2_02:37]
RECONCILIATION OF GAAP NET INCOME (LOSS) TO NON-GAAP NET INCOME (LOSS)

[0001193125-15-277824:8k_2_02:38]
(In thousands, except per share data)

[0001193125-15-277824:8k_2_02:39]
|  |  | Three months endedJune 30, |  |
|  |  | 2015 |  |  | 2014 |  |
| Net loss |  | $ | (9,121 | ) |  | $ | (13,517 | ) |
| Stock-based compensation |  |  | 1,128 |  |  |  | 1,581 |  |
| Amortization of acquisition-related intangibles |  |  | 39 |  |  |  | 39 |  |
| Restructuring and impairment charges |  |  | 741 |  |  |  | 1,179 |  |
| Consumption of zero cost-basis inventory |  |  | (846 | ) |  |  | (1,372 | ) |
| Change of fair value of derivatives and warrants |  |  | (800 | ) |  |  | 35 |  |
| Non-cash interest expense |  |  | 111 |  |  |  | 190 |  |
| Non-GAAP net loss |  | $ | (8,748 | ) |  | $ | (11,865 | ) |
| Non-GAAP loss per share |  | $ | (0.72 | ) |  | $ | (1.53 | ) |
| Weighted average shares outstanding |  |  | 12,111 |  |  |  | 7,769 |  |

[0001193125-15-277824:8k_2_02:40]
RECONCILIATION OF FORECAST GAAP NET LOSS TO NON-GAAP NET LOSS

[0001193125-15-277824:8k_2_02:41]
(In millions, except per share data)

[0001193125-15-277824:8k_2_02:42]
|  |  | Three months endingSept. 30, 2015 |  |
| Net loss |  | $ | (8.5 | ) |
| Stock-based compensation |  |  | 0.7 |  |
| Non-cash interest expense |  |  | 0.1 |  |
| Consumption of zero-cost inventory |  |  | (1.3 | ) |
| Non-GAAP net loss |  | $ | (9.0 | ) |
| Non-GAAP net loss per share |  | $ | (0.65 | ) |
| Shares outstanding |  |  | 13.8 |  |

[0001193125-15-277824:8k_2_02:43]
Note: Non-GAAP net loss is defined by the Company as net loss before stock-based compensation; amortization of
acquisition-related intangibles; restructuring and impairment charges; consumption of zero cost-basis inventory; non-cash interest expense; change in fair value of derivatives and warrants; and other unusual charges, net of any tax effects related
to these items. The Company believes non-GAAP net loss assists management and investors in comparing the Company’s performance across reporting periods on a consistent basis by excluding these non-cash, non-recurring or other charges that it
does not believe are indicative of its core operating performance. The Company also regards non-GAAP net loss as a useful measure of operating performance to complement operating loss, net loss and other GAAP financial performance measures. In
addition, the Company uses non-GAAP net loss as a factor in evaluating management’s performance when determining incentive compensation and to evaluate the effectiveness of its business strategies.

[0001193125-15-277824:8k_2_02:44]
| AMSC Reports Q1FY15 Results |  | Page 8 |

[0001193125-15-277824:8k_2_02:45]
Generally, a non-GAAP financial measure is a numerical measure of a company’s performance, financial
position or cash flow that either excludes or includes amounts that are not normally excluded or included in the most directly comparable measure calculated and presented in accordance with GAAP. The non-GAAP measures included in this release,
however, should be considered in addition to, and not as a substitute for or superior to, operating income, cash flows, or other measures of financial performance prepared in accordance with GAAP. A reconciliation of non-GAAP to GAAP net loss is set
forth in the table above.

[0001193125-15-277824:8k_2_02:46]
AMSC Contact:

[0001193125-15-277824:8k_2_02:47]
Kerry
Farrell

[0001193125-15-277824:8k_2_02:48]
Phone: 978-842-3247

[0001193125-15-277824:8k_2_02:49]
Email: kerry.farrell @ amsc.com
