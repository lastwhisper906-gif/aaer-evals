# AMSC MD&A — 0001193125-13-048834


## mdna

[0001193125-13-048834:mdna:1]
[same as prior period, unchanged from 0001193125-12-454266:mdna:1]

[0001193125-13-048834:mdna:2]
cannot be certain as to the outcome of these proceedings; we have been named as a party to purported stockholder class actions and stockholder derivative complaints, and we may be named in
additional litigation, all of which will require significant management time and attention, result in significant legal expenses and may result in an unfavorable outcome, which could have a material adverse effect on our business, operating results
and financial condition; our 7% convertible note contains warrants and provisions that could limit our ability to repay the note in shares of common stock and should the note be repaid in stock, shareholders could experience significant dilution;
our common stock has experienced, and may continue to experience, significant market price and volume fluctuations, which may prevent our stockholders from selling our common stock at a profit and could lead to costly litigation against us that
could divert our management’s attention; and new regulations related to conflict-free minerals may force us to incur significant additional expenses. These and the important factors discussed under the caption “Risk Factors” in
Part II. Item 1A and Part 1. Item 1A of our Form 10-K/A for the fiscal year ended March 31, 2012, among others, could cause actual results to differ materially from those indicated by forward-looking statements made herein
and presented elsewhere by management from time to time. Any such forward-looking statements represent management’s estimates as of the date of this Quarterly Report on Form 10-Q. While we may elect to update such forward-looking statements at
some point in the future, we disclaim any obligation to do so, even if subsequent events cause our views to change. These forward-looking statements should not be relied upon as representing our views as of any date subsequent to the date of this
Quarterly Report on Form 10-Q.

[0001193125-13-048834:mdna:3]
American Superconductor®, Amperium®, AMSC®, D-VAR®, PowerModuleTM, PQ-IVR®, SeaTitanTM, Gridtec SolutionsTM, Windtec SolutionsTM and Smarter, Cleaner… Better EnergyTM are trademarks or registered trademarks of American Superconductor Corporation or its subsidiaries. We reserve all of our rights with respect to our trademarks or registered trademarks regardless of
whether they are so designated in this Quarterly Report on Form 10-Q by an ® or TM symbol. All other brand names, product names, trademarks or
service marks appearing in this Quarterly Report on Form 10-Q are the property of their respective holders.

[0001193125-13-048834:mdna:4]
Overview

[0001193125-13-048834:mdna:5]
[same as prior period, unchanged from 0001193125-12-454266:mdna:6]

[0001193125-13-048834:mdna:6]
[same as prior period, unchanged from 0001193125-12-454266:mdna:7]

[0001193125-13-048834:mdna:7]
We manufacture products using two proprietary core technologies: PowerModule™ programmable power electronic
converters and our Amperium® HTS (High Temperature Superconductor) wires. These technologies and our
system-level solutions are protected by a broad and deep intellectual property portfolio consisting of hundreds of patents and licenses worldwide.

[0001193125-13-048834:mdna:8]
We operate our business under two market-facing business units: Wind and Grid. We believe this market-centric structure enables us to more effectively anticipate and meet the needs of wind turbine
manufacturers, power generation project developers and electric utilities.

[0001193125-13-048834:mdna:9]
|  | • |  | Wind. Through our Windtec Solutions, our Wind business segment enables manufacturers to field wind turbines with exceptional power output, reliability and affordability. We supply advanced power electronics and control systems, license our highly engineered wind turbine designs, and provide extensive customer support services to wind turbine manufacturers. Our design portfolio includes a broad range of drive trains and power ratings up to 10 megawatts. We provide a broad range of power electronics and software based control systems that are highly integrated and redesigned for optimized performance, efficiency, and grid compatibility. |

[0001193125-13-048834:mdna:10]
[same as prior period, unchanged from 0001193125-12-454266:mdna:11]

[0001193125-13-048834:mdna:11]
Our fiscal year begins on April 1 and ends on March 31. This document refers to
fiscal 2012, which is defined as the period beginning on April 1, 2012 and concluding on March 31, 2013. The third quarter of fiscal 2012 began on October 1, 2012 and concluded on December 31, 2012.

[0001193125-13-048834:mdna:12]
On April 4, 2012 we completed a private placement of a $25.0 million of senior convertible note (the “Initial Note”) with
Capital Ventures International (“CVI”), an affiliate of Heights Capital Management. On June 5, 2012, we entered into a $10.0 million Loan and Security Agreement (“Term Loan”) with Hercules Technology Growth Capital, Inc. On
December 20, 2012, we entered into an Amendment and Exchange Agreement, (the “Amendment”), with CVI , pursuant to which we exchanged the Initial Note for a new unsecured, senior convertible note (the “Exchanged Note”), which
had the same principal amount and accrued interest as the Initial Note at the time of the exchange. See Liquidity and Capital Resources below for further discussion of these debt arrangements.

[0001193125-13-048834:mdna:13]
In response to challenging conditions in the wind power market, on November 28, 2012 we reduced our global workforce by
approximately 25%. In addition, we plan to consolidate certain of our office locations. These workforce reductions and planned office consolidations are expected to lower operating costs and enhance liquidity. We expect these reductions to result in
a reduction of our annualized expenses of approximately $10 million.

[0001193125-13-048834:mdna:14]
Our cash requirements depend on numerous factors,
including our ability to profitably grow revenues, fund and maintain compliance with the covenants and restrictions on our debt obligations, successful completion of our product development activities, ability to commercialize our product
prototypes, rate of customer and market adoption of our products, and collecting receivables according to established terms. Significant deviations to our business plan with regard to these factors, which are important drivers to our business, could
have a material adverse effect on our operating performance, financial condition, and future business prospects. We expect to pursue the expansion of our operations through internal growth, diversification of our customer base, and potential
strategic alliances. Potential sources of additional capital include the sale of assets, or obtaining additional financing. With respect to additional financing, there can be no assurance that we will be able to sell assets, or that a financing will
be available, with commercially acceptable terms or at all. See below for a discussion of liquidity and capital resources.

[0001193125-13-048834:mdna:15]
During March 2011, we engaged in discussions with Sinovel, formerly our largest customer, regarding the acceptance of its scheduled
shipments, outstanding receivables, and the delivery of a custom solution desired by Sinovel for low voltage ride through (“LVRT”) that required a modification to our existing LVRT design. The custom design required modified software and
additional hardware. Toward the end of March, Sinovel requested that we provide them with the additional hardware without additional cost. On March 31, 2011, we proposed to Sinovel that we would provide the additional hardware without
additional cost if Sinovel would accept the scheduled shipments. Sinovel rejected this proposal due to what we were told was excess inventory of our components. Since Sinovel did not give us the requisite notice under our contracts that they
intended to delay deliveries, we believe that these actions constitute material breaches of our contracts.

[0001193125-13-048834:mdna:16]
As of the date of
this filing, we have not received payment from Sinovel for any outstanding receivables nor have we been notified as to when, if ever, Sinovel will accept contracted shipments that were scheduled for delivery after March 31,
2011. Additionally, based in part upon evidence obtained through an internal investigation and a criminal investigation conducted by Austrian authorities regarding the actions of a former employee of our Austrian subsidiary, we believe that
Sinovel illegally obtained and used our intellectual property in violation of civil and criminal intellectual property laws. In July 2011, a former employee of our Austrian subsidiary was arrested in Austria on charges of economic espionage and
fraudulent manipulation of data. In September 2011, the former employee pled guilty to the charges, and was imprisoned. The evidence presented during the court hearing showed that this former employee was contracted by Sinovel through an
intermediary, while employed by us, and improperly obtained and transferred to Sinovel portions of our wind turbine control software source code developed for Sinovel’s 1.5MW wind turbines. Except for portions of this 1.5MW wind turbine
software, we do not believe that the source code for any other turbines, such as the 3MW, 5MW and 6MW wind turbines, that were designed by and co-developed with us, have been transferred to Sinovel. Moreover, we believe the evidence shows this
former employee illegally used source code to develop, for Sinovel, a software modification to circumvent the encryption and remove technical protection measures on the PM3000 power converters in 1.5MW wind turbines in the field. We believe that
only the binary code, or upper layer, of the PM3000 software developed to circumvent the encryption and remove technical protection measures was transferred to Sinovel. We do not believe that any PM3000 source code was transferred to Sinovel. These
actions potentially enable Sinovel to deploy, independent of us, wind turbine control software, including a low voltage ride through solution, on all of its 1.5MW wind turbines in the field. In addition, by having the wind turbine control source
code, Sinovel could potentially modify the source code to allow the use of core electrical components, including power converters, from other manufacturers.

[0001193125-13-048834:mdna:17]
On September 13, 2011, we commenced a series of legal actions in China against Sinovel.
We filed a claim for arbitration in Beijing, China to compel Sinovel to pay us for past product shipments and to accept all contracted but not yet delivered core electrical components and spare parts under all existing contracts with us. The
arbitration claim was filed with the Beijing Arbitration Commission in accordance with the terms of our supply contracts with Sinovel. We also filed civil and criminal complaints against Sinovel.

[0001193125-13-048834:mdna:18]
We cannot provide any assurance as to the outcome of these legal actions. See Part II, Item 1, Legal Proceedings below for
additional information regarding these legal proceedings.

[0001193125-13-048834:mdna:19]
Critical Accounting Policies and Estimates

[0001193125-13-048834:mdna:20]
The preparation of the unaudited condensed consolidated financial statements requires that we make estimates and judgments that affect the
reported amounts of assets, liabilities, revenues and expenses, and related disclosure of contingent assets and liabilities. We base our estimates on historical experience and various other assumptions that are believed to be reasonable under the
circumstances, the results of which form the basis for making judgments about the carrying values of assets and liabilities that are not readily apparent from other sources. Actual results may differ under different assumptions or conditions. Except
as stated below, there were no significant changes in the critical accounting policies during the nine months ended December 31, 2012 that were disclosed in our Form 10-K/A for fiscal 2011, which ended on March 31, 2012.

[0001193125-13-048834:mdna:21]
[same as prior period, unchanged from 0001193125-12-454266:mdna:22]

[0001193125-13-048834:mdna:22]
Our financial instruments consist principally of cash and cash equivalents, accounts receivable, accounts payable, accrued expenses, derivatives, warrants, convertible notes and a term loan. The estimated
fair values have been determined through information obtained from market sources and management estimates. The carrying amounts of these instruments approximate fair value. We have identified all of the derivatives associated with the Exchanged
Note which include holder change of control redemption rights, issuer optional redemption rights, sale redemption rights and a feature to covert the Convertible Note into equity at the holder’s option. The derivative liability is subject to
revaluation at each balance sheet date, and any change in fair value will be recorded as a change in fair value in other income (expense) until the earlier of their exercise or expiration of the derivatives associated with the Exchanged Note. We
rely on assumptions in a lattice model to determine the fair value of the derivative liability. We have appropriately valued the derivative liability within Level 3 of the valuation hierarchy. Warrants were issued in conjunction with the Exchanged
Note and Term Loan. These warrants are subject to revaluation at each balance sheet date, and any change in fair value will be recorded as a change in fair value in other income (expense) until the earlier of the warrants’ exercise or
expiration. We rely on assumptions used in a Black-Scholes model to determine the fair value of the warrants. We have appropriately valued the warrants within Level 3 of the valuation hierarchy.

[0001193125-13-048834:mdna:23]
[same as prior period, unchanged from 0001193125-12-454266:mdna:24]

[0001193125-13-048834:mdna:24]
Three and nine months ended December 31, 2012 compared to the three and nine months ended December 31, 2011

[0001193125-13-048834:mdna:25]
[same as prior period, unchanged from 0001193125-12-454266:mdna:26]

[0001193125-13-048834:mdna:26]
Total
revenues decreased by 4% to $17.4 million for the three months ended December 31, 2012, compared to $18.1 million for the three months ended December 31, 2011. Total revenues increased by 40% to $67.0 million for the nine months ended
December 31, 2012, compared to $47.9 million for the nine months ended December 31, 2011. Our revenues are summarized as follows (in thousands):

[0001193125-13-048834:mdna:27]
|  |  | Three months ended |  |  | Nine months ended |  |
|  |  | December 31, |  |  | December 31, |  |
|  |  | 2012 |  |  | 2011 |  |  | 2012 |  |  | 2011 |  |
| Revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Wind |  | $ | 6,808 |  |  | $ | 10,125 |  |  | $ | 35,321 |  |  | $ | 27,836 |  |
| Grid |  |  | 10,609 |  |  |  | 7,933 |  |  |  | 31,679 |  |  |  | 20,080 |  |
| Total |  | $ | 17,417 |  |  | $ | 18,058 |  |  | $ | 67,000 |  |  | $ | 47,916 |  |

[0001193125-13-048834:mdna:28]
Our Wind business unit accounted for 39% and 53% of total revenues for the three and nine
months ended December 31, 2012, respectively, compared to 56% and 58% for the three and nine months ended December 31, 2011, respectively. Revenues in the Wind business unit decreased 33% and increased 27% to $6.8 million and $35.3 million
in the three and nine months ended December 31, 2012, respectively, from $10.1 million and $27.8 million in the three and nine months ended December 31, 2011, respectively. The decrease in the Wind business unit revenues in the
three months ended December 31, 2012, compared to the same prior year period was primarily due to decreased shipments of electrical control systems to customers in India and Korea amid a challenging global market environment in the wind
industry. Wind business unit revenues increased in the nine months ended December 31, 2012, as compared to the prior year period primarily due to increased shipments of electrical control systems to customers in China and India.

[0001193125-13-048834:mdna:29]
Our Grid business unit accounted for 61% and 47% of total revenues for the three and nine months ended December 31, 2012,
respectively, compared to 44% and 42% for the three and nine months ended December 31, 2011, respectively. Our Grid business unit revenues increased 34% and 58% to $10.6 million and $31.7 million in the three and nine months ended
December 31, 2012, respectively, from $7.9 million and $20.1 million for the three and nine months ended December 31, 2011, respectively. For the three months ended December 31, 2012, Grid business unit revenues increased
primarily due to increased D-VAR shipments to customers in the United Kingdom. For the nine months ended December 31, 2012, Grid business unit revenues increased primarily due to increased D-VAR revenues to customers in Australia and the United
Kingdom.

[0001193125-13-048834:mdna:30]
Revenues from significant government-funded contracts are summarized as follows (in thousands):

[0001193125-13-048834:mdna:31]
|  |  | Expected totalcontract value |  |  | Revenue earnedthroughDecember 31,2012 |  |  | Three months endedDecember 31, |  |  | Nine months endedDecember 31, |  |
| Project name |  |  |  | 2012 |  |  | 2011 |  |  | 2012 |  |  | 2011 |  |
| HYDRA |  | $ | 29,043 |  |  | $ | 13,815 |  |  | $ | 549 |  |  | $ | 511 |  |  | $ | 1,658 |  |  | $ | 1,208 |  |
| LIPA I and II |  |  | 40,141 |  |  |  | 40,141 |  |  |  | — |  |  |  | 116 |  |  |  | 163 |  |  |  | 1,500 |  |
| DOE-FCL |  |  | 7,898 |  |  |  | 7,536 |  |  |  | 25 |  |  |  | 95 |  |  |  | 286 |  |  |  | 409 |  |
| Total |  | $ | 77,082 |  |  | $ | 61,492 |  |  | $ | 574 |  |  | $ | 722 |  |  | $ | 2,107 |  |  | $ | 3,117 |  |

[0001193125-13-048834:mdna:32]
These significant projects represented 5% and 7% of the Grid business unit revenues for the three and
nine months ended December 31, 2012, respectively, compared to 9% and 16% of the Grid business unit revenues for the three and nine months ended December 31, 2011, respectively.

[0001193125-13-048834:mdna:33]
Project HYDRA is a project with Consolidated Edison, Inc. that is being partially funded by the Department of
Homeland Security (“DHS”). DHS is expected to invest up to a total of $29.0 million in the development of a new HTS power grid technology called FaultBlocker cable systems. FaultBlocker cable systems are designed to utilize customized
Amperium® HTS wires, and ancillary controls to deliver more power through the grid while also being able to
suppress power surges that can disrupt service. Of the total $29.0 million in funding expected from DHS, it has committed funding of $18.9 million to us as of December 31, 2012. On January 7, 2013, DHS committed an additional
$1.6 million in funding to us for Project HYDRA. Consolidated Edison and Southwire Company are our subcontractors on this project.

[0001193125-13-048834:mdna:34]
LIPA II is a project to install an HTS power cable using our
Amperium® wire for the Long Island Power Authority. DOE-FCL is a project to develop and demonstrate a
transmission voltage SuperLimiter fault current limiter (“FCL”).

[0001193125-13-048834:mdna:35]
The following table sets forth customers
who represented 10% or more of our total revenues for the three and nine months ended December 31, 2012 and 2011:

[0001193125-13-048834:mdna:36]
|  |  | Three months ended |  |  | Nine months ended |  |
|  |  | December 31, |  |  | December 31, |  |
|  |  | 2012 |  |  | 2011 |  |  | 2012 |  |  | 2011 |  |
| CG Power Solutions UK Ltd. |  |  | 20.8 | % |  |  | – | % |  |  | <10 | % |  |  | – | % |
| E.ON Climate & Renewables |  |  | 19.4 | % |  |  | – | % |  |  | <10 | % |  |  | – | % |
| INOX Wind Limited |  |  | 18.9 | % |  |  | 26.5 | % |  |  | 17.3 | % |  |  | 20.5 | % |
| Beijing JINGCHENG New Energy Co., Ltd. |  |  | <10 | % |  |  | <10 | % |  |  | 16.7 | % |  |  | <10 | % |
| Doosan Heavy Industries & Construction Co Ltd. |  |  | <10 | % |  |  | 12.1 | % |  |  | <10 | % |  |  | 14.8 | % |
| Ergon Energy Corporation Limited |  |  | – | % |  |  | 10.6 | % |  |  | – | % |  |  | <10 | % |

[0001193125-13-048834:mdna:37]
[same as prior period, unchanged from 0001193125-12-454266:mdna:38]

[0001193125-13-048834:mdna:38]
Cost of revenues was $16.5 million and $53.8 million for the three and nine months ended December 31, 2012, respectively, compared to
$18.9 million and $57.8 million for the three and nine months ended December 31, 2011, respectively. Gross margin was 5% and 20% for the three and nine months ended December 31, 2012, respectively, compared to (5%) and
(21%) for the three and nine months ended December 31, 2011, respectively. The increases in gross margin for both the three and nine months ended December 31, 2012 as compared to the same periods in fiscal 2011, were primarily due to
settlements of certain adverse purchase order liabilities resulting in a benefit to cost of revenues of $0.1 million and $8.4 million in the three and nine months ended December 31, 2012, respectively, and $0.8 million due to the expiration of
warranty liabilities, primarily with customers in China, as well as higher revenues, primarily in the nine months ended December 31, 2012, which included approximately $3.3 million of revenue from Chinese customers representing payment for past
shipments for which revenue was recognized upon cash collection. Costs associated with this revenue were recorded in prior periods.

[0001193125-13-048834:mdna:39]
[same as prior period, unchanged from 0001193125-12-454266:mdna:41]

[0001193125-13-048834:mdna:40]
[same as prior period, unchanged from 0001193125-12-454266:mdna:42]

[0001193125-13-048834:mdna:41]
[same as prior period, unchanged from 0001193125-12-454266:mdna:43]

[0001193125-13-048834:mdna:42]
|  |  | Three months ended |  |  | Nine months ended |  |
|  |  | December 31, |  |  | December 31, |  |
|  |  | 2012 |  |  | 2011 |  |  | 2012 |  |  | 2011 |  |
| R&D expenses per condensed consolidated statements of operations |  | $ | 3,948 |  |  | $ | 5,928 |  |  | $ | 11,480 |  |  | $ | 21,339 |  |
| R&D expenditures reclassified as cost of revenues |  |  | 3,044 |  |  |  | 2,480 |  |  |  | 10,184 |  |  |  | 9,782 |  |
| R&D expenditures offset by cost-sharing funding |  |  | 40 |  |  |  | 42 |  |  |  | 144 |  |  |  | 123 |  |
| Aggregated R&D expenses |  | $ | 7,033 |  |  | $ | 8,450 |  |  | $ | 21,807 |  |  | $ | 31,244 |  |

[0001193125-13-048834:mdna:43]
R&D expenses (exclusive of amounts classified as cost of revenues and amounts offset by cost-sharing
funding) decreased by 33% and 46% to $3.9 million and $11.5 million for the three and nine months ended December 31, 2012, respectively, compared to $5.9 million and $21.3 million for the three and nine months ended December 31, 2011,
respectively. The decreases in R&D expenses were driven primarily by the realization of savings from actions to reduce personnel and other costs that were implemented in fiscal 2011 as well as partial savings from the action to reduce personnel
and other costs undertaken in the third quarter of fiscal 2012. The increases in R&D expenditures reclassified to costs of revenue during the three and nine months ended December 31, 2012 were a result of increased license and development
revenue in our Wind segment partially offset by a decrease in activity in our government funded contracts in our Grid business unit compared to the prior year period. Aggregated R&D expenses, which include amounts classified as cost of revenues
and amounts offset by cost-sharing funding, decreased 17% and 30% to $7.0 million and $21.8 million for the three and nine months ended December 31, 2012, respectively, compared to $8.5 million and $31.2 million for the three and
nine months ended December 31, 2011, respectively.

[0001193125-13-048834:mdna:44]
We present aggregated R&D, which is a non-GAAP measure, because
we believe this presentation provides useful information on our aggregate R&D spending and because R&D expenses as reported on the unaudited condensed consolidated statements of income have been, and may in the future be, subject to
significant fluctuations solely as a result of changes in the level of externally funded contract development work, resulting in significant changes in the amount of the costs recorded as costs of revenues rather than as R&D expenses, as
discussed above.

[0001193125-13-048834:mdna:45]
Selling, general, and administrative

[0001193125-13-048834:mdna:46]
SG&A expenses decreased by 30% and 34% to $10.8 million and $36.3 million in the three and nine months ended December 31, 2012, respectively, compared to $15.4 million and $55.0 million
in the three and nine months ended December 31, 2011, respectively. The decreases in SG&A expenses during the three and nine month periods ended December 31, 2012, as compared to the prior year periods, were due primarily to the
realization of savings from our actions to reduce personnel and other costs during fiscal 2011 and partial realization of savings from the action to reduce personnel and other costs undertaken in the three months ended December 31, 2012, and
with respect to the nine months ended December 31, 2012, costs associated with the severance of our former chief executive officer that were incurred during the comparable period of the prior year.

[0001193125-13-048834:mdna:47]
Amortization of acquisition related intangibles

[0001193125-13-048834:mdna:48]
We recorded amortization expense related to our core technology and know-how, trade names and trademark intangible assets of $0.1 million
and $0.2 million in the three and nine months ended December 31, 2012, respectively, compared to $0.3 million and $0.9 million in the three and nine months ended December 31, 2011, respectively. These intangible assets are
primarily as a result of our Windtec acquisition in 2007.

[0001193125-13-048834:mdna:49]
Restructuring and Impairments

[0001193125-13-048834:mdna:50]
We recorded restructuring and impairment charges $6.7 million and $6.8 million in the three and nine months ended December 31, 2012,
respectively, compared to $4.1 million and $8.4 million in the three and nine months ended December 31, 2011. These amounts consist primarily of a long-lived asset impairment charge of $4.5 million recorded in the three months ended
December 31, 2012, as well as employee severance and benefit costs related to the restructuring plan of $2.2 million and $2.3 million in the three and nine months ended December 31, 2012, respectively. For the three and nine months ended
December 31, 2011, these amounts include employee severance and benefit costs related to the restructuring plan of $2.2 million and $5.4 million, respectively, and impairment charges on long-lived assets for which there is no remaining future
economic benefit as of December 31, 2011 of $0.1 million and $1.1 million, respectively. Finally, for the nine months ended December 31, 2011, the Company recorded facility exit costs of $0.1 million associated with portions of the leased
space in Klagenfurt, Austria.

[0001193125-13-048834:mdna:51]
[same as prior period, unchanged from 0001193125-12-454266:mdna:53]

[0001193125-13-048834:mdna:52]
[same as prior period, unchanged from 0001193125-12-454266:mdna:54]

[0001193125-13-048834:mdna:53]
|  |  | Three months ended |  |  | Nine months ended |  |
|  |  | December 31, |  |  | December 31, |  |
|  |  | 2012 |  |  | 2011 |  |  | 2012 |  |  | 2011 |  |
| Operating (loss) income: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Wind |  | $ | (5,365 | ) |  | $ | (14,014 | ) |  | $ | (10,514 | ) |  | $ | (54,719 | ) |
| Grid |  |  | (6,705 | ) |  |  | (6,313 | ) |  |  | (18,620 | ) |  |  | (24,511 | ) |
| Unallocated corporate expenses |  |  | (8,546 | ) |  |  | (6,242 | ) |  |  | (12,580 | ) |  |  | (36,790 | ) |
| Total |  | $ | (20,616 | ) |  | $ | (26,569 | ) |  | $ | (41,714 | ) |  | $ | (116,020 | ) |

[0001193125-13-048834:mdna:54]
Our Wind segment generated operating losses of $5.4 million and $10.5 million in the three and nine
months ended December 31, 2012, respectively, compared to operating losses of $14.0 million and $54.7 million in the three and nine months ended December 31, 2011, respectively. The decreases in Wind business unit operating
losses were primarily due to the settlement of certain adverse purchase order liabilities, the expiration of warranty liabilities with certain Chinese customers, and the realization of savings from actions to reduce personnel and other costs that
were implemented in fiscal 2011.

[0001193125-13-048834:mdna:55]
Our Grid segment operating losses increased to $6.7 million in the three months ended
December 31, 2012, compared to $6.3 million in the three months ended December 31, 2011. Our Grid segment operating losses decreased to $18.6 million in the nine months ended December 31, 2012, from $24.5 million in the nine
months ended December 31, 2011. The increase in Grid business unit operating losses for the three month period was primarily due to higher operating expenses, primarily as a result of higher corporate allocations, partially offset by higher
revenues. The decrease in Grid business unit operating losses for the nine month period was primarily due to the realization of savings from actions to reduce personnel and other costs that were implemented in fiscal 2011 and increased revenues from
D-VAR shipments to customers in United Kingdom and Australia.

[0001193125-13-048834:mdna:56]
Unallocated corporate expenses for the three and nine months
ended December 31, 2012, consist primarily of stock-based compensation expense of $1.9 million and $6.0 million, respectively, restructuring and impairment charges of $6.7 million and $6.8 million, respectively. Unallocated corporate expenses
in both the three and nine months ended December 31, 2011, primarily consisted of restructuring and impairment charges of $4.1 million and $8.4 million, respectively, and stock based compensation expense of $2.1 million and $7.7
million respectively. For the nine months ended December 31, 2011, unallocated corporate expenses also included the write-off of the advanced payment to The Switch of $20.6 million.

[0001193125-13-048834:mdna:57]
[same as prior period, unchanged from 0001193125-12-454266:mdna:59]

[0001193125-13-048834:mdna:58]
As a result of our completed debt financings during the nine months ended December 31, 2012, we recognized a liability for derivative
features embedded within the financing agreements, including the convertible feature of the convertible note and warrants issued in conjunction with the Exchanged Note and Term Loan. We are required to value the derivative liabilities and warrants
at fair value each quarter and recognize a gain or loss on the change in fair value of these instruments.

[0001193125-13-048834:mdna:59]
The fair value of
the derivative liabilities and warrants decreased by $5.2 million and $6.1 million and resulted in a gain to our consolidated statements of operations for the three and nine months ended December 31, 2012, respectively. The primary driver of
the gain was the decrease in our stock price during these periods.

[0001193125-13-048834:mdna:60]
[same as prior period, unchanged from 0001193125-12-454266:mdna:62]

[0001193125-13-048834:mdna:61]
Interest expense, net, was $4.6 million and $10.2 million in the three and nine months ended December 31, 2012, respectively,
compared to interest expense of less than $0.1 million and interest income of $0.2 million for the three and nine months ended December 31, 2011, respectively. The increase in interest expense was due to the debt financings completed
during the nine months ended December 31, 2012.

[0001193125-13-048834:mdna:62]
[same as prior period, unchanged from 0001193125-12-454266:mdna:64]

[0001193125-13-048834:mdna:63]
Other expense, net, was $0.1 million and $1.3 million in the three and nine months ended December 31, 2012, respectively, compared to
other income of $0.4 million and $1.3 million for the three and nine months ended December 31, 2011, respectively. The increase in other expense, net primarily relates to lower foreign currency translation gains.

[0001193125-13-048834:mdna:64]
[same as prior period, unchanged from 0001193125-12-454266:mdna:66]

[0001193125-13-048834:mdna:65]
In
the three and nine months ended December 31, 2012, we recorded income tax expense of $0.1 million and an income tax benefit of $0.7 million, respectively. For the three and nine months ended December 31, 2011, we recorded income tax
expense of $0.1 million and $1.2 million, respectively. The income tax expense for the three months ended December 31, 2012, and the three and nine months ended December 31, 2011, was primarily due to income taxes in foreign
jurisdictions. The income tax benefit for the nine months ended December 31, 2012, is primarily due to a refund of income taxes paid in China. We have provided a valuation allowance against all existing and newly created deferred tax assets as
of December 31, 2012, as it is more likely than not that our deferred tax assets are not currently realizable due to the net operating losses we have incurred since our inception.

[0001193125-13-048834:mdna:66]
[same as prior period, unchanged from 0001193125-12-454266:mdna:68]

[0001193125-13-048834:mdna:67]
Generally, a non-GAAP financial
measure is a numerical measure of a company’s performance, financial position, or cash flow that either excludes or includes amounts that are not normally excluded or included in the most directly comparable measure calculated and presented in
accordance with GAAP. The non-GAAP measures included in this Form 10-Q, however, should be considered in addition to, and not as a substitute for, or superior to, the comparable measure prepared in accordance with GAAP.

[0001193125-13-048834:mdna:68]
We define non-GAAP net (loss) income as net (loss) income before adverse purchase commitment (recoveries) losses, net, stock-based
compensation, amortization of acquisition-related intangibles, restructuring and impairment charges, changes in fair value of derivatives and warrants, non-cash interest expense, and the other non-cash or unusual items indicated in the table below.
We believe non-GAAP net (loss) income assists management and investors in comparing our performance across reporting periods on a consistent basis by excluding these non-cash or non-recurring charges that we do not believe are indicative of our core
operating performance. We also regard non-GAAP net (loss) income as a useful measure of operating performance which more closely aligns net (loss) income with cash used in/provided by continuing operations. In addition, we use non-GAAP net (loss)
income as a factor in evaluating management’s performance when determining incentive compensation and to evaluate the effectiveness of our business strategies. A reconciliation of non-GAAP to GAAP net (loss) income is set forth in the table
below (in thousands, except per share data):

[0001193125-13-048834:mdna:69]
|  |  | Three months ended |  |  | Nine months ended |  |
|  |  | December 31, |  |  | December 31, |  |
|  |  | 2012 |  |  | 2011 |  |  | 2012 |  |  | 2011 |  |
| Net loss |  | $ | (20,135 | ) |  | $ | (26,271 | ) |  | $ | (46,360 | ) |  | $ | (115,660 | ) |
| Adverse purchase commitment (recoveries) losses, net |  |  | (119 | ) |  |  | (94 | ) |  |  | (8,428 | ) |  |  | 73 |  |
| Stock-based compensation |  |  | 1,929 |  |  |  | 2,118 |  |  |  | 5,968 |  |  |  | 7,697 |  |
| Amortization of acquisition-related intangibles |  |  | 81 |  |  |  | 287 |  |  |  | 242 |  |  |  | 891 |  |
| Restructuring and impairment charges |  |  | 6,702 |  |  |  | 4,092 |  |  |  | 6,845 |  |  |  | 8,393 |  |
| Executive severance |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 2,066 |  |
| Sinovel litigation |  |  | (12 | ) |  |  | 2,423 |  |  |  | 411 |  |  |  | 5,757 |  |
| Consumption of zero cost-basis inventory |  |  | (602 | ) |  |  | (46 | ) |  |  | (1,389 | ) |  |  | (173 | ) |
| Change in fair value of derivatives and warrants |  |  | (5,217 | ) |  |  | — |  |  |  | (6,114 | ) |  |  | — |  |
| Non-cash interest expense |  |  | 3,867 |  |  |  | — |  |  |  | 8,404 |  |  |  | — |  |
| Write-off of advance payment |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 20,551 |  |
| Non-GAAP net loss |  | $ | (13,506 | ) |  | $ | (17,491 | ) |  | $ | (40,421 | )* |  | $ | (70,405 | ) |
| Non-GAAP loss earnings per share |  | $ | (0.26 | ) |  | $ | (0.34 | ) |  | $ | (0.78 | ) |  | $ | (1.39 | ) |
| Weighted average shares outstanding |  |  | 52,792 |  |  |  | 50,933 |  |  |  | 51,966 |  |  |  | 50,789 |  |

[0001193125-13-048834:mdna:70]
| * | Non-GAAP net loss for the nine months ended December 31, 2012 includes a correction of the Non-GAAP net loss for the first and second quarters of fiscal 2012 relating to the presentation of the effect of the consumption of zero-cost based inventory. Had Non-GAAP net loss been properly reported in those periods, Non-GAAP net loss would have increased by $0.8 million in each of the first and second quarters of fiscal 2012. |

[0001193125-13-048834:mdna:71]
We incurred non-GAAP net losses of $13.5 million and $40.4 million or ($0.26) and
($0.78) per share, for the three and nine months ended December 31, 2012, respectively, compared to a non-GAAP net losses of $17.5 million and $70.4 million, or ($0.34) and ($1.39) per share, for the three and nine months ended
December 31, 2011, respectively. The decreases in the non-GAAP net losses were driven primarily by the factors that resulted in a lower net loss, including the savings from cost reduction actions undertaken in fiscal 2011 and increased
revenues, particularly during the nine months ended December 31, 2012.

[0001193125-13-048834:mdna:72]
[same as prior period, unchanged from 0001193125-12-454266:mdna:74]

[0001193125-13-048834:mdna:73]
At December 31, 2012, we had cash, cash equivalents, marketable securities and restricted cash of $56.4 million, compared to $66.2
million at March 31, 2012, a decrease of $9.8 million. Our cash and cash equivalents, marketable securities and restricted cash are summarized as follows (in thousands):

[0001193125-13-048834:mdna:74]
|  |  | December 31, |  |  | March 31, |  |
|  |  | 2012 |  |  | 2012 |  |
| Cash and cash equivalents |  | $ | 42,457 |  |  | $ | 46,279 |  |
| Marketable securities |  |  | — |  |  |  | 5,304 |  |
| Restricted cash |  |  | 13,974 |  |  |  | 14,626 |  |
| Total cash, cash equivalents, marketable securities and restricted cash |  | $ | 56,431 |  |  | $ | 66,209 |  |

[0001193125-13-048834:mdna:75]
With respect to the unaudited condensed consolidated statement of cash flows, for the nine months ended
December 31, 2012, net cash used in operating activities was $40.7 million compared to $133.3 million for the nine months ended December 31, 2011. The decrease in net cash used in operations is due primarily to the $69.3 million decrease
in net loss and a decrease in cash used for working capital of $53.0 million, partially offset by a decrease in non-cash items of $29.7 million primarily relating to the write-off of the advance payment to the Switch of $20.6 million during the nine
months ended December 31, 2011 and during the nine months ended December 31, 2012, non-cash gains from the recoveries of adverse purchase commitments of $8.4 million and a gain from the change in fair value of derivatives and warrants of
$6.1 million.

[0001193125-13-048834:mdna:76]
For the nine months ended December 31, 2012, net cash provided by investing activities was $4.7 million
compared to net cash provided by investing activities of $68.3 million for the nine months ended December 31, 2011. The decrease in net cash provided by investing activities for the nine months ended December 31, 2012 was driven primarily
by a decrease in the proceeds from the maturity of marketable securities of $105.4 million, partially offset by a decrease in capital expenditures of $8.1 million, the decrease in restricted cash of $6.7 million, and the $20.6 million advance
payment to The Switch, the $3.9 million of purchased intangible assets and the additional minority investment in Tres Amigas of $1.8 million during the nine months ended December 31, 2011, none of which recurred.

[0001193125-13-048834:mdna:77]
For the nine months ended December 31, 2012, net cash provided by financing activities was $32.3 million compared to cash used in
financing activities of $0.1 million in the nine months ended December 31, 2011. The increase in net cash provided by financing activities is primarily due to the net proceeds from our financings of $32.9 million during the nine months ended
December 31, 2012.

[0001193125-13-048834:mdna:78]
At December 31, 2012, we had $9.2 million of restricted cash included in current
assets, and $4.8 million of restricted cash included in long-term assets. These amounts included in restricted cash represent deposits to secure letters of credit for various supply contracts and are held in interest bearing accounts. We are working
with our inventory suppliers to delay cash settlements and to reduce the gross liability associated with our adverse purchase commitments, which is approximately $1.8 million as of December 31, 2012. In conjunction with certain of these
settlements, we agreed to provide letters of credit and bank guarantees in the amount of approximately $9.0 million with expirations through January 31, 2013. The letters of credit and bank guarantees were secured with cash collateral of $8.5
million and were included in our restricted cash balance as of December 31, 2012. As of January 2013, these letters of credit had been cancelled and the cash collateral has been returned to unrestricted cash. During the three and nine months ended
December 31, 2012, we agreed to settle adverse purchase commitments with certain of our vendors and reduced the gross liability associated with our adverse purchase commitments, which had a direct benefit to our cost of sales of $0.1 million
and $8.4 million, respectively.

[0001193125-13-048834:mdna:79]
On May 16, 2012, we entered into an agreement with one of our vendors to settle certain
of our adverse purchase commitments. The agreement was amended on November 6, 2012 (as amended, the “Settlement Agreement”). In conjunction with the Settlement Agreement, we agreed to pay the vendor approximately
€2.2 million (the “Settlement Amount”). Under the Settlement Agreement, we had the option, at our sole discretion, to pay the settlement amount in cash, shares of our common stock, or a combination of cash and common stock.
Accordingly, during the three months ended December 31, 2012, we issued 765,301 shares of our common stock to the vendor and filed a registration statement on Form S-3 to register the vendor’s resale of such shares of common stock. If the
net proceeds from the vendor’s resale of the shares of common stock during a specified period plus any other cash payments made by us subsequent to the date of the Settlement Agreement were less than the Settlement Amount, we agreed to make an
additional payment equal to the shortfall in cash to the vendor no later than December 31, 2012, as of December 31, 2012 we paid $0.8 million as a result of such a shortfall. As security for our obligations, we have provided the vendor
with a letter of credit in the amount of €2.2 million, approximately $3.0 million, with an expiration of December 31, 2012 and was included in our restricted cash balance as of December 31, 2012. As of December 31, 2012, we had
not been formally released from the letter of credit. We received that release in January 2013.

[0001193125-13-048834:mdna:80]
On April 4, 2012, we
entered into a Securities Purchase Agreement with Capital Ventures International (“CVI”), an affiliate of Heights Capital Management (the “Purchase Agreement”) and completed a private placement of $25.0 million of 7% senior
convertible notes (the “Initial Note”). After fees and expenses, the net proceeds were $23.2 million. The Initial Note had an initial conversion price of $4.85 per share, representing a premium of approximately 20% over our closing price
on April 3, 2012. The Initial Note was payable in monthly installments beginning four months from issuance and ending on October 4, 2014. Monthly payments were payable in cash or shares of our common stock at our option, subject to certain
trading volume, stock price and other conditions. CVI could also elect to defer receipt of monthly installment payments at its option. Any deferred installment payments would continue to accrue interest. We registered 10,262,311 shares of our common
stock which may be used as payment for principal and interest in lieu of cash for resale under the Securities Act as required under a Registration Rights Agreement with CVI.

[0001193125-13-048834:mdna:81]
On December 20, 2012, we entered into an Amendment and Exchange Agreement, (the “Amendment”) with CVI, which amended the Purchase Agreement. Pursuant to the Amendment, the Company and CVI
exchanged the Initial Note for a new unsecured, senior convertible note, (the “Exchanged Note”). At the time of the exchange, the Exchanged Note had the same principal amount and accrued interest as the Initial Note. The Exchanged Note is
convertible into our common stock and has the same scheduled monthly installment payments as the Initial Note. The Exchanged Note provides us with additional flexibility to make monthly installment payments in shares of our common stock. We retain
the ability to repay the Exchanged Note in cash. Specifically, the amendments to the Exchanged Note:

[0001193125-13-048834:mdna:82]
|  | • |  | Allow us to convert, subject to the satisfaction of certain conditions set forth in the Exchanged Note, (a) at least $2.5 million of the approximately $5.3 million installment amount payable with respect to the January 2013 installment date (including approximately $4.2 million of deferred installment amounts from the period September 4, 2012 to December 3, 2012) into shares of the Company’s common stock, (On December 21, 2012 we converted $3.8 million in deferred installment amount principal and interest and issued 1,715,443 shares of common stock), and (b) the balance of the January 2013 installment amount in equal amounts on each of the February and March 2013 installment dates; |

[0001193125-13-048834:mdna:83]
|  | • |  | Reduce the price failure equity condition with respect to a particular date of determination from $2.50 to $1.00; |

[0001193125-13-048834:mdna:84]
35

[0001193125-13-048834:mdna:85]
|  | • |  | Reduce the aggregate daily dollar trading volume equity condition required for at least 25 of the 30 consecutive trading days immediately preceding a date of determination from $1,500,000 to $850,000 per trading day. In addition, if the aggregate daily dollar trading volume is between $50,000 and $850,000, the Company may still convert into common stock a portion of an installment amount payable with respect to an installment date equal to the quotient of (x) the aggregate daily dollar trading volume, divided by (y) $850,000; |

[0001193125-13-048834:mdna:86]
|  | • |  | Increase CVI’s beneficial ownership limitation under the Exchanged Note from 4.99% to 9.99%; and |

[0001193125-13-048834:mdna:87]
|  | • |  | Reduce the conversion price, from $4.85 per share our common stock to $3.19 per share of our common stock, subject to certain price-based and other anti-dilution adjustments. |

[0001193125-13-048834:mdna:88]
On June 5, 2012, we entered into a Term Loan with Hercules Technology
Growth Capital, Inc., under which we borrowed $10.0 million. After the closing fees and expenses, the net proceeds were $9.7 million. The Term Loan bears an interest rate equal to 11% plus the percentage, if any, in which the prime rate as reported
by The Wall Street Journal exceeds 3.75%. We made interest only payments from July 1, 2012 through October 31, 2012, after which we began paying the Term Loan in equal monthly installments ending on December 1, 2014. The Term Loan is
secured by substantially all of our existing and future assets, including a mortgage on real property owned by our wholly owned subsidiary, ASC Devens LLC, and located at 64 Jackson Road, Devens, Massachusetts. The Term Loan contains certain
covenants that restrict our ability to, among other things, incur or assume certain debt, merge or consolidate, materially change the nature of our business, make certain investments, acquire or dispose of certain assets, make guaranties or grant
liens on its assets, make certain loans, advances or investments, declare dividends or make distributions or enter into transactions with affiliates. In addition, the Term Loan contains a covenant which requires us to maintain a minimum unrestricted
cash balance in the United States of at least $10.0 million at the inception of the Term Loan, which will decrease starting November 1, 2012 and monthly thereafter by the amount of principal paid. The events of default under the Term Loan
include, but are not limited to, failure to pay amounts due, breaches of covenants, bankruptcy events, cross defaults under other material indebtedness and the occurrence of a material adverse effect and/or change in control. In the case of a
continuing event of default, the lender may, among other remedies, declare due all unpaid principal amounts outstanding and any accrued but unpaid interest and foreclose on all collateral granted to the lender as security under the Term Loan.

[0001193125-13-048834:mdna:89]
Although we believe we are in and expect to remain in compliance with covenants and restrictions included in the agreements
governing these debt arrangements as of the date of this Quarterly Report on Form 10-Q, there can be no assurance that we will continue to be in compliance. If we fail to stay in compliance with our covenants or suffer some other event of default,
we may be forced to repay the outstanding principal of one or both of our debt obligations. In the case of the Exchanged Note, such an event of default would also include the requirement to pay a penalty as defined in the agreement. Should this
occur, our liquidity would be adversely affected.

[0001193125-13-048834:mdna:90]
At December 31, 2012, we had cash and cash equivalents, of $42.5
million, all of which was unrestricted. We experienced a substantial decline in revenues, incurred a net loss of $136.8 million and used $141.0 million of cash for operations during the fiscal year ended March 31, 2012. As a result, we reduced
our global workforce by approximately 50% and consolidated certain business operations in three locations to reduce facility costs. During the third quarter of fiscal 2012, in response to challenging conditions in the wind power market, we undertook
an action to again reduce our global workforce by approximately 25%, including a plan to consolidate certain of our office locations. As of December 31, 2012, we had a global workforce of approximately 373 persons.

[0001193125-13-048834:mdna:91]
We used $40.7 million in cash for operations during the nine months ended December 31, 2012, compared to $133.3 million during the
nine months ended December 31, 2011. We expect that our cost reduction efforts will result in a substantial reduction in cash used for operations during the fiscal year ending March 31, 2013. We plan to closely monitor our expenses and, if
required, expect to further reduce operating costs and capital spending to enhance liquidity.

[0001193125-13-048834:mdna:92]
We believe that our available
cash, together with additional reductions in operating costs and capital expenditures that we expect to make, if necessary, will be sufficient to fund our operations, capital expenditures and any scheduled cash payments under our debt obligations
through December 31, 2013, on the assumption that we continue to be able to make installment payments on the Exchanged Note in shares of common stock. Our ability to pay required monthly installment payments under the Exchanged Note in equity
instead of cash is based on certain stock price and trading volume conditions that are outside of our control. If one or both of these equity conditions are not met (absent a waiver from the lender, which has been provided in the past) we may be
required to make required monthly installment payments in cash. As of the date of this report, we have only made payments to the lender in shares of common stock. Should a scenario arise that we are required to make future scheduled installment
payments entirely in cash, then there may not be sufficient available cash to fund operations, capital expenditures and scheduled cash payments under our other debt obligations through December 31, 2013. Further, our liquidity is highly
dependent on our ability to profitably grow revenues through

[0001193125-13-048834:mdna:93]
both the acquisition of new customers and growth from our existing customers, fund and maintain compliance with the covenants and restrictions on our debt obligations, and raise additional
capital, as required. Potential sources of additional capital include sales of assets and obtaining additional financing (with the agreement of its lenders if required). With respect to sales of assets or additional financing, there can be no
assurance that such sales can be completed on acceptable terms or at all or that financing will be available on commercially acceptable terms or at all.

[0001193125-13-048834:mdna:94]
Legal Proceedings

[0001193125-13-048834:mdna:95]
We are involved in legal and administrative
proceedings and claims of various types. See Part II, Item 1, “Legal Proceedings,” for additional information. We record a liability in our consolidated financial statements for these matters when a loss is known or considered
probable and the amount can be reasonably estimated. We review these estimates each accounting period as additional information is known and adjust the loss provision when appropriate. If a matter is both probable to result in a liability and the
amounts of loss can be reasonably estimated, we estimate and disclose the possible loss or range of loss. If the loss is not probable or cannot be reasonably estimated, a liability is not recorded in its consolidated financial statements.

[0001193125-13-048834:mdna:96]
[same as prior period, unchanged from 0001193125-12-454266:mdna:91]

[0001193125-13-048834:mdna:97]
We do not have any off-balance sheet arrangements, as defined under SEC rules, such as relationships with unconsolidated entities or financial partnerships, which are often referred to as structured
finance or special purpose entities, established for the purpose of facilitating transactions that are not required to be reflected on our balance sheet except as discussed below.

[0001193125-13-048834:mdna:98]
We occasionally enter into construction contracts that include a performance bond. As these contracts progress, we continually assess the
probability of a payout from the performance bond. Should we determine that such a payout is probable, we would record a liability.

[0001193125-13-048834:mdna:99]
[same as prior period, unchanged from 0001193125-12-454266:mdna:94]

[0001193125-13-048834:mdna:100]
[same as prior period, unchanged from 0001193125-12-454266:mdna:95]

[0001193125-13-048834:mdna:101]
In June 2011, the FASB issued Accounting Standards Update (ASU) No. 2011-05, Comprehensive Income (Topic 220): Presentation of Comprehensive Income. ASU 2011-05 requires entities to present
net income and other comprehensive income in either a single continuous statement or in two separate, but consecutive, statements of net income and other comprehensive income. ASU 2011-05 is effective for fiscal years and interim periods beginning
after December 15, 2011. We early adopted ASU 2011-05 and it did not have a material impact on our consolidated results of operations, financial condition, or cash flows.

[0001193125-13-048834:mdna:102]
In September 2011, the FASB issued Accounting Standards Update No. 2011-08, Intangibles — Goodwill and Other (Topic 350). ASU 2011-08 allows entities to first assess qualitatively
whether it is necessary to perform the two-step goodwill impairment test. If an entity believes, as a result of its qualitative assessment, that it is more likely than not that the fair value of a reporting unit is less than its carrying amount, the
quantitative two-step goodwill impairment test is required. An entity has the unconditional option to bypass the qualitative assessment and proceed directly to performing the first step of the goodwill impairment test. ASU 2011-08 is effective for
our first quarter of fiscal 2013 but is eligible for early adoption. We do not believe adoption of this standard will have an impact on our consolidated results of operations, financial condition, or cash flows.

[0001193125-13-048834:mdna:103]
In December 2011, the FASB issued Accounting Standards Update No. 2011-11, Balance Sheet (Topic 210)-Disclosures about Offsetting
Assets and Liabilities (ASU 2011-11). The update requires entities to disclose information about offsetting and related arrangements of financial instruments and derivative instruments. ASU 2011-11 is effective for our first quarter of fiscal
2014. We are currently evaluating the impact of adopting ASU 2011-11, but currently believe there will be no significant impact on our consolidated results of operations, financial condition, or cash flows.

[0001193125-13-048834:mdna:104]
We do not believe that other recently issued accounting pronouncements will have a material impact on our financial statements.
