# AMSC 8-K — 0001193125-13-048784 filed 2013-02-11

## item codes, every 8-K on or before 2013-02-11

- 2013-02-11 0001193125-13-048784 — 2.02, 9.01
- 2013-01-08 0001193125-13-006861 — 5.02, 9.01
- 2012-12-21 0001193125-12-511592 — 1.01, 2.03, 3.02, 9.01
- 2012-11-28 0001193125-12-483317 — 2.05, 5.02, 7.01, 9.01
- 2012-11-06 0001193125-12-453359 — 2.02, 9.01
- 2012-08-02 0001193125-12-330534 — 2.02, 9.01
- 2012-07-27 0001193125-12-318790 — 5.02, 5.07, 9.01
- 2012-06-06 0001193125-12-261030 — 1.01, 2.02, 2.03, 3.02, 5.02, 9.01
- 2012-05-09 0001193125-12-222210 — 5.02
- 2012-04-20 0001193125-12-172045 — 8.01
- 2012-04-13 0001193125-12-162694 — 2.02, 8.01, 9.01
- 2012-04-04 0001193125-12-149102 — 1.01, 2.02, 2.03, 3.02, 9.01
- 2012-02-09 0001193125-12-048009 — 2.02, 9.01
- 2012-02-06 0001193125-12-041344 — 5.07 — amendment of 0000950123-11-102495
- 2011-12-08 0000950123-11-102495 — 5.07
- 2011-11-29 0000950123-11-100822 — 2.05
- 2011-11-09 0000950123-11-096775 — 2.02, 9.01
- 2011-10-31 0000950123-11-093390 — 1.02, 9.01
- 2011-10-07 0000950123-11-089221 — 8.01
- 2011-10-03 0000950123-11-088315 — 7.01
- 2011-09-23 0000950123-11-086288 — 2.02, 9.01
- 2011-09-15 0000950123-11-084585 — 7.01
- 2011-09-06 0000950123-11-082736 — 7.01
- 2011-08-18 0000950123-11-078526 — 3.01, 7.01, 9.01
- 2011-08-11 0000950123-11-075905 — 5.02
- 2011-08-11 0000950123-11-075904 — 2.02, 2.05, 9.01
- 2011-07-11 0000950123-11-064934 — 2.02, 4.02, 9.01
- 2011-06-30 0000950123-11-063287 — 1.01, 3.02, 9.01
- 2011-06-21 0000950123-11-060491 — 3.01, 7.01, 9.01
- 2011-06-13 0000950123-11-058656 — 1.01, 9.01
- 2011-05-24 0000950123-11-053517 — 5.02, 9.01
- 2011-04-05 0001299933-11-001020 — 2.02, 9.01
- 2011-03-15 0000950123-11-025580 — 5.02
- 2011-03-14 0000950123-11-025205 — 1.01, 3.02, 9.01
- 2011-02-01 0001299933-11-000333 — 2.02, 9.01
- 2010-11-12 0000950123-10-104604 — 8.01, 9.01
- 2010-11-08 0000950123-10-102424 — 8.01, 9.01
- 2010-11-02 0001299933-10-003878 — 2.02, 9.01
- 2010-09-15 0000950123-10-086373 — 1.01, 9.01 — amendment, the index does not say of what
- 2010-08-06 0000950123-10-074362 — 5.07
- 2010-07-29 0001299933-10-002860 — 2.02, 9.01
- 2010-05-17 0000950123-10-050424 — 1.01, 9.01
- 2010-05-14 0001299933-10-001972 — 5.02
- 2010-05-13 0001299933-10-001943 — 2.02, 9.01
- 2010-02-08 0001299933-10-000506 — 8.01
- 2010-02-02 0001299933-10-000386 — 2.02, 9.01
- 2009-12-15 0001299933-09-004928 — 5.02
- 2009-10-29 0001299933-09-004267 — 2.02, 9.01
- 2009-08-12 0001193125-09-173026 — 5.02, 9.01
- 2009-07-30 0001193125-09-158842 — 1.01, 2.02, 9.01
- 2009-05-15 0001193125-09-113158 — 5.02
- 2009-05-14 0001193125-09-110619 — 2.02, 9.01
- 2009-04-20 0001193125-09-082590 — 5.02
- 2009-02-03 0001193125-09-016992 — 2.02, 9.01
- 2009-01-22 0001193125-09-009777 — 2.02, 9.01
- 2008-11-04 0001193125-08-223730 — 2.02, 9.01
- 2008-08-11 0001193125-08-173616 — 8.01
- 2008-08-07 0001193125-08-170325 — 8.01
- 2008-08-05 0001193125-08-165888 — 2.02, 9.01
- 2008-06-11 0001193125-08-132049 — 1.01, 9.01
- 2008-05-20 0001193125-08-119372 — 5.02, 9.01
- 2008-05-08 0001193125-08-107052 — 2.02, 9.01
- 2008-01-31 0001193125-08-016233 — 2.02, 9.01
- 2008-01-30 0001193125-08-015494 — 5.03, 9.01
- 2007-11-01 0001193125-07-231866 — 2.02, 9.01
- 2007-10-31 0001193125-07-231225 — 2.05
- 2007-10-29 0001193125-07-228284 — 5.03, 9.01
- 2007-09-27 0001193125-07-208950 — 5.02
- 2007-08-09 0001193125-07-176553 — 2.02, 9.01
- 2007-08-07 0001193125-07-173829 — 1.01, 5.02, 9.01
- 2007-07-02 0001193125-07-148303 — 5.02, 9.01
- 2007-06-20 0001193125-07-139068 — 8.01, 9.01
- 2007-06-14 0001193125-07-135550 — 9.01 — amendment of 0001193125-07-005297
- 2007-06-14 0001193125-07-135340 — 5.02
- 2007-05-24 0001193125-07-122148 — 2.02, 9.01
- 2007-03-30 0001193125-07-070154 — 2.05, 9.01
- 2007-03-23 0001193125-07-062978 — 9.01 — amendment of 0001193125-07-005297
- 2007-02-01 0001193125-07-017883 — 2.02, 9.01
- 2007-01-11 0001193125-07-005297 — 2.01, 9.01
- 2006-12-05 0001181431-06-067500 — 5.02
- 2006-11-29 0001193125-06-243360 — 1.01, 3.02, 9.01
- 2006-11-02 0001193125-06-221464 — 2.02, 9.01
- 2006-09-21 0001193125-06-194526 — 5.02
- 2006-08-08 0001193125-06-164819 — 2.02, 9.01
- 2006-08-02 0001193125-06-159113 — 1.01, 9.01
- 2006-07-28 0001193125-06-156172 — 1.01
- 2006-06-26 0001193125-06-135913 — 1.01, 3.03, 9.01
- 2006-05-11 0001193125-06-108489 — 2.02, 9.01
- 2006-05-05 0001193125-06-102270 — 1.01, 9.01
- 2006-05-01 0001193125-06-094941 — 2.02, 2.06, 9.01
- 2006-02-24 0001193125-06-038281 — 5.02, 9.01
- 2006-02-02 0001181431-06-007665 — 2.02, 9.01
- 2005-11-09 0001181431-05-060304 — 2.02, 9.01
- 2005-08-04 0001181431-05-044420 — 2.02, 9.01
- 2005-07-28 0001193125-05-151272 — 5.02, 9.01
- 2005-06-14 0001193125-05-125148 — 5.02, 9.01
- 2005-05-12 0001181431-05-027410 — 2.02, 9.01
- 2005-05-10 0001193125-05-102795 — 1.01
- 2005-04-05 0001181431-05-020680 — 1.01, 2.02, 3.02, 9.01
- 2005-02-03 0001181431-05-006678 — 2.02, 9.01
- 2004-11-09 0001181431-04-051381 — 2.02, 9.01 — amendment, the index does not say of what
- 2004-11-04 0001181431-04-050706 — 2.02, 9.01
- 2004-10-15 0001193125-04-172458 — 1.01, 9.01
- 2004-08-05 0001193125-04-132162 — 12
- 2004-05-13 0001193125-04-086853 — 12
- 2004-02-05 0001193125-04-015060 — 12
- 2003-11-06 0001193125-03-074000 — 12
- 2003-09-26 0001193125-03-054624 — 5
- 2003-08-06 0001193125-03-029666 — 12
- 2003-05-14 0000927016-03-002619 — 9
- 2002-12-31 0000927016-02-006114 — 5
- 2000-01-24 0000927016-00-000150 — 5, 7
- 1998-11-02 0000950135-98-005625 — 5, 7
- 1998-03-24 0000950135-98-001743 — 5, 7
- 1997-09-05 0000950135-97-003729 — 5, 7
- 1997-06-23 0000950135-97-002785 — 1 — amendment of 0000950135-97-001972
- 1997-04-23 0000950135-97-001972 — 2, 7

## late-filing notifications on or before 2013-02-11

- 2011-08-10 0000950123-11-075677 — NT 10-Q, for the period ended 2011-06-30
- 2011-05-31 0000950123-11-055465 — NT 10-K, for the period ended 2011-03-31

## item 2.02 — earnings release, exhibit 99.1

[0001193125-13-048784:8k_2_02:1]
EX-99.1
2
d481506dex991.htm
EX-99.1

[0001193125-13-048784:8k_2_02:2]
EX-99.1

[0001193125-13-048784:8k_2_02:3]
Exhibit 99.1

[0001193125-13-048784:8k_2_02:4]
AMSC Reports Third Quarter

[0001193125-13-048784:8k_2_02:5]
Financial Results

[0001193125-13-048784:8k_2_02:6]
Company to host conference call today at 5 p.m. ET

[0001193125-13-048784:8k_2_02:7]
Devens, MA – February 11, 2013 – AMSC (NASDAQ: AMSC), a global solutions provider serving wind and power grid
industry leaders, today reported financial results for its third quarter of fiscal year 2012 ended December 31, 2012.

[0001193125-13-048784:8k_2_02:8]
Revenues for the third quarter of fiscal 2012 were $17.4 million, which compares with $18.1 million for the third quarter of fiscal
2011. Revenues were lower than the company’s previous forecast due primarily to delayed revenue recognition with a customer in the company’s Wind segment. As a result of this delay, the company’s Wind revenues for the third quarter of
fiscal 2012 declined by 33 percent year over year. The company increased its Grid revenues by 34 percent year over year in the third fiscal quarter as a result of greater D-VAR® system shipments.

[0001193125-13-048784:8k_2_02:9]
For the third quarter of fiscal 2012,
AMSC reported a net loss of $20.1 million, or $0.38 per share. This figure includes approximately $6.7 million in restructuring and impairment charges, partially offset by a $5.2 million non-cash “mark-to-market” gain driven by the
re-valuation of the derivative liability and warrants associated with the company’s debt financings. For the third quarter of fiscal 2011, AMSC’s net loss was $26.3 million, or $0.52 per share. This figure included an aggregate of $6.5
million in costs associated with corporate restructuring, impairment and litigation charges.

[0001193125-13-048784:8k_2_02:10]
The company’s non-GAAP net loss for the
third quarter of fiscal 2012 was $13.5 million, or $0.26 per share. This compares with a non-GAAP net loss of $17.5 million, or $0.34 per share, for the third quarter of fiscal 2011. Please refer to the financial table below for a reconciliation of
GAAP to non-GAAP results.

[0001193125-13-048784:8k_2_02:11]
AMSC’s cash, cash equivalents, marketable securities, and restricted cash at December 31, 2012 totaled
$56.4 million. This compares with $73.1 million as of September 30, 2012. The company’s cash usage during the third fiscal quarter included payments toward its adverse purchase commitments, which were reduced from approximately $12.1
million as of September 30, 2012 to approximately $1.8 million as of December 31, 2012.

[0001193125-13-048784:8k_2_02:12]
“Our non-GAAP net loss and ending cash
balance came in better than our forecast in the third fiscal quarter despite the revenue shortfall,” said Daniel P. McGahn, President and CEO, AMSC. “In response to the recent challenges in the global wind power market, we also took action
during the third quarter to lower our cost structure while continuing to focus on building our order book.”

[0001193125-13-048784:8k_2_02:13]
Looking Forward

[0001193125-13-048784:8k_2_02:14]
For the fourth fiscal quarter ending March 31, 2013, AMSC expects that its revenues will exceed $18 million and that its net loss
will be less than $18 million, or $0.32 per share. This forecast excludes any impact from mark-to-market adjustments related to the derivative liability and warrants. AMSC expects

[0001193125-13-048784:8k_2_02:15]
| AMSC Reports Q3 Results |  | Page 2 |

[0001193125-13-048784:8k_2_02:16]
that its non-GAAP (as defined below) net loss for the fourth quarter of fiscal 2012 will be less than $13 million, or
$0.23 per share. AMSC expects to have more than $48 million in cash, cash equivalents and restricted cash on March 31, 2013.

[0001193125-13-048784:8k_2_02:17]
“As we
approach the start of fiscal year 2013, the tenor in the global wind power market has been changing for the better,” McGahn continued. “A healthy rebound has been forecast in our core Asian markets, while the U.S., U.K. and Australia
– key adopters of our D-VAR grid interconnection solution – remain stable and compelling. At the same time, we have begun to pursue opportunities related to a broader adoption of renewables in emerging markets such as South America, South
Africa and Eastern Europe. Given these trends, activities and the diversity of our global revenue streams, we believe that we will be able to generate annual revenue growth of at least 25% in fiscal 2013.”

[0001193125-13-048784:8k_2_02:18]
Conference Call Reminder

[0001193125-13-048784:8k_2_02:19]
In conjunction
with this announcement, AMSC management will participate in a conference call with investors beginning at 5:00 p.m. Eastern Time today to discuss the company’s results and its business outlook. Those who wish to listen to the live or archived
conference call webcast should visit the “Investors” section of the company’s website at http://www.amsc.com/investors. The live call also can be accessed by dialing 719-325-2454 and using conference ID 3192954.

[0001193125-13-048784:8k_2_02:20]
About AMSC (NASDAQ: AMSC)

[0001193125-13-048784:8k_2_02:21]
AMSC
generates the ideas, technologies and solutions that meet the world’s demand for smarter, cleaner … better energy. Through its Windtec™ Solutions, AMSC provides wind turbine electronic controls and systems, designs and engineering
services that reduce the cost of wind energy. Through its Gridtec™ Solutions, AMSC provides the engineering planning services and advanced grid systems that optimize network reliability, efficiency and performance. The company’s solutions
are now powering gigawatts of renewable energy globally and are enhancing the performance and reliability of power networks in more than a dozen countries. Founded in 1987, AMSC is headquartered near Boston, Massachusetts with operations in Asia,
Australia, Europe and North America. For more information, please visit www.amsc.com.

[0001193125-13-048784:8k_2_02:22]
AMSC, Windtec, and Gridtec are trademarks or
registered trademarks of American Superconductor Corporation. All other brand names, product names, trademarks or service marks belong to their respective holders.

[0001193125-13-048784:8k_2_02:23]
There are a number of important factors that could materially impact the value of our common stock or cause actual results to differ
materially from those indicated by such forward-looking statements. Such factors include: Our success in addressing the wind energy market is dependent on the manufacturers that license our designs; we may not realize all of the sales expected from
our backlog of orders and contracts; we may require additional funding in the future and may be unable to raise capital when needed; our business and operations would be adversely impacted in the event of a failure or security breach of our
information technology infrastructure; our success is dependent upon attracting and retaining qualified personnel and our inability to do so could significantly damage our business and prospects; we rely upon third-party suppliers for the components
and subassemblies of many of our Wind and Grid products, making us vulnerable to supply shortages and price fluctuations, which could harm our business; many of our revenue opportunities are dependent upon subcontractors and other business
collaborators; if we fail to implement our business strategy successfully, our financial performance could be harmed; problems with product quality or product performance may cause us to incur warranty expenses and may damage our market reputation

[0001193125-13-048784:8k_2_02:24]
| AMSC Reports Q3 Results |  | Page 3 |

[0001193125-13-048784:8k_2_02:25]
and prevent us from achieving increased sales and market share; our contracts with the United States government are
subject to audit, modification or termination by the United States government and include certain other provisions in favor of the government; the continued funding of such contracts remains subject to annual congressional appropriation which, if
not approved, could reduce our revenue and lower or eliminate our profit; we may acquire additional complementary businesses or technologies, which may require us to incur substantial costs for which we may never realize the anticipated benefits;
many of our customers outside of the United States are, either directly or indirectly, related to governmental entities, and we could be adversely affected by violations of the United States Foreign Corrupt Practices Act and similar worldwide
anti-bribery laws outside the United States; we have limited experience in marketing and selling our superconductor products and system-level solutions, and our failure to effectively market and sell our products and solutions could lower our
revenue and cash flow; we have a history of operating losses, and we may incur additional losses in the future; our operating results may fluctuate significantly from quarter to quarter and may fall below expectations in any particular fiscal
quarter; our new debt obligations include certain covenants and other events of default. Should we not comply with the covenants or incur an event of default, we may be required to repay our debt obligations in cash, which could have an adverse
effect on our liquidity; we have recorded a liability for adverse purchase commitments with certain of our vendors; should we be required to settle these liabilities in cash, our liquidity could be adversely affected; if we fail to maintain proper
and effective internal controls over financial reporting, our ability to produce accurate and timely financial statements could be impaired and may lead investors and other users to lose confidence in our financial data; we may be required to issue
performance bonds or provide letters of credit, which restricts our ability to access any cash used as collateral for the bonds or letters of credit; changes in exchange rates could adversely affect our results from operations; growth of the wind
energy market depends largely on the availability and size of government subsidies and economic incentives; we depend on sales to customers in China, and global conditions could negatively affect our operating results or limit our ability to expand
our operations outside of China; changes in China’s political, social, regulatory and economic environment may affect our financial performance; our products face intense competition, which could limit our ability to acquire or retain
customers; our international operations are subject to risks that we do not face in the United States, which could have an adverse effect on our operating results; adverse changes in domestic and global economic conditions could adversely affect our
operating results; we may be unable to adequately prevent disclosure of trade secrets and other proprietary information; our patents may not provide meaningful protection for our technology, which could result in us losing some or all of our market
position; the commercial uses of superconductor products are limited today, and a widespread commercial market for our products may not develop; there are a number of technological challenges that must be successfully addressed before our
superconductor products can gain widespread commercial acceptance, and our inability to address such technological challenges could adversely affect our ability to acquire customers for our products; we have not manufactured our Amperium wire in
commercial quantities, and a failure to manufacture our Amperium wire in commercial quantities at acceptable cost and quality levels would substantially limit our future revenue and profit potential; third parties have or may acquire patents that
cover the materials, processes and technologies we use or may use in the future to manufacture our Amperium products, and our success depends on our ability to license such patents or other proprietary rights; our technology and products could
infringe intellectual property rights of others, which may require costly litigation and, if we are not successful, could cause us to pay substantial damages and disrupt our business; we have filed a demand for arbitration and other lawsuits against
our former largest customer, Sinovel, regarding amounts we contend are overdue. We cannot be certain as to the outcome of these proceedings; we have been named as a party to purported stockholder class actions and stockholder derivative complaints,
and we may be named in additional litigation, all of which will require significant management time and attention, result in significant legal expenses and may result in an unfavorable outcome, which could have a material adverse effect on our
business, operating results and financial condition; our 7% convertible note contains provisions that could limit our ability to repay the note in shares of common stock and should the note be repaid in stock, shareholders could experience
significant dilution; our common stock has experienced, and may continue to experience, significant market price and volume fluctuations, which may prevent our stockholders from selling our common stock at a profit and could lead to costly
litigation against us that could divert our management’s attention; and new regulations related to conflict-free minerals may force us to incur additional expenses. These and the important factors discussed under the caption “Risk
Factors” in Part II. Item 1A and Part 1. Item 1A of our Form 10-K/A for the fiscal year ended March 31, 2012, and our other reports filed with the SEC, among others, could cause actual results to differ materially from those
indicated by forward-looking statements made herein and presented elsewhere by management from time to time. Any such forward-looking statements represent management’s estimates as of the date of this press release. While we may elect to update
such forward-looking statements at some point in the future, we disclaim any obligation to do so, even if subsequent events cause our views to change. These forward-looking statements should not be relied upon as representing our views as of any
date subsequent to the date of this press release.

[0001193125-13-048784:8k_2_02:26]
| AMSC Reports Q3 Results |  | Page 4 |

[0001193125-13-048784:8k_2_02:27]
UNAUDITED CONSOLIDATED STATEMENTS OF OPERATIONS

[0001193125-13-048784:8k_2_02:28]
(In thousands, except per share data)

[0001193125-13-048784:8k_2_02:29]
|  |  | Three months endedDecember 31, |  |  | Nine months endedDecember 31, |  |
|  |  | 2012 |  |  | 2011 |  |  | 2012 |  |  | 2011 |  |
| Revenues |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Wind |  | $ | 6,808 |  |  | $ | 10,125 |  |  | $ | 35,321 |  |  | $ | 27,836 |  |
| Grid |  |  | 10,609 |  |  |  | 7,933 |  |  |  | 31,679 |  |  |  | 20,080 |  |
| Total Revenues |  |  | 17,417 |  |  |  | 18,058 |  |  |  | 67,000 |  |  |  | 47,916 |  |
| Cost of revenues |  |  | 16,533 |  |  |  | 18,918 |  |  |  | 53,843 |  |  |  | 57,810 |  |
| Gross profit (loss) |  |  | 884 |  |  |  | (860 | ) |  |  | 13,157 |  |  |  | (9,894 | ) |
| Cost and operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Research and development |  |  | 3,948 |  |  |  | 5,928 |  |  |  | 11,480 |  |  |  | 21,339 |  |
| Selling, general and administrative |  |  | 10,769 |  |  |  | 15,402 |  |  |  | 36,304 |  |  |  | 54,952 |  |
| Restructuring and impairments |  |  | 6,702 |  |  |  | 4,092 |  |  |  | 6,845 |  |  |  | 8,393 |  |
| Write-off of advance payment |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 20,551 |  |
| Amortization of acquisition related intangibles |  |  | 81 |  |  |  | 287 |  |  |  | 242 |  |  |  | 891 |  |
| Total cost and operating expenses |  |  | 21,500 |  |  |  | 25,709 |  |  |  | 54,871 |  |  |  | 106,126 |  |
| Operating loss |  |  | (20,616 | ) |  |  | (26,569 | ) |  |  | (41,714 | ) |  |  | (116,020 | ) |
| Change in fair value of derivatives and warrants |  |  | 5,217 |  |  |  | — |  |  |  | 6,114 |  |  |  | — |  |
| Interest (expense) income, net |  |  | (4,553 | ) |  |  | (11 | ) |  |  | (10,191 | ) |  |  | 232 |  |
| Other (expense) income, net |  |  | (109 | ) |  |  | 393 |  |  |  | (1,252 | ) |  |  | 1,313 |  |
| Loss before income tax expense |  |  | (20,061 | ) |  |  | (26,187 | ) |  |  | (47,043 | ) |  |  | (114,475 | ) |
| Income tax expense (benefit) |  |  | 74 |  |  |  | 84 |  |  |  | (683 | ) |  |  | 1,185 |  |
| Net loss |  | $ | (20,135 | ) |  | $ | (26,271 | ) |  | $ | (46,360 | ) |  | $ | (115,660 | ) |
| Net loss per common share |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | (0.38 | ) |  | $ | (0.52 | ) |  | $ | (0.89 | ) |  | $ | (2.28 | ) |
| Diluted |  | $ | (0.38 | ) |  | $ | (0.52 | ) |  | $ | (0.89 | ) |  | $ | (2.28 | ) |
| Weighted average number of common shares outstanding |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  |  | 52,792 |  |  |  | 50,933 |  |  |  | 51,966 |  |  |  | 50,789 |  |
| Diluted |  |  | 52,792 |  |  |  | 50,933 |  |  |  | 51,966 |  |  |  | 50,789 |  |

[0001193125-13-048784:8k_2_02:30]
| AMSC Reports Q3 Results |  | Page 5 |

[0001193125-13-048784:8k_2_02:31]
UNAUDITED CONSOLIDATED BALANCE SHEETS

[0001193125-13-048784:8k_2_02:32]
(In thousands)

[0001193125-13-048784:8k_2_02:33]
|  |  | December 31,2012 |  |  | March 31,2012 |  |
| ASSETS |  |  |  |  |  |  |  |  |
| Current assets: |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 42,457 |  |  | $ | 46,279 |  |
| Marketable securities |  |  | — |  |  |  | 5,304 |  |
| Accounts receivable, net |  |  | 12,328 |  |  |  | 18,999 |  |
| Inventory |  |  | 36,455 |  |  |  | 29,256 |  |
| Prepaid expenses and other current assets |  |  | 26,735 |  |  |  | 31,444 |  |
| Restricted cash |  |  | 9,154 |  |  |  | 12,086 |  |
| Deferred tax assets |  |  | 203 |  |  |  | 203 |  |
| Total current assets |  |  | 127,332 |  |  |  | 143,571 |  |
| Property, plant and equipment, net |  |  | 78,010 |  |  |  | 90,828 |  |
| Intangibles, net |  |  | 2,999 |  |  |  | 3,772 |  |
| Restricted cash |  |  | 4,820 |  |  |  | 2,540 |  |
| Deferred tax assets |  |  | 3,129 |  |  |  | 3,129 |  |
| Other assets |  |  | 9,029 |  |  |  | 11,216 |  |
| Total assets |  | $ | 225,319 |  |  | $ | 255,056 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |  |  |  |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |  |  |  |
| Accounts payable and accrued expenses |  | $ | 30,320 |  |  | $ | 37,582 |  |
| Note payable, current portion, net of discount of $552 as of December 31, 2012 |  |  | 4,063 |  |  |  | — |  |
| Current portion of convertible note, net of discount of $5,448 as of December 31, 2012 |  |  | 7,162 |  |  |  | — |  |
| Derivative liability |  |  | 5,605 |  |  |  | — |  |
| Adverse purchase commitments |  |  | 1,799 |  |  |  | 25,894 |  |
| Deferred revenue |  |  | 23,794 |  |  |  | 19,718 |  |
| Deferred tax liabilities |  |  | 3,129 |  |  |  | 3,129 |  |
| Total current liabilities |  |  | 75,872 |  |  |  | 86,323 |  |
| Note payable, net of discount of $174 as of December 31, 2012 |  |  | 4,442 |  |  |  | — |  |
| Convertible note net of discount of $1,287 as of December 31, 2012 |  |  | 7,047 |  |  |  | — |  |
| Deferred revenue |  |  | 1,445 |  |  |  | 1,558 |  |
| Deferred tax liabilities |  |  | 203 |  |  |  | 203 |  |
| Other liabilities |  |  | 1,497 |  |  |  | 2,093 |  |
| Total liabilities |  |  | 90,506 |  |  |  | 90,177 |  |
| Stockholders’ equity: |  |  |  |  |  |  |  |  |
| Common stock |  |  | 567 |  |  |  | 520 |  |
| Additional paid-in capital |  |  | 913,107 |  |  |  | 896,603 |  |
| Treasury stock |  |  | (313 | ) |  |  | (271 | ) |
| Accumulated other comprehensive income |  |  | 1,812 |  |  |  | 2,027 |  |
| Accumulated deficit |  |  | (780,360 | ) |  |  | (734,000 | ) |
| Total stockholders’ equity |  |  | 134,813 |  |  |  | 164,879 |  |
| Total liabilities and stockholders’ equity |  | $ | 225,319 |  |  | $ | 255,056 |  |

[0001193125-13-048784:8k_2_02:34]
| AMSC Reports Q3 Results |  | Page 6 |

[0001193125-13-048784:8k_2_02:35]
UNAUDITED CONSOLIDATED STATEMENTS OF CASH FLOWS

[0001193125-13-048784:8k_2_02:36]
(In thousands)

[0001193125-13-048784:8k_2_02:37]
|  |  | Nine months endedDecember 31, |  |
|  |  | 2012 |  |  | 2011 |  |
| Cash flows from operating activities: |  |  |  |  |  |  |  |  |
| Net loss |  | $ | (46,360 | ) |  | $ | (115,660 | ) |
| Adjustments to reconcile net (loss) to net cash (used in) operations: |  |  |  |  |  |  |  |  |
| Depreciation and amortization |  |  | 10,143 |  |  |  | 10,875 |  |
| Stock-based compensation expense |  |  | 5,968 |  |  |  | 7,697 |  |
| Write-off of advanced payment to The Switch |  |  | — |  |  |  | 20,551 |  |
| Restructuring charges, net of payments |  |  | 261 |  |  |  | 2,721 |  |
| Impairment of long-lived and intangible assets |  |  | 4,507 |  |  |  | 2,829 |  |
| Provision for excess and obsolete inventory |  |  | 957 |  |  |  | 2,150 |  |
| Adverse purchase commitment (recoveries) losses, net |  |  | (8,428 | ) |  |  | 73 |  |
| Loss on minority interest investments |  |  | 1,914 |  |  |  | 1,614 |  |
| Change in fair value of convertible notes and warrants |  |  | (6,114 | ) |  |  | — |  |
| Non-cash interest expense |  |  | 8,404 |  |  |  | — |  |
| Other non-cash items |  |  | 1,790 |  |  |  | 613 |  |
| Changes in operating asset and liability accounts: |  |  |  |  |  |  |  |  |
| Accounts receivable |  |  | 6,085 |  |  |  | (1,262 | ) |
| Inventory |  |  | (8,173 | ) |  |  | (10,419 | ) |
| Prepaid expenses and other current assets |  |  | 4,699 |  |  |  | 3,244 |  |
| Accounts payable and accrued expenses |  |  | (20,330 | ) |  |  | (63,554 | ) |
| Deferred revenue |  |  | 3,986 |  |  |  | 5,254 |  |
| Net cash used in operating activities |  |  | (40,691 | ) |  |  | (133,274 | ) |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |
| Net cash provided by investing activities |  |  | 4,691 |  |  |  | 68,321 |  |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |
| Net cash provided by (used in) financing activities |  |  | 32,262 |  |  |  | (121 | ) |
| Effect of exchange rate changes on cash and cash equivalents |  |  | (84 | ) |  |  | (104 | ) |
| Net (decrease) in cash and cash equivalents |  |  | (3,822 | ) |  |  | (65,178 | ) |
| Cash and cash equivalents at beginning of year |  |  | 46,279 |  |  |  | 123,783 |  |
| Cash and cash equivalents at end of year |  | $ | 42,457 |  |  | $ | 58,605 |  |
| Supplemental schedule of cash flow information: |  |  |  |  |  |  |  |  |
| Cash paid for income taxes, net of refunds |  | $ | (704 | ) |  | $ | 13,482 |  |
| Issuance of common stock to settle liabilities |  |  | 10,406 |  |  |  | 586 |  |
| Cash paid for interest expense |  |  | 543 |  |  |  | — |  |

[0001193125-13-048784:8k_2_02:38]
| AMSC Reports Q3 Results |  | Page 7 |

[0001193125-13-048784:8k_2_02:39]
Reconciliation of GAAP Net (Loss) Income to Non-GAAP Net (Loss) Income

[0001193125-13-048784:8k_2_02:40]
(In thousands, except per share data)

[0001193125-13-048784:8k_2_02:41]
|  |  | Three months endedDecember 31, |  |  | Nine months endedDecember 31, |  |
|  |  | 2012 |  |  | 2011 |  |  | 2012 |  |  | 2011 |  |
| Net loss |  | $ | (20,135 | ) |  | $ | (26,271 | ) |  | $ | (46,360 | ) |  | $ | (115,660 | ) |
| Adverse purchase commitment (recoveries) losses, net |  |  | (119 | ) |  |  | (94 | ) |  |  | (8,428 | ) |  |  | 73 |  |
| Stock-based compensation |  |  | 1,929 |  |  |  | 2,118 |  |  |  | 5,968 |  |  |  | 7,697 |  |
| Amortization of acquisition-related intangibles |  |  | 81 |  |  |  | 287 |  |  |  | 242 |  |  |  | 891 |  |
| Restructuring and impairment charges |  |  | 6,702 |  |  |  | 4,092 |  |  |  | 6,845 |  |  |  | 8,393 |  |
| Executive severance |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 2,066 |  |
| Sinovel litigation |  |  | (12 | ) |  |  | 2,423 |  |  |  | 411 |  |  |  | 5,757 |  |
| Consumption of zero cost-basis inventory |  |  | (602 | ) |  |  | (46 | ) |  |  | (1,389 | ) |  |  | (173 | ) |
| Change in fair value of derivatives and warrants |  |  | (5,217 | ) |  |  | — |  |  |  | (6,114 | ) |  |  | — |  |
| Non-cash interest expense |  |  | 3,867 |  |  |  | — |  |  |  | 8,404 |  |  |  | — |  |
| Write-off of advance payment |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 20,551 |  |
| Non-GAAP net loss |  | $ | (13,506 | ) |  | $ | (17,491 | ) |  | $ | (40,421 | )* |  | $ | (70,405 | ) |
| Non-GAAP loss earnings per share |  | $ | (0.26 | ) |  | $ | (0.34 | ) |  | $ | (0.78 | ) |  | $ | (1.39 | ) |
| Weighted average shares outstanding |  |  | 52,792 |  |  |  | 50,933 |  |  |  | 51,966 |  |  |  | 50,789 |  |

[0001193125-13-048784:8k_2_02:42]
* Non-GAAP net loss for the nine months ended December 31, 2012 includes a correction of the Non-GAAP net loss for
the first and second quarters of fiscal 2012 relating to the presentation of the effect of the consumption of zero-cost based inventory. Had Non-GAAP net loss been properly reported in those periods, Non-GAAP net loss would have increased by
$0.8 million in each of the first and second quarters of fiscal 2012.

[0001193125-13-048784:8k_2_02:43]
Reconciliation of Forecast GAAP Net Loss to Non-GAAP
Net Loss

[0001193125-13-048784:8k_2_02:44]
(In millions, except per share data)

[0001193125-13-048784:8k_2_02:45]
|  |  | Three months endingMarch 31, 2013 |  |
| Net loss |  | $ | (18.0 | ) |
| Amortization of acquisition-related intangibles |  |  | 0.1 |  |
| Stock-based compensation |  |  | 2.1 |  |
| Non-cash interest expense |  |  | 2.8 |  |
| Non-GAAP net loss |  | $ | (13.0 | ) |
| Non-GAAP net loss per share |  | $ | (0.23 | ) |
| Shares outstanding |  |  | 55.6 |  |

[0001193125-13-048784:8k_2_02:46]
Note: Non-GAAP net income (loss) is defined by the company as net income (loss) before adverse
purchase commitments (recoveries) losses, net; stock-based compensation; amortization of acquisition-related intangibles; restructuring and impairment charges; executive severance; Sinovel litigation costs; consumption of zero cost-basis inventory;
non-cash interest expense; change in fair value of derivative liability and warrants and other unusual charges; net of any tax effects related to these items. The company believes non-GAAP net income (loss) assists management and investors in
comparing the company’s performance across reporting periods on a consistent basis by excluding these non-cash or non-recurring charges that it does not believe are indicative of its core operating performance. The company also regards non-GAAP
net income (loss) as a useful measure of operating performance and cash flow to complement operating income, net income (loss) and other GAAP financial performance measures. In addition, the company uses non-GAAP net (loss) income as a factor in
evaluating management’s performance when determining incentive compensation and to evaluate the effectiveness of its business strategies.

[0001193125-13-048784:8k_2_02:47]
| AMSC Reports Q3 Results |  | Page 8 |

[0001193125-13-048784:8k_2_02:48]
Generally, a non-GAAP financial measure is a numerical measure of a company’s performance, financial position or
cash flow that either excludes or includes amounts that are not normally excluded or included in the most directly comparable measure calculated and presented in accordance with GAAP. The non-GAAP measures included in this release, however, should
be considered in addition to, and not as a substitute for or superior to, operating income, cash flows, or other measures of financial performance prepared in accordance with GAAP. A reconciliation of non-GAAP to GAAP net income is set forth in the
table above.

[0001193125-13-048784:8k_2_02:49]
AMSC Contact:

[0001193125-13-048784:8k_2_02:50]
Kerry Farrell

[0001193125-13-048784:8k_2_02:51]
Phone: 978-842-3247

[0001193125-13-048784:8k_2_02:52]
Email: kerry.farrell@amsc.com
