# AMSC notes — 0001193125-13-048834


## amsc:PrepaidAndOtherCurrentAssetsDisclosureTextBlock

[0001193125-13-048834:notes:1]
[same as prior period, unchanged from 0001193125-12-454266:notes:1]

[0001193125-13-048834:notes:2]
[same as prior period, unchanged from 0001193125-12-454266:notes:2]

[0001193125-13-048834:notes:3]
|  |  | December 31, |  |  | March 31, |
|  |  | 2012 |  |  | 2012 |
| Non-Trade receivables | $ | 495 |  |  | 3,922 |
| Prepaid expenses |  | 2,809 |  |  | 4,707 |
| Prepaid VAT and other taxes |  | 18,613 |  |  | 18,273 |
| Notes receivable |  | 4,765 |  |  | 4,526 |
| Other current assets |  | 53 |  |  | 16 |
| Total | $ | 26,735 |  | $ | 31,444 |


## amsc:ScheduleOfBusinessSegmentAssetsTextBlock

[0001193125-13-048834:notes:4]
|  |  | December 31, |  |  | March 31, |
|  |  | 2012 |  |  | 2012 |
| Wind | $ | 69,221 |  | $ | 70,054 |
| Grid |  | 72,714 |  |  | 89,091 |
| Corporate assets |  | 83,384 |  |  | 95,911 |
| Total | $ | 225,319 |  | $ | 255,056 |


## amsc:ScheduleOfBusinessSegmentOperatingResultsTextBlock

[0001193125-13-048834:notes:5]
|  |  | Three months ended |  |  | Nine months ended |
|  |  | December 31, |  |  | December 31, |
|  |  | 2012 |  | 2011 |  |  | 2012 |  | 2011 |
| Revenues: |  |  |  |  |  |  |  |  |  |
| Wind | $ | 6,808 | $ | 10,125 |  | $ | 35,321 | $ | 27,836 |
| Grid |  | 10,609 |  | 7,933 |  |  | 31,679 |  | 20,080 |
| Total | $ | 17,417 | $ | 18,058 |  | $ | 67,000 | $ | 47,916 |

[0001193125-13-048834:notes:6]
|  |  | Three months ended |  |  | Nine months ended |
|  |  | December 31, |  |  | December 31, |
|  |  | 2012 |  | 2011 |  |  | 2012 |  | 2011 |
| Operating (loss) income: |  |  |  |  |  |  |  |  |  |
| Wind | $ | (5,365) | $ | (14,014) |  | $ | (10,514) | $ | (54,719) |
| Grid |  | (6,705) |  | (6,313) |  |  | (18,620) |  | (24,511) |
| Unallocated corporate expenses |  | (8,546) |  | (6,242) |  |  | (12,580) |  | (36,790) |
| Total | $ | (20,616) | $ | (26,569) |  | $ | (41,714) | $ | (116,020) |


## amsc:ScheduleOfLiabilitiesMeasuredAtFairValueTableTextBlock

[0001193125-13-048834:notes:7]
|  |  | Derivative |  |  |  |
|  |  | Liability |  |  | Warrants |
| April 1, 2012 | $ | - |  | $ | - |
| Valuation of original derivative liability |  | 3,779 |  |  | - |
| Warrant issuance with Senior Convertible Note |  | - |  |  | 7,018 |
| Warrant issuance with Senior Secured Term Loan |  | - |  |  | 380 |
| Valuation of derivative liability attributable to modification |  | 542 |  |  | - |
| Mark to market adjustment |  | (3,297) |  |  | (2,817) |
| Balance at December 31, 2012 | $ | 1,024 |  | $ | 4,581 |


## us-gaap:AccountsPayableAndAccruedLiabilitiesDisclosureTextBlock

[0001193125-13-048834:notes:8]
[same as prior period, unchanged from 0001193125-12-454266:notes:8]

[0001193125-13-048834:notes:9]
[same as prior period, unchanged from 0001193125-12-454266:notes:9]

[0001193125-13-048834:notes:10]
|  |  | December 31, |  |  | March 31, |
|  |  | 2012 |  |  | 2012 |
| Accounts payable | $ | 7,207 |  | $ | 8,191 |
| Accrued inventories in-transit |  | 2,712 |  |  | 3,330 |
| Accrued miscellaneous expenses |  | 8,494 |  |  | 9,595 |
| Accrued outside services |  | 1,649 |  |  | 113 |
| Accrued subcontractor program costs |  | 1,924 |  |  | 1,885 |
| Accrued compensation |  | 4,208 |  |  | 8,380 |
| Income taxes payable |  | 108 |  |  | 192 |
| Accrued warranty |  | 4,018 |  |  | 5,896 |
| Total | $ | 30,320 |  | $ | 37,582 |

[0001193125-13-048834:notes:11]
[same as prior period, unchanged from 0001193125-12-454266:notes:11]

[0001193125-13-048834:notes:12]
The Company generally provides a one to three year warranty on its products, commencing upon installation. A provision is recorded upon revenue recognition to cost of revenues for estimated warranty expense based on historical experience.

[0001193125-13-048834:notes:13]
[same as prior period, unchanged from 0001193125-12-454266:notes:13]

[0001193125-13-048834:notes:14]
|  |  | Three months ended |  |  | Nine months ended |
|  |  | December 31, |  |  | December 31, |
|  |  | 2012 |  | 2011 |  |  | 2012 |  | 2011 |
| Balance at beginning of period | $ | 4,792 | $ | 7,055 |  | $ | 5,896 | $ | 7,907 |
| Change in accruals for warranties during the period |  | (627) |  | (300) |  |  | (1,178) |  | (774) |
| Settlements during the period |  | (147) |  | (482) |  |  | (700) |  | (860) |
| Balance at end of period | $ | 4,018 | $ | 6,273 |  | $ | 4,018 | $ | 6,273 |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001193125-13-048834:notes:15]
13.  Commitments and Contingencies

[0001193125-13-048834:notes:16]
Commitments

[0001193125-13-048834:notes:17]
Purchase Commitments

[0001193125-13-048834:notes:18]
The Company periodically enters into non-cancelable purchase contracts in order to ensure the availability of materials to support production of its products. Purchase commitments represent enforceable and legally binding agreements with suppliers to purchase goods or services. The Company periodically assesses the need to provide for impairment on these purchase contracts and record a loss on purchase commitments when required.  As of December 31, 2012, the Company recorded a liability for adverse purchase commitments of $1.8 million. During the three and nine months ended December 31, 2012, the Company reduced its accrual for adverse purchase commitments by $10.3 million and $24.1 million, respectively due to settlements with and payments to certain vendors.

[0001193125-13-048834:notes:19]
On May 16, 2012, the Company entered into an agreement with one of its vendors to settle certain of its adverse purchase commitments.  The agreement was amended on November 6, 2012 (as amended, the “Settlement Agreement”).  In conjunction with the Settlement Agreement, the Company agreed to pay the vendor approximately €2.2 million (the “Settlement Amount”). Under the Settlement Agreement, the Company had the option, at its sole discretion, to pay the settlement amount in cash, shares of the Company’s common stock, or a combination of cash and common stock.  Accordingly, during the three months ended December 31, 2012, the Company issued 765,301 shares of common stock to the vendor and filed a registration statement on Form S-3 to register the vendor’s resale of such shares of common stock.  If the net proceeds from the vendor’s resale of the shares of common stock during a specified period plus any other cash payments made by the Company subsequent to the date of the Settlement Agreement were less than the Settlement Amount, the Company agreed to make an additional payment equal to the shortfall in cash to the vendor no later than December 31, 2012.  As of December 31, 2012 the Company made a payment of $0.8 million as a result of such a shortfall. As security for the Company’s obligations under the Settlement Agreement, the Company provided the vendor with a letter of credit in the amount of approximately €2.2 million with an expiration of December 31, 2012. The letter of credit is secured with cash collateral of approximately $3.0 million, and is included in the Company’s restricted cash balance as of December 31, 2012. As of December 31, 2012, the Company had not been formally released from the letter of credit. The Company received that release in January 2013.

[0001193125-13-048834:notes:20]
During the fourth quarter of the year ended March 31, 2012, several vendors notified the Company that they had suffered losses as a result of procuring safety stock in anticipation of receiving future purchase orders or contracts from the Company.  Subsequently three vendors filed lawsuits through the Chinese legal system seeking payment for inventories held to be delivered under purchase orders and safety stock. One of these lawsuits has been settled and dismissed. The Company has accrued outstanding adverse purchase commitments based on legally binding contracts and purchase orders that were placed with its vendors for parts with no future demand.  The vendor claims for safety stock were not supported by valid purchase orders or valid executed contracts and are not considered part of the adverse purchase commitment liability. The claims for safety stock have not been accrued as of December 31, 2012.  The Company has determined that, although it believes that there is no legally enforceable contract for safety stock and will continue to defend its legal position that it does not owe amounts for safety stock, it is reasonably possible that a case may be made against the Company under certain situations. As the loss is reasonably possible but not probable, the Company has not accounted for the loss.  The Company has determined that the range for this potential loss is between $0 and $2 million.

[0001193125-13-048834:notes:21]
Contingencies

[0001193125-13-048834:notes:22]
From time to time, the Company is involved in legal and administrative proceedings and claims of various types.  The Company records a liability in its consolidated financial statements for these matters when a loss is known or considered probable and the amount can be reasonably estimated. The Company reviews these estimates each accounting period as additional information is known and adjusts the loss provision when appropriate. If a matter is both probable to result in a liability and the amounts of loss can be reasonably estimated, the Company estimates and discloses the possible loss or range of loss. If the loss is not probable or cannot be reasonably estimated, a liability is not recorded in its consolidated financial statements.

[0001193125-13-048834:notes:23]
Between April 6, 2011 and May 12, 2011, seven putative securities class action complaints were filed against the Company and two of its officers in the United States District Court for the District of Massachusetts; one complaint additionally asserted claims against the underwriters who participated in our November 12, 2010 securities offering.  On June 7, 2011, the United States District Court for the District of Massachusetts consolidated these actions under the caption Lenartz v. American Superconductor Corporation, et al., Docket No. 1:11-cv-10582-WGY.  On August 31, 2011, Lead Plaintiff, the Plumbers and Pipefitters National Pension Fund, filed a consolidated amended complaint against the Company, its officers and directors, and the underwriters who participated in our November 12, 2010 securities offering, asserting claims under sections 10(b) and 20(a) of the Securities Exchange Act of 1934 and Rule 10b-5 promulgated under the Securities Exchange Act of 1934 (the “Exchange Act”), as well as under sections 11, 12(a)(2) and 15 of the Securities Act of 1933 (the “Securities Act”).  The complaint alleges that during the relevant class period, the Company and its officers omitted to state material facts and made materially false and misleading statements relating to, among other things, its projected and recognized revenues and earnings, as well as its relationship with Sinovel Wind Group Co., Ltd. that artificially inflated the value of the Company’s stock price.  The complaint further alleges that the Company’s November 12, 2010 securities offering contained untrue statements of material facts and omitted to state material facts required to be stated therein.  The plaintiffs seek unspecified damages, rescindment of the Company’s November 12, 2010 securities offering, and an award of costs and expenses, including attorney’s fees.  All defendants moved to dismiss the consolidated amended complaint.  On December 16, 2011, the district court issued a summary order declining to dismiss the Securities Act claims against the Company and its officers, and taking under advisement the motion to dismiss the Exchange Act claims against the Company and its officers and the motion to dismiss the Securities Act claims made against the underwriters. On July 26, 2012, the district court dismissed the Exchange Act claims against the Company and its officers and denied the motion to dismiss the Securities Act claims made against the underwriters.

[0001193125-13-048834:notes:24]
Between May 4, 2011 and June 17, 2011, four putative shareholder derivative complaints were filed against the Company (as a nominal defendant) and certain of its directors in the United States District Court for the District of Massachusetts.  On July 5, 2011, the District Court consolidated three of these actions, and that matter is now captioned In re American Superconductor Corporation Derivative Litigation, Docket No. 1:11-cv-10784-WGY.  On June 1, 2011, the plaintiff in the fourth action, Marlborough Family Revocable Trust v. Yurek, et al., moved to voluntarily dismiss its complaint and refiled its complaint in Superior Court for the Commonwealth of Massachusetts, Middlesex County.  On September 7, 2011, the Marlborough action and another putative shareholder derivative complaint filed in Superior Court for the Commonwealth of Massachusetts were consolidated.  That consolidated matter is captioned In re American Superconductor Corporation Shareholder Derivative Litigation, Docket No. 11-1961.  On January 12, 2012, an additional shareholder derivative complaint was filed in the Court of Chancery for the State of Delaware.  That matter is captioned Krasnoff v. Budhraja, et al., Docket No. 7171.  The allegations of the derivative complaints mirror the allegations made in the putative class action complaints described above.  The plaintiffs purport to assert claims against the director defendants for breach of fiduciary duty, abuse of control, gross mismanagement, unjust enrichment and corporate waste.  The plaintiffs seek unspecified damages on behalf of the Company, as well as an award of costs and expenses, including attorney’s fees.

[0001193125-13-048834:notes:25]
With respect to the above referenced litigation matters, an estimate of loss or range of loss cannot be made. There are numerous factors that make it difficult to meaningfully estimate possible loss or range of loss at this stage of these litigation matters, including that: the proceedings are in relatively early stages, there are significant factual and legal issues to be resolved, information obtained or rulings made during the lawsuits could affect the methodology for calculation of rescission and the related statutory interest rate. In addition, with respect to claims where damages are the requested relief, no amount of loss or damages has been specified. Therefore, the Company is unable at this time to estimate possible losses.  The Company believes that these litigations are without merit, and it intends to defend these actions vigorously. Therefore no adjustment has been made to the financial statements to reflect the outcome of these uncertainties.

[0001193125-13-048834:notes:26]
On September 13, 2011, the Company commenced a series of legal actions in China against Sinovel Wind Group Co. Ltd. (“Sinovel”).  The Company’s Chinese subsidiary, Suzhou AMSC Superconductor Co. Ltd., filed a claim for arbitration with the Beijing Arbitration Commission in accordance with the terms of the Company’s supply contracts with Sinovel.  The case is captioned (2011) Jin Zhong An Zi No. 0963. On March 31, 2011, Sinovel refused to accept contracted shipments of 1.5 megawatt (MW) and 3 MW wind turbine core electrical components and spare parts that the Company was prepared to deliver. The Company alleges that these actions constitute material breaches of its contracts because Sinovel did not give it notice that it intended to delay deliveries as required under the contracts. Moreover, the Company alleges that Sinovel has refused to pay past due amounts for prior shipments of core electrical components and spare parts. The Company is seeking compensation for past product shipments and retention (including interest) in the amount of approximately RMB 485 million ($76 million) due to Sinovel’s breaches of its contracts. The Company is also seeking specific performance of our existing contracts as well as reimbursement of all costs and reasonable expenses with respect to the arbitration. The value of the undelivered components under the existing contracts, including the deliveries refused by Sinovel in March 2011, amounts to approximately RMB 4.6 billion ($720 million).

[0001193125-13-048834:notes:27]
On October 8, 2011, Sinovel filed with the Beijing Arbitration Commission an application under the caption (2011) Jing Zhong An Zi No. 0963, for a counterclaim against the Company for breach of the same contracts under which the Company filed its original arbitration claim.  Sinovel claimed, among other things, that the goods supplied by the Company do not conform to the standards specified in the contracts and claimed damages in the amount of approximately RMB 370 million ($58 million).  On October 17, 2011, Sinovel filed with the Beijing Arbitration Commission a request for change of counterclaim to increase its damage claim to approximately RMB 1 billion ($157 million).  On December 22, 2011, Sinovel filed with the Beijing Arbitration Commission an additional request for change of counterclaim to increase its damages claim to approximately RMB 1.2 billion ($190 million). On February 27, 2012, Sinovel filed with the Beijing Arbitration Commission an application under the caption (2012) Jing Zhong An Zi No. 0157, against the Company for breach of the same contracts under which the Company filed its original arbitration claim.  Sinovel claimed, among other things, that the goods supplied by the Company do not conform to the standards specified in the contracts and claimed damages in the amount of approximately RMB 105 million ($17 million). The Company believes that Sinovel’s claims are without merit and it intends to defend these actions vigorously. Since the proceedings in this matter are in relatively early stages, the Company cannot reasonably estimate possible losses or range of losses at this time.

[0001193125-13-048834:notes:28]
The Company also submitted a civil action application to the Beijing No. 1 Intermediate People’s Court under the caption (2011) Yi Zhong Min Chu Zi No. 15524, against Sinovel for software copyright infringement on September 13, 2011.  The application alleges Sinovel’s unauthorized use of portions of the Company’s wind turbine control software source code developed for Sinovel’s 1.5MW wind turbines and the binary code, or upper layer, of the Company’s software for the PM3000 power converters in 1.5MW wind turbines. In July 2011, a former employee of the Company’s Austrian subsidiary was arrested in Austria on charges of economic espionage and fraudulent manipulation of data. In September 2011, the former employee pled guilty to the charges, and was imprisoned.  As a result of the Company’s internal investigation and a criminal investigation conducted by Austrian authorities, the Company believes that this former employee was contracted by Sinovel through an intermediary while employed by the Company and improperly obtained and transferred to Sinovel portions of its wind turbine control software source code developed for Sinovel’s 1.5MW wind turbines. Moreover, the Company believes the former employee illegally used source code to develop for Sinovel a software modification to circumvent the encryption and remove technical protection measures on the Company’s PM3000 power converters in 1.5MW wind turbines in the field.  The Company is seeking a cease and desist order with respect to the unauthorized copying, installation and use of its software, monetary damages of approximately RMB 38 million ($6 million) for our economic losses and reimbursement of all costs and reasonable expenses.  The No. 1 Intermediate People’s Court accepted the case, which was necessary in order for the case to proceed.  In November 2011, Sinovel filed a motion to remove this case from the Beijing No. 1 Intermediate People’s Court and transfer the matter to the Beijing Arbitration Commission.  On February 14, 2012, the court denied Sinovel’s motion to remove the case.  On February 21, 2012, Sinovel filed an appeal of the Beijing No. 1 Intermediate People’s Court decision to the Beijing Higher People’s Court.  On April 25, 2012, the Beijing Higher People’s Court issued a final Civil Ruling which supports the Beijing No.1 Intermediate People’s Court’s civil ruling and rejected Sinovel’s appeal. Sinovel filed an appeal of the Beijing Higher People’s Court’s decision with China’s Supreme People’s Court. A hearing regarding this appeal was held at the Chinese Supreme People’s Court on October 26, 2012. On November 23, 2012, the China’s Supreme People’s Court issued a Civil Ruling, holding that (1) it will conduct a re-trial of Sinovel’s appeal, and (2) the lower court’s decision will be stayed pending the retrial.

[0001193125-13-048834:notes:29]
Sinovel filed a new motion on June 18, 2012, to remove this case from the Beijing No. 1 Intermediate People’s Court to the court located in Gansu Province. On October 19, 2012, the Court disallowed Sinovel’s motion due to its late filing.

[0001193125-13-048834:notes:30]
The Company submitted a civil action application to the Beijing Higher People’s Court against Sinovel and certain of its employees for trade secret infringement on September 13, 2011 under the caption (2011) Gao Min Chu Zi No. 4193.  The application alleges the defendants’ unauthorized use of portions of the Company’s wind turbine control software source code developed for Sinovel’s 1.5MW wind turbines as described above with respect to the Copyright Action. The Company is seeking monetary damages of RMB 2.9 billion ($453 million) for the trade secret infringement as well as reimbursement of all costs and reasonable expenses.  The Beijing Higher People’s Court accepted the case, which was necessary in order for the case to proceed.  On December 22, 2011, the Beijing Higher People’s Court transferred this case to the Beijing No. 1 Intermediate People’s Court under the caption (2011) Gao Min Chu Zi No. 4193. On June 7, 2012, the Company received an Acceptance Notice from the Beijing No.1 Intermediate People’s Court under the caption (2012) Yi Zhong Min Chu Zi No.6833. The Company is currently awaiting notice from the Beijing No. 1 Intermediate People’s Court regarding the first hearing date. In August 2012, Sinovel filed a motion to remove this case from the Beijing No. 1 Intermediate People’s Court and transfer the matter to the Beijing Arbitration Commission.

[0001193125-13-048834:notes:31]
On September 16, 2011, the Company filed a civil copyright infringement complaint in the Hainan Province No. 1 Intermediate People’s Court against Dalian Guotong Electric Co. Ltd. (“Guotong”), a supplier of power converter products to Sinovel, and Huaneng Hainan Power, Inc. (“Huaneng”), a wind farm operator that has purchased Sinovel wind turbines containing Guotong power converter products.  The case is captioned (2011)  Hainan Yi Zhong Min Chu Zi No. 62.  The application alleges that the Company’s PM1000 converters in certain Sinovel wind turbines have been replaced by converters produced by Guotong. Because the Guotong converters are being used in wind turbines containing the Company’s wind turbine control software, the Company believes that its copyrighted software is being infringed.  The Company is seeking a cease and desist order with respect to the unauthorized use of its software, monetary damages of RMB 1.2 million ($0.2 million) for its economic losses (with respect to Guotong only) and reimbursement of all costs and reasonable expenses.  The court has accepted the case, which was necessary in order for the case to proceed.  In addition, upon the request of the defendant Huaneng, Sinovel has been added by the court to this case as a defendant and Huaneng has been released from this case.  In December 2011, Sinovel filed a jurisdiction opposition motion requesting dismissal by the Hainan Province No. 1 Intermediate People’s Court, saying the case should be governed by the Beijing Arbitration Commission. On February 3, 2012, the Company received the Civil Ruling from the court, which granted Sinovel’s motion, and dismissed the entire case. The Company appealed the court’s ruling to the Hainan Higher Court, which on April 5, 2012 upheld the decision of the Hainan Province No. 1 Intermediate People’s Court.  On April 9, 2012, the Company filed an appeal of the Hainan Higher Court’s decision with China’s Supreme People’s Court. The Supreme Court accepted the appeal on May 23, 2012. The case is captioned, (2012) Min Shen Zi No. 630. On December 20, 2012, the China’s Supreme People’s Court issued a Civil ruling, holding that (1) it will conduct a re-trial of the Company’s appeal and (2) the lower court’s decision will be stayed pending the re-trial.

[0001193125-13-048834:notes:32]
Ghodawat Energy Pvt Ltd (“Ghodawat”), a company registered in India carrying on the business of wind power development, lodged a Request for Arbitration with the Secretariat of the ICC International Court of Arbitration on May 12, 2011 and named AMSC Windtec GmbH (“AMSC Austria”) as the Respondent.  Under the Request for Arbitration, Ghodawat alleges that AMSC Austria breached an agreement dated March 19, 2008 pursuant to which AMSC Austria granted a license to Ghodawat to manufacture, use, sell, market, erect, commission and maintain certain wind turbines using its technical information and wind turbine design (the “License Agreement”).  Under the Request for Arbitration, Ghodawat’s claims in this arbitration amount to approximately €18 million ($24 million).  AMSC Austria filed an Answer to Request for Arbitration and Counterclaim (“Answer and Counterclaim”), in which AMSC Austria denied Ghodawat’s claims in their entirety.  AMSC Austria has also submitted counterclaims under the License Agreement against Ghodawat in the amount of approximately €6 million ($9 million).  Ghodawat has filed a Reply to Answer to Request for Arbitration and Counterclaim in which it denies AMSC Austria’s counterclaims.  The arbitration proceedings are currently ongoing.  The Company has recorded a loss contingency based on its assessment of probable losses on this claim; however this amount is immaterial to its consolidated financial statements.

[0001193125-13-048834:notes:33]
Other

[0001193125-13-048834:notes:34]
The Company enters into long-term construction contracts with customers that require the Company to obtain performance bonds. The Company is required to deposit an amount equivalent to some or all the face amount of the performance bonds into an escrow account until the termination of the bond. When the performance conditions are met, amounts deposited as collateral for the performance bonds are returned to the Company. In addition, the Company has various contractual arrangements in which minimum quantities of goods or services have been committed to be purchased on an annual basis.

[0001193125-13-048834:notes:35]
At December 31, 2012, the Company had $9.2 million of restricted cash included in current assets, and $4.8 million of restricted cash included in long-term assets. These amounts included in restricted cash represent deposits to secure letters of credit for various supply contracts, including those deemed as adverse purchase commitments, and are held in interest bearing accounts.  The Company is working with its inventory suppliers to delay cash settlements and to reduce the gross liability associated with its adverse purchase commitments, which is approximately $1.8 million as of December 31, 2012. During the three and nine months ended December 31, 2012, the Company agreed to settle adverse purchase commitments with certain of its vendors. In conjunction with certain of these settlements, the Company agreed tp provide letters of credit and bank guarantees in the amount of approximately $9.0 million with expirations through January 31, 2013. The letters of credit and bank guarantees were secured with cash collateral of approximately $8.5 million and were included in the Company’s restricted cash balance as of December 31, 2012. As of January 2013, these letters of credit had been cancelled and the cash collateral has been returned to unrestricted cash.


## us-gaap:DebtDisclosureTextBlock

[0001193125-13-048834:notes:36]
11.  Debt

[0001193125-13-048834:notes:37]
Senior Convertible Notes

[0001193125-13-048834:notes:38]
On April 4, 2012, the Company entered into a Securities Purchase Agreement with Capital Ventures International (“CVI”), an affiliate of Heights Capital Management (the “Purchase Agreement”) and completed a private placement of $25.0 million aggregate principal amount of  a 7%  unsecured senior convertible note (the “Initial Note”). After fees and expenses, the net proceeds were $23.2 million.  The Initial Note had an initial conversion price of $4.85 per share, representing a premium of approximately 20% over AMSC’s closing price on April 3, 2012. The Initial Note was payable in monthly installments beginning four months from issuance and ending on October 4, 2014.  Monthly payments were payable in cash or the Company’s common stock at the option of the Company, subject to certain trading volume, stock price and other conditions. CVI could have also elected to defer receipt of monthly installment payments at its option. Any deferred installment payments would have continued to accrue interest. The Company registered 10,262,311 shares of common stock which may be used as payment for principal and interest in lieu of cash for resale under the Securities Act as required under a Registration Rights Agreement with CVI.

[0001193125-13-048834:notes:39]
The Company accounted for the Initial Note as an instrument that has the characteristics of a debt host contract containing several embedded derivative features that would require bifurcation and separate accounting as a derivative instrument pursuant to the provisions of ASC 815. The Company elected not to use the fair value option for the aggregate amount of the Exchanged Note and recorded the liability at its stated value on the date of issuance with no changes in fair value reported in subsequent periods.

[0001193125-13-048834:notes:40]
The Company has identified the following derivatives associated with the Initial Note: holder change of control redemption rights; issuer optional redemption rights; sale redemption rights and a feature to convert the Initial Note into equity at the holder’s option.  The Company valued these derivatives at $3.8 million upon issuance of the Initial Note. See Note 12, “Warrants and Derivative Liabilities”, for additional information regarding derivative liabilities.

[0001193125-13-048834:notes:41]
In conjunction with the Initial Note, CVI received a warrant to purchase approximately 3.1 million additional shares of common stock exercisable at a strike price of $5.45 per share, subject to adjustment, until October 4, 2017. Due to certain adjustment provisions within the warrant, it qualified for liability accounting and had a fair value of $7.0 million upon issuance. The Company recorded the value as a debt discount and a warrant liability. See Note 12, “Warrants and Derivative Liabilities”, for additional information regarding the warrant.

[0001193125-13-048834:notes:42]
The process of valuing financial and derivative instruments utilizes facts and circumstances as of the measurement date as well as certain inputs, assumptions, and judgments that may affect the estimated fair value of the instruments. Upon issuance of the Initial Note, the Company determined the initial carrying value of the Initial Note to be $25.0 million. In addition, the Company also incurred $1.8 million of legal and origination costs as of the nine months ended December 31, 2012, which have been recorded as a discount on the Initial Note.

[0001193125-13-048834:notes:43]
On December 20, 2012, the Company entered into an Amendment and Exchange Agreement, (the “Amendment”) with CVI, which amended the Purchase Agreement. Pursuant to the Amendment, the Company and CVI exchanged the Initial Note for a new unsecured, senior convertible note, (the “Exchanged Note”). At the time of the exchange, the Exchanged Note had the same principal amount and accrued interest as the Initial Notes. The Exchanged Note is convertible into the Company’s common stock and has the same scheduled monthly installment payments as the Initial Note. The Exchanged Note provides the Company with additional flexibility to make monthly installment payments in shares of the Company’s common stock. The Company retains the ability to repay the Exchanged Note in cash. Specifically, the amendments to the Exchanged Note:

[0001193125-13-048834:notes:44]
| · | Allow the Company to convert, subject to the satisfaction of certain conditions set forth in the Exchanged Note, |

[0001193125-13-048834:notes:45]
(a) at least $2.5 million of the approximately $5.3 million installment amount payable with respect to the January 2013 installment date (including approximately $4.2 million of deferred installment amounts from the period September 4, 2012 to December 3, 2012) into shares of the Company’s common stock, (On December 21, 2012 the Company converted $3.8 million in deferred installment amount principal and interest and issued 1,715,443 shares of common stock), and (b) the balance of the January 2013 installment amount in equal amounts on each of the February and March 2013 installment dates;

[0001193125-13-048834:notes:46]
| · | Reduce the price failure equity condition with respect to a particular date of determination from $2.50 to $1.00; |

[0001193125-13-048834:notes:47]
| · | Reduce the aggregate daily dollar trading volume equity condition required for at least 25 of the 30 consecutive trading days immediately preceding a date of determination from $1,500,000 to $850,000 per trading day. In addition, if the aggregate daily dollar trading volume is between $50,000 and $850,000, the Company may still convert into common stock a portion of an installment amount payable with respect to an installment date equal to the quotient of (x) the aggregate daily dollar trading volume, divided by (y) $850,000; |

[0001193125-13-048834:notes:48]
| · | Increase CVI’s beneficial ownership limitation under the Exchanged Note from 4.99% to 9.99%; and |

[0001193125-13-048834:notes:49]
| · | Reduce the conversion price, from $4.85 per share of the Company’s common stock to $3.19 per share of the Company’s common stock, subject to certain price-based and other anti-dilution adjustments. |

[0001193125-13-048834:notes:50]
The Company assessed the changes in the Exchanged Note and accounted for it as a modification of the Initial Note. Therefore, the Company determined the incremental value of the derivative instruments as a result of the Exchanged Note having a reduced conversion price. As a result of the re-valuation, the Company recorded a $0.5 million increase in the value of the derivative liability and additional debt discount. At the modification date, the value of the derivative liability was $1.5 million. The total debt discount, including the embedded derivatives in the Initial Note,  the incremental value of embedded derivatives in the Exchanged Note, warrant and legal and origination costs of $13.1 million is being amortized into interest expense over the term of the Exchanged Note using the effective interest method. Under this method, interest expense is recognized each period until the debt instruments reach maturity.  If the maturity of the Exchanged Note is accelerated because of prepayment, then the amortization will be accelerated.  During the three and nine months ended December 31, 2012, the Company recorded non-cash interest expense for amortization of the debt discount related to the convertible notes of $2.2 million and $6.4 million, respectively.

[0001193125-13-048834:notes:51]
Provided certain equity conditions are met, the Company may elect to repay principal and interest in shares of the Company’s common stock. If the Company elects to make a payment in shares of the Company’s common stock, the number of shares to be issued is determined by dividing the amount of such payment by 85% of the lessor of the average volume-weighted average price (“VWAP”) of the 10 consecutive days immediately preceding the payment date or the VWAP price on the day preceding the payment date (the “Market Price”). On December 20, 2012 the Company paid approximately $3.8 million in principal and interest by issuing 1,715,443 shares of the Company’s common stock. The Company records the difference between the closing price of its common stock on the day preceding the payment date and the Market Price as a discount on the fair value of its shares. During the three and nine months ended December 31, 2012, the Company recorded $1.5 million of non-cash interest expense related to installment payments made by issuing the Company’s common stock at a discount.

[0001193125-13-048834:notes:52]
The Exchanged Note and Purchase Agreement contains certain covenants and restrictions, including, among others, that for so long as the Exchanged Note is outstanding, the Company will not incur any indebtedness (other than permitted indebtedness under the Exchanged Note), permit liens on its properties (other than permitted liens under the Exchanged Note), make payments on junior securities or declare dividends.  The Exchanged Note also contains limitations on the transfer of certain assets.  Events of default under the Exchanged Note include failure to pay principal or interest as due on the Exchanged Note, failure to deliver registered shares of common stock upon the holders request for conversion of part or all of the Exchanged Note, failure to maintain the Company's common stock eligible for trading on defined markets, cross defaults to other material indebtedness, receipt of uninsured judgments against the Company in excess of defined limits and other administrative covenants, including the Term Loan discussed below, as defined in the Exchanged Note and related documentation. Upon an event of default, the holders may require the Company to redeem all or any portion of the outstanding principal amount of the Exchanged Note in cash plus a penalty as specified in the agreement.  Also, if the Company fails to maintain an effective registration statement covering common stock to be used in settling obligations under the Exchanged Note, the Company will be required to pay a penalty as specified in the agreement.

[0001193125-13-048834:notes:53]
In addition, on October 4, 2012, the Company had the right to issue an additional $15 million aggregate principal amount of convertible notes and warrant to the same investor, subject to certain conditions.   Because the Company did not meet these conditions, it no longer has the right to compel the investor to purchase additional convertible notes on the terms contained in the agreement.

[0001193125-13-048834:notes:54]
Senior Secured Term Loan

[0001193125-13-048834:notes:55]
On June 5, 2012, the Company entered into a Term Loan with Hercules Technology Growth Capital, Inc. (“Hercules”), under which the Company borrowed $10.0 million (the “Term Loan”). After the closing fees and expenses, the net proceeds to the Company were $9.7 million. The Term Loan bears an interest rate equal to 11% plus the percentage, if any, by which the prime rate as reported by The Wall Street Journal exceeds 3.75%.  The Company made interest-only payments from July 1, 2012 through October 31, 2012, after which the Company repays the loan in equal monthly installments ending on December 1, 2014. The Term Loan is secured by substantially all of the Company’s existing and future assets, including a mortgage on real property owned by the Company’s wholly-owned subsidiary, ASC Devens LLC, and located at 64 Jackson Road, Devens, Massachusetts. In addition, Hercules received a warrant to purchase 139,276 shares of common stock, exercisable at an initial strike price of $3.59 per share, subject to adjustment, until December 5, 2017.  Due to certain adjustment provisions within the warrant, it qualified for liability accounting and the fair value of $0.4 million was recorded upon issuance, which the Company recorded as a debt discount and a warrant liability. See Note 12, “Warrants and Derivative Liabilities”, for a discussion on warrants and the valuation assumptions used.  The Company will pay an end of term fee of $0.5 million upon the earlier of maturity or prepayment of the loan.  The Company has accrued this as of the nine months ended December  31, 2012 and recorded a corresponding amount into the debt discount.   In addition, the Company incurred $0.3 million of legal and origination costs in the nine months ended December 31, 2012, which have been recorded as a debt discount. The total debt discount including the warrant, end of term fee and legal and origination costs of $1.2 million is being amortized into interest expense over the term of the Term Loan using the effective interest method. Under this method, interest expense is recognized each period until the debt instrument reaches maturity. If the maturity of the Term Loan is accelerated because of prepayment, then the amortization will be accelerated.  During the three and nine months ended December 31, 2012, the Company recorded non-cash interest expense for amortization of the debt discount related to the Term Loan of $0.2 million and $0.5 million, respectively.

[0001193125-13-048834:notes:56]
The Term Loan contains certain covenants that restrict the Company’s ability to, among other things, incur or assume certain debt, merge or consolidate, materially change the nature of our business, make certain investments, acquire or dispose of certain assets, make guaranties or grant liens on its assets, make certain loans, advances or investments, declare dividends or make distributions or enter into transactions with affiliates. In addition, the Term Loan contains a covenant that requires the Company to maintain a minimum unrestricted cash balance in the United States of at least $10.0 million at the inception of the Term Loan, which decreased starting November 1, 2012 and monthly thereafter by the amount of principal paid.  The events of default under the Term Loan include, but are not limited to, failure to pay amounts due, breaches of covenants, bankruptcy events, cross defaults under other material indebtedness and the occurrence of a material adverse effect and/or change in control. In the case of a continuing event of default, the Lender may, among other remedies, declare due all unpaid principal amounts outstanding and any accrued but unpaid interest and foreclose on all collateral granted to the Lender as security under the Term Loan.

[0001193125-13-048834:notes:57]
Although the Company believes it is in and expects to remain in compliance with the covenants and restrictions under the Exchanged Notes and Term Loan as of the date of this Quarterly Report on Form 10-Q, and expects to remain in compliance there can be no assurance that the Company will continue to be in compliance.

[0001193125-13-048834:notes:58]
Interest expense on the convertible notes and Term Loan for the three and nine months ended December 31, 2012 was $4.6 million and $10.3 million respectively, which included $3.9 million and $8.4 million of non-cash interest expense related to the amortization of the debt discount on the Exchanged Note and Term Loan and payment of the Exchanged Notes in Company common stock at a discount, respectively.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001193125-13-048834:notes:59]
12.  Warrants and Derivative Liabilities

[0001193125-13-048834:notes:60]
On April 4, 2012, the Company entered into a Purchase Agreement for the Initial Note and on December 20, 2012, the Company entered into the Amendment pursuant to which it exchanged the Initial Note and exchanged the Initial Note for the Exchanged Note, as described in Note 11. The Initial Note included a warrant to purchase 3.1 million shares of the Company’s common stock. The warrant is exercisable at any time on or after the date that is six months after the issuance of the warrant and entitles CVI to purchase shares of the Company’s common stock for a period of five years from the initial date the warrant becomes exercisable at a price equal to $5.45 per share, subject to certain price-based and other anti-dilution adjustments. The warrant may not be exercised if, after giving effect to the conversion, CVI together with its affiliates would beneficially own in excess of 4.99% of the Company’s common stock. This percentage may be raised to any other percentage not in excess of 9.99% at the option of CVI, upon at least 61-days’ prior notice to the Company, or lowered to any other percentage, at the option of CVI, at any time.

[0001193125-13-048834:notes:61]
The Company accounts for the warrant as a liability due to certain adjustment provisions within the warrant, which requires that it be recorded at fair value.  The warrant is subject to revaluation at each balance sheet date and any change in fair value will be recorded as a change in fair value in other income (expense) until the earlier of expiration or its exercise at which time the warrant liability will be reclassified to equity. Following is a summary of the key assumptions used to calculate the fair value of the warrant:

[0001193125-13-048834:notes:62]
|  |  | December 31, |  |  | September 30, |  |  | June 30, |  |  | April 4, |  |
|  |  | 2012 |  |  | 2012 |  |  | 2012 |  |  | 2012 |  |
| Risk-free interest rate |  | 0.75 | % |  | 0.63 | % |  | 0.77 | % |  | 1.19 | % |
| Expected annual dividend yield |  | 0.0 | % |  | 0.0 | % |  | 0.0 | % |  | 0.0 | % |
| Expected volatility |  | 80.6 | % |  | 80.9 | % |  | 80.8 | % |  | 80.0 | % |
| Term (years) |  | 4.76 |  |  | 5.01 |  |  | 5.28 |  |  | 5.5 |  |
| Fair Value | $ | 4.4 million |  | $ | 7.1 million |  | $ | 8.6 million |  | $ | 7.0 million |  |

[0001193125-13-048834:notes:63]
The Company recorded a gain for the change in the fair value of the CVI warrant of $2.7 million and $2.6 million to change in fair value of derivatives and warrants in the three and nine months ended December 31, 2012, respectively.

[0001193125-13-048834:notes:64]
The Company determined certain embedded derivatives issued with the convertible notes required accounting as a liability, which requires they be accounted for as a standalone liability subject to revaluation at each balance sheet date with changes in fair value recorded as change in fair value of derivatives and warrants until the earlier of exercise or expiration.

[0001193125-13-048834:notes:65]
The terms of the debt modification reduced the conversion price of the Initial Note from $4.85 per share to $3.19 per share in the Exchanged Note. As a result the Company revalued these derivatives pre- and post-modification and recorded the difference of $0.5 million as a debt discount and a derivative liability (see Note 11, “Debt”).  The Company calculated the fair value of the derivative liabilities utilizing an integrated lattice model. The lattice model is an option pricing model that involves the construction of a binomial tree to show the different paths that the underlying asset may take over the option's life. A lattice model can take into account expected changes in various parameters such as volatility over the life of the options, providing more accurate estimates of option prices than the Black-Scholes model. Following is a summary of the key assumptions used to value the convertible notes derivative feature:

[0001193125-13-048834:notes:66]
|  |  |  |  |  | Post-modification |  |  | Pre-modification |  |  |  |  |  |  |  |  |  |  |
|  |  | December 31, |  |  | December 20, |  |  | December 20, |  |  | September 30, |  |  | June 30, |  |  | April 4, |  |
|  |  | 2012 |  |  | 2012 |  |  | 2012 |  |  | 2012 |  |  | 2012 |  |  | 2012 |  |
| Stock Price | $ | 2.62 |  | $ | 2.95 |  | $ | 2.95 |  | $ | 4.15 |  | $ | 4.68 |  | $ | 3.97 |  |
| Percentage Volume Condition Met |  | 94.5 | % |  | 94.9 | % |  | 28.6 | % |  | 51.0 | % |  | 75.2 | % |  | 85.9 | % |
| Expected Volatility |  | 73.5 | % |  | 72.5 | % |  | 72.5 | % |  | 70.0 | % |  | 71.0 | % |  | 75.0 | % |
| Risk Free Rate |  | 0.23 | % |  | 0.25 | % |  | 0.25 | % |  | 0.23 | % |  | 0.33 | % |  | 0.44 | % |
| Bond Yield |  | 16.5 | % |  | 16.5 | % |  | 16.5 | % |  | 15.0 | % |  | 16.0 | % |  | 15.0 | % |
| Recovery Rate |  | 30.0 | % |  | 30.0 | % |  | 30.0 | % |  | 30.0 | % |  | 30.0 | % |  | 30.0 | % |
| Redeemable |  | yes |  |  | yes |  |  | yes |  |  | yes |  |  | yes |  |  | yes |  |
| Total Time (years) |  | 1.76 |  |  | 1.79 |  |  | 1.79 |  |  | 2.01 |  |  | 2.28 |  |  | 2.5 |  |
| Dilution Effect |  | yes |  |  | yes |  |  | yes |  |  | yes |  |  | yes |  |  | yes |  |
| Indicated Percent of Par |  | 98.0 | % |  | 119.0 | % |  | 99.0 | % |  | 108.0 | % |  | 121.0 | % |  | 117.0 | % |
| Fair Value | $ | 1.0 million |  | $ | 1.5 million |  | $ | 0.9 million |  | $ | 2.8 million |  | $ | 4.5 million |  | $ | 3.8 million |  |

[0001193125-13-048834:notes:67]
Based on historical volume-weighted average price, (“VWAP”) of the Company’s common stock as well as the historic average dollar trading volume of the Company’s common stock, the percentage volume condition is the probability that the Company will convert monthly installment payments into the Company’s common stock. The expected volatility rate was estimated based on an equal weighting of the historical volatility of the Company’s common stock and the implied volatility of the Company’s traded options. To determine the risk-free interest rate, an interpolated rate was used based on the one, two and three-year United States Treasury rates. The bond yield was estimated using comparable corporate debt and yield information. The recovery rate of the Exchanged Note was estimated by reviewing historical corporate debt that went into default. The bond is redeemable by the Company at any point after the one-year anniversary of the grant date provided certain provisions within the note. The total time is based on the actual 30-month contractual terms. It was determined that there is a dilution effect based on the Company’s ability to make payments in shares of common stock.

[0001193125-13-048834:notes:68]
The Company recorded a gain from the change in the fair value of the derivative liabilities of $2.3 million and $3.3 million to changes in fair value of derivatives and warrants in the three and nine months ended December 31, 2012, respectively.

[0001193125-13-048834:notes:69]
On June 5, 2012, the Company entered into a Loan and Security Agreement with Hercules (see Note 11, “Debt”, for additional information regarding the Loan and Security Agreement).  In conjunction with this agreement, the Company issued a warrant to purchase 139,276 shares of the Company’s common stock. The warrant is exercisable at any time after the issuance of the warrant and expires on December 5, 2017, at a price equal to $3.59 per share subject to certain price-based and other anti-dilution adjustments.

[0001193125-13-048834:notes:70]
The Company accounts for the warrant as a liability due to certain provisions within the warrant, which requires that it be recorded at fair value.  The warrant is subject to revaluation at each balance sheet date and any change in fair value will be recorded as changes in fair value of derivatives and warrants until the earlier of expiration or its exercise at which time the warrant liability will be reclassified to equity. Following is a summary of the key assumptions used to calculate the fair value of the warrant:

[0001193125-13-048834:notes:71]
|  |  | December 31, |  |  | September 30, |  |  | June 30, |  |  | June 5, |  |
|  |  | 2012 |  |  | 2012 |  |  | 2012 |  |  | 2012 |  |
| Risk-free interest rate |  | 0.75 | % |  | 0.64 | % |  | 0.80 | % |  | 0.77 | % |
| Expected annual dividend yield |  | 0.0 | % |  | 0.0 | % |  | 0.0 | % |  | 0.0 | % |
| Expected volatility |  | 80.14 | % |  | 81.18 | % |  | 80.32 | % |  | 79.90 | % |
| Term (years) |  | 4.93 |  |  | 5.18 |  |  | 5.44 |  |  | 5.5 |  |
| Fair Value | $ | 0.2 million |  | $ | 0.4 million |  | $ | 0.5 million |  | $ | 0.4 million |  |

[0001193125-13-048834:notes:72]
The Company prepared its estimates for the assumptions used to determine the fair value of the warrants issued in conjunction with both the Convertible Note and Term Loan utilizing the respective terms of the warrants with similar inputs, as described above.

[0001193125-13-048834:notes:73]
The Company recorded a gain from the change in the fair value of the Hercules warrant of $0.2 million during the three and nine months ended December 31, 2012.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001193125-13-048834:notes:74]
[same as prior period, unchanged from 0001193125-12-454266:notes:50]

[0001193125-13-048834:notes:75]
The Company accounts for its stock-based compensation at fair value. The following table summarizes stock-based compensation expense by financial statement line item for the three and nine months ended December 31, 2012 and 2011 (in thousands):

[0001193125-13-048834:notes:76]
|  |  | Three months ended |  |  | Nine months ended |
|  |  | December 31, |  |  | December 31, |
|  |  | 2012 |  | 2011 |  |  | 2012 |  | 2011 |
| Cost of revenues | $ | 135 | $ | 138 |  | $ | 518 | $ | 908 |
| Research and development |  | 627 |  | 623 |  |  | 1,781 |  | 1,948 |
| Selling, general and administrative |  | 1,167 |  | 1,357 |  |  | 3,669 |  | 4,841 |
| Total | $ | 1,929 | $ | 2,118 |  | $ | 5,968 | $ | 7,697 |

[0001193125-13-048834:notes:77]
During the nine months ended December 31, 2012, the Company granted approximately 857,000 stock options and awarded 1,758,000 shares of restricted stock shares to employees under the 2007 Stock Incentive Plan. In addition the Company issued 158,000 restricted stock units, each of which represents the right to receive one share of common stock, in connection with a severance agreement entered into with one of our former executive officers, and issued approximately 215,000 immediately vested shares of common stock in-lieu of cash bonuses, to employees under the 2007 Stock Incentive Plan. The Company recorded the issuance of stock in-lieu of cash bonuses as a non-cash issuance of stock to settle liabilities in the unaudited consolidated condensed statement of cash flows. The options granted vest upon the passage of time, generally 3 years. For awards that vest upon the passage of time, expense is being recorded over the vesting period.

[0001193125-13-048834:notes:78]
The estimated fair value of the Company’s stock-based awards, less expected annual forfeitures, is amortized over the awards’ service period. The total unrecognized compensation cost for unvested outstanding stock options was $4.6 million as of December 31, 2012. This expense will be recognized over a weighted average expense period of approximately 1.9 years.  The total unrecognized compensation cost for unvested outstanding restricted stock was $5.5 million as of December 31, 2012. This expense will be recognized over a weighted average expense period of approximately 1.5 years.

[0001193125-13-048834:notes:79]
The weighted-average assumptions used in the Black-Scholes valuation model for stock options granted during the three and nine months ended December 31, 2012 and 2011 are as follows:

[0001193125-13-048834:notes:80]
|  | Three months ended |  |  | Nine months ended |  |
|  | December 31, |  |  | December 31, |  |
|  | 2012 |  | 2011 |  |  | 2012 |  | 2011 |  |
| Expected volatility | 72.4 | % | 79.7 | % |  | 72.0 | % | 69.7 | % |
| Risk-free interest rate | 1.0 | % | 1.1 | % |  | 0.9 | % | 1.8 | % |
| Expected life (years) | 5.9 |  | 5.9 |  |  | 5.9 |  | 5.9 |  |
| Dividend yield | None |  | None |  |  | None |  | None |  |

[0001193125-13-048834:notes:81]
[same as prior period, unchanged from 0001193125-12-454266:notes:57]


## us-gaap:EarningsPerShareTextBlock

[0001193125-13-048834:notes:82]
[same as prior period, unchanged from 0001193125-12-454266:notes:58]

[0001193125-13-048834:notes:83]
Basic net (loss) income per share (“EPS”) is computed by dividing net (loss) income by the weighted-average number of common shares outstanding for the period. Where applicable, diluted EPS is computed by dividing the net (loss) income by the weighted-average number of common shares and dilutive common equivalent shares outstanding during the period, calculated using the treasury stock method. Common equivalent shares include the effect of restricted stock, exercise of stock options and warrants, shares issuable on conversion of debt and contingently issuable shares. For both the three and nine months ended December 31, 2012, 11.8 million shares were not included in the calculation of diluted EPS as they were considered anti-dilutive, of which 2.9 million shares relate to outstanding stock options, 3.2 million shares relate to the issuance of warrants, and 5.7 million shares relate to the convertible feature of the Company’s Exchanged Note. For both the three and nine months ended December 31, 2011, 2.4 million shares of common stock underlying outstanding stock options were not included in the calculation of diluted EPS as they were considered anti-dilutive.

[0001193125-13-048834:notes:84]
The following table reconciles the numerators and denominators of the earnings per share calculation for the three and nine months ended December 31, 2012 and 2011 (in thousands, except per share data):

[0001193125-13-048834:notes:85]
|  |  | Three months ended |  |  | Nine months ended |
|  |  | December 31, |  |  | December 31, |
|  |  | 2012 |  | 2011 |  |  | 2012 |  | 2011 |
| Numerator: |  |  |  |  |  |  |  |  |  |
| Net loss | $ | (20,135) | $ | (26,271) |  | $ | (46,360) | $ | (115,660) |
| Denominator: |  |  |  |  |  |  |  |  |  |
| Weighted-average shares of common stock outstanding |  | 53,745 |  | 51,459 |  |  | 52,558 |  | 51,120 |
| Weighted-average shares subject to repurchase |  | (953) |  | (526) |  |  | (592) |  | (331) |
| Shares used in per-share calculation ― basic |  | 52,792 |  | 50,933 |  |  | 51,966 |  | 50,789 |
| Shares used in per-share calculation ― diluted |  | 52,792 |  | 50,933 |  |  | 51,966 |  | 50,789 |
| Net loss per share ― basic | $ | (0.38) | $ | (0.52) |  | $ | (0.89) | $ | (2.28) |
| Net loss per share ― diluted | $ | (0.38) | $ | (0.52) |  | $ | (0.89) | $ | (2.28) |


## us-gaap:EquityMethodInvestmentsDisclosureTextBlock

[0001193125-13-048834:notes:86]
[same as prior period, unchanged from 0001193125-12-454266:notes:62]

[0001193125-13-048834:notes:87]
[same as prior period, unchanged from 0001193125-12-454266:notes:63]

[0001193125-13-048834:notes:88]
On October 9, 2009, the Company made an investment in Tres Amigas LLC, a Delaware limited liability company (“Tres Amigas”), focused on providing the first common interconnection of America's three power grids to help the country achieve its renewable energy goals and facilitate the smooth, reliable and efficient transfer of green power from region to region, for $1.8 million, consisting of $0.8 million in cash and $1.0 million in AMSC common stock. On January 6, 2011 and May 20, 2011, the Company increased its minority position in Tres Amigas by investing an additional $1.8 million in cash on each date. As of December 31, 2012, the Company holds a 28% ownership interest in Tres Amigas.

[0001193125-13-048834:notes:89]
The Company’s investment in Tres Amigas is included in other assets on the unaudited condensed consolidated balance sheet and the equity in undistributed losses of Tres Amigas is included in other (expense) income, net, on the unaudited condensed consolidated statements of operations.

[0001193125-13-048834:notes:90]
The net investment activity for the nine months ended December 31, 2012 is as follows (in thousands):

[0001193125-13-048834:notes:91]
| Balance at April 1, 2012 | $ | 3,859 |
| Minority interest in net losses |  | (689) |
| Balance at December 31, 2012 | $ | 3,170 |

[0001193125-13-048834:notes:92]
[same as prior period, unchanged from 0001193125-12-454266:notes:68]

[0001193125-13-048834:notes:93]
On August 12, 2010, the Company acquired (through its Austrian subsidiary), a minority ownership position in Blade Dynamics Ltd. (“Blade Dynamics”), a designer and manufacturer of advanced wind turbine blades based on proprietary materials and structural technologies, for $8.0 million in cash. During the three months ended December 31, 2012, an additional investor invested in Blade Dynamics and as of December 31, 2012, the Company now holds a 19% ownership interest in Blade Dynamics. As a result of the Company’s investment being reduced to less than 20%, and that the Company believes it no longer has the ability to significantly influence the operations of Blade Dynamics,  the Company has therefore changed its accounting for this investment from the equity method to the cost method as of December 1, 2012.

[0001193125-13-048834:notes:94]
The investment is carried at the acquisition cost, plus the Company’s equity in undistributed earnings or losses, through December 1, 2012 the date which the company no longer reports undistributed earnings or losses. The Company’s investment in Blade Dynamics is included in other assets on the unaudited condensed consolidated balance sheet and the equity in undistributed losses of Blade Dynamics is included in other income, net, on the unaudited condensed consolidated statements of operations.

[0001193125-13-048834:notes:95]
| Balance at April 1, 2012 | $ | 6,083 |
| Minority interest in net losses |  | (1,227) |
| Net foreign exchange rate impact |  | (101) |
| Balance at December 31, 2012 | $ | 4,755 |


## us-gaap:FairValueAssetsAndLiabilitiesMeasuredOnRecurringBasisGainLossIncludedInEarningsTextBlock

[0001193125-13-048834:notes:96]
|  |  | Total |  | Quoted Prices in |  | Significant Other |  | Significant |
|  |  | Carrying |  | Active Markets |  | Observable Inputs |  | Unobservable Inputs |
|  |  | Value |  | (Level 1) |  | (Level 2) |  | (Level 3) |
| December 31, 2012: |  |  |  |  |  |  |  |  |
| Assets: |  |  |  |  |  |  |  |  |
| Cash equivalents | $ | 23,639 | $ | 23,639 | $ | - | $ | - |
| Liabilities: |  |  |  |  |  |  |  |  |
| Derivative liability | $ | 1,024 | $ | - | $ | - | $ | 1,024 |
| Warrants |  | 4,581 |  | - |  | - |  | 4,581 |
|  |  | Total |  | Quoted Prices in |  | Significant Other |  | Significant |
|  |  | Carrying |  | Active Markets |  | Observable Inputs |  | Unobservable Inputs |
|  |  | Value |  | (Level 1) |  | (Level 2) |  | (Level 3) |
| March 31, 2012: |  |  |  |  |  |  |  |  |
| Assets: |  |  |  |  |  |  |  |  |
| Cash equivalents | $ | 23,485 | $ | 23,485 | $ | - | $ | - |
| Short-term commercial paper |  | 5,304 |  | - |  | 5,304 |  | - |


## us-gaap:FairValueDisclosuresTextBlock

[0001193125-13-048834:notes:97]
[same as prior period, unchanged from 0001193125-12-454266:notes:74]

[0001193125-13-048834:notes:98]
In January 2010, the Financial Accounting Standards Board (“FASB”) issued guidance related to disclosures of fair value measurements. The guidance requires gross presentation of activity within the Level 3 measurement roll-forward and details of transfers in and out of Level 1 and 2 measurements. It also clarifies two existing disclosure requirements on the level of disaggregation of fair value measurements and disclosures on inputs and valuation techniques. A change in the hierarchy of an investment from its current level will be reflected in the period during which the pricing methodology of such investment changes. Disclosure of the transfer of securities from Level 1 to Level 2 or Level 3 will be made in the event that the related security is significant to total cash and investments. The Company did not have any transfers of assets and liabilities between Level 1, Level 2 and Level 3 of the fair value measurement hierarchy during the three months ended December 31, 2012.

[0001193125-13-048834:notes:99]
[same as prior period, unchanged from 0001193125-12-454266:notes:76]

[0001193125-13-048834:notes:100]
[same as prior period, unchanged from 0001193125-12-454266:notes:77]

[0001193125-13-048834:notes:101]
[same as prior period, unchanged from 0001193125-12-454266:notes:78]

[0001193125-13-048834:notes:102]
The following table provides the assets carried at fair value, measured as of December 31, 2012 and March 31, 2012 (in thousands):

[0001193125-13-048834:notes:103]
The table below reflects the activity for the Company’s major classes of liabilities measured at fair value for the period ended December 31, 2012 (in thousands):

[0001193125-13-048834:notes:104]
[same as prior period, unchanged from 0001193125-12-454266:notes:81]

[0001193125-13-048834:notes:105]
[same as prior period, unchanged from 0001193125-12-454266:notes:82]

[0001193125-13-048834:notes:106]
[same as prior period, unchanged from 0001193125-12-454266:notes:83]

[0001193125-13-048834:notes:107]
[same as prior period, unchanged from 0001193125-12-454266:notes:84]

[0001193125-13-048834:notes:108]
[same as prior period, unchanged from 0001193125-12-454266:notes:85]

[0001193125-13-048834:notes:109]
[same as prior period, unchanged from 0001193125-12-454266:notes:86]

[0001193125-13-048834:notes:110]
The Company has identified all of the derivatives (“Derivative Liability”) associated with the Exchanged Note which include holder change of control redemption rights, issuer optional redemption rights, sale redemption rights and a feature to convert the Exchanged Note into equity at the holder’s option. The Derivative Liability is subject to revaluation at each balance sheet date, and any change in fair value will be recorded as a change in fair value in other income (expense) until the earlier of its exercise or expiration. The Company relies on assumptions in a lattice model to determine the fair value of Derivative Liability. The Company has appropriately valued the Derivative Liability within Level 3 of the valuation hierarchy.  See Note 11, “Debt”, for discussion on the Exchanged Note, Derivative Liability and valuation assumptions used.

[0001193125-13-048834:notes:111]
[same as prior period, unchanged from 0001193125-12-454266:notes:88]

[0001193125-13-048834:notes:112]
Warrants were issued in conjunction with the Initial Note and the Term Loan. See Note 11, “Debt,” for additional information on warrants.  These warrants are subject to revaluation at each balance sheet date, and any change in fair value will be recorded as a change in fair value in other income (expense) until the earlier of their exercise or expiration.

[0001193125-13-048834:notes:113]
The Company relies on various assumptions to determine the fair value of warrants. The Company has appropriately valued the warrants within Level 3 of the valuation hierarchy.  See Note 12, “Warrants and Derivative Liabilities,” for a discussion of the warrants and the valuation assumptions used.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001193125-13-048834:notes:114]
[same as prior period, unchanged from 0001193125-12-454266:notes:91]

[0001193125-13-048834:notes:115]
For the three and nine months ended December 31, 2012, the Company recorded income tax expense of $0.1 million and an income tax benefit of $0.7 million, respectively. For the three and nine months ended December 31, 2011, the Company recorded income tax expense of $0.1 million and $1.2 million, respectively.  The income tax expense for the three months ended December 31, 2012, was primarily due to income taxes in foreign jurisdictions. The income tax benefit for the nine months ended December 31, 2012 was primarily due to a refund of income taxes paid in China. The Company has provided a valuation allowance against all existing and newly created deferred tax assets as of December 31, 2012, as it is more likely than not that its deferred tax assets are not currently realizable due to the net operating losses incurred by the Company since its inception.


## us-gaap:InventoryDisclosureTextBlock

[0001193125-13-048834:notes:116]
[same as prior period, unchanged from 0001193125-12-454266:notes:93]

[0001193125-13-048834:notes:117]
The components of inventory at December 31, 2012 and March 31, 2012 are as follows (in thousands):

[0001193125-13-048834:notes:118]
|  |  | December 31, |  |  | March 31, |
|  |  | 2012 |  |  | 2012 |
| Raw materials | $ | 10,750 |  | $ | 9,962 |
| Work-in-process |  | 3,576 |  |  | 2,390 |
| Finished goods |  | 19,740 |  |  | 14,438 |
| Deferred program costs |  | 2,389 |  |  | 2,466 |
| Net inventory | $ | 36,455 |  | $ | 29,256 |

[0001193125-13-048834:notes:119]
For the three and nine months ended December 31, 2012, the Company recorded an inventory write-down of approximately $0.5 million and $1.0 million, respectively, based on evaluating its ending inventory on hand for excess quantities and obsolescence.

[0001193125-13-048834:notes:120]
Deferred program costs as of December 31, 2012 and March 31, 2012 primarily represent costs incurred on D-VAR turnkey projects and programs accounted for under contract accounting where the Company needs to complete development programs before revenue and costs will be recognized, respectively.


## us-gaap:LoansNotesTradeAndOtherReceivablesDisclosureTextBlock

[0001193125-13-048834:notes:121]
[same as prior period, unchanged from 0001193125-12-454266:notes:98]

[0001193125-13-048834:notes:122]
Accounts receivable at December 31, 2012 and March 31, 2012 consisted of the following (in thousands):

[0001193125-13-048834:notes:123]
|  |  | December 31, |  |  | March 31, |
|  |  | 2012 |  |  | 2012 |
| Accounts receivable (billed) | $ | 11,424 |  | $ | 16,240 |
| Accounts receivable (unbilled) |  | 914 |  |  | 2,811 |
| Less: Allowance for doubtful accounts |  | (10) |  |  | (52) |
| Accounts receivable, net | $ | 12,328 |  | $ | 18,999 |


## us-gaap:NewAccountingPronouncementsAndChangesInAccountingPrinciplesTextBlock

[0001193125-13-048834:notes:124]
16. Recent Accounting Pronouncements

[0001193125-13-048834:notes:125]
In June 2011, the FASB issued Accounting Standards Update (ASU) No. 2011-05, Comprehensive Income (Topic 220): Presentation of Comprehensive Income. ASU 2011-05 requires entities to present net income and other comprehensive income in either a single continuous statement or in two separate, but consecutive, statements of net income and other comprehensive income. ASU 2011-05 is effective for fiscal years and interim periods beginning after December 15, 2011. The Company early adopted ASU 2011-05 and it did not have a material impact on the Company’s consolidated results of operations, financial condition, or cash flows.

[0001193125-13-048834:notes:126]
In September 2011, the FASB issued Accounting Standards Update No. 2011-08, Intangibles — Goodwill and Other (Topic 350). ASU 2011-08 allows entities to first assess qualitatively whether it is necessary to perform the two-step goodwill impairment test. If an entity believes, as a result of its qualitative assessment, that it is more likely than not that the fair value of a reporting unit is less than its carrying amount, the quantitative two-step goodwill impairment test is required. An entity has the unconditional option to bypass the qualitative assessment and proceed directly to performing the first step of the goodwill impairment test. ASU 2011-08 is effective for our first quarter of fiscal 2013 but is eligible for early adoption. The Company does not believe adoption of this standard will have an impact on its consolidated results of operations, financial condition, or cash flows.

[0001193125-13-048834:notes:127]
In December 2011, the FASB issued Accounting Standards Update No. 2011-11, Balance Sheet (Topic 210)-Disclosures about Offsetting Assets and Liabilities (ASU 2011-11). The update requires entities to disclose information about offsetting and related arrangements of financial instruments and derivative instruments. ASU 2011-11 is effective for our first quarter of fiscal 2014. The Company is currently evaluating the impact of adopting ASU 2011-11, but currently does not believe there will be a significant impact on its consolidated results of operations, financial condition, or cash flows.

[0001193125-13-048834:notes:128]
The Company does not believe that other recently issued accounting pronouncements will have a material impact on its financial statements.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001193125-13-048834:notes:129]
10. Restructuring and Impairments

[0001193125-13-048834:notes:130]
Restructuring

[0001193125-13-048834:notes:131]
[same as prior period, unchanged from 0001193125-12-454266:notes:107]

[0001193125-13-048834:notes:132]
During the year ended March 31, 2012, the Company initiated restructuring activities in order to reorganize its global operations, streamline various functions of the business, and reduce its global workforce to better reflect the demand for its products. These activities resulted in the reduction of its global workforce by approximately 50%. During the nine months ended December 31, 2012, the Company initiated further restructuring activities to lower operating costs and enhance liquidity. On November 28, 2012, the Company undertook an action to reduce its global workforce by approximately 25%. As a result, for the three and nine months ended December 31, 2012, the Company incurred restructuring costs of $2.2 million and $2.3 million, respectively.  During the three months ended, December 31, 2012, $1.1 million of these additional charges were paid and the remaining balance of accrued restructuring is expected to be paid through December 2013.

[0001193125-13-048834:notes:133]
[same as prior period, unchanged from 0001193125-12-454266:notes:109]

[0001193125-13-048834:notes:134]
|  |  | Severance pay |  | Facility |  |  |
| Three months ended December 31, 2012 |  | and benefits |  | exit costs |  | Total |
| Accrued restructuring balance at October 1, 2012 | $ | 302 |  | - | $ | 302 |
| Charges to operations |  | 2,194 |  | - |  | 2,194 |
| Cash payments |  | (1,112) |  | - |  | (1,112) |
| Accrued restructuring balance at December 31, 2012 | $ | 1,384 | $ | - | $ | 1,384 |
| Nine months ended December 31, 2012 |  |  |  |  |  |  |
| Accrued restructuring balance at April 1, 2012 | $ | 680 | $ | 294 | $ | 974 |
| Charges to operations |  | 2,377 |  | (39) |  | 2,338 |
| Cash payments |  | (1,673) |  | (255) |  | (1,928) |
| Accrued restructuring balance at December 31, 2012 | $ | 1,384 | $ | - | $ | 1,384 |

[0001193125-13-048834:notes:135]
All restructuring charges discussed above are included within restructuring and impairments in the Company’s unaudited condensed consolidated statements of operations.  The Company includes accrued restructuring within accounts payable and accrued expenses in the unaudited condensed consolidated balance sheet.

[0001193125-13-048834:notes:136]
Impairments

[0001193125-13-048834:notes:137]
The Company periodically evaluates its long-lived assets consisting principally of fixed assets and amortizable intangible assets for potential impairment. In accordance with the applicable accounting guidance for the treatment of long-lived assets, the Company reviews the carrying value of its long-lived assets or asset group that is held and used, including intangible assets subject to amortization, for impairment whenever events and circumstances indicate that the carrying value of the assets may not be recoverable. Under the held and used approach, the asset or asset group to be tested for impairment should represent the lowest level for which identifiable cash flows are largely independent of the cash flows of other groups of assets and liabilities. The Company evaluates its long-lived assets whenever events or circumstances suggest that the carrying amount of an asset or group of assets may not be recoverable from the estimated undiscounted future cash flows.

[0001193125-13-048834:notes:138]
In November 2012, in response to challenging conditions in the wind power market, the Company undertook certain restructuring activities, to reduce costs. Since the restructuring action impacted all of the Company’s operations, the Company concluded that there were indicators of potential impairment of its long-lived assets,  and it therefore conducted an assessment of the recoverability of these assets during the three months ended December 31, 2012 by comparing the carrying value of the assets to the pre-tax undiscounted cash flows estimated to be generated by those assets over their remaining useful lives. Based on the calculation performed by management, the sum of the undiscounted cash flows forecasted to be generated by certain assets within its Grid segment and its Wind segment were less than the carrying value of those assets. In addition, the excess undiscounted cash flows generated by all of its reporting units were insufficient to cover the carrying value of its Corporate assets. Therefore, there was an indication that its Corporate reporting unit, Wind segment and certain of its Grid segment assets were impaired and, as a result, the Company performed additional analysis. An evaluation of the level of impairment was made by comparing the implied fair value of those definite long-lived tangible and intangible assets of its Corporate reporting unit, Wind segment and Grid segment against their carrying values.

[0001193125-13-048834:notes:139]
The fair values of the impacted property and equipment were based on what the Company could reasonably expect to sell each asset from the perspective of a market participant. The determination of the fair value of its property and equipment includes estimates and judgments regarding the marketability and ultimate sales price of individual assets. The Company utilized market data and approximations from comparable analyses to arrive at the estimated fair values of the impacted property and equipment. The fair values of amortization intangible assets related to completed technology and trade names were determined using primarily the relief-from-royalty method over the estimated economic lives of those assets from the perspective of a market participant. During the three months ended December 31, 2012, the Company determined that certain of its Corporate assets and Grid segment property, plant and equipment were impaired as their carrying values exceeded their fair values.   The Company determined the long-lived assets of its Wind segment were not impaired. Accordingly, the Company recorded an aggregate impairment charge of $4.5 million for the three months ended December 31, 2012.


## us-gaap:ScheduleOfRevenueByMajorCustomersByReportingSegmentsTableTextBlock

[0001193125-13-048834:notes:140]
|  | Three months ended |  |  | Nine months ended |  |
|  | December 31, |  |  | December 31, |  |
|  | 2012 |  | 2011 |  |  | 2012 |  | 2011 |  |
| CG Power Solutions UK Ltd. | 20.8 | % | - | % |  | < 10 | % | - | % |
| E.ON Climate & Renewables | 19.4 | % | - | % |  | < 10 | % | - | % |
| INOX Wind Limited | 18.9 | % | 26.5 | % |  | 17.3 | % | 20.5 | % |
| Beijing JINGCHENG New Energy Co., Ltd. | < 10 | % | < 10 | % |  | 16.7 | % | < 10 | % |
| Doosan Heavy Industries & Construction Co Ltd. | < 10 | % | 12.1 | % |  | < 10 | % | 14.8 | % |
| Ergon Energy Corporation Limited | - | % | 10.6 | % |  | - | % | < 10 | % |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001193125-13-048834:notes:141]
[same as prior period, unchanged from 0001193125-12-454266:notes:115]

[0001193125-13-048834:notes:142]
[same as prior period, unchanged from 0001193125-12-454266:notes:116]

[0001193125-13-048834:notes:143]
Through its Windtec Solutions, the Wind business segment enables manufacturers to field wind turbines with exceptional power output, reliability and affordability.  The Company supplies advanced power electronics and control systems, licenses its highly engineered wind turbine designs, and provides extensive customer support services to wind turbine manufactures. Its design portfolio includes a broad range of drive trains and power ratings up to 10 megawatts.  It provides a broad range of power electronics and software based control systems that are highly integrated and designed for optimized performance, efficiency, and grid compatibility.

[0001193125-13-048834:notes:144]
Through its Gridtec Solutions, the Grid business segment enables electric utilities and renewable energy project developers to connect, transmit and distribute power with exceptional efficiency, reliability and affordability.  The Company provides transmission planning services that allow it to identify power grid congestion, poor power quality and other risks, which help the Company determine how its solutions can improve network performance.  These services often lead to sales of grid interconnection solutions for wind farms and solar power plants, power quality systems and transmission and distribution cable systems.

[0001193125-13-048834:notes:145]
[same as prior period, unchanged from 0001193125-12-454266:notes:119]

[0001193125-13-048834:notes:146]
[same as prior period, unchanged from 0001193125-12-454266:notes:120]

[0001193125-13-048834:notes:147]
Unallocated corporate expenses primarily consist of stock-based compensation expense of $1.9 million and $6.0 million, respectively and restructuring and impairment charges of $6.7 million and $6.8 million, respectively, for the three and nine months ended December 31, 2012.  For the three and nine months ended December 31, 2011, unallocated corporate expenses primarily consist of restructuring and impairment charges of $4.1 million and $8.4 million, respectively, and stock-based compensation expense of $2.1 million and $7.7 million, respectively. In addition, the nine months ended December 31, 2011 includes expense of $20.6 million for the write-off of an advanced payment to The Switch.

[0001193125-13-048834:notes:148]
[same as prior period, unchanged from 0001193125-12-454266:notes:122]

[0001193125-13-048834:notes:149]
The following table sets forth customers who represented 10% or more of the Company’s total revenues for the three and nine months ended December 31, 2012 and 2011:


## us-gaap:SubsequentEventsTextBlock

[0001193125-13-048834:notes:150]
17. Subsequent Events

[0001193125-13-048834:notes:151]
The Company has performed an evaluation of subsequent events through the time of filing this Quarterly Report on Form 10-Q with the SEC, and has determined that there are no such events that are required to be disclosed.
