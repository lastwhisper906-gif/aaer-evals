# AMSC 8-K — 0001437749-21-018522 filed 2021-08-04

## item codes, every 8-K on or before 2021-08-04

- 2021-08-04 0001437749-21-018522 — 2.02, 9.01
- 2021-08-02 0001193125-21-233260 — 5.07
- 2021-06-02 0001437749-21-013955 — 2.02, 9.01
- 2021-05-25 0001437749-21-013279 — 5.02, 9.01
- 2021-05-21 0001193125-21-168626 — 8.01, 9.01
- 2021-05-10 0001193125-21-156251 — 1.01, 9.01
- 2021-02-26 0001193125-21-060434 — 8.01, 9.01
- 2021-02-03 0001437749-21-001859 — 2.02, 9.01
- 2021-02-01 0001437749-21-001681 — 5.03, 9.01
- 2020-12-14 0001437749-20-025291 — 9.01 — amendment, the index does not say of what
- 2020-11-04 0001437749-20-022520 — 2.02, 9.01
- 2020-10-26 0001193125-20-276900 — 8.01, 9.01
- 2020-10-05 0001437749-20-020735 — 2.02
- 2020-10-05 0001437749-20-020734 — 1.01, 2.01, 3.02, 9.01
- 2020-10-02 0001437749-20-020660 — 8.01
- 2020-09-16 0001437749-20-019767 — 8.01
- 2020-08-05 0001437749-20-016665 — 2.02, 5.07, 9.01
- 2020-06-02 0001437749-20-012274 — 2.02, 9.01
- 2020-05-27 0001437749-20-011837 — 5.02, 9.01
- 2020-02-05 0001437749-20-001788 — 2.02, 9.01
- 2019-11-05 0001437749-19-021590 — 2.02, 9.01
- 2019-08-06 0001437749-19-015631 — 2.02, 9.01
- 2019-08-06 0001193125-19-214189 — 5.02, 5.07, 9.01
- 2019-06-05 0001437749-19-011476 — 2.02, 5.02, 9.01
- 2019-05-24 0001437749-19-010833 — 5.02
- 2019-02-05 0001628280-19-000964 — 2.02, 8.01, 9.01
- 2018-11-06 0001628280-18-013765 — 2.02, 9.01
- 2018-10-31 0001628280-18-013204 — 1.01
- 2018-08-01 0001628280-18-010196 — 5.07
- 2018-07-31 0001628280-18-009846 — 2.02, 9.01
- 2018-07-09 0001193125-18-214745 — 1.01, 9.01
- 2018-07-03 0001628280-18-009075 — 5.02, 9.01
- 2018-06-14 0001628280-18-007877 — 5.02
- 2018-06-06 0001628280-18-007643 — 2.02, 9.01
- 2018-04-10 0001628280-18-004141 — 5.02
- 2018-04-03 0001628280-18-003952 — 2.01, 9.01
- 2018-02-05 0001628280-18-000989 — 2.02, 9.01
- 2018-02-01 0001628280-18-000826 — 1.01, 9.01
- 2017-11-07 0001628280-17-011076 — 2.02, 9.01
- 2017-09-26 0001628280-17-009444 — 3.02, 8.01
- 2017-08-08 0001628280-17-008329 — 2.02, 9.01
- 2017-08-01 0001628280-17-007765 — 5.02, 5.07
- 2017-07-03 0001193125-17-221140 — 5.02, 9.01
- 2017-05-26 0001193125-17-185503 — 8.01, 9.01
- 2017-05-25 0001628280-17-005914 — 2.02, 9.01 — amendment of 0001628280-17-005884
- 2017-05-25 0001628280-17-005884 — 2.02, 9.01
- 2017-05-10 0001193125-17-165924 — 8.01, 9.01
- 2017-05-09 0001193125-17-164273 — 5.02
- 2017-05-04 0001193125-17-158639 — 1.02, 8.01
- 2017-04-26 0001193125-17-139493 — 2.02, 9.01
- 2017-04-04 0001193125-17-109748 — 2.05, 5.02, 9.01
- 2017-02-06 0001628280-17-000899 — 2.02, 9.01
- 2017-01-27 0001193125-17-021808 — 1.01, 2.02, 9.01
- 2016-11-02 0001628280-16-020598 — 2.02, 9.01
- 2016-09-16 0001193125-16-712301 — 5.02
- 2016-08-23 0001193125-16-688767 — 8.01
- 2016-08-09 0001628280-16-018763 — 2.02, 9.01
- 2016-08-02 0001193125-16-668417 — 5.02, 5.07, 9.01
- 2016-05-31 0001564590-16-020114 — 2.02, 9.01
- 2016-05-18 0001193125-16-594515 — 5.02
- 2016-03-08 0001193125-16-496113 — 1.01
- 2016-02-09 0001193125-16-454775 — 2.02, 9.01
- 2015-12-17 0001193125-15-405566 — 1.01
- 2015-11-03 0001193125-15-363413 — 2.02, 9.01
- 2015-08-31 0001193125-15-307558 — 1.01
- 2015-08-05 0001193125-15-277824 — 2.02, 9.01
- 2015-07-31 0001193125-15-273009 — 5.07
- 2015-06-26 0001193125-15-237190 — 5.02
- 2015-06-09 0001193125-15-218028 — 8.01
- 2015-05-28 0001193125-15-202933 — 2.02, 9.01
- 2015-04-28 0001193125-15-153319 — 8.01, 9.01
- 2015-04-23 0001193125-15-144123 — 2.02, 8.01, 9.01
- 2015-04-23 0001193125-15-143608 — 8.01
- 2015-04-10 0001193125-15-126160 — 8.01
- 2015-03-24 0001193125-15-103436 — 5.03, 9.01
- 2015-03-18 0001193125-15-097034 — 5.07
- 2015-02-05 0001193125-15-034499 — 2.02, 9.01
- 2015-01-29 0001193125-15-024629 — 2.02, 9.01
- 2015-01-21 0001193125-15-016287 — 3.01, 8.01
- 2015-01-06 0001193125-15-002902 — 5.02
- 2014-12-22 0001193125-14-450591 — 1.01, 2.03, 3.02, 9.01
- 2014-11-13 0001193125-14-410207 — 1.01, 9.01
- 2014-11-07 0001193125-14-402383 — 1.02, 7.01, 9.01
- 2014-11-06 0001193125-14-399779 — 2.02, 9.01
- 2014-10-01 0001193125-14-360072 — 2.02, 8.01, 9.01
- 2014-09-04 0001193125-14-331411 — 8.01
- 2014-08-21 0001193125-14-317133 — 1.01
- 2014-08-06 0001193125-14-298306 — 5.02, 5.07, 9.01
- 2014-08-05 0001193125-14-294647 — 2.02, 9.01
- 2014-07-16 0001193125-14-269902 — 8.01
- 2014-06-23 0001193125-14-244592 — 3.02, 8.01
- 2014-06-05 0001193125-14-226459 — 2.02, 9.01
- 2014-06-05 0001193125-14-226457 — 1.01, 9.01
- 2014-03-19 0001193125-14-106558 — 2.05
- 2014-03-03 0001193125-14-078917 — 1.01, 3.02, 9.01
- 2014-02-28 0001193125-14-077480 — 8.01, 9.01
- 2014-02-06 0001193125-14-037960 — 2.02, 8.01, 9.01
- 2013-11-20 0001193125-13-447829 — 3.02, 8.01
- 2013-11-18 0001193125-13-444697 — 1.01, 2.03, 3.02, 9.01
- 2013-11-07 0001193125-13-431705 — 2.02, 9.01
- 2013-10-09 0001193125-13-395362 — 1.01, 2.03, 3.02, 9.01
- 2013-09-25 0001193125-13-378481 — 5.02, 9.01
- 2013-08-21 0001193125-13-341566 — 4.01, 9.01
- 2013-08-07 0001193125-13-323082 — 2.02, 9.01
- 2013-08-02 0001193125-13-317278 — 5.02, 5.07
- 2013-06-14 0001193125-13-258758 — 2.02, 9.01
- 2013-04-01 0001193125-13-136714 — 2.02, 8.01, 9.01
- 2013-02-20 0001193125-13-067218 — 5.02, 9.01
- 2013-02-14 0001193125-13-060131 — 1.01, 9.01
- 2013-02-11 0001193125-13-048784 — 2.02, 9.01
- 2013-01-08 0001193125-13-006861 — 5.02, 9.01
- 2012-12-21 0001193125-12-511592 — 1.01, 2.03, 3.02, 9.01
- 2012-11-28 0001193125-12-483317 — 2.05, 5.02, 7.01, 9.01
- 2012-11-06 0001193125-12-453359 — 2.02, 9.01
- 2012-08-02 0001193125-12-330534 — 2.02, 9.01
- 2012-07-27 0001193125-12-318790 — 5.02, 5.07, 9.01
- 2012-06-06 0001193125-12-261030 — 1.01, 2.02, 2.03, 3.02, 5.02, 9.01
- 2012-05-09 0001193125-12-222210 — 5.02
- 2012-04-20 0001193125-12-172045 — 8.01
- 2012-04-13 0001193125-12-162694 — 2.02, 8.01, 9.01
- 2012-04-04 0001193125-12-149102 — 1.01, 2.02, 2.03, 3.02, 9.01
- 2012-02-09 0001193125-12-048009 — 2.02, 9.01
- 2012-02-06 0001193125-12-041344 — 5.07 — amendment of 0000950123-11-102495
- 2011-12-08 0000950123-11-102495 — 5.07
- 2011-11-29 0000950123-11-100822 — 2.05
- 2011-11-09 0000950123-11-096775 — 2.02, 9.01
- 2011-10-31 0000950123-11-093390 — 1.02, 9.01
- 2011-10-07 0000950123-11-089221 — 8.01
- 2011-10-03 0000950123-11-088315 — 7.01
- 2011-09-23 0000950123-11-086288 — 2.02, 9.01
- 2011-09-15 0000950123-11-084585 — 7.01
- 2011-09-06 0000950123-11-082736 — 7.01
- 2011-08-18 0000950123-11-078526 — 3.01, 7.01, 9.01
- 2011-08-11 0000950123-11-075905 — 5.02
- 2011-08-11 0000950123-11-075904 — 2.02, 2.05, 9.01
- 2011-07-11 0000950123-11-064934 — 2.02, 4.02, 9.01
- 2011-06-30 0000950123-11-063287 — 1.01, 3.02, 9.01
- 2011-06-21 0000950123-11-060491 — 3.01, 7.01, 9.01
- 2011-06-13 0000950123-11-058656 — 1.01, 9.01
- 2011-05-24 0000950123-11-053517 — 5.02, 9.01
- 2011-04-05 0001299933-11-001020 — 2.02, 9.01
- 2011-03-15 0000950123-11-025580 — 5.02
- 2011-03-14 0000950123-11-025205 — 1.01, 3.02, 9.01
- 2011-02-01 0001299933-11-000333 — 2.02, 9.01
- 2010-11-12 0000950123-10-104604 — 8.01, 9.01
- 2010-11-08 0000950123-10-102424 — 8.01, 9.01
- 2010-11-02 0001299933-10-003878 — 2.02, 9.01
- 2010-09-15 0000950123-10-086373 — 1.01, 9.01 — amendment, the index does not say of what
- 2010-08-06 0000950123-10-074362 — 5.07
- 2010-07-29 0001299933-10-002860 — 2.02, 9.01
- 2010-05-17 0000950123-10-050424 — 1.01, 9.01
- 2010-05-14 0001299933-10-001972 — 5.02
- 2010-05-13 0001299933-10-001943 — 2.02, 9.01
- 2010-02-08 0001299933-10-000506 — 8.01
- 2010-02-02 0001299933-10-000386 — 2.02, 9.01
- 2009-12-15 0001299933-09-004928 — 5.02
- 2009-10-29 0001299933-09-004267 — 2.02, 9.01
- 2009-08-12 0001193125-09-173026 — 5.02, 9.01
- 2009-07-30 0001193125-09-158842 — 1.01, 2.02, 9.01
- 2009-05-15 0001193125-09-113158 — 5.02
- 2009-05-14 0001193125-09-110619 — 2.02, 9.01
- 2009-04-20 0001193125-09-082590 — 5.02
- 2009-02-03 0001193125-09-016992 — 2.02, 9.01
- 2009-01-22 0001193125-09-009777 — 2.02, 9.01
- 2008-11-04 0001193125-08-223730 — 2.02, 9.01
- 2008-08-11 0001193125-08-173616 — 8.01
- 2008-08-07 0001193125-08-170325 — 8.01
- 2008-08-05 0001193125-08-165888 — 2.02, 9.01
- 2008-06-11 0001193125-08-132049 — 1.01, 9.01
- 2008-05-20 0001193125-08-119372 — 5.02, 9.01
- 2008-05-08 0001193125-08-107052 — 2.02, 9.01
- 2008-01-31 0001193125-08-016233 — 2.02, 9.01
- 2008-01-30 0001193125-08-015494 — 5.03, 9.01
- 2007-11-01 0001193125-07-231866 — 2.02, 9.01
- 2007-10-31 0001193125-07-231225 — 2.05
- 2007-10-29 0001193125-07-228284 — 5.03, 9.01
- 2007-09-27 0001193125-07-208950 — 5.02
- 2007-08-09 0001193125-07-176553 — 2.02, 9.01
- 2007-08-07 0001193125-07-173829 — 1.01, 5.02, 9.01
- 2007-07-02 0001193125-07-148303 — 5.02, 9.01
- 2007-06-20 0001193125-07-139068 — 8.01, 9.01
- 2007-06-14 0001193125-07-135550 — 9.01 — amendment of 0001193125-07-005297
- 2007-06-14 0001193125-07-135340 — 5.02
- 2007-05-24 0001193125-07-122148 — 2.02, 9.01
- 2007-03-30 0001193125-07-070154 — 2.05, 9.01
- 2007-03-23 0001193125-07-062978 — 9.01 — amendment of 0001193125-07-005297
- 2007-02-01 0001193125-07-017883 — 2.02, 9.01
- 2007-01-11 0001193125-07-005297 — 2.01, 9.01
- 2006-12-05 0001181431-06-067500 — 5.02
- 2006-11-29 0001193125-06-243360 — 1.01, 3.02, 9.01
- 2006-11-02 0001193125-06-221464 — 2.02, 9.01
- 2006-09-21 0001193125-06-194526 — 5.02
- 2006-08-08 0001193125-06-164819 — 2.02, 9.01
- 2006-08-02 0001193125-06-159113 — 1.01, 9.01
- 2006-07-28 0001193125-06-156172 — 1.01
- 2006-06-26 0001193125-06-135913 — 1.01, 3.03, 9.01
- 2006-05-11 0001193125-06-108489 — 2.02, 9.01
- 2006-05-05 0001193125-06-102270 — 1.01, 9.01
- 2006-05-01 0001193125-06-094941 — 2.02, 2.06, 9.01
- 2006-02-24 0001193125-06-038281 — 5.02, 9.01
- 2006-02-02 0001181431-06-007665 — 2.02, 9.01
- 2005-11-09 0001181431-05-060304 — 2.02, 9.01
- 2005-08-04 0001181431-05-044420 — 2.02, 9.01
- 2005-07-28 0001193125-05-151272 — 5.02, 9.01
- 2005-06-14 0001193125-05-125148 — 5.02, 9.01
- 2005-05-12 0001181431-05-027410 — 2.02, 9.01
- 2005-05-10 0001193125-05-102795 — 1.01
- 2005-04-05 0001181431-05-020680 — 1.01, 2.02, 3.02, 9.01
- 2005-02-03 0001181431-05-006678 — 2.02, 9.01
- 2004-11-09 0001181431-04-051381 — 2.02, 9.01 — amendment, the index does not say of what
- 2004-11-04 0001181431-04-050706 — 2.02, 9.01
- 2004-10-15 0001193125-04-172458 — 1.01, 9.01
- 2004-08-05 0001193125-04-132162 — 12
- 2004-05-13 0001193125-04-086853 — 12
- 2004-02-05 0001193125-04-015060 — 12
- 2003-11-06 0001193125-03-074000 — 12
- 2003-09-26 0001193125-03-054624 — 5
- 2003-08-06 0001193125-03-029666 — 12
- 2003-05-14 0000927016-03-002619 — 9
- 2002-12-31 0000927016-02-006114 — 5
- 2000-01-24 0000927016-00-000150 — 5, 7
- 1998-11-02 0000950135-98-005625 — 5, 7
- 1998-03-24 0000950135-98-001743 — 5, 7
- 1997-09-05 0000950135-97-003729 — 5, 7
- 1997-06-23 0000950135-97-002785 — 1 — amendment of 0000950135-97-001972
- 1997-04-23 0000950135-97-001972 — 2, 7

## late-filing notifications on or before 2021-08-04

- 2011-08-10 0000950123-11-075677 — NT 10-Q, for the period ended 2011-06-30
- 2011-05-31 0000950123-11-055465 — NT 10-K, for the period ended 2011-03-31

## item 2.02 — earnings release, exhibit 99.1

[0001437749-21-018522:8k_2_02:1]
EX-99.1
2
ex_256903.htm
EXHIBIT 99.1

[0001437749-21-018522:8k_2_02:2]
ex_256903.htm

[0001437749-21-018522:8k_2_02:3]
Exhibit 99.1

[0001437749-21-018522:8k_2_02:4]
AMSC Reports First Quarter Fiscal Year 2021 Financial Results and Provides Business Outlook

[0001437749-21-018522:8k_2_02:5]
Company to host conference call tomorrow, August 5 at 10:00 am ET

[0001437749-21-018522:8k_2_02:6]
Ayer, MA – August 4, 2021 – AMSC (Nasdaq: AMSC), a leading system provider of megawatt-scale power resiliency solutions that orchestrate the rhythm and harmony of power on the grid™, and protect and expand the capability and resiliency of our Navy’s fleet, today reported financial results for its first quarter of fiscal year 2021 ended June 30, 2021.

[0001437749-21-018522:8k_2_02:7]
Revenues for the first quarter of fiscal 2021 were $25.4 million compared with $21.2 million for the same period of fiscal 2020. The year-over-year increase was a result of higher Grid segment revenues versus the year ago period.  The higher Grid segment revenues were primarily due to increased new energy power systems shipments and higher ship protection systems revenue, versus the year ago period.

[0001437749-21-018522:8k_2_02:8]
AMSC’s net loss for the first quarter of fiscal 2021 was $5.4 million, or $0.20 per share, compared to a net loss of $3.4 million, or $0.16 per share, for the same period of fiscal 2020.  The Company’s non-GAAP net loss for the first quarter of fiscal 2021 was $2.7 million, or $0.10 per share, compared with a non-GAAP net loss of $2.4 million, or $0.11 per share, in the same period of fiscal 2020. Please refer to the financial table below for a reconciliation of GAAP to non-GAAP results.

[0001437749-21-018522:8k_2_02:9]
Cash, cash equivalents, marketable securities and restricted cash on June 30, 2021, totaled $63.1 million, compared with $80.7 million at March 31, 2021.

[0001437749-21-018522:8k_2_02:10]
“We delivered a very strong start to fiscal 2021,” said Daniel P. McGahn, Chairman, President and CEO, AMSC. “Grid segment revenues grew over 30% versus year ago results and were, in fact, the highest we have ever reported. Our new energy power systems products contributed to the strong growth in the quarter, along with growth from ship protection systems. We are on track for sequentially higher quarterly revenue levels this fiscal year. We believe our growth through Grid strategy is working.”

[0001437749-21-018522:8k_2_02:11]
| AMSC Reports Q1FY21 Results | Page 2 |

[0001437749-21-018522:8k_2_02:12]
Business Outlook

[0001437749-21-018522:8k_2_02:13]
For the second quarter ending September 30, 2021, AMSC expects that its revenues will be in the range of $24 million to $27 million.  The Company’s net loss for the second quarter of fiscal 2021 is expected not to exceed $6.7 million, or $0.25 per share. The Company’s net loss guidance assumes no changes in contingent consideration nor any purchase accounting adjustments associated with the Neeltran Acquisition.  The Company's non-GAAP net loss (as defined below) is expected not to exceed $5.0 million, or $0.18 per share.  The Company expects operating cash flow to be a burn of $4 million to $6 million in the second quarter of fiscal 2021.  The Company expects cash, cash equivalents, marketable securities and restricted cash on September 30, 2021, to be no less than $56 million.

[0001437749-21-018522:8k_2_02:14]
Conference Call Reminder

[0001437749-21-018522:8k_2_02:15]
In conjunction with this announcement, AMSC management will participate in a conference call with investors beginning at 10:00 a.m. Eastern Time on Thursday, August 5, 2021, to discuss the Company’s financial results and business outlook. Those who wish to listen to the live or archived conference call webcast should visit the “Investors” section of the Company’s website at https://ir.amsc.com.  To preregister for the call, go to ClickToJoinLink.  Callers who click on the link will be able to enter their information to gain immediate access to the call and bypass the live operator. Participants may preregister 15 minutes prior to the scheduled start time.  The live call can also be accessed by dialing 800-437-2398 or 323-289-6576 and using conference ID 9736574. A replay of the call may be accessed 2 hours following the call by dialing 888-203-1112 or 719-457-0820 and using conference passcode 9736574.

[0001437749-21-018522:8k_2_02:16]
About AMSC (Nasdaq: AMSC)

[0001437749-21-018522:8k_2_02:17]
AMSC generates the ideas, technologies and solutions that meet the world’s demand for smarter, cleaner … better energy™. Through its Gridtec™ Solutions, AMSC provides the engineering planning services and advanced grid systems that optimize network reliability, efficiency and performance.  Through its Marinetec™ Solutions, AMSC provides ship protection systems and is developing propulsion and power management solutions designed to help fleets increase system efficiencies, enhance power quality and boost operational safety.  Through its Windtec™ Solutions, AMSC provides wind turbine electronic controls and systems, designs and engineering services that reduce the cost of wind energy. The Company’s solutions are enhancing the performance and reliability of power networks, increasing the operational safety of navy fleets, and powering gigawatts of renewable energy globally. Founded in 1987, AMSC is headquartered near Boston, Massachusetts with operations in Asia, Australia, Europe and North America. For more information, please visit www.amsc.com.

[0001437749-21-018522:8k_2_02:18]
AMSC, American Superconductor, D-VAR, D-VAR VVO, Gridtec, Marinetec, Windtec, Smarter, Cleaner … Better Energy, and Orchestrate the Rhythm and Harmony of Power on the Grid are trademarks or registered trademarks of American Superconductor Corporation. All other brand names, product names, trademarks or service marks belong to their respective holders.

[0001437749-21-018522:8k_2_02:19]
| AMSC Reports Q1FY21 Results | Page 3 |

[0001437749-21-018522:8k_2_02:20]
Forward-Looking Statements

[0001437749-21-018522:8k_2_02:21]
| AMSC Reports Q1FY21 Results | Page 4 |

[0001437749-21-018522:8k_2_02:22]
UNAUDITED CONSOLIDATED STATEMENTS OF OPERATIONS

[0001437749-21-018522:8k_2_02:23]
(In thousands, except per share data)

[0001437749-21-018522:8k_2_02:24]
|  |  | Three Months Ended |  |
|  |  | June 30, |  |
|  |  | 2021 |  |  | 2020 |  |
| Revenues |  |  |  |  |  |  |  |  |
| Grid |  | $ | 23,501 |  |  | $ | 17,715 |  |
| Wind |  |  | 1,919 |  |  |  | 3,498 |  |
| Total revenues |  |  | 25,420 |  |  |  | 21,213 |  |
| Cost of revenues |  |  | 22,051 |  |  |  | 16,173 |  |
| Gross margin |  |  | 3,369 |  |  |  | 5,040 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |
| Research and development |  |  | 3,041 |  |  |  | 2,499 |  |
| Selling, general and administrative |  |  | 7,142 |  |  |  | 5,637 |  |
| Amortization of acquisition-related intangibles |  |  | 585 |  |  |  | 121 |  |
| Change in fair value of contingent consideration |  |  | 100 |  |  |  | — |  |
| Total operating expenses |  |  | 10,868 |  |  |  | 8,257 |  |
| Operating loss |  |  | (7,499 | ) |  |  | (3,217 | ) |
| Interest income, net |  |  | 32 |  |  |  | 158 |  |
| Other expense, net |  |  | (64 | ) |  |  | (170 | ) |
| Loss before income tax expense (benefit) |  |  | (7,531 | ) |  |  | (3,229 | ) |
| Income tax expense (benefit) |  |  | (2,128 | ) |  |  | 188 |  |
| Net loss |  | $ | (5,403 | ) |  | $ | (3,417 | ) |
| Net loss per common share |  |  |  |  |  |  |  |  |
| Basic |  | $ | (0.20 | ) |  | $ | (0.16 | ) |
| Diluted |  | $ | (0.20 | ) |  | $ | (0.16 | ) |
| Weighted average number of common shares outstanding |  |  |  |  |  |  |  |  |
| Basic |  |  | 26,826 |  |  |  | 21,689 |  |
| Diluted |  |  | 26,826 |  |  |  | 21,689 |  |

[0001437749-21-018522:8k_2_02:25]
| AMSC Reports Q1FY21 Results | Page 5 |

[0001437749-21-018522:8k_2_02:26]
UNAUDITED CONSOLIDATED BALANCE SHEET

[0001437749-21-018522:8k_2_02:27]
(In thousands, except per share data)

[0001437749-21-018522:8k_2_02:28]
|  |  | June 30, 2021 |  |  | March 31, 2021 |  |
| ASSETS |  |  |  |  |  |  |  |  |
| Current assets: |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 50,070 |  |  | $ | 67,814 |  |
| Marketable securities |  |  | 5,164 |  |  |  | 5,140 |  |
| Accounts receivable, net |  |  | 23,908 |  |  |  | 13,267 |  |
| Inventory, net |  |  | 22,155 |  |  |  | 13,306 |  |
| Prepaid expenses and other current assets |  |  | 5,906 |  |  |  | 3,546 |  |
| Restricted cash |  |  | 2,313 |  |  |  | 2,157 |  |
| Total current assets |  |  | 109,516 |  |  |  | 105,230 |  |
| Property, plant and equipment, net |  |  | 15,067 |  |  |  | 8,997 |  |
| Intangibles, net |  |  | 13,312 |  |  |  | 9,153 |  |
| Right-of-use assets |  |  | 3,764 |  |  |  | 3,747 |  |
| Goodwill |  |  | 43,471 |  |  |  | 34,634 |  |
| Restricted cash |  |  | 5,568 |  |  |  | 5,568 |  |
| Deferred tax assets |  |  | 1,149 |  |  |  | 1,223 |  |
| Other assets |  |  | 320 |  |  |  | 314 |  |
| Total assets |  | $ | 192,167 |  |  | $ | 168,866 |  |
| LIABILITIES AND STOCKHOLDERS' EQUITY |  |  |  |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |  |  |  |
| Accounts payable and accrued expenses |  | $ | 33,439 |  |  | $ | 19,810 |  |
| Lease liability, current portion |  |  | 696 |  |  |  | 612 |  |
| Debt, current portion |  |  | 72 |  |  |  | — |  |
| Contingent consideration |  |  | 7,150 |  |  |  | 7,050 |  |
| Deferred revenue, current portion |  |  | 20,550 |  |  |  | 13,266 |  |
| Total current liabilities |  |  | 61,907 |  |  |  | 40,738 |  |
| Deferred revenue, long term portion |  |  | 8,072 |  |  |  | 7,991 |  |
| Lease liability, long term portion |  |  | 3,194 |  |  |  | 3,246 |  |
| Deferred tax liabilities |  |  | 273 |  |  |  | 274 |  |
| Debt, long-term portion |  |  | 143 |  |  |  | — |  |
| Other liabilities |  |  | 25 |  |  |  | 25 |  |
| Total liabilities |  |  | 73,614 |  |  |  | 52,274 |  |
| Stockholders' equity: |  |  |  |  |  |  |  |  |
| Common stock |  |  | 287 |  |  |  | 280 |  |
| Additional paid-in capital |  |  | 1,128,961 |  |  |  | 1,121,495 |  |
| Treasury stock |  |  | (3,639 | ) |  |  | (3,593 | ) |
| Accumulated other comprehensive loss |  |  | (340 | ) |  |  | (277 | ) |
| Accumulated deficit |  |  | (1,006,716 | ) |  |  | (1,001,313 | ) |
| Total stockholders' equity |  |  | 118,553 |  |  |  | 116,592 |  |
| Total liabilities and stockholders' equity |  | $ | 192,167 |  |  | $ | 168,866 |  |

[0001437749-21-018522:8k_2_02:29]
| AMSC Reports Q1FY21 Results | Page 6 |

[0001437749-21-018522:8k_2_02:30]
UNAUDITED CONSOLIDATED STATEMENTS OF CASH FLOWS

[0001437749-21-018522:8k_2_02:31]
(In thousands)

[0001437749-21-018522:8k_2_02:32]
|  |  | Three Months Ended June 30, |  |
|  |  | 2021 |  |  | 2020 |  |
| Cash flows from operating activities: |  |  |  |  |  |  |  |  |
| Net loss |  | $ | (5,403 | ) |  | $ | (3,417 | ) |
| Adjustments to reconcile net loss to net cash used in operations: |  |  |  |  |  |  |  |  |
| Depreciation and amortization |  |  | 1,268 |  |  |  | 1,000 |  |
| Stock-based compensation expense |  |  | 1,292 |  |  |  | 909 |  |
| Provision for excess and obsolete inventory |  |  | 624 |  |  |  | 789 |  |
| Deferred income taxes |  |  | (2,207 | ) |  |  | — |  |
| Change in fair value of contingent consideration |  |  | 100 |  |  |  | — |  |
| Non-cash interest income |  |  | (24 | ) |  |  | (134 | ) |
| Other non-cash items |  |  | 124 |  |  |  | 102 |  |
| Unrealized foreign exchange loss on cash and cash equivalents |  |  | 3 |  |  |  | 85 |  |
| Changes in operating asset and liability accounts: |  |  |  |  |  |  |  |  |
| Accounts receivable |  |  | (7,388 | ) |  |  | 8,783 |  |
| Inventory |  |  | (465 | ) |  |  | 1,132 |  |
| Prepaid expenses and other assets |  |  | 463 |  |  |  | (496 | ) |
| Accounts payable and accrued expenses |  |  | 8,563 |  |  |  | (7,974 | ) |
| Deferred revenue |  |  | (2,779 | ) |  |  | (3,894 | ) |
| Net cash used in operating activities |  |  | (5,829 | ) |  |  | (3,115 | ) |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |
| Purchase of property, plant and equipment |  |  | (224 | ) |  |  | (637 | ) |
| Cash paid for acquisition, net of cash acquired |  |  | (11,479 | ) |  |  | — |  |
| Change in other assets |  |  | (5 | ) |  |  | 128 |  |
| Net cash used in investing activities |  |  | (11,708 | ) |  |  | (509 | ) |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |
| Repurchase of treasury stock |  |  | (46 | ) |  |  | (376 | ) |
| Net cash used in financing activities |  |  | (46 | ) |  |  | (376 | ) |
| Effect of exchange rate changes on cash |  |  | (5 | ) |  |  | 12 |  |
| Net decrease in cash, cash equivalents and restricted cash |  |  | (17,588 | ) |  |  | (3,988 | ) |
| Cash, cash equivalents and restricted cash at beginning of period |  |  | 75,539 |  |  |  | 30,864 |  |
| Cash, cash equivalents and restricted cash at end of period |  | $ | 57,951 |  |  | $ | 26,876 |  |

[0001437749-21-018522:8k_2_02:33]
| AMSC Reports Q1FY21 Results | Page 7 |

[0001437749-21-018522:8k_2_02:34]
RECONCILIATION OF GAAP NET LOSS TO NON-GAAP NET LOSS

[0001437749-21-018522:8k_2_02:35]
(In thousands, except per share data)

[0001437749-21-018522:8k_2_02:36]
|  |  | Three Months Ended June 30, |  |
|  |  | 2021 |  |  | 2020 |  |
| Net loss |  | $ | (5,403 | ) |  | $ | (3,417 | ) |
| Stock-based compensation |  |  | 1,292 |  |  |  | 909 |  |
| Amortization of acquisition-related intangibles |  |  | 622 |  |  |  | 121 |  |
| Acquisition costs |  |  | 688 |  |  |  | — |  |
| Change in fair value of contingent consideration |  |  | 100 |  |  |  | — |  |
| Non-GAAP net loss |  | $ | (2,701 | ) |  | $ | (2,387 | ) |
| Non-GAAP net loss per share - basic |  | $ | (0.10 | ) |  | $ | (0.11 | ) |
| Weighted average shares outstanding - basic |  |  | 26,826 |  |  |  | 21,689 |  |

[0001437749-21-018522:8k_2_02:37]
Reconciliation of Forecast GAAP Net Loss to Non-GAAP Net Loss

[0001437749-21-018522:8k_2_02:38]
(In millions, except per share data)

[0001437749-21-018522:8k_2_02:39]
|  |  | Three months ending |  |
|  |  | September 30, 2021 |  |
| Net loss |  | $ | (6.7) |  |
| Stock-based compensation |  |  | 1.0 |  |
| Amortization of acquisition-related intangibles |  |  | 0.7 |  |
| Non-GAAP net loss |  | $ | (5.0) |  |
| Non-GAAP net loss per share |  | $ | (0.18 | ) |
| Shares outstanding |  |  | 27.1 |  |

[0001437749-21-018522:8k_2_02:40]
| AMSC Reports Q1FY21 Results | Page 8 |

[0001437749-21-018522:8k_2_02:41]
Note: Non-GAAP net loss is defined by the Company as net (loss) before: stock-based compensation; amortization of acquisition-related intangibles; acquisition costs; changes in fair value of contingent consideration; other non-cash or unusual charges, and the tax effect of adjustments calculated at the relevant rate for our non-GAAP metric. The Company believes non-GAAP net loss assists management and investors in comparing the Company’s performance across reporting periods on a consistent basis by excluding these non-cash, non-recurring or other charges that it does not believe are indicative of its core operating performance.  Actual GAAP and non-GAAP net loss for the fiscal quarter ending September 30, 2021, including the above adjustments, may differ materially from those forecasted in the table above, including as a result of the inclusion of the change in fair value of contingent consideration.

[0001437749-21-018522:8k_2_02:42]
Generally, a non-GAAP financial measure is a numerical measure of a company's performance, financial position or cash flow that either excludes or includes amounts that are not normally excluded or included in the most directly comparable measure calculated and presented in accordance with GAAP. The non-GAAP measure included in this release, however, should be considered in addition to, and not as a substitute for or superior to, operating income, cash flows, or other measures of financial performance prepared in accordance with GAAP. A reconciliation of GAAP to non-GAAP net loss is set forth in the table above.

[0001437749-21-018522:8k_2_02:43]
AMSC Contacts

[0001437749-21-018522:8k_2_02:44]
Investor Relations Contact:

[0001437749-21-018522:8k_2_02:45]
LHA Investor Relations

[0001437749-21-018522:8k_2_02:46]
Carolyn Capaccio

[0001437749-21-018522:8k_2_02:47]
(212) 838-3777

[0001437749-21-018522:8k_2_02:48]
amscIR@lhai.com

[0001437749-21-018522:8k_2_02:49]
Public Relations Contact:

[0001437749-21-018522:8k_2_02:50]
RooneyPartners LLC

[0001437749-21-018522:8k_2_02:51]
Joe Luongo

[0001437749-21-018522:8k_2_02:52]
(914) 906-5903

[0001437749-21-018522:8k_2_02:53]
jluongo@rooneyco.com

[0001437749-21-018522:8k_2_02:54]
AMSC Communications Manager:

[0001437749-21-018522:8k_2_02:55]
Nicol Golez

[0001437749-21-018522:8k_2_02:56]
978-399-8344

[0001437749-21-018522:8k_2_02:57]
Nicol.Golez@amsc.com
