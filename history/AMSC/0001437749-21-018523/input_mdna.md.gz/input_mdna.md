# AMSC MD&A — 0001437749-21-018523


## mdna

[0001437749-21-018523:mdna:1]
[same as prior period, unchanged from 0001437749-21-001877:mdna:1]

[0001437749-21-018523:mdna:2]
American Superconductor®, Amperium®, AMSC®, D-VAR®, PowerModule™, D-VAR VVO®, PQ-IVR®, SeaTitan®, Gridtec™ Solutions, Windtec™ Solutions, Smarter, Cleaner...Better Energy™, Orchestrate the Rhythm and Harmony of Power on the Grid™, actiVAR®, armorVAR™, NEPSI™ and Neeltran™ are trademarks or registered trademarks of American Superconductor Corporation or our subsidiaries. We reserve all of our rights with respect to our trademarks or registered trademarks regardless of whether they are so designated in this Quarterly Report on Form 10-Q by an ® or ™ symbol. All other brand names, product names, trademarks or service marks appearing in this Quarterly Report on Form 10-Q are the property of their respective holders.

[0001437749-21-018523:mdna:3]
[same as prior period, unchanged from 0001437749-21-001877:mdna:3]

[0001437749-21-018523:mdna:4]
[same as prior period, unchanged from 0001437749-21-001877:mdna:4]

[0001437749-21-018523:mdna:5]
[same as prior period, unchanged from 0001437749-21-001877:mdna:5]

[0001437749-21-018523:mdna:6]
[same as prior period, unchanged from 0001437749-21-001877:mdna:6]

[0001437749-21-018523:mdna:7]
[same as prior period, unchanged from 0001437749-21-001877:mdna:7]

[0001437749-21-018523:mdna:8]
|  | • | Grid. Through our Gridtec™ Solutions, our Grid business segment enables electric utilities, industrial facilities and renewable energy project developers to connect, transmit and distribute power with exceptional efficiency, reliability, security and affordability. We provide transmission planning services that allow us to identify power grid congestion, poor power quality, and other risks, which help us determine how our solutions can improve network performance. These services often lead to sales of our grid interconnection solutions for wind farms and solar power plants, power quality systems and transmission and distribution cable systems. We also sell ship protection products to the U.S. Navy through our Grid business segment. |

[0001437749-21-018523:mdna:9]
|  | • | Wind. Through our Windtec™ Solutions, our Wind business segment enables manufacturers to field wind turbines with exceptional power output, reliability and affordability. We supply advanced power electronics and control systems, license our highly engineered wind turbine designs, and provide extensive customer support services to wind turbine manufacturers. Our design portfolio includes a broad range of drive trains and power ratings of 2 megawatts (“MW”) and higher. We provide a broad range of power electronics and software-based control systems that are highly integrated and designed for optimized performance, efficiency, and grid compatibility. |

[0001437749-21-018523:mdna:10]
Our fiscal year begins on April 1 and ends on March 31. When we refer to a particular fiscal year, we are referring to the fiscal year that began on April 1 of that same year. For example, fiscal 2021 refers to the fiscal year that began on April 1, 2021. Other fiscal years follow similarly.

[0001437749-21-018523:mdna:11]
[same as prior period, unchanged from 0001437749-21-001877:mdna:11]

[0001437749-21-018523:mdna:12]
On October 1, 2020, we entered into a Stock Purchase Agreement (the “NEPSI Stock Purchase Agreement”) with the selling stockholders named therein.  Pursuant to the terms of the NEPSI Stock Purchase Agreement and concurrently with entering into such agreement, we acquired all of the issued and outstanding (i) shares of capital stock of “NEPSI, a New York corporation", and (ii) membership interests of Northeast Power Realty, LLC, a New York limited liability company, which holds the real property that serves as NEPSI’s headquarters (the "NEPSI Acquisition"). NEPSI is a U.S.-based global provider of medium-voltage metal-enclosed power capacitor banks and harmonic filter banks for use on electric power systems.  As a result of this transaction, NEPSI became a wholly-owned subsidiary and is operated by our Grid business segment.

[0001437749-21-018523:mdna:13]
[same as prior period, unchanged from 0001437749-21-001877:mdna:13]

[0001437749-21-018523:mdna:14]
On May 6, 2021, we acquired all of the issued and outstanding shares of capital stock of (i) Neeltran, a Connecticut corporation that supplies rectifiers and transformers to industrial customers, and (ii) Neeltran International, Inc., a Connecticut corporation (“International”), as well as the real property that served as Neeltran’s headquarters ("the Neeltran Acquisition"). For additional information, see “Liquidity and Capital Resources” below.

[0001437749-21-018523:mdna:15]
In 2020, COVID-19 was declared a pandemic and spread throughout the globe, including in the Commonwealth of Massachusetts where our headquarters are located, and in other areas where we have business operations. In response to the pandemic, we have followed the guidelines of the U.S. Centers for Disease Control and Prevention (“CDC”) and applicable state government authorities to protect the health and safety of our employees, their families, our suppliers, our customers and our communities. While these measures and, COVID-19 generally, have not materially disrupted our business to date, any future actions necessitated by the COVID-19 pandemic may result in disruption to our business.

[0001437749-21-018523:mdna:16]
The COVID-19 pandemic continues to rapidly evolve. The extent to which the outbreak impacts our business, liquidity, results of operations and financial condition will depend on future developments, which are highly uncertain and cannot be predicted with confidence, including the continued geographic spread of the disease, the duration of the pandemic, the location, duration and magnitude of future waves of infection, new variants of the virus, availability and adoption of vaccines, effectiveness of vaccines against the virus and its mutations, travel restrictions and social distancing in the United States, the European Union, India and other countries, the duration and extent of business closures or business disruptions and the effectiveness of actions taken to contain and treat the disease.

[0001437749-21-018523:mdna:17]
[same as prior period, unchanged from 0001437749-21-001877:mdna:17]

[0001437749-21-018523:mdna:18]
The preparation of the unaudited condensed consolidated financial statements requires that we make estimates and judgments that affect the reported amounts of assets, liabilities, revenues and expenses, and related disclosure of contingent assets and liabilities. We base our estimates on historical experience and various other assumptions that are believed to be reasonable under the circumstances, the results of which form the basis for making judgments about the carrying values of assets and liabilities that are not readily apparent from other sources. Actual results may differ under different assumptions or conditions. There were no significant changes in the critical accounting policies that were disclosed in our Form 10-K for the fiscal year ended March 31, 2021.

[0001437749-21-018523:mdna:19]
[same as prior period, unchanged from 0001437749-21-001877:mdna:19]

[0001437749-21-018523:mdna:20]
Three months ended June 30, 2021, compared to the three months ended June 30, 2020

[0001437749-21-018523:mdna:21]
[same as prior period, unchanged from 0001437749-21-001877:mdna:21]

[0001437749-21-018523:mdna:22]
Total revenues increased 20% to $25.4 million for the three months ended June 30, 2021, compared to $21.2 million for the three months ended June 30, 2020.  Our revenues are summarized as follows (in thousands):

[0001437749-21-018523:mdna:23]
|  |  | Three Months Ended June 30, |  |
|  |  | 2021 |  |  | 2020 |  |
| Revenues: |  |  |  |  |  |  |  |  |
| Grid |  | $ | 23,501 |  |  | $ | 17,715 |  |
| Wind |  |  | 1,919 |  |  |  | 3,498 |  |
| Total |  | $ | 25,420 |  |  | $ | 21,213 |  |

[0001437749-21-018523:mdna:24]
Our Grid business unit accounted for 92% of total revenues for the three months ended June 30, 2021, compared to 84% for the three months ended June 30, 2020. Our Grid business unit revenues increased 33% to $23.5 million in the three months ended June 30, 2021, from $17.7 million in the three months ended June 30, 2020.  The increase in the Grid business unit revenue in the three months ended June 30, 2021, was driven by the contributions from the acquisitions of NEPSI and Neeltran as well as growth in the SPS product line.

[0001437749-21-018523:mdna:25]
Our Wind business unit accounted for 8% of total revenues for the three months ended June 30, 2021, compared to 16% for the three months ended June 30, 2020.  Revenues in the Wind business unit decreased 45%to $1.9 million in the three months ended June 30, 2021, from $3.5 million in the three months ended June 30, 2020. The decrease in the three months ending June 30, 2021, was driven by shipments of electrical control systems ("ECS") to Doosan in the three months ended June 30, 2020 with no similar shipments in the current year period. Inox, historically one of the largest customers of our Wind business unit has had and may in the future have its ability to perform under our ECS supply contract hampered by the prolonged impacts of the COVID-19 pandemic. Inox has been active in the new central and state government auction regime in India and has a cumulative order book of over 1.4 GW. We are parties to a technology transfer & license agreement dated as of April 17, 2009, as amended (the “2009 TTLA”) with Inox for a 2 MW class wind turbine, the manufacture of which requires our ECS.  On July 21, 2021, we sent written notice to Inox notifying Inox of its default under the 2009 TTLA due to Inox’s failure to pay royalties for commissioned 2 MW wind turbines in the amount of €0.7 million that Inox is obligated to pay under the terms of the 2009 TTLA.  If Inox fails to pay such royalties in the amount of €0.7 million in accordance with the terms of the 2009 TTLA within the thirty working day cure period after receipt of the default notice, then we may terminate the 2009 TTLA by providing written notice of such termination to Inox.  We cannot predict if and when Inox will pay royalties due and payable under the 2009 TTLA. In the event we were to terminate the 2009 TTLA, Inox would no longer be able to manufacture 2 MW wind turbines, likely result in a decrease in Inox’s demand for our ECS and our revenues and liquidity could be impacted. We cannot predict if and how successful Inox will be in executing on these orders or in obtaining new orders under the new central and state auction regime. Any failure by Inox to succeed under this regime, or any delay in Inox’s ability to deliver its wind turbines, could result in fewer ECS shipments to Inox.

[0001437749-21-018523:mdna:26]
[same as prior period, unchanged from 0001437749-21-001877:mdna:26]

[0001437749-21-018523:mdna:27]
Cost of revenues increased by 36% to $22.1 million for the three months ended June 30, 2021, compared to $16.2 million for the three months ended June 30, 2020. Gross margin was 13% for the three months ended June 30, 2021, compared to 24% for the three months ended June 30, 2020.  The decrease in gross margin in the three months ended June 30, 2021, was due to an unfavorable product mix and additional cost related to purchase accounting adjustments associated with the Neeltran Acquisition. Cost of revenues includes total amortization expense of less than $0.1 million in the three months ended June 30, 2021, as a result of each of the NEPSI and Neeltran acquired backlog intangible assets.  In addition, a fair value purchase adjustment of approximately $0.3 million for the step-up basis assigned to acquired inventory, to properly reflect the fair value in purchase accounting, was charged to cost of revenues in the three months ended June 30, 2021.

[0001437749-21-018523:mdna:28]
[same as prior period, unchanged from 0001437749-21-001877:mdna:28]

[0001437749-21-018523:mdna:29]
[same as prior period, unchanged from 0001437749-21-001877:mdna:29]

[0001437749-21-018523:mdna:30]
Research and development ("R&D") expenses increased 22% in the three months ended June 30, 2021, to $3.0 million from $2.5 million in the three months ended June 30, 2020.  The increase in R&D expense was due to higher overall compensation expense and less allocation of expenses to cost of goods sold for revenue generating projects in the three months ended June 30, 2021, compared to the three months ended June 30, 2020.

[0001437749-21-018523:mdna:31]
[same as prior period, unchanged from 0001437749-21-001877:mdna:31]

[0001437749-21-018523:mdna:32]
Selling, general and administrative ("SG&A") expenses increased 27% in the three months ended June 30, 2021, to $7.1 million from $5.6 million in the three months ended June 30, 2020. The increase in SG&A expense in the three months ended June 30, 2021 was due to higher overall compensation expense, including stock compensation, than in the prior year period and acquisition related costs due to the Neeltran Acquisition.

[0001437749-21-018523:mdna:33]
[same as prior period, unchanged from 0001437749-21-001877:mdna:33]

[0001437749-21-018523:mdna:34]
We recorded amortization expense related to our core technology and know-how, customer relationships, and other intangible assets of $0.6 million in the three months ended June 30, 2021 and $0.1 million in the three months ended June 30, 2020.  The increase in amortization expense is primarily a result of the acquisitions of NEPSI and Neeltran.

[0001437749-21-018523:mdna:35]
[same as prior period, unchanged from 0001437749-21-001877:mdna:35]

[0001437749-21-018523:mdna:36]
The change in fair value of our contingent consideration for the earnout payment on the NEPSI Acquisition resulted in a loss of $0.1 million in the three months ended June 30, 2021. The change in the fair value was primarily driven by an increased likelihood of achieving certain revenue targets.

[0001437749-21-018523:mdna:37]
[same as prior period, unchanged from 0001437749-21-001877:mdna:37]

[0001437749-21-018523:mdna:38]
[same as prior period, unchanged from 0001437749-21-001877:mdna:38]

[0001437749-21-018523:mdna:39]
|  |  | Three Months Ended June 30, |  |
|  |  | 2021 |  |  | 2020 |  |
| Operating loss: |  |  |  |  |  |  |  |  |
| Grid |  | $ | (5,345 | ) |  | $ | (1,188 | ) |
| Wind |  |  | (763 | ) |  |  | (1,120 | ) |
| Unallocated corporate expenses |  |  | (1,391 | ) |  |  | (909 | ) |
| Total |  | $ | (7,499 | ) |  | $ | (3,217 | ) |

[0001437749-21-018523:mdna:40]
Our Grid business segment generated operating losses of $5.3 million in the three months ended June 30, 2021, compared to $1.2 million in the three months ended June 30, 2020. The increase in the Grid business unit operating loss in the three months ended June 30, 2021, was due to a less favorable product mix and the impact of the purchase accounting adjustments recorded as part of the Neeltran Acquisition including the inventory step up charge noted above and an adjustment which reduced revenue by $0.4 million less than the contract value, to recognize the fair value adjustment related to the acquired customer deposits, in order to properly reflect pre-acquisition activities.

[0001437749-21-018523:mdna:41]
Our Wind business segment generated an operating loss of $0.8 million in the three months ended June 30, 2021, compared to $1.1 million in the three months ended June 30, 2020. The decrease in the Wind business unit operating loss was due to reduced manufacturing overhead associated with consolidating wind manufacturing into our Ayer manufacturing facility in Massachusetts.

[0001437749-21-018523:mdna:42]
Unallocated corporate expenses consist of a loss on contingent consideration of $0.1 million in the three months ended June 30, 2021. Additionally, unallocated corporate expenses consisted of stock-based compensation expense of $1.3 million and $0.9 million in the three months ended June 30, 2021 and 2020, respectively.

[0001437749-21-018523:mdna:43]
[same as prior period, unchanged from 0001437749-21-001877:mdna:45]

[0001437749-21-018523:mdna:44]
Interest income, net, was less than $0.1 million in the three months ended June 30, 2021, compared to $0.2 million in the three months ended June 30, 2020. The decrease in interest income in the three months ended June 30, 2021, was related to a lower cash balance earning lower interest rates than in the prior period.

[0001437749-21-018523:mdna:45]
[same as prior period, unchanged from 0001437749-21-001877:mdna:47]

[0001437749-21-018523:mdna:46]
Other expense, net, was less than $0.1 million in the three months ended June 30, 2021, compared to other expense, net of $0.2 million in the three months ended June 30, 2020.  Other expense, net, during both periods was driven by the impacts of fluctuations in foreign currencies during the respective period.

[0001437749-21-018523:mdna:47]
[same as prior period, unchanged from 0001437749-21-001877:mdna:49]

[0001437749-21-018523:mdna:48]
Income tax benefit was $2.1 million in the three months ended June 30, 2021, and income tax expense was $0.2 million in the three months ended June 30, 2020.  The decrease in income tax expense is a result of the release of the valuation allowance due to the recording of the deferred tax liability from the Neeltran Acquisition.

[0001437749-21-018523:mdna:49]
[same as prior period, unchanged from 0001437749-21-001877:mdna:51]

[0001437749-21-018523:mdna:50]
Net loss was $5.4 million in the three months ended June 30, 2021, compared to $3.4 million in the three months ended June 30, 2020.  The increase in net loss was driven by lower gross margin and higher operating expenses primarily due to acquisition and purchase accounting adjustments in the period ending June 30, 2021.

[0001437749-21-018523:mdna:51]
[same as prior period, unchanged from 0001437749-21-001877:mdna:53]

[0001437749-21-018523:mdna:52]
[same as prior period, unchanged from 0001437749-21-001877:mdna:54]

[0001437749-21-018523:mdna:53]
We define non-GAAP net loss as net loss before stock-based compensation, amortization of acquisition-related intangibles, acquisition costs, change in fair value of contingent consideration, and other non-cash or unusual charges.  We believe non-GAAP net loss assists management and investors in comparing our performance across reporting periods on a consistent basis by excluding these non-cash charges and other items that we do not believe are indicative of our core operating performance. In addition, we use non-GAAP net loss as a factor to evaluate the effectiveness of our business strategies. A reconciliation of GAAP to non-GAAP net loss is set forth in the table below (in thousands, except per share data):

[0001437749-21-018523:mdna:54]
|  |  | Three Months Ended June 30, |  |
|  |  | 2021 |  |  | 2020 |  |
| Net loss |  | $ | (5,403 | ) |  | $ | (3,417 | ) |
| Stock-based compensation |  |  | 1,292 |  |  |  | 909 |  |
| Amortization of acquisition-related intangibles |  |  | 622 |  |  |  | 121 |  |
| Acquisition costs |  |  | 688 |  |  |  | — |  |
| Change in fair value of contingent consideration |  |  | 100 |  |  |  | — |  |
| Non-GAAP net loss |  | $ | (2,701 | ) |  | $ | (2,387 | ) |
| Non-GAAP net loss per share - basic |  | $ | (0.10 | ) |  | $ | (0.11 | ) |
| Weighted average shares outstanding - basic |  |  | 26,826 |  |  |  | 21,689 |  |

[0001437749-21-018523:mdna:55]
We incurred non-GAAP net losses of $2.7 million or $0.10 per share, for the three months ended June 30, 2021, compared to $2.4 million, or $0.11 per share, for the three months ended June 30, 2020. The increase in the non-GAAP net loss was due to a higher operating loss driven by lower gross margin and higher operating expenses.

[0001437749-21-018523:mdna:56]
[same as prior period, unchanged from 0001437749-21-001877:mdna:59]

[0001437749-21-018523:mdna:57]
We have experienced recurring operating losses, and as of June 30, 2021, had an accumulated deficit of $1,006.7 million.

[0001437749-21-018523:mdna:58]
Our cash requirements depend on numerous factors, including the successful completion of our product development activities, our ability to commercialize our REG and ship protection system solutions, the rate of customer and market adoption of our products, collecting receivables according to established terms, the continued availability of U.S. government funding during the product development phase of our superconductor-based products and whether Inox is successful in executing on Solar Energy Corporation of India Limited orders or in obtaining additional orders under the new central and state auction regime. We continue to closely monitor our expenses and, if required, expect to reduce our operating and capital spending to enhance liquidity.

[0001437749-21-018523:mdna:59]
In February 2021, we filed a shelf registration statement on Form S-3 that will expire in February 2024 (the “Form S-3”). The Form S-3 allows us to offer and sell from time-to-time up to $250 million of common stock, debt securities, warrants or units comprised of any combination of these securities. The Form S-3 is intended to provide us flexibility to conduct registered sales of our securities, subject to market conditions, in order to fund our future capital needs. The terms of any future offering under the Form S-3 will be established at the time of such offering and will be described in a prospectus supplement filed with the SEC prior to the completion of any such offering.

[0001437749-21-018523:mdna:60]
As described above, on May 6, 2021, we acquired all of the issued and outstanding shares of capital stock of (i) Neeltran, that supplies rectifiers and transformers to industrial customers, and (ii) International, for: (a) $1.0 million in cash, and (b) 301,556 shares of the Company’s common stock, which were paid and issued to the selling stockholders of Neeltran. We also paid $1.1 million to the selling stockholders of International at closing to pay off previous loans made by them to Neeltran.

[0001437749-21-018523:mdna:61]
Also on May 6, 2021, our wholly-owned Connecticut limited liability company, AMSC Husky LLC, purchased the real property that served as Neeltran’s headquarters for $4.3 million, of which (a) $2.4 million was paid in immediately available funds by AMSC Husky to the owners of such real property, and (b) $1.9 million was paid directly to TD Bank as full payment for the outstanding indebtedness secured by the mortgage on such real property. In addition to the amount paid to discharge the mortgage, we paid approximately $5.7 million directly to other Neeltran lenders at closing to extinguish outstanding Neeltran indebtedness to third parties on behalf of the sellers. All cash payments associated with the Neeltran Acquisition were funded with cash on hand.

[0001437749-21-018523:mdna:62]
As of June 30, 2021, we had cash, cash equivalents, marketable securities and restricted cash of $63.1 million, compared to $80.7 million as of March 31, 2021, a decrease of $17.6 million. As of June 30, 2021, we had approximately $3.3 million of cash, cash equivalents, and restricted cash in foreign bank accounts. Our cash, cash equivalents, marketable securities and restricted cash are summarized as follows (in thousands):

[0001437749-21-018523:mdna:63]
|  |  | June 30, 2021 |  |  | March 31, 2021 |  |
| Cash and cash equivalents |  | $ | 50,070 |  |  | $ | 67,814 |  |
| Marketable securities |  |  | 5,164 |  |  |  | 5,140 |  |
| Restricted cash |  |  | 7,881 |  |  |  | 7,725 |  |
| Total cash, cash equivalents, marketable securities and restricted cash |  | $ | 63,115 |  |  | $ | 80,679 |  |

[0001437749-21-018523:mdna:64]
For the three months ended June 30, 2021, net cash used in operating activities was $5.8 million, compared to $3.1 million for the three months ended June 30, 2020.  The increase in net cash used in operations was due primarily to the deferred income taxes recorded in conjunction with the Neeltran Acquisition during the current year period.

[0001437749-21-018523:mdna:65]
For the three months ended June 30, 2021, net cash used in investing activities was $11.7 million, compared to $0.5 million for the three months ended June 30, 2020. The increase in net cash used in investing activities was primarily due to the cash that was used to pay for the Neeltran Acquisition.

[0001437749-21-018523:mdna:66]
For the three months ended June 30, 2021, net cash used in financing activities was less than $0.1 million compared to $0.4 million in the three months ended June 30, 2020.  The decrease in net cash used in financing activities was due primarily to a decrease in the repurchase of common stock in connection with employee tax obligations upon the vesting of stock awards.

[0001437749-21-018523:mdna:67]
As of June 30, 2021, we had $5.6 million of restricted cash included in long-term assets and $2.3 million of restricted cash included in current assets.  These amounts of restricted cash primarily represent deposits to secure letters of credit for various supply contracts and long-term projects, including the irrevocable letter of credit in the amount of $5.0 million to secure certain of our obligations under the Subcontract Agreement with ComEd. These deposits are held in interest bearing accounts.

[0001437749-21-018523:mdna:68]
We believe we have sufficient available liquidity to fund our operations and capital expenditures for the next twelve months. In addition, we may seek to raise additional capital, which could be in the form of loans, convertible debt or equity, to fund our operating requirements and capital expenditures. Our liquidity is highly dependent on our ability to increase revenues, including our ability to collect revenues under our agreements with Inox, control our operating costs, and raise additional capital, if necessary. There can be no assurance that we will be able to raise additional capital on favorable terms or at all, or execute on any other means of improving our liquidity as described above.  Additionally, the impact of the COVID-19 pandemic on the global financial markets may reduce our ability to raise additional capital, if necessary, which could negatively impact our liquidity.

[0001437749-21-018523:mdna:69]
Legal Proceedings

[0001437749-21-018523:mdna:70]
We are involved in legal and administrative proceedings and claims of various types. See Part II, Item 1, “Legal Proceedings,” for additional information. We record a liability in our consolidated financial statements for these matters when a loss is known or considered probable and the amount can be reasonably estimated. We review these estimates each accounting period as additional information is known and adjust the loss provision when appropriate. If a matter is both probable to result in liability and the amounts of loss can be reasonably estimated, we estimate and disclose the possible loss or range of loss to the extent necessary to make the consolidated financial statements not misleading. If the loss is not probable or cannot be reasonably estimated, a liability is not recorded in our consolidated financial statements.

[0001437749-21-018523:mdna:71]
[same as prior period, unchanged from 0001437749-21-001877:mdna:76]

[0001437749-21-018523:mdna:72]
[same as prior period, unchanged from 0001437749-21-001877:mdna:77]

[0001437749-21-018523:mdna:73]
[same as prior period, unchanged from 0001437749-21-001877:mdna:78]

[0001437749-21-018523:mdna:74]
[same as prior period, unchanged from 0001437749-21-001877:mdna:79]

[0001437749-21-018523:mdna:75]
[same as prior period, unchanged from 0001437749-21-001877:mdna:80]

[0001437749-21-018523:mdna:76]
In June 2016, the FASB issued ASU 2016-13, Financial Instruments-Credit Losses (Topic 326): Measurement of Credit Losses on Financial Instruments. The amendments in ASU 2016-13 provide more decision-useful information about the expected credit losses on financial instruments and other commitments to extend credit held by a reporting entity at each reporting date. Following the release of ASU 2019-10 in November 2019, the new effective date, as long as the Company remains a smaller reporting company, would be annual reporting periods beginning after December 15, 2022.   We are currently evaluating the impact, if any, that the adoption of ASU 2016-13 may have on our consolidated financial statements.

[0001437749-21-018523:mdna:77]
In December 2019, the FASB issued ASU 2019-12, Income Taxes (Topic 740): Simplifying the Accounting for Income Taxes. The amendments in ASU 2019-12 provide for simplified accounting to several income tax situations and removal of certain accounting exceptions.  As of April 1, 2021, we have adopted ASU 2019-12 and noted no material impact on our consolidated financial statements.

[0001437749-21-018523:mdna:78]
We do not believe that, outside of those disclosed here, there are any other recently issued accounting pronouncements that will have a material impact on our consolidated financial statements.
