# AMSC note change history — 0001437749-21-001877 → 0001437749-21-018523


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- added (2021-08-04):
[0001437749-21-018523:note_history:1]
As of  June 30, 2021, the Company had $5.6 million of restricted cash included in long-term assets and $2.3 million of restricted cash included in current assets. As of  March 31, 2021, the Company had $5.6 million of restricted cash included in long term assets and $2.2 million of restricted cash included in current assets. These amounts included in restricted cash primarily represent deposits to secure letters of credit for various supply contracts and long-term projects, including the irrevocable letter of credit in the amount of $5.0 million to secure certain of the Company's obligations under a subcontract agreement with ComEd.  These deposits are held in interest bearing accounts.

- removed (2021-08-04):
[0001437749-21-001877:note_history:2]
As of

- removed (2021-08-04):
[0001437749-21-001877:note_history:3]
December 31, 2020

- removed (2021-08-04):
[0001437749-21-001877:note_history:4]
, and

- removed (2021-08-04):
[0001437749-21-001877:note_history:5]
March 31, 2020

- removed (2021-08-04):
[0001437749-21-001877:note_history:6]
, the Company had $

- removed (2021-08-04):
[0001437749-21-001877:note_history:7]
5.6

- removed (2021-08-04):
[0001437749-21-001877:note_history:8]
million of restricted cash included in long-term assets and $

- removed (2021-08-04):
[0001437749-21-001877:note_history:9]
0.6

- removed (2021-08-04):
[0001437749-21-001877:note_history:10]
million of restricted cash included in current assets, respectively. These amounts included in restricted cash primarily represent deposits to secure letters of credit for various supply contracts and long-term projects, including the irrevocable letter of credit in the amount of 
$5.0
 million to secure certain of the Company's obligations under the Subcontract Agreement with ComEd.  These deposits are held in interest bearing accounts.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- added (2021-08-04):
[0001437749-21-018523:note_history:11]
American Superconductor Corporation (together with its subsidiaries, “AMSC®” or the “Company”) was founded on  April 9, 1987. The Company is a leading system provider of megawatt-scale power resiliency solutions that Orchestrate the Rhythm and Harmony of Power on the Grid™ and that protect and expand the capability of the Navy’s fleet. The Company’s system level products leverage its proprietary “smart materials” and “smart software and controls” to provide enhanced resiliency and improved performance of megawatt-scale power flow.

- changed (2021-08-04):
[0001437749-21-018523:note_history:12]
These unaudited condensed consolidated financial statements of the Company have been prepared on a going concern basis in accordance with United States generally accepted accounting principles (“GAAP”) and the Securities and Exchange Commission’s (“SEC”) instructions to Form 10-Q. The going concern basis of presentation assumes that the Company will continue operations and will be able to realize its assets and discharge its liabilities and commitments in the normal course of business. Certain information and footnote disclosures normally included in the financial statements prepared in accordance with GAAP have been condensed or omitted pursuant to those instructions. The year-end condensed balance sheet data was derived from audited financial statements but does not include all disclosures required by GAAP. The unaudited condensed consolidated financial statements, in the opinion of management, reflect all adjustments (consisting of normal recurring adjustments) necessary for a fair statement of the results for the interim periods ended  June 30, 2021 and 2020 and the financial position at  June 30, 2021; however, these results are not necessarily indicative of results which  may be expected for the full year. The interim condensed consolidated financial statements, and notes thereto, should be read in conjunction with the audited consolidated financial statements for the year ended  March 31, 2021, and notes thereto, included in the Company’s Annual Report on Form 10-K for the year ended  March 31, 2021 filed with the SEC on  June 2, 2021.
  (was, 2021-02-03, similarity 0.8139):
[0001437749-21-001877:note_history:12]
These unaudited condensed consolidated financial statements of the Company have been prepared on a going concern basis in accordance with United States generally accepted accounting principles (“GAAP”) and the Securities and Exchange Commission's (“SEC”) instructions to Form 
10
-Q. The going concern basis of presentation assumes that the Company will continue operations and will be able to realize its assets and discharge its liabilities and commitments in the normal course of business. Certain information and footnote disclosures normally included in the financial statements prepared in accordance with GAAP have been condensed or omitted pursuant to those instructions. The year-end condensed balance sheet data was derived from audited financial statements but does 
not
 include all disclosures required by GAAP. The unaudited condensed consolidated financial statements, in the opinion of management, reflect all adjustments (consisting of normal recurring adjustments) necessary for a fair statement of the results for the interim periods ended

- added (2021-08-04):
[0001437749-21-018523:note_history:13]
The Company has historically experienced recurring operating losses and as of  June 30, 2021, the Company had an accumulated deficit of $1,006.7 million. In addition, the Company has historically experienced recurring negative operating cash flows.  At  June 30, 2021, the Company had cash, cash equivalents, and marketable securities of $55.2 million. Marketable securities include certificate of deposits with maturities of less than three months.  Cash used in operations for the three months ended  June 30, 2021 was $5.8 million.

- added (2021-08-04):
[0001437749-21-018523:note_history:14]
In  February 2021, the Company filed a shelf registration statement on Form S-3 that will expire in  February 2024 (the “Form S-3”). The Form S-3 allows the Company to offer and sell from time-to-time up to $250 million of common stock, debt securities, warrants or units comprised of any combination of these securities. The Form S-3 is intended to provide the Company flexibility to conduct registered sales of the Company's securities, subject to market conditions, in order to fund the Company's future capital needs. The terms of any future offering under the Form S-3 will be established at the time of such offering and will be described in a prospectus supplement filed with the SEC prior to the completion of any such offering.

- added (2021-08-04):
[0001437749-21-018523:note_history:15]
On  May 6, 2021 (the "Neeltran Acquisition Date"), the Company entered into a Purchase and Sale Agreement (the "Real Property Purchase Agreement") and a Stock Purchase Agreement (the "Neeltran Stock Purchase Agreement") with the selling equity holders named therein. Also on  May 6, 2021, pursuant to the Real Property Purchase Agreement, the Company's wholly-owned Connecticut limited liability company, AMSC Husky LLC ("AMSC Husky"), purchased the real property that served as Neeltran's headquarters for $4.3 million, of which (a) $2.4 million was paid in immediately available funds by AMSC Husky to the owners of such real property, and (b) $1.9 million was paid directly to TD Bank as full payment for the outstanding indebtedness secured by the mortgage on such real property.  Pursuant to the terms of the Neeltran Stock Purchase Agreement and concurrently with entering into such agreement, the Company purchased all of the issued and outstanding shares of capital stock of (i) Neeltran, Inc., a Connecticut corporation ("Neeltran") that supplies rectifiers and transformers to industrial customers, and (ii) Neeltran International, Inc., a Connecticut corporation ("International"), for: (a) $1.0 million in cash, and (b) 301,556 shares of the Company's common stock, $.01 par value per share (the "AMSC Shares"), that were paid and issued to the Neeltran selling stockholders, respectively at closing (the "Neeltran Acquisition"). The Company also paid $1.1 million to International selling stockholders at closing to pay off previous loans made by them to Neeltran. Additionally, the Company paid approximately $7.6 million on behalf of the selling equity holders, including $1.9 million of indebtedness secured by the mortgage on the real property as described above, directly to Neeltran lenders at closing to extinguish outstanding Neeltran indebtedness to third parties on behalf of the sellers.

- changed (2021-08-04):
[0001437749-21-018523:note_history:16]
In  March 2020, the World Health Organization declared the disease caused by the novel coronavirus, COVID-19, to be a pandemic. COVID-19 has spread throughout the globe, including in the Commonwealth of Massachusetts where the Company’s headquarters are located, and in other areas where the Company has business operations. In response to the outbreak, the Company has followed the guidelines of the U.S. Centers for Disease Control and Prevention and applicable state government authorities to protect the health and safety of the Company’s employees, families, suppliers, customers and communities. While these existing measures and, COVID-19 generally, have not materially disrupted the Company’s business to date, any future actions necessitated by the COVID-19 pandemic  may result in disruption to the Company’s business.
  (was, 2021-02-03, similarity 0.9927):
[0001437749-21-001877:note_history:16]
In 
 March 2020, 
the World Health Organization declared the disease caused by the novel coronavirus, COVID-
19,
 to be a pandemic. COVID-
19
 has spread throughout the globe, including in the Commonwealth of Massachusetts where the Company's headquarters are located, and in other areas where the Company has business operations. In response to the outbreak, the Company has followed the guidelines of the U.S. Centers for Disease Control and Prevention and applicable state government authorities to protect the health and safety of the Company's employees, families, suppliers, customers and communities. While these existing measures and, COVID-
19
 generally, have 
not
 materially disrupted the Company's business to date, any future actions necessitated by the COVID-
19
 pandemic 
 may 
result in disruption to the Company's business.

- added (2021-08-04):
[0001437749-21-018523:note_history:17]
While the COVID-19 pandemic continues to rapidly evolve, the Company continues to assess the impact of the COVID-19 pandemic to best mitigate risk and continue the operations of the Company’s business. The extent to which the outbreak impacts the Company’s business, liquidity, results of operations and financial condition will depend on future developments, which are highly uncertain and cannot be predicted with confidence, including new information that  may emerge concerning the severity of the COVID-19 pandemic, the spread of new variations of the virus, the actions to contain it or treat its impact and the effectiveness and adoption of vaccines, among others.  If the Company, its customers or suppliers experience prolonged shutdowns or other business disruptions, the Company’s business, liquidity, results of operations and financial condition are likely to be materially adversely affected, and the Company’s ability to access the capital markets  may be limited.

- added (2021-08-04):
[0001437749-21-018523:note_history:18]
The Company believes that based on the information presented above and its quarterly management assessment, it has sufficient liquidity to fund its operations and capital expenditures for the next twelve months following the issuance of the financial statements for the three months ended  June 30, 2021. The Company’s liquidity is highly dependent on its ability to increase revenues, including its ability to collect revenues under its agreements with Inox, its ability to control its operating costs, and its ability to raise additional capital, if necessary.  The impact of the COVID-19 pandemic on the global financing markets  may reduce the Company's ability to raise additional capital, if necessary, which could negatively impact the Company's liquidity.  There can be no assurance that the Company will be able to continue to raise additional capital, on favorable terms or at all, from other sources or execute on any other means of improving liquidity described above.

- removed (2021-08-04):
[0001437749-21-001877:note_history:19]
American Superconductor Corporation (together with its subsidiaries, “AMSC®” or the “Company”) was founded on 
 April

- removed (2021-08-04):
[0001437749-21-001877:note_history:20]
9,

- removed (2021-08-04):
[0001437749-21-001877:note_history:21]
1987.
 The Company is a leading system provider of megawatt-scale power resiliency solutions that Orchestrate the Rhythm and Harmony of Power on the Grid
™
 and that protect and expand the capability of the Navy's fleet. The Company's system level products leverage its proprietary “smart materials” and “smart software and controls” to provide enhanced resiliency and improved performance of megawatt-scale power flow.

- removed (2021-08-04):
[0001437749-21-001877:note_history:22]
December 31, 2020

- removed (2021-08-04):
[0001437749-21-001877:note_history:23]
and

- removed (2021-08-04):
[0001437749-21-001877:note_history:24]
2019

- removed (2021-08-04):
[0001437749-21-001877:note_history:25]
and the financial position at

- removed (2021-08-04):
[0001437749-21-001877:note_history:26]
December 31, 2020

- removed (2021-08-04):
[0001437749-21-001877:note_history:27]
; however, these results are 
not
 necessarily indicative of results which 
 may 
be expected for the full year. The interim condensed consolidated financial statements, and notes thereto, should be read in conjunction with the audited consolidated financial statements for the year ended

- removed (2021-08-04):
[0001437749-21-001877:note_history:28]
March 31, 2020

- removed (2021-08-04):
[0001437749-21-001877:note_history:29]
, and notes thereto, included in the Company's Annual Report on Form 
10
-K for the year ended

- removed (2021-08-04):
[0001437749-21-001877:note_history:30]
March 31, 2020

- removed (2021-08-04):
[0001437749-21-001877:note_history:31]
filed with the SEC on 
 June 2, 2020.

- removed (2021-08-04):
[0001437749-21-001877:note_history:32]
The Company has historically experienced recurring operating losses and as of

- removed (2021-08-04):
[0001437749-21-001877:note_history:33]
December 31, 2020

- removed (2021-08-04):
[0001437749-21-001877:note_history:34]
, the Company had an accumulated deficit of $

- removed (2021-08-04):
[0001437749-21-001877:note_history:35]
993.7

- removed (2021-08-04):
[0001437749-21-001877:note_history:36]
million. In addition, the Company has historically experienced recurring negative operating cash flows.  At

- removed (2021-08-04):
[0001437749-21-001877:note_history:37]
December 31, 2020

- removed (2021-08-04):
[0001437749-21-001877:note_history:38]
, the Company had cash, cash equivalents, and marketable securities of $

- removed (2021-08-04):
[0001437749-21-001877:note_history:39]
78.1

- removed (2021-08-04):
[0001437749-21-001877:note_history:40]
million. Marketable securities include certificate of deposits with maturities between 
three
 and 
nine
 months.  Cash used in operations for the

- removed (2021-08-04):
[0001437749-21-001877:note_history:41]
nine

- removed (2021-08-04):
[0001437749-21-001877:note_history:42]
months ended

- removed (2021-08-04):
[0001437749-21-001877:note_history:43]
December 31, 2020

- removed (2021-08-04):
[0001437749-21-001877:note_history:44]
was $

- removed (2021-08-04):
[0001437749-21-001877:note_history:45]
4.9

- removed (2021-08-04):
[0001437749-21-001877:note_history:46]
million.

- removed (2021-08-04):
[0001437749-21-001877:note_history:47]
In 
 December 2015, 
the Company entered into a set of strategic agreements valued at approximately 
$210.0
 million with Inox Wind Ltd. (“Inox” or “Inox Wind”), which includes a multi-year supply contract pursuant to which the Company will supply electrical control systems ("ECS") to Inox and a license agreement allowing Inox to manufacture a limited number of ECS. After Inox purchases the specified number of ECS required under the terms of the supply contract, Inox agreed that the Company will continue as Inox's preferred supplier and Inox will be required to purchase from the Company a majority of its ECS requirements for an additional 
three
-year period. Pursuant to these strategic agreements, Inox must forecast future purchase orders of sets of ECS which become firm orders 
three
 months prior to shipment, and Inox must post letters of credit before the Company will ship such orders. Inox had been delinquent on its obligation to post letters of credit for sets of ECS that Inox forecasted to purchase under the terms of the supply contract.  On 
 May 29, 2020, 
the Company sent written notice to Inox notifying Inox of its default under the supply contract due to Inox's failure to post letters of credit in the amount of 
€6.0
 million for the payment of ECS that Inox is obligated to purchase under the terms of the supply contract.  If Inox failed to post letters of credit in the amount of 
€6.0
 million in accordance with the terms of the supply contract within the 
ninety
 day cure period after receipt of the default notice, then the Company could have terminated the supply contract by providing written notice of such termination to Inox.  On 
 September 2, 2020, 
Inox delivered approved letters of credit in the amount of 
€1.3
 million for the payment of a portion of the ECS that Inox was obligated to purchase under the terms of the supply contract.  On 
 September 11, 2020, 
the Company notified Inox that due to (i) the Company's business relationship with Inox, and (ii) Inox's delivery of approved letters of credit in the amount of 
€1.3
 million as described above, the Company gave Inox until 
 October 5, 2020 
to regain compliance with the terms of the supply contract by providing approved letters of credit in the amount of 
€4.7
 million for payment of the remaining ECS that Inox currently was obligated to purchase under the terms of the supply contract.  On 
 October 1, 2020, 
Inox delivered approved letters of credit for payment of the remaining ECS that Inox was obligated to purchase under the terms of the supply contract and cured the default set forth in the 
 May 29, 2020 
default notice.

- removed (2021-08-04):
[0001437749-21-001877:note_history:48]
On 
 October 1, 2020 (
the "Acquisition Date"), the Company entered into a Stock Purchase Agreement (the “Stock Purchase Agreement”) with the selling stockholders named therein.  Pursuant to the terms of the Stock Purchase Agreement and concurrently with entering into such agreement, the Company acquired all of the issued and outstanding (i) shares of capital stock of Northeast Power Systems, Inc., a New York corporation (“NEPSI”), and (ii) membership interests of Northeast Power Realty, LLC, a New York limited liability company, which holds the real property that serves as NEPSI's headquarters (the "Acquisition"). NEPSI is a U.S.-based global provider of medium-voltage metal-enclosed power capacitor banks and harmonic filter banks for use on electric power systems. NEPSI is now a wholly-owned subsidiary of the Company and is operated by its Grid business unit. The purchase price was 
$26.0
 million in cash and 
873,657
 restricted shares of common stock of the Company.  As part of the transaction, the selling stockholders 
 may 
receive up to an additional 
1,000,000
 shares of common stock of the Company upon the achievement of certain specified revenue objectives in the future.

- removed (2021-08-04):
[0001437749-21-001877:note_history:49]
On 
 October 22, 2020, 
the Company entered into an underwriting agreement with Oppenheimer & Co. Inc., as representative of the several underwriters named therein, relating to the issuance and sale (the “Offering”) of 
3,670,000
 shares of the Company's common stock at a public offering price of 
$15.00
 per share. The net proceeds to the Company from the Offering were approximately 
$51.5
 million, after deducting underwriting discounts and commissions and offering expenses payable by the Company. The Offering closed on 
 October 26, 2020. 
In addition, the Company had granted the underwriters a 
30
-day option to purchase up to an additional 
550,500
 shares of common stock at the public offering price which was 
not
 exercised.

- removed (2021-08-04):
[0001437749-21-001877:note_history:50]
While the COVID-
19
 pandemic continues to rapidly evolve, the Company continues to assess the impact of the COVID-
19
 pandemic to best mitigate risk and continue the operations of the Company's business. The extent to which the outbreak impacts the Company's business, liquidity, results of operations and financial condition will depend on future developments, which are highly uncertain and cannot be predicted with confidence, including new information that 
 may 
emerge concerning the severity of the COVID-
19
 pandemic and the actions to contain it or treat its impact, among others.  If the Company, its customers or suppliers experience prolonged shutdowns or other business disruptions, the Company's business, liquidity, results of operations and financial condition are likely to be materially adversely affected, and the Company's ability to access the capital markets 
 may 
be limited.

- removed (2021-08-04):
[0001437749-21-001877:note_history:51]
The Company believes that based on the information presented above and its quarterly management assessment, it has sufficient liquidity to fund its operations and capital expenditures for the next 
twelve
 months following the issuance of the financial statements for the

- removed (2021-08-04):
[0001437749-21-001877:note_history:52]
nine

- removed (2021-08-04):
[0001437749-21-001877:note_history:53]
months ended

- removed (2021-08-04):
[0001437749-21-001877:note_history:54]
December 31, 2020

- removed (2021-08-04):
[0001437749-21-001877:note_history:55]
. The Company's liquidity is highly dependent on its ability to increase revenues, including its ability to collect revenues under its agreements with Inox, its ability to control its operating costs, and its ability to raise additional capital, if necessary.  The impact of the COVID-
19
 pandemic on the global financing markets 
 may 
reduce the Company's ability to raise additional capital, if necessary, which could negatively impact the Company's liquidity.  There can be 
no
 assurance that the Company will be able to continue to raise additional capital, on favorable terms or at all, from other sources or execute on any other means of improving liquidity described above.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: no_prior_note, score: 0.0

- added (2021-08-04):
[0001437749-21-018523:note_history:56]
14. Debt

- added (2021-08-04):
[0001437749-21-018523:note_history:57]
As part of the Neeltran Acquisition, the Company identified four equipment financing agreements that Neeltran had entered into prior to the acquisition on  May 6, 2021. The Company determined to account for these agreements as a debt transaction and recorded current and long-term debt liabilities of $0.1 million each during the three months ended  June 30, 2021.


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2021-08-04):
[0001437749-21-018523:note_history:58]
|  |  | Three Months Ended June 30, 2021 |  |
| Product Line: |  | Grid |  |  | Wind |  |
| Equipment and systems |  | $ | 21,159 |  |  | $ | 1,033 |  |
| Services and technology development |  |  | 2,342 |  |  |  | 886 |  |
| Total |  | $ | 23,501 |  |  | $ | 1,919 |  |
| Region: |  |  |  |  |  |  |  |  |
| Americas |  | $ | 22,645 |  |  | $ | 19 |  |
| Asia Pacific |  |  | 598 |  |  |  | 1,870 |  |
| EMEA |  |  | 258 |  |  |  | 30 |  |
| Total |  | $ | 23,501 |  |  | $ | 1,919 |  |
  (was, 2021-02-03, similarity 0.7051):
[0001437749-21-001877:note_history:58]
|  |  | Three Months Ended December 31, 2020 |  |  | Nine Months Ended December 31, 2020 |  |
| Product Line: |  | Grid |  |  | Wind |  |  | Grid |  |  | Wind |  |
| Equipment and systems |  | $ | 15,930 |  |  | $ | 6,153 |  |  | $ | 47,729 |  |  | $ | 12,828 |  |
| Services and technology development |  |  | 1,156 |  |  |  | 393 |  |  |  | 3,420 |  |  |  | 1,984 |  |
| Total |  | $ | 17,086 |  |  | $ | 6,546 |  |  | $ | 51,149 |  |  | $ | 14,812 |  |
| Region: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas |  | $ | 13,394 |  |  | $ | 14 |  |  | $ | 39,626 |  |  | $ | 56 |  |
| Asia Pacific |  |  | 351 |  |  |  | 6,461 |  |  |  | 6,736 |  |  |  | 14,463 |  |
| EMEA |  |  | 3,341 |  |  |  | 71 |  |  |  | 4,787 |  |  |  | 293 |  |
| Total |  | $ | 17,086 |  |  | $ | 6,546 |  |  | $ | 51,149 |  |  | $ | 14,812 |  |

- changed (2021-08-04):
[0001437749-21-018523:note_history:59]
|  |  | Three Months Ended June 30, 2020 |  |
| Product Line: |  | Grid |  |  | Wind |  |
| Equipment and systems |  | $ | 16,537 |  |  | $ | 2,618 |  |
| Services and technology development |  |  | 1,178 |  |  |  | 880 |  |
| Total |  | $ | 17,715 |  |  | $ | 3,498 |  |
| Region: |  |  |  |  |  |  |  |  |
| Americas |  | $ | 10,554 |  |  | $ | 12 |  |
| Asia Pacific |  |  | 6,015 |  |  |  | 3,269 |  |
| EMEA |  |  | 1,146 |  |  |  | 217 |  |
| Total |  | $ | 17,715 |  |  | $ | 3,498 |  |
  (was, 2021-02-03, similarity 0.7051):
[0001437749-21-001877:note_history:59]
|  |  | Three Months Ended December 31, 2019 |  |  | Nine Months Ended December 31, 2019 |  |
| Product Line: |  | Grid |  |  | Wind |  |  | Grid |  |  | Wind |  |
| Equipment and systems |  | $ | 14,040 |  |  | $ | 2,160 |  |  | $ | 32,438 |  |  | $ | 7,742 |  |
| Services and technology development |  |  | 1,192 |  |  |  | 523 |  |  |  | 4,139 |  |  |  | 1,379 |  |
| Total |  | $ | 15,232 |  |  | $ | 2,683 |  |  | $ | 36,577 |  |  | $ | 9,120 |  |
| Region: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas |  | $ | 10,164 |  |  | $ | 2 |  |  | $ | 28,663 |  |  | $ | 49 |  |
| Asia Pacific |  |  | 330 |  |  |  | 2,647 |  |  |  | 2,550 |  |  |  | 8,968 |  |
| EMEA |  |  | 4,738 |  |  |  | 34 |  |  |  | 5,364 |  |  |  | 104 |  |
| Total |  | $ | 15,232 |  |  | $ | 2,683 |  |  | $ | 36,577 |  |  | $ | 9,120 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- added (2021-08-04):
[0001437749-21-018523:note_history:60]
The Company’s revenues in its Grid business segment are derived primarily through enabling the transmission and distribution of power, providing planning services that allow it to identify power grid needs and risks, and developing ship protection systems for the U.S. Navy. The Company’s revenues in its Wind business segment are derived primarily through supplying advanced power electronics and control systems, licensing its highly engineered wind turbine designs, and providing extensive customer support services to wind turbine manufacturers. The Company records revenue based on a five-step model in accordance with ASC 606. For its customer contracts, the Company identifies the performance obligations, determines the transaction price, allocates the contract transaction price to the performance obligations, and recognizes the revenue when (or as) control of goods or services is transferred to the customer. In the three months ended  June 30, 2021 and 2020, 78% and 80% of revenue, respectively, was recognized at the point in time when control transferred to the customer, with the remainder being recognized over time.

- changed (2021-08-04):
[0001437749-21-018523:note_history:61]
In the Company's equipment and system product line, each contract with a customer summarizes each product sold to a customer, which typically represents distinct performance obligations. A contract's transaction price is allocated to each distinct performance obligation using the respective standalone selling price which is determined primarily using the cost-plus expected margin approach and recognized as revenue when, or as, the performance obligation is satisfied. The majority of the Company’s product sales transfer control to the customer in line with the contracted delivery terms and revenue is recorded at the point in time when title and risk transfer to the customer, which is primarily upon delivery, as the Company has determined that this is the point in time that control transfers to the customer.
  (was, 2021-02-03, similarity 0.9988):
[0001437749-21-001877:note_history:61]
In the Company's equipment and system product line, each contract with a customer summarizes each product sold to a customer, which typically represents distinct performance obligations. A contract's transaction price is allocated to each distinct performance obligation using the respective standalone selling price which is determined primarily using the cost-plus expected margin approach and recognized as revenue when, or as, the performance obligation is satisfied. The majority of the Company's product sales transfer control to the customer in line with the contracted delivery terms and revenue is recorded at the point in time when title and risk transfer to the customer, which is primarily upon delivery, as the Company has determined that this is the point in time that control transfers to the customer.

- changed (2021-08-04):
[0001437749-21-018523:note_history:62]
The Company's equipment and system product line includes certain contracts which do not meet the requirements of an exchange transaction and therefore do not fall within the scope of ASC 606.  As these non-exchange transaction contracts are considered grant revenue and do not fall within any specific accounting literature, the Company follows guidance within ASC 606 by analogy to recognize grant revenue over time.  In the three months ended  June 30, 2021 and 2020, the Company recorded $0.5 million and $0.4 million in grant revenue, respectively, which is included in the Company’s Grid business segment revenue.
  (was, 2021-02-03, similarity 0.8236):
[0001437749-21-001877:note_history:62]
The Company's equipment and system product line includes certain contracts which do 
not
 meet the requirements of an exchange transaction and therefore do 
not
 fall within the scope of ASC 
606.
  As these non-exchange transaction contracts are considered grant revenue and do 
not
 fall within any specific accounting literature, the Company follows guidance within ASC 
606
 by analogy to recognize grant revenue over time.  In the

- changed (2021-08-04):
[0001437749-21-018523:note_history:63]
The Company’s policy is not to accept volume discounts, product returns, or rebates and allowances within its contracts. In the event a contract was approved with any of these terms, it would be evaluated for variable consideration, estimated and recorded as a reduction of revenue in the same period the related product revenue was recorded.
  (was, 2021-02-03, similarity 0.9971):
[0001437749-21-001877:note_history:63]
The Company's policy is 
not
 to accept volume discounts, product returns, or rebates and allowances within its contracts. In the event a contract was approved with any of these terms, it would be evaluated for variable consideration, estimated and recorded as a reduction of revenue in the same period the related product revenue was recorded.

- changed (2021-08-04):
[0001437749-21-018523:note_history:64]
The Company’s contracts with customers do not typically include extended payment terms and  may include milestone billing over the life of the contract. Payment terms vary by contract type and type of customer and generally range from 30 to 60 days from delivery.
  (was, 2021-02-03, similarity 0.9962):
[0001437749-21-001877:note_history:64]
The Company's contracts with customers do 
not
 typically include extended payment terms and 
 may 
include milestone billing over the life of the contract. Payment terms vary by contract type and type of customer and generally range from 
30
 to 
60
 days from delivery.

- changed (2021-08-04):
[0001437749-21-018523:note_history:65]
The following tables disaggregate the Company’s revenue by product line and by shipment destination (in thousands):
  (was, 2021-02-03, similarity 0.9209):
[0001437749-21-001877:note_history:65]
The following tables disaggregate the Company's revenue by product line and by shipment destination:

- changed (2021-08-04):
[0001437749-21-018523:note_history:66]
|  |  | Three Months Ended June 30, 2021 |  |
| Product Line: |  | Grid |  |  | Wind |  |
| Equipment and systems |  | $ | 21,159 |  |  | $ | 1,033 |  |
| Services and technology development |  |  | 2,342 |  |  |  | 886 |  |
| Total |  | $ | 23,501 |  |  | $ | 1,919 |  |
| Region: |  |  |  |  |  |  |  |  |
| Americas |  | $ | 22,645 |  |  | $ | 19 |  |
| Asia Pacific |  |  | 598 |  |  |  | 1,870 |  |
| EMEA |  |  | 258 |  |  |  | 30 |  |
| Total |  | $ | 23,501 |  |  | $ | 1,919 |  |
  (was, 2021-02-03, similarity 0.7051):
[0001437749-21-001877:note_history:66]
|  |  | Three Months Ended December 31, 2020 |  |  | Nine Months Ended December 31, 2020 |  |
| Product Line: |  | Grid |  |  | Wind |  |  | Grid |  |  | Wind |  |
| Equipment and systems |  | $ | 15,930 |  |  | $ | 6,153 |  |  | $ | 47,729 |  |  | $ | 12,828 |  |
| Services and technology development |  |  | 1,156 |  |  |  | 393 |  |  |  | 3,420 |  |  |  | 1,984 |  |
| Total |  | $ | 17,086 |  |  | $ | 6,546 |  |  | $ | 51,149 |  |  | $ | 14,812 |  |
| Region: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas |  | $ | 13,394 |  |  | $ | 14 |  |  | $ | 39,626 |  |  | $ | 56 |  |
| Asia Pacific |  |  | 351 |  |  |  | 6,461 |  |  |  | 6,736 |  |  |  | 14,463 |  |
| EMEA |  |  | 3,341 |  |  |  | 71 |  |  |  | 4,787 |  |  |  | 293 |  |
| Total |  | $ | 17,086 |  |  | $ | 6,546 |  |  | $ | 51,149 |  |  | $ | 14,812 |  |

- changed (2021-08-04):
[0001437749-21-018523:note_history:67]
|  |  | Three Months Ended June 30, 2020 |  |
| Product Line: |  | Grid |  |  | Wind |  |
| Equipment and systems |  | $ | 16,537 |  |  | $ | 2,618 |  |
| Services and technology development |  |  | 1,178 |  |  |  | 880 |  |
| Total |  | $ | 17,715 |  |  | $ | 3,498 |  |
| Region: |  |  |  |  |  |  |  |  |
| Americas |  | $ | 10,554 |  |  | $ | 12 |  |
| Asia Pacific |  |  | 6,015 |  |  |  | 3,269 |  |
| EMEA |  |  | 1,146 |  |  |  | 217 |  |
| Total |  | $ | 17,715 |  |  | $ | 3,498 |  |
  (was, 2021-02-03, similarity 0.7051):
[0001437749-21-001877:note_history:67]
|  |  | Three Months Ended December 31, 2019 |  |  | Nine Months Ended December 31, 2019 |  |
| Product Line: |  | Grid |  |  | Wind |  |  | Grid |  |  | Wind |  |
| Equipment and systems |  | $ | 14,040 |  |  | $ | 2,160 |  |  | $ | 32,438 |  |  | $ | 7,742 |  |
| Services and technology development |  |  | 1,192 |  |  |  | 523 |  |  |  | 4,139 |  |  |  | 1,379 |  |
| Total |  | $ | 15,232 |  |  | $ | 2,683 |  |  | $ | 36,577 |  |  | $ | 9,120 |  |
| Region: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas |  | $ | 10,164 |  |  | $ | 2 |  |  | $ | 28,663 |  |  | $ | 49 |  |
| Asia Pacific |  |  | 330 |  |  |  | 2,647 |  |  |  | 2,550 |  |  |  | 8,968 |  |
| EMEA |  |  | 4,738 |  |  |  | 34 |  |  |  | 5,364 |  |  |  | 104 |  |
| Total |  | $ | 15,232 |  |  | $ | 2,683 |  |  | $ | 36,577 |  |  | $ | 9,120 |  |

- added (2021-08-04):
[0001437749-21-018523:note_history:68]
As of  June 30, 2021, and 2020, the Company’s contract assets and liabilities primarily relate to the timing differences between cash received from a customer in connection with contractual rights to invoicing and the timing of revenue recognition following completion of performance obligations. The Company's accounts receivable balance is made up entirely of customer contract related balances. Changes in the Company’s contract assets, which are included in “Unbilled accounts receivable” and “Deferred program costs” (see Note 8, “Accounts Receivable” and Note 9, “Inventory” for a reconciliation to the condensed consolidated balance sheets) and "Contract liabilities", which are included in the current portion and long-term portion of "Deferred revenue" in the Company’s condensed consolidated balance sheets, are as follows (in thousands):

- changed (2021-08-04):
[0001437749-21-018523:note_history:69]
|  |  | Unbilled Accounts Receivable |  |  | Deferred Program Costs |  |  | Contract Liabilities |  |
| Beginning balance as of March 31, 2021 |  | $ | 5,765 |  |  | $ | 978 |  |  | $ | 21,258 |  |
| Increases for costs incurred to fulfill performance obligations |  |  | — |  |  |  | 1,434 |  |  |  | — |  |
| Increase for balances acquired |  |  | — |  |  |  | 634 |  |  |  | 10,048 |  |
| Increase (decrease) due to customer billings |  |  | (1,564 | ) |  |  | — |  |  |  | 21,425 |  |
| Decrease due to cost recognition on completed performance obligations |  |  | — |  |  |  | (2,041 | ) |  |  | — |  |
| Increase (decrease) due to recognition of revenue based on transfer of control of performance obligations |  |  | 4,360 |  |  |  | — |  |  |  | (24,355 | ) |
| Other changes and FX impact |  |  | — |  |  |  | 3 |  |  |  | 246 |  |
| Ending balance as of June 30, 2021 |  | $ | 8,561 |  |  | $ | 1,008 |  |  | $ | 28,622 |  |
  (was, 2021-02-03, similarity 0.9799):
[0001437749-21-001877:note_history:69]
|  |  | Unbilled Accounts Receivable |  |  | Deferred Program Costs |  |  | Contract Liabilities |  |
| Beginning balance as of March 31, 2020 |  | $ | 5,711 |  |  | $ | 1,631 |  |  | $ | 26,142 |  |
| Increases for costs incurred to fulfill performance obligations |  |  | — |  |  |  | 6,635 |  |  |  | — |  |
| Increase for balances acquired |  |  | 101 |  |  |  | — |  |  |  | 2,700 |  |
| Increase (decrease) due to customer billings |  |  | (8,255 | ) |  |  | — |  |  |  | 42,785 |  |
| Decrease due to cost recognition on completed performance obligations |  |  | — |  |  |  | (6,969 | ) |  |  | — |  |
| Increase (decrease) due to recognition of revenue based on transfer of control of performance obligations |  |  | 6,644 |  |  |  | — |  |  |  | (48,274 | ) |
| Other changes and FX impact |  |  | — |  |  |  | 33 |  |  |  | 1,025 |  |
| Ending balance as of December 31, 2020 |  | $ | 4,201 |  |  | $ | 1,330 |  |  | $ | 24,378 |  |

- changed (2021-08-04):
[0001437749-21-018523:note_history:70]
|  |  | Unbilled Accounts Receivable |  |  | Deferred Program Costs |  |  | Contract Liabilities |  |
| Beginning balance as of March 31, 2020 |  | $ | 5,711 |  |  | $ | 1,631 |  |  | $ | 26,142 |  |
| Increases for costs incurred to fulfill performance obligations |  |  | — |  |  |  | 1,978 |  |  |  | — |  |
| Increase (decrease) due to customer billings |  |  | (3,620 | ) |  |  | — |  |  |  | 12,276 |  |
| Decrease due to cost recognition on completed performance obligations |  |  | — |  |  |  | (2,815 | ) |  |  | — |  |
| Increase (decrease) due to recognition of revenue based on transfer of control of performance obligations |  |  | 2,033 |  |  |  | — |  |  |  | (16,227 | ) |
| Other changes and FX impact |  |  | 1 |  |  |  | 7 |  |  |  | 194 |  |
| Ending balance as of June 30, 2020 |  | $ | 4,125 |  |  | $ | 801 |  |  | $ | 22,385 |  |
  (was, 2021-02-03, similarity 0.9192):
[0001437749-21-001877:note_history:70]
|  |  | Unbilled Accounts Receivable |  |  | Deferred Program Costs |  |  | Contract Liabilities |  |
| Beginning balance as of March 31, 2019 |  | $ | 2,213 |  |  | $ | 318 |  |  | $ | 15,519 |  |
| Increases for costs incurred to fulfill performance obligations |  |  | — |  |  |  | 3,001 |  |  |  | — |  |
| Increase (decrease) due to customer billings |  |  | (7,417 | ) |  |  | — |  |  |  | 36,461 |  |
| Decrease due to cost recognition on completed performance obligations |  |  | — |  |  |  | (2,221 | ) |  |  | — |  |
| Increase (decrease) due to recognition of revenue based on transfer of control of performance obligations |  |  | 9,820 |  |  |  | — |  |  |  | (28,768 | ) |
| Other changes and FX impact |  |  | (3 | ) |  |  | (1 | ) |  |  | (69 | ) |
| Ending balance as of December 31, 2019 |  | $ | 4,613 |  |  | $ | 1,097 |  |  | $ | 23,143 |  |

- added (2021-08-04):
[0001437749-21-018523:note_history:71]
The Company’s remaining performance obligations represent the unrecognized revenue value of the Company’s contractual commitments. The Company’s performance obligations  may vary significantly each reporting period based on the timing of major new contractual commitments. As of  June 30, 2021, the Company had outstanding performance obligations on existing contracts under ASC 606 to be recognized in the next twelve months of approximately $86.9 million. There are also approximately $15.9 million of outstanding performance obligations to be recognized over a period of thirteen to sixty months. The remaining performance obligations are subject to customer actions and therefore the timing of revenue recognition cannot be reasonably estimated. The twelve-month performance obligations include anticipated shipments to Inox based on the twelve-month rolling forecast provided by Inox on the multi-year supply contract. The quantities specified in any forecast provided by Inox related to the multi-year supply contract are firm and irrevocable for the first three months of a twelve-month rolling forecast. The timing of the performance obligations beyond the twelve-month forecast provided by Inox are not determinable and therefore are not included in the total remaining performance obligations.

- changed (2021-08-04):
[0001437749-21-018523:note_history:72]
The following table sets forth customers who represented 10% or more of the Company’s total revenues for the three months ended  June 30, 2021 and 2020:
  (was, 2021-02-03, similarity 0.8514):
[0001437749-21-001877:note_history:72]
The following table sets forth customers who represented 
10%
 or more of the Company's total revenues for the

- added (2021-08-04):
[0001437749-21-018523:note_history:73]
|  |  |  | Three Months Ended |  |
|  | Reportable |  | June 30, |  |
|  | Segment |  | 2021 |  |  | 2020 |  |
| Micron Technology | Grid |  |  | 21 | % |  | <10% |  |
| EPC Services | Grid |  |  | <10% |  |  |  | 24 | % |
| Nextera Energy Resources | Grid |  |  | 12 | % |  |  | <10% |  |
| Ascend Performance Materials Ops LLC | Grid |  |  | 10 | % |  |  | 0 | % |
| Siemens Gamesa Renewable Energy Pty. Ltd. | Grid |  |  | <10% |  |  |  | 25 | % |

- removed (2021-08-04):
[0001437749-21-001877:note_history:74]
The Company's revenues in its Grid segment are derived primarily through enabling the transmission and distribution of power, providing planning services that allow it to identify power grid needs and risks, and developing ship protection systems for the U.S. Navy. The Company's revenues in its Wind segment are derived primarily through supplying advanced power electronics and control systems, licensing its highly engineered wind turbine designs, and providing extensive customer support services to wind turbine manufacturers. The Company records revenue based on a 
five
-step model in accordance with ASC 
606,

- removed (2021-08-04):
[0001437749-21-001877:note_history:75]
Revenue from Contracts with Customers
. For its customer contracts, the Company identifies the performance obligations, determines the transaction price, allocates the contract transaction price to the performance obligations, and recognizes the revenue when (or as) control of goods or services is transferred to the customer. In the

- removed (2021-08-04):
[0001437749-21-001877:note_history:76]
three
 and 
nine

- removed (2021-08-04):
[0001437749-21-001877:note_history:77]
months ended

- removed (2021-08-04):
[0001437749-21-001877:note_history:78]
December 31, 2020

- removed (2021-08-04):
[0001437749-21-001877:note_history:79]
,

- removed (2021-08-04):
[0001437749-21-001877:note_history:80]
78

- removed (2021-08-04):
[0001437749-21-001877:note_history:81]
% and

- removed (2021-08-04):
[0001437749-21-001877:note_history:82]
79

- removed (2021-08-04):
[0001437749-21-001877:note_history:83]
% of revenue, respectively, was recognized at the point in time when control transferred to the customer, with the remainder being recognized over time.  In the

- removed (2021-08-04):
[0001437749-21-001877:note_history:84]
three
 and 
nine

- removed (2021-08-04):
[0001437749-21-001877:note_history:85]
months ended

- removed (2021-08-04):
[0001437749-21-001877:note_history:86]
December 31, 2019

- removed (2021-08-04):
[0001437749-21-001877:note_history:87]
, 
57%
 and 
69%,
 respectively, of revenue was recognized at the point in time when control transferred to the customer, with the remainder being recognized over time.

- removed (2021-08-04):
[0001437749-21-001877:note_history:88]
Following the Acquisition of NEPSI, the Company evaluated all open NEPSI contracts at the date of the Acquisition against a 
five
-step model in accordance with ASC 
606
 as NEPSI, as a private company, had deferred adopting 
ASC606
 prior to the Acquisition, as permitted.  The Company identified 
two
 NEPSI revenue streams which are (
1
) the sale of its major components which falls under the equipment and systems product line and (
2
) the sale of spare parts, which falls under the service product line.  Further details on each of these product lines can be found below.  The Company does 
not
 expect a material impact to its consolidated statements of operations on an ongoing basis resulting from the adoption of the ASC 
606
 standard for the NEPSI business, and NEPSI revenue streams will follow the existing policies noted below.

- removed (2021-08-04):
[0001437749-21-001877:note_history:89]
three
 and 
nine
 months ended 
 December 31, 2020

- removed (2021-08-04):
[0001437749-21-001877:note_history:90]
, the Company recorded $

- removed (2021-08-04):
[0001437749-21-001877:note_history:91]
1.1

- removed (2021-08-04):
[0001437749-21-001877:note_history:92]
million and $

- removed (2021-08-04):
[0001437749-21-001877:note_history:93]
1.8

- removed (2021-08-04):
[0001437749-21-001877:note_history:94]
million in grant revenue, respectively, which is included in the Company's Grid segment revenue.  In the

- removed (2021-08-04):
[0001437749-21-001877:note_history:95]
three
 and 
nine

- removed (2021-08-04):
[0001437749-21-001877:note_history:96]
months ended

- removed (2021-08-04):
[0001437749-21-001877:note_history:97]
December 31, 2019

- removed (2021-08-04):
[0001437749-21-001877:note_history:98]
, the Company recorded 
$3.9
 million and 
$5.3
 million in grant revenue, respectively, which is included in the Company's Grid segment revenue.

- removed (2021-08-04):
[0001437749-21-001877:note_history:99]
As of

- removed (2021-08-04):
[0001437749-21-001877:note_history:100]
December 31, 2020

- removed (2021-08-04):
[0001437749-21-001877:note_history:101]
, and

- removed (2021-08-04):
[0001437749-21-001877:note_history:102]
2019

- removed (2021-08-04):
[0001437749-21-001877:note_history:103]
, the Company's contract assets and liabilities primarily relate to the timing differences between cash received from a customer in connection with contractual rights to invoicing and the timing of revenue recognition following completion of performance obligations. The Company's accounts receivable balance is made up entirely of customer contract related balances. Changes in the Company's contract assets, which are included in “Unbilled accounts receivable” and “Deferred program costs” (see Note 
8,
 “Accounts Receivable” and Note 
9,
 “Inventory” for a reconciliation to the condensed consolidated balance sheets) and contract liabilities, which are included in the current portion and long term portion of "Deferred revenue" in the Company's condensed consolidated balance sheets, are as follows:

- removed (2021-08-04):
[0001437749-21-001877:note_history:104]
The Company's remaining performance obligations represent the unrecognized revenue value of the Company's contractual commitments. The Company's performance obligations 
 may 
vary significantly each reporting period based on the timing of major new contractual commitments. As of

- removed (2021-08-04):
[0001437749-21-001877:note_history:105]
December 31, 2020

- removed (2021-08-04):
[0001437749-21-001877:note_history:106]
, the Company had outstanding performance obligations on existing contracts under ASC 
606
 to be recognized in the next 
twelve
 months of approximately $

- removed (2021-08-04):
[0001437749-21-001877:note_history:107]
51.1

- removed (2021-08-04):
[0001437749-21-001877:note_history:108]
million. There are also approximately $

- removed (2021-08-04):
[0001437749-21-001877:note_history:109]
7.2

- removed (2021-08-04):
[0001437749-21-001877:note_history:110]
million of outstanding performance obligations to be recognized over a period of 
thirteen
 to 
sixty
 months. The remaining performance obligations are subject to customer actions and therefore the timing of revenue recognition cannot be reasonably estimated. The 
twelve
-month performance obligations include anticipated shipments to Inox based on the 
twelve
-month rolling forecast provided by Inox on the multi-year supply contract. The quantities specified in any forecast provided by Inox related to the multi-year supply contract are firm and irrevocable for the 
first

- removed (2021-08-04):
[0001437749-21-001877:note_history:111]
three
 months of a 
twelve
-month rolling forecast. The timing of the performance obligations beyond the 
twelve
-month forecast provided by Inox are 
not
 determinable and therefore are 
not
 included in the total remaining performance obligations.

- removed (2021-08-04):
[0001437749-21-001877:note_history:112]
three
 and 
nine
 months ended 
 December 31, 2020

- removed (2021-08-04):
[0001437749-21-001877:note_history:113]
and

- removed (2021-08-04):
[0001437749-21-001877:note_history:114]
2019

- removed (2021-08-04):
[0001437749-21-001877:note_history:115]
:

- removed (2021-08-04):
[0001437749-21-001877:note_history:116]
|  |  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  | Reportable |  | December 31, |  |  | December 31, |  |
|  | Segment |  | 2020 |  |  | 2019 |  |  | 2020 |  |  | 2019 |  |
| Inox Wind Limited | Wind |  |  | 24 | % |  |  | <10% |  |  |  | 12 | % |  |  | 11 | % |
| Department of Homeland Security | Grid |  |  | <10% |  |  |  | 22 | % |  |  | <10% |  |  |  | 12 | % |
| Vestas | Grid |  |  | <10% |  |  |  | 25 | % |  |  | <10% |  |  |  | 10 | % |
| EPC Services | Grid |  |  | 14 | % |  |  | <10% |  |  |  | 17 | % |  |  | <10% |  |


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: tag_name, score: 1.0

- changed (2021-08-04):
[0001437749-21-018523:note_history:117]
The Company has performed an evaluation of subsequent events through the time of filing this Quarterly Report on Form 10-Q with the SEC and has determined that there are no such events to report.
  (was, 2021-02-03, similarity 0.9974):
[0001437749-21-001877:note_history:117]
The Company has performed an evaluation of subsequent events through the time of filing this Quarterly Report on Form 
10
-Q with the SEC and has determined that there are 
no
 such events to report.
