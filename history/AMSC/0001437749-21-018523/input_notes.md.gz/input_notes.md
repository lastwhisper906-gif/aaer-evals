# AMSC notes — 0001437749-21-018523


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0001437749-21-018523:notes:1]
1. Nature of the Business and Operations and Liquidity

[0001437749-21-018523:notes:2]
[same as prior period, unchanged from 0001437749-21-001877:notes:231]

[0001437749-21-018523:notes:3]
American Superconductor Corporation (together with its subsidiaries, “AMSC®” or the “Company”) was founded on  April 9, 1987. The Company is a leading system provider of megawatt-scale power resiliency solutions that Orchestrate the Rhythm and Harmony of Power on the Grid™ and that protect and expand the capability of the Navy’s fleet. The Company’s system level products leverage its proprietary “smart materials” and “smart software and controls” to provide enhanced resiliency and improved performance of megawatt-scale power flow.

[0001437749-21-018523:notes:4]
These unaudited condensed consolidated financial statements of the Company have been prepared on a going concern basis in accordance with United States generally accepted accounting principles (“GAAP”) and the Securities and Exchange Commission’s (“SEC”) instructions to Form 10-Q. The going concern basis of presentation assumes that the Company will continue operations and will be able to realize its assets and discharge its liabilities and commitments in the normal course of business. Certain information and footnote disclosures normally included in the financial statements prepared in accordance with GAAP have been condensed or omitted pursuant to those instructions. The year-end condensed balance sheet data was derived from audited financial statements but does not include all disclosures required by GAAP. The unaudited condensed consolidated financial statements, in the opinion of management, reflect all adjustments (consisting of normal recurring adjustments) necessary for a fair statement of the results for the interim periods ended  June 30, 2021 and 2020 and the financial position at  June 30, 2021; however, these results are not necessarily indicative of results which  may be expected for the full year. The interim condensed consolidated financial statements, and notes thereto, should be read in conjunction with the audited consolidated financial statements for the year ended  March 31, 2021, and notes thereto, included in the Company’s Annual Report on Form 10-K for the year ended  March 31, 2021 filed with the SEC on  June 2, 2021.

[0001437749-21-018523:notes:5]
[same as prior period, unchanged from 0001437749-21-001877:notes:240]

[0001437749-21-018523:notes:6]
The Company has historically experienced recurring operating losses and as of  June 30, 2021, the Company had an accumulated deficit of $1,006.7 million. In addition, the Company has historically experienced recurring negative operating cash flows.  At  June 30, 2021, the Company had cash, cash equivalents, and marketable securities of $55.2 million. Marketable securities include certificate of deposits with maturities of less than three months.  Cash used in operations for the three months ended  June 30, 2021 was $5.8 million.

[0001437749-21-018523:notes:7]
In  February 2021, the Company filed a shelf registration statement on Form S-3 that will expire in  February 2024 (the “Form S-3”). The Form S-3 allows the Company to offer and sell from time-to-time up to $250 million of common stock, debt securities, warrants or units comprised of any combination of these securities. The Form S-3 is intended to provide the Company flexibility to conduct registered sales of the Company's securities, subject to market conditions, in order to fund the Company's future capital needs. The terms of any future offering under the Form S-3 will be established at the time of such offering and will be described in a prospectus supplement filed with the SEC prior to the completion of any such offering.

[0001437749-21-018523:notes:8]
On  May 6, 2021 (the "Neeltran Acquisition Date"), the Company entered into a Purchase and Sale Agreement (the "Real Property Purchase Agreement") and a Stock Purchase Agreement (the "Neeltran Stock Purchase Agreement") with the selling equity holders named therein. Also on  May 6, 2021, pursuant to the Real Property Purchase Agreement, the Company's wholly-owned Connecticut limited liability company, AMSC Husky LLC ("AMSC Husky"), purchased the real property that served as Neeltran's headquarters for $4.3 million, of which (a) $2.4 million was paid in immediately available funds by AMSC Husky to the owners of such real property, and (b) $1.9 million was paid directly to TD Bank as full payment for the outstanding indebtedness secured by the mortgage on such real property.  Pursuant to the terms of the Neeltran Stock Purchase Agreement and concurrently with entering into such agreement, the Company purchased all of the issued and outstanding shares of capital stock of (i) Neeltran, Inc., a Connecticut corporation ("Neeltran") that supplies rectifiers and transformers to industrial customers, and (ii) Neeltran International, Inc., a Connecticut corporation ("International"), for: (a) $1.0 million in cash, and (b) 301,556 shares of the Company's common stock, $.01 par value per share (the "AMSC Shares"), that were paid and issued to the Neeltran selling stockholders, respectively at closing (the "Neeltran Acquisition"). The Company also paid $1.1 million to International selling stockholders at closing to pay off previous loans made by them to Neeltran. Additionally, the Company paid approximately $7.6 million on behalf of the selling equity holders, including $1.9 million of indebtedness secured by the mortgage on the real property as described above, directly to Neeltran lenders at closing to extinguish outstanding Neeltran indebtedness to third parties on behalf of the sellers.

[0001437749-21-018523:notes:9]
In  March 2020, the World Health Organization declared the disease caused by the novel coronavirus, COVID-19, to be a pandemic. COVID-19 has spread throughout the globe, including in the Commonwealth of Massachusetts where the Company’s headquarters are located, and in other areas where the Company has business operations. In response to the outbreak, the Company has followed the guidelines of the U.S. Centers for Disease Control and Prevention and applicable state government authorities to protect the health and safety of the Company’s employees, families, suppliers, customers and communities. While these existing measures and, COVID-19 generally, have not materially disrupted the Company’s business to date, any future actions necessitated by the COVID-19 pandemic  may result in disruption to the Company’s business.

[0001437749-21-018523:notes:10]
While the COVID-19 pandemic continues to rapidly evolve, the Company continues to assess the impact of the COVID-19 pandemic to best mitigate risk and continue the operations of the Company’s business. The extent to which the outbreak impacts the Company’s business, liquidity, results of operations and financial condition will depend on future developments, which are highly uncertain and cannot be predicted with confidence, including new information that  may emerge concerning the severity of the COVID-19 pandemic, the spread of new variations of the virus, the actions to contain it or treat its impact and the effectiveness and adoption of vaccines, among others.  If the Company, its customers or suppliers experience prolonged shutdowns or other business disruptions, the Company’s business, liquidity, results of operations and financial condition are likely to be materially adversely affected, and the Company’s ability to access the capital markets  may be limited.

[0001437749-21-018523:notes:11]
The Company believes that based on the information presented above and its quarterly management assessment, it has sufficient liquidity to fund its operations and capital expenditures for the next twelve months following the issuance of the financial statements for the three months ended  June 30, 2021. The Company’s liquidity is highly dependent on its ability to increase revenues, including its ability to collect revenues under its agreements with Inox, its ability to control its operating costs, and its ability to raise additional capital, if necessary.  The impact of the COVID-19 pandemic on the global financing markets  may reduce the Company's ability to raise additional capital, if necessary, which could negatively impact the Company's liquidity.  There can be no assurance that the Company will be able to continue to raise additional capital, on favorable terms or at all, from other sources or execute on any other means of improving liquidity described above.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001437749-21-018523:notes:12]
2. Acquisitions

[0001437749-21-018523:notes:13]
2021 Acquisition of Neeltran

[0001437749-21-018523:notes:14]
As described in Note 1, "Nature of the Business and Operations and Liquidity", on the Neeltran Acquisition Date, pursuant to the terms of the Neeltran Stock Purchase Agreement, the Company purchased all of the issued and outstanding shares of capital stock of Neeltran and International for $1.0 million in cash and the AMSC Shares, that were paid and issued, respectively, to the Neeltran selling stockholders. The Company also paid $1.1 million to International selling stockholders to pay off previous loans made by them to Neeltran.

[0001437749-21-018523:notes:15]
Additionally, the Company paid approximately $7.6 million, including $1.9 million of indebtedness secured by the mortgage on the real property as described below, directly to Neeltran lenders at closing to extinguish outstanding Neeltran indebtedness to third parties. Pursuant to the terms of the Real Property Purchase Agreement, AMSC Husky purchased the real property that serves as Neeltran's headquarters for $4.3 million, of which (a) $2.4 million was paid immediately available funds by AMSC Husky to the selling parties, and (b) $1.9 million was paid directly to TD Bank as full payment for the outstanding indebtedness secured by the mortgage on such real property. The total purchase price of $16.4 million includes cash paid, the fair value of the AMSC Shares issued at closing and the debt payoff on behalf of the sellers as follows (in millions):

[0001437749-21-018523:notes:16]
| Cash payment |  | $ | 4.4 |  |
| Issuance of 301,556 shares of Company's common stock |  |  | 4.4 |  |
| Debt payment to third party lenders on behalf of sellers |  |  | 7.6 |  |
| Total consideration |  | $ | 16.4 |  |

[0001437749-21-018523:notes:17]
The Neeltran Acquisition completed by the Company during the three months ended  June 30, 2021 has been accounted for under the purchase method of accounting in accordance with ASC 805, Business Combinations. The Company allocated the purchase price to the assets acquired and liabilities assumed at their estimated fair values as of the date of Neeltran Acquisition. The excess of the purchase price paid by the Company over the estimated fair value of net assets acquired has been recorded as goodwill. As Neeltran was previously a private company, the adoption of Accounting Standards Codification 842 ("ASC 842") was completed as part of the Neeltran Acquisition. See Note 15 "Leases" for further details. Neeltran had previously adopted Accounting Standards Codification 606, Revenue from Contracts with Customers ("ASC 606") as part of prior year audited financial statements.

[0001437749-21-018523:notes:18]
The following table summarizes the allocation of the purchase price based on the estimated fair value of the assets acquired and liabilities assumed in connections with the Neeltran Acquisition (in millions):

[0001437749-21-018523:notes:19]
| Cash and short-term investments |  | $ | 0.5 |  |
| Net working capital (excluding inventory and deferred revenue) |  |  | (0.9 | ) |
| Inventory |  |  | 9.0 |  |
| Property, plant and equipment |  |  | 6.5 |  |
| Deferred revenue |  |  | (10.0 | ) |
| Deferred tax liability |  |  | (2.3 | ) |
| Net tangible assets/(liabilities) |  |  | 2.8 |  |
| Backlog |  |  | 0.1 |  |
| Trade names and trademarks |  |  | 1.2 |  |
| Customer relationships |  |  | 3.5 |  |
| Net identifiable intangible assets/(liabilities) |  |  | 4.8 |  |
| Goodwill |  |  | 8.8 |  |
| Total purchase consideration |  | $ | 16.4 |  |

[0001437749-21-018523:notes:20]
Inventory includes a
  $0.6 million adjustment to step up the inventory balance to fair value consistent with the purchase price allocation. The fair value was based on the estimated selling price of the inventory, less the remaining manufacturing and selling cost and a normal profit margin on those manufacturing and selling efforts. The inventory step up adjustment increased cost of revenue
  $0.3 million in the
  three month period ended
   June 30, 2021 as the inventory was sold.

[0001437749-21-018523:notes:21]
Backlog of $0.1 million was evaluated using the multi period excess earnings method under the income approach. The contracts with customers do not provide for any guarantees to source all future requirements from the Company. The amortization method being utilized is economic consumption estimated over a two year period with the expense being allocated to cost of revenues.

[0001437749-21-018523:notes:22]
Customer relationships of $3.5 million relates to customers currently under contract and was determined based on a multi period excess earnings method under the income approach. The method of amortization being utilized is the economic consumption over 7 years with the expense being allocated to SG&A.

[0001437749-21-018523:notes:23]
Trade names and trademarks of $1.2 million were reviewed using the assumption that the Company would continue to utilize the Neeltran trade name indefinitely. The relief from royalty method was utilized using a 1% royalty rate on revenues with a 24.5% discount rate over 15 years.

[0001437749-21-018523:notes:24]
The goodwill represents the value associated with the acquired workforce and expected synergies related to the business combinations of the
   two companies. Goodwill resulting from the Neeltran Acquisition was assigned to the Company's Grid business segment. Goodwill recognized in the Neeltran Acquisition is
   not deductible for tax purposes. This purchase price allocation is preliminary and has
   not been finalized as the analysis on the assets and liabilities acquired, primarily the tax liability
    may require further adjustments to our purchase accounting that could result in a measurement period adjustment that would impact our recorded net assets and goodwill as of
    May 6, 2021. Material changes, if any, to the preliminary allocation summarized above will be reported once the related uncertainties are resolved but
   no later than
    May 6, 2022.  The
   $2.3 million of deferred tax liability is primarily related to inventory step up and intangibles.

[0001437749-21-018523:notes:25]
The results of Neeltran's operations, are included in the Company's consolidated results from the date of the Neeltran Acquisition of
   May 6, 2021, for the
  three months ended
   June 30, 2021. In the unaudited consolidated results for the
  three months ended
   June 30, 2021, Neeltran contributed
  $5.5 million of revenue and
  $0.2 million in net loss for the Company.

[0001437749-21-018523:notes:26]
2020 Acquisition of NEPSI

[0001437749-21-018523:notes:27]
On  October 1, 2020 (the "NEPSI Acquisition Date"), the Company entered into a Stock Purchase Agreement (the "NEPSI Stock Purchase Agreement") with the selling stockholders named therein. Pursuant to the terms of the NEPSI Stock Purchase Agreement and concurrently with entering into such agreement, the Company acquired all of the issued and outstanding (i) shares of capital stock of Northeast Power Systems, Inc., a New York corporation ("NEPSI"), and (ii) membership interests of Northeast Power Realty, LLC, a New York limited liability company, which holds the real property that serves as NEPSI's headquarters (the "NEPSI Acquisition"). NEPSI is a U.S.-based global provider of medium-voltage metal-enclosed power capacitor banks and harmonic filter banks for use on electric power systems. Prior to the NEPSI Acquisition, the Company had purchased $0.4 million of products from NEPSI in fiscal year 2019 for which NEPSI was paid and had recorded revenue.

[0001437749-21-018523:notes:28]
Pursuant to the NEPSI Stock Purchase Agreement, the Company acquired all of the issued and outstanding shares of NEPSI, and membership interest in the realty entity, for which the Company paid $26.0 million in cash and issued 873,657 restricted shares of the Company’s common stock. Additionally, the Company  may issue to the selling stockholders up to an additional 1,000,000 shares of common stock upon NEPSI’s achievement of specified revenue objectives during varying periods of up to four years following closing of the NEPSI Acquisition. This contingent consideration is recorded as a derivative liability based on a Monte Carlo simulation to determine fair value at the time of issuance. NEPSI is now a wholly-owned subsidiary of the Company and is operated and reported as a component of its Grid business unit.

[0001437749-21-018523:notes:29]
The NEPSI Acquisition completed by the Company during the fiscal year ended  March 31, 2021 has been accounted for under the purchase method of accounting in accordance with ASC 805, Business Combinations. The Company allocated the purchase price to the assets acquired and liabilities assumed at their estimated fair values as of the date of NEPSI Acquisition. The excess of the purchase price paid by the Company over the estimated fair value of net assets acquired has been recorded as goodwill.  As NEPSI was previously a private company, the adoption of ASC 606 was completed as part of the NEPSI Acquisition.  See Note 3 "Revenue Recognition" for further details.  There were no leases acquired and the NEPSI Acquisition had no impact to the Company's reporting under ASC 842.

[0001437749-21-018523:notes:30]
The total purchase price of approximately $42.4 million includes the fair value of shares of the Company’s common stock issued at closing, cash paid, and contingent consideration as follows (in millions):

[0001437749-21-018523:notes:31]
| Cash payment |  | $ | 26.0 |  |
| Issuance of 873,657 shares of Company’s common stock |  |  | 12.4 |  |
| Contingent consideration |  |  | 4.0 |  |
| Total consideration |  | $ | 42.4 |  |

[0001437749-21-018523:notes:32]
At the NEPSI Acquisition Date, in addition to the $26.0 million cash, the Company valued the Company’s common stock, using $14.23 per share, which was the closing price on the day that the Company acquired NEPSI and $4.0 million of contingent consideration for the earnout liability valued as of the NEPSI Acquisition Date. NEPSI Acquisition costs of $0.3 million were recorded in selling, general and administrative ("SG&A") costs for the fiscal year ended  March 31, 2021.

[0001437749-21-018523:notes:33]
The fair value of the contingent consideration was determined using a Monte Carlo model and is accounted for as a derivative liability which is revalued at the fair value determined at each subsequent balance sheet date until the contingencies are resolved and the shares to be issued are determined, with the change in fair value recorded in the current period operating loss or (income).  See Note 13, "Contingent Consideration" for further details and a summary of key assumptions used to determine fair value in each period.

[0001437749-21-018523:notes:34]
The following table summarizes the allocation of the purchase price based on the estimated fair values of the assets acquired and liabilities assumed and related deferred income taxes in connection with the NEPSI Acquisition (in millions):

[0001437749-21-018523:notes:35]
[same as prior period, unchanged from 0001437749-21-001877:notes:39]

[0001437749-21-018523:notes:36]
Inventory includes a $1.0 million adjustment to step up the inventory balance to fair value consistent with the purchase price allocation.  The fair value was determined based on the estimated selling price of the inventory, less the remaining manufacturing and selling cost and a normal profit margin on those manufacturing and selling efforts. The $1.0 million step up adjustment increased cost of revenue in the fiscal year ended  March 31, 2021 as the inventory was sold.  This increase is not reflected in the pro forma condensed combined statements of operations because it does not have a continuing impact beyond the first year.

[0001437749-21-018523:notes:37]
Backlog of $0.6 million was evaluated using the multi period excess earnings method under the income approach. The contracts with customers do not provide for any guarantees to source all future requirements from the Company. The amortization method being utilized is economic consumption estimated over a two year period with the expense being allocated to cost of revenues.

[0001437749-21-018523:notes:38]
Customer relationships of $6.1 million relates to customers currently under contract and was determined based on a multi period excess earnings method under the income approach. The method of amortization being utilized is the economic consumption over 7 years with the expense being allocated to SG&A.

[0001437749-21-018523:notes:39]
Trade names and trademarks of $0.6 million were reviewed, using the assumption that the Company would continue to utilize the NEPSI trade name indefinitely. The relief from royalty method was utilized using an 8% royalty rate on revenues with a 13% discount rate over 8 years.

[0001437749-21-018523:notes:40]
Goodwill represents the value associated with the acquired workforce and expected synergies related to the business combination of the two companies. Goodwill resulting from the NEPSI Acquisition was assigned to the Company’s Grid business segment.  Goodwill recognized in the NEPSI Acquisition is not deductible for tax purposes. This purchase price allocation is preliminary and has not been finalized as the analysis on the assets and liabilities acquired, primarily the tax related liability  may require further adjustments to our purchase accounting that could result in a measurement period adjustment that would impact our reported net assets and goodwill as of  October 1, 2020. Material changes, if any, to the preliminary allocation summarized above will be reported once the related uncertainties are resolved, but no later than  October 1, 2021. The $1.7 million of deferred tax liability is primarily related to inventory step up and intangibles.

[0001437749-21-018523:notes:41]
[same as prior period, unchanged from 0001437749-21-001877:notes:45]

[0001437749-21-018523:notes:42]
The unaudited pro forma condensed consolidated statement of operations for the
  three months ended
   June 30, 2021 and 
  2020 is presented as if the NEPSI Acquisition and Neeltran Acquisition had occurred on
   April 1, 2020.

[0001437749-21-018523:notes:43]
|  |  | Three Months Ended June 30, |  |
|  |  | 2021 |  |  | 2020 |  |
| Revenues |  | $ | 28,250 |  |  | $ | 32,627 |  |
| Operating loss |  |  | (6,786 | ) |  |  | (3,343 | ) |
| Net loss |  | $ | (7,261 | ) |  | $ | 395 |  |
| Net loss per common share |  |  |  |  |  |  |  |  |
| Basic |  | $ | (0.27 | ) |  | $ | 0.02 |  |
| Diluted |  |  | (0.27 | ) |  |  | 0.02 |  |
| Shares - basic |  |  | 26,826 |  |  |  | 22,865 |  |
| Shares - diluted |  |  | 26,826 |  |  |  | 22,865 |  |

[0001437749-21-018523:notes:44]
The pro forma amounts include the historical operating results of the Company, NEPSI and Neeltran, with appropriate adjustments that give effect to acquisition related costs, income taxes, intangible amortization resulting from the NEPSI Acquisition and Neeltran Acquisition and certain conforming accounting policies of the Company. The pro forma amounts are
   not necessarily indicative of the operating results that would have occurred if the NEPSI Acquisition and Neeltran Acquisition and related transactions had been completed at the beginning of the applicable periods presented. In addition, the pro forma amounts are
   not necessarily indicative of operating results in future periods.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001437749-21-018523:notes:45]
3. Revenue Recognition

[0001437749-21-018523:notes:46]
The Company’s revenues in its Grid business segment are derived primarily through enabling the transmission and distribution of power, providing planning services that allow it to identify power grid needs and risks, and developing ship protection systems for the U.S. Navy. The Company’s revenues in its Wind business segment are derived primarily through supplying advanced power electronics and control systems, licensing its highly engineered wind turbine designs, and providing extensive customer support services to wind turbine manufacturers. The Company records revenue based on a five-step model in accordance with ASC 606. For its customer contracts, the Company identifies the performance obligations, determines the transaction price, allocates the contract transaction price to the performance obligations, and recognizes the revenue when (or as) control of goods or services is transferred to the customer. In the three months ended  June 30, 2021 and 2020, 78% and 80% of revenue, respectively, was recognized at the point in time when control transferred to the customer, with the remainder being recognized over time.

[0001437749-21-018523:notes:47]
In the Company's equipment and system product line, each contract with a customer summarizes each product sold to a customer, which typically represents distinct performance obligations. A contract's transaction price is allocated to each distinct performance obligation using the respective standalone selling price which is determined primarily using the cost-plus expected margin approach and recognized as revenue when, or as, the performance obligation is satisfied. The majority of the Company’s product sales transfer control to the customer in line with the contracted delivery terms and revenue is recorded at the point in time when title and risk transfer to the customer, which is primarily upon delivery, as the Company has determined that this is the point in time that control transfers to the customer.

[0001437749-21-018523:notes:48]
The Company's equipment and system product line includes certain contracts which do not meet the requirements of an exchange transaction and therefore do not fall within the scope of ASC 606.  As these non-exchange transaction contracts are considered grant revenue and do not fall within any specific accounting literature, the Company follows guidance within ASC 606 by analogy to recognize grant revenue over time.  In the three months ended  June 30, 2021 and 2020, the Company recorded $0.5 million and $0.4 million in grant revenue, respectively, which is included in the Company’s Grid business segment revenue.

[0001437749-21-018523:notes:49]
In the Company's service and technology development product line, there are several different types of transactions and each begins with a contract with a customer that summarizes each product sold to a customer, which typically represent distinct performance obligations. The technology development transactions are primarily for activities that have no alternative use and for which a profit can be expected throughout the life of the contract. In these cases, the revenue is recognized over time, but in the instances where the profit cannot be assured throughout the entire contract, the revenue is recognized at a point in time. Each contract's transaction price is allocated to each distinct performance obligation using the respective standalone selling price which is determined primarily using the cost-plus expected margin approach. The ongoing service transactions are for service contracts that provide benefit to the customer simultaneously as the Company performs its obligations, and therefore this revenue is recognized ratably over time throughout the effective period of these contracts. The transaction prices on these contracts are allocated based on an adjusted market approach which is re-assessed annually for reasonableness. The field service transactions include contracts for delivery of goods and completion of services made at the customer's requests, which are not deemed satisfied until the work has been completed and/or the requested goods have been delivered, so all of this revenue is recognized at the point in time when the control changes, and at allocated prices based on the adjusted market approach driven by standard price lists. The royalty transactions are related to certain contract terms on transactions in the Company's equipment and systems product line based on activity as specified in the contracts. The transaction prices of these agreements are calculated based on an adjusted market approach as specified in the contract. The Company reports royalty revenue for usage-based royalties when the sales have occurred. In circumstances when collectability is not assured and a contract does not exist under ASC 606, revenue is deferred until a non-refundable payment has been received for substantially all the amount that is due and there are no further remaining performance obligations.

[0001437749-21-018523:notes:50]
[same as prior period, unchanged from 0001437749-21-001877:notes:286]

[0001437749-21-018523:notes:51]
The Company’s policy is not to accept volume discounts, product returns, or rebates and allowances within its contracts. In the event a contract was approved with any of these terms, it would be evaluated for variable consideration, estimated and recorded as a reduction of revenue in the same period the related product revenue was recorded.

[0001437749-21-018523:notes:52]
The Company provides assurance-type warranties on all product sales for a term of typically one to three years, and extended service-type warranties at the customer's option for an additional term ranging up to four additional years. The Company accrues for the estimated warranty costs for assurance warranties at the time of sale based on historical warranty experience plus any known or expected changes in warranty exposure. For all extended service-type warranties, the Company recognizes the revenue ratably over time during the effective period of the services.

[0001437749-21-018523:notes:53]
The Company records revenue net of sales tax, value added tax, excise tax and other taxes collected concurrent with revenue-producing activities. The Company has elected to recognize the cost for freight and shipping when control over the products sold passes to customers and revenue is recognized. The Company has elected to recognize incremental costs of obtaining a contract as expense when incurred except in contracts where the amortization period would exceed twelve months; in such cases the long-term amount will be assessed for materiality. The Company has elected not to adjust the promised amount of consideration for the effects of a significant financing component if the period of financing is twelve months or less.

[0001437749-21-018523:notes:54]
The Company’s contracts with customers do not typically include extended payment terms and  may include milestone billing over the life of the contract. Payment terms vary by contract type and type of customer and generally range from 30 to 60 days from delivery.

[0001437749-21-018523:notes:55]
The following tables disaggregate the Company’s revenue by product line and by shipment destination (in thousands):

[0001437749-21-018523:notes:56]
|  |  | Three Months Ended June 30, 2021 |  |
| Product Line: |  | Grid |  |  | Wind |  |
| Equipment and systems |  | $ | 21,159 |  |  | $ | 1,033 |  |
| Services and technology development |  |  | 2,342 |  |  |  | 886 |  |
| Total |  | $ | 23,501 |  |  | $ | 1,919 |  |
| Region: |  |  |  |  |  |  |  |  |
| Americas |  | $ | 22,645 |  |  | $ | 19 |  |
| Asia Pacific |  |  | 598 |  |  |  | 1,870 |  |
| EMEA |  |  | 258 |  |  |  | 30 |  |
| Total |  | $ | 23,501 |  |  | $ | 1,919 |  |

[0001437749-21-018523:notes:57]
|  |  | Three Months Ended June 30, 2020 |  |
| Product Line: |  | Grid |  |  | Wind |  |
| Equipment and systems |  | $ | 16,537 |  |  | $ | 2,618 |  |
| Services and technology development |  |  | 1,178 |  |  |  | 880 |  |
| Total |  | $ | 17,715 |  |  | $ | 3,498 |  |
| Region: |  |  |  |  |  |  |  |  |
| Americas |  | $ | 10,554 |  |  | $ | 12 |  |
| Asia Pacific |  |  | 6,015 |  |  |  | 3,269 |  |
| EMEA |  |  | 1,146 |  |  |  | 217 |  |
| Total |  | $ | 17,715 |  |  | $ | 3,498 |  |

[0001437749-21-018523:notes:58]
As of  June 30, 2021, and 2020, the Company’s contract assets and liabilities primarily relate to the timing differences between cash received from a customer in connection with contractual rights to invoicing and the timing of revenue recognition following completion of performance obligations. The Company's accounts receivable balance is made up entirely of customer contract related balances. Changes in the Company’s contract assets, which are included in “Unbilled accounts receivable” and “Deferred program costs” (see Note 8, “Accounts Receivable” and Note 9, “Inventory” for a reconciliation to the condensed consolidated balance sheets) and "Contract liabilities", which are included in the current portion and long-term portion of "Deferred revenue" in the Company’s condensed consolidated balance sheets, are as follows (in thousands):

[0001437749-21-018523:notes:59]
|  |  | Unbilled Accounts Receivable |  |  | Deferred Program Costs |  |  | Contract Liabilities |  |
| Beginning balance as of March 31, 2021 |  | $ | 5,765 |  |  | $ | 978 |  |  | $ | 21,258 |  |
| Increases for costs incurred to fulfill performance obligations |  |  | — |  |  |  | 1,434 |  |  |  | — |  |
| Increase for balances acquired |  |  | — |  |  |  | 634 |  |  |  | 10,048 |  |
| Increase (decrease) due to customer billings |  |  | (1,564 | ) |  |  | — |  |  |  | 21,425 |  |
| Decrease due to cost recognition on completed performance obligations |  |  | — |  |  |  | (2,041 | ) |  |  | — |  |
| Increase (decrease) due to recognition of revenue based on transfer of control of performance obligations |  |  | 4,360 |  |  |  | — |  |  |  | (24,355 | ) |
| Other changes and FX impact |  |  | — |  |  |  | 3 |  |  |  | 246 |  |
| Ending balance as of June 30, 2021 |  | $ | 8,561 |  |  | $ | 1,008 |  |  | $ | 28,622 |  |

[0001437749-21-018523:notes:60]
|  |  | Unbilled Accounts Receivable |  |  | Deferred Program Costs |  |  | Contract Liabilities |  |
| Beginning balance as of March 31, 2020 |  | $ | 5,711 |  |  | $ | 1,631 |  |  | $ | 26,142 |  |
| Increases for costs incurred to fulfill performance obligations |  |  | — |  |  |  | 1,978 |  |  |  | — |  |
| Increase (decrease) due to customer billings |  |  | (3,620 | ) |  |  | — |  |  |  | 12,276 |  |
| Decrease due to cost recognition on completed performance obligations |  |  | — |  |  |  | (2,815 | ) |  |  | — |  |
| Increase (decrease) due to recognition of revenue based on transfer of control of performance obligations |  |  | 2,033 |  |  |  | — |  |  |  | (16,227 | ) |
| Other changes and FX impact |  |  | 1 |  |  |  | 7 |  |  |  | 194 |  |
| Ending balance as of June 30, 2020 |  | $ | 4,125 |  |  | $ | 801 |  |  | $ | 22,385 |  |

[0001437749-21-018523:notes:61]
The Company’s remaining performance obligations represent the unrecognized revenue value of the Company’s contractual commitments. The Company’s performance obligations  may vary significantly each reporting period based on the timing of major new contractual commitments. As of  June 30, 2021, the Company had outstanding performance obligations on existing contracts under ASC 606 to be recognized in the next twelve months of approximately $86.9 million. There are also approximately $15.9 million of outstanding performance obligations to be recognized over a period of thirteen to sixty months. The remaining performance obligations are subject to customer actions and therefore the timing of revenue recognition cannot be reasonably estimated. The twelve-month performance obligations include anticipated shipments to Inox based on the twelve-month rolling forecast provided by Inox on the multi-year supply contract. The quantities specified in any forecast provided by Inox related to the multi-year supply contract are firm and irrevocable for the first three months of a twelve-month rolling forecast. The timing of the performance obligations beyond the twelve-month forecast provided by Inox are not determinable and therefore are not included in the total remaining performance obligations.

[0001437749-21-018523:notes:62]
The following table sets forth customers who represented 10% or more of the Company’s total revenues for the three months ended  June 30, 2021 and 2020:

[0001437749-21-018523:notes:63]
|  |  |  | Three Months Ended |  |
|  | Reportable |  | June 30, |  |
|  | Segment |  | 2021 |  |  | 2020 |  |
| Micron Technology | Grid |  |  | 21 | % |  | <10% |  |
| EPC Services | Grid |  |  | <10% |  |  |  | 24 | % |
| Nextera Energy Resources | Grid |  |  | 12 | % |  |  | <10% |  |
| Ascend Performance Materials Ops LLC | Grid |  |  | 10 | % |  |  | 0 | % |
| Siemens Gamesa Renewable Energy Pty. Ltd. | Grid |  |  | <10% |  |  |  | 25 | % |


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001437749-21-018523:notes:64]
4. Stock-Based Compensation

[0001437749-21-018523:notes:65]
The Company accounts for its stock-based compensation at fair value. The following table summarizes stock-based compensation expense by financial statement line item for the three months ended  June 30, 2021 and 2020 (in thousands):

[0001437749-21-018523:notes:66]
|  |  | Three Months Ended June 30, |  |
|  |  | 2021 |  |  | 2020 |  |
| Cost of revenues |  | $ | 91 |  |  | $ | 28 |  |
| Research and development |  |  | 247 |  |  |  | 130 |  |
| Selling, general and administrative |  |  | 954 |  |  |  | 751 |  |
| Total |  | $ | 1,292 |  |  | $ | 909 |  |

[0001437749-21-018523:notes:67]
The Company issued 119,044 shares of immediately vested common stock, of which 110,752 shares were issued in-lieu of cash bonuses in the period, and 309,700 shares of restricted stock awards during the three months ended  June 30, 2021. The Company issued 27,341 shares of immediately vested common stock and 658,667 shares of restricted stock awards during the three months ended  June 30, 2020.  These restricted stock awards generally vest over 2-3 years.  Awards for restricted stock include both time-based and performance-based awards.  For options and restricted stock awards that vest upon the passage of time, expense is being recorded over the vesting period.  Performance-based awards are expensed over the requisite service period based on probability of achievement.

[0001437749-21-018523:notes:68]
The estimated fair value of the Company’s stock-based awards, less expected annual forfeitures, is amortized over the awards’ service period. The Company has no unrecognized compensation cost for unvested outstanding stock options at  June 30, 2021. The total unrecognized compensation cost for unvested outstanding restricted stock was $7.7 million at  June 30, 2021. This expense will be recognized over a weighted-average expense period of approximately 1.9 years.

[0001437749-21-018523:notes:69]
The Company did not grant any stock options during the three months ended  June 30, 2021 or 2020.


## us-gaap:EarningsPerShareTextBlock

[0001437749-21-018523:notes:70]
5. Computation of Net Loss per Common Share

[0001437749-21-018523:notes:71]
Basic net loss per share (“EPS”) is computed by dividing net loss by the weighted-average number of common shares outstanding for the period. Where applicable, diluted EPS is computed by dividing the net loss by the weighted-average number of common shares and dilutive common equivalent shares outstanding during the period, calculated using the treasury stock method. Common equivalent shares include the effect of restricted stock, exercise of stock options and warrants and contingently issuable shares. Stock options and warrants that are out-of-the-money with exercise prices greater than the average market price of the underlying common shares and shares of performance based restricted stock where the contingency was not met are excluded from the computation of diluted EPS as the effect of their inclusion would be anti-dilutive.  For the three months ended  June 30, 2021, 1.1 million shares were not included in the calculation of diluted EPS.  Of these, 1.0 million relate to shares tied to the derivative liability for which the contingency has not yet been met, and 0.1 million relate to outstanding stock options as they were considered anti-dilutive. For the three months ended  June 30, 2020, 0.1 million shares related to outstanding stock options were not included in the calculation of diluted EPS as they were considered anti-dilutive.

[0001437749-21-018523:notes:72]
The following table reconciles the numerators and denominators of the earnings per share calculation for the three months ended  June 30, 2021 and 2020 (in thousands, except per share data):

[0001437749-21-018523:notes:73]
|  |  | Three Months Ended June 30, |  |
|  |  | 2021 |  |  | 2020 |  |
| Numerator: |  |  |  |  |  |  |  |  |
| Net loss |  | $ | (5,403 | ) |  | $ | (3,417 | ) |
| Denominator: |  |  |  |  |  |  |  |  |
| Weighted-average shares of common stock outstanding |  |  | 27,919 |  |  |  | 22,827 |  |
| Weighted-average shares subject to repurchase |  |  | (1,093 | ) |  |  | (1,138 | ) |
| Shares used in per-share calculation ― basic |  |  | 26,826 |  |  |  | 21,689 |  |
| Shares used in per-share calculation ― diluted |  |  | 26,826 |  |  |  | 21,689 |  |
| Net loss per share ― basic |  | $ | (0.20 | ) |  | $ | (0.16 | ) |
| Net loss per share ― diluted |  | $ | (0.20 | ) |  | $ | (0.16 | ) |


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001437749-21-018523:notes:74]
6. Goodwill and Other Intangibles

[0001437749-21-018523:notes:75]
[same as prior period, unchanged from 0001437749-21-001877:notes:165]

[0001437749-21-018523:notes:76]
Goodwill represents the difference between the purchase price and the fair value of the identifiable tangible and intangible net assets when accounted for using the purchase method of accounting. The Company's goodwill balance relates to the Neeltran Acquisition in the current year, the NEPSI Acquisition in fiscal 2020, and the acquisition of Infinia Technology Corporation in fiscal 2017 and is reported in the Grid business segment. Goodwill is not amortized but reviewed for impairment. Goodwill is reviewed annually and whenever events or changes in circumstances indicate that the carrying value of the goodwill might not be recoverable.

[0001437749-21-018523:notes:77]
The following table provides a roll forward of the changes in the Company's Grid business segment goodwill balance:

[0001437749-21-018523:notes:78]
|  |  | Goodwill |  |
| March 31, 2021 |  | $ | 34,634 |  |
| Neeltran Acquisition |  |  | 8,837 |  |
| Less impairment loss |  |  | - |  |
| June 30, 2021 |  | $ | 43,471 |  |

[0001437749-21-018523:notes:79]
The Company did not identify any triggering events in the three months ended  June 30, 2021 that would require interim impairment testing of goodwill.

[0001437749-21-018523:notes:80]
[same as prior period, unchanged from 0001437749-21-001877:notes:172]

[0001437749-21-018523:notes:81]
Intangible assets at  June 30, 2021 and  March 31, 2021 consisted of the following (in thousands):

[0001437749-21-018523:notes:82]
|  |  | June 30, 2021 |  |  | March 31, 2021 |  |  |  |  |  |
|  |  | Gross Amount |  |  | Accumulated Amortization |  |  | Net Book Value |  |  | Gross Amount |  |  | Accumulated Amortization |  |  | Net Book Value |  |  | Estimated Useful Life |  |
| Backlog |  | $ | 681 |  |  | $ | (512 | ) |  | $ | 169 |  |  | $ | 600 |  |  | $ | (475 | ) |  | $ | 125 |  |  |  | 2 |  |
| Trade name |  |  | 1,800 |  |  |  | — |  |  |  | 1,800 |  |  |  | 600 |  |  |  | — |  |  |  | 600 |  |  |  | Indefinite |  |
| Customer relationships |  |  | 9,600 |  |  |  | (1,203 | ) |  |  | 8,397 |  |  |  | 6,100 |  |  |  | (739 | ) |  |  | 5,361 |  |  |  | 7 |  |
| Core technology and know-how |  |  | 5,970 |  |  |  | (3,024 | ) |  |  | 2,946 |  |  |  | 5,970 |  |  |  | (2,903 | ) |  |  | 3,067 |  |  |  | 5-10 |  |
| Intangible assets |  | $ | 18,051 |  |  | $ | (4,739 | ) |  | $ | 13,312 |  |  | $ | 13,270 |  |  | $ | (4,117 | ) |  | $ | 9,153 |  |  |  |  |  |

[0001437749-21-018523:notes:83]
The Company recorded intangible amortization expense related to customer relationship and core technology and know-how of $0.6 million and $0.1 million, in the three months ended  June 30, 2021, and 2020, respectively.  Additionally, in the three months ended  June 30, 2021, the Company recorded less than $0.1 million related to intangible amortization related to backlog that is reported in cost of revenues.

[0001437749-21-018523:notes:84]
[same as prior period, unchanged from 0001437749-21-001877:notes:180]

[0001437749-21-018523:notes:85]
| Years ended March 31, |  | Total |  |
| 2022 |  |  | 2,028 |  |
| 2023 |  |  | 2,765 |  |
| 2024 |  |  | 2,152 |  |
| 2025 |  |  | 1,648 |  |
| 2026 |  |  | 1,221 |  |
| Thereafter |  |  | 1,698 |  |
| Total |  | $ | 11,512 |  |

[0001437749-21-018523:notes:86]
[same as prior period, unchanged from 0001437749-21-001877:notes:182]


## us-gaap:FairValueDisclosuresTextBlock

[0001437749-21-018523:notes:87]
7. Fair Value Measurements

[0001437749-21-018523:notes:88]
A valuation hierarchy for disclosure of the inputs to valuation used to measure fair value has been established. This hierarchy prioritizes the inputs into three broad levels as follows:

[0001437749-21-018523:notes:89]
| Level 1 | - | Inputs are unadjusted quoted prices in active markets for identical assets or liabilities that the Company has the ability to access at the measurement date. |
| Level 2 | - | Inputs include quoted prices for similar assets and liabilities in active markets, quoted prices for identical or similar assets or liabilities in markets that are not active, inputs other than quoted prices that are observable for the asset or liability, and inputs that are derived principally from or corroborated by observable market data by correlation or other means (market corroborated inputs). |
| Level 3 | - | Unobservable inputs that reflect the Company’s assumptions that market participants would use in pricing the asset or liability. The Company develops these inputs based on the best information available, including its own data. |

[0001437749-21-018523:notes:90]
The Company provides a gross presentation of activity within Level 3 measurement roll-forward and details of transfers in and out of Level 1 and 2 measurements.  A change in the hierarchy of an investment from its current level is reflected in the period during which the pricing methodology of such investment changes.  Disclosure of the transfer of securities from Level 1 to Level 2 or Level 3 is made in the event that the related security is significant to total cash and investments.  The Company did not have any transfers of assets and liabilities from Level 1, Level 2 or Level 3 of the fair value measurement hierarchy during the three months ended  June 30, 2021.

[0001437749-21-018523:notes:91]
A financial asset’s or liability’s classification within the hierarchy is determined based on the lowest level input that is significant to the fair value measurement.

[0001437749-21-018523:notes:92]
[same as prior period, unchanged from 0001437749-21-001877:notes:143]

[0001437749-21-018523:notes:93]
[same as prior period, unchanged from 0001437749-21-001877:notes:144]

[0001437749-21-018523:notes:94]
Cash equivalents consist of highly liquid instruments with maturities of three months or less that are regarded as high quality, low risk investments, are measured using such inputs as quoted prices and are classified within Level 1 of the valuation hierarchy. Cash equivalents consist principally of certificates of deposits and money market accounts.

[0001437749-21-018523:notes:95]
[same as prior period, unchanged from 0001437749-21-001877:notes:146]

[0001437749-21-018523:notes:96]
Marketable securities consist of certificates of deposit that are measured using such inputs as quoted prices and are classified within Level 1 of the valuation hierarchy. The Company determines the appropriate classification of its marketable securities at the time of purchase and re-evaluates such classification as of each balance sheet date.  All marketable securities are considered available for sale and are carried at fair value.   Changes in fair value are recorded to other income (expense), net.  The Company recognized no change in the three months ended  June 30, 2021 and $0.1 million in unrealized gains on marketable securities, which is recorded in other income (expense), net, for the three months ended  June 30, 2020.  The Company periodically reviews the realizability of each short- and long-term marketable security when impairment indicators exist with respect to the security.  If other than temporary impairment of value of the security exists, then the carrying value of the security is written down to its estimated fair value.

[0001437749-21-018523:notes:97]
Contingent Consideration

[0001437749-21-018523:notes:98]
Contingent consideration relates to the earnout payment set forth in the NEPSI Stock Purchase Agreement that provides that the selling stockholders  may receive up to an additional 1,000,000 shares of common stock of the Company upon the achievement of certain specified revenue objectives over varying periods of up to four years following the NEPSI Acquisition Date. See Note 13, "Contingent Consideration" and Note 2, “Acquisitions” for further discussion. The Company relied on a Monte Carlo method to determine the fair value of the contingent consideration on the NEPSI Acquisition Date and will continue to revalue the fair value of the contingent consideration using the same method at each subsequent balance sheet date until the contingencies are resolved and the shares to be issued are determined, with the change in fair value recorded in the current period operating loss.

[0001437749-21-018523:notes:99]
The following table provides the assets and liabilities carried at fair value on a recurring basis, measured as of  June 30, 2021 and  March 31, 2021 (in thousands):

[0001437749-21-018523:notes:100]
|  |  | Total Carrying Value |  |  | Quoted Prices in Active Markets (Level 1) |  |  | Significant Other Observable Inputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |
| June 30, 2021: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash equivalents |  | $ | 28,107 |  |  | $ | 28,107 |  |  | $ | — |  |  | $ | — |  |
| Marketable securities |  | $ | 5,165 |  |  | $ | 5,165 |  |  | $ | — |  |  | $ | — |  |
| Derivative liabilities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Contingent consideration |  | $ | 7,150 |  |  | $ | — |  |  | $ | — |  |  | $ | 7,150 |  |

[0001437749-21-018523:notes:101]
|  |  | Total Carrying Value |  |  | Quoted Prices in Active Markets (Level 1) |  |  | Significant Other Observable Inputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |
| March 31, 2021: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash equivalents |  | $ | 54,104 |  |  | $ | 54,104 |  |  | $ | — |  |  | $ | — |  |
| Marketable securities |  | $ | 5,140 |  |  | $ | 5,140 |  |  | $ | — |  |  | $ | — |  |
| Derivative liabilities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Contingent consideration |  | $ | 7,050 |  |  | $ | — |  |  | $ | — |  |  | $ | 7,050 |  |

[0001437749-21-018523:notes:102]
The table below reflects the activity for the Company’s derivative liability measured at fair value on a recurring basis (in thousands):

[0001437749-21-018523:notes:103]
|  |  | Acquisition Contingent Consideration |  |
| April 1, 2021 |  | $ | 7,050 |  |
| Mark to market adjustment |  |  | 100 |  |
| Balance at June 30, 2021 |  | $ | 7,150 |  |


## amsc:AccountsReceivableTextBlock

[0001437749-21-018523:notes:104]
8. Accounts Receivable

[0001437749-21-018523:notes:105]
Accounts receivable at  June 30, 2021 and  March 31, 2021 consisted of the following (in thousands):

[0001437749-21-018523:notes:106]
|  |  | June 30, 2021 |  |  | March 31, 2021 |  |
| Accounts receivable (billed) |  | $ | 15,347 |  |  | $ | 7,502 |  |
| Accounts receivable (unbilled) |  |  | 8,561 |  |  |  | 5,765 |  |
| Accounts receivable, net |  | $ | 23,908 |  |  | $ | 13,267 |  |


## us-gaap:InventoryDisclosureTextBlock

[0001437749-21-018523:notes:107]
9. Inventory

[0001437749-21-018523:notes:108]
Inventory, net of reserves, at  June 30, 2021 and  March 31, 2021 consisted of the following (in thousands):

[0001437749-21-018523:notes:109]
|  |  | June 30, 2021 |  |  | March 31, 2021 |  |
| Raw materials |  | $ | 9,756 |  |  | $ | 8,255 |  |
| Work-in-process |  |  | 9,600 |  |  |  | 3,297 |  |
| Finished goods |  |  | 1,791 |  |  |  | 777 |  |
| Deferred program costs |  |  | 1,008 |  |  |  | 977 |  |
| Net inventory |  | $ | 22,155 |  |  | $ | 13,306 |  |

[0001437749-21-018523:notes:110]
The Company recorded inventory write-downs of $0.6 million and $0.8 million for the three months ended  June 30, 2021, and 2020, respectively.  These write-downs were based on the Company's evaluation of its inventory on hand for excess quantities and obsolescence.

[0001437749-21-018523:notes:111]
Deferred program costs as of  June 30, 2021, and  March 31, 2021, primarily represent costs incurred on programs where the Company needs to complete performance obligations before the related revenue and costs will be recognized.


## us-gaap:PropertyPlantAndEquipmentDisclosureTextBlock

[0001437749-21-018523:notes:112]
10. Property, Plant and Equipment

[0001437749-21-018523:notes:113]
The cost and accumulated depreciation of property, plant and equipment at  June 30, 2021 and  March 31, 2021 are as follows (in thousands):

[0001437749-21-018523:notes:114]
|  |  | June 30, 2021 |  |  | March 31, 2021 |  |
| Construction in progress - equipment |  | $ | 286 |  |  | $ | 220 |  |
| Land |  |  | 980 |  |  |  | 270 |  |
| Building |  |  | 5,270 |  |  |  | 1,630 |  |
| Equipment and software |  |  | 43,773 |  |  |  | 41,652 |  |
| Finance lease - right of use asset |  |  | 12 |  |  |  | — |  |
| Furniture and fixtures |  |  | 1,380 |  |  |  | 1,333 |  |
| Leasehold improvements |  |  | 6,452 |  |  |  | 6,308 |  |
| Property, plant and equipment, gross |  |  | 58,153 |  |  |  | 51,413 |  |
| Less accumulated depreciation |  |  | (43,086 | ) |  |  | (42,416 | ) |
| Property, plant and equipment, net |  | $ | 15,067 |  |  | $ | 8,997 |  |

[0001437749-21-018523:notes:115]
Depreciation expense was $0.6 million and $0.9 million for the three months ended  June 30, 2021 and 2020, respectively.  The increase in land and building relates to the property added as part of the Neeltran Acquisition.


## us-gaap:AccountsPayableAndAccruedLiabilitiesDisclosureTextBlock

[0001437749-21-018523:notes:116]
11. Accounts Payable and Accrued Expenses

[0001437749-21-018523:notes:117]
Accounts payable and accrued expenses at  June 30, 2021 and  March 31, 2021 consisted of the following (in thousands):

[0001437749-21-018523:notes:118]
|  |  | June 30, 2021 |  |  | March 31, 2021 |  |
| Accounts payable |  | $ | 16,520 |  |  | $ | 5,353 |  |
| Accrued inventories in-transit |  |  | 1,927 |  |  |  | 1,460 |  |
| Accrued other miscellaneous expenses |  |  | 2,800 |  |  |  | 2,369 |  |
| Advanced deposits |  |  | 2,152 |  |  |  | 1,035 |  |
| Accrued compensation |  |  | 7,291 |  |  |  | 7,018 |  |
| Income taxes payable |  |  | 563 |  |  |  | 522 |  |
| Accrued product warranty |  |  | 2,186 |  |  |  | 2,053 |  |
| Total |  | $ | 33,439 |  |  | $ | 19,810 |  |

[0001437749-21-018523:notes:119]
The Company generally provides a one to three year warranty on its products, commencing upon delivery or installation where applicable. A provision is recorded upon revenue recognition to cost of revenues for estimated warranty expense based on historical experience.

[0001437749-21-018523:notes:120]
[same as prior period, unchanged from 0001437749-21-001877:notes:22]

[0001437749-21-018523:notes:121]
|  |  | Three Months Ended June 30, |  |
|  |  | 2021 |  |  | 2020 |  |
| Balance at beginning of period |  | $ | 2,053 |  |  | $ | 2,015 |  |
| Acquired warranty obligations |  |  | 248 |  |  |  | — |  |
| Change in accruals for warranties during the period |  |  | 107 |  |  |  | 236 |  |
| Settlements during the period |  |  | (222 | ) |  |  | (83 | ) |
| Balance at end of period |  | $ | 2,186 |  |  | $ | 2,168 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0001437749-21-018523:notes:122]
12. Income Taxes

[0001437749-21-018523:notes:123]
The Company recorded an income tax benefit of $2.1 million in the three month period ended  June 30, 2021. The Company recorded income tax expense of $0.2 million in the three months ended  June 30, 2020.

[0001437749-21-018523:notes:124]
As a result of a difference in book and tax basis related to the intangible assets acquired in the Neeltran Acquisition (see Note 2, "Acquisitions"), the Company recorded a deferred tax liability of $2.3 million. As a result, the Company was able to benefit from additional deferred tax assets and therefore released a corresponding valuation allowance of $2.3 million during the three months ended  June 30, 2021.  The purchase price allocation is preliminary and has not been finalized as the analysis on the assets and liabilities acquired, primarily the tax related liability,  may require further adjustments to the Company's purchase accounting that could result in measurement period adjustments that would impact the Company's reported net assets and goodwill as of  May 6, 2021. Material changes, if any, to the preliminary allocation summarized in Note 2, "Acquisitions" will be reported once the related uncertainties are resolved, but no later than  May 6, 2022.  Goodwill recognized in the Neeltran Acquisition and the NEPSI Acquisition is not deductible for tax purposes.

[0001437749-21-018523:notes:125]
Accounting for income taxes requires a two-step approach to recognizing and measuring uncertain tax positions.  The first step is to evaluate the tax position for recognition by determining if, based on the technical merits, it is more likely than not the position will be sustained upon audit, including resolution of related appeals or litigation processes, if any.  The second step is to measure the tax benefit as the largest amount that is more than 50% likely to be realized upon ultimate settlement.  The Company re-evaluates these uncertain tax positions on a quarterly basis.  The evaluation is based on factors including, but not limited to, changes in facts or circumstances, changes in tax law, effectively settled issues under audit and new audit activity.  Any changes in these factors could result in the recognition of a tax benefit or an additional charge to the tax provision.  The Company did not identify any uncertain tax positions in the three months ended  June 30, 2021 and did not have any gross unrecognized tax benefits as of  June 30, 2021.


## amsc:BusinessCombinationContingentConsiderationTextBlock

[0001437749-21-018523:notes:126]
13. Contingent Consideration

[0001437749-21-018523:notes:127]
The Company evaluated the NEPSI Acquisition earnout payment set forth in the NEPSI Stock Purchase Agreement (see Note 2, "Acquisitions" for further details), which  may require settlement in the Company's common stock, and determined the contingent consideration qualified for liability classification and derivative treatment under ASC 815, Derivatives and Hedging. As a result, for each period, the fair value of the contingent consideration will be remeasured and the resulting gain or loss will be recognized in operating expenses until the share amount is fixed.

[0001437749-21-018523:notes:128]
Following is a summary of the key assumptions used in a Monte Carlo simulation to calculate the fair value of the contingent consideration related to the NEPSI Acquisition:

[0001437749-21-018523:notes:129]
|  |  | June 30, |  |  | March 31, |  |  | December 31, |  |  | October 1, |  |
|  |  | 2021 |  |  | 2021 |  |  | 2020 |  |  | 2020 |  |
| Revenue risk premium |  |  | 6.60 | % |  |  | 6.70 | % |  |  | 6.90 | % |  |  | 7.10 | % |
| Revenue volatility |  |  | 30 | % |  |  | 30 | % |  |  | 30 | % |  |  | 30 | % |
| Stock Price |  | $ | 17.39 |  |  | $ | 18.96 |  |  | $ | 23.42 |  |  | $ | 14.23 |  |
| Payment delay (days) |  |  | 80 |  |  |  | 80 |  |  |  | 80 |  |  |  | — |  |
| Fair value |  |  | 7.2 |  |  |  | 7.1 |  |  |  | 6.7 |  |  |  | 4.0 |  |

[0001437749-21-018523:notes:130]
The Company recorded a net loss of $0.1 million resulting from the increase in the fair value of the contingent consideration in the three months ended  June 30, 2021.


## us-gaap:DebtDisclosureTextBlock

[0001437749-21-018523:notes:131]
14. Debt

[0001437749-21-018523:notes:132]
As part of the Neeltran Acquisition, the Company identified four equipment financing agreements that Neeltran had entered into prior to the acquisition on  May 6, 2021. The Company determined to account for these agreements as a debt transaction and recorded current and long-term debt liabilities of $0.1 million each during the three months ended  June 30, 2021.


## us-gaap:LesseeOperatingLeasesTextBlock

[0001437749-21-018523:notes:133]
15. Leases

[0001437749-21-018523:notes:134]
The Company determines whether a contract is or contains a lease at inception of a contract. The Company defines a lease as a contract, or part of a contract, that conveys the right to control the use of identified property or equipment (an identified asset) for a period of time in exchange for consideration. Control over the use of the identified asset means that the Company have both the right to obtain substantially all of the economic benefits from the use of the asset and the right to direct the use of the asset.

[0001437749-21-018523:notes:135]
The discount rate was calculated using an incremental borrowing rate based on an assessment prepared by the Company through the use of Company credit ratings, consideration of its lease populations potential risk to its total capital structure, and a market rate for a collateralized loan for its risk profile, calculated by a third party. The Company elected to apply the discount rate using the remaining lease term at the date of adoption for Neeltran lease contracts.

[0001437749-21-018523:notes:136]
Following the Neeltran Acquisition, the Company evaluated all open Neeltran contracts at the date of the acquisition to determine if any applied under ASC 842 as Neeltran, a private company, had deferred adopting ASC 842 prior to the Neeltran Acquisition, as permitted. The Company identified nine lease contracts with terms greater than twelve months and evaluated them under ASC 842 guidance. As part of the implementation, we identified one lease contract that classified as a financing lease. The Company does not expect a material impact to the financial statements on an ongoing basis resulting from the adoption of the ASC 842 standard for the Neeltran business and Neeltran will follow the existing policies below.

[0001437749-21-018523:notes:137]
Operating Leases

[0001437749-21-018523:notes:138]
All significant lease arrangements are recognized at lease commencement.  Operating lease right–of-use assets and lease liabilities are recognized at commencement. The operating lease right-of-use asset includes any lease payments related to initial direct cost and prepayments and excludes any lease incentives. Lease expense is recognized on a straight-line basis over the lease term.  The Company enters into a variety of operating lease agreements through the normal course of its business, but primarily real estate leases to support its operations. The real estate lease agreements generally provide for fixed minimum rental payments and the payment of real estate taxes and insurance. Many of these real estate leases have one or more renewal options that allow the Company, at its discretion, to renew the lease for varying periods up to five years or to terminate the lease. Only renewal options or termination rights that the Company believed were likely to be exercised were included in the lease calculations.

[0001437749-21-018523:notes:139]
The Company also enters into leases for vehicles, IT equipment and service agreements, and other leases related to its manufacturing operations that are also included in the right-of-use assets and lease liability accounts if they are for a term of longer than twelve months. However, many of these leases are either short-term in nature or immaterial. The Company has made the policy election to exclude short-term leases from the balance sheet.

[0001437749-21-018523:notes:140]
Finance﻿ Leases

[0001437749-21-018523:notes:141]
As part of the adoption of ASC 842 at Neeltran, the Company identified one lease contract that is classified as a financing lease. In  February 2020, Neeltran entered into a contract to lease a copy machine for an initial term of 39 months, or through  May 2023. The Company concluded that the lease should be classified and accounted for as a finance lease as the total value of the lease payments are greater than fair value of the asset. Accordingly, on  May 6, 2021, the Company recognized a finance lease right-of-use asset and a finance lease liability of $13.2 thousand on the Neeltran opening balance sheet. As of  June 30, 2021, the right-of-use asset related to the finance lease was $12.2 thousand, net of accumulated amortization of $1.0 thousand, and is included in the property and equipment, net on the Company's consolidated balance sheet.

[0001437749-21-018523:notes:142]
Finance lease right-of-use assets and lease liabilities are recognized similar to an operating lease, at the lease commencement date or the date the lessor makes the leased asset available for use. Finance lease right-of-use assets are generally amortized on a straight-line basis over the lease term, and the carrying amount of the finance lease liabilities are (1) accreted to reflect interest using the incremental borrowing rate if the rate implicit in the lease is not readily determinable, and (2) reduced to reflect lease payments made during the period. Amortization expense for finance lease right-of-use assets and interest accretion on finance lease liabilities are recorded to depreciation expense and interest expense, respectively in our consolidated statement of operations.

[0001437749-21-018523:notes:143]
Supplemental balance sheet information related to leases at  June 30, 2021, and  March 31, 2021 are as follows (in thousands):

[0001437749-21-018523:notes:144]
|  |  | June 30, 2021 |  |  | March 31, 2021 |  |
| Leases: |  |  |  |  |  |  |  |  |
| Right-of-use assets - Financing |  | $ | 12 |  |  |  | — |  |
| Right-of-use assets - Operating |  |  | 3,764 |  |  |  | 3,747 |  |
| Total right-of-use assets |  |  | 3,776 |  |  |  | 3,747 |  |
| Lease liabilities - ST Financing |  | $ | 6 |  |  |  | — |  |
| Lease liabilities - ST Operating |  |  | 690 |  |  |  | 612 |  |
| Lease liabilities - LT Financing |  |  | 6 |  |  |  | — |  |
| Lease liabilities - LT Operating |  |  | 3,188 |  |  |  | 3,246 |  |
| Total lease liabilities |  |  | 3,890 |  |  |  | 3,858 |  |
| Weighted-average remaining lease term |  |  | 5.49 |  |  |  | 5.82 |  |
| Weighted-average discount rate |  |  | 6.55 | % |  |  | 6.72 | % |

[0001437749-21-018523:notes:145]
The costs related to the Company's finance lease are not material. The costs related to the Company's operating leases for the three months ended  June 30, 2021, and 2020 are as follows (in thousands):

[0001437749-21-018523:notes:146]
|  |  | Three Months Ended |  |
|  |  | June 30, 2021 |  |
| Operating Leases: |  |  |  |  |
| Operating lease costs - fixed |  | $ | 231 |  |
| Operating lease costs - variable |  |  | 32 |  |
| Short-term lease costs |  |  | 67 |  |
| Total lease costs |  |  | 330 |  |

[0001437749-21-018523:notes:147]
|  |  | Three Months Ended |  |
|  |  | June 30, 2020 |  |
| Operating Leases: |  |  |  |  |
| Operating lease costs - fixed |  | $ | 178 |  |
| Operating lease costs - variable |  |  | 27 |  |
| Short-term lease costs |  |  | 168 |  |
| Total lease costs |  |  | 373 |  |

[0001437749-21-018523:notes:148]
The Company’s estimated minimum future lease obligations under the Company's leases are as follows (in thousands):

[0001437749-21-018523:notes:149]
|  |  | Leases |  |
| Year ended March 31, |  |  |  |  |
| 2022 |  | $ | 695 |  |
| 2023 |  |  | 894 |  |
| 2024 |  |  | 799 |  |
| 2025 |  |  | 674 |  |
| 2026 |  |  | 673 |  |
| Thereafter |  |  | 934 |  |
| Total minimum lease payments |  |  | 4,669 |  |
| Less: interest |  |  | 779 |  |
| Present value of lease liabilities |  |  | 3,890 |  |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001437749-21-018523:notes:150]
16. Commitments and Contingencies

[0001437749-21-018523:notes:151]
Legal Contingencies

[0001437749-21-018523:notes:152]
From time to time, the Company is involved in legal and administrative proceedings and claims of various types. The Company records a liability in its consolidated financial statements for these matters when a loss is known or considered probable and the amount can be reasonably estimated. The Company reviews these estimates each accounting period as additional information is known and adjusts the loss provision when appropriate. If a matter is both probable to result in a liability and the amounts of loss can be reasonably estimated, the Company estimates and discloses the possible loss or range of loss to the extent necessary to make the consolidated financial statements not misleading. If the loss is not probable or cannot be reasonably estimated, a liability is not recorded in its consolidated financial statements.

[0001437749-21-018523:notes:153]
Other

[0001437749-21-018523:notes:154]
The Company enters into long-term construction contracts with customers that require the Company to obtain performance bonds. The Company is required to deposit an amount equivalent to some or all the face amount of the performance bonds into an escrow account until the termination of the bond. When the performance conditions are met, amounts deposited as collateral for the performance bonds are returned to the Company. In addition, the Company has various contractual arrangements in which minimum quantities of goods or services have been committed to be purchased on an annual basis.

[0001437749-21-018523:notes:155]
As of  June 30, 2021, the Company had $5.6 million of restricted cash included in long-term assets and $2.3 million of restricted cash included in current assets. As of  March 31, 2021, the Company had $5.6 million of restricted cash included in long term assets and $2.2 million of restricted cash included in current assets. These amounts included in restricted cash primarily represent deposits to secure letters of credit for various supply contracts and long-term projects, including the irrevocable letter of credit in the amount of $5.0 million to secure certain of the Company's obligations under a subcontract agreement with ComEd.  These deposits are held in interest bearing accounts.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001437749-21-018523:notes:156]
17. Business Segments

[0001437749-21-018523:notes:157]
The Company reports its financial results in two reportable business segments: Grid and Wind.

[0001437749-21-018523:notes:158]
Through the Company’s power grid offerings, the Grid business segment enables electric utilities, industrial facilities, and renewable energy project developers to connect, transmit and distribute power with exceptional efficiency, reliability, security and affordability through its transmission planning services, power electronics, and superconductor-based systems. The sales process is enabled by transmission planning services that allow it to identify power grid congestion, poor power quality and other risks, which helps the Company determine how its solutions can improve network performance. These services often lead to sales of grid interconnection solutions for wind farms and solar power plants, power quality systems, and transmission and distribution cable systems.  The Company also sells ship protection products to the U.S. Navy through its Grid business segment.

[0001437749-21-018523:notes:159]
Through the Company’s wind power offerings, the Wind business segment enables manufacturers to field wind turbines with exceptional power output, reliability and affordability.  The Company provides advanced power electronics and control system products, engineered designs, and support services. The Company supplies advanced power electronics and control systems, licenses its highly engineered wind turbine designs, and provides extensive customer support services to wind turbine manufacturers. The Company’s design portfolio includes a broad range of drive trains and power ratings of 2 megawatts ("MWs") and higher. The Company provides a broad range of power electronics and software-based control systems that are highly integrated and designed for optimized performance, efficiency, and grid compatibility.

[0001437749-21-018523:notes:160]
The operating results for the two business segments are as follows (in thousands):

[0001437749-21-018523:notes:161]
|  |  | Three Months Ended June 30, |  |
|  |  | 2021 |  |  | 2020 |  |
| Revenues: |  |  |  |  |  |  |  |  |
| Grid |  | $ | 23,501 |  |  | $ | 17,715 |  |
| Wind |  |  | 1,919 |  |  |  | 3,498 |  |
| Total |  | $ | 25,420 |  |  | $ | 21,213 |  |

[0001437749-21-018523:notes:162]
|  |  | Three Months Ended June 30, |  |
|  |  | 2021 |  |  | 2020 |  |
| Operating loss: |  |  |  |  |  |  |  |  |
| Grid |  | $ | (5,345 | ) |  | $ | (1,188 | ) |
| Wind |  |  | (763 | ) |  |  | (1,120 | ) |
| Unallocated corporate expenses |  |  | (1,391 | ) |  |  | (909 | ) |
| Total |  | $ | (7,499 | ) |  | $ | (3,217 | ) |

[0001437749-21-018523:notes:163]
The accounting policies of the business segments are the same as those for the consolidated Company. The Company’s business segments have been determined in accordance with the Company’s internal management structure, which is organized based on operating activities. The Company evaluates performance based upon several factors, of which the primary financial measures are segment revenues and segment operating loss. The disaggregated financial results of the segments reflect allocation of certain functional expense categories consistent with the basis and manner in which Company management internally disaggregates financial information for the purpose of assisting in making internal operating decisions. In addition, certain corporate expenses which the Company does not believe are specifically attributable or allocable to either of the two business segments have been excluded from the segment operating loss.

[0001437749-21-018523:notes:164]
Unallocated corporate expenses consist of loss on contingent consideration of $0.1 million in the three months ended  June 30, 2021. Additionally, unallocated corporate expenses consist of stock-based compensation expense of $1.3 million and $0.9 million in the three months ended  June 30, 2021, and 2020, respectively.

[0001437749-21-018523:notes:165]
Total assets for the two business segments as of  June 30, 2021, and  March 31, 2021, are as follows (in thousands):

[0001437749-21-018523:notes:166]
|  |  | June 30, 2021 |  |  | March 31, 2021 |  |
| Grid |  | $ | 121,355 |  |  | $ | 81,253 |  |
| Wind |  |  | 6,949 |  |  |  | 6,098 |  |
| Corporate assets |  |  | 63,863 |  |  |  | 81,515 |  |
| Total |  | $ | 192,167 |  |  | $ | 168,866 |  |


## us-gaap:NewAccountingPronouncementsAndChangesInAccountingPrinciplesTextBlock

[0001437749-21-018523:notes:167]
18. Recent Accounting Pronouncements

[0001437749-21-018523:notes:168]
In  June 2016, the FASB issued ASU 2016-13, Financial Instruments-Credit Losses (Topic 326): Measurement of Credit Losses on Financial Instruments. The amendments in ASU 2016-13 will provide more decision-useful information about the expected credit losses on financial instruments and other commitments to extend credit held by a reporting entity at each reporting date. Following the release of ASU 2019-10 in  November 2019, the new effective date, as long as the Company remains a smaller reporting company, would be annual reporting periods beginning after  December 15, 2022.  The Company is currently evaluating the impact, if any, that the adoption of ASU 2016-13  may have on its consolidated financial statements.

[0001437749-21-018523:notes:169]
In  December 2019, the FASB issued ASU 2019-12, Income Taxes (Topic 740): Simplifying the Accounting for Income Taxes. The amendments in ASU 2019-12 provide for simplified accounting to several income tax situations and removal of certain accounting exceptions. As of  April 1, 2021, we have adopted ASU 2019-12 and noted no material impact on our consolidated financial statements.


## us-gaap:SubsequentEventsTextBlock

[0001437749-21-018523:notes:170]
19. Subsequent Events

[0001437749-21-018523:notes:171]
The Company has performed an evaluation of subsequent events through the time of filing this Quarterly Report on Form 10-Q with the SEC and has determined that there are no such events to report.
