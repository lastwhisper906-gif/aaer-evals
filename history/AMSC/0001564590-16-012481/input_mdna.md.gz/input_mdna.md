# AMSC MD&A — 0001564590-16-012481


## mdna

[0001564590-16-012481:mdna:1]
[same as prior period, unchanged from 0001564590-15-009122:mdna:1]

[0001564590-16-012481:mdna:2]
largest customer, Sinovel, regarding amounts we contend are overdue. We cannot be certain as to the outcome of these proceedings; We have been named as a party in various legal proceedings, and we may be named in additional litigation, all of which will require significant management time and attention, result in significant legal expenses and may result in an unfavorable outcome, which could have a material adverse effect on our business, operating results and financial condition; and our common stock has experienced, and may continue to experience, significant market price and volume fluctuations, which may prevent our stockholders from selling our common stock at a profit and could lead to costly litigation against us that could divert our management’s attention.  These and the important factors discussed under the caption “Risk Factors” in Part 1. Item 1A of our Form 10-K for the fiscal year ended March 31, 2015, among others, could cause actual results to differ materially from those indicated by forward-looking statements made herein and presented elsewhere by management from time to time. Any such forward-looking statements represent management’s estimates as of the date of this Quarterly Report on Form 10-Q. While we may elect to update such forward-looking statements at some point in the future, we disclaim any obligation to do so, even if subsequent events cause our views to change. These forward-looking statements should not be relied upon as representing our views as of any date subsequent to the date of this Quarterly Report on Form 10-Q.

[0001564590-16-012481:mdna:3]
[same as prior period, unchanged from 0001564590-15-009122:mdna:3]

[0001564590-16-012481:mdna:4]
[same as prior period, unchanged from 0001564590-15-009122:mdna:4]

[0001564590-16-012481:mdna:5]
[same as prior period, unchanged from 0001564590-15-009122:mdna:5]

[0001564590-16-012481:mdna:6]
[same as prior period, unchanged from 0001564590-15-009122:mdna:6]

[0001564590-16-012481:mdna:7]
[same as prior period, unchanged from 0001564590-15-009122:mdna:7]

[0001564590-16-012481:mdna:8]
[same as prior period, unchanged from 0001564590-15-009122:mdna:8]

[0001564590-16-012481:mdna:9]
[same as prior period, unchanged from 0001564590-15-009122:mdna:9]

[0001564590-16-012481:mdna:10]
[same as prior period, unchanged from 0001564590-15-009122:mdna:10]

[0001564590-16-012481:mdna:11]
[same as prior period, unchanged from 0001564590-15-009122:mdna:11]

[0001564590-16-012481:mdna:12]
[same as prior period, unchanged from 0001564590-15-009122:mdna:12]

[0001564590-16-012481:mdna:13]
We have experienced recurring operating losses and as of December 31, 2015, had an accumulated deficit of $924.8 million. In addition, we have experienced recurring negative operating cash flows. At December 31, 2015, we had cash and cash equivalents of $36.4 million. Cash used in operations for the nine months ended December 31, 2015 was $7.8 million.

[0001564590-16-012481:mdna:14]
Over the last several years, we have entered into several debt and equity financing arrangements in order to enhance liquidity.  Since April 1, 2012, we generated aggregate cash flows from financing activities of $72.0 million.  This amount includes proceeds from our April 2015 equity offering, which generated net proceeds of approximately $22.3 million, after deducting underwriting discounts and commissions and estimated offering expenses.  See Note 10, “Debt”, and Note 12 “Stockholders Equity” for further discussion of these financing arrangements. We believe that we are in compliance with the covenants and restrictions included in the agreements governing our debt arrangements as of December 31, 2015.

[0001564590-16-012481:mdna:15]
[same as prior period, unchanged from 0001564590-15-009122:mdna:15]

[0001564590-16-012481:mdna:16]
[same as prior period, unchanged from 0001564590-15-009122:mdna:16]

[0001564590-16-012481:mdna:17]
We cannot provide any assurance as to the outcome of these legal actions. For more information about these legal proceedings, see Part II, Item 1, “Legal Proceedings.”

[0001564590-16-012481:mdna:18]
Our cash requirements depend on numerous factors, including the successful completion of our product development activities, our ability to commercialize our Resilient Electric Grid (“REG”) and ship protection system solutions, rate of customer and market adoption of our products, collecting receivables according to established terms, and the continued availability of U.S. government funding during the product development phase of our Superconductors based products. In addition we are focused on achieving certain operational objectives.  During the first half of fiscal 2015, we achieved our near term objectives, including announcing that Washington D.C.’s Pepco is conducting a deployment study of our REG system; receiving a large wind order from Inox Wind Ltd (“Inox”); announcing new D-VAR orders; and announcing new authorized funding for Project REG.  In the longer term, we expect to have a decision on moving to the manufacturing and construction phase of Project REG and we expect to receive additional business from the U.S. Navy.  In addition, in December 2015, we entered into a set of strategic agreements valued at approximately $210.0 million with Inox, which includes a multi-year supply contract pursuant to which the Company will supply electric control systems to Inox and a license agreement allowing Inox to manufacture a limited number of electrical control systems over the next three to four years.  After this initial three to four year period, the Company will continue as Inox’s preferred supplier and Inox will be required to purchase from the Company a majority of its electric control systems requirements for an additional three-year period.  These agreements are expected to provide a foundation for the business as we pursue our longer-term objectives.  Significant deviations to our business plan with regard to these factors and events, which are important drivers to our business, could have a material adverse effect on our operating performance, financial condition, and future business prospects. We expect to pursue the expansion of our operations through internal growth, diversification of our customer base, and potential strategic alliances. See below for a discussion of liquidity and capital resources.

[0001564590-16-012481:mdna:19]
On October 6, 2015, 100% of the outstanding common stock of Blade Dynamics Limited (“Blade Dynamics”) was acquired by a subsidiary of General Electric Company.  After deducting transaction expenses, we received net proceeds of $2.5 million from the sale, which was recorded as a gain during the three months ended December 31, 2015.  Additionally, under the terms of the purchase agreement, we may be entitled to receive up to an additional $1.6 million in proceeds, upon the successful achievement of certain milestones by Blade Dynamics over the next three years.  We no longer believe our investment in Tres Amigas, LLC, a Delaware limited liability Company (“Tres Amigas”) is recoverable.  We fully impaired our remaining investment in Tres Amigas during the three months ended June 30, 2015. (See Note 14, “Minority Investments”, for further information about such investment).

[0001564590-16-012481:mdna:20]
[same as prior period, unchanged from 0001564590-15-009122:mdna:20]

[0001564590-16-012481:mdna:21]
The preparation of the unaudited condensed consolidated financial statements requires that we make estimates and judgments that affect the reported amounts of assets, liabilities, revenues and expenses, and related disclosure of contingent assets and liabilities. We base our estimates on historical experience and various other assumptions that are believed to be reasonable under the circumstances, the results of which form the basis for making judgments about the carrying values of assets and liabilities that are not readily apparent from other sources. Actual results may differ under different assumptions or conditions. There were no significant changes in the critical accounting policies during the nine months ended December 31, 2015 that were disclosed in our Form 10-K for fiscal 2014, which ended on March 31, 2015.

[0001564590-16-012481:mdna:22]
[same as prior period, unchanged from 0001564590-15-009122:mdna:22]

[0001564590-16-012481:mdna:23]
Three and nine months ended December 31, 2015 compared to the three and nine months ended December 31, 2014

[0001564590-16-012481:mdna:24]
[same as prior period, unchanged from 0001564590-15-009122:mdna:24]

[0001564590-16-012481:mdna:25]
Total revenues increased 21% and 51% to $25.8 million and $68.5 million for the three and nine months ended December 31, 2015, respectively, compared to $21.3 million and $45.4 million for the three and nine months ended December 31, 2014, respectively.  Our revenues are summarized as follows (in thousands):

[0001564590-16-012481:mdna:26]
|  | Three months ended December 31, |  |  | Nine months ended December 31, |  |
|  | 2015 |  |  | 2014 |  |  | 2015 |  |  | 2014 |  |
| Revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Wind | $ | 17,229 |  |  | $ | 15,131 |  |  | $ | 48,976 |  |  | $ | 30,244 |  |
| Grid |  | 8,543 |  |  |  | 6,119 |  |  |  | 19,523 |  |  |  | 15,157 |  |
| Total | $ | 25,772 |  |  | $ | 21,250 |  |  | $ | 68,499 |  |  | $ | 45,401 |  |

[0001564590-16-012481:mdna:27]
Our Wind business unit accounted for 67% and 71% of total revenues for the three and nine months ended December 31, 2015, respectively, compared to 71% and 67% for the three and nine months ended December 31, 2014, respectively. Revenues in the Wind business unit increased 14% and 62% to $17.2 million and $49.0 million in the three and nine months ended December 31, 2015, respectively, from $15.1 million and $30.2 million in the three and nine months ended December 31, 2014, respectively. Wind business unit revenues during the three months ended December 31, 2015 increased primarily due to higher volume of sales to Inox in India.  Wind business unit revenues in the nine months ended December 31, 2015, increased primarily due to higher volume of sales to Inox in India and Beijing JINGCHENG New Energy (“JCNE”) in China.

[0001564590-16-012481:mdna:28]
Our Grid business unit accounted for 33% and 29% of total revenues for the three and nine months ended December 31, 2015, respectively, compared to 29% and 33% for the three and nine months ended December 31, 2014, respectively. Our Grid business unit revenues increased 40% and 29% to $8.5 million and $19.5 million in the three and nine months ended December 31, 2015, respectively, from $6.1 million and $15.2 million in the three and nine months ended December 31, 2014, respectively. Grid business unit revenues increased in the three and nine months ended December 31, 2015 primarily due to higher D-VAR system revenues, partially offset by lower HTS wire sales, particularly in the nine months ended December 31, 2015.

[0001564590-16-012481:mdna:29]
Revenues from Project HYDRA and Project REG represented 6% and 7% of our Grid business unit’s revenue for the three and nine months ended December 31, 2015, respectively, compared to 10% and 9% for the three and nine months ended December 31, 2014, respectively.  Our revenues for these projects are derived by funding from the Department of Homeland Security (“DHS”).  Project HYDRA is a project with Consolidated Edison, Inc. (“ConEd”) to demonstrate our REG product in ConEd’s electric grid.  Project REG is a project with Commonwealth Edison, Inc. (“ComEd”) to permanently install our REG product in ComEd’s electric grid.  This fault current limiting cable system is designed to utilize customized Amperium® HTS wire, and ancillary controls to deliver more power through the grid while also being able to suppress power surges that can disrupt service. DHS has committed 100% of the total expected funding of $29.0 million for Project HYDRA.  Under Project REG, DHS is expected to invest up to $60.0 million to enable the deployment of the REG system in Chicago’s electric grid.  We are nearing completion on the first phase of the project which among other things, will result in the creation of a detailed deployment plan.  In the fiscal year ended March 31, 2015, DHS committed funding of $1.5 million for the first phase of the project.  During the three months ended September 30, 2015, DHS committed funding of an additional $3.7 million, for a total of $5.2 million.  This additional funding serves as a bridge between the detailed deployment plan and construction phases of the project.  The period of performance to complete the engineering work extends through May 31, 2017.  The final phase of the project involves the delivery of the REG system and the associated construction and deployment of the system in ComEd’s grid.  We will not begin this phase of the project until all parties agree to proceed.  There can be no assurance that all parties will agree to proceed with the project.

[0001564590-16-012481:mdna:30]
The following table sets forth customers who represented 10% or more of our total revenues for the three and nine months ended December 31, 2015 and 2014:

[0001564590-16-012481:mdna:31]
|  | Three months ended December 31, |  |  | Nine months ended December 31, |  |
|  | 2015 |  |  | 2014 |  |  | 2015 |  |  | 2014 |  |
| INOX Wind Limited |  | 64 | % |  |  | 61% |  |  |  | 58% |  |  |  | 54% |  |
| Fuji Bridex Pte Ltd |  | 18 | % |  | —% |  |  | <10% |  |  | —% |  |

[0001564590-16-012481:mdna:32]
[same as prior period, unchanged from 0001564590-15-009122:mdna:32]

[0001564590-16-012481:mdna:33]
Cost of revenues increased by 6% and 27% to $19.3 million and $55.8 million for the three and nine months ended December 31, 2015, respectively, compared to $18.1 million and $44.0 million for the three and nine months ended December 31, 2014, respectively. Gross margin was 25.3% and 18.6% for the three and nine months ended December 31, 2015, respectively, compared to 14.9% and 3.2% for the three and nine months ended December 31, 2014, respectively. The increases in gross margin for the three and nine months ended December 31, 2015 as compared to the same periods in fiscal 2014, were primarily due to higher revenues and a more favorable product mix for our D-VAR product as well as from higher Wind royalty revenues in the nine months ended December 31, 2015.

[0001564590-16-012481:mdna:34]
[same as prior period, unchanged from 0001564590-15-009122:mdna:34]

[0001564590-16-012481:mdna:35]
[same as prior period, unchanged from 0001564590-15-009122:mdna:35]

[0001564590-16-012481:mdna:36]
R&D expenses decreased by 1% each to $2.8 million and $8.9 million for both the three and nine months ended December 31, 2015, respectively, from $2.8 million and $9.0 million for the three and nine months ended December 31, 2014, respectively.  The slight decreases in both periods are primarily the result of lower stock compensation expense partially offset by new product development expenses in our Grid segment.

[0001564590-16-012481:mdna:37]
[same as prior period, unchanged from 0001564590-15-009122:mdna:37]

[0001564590-16-012481:mdna:38]
SG&A expenses decreased by 7% and 9% to $7.0 million and $21.3 million in the three and nine months ended December 31, 2015, respectively, from $7.5 million and $23.5 million in the three and nine months ended December 31, 2014, respectively. The decreases in SG&A expenses were due primarily to the realization of savings from cost reduction actions that were implemented in prior periods as well as reductions in stock compensation and legal costs.

[0001564590-16-012481:mdna:39]
[same as prior period, unchanged from 0001564590-15-009122:mdna:39]

[0001564590-16-012481:mdna:40]
We recorded an arbitration award expense of $10.2 million in the nine months ended December 31, 2014 following a decision by the Arbitration Tribunal for the ICC International Court of Arbitration on August 29, 2014 finding us liable for damages under a breach of contract proceeding against Ghodawat Energy Pvt Ltd (“Ghodawat”).

[0001564590-16-012481:mdna:41]
[same as prior period, unchanged from 0001564590-15-009122:mdna:41]

[0001564590-16-012481:mdna:42]
We recorded amortization expense related to our core technology and know-how, trade names and trademark intangible assets of less than $0.1 million and $0.1 million in the three and nine months ended December 31, 2015 and 2014, respectively.

[0001564590-16-012481:mdna:43]
[same as prior period, unchanged from 0001564590-15-009122:mdna:43]

[0001564590-16-012481:mdna:44]
We recorded restructuring and impairment charges of $0.8 million in the nine months ended December 31, 2015, which included an impairment charge of $0.7 million to fully impair our investment in Tres Amigas as our investment is no longer deemed recoverable. We recorded $0.5 million and $5.4 million of restructuring and impairment charges in the three and nine months ended December 31, 2014, respectively. These amounts include restructuring charges of $0.5 million and $1.9 million which were recorded during the three and nine months ended December 31, 2014.  These amounts include severance, relocation, lease termination and other costs associated with the consolidation of our facility in Middleton, WI into our facility in Devens, MA, as well as headcount reductions in our China operation, primarily during the nine months ended December 31, 2014.  In addition, the $5.4 million recorded in the nine months ended December 31, 2014 includes an impairment charge of $3.5 million on our minority investment in Blade Dynamics.  The impairment charge followed an analysis in which we determined that this investment was not recoverable due to a dilutive financing which resulted in the loss of certain of our shareholder rights, as well as certain operational issues in the company.

[0001564590-16-012481:mdna:45]
[same as prior period, unchanged from 0001564590-15-009122:mdna:45]

[0001564590-16-012481:mdna:46]
[same as prior period, unchanged from 0001564590-15-009122:mdna:46]

[0001564590-16-012481:mdna:47]
|  | Three months ended December 31, |  |  | Nine months ended December 31, |  |
|  | 2015 |  |  | 2014 |  |  | 2015 |  |  | 2014 |  |
| Operating (loss) profit: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Wind | $ | (263 | ) |  | $ | 1,301 |  |  | $ | (2,127 | ) |  | $ | (16,790 | ) |
| Grid |  | (2,342 | ) |  |  | (7,050 | ) |  |  | (12,963 | ) |  |  | (20,016 | ) |
| Unallocated corporate expenses |  | (707 | ) |  |  | (1,986 | ) |  |  | (3,321 | ) |  |  | (9,995 | ) |
| Total | $ | (3,312 | ) |  | $ | (7,735 | ) |  | $ | (18,411 | ) |  | $ | (46,801 | ) |

[0001564590-16-012481:mdna:48]
Our Wind segment generated operating losses of $0.3 million and $2.1 million in the three and nine months ended December 31, 2015, respectively, compared to profit of $1.3 million and a loss of $16.8 million in the three and nine months ended December 31, 2014, respectively. The increase in the Wind business unit operating loss during the three months ended December 31, 2015 was due primarily to the decreased consumption of zero-cost inventory and lower royalty revenues, partially offset by higher ECS product revenues.  The decrease in the Wind business unit operating loss during the nine months ended December 31, 2015 was due primarily to increased revenues for shipments to Inox in India and JCNE in China, a favorable revenue mix as a result of higher royalty revenues in the nine months ended December 31, 2015, and a charge of $10.2 million in the nine months ended December 31, 2014 relating to the arbitration award to Ghodawat.

[0001564590-16-012481:mdna:49]
The operating losses in our Grid segment decreased to $2.3 million and $13.0 million in the three and nine months ended December 31, 2015, respectively, compared to $7.0 million and $20.0 million in the three and nine months ended December 31, 2014, respectively. The decrease in the Grid business unit operating loss during the three months ended December 31, 2015 was driven primarily by increased D-VAR revenues in the current year period.  The decrease in the Grid business unit operating loss during the nine months ended December 31, 2015 was driven primarily by higher D-VAR revenues, increased production which resulted in better factory absorption, and the favorable impact of consolidating our Wisconsin facility into our Massachusetts facility during fiscal year 2014 which improved gross margin.

[0001564590-16-012481:mdna:50]
Unallocated corporate expenses primarily include stock-based compensation expense of $0.7 million and $2.5 million for the three and nine months ended December 31, 2015, respectively, and an impairment charge of $0.7 million, for the nine months ended December 31, 2015.  Unallocated corporate expenses primarily consist of stock-based compensation expense of $1.5 million and $4.6 million, and restructuring charges of $0.5 million and $5.4 million for the three and nine months ended December 31, 2014, respectively.

[0001564590-16-012481:mdna:51]
[same as prior period, unchanged from 0001564590-15-009122:mdna:51]

[0001564590-16-012481:mdna:52]
The change in fair value of derivatives and warrants resulted in a loss of $1.1 million and a gain of $0.4 million in the three and nine months ended December 31, 2015, respectively, compared to gains of $2.3 million and $3.0 million in the three and nine months ended December 31, 2014, respectively. The changes in the fair value were primarily driven by changes in stock price, which is a key valuation metric.

[0001564590-16-012481:mdna:53]
Gain on sale of minority interest

[0001564590-16-012481:mdna:54]
We recorded a gain on sale of minority interest of $2.5 million in the three months ended December 31, 2015, related to the sale of our investment in Blade Dynamics in that period.

[0001564590-16-012481:mdna:55]
[same as prior period, unchanged from 0001564590-15-009122:mdna:53]

[0001564590-16-012481:mdna:56]
Interest expense, net, was $0.2 million and $0.8 million in the three and nine months ended December 31, 2015, respectively, compared to $0.5 million and $1.6 million in the three and nine months ended December 31, 2014, respectively. The decreases in interest expense were due primarily to the maturity of one of our term loans with Hercules Technology Growth Capital, Inc. (“Hercules”) in December 2014.

[0001564590-16-012481:mdna:57]
Other (expense) income, net

[0001564590-16-012481:mdna:58]
Other (expense) income, net, was an expense of less than $0.1 million and $1.2 million in the three and nine months ended December 31, 2015, respectively, compared to other expense, net of $0.2 million and other income, net of $0.4 million in the three and nine months ended December 31, 2014, respectively.  The decrease in other expense, net during the three months ended December 31, 2015, was primarily driven by lower foreign currency losses.  The increase in other expense during the nine months ended December 31, 2015 was driven primarily by higher foreign currency losses in the current year as opposed to foreign currency gains in the prior year period, partially offset by lower minority interest charges resulting from the impairment of our minority interest in Tres Amigas during the three months ended June 30, 2015.

[0001564590-16-012481:mdna:59]
[same as prior period, unchanged from 0001564590-15-009122:mdna:57]

[0001564590-16-012481:mdna:60]
Income tax expense was $0.8 million and $2.3 million in the three and nine months ended December 31, 2015, respectively, compared to $0.2 million and $0.4 million in the three and nine months ended December 31, 2014, respectively. The increases in income tax expense in both periods were primarily due to taxes related to dividend withholding taxes and increases in income taxes, including tax reserves, in foreign jurisdictions.

[0001564590-16-012481:mdna:61]
[same as prior period, unchanged from 0001564590-15-009122:mdna:59]

[0001564590-16-012481:mdna:62]
[same as prior period, unchanged from 0001564590-15-009122:mdna:60]

[0001564590-16-012481:mdna:63]
We define non-GAAP net loss as net loss before gain on sale of investment in Blade Dynamics, stock-based compensation, arbitration award expense, amortization of acquisition-related intangibles, restructuring and impairment charges, consumption of zero cost-basis inventory, changes in fair value of derivatives and warrants, non-cash interest expense, and the other non-cash or unusual charges, net of any tax effects related to these items, indicated in the table below. We believe non-GAAP net loss assists management and investors in comparing our performance across reporting periods on a consistent basis by excluding these non-cash or non-recurring charges that we do not believe are indicative of our core operating performance. We also regard non-GAAP net loss as a useful measure of operating performance which more closely aligns net loss with cash used in/provided by continuing operations. In addition, we use non-GAAP net loss as a factor in evaluating management’s performance when determining incentive compensation and to evaluate the effectiveness of our business strategies. A reconciliation of non-GAAP to GAAP net loss is set forth in the table below (in thousands, except per share data):

[0001564590-16-012481:mdna:64]
|  | Three months ended December 31, |  |  | Nine months ended December 31, |  |
|  | 2015 |  |  | 2014 |  |  | 2015 |  |  | 2014 |  |
| Net loss | $ | (2,957 | ) |  | $ | (6,353 | ) |  | $ | (19,777 | ) |  | $ | (45,292 | ) |
| Gain on sale of interest in Blade Dynamics, net of tax effect |  | (2,354 | ) |  |  | - |  |  |  | (2,354 | ) |  |  | - |  |
| Stock-based compensation |  | 708 |  |  |  | 1,521 |  |  |  | 2,542 |  |  |  | 4,620 |  |
| Arbitration award expense |  | - |  |  |  | - |  |  |  | - |  |  |  | 10,188 |  |
| Amortization of acquisition-related intangibles |  | 39 |  |  |  | 39 |  |  |  | 118 |  |  |  | 118 |  |
| Restructuring and impairment charges | - |  |  |  | 507 |  |  |  | 779 |  |  |  | 5,416 |  |
| Consumption of zero cost-basis inventory |  | (1,543 | ) |  |  | (3,143 | ) |  |  | (3,612 | ) |  |  | (5,710 | ) |
| Change in fair value of derivatives and warrants |  | 1,092 |  |  |  | (2,288 | ) |  |  | (409 | ) |  |  | (3,048 | ) |
| Non-cash interest expense |  | 83 |  |  |  | 147 |  |  |  | 290 |  |  |  | 490 |  |
| Non-GAAP net loss | $ | (4,932 | ) |  | $ | (9,570 | ) |  | $ | (22,423 | ) |  | $ | (33,218 | ) |
| Non-GAAP loss per share | $ | (0.36 | ) |  | $ | (1.09 | ) |  | $ | (1.72 | ) |  | $ | (4.04 | ) |
| Weighted average shares outstanding - basic and diluted |  | 13,539 |  |  |  | 8,764 |  |  |  | 13,052 |  |  |  | 8,228 |  |

[0001564590-16-012481:mdna:65]
We incurred non-GAAP net losses of $4.9 million and $22.4 million or $0.36 and $1.72 per share, for the three and nine months ended December 31, 2015, respectively, compared to non-GAAP net losses of $9.6 million and $33.2 million or $1.09 and $4.04 per share, for the three and nine months ended December 31, 2014, respectively. The decreases in non-GAAP net loss were driven primarily by higher revenues in both of our business units, including higher royalty revenues in our Wind segment, particularly in the nine months ended December 31, 2015, as previously discussed, as well as higher gross margin and lower operating expenses.

[0001564590-16-012481:mdna:66]
[same as prior period, unchanged from 0001564590-15-009122:mdna:65]

[0001564590-16-012481:mdna:67]
At December 31, 2015, we had cash, cash equivalents, and restricted cash of $37.7 million, compared to $24.5 million at March 31, 2015, an increase of $13.2 million. Our cash and cash equivalents, and restricted cash are summarized as follows (in thousands):

[0001564590-16-012481:mdna:68]
|  | December 31, |  |  | March 31, |  |
|  | 2015 |  |  | 2015 |  |
| Cash and cash equivalents | $ | 36,437 |  |  | $ | 20,490 |  |
| Restricted cash |  | 1,228 |  |  |  | 4,059 |  |
| Total cash, cash equivalents, and restricted cash | $ | 37,665 |  |  | $ | 24,549 |  |

[0001564590-16-012481:mdna:69]
For the nine months ended December 31, 2015, net cash used in operating activities was $7.8 million compared to $20.9 million for the nine months ended December 31, 2014. The decrease in net cash used in operations was due primarily to lower net loss for the reasons discussed above offset by an increase in cash used from changes in operating asset and liability accounts during the nine months ended December 31, 2015 compared to the nine months ended December 31, 2014.

[0001564590-16-012481:mdna:70]
For the nine months ended December 31, 2015, net cash provided by investing activities was $4.9 million, compared to $4.4 million for the nine months ended December 31, 2014. The increase in net cash provided by investing activities was due primarily to the proceeds from the sale of our minority interest in Blade Dynamics, partially offset by a net decrease in the change in restricted cash of $1.9 million compared to the nine months ended December 31, 2014.

[0001564590-16-012481:mdna:71]
For the nine months ended December 31, 2015, net cash provided by financing activities was $19.2 million compared to $9.7 million in the nine months ended December 31, 2014. The increase in net cash provided by financing activities was primarily due to net proceeds of $22.3 million from the issuance of 4.0 million shares of common stock on April 29, 2015, which was an increase of $7.3 million over the prior year period net offering proceeds from the sale of shares under our At-Market Sales Arrangement and an equity offering in November 2014.  Additionally, amounts repaid for debt decreased by $3.3 million compared to the prior year period due to the repayment in full of one of our term loans in the prior-year period.

[0001564590-16-012481:mdna:72]
At December 31, 2015, we had $0.4 million of restricted cash included in current assets and $0.8 million of restricted cash included in long-term assets. These amounts included in restricted cash primarily represent deposits to secure letters of credit for various supply contracts and customs authorities. These deposits are held in interest bearing accounts.

[0001564590-16-012481:mdna:73]
[same as prior period, unchanged from 0001564590-15-009122:mdna:72]

[0001564590-16-012481:mdna:74]
[same as prior period, unchanged from 0001564590-15-009122:mdna:73]

[0001564590-16-012481:mdna:75]
[same as prior period, unchanged from 0001564590-15-009122:mdna:74]

[0001564590-16-012481:mdna:76]
The Term Loans are secured by substantially all of our existing and future assets, including a mortgage on real property owned by our wholly-owned subsidiary, ASC Devens LLC, and located at 64 Jackson Road, Devens, Massachusetts.  The Term Loans contain certain covenants that restrict our ability to, among other things, incur or assume certain debt, merge or consolidate, materially change the nature of our business, make certain investments, acquire or dispose of certain assets, make guarantees or grant liens on our assets, make certain loans, advances or investments, declare dividends or make distributions or enter into transactions with affiliates. In addition, there is a covenant that requires us to maintain a minimum unrestricted cash balance (the “Minimum Threshold”) in the United States.  As part of the Hercules Second Amendment, this Minimum Threshold was amended to be the lower of $5.0 million or the aggregate outstanding principal balance of the Term Loans.  As a result of the April 2015 offering (see discussion below), the Minimum Threshold was reduced to the lesser of $2.0 million or the aggregate outstanding principal balance of the Term Loans.  As of December 31, 2015, the Minimum Threshold was $2.0 million.  The events of default under the Term Loans include, but are not limited to, failure to pay amounts due, breaches of covenants, bankruptcy events, cross defaults under other material indebtedness and the occurrence of a material adverse effect and/or change in control. In the case of a continuing event of default, Hercules may, among other remedies, declare due all unpaid principal amounts outstanding and any accrued but unpaid interest and foreclose on all collateral granted to Hercules as security under the Term Loans.

[0001564590-16-012481:mdna:77]
We believe we are in and expect to remain in compliance with the covenants and restrictions under the Term Loans as of the date of this Quarterly Report on Form 10-Q. If we fail to stay in compliance with our covenants or experience some other event of default, we may be forced to repay the outstanding principal on the Term Loans.

[0001564590-16-012481:mdna:78]
We have experienced recurring operating losses and as of December 31, 2015, had an accumulated deficit of $924.8 million. In addition, we have experienced recurring negative operating cash flows. At December 31, 2015, we had cash and cash equivalents of $36.4 million, as compared to cash used in operations of $7.8 million for the nine months ended December 31, 2015. On April 29, 2015, we completed an equity offering which raised net proceeds of $22.3 million after deducting underwriting discounts and commissions and estimated offering expenses payable by us from the sale of 4.0 million shares of our common stock at a public offering price of $6.00 per share.  On October 6, 2015, 100% of the outstanding common stock of Blade Dynamics was acquired by a subsidiary of General Electric Company.  After deducting transaction expenses, we received net proceeds of $2.5 million from the sale, which was recorded as a gain during the three months ended December 31, 2015.  Additionally, under the terms of the purchase agreement, we may be entitled to receive up to an additional $1.6 million in proceeds, upon the successful achievement of certain milestones by Blade Dynamics over the next three years.   In addition, in December 2015, we entered into a set of strategic agreements valued at approximately $210.0 million with Inox, which includes a multi-year supply contract pursuant to which we will supply electric control systems to Inox and a license agreement allowing Inox to manufacture a limited number of electrical control systems over the next three to four years.  After this initial three to four year period, we will continue as Inox’s preferred supplier and Inox will be required to purchase from us a majority of its electric control systems requirements for an additional three-year period.  These agreements are expected to provide a foundation for the business as we pursue our longer-term objectives.

[0001564590-16-012481:mdna:79]
We believe we have sufficient available liquidity to fund our operations, capital expenditures and scheduled cash payments under our debt obligations for the next twelve months. Our liquidity is highly dependent on our ability to increase revenues, control our operating costs, and our ability to maintain compliance with the covenants and restrictions on our debt obligations (or obtain waivers from our lender in the event of non-compliance), and our ability to raise additional capital, if necessary.  There can be no assurance that we will be able to continue to raise additional capital from other sources or execute on any other means of improving our liquidity as described above.

[0001564590-16-012481:mdna:80]
Legal Proceedings

[0001564590-16-012481:mdna:81]
We are involved in legal and administrative proceedings and claims of various types. See Part II, Item 1, “Legal Proceedings,” for additional information. We record a liability in our consolidated financial statements for these matters when a loss is known or considered probable and the amount can be reasonably estimated. We review these estimates each accounting period as additional information is known and adjust the loss provision when appropriate. If a matter is both probable to result in liability and the amounts of loss can be reasonably estimated, we estimate and disclose the possible loss or range of loss to the extent necessary to make the consolidated financial statements not misleading. If the loss is not probable or cannot be reasonably estimated, a liability is not recorded in our consolidated financial statements.

[0001564590-16-012481:mdna:82]
[same as prior period, unchanged from 0001564590-15-009122:mdna:83]

[0001564590-16-012481:mdna:83]
[same as prior period, unchanged from 0001564590-15-009122:mdna:84]

[0001564590-16-012481:mdna:84]
[same as prior period, unchanged from 0001564590-15-009122:mdna:85]

[0001564590-16-012481:mdna:85]
[same as prior period, unchanged from 0001564590-15-009122:mdna:86]

[0001564590-16-012481:mdna:86]
[same as prior period, unchanged from 0001564590-15-009122:mdna:87]

[0001564590-16-012481:mdna:87]
In May 2014, the FASB and the International Accounting Standards Board (IASB) issued, ASU Revenue from Contracts with Customers 2014-09 (Topic 606). The guidance substantially converges final standards on revenue recognition between the FASB and IASB providing a framework on addressing revenue recognition issues and, upon its effective date, replaces almost all existing revenue recognition guidance, including industry-specific guidance, in current U.S. generally accepted accounting principles.  The ASU is effective for annual reporting periods beginning after December 15, 2017.  We are currently evaluating the impact, if any, the adoption of ASU 2014-09 may have on our current practices.

[0001564590-16-012481:mdna:88]
In July 2014, the FASB issued ASU 2014-12, Compensation – Stock Compensation (Topic 718): Accounting for Share Based Payments When the Terms of an Award Provide that a Performance Target Could be Achieved after the Requisite Service Period.    To account for such awards, a reporting entity should apply existing guidance in FASB Accounting Standards Codification Topic 718, Compensation – Stock Compensation, as it relates to awards with performance conditions that affect vesting.  As such, the performance target should not be reflected in estimating the grant-date fair value of the award. This ASU is effective for annual reporting periods and interim periods, within those annual periods beginning after December 15, 2015.  We are currently evaluating the impact, if any, the adoption of ASU 2014-12 may have on our current practices.

[0001564590-16-012481:mdna:89]
In August 2014, the FASB issued ASU 2014-15, Presentation of Financial Statements – Going Concern (Subtopic 205-40): Disclosure of Uncertainties About an Entity’s Ability to Continue as a Going Concern.  The new standard explicitly requires the assessment at interim and annual periods, and provides management with its own disclosure guidance. This ASU is effective for annual reporting periods and interim periods, within those annual periods ending after December 15, 2016.  We are currently evaluating the impact, if any, the adoption of ASU 2014-15 may have on our current practices.

[0001564590-16-012481:mdna:90]
In April 2015, the FASB issued ASU 2015-03 Interest—Imputation of Interest (Subtopic 835-30): Simplifying the Presentation of Debt Issuance Costs.  The amendments in ASU 2015-03 require an entity to present debt issuance costs on the balance sheet as a direct deduction from the related debt liability as opposed to an asset. Amortization of the costs will continue to be reported as interest expense. This ASU is effective for annual reporting periods beginning after December 15, 2015, and interim periods within those fiscal years.  We are currently evaluating the impact, if any, the adoption of ASU 2015-03 may have on our current practices and currently do not believe there will be an impact on our consolidated results of operations, financial condition, or cash flow.

[0001564590-16-012481:mdna:91]
In June 2015, the FASB issued ASU 2015-10 Technical Corrections and Improvements.  The amendments in ASU 2015-10 clarify and correct some of the difference that arose between original guidance from FASB, EITF and other sources, and the translation into the new Codification. This ASU is effective for annual reporting periods beginning after December 15, 2015, and interim periods within those fiscal years.  We are currently evaluating the impact, if any, the adoption of ASU 2015-10 may have on our current practices and currently do not believe there will be an impact on our consolidated results of operations, financial condition, or cash flow.

[0001564590-16-012481:mdna:92]
In July 2015, the FASB issued ASU 2015-11 Inventory (Topic 330): Simplifying the Measurement of Inventory.  The amendments in ASU 2015-11 clarify the proper way to identify market value in the use of lower of cost or market value valuation method.  As market value could be determined multiple ways under prior standards, it will now be considered as net realizable value. This ASU is effective for annual reporting periods beginning after December 15, 2016, and interim periods within those fiscal years.  We are currently evaluating the impact, if any, the adoption of ASU 2015-11 may have on our current practices.

[0001564590-16-012481:mdna:93]
In September 2015, the FASB issued ASU 2015-16 Business Combinations (Topic 805): Simplifying the Accounting for Measurement-Period Adjustments.  The amendments in ASU 2015-16 require that an acquirer recognize adjustments to provisional amounts identified during the measurement period in the reporting period in which the adjustment amounts are determined. This ASU is effective for annual reporting periods beginning after December 15, 2015, and interim periods within those fiscal years.  We are currently evaluating the impact, if any, the adoption of ASU 2015-16 may have on our current practices, and currently do not believe there will be an impact on our consolidated results of operations, financial condition, or cash flow.

[0001564590-16-012481:mdna:94]
In November 2015, the FASB issued ASU 2015-17 Income Taxes (Topic 740): Balance Sheet Classification of Deferred Taxes.  The amendments in ASU 2015-17 require that deferred tax liabilities and assets be classified as noncurrent in a classified statement of financial position. This ASU is effective for annual reporting periods beginning after December 15, 2016, and interim periods within those fiscal years.  We are currently evaluating the impact, if any, the adoption of ASU 2015-17 may have on our current practices.

[0001564590-16-012481:mdna:95]
In January 2016, the FASB issued ASU 2016-01 Financial Instruments—Overall (Subtopic 825-10): Recognition and Measurement of Financial Assets and Financial Liabilities.  The amendments in ASU 2016-01 will enhance the reporting model for financial instruments to provide users of financial statements with more decision-useful information. This ASU is effective for annual reporting periods beginning after December 15, 2017, and interim periods within those fiscal years.  We are currently evaluating the impact, if any, the adoption of ASU 2016-01 may have on our current practices.
