# AMSC notes — 0001437749-21-001877


## amsc:AccountsReceivableTableTextBlock

[0001437749-21-001877:notes:1]
|  |  | December 31, 2020 |  |  | March 31, 2020 |  |
| Accounts receivable (billed) |  | $ | 7,897 |  |  | $ | 11,276 |  |
| Accounts receivable (unbilled) |  |  | 4,201 |  |  |  | 5,711 |  |
| Less: Allowance for doubtful accounts |  |  | (15 | ) |  |  | — |  |
| Accounts receivable, net |  | $ | 12,083 |  |  | $ | 16,987 |  |


## amsc:AccountsReceivableTextBlock

[0001437749-21-001877:notes:2]
8.
 Accounts Receivable

[0001437749-21-001877:notes:3]
[same as prior period, unchanged from 0001437749-20-022522:notes:3]

[0001437749-21-001877:notes:4]
December 31, 2020

[0001437749-21-001877:notes:5]
[same as prior period, unchanged from 0001437749-20-022522:notes:5]

[0001437749-21-001877:notes:6]
[same as prior period, unchanged from 0001437749-20-022522:notes:6]

[0001437749-21-001877:notes:7]
[same as prior period, unchanged from 0001437749-20-022522:notes:7]

[0001437749-21-001877:notes:8]
[same as prior period, unchanged from 0001437749-20-022522:notes:8]

[0001437749-21-001877:notes:9]
[same as prior period, unchanged from 0001437749-20-022522:notes:9]

[0001437749-21-001877:notes:10]
million for the

[0001437749-21-001877:notes:11]
three
 and 
nine

[0001437749-21-001877:notes:12]
months ended

[0001437749-21-001877:notes:13]
[same as prior period, unchanged from 0001437749-20-022522:notes:11]

[0001437749-21-001877:notes:14]
allowance for the

[0001437749-21-001877:notes:15]
December 31, 2019

[0001437749-21-001877:notes:16]
[same as prior period, unchanged from 0001437749-20-022522:notes:14]


## amsc:AssetsAndLiabilitiesLesseeTableTextBlock

[0001437749-21-001877:notes:17]
|  |  | December 31, 2020 |  |  | March 31, 2020 |  |
| Operating Leases: |  |  |  |  |  |  |  |  |
| Right-of-use assets |  | $ | 3,806 |  |  | $ | 3,359 |  |
| Total right-of-use assets |  |  | 3,806 |  |  |  | 3,359 |  |
| Lease liabilities - ST |  | $ | 581 |  |  | $ | 439 |  |
| Lease liabilities - LT |  |  | 3,329 |  |  |  | 3,000 |  |
| Total operating lease liabilities |  |  | 3,910 |  |  |  | 3,439 |  |
| Weighted-average remaining lease term |  |  | 6.04 |  |  |  | 6.91 |  |
| Weighted-average discount rate |  |  | 6.76 | % |  |  | 7.08 | % |


## us-gaap:AccountsPayableAndAccruedLiabilitiesDisclosureTextBlock

[0001437749-21-001877:notes:18]
11.
 Accounts Payable and Accrued Expenses

[0001437749-21-001877:notes:19]
[same as prior period, unchanged from 0001437749-20-022522:notes:17]

[0001437749-21-001877:notes:20]
|  |  | December 31, 2020 |  |  | March 31, 2020 |  |
| Accounts payable |  | $ | 3,664 |  |  | $ | 10,045 |  |
| Accrued inventories in-transit |  |  | 1,131 |  |  |  | 763 |  |
| Accrued other miscellaneous expenses |  |  | 2,397 |  |  |  | 1,986 |  |
| Advanced deposits |  |  | 1,417 |  |  |  | 666 |  |
| Accrued compensation |  |  | 5,751 |  |  |  | 5,683 |  |
| Income taxes payable |  |  | 635 |  |  |  | 933 |  |
| Accrued product warranty |  |  | 2,020 |  |  |  | 2,015 |  |
| Total |  | $ | 17,015 |  |  | $ | 22,091 |  |

[0001437749-21-001877:notes:21]
[same as prior period, unchanged from 0001437749-20-022522:notes:19]

[0001437749-21-001877:notes:22]
[same as prior period, unchanged from 0001437749-20-022522:notes:20]

[0001437749-21-001877:notes:23]
|  |  | Three Months Ended December 31, |  |  | Nine Months Ended December 31, |  |
|  |  | 2020 |  |  | 2019 |  |  | 2020 |  |  | 2019 |  |
| Balance at beginning of period |  | $ | 2,109 |  |  | $ | 1,641 |  |  | $ | 2,015 |  |  | $ | 1,545 |  |
| Acquired warranty obligations |  |  | 147 |  |  |  | — |  |  |  | 147 |  |  |  | — |  |
| Change in accruals for warranties during the period |  |  | 124 |  |  |  | 93 |  |  |  | 507 |  |  |  | 247 |  |
| Settlements during the period |  |  | (360 | ) |  |  | (28 | ) |  |  | (649 | ) |  |  | (86 | ) |
| Balance at end of period |  | $ | 2,020 |  |  | $ | 1,706 |  |  | $ | 2,020 |  |  | $ | 1,706 |  |


## us-gaap:BusinessAcquisitionProFormaInformationTextBlock

[0001437749-21-001877:notes:24]
|  |  | Three Months Ended December 31, |  |  | Nine Months Ended December 31, |  |
|  |  | 2020 |  |  | 2019 |  |  | 2020 |  |  | 2019 |  |
| Revenues |  | $ | 23,632 |  |  | $ | 22,412 |  |  | $ | 78,298 |  |  | $ | 66,135 |  |
| Operating loss |  |  | (8,769 | ) |  |  | (6,988 | ) |  |  | (15,016 | ) |  |  | (15,469 | ) |
| Net loss |  | $ | (9,169 | ) |  | $ | (7,117 | ) |  | $ | (15,775 | ) |  | $ | (7,879 | ) |
| Net loss per common share |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | (0.36 | ) |  | $ | (0.32 | ) |  | $ | (0.67 | ) |  | $ | (0.36 | ) |
| Diluted |  | $ | (0.36 | ) |  | $ | (0.35 | ) |  | $ | (0.67 | ) |  | $ | (0.57 | ) |
| Shares - basic |  |  | 25,470 |  |  |  | 22,059 |  |  |  | 23,594 |  |  |  | 21,660 |  |
| Shares - diluted |  |  | 25,470 |  |  |  | 22,077 |  |  |  | 23,594 |  |  |  | 21,768 |  |


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001437749-21-001877:notes:25]
2.
 NEPSI Acquisition

[0001437749-21-001877:notes:26]
Acquisition of NEPSI

[0001437749-21-001877:notes:27]
As described in Note 
1,
 Nature of the Business and Operations and Liquidity, on the Acquisition Date, the Company acquired all of the issued and outstanding shares of capital stock of NEPSI and membership interests of Northeast Power Realty, LLC, a New York limited liability company, which holds the real property that serves as NEPSI's headquarters. NEPSI is a U.S.-based global provider of medium-voltage metal-enclosed power capacitor banks and harmonic filter banks for use on electric power systems. Prior to the Acquisition, the Company had purchased 
$0.4
 million of products from NEPSI in fiscal year 
2019
 for which NEPSI was paid and had recorded revenue.

[0001437749-21-001877:notes:28]
Pursuant to the Stock Purchase Agreement, the Company acquired all of the issued and outstanding shares of NEPSI, and membership interest in the realty entity, for which the Company paid 
$26.0
 million in cash and issued 
873,657
 restricted shares of the Company's common stock. Additionally, the Company 
 may 
issue to the selling stockholders up to an additional 
1,000,000
 shares of common stock upon NEPSI's achievement of specified revenue objectives during varying periods of up to 
four
 years following closing of the Acquisition. This contingent consideration is recorded as a derivative liability based on a Monte Carlo simulation to determine fair value at the time of issuance. NEPSI is now a wholly-owned subsidiary of the Company and is operated and reported as a component of its Grid business unit.

[0001437749-21-001877:notes:29]
The Acquisition completed by the Company during the 
nine
 months ended 
 December 31, 2020 
has been accounted for under the purchase method of accounting in accordance with ASC 
805,

[0001437749-21-001877:notes:30]
Business Combinations
. The Company allocated the purchase price to the assets acquired and liabilities assumed at their estimated fair values as of the date of acquisition. The excess of the purchase price paid by the Company over the estimated fair value of net assets acquired has been recorded as goodwill.  As NEPSI was previously a private company, the adoption of Accounting Standards Codification ("ASC 
606"
) was completed as part of the Acquisition.  See Note 
3
 "Revenue Recognition" for further details.  There were 
no
 leases acquired and the Acquisition had 
no
 impact to the Company's reporting under ASC 
842.

[0001437749-21-001877:notes:31]
The total purchase price of approximately 
$42.4
 million includes the fair value of shares of the Company's common stock issued at closing, cash paid, and contingent consideration as follows (in millions):

[0001437749-21-001877:notes:32]
| Cash payment |  | $ | 26.0 |  |
| Issuance of 873,657 shares of Company's common stock |  |  | 12.4 |  |
| Contingent consideration |  |  | 4.0 |  |
| Total consideration |  |  | 42.4 |  |

[0001437749-21-001877:notes:33]
At the Acquisition Date, in addition to the 
$26.0
 million cash, the Company valued the Company's common stock, using 
$14.23
 per share, which was the closing price on the day that the Company acquired NEPSI and 
$4.0
 million of contingent consideration for the earnout liability valued as of the Acquisition Date. Acquisition costs of

[0001437749-21-001877:notes:34]
$0.3

[0001437749-21-001877:notes:35]
million were recorded in selling, general and administrative ("SG&A") costs for the

[0001437749-21-001877:notes:36]
.

[0001437749-21-001877:notes:37]
The fair value of the contingent consideration was determined using a Monte Carlo model and is accounted for as a derivative liability which is revalued at the fair value determined at each subsequent balance sheet date until the contingencies are resolved and the shares to be issued are determined, with the change in fair value recorded in the current period operating loss or (income).  See Note 
13,
 "Warrants and Derivative Liabilities" for further details and a summary of key assumptions used to determine fair value in each period.

[0001437749-21-001877:notes:38]
The following table summarizes the allocation of the purchase price based on the estimated fair values of the assets acquired and liabilities assumed and related deferred income taxes in connection with the Acquisition (in millions):

[0001437749-21-001877:notes:39]
| Net working capital (excluding inventory and deferred revenue) |  | $ | 0.1 |  |
| Inventory |  |  | 4.2 |  |
| Property, plant and equipment |  |  | 2.3 |  |
| Deferred revenue |  |  | (2.7 | ) |
| Deferred tax liability |  |  | (1.7 | ) |
| Net tangible assets/(liabilities) |  |  | 2.2 |  |
| Backlog |  |  | 0.6 |  |
| Trade names and trademarks |  |  | 0.6 |  |
| Customer relationships |  |  | 6.1 |  |
| Net identifiable intangible assets/(liabilities) |  |  | 7.3 |  |
| Goodwill |  |  | 32.9 |  |
| Total purchase consideration |  | $ | 42.4 |  |

[0001437749-21-001877:notes:40]
Inventory includes a 
$1.0
 million adjustment to step up the inventory balance to fair value consistent with the purchase price allocation.  The fair value was determined based on the estimated selling price of the inventory, less the remaining manufacturing and selling cost and a normal profit margin on those manufacturing and selling efforts. The 
$1.0
 million step up adjustment increased cost of revenue in the 
three
 and 
nine
 months periods ended 
 December 31, 2020 
as the inventory was sold.  This increase is 
not
 reflected in the pro forma condensed combined statements of operations because it does 
not
 have a continuing impact beyond the 
first
 year.

[0001437749-21-001877:notes:41]
Backlog of 
$0.6
 million was evaluated using the multi period excess earnings method under the income approach. The contracts with customers do 
not
 provide for any guarantees to source all future requirements from the Company. The amortization method being utilized is economic consumption estimated over a 
two
 year period with the expense being allocated to cost of revenues.

[0001437749-21-001877:notes:42]
Customer relationships of 
$6.1
 million relates to customers currently under contract and was determined based on a multi period excess earnings method under the income approach.   The method of amortization being utilized is the economic consumption over 
7
 years with the expense being allocated to SG&A.

[0001437749-21-001877:notes:43]
Trade names and trademarks of 
$0.6
 million were reviewed, using the assumption that the Company would continue to utilize the NEPSI trade name indefinitely. The relief from royalty method was utilized using an 
8%
 royalty rate on revenues with a 
13%
 discount rate over 
8
 years.

[0001437749-21-001877:notes:44]
Goodwill represents the value associated with the acquired workforce and expected synergies related to the business combination of the 
two
 companies. Goodwill resulting from the Acquisition was assigned to the Company's Grid segment.  Goodwill recognized in the Acquisition is 
not
 deductible for tax purposes. This purchase price allocation is preliminary and has 
not
 been finalized as the analysis on the assets and liabilities acquired, primarily the tax related liability 
 may 
require further adjustments to our purchase accounting that could result in a measurement period adjustment that would impact our reported net assets and goodwill as of 
 October 1, 2020. 
Material changes, if any, to the preliminary allocation summarized above will be reported once the related uncertainties are resolved, but 
no
 later than 
 October 1, 2021. 
The 
$1.7
 million of deferred tax liability is primarily related to inventory step up and intangibles.

[0001437749-21-001877:notes:45]
Unaudited Pro Forma Operating Results

[0001437749-21-001877:notes:46]
The unaudited pro forma condensed consolidated statement of operations for the

[0001437749-21-001877:notes:47]
2019

[0001437749-21-001877:notes:48]
is presented as if the Acquisition had occurred on 
 April 1, 2019.

[0001437749-21-001877:notes:49]
The pro forma amounts include the historical operating results of the Company and NEPSI with appropriate adjustments that give effect to acquisition related costs, income taxes, intangible amortization resulting from the Acquisition and certain conforming accounting policies of the Company.  The 
three
 and 
nine
 month periods ended 
 December 31, 2020 
include

[0001437749-21-001877:notes:50]
$2.7

[0001437749-21-001877:notes:51]
million decrease in operating loss and net loss for the change in fair value on the contingent consideration.  The pro forma amounts are 
not
 necessarily indicative of the operating results that would have occurred if the Acquisition and related transactions had been completed at the beginning of the applicable periods presented. In addition, the pro forma amounts are 
not
 necessarily indicative of operating results in future periods.

[0001437749-21-001877:notes:52]
In the unaudited consolidated results for the 
three
 and 
nine
 months ended 
 December 31, 2020, 
NEPSI's operations are included in the Company's consolidated results from the date of Acquisition of 
 October 1, 2020. 
NEPSI contributed

[0001437749-21-001877:notes:53]
$6.6

[0001437749-21-001877:notes:54]
million of revenue and

[0001437749-21-001877:notes:55]
million in net income for the Company for the 
three
 and 
nine
 month periods ended 
 December 31, 2020.  
Amortization expense of

[0001437749-21-001877:notes:56]
$0.5

[0001437749-21-001877:notes:57]
million is included in the  
three
 and 
nine
 months ended  
 December 31, 2020 
as a result of the NEPSI acquired intangible assets.  In addition,

[0001437749-21-001877:notes:58]
$1.0

[0001437749-21-001877:notes:59]
million for the step-up basis assigned to acquired inventory was charged to cost of revenues in the 
three
 and 
nine
 months ended 
 December 31, 2020.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001437749-21-001877:notes:60]
15.
 Commitments and Contingencies

[0001437749-21-001877:notes:61]
Legal Contingencies

[0001437749-21-001877:notes:62]
From time to time, the Company is involved in legal and administrative proceedings and claims of various types. The Company records a liability in its consolidated financial statements for these matters when a loss is known or considered probable and the amount can be reasonably estimated. The Company reviews these estimates each accounting period as additional information is known and adjusts the loss provision when appropriate. If a matter is both probable to result in a liability and the amounts of loss can be reasonably estimated, the Company estimates and discloses the possible loss or range of loss to the extent necessary to make the consolidated financial statements 
not
 misleading. If the loss is 
not
 probable or cannot be reasonably estimated, a liability is 
not
 recorded in its consolidated financial statements.

[0001437749-21-001877:notes:63]
Other

[0001437749-21-001877:notes:64]
The Company enters into long-term construction contracts with customers that require the Company to obtain performance bonds. The Company is required to deposit an amount equivalent to some or all the face amount of the performance bonds into an escrow account until the termination of the bond. When the performance conditions are met, amounts deposited as collateral for the performance bonds are returned to the Company. In addition, the Company has various contractual arrangements in which minimum quantities of goods or services have been committed to be purchased on an annual basis.

[0001437749-21-001877:notes:65]
As of

[0001437749-21-001877:notes:66]
, and

[0001437749-21-001877:notes:67]
, the Company had $

[0001437749-21-001877:notes:68]
5.6

[0001437749-21-001877:notes:69]
million of restricted cash included in long-term assets and $

[0001437749-21-001877:notes:70]
0.6

[0001437749-21-001877:notes:71]
million of restricted cash included in current assets, respectively. These amounts included in restricted cash primarily represent deposits to secure letters of credit for various supply contracts and long-term projects, including the irrevocable letter of credit in the amount of 
$5.0
 million to secure certain of the Company's obligations under the Subcontract Agreement with ComEd.  These deposits are held in interest bearing accounts.


## us-gaap:ContractWithCustomerAssetAndLiabilityTableTextBlock

[0001437749-21-001877:notes:72]
|  |  | Unbilled Accounts Receivable |  |  | Deferred Program Costs |  |  | Contract Liabilities |  |
| Beginning balance as of March 31, 2020 |  | $ | 5,711 |  |  | $ | 1,631 |  |  | $ | 26,142 |  |
| Increases for costs incurred to fulfill performance obligations |  |  | — |  |  |  | 6,635 |  |  |  | — |  |
| Increase for balances acquired |  |  | 101 |  |  |  | — |  |  |  | 2,700 |  |
| Increase (decrease) due to customer billings |  |  | (8,255 | ) |  |  | — |  |  |  | 42,785 |  |
| Decrease due to cost recognition on completed performance obligations |  |  | — |  |  |  | (6,969 | ) |  |  | — |  |
| Increase (decrease) due to recognition of revenue based on transfer of control of performance obligations |  |  | 6,644 |  |  |  | — |  |  |  | (48,274 | ) |
| Other changes and FX impact |  |  | — |  |  |  | 33 |  |  |  | 1,025 |  |
| Ending balance as of December 31, 2020 |  | $ | 4,201 |  |  | $ | 1,330 |  |  | $ | 24,378 |  |

[0001437749-21-001877:notes:73]
|  |  | Unbilled Accounts Receivable |  |  | Deferred Program Costs |  |  | Contract Liabilities |  |
| Beginning balance as of March 31, 2019 |  | $ | 2,213 |  |  | $ | 318 |  |  | $ | 15,519 |  |
| Increases for costs incurred to fulfill performance obligations |  |  | — |  |  |  | 3,001 |  |  |  | — |  |
| Increase (decrease) due to customer billings |  |  | (7,417 | ) |  |  | — |  |  |  | 36,461 |  |
| Decrease due to cost recognition on completed performance obligations |  |  | — |  |  |  | (2,221 | ) |  |  | — |  |
| Increase (decrease) due to recognition of revenue based on transfer of control of performance obligations |  |  | 9,820 |  |  |  | — |  |  |  | (28,768 | ) |
| Other changes and FX impact |  |  | (3 | ) |  |  | (1 | ) |  |  | (69 | ) |
| Ending balance as of December 31, 2019 |  | $ | 4,613 |  |  | $ | 1,097 |  |  | $ | 23,143 |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001437749-21-001877:notes:74]
13.
 Warrants and Derivative Liabilities

[0001437749-21-001877:notes:75]
Contingent Consideration

[0001437749-21-001877:notes:76]
The Company evaluated the Acquisition earnout payment set forth in the Stock Purchase Agreement (see Note 
2,
 "NEPSI Acquisition" for further details), which 
 may 
require settlement in the Company's common stock, and determined the contingent consideration qualified for liability classification and derivative treatment under ASC 
815,

[0001437749-21-001877:notes:77]
Derivatives and Hedging
. As a result, for each period, the fair value of the contingent consideration will be remeasured and the resulting gain or loss will be recognized in operating expenses until the share amount is fixed.

[0001437749-21-001877:notes:78]
Following is a summary of the key assumptions used in a Monte Carlo simulation to calculate the fair value of the contingent consideration related to the Acquisition:

[0001437749-21-001877:notes:79]
|  |  | December 31, |  |  | October 1, |  |
| Fiscal Year 2020 |  | 2020 |  |  | 2020 |  |
| Revenue risk premium |  |  | 6.90 | % |  |  | 7.10 | % |
| Revenue volatility |  |  | 30 | % |  |  | 30 | % |
| Stock Price |  | $ | 23.42 |  |  | $ | 14.23 |  |
| Payment delay (days) |  |  | 80 |  |  |  | — |  |
| Fair value |  | $6.7 million |  |  | $4.0 million |  |

[0001437749-21-001877:notes:80]
The Company recorded a net loss of $

[0001437749-21-001877:notes:81]
2.7

[0001437749-21-001877:notes:82]
million resulting from the increase in the fair value of the contingent consideration in both the

[0001437749-21-001877:notes:83]
Warrants

[0001437749-21-001877:notes:84]
The Company accounted for its warrants as liabilities due to certain adjustment provisions within the instruments, which required that they be recorded at fair value. The warrants were subject to revaluation at each balance sheet date and any change in fair value was recorded as a change in fair value of warrants until the earlier of its expiration or its exercise at which time the warrant liability was reclassified to equity. The Company calculated the fair value of the warrants utilizing an integrated lattice model. See Note 
7,
 "Fair Value Measurements", for further discussion.  As of

[0001437749-21-001877:notes:85]
[same as prior period, unchanged from 0001437749-20-022522:notes:38]

[0001437749-21-001877:notes:86]
[same as prior period, unchanged from 0001437749-20-022522:notes:39]

[0001437749-21-001877:notes:87]
[same as prior period, unchanged from 0001437749-20-022522:notes:40]

[0001437749-21-001877:notes:88]
nine

[0001437749-21-001877:notes:89]
[same as prior period, unchanged from 0001437749-20-022522:notes:44]

[0001437749-21-001877:notes:90]
On 
 November 13, 2014, 
the Company completed an offering of 
909,090
 units of the Company's common stock with Hudson Bay Capital. Each unit consisted of 
one
 share of the Company's common stock and 
0.9
 of a warrant to purchase 
one
 share of common stock, or a warrant to purchase in the aggregate 
818,181
 shares.  The Hudson Warrants were exercisable at any time, at an exercise price equal to 
$7.81
 per share, subject to certain price-based and other anti-dilution adjustments including those noted above.  On 
 November 13, 2019, 
Hudson partially exercised the Hudson Warrants for 
786,000
 restricted shares of Company common stock at 
$7.81
 per share
.  
The remaining 
32,181
 warrants expired on 
 November 13, 2019. 
The Company recorded net gains of 
$0.5
 million and 
$4.6
 million to change in fair value of warrants, resulting from the decrease in the fair value of the Hudson Warrants during the 
three
 and

[0001437749-21-001877:notes:91]
, respectively.


## us-gaap:DisaggregationOfRevenueTableTextBlock

[0001437749-21-001877:notes:92]
|  |  | Three Months Ended December 31, 2020 |  |  | Nine Months Ended December 31, 2020 |  |
| Product Line: |  | Grid |  |  | Wind |  |  | Grid |  |  | Wind |  |
| Equipment and systems |  | $ | 15,930 |  |  | $ | 6,153 |  |  | $ | 47,729 |  |  | $ | 12,828 |  |
| Services and technology development |  |  | 1,156 |  |  |  | 393 |  |  |  | 3,420 |  |  |  | 1,984 |  |
| Total |  | $ | 17,086 |  |  | $ | 6,546 |  |  | $ | 51,149 |  |  | $ | 14,812 |  |
| Region: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas |  | $ | 13,394 |  |  | $ | 14 |  |  | $ | 39,626 |  |  | $ | 56 |  |
| Asia Pacific |  |  | 351 |  |  |  | 6,461 |  |  |  | 6,736 |  |  |  | 14,463 |  |
| EMEA |  |  | 3,341 |  |  |  | 71 |  |  |  | 4,787 |  |  |  | 293 |  |
| Total |  | $ | 17,086 |  |  | $ | 6,546 |  |  | $ | 51,149 |  |  | $ | 14,812 |  |

[0001437749-21-001877:notes:93]
|  |  | Three Months Ended December 31, 2019 |  |  | Nine Months Ended December 31, 2019 |  |
| Product Line: |  | Grid |  |  | Wind |  |  | Grid |  |  | Wind |  |
| Equipment and systems |  | $ | 14,040 |  |  | $ | 2,160 |  |  | $ | 32,438 |  |  | $ | 7,742 |  |
| Services and technology development |  |  | 1,192 |  |  |  | 523 |  |  |  | 4,139 |  |  |  | 1,379 |  |
| Total |  | $ | 15,232 |  |  | $ | 2,683 |  |  | $ | 36,577 |  |  | $ | 9,120 |  |
| Region: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas |  | $ | 10,164 |  |  | $ | 2 |  |  | $ | 28,663 |  |  | $ | 49 |  |
| Asia Pacific |  |  | 330 |  |  |  | 2,647 |  |  |  | 2,550 |  |  |  | 8,968 |  |
| EMEA |  |  | 4,738 |  |  |  | 34 |  |  |  | 5,364 |  |  |  | 104 |  |
| Total |  | $ | 15,232 |  |  | $ | 2,683 |  |  | $ | 36,577 |  |  | $ | 9,120 |  |


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001437749-21-001877:notes:94]
4.
 Stock-Based Compensation

[0001437749-21-001877:notes:95]
[same as prior period, unchanged from 0001437749-20-022522:notes:50]

[0001437749-21-001877:notes:96]
[same as prior period, unchanged from 0001437749-20-022522:notes:53]

[0001437749-21-001877:notes:97]
|  |  | Three Months Ended December 31, |  |  | Nine Months Ended December 31, |  |
|  |  | 2020 |  |  | 2019 |  |  | 2020 |  |  | 2019 |  |
| Cost of revenues |  | $ | (23 | ) |  | $ | 21 |  |  | $ | 35 |  |  | $ | 45 |  |
| Research and development |  |  | 179 |  |  |  | 117 |  |  |  | 470 |  |  |  | 219 |  |
| Selling, general and administrative |  |  | 683 |  |  |  | 452 |  |  |  | 2,092 |  |  |  | 971 |  |
| Total |  | $ | 839 |  |  | $ | 590 |  |  | $ | 2,597 |  |  | $ | 1,236 |  |

[0001437749-21-001877:notes:98]
[same as prior period, unchanged from 0001437749-20-022522:notes:55]

[0001437749-21-001877:notes:99]
[same as prior period, unchanged from 0001437749-20-022522:notes:56]

[0001437749-21-001877:notes:100]
[same as prior period, unchanged from 0001437749-20-022522:notes:57]

[0001437749-21-001877:notes:101]
697,167

[0001437749-21-001877:notes:102]
[same as prior period, unchanged from 0001437749-20-022522:notes:59]

[0001437749-21-001877:notes:103]
and issued 
13,174
 shares of immediately vested common stock and 
366,000
 shares of restricted stock awards during the

[0001437749-21-001877:notes:104]
[same as prior period, unchanged from 0001437749-20-022522:notes:62]

[0001437749-21-001877:notes:105]
[same as prior period, unchanged from 0001437749-20-022522:notes:63]

[0001437749-21-001877:notes:106]
[same as prior period, unchanged from 0001437749-20-022522:notes:64]

[0001437749-21-001877:notes:107]
[same as prior period, unchanged from 0001437749-20-022522:notes:65]

[0001437749-21-001877:notes:108]
[same as prior period, unchanged from 0001437749-20-022522:notes:66]

[0001437749-21-001877:notes:109]
0.4

[0001437749-21-001877:notes:110]
[same as prior period, unchanged from 0001437749-20-022522:notes:68]

[0001437749-21-001877:notes:111]
5.2

[0001437749-21-001877:notes:112]
[same as prior period, unchanged from 0001437749-20-022522:notes:70]

[0001437749-21-001877:notes:113]
1.9

[0001437749-21-001877:notes:114]
[same as prior period, unchanged from 0001437749-20-022522:notes:72]

[0001437749-21-001877:notes:115]
The Company did 
not
 grant any stock options during the

[0001437749-21-001877:notes:116]
[same as prior period, unchanged from 0001437749-20-022522:notes:76]

[0001437749-21-001877:notes:117]
[same as prior period, unchanged from 0001437749-20-022522:notes:77]

[0001437749-21-001877:notes:118]
[same as prior period, unchanged from 0001437749-20-022522:notes:78]

[0001437749-21-001877:notes:119]
[same as prior period, unchanged from 0001437749-20-022522:notes:79]

[0001437749-21-001877:notes:120]
[same as prior period, unchanged from 0001437749-20-022522:notes:80]

[0001437749-21-001877:notes:121]
|  |  | Three Months Ended December 31, |  |  | Nine Months Ended December 31, |  |
|  |  | 2020 |  |  | 2019 |  |  | 2020 |  |  | 2019 |  |
| Expected volatility |  |  | N/A |  |  |  | N/A |  |  |  | N/A |  |  |  | 66.5 | % |
| Risk-free interest rate |  |  | N/A |  |  |  | N/A |  |  |  | N/A |  |  |  | 1.8 | % |
| Expected life (years) |  |  | N/A |  |  |  | N/A |  |  |  | N/A |  |  |  | 5.91 |  |
| Dividend yield |  |  | N/A |  |  |  | N/A |  |  |  | N/A |  |  | None |  |


## us-gaap:EarningsPerShareTextBlock

[0001437749-21-001877:notes:122]
5.
 Computation of Net Loss per Common Share

[0001437749-21-001877:notes:123]
Basic net loss per share (“EPS”) is computed by dividing net loss by the weighted-average number of common shares outstanding for the period. Where applicable, diluted EPS is computed by dividing the net loss by the weighted-average number of common shares and dilutive common equivalent shares outstanding during the period, calculated using the treasury stock method. Common equivalent shares include the effect of restricted stock, exercise of stock options and warrants and contingently issuable shares. Stock options and warrants that are out-of-the-money with exercise prices greater than the average market price of the underlying common shares and shares of performance based restricted stock where the contingency was 
not
 met are excluded from the computation of diluted EPS as the effect of their inclusion would be anti-dilutive.  For the

[0001437749-21-001877:notes:124]
[same as prior period, unchanged from 0001437749-20-022522:notes:84]

[0001437749-21-001877:notes:125]
1.1

[0001437749-21-001877:notes:126]
million shares were 
not
 included in the calculation of diluted EPS.  Of these,

[0001437749-21-001877:notes:127]
1.0

[0001437749-21-001877:notes:128]
million relate to shares tied to the derivative liability for which the contingency has 
not
 yet been met, and

[0001437749-21-001877:notes:129]
million relate to outstanding stock options as they were considered anti-dilutive
.
 For the

[0001437749-21-001877:notes:130]
million shares related to outstanding stock options were 
not
 included in the calculation of diluted EPS as they were considered anti-dilutive.

[0001437749-21-001877:notes:131]
[same as prior period, unchanged from 0001437749-20-022522:notes:88]

[0001437749-21-001877:notes:132]
[same as prior period, unchanged from 0001437749-20-022522:notes:89]

[0001437749-21-001877:notes:133]
|  |  | Three Months Ended December 31, |  |  | Nine Months Ended December 31, |  |
|  |  | 2020 |  |  | 2019 |  |  | 2020 |  |  | 2019 |  |
| Numerator: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net loss |  | $ | (7,933 | ) |  | $ | (6,845 | ) |  | $ | (15,062 | ) |  | $ | (11,209 | ) |
| Less: decrease in fair value of warrants, net of income tax |  |  | — |  |  |  | (556 | ) |  |  | — |  |  |  | (4,648 | ) |
| Plus: change in fair value due to exercise of warrants |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 83 |  |
| Net loss - diluted |  | $ | (7,933 | ) |  | $ | (7,401 | ) |  | $ | (15,062 | ) |  | $ | (15,774 | ) |
| Denominator: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Weighted-average shares of common stock outstanding |  |  | 26,532 |  |  |  | 22,110 |  |  |  | 24,143 |  |  |  | 21,729 |  |
| Weighted-average shares subject to repurchase |  |  | (1,062 | ) |  |  | (925 | ) |  |  | (1,132 | ) |  |  | (943 | ) |
| Shares used in per-share calculation ― basic |  |  | 25,470 |  |  |  | 21,185 |  |  |  | 23,011 |  |  |  | 20,786 |  |
| Common stock warrants |  |  | — |  |  |  | 18 |  |  |  | — |  |  |  | 108 |  |
| Shares used in per-share calculation ― diluted |  |  | 25,470 |  |  |  | 21,203 |  |  |  | 23,011 |  |  |  | 20,894 |  |
| Net loss per share ― basic |  | $ | (0.31 | ) |  | $ | (0.32 | ) |  | $ | (0.65 | ) |  | $ | (0.54 | ) |
| Net loss per share ― diluted |  | $ | (0.31 | ) |  | $ | (0.35 | ) |  | $ | (0.65 | ) |  | $ | (0.75 | ) |

[0001437749-21-001877:notes:134]
[same as prior period, unchanged from 0001437749-20-022522:notes:91]

[0001437749-21-001877:notes:135]
, the diluted net loss per common share amounts under the treasury stock method were calculated based on the dilutive effect of the total number of shares of common stock related to the warrants issued to Hudson Bay Capital (the “Hudson Warrants”) for 
818,181
 shares with an exercise price of 
$7.81.
  For the

[0001437749-21-001877:notes:136]
month periods ended

[0001437749-21-001877:notes:137]
, the average stock price was 
$8.19
 and 
$9.29
 respectively through 
 November 13, 2019 
when the Hudson Warrant was partially exercised for 
786,000
 shares, providing 
37,962
 and 
130,345
 dilutive shares respectively. The increase of 
$0.6
 million and the decrease of 
$4.6
 million in the fair value of the warrant liability, respectively, is included in the net loss available to common shareholders for the diluted net loss per common share amount when the impact is dilutive.


## us-gaap:FairValueDisclosuresTextBlock

[0001437749-21-001877:notes:138]
7.
 Fair Value Measurements

[0001437749-21-001877:notes:139]
[same as prior period, unchanged from 0001437749-20-022522:notes:94]

[0001437749-21-001877:notes:140]
[same as prior period, unchanged from 0001437749-20-022522:notes:95]

[0001437749-21-001877:notes:141]
[same as prior period, unchanged from 0001437749-20-022522:notes:96]

[0001437749-21-001877:notes:142]
[same as prior period, unchanged from 0001437749-20-022522:notes:97]

[0001437749-21-001877:notes:143]
[same as prior period, unchanged from 0001437749-20-022522:notes:98]

[0001437749-21-001877:notes:144]
[same as prior period, unchanged from 0001437749-20-022522:notes:99]

[0001437749-21-001877:notes:145]
[same as prior period, unchanged from 0001437749-20-022522:notes:100]

[0001437749-21-001877:notes:146]
[same as prior period, unchanged from 0001437749-20-022522:notes:101]

[0001437749-21-001877:notes:147]
Marketable securities consist of certificates of deposit that are measured using such inputs as quoted prices and are classified within Level 
1
 of the valuation hierarchy. The Company determines the appropriate classification of its marketable securities at the time of purchase and re-evaluates such classification as of each balance sheet date.  All marketable securities are considered available for sale and are carried at fair value.   Changes in fair value are recorded to other income (expense), net.  The Company recognized 
no
 change in the 
three
 months ended

[0001437749-21-001877:notes:148]
and 
$0.2
 million in unrealized losses on marketable securities, which is recorded in other income (expense), net, for the

[0001437749-21-001877:notes:149]
[same as prior period, unchanged from 0001437749-20-022522:notes:103]

[0001437749-21-001877:notes:150]
and less than a 
$0.1
 million gain which was recognized during the

[0001437749-21-001877:notes:151]
upon the sale of 
one
 of the certificates of deposit.  The Company did

[0001437749-21-001877:notes:152]
not

[0001437749-21-001877:notes:153]
[same as prior period, unchanged from 0001437749-20-022522:notes:106]

[0001437749-21-001877:notes:154]
[same as prior period, unchanged from 0001437749-20-022522:notes:107]

[0001437749-21-001877:notes:155]
Contingent consideration relates to the earnout payment set forth in the Stock Purchase Agreement that provides that the selling stockholders 
 may 
receive up to an additional 
1,000,000
 shares of common stock of the Company upon the achievement of certain specified revenue objectives over varying periods of up to 
four
 years following the Acquisition Date. See Note 
13,
 "Warrants and Derivative Liabilities" and Note 
2,
 “NEPSI Acquisition” for further discussion. The Company relied on a Monte Carlo method to determine the fair value of the contingent consideration on the Acquisition Date and will continue to revalue the fair value of the contingent consideration using the same method at each subsequent balance sheet date until the contingencies are resolved and the shares to be issued are determined, with the change in fair value recorded in the current period operating loss.

[0001437749-21-001877:notes:156]
[same as prior period, unchanged from 0001437749-20-022522:notes:109]

[0001437749-21-001877:notes:157]
, the Company has 
no
 remaining outstanding warrants.

[0001437749-21-001877:notes:158]
The Company historically relied on various assumptions in a lattice model to determine the fair value of warrants. The Company had valued the warrants within Level 
3
 of the valuation hierarchy. See Note 
13,
 “Warrants and Derivative Liabilities,” for a discussion of the warrants and the valuation assumptions used.

[0001437749-21-001877:notes:159]
[same as prior period, unchanged from 0001437749-20-022522:notes:112]

[0001437749-21-001877:notes:160]
|  |  | Total Carrying Value |  |  | Quoted Prices in Active Markets (Level 1) |  |  | Significant Other Observable Inputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |
| December 31, 2020: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash equivalents |  | $ | 56,101 |  |  | $ | 56,101 |  |  | $ | — |  |  | $ | — |  |
| Marketable securities |  | $ | 10,239 |  |  | $ | 10,239 |  |  | $ | — |  |  | $ | — |  |
| Derivative liabilities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Contingent consideration |  | $ | 6,730 |  |  | $ | — |  |  | $ | — |  |  | $ | 6,730 |  |

[0001437749-21-001877:notes:161]
[same as prior period, unchanged from 0001437749-20-022522:notes:114]

[0001437749-21-001877:notes:162]
The table below reflects the activity for the Company's derivative liability measured at fair value on a recurring basis (in thousands):

[0001437749-21-001877:notes:163]
|  |  | Acquisition Contingent Consideration |  |
| April 1, 2020 |  | $ | - |  |
| Issuance of contingent consideration |  |  | 3,990 |  |
| Mark to market adjustment |  |  | 2,740 |  |
| Balance at December 31, 2020 |  | $ | 6,730 |  |


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001437749-21-001877:notes:164]
6.
 Goodwill and Other Intangibles

[0001437749-21-001877:notes:165]
Goodwill

[0001437749-21-001877:notes:166]
The guidance under ASC 
805
-
30
 provides for the recognition of goodwill on the Acquisition Date measured as the excess of the aggregate consideration transferred over the net of the Acquisition Date amounts of net assets acquired and liabilities assumed. The Company's goodwill balance relates to the Acquisition of NEPSI in the current year and ITC in fiscal 
2017
 and is reported in the Grid business segment.  The fair market value of the contingent consideration included in the total consideration transferred was determined using the Monte Carlo model, and all other consideration transferred was calculated using its observable fair market value. The tangible net assets acquired fair market value was based on observable market fair value. The acquired intangible asset fair value was determined using discounted cash flows under an excess in earnings model or relief in royalty method where appropriate.

[0001437749-21-001877:notes:167]
Goodwill represents the difference between the purchase price and the fair value of the identifiable tangible and intangible net assets when accounted for using the purchase method of accounting. Goodwill is 
not
 amortized but reviewed for impairment. Goodwill is reviewed annually and whenever events or changes in circumstances indicate that the carrying value of the goodwill might 
not
 be recoverable.

[0001437749-21-001877:notes:168]
The following table provides a roll forward of the changes in our Grid business segment goodwill balance:

[0001437749-21-001877:notes:169]
|  |  | Goodwill |  |
| March 31, 2020 |  | $ | 1,719 |  |
| NEPSI Acquisition |  |  | 32,940 |  |
| Less impairment loss |  |  | - |  |
| December 31, 2020 |  | $ | 34,659 |  |

[0001437749-21-001877:notes:170]
The Company did 
not
 identify any triggering events in the

[0001437749-21-001877:notes:171]
, that would require interim impairment testing of goodwill.

[0001437749-21-001877:notes:172]
Other Intangibles

[0001437749-21-001877:notes:173]
Intangible assets at

[0001437749-21-001877:notes:174]
|  |  | December 31, 2020 |  |  | March 31, 2020 |  |  |  |  |  |
|  |  | Gross Amount |  |  | Accumulated Amortization |  |  | Net Book Value |  |  | Gross Amount |  |  | Accumulated Amortization |  |  | Net Book Value |  |  | Estimated Useful Life |  |
| Backlog |  | $ | 600 |  |  | $ | (285 | ) |  | $ | 315 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  |  | 2 |  |
| Trade name |  |  | 600 |  |  |  | — |  |  |  | 600 |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | Indefinite |  |
| Customer relationships |  |  | 6,100 |  |  |  | (239 | ) |  |  | 5,861 |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 7 |  |
| Core technology and know-how |  |  | 5,970 |  |  |  | (2,782 | ) |  |  | 3,188 |  |  |  | 5,970 |  |  |  | (2,420 | ) |  |  | 3,550 |  |  |  | 5-10 |  |
| Intangible assets |  | $ | 13,270 |  |  | $ | (3,306 | ) |  | $ | 9,964 |  |  | $ | 5,970 |  |  | $ | (2,420 | ) |  | $ | 3,550 |  |  |  |  |  |

[0001437749-21-001877:notes:175]
The Company recorded intangible amortization expense related to customer relationship and core technology and know-how of 
$0.4
 million and 
$0.6
 million in the

[0001437749-21-001877:notes:176]
, respectively, and 
$0.1
 and 
$0.3
 million for the

[0001437749-21-001877:notes:177]
, respectively.  Additionally, in each of the

[0001437749-21-001877:notes:178]
the Company recorded

[0001437749-21-001877:notes:179]
million related to intangible amortization related to backlog that is reported in cost of revenues.

[0001437749-21-001877:notes:180]
Expected future amortization expense related to intangible assets is as follows (in thousands):

[0001437749-21-001877:notes:181]
| Years ended March 31, |  | Total |  |
| 2021 |  |  | 826 |  |
| 2022 |  |  | 2,115 |  |
| 2023 |  |  | 1,808 |  |
| 2024 |  |  | 1,393 |  |
| 2025 |  |  | 1,077 |  |
| Thereafter |  |  | 2,145 |  |
| Total |  | $ | 9,364 |  |

[0001437749-21-001877:notes:182]
The Company's intangible assets relate entirely to the Grid business segment operations in the United States.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001437749-21-001877:notes:183]
12.
 Income Taxes

[0001437749-21-001877:notes:184]
The Company recorded an income tax benefit of $

[0001437749-21-001877:notes:185]
1.5

[0001437749-21-001877:notes:186]
[same as prior period, unchanged from 0001437749-20-022522:notes:120]

[0001437749-21-001877:notes:187]
1.2

[0001437749-21-001877:notes:188]
[same as prior period, unchanged from 0001437749-20-022522:notes:122]

[0001437749-21-001877:notes:189]
, respectively. 
The Company recorded income tax expense of 
$0.1
 million in the 
three
 months ended

[0001437749-21-001877:notes:190]
, and less than

[0001437749-21-001877:notes:191]
million in the 
nine
 months ended

[0001437749-21-001877:notes:192]
As a result of a difference in book and tax basis related to the intangible assets acquired in the Acquisition (see Note 
2,
 "NEPSI Acquisition"), the Company recorded a deferred tax liability of 
$1.7
 million. As a result, the Company was able to benefit from additional deferred tax assets and therefore released a corresponding valuation allowance of

[0001437749-21-001877:notes:193]
$1.7

[0001437749-21-001877:notes:194]
million during the

[0001437749-21-001877:notes:195]
.  The purchase price allocation is preliminary and has 
not
 been finalized as the analysis on the assets and liabilities acquired, primarily the tax related liability, 
 may 
require further adjustments to the Company's purchase accounting that could result in measurement period adjustments that would impact the Company's reported net assets and goodwill as of 
 October 1, 2020. 
Material changes, if any, to the preliminary allocation summarized in Note 
2,
 "NEPSI Acquisition" will be reported once the related uncertainties are resolved, but 
no
 later than 
 October 1, 2021.  
Goodwill recognized in the Acquisition is 
not
 deductible for tax purposes.

[0001437749-21-001877:notes:196]
Accounting for income taxes requires a 
two
-step approach to recognizing and measuring uncertain tax positions.  The 
first
 step is to evaluate the tax position for recognition by determining if, based on the technical merits, it is more likely than 
not
 the position will be sustained upon audit, including resolution of related appeals or litigation processes, if any.  The 
second
 step is to measure the tax benefit as the largest amount that is more than 
50%
 likely to be realized upon ultimate settlement.  The Company re-evaluates these uncertain tax positions on a quarterly basis.  The evaluation is based on factors including, but 
not
 limited to, changes in facts or circumstances, changes in tax law, effectively settled issues under audit and new audit activity.  Any changes in these factors could result in the recognition of a tax benefit or an additional charge to the tax provision.  The Company did 
not
 identify any uncertain tax positions in the

[0001437749-21-001877:notes:197]
[same as prior period, unchanged from 0001437749-20-022522:notes:126]


## us-gaap:InventoryDisclosureTextBlock

[0001437749-21-001877:notes:198]
9.
 Inventory

[0001437749-21-001877:notes:199]
[same as prior period, unchanged from 0001437749-20-022522:notes:128]

[0001437749-21-001877:notes:200]
|  |  | December 31, 2020 |  |  | March 31, 2020 |  |
| Raw materials |  | $ | 7,651 |  |  | $ | 10,739 |  |
| Work-in-process |  |  | 3,497 |  |  |  | 1,345 |  |
| Finished goods |  |  | 1,698 |  |  |  | 5,260 |  |
| Deferred program costs |  |  | 1,330 |  |  |  | 1,631 |  |
| Net inventory |  | $ | 14,176 |  |  | $ | 18,975 |  |

[0001437749-21-001877:notes:201]
[same as prior period, unchanged from 0001437749-20-022522:notes:130]

[0001437749-21-001877:notes:202]
million and 
$0.3
 million for the 
three
 months ended

[0001437749-21-001877:notes:203]
[same as prior period, unchanged from 0001437749-20-022522:notes:132]

[0001437749-21-001877:notes:204]
1.6

[0001437749-21-001877:notes:205]
million and 
$0.5
 million for the

[0001437749-21-001877:notes:206]
[same as prior period, unchanged from 0001437749-20-022522:notes:135]

[0001437749-21-001877:notes:207]
[same as prior period, unchanged from 0001437749-20-022522:notes:136]

[0001437749-21-001877:notes:208]
[same as prior period, unchanged from 0001437749-20-022522:notes:137]


## us-gaap:LeaseCostTableTextBlock

[0001437749-21-001877:notes:209]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | December 31, 2020 |  |  | December 31, 2020 |  |
| Operating Leases: |  |  |  |  |  |  |  |  |
| Operating lease costs - fixed |  | $ | 226 |  |  | $ | 618 |  |
| Operating lease costs - variable |  |  | 31 |  |  |  | 87 |  |
| Short-term lease costs |  |  | 338 |  |  |  | 989 |  |
| Total lease costs |  |  | 595 |  |  |  | 1,694 |  |

[0001437749-21-001877:notes:210]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | December 31, 2019 |  |  | December 31, 2019 |  |
| Operating Leases: |  |  |  |  |  |  |  |  |
| Operating lease costs - fixed |  | $ | 179 |  |  | $ | 535 |  |
| Operating lease costs - variable |  |  | 27 |  |  |  | 73 |  |
| Short-term lease costs |  |  | 164 |  |  |  | 378 |  |
| Total lease costs |  |  | 370 |  |  |  | 986 |  |


## us-gaap:LesseeOperatingLeaseLiabilityMaturityTableTextBlock

[0001437749-21-001877:notes:211]
|  |  | Operating Leases |  |
| Year ended March 31, |  |  |  |  |
| 2021 |  | $ | 216 |  |
| 2022 |  |  | 814 |  |
| 2023 |  |  | 787 |  |
| 2024 |  |  | 733 |  |
| 2025 |  |  | 659 |  |
| Thereafter |  |  | 1,597 |  |
| Total minimum lease payments |  |  | 4,806 |  |
| Less: interest |  |  | 896 |  |
| Present value of lease liabilities |  |  | 3,910 |  |


## us-gaap:LesseeOperatingLeasesTextBlock

[0001437749-21-001877:notes:212]
14.
 Leases

[0001437749-21-001877:notes:213]
[same as prior period, unchanged from 0001437749-20-022522:notes:142]

[0001437749-21-001877:notes:214]
[same as prior period, unchanged from 0001437749-20-022522:notes:143]

[0001437749-21-001877:notes:215]
[same as prior period, unchanged from 0001437749-20-022522:notes:144]

[0001437749-21-001877:notes:216]
[same as prior period, unchanged from 0001437749-20-022522:notes:145]

[0001437749-21-001877:notes:217]
[same as prior period, unchanged from 0001437749-20-022522:notes:146]

[0001437749-21-001877:notes:218]
[same as prior period, unchanged from 0001437749-20-022522:notes:147]

[0001437749-21-001877:notes:219]
[same as prior period, unchanged from 0001437749-20-022522:notes:148]

[0001437749-21-001877:notes:220]
[same as prior period, unchanged from 0001437749-20-022522:notes:149]

[0001437749-21-001877:notes:221]
[same as prior period, unchanged from 0001437749-20-022522:notes:150]


## us-gaap:NewAccountingPronouncementsAndChangesInAccountingPrinciplesTextBlock

[0001437749-21-001877:notes:222]
17.
 Recent Accounting Pronouncements

[0001437749-21-001877:notes:223]
In 
 June 2016, 
the FASB issued ASU 
2016
-
13,

[0001437749-21-001877:notes:224]
Financial Instruments-Credit Losses (Topic 
326
): Measurement of Credit Losses on Financial Instruments
. The amendments in ASU 
2016
-
13
 will provide more decision-useful information about the expected credit losses on financial instruments and other commitments to extend credit held by a reporting entity at each reporting date. The ASU is effective for annual reporting periods beginning after 
 December 15, 2019, 
including interim periods within that year.  Following the release of ASU 
2019
-
10
 in 
 November 2019, 
the new effective date, as long as the Company remains a smaller reporting company, would be annual reporting periods beginning after 
 December 15, 2022.  
The Company is currently evaluating the impact, if any, that the adoption of ASU 
2016
-
13

[0001437749-21-001877:notes:225]
may 
have on its consolidated financial statements.

[0001437749-21-001877:notes:226]
In 
 August 2018, 
the FASB issued ASU 
2018
-
13,

[0001437749-21-001877:notes:227]
Fair Value Measurement (Topic 
820
): Changes to the Disclosure Requirements for Fair Value Measurement
. The amendments in ASU 
2018
-
13
 provide for increased effectiveness of the disclosures made around fair value measurements while including consideration for costs and benefits. The ASU is effective for annual reporting periods beginning after 
 December 15, 2019, 
including interim periods within those periods. As of 
 April 1, 2020, 
the Company has adopted ASU 
2018
-
13
 and noted 
no
 material impact on its consolidated financial statements.

[0001437749-21-001877:notes:228]
In 
 December 2019, 
the FASB issued ASU 
2019
-
12,

[0001437749-21-001877:notes:229]
Income Taxes (Topic 
740
): Simplifying the Accounting for Income Taxes
. The amendments in ASU 
2019
-
12
 provide for simplified accounting to several income tax situations and removal of certain accounting exceptions. The ASU is effective for annual reporting periods beginning after 
 December 15, 2020, 
including interim periods within those periods. The Company does 
not
 expect the impact of the adoption of ASU 
2019
-
12
 to be material to its consolidated financial statements.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0001437749-21-001877:notes:230]
[same as prior period, unchanged from 0001437749-20-022522:notes:159]

[0001437749-21-001877:notes:231]
[same as prior period, unchanged from 0001437749-20-022522:notes:160]

[0001437749-21-001877:notes:232]
[same as prior period, unchanged from 0001437749-20-022522:notes:161]

[0001437749-21-001877:notes:233]
[same as prior period, unchanged from 0001437749-20-022522:notes:162]

[0001437749-21-001877:notes:234]
1987.
 The Company is a leading system provider of megawatt-scale power resiliency solutions that Orchestrate the Rhythm and Harmony of Power on the Grid
™
 and that protect and expand the capability of the Navy's fleet. The Company's system level products leverage its proprietary “smart materials” and “smart software and controls” to provide enhanced resiliency and improved performance of megawatt-scale power flow.

[0001437749-21-001877:notes:235]
[same as prior period, unchanged from 0001437749-20-022522:notes:164]

[0001437749-21-001877:notes:236]
[same as prior period, unchanged from 0001437749-20-022522:notes:165]

[0001437749-21-001877:notes:237]
[same as prior period, unchanged from 0001437749-20-022522:notes:166]

[0001437749-21-001877:notes:238]
[same as prior period, unchanged from 0001437749-20-022522:notes:167]

[0001437749-21-001877:notes:239]
[same as prior period, unchanged from 0001437749-20-022522:notes:168]

[0001437749-21-001877:notes:240]
[same as prior period, unchanged from 0001437749-20-022522:notes:169]

[0001437749-21-001877:notes:241]
[same as prior period, unchanged from 0001437749-20-022522:notes:170]

[0001437749-21-001877:notes:242]
[same as prior period, unchanged from 0001437749-20-022522:notes:171]

[0001437749-21-001877:notes:243]
993.7

[0001437749-21-001877:notes:244]
[same as prior period, unchanged from 0001437749-20-022522:notes:173]

[0001437749-21-001877:notes:245]
[same as prior period, unchanged from 0001437749-20-022522:notes:174]

[0001437749-21-001877:notes:246]
78.1

[0001437749-21-001877:notes:247]
million. Marketable securities include certificate of deposits with maturities between 
three
 and 
nine
 months.  Cash used in operations for the

[0001437749-21-001877:notes:248]
[same as prior period, unchanged from 0001437749-20-022522:notes:177]

[0001437749-21-001877:notes:249]
4.9

[0001437749-21-001877:notes:250]
[same as prior period, unchanged from 0001437749-20-022522:notes:179]

[0001437749-21-001877:notes:251]
[same as prior period, unchanged from 0001437749-20-022522:notes:180]

[0001437749-21-001877:notes:252]
On 
 October 1, 2020 (
the "Acquisition Date"), the Company entered into a Stock Purchase Agreement (the “Stock Purchase Agreement”) with the selling stockholders named therein.  Pursuant to the terms of the Stock Purchase Agreement and concurrently with entering into such agreement, the Company acquired all of the issued and outstanding (i) shares of capital stock of Northeast Power Systems, Inc., a New York corporation (“NEPSI”), and (ii) membership interests of Northeast Power Realty, LLC, a New York limited liability company, which holds the real property that serves as NEPSI's headquarters (the "Acquisition"). NEPSI is a U.S.-based global provider of medium-voltage metal-enclosed power capacitor banks and harmonic filter banks for use on electric power systems. NEPSI is now a wholly-owned subsidiary of the Company and is operated by its Grid business unit. The purchase price was 
$26.0
 million in cash and 
873,657
 restricted shares of common stock of the Company.  As part of the transaction, the selling stockholders 
 may 
receive up to an additional 
1,000,000
 shares of common stock of the Company upon the achievement of certain specified revenue objectives in the future.

[0001437749-21-001877:notes:253]
On 
 October 22, 2020, 
the Company entered into an underwriting agreement with Oppenheimer & Co. Inc., as representative of the several underwriters named therein, relating to the issuance and sale (the “Offering”) of 
3,670,000
 shares of the Company's common stock at a public offering price of 
$15.00
 per share. The net proceeds to the Company from the Offering were approximately 
$51.5
 million, after deducting underwriting discounts and commissions and offering expenses payable by the Company. The Offering closed on 
 October 26, 2020. 
In addition, the Company had granted the underwriters a 
30
-day option to purchase up to an additional 
550,500
 shares of common stock at the public offering price which was 
not
 exercised.

[0001437749-21-001877:notes:254]
[same as prior period, unchanged from 0001437749-20-022522:notes:183]

[0001437749-21-001877:notes:255]
[same as prior period, unchanged from 0001437749-20-022522:notes:184]

[0001437749-21-001877:notes:256]
[same as prior period, unchanged from 0001437749-20-022522:notes:185]

[0001437749-21-001877:notes:257]
[same as prior period, unchanged from 0001437749-20-022522:notes:186]


## us-gaap:PropertyPlantAndEquipmentDisclosureTextBlock

[0001437749-21-001877:notes:258]
10.
 Property, Plant and Equipment

[0001437749-21-001877:notes:259]
[same as prior period, unchanged from 0001437749-20-022522:notes:188]

[0001437749-21-001877:notes:260]
[same as prior period, unchanged from 0001437749-20-022522:notes:189]

[0001437749-21-001877:notes:261]
|  |  | December 31, 2020 |  |  | March 31, 2020 |  |
| Construction in progress - equipment |  | $ | 111 |  |  | $ | 3,130 |  |
| Land |  |  | 270 |  |  |  | — |  |
| Building |  |  | 1,630 |  |  |  | — |  |
| Equipment and software |  |  | 41,743 |  |  |  | 41,737 |  |
| Furniture and fixtures |  |  | 1,310 |  |  |  | 1,302 |  |
| Leasehold improvements |  |  | 6,306 |  |  |  | 2,477 |  |
| Property, plant and equipment, gross |  |  | 51,370 |  |  |  | 48,646 |  |
| Less accumulated depreciation |  |  | (41,823 | ) |  |  | (40,081 | ) |
| Property, plant and equipment, net |  | $ | 9,547 |  |  | $ | 8,565 |  |

[0001437749-21-001877:notes:262]
[same as prior period, unchanged from 0001437749-20-022522:notes:191]

[0001437749-21-001877:notes:263]
[same as prior period, unchanged from 0001437749-20-022522:notes:193]

[0001437749-21-001877:notes:264]
[same as prior period, unchanged from 0001437749-20-022522:notes:194]

[0001437749-21-001877:notes:265]
2.9

[0001437749-21-001877:notes:266]
million and 
$3.1
 million for the

[0001437749-21-001877:notes:267]
, respectively.  The decrease in construction in progress primarily relates to the completion of capital investments in the Company's HTS equipment and leasehold improvements in the Company's leased facilities in Westminster and Ayer, Massachusetts.  The increase in land and building relates to the property added as part of the NEPSI Acquisition.


## us-gaap:ReconciliationOfAssetsFromSegmentToConsolidatedTextBlock

[0001437749-21-001877:notes:268]
|  |  | December 31, 2020 |  |  | March 31, 2020 |  |
| Grid |  | $ | 83,623 |  |  | $ | 44,044 |  |
| Wind |  |  | 6,140 |  |  |  | 14,250 |  |
| Corporate assets |  |  | 85,284 |  |  |  | 65,815 |  |
| Total |  | $ | 175,047 |  |  | $ | 124,109 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001437749-21-001877:notes:269]
3.
 Revenue Recognition

[0001437749-21-001877:notes:270]
The Company's revenues in its Grid segment are derived primarily through enabling the transmission and distribution of power, providing planning services that allow it to identify power grid needs and risks, and developing ship protection systems for the U.S. Navy. The Company's revenues in its Wind segment are derived primarily through supplying advanced power electronics and control systems, licensing its highly engineered wind turbine designs, and providing extensive customer support services to wind turbine manufacturers. The Company records revenue based on a 
five
-step model in accordance with ASC 
606,

[0001437749-21-001877:notes:271]
[same as prior period, unchanged from 0001437749-20-022522:notes:201]

[0001437749-21-001877:notes:272]
[same as prior period, unchanged from 0001437749-20-022522:notes:202]

[0001437749-21-001877:notes:273]
[same as prior period, unchanged from 0001437749-20-022522:notes:203]

[0001437749-21-001877:notes:274]
[same as prior period, unchanged from 0001437749-20-022522:notes:204]

[0001437749-21-001877:notes:275]
% of revenue, respectively, was recognized at the point in time when control transferred to the customer, with the remainder being recognized over time.  In the

[0001437749-21-001877:notes:276]
, 
57%
 and 
69%,
 respectively, of revenue was recognized at the point in time when control transferred to the customer, with the remainder being recognized over time.

[0001437749-21-001877:notes:277]
Following the Acquisition of NEPSI, the Company evaluated all open NEPSI contracts at the date of the Acquisition against a 
five
-step model in accordance with ASC 
606
 as NEPSI, as a private company, had deferred adopting 
ASC606
 prior to the Acquisition, as permitted.  The Company identified 
two
 NEPSI revenue streams which are (
1
) the sale of its major components which falls under the equipment and systems product line and (
2
) the sale of spare parts, which falls under the service product line.  Further details on each of these product lines can be found below.  The Company does 
not
 expect a material impact to its consolidated statements of operations on an ongoing basis resulting from the adoption of the ASC 
606
 standard for the NEPSI business, and NEPSI revenue streams will follow the existing policies noted below.

[0001437749-21-001877:notes:278]
In the Company's equipment and system product line, each contract with a customer summarizes each product sold to a customer, which typically represents distinct performance obligations. A contract's transaction price is allocated to each distinct performance obligation using the respective standalone selling price which is determined primarily using the cost-plus expected margin approach and recognized as revenue when, or as, the performance obligation is satisfied. The majority of the Company's product sales transfer control to the customer in line with the contracted delivery terms and revenue is recorded at the point in time when title and risk transfer to the customer, which is primarily upon delivery, as the Company has determined that this is the point in time that control transfers to the customer.

[0001437749-21-001877:notes:279]
[same as prior period, unchanged from 0001437749-20-022522:notes:209]

[0001437749-21-001877:notes:280]
three
 and 
nine
 months ended 
 December 31, 2020

[0001437749-21-001877:notes:281]
, the Company recorded $

[0001437749-21-001877:notes:282]
1.8

[0001437749-21-001877:notes:283]
million in grant revenue, respectively, which is included in the Company's Grid segment revenue.  In the

[0001437749-21-001877:notes:284]
, the Company recorded 
$3.9
 million and 
$5.3
 million in grant revenue, respectively, which is included in the Company's Grid segment revenue.

[0001437749-21-001877:notes:285]
In the Company's service and technology development product line, there are several different types of transactions and each begins with a contract with a customer that summarizes each product sold to a customer, which typically represent distinct performance obligations. The technology development transactions are primarily for activities that have 
no
 alternative use and for which a profit can be expected throughout the life of the contract. In these cases, the revenue is recognized over time, but in the instances where the profit cannot be assured throughout the entire contract, the revenue is recognized at a point in time. Each contract's transaction price is allocated to each distinct performance obligation using the respective standalone selling price which is determined primarily using the cost-plus expected margin approach. The ongoing service transactions are for service contracts that provide benefit to the customer simultaneously as the Company performs its obligations, and therefore this revenue is recognized ratably over time throughout the effective period of these contracts. The transaction prices on these contracts are allocated based on an adjusted market approach which is re-assessed annually for reasonableness. The field service transactions include contracts for delivery of goods and completion of services made at the customer's requests, which are 
not
 deemed satisfied until the work has been completed and/or the requested goods have been delivered, so all of this revenue is recognized at the point in time when the control changes, and at allocated prices based on the adjusted market approach driven by standard price lists. The royalty transactions are related to certain contract terms on transactions in the Company's equipment and systems product line based on activity as specified in the contracts. The transaction prices of these agreements are calculated based on an adjusted market approach as specified in the contract. The Company reports royalty revenue for usage-based royalties when the sales have occurred. In circumstances when collectability is 
not
 assured and a contract does 
not
 exist under ASC 
606,
 revenue is deferred until a non-refundable payment has been received for substantially all the amount that is due and there are 
no
 further remaining performance obligations.

[0001437749-21-001877:notes:286]
[same as prior period, unchanged from 0001437749-20-022522:notes:216]

[0001437749-21-001877:notes:287]
[same as prior period, unchanged from 0001437749-20-022522:notes:217]

[0001437749-21-001877:notes:288]
[same as prior period, unchanged from 0001437749-20-022522:notes:218]

[0001437749-21-001877:notes:289]
The Company records revenue net of sales tax, value added tax, excise tax and other taxes collected concurrent with revenue-producing activities. The Company has elected to recognize the cost for freight and shipping when control over the products sold passes to customers and revenue is recognized. The Company has elected to recognize incremental costs of obtaining a contract as expense when incurred except in contracts where the amortization period would exceed 
twelve
 months; in such cases the long-term amount will be assessed for materiality. The Company has elected 
not
 to adjust the promised amount of consideration for the effects of a significant financing component if the period of financing is 
twelve
 months or less.

[0001437749-21-001877:notes:290]
[same as prior period, unchanged from 0001437749-20-022522:notes:220]

[0001437749-21-001877:notes:291]
[same as prior period, unchanged from 0001437749-20-022522:notes:221]

[0001437749-21-001877:notes:292]
, the Company's contract assets and liabilities primarily relate to the timing differences between cash received from a customer in connection with contractual rights to invoicing and the timing of revenue recognition following completion of performance obligations. The Company's accounts receivable balance is made up entirely of customer contract related balances. Changes in the Company's contract assets, which are included in “Unbilled accounts receivable” and “Deferred program costs” (see Note 
8,
 “Accounts Receivable” and Note 
9,
 “Inventory” for a reconciliation to the condensed consolidated balance sheets) and contract liabilities, which are included in the current portion and long term portion of "Deferred revenue" in the Company's condensed consolidated balance sheets, are as follows:

[0001437749-21-001877:notes:293]
[same as prior period, unchanged from 0001437749-20-022522:notes:224]

[0001437749-21-001877:notes:294]
[same as prior period, unchanged from 0001437749-20-022522:notes:225]

[0001437749-21-001877:notes:295]
51.1

[0001437749-21-001877:notes:296]
[same as prior period, unchanged from 0001437749-20-022522:notes:227]

[0001437749-21-001877:notes:297]
7.2

[0001437749-21-001877:notes:298]
[same as prior period, unchanged from 0001437749-20-022522:notes:229]

[0001437749-21-001877:notes:299]
[same as prior period, unchanged from 0001437749-20-022522:notes:230]

[0001437749-21-001877:notes:300]
[same as prior period, unchanged from 0001437749-20-022522:notes:231]

[0001437749-21-001877:notes:301]
[same as prior period, unchanged from 0001437749-20-022522:notes:232]

[0001437749-21-001877:notes:302]
|  |  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  | Reportable |  | December 31, |  |  | December 31, |  |
|  | Segment |  | 2020 |  |  | 2019 |  |  | 2020 |  |  | 2019 |  |
| Inox Wind Limited | Wind |  |  | 24 | % |  |  | <10% |  |  |  | 12 | % |  |  | 11 | % |
| Department of Homeland Security | Grid |  |  | <10% |  |  |  | 22 | % |  |  | <10% |  |  |  | 12 | % |
| Vestas | Grid |  |  | <10% |  |  |  | 25 | % |  |  | <10% |  |  |  | 10 | % |
| EPC Services | Grid |  |  | 14 | % |  |  | <10% |  |  |  | 17 | % |  |  | <10% |  |


## us-gaap:ScheduleOfSegmentReportingInformationBySegmentTextBlock

[0001437749-21-001877:notes:303]
|  |  | Three Months Ended December 31, |  |  | Nine Months Ended December 31, |  |
|  |  | 2020 |  |  | 2019 |  |  | 2020 |  |  | 2019 |  |
| Revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Grid |  | $ | 17,086 |  |  | $ | 15,232 |  |  | $ | 51,149 |  |  | $ | 36,577 |  |
| Wind |  |  | 6,546 |  |  |  | 2,683 |  |  |  | 14,812 |  |  |  | 9,120 |  |
| Total |  | $ | 23,632 |  |  | $ | 17,915 |  |  | $ | 65,961 |  |  | $ | 45,697 |  |

[0001437749-21-001877:notes:304]
|  |  | Three Months Ended December 31, |  |  | Nine Months Ended December 31, |  |
|  |  | 2020 |  |  | 2019 |  |  | 2020 |  |  | 2019 |  |
| Operating profit (loss): |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Grid |  | $ | (5,826 | ) |  | $ | (3,732 | ) |  | $ | (8,388 | ) |  | $ | (9,723 | ) |
| Wind |  |  | 147 |  |  |  | (2,297 | ) |  |  | (1,956 | ) |  |  | (6,015 | ) |
| Unallocated corporate expenses |  |  | (3,579 | ) |  |  | (590 | ) |  |  | (5,337 | ) |  |  | (1,236 | ) |
| Total |  | $ | (9,258 | ) |  | $ | (6,619 | ) |  | $ | (15,681 | ) |  | $ | (16,974 | ) |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001437749-21-001877:notes:305]
16.
 Business Segments

[0001437749-21-001877:notes:306]
[same as prior period, unchanged from 0001437749-20-022522:notes:237]

[0001437749-21-001877:notes:307]
[same as prior period, unchanged from 0001437749-20-022522:notes:238]

[0001437749-21-001877:notes:308]
[same as prior period, unchanged from 0001437749-20-022522:notes:239]

[0001437749-21-001877:notes:309]
[same as prior period, unchanged from 0001437749-20-022522:notes:240]

[0001437749-21-001877:notes:310]
[same as prior period, unchanged from 0001437749-20-022522:notes:241]

[0001437749-21-001877:notes:311]
Unallocated corporate expenses consist primarily of loss on contingent consideration of

[0001437749-21-001877:notes:312]
million in both the

[0001437749-21-001877:notes:313]
. Additionally, unallocated corporate expenses consist of stock-based compensation expense of $

[0001437749-21-001877:notes:314]
0.8

[0001437749-21-001877:notes:315]
[same as prior period, unchanged from 0001437749-20-022522:notes:243]

[0001437749-21-001877:notes:316]
$0.6

[0001437749-21-001877:notes:317]
[same as prior period, unchanged from 0001437749-20-022522:notes:245]

[0001437749-21-001877:notes:318]
, respectively, and $

[0001437749-21-001877:notes:319]
2.6

[0001437749-21-001877:notes:320]
million and 
$1.2
 million in the

[0001437749-21-001877:notes:321]
[same as prior period, unchanged from 0001437749-20-022522:notes:249]


## us-gaap:SubsequentEventsTextBlock

[0001437749-21-001877:notes:322]
18.
 Subsequent Events

[0001437749-21-001877:notes:323]
The Company has performed an evaluation of subsequent events through the time of filing this Quarterly Report on Form 
10
-Q with the SEC and has determined that there are 
no
 such events to report.
