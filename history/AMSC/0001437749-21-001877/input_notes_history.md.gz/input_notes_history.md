# AMSC note change history — 0001437749-20-022522 → 0001437749-21-001877


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2021-02-03):
[0001437749-21-001877:note_history:1]
December 31, 2020
  (was, 2020-11-04, similarity 0.8):
[0001437749-20-022522:note_history:1]
September 30, 2020,

- changed (2021-02-03):
[0001437749-21-001877:note_history:2]
, and
  (was, 2020-11-04, similarity 0.75):
[0001437749-20-022522:note_history:2]
and


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2021-02-03):
[0001437749-21-001877:note_history:3]
1987.
 The Company is a leading system provider of megawatt-scale power resiliency solutions that Orchestrate the Rhythm and Harmony of Power on the Grid
™
 and that protect and expand the capability of the Navy's fleet. The Company's system level products leverage its proprietary “smart materials” and “smart software and controls” to provide enhanced resiliency and improved performance of megawatt-scale power flow.
  (was, 2020-11-04, similarity 0.9976):
[0001437749-20-022522:note_history:3]
1987.
 The Company is a leading system provider of megawatt-scale power resiliency solutions that orchestrate the rhythm and harmony of power on the grid
™
, and that protect and expand the capability of the Navy's fleet. The Company's system level products leverage its proprietary “smart materials” and “smart software and controls” to provide enhanced resiliency and improved performance of megawatt-scale power flow.

- changed (2021-02-03):
[0001437749-21-001877:note_history:4]
December 31, 2020
  (was, 2020-11-04, similarity 0.8):
[0001437749-20-022522:note_history:4]
September 30, 2020

- changed (2021-02-03):
[0001437749-21-001877:note_history:5]
December 31, 2020
  (was, 2020-11-04, similarity 0.8):
[0001437749-20-022522:note_history:5]
September 30, 2020

- changed (2021-02-03):
[0001437749-21-001877:note_history:6]
December 31, 2020
  (was, 2020-11-04, similarity 0.8):
[0001437749-20-022522:note_history:6]
September 30, 2020

- changed (2021-02-03):
[0001437749-21-001877:note_history:7]
December 31, 2020
  (was, 2020-11-04, similarity 0.8):
[0001437749-20-022522:note_history:7]
September 30, 2020

- changed (2021-02-03):
[0001437749-21-001877:note_history:8]
million. Marketable securities include certificate of deposits with maturities between 
three
 and 
nine
 months.  Cash used in operations for the
  (was, 2020-11-04, similarity 0.9433):
[0001437749-20-022522:note_history:8]
million. Marketable securities include certificate of deposits with maturities between 
six
 and 
eleven
 months.  Cash used in operations for the

- added (2021-02-03):
[0001437749-21-001877:note_history:9]
nine

- changed (2021-02-03):
[0001437749-21-001877:note_history:10]
December 31, 2020
  (was, 2020-11-04, similarity 0.8):
[0001437749-20-022522:note_history:10]
September 30, 2020

- changed (2021-02-03):
[0001437749-21-001877:note_history:11]
On 
 October 1, 2020 (
the "Acquisition Date"), the Company entered into a Stock Purchase Agreement (the “Stock Purchase Agreement”) with the selling stockholders named therein.  Pursuant to the terms of the Stock Purchase Agreement and concurrently with entering into such agreement, the Company acquired all of the issued and outstanding (i) shares of capital stock of Northeast Power Systems, Inc., a New York corporation (“NEPSI”), and (ii) membership interests of Northeast Power Realty, LLC, a New York limited liability company, which holds the real property that serves as NEPSI's headquarters (the "Acquisition"). NEPSI is a U.S.-based global provider of medium-voltage metal-enclosed power capacitor banks and harmonic filter banks for use on electric power systems. NEPSI is now a wholly-owned subsidiary of the Company and is operated by its Grid business unit. The purchase price was 
$26.0
 million in cash and 
873,657
 restricted shares of common stock of the Company.  As part of the transaction, the selling stockholders 
 may 
receive up to an additional 
1,000,000
 shares of common stock of the Company upon the achievement of certain specified revenue objectives in the future.
  (was, 2020-11-04, similarity 0.9755):
[0001437749-20-022522:note_history:11]
On 
 October 1, 2020, 
the Company entered into a Stock Purchase Agreement (the “Stock Purchase Agreement”) with the selling stockholders named therein.  Pursuant to the terms of the Stock Purchase Agreement and concurrently with entering into such agreement, the Company acquired all of the issued and outstanding (i) shares of capital stock of Northeast Power Systems, Inc., a New York corporation (“NEPSI”), and (ii) membership interests of Northeast Power Realty, LLC, a New York limited liability company, which holds the real property that serves as NEPSI's headquarters. NEPSI is a U.S.-based global provider of medium-voltage metal-enclosed power capacitor banks and harmonic filter banks for use on electric power systems. NEPSI is now a wholly-owned subsidiary of the Company and will be operated by its Grid business unit. The purchase price was 
$26.0
 million in cash and 
873,657
 restricted shares of common stock of the Company.  As part of the transaction, the selling stockholders 
 may 
receive up to an additional 
1,000,000
 shares of common stock of the Company upon the achievement of certain specified revenue objectives in the future.

- changed (2021-02-03):
[0001437749-21-001877:note_history:12]
On 
 October 22, 2020, 
the Company entered into an underwriting agreement with Oppenheimer & Co. Inc., as representative of the several underwriters named therein, relating to the issuance and sale (the “Offering”) of 
3,670,000
 shares of the Company's common stock at a public offering price of 
$15.00
 per share. The net proceeds to the Company from the Offering were approximately 
$51.5
 million, after deducting underwriting discounts and commissions and offering expenses payable by the Company. The Offering closed on 
 October 26, 2020. 
In addition, the Company had granted the underwriters a 
30
-day option to purchase up to an additional 
550,500
 shares of common stock at the public offering price which was 
not
 exercised.
  (was, 2020-11-04, similarity 0.9736):
[0001437749-20-022522:note_history:12]
On 
 October 22, 2020, 
the Company entered into an underwriting agreement with Oppenheimer & Co. Inc., as representative of the several underwriters named therein, relating to the issuance and sale (the “Offering”) of 
3,670,000
 shares of the Company's common stock at a public offering price of 
$15.00
 per share. The net proceeds to the Company from the Offering were approximately 
$51.4
 million, after deducting underwriting discounts and commissions and estimated offering expenses payable by the Company. The Offering closed on 
 October 26, 2020. 
In addition, the Company has granted the underwriters a 
30
-day option to purchase up to an additional 
550,500
 shares of common stock at the public offering price.

- added (2021-02-03):
[0001437749-21-001877:note_history:13]
nine

- changed (2021-02-03):
[0001437749-21-001877:note_history:14]
December 31, 2020
  (was, 2020-11-04, similarity 0.8):
[0001437749-20-022522:note_history:14]
September 30, 2020

- removed (2021-02-03):
[0001437749-20-022522:note_history:15]
six

- removed (2021-02-03):
[0001437749-20-022522:note_history:16]
six


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2021-02-03):
[0001437749-21-001877:note_history:17]
|  |  | Three Months Ended December 31, 2020 |  |  | Nine Months Ended December 31, 2020 |  |
| Product Line: |  | Grid |  |  | Wind |  |  | Grid |  |  | Wind |  |
| Equipment and systems |  | $ | 15,930 |  |  | $ | 6,153 |  |  | $ | 47,729 |  |  | $ | 12,828 |  |
| Services and technology development |  |  | 1,156 |  |  |  | 393 |  |  |  | 3,420 |  |  |  | 1,984 |  |
| Total |  | $ | 17,086 |  |  | $ | 6,546 |  |  | $ | 51,149 |  |  | $ | 14,812 |  |
| Region: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas |  | $ | 13,394 |  |  | $ | 14 |  |  | $ | 39,626 |  |  | $ | 56 |  |
| Asia Pacific |  |  | 351 |  |  |  | 6,461 |  |  |  | 6,736 |  |  |  | 14,463 |  |
| EMEA |  |  | 3,341 |  |  |  | 71 |  |  |  | 4,787 |  |  |  | 293 |  |
| Total |  | $ | 17,086 |  |  | $ | 6,546 |  |  | $ | 51,149 |  |  | $ | 14,812 |  |
  (was, 2020-11-04, similarity 0.9831):
[0001437749-20-022522:note_history:17]
|  |  | Three Months Ended September 30, 2020 |  |  | Six Months Ended September 30, 2020 |  |
| Product Line: |  | Grid |  |  | Wind |  |  | Grid |  |  | Wind |  |
| Equipment and systems |  | $ | 15,261 |  |  | $ | 4,059 |  |  | $ | 31,798 |  |  | $ | 6,676 |  |
| Services and technology development |  |  | 1,086 |  |  |  | 711 |  |  |  | 2,264 |  |  |  | 1,591 |  |
| Total |  | $ | 16,347 |  |  | $ | 4,770 |  |  | $ | 34,062 |  |  | $ | 8,267 |  |
| Region: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas |  | $ | 15,677 |  |  | $ | 30 |  |  | $ | 26,231 |  |  | $ | 42 |  |
| Asia Pacific |  |  | 370 |  |  |  | 4,734 |  |  |  | 6,385 |  |  |  | 8,002 |  |
| EMEA |  |  | 300 |  |  |  | 6 |  |  |  | 1,446 |  |  |  | 223 |  |
| Total |  | $ | 16,347 |  |  | $ | 4,770 |  |  | $ | 34,062 |  |  | $ | 8,267 |  |

- changed (2021-02-03):
[0001437749-21-001877:note_history:18]
|  |  | Three Months Ended December 31, 2019 |  |  | Nine Months Ended December 31, 2019 |  |
| Product Line: |  | Grid |  |  | Wind |  |  | Grid |  |  | Wind |  |
| Equipment and systems |  | $ | 14,040 |  |  | $ | 2,160 |  |  | $ | 32,438 |  |  | $ | 7,742 |  |
| Services and technology development |  |  | 1,192 |  |  |  | 523 |  |  |  | 4,139 |  |  |  | 1,379 |  |
| Total |  | $ | 15,232 |  |  | $ | 2,683 |  |  | $ | 36,577 |  |  | $ | 9,120 |  |
| Region: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas |  | $ | 10,164 |  |  | $ | 2 |  |  | $ | 28,663 |  |  | $ | 49 |  |
| Asia Pacific |  |  | 330 |  |  |  | 2,647 |  |  |  | 2,550 |  |  |  | 8,968 |  |
| EMEA |  |  | 4,738 |  |  |  | 34 |  |  |  | 5,364 |  |  |  | 104 |  |
| Total |  | $ | 15,232 |  |  | $ | 2,683 |  |  | $ | 36,577 |  |  | $ | 9,120 |  |
  (was, 2020-11-04, similarity 0.9831):
[0001437749-20-022522:note_history:18]
|  |  | Three Months Ended September 30, 2019 |  |  | Six Months Ended September 30, 2019 |  |
| Product Line: |  | Grid |  |  | Wind |  |  | Grid |  |  | Wind |  |
| Equipment and systems |  | $ | 10,044 |  |  | $ | 2,077 |  |  | $ | 18,399 |  |  | $ | 5,581 |  |
| Services and technology development |  |  | 1,445 |  |  |  | 446 |  |  |  | 2,946 |  |  |  | 856 |  |
| Total |  | $ | 11,489 |  |  | $ | 2,523 |  |  | $ | 21,345 |  |  | $ | 6,437 |  |
| Region: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas |  | $ | 10,698 |  |  | $ | 1 |  |  | $ | 18,499 |  |  | $ | 47 |  |
| Asia Pacific |  |  | 393 |  |  |  | 2,464 |  |  |  | 2,220 |  |  |  | 6,320 |  |
| EMEA |  |  | 398 |  |  |  | 58 |  |  |  | 626 |  |  |  | 70 |  |
| Total |  | $ | 11,489 |  |  | $ | 2,523 |  |  | $ | 21,345 |  |  | $ | 6,437 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2021-02-03):
[0001437749-21-001877:note_history:19]
The Company's revenues in its Grid segment are derived primarily through enabling the transmission and distribution of power, providing planning services that allow it to identify power grid needs and risks, and developing ship protection systems for the U.S. Navy. The Company's revenues in its Wind segment are derived primarily through supplying advanced power electronics and control systems, licensing its highly engineered wind turbine designs, and providing extensive customer support services to wind turbine manufacturers. The Company records revenue based on a 
five
-step model in accordance with ASC 
606,
  (was, 2020-11-04, similarity 0.9667):
[0001437749-20-022522:note_history:19]
The Company's revenues in its Grid segment are derived primarily through enabling the transmission and distribution of power, providing planning services that allow it to identify power grid needs and risks, and developing ship protection systems for the U.S. Navy. The Company's revenues in its Wind segment are derived primarily through supplying advanced power electronics and control systems, licensing its highly engineered wind turbine designs, and providing extensive customer support services to wind turbine manufacturers. The Company records revenue based on a 
five
-step model in accordance with Accounting Standards Codification ("ASC") 
606,

- changed (2021-02-03):
[0001437749-21-001877:note_history:20]
three
 and 
nine
  (was, 2020-11-04, similarity 0.8148):
[0001437749-20-022522:note_history:20]
three
 and 
six

- changed (2021-02-03):
[0001437749-21-001877:note_history:21]
December 31, 2020
  (was, 2020-11-04, similarity 0.8):
[0001437749-20-022522:note_history:21]
September 30, 2020

- changed (2021-02-03):
[0001437749-21-001877:note_history:22]
% of revenue, respectively, was recognized at the point in time when control transferred to the customer, with the remainder being recognized over time.  In the
  (was, 2020-11-04, similarity 0.9184):
[0001437749-20-022522:note_history:22]
of revenue was recognized at the point in time when control transferred to the customer, with the remainder being recognized over time.

- added (2021-02-03):
[0001437749-21-001877:note_history:23]
three
 and 
nine

- added (2021-02-03):
[0001437749-21-001877:note_history:24]
months ended

- changed (2021-02-03):
[0001437749-21-001877:note_history:25]
December 31, 2019
  (was, 2020-11-04, similarity 0.8):
[0001437749-20-022522:note_history:25]
September 30, 2019

- changed (2021-02-03):
[0001437749-21-001877:note_history:26]
, 
57%
 and 
69%,
 respectively, of revenue was recognized at the point in time when control transferred to the customer, with the remainder being recognized over time.
  (was, 2020-11-04, similarity 0.8102):
[0001437749-20-022522:note_history:26]
% of revenue, respectively, was recognized at the point in time when control transferred to the customer, with the remainder being recognized over time.  In both the 
three
 and 
six
 months ended

- added (2021-02-03):
[0001437749-21-001877:note_history:27]
Following the Acquisition of NEPSI, the Company evaluated all open NEPSI contracts at the date of the Acquisition against a 
five
-step model in accordance with ASC 
606
 as NEPSI, as a private company, had deferred adopting 
ASC606
 prior to the Acquisition, as permitted.  The Company identified 
two
 NEPSI revenue streams which are (
1
) the sale of its major components which falls under the equipment and systems product line and (
2
) the sale of spare parts, which falls under the service product line.  Further details on each of these product lines can be found below.  The Company does 
not
 expect a material impact to its consolidated statements of operations on an ongoing basis resulting from the adoption of the ASC 
606
 standard for the NEPSI business, and NEPSI revenue streams will follow the existing policies noted below.

- changed (2021-02-03):
[0001437749-21-001877:note_history:28]
In the Company's equipment and system product line, each contract with a customer summarizes each product sold to a customer, which typically represents distinct performance obligations. A contract's transaction price is allocated to each distinct performance obligation using the respective standalone selling price which is determined primarily using the cost-plus expected margin approach and recognized as revenue when, or as, the performance obligation is satisfied. The majority of the Company's product sales transfer control to the customer in line with the contracted delivery terms and revenue is recorded at the point in time when title and risk transfer to the customer, which is primarily upon delivery, as the Company has determined that this is the point in time that control transfers to the customer.
  (was, 2020-11-04, similarity 0.9788):
[0001437749-20-022522:note_history:28]
In the Company's equipment and system product line, each contract with a customer summarizes each product sold to a customer, which typically represents distinct performance obligations. A contract's transaction price is allocated to each distinct performance obligation using the respective standalone selling price which is determined primarily using the cost-plus expected margin approach and recognized as revenue when, or as, the performance obligation is satisfied. The majority of the Company's product sales transfer control to the customer in line with the contracted delivery terms and revenue is recorded at the point in time when title and risk transfer to the customer, as the Company has determined that this is the point in time that control transfers to the customer.

- changed (2021-02-03):
[0001437749-21-001877:note_history:29]
three
 and 
nine
 months ended 
 December 31, 2020
  (was, 2020-11-04, similarity 0.875):
[0001437749-20-022522:note_history:29]
three
 and 
six
 months ended 
 September 30, 2020

- changed (2021-02-03):
[0001437749-21-001877:note_history:30]
, the Company recorded $
  (was, 2020-11-04, similarity 0.9565):
[0001437749-20-022522:note_history:30]
the Company recorded $

- changed (2021-02-03):
[0001437749-21-001877:note_history:31]
million in grant revenue, respectively, which is included in the Company's Grid segment revenue.  In the
  (was, 2020-11-04, similarity 0.8841):
[0001437749-20-022522:note_history:31]
million in grant revenue, respectively, which is included in the Company's Grid segment revenue.  In the 
three
 and 
six
 months ended

- added (2021-02-03):
[0001437749-21-001877:note_history:32]
three
 and 
nine

- added (2021-02-03):
[0001437749-21-001877:note_history:33]
months ended

- changed (2021-02-03):
[0001437749-21-001877:note_history:34]
December 31, 2019
  (was, 2020-11-04, similarity 0.8):
[0001437749-20-022522:note_history:34]
September 30, 2019

- changed (2021-02-03):
[0001437749-21-001877:note_history:35]
, the Company recorded 
$3.9
 million and 
$5.3
 million in grant revenue, respectively, which is included in the Company's Grid segment revenue.
  (was, 2020-11-04, similarity 0.9699):
[0001437749-20-022522:note_history:35]
, the Company recorded 
$0.7
 million and 
$1.1
 million in grant revenue, respectively, which is included in the Company's Grid revenue.

- changed (2021-02-03):
[0001437749-21-001877:note_history:36]
In the Company's service and technology development product line, there are several different types of transactions and each begins with a contract with a customer that summarizes each product sold to a customer, which typically represent distinct performance obligations. The technology development transactions are primarily for activities that have 
no
 alternative use and for which a profit can be expected throughout the life of the contract. In these cases, the revenue is recognized over time, but in the instances where the profit cannot be assured throughout the entire contract, the revenue is recognized at a point in time. Each contract's transaction price is allocated to each distinct performance obligation using the respective standalone selling price which is determined primarily using the cost-plus expected margin approach. The ongoing service transactions are for service contracts that provide benefit to the customer simultaneously as the Company performs its obligations, and therefore this revenue is recognized ratably over time throughout the effective period of these contracts. The transaction prices on these contracts are allocated based on an adjusted market approach which is re-assessed annually for reasonableness. The field service transactions include contracts for delivery of goods and completion of services made at the customer's requests, which are 
not
 deemed satisfied until the work has been completed and/or the requested goods have been delivered, so all of this revenue is recognized at the point in time when the control changes, and at allocated prices based on the adjusted market approach driven by standard price lists. The royalty transactions are related to certain contract terms on transactions in the Company's equipment and systems product line based on activity as specified in the contracts. The transaction prices of these agreements are calculated based on an adjusted market approach as specified in the contract. The Company reports royalty revenue for usage-based royalties when the sales have occurred. In circumstances when collectability is 
not
 assured and a contract does 
not
 exist under ASC 
606,
 revenue is deferred until a non-refundable payment has been received for substantially all the amount that is due and there are 
no
 further remaining performance obligations.
  (was, 2020-11-04, similarity 0.9998):
[0001437749-20-022522:note_history:36]
In the Company's service and technology development product line, there are several different types of transactions and each begins with a contract with a customer that summarizes each product sold to a customer, which typically represents distinct performance obligations. The technology development transactions are primarily for activities that have 
no
 alternative use and for which a profit can be expected throughout the life of the contract. In these cases, the revenue is recognized over time, but in the instances where the profit cannot be assured throughout the entire contract, the revenue is recognized at a point in time. Each contract's transaction price is allocated to each distinct performance obligation using the respective standalone selling price which is determined primarily using the cost-plus expected margin approach. The ongoing service transactions are for service contracts that provide benefit to the customer simultaneously as the Company performs its obligations, and therefore this revenue is recognized ratably over time throughout the effective period of these contracts. The transaction prices on these contracts are allocated based on an adjusted market approach which is re-assessed annually for reasonableness. The field service transactions include contracts for delivery of goods and completion of services made at the customer's requests, which are 
not
 deemed satisfied until the work has been completed and/or the requested goods have been delivered, so all of this revenue is recognized at the point in time when the control changes, and at allocated prices based on the adjusted market approach driven by standard price lists. The royalty transactions are related to certain contract terms on transactions in the Company's equipment and systems product line based on activity as specified in the contracts. The transaction prices of these agreements are calculated based on an adjusted market approach as specified in the contract. The Company reports royalty revenue for usage-based royalties when the sales have occurred. In circumstances when collectability is 
not
 assured and a contract does 
not
 exist under ASC 
606,
 revenue is deferred until a non-refundable payment has been received for substantially all the amount that is due and there are 
no
 further remaining performance obligations.

- changed (2021-02-03):
[0001437749-21-001877:note_history:37]
|  |  | Three Months Ended December 31, 2020 |  |  | Nine Months Ended December 31, 2020 |  |
| Product Line: |  | Grid |  |  | Wind |  |  | Grid |  |  | Wind |  |
| Equipment and systems |  | $ | 15,930 |  |  | $ | 6,153 |  |  | $ | 47,729 |  |  | $ | 12,828 |  |
| Services and technology development |  |  | 1,156 |  |  |  | 393 |  |  |  | 3,420 |  |  |  | 1,984 |  |
| Total |  | $ | 17,086 |  |  | $ | 6,546 |  |  | $ | 51,149 |  |  | $ | 14,812 |  |
| Region: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas |  | $ | 13,394 |  |  | $ | 14 |  |  | $ | 39,626 |  |  | $ | 56 |  |
| Asia Pacific |  |  | 351 |  |  |  | 6,461 |  |  |  | 6,736 |  |  |  | 14,463 |  |
| EMEA |  |  | 3,341 |  |  |  | 71 |  |  |  | 4,787 |  |  |  | 293 |  |
| Total |  | $ | 17,086 |  |  | $ | 6,546 |  |  | $ | 51,149 |  |  | $ | 14,812 |  |
  (was, 2020-11-04, similarity 0.9831):
[0001437749-20-022522:note_history:37]
|  |  | Three Months Ended September 30, 2020 |  |  | Six Months Ended September 30, 2020 |  |
| Product Line: |  | Grid |  |  | Wind |  |  | Grid |  |  | Wind |  |
| Equipment and systems |  | $ | 15,261 |  |  | $ | 4,059 |  |  | $ | 31,798 |  |  | $ | 6,676 |  |
| Services and technology development |  |  | 1,086 |  |  |  | 711 |  |  |  | 2,264 |  |  |  | 1,591 |  |
| Total |  | $ | 16,347 |  |  | $ | 4,770 |  |  | $ | 34,062 |  |  | $ | 8,267 |  |
| Region: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas |  | $ | 15,677 |  |  | $ | 30 |  |  | $ | 26,231 |  |  | $ | 42 |  |
| Asia Pacific |  |  | 370 |  |  |  | 4,734 |  |  |  | 6,385 |  |  |  | 8,002 |  |
| EMEA |  |  | 300 |  |  |  | 6 |  |  |  | 1,446 |  |  |  | 223 |  |
| Total |  | $ | 16,347 |  |  | $ | 4,770 |  |  | $ | 34,062 |  |  | $ | 8,267 |  |

- changed (2021-02-03):
[0001437749-21-001877:note_history:38]
|  |  | Three Months Ended December 31, 2019 |  |  | Nine Months Ended December 31, 2019 |  |
| Product Line: |  | Grid |  |  | Wind |  |  | Grid |  |  | Wind |  |
| Equipment and systems |  | $ | 14,040 |  |  | $ | 2,160 |  |  | $ | 32,438 |  |  | $ | 7,742 |  |
| Services and technology development |  |  | 1,192 |  |  |  | 523 |  |  |  | 4,139 |  |  |  | 1,379 |  |
| Total |  | $ | 15,232 |  |  | $ | 2,683 |  |  | $ | 36,577 |  |  | $ | 9,120 |  |
| Region: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas |  | $ | 10,164 |  |  | $ | 2 |  |  | $ | 28,663 |  |  | $ | 49 |  |
| Asia Pacific |  |  | 330 |  |  |  | 2,647 |  |  |  | 2,550 |  |  |  | 8,968 |  |
| EMEA |  |  | 4,738 |  |  |  | 34 |  |  |  | 5,364 |  |  |  | 104 |  |
| Total |  | $ | 15,232 |  |  | $ | 2,683 |  |  | $ | 36,577 |  |  | $ | 9,120 |  |
  (was, 2020-11-04, similarity 0.9831):
[0001437749-20-022522:note_history:38]
|  |  | Three Months Ended September 30, 2019 |  |  | Six Months Ended September 30, 2019 |  |
| Product Line: |  | Grid |  |  | Wind |  |  | Grid |  |  | Wind |  |
| Equipment and systems |  | $ | 10,044 |  |  | $ | 2,077 |  |  | $ | 18,399 |  |  | $ | 5,581 |  |
| Services and technology development |  |  | 1,445 |  |  |  | 446 |  |  |  | 2,946 |  |  |  | 856 |  |
| Total |  | $ | 11,489 |  |  | $ | 2,523 |  |  | $ | 21,345 |  |  | $ | 6,437 |  |
| Region: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas |  | $ | 10,698 |  |  | $ | 1 |  |  | $ | 18,499 |  |  | $ | 47 |  |
| Asia Pacific |  |  | 393 |  |  |  | 2,464 |  |  |  | 2,220 |  |  |  | 6,320 |  |
| EMEA |  |  | 398 |  |  |  | 58 |  |  |  | 626 |  |  |  | 70 |  |
| Total |  | $ | 11,489 |  |  | $ | 2,523 |  |  | $ | 21,345 |  |  | $ | 6,437 |  |

- changed (2021-02-03):
[0001437749-21-001877:note_history:39]
December 31, 2020
  (was, 2020-11-04, similarity 0.8):
[0001437749-20-022522:note_history:39]
September 30, 2020

- changed (2021-02-03):
[0001437749-21-001877:note_history:40]
, the Company's contract assets and liabilities primarily relate to the timing differences between cash received from a customer in connection with contractual rights to invoicing and the timing of revenue recognition following completion of performance obligations. The Company's accounts receivable balance is made up entirely of customer contract related balances. Changes in the Company's contract assets, which are included in “Unbilled accounts receivable” and “Deferred program costs” (see Note 
8,
 “Accounts Receivable” and Note 
9,
 “Inventory” for a reconciliation to the condensed consolidated balance sheets) and contract liabilities, which are included in the current portion and long term portion of "Deferred revenue" in the Company's condensed consolidated balance sheets, are as follows:
  (was, 2020-11-04, similarity 0.9875):
[0001437749-20-022522:note_history:40]
, the Company's contract assets and liabilities primarily relate to the timing differences between cash received from a customer in connection with contractual rights to invoicing and the timing of revenue recognition following completion of performance obligations. The Company's accounts receivable balance is made up entirely of customer contract related balances. Changes in the Company's contract assets, which are included in “Accounts receivable (unbilled)” and “Deferred program costs” (see Note 
7,
 “Accounts Receivable” and Note 
8,
 “Inventory” for a reconciliation to the condensed consolidated balance sheets) and contract liabilities, which are included in the current portion and long term portion of "Deferred revenue" in the Company's condensed consolidated balance sheets, are as follows:

- added (2021-02-03):
[0001437749-21-001877:note_history:41]
|  |  | Unbilled Accounts Receivable |  |  | Deferred Program Costs |  |  | Contract Liabilities |  |
| Beginning balance as of March 31, 2020 |  | $ | 5,711 |  |  | $ | 1,631 |  |  | $ | 26,142 |  |
| Increases for costs incurred to fulfill performance obligations |  |  | — |  |  |  | 6,635 |  |  |  | — |  |
| Increase for balances acquired |  |  | 101 |  |  |  | — |  |  |  | 2,700 |  |
| Increase (decrease) due to customer billings |  |  | (8,255 | ) |  |  | — |  |  |  | 42,785 |  |
| Decrease due to cost recognition on completed performance obligations |  |  | — |  |  |  | (6,969 | ) |  |  | — |  |
| Increase (decrease) due to recognition of revenue based on transfer of control of performance obligations |  |  | 6,644 |  |  |  | — |  |  |  | (48,274 | ) |
| Other changes and FX impact |  |  | — |  |  |  | 33 |  |  |  | 1,025 |  |
| Ending balance as of December 31, 2020 |  | $ | 4,201 |  |  | $ | 1,330 |  |  | $ | 24,378 |  |

- changed (2021-02-03):
[0001437749-21-001877:note_history:42]
|  |  | Unbilled Accounts Receivable |  |  | Deferred Program Costs |  |  | Contract Liabilities |  |
| Beginning balance as of March 31, 2019 |  | $ | 2,213 |  |  | $ | 318 |  |  | $ | 15,519 |  |
| Increases for costs incurred to fulfill performance obligations |  |  | — |  |  |  | 3,001 |  |  |  | — |  |
| Increase (decrease) due to customer billings |  |  | (7,417 | ) |  |  | — |  |  |  | 36,461 |  |
| Decrease due to cost recognition on completed performance obligations |  |  | — |  |  |  | (2,221 | ) |  |  | — |  |
| Increase (decrease) due to recognition of revenue based on transfer of control of performance obligations |  |  | 9,820 |  |  |  | — |  |  |  | (28,768 | ) |
| Other changes and FX impact |  |  | (3 | ) |  |  | (1 | ) |  |  | (69 | ) |
| Ending balance as of December 31, 2019 |  | $ | 4,613 |  |  | $ | 1,097 |  |  | $ | 23,143 |  |
  (was, 2020-11-04, similarity 0.9953):
[0001437749-20-022522:note_history:42]
|  |  | Unbilled Accounts Receivable |  |  | Deferred Program Costs |  |  | Contract Liabilities |  |
| Beginning balance as of March 31, 2019 |  | $ | 2,213 |  |  | $ | 318 |  |  | $ | 15,519 |  |
| Increases for costs incurred to fulfill performance obligations |  |  | — |  |  |  | 2,153 |  |  |  | — |  |
| Increase (decrease) due to customer billings |  |  | (2,926 | ) |  |  | — |  |  |  | 19,340 |  |
| Decrease due to cost recognition on completed performance obligations |  |  | — |  |  |  | (310 | ) |  |  | — |  |
| Increase (decrease) due to recognition of revenue based on transfer of control of performance obligations |  |  | 4,711 |  |  |  | — |  |  |  | (18,534 | ) |
| Other changes and FX impact |  |  | (4 | ) |  |  | (9 | ) |  |  | (313 | ) |
| Ending balance as of September 30, 2019 |  | $ | 3,994 |  |  | $ | 2,152 |  |  | $ | 16,012 |  |

- changed (2021-02-03):
[0001437749-21-001877:note_history:43]
December 31, 2020
  (was, 2020-11-04, similarity 0.8):
[0001437749-20-022522:note_history:43]
September 30, 2020

- changed (2021-02-03):
[0001437749-21-001877:note_history:44]
three
 and 
nine
 months ended 
 December 31, 2020
  (was, 2020-11-04, similarity 0.875):
[0001437749-20-022522:note_history:44]
three
 and 
six
 months ended 
 September 30, 2020

- added (2021-02-03):
[0001437749-21-001877:note_history:45]
|  |  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  | Reportable |  | December 31, |  |  | December 31, |  |
|  | Segment |  | 2020 |  |  | 2019 |  |  | 2020 |  |  | 2019 |  |
| Inox Wind Limited | Wind |  |  | 24 | % |  |  | <10% |  |  |  | 12 | % |  |  | 11 | % |
| Department of Homeland Security | Grid |  |  | <10% |  |  |  | 22 | % |  |  | <10% |  |  |  | 12 | % |
| Vestas | Grid |  |  | <10% |  |  |  | 25 | % |  |  | <10% |  |  |  | 10 | % |
| EPC Services | Grid |  |  | 14 | % |  |  | <10% |  |  |  | 17 | % |  |  | <10% |  |

- removed (2021-02-03):
[0001437749-20-022522:note_history:46]
,

- removed (2021-02-03):
[0001437749-20-022522:note_history:47]
77%

- removed (2021-02-03):
[0001437749-20-022522:note_history:48]
|  |  | Unbilled Accounts Receivable |  |  | Deferred Program Costs |  |  | Contract Liabilities |  |
| Beginning balance as of March 31, 2020 |  | $ | 5,711 |  |  | $ | 1,631 |  |  | $ | 26,142 |  |
| Increases for costs incurred to fulfill performance obligations |  |  | — |  |  |  | 3,279 |  |  |  | — |  |
| Increase (decrease) due to customer billings |  |  | (5,929 | ) |  |  | — |  |  |  | 23,931 |  |
| Decrease due to cost recognition on completed performance obligations |  |  | — |  |  |  | (3,314 | ) |  |  | — |  |
| Increase (decrease) due to recognition of revenue based on transfer of control of performance obligations |  |  | 6,186 |  |  |  | — |  |  |  | (28,678 | ) |
| Other changes and FX impact |  |  | 0 |  |  |  | 18 |  |  |  | 561 |  |
| Ending balance as of September 30, 2020 |  | $ | 5,968 |  |  | $ | 1,614 |  |  | $ | 21,956 |  |

- removed (2021-02-03):
[0001437749-20-022522:note_history:49]
|  |  |  | Three Months Ended |  |  | Six Months Ended |  |
|  | Reportable |  | September 30, |  |  | September 30, |  |
|  | Segment |  | 2020 |  |  | 2019 |  |  | 2020 |  |  | 2019 |  |
| EPC Services | Grid |  |  | 12 | % |  |  | 0 | % |  |  | 18 | % |  |  | 0 | % |
| Hoffman Construction | Grid |  |  | <10% |  |  |  | 25 | % |  |  | <10% |  |  |  | 12 | % |
| Inox Wind Limited | Wind |  |  | <10% |  |  |  | <10% |  |  |  | <10% |  |  |  | 17 | % |
| M.J. Electric, LLC | Grid |  |  | <10% |  |  |  | 25 | % |  |  | <10% |  |  |  | 13 | % |
| Micron Technology | Grid |  |  | <10% |  |  |  | <10% |  |  |  | <10% |  |  |  | 14 | % |
| Reed & Reed Inc. | Grid |  |  | 25 | % |  |  | 0 | % |  |  | 12 | % |  |  | 0 | % |
| Siemens Gamesa Renewable Energy Pty. Ltd. | Grid |  |  | <10% |  |  |  | 0 | % |  |  | 13 | % |  |  | 0 | % |


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: tag_name, score: 1.0

- changed (2021-02-03):
[0001437749-21-001877:note_history:50]
The Company has performed an evaluation of subsequent events through the time of filing this Quarterly Report on Form 
10
-Q with the SEC and has determined that there are 
no
 such events to report.
  (was, 2020-11-04, similarity 0.9112):
[0001437749-20-022522:note_history:50]
The Company has performed an evaluation of subsequent events through the time of filing this Quarterly Report on Form 
10
-Q with the SEC and has determined that other than the following information, there are 
no
 such events to report.

- removed (2021-02-03):
[0001437749-20-022522:note_history:51]
On 
 October 1, 2020, 
the Company entered into the Stock Purchase Agreement with the selling stockholders named therein.  Pursuant to the terms of the Stock Purchase Agreement and concurrently with entering into such agreement, the Company acquired all of the issued and outstanding (i) shares of capital stock of NEPSI, and (ii) membership interests of Northeast Power Realty, LLC, a New York limited liability company, which holds the real property that serves as NEPSI's headquarters.  NEPSI is a U.S.-based global provider of medium-voltage metal-enclosed power capacitor banks and harmonic filter banks for use on electric power systems. NEPSI is now a wholly-owned subsidiary of the Company and will be operated by the Grid business unit. The NEPSI purchase price was 
$26.0
 million in cash on hand, including cash from the settlement of the Company's 
$25
 million certificate of deposit during the 
three
 months ended 
 September 30, 2020, 
and 
873,657
 restricted shares of common stock of the Company.  The transaction also includes an earn-out opportunity with the potential for the issuance of up to an additional 
1.0
 million shares of common stock of the Company to the selling stockholders based on the achievement by NEPSI of certain revenue targets for the fiscal years ending 
 March 31, 2021 
through 
 March 31, 2024. 
The Company assumed 
no
 debt in this transaction. NEPSI's results of operations will be included in the Company's consolidated financial statements beginning on 
 October 1, 2020.

- removed (2021-02-03):
[0001437749-20-022522:note_history:52]
On 
 October 26, 2020, 
the Company completed the Offering of 
3,670,000
 shares of common stock of the Company at a public offering price of 
$15.00
 per share.  The net proceeds to the Company from the Offering were approximately 
$51.4
 million, after deducting underwriting discounts and commissions and estimated offering expenses payable by the Company. In addition, the Company has granted the underwriters a 
30
-day option to purchase up to an additional 
550,500
 shares of common stock at the public offering price.
