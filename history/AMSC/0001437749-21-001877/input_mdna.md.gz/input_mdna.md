# AMSC MD&A — 0001437749-21-001877


## mdna

[0001437749-21-001877:mdna:1]
[same as prior period, unchanged from 0001437749-20-022522:mdna:1]

[0001437749-21-001877:mdna:2]
[same as prior period, unchanged from 0001437749-20-022522:mdna:2]

[0001437749-21-001877:mdna:3]
[same as prior period, unchanged from 0001437749-20-022522:mdna:3]

[0001437749-21-001877:mdna:4]
[same as prior period, unchanged from 0001437749-20-022522:mdna:4]

[0001437749-21-001877:mdna:5]
[same as prior period, unchanged from 0001437749-20-022522:mdna:5]

[0001437749-21-001877:mdna:6]
[same as prior period, unchanged from 0001437749-20-022522:mdna:6]

[0001437749-21-001877:mdna:7]
[same as prior period, unchanged from 0001437749-20-022522:mdna:7]

[0001437749-21-001877:mdna:8]
[same as prior period, unchanged from 0001437749-20-022522:mdna:8]

[0001437749-21-001877:mdna:9]
[same as prior period, unchanged from 0001437749-20-022522:mdna:9]

[0001437749-21-001877:mdna:10]
[same as prior period, unchanged from 0001437749-20-022522:mdna:10]

[0001437749-21-001877:mdna:11]
On October 31, 2018, we entered into a Subcontract Agreement with Commonwealth Edison Company (“ComEd”) (the “Subcontract Agreement”) for the manufacture and installation of the Company’s REG system within ComEd’s electric grid in Chicago, Illinois (the “Project”). As provided in the Subcontract Agreement, the Subcontract Agreement became effective upon the signing of an amendment by us and the U.S. Department of Homeland Security (“DHS”) to the existing contract (the “Prime Contract”) between us and DHS on June 20, 2019. Unless terminated earlier by us, ComEd or DHS according to the terms of the Subcontract Agreement, the term of the Subcontract Agreement will continue until we complete our warranty obligations under the Subcontract Agreement. Under the terms of the Subcontract Agreement, we have agreed, among other things, to provide the REG system and to supervise ComEd’s installation of the REG system in Chicago. As part of our separate cost sharing arrangement with DHS under the Prime Contract, we expect funding provided by DHS in connection with the Subcontract Agreement to be between $9.0 to $11.0 million, which represents the total amount of revenue we are expected to recognize over the term of the Subcontract Agreement and includes up to $1.0 million that we have agreed to reimburse ComEd for costs incurred by ComEd while undertaking its tasks under the Subcontract Agreement (the “Reimbursement Amount”). In addition, we are required to deliver an irrevocable letter of credit in the amount of $5.0 million to secure certain Company obligations under the Subcontract Agreement, which we have done, and deposited $5.0 million in an escrow account as collateral to secure such letter of credit.  ComEd has agreed to provide the site and provide all civil engineering work required to support the installation, operation and integration of the REG system into ComEd’s electric grid. Other than the Reimbursement Amount, ComEd is responsible for its own costs and expenses. DHS’s approval to commence with construction was obtained on June 20, 2019. Substation work on the project began in late 2019 and we have delivered the REG project hardware. The REG system is expected to be operational in 2021.

[0001437749-21-001877:mdna:12]
On October 1, 2020, we entered into a Stock Purchase Agreement (the “Stock Purchase Agreement”) with the selling stockholders named therein.  Pursuant to the terms of the Stock Purchase Agreement and concurrently with entering into such agreement, we acquired all of the issued and outstanding (i) shares of capital stock of Northeast Power Systems, Inc., a New York corporation (“NEPSI”), and (ii) membership interests of Northeast Power Realty, LLC, a New York limited liability company, which holds the real property that serves as NEPSI’s headquarters (the "Acquisition"). NEPSI is a U.S.-based global provider of medium-voltage metal-enclosed power capacitor banks and harmonic filter banks for use on electric power systems.  As a result of this transaction, NEPSI became a wholly-owned subsidiary and will be operated by our Grid business segment.

[0001437749-21-001877:mdna:13]
The NEPSI purchase price was $26.0 million in cash on hand, including cash from the settlement of our $25 million certificate of deposit during the three months ended September 30, 2020, and 873,657 restricted shares of our common stock.  As part of the transaction, in the future, the selling stockholders may receive up to an additional 1,000,000 million restricted shares of our common stock upon the achievement of certain specified future revenue objectives during varying periods of up to four years after the closing.

[0001437749-21-001877:mdna:14]
On October 26, 2020, we completed the Offering of 3,670,000 shares of our common stock at a public offering price of $15.00 per share. We received net proceeds of approximately $51.5 million after deducting underwriting discounts and commissions and offering expenses.  See Note 1, “Nature of the Business and Operations and Liquidity,” for further information about this offering.

[0001437749-21-001877:mdna:15]
[same as prior period, unchanged from 0001437749-20-022522:mdna:15]

[0001437749-21-001877:mdna:16]
[same as prior period, unchanged from 0001437749-20-022522:mdna:16]

[0001437749-21-001877:mdna:17]
[same as prior period, unchanged from 0001437749-20-022522:mdna:17]

[0001437749-21-001877:mdna:18]
[same as prior period, unchanged from 0001437749-20-022522:mdna:18]

[0001437749-21-001877:mdna:19]
[same as prior period, unchanged from 0001437749-20-022522:mdna:19]

[0001437749-21-001877:mdna:20]
Three and nine months ended December 31, 2020 compared to the three and nine months ended December 31, 2019

[0001437749-21-001877:mdna:21]
[same as prior period, unchanged from 0001437749-20-022522:mdna:21]

[0001437749-21-001877:mdna:22]
Total revenues increased 32% and 44% to $23.6 million and $66.0 million for the three and nine months ended December 31, 2020, respectively, compared to $17.9 million and $45.7 million for the three and nine months ended December 31, 2019, respectively.  Our revenues are summarized as follows (in thousands):

[0001437749-21-001877:mdna:23]
|  |  | Three Months Ended December 31, |  |  | Nine Months Ended December 31, |  |
|  |  | 2020 |  |  | 2019 |  |  | 2020 |  |  | 2019 |  |
| Revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Grid |  | $ | 17,086 |  |  | $ | 15,232 |  |  | $ | 51,149 |  |  | $ | 36,577 |  |
| Wind |  |  | 6,546 |  |  |  | 2,683 |  |  |  | 14,812 |  |  |  | 9,120 |  |
| Total |  | $ | 23,632 |  |  | $ | 17,915 |  |  | $ | 65,961 |  |  | $ | 45,697 |  |

[0001437749-21-001877:mdna:24]
Our Grid business unit accounted for 72% and 78% of total revenues for the three and nine months ended December 31, 2020, respectively, compared to 85% and 80% for the three and nine months ended December 31, 2019, respectively. Our Grid business unit revenues increased 12% and 40% to $17.1 million and $51.1 million in the three and nine months ended December 31, 2020, respectively, from $15.2 million and $36.6 million in the three and nine months ended December 31, 2019, respectively.  Grid business unit revenue in the three months ended December 31, 2020 was driven by the acquisition of NEPSI and its accompanying revenue and stronger ship protection systems revenue.  Grid business unit revenue in the nine months ended December 31, 2020 was driven by stronger D-VAR, VVO and ship protection systems revenue as well as the acquisition of NEPSI.

[0001437749-21-001877:mdna:25]
Our Wind business unit accounted for 28% and 22% of total revenues for the three and nine months ended December 31, 2020, respectively, compared to 15% and 20% for the three and nine months ended December 31, 2019, respectively. Revenues in the Wind business unit increased 144% and 62% to $6.5 million and $14.8 million in the three and nine months ended December 31, 2020, from $2.7 million and $9.1 million in the three and nine months ended December 31, 2019. The increase in the three months ending December 31, 2020 was driven by increased shipments of electrical control systems ("ECS") to Inox.   The increase in the nine months ending December 31, 2020 was due to increased shipments of ECS to Inox and an increase in spares revenue.  As further described in Note 1 “Nature of the Business and Operations and Liquidity,” Inox was delinquent on its obligations to post letters of credit for sets of ECS that Inox has agreed to purchase under the terms of the supply contract, and on May 29, 2020, we sent written notice to Inox notifying Inox of its default under the supply contract due to Inox’s failure to post letters of credit in the amount of €6.0 million for the payment of ECS that Inox is obligated to purchase under the terms of the supply contract. On October 1, 2020, Inox delivered approved letters of credit for payment of the remaining ECS that Inox had been obligated to purchase under the terms of the Supply Contract and cured the default set forth in the May 29, 2020 default notice.  Despite curing the default, Inox’s ability to perform under the supply contract has been and may continue in the future to be hampered by the prolonged impacts of the COVID-19 pandemic. Inox has been active in the new central and state government auction regime in India and has a cumulative order book of over 1.4 GW.  However, we cannot predict if and how successful Inox will be in executing on these orders or in obtaining new orders under the new central and state auction regime. Any failure by Inox to succeed under this regime, or any delay in Inox’s ability to deliver its wind turbines, could result in fewer ECS shipments to Inox.

[0001437749-21-001877:mdna:26]
[same as prior period, unchanged from 0001437749-20-022522:mdna:26]

[0001437749-21-001877:mdna:27]
Cost of revenues increased by 20% and 33% to $19.7 million and $51.4 million for the three and nine months ended December 31, 2020, compared to $16.3 million and $38.8 million for the three and nine months ended December 31, 2019. Gross margin was 17% and 22% for the three and nine months ended December 31, 2020, compared to 9% and 15% for the three and nine months ended December 31, 2019.  The increase in gross margin in the three and nine months ended December 31, 2020 was due to higher revenue and a more favorable product mix.  Cost of revenues includes amortization expense of $0.3 million in the three and nine months ended December 31, 2020 as a result of the NEPSI acquired backlog intangible asset.  In addition, a fair value purchase adjustment of approximately $1.0 million for the step-up basis assigned to acquired inventory, to properly reflect the fair value in purchase accounting, was charged to cost of revenues in the three and nine months ended December 31, 2020. The step up was assigned to acquired work-in-progress and finished goods inventory that was completely delivered in the three and nine months period ended December 31, 2020.

[0001437749-21-001877:mdna:28]
[same as prior period, unchanged from 0001437749-20-022522:mdna:28]

[0001437749-21-001877:mdna:29]
[same as prior period, unchanged from 0001437749-20-022522:mdna:29]

[0001437749-21-001877:mdna:30]
Research and development ("R&D") expenses increased 48% in the three months ended December 31, 2020 to $3.0 million from $2.0 million in the three months ended December 31, 2019.  The increase in R&D expense was due to higher overall compensation expense and less allocation of expenses to cost of goods sold for revenue generating projects in the three months ended December 31, 2020 compared to the three months ended December 31, 2019.  Research and development expenses increased 19% in the nine months ended December 31, 2020 to $8.2 million from $6.9 million in the nine months ended December 31, 2019. The increase in R&D expense in the nine month period was due to higher overall compensation expense and less allocation of expenses to cost of goods sold for revenue generating projects than in the prior year period.

[0001437749-21-001877:mdna:31]
[same as prior period, unchanged from 0001437749-20-022522:mdna:31]

[0001437749-21-001877:mdna:32]
Selling, general and administrative ("SG&A") expenses increased 17% in the three months ended December 31, 2020 to $7.1 million from $6.1 million in the three months ended December 31, 2019. The increase in SG&A expense in the three months ended December 31, 2020 was due to higher overall compensation expense, including stock compensation, than in the prior year period.  SG&A expenses increased 11% to $18.6 million in the nine months ended December 31, 2020 compared to $16.7 million in the nine months ended December 31, 2019. The increase in SG&A expense in the nine months ended December 31, 2020 was due to higher overall compensation expense, including stock compensation, than in the prior year period.

[0001437749-21-001877:mdna:33]
[same as prior period, unchanged from 0001437749-20-022522:mdna:33]

[0001437749-21-001877:mdna:34]
We recorded amortization expense related to our core technology and know-how, customer relationships, and other intangible assets of $0.4 million and $0.1 million in the three month periods ended December 31, 2020 and 2019, respectively, and $0.6 million and $0.3 million in the nine month periods ended December 31, 2020 and 2019 respectively.  The increases in amortization expense in both periods are primarily a result of the acquisition of NEPSI.

[0001437749-21-001877:mdna:35]
Change in fair value of contingent consideration

[0001437749-21-001877:mdna:36]
The change in fair value of our contingent consideration for the earnout payment on the NEPSI Acquisition resulted in a loss of $2.7 million in both the three and nine months ended December 31, 2020. The change in the fair value was primarily driven by the change in our stock price, which is a key valuation metric.

[0001437749-21-001877:mdna:37]
[same as prior period, unchanged from 0001437749-20-022522:mdna:35]

[0001437749-21-001877:mdna:38]
[same as prior period, unchanged from 0001437749-20-022522:mdna:36]

[0001437749-21-001877:mdna:39]
|  |  | Three Months Ended December 31, |  |  | Nine Months Ended December 31, |  |
|  |  | 2020 |  |  | 2019 |  |  | 2020 |  |  | 2019 |  |
| Operating profit (loss): |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Grid |  | $ | (5,826 | ) |  | $ | (3,732 | ) |  | $ | (8,388 | ) |  | $ | (9,723 | ) |
| Wind |  |  | 147 |  |  |  | (2,297 | ) |  |  | (1,956 | ) |  |  | (6,015 | ) |
| Unallocated corporate expenses |  |  | (3,579 | ) |  |  | (590 | ) |  |  | (5,337 | ) |  |  | (1,236 | ) |
| Total |  | $ | (9,258 | ) |  | $ | (6,619 | ) |  | $ | (15,681 | ) |  | $ | (16,974 | ) |

[0001437749-21-001877:mdna:40]
Our Grid segment generated operating losses of $5.8 million and $8.4 million in the three and nine months ended December 31, 2020, compared to $3.7 million and $9.7 million in the three and nine months ended December 31, 2019. The increase in the Grid business unit operating loss in the three months ended December 31, 2020 was due a less favorable product mix and the impact of the purchase accounting adjustments recorded as part of the NEPSI Acquisition including the inventory step up charge noted above and an adjustment to revenue of $0.3 million less than the contract value, for recognition of the fair value adjustment that reduced acquired customer deposits to properly reflect pre-acquisition activities.  The decrease in the Grid business unit operating loss in the nine months ended December 31, 2020 was due to higher revenues and a more favorable product mix.

[0001437749-21-001877:mdna:41]
Our Wind segment generated an operating profit of $0.1 million and an operating loss of $2.0 million in the three and nine months ended December 31, 2020, compared to operating losses of $2.3 million and $6.0 million in the three and nine months ended December 31, 2019. The decrease in the Wind business unit operating loss in both periods was due to higher revenues.

[0001437749-21-001877:mdna:42]
Unallocated corporate expenses consist of a loss on contingent consideration of $2.7 million in both the three and nine months ended December 31, 2020. Additionally, unallocated corporate expenses consisted of stock-based compensation expense of $0.8 million and $0.6 million in the three months ended December 31, 2020 and 2019, respectively.  Unallocated corporate expenses consisted of stock-based compensation expense of $2.6 million and $1.2 million in the nine months ended December 31, 2020 and 2019, respectively.

[0001437749-21-001877:mdna:43]
[same as prior period, unchanged from 0001437749-20-022522:mdna:41]

[0001437749-21-001877:mdna:44]
There were no warrants outstanding in the three and nine months ended December 31, 2020. The change in fair value of warrants resulted in gains of $0.6 million and $4.6 million in the three and nine months ended December 31, 2019. The change in the fair value was primarily driven by changes in stock price, which is a key valuation metric.

[0001437749-21-001877:mdna:45]
[same as prior period, unchanged from 0001437749-20-022522:mdna:43]

[0001437749-21-001877:mdna:46]
Interest income, net, was $0.1 million and $0.4 million in the three and nine months ended December 31, 2020, compared to $0.3 million and $1.1 million in the three and nine months ended December 31, 2019. The decreases in interest income in the three and nine months ended December 31, 2020 were related to lower cash balances earning lower interest rates than in the prior periods, as well as interest recorded related to the sale of the Devens facility for the nine months ended December 31, 2019 with no such transaction in the current year.

[0001437749-21-001877:mdna:47]
Other (expense) income, net

[0001437749-21-001877:mdna:48]
Other expense, net, was $0.3 million and $0.9 million in the three and nine months ended December 31, 2020, compared to other expense, net of $0.9 million and other income, net of less than $0.1 million in the three and nine months ended December 31, 2019.  The changes in other expense, net, during both periods was driven by the impacts of fluctuations in foreign currencies during the respective period.

[0001437749-21-001877:mdna:49]
[same as prior period, unchanged from 0001437749-20-022522:mdna:47]

[0001437749-21-001877:mdna:50]
Income tax benefit was $1.5 million and $1.2 in the three and nine months ended December 31, 2020, respectively.  Income tax expense was $0.1 million and less than $0.1 million in the three and nine months ended December 31, 2019, respectively. The decrease in income tax expense in both periods is a result of purchase accounting for the acquired intangible assets and the resulting deferred tax liability in the NEPSI Acquisition.  The Company recorded a deferred tax liability of $1.7 million, primarily for the difference in book and tax basis on the intangibles during the three months ended December 31, 2020. As a result, the Company was able to benefit additional deferred tax assets and therefore released a corresponding valuation allowance of $1.7 million during the three and nine months ended December 31, 2020.

[0001437749-21-001877:mdna:51]
[same as prior period, unchanged from 0001437749-20-022522:mdna:49]

[0001437749-21-001877:mdna:52]
Net loss was $7.9 million and $15.1 million in the three and nine months ended December 31, 2020, compared to $6.8 million and $11.2 million in the three and nine months ended December 31, 2019.  The increases in net loss were driven by the change in fair value of contingent consideration loss in the three and nine months ended December 31, 2020, the gain on fair value of warrants in the prior year period that did not recur in the nine months ended December 31, 2020 as well as the changes discussed above.

[0001437749-21-001877:mdna:53]
[same as prior period, unchanged from 0001437749-20-022522:mdna:51]

[0001437749-21-001877:mdna:54]
[same as prior period, unchanged from 0001437749-20-022522:mdna:52]

[0001437749-21-001877:mdna:55]
We define non-GAAP net loss as net loss before stock-based compensation, amortization of acquisition-related intangibles, acquisition costs, change in fair value of contingent consideration and warrants, and other non-cash or unusual charges.  We believe non-GAAP net loss assists management and investors in comparing our performance across reporting periods on a consistent basis by excluding these non-cash charges and other items that we do not believe are indicative of our core operating performance. In addition, we use non-GAAP net loss as a factor to evaluate the effectiveness of our business strategies. A reconciliation of GAAP to non-GAAP net loss is set forth in the table below (in thousands, except per share data):

[0001437749-21-001877:mdna:56]
|  |  | Three Months Ended December 31, |  |  | Nine Months Ended December 31, |  |
|  |  | 2020 |  |  | 2019 |  |  | 2020 |  |  | 2019 |  |
| Net loss |  | $ | (7,933 | ) |  | $ | (6,845 | ) |  | $ | (15,062 | ) |  | $ | (11,209 | ) |
| Stock-based compensation |  |  | 839 |  |  |  | 590 |  |  |  | 2,597 |  |  |  | 1,236 |  |
| Amortization of acquisition-related intangibles |  |  | 645 |  |  |  | 85 |  |  |  | 886 |  |  |  | 255 |  |
| Acquisition costs |  |  | 313 |  |  |  | — |  |  |  | 313 |  |  |  | — |  |
| Change in fair value of contingent consideration and warrants |  |  | 2,740 |  |  |  | (556 | ) |  |  | 2,740 |  |  |  | (4,648 | ) |
| Non-GAAP net loss |  | $ | (3,395 | ) |  | $ | (6,726 | ) |  | $ | (8,526 | ) |  | $ | (14,366 | ) |
| Non-GAAP net loss per share - basic |  | $ | (0.13 | ) |  | $ | (0.32 | ) |  | $ | (0.37 | ) |  | $ | (0.69 | ) |
| Weighted average shares outstanding - basic |  |  | 25,470 |  |  |  | 21,185 |  |  |  | 23,011 |  |  |  | 20,786 |  |

[0001437749-21-001877:mdna:57]
We incurred non-GAAP net losses of $3.4 million and $8.5 million or $0.13 and $0.37 per share, for the three and nine months ended December 31, 2020, compared to $6.7 million and $14.4 million, or $0.32 and $0.69 per share, for the three and nine months ended December 31, 2019. The decrease in the three and nine month non-GAAP net loss was due to lower operating loss driven by higher revenues and a more favorable product mix.

[0001437749-21-001877:mdna:58]
[same as prior period, unchanged from 0001437749-20-022522:mdna:56]

[0001437749-21-001877:mdna:59]
[same as prior period, unchanged from 0001437749-20-022522:mdna:57]

[0001437749-21-001877:mdna:60]
We have experienced recurring operating losses, and as of December 31, 2020, had an accumulated deficit of $993.7 million.

[0001437749-21-001877:mdna:61]
[same as prior period, unchanged from 0001437749-20-022522:mdna:59]

[0001437749-21-001877:mdna:62]
As described above, on October 1, 2020, we acquired NEPSI. The NEPSI purchase price was $26.0 million in cash, including cash from the settlement of our $25 million certificate of deposit during the three months ended September 30, 2020, and 873,657 restricted shares of our common stock.  As part of the transaction, the selling stockholders may receive up to an additional 1,000,000 restricted shares of our common stock upon the achievement of certain specified revenue objectives in the future.

[0001437749-21-001877:mdna:63]
As described above, on October 26, 2020, we completed an offering of 3,670,000 shares of our common stock at a public offering price of $15.00 per share. We received net proceeds of approximately $51.5 million after deducting underwriting discounts and commissions and offering expenses.  In addition, we had granted the underwriters a 30-day option to purchase up to an additional 550,500 shares of common stock at the public offering price which they did not exercise.

[0001437749-21-001877:mdna:64]
As of December 31, 2020, we had cash, cash equivalents, marketable securities and restricted cash of $84.4 million, compared to $66.1 million as of March 31, 2020, an increase of $18.3 million. As of December 31, 2020, we had approximately $2.8 million of cash, cash equivalents, and restricted cash in foreign bank accounts. Our cash, cash equivalents, marketable securities and restricted cash are summarized as follows (in thousands):

[0001437749-21-001877:mdna:65]
|  |  | December 31, 2020 |  |  | March 31, 2020 |  |
| Cash and cash equivalents |  | $ | 67,909 |  |  | $ | 24,699 |  |
| Marketable securities |  |  | 10,239 |  |  |  | 35,195 |  |
| Restricted cash |  |  | 6,233 |  |  |  | 6,165 |  |
| Total cash, cash equivalents, marketable securities and restricted cash |  | $ | 84,381 |  |  | $ | 66,059 |  |

[0001437749-21-001877:mdna:66]
For the nine months ended December 31, 2020, net cash used in operating activities was $4.9 million, compared to $17.8 million for the nine months ended December 31, 2019.  The decrease in net cash used in operations was due primarily to the overall impact of increased sales activities on the operating accounts in the current year period.

[0001437749-21-001877:mdna:67]
For the nine months ended December 31, 2020, net cash used in investing activities was $2.6 million, compared to net cash used in investing activities of $34.9 million for the nine months ended December 31, 2019. The decrease in net cash used in investing activities was due primarily to the purchase of the $35.0 million certificate of deposit in the nine months ended December 31, 2019 with no such transaction in the current year period and the sale of the $25.0 million certificate of deposit in the nine months ended December 31, 2020, offset by cash that was used to pay for the Acquisition.

[0001437749-21-001877:mdna:68]
For the nine months ended December 31, 2020, net cash provided by financing activities was $50.6 million compared to net cash provided by financing activities of $5.7 million in the nine months ended December 31, 2019.  The increase in net cash provided by financing activities was due primarily to the proceeds from the October 2020 offering.

[0001437749-21-001877:mdna:69]
As of December 31, 2020, we had $5.6 million of restricted cash included in long-term assets and $0.6 million of restricted cash included in current assets.  These amounts included in restricted cash primarily represent deposits to secure letters of credit for various supply contracts and long-term projects, including the irrevocable letter of credit in the amount of $5.0 million to secure certain of our obligations under the Subcontract Agreement with ComEd. These deposits are held in interest bearing accounts.

[0001437749-21-001877:mdna:70]
We believe we have sufficient available liquidity to fund our operations and capital expenditures for the next twelve months. In addition, we may seek to raise additional capital, which could be in the form of loans, convertible debt or equity, to fund our operating requirements and capital expenditures. We have no outstanding warrants as of December 31, 2020. Our liquidity is highly dependent on our ability to increase revenues, including our ability to collect revenues under our agreements with Inox, control our operating costs, and raise additional capital, if necessary. There can be no assurance that we will be able to raise additional capital on favorable terms or at all, or execute on any other means of improving our liquidity as described above.  Additionally, the impact of the COVID-19 pandemic on the global financial markets may reduce our ability to raise additional capital, if necessary, which could negatively impact our liquidity.

[0001437749-21-001877:mdna:71]
[same as prior period, unchanged from 0001437749-20-022522:mdna:69]

[0001437749-21-001877:mdna:72]
[same as prior period, unchanged from 0001437749-20-022522:mdna:70]

[0001437749-21-001877:mdna:73]
|  |  | Nine months ended |  |
|  |  | December 31, 2020 |  |  | December 31, 2019 |  |
| Operating cash flow |  | $ | (4,871 | ) |  | $ | (17,779 | ) |
| Sinovel settlement (net of legal fees and expenses) |  |  | — |  |  |  | 1,000 |  |
| Tax effect of adjustments |  |  | — |  |  |  | 2,724 |  |
| Non-GAAP operating cash flow |  | $ | (4,871 | ) |  | $ | (14,055 | ) |

[0001437749-21-001877:mdna:74]
Legal Proceedings

[0001437749-21-001877:mdna:75]
We are involved in legal and administrative proceedings and claims of various types. See Part II, Item 1, “Legal Proceedings,” for additional information. We record a liability in our consolidated financial statements for these matters when a loss is known or considered probable and the amount can be reasonably estimated. We review these estimates each accounting period as additional information is known and adjust the loss provision when appropriate. If a matter is both probable to result in liability and the amounts of loss can be reasonably estimated, we estimate and disclose the possible loss or range of loss to the extent necessary to make the consolidated financial statements not misleading. If the loss is not probable or cannot be reasonably estimated, a liability is not recorded in our consolidated financial statements.

[0001437749-21-001877:mdna:76]
[same as prior period, unchanged from 0001437749-20-022522:mdna:74]

[0001437749-21-001877:mdna:77]
[same as prior period, unchanged from 0001437749-20-022522:mdna:75]

[0001437749-21-001877:mdna:78]
[same as prior period, unchanged from 0001437749-20-022522:mdna:76]

[0001437749-21-001877:mdna:79]
[same as prior period, unchanged from 0001437749-20-022522:mdna:77]

[0001437749-21-001877:mdna:80]
[same as prior period, unchanged from 0001437749-20-022522:mdna:78]

[0001437749-21-001877:mdna:81]
In June 2016, the FASB issued ASU 2016-13, Financial Instruments-Credit Losses (Topic 326): Measurement of Credit Losses on Financial Instruments. The amendments in ASU 2016-13 provide more decision-useful information about the expected credit losses on financial instruments and other commitments to extend credit held by a reporting entity at each reporting date. The ASU is effective for annual reporting periods beginning after December 15, 2019, including interim periods within that year.  Following the release of ASU 2019-10 in November 2019, the new effective date, as long as the Company remains a smaller reporting company, would be annual reporting periods beginning after December 15, 2022.   We are currently evaluating the impact, if any, that the adoption of ASU 2016-13 may have on our consolidated financial statements.

[0001437749-21-001877:mdna:82]
In August 2018, the FASB issued ASU 2018-13, Fair Value Measurement (Topic 820): Changes to the Disclosure Requirements for Fair Value Measurement. The amendments in ASU 2018-13 provide for increased effectiveness of the disclosures made around fair value measurements while including consideration for costs and benefits. The ASU is effective for annual reporting periods beginning after December 15, 2019, including interim periods within those periods.  As of April 1, 2020, we have adopted ASU 2018-13 and noted no material impact on our consolidated financial statements.

[0001437749-21-001877:mdna:83]
In December 2019, the FASB issued ASU 2019-12, Income Taxes (Topic 740): Simplifying the Accounting for Income Taxes. The amendments in ASU 2019-12 provide for simplified accounting to several income tax situations and removal of certain accounting exceptions. The ASU is effective for annual reporting periods beginning after December 15, 2020, including interim periods within those periods. We do not expect the impact of the adoption of ASU 2019-12 to be material to our consolidated financial statements.

[0001437749-21-001877:mdna:84]
We do not believe that, outside of those disclosed here, there are any other recently issued accounting pronouncements that will have a material impact on our consolidated financial statements.
