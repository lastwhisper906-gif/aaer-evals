# AMSC 10-Q controls and the auditor's report


## item_4_controls

[0001437749-21-001877:item_4_controls:1]
| ITEM 4. | CONTROLS AND PROCEDURES |

[0001437749-21-001877:item_4_controls:2]
Evaluation of Disclosure Controls and Procedures

[0001437749-21-001877:item_4_controls:3]
Our management, with the participation of our Chief Executive Officer and Chief Financial Officer, evaluated the effectiveness of our disclosure controls and procedures as of December 31, 2020. The term “disclosure controls and procedures,” as defined in Rules 13a-15(e) and 15d-15(e) under the Exchange Act, means controls and other procedures of a company that are designed to ensure that information required to be disclosed by a company in the reports that it files or submits under the Exchange Act is recorded, processed, summarized and reported within the time periods specified in the SEC’s rules and forms. Disclosure controls and procedures include, without limitation, controls and procedures designed to ensure that information required to be disclosed by a company in the reports that it files or submits under the Exchange Act is accumulated and communicated to the Company’s management, including its principal executive and principal financial officers, as appropriate to allow timely decisions regarding required disclosure. Management recognizes that any controls and procedures, no matter how well designed and operated, can provide only reasonable assurance of achieving their objectives and management necessarily applies its judgment in evaluating the cost-benefit relationship of possible controls and procedures.

[0001437749-21-001877:item_4_controls:4]
In making this evaluation, our management considered the material weakness in our internal control over financial reporting described below. Based on such evaluation, our Chief Executive Officer and Chief Financial Officer have concluded that our disclosure controls and procedures were not effective at the reasonable assurance level as of such date.

[0001437749-21-001877:item_4_controls:5]
Material Weakness

[0001437749-21-001877:item_4_controls:6]
A material weakness is a deficiency, or a combination of deficiencies, in internal control over financial reporting such that there is a reasonable possibility that a material misstatement of the annual or interim financial statements will not be prevented or detected on a timely basis. During the third quarter of fiscal 2020, in connection with the preparation of our financial statements for this Quarterly Report on Form 10-Q, management identified the following material weakness: we did not maintain proper controls, processes and procedures  over the initial purchase accounting and the continuing fair value accounting associated with the NEPSI Acquisition that were adequately designed, documented and executed to support the accurate and timely reporting of our financial results regarding the initial purchase accounting and the continuing fair value accounting associated with the NEPSI Acquisition. Specifically, the modeling assumptions and the calculation performed by our third-party valuation specialist as it relates to fair value accounting reporting for contingent consideration on the purchase accounting for the NEPSI Acquisition included errors resulting in a $1.3 million overstatement in both the fair value of the earnout payment and the preliminary estimated purchase price paid to NEPSI, that we failed to detect, which were reflected in Exhibit 99.3 of our Form 8-K/A filed with the Securities and Exchange Commission (“SEC”) on December 14, 2020.  As a result, we made post-closing adjustments necessary to properly reflect the fair value of the contingent consideration liability in the financial statements included in this Quarterly Report on Form 10-Q for the period ended December 31, 2020.

[0001437749-21-001877:item_4_controls:7]
Notwithstanding the material weakness, we believe that our financial statements contained in this Quarterly Report on Form 10-Q fairly present our financial position, results of operations and cash flows for the periods covered by this report in all material respects.

[0001437749-21-001877:item_4_controls:8]
Our management, with the oversight of our audit committee, has initiated steps and plans to take additional measures to remediate the underlying causes of the material weakness, which we currently believe will be primarily through the development and implementation of new procedures, policies, processes, including revising precision level of management review controls and gaining additional assurance regarding timely completion of our outside service providers’ quality control procedures. It is possible that we may determine that additional remediation steps will be necessary in the future.

[0001437749-21-001877:item_4_controls:9]
Changes in Internal Control over Financial Reporting

[0001437749-21-001877:item_4_controls:10]
Other than the material weakness described above, there were no changes in our internal control over financial reporting (as defined in Rules 13a-15(f) and 15d-15(f) under the Exchange Act) during the quarter ended December 31, 2020 that have materially affected, or are reasonably likely to materially affect, our internal control over financial reporting.

[0001437749-21-001877:item_4_controls:11]
28
