# AMSC 8-K — 0001193125-13-323082 filed 2013-08-07

## item codes, every 8-K on or before 2013-08-07

- 2013-08-07 0001193125-13-323082 — 2.02, 9.01
- 2013-08-02 0001193125-13-317278 — 5.02, 5.07
- 2013-06-14 0001193125-13-258758 — 2.02, 9.01
- 2013-04-01 0001193125-13-136714 — 2.02, 8.01, 9.01
- 2013-02-20 0001193125-13-067218 — 5.02, 9.01
- 2013-02-14 0001193125-13-060131 — 1.01, 9.01
- 2013-02-11 0001193125-13-048784 — 2.02, 9.01
- 2013-01-08 0001193125-13-006861 — 5.02, 9.01
- 2012-12-21 0001193125-12-511592 — 1.01, 2.03, 3.02, 9.01
- 2012-11-28 0001193125-12-483317 — 2.05, 5.02, 7.01, 9.01
- 2012-11-06 0001193125-12-453359 — 2.02, 9.01
- 2012-08-02 0001193125-12-330534 — 2.02, 9.01
- 2012-07-27 0001193125-12-318790 — 5.02, 5.07, 9.01
- 2012-06-06 0001193125-12-261030 — 1.01, 2.02, 2.03, 3.02, 5.02, 9.01
- 2012-05-09 0001193125-12-222210 — 5.02
- 2012-04-20 0001193125-12-172045 — 8.01
- 2012-04-13 0001193125-12-162694 — 2.02, 8.01, 9.01
- 2012-04-04 0001193125-12-149102 — 1.01, 2.02, 2.03, 3.02, 9.01
- 2012-02-09 0001193125-12-048009 — 2.02, 9.01
- 2012-02-06 0001193125-12-041344 — 5.07 — amendment of 0000950123-11-102495
- 2011-12-08 0000950123-11-102495 — 5.07
- 2011-11-29 0000950123-11-100822 — 2.05
- 2011-11-09 0000950123-11-096775 — 2.02, 9.01
- 2011-10-31 0000950123-11-093390 — 1.02, 9.01
- 2011-10-07 0000950123-11-089221 — 8.01
- 2011-10-03 0000950123-11-088315 — 7.01
- 2011-09-23 0000950123-11-086288 — 2.02, 9.01
- 2011-09-15 0000950123-11-084585 — 7.01
- 2011-09-06 0000950123-11-082736 — 7.01
- 2011-08-18 0000950123-11-078526 — 3.01, 7.01, 9.01
- 2011-08-11 0000950123-11-075905 — 5.02
- 2011-08-11 0000950123-11-075904 — 2.02, 2.05, 9.01
- 2011-07-11 0000950123-11-064934 — 2.02, 4.02, 9.01
- 2011-06-30 0000950123-11-063287 — 1.01, 3.02, 9.01
- 2011-06-21 0000950123-11-060491 — 3.01, 7.01, 9.01
- 2011-06-13 0000950123-11-058656 — 1.01, 9.01
- 2011-05-24 0000950123-11-053517 — 5.02, 9.01
- 2011-04-05 0001299933-11-001020 — 2.02, 9.01
- 2011-03-15 0000950123-11-025580 — 5.02
- 2011-03-14 0000950123-11-025205 — 1.01, 3.02, 9.01
- 2011-02-01 0001299933-11-000333 — 2.02, 9.01
- 2010-11-12 0000950123-10-104604 — 8.01, 9.01
- 2010-11-08 0000950123-10-102424 — 8.01, 9.01
- 2010-11-02 0001299933-10-003878 — 2.02, 9.01
- 2010-09-15 0000950123-10-086373 — 1.01, 9.01 — amendment, the index does not say of what
- 2010-08-06 0000950123-10-074362 — 5.07
- 2010-07-29 0001299933-10-002860 — 2.02, 9.01
- 2010-05-17 0000950123-10-050424 — 1.01, 9.01
- 2010-05-14 0001299933-10-001972 — 5.02
- 2010-05-13 0001299933-10-001943 — 2.02, 9.01
- 2010-02-08 0001299933-10-000506 — 8.01
- 2010-02-02 0001299933-10-000386 — 2.02, 9.01
- 2009-12-15 0001299933-09-004928 — 5.02
- 2009-10-29 0001299933-09-004267 — 2.02, 9.01
- 2009-08-12 0001193125-09-173026 — 5.02, 9.01
- 2009-07-30 0001193125-09-158842 — 1.01, 2.02, 9.01
- 2009-05-15 0001193125-09-113158 — 5.02
- 2009-05-14 0001193125-09-110619 — 2.02, 9.01
- 2009-04-20 0001193125-09-082590 — 5.02
- 2009-02-03 0001193125-09-016992 — 2.02, 9.01
- 2009-01-22 0001193125-09-009777 — 2.02, 9.01
- 2008-11-04 0001193125-08-223730 — 2.02, 9.01
- 2008-08-11 0001193125-08-173616 — 8.01
- 2008-08-07 0001193125-08-170325 — 8.01
- 2008-08-05 0001193125-08-165888 — 2.02, 9.01
- 2008-06-11 0001193125-08-132049 — 1.01, 9.01
- 2008-05-20 0001193125-08-119372 — 5.02, 9.01
- 2008-05-08 0001193125-08-107052 — 2.02, 9.01
- 2008-01-31 0001193125-08-016233 — 2.02, 9.01
- 2008-01-30 0001193125-08-015494 — 5.03, 9.01
- 2007-11-01 0001193125-07-231866 — 2.02, 9.01
- 2007-10-31 0001193125-07-231225 — 2.05
- 2007-10-29 0001193125-07-228284 — 5.03, 9.01
- 2007-09-27 0001193125-07-208950 — 5.02
- 2007-08-09 0001193125-07-176553 — 2.02, 9.01
- 2007-08-07 0001193125-07-173829 — 1.01, 5.02, 9.01
- 2007-07-02 0001193125-07-148303 — 5.02, 9.01
- 2007-06-20 0001193125-07-139068 — 8.01, 9.01
- 2007-06-14 0001193125-07-135550 — 9.01 — amendment of 0001193125-07-005297
- 2007-06-14 0001193125-07-135340 — 5.02
- 2007-05-24 0001193125-07-122148 — 2.02, 9.01
- 2007-03-30 0001193125-07-070154 — 2.05, 9.01
- 2007-03-23 0001193125-07-062978 — 9.01 — amendment of 0001193125-07-005297
- 2007-02-01 0001193125-07-017883 — 2.02, 9.01
- 2007-01-11 0001193125-07-005297 — 2.01, 9.01
- 2006-12-05 0001181431-06-067500 — 5.02
- 2006-11-29 0001193125-06-243360 — 1.01, 3.02, 9.01
- 2006-11-02 0001193125-06-221464 — 2.02, 9.01
- 2006-09-21 0001193125-06-194526 — 5.02
- 2006-08-08 0001193125-06-164819 — 2.02, 9.01
- 2006-08-02 0001193125-06-159113 — 1.01, 9.01
- 2006-07-28 0001193125-06-156172 — 1.01
- 2006-06-26 0001193125-06-135913 — 1.01, 3.03, 9.01
- 2006-05-11 0001193125-06-108489 — 2.02, 9.01
- 2006-05-05 0001193125-06-102270 — 1.01, 9.01
- 2006-05-01 0001193125-06-094941 — 2.02, 2.06, 9.01
- 2006-02-24 0001193125-06-038281 — 5.02, 9.01
- 2006-02-02 0001181431-06-007665 — 2.02, 9.01
- 2005-11-09 0001181431-05-060304 — 2.02, 9.01
- 2005-08-04 0001181431-05-044420 — 2.02, 9.01
- 2005-07-28 0001193125-05-151272 — 5.02, 9.01
- 2005-06-14 0001193125-05-125148 — 5.02, 9.01
- 2005-05-12 0001181431-05-027410 — 2.02, 9.01
- 2005-05-10 0001193125-05-102795 — 1.01
- 2005-04-05 0001181431-05-020680 — 1.01, 2.02, 3.02, 9.01
- 2005-02-03 0001181431-05-006678 — 2.02, 9.01
- 2004-11-09 0001181431-04-051381 — 2.02, 9.01 — amendment, the index does not say of what
- 2004-11-04 0001181431-04-050706 — 2.02, 9.01
- 2004-10-15 0001193125-04-172458 — 1.01, 9.01
- 2004-08-05 0001193125-04-132162 — 12
- 2004-05-13 0001193125-04-086853 — 12
- 2004-02-05 0001193125-04-015060 — 12
- 2003-11-06 0001193125-03-074000 — 12
- 2003-09-26 0001193125-03-054624 — 5
- 2003-08-06 0001193125-03-029666 — 12
- 2003-05-14 0000927016-03-002619 — 9
- 2002-12-31 0000927016-02-006114 — 5
- 2000-01-24 0000927016-00-000150 — 5, 7
- 1998-11-02 0000950135-98-005625 — 5, 7
- 1998-03-24 0000950135-98-001743 — 5, 7
- 1997-09-05 0000950135-97-003729 — 5, 7
- 1997-06-23 0000950135-97-002785 — 1 — amendment of 0000950135-97-001972
- 1997-04-23 0000950135-97-001972 — 2, 7

## late-filing notifications on or before 2013-08-07

- 2011-08-10 0000950123-11-075677 — NT 10-Q, for the period ended 2011-06-30
- 2011-05-31 0000950123-11-055465 — NT 10-K, for the period ended 2011-03-31

## item 2.02 — earnings release, exhibit 99.1

[0001193125-13-323082:8k_2_02:1]
EX-99.1
2
d581000dex991.htm
EX-99.1

[0001193125-13-323082:8k_2_02:2]
EX-99.1

[0001193125-13-323082:8k_2_02:3]
Exhibit 99.1

[0001193125-13-323082:8k_2_02:4]
AMSC Reports First Quarter 2013 Financial Results and Provides Business Outlook

[0001193125-13-323082:8k_2_02:5]
Grows Revenue 13% and Narrows Net Loss 47% Sequentially

[0001193125-13-323082:8k_2_02:6]
Management to Host Conference Call Today at 10 a.m. ET

[0001193125-13-323082:8k_2_02:7]
Devens, MA –
August 7, 2013 – AMSC (NASDAQ: AMSC), a global solutions provider serving wind and power grid industry leaders, today reported financial results for its first quarter ended June 30, 2013.

[0001193125-13-323082:8k_2_02:8]
Revenues for the first quarter of fiscal 2013 were $23.1 million, compared with $28.7 million for the same period of fiscal 2012 and $20.4 million for
the fourth quarter of fiscal 2012. The 13% improvement from the fourth quarter of fiscal 2012 was driven by higher revenues from the Company’s Wind segment.

[0001193125-13-323082:8k_2_02:9]
AMSC’s net loss for the first quarter of fiscal 2013 was $10.5 million, or $0.18 per share, compared with $10.3 million, or $0.20 per share, for the same period of fiscal 2012 and $19.8 million, or
$0.35 per share, for the fourth quarter of fiscal 2012.

[0001193125-13-323082:8k_2_02:10]
The Company’s non-GAAP net loss for the first quarter of fiscal 2013 was $8.1
million, or $0.14 per share, compared with a non-GAAP net loss of $11.0 million, or $0.21 per share, for the first quarter of fiscal 2012 and $11.8 million, or $0.21 per share, for the fourth quarter of fiscal 2012. Please refer to the financial
table below for a reconciliation of GAAP to non-GAAP results.

[0001193125-13-323082:8k_2_02:11]
Cash, cash equivalents, and restricted cash at June 30, 2013 totaled $39.5
million, compared with $50.2 million as of March 31, 2013.

[0001193125-13-323082:8k_2_02:12]
For the second fiscal quarter ending September 30, 2013, AMSC expects
that its revenues will exceed $23 million and that its net loss will be less than $17 million, or $0.28 per share. This forecast excludes any impact from mark-to-market adjustments related to the Company’s derivative liability and warrants.
AMSC expects that its non-GAAP net loss for its second quarter of fiscal 2013 will be less than $12 million, or $0.20 per share. The Company’s net loss and non-GAAP net loss are expected to be impacted by a less favorable mix of revenues in the
second quarter compared with the first quarter of fiscal 2013. AMSC expects to have more than $30 million in cash, cash equivalents and restricted cash on September 30, 2013.

[0001193125-13-323082:8k_2_02:13]
“AMSC continued to execute to plan for the first fiscal quarter, growing revenues by 13% and reducing net loss by 47% on a sequential basis from the fourth quarter of fiscal 2012,” said Daniel
P. McGahn, AMSC President and CEO. “In fiscal 2013, we remain focused on effectively managing our cash position, while driving profitable revenue growth. We are reaffirming our guidance that we expect annual revenue

[0001193125-13-323082:8k_2_02:14]
| AMSC Reports Q1 Results |  | Page 2 |

[0001193125-13-323082:8k_2_02:15]
growth of at least 25% in fiscal 2013 over fiscal 2012. We have a solid presence in several established markets and continue to seek opportunities to enter emerging markets where we see
significant opportunity.”

[0001193125-13-323082:8k_2_02:16]
Conference Call Reminder

[0001193125-13-323082:8k_2_02:17]
In conjunction with this announcement, AMSC management will participate in a conference call with investors beginning at 10:00 a.m. Eastern Time today to discuss the Company’s results and its
business outlook. To listen to the live or archived conference call webcast please visit the “Investors” section of the Company’s website at http://www.amsc.com/investors. The live call also can be accessed by dialing
785-830-7991 and using conference ID 6217879.

[0001193125-13-323082:8k_2_02:18]
About AMSC (NASDAQ: AMSC)

[0001193125-13-323082:8k_2_02:19]
AMSC generates the ideas, technologies and solutions that meet the world’s demand for smarter, cleaner … better energy™. Through its
Windtec™ Solutions, AMSC provides wind turbine electronic controls and systems, designs and engineering services that reduce the cost of wind energy. Through its Gridtec™ Solutions, AMSC provides the engineering planning services and
advanced grid systems that optimize network reliability, efficiency and performance. The company’s solutions are now powering gigawatts of renewable energy globally and are enhancing the performance and reliability of power networks in more
than a dozen countries. Founded in 1987, AMSC is headquartered near Boston, Massachusetts with operations in Asia, Australia, Europe and North America. For more information, please visit www.amsc.com.

[0001193125-13-323082:8k_2_02:20]
AMSC, Windtec, Gridtec, and Smarter, Cleaner … Better Energy are trademarks or registered trademarks of American Superconductor Corporation. All
other brand names, product names, trademarks or service marks belong to their respective holders.

[0001193125-13-323082:8k_2_02:21]
There are a number of important factors that
could materially impact the value of our common stock or cause actual results to differ materially from those indicated by such forward-looking statements. Such factors include: We have experienced recurring operating losses and recurring negative
cash flows from operations which raise substantial doubt about our ability to continue as a going concern. This substantial doubt has resulted in a qualified opinion from our auditors with an explanatory paragraph regarding our ability to continue
as a going concern. We believe this opinion may have an adverse effect on our customer and supplier relationships; our success in addressing the wind energy market is dependent on the manufacturers that license our designs; we may not realize all of
the sales expected from our backlog of orders and contracts; our business and operations would be adversely impacted in the event of a failure or security breach of our information technology infrastructure; our success is dependent upon attracting
and retaining qualified personnel and our inability to do so could significantly damage our business and prospects; we rely upon third-party suppliers for the components and subassemblies of many of our Wind and Grid products, making us vulnerable
to supply shortages and price fluctuations, which could harm our business; many of our revenue opportunities are dependent upon subcontractors and other business collaborators; if we fail to implement our business strategy successfully, our
financial performance could be harmed; problems with product quality or product performance may cause us to incur warranty expenses and may damage our market reputation and prevent us from achieving increased sales and market share; our contracts
with the U. S. government are subject to audit, modification or termination by the U. S. government and include certain other provisions in favor of the government; the continued funding of such contracts remains subject to annual congressional
appropriation which, if not approved, could reduce our revenue and lower or eliminate our profit; we may acquire additional complementary businesses or technologies, which may require us to incur substantial costs for which we may never

[0001193125-13-323082:8k_2_02:22]
| AMSC Reports Q1 Results |  | Page 3 |

[0001193125-13-323082:8k_2_02:23]
realize the anticipated benefits; many of our customers outside of the United States are, either directly or indirectly, related to governmental entities, and we could be adversely affected by
violations of the United States Foreign Corrupt Practices Act and similar worldwide anti-bribery laws outside the United States; we have limited experience in marketing and selling our superconductor products and system-level solutions, and our
failure to effectively market and sell our products and solutions could lower our revenue and cash flow; we have experienced recurring losses from operations and negative operating cash flow; these factors raise substantial doubt regarding our
ability to continue as a going concern; we have a history of operating losses, and we may incur additional losses in the future; our operating results may fluctuate significantly from quarter to quarter and may fall below expectations in any
particular fiscal quarter; we may require additional funding in the future and may be unable to raise capital when needed; our debt obligations include certain covenants and other events of default;. Should we not comply with the covenants or incur
an event of default, we may be required to repay our debt obligations in cash, which could have an adverse effect on our liquidity; if we fail to maintain proper and effective internal controls over financial reporting, our ability to produce
accurate and timely financial statements could be impaired and may lead investors and other users to lose confidence in our financial data; we may be required to issue performance bonds or provide letters of credit, which restricts our ability to
access any cash used as collateral for the bonds or letters of credit; changes in exchange rates could adversely affect our results from operations; growth of the wind energy market depends largely on the availability and size of government
subsidies and economic incentives; we depend on sales to customers in China, and global conditions could negatively affect our operating results or limit our ability to expand our operations outside of China; changes in China’s political,
social, regulatory and economic environment may affect our financial performance; our products face intense competition, which could limit our ability to acquire or retain customers; our international operations are subject to risks that we do not
face in the United States, which could have an adverse effect on our operating results; adverse changes in domestic and global economic conditions could adversely affect our operating results; we may be unable to adequately prevent disclosure of
trade secrets and other proprietary information; our patents may not provide meaningful protection for our technology, which could result in us losing some or all of our market position; the commercial uses of superconductor products are limited
today, and a widespread commercial market for our products may not develop; there are a number of technological challenges that must be successfully addressed before our superconductor products can gain widespread commercial acceptance, and our
inability to address such technological challenges could adversely affect our ability to acquire customers for our products; we have not manufactured our Amperium wire in commercial quantities, and a failure to manufacture our Amperium wire in
commercial quantities at acceptable cost and quality levels would substantially limit our future revenue and profit potential; third parties have or may acquire patents that cover the materials, processes and technologies we use or may use in the
future to manufacture our Amperium products, and our success depends on our ability to license such patents or other proprietary rights; our technology and products could infringe intellectual property rights of others, which may require costly
litigation and, if we are not successful, could cause us to pay substantial damages and disrupt our business; we have filed a demand for arbitration and other lawsuits against our former largest customer, Sinovel, regarding amounts we contend are
overdue. We cannot be certain as to the outcome of these proceedings; we have been named as a party to purported stockholder class actions and stockholder derivative complaints, and we may be named in additional litigation, all of which will require
significant management time and attention, result in significant legal expenses and may result in an unfavorable outcome, which could have a material adverse effect on our business, operating results and financial condition; our 7% convertible note
contains warrants and provisions that could limit our ability to repay the note in shares of common stock and should the note be repaid in stock, shareholders could experience significant dilution; our common stock has experienced, and may continue
to experience, significant market price and volume fluctuations, which may prevent our stockholders from selling our common stock at a profit and could lead to costly litigation against us that could divert our management’s attention; and new
regulations related to conflict-free minerals may force us to incur significant additional expenses. These and the important factors discussed under the caption “Risk Factors” in Part 1. Item 1A of our Form 10-K for the fiscal year
ended March 31, 2013, and our other reports filed with the SEC, among others, could cause actual results to differ materially from those indicated by forward-looking statements made herein and presented elsewhere by management from time to
time. Any such forward-looking statements represent management’s estimates as of the date of this press release. While we may elect to update such forward-looking statements at some point in the future, we disclaim any obligation to do so, even
if subsequent events cause our views to change. These forward-looking statements should not be relied upon as representing our views as of any date subsequent to the date of this press release.

[0001193125-13-323082:8k_2_02:24]
| AMSC Reports Q1 Results |  | Page 4 |

[0001193125-13-323082:8k_2_02:25]
UNAUDITED CONSOLIDATED STATEMENTS OF OPERATIONS

[0001193125-13-323082:8k_2_02:26]
(In thousands, except per share data)

[0001193125-13-323082:8k_2_02:27]
|  |  | Three months endedJune 30, |  |
|  |  | 2013 |  |  | 2012 |  |
| Revenues: |  |  |  |  |  |  |  |  |
| Wind |  | $ | 14,701 |  |  | $ | 16,511 |  |
| Grid |  |  | 8,385 |  |  |  | 12,205 |  |
| Total revenues |  |  | 23,086 |  |  |  | 28,716 |  |
| Cost of revenues |  |  | 17,987 |  |  |  | 16,926 |  |
| Gross profit |  |  | 5,099 |  |  |  | 11,790 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |
| Research and development |  |  | 3,027 |  |  |  | 3,910 |  |
| Selling, general and administrative |  |  | 10,827 |  |  |  | 13,799 |  |
| Restructuring and impairments |  |  | 13 |  |  |  | 128 |  |
| Amortization of acquisition related intangibles |  |  | 82 |  |  |  | 81 |  |
| Total operating expenses |  |  | 13,949 |  |  |  | 17,918 |  |
| Operating loss |  |  | (8,850 | ) |  |  | (6,128 | ) |
| Change in fair value of derivatives and warrants |  |  | 469 |  |  |  | (2,388 | ) |
| Interest expense, net |  |  | (2,111 | ) |  |  | (2,718 | ) |
| Other income, net |  |  | 69 |  |  |  | 123 |  |
| Loss before income tax expense |  |  | (10,423 | ) |  |  | (11,111 | ) |
| Income tax (benefit) expense |  |  | 90 |  |  |  | (836 | ) |
| Net loss |  | $ | (10,513 | ) |  | $ | (10,275 | ) |
| Net loss per common share |  |  |  |  |  |  |  |  |
| Basic |  | ($ | 0.18 | ) |  | ($ | 0.20 | ) |
| Diluted |  | ($ | 0.18 | ) |  | ($ | 0.20 | ) |
| Weighted average number of common shares outstanding |  |  |  |  |  |  |  |  |
| Basic |  |  | 58,300 |  |  |  | 51,191 |  |
| Diluted |  |  | 58,300 |  |  |  | 51,191 |  |

[0001193125-13-323082:8k_2_02:28]
| AMSC Reports Q1 Results |  | Page 5 |

[0001193125-13-323082:8k_2_02:29]
UNAUDITED CONSOLIDATED BALANCE SHEETS

[0001193125-13-323082:8k_2_02:30]
(In thousands)

[0001193125-13-323082:8k_2_02:31]
|  |  | June 30,2013 |  |  | March 31,2013 |  |
| ASSETS |  |  |  |  |  |  |  |  |
| Current assets: |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 32,608 |  |  | $ | 39,243 |  |
| Accounts receivable, net |  |  | 11,088 |  |  |  | 18,864 |  |
| Inventory |  |  | 30,752 |  |  |  | 33,473 |  |
| Prepaid expenses and other current assets |  |  | 23,868 |  |  |  | 22,469 |  |
| Restricted cash |  |  | 824 |  |  |  | 6,136 |  |
| Total current assets |  |  | 99,140 |  |  |  | 120,185 |  |
| Property, plant and equipment, net |  |  | 71,931 |  |  |  | 74,626 |  |
| Intangibles, net |  |  | 2,536 |  |  |  | 2,749 |  |
| Restricted cash |  |  | 6,098 |  |  |  | 4,820 |  |
| Deferred tax assets |  |  | 5,421 |  |  |  | 5,354 |  |
| Other assets |  |  | 9,067 |  |  |  | 9,020 |  |
| Total assets |  | $ | 194,193 |  |  | $ | 216,754 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |  |  |  |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |  |  |  |
| Accounts payable and accrued expenses |  | $ | 25,481 |  |  | $ | 30,138 |  |
| Note payable, current portion, net of discount of $363 as of June 30, 2013 and $458 as of March 31, 2013 |  |  | 4,252 |  |  |  | 4,158 |  |
| Current portion of convertible note, net of discount of $3,259 as of June 30, 2013 and $4,289 as of March 31, 2013 |  |  | 7,426 |  |  |  | 4,610 |  |
| Derivative liability |  |  | 3,693 |  |  |  | 4,162 |  |
| Adverse purchase commitments |  |  | 1,179 |  |  |  | 1,440 |  |
| Deferred revenue |  |  | 20,031 |  |  |  | 29,805 |  |
| Deferred tax liabilities |  |  | 5,452 |  |  |  | 5,444 |  |
| Total current liabilities |  |  | 67,514 |  |  |  | 79,757 |  |
| Note Payable, net of current portion and discount of $39 as of June 30, 2013 and $95 as of March 31, 2013 |  |  | 2,268 |  |  |  | 3,367 |  |
| Convertible note net of current portion and discount of $172 as of June 30, 2013 and $600 as of March 31, 2013 |  |  | 3,532 |  |  |  | 5,881 |  |
| Deferred revenue |  |  | 1,234 |  |  |  | 1,340 |  |
| Other liabilities |  |  | 1,165 |  |  |  | 1,291 |  |
| Total liabilities |  |  | 75,713 |  |  |  | 91,636 |  |
| Stockholders’ equity: |  |  |  |  |  |  |  |  |
| Common stock |  |  | 610 |  |  |  | 603 |  |
| Additional paid-in capital |  |  | 927,807 |  |  |  | 923,847 |  |
| Treasury stock |  |  | (370 | ) |  |  | (313 | ) |
| Accumulated other comprehensive income |  |  | 1,077 |  |  |  | 1,112 |  |
| Accumulated deficit |  |  | (810,644 | ) |  |  | (800,131 | ) |
| Total stockholders’ equity |  |  | 118,480 |  |  |  | 125,118 |  |
| Total liabilities and stockholders’ equity |  | $ | 194,193 |  |  | $ | 216,754 |  |

[0001193125-13-323082:8k_2_02:32]
| AMSC Reports Q1 Results |  | Page 6 |

[0001193125-13-323082:8k_2_02:33]
UNAUDITED CONSOLIDATED STATEMENTS OF CASH FLOWS

[0001193125-13-323082:8k_2_02:34]
(In thousands)

[0001193125-13-323082:8k_2_02:35]
|  |  | Three Months endedJune 30, |  |
|  |  | 2013 |  |  | 2012 |  |
| Cash flows from operating activities: |  |  |  |  |  |  |  |  |
| Net loss |  | $ | (10,513 | ) |  | $ | (10,275 | ) |
| Adjustments to reconcile net (loss) income to net cash (used in) provided by operations: |  |  |  |  |  |  |  |  |
| Depreciation and amortization |  |  | 2,655 |  |  |  | 3,344 |  |
| Stock-based compensation expense |  |  | 2,135 |  |  |  | 1,994 |  |
| Restructuring charges, net of payments |  |  | (27 | ) |  |  | (39 | ) |
| Provision for excess and obsolete inventory |  |  | 160 |  |  |  | 250 |  |
| Adverse purchase commitment recoveries, net |  |  | — |  |  |  | (7,301 | ) |
| Loss on minority interest investments |  |  | 248 |  |  |  | 812 |  |
| Change in fair value of derivatives and warrants |  |  | (469 | ) |  |  | 2,388 |  |
| Non-cash interest expense |  |  | 1,672 |  |  |  | 2,282 |  |
| Other non-cash items |  |  | 686 |  |  |  | 200 |  |
| Changes in operating asset and liability accounts: |  |  |  |  |  |  |  |  |
| Accounts receivable |  |  | 8,111 |  |  |  | 4,132 |  |
| Inventory |  |  | 2,861 |  |  |  | 136 |  |
| Prepaid expenses and other current assets |  |  | (1,151 | ) |  |  | 848 |  |
| Accounts payable and accrued expenses |  |  | (5,464 | ) |  |  | (6,449 | ) |
| Deferred revenue |  |  | (10,211 | ) |  |  | (3,913 | ) |
| Net cash used in operating activities |  |  | (9,307 | ) |  |  | (11,591 | ) |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |
| Net cash provided by (used in) investing activities |  |  | 3,774 |  |  |  | (6,846 | ) |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |
| Net cash (used in) provided by financing activities |  |  | (1,211 | ) |  |  | 32,925 |  |
| Effect of exchange rate changes on cash and cash equivalents |  |  | 109 |  |  |  | (280 | ) |
| Net (decrease) increase in cash and cash equivalents |  |  | (6,635 | ) |  |  | 14,208 |  |
| Cash and cash equivalents at beginning of period |  |  | 39,243 |  |  |  | 46,279 |  |
| Cash and cash equivalents at end of period |  | $ | 32,608 |  |  | $ | 60,487 |  |

[0001193125-13-323082:8k_2_02:36]
| AMSC Reports Q1 Results |  | Page 7 |

[0001193125-13-323082:8k_2_02:37]
RECONCILIATION OF GAAP NET LOSS TO NON-GAAP NET LOSS

[0001193125-13-323082:8k_2_02:38]
(In thousands, except per share data)

[0001193125-13-323082:8k_2_02:39]
|  |  | Three months endedJune 30, |  |
|  |  | 2013 |  |  | 2012 |  |
| Net loss |  | $ | (10,513 | ) |  | $ | (10,275 | ) |
| Adverse purchase commitment recoveries, net |  |  | — |  |  |  | (7,301 | ) |
| Stock-based compensation |  |  | 2,135 |  |  |  | 1,994 |  |
| Amortization of acquisition-related intangibles |  |  | 82 |  |  |  | 81 |  |
| Restructuring and impairment charges |  |  | 13 |  |  |  | 128 |  |
| Sinovel litigation |  |  | 107 |  |  |  | 120 |  |
| Consumption of zero cost-basis inventory |  |  | (1,174 | ) |  |  | (387 | ) |
| Gain/(loss) in change of fair value of derivatives and warrants |  |  | (469 | ) |  |  | 2,388 |  |
| Non-cash interest expense |  |  | 1,672 |  |  |  | 2,282 |  |
| Non-GAAP net (loss) income |  | $ | (8,147 | ) |  | $ | (10,970 | ) |
| Non-GAAP loss per share |  | $ | (0.14 | ) |  | $ | (0.21 | ) |
| Weighted average shares outstanding |  |  | 58,300 |  |  |  | 51,191 |  |

[0001193125-13-323082:8k_2_02:40]
RECONCILIATION OF FORECAST GAAP NET LOSS TO NON-GAAP NET LOSS

[0001193125-13-323082:8k_2_02:41]
(In millions, except per share data)

[0001193125-13-323082:8k_2_02:42]
|  |  | Three months endingSept. 30, 2013 |  |
| Net loss |  | $ | (17.0 | ) |
| Amortization of acquisition-related intangibles |  |  | 0.1 |  |
| Stock-based compensation |  |  | 2.4 |  |
| Non-cash interest expense |  |  | 3.6 |  |
| Consumption of zero-cost inventory |  |  | (1.1 | ) |
| Non-GAAP net loss |  | $ | (12.0 | ) |
| Non-GAAP net loss per share |  | $ | (0.20 | ) |
| Shares outstanding |  |  | 60.3 |  |

[0001193125-13-323082:8k_2_02:43]
| AMSC Reports Q1 Results |  | Page 8 |

[0001193125-13-323082:8k_2_02:44]
Note: Non-GAAP net loss is defined by the company as net loss before adverse purchase commitments
(recoveries) losses, net; stock-based compensation; amortization of acquisition-related intangibles; restructuring and impairment charges; Sinovel litigation costs; consumption of zero cost-basis inventory; non-cash interest expense; change in fair
value of derivatives and warrants and other unusual charges; net of any tax effects related to these items. The company believes non-GAAP net loss assists management and investors in comparing the company’s performance across reporting periods
on a consistent basis by excluding these non-cash or other non-recurring charges that it does not believe are indicative of its core operating performance. The company also regards non-GAAP net loss as a useful measure of operating performance and
cash flow to complement operating loss, net loss and other GAAP financial performance measures. In addition, the company uses non-GAAP net loss as a factor in evaluating management’s performance when determining incentive compensation and to
evaluate the effectiveness of its business strategies.

[0001193125-13-323082:8k_2_02:45]
Generally, a non-GAAP financial measure is a numerical measure of a
company’s performance, financial position or cash flow that either excludes or includes amounts that are not normally excluded or included in the most directly comparable measure calculated and presented in accordance with GAAP. The non-GAAP
measures included in this release, however, should be considered in addition to, and not as a substitute for or superior to, operating income, cash flows, or other measures of financial performance prepared in accordance with GAAP. A reconciliation
of non-GAAP to GAAP net loss is set forth in the table above.

[0001193125-13-323082:8k_2_02:46]
AMSC Contact:

[0001193125-13-323082:8k_2_02:47]
Kerry Farrell

[0001193125-13-323082:8k_2_02:48]
Phone: 978-842-3247

[0001193125-13-323082:8k_2_02:49]
Email: kerry.farrell@amsc.com
