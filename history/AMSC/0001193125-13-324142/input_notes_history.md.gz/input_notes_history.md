# AMSC note change history — 0001193125-13-048834 → 0001193125-13-324142


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2013-08-07):
[0001193125-13-324142:note_history:1]
| 12. | Commitments and Contingencies |
  (was, 2013-02-11, similarity 0.9118):
[0001193125-13-048834:note_history:1]
13.  Commitments and Contingencies

- changed (2013-08-07):
[0001193125-13-324142:note_history:2]
The Company
periodically enters into non-cancelable purchase contracts in order
to ensure the availability of materials to support production of
its products. Purchase commitments represent enforceable and
legally binding agreements with suppliers to purchase goods or
services. The Company periodically assesses the need to provide for
impairment on these purchase contracts and record a loss on
purchase commitments when required. As of June 30, 2013, the
Company reported a liability for adverse purchase commitments of
$1.2 million. During the three months ended June 30, 2013, the
Company reduced its accrual for adverse purchase commitments by
$0.3 million due to payments to certain vendors.
  (was, 2013-02-11, similarity 0.8805):
[0001193125-13-048834:note_history:2]
The Company periodically enters into non-cancelable purchase contracts in order to ensure the availability of materials to support production of its products. Purchase commitments represent enforceable and legally binding agreements with suppliers to purchase goods or services. The Company periodically assesses the need to provide for impairment on these purchase contracts and record a loss on purchase commitments when required.  As of December 31, 2012, the Company recorded a liability for adverse purchase commitments of $1.8 million. During the three and nine months ended December 31, 2012, the Company reduced its accrual for adverse purchase commitments by $10.3 million and $24.1 million, respectively due to settlements with and payments to certain vendors.

- changed (2013-08-07):
[0001193125-13-324142:note_history:3]
Legal
Contingencies
  (was, 2013-02-11, similarity 0.8125):
[0001193125-13-048834:note_history:3]
Contingencies

- changed (2013-08-07):
[0001193125-13-324142:note_history:4]
Between
April 6, 2011 and May 12, 2011, seven putative securities
class action complaints were filed against the Company and two of
its officers in the United States District Court for the District
of Massachusetts; one complaint additionally asserted claims
against the underwriters who participated in our November 12,
2010 securities offering. On June 7, 2011, the United
States District Court for the District of Massachusetts
consolidated these actions under the caption Lenartz v. American
Superconductor Corporation, et al., Docket
No. 1:11-cv-10582-WGY. On August 31, 2011, Lead
Plaintiff, the Plumbers and Pipefitters National Pension Fund,
filed a consolidated amended complaint against the Company, its
officers and directors, and the underwriters who participated in
our November 12, 2010 securities offering, asserting claims
under sections 10(b) and 20(a) of the Securities Exchange Act of
1934 and Rule 10b-5 promulgated under the Securities Exchange Act
of 1934 (the “Exchange Act”), as well as under
sections 11, 12(a)(2) and 15 of the Securities Act of 1933
(the “Securities Act”). The complaint alleges that
during the relevant class period, the Company and its officers
omitted to state material facts and made materially false and
misleading statements relating to, among other things, its
projected and recognized revenues and earnings, as well as its
relationship with Sinovel Wind Group Co., Ltd. that artificially
inflated the value of the Company’s stock price. The
complaint further alleges that the Company’s
November 12, 2010 securities offering contained untrue
statements of material facts and omitted to state material facts
required to be stated therein. The plaintiffs seek unspecified
damages, rescindment of the Company’s November 12, 2010
securities offering, and an award of costs and expenses, including
attorney’s fees. All defendants moved to dismiss the
consolidated amended complaint. On December 16, 2011, the
district court issued a summary order declining to dismiss the
Securities Act claims against the Company and its officers, and
taking under advisement the motion to dismiss the Exchange Act
claims against the Company and its officers and the motion to
dismiss the Securities Act claims made against the underwriters. On
July 26, 2012, the district court dismissed the Exchange Act
claims against the Company and its officers and denied the motion
to dismiss the Securities Act claims made against the underwriters.
On May 17, 2013, the parties informed the district court that
they had reached a settlement in principle, and requested a 30-day
stay of the proceedings while the specific terms of the settlement
continue to be negotiated. Based on the Company’s assessment
of the probable losses on this claim, the Company has recorded a
loss contingency of $1.8 million as of June 30,
2013.
  (was, 2013-02-11, similarity 0.9299):
[0001193125-13-048834:note_history:4]
Between April 6, 2011 and May 12, 2011, seven putative securities class action complaints were filed against the Company and two of its officers in the United States District Court for the District of Massachusetts; one complaint additionally asserted claims against the underwriters who participated in our November 12, 2010 securities offering.  On June 7, 2011, the United States District Court for the District of Massachusetts consolidated these actions under the caption Lenartz v. American Superconductor Corporation, et al., Docket No. 1:11-cv-10582-WGY.  On August 31, 2011, Lead Plaintiff, the Plumbers and Pipefitters National Pension Fund, filed a consolidated amended complaint against the Company, its officers and directors, and the underwriters who participated in our November 12, 2010 securities offering, asserting claims under sections 10(b) and 20(a) of the Securities Exchange Act of 1934 and Rule 10b-5 promulgated under the Securities Exchange Act of 1934 (the “Exchange Act”), as well as under sections 11, 12(a)(2) and 15 of the Securities Act of 1933 (the “Securities Act”).  The complaint alleges that during the relevant class period, the Company and its officers omitted to state material facts and made materially false and misleading statements relating to, among other things, its projected and recognized revenues and earnings, as well as its relationship with Sinovel Wind Group Co., Ltd. that artificially inflated the value of the Company’s stock price.  The complaint further alleges that the Company’s November 12, 2010 securities offering contained untrue statements of material facts and omitted to state material facts required to be stated therein.  The plaintiffs seek unspecified damages, rescindment of the Company’s November 12, 2010 securities offering, and an award of costs and expenses, including attorney’s fees.  All defendants moved to dismiss the consolidated amended complaint.  On December 16, 2011, the district court issued a summary order declining to dismiss the Securities Act claims against the Company and its officers, and taking under advisement the motion to dismiss the Exchange Act claims against the Company and its officers and the motion to dismiss the Securities Act claims made against the underwriters. On July 26, 2012, the district court dismissed the Exchange Act claims against the Company and its officers and denied the motion to dismiss the Securities Act claims made against the underwriters.

- changed (2013-08-07):
[0001193125-13-324142:note_history:5]
If a matter is
both probable to result in liability and the amount of loss can be
reasonably estimated, we estimate and disclose the possible loss or
range of possible loss. With respect to the above referenced
shareholder derivative litigation matters, an estimate of loss or
range of loss cannot be made. There are numerous factors that make
it difficult to meaningfully estimate possible loss or range of
loss at this stage of these litigation matters, including that: the
proceedings are in relatively early stages, there are significant
factual and legal issues to be resolved, information obtained or
rulings made during the lawsuits could affect the methodology for
calculation of rescission and the related statutory interest rate.
In addition, with respect to claims where damages are the requested
relief, no amount of loss or damages has been specified. Therefore,
the Company is unable at this time to estimate possible losses. The
Company believes that these litigations are without merit, and it
intends to defend these actions vigorously.
  (was, 2013-02-11, similarity 0.8259):
[0001193125-13-048834:note_history:5]
With respect to the above referenced litigation matters, an estimate of loss or range of loss cannot be made. There are numerous factors that make it difficult to meaningfully estimate possible loss or range of loss at this stage of these litigation matters, including that: the proceedings are in relatively early stages, there are significant factual and legal issues to be resolved, information obtained or rulings made during the lawsuits could affect the methodology for calculation of rescission and the related statutory interest rate. In addition, with respect to claims where damages are the requested relief, no amount of loss or damages has been specified. Therefore, the Company is unable at this time to estimate possible losses.  The Company believes that these litigations are without merit, and it intends to defend these actions vigorously. Therefore no adjustment has been made to the financial statements to reflect the outcome of these uncertainties.

- changed (2013-08-07):
[0001193125-13-324142:note_history:6]
On
September 13, 2011, the Company commenced a series of legal
actions in China against Sinovel Wind Group Co. Ltd.
(“Sinovel”). The Company’s Chinese subsidiary,
Suzhou AMSC Superconductor Co. Ltd., filed a claim for arbitration
with the Beijing Arbitration Commission in accordance with the
terms of the Company’s supply contracts with Sinovel. The
case is captioned (2011) Jing Zhong An Zi
No. 0963. On March 31, 2011, Sinovel refused to
accept contracted shipments of 1.5 megawatt, (“MW”) and
3 MW wind turbine core electrical components and spare parts that
the Company was prepared to deliver. The Company alleges that these
actions constitute material breaches of its contracts because
Sinovel did not give it notice that it intended to delay deliveries
as required under the contracts. Moreover, the Company alleges that
Sinovel has refused to pay past due amounts for prior shipments of
core electrical components and spare parts. The Company is seeking
compensation for past product shipments and retention (including
interest) in the amount of approximately RMB 485 million ($76
million) due to Sinovel’s breaches of its contracts. The
Company is also seeking specific performance of our existing
contracts as well as reimbursement of all costs and reasonable
expenses with respect to the arbitration. The value of the
undelivered components under the existing contracts, including the
deliveries refused by Sinovel in March 2011, amounts to
approximately RMB 4.6 billion ($720 million).
  (was, 2013-02-11, similarity 0.9419):
[0001193125-13-048834:note_history:6]
On September 13, 2011, the Company commenced a series of legal actions in China against Sinovel Wind Group Co. Ltd. (“Sinovel”).  The Company’s Chinese subsidiary, Suzhou AMSC Superconductor Co. Ltd., filed a claim for arbitration with the Beijing Arbitration Commission in accordance with the terms of the Company’s supply contracts with Sinovel.  The case is captioned (2011) Jin Zhong An Zi No. 0963. On March 31, 2011, Sinovel refused to accept contracted shipments of 1.5 megawatt (MW) and 3 MW wind turbine core electrical components and spare parts that the Company was prepared to deliver. The Company alleges that these actions constitute material breaches of its contracts because Sinovel did not give it notice that it intended to delay deliveries as required under the contracts. Moreover, the Company alleges that Sinovel has refused to pay past due amounts for prior shipments of core electrical components and spare parts. The Company is seeking compensation for past product shipments and retention (including interest) in the amount of approximately RMB 485 million ($76 million) due to Sinovel’s breaches of its contracts. The Company is also seeking specific performance of our existing contracts as well as reimbursement of all costs and reasonable expenses with respect to the arbitration. The value of the undelivered components under the existing contracts, including the deliveries refused by Sinovel in March 2011, amounts to approximately RMB 4.6 billion ($720 million).

- changed (2013-08-07):
[0001193125-13-324142:note_history:7]
The Company
also submitted a civil action application to the Beijing No. 1
Intermediate People’s Court under the caption
(2011) Yi Zhong Min Chu Zi No. 15524, against
Sinovel for software copyright infringement on September 13,
2011. The application alleges Sinovel’s unauthorized use of
portions of the Company’s wind turbine control software
source code developed for Sinovel’s 1.5MW wind turbines and
the binary code, or upper layer, of the Company’s software
for the PM3000 power converters in 1.5MW wind turbines. In July
2011, a former employee of the Company’s Austrian subsidiary
was arrested in Austria on charges of economic espionage and
fraudulent manipulation of data. In September 2011, the former
employee pled guilty to the charges, and was imprisoned. As a
result of the Company’s internal investigation and a criminal
investigation conducted by Austrian authorities, the Company
believes that this former employee was contracted by Sinovel
through an intermediary while employed by the Company and
improperly obtained and transferred to Sinovel portions of its wind
turbine control software source code developed for Sinovel’s
1.5MW wind turbines. Moreover, the Company believes the former
employee illegally used source code to develop for Sinovel a
software modification to circumvent the encryption and remove
technical protection measures on the Company’s PM3000 power
converters in 1.5MW wind turbines in the field. The Company is
seeking a cease and desist order with respect to the unauthorized
copying, installation and use of its software, monetary damages of
approximately RMB 38 million ($6 million) for our economic
losses and reimbursement of all costs and reasonable expenses. The
Beijing No. 1 Intermediate People’s Court accepted the
case, which was necessary in order for the case to proceed. In
November 2011, Sinovel filed a motion to remove this case from the
Beijing No. 1 Intermediate People’s Court and transfer
the matter to the Beijing Arbitration Commission. On
February 14, 2012, the court denied Sinovel’s motion to
remove the case. On February 21, 2012, Sinovel filed an appeal
of the Beijing No. 1 Intermediate People’s Court
decision to the Beijing Higher People’s Court. On
April 25, 2012, the Beijing Higher People’s Court issued
a final Civil Ruling which supports the Beijing No.1 Intermediate
People’s Court’s civil ruling and rejected
Sinovel’s appeal. Sinovel filed an appeal of the Beijing
Higher People’s Court’s decision with China’s
Supreme People’s Court. A hearing regarding this appeal was
held at the Chinese Supreme People’s Court on
October 26, 2012. On November 23, 2012, China’s
Supreme People’s Court issued a Civil Ruling, holding that
(1) it will conduct a re-trial of Sinovel’s appeal, and
(2) the lower court’s decision will be stayed pending
the re-trial. China’s Supreme People’s Court conducted
a re-trial of Sinovel’s appeal on May 29,
2013.
  (was, 2013-02-11, similarity 0.6157):
[0001193125-13-048834:note_history:7]
The Company also submitted a civil action application to the Beijing No. 1 Intermediate People’s Court under the caption (2011) Yi Zhong Min Chu Zi No. 15524, against Sinovel for software copyright infringement on September 13, 2011.  The application alleges Sinovel’s unauthorized use of portions of the Company’s wind turbine control software source code developed for Sinovel’s 1.5MW wind turbines and the binary code, or upper layer, of the Company’s software for the PM3000 power converters in 1.5MW wind turbines. In July 2011, a former employee of the Company’s Austrian subsidiary was arrested in Austria on charges of economic espionage and fraudulent manipulation of data. In September 2011, the former employee pled guilty to the charges, and was imprisoned.  As a result of the Company’s internal investigation and a criminal investigation conducted by Austrian authorities, the Company believes that this former employee was contracted by Sinovel through an intermediary while employed by the Company and improperly obtained and transferred to Sinovel portions of its wind turbine control software source code developed for Sinovel’s 1.5MW wind turbines. Moreover, the Company believes the former employee illegally used source code to develop for Sinovel a software modification to circumvent the encryption and remove technical protection measures on the Company’s PM3000 power converters in 1.5MW wind turbines in the field.  The Company is seeking a cease and desist order with respect to the unauthorized copying, installation and use of its software, monetary damages of approximately RMB 38 million ($6 million) for our economic losses and reimbursement of all costs and reasonable expenses.  The No. 1 Intermediate People’s Court accepted the case, which was necessary in order for the case to proceed.  In November 2011, Sinovel filed a motion to remove this case from the Beijing No. 1 Intermediate People’s Court and transfer the matter to the Beijing Arbitration Commission.  On February 14, 2012, the court denied Sinovel’s motion to remove the case.  On February 21, 2012, Sinovel filed an appeal of the Beijing No. 1 Intermediate People’s Court decision to the Beijing Higher People’s Court.  On April 25, 2012, the Beijing Higher People’s Court issued a final Civil Ruling which supports the Beijing No.1 Intermediate People’s Court’s civil ruling and rejected Sinovel’s appeal. Sinovel filed an appeal of the Beijing Higher People’s Court’s decision with China’s Supreme People’s Court. A hearing regarding this appeal was held at the Chinese Supreme People’s Court on October 26, 2012. On November 23, 2012, the China’s Supreme People’s Court issued a Civil Ruling, holding that (1) it will conduct a re-trial of Sinovel’s appeal, and (2) the lower court’s decision will be stayed pending the retrial.

- changed (2013-08-07):
[0001193125-13-324142:note_history:8]
On
September 16, 2011, the Company filed a civil copyright
infringement complaint in the Hainan Province No. 1
Intermediate People’s Court against Dalian Guotong Electric
Co. Ltd. (“Guotong”), a supplier of power converter
products to Sinovel, and Huaneng Hainan Power, Inc.
(“Huaneng”), a wind farm operator that has purchased
Sinovel wind turbines containing Guotong power converter products.
The case is captioned (2011) Hainan Yi Zhong Min Chu Zi
No. 62. The application alleges that the Company’s
PM1000 converters in certain Sinovel wind turbines have been
replaced by converters produced by Guotong. Because the Guotong
converters are being used in wind turbines containing the
Company’s wind turbine control software, the Company believes
that its copyrighted software is being infringed. The Company is
seeking a cease and desist order with respect to the unauthorized
use of its software, monetary damages of RMB 1.2 million ($0.2
million) for its economic losses (with respect to Guotong only) and
reimbursement of all costs and reasonable expenses. The court has
accepted the case, which was necessary in order for the case to
proceed. In addition, upon the request of the defendant Huaneng,
Sinovel has been added by the court to this case as a defendant and
Huaneng has been released from this case. In December 2011, Sinovel
filed a jurisdiction opposition motion requesting dismissal by the
Hainan Province No. 1 Intermediate People’s Court,
saying the case should be governed by the Beijing Arbitration
Commission. On February 3, 2012, the Company received the
Civil Ruling from the court, which granted Sinovel’s motion,
and dismissed the entire case. The Company appealed the
court’s ruling to the Hainan Higher Court, which on
April 5, 2012 upheld the decision of the Hainan Province
No. 1 Intermediate People’s Court. On April 9,
2012, the Company filed an appeal of the Hainan Higher
Court’s decision with China’s Supreme People’s
Court. China’s Supreme People’s Court accepted the
appeal on May 23, 2012. The case is captioned, (2012) Min
Shen Zi No. 630. On December 20, 2012, China’s
Supreme People’s Court issued a Civil ruling, holding that
(1) it will conduct a re-trial of the Company’s appeal
and (2) the lower court’s decision will be stayed
pending the re-trial. China’s Supreme People’s Court
conducted a re-trial of Sinovel’s appeal on May 29,
2013.
  (was, 2013-02-11, similarity 0.8617):
[0001193125-13-048834:note_history:8]
On September 16, 2011, the Company filed a civil copyright infringement complaint in the Hainan Province No. 1 Intermediate People’s Court against Dalian Guotong Electric Co. Ltd. (“Guotong”), a supplier of power converter products to Sinovel, and Huaneng Hainan Power, Inc. (“Huaneng”), a wind farm operator that has purchased Sinovel wind turbines containing Guotong power converter products.  The case is captioned (2011)  Hainan Yi Zhong Min Chu Zi No. 62.  The application alleges that the Company’s PM1000 converters in certain Sinovel wind turbines have been replaced by converters produced by Guotong. Because the Guotong converters are being used in wind turbines containing the Company’s wind turbine control software, the Company believes that its copyrighted software is being infringed.  The Company is seeking a cease and desist order with respect to the unauthorized use of its software, monetary damages of RMB 1.2 million ($0.2 million) for its economic losses (with respect to Guotong only) and reimbursement of all costs and reasonable expenses.  The court has accepted the case, which was necessary in order for the case to proceed.  In addition, upon the request of the defendant Huaneng, Sinovel has been added by the court to this case as a defendant and Huaneng has been released from this case.  In December 2011, Sinovel filed a jurisdiction opposition motion requesting dismissal by the Hainan Province No. 1 Intermediate People’s Court, saying the case should be governed by the Beijing Arbitration Commission. On February 3, 2012, the Company received the Civil Ruling from the court, which granted Sinovel’s motion, and dismissed the entire case. The Company appealed the court’s ruling to the Hainan Higher Court, which on April 5, 2012 upheld the decision of the Hainan Province No. 1 Intermediate People’s Court.  On April 9, 2012, the Company filed an appeal of the Hainan Higher Court’s decision with China’s Supreme People’s Court. The Supreme Court accepted the appeal on May 23, 2012. The case is captioned, (2012) Min Shen Zi No. 630. On December 20, 2012, the China’s Supreme People’s Court issued a Civil ruling, holding that (1) it will conduct a re-trial of the Company’s appeal and (2) the lower court’s decision will be stayed pending the re-trial.

- changed (2013-08-07):
[0001193125-13-324142:note_history:9]
Ghodawat Energy
Pvt Ltd (“Ghodawat”), a company registered in India
carrying on the business of wind power development, lodged a
Request for Arbitration with the Secretariat of the ICC
International Court of Arbitration on May 12, 2011 and named
AMSC Windtec GmbH (“AMSC Austria”) as the Respondent.
Under the Request for Arbitration, Ghodawat alleges that AMSC
Austria breached an agreement dated March 19, 2008 pursuant to
which AMSC Austria granted a license to Ghodawat to manufacture,
use, sell, market, erect, commission and maintain certain wind
turbines using its technical information and wind turbine design
(the “License Agreement”). Under the Request for
Arbitration, Ghodawat’s claims in this arbitration amount to
approximately €18 million ($24 million). AMSC Austria
filed an Answer to Request for Arbitration and Counterclaim
(“Answer and Counterclaim”), in which AMSC Austria
denied Ghodawat’s claims in their entirety. AMSC Austria
has also submitted counterclaims under the License Agreement
against Ghodawat in the amount of approximately
€6 million ($9 million). Ghodawat has filed a Reply
to Answer to Request for Arbitration and Counterclaim in which it
denies AMSC Austria’s counterclaims. On June 3, 2013,
the final oral submissions hearing was conducted and the Company
believes it will take several months for the Tribunal to render a
decision. The Company has recorded a loss contingency based on its
assessment of probable losses on this claim; however this amount is
immaterial to its consolidated financial statements.
  (was, 2013-02-11, similarity 0.817):
[0001193125-13-048834:note_history:9]
Ghodawat Energy Pvt Ltd (“Ghodawat”), a company registered in India carrying on the business of wind power development, lodged a Request for Arbitration with the Secretariat of the ICC International Court of Arbitration on May 12, 2011 and named AMSC Windtec GmbH (“AMSC Austria”) as the Respondent.  Under the Request for Arbitration, Ghodawat alleges that AMSC Austria breached an agreement dated March 19, 2008 pursuant to which AMSC Austria granted a license to Ghodawat to manufacture, use, sell, market, erect, commission and maintain certain wind turbines using its technical information and wind turbine design (the “License Agreement”).  Under the Request for Arbitration, Ghodawat’s claims in this arbitration amount to approximately €18 million ($24 million).  AMSC Austria filed an Answer to Request for Arbitration and Counterclaim (“Answer and Counterclaim”), in which AMSC Austria denied Ghodawat’s claims in their entirety.  AMSC Austria has also submitted counterclaims under the License Agreement against Ghodawat in the amount of approximately €6 million ($9 million).  Ghodawat has filed a Reply to Answer to Request for Arbitration and Counterclaim in which it denies AMSC Austria’s counterclaims.  The arbitration proceedings are currently ongoing.  The Company has recorded a loss contingency based on its assessment of probable losses on this claim; however this amount is immaterial to its consolidated financial statements.

- added (2013-08-07):
[0001193125-13-324142:note_history:10]
As of
June 30, 2013 the Company had $0.8 million of restricted cash
included in current assets, and $6.1 million of restricted cash
included in long-term assets. These amounts included in restricted
cash represent deposits to secure letters of credit for various
supply contracts. These deposits are held in interest bearing
accounts.

- added (2013-08-07):
[0001193125-13-324142:note_history:11]
As of
June 30, 2013, the Company had one performance bond in support
of customer contracts. The total value of the outstanding
performance bond is $0.2 million with an expiration date of March
2014. In the event that the payment is made in accordance with the
requirements of any of these performance bonds, the Company would
record the payment as an offset to revenue.

- added (2013-08-07):
[0001193125-13-324142:note_history:12]
The Company had
an unused, unsecured line of credit consisting of
€2.7 million (approximately $3.5 million) in Austria as
of June 30, 2013.

- removed (2013-08-07):
[0001193125-13-048834:note_history:13]
On May 16, 2012, the Company entered into an agreement with one of its vendors to settle certain of its adverse purchase commitments.  The agreement was amended on November 6, 2012 (as amended, the “Settlement Agreement”).  In conjunction with the Settlement Agreement, the Company agreed to pay the vendor approximately €2.2 million (the “Settlement Amount”). Under the Settlement Agreement, the Company had the option, at its sole discretion, to pay the settlement amount in cash, shares of the Company’s common stock, or a combination of cash and common stock.  Accordingly, during the three months ended December 31, 2012, the Company issued 765,301 shares of common stock to the vendor and filed a registration statement on Form S-3 to register the vendor’s resale of such shares of common stock.  If the net proceeds from the vendor’s resale of the shares of common stock during a specified period plus any other cash payments made by the Company subsequent to the date of the Settlement Agreement were less than the Settlement Amount, the Company agreed to make an additional payment equal to the shortfall in cash to the vendor no later than December 31, 2012.  As of December 31, 2012 the Company made a payment of $0.8 million as a result of such a shortfall. As security for the Company’s obligations under the Settlement Agreement, the Company provided the vendor with a letter of credit in the amount of approximately €2.2 million with an expiration of December 31, 2012. The letter of credit is secured with cash collateral of approximately $3.0 million, and is included in the Company’s restricted cash balance as of December 31, 2012. As of December 31, 2012, the Company had not been formally released from the letter of credit. The Company received that release in January 2013.

- removed (2013-08-07):
[0001193125-13-048834:note_history:14]
During the fourth quarter of the year ended March 31, 2012, several vendors notified the Company that they had suffered losses as a result of procuring safety stock in anticipation of receiving future purchase orders or contracts from the Company.  Subsequently three vendors filed lawsuits through the Chinese legal system seeking payment for inventories held to be delivered under purchase orders and safety stock. One of these lawsuits has been settled and dismissed. The Company has accrued outstanding adverse purchase commitments based on legally binding contracts and purchase orders that were placed with its vendors for parts with no future demand.  The vendor claims for safety stock were not supported by valid purchase orders or valid executed contracts and are not considered part of the adverse purchase commitment liability. The claims for safety stock have not been accrued as of December 31, 2012.  The Company has determined that, although it believes that there is no legally enforceable contract for safety stock and will continue to defend its legal position that it does not owe amounts for safety stock, it is reasonably possible that a case may be made against the Company under certain situations. As the loss is reasonably possible but not probable, the Company has not accounted for the loss.  The Company has determined that the range for this potential loss is between $0 and $2 million.

- removed (2013-08-07):
[0001193125-13-048834:note_history:15]
At December 31, 2012, the Company had $9.2 million of restricted cash included in current assets, and $4.8 million of restricted cash included in long-term assets. These amounts included in restricted cash represent deposits to secure letters of credit for various supply contracts, including those deemed as adverse purchase commitments, and are held in interest bearing accounts.  The Company is working with its inventory suppliers to delay cash settlements and to reduce the gross liability associated with its adverse purchase commitments, which is approximately $1.8 million as of December 31, 2012. During the three and nine months ended December 31, 2012, the Company agreed to settle adverse purchase commitments with certain of its vendors. In conjunction with certain of these settlements, the Company agreed tp provide letters of credit and bank guarantees in the amount of approximately $9.0 million with expirations through January 31, 2013. The letters of credit and bank guarantees were secured with cash collateral of approximately $8.5 million and were included in the Company’s restricted cash balance as of December 31, 2012. As of January 2013, these letters of credit had been cancelled and the cash collateral has been returned to unrestricted cash.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2013-08-07):
[0001193125-13-324142:note_history:16]
| 10. | Debt |
  (was, 2013-02-11, similarity 0.6667):
[0001193125-13-048834:note_history:16]
11.  Debt

- changed (2013-08-07):
[0001193125-13-324142:note_history:17]
Senior
Convertible Note
  (was, 2013-02-11, similarity 0.9787):
[0001193125-13-048834:note_history:17]
Senior Convertible Notes

- changed (2013-08-07):
[0001193125-13-324142:note_history:18]
On
April 4, 2012, the Company entered into a Securities Purchase
Agreement with Capital Ventures International (“CVI”),
an affiliate of Heights Capital Management (the “Purchase
Agreement”) and completed a private placement of the Initial
Note, a 7% unsecured senior convertible note. After fees and
expenses, the net proceeds of the Initial Note were $23.2 million.
The Initial Note had an initial conversion price of $4.85 per
share, representing a premium of approximately 20% over
AMSC’s closing price on April 3, 2012. The Initial Note
was payable in monthly installments beginning four months from
issuance and ending on October 4, 2014. Monthly payments were
payable in cash or the Company’s common stock at the option
of the Company, subject to certain trading volume, stock price and
other conditions. CVI could have also elected to defer receipt of
monthly installment payments at its option. Any deferred
installment payments would have continued to accrue interest. The
Company registered 10,262,311 shares of common stock which may be
used as payment for principal and interest in lieu of cash for
resale under the Securities Act as required under a Registration
Rights Agreement with CVI.
  (was, 2013-02-11, similarity 0.9586):
[0001193125-13-048834:note_history:18]
On April 4, 2012, the Company entered into a Securities Purchase Agreement with Capital Ventures International (“CVI”), an affiliate of Heights Capital Management (the “Purchase Agreement”) and completed a private placement of $25.0 million aggregate principal amount of  a 7%  unsecured senior convertible note (the “Initial Note”). After fees and expenses, the net proceeds were $23.2 million.  The Initial Note had an initial conversion price of $4.85 per share, representing a premium of approximately 20% over AMSC’s closing price on April 3, 2012. The Initial Note was payable in monthly installments beginning four months from issuance and ending on October 4, 2014.  Monthly payments were payable in cash or the Company’s common stock at the option of the Company, subject to certain trading volume, stock price and other conditions. CVI could have also elected to defer receipt of monthly installment payments at its option. Any deferred installment payments would have continued to accrue interest. The Company registered 10,262,311 shares of common stock which may be used as payment for principal and interest in lieu of cash for resale under the Securities Act as required under a Registration Rights Agreement with CVI.

- changed (2013-08-07):
[0001193125-13-324142:note_history:19]
The Company has
identified the following derivatives associated with the Initial
Note: holder change of control redemption rights; issuer optional
redemption rights; sale redemption rights and a feature to convert
the Initial Note into equity at the holder’s option. The
Company valued these derivatives at $3.8 million upon issuance of
the Initial Note. (See Note 11, “Warrants and Derivative
Liabilities,” for additional information regarding derivative
liabilities.)
  (was, 2013-02-11, similarity 0.9957):
[0001193125-13-048834:note_history:19]
The Company has identified the following derivatives associated with the Initial Note: holder change of control redemption rights; issuer optional redemption rights; sale redemption rights and a feature to convert the Initial Note into equity at the holder’s option.  The Company valued these derivatives at $3.8 million upon issuance of the Initial Note. See Note 12, “Warrants and Derivative Liabilities”, for additional information regarding derivative liabilities.

- changed (2013-08-07):
[0001193125-13-324142:note_history:20]
In conjunction
with the Initial Note, CVI received a warrant to purchase
approximately 3.1 million additional shares of common stock
exercisable at a strike price of $5.45 per share, subject to
adjustment, until October 4, 2017. Due to certain adjustment
provisions within the warrant, it qualified for liability
accounting and had a fair value of $7.0 million upon issuance. The
Company recorded the value as a debt discount and a warrant
liability. (See Note 11, “Warrants and Derivative
Liabilities,” for additional information regarding the
warrant.)
  (was, 2013-02-11, similarity 0.9963):
[0001193125-13-048834:note_history:20]
In conjunction with the Initial Note, CVI received a warrant to purchase approximately 3.1 million additional shares of common stock exercisable at a strike price of $5.45 per share, subject to adjustment, until October 4, 2017. Due to certain adjustment provisions within the warrant, it qualified for liability accounting and had a fair value of $7.0 million upon issuance. The Company recorded the value as a debt discount and a warrant liability. See Note 12, “Warrants and Derivative Liabilities”, for additional information regarding the warrant.

- changed (2013-08-07):
[0001193125-13-324142:note_history:21]
The process of
valuing financial and derivative instruments utilizes facts and
circumstances as of the measurement date as well as certain inputs,
assumptions, and judgments that may affect the estimated fair value
of the instruments. Upon issuance of the Initial Note, the Company
determined the initial carrying value of the Initial Note to be
$25.0 million. In addition, the Company also incurred $1.8 million
of legal and origination costs as of the year ended March 31,
2013, which have been recorded as a discount on the Initial
Note.
  (was, 2013-02-11, similarity 0.9607):
[0001193125-13-048834:note_history:21]
The process of valuing financial and derivative instruments utilizes facts and circumstances as of the measurement date as well as certain inputs, assumptions, and judgments that may affect the estimated fair value of the instruments. Upon issuance of the Initial Note, the Company determined the initial carrying value of the Initial Note to be $25.0 million. In addition, the Company also incurred $1.8 million of legal and origination costs as of the nine months ended December 31, 2012, which have been recorded as a discount on the Initial Note.

- changed (2013-08-07):
[0001193125-13-324142:note_history:22]
On
December 20, 2012, the Company entered into an Amendment and
Exchange Agreement, (the “Amendment”) with CVI, which
amended the Purchase Agreement. Pursuant to the Amendment, the
Company and CVI exchanged the Initial Note for the Exchanged Note.
At the time of the exchange, the Exchanged Note had the same
principal amount and accrued interest as the Initial Note. The
Exchanged Note is convertible into the Company’s common stock
and has the same scheduled monthly installment payments as the
Initial Note. The Exchanged Note provides the Company with
additional flexibility to make monthly installment payments in
shares of the Company’s common stock. The Company retains the
ability to repay the Exchanged Note in cash. Specifically, the
amendments to the Exchanged Note:
  (was, 2013-02-11, similarity 0.9478):
[0001193125-13-048834:note_history:22]
On December 20, 2012, the Company entered into an Amendment and Exchange Agreement, (the “Amendment”) with CVI, which amended the Purchase Agreement. Pursuant to the Amendment, the Company and CVI exchanged the Initial Note for a new unsecured, senior convertible note, (the “Exchanged Note”). At the time of the exchange, the Exchanged Note had the same principal amount and accrued interest as the Initial Notes. The Exchanged Note is convertible into the Company’s common stock and has the same scheduled monthly installment payments as the Initial Note. The Exchanged Note provides the Company with additional flexibility to make monthly installment payments in shares of the Company’s common stock. The Company retains the ability to repay the Exchanged Note in cash. Specifically, the amendments to the Exchanged Note:

- added (2013-08-07):
[0001193125-13-324142:note_history:23]
|  | • |  | Allow the Company to convert, subject to the satisfaction of certain conditions set forth in the Exchanged Note, (a) at least $2.5 million of the approximately $5.3 million installment amount payable with respect to the January 2013 installment date (including approximately $4.2 million of deferred installment amounts from the period September 4, 2012 to December 3, 2012) into shares of the Company’s common stock (on December 21, 2012 the Company converted $3.8 million in deferred installment amount principal and interest and issued 1,715,443 shares of common stock), and (b) the balance of the January 2013 installment amount in equal amounts on each of the February and March 2013 installment dates; |

- changed (2013-08-07):
[0001193125-13-324142:note_history:24]
|  | • |  | Reduce the price failure equity condition with respect to a particular date of determination from $2.50 to $1.00; |
  (was, 2013-02-11, similarity 0.9744):
[0001193125-13-048834:note_history:24]
| · | Reduce the price failure equity condition with respect to a particular date of determination from $2.50 to $1.00; |

- changed (2013-08-07):
[0001193125-13-324142:note_history:25]
|  | • |  | Reduce the aggregate daily dollar trading volume equity condition required for at least 25 of the 30 consecutive trading days immediately preceding a date of determination from $1,500,000 to $850,000 per trading day. In addition, if the aggregate daily dollar trading volume is between $50,000 and $850,000, the Company may still convert into common stock a portion of an installment amount payable with respect to an installment date equal to the quotient of (x) the aggregate daily dollar trading volume, divided by (y) $850,000; |
  (was, 2013-02-11, similarity 0.9941):
[0001193125-13-048834:note_history:25]
| · | Reduce the aggregate daily dollar trading volume equity condition required for at least 25 of the 30 consecutive trading days immediately preceding a date of determination from $1,500,000 to $850,000 per trading day. In addition, if the aggregate daily dollar trading volume is between $50,000 and $850,000, the Company may still convert into common stock a portion of an installment amount payable with respect to an installment date equal to the quotient of (x) the aggregate daily dollar trading volume, divided by (y) $850,000; |

- changed (2013-08-07):
[0001193125-13-324142:note_history:26]
|  | • |  | Increase CVI’s beneficial ownership limitation under the Exchanged Note from 4.99% to 9.99%; and |
  (was, 2013-02-11, similarity 0.97):
[0001193125-13-048834:note_history:26]
| · | Increase CVI’s beneficial ownership limitation under the Exchanged Note from 4.99% to 9.99%; and |

- changed (2013-08-07):
[0001193125-13-324142:note_history:27]
|  | • |  | Reduce the conversion price, from $4.85 per share of the Company’s common stock to $3.19 per share of the Company’s common stock, subject to certain price-based and other anti-dilution adjustments. |
  (was, 2013-02-11, similarity 0.9851):
[0001193125-13-048834:note_history:27]
| · | Reduce the conversion price, from $4.85 per share of the Company’s common stock to $3.19 per share of the Company’s common stock, subject to certain price-based and other anti-dilution adjustments. |

- changed (2013-08-07):
[0001193125-13-324142:note_history:28]
The Company
assessed the changes in the Exchanged Note and accounted for it as
a modification of the Initial Note. Therefore, the Company
determined the incremental value of the derivative instruments, as
a result of the Exchanged Note, as having a reduced conversion
price. As a result of the re-valuation, the Company recorded a $0.5
million increase in the value of the derivative liability and
additional debt discount. At the modification date, the value of
the derivative liability was $1.5 million. The total debt discount,
including the embedded derivatives in the Initial Note, the
incremental value of embedded derivatives in the Exchanged Note,
warrant and legal and origination costs of $13.1 million is being
amortized into interest expense over the term of the Exchanged Note
using the effective interest method. Under this method, interest
expense is recognized each period until the debt instruments reach
maturity. If the maturity of the Exchanged Note is accelerated
because of prepayment, then the amortization will be accelerated.
During the three months ended June 30, 2013, and 2012 the
Company recorded non-cash interest expense for amortization of the
debt discount related to the convertible notes of $1.5 million and
$2.2 million, respectively.
  (was, 2013-02-11, similarity 0.9768):
[0001193125-13-048834:note_history:28]
The Company assessed the changes in the Exchanged Note and accounted for it as a modification of the Initial Note. Therefore, the Company determined the incremental value of the derivative instruments as a result of the Exchanged Note having a reduced conversion price. As a result of the re-valuation, the Company recorded a $0.5 million increase in the value of the derivative liability and additional debt discount. At the modification date, the value of the derivative liability was $1.5 million. The total debt discount, including the embedded derivatives in the Initial Note,  the incremental value of embedded derivatives in the Exchanged Note, warrant and legal and origination costs of $13.1 million is being amortized into interest expense over the term of the Exchanged Note using the effective interest method. Under this method, interest expense is recognized each period until the debt instruments reach maturity.  If the maturity of the Exchanged Note is accelerated because of prepayment, then the amortization will be accelerated.  During the three and nine months ended December 31, 2012, the Company recorded non-cash interest expense for amortization of the debt discount related to the convertible notes of $2.2 million and $6.4 million, respectively.

- changed (2013-08-07):
[0001193125-13-324142:note_history:29]
Provided
certain equity conditions are met, the Company may elect to repay
principal and interest in shares of the Company’s common
stock. If the Company elects to make a payment in shares of the
Company’s common stock, the number of shares to be issued is
determined by dividing the amount of such payment by 85% of the
lessor of the average volume-weighted average price
(“VWAP”) of the 10 consecutive days immediately
preceding the payment date or the VWAP price on the day preceding
the payment date (the “Market Price”). The Company
records the difference between the closing price of its common
stock on the day preceding the payment date and the Market Price as
a discount on the fair value of its shares. During the three months
ended June 30, 2013, the Company recorded $0.1 million of
non-cash interest expense related to installment payments made by
issuing the Company’s common stock at a discount.
  (was, 2013-02-11, similarity 0.691):
[0001193125-13-048834:note_history:29]
Provided certain equity conditions are met, the Company may elect to repay principal and interest in shares of the Company’s common stock. If the Company elects to make a payment in shares of the Company’s common stock, the number of shares to be issued is determined by dividing the amount of such payment by 85% of the lessor of the average volume-weighted average price (“VWAP”) of the 10 consecutive days immediately preceding the payment date or the VWAP price on the day preceding the payment date (the “Market Price”). On December 20, 2012 the Company paid approximately $3.8 million in principal and interest by issuing 1,715,443 shares of the Company’s common stock. The Company records the difference between the closing price of its common stock on the day preceding the payment date and the Market Price as a discount on the fair value of its shares. During the three and nine months ended December 31, 2012, the Company recorded $1.5 million of non-cash interest expense related to installment payments made by issuing the Company’s common stock at a discount.

- changed (2013-08-07):
[0001193125-13-324142:note_history:30]
The Exchanged
Note and Purchase Agreement contain certain covenants and
restrictions, including, among others, that for so long as the
Exchanged Note is outstanding, the Company will not incur any
indebtedness (other than permitted indebtedness under the Exchanged
Note), permit liens on its properties (other than permitted liens
under the Exchanged Note), make payments on junior securities or
declare dividends. The Exchanged Note also contains limitations on
the transfer of certain assets. Events of default under the
Exchanged Note include failure to pay principal or interest as due
on the Exchanged Note, failure to deliver registered shares of
common stock upon the holders request for conversion of part or all
of the Exchanged Note, failure to maintain the Company’s
common stock eligible for trading on defined markets, cross
defaults to other material indebtedness, receipt of uninsured
judgments against the Company in excess of defined limits and other
administrative covenants, including the Term Loan discussed below,
as defined in the Exchanged Note and related documentation. Upon an
event of default, the holders may require the Company to redeem all
or any portion of the outstanding principal amount of the Exchanged
Note in cash plus a penalty as specified in the agreement. Also, if
the Company fails to maintain an effective registration statement
covering common stock to be used in settling obligations under the
Exchanged Note, the Company will be required to pay a penalty as
specified in the agreement.
  (was, 2013-02-11, similarity 0.999):
[0001193125-13-048834:note_history:30]
The Exchanged Note and Purchase Agreement contains certain covenants and restrictions, including, among others, that for so long as the Exchanged Note is outstanding, the Company will not incur any indebtedness (other than permitted indebtedness under the Exchanged Note), permit liens on its properties (other than permitted liens under the Exchanged Note), make payments on junior securities or declare dividends.  The Exchanged Note also contains limitations on the transfer of certain assets.  Events of default under the Exchanged Note include failure to pay principal or interest as due on the Exchanged Note, failure to deliver registered shares of common stock upon the holders request for conversion of part or all of the Exchanged Note, failure to maintain the Company's common stock eligible for trading on defined markets, cross defaults to other material indebtedness, receipt of uninsured judgments against the Company in excess of defined limits and other administrative covenants, including the Term Loan discussed below, as defined in the Exchanged Note and related documentation. Upon an event of default, the holders may require the Company to redeem all or any portion of the outstanding principal amount of the Exchanged Note in cash plus a penalty as specified in the agreement.  Also, if the Company fails to maintain an effective registration statement covering common stock to be used in settling obligations under the Exchanged Note, the Company will be required to pay a penalty as specified in the agreement.

- changed (2013-08-07):
[0001193125-13-324142:note_history:31]
On June 5,
2012, the Company entered into a Term Loan with Hercules Technology
Growth Capital, Inc. (“Hercules”), under which the
Company borrowed $10.0 million (the “Term Loan”). After
the closing fees and expenses, the net proceeds to the Company were
$9.7 million. The Term Loan bears an interest rate equal to 11%
plus the percentage, if any, by which the prime rate as reported by
The Wall Street Journal exceeds 3.75%. The Company made
interest-only payments from July 1, 2012 through
October 31, 2012, after which the Company repays the loan in
equal monthly installments ending on December 1, 2014. The
Term Loan is secured by substantially all of the Company’s
existing and future assets, including a mortgage on real property
owned by the Company’s wholly-owned subsidiary, ASC Devens
LLC, and located at 64 Jackson Road, Devens, Massachusetts. In
addition, Hercules received a warrant to purchase 139,276 shares of
common stock, exercisable at an initial strike price of $3.59 per
share, subject to adjustment, until December 5, 2017. Due to
certain adjustment provisions within the warrant, it qualified for
liability accounting and the fair value of $0.4 million was
recorded upon issuance, which the Company recorded as a debt
discount and a warrant liability. (See Note 11, “Warrants and
Derivative Liabilities,” for a discussion on warrants and the
valuation assumptions used.) The Company will pay an end of term
fee of $0.5 million upon the earlier of maturity or prepayment of
the loan. The Company has accrued this as of the year ended
March 31, 2013 and recorded a corresponding amount into the
debt discount. In addition, the Company incurred $0.3 million of
legal and origination costs in the year ended March 31, 2013,
which have been recorded as a debt discount. The total debt
discount including the warrant, end of term fee and legal and
origination costs of $1.2 million is being amortized into interest
expense over the term of the Term Loan using the effective interest
method. Under this method, interest expense is recognized each
period until the debt instrument reaches maturity. If the maturity
of the Term Loan is accelerated because of prepayment, then the
amortization will be accelerated. During the three months ended
June 30, 2013 and 2012, the Company recorded non-cash interest
expense for amortization of the debt discount related to the Term
Loan of $0.1 million and $0.1 million, respectively.
  (was, 2013-02-11, similarity 0.9695):
[0001193125-13-048834:note_history:31]
On June 5, 2012, the Company entered into a Term Loan with Hercules Technology Growth Capital, Inc. (“Hercules”), under which the Company borrowed $10.0 million (the “Term Loan”). After the closing fees and expenses, the net proceeds to the Company were $9.7 million. The Term Loan bears an interest rate equal to 11% plus the percentage, if any, by which the prime rate as reported by The Wall Street Journal exceeds 3.75%.  The Company made interest-only payments from July 1, 2012 through October 31, 2012, after which the Company repays the loan in equal monthly installments ending on December 1, 2014. The Term Loan is secured by substantially all of the Company’s existing and future assets, including a mortgage on real property owned by the Company’s wholly-owned subsidiary, ASC Devens LLC, and located at 64 Jackson Road, Devens, Massachusetts. In addition, Hercules received a warrant to purchase 139,276 shares of common stock, exercisable at an initial strike price of $3.59 per share, subject to adjustment, until December 5, 2017.  Due to certain adjustment provisions within the warrant, it qualified for liability accounting and the fair value of $0.4 million was recorded upon issuance, which the Company recorded as a debt discount and a warrant liability. See Note 12, “Warrants and Derivative Liabilities”, for a discussion on warrants and the valuation assumptions used.  The Company will pay an end of term fee of $0.5 million upon the earlier of maturity or prepayment of the loan.  The Company has accrued this as of the nine months ended December  31, 2012 and recorded a corresponding amount into the debt discount.   In addition, the Company incurred $0.3 million of legal and origination costs in the nine months ended December 31, 2012, which have been recorded as a debt discount. The total debt discount including the warrant, end of term fee and legal and origination costs of $1.2 million is being amortized into interest expense over the term of the Term Loan using the effective interest method. Under this method, interest expense is recognized each period until the debt instrument reaches maturity. If the maturity of the Term Loan is accelerated because of prepayment, then the amortization will be accelerated.  During the three and nine months ended December 31, 2012, the Company recorded non-cash interest expense for amortization of the debt discount related to the Term Loan of $0.2 million and $0.5 million, respectively.

- changed (2013-08-07):
[0001193125-13-324142:note_history:32]
Although the
Company believes that it is in and expects to remain in compliance
with the covenants and restrictions under the Exchanged Notes and
Term Loan as of the date of this Quarterly Report on Form 10-Q,
there can be no assurance that the Company will continue to be in
compliance.
  (was, 2013-02-11, similarity 0.932):
[0001193125-13-048834:note_history:32]
Although the Company believes it is in and expects to remain in compliance with the covenants and restrictions under the Exchanged Notes and Term Loan as of the date of this Quarterly Report on Form 10-Q, and expects to remain in compliance there can be no assurance that the Company will continue to be in compliance.

- added (2013-08-07):
[0001193125-13-324142:note_history:33]
Interest
expense on the Exchanged Note and Term Loan for the three months
ended June 30, 2013 and 2012 was $2.1 million, and $2.7
million, respectively, which included $1.7 million and $2.3
million, respectively, of non-cash interest expense related to the
amortization of the debt discount on the Exchanged Note and Term
Loan and payment of the Exchanged Note in Company common stock at a
discount.

- removed (2013-08-07):
[0001193125-13-048834:note_history:34]
| · | Allow the Company to convert, subject to the satisfaction of certain conditions set forth in the Exchanged Note, |

- removed (2013-08-07):
[0001193125-13-048834:note_history:35]
(a) at least $2.5 million of the approximately $5.3 million installment amount payable with respect to the January 2013 installment date (including approximately $4.2 million of deferred installment amounts from the period September 4, 2012 to December 3, 2012) into shares of the Company’s common stock, (On December 21, 2012 the Company converted $3.8 million in deferred installment amount principal and interest and issued 1,715,443 shares of common stock), and (b) the balance of the January 2013 installment amount in equal amounts on each of the February and March 2013 installment dates;

- removed (2013-08-07):
[0001193125-13-048834:note_history:36]
In addition, on October 4, 2012, the Company had the right to issue an additional $15 million aggregate principal amount of convertible notes and warrant to the same investor, subject to certain conditions.   Because the Company did not meet these conditions, it no longer has the right to compel the investor to purchase additional convertible notes on the terms contained in the agreement.

- removed (2013-08-07):
[0001193125-13-048834:note_history:37]
Interest expense on the convertible notes and Term Loan for the three and nine months ended December 31, 2012 was $4.6 million and $10.3 million respectively, which included $3.9 million and $8.4 million of non-cash interest expense related to the amortization of the debt discount on the Exchanged Note and Term Loan and payment of the Exchanged Notes in Company common stock at a discount, respectively.


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: tag_name, score: 1.0

- changed (2013-08-07):
[0001193125-13-324142:note_history:38]
| 16. | Subsequent Events |
  (was, 2013-02-11, similarity 0.8636):
[0001193125-13-048834:note_history:38]
17. Subsequent Events

- added (2013-08-07):
[0001193125-13-324142:note_history:39]
On
July 24, 2013, the Company undertook an action to reduce
headcount as part of its plan to reduce operating expenses in order
to enhance liquidity. The Company reduced its workforce by
approximately 7%, impacting primarily selling, engineering and
general and administrative functions. The Company expects to record
a restructuring charge for severance and other costs of
approximately $1.0 million in the second quarter of fiscal
2013.

- removed (2013-08-07):
[0001193125-13-048834:note_history:40]
The Company has performed an evaluation of subsequent events through the time of filing this Quarterly Report on Form 10-Q with the SEC, and has determined that there are no such events that are required to be disclosed.
