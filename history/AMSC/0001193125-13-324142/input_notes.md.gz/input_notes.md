# AMSC notes — 0001193125-13-324142


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001193125-13-324142:notes:1]
| 2. | Stock-Based Compensation |

[0001193125-13-324142:notes:2]
The Company
accounts for its stock-based compensation at fair value. The
following table summarizes stock-based compensation expense by
financial statement line item for the three months ended
June 30, 2013 and 2012 (in thousands):

[0001193125-13-324142:notes:3]
|  |  | Three months ended June 30, |  |
|  |  | 2013 |  |  | 2012 |  |
| Cost of revenues |  | $ | 205 |  |  | $ | 170 |  |
| Research and development |  |  | 575 |  |  |  | 562 |  |
| Selling, general and administrative |  |  | 1,355 |  |  |  | 1,262 |  |
| Total |  | $ | 2,135 |  |  | $ | 1,994 |  |

[0001193125-13-324142:notes:4]
During the
three months ended June 30, 2013, the Company granted
approximately 314,765 stock options and issued 154,080 shares of
common stock in-lieu of cash bonuses to employees under the 2007
Stock Incentive Plan. The shares issued in-lieu of cash bonuses
vest immediately, the options granted vest upon the passage of
time, generally 3 years. For awards that vest upon the passage of
time, expense is being recorded over the vesting period.

[0001193125-13-324142:notes:5]
The estimated
fair value of the Company’s stock-based awards, less expected
annual forfeitures, is amortized over the awards’ service
period. The total unrecognized compensation cost for unvested
outstanding stock options was $3.3 million for the three months
ended June 30, 2013. This expense will be recognized over a
weighted average expense period of approximately 1.9 years. The
total unrecognized compensation cost for unvested outstanding
restricted stock was $4.6 million for the three months ended
June 30, 2013. This expense will be recognized over a weighted
average expense period of approximately 1.3 years.

[0001193125-13-324142:notes:6]
The
weighted-average assumptions used in the Black-Scholes valuation
model for stock options granted during the three months ended
June 30, 2013 and 2012 are as follows:

[0001193125-13-324142:notes:7]
|  |  | Three months ended June 30, |  |
|  |  | 2013 |  |  | 2012 |  |
| Expected volatility |  |  | 74.6 | % |  |  | 72.0 | % |
| Risk-free interest rate |  |  | 1.7 | % |  |  | 0.9 | % |
| Expected life (years) |  |  | 5.9 |  |  |  | 5.9 |  |
| Dividend yield |  |  | None |  |  |  | None |  |

[0001193125-13-324142:notes:8]
The expected
volatility rate was estimated based on an equal weighting of the
historical volatility of the Company’s common stock and the
implied volatility of the Company’s traded options. The
expected term was estimated based on an analysis of the
Company’s historical experience of exercise, cancellation,
and expiration patterns. The risk-free interest rate is based on
the average of the five and seven year United States Treasury
rates.


## us-gaap:ScheduleOfAccountsPayableAndAccruedLiabilitiesTableTextBlock

[0001193125-13-324142:notes:9]
Accounts payable and accrued expenses consisted of the
following (in thousands):

[0001193125-13-324142:notes:10]
|  |  | June 30, |  |  | March 31, |  |
|  |  | 2013 |  |  | 2013 |  |
| Accounts payable |  | $ | 4,174 |  |  | $ | 7,146 |  |
| Accrued miscellaneous expenses |  |  | 9,419 |  |  |  | 9,142 |  |
| Accrued VAT |  |  | 1,517 |  |  |  | 809 |  |
| Accrued outside services |  |  | 2,744 |  |  |  | 2,251 |  |
| Accrued subcontractor program costs |  |  | 512 |  |  |  | 2,442 |  |
| Accrued compensation |  |  | 4,153 |  |  |  | 5,506 |  |
| Income taxes payable |  |  | 175 |  |  |  | 133 |  |
| Accrued warranty |  |  | 2,787 |  |  |  | 2,709 |  |
| Total |  | $ | 25,481 |  |  | $ | 30,138 |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001193125-13-324142:notes:11]
| 14. | Business Segments |

[0001193125-13-324142:notes:12]
The Company
reported its financial results in two reportable business segments:
Wind and Grid.

[0001193125-13-324142:notes:13]
Through its
Windtec Solutions, the Wind business segment enables manufacturers
to field wind turbines with highly competitive power output,
reliability and affordability. The Company supplies advanced power
electronics and control systems, licenses its highly engineered
wind turbine designs, and provides extensive customer support
services to wind turbine manufactures. Its design portfolio
includes a broad range of drive trains and power ratings. It
provides a broad range of power electronics and software-based
control systems that are highly integrated and designed for
optimized performance, efficiency, and grid
compatibility.

[0001193125-13-324142:notes:14]
Through its
Gridtec Solutions, the Grid business segment enables electric
utilities and renewable energy project developers to connect,
transmit and distribute power with highly competitive efficiency,
reliability and affordability. The Company provides transmission
planning services that allow it to identify power grid congestion,
poor power quality and other risks, which help the Company
determine how its solutions can improve network performance. These
services often lead to sales of grid interconnection solutions for
wind farms and solar power plants, power quality systems and
transmission and distribution cable systems.

[0001193125-13-324142:notes:15]
The operating
results for the two business segments are as follows (in
thousands):

[0001193125-13-324142:notes:16]
|  |  | Three months ended June 30, |  |
|  |  | 2013 |  |  | 2012 |  |
| Revenues: |  |  |  |  |  |  |  |  |
| Wind |  | $ | 14,701 |  |  | $ | 16,511 |  |
| Grid |  |  | 8,385 |  |  |  | 12,205 |  |
| Total |  | $ | 23,086 |  |  | $ | 28,716 |  |
|  |  | Three months ended June 30, |  |
|  |  | 2013 |  |  | 2012 |  |
| Operating (loss) income: |  |  |  |  |  |  |  |  |
| Wind |  | $ | (1,825 | ) |  | $ | 1,301 |  |
| Grid |  |  | (4,869 | ) |  |  | (5,343 | ) |
| Unallocated corporate expenses |  |  | (2,156 | ) |  |  | (2,086 | ) |
| Total |  | $ | (8,850 | ) |  | $ | (6,128 | ) |

[0001193125-13-324142:notes:17]
The accounting
policies of the business segments are the same as those for the
consolidated Company. The Company’s business segments have
been determined in accordance with the Company’s internal
management structure, which is organized based on operating
activities. The Company evaluates performance based upon
several factors, of which the primary financial measures are
segment revenues and segment operating (loss) income. The
disaggregated financial results of the segments reflect allocation
of certain functional expense categories consistent with the basis
and manner in which Company management internally disaggregates
financial information for the purpose of assisting in making
internal operating decisions. In addition, certain corporate
expenses which the Company does not believe are specifically
attributable or allocable to either of the two business segments
have been excluded from the segment operating income.

[0001193125-13-324142:notes:18]
Unallocated
corporate expenses primarily consist of stock-based compensation
expense of $2.1 million and $2.0 million for the three months ended
June 30, 2013 and 2012, respectively.

[0001193125-13-324142:notes:19]
Total assets
for the two business segments are as follows (in
thousands):

[0001193125-13-324142:notes:20]
|  |  | June 30, 2013 |  |  | March 31, 2013 |  |
| Wind |  | $ | 56,015 |  |  | $ | 67,111 |  |
| Grid |  |  | 72,252 |  |  |  | 72,800 |  |
| Corporate assets |  |  | 65,926 |  |  |  | 76,843 |  |
| Total |  | $ | 194,193 |  |  | $ | 216,754 |  |

[0001193125-13-324142:notes:21]
The following
table sets forth customers who represented 10% or more of the
Company’s total revenues for the three months ended
June 30, 2013 and 2012:

[0001193125-13-324142:notes:22]
|  |  | Three months ended |  |
|  |  | June 30, |  |
|  |  | 2013 |  |  | 2012 |  |
| Beijing JINGCHENG New Energy Co., Ltd. |  |  | 35 | % |  |  | 19 | % |
| INOX Wind Limited |  |  | 15 | % |  |  | 15 | % |
| Karara Mining Ltd |  |  | <1 | % |  |  | 15 | % |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001193125-13-324142:notes:23]
| 12. | Commitments and Contingencies |

[0001193125-13-324142:notes:24]
Commitments

[0001193125-13-324142:notes:25]
Purchase
Commitments

[0001193125-13-324142:notes:26]
The Company
periodically enters into non-cancelable purchase contracts in order
to ensure the availability of materials to support production of
its products. Purchase commitments represent enforceable and
legally binding agreements with suppliers to purchase goods or
services. The Company periodically assesses the need to provide for
impairment on these purchase contracts and record a loss on
purchase commitments when required. As of June 30, 2013, the
Company reported a liability for adverse purchase commitments of
$1.2 million. During the three months ended June 30, 2013, the
Company reduced its accrual for adverse purchase commitments by
$0.3 million due to payments to certain vendors.

[0001193125-13-324142:notes:27]
Legal
Contingencies

[0001193125-13-324142:notes:28]
From time to
time, the Company is involved in legal and administrative
proceedings and claims of various types. The Company records a
liability in its consolidated financial statements for these
matters when a loss is known or considered probable and the amount
can be reasonably estimated. The Company reviews these estimates
each accounting period as additional information is known and
adjusts the loss provision when appropriate. If a matter is both
probable to result in a liability and the amounts of loss can be
reasonably estimated, the Company estimates and discloses the
possible loss or range of loss. If the loss is not probable or
cannot be reasonably estimated, a liability is not recorded in its
consolidated financial statements.

[0001193125-13-324142:notes:29]
Between
April 6, 2011 and May 12, 2011, seven putative securities
class action complaints were filed against the Company and two of
its officers in the United States District Court for the District
of Massachusetts; one complaint additionally asserted claims
against the underwriters who participated in our November 12,
2010 securities offering. On June 7, 2011, the United
States District Court for the District of Massachusetts
consolidated these actions under the caption Lenartz v. American
Superconductor Corporation, et al., Docket
No. 1:11-cv-10582-WGY. On August 31, 2011, Lead
Plaintiff, the Plumbers and Pipefitters National Pension Fund,
filed a consolidated amended complaint against the Company, its
officers and directors, and the underwriters who participated in
our November 12, 2010 securities offering, asserting claims
under sections 10(b) and 20(a) of the Securities Exchange Act of
1934 and Rule 10b-5 promulgated under the Securities Exchange Act
of 1934 (the “Exchange Act”), as well as under
sections 11, 12(a)(2) and 15 of the Securities Act of 1933
(the “Securities Act”). The complaint alleges that
during the relevant class period, the Company and its officers
omitted to state material facts and made materially false and
misleading statements relating to, among other things, its
projected and recognized revenues and earnings, as well as its
relationship with Sinovel Wind Group Co., Ltd. that artificially
inflated the value of the Company’s stock price. The
complaint further alleges that the Company’s
November 12, 2010 securities offering contained untrue
statements of material facts and omitted to state material facts
required to be stated therein. The plaintiffs seek unspecified
damages, rescindment of the Company’s November 12, 2010
securities offering, and an award of costs and expenses, including
attorney’s fees. All defendants moved to dismiss the
consolidated amended complaint. On December 16, 2011, the
district court issued a summary order declining to dismiss the
Securities Act claims against the Company and its officers, and
taking under advisement the motion to dismiss the Exchange Act
claims against the Company and its officers and the motion to
dismiss the Securities Act claims made against the underwriters. On
July 26, 2012, the district court dismissed the Exchange Act
claims against the Company and its officers and denied the motion
to dismiss the Securities Act claims made against the underwriters.
On May 17, 2013, the parties informed the district court that
they had reached a settlement in principle, and requested a 30-day
stay of the proceedings while the specific terms of the settlement
continue to be negotiated. Based on the Company’s assessment
of the probable losses on this claim, the Company has recorded a
loss contingency of $1.8 million as of June 30,
2013.

[0001193125-13-324142:notes:30]
Between
May 4, 2011 and June 17, 2011, four putative shareholder
derivative complaints were filed against the Company (as a nominal
defendant) and certain of its directors in the United States
District Court for the District of Massachusetts. On
July 5, 2011, the District Court consolidated three of these
actions, and that matter is now captioned In re American
Superconductor Corporation Derivative Litigation, Docket
No. 1:11-cv-10784-WGY. On June 1, 2011, the
plaintiff in the fourth action, Marlborough Family Revocable
Trust v. Yurek, et al., moved to voluntarily dismiss its
complaint and refiled its complaint in Superior Court for the
Commonwealth of Massachusetts, Middlesex County. On
September 7, 2011, the Marlborough action and another
putative shareholder derivative complaint filed in Superior Court
for the Commonwealth of Massachusetts were consolidated. That
consolidated matter is captioned In re American Superconductor
Corporation Shareholder Derivative Litigation, Docket
No. 11-1961. On January 12, 2012, an additional
shareholder derivative complaint was filed in the Court of Chancery
for the State of Delaware. That matter is captioned Krasnoff v.
Budhraja, et al., Docket No. 7171. The allegations
of the derivative complaints mirror the allegations made in the
putative class action complaints described above. The
plaintiffs purport to assert claims against the director defendants
for breach of fiduciary duty, abuse of control, gross
mismanagement, unjust enrichment and corporate waste. The
plaintiffs seek unspecified damages on behalf of the Company, as
well as an award of costs and expenses, including attorney’s
fees.

[0001193125-13-324142:notes:31]
If a matter is
both probable to result in liability and the amount of loss can be
reasonably estimated, we estimate and disclose the possible loss or
range of possible loss. With respect to the above referenced
shareholder derivative litigation matters, an estimate of loss or
range of loss cannot be made. There are numerous factors that make
it difficult to meaningfully estimate possible loss or range of
loss at this stage of these litigation matters, including that: the
proceedings are in relatively early stages, there are significant
factual and legal issues to be resolved, information obtained or
rulings made during the lawsuits could affect the methodology for
calculation of rescission and the related statutory interest rate.
In addition, with respect to claims where damages are the requested
relief, no amount of loss or damages has been specified. Therefore,
the Company is unable at this time to estimate possible losses. The
Company believes that these litigations are without merit, and it
intends to defend these actions vigorously.

[0001193125-13-324142:notes:32]
On
September 13, 2011, the Company commenced a series of legal
actions in China against Sinovel Wind Group Co. Ltd.
(“Sinovel”). The Company’s Chinese subsidiary,
Suzhou AMSC Superconductor Co. Ltd., filed a claim for arbitration
with the Beijing Arbitration Commission in accordance with the
terms of the Company’s supply contracts with Sinovel. The
case is captioned (2011) Jing Zhong An Zi
No. 0963. On March 31, 2011, Sinovel refused to
accept contracted shipments of 1.5 megawatt, (“MW”) and
3 MW wind turbine core electrical components and spare parts that
the Company was prepared to deliver. The Company alleges that these
actions constitute material breaches of its contracts because
Sinovel did not give it notice that it intended to delay deliveries
as required under the contracts. Moreover, the Company alleges that
Sinovel has refused to pay past due amounts for prior shipments of
core electrical components and spare parts. The Company is seeking
compensation for past product shipments and retention (including
interest) in the amount of approximately RMB 485 million ($76
million) due to Sinovel’s breaches of its contracts. The
Company is also seeking specific performance of our existing
contracts as well as reimbursement of all costs and reasonable
expenses with respect to the arbitration. The value of the
undelivered components under the existing contracts, including the
deliveries refused by Sinovel in March 2011, amounts to
approximately RMB 4.6 billion ($720 million).

[0001193125-13-324142:notes:33]
On
October 8, 2011, Sinovel filed with the Beijing Arbitration
Commission an application under the caption (2011) Jing
Zhong An Zi No. 0963, for a counterclaim against the
Company for breach of the same contracts under which the Company
filed its original arbitration claim. Sinovel claimed, among other
things, that the goods supplied by the Company do not conform to
the standards specified in the contracts and claimed damages in the
amount of approximately RMB 370 million ($58 million). On
October 17, 2011, Sinovel filed with the Beijing Arbitration
Commission a request for change of counterclaim to increase its
damage claim to approximately RMB 1 billion ($157 million). On
December 22, 2011, Sinovel filed with the Beijing Arbitration
Commission an additional request for change of counterclaim to
increase its damages claim to approximately RMB 1.2 billion ($190
million). On February 27, 2012, Sinovel filed with the Beijing
Arbitration Commission an application under the caption
(2012) Jing Zhong An Zi No. 0157, against the
Company for breach of the same contracts under which the Company
filed its original arbitration claim. Sinovel claimed, among other
things, that the goods supplied by the Company do not conform to
the standards specified in the contracts and claimed damages in the
amount of approximately RMB 105 million ($17 million). The
Company believes that Sinovel’s claims are without merit and
it intends to defend these actions vigorously. Since the
proceedings in this matter are in relatively early stages, the
Company cannot reasonably estimate possible losses or range of
losses at this time.

[0001193125-13-324142:notes:34]
The Company
also submitted a civil action application to the Beijing No. 1
Intermediate People’s Court under the caption
(2011) Yi Zhong Min Chu Zi No. 15524, against
Sinovel for software copyright infringement on September 13,
2011. The application alleges Sinovel’s unauthorized use of
portions of the Company’s wind turbine control software
source code developed for Sinovel’s 1.5MW wind turbines and
the binary code, or upper layer, of the Company’s software
for the PM3000 power converters in 1.5MW wind turbines. In July
2011, a former employee of the Company’s Austrian subsidiary
was arrested in Austria on charges of economic espionage and
fraudulent manipulation of data. In September 2011, the former
employee pled guilty to the charges, and was imprisoned. As a
result of the Company’s internal investigation and a criminal
investigation conducted by Austrian authorities, the Company
believes that this former employee was contracted by Sinovel
through an intermediary while employed by the Company and
improperly obtained and transferred to Sinovel portions of its wind
turbine control software source code developed for Sinovel’s
1.5MW wind turbines. Moreover, the Company believes the former
employee illegally used source code to develop for Sinovel a
software modification to circumvent the encryption and remove
technical protection measures on the Company’s PM3000 power
converters in 1.5MW wind turbines in the field. The Company is
seeking a cease and desist order with respect to the unauthorized
copying, installation and use of its software, monetary damages of
approximately RMB 38 million ($6 million) for our economic
losses and reimbursement of all costs and reasonable expenses. The
Beijing No. 1 Intermediate People’s Court accepted the
case, which was necessary in order for the case to proceed. In
November 2011, Sinovel filed a motion to remove this case from the
Beijing No. 1 Intermediate People’s Court and transfer
the matter to the Beijing Arbitration Commission. On
February 14, 2012, the court denied Sinovel’s motion to
remove the case. On February 21, 2012, Sinovel filed an appeal
of the Beijing No. 1 Intermediate People’s Court
decision to the Beijing Higher People’s Court. On
April 25, 2012, the Beijing Higher People’s Court issued
a final Civil Ruling which supports the Beijing No.1 Intermediate
People’s Court’s civil ruling and rejected
Sinovel’s appeal. Sinovel filed an appeal of the Beijing
Higher People’s Court’s decision with China’s
Supreme People’s Court. A hearing regarding this appeal was
held at the Chinese Supreme People’s Court on
October 26, 2012. On November 23, 2012, China’s
Supreme People’s Court issued a Civil Ruling, holding that
(1) it will conduct a re-trial of Sinovel’s appeal, and
(2) the lower court’s decision will be stayed pending
the re-trial. China’s Supreme People’s Court conducted
a re-trial of Sinovel’s appeal on May 29,
2013.

[0001193125-13-324142:notes:35]
Sinovel filed a
new motion on June 18, 2012, to remove this case from the
Beijing No. 1 Intermediate People’s Court to the court
located in Gansu Province. On October 19, 2012, the court
disallowed Sinovel’s motion due to its late
filing.

[0001193125-13-324142:notes:36]
The Company
submitted a civil action application to the Beijing Higher
People’s Court against Sinovel and certain of its employees
for trade secret infringement on September 13, 2011 under the
caption (2011) Gao Min Chu Zi No. 4193. The
application alleges the defendants’ unauthorized use of
portions of the Company’s wind turbine control software
source code developed for Sinovel’s 1.5MW wind turbines as
described above with respect to the Copyright Action. The Company
is seeking monetary damages of RMB 2.9 billion ($453 million) for
the trade secret infringement as well as reimbursement of all costs
and reasonable expenses. The Beijing Higher People’s Court
accepted the case, which was necessary in order for the case to
proceed. On December 22, 2011, the Beijing Higher
People’s Court transferred this case to the Beijing
No. 1 Intermediate People’s Court under the caption
(2011) Gao Min Chu Zi No. 4193. On June 7,
2012, the Company received an Acceptance Notice from the Beijing
No.1 Intermediate People’s Court under the caption
(2012) Yi Zhong Min Chu Zi No.6833. The Company is
currently awaiting notice from the Beijing No. 1 Intermediate
People’s Court regarding the first hearing date. In August
2012, Sinovel filed a motion to remove this case from the Beijing
No. 1 Intermediate People’s Court and transfer the
matter to the Beijing Arbitration Commission.

[0001193125-13-324142:notes:37]
On
September 16, 2011, the Company filed a civil copyright
infringement complaint in the Hainan Province No. 1
Intermediate People’s Court against Dalian Guotong Electric
Co. Ltd. (“Guotong”), a supplier of power converter
products to Sinovel, and Huaneng Hainan Power, Inc.
(“Huaneng”), a wind farm operator that has purchased
Sinovel wind turbines containing Guotong power converter products.
The case is captioned (2011) Hainan Yi Zhong Min Chu Zi
No. 62. The application alleges that the Company’s
PM1000 converters in certain Sinovel wind turbines have been
replaced by converters produced by Guotong. Because the Guotong
converters are being used in wind turbines containing the
Company’s wind turbine control software, the Company believes
that its copyrighted software is being infringed. The Company is
seeking a cease and desist order with respect to the unauthorized
use of its software, monetary damages of RMB 1.2 million ($0.2
million) for its economic losses (with respect to Guotong only) and
reimbursement of all costs and reasonable expenses. The court has
accepted the case, which was necessary in order for the case to
proceed. In addition, upon the request of the defendant Huaneng,
Sinovel has been added by the court to this case as a defendant and
Huaneng has been released from this case. In December 2011, Sinovel
filed a jurisdiction opposition motion requesting dismissal by the
Hainan Province No. 1 Intermediate People’s Court,
saying the case should be governed by the Beijing Arbitration
Commission. On February 3, 2012, the Company received the
Civil Ruling from the court, which granted Sinovel’s motion,
and dismissed the entire case. The Company appealed the
court’s ruling to the Hainan Higher Court, which on
April 5, 2012 upheld the decision of the Hainan Province
No. 1 Intermediate People’s Court. On April 9,
2012, the Company filed an appeal of the Hainan Higher
Court’s decision with China’s Supreme People’s
Court. China’s Supreme People’s Court accepted the
appeal on May 23, 2012. The case is captioned, (2012) Min
Shen Zi No. 630. On December 20, 2012, China’s
Supreme People’s Court issued a Civil ruling, holding that
(1) it will conduct a re-trial of the Company’s appeal
and (2) the lower court’s decision will be stayed
pending the re-trial. China’s Supreme People’s Court
conducted a re-trial of Sinovel’s appeal on May 29,
2013.

[0001193125-13-324142:notes:38]
Ghodawat Energy
Pvt Ltd (“Ghodawat”), a company registered in India
carrying on the business of wind power development, lodged a
Request for Arbitration with the Secretariat of the ICC
International Court of Arbitration on May 12, 2011 and named
AMSC Windtec GmbH (“AMSC Austria”) as the Respondent.
Under the Request for Arbitration, Ghodawat alleges that AMSC
Austria breached an agreement dated March 19, 2008 pursuant to
which AMSC Austria granted a license to Ghodawat to manufacture,
use, sell, market, erect, commission and maintain certain wind
turbines using its technical information and wind turbine design
(the “License Agreement”). Under the Request for
Arbitration, Ghodawat’s claims in this arbitration amount to
approximately €18 million ($24 million). AMSC Austria
filed an Answer to Request for Arbitration and Counterclaim
(“Answer and Counterclaim”), in which AMSC Austria
denied Ghodawat’s claims in their entirety. AMSC Austria
has also submitted counterclaims under the License Agreement
against Ghodawat in the amount of approximately
€6 million ($9 million). Ghodawat has filed a Reply
to Answer to Request for Arbitration and Counterclaim in which it
denies AMSC Austria’s counterclaims. On June 3, 2013,
the final oral submissions hearing was conducted and the Company
believes it will take several months for the Tribunal to render a
decision. The Company has recorded a loss contingency based on its
assessment of probable losses on this claim; however this amount is
immaterial to its consolidated financial statements.

[0001193125-13-324142:notes:39]
Other

[0001193125-13-324142:notes:40]
The Company
enters into long-term construction contracts with customers that
require the Company to obtain performance bonds. The Company is
required to deposit an amount equivalent to some or all the face
amount of the performance bonds into an escrow account until the
termination of the bond. When the performance conditions are met,
amounts deposited as collateral for the performance bonds are
returned to the Company. In addition, the Company has various
contractual arrangements in which minimum quantities of goods or
services have been committed to be purchased on an annual
basis.

[0001193125-13-324142:notes:41]
As of
June 30, 2013 the Company had $0.8 million of restricted cash
included in current assets, and $6.1 million of restricted cash
included in long-term assets. These amounts included in restricted
cash represent deposits to secure letters of credit for various
supply contracts. These deposits are held in interest bearing
accounts.

[0001193125-13-324142:notes:42]
As of
June 30, 2013, the Company had one performance bond in support
of customer contracts. The total value of the outstanding
performance bond is $0.2 million with an expiration date of March
2014. In the event that the payment is made in accordance with the
requirements of any of these performance bonds, the Company would
record the payment as an offset to revenue.

[0001193125-13-324142:notes:43]
The Company had
an unused, unsecured line of credit consisting of
€2.7 million (approximately $3.5 million) in Austria as
of June 30, 2013.


## us-gaap:ScheduleOfRestructuringAndRelatedCostsTextBlock

[0001193125-13-324142:notes:44]
The following
table presents restructuring charges and cash payments (in
thousands):

[0001193125-13-324142:notes:45]
|  |  | Severance pay and benefits |  |  | Facility exit costs |  |  | Total |  |
| Three months ended June 30, 2013 |  |  |  |  |  |  |  |  |  |  |  |  |
| Accrued restructuring balance at April 1, 2013 |  | $ | 199 |  |  |  | — |  |  | $ | 199 |  |
| Charges to operations |  |  | 13 |  |  |  | — |  |  |  | 13 |  |
| Cash payments |  |  | (136 | ) |  |  | — |  |  |  | (136 | ) |
| Accrued restructuring balance at June 30, 2013 |  | $ | 76 |  |  | $ | — |  |  | $ | 76 |  |
| Three months ended June 30, 2012 |  |  |  |  |  |  |  |  |  |  |  |  |
| Accrued restructuring balance at April 1, 2012 |  | $ | 680 |  |  | $ | 294 |  |  | $ | 974 |  |
| Charges to operations |  |  | 167 |  |  |  | (39 | ) |  |  | 128 |  |
| Cash payments |  |  | (269 | ) |  |  | (255 | ) |  |  | (524 | ) |
| Accrued restructuring balance at June 30, 2012 |  | $ | 578 |  |  | $ | — |  |  | $ | 578 |  |


## us-gaap:DebtDisclosureTextBlock

[0001193125-13-324142:notes:46]
| 10. | Debt |

[0001193125-13-324142:notes:47]
Senior
Convertible Note

[0001193125-13-324142:notes:48]
On
April 4, 2012, the Company entered into a Securities Purchase
Agreement with Capital Ventures International (“CVI”),
an affiliate of Heights Capital Management (the “Purchase
Agreement”) and completed a private placement of the Initial
Note, a 7% unsecured senior convertible note. After fees and
expenses, the net proceeds of the Initial Note were $23.2 million.
The Initial Note had an initial conversion price of $4.85 per
share, representing a premium of approximately 20% over
AMSC’s closing price on April 3, 2012. The Initial Note
was payable in monthly installments beginning four months from
issuance and ending on October 4, 2014. Monthly payments were
payable in cash or the Company’s common stock at the option
of the Company, subject to certain trading volume, stock price and
other conditions. CVI could have also elected to defer receipt of
monthly installment payments at its option. Any deferred
installment payments would have continued to accrue interest. The
Company registered 10,262,311 shares of common stock which may be
used as payment for principal and interest in lieu of cash for
resale under the Securities Act as required under a Registration
Rights Agreement with CVI.

[0001193125-13-324142:notes:49]
The Company
accounted for the Initial Note as an instrument that has the
characteristics of a debt host contract containing several embedded
derivative features that would require bifurcation and separate
accounting as a derivative instrument pursuant to the provisions of
ASC 815. The Company elected not to use the fair value option for
the aggregate amount of the Exchanged Note and recorded the
liability at its stated value on the date of issuance with no
changes in fair value reported in subsequent periods.

[0001193125-13-324142:notes:50]
The Company has
identified the following derivatives associated with the Initial
Note: holder change of control redemption rights; issuer optional
redemption rights; sale redemption rights and a feature to convert
the Initial Note into equity at the holder’s option. The
Company valued these derivatives at $3.8 million upon issuance of
the Initial Note. (See Note 11, “Warrants and Derivative
Liabilities,” for additional information regarding derivative
liabilities.)

[0001193125-13-324142:notes:51]
In conjunction
with the Initial Note, CVI received a warrant to purchase
approximately 3.1 million additional shares of common stock
exercisable at a strike price of $5.45 per share, subject to
adjustment, until October 4, 2017. Due to certain adjustment
provisions within the warrant, it qualified for liability
accounting and had a fair value of $7.0 million upon issuance. The
Company recorded the value as a debt discount and a warrant
liability. (See Note 11, “Warrants and Derivative
Liabilities,” for additional information regarding the
warrant.)

[0001193125-13-324142:notes:52]
The process of
valuing financial and derivative instruments utilizes facts and
circumstances as of the measurement date as well as certain inputs,
assumptions, and judgments that may affect the estimated fair value
of the instruments. Upon issuance of the Initial Note, the Company
determined the initial carrying value of the Initial Note to be
$25.0 million. In addition, the Company also incurred $1.8 million
of legal and origination costs as of the year ended March 31,
2013, which have been recorded as a discount on the Initial
Note.

[0001193125-13-324142:notes:53]
On
December 20, 2012, the Company entered into an Amendment and
Exchange Agreement, (the “Amendment”) with CVI, which
amended the Purchase Agreement. Pursuant to the Amendment, the
Company and CVI exchanged the Initial Note for the Exchanged Note.
At the time of the exchange, the Exchanged Note had the same
principal amount and accrued interest as the Initial Note. The
Exchanged Note is convertible into the Company’s common stock
and has the same scheduled monthly installment payments as the
Initial Note. The Exchanged Note provides the Company with
additional flexibility to make monthly installment payments in
shares of the Company’s common stock. The Company retains the
ability to repay the Exchanged Note in cash. Specifically, the
amendments to the Exchanged Note:

[0001193125-13-324142:notes:54]
|  | • |  | Allow the Company to convert, subject to the satisfaction of certain conditions set forth in the Exchanged Note, (a) at least $2.5 million of the approximately $5.3 million installment amount payable with respect to the January 2013 installment date (including approximately $4.2 million of deferred installment amounts from the period September 4, 2012 to December 3, 2012) into shares of the Company’s common stock (on December 21, 2012 the Company converted $3.8 million in deferred installment amount principal and interest and issued 1,715,443 shares of common stock), and (b) the balance of the January 2013 installment amount in equal amounts on each of the February and March 2013 installment dates; |

[0001193125-13-324142:notes:55]
|  | • |  | Reduce the price failure equity condition with respect to a particular date of determination from $2.50 to $1.00; |

[0001193125-13-324142:notes:56]
|  | • |  | Reduce the aggregate daily dollar trading volume equity condition required for at least 25 of the 30 consecutive trading days immediately preceding a date of determination from $1,500,000 to $850,000 per trading day. In addition, if the aggregate daily dollar trading volume is between $50,000 and $850,000, the Company may still convert into common stock a portion of an installment amount payable with respect to an installment date equal to the quotient of (x) the aggregate daily dollar trading volume, divided by (y) $850,000; |

[0001193125-13-324142:notes:57]
|  | • |  | Increase CVI’s beneficial ownership limitation under the Exchanged Note from 4.99% to 9.99%; and |

[0001193125-13-324142:notes:58]
|  | • |  | Reduce the conversion price, from $4.85 per share of the Company’s common stock to $3.19 per share of the Company’s common stock, subject to certain price-based and other anti-dilution adjustments. |

[0001193125-13-324142:notes:59]
The Company
assessed the changes in the Exchanged Note and accounted for it as
a modification of the Initial Note. Therefore, the Company
determined the incremental value of the derivative instruments, as
a result of the Exchanged Note, as having a reduced conversion
price. As a result of the re-valuation, the Company recorded a $0.5
million increase in the value of the derivative liability and
additional debt discount. At the modification date, the value of
the derivative liability was $1.5 million. The total debt discount,
including the embedded derivatives in the Initial Note, the
incremental value of embedded derivatives in the Exchanged Note,
warrant and legal and origination costs of $13.1 million is being
amortized into interest expense over the term of the Exchanged Note
using the effective interest method. Under this method, interest
expense is recognized each period until the debt instruments reach
maturity. If the maturity of the Exchanged Note is accelerated
because of prepayment, then the amortization will be accelerated.
During the three months ended June 30, 2013, and 2012 the
Company recorded non-cash interest expense for amortization of the
debt discount related to the convertible notes of $1.5 million and
$2.2 million, respectively.

[0001193125-13-324142:notes:60]
Provided
certain equity conditions are met, the Company may elect to repay
principal and interest in shares of the Company’s common
stock. If the Company elects to make a payment in shares of the
Company’s common stock, the number of shares to be issued is
determined by dividing the amount of such payment by 85% of the
lessor of the average volume-weighted average price
(“VWAP”) of the 10 consecutive days immediately
preceding the payment date or the VWAP price on the day preceding
the payment date (the “Market Price”). The Company
records the difference between the closing price of its common
stock on the day preceding the payment date and the Market Price as
a discount on the fair value of its shares. During the three months
ended June 30, 2013, the Company recorded $0.1 million of
non-cash interest expense related to installment payments made by
issuing the Company’s common stock at a discount.

[0001193125-13-324142:notes:61]
The Exchanged
Note and Purchase Agreement contain certain covenants and
restrictions, including, among others, that for so long as the
Exchanged Note is outstanding, the Company will not incur any
indebtedness (other than permitted indebtedness under the Exchanged
Note), permit liens on its properties (other than permitted liens
under the Exchanged Note), make payments on junior securities or
declare dividends. The Exchanged Note also contains limitations on
the transfer of certain assets. Events of default under the
Exchanged Note include failure to pay principal or interest as due
on the Exchanged Note, failure to deliver registered shares of
common stock upon the holders request for conversion of part or all
of the Exchanged Note, failure to maintain the Company’s
common stock eligible for trading on defined markets, cross
defaults to other material indebtedness, receipt of uninsured
judgments against the Company in excess of defined limits and other
administrative covenants, including the Term Loan discussed below,
as defined in the Exchanged Note and related documentation. Upon an
event of default, the holders may require the Company to redeem all
or any portion of the outstanding principal amount of the Exchanged
Note in cash plus a penalty as specified in the agreement. Also, if
the Company fails to maintain an effective registration statement
covering common stock to be used in settling obligations under the
Exchanged Note, the Company will be required to pay a penalty as
specified in the agreement.

[0001193125-13-324142:notes:62]
Senior
Secured Term Loan

[0001193125-13-324142:notes:63]
On June 5,
2012, the Company entered into a Term Loan with Hercules Technology
Growth Capital, Inc. (“Hercules”), under which the
Company borrowed $10.0 million (the “Term Loan”). After
the closing fees and expenses, the net proceeds to the Company were
$9.7 million. The Term Loan bears an interest rate equal to 11%
plus the percentage, if any, by which the prime rate as reported by
The Wall Street Journal exceeds 3.75%. The Company made
interest-only payments from July 1, 2012 through
October 31, 2012, after which the Company repays the loan in
equal monthly installments ending on December 1, 2014. The
Term Loan is secured by substantially all of the Company’s
existing and future assets, including a mortgage on real property
owned by the Company’s wholly-owned subsidiary, ASC Devens
LLC, and located at 64 Jackson Road, Devens, Massachusetts. In
addition, Hercules received a warrant to purchase 139,276 shares of
common stock, exercisable at an initial strike price of $3.59 per
share, subject to adjustment, until December 5, 2017. Due to
certain adjustment provisions within the warrant, it qualified for
liability accounting and the fair value of $0.4 million was
recorded upon issuance, which the Company recorded as a debt
discount and a warrant liability. (See Note 11, “Warrants and
Derivative Liabilities,” for a discussion on warrants and the
valuation assumptions used.) The Company will pay an end of term
fee of $0.5 million upon the earlier of maturity or prepayment of
the loan. The Company has accrued this as of the year ended
March 31, 2013 and recorded a corresponding amount into the
debt discount. In addition, the Company incurred $0.3 million of
legal and origination costs in the year ended March 31, 2013,
which have been recorded as a debt discount. The total debt
discount including the warrant, end of term fee and legal and
origination costs of $1.2 million is being amortized into interest
expense over the term of the Term Loan using the effective interest
method. Under this method, interest expense is recognized each
period until the debt instrument reaches maturity. If the maturity
of the Term Loan is accelerated because of prepayment, then the
amortization will be accelerated. During the three months ended
June 30, 2013 and 2012, the Company recorded non-cash interest
expense for amortization of the debt discount related to the Term
Loan of $0.1 million and $0.1 million, respectively.

[0001193125-13-324142:notes:64]
The Term Loan
contains certain covenants that restrict the Company’s
ability to, among other things, incur or assume certain debt, merge
or consolidate, materially change the nature of our business, make
certain investments, acquire or dispose of certain assets, make
guaranties or grant liens on its assets, make certain loans,
advances or investments, declare dividends or make distributions or
enter into transactions with affiliates. In addition, the Term Loan
contains a covenant that requires the Company to maintain a minimum
unrestricted cash balance in the United States of at least $10.0
million at the inception of the Term Loan, which decreased starting
November 1, 2012 and monthly thereafter by the amount of
principal paid. The events of default under the Term Loan include,
but are not limited to, failure to pay amounts due, breaches of
covenants, bankruptcy events, cross defaults under other material
indebtedness and the occurrence of a material adverse effect and/or
change in control. In the case of a continuing event of
default, the Lender may, among other remedies, declare due all
unpaid principal amounts outstanding and any accrued but unpaid
interest and foreclose on all collateral granted to the Lender as
security under the Term Loan.

[0001193125-13-324142:notes:65]
Although the
Company believes that it is in and expects to remain in compliance
with the covenants and restrictions under the Exchanged Notes and
Term Loan as of the date of this Quarterly Report on Form 10-Q,
there can be no assurance that the Company will continue to be in
compliance.

[0001193125-13-324142:notes:66]
Interest
expense on the Exchanged Note and Term Loan for the three months
ended June 30, 2013 and 2012 was $2.1 million, and $2.7
million, respectively, which included $1.7 million and $2.3
million, respectively, of non-cash interest expense related to the
amortization of the debt discount on the Exchanged Note and Term
Loan and payment of the Exchanged Note in Company common stock at a
discount.


## us-gaap:LoansNotesTradeAndOtherReceivablesDisclosureTextBlock

[0001193125-13-324142:notes:67]
| 5. | Accounts Receivable |

[0001193125-13-324142:notes:68]
Accounts
receivable at June 30, 2013 and March 31, 2013 consisted
of the following (in thousands):

[0001193125-13-324142:notes:69]
|  |  | June 30, 2013 |  |  | March 31, 2013 |  |
| Accounts receivable (billed) |  | $ | 9,225 |  |  | $ | 17,222 |  |
| Accounts receivable (unbilled) |  |  | 1,863 |  |  |  | 1,642 |  |
| Less: Allowance for doubtful accounts |  |  | — |  |  |  | — |  |
| Accounts receivable, net |  | $ | 11,088 |  |  | $ | 18,864 |  |


## us-gaap:FairValueDisclosuresTextBlock

[0001193125-13-324142:notes:70]
| 4. | Fair Value Measurements |

[0001193125-13-324142:notes:71]
In January
2010, the Financial Accounting Standards Board (“FASB”)
issued guidance related to disclosures of fair value measurements.
The guidance requires gross presentation of activity within the
Level 3 measurement roll-forward and details of transfers in
and out of Level 1 and 2 measurements. It also clarifies two
existing disclosure requirements on the level of disaggregation of
fair value measurements and disclosures on inputs and valuation
techniques. A change in the hierarchy of an investment from its
current level will be reflected in the period during which the
pricing methodology of such investment changes. Disclosure of the
transfer of securities from Level 1 to Level 2 or
Level 3 will be made in the event that the related security is
significant to total cash and investments. The Company did not have
any transfers of assets and liabilities between Level 1,
Level 2 and Level 3 of the fair value measurement hierarchy
during the three months ended June 30, 2013.

[0001193125-13-324142:notes:72]
A valuation
hierarchy for disclosure of the inputs to valuation used to measure
fair value has been established. This hierarchy prioritizes the
inputs into three broad levels as follows:

[0001193125-13-324142:notes:73]
| Level 1 - |  | Inputs are unadjusted quoted prices in active markets for identical assets or liabilities that the Company has the ability to access at the measurement date. |
| Level 2 - |  | Inputs include quoted prices for similar assets and liabilities in active markets, quoted prices for identical or similar assets or liabilities in markets that are not active, inputs other than quoted prices that are observable for the asset or liability, and inputs that are derived principally from or corroborated by observable market data by correlation or other means (market corroborated inputs). |
| Level 3 - |  | Unobservable inputs that reflect the Company’s assumptions that market participants would use in pricing the asset or liability. The Company develops these inputs based on the best information available, including its own data. |

[0001193125-13-324142:notes:74]
A financial
asset’s or liability’s classification within the
hierarchy is determined based on the lowest level input that is
significant to the fair value measurement.

[0001193125-13-324142:notes:75]
The following
table provides the assets carried at fair value, measured as of
June 30, 2013 and March 31, 2013 (in
thousands):

[0001193125-13-324142:notes:76]
|  |  | Total Carrying Value |  |  | Quoted Prices in Active Markets (Level 1) |  |  | Significant Other Observable Inputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |
| June 30, 2013: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash equivalents |  | $ | 18,658 |  |  | $ | 18,658 |  |  | $ | — |  |  | $ | — |  |
| Liabilities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Derivative liability |  | $ | 477 |  |  | $ | — |  |  | $ | — |  |  | $ | 477 |  |
| Warrants |  | $ | 3,216 |  |  | $ | — |  |  | $ | — |  |  | $ | 3,216 |  |
|  |  | Total Carrying Value |  |  | Quoted Prices in Active Markets (Level 1) |  |  | Using Significant Other Observable Inputs (Level 2) |  |  | Using Significant Unobservable Inputs (Level 3) |  |
| March 31, 2013: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash equivalents |  | $ | 18,649 |  |  | $ | 18,649 |  |  | $ | — |  |  | $ | — |  |
| Liabilities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Derivative liability |  | $ | 529 |  |  | $ | — |  |  | $ | — |  |  | $ | 529 |  |
| Warrants |  | $ | 3,633 |  |  | $ | — |  |  | $ | — |  |  | $ | 3,633 |  |

[0001193125-13-324142:notes:77]
The table below
reflects the activity for the Company’s major classes of
liabilities measured at fair value for the period ended
June 30, 2013 (in thousands).

[0001193125-13-324142:notes:78]
|  |  | Derivative Liability |  |  | Warrants |  |
| April 1, 2013 |  | $ | 529 |  |  | $ | 3,633 |  |
| Mark to market adjustment |  |  | (52 | ) |  |  | (417 | ) |
| Balance at June 30, 2013 |  | $ | 477 |  |  | $ | 3,216 |  |
|  |  | Derivative Liability |  |  | Warrants |  |
| April 1, 2012 |  | $ | — |  |  | $ | — |  |
| Valuation of derivative liability |  |  | 3,779 |  |  |  | — |  |
| Warrant issuance with Senior Convertible Notes |  |  | — |  |  |  | 7,018 |  |
| Warrant issuance with Senior Secured Term Loan |  |  | — |  |  |  | 380 |  |
| Valuation of derivative liability attributable to modification |  |  | 542 |  |  |  | — |  |
| Mark to market adjustment |  |  | (3,792 | ) |  |  | (3,765 | ) |
| Balance at March 31, 2013 |  | $ | 529 |  |  | $ | 3,633 |  |

[0001193125-13-324142:notes:79]
Valuation
Techniques

[0001193125-13-324142:notes:80]
Cash
Equivalents

[0001193125-13-324142:notes:81]
Cash
equivalents consist of highly liquid instruments with maturities of
three months or less that are regarded as high quality, low risk
investments and are measured using such inputs as quoted prices,
and are classified within Level 1 of the valuation hierarchy. Cash
equivalents consist principally of certificates of deposits and
money market accounts.

[0001193125-13-324142:notes:82]
Derivative
Liability

[0001193125-13-324142:notes:83]
The Company has
identified all of the derivatives (“Derivative
Liability”) associated with the Exchanged Note which include
put rights to require the investor to acquire an additional $15.0
million convertible note and additional warrants, holder change of
control redemption rights, issuer optional redemption rights, sale
redemption rights and a right to make payment in the form of stock
rather than cash if certain equity conditions are met. The
Derivative Liability is subject to revaluation at each balance
sheet date, and any change in fair value will be recorded as a
change in fair value in other income (expense) until the earlier of
its exercise or expiration. The Company relies on assumptions in a
lattice model to determine the fair value of Derivative Liability.
The Company has appropriately valued the Derivative Liability
within Level 3 of the valuation hierarchy. See Note 10,
“Debt”, for discussion on the Exchanged Note,
Derivative Liability and valuation assumptions used.

[0001193125-13-324142:notes:84]
[same as prior period, unchanged from 0001193125-13-048834:notes:111]

[0001193125-13-324142:notes:85]
Warrants were
issued in conjunction with the Initial Note and the Term Loan. See
Note 10, “Debt”, for additional information on
warrants. These warrants are subject to revaluation at each balance
sheet date, and any change in fair value will be recorded as a
change in fair value in other income (expense) until the earlier of
their exercise or expiration.

[0001193125-13-324142:notes:86]
The Company
relies on assumptions used in a lattice model to determine the fair
value of warrants. The Company has appropriately valued the
warrants within Level 3 of the valuation hierarchy. See Note 11,
“Warrants and Derivative Liabilities”, for a discussion
of the warrants and the valuation assumptions used.


## us-gaap:FairValueByBalanceSheetGroupingTextBlock

[0001193125-13-324142:notes:87]
Following is a summary of the key assumptions
used to value the convertible notes derivative feature:

[0001193125-13-324142:notes:88]
|  |  | June 30, |  |
|  |  | 2013 |  |
| Fiscal Year 2013 |  |  |  |  |
| Principal Outstanding (000’s) |  | $ | 14,389 |  |
| Stock Price |  | $ | 2.64 |  |
| Percentage Volume Condition Met |  |  | 87.5 | % |
| Expected Volatility |  |  | 65.8 | % |
| Risk Free Rate |  |  | 0.21 | % |
| Bond Yield |  |  | 16.7 | % |
| Recovery Rate |  |  | 37.0 | % |
| Redeemable |  |  | yes |  |
| Total Time (years) |  |  | 1.26 |  |
| Dilution Effect |  |  | yes |  |
| Fair Value |  | $ | 0.5 million |  |
| Fair Value as a Percent of Par |  |  | 3.3 | % |

[0001193125-13-324142:notes:89]
|  |  |  |  |  |  |  |  | Post- modification |  |  | Pre-modification |  |  |  |  |  |  |  |  |  |  |
|  |  | March 31, |  |  | December 31, |  |  | December 20, |  |  | December 20, |  |  | September 30, |  |  | June 30, |  |  | April 4, |  |
|  |  | 2013 |  |  | 2012 |  |  | 2012 |  |  | 2012 |  |  | 2012 |  |  | 2012 |  |  | 2012 |  |
| Fiscal Year 2012 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Principal Outstanding (000’s) |  | $ | 15,380 |  |  | $ | 20,944 |  |  | $ | 20,944 |  |  | $ | 24,617 |  |  | $ | 24,191 |  |  | $ | 25,278 |  |  | $ | 25,000 |  |
| Stock Price |  | $ | 2.67 |  |  | $ | 2.62 |  |  | $ | 2.95 |  |  | $ | 2.95 |  |  | $ | 4.15 |  |  | $ | 4.68 |  |  | $ | 3.97 |  |
| Percentage Volume Condition Met |  |  | 80.5 | % |  |  | 94.5 | % |  |  | 94.9 | % |  |  | 28.6 | % |  |  | 51.0 | % |  |  | 75.2 | % |  |  | 85.9 | % |
| Expected Volatility |  |  | 66.9 | % |  |  | 73.5 | % |  |  | 72.5 | % |  |  | 72.5 | % |  |  | 70.0 | % |  |  | 71.0 | % |  |  | 75.0 | % |
| Risk Free Rate |  |  | 0.20 | % |  |  | 0.23 | % |  |  | 0.25 | % |  |  | 0.25 | % |  |  | 0.23 | % |  |  | 0.33 | % |  |  | 0.44 | % |
| Bond Yield |  |  | 16.5 | % |  |  | 16.5 | % |  |  | 16.5 | % |  |  | 16.5 | % |  |  | 15.0 | % |  |  | 16.0 | % |  |  | 15.0 | % |
| Recovery Rate |  |  | 30.0 | % |  |  | 30.0 | % |  |  | 30.0 | % |  |  | 30.0 | % |  |  | 30.0 | % |  |  | 30.0 | % |  |  | 30.0 | % |
| Redeemable |  |  | yes |  |  |  | yes |  |  |  | yes |  |  |  | yes |  |  |  | yes |  |  |  | yes |  |  |  | yes |  |
| Total Time (years) |  |  | 1.51 |  |  |  | 1.76 |  |  |  | 1.79 |  |  |  | 1.79 |  |  |  | 2.01 |  |  |  | 2.28 |  |  |  | 2.5 |  |
| Dilution Effect |  |  | yes |  |  |  | yes |  |  |  | yes |  |  |  | yes |  |  |  | yes |  |  |  | yes |  |  |  | yes |  |
| Fair Value as a Percent of Par |  |  | 3.4 | % |  |  | 4.9 | % |  |  | 7.1 | % |  |  | 3.9 | % |  |  | 11.4 | % |  |  | 17.9 | % |  |  | 15.1 | % |
| Fair Value |  | $ | 0.5 million |  |  | $ | 1.0 million |  |  | $ | 1.5 million |  |  | $ | 0.9 million |  |  | $ | 2.8 million |  |  | $ | 4.5 million |  |  | $ | 3.8 million |  |


## us-gaap:InventoryDisclosureTextBlock

[0001193125-13-324142:notes:90]
| 6. | Inventory |

[0001193125-13-324142:notes:91]
The components
of inventory at June 30, 2013 and March 31, 2013 are as
follows (in thousands):

[0001193125-13-324142:notes:92]
|  |  | June 30, 2013 |  |  | March 31, 2013 |  |
| Raw materials |  | $ | 6,423 |  |  | $ | 5,966 |  |
| Work-in-process |  |  | 3,730 |  |  |  | 3,427 |  |
| Finished goods |  |  | 17,914 |  |  |  | 21,655 |  |
| Deferred program costs |  |  | 2,685 |  |  |  | 2,425 |  |
| Net inventory |  | $ | 30,752 |  |  | $ | 33,473 |  |

[0001193125-13-324142:notes:93]
For the three
months ended June 30, 2013, the Company recorded an inventory
write-down of approximately $0.2 million based on evaluating its
ending inventory on hand for excess quantities and
obsolescence.

[0001193125-13-324142:notes:94]
Deferred
program costs as of June 30, 2013 and March 31, 2013
primarily represent costs incurred on programs accounted for
under contract accounting where the Company needs to complete
development programs before revenue and costs will be recognized,
respectively.


## us-gaap:AccountsPayableAndAccruedLiabilitiesDisclosureTextBlock

[0001193125-13-324142:notes:95]
| 7. | Accounts Payable and Accrued Expenses |

[0001193125-13-324142:notes:96]
The Company generally provides a one to three year warranty on
its products, commencing upon installation. A provision is recorded
upon revenue recognition to cost of revenues for estimated warranty
expense based on historical experience.

[0001193125-13-324142:notes:97]
Product warranty activity was as follows (in
thousands):

[0001193125-13-324142:notes:98]
|  |  | Three months ended June 30, |  |
|  |  | 2013 |  |  | 2012 |  |
| Balance at beginning of period |  | $ | 2,709 |  |  | $ | 5,896 |  |
| Accruals for warranties during the period |  |  | 152 |  |  |  | (167 | ) |
| Settlements during the period |  |  | (74 | ) |  |  | (229 | ) |
| Balance at end of period |  | $ | 2,787 |  |  | $ | 5,500 |  |


## us-gaap:ScheduleOfEarningsPerShareBasicAndDilutedTableTextBlock

[0001193125-13-324142:notes:99]
The following
table reconciles the numerators and denominators of the earnings
per share calculation for the three months ended June 30, 2013
and 2012 (in thousands, except per share data):

[0001193125-13-324142:notes:100]
|  |  | Three months ended June 30, |  |
|  |  | 2013 |  |  | 2012 |  |
| Numerator: |  |  |  |  |  |  |  |  |
| Net loss |  | $ | (10,513 | ) |  | $ | (10,275 | ) |
| Denominator: |  |  |  |  |  |  |  |  |
| Weighted-average shares of common stock outstanding |  |  | 60,463 |  |  |  | 51,997 |  |
| Weighted-average shares subject to repurchase |  |  | (2,163 | ) |  |  | (806 | ) |
| Shares used in per-share calculation — basic |  |  | 58,300 |  |  |  | 51,191 |  |
| Shares used in per-share calculation — diluted |  |  | 58,300 |  |  |  | 51,191 |  |
| Net loss per share — basic |  | $ | (0.18 | ) |  | $ | (0.20 | ) |
| Net loss per share — diluted |  | $ | (0.18 | ) |  | $ | (0.20 | ) |


## us-gaap:EquityMethodInvestmentsDisclosureTextBlock

[0001193125-13-324142:notes:101]
| 13. | Equity Investments |

[0001193125-13-324142:notes:102]
[same as prior period, unchanged from 0001193125-13-048834:notes:87]

[0001193125-13-324142:notes:103]
On
October 9, 2009, the Company made an investment in Tres Amigas
LLC, a Delaware limited liability company (“Tres
Amigas”), focused on providing the first common
interconnection of America’s three power grids to help the
country achieve its renewable energy goals and facilitate the
smooth, reliable and efficient transfer of green power from region
to region, for $1.8 million, consisting of $0.8 million in cash and
$1.0 million in AMSC common stock. On January 6, 2011 and
May 20, 2011, the Company increased its minority position in
Tres Amigas by investing an additional $1.8 million in cash on each
date. As of June 30, 2013, the Company holds a 26% ownership
interest in Tres Amigas.

[0001193125-13-324142:notes:104]
The
Company’s investment in Tres Amigas is included in other
assets on the consolidated balance sheet and the equity in
undistributed losses of Tres Amigas is included in other income,
net, on the consolidated statements of operations.

[0001193125-13-324142:notes:105]
The net
investment activity for the three months ended June 30, 2013
is as follows (in thousands):

[0001193125-13-324142:notes:106]
| Balance at April 1, 2013 |  | $ | 2,853 |  |
| Minority interest in net losses |  |  | (248 | ) |
| Balance at June 30, 2013 |  | $ | 2,605 |  |

[0001193125-13-324142:notes:107]
[same as prior period, unchanged from 0001193125-13-048834:notes:92]

[0001193125-13-324142:notes:108]
On
August 12, 2010, the Company acquired (through its Austrian
subsidiary), a minority ownership position in Blade Dynamics Ltd.
(“Blade Dynamics”), a designer and manufacturer of
advanced wind turbine blades based on proprietary materials and
structural technologies, for $8.0 million in cash. As of
June 30, 2013, the Company holds a 19% ownership interest in
Blade Dynamics.

[0001193125-13-324142:notes:109]
The investment
is carried at the acquisition cost, plus the Company’s equity
in undistributed earnings or losses, through December 1, 2012 the
date which the company no longer reports undistributed earnings or
losses. The Company’s investment in Blade Dynamics is
included in other assets on the unaudited condensed consolidated
balance sheet and the equity in undistributed losses of Blade
Dynamics is included in other income, net, on the unaudited
condensed consolidated statements of operations.

[0001193125-13-324142:notes:110]
The net investment activity
for the three months ended June 30, 2013 is as follows (in
thousands):

[0001193125-13-324142:notes:111]
| Balance at April 1, 2013 |  | $ | 4,611 |  |
| Minority interest in net losses |  |  | — |  |
| Net foreign exchange rate impact |  |  | (69 | ) |
| Balance at June 30, 2013 |  | $ | 4,680 |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001193125-13-324142:notes:112]
| 11. | Warrants and Derivative Liabilities |

[0001193125-13-324142:notes:113]
On April 4, 2012, the Company entered into a Purchase
Agreement for the Initial Note and on December 20, 2012, the
Company entered into the Amendment pursuant to which it exchanged
the Initial Note for the Exchanged Note, as described in Note 10.
The Initial Note included a warrant to purchase
3,094,060 million shares of the Company’s common stock.
The warrant is exercisable at any time on or after the date that is
six months after the issuance of the warrant and entitles CVI to
purchase shares of the Company’s common stock for a period of
five years from the initial date the warrant becomes exercisable at
a price equal to $5.45 per share, subject to certain price-based
and other anti-dilution adjustments. The warrant may not be
exercised if, after giving effect to the conversion, CVI together
with its affiliates would beneficially own in excess of 4.99% of
the Company’s common stock. This percentage may be raised to
any other percentage not in excess of 9.99% at the option of CVI,
upon at least 61-days prior notice to the Company, or lowered to
any other percentage, at the option of CVI, at any time.

[0001193125-13-324142:notes:114]
The Company calculated the fair value of the derivative
liabilities and warrants utilizing an integrated lattice model. The
lattice model is an option pricing model that involves the
construction of a binomial tree to show the different paths that
the underlying asset may take over the option’s life. A
lattice model can take into account expected changes in various
parameters such as volatility over the life of the options,
providing more accurate estimates of option prices than the
Black-Scholes model.

[0001193125-13-324142:notes:115]
The Company accounts for the warrant as a liability due to
certain adjustment provisions within the warrant, which requires
that it be recorded at fair value. The warrant is subject to
revaluation at each balance sheet date and any change in fair value
will be recorded as a change in fair value in other income
(expense) until the earlier of expiration or its exercise at which
time the warrant liability will be reclassified to equity.
Following is a summary of the key assumptions used to calculate the
fair value of the warrant:

[0001193125-13-324142:notes:116]
|  |  | June 30, 2013 |  |
| Fiscal Year 2013 |  |  |  |  |
| Risk-free interest rate |  |  | 1.13 | % |
| Expected annual dividend yield |  |  | 0.0 | % |
| Expected volatility |  |  | 71.9 | % |
| Term (years) |  |  | 4.27 |  |
| Fair Value |  | $ | 3.0 million |  |

[0001193125-13-324142:notes:117]
|  |  | March 31, |  |  | December 31, |  |  | September 30, |  |  | June 30, |  |  | April 4, |  |
|  |  | 2013 |  |  | 2012 |  |  | 2012 |  |  | 2012 |  |  | 2012 |  |
| Fiscal Year 2012 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Risk-free interest rate |  |  | 0.67 | % |  |  | 0.75 | % |  |  | 0.63 | % |  |  | 0.77 | % |  |  | 1.19 | % |
| Expected annual dividend yield |  |  | 0.0 | % |  |  | 0.0 | % |  |  | 0.0 | % |  |  | 0.0 | % |  |  | 0.0 | % |
| Expected volatility |  |  | 71.7 | % |  |  | 80.6 | % |  |  | 80.9 | % |  |  | 80.8 | % |  |  | 80.0 | % |
| Term (years) |  |  | 4.51 |  |  |  | 4.76 |  |  |  | 5.01 |  |  |  | 5.28 |  |  |  | 5.5 |  |
| Fair Value |  | $ | 3.4 million |  |  | $ | 4.4 million |  |  | $ | 7.1 million |  |  | $ | 8.6 million |  |  | $ | 7.0 million |  |

[0001193125-13-324142:notes:118]
The Company recorded the change in the fair value of the CVI
warrant of $0.4 million gain and $1.6 million loss, to change in
fair value of derivatives and warrants in the three months ended
June 30, 2013 and 2012, respectively.

[0001193125-13-324142:notes:119]
The Company determined certain embedded derivatives issued with
the convertible notes required accounting as a liability, which
requires they be accounted for as a standalone liability subject to
revaluation at each balance sheet date with changes in fair value
recorded as change in fair value of derivatives and warrants until
the earlier of exercise or expiration.

[0001193125-13-324142:notes:120]
The terms of the debt modification reduced the conversion price
of the Initial Note from $4.85 per share to $3.19 per share in the
Exchanged Note. As a result the Company revalued these derivatives
pre- and post-modification and recorded the difference of $0.5
million as a debt discount and a derivative liability. (See Note
10, “Debt,” for further discussion). Following is a
summary of the key assumptions used to value the convertible notes
derivative feature:

[0001193125-13-324142:notes:121]
Based on historical volume-weighted average price
(“VWAP”) of the Company’s common stock as well as
the historic average dollar trading volume of the Company’s
common stock, the percentage volume condition is the probability
that the Company will convert monthly installment payments into the
Company’s common stock. The expected volatility rate was
estimated based on an equal weighting of the historical volatility
of the Company’s common stock and the implied volatility of
the Company’s traded options. To determine the risk-free
interest rate, an interpolated rate was used based on the one, two
and three-year United States Treasury rates. The bond yield was
estimated using comparable corporate debt and yield information.
The recovery rate of the Exchanged Note was estimated by reviewing
historical corporate debt that went into default. The bond is
redeemable by the Company at any point after the one-year
anniversary of the grant date provided certain provisions within
the note. The total time is based on the actual 30-month
contractual terms. It was determined that there is a dilution
effect based on the Company’s ability to make payments in
shares of common stock.

[0001193125-13-324142:notes:122]
The Company recorded the change in the fair value of the
derivative liabilities of $0.1 million gain and $0.7 million loss,
to changes in fair value of derivatives and warrants in the three
months ended June 30, 2013 and 2012, respectively.

[0001193125-13-324142:notes:123]
On June 5, 2012, the Company entered into a Loan and
Security Agreement with Hercules (see Note 10, “Debt,”
for additional information regarding the Loan and Security
Agreement). In conjunction with this agreement, the Company issued
a warrant to purchase 139,276 shares of the Company’s common
stock. The warrant is exercisable at any time after the issuance of
the warrant and expires on December 5, 2017, at a price equal
to $3.59 per share subject to certain price-based and other
anti-dilution adjustments.

[0001193125-13-324142:notes:124]
The Company accounts for the warrant as a liability due to
certain provisions within the warrant, which requires that it be
recorded at fair value. The warrant is subject to revaluation at
each balance sheet date and any change in fair value will be
recorded as changes in fair value of derivatives and warrants until
the earlier of expiration or its exercise at which time the warrant
liability will be reclassified to equity. Following is a summary of
the key assumptions used to calculate the fair value of the
warrant:

[0001193125-13-324142:notes:125]
|  |  | June 30, |  |
|  |  | 2013 |  |
| Fiscal Year 2013 |  |  |  |  |
| Risk-free interest rate |  |  | 1.20 | % |
| Expected annual dividend yield |  |  | — | % |
| Expected volatility |  |  | 72.3 | % |
| Term (years) |  |  | 4.43 |  |
| Fair Value |  | $ | 0.2 million |  |

[0001193125-13-324142:notes:126]
|  |  | March 31, |  |  | December 31, |  |  | September 30, |  |  | June 30, |  |  | June 5, |  |
|  |  | 2013 |  |  | 2012 |  |  | 2012 |  |  | 2012 |  |  | 2012 |  |
| Fiscal Year 2012 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Risk-free interest rate |  |  | 0.70 | % |  |  | 0.75 | % |  |  | 0.64 | % |  |  | 0.80 | % |  |  | 0.77 | % |
| Expected annual dividend yield |  |  | — | % |  |  | — | % |  |  | — | % |  |  | — | % |  |  | — | % |
| Expected volatility |  |  | 72.01 | % |  |  | 80.14 | % |  |  | 81.18 | % |  |  | 80.32 | % |  |  | 79.99 | % |
| Term (years) |  |  | 4.68 |  |  |  | 4.93 |  |  |  | 5.18 |  |  |  | 5.44 |  |  |  | 5.5 |  |
| Fair Value |  | $ | 0.2 million |  |  | $ | 0.2 million |  |  | $ | 0.4 million |  |  | $ | 0.5 million |  |  | $ | 0.4 million |  |

[0001193125-13-324142:notes:127]
The Company prepared its estimates for the assumptions used to
determine the fair value of the warrants issued in conjunction with
both the Convertible Note and Term Loan utilizing the respective
terms of the warrants with similar inputs, as described
above.

[0001193125-13-324142:notes:128]
The Company recorded a loss from the change in the fair value
of the Hercules warrant of $0.1 million, during the three months
ended June 30, 2012.


## us-gaap:NewAccountingPronouncementsAndChangesInAccountingPrinciplesTextBlock

[0001193125-13-324142:notes:129]
| 15. | Recent Accounting Pronouncements |

[0001193125-13-324142:notes:130]
In January
2013, the Financial Accounting Standards Board (FASB) issued
Accounting Standards Update (ASU) No. 2013-01, Balance
Sheet (Topic 210): Clarifying the Scope of Disclosures about
Offsetting Assets and Liabilities (ASU 2013-01). The main
objective in developing this update is to address implementation
issues about the scope of Accounting Standards Update
No. 2011-11, Balance Sheet (Topic 210): Disclosures about
Offsetting Assets and Liabilities. The update requires entities to
disclose information about offsetting and related arrangements of
financial instruments and derivative instruments. ASU 2013-01 is
effective for our first quarter of fiscal 2014. The Company is
currently evaluating the impact of adopting ASU 2013-01, but
currently does not believe there will be a significant impact on
its consolidated results of operations, financial condition, or
cash flows.

[0001193125-13-324142:notes:131]
In February
2013, the FASB issued ASU No. 2013-02, Comprehensive
Income (Topic 220): Reporting of Amounts Reclassified Out of
Accumulated Other Comprehensive Income (ASU 2013-02). The
amendments of this ASU require an entity to provide information
about the amounts reclassified out of accumulated other
comprehensive income (“AOCI”) by component. In
addition, an entity is required to present, either on the face of
the statement where net income (loss) is presented or in the notes,
significant amounts reclassified out of AOCI by the respective line
items of net income but only if the amount reclassified is required
under U.S. GAAP to be reclassified to net income in its entirety in
the same reporting period. For other amounts that are not required
under U.S. GAAP to be reclassified in their entirety to net income,
an entity is required to cross-reference to other disclosures
required under U.S. GAAP that provide additional detail about those
amounts. ASU 2013-02 is effective for fiscal years and interim
periods beginning after December 15, 2012. The Company early
adopted ASU 2013-02 and it did not have a material impact on the
Company’s consolidated results of operations, financial
condition, or cash flows.

[0001193125-13-324142:notes:132]
In March 2013,
the FASB issued ASU No. 2013-05, Foreign Currency Matters
(Topic 830): Parent’s Accounting for the Cumulative
Translation Adjustment upon Derecognition of Certain Subsidiaries
or Groups of Assets within a Foreign Entity or of an Investment in
a Foreign Entity (ASU 2013-05). The objective of the amendments
in this update is to resolve the diversity in practice about
whether Subtopic 810-10, Consolidation—Overall, or Subtopic
830-30, Foreign Currency Matters—Translation of Financial
Statements, applies to the release of the cumulative translation
adjustment into net income when a parent either sells a part or all
of its investment in a foreign entity or no longer holds a
controlling financial interest in a subsidiary or group of assets
that is a nonprofit activity or a business (other than a sale of in
substance real estate or conveyance of oil and gas mineral rights)
within a foreign entity. In addition, the amendments in this Update
resolve the diversity in practice for the treatment of business
combinations achieved in involving a foreign entity. ASU 2013-05 is
effective for fiscal years and interim periods beginning after
December 15, 2013. The Company is currently evaluating the
impact of ASU 2013-05, but currently does not believe there will be
a significant impact on the Company’s consolidated results of
operations, financial condition, or cash flows.

[0001193125-13-324142:notes:133]
In June 2013,
the FASB issued ASU 2013-07, Liquidation Basis of
Accounting, to require entities to begin preparing financial
statements on a liquidation basis when liquidation is imminent. The
guidance requires liquidation accounting when liquidation is
imminent, unless an entity is outside the scope of the guidance or
it is following a liquidation plan established at its inception.
The guidance says liquidation is imminent when either, the party or
parties with the authority to approve a liquidation plan do so or
other forces (e.g., involuntary bankruptcy) impose a plan for
liquidation, and the likelihood that the entity will return from
liquidation is remote. The guidance also requires entities using
the liquidation basis of accounting to measure their assets at the
amount they expect to collect upon sale and liabilities are not
remeasured to reflect any anticipation that the entity will be
legally released from the obligation. ASU 2013-07 is effective for
annual periods beginning after December 15, 2013. The Company
is currently evaluating the impact of adopting ASU 2013-07, but
currently does not believe there will be an impact on its
consolidated results of operations, financial condition, or cash
flows.

[0001193125-13-324142:notes:134]
The Company
does not believe that other recently issued accounting
pronouncements will have a material impact on its financial
statements.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001193125-13-324142:notes:135]
| 9. | Restructuring |

[0001193125-13-324142:notes:136]
The Company accounts for charges resulting from operational
restructuring actions in accordance with ASC Topic 420, Exit or
Disposal Cost Obligations (“ASC 420”) and ASC Topic
712, Compensation—Nonretirement Postemployment
Benefits (“ASC 712”). In accounting for these
obligations, the Company is required to make assumptions related to
the amounts of employee severance, benefits, and related costs and
the time period over which leased facilities will remain vacant,
sublease terms, sublease rates and discount rates. Estimates and
assumptions are based on the best information available at the time
the obligation arises. These estimates are reviewed and revised as
facts and circumstances dictate; changes in these estimates could
have a material effect on the amount accrued on the consolidated
balance sheet.

[0001193125-13-324142:notes:137]
During the years ended March 31, 2013 and March 31,
2012, the Company initiated restructuring activities, approved by
the Board of Directors, in order to reorganize its global
operations, streamline various functions of the business, and
reduce its global workforce to better reflect the demand for its
products. The Company undertook an additional workforce reduction
in July 2013, (See Note 16—“Subsequent Events”,
for additional information related to the July reduction). These
activities resulted in the reduction of its global workforce by
approximately 57%, in aggregate. During the three months ended
June 30, 2013 and 2012, the Company incurred restructuring
costs of less than $0.1 million and $0.1 million, respectively. The
remaining balance of accrued restructuring is expected to be paid
through June 2014.

[0001193125-13-324142:notes:138]
The following table presents restructuring charges and cash
payments (in thousands):

[0001193125-13-324142:notes:139]
All restructuring charges discussed above are included within
restructuring and impairments in the Company’s unaudited
condensed consolidated statements of operations. The Company
includes accrued restructuring within accounts payable and accrued
expenses in the unaudited condensed consolidated balance
sheets.


## us-gaap:SubsequentEventsTextBlock

[0001193125-13-324142:notes:140]
| 16. | Subsequent Events |

[0001193125-13-324142:notes:141]
On
July 24, 2013, the Company undertook an action to reduce
headcount as part of its plan to reduce operating expenses in order
to enhance liquidity. The Company reduced its workforce by
approximately 7%, impacting primarily selling, engineering and
general and administrative functions. The Company expects to record
a restructuring charge for severance and other costs of
approximately $1.0 million in the second quarter of fiscal
2013.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001193125-13-324142:notes:142]
8. Income
Taxes

[0001193125-13-324142:notes:143]
For the three
months ended June 30, 2013 and 2012, the Company recorded an
income tax expense of $0.1 million and income tax benefit of $0.8
million, respectively. The income tax expense for the three months
ended June 30, 2013, was primarily due to income taxes in the
Company’s foreign jurisdictions. The income tax benefit for
the three months ended June 30, 2012, was primarily due to a
refund of Chinese income taxes of $0.9 million.


## us-gaap:EarningsPerShareTextBlock

[0001193125-13-324142:notes:144]
| 3. | Computation of Net (Loss) Income per Common Share |

[0001193125-13-324142:notes:145]
Basic net loss per share (“EPS”) is computed by
dividing net loss by the weighted-average number of common shares
outstanding for the period. Where applicable, diluted EPS is
computed by dividing the net loss by the weighted-average number of
common shares and dilutive common equivalent shares outstanding
during the period, calculated using the treasury stock method.
Common equivalent shares include the effect of restricted stock,
exercise of stock options and warrants and contingently issuable
shares. For the three months ended June 30, 2013,
6.1 million shares were not included in the calculation of
diluted EPS as they were considered anti-dilutive, of which
2.9 million relate to unvested stock options and
3.2 million relate to the issuance of warrants. For the three
months ended June 30, 2012, 6.3 million shares were not
included in the calculation of diluted EPS as they were considered
anti-dilutive, of which 3.1 million relate to unvested stock
options and 3.2 million relate to the issue of
warrants.

[0001193125-13-324142:notes:146]
The following table reconciles the numerators and denominators
of the earnings per share calculation for the three months ended
June 30, 2013 and 2012 (in thousands, except per share
data):
