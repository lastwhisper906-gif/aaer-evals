# AMSC 8-K — 0001437749-20-016665 filed 2020-08-05

## item codes, every 8-K on or before 2020-08-05

- 2020-08-05 0001437749-20-016665 — 2.02, 5.07, 9.01
- 2020-06-02 0001437749-20-012274 — 2.02, 9.01
- 2020-05-27 0001437749-20-011837 — 5.02, 9.01
- 2020-02-05 0001437749-20-001788 — 2.02, 9.01
- 2019-11-05 0001437749-19-021590 — 2.02, 9.01
- 2019-08-06 0001437749-19-015631 — 2.02, 9.01
- 2019-08-06 0001193125-19-214189 — 5.02, 5.07, 9.01
- 2019-06-05 0001437749-19-011476 — 2.02, 5.02, 9.01
- 2019-05-24 0001437749-19-010833 — 5.02
- 2019-02-05 0001628280-19-000964 — 2.02, 8.01, 9.01
- 2018-11-06 0001628280-18-013765 — 2.02, 9.01
- 2018-10-31 0001628280-18-013204 — 1.01
- 2018-08-01 0001628280-18-010196 — 5.07
- 2018-07-31 0001628280-18-009846 — 2.02, 9.01
- 2018-07-09 0001193125-18-214745 — 1.01, 9.01
- 2018-07-03 0001628280-18-009075 — 5.02, 9.01
- 2018-06-14 0001628280-18-007877 — 5.02
- 2018-06-06 0001628280-18-007643 — 2.02, 9.01
- 2018-04-10 0001628280-18-004141 — 5.02
- 2018-04-03 0001628280-18-003952 — 2.01, 9.01
- 2018-02-05 0001628280-18-000989 — 2.02, 9.01
- 2018-02-01 0001628280-18-000826 — 1.01, 9.01
- 2017-11-07 0001628280-17-011076 — 2.02, 9.01
- 2017-09-26 0001628280-17-009444 — 3.02, 8.01
- 2017-08-08 0001628280-17-008329 — 2.02, 9.01
- 2017-08-01 0001628280-17-007765 — 5.02, 5.07
- 2017-07-03 0001193125-17-221140 — 5.02, 9.01
- 2017-05-26 0001193125-17-185503 — 8.01, 9.01
- 2017-05-25 0001628280-17-005914 — 2.02, 9.01 — amendment of 0001628280-17-005884
- 2017-05-25 0001628280-17-005884 — 2.02, 9.01
- 2017-05-10 0001193125-17-165924 — 8.01, 9.01
- 2017-05-09 0001193125-17-164273 — 5.02
- 2017-05-04 0001193125-17-158639 — 1.02, 8.01
- 2017-04-26 0001193125-17-139493 — 2.02, 9.01
- 2017-04-04 0001193125-17-109748 — 2.05, 5.02, 9.01
- 2017-02-06 0001628280-17-000899 — 2.02, 9.01
- 2017-01-27 0001193125-17-021808 — 1.01, 2.02, 9.01
- 2016-11-02 0001628280-16-020598 — 2.02, 9.01
- 2016-09-16 0001193125-16-712301 — 5.02
- 2016-08-23 0001193125-16-688767 — 8.01
- 2016-08-09 0001628280-16-018763 — 2.02, 9.01
- 2016-08-02 0001193125-16-668417 — 5.02, 5.07, 9.01
- 2016-05-31 0001564590-16-020114 — 2.02, 9.01
- 2016-05-18 0001193125-16-594515 — 5.02
- 2016-03-08 0001193125-16-496113 — 1.01
- 2016-02-09 0001193125-16-454775 — 2.02, 9.01
- 2015-12-17 0001193125-15-405566 — 1.01
- 2015-11-03 0001193125-15-363413 — 2.02, 9.01
- 2015-08-31 0001193125-15-307558 — 1.01
- 2015-08-05 0001193125-15-277824 — 2.02, 9.01
- 2015-07-31 0001193125-15-273009 — 5.07
- 2015-06-26 0001193125-15-237190 — 5.02
- 2015-06-09 0001193125-15-218028 — 8.01
- 2015-05-28 0001193125-15-202933 — 2.02, 9.01
- 2015-04-28 0001193125-15-153319 — 8.01, 9.01
- 2015-04-23 0001193125-15-144123 — 2.02, 8.01, 9.01
- 2015-04-23 0001193125-15-143608 — 8.01
- 2015-04-10 0001193125-15-126160 — 8.01
- 2015-03-24 0001193125-15-103436 — 5.03, 9.01
- 2015-03-18 0001193125-15-097034 — 5.07
- 2015-02-05 0001193125-15-034499 — 2.02, 9.01
- 2015-01-29 0001193125-15-024629 — 2.02, 9.01
- 2015-01-21 0001193125-15-016287 — 3.01, 8.01
- 2015-01-06 0001193125-15-002902 — 5.02
- 2014-12-22 0001193125-14-450591 — 1.01, 2.03, 3.02, 9.01
- 2014-11-13 0001193125-14-410207 — 1.01, 9.01
- 2014-11-07 0001193125-14-402383 — 1.02, 7.01, 9.01
- 2014-11-06 0001193125-14-399779 — 2.02, 9.01
- 2014-10-01 0001193125-14-360072 — 2.02, 8.01, 9.01
- 2014-09-04 0001193125-14-331411 — 8.01
- 2014-08-21 0001193125-14-317133 — 1.01
- 2014-08-06 0001193125-14-298306 — 5.02, 5.07, 9.01
- 2014-08-05 0001193125-14-294647 — 2.02, 9.01
- 2014-07-16 0001193125-14-269902 — 8.01
- 2014-06-23 0001193125-14-244592 — 3.02, 8.01
- 2014-06-05 0001193125-14-226459 — 2.02, 9.01
- 2014-06-05 0001193125-14-226457 — 1.01, 9.01
- 2014-03-19 0001193125-14-106558 — 2.05
- 2014-03-03 0001193125-14-078917 — 1.01, 3.02, 9.01
- 2014-02-28 0001193125-14-077480 — 8.01, 9.01
- 2014-02-06 0001193125-14-037960 — 2.02, 8.01, 9.01
- 2013-11-20 0001193125-13-447829 — 3.02, 8.01
- 2013-11-18 0001193125-13-444697 — 1.01, 2.03, 3.02, 9.01
- 2013-11-07 0001193125-13-431705 — 2.02, 9.01
- 2013-10-09 0001193125-13-395362 — 1.01, 2.03, 3.02, 9.01
- 2013-09-25 0001193125-13-378481 — 5.02, 9.01
- 2013-08-21 0001193125-13-341566 — 4.01, 9.01
- 2013-08-07 0001193125-13-323082 — 2.02, 9.01
- 2013-08-02 0001193125-13-317278 — 5.02, 5.07
- 2013-06-14 0001193125-13-258758 — 2.02, 9.01
- 2013-04-01 0001193125-13-136714 — 2.02, 8.01, 9.01
- 2013-02-20 0001193125-13-067218 — 5.02, 9.01
- 2013-02-14 0001193125-13-060131 — 1.01, 9.01
- 2013-02-11 0001193125-13-048784 — 2.02, 9.01
- 2013-01-08 0001193125-13-006861 — 5.02, 9.01
- 2012-12-21 0001193125-12-511592 — 1.01, 2.03, 3.02, 9.01
- 2012-11-28 0001193125-12-483317 — 2.05, 5.02, 7.01, 9.01
- 2012-11-06 0001193125-12-453359 — 2.02, 9.01
- 2012-08-02 0001193125-12-330534 — 2.02, 9.01
- 2012-07-27 0001193125-12-318790 — 5.02, 5.07, 9.01
- 2012-06-06 0001193125-12-261030 — 1.01, 2.02, 2.03, 3.02, 5.02, 9.01
- 2012-05-09 0001193125-12-222210 — 5.02
- 2012-04-20 0001193125-12-172045 — 8.01
- 2012-04-13 0001193125-12-162694 — 2.02, 8.01, 9.01
- 2012-04-04 0001193125-12-149102 — 1.01, 2.02, 2.03, 3.02, 9.01
- 2012-02-09 0001193125-12-048009 — 2.02, 9.01
- 2012-02-06 0001193125-12-041344 — 5.07 — amendment of 0000950123-11-102495
- 2011-12-08 0000950123-11-102495 — 5.07
- 2011-11-29 0000950123-11-100822 — 2.05
- 2011-11-09 0000950123-11-096775 — 2.02, 9.01
- 2011-10-31 0000950123-11-093390 — 1.02, 9.01
- 2011-10-07 0000950123-11-089221 — 8.01
- 2011-10-03 0000950123-11-088315 — 7.01
- 2011-09-23 0000950123-11-086288 — 2.02, 9.01
- 2011-09-15 0000950123-11-084585 — 7.01
- 2011-09-06 0000950123-11-082736 — 7.01
- 2011-08-18 0000950123-11-078526 — 3.01, 7.01, 9.01
- 2011-08-11 0000950123-11-075905 — 5.02
- 2011-08-11 0000950123-11-075904 — 2.02, 2.05, 9.01
- 2011-07-11 0000950123-11-064934 — 2.02, 4.02, 9.01
- 2011-06-30 0000950123-11-063287 — 1.01, 3.02, 9.01
- 2011-06-21 0000950123-11-060491 — 3.01, 7.01, 9.01
- 2011-06-13 0000950123-11-058656 — 1.01, 9.01
- 2011-05-24 0000950123-11-053517 — 5.02, 9.01
- 2011-04-05 0001299933-11-001020 — 2.02, 9.01
- 2011-03-15 0000950123-11-025580 — 5.02
- 2011-03-14 0000950123-11-025205 — 1.01, 3.02, 9.01
- 2011-02-01 0001299933-11-000333 — 2.02, 9.01
- 2010-11-12 0000950123-10-104604 — 8.01, 9.01
- 2010-11-08 0000950123-10-102424 — 8.01, 9.01
- 2010-11-02 0001299933-10-003878 — 2.02, 9.01
- 2010-09-15 0000950123-10-086373 — 1.01, 9.01 — amendment, the index does not say of what
- 2010-08-06 0000950123-10-074362 — 5.07
- 2010-07-29 0001299933-10-002860 — 2.02, 9.01
- 2010-05-17 0000950123-10-050424 — 1.01, 9.01
- 2010-05-14 0001299933-10-001972 — 5.02
- 2010-05-13 0001299933-10-001943 — 2.02, 9.01
- 2010-02-08 0001299933-10-000506 — 8.01
- 2010-02-02 0001299933-10-000386 — 2.02, 9.01
- 2009-12-15 0001299933-09-004928 — 5.02
- 2009-10-29 0001299933-09-004267 — 2.02, 9.01
- 2009-08-12 0001193125-09-173026 — 5.02, 9.01
- 2009-07-30 0001193125-09-158842 — 1.01, 2.02, 9.01
- 2009-05-15 0001193125-09-113158 — 5.02
- 2009-05-14 0001193125-09-110619 — 2.02, 9.01
- 2009-04-20 0001193125-09-082590 — 5.02
- 2009-02-03 0001193125-09-016992 — 2.02, 9.01
- 2009-01-22 0001193125-09-009777 — 2.02, 9.01
- 2008-11-04 0001193125-08-223730 — 2.02, 9.01
- 2008-08-11 0001193125-08-173616 — 8.01
- 2008-08-07 0001193125-08-170325 — 8.01
- 2008-08-05 0001193125-08-165888 — 2.02, 9.01
- 2008-06-11 0001193125-08-132049 — 1.01, 9.01
- 2008-05-20 0001193125-08-119372 — 5.02, 9.01
- 2008-05-08 0001193125-08-107052 — 2.02, 9.01
- 2008-01-31 0001193125-08-016233 — 2.02, 9.01
- 2008-01-30 0001193125-08-015494 — 5.03, 9.01
- 2007-11-01 0001193125-07-231866 — 2.02, 9.01
- 2007-10-31 0001193125-07-231225 — 2.05
- 2007-10-29 0001193125-07-228284 — 5.03, 9.01
- 2007-09-27 0001193125-07-208950 — 5.02
- 2007-08-09 0001193125-07-176553 — 2.02, 9.01
- 2007-08-07 0001193125-07-173829 — 1.01, 5.02, 9.01
- 2007-07-02 0001193125-07-148303 — 5.02, 9.01
- 2007-06-20 0001193125-07-139068 — 8.01, 9.01
- 2007-06-14 0001193125-07-135550 — 9.01 — amendment of 0001193125-07-005297
- 2007-06-14 0001193125-07-135340 — 5.02
- 2007-05-24 0001193125-07-122148 — 2.02, 9.01
- 2007-03-30 0001193125-07-070154 — 2.05, 9.01
- 2007-03-23 0001193125-07-062978 — 9.01 — amendment of 0001193125-07-005297
- 2007-02-01 0001193125-07-017883 — 2.02, 9.01
- 2007-01-11 0001193125-07-005297 — 2.01, 9.01
- 2006-12-05 0001181431-06-067500 — 5.02
- 2006-11-29 0001193125-06-243360 — 1.01, 3.02, 9.01
- 2006-11-02 0001193125-06-221464 — 2.02, 9.01
- 2006-09-21 0001193125-06-194526 — 5.02
- 2006-08-08 0001193125-06-164819 — 2.02, 9.01
- 2006-08-02 0001193125-06-159113 — 1.01, 9.01
- 2006-07-28 0001193125-06-156172 — 1.01
- 2006-06-26 0001193125-06-135913 — 1.01, 3.03, 9.01
- 2006-05-11 0001193125-06-108489 — 2.02, 9.01
- 2006-05-05 0001193125-06-102270 — 1.01, 9.01
- 2006-05-01 0001193125-06-094941 — 2.02, 2.06, 9.01
- 2006-02-24 0001193125-06-038281 — 5.02, 9.01
- 2006-02-02 0001181431-06-007665 — 2.02, 9.01
- 2005-11-09 0001181431-05-060304 — 2.02, 9.01
- 2005-08-04 0001181431-05-044420 — 2.02, 9.01
- 2005-07-28 0001193125-05-151272 — 5.02, 9.01
- 2005-06-14 0001193125-05-125148 — 5.02, 9.01
- 2005-05-12 0001181431-05-027410 — 2.02, 9.01
- 2005-05-10 0001193125-05-102795 — 1.01
- 2005-04-05 0001181431-05-020680 — 1.01, 2.02, 3.02, 9.01
- 2005-02-03 0001181431-05-006678 — 2.02, 9.01
- 2004-11-09 0001181431-04-051381 — 2.02, 9.01 — amendment, the index does not say of what
- 2004-11-04 0001181431-04-050706 — 2.02, 9.01
- 2004-10-15 0001193125-04-172458 — 1.01, 9.01
- 2004-08-05 0001193125-04-132162 — 12
- 2004-05-13 0001193125-04-086853 — 12
- 2004-02-05 0001193125-04-015060 — 12
- 2003-11-06 0001193125-03-074000 — 12
- 2003-09-26 0001193125-03-054624 — 5
- 2003-08-06 0001193125-03-029666 — 12
- 2003-05-14 0000927016-03-002619 — 9
- 2002-12-31 0000927016-02-006114 — 5
- 2000-01-24 0000927016-00-000150 — 5, 7
- 1998-11-02 0000950135-98-005625 — 5, 7
- 1998-03-24 0000950135-98-001743 — 5, 7
- 1997-09-05 0000950135-97-003729 — 5, 7
- 1997-06-23 0000950135-97-002785 — 1 — amendment of 0000950135-97-001972
- 1997-04-23 0000950135-97-001972 — 2, 7

## late-filing notifications on or before 2020-08-05

- 2011-08-10 0000950123-11-075677 — NT 10-Q, for the period ended 2011-06-30
- 2011-05-31 0000950123-11-055465 — NT 10-K, for the period ended 2011-03-31

## item 2.02 — earnings release, exhibit 99.1

[0001437749-20-016665:8k_2_02:1]
EX-99.1
2
ex_191430.htm
EXHIBIT 99.1

[0001437749-20-016665:8k_2_02:2]
ex_151959.htm

[0001437749-20-016665:8k_2_02:3]
Exhibit 99.1

[0001437749-20-016665:8k_2_02:4]
AMSC Reports First Quarter Fiscal Year 2020 Financial Results and Provides Business Outlook

[0001437749-20-016665:8k_2_02:5]
Company to host conference call tomorrow, August 6 at 10:00 am ET

[0001437749-20-016665:8k_2_02:6]
Ayer, MA – August 5, 2020 – AMSC (Nasdaq: AMSC), a leading system provider of megawatt-scale power resiliency solutions that orchestrate the rhythm and harmony of power on the grid™, and that protect and expand the capability and resiliency of our Navy’s fleet, today reported financial results for its first quarter of fiscal year 2020 ended June 30, 2020.

[0001437749-20-016665:8k_2_02:7]
Revenues for the first quarter of fiscal 2020 were $21.2 million compared with $13.8 million for the same period of fiscal 2019. The year-over-year increase was a result of higher Grid segment revenues versus the year ago period.  The higher Grid segment revenues are primarily due to increased D-VAR shipments, versus the year ago period.

[0001437749-20-016665:8k_2_02:8]
AMSC’s net loss for the first quarter of fiscal 2020 was $3.4 million, or $0.16 per share, compared to a net loss of $3.5 million, or $0.17 per share, for the same period of fiscal 2019.  The Company’s non-GAAP net loss for the first quarter of fiscal 2020 was $2.4 million, or $0.11 per share, compared with a non-GAAP net loss of $6.2 million, or $0.30 per share, in the same period of fiscal 2019. Please refer to the financial table below for a reconciliation of GAAP to non-GAAP results.

[0001437749-20-016665:8k_2_02:9]
Cash, cash equivalents, marketable securities and restricted cash on June 30, 2020 totaled $62.2 million, compared with $66.1 million at March 31, 2020.

[0001437749-20-016665:8k_2_02:10]
“We are off to a very strong start to fiscal 2020,” said Daniel P. McGahn, Chairman, President and CEO, AMSC. “Grid segment revenues grew nearly 80% versus year ago results and were, in fact, the highest we have reported in nearly a decade. All of our Grid products contributed to the strong growth in the quarter. Our growth through Grid strategy is working.”

[0001437749-20-016665:8k_2_02:11]
| AMSC Reports Q1FY20 Results | Page 2 |

[0001437749-20-016665:8k_2_02:12]
Business Outlook

[0001437749-20-016665:8k_2_02:13]
For the second quarter ending September 30, 2020, AMSC expects that its revenues will be in the range of $17 million to $21 million.  The Company’s net loss for the second quarter of fiscal 2020 is expected not to exceed $6.5 million, or $0.30 per share.  The Company's non-GAAP net loss (as defined below) is expected not to exceed $5.5 million, or $0.25 per share.  The Company expects operating cash flow to be a burn of $4 million to $6 million in the second quarter of fiscal 2020.  The Company expects cash, cash equivalents, marketable securities and restricted cash on September 30, 2020, to be no less than $55 million.

[0001437749-20-016665:8k_2_02:14]
Conference Call Reminder

[0001437749-20-016665:8k_2_02:15]
In conjunction with this announcement, AMSC management will participate in a conference call with investors beginning at 10:00 a.m. Eastern Time on Thursday, August 6, 2020, to discuss the Company’s financial results and business outlook. Those who wish to listen to the live or archived conference call webcast should visit the “Investors” section of the Company’s website at http://www.amsc.com/investors. The live call also can be accessed by dialing 800-353-6461 or 334-323-0501 and using conference ID 9500583. A replay of the call may be accessed 2 hours following the call by dialing 888-203-1112 or 719-457-0820 and using conference ID 9500583.

[0001437749-20-016665:8k_2_02:16]
About AMSC (Nasdaq: AMSC)

[0001437749-20-016665:8k_2_02:17]
AMSC generates the ideas, technologies and solutions that meet the world’s demand for smarter, cleaner … better energy™. Through its Gridtec™ Solutions, AMSC provides the engineering planning services and advanced grid systems that optimize network reliability, efficiency and performance.  Through its Marinetec™ Solutions, AMSC provides ship protection systems and is developing propulsion and power management solutions designed to help fleets increase system efficiencies, enhance power quality and boost operational safety.  Through its Windtec™ Solutions, AMSC provides wind turbine electronic controls and systems, designs and engineering services that reduce the cost of wind energy. The Company’s solutions are enhancing the performance and reliability of power networks, increasing the operational safety of navy fleets, and powering gigawatts of renewable energy globally. Founded in 1987, AMSC is headquartered near Boston, Massachusetts with operations in Asia, Australia, Europe and North America. For more information, please visit www.amsc.com.

[0001437749-20-016665:8k_2_02:18]
AMSC, American Superconductor, D-VAR, D-VAR VVO, Gridtec, Marintec, Windtec, Smarter, Cleaner … Better Energy, and Orchestrate the Rhythm and Harmony of Power on the Grid are trademarks or registered trademarks of American Superconductor Corporation. All other brand names, product names, trademarks or service marks belong to their respective holders.

[0001437749-20-016665:8k_2_02:19]
| AMSC Reports Q1FY20 Results | Page 3 |

[0001437749-20-016665:8k_2_02:20]
Forward-Looking Statements

[0001437749-20-016665:8k_2_02:21]
| AMSC Reports Q1FY20 Results | Page 4 |

[0001437749-20-016665:8k_2_02:22]
UNAUDITED CONSOLIDATED STATEMENTS OF OPERATIONS

[0001437749-20-016665:8k_2_02:23]
(In thousands, except per share data)

[0001437749-20-016665:8k_2_02:24]
|  |  | Three Months Ended |  |
|  |  | June 30, |  |
|  |  | 2020 |  |  | 2019 |  |
| Revenues |  |  |  |  |  |  |  |  |
| Grid |  | $ | 17,715 |  |  | $ | 9,855 |  |
| Wind |  |  | 3,498 |  |  |  | 3,915 |  |
| Total revenues |  |  | 21,213 |  |  |  | 13,770 |  |
| Cost of revenues |  |  | 16,173 |  |  |  | 12,193 |  |
| Gross margin |  |  | 5,040 |  |  |  | 1,577 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |
| Research and development |  |  | 2,499 |  |  |  | 2,473 |  |
| Selling, general and administrative |  |  | 5,637 |  |  |  | 5,255 |  |
| Amortization of acquisition-related intangibles |  |  | 121 |  |  |  | 85 |  |
| Total operating expenses |  |  | 8,257 |  |  |  | 7,813 |  |
| Operating loss |  |  | (3,217 | ) |  |  | (6,236 | ) |
| Change in fair value of warrants |  |  | — |  |  |  | 2,946 |  |
| Interest income, net |  |  | 158 |  |  |  | 505 |  |
| Other expense, net |  |  | (170 | ) |  |  | (543 | ) |
| Loss before income tax expense |  |  | (3,229 | ) |  |  | (3,328 | ) |
| Income tax expense |  |  | 188 |  |  |  | 211 |  |
| Net loss |  | $ | (3,417 | ) |  | $ | (3,539 | ) |
| Net loss per common share |  |  |  |  |  |  |  |  |
| Basic |  | $ | (0.16 | ) |  | $ | (0.17 | ) |
| Diluted |  | $ | (0.16 | ) |  | $ | (0.17 | ) |
| Weighted average number of common shares outstanding |  |  |  |  |  |  |  |  |
| Basic |  |  | 21,689 |  |  |  | 20,514 |  |
| Diluted |  |  | 21,689 |  |  |  | 20,514 |  |

[0001437749-20-016665:8k_2_02:25]
| AMSC Reports Q1FY20 Results | Page 5 |

[0001437749-20-016665:8k_2_02:26]
UNAUDITED CONSOLIDATED BALANCE SHEET

[0001437749-20-016665:8k_2_02:27]
(In thousands, except per share data)

[0001437749-20-016665:8k_2_02:28]
|  |  | June 30, 2020 |  |  | March 31, 2020 |  |
| ASSETS |  |  |  |  |  |  |  |  |
| Current assets: |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 20,709 |  |  | $ | 24,699 |  |
| Marketable securities |  |  | 30,260 |  |  |  | 30,149 |  |
| Accounts receivable, net |  |  | 8,203 |  |  |  | 16,987 |  |
| Inventory |  |  | 17,061 |  |  |  | 18,975 |  |
| Prepaid expenses and other current assets |  |  | 3,615 |  |  |  | 2,959 |  |
| Restricted cash |  |  | 508 |  |  |  | 508 |  |
| Total current assets |  |  | 80,356 |  |  |  | 94,277 |  |
| Marketable securities |  |  | 5,070 |  |  |  | 5,046 |  |
| Property, plant and equipment, net |  |  | 8,331 |  |  |  | 8,565 |  |
| Intangibles, net |  |  | 3,429 |  |  |  | 3,550 |  |
| Right-of-use assets |  |  | 3,264 |  |  |  | 3,359 |  |
| Goodwill |  |  | 1,719 |  |  |  | 1,719 |  |
| Restricted cash |  |  | 5,659 |  |  |  | 5,657 |  |
| Deferred tax assets |  |  | 1,580 |  |  |  | 1,551 |  |
| Other assets |  |  | 262 |  |  |  | 385 |  |
| Total assets |  | $ | 109,670 |  |  | $ | 124,109 |  |
| LIABILITIES AND STOCKHOLDERS' EQUITY |  |  |  |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |  |  |  |
| Accounts payable and accrued expenses |  | $ | 14,265 |  |  | $ | 22,091 |  |
| Lease liability, current portion |  |  | 444 |  |  |  | 439 |  |
| Deferred revenue, current portion |  |  | 14,724 |  |  |  | 18,430 |  |
| Total current liabilities |  |  | 29,433 |  |  |  | 40,960 |  |
| Deferred revenue, long term portion |  |  | 7,661 |  |  |  | 7,712 |  |
| Lease liability, long term portion |  |  | 2,891 |  |  |  | 3,000 |  |
| Deferred tax liabilities |  |  | 231 |  |  |  | 180 |  |
| Other liabilities |  |  | 35 |  |  |  | 38 |  |
| Total liabilities |  |  | 40,251 |  |  |  | 51,890 |  |
| Stockholders' equity: |  |  |  |  |  |  |  |  |
| Common stock |  |  | 234 |  |  |  | 229 |  |
| Additional paid-in capital |  |  | 1,054,499 |  |  |  | 1,053,507 |  |
| Treasury stock |  |  | (3,043 | ) |  |  | (2,666 | ) |
| Accumulated other comprehensive loss |  |  | (219 | ) |  |  | (216 | ) |
| Accumulated deficit |  |  | (982,052 | ) |  |  | (978,635 | ) |
| Total stockholders' equity |  |  | 69,419 |  |  |  | 72,219 |  |
| Total liabilities and stockholders' equity |  | $ | 109,670 |  |  | $ | 124,109 |  |

[0001437749-20-016665:8k_2_02:29]
| AMSC Reports Q1FY20 Results | Page 6 |

[0001437749-20-016665:8k_2_02:30]
UNAUDITED CONSOLIDATED STATEMENTS OF CASH FLOWS

[0001437749-20-016665:8k_2_02:31]
(In thousands)

[0001437749-20-016665:8k_2_02:32]
|  |  | Three Months Ended June 30, |  |
|  |  | 2020 |  |  | 2019 |  |
| Cash flows from operating activities: |  |  |  |  |  |  |  |  |
| Net loss |  | $ | (3,417 | ) |  | $ | (3,539 | ) |
| Adjustments to reconcile net loss to net cash used in operations: |  |  |  |  |  |  |  |  |
| Depreciation and amortization |  |  | 1,000 |  |  |  | 1,149 |  |
| Stock-based compensation expense |  |  | 909 |  |  |  | 249 |  |
| Provision for excess and obsolete inventory |  |  | 789 |  |  |  | 89 |  |
| Change in fair value of warrants |  |  | — |  |  |  | (2,946 | ) |
| Non-cash interest income |  |  | (134 | ) |  |  | (112 | ) |
| Other non-cash items |  |  | 102 |  |  |  | 100 |  |
| Unrealized foreign exchange loss on cash and cash equivalents |  |  | 85 |  |  |  | — |  |
| Changes in operating asset and liability accounts: |  |  |  |  |  |  |  |  |
| Accounts receivable |  |  | 8,783 |  |  |  | (2,874 | ) |
| Inventory |  |  | 1,132 |  |  |  | 108 |  |
| Prepaid expenses and other assets |  |  | (496 | ) |  |  | (1,002 | ) |
| Accounts payable and accrued expenses |  |  | (7,974 | ) |  |  | (181 | ) |
| Deferred revenue |  |  | (3,894 | ) |  |  | 3,093 |  |
| Net cash used in operating activities |  |  | (3,115 | ) |  |  | (5,866 | ) |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |
| Purchase of property, plant and equipment |  |  | (637 | ) |  |  | (836 | ) |
| Proceeds from the sale of property, plant and equipment |  |  | — |  |  |  | 3,001 |  |
| Change in other assets |  |  | 128 |  |  |  | 94 |  |
| Net cash (used in)/provided by investing activities |  |  | (509 | ) |  |  | 2,259 |  |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |
| Repurchase of treasury stock |  |  | (376 | ) |  |  | (283 | ) |
| Net cash used in financing activities |  |  | (376 | ) |  |  | (283 | ) |
| Effect of exchange rate changes on cash |  |  | 12 |  |  |  | 359 |  |
| Net decrease in cash, cash equivalents and restricted cash |  |  | (3,988 | ) |  |  | (3,531 | ) |
| Cash, cash equivalents and restricted cash at beginning of period |  |  | 30,864 |  |  |  | 78,198 |  |
| Cash, cash equivalents and restricted cash at end of period |  | $ | 26,876 |  |  | $ | 74,667 |  |

[0001437749-20-016665:8k_2_02:33]
| AMSC Reports Q1FY20 Results | Page 7 |

[0001437749-20-016665:8k_2_02:34]
RECONCILIATION OF GAAP NET LOSS TO NON-GAAP NET LOSS

[0001437749-20-016665:8k_2_02:35]
(In thousands, except per share data)

[0001437749-20-016665:8k_2_02:36]
|  |  | Three Months Ended June 30, |  |
|  |  | 2020 |  |  | 2019 |  |
| Net loss |  | $ | (3,417 | ) |  | $ | (3,539 | ) |
| Stock-based compensation |  |  | 909 |  |  |  | 249 |  |
| Amortization of acquisition-related intangibles |  |  | 121 |  |  |  | 85 |  |
| Change in fair value of warrants |  |  | — |  |  |  | (2,946 | ) |
| Non-GAAP net loss |  | $ | (2,387 | ) |  | $ | (6,151 | ) |
| Non-GAAP net loss per share - basic and diluted |  | $ | (0.11 | ) |  | $ | (0.30 | ) |
| Weighted average shares outstanding - basic and diluted |  |  | 21,689 |  |  |  | 20,514 |  |

[0001437749-20-016665:8k_2_02:37]
RECONCILIATION OF GAAP OPERATING CASH FLOW TO NON-GAAP OPERATING CASH FLOW

[0001437749-20-016665:8k_2_02:38]
(In thousands)

[0001437749-20-016665:8k_2_02:39]
|  |  | Three months ended |  |
|  |  | June 30, 2020 |  |  | June 30, 2019 |  |
| Operating cash flow |  | $ | (3,115 | ) |  | $ | (5,866 | ) |
| Sinovel settlement (net of legal fees and expenses) |  |  | — |  |  |  | 1,000 |  |
| Non-GAAP operating cash flow |  | $ | (3,115 | ) |  | $ | (4,866 | ) |

[0001437749-20-016665:8k_2_02:40]
Reconciliation of Forecast GAAP Net Loss to Non-GAAP Net Loss

[0001437749-20-016665:8k_2_02:41]
(In millions, except per share data)

[0001437749-20-016665:8k_2_02:42]
|  |  | Three months ending |  |
|  |  | September 30, 2020 |  |
| Net loss |  | $ | (6.5 | ) |
| Stock-based compensation |  |  | 0.9 |  |
| Amortization of acquisition-related intangibles |  |  | 0.1 |  |
| Non-GAAP net loss |  | $ | (5.5 | ) |
| Non-GAAP net loss per share |  | $ | (0.25 | ) |
| Shares outstanding |  |  | 21.9 |  |

[0001437749-20-016665:8k_2_02:43]
| AMSC Reports Q1FY20 Results | Page 8 |

[0001437749-20-016665:8k_2_02:44]
Note: Non-GAAP net loss is defined by the Company as net income (loss) before; stock-based compensation; amortization of acquisition-related intangibles; changes in fair value of warrants; other non-cash or unusual charges, and the tax effect of adjustments calculated at the relevant rate for our non-GAAP metric. The Company believes non-GAAP net loss assists management and investors in comparing the Company’s performance across reporting periods on a consistent basis by excluding these non-cash, non-recurring or other charges that it does not believe are indicative of its core operating performance.  The Company no longer has any warrants outstanding, therefore the Company's non-GAAP net loss guidance does not include the impact from this adjustment.  Actual non-GAAP net loss for the fiscal quarter ending September 30, 2020, including the above adjustments, may differ materially from those forecasted in the table above.

[0001437749-20-016665:8k_2_02:45]
Non-GAAP operating cash flow is defined by the Company as operating cash flow before: Sinovel settlement (net of legal fees and expenses); and other unusual cash flows or items. The Company believes non-GAAP operating cash flow assists management and investors in comparing the Company’s operating cash flow across reporting periods on a consistent basis by excluding these non-recurring cash items that it does not believe are indicative of its core operating cash flow.

[0001437749-20-016665:8k_2_02:46]
Generally, a non-GAAP financial measure is a numerical measure of a company's performance, financial position or cash flow that either excludes or includes amounts that are not normally excluded or included in the most directly comparable measure calculated and presented in accordance with GAAP. The non-GAAP measures included in this release, however, should be considered in addition to, and not as a substitute for or superior to, operating income, cash flows, or other measures of financial performance prepared in accordance with GAAP. A reconciliation of GAAP to non-GAAP net loss is set forth in the table above.

[0001437749-20-016665:8k_2_02:47]
AMSC Contacts

[0001437749-20-016665:8k_2_02:48]
Investor Relations Contact:

[0001437749-20-016665:8k_2_02:49]
LHA Investor Relations

[0001437749-20-016665:8k_2_02:50]
Sanjay M. Hurry

[0001437749-20-016665:8k_2_02:51]
(212) 838-3777

[0001437749-20-016665:8k_2_02:52]
amscIR@lhai.com

[0001437749-20-016665:8k_2_02:53]
Public Relations Contact:

[0001437749-20-016665:8k_2_02:54]
RooneyPartners LLC

[0001437749-20-016665:8k_2_02:55]
Bob Cavosi

[0001437749-20-016665:8k_2_02:56]
646-638-9891

[0001437749-20-016665:8k_2_02:57]
rcavosi@rooneyco.com

[0001437749-20-016665:8k_2_02:58]
AMSC Communications Manager:

[0001437749-20-016665:8k_2_02:59]
Nicol Golez

[0001437749-20-016665:8k_2_02:60]
978-399-8344

[0001437749-20-016665:8k_2_02:61]
Nicol.Golez@amsc.com
