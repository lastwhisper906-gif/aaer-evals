# AMSC note change history — 0001437749-20-001789 → 0001437749-20-016667


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- added (2020-08-05):
[0001437749-20-016667:note_history:1]
June 30, 2020

- added (2020-08-05):
[0001437749-20-016667:note_history:2]
and

- added (2020-08-05):
[0001437749-20-016667:note_history:3]
March 31, 2020

- added (2020-08-05):
[0001437749-20-016667:note_history:4]
million of restricted cash included in long-term assets and $

- added (2020-08-05):
[0001437749-20-016667:note_history:5]
0.5

- added (2020-08-05):
[0001437749-20-016667:note_history:6]
million of restricted cash included in current assets, respectively. These amounts included in restricted cash primarily represent deposits to secure letters of credit for various supply contracts and long-term projects, including the irrevocable letter of credit in the amount of 
$5.0
 million to secure certain of the Company's obligations under the Subcontract Agreement with ComEd.  These deposits are held in interest bearing accounts.

- removed (2020-08-05):
[0001437749-20-001789:note_history:7]
December 31, 2019

- removed (2020-08-05):
[0001437749-20-001789:note_history:8]
million of restricted cash included in long-term assets. These amounts included in restricted cash primarily represent deposits to secure letters of credit for various supply contracts. These deposits are held in interest bearing accounts.  As part of the agreement with Commonwealth Edison Company to install the Resilient Electric Grid ("REG") system in Chicago, the Company agreed to deliver an irrevocable letter of credit in the amount of 
$5.0
 million to secure certain Company obligations under the Subcontract Agreement.  The funds to secure the 
$5.0
 million letter of credit were deposited in an escrow account on 
 July 1, 2019.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2020-08-05):
[0001437749-20-016667:note_history:9]
1987.
 The Company is a leading system provider of megawatt-scale power resiliency solutions that orchestrate the rhythm and harmony of power on the grid
™
, and that protect and expand the capability of the Navy's fleet. The Company's system level products leverage its proprietary “smart materials” and “smart software and controls” to provide enhanced resiliency and improved performance of megawatt-scale power flow.
  (was, 2020-02-05, similarity 0.7093):
[0001437749-20-001789:note_history:9]
1987.
 The Company is a leading system provider of megawatt-scale power solutions that enhance the performance of the power grid, protect the Navy’s fleet, and lower the cost of wind power. The Company’s system level products leverage its proprietary “smart materials” and “smart software and controls” to provide enhanced resiliency and improved performance of megawatt-scale power flow.

- changed (2020-08-05):
[0001437749-20-016667:note_history:10]
These unaudited condensed consolidated financial statements of the Company have been prepared on a going concern basis in accordance with United States generally accepted accounting principles (“GAAP”) and the Securities and Exchange Commission's (“SEC”) instructions to Form 
10
-Q. The going concern basis of presentation assumes that the Company will continue operations and will be able to realize its assets and discharge its liabilities and commitments in the normal course of business. Certain information and footnote disclosures normally included in the financial statements prepared in accordance with GAAP have been condensed or omitted pursuant to those instructions. The year-end condensed balance sheet data was derived from audited financial statements but does 
not
 include all disclosures required by GAAP. The unaudited condensed consolidated financial statements, in the opinion of management, reflect all adjustments (consisting of normal recurring adjustments) necessary for a fair statement of the results for the interim periods ended
  (was, 2020-02-05, similarity 0.9991):
[0001437749-20-001789:note_history:10]
These unaudited condensed consolidated financial statements of the Company have been prepared on a going concern basis in accordance with United States generally accepted accounting principles (“GAAP”) and the Securities and Exchange Commission’s (“SEC”) instructions to Form 
10
-Q. The going concern basis of presentation assumes that the Company will continue operations and will be able to realize its assets and discharge its liabilities and commitments in the normal course of business. Certain information and footnote disclosures normally included in the financial statements prepared in accordance with GAAP have been condensed or omitted pursuant to those instructions. The year-end condensed balance sheet data was derived from audited financial statements but does 
not
 include all disclosures required by GAAP. The unaudited condensed consolidated financial statements, in the opinion of management, reflect all adjustments (consisting of normal recurring adjustments) necessary for a fair statement of the results for the interim periods ended

- added (2020-08-05):
[0001437749-20-016667:note_history:11]
June 30, 2020

- added (2020-08-05):
[0001437749-20-016667:note_history:12]
June 30, 2020

- changed (2020-08-05):
[0001437749-20-016667:note_history:13]
, and notes thereto, included in the Company's Annual Report on Form 
10
-K for the year ended
  (was, 2020-02-05, similarity 0.9891):
[0001437749-20-001789:note_history:13]
, and notes thereto, included in the Company’s annual report on Form 
10
-K for the year ended

- changed (2020-08-05):
[0001437749-20-016667:note_history:14]
filed with the SEC on 
 June 2, 2020.
  (was, 2020-02-05, similarity 0.6593):
[0001437749-20-001789:note_history:14]
filed with the Securities and Exchange Commission on 
 June 5, 2019.

- added (2020-08-05):
[0001437749-20-016667:note_history:15]
June 30, 2020

- added (2020-08-05):
[0001437749-20-016667:note_history:16]
June 30, 2020

- changed (2020-08-05):
[0001437749-20-016667:note_history:17]
million. Marketable securities include certificate of deposits with maturities between 
eight
 and 
twenty-one
 months.  Cash used in operations for the
  (was, 2020-02-05, similarity 0.7843):
[0001437749-20-001789:note_history:17]
million, with 
no
 outstanding debt other than ordinary trade payables. Marketable securities include certificate of deposits with maturities between 
eleven
 and 
twenty-four
 months.  Cash used in operations for the

- added (2020-08-05):
[0001437749-20-016667:note_history:18]
three

- added (2020-08-05):
[0001437749-20-016667:note_history:19]
June 30, 2020

- changed (2020-08-05):
[0001437749-20-016667:note_history:20]
In 
 December 2015, 
the Company entered into a set of strategic agreements valued at approximately 
$210.0
 million with Inox Wind Ltd. (“Inox” or “Inox Wind”), which includes a multi-year supply contract pursuant to which the Company will supply electrical control systems ("ECS") to Inox and a license agreement allowing Inox to manufacture a limited number of ECS. After Inox purchases the specified number of ECS required under the terms of the supply contract, Inox agreed that the Company will continue as Inox's preferred supplier and Inox will be required to purchase from the Company a majority of its ECS requirements for an additional 
three
-year period. Pursuant to these strategic agreements, Inox must forecast future purchase orders of sets of ECS which become firm orders 
three
 months prior to shipment, and Inox must post letters of credit before the Company will ship such orders. Inox is currently delinquent on its obligation to post letters of credit for sets of ECS that Inox forecasted to purchase under the terms of the supply contract.  On 
 May 29, 2020, 
the Company sent written notice to Inox notifying Inox of its default under the supply contract due to Inox's failure to post letters of credit in the amount of 
€6.0
 million for the payment of ECS that Inox is obligated to purchase under the terms of the supply contract.  If Inox fails to post letters of credit in the amount of 
€6.0
 million in accordance with the terms of the supply contract within the 
ninety
 day cure period after receipt of the default notice, then the Company 
 may 
terminate the supply contract by providing written notice of such termination to Inox.  We cannot predict if and when Inox will post letters of credit consistent with the forecasted ECS quantities. Inox's failure to post letters of credit and take delivery of forecasted ECS quantities would impact the Company's revenues and liquidity.  In the event the Company were to terminate the supply contract, the Company's revenues and liquidity would also be impacted.
  (was, 2020-02-05, similarity 0.6384):
[0001437749-20-001789:note_history:20]
In 
 December 2015, 
the Company entered into a set of strategic agreements valued at approximately 
$210.0
 million with Inox Wind Ltd. (“Inox” or “Inox Wind”), which includes a multi-year supply contract pursuant to which the Company will supply electrical control systems ("ECS") to Inox and a license agreement allowing Inox to manufacture a limited number of ECS. After Inox purchases the specified number of ECS required under the terms of the supply contract, Inox agreed that the Company will continue as Inox’s preferred supplier and Inox will be required to purchase from the Company a majority of its ECS requirements for an additional 
three
-year period. Pursuant to these strategic agreements, Inox must forecast future purchase orders of sets of ECS which become firm orders 
three
 months prior to shipment, and Inox must post letters of credit before the Company will ship such orders. Inox is currently delinquent on its obligation to post letters of credit for sets of ECS that Inox forecasted to purchase under the terms of the supply contract.  We cannot predict if and when Inox will post letters of credit consistent with the forecasted ECS quantities. Inox’s failure to post letters of credit and take delivery of forecasted ECS quantities would impact the Company’s revenues and liquidity.

- added (2020-08-05):
[0001437749-20-016667:note_history:21]
In 
 March 2020, 
the World Health Organization declared the disease caused by the novel coronavirus, COVID-
19,
 to be a pandemic. COVID-
19
 has spread throughout the globe, including in the Commonwealth of Massachusetts where the Company's headquarters are located, and in other areas where the Company has business operations. In response to the outbreak, the Company has followed the guidelines of the U.S. Centers for Disease Control and Prevention and applicable state government authorities to protect the health and safety of the Company's employees, families, suppliers, customers and communities. While these existing measures and, COVID-
19
 generally, have 
not
 materially disrupted the Company's business to date, any future actions necessitated by the COVID-
19
 pandemic 
 may 
result in disruption to the Company's business.

- added (2020-08-05):
[0001437749-20-016667:note_history:22]
While the COVID-
19
 pandemic continues to rapidly evolve, the Company continues to assess the impact of the COVID-
19
 pandemic to best mitigate risk and continue the operations of the Company's business. The extent to which the outbreak impacts the Company's business, liquidity, results of operations and financial condition will depend on future developments, which are highly uncertain and cannot be predicted with confidence, including new information that 
 may 
emerge concerning the severity of the COVID-
19
 pandemic and the actions to contain it or treat its impact, among others.  If the Company, its customers or suppliers experience prolonged shutdowns or other business disruptions, the Company's business, liquidity, results of operations and financial condition are likely to be materially adversely affected, and the Company's ability to access the capital markets 
 may 
be limited.

- added (2020-08-05):
[0001437749-20-016667:note_history:23]
three

- added (2020-08-05):
[0001437749-20-016667:note_history:24]
June 30, 2020

- added (2020-08-05):
[0001437749-20-016667:note_history:25]
. The Company's liquidity is highly dependent on its ability to increase revenues, including its ability to collect revenues under its agreements with Inox, its ability to control its operating costs, and its ability to raise additional capital, if necessary.  The impact of the COVID-
19
 pandemic on the global financing markets 
 may 
reduce the Company's ability to raise additional capital, if necessary, which could negatively impact the Company's liquidity.  There can be 
no
 assurance that the Company will be able to continue to raise additional capital, on favorable terms or at all, from other sources or execute on any other means of improving liquidity described above.

- removed (2020-08-05):
[0001437749-20-001789:note_history:26]
December 31, 2019

- removed (2020-08-05):
[0001437749-20-001789:note_history:27]
December 31, 2019

- removed (2020-08-05):
[0001437749-20-001789:note_history:28]
December 31, 2019

- removed (2020-08-05):
[0001437749-20-001789:note_history:29]
December 31, 2019

- removed (2020-08-05):
[0001437749-20-001789:note_history:30]
nine

- removed (2020-08-05):
[0001437749-20-001789:note_history:31]
December 31, 2019

- removed (2020-08-05):
[0001437749-20-001789:note_history:32]
On 
 July

- removed (2020-08-05):
[0001437749-20-001789:note_history:33]
3,

- removed (2020-08-05):
[0001437749-20-001789:note_history:34]
2018,
 the Company and its wholly-owned subsidiaries Suzhou AMSC Superconductor Co. Ltd. (“AMSC China”) and AMSC Austria GMBH (“AMSC Austria”) entered into a settlement agreement (the “Settlement Agreement”) with Sinovel Wind Group Co., Ltd. (“Sinovel”). The Settlement Agreement settles the litigation and arbitration proceedings between the Company and Sinovel. Under the terms of the Settlement Agreement, Sinovel agreed to pay AMSC China an aggregate cash amount in Renminbi (“RMB”) equivalent to 
$57.5
 million, consisting of 
two
 installments. Sinovel paid the 
first
 installment of the RMB equivalent of 
$32.5
 million on 
 July

- removed (2020-08-05):
[0001437749-20-001789:note_history:35]
4,

- removed (2020-08-05):
[0001437749-20-001789:note_history:36]
2018,
 which was repatriated to the Company during the 
nine
 months ended 
 December

- removed (2020-08-05):
[0001437749-20-001789:note_history:37]
31,

- removed (2020-08-05):
[0001437749-20-001789:note_history:38]
2018
 and paid the 
second
 installment of the RMB equivalent of 
$25.0
 million on 
 December 27, 2018.  
The Company’s fiscal 
2018
 results included the net gain received from the settlement with Sinovel of 
$52.7
 million.

- removed (2020-08-05):
[0001437749-20-001789:note_history:39]
On 
 February 1, 2018, 
ASC Devens LLC (the “Seller”), a wholly-owned subsidiary of the Company, entered into a Purchase and Sale Agreement (the “PSA”) with 
64
 Jackson, LLC (the “Purchaser”) and Stewart Title Guaranty Company (“Escrow Agent”), to effectuate the sale of certain real property located at 
64
 Jackson Road, Devens, Massachusetts, including the building that had served as the Company’s headquarters (collectively, the “Property”), in exchange for total consideration of 
$23.0
 million, composed of (i) cash consideration of 
$17.0
 million, and (ii) a 
$6.0
 million subordinated secured commercial promissory note payable to the Company (the “Seller Note”). Subsequently, the Seller, the Purchaser and Jackson 
64
 MGI, LLC (“Assignee”) entered into an Assignment of Purchase and Sale Agreement (the “Assignment Agreement”), pursuant to which the Purchaser assigned all of its rights and interests in the PSA to the Assignee and the Assignee agreed to assume all of the Purchaser’s obligations and liabilities under the PSA. The transaction closed on 
 March 28, 2018, 
at which time the Company received, from the Assignee, cash consideration, net of certain agreed upon closing costs, of 
$16.9
 million, and the Seller Note at an interest rate of 
1.96%.
 The Seller Note was secured by a subordinated 
second
 mortgage on the Property and a subordinated 
second
 assignment of leases and rents.  The Company received the 
first

- removed (2020-08-05):
[0001437749-20-001789:note_history:40]
$3.0
 million payment due pursuant to the Seller Note on 
 March 28, 2019 
and the 
second

- removed (2020-08-05):
[0001437749-20-001789:note_history:41]
$3.0
 million payment plus interest on 
 May 23, 2019.

- removed (2020-08-05):
[0001437749-20-001789:note_history:42]
The Company issued warrants in conjunction with an equity offering to Hudson Bay Capital ("Hudson") in 
 November 2014 (
the "Hudson Warrant").  The Hudson Warrant was partially exercised on 
 November 13, 2019 
with an exercise price of 
$7.81.
 The Company received 
$6.1
 million in cash for 
786,000
 warrants. The remaining 
32,181
 warrants expired on 
 November 13, 2019.

- removed (2020-08-05):
[0001437749-20-001789:note_history:43]
nine

- removed (2020-08-05):
[0001437749-20-001789:note_history:44]
December 31, 2019

- removed (2020-08-05):
[0001437749-20-001789:note_history:45]
. The Company’s liquidity is highly dependent on its ability to increase revenues, including its ability to collect revenues under its agreements with Inox, its ability to control its operating costs, and its ability to raise additional capital, if necessary. There can be 
no
 assurance that the Company will be able to continue to raise additional capital, on favorable terms or at all, from other sources or execute on any other means of improving liquidity described above.


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2020-08-05):
[0001437749-20-016667:note_history:46]
|  |  | Three Months Ended June 30, 2020 |  |
| Product Line: |  | Grid |  |  | Wind |  |
| Equipment and systems |  | $ | 16,537 |  |  | $ | 2,618 |  |
| Services and technology development |  |  | 1,178 |  |  |  | 880 |  |
| Total |  | $ | 17,715 |  |  | $ | 3,498 |  |
| Region: |  |  |  |  |  |  |  |  |
| Americas |  | $ | 10,554 |  |  | $ | 12 |  |
| Asia Pacific |  |  | 6,015 |  |  |  | 3,269 |  |
| EMEA |  |  | 1,146 |  |  |  | 217 |  |
| Total |  | $ | 17,715 |  |  | $ | 3,498 |  |
  (was, 2020-02-05, similarity 0.7051):
[0001437749-20-001789:note_history:46]
|  |  | Three Months Ended December 31, 2019 |  |  | Nine Months Ended December 31, 2019 |  |
| Product Line: |  | Grid |  |  | Wind |  |  | Grid |  |  | Wind |  |
| Equipment and systems |  | $ | 14,040 |  |  | $ | 2,160 |  |  | $ | 32,438 |  |  | $ | 7,742 |  |
| Services and technology development |  |  | 1,192 |  |  |  | 523 |  |  |  | 4,139 |  |  |  | 1,379 |  |
| Total |  | $ | 15,232 |  |  | $ | 2,683 |  |  | $ | 36,577 |  |  | $ | 9,120 |  |
| Region: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas |  | $ | 10,164 |  |  | $ | 2 |  |  | $ | 28,663 |  |  | $ | 49 |  |
| Asia Pacific |  |  | 330 |  |  |  | 2,647 |  |  |  | 2,550 |  |  |  | 8,968 |  |
| EMEA |  |  | 4,738 |  |  |  | 34 |  |  |  | 5,364 |  |  |  | 104 |  |
| Total |  | $ | 15,232 |  |  | $ | 2,683 |  |  | $ | 36,577 |  |  | $ | 9,120 |  |

- changed (2020-08-05):
[0001437749-20-016667:note_history:47]
|  |  | Three Months Ended June 30, 2019 |  |
| Product Line: |  | Grid |  |  | Wind |  |
| Equipment and systems |  | $ | 8,354 |  |  | $ | 3,505 |  |
| Services and technology development |  |  | 1,501 |  |  |  | 410 |  |
| Total |  | $ | 9,855 |  |  | $ | 3,915 |  |
| Region: |  |  |  |  |  |  |  |  |
| Americas |  | $ | 7,801 |  |  | $ | 46 |  |
| Asia Pacific |  |  | 1,827 |  |  |  | 3,856 |  |
| EMEA |  |  | 227 |  |  |  | 13 |  |
| Total |  | $ | 9,855 |  |  | $ | 3,915 |  |
  (was, 2020-02-05, similarity 0.7051):
[0001437749-20-001789:note_history:47]
|  |  | Three Months Ended December 31, 2018 |  |  | Nine Months Ended December 31, 2018 |  |
| Product Line: |  | Grid |  |  | Wind |  |  | Grid |  |  | Wind |  |
| Equipment and systems |  | $ | 4,614 |  |  | $ | 7,215 |  |  | $ | 17,571 |  |  | $ | 17,925 |  |
| Services and technology development |  |  | 2,212 |  |  |  | 93 |  |  |  | 5,754 |  |  |  | 368 |  |
| Total |  | $ | 6,826 |  |  | $ | 7,308 |  |  | $ | 23,325 |  |  | $ | 18,293 |  |
| Region: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas |  | $ | 3,771 |  |  | $ | 36 |  |  | $ | 16,319 |  |  | $ | 82 |  |
| Asia Pacific |  |  | 2,815 |  |  |  | 7,263 |  |  |  | 5,930 |  |  |  | 18,136 |  |
| EMEA |  |  | 240 |  |  |  | 9 |  |  |  | 1,076 |  |  |  | 75 |  |
| Total |  | $ | 6,826 |  |  | $ | 7,308 |  |  | $ | 23,325 |  |  | $ | 18,293 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2020-08-05):
[0001437749-20-016667:note_history:48]
The Company's revenues in its Grid segment are derived primarily through enabling the transmission and distribution of power, providing planning services that allow it to identify power grid needs and risks, and developing ship protection systems for the U.S. Navy. The Company's revenues in its Wind segment are derived primarily through supplying advanced power electronics and control systems, licensing its highly engineered wind turbine designs, and providing extensive customer support services to wind turbine manufacturers. The Company records revenue based on a 
five
-step model in accordance with Accounting Standards Codification ("ASC") 
606,
  (was, 2020-02-05, similarity 0.7848):
[0001437749-20-001789:note_history:48]
The Company’s revenues in its Grid segment are derived primarily through enabling the transmission and distribution of power, providing planning services that allow it to identify power grid needs and risks, and developing ship protection systems for the U.S. Navy. The Company’s revenues in its Wind segment are derived primarily through supplying advanced power electronics and control systems, licensing its highly engineered wind turbine designs, and providing extensive customer support services to wind turbine manufacturers. The Company records revenue based on a 
five
-step model in accordance with ASC 
606.
 For its customer contracts, the Company identifies the performance obligations, determines the transaction price, allocates the contract transaction price to the performance obligations, and recognizes the revenue when (or as) control of goods or services is transferred to the customer. In the

- added (2020-08-05):
[0001437749-20-016667:note_history:49]
Revenue from Contracts with Customers
. For its customer contracts, the Company identifies the performance obligations, determines the transaction price, allocates the contract transaction price to the performance obligations, and recognizes the revenue when (or as) control of goods or services is transferred to the customer. In the

- added (2020-08-05):
[0001437749-20-016667:note_history:50]
three

- added (2020-08-05):
[0001437749-20-016667:note_history:51]
June 30, 2020

- changed (2020-08-05):
[0001437749-20-016667:note_history:52]
In the Company's equipment and system product line, each contract with a customer summarizes each product sold to a customer, which typically represents distinct performance obligations. A contract's transaction price is allocated to each distinct performance obligation using the respective standalone selling price which is determined primarily using the cost-plus expected margin approach and recognized as revenue when, or as, the performance obligation is satisfied. The majority of the Company's product sales transfer control to the customer in line with the contracted delivery terms and revenue is recorded at the point in time when title and risk transfer to the customer, as the Company has determined that this is the point in time that control transfers to the customer.
  (was, 2020-02-05, similarity 0.9987):
[0001437749-20-001789:note_history:52]
In the Company's equipment and system product line, each contract with a customer summarizes each product sold to a customer, which typically represents distinct performance obligations. A contract's transaction price is allocated to each distinct performance obligation using the respective standalone selling price which is determined primarily using the cost-plus expected margin approach and recognized as revenue when, or as, the performance obligation is satisfied. The majority of the Company’s product sales transfer control to the customer in line with the contracted delivery terms and revenue is recorded at the point in time when title and risk transfer to the customer, as the Company has determined that this is the point in time that control transfers to the customer.

- changed (2020-08-05):
[0001437749-20-016667:note_history:53]
The Company's equipment and system product line includes certain contracts which do 
not
 meet the requirements of an exchange transaction and therefore do 
not
 fall within the scope of ASC 
606.
  As these non-exchange transaction contracts are considered grant revenue and do 
not
 fall within any specific accounting literature, the Company follows guidance within ASC 
606
 by analogy to recognize grant revenue over time.  In each of the
  (was, 2020-02-05, similarity 0.9834):
[0001437749-20-001789:note_history:53]
The Company's equipment and system product line includes certain contracts which do 
not
 meet the requirements of an exchange transaction and therefore do 
not
 fall within the scope of ASC 
606.
  As these non-exchange transaction contracts are considered grant revenue and do 
not
 fall within any specific accounting literature, the Company follows guidance within ASC 
606
 by analogy to recognize grant revenue over time.  In the

- changed (2020-08-05):
[0001437749-20-016667:note_history:54]
three
 months ended 
 June 30, 2020
  (was, 2020-02-05, similarity 0.7164):
[0001437749-20-001789:note_history:54]
three
 and 
nine
 months ended 
 December 31, 2019

- changed (2020-08-05):
[0001437749-20-016667:note_history:55]
and
  (was, 2020-02-05, similarity 0.75):
[0001437749-20-001789:note_history:55]
, and

- changed (2020-08-05):
[0001437749-20-016667:note_history:56]
the Company recorded $
  (was, 2020-02-05, similarity 0.9565):
[0001437749-20-001789:note_history:56]
, the Company recorded $

- changed (2020-08-05):
[0001437749-20-016667:note_history:57]
million in grant revenue, which is included in the Company's Grid segment revenue.
  (was, 2020-02-05, similarity 0.8111):
[0001437749-20-001789:note_history:57]
million in grant revenue, respectively, which is included in the Company’s Grid revenue. There was

- changed (2020-08-05):
[0001437749-20-016667:note_history:58]
The Company's policy is 
not
 to accept volume discounts, product returns, or rebates and allowances within its contracts. In the event a contract was approved with any of these terms, it would be evaluated for variable consideration, estimated and recorded as a reduction of revenue in the same period the related product revenue was recorded.
  (was, 2020-02-05, similarity 0.9795):
[0001437749-20-001789:note_history:58]
The Company’s policy is to 
not
 accept volume discounts, product returns, or rebates and allowances within its contracts. In the event a contract was approved with any of these terms, it would be evaluated for variable consideration, estimated and recorded as a reduction of revenue in the same period the related product revenue was recorded.

- changed (2020-08-05):
[0001437749-20-016667:note_history:59]
The Company provides assurance-type warranties on all product sales for a term of typically 
one
 to 
three
 years, and extended service-type warranties at the customer's option for an additional term ranging up to 
four
 additional years. The Company accrues for the estimated warranty costs for assurance warranties at the time of sale based on historical warranty experience plus any known or expected changes in warranty exposure. For all extended service-type warranties, the Company recognizes the revenue ratably over time during the effective period of the services.
  (was, 2020-02-05, similarity 0.9947):
[0001437749-20-001789:note_history:59]
The Company provides assurance-type warranties on all product sales for a term of typically 
one
 to 
two
 years, and extended service-type warranties at the customer's option for an additional term ranging up to 
four
 additional years. The Company accrues for the estimated warranty costs for assurance warranties at the time of sale based on historical warranty experience plus any known or expected changes in warranty exposure. For all extended service-type warranties, the Company recognizes the revenue ratably over time during the effective period of the services.

- changed (2020-08-05):
[0001437749-20-016667:note_history:60]
The Company's contracts with customers do 
not
 typically include extended payment terms and 
 may 
include milestone billing over the life of the contract. Payment terms vary by contract type and type of customer and generally range from 
30
 to 
60
 days from delivery.
  (was, 2020-02-05, similarity 0.9962):
[0001437749-20-001789:note_history:60]
The Company’s contracts with customers do 
not
 typically include extended payment terms and 
 may 
include milestone billing over the life of the contract. Payment terms vary by contract type and type of customer and generally range from 
30
 to 
60
 days from delivery.

- changed (2020-08-05):
[0001437749-20-016667:note_history:61]
The following tables disaggregate the Company's revenue by product line and by shipment destination:
  (was, 2020-02-05, similarity 0.99):
[0001437749-20-001789:note_history:61]
The following tables disaggregate the Company’s revenue by product line and by shipment destination:

- changed (2020-08-05):
[0001437749-20-016667:note_history:62]
|  |  | Three Months Ended June 30, 2020 |  |
| Product Line: |  | Grid |  |  | Wind |  |
| Equipment and systems |  | $ | 16,537 |  |  | $ | 2,618 |  |
| Services and technology development |  |  | 1,178 |  |  |  | 880 |  |
| Total |  | $ | 17,715 |  |  | $ | 3,498 |  |
| Region: |  |  |  |  |  |  |  |  |
| Americas |  | $ | 10,554 |  |  | $ | 12 |  |
| Asia Pacific |  |  | 6,015 |  |  |  | 3,269 |  |
| EMEA |  |  | 1,146 |  |  |  | 217 |  |
| Total |  | $ | 17,715 |  |  | $ | 3,498 |  |
  (was, 2020-02-05, similarity 0.7051):
[0001437749-20-001789:note_history:62]
|  |  | Three Months Ended December 31, 2019 |  |  | Nine Months Ended December 31, 2019 |  |
| Product Line: |  | Grid |  |  | Wind |  |  | Grid |  |  | Wind |  |
| Equipment and systems |  | $ | 14,040 |  |  | $ | 2,160 |  |  | $ | 32,438 |  |  | $ | 7,742 |  |
| Services and technology development |  |  | 1,192 |  |  |  | 523 |  |  |  | 4,139 |  |  |  | 1,379 |  |
| Total |  | $ | 15,232 |  |  | $ | 2,683 |  |  | $ | 36,577 |  |  | $ | 9,120 |  |
| Region: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas |  | $ | 10,164 |  |  | $ | 2 |  |  | $ | 28,663 |  |  | $ | 49 |  |
| Asia Pacific |  |  | 330 |  |  |  | 2,647 |  |  |  | 2,550 |  |  |  | 8,968 |  |
| EMEA |  |  | 4,738 |  |  |  | 34 |  |  |  | 5,364 |  |  |  | 104 |  |
| Total |  | $ | 15,232 |  |  | $ | 2,683 |  |  | $ | 36,577 |  |  | $ | 9,120 |  |

- changed (2020-08-05):
[0001437749-20-016667:note_history:63]
|  |  | Three Months Ended June 30, 2019 |  |
| Product Line: |  | Grid |  |  | Wind |  |
| Equipment and systems |  | $ | 8,354 |  |  | $ | 3,505 |  |
| Services and technology development |  |  | 1,501 |  |  |  | 410 |  |
| Total |  | $ | 9,855 |  |  | $ | 3,915 |  |
| Region: |  |  |  |  |  |  |  |  |
| Americas |  | $ | 7,801 |  |  | $ | 46 |  |
| Asia Pacific |  |  | 1,827 |  |  |  | 3,856 |  |
| EMEA |  |  | 227 |  |  |  | 13 |  |
| Total |  | $ | 9,855 |  |  | $ | 3,915 |  |
  (was, 2020-02-05, similarity 0.7051):
[0001437749-20-001789:note_history:63]
|  |  | Three Months Ended December 31, 2018 |  |  | Nine Months Ended December 31, 2018 |  |
| Product Line: |  | Grid |  |  | Wind |  |  | Grid |  |  | Wind |  |
| Equipment and systems |  | $ | 4,614 |  |  | $ | 7,215 |  |  | $ | 17,571 |  |  | $ | 17,925 |  |
| Services and technology development |  |  | 2,212 |  |  |  | 93 |  |  |  | 5,754 |  |  |  | 368 |  |
| Total |  | $ | 6,826 |  |  | $ | 7,308 |  |  | $ | 23,325 |  |  | $ | 18,293 |  |
| Region: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas |  | $ | 3,771 |  |  | $ | 36 |  |  | $ | 16,319 |  |  | $ | 82 |  |
| Asia Pacific |  |  | 2,815 |  |  |  | 7,263 |  |  |  | 5,930 |  |  |  | 18,136 |  |
| EMEA |  |  | 240 |  |  |  | 9 |  |  |  | 1,076 |  |  |  | 75 |  |
| Total |  | $ | 6,826 |  |  | $ | 7,308 |  |  | $ | 23,325 |  |  | $ | 18,293 |  |

- added (2020-08-05):
[0001437749-20-016667:note_history:64]
June 30, 2020

- added (2020-08-05):
[0001437749-20-016667:note_history:65]
, and 
 June 30,

- added (2020-08-05):
[0001437749-20-016667:note_history:66]
, the Company's contract assets and liabilities primarily relate to the timing differences between cash received from a customer in connection with contractual rights to invoicing and the timing of revenue recognition following completion of performance obligations. The Company's accounts receivable balance is made up entirely of customer contract related balances. Changes in the Company's contract assets, which are included in “Accounts receivable (unbilled)” and “Deferred program costs” (see Note 
7,
 “Accounts Receivable” and Note 
8,
 “Inventory” for a reconciliation to the condensed consolidated balance sheets) and contract liabilities, which are included in the current portion and long term portion of "Deferred revenue" in the Company's condensed consolidated balance sheets, are as follows:

- changed (2020-08-05):
[0001437749-20-016667:note_history:67]
|  |  | Unbilled Accounts Receivable |  |  | Deferred Program Costs |  |  | Contract Liabilities |  |
| Beginning balance as of March 31, 2020 |  | $ | 5,711 |  |  | $ | 1,631 |  |  | $ | 26,142 |  |
| Increases for costs incurred to fulfill performance obligations |  |  | — |  |  |  | 1,978 |  |  |  | — |  |
| Increase (decrease) due to customer billings |  |  | (3,620 | ) |  |  | — |  |  |  | 12,276 |  |
| Decrease due to cost recognition on completed performance obligations |  |  | — |  |  |  | (2,815 | ) |  |  | — |  |
| Increase (decrease) due to recognition of revenue based on transfer of control of performance obligations |  |  | 2,033 |  |  |  | — |  |  |  | (16,227 | ) |
| Other changes and FX impact |  |  | 1 |  |  |  | 7 |  |  |  | 194 |  |
| Ending balance as of June 30, 2020 |  | $ | 4,125 |  |  | $ | 801 |  |  | $ | 22,385 |  |
  (was, 2020-02-05, similarity 0.9192):
[0001437749-20-001789:note_history:67]
|  |  | Unbilled Accounts Receivable |  |  | Deferred Program Costs |  |  | Contract Liabilities |  |
| Beginning balance as of March 31, 2019 |  | $ | 2,213 |  |  | $ | 318 |  |  | $ | 15,519 |  |
| Increases for costs incurred to fulfill performance obligations |  |  | — |  |  |  | 3,001 |  |  |  | — |  |
| Increase (decrease) due to customer billings |  |  | (7,417 | ) |  |  | — |  |  |  | 36,461 |  |
| Decrease due to cost recognition on completed performance obligations |  |  | — |  |  |  | (2,221 | ) |  |  | — |  |
| Increase (decrease) due to recognition of revenue based on transfer of control of performance obligations |  |  | 9,820 |  |  |  | — |  |  |  | (28,768 | ) |
| Other changes and FX impact |  |  | (3 | ) |  |  | (1 | ) |  |  | (69 | ) |
| Ending balance as of December 31, 2019 |  | $ | 4,613 |  |  | $ | 1,097 |  |  | $ | 23,143 |  |

- changed (2020-08-05):
[0001437749-20-016667:note_history:68]
|  |  | Unbilled Accounts Receivable |  |  | Deferred Program Costs |  |  | Contract Liabilities |  |
| Beginning balance as of March 31, 2019 |  | $ | 2,213 |  |  | $ | 318 |  |  | $ | 15,521 |  |
| Increases for costs incurred to fulfill performance obligations |  |  | — |  |  |  | 771 |  |  |  | — |  |
| Increase (decrease) due to customer billings |  |  | (1,584 | ) |  |  | — |  |  |  | 10,857 |  |
| Decrease due to cost recognition on completed performance obligations |  |  | — |  |  |  | (4 | ) |  |  | — |  |
| Increase (decrease) due to recognition of revenue based on transfer of control of performance obligations |  |  | 1,467 |  |  |  | — |  |  |  | (7,761 | ) |
| Other changes and FX impact |  |  | (3 | ) |  |  | 3 |  |  |  | 73 |  |
| Ending balance as of June 30, 2019 |  | $ | 2,093 |  |  | $ | 1,088 |  |  | $ | 18,690 |  |
  (was, 2020-02-05, similarity 0.9028):
[0001437749-20-001789:note_history:68]
|  |  | Unbilled Accounts Receivable |  |  | Deferred Program Costs |  |  | Contract Liabilities |  |
| Beginning balance as of March 31, 2018 |  | $ | 3,016 |  |  | $ | 2,567 |  |  | $ | 21,937 |  |
| Impact of adoption of ASC 606 |  |  | — |  |  |  | (1,599 | ) |  |  | (2,657 | ) |
| Increases for costs incurred to fulfill performance obligations |  |  | — |  |  |  | 1,461 |  |  |  | — |  |
| Increase (decrease) due to customer billings |  |  | (11,063 | ) |  |  | — |  |  |  | 11,167 |  |
| Decrease due to cost recognition on completed performance obligations |  |  | — |  |  |  | (1,132 | ) |  |  | — |  |
| Increase (decrease) due to recognition of revenue based on transfer of control of performance obligations |  |  | 9,722 |  |  |  | (9 | ) |  |  | (11,345 | ) |
| Other changes and FX impact |  |  | (53 | ) |  |  | 8 |  |  |  | (1,040 | ) |
| Ending balance as of December 31, 2018 |  | $ | 1,622 |  |  | $ | 1,296 |  |  | $ | 18,062 |  |

- changed (2020-08-05):
[0001437749-20-016667:note_history:69]
The Company's remaining performance obligations represent the unrecognized revenue value of the Company's contractual commitments. The Company's performance obligations 
 may 
vary significantly each reporting period based on the timing of major new contractual commitments. As of
  (was, 2020-02-05, similarity 0.9892):
[0001437749-20-001789:note_history:69]
The Company’s remaining performance obligations represent the unrecognized revenue value of the Company’s contractual commitments. The Company’s performance obligations 
 may 
vary significantly each reporting period based on the timing of major new contractual commitments. As of

- added (2020-08-05):
[0001437749-20-016667:note_history:70]
June 30, 2020

- added (2020-08-05):
[0001437749-20-016667:note_history:71]
14.5

- changed (2020-08-05):
[0001437749-20-016667:note_history:72]
three
 months of a 
twelve
-month rolling forecast. The timing of the performance obligations beyond the 
twelve
-month forecast provided by Inox are 
not
 determinable and therefore are 
not
 included in the total remaining performance obligations.  See Note 
1,
 “Nature of the Business and Operations and Liquidity,” for further information regarding the uncertainty of timing of the performance obligations as a result of the written notice that the Company sent to Inox on 
 May 29, 2020 
notifying Inox of its default under the supply contract.
  (was, 2020-02-05, similarity 0.6261):
[0001437749-20-001789:note_history:72]
three
 months of a 
twelve
-month rolling forecast. The timing of the performance obligations beyond the 
twelve
-month forecast provided by Inox are 
not
 determinable and therefore are 
not
 included in the total remaining performance obligations.

- changed (2020-08-05):
[0001437749-20-016667:note_history:73]
The following table sets forth customers who represented 
10%
 or more of the Company's total revenues for the
  (was, 2020-02-05, similarity 0.9714):
[0001437749-20-001789:note_history:73]
The following table sets forth customers who represented 
10%
 or more of the Company’s total revenues for

- changed (2020-08-05):
[0001437749-20-016667:note_history:74]
three
 months ended 
 June 30, 2020
  (was, 2020-02-05, similarity 0.7164):
[0001437749-20-001789:note_history:74]
three
 and 
nine
 months ended 
 December 31, 2019

- added (2020-08-05):
[0001437749-20-016667:note_history:75]
and

- added (2020-08-05):
[0001437749-20-016667:note_history:76]
2019

- added (2020-08-05):
[0001437749-20-016667:note_history:77]
|  |  |  | Three Months Ended |  |
|  | Reportable |  | June 30, |  |
|  | Segment |  | 2020 |  |  | 2019 |  |
| Inox Wind Limited | Wind |  | <10% |  |  | 27% |  |
| Micron Technology | Grid |  | 0% |  |  | 25% |  |
| Siemens Gamesa Renewable Energy | Grid |  | 25% |  |  | 0% |  |
| EPC Services Company | Grid |  | 24% |  |  | 0% |  |

- removed (2020-08-05):
[0001437749-20-001789:note_history:78]
On 
 April 1, 2018, 
the Company adopted Accounting Standards Codification (“ASC”) 
606,

- removed (2020-08-05):
[0001437749-20-001789:note_history:79]
Revenue from Contracts with Customers,

- removed (2020-08-05):
[0001437749-20-001789:note_history:80]
and all the related amendments and applied it to all contracts that were 
not
 completed as of 
 April 1, 2018 
using the modified retrospective method.

- removed (2020-08-05):
[0001437749-20-001789:note_history:81]
three
 and 
nine

- removed (2020-08-05):
[0001437749-20-001789:note_history:82]
December 31, 2019

- removed (2020-08-05):
[0001437749-20-001789:note_history:83]
million and $

- removed (2020-08-05):
[0001437749-20-001789:note_history:84]
no

- removed (2020-08-05):
[0001437749-20-001789:note_history:85]
grant revenue in the

- removed (2020-08-05):
[0001437749-20-001789:note_history:86]
three
 and 
nine

- removed (2020-08-05):
[0001437749-20-001789:note_history:87]
months ended

- removed (2020-08-05):
[0001437749-20-001789:note_history:88]
December 31, 2018

- removed (2020-08-05):
[0001437749-20-001789:note_history:89]
.

- removed (2020-08-05):
[0001437749-20-001789:note_history:90]
December 31, 2019

- removed (2020-08-05):
[0001437749-20-001789:note_history:91]
December 31, 2018

- removed (2020-08-05):
[0001437749-20-001789:note_history:92]
, the Company’s contract assets and liabilities primarily relate to the timing differences between cash received from a customer in connection with contractual rights to invoicing and the timing of revenue recognition following completion of performance obligations. The Company's accounts receivable balance is made up entirely of customer contract related balances. Changes in the Company’s contract assets, which are included in “Accounts Receivable (unbilled)” and “Deferred program costs” (see Note 
7,
 “Accounts Receivable” and Note 
8,
 “Inventory” for a reconciliation to the condensed consolidated balance sheets) and contract liabilities, which are included in the current portion and long term portion of deferred revenue in the Company’s condensed consolidated balance sheets, are as follows:

- removed (2020-08-05):
[0001437749-20-001789:note_history:93]
December 31, 2019

- removed (2020-08-05):
[0001437749-20-001789:note_history:94]
|  |  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  | Reportable |  | December 31, |  |  | December 31, |  |
|  | Segment |  | 2019 |  |  | 2018 |  |  | 2019 |  |  | 2018 |  |
| Inox Wind Limited | Wind |  |  | <10% |  |  |  | 47 | % |  |  | 11 | % |  |  | 40 | % |
| Department of Homeland Security | Grid |  |  | 22 | % |  |  | <10% |  |  |  | 12 | % |  |  | <10% |  |
| Vestas | Grid |  |  | 25 | % |  |  | <10% |  |  |  | 10 | % |  |  | 15 | % |
| Fuji Bridex Pte. Ltd. | Grid |  |  | <10% |  |  |  | 17 | % |  |  | <10% |  |  |  | <10% |  |


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: tag_name, score: 1.0

- added (2020-08-05):
[0001437749-20-016667:note_history:95]
The Company has performed an evaluation of subsequent events through the time of filing this Quarterly Report on Form 
10
-Q with the SEC and has determined that other than the following information, there are 
no
 such events to report.  In 
 July 2020, 
the Company undertook restructuring activities, approved by the Board of Directors, in order to reorganize its global manufacturing operations and reduce its workforce to better reflect the current demand for its wind products.  Over the remainder of fiscal 
2020
 the Company intends to consolidate Wind manufacturing activities into its Massachusetts facilities and as a result reduced the headcount at its operation in Romania.   The cost
s
 associated with this restructuring event are 
not
 expected to be material to the consolidated financial statements.

- removed (2020-08-05):
[0001437749-20-001789:note_history:96]
The Company has performed an evaluation of subsequent events through the time of filing this Quarterly Report on Form 
10
-Q with the SEC and has determined that there are 
no
 such events to report.
