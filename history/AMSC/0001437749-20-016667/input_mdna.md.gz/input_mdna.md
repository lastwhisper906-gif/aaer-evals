# AMSC MD&A — 0001437749-20-016667


## mdna

[0001437749-20-016667:mdna:1]
[same as prior period, unchanged from 0001437749-20-001789:mdna:1]

[0001437749-20-016667:mdna:2]
American Superconductor®, Amperium®, AMSC®, D-VAR®, PowerModule™, D-VAR VVO®, PQ-IVR®, SeaTitan®, Gridtec Solutions™, Windtec Solutions™, Smarter, Cleaner...Better Energy™ and Orchestrate the Rhythm and Harmony of Power on the Grid are trademarks or registered trademarks of American Superconductor Corporation or our subsidiaries. We reserve all of our rights with respect to our trademarks or registered trademarks regardless of whether they are so designated in this Quarterly Report on Form 10-Q by an ® or ™ symbol. All other brand names, product names, trademarks or service marks appearing in this Quarterly Report on Form 10-Q are the property of their respective holders.

[0001437749-20-016667:mdna:3]
[same as prior period, unchanged from 0001437749-20-001789:mdna:3]

[0001437749-20-016667:mdna:4]
We are a leading system provider of megawatt-scale resiliency solutions that orchestrate the rhythm and harmony of power on the grid™, and that protect and expand the capability of the Navy's fleet. In the power grid market, we enable electric utilities, industrial facilities, and renewable energy project developers to connect, transmit and distribute smarter, cleaner and better power through our transmission planning services and power electronics and superconductor-based systems. In the wind power market, we enable manufacturers to field highly competitive wind turbines through our advanced power electronics and control system products, engineering, and support services. Our power grid and wind products and services provide exceptional reliability, security, efficiency and affordability to our customers.

[0001437749-20-016667:mdna:5]
Our power system solutions help to improve energy efficiency, alleviate power grid capacity constraints, improve system resiliency, and increase the adoption of renewable energy generation. Demand for our solutions is driven by the growing needs for modernized smart grids that improve power reliability, security and quality, the U.S. Navy's effort to upgrade on-board power systems to support fleet electrification, and the need for increased renewable sources of electricity, such as wind and solar energy. Concerns about these factors have led to increased spending by corporations and the military, as well as supportive government regulations and initiatives on local, state, and national levels, including renewable portfolio standards, tax incentives and international treaties.

[0001437749-20-016667:mdna:6]
[same as prior period, unchanged from 0001437749-20-001789:mdna:6]

[0001437749-20-016667:mdna:7]
We operate our business under two market-facing business units: Grid and Wind. We believe this market-centric structure enables us to more effectively anticipate and meet the needs of the U.S. Navy, electric utilities, industrial facilities, power generation project developers and wind turbine manufacturers.

[0001437749-20-016667:mdna:8]
|  | • | Grid. Through our Gridtec Solutions™, our Grid business segment enables electric utilities, industrial facilities and renewable energy project developers to connect, transmit and distribute power with exceptional efficiency, reliability, security and affordability. We provide transmission planning services that allow us to identify power grid congestion, poor power quality, and other risks, which help us determine how our solutions can improve network performance. These services often lead to sales of our grid interconnection solutions for wind farms and solar power plants, power quality systems and transmission and distribution cable systems. We also sell ship protection products to the U.S. Navy through our Grid business segment. |

[0001437749-20-016667:mdna:9]
[same as prior period, unchanged from 0001437749-20-001789:mdna:9]

[0001437749-20-016667:mdna:10]
Our fiscal year begins on April 1 and ends on March 31. When we refer to a particular fiscal year, we are referring to the fiscal year beginning on April 1 of that same year. For example, fiscal 2020 refers to the fiscal year beginning on April 1, 2020. Other fiscal years follow similarly.

[0001437749-20-016667:mdna:11]
On October 31, 2018, we entered into a Subcontract Agreement with Commonwealth Edison Company (“ComEd”) (the “Subcontract Agreement”) for the manufacture and installation of the Company’s REG system within ComEd’s electric grid in Chicago, Illinois (the “Project”). As provided in the Subcontract Agreement, the Subcontract Agreement became effective upon the signing of an amendment by us and the U.S. Department of Homeland Security (“DHS”) to the existing contract (the “Prime Contract”) between us and DHS on June 20, 2019. Unless terminated earlier by us, ComEd or DHS according to the terms of the Subcontract Agreement, the term of the Subcontract Agreement will continue until we complete our warranty obligations under the Subcontract Agreement. Under the terms of the Subcontract Agreement, we have agreed, among other things, to provide the REG system and to supervise ComEd’s installation of the REG system in Chicago. As part of our separate cost sharing arrangement with DHS under the Prime Contract, we expect funding provided by DHS in connection with the Subcontract Agreement to be between $9.0 to $11.0 million, which represents the total amount of revenue we are expected to recognize over the term of the Subcontract Agreement and includes up to $1.0 million that we have agreed to reimburse ComEd for costs incurred by ComEd while undertaking its tasks under the Subcontract Agreement (the “Reimbursement Amount”). In addition, we are required to deliver an irrevocable letter of credit in the amount of $5.0 million to secure certain Company obligations under the Subcontract Agreement, which we have done, and deposited $5.0 million in an escrow account as collateral to secure such letter of credit.  ComEd has agreed to provide the site and provide all civil engineering work required to support the installation, operation and integration of the REG system into ComEd’s electric grid. Other than the Reimbursement Amount, ComEd is responsible for its own costs and expenses. DHS’s approval to commence with construction was obtained on June 20, 2019. Substation work on the project began in late 2019 and we are on schedule to deliver the REG project hardware in late 2020. The REG system is expected to be operational in 2021.

[0001437749-20-016667:mdna:12]
In March 2020, the World Health Organization declared the disease caused by the novel coronavirus, COVID-19 to be a pandemic. COVID-19, has spread throughout the globe, including in the Commonwealth of Massachusetts where our headquarters are located, and in other areas where we have business operations. In response to the outbreak, we have followed the guidelines of the U.S. Centers for Disease Control and Prevention and applicable state government authorities to protect the health and safety of our employees, their families, our suppliers, our customers and our communities. While these existing measures and, COVID-19 generally, have not materially disrupted our business to date, any future actions necessitated by the COVID-19 pandemic may result in disruption to our business.

[0001437749-20-016667:mdna:13]
The COVID-19 pandemic continues to rapidly evolve. The extent to which the outbreak impacts our business, liquidity, results of operations and financial condition will depend on future developments, which are highly uncertain and cannot be predicted with confidence, including new information that may emerge concerning the severity of the COVID-19 pandemic and the actions to contain it or treat its impact, among others.

[0001437749-20-016667:mdna:14]
[same as prior period, unchanged from 0001437749-20-001789:mdna:14]

[0001437749-20-016667:mdna:15]
The preparation of the unaudited condensed consolidated financial statements requires that we make estimates and judgments that affect the reported amounts of assets, liabilities, revenues and expenses, and related disclosure of contingent assets and liabilities. We base our estimates on historical experience and various other assumptions that are believed to be reasonable under the circumstances, the results of which form the basis for making judgments about the carrying values of assets and liabilities that are not readily apparent from other sources. Actual results may differ under different assumptions or conditions. There were no significant changes in the critical accounting policies that were disclosed in our Form 10-K for the fiscal year ended March 31, 2020.

[0001437749-20-016667:mdna:16]
[same as prior period, unchanged from 0001437749-20-001789:mdna:16]

[0001437749-20-016667:mdna:17]
Three months ended June 30, 2020 compared to the three months ended June 30, 2019

[0001437749-20-016667:mdna:18]
[same as prior period, unchanged from 0001437749-20-001789:mdna:18]

[0001437749-20-016667:mdna:19]
Total revenues increased 54% to $21.2 million for the three months ended June 30, 2020, compared to $13.8 million for the three months ended June 30, 2019.  Our revenues are summarized as follows (in thousands):

[0001437749-20-016667:mdna:20]
|  |  | Three Months Ended June 30, |  |
|  |  | 2020 |  |  | 2019 |  |
| Revenues: |  |  |  |  |  |  |  |  |
| Grid |  | $ | 17,715 |  |  | $ | 9,855 |  |
| Wind |  |  | 3,498 |  |  |  | 3,915 |  |
| Total |  | $ | 21,213 |  |  | $ | 13,770 |  |

[0001437749-20-016667:mdna:21]
Our Grid business unit accounted for 84% of total revenues for the three months ended June 30, 2020, compared to 72% for the three months ended June 30, 2019. Our Grid business unit revenues increased 80% to $17.7 million in the three months ended June 30, 2020, from $9.9 million in the three months ended June 30, 2019. Grid business unit revenue in the three months ended June 30, 2020 was driven by stronger D-VAR, VVO and SPS revenue.

[0001437749-20-016667:mdna:22]
Our Wind business unit accounted for 16% of total revenues for the three months ended June 30, 2020, compared to 28% for the three months ended June 30, 2019. Revenues in the Wind business unit decreased 11% to $3.5 million in the three months ended June 30, 2020, from $3.9 million in the three months ended June 30, 2019. The decrease over the prior year period was driven primarily by decreased shipments of electrical control systems ("ECS") to Inox partially offset by increased ECS shipments to Doosan.  As further described in Note 1 “Nature of the Business and Operations and Liquidity,” Inox is currently delinquent on its obligations to post letters of credit for sets of ECS that Inox has agreed to purchase under the terms of the supply contract, and on May 29, 2020, we sent written notice to Inox notifying Inox of its default under the supply contract due to Inox’s failure to post letters of credit in the amount of €6.0 million for the payment of ECS that Inox is obligated to purchase under the terms of the supply contract. If Inox fails to post letters of credit in the amount of €6.0 million in accordance with the terms of the supply contract within the ninety-day cure period after receipt of the default notice, then we may terminate the supply contract by providing written notice of such termination to Inox.  In addition, Inox’s ability to perform under the supply contract has been and may continue to be hampered by the prolonged impacts of the COVID-19 pandemic. Starting in March 2020 through the end of May 2020, India’s manufacturing facilities were closed at the direction of India’s government and since such time have closed periodically in regions that become highly affected by COVID-19.  We cannot predict if and when Inox will resume posting letters of credit for payment of contracted-for shipments of ECS. Inox's continued failure to post letters of credit and take delivery of contracted-for shipments of ECS has negatively impacted, and could continue to negatively impact, our revenues and liquidity.  In the event we were to terminate the supply contract, our revenues and liquidity could also be negatively impacted.  Inox has been active in the new central and state government auction regime in India and has a cumulative order book of over 1.4 GW.  However, we cannot predict if and how successful Inox will be in executing on these orders or in obtaining new orders under the new central and state auction regime. Any failure by Inox to succeed under this regime, or any delay in Inox’s ability to deliver its wind turbines, could result in fewer ECS shipments to Inox.

[0001437749-20-016667:mdna:23]
[same as prior period, unchanged from 0001437749-20-001789:mdna:23]

[0001437749-20-016667:mdna:24]
Cost of revenues increased by 33% to $16.2 million for the three months ended June 30, 2020, compared to $12.2 million for the three months ended June 30, 2019. Gross margin was 24% for the three months ended June 30, 2020, compared to 11% for the three months ended June 30, 2019.  The increase in gross margin in the three months ended June 30, 2020 was due to higher revenue and a more favorable product mix.

[0001437749-20-016667:mdna:25]
[same as prior period, unchanged from 0001437749-20-001789:mdna:25]

[0001437749-20-016667:mdna:26]
[same as prior period, unchanged from 0001437749-20-001789:mdna:26]

[0001437749-20-016667:mdna:27]
Research and development expenses were $2.5 million in both periods.  There was a slight increase in overall compensation offset by lower travel expenses in the three months ended June 30, 2020 compared to the three months ended June 30, 2019.

[0001437749-20-016667:mdna:28]
[same as prior period, unchanged from 0001437749-20-001789:mdna:28]

[0001437749-20-016667:mdna:29]
Selling, general and administrative ("SG&A") expenses increased 7% in the three months ended June 30, 2020 to $5.6 million from $5.3 million in the three months ended June 30, 2019. The increase in SG&A expense in the three months ended June 30, 2020 was due to higher overall compensation expense than in the prior year period.

[0001437749-20-016667:mdna:30]
[same as prior period, unchanged from 0001437749-20-001789:mdna:32]

[0001437749-20-016667:mdna:31]
We recorded amortization expense related to our core technology and know-how, trade names and trademark, and intangible assets of $0.1 million in each of the three month periods ended June 30, 2020 and 2019.

[0001437749-20-016667:mdna:32]
Operating loss

[0001437749-20-016667:mdna:33]
Our operating loss is summarized as follows (in thousands):

[0001437749-20-016667:mdna:34]
|  |  | Three Months Ended June 30, |  |
|  |  | 2020 |  |  | 2019 |  |
| Operating loss: |  |  |  |  |  |  |  |  |
| Grid |  | $ | (1,188 | ) |  | $ | (4,663 | ) |
| Wind |  |  | (1,120 | ) |  |  | (1,324 | ) |
| Unallocated corporate expenses |  |  | (909 | ) |  |  | (249 | ) |
| Total |  | $ | (3,217 | ) |  | $ | (6,236 | ) |

[0001437749-20-016667:mdna:35]
Our Grid segment generated an operating loss of $1.2 million in the three months ended June 30, 2020, compared to $4.7 million in the three months ended June 30, 2019. The decrease in the Grid business unit operating loss in the three months ended June 30, 2020 was primarily due to higher revenues and a more favorable product mix.

[0001437749-20-016667:mdna:36]
Our Wind segment generated an operating loss of $1.1 million in the three months ended June 30, 2020, compared to $1.3 million in the three months ended June 30, 2019. The decrease in the Wind business unit operating loss was due to lower sales and marketing expenses.

[0001437749-20-016667:mdna:37]
Unallocated corporate expenses primarily consisted of stock-based compensation expense of $0.9 million and $0.2 million in the three months ended June 30, 2020 and 2019, respectively.

[0001437749-20-016667:mdna:38]
[same as prior period, unchanged from 0001437749-20-001789:mdna:42]

[0001437749-20-016667:mdna:39]
There were no warrants outstanding in the three months ended June 30, 2020  The change in fair value of warrants resulted in a gain of $2.9 million in the three months ended June 30, 2019. The change in the fair value was primarily driven by changes in stock price, which is a key valuation metric.

[0001437749-20-016667:mdna:40]
[same as prior period, unchanged from 0001437749-20-001789:mdna:46]

[0001437749-20-016667:mdna:41]
Interest income, net, was $0.2 million in the three months ended June 30, 2020, compared to $0.5 million in the three months ended June 30, 2019. The decrease in interest income in the three months ended June 30, 2020 was related to lower cash balances earning lower interest rates than in the prior period.

[0001437749-20-016667:mdna:42]
Other expense, net

[0001437749-20-016667:mdna:43]
Other expense, net, was $0.2 million in the three months ended June 30, 2020, compared to $0.5 million in the three months ended June 30, 2019.  The decrease in other expense, net, was primarily driven by lower foreign currency losses.

[0001437749-20-016667:mdna:44]
[same as prior period, unchanged from 0001437749-20-001789:mdna:50]

[0001437749-20-016667:mdna:45]
Income tax expense in both of the three month periods ended June 30, 2020 and 2019 was $0.2 million. The income tax expense is due primarily to taxes incurred in foreign jurisdictions.

[0001437749-20-016667:mdna:46]
Net loss

[0001437749-20-016667:mdna:47]
Net loss was $3.4 million in the three months ended June 30, 2020, compared to $3.5 million in the three months ended June 30, 2019.  The decrease in net loss was primarily driven by increased gross margin offset by the gain on fair value of warrants in the prior year period that did not recur in the three months ended June 30, 2020.

[0001437749-20-016667:mdna:48]
Non-GAAP Financial Measure - Non-GAAP Net Loss

[0001437749-20-016667:mdna:49]
[same as prior period, unchanged from 0001437749-20-001789:mdna:55]

[0001437749-20-016667:mdna:50]
We define non-GAAP net loss as net loss before stock-based compensation, amortization of acquisition-related intangibles, changes in fair value of warrants, and other non-cash or unusual charges, and the tax effect of those adjustments calculated at the relevant rate for our non-GAAP metric, if applicable.  We believe non-GAAP net loss assists management and investors in comparing our performance across reporting periods on a consistent basis by excluding these non-cash charges and other items that we do not believe are indicative of our core operating performance. In addition, we use non-GAAP net loss as a factor to evaluate the effectiveness of our business strategies. A reconciliation of GAAP to non-GAAP net loss is set forth in the table below (in thousands, except per share data):

[0001437749-20-016667:mdna:51]
|  |  | Three Months Ended June 30, |  |
|  |  | 2020 |  |  | 2019 |  |
| Net loss |  | $ | (3,417 | ) |  | $ | (3,539 | ) |
| Stock-based compensation |  |  | 909 |  |  |  | 249 |  |
| Amortization of acquisition-related intangibles |  |  | 121 |  |  |  | 85 |  |
| Change in fair value of warrants |  |  | — |  |  |  | (2,946 | ) |
| Non-GAAP net loss |  | $ | (2,387 | ) |  | $ | (6,151 | ) |
| Non-GAAP net loss per share - basic and diluted |  | $ | (0.11 | ) |  | $ | (0.30 | ) |
| Weighted average shares outstanding - basic and diluted |  |  | 21,689 |  |  |  | 20,514 |  |

[0001437749-20-016667:mdna:52]
We incurred non-GAAP net losses of $2.4 million or $0.11 per share, for the three months ended June 30, 2020, compared to $6.2 million, or $0.30 per share for the three months ended June 30, 2019. The decrease in non-GAAP net loss was due to improved operating loss driven by higher revenues and a more favorable product mix.

[0001437749-20-016667:mdna:53]
For a description and reconciliation of our other non-GAAP financial measure, non-GAAP operating cash flow, see below under “Non-GAAP Financial Measure – Non-GAAP Operating Cash Flow.”

[0001437749-20-016667:mdna:54]
[same as prior period, unchanged from 0001437749-20-001789:mdna:60]

[0001437749-20-016667:mdna:55]
We have experienced recurring operating losses, and as of June 30, 2020, had an accumulated deficit of $982.1 million.

[0001437749-20-016667:mdna:56]
Our cash requirements depend on numerous factors, including the successful completion of our product development activities, our ability to commercialize our REG and ship protection system solutions, the rate of customer and market adoption of our products, collecting receivables according to established terms, the continued availability of U.S. government funding during the product development phase of our superconductor-based products, whether Inox is successful in executing on SECI orders or in obtaining additional orders under the new central and state auction regime, and whether and the extent to which Inox fulfills its purchase obligations under our supply contract. We continue to closely monitor our expenses and, if required, expect to further reduce our operating and capital spending to enhance liquidity.

[0001437749-20-016667:mdna:57]
As of June 30, 2020, we had cash, cash equivalents, restricted cash, and marketable securities of $62.2 million, compared to $66.1 million as of March 31, 2020, a decrease of $3.9 million. As of June 30, 2020, we had approximately $6.0 million of cash, cash equivalents, and restricted cash in foreign bank accounts. Our cash and cash equivalents, marketable securities and restricted cash are summarized as follows (in thousands):

[0001437749-20-016667:mdna:58]
|  |  | June 30, 2020 |  |  | March 31, 2020 |  |
| Cash and cash equivalents |  | $ | 20,709 |  |  | $ | 24,699 |  |
| Marketable securities |  |  | 35,330 |  |  |  | 35,195 |  |
| Restricted cash |  |  | 6,167 |  |  |  | 6,165 |  |
| Total cash, cash equivalents, marketable securities and restricted cash |  | $ | 62,206 |  |  | $ | 66,059 |  |

[0001437749-20-016667:mdna:59]
For the three months ended June 30, 2020, net cash used in operating activities was $3.1 million, compared to $5.9 million for the three months ended June 30, 2019. The decrease in net cash used in operations was due primarily to collections on accounts receivable, partially offset by higher payments on accounts payable and accrued expenses in the three months ended June 30, 2020 as compared to June 30, 2019.

[0001437749-20-016667:mdna:60]
For the three months ended June 30, 2020, net cash used in investing activities was $0.5 million, compared to cash provided by investing activities of $2.3 million for the three months ended June 30, 2019. The decrease in net cash provided by investing activities was due primarily to the receipt of the second installment payment under the note receivable from the sale of our former Devens facility in the three months ended June 30, 2019 with no such transaction in the current fiscal year.

[0001437749-20-016667:mdna:61]
For the three months ended June 30, 2020, net cash used in financing activities was $0.4 million compared to $0.3 million in the three months ended June 30, 2019.  The increase in net cash used in financing activities was due primarily to the repurchase of common stock in connection with employee tax obligations upon the vesting of stock awards.

[0001437749-20-016667:mdna:62]
As of June 30, 2020, we had $5.7 million of restricted cash included in long-term assets and $0.5 million of restricted cash included in current assets.  These amounts included in restricted cash primarily represent deposits to secure letters of credit for various supply contracts and long-term projects, including the irrevocable letter of credit in the amount of $5.0 million to secure certain of the Company's obligations under the Subcontract Agreement with ComEd. These deposits are held in interest bearing accounts.

[0001437749-20-016667:mdna:63]
We believe we have sufficient available liquidity to fund our operations and capital expenditures for the next twelve months. In addition, we may seek to raise additional capital, which could be in the form of loans, convertible debt or equity, to fund our operating requirements and capital expenditures. We have no outstanding warrants as of June 30, 2020. Our liquidity is highly dependent on our ability to increase revenues, including our ability to collect revenues under our agreements with Inox, control our operating costs, and raise additional capital, if necessary. There can be no assurance that we will be able to raise additional capital on favorable terms or at all, or execute on any other means of improving our liquidity as described above.  Additionally, the impact of the COVID-19 pandemic on the global financial markets may reduce our ability to raise additional capital, if necessary, which could negatively impact our liquidity.

[0001437749-20-016667:mdna:64]
[same as prior period, unchanged from 0001437749-20-001789:mdna:70]

[0001437749-20-016667:mdna:65]
We define non-GAAP operating cash flow as operating cash flow before the Sinovel settlement (net of legal fees and expenses); and other unusual cash flows or items. We believe non-GAAP operating cash flow assists management and investors in comparing our operating cash flow across reporting periods on a consistent basis by excluding these non-recurring cash items that we do not believe are indicative of our core operating cash flow. A reconciliation of GAAP to non-GAAP operating cash flow is set forth in the table below (in thousands).

[0001437749-20-016667:mdna:66]
|  |  | Three months ended |  |
|  |  | June 30, 2020 |  |  | June 30, 2019 |  |
| Operating cash flow |  | $ | (3,115 | ) |  | $ | (5,866 | ) |
| Sinovel settlement (net of legal fees and expenses) |  |  | — |  |  |  | 1,000 |  |
| Non-GAAP operating cash flow |  | $ | (3,115 | ) |  | $ | (4,866 | ) |

[0001437749-20-016667:mdna:67]
Legal Proceedings

[0001437749-20-016667:mdna:68]
We are involved in legal and administrative proceedings and claims of various types. See Part II, Item 1, “Legal Proceedings,” for additional information. We record a liability in our consolidated financial statements for these matters when a loss is known or considered probable and the amount can be reasonably estimated. We review these estimates each accounting period as additional information is known and adjust the loss provision when appropriate. If a matter is both probable to result in liability and the amounts of loss can be reasonably estimated, we estimate and disclose the possible loss or range of loss to the extent necessary to make the consolidated financial statements not misleading. If the loss is not probable or cannot be reasonably estimated, a liability is not recorded in our consolidated financial statements.

[0001437749-20-016667:mdna:69]
[same as prior period, unchanged from 0001437749-20-001789:mdna:75]

[0001437749-20-016667:mdna:70]
[same as prior period, unchanged from 0001437749-20-001789:mdna:76]

[0001437749-20-016667:mdna:71]
[same as prior period, unchanged from 0001437749-20-001789:mdna:77]

[0001437749-20-016667:mdna:72]
In addition, we have various contractual arrangements under which we have committed to purchase minimum quantities of goods or services on an annual basis.

[0001437749-20-016667:mdna:73]
[same as prior period, unchanged from 0001437749-20-001789:mdna:79]

[0001437749-20-016667:mdna:74]
In June 2016, the FASB issued ASU 2016-13, Financial Instruments-Credit Losses (Topic 326): Measurement of Credit Losses on Financial Instruments. The amendments in ASU 2016-13 provide more decision-useful information about the expected credit losses on financial instruments and other commitments to extend credit held by a reporting entity at each reporting date. The ASU is effective for annual reporting periods beginning after December 15, 2019, including interim periods within that year.  Following the release of ASU 2019-10 in November 2019, the new effective date, as long as the Company remains a smaller reporting company, would be annual reporting periods beginning after December 15, 2022.   We are currently evaluating the impact, if any, that the adoption of ASU 2016-13 may have on our consolidated financial statements.

[0001437749-20-016667:mdna:75]
In August 2018, the FASB issued ASU 2018-13, Fair Value Measurement (Topic 820): Changes to the Disclosure Requirements for Fair Value Measurement. The amendments in ASU 2018-13 provide for increased effectiveness of the disclosures made around fair value measurements while including consideration for costs and benefits. The ASU is effective for annual reporting periods beginning after December 15, 2019, including interim periods within those periods.  As of April 1, 2020, we have adopted ASU 2018-13 and noted no material impact on our consolidated financial statements, primarily due to the fact that we do not currently report any Level 3 fair value measurements.

[0001437749-20-016667:mdna:76]
In December 2019, the FASB issued ASU 2019-12, Income Taxes (Topic 740): Simplifying the Accounting for Income Taxes. The amendments in ASU 2019-12 provide for simplified accounting to several income tax situations and removal of certain accounting exceptions. The ASU is effective for annual reporting periods beginning after December 15, 2020, including interim periods within those periods. We do not expect the impact of the adoption of ASU 2019-12 to be material to our consolidated financial statements.

[0001437749-20-016667:mdna:77]
We do not believe that, outside of those disclosed here, there are any other recently issued accounting pronouncements that will have a material impact on our consolidated financial statements.
