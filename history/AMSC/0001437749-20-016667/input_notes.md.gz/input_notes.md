# AMSC notes — 0001437749-20-016667


## amsc:AccountsReceivableTableTextBlock

[0001437749-20-016667:notes:1]
|  |  | June 30, 2020 |  |  | March 31, 2020 |  |
| Accounts receivable (billed) |  | $ | 4,078 |  |  | $ | 11,276 |  |
| Accounts receivable (unbilled) |  |  | 4,125 |  |  |  | 5,711 |  |
| Accounts receivable, net |  | $ | 8,203 |  |  | $ | 16,987 |  |


## amsc:AccountsReceivableTextBlock

[0001437749-20-016667:notes:2]
[same as prior period, unchanged from 0001437749-20-001789:notes:2]

[0001437749-20-016667:notes:3]
[same as prior period, unchanged from 0001437749-20-001789:notes:3]

[0001437749-20-016667:notes:4]
June 30, 2020

[0001437749-20-016667:notes:5]
[same as prior period, unchanged from 0001437749-20-001789:notes:5]

[0001437749-20-016667:notes:6]
March 31, 2020

[0001437749-20-016667:notes:7]
[same as prior period, unchanged from 0001437749-20-001789:notes:7]


## amsc:AssetsAndLiabilitiesLesseeTableTextBlock

[0001437749-20-016667:notes:8]
|  |  | June 30, 2020 |  |  | March 31, 2020 |  |
| Operating Leases: |  |  |  |  |  |  |  |  |
| Right-of-use assets |  | $ | 3,264 |  |  | $ | 3,359 |  |
| Total right-of-use assets |  |  | 3,264 |  |  |  | 3,359 |  |
| Lease liabilities - ST |  | $ | 444 |  |  | $ | 439 |  |
| Lease liabilities - LT |  |  | 2,891 |  |  |  | 3,000 |  |
| Total operating lease liabilities |  |  | 3,335 |  |  |  | 3,439 |  |
| Weighted-average remaining lease term |  |  | 6.7 |  |  |  | 6.9 |  |
| Weighted-average discount rate |  |  | 7.09 | % |  |  | 7.08 | % |


## us-gaap:AccountsPayableAndAccruedLiabilitiesDisclosureTextBlock

[0001437749-20-016667:notes:9]
10.
 Accounts Payable and Accrued Expenses

[0001437749-20-016667:notes:10]
[same as prior period, unchanged from 0001437749-20-001789:notes:55]

[0001437749-20-016667:notes:11]
|  |  | June 30, 2020 |  |  | March 31, 2020 |  |
| Accounts payable |  | $ | 3,539 |  |  | $ | 10,045 |  |
| Accrued inventories in-transit |  |  | 1,201 |  |  |  | 763 |  |
| Accrued other miscellaneous expenses |  |  | 2,342 |  |  |  | 1,986 |  |
| Advanced deposits |  |  | 665 |  |  |  | 666 |  |
| Accrued compensation |  |  | 3,404 |  |  |  | 5,683 |  |
| Income taxes payable |  |  | 946 |  |  |  | 933 |  |
| Accrued product warranty |  |  | 2,168 |  |  |  | 2,015 |  |
| Total |  | $ | 14,265 |  |  | $ | 22,091 |  |

[0001437749-20-016667:notes:12]
The Company generally provides a 
one
 to 
three
 year warranty on its products, commencing upon delivery or installation where applicable. A provision is recorded upon revenue recognition to cost of revenues for estimated warranty expense based on historical experience.

[0001437749-20-016667:notes:13]
[same as prior period, unchanged from 0001437749-20-001789:notes:58]

[0001437749-20-016667:notes:14]
|  |  | Three Months Ended June 30, |  |
|  |  | 2020 |  |  | 2019 |  |
| Balance at beginning of period |  | $ | 2,015 |  |  | $ | 1,545 |  |
| Change in accruals for warranties during the period |  |  | 236 |  |  |  | 85 |  |
| Settlements during the period |  |  | (83 | ) |  |  | (24 | ) |
| Balance at end of period |  | $ | 2,168 |  |  | $ | 1,606 |  |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001437749-20-016667:notes:15]
14.
 Commitments and Contingencies

[0001437749-20-016667:notes:16]
Legal Contingencies

[0001437749-20-016667:notes:17]
From time to time, the Company is involved in legal and administrative proceedings and claims of various types. The Company records a liability in its consolidated financial statements for these matters when a loss is known or considered probable and the amount can be reasonably estimated. The Company reviews these estimates each accounting period as additional information is known and adjusts the loss provision when appropriate. If a matter is both probable to result in a liability and the amounts of loss can be reasonably estimated, the Company estimates and discloses the possible loss or range of loss to the extent necessary to make the consolidated financial statements 
not
 misleading. If the loss is 
not
 probable or cannot be reasonably estimated, a liability is 
not
 recorded in its consolidated financial statements.

[0001437749-20-016667:notes:18]
Other

[0001437749-20-016667:notes:19]
The Company enters into long-term construction contracts with customers that require the Company to obtain performance bonds. The Company is required to deposit an amount equivalent to some or all the face amount of the performance bonds into an escrow account until the termination of the bond. When the performance conditions are met, amounts deposited as collateral for the performance bonds are returned to the Company. In addition, the Company has various contractual arrangements in which minimum quantities of goods or services have been committed to be purchased on an annual basis.

[0001437749-20-016667:notes:20]
As of

[0001437749-20-016667:notes:21]
, the Company had $

[0001437749-20-016667:notes:22]
5.7

[0001437749-20-016667:notes:23]
million of restricted cash included in long-term assets and $

[0001437749-20-016667:notes:24]
0.5

[0001437749-20-016667:notes:25]
million of restricted cash included in current assets, respectively. These amounts included in restricted cash primarily represent deposits to secure letters of credit for various supply contracts and long-term projects, including the irrevocable letter of credit in the amount of 
$5.0
 million to secure certain of the Company's obligations under the Subcontract Agreement with ComEd.  These deposits are held in interest bearing accounts.


## us-gaap:ContractWithCustomerAssetAndLiabilityTableTextBlock

[0001437749-20-016667:notes:26]
|  |  | Unbilled Accounts Receivable |  |  | Deferred Program Costs |  |  | Contract Liabilities |  |
| Beginning balance as of March 31, 2020 |  | $ | 5,711 |  |  | $ | 1,631 |  |  | $ | 26,142 |  |
| Increases for costs incurred to fulfill performance obligations |  |  | — |  |  |  | 1,978 |  |  |  | — |  |
| Increase (decrease) due to customer billings |  |  | (3,620 | ) |  |  | — |  |  |  | 12,276 |  |
| Decrease due to cost recognition on completed performance obligations |  |  | — |  |  |  | (2,815 | ) |  |  | — |  |
| Increase (decrease) due to recognition of revenue based on transfer of control of performance obligations |  |  | 2,033 |  |  |  | — |  |  |  | (16,227 | ) |
| Other changes and FX impact |  |  | 1 |  |  |  | 7 |  |  |  | 194 |  |
| Ending balance as of June 30, 2020 |  | $ | 4,125 |  |  | $ | 801 |  |  | $ | 22,385 |  |

[0001437749-20-016667:notes:27]
|  |  | Unbilled Accounts Receivable |  |  | Deferred Program Costs |  |  | Contract Liabilities |  |
| Beginning balance as of March 31, 2019 |  | $ | 2,213 |  |  | $ | 318 |  |  | $ | 15,521 |  |
| Increases for costs incurred to fulfill performance obligations |  |  | — |  |  |  | 771 |  |  |  | — |  |
| Increase (decrease) due to customer billings |  |  | (1,584 | ) |  |  | — |  |  |  | 10,857 |  |
| Decrease due to cost recognition on completed performance obligations |  |  | — |  |  |  | (4 | ) |  |  | — |  |
| Increase (decrease) due to recognition of revenue based on transfer of control of performance obligations |  |  | 1,467 |  |  |  | — |  |  |  | (7,761 | ) |
| Other changes and FX impact |  |  | (3 | ) |  |  | 3 |  |  |  | 73 |  |
| Ending balance as of June 30, 2019 |  | $ | 2,093 |  |  | $ | 1,088 |  |  | $ | 18,690 |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001437749-20-016667:notes:28]
12.
 Warrants and Derivative Liabilities

[0001437749-20-016667:notes:29]
The Company accounted for its warrants as liabilities due to certain adjustment provisions within the instruments, which required that they be recorded at fair value. The warrants were subject to revaluation at each balance sheet date and any change in fair value was recorded as a change in fair value of warrants until the earlier of its expiration or its exercise at which time the warrant liability was reclassified to equity. The Company calculated the fair value of the warrants utilizing an integrated lattice model. See Note 
6,
 "Fair Value Measurements", for further discussion.

[0001437749-20-016667:notes:30]
[same as prior period, unchanged from 0001437749-20-001789:notes:73]

[0001437749-20-016667:notes:31]
On 
 December 19, 2014, 
the Company entered into a 
second
 amendment to the Loan and Security Agreement with Hercules (the "Hercules Second Amendment"). In conjunction with the Hercules Second Amendment, the Company issued Hercules a warrant to purchase 
58,823
 shares of the Company's common stock (the "Hercules Warrant") which replaced the First Warrant and the Second Warrant.  The Hercules Warrant was exercisable at any time after its issuance at an exercise price of 
$7.85
 per share, subject to certain price-based and other anti-dilution adjustments, including the equity offering in 
 May 2017, 
the acquisition of Infinia Technology Corporation ("ITC") with common stock in 
 September 2017 
and sales of common stock under the ATM entered into in 
 January 2017.  
This warrant had a fair value of 
$0.4
 million as of 
 March 31, 2019.  
On 
 April 8, 2019, 
Hercules notified the Company of its intent to exercise this warrant on a cashless basis.  Hercules received 
22,821
 shares of the Company's common stock on 
 April 17, 2019.  
As a result of this exercise the Company recorded a net gain of 
$0.1
 million to change in fair value of warrants, resulting from the decrease in the fair value of the Hercules Warrant during the

[0001437749-20-016667:notes:32]
three

[0001437749-20-016667:notes:33]
months ended

[0001437749-20-016667:notes:34]
June 30, 2019

[0001437749-20-016667:notes:35]
.

[0001437749-20-016667:notes:36]
[same as prior period, unchanged from 0001437749-20-001789:notes:75]

[0001437749-20-016667:notes:37]
On 
 November 13, 2014, 
the Company completed an offering of 
909,090
 units of the Company's common stock with Hudson Bay Capital. Each unit consisted of 
one
 share of the Company's common stock and 
0.9
 of a warrant to purchase 
one
 share of common stock, or a warrant to purchase in the aggregate 
818,181
 shares (the 
 “November 2014 
Warrant”).  The 
 November 2014 
Warrant was exercisable at any time, at an exercise price equal to 
$7.81
 per share, subject to certain price-based and other anti-dilution adjustments including those noted above.  On 
 November 13, 2019, 
Hudson partially exercised the 
 November 2014 
Warrant for 
786,000
 restricted shares of Company common stock at 
$7.81
 per share
.  
The remaining 
32,181
 warrants expired on 
 November 13, 2019. 
The Company recorded a net gain of 
$2.9
 million to change in fair value of warrants, resulting from the decrease in the fair value of the 
 November 2014 
Warrant during the

[0001437749-20-016667:notes:38]
.  As of

[0001437749-20-016667:notes:39]
, the Company had 
no
 remaining outstanding warrants.


## us-gaap:DisaggregationOfRevenueTableTextBlock

[0001437749-20-016667:notes:40]
|  |  | Three Months Ended June 30, 2020 |  |
| Product Line: |  | Grid |  |  | Wind |  |
| Equipment and systems |  | $ | 16,537 |  |  | $ | 2,618 |  |
| Services and technology development |  |  | 1,178 |  |  |  | 880 |  |
| Total |  | $ | 17,715 |  |  | $ | 3,498 |  |
| Region: |  |  |  |  |  |  |  |  |
| Americas |  | $ | 10,554 |  |  | $ | 12 |  |
| Asia Pacific |  |  | 6,015 |  |  |  | 3,269 |  |
| EMEA |  |  | 1,146 |  |  |  | 217 |  |
| Total |  | $ | 17,715 |  |  | $ | 3,498 |  |

[0001437749-20-016667:notes:41]
|  |  | Three Months Ended June 30, 2019 |  |
| Product Line: |  | Grid |  |  | Wind |  |
| Equipment and systems |  | $ | 8,354 |  |  | $ | 3,505 |  |
| Services and technology development |  |  | 1,501 |  |  |  | 410 |  |
| Total |  | $ | 9,855 |  |  | $ | 3,915 |  |
| Region: |  |  |  |  |  |  |  |  |
| Americas |  | $ | 7,801 |  |  | $ | 46 |  |
| Asia Pacific |  |  | 1,827 |  |  |  | 3,856 |  |
| EMEA |  |  | 227 |  |  |  | 13 |  |
| Total |  | $ | 9,855 |  |  | $ | 3,915 |  |


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001437749-20-016667:notes:42]
[same as prior period, unchanged from 0001437749-20-001789:notes:93]

[0001437749-20-016667:notes:43]
[same as prior period, unchanged from 0001437749-20-001789:notes:94]

[0001437749-20-016667:notes:44]
2019

[0001437749-20-016667:notes:45]
[same as prior period, unchanged from 0001437749-20-001789:notes:95]

[0001437749-20-016667:notes:46]
|  |  | Three Months Ended June 30, |  |
|  |  | 2020 |  |  | 2019 |  |
| Cost of revenues |  | $ | 28 |  |  | $ | 3 |  |
| Research and development |  |  | 130 |  |  |  | 10 |  |
| Selling, general and administrative |  |  | 751 |  |  |  | 236 |  |
| Total |  | $ | 909 |  |  | $ | 249 |  |

[0001437749-20-016667:notes:47]
[same as prior period, unchanged from 0001437749-20-001789:notes:97]

[0001437749-20-016667:notes:48]
27,341

[0001437749-20-016667:notes:49]
[same as prior period, unchanged from 0001437749-20-001789:notes:99]

[0001437749-20-016667:notes:50]
658,667

[0001437749-20-016667:notes:51]
[same as prior period, unchanged from 0001437749-20-001789:notes:101]

[0001437749-20-016667:notes:52]
and issued 
13,174
 shares of immediately vested common stock and

[0001437749-20-016667:notes:53]
160,500

[0001437749-20-016667:notes:54]
[same as prior period, unchanged from 0001437749-20-001789:notes:105]

[0001437749-20-016667:notes:55]
The estimated fair value of the Company's stock-based awards, less expected annual forfeitures, is amortized over the awards' service period. The total unrecognized compensation cost for unvested outstanding stock options was less than $

[0001437749-20-016667:notes:56]
[same as prior period, unchanged from 0001437749-20-001789:notes:107]

[0001437749-20-016667:notes:57]
[same as prior period, unchanged from 0001437749-20-001789:notes:108]

[0001437749-20-016667:notes:58]
[same as prior period, unchanged from 0001437749-20-001789:notes:109]

[0001437749-20-016667:notes:59]
0.9

[0001437749-20-016667:notes:60]
[same as prior period, unchanged from 0001437749-20-001789:notes:111]

[0001437749-20-016667:notes:61]
6.3

[0001437749-20-016667:notes:62]
[same as prior period, unchanged from 0001437749-20-001789:notes:113]

[0001437749-20-016667:notes:63]
2.1

[0001437749-20-016667:notes:64]
[same as prior period, unchanged from 0001437749-20-001789:notes:114]

[0001437749-20-016667:notes:65]
The Company did 
not
 grant any stock options during the 
three
 months ended

[0001437749-20-016667:notes:66]
.  The Company granted

[0001437749-20-016667:notes:67]
[same as prior period, unchanged from 0001437749-20-001789:notes:116]

[0001437749-20-016667:notes:68]
[same as prior period, unchanged from 0001437749-20-001789:notes:117]

[0001437749-20-016667:notes:69]
[same as prior period, unchanged from 0001437749-20-001789:notes:122]

[0001437749-20-016667:notes:70]
[same as prior period, unchanged from 0001437749-20-001789:notes:123]

[0001437749-20-016667:notes:71]
[same as prior period, unchanged from 0001437749-20-001789:notes:124]

[0001437749-20-016667:notes:72]
[same as prior period, unchanged from 0001437749-20-001789:notes:125]

[0001437749-20-016667:notes:73]
|  |  | Three Months Ended June 30, |  |
|  |  | 2020 |  |  | 2019 |  |
| Expected volatility |  |  | N/A |  |  |  | 66.5 | % |
| Risk-free interest rate |  |  | N/A |  |  |  | 1.8 | % |
| Expected life (years) |  |  | N/A |  |  |  | 5.91 |  |
| Dividend yield |  |  | N/A |  |  |  | None |  |


## us-gaap:EarningsPerShareTextBlock

[0001437749-20-016667:notes:74]
[same as prior period, unchanged from 0001437749-20-001789:notes:127]

[0001437749-20-016667:notes:75]
Basic net loss per share (“EPS”) is computed by dividing net loss by the weighted-average number of common shares outstanding for the period. Where applicable, diluted EPS is computed by dividing the net loss by the weighted-average number of common shares and dilutive common equivalent shares outstanding during the period, calculated using the treasury stock method. Common equivalent shares include the effect of restricted stock, exercise of stock options and warrants and contingently issuable shares. Stock options and warrants that are out-of-the-money with exercise prices greater than the average market price of the underlying common shares and shares of performance based restricted stock where the contingency was 
not
 met are excluded from the computation of diluted EPS as the effect of their inclusion would be anti-dilutive.  For the 
three
 months ended

[0001437749-20-016667:notes:76]
[same as prior period, unchanged from 0001437749-20-001789:notes:129]

[0001437749-20-016667:notes:77]
million shares related to outstanding stock options were 
not
 included in the calculation of diluted EPS as they were considered anti-dilutive
.
 For the 
three
 months ended

[0001437749-20-016667:notes:78]
, 
1.0
 million shares were 
not
 included in the calculation of diluted EPS as they were considered anti-dilutive, of which 
0.2
 million relate to outstanding stock options, and 
0.8
 million relate to outstanding warrants.

[0001437749-20-016667:notes:79]
[same as prior period, unchanged from 0001437749-20-001789:notes:134]

[0001437749-20-016667:notes:80]
[same as prior period, unchanged from 0001437749-20-001789:notes:135]

[0001437749-20-016667:notes:81]
|  |  | Three Months Ended June 30, |  |
|  |  | 2020 |  |  | 2019 |  |
| Numerator: |  |  |  |  |  |  |  |  |
| Net loss |  | $ | (3,417 | ) |  | $ | (3,539 | ) |
| Denominator: |  |  |  |  |  |  |  |  |
| Weighted-average shares of common stock outstanding |  |  | 22,827 |  |  |  | 21,499 |  |
| Weighted-average shares subject to repurchase |  |  | (1,138 | ) |  |  | (985 | ) |
| Shares used in per-share calculation ― basic |  |  | 21,689 |  |  |  | 20,514 |  |
| Shares used in per-share calculation ― diluted |  |  | 21,689 |  |  |  | 20,514 |  |
| Net loss per share ― basic |  | $ | (0.16 | ) |  | $ | (0.17 | ) |
| Net loss per share ― diluted |  | $ | (0.16 | ) |  | $ | (0.17 | ) |


## us-gaap:FairValueDisclosuresTextBlock

[0001437749-20-016667:notes:82]
[same as prior period, unchanged from 0001437749-20-001789:notes:138]

[0001437749-20-016667:notes:83]
[same as prior period, unchanged from 0001437749-20-001789:notes:139]

[0001437749-20-016667:notes:84]
| Level 1 | - | Inputs are unadjusted quoted prices in active markets for identical assets or liabilities that the Company has the ability to access at the measurement date. |
| Level 2 | - | Inputs include quoted prices for similar assets and liabilities in active markets, quoted prices for identical or similar assets or liabilities in markets that are not active, inputs other than quoted prices that are observable for the asset or liability, and inputs that are derived principally from or corroborated by observable market data by correlation or other means (market corroborated inputs). |
| Level 3 | - | Unobservable inputs that reflect the Company's assumptions that market participants would use in pricing the asset or liability. The Company develops these inputs based on the best information available, including its own data. |

[0001437749-20-016667:notes:85]
[same as prior period, unchanged from 0001437749-20-001789:notes:141]

[0001437749-20-016667:notes:86]
A financial asset's or liability's classification within the hierarchy is determined based on the lowest level input that is significant to the fair value measurement.

[0001437749-20-016667:notes:87]
[same as prior period, unchanged from 0001437749-20-001789:notes:150]

[0001437749-20-016667:notes:88]
[same as prior period, unchanged from 0001437749-20-001789:notes:151]

[0001437749-20-016667:notes:89]
[same as prior period, unchanged from 0001437749-20-001789:notes:152]

[0001437749-20-016667:notes:90]
[same as prior period, unchanged from 0001437749-20-001789:notes:153]

[0001437749-20-016667:notes:91]
Marketable securities consist of certificates of deposit that are measured using such inputs as quoted prices and are classified within Level 
1
 of the valuation hierarchy. The Company determines the appropriate classification of its marketable securities at the time of purchase and re-evaluates such classification as of each balance sheet date.  All marketable securities are considered available for sale and are carried at fair value.   Changes in fair value are recorded to other income (expense), net.  The Company recognized 
$0.1
 million in unrealized gains on marketable securities, which is recorded in other income (expense), net, for the 
three
 months ended

[0001437749-20-016667:notes:92]
and did 
not
 recognize any gains or losses on marketable securities in the 
three
 months ended

[0001437749-20-016667:notes:93]
.  The Company periodically reviews the realizability of each short and long term marketable security when impairment indicators exist with respect to the security.  If other than temporary impairment of value of the security exists, the carrying value of the security is written down to its estimated fair value.

[0001437749-20-016667:notes:94]
[same as prior period, unchanged from 0001437749-20-001789:notes:155]

[0001437749-20-016667:notes:95]
The Company issued warrants in conjunction with an equity offering to Hudson Bay Capital in 
 November 2014 
and a Loan and Security Agreement with Hercules Technology Growth Capital, Inc. (“Hercules”). The warrants issued to Hercules were exercised on 
 April 8, 2019.  
The warrants issued to Hudson were partially exercised on 
 November 13, 2019 
and the remaining unexercised warrants expired on 
 November 13, 2019.  
As of

[0001437749-20-016667:notes:96]
the Company has 
no
 remaining outstanding warrants.

[0001437749-20-016667:notes:97]
The Company historically relied on various assumptions in a lattice model to determine the fair value of warrants. The Company had valued the warrants within Level 
3
 of the valuation hierarchy. See Note 
12,
 “Warrants and Derivative Liabilities,” for a discussion of the warrants and the valuation assumptions used.

[0001437749-20-016667:notes:98]
[same as prior period, unchanged from 0001437749-20-001789:notes:144]

[0001437749-20-016667:notes:99]
|  |  | Total Carrying Value |  |  | Quoted Prices in Active Markets (Level 1) |  |  | Significant Other Observable Inputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |
| June 30, 2020: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash equivalents |  | $ | 15,502 |  |  | $ | 15,502 |  |  | $ | — |  |  | $ | — |  |
| Marketable securities |  | $ | 35,330 |  |  | $ | 35,330 |  |  | $ | — |  |  | $ | — |  |

[0001437749-20-016667:notes:100]
|  |  | Total Carrying Value |  |  | Quoted Prices in Active Markets (Level 1) |  |  | Significant Other Observable Inputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |
| March 31, 2020: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash equivalents |  | $ | 19,394 |  |  | $ | 19,394 |  |  | $ | — |  |  | $ | — |  |
| Marketable securities |  | $ | 35,195 |  |  | $ | 35,195 |  |  | $ | — |  |  | $ | — |  |


## us-gaap:GoodwillDisclosureTextBlock

[0001437749-20-016667:notes:101]
[same as prior period, unchanged from 0001437749-20-001789:notes:158]

[0001437749-20-016667:notes:102]
The Company did 
not
 identify any triggering events in the

[0001437749-20-016667:notes:103]
[same as prior period, unchanged from 0001437749-20-001789:notes:161]


## us-gaap:IncomeTaxDisclosureTextBlock

[0001437749-20-016667:notes:104]
11.
 Income Taxes

[0001437749-20-016667:notes:105]
The Company recorded income tax expense of $

[0001437749-20-016667:notes:106]
0.2

[0001437749-20-016667:notes:107]
million in each of the 
three
 month periods ended

[0001437749-20-016667:notes:108]
Accounting for income taxes requires a 
two
-step approach to recognizing and measuring uncertain tax positions.  The 
first
 step is to evaluate the tax position for recognition by determining if, based on the technical merits, it is more likely than 
not
 the position will be sustained upon audit, including resolution of related appeals or litigation processes, if any.  The 
second
 step is to measure the tax benefit as the largest amount that is more than 
50%
 likely to be realized upon ultimate settlement.  The Company re-evaluates these uncertain tax positions on a quarterly basis.  The evaluation is based on factors including, but 
not
 limited to, changes in facts or circumstances, changes in tax law, effectively settled issues under audit and new audit activity.  Any changes in these factors could result in the recognition of a tax benefit or an additional charge to the tax provision.  The Company did 
not
 identify any uncertain tax positions in the

[0001437749-20-016667:notes:109]
[same as prior period, unchanged from 0001437749-20-001789:notes:168]


## us-gaap:InventoryDisclosureTextBlock

[0001437749-20-016667:notes:110]
[same as prior period, unchanged from 0001437749-20-001789:notes:169]

[0001437749-20-016667:notes:111]
[same as prior period, unchanged from 0001437749-20-001789:notes:170]

[0001437749-20-016667:notes:112]
|  |  | June 30, 2020 |  |  | March 31, 2020 |  |
| Raw materials |  | $ | 8,158 |  |  | $ | 10,739 |  |
| Work-in-process |  |  | 1,677 |  |  |  | 1,345 |  |
| Finished goods |  |  | 6,425 |  |  |  | 5,260 |  |
| Deferred program costs |  |  | 801 |  |  |  | 1,631 |  |
| Net inventory |  | $ | 17,061 |  |  | $ | 18,975 |  |

[0001437749-20-016667:notes:113]
[same as prior period, unchanged from 0001437749-20-001789:notes:172]

[0001437749-20-016667:notes:114]
0.8

[0001437749-20-016667:notes:115]
million and 
$0.1
 million for the 
three
 months ended

[0001437749-20-016667:notes:116]
, respectively.  These write-downs were based on the Company's evaluation of its inventory on hand for excess quantities and obsolescence.

[0001437749-20-016667:notes:117]
[same as prior period, unchanged from 0001437749-20-001789:notes:179]

[0001437749-20-016667:notes:118]
[same as prior period, unchanged from 0001437749-20-001789:notes:180]


## us-gaap:LeaseCostTableTextBlock

[0001437749-20-016667:notes:119]
|  |  | Three Months Ended |  |  | Three Months Ended |  |
|  |  | June 30, 2020 |  |  | June 30, 2019 |  |
| Operating Leases: |  |  |  |  |  |  |  |  |
| Operating lease costs - fixed |  | $ | 178 |  |  | $ | 178 |  |
| Operating lease costs - variable |  |  | 27 |  |  |  | 21 |  |
| Short-term lease costs |  |  | 168 |  |  |  | 233 |  |
| Total lease costs |  |  | 373 |  |  |  | 432 |  |


## us-gaap:LesseeOperatingLeaseLiabilityMaturityTableTextBlock

[0001437749-20-016667:notes:120]
|  |  | Operating Leases |  |
| Year ended March 31, |  |  |  |  |
| 2020 |  | $ | 501 |  |
| 2021 |  |  | 646 |  |
| 2022 |  |  | 620 |  |
| 2023 |  |  | 558 |  |
| 2024 |  |  | 501 |  |
| Thereafter |  |  | 1,396 |  |
| Total minimum lease payments |  |  | 4,222 |  |
| Less: interest |  |  | (887 | ) |
| Present value of lease liabilities |  |  | 3,335 |  |


## us-gaap:LesseeOperatingLeasesTextBlock

[0001437749-20-016667:notes:121]
13.
 Leases

[0001437749-20-016667:notes:122]
[same as prior period, unchanged from 0001437749-20-001789:notes:184]

[0001437749-20-016667:notes:123]
[same as prior period, unchanged from 0001437749-20-001789:notes:185]

[0001437749-20-016667:notes:124]
All significant lease arrangements are recognized at lease commencement.  Operating lease right–of-use assets and lease liabilities are recognized at commencement. The operating lease right-of-use asset includes any lease payments related to initial direct cost and prepayments and excludes any lease incentives. Lease expense is recognized on a straight-line basis over the lease term.  The Company enters into a variety of operating lease agreements through the normal course of its business, but primarily real estate leases to support its operations. The real estate lease agreements generally provide for fixed minimum rental payments and the payment of real estate taxes and insurance. Many of these real estate leases have 
one
 or more renewal options that allow the Company, at its discretion, to renew the lease for varying periods up to 
five
 years or to terminate the lease. Only renewal options or termination rights that the Company believed were likely to be exercised were included in the lease calculations.

[0001437749-20-016667:notes:125]
The Company also enters into leases for vehicles, IT equipment and service agreements, and other leases related to its manufacturing operations that are also included in the right-of-use assets and lease liability accounts if they are for a term of longer than 
twelve
 months. However, many of these leases are either short-term in nature or immaterial. The Company has made the policy election to exclude short term leases from the balance sheet.

[0001437749-20-016667:notes:126]
[same as prior period, unchanged from 0001437749-20-001789:notes:191]

[0001437749-20-016667:notes:127]
[same as prior period, unchanged from 0001437749-20-001789:notes:192]

[0001437749-20-016667:notes:128]
[same as prior period, unchanged from 0001437749-20-001789:notes:193]

[0001437749-20-016667:notes:129]
[same as prior period, unchanged from 0001437749-20-001789:notes:194]

[0001437749-20-016667:notes:130]
The Company's estimated minimum future lease obligations under the Company's leases are as follows:


## us-gaap:NewAccountingPronouncementsAndChangesInAccountingPrinciplesTextBlock

[0001437749-20-016667:notes:131]
16.
 Recent Accounting Pronouncements

[0001437749-20-016667:notes:132]
In 
 June 2016, 
the FASB issued ASU 
2016
-
13,

[0001437749-20-016667:notes:133]
Financial Instruments-Credit Losses (Topic 
326
): Measurement of Credit Losses on Financial Instruments
. The amendments in ASU 
2016
-
13
 will provide more decision-useful information about the expected credit losses on financial instruments and other commitments to extend credit held by a reporting entity at each reporting date. The ASU is effective for annual reporting periods beginning after 
 December 15, 2019, 
including interim periods within that year.  Following the release of ASU 
2019
-
10
 in 
 November 2019, 
the new effective date, as long as the Company remains a smaller reporting company, would be annual reporting periods beginning after 
 December 15, 2022.  
The Company is currently evaluating the impact, if any, that the adoption of ASU 
2016
-
13

[0001437749-20-016667:notes:134]
may 
have on its consolidated financial statements.

[0001437749-20-016667:notes:135]
In 
 August 2018, 
the FASB issued ASU 
2018
-
13,

[0001437749-20-016667:notes:136]
Fair Value Measurement (Topic 
820
): Changes to the Disclosure Requirements for Fair Value Measurement
. The amendments in ASU 
2018
-
13
 provide for increased effectiveness of the disclosures made around fair value measurements while including consideration for costs and benefits. The ASU is effective for annual reporting periods beginning after 
 December 15, 2019, 
including interim periods within those periods. As of 
 April 1, 2020, 
the Company has adopted ASU 
2018
-
13
 and noted 
no
 material impact on its consolidated financial statements, primarily due to the fact that the Company does 
not
 currently report any Level 
3
 fair value measurements.

[0001437749-20-016667:notes:137]
In 
 December 2019, 
the FASB issued ASU 
2019
-
12,

[0001437749-20-016667:notes:138]
Income Taxes (Topic 
740
): Simplifying the Accounting for Income Taxes
. The amendments in ASU 
2019
-
12
 provide for simplified accounting to several income tax situations and removal of certain accounting exceptions. The ASU is effective for annual reporting periods beginning after 
 December 15, 2020, 
including interim periods within those periods. The Company does 
not
 expect the impact of the adoption of ASU 
2019
-
12
 to be material to its consolidated financial statements.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0001437749-20-016667:notes:139]
[same as prior period, unchanged from 0001437749-20-001789:notes:218]

[0001437749-20-016667:notes:140]
Nature of the Business and Operations

[0001437749-20-016667:notes:141]
American Superconductor Corporation (together with its subsidiaries, “AMSC®” or the “Company”) was founded on 
 April

[0001437749-20-016667:notes:142]
9,

[0001437749-20-016667:notes:143]
1987.
 The Company is a leading system provider of megawatt-scale power resiliency solutions that orchestrate the rhythm and harmony of power on the grid
™
, and that protect and expand the capability of the Navy's fleet. The Company's system level products leverage its proprietary “smart materials” and “smart software and controls” to provide enhanced resiliency and improved performance of megawatt-scale power flow.

[0001437749-20-016667:notes:144]
These unaudited condensed consolidated financial statements of the Company have been prepared on a going concern basis in accordance with United States generally accepted accounting principles (“GAAP”) and the Securities and Exchange Commission's (“SEC”) instructions to Form 
10
-Q. The going concern basis of presentation assumes that the Company will continue operations and will be able to realize its assets and discharge its liabilities and commitments in the normal course of business. Certain information and footnote disclosures normally included in the financial statements prepared in accordance with GAAP have been condensed or omitted pursuant to those instructions. The year-end condensed balance sheet data was derived from audited financial statements but does 
not
 include all disclosures required by GAAP. The unaudited condensed consolidated financial statements, in the opinion of management, reflect all adjustments (consisting of normal recurring adjustments) necessary for a fair statement of the results for the interim periods ended

[0001437749-20-016667:notes:145]
and the financial position at

[0001437749-20-016667:notes:146]
; however, these results are 
not
 necessarily indicative of results which 
 may 
be expected for the full year. The interim condensed consolidated financial statements, and notes thereto, should be read in conjunction with the audited consolidated financial statements for the year ended

[0001437749-20-016667:notes:147]
, and notes thereto, included in the Company's Annual Report on Form 
10
-K for the year ended

[0001437749-20-016667:notes:148]
filed with the SEC on 
 June 2, 2020.

[0001437749-20-016667:notes:149]
Liquidity

[0001437749-20-016667:notes:150]
The Company has historically experienced recurring operating losses and as of

[0001437749-20-016667:notes:151]
, the Company had an accumulated deficit of $

[0001437749-20-016667:notes:152]
982.1

[0001437749-20-016667:notes:153]
million. In addition, the Company has historically experienced recurring negative operating cash flows.  At

[0001437749-20-016667:notes:154]
, the Company had cash, cash equivalents, and marketable securities of $

[0001437749-20-016667:notes:155]
56.0

[0001437749-20-016667:notes:156]
million. Marketable securities include certificate of deposits with maturities between 
eight
 and 
twenty-one
 months.  Cash used in operations for the

[0001437749-20-016667:notes:157]
was $

[0001437749-20-016667:notes:158]
3.1

[0001437749-20-016667:notes:159]
million.

[0001437749-20-016667:notes:160]
In 
 December 2015, 
the Company entered into a set of strategic agreements valued at approximately 
$210.0
 million with Inox Wind Ltd. (“Inox” or “Inox Wind”), which includes a multi-year supply contract pursuant to which the Company will supply electrical control systems ("ECS") to Inox and a license agreement allowing Inox to manufacture a limited number of ECS. After Inox purchases the specified number of ECS required under the terms of the supply contract, Inox agreed that the Company will continue as Inox's preferred supplier and Inox will be required to purchase from the Company a majority of its ECS requirements for an additional 
three
-year period. Pursuant to these strategic agreements, Inox must forecast future purchase orders of sets of ECS which become firm orders 
three
 months prior to shipment, and Inox must post letters of credit before the Company will ship such orders. Inox is currently delinquent on its obligation to post letters of credit for sets of ECS that Inox forecasted to purchase under the terms of the supply contract.  On 
 May 29, 2020, 
the Company sent written notice to Inox notifying Inox of its default under the supply contract due to Inox's failure to post letters of credit in the amount of 
€6.0
 million for the payment of ECS that Inox is obligated to purchase under the terms of the supply contract.  If Inox fails to post letters of credit in the amount of 
€6.0
 million in accordance with the terms of the supply contract within the 
ninety
 day cure period after receipt of the default notice, then the Company 
 may 
terminate the supply contract by providing written notice of such termination to Inox.  We cannot predict if and when Inox will post letters of credit consistent with the forecasted ECS quantities. Inox's failure to post letters of credit and take delivery of forecasted ECS quantities would impact the Company's revenues and liquidity.  In the event the Company were to terminate the supply contract, the Company's revenues and liquidity would also be impacted.

[0001437749-20-016667:notes:161]
In 
 March 2020, 
the World Health Organization declared the disease caused by the novel coronavirus, COVID-
19,
 to be a pandemic. COVID-
19
 has spread throughout the globe, including in the Commonwealth of Massachusetts where the Company's headquarters are located, and in other areas where the Company has business operations. In response to the outbreak, the Company has followed the guidelines of the U.S. Centers for Disease Control and Prevention and applicable state government authorities to protect the health and safety of the Company's employees, families, suppliers, customers and communities. While these existing measures and, COVID-
19
 generally, have 
not
 materially disrupted the Company's business to date, any future actions necessitated by the COVID-
19
 pandemic 
 may 
result in disruption to the Company's business.

[0001437749-20-016667:notes:162]
While the COVID-
19
 pandemic continues to rapidly evolve, the Company continues to assess the impact of the COVID-
19
 pandemic to best mitigate risk and continue the operations of the Company's business. The extent to which the outbreak impacts the Company's business, liquidity, results of operations and financial condition will depend on future developments, which are highly uncertain and cannot be predicted with confidence, including new information that 
 may 
emerge concerning the severity of the COVID-
19
 pandemic and the actions to contain it or treat its impact, among others.  If the Company, its customers or suppliers experience prolonged shutdowns or other business disruptions, the Company's business, liquidity, results of operations and financial condition are likely to be materially adversely affected, and the Company's ability to access the capital markets 
 may 
be limited.

[0001437749-20-016667:notes:163]
The Company believes that based on the information presented above and its quarterly management assessment, it has sufficient liquidity to fund its operations and capital expenditures for the next 
twelve
 months following the issuance of the financial statements for the

[0001437749-20-016667:notes:164]
. The Company's liquidity is highly dependent on its ability to increase revenues, including its ability to collect revenues under its agreements with Inox, its ability to control its operating costs, and its ability to raise additional capital, if necessary.  The impact of the COVID-
19
 pandemic on the global financing markets 
 may 
reduce the Company's ability to raise additional capital, if necessary, which could negatively impact the Company's liquidity.  There can be 
no
 assurance that the Company will be able to continue to raise additional capital, on favorable terms or at all, from other sources or execute on any other means of improving liquidity described above.


## us-gaap:PropertyPlantAndEquipmentDisclosureTextBlock

[0001437749-20-016667:notes:165]
9.
 Property, Plant and Equipment

[0001437749-20-016667:notes:166]
[same as prior period, unchanged from 0001437749-20-001789:notes:220]

[0001437749-20-016667:notes:167]
[same as prior period, unchanged from 0001437749-20-001789:notes:221]

[0001437749-20-016667:notes:168]
|  |  | June 30, 2020 |  |  | March 31, 2020 |  |
| Construction in progress - equipment |  | $ | 3,739 |  |  | $ | 3,130 |  |
| Equipment and software |  |  | 41,798 |  |  |  | 41,737 |  |
| Furniture and fixtures |  |  | 1,317 |  |  |  | 1,302 |  |
| Leasehold improvements |  |  | 2,480 |  |  |  | 2,477 |  |
| Property, plant and equipment, gross |  |  | 49,334 |  |  |  | 48,646 |  |
| Less accumulated depreciation |  |  | (41,003 | ) |  |  | (40,081 | ) |
| Property, plant and equipment, net |  | $ | 8,331 |  |  | $ | 8,565 |  |

[0001437749-20-016667:notes:169]
[same as prior period, unchanged from 0001437749-20-001789:notes:223]

[0001437749-20-016667:notes:170]
million and 
$1.1
 million for the 
three
 months ended

[0001437749-20-016667:notes:171]
, respectively. Construction in progress - equipment primarily includes capital investments in the Company's HTS equipment and leasehold improvements in the Company's leased facility in Ayer, Massachusetts.


## us-gaap:ReconciliationOfAssetsFromSegmentToConsolidatedTextBlock

[0001437749-20-016667:notes:172]
|  |  | June 30, 2020 |  |  | March 31, 2020 |  |
| Grid |  | $ | 34,651 |  |  | $ | 44,044 |  |
| Wind |  |  | 11,293 |  |  |  | 14,250 |  |
| Corporate assets |  |  | 63,726 |  |  |  | 65,815 |  |
| Total |  | $ | 109,670 |  |  | $ | 124,109 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001437749-20-016667:notes:173]
[same as prior period, unchanged from 0001437749-20-001789:notes:242]

[0001437749-20-016667:notes:174]
The Company's revenues in its Grid segment are derived primarily through enabling the transmission and distribution of power, providing planning services that allow it to identify power grid needs and risks, and developing ship protection systems for the U.S. Navy. The Company's revenues in its Wind segment are derived primarily through supplying advanced power electronics and control systems, licensing its highly engineered wind turbine designs, and providing extensive customer support services to wind turbine manufacturers. The Company records revenue based on a 
five
-step model in accordance with Accounting Standards Codification ("ASC") 
606,

[0001437749-20-016667:notes:175]
Revenue from Contracts with Customers
. For its customer contracts, the Company identifies the performance obligations, determines the transaction price, allocates the contract transaction price to the performance obligations, and recognizes the revenue when (or as) control of goods or services is transferred to the customer. In the

[0001437749-20-016667:notes:176]
80

[0001437749-20-016667:notes:177]
[same as prior period, unchanged from 0001437749-20-001789:notes:248]

[0001437749-20-016667:notes:178]
78

[0001437749-20-016667:notes:179]
[same as prior period, unchanged from 0001437749-20-001789:notes:250]

[0001437749-20-016667:notes:180]
In the Company's equipment and system product line, each contract with a customer summarizes each product sold to a customer, which typically represents distinct performance obligations. A contract's transaction price is allocated to each distinct performance obligation using the respective standalone selling price which is determined primarily using the cost-plus expected margin approach and recognized as revenue when, or as, the performance obligation is satisfied. The majority of the Company's product sales transfer control to the customer in line with the contracted delivery terms and revenue is recorded at the point in time when title and risk transfer to the customer, as the Company has determined that this is the point in time that control transfers to the customer.

[0001437749-20-016667:notes:181]
The Company's equipment and system product line includes certain contracts which do 
not
 meet the requirements of an exchange transaction and therefore do 
not
 fall within the scope of ASC 
606.
  As these non-exchange transaction contracts are considered grant revenue and do 
not
 fall within any specific accounting literature, the Company follows guidance within ASC 
606
 by analogy to recognize grant revenue over time.  In each of the

[0001437749-20-016667:notes:182]
three
 months ended 
 June 30, 2020

[0001437749-20-016667:notes:183]
the Company recorded $

[0001437749-20-016667:notes:184]
0.4

[0001437749-20-016667:notes:185]
million in grant revenue, which is included in the Company's Grid segment revenue.

[0001437749-20-016667:notes:186]
[same as prior period, unchanged from 0001437749-20-001789:notes:259]

[0001437749-20-016667:notes:187]
[same as prior period, unchanged from 0001437749-20-001789:notes:260]

[0001437749-20-016667:notes:188]
The Company's policy is 
not
 to accept volume discounts, product returns, or rebates and allowances within its contracts. In the event a contract was approved with any of these terms, it would be evaluated for variable consideration, estimated and recorded as a reduction of revenue in the same period the related product revenue was recorded.

[0001437749-20-016667:notes:189]
The Company provides assurance-type warranties on all product sales for a term of typically 
one
 to 
three
 years, and extended service-type warranties at the customer's option for an additional term ranging up to 
four
 additional years. The Company accrues for the estimated warranty costs for assurance warranties at the time of sale based on historical warranty experience plus any known or expected changes in warranty exposure. For all extended service-type warranties, the Company recognizes the revenue ratably over time during the effective period of the services.

[0001437749-20-016667:notes:190]
[same as prior period, unchanged from 0001437749-20-001789:notes:263]

[0001437749-20-016667:notes:191]
The Company's contracts with customers do 
not
 typically include extended payment terms and 
 may 
include milestone billing over the life of the contract. Payment terms vary by contract type and type of customer and generally range from 
30
 to 
60
 days from delivery.

[0001437749-20-016667:notes:192]
The following tables disaggregate the Company's revenue by product line and by shipment destination:

[0001437749-20-016667:notes:193]
, and 
 June 30,

[0001437749-20-016667:notes:194]
, the Company's contract assets and liabilities primarily relate to the timing differences between cash received from a customer in connection with contractual rights to invoicing and the timing of revenue recognition following completion of performance obligations. The Company's accounts receivable balance is made up entirely of customer contract related balances. Changes in the Company's contract assets, which are included in “Accounts receivable (unbilled)” and “Deferred program costs” (see Note 
7,
 “Accounts Receivable” and Note 
8,
 “Inventory” for a reconciliation to the condensed consolidated balance sheets) and contract liabilities, which are included in the current portion and long term portion of "Deferred revenue" in the Company's condensed consolidated balance sheets, are as follows:

[0001437749-20-016667:notes:195]
The Company's remaining performance obligations represent the unrecognized revenue value of the Company's contractual commitments. The Company's performance obligations 
 may 
vary significantly each reporting period based on the timing of major new contractual commitments. As of

[0001437749-20-016667:notes:196]
[same as prior period, unchanged from 0001437749-20-001789:notes:269]

[0001437749-20-016667:notes:197]
53.7

[0001437749-20-016667:notes:198]
[same as prior period, unchanged from 0001437749-20-001789:notes:271]

[0001437749-20-016667:notes:199]
14.5

[0001437749-20-016667:notes:200]
[same as prior period, unchanged from 0001437749-20-001789:notes:273]

[0001437749-20-016667:notes:201]
three
 months of a 
twelve
-month rolling forecast. The timing of the performance obligations beyond the 
twelve
-month forecast provided by Inox are 
not
 determinable and therefore are 
not
 included in the total remaining performance obligations.  See Note 
1,
 “Nature of the Business and Operations and Liquidity,” for further information regarding the uncertainty of timing of the performance obligations as a result of the written notice that the Company sent to Inox on 
 May 29, 2020 
notifying Inox of its default under the supply contract.

[0001437749-20-016667:notes:202]
The following table sets forth customers who represented 
10%
 or more of the Company's total revenues for the

[0001437749-20-016667:notes:203]
[same as prior period, unchanged from 0001437749-20-001789:notes:276]

[0001437749-20-016667:notes:204]
|  |  |  | Three Months Ended |  |
|  | Reportable |  | June 30, |  |
|  | Segment |  | 2020 |  |  | 2019 |  |
| Inox Wind Limited | Wind |  | <10% |  |  | 27% |  |
| Micron Technology | Grid |  | 0% |  |  | 25% |  |
| Siemens Gamesa Renewable Energy | Grid |  | 25% |  |  | 0% |  |
| EPC Services Company | Grid |  | 24% |  |  | 0% |  |


## us-gaap:ScheduleOfSegmentReportingInformationBySegmentTextBlock

[0001437749-20-016667:notes:205]
|  |  | Three Months Ended June 30, |  |
|  |  | 2020 |  |  | 2019 |  |
| Revenues: |  |  |  |  |  |  |  |  |
| Grid |  | $ | 17,715 |  |  | $ | 9,855 |  |
| Wind |  |  | 3,498 |  |  |  | 3,915 |  |
| Total |  | $ | 21,213 |  |  | $ | 13,770 |  |

[0001437749-20-016667:notes:206]
|  |  | Three Months Ended June 30, |  |
|  |  | 2020 |  |  | 2019 |  |
| Operating loss: |  |  |  |  |  |  |  |  |
| Grid |  | $ | (1,188 | ) |  | $ | (4,663 | ) |
| Wind |  |  | (1,120 | ) |  |  | (1,324 | ) |
| Unallocated corporate expenses |  |  | (909 | ) |  |  | (249 | ) |
| Total |  | $ | (3,217 | ) |  | $ | (6,236 | ) |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001437749-20-016667:notes:207]
15.
 Business Segments

[0001437749-20-016667:notes:208]
[same as prior period, unchanged from 0001437749-20-001789:notes:281]

[0001437749-20-016667:notes:209]
Through the Company's power grid offerings, the Grid business segment enables electric utilities, industrial facilities, and renewable energy project developers to connect, transmit and distribute power with exceptional efficiency, reliability, security and affordability through its transmission planning services, power electronics, and superconductor-based systems. The sales process is enabled by transmission planning services that allow it to identify power grid congestion, poor power quality and other risks, which helps the Company determine how its solutions can improve network performance. These services often lead to sales of grid interconnection solutions for wind farms and solar power plants, power quality systems, and transmission and distribution cable systems.  The Company also sells ship protection products to the U.S. Navy through its Grid business segment.

[0001437749-20-016667:notes:210]
Through the Company's wind power offerings, the Wind business segment enables manufacturers to field wind turbines with exceptional power output, reliability and affordability.  The Company provides advanced power electronics and control system products, engineered designs, and support services. The Company supplies advanced power electronics and control systems, licenses its highly engineered wind turbine designs, and provides extensive customer support services to wind turbine manufacturers. The Company's design portfolio includes a broad range of drive trains and power ratings of 
2
 megawatts ("MWs") and higher. The Company provides a broad range of power electronics and software-based control systems that are highly integrated and designed for optimized performance, efficiency, and grid compatibility.

[0001437749-20-016667:notes:211]
[same as prior period, unchanged from 0001437749-20-001789:notes:284]

[0001437749-20-016667:notes:212]
The accounting policies of the business segments are the same as those for the consolidated Company. The Company's business segments have been determined in accordance with the Company's internal management structure, which is organized based on operating activities. The Company evaluates performance based upon several factors, of which the primary financial measures are segment revenues and segment operating loss. The disaggregated financial results of the segments reflect allocation of certain functional expense categories consistent with the basis and manner in which Company management internally disaggregates financial information for the purpose of assisting in making internal operating decisions. In addition, certain corporate expenses which the Company does 
not
 believe are specifically attributable or allocable to either of the 
two
 business segments have been excluded from the segment operating loss.

[0001437749-20-016667:notes:213]
[same as prior period, unchanged from 0001437749-20-001789:notes:286]

[0001437749-20-016667:notes:214]
[same as prior period, unchanged from 0001437749-20-001789:notes:287]

[0001437749-20-016667:notes:215]
$0.2

[0001437749-20-016667:notes:216]
[same as prior period, unchanged from 0001437749-20-001789:notes:289]

[0001437749-20-016667:notes:217]
, respectively.

[0001437749-20-016667:notes:218]
[same as prior period, unchanged from 0001437749-20-001789:notes:295]


## us-gaap:SubsequentEventsTextBlock

[0001437749-20-016667:notes:219]
17.
 Subsequent Events

[0001437749-20-016667:notes:220]
The Company has performed an evaluation of subsequent events through the time of filing this Quarterly Report on Form 
10
-Q with the SEC and has determined that other than the following information, there are 
no
 such events to report.  In 
 July 2020, 
the Company undertook restructuring activities, approved by the Board of Directors, in order to reorganize its global manufacturing operations and reduce its workforce to better reflect the current demand for its wind products.  Over the remainder of fiscal 
2020
 the Company intends to consolidate Wind manufacturing activities into its Massachusetts facilities and as a result reduced the headcount at its operation in Romania.   The cost
s
 associated with this restructuring event are 
not
 expected to be material to the consolidated financial statements.
