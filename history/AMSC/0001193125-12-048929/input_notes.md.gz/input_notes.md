# AMSC notes — 0001193125-12-048929


## amsc:BusinessCombinationsPolicyPolicyTextBlock

[0001193125-12-048929:notes:1]
In December 2010, the FASB issued Accounting Standards Update (ASU) No. 2010-29, Business Combinations (Topic 805), Disclosure of Supplementary Pro forma Information for Business Combinations a consensus of the FASB Emerging Issues Task Force (ASC 2010-29). This amendment clarifies the periods for which pro forma financial information is presented. The disclosures include pro forma revenue and earnings of the combined entity for the current reporting period as though the acquisition date for all business combinations that occurred during the year had been as of the beginning of the annual reporting period. If comparative financial statements are presented, the pro forma revenue and earnings of the combined entity for the comparable prior reporting period should be reported as though the acquisition date for all business combinations that occurred during the current year had been as of the beginning of the comparable prior annual reporting period. ASU 2010-29 is effective prospectively for business combinations that occur on or after the beginning of the first annual reporting period beginning after December 15, 2010. The adoption of ASU 2010-29 did not have a material impact on the Company's consolidated results of operations, financial condition, or cash flows.


## amsc:ComprehensiveIncomePolicyPolicyTextBlock

[0001193125-12-048929:notes:2]
In June 2011, the FASB issued Accounting Standards Update (ASU) No. 2011-05, Comprehensive Income (Topic 220): Presentation of Comprehensive Income. ASU 2011-05 requires entities to present net income and other comprehensive income in either a single continuous statement or in two separate, but consecutive, statements of net income and other comprehensive income. ASU 2011-05 is effective for fiscal years and interim periods beginning after December 15, 2011. The Company does not expect the adoption of ASU 2011-05 to have a material impact on the Company's consolidated results of operations, financial condition, or cash flows.


## amsc:RecentAccountingPronouncementsTextBlock

[0001193125-12-048929:notes:3]
[same as prior period, unchanged from 0000950123-11-096966:notes:4]


## amsc:ScheduleOfAccountsReceivableTextBlock

[0001193125-12-048929:notes:4]
|  |  | December 31, |  |  | March 31, |  |
|  |  | 2011 |  |  | 2011 |  |
| Accounts receivable (billed) | $ | 11,708 |  | $ | 10,938 |  |
| Accounts receivable (unbilled) |  | 3,308 |  |  | 5,004 |  |
| Less: Allowance for doubtful accounts |  | (252 | ) |  | (683 | ) |
| Accounts receivable, net | $ | 14,764 |  | $ | 15,259 |  |


## amsc:ScheduleOfBusinessSegmentAssetsTextBlock

[0001193125-12-048929:notes:5]
|  |  | December 31, |  | March 31, |
|  |  | 2011 |  | 2011 |
| Wind | $ | 89,370 | $ | 145,464 |
| Grid |  | 70,285 |  | 67,081 |
| Corporate assets |  | 115,708 |  | 228,664 |
| Total | $ | 275,363 | $ | 441,209 |


## amsc:ScheduleOfBusinessSegmentOperatingResultsTextBlock

[0001193125-12-048929:notes:6]
|  |  | Three months ended |  |  |  |  |  | Nine months ended |  |  |
|  |  | December 31, |  |  |  |  |  | December 31, |  |  |
|  |  | 2011 | 2010 |  |  | 2011 |  |  |  | 2010 |
| Revenues: |  |  |  |  |  |  |  |  |  |  |
| Wind | $ | 10,125 |  | $ | 10,840 |  | $ | 27,836 | $ | 183,162 |
| Grid |  | 7,933 |  |  | 20,730 |  |  | 20,080 |  | 43,691 |
| Total | $ | 18,058 |  | $ | 31,570 |  | $ | 47,916 | $ | 226,853 |

[0001193125-12-048929:notes:7]
|  |  |  |  |  |  |  |  | Nine months ended |  |  |  |  |
|  |  | Three months ended |  |  |  |  |  | December 31, |  |  |  |  |
|  |  | December 31, |  |  |  |  |  |  |  |  |  |  |
|  |  | 2011 |  |  | 2010 |  |  | 2011 |  |  | 2010 |  |
| Operating (loss) income: |  |  |  |  |  |  |  |  |  |  |  |  |
| Wind | ($ | 14,014 | ) | ($ | 12,494 | ) | ($ | 54,719 | ) | $ | 51,499 |  |
| Grid |  | (6,313 | ) |  | (8,189 | ) |  | (24,511 | ) |  | (35,166 | ) |
| Unallocated corporate |  | (6,242 | ) |  | (2,277 | ) |  | (36,790 | ) |  | (10,135 | ) |
| expenses |  |  |  |  |  |  |  |  |  |  |  |  |
| Total | ($ | 26,569 | ) | ($ | 22,960 | ) | ($ | 116,020 | ) | $ | 6,198 |  |


## amsc:ScheduleOfEarningsPerShareBasicAndDilutedTextBlock

[0001193125-12-048929:notes:8]
|  |  | Three months ended |  |  | Nine months ended |  |
|  |  | December 31, |  |  | December 31, |  |
|  |  | 2011 |  |  | 2010 |  |  | 2011 |  |  | 2010 |  |
| Numerator: |  |  |  |  |  |  |  |  |  |  |  |  |
| Net loss | $ | (26,271 | ) | $ | (18,158 | ) | $ | (115,660 | ) | $ | (1,150 | ) |
| Denominator: |  |  |  |  |  |  |  |  |  |  |  |  |
| Weighted-average shares of common stock outstanding |  | 51,459 |  |  | 48,731 |  |  | 51,120 |  |  | 46,667 |  |
| Weighted-average shares subject to repurchase |  | (526 | ) |  | (663 | ) |  | (331 | ) |  | (650 | ) |
| Shares used in per-share calculation basic |  | 50,933 |  |  | 48,068 |  |  | 50,789 |  |  | 46,017 |  |
| Shares used in per-share calculation diluted |  | 50,933 |  |  | 48,068 |  |  | 50,789 |  |  | 46,017 |  |
| Net loss per share basic | $ | (0.52 | ) | $ | (0.38 | ) | $ | (2.28 | ) | $ | (0.02 | ) |
| Net loss per share diluted | $ | (0.52 | ) | $ | (0.38 | ) | $ | (2.28 | ) | $ | (0.02 | ) |


## amsc:ScheduleOfStockBasedCompensationExpensesIncludedInConsolidatedStatementOfIncomeTextBlock

[0001193125-12-048929:notes:9]
|  |  | Three months ended |  |  | Nine months ended |
|  |  | December 31, |  |  | December 31, |
|  |  | 2011 |  | 2010 |  |  | 2011 |  | 2010 |
| Cost of revenues | $ | 138 | $ | (6 | ) | $ | 908 | $ | 828 |
| Research and development |  | 623 |  | 237 |  |  | 1,948 |  | 1,396 |
| Selling, general and administrative |  | 1,357 |  | 2,017 |  |  | 4,841 |  | 7,849 |
| Total | $ | 2,118 | $ | 2,248 |  | $ | 7,697 | $ | 10,073 |


## amsc:ScheduleOfWeightedAverageAssumptionsUsedInBlackScholesValuationModelForStockOptionsGrantedTextBlock

[0001193125-12-048929:notes:10]
|  | Three months ended |  | Nine months ended |  |
|  | December 31, |  | December 31, |  |
|  | 2011 |  | 2010 |  | 2011 |  | 2010 |  |
| Expected volatility | 79.7 | % | 61.4 | % | 69.7 | % | 65.5 | % |
| Risk-free interest rate | 1.1 | % | 2.4 | % | 1.8 | % | 2.1 | % |
| Expected life (years) | 5.9 |  | 6.1 |  | 5.9 |  | 6.1 |  |
| Dividend yield | None |  | None |  | None |  | None |  |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001193125-12-048929:notes:11]
10. Commitments and Contingencies

[0001193125-12-048929:notes:12]
Commitments

[0001193125-12-048929:notes:13]
The Company periodically enters into non-cancelable purchase contracts in order to ensure the availability of materials to support production of its products. Purchase commitments represent enforceable and legally binding agreements with suppliers to purchase goods or services. The Company periodically assesses the need to provide for impairment on these purchase contracts and records a loss on purchase commitments when required. As of December 31, 2011, the Company has $28.8 million of adverse purchase commitments in excess of its estimated future demand from certain of its customers in China, which the Company has recorded as a liability. The Company recorded adverse purchase commitment recoveries of $0.1 million and losses of less than $0.1 million during the three and nine months ended December 31, 2011, respectively. Adverse purchase commitment recoveries in the three months ended December 31, 2011 are the result of reductions in commitments to purchase materials due to renegotiations with certain suppliers and are recorded against cost of revenues.

[0001193125-12-048929:notes:14]
Contingencies

[0001193125-12-048929:notes:15]
From time to time, the Company is involved in legal and administrative proceedings and claims of various types. The Company records a liability in its consolidated financial statements for these matters when a loss is known or considered probable and the amount can be reasonably estimated. The Company reviews these estimates each accounting period as additional information is known and adjusts the loss provision when appropriate. If a matter is both probable to result in liability and the amounts of loss can be reasonably estimated, the Company estimates and discloses the possible loss or range of loss. If the loss is not probable or cannot be reasonably estimated, a liability is not recorded in its consolidated financial statements.

[0001193125-12-048929:notes:16]
Between April 6, 2011 and May 12, 2011, seven putative securities class action complaints were filed against the Company and two of its officers in the United States District Court for the District of Massachusetts; one complaint additionally asserted claims against the underwriters who participated in our November 12, 2010 securities offering. On June 7, 2011, the United States District Court for the District of Massachusetts consolidated these actions under the caption Lenartz v. American Superconductor Corporation, et al., Docket No. 1:11-cv-10582-WGY. On August 31, 2011, Lead Plaintiff, the Plumbers and Pipefitters National Pension Fund, filed a consolidated amended complaint against the Company, its officers and directors, and the underwriters who participated in our November 12, 2010 securities offering, asserting claims under sections 10(b) and 20(a) of the Securities Exchange Act of 1934 and Rule 10b-5 promulgated under the Securities Exchange Act of 1934, as well as under sections 11, 12(a)(2) and 15 of the Securities Act of 1933. The complaint alleges that during the relevant class period, the Company and its officers omitted to state material facts and made materially false and misleading statements relating to, among other things, its projected and recognized revenues and earnings, as well as its relationship with Sinovel Wind Group Co., Ltd. that artificially inflated the value of the Company's stock price. The complaint further alleges that the Company's November 12, 2010 securities offering contained untrue statements of material facts and omitted to state material facts required to be stated therein. The plaintiffs seek unspecified damages, rescindment of the Company's November 12, 2010 securities offering, and an award of costs and expenses, including attorney's fees.

[0001193125-12-048929:notes:17]
Between May 4, 2011 and June 17, 2011, four putative shareholder derivative complaints were filed against the Company (as a nominal defendant) and certain of its directors in the United States District Court for the District of Massachusetts. On July 5, 2011, the District Court consolidated three of these actions, and that matter is now captioned In re American Superconductor Corporation Derivative Litigation, Docket No. 1:11-cv-10784-WGY. On June 1, 2011, the plaintiff in the fourth action, Marlborough Family Revocable Trust v. Yurek, et al., moved to voluntarily dismiss its complaint and refiled its complaint in Superior Court for the Commonwealth of Massachusetts, Middlesex County. On September 7, 2011, the Marlborough action and another putative shareholder derivative complaint filed in Superior Court for the Commonwealth of Massachusetts were consolidated. That consolidated matter is captioned Marlborough Family Revocable Trust v. Yurek, et al., Docket No. 11-1961. On January 12, 2012, an additional shareholder derivative complaint was filed in the Court of Chancery for the State of Delaware. That matter is captioned Krasnoff v. Budhraja, et al., Docket No. 7171. The allegations of the

[0001193125-12-048929:notes:18]
derivative complaints mirror the allegations made in the putative class action complaints described above. The plaintiffs purport to assert claims against the director defendants for breach of fiduciary duty, abuse of control, gross mismanagement and corporate waste. The plaintiffs seek unspecified damages on behalf of the Company, as well as an award of costs and expenses, including attorney's fees.

[0001193125-12-048929:notes:19]
With respect to the above referenced litigation matters, an estimate of loss or range of loss cannot be made. There are numerous factors that make it difficult to meaningfully estimate possible loss or range of loss at this stage of these litigation matters, including that: the proceedings are in relatively early stages, there are significant factual and legal issues to be resolved, information obtained or rulings made during the lawsuits could affect the methodology for calculation of rescission and the related statutory interest rate. In addition, with respect to claims where damages are the requested relief, no amount of loss or damages has been specified. Therefore, the Company is unable at this time to estimate possible losses. The Company believes that these litigations are without merit, and it intends to defend these actions vigorously.

[0001193125-12-048929:notes:20]
On September 13, 2011, the Company commenced a series of legal actions in China against Sinovel Wind Group Co. Ltd. ("Sinovel"). The Company's Chinese subsidiary, Suzhou AMSC Superconductor Co. Ltd., filed a claim for arbitration with the Beijing Arbitration Commission in accordance with the terms of the Company's supply contracts with Sinovel. The case is captioned (2011) Jin Zhong An Zi No. 0693. On March 31, 2011, Sinovel refused to accept contracted shipments of 1.5 megawatt (MW) and 3 MW wind turbine core electrical components and spare parts that the Company was prepared to deliver. The Company alleges that these actions constitute material breaches of its contracts because Sinovel did not give it notice that it intended to delay deliveries as required under the contracts. Moreover, the Company alleges that Sinovel has refused to pay past due amounts for prior shipments of core electrical components and spare parts. The Company is seeking compensation for past product shipments (including interest) and monetary damages in the amount of approximately RMB 430 million ($67 million) due to Sinovel's breaches of its contracts. The Company is also seeking specific performance of our existing contracts as well as reimbursement of all costs and reasonable expenses with respect to the arbitration. The value of the undelivered components under the existing contracts, including the deliveries refused by Sinovel in March 2011, amounts to approximately RMB 4.6 billion ($720 million).

[0001193125-12-048929:notes:21]
On October 8, 2011, Sinovel filed with the Beijing Arbitration Commission an application under the caption (2011) Jing Zhong An Zi No. 0693, for a counterclaim against the Company for breach of the same contracts under which the Company filed its original arbitration claim. Sinovel claimed, among other things, that the goods supplied by the Company do not conform to the standards specified in the contracts and claimed damages in the amount of approximately RMB 370 million ($58 million). On October 17, 2011, Sinovel filed with the Beijing Arbitration Commission a request for change of counterclaim to increase its damage claim to approximately RMB 1 billion ($157 million). On December 22, 2011, Sinovel filed with the Beijing Arbitration Commission an additional request for change of counterclaim to increase its damages claim to approximately RMB 1.2 billion ($190 million). Deducting the RMB 430 million ($67 million) of past product shipments claimed by the Company, the net amount of damages claimed by Sinovel is approximately RMB 770 million ($120 million). The Company believes that Sinovel's claims are without merit and it intends to defend these actions vigorously. Since the proceedings in this matter are in relatively early stages, the Company cannot reasonably estimate possible losses or range of losses at this time.

[0001193125-12-048929:notes:22]
The Company also submitted a civil action application to the Beijing No. 1 Intermediate People's Court under the caption (2011) Yi Zhong Min Chu Zi No. 15524, against Sinovel for software copyright infringement on September 13, 2011. The application alleges Sinovel's unauthorized use of portions of the Company's wind turbine control software source code developed for Sinovel's 1.5MW wind turbines and the binary code, or upper layer, of the Company's software for the PM3000 power converters in 1.5MW wind turbines. In July 2011, a former employee of the Company's AMSC Windtec GmbH subsidiary was arrested in Austria on charges of economic espionage and fraudulent manipulation of data. In September 2011, the former employee pled guilty to the charges, and he is currently serving a prison sentence. As a result of the Company's internal investigation and a criminal investigation conducted by Austrian authorities, the Company believes that this former employee was contracted by Sinovel through an intermediary while employed by the Company and improperly obtained and transferred to Sinovel portions of its wind turbine control software source code developed for Sinovel's 1.5MW wind turbines. Moreover, the Company believes the former employee illegally used source code to develop for Sinovel a software modification to circumvent the encryption and remove technical protection measures on the PM3000 power converters in 1.5MW wind turbines in the field. The Company is seeking a cease and desist order with respect to the unauthorized copying, installation and use of its software, monetary damages of approximately RMB 38 million ($6 million) for our economic losses and reimbursement of all costs and reasonable expenses. The No. 1 Intermediate People's Court accepted the case, which was necessary in order for the case to proceed. In November 2011, Sinovel filed a motion to remove this case from the Beijing No. 1 Intermediate People's Court and transfer the matter to the Beijing Arbitration Commission. The Company is awaiting the

[0001193125-12-048929:notes:23]
court's decision.

[0001193125-12-048929:notes:24]
The Company submitted a civil action application to the Beijing Higher People's Court against Sinovel and certain of its employees for trade secret infringement on September 13, 2011 under the caption (2011) Gao Min Chu Zi No. 4193. The application alleges the defendants' unauthorized use of portions of the Company's wind turbine control software source code developed for Sinovel's 1.5MW wind turbines as described above with respect to the Copyright Action. The Company is seeking monetary damages of RMB 2.9 billion ($453 million) for the trade secret infringement as well as reimbursement of all costs and reasonable expenses. The Beijing Higher People's Court accepted the case, which was necessary in order for the case to proceed. On December 22, 2011, the Beijing Higher People's Court transferred this case to the Beijing No. 1 Intermediate People's Court under the caption (2011) Gao Min Chu Zi No. 4193. The Company is currently awaiting notice from the Beijing No. 1 Intermediate People's Court regarding the evidence submission deadline and the first hearing date.

[0001193125-12-048929:notes:25]
On September 16, 2011, the Company filed a civil copyright infringement complaint in the Hainan Province No. 1 Intermediate People's Court against Dalian Guotong Electric Co. Ltd. ("Guotong"), a supplier of power converter products to Sinovel, and Huaneng Hainan Power, Inc. ("Huaneng"), a wind farm operator that has purchased Sinovel wind turbines containing Guotong power converter products. The case is captioned (2011) Hainan Yi Zhong Min Chu Zi No. 62. The application alleges that the Company's PM1000 converters in certain Sinovel wind turbines have been replaced by converters produced by Guotong. Because the Guotong converters are being used in wind turbines containing the Company's wind turbine control software, the Company believes that its copyrighted software is being infringed. The Company is seeking a cease and desist order with respect to the unauthorized use of its software, monetary damages of RMB 1.2 million ($0.2 million) for its economic losses (with respect to Guotong only) and reimbursement of all costs and reasonable expenses. The court has accepted the case, which was necessary in order for the case to proceed. In addition, upon the request of the defendant Huaneng, Sinovel has been added by the court to this case as a defendant and Huaneng has been released from this case. In December 2011, Sinovel filed a jurisdiction opposition motion requesting dismissal by the Hainan Province No. 1 Intermediate People's Court, saying the case should be governed by the Beijing Arbitration Commission. On February 3, 2012, the Company received the Civil Ruling from the court, which granted Sinovel's motion, and dismissed the entire case. The Company plans to appeal the court's ruling.

[0001193125-12-048929:notes:26]
Ghodawat Energy Pvt Ltd ("Ghodawat"), a company registered in India carrying on the business of wind power development, lodged a Request for Arbitration with the Secretariat of the ICC International Court of Arbitration on May 12, 2011 and named AMSC Windtec GmbH ("AMSC Windtec") as the Respondent. Under the Request for Arbitration, Ghodawat alleges that AMSC Windtec breached an agreement dated March 19, 2008 pursuant to which AMSC Windtec granted a license to Ghodawat to manufacture, use, sell, market, erect, commission and maintain certain wind turbines using its technical information and wind turbine design (the "License Agreement"). Under the Request for Arbitration, Ghodawat's claims in this arbitration amount to approximately €18 million ($24 million). AMSC Windtec filed an Answer to Request for Arbitration and Counterclaim ("Answer and Counterclaim"), in which AMSC Windtec denied Ghodawat's claims in their entirety. AMSC Windtec has also submitted counterclaims under the License Agreement against Ghodawat in the amount of approximately €6 million ($9 million). Ghodawat has filed a Reply to Answer to Request for Arbitration and Counterclaim in which it denies AMSC Windtec's counterclaims. The arbitration proceedings are currently ongoing. The Company has recorded a loss contingency based on its assessment of probable losses on this claim; however this amount is immaterial to its consolidated financial statements.

[0001193125-12-048929:notes:27]
Other

[0001193125-12-048929:notes:28]
The Company enters into long-term construction contracts with customers that require the Company to obtain performance bonds. The Company is required to deposit an amount equivalent to some or all the face amount of the performance bonds into an escrow account until the termination of the bond. When the performance conditions are met, amounts deposited as collateral for the performance bonds are returned to the Company. In addition, the Company has various contractual arrangements in which minimum quantities of goods or services have been committed to be purchased on an annual basis.

[0001193125-12-048929:notes:29]
As of December 31, 2011, the Company had two performance bonds in support of customer contracts. The total value of the outstanding performance bonds was $0.4 million with various expiration dates through October 2012. In the event that the payment is made in accordance with the requirements of any of these performance bonds, the Company would record the payment as an offset to revenue.

[0001193125-12-048929:notes:30]
At December 31, 2011, the Company had $9.0 million of restricted cash included in current assets and $2.5 million of restricted cash included in long-term assets. These amounts included in restricted cash represent deposits to secure letters of credit for various supply contracts. These deposits are held in interest bearing accounts.

[0001193125-12-048929:notes:31]
The Company had unused, unsecured lines of credit consisting of €2.3 million (approximately $3.0 million) in Austria as of December 31, 2011. During the nine months ended December 31, 2011, the Company's unsecured credit line with the Bank of China expired and it repaid borrowings on lines of credit of $4.6 million. There were no borrowings outstanding as of December 31, 2011.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001193125-12-048929:notes:32]
2. Stock-Based Compensation

[0001193125-12-048929:notes:33]
The Company accounts for its stock-based compensation at fair value. The following table summarizes stock-based compensation expense by financial statement line item for the three and nine months ended December 31, 2011 and 2010 (in thousands):

[0001193125-12-048929:notes:34]
During the nine months ended December 31, 2011, the Company granted approximately 815,000 and 408,000 shares of stock options and restricted stock, respectively, to employees under the 2007 Stock Incentive Plan. The restricted stock granted during the nine months ended December 31, 2011 includes approximately 109,000 shares of performance-based restricted stock, which will vest upon achievement of certain financial performance measurements. The Company recognizes the fair value of the performance based awards over the estimated period of each award for which the achievement of the performance measures are probable to occur. As of December 31, 2011, the Company has assessed the weighted average probability for these awards as likely to occur and has recorded expenses accordingly. The remaining shares granted vest upon the passage of time, generally three years. For awards that vest upon the passage of time, expense is being recorded over the vesting period.

[0001193125-12-048929:notes:35]
The estimated fair value of the Company's stock-based awards, less expected annual forfeitures, is amortized over the awards' service period. The total unrecognized compensation cost for unvested outstanding stock options was $7.4 million as of December 31, 2011. This expense will be recognized over a weighted average expense period of approximately 2.1 years. The total unrecognized compensation cost for unvested outstanding restricted stock was $4.0 million as of December 31, 2011. This expense will be recognized over a weighted average expense period of approximately 1.7 years.

[0001193125-12-048929:notes:36]
The weighted-average assumptions used in the Black-Scholes valuation model for stock options granted during the three and nine months ended December 31, 2011 and 2010 are as follows:

[0001193125-12-048929:notes:37]
[same as prior period, unchanged from 0000950123-11-096966:notes:47]

[0001193125-12-048929:notes:38]
In conjunction with the departure of certain former executive officers, the Company agreed to modify certain vested awards by extending the period over which two former officers would be entitled to exercise stock options and accelerated the vesting of certain other outstanding awards for one former officer. Accordingly, the Company recorded stock-based compensation expense related to these modifications of $0.9 million in the nine months ended December 31, 2011.


## us-gaap:EarningsPerShareTextBlock

[0001193125-12-048929:notes:39]
3. Computation of Net (Loss) Income per Common Share

[0001193125-12-048929:notes:40]
Basic net (loss) income per share ("EPS") is computed by dividing net (loss) income by the weighted-average number of common shares outstanding for the period. Where applicable, diluted EPS is computed by dividing the net (loss) income by the weighted-average number of common shares and dilutive common equivalent shares outstanding during the period, calculated using the treasury stock method. Common equivalent shares include the effect of restricted stock, exercise of stock options and warrants and contingently issuable shares. For the three and nine months ended December 31, 2011 and 2010, 2.4 million shares and 2.0 million shares, respectively, and 2.4 million shares and 2.0 million shares, respectively, were not included in the calculation of diluted EPS as they were considered anti-dilutive.

[0001193125-12-048929:notes:41]
The following table reconciles the numerators and denominators of the earnings per share calculation for the three and nine months ended December 31, 2011 and 2010 (in thousands, except per share data):


## us-gaap:EquityMethodInvestmentsDisclosureTextBlock

[0001193125-12-048929:notes:42]
11. Equity Investments

[0001193125-12-048929:notes:43]
[same as prior period, unchanged from 0000950123-11-096966:notes:53]

[0001193125-12-048929:notes:44]
On October 9, 2009, the Company made an investment in Tres Amigas LLC, a Delaware limited liability company ("Tres Amigas"), is focused on providing the first common interconnection of America's three power grids to help the country achieve its renewable energy goals and facilitate the smooth, reliable and efficient transfer of green power from region to region, for $1.8 million, consisting of $0.8 million in cash and $1.0 million in AMSC common stock. On January 6, 2011 and May 20, 2011, the Company increased its minority position in Tres Amigas by investing an additional $1.8 million in cash on each date. As of December 31, 2011, the Company holds a 34% ownership interest in Tres Amigas

[0001193125-12-048929:notes:45]
The Company has determined that Tres Amigas is a variable interest entity ("VIE") and that the Company is not the primary beneficiary of the VIE. Therefore, the Company has not consolidated Tres Amigas as of December 31, 2011. The investment is carried at the acquisition cost, plus the Company's equity in undistributed earnings or losses. The Company's maximum exposure to loss is limited to the Company's recorded investment in this VIE. The Company's investment in Tres Amigas is included in other assets on the consolidated balance sheet and the equity in undistributed losses of Tres Amigas is included in other income, net, on the consolidated statements of operations.

[0001193125-12-048929:notes:46]
The net investment activity for the nine months ended December 31, 2011 is as follows (in thousands):

[0001193125-12-048929:notes:47]
| Balance at April 1, 2011 | $ | 3,026 |  |
| Purchase of minority investment |  | 1,800 |  |
| Minority interest in net losses |  | (741 | ) |
| Balance at December 31, 2011 | $ | 4,085 |  |

[0001193125-12-048929:notes:48]
[same as prior period, unchanged from 0000950123-11-096966:notes:58]

[0001193125-12-048929:notes:49]
On August 12, 2010, the Company acquired (through its Austrian subsidiary), a minority ownership position in Blade Dynamics Ltd. ("Blade Dynamics"), a designer and manufacturer of advanced wind turbine blades based on proprietary materials and structural technologies, for $8.0 million in cash. The Company uses the equity method of accounting for this investment since it does not have a controlling ownership interest in the operating and financial policies of Blade Dynamics. As such, the investment is carried at the acquisition cost, plus the Company's equity in undistributed earnings or losses. The Company's investment is included in other assets on the unaudited condensed consolidated balance sheets and the minority interest in net losses of Blade Dynamics is included in other income, net, on the unaudited condensed consolidated statements of operations. As of December 31, 2011, the Company holds a 25% ownership interest in Blade Dynamics. The net investment activity for the nine months ended December 31, 2011 is as follows (in thousands):

[0001193125-12-048929:notes:50]
| Balance at April 1, 2011 | $ | 7,903 |  |
| Minority interest in net losses |  | (880 | ) |
| Net foreign exchange rate impact |  | (561 | ) |
| Balance at December 31, 2011 | $ | 6,462 |  |


## us-gaap:FairValueAssetsAndLiabilitiesMeasuredOnRecurringBasisGainLossIncludedInEarningsTextBlock

[0001193125-12-048929:notes:51]
|  |  | Total |  | Quoted Prices in |  | Using Significant Other |  | Using Significant |
|  |  | Carrying |  | Active Markets |  | Observable Inputs |  | Unobservable Inputs |
|  |  | Value |  | (Level 1) |  | (Level 2) |  | (Level 3) |
| March 31, 2011: |  |  |  |  |  |  |  |  |
| Assets: |  |  |  |  |  |  |  |  |
| Cash equivalents | $ | 49,837 | $ | 49,837 | $ | — | $ | — |
| Short-term government-backed |  | 76,371 |  | — |  | 76,371 |  | — |
| securities |  |  |  |  |  |  |  |  |
| Short-term commercial paper |  | 39,755 |  | — |  | 39,755 |  | — |
| Derivatives |  | 3,087 |  | — |  | 3,087 |  | — |

[0001193125-12-048929:notes:52]
|  |  | Total |  | Quoted Prices in |  | Using Significant Other |  | Using Significant |
|  |  | Carrying |  | Active Markets |  | Observable Inputs |  | Unobservable Inputs |
|  |  | Value |  | (Level 1) |  | (Level 2) |  | (Level 3) |
| December 31, 2011: |  |  |  |  |  |  |  |  |
| Assets: |  |  |  |  |  |  |  |  |
| Cash equivalents | $ | 38,474 | $ | 38,474 | $ | — | $ | — |
| Short-term commercial paper |  | 5,261 |  | — |  | 5,261 |  | — |


## us-gaap:FairValueDisclosuresTextBlock

[0001193125-12-048929:notes:53]
[same as prior period, unchanged from 0000950123-11-096966:notes:62]

[0001193125-12-048929:notes:54]
[same as prior period, unchanged from 0000950123-11-096966:notes:64]

[0001193125-12-048929:notes:55]
Level 1 - Inputs are unadjusted quoted prices in active markets for identical assets or liabilities that the Company has the ability to access at the measurement date.

[0001193125-12-048929:notes:56]
Level 2 - Inputs include quoted prices for similar assets and liabilities in active markets, quoted prices for identical or similar assets or liabilities in markets that are not active, inputs other than quoted prices that are observable for the asset or liability, and inputs that are derived principally from or corroborated by observable market data by correlation or other means (market corroborated inputs).

[0001193125-12-048929:notes:57]
Level 3 - Unobservable inputs that reflect the Company's assumptions that market participants would use in pricing the asset or liability. The Company develops these inputs based on the best information available, including its own data.

[0001193125-12-048929:notes:58]
[same as prior period, unchanged from 0000950123-11-096966:notes:66]

[0001193125-12-048929:notes:59]
The Company presents financial asset and liability activity on a gross basis within the Level 3 measurement roll-forward and details of transfers in and out of Level 1 and 2 measurements. Changes in the hierarchy of financial assets and liabilities from its current level will be reflected in the period during which the pricing methodology of such investment changes. Disclosure of the transfer of securities from Level 1 to Level 2 or Level 3 will be made in the event that the related security is significant to total cash and investments. The Company did not have any transfers of assets and liabilities between Level 1 and Level 2 of the fair value measurement hierarchy during the three or nine months ended December 31, 2011.

[0001193125-12-048929:notes:60]
The following table provides the assets carried at fair value, measured as of December 31, 2011 and March 31, 2011 (in thousands):

[0001193125-12-048929:notes:61]
[same as prior period, unchanged from 0000950123-11-096966:notes:68]

[0001193125-12-048929:notes:62]
[same as prior period, unchanged from 0000950123-11-096966:notes:69]

[0001193125-12-048929:notes:63]
[same as prior period, unchanged from 0000950123-11-096966:notes:70]

[0001193125-12-048929:notes:64]
[same as prior period, unchanged from 0000950123-11-096966:notes:71]

[0001193125-12-048929:notes:65]
[same as prior period, unchanged from 0000950123-11-096966:notes:72]

[0001193125-12-048929:notes:66]
[same as prior period, unchanged from 0000950123-11-096966:notes:73]

[0001193125-12-048929:notes:67]
[same as prior period, unchanged from 0000950123-11-096966:notes:74]


## us-gaap:IncomeTaxDisclosureTextBlock

[0001193125-12-048929:notes:68]
8. Income Taxes

[0001193125-12-048929:notes:69]
The Company recorded income tax expense of less than $0.1 million and $1.2 million for the three and nine months ended December 31, 2011, respectively, and the Company recorded an income tax benefit of $2.5 million and income tax expense of $12.6 million for the three and nine months ended December 31, 2010, respectively. The Company has provided a valuation allowance against all net deferred tax assets as of December 31, 2011, as it is more likely than not that its net deferred tax assets are not currently realizable due to the net operating losses incurred by the Company since its inception in the U.S., its significant write-offs in the fiscal year ended March 31, 2011 and the losses that are forecasted in certain foreign jurisdictions in the future.

[0001193125-12-048929:notes:70]
During the nine months ended December 31, 2011, the Company recorded additional income tax expense of $0.8 million for uncertain tax positions related to its Austrian subsidiary.


## us-gaap:InventoryDisclosureTextBlock

[0001193125-12-048929:notes:71]
6. Inventory

[0001193125-12-048929:notes:72]
[same as prior period, unchanged from 0000950123-11-096966:notes:79]

[0001193125-12-048929:notes:73]
|  |  | December 31, |  | March 31, |
|  |  | 2011 |  | 2011 |
| Raw materials | $ | 10,279 | $ | 17,100 |
| Work-in-process |  | 4,844 |  | 2,432 |
| Finished goods |  | 15,683 |  | 3,915 |
| Deferred program costs |  | 3,215 |  | 2,381 |
| Net inventory | $ | 34,021 | $ | 25,828 |

[0001193125-12-048929:notes:74]
The Company recorded inventory write-downs of approximately $0.7 million and $2.2 million in the three and nine months ended December 31, 2011, respectively.

[0001193125-12-048929:notes:75]
Deferred program costs as of December 31, 2011 and March 31 2011 primarily represent costs incurred on D-VAR turnkey projects and programs accounted for under contract accounting where the Company needs to complete development programs before revenue and costs will be recognized.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0001193125-12-048929:notes:76]
1. Description of the Business and Basis of Presentation

[0001193125-12-048929:notes:77]
American Superconductor Corporation ("AMSC" or the "Company") was founded on April 9, 1987. The Company is a leading provider of megawatt-scale solutions that lower the cost of wind power and enhance the performance of the power grid. In the wind power market, the Company enables manufacturers to field wind turbines through its advanced engineering, support services and power electronics products. In the power grid market, the Company enables electric utilities and renewable energy project developers to connect, transmit and distribute power through its transmission planning services and power electronics and superconductor-based products. The Company's wind and power grid products and services provide exceptional reliability, security, efficiency and affordability to its customers.

[0001193125-12-048929:notes:78]
These unaudited condensed consolidated financial statements of the Company have been prepared in accordance with the Securities and Exchange Commission's ("SEC") instructions to Form 10-Q. Certain information and footnote disclosures normally included in the financial statements prepared in accordance with accounting principles generally accepted in the United States ("GAAP") have been condensed or omitted pursuant to those instructions. The year-end condensed balance sheet data was derived from audited financial statements but does not include all disclosures required by GAAP. The unaudited condensed consolidated financial statements, in the opinion of management, reflect all adjustments (consisting of normal recurring adjustments) necessary for a fair statement of the results for the interim periods ended December 31, 2011 and 2010 and the financial position at December 31, 2011. The unaudited condensed consolidated financial statements include the accounts of the Company and its wholly-owned subsidiaries. All significant intercompany balances and transactions are eliminated in consolidation. Certain reclassifications of prior year amounts have been made to conform to current year presentation. These reclassifications had no effect on net income, cash flows from operating activities or stockholders' equity.

[0001193125-12-048929:notes:79]
[same as prior period, unchanged from 0000950123-11-096966:notes:85]

[0001193125-12-048929:notes:80]
Wind. Through its Windtec Solutions, the Wind business segment enables manufacturers to field wind turbines with exceptional power output, reliability and affordability. The Company licenses its highly engineered wind turbine designs, provides extensive customer support services and supplies advanced power electronics and control systems to wind turbine manufactures. The Company's design portfolio includes a broad range of drive trains and power ratings up to 10 megawatts. The Company believes its unique engineering capabilities, ranging from bearings to advanced synchronous generators to blades, enables it to provide its partners with highly-optimized wind turbine platforms. Furthermore, these designs and support services typically lead to sales of its power electronics and software-based control systems, which are designed for optimized performance, efficiency and grid compatibility.

[0001193125-12-048929:notes:81]
Grid. Through its Gridtec Solutions, the Grid business segment enables electric utilities and renewable energy project developers to connect, transmit and distribute power with exceptional efficiency, reliability and affordability. The Company provides transmission planning services that allow it to identify power grid congestion, poor power quality and other risks, which helps it determine how its solutions can improve network performance. These services often lead to sales of grid interconnection solutions for wind farms and solar power plants, power quality systems and transmission and distribution cable systems.

[0001193125-12-048929:notes:82]
On March 12, 2011, the Company entered into a Share Purchase Agreement, by and among the Company and the shareholders of The Switch Engineering Oy, a power technologies company headquartered in Finland ("The Switch"), which was amended on June 29, 2011 (as amended, the "Agreement"). Pursuant to the Agreement, the Company agreed to acquire all of the outstanding shares of The Switch. On October 28, 2011, the Company and The Switch entered into a termination agreement pursuant to which the parties mutually agreed to terminate the Agreement due to adverse market conditions for a financing required to fund the acquisition. Under the termination agreement, The Switch retained a $20.6 million advance payment as a break-up fee. As a result, the Company recorded a write-off of the advance payment during the nine months ended December 31, 2011.

[0001193125-12-048929:notes:83]
At December 31, 2011, the Company had cash, cash equivalents, and marketable securities of $63.9 million. The Company has experienced a substantial decline in revenues and incurred a net loss of $115.7 million during the nine months ended December 31, 2011. The Company's business plan anticipates a substantial use of cash from operations in its fiscal year ending March 31, 2012 in light of the difficult and uncertain current economic environment in China, the significant restructuring actions undertaken and the slowdown in the Chinese wind power market, which has accounted for more than two-thirds of the Company's revenues in recent fiscal years. At December 31, 2011, the Company has accrued liabilities related to adverse purchase commitments for inventory totaling $28.8 million. From April 1, 2011 through the date of this filing, the Company has reduced its global workforce by approximately 50%, which is expected to result in annual savings of approximately $50 million. As of December 31, 2011, the Company has a global workforce of over 400 persons. The Companyï¿½s cost reduction efforts and anticipated revenue growth are expected to result in a substantial reduction in cash used for operations during the fiscal year ended March 31, 2013. The Company plans to continue to closely monitor its expenses and if required, will further reduce operating costs and capital spending to enhance liquidity. The Company is working with its inventory suppliers to delay cash settlements and reduce the gross liability associated with its adverse purchase commitments. The Company believes that its available cash, together with additional reductions in operating costs and capital expenditures as necessary, will be sufficient to fund its operations, capital expenditures and other cash requirements for the next twelve months. To bolster its long-term liquidity, the Company intends to seek financing through means that may include public and private equity offerings, debt financings, and other financing alternatives. However, there can be no assurance that financing will be available on commercially acceptable terms or at all. The Company's liquidity is highly dependent on its ability to profitably grow its revenues, successfully manage its adverse purchase order commitments and raise additional capital as required.

[0001193125-12-048929:notes:84]
The results of operations for an interim period are not necessarily indicative of the results of operations to be expected for the fiscal year. These unaudited condensed consolidated financial statements should be read in conjunction with the audited consolidated financial statements for the fiscal year ended March 31, 2011 (fiscal 2010) which are contained in the Company's Annual Report on Form 10-K.

[0001193125-12-048929:notes:85]
The Company's fiscal year begins on April 1 and ends on March 31. This document refers to fiscal 2011, which is defined as the period beginning on April 1, 2011 and concluding on March 31, 2012. The third quarter of fiscal 2011 began on October 1, 2011 and concluded on December 31, 2011.


## us-gaap:ProductWarrantyDisclosureTextBlock

[0001193125-12-048929:notes:86]
7. Product Warranty

[0001193125-12-048929:notes:87]
[same as prior period, unchanged from 0000950123-11-096966:notes:93]

[0001193125-12-048929:notes:88]
[same as prior period, unchanged from 0000950123-11-096966:notes:94]

[0001193125-12-048929:notes:89]
|  |  | Three months ended |  |  | Nine months ended |  |
|  |  | December 31, |  |  | December 31, |  |
|  |  | 2011 |  |  | 2010 |  |  | 2011 |  |  | 2010 |  |
| Balance at beginning of period | $ | 7,055 |  | $ | 7,374 |  | $ | 7,907 |  | $ | 6,431 |  |
| Change in accruals for warranties during the period |  | (300 | ) |  | 2,193 |  |  | (774 | ) |  | 6,533 |  |
| Settlements during the period |  | (482 | ) |  | (1,119 | ) |  | (860 | ) |  | (4,516 | ) |
| Balance at end of period | $ | 6,273 |  | $ | 8,448 |  | $ | 6,273 |  | $ | 8,448 |  |

[0001193125-12-048929:notes:90]
The Company includes warranty period expirations as changes in accruals for warranties in the table above. The Company includes the warranty accrual within accounts payable and accrued expenses in the unaudited condensed consolidated balance sheets.


## us-gaap:RestructuringImpairmentAndOtherActivitiesDisclosureTextBlock

[0001193125-12-048929:notes:91]
9. Restructuring and Impairments

[0001193125-12-048929:notes:92]
Restructuring

[0001193125-12-048929:notes:93]
The Company accounts for charges resulting from operational restructuring actions in accordance with ASC Topic 420,

[0001193125-12-048929:notes:94]
Exit or Disposal Cost Obligations ("ASC 420") and ASC Topic 712, Compensation—Nonretirement Postemployment Benefits

[0001193125-12-048929:notes:95]
("ASC 712"). In accounting for these obligations, the Company is required to make assumptions related to the amounts of employee severance, benefits, and related costs and the time period over which leased facilities will remain vacant, sublease terms, sublease rates and discount rates. Estimates and assumptions are based on the best information available at the time the obligation arises. These estimates are reviewed and revised as facts and circumstances dictate; changes in these estimates could have a material effect on the amount accrued on the consolidated balance sheet.

[0001193125-12-048929:notes:96]
The Company initiated restructuring activities in order to reorganize global operations, streamline various functions of the business, and reduce its global workforce to better reflect the demand for its products. From April 1, 2011 through the date of this filing, the Company has reduced its global workforce by approximately 50%, which is expected to generate annualized savings of more than $50 million annually. During the three and nine months ended December 31, 2011, the Company incurred costs associated with the workforce reduction consisting of severance pay, outplacement services, medical benefits, and other related benefits. As a result, for the three and nine months ending December 31, 2011, the Company recorded employee severance and benefit costs of $2.2 million and $5.4 million, respectively. These charges are expected to be paid through the fiscal year ending March 31, 2012.

[0001193125-12-048929:notes:97]
The following table presents restructuring charges and cash payments (in thousands):

[0001193125-12-048929:notes:98]
|  |  | Severance pay and |  |  | Facility |  |  |  |  |
|  |  | benefits |  |  | exit costs |  |  | Total |  |
| Accrued restructuring balance at October 1, 2011 | $ | 2,076 |  | $ | 127 |  | $ | 2,203 |  |
| Charges to operations |  | 2,181 |  |  | - |  |  | 2,181 |  |
| Cash payments |  | (1,647 | ) |  | (16 | ) |  | (1,663 | ) |
| Accrued restructuring balance at December 31, 2011 | $ | 2,610 |  | $ | 111 |  | $ | 2,721 |  |
| Accrued restructuring balance at April 1, 2011 | $ | - |  | $ | - |  | $ | - |  |
| Charges to operations |  | 5,437 |  |  | 127 |  |  | 5,564 |  |
| Cash payments |  | (2,827 | ) |  | (16 | ) |  | (2,843 | ) |
| Accrued restructuring balance at December 31, 2011 | $ | 2,610 |  | $ | 111 |  | $ | 2,721 |  |

[0001193125-12-048929:notes:99]
In addition, during the nine months ended December 31, 2011 the Company consolidated certain of its business operations in Europe to reduce overall facility costs. The consolidation plan entailed vacating approximately 8,937 square feet of occupied space in Klagenfurt, Austria and plans to vacate approximately 3,300 square feet of occupied space in Nuremburg, Germany. The Klagenfurt facility closure was accounted for in accordance with ASC 420, pursuant to which the Company recorded a liability equal to the fair value of the remaining lease payments as of the cease-use date. Fair value was determined based upon the discounted present value of remaining lease rentals (using a discount rate of 10.1%) for the space no longer occupied, considering future estimated potential sublease income. As a result, the Company recorded facility exit costs of $0.1 million related to the remaining lease commitment on the leased space. These charges are expected to be paid through fiscal 2012. As of December 31, 2011, the Company had not ceased using the Nuremburg facility and therefore recorded no liability for remaining lease payments. All restructuring charges discussed above are included within restructuring and impairments in the Company's unaudited condensed consolidated statements of operations. The Company includes accrued restructuring within accounts payable and accrued expenses in the unaudited condensed consolidated balance sheets.

[0001193125-12-048929:notes:100]
Impairments

[0001193125-12-048929:notes:101]
The Company periodically evaluates its long-lived assets consisting principally of fixed assets and amortizable intangible assets for potential impairment. In accordance with the applicable accounting guidance for the treatment of long-lived assets, the Company reviews the carrying value of its long-lived assets or asset group that is held and used, including intangible assets subject to amortization, for impairment whenever events and circumstances indicate that the carrying value of the assets may not be recoverable. Under the held and used approach, the asset or asset group to be tested for impairment should represent the lowest level for which identifiable cash flows are largely independent of the cash flows of other groups of assets and liabilities. The Company evaluates its long-lived assets whenever events or circumstances suggest that the carrying amount of an asset or group of assets may not be recoverable from the estimated undiscounted future cash flows.

[0001193125-12-048929:notes:102]
In November 2011, the Company completed certain restructuring activities to reduce costs and to align its strategic priorities to capitalize on near and long-term opportunities in its Grid segment. As a result, the Company concluded that there were indicators of potential impairment of certain long-lived assets in its Grid segment and therefore conducted an assessment of the recoverability of these assets during the three months ended December 31, 2011 by comparing the carrying value of the assets to the pre-tax undiscounted cash flows estimated to be generated by those assets over their remaining book useful lives. Based on the calculation performed by management, the sum of the undiscounted cash flows forecasted to be generated by certain assets within its Grid segment were less than the carrying value of those assets. Therefore, there was an indication that certain of the Company's Grid assets were impaired and, as a result, the Company performed additional analysis. An evaluation of the level of impairment was made by comparing the implied fair value of those definite long-lived tangible and intangible assets of its Grid segment against their carrying values.

[0001193125-12-048929:notes:103]
The fair values of the impacted property and equipment were based on what the Company could reasonably expect to sell each asset from the perspective of a market participant. The determination of the fair value of its property and equipment includes estimates and judgments regarding the marketability and ultimate sales price of individual assets. The Company utilized market data and approximations from comparable analyses to arrive at the estimated fair values of the impacted property and equipment. The fair values of amortization intangible assets related to completed technology were determined

[0001193125-12-048929:notes:104]
using the relief-from-royalty method over the estimated economic lives of those assets from the perspective of a market participant. During the three months ended December 31, 2011, the Company determined that certain of its Grid segment property, plant and equipment were impaired as their carrying value exceeded their fair value. Accordingly, the Company recorded an impairment charge of $1.7 million.

[0001193125-12-048929:notes:105]
In addition, the Company recorded impairment charges of $0.2 million and $1.1 million during the three and nine months ended December 31, 2011, respectively, primarily related to long-lived assets for which there is no remaining future economic benefit as a result of the consolidation of operations in Europe.


## us-gaap:ScheduleOfAccountsNotesLoansAndFinancingReceivableTextBlock

[0001193125-12-048929:notes:106]
5. Accounts Receivable

[0001193125-12-048929:notes:107]
[same as prior period, unchanged from 0000950123-11-096966:notes:97]

[0001193125-12-048929:notes:108]
The Company records bank acceptance notes receivable arranged with third-party financial institutions by certain customers to settle their transactions within prepaid expenses and other current assets. These notes are typically non-interest bearing and generally have maturities of less than six months. The carrying amount of notes receivable approximate their fair values. The Company had notes receivable outstanding of $3.2 million and $2.0 million as of December 31, 2011 and March 31, 2011, respectively.


## us-gaap:ScheduleOfRevenueByMajorCustomersByReportingSegmentsTableTextBlock

[0001193125-12-048929:notes:109]
|  |  | Three months ended |  |  | Nine months ended |  |
|  |  | December 31, |  |  | December 31, |  |
|  |  | 2011 |  |  | 2010 |  |  | 2011 |  |  | 2010 |  |
| Inox Wind, Ltd. |  | 27 | % | < | 10 | % |  | 21 | % | < | 10 | % |
| Doosan Heavy Industries & Construction Co Ltd. |  | 12 | % | < | 10 | % |  | 15 | % | < | 10 | % |
| Ergon Energy Corporation Limited |  | 11 | % |  | — |  | < | 10 | % |  | — |  |
| Vestas – Australian Wind Technology Ltd | < | 10 | % |  | 44 | % | < | 10 | % | < | 10 | % |
| Hyundai Heavy Industries Co., Ltd. | < | 10 | % |  | 10 | % | < | 10 | % | < | 10 | % |
| Shenyang Blower Works Group Co., Ltd. | < | 10 | % |  | 11 | % | < | 10 | % | < | 10 | % |
| Sinovel Wind Co., Ltd |  | — |  |  | — |  |  | — |  |  | 66 | % |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001193125-12-048929:notes:110]
12. Business Segments

[0001193125-12-048929:notes:111]
[same as prior period, unchanged from 0000950123-11-096966:notes:100]

[0001193125-12-048929:notes:112]
The Company segments its business into two market-facing business units: Wind and Grid. The Company believes this market-centric structure enables it to more effectively anticipate and meet the needs of wind turbine manufacturers, power generation project developers and electric utilities.

[0001193125-12-048929:notes:113]
Grid. Through its Gridtec Solutions, the Grid business segment enables electric utilities and renewable energy project developers to connect, transmit and distribute power with exceptional efficiency, reliability and affordability. The Grid business unit provides transmission planning services that allow us to identify power grid congestion, poor power quality and other risks, which helps the Company determine how its solutions can improve network performance. These services often lead to sales of grid interconnection solutions for wind farms and solar power plants, power quality systems and transmission and distribution cable systems.

[0001193125-12-048929:notes:114]
[same as prior period, unchanged from 0000950123-11-096966:notes:103]

[0001193125-12-048929:notes:115]
[same as prior period, unchanged from 0000950123-11-096966:notes:104]

[0001193125-12-048929:notes:116]
The accounting policies of the business segments are the same as those for the consolidated Company. The Company's business segments have been determined in accordance with the Company's internal management structure, which is organized based on operating activities. The Company evaluates performance based upon several factors, of which the primary financial measures are segment revenues and segment operating (loss) income. The disaggregated financial results of the segments reflect allocation of certain functional expense categories consistent with the basis and manner in which Company management

[0001193125-12-048929:notes:117]
internally disaggregates financial information for the purpose of assisting in making internal operating decisions. In addition, certain corporate expenses which the Company does not believe are specifically attributable or allocable to either of the two business segments have been excluded from the segment operating (loss) income.

[0001193125-12-048929:notes:118]
For the three and nine months ended December 31, 2011, unallocated corporate expenses primarily consist of restructuring and impairment charges of $4.1 million and $8.4 million, respectively, and stock-based compensation expense of $2.1 million and $7.7 million, respectively. In addition, the nine months ended December 31, 2011 includes expense of $20.6 million for the write-off of an advanced payment to The Switch. Unallocated corporate expenses primarily consist of stock-based compensation expense of $2.2 million and $10.1 million for the three and nine months ended December 31, 2010, respectively.

[0001193125-12-048929:notes:119]
[same as prior period, unchanged from 0000950123-11-096966:notes:107]

[0001193125-12-048929:notes:120]
[same as prior period, unchanged from 0000950123-11-096966:notes:108]


## us-gaap:SubsequentEventsTextBlock

[0001193125-12-048929:notes:121]
14. Subsequent Events

[0001193125-12-048929:notes:122]
The Company has performed an evaluation of subsequent events through the time of filing this Quarterly Report on Form 10-Q with the SEC, and has determined that there are no such events that are required to be disclosed.
