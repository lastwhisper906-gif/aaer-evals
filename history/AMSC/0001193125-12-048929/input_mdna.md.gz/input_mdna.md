# AMSC MD&A — 0001193125-12-048929


## mdna

[0001193125-12-048929:mdna:1]
| ITEM 2. | MANAGEMENT’S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS |

[0001193125-12-048929:mdna:2]
21

[0001193125-12-048929:mdna:3]
result in an unfavorable outcome, which could have a material adverse effect on our business, operating results and financial condition; our technology and products could infringe intellectual
property rights of others, which may require costly litigation and, if we are not successful, could cause us to pay substantial damages and disrupt our business; our patents may not provide meaningful protection for our technology, which could
result in us losing some or all of our market position; third parties have or may acquire patents that cover the materials, processes and technologies we use or may use in the future to manufacture our Amperium products, and our success depends on
our ability to license such patents or other proprietary rights; and our common stock has experienced, and may continue to experience, significant market price and volume fluctuations, which may prevent our stockholders from selling our common stock
at a profit and could lead to costly litigation against us that could divert our management’s attention. These and the important factors discussed under the caption “Risk Factors” in Part II. Item 1A and Part 1.
Item 1A of our Form 10-K for the fiscal year ended March 31, 2011, among others, could cause actual results to differ materially from those indicated by forward-looking statements made herein and presented elsewhere by management from time
to time. Any such forward-looking statements represent management’s estimates as of the date of this Quarterly Report on Form 10-Q. While we may elect to update such forward-looking statements at some point in the future, we disclaim any
obligation to do so, even if subsequent events cause our views to change. These forward-looking statements should not be relied upon as representing our views as of any date subsequent to the date of this Quarterly Report on Form 10-Q.

[0001193125-12-048929:mdna:4]
AMSC, American Superconductor, Amperium, dSVC, DataPark, D-VAR, D-VAR-RT, FaultBlocker, Gridtec Solutions, PowerModule,
PowerPipelines, PQ-IVR, SafetyLock, SeaTitan, SolarTie, SuperGEAR, Wind-RT, Windtec, Windtec Solutions, wtCMS, wtSCADA, wtWPC, and “smarter, cleaner … better energy,” are trademarks or registered trademarks of American
Superconductor Corporation or its subsidiaries. All other brand names, product names, trademarks or service marks appearing in this Quarterly Report on Form 10-Q are the property of their respective holders.

[0001193125-12-048929:mdna:5]
[same as prior period, unchanged from 0000950123-11-096966:mdna:4]

[0001193125-12-048929:mdna:6]
American Superconductor Corporation (“AMSC”) was founded on April 9, 1987. We are a leading provider of megawatt-scale
solutions that lower the cost of wind power and enhance the performance of the power grid. In the wind power market, we enable manufacturers to field wind turbines through our advanced engineering, support services and power electronics products. In
the power grid market, we enable electric utilities and renewable energy project developers to connect, transmit and distribute power through our transmission planning services and power electronics and superconductor based products. Our wind and
power grid products and services provide exceptional reliability, security, efficiency and affordability to our customers.

[0001193125-12-048929:mdna:7]
Our wind and power grid solutions help to improve energy efficiency, alleviate power grid capacity constraints and increase the adoption
of renewable energy generation. Demand for our solutions is driven by the growing needs for renewable sources of electricity, such as wind and solar energy, and for modernized smart grids that improve power reliability and quality. Concerns about
these factors have led to increased spending by corporations as well as supportive government regulations and initiatives on local, state, national and global levels, including renewable portfolio standards, tax incentives and international
treaties.

[0001193125-12-048929:mdna:8]
We manufacture products using two proprietary core technologies: PowerModule™ programmable power electronic
converters and our Amperium™ HTS wires. These technologies and our system-level solutions are protected by a broad and deep intellectual property portfolio consisting of hundreds of patents and licenses worldwide.

[0001193125-12-048929:mdna:9]
We segment our business in two market-facing business units: Wind and Grid. We believe this market-centric structure enables us to more
effectively anticipate and meet the needs of wind turbine manufacturers, power generation project developers and electric utilities.

[0001193125-12-048929:mdna:10]
[same as prior period, unchanged from 0000950123-11-096966:mdna:9]

[0001193125-12-048929:mdna:11]
[same as prior period, unchanged from 0000950123-11-096966:mdna:10]

[0001193125-12-048929:mdna:12]
Our fiscal year begins on April 1 and ends on March 31. This document refers to
fiscal 2011, which is defined as the period beginning on April 1, 2011 and concluding on March 31, 2012. The third quarter of fiscal 2011 began on October 1, 2011 and concluded on December 31, 2011.

[0001193125-12-048929:mdna:13]
Our cash requirements depend on numerous factors, including successful completion of our product development activities, ability to
commercialize our product prototypes, rate of customer and market adoption of our products, collecting receivables according to established terms, and the continued availability of U.S. government funding during the product development phase.
Significant deviations to our business plan with regard to these factors, which are important drivers to our business, could have a material adverse effect on our operating performance, financial condition, and future business prospects. We expect
to pursue the expansion of our operations through internal growth and potential strategic alliances and acquisitions.

[0001193125-12-048929:mdna:14]
As of
December 31, 2011 and March 31, 2011, we had backlog of approximately $299.6 million and $228.4 million, respectively, excluding Sinovel. On March 31, 2011, Sinovel refused to accept contracted shipments of 1.5MW and 3MW wind turbine
core electrical components and spare parts that we were prepared to deliver. As a result, we have not made shipments to Sinovel since February 2011. Additionally, we are pursuing litigation against Sinovel for the theft of our intellectual property
(as discussed below). Consequently, our reported backlog excludes purchase contracts with Sinovel.

[0001193125-12-048929:mdna:15]
During March 2011, we
engaged in discussions with Sinovel regarding the acceptance of its scheduled shipments, outstanding receivables, and the delivery of a custom solution desired by Sinovel for low voltage ride through (“LVRT”) that required a
modification to our existing LVRT design. The custom design required modified software and additional hardware. Toward the end of March, Sinovel requested that we provide them with the additional hardware without additional cost. On
March 31, 2011, we proposed to Sinovel that we would provide the additional hardware without additional cost if Sinovel would accept the scheduled shipments. Sinovel rejected this proposal due to what we were told was excess inventory of our
components. Since Sinovel did not give us the requisite notice under our contracts that they intended to delay acceptance of deliveries, we believe that these actions constitute material breaches of our contracts.

[0001193125-12-048929:mdna:16]
As of the date of this filing, we have not received payment for any outstanding receivables nor have we been notified as to when, if
ever, Sinovel will accept contracted shipments that were scheduled for delivery after March 31, 2011. Additionally, based in part upon evidence obtained through an internal investigation and a criminal investigation conducted by Austrian
authorities regarding the actions of a former employee of our AMSC Austria subsidiary, we believe that Sinovel illegally obtained and used our intellectual property in violation of civil and criminal intellectual property laws. In July 2011, the
former employee was arrested in Austria and in September 2011, pled guilty to charges of economic espionage and fraudulent manipulation of data. The evidence presented during the court hearing showed that this former employee was contracted by
Sinovel through an intermediary while employed by us and improperly obtained and transferred to Sinovel portions of our wind turbine control software source code developed for Sinovel’s 1.5MW wind turbines. Except for portions of this 1.5MW
wind turbine software, we do not believe that the source code for any other turbines, such as the 3MW, 5MW and 6MW wind turbines that were designed by and co-developed with us have been transferred to Sinovel. Moreover, we believe the evidence shows
this former employee illegally used source code to develop for Sinovel a software modification to circumvent the encryption and remove technical protection measures on the PM3000 power converters in 1.5MW wind turbines in the field. We believe that
only the binary code, or upper layer, of the PM3000 software developed to circumvent the encryption and remove technical protection measures was transferred to Sinovel. We do not believe that any PM3000 source code was transferred to Sinovel. These
actions potentially enable Sinovel to deploy, independent of us, wind turbine control software, including a low voltage ride through solution, on all of its 1.5MW wind turbines in the field. In addition, by having the wind turbine control source
code, Sinovel could potentially modify the source code to allow the use of core electrical components, including power converters, from other manufacturers.

[0001193125-12-048929:mdna:17]
On September 13, 2011, we commenced a series of legal actions in China against Sinovel. We filed a claim for arbitration in Beijing, China to compel Sinovel to pay us for past product shipments and
to accept all contracted but not yet delivered core electrical components and spare parts under all existing contracts with us. The arbitration claim was filed with the Beijing Arbitration Commission in accordance with the terms of our supply
contracts with Sinovel. We have also filed civil and criminal complaints against Sinovel.

[0001193125-12-048929:mdna:18]
We cannot provide any assurance as
to the outcome of these legal actions. We are now operating our business under the assumption that Sinovel will not be a customer.

[0001193125-12-048929:mdna:19]
On September 16, 2011, we filed a civil complaint in China against Dalian Guotong Electric, Co., Ltd. and other parties. The complaints allege the illegal use of our intellectual property. We
are seeking to compel Sinovel and the other parties to cease and desist from infringing our intellectual property and are also seeking monetary damages to compensate us for our

[0001193125-12-048929:mdna:20]
economic losses resulting from the infringement. In December 2011, Sinovel filed a jurisdiction opposition motion requesting dismissal by the Hainan Province No. 1 Intermediate People’s
Court, saying the case should be governed by the Beijing Arbitration Commission. On February 3, 2012, we received the Civil Ruling from the court, which granted Sinovel’s motion, and dismissed the entire case. We plan to appeal the
court’s ruling.

[0001193125-12-048929:mdna:21]
[same as prior period, unchanged from 0000950123-11-096966:mdna:19]

[0001193125-12-048929:mdna:22]
The preparation of the unaudited condensed consolidated financial statements requires that we make estimates and judgments that affect the
reported amounts of assets, liabilities, revenues and expenses, and related disclosure of contingent assets and liabilities. We base our estimates on historical experience and various other assumptions that are believed to be reasonable under the
circumstances, the results of which form the basis for making judgments about the carrying values of assets and liabilities that are not readily apparent from other sources. Actual results may differ under different assumptions or conditions. There
were no significant changes in the third quarter of fiscal 2011 in the critical accounting policies that were disclosed in our Form 10-K for fiscal 2010, which ended on March 31, 2011.

[0001193125-12-048929:mdna:23]
[same as prior period, unchanged from 0000950123-11-096966:mdna:21]

[0001193125-12-048929:mdna:24]
Three and nine months ended December 31, 2011 compared to
the three and nine months ended December 31, 2010

[0001193125-12-048929:mdna:25]
Beginning on April 1, 2011, management revised its
reportable business segments into Wind and Grid as a result of changes in the manner in which we disaggregate the Company’s operations for making operating decisions and assessing performance of our business segments. Previously, we had two
reportable business segments: AMSC Power Systems and AMSC Superconductors. All prior period segment disclosures have been revised to conform to management’s current view of its business segments.

[0001193125-12-048929:mdna:26]
As discussed above, the loss of Sinovel as a customer has materially and adversely affected our business and results of operations.
Because Sinovel has accounted for more than two-thirds of our revenues over each of the past three fiscal years, we experienced significantly lower revenues and significant operating losses during the three and nine months ended December 31,
2011. Revenues to Sinovel represented 0% and 66% of total revenues for the three and nine months ended December 31, 2010, respectively. Since no cash payments were made by Sinovel in the three and nine months ended December 31, 2011, no
revenue was recognized from Sinovel in the three and nine months ended December 31, 2011.

[0001193125-12-048929:mdna:27]
[same as prior period, unchanged from 0000950123-11-096966:mdna:25]

[0001193125-12-048929:mdna:28]
Total revenues decreased by 43% and 79% to $18.1 million and $47.9 million for the three and nine months ended December 31, 2011,
respectively, compared to $31.6 million and $226.9 million for the three and nine months ended December 31, 2010, respectively. Our revenues are summarized as follows (in thousands):

[0001193125-12-048929:mdna:29]
|  |  | Three months endedDecember 31, |  |  | Nine months endedDecember 31, |  |
|  |  | 2011 |  |  | 2010 |  |  | 2011 |  |  | 2010 |  |
| Revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Wind |  | $ | 10,125 |  |  | $ | 10,840 |  |  | $ | 27,836 |  |  | $ | 183,162 |  |
| Grid |  |  | 7,933 |  |  |  | 20,730 |  |  |  | 20,080 |  |  |  | 43,691 |  |
| Total |  | $ | 18,058 |  |  | $ | 31,570 |  |  | $ | 47,916 |  |  | $ | 226,853 |  |

[0001193125-12-048929:mdna:30]
Our Wind business unit accounted for 56% and 58% of total revenues for the three and nine months ended
December 31, 2011, respectively, compared to 34% and 81% for the three and nine months ended December 31, 2010, respectively. Revenues in the Wind business unit decreased 7% and 85% to $10.1 million and $27.8 million in the three and nine
months ended December 31, 2011, respectively, from $10.8 million and $183.2 million in the three and nine months ended December 31, 2010, respectively. The decrease in Wind business unit revenues for the three months ended
December 31, 2011 was primarily due to lower Wind product sales in China. The decrease in Wind revenues for the nine months ended December 31, 2011 was primarily due to the loss of Sinovel as a customer, as described above.

[0001193125-12-048929:mdna:31]
Our Grid business unit accounted for 44% and 42% of total revenues for the three and nine months ended December 31, 2011,
respectively, compared to 66% and 19% for the three and nine months ended December 31, 2010, respectively. Revenues in the Grid business unit decreased 62% and 54% to $7.9 million and $20.1 million in the three and nine months ended
December 31, 2011, respectively, from $20.7 million and $43.7 million in the three and nine months ended December 31, 2010, respectively. The decrease in Grid business unit revenues for the three and nine months ended December 31,
2011 was due primarily to a large D-VAR sale in the three months ended December 31, 2010 and lower HTS product sales.

[0001193125-12-048929:mdna:32]
The following table sets forth customers who represented 10% or more of the Company’s
total revenues:

[0001193125-12-048929:mdna:33]
|  |  | Three months endedDecember 31, |  |  | Nine months endedDecember 31, |  |
|  |  | 2011 |  |  | 2010 |  |  | 2011 |  |  | 2010 |  |
| Inox Wind, Ltd. |  |  | 27 | % |  |  | < 10 | % |  |  | 21 | % |  |  | < 10 | % |
| Doosan Heavy Industries & Construction Co Ltd. |  |  | 12 | % |  |  | < 10 | % |  |  | 15 | % |  |  | < 10 | % |
| Ergon Energy Corporation Limited |  |  | 11 | % |  |  | — |  |  |  | < 10 | % |  |  | — |  |
| Vestas – Australian Wind Technology Ltd |  |  | < 10 | % |  |  | 44 | % |  |  | < 10 | % |  |  | < 10 | % |
| Hyundai Heavy Industries Co., Ltd. |  |  | < 10 | % |  |  | 10 | % |  |  | < 10 | % |  |  | < 10 | % |
| Shenyang Blower Works Group Co., Ltd. |  |  | < 10 | % |  |  | 11 | % |  |  | < 10 | % |  |  | < 10 | % |
| Sinovel Wind Co., Ltd |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 66 | % |

[0001193125-12-048929:mdna:34]
Revenues from significant government-funded contracts are summarized as follows (in thousands):

[0001193125-12-048929:mdna:35]
| Project name |  | Expected totalcontract value |  |  | Revenue earnedthroughDecember 31, 2011 |  |  | Three months endedDecember 31, |  |  | Nine months endedDecember 31, |  |
|  |  |  | 2011 |  |  | 2010 |  |  | 2011 |  |  | 2010 |  |
| HYDRA |  | $ | 29,043 |  |  | $ | 11,760 |  |  | $ | 511 |  |  | $ | 112 |  |  | $ | 1,208 |  |  | $ | 621 |  |
| LIPA I and II |  |  | 40,141 |  |  |  | 39,900 |  |  |  | 116 |  |  |  | 861 |  |  |  | 1,500 |  |  |  | 3,009 |  |
| DOE-FCL |  |  | 7,898 |  |  |  | 6,962 |  |  |  | 95 |  |  |  | 571 |  |  |  | 409 |  |  |  | 1,558 |  |
| NAVSEA Motor Study |  |  | 6,511 |  |  |  | 6,492 |  |  |  | — |  |  |  | 103 |  |  |  | — |  |  |  | 252 |  |
| Total |  | $ | 83,593 |  |  | $ | 65,114 |  |  | $ | 722 |  |  | $ | 1,647 |  |  | $ | 3,117 |  |  | $ | 5,440 |  |

[0001193125-12-048929:mdna:36]
These projects represented 9% and 16% of the Grid business unit revenues for the three and nine months
ended December 31, 2011, respectively, compared to 8% and 12% for the three and nine months ended December 31, 2010, respectively.

[0001193125-12-048929:mdna:37]
Project HYDRA is a contract with Consolidated Edison, Inc. which is being partially funded by the U.S. Department of Homeland Security (“DHS”). DHS is expected to invest up to a total of $29.0
million in the development of a new high temperature superconductor power grid technology called FaultBlocker™ cable systems. FaultBlocker cable systems are designed to utilize customized Amperium™ HTS wires, and ancillary controls to
deliver more power through the grid while also being able to suppress power surges that can disrupt service. On September 15, 2011, DHS committed an additional $4.1 million in funding on Project HYDRA. Of the total $29.0 million in funding
expected from DHS, it has committed funding of $15.6 million to us as of December 31, 2011. Consolidated Edison and Southwire Company are subcontractors to us on this project.

[0001193125-12-048929:mdna:38]
LIPA II is a project to install an HTS power cable utilizing our Amperium™ wire for the Long Island Power Authority. DOE-FCL is a
project to develop and demonstrate a transmission voltage SuperLimiter fault current limiter (“FCL”). The NAVSEA Motor Study is a project designed to test the 36.5 MW superconductor motor developed for the U.S. Navy.

[0001193125-12-048929:mdna:39]
25

[0001193125-12-048929:mdna:40]
[same as prior period, unchanged from 0000950123-11-096966:mdna:39]

[0001193125-12-048929:mdna:41]
Cost of revenues decreased by 40% and 61% to $18.9 million and $57.8 million for the three and nine months ended December 31, 2011,
compared to $31.5 million and $149.2 million for the three and nine months ended December 31, 2010. Gross margin was (5%) and (21%) for the three and nine months ended December 31, 2011, respectively, compared to 0% and 34% for
the three and nine months ended December 31, 2010, respectively. The decrease in gross margin in the three months ended December 31, 2011 compared to the same period in fiscal 2010 was due primarily to lower sales volume resulting in
unabsorbed fixed costs. The decrease in gross margin for the nine months ended December 31, 2011 as compared to the same period in fiscal 2010 was primarily a result of lower sales due to the loss of Sinovel as a customer and unabsorbed fixed
overhead due to idle capacity. This is expected to improve in the future quarters as the wind market in China recovers.

[0001193125-12-048929:mdna:42]
Operating
Expenses

[0001193125-12-048929:mdna:43]
[same as prior period, unchanged from 0000950123-11-096966:mdna:44]

[0001193125-12-048929:mdna:44]
A portion of our R&D expenditures related to externally funded development contracts has been classified as cost of revenues (rather than as R&D expenses). Additionally, a portion of R&D
expenses was offset by cost-sharing funding. Our R&D expenditures are summarized as follows (in thousands):

[0001193125-12-048929:mdna:45]
|  |  | Three months endedDecember 31, |  |  | Nine months endedDecember 31, |  |
|  |  | 2011 |  |  | 2010 |  |  | 2011 |  |  | 2010 |  |
| R&D expenses per condensed consolidated statements of operations |  | $ | 5,928 |  |  | $ | 8,417 |  |  | $ | 21,339 |  |  | $ | 23,610 |  |
| R&D expenditures reclassified as cost of revenues |  |  | 2,480 |  |  |  | 3,862 |  |  |  | 9,782 |  |  |  | 11,582 |  |
| R&D expenditures offset by cost-sharing funding |  |  | 42 |  |  |  | 128 |  |  |  | 123 |  |  |  | 402 |  |
| Aggregated R&D expenses |  | $ | 8,450 |  |  | $ | 12,407 |  |  | $ | 31,244 |  |  | $ | 35,594 |  |

[0001193125-12-048929:mdna:46]
R&D expenses (exclusive of amounts classified as cost of revenues and amounts offset by cost-sharing
funding) decreased by 30% and 10% to $5.9 million and $21.3 million for the three and nine months ended December 31, 2011, respectively, from $8.4 million and $23.6 million for the three and nine months ended December 31, 2010,
respectively. Lower R&D expenditures for the three and nine months ended December 31, 2011 were primarily due to the impact of our cost reduction activities. The decrease in R&D expenditures reclassified to costs of revenue was a result
of decreased efforts under license and development contracts for wind turbine designs compared to the prior year. Aggregated R&D expenses, which include amounts classified as cost of revenues and amounts offset by cost-sharing funding, decreased
32% and 12% to $8.5 million and $31.2 million, or 47% and 65% of revenues for the three and nine months ended December 31, 2011, respectively, compared to $12.4 million and $35.6 million, or 39% and 16% of revenues, for the three and nine
months ended December 31, 2010, respectively. R&D expenses are expected to decline year over year for the next several quarters as a result of the restructuring actions undertaken in fiscal 2011.

[0001193125-12-048929:mdna:47]
We present aggregated R&D, which is a non-GAAP measure, because we believe this presentation provides useful information on our
aggregate R&D spending and because R&D expenses as reported on the unaudited condensed consolidated statements of income have been, and may in the future, be subject to significant fluctuations solely as a result of changes in the level of
externally funded contract development work, resulting in significant changes in the amount of the costs recorded as costs of revenues rather than as R&D expenses, as discussed above.

[0001193125-12-048929:mdna:48]
[same as prior period, unchanged from 0000950123-11-096966:mdna:49]

[0001193125-12-048929:mdna:49]
SG&A expenses increased by 9% and
18% to $15.4 million and $55.0 million, or 85% and 115% of revenues, for the three and nine months ended December 31, 2011, respectively, from $14.2 million and $46.7 million, or 45% and 21% of revenues, for each of the three and nine months
ended December 31, 2010, respectively.

[0001193125-12-048929:mdna:50]
The increases in SG&A expenses were due primarily to increases in legal fees
associated with ongoing litigation as discussed in Part II, Item 1, “Legal Proceedings,” of this Quarterly Report on Form 10-Q. During the three and nine months ended December 31, 2011, we incurred $2.4 million and $5.8
million, respectively, in legal fees related to Sinovel litigation. Going forward, we expect litigation expenses for Sinovel to be reduced as compared to the amount incurred in the third quarter.

[0001193125-12-048929:mdna:51]
[same as prior period, unchanged from 0000950123-11-096966:mdna:51]

[0001193125-12-048929:mdna:52]
In October 2011, we terminated our previously planned acquisition of The Switch due to adverse market conditions for a financing required to fund the acquisition. As a result, The Switch retained a $20.6
million advance payment as a break-up fee, and we recorded a write-off of the advance payment during the nine months ended December 31, 2011.

[0001193125-12-048929:mdna:53]
[same as prior period, unchanged from 0000950123-11-096966:mdna:53]

[0001193125-12-048929:mdna:54]
We recorded amortization
expense related to our core technology and know-how, trade names and trademark intangible assets of $0.3 million and $0.9 million in the three and nine months ended December 31, 2011, respectively, compared to $0.4 million and $1.2 million in
the three and nine months ended December 31, 2010. These intangible assets are primarily a result of our AMSC Windtec acquisition.

[0001193125-12-048929:mdna:55]
[same as prior period, unchanged from 0000950123-11-096966:mdna:55]

[0001193125-12-048929:mdna:56]
We recorded restructuring and impairment charges of $4.1 million and $8.4 million in the three and nine months ended December 31, 2011, respectively. These amounts consist primarily of a long-lived
asset impairment of $1.7 million recorded in the three months ended December 31, 2011. In addition, for the three and nine months ended December 31, 2011, these amounts include employee severance and benefit costs related to the
restructuring plan of $2.2 million and $5.4 million, respectively, and impairment charges on long-lived assets for which there is no remaining future economic benefit as of December 31, 2011 of $0.1 million and $1.1 million, respectively.
Finally, for the nine months ended December 31, 2011, the Company recorded facility exit costs of $0.1 million associated with portions of the leased space in Klagenfurt, Austria

[0001193125-12-048929:mdna:57]
Operating (loss) income

[0001193125-12-048929:mdna:58]
Our operating (loss) income is summarized
as follows (in thousands):

[0001193125-12-048929:mdna:59]
|  |  | Three months endedDecember 31, |  |  | Nine months endedDecember 31, |  |
|  |  | 2011 |  |  | 2010 |  |  | 2011 |  |  | 2010 |  |
| Operating (loss) income: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Wind |  | ($ | 14,014 | ) |  | ($ | 12,494 | ) |  | ($ | 54,719 | ) |  | $ | 51,499 |  |
| Grid |  |  | (6,313 | ) |  |  | (8,189 | ) |  |  | (24,511 | ) |  |  | (35,166 | ) |
| Unallocated corporate expenses |  |  | (6,242 | ) |  |  | (2,277 | ) |  |  | (36,790 | ) |  |  | (10,135 | ) |
| Total |  | ($ | 26,569 | ) |  | ($ | 22,960 | ) |  | ($ | 116,020 | ) |  | $ | 6,198 |  |

[0001193125-12-048929:mdna:60]
Operating loss for the Wind business unit increased to $14.0 million in the three months ended
December 31, 2011 compared to $12.5 million in the three months ended December 31, 2010. Operating (loss) income for the Wind business unit decreased to an operating loss of $54.7 million in the nine months ended December 31, 2011,
compared to operating income of $51.5 million in the nine months ended December 31, 2010. For the three months ended December 31, 2011 the increase in operating loss was primarily due to a lower revenues and legal expenses associated with
the Sinovel litigation. For the nine months ended December 31, 2011, the decrease in Wind business unit operating income was primarily due to the loss of Sinovel as a customer, as described above.

[0001193125-12-048929:mdna:61]
Operating loss for the Grid business unit decreased to $6.3 million in the three months ended December 31, 2011, from $8.2 million
in the three months ended December 31, 2010. Operating loss for the Grid business unit decreased to $24.5 million in the nine months ended December 31, 2011 from $35.2 million in the nine months ended December 31, 2010. The decreases
in Grid business unit operating loss were primarily due to lower operating expenses as a result of the reductions in force, reduced discretionary spending and changes to corporate allocations, partially offset by reduced D-VAR revenues.

[0001193125-12-048929:mdna:62]
27

[0001193125-12-048929:mdna:63]
For the three and nine months ended December 31, 2011, unallocated corporate expenses
primarily consist of restructuring and impairment charges of $4.1 million and $8.4 million, respectively, and stock-based compensation expense of $2.1 million and $7.7 million, respectively. In addition, the nine months ended December 31, 2011
includes expense of $20.6 million for the write-off of an advance payment to The Switch. Unallocated corporate expenses for the three and nine months ended December 31, 2010, primarily consist of stock-based compensation expense of $2.2 million
and $10.1 million respectively.

[0001193125-12-048929:mdna:64]
Interest (expense) income, net

[0001193125-12-048929:mdna:65]
Interest (expense) income, net, was an expense of less than $0.1 million and income of $0.2 million in the three and nine months ended
December 31, 2011, respectively, compared to income of $0.2 million and $0.5 million in the three and nine months ended December 31, 2010, respectively. The decreases are due primarily to lower interest-bearing cash balances.

[0001193125-12-048929:mdna:66]
[same as prior period, unchanged from 0000950123-11-096966:mdna:65]

[0001193125-12-048929:mdna:67]
Other income, net, was $0.4 million and $1.3 million in the three and nine months ended December 31, 2011, respectively, compared to
$2.1 million and $4.7 million for the three and nine months ended December 31, 2010. The decrease in other income, net, for the three months ended December 31, 2011, primarily relates to a decrease in foreign currency gains of $1.9
million. For the nine months ended December 31, 2011, the decrease in other income, net primarily relates to a decrease in foreign currency gains of $2.8 million and an increase in losses on minority interest investments of $0.3 million.

[0001193125-12-048929:mdna:68]
[same as prior period, unchanged from 0000950123-11-096966:mdna:68]

[0001193125-12-048929:mdna:69]
In the three and nine months ended December 31, 2011, we recorded income tax expense of less than $0.1 million and $1.2 million, respectively, compared to an income tax benefit of $2.5 million and an
income tax expense of $12.6 million in the three and nine months ended December 31, 2010. Income tax expense decreased primarily due to the pretax losses in the three and nine months ended December 31, 2011 with a full valuation allowance
applied to these deferred tax assets. We have provided a valuation allowance against all deferred tax assets as of December 31, 2011, as it is more likely than not that our deferred tax assets are not currently realizable due to the net
operating losses incurred since our inception in the U.S. and the significant write-offs in certain foreign jurisdictions in the fiscal year ended March 31, 2011 and the losses forecasted in certain foreign jurisdictions in the future.

[0001193125-12-048929:mdna:70]
[same as prior period, unchanged from 0000950123-11-096966:mdna:70]

[0001193125-12-048929:mdna:71]
Generally, a non-GAAP financial measure is a numerical measure of a company’s performance, financial position or cash flow that either excludes or includes amounts that are not normally excluded or
included in the most directly comparable measure calculated and presented in accordance with GAAP. The non-GAAP measures included in this Form 10-Q, however, should be considered in addition to, and not as a substitute for or superior to the
comparable measure prepared in accordance with GAAP.

[0001193125-12-048929:mdna:72]
We define non-GAAP net (loss) income as net (loss) income before amortization of
acquisition-related intangibles, restructuring and impairments, stock-based compensation, other unusual charges and any tax effects related to these items. We believe non-GAAP net (loss) income assists management and investors in comparing our
performance across reporting periods on a consistent basis by excluding these non-cash or non-recurring charges that we do not believe are indicative of our core operating performance. We also regard non-GAAP net (loss) income as a useful measure of
operating performance which more closely aligns net (loss) income with cash used in/provided by continuing operations. In addition, we use non-GAAP net (loss) income as a factor in evaluating management’s performance when determining incentive
compensation and to evaluate the effectiveness of our business strategies. A reconciliation of non-GAAP to GAAP net (loss) income is set forth in the table below (in thousands, except per share data):

[0001193125-12-048929:mdna:73]
|  |  | Three months endedDecember 31, |  |  | Nine months endedDecember 31, |  |
|  |  | 2011 |  |  | 2010 |  |  | 2011 |  |  | 2010 |  |
| Net loss |  | $ | (26,271 | ) |  | $ | (18,158 | ) |  | $ | (115,660 | ) |  | $ | (1,150 | ) |
| Write-off of advance payment |  |  | — |  |  |  | — |  |  |  | 20,551 |  |  |  | — |  |
| Stock-based compensation |  |  | 2,118 |  |  |  | 2,249 |  |  |  | 7,697 |  |  |  | 10,073 |  |
| Restructuring and impairment charges |  |  | 4,092 |  |  |  | — |  |  |  | 8,393 |  |  |  | — |  |
| Executive severance |  |  | — |  |  |  | — |  |  |  | 2,066 |  |  |  | — |  |
| Sinovel litigation |  |  | 2,423 |  |  |  | — |  |  |  | 5,757 |  |  |  | — |  |
| Provision for excess and obsolete inventory |  |  | — |  |  |  | 2,087 |  |  |  | — |  |  |  | 2,667 |  |
| Adverse purchase commitment (recoveries) losses, net |  |  | (94 | ) |  |  | — |  |  |  | 73 |  |  |  | — |  |
| Margin on zero cost-basis inventory |  |  | (46 | ) |  |  | — |  |  |  | (173 | ) |  |  | — |  |
| Value-added tax write-off |  |  | — |  |  |  | 118 |  |  |  | — |  |  |  | 550 |  |
| Amortization of acquisition-related intangibles |  |  | 287 |  |  |  | 392 |  |  |  | 891 |  |  |  | 1,154 |  |
| Tax effects |  |  | — |  |  |  | (88 | ) |  |  | — |  |  |  | (255 | ) |
| Non-GAAP net (loss) income |  | $ | (17,491 | ) |  | $ | (13,400 | ) |  | $ | (70,405 | ) |  | $ | 13,039 |  |
| Non-GAAP (loss) earnings per share |  | $ | (0.34 | ) |  | $ | (0.28 | ) |  | $ | (1.39 | ) |  | $ | 0.28 |  |
| Weighted average shares outstanding * |  |  | 50,933 |  |  |  | 48,068 |  |  |  | 50,789 |  |  |  | 46,017 |  |

[0001193125-12-048929:mdna:74]
| * | Diluted shares are used for periods where net income is generated. |

[0001193125-12-048929:mdna:75]
We incurred non-GAAP net losses of $17.5 million and $70.4 million, or ($0.34) and ($1.39) per share, for the three months and nine months ended December 31, 2011, compared to non-GAAP net loss of
$13.4 million, or ($0.28) per share and non-GAAP net income of $13.0 million, or $0.28 per diluted share, for the three and nine months ended December 31, 2010. The higher non-GAAP net losses were driven primarily by an increase in net loss as
described above and decreases in stock-based compensation and provisions for excess and obsolete inventory related to certain customers in China, partially offset by add backs for the write-off of the advance payment to The Switch, Sinovel
litigation expenses and restructuring and impairment charges.

[0001193125-12-048929:mdna:76]
[same as prior period, unchanged from 0000950123-11-096966:mdna:76]

[0001193125-12-048929:mdna:77]
At December 31, 2011, we had cash, cash equivalents, marketable securities and restricted cash of $75.5 million, compared to $245.5
million at March 31, 2011, a decrease of $170.0 million. Our cash and cash equivalents, marketable securities and restricted cash are summarized as follows (in thousands):

[0001193125-12-048929:mdna:78]
|  |  | December 31,2011 |  |  | March 31,2011 |  |
| Cash and cash equivalents |  | $ | 58,605 |  |  | $ | 123,783 |  |
| Marketable securities |  |  | 5,261 |  |  |  | 116,126 |  |
| Restricted cash |  |  | 11,589 |  |  |  | 5,566 |  |
| Total cash, cash equivalents, marketable securities and restricted cash |  | $ | 75,455 |  |  | $ | 245,475 |  |

[0001193125-12-048929:mdna:79]
For the nine months ended December 31, 2011, net cash used in operating activities was $133.3
million compared to $16.0 million in the nine months ended December 31, 2010. The increase in net cash used in operations is due primarily to an increase in net loss of $114.5 million and an increase in cash used for working capital of $32.2
million, partially offset by the write-off of the advance payment to The Switch of $20.6 million, net restructuring charges of $2.7 million, impairment charges of $2.8 million and deferred income taxes of $3.9 million.

[0001193125-12-048929:mdna:80]
For the nine months ended December 31, 2011, net cash provided by investing activities was $68.3 million compared to net cash used
in investing activities of $64.8 million in the nine months ended December 31, 2010. The increase in net cash provided by investing activities for the nine months ended December 31, 2011 was driven primarily by an increase in net
maturities and sales of marketable securities of $135.0 million, a decrease in capital expenditures of $21.4 million and decrease in purchased minority investments of $6.2 million, partially offset by the $20.6 million advance payment to The Switch
and an increase in restricted cash of $6.3 million.

[0001193125-12-048929:mdna:81]
For the nine months ended December 31, 2011, net cash used in
financing activities was $0.1 million compared to cash provided by financing activities of $162.6 million in the nine months ended December 31, 2010. The decrease in net cash provided by financing activities is primarily due to a decrease in
proceeds from public offering of $155.2 million, a decrease from exercise of employee stock options and ESPP of $7.2 million and payments in lieu of issuance of common stock for payroll taxes of $0.3 million.

[0001193125-12-048929:mdna:82]
As of December 31, 2011, we had two performance bonds in support of customer contracts.
The total value of the outstanding performance bonds is $0.4 million with expiration dates through October 2012. In the event that the payment is made in accordance with the requirements of any of these performance bonds, we would record the payment
as an offset to revenue.

[0001193125-12-048929:mdna:83]
At December 31, 2011, the Company had $9.0 million of restricted cash included in current
assets and $2.5 million of restricted cash included in long-term assets. These amounts included in restricted cash represent deposits to secure letters of credit for various supply contracts. These deposits are held in interest bearing accounts

[0001193125-12-048929:mdna:84]
We had unused, unsecured lines of credit consisting of €2.3 million (approximately $3.0 million) in Austria as of
December 31, 2011. During the nine months ended December 31, 2011, our unsecured credit line with the Bank of China expired and we repaid borrowings on lines of credit of $4.6 million. There were no borrowings outstanding as of
December 31, 2011.

[0001193125-12-048929:mdna:85]
Our business plan anticipates a substantial use of cash from operations in our fiscal year ending
March 31, 2012 in light of the difficult and uncertain current economic environment in China, the significant restructuring actions undertaken and the slowdown in the Chinese wind power market, which has accounted for more than two-thirds of
our revenues in recent fiscal years. At December 31, 2011, we had accrued liabilities related to adverse purchase commitments for inventory totaling $28.8 million. From April 1, 2011 through the date of this filing, we have reduced our
global workforce by approximately 50%, which is expected to result in annual savings of approximately $50 million. As of December 31, 2011, we have a global workforce of over 400 persons. Our cost reduction efforts and anticipated revenue
growth are expected to result in a substantial reduction in cash used for operations during the fiscal year ended March 31, 2013. We plan to continue to closely monitor our expenses and if required, will further reduce operating costs and
capital spending to enhance liquidity. We are working with our inventory suppliers to delay cash settlements and, reduce the gross liability associated with our adverse purchase commitments. We believe that our available cash, together with
additional reductions in operating costs and capital expenditures as necessary, will be sufficient to fund our operations, capital expenditures and other cash requirements for the next twelve months. To bolster our long-term liquidity, we intend to
seek financing through means that may include public and private equity offerings, debt financings, and other financing alternatives. However, there can be no assurance that financing will be available on commercially acceptable terms or at all. Our
liquidity is highly dependent on our ability to profitably grow revenues, successfully manage our adverse purchase order commitments and raise additional capital as required.

[0001193125-12-048929:mdna:86]
Between April 6, 2011 and May 12, 2011, seven putative securities class action complaints were filed against us and two of our officers in the United States District Court for the District of
Massachusetts; one complaint additionally asserted claims against the underwriters who participated in our November 12, 2010 securities offering. On June 7, 2011, the United States District Court for the District of Massachusetts
consolidated these actions under the caption Lenartz v. American Superconductor Corporation, et al., Docket No. 1:11-cv-10582-WGY. On August 31, 2011, Lead Plaintiff, the Plumbers and Pipefitters National Pension Fund, filed a
consolidated amended complaint against us, our officers and directors, and the underwriters who participated in our November 12, 2010 securities offering, asserting claims under sections 10(b) and 20(a) of the Securities Exchange Act of 1934
and Rule 10b-5 promulgated under the Securities Exchange Act of 1934, as well as under sections 11, 12(a)(2) and 15 of the Securities Act of 1933. The complaint alleges that during the relevant class period, we and our officers omitted to state
material facts and made materially false and misleading statements relating to, among other things, our projected and recognized revenues and earnings, as well as our relationship with Sinovel Wind Group Co., Ltd. that artificially inflated the
value of our stock price. The complaint further alleges that our November 12, 2010 securities offering contained untrue statements of material facts and omitted to state material facts required to be stated therein. The plaintiffs seek
unspecified damages, rescindment of our November 12, 2010 securities offering, and an award of costs and expenses, including attorney’s fees.

[0001193125-12-048929:mdna:87]
Between May 4, 2011 and June 17, 2011, four putative shareholder derivative complaints were filed against us (as a nominal defendant) and certain of our directors in the United States District
Court for the District of Massachusetts. On July 5, 2011, the District Court consolidated three of these actions, and that matter is now captioned In re American Superconductor Corporation Derivative Litigation, Docket
No. 1:11-cv-10784-WGY. On June 1, 2011, the plaintiff in the fourth action, Marlborough Family Revocable Trust v. Yurek, et al., moved to voluntarily dismiss its complaint and refiled its complaint in Superior Court for the
Commonwealth of Massachusetts, Middlesex County. On September 7, 2011, the Marlborough action and another putative shareholder derivative complaint filed in Superior Court for the Commonwealth of Massachusetts were
consolidated. That consolidated matter is captioned Marlborough Family Revocable Trust v. Yurek, et al., Docket No. 11-1961. On January 12, 2012, an additional shareholder derivative complaint was filed in the Court of
Chancery for the State of Delaware. That matter is captioned Krasnoff v. Budhraja, et al., Docket No. 7171. The allegations of the derivative

[0001193125-12-048929:mdna:88]
complaints mirror the allegations made in the putative class action complaints described above. The plaintiffs purport to assert claims against the director defendants for breach of
fiduciary duty, abuse of control, gross mismanagement and corporate waste. The plaintiffs seek unspecified damages on behalf of us, as well as an award of costs and expenses, including attorney’s fees.

[0001193125-12-048929:mdna:89]
If a matter is both probable to result in liability and the amounts of loss can be reasonably estimated, we estimate and disclose the
possible loss or range of loss. With respect to the above referenced litigation matters, such an estimate cannot be made. There are numerous factors that make it difficult to meaningfully estimate possible loss or range of loss at this stage of
these litigation matters, including that: the proceedings are in relatively early stages, there are significant factual and legal issues to be resolved, information obtained or rulings made during the lawsuits could affect the methodology for
calculation of rescission and the related statutory interest rate. In addition, with respect to claims where damages are the requested relief, no amount of loss or damages has been specified. Therefore, we are unable at this time to estimate
possible losses. We believe that these litigations are without merit, and we intend to defend these actions vigorously.

[0001193125-12-048929:mdna:90]
On
September 13, 2011, we commenced a series of legal actions in China against Sinovel Wind Group Co. Ltd. (“Sinovel”). Our Chinese subsidiary, Suzhou AMSC Superconductor Co. Ltd., filed a claim for arbitration with the Beijing
Arbitration Commission in accordance with the terms of our supply contracts with Sinovel. The case is captioned (2011) Jin Zhong An Zi No. 0693. On March 31, 2011, Sinovel refused to accept contracted shipments of 1.5 megawatt
(MW) and 3 MW wind turbine core electrical components and spare parts that we were prepared to deliver. We allege that these actions constitute material breaches of our contracts because Sinovel did not give us notice that it intended to delay
deliveries as required under the contracts. Moreover, we allege that Sinovel has refused to pay past due amounts for prior shipments of core electrical components and spare parts. We are seeking compensation for past product shipments (including
interest) and monetary damages in the amount of approximately RMB 430 million ($67 million) due to Sinovel’s breaches of our contracts. We are also seeking specific performance of our existing contracts as well as reimbursement of all
costs and reasonable expenses with respect to the arbitration. The value of the undelivered components under the existing contracts, including the deliveries refused by Sinovel in March 2011, amounts to approximately RMB 4.6 billion ($720 million).

[0001193125-12-048929:mdna:91]
On October 8, 2011, Sinovel filed with the Beijing Arbitration Commission an application under the caption
(2011) Jing Zhong An Zi No. 0693, for a counterclaim against the Company for breach of the same contracts under which the Company filed its original arbitration claim. Sinovel claimed, among other things, that the goods supplied by
the Company do not conform to the standards specified in the contracts and claimed damages in the amount of approximately RMB 370 million ($58 million). On October 17, 2011, Sinovel filed with the Beijing Arbitration Commission a request
for change of counterclaim to increase its damage claim to approximately RMB 1 billion ($157 million). On December 22, 2011, Sinovel filed with the Beijing Arbitration Commission an additional request for change of counterclaim to increase its
damages claim to approximately RMB 1.2 billion ($190 million). Deducting the RMB 430 million ($67 million) of past product shipments claimed by the Company, the net amount of damages claimed by Sinovel is approximately RMB 770 million
($120 million). We believe that Sinovel’s claims are without merit and we intend to defend these actions vigorously. Since the proceedings in this matter are in relatively early stages, we cannot reasonably estimate possible losses or range of
losses at this time.

[0001193125-12-048929:mdna:92]
We also submitted a civil action application to the Beijing No. 1 Intermediate People’s Court
under the caption (2011) Yi Zhong Min Chu Zi No. 15524, against Sinovel for software copyright infringement on September 13, 2011. The application alleges Sinovel’s unauthorized use of portions of our wind turbine control
software source code developed for Sinovel’s 1.5MW wind turbines and the binary code, or upper layer, of our software for the PM3000 power converters in 1.5MW wind turbines. In July 2011, a former employee of our AMSC Windtec GmbH subsidiary
was arrested in Austria on charges of economic espionage and fraudulent manipulation of data. In September 2011, the former employee pled guilty to the charges, and he is currently serving a prison sentence. As a result of our internal investigation
and a criminal investigation conducted by Austrian authorities, we believe that this former employee was contracted by Sinovel through an intermediary while employed by us and improperly obtained and transferred to Sinovel portions of our wind
turbine control software source code developed for Sinovel’s 1.5MW wind turbines. Moreover, we believe the former employee illegally used source code to develop for Sinovel a software modification to circumvent the encryption and remove
technical protection measures on the PM3000 power converters in 1.5MW wind turbines in the field. We are seeking a cease and desist order with respect to the unauthorized copying, installation and use of our software, monetary damages of
approximately RMB 38 million ($6 million) for our economic losses and reimbursement of all costs and reasonable expenses. The No. 1 Intermediate People’s Court accepted the case, which was necessary in order for the case to proceed.
In November 2011, Sinovel filed a motion to remove this case from the Beijing No. 1 Intermediate People’s Court and transfer the matter to the Beijing Arbitration Commission. We are awaiting the court’s decision.

[0001193125-12-048929:mdna:93]
31

[0001193125-12-048929:mdna:94]
We submitted a civil action application to the Beijing Higher People’s Court against
Sinovel and certain of its employees for trade secret infringement on September 13 2011 under the caption (2011) Gao Min Chu Zi No. 4193. The application alleges the defendants’ unauthorized use of portions of our wind
turbine control software source code developed for Sinovel’s 1.5MW wind turbines as described above with respect to the Copyright Action. We are seeking monetary damages of RMB 2.9 billion ($453 million) for the trade secret infringement as
well as reimbursement of all costs and reasonable expenses. The Beijing Higher People’s Court accepted the case, which was necessary in order for the case to proceed. On December 22, 2011 the Beijing Higher People’s Court transferred
this case to the Beijing No. 1 Intermediate People’s Court under the caption (2011) Gao Min Chu Zi No. 4193. We are currently awaiting notice from the Beijing No. 1 Intermediate People’s Court regarding the
evidence submission deadline and the first hearing date.

[0001193125-12-048929:mdna:95]
On September 16, 2011, we filed a civil copyright infringement
complaint in the Hainan Province No. 1 Intermediate People’s Court against Dalian Guotong Electric Co. Ltd. (“Guotong”), a supplier of power converter products to Sinovel, and Huaneng Hainan Power, Inc. (“Huaneng”), a
wind farm operator that has purchased Sinovel wind turbines containing Guotong power converter products. The case is captioned (2011) Hainan Yi Zhong Min Chu Zi No. 62. The application alleges that our PM1000 converters in certain
Sinovel wind turbines have been replaced by converters produced by Guotong. Because the Guotong converters are being used in wind turbines containing our wind turbine control software, we believe that our copyrighted software is being infringed. We
are seeking a cease and desist order with respect to the unauthorized use of our software, monetary damages of RMB 1.2 million ($0.2 million) for our economic losses (with respect to Guotong only) and reimbursement of all costs and reasonable
expenses. The court has accepted the case, which was necessary in order for the case to proceed. In addition, upon the request of the defendant Huaneng, Sinovel has been added by the court to this case as a defendant and Huaneng has been released
from this case. In December 2011, Sinovel filed a jurisdiction opposition motion requesting dismissal by the Hainan Province No. 1 Intermediate People’s Court, saying the case should be governed by the Beijing Arbitration Commission. On
February 3, 2012, we received the Civil Ruling from the court, which granted Sinovel’s motion, and dismissed the entire case. We plan to appeal the court’s ruling.

[0001193125-12-048929:mdna:96]
Ghodawat Energy Pvt Ltd (“Ghodawat”), a company registered in India carrying on the business of wind power development, lodged
a Request for Arbitration with the Secretariat of the ICC International Court of Arbitration on May 12, 2011 and named AMSC Windtec GmbH (“AMSC Windtec”) as the Respondent. Under the Request for Arbitration, Ghodawat alleges that AMSC
Windtec breached an agreement dated March 19, 2008 pursuant to which AMSC Windtec granted a license to Ghodawat to manufacture, use, sell, market, erect, commission and maintain certain wind turbines using its technical information and wind
turbine design (the “License Agreement”). Under the Request for Arbitration, Ghodawat’s claims in this arbitration amount to approximately €18 million ($24 million). AMSC Windtec filed an Answer to Request for
Arbitration and Counterclaim (“Answer and Counterclaim”), in which AMSC Windtec denied Ghodawat’s claims in their entirety. AMSC Windtec has also submitted counterclaims under the License Agreement against Ghodawat in the amount
of approximately €6 million ($9 million). Ghodawat has filed a Reply to Answer to Request for Arbitration and Counterclaim in which it denies AMSC Windtec’s counterclaims. The arbitration proceedings are currently ongoing. We
have recorded a loss contingency based on our assessment of probable losses on this claim, however this amount is immaterial to our consolidated financial statements.

[0001193125-12-048929:mdna:97]
[same as prior period, unchanged from 0000950123-11-096966:mdna:98]

[0001193125-12-048929:mdna:98]
We do not have any off-balance sheet
arrangements, as defined under SEC rules, such as relationships with unconsolidated entities or financial partnerships, which are often referred to as structured finance or special purpose entities, established for the purpose of facilitating
transactions that are not required to be reflected on our balance sheet except as discussed below.

[0001193125-12-048929:mdna:99]
We occasionally enter into
construction contracts that include a performance bond. As these contracts progress, we continually assess the probability of a payout from the performance bond. Should we determine that such a payout is probable, we would record a liability.

[0001193125-12-048929:mdna:100]
In addition, the Company has various contractual arrangements in which minimum quantities of goods or services have been
committed to be purchased on an annual basis.

[0001193125-12-048929:mdna:101]
[same as prior period, unchanged from 0000950123-11-096966:mdna:102]

[0001193125-12-048929:mdna:102]
In December 2010, the FASB issued Accounting Standards Update (ASU) No. 2010-29, Business Combinations (Topic 805), Disclosure of
Supplementary Pro forma Information for Business Combinations a consensus of the FASB Emerging Issues Task Force (ASC 2010-29). This amendment clarifies the periods for which pro forma financial information is

[0001193125-12-048929:mdna:103]
presented. The disclosures include pro forma revenue and earnings of the combined entity for the current reporting period as though the acquisition date for all business combinations that
occurred during the year had been as of the beginning of the annual reporting period. If comparative financial statements are presented, the pro forma revenue and earnings of the combined entity for the comparable prior reporting period should be
reported as though the acquisition date for all business combinations that occurred during the current year had been as of the beginning of the comparable prior annual reporting period. ASU 2010-29 is effective prospectively for business
combinations that occur on or after the beginning of the first annual reporting period beginning after December 15, 2010. The adoption of ASU 2010-29 did not have a material impact on our consolidated results of operations, financial condition,
or cash flows.

[0001193125-12-048929:mdna:104]
In June 2011, the FASB issued Accounting Standards Update (ASU) No. 2011-05, Comprehensive Income
(Topic 220): Presentation of Comprehensive Income. ASU 2011-05 requires entities to present net income and other comprehensive income in either a single continuous statement or in two separate, but consecutive, statements of net income and other
comprehensive income. ASU 2011-05 is effective for fiscal years and interim periods beginning after December 15, 2011. We do not expect the adoption of ASU 2011-05 to have a material impact on our consolidated results of operations, financial
condition, or cash flows.

[0001193125-12-048929:mdna:105]
33
