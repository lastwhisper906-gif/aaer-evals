# AMSC 8-K — 0001193125-12-048009 filed 2012-02-09

## item codes, every 8-K on or before 2012-02-09

- 2012-02-09 0001193125-12-048009 — 2.02, 9.01
- 2012-02-06 0001193125-12-041344 — 5.07 — amendment of 0000950123-11-102495
- 2011-12-08 0000950123-11-102495 — 5.07
- 2011-11-29 0000950123-11-100822 — 2.05
- 2011-11-09 0000950123-11-096775 — 2.02, 9.01
- 2011-10-31 0000950123-11-093390 — 1.02, 9.01
- 2011-10-07 0000950123-11-089221 — 8.01
- 2011-10-03 0000950123-11-088315 — 7.01
- 2011-09-23 0000950123-11-086288 — 2.02, 9.01
- 2011-09-15 0000950123-11-084585 — 7.01
- 2011-09-06 0000950123-11-082736 — 7.01
- 2011-08-18 0000950123-11-078526 — 3.01, 7.01, 9.01
- 2011-08-11 0000950123-11-075905 — 5.02
- 2011-08-11 0000950123-11-075904 — 2.02, 2.05, 9.01
- 2011-07-11 0000950123-11-064934 — 2.02, 4.02, 9.01
- 2011-06-30 0000950123-11-063287 — 1.01, 3.02, 9.01
- 2011-06-21 0000950123-11-060491 — 3.01, 7.01, 9.01
- 2011-06-13 0000950123-11-058656 — 1.01, 9.01
- 2011-05-24 0000950123-11-053517 — 5.02, 9.01
- 2011-04-05 0001299933-11-001020 — 2.02, 9.01
- 2011-03-15 0000950123-11-025580 — 5.02
- 2011-03-14 0000950123-11-025205 — 1.01, 3.02, 9.01
- 2011-02-01 0001299933-11-000333 — 2.02, 9.01
- 2010-11-12 0000950123-10-104604 — 8.01, 9.01
- 2010-11-08 0000950123-10-102424 — 8.01, 9.01
- 2010-11-02 0001299933-10-003878 — 2.02, 9.01
- 2010-09-15 0000950123-10-086373 — 1.01, 9.01 — amendment, the index does not say of what
- 2010-08-06 0000950123-10-074362 — 5.07
- 2010-07-29 0001299933-10-002860 — 2.02, 9.01
- 2010-05-17 0000950123-10-050424 — 1.01, 9.01
- 2010-05-14 0001299933-10-001972 — 5.02
- 2010-05-13 0001299933-10-001943 — 2.02, 9.01
- 2010-02-08 0001299933-10-000506 — 8.01
- 2010-02-02 0001299933-10-000386 — 2.02, 9.01
- 2009-12-15 0001299933-09-004928 — 5.02
- 2009-10-29 0001299933-09-004267 — 2.02, 9.01
- 2009-08-12 0001193125-09-173026 — 5.02, 9.01
- 2009-07-30 0001193125-09-158842 — 1.01, 2.02, 9.01
- 2009-05-15 0001193125-09-113158 — 5.02
- 2009-05-14 0001193125-09-110619 — 2.02, 9.01
- 2009-04-20 0001193125-09-082590 — 5.02
- 2009-02-03 0001193125-09-016992 — 2.02, 9.01
- 2009-01-22 0001193125-09-009777 — 2.02, 9.01
- 2008-11-04 0001193125-08-223730 — 2.02, 9.01
- 2008-08-11 0001193125-08-173616 — 8.01
- 2008-08-07 0001193125-08-170325 — 8.01
- 2008-08-05 0001193125-08-165888 — 2.02, 9.01
- 2008-06-11 0001193125-08-132049 — 1.01, 9.01
- 2008-05-20 0001193125-08-119372 — 5.02, 9.01
- 2008-05-08 0001193125-08-107052 — 2.02, 9.01
- 2008-01-31 0001193125-08-016233 — 2.02, 9.01
- 2008-01-30 0001193125-08-015494 — 5.03, 9.01
- 2007-11-01 0001193125-07-231866 — 2.02, 9.01
- 2007-10-31 0001193125-07-231225 — 2.05
- 2007-10-29 0001193125-07-228284 — 5.03, 9.01
- 2007-09-27 0001193125-07-208950 — 5.02
- 2007-08-09 0001193125-07-176553 — 2.02, 9.01
- 2007-08-07 0001193125-07-173829 — 1.01, 5.02, 9.01
- 2007-07-02 0001193125-07-148303 — 5.02, 9.01
- 2007-06-20 0001193125-07-139068 — 8.01, 9.01
- 2007-06-14 0001193125-07-135550 — 9.01 — amendment of 0001193125-07-005297
- 2007-06-14 0001193125-07-135340 — 5.02
- 2007-05-24 0001193125-07-122148 — 2.02, 9.01
- 2007-03-30 0001193125-07-070154 — 2.05, 9.01
- 2007-03-23 0001193125-07-062978 — 9.01 — amendment of 0001193125-07-005297
- 2007-02-01 0001193125-07-017883 — 2.02, 9.01
- 2007-01-11 0001193125-07-005297 — 2.01, 9.01
- 2006-12-05 0001181431-06-067500 — 5.02
- 2006-11-29 0001193125-06-243360 — 1.01, 3.02, 9.01
- 2006-11-02 0001193125-06-221464 — 2.02, 9.01
- 2006-09-21 0001193125-06-194526 — 5.02
- 2006-08-08 0001193125-06-164819 — 2.02, 9.01
- 2006-08-02 0001193125-06-159113 — 1.01, 9.01
- 2006-07-28 0001193125-06-156172 — 1.01
- 2006-06-26 0001193125-06-135913 — 1.01, 3.03, 9.01
- 2006-05-11 0001193125-06-108489 — 2.02, 9.01
- 2006-05-05 0001193125-06-102270 — 1.01, 9.01
- 2006-05-01 0001193125-06-094941 — 2.02, 2.06, 9.01
- 2006-02-24 0001193125-06-038281 — 5.02, 9.01
- 2006-02-02 0001181431-06-007665 — 2.02, 9.01
- 2005-11-09 0001181431-05-060304 — 2.02, 9.01
- 2005-08-04 0001181431-05-044420 — 2.02, 9.01
- 2005-07-28 0001193125-05-151272 — 5.02, 9.01
- 2005-06-14 0001193125-05-125148 — 5.02, 9.01
- 2005-05-12 0001181431-05-027410 — 2.02, 9.01
- 2005-05-10 0001193125-05-102795 — 1.01
- 2005-04-05 0001181431-05-020680 — 1.01, 2.02, 3.02, 9.01
- 2005-02-03 0001181431-05-006678 — 2.02, 9.01
- 2004-11-09 0001181431-04-051381 — 2.02, 9.01 — amendment, the index does not say of what
- 2004-11-04 0001181431-04-050706 — 2.02, 9.01
- 2004-10-15 0001193125-04-172458 — 1.01, 9.01
- 2004-08-05 0001193125-04-132162 — 12
- 2004-05-13 0001193125-04-086853 — 12
- 2004-02-05 0001193125-04-015060 — 12
- 2003-11-06 0001193125-03-074000 — 12
- 2003-09-26 0001193125-03-054624 — 5
- 2003-08-06 0001193125-03-029666 — 12
- 2003-05-14 0000927016-03-002619 — 9
- 2002-12-31 0000927016-02-006114 — 5
- 2000-01-24 0000927016-00-000150 — 5, 7
- 1998-11-02 0000950135-98-005625 — 5, 7
- 1998-03-24 0000950135-98-001743 — 5, 7
- 1997-09-05 0000950135-97-003729 — 5, 7
- 1997-06-23 0000950135-97-002785 — 1 — amendment of 0000950135-97-001972
- 1997-04-23 0000950135-97-001972 — 2, 7

## late-filing notifications on or before 2012-02-09

- 2011-08-10 0000950123-11-075677 — NT 10-Q, for the period ended 2011-06-30
- 2011-05-31 0000950123-11-055465 — NT 10-K, for the period ended 2011-03-31

## item 2.02 — earnings release, exhibit 99.1

[0001193125-12-048009:8k_2_02:1]
EX-99.1
2
d297594dex991.htm
PRESS RELEASE ISSUED BY AMERICAN SUPERCONDUCTOR CORPORATION ON FEBRUARY 9, 2012.

[0001193125-12-048009:8k_2_02:2]
Press release issued by American Superconductor Corporation on February 9, 2012.

[0001193125-12-048009:8k_2_02:3]
Exhibit 99.1

[0001193125-12-048009:8k_2_02:4]
AMSC Reports Third Quarter

[0001193125-12-048009:8k_2_02:5]
Financial Results

[0001193125-12-048009:8k_2_02:6]
Devens, MA – February 9, 2012 – AMSC (NASDAQ: AMSC), a
global solutions provider serving wind and grid leaders, today reported financial results for its third quarter of fiscal year 2011 ended December 31, 2011.

[0001193125-12-048009:8k_2_02:7]
Revenues for the third quarter of fiscal 2011 were $18.1 million. This compares with $31.6 million for the third quarter of fiscal 2010 and $20.8 million for the second quarter of fiscal 2011. The
year-over-year decline is due primarily to lower shipments from the company’s Grid segment while the quarter-over-quarter decline was due to slightly lower shipments of wind turbine power electronics and controls from the company’s Wind
segment.

[0001193125-12-048009:8k_2_02:8]
AMSC reported a net loss for the third fiscal quarter of $26.3 million, or $0.52 per share. This figure includes approximately $6.5
million in expenses related to the company’s litigation against Sinovel Wind Group Co., Ltd. and restructuring and impairment charges related to the workforce reduction that was announced in November 2011. For the third quarter of fiscal year
2010, AMSC reported a net loss of $18.2 million, or $0.38 per share. AMSC reported a net loss of $51.7 million, or $1.02 per share, for the second quarter of fiscal year 2011.

[0001193125-12-048009:8k_2_02:9]
The company’s non-GAAP net loss for the third quarter of fiscal 2011 was $17.5 million, or $0.34 per share. This compares with a non-GAAP net loss of $13.4 million, or $0.28 per diluted share, for
the third quarter of fiscal 2010 and a non-GAAP net loss of $22.1 million, or $0.44 per share, for the second quarter of fiscal year 2011. Please refer to the financial table below for a reconciliation of GAAP to non-GAAP results.

[0001193125-12-048009:8k_2_02:10]
AMSC’s cash, cash equivalents, marketable securities and restricted cash at December 31, 2011 totaled $75.5 million. This is in line with the
company’s guidance and compares with $108.3 million as of September 30, 2011.

[0001193125-12-048009:8k_2_02:11]
The company’s total backlog as of
December 31, 2011, excluding contracts related to Sinovel, increased to $300 million from $298 million as of September 30, 2011.

[0001193125-12-048009:8k_2_02:12]
“I am pleased to report that AMSC exceeded each of its financial targets for the third fiscal quarter,” said AMSC President and Chief Executive
Officer Daniel P. McGahn. “We again generated a diversified revenue stream, with solid contributions from both our Wind and Grid segments and with Australia, India, Korea and the United States each contributing more than 10 percent of our total
quarterly revenues. We further streamlined our cost structure in the third fiscal quarter, allowing us to reduce our cash usage and better position AMSC for sustainable profitability. In addition, on the orders front, we continued building our order
book for fiscal 2012, which begins on April 1, 2012.”

[0001193125-12-048009:8k_2_02:13]
| AMSC Reports Third Quarter Results |  | Page 2 |

[0001193125-12-048009:8k_2_02:14]
Looking Forward

[0001193125-12-048009:8k_2_02:15]
“The pipeline of business we have built and the organizational changes we have made provide us with confidence that we will post sequential growth and will reduce our cash usage in the fourth fiscal
quarter,” McGahn continued. “Our outlook continues to brighten, and we look forward to finishing fiscal year 2011 on a positive note.”

[0001193125-12-048009:8k_2_02:16]
For the quarter ending March 31, 2012, AMSC expects that its revenues will exceed $27 million. AMSC expects that its net loss for the fourth quarter of fiscal 2011 will be less than $24 million, or
$0.47 per share. AMSC expects that its non-GAAP net loss for the fourth fiscal quarter will be less than $20 million, or $0.39 per share.

[0001193125-12-048009:8k_2_02:17]
AMSC estimates that it will have approximately $50 million in cash, cash equivalents, marketable securities and restricted cash on March 31, 2012.
The company expects that its net cash usage will be further reduced in subsequent quarters as revenues grow year over year, working capital requirements are minimized and the benefits of recent cost reduction efforts are fully realized. AMSC
believes that it has sufficient cash to fund its operations for at least the next 12 months.

[0001193125-12-048009:8k_2_02:18]
Conference Call Reminder

[0001193125-12-048009:8k_2_02:19]
In conjunction with this announcement, AMSC management will participate in a conference call with investors beginning at 10:00 a.m. Eastern Time today to
discuss the company’s results and its business outlook. Those who wish to listen to the live or archived conference call webcast should visit the “Investors” section of the company’s website at
http://www.amsc.com/investors. The live call also can be accessed by dialing 719-457-2637 and using conference ID 7201664.

[0001193125-12-048009:8k_2_02:20]
About
AMSC (NASDAQ: AMSC)

[0001193125-12-048009:8k_2_02:21]
AMSC generates the ideas, technologies and solutions that meet the world’s demand for smarter, cleaner …
better energy. Through its Windtec™ Solutions, AMSC enables manufacturers to launch best-in-class wind turbines quickly, effectively and profitably. Through its Gridtec™ Solutions, AMSC provides the engineering planning services and
advanced grid systems that optimize network reliability, efficiency and performance. The company’s solutions are now powering gigawatts of renewable energy globally and enhancing the performance and reliability of power networks in more than a
dozen countries. Founded in 1987, AMSC is headquartered near Boston, Massachusetts with operations in Asia, Australia, Europe and North America. For more information, please visit www.amsc.com.

[0001193125-12-048009:8k_2_02:22]
AMSC Contact:

[0001193125-12-048009:8k_2_02:23]
Jason Fredette

[0001193125-12-048009:8k_2_02:24]
Phone: 978-842-3177

[0001193125-12-048009:8k_2_02:25]
Email:
jfredette@amsc.com

[0001193125-12-048009:8k_2_02:26]
AMSC, Windtec and Gridtec are trademarks or registered trademarks of American Superconductor Corporation. All
other brand names, product names, trademarks or service marks belong to their respective holders.

[0001193125-12-048009:8k_2_02:27]
| AMSC Reports Third Quarter Results |  | Page 3 |

[0001193125-12-048009:8k_2_02:28]
affected our business and results of operations and if, as we expect, Sinovel continues to refuse to accept shipments from us, our business and results of operations will be further materially
and adversely affected; we intend to seek additional funding in the future and may be unable to raise capital when needed; we have a history of operating losses, and we may incur additional losses in the future; our operating results may fluctuate
significantly from quarter to quarter and may fall below expectations in any particular fiscal quarter; changes in exchange rates could adversely affect our results from operations; we have identified material weaknesses in our internal control over
financial reporting and if we fail to remediate these weaknesses and maintain proper and effective internal controls over financial reporting, our ability to produce accurate and timely financial statements could be impaired and may lead investors
and other users to lose confidence in our financial data; if we fail to implement our business strategy successfully, our financial performance could be harmed; we may not realize all of the sales expected from our backlog of orders and contracts;
many of our revenue opportunities are dependent upon subcontractors and other business collaborators; our products face intense competition, which could limit our ability to acquire or retain customers; our success is dependent upon attracting and
retaining qualified personnel and our inability to do so could significantly damage our business and prospects; we may acquire additional complementary businesses or technologies, which may require us to incur substantial costs for which we may
never realize the anticipated benefits; our international operations are subject to risks that we do not face in the United States, which could have an adverse effect on our operating results; we depend on sales to customers in China, and global
conditions could negatively affect our operating results or limit our ability to expand our operations outside of China; changes in China’s political, social, regulatory and economic environment may affect our financial performance; many of our
customer relationships outside of the United States are, either directly or indirectly, with governmental entities, and we could be adversely affected by violations of the United States Foreign Corrupt Practices Act and similar worldwide
anti-bribery laws outside the United States; we rely upon third party suppliers for the components and subassemblies of many of our Wind and Grid products, making us vulnerable to supply shortages and price fluctuations, which could harm our
business; we are becoming increasingly reliant on contracts that require the issuance of performance bonds; problems with product quality or product performance may cause us to incur warranty expenses and may damage our market reputation and prevent
us from achieving increased sales and market share; our success in addressing the wind energy market is dependent on the manufacturers that license our designs; growth of the wind energy market depends largely on the availability and size of
government subsidies and economic incentives; there are a number of technological challenges that must be successfully addressed before our superconductor products can gain widespread commercial acceptance, and our inability to address such
technological challenges could adversely affect our ability to acquire customers for our products; we have not manufactured our Amperium wire in commercial quantities, and a failure to manufacture our Amperium wire in commercial quantities at
acceptable cost and quality levels would substantially limit our future revenue and profit potential; the commercial uses of superconductor products are limited today, and a widespread commercial market for our products may not develop; we have
limited experience in marketing and selling our superconductor products and system-level solutions, and our failure to effectively market and sell our products and solutions could lower our revenue and cash flow; our contracts with the U.S.
government are subject to audit, modification or termination by the U.S. government and include certain other provisions in favor of the government; the continued funding of such contracts remains subject to annual congressional appropriation which,
if not approved, could reduce our revenue and lower or eliminate our profit; we may be unable to adequately prevent disclosure of trade secrets and other proprietary information; we have filed a demand for arbitration and other lawsuits against
Sinovel regarding amounts we contend are due and owing and are in dispute; we cannot be certain as to the outcome of the proceedings against Sinovel; we have been named as a party to purported stockholder class actions and shareholder derivative
complaints, and we may be named in additional litigation, all of which will require significant management time and attention, result in significant legal expenses and may result in an unfavorable outcome, which could have a material adverse effect
on our business, operating results and financial condition; our technology and products could infringe intellectual property rights of others, which may require costly litigation and, if we are not successful, could cause us to pay substantial
damages and disrupt our business; our patents may not provide meaningful protection for our technology, which could result in us losing some or all of our market position; third parties have or may acquire patents that cover the materials, processes
and technologies we use or may use in the future to manufacture our Amperium products, and our success depends on our ability to license such patents or other proprietary rights; and our common stock has experienced, and may continue to experience,
significant market price and volume fluctuations, which may prevent our stockholders from selling our common stock at a profit and could lead to costly litigation against us that could divert our management’s attention. Reference is made to
many of these factors and others in the “Risk Factors” section of the company’s most recent quarterly or annual report filed with the Securities and Exchange Commission. In addition, any forward-looking statements included in this
release represent the company’s expectations as of the date of this release. While the company anticipates that subsequent events and developments may cause the company’s views to change, the company specifically disclaims any obligation
to update these forward-looking statements. These forward-looking statements should not be relied upon as representing the company’s views as of any date subsequent to the date of this release.

[0001193125-12-048009:8k_2_02:29]
| AMSC Reports Third Quarter Results |  | Page 4 |

[0001193125-12-048009:8k_2_02:30]
UNAUDITED CONSOLIDATED STATEMENTS OF OPERATIONS

[0001193125-12-048009:8k_2_02:31]
(In thousands, except per share data)

[0001193125-12-048009:8k_2_02:32]
|  |  | Three months endedDecember 31, |  |  | Nine months endedDecember 31, |  |
|  |  | 2011 |  |  | 2010 |  |  | 2011 |  |  | 2010 |  |
| Revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Wind |  | $ | 10,125 |  |  | $ | 10,840 |  |  | $ | 27,836 |  |  | $ | 183,162 |  |
| Grid |  |  | 7,933 |  |  |  | 20,730 |  |  |  | 20,080 |  |  |  | 43,691 |  |
| Total revenues |  |  | 18,058 |  |  |  | 31,570 |  |  |  | 47,916 |  |  |  | 226,853 |  |
| Cost of revenues |  |  | 18,918 |  |  |  | 31,528 |  |  |  | 57,810 |  |  |  | 149,167 |  |
| Gross profit |  |  | (860 | ) |  |  | 42 |  |  |  | (9,894 | ) |  |  | 77,686 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Research and development |  |  | 5,928 |  |  |  | 8,417 |  |  |  | 21,339 |  |  |  | 23,610 |  |
| Selling, general and administrative |  |  | 15,402 |  |  |  | 14,192 |  |  |  | 54,952 |  |  |  | 46,724 |  |
| Write-off of advance payment |  |  | — |  |  |  | — |  |  |  | 20,551 |  |  |  | — |  |
| Amortization of acquisition related intangibles |  |  | 287 |  |  |  | 393 |  |  |  | 891 |  |  |  | 1,154 |  |
| Restructuring and impairments |  |  | 4,092 |  |  |  | — |  |  |  | 8,393 |  |  |  | — |  |
| Total operating expenses |  |  | 25,709 |  |  |  | 23,002 |  |  |  | 106,126 |  |  |  | 71,488 |  |
| Operating (loss) income |  |  | (26,569 | ) |  |  | (22,960 | ) |  |  | (116,020 | ) |  |  | 6,198 |  |
| Interest (expense) income, net |  |  | (11 | ) |  |  | 171 |  |  |  | 232 |  |  |  | 549 |  |
| Other income (expense), net |  |  | 393 |  |  |  | 2,136 |  |  |  | 1,313 |  |  |  | 4,745 |  |
| (Loss) income before income tax expense (benefit) |  |  | (26,187 | ) |  |  | (20,653 | ) |  |  | (114,475 | ) |  |  | 11,492 |  |
| Income tax expense (benefit) |  |  | 84 |  |  |  | (2,495 | ) |  |  | 1,185 |  |  |  | 12,642 |  |
| Net loss |  | $ | (26,271 | ) |  | $ | (18,158 | ) |  | $ | (115,660 | ) |  | $ | (1,150 | ) |
| Net loss per common share |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | (0.52 | ) |  | $ | (0.38 | ) |  | $ | (2.28 | ) |  | $ | (0.02 | ) |
| Diluted |  | $ | (0.52 | ) |  | $ | (0.38 | ) |  | $ | (2.28 | ) |  | $ | (0.02 | ) |
| Weighted average number of common shares outstanding |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  |  | 50,933 |  |  |  | 48,068 |  |  |  | 50,789 |  |  |  | 46,017 |  |
| Diluted |  |  | 50,933 |  |  |  | 48,068 |  |  |  | 50,789 |  |  |  | 46,017 |  |

[0001193125-12-048009:8k_2_02:33]
| AMSC Reports Third Quarter Results |  | Page 5 |

[0001193125-12-048009:8k_2_02:34]
UNAUDITED CONDENSED CONSOLIDATED BALANCE SHEETS

[0001193125-12-048009:8k_2_02:35]
(In thousands)

[0001193125-12-048009:8k_2_02:36]
|  |  | December 31,2011 |  |  | March 31,2011 |  |
| ASSETS |  |  |  |  |  |  |  |  |
| Current assets: |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 58,605 |  |  | $ | 123,783 |  |
| Marketable securities |  |  | 5,261 |  |  |  | 116,126 |  |
| Accounts receivable, net |  |  | 14,764 |  |  |  | 15,259 |  |
| Inventory |  |  | 34,021 |  |  |  | 25,828 |  |
| Prepaid expenses and other current assets |  |  | 29,789 |  |  |  | 32,759 |  |
| Restricted cash |  |  | 9,049 |  |  |  | 5,566 |  |
| Deferred tax assets |  |  | 484 |  |  |  | 484 |  |
| Total current assets |  |  | 151,973 |  |  |  | 319,805 |  |
| Property, plant and equipment, net |  |  | 94,073 |  |  |  | 96,494 |  |
| Intangibles, net |  |  | 8,662 |  |  |  | 7,054 |  |
| Restricted cash |  |  | 2,540 |  |  |  | — |  |
| Deferred tax assets |  |  | 5,840 |  |  |  | 5,840 |  |
| Other assets |  |  | 12,275 |  |  |  | 12,016 |  |
| Total assets |  | $ | 275,363 |  |  | $ | 441,209 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |  |  |  |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |  |  |  |
| Accounts payable and accrued expenses |  | $ | 39,075 |  |  | $ | 90,273 |  |
| Adverse purchase commitments |  |  | 28,763 |  |  |  | 38,763 |  |
| Deferred revenue |  |  | 15,246 |  |  |  | 10,304 |  |
| Deferred tax liabilities |  |  | 5,840 |  |  |  | 5,840 |  |
| Total current liabilities |  |  | 88,924 |  |  |  | 145,180 |  |
| Deferred revenue |  |  | 1,921 |  |  |  | 2,181 |  |
| Deferred tax liabilities |  |  | 484 |  |  |  | 484 |  |
| Other |  |  | 969 |  |  |  | 509 |  |
| Total liabilities |  |  | 92,298 |  |  |  | 148,354 |  |
| Commitments and contingencies |  |  |  |  |  |  |  |  |
| Stockholders’ equity: |  |  |  |  |  |  |  |  |
| Common stock |  |  | 515 |  |  |  | 507 |  |
| Additional paid-in capital |  |  | 894,129 |  |  |  | 885,704 |  |
| Treasury stock |  |  | (271 | ) |  |  | — |  |
| Accumulated other comprehensive income |  |  | 1,525 |  |  |  | 3,817 |  |
| Accumulated deficit |  |  | (712,833 | ) |  |  | (597,173 | ) |
| Total stockholders’ equity |  |  | 183,065 |  |  |  | 292,855 |  |
| Total liabilities and stockholders’ equity |  | $ | 275,363 |  |  | $ | 441,209 |  |

[0001193125-12-048009:8k_2_02:37]
| AMSC Reports Third Quarter Results |  | Page 6 |

[0001193125-12-048009:8k_2_02:38]
UNAUDITED CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS

[0001193125-12-048009:8k_2_02:39]
(In thousands)

[0001193125-12-048009:8k_2_02:40]
|  |  | Nine months ended December 31, |  |
|  |  | 2011 |  |  | 2010 |  |
| Cash flows from operating activities: |  |  |  |  |  |  |  |  |
| Net loss |  | $ | (115,660 | ) |  | $ | (1,150 | ) |
| Adjustments to reconcile net loss to net cash used in operations: |  |  |  |  |  |  |  |  |
| Depreciation and amortization |  |  | 10,875 |  |  |  | 7,990 |  |
| Stock-based compensation expense |  |  | 7,697 |  |  |  | 10,311 |  |
| Provision for excess and obsolete inventory |  |  | 2,150 |  |  |  | 2,667 |  |
| Adverse purchase commitment losses (recoveries), net |  |  | 73 |  |  |  | — |  |
| Allowance for doubtful accounts |  |  | — |  |  |  | 25 |  |
| Write-off of advance payment |  |  | 20,551 |  |  |  | — |  |
| Write-off of prepaid value added taxes |  |  | — |  |  |  | 550 |  |
| Restructuring charges, net of payments |  |  | 2,721 |  |  |  | — |  |
| Impairment of long-lived assets |  |  | 2,829 |  |  |  | — |  |
| Deferred income taxes |  |  | — |  |  |  | (3,902 | ) |
| Other non-cash items |  |  | 2,227 |  |  |  | 2,025 |  |
| Changes in operating asset and liability accounts: |  |  |  |  |  |  |  |  |
| Accounts receivable |  |  | (1,262 | ) |  |  | 40,431 |  |
| Inventory |  |  | (10,419 | ) |  |  | (42,934 | ) |
| Prepaid expenses and other current assets |  |  | 3,244 |  |  |  | (16,973 | ) |
| Accounts payable and accrued expenses |  |  | (63,554 | ) |  |  | 4,945 |  |
| Deferred revenue |  |  | 5,254 |  |  |  | (20,027 | ) |
| Net cash used in operating activities |  |  | (133,274 | ) |  |  | (16,042 | ) |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |
| Purchase of property, plant and equipment |  |  | (9,332 | ) |  |  | (30,690 | ) |
| Purchase of marketable securities |  |  | — |  |  |  | (71,763 | ) |
| Proceeds from sales and maturities of marketable securities |  |  | 110,667 |  |  |  | 47,462 |  |
| Change in restricted cash |  |  | (6,036 | ) |  |  | 250 |  |
| Purchase of intangible assets |  |  | (3,893 | ) |  |  | (2,001 | ) |
| Purchase of minority investments |  |  | (1,800 | ) |  |  | (8,000 | ) |
| Advance payment for previously planned acquisition |  |  | (20,551 | ) |  |  | — |  |
| Change in other assets |  |  | (734 | ) |  |  | (30 | ) |
| Net cash provided by (used in) investing activities |  |  | 68,321 |  |  |  | (64,772 | ) |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |
| Proceeds from public equity offering, net |  |  | — |  |  |  | 155,240 |  |
| Payments in lieu of issuance of common stock for payroll taxes |  |  | (271 | ) |  |  | — |  |
| Proceeds from exercise of employee stock options and ESPP |  |  | 150 |  |  |  | 7,350 |  |
| Net cash (used in) provided by financing activities |  |  | (121 | ) |  |  | 162,590 |  |
| Effect of exchange rate changes on cash and cash equivalents |  |  | (104 | ) |  |  | (351 | ) |
| Net (decrease) increase in cash and cash equivalents |  |  | (65,178 | ) |  |  | 81,427 |  |
| Cash and cash equivalents at beginning of period |  |  | 123,783 |  |  |  | 87,594 |  |
| Cash and cash equivalents at end of period |  | $ | 58,605 |  |  | $ | 169,021 |  |
| Supplemental schedule of cash flow information: |  |  |  |  |  |  |  |  |
| Cash paid for income taxes, net of refunds |  |  | 13,482 |  |  | $ | 13,660 |  |
| Non-cash contingent consideration in connection with acquisitions |  |  | — |  |  |  | 10,004 |  |
| Non-cash issuance of common stock |  |  | 586 |  |  |  | 637 |  |

[0001193125-12-048009:8k_2_02:41]
| AMSC Reports Third Quarter Results |  | Page 7 |

[0001193125-12-048009:8k_2_02:42]
Reconciliation of GAAP Net (Loss) Income to Non-GAAP Net (Loss) Income

[0001193125-12-048009:8k_2_02:43]
(In thousands, except per share data)

[0001193125-12-048009:8k_2_02:44]
|  |  | Three months ended December 31, |  |  | Nine months ended December 31, |  |
|  |  | 2011 |  |  | 2010 |  |  | 2011 |  |  | 2010 |  |
| Net loss |  | $ | (26,271 | ) |  | $ | (18,158 | ) |  | $ | (115,660 | ) |  | $ | (1,150 | ) |
| Write-off of advance payment |  |  | — |  |  |  | — |  |  |  | 20,551 |  |  |  | — |  |
| Stock-based compensation |  |  | 2,118 |  |  |  | 2,249 |  |  |  | 7,697 |  |  |  | 10,073 |  |
| Executive severance |  |  | — |  |  |  | — |  |  |  | 2,066 |  |  |  | — |  |
| Restructuring and impairment charges |  |  | 4,092 |  |  |  | — |  |  |  | 8,393 |  |  |  | — |  |
| Sinovel litigation |  |  | 2,423 |  |  |  | — |  |  |  | 5,757 |  |  |  | — |  |
| Provision for excess and obsolete inventory |  |  | — |  |  |  | 2,087 |  |  |  | — |  |  |  | 2,667 |  |
| Adverse purchase commitment (recoveries) losses, net |  |  | (94 | ) |  |  | — |  |  |  | 73 |  |  |  | — |  |
| Value-added tax write-off |  |  | — |  |  |  | 118 |  |  |  | — |  |  |  | 550 |  |
| Margin on zero cost-basis inventory |  |  | (46 | ) |  |  | — |  |  |  | (173 | ) |  |  | — |  |
| Amortization of acquisition-related intangibles |  |  | 287 |  |  |  | 392 |  |  |  | 891 |  |  |  | 1,154 |  |
| Tax effects |  |  | — |  |  |  | (88 | ) |  |  | — |  |  |  | (255 | ) |
| Non-GAAP net (loss) income |  | $ | (17,491 | ) |  | $ | (13,400 | ) |  | $ | (70,405 | ) |  | $ | 13,039 |  |
| Non-GAAP (loss) earnings per share |  | $ | (0.34 | ) |  | $ | (0.28 | ) |  | $ | (1.39 | ) |  | $ | 0.28 |  |
| Weighted average shares outstanding * |  |  | 50,933 |  |  |  | 48,068 |  |  |  | 50,789 |  |  |  | 46,017 |  |

[0001193125-12-048009:8k_2_02:45]
| * | Diluted shares are used for periods where net income is generated. |

[0001193125-12-048009:8k_2_02:46]
Reconciliation of Forecast GAAP Net Loss to Non-GAAP Net Loss

[0001193125-12-048009:8k_2_02:47]
(In
millions, except per share data)

[0001193125-12-048009:8k_2_02:48]
|  |  | Three months endingMarch 31, 2012 |  |
| Net loss |  | $ | (24.0 | ) |
| Amortization of acquisition-related intangibles |  |  | 0.3 |  |
| Stock-based compensation |  |  | 2.7 |  |
| Sinovel litigation expenses |  |  | 1.0 |  |
| Tax effects |  |  | 0.0 |  |
| Non-GAAP net loss |  | $ | (20.0 | ) |
| Non-GAAP net loss per share |  | $ | (0.39 | ) |
| Shares outstanding |  |  | 51.1 |  |

[0001193125-12-048009:8k_2_02:49]
Note: Non-GAAP net income (loss) is defined by the company as net income (loss) before amortization of
acquisition-related intangibles, restructuring and impairments, stock-based compensation, severance and other unusual charges, and any tax effects related to these items. The company believes non-GAAP net income (loss) assists management and
investors in comparing the company’s performance across reporting periods on a consistent basis by excluding these non-cash or non-recurring charges that it does not believe are indicative of its core operating performance. The company also
regards non-GAAP net income (loss) as a useful measure of operating performance and cash flow to complement operating income, net income (loss) and other GAAP financial performance measures. In addition, the company uses non-GAAP net (loss) income
as a factor in evaluating management’s performance when determining incentive compensation and to evaluate the effectiveness of its business strategies.

[0001193125-12-048009:8k_2_02:50]
| AMSC Reports Third Quarter Results |  | Page 8 |

[0001193125-12-048009:8k_2_02:51]
Generally, a non-GAAP financial measure is a numerical measure of a company’s performance,
financial position or cash flow that either excludes or includes amounts that are not normally excluded or included in the most directly comparable measure calculated and presented in accordance with GAAP. The non-GAAP measures included in this
release, however, should be considered in addition to, and not as a substitute for or superior to, operating income, cash flows, or other measures of financial performance prepared in accordance with GAAP. A reconciliation of non-GAAP to GAAP net
income is set forth in the table above.
