# AMSC notes — 0001437749-25-017986


## cyd:CybersecurityRiskManagementProcessesForAssessingIdentifyingAndManagingThreatsTextBlock

[0001437749-25-017986:notes:1]
| Item 1C. | CYBERSECURITY |

[0001437749-25-017986:notes:2]
Overview

[0001437749-25-017986:notes:3]
Our technologies, systems and networks  may be subject to cybersecurity threats. Our business, like others within the energy technologies industry, is faced with growing cybersecurity threats as we increasingly rely on digital technologies across our business, some of which are managed by third-party service providers on whom we rely to help us collect, host or process information.

[0001437749-25-017986:notes:4]
We recognize the significance of these threats, sometimes referred to as hacking, cybersecurity fraud, and cyberattacks, and maintains processes and procedures designed to protect our critical systems and sensitive information from unauthorized access. However, there can be no assurance that a cyber-attack would timely be detected or thwarted. To date, we are not aware of any material cybersecurity incidents that have materially affected or are reasonably likely to materially affect us, and we have not incurred significant operating expenses related to cybersecurity incidents. For more information on risks related to cybersecurity, please see the section titled “Risk Factors” included under Item 1A of this Annual Report on Form 10-K.

[0001437749-25-017986:notes:5]
Risk Management and Strategy

[0001437749-25-017986:notes:6]
Our cybersecurity risk management program includes operational, technical and physical controls to protect against and respond timely to cybersecurity threats. To address evolving cybersecurity risks and corresponding regulations, our policies and procedures are benchmarked to industry, regulatory and cybersecurity frameworks (including the National Institute of Standards and Technology). This does not imply that we meet any particular technical standards, specifications, or requirements, only that we  may use industry, regulatory, and cybersecurity frameworks as a guide to help us identify, assess, and manage cybersecurity risks relevant to our business.

[0001437749-25-017986:notes:7]
Our cybersecurity risk management program is integrated into our overall risk management program, and shares common methodologies, reporting channels and governance processes that apply across the risk management program to other legal, compliance, strategic, operational, and financial risk areas.

[0001437749-25-017986:notes:8]
Management has engaged third-party vendors to assist in monitoring our cybersecurity risk management programs and identifying and responding to any incidents. Additionally, third-party vendors are routinely engaged to evaluate how effectively management as a whole manages cybersecurity risk. This includes annual testing of our incident response plan through tabletop exercises and simulations to ensure readiness as well as penetration testing and security assessments. We also utilize third-party cybersecurity vendors to assess our protections against identified vulnerabilities, and we have implemented a third-party risk management process for key service providers, based on our assessment of their criticality to our operations.

[0001437749-25-017986:notes:9]
We have developed cybersecurity training for employees concerning cybersecurity risk.  This training provides information on security awareness and phishing simulations.  All employees are required to attend periodic cybersecurity training. On a regular basis, our IT team shares news and articles related to cybersecurity awareness with all employees.

[0001437749-25-017986:notes:10]
Our cybersecurity risk assessment is performed annually and includes external and internal penetration testing performed by third party vendors to test for vulnerabilities in the Company’s environment.

[0001437749-25-017986:notes:11]
We have not identified risks from known cybersecurity threats, including as a result of any prior cybersecurity incidents, that have materially affected us, including our operations, business strategy, results of operations, or financial condition. We face risks from cybersecurity threats that, if realized, are reasonably likely to materially affect us, including our operations, business strategy, results of operations, or financial condition. See "Risk Factors – Our business and operations may be materially adversely impacted in the event of a failure or security breach of our or any critical third parties' IT Systems or Confidential Information."


## cyd:CybersecurityRiskBoardOfDirectorsOversightTextBlock

[0001437749-25-017986:notes:12]
Governance

[0001437749-25-017986:notes:13]
The Board of Directors has delegated the oversight of risks from cybersecurity threats to the Audit Committee, which has delegated authority to the Chief Financial Officer to oversee the Company’s day-to-day cybersecurity risk management, including prevention, detection and responding to any suspected cybersecurity incident.

[0001437749-25-017986:notes:14]
The Audit Committee is updated at least annually by the CFO on the status of cybersecurity matters. Contemporaneous reporting is provided on an as needed basis to the Audit Committee and to the full Board of Directors on significant cyber events including response, legal obligations, and outreach and notification to regulators, and third parties when needed.

[0001437749-25-017986:notes:15]
The Director, Global Information Technology and Financial Systems (the “IT Director”), leads an internal team who work directly with our third-party vendors to manage our cybersecurity risk management program and activities. The internal team monitors our information systems for cybersecurity threats, reviews cybersecurity incidents, analyzes emerging threats, and develops and implements risk mitigation strategies. Under our CFO’s authority, the IT Director periodically reports on the cybersecurity program to our executive leadership team, including by providing the team with updates on cybersecurity threats and incidents, the status of ongoing projects and initiatives, performance metrics, and additional cybersecurity topics. On an annual basis, the IT Director reviews the results of the current state of cybersecurity risk management, including the results of our cybersecurity risk assessment and any action plan to address any identified vulnerabilities.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0001437749-25-017986:notes:16]
1. Nature of the Business and Operations and Liquidity

[0001437749-25-017986:notes:17]
Nature of the Business and Operations

[0001437749-25-017986:notes:18]
American Superconductor Corporation (together with its subsidiaries, “AMSC®” or the “Company”) was founded on  April 9, 1987. The Company is a leading system provider of megawatt-scale power resiliency solutions that orchestrate the rhythm and harmony of power on the grid™ and protect and expand the capability of the Navy's fleet. The Company’s system level products leverage its proprietary “smart materials” and “smart software and controls” to provide enhanced resiliency and improved performance of megawatt-scale power flow.

[0001437749-25-017986:notes:19]
These consolidated financial statements of the Company have been prepared on a going concern basis in accordance with United States generally accepted accounting principles (“GAAP”) and the Securities and Exchange Commission’s (“SEC”) instructions to Form 10-K. Certain prior period amounts were reclassified to conform to the presentation in the current period. The going concern basis of presentation assumes that the Company will continue operations and will be able to realize its assets and discharge its liabilities and commitments in the normal course of business. All significant intercompany accounts and transactions are eliminated in consolidation. Investments in entities in which we do not have a controlling interest are accounted for under the equity method of accounting.

[0001437749-25-017986:notes:20]
Liquidity

[0001437749-25-017986:notes:21]
The Company’s primary sources of liquidity are internally generated cash provided by operating activities, our cash and cash equivalents on hand, along with access to capital markets. The Company believes that these sources of liquidity are sufficient to meet both its short-term and reasonably foreseeable long-term requirements and obligations. At  March 31, 2025, the Company had cash and cash equivalents of $79.5 million. Cash provided by operations for the year ended  March 31, 2025 was $28.3 million.

[0001437749-25-017986:notes:22]
On  August 1, 2024 (the "Acquisition Date"), the Company entered into a Stock Purchase Agreement (the “Stock Purchase Agreement”) with the selling stockholders named therein. Pursuant to the terms of the Stock Purchase Agreement and concurrently with entering into such agreement, the Company acquired all of the issued and outstanding shares of Megatran Industries, Inc. ("Megatran") (the "Acquisition"), for aggregate consideration in an amount equal to $61.4 million (the “Purchase Price”), which consideration amount was subject to various adjustments set forth in the Stock Purchase Agreement (including those described below) and consisted of: (a) (i) $25.0 million, minus (ii) the Indebtedness (as defined in the Stock Purchase Agreement) outstanding as of immediately prior to the closing, minus (iii) Company Expenses (as defined in the Stock Purchase Agreement) (collectively, the “Cash Purchase Price”); (b) a number of restricted shares (rounded up or down to the nearest whole share, as applicable) (the “Company Shares”) of the Company’s common stock, $.01 par value per share equal to the quotient obtained by dividing (x) $31.4 million (the “Share Purchase Price”) by (y) the closing price per share of common stock on the Nasdaq Global Select Market on the last trading day immediately preceding the Acquisition Date; and (c) an additional cash payment equal to $5.0 million, as adjusted pursuant to Sections 5.6(c), (d), and (f) of the Stock Purchase Agreement (the “Additional Cash Purchase Price”). Megatran is now a wholly-owned subsidiary of the Company and, together with its wholly-owned subsidiaries and affiliates, is operated and reported as a component of its Grid business segment. On the Acquisition Date, the Company paid to Megatran's selling stockholders $25.0 million in cash on hand, and 1,297,600 restricted shares of common stock. On  September 23, 2024, the Company paid $3.3 million to the selling stockholders, which was calculated based on the agreed upon formula set forth in the Stock Purchase Agreement. As of  March 31, 2025, there are no remaining obligations to the selling stockholders of Megatran. Throughout the financial statements and related footnotes, this is referred to as the "acquisition of NWL".

[0001437749-25-017986:notes:23]
In  January 2024, we filed a shelf registration statement on Form S-3 that will expire three years from the date on which it was declared effective,  March 15, 2027 (the “Form S-3”). The Form S-3 allows us to offer and sell from time-to-time up to $250 million of common stock, debt securities, warrants or units comprised of any combination of these securities. The Form S-3 is intended to provide us flexibility to conduct registered sales of our securities, subject to market conditions, in order to fund our future capital needs. The terms of any future offering under the Form S-3 will be established at the time of such offering and will be described in a prospectus supplement filed with the SEC prior to the completion of any such offering.

[0001437749-25-017986:notes:24]
In  August 2024, the Company filed an automatically-effective shelf registration statement on Form S-3 that will expire no later than  August 12, 2027 (the “Second Form S-3”). The Second Form S-3 allows the Company to offer and sell from time-to-time unspecified amounts of common stock, debt securities, warrants or units comprised of any combination of these securities and allows certain selling stockholders to offer and sell from time-to-time common stock. The Second Form S-3 assisted the Megatran selling stockholders in the resale of their common stock and is intended to provide the Company flexibility to conduct registered sales of its securities, subject to market conditions, in order to fund its future capital needs. The terms of any future offering under the Second Form S-3 will be established at the time of such offering and will be described in a prospectus supplement filed with the SEC prior to the completion of any such offering.

[0001437749-25-017986:notes:25]
The Company believes that based on the information presented above and its annual management assessment, it has sufficient liquidity to fund its operations and capital expenditures for the next
    twelve months following the issuance of the consolidated financial statements for the year ended
     March 31, 2025. The impact of global sources of instability on the global financing markets
     may reduce the Company's ability to raise additional capital, if necessary, which could negatively impact the Company's liquidity.  There can be
    no assurance that the Company will be able to continue to raise additional capital, on favorable terms or at all, from other sources or execute on any other means of improving liquidity described above.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001437749-25-017986:notes:26]
2. Acquisition

[0001437749-25-017986:notes:27]
Acquisition of NWL

[0001437749-25-017986:notes:28]
As described in Note 1, Nature of the Business and Operations and Liquidity, on the Acquisition Date, the Company acquired all of the issued and outstanding shares of capital stock of Megatran. Megatran's wholly-owned subsidiary, NWL, Inc. ("NWL"), is a U.S.-based global provider of engineered power conversion solutions for demanding industrial and military applications.

[0001437749-25-017986:notes:29]
The Acquisition has been accounted for under the purchase method of accounting in accordance with ASC 805, Business Combinations. The Company allocated the purchase price to the assets acquired and liabilities assumed at their estimated fair values as of the Acquisition Date. The excess of the purchase price paid by the Company over the estimated fair value of net assets acquired has been recorded as goodwill.

[0001437749-25-017986:notes:30]
The total purchase price of approximately $61.4 million includes the fair value of shares of the Company’s common stock issued at closing, and cash paid, as follows (in millions):

[0001437749-25-017986:notes:31]
| Cash payments | $30.0 |
| Issuance of 1,297,600 shares of Company’s common stock | $31.4 |

[0001437749-25-017986:notes:32]
At the Acquisition Date, in addition to the $30.0 million cash, the Company valued the Company’s common stock, using $24.16 per share, which was the closing price on the day prior to the day that the Company acquired Megatran. Acquisition costs of $1.1 million were included in selling, general and administrative ("SG&A") for the fiscal year ended  March 31, 2025.

[0001437749-25-017986:notes:33]
The following table summarizes the allocation of the purchase price based on the estimated fair values of the assets acquired and liabilities assumed and related deferred income taxes in connection with the Acquisition as of the Acquisition Date and reflective of measurement period adjustments (in millions):

[0001437749-25-017986:notes:34]
| Cash and cash equivalents |  | $ | 0.4 |  |
| Equity-method investments |  |  | 1.2 |  |
| Prepaid expenses and other current assets |  |  | 1.7 |  |
| Accounts receivable |  |  | 16.1 |  |
| Inventory |  |  | 23.1 |  |
| Property, plant, and equipment |  |  | 28.4 |  |
| Accounts payable and accrued expenses |  |  | (5.6 | ) |
| Deferred revenue |  |  | (5.0 | ) |
| Deferred tax liability |  |  | (5.6 | ) |
| Net tangible assets/(liabilities) |  |  | 54.7 |  |
| Backlog |  |  | 0.7 |  |
| Customer relationships |  |  | 1.3 |  |
| Net identifiable intangible assets |  |  | 2.0 |  |
| Goodwill |  |  | 4.7 |  |
| Total purchase consideration |  | $ | 61.4 |  |

[0001437749-25-017986:notes:35]
The fair value of the financial assets acquired includes receivables with a fair value of $16.1 million. The gross amount due is $16.9 million, of which $0.8 million is expected to be uncollectible.

[0001437749-25-017986:notes:36]
Inventory includes a $0.7 million adjustment to step up the inventory balance to fair value consistent with the purchase price allocation. The fair value was determined based on the estimated selling price of the inventory, less the remaining manufacturing and selling cost and a normal profit margin on those manufacturing and selling efforts. The inventory step up adjustment increased cost of revenue $0.7 million for the fiscal year ended  March 31, 2025 as the inventory was sold.

[0001437749-25-017986:notes:37]
Backlog of $0.7 million was evaluated using the multi period excess earnings method under the income approach. The contracts with customers do not provide for any guarantees to source all future requirements from the Company. The amortization method being utilized is economic consumption estimated over an eight-month period with the expense being allocated to cost of revenues.

[0001437749-25-017986:notes:38]
Customer relationships of $1.3 million relates to customers currently under contract and was determined based on a multi period excess earnings method under the income approach. The method of amortization being utilized is straight line over 10 years, as the results were not materially different from the economic consumption method, with the expense being allocated to SG&A.

[0001437749-25-017986:notes:39]
Goodwill represents the value associated with the acquired workforce and expected synergies related to the business combination of the two companies. Goodwill resulting from the Acquisition was assigned to the Company’s Grid business segment. Goodwill recognized in the Acquisition is not deductible for tax purposes. This purchase price allocation is preliminary and has not been finalized as the analysis on the assets and liabilities acquired, primarily the tax related liability,  may require further adjustments to our purchase accounting that could result in a measurement period adjustment that would impact the Company's reported net assets and goodwill as of  August 1, 2024. Material changes, if any, to the preliminary allocation summarized above will be reported once the related uncertainties are resolved, but no later than  August 1, 2025. The deferred tax liability initially valued at $6.4 million is primarily related to basis difference of property, plant, and equipment. As of  March 31, 2025 based on basis differences identified through the finalization of NWL’s pre-acquisition tax returns as well as a true up of state tax rates, a reduction in the deferred tax liability of $0.8 million was recorded in the three months ended  March 31, 2025. This decreased the balance to $5.6 million, and the offsetting reduction was recorded to Goodwill, decreasing the balance to $4.7 million.

[0001437749-25-017986:notes:40]
Pro forma Operating Results (Unaudited)

[0001437749-25-017986:notes:41]
The pro forma consolidated statement of operations for the fiscal years ended  March 31, 2025 and 2024 presented as if the Acquisition had occurred on  April 1, 2023, is unaudited and is as follows:

[0001437749-25-017986:notes:42]
|  |  | Fiscal year ended March 31, |  |
|  |  | 2025 |  |  | 2024 |  |
| Net Revenue |  | $ | 246,089 |  |  | $ | 220,102 |  |
| Operating income (loss) |  |  | 1,413 |  |  |  | (5,696 | ) |
| Net income |  | $ | 4,153 |  |  | $ | 1,245 |  |
| Net income per common share |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.11 |  |  | $ | 0.04 |  |
| Diluted |  | $ | 0.11 |  |  | $ | 0.04 |  |
| Shares - basic |  |  | 37,426 |  |  |  | 31,122 |  |
| Shares - diluted |  |  | 38,155 |  |  |  | 31,586 |  |

[0001437749-25-017986:notes:43]
The pro forma amounts include the historical operating results of the Company and Megatran with appropriate adjustments that give effect to acquisition related costs, income taxes, intangible amortization resulting from the Acquisition and certain conforming accounting policies of the Company. The pro forma amounts are not necessarily indicative of the operating results that would have occurred if the Acquisition and related transactions had been completed at the beginning of the applicable periods presented. In addition, the pro forma amounts are not necessarily indicative of operating results in future periods.

[0001437749-25-017986:notes:44]
In the consolidated results for the fiscal year ended  March 31, 2025, Megatran’s operations are included in the Company’s consolidated results from the Acquisition Date of  August 1, 2024. Megatran contributed $50.5 million of revenue and $6.0 million in net income for the Company for the fiscal year ended  March 31, 2025. Amortization expense of $0.8 million is included for the fiscal year ended  March 31, 2025, as a result of the Megatran acquired intangible assets. In addition, $0.7 million for the step-up basis assigned to acquired inventory was charged to cost of revenues for the fiscal year ended  March 31, 2025.


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001437749-25-017986:notes:45]
3. Summary of Significant Accounting Policies

[0001437749-25-017986:notes:46]
Basis of Consolidation

[0001437749-25-017986:notes:47]
The consolidated financial statements include the accounts of the Company and its wholly-owned subsidiaries. All significant intercompany balances and transactions are eliminated.

[0001437749-25-017986:notes:48]
Use of Estimates

[0001437749-25-017986:notes:49]
The preparation of financial statements in conformity with GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities, disclosure of contingent assets and liabilities at the date of the financial statements and the reported amounts of revenue and expenses during the reporting period. The Company bases its estimates on historical experience and various other factors believed to be reasonable under the circumstances, the results of which form the basis for making judgments about the carrying value of assets and liabilities that are not readily apparent from other sources. On an ongoing basis, the Company evaluates its estimates, including those related to revenue recognition, goodwill and intangible assets, business combinations, tax reserves, and deferred tax assets. Provisions for depreciation are based on their estimated useful lives using the straight-line method. Some of these estimates can be subjective and complex and, consequently, actual results  may differ from these estimates under different assumptions or conditions. While for any given estimate or assumption made by the Company’s management there  may be other estimates or assumptions that are reasonable, the Company believes that, given the current facts and circumstances, it is unlikely that applying any such other reasonable estimate or assumption would materially impact the financial statements.

[0001437749-25-017986:notes:50]
Cash Equivalents

[0001437749-25-017986:notes:51]
Cash equivalents consist of highly liquid instruments with maturities of three months or less that are regarded as high quality, low risk investments and are measured using such inputs as quoted prices, and are classified within Level 1 of the valuation hierarchy. Cash equivalents consist principally of certificates of deposits and money market accounts.

[0001437749-25-017986:notes:52]
Accounts Receivable

[0001437749-25-017986:notes:53]
Accounts receivable consist of amounts owed by commercial companies and government agencies. Accounts receivable are stated net of allowances for credit losses. The Company’s accounts receivable relate principally to a limited number of customers. As of  March 31, 2025, Innomotics, LLC., accounted for approximately 22% of the Company's accounts receivable balance, with no other customers accounting for greater than 10% of the balance. As of  March 31, 2024, Capital Power and INOX Wind Limited accounted for approximately 14% and 12% of the Company's accounts receivable balance, respectively, with no other customers accounting for greater than 10% of the balance. Changes in the financial condition or operations of the Company’s customers  may result in delayed payments or non-payments which would adversely impact its cash flows from operating activities and/or its results of operations. As such, the Company  may require collateral, advanced payment or other security based upon the customer history and/or creditworthiness. In determining the allowance for credit losses, the Company evaluates the collectability of accounts receivable based primarily on the probability of recoverability based on historical collection and write-off experience, the age of past due receivables, specific customer circumstances, and current economic trends. The Company has not recorded an allowance for credit losses as of each of the years ended  March 31, 2025 and 2024. If the financial condition of the Company’s customers were to deteriorate, resulting in an impairment of their ability to make payment, additional allowances  may be required. Failure to accurately estimate the losses for credit losses and ensure that payments are received on a timely basis could have a material adverse effect on the Company’s business, financial condition, results of operations, and cash flows.

[0001437749-25-017986:notes:54]
Inventory

[0001437749-25-017986:notes:55]
Inventories include material, direct labor and related manufacturing overhead, and are stated at the lower of cost, determined on a first-in, first-out basis, or net realizable value determined as the estimated selling prices in the ordinary course of business, less reasonably predictable costs of completion, disposal and transportation. The Company records inventory when it takes delivery and title to the product according to the terms of each supply contract.

[0001437749-25-017986:notes:56]
Program costs  may be deferred and recorded as inventory on contracts on which costs are incurred in excess of approved contractual amounts and/or funding, if future recovery of the costs is deemed probable.

[0001437749-25-017986:notes:57]
At each balance sheet date, the Company evaluates its ending inventories for excess quantities and obsolescence. Inventories that management considers excess or obsolete are reserved. Management considers forecasted demand in relation to the inventory on hand, competitiveness of product offerings, market conditions and product life cycles when determining excess and obsolescence and net realizable value adjustments. Once inventory is written down and a new cost basis is established, it is not written back up if demand increases.

[0001437749-25-017986:notes:58]
For the fiscal years ended  March 31, 2025 and 2024, the Company recorded inventory reserves of approximately $1.5 million and $2.0 million, respectively, based on evaluating its ending inventory on hand for excess quantities and obsolescence.

[0001437749-25-017986:notes:59]
Leases

[0001437749-25-017986:notes:60]
The Company determines whether a contract is or contains a lease at inception of a contract. The Company defines a lease as a contract, or part of a contract, that conveys the right to control the use of identified property or equipment (an identified asset) for a period of time in exchange for consideration. Control over the use of the identified asset means that the Company has both the right to obtain substantially all of the economic benefits from the use of the asset and the right to direct the use of the asset.

[0001437749-25-017986:notes:61]
Leases include all agreements in which the Company obtains control of a physical asset.  Leases are captured on the balance sheet as both a right of use asset and associated lease liability and are valued based on the commencement of the Company's control of the asset, after being discounted by its incremental borrowing rate. The Company's lease portfolio is made up primarily of real estate leases for its various offices, but also include items such as vehicles, IT equipment and other miscellaneous tools and equipment needed for manufacturing. The Company's incremental borrowing rate was determined through an analysis to identify what rates it could obtain if the Company were to secure external financing for similar transactions, and includes considerations of both the market and its current credit ratings. An analysis is performed annually, or upon execution of any individually material agreement, to ensure that the rates being applied to newly acquired leases are still accurate.

[0001437749-25-017986:notes:62]
The majority of the Company's leases are classified as operating leases, and therefore the expense is captured in operating loss from operations each period.

[0001437749-25-017986:notes:63]
The Company has elected to exclude all leases of less than twelve months from the balance sheet presentation. The Company has also elected a policy in which the Company will not segregate lease components from non-lease components, so in the event the Company executes an agreement which includes a non-lease component its asset and liability recorded to the balance sheet will include the value of that non-lease component as well.  This policy will be applied to all classifications of leases.

[0001437749-25-017986:notes:64]
Property, Plant and Equipment

[0001437749-25-017986:notes:65]
Property, plant and equipment are carried at cost less accumulated depreciation and amortization. The Company accounts for depreciation and amortization using the straight-line method to allocate the cost of property, plant and equipment over their estimated useful lives as follows:

[0001437749-25-017986:notes:66]
| Asset Classification |  | Estimated Useful Life in Years |  |
| Building |  | 40 |  |
| Equipment and software |  | 3-10 |  |
| Furniture and fixtures |  | 3-5 |  |
| Leasehold improvements |  | Shorter of the estimated useful life or the remaining lease term |  |

[0001437749-25-017986:notes:67]
Expenditures for maintenance and repairs are expensed as incurred. Upon retirement or other disposition of assets, the costs and related accumulated depreciation are eliminated from the accounts and the resulting gain or loss is reflected in operating expenses.

[0001437749-25-017986:notes:68]
Valuation of Long-Lived Assets

[0001437749-25-017986:notes:69]
The Company reviews the carrying value of its long-lived assets or asset group that is held and used, including intangible assets subject to amortization, for impairment whenever events and circumstances indicate that the carrying value of the assets  may not be recoverable. Under the held and used approach, the asset or asset group to be tested for impairment should represent the lowest level for which identifiable cash flows are largely independent of the cash flows of other groups of assets and liabilities. The Company evaluates its long-lived assets whenever events or circumstances suggest that the carrying amount of an asset or group of assets  may not be recoverable from the estimated undiscounted future cash flows.

[0001437749-25-017986:notes:70]
There was no impairment indicators during the fiscal years ended  March 31, 2025 and 2024.

[0001437749-25-017986:notes:71]
Goodwill

[0001437749-25-017986:notes:72]
Goodwill represents the excess of cost over net assets of acquired businesses that are consolidated. The Company performs its annual assessment of goodwill on  February 28th of each fiscal year and whenever events or changes in circumstances or a triggering event indicate that the carrying amount  may not be recoverable. Determining whether a triggering event has occurred often involves significant judgment from management. An entity is permitted to first assess qualitatively whether it is necessary to perform a goodwill impairment test. The quantitative impairment test is required only if the entity concludes that it is more likely than not that a reporting unit’s fair value is less than its carrying amount. The Company determines the fair value of a reporting unit, using a methodology which combines an income approach, using a discounted cash flow method, with a market approach. In evaluating whether it is more likely than not that the fair value of a reporting unit is less than its carrying amount, an entity should consider the totality of all relevant events or circumstances that affect the fair value or carrying amount of a reporting unit.  If the carrying value of a reporting unit exceeds the reporting unit’s fair value, then an impairment charge is recognized reducing the goodwill by the excess of the carrying amount over the fair value, not to exceed the total amount of the goodwill allocated to the that reporting unit. See Note 5, "Goodwill" for further information and discussion.

[0001437749-25-017986:notes:73]
The Company performed its annual assessment of goodwill on  February 28, 2025, and determined that there was no impairment to goodwill.

[0001437749-25-017986:notes:74]
Revenue Recognition

[0001437749-25-017986:notes:75]
Revenue contracts are defined as an arrangement that creates enforceable rights and obligations of both parties where collection of the contract price is deemed probable. The Company records revenue based on a five-step model which includes confirmation of contract existence, identifying the performance obligations, determining the transaction price, allocating the contract transaction price to the performance obligations, and recognizing the revenue when (or as) control of goods or services is transferred to the customer. The transfer of control  can occur at the time of delivery, installation or post-installation where applicable.

[0001437749-25-017986:notes:76]
The Company's equipment and system product line includes certain contracts which do not meet the requirements of an exchange transaction and therefore do not fall within the scope of Accounting Standards Codification ("ASC") 606.

[0001437749-25-017986:notes:77]
For certain arrangements, such as contracts to perform research and development, prototype development contracts and certain customized product sales, the Company records revenues using the over-time method, measured by the relationship of costs incurred to total estimated contract costs. Over-time revenue recognition accounting is predominantly used on certain turnkey power systems installations for electric utilities and long-term prototype development contracts with the U.S. government. The Company follows this method when any of the three following criteria are met: when the customer receives the benefits as they are performed, control transfers to the customer as the work is performed, or there is no alternative use to the Company and there is an enforceable right to payment through the life of the contract. However, the ability to reliably estimate total costs at completion is challenging, especially on long-term prototype development contracts, and could result in future changes in contract estimates. For contracts where reasonably dependable estimates of the revenues and costs cannot be made, the Company follows the point in time method. In addition, some contracts contain an element of variable consideration, including liquidated damages and/or penalties, which requires payment to the customer in the event that delivery timelines or milestones are not met. The Company estimates the total consideration payable by the customer when the contracts contain variable consideration provisions, based on the most likely amount anticipated to be recognized for transferring the promised goods or services. As a result, the Company  may constrain revenue to the extent that a significant reversal in the amount of cumulative revenue recognized will not occur until the uncertainty associated with the variable consideration is subsequently resolved.

[0001437749-25-017986:notes:78]
The Company enters into sales arrangements that  may provide for multiple performance obligations to a customer. Sales of certain products  may include extended warranty and support or service packages, and at times include performance bonds. As these contracts progress, the Company continually assesses the probability of a payout from the performance bond. Should the Company determine that such a payout is likely, the Company would record a liability. The Company would reduce revenue to the extent a liability is recorded. In addition, the Company enters into licensing arrangements that include training services.

[0001437749-25-017986:notes:79]
Performance obligations are separated into more than one unit of accounting when (1) the delivered element(s) have value to the customer on a stand-alone basis, and (2) the Company's promise to transfer the goods or services to the customer is separately identifiable from other promises in the contract.  In general, revenues are separated between the different product shipments which have stand-alone value, and the various services to be provided. Revenue for product shipments is generally recognized at a point in time where control of the product is transferred to the customer, while revenues for the services are generally recognized over the period of performance. The Company identifies all goods and/or services that are to be delivered separately under a sales arrangement and allocates the transaction price to each distinct performance obligation using the respective standalone selling price ("SSP") which is determined primarily using the cost plus expected margin approach for products and a relief from royalty method for licenses.  Revenue allocated to each performance obligation is recognized when, or as, the performance obligation is satisfied. The Company reviews SSP and the related margins at least annually. The Company has elected to recognize revenue based on the as invoiced practical expedient if there is a right to consideration from a customer in an amount that corresponds directly with the value of the Company's performance.

[0001437749-25-017986:notes:80]
The Company’s license agreements provide either for the payment of contractually determined paid-up front license fees or milestone based payments in consideration for the grant of rights to manufacture and/or sell products using its patented technologies or know-how. Some of these agreements provide for the release of the licensee from past and future intellectual property infringement claims. When the Company can determine that it has no further obligations other than the grant of the license and that the Company has fully transferred the technology know-how, the Company recognizes the revenue under a point in time model. In other license arrangements, the Company  may also agree to provide training services to transfer the technology know-how. In these arrangements, the Company has determined that the licenses have no standalone value to the customer and are not separable from training services as the Company can only fully transfer the technology know-how through the training component. Accordingly, the Company accounts for these arrangements as a single unit of accounting, and recognizes revenue over the period of its performance using the over-time method. Costs for these arrangements are expensed as incurred.

[0001437749-25-017986:notes:81]
Existing customers are subject to ongoing credit evaluations based on payment history and other factors. If it is determined that collectability of any portion of the contract value is not probable, an analysis of variable consideration will be performed using either the most likely amount or expected value method to determine the amount of revenue that must be constrained until the scenario causing the variability has been resolved. For contractual arrangements that involve variable consideration, the Company recognizes revenue for these amounts upon reaching the constraining event successfully. The Company does not generally provide for extended payment terms or provide its customers with a right of return.

[0001437749-25-017986:notes:82]
Infrequently, the Company receives requests from customers to hold product being purchased from us for a valid business purpose. The Company recognizes revenues for such arrangements provided the transaction meets, at a minimum, the following criteria: a valid business purpose for the arrangement exists; risk of ownership of the purchased product has been transferred to the buyer; there is a fixed delivery date that is reasonable and consistent with the buyer’s business purpose; the product is ready for shipment; there are no continuing performance obligation in regards to the purchased product and these products have been segregated from the Company's inventories and cannot be used to fill other orders received. During the fiscal years ended  March 31, 2025 and 2024 there were no such held transactions.

[0001437749-25-017986:notes:83]
The Company has elected to record taxes collected from customers on a net basis and does not include tax amounts in revenue or costs of revenue.

[0001437749-25-017986:notes:84]
The Company’s contract assets and liabilities primarily relate to the timing differences between cash received from a customer in connection with contractual rights to invoicing and the timing of revenue recognition following completion of performance obligations. The Company's accounts receivable balance is made up entirely of customer contract related balances.

[0001437749-25-017986:notes:85]
Business Acquisitions

[0001437749-25-017986:notes:86]
The Company accounts for acquisitions using the purchase method of accounting in accordance with ASC 805, Business Combinations. The purchase price for each acquisition is allocated to the assets acquired and liabilities assumed based on their estimated fair values at the date of acquisition. Intangible assets, if identified, are also recorded at fair value.  The excess purchase price over the estimated fair value of the net assets acquired is recorded as goodwill.

[0001437749-25-017986:notes:87]
Determining the fair value of certain assets and liabilities assumed is judgmental in nature and often involves the use of significant estimates and assumptions as well as the use of specialists as needed.

[0001437749-25-017986:notes:88]
The consideration for its acquisitions  may include future payments that are contingent upon the occurrence of a particular event. The Company records a contingent consideration obligation for such contingent consideration payments at fair value on the acquisition date. The Company estimates the fair value of contingent consideration obligations through valuation models that incorporate probability adjusted assumptions related to the achievement of the milestones and the likelihood of making related payments, refer to Note 13 for further information regarding valuation methodology and assumptions. Each period the Company revalues the contingent consideration obligations associated with the acquisition to fair value and records changes in the fair value within the operating expenses in its consolidated statements of operations. Increases or decreases in the fair value of the contingent consideration obligations can result from changes in assumed revenue risk premium and volatility, as well as changes in the stock price and assumed probability with respect to the attainment of certain financial and operational metrics, among others. Significant judgment is employed in determining these assumptions as of the acquisition date and for each subsequent period. Accordingly, future business and economic conditions, as well as changes in any of the assumptions described above, can materially impact the fair value of contingent consideration recorded at each reporting period.

[0001437749-25-017986:notes:89]
Product Warranty

[0001437749-25-017986:notes:90]
Warranty obligations are incurred in connection with the sale of the Company’s products. The Company provides assurance-type warranties on all product sales for a term of typically one to three years, and extended service-type warranties at the customers’ option for an additional term ranging up to four additional years. The Company accrues for the estimated warranty costs for assurance warranties at the time of sale based on historical warranty experience plus any known or expected changes in warranty exposure. For all extended service-type warranties, the Company recognizes the revenue ratably over time during the effective period of the service.  The costs incurred to provide for these warranty obligations are estimated and recorded as an accrued liability at the time of sale. Future warranty costs are estimated based on historical performance rates and related costs to repair given products. The accounting estimate related to product warranty involves judgment in determining future estimated warranty costs. Should actual performance rates or repair costs differ from estimates, revision to the estimated warranty liability would be required.

[0001437749-25-017986:notes:91]
Research and Development Costs

[0001437749-25-017986:notes:92]
Research and development costs are expensed as incurred.

[0001437749-25-017986:notes:93]
Income Taxes

[0001437749-25-017986:notes:94]
The Company’s provision for income taxes is comprised of a current and a deferred portion. The current income tax provision is calculated as the estimated taxes payable or refundable on tax returns for the current fiscal year. The deferred income tax provision is calculated for the estimated future tax effects attributable to temporary differences and carry-forwards using expected tax rates in effect in the years during which the differences are expected to reverse.

[0001437749-25-017986:notes:95]
Deferred income taxes are recognized for the tax consequences in future fiscal years of differences between the tax bases of assets and liabilities and their financial reporting amounts at each fiscal year end based on enacted tax laws and statutory tax rates applicable to the periods in which the differences are expected to affect taxable income. Valuation allowances are established when necessary to reduce net deferred tax assets to the amount expected to be realized. The Company has provided a valuation allowance against its U.S., Poland, and Romania deferred income tax assets since the Company believes that it is more likely than not that these deferred tax assets are not currently realizable due to uncertainty around profitability in the future.

[0001437749-25-017986:notes:96]
Accounting for income taxes requires a two-step approach to recognizing and measuring uncertain tax positions. The first step is to evaluate the tax position for recognition by determining if, based on the technical merits, it is more likely than not that the position will be sustained upon audit, including resolution of related appeals or litigation processes, if any. The second step is to measure the tax benefit as the largest amount that is more than 50% likely of being realized upon ultimate settlement. The Company reevaluates these uncertain tax positions on a quarterly basis. This evaluation is based on factors including, but not limited to, changes in facts or circumstances, changes in tax law, effectively settled issues under audit and new audit activity. Any changes in these factors could result in the recognition of a tax benefit or an additional charge to the tax provision. The Company includes interest and penalties related to gross unrecognized tax benefits within the provision for income taxes. See Note 14, “Income Taxes,” for further information regarding its income tax assumptions and expenses.

[0001437749-25-017986:notes:97]
Stock-Based Compensation

[0001437749-25-017986:notes:98]
The Company accounts for stock-based payment transactions using a fair value-based method and recognizes the related expense in the results of operations.

[0001437749-25-017986:notes:99]
Stock-based compensation is estimated at the grant date based on the fair value of the award and is recognized as expense over the requisite service period of the award. The fair value of restricted stock awards is determined by reference to the fair market value of the Company’s common stock on the date of grant. The Company uses the Black-Scholes option pricing model to estimate the fair value of option awards with service and performance conditions. For awards with service conditions only, the Company recognizes compensation cost on a straight-line basis over the requisite service/vesting period. For awards with performance conditions, estimates of compensation cost are made based on the probable outcome of the performance conditions. The cumulative effect of changes in the probability outcomes are recorded in the period in which the changes occur.

[0001437749-25-017986:notes:100]
Determining the appropriate fair value model and related assumptions requires judgment, including estimating stock price volatilities of the Company’s common stock and expected terms. The expected volatility rates are estimated based on historical and implied volatilities of the Company’s common stock. The expected term represents the average time that the options that vest are expected to be outstanding based on the vesting provisions and the Company’s historical exercise, cancellation and expiration patterns.

[0001437749-25-017986:notes:101]
The Company estimates pre-vesting forfeitures when recognizing compensation expense based on historical and forward-looking factors. Changes in estimated forfeiture rates and differences between estimated forfeiture rates and actual experience  may result in significant, unanticipated increases or decreases in stock-based compensation expense from period to period. The termination of employment of certain employees who hold large numbers of stock-based awards  may also have a significant, unanticipated impact on forfeiture experience and, therefore, on stock-based compensation expense. The Company will update these assumptions on at least an annual basis and on an interim basis if significant changes to the assumptions are warranted.

[0001437749-25-017986:notes:102]
The Company accounts for share-based payments made to non-employees in the same manner as other share-based payments for employees, with the measurement being based on the fair value at the grant date. The non-employee share based payments will be included within the Company's stock compensation currently reported.

[0001437749-25-017986:notes:103]
Equity Method Investments

[0001437749-25-017986:notes:104]
The Company treats the equity investment in the consolidated financial statements under the equity method. Equity method investments are equity securities in entities we do not control but over which we have the ability to exercise significant influence. These investments are accounted for under the equity method of accounting in accordance with ASC 323, Investments — Equity Method and Joint Ventures. Equity method investments are measured at cost minus impairment, if any, plus or minus the Company’s share of an investee’s income or loss, less distributions received.

[0001437749-25-017986:notes:105]
Computation of Net Income (Loss) per Common Share

[0001437749-25-017986:notes:106]
Basic net loss per share (“EPS”) is computed by dividing net loss by the weighted-average number of common shares outstanding for the period. Diluted EPS is computed in periods of net income, by dividing the net loss by the weighted-average number of common shares and dilutive common equivalent shares outstanding during the period, calculated using the treasury stock method. Common equivalent shares include the effect of restricted stock, exercise of stock options and warrants and contingently issuable shares. For the fiscal years ended  March 31, 2025, common equivalent shares of 468,815 were not included in the calculation of diluted EPS as they were considered antidilutive. Of these, 468,652 were shares of performance-based restricted stock where the contingency was not met, and 163 were awards that were considered anti-dilutive. For the fiscal years ended  March 31, 2024, common equivalent shares of 809,949 were not included in the calculation of diluted EPS as they were considered antidilutive. Of these, 509,949 were shares of performance-based restricted stock where the contingency was not met, and 300,000 relate to shares associated with the derivative liability for which the contingency had not yet been met. The following table reconciles the numerators and denominators of the EPS calculation for the fiscal years ended  March 31, 2025 and 2024 (in thousands except per share amounts):

[0001437749-25-017986:notes:107]
|  |  | Fiscal year ended March 31, |  |
|  |  | 2025 |  |  | 2024 |  |
| Numerator: |  |  |  |  |  |  |  |  |
| Net income (loss) |  | $ | 6,033 |  |  | $ | (11,111 | ) |
| Denominator: |  |  |  |  |  |  |  |  |
| Weighted-average shares of common stock outstanding |  |  | 38,457 |  |  |  | 31,277 |  |
| Weighted-average shares subject to repurchase |  |  | (1,467 | ) |  |  | (1,452 | ) |
| Shares used in per-share calculation ― basic |  |  | 36,990 |  |  |  | 29,825 |  |
| Shares used in per-share calculation ― diluted |  |  | 37,718 |  |  |  | 29,825 |  |
| Net loss per share ― basic |  | $ | 0.16 |  |  | $ | (0.37 | ) |
| Net loss per share ― diluted |  | $ | 0.16 |  |  | $ | (0.37 | ) |

[0001437749-25-017986:notes:108]
Foreign Currency Translation

[0001437749-25-017986:notes:109]
The functional currency of all the Company’s foreign subsidiaries is the U.S. dollar, except for AMSC Austria, for which the local currency (Euro) is the functional currency. The assets and liabilities of AMSC Austria are translated into U.S. dollars at the exchange rate in effect at the balance sheet date and income and expense items are translated at average rates for the period. Cumulative translation adjustments are excluded from net loss and shown as a separate component of stockholders’ equity. Net foreign currency gains and losses are included in other expense, net on the consolidated statements of operations and were net losses of $0.7 million, for both of the fiscal years ended  March 31, 2025 and 2024. The Company has no restrictions on the foreign exchange activities of its foreign subsidiaries, including the payment of dividends and other distributions.

[0001437749-25-017986:notes:110]
Risks and Uncertainties

[0001437749-25-017986:notes:111]
The preparation of financial statements in conformity with GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities and disclosures of contingent assets and liabilities at the date of the financial statements and the reported amounts of revenues and expenses during the reporting period. Actual results could materially differ from those estimates and would impact future results of operations and cash flows.

[0001437749-25-017986:notes:112]
The Company invests its available cash in high credit, quality financial instruments and invests primarily in investment-grade marketable securities, including, but not limited to, government obligations and money market funds.

[0001437749-25-017986:notes:113]
Several of the Company’s government contracts are being funded incrementally, and as such, are subject to the future authorization, appropriation, and availability of government funding. The Company has a history of successfully obtaining financing under incrementally-funded contracts with the U.S. government and it expects to continue to obtain additional contract modifications in the year ending  March 31, 2026 and beyond as incremental funding is authorized and appropriated by the government.

[0001437749-25-017986:notes:114]
Contingencies

[0001437749-25-017986:notes:115]
From time to time, the Company  may be involved in legal and administrative proceedings and claims of various types. The Company records a liability in its consolidated financial statements for these matters when a loss is known or considered probable and the amount can be reasonably estimated. Management reviews these estimates in each accounting period as additional information is known and adjusts the loss provision when appropriate. If the loss is not probable or cannot be reasonably estimated, a liability is not recorded in the consolidated financial statements. If, with respect to a matter, it is not both probable to result in liability and the amount of loss cannot be reasonably estimated, an estimate of possible loss or range of loss is disclosed unless such an estimate cannot be made. The Company does not recognize gain contingencies until they are realized. Legal costs incurred in connection with loss contingencies are expensed as incurred. See Note 18, “Commitments and Contingencies,” for further information.

[0001437749-25-017986:notes:116]
Disclosure of Fair Value of Financial Instruments

[0001437749-25-017986:notes:117]
The Company’s financial instruments consist principally of cash and cash equivalents, restricted cash, accounts receivable, accounts payable, accrued expenses, and contingent consideration. The carrying amounts of cash and cash equivalents, restricted cash, accounts receivable, short-term debt, accounts payable, and accrued expenses due to their short nature approximate fair value at  March 31, 2025 and 2024. The estimated fair values have been determined through information obtained from market sources and management estimates. Changes in fair value are recorded to other income (expense), net. The fair value for the contingent consideration is estimated using a Monte Carlo simulation and subject to revaluation at each balance sheet date. The Company classifies the estimates used to fair value these instruments as Level 3 inputs. See Note 6, “Fair Value Measurements” for a full discussion on fair value measurements.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001437749-25-017986:notes:118]
4. Revenue Recognition

[0001437749-25-017986:notes:119]
The Company’s revenues in its Grid segment are derived primarily through enabling the transmission and distribution of power, providing planning services that allow it to identify power grid needs and risks, and developing ship protection systems for the U.S. Navy. The Company’s revenues in its Wind segment are derived primarily through supplying advanced power electronics and control systems, licensing its highly engineered wind turbine designs, and providing extensive customer support services to wind turbine manufacturers. The Company records revenue based on a five-step model in accordance with ASC 606. For its customer contracts, the Company identifies the performance obligations, determines the transaction price, allocates the contract transaction price to the performance obligations, and recognizes the revenue when (or as) control of goods or services is transferred to the customer. For the fiscal year ended  March 31, 2025, 88% of revenue was recognized at the point in time when control transferred to the customer, with the remainder being recognized over time. For the fiscal year ended  March 31, 2024, 80% of revenue was recognized at the point in time when control transferred to the customer, with the remainder being recognized over time.

[0001437749-25-017986:notes:120]
In the Company's equipment and system product line, each contract with a customer summarizes each product sold to a customer, which typically represents distinct performance obligations. A contract's transaction price is allocated to each distinct performance obligation using the respective standalone selling price which is determined primarily using the cost plus expected margin approach and recognized as revenue when, or as, the performance obligation is satisfied. The majority of the Company’s product sales transfer control to the customer in line with the contracted delivery terms and revenue is recorded at the point in time when title and risk transfer to the customer, which is primarily upon delivery, as the Company has determined that this is the point in time that control transfers to the customer.

[0001437749-25-017986:notes:121]
In the Company's service and technology development product line, there are several different types of transactions and each begins with a contract with a customer that summarizes each product sold to a customer, which typically represents distinct performance obligations. The technology development transactions are primarily for activities that have no alternative use and for which a profit can be expected throughout the life of the contract. In these cases, the revenue is recognized over time, but in the instances where the profit cannot be assured throughout the entire contract then the revenue is recognized at a point in time. Each contract's transaction price is allocated to each distinct performance obligation using the respective standalone selling price which is determined primarily using the cost plus expected margin approach. The ongoing service transactions are for service contracts that provide benefit to the customer simultaneously as the Company performs its obligations, and therefore this revenue is recognized ratably over time throughout the effective period of these contracts. The transaction prices on these contracts are allocated based on an adjusted market approach which is re-assessed annually for reasonableness. The field service transactions include contracts for delivery of goods and completion of services made at the customer's requests, which are not deemed satisfied until the work has been completed and/or the requested goods have been delivered, so all of this revenue is recognized at the point in time when the control changes, and at allocated prices based on the adjusted market approach driven by standard price lists. The royalty transactions are related to certain contract terms on transactions in the Company's equipment and systems product line based on activity as specified in the contracts. The transaction prices of these agreements are calculated based on an adjusted market approach as specified in the contract. The Company reports royalty revenue for usage-based royalties when the sales have occurred. In circumstances when collectability is not assured and a contract does not exist under ASC 606, revenue is deferred until a non-refundable payment has been received for substantially all the amount that is due and there are no further remaining performance obligations.

[0001437749-25-017986:notes:122]
The Company's service contracts can include a purchase order from a customer for specific goods in which each item is a distinct performance obligation satisfied at a point in time at which control of the goods is transferred to the customer. This transfer occurs based on the contracted delivery terms or when the requested service work has been completed. The transaction price for these goods is allocated based on the adjusted market approach considering similar transactions under similar circumstances. Service contracts are also derived from ongoing maintenance contracts and extended service-type warranty contracts. In these transactions, the Company is contracted to provide an ongoing service over a specified period of time. As the customer is consuming the benefits as the service is being provided the revenue is recognized over time ratably.

[0001437749-25-017986:notes:123]
The Company’s policy is not to accept volume discounts, product returns, or rebates and allowances within its contracts. In the event a contract was approved with any of these terms, it would be evaluated for variable consideration, estimated and recorded as a reduction of revenue in the same period the related product revenue was recorded.

[0001437749-25-017986:notes:124]
The Company provides assurance-type warranties on all product sales for a term of typically one to three years, and extended service-type warranties are available for purchase at the customer's option for an additional term ranging up to four additional years. The Company accrues for the estimated warranty costs for assurance warranties at the time of sale based on historical warranty experience plus any known or expected changes in warranty exposure. For all extended service-type warranties, the Company recognizes the revenue ratably over time during the effective period of the services.

[0001437749-25-017986:notes:125]
The Company records revenue net of sales tax, value added tax, excise tax and other taxes collected concurrent with revenue-producing activities. The Company has elected to recognize the cost for freight and shipping when control over the products sold passes to customers and revenue is recognized. The Company has elected to recognize incremental costs of obtaining a contract as expense when incurred except in contracts where the amortization period would exceed twelve months. As of  March 31, 2025 and 2024, the Company's capitalized incremental contract costs were not material. The Company has elected not to adjust the promised amount of consideration for the effects of a significant financing component if the period of financing is twelve months or less. The Company has elected to recognize revenue based on the as invoiced practical expedient if there is a right to consideration from a customer in an amount that corresponds directly with the value of the Company's performance.

[0001437749-25-017986:notes:126]
The Company’s contracts with customers do not typically include extended payment terms and  may include milestone billing over the life of the contract. Payment terms vary by contract type and type of customer and generally range from 30 to 60 days from delivery.

[0001437749-25-017986:notes:127]
The following tables disaggregate the Company’s revenue by product line and by shipment destination (in thousands):

[0001437749-25-017986:notes:128]
|  |  | Year Ended March 31, 2025 |  |
| Product Line: |  | Grid |  |  | Wind |  |
| Equipment and systems |  | $ | 175,117 |  |  | $ | 34,079 |  |
| Services and technology development |  |  | 12,053 |  |  |  | 1,569 |  |
| Total |  | $ | 187,170 |  |  | $ | 35,648 |  |
| Region: |  |  |  |  |  |  |  |  |
| Americas |  | $ | 169,886 |  |  | $ | 2 |  |
| Asia Pacific |  |  | 7,392 |  |  |  | 35,608 |  |
| EMEA |  |  | 9,892 |  |  |  | 38 |  |
| Total |  | $ | 187,170 |  |  | $ | 35,648 |  |

[0001437749-25-017986:notes:129]
|  |  | Year Ended March 31, 2024 |  |
| Product Line: |  | Grid |  |  | Wind |  |
| Equipment and systems |  | $ | 112,829 |  |  | $ | 21,211 |  |
| Services and technology development |  |  | 9,236 |  |  |  | 2,363 |  |
| Total |  | $ | 122,065 |  |  | $ | 23,574 |  |
| Region: |  |  |  |  |  |  |  |  |
| Americas |  | $ | 107,036 |  |  | $ | 102 |  |
| Asia Pacific |  |  | 9,768 |  |  |  | 23,404 |  |
| EMEA |  |  | 5,261 |  |  |  | 68 |  |
| Total |  | $ | 122,065 |  |  | $ | 23,574 |  |

[0001437749-25-017986:notes:130]
As of  March 31, 2025 and  March 31, 2024, the Company’s contract assets and liabilities primarily relate to the timing differences between cash received from a customer in connection with contractual rights to invoicing and the timing of revenue recognition following completion of performance obligations. The Company's accounts receivable balance is made up entirely of customer contract related balances. Changes in the Company’s contract assets, which are included in “Unbilled accounts receivable” and “Deferred program costs” (see Note 7, “Accounts Receivable” and Note 8, “Inventory” for a reconciliation to the consolidated balance sheets) and "Contract liabilities", which are included in the current portion and long term portion of “Deferred revenue” in the Company’s consolidated balance sheets, are as follows (in thousands):

[0001437749-25-017986:notes:131]
|  |  | Unbilled AR |  |  | Deferred Program Costs |  |  | Contract Liabilities |  |
| Beginning balance as of March 31, 2024 |  | $ | 6,150 |  |  | $ | 2,523 |  |  | $ | 57,829 |  |
| Increases for balances acquired |  |  | — |  |  |  | — |  |  |  | 5,049 |  |
| Increases for costs incurred to fulfill performance obligations |  |  | — |  |  |  | 16,363 |  |  |  | — |  |
| Increase (decrease) due to customer billings |  |  | (8,754 | ) |  |  | — |  |  |  | 120,533 |  |
| Decrease due to cost recognition on completed performance obligations |  |  | — |  |  |  | (13,131 | ) |  |  | — |  |
| Increase (decrease) due to recognition of revenue based on transfer of control of performance obligations |  |  | 8,981 |  |  |  | — |  |  |  | (107,211 | ) |
| Other changes and foreign currency exchange impact |  |  | (1 | ) |  |  | 1 |  |  |  | (67 | ) |
| Ending balance as of March 31, 2025 |  | $ | 6,376 |  |  | $ | 5,756 |  |  | $ | 76,133 |  |

[0001437749-25-017986:notes:132]
|  |  | Unbilled AR |  |  | Deferred Program Costs |  |  | Contract Liabilities |  |
| Beginning balance as of March 31, 2023 |  | $ | 9,958 |  |  | $ | 2,136 |  |  | $ | 50,760 |  |
| Increases for costs incurred to fulfill performance obligations |  |  | — |  |  |  | 4,411 |  |  |  | — |  |
| Increase (decrease) due to customer billings |  |  | (20,392 | ) |  |  | — |  |  |  | 77,685 |  |
| Decrease due to cost recognition on completed performance obligations |  |  | — |  |  |  | (4,021 | ) |  |  | — |  |
| Increase (decrease) due to recognition of revenue based on transfer of control of performance obligations |  |  | 16,572 |  |  |  | — |  |  |  | (70,529 | ) |
| Other changes and foreign currency exchange impact |  |  | 12 |  |  |  | (3 | ) |  |  | (87 | ) |
| Ending balance as of March 31, 2024 |  | $ | 6,150 |  |  | $ | 2,523 |  |  | $ | 57,829 |  |

[0001437749-25-017986:notes:133]
The Company’s remaining performance obligations represent the unrecognized revenue value of the Company’s contractual commitments. The Company’s performance obligations  may vary significantly each reporting period based on the timing of major new contractual commitments. As of  March 31, 2025, the Company had outstanding performance obligations on existing contracts under ASC 606 to be recognized in the next twelve months of approximately $200.9 million. There are also approximately $109.4 million of outstanding performance obligations to be recognized over a period of thirteen to sixty months. The remaining performance obligations are subject to customer actions and therefore the timing of revenue recognition cannot be reasonably estimated.

[0001437749-25-017986:notes:134]
The following table sets forth customers who represented 10% or more of the Company’s total revenues for the years ended  March 31, 2025 and 2024:

[0001437749-25-017986:notes:135]
|  |  |  | Year Ended |  |
|  | Reportable |  | March 31, |  |
|  | Segment |  | 2025 |  |  | 2024 |  |
| Inox Wind Limited | Wind |  |  | 14 | % |  | 13 | % |


## us-gaap:GoodwillDisclosureTextBlock

[0001437749-25-017986:notes:136]
5. Goodwill

[0001437749-25-017986:notes:137]
The guidance under ASC 805-30, Business Combinations, provides for the recognition of goodwill on the acquisition date measured as the excess of the aggregate consideration transferred over the net of the acquisition date amounts of net assets acquired and liabilities assumed. The Company's goodwill balance relates to the NWL acquisition in fiscal 2024, the Neeltran acquisition in fiscal 2021, the NEPSI acquisition in fiscal 2020, and Infinia Technology Corporation acquisition in fiscal 2017 and is reported in the Grid business segment.

[0001437749-25-017986:notes:138]
Goodwill represents the difference between the purchase price and the fair value of the identifiable tangible and intangible net assets when accounted for using the purchase method of accounting. Goodwill is not amortized but reviewed for impairment. Goodwill is reviewed annually on  February 28th and whenever events or changes in circumstances indicate that the carrying value of the goodwill might not be recoverable. Goodwill increased by $4.7 million during the fiscal year ended  March 31, 2025, related to the NWL acquisition. This includes a $0.8 million adjustment related to the true up of the deferred tax asset consisting primarily of tax basis differences identified through NWL's final pre-acquisition tax returns. There were no changes to Goodwill during the fiscal year ended  March 31, 2024.

[0001437749-25-017986:notes:139]
The Company performed its annual assessment of goodwill on  February 28, 2025 and determined that there was no impairment to goodwill.


## us-gaap:FairValueDisclosuresTextBlock

[0001437749-25-017986:notes:140]
6. Fair Value Measurements

[0001437749-25-017986:notes:141]
A valuation hierarchy for disclosure of the inputs to valuation used to measure fair value has been established. This hierarchy prioritizes the inputs into three broad levels as follows:

[0001437749-25-017986:notes:142]
| Level 1 | - | Inputs are unadjusted quoted prices in active markets for identical assets or liabilities that the Company has the ability to access at the measurement date. |
| Level 2 | - | Inputs include quoted prices for similar assets and liabilities in active markets, quoted prices for identical or similar assets or liabilities in markets that are not active, inputs other than quoted prices that are observable for the asset or liability, and inputs that are derived principally from or corroborated by observable market data by correlation or other means (market corroborated inputs). |
| Level 3 | - | Unobservable inputs that reflect the Company’s assumptions that market participants would use in pricing the asset or liability. The Company develops these inputs based on the best information available, including its own data. |

[0001437749-25-017986:notes:143]
The Company provides a gross presentation of activity within Level 3 measurement roll-forward and details of transfers in and out of Level 1 and 2 measurements.  A change in the hierarchy of an investment from its current level is reflected in the period during which the pricing methodology of such investment changes.  Disclosure of the transfer of securities from Level 1 to Level 2 or Level 3 is made in the event that the related security is significant to total cash and investments.  The Company did not have any transfers of assets and liabilities from Level 1, Level 2 or Level 3 of the fair value measurement hierarchy during the year ended  March 31, 2025.

[0001437749-25-017986:notes:144]
A financial asset’s or liability’s classification within the hierarchy is determined based on the lowest level input that is significant to the fair value measurement.

[0001437749-25-017986:notes:145]
Valuation Techniques

[0001437749-25-017986:notes:146]
Cash equivalents consist of highly liquid instruments with maturities of three months or less that are regarded as high quality, low risk investments and are measured using such inputs as quoted prices, and are classified within Level 1 of the valuation hierarchy. Cash equivalents consist principally of money market accounts.

[0001437749-25-017986:notes:147]
Short-term Cash Instruments

[0001437749-25-017986:notes:148]
Short-term cash instruments consist of highly liquid instruments with maturities of three months or less that are regarded as high quality, low risk investments and are measured using such inputs as quoted prices in markets that are not active, and are classified within Level 2 of the valuation hierarchy. Short-term cash instruments consist principally of certificates of deposits.

[0001437749-25-017986:notes:149]
Contingent Consideration

[0001437749-25-017986:notes:150]
Contingent consideration relates to the earnout payment set forth in the Stock Purchase Agreement governing the acquisition of Northeast Power Systems, Inc ("NEPSI") that provided that NEPSI could receive up to an additional 1,000,000 shares of common stock of the Company upon the achievement of certain specified revenue objectives over varying periods of up to four years following the NEPSI Acquisition Date which concluded in  September of 2024. The Megatran Stock Purchase Agreement provided that the selling stockholders would be made whole as set forth in the agreement. We classified contingent consideration related to certain acquisitions within level 3 of the fair value hierarchy because the fair value is derived using significant unobservable inputs, which include revenue risk premium and revenue volatility. See Note 13, "Contingent Consideration" for further discussion. As of  September 30, 2024, the Company had settled all outstanding contingent consideration.

[0001437749-25-017986:notes:151]
The following table provides the assets and liabilities carried at fair value on a recurring basis, measured as of  March 31, 2025 and 2024 (in thousands):

[0001437749-25-017986:notes:152]
|  |  | Total Carrying Value |  |  | Quoted Prices in Active Markets (Level 1) |  |  | Significant Other Observable Inputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |
| March 31, 2025: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash equivalents |  | $ | 51,230 |  |  | $ | 51,230 |  |  | $ | — |  |  | $ | — |  |
| Short-term cash instruments |  | $ | 1,404 |  |  | $ | — |  |  | $ | 1,404 |  |  | $ | — |  |

[0001437749-25-017986:notes:153]
|  |  | Total Carrying Value |  |  | Quoted Prices in Active Markets (Level 1) |  |  | Significant Other Observable Inputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |
| March 31, 2024: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash equivalents |  | $ | 71,392 |  |  | $ | 71,392 |  |  | $ | — |  |  | $ | — |  |
| Short-term cash instruments |  | $ | 1,440 |  |  | $ | — |  |  | $ | 1,440 |  |  | $ | — |  |
| Derivative liabilities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Contingent Consideration |  | $ | 3,100 |  |  | $ | — |  |  | $ | — |  |  | $ | 3,100 |  |

[0001437749-25-017986:notes:154]
The table below reflects the activity for the Company’s contingent consideration derivative liability measured at fair value on a recurring basis (in thousands):

[0001437749-25-017986:notes:155]
|  |  | NEPSI Acquisition Contingent Consideration |  |  | NWL Acquisition Contingent Consideration |  |
| Balance at March 31, 2023 |  | $ | 1,270 |  |  | $ | — |  |
| Change in fair value |  |  | 4,922 |  |  |  | — |  |
| Settlement of contingent consideration |  |  | (3,092 | ) |  |  | — |  |
| Balance at March 31, 2024 |  | $ | 3,100 |  |  | $ | — |  |
| Change in fair value |  |  | 3,404 |  |  |  | 3,278 |  |
| Settlement of contingent consideration |  |  | (6,504 | ) |  |  | (3,278 | ) |
| Balance at March 31, 2025 |  | $ | - |  |  | $ | - |  |


## amsc:AccountsReceivableTextBlock

[0001437749-25-017986:notes:156]
7. Accounts Receivable

[0001437749-25-017986:notes:157]
Accounts receivable at  March 31, 2025 and  March 31, 2024 consisted of the following (in thousands):

[0001437749-25-017986:notes:158]
|  |  | March 31, 2025 |  |  | March 31, 2024 |  |
| Accounts receivable (billed) |  | $ | 39,810 |  |  | $ | 20,175 |  |
| Accounts receivable (unbilled) |  |  | 6,376 |  |  |  | 6,150 |  |
| Accounts receivable |  | $ | 46,186 |  |  | $ | 26,325 |  |


## us-gaap:InventoryDisclosureTextBlock

[0001437749-25-017986:notes:159]
8. Inventory

[0001437749-25-017986:notes:160]
Inventory, net of reserves, at  March 31, 2025 and  March 31, 2024 consisted of the following (in thousands):

[0001437749-25-017986:notes:161]
|  |  | March 31, 2025 |  |  | March 31, 2024 |  |
| Raw materials |  | $ | 35,892 |  |  | $ | 20,622 |  |
| Work-in-process |  |  | 19,633 |  |  |  | 14,872 |  |
| Finished goods |  |  | 9,888 |  |  |  | 3,840 |  |
| Deferred program costs |  |  | 5,756 |  |  |  | 2,523 |  |
| Inventory |  | $ | 71,169 |  |  | $ | 41,857 |  |

[0001437749-25-017986:notes:162]
The Company recorded inventory write-downs of $1.5 million and $2.0 million for the fiscal years ended  March 31, 2025 and 2024, respectively. These write-downs were based on the Company's evaluation on its inventory on hand for excess quantities and obsolescence.

[0001437749-25-017986:notes:163]
Deferred program costs as of  March 31, 2025 and  March 31, 2024 primarily represent costs incurred on programs where the Company needs to complete performance obligations before the related revenue and costs will be recognized.


## us-gaap:PropertyPlantAndEquipmentDisclosureTextBlock

[0001437749-25-017986:notes:164]
9. Property, Plant and Equipment

[0001437749-25-017986:notes:165]
The cost and accumulated depreciation of property, plant and equipment at  March 31, 2025 and 2024 are as follows (in thousands):

[0001437749-25-017986:notes:166]
|  |  | March 31, 2025 |  |  | March 31, 2024 |  |
| Land |  | $ | 22,650 |  |  | $ | 980 |  |
| Construction in progress - equipment |  |  | 1,371 |  |  |  | 226 |  |
| Buildings |  |  | 7,528 |  |  |  | 5,416 |  |
| Equipment and software |  |  | 47,774 |  |  |  | 44,095 |  |
| Furniture and fixtures |  |  | 1,672 |  |  |  | 1,526 |  |
| Leasehold improvements |  |  | 7,969 |  |  |  | 6,990 |  |
| Property, plant and equipment, gross |  |  | 88,964 |  |  |  | 59,233 |  |
| Less accumulated depreciation |  |  | (50,392 | ) |  |  | (48,372 | ) |
| Property, plant and equipment, net |  | $ | 38,572 |  |  | $ | 10,861 |  |

[0001437749-25-017986:notes:167]
Depreciation expense was $3.1 million and $2.3 million, for the fiscal years ended  March 31, 2025 and 2024, respectively. The increase in land relates to the property added as part of the NWL Acquisition.


## us-gaap:IntangibleAssetsDisclosureTextBlock

[0001437749-25-017986:notes:168]
10. Intangible Assets

[0001437749-25-017986:notes:169]
Intangible assets at  March 31, 2025 and 2024 consisted of the following (in thousands):

[0001437749-25-017986:notes:170]
|  |  | 2025 |  |  | 2024 |  |  |  |  |
|  |  | Gross Amount |  |  | Accumulated Amortization |  |  | Net Book Value |  |  | Gross Amount |  |  | Accumulated Amortization |  |  | Net Book Value |  |  | Estimated Useful Life |  |
| Backlog |  |  | 1,381 |  |  |  | (1,381 | ) |  |  | — |  |  |  | 681 |  |  |  | (681 | ) |  |  | - |  |  | 2 |  |
| Trade names and trademarks |  |  | 1,800 |  |  |  | — |  |  |  | 1,800 |  |  |  | 1,800 |  |  |  | — |  |  |  | 1,800 |  |  | Indefinite |  |
| Customer relationships |  |  | 10,880 |  |  |  | (7,901 | ) |  |  | 2,980 |  |  |  | 9,600 |  |  |  | (6,649 | ) |  |  | 2,951 |  |  | 7-10 |  |
| Core technology and know-how |  |  | 5,970 |  |  |  | (4,834 | ) |  |  | 1,136 |  |  |  | 5,970 |  |  |  | (4,352 | ) |  |  | 1,618 |  |  | 5-10 |  |
| Intangible assets |  | $ | 20,031 |  |  | $ | (14,116 | ) |  | $ | 5,916 |  |  | $ | 18,051 |  |  | $ | (11,682 | ) |  | $ | 6,369 |  |  |  |  |

[0001437749-25-017986:notes:171]
The Company recorded intangible amortization expense of $2.4 million and $2.2 million, for the fiscal years ended  March 31, 2025 and 2024, respectively. Included in the current period is $0.7 million related to intangible amortization related to backlog that is reported in cost of revenues for the fiscal year ended  March 31, 2025 and less than $0.1 million for the fiscal year ended  March 31, 2024.

[0001437749-25-017986:notes:172]
Expected future amortization expense related to intangible assets is as follows (in thousands):

[0001437749-25-017986:notes:173]
| Fiscal years ending March 31, |  | Total |  |
| 2026 |  | $ | 1,349 |  |
| 2027 |  |  | 1,213 |  |
| 2028 |  |  | 671 |  |
| 2029 |  |  | 201 |  |
| 2030 |  |  | 128 |  |
| Thereafter |  |  | 554 |  |
| Total |  | $ | 4,116 |  |

[0001437749-25-017986:notes:174]
The Company's intangible assets relate entirely to the Grid business segment operations in the United States.


## us-gaap:EquityMethodInvestmentsDisclosureTextBlock

[0001437749-25-017986:notes:175]
11. Equity-Method Investments

[0001437749-25-017986:notes:176]
Investment in NWL Pacific Inc. Co., LTD

[0001437749-25-017986:notes:177]
The Company has a 50% ownership in NWL Pacific Inc. Co., LTD ("NWL Pacific"). The investment represents the Company's interest in NWL Pacific. The investment is a joint venture in South Korea established on  May 12, 1998.

[0001437749-25-017986:notes:178]
The Company treats the equity investment in the consolidated financial statements under the equity method. Equity method investments are equity securities in entities the Company does not control but over which it has the ability to exercise significant influence. These investments are accounted for under the equity method of accounting in accordance with ASC 323, Investments — Equity Method and Joint Ventures. Equity method investments are measured at cost minus impairment, if any, plus or minus the Company’s share of an investee’s income or loss, less distributions received. As of  March 31, 2025 the Company did not have material accounts receivable nor accounts payable balances with NWL Pacific.

[0001437749-25-017986:notes:179]
The tables below present the summarized financial information from the Acquisition Date through  March 31, 2025, as provided to the Company by the investee, for the unconsolidated company (in thousands):

[0001437749-25-017986:notes:180]
|  |  | Fiscal year ended March 31, |  |
|  |  | 2025 |  |
| Net Revenue |  | $ | 3,702 |  |
| Gross Profit |  |  | 1,483 |  |
| Income from operations |  |  | 490 |  |
| Net income |  |  | 474 |  |

[0001437749-25-017986:notes:181]
|  |  | Balance at March 31, |  |
|  |  | 2025 |  |
| Current Assets |  | $ | 5,423 |  |
| Noncurrent Assets |  |  | 377 |  |
| Current Liabilities |  |  | 2,336 |  |
| Noncurrent Liabilities |  |  | 42 |  |


## us-gaap:AccountsPayableAndAccruedLiabilitiesDisclosureTextBlock

[0001437749-25-017986:notes:182]
12. Accounts Payable and Accrued Expenses

[0001437749-25-017986:notes:183]
Accounts payable and accrued expenses at  March 31, 2025 and  March 31, 2024 consisted of the following (in thousands):

[0001437749-25-017986:notes:184]
|  |  | March 31, 2025 |  |  | March 31, 2024 |  |
| Accounts payable |  | $ | 6,733 |  |  | $ | 4,476 |  |
| Accrued inventories in-transit |  |  | 2,111 |  |  |  | 539 |  |
| Accrued other miscellaneous expenses |  |  | 3,600 |  |  |  | 2,366 |  |
| Accrued contract loss |  |  | 97 |  |  |  | 97 |  |
| Advanced deposits |  |  | 1,267 |  |  |  | 2,270 |  |
| Accrued compensation |  |  | 13,418 |  |  |  | 10,326 |  |
| Income taxes payable |  |  | 305 |  |  |  | 346 |  |
| Accrued product warranty |  |  | 3,033 |  |  |  | 2,363 |  |
| Accrued commissions |  |  | 1,718 |  |  |  | 1,452 |  |
| Total |  | $ | 32,282 |  |  | $ | 24,235 |  |

[0001437749-25-017986:notes:185]
The Company generally provides a one to three year warranty on its products, commencing upon delivery or installation where applicable. A provision is recorded upon revenue recognition to cost of revenues for estimated warranty expense based on historical experience.

[0001437749-25-017986:notes:186]
Product warranty activity was as follows (in thousands):

[0001437749-25-017986:notes:187]
|  |  | Fiscal Years Ended March 31, |  |
|  |  | 2025 |  |  | 2024 |  |
| Balance at beginning of period |  | $ | 2,363 |  |  | $ | 2,638 |  |
| Acquired warranty obligations |  |  | 637 |  |  |  | - |  |
| Provisions for warranties during the period |  |  | 1,641 |  |  |  | 1,751 |  |
| Settlements during the period |  |  | (1,608 | ) |  |  | (2,026 | ) |
| Balance at end of period |  | $ | 3,033 |  |  | $ | 2,363 |  |


## amsc:BusinessCombinationContingentConsiderationTextBlock

[0001437749-25-017986:notes:188]
13. Contingent Consideration

[0001437749-25-017986:notes:189]
NEPSI Contingent Consideration

[0001437749-25-017986:notes:190]
On  October 1, 2020 (the "NEPSI Acquisition Date"), the Company entered into a Stock Purchase Agreement (the "NEPSI Stock Purchase Agreement") with the selling stockholders named therein. Pursuant to the terms of the NEPSI Stock Purchase Agreement and concurrently with entering into such agreement, the Company acquired all of the issued and outstanding (i) shares of capital stock of NEPSI, and (ii) membership interests of Northeast Power Realty, LLC, a New York limited liability company, which holds the real property that serves as NEPSI's headquarters (the "NEPSI Acquisition"). NEPSI is a U.S.-based global provider of medium-voltage metal-enclosed power capacitor banks and harmonic filter banks for use on electric power systems. NEPSI is a wholly-owned subsidiary of the Company and is operated by its Grid business segment. The purchase price was $26.0 million in cash and 873,657 restricted shares of common stock of the Company. As part of the transaction, the selling stockholders were entitled to receive up to an additional 1,000,000 shares of common stock of the Company upon the achievement of certain specified revenue objectives during varying periods of up to four years following closing of the NEPSI Acquisition. During the year ended  March 31, 2024, the Company issued 399,999 shares of common stock and cash in lieu of a fractional share of common stock, related to the achievement of specified revenue objectives in connection with the NEPSI Acquisition. One specified revenue objective, which would have earned the selling stockholders 300,000 shares of Company common stock, was not achieved. NEPSI recognized revenues in excess of $120.0 million during the four years after the NEPSI Acquisition Date. As a result, during the quarter ended  September 30, 2024, the Company issued 300,000 shares of common stock of the Company to the selling stockholders, following certification of the achievement of the specified earnout revenue objective. As of  September 30, 2024, the Company had settled all outstanding contingent consideration under the NEPSI Stock Purchase Agreement.

[0001437749-25-017986:notes:191]
The Company evaluated the NEPSI Acquisition earnout payment set forth in the NEPSI Stock Purchase Agreement, which was expected to require settlement in the Company's common stock, and determined the contingent consideration qualified for liability classification and derivative treatment under ASC 815, Derivatives and Hedging. As a result, for the periods in which the Company had outstanding contingent consideration, the fair value of the contingent consideration was remeasured and the resulting gain or loss was recognized in operating expenses until the share amount was fixed.

[0001437749-25-017986:notes:192]
The following is a summary of the key assumptions used in a Monte Carlo simulation to calculate the fair value of the contingent consideration related to the NEPSI Acquisition:

[0001437749-25-017986:notes:193]
| Fiscal Year 2024 |  | June 30, 2024 |  |
| Revenue risk premium |  |  | 5.50 | % |
| Revenue volatility |  |  | 27.5 | % |
| Stock Price |  | $ | 23.39 |  |
| Payment delay (days) |  |  | 80 |  |
| Fair value (millions) |  | $ | 7.0 |  |

[0001437749-25-017986:notes:194]
During the fiscal year ended  March 31, 2025, the Company issued 300,000 shares of common stock related to the achievement of specified revenue objectives at a fair value of $6.5 million. The Company recorded a loss of $3.4 million for the increase in the fair value of the contingent consideration in the year ended  March 31, 2025. The Company recorded a loss of $4.9 million for the increase in the fair value of the contingent consideration in the year ended  March 31, 2024.

[0001437749-25-017986:notes:195]
NWL Contingent Consideration

[0001437749-25-017986:notes:196]
On  August 1, 2024, the Company entered into the Stock Purchase Agreement with the selling stockholders of NWL named therein. Pursuant to the terms of the Stock Purchase Agreement and concurrently with entering into such agreement, the Company acquired all of the issued and outstanding shares of Megatran for aggregate consideration in an amount equal to $61.4 million which consideration amount was subject to various adjustments set forth in the Stock Purchase Agreement. The value of the contingent consideration to make the sellers whole was determined to be de minimis at the time of the Acquisition. On  September 23, 2024, the Company paid $3.3 million to the selling stockholders, which was calculated based on the agreed upon formula set forth in the Stock Purchase Agreement. This amount is reflected as the change in fair value of this contingent consideration in the fiscal year ended  March 31, 2025. As of  September 30, 2024, there were no remaining obligations to the selling stockholders of NWL.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001437749-25-017986:notes:197]
14. Income Taxes

[0001437749-25-017986:notes:198]
(Loss) income before income taxes for the fiscal years ended  March 31, 2025, and 2024 are provided in the table as follows (in thousands):

[0001437749-25-017986:notes:199]
|  |  | Fiscal years ended March 31, |  |
|  |  | 2025 |  |  | 2024 |  |
| Income/(Loss) before income tax expense: |  |  |  |  |  |  |  |  |
| U.S. |  | $ | 1,882 |  |  | $ | (11,503 | ) |
| Foreign |  |  | 484 |  |  |  | 701 |  |
| Total |  | $ | 2,366 |  |  | $ | (10,802 | ) |

[0001437749-25-017986:notes:200]
The components of income tax expense (benefit) consist of the following (in thousands):

[0001437749-25-017986:notes:201]
|  |  | Fiscal years ended March 31, |  |
|  |  | 2025 |  |  | 2024 |  |
| Current |  |  |  |  |  |  |  |  |
| Federal |  | $ | 305 |  |  | $ | 150 |  |
| State |  |  | 222 |  |  |  | — |  |
| Foreign |  |  | 110 |  |  |  | 94 |  |
| Total current |  |  | 637 |  |  |  | 244 |  |
| Deferred |  |  |  |  |  |  |  |  |
| Federal |  |  | (4,259 | ) |  |  | 56 |  |
| State |  |  | (13 | ) |  |  | — |  |
| Foreign |  |  | (32 | ) |  |  | 9 |  |
| Total deferred |  |  | (4,304 | ) |  |  | 65 |  |
| Income tax expense (benefit) |  | $ | (3,667 | ) |  | $ | 309 |  |

[0001437749-25-017986:notes:202]
The reconciliation between the statutory federal income tax rate and the Company’s effective income tax rate is shown below.

[0001437749-25-017986:notes:203]
|  |  | Fiscal years ended March 31, |  |
|  |  | 2025 |  |  | 2024 |  |
| Statutory federal income tax rate |  |  | (21 | )% |  |  | (21 | )% |
| State income taxes, net of federal benefit |  |  | (35 | ) |  |  | (7 | ) |
| Foreign income tax rate differential |  |  | (2 | ) |  |  | (2 | ) |
| Stock options |  |  | (54 | ) |  |  | — |  |
| Research and development tax credit |  |  | — |  |  |  | (4 | ) |
| Mark to market adjustment on contingent consideration |  |  | 59 |  |  |  | (10 | ) |
| Nondeductible expenses |  |  | 12 |  |  |  | — |  |
| True-up of NOLs |  |  | 10 |  |  |  | (58 | ) |
| Withholding Tax |  |  | 16 |  |  |  | — |  |
| 162(m) |  |  | 43 |  |  |  | — |  |
| Other |  |  | 4 |  |  |  | (4 | ) |
| Valuation allowance |  |  | (231 | ) |  |  | 60 |  |
| Effective income tax rate |  |  | 155 | % |  |  | 3 | % |

[0001437749-25-017986:notes:204]
The following is a summary of the principal components of the Company’s deferred tax assets and liabilities (in thousands):

[0001437749-25-017986:notes:205]
|  |  | March 31, 2025 |  |  | March 31, 2024 |  |
| Deferred tax assets: |  |  |  |  |  |  |  |  |
| Net operating loss carryforwards |  | $ | 150,703 |  |  | $ | 155,714 |  |
| Research and development and other tax credit carryforwards |  |  | 12,605 |  |  |  | 12,790 |  |
| Capitalized research and development costs |  |  | 5,787 |  |  |  | 3,514 |  |
| Accruals and reserves |  |  | 8,148 |  |  |  | 6,522 |  |
| Fixed assets and intangible assets |  |  | 398 |  |  |  | 639 |  |
| Other |  |  | 2,459 |  |  |  | 1,665 |  |
| Gross deferred tax assets |  |  | 180,100 |  |  |  | 180,844 |  |
| Valuation allowance |  |  | (171,674 | ) |  |  | (177,112 | ) |
| Total deferred tax assets |  |  | 8,426 |  |  |  | 3,732 |  |
| Deferred tax liabilities: |  |  |  |  |  |  |  |  |
| Amortization |  |  | (7,127 | ) |  |  | (1,492 | ) |
| Other |  |  | (1,716 | ) |  |  | (1,421 | ) |
| Total deferred tax liabilities |  |  | (8,843 | ) |  |  | (2,913 | ) |
| Net deferred tax assets (liabilities) |  | $ | (417 | ) |  | $ | 819 |  |

[0001437749-25-017986:notes:206]
Under the Tax Cuts and Jobs Act of 2017, taxpayers are required to capitalize and amortize expenses related for research and experimental as classified under Section 174 beginning in 2022. Amortization recovery for such costs are five years for domestic expenditures and fifteen for foreign expenditures. As of  March 31, 2025, the Company had approximately $31.9 million of research and experimental expenses that had been capitalized under Section 174 with a remaining basis of $24.4 million.

[0001437749-25-017986:notes:207]
The Company has provided a full valuation allowance against its net deferred income tax assets in the U.S., Romania and Poland since it is more likely than not that its deferred tax assets will not be realizable. After consideration of all the available evidence, both positive and negative, the Company has determined that a $171.7 million valuation allowance at  March 31, 2025 is necessary to reduce the deferred tax assets to the amount that will more likely than not be realized which is a $5.4 million decrease from the $177.1 million valuation allowance as of  March 31, 2024.

[0001437749-25-017986:notes:208]
At  March 31, 2025, the Company had aggregate net operating loss carryforwards in the U.S. for federal and state income tax purposes of approximately $655.7 million and $185.6 million, respectively, which expire in the years ending  March 31, 2026 through 2040. For U.S. federal tax purpose, approximately $103.1 million of federal net operating losses have an indefinite carryforward period. Included in the U.S. net operating loss are $3.5 million of acquired losses from Power Quality Systems, Inc. and $0.3 million of acquired losses from Infinia Technology Corporation. Research and development and other tax credit carryforwards amounting to approximately $10.6 million and $2.5 million are available to offset federal and state income taxes, respectively, and will expire in the years ending 2026 through 2041.

[0001437749-25-017986:notes:209]
As of  March 31, 2025, AMSC Romania has aggregate net operating loss carryforwards of approximately $0.4 million, which will begin to expire at  March 31, 2028 and NWL Poland has aggregate net operating loss carryforwards of approximately $0.4 million, which will begin to expire at  March 31, 2030.

[0001437749-25-017986:notes:210]
Section
    382 of the U.S. Internal Revenue Code of
    1986, as amended (the “IRC”), provides limits on the extent to which a corporation that has undergone an ownership change (as defined) can utilize any net operating loss ("NOL") and general business tax credit carryforwards it
     may have. The Company updated its study in fiscal
    2024 to determine whether Section
    382 could limit the use of its carryforwards in this manner. After completing this study, the Company has concluded that the limitation will
    not have a material impact on its ability to utilize its NOL carryforwards.  If there were material ownership changes subsequent to the study, such changes could limit the Company's ability to utilize its NOL carryforwards.

[0001437749-25-017986:notes:211]
The total amount of undistributed foreign earnings available to be repatriated at  March 31, 2025 was $3.1 million resulting in the recording of a $0.4 million deferred tax liability for foreign withholding taxes.

[0001437749-25-017986:notes:212]
The Company has not recorded a deferred tax asset for the temporary difference associated with the excess of the tax greater than the book basis in its Romanian and Poland subsidiaries as the future tax benefit is not expected to reverse in the foreseeable future.

[0001437749-25-017986:notes:213]
Accounting for income taxes requires a two-step approach to recognizing and measuring uncertain tax positions. The first step is to evaluate the tax position for recognition by determining if, based on the technical merits, it is more likely than not that the position will be sustained upon audit, including resolution of related appeals or litigation processes, if any. The second step is to measure the tax benefit as the largest amount that is more than 50% likely of being realized upon ultimate settlement. The Company reevaluates these uncertain tax positions on a quarterly basis. This evaluation is based on factors including, but not limited to, changes in facts or circumstances, changes in tax law, effectively settled issues under audit and new audit activity. Any changes in these factors could result in the recognition of a tax benefit or an additional charge to the tax provision. The Company did not identify any uncertain tax positions at  March 31, 2025. The Company did not have any gross unrecognized tax benefits at  March 31, 2025 or 2024.

[0001437749-25-017986:notes:214]
There were no reversals of uncertain tax positions in the fiscal years ended  March 31, 2025 and 2024.

[0001437749-25-017986:notes:215]
The Company accounts for interest and penalties related to uncertain tax positions as part of its provision for federal and state income taxes. Any unrecognized tax benefits, if recognized, would favorably affect its effective tax rate in any future period. The Company does not expect that the amounts of unrecognized benefits will change significantly within the next twelve months.

[0001437749-25-017986:notes:216]
The Company conducts business globally and, as a result, its subsidiaries file income tax returns in the U.S. federal jurisdiction and various state and foreign jurisdictions. Major tax jurisdictions include the U.S. and Austria. All U.S. income tax filings for fiscal years ended  March 31, 1997 through 2024 remain open and subject to examination.

[0001437749-25-017986:notes:217]
All fiscal years from the fiscal year ended  March 31, 2023 through 2025 remain open and subject to examination in Austria. Tax filings in Romania for the fiscal years ended  March 31, 2020 through 2025 remain open and subject to examination. Tax filings in Poland for tax years 2021 through  March 31, 2025 remain open and subject to examination.


## us-gaap:DebtDisclosureTextBlock

[0001437749-25-017986:notes:218]
15. Debt

[0001437749-25-017986:notes:219]
As part of the acquisition of Neeltran, the Company identified four equipment financing agreements that Neeltran had entered into prior to the acquisition of Neeltran on  May 6, 2021. The Company did not have a current or long-term debt balance as of  March 31, 2025, and had a current debt balance of less than $0.1 million and no long-term debt balance as of  March 31, 2024.


## us-gaap:LesseeOperatingLeasesTextBlock

[0001437749-25-017986:notes:220]
16. Leases

[0001437749-25-017986:notes:221]
Operating Leases

[0001437749-25-017986:notes:222]
All significant lease arrangements are recognized at lease commencement. Operating lease right–of-use assets and lease liabilities are recognized at commencement. The operating lease right-of-use asset includes any lease payments related to initial direct cost and prepayments and excludes any lease incentives. Lease expense is recognized on a straight-line basis over the lease term. The Company enters into a variety of operating lease agreements through the normal course of its business, but primarily real estate leases to support its operations. The real estate lease agreements generally provide for fixed minimum rental payments and the payment of real estate taxes and insurance. Many of these real estate leases have one or more renewal options that allow the Company, at its discretion, to renew the lease for varying periods up to five years or to terminate the lease. Only renewal options or termination rights that the Company believed were likely to be exercised were included in the lease calculations.

[0001437749-25-017986:notes:223]
The Company also enters into leases for vehicles, IT equipment and service agreements, and other leases related to its manufacturing operations that are also included in the right-of-use assets and lease liability accounts if they are for a term of longer than twelve months. However, many of these leases are either short-term in nature or immaterial. The Company has made the policy election to exclude short-term leases from the consolidated balance sheets.

[0001437749-25-017986:notes:224]
Supplemental balance sheet information related to leases at  March 31, 2025 and 2024 are as follows (in thousands):

[0001437749-25-017986:notes:225]
|  |  | March 31, 2025 |  |  | March 31, 2024 |  |
| Leases: |  |  |  |  |  |  |  |  |
| Right-of-use assets - Operating |  |  | 3,829 |  |  |  | 2,557 |  |
| Total right-of-use assets |  | $ | 3,829 |  |  | $ | 2,557 |  |
| Lease liabilities - ST Operating |  |  | 685 |  |  |  | 716 |  |
| Lease liabilities - LT Operating |  |  | 2,684 |  |  |  | 1,968 |  |
| Total lease liabilities |  | $ | 3,369 |  |  | $ | 2,684 |  |
| Weighted-average remaining lease term |  |  | 4.94 |  |  |  | 3.49 |  |
| Weighted-average discount rate |  |  | 14.94 | % |  |  | 9.83 | % |

[0001437749-25-017986:notes:226]
The costs related to the Company's finance lease are not material. The costs related to the Company's operating leases for the fiscal years ended  March 31, 2025 and 2024, are as follows (in thousands):

[0001437749-25-017986:notes:227]
|  |  | Year ended |  |  | Year ended |  |
|  |  | March 31, 2025 |  |  | March 31, 2024 |  |
| Operating Leases: |  |  |  |  |  |  |  |  |
| Operating lease costs - fixed |  | $ | 1,453 |  |  | $ | 1,023 |  |
| Operating lease costs - variable |  |  | 119 |  |  |  | 158 |  |
| Short-term lease costs |  |  | 153 |  |  |  | 149 |  |
| Total lease costs |  | $ | 1,725 |  |  | $ | 1,330 |  |

[0001437749-25-017986:notes:228]
The Company’s estimated minimum future lease obligations under the Company's leases are as follows:

[0001437749-25-017986:notes:229]
|  |  | Operating Leases |  |
| Year ended March 31, |  |  |  |  |
| 2026 |  | $ | 1,041 |  |
| 2027 |  |  | 1,426 |  |
| 2028 |  |  | 812 |  |
| 2029 |  |  | 401 |  |
| 2030 |  |  | 300 |  |
| Thereafter |  |  | 1,212 |  |
| Total minimum lease payments |  |  | 5,192 |  |
| Less: interest |  |  | (1,823 | ) |
| Present value of lease liabilities |  | $ | 3,369 |  |


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001437749-25-017986:notes:230]
17. Stockholders’ Equity

[0001437749-25-017986:notes:231]
Stock-Based Compensation Plans

[0001437749-25-017986:notes:232]
As of  March 31, 2025, the Company had two active stock plans: the Amended and Restated 2007 Director Stock Plan, as amended (the “2007 Director Plan”) and the 2022 Stock Incentive Plan, as amended and restated (the "2022 Plan"). On  August 2, 2024, the Company's stockholders approved the amendments to the 2022 Plan and amendments to the Company's 2007 Director Plan. The amendment to the 2022 Plan increased the total number of shares of common stock authorized for issuance under the 2022 Plan from 1,150,000 shares to 4,400,000 shares of common stock. The amendment to the 2007 Director Plan increased the total number of shares of common stock authorized for issuance under the 2007 Director Plan from 430,000 shares to 580,000 shares.

[0001437749-25-017986:notes:233]
The 2022 Plan provides for the grant of incentive stock options intended to qualify under Section 422 of the IRC of 1986, as amended, nonstatutory stock options, stock appreciation rights, restricted stock, restricted stock units and other stock-based awards. In the case of options, the exercise price is no less than the fair market value of the common stock, as determined by (or in a manner approved by) the Board of Directors, on the date of grant. The contractual life of options is generally 10 years. Options generally vest over a 3-5 year period while restricted stock generally vests over a 3 year period. The 2022 Plan replaced the Company’s 2007 Stock Incentive Plan, as amended (the “2007 Plan”). No further awards are granted under the 2007 Plan following effectiveness of the 2022 Plan; however, the terms and conditions of the 2007 Plan continue to govern any outstanding awards granted thereunder.

[0001437749-25-017986:notes:234]
The 2007 Director Plan provides for the grant of nonstatutory stock options and stock awards to members of the Board of Directors who are not also employees of the Company ("outside directors"). Under the terms of the 2007 Director Plan, each outside director is granted an option to purchase shares of common stock with an aggregate grant date value equal to $40,000 upon his or her initial election to the Board with an exercise price equal to the fair market value of the Company’s common stock on the date of the grant. These options vest in equal annual installments over a two-year period. In addition, each outside director is granted an award of shares of common stock on the third business day following the last day of each fiscal year with an aggregate value equal to $50,000 using the closing price of the Company's common stock two business days following the last day of each fiscal year, subject to proration for any partial fiscal year of service.

[0001437749-25-017986:notes:235]
As of  March 31, 2025, the 2022 Plan had 2,450,662 shares available for future issuance, and the 2007 Director Plan had 253,596 shares available for future issuance. Additionally, any shares which are subject to awards previously granted under the 2007 Plan that are forfeited or lapse unexercised and which following the effectiveness of the 2022 Plan are not issued under the 2007 Plan will become available for issuance under the 2022 Plan.

[0001437749-25-017986:notes:236]
The components of stock-based compensation for the years ended  March 31, 2025 and 2024 were as follows (in thousands):

[0001437749-25-017986:notes:237]
|  |  | Fiscal years ended March 31, |  |
|  |  | 2025 |  |  | 2024 |  |
| Stock options |  | $ | 8 |  |  | $ | 40 |  |
| Restricted stock and stock awards |  |  | 7,732 |  |  |  | 4,563 |  |
| Employee stock purchase plan |  |  | 54 |  |  |  | 49 |  |
| Total stock-based compensation expense |  | $ | 7,794 |  |  | $ | 4,652 |  |

[0001437749-25-017986:notes:238]
The estimated fair value of the Company’s stock-based awards, less expected annual forfeitures, is amortized over the awards’ service period. The total unrecognized compensation cost for unvested outstanding restricted stock was $15.6 million as of  March 31, 2025. This expense will be recognized over a weighted-average expense period of approximately 1.6 years.

[0001437749-25-017986:notes:239]
The following table summarizes stock-based compensation expense by financial statement line item for the fiscal years ended  March 31, 2025 and 2024 (in thousands):

[0001437749-25-017986:notes:240]
|  |  | Fiscal years ended March 31, |  |
|  |  | 2025 |  |  | 2024 |  |
| Cost of revenues |  | $ | 536 |  |  | $ | 293 |  |
| Research and development |  |  | 1,132 |  |  |  | 627 |  |
| Selling, general and administrative |  |  | 6,126 |  |  |  | 3,732 |  |
| Total |  | $ | 7,794 |  |  | $ | 4,652 |  |

[0001437749-25-017986:notes:241]
The following table summarizes the information concerning currently outstanding and exercisable employee and non-employee options:

[0001437749-25-017986:notes:242]
|  |  | Options / Shares |  |  | Weighted-Average Exercise Price |  |  | Weighted-Average Remaining Contractual Term |  |  | Aggregate Intrinsic Value (thousands) |  |
| Outstanding at March 31, 2024 |  |  | 36,206 |  |  | $ | 6.94 |  |  |  |  |  |  |  |  |  |
| Granted |  |  | — |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Exercised |  |  | — |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Canceled/forfeited |  |  | — |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Outstanding at March 31, 2025 |  |  | 36,206 |  |  | $ | 6.94 |  |  |  | 5.2 |  |  | $ | 406 |  |
| Exercisable at March 31, 2025 |  |  | 36,206 |  |  | $ | 6.94 |  |  |  | 5.2 |  |  | $ | 406 |  |
| Fully vested and expected to vest at March 31, 2025 |  |  | 36,206 |  |  | $ | 6.94 |  |  |  | 5.2 |  |  | $ | 406 |  |

[0001437749-25-017986:notes:243]
The Company did not grant any stock options under the 2007 Director Plan nor the 2022 Plan during both fiscal years ended  March 31, 2025 and 2024.

[0001437749-25-017986:notes:244]
The following table summarizes the restricted stock activity for the year ended  March 31, 2025:

[0001437749-25-017986:notes:245]
|  |  | Shares |  |  | Weighted Average Grant Date Fair Value |  |  | Intrinsic Aggregate Value (thousands) |  |
| Outstanding at March 31, 2024 |  |  | 1,425,654 |  |  | $ | 6.74 |  |  |  |  |  |
| Granted |  |  | 891,700 |  |  |  | 21.99 |  |  |  |  |  |
| Vested |  |  | (524,201 | ) |  |  | 8.50 |  |  |  |  |  |
| Forfeited |  |  | (3,000 | ) |  |  | 5.94 |  |  |  |  |  |
| Outstanding at March 31, 2025 |  |  | 1,790,153 |  |  | $ | 13.82 |  |  | $ | 32,473 |  |

[0001437749-25-017986:notes:246]
The total fair value of restricted stock that was granted during the fiscal years ended  March 31, 2025 and 2024 was $19.6 million and $4.8 million, respectively. The total fair value of restricted stock that vested during the fiscal years ended  March 31, 2025 and 2024 was $10.7 million and $4.5 million, respectively.

[0001437749-25-017986:notes:247]
There were 250,000 performance-based restricted shares awarded during the fiscal year ended  March 31, 2025 for which the performance conditions are deemed probable to be met and the expense is being recorded over a three-year vesting period. There were 213,000 performance-based restricted shares awarded during the fiscal year ended  March 31, 2024 for which the performance conditions are deemed probable to be met and the expense is being recorded over a three-year vesting period.

[0001437749-25-017986:notes:248]
The remaining shares awarded vest upon the passage of time. For awards that vest upon the passage of time, expense is being recorded over the vesting period.

[0001437749-25-017986:notes:249]
Employee Stock Purchase Plan

[0001437749-25-017986:notes:250]
The Company maintains the 2000 Employee Stock Purchase Plan, as amended (the "ESPP") which provides employees with the opportunity to purchase shares of common stock at a price equal to the market value of the common stock at the end of the offering period, less a 15% purchase discount. As of  March 31, 2025, the ESPP had 48,635 shares available for future issuance. The Company recognized less than $0.1 million of compensation expense for both the fiscal years ended  March 31, 2025 and 2024, related to the ESPP.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001437749-25-017986:notes:251]
18. Commitments and Contingencies

[0001437749-25-017986:notes:252]
Purchase Commitments

[0001437749-25-017986:notes:253]
The Company periodically enters into non-cancelable purchase contracts in order to ensure the availability of materials to support production of its products. Purchase commitments represent enforceable and legally binding agreements with suppliers to purchase goods or services. The Company periodically assesses the need to provide for impairment on these purchase contracts and records a loss on purchase commitments when required.

[0001437749-25-017986:notes:254]
Lease Commitments

[0001437749-25-017986:notes:255]
During the years ended  March 31, 2025 and 2024, all lease costs were recorded in selling, general and administrative expense.  See Note 16, "Leases" for further details.

[0001437749-25-017986:notes:256]
Legal Contingencies

[0001437749-25-017986:notes:257]
From time to time, the Company is involved in legal and administrative proceedings and claims of various types. The Company records a liability in its consolidated financial statements for these matters when a loss is known or considered probable and the amount can be reasonably estimated. The Company reviews these estimates each accounting period as additional information is known and adjusts the loss provision when appropriate. If a matter is both probable to result in a liability and the amounts of loss can be reasonably estimated, the Company estimates and discloses the possible loss or range of loss to the extent necessary to make the consolidated financial statements not misleading. If the loss is not probable or cannot be reasonably estimated, a liability is not recorded in its consolidated financial statements.

[0001437749-25-017986:notes:258]
Other

[0001437749-25-017986:notes:259]
The Company enters into long-term construction contracts with customers that require the Company to obtain performance bonds. The Company is required to deposit an amount equivalent to some or all the face amount of the performance bonds into an escrow account until the termination of the bond. When the performance conditions are met, amounts deposited as collateral for the performance bonds are returned to the Company. In addition, the Company has various contractual arrangements in which minimum quantities of goods or services have been committed to be purchased on an annual basis.

[0001437749-25-017986:notes:260]
As of  March 31, 2025, the Company had $4.3 million of restricted cash included in long-term assets and $1.6 million of restricted cash included in current assets. As of  March 31, 2024, the Company had $1.3 million of restricted cash included in long term assets and $0.5 million of restricted cash included in current assets. These amounts included in restricted cash primarily represent deposits to secure letters of credit for various supply contracts and long-term projects or collateral deposits. These deposits are held in interest bearing accounts.


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0001437749-25-017986:notes:261]
19. Employee Benefit Plans

[0001437749-25-017986:notes:262]
The Company has implemented a defined contribution plan (the “Plan”) under Section 401(k) of the IRC. Any contributions made by the Company to the Plan are discretionary. The Company has a stock match program under which the Company matched, in the form of Company common stock, 100% up to 5% of eligible contributions. The Company recorded expenses of $1.2 million and $0.6 million in the fiscal years ended  March 31, 2025 and 2024, respectively, and recorded corresponding charges to additional paid-in capital related to this program.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001437749-25-017986:notes:263]
20. Business Segments

[0001437749-25-017986:notes:264]
The Company reports its financial results in two reportable business segments: Grid and Wind. In accordance with ASC 280, Segment Reporting, the Company has identified two operating segments. The Company's operating segments reflect the way in which internally-reported financial information is used to make decisions and allocate resources.

[0001437749-25-017986:notes:265]
Through the Company’s power grid offerings, the Grid business segment enables electric utilities, industrial facilities, and renewable energy project developers to connect, transmit and distribute smarter, cleaner and better power through its transmission planning services, power electronics, and superconductor-based systems. The sales process is enabled by transmission planning services that allow it to identify power grid congestion, poor power quality and other risks, which helps the Company determine how its solutions can improve network performance. These services often lead to sales of grid interconnection solutions for wind farms and solar power plants, power quality systems, and transmission and distribution cable systems. The Company also sells ship protection products to the U.S. Navy through its Grid business segment.

[0001437749-25-017986:notes:266]
Through the Company’s wind power offerings, the Wind business segment enables manufacturers to field highly competitive wind turbines through its advanced power electronics and control system products, engineered designs, and support services. The Company supplies advanced power electronics and control systems, licenses its highly engineered wind turbine designs, and provides extensive customer support services to wind turbine manufacturers. The Company’s design portfolio includes a broad range of drive trains and power ratings of 2 megawatts ("MWs") and higher. The Company provides a broad range of power electronics and software-based control systems that are highly integrated and designed for optimized performance, efficiency, and grid compatibility.

[0001437749-25-017986:notes:267]
AMSC’s Chief Executive Officer Daniel McGahn is the chief operating decision maker. The chief operating decision maker uses segment operating income (loss) to allocate resources (including employees, property, and financial or capital resources) for each segment predominantly in the annual budget and forecasting process. The chief operating decision maker considers budget-to-actual variances on a monthly basis for segment operating income (loss) when making decisions about allocating capital and personnel to the segments. The chief operating decision maker also uses segment operating income or loss to assess the performance for each segment by comparing the results and return on assets of each segment with one another and in the compensation of certain employees.

[0001437749-25-017986:notes:268]
The following tables (i) summarize total sales by segment and (ii) reconcile each segment's sales to their respective segment operating income, including segment operating expenses, for each of the years ended  March 31, 2025 and 2024 (in thousands):

[0001437749-25-017986:notes:269]
|  |  | Fiscal Year Ended March 31, 2025 |  |
|  |  | Grid |  |  | Wind |  |  | Unallocated |  |  | Total |  |
| Segment operating income: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Revenues |  | $ | 187,170 |  |  | $ | 35,648 |  |  | $ | - |  |  | $ | 222,818 |  |
| Less (a) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Segment other operating expenses (b) |  |  | 185,358 |  |  |  | 31,856 |  |  |  | 6,681 |  |  |  | 223,895 |  |
| Segment operating income (loss) |  | $ | 1,812 |  |  | $ | 3,792 |  |  | $ | (6,681 | ) |  | $ | (1,077 | ) |

[0001437749-25-017986:notes:270]
(a) The significant expense categories and amounts align with the segment-level information that is regularly provided to the chief operating decision maker.

[0001437749-25-017986:notes:271]
(b) Segment other operating expense includes cost of sales, research and development expense, selling general, and administrative expense, amortization of acquisition related intangibles, and gain/loss on contingent consideration.

[0001437749-25-017986:notes:272]
|  |  | Fiscal Year Ended March 31, 2024 |  |
|  |  | Grid |  |  | Wind |  |  | Unallocated |  |  | Total |  |
| Segment operating income: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Revenues |  | $ | 122,065 |  |  | $ | 23,574 |  |  | $ | - |  |  | $ | 145,639 |  |
| Less (a) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Segment other operating expenses (b) |  |  | 128,974 |  |  |  | 23,125 |  |  |  | 4,908 |  |  |  | 157,007 |  |
| Segment operating income (loss) |  | $ | (6,909 | ) |  | $ | 449 |  |  | $ | (4,908 | ) |  | $ | (11,368 | ) |

[0001437749-25-017986:notes:273]
Unallocated corporate expenses consist of a loss on contingent consideration of $6.7 million in the fiscal year ended  March 31, 2025, and a loss on contingent consideration of $4.9 million in the fiscal year ended  March 31, 2024.

[0001437749-25-017986:notes:274]
The reconciliation of segment operating loss to consolidated income (loss) before income taxes for the years ended  March 31, 2025 and 2024 is as follows (in thousands):

[0001437749-25-017986:notes:275]
|  |  | Fiscal Years Ended March 31, |  |
|  |  | 2025 |  |  | 2024 |  |
| Operating loss: |  | $ | (1,077 | ) |  | $ | (11,368 | ) |
| Interest income, net |  |  | 3,708 |  |  |  | 1,302 |  |
| Other expense |  |  | (265 | ) |  |  | (736 | ) |
| Income (loss) before taxes |  | $ | 2,366 |  |  | $ | (10,802 | ) |

[0001437749-25-017986:notes:276]
Depreciation and amortization expense by segment for the years ended  March 31, 2025 and 2024 is as follows (in thousands):

[0001437749-25-017986:notes:277]
|  |  | Fiscal Years Ended March 31, |  |
|  |  | 2025 |  |  | 2024 |  |
| Grid |  | $ | 5,468 |  |  | $ | 4,408 |  |
| Wind |  |  | 92 |  |  |  | 87 |  |
| Total |  | $ | 5,560 |  |  | $ | 4,495 |  |

[0001437749-25-017986:notes:278]
Total assets for the two business segments as of  March 31, 2025 and  March 31, 2024 are as follows (in thousands):

[0001437749-25-017986:notes:279]
|  |  | March 31, 2025 |  |  | March 31, 2024 |  |
| Grid |  | $ | 211,520 |  |  | $ | 125,878 |  |
| Wind |  |  | 13,697 |  |  |  | 14,733 |  |
| Corporate assets |  |  | 85,304 |  |  |  | 92,160 |  |
| Total |  | $ | 310,521 |  |  | $ | 232,771 |  |

[0001437749-25-017986:notes:280]
The accounting policies of the business segments are the same as those for the consolidated Company. The Company’s business segments have been determined in accordance with the Company’s internal management structure, which is organized based on operating activities. The Company evaluates performance based upon several factors, of which the primary financial measures are segment revenues and segment operating loss. The disaggregated financial results of the segments reflect allocation of certain functional expense categories consistent with the basis and manner in which Company management internally disaggregates financial information for the purpose of assisting in making internal operating decisions.

[0001437749-25-017986:notes:281]
Geographic information about property, plant and equipment associated with particular regions is as follows (in thousands):

[0001437749-25-017986:notes:282]
|  |  | March 31, |  |
|  |  | 2025 |  |  | 2024 |  |
| North America |  | $ | 37,426 |  |  | $ | 10,679 |  |
| Europe |  |  | 1,097 |  |  |  | 149 |  |
| Asia Pacific |  |  | 49 |  |  |  | 33 |  |
| Total |  | $ | 38,572 |  |  | $ | 10,861 |  |


## us-gaap:NewAccountingPronouncementsAndChangesInAccountingPrinciplesTextBlock

[0001437749-25-017986:notes:283]
21. Recent Accounting Pronouncements

[0001437749-25-017986:notes:284]
In  November 2023, the FASB issued ASU 2023-07, Segment Reporting (Topic 280): Improvements to Reportable Segment Disclosures. The amendments in ASU 2023-07 improve the disclosures about a public entity’s reportable segments and address requests from investors for additional, more detailed information about a reportable segment’s expenses. Following the release of ASU 2023-07 in  November 2023, the effective date will be annual reporting periods beginning after  December 15, 2024. As of  March 31, 2025, the Company has adopted ASU 2023-07 and made the required disclosures, and noted no other material impact on its consolidated financial statements.

[0001437749-25-017986:notes:285]
In  December 2023, the FASB issued ASU 2023-09, Income Taxes (Topic 740): Improvements to Income Tax Disclosures. The amendments in ASU 2023-09 address investor requests for more transparency about income tax information through improvements to income tax disclosures primarily related to the rate reconciliation and income taxes paid information. Following the release of ASU 2023-09 in  December 2023, the effective date will be annual reporting periods beginning after  December 15, 2024. The Company is evaluating the impact on its consolidated financial statements.

[0001437749-25-017986:notes:286]
In  March 2024, the FASB issued ASU 2024-02, Codification Improvements—Amendments to Remove References to the Concepts Statements. The amendments in ASU 2024-02 contain amendments to the Codification that remove references to various FASB Concepts Statements. Following the release of ASU 2024-02 in  March 2024, the effective date will be annual reporting periods beginning after  December 15, 2024. The Company is evaluating any material impact on its consolidated financial statements.

[0001437749-25-017986:notes:287]
In  November 2024, the FASB issued ASU 2024-03, Income Statement—Reporting Comprehensive Income—Expense Disaggregation Disclosures. The amendments in ASU 2024-03 address investor requests for more disclosure of disaggregated financial reporting information about expenses presented in the income statement. Following the release of ASU 2024-03 in  November 2024, the effective date will be annual reporting periods beginning after  December 15, 2026. The Company is evaluating the impact on its consolidated financial statements.


## us-gaap:SubsequentEventsTextBlock

[0001437749-25-017986:notes:288]
22. Subsequent Events

[0001437749-25-017986:notes:289]
The Company has performed an evaluation of subsequent events through the time of filing this Annual Report on Form 10-K with the SEC, and has determined that there are no such events to report.


## ecd:MtrlTermsOfTrdArrTextBlock

[0001437749-25-017986:notes:290]
| Item 9B. | OTHER INFORMATION |

[0001437749-25-017986:notes:291]
(a) None.

[0001437749-25-017986:notes:292]
(b) During the three months ended  March 31, 2025, no director or officer of the Company adopted or terminated a “Rule 10b5-1 trading arrangement” or “non-Rule 10b5-1 trading arrangement,” as each term is defined in Item 408(a) of Regulation S-K.
