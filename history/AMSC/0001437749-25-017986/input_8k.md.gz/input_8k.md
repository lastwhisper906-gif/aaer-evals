# AMSC 8-K — 0001437749-25-017983 filed 2025-05-21

## item codes, every 8-K on or before 2025-05-21

- 2025-05-21 0001437749-25-017983 — 2.02, 5.02, 9.01
- 2025-02-05 0001437749-25-002901 — 2.02, 5.03, 9.01
- 2024-10-30 0001437749-24-032617 — 2.02, 9.01
- 2024-08-13 0001193125-24-199141 — 8.01, 9.01
- 2024-08-06 0001437749-24-024924 — 9.01 — amendment of 0001193125-24-193425
- 2024-08-06 0001437749-24-024881 — 2.02, 9.01
- 2024-08-05 0001193125-24-193965 — 5.02, 5.07, 9.01
- 2024-08-05 0001193125-24-193425 — 1.01, 2.01, 8.01, 9.01
- 2024-05-29 0001437749-24-018599 — 2.02, 5.02, 9.01
- 2024-01-31 0001193125-24-020938 — 8.01, 9.01
- 2024-01-24 0001437749-24-002040 — 2.02, 9.01
- 2023-11-01 0001437749-23-029749 — 2.02, 9.01
- 2023-08-11 0001437749-23-023329 — 5.07
- 2023-08-09 0001437749-23-022786 — 2.02, 9.01
- 2023-06-21 0001193125-23-171201 — 5.02, 9.01
- 2023-05-31 0001437749-23-016264 — 2.02, 9.01
- 2023-02-01 0001437749-23-002268 — 2.02, 9.01
- 2022-11-01 0001437749-22-025365 — 2.02, 9.01
- 2022-08-05 0001193125-22-213651 — 5.02, 5.07, 9.01
- 2022-08-03 0001437749-22-018628 — 2.02, 9.01
- 2022-06-10 0001437749-22-014780 — 5.02, 9.01
- 2022-06-01 0001437749-22-014033 — 2.02, 9.01
- 2022-02-02 0001437749-22-002207 — 2.02, 9.01
- 2021-11-08 0001437749-21-025697 — 2.02, 9.01
- 2021-08-04 0001437749-21-018522 — 2.02, 9.01
- 2021-08-02 0001193125-21-233260 — 5.07
- 2021-06-02 0001437749-21-013955 — 2.02, 9.01
- 2021-05-25 0001437749-21-013279 — 5.02, 9.01
- 2021-05-21 0001193125-21-168626 — 8.01, 9.01
- 2021-05-10 0001193125-21-156251 — 1.01, 9.01
- 2021-02-26 0001193125-21-060434 — 8.01, 9.01
- 2021-02-03 0001437749-21-001859 — 2.02, 9.01
- 2021-02-01 0001437749-21-001681 — 5.03, 9.01
- 2020-12-14 0001437749-20-025291 — 9.01 — amendment, the index does not say of what
- 2020-11-04 0001437749-20-022520 — 2.02, 9.01
- 2020-10-26 0001193125-20-276900 — 8.01, 9.01
- 2020-10-05 0001437749-20-020735 — 2.02
- 2020-10-05 0001437749-20-020734 — 1.01, 2.01, 3.02, 9.01
- 2020-10-02 0001437749-20-020660 — 8.01
- 2020-09-16 0001437749-20-019767 — 8.01
- 2020-08-05 0001437749-20-016665 — 2.02, 5.07, 9.01
- 2020-06-02 0001437749-20-012274 — 2.02, 9.01
- 2020-05-27 0001437749-20-011837 — 5.02, 9.01
- 2020-02-05 0001437749-20-001788 — 2.02, 9.01
- 2019-11-05 0001437749-19-021590 — 2.02, 9.01
- 2019-08-06 0001437749-19-015631 — 2.02, 9.01
- 2019-08-06 0001193125-19-214189 — 5.02, 5.07, 9.01
- 2019-06-05 0001437749-19-011476 — 2.02, 5.02, 9.01
- 2019-05-24 0001437749-19-010833 — 5.02
- 2019-02-05 0001628280-19-000964 — 2.02, 8.01, 9.01
- 2018-11-06 0001628280-18-013765 — 2.02, 9.01
- 2018-10-31 0001628280-18-013204 — 1.01
- 2018-08-01 0001628280-18-010196 — 5.07
- 2018-07-31 0001628280-18-009846 — 2.02, 9.01
- 2018-07-09 0001193125-18-214745 — 1.01, 9.01
- 2018-07-03 0001628280-18-009075 — 5.02, 9.01
- 2018-06-14 0001628280-18-007877 — 5.02
- 2018-06-06 0001628280-18-007643 — 2.02, 9.01
- 2018-04-10 0001628280-18-004141 — 5.02
- 2018-04-03 0001628280-18-003952 — 2.01, 9.01
- 2018-02-05 0001628280-18-000989 — 2.02, 9.01
- 2018-02-01 0001628280-18-000826 — 1.01, 9.01
- 2017-11-07 0001628280-17-011076 — 2.02, 9.01
- 2017-09-26 0001628280-17-009444 — 3.02, 8.01
- 2017-08-08 0001628280-17-008329 — 2.02, 9.01
- 2017-08-01 0001628280-17-007765 — 5.02, 5.07
- 2017-07-03 0001193125-17-221140 — 5.02, 9.01
- 2017-05-26 0001193125-17-185503 — 8.01, 9.01
- 2017-05-25 0001628280-17-005914 — 2.02, 9.01 — amendment of 0001628280-17-005884
- 2017-05-25 0001628280-17-005884 — 2.02, 9.01
- 2017-05-10 0001193125-17-165924 — 8.01, 9.01
- 2017-05-09 0001193125-17-164273 — 5.02
- 2017-05-04 0001193125-17-158639 — 1.02, 8.01
- 2017-04-26 0001193125-17-139493 — 2.02, 9.01
- 2017-04-04 0001193125-17-109748 — 2.05, 5.02, 9.01
- 2017-02-06 0001628280-17-000899 — 2.02, 9.01
- 2017-01-27 0001193125-17-021808 — 1.01, 2.02, 9.01
- 2016-11-02 0001628280-16-020598 — 2.02, 9.01
- 2016-09-16 0001193125-16-712301 — 5.02
- 2016-08-23 0001193125-16-688767 — 8.01
- 2016-08-09 0001628280-16-018763 — 2.02, 9.01
- 2016-08-02 0001193125-16-668417 — 5.02, 5.07, 9.01
- 2016-05-31 0001564590-16-020114 — 2.02, 9.01
- 2016-05-18 0001193125-16-594515 — 5.02
- 2016-03-08 0001193125-16-496113 — 1.01
- 2016-02-09 0001193125-16-454775 — 2.02, 9.01
- 2015-12-17 0001193125-15-405566 — 1.01
- 2015-11-03 0001193125-15-363413 — 2.02, 9.01
- 2015-08-31 0001193125-15-307558 — 1.01
- 2015-08-05 0001193125-15-277824 — 2.02, 9.01
- 2015-07-31 0001193125-15-273009 — 5.07
- 2015-06-26 0001193125-15-237190 — 5.02
- 2015-06-09 0001193125-15-218028 — 8.01
- 2015-05-28 0001193125-15-202933 — 2.02, 9.01
- 2015-04-28 0001193125-15-153319 — 8.01, 9.01
- 2015-04-23 0001193125-15-144123 — 2.02, 8.01, 9.01
- 2015-04-23 0001193125-15-143608 — 8.01
- 2015-04-10 0001193125-15-126160 — 8.01
- 2015-03-24 0001193125-15-103436 — 5.03, 9.01
- 2015-03-18 0001193125-15-097034 — 5.07
- 2015-02-05 0001193125-15-034499 — 2.02, 9.01
- 2015-01-29 0001193125-15-024629 — 2.02, 9.01
- 2015-01-21 0001193125-15-016287 — 3.01, 8.01
- 2015-01-06 0001193125-15-002902 — 5.02
- 2014-12-22 0001193125-14-450591 — 1.01, 2.03, 3.02, 9.01
- 2014-11-13 0001193125-14-410207 — 1.01, 9.01
- 2014-11-07 0001193125-14-402383 — 1.02, 7.01, 9.01
- 2014-11-06 0001193125-14-399779 — 2.02, 9.01
- 2014-10-01 0001193125-14-360072 — 2.02, 8.01, 9.01
- 2014-09-04 0001193125-14-331411 — 8.01
- 2014-08-21 0001193125-14-317133 — 1.01
- 2014-08-06 0001193125-14-298306 — 5.02, 5.07, 9.01
- 2014-08-05 0001193125-14-294647 — 2.02, 9.01
- 2014-07-16 0001193125-14-269902 — 8.01
- 2014-06-23 0001193125-14-244592 — 3.02, 8.01
- 2014-06-05 0001193125-14-226459 — 2.02, 9.01
- 2014-06-05 0001193125-14-226457 — 1.01, 9.01
- 2014-03-19 0001193125-14-106558 — 2.05
- 2014-03-03 0001193125-14-078917 — 1.01, 3.02, 9.01
- 2014-02-28 0001193125-14-077480 — 8.01, 9.01
- 2014-02-06 0001193125-14-037960 — 2.02, 8.01, 9.01
- 2013-11-20 0001193125-13-447829 — 3.02, 8.01
- 2013-11-18 0001193125-13-444697 — 1.01, 2.03, 3.02, 9.01
- 2013-11-07 0001193125-13-431705 — 2.02, 9.01
- 2013-10-09 0001193125-13-395362 — 1.01, 2.03, 3.02, 9.01
- 2013-09-25 0001193125-13-378481 — 5.02, 9.01
- 2013-08-21 0001193125-13-341566 — 4.01, 9.01
- 2013-08-07 0001193125-13-323082 — 2.02, 9.01
- 2013-08-02 0001193125-13-317278 — 5.02, 5.07
- 2013-06-14 0001193125-13-258758 — 2.02, 9.01
- 2013-04-01 0001193125-13-136714 — 2.02, 8.01, 9.01
- 2013-02-20 0001193125-13-067218 — 5.02, 9.01
- 2013-02-14 0001193125-13-060131 — 1.01, 9.01
- 2013-02-11 0001193125-13-048784 — 2.02, 9.01
- 2013-01-08 0001193125-13-006861 — 5.02, 9.01
- 2012-12-21 0001193125-12-511592 — 1.01, 2.03, 3.02, 9.01
- 2012-11-28 0001193125-12-483317 — 2.05, 5.02, 7.01, 9.01
- 2012-11-06 0001193125-12-453359 — 2.02, 9.01
- 2012-08-02 0001193125-12-330534 — 2.02, 9.01
- 2012-07-27 0001193125-12-318790 — 5.02, 5.07, 9.01
- 2012-06-06 0001193125-12-261030 — 1.01, 2.02, 2.03, 3.02, 5.02, 9.01
- 2012-05-09 0001193125-12-222210 — 5.02
- 2012-04-20 0001193125-12-172045 — 8.01
- 2012-04-13 0001193125-12-162694 — 2.02, 8.01, 9.01
- 2012-04-04 0001193125-12-149102 — 1.01, 2.02, 2.03, 3.02, 9.01
- 2012-02-09 0001193125-12-048009 — 2.02, 9.01
- 2012-02-06 0001193125-12-041344 — 5.07 — amendment of 0000950123-11-102495
- 2011-12-08 0000950123-11-102495 — 5.07
- 2011-11-29 0000950123-11-100822 — 2.05
- 2011-11-09 0000950123-11-096775 — 2.02, 9.01
- 2011-10-31 0000950123-11-093390 — 1.02, 9.01
- 2011-10-07 0000950123-11-089221 — 8.01
- 2011-10-03 0000950123-11-088315 — 7.01
- 2011-09-23 0000950123-11-086288 — 2.02, 9.01
- 2011-09-15 0000950123-11-084585 — 7.01
- 2011-09-06 0000950123-11-082736 — 7.01
- 2011-08-18 0000950123-11-078526 — 3.01, 7.01, 9.01
- 2011-08-11 0000950123-11-075905 — 5.02
- 2011-08-11 0000950123-11-075904 — 2.02, 2.05, 9.01
- 2011-07-11 0000950123-11-064934 — 2.02, 4.02, 9.01
- 2011-06-30 0000950123-11-063287 — 1.01, 3.02, 9.01
- 2011-06-21 0000950123-11-060491 — 3.01, 7.01, 9.01
- 2011-06-13 0000950123-11-058656 — 1.01, 9.01
- 2011-05-24 0000950123-11-053517 — 5.02, 9.01
- 2011-04-05 0001299933-11-001020 — 2.02, 9.01
- 2011-03-15 0000950123-11-025580 — 5.02
- 2011-03-14 0000950123-11-025205 — 1.01, 3.02, 9.01
- 2011-02-01 0001299933-11-000333 — 2.02, 9.01
- 2010-11-12 0000950123-10-104604 — 8.01, 9.01
- 2010-11-08 0000950123-10-102424 — 8.01, 9.01
- 2010-11-02 0001299933-10-003878 — 2.02, 9.01
- 2010-09-15 0000950123-10-086373 — 1.01, 9.01 — amendment, the index does not say of what
- 2010-08-06 0000950123-10-074362 — 5.07
- 2010-07-29 0001299933-10-002860 — 2.02, 9.01
- 2010-05-17 0000950123-10-050424 — 1.01, 9.01
- 2010-05-14 0001299933-10-001972 — 5.02
- 2010-05-13 0001299933-10-001943 — 2.02, 9.01
- 2010-02-08 0001299933-10-000506 — 8.01
- 2010-02-02 0001299933-10-000386 — 2.02, 9.01
- 2009-12-15 0001299933-09-004928 — 5.02
- 2009-10-29 0001299933-09-004267 — 2.02, 9.01
- 2009-08-12 0001193125-09-173026 — 5.02, 9.01
- 2009-07-30 0001193125-09-158842 — 1.01, 2.02, 9.01
- 2009-05-15 0001193125-09-113158 — 5.02
- 2009-05-14 0001193125-09-110619 — 2.02, 9.01
- 2009-04-20 0001193125-09-082590 — 5.02
- 2009-02-03 0001193125-09-016992 — 2.02, 9.01
- 2009-01-22 0001193125-09-009777 — 2.02, 9.01
- 2008-11-04 0001193125-08-223730 — 2.02, 9.01
- 2008-08-11 0001193125-08-173616 — 8.01
- 2008-08-07 0001193125-08-170325 — 8.01
- 2008-08-05 0001193125-08-165888 — 2.02, 9.01
- 2008-06-11 0001193125-08-132049 — 1.01, 9.01
- 2008-05-20 0001193125-08-119372 — 5.02, 9.01
- 2008-05-08 0001193125-08-107052 — 2.02, 9.01
- 2008-01-31 0001193125-08-016233 — 2.02, 9.01
- 2008-01-30 0001193125-08-015494 — 5.03, 9.01
- 2007-11-01 0001193125-07-231866 — 2.02, 9.01
- 2007-10-31 0001193125-07-231225 — 2.05
- 2007-10-29 0001193125-07-228284 — 5.03, 9.01
- 2007-09-27 0001193125-07-208950 — 5.02
- 2007-08-09 0001193125-07-176553 — 2.02, 9.01
- 2007-08-07 0001193125-07-173829 — 1.01, 5.02, 9.01
- 2007-07-02 0001193125-07-148303 — 5.02, 9.01
- 2007-06-20 0001193125-07-139068 — 8.01, 9.01
- 2007-06-14 0001193125-07-135550 — 9.01 — amendment of 0001193125-07-005297
- 2007-06-14 0001193125-07-135340 — 5.02
- 2007-05-24 0001193125-07-122148 — 2.02, 9.01
- 2007-03-30 0001193125-07-070154 — 2.05, 9.01
- 2007-03-23 0001193125-07-062978 — 9.01 — amendment of 0001193125-07-005297
- 2007-02-01 0001193125-07-017883 — 2.02, 9.01
- 2007-01-11 0001193125-07-005297 — 2.01, 9.01
- 2006-12-05 0001181431-06-067500 — 5.02
- 2006-11-29 0001193125-06-243360 — 1.01, 3.02, 9.01
- 2006-11-02 0001193125-06-221464 — 2.02, 9.01
- 2006-09-21 0001193125-06-194526 — 5.02
- 2006-08-08 0001193125-06-164819 — 2.02, 9.01
- 2006-08-02 0001193125-06-159113 — 1.01, 9.01
- 2006-07-28 0001193125-06-156172 — 1.01
- 2006-06-26 0001193125-06-135913 — 1.01, 3.03, 9.01
- 2006-05-11 0001193125-06-108489 — 2.02, 9.01
- 2006-05-05 0001193125-06-102270 — 1.01, 9.01
- 2006-05-01 0001193125-06-094941 — 2.02, 2.06, 9.01
- 2006-02-24 0001193125-06-038281 — 5.02, 9.01
- 2006-02-02 0001181431-06-007665 — 2.02, 9.01
- 2005-11-09 0001181431-05-060304 — 2.02, 9.01
- 2005-08-04 0001181431-05-044420 — 2.02, 9.01
- 2005-07-28 0001193125-05-151272 — 5.02, 9.01
- 2005-06-14 0001193125-05-125148 — 5.02, 9.01
- 2005-05-12 0001181431-05-027410 — 2.02, 9.01
- 2005-05-10 0001193125-05-102795 — 1.01
- 2005-04-05 0001181431-05-020680 — 1.01, 2.02, 3.02, 9.01
- 2005-02-03 0001181431-05-006678 — 2.02, 9.01
- 2004-11-09 0001181431-04-051381 — 2.02, 9.01 — amendment, the index does not say of what
- 2004-11-04 0001181431-04-050706 — 2.02, 9.01
- 2004-10-15 0001193125-04-172458 — 1.01, 9.01
- 2004-08-05 0001193125-04-132162 — 12
- 2004-05-13 0001193125-04-086853 — 12
- 2004-02-05 0001193125-04-015060 — 12
- 2003-11-06 0001193125-03-074000 — 12
- 2003-09-26 0001193125-03-054624 — 5
- 2003-08-06 0001193125-03-029666 — 12
- 2003-05-14 0000927016-03-002619 — 9
- 2002-12-31 0000927016-02-006114 — 5
- 2000-01-24 0000927016-00-000150 — 5, 7
- 1998-11-02 0000950135-98-005625 — 5, 7
- 1998-03-24 0000950135-98-001743 — 5, 7
- 1997-09-05 0000950135-97-003729 — 5, 7
- 1997-06-23 0000950135-97-002785 — 1 — amendment of 0000950135-97-001972
- 1997-04-23 0000950135-97-001972 — 2, 7

## late-filing notifications on or before 2025-05-21

- 2011-08-10 0000950123-11-075677 — NT 10-Q, for the period ended 2011-06-30
- 2011-05-31 0000950123-11-055465 — NT 10-K, for the period ended 2011-03-31

## item 2.02 — earnings release, exhibit 99.1

[0001437749-25-017983:8k_2_02:1]
EX-99.1
3
ex_774528.htm
EXHIBIT 99.1

[0001437749-25-017983:8k_2_02:2]
ex_774528.htm

[0001437749-25-017983:8k_2_02:3]
Exhibit 99.1

[0001437749-25-017983:8k_2_02:4]
AMSC Reports Fourth Quarter and Fiscal Year 2024 Financial Results and Business Outlook

[0001437749-25-017983:8k_2_02:5]
Business Highlights:

[0001437749-25-017983:8k_2_02:6]
• Full year revenues increased 53% year over year to $222.8 million

[0001437749-25-017983:8k_2_02:7]
• Full year net income increased $17.1 million year over year to $6.0 million

[0001437749-25-017983:8k_2_02:8]
• Generated $6.3 million of operating cash flow in the fourth quarter, helping to further strengthen the balance sheet

[0001437749-25-017983:8k_2_02:9]
Company to host conference call tomorrow, May 22 at 10:00 am ET

[0001437749-25-017983:8k_2_02:10]
Ayer, MA – May 21, 2025 – AMSC (Nasdaq: AMSC), a leading system provider of megawatt-scale power resiliency solutions that orchestrate the rhythm and harmony of power on the grid™ and that protect and expand the capability and resiliency of our Navy’s fleet, today reported financial results for its fourth quarter and fiscal year ended March 31, 2025 ("fiscal 2024").

[0001437749-25-017983:8k_2_02:11]
Revenues for the fourth quarter of fiscal 2024 were $66.7 million compared with $42.0 million for the same period of fiscal 2023. The year-over-year increase was driven by organic growth in New Energy Power Systems revenues along with the contributions from the acquisition of NWL, Inc.

[0001437749-25-017983:8k_2_02:12]
AMSC’s net income for the fourth quarter of fiscal 2024 was $1.2 million, or $0.03 per share, compared to net loss of $1.6 million, or $0.05 per share, for the same period of fiscal 2023. The Company’s non-GAAP net income for the fourth quarter of fiscal 2024 was $4.8 million, or $0.13 per share, compared with a non-GAAP net income of $1.9 million, or $0.06 per share, in the same period of fiscal 2023. Please refer to the financial table below for a reconciliation of GAAP to non-GAAP results.

[0001437749-25-017983:8k_2_02:13]
Revenues for fiscal 2024 were $222.8 million as compared to $145.6 million in fiscal 2023. The year-over-year increase was driven by higher D-VAR and NEPSI revenues than in the prior year period along with the contribution from the acquisition of NWL, Inc.

[0001437749-25-017983:8k_2_02:14]
AMSC reported net income for fiscal 2024 of $6.0 million, or $0.16 per share, compared to a net loss of $11.1 million, or $0.37 per share in fiscal 2023. The Company's non-GAAP net income for fiscal 2024 was $24.0 million, or $0.65 per share, compared with non-GAAP net income of $0.6 million, or $0.02 per share, for fiscal 2023. Please refer to the financial table below for a reconciliation of GAAP to non-GAAP results.

[0001437749-25-017983:8k_2_02:15]
Cash, cash equivalents and restricted cash on March 31, 2025 totaled $85.4 million.

[0001437749-25-017983:8k_2_02:16]
"AMSC reported its strongest quarterly and annual performance in years," said Daniel P. McGahn, Chairman, President and CEO of AMSC. "Fiscal fourth quarter revenue grew sequentially to over $66 million, up nearly 60% year-over-year. Net income surpassed $1.2 million, making our third consecutive quarter of profitability, and seventh consecutive quarter of positive operating cash flow. We secured $75 million in new orders, bringing total year-end orders to a recent record of nearly $320 million. Our fiscal 2024 results reflect improved financial performance, a resilient and diversified order pipeline, and solid operational execution—positioning AMSC for long-term success. With expanding end markets, we’re focused on broadening our offerings, entering new sectors, and strengthening customer relationships. We enter fiscal 2025 with strong momentum and confidence in our ability to continue building a more resilient and profitable company."

[0001437749-25-017983:8k_2_02:17]
| AMSC Reports Q4FY24 Results | Page 2 |

[0001437749-25-017983:8k_2_02:18]
Business Outlook

[0001437749-25-017983:8k_2_02:19]
For the first quarter ending June 30, 2025, AMSC expects that its revenues will be in the range of $64.0 million to $68.0 million. The Company’s net income for the first quarter of fiscal 2025 is expected to exceed $1.0 million, or $0.03 per share. The Company's non-GAAP net income (as defined below) is expected to exceed $4.0 million, or $0.10 per share.

[0001437749-25-017983:8k_2_02:20]
Conference Call Reminder

[0001437749-25-017983:8k_2_02:21]
In conjunction with this announcement, AMSC management will participate in a conference call with investors beginning at 10:00 a.m. Eastern Time on Thursday, May 22, 2025, to discuss the Company’s financial results and business outlook. Those who wish to listen to the live or archived conference call webcast should visit the “Investors” section of the Company’s website at https://ir.amsc.com. The live call can be accessed by dialing 1-844-481-2802 or 1-412-317-0675 and asking to join the AMSC call. A replay of the call may be accessed 2 hours following the call by dialing 1-877-344-7529 and using conference passcode 4917468.

[0001437749-25-017983:8k_2_02:22]
About AMSC (Nasdaq: AMSC)

[0001437749-25-017983:8k_2_02:23]
AMSC generates the ideas, technologies and solutions that meet the world’s demand for smarter, cleaner … better energy™. Through its Gridtec™ Solutions, AMSC provides the engineering planning services and advanced grid systems that optimize network reliability, efficiency and performance.  Through its Marinetec™ Solutions, AMSC provides ship protection and is developing propulsion and power management solutions designed to help fleets increase system efficiencies, enhance power quality and boost operational safety.  Through its Windtec™ Solutions, AMSC provides wind turbine electronic controls and systems, designs and engineering services that reduce the cost of wind energy. The Company’s solutions are enhancing the performance and reliability of power networks, increasing the operational safety of navy fleets, and powering gigawatts of renewable energy globally. Founded in 1987, AMSC is headquartered near Boston, Massachusetts with operations in Asia, Australia, Europe and North America. For more information, please visit www.amsc.com.

[0001437749-25-017983:8k_2_02:24]
AMSC, American Superconductor, D-VAR, D-VAR VVO, Gridtec, Marintec, Windtec, Neeltran, NEPSI, NWL, Smarter, Cleaner … Better Energy and Orchestrate the Rhythm and Harmony of Power on the Grid are trademarks or registered trademarks of American Superconductor Corporation. All other brand names, product names, trademarks or service marks belong to their respective holders.

[0001437749-25-017983:8k_2_02:25]
| AMSC Reports Q4FY24 Results | Page 3 |

[0001437749-25-017983:8k_2_02:26]
Forward-Looking Statements

[0001437749-25-017983:8k_2_02:27]
and the other important factors discussed under the caption "Risk Factors" in Part 1. Item 1A of our Form 10-K for the fiscal year ended March 31, 2025, and our other reports filed with the SEC. These important factors, among others, could cause actual results to differ materially from those indicated by forward-looking statements made herein and presented elsewhere by management from time to time. Any such forward-looking statements represent management's estimates as of the date of this press release. While we may elect to update such forward-looking statements at some point in the future, we disclaim any obligation to do so, even if subsequent events cause our views to change. These forward-looking statements should not be relied upon as representing our views as of any date subsequent to the date of this press release.

[0001437749-25-017983:8k_2_02:28]
| AMSC Reports Q4FY24 Results | Page 4 |

[0001437749-25-017983:8k_2_02:29]
UNAUDITED CONSOLIDATED STATEMENTS OF OPERATIONS

[0001437749-25-017983:8k_2_02:30]
(In thousands, except per share data)

[0001437749-25-017983:8k_2_02:31]
|  |  | Three Months Ended |  |  | Twelve Months Ended |  |
|  |  | March 31, |  |  | March 31, |  |
|  |  | 2025 |  |  | 2024 |  |  | 2025 |  |  | 2024 |  |
| Revenues |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Grid |  | $ | 55,592 |  |  | $ | 34,211 |  |  | $ | 187,170 |  |  | $ | 122,065 |  |
| Wind |  |  | 11,063 |  |  |  | 7,817 |  |  |  | 35,648 |  |  |  | 23,574 |  |
| Total revenues |  |  | 66,655 |  |  |  | 42,028 |  |  |  | 222,818 |  |  |  | 145,639 |  |
| Cost of revenues |  |  | 48,964 |  |  |  | 31,598 |  |  |  | 160,964 |  |  |  | 110,356 |  |
| Gross margin |  |  | 17,691 |  |  |  | 10,430 |  |  |  | 61,854 |  |  |  | 35,283 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Research and development |  |  | 3,493 |  |  |  | 2,298 |  |  |  | 11,425 |  |  |  | 7,991 |  |
| Selling, general and administrative |  |  | 12,101 |  |  |  | 7,953 |  |  |  | 43,091 |  |  |  | 31,600 |  |
| Amortization of acquisition related intangibles |  |  | 444 |  |  |  | 538 |  |  |  | 1,733 |  |  |  | 2,152 |  |
| Change in fair value of contingent consideration |  |  | — |  |  |  | 1,870 |  |  |  | 6,682 |  |  |  | 4,922 |  |
| Restructuring |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (14 | ) |
| Total operating expenses |  |  | 16,038 |  |  |  | 12,659 |  |  |  | 62,931 |  |  |  | 46,651 |  |
| Operating income (loss) |  |  | 1,653 |  |  |  | (2,229 | ) |  |  | (1,077 | ) |  |  | (11,368 | ) |
| Interest income, net |  |  | 807 |  |  |  | 784 |  |  |  | 3,708 |  |  |  | 1,302 |  |
| Other expense, net |  |  | (49 | ) |  |  | (117 | ) |  |  | (265 | ) |  |  | (736 | ) |
| Income (loss) before income tax (benefit) expense |  |  | 2,411 |  |  |  | (1,562 | ) |  |  | 2,366 |  |  |  | (10,802 | ) |
| Income tax (benefit) expense |  |  | 1,204 |  |  |  | 17 |  |  |  | (3,667 | ) |  |  | 309 |  |
| Net income (loss) |  | $ | 1,207 |  |  | $ | (1,579 | ) |  | $ | 6,033 |  |  | $ | (11,111 | ) |
| Net income (loss) per common share |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.03 |  |  | $ | (0.05 | ) |  | $ | 0.16 |  |  | $ | (0.37 | ) |
| Diluted |  | $ | 0.03 |  |  | $ | (0.05 | ) |  | $ | 0.16 |  |  | $ | (0.37 | ) |
| Weighted average number of common shares outstanding |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  |  | 37,672 |  |  |  | 33,139 |  |  |  | 36,990 |  |  |  | 29,825 |  |
| Diluted |  |  | 38,516 |  |  |  | 33,139 |  |  |  | 37,718 |  |  |  | 29,825 |  |

[0001437749-25-017983:8k_2_02:32]
| AMSC Reports Q4FY24 Results | Page 5 |

[0001437749-25-017983:8k_2_02:33]
CONSOLIDATED BALANCE SHEET

[0001437749-25-017983:8k_2_02:34]
(In thousands, except per share data)

[0001437749-25-017983:8k_2_02:35]
|  |  | March 31, |  |  | March 31, |  |
|  |  | 2025 |  |  | 2024 |  |
| ASSETS |  |  |  |  |  |  |  |  |
| Current assets: |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 79,494 |  |  | $ | 90,522 |  |
| Accounts receivable, net |  |  | 46,186 |  |  |  | 26,325 |  |
| Inventory, net |  |  | 71,169 |  |  |  | 41,857 |  |
| Prepaid expenses and other current assets |  |  | 8,055 |  |  |  | 7,295 |  |
| Restricted cash |  |  | 1,613 |  |  |  | 468 |  |
| Total current assets |  |  | 206,517 |  |  |  | 166,467 |  |
| Property, plant and equipment, net |  |  | 38,572 |  |  |  | 10,861 |  |
| Intangibles, net |  |  | 5,916 |  |  |  | 6,369 |  |
| Right-of-use assets |  |  | 3,829 |  |  |  | 2,557 |  |
| Goodwill |  |  | 48,164 |  |  |  | 43,471 |  |
| Restricted cash |  |  | 4,274 |  |  |  | 1,290 |  |
| Deferred tax assets |  |  | 1,178 |  |  |  | 1,119 |  |
| Equity-method Investments |  |  | 1,113 |  |  |  | — |  |
| Other assets |  |  | 958 |  |  |  | 637 |  |
| Total assets |  | $ | 310,521 |  |  | $ | 232,771 |  |
| LIABILITIES AND STOCKHOLDERS' EQUITY |  |  |  |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |  |  |  |
| Accounts payable and accrued expenses |  | $ | 32,282 |  |  | $ | 24,235 |  |
| Lease liability, current portion |  |  | 685 |  |  |  | 716 |  |
| Debt, current portion |  |  | — |  |  |  | 25 |  |
| Contingent consideration |  |  | — |  |  |  | 3,100 |  |
| Deferred revenue, current portion |  |  | 66,797 |  |  |  | 50,732 |  |
| Total current liabilities |  |  | 99,764 |  |  |  | 78,808 |  |
| Deferred revenue, long term portion |  |  | 9,336 |  |  |  | 7,097 |  |
| Lease liability, long term portion |  |  | 2,684 |  |  |  | 1,968 |  |
| Deferred tax liabilities |  |  | 1,595 |  |  |  | 300 |  |
| Other liabilities |  |  | 28 |  |  |  | 27 |  |
| Total liabilities |  |  | 113,407 |  |  |  | 88,200 |  |
| Stockholders' equity: |  |  |  |  |  |  |  |  |
| Common stock, $0.01 par value, 75,000,000 shares authorized; 39,887,536 and 37,343,812 shares issued and 39,484,185 and 36,946,181 shares outstanding at March 31, 2025 and 2024, respectively |  |  | 399 |  |  |  | 373 |  |
| Additional paid-in capital |  |  | 1,259,540 |  |  |  | 1,212,913 |  |
| Treasury stock, at cost, 403,351 and 397,631 at March 31, 2025 and 2024, respectively |  |  | (3,765 | ) |  |  | (3,639 | ) |
| Accumulated other comprehensive income |  |  | 1,565 |  |  |  | 1,582 |  |
| Accumulated deficit |  |  | (1,060,625 | ) |  |  | (1,066,658 | ) |
| Total stockholders' equity |  |  | 197,114 |  |  |  | 144,571 |  |
| Total liabilities and stockholders' equity |  | $ | 310,521 |  |  | $ | 232,771 |  |

[0001437749-25-017983:8k_2_02:36]
| AMSC Reports Q4FY24 Results | Page 6 |

[0001437749-25-017983:8k_2_02:37]
CONSOLIDATED STATEMENTS OF CASH FLOWS

[0001437749-25-017983:8k_2_02:38]
(In thousands)

[0001437749-25-017983:8k_2_02:39]
|  |  | Year Ended March 31, |  |
|  |  | 2025 |  |  | 2024 |  |
| Cash flows from operating activities: |  |  |  |  |  |  |  |  |
| Net income (loss) |  | $ | 6,033 |  |  | $ | (11,111 | ) |
| Adjustments to reconcile net income (loss) to net cash provided by operations: |  |  |  |  |  |  |  |  |
| Depreciation and amortization |  |  | 5,560 |  |  |  | 4,494 |  |
| Stock-based compensation expense |  |  | 7,794 |  |  |  | 4,652 |  |
| Provision for excess and obsolete inventory |  |  | 1,532 |  |  |  | 1,970 |  |
| Amortization of operating lease right-of-use assets |  |  | 976 |  |  |  | 321 |  |
| Deferred income taxes |  |  | (4,304 | ) |  |  | 65 |  |
| Earnings from equity method investments |  |  | 132 |  |  |  | — |  |
| Change in fair value of contingent consideration |  |  | 6,682 |  |  |  | 4,922 |  |
| Other non-cash items |  |  | (587 | ) |  |  | 44 |  |
| Unrealized foreign exchange gain on cash and cash equivalents |  |  | (41 | ) |  |  | (2 | ) |
| Changes in operating asset and liability accounts: |  |  |  |  |  |  |  |  |
| Accounts receivable |  |  | (3,213 | ) |  |  | 4,340 |  |
| Inventory |  |  | (7,707 | ) |  |  | (6,841 | ) |
| Prepaid expenses and other current assets |  |  | 543 |  |  |  | 5,992 |  |
| Operating leases |  |  | (1,563 | ) |  |  | (327 | ) |
| Accounts payable and accrued expenses |  |  | 3,209 |  |  |  | (13,498 | ) |
| Deferred revenue |  |  | 13,239 |  |  |  | 7,117 |  |
| Net cash provided by operating activities |  |  | 28,285 |  |  |  | 2,138 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |
| Purchases of property, plant and equipment |  |  | (2,415 | ) |  |  | (934 | ) |
| Cash paid to settle NWL contingent consideration liability |  |  | (3,278 | ) |  |  | — |  |
| Cash paid for NWL Acquisition, net of cash acquired |  |  | (29,577 | ) |  |  | — |  |
| Change in other assets |  |  | 64 |  |  |  | (27 | ) |
| Net cash used in investing activities |  |  | (35,206 | ) |  |  | (961 | ) |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |
| Repurchase of treasury stock |  |  | (126 | ) |  |  | — |  |
| Repayment of debt |  |  | (25 | ) |  |  | (65 | ) |
| Cash paid related to registration of common stock shares |  |  | (148 | ) |  |  | — |  |
| Proceeds from public equity offering, net |  |  | — |  |  |  | 65,227 |  |
| Proceeds from exercise of employee stock options and ESPP |  |  | 307 |  |  |  | 279 |  |
| Net cash provided by financing activities |  |  | 8 |  |  |  | 65,441 |  |
| Effect of exchange rate changes on cash, cash equivalents and restricted cash |  |  | 14 |  |  |  | (13 | ) |
| Net (decrease) increase in cash, cash equivalents and restricted cash |  |  | (6,899 | ) |  |  | 66,605 |  |
| Cash, cash equivalents and restricted cash at beginning of year |  |  | 92,280 |  |  |  | 25,675 |  |
| Cash, cash equivalents and restricted cash at end of year |  | $ | 85,381 |  |  | $ | 92,280 |  |

[0001437749-25-017983:8k_2_02:40]
| AMSC Reports Q4FY24 Results | Page 7 |

[0001437749-25-017983:8k_2_02:41]
RECONCILIATION OF GAAP NET INCOME (LOSS) TO NON-GAAP NET INCOME

[0001437749-25-017983:8k_2_02:42]
(In thousands, except per share data)

[0001437749-25-017983:8k_2_02:43]
|  |  | Three Months Ended March 31, |  |  | Year Ended March 31, |  |
|  |  | 2025 |  |  | 2024 |  |  | 2025 |  |  | 2024 |  |
| Net income (loss) |  | $ | 1,206 |  |  | $ | (1,579 | ) |  | $ | 6,033 |  |  | $ | (11,111 | ) |
| Stock-based compensation |  |  | 2,855 |  |  |  | 1,044 |  |  |  | 7,794 |  |  |  | 4,652 |  |
| Amortization of acquisition-related intangibles |  |  | 706 |  |  |  | 538 |  |  |  | 2,433 |  |  |  | 2,158 |  |
| Change in fair value of contingent consideration |  |  | — |  |  |  | 1,870 |  |  |  | 6,682 |  |  |  | 4,922 |  |
| Acquisition costs |  |  | — |  |  |  | — |  |  |  | 1,095 |  |  |  | — |  |
| Non-GAAP net income |  |  | 4,767 |  |  |  | 1,873 |  |  |  | 24,037 |  |  |  | 621 |  |
| Non-GAAP net income per share - basic |  | $ | 0.13 |  |  | $ | 0.06 |  |  | $ | 0.65 |  |  | $ | 0.02 |  |
| Non-GAAP net income per share - diluted |  | $ | 0.12 |  |  | $ | 0.05 |  |  | $ | 0.64 |  |  | $ | 0.02 |  |
| Weighted average shares outstanding - basic |  |  | 37,672 |  |  |  | 33,139 |  |  |  | 36,990 |  |  |  | 29,825 |  |
| Weighted average shares outstanding - diluted |  |  | 38,516 |  |  |  | 34,447 |  |  |  | 37,718 |  |  |  | 30,909 |  |

[0001437749-25-017983:8k_2_02:44]
Reconciliation of Forecast GAAP Net Income to Non-GAAP Net Income

[0001437749-25-017983:8k_2_02:45]
(In millions, except per share data)

[0001437749-25-017983:8k_2_02:46]
|  |  | Three months ending |  |
|  |  | June 30, 2025 |  |
| Net income |  | $ | 1.0 |  |
| Stock-based compensation |  |  | 2.6 |  |
| Amortization of acquisition-related intangibles |  |  | 0.4 |  |
| Non-GAAP net income |  | $ | 4.0 |  |
| Non-GAAP net income per share |  | $ | 0.10 |  |
| Shares outstanding |  |  | 38.7 |  |

[0001437749-25-017983:8k_2_02:47]
| AMSC Reports Q4FY24 Results | Page 8 |

[0001437749-25-017983:8k_2_02:48]
Note: Non-GAAP net income (loss) is defined by the Company as net income (loss) before; stock-based compensation; amortization of acquisition-related intangibles; changes in fair value of contingent consideration; acquisition costs; other non-cash or unusual charges, and the tax effect of adjustments calculated at the relevant rate for our non-GAAP metric. The Company believes non-GAAP net income (loss) and non-GAAP net income (loss) per share assist management and investors in comparing the Company’s performance across reporting periods on a consistent basis by excluding these non-cash, non-recurring or other charges that it does not believe are indicative of its core operating performance. Actual GAAP and non-GAAP net income (loss) and net income (loss) per share for the fiscal quarter ending June 30, 2025, including the above adjustments, may differ materially from those forecasted in the table above, including as a result of changes in the fair value of contingent consideration.

[0001437749-25-017983:8k_2_02:49]
Generally, a non-GAAP financial measure is a numerical measure of a company's performance, financial position or cash flow that either excludes or includes amounts that are not normally excluded or included in the most directly comparable measure calculated and presented in accordance with GAAP. The non-GAAP measures included in this release, however, should be considered in addition to, and not as a substitute for or superior to, operating income or other measures of financial performance prepared in accordance with GAAP. A reconciliation of GAAP to non-GAAP net income (loss) is set forth in the table above. Non-GAAP net income (loss) per share is defined as non-GAAP net income (loss) divided by shares outstanding.

[0001437749-25-017983:8k_2_02:50]
AMSC Contacts

[0001437749-25-017983:8k_2_02:51]
Investor Relations Contact:

[0001437749-25-017983:8k_2_02:52]
Carolyn Capaccio, CFA

[0001437749-25-017983:8k_2_02:53]
(212) 838-3777

[0001437749-25-017983:8k_2_02:54]
Email: amscIR@allianceadvisors.com

[0001437749-25-017983:8k_2_02:55]
AMSC Director, Communications:

[0001437749-25-017983:8k_2_02:56]
Nicol Golez

[0001437749-25-017983:8k_2_02:57]
Phone: (978) 399-8344

[0001437749-25-017983:8k_2_02:58]
Email: Nicol.Golez@amsc.com

[0001437749-25-017983:8k_2_02:59]
Public Relations Contact:

[0001437749-25-017983:8k_2_02:60]
RooneyPartners

[0001437749-25-017983:8k_2_02:61]
Joe Luongo

[0001437749-25-017983:8k_2_02:62]
(914) 906-5903

[0001437749-25-017983:8k_2_02:63]
Email: jluongo@rooneypartners.com

## item 5.02 — body, verbatim

[0001437749-25-017983:8k_body:1]
Item 5.02. Departure of Directors or Certain Officers; Election of Directors; Appointment of Certain Officers; Compensatory Arrangements of Certain Officers.

[0001437749-25-017983:8k_body:2]
(d) On May 15, 2025, the Board of Directors (the “Board”) of the Company elected Terence R. Donnelly to the Board, effective May 27, 2025. Mr. Donnelly was also appointed to the Audit Committee, effective upon his election to the Board.

[0001437749-25-017983:8k_body:3]
Mr. Donnelly will be compensated for his service on the Board and the Audit Committee in accordance with the Company’s existing compensation arrangements for non-employee directors. Mr. Donnelly will receive an automatic grant of a number of options to purchase shares of common stock under the Company’s Amended and Restated 2007 Director Stock Plan, as amended (the “2007 Director Plan”) on the date he commences service on the Board equal to (a) $40,000 divided by (b) the Black-Scholes value of an option to purchase one share of common stock. Under the 2007 Director Plan, these options have an exercise price equal to the fair market value of the Company’s common stock on the date of grant and become exercisable in equal installments over a two-year period, subject to accelerated vesting upon a change in control.

[0001437749-25-017983:8k_body:4]
In accordance with the Company’s existing compensation arrangements for non-employee directors, Mr. Donnelly also will receive a cash retainer of $35,000 per year for his service on the Board, to be paid in the form of a quarterly retainer of $8,750. Mr. Donnelly will be paid a cash retainer of $12,000 per year for his service on the Audit Committee. Pursuant to the 2007 Director Plan, Mr. Donnelly also will receive an annual equity award consisting of fully-vested shares of common stock with an aggregate value equal to $100,000, subject to proration for any partial fiscal year of service. The Company has agreed to pay Mr. Donnelly’s reasonable travel and accommodation expenses to attend meetings and other corporate functions related to his service on the Board, along with any taxes related to such payments.

[0001437749-25-017983:8k_body:5]
(e) Fiscal 2025 Executive Incentive Plan. On May 15, 2025, the Compensation Committee of the Board (the “Committee”) of the Company and the Board approved an executive incentive plan for the Company’s fiscal year ending March 31, 2026 (“fiscal 2025”). Participants in the plan include the Company’s chief executive officer and all other current executive officers. Pursuant to the plan, each participant is designated a target cash incentive amount, expressed as a percentage of the participant’s annual base salary. The Committee is responsible for determining the payout under the plan to each participant except the chief executive officer. The Board determines the payout under the plan for the chief executive officer, taking into account the recommendation of the Committee.

[0001437749-25-017983:8k_body:6]
The amount of the incentive award actually paid to each participant may be less than or greater than the participant’s target cash incentive, with the amount capped at 200% of the target incentive. For each participant, individual incentive awards will be determined following the end of fiscal 2025 based on the following factors and their corresponding weightings:

[0001437749-25-017983:8k_body:7]
•

[0001437749-25-017983:8k_body:8]
the Company’s non-GAAP net income for fiscal 2025 as compared to the established target – 50%

[0001437749-25-017983:8k_body:9]
•

[0001437749-25-017983:8k_body:10]
the Company’s revenues for fiscal 2025 as compared to the established target – 25%

[0001437749-25-017983:8k_body:11]
•

[0001437749-25-017983:8k_body:12]
the Company’s operating expenses for fiscal 2025 as compared to the established target – 25%

[0001437749-25-017983:8k_body:13]
The following table sets forth the target cash incentive for fiscal 2025 for each current executive officer:

[0001437749-25-017983:8k_body:14]
Executive Officer

[0001437749-25-017983:8k_body:15]
Title

[0001437749-25-017983:8k_body:16]
Target Incentive

[0001437749-25-017983:8k_body:17]
as % of

[0001437749-25-017983:8k_body:18]
Base Salary

[0001437749-25-017983:8k_body:19]
Target Incentive

[0001437749-25-017983:8k_body:20]
Daniel P. McGahn

[0001437749-25-017983:8k_body:21]
Chairman, President and Chief Executive Officer

[0001437749-25-017983:8k_body:22]
100

[0001437749-25-017983:8k_body:23]
%

[0001437749-25-017983:8k_body:24]
$

[0001437749-25-017983:8k_body:25]
725,000

[0001437749-25-017983:8k_body:26]
John W. Kosiba, Jr.

[0001437749-25-017983:8k_body:27]
Senior Vice President, Chief Financial Officer and Treasurer

[0001437749-25-017983:8k_body:28]
70

[0001437749-25-017983:8k_body:29]
%

[0001437749-25-017983:8k_body:30]
$

[0001437749-25-017983:8k_body:31]
315,000
