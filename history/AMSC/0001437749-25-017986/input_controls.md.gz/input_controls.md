# AMSC 10-K controls and the auditor's report


## auditors_report

[0001437749-25-017986:auditors_report:1]
Report of Independent Registered Public Accounting Firm

[0001437749-25-017986:auditors_report:2]
To the Stockholders and Board of Directors of American Superconductor Corporation

[0001437749-25-017986:auditors_report:3]
Opinion on the Financial Statements

[0001437749-25-017986:auditors_report:4]
We have audited the accompanying consolidated balance sheets of American Superconductor Corporation and its subsidiaries (the Company) as of March 31, 2025 and 2024, the related consolidated statements of operations, comprehensive income (loss), stockholders’ equity and cash flows for each of the two years in the period ended March 31, 2025, and the related notes to the consolidated financial statements (collectively, the financial statements). In our opinion, the financial statements present fairly, in all material respects, the financial position of the Company as of March 31, 2025 and 2024, and the results of its operations and its cash flows for each of the two years in the period ended March 31, 2025, in conformity with accounting principles generally accepted in the United States of America.

[0001437749-25-017986:auditors_report:5]
We have also audited, in accordance with the standards of the Public Company Accounting Oversight Board (United States) (PCAOB), the Company’s internal control over financial reporting as of March 31, 2025, based on criteria established in Internal Control—Integrated Framework issued by the Committee of Sponsoring Organizations of the Treadway Commission in 2013, and our report dated May 21, 2025 expressed an unqualified opinion on the effectiveness of the Company’s internal control over financial reporting.

[0001437749-25-017986:auditors_report:6]
Basis for Opinion

[0001437749-25-017986:auditors_report:7]
These financial statements are the responsibility of the Company’s management. Our responsibility is to express an opinion on the Company’s financial statements based on our audits. We are a public accounting firm registered with the PCAOB and are required to be independent with respect to the Company in accordance with U.S. federal securities laws and the applicable rules and regulations of the Securities and Exchange Commission and the PCAOB.

[0001437749-25-017986:auditors_report:8]
We conducted our audits in accordance with the standards of the PCAOB. Those standards require that we plan and perform the audit to obtain reasonable assurance about whether the financial statements are free of material misstatement, whether due to error or fraud. Our audits included performing procedures to assess the risks of material misstatement of the financial statements, whether due to error or fraud, and performing procedures that respond to those risks. Such procedures included examining, on a test basis, evidence regarding the amounts and disclosures in the financial statements. Our audits also included evaluating the accounting principles used and significant estimates made by management, as well as evaluating the overall presentation of the financial statements. We believe that our audits provide a reasonable basis for our opinion.

[0001437749-25-017986:auditors_report:9]
Critical Audit Matters

[0001437749-25-017986:auditors_report:10]
The critical audit matters communicated below are matters arising from the current period audit of the financial statements that were communicated or required to be communicated to the audit committee and that: (1) relate to accounts or disclosures that are material to the financial statements and (2) involved our especially challenging, subjective or complex judgments. The communication of critical audit matters does not alter in any way our opinion on the financial statements, taken as a whole, and we are not, by communicating the critical audit matters below, providing separate opinions on the critical audit matters or on the accounts or disclosures to which they relate.

[0001437749-25-017986:auditors_report:11]
47

[0001437749-25-017986:auditors_report:12]
Over-Time Revenue Recognition

[0001437749-25-017986:auditors_report:13]
As described in Notes 3 and 4 of the consolidated financial statements, for certain arrangements, such as contracts to perform research and development, prototype development contracts and certain customized product sales, the Company records revenues using the over-time method, measured by the relationship of costs incurred to total estimated contract costs. The ability to reliably estimate total estimated contract costs is challenging, especially on long-term prototype development contracts, and may require significant analysis and judgments by management, including evaluating customer change orders, to determine the appropriate amount of revenue to recognize.

[0001437749-25-017986:auditors_report:14]
We identified revenue recognition pertaining to customer contracts satisfied over-time as a critical audit matter as there are significant judgments exercised by management in determining total estimated contract costs used in determining revenue recognition. Given the high degree of management judgment involved in various cost estimates that are used in the revenue calculations, the audit effort required to evaluate management’s judgments in determining revenue recognition for the Company’s contracts was extensive and required a high degree of auditor judgment.

[0001437749-25-017986:auditors_report:15]
Our audit procedures related to revenue recognition included the following, among others:

[0001437749-25-017986:auditors_report:16]
|  | ● | We obtained an understanding of the relevant internal controls related to revenue recognition and tested the design and operating effectiveness of those internal controls including management’s review control over the assumptions and key inputs used to recognize over-time revenue. |

[0001437749-25-017986:auditors_report:17]
|  | ● | We selected a sample of contracts with customers and related revenue transactions and performed the following audit procedures: |

[0001437749-25-017986:auditors_report:18]
|  | o | Obtained customer contract, customer change orders (as applicable), related invoices, purchase orders, and management revenue recognition analysis for each testing selection, to evaluate if relevant contractual terms and transaction price were appropriately considered by management and conclusions on revenue recognition method were in accordance with the relevant accounting guidance. |
|  | o | Assessed the validity of data used in the model for completeness and accuracy by comparing selected items from the underlying budget to the source information used to develop the contract budget and agreeing, on a sample basis, costs incurred to source documents. |

[0001437749-25-017986:auditors_report:19]
|  | o | Evaluated management’s estimations of total contract cost by assessing actual costs to date against projections made throughout the course of the contract term. |

[0001437749-25-017986:auditors_report:20]
Valuation of Certain Tangible and Intangible Assets in Business Combination

[0001437749-25-017986:auditors_report:21]
As described in Note 2 of the consolidated financial statements, the Company completed the acquisition of Megatran Industries, Inc. on August 1, 2024, for total consideration of $61.4 million. The Company accounted for this transaction under the acquisition method of accounting for business combinations. Accordingly, the total consideration paid was allocated to the assets acquired and liabilities assumed based on their respective fair values, including identified intangible assets and land. The Company estimated the fair value of the identified intangible assets using the multi-period excess earnings method, which required management to make significant estimates and assumptions related to revenue growth and expense forecasts, customer attrition rates, and the selection of discount rates. The Company also made significant judgments regarding the estimates used to determine the fair value of the acquired land.

[0001437749-25-017986:auditors_report:22]
We identified the valuation of the identified intangible assets and land as a critical audit matter because of the significant estimates and assumptions management used in the fair value determination. Auditing management’s forecasted revenue growth and expenses, customer attrition rates, selection of the discount rates, and the fair value of acquired land required a high degree of auditor judgment and an increased extent of effort when performing audit procedures, including the use of our valuation specialists.

[0001437749-25-017986:auditors_report:23]
Our audit procedures related to the determination of the fair value of identified intangible assets and land, included the following, among others:

[0001437749-25-017986:auditors_report:24]
|  | ● | We obtained an understanding of the relevant internal controls related to the valuation of the identified intangible assets and land and tested the design and operating effectiveness of those internal controls including management’s review control over the assumptions and key inputs used in the purchase price allocation. |

[0001437749-25-017986:auditors_report:25]
|  | ● | We evaluated the reasonableness of management’s revenue growth and expenses forecasts and customer attrition rates by comparing the projections to historical results as well as industry benchmarks. |

[0001437749-25-017986:auditors_report:26]
|  | ● | With the assistance of our valuation specialists, we: |

[0001437749-25-017986:auditors_report:27]
|  | o | Evaluated the reasonableness of the Company’s valuation methodologies |
|  | o | Tested the source information underlying the determination of the discount rates and verified the accuracy of the calculations. |
|  | o | Tested the relevance and reliability of source information underlying the determination of fair value of the acquired land and compared to available market data. |

[0001437749-25-017986:auditors_report:28]
|  | o | Developed an independent estimate of the fair value of the acquired land and compared to management’s estimate. |

[0001437749-25-017986:auditors_report:29]
Neeltran Goodwill Valuation Impairment Assessment

[0001437749-25-017986:auditors_report:30]
As described in Notes 3 and 5 to the consolidated financial statements, management tests goodwill for impairment, at the reporting unit level, as of February 28 of each fiscal year, or more frequently if events or changes in circumstances indicate the goodwill asset might be impaired. The Company first assesses qualitatively whether it is necessary to perform a quantitative goodwill impairment test. The quantitative impairment test is required only if the entity concludes that it is more likely than not that a reporting unit’s fair value is less than its carrying amount. A quantitative assessment was performed as of February 28, 2025, for the Company’s goodwill balance resulting from its acquisition of Neeltran, Inc. To test goodwill quantitatively for impairment, management compares the estimated fair value of each reporting unit with the carrying amount of each reporting unit, including the recorded goodwill. In estimating the fair value of each reporting unit, management uses a methodology which combines an income approach, using a discounted cash flows method, with a market approach.

[0001437749-25-017986:auditors_report:31]
We identified the goodwill impairment assessment for the Company’s Neeltran reporting unit as a critical audit matter because of the significant estimates and assumptions used by management when estimating the fair value of this reporting unit, including management’s forecasts of revenue growth rates, operating margins and terminal growth rates as well as management’s selection of the discount rates. Auditing the reasonableness of management’s estimates and assumptions involved a high degree of auditor judgment and increased audit effort, including the use of our valuation specialists.

[0001437749-25-017986:auditors_report:32]
Our audit procedures related to the assessment of Neeltran goodwill impairment included the following, among others:

[0001437749-25-017986:auditors_report:33]
|  | ● | We obtained an understanding of the relevant internal controls related to management’s goodwill impairment assessment and tested the design and operating effectiveness of those internal controls including management’s review control over the significant assumptions in the goodwill impairment assessment. |

[0001437749-25-017986:auditors_report:34]
|  | ● | We evaluated the reasonableness of management’s forecasts of revenue growth rates and operating margins by comparing the projections to historical results. |

[0001437749-25-017986:auditors_report:35]
|  | ● | We tested the underlying data used by management in their development of forecasts of revenue growth rates and operating margins for accuracy and completeness. |

[0001437749-25-017986:auditors_report:36]
|  | ● | We evaluated the reasonableness of management’s selection of comparable entities with similar operations and economic characteristics. |

[0001437749-25-017986:auditors_report:37]
|  | ● | With the assistance of our valuation specialists, we: |

[0001437749-25-017986:auditors_report:38]
|  | o | Evaluated the reasonableness of the discount rate and multiple of earnings used in management’s assessment by comparing the underlying source information to publicly available market data and verifying the accuracy of the calculations |
|  | o | Evaluated the appropriateness of the valuation methods used by management and tested their mathematical accuracy. |

[0001437749-25-017986:auditors_report:39]
/s/ RSM US LLP

[0001437749-25-017986:auditors_report:40]
We have served as the Company's auditor since 2013.

[0001437749-25-017986:auditors_report:41]
Boston, Massachusetts

[0001437749-25-017986:auditors_report:42]
May 21, 2025

[0001437749-25-017986:auditors_report:43]
48

[0001437749-25-017986:auditors_report:44]
AMERICAN SUPERCONDUCTOR CORPORATION

[0001437749-25-017986:auditors_report:45]
PART I — FINANCIAL INFORMATION

[0001437749-25-017986:auditors_report:46]
ITEM 1. FINANCIAL STATEMENTS


## item_9a

[0001437749-25-017986:item_9a:1]
| Item 9A. | CONTROLS AND PROCEDURES |

[0001437749-25-017986:item_9a:2]
Evaluation of Disclosure Controls and Procedures

[0001437749-25-017986:item_9a:3]
Our management, with the participation of our Chief Executive Officer and Chief Financial Officer, evaluated the effectiveness of our disclosure controls and procedures as of March 31, 2025. The term “disclosure controls and procedures,” as defined in Rules 13a-15(e) and 15d-15(e) under the Exchange Act, means controls and other procedures of a company that are designed to ensure that information required to be disclosed by a company in the reports that it files or submits under the Exchange Act is recorded, processed, summarized and reported, within the time periods specified in the SEC’s rules and forms. Disclosure controls and procedures include, without limitation, controls and procedures designed to ensure that information required to be disclosed by a company in the reports that it files or submits under the Exchange Act is accumulated and communicated to the company’s management, including its principal executive and principal financial officers, as appropriate, to allow timely decisions regarding required disclosure. Management recognizes that any controls and procedures, no matter how well designed and operated, can provide only reasonable assurance of achieving their objectives and management necessarily applies its judgment in evaluating the cost-benefit relationship of possible controls and procedures.

[0001437749-25-017986:item_9a:4]
Based on the evaluation of our disclosure controls and procedures as of March 31, 2025, our Chief Executive Officer and Chief Financial Officer concluded that, as of such date, our disclosure controls and procedures were effective at the reasonable assurance level.

[0001437749-25-017986:item_9a:5]
Management’s Report on Internal Control over Financial Reporting

[0001437749-25-017986:item_9a:6]
Management is responsible for establishing and maintaining adequate internal control over our financial reporting. Internal control over financial reporting is defined in Rules 13a–15(f) and 15d–15(f) under the Exchange Act as a process designed by, or under the supervision of, a company’s chief executive officer and chief financial officer, and effected by the board of directors, management and other personnel, to provide reasonable assurance regarding the reliability of financial reporting and the preparation of financial statements for external purposes in accordance with generally accepted accounting principles, and includes those policies and procedures that:

[0001437749-25-017986:item_9a:7]
(1) Pertain to the maintenance of records that, in reasonable detail, accurately and fairly reflect the transactions and dispositions of assets;

[0001437749-25-017986:item_9a:8]
(2) Provide reasonable assurance that transactions are recorded as necessary to permit preparation of financial statements in accordance with generally accepted accounting principles, and that receipts and expenditures are being made only in accordance with authorizations of management and directors; and

[0001437749-25-017986:item_9a:9]
(3) Provide reasonable assurance regarding prevention or timely detection of unauthorized acquisition, use or disposition of assets that could have a material effect on the financial statements.

[0001437749-25-017986:item_9a:10]
Under the supervision and with the participation of our management, including our Chief Executive Officer and Chief Financial Officer, an evaluation was conducted of the effectiveness of our internal control over financial reporting as of March 31, 2025, based on the Committee of Sponsoring Organizations of the Treadway Commission’s Internal Control – Integrated Framework (2013 Edition). Based on this evaluation, management concluded that our internal control over financial reporting was effective as of March 31, 2025. Our evaluation excluded the acquisition of Megatran Industries, Inc. (referred to as the “NWL acquisition”), which was acquired on August 1, 2024. Our Consolidated Statement of Operations for the year ended March 31, 2025 included revenue of approximately $50.5 million and our Consolidated Balance Sheet as of March 31, 2025 included total assets of approximately $85.4 million attributable to the NWL acquisition. In accordance with guidance issued by the Securities and Exchange Commission, companies are allowed to exclude acquisitions from their assessment of internal control over financial reporting during the first year subsequent to the acquisition while integrating the acquired operations.

[0001437749-25-017986:item_9a:11]
The effectiveness of our internal control over financial reporting as of March 31, 2025 has been audited by RSM US LLP, an independent registered public accounting firm, as stated in their report which is included herein.

[0001437749-25-017986:item_9a:12]
Changes in Internal Control over Financial Reporting

[0001437749-25-017986:item_9a:13]
There were no changes to our internal control over financial reporting (as defined in Rules 13a-15(f) and 15d-15(f) under the Exchange Act) during the fiscal quarter ended March 31, 2025 that have materially affected, or are reasonably likely to materially affect, our internal control over financial reporting.

[0001437749-25-017986:item_9a:14]
87

[0001437749-25-017986:item_9a:15]
Report of Independent Registered Public Accounting Firm

[0001437749-25-017986:item_9a:16]
To the Stockholders and the Board of Directors of American Superconductor Corporation

[0001437749-25-017986:item_9a:17]
Opinion on the Internal Control Over Financial Reporting

[0001437749-25-017986:item_9a:18]
We have audited American Superconductor Corporation's (the Company) internal control over financial reporting as of March 31, 2025, based on criteria established in Internal Control—Integrated Framework issued by the Committee of Sponsoring Organizations of the Treadway Commission in 2013. In our opinion, the Company maintained, in all material respects, effective internal control over financial reporting as of March 31, 2025, based on criteria established in Internal Control—Integrated Framework issued by the Committee of Sponsoring Organizations of the Treadway Commission in 2013.

[0001437749-25-017986:item_9a:19]
We have also audited, in accordance with the standards of the Public Company Accounting Oversight Board (United States) (PCAOB), the consolidated financial statements of the Company and our report dated May 21, 2025 expressed an unqualified opinion.

[0001437749-25-017986:item_9a:20]
As described in Management’s Report on Internal Control over Financial Reporting, management has excluded Megatran Industries, Inc. and its wholly-owned subsidiaries (Megatran) from its assessment of internal control over financial reporting as of March 31, 2025, because it was acquired by the Company in the second quarter of 2024 and has not yet been fully incorporated into the Company’s internal controls over financial reporting. We have also excluded Megatran from our audit of internal control over financial reporting as of March 31, 2025. Megatran is a wholly owned subsidiary whose total assets and revenues represent approximately 28% and 23%, respectively, of the related consolidated financial statement amounts as of and for the year ended March 31, 2025.

[0001437749-25-017986:item_9a:21]
Basis for Opinion

[0001437749-25-017986:item_9a:22]
The Company’s management is responsible for maintaining effective internal control over financial reporting and for its assessment of the effectiveness of internal control over financial reporting in the accompanying Management’s Report on Internal Control over Financial Reporting. Our responsibility is to express an opinion on the Company’s internal control over financial reporting based on our audit. We are a public accounting firm registered with the PCAOB and are required to be independent with respect to the Company in accordance with U.S. federal securities laws and the applicable rules and regulations of the Securities and Exchange Commission and the PCAOB.

[0001437749-25-017986:item_9a:23]
We conducted our audit in accordance with the standards of the PCAOB. Those standards require that we plan and perform the audit to obtain reasonable assurance about whether effective internal control over financial reporting was maintained in all material respects. Our audit included obtaining an understanding of internal control over financial reporting, assessing the risk that a material weakness exists, and testing and evaluating the design and operating effectiveness of internal control based on the assessed risk. Our audit also included performing such other procedures as we considered necessary in the circumstances. We believe that our audit provides a reasonable basis for our opinion.

[0001437749-25-017986:item_9a:24]
Definition and Limitations of Internal Control Over Financial Reporting

[0001437749-25-017986:item_9a:25]
A company's internal control over financial reporting is a process designed to provide reasonable assurance regarding the reliability of financial reporting and the preparation of financial statements for external purposes in accordance with generally accepted accounting principles. A company's internal control over financial reporting includes those policies and procedures that (1) pertain to the maintenance of records that, in reasonable detail, accurately and fairly reflect the transactions and dispositions of the assets of the company; (2) provide reasonable assurance that transactions are recorded as necessary to permit preparation of financial statements in accordance with generally accepted accounting principles, and that receipts and expenditures of the company are being made only in accordance with authorizations of management and directors of the company; and (3) provide reasonable assurance regarding prevention or timely detection of unauthorized acquisition, use or disposition of the company's assets that could have a material effect on the financial statements.

[0001437749-25-017986:item_9a:26]
Because of its inherent limitations, internal control over financial reporting may not prevent or detect misstatements. Also, projections of any evaluation of effectiveness to future periods are subject to the risk that controls may become inadequate because of changes in conditions, or that the degree of compliance with the policies or procedures may deteriorate.

[0001437749-25-017986:item_9a:27]
/s/ RSM US LLP

[0001437749-25-017986:item_9a:28]
Boston, Massachusetts

[0001437749-25-017986:item_9a:29]
May 21, 2025

[0001437749-25-017986:item_9a:30]
88
