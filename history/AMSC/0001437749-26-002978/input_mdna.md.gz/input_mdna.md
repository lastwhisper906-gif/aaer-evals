# AMSC MD&A — 0001437749-26-002978


## mdna

[0001437749-26-002978:mdna:1]
[same as prior period, unchanged from 0001437749-25-033351:mdna:1]

[0001437749-26-002978:mdna:2]
[same as prior period, unchanged from 0001437749-25-033351:mdna:2]

[0001437749-26-002978:mdna:3]
[same as prior period, unchanged from 0001437749-25-033351:mdna:3]

[0001437749-26-002978:mdna:4]
[same as prior period, unchanged from 0001437749-25-033351:mdna:4]

[0001437749-26-002978:mdna:5]
[same as prior period, unchanged from 0001437749-25-033351:mdna:5]

[0001437749-26-002978:mdna:6]
[same as prior period, unchanged from 0001437749-25-033351:mdna:6]

[0001437749-26-002978:mdna:7]
[same as prior period, unchanged from 0001437749-25-033351:mdna:7]

[0001437749-26-002978:mdna:8]
[same as prior period, unchanged from 0001437749-25-033351:mdna:8]

[0001437749-26-002978:mdna:9]
[same as prior period, unchanged from 0001437749-25-033351:mdna:9]

[0001437749-26-002978:mdna:10]
[same as prior period, unchanged from 0001437749-25-033351:mdna:10]

[0001437749-26-002978:mdna:11]
[same as prior period, unchanged from 0001437749-25-033351:mdna:11]

[0001437749-26-002978:mdna:12]
On December 5, 2025 (the "Comtrafo Acquisition Date"), we entered into a Stock Exchange Agreement (the "Stock Exchange Agreement") with the selling stockholders named therein (the "Stockholders"). Pursuant to the terms of the Stock Exchange Agreement, Mardin Participações Ltda., an entity incorporated in Brazil (“AMSC Brazil”) and our wholly-owned subsidiary, directly or indirectly, purchased all of the issued and outstanding shares of Comtrafo Indústria de Transformadores Elétricos S.A. ("Comtrafo") (collectively, the "Comtrafo Acquisition") for (a) (i) 300,000,000 Brazilian Real in cash; and (b) 2,417,142 restricted shares of our common stock, $0.01 par value per share (the "AMSC Shares") that were paid and issued, respectively, at closing. In addition, pursuant to certain additional real property agreements, AMSC Brazil through Comtrafo purchased certain real estate assets and transportation assets of Comtrafo for 155,564,538 Brazilian Real and 13,376,676 Brazilian Real, respectively, in cash. Additionally, AMSC Brazil has agreed to pay the Stockholders up to an additional 382,500,000 Brazilian Real in cash (the "Earnout") upon the achievement of specified earnings before interest, taxes, depreciation, and amortization ("EBITDA") objectives during the three years following the closing. Comtrafo is a Brazil-based manufacturer of large power and distribution transformers primarily for utility customers and also for industrial customers.

[0001437749-26-002978:mdna:13]
[same as prior period, unchanged from 0001437749-25-033351:mdna:12]

[0001437749-26-002978:mdna:14]
[same as prior period, unchanged from 0001437749-25-033351:mdna:13]

[0001437749-26-002978:mdna:15]
[same as prior period, unchanged from 0001437749-25-033351:mdna:14]

[0001437749-26-002978:mdna:16]
[same as prior period, unchanged from 0001437749-25-033351:mdna:15]

[0001437749-26-002978:mdna:17]
[same as prior period, unchanged from 0001437749-25-033351:mdna:16]

[0001437749-26-002978:mdna:18]
Three and nine months ended December 31, 2025, compared to the three and nine months ended December 31, 2024

[0001437749-26-002978:mdna:19]
[same as prior period, unchanged from 0001437749-25-033351:mdna:18]

[0001437749-26-002978:mdna:20]
Total revenues increased 21% to $74.5 million for the three months ended December 31, 2025 and total revenues increased 36% to $212.7 million for the nine months ended December 31, 2025 compared to $61.4 million and $156.2 for the three and nine months ended December 31, 2024, respectively. Our revenues are summarized as follows (in thousands):

[0001437749-26-002978:mdna:21]
|  |  | Three Months Ended December 31, |  |  | Nine Months Ended December 31, |  |
|  |  | 2025 |  |  | 2024 |  |  | 2025 |  |  | 2024 |  |
| Revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Grid |  | $ | 63,187 |  |  | $ | 52,306 |  |  | $ | 177,616 |  |  | $ | 131,578 |  |
| Wind |  |  | 11,342 |  |  |  | 9,097 |  |  |  | 35,133 |  |  |  | 24,585 |  |
| Total |  | $ | 74,529 |  |  | $ | 61,403 |  |  | $ | 212,749 |  |  | $ | 156,163 |  |

[0001437749-26-002978:mdna:22]
Our Grid business segment accounted for 85% and 83% of total revenues for both the three and nine months ended December 31, 2025, respectively, compared to 85% and 84% for the three and nine months ended December 31, 2024, respectively. Our Grid business segment revenues increased 21% to $63.2 million in the three months ended December 31, 2025, from $52.3 million in the three months ended December 31, 2024. Our Grid business segment revenues increased 35% to $177.6 million in the nine months ended December 31, 2025, from $131.6 million in the nine months ended December 31, 2024. The increase in the Grid business segment revenues in the three months ended December 31, 2025, compared to the three months ended December 31, 2024, was driven by increased shipments of new energy power systems and additional ship protection systems revenues than in the prior year period along with the addition of Comtrafo revenues. The increase in the Grid business segment revenues in the nine months ended December 31, 2025, compared to the nine months ended December 31, 2024, was driven by the acquisitions of NWL and Comtrafo, increased shipments of new energy power systems, and additional ship protection systems revenues compared to the prior year periods.

[0001437749-26-002978:mdna:23]
Our Wind business segment accounted for 15% and 17% of total revenues for the three and nine months ended December 31, 2025, respectively, compared to 15% and 16% for the three and nine months ended December 31, 2024, respectively. Revenues in the Wind business segment increased 25% to $11.3 million in the three months ended December 31, 2025, from $9.1 million in the three months ended December 31, 2024. Revenues in the Wind business segment increased 43% to $35.1 million in the nine months ended December 31, 2025, from $24.6 million in the nine months ended December 31, 2024. The increase during the three and nine months ended December 31, 2025, compared to the three and nine months ended December 31, 2024, was driven by additional shipments of electrical control systems ("ECS").

[0001437749-26-002978:mdna:24]
[same as prior period, unchanged from 0001437749-25-033351:mdna:23]

[0001437749-26-002978:mdna:25]
Cost of revenues increased by 15% to $51.7 million for the three months ended December 31, 2025, compared to $45.1 million for the three months ended December 31, 2024. Cost of revenues increased by 29% to $145.0 million for the nine months ended December 31, 2025, compared to $112.0 million for the nine months ended December 31, 2024. Gross margin was 31% and 32% for the three and nine months ended December 31, 2025, respectively, compared to 27% and 28% for the three and nine months ended December 31, 2024, respectively. Cost of revenues includes total amortization expense of $0.1 million in the three and nine months ended December 31, 2025 as a result of Comtrafo acquired backlog intangible assets. In addition, a charge of $0.4 million related to a fair value adjustment for the step-up basis assigned to acquired inventory to properly reflect the fair value in purchase accounting was charged to cost of revenues in the three and nine months ended December 31, 2025, when the inventory was sold. The increase in gross margin in the three and nine months ended December 31, 2025 was due to higher revenues, a favorable product mix and favorable impacts across the business due to pricing increases across product lines.

[0001437749-26-002978:mdna:26]
[same as prior period, unchanged from 0001437749-25-033351:mdna:25]

[0001437749-26-002978:mdna:27]
[same as prior period, unchanged from 0001437749-25-033351:mdna:26]

[0001437749-26-002978:mdna:28]
Research and development ("R&D") expenses increased 18% in the three months ended December 31, 2025, to $3.5 million from $3.0 million in the three months ended December 31, 2024. R&D expenses increased 46% in the nine months ended December 31, 2025, to $11.6 million from $7.9 million in the nine months ended December 31, 2024. The increase in the three and nine months ended December 31, 2025 was driven primarily by higher overall compensation expense and additional stock-based compensation expense.

[0001437749-26-002978:mdna:29]
[same as prior period, unchanged from 0001437749-25-033351:mdna:28]

[0001437749-26-002978:mdna:30]
Selling, general and administrative ("SG&A") expenses increased 33% in the three months ended December 31, 2025, to $15.4 million from $11.6 million in the three ended December 31, 2024. SG&A expenses increased 39% in the nine months ended December 31, 2025, to $43.1 million from $31.0 million in the nine months ended December 31, 2024. The increase in SG&A expense in the three and nine months ended December 31, 2025 was driven primarily by higher overall compensation expense, additional stock-based compensation expense, and acquisition costs related to the acquisition of Comtrafo.

[0001437749-26-002978:mdna:31]
[same as prior period, unchanged from 0001437749-25-033351:mdna:30]

[0001437749-26-002978:mdna:32]
We recorded amortization expense related to our core technology and know-how and customer relationships of $0.5 million in the three months ended December 31, 2025, and $0.4 million in the three months ended December 31, 2024. We recorded amortization expense related to our core technology and know-how and customer relationships of $1.2 million in the nine months ended December 31, 2025, and $1.3 million in the nine months ended December 31, 2024. The increase in amortization expense in the three months ended December 31, 2025, was a result of additional amortization related to the Comtrafo acquisition, as well as ongoing activity from NEPSI and Neeltran which are using the economic consumption method as the basis to amortize the acquired customer relationships intangible assets. The decrease in amortization expense in the nine months ended December 31, 2025, was a result of additional amortization expense related to the Comtrafo acquisition using the economic consumption method as the basis to amortize the acquired customer relationships intangible assets offset by similar ongoing activity from NEPSI and Neeltran, Inc.

[0001437749-26-002978:mdna:33]
[same as prior period, unchanged from 0001437749-25-033351:mdna:32]

[0001437749-26-002978:mdna:34]
The change in fair value of our contingent consideration for the earnout payment on the acquisition of NEPSI resulted in a loss of $3.4 million resulting from an increase in fair value in the nine months ended December 31, 2024. During the three and nine months ended December 31, 2024, we issued 300,000 shares of common stock of the Company to the selling stockholders following certification of the achievement of specified earnout revenue objectives. There was no activity in the three and nine months ended December 31, 2025 as the contingent consideration for NEPSI and NWL was settled during the prior fiscal year. The change in fair value of the Comtrafo contingent consideration was deemed immaterial to the financial statements from the Comtrafo Acquisition Date.

[0001437749-26-002978:mdna:35]
[same as prior period, unchanged from 0001437749-25-033351:mdna:34]

[0001437749-26-002978:mdna:36]
[same as prior period, unchanged from 0001437749-25-033351:mdna:35]

[0001437749-26-002978:mdna:37]
|  |  | Three Months Ended December 31, |  |  | Nine Months Ended December 31, |  |
|  |  | 2025 |  |  | 2024 |  |  | 2025 |  |  | 2024 |  |
| Operating income (loss): |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Grid |  | $ | 2,031 |  |  | $ | 234 |  |  | $ | 7,464 |  |  | $ | 1,572 |  |
| Wind |  |  | 1,328 |  |  |  | 1,081 |  |  |  | 4,503 |  |  |  | 2,387 |  |
| Unallocated corporate expenses |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (6,689 | ) |
| Total |  | $ | 3,359 |  |  | $ | 1,315 |  |  | $ | 11,967 |  |  | $ | (2,730 | ) |

[0001437749-26-002978:mdna:38]
Our Grid business segment generated operating income of $2.0 million and $7.5 million in the three and nine months ended December 31, 2025, respectively, compared to an operating income of $0.2 million and $1.6 million in the three and nine months ended December 31, 2024, respectively. The increase in the Grid business segment operating income in the three and nine months ended December 31, 2025 was due to higher revenues and gross margins.

[0001437749-26-002978:mdna:39]
Our Wind business segment generated operating income of $1.3 million and $4.5 million in the three and nine months ended December 31, 2025, respectively, compared to operating income of $1.1 million and $2.4 million in the three and nine months ended December 31, 2024, respectively. The increase in the Wind business segment operating income in the three and nine months ended December 31, 2025 was due to higher revenues and gross margins from increased sales of ECS units.

[0001437749-26-002978:mdna:40]
Unallocated corporate expenses included a net loss on contingent consideration of $6.7 million in the nine months ended December 31, 2024.

[0001437749-26-002978:mdna:41]
[same as prior period, unchanged from 0001437749-25-033351:mdna:40]

[0001437749-26-002978:mdna:42]
Interest income, net, was $2.0 million and $5.2 million in the three and nine months ended December 31, 2025, respectively, compared to $0.8 million and $2.9 million in the three and nine months ended December 31, 2024, respectively. The increase in interest income, net, in the three and nine months ended December 31, 2025 was due to higher cash balances primarily generated from the public offering completed in June 2025.

[0001437749-26-002978:mdna:43]
Other income (expense), net

[0001437749-26-002978:mdna:44]
Other expense, net, was $0.1 million and both in the three and nine months ended December 31, 2025, compared to other income, net of $0.3 million and other expense, net of $0.2 million in the three and nine months ended December 31, 2024, respectively. The increase in other expense, net, during the three months ended December 31, 2025, compared to the three months ended December 31, 2024 was driven by unfavorable fluctuations in foreign currencies. The decrease in other expense, net, during the nine months ended December 31, 2025,  compared to the nine months ended December 31, 2024 was driven by favorable fluctuations in foreign currencies.

[0001437749-26-002978:mdna:45]
[same as prior period, unchanged from 0001437749-25-033351:mdna:44]

[0001437749-26-002978:mdna:46]
Income tax benefit was $112.3 million and $112.1 million in the three and nine months ended December 31, 2025, respectively, compared to income tax benefit of $0.1 million and $4.9 million in the three and nine months ended December 31, 2024, respectively. The increase in our income tax benefit was primarily due to a $113.1 million non-cash tax benefit from the release of the majority of our valuation allowance against deferred tax assets.

[0001437749-26-002978:mdna:47]
[same as prior period, unchanged from 0001437749-25-033351:mdna:46]

[0001437749-26-002978:mdna:48]
Net income was $117.8 million and $129.3 million in the three and nine months ended December 31, 2025, respectively, compared to $2.5 million and $4.8 million in the three and nine months ended December 31, 2024, respectively. The increase in net income for the three and nine months ended December 31, 2025 was driven primarily by the release of the valuation allowance and increased revenues and gross margins.

[0001437749-26-002978:mdna:49]
[same as prior period, unchanged from 0001437749-25-033351:mdna:48]

[0001437749-26-002978:mdna:50]
[same as prior period, unchanged from 0001437749-25-033351:mdna:49]

[0001437749-26-002978:mdna:51]
[same as prior period, unchanged from 0001437749-25-033351:mdna:50]

[0001437749-26-002978:mdna:52]
|  |  | Three Months Ended December 31, |  |  | Nine Months Ended December 31, |  |
|  |  | 2025 |  |  | 2024 |  |  | 2025 |  |  | 2024 |  |
| Net income |  | $ | 117,806 |  |  | $ | 2,465 |  |  | $ | 129,280 |  |  | $ | 4,828 |  |
| Stock-based compensation |  |  | 3,822 |  |  |  | 2,861 |  |  |  | 12,114 |  |  |  | 4,933 |  |
| Acquisition costs |  |  | 1,286 |  |  |  | 15 |  |  |  | 1,285 |  |  |  | 1,095 |  |
| Amortization of acquisition-related intangibles |  |  | 618 |  |  |  | 706 |  |  |  | 1,292 |  |  |  | 1,727 |  |
| Change in fair value of contingent consideration |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 6,682 |  |
| Non-GAAP net income |  | $ | 123,532 |  |  | $ | 6,047 |  |  | $ | 143,971 |  |  | $ | 19,265 |  |
| Non-GAAP net income per share - basic |  | $ | 2.81 |  |  | $ | 0.16 |  |  | $ | 3.42 |  |  | $ | 0.52 |  |
| Non-GAAP net income per share - diluted |  | $ | 2.75 |  |  | $ | 0.16 |  |  | $ | 3.35 |  |  | $ | 0.51 |  |
| Weighted average shares outstanding - basic |  |  | 43,957 |  |  |  | 37,661 |  |  |  | 42,036 |  |  |  | 36,766 |  |
| Weighted average shares outstanding - diluted |  |  | 44,939 |  |  |  | 38,463 |  |  |  | 42,975 |  |  |  | 37,457 |  |

[0001437749-26-002978:mdna:53]
We generated non-GAAP net income of $123.5 million and $144.0 million, or $2.81 and $3.42 per share, for the three and nine months ended December 31, 2025, respectively, compared to a non-GAAP net income of $6.0 million and $19.3 million, or $0.16 and $0.52 per share, for the three and nine months ended December 31, 2024, respectively. For the three and nine months ended December 31, 2025, the increase in non-GAAP net income was a result of the release of the valuation allowance and higher revenues and gross margins.

[0001437749-26-002978:mdna:54]
33

[0001437749-26-002978:mdna:55]
[same as prior period, unchanged from 0001437749-25-033351:mdna:54]

[0001437749-26-002978:mdna:56]
The Company’s primary sources of liquidity are internally generated cash provided by operating activities, our cash and cash equivalents on hand, along with access to capital markets, including through our currently effective Registration Statements on Form S-3. We believe that these sources of liquidity are sufficient to meet both our short-term and reasonably foreseeable long-term requirements and obligations. As of December 31, 2025, we had cash and cash equivalents of $141.1 million.

[0001437749-26-002978:mdna:57]
[same as prior period, unchanged from 0001437749-25-033351:mdna:56]

[0001437749-26-002978:mdna:58]
[same as prior period, unchanged from 0001437749-25-033351:mdna:57]

[0001437749-26-002978:mdna:59]
As of December 31, 2025, we had cash, cash equivalents and restricted cash of $147.1 million, compared to $85.4 million as of March 31, 2025, an increase of $61.7 million. As of December 31, 2025, we had $22.8 million in cash, cash equivalents, and restricted cash in foreign bank accounts. Our cash, cash equivalents, and restricted cash are summarized as follows (in thousands):

[0001437749-26-002978:mdna:60]
|  |  | December 31, 2025 |  |  | March 31, 2025 |  |
| Cash and cash equivalents |  | $ | 141,072 |  |  | $ | 79,494 |  |
| Restricted cash |  |  | 6,039 |  |  |  | 4,274 |  |
| Total cash, cash equivalents, and restricted cash |  | $ | 147,111 |  |  | $ | 83,768 |  |

[0001437749-26-002978:mdna:61]
For the nine months ended December 31, 2025, net cash provided by operating activities was $13.9 million, compared to $22.0 million for the nine months ended December 31, 2024. The decrease in cash flows provided by operating activities in the nine months ended December 31, 2025 was due primarily to changes in deferred revenue, offset by change in accounts payable and accrued expenses, accounts receivable, deferred income taxes, and stock-based compensation expense.

[0001437749-26-002978:mdna:62]
For the nine months ended December 31, 2025, net cash used in investing activities was $75.3 million, compared to $34.1 million for the nine months ended December 31, 2024. The increase in net cash used in investing activities was primarily due to cash paid for the Comtrafo acquisition in the current year.

[0001437749-26-002978:mdna:63]
For the nine months ended December 31, 2025, net cash provided by financing activities was $123.9 million compared to cash used in financing activities of $0.1 million for the nine months ended December 31, 2024. The increase in net cash provided by financing activities was due primarily to the equity raise in June 2025.

[0001437749-26-002978:mdna:64]
As of December 31, 2025, we had $3.3 million of restricted cash included in long-term assets and $2.8 million of restricted cash included in current assets. At March 31, 2025, we had $4.3 million of restricted cash included in long-term assets and $1.6 million of restricted cash in current assets. These amounts included in restricted cash primarily represent collateral deposits to secure surety bonds and letters of credit for various customer contracts. These deposits are held in interest bearing accounts.

[0001437749-26-002978:mdna:65]
We are a party to many contractual obligations involving commitments to make payments to third parties. These obligations impact our short-term and long-term liquidity and capital resource needs. Certain contractual obligations are reflected on the condensed consolidated balance sheet as of December 31, 2025, while others are considered future commitments. We have various contractual arrangements, under which we have committed to purchase certain minimum quantities of goods or services on an annual basis. For information regarding our other contractual obligations, refer to Note 3, "Revenue Recognition," Note 14, "Contingent Consideration," Note 16, "Leases" and Note 17, "Commitments and Contingencies" to our condensed consolidated financial statements included elsewhere in this Quarterly Report on Form 10-Q. Other than the contingent consideration owed to the former Comtrafo stockholders there have been no material changes to our contractual obligations from those disclosed in our Annual Report on Form 10-K for the fiscal year ended March 31, 2025.

[0001437749-26-002978:mdna:66]
We believe we have sufficient available liquidity to fund our operations and capital expenditures for at least the next twelve months and into the future. We raised $124.6 million, net of offering expenses, through an equity raise in June 2025, of which $88.3 million was used for the Comtrafo Acquisition. In addition, we may seek to raise additional capital, which could be in the form of loans, convertible debt or equity, to fund our operating requirements and capital expenditures. There can be no assurance that we will be able to raise additional capital on favorable terms or at all or execute on any other means of improving our liquidity as described above.  Additionally, the impact of global sources of instability, including the ongoing war between Russia and Ukraine, tariffs, trade restrictions and resulting trade conflicts, instability of financial institutions and political instability in the United States, on the global financial markets may reduce our ability to raise additional capital, if necessary, which could negatively impact our liquidity.

[0001437749-26-002978:mdna:67]
Legal Proceedings

[0001437749-26-002978:mdna:68]
[same as prior period, unchanged from 0001437749-25-033351:mdna:67]

[0001437749-26-002978:mdna:69]
[same as prior period, unchanged from 0001437749-25-033351:mdna:68]

[0001437749-26-002978:mdna:70]
In December 2023, the FASB issued ASU 2023-09, 
    Income Taxes (Topic 740): Improvements to Income Tax Disclosures. The amendments in ASU 2023-09 address investor requests for more transparency about income tax information through improvements to income tax disclosures primarily related to the rate reconciliation and income taxes paid information. Following the release of ASU 2023-09 in December 2023, the effective date was annual reporting periods beginning after December 15, 2024. As of
    December 31, 2025, we are evaluating the impact on our consolidated financial statements.

[0001437749-26-002978:mdna:71]
In March 2024, the FASB issued ASU 2024-02, Codification Improvements—Amendments to Remove References to the Concepts Statements. The amendments in ASU 2024-02 contain amendments to the Codification that remove references to various FASB Concepts Statements. Following the release of ASU 2024-02 in March 2024, the effective date was annual reporting periods beginning after December 15, 2024. As of December 31, 2025, we are evaluating the impact on our consolidated financial statements.

[0001437749-26-002978:mdna:72]
In November 2024, the FASB issued ASU 2024-03, Income Statement—Reporting Comprehensive Income—Expense Disaggregation Disclosures. The amendments in ASU 2024-03 address investor requests for more disclosure of disaggregated financial reporting information about expenses presented in the income statement. Following the release of ASU 2024-03 in November 2024, the effective date will be annual reporting periods beginning after December 15, 2026. As of December 31, 2025, we are evaluating the impact on our consolidated financial statements.

[0001437749-26-002978:mdna:73]
We do not believe that, outside of those disclosed here, there are any other recently issued accounting pronouncements that will have a material impact on our condensed consolidated financial statements.
