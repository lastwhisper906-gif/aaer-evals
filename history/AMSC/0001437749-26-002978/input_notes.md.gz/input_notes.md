# AMSC notes — 0001437749-26-002978


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0001437749-26-002978:notes:1]
[same as prior period, unchanged from 0001437749-25-033351:notes:1]

[0001437749-26-002978:notes:2]
[same as prior period, unchanged from 0001437749-25-033351:notes:2]

[0001437749-26-002978:notes:3]
[same as prior period, unchanged from 0001437749-25-033351:notes:3]

[0001437749-26-002978:notes:4]
These unaudited condensed consolidated financial statements of the Company have been prepared on a going concern basis in accordance with United States generally accepted accounting principles (“GAAP”) and the Securities and Exchange Commission’s (“SEC”) instructions to Form 10-Q. All significant intercompany accounts and transactions are eliminated in consolidation. Investments in entities in which we do not have a controlling interest are accounted for under the equity method of accounting. The going concern basis of presentation assumes that the Company will continue operations and will be able to realize its assets and discharge its liabilities and commitments in the normal course of business. Certain information and footnote disclosures normally included in the condensed consolidated financial statements prepared in accordance with GAAP have been omitted pursuant to those instructions. The year-end balance sheet data was derived from audited financial statements but does not include all disclosures required by GAAP. The unaudited condensed consolidated financial statements, in the opinion of management, reflect all adjustments (consisting of normal recurring adjustments) necessary for a fair statement of the results for the interim periods ended  December 31, 2025 and 2024, and the financial position at  December 31, 2025; however, these results are not necessarily indicative of results which  may be expected for the full year. The interim condensed consolidated financial statements, and notes thereto, should be read in conjunction with the audited condensed consolidated financial statements for the year ended  March 31, 2025, and notes thereto, included in the Company’s Annual Report on Form 10-K for the year ended  March 31, 2025 filed with the SEC on  May 21, 2025.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001437749-26-002978:notes:5]
[same as prior period, unchanged from 0001437749-25-033351:notes:5]

[0001437749-26-002978:notes:6]
Acquisition of Comtrafo

[0001437749-26-002978:notes:7]
On  December 5, 2025 (the "Comtrafo Acquisition Date"), the Company entered into a Stock Exchange Agreement (the “Stock Exchange Agreement”) with the selling stockholders named therein. Pursuant to the terms of the Stock Exchange Agreement and concurrently with entering into such agreement, the Company acquired all of the issued and outstanding shares of capital stock of Comtrafo Indústria de Transformadores Elétricos S.A. ("Comtrafo") (the "Comtrafo Acquisition"). Comtrafo is a Brazil-based manufacturer of large power and distribution transformers primarily for utility customers and also for industrial customers.

[0001437749-26-002978:notes:8]
The Comtrafo Acquisition has been accounted for under the purchase method of accounting in accordance with ASC 805, Business Combinations. The Company allocated the purchase price on a preliminary basis using the information available as of  December 31, 2025 to the assets acquired and liabilities assumed at their estimated fair values as of the date of acquisition. Due to the timing of the completion of the acquisition, the purchase price and related allocation are preliminary and could be revised as a result of adjustments made to the purchase price, and additional information obtained regarding assets acquired and liabilities assumed and revisions of provisional estimates of fair values, including, but not limited to the completion of independent appraisals of inventory, customer relationships, backlog, deferred taxes, tangible assets and intangible assets. Changes to the purchase price allocation could be significant. The purchase price allocation will be finalized within the measurement period of up to one year from the acquisition. The excess of the purchase price paid by the Company over the estimated fair value of net assets acquired has been recorded as goodwill.

[0001437749-26-002978:notes:9]
The total purchase price of approximately $202.7 million includes the fair value of the Company's common stock issued at closing, contingent consideration and cash paid, as follows (in millions):

[0001437749-26-002978:notes:10]
| Cash payments | $88.3 |
| Issuance of 2,417,142 shares of Company’s common stock | 78.5 |
| Contingent consideration | 35.9 |
| Total consideration | $202.7 |

[0001437749-26-002978:notes:11]
At the Comtrafo Acquisition Date, in addition to the $88.3 million cash, the Company valued the Company's common stock at $32.47 per share, which was the closing price on that date. Comtrafo Acquisition costs of $1.2 million were included in SG&A and $0.1 million were included in cost of revenues for the three and nine months ended  December 31, 2025.

[0001437749-26-002978:notes:12]
The following table summarizes the allocation of the purchase price based on the estimated fair values of the assets acquired and liabilities assumed and related deferred income taxes in connection with the Comtrafo Acquisition as of the Comtrafo Acquisition Date (in millions):

[0001437749-26-002978:notes:13]
| Cash and cash equivalents |  | $ | 16.2 |  |
| Prepaid expenses and other current assets |  |  | 6.7 |  |
| Accounts receivable |  |  | 4.1 |  |
| Inventory |  |  | 28.4 |  |
| Property, plant and equipment |  |  | 50.3 |  |
| Deferred tax asset |  |  | 4.1 |  |
| Accounts payable and accrued expenses |  |  | (10.2 | ) |
| Debt, current and long-term |  |  | (8.8 | ) |
| Deferred revenue |  |  | (19.8 | ) |
| Net tangible assets/(liabilities) |  |  | 71.0 |  |
| Backlog |  |  | 1.8 |  |
| Customer relationships |  |  | 7.7 |  |
| Net identifiable intangible assets/(liabilities) |  |  | 9.5 |  |
| Goodwill |  |  | 122.2 |  |
| Total purchase consideration |  | $ | 202.7 |  |

[0001437749-26-002978:notes:14]
The fair value of the financial assets acquired includes receivables with a fair value of $4.1 million. The gross amount due is $8.5 million, of which $4.4 million is expected to be uncollectible in order to align with existing AMSC reserve policy.

[0001437749-26-002978:notes:15]
Inventory includes a $1.5 million adjustment to step-up the inventory balance to fair value consistent with the purchase price allocation. The fair value was determined based on the estimated selling price of the inventory, less the remaining manufacturing and selling cost and a normal profit margin on those manufacturing and selling efforts. The inventory step-up adjustment increased cost of revenue $0.4 million in the three and nine months ended  December 31, 2025, as the inventory was sold.

[0001437749-26-002978:notes:16]
Backlog of $1.8 million was evaluated using the multi period excess earnings method under the income approach. The contracts do not provide for any guarantees to source all future requirements from the Company. The amortization method being utilized is economic consumption estimated over a sixteen-month period with the expense being allocated to cost of revenues.

[0001437749-26-002978:notes:17]
Customer relationships of $7.7 million relate to customers currently under contract and was based on a multi period excess earnings method under the income approach. The method of amortization being utilized is the economic consumption over 5 years with the expense being allocated to SG&A.

[0001437749-26-002978:notes:18]
Goodwill represents the value associated with the acquired workforce and expected synergies related to the business combination of the two companies. Goodwill resulting from the Comtrafo Acquisition was assigned to the Company's Grid segment. Goodwill recognized in the Comtrafo Acquisition is not deductible for tax purposes. The $4.1 million of deferred tax asset is primarily related to basis difference of intangibles, inventory and property, plant, and equipment.

[0001437749-26-002978:notes:19]
[same as prior period, unchanged from 0001437749-25-033351:notes:6]

[0001437749-26-002978:notes:20]
On  August 1, 2024 (the "NWL Acquisition Date"), the Company entered into a Stock Purchase Agreement (the “Stock Purchase Agreement”) with the selling stockholders named therein. Pursuant to the terms of the Stock Purchase Agreement and concurrently with entering into such agreement, the Company acquired all of the issued and outstanding shares of capital stock of Megatran Industries, Inc. ("Megatran") (the "NWL Acquisition"). Megatran's wholly-owned subsidiary, NWL, Inc. (together with Megatran, "NWL"), is a U.S.-based global provider of engineered power conversion solutions for demanding industrial and military applications.

[0001437749-26-002978:notes:21]
[same as prior period, unchanged from 0001437749-25-033351:notes:8]

[0001437749-26-002978:notes:22]
[same as prior period, unchanged from 0001437749-25-033351:notes:9]

[0001437749-26-002978:notes:23]
| Cash payments | $30.0 |
| Issuance of 1,297,600 shares of Company’s common stock | 31.4 |
| Total consideration | $61.4 |

[0001437749-26-002978:notes:24]
At the NWL Acquisition Date, in addition to the $30.0 million cash, the Company valued the Company’s common stock, at $24.16 per share, which was the closing price on the day prior to the day that the Company completed the NWL Acquisition. NWL Acquisition costs of $1.1 million were included in selling, general and administrative ("SG&A") for the fiscal year ended  March 31, 2025.

[0001437749-26-002978:notes:25]
The following table summarizes the allocation of the purchase price based on the estimated fair values of the assets acquired and liabilities assumed and related deferred income taxes in connection with the NWL Acquisition as of the NWL Acquisition Date and reflective of measurement period adjustments (in millions):

[0001437749-26-002978:notes:26]
[same as prior period, unchanged from 0001437749-25-033351:notes:13]

[0001437749-26-002978:notes:27]
[same as prior period, unchanged from 0001437749-25-033351:notes:14]

[0001437749-26-002978:notes:28]
Inventory includes a $0.7 million adjustment to step-up the inventory balance to fair value consistent with the purchase price allocation. The fair value was determined based on the estimated selling price of the inventory, less the remaining manufacturing and selling cost and a normal profit margin on those manufacturing and selling efforts. The inventory step-up adjustment increased cost of revenue $0.7 million for the fiscal year ended  March 31, 2025 as the inventory was sold.

[0001437749-26-002978:notes:29]
[same as prior period, unchanged from 0001437749-25-033351:notes:16]

[0001437749-26-002978:notes:30]
[same as prior period, unchanged from 0001437749-25-033351:notes:17]

[0001437749-26-002978:notes:31]
[same as prior period, unchanged from 0001437749-25-033351:notes:18]

[0001437749-26-002978:notes:32]
[same as prior period, unchanged from 0001437749-25-033351:notes:19]

[0001437749-26-002978:notes:33]
The unaudited pro forma condensed consolidated statement of operations for the three and nine months ended  December 31, 2025 and 2024 presented as if the NWL and Comtrafo Acquisitions had occurred on  April 1, 2024, is as follows:

[0001437749-26-002978:notes:34]
|  |  | Three Months Ended December 31, 2025 |  |  | Nine Months Ended December 31, 2025 |  |  | Three Months Ended December 31, 2024 |  |  | Nine Months Ended December 31, 2024 |  |
| Net Revenue |  | $ | 85,882 |  |  | $ | 248,163 |  |  | $ | 70,190 |  |  | $ | 222,273 |  |
| Operating income |  |  | 4,986 |  |  |  | 19,565 |  |  |  | 454 |  |  |  | 4,543 |  |
| Net income |  | $ | 119,381 |  |  | $ | 134,171 |  |  | $ | 4,776 |  |  | $ | 12,956 |  |
| Net income per common share |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 2.61 |  |  | $ | 3.03 |  |  | $ | 0.12 |  |  | $ | 0.33 |  |
| Diluted |  | $ | 2.56 |  |  | $ | 2.97 |  |  | $ | 0.11 |  |  | $ | 0.32 |  |
| Shares - basic |  |  | 45,692 |  |  |  | 44,225 |  |  |  | 41,376 |  |  |  | 39,764 |  |
| Shares - diluted |  |  | 46,673 |  |  |  | 45,163 |  |  |  | 42,178 |  |  |  | 40,454 |  |

[0001437749-26-002978:notes:35]
The pro forma amounts include the historical operating results of the Company, NWL, and Comtrafo with appropriate adjustments that give effect to acquisition related costs, income taxes, intangible amortization resulting from the NWL and Comtrafo Acquisitions and certain conforming accounting policies of the Company. The pro forma amounts are not necessarily indicative of the operating results that would have occurred if the NWL and Comtrafo Acquisitions and related transactions had been completed at the beginning of the applicable periods presented. In addition, the pro forma amounts are not necessarily indicative of operating results in future periods.

[0001437749-26-002978:notes:36]
NWL contributed $14.1 million of revenue and $0.6 million of net loss for the Company for the three months ended  December 31, 2025. NWL contributed $48.3 million of revenue and $3.9 million in net income for the Company for the nine months ended  December 31, 2025. Amortization expense of less than $0.1 million and $0.1 million is included in the three and nine months ended  December 31, 2025, respectively, as a result of the acquired intangible assets from the NWL Acquisition.

[0001437749-26-002978:notes:37]
Comtrafo contributed $4.6 million of revenue and $0.9 million in net income for the Company for the three and nine months ended  December 31, 2025. Amortization expense of $0.2 million is included in the three and nine months ended  December 31, 2025, as a result of the acquired intangible assets from the Comtrafo Acquisition. In addition, $0.4 million for the step-up basis assigned to acquired inventory was charged to cost of revenues in the three and nine months ended  December 31, 2025.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001437749-26-002978:notes:38]
[same as prior period, unchanged from 0001437749-25-033351:notes:24]

[0001437749-26-002978:notes:39]
The Company’s revenues in its Grid segment are derived primarily through enabling the transmission and distribution of power, providing planning services that allow it to identify power grid needs and risks, and developing ship protection systems for the U.S. Navy. The Company’s revenues in its Wind segment are derived primarily through supplying advanced power electronics and control systems, licensing its highly engineered wind turbine designs, and providing extensive customer support services to wind turbine manufacturers. The Company records revenue based on a five-step model in accordance with Accounting Standards Codification ("ASC") 606. For its customer contracts, the Company identifies the performance obligations, determines the transaction price, allocates the contract transaction price to the performance obligations, and recognizes the revenue when (or as) control of goods or services is transferred to the customer. For the three and nine months ended  December 31, 2025, 86% and 89%, respectively, of revenue was recognized at the point in time when control transferred to the customer, with the remainder being recognized over time. For the three and nine months ended  December 31, 2024, 87% and 88%, respectively, of revenue was recognized at the point in time when control transferred to the customer, with the remainder being recognized over time.

[0001437749-26-002978:notes:40]
[same as prior period, unchanged from 0001437749-25-033351:notes:26]

[0001437749-26-002978:notes:41]
[same as prior period, unchanged from 0001437749-25-033351:notes:27]

[0001437749-26-002978:notes:42]
[same as prior period, unchanged from 0001437749-25-033351:notes:28]

[0001437749-26-002978:notes:43]
[same as prior period, unchanged from 0001437749-25-033351:notes:29]

[0001437749-26-002978:notes:44]
[same as prior period, unchanged from 0001437749-25-033351:notes:30]

[0001437749-26-002978:notes:45]
Infrequently, the Company receives requests from customers to hold product being purchased from us for a valid business purpose. The Company recognizes revenues for such arrangements provided the transaction meets, at a minimum, the following criteria: the reason for the bill-and-hold arrangement must be substantive; the product must be identified separately as belonging to the customer; the product currently must be ready for physical transfer to the customer; the entity cannot have the ability to use the product or to direct it to another customer. Revenue for the nine months ended  December 31, 2025 included $7.9 million from such held transactions. There were no such transactions for the three months ended  December 31, 2025 and the three and nine months ended  December 31, 2024.

[0001437749-26-002978:notes:46]
The Company records revenue net of sales tax, value added tax, excise tax and other taxes collected concurrent with revenue-producing activities. The Company has elected to recognize the cost for freight and shipping when control over the products sold passes to customers and revenue is recognized. The Company has elected to recognize incremental costs of obtaining a contract as expense when incurred except in contracts where the amortization period would exceed twelve months. As of  December 31, 2025 and  March 31, 2025, the Company's capitalized incremental contract costs were not material. The Company has elected not to adjust the promised amount of consideration for the effects of a significant financing component if the period of financing is twelve months or less. The Company has elected to recognize revenue based on the as invoiced practical expedient if there is a right to consideration from a customer in an amount that corresponds directly with the value of the Company's performance.

[0001437749-26-002978:notes:47]
[same as prior period, unchanged from 0001437749-25-033351:notes:33]

[0001437749-26-002978:notes:48]
[same as prior period, unchanged from 0001437749-25-033351:notes:34]

[0001437749-26-002978:notes:49]
|  |  | Three Months Ended December 31, 2025 |  |  | Nine Months Ended December 31, 2025 |  |
| Product Line: |  | Grid |  |  | Wind |  |  | Grid |  |  | Wind |  |
| Equipment and systems |  | $ | 56,004 |  |  | $ | 143 |  |  | $ | 156,300 |  |  | $ | 445 |  |
| Services and technology development |  |  | 7,183 |  |  |  | 11,199 |  |  |  | 21,316 |  |  |  | 34,688 |  |
| Total |  | $ | 63,187 |  |  | $ | 11,342 |  |  | $ | 177,616 |  |  | $ | 35,133 |  |
| Region: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas |  | $ | 51,974 |  |  | $ | — |  |  | $ | 137,394 |  |  | $ | 16 |  |
| Asia Pacific |  |  | 7,253 |  |  |  | 11,326 |  |  |  | 29,583 |  |  |  | 35,022 |  |
| EMEA |  |  | 3,960 |  |  |  | 16 |  |  |  | 10,639 |  |  |  | 95 |  |
| Total |  | $ | 63,187 |  |  | $ | 11,342 |  |  | $ | 177,616 |  |  | $ | 35,133 |  |

[0001437749-26-002978:notes:50]
|  |  | Three Months Ended December 31, 2024 |  |  | Nine Months Ended December 31, 2024 |  |
| Product Line: |  | Grid |  |  | Wind |  |  | Grid |  |  | Wind |  |
| Equipment and systems |  | $ | 48,979 |  |  | $ | 8,768 |  |  | $ | 123,431 |  |  | $ | 23,357 |  |
| Services and technology development |  |  | 3,327 |  |  |  | 329 |  |  |  | 8,147 |  |  |  | 1,228 |  |
| Total |  | $ | 52,306 |  |  | $ | 9,097 |  |  | $ | 131,578 |  |  | $ | 24,585 |  |
| Region: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas |  | $ | 47,737 |  |  | $ | - |  |  | $ | 121,696 |  |  | $ | 1 |  |
| Asia Pacific |  |  | 2,293 |  |  |  | 9,080 |  |  |  | 4,280 |  |  |  | 24,562 |  |
| EMEA |  |  | 2,276 |  |  |  | 17 |  |  |  | 5,602 |  |  |  | 22 |  |
| Total |  | $ | 52,306 |  |  | $ | 9,097 |  |  | $ | 131,578 |  |  | $ | 24,585 |  |

[0001437749-26-002978:notes:51]
As of  December 31, 2025 and 2024, the Company’s contract assets and liabilities primarily relate to the timing differences between cash received from a customer in connection with contractual rights to invoicing and the timing of revenue recognition following completion of performance obligations. The Company's accounts receivable balance is made up entirely of customer contract related balances. Changes in the Company’s contract assets, which are included in “Unbilled accounts receivable” and “Deferred program costs” (see Note 8, “Accounts Receivable” and Note 9, “Inventory” for a reconciliation to the condensed consolidated balance sheets) and "Contract liabilities", which are included in the current portion and long-term portion of "Deferred revenue" in the Company’s condensed consolidated balance sheets, are as follows (in thousands):

[0001437749-26-002978:notes:52]
|  |  | Unbilled Accounts Receivable |  |  | Deferred Program Costs |  |  | Contract Liabilities |  |
| Beginning balance as of March 31, 2025 |  | $ | 6,376 |  |  | $ | 5,757 |  |  | $ | 76,133 |  |
| Increase for balance acquired |  |  | — |  |  |  | — |  |  |  | 19,783 |  |
| Increases for costs incurred to fulfill performance obligations |  |  | — |  |  |  | 23,174 |  |  |  | — |  |
| Increase (decrease) due to customer billings |  |  | (15,991 | ) |  |  | — |  |  |  | 81,667 |  |
| Decrease due to cost recognition on completed performance obligations |  |  | — |  |  |  | (21,767 | ) |  |  | — |  |
| Increase (decrease) due to recognition of revenue based on transfer of control of performance obligations |  |  | 22,399 |  |  |  | — |  |  |  | (88,591 | ) |
| Other changes and FX impact |  |  | 12 |  |  |  | (1 | ) |  |  | 371 |  |
| Ending balance as of December 31, 2025 |  | $ | 12,796 |  |  | $ | 7,163 |  |  | $ | 89,363 |  |

[0001437749-26-002978:notes:53]
|  |  | Unbilled Accounts Receivable |  |  | Deferred Program Costs |  |  | Contract Liabilities |  |
| Beginning balance as of March 31, 2024 |  | $ | 6,150 |  |  | $ | 2,523 |  |  | $ | 57,829 |  |
| Increase for balances acquired |  |  | — |  |  |  | — |  |  |  | 5,049 |  |
| Increases for costs incurred to fulfill performance obligations |  |  | — |  |  |  | 10,876 |  |  |  | — |  |
| Increase (decrease) due to customer billings |  |  | (7,139 | ) |  |  | — |  |  |  | 96,400 |  |
| Decrease due to cost recognition on completed performance obligations |  |  | — |  |  |  | (6,133 | ) |  |  | — |  |
| Increase (decrease) due to recognition of revenue based on transfer of control of performance obligations |  |  | 6,120 |  |  |  | — |  |  |  | (75,410 | ) |
| Other changes and FX impact |  |  | (18 | ) |  |  | (11 | ) |  |  | (540 | ) |
| Ending balance as of December 31, 2024 |  | $ | 5,113 |  |  | $ | 7,255 |  |  | $ | 83,328 |  |

[0001437749-26-002978:notes:54]
The Company’s remaining performance obligations represent the unrecognized revenue value of the Company’s contractual commitments. The Company’s performance obligations  may vary significantly each reporting period based on the timing of major new contractual commitments. As of  December 31, 2025, the Company had outstanding performance obligations on existing contracts under ASC 606 to be recognized in the next twelve months of approximately $253.5 million. There are also approximately $99.7 million of outstanding performance obligations to be recognized over a period of thirteen to sixty months. The remaining performance obligations are subject to customer actions and therefore the timing of revenue recognition cannot be reasonably estimated.

[0001437749-26-002978:notes:55]
The following table sets forth customers who represented 10% or more of the Company’s total revenues for the three and nine months ended  December 31, 2025, and 2024:

[0001437749-26-002978:notes:56]
|  |  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  | Reportable |  | December 31, |  |  | December 31, |  |
|  | Segment |  | 2025 |  |  | 2024 |  |  | 2025 |  |  | 2024 |  |
| Inox Wind Limited | Wind |  |  | 14 | % |  |  | 10 | % |  |  | 15 | % |  |  | 13 | % |
| Innomotics LLC | Grid |  |  | <10% |  |  |  | 14 | % |  |  | <10% |  |  |  | <10% |  |
| Fuji Bridex Pte Ltd | Grid |  |  | <10% |  |  |  | <10% |  |  |  | 11 | % |  |  | <10% |  |


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001437749-26-002978:notes:57]
[same as prior period, unchanged from 0001437749-25-033351:notes:43]

[0001437749-26-002978:notes:58]
The Company accounts for its stock-based compensation at fair value. The following table summarizes stock-based compensation expense by financial statement line item for the three and nine months ended  December 31, 2025, and 2024 (in thousands):

[0001437749-26-002978:notes:59]
|  |  | Three Months Ended December 31, |  |  | Nine Months Ended December 31, |  |
|  |  | 2025 |  |  | 2024 |  |  | 2025 |  |  | 2024 |  |
| Cost of revenues |  | $ | 269 |  |  | $ | 211 |  |  | $ | 875 |  |  | $ | 309 |  |
| Research and development |  |  | 504 |  |  |  | 442 |  |  |  | 1,703 |  |  |  | 697 |  |
| Selling, general and administrative |  |  | 3,049 |  |  |  | 2,208 |  |  |  | 9,536 |  |  |  | 3,927 |  |
| Total |  | $ | 3,822 |  |  | $ | 2,861 |  |  | $ | 12,114 |  |  | $ | 4,933 |  |

[0001437749-26-002978:notes:60]
The Company issued no shares and 887,000 shares of restricted stock during the three and nine months ended  December 31, 2025, respectively. The Company issued no shares and 39,445 shares of immediately vested common stock during the three and nine months ended  December 31, 2025, respectively. The Company issued 30,000 shares and 872,500 shares of restricted stock during the three and nine months ended  December 31, 2024, respectively. The Company issued no shares and 19,200 shares of immediately vested common stock during the three and nine months ended  December 31, 2024, respectively. These restricted stock awards generally vest over 2-3 years. Awards for restricted stock include both time-based and performance-based awards. For options and restricted stock awards that vest upon the passage of time, expense is being recorded over the vesting period. Performance-based awards are expensed over the requisite service period based on probability of achievement.

[0001437749-26-002978:notes:61]
The Company granted no stock options and 2,112 stock options during the three and nine months ended  December 31, 2025, respectively. The Company granted no stock options during the three and nine months ended  December 31, 2024. The stock options granted during the nine months ended  December 31, 2025 will vest over 2 years. The estimated fair value of the Company’s stock-based awards, less expected annual forfeitures, is amortized over the awards’ service period. There were less than $0.1 million of unrecognized compensation costs for unvested stock options as of  December 31, 2025. This expense will be recognized over a weighted average period of approximately 1.4 years. The total unrecognized compensation cost for unvested outstanding restricted stock was $24.9 million as of  December 31, 2025. This expense will be recognized over a weighted-average expense period of approximately 1.7 years.

[0001437749-26-002978:notes:62]
The weighted average assumptions used in the Black Scholes valuation model for stock options granted during the nine months ended  December 31, 2025 are as follows:

[0001437749-26-002978:notes:63]
|  |  | Nine Months Ended December 31, |  |
|  |  | 2025 |  |
| Expected volatility |  |  | 74.01 | % |
| Risk-free interest rate |  |  | 4.19 | % |
| Expected life (years) |  |  | 6.31 |  |
| Dividend yield |  | None |  |


## us-gaap:EarningsPerShareTextBlock

[0001437749-26-002978:notes:64]
[same as prior period, unchanged from 0001437749-25-033351:notes:50]

[0001437749-26-002978:notes:65]
Basic net income per share (“EPS”) is computed by dividing net income by the weighted-average number of common shares outstanding for the period. Where applicable, diluted EPS is computed by dividing the net income by the weighted-average number of common shares and dilutive common equivalent shares outstanding during the period, calculated using the treasury stock method. Common equivalent shares include the effect of restricted stock, exercise of stock options and warrants and contingently issuable shares. Stock options and warrants that are out-of-the-money with exercise prices greater than the average market price of the underlying common shares and shares of performance-based restricted stock where the contingency was not met are excluded from the computation of diluted EPS as the effect of their inclusion would be anti-dilutive. For the three months ended  December 31, 2025, 496,105 shares were not included in the calculation of diluted EPS. Of these, 495,834 were shares of performance-based restricted stock where the contingency was not met and 271 shares relate to outstanding stock options that were considered anti-dilutive. For the nine months ended  December 31, 2025, 508,391 shares were not included in the calculation of diluted EPS. Of these, 507,895 were shares of performance-based restricted stock where the contingency was not met and 496 shares relate to outstanding stock options that were considered anti-dilutive. For the three months ended  December 31, 2024, 475,971 shares were not included in the calculation of diluted EPS. Of these, 475,971 were shares of performance-based restricted stock where the contingency was not met. For the nine months ended  December 31, 2024, 471,985 shares were not included in the calculation of diluted EPS. Of these, 471,768 were shares of performance-based restricted stock where the contingency was not met. Of the remaining shares, 217 shares relate to outstanding stock awards that were considered anti-dilutive.

[0001437749-26-002978:notes:66]
The following table reconciles the numerators and denominators of the earnings per share calculation for the three and nine months ended  December 31, 2025, and 2024 (in thousands, except per share data):

[0001437749-26-002978:notes:67]
|  |  | Three Months Ended December 31, |  |  | Nine Months Ended December 31, |  |
|  |  | 2025 |  |  | 2024 |  |  | 2025 |  |  | 2024 |  |
| Numerator: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income |  | $ | 117,806 |  |  | $ | 2,465 |  |  | $ | 129,280 |  |  | $ | 4,828 |  |
| Denominator: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Weighted-average shares of common stock outstanding |  |  | 45,872 |  |  |  | 39,450 |  |  |  | 43,980 |  |  |  | 38,127 |  |
| Weighted-average shares subject to repurchase |  |  | (1,915 | ) |  |  | (1,789 | ) |  |  | (1,943 | ) |  |  | (1,361 | ) |
| Shares used in per-share calculation ― basic |  |  | 43,957 |  |  |  | 37,661 |  |  |  | 42,036 |  |  |  | 36,766 |  |
| Shares used in per-share calculation ― diluted |  |  | 44,939 |  |  |  | 38,463 |  |  |  | 42,975 |  |  |  | 37,457 |  |
| Net income per share ― basic |  | $ | 2.68 |  |  | $ | 0.07 |  |  | $ | 3.08 |  |  | $ | 0.13 |  |
| Net income per share ― diluted |  | $ | 2.62 |  |  | $ | 0.06 |  |  | $ | 3.01 |  |  | $ | 0.13 |  |


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001437749-26-002978:notes:68]
[same as prior period, unchanged from 0001437749-25-033351:notes:54]

[0001437749-26-002978:notes:69]
[same as prior period, unchanged from 0001437749-25-033351:notes:55]

[0001437749-26-002978:notes:70]
Goodwill represents the difference between the purchase price and the fair value of the identifiable tangible and intangible net assets when accounted for using the purchase method of accounting. Goodwill is not amortized but reviewed for impairment. The Company's goodwill balance relates to the Comtrafo Acquisition in fiscal 2025, the NWL Acquisition in fiscal 2024, the acquisition of Neeltran, Inc. in fiscal 2021, the Northeast Power Systems, Inc. ("NEPSI") acquisition in fiscal 2020, and the acquisition of Infinia Technology Corporation in fiscal 2017 and is reported in the Grid business segment. Goodwill is reviewed annually on  February 28th and whenever events or changes in circumstances indicate that the carrying value of the goodwill might not be recoverable. Goodwill increased by $122.2 million during the three and nine months ended  December 31, 2025, related to the Comtrafo Acquisition. Changes in the Company’s goodwill are as follows (in thousands):

[0001437749-26-002978:notes:71]
|  |  | Goodwill |  |
| March 31, 2025 |  | $ | 48,164 |  |
| Balance acquired - Comtrafo |  |  | 122,175 |  |
| Currency translation adjustment |  |  | (3,967 | ) |
| December 31, 2025 |  | $ | 166,373 |  |

[0001437749-26-002978:notes:72]
The Company did not identify any triggers to assess impairment in the three and nine months ended  December 31, 2025 or 2024.

[0001437749-26-002978:notes:73]
[same as prior period, unchanged from 0001437749-25-033351:notes:58]

[0001437749-26-002978:notes:74]
Intangible assets at  December 31, 2025 and  March 31, 2025 consisted of the following (in thousands):

[0001437749-26-002978:notes:75]
|  |  | December 31, 2025 |  |  | March 31, 2025 |  |  |  |  |  |
|  |  | Gross Amount |  |  | Accumulated Amortization |  |  | Net Book Value |  |  | Gross Amount |  |  | Accumulated Amortization |  |  | Net Book Value |  |  | Estimated Useful Life |  |
| Backlog |  |  | 3,095 |  |  |  | (1,488 | ) |  |  | 1,607 |  |  |  | 1,381 |  |  |  | (1,381 | ) |  |  | — |  |  |  | 2 |  |
| Trade name and trademarks |  |  | 1,800 |  |  |  |  |  |  |  | 1,800 |  |  |  | 1,800 |  |  |  | — |  |  |  | 1,800 |  |  | Indefinite |  |
| Customer relationships |  |  | 18,392 |  |  |  | (8,720 | ) |  |  | 9,671 |  |  |  | 10,880 |  |  |  | (7,901 | ) |  |  | 2,980 |  |  |  | 7-10 |  |
| Core technology and know-how |  |  | 5,970 |  |  |  | (5,197 | ) |  |  | 773 |  |  |  | 5,970 |  |  |  | (4,834 | ) |  |  | 1,136 |  |  |  | 5-10 |  |
| Intangible assets |  | $ | 29,257 |  |  | $ | (15,405 | ) |  | $ | 13,852 |  |  | $ | 20,031 |  |  | $ | (14,116 | ) |  | $ | 5,916 |  |  |  |  |  |

[0001437749-26-002978:notes:76]
The Company recorded intangible amortization expense related to customer relationship and core technology and know-how of $0.5 million and $1.2 million in the three and nine months ended  December 31, 2025, respectively. The Company recorded intangible amortization expense related to customer relationship and core technology and know-how of $0.4 million and $1.3 million in the three and nine months ended  December 31, 2024. The Company recorded intangible amortization expense related to backlog of $0.1 million in the three and nine months ended  December 31, 2025. The Company recorded intangible amortization expense related to backlog of $0.3 million and 0.4 million in the three and nine months ended  December 31, 2024, respectively.

[0001437749-26-002978:notes:77]
[same as prior period, unchanged from 0001437749-25-033351:notes:62]

[0001437749-26-002978:notes:78]
| Years ending March 31, |  | Total |  |
| 2026 (remaining) |  |  | 1,175 |  |
| 2027 |  |  | 2,735 |  |
| 2028 |  |  | 3,217 |  |
| 2029 |  |  | 2,255 |  |
| 2030 |  |  | 1,372 |  |
| Thereafter |  |  | 1,298 |  |
| Total |  | $ | 12,052 |  |

[0001437749-26-002978:notes:79]
The Company's intangible assets relate entirely to the Grid business segment operations in the United States and Brazil. The following tables summarizes the Company’s intangibles by geography (in thousands):

[0001437749-26-002978:notes:80]
|  |  | December 31, 2025 |  |  | March 31, 2025 |  |
| U.S. |  | $ | 4,904 |  |  | $ | 5,916 |  |
| Brazil |  |  | 8,947 |  |  |  | — |  |
| Total |  | $ | 13,852 |  |  | $ | 5,916 |  |


## us-gaap:FairValueDisclosuresTextBlock

[0001437749-26-002978:notes:81]
[same as prior period, unchanged from 0001437749-25-033351:notes:65]

[0001437749-26-002978:notes:82]
[same as prior period, unchanged from 0001437749-25-033351:notes:66]

[0001437749-26-002978:notes:83]
[same as prior period, unchanged from 0001437749-25-033351:notes:67]

[0001437749-26-002978:notes:84]
The Company provides a gross presentation of activity within Level 3 measurement roll-forward and details of transfers in and out of Level 1 and 2 measurements. A change in the hierarchy of an investment from its current level is reflected in the period during which the pricing methodology of such investment changes. Disclosure of the transfer of securities from Level 1 to Level 2 or Level 3 is made in the event that the related security is significant to total cash and investments. The Company did not have any transfers of assets and liabilities from Level 1, Level 2 or Level 3 of the fair value measurement hierarchy during the three or nine months ended  December 31, 2025.

[0001437749-26-002978:notes:85]
[same as prior period, unchanged from 0001437749-25-033351:notes:69]

[0001437749-26-002978:notes:86]
[same as prior period, unchanged from 0001437749-25-033351:notes:70]

[0001437749-26-002978:notes:87]
[same as prior period, unchanged from 0001437749-25-033351:notes:71]

[0001437749-26-002978:notes:88]
[same as prior period, unchanged from 0001437749-25-033351:notes:72]

[0001437749-26-002978:notes:89]
[same as prior period, unchanged from 0001437749-25-033351:notes:73]

[0001437749-26-002978:notes:90]
[same as prior period, unchanged from 0001437749-25-033351:notes:74]

[0001437749-26-002978:notes:91]
Contingent Consideration

[0001437749-26-002978:notes:92]
Contingent consideration relates to the earnout payment set forth in the Stock Exchange Agreement governing the acquisition of Comtrafo that provides the selling stockholders  may receive an additional sum of cash upon the achievement of certain specified earnings before interest, taxes, depreciation, and amortization ("EBITDA") objectives during the three years following the Comtrafo Acquisition Date. See Note 14, "Contingent Consideration" for further discussion. The Company relied on a Monte Carlo method to determine the fair value of the contingent consideration on the closing of the acquisition of Comtrafo and continues to revalue the fair value of the contingent consideration using the same method at each subsequent balance sheet date until the contingencies are resolved and the cash to be paid is determined, with the change in fair value recorded in the current period operating loss. For the period ended  December 31, 2025, the change in fair value from  December 5, 2025 was not considered material and as such no adjustment was recorded.

[0001437749-26-002978:notes:93]
The following table provides the assets and liabilities carried at fair value on a recurring basis, measured as of  December 31, 2025 and  March 31, 2025 (in thousands):

[0001437749-26-002978:notes:94]
|  |  | Total Carrying Value |  |  | Quoted Prices in Active Markets (Level 1) |  |  | Significant Other Observable Inputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |
| December 31, 2025: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash equivalents |  | $ | 98,468 |  |  | $ | 98,468 |  |  | $ | — |  |  | $ | — |  |
| Short-term cash instruments |  | $ | 1,335 |  |  | $ | — |  |  | $ | 1,335 |  |  | $ | — |  |
| Liabilities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Contingent consideration |  | $ | 34,737 |  |  | $ | — |  |  | $ | — |  |  | $ | 34,737 |  |

[0001437749-26-002978:notes:95]
[same as prior period, unchanged from 0001437749-25-033351:notes:77]

[0001437749-26-002978:notes:96]
The table below reflects the activity for the Company's contingent consideration derivative liability measured at fair value on a recurring basis (in thousands):

[0001437749-26-002978:notes:97]
|  |  | Comtrafo Acquisition Contingent Consideration |  |
| Balance at March 31, 2025 |  | $ | — |  |
| Issuance of contingent consideration |  |  | 35,902 |  |
| Change in fair value |  |  | — |  |
| FX Impact |  |  | (1,165 | ) |
| Balance at December 31, 2025 |  | $ | 34,737 |  |


## amsc:AccountsReceivableTextBlock

[0001437749-26-002978:notes:98]
[same as prior period, unchanged from 0001437749-25-033351:notes:78]

[0001437749-26-002978:notes:99]
Accounts receivable at  December 31, 2025 and  March 31, 2025 consisted of the following (in thousands):

[0001437749-26-002978:notes:100]
|  |  | December 31, 2025 |  |  | March 31, 2025 |  |
| Accounts receivable (billed) |  | $ | 49,785 |  |  | $ | 39,810 |  |
| Accounts receivable (unbilled) |  |  | 12,796 |  |  |  | 6,376 |  |
| Accounts receivable |  | $ | 62,581 |  |  | $ | 46,186 |  |


## us-gaap:InventoryDisclosureTextBlock

[0001437749-26-002978:notes:101]
[same as prior period, unchanged from 0001437749-25-033351:notes:81]

[0001437749-26-002978:notes:102]
Inventory, net of reserves, at  December 31, 2025 and  March 31, 2025 consisted of the following (in thousands):

[0001437749-26-002978:notes:103]
|  |  | December 31, 2025 |  |  | March 31, 2025 |  |
| Raw materials |  | $ | 53,480 |  |  | $ | 35,892 |  |
| Work-in-process |  |  | 32,108 |  |  |  | 19,633 |  |
| Finished goods |  |  | 12,657 |  |  |  | 9,888 |  |
| Deferred program costs |  |  | 7,163 |  |  |  | 5,756 |  |
| Net inventory |  | $ | 105,408 |  |  | $ | 71,169 |  |

[0001437749-26-002978:notes:104]
The Company recorded inventory write-downs of $0.4 million for the three months ended  December 31, 2025 and 2024. The Company recorded inventory write-downs of $2.2 million and $1.2 million for the nine months ended  December 31, 2025 and 2024, respectively. These write-downs were based on the Company's evaluation of its inventory on hand for excess quantities and obsolescence.

[0001437749-26-002978:notes:105]
Deferred program costs as of  December 31, 2025 and  March 31, 2025 primarily represent costs incurred on programs where the Company needs to complete performance obligations before the related revenue and costs will be recognized.


## us-gaap:PropertyPlantAndEquipmentDisclosureTextBlock

[0001437749-26-002978:notes:106]
[same as prior period, unchanged from 0001437749-25-033351:notes:86]

[0001437749-26-002978:notes:107]
The cost and accumulated depreciation of property, plant and equipment at  December 31, 2025 and  March 31, 2025 are as follows (in thousands):

[0001437749-26-002978:notes:108]
|  |  | December 31, 2025 |  |  | March 31, 2025 |  |
| Land |  | $ | 37,059 |  |  | $ | 22,650 |  |
| Construction in progress – equipment |  |  | 938 |  |  |  | 1,371 |  |
| Buildings |  |  | 29,854 |  |  |  | 7,528 |  |
| Equipment and software |  |  | 59,443 |  |  |  | 47,774 |  |
| Furniture and fixtures |  |  | 1,866 |  |  |  | 1,672 |  |
| Leasehold improvements |  |  | 8,334 |  |  |  | 7,969 |  |
| Property, plant and equipment, gross |  |  | 137,494 |  |  |  | 88,964 |  |
| Less accumulated depreciation |  |  | (50,043 | ) |  |  | (50,392 | ) |
| Property, plant and equipment, net |  | $ | 87,451 |  |  | $ | 38,572 |  |

[0001437749-26-002978:notes:109]
Depreciation expense was $1.0 million and $0.9 million for the three months ended  December 31, 2025 and 2024, respectively. Depreciation expense was $2.9 million and $2.3 million for the nine months ended  December 31, 2025 and 2024, respectively. The increase in land, building, and equipment and software relates to the property added as part of the Comtrafo Acquisition.


## us-gaap:EquityMethodInvestmentsDisclosureTextBlock

[0001437749-26-002978:notes:110]
[same as prior period, unchanged from 0001437749-25-033351:notes:90]

[0001437749-26-002978:notes:111]
[same as prior period, unchanged from 0001437749-25-033351:notes:91]

[0001437749-26-002978:notes:112]
[same as prior period, unchanged from 0001437749-25-033351:notes:92]

[0001437749-26-002978:notes:113]
The Company treats the equity investment in the condensed consolidated financial statements under the equity method. Equity method investments are equity securities in entities the Company does not control but over which it has the ability to exercise significant influence. These investments are accounted for under the equity method of accounting in accordance with ASC 323, Investments — Equity Method and Joint Ventures. Equity method investments are measured at cost minus impairment, if any, plus or minus the Company’s share of an investee’s income or loss, less distributions received. As of  December 31, 2025 the Company did not have material accounts receivable nor accounts payable balances with NWL Pacific. The Company's investment in NWL Pacific was $1.6 million and $1.1 million as of  December 31, 2025 and  March 31, 2025, respectively.

[0001437749-26-002978:notes:114]
The table below presents the summarized financial information for periods presented post-acquisition, as provided to the Company by the investee, for the unconsolidated company (in thousands):

[0001437749-26-002978:notes:115]
|  |  | Three Months Ended December 31, |  |  | Nine Months Ended December 31, |  |
|  |  | 2025 |  |  | 2025 |  |
| Net revenue |  | $ | 2,317 |  |  | $ | 6,003 |  |
| Gross profit |  |  | 854 |  |  |  | 2,508 |  |
| Income from operation |  |  | 334 |  |  |  | 1,089 |  |
| Net income |  | $ | 354 |  |  | $ | 1,221 |  |


## us-gaap:AccountsPayableAndAccruedLiabilitiesDisclosureTextBlock

[0001437749-26-002978:notes:116]
[same as prior period, unchanged from 0001437749-25-033351:notes:96]

[0001437749-26-002978:notes:117]
Accounts payable and accrued expenses at  December 31, 2025 and  March 31, 2025 consisted of the following (in thousands):

[0001437749-26-002978:notes:118]
|  |  | December 31, 2025 |  |  | March 31, 2025 |  |
| Accounts payable |  | $ | 16,186 |  |  | $ | 6,733 |  |
| Accrued inventories in-transit |  |  | 1,855 |  |  |  | 2,111 |  |
| Accrued other miscellaneous expenses |  |  | 5,903 |  |  |  | 3,600 |  |
| Accrued contract loss |  |  | - |  |  |  | 97 |  |
| Advanced deposits |  |  | 1,630 |  |  |  | 1,267 |  |
| Accrued compensation |  |  | 12,768 |  |  |  | 13,418 |  |
| Income taxes payable |  |  | 1,895 |  |  |  | 305 |  |
| Accrued product warranty |  |  | 4,066 |  |  |  | 3,033 |  |
| Accrued commissions |  |  | 2,299 |  |  |  | 1,718 |  |
| Total |  | $ | 46,602 |  |  | $ | 32,282 |  |

[0001437749-26-002978:notes:119]
[same as prior period, unchanged from 0001437749-25-033351:notes:99]

[0001437749-26-002978:notes:120]
[same as prior period, unchanged from 0001437749-25-033351:notes:100]

[0001437749-26-002978:notes:121]
|  |  | Three Months Ended December 31, |  |  | Nine Months Ended December 31, |  |
|  |  | 2025 |  |  | 2024 |  |  | 2025 |  |  | 2024 |  |
| Balance at beginning of period |  | $ | 3,333 |  |  | $ | 3,110 |  |  | $ | 3,033 |  |  | $ | 2,363 |  |
| Acquired warranty obligations |  |  | 450 |  |  |  | — |  |  |  | 450 |  |  |  | 637 |  |
| Provisions for warranties during the period |  |  | 551 |  |  |  | 348 |  |  |  | 1,619 |  |  |  | 1,122 |  |
| Settlements during the period |  |  | (268 | ) |  |  | (415 | ) |  |  | (1,036 | ) |  |  | (1,079 | ) |
| Balance at end of period |  | $ | 4,066 |  |  | $ | 3,043 |  |  | $ | 4,066 |  |  | $ | 3,043 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0001437749-26-002978:notes:122]
[same as prior period, unchanged from 0001437749-25-033351:notes:102]

[0001437749-26-002978:notes:123]
The Company recorded income tax benefits of $112.4 million and $112.1 million for the three and nine months ended  December 31, 2025, respectively, and income tax benefit of $0.1 million and $4.9 million for the three and nine months ended  December 31, 2024, respectively.

[0001437749-26-002978:notes:124]
On a quarterly basis, the Company reassesses the valuation allowance on deferred income tax assets, weighing positive and negative evidence to assess the recoverability of the deferred tax assets. As of  December 31, 2025, the Company recorded a $113.1 million non-cash income tax benefit related to the release of a substantial portion of its valuation allowance against deferred tax assets. This was based on the Company's evaluation of the positive evidence, including cumulative income position over the three-year period  December 31, 2025, revenue growth, current profitability, expectations regarding future forecasted income, and negative evidence, including uncertainty in economic and political environments from industry competition and dependence on government contracts. This release of the valuation allowance resulted in the recognition of a deferred tax asset and a corresponding increase to income tax benefit in the current period, the effect of which is an increase in reported net income.

[0001437749-26-002978:notes:125]
[same as prior period, unchanged from 0001437749-25-033351:notes:104]

[0001437749-26-002978:notes:126]
Accounting for income taxes requires a two-step approach to recognizing and measuring uncertain tax positions. The first step is to evaluate the tax position for recognition by determining if, based on the technical merits, it is more likely than not the position will be sustained upon audit, including resolution of related appeals or litigation processes, if any. The second step is to measure the tax benefit as the largest amount that is more than 50% likely to be realized upon ultimate settlement. The Company re-evaluates these uncertain tax positions on a quarterly basis. The evaluation is based on factors including, but not limited to, changes in facts or circumstances, changes in tax law, effectively settled issues under audit and new audit activity. Any changes in these factors could result in the recognition of a tax benefit or an additional charge to the tax provision. The Company did not identify any uncertain tax positions in the nine months ended  December 31, 2025 and did not have any gross unrecognized tax benefits as of  December 31, 2025.


## amsc:BusinessCombinationContingentConsiderationTextBlock

[0001437749-26-002978:notes:127]
[same as prior period, unchanged from 0001437749-25-033351:notes:107]

[0001437749-26-002978:notes:128]
[same as prior period, unchanged from 0001437749-25-033351:notes:108]

[0001437749-26-002978:notes:129]
[same as prior period, unchanged from 0001437749-25-033351:notes:109]

[0001437749-26-002978:notes:130]
[same as prior period, unchanged from 0001437749-25-033351:notes:110]

[0001437749-26-002978:notes:131]
Following is a summary of the key assumptions used in a Monte Carlo simulation to calculate the fair value of contingent consideration related to the NEPSI Acquisition:

[0001437749-26-002978:notes:132]
[same as prior period, unchanged from 0001437749-25-033351:notes:114]

[0001437749-26-002978:notes:133]
[same as prior period, unchanged from 0001437749-25-033351:notes:111]

[0001437749-26-002978:notes:134]
[same as prior period, unchanged from 0001437749-25-033351:notes:112]

[0001437749-26-002978:notes:135]
Comtrafo Contingent Consideration

[0001437749-26-002978:notes:136]
On  December 5, 2025, the Company entered into the Stock Exchange Agreement with the selling stockholders named therein. Pursuant to the terms of the Stock Exchange Agreement, the Company has agreed to pay the selling stockholders of the Comtrafo Acquisition an additional amount in cash upon the achievement of specified EBITDA objectives during the three years following the Comtrafo Acquisition Date. The Company evaluated the Comtrafo Acquisition earnout payment set forth in the Comtrafo Stock Exchange Agreement (See Note 2, "Acquisitions" for further details), which will require settlement in cash, and determined the contingent consideration qualified for liability classification. As a result, for each period, the fair value of the contingent consideration will be remeasured, and the resulting gain or loss will be recognized until the cash amount is fixed.

[0001437749-26-002978:notes:137]
Following is a summary of the key assumptions used in a Monte Carlo simulation to calculate the fair value of contingent consideration related to the Comtrafo Acquisition:

[0001437749-26-002978:notes:138]
|  |  | December 05, |  |
| Fiscal Year 2025 |  | 2025 |  |
| EBITDA Risk Premium (continuous) |  |  | 2.10 | % |
| EBITDA Volatility |  |  | 25.0 | % |
| Credit Spread (semiannual) |  |  | 1.9 | % |
| Payment delay (days) |  |  | 89 |  |
| Fair value (millions) |  | $ | 35.9 |  |

[0001437749-26-002978:notes:139]
The Company performed an analysis on the change in fair value through  December 31, 2025 and concluded the impact was immaterial to the financial statements. The Company recorded no gains or losses from the changes in fair value of the contingent consideration in the three and nine months ended  December 31, 2025. The Company recorded a loss of $6.7 million resulting from the increases in the fair value of the NEPSI and NWL contingent consideration in the nine months ended  December 31, 2024.


## us-gaap:DebtDisclosureTextBlock

[0001437749-26-002978:notes:140]
15. Debt

[0001437749-26-002978:notes:141]
As part of the Comtrafo Acquisition, the Company identified three debt agreements that Comtrafo had entered into prior to the Comtrafo Acquisition Date. Based on the current maturity schedules of the respective agreements, the Company recorded current and long-term debt of $1.6 million and $6.1 million, respectively during the three months ended  December 31, 2025.


## us-gaap:LesseeOperatingLeasesTextBlock

[0001437749-26-002978:notes:142]
16. Leases

[0001437749-26-002978:notes:143]
[same as prior period, unchanged from 0001437749-25-033351:notes:117]

[0001437749-26-002978:notes:144]
[same as prior period, unchanged from 0001437749-25-033351:notes:118]

[0001437749-26-002978:notes:145]
[same as prior period, unchanged from 0001437749-25-033351:notes:119]

[0001437749-26-002978:notes:146]
Supplemental balance sheet information related to leases at  December 31, 2025, and  March 31, 2025 are as follows (in thousands):

[0001437749-26-002978:notes:147]
|  |  | December 31, 2025 |  |  | March 31, 2025 |  |
| Leases: |  |  |  |  |  |  |  |  |
| Right-of-use assets – Operating |  | $ | 3,655 |  |  | $ | 3,829 |  |
| Total right-of-use assets |  |  | 3,655 |  |  |  | 3,829 |  |
| Lease liabilities – ST Operating |  | $ | 1,078 |  |  | $ | 685 |  |
| Lease liabilities – LT Operating |  |  | 2,560 |  |  |  | 2,684 |  |
| Total lease liabilities |  | $ | 3,638 |  |  | $ | 3,369 |  |
| Weighted-average remaining lease term |  |  | 4.46 |  |  |  | 4.94 |  |
| Weighted-average discount rate |  |  | 15.51 | % |  |  | 14.94 | % |

[0001437749-26-002978:notes:148]
The costs related to the Company's operating leases for the three and nine months ended  December 31, 2025 and 2024, are as follows (in thousands):

[0001437749-26-002978:notes:149]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | December 31, 2025 |  |  | December 31, 2025 |  |
| Operating Leases: |  |  |  |  |  |  |  |  |
| Operating lease costs – fixed |  | $ | 425 |  |  | $ | 1,259 |  |
| Operating lease costs – variable |  |  | 45 |  |  |  | 136 |  |
| Short-term lease costs |  |  | 42 |  |  |  | 125 |  |
| Total lease costs |  | $ | 512 |  |  | $ | 1,520 |  |

[0001437749-26-002978:notes:150]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | December 31, 2024 |  |  | December 31, 2024 |  |
| Operating Leases: |  |  |  |  |  |  |  |  |
| Operating lease costs – fixed |  | $ | 407 |  |  | $ | 1,052 |  |
| Operating lease costs – variable |  |  | 21 |  |  |  | 110 |  |
| Short-term lease costs |  |  | 38 |  |  |  | 116 |  |
| Total lease costs |  | $ | 466 |  |  | $ | 1,278 |  |

[0001437749-26-002978:notes:151]
[same as prior period, unchanged from 0001437749-25-033351:notes:125]

[0001437749-26-002978:notes:152]
|  |  | Leases |  |
| Year ending March 31, |  |  |  |  |
| 2026 (remaining) |  | $ | 305 |  |
| 2027 |  |  | 1,583 |  |
| 2028 |  |  | 1,026 |  |
| 2029 |  |  | 420 |  |
| 2030 |  |  | 350 |  |
| Thereafter |  |  | 1,242 |  |
| Total minimum lease payments |  |  | 4,926 |  |
| Less: interest |  |  | (1,288 | ) |
| Present value of lease liabilities |  | $ | 3,638 |  |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001437749-26-002978:notes:153]
17. Commitments and Contingencies

[0001437749-26-002978:notes:154]
Legal Contingencies

[0001437749-26-002978:notes:155]
From time to time, the Company is involved in legal and administrative proceedings and claims of various types. The Company records a liability in its condensed consolidated financial statements for these matters when a loss is known or considered probable and the amount can be reasonably estimated. The Company reviews these estimates each accounting period as additional information is known and adjusts the loss provision when appropriate. If a matter is both probable to result in a liability and the amounts of loss can be reasonably estimated, the Company estimates and discloses the possible loss or range of loss to the extent necessary to make the condensed consolidated financial statements not misleading. If the loss is not probable or cannot be reasonably estimated, a liability is not recorded in its condensed consolidated financial statements.

[0001437749-26-002978:notes:156]
Other

[0001437749-26-002978:notes:157]
The Company enters into long-term construction contracts with customers that require the Company to obtain performance bonds. The Company is required to deposit an amount equivalent to some or all the face amount of the performance bonds into an escrow account until the termination of the bond. When the performance conditions are met, amounts deposited as collateral for the performance bonds are returned to the Company. In addition, the Company has various contractual arrangements in which minimum quantities of goods or services have been committed to be purchased on an annual basis.

[0001437749-26-002978:notes:158]
AMSC Brazil, through Comtrafo, entered into an agreement to purchase additional real estate within the twelve months following the Comtrafo Acquisition Date for 37,246,459 Brazilian Real upon successful re-zoning classification of such real estate.

[0001437749-26-002978:notes:159]
As of  December 31, 2025, the Company had $3.3 million of restricted cash included in long-term assets and $2.8 million of restricted cash included in current assets. As of  March 31, 2025, the Company had $4.3 million of restricted cash included in long-term assets and $1.6 million of restricted cash included in current assets. These amounts included in restricted cash primarily represent deposits to secure letters of credit for various supply contracts and long-term projects or collateral deposits. These deposits are held in interest bearing accounts.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001437749-26-002978:notes:160]
18. Business Segments

[0001437749-26-002978:notes:161]
[same as prior period, unchanged from 0001437749-25-033351:notes:134]

[0001437749-26-002978:notes:162]
[same as prior period, unchanged from 0001437749-25-033351:notes:135]

[0001437749-26-002978:notes:163]
[same as prior period, unchanged from 0001437749-25-033351:notes:136]

[0001437749-26-002978:notes:164]
[same as prior period, unchanged from 0001437749-25-033351:notes:137]

[0001437749-26-002978:notes:165]
The following tables (i) summarize total sales by segment and (ii) reconcile each segment's sales to their respective segment operating income, including segment operating expenses, for each of the three and nine months ended  December 31, 2025 and 2024 (in thousands):

[0001437749-26-002978:notes:166]
|  |  | Three Months Ended December 31, 2025 |  |  | Nine Months Ended December 31, 2025 |  |
|  |  | Grid |  |  | Wind |  |  | Unallocated |  |  | Total |  |  | Grid |  |  | Wind |  |  | Unallocated |  |  | Total |  |
| Segment operating income: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Revenues |  | $ | 63,187 |  |  | $ | 11,342 |  |  | $ | - |  |  | $ | 74,529 |  |  | $ | 177,616 |  |  | $ | 35,133 |  |  | $ | - |  |  | $ | 212,749 |  |
| Less (a) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Segment other operating expenses (b) |  |  | 61,156 |  |  |  | 10,014 |  |  |  | - |  |  |  | 71,170 |  |  |  | 170,152 |  |  |  | 30,630 |  |  |  | - |  |  |  | 200,782 |  |
| Segment operating income |  | $ | 2,031 |  |  | $ | 1,328 |  |  | $ | - |  |  | $ | 3,359 |  |  | $ | 7,464 |  |  | $ | 4,503 |  |  | $ | - |  |  | $ | 11,967 |  |

[0001437749-26-002978:notes:167]
[same as prior period, unchanged from 0001437749-25-033351:notes:140]

[0001437749-26-002978:notes:168]
[same as prior period, unchanged from 0001437749-25-033351:notes:141]

[0001437749-26-002978:notes:169]
|  |  | Three Months Ended December 31, 2024 |  |  | Nine Months Ended December 31, 2024 |  |
|  |  | Grid |  |  | Wind |  |  | Unallocated |  |  | Total |  |  | Grid |  |  | Wind |  |  | Unallocated |  |  | Total |  |
| Segment operating income: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Revenues |  | $ | 52,306 |  |  | $ | 9,097 |  |  | $ | - |  |  | $ | 61,403 |  |  | $ | 131,578 |  |  | $ | 24,585 |  |  | $ | - |  |  | $ | 156,163 |  |
| Less (a) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Segment other operating expenses (b) |  |  | 52,072 |  |  |  | 8,016 |  |  |  | - |  |  |  | 60,088 |  |  |  | 130,006 |  |  |  | 22,198 |  |  |  | 6,689 |  |  |  | 158,893 |  |
| Segment operating income (loss) |  | $ | 234 |  |  | $ | 1,081 |  |  | $ | - |  |  | $ | 1,315 |  |  | $ | 1,572 |  |  | $ | 2,387 |  |  | $ | (6,689 | ) |  | $ | (2,730 | ) |

[0001437749-26-002978:notes:170]
[same as prior period, unchanged from 0001437749-25-033351:notes:143]

[0001437749-26-002978:notes:171]
Unallocated corporate expenses consisted of net losses resulting from activity relating to both the NEPSI earnout and the Megatran make whole payment which resulted in $6.7 million in increases in the fair value of contingent consideration in the nine months ended  December 31, 2024.

[0001437749-26-002978:notes:172]
The reconciliation of segment operating income (loss) to consolidated income (loss) before income taxes for the three and nine months ended  December 31, 2025 and 2024 is as follows (in thousands):

[0001437749-26-002978:notes:173]
|  |  | Three Months Ended December 31, |  |  | Nine Months Ended December 31, 2025 |  |
|  |  | 2025 |  |  | 2024 |  |  | 2025 |  |  | 2024 |  |
| Operating income (loss): |  | $ | 3,359 |  |  | $ | 1,315 |  |  | $ | 11,967 |  |  | $ | (2,730 | ) |
| Interest income, net |  |  | 1,997 |  |  |  | 802 |  |  |  | 5,198 |  |  | $ | 2,901 |  |
| Other (expense)/income, net |  |  | 77 |  |  |  | 272 |  |  |  | 57 |  |  |  | (214 | ) |
| Income (loss) before income tax benefit |  | $ | 5,433 |  |  | $ | 2,389 |  |  | $ | 17,222 |  |  | $ | (43 | ) |

[0001437749-26-002978:notes:174]
Depreciation and amortization expense by segment for the three and nine months ended  December 31, 2025 and 2024 is as follows (in thousands):

[0001437749-26-002978:notes:175]
|  |  | Three Months Ended December 31, |  |  | Nine Months Ended December 31, 2025 |  |
|  |  | 2025 |  |  | 2024 |  |  | 2025 |  |  | 2024 |  |
| Grid |  | $ | 1,726 |  |  | $ | 1,567 |  |  | $ | 4,089 |  |  | $ | 3,920 |  |
| Wind |  |  | 63 |  |  |  | 22 |  |  |  | 95 |  |  | $ | 64 |  |
| Total |  | $ | 1,789 |  |  | $ | 1,589 |  |  | $ | 4,184 |  |  | $ | 3,984 |  |

[0001437749-26-002978:notes:176]
[same as prior period, unchanged from 0001437749-25-033351:notes:149]

[0001437749-26-002978:notes:177]
Total assets for the two business segments as of  December 31, 2025 and  March 31, 2025, are as follows (in thousands):

[0001437749-26-002978:notes:178]
|  |  | December 31, 2025 |  |  | March 31, 2025 |  |
| Grid |  | $ | 558,431 |  |  | $ | 211,520 |  |
| Wind |  |  | 13,969 |  |  |  | 13,697 |  |
| Corporate assets |  |  | 147,134 |  |  |  | 85,304 |  |
| Total |  | $ | 719,534 |  |  | $ | 310,521 |  |


## us-gaap:NewAccountingPronouncementsAndChangesInAccountingPrinciplesTextBlock

[0001437749-26-002978:notes:179]
19. Recent Accounting Pronouncements

[0001437749-26-002978:notes:180]
In  December 2023, the FASB issued ASU 2023-09, Income Taxes (Topic 740): Improvements to Income Tax Disclosures. The amendments in ASU 2023-09 address investor requests for more transparency about income tax information through improvements to income tax disclosures primarily related to the rate reconciliation and income taxes paid information. Following the release of ASU 2023-09 in  December 2023, the effective date was annual reporting periods beginning after  December 15, 2024. As of  December 31, 2025, the Company is evaluating the impact on its consolidated financial statements.

[0001437749-26-002978:notes:181]
In  March 2024, the FASB issued ASU 2024-02, Codification Improvements—Amendments to Remove References to the Concepts Statements. The amendments in ASU 2024-02 contain amendments to the Codification that remove references to various FASB Concepts Statements. Following the release of ASU 2024-02 in  March 2024, the effective date was annual reporting periods beginning after  December 15, 2024. As of  December 31, 2025, the Company is evaluating the impact on its consolidated financial statements.

[0001437749-26-002978:notes:182]
In  November 2024, the FASB issued ASU 2024-03, Income Statement—Reporting Comprehensive Income—Expense Disaggregation Disclosures. The amendments in ASU 2024-03 address investor requests for more disclosure of disaggregated financial reporting information about expenses presented in the income statement. Following the release of ASU 2024-03 in  November 2024, the effective date will be annual reporting periods beginning after  December 15, 2026. As of  December 31, 2025, the Company is evaluating the impact on its consolidated financial statements.


## us-gaap:SubsequentEventsTextBlock

[0001437749-26-002978:notes:183]
20. Subsequent Events

[0001437749-26-002978:notes:184]
The Company has performed an evaluation of subsequent events through the time of filing this Quarterly Report on Form 10-Q with the SEC and has determined that there are no such events to report.


## ecd:MtrlTermsOfTrdArrTextBlock

[0001437749-26-002978:notes:185]
[same as prior period, unchanged from 0001437749-25-033351:notes:158]

[0001437749-26-002978:notes:186]
[same as prior period, unchanged from 0001437749-25-033351:notes:159]

[0001437749-26-002978:notes:187]
[same as prior period, unchanged from 0001437749-25-033351:notes:160]

[0001437749-26-002978:notes:188]
(c) During the three months ended  December 31, 2025, no director or officer of the Company adopted or terminated a "Rule 10b5-1 trading arrangement" or "non-Rule 10b5-1 trading arrangement," as each term is defined in Item 408(a) of Regulation S-K.
