# AMSC note change history — 0001437749-25-033351 → 0001437749-26-002978


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- added (2026-02-04):
[0001437749-26-002978:note_history:1]
AMSC Brazil, through Comtrafo, entered into an agreement to purchase additional real estate within the twelve months following the Comtrafo Acquisition Date for 37,246,459 Brazilian Real upon successful re-zoning classification of such real estate.

- changed (2026-02-04):
[0001437749-26-002978:note_history:2]
As of  December 31, 2025, the Company had $3.3 million of restricted cash included in long-term assets and $2.8 million of restricted cash included in current assets. As of  March 31, 2025, the Company had $4.3 million of restricted cash included in long-term assets and $1.6 million of restricted cash included in current assets. These amounts included in restricted cash primarily represent deposits to secure letters of credit for various supply contracts and long-term projects or collateral deposits. These deposits are held in interest bearing accounts.
  (was, 2025-11-05, similarity 0.9916):
[0001437749-25-033351:note_history:2]
As of  September 30, 2025, the Company had $3.0 million of restricted cash included in long-term assets and $2.9 million of restricted cash included in current assets. As of  March 31, 2025, the Company had $4.3 million of restricted cash included in long term assets and $1.6 million of restricted cash included in current assets. These amounts included in restricted cash primarily represent deposits to secure letters of credit for various supply contracts and long-term projects or collateral deposits. These deposits are held in interest bearing accounts.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2026-02-04):
[0001437749-26-002978:note_history:3]
These unaudited condensed consolidated financial statements of the Company have been prepared on a going concern basis in accordance with United States generally accepted accounting principles (“GAAP”) and the Securities and Exchange Commission’s (“SEC”) instructions to Form 10-Q. All significant intercompany accounts and transactions are eliminated in consolidation. Investments in entities in which we do not have a controlling interest are accounted for under the equity method of accounting. The going concern basis of presentation assumes that the Company will continue operations and will be able to realize its assets and discharge its liabilities and commitments in the normal course of business. Certain information and footnote disclosures normally included in the condensed consolidated financial statements prepared in accordance with GAAP have been omitted pursuant to those instructions. The year-end balance sheet data was derived from audited financial statements but does not include all disclosures required by GAAP. The unaudited condensed consolidated financial statements, in the opinion of management, reflect all adjustments (consisting of normal recurring adjustments) necessary for a fair statement of the results for the interim periods ended  December 31, 2025 and 2024, and the financial position at  December 31, 2025; however, these results are not necessarily indicative of results which  may be expected for the full year. The interim condensed consolidated financial statements, and notes thereto, should be read in conjunction with the audited condensed consolidated financial statements for the year ended  March 31, 2025, and notes thereto, included in the Company’s Annual Report on Form 10-K for the year ended  March 31, 2025 filed with the SEC on  May 21, 2025.
  (was, 2025-11-05, similarity 0.996):
[0001437749-25-033351:note_history:3]
These unaudited condensed consolidated financial statements of the Company have been prepared on a going concern basis in accordance with United States generally accepted accounting principles (“GAAP”) and the Securities and Exchange Commission’s (“SEC”) instructions to Form 10-Q. All significant intercompany accounts and transactions are eliminated in consolidation. Investments in entities in which we do not have a controlling interest are accounted for under the equity method of accounting. The going concern basis of presentation assumes that the Company will continue operations and will be able to realize its assets and discharge its liabilities and commitments in the normal course of business. Certain information and footnote disclosures normally included in the condensed consolidated financial statements prepared in accordance with GAAP have been omitted pursuant to those instructions. The year-end balance sheet data was derived from audited financial statements but does not include all disclosures required by GAAP. The unaudited condensed consolidated financial statements, in the opinion of management, reflect all adjustments (consisting of normal recurring adjustments) necessary for a fair statement of the results for the interim periods ended  September 30, 2025 and 2024, and the financial position at  September 30, 2025; however, these results are not necessarily indicative of results which  may be expected for the full year. The interim condensed consolidated financial statements, and notes thereto, should be read in conjunction with the audited condensed consolidated financial statements for the year ended  March 31, 2025, and notes thereto, included in the Company’s Annual Report on Form 10-K for the year ended  March 31, 2025 filed with the SEC on  May 21, 2025.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: no_prior_note, score: 0.0

- added (2026-02-04):
[0001437749-26-002978:note_history:4]
15. Debt

- added (2026-02-04):
[0001437749-26-002978:note_history:5]
As part of the Comtrafo Acquisition, the Company identified three debt agreements that Comtrafo had entered into prior to the Comtrafo Acquisition Date. Based on the current maturity schedules of the respective agreements, the Company recorded current and long-term debt of $1.6 million and $6.1 million, respectively during the three months ended  December 31, 2025.


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2026-02-04):
[0001437749-26-002978:note_history:6]
|  |  | Three Months Ended December 31, 2025 |  |  | Nine Months Ended December 31, 2025 |  |
| Product Line: |  | Grid |  |  | Wind |  |  | Grid |  |  | Wind |  |
| Equipment and systems |  | $ | 56,004 |  |  | $ | 143 |  |  | $ | 156,300 |  |  | $ | 445 |  |
| Services and technology development |  |  | 7,183 |  |  |  | 11,199 |  |  |  | 21,316 |  |  |  | 34,688 |  |
| Total |  | $ | 63,187 |  |  | $ | 11,342 |  |  | $ | 177,616 |  |  | $ | 35,133 |  |
| Region: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas |  | $ | 51,974 |  |  | $ | — |  |  | $ | 137,394 |  |  | $ | 16 |  |
| Asia Pacific |  |  | 7,253 |  |  |  | 11,326 |  |  |  | 29,583 |  |  |  | 35,022 |  |
| EMEA |  |  | 3,960 |  |  |  | 16 |  |  |  | 10,639 |  |  |  | 95 |  |
| Total |  | $ | 63,187 |  |  | $ | 11,342 |  |  | $ | 177,616 |  |  | $ | 35,133 |  |
  (was, 2025-11-05, similarity 0.9815):
[0001437749-25-033351:note_history:6]
|  |  | Three Months Ended September 30, 2025 |  |  | Six Months Ended September 30, 2025 |  |
| Product Line: |  | Grid |  |  | Wind |  |  | Grid |  |  | Wind |  |
| Equipment and systems |  | $ | 49,951 |  |  | $ | 11,223 |  |  | $ | 105,574 |  |  | $ | 23,103 |  |
| Services and technology development |  |  | 4,391 |  |  |  | 297 |  |  |  | 8,855 |  |  |  | 688 |  |
| Total |  | $ | 54,342 |  |  | $ | 11,520 |  |  | $ | 114,429 |  |  | $ | 23,791 |  |
| Region: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas |  | $ | 47,400 |  |  | $ | 16 |  |  | $ | 85,421 |  |  | $ | 16 |  |
| Asia Pacific |  |  | 4,026 |  |  |  | 11,425 |  |  |  | 22,329 |  |  |  | 23,696 |  |
| EMEA |  |  | 2,916 |  |  |  | 79 |  |  |  | 6,679 |  |  |  | 79 |  |
| Total |  | $ | 54,342 |  |  | $ | 11,520 |  |  | $ | 114,429 |  |  | $ | 23,791 |  |

- changed (2026-02-04):
[0001437749-26-002978:note_history:7]
|  |  | Three Months Ended December 31, 2024 |  |  | Nine Months Ended December 31, 2024 |  |
| Product Line: |  | Grid |  |  | Wind |  |  | Grid |  |  | Wind |  |
| Equipment and systems |  | $ | 48,979 |  |  | $ | 8,768 |  |  | $ | 123,431 |  |  | $ | 23,357 |  |
| Services and technology development |  |  | 3,327 |  |  |  | 329 |  |  |  | 8,147 |  |  |  | 1,228 |  |
| Total |  | $ | 52,306 |  |  | $ | 9,097 |  |  | $ | 131,578 |  |  | $ | 24,585 |  |
| Region: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas |  | $ | 47,737 |  |  | $ | - |  |  | $ | 121,696 |  |  | $ | 1 |  |
| Asia Pacific |  |  | 2,293 |  |  |  | 9,080 |  |  |  | 4,280 |  |  |  | 24,562 |  |
| EMEA |  |  | 2,276 |  |  |  | 17 |  |  |  | 5,602 |  |  |  | 22 |  |
| Total |  | $ | 52,306 |  |  | $ | 9,097 |  |  | $ | 131,578 |  |  | $ | 24,585 |  |
  (was, 2025-11-05, similarity 0.9815):
[0001437749-25-033351:note_history:7]
|  |  | Three Months Ended September 30, 2024 |  |  | Six Months Ended September 30, 2024 |  |
| Product Line: |  | Grid |  |  | Wind |  |  | Grid |  |  | Wind |  |
| Equipment and systems |  | $ | 43,747 |  |  | $ | 7,166 |  |  | $ | 74,452 |  |  | $ | 14,591 |  |
| Services and technology development |  |  | 3,189 |  |  |  | 369 |  |  |  | 4,820 |  |  |  | 898 |  |
| Total |  | $ | 46,936 |  |  | $ | 7,535 |  |  | $ | 79,272 |  |  | $ | 15,489 |  |
| Region: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas |  | $ | 43,479 |  |  | $ | 1 |  |  | $ | 73,957 |  |  | $ | 1 |  |
| Asia Pacific |  |  | 790 |  |  |  | 7,531 |  |  |  | 1,989 |  |  |  | 15,483 |  |
| EMEA |  |  | 2,667 |  |  |  | 3 |  |  |  | 3,326 |  |  |  | 5 |  |
| Total |  | $ | 46,936 |  |  | $ | 7,535 |  |  | $ | 79,272 |  |  | $ | 15,489 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2026-02-04):
[0001437749-26-002978:note_history:8]
The Company’s revenues in its Grid segment are derived primarily through enabling the transmission and distribution of power, providing planning services that allow it to identify power grid needs and risks, and developing ship protection systems for the U.S. Navy. The Company’s revenues in its Wind segment are derived primarily through supplying advanced power electronics and control systems, licensing its highly engineered wind turbine designs, and providing extensive customer support services to wind turbine manufacturers. The Company records revenue based on a five-step model in accordance with Accounting Standards Codification ("ASC") 606. For its customer contracts, the Company identifies the performance obligations, determines the transaction price, allocates the contract transaction price to the performance obligations, and recognizes the revenue when (or as) control of goods or services is transferred to the customer. For the three and nine months ended  December 31, 2025, 86% and 89%, respectively, of revenue was recognized at the point in time when control transferred to the customer, with the remainder being recognized over time. For the three and nine months ended  December 31, 2024, 87% and 88%, respectively, of revenue was recognized at the point in time when control transferred to the customer, with the remainder being recognized over time.
  (was, 2025-11-05, similarity 0.8246):
[0001437749-25-033351:note_history:8]
The Company’s revenues in its Grid segment are derived primarily through enabling the transmission and distribution of power, providing planning services that allow it to identify power grid needs and risks, and developing ship protection systems for the U.S. Navy. The Company’s revenues in its Wind segment are derived primarily through supplying advanced power electronics and control systems, licensing its highly engineered wind turbine designs, and providing extensive customer support services to wind turbine manufacturers. The Company records revenue based on a five-step model in accordance with Accounting Standards Codification ("ASC") 606. For its customer contracts, the Company identifies the performance obligations, determines the transaction price, allocates the contract transaction price to the performance obligations, and recognizes the revenue when (or as) control of goods or services is transferred to the customer. For both the three and six months ended  September 30, 2025, 90% of revenue was recognized at the point in time when control transferred to the customer, with the remainder being recognized over time. For the three and six months ended  September 30, 2024, 90% and 89%, respectively, of revenue was recognized at the point in time when control transferred to the customer, with the remainder being recognized over time.

- changed (2026-02-04):
[0001437749-26-002978:note_history:9]
Infrequently, the Company receives requests from customers to hold product being purchased from us for a valid business purpose. The Company recognizes revenues for such arrangements provided the transaction meets, at a minimum, the following criteria: the reason for the bill-and-hold arrangement must be substantive; the product must be identified separately as belonging to the customer; the product currently must be ready for physical transfer to the customer; the entity cannot have the ability to use the product or to direct it to another customer. Revenue for the nine months ended  December 31, 2025 included $7.9 million from such held transactions. There were no such transactions for the three months ended  December 31, 2025 and the three and nine months ended  December 31, 2024.
  (was, 2025-11-05, similarity 0.9063):
[0001437749-25-033351:note_history:9]
Infrequently, the Company receives requests from customers to hold product being purchased from us for a valid business purpose. The Company recognizes revenues for such arrangements provided the transaction meets, at a minimum, the following criteria: the reason for the bill-and-hold arrangement must be substantive; the product must be identified separately as belonging to the customer; the product currently must be ready for physical transfer to the customer; the entity cannot have the ability to use the product or to direct it to another customer. Revenue for the three and six months ended  September 30, 2025 included $7.9 million from such held transactions. There were no such transactions for the three and six months ended  September 30, 2024.

- changed (2026-02-04):
[0001437749-26-002978:note_history:10]
The Company records revenue net of sales tax, value added tax, excise tax and other taxes collected concurrent with revenue-producing activities. The Company has elected to recognize the cost for freight and shipping when control over the products sold passes to customers and revenue is recognized. The Company has elected to recognize incremental costs of obtaining a contract as expense when incurred except in contracts where the amortization period would exceed twelve months. As of  December 31, 2025 and  March 31, 2025, the Company's capitalized incremental contract costs were not material. The Company has elected not to adjust the promised amount of consideration for the effects of a significant financing component if the period of financing is twelve months or less. The Company has elected to recognize revenue based on the as invoiced practical expedient if there is a right to consideration from a customer in an amount that corresponds directly with the value of the Company's performance.
  (was, 2025-11-05, similarity 0.9965):
[0001437749-25-033351:note_history:10]
The Company records revenue net of sales tax, value added tax, excise tax and other taxes collected concurrent with revenue-producing activities. The Company has elected to recognize the cost for freight and shipping when control over the products sold passes to customers and revenue is recognized. The Company has elected to recognize incremental costs of obtaining a contract as expense when incurred except in contracts where the amortization period would exceed twelve months. As of  September 30, 2025 and  March 31, 2025, the Company's capitalized incremental contract costs were not material. The Company has elected not to adjust the promised amount of consideration for the effects of a significant financing component if the period of financing is twelve months or less. The Company has elected to recognize revenue based on the as invoiced practical expedient if there is a right to consideration from a customer in an amount that corresponds directly with the value of the Company's performance.

- changed (2026-02-04):
[0001437749-26-002978:note_history:11]
|  |  | Three Months Ended December 31, 2025 |  |  | Nine Months Ended December 31, 2025 |  |
| Product Line: |  | Grid |  |  | Wind |  |  | Grid |  |  | Wind |  |
| Equipment and systems |  | $ | 56,004 |  |  | $ | 143 |  |  | $ | 156,300 |  |  | $ | 445 |  |
| Services and technology development |  |  | 7,183 |  |  |  | 11,199 |  |  |  | 21,316 |  |  |  | 34,688 |  |
| Total |  | $ | 63,187 |  |  | $ | 11,342 |  |  | $ | 177,616 |  |  | $ | 35,133 |  |
| Region: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas |  | $ | 51,974 |  |  | $ | — |  |  | $ | 137,394 |  |  | $ | 16 |  |
| Asia Pacific |  |  | 7,253 |  |  |  | 11,326 |  |  |  | 29,583 |  |  |  | 35,022 |  |
| EMEA |  |  | 3,960 |  |  |  | 16 |  |  |  | 10,639 |  |  |  | 95 |  |
| Total |  | $ | 63,187 |  |  | $ | 11,342 |  |  | $ | 177,616 |  |  | $ | 35,133 |  |
  (was, 2025-11-05, similarity 0.9815):
[0001437749-25-033351:note_history:11]
|  |  | Three Months Ended September 30, 2025 |  |  | Six Months Ended September 30, 2025 |  |
| Product Line: |  | Grid |  |  | Wind |  |  | Grid |  |  | Wind |  |
| Equipment and systems |  | $ | 49,951 |  |  | $ | 11,223 |  |  | $ | 105,574 |  |  | $ | 23,103 |  |
| Services and technology development |  |  | 4,391 |  |  |  | 297 |  |  |  | 8,855 |  |  |  | 688 |  |
| Total |  | $ | 54,342 |  |  | $ | 11,520 |  |  | $ | 114,429 |  |  | $ | 23,791 |  |
| Region: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas |  | $ | 47,400 |  |  | $ | 16 |  |  | $ | 85,421 |  |  | $ | 16 |  |
| Asia Pacific |  |  | 4,026 |  |  |  | 11,425 |  |  |  | 22,329 |  |  |  | 23,696 |  |
| EMEA |  |  | 2,916 |  |  |  | 79 |  |  |  | 6,679 |  |  |  | 79 |  |
| Total |  | $ | 54,342 |  |  | $ | 11,520 |  |  | $ | 114,429 |  |  | $ | 23,791 |  |

- changed (2026-02-04):
[0001437749-26-002978:note_history:12]
|  |  | Three Months Ended December 31, 2024 |  |  | Nine Months Ended December 31, 2024 |  |
| Product Line: |  | Grid |  |  | Wind |  |  | Grid |  |  | Wind |  |
| Equipment and systems |  | $ | 48,979 |  |  | $ | 8,768 |  |  | $ | 123,431 |  |  | $ | 23,357 |  |
| Services and technology development |  |  | 3,327 |  |  |  | 329 |  |  |  | 8,147 |  |  |  | 1,228 |  |
| Total |  | $ | 52,306 |  |  | $ | 9,097 |  |  | $ | 131,578 |  |  | $ | 24,585 |  |
| Region: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas |  | $ | 47,737 |  |  | $ | - |  |  | $ | 121,696 |  |  | $ | 1 |  |
| Asia Pacific |  |  | 2,293 |  |  |  | 9,080 |  |  |  | 4,280 |  |  |  | 24,562 |  |
| EMEA |  |  | 2,276 |  |  |  | 17 |  |  |  | 5,602 |  |  |  | 22 |  |
| Total |  | $ | 52,306 |  |  | $ | 9,097 |  |  | $ | 131,578 |  |  | $ | 24,585 |  |
  (was, 2025-11-05, similarity 0.9815):
[0001437749-25-033351:note_history:12]
|  |  | Three Months Ended September 30, 2024 |  |  | Six Months Ended September 30, 2024 |  |
| Product Line: |  | Grid |  |  | Wind |  |  | Grid |  |  | Wind |  |
| Equipment and systems |  | $ | 43,747 |  |  | $ | 7,166 |  |  | $ | 74,452 |  |  | $ | 14,591 |  |
| Services and technology development |  |  | 3,189 |  |  |  | 369 |  |  |  | 4,820 |  |  |  | 898 |  |
| Total |  | $ | 46,936 |  |  | $ | 7,535 |  |  | $ | 79,272 |  |  | $ | 15,489 |  |
| Region: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas |  | $ | 43,479 |  |  | $ | 1 |  |  | $ | 73,957 |  |  | $ | 1 |  |
| Asia Pacific |  |  | 790 |  |  |  | 7,531 |  |  |  | 1,989 |  |  |  | 15,483 |  |
| EMEA |  |  | 2,667 |  |  |  | 3 |  |  |  | 3,326 |  |  |  | 5 |  |
| Total |  | $ | 46,936 |  |  | $ | 7,535 |  |  | $ | 79,272 |  |  | $ | 15,489 |  |

- changed (2026-02-04):
[0001437749-26-002978:note_history:13]
As of  December 31, 2025 and 2024, the Company’s contract assets and liabilities primarily relate to the timing differences between cash received from a customer in connection with contractual rights to invoicing and the timing of revenue recognition following completion of performance obligations. The Company's accounts receivable balance is made up entirely of customer contract related balances. Changes in the Company’s contract assets, which are included in “Unbilled accounts receivable” and “Deferred program costs” (see Note 8, “Accounts Receivable” and Note 9, “Inventory” for a reconciliation to the condensed consolidated balance sheets) and "Contract liabilities", which are included in the current portion and long-term portion of "Deferred revenue" in the Company’s condensed consolidated balance sheets, are as follows (in thousands):
  (was, 2025-11-05, similarity 0.9958):
[0001437749-25-033351:note_history:13]
As of  September 30, 2025 and 2024, the Company’s contract assets and liabilities primarily relate to the timing differences between cash received from a customer in connection with contractual rights to invoicing and the timing of revenue recognition following completion of performance obligations. The Company's accounts receivable balance is made up entirely of customer contract related balances. Changes in the Company’s contract assets, which are included in “Unbilled accounts receivable” and “Deferred program costs” (see Note 8, “Accounts Receivable” and Note 9, “Inventory” for a reconciliation to the condensed consolidated balance sheets) and "Contract liabilities", which are included in the current portion and long-term portion of "Deferred revenue" in the Company’s condensed consolidated balance sheets, are as follows (in thousands):

- changed (2026-02-04):
[0001437749-26-002978:note_history:14]
|  |  | Unbilled Accounts Receivable |  |  | Deferred Program Costs |  |  | Contract Liabilities |  |
| Beginning balance as of March 31, 2025 |  | $ | 6,376 |  |  | $ | 5,757 |  |  | $ | 76,133 |  |
| Increase for balance acquired |  |  | — |  |  |  | — |  |  |  | 19,783 |  |
| Increases for costs incurred to fulfill performance obligations |  |  | — |  |  |  | 23,174 |  |  |  | — |  |
| Increase (decrease) due to customer billings |  |  | (15,991 | ) |  |  | — |  |  |  | 81,667 |  |
| Decrease due to cost recognition on completed performance obligations |  |  | — |  |  |  | (21,767 | ) |  |  | — |  |
| Increase (decrease) due to recognition of revenue based on transfer of control of performance obligations |  |  | 22,399 |  |  |  | — |  |  |  | (88,591 | ) |
| Other changes and FX impact |  |  | 12 |  |  |  | (1 | ) |  |  | 371 |  |
| Ending balance as of December 31, 2025 |  | $ | 12,796 |  |  | $ | 7,163 |  |  | $ | 89,363 |  |
  (was, 2025-11-05, similarity 0.9444):
[0001437749-25-033351:note_history:14]
|  |  | Unbilled Accounts Receivable |  |  | Deferred Program Costs |  |  | Contract Liabilities |  |
| Beginning balance as of March 31, 2024 |  | $ | 6,150 |  |  | $ | 2,523 |  |  | $ | 57,829 |  |
| Increase for balances acquired |  |  | — |  |  |  | — |  |  |  | 5,049 |  |
| Increases for costs incurred to fulfill performance obligations |  |  | — |  |  |  | 4,866 |  |  |  | — |  |
| Increase (decrease) due to customer billings |  |  | (6,241 | ) |  |  | — |  |  |  | 70,133 |  |
| Decrease due to cost recognition on completed performance obligations |  |  | — |  |  |  | (2,553 | ) |  |  | — |  |
| Increase (decrease) due to recognition of revenue based on transfer of control of performance obligations |  |  | 4,607 |  |  |  | — |  |  |  | (52,084 | ) |
| Other changes and FX impact |  |  | 7 |  |  |  | 12 |  |  |  | 344 |  |
| Ending balance as of September 30, 2024 |  | $ | 4,523 |  |  | $ | 4,848 |  |  | $ | 81,271 |  |

- added (2026-02-04):
[0001437749-26-002978:note_history:15]
|  |  | Unbilled Accounts Receivable |  |  | Deferred Program Costs |  |  | Contract Liabilities |  |
| Beginning balance as of March 31, 2024 |  | $ | 6,150 |  |  | $ | 2,523 |  |  | $ | 57,829 |  |
| Increase for balances acquired |  |  | — |  |  |  | — |  |  |  | 5,049 |  |
| Increases for costs incurred to fulfill performance obligations |  |  | — |  |  |  | 10,876 |  |  |  | — |  |
| Increase (decrease) due to customer billings |  |  | (7,139 | ) |  |  | — |  |  |  | 96,400 |  |
| Decrease due to cost recognition on completed performance obligations |  |  | — |  |  |  | (6,133 | ) |  |  | — |  |
| Increase (decrease) due to recognition of revenue based on transfer of control of performance obligations |  |  | 6,120 |  |  |  | — |  |  |  | (75,410 | ) |
| Other changes and FX impact |  |  | (18 | ) |  |  | (11 | ) |  |  | (540 | ) |
| Ending balance as of December 31, 2024 |  | $ | 5,113 |  |  | $ | 7,255 |  |  | $ | 83,328 |  |

- changed (2026-02-04):
[0001437749-26-002978:note_history:16]
The Company’s remaining performance obligations represent the unrecognized revenue value of the Company’s contractual commitments. The Company’s performance obligations  may vary significantly each reporting period based on the timing of major new contractual commitments. As of  December 31, 2025, the Company had outstanding performance obligations on existing contracts under ASC 606 to be recognized in the next twelve months of approximately $253.5 million. There are also approximately $99.7 million of outstanding performance obligations to be recognized over a period of thirteen to sixty months. The remaining performance obligations are subject to customer actions and therefore the timing of revenue recognition cannot be reasonably estimated.
  (was, 2025-11-05, similarity 0.9953):
[0001437749-25-033351:note_history:16]
The Company’s remaining performance obligations represent the unrecognized revenue value of the Company’s contractual commitments. The Company’s performance obligations  may vary significantly each reporting period based on the timing of major new contractual commitments. As of  September 30, 2025, the Company had outstanding performance obligations on existing contracts under ASC 606 to be recognized in the next twelve months of approximately $209.5 million. There are also approximately $78.2 million of outstanding performance obligations to be recognized over a period of thirteen to sixty months. The remaining performance obligations are subject to customer actions and therefore the timing of revenue recognition cannot be reasonably estimated.

- changed (2026-02-04):
[0001437749-26-002978:note_history:17]
The following table sets forth customers who represented 10% or more of the Company’s total revenues for the three and nine months ended  December 31, 2025, and 2024:
  (was, 2025-11-05, similarity 0.9677):
[0001437749-25-033351:note_history:17]
The following table sets forth customers who represented 10% or more of the Company’s total revenues for the three and six months ended  September 30, 2025, and 2024:

- added (2026-02-04):
[0001437749-26-002978:note_history:18]
|  |  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  | Reportable |  | December 31, |  |  | December 31, |  |
|  | Segment |  | 2025 |  |  | 2024 |  |  | 2025 |  |  | 2024 |  |
| Inox Wind Limited | Wind |  |  | 14 | % |  |  | 10 | % |  |  | 15 | % |  |  | 13 | % |
| Innomotics LLC | Grid |  |  | <10% |  |  |  | 14 | % |  |  | <10% |  |  |  | <10% |  |
| Fuji Bridex Pte Ltd | Grid |  |  | <10% |  |  |  | <10% |  |  |  | 11 | % |  |  | <10% |  |

- removed (2026-02-04):
[0001437749-25-033351:note_history:19]
|  |  | Unbilled Accounts Receivable |  |  | Deferred Program Costs |  |  | Contract Liabilities |  |
| Beginning balance as of March 31, 2025 |  | $ | 6,376 |  |  | $ | 5,756 |  |  | $ | 76,133 |  |
| Increases for costs incurred to fulfill performance obligations |  |  | — |  |  |  | 15,934 |  |  |  | — |  |
| Increase (decrease) due to customer billings |  |  | (10,269 | ) |  |  | — |  |  |  | 47,765 |  |
| Decrease due to cost recognition on completed performance obligations |  |  | — |  |  |  | (16,718 | ) |  |  | — |  |
| Increase (decrease) due to recognition of revenue based on transfer of control of performance obligations |  |  | 12,207 |  |  |  | — |  |  |  | (61,496 | ) |
| Other changes and FX impact |  |  | 13 |  |  |  | 46 |  |  |  | 988 |  |
| Ending balance as of September 30, 2025 |  | $ | 8,327 |  |  | $ | 5,018 |  |  | $ | 63,390 |  |

- removed (2026-02-04):
[0001437749-25-033351:note_history:20]
|  |  |  | Three Months Ended |  |  | Six Months Ended |  |
|  | Reportable |  | September 30, |  |  | September 30, |  |
|  | Segment |  | 2025 |  |  | 2024 |  |  | 2025 |  |  | 2024 |  |
| Inox Wind Limited | Wind |  |  | 16 | % |  |  | 12 | % |  |  | 16 | % |  |  | 14 | % |
| Anovion LLC | Grid |  |  | 12 | % |  | <10 | % |  | <10 | % |  | <10 | % |
| Fuji Bridex Pte Ltd | Grid |  | <10 | % |  | <10 | % |  |  | 13 | % |  | <10 | % |
