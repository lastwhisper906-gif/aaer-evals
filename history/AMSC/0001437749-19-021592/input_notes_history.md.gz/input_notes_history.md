# AMSC note change history — 0001437749-19-015632 → 0001437749-19-021592


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- added (2019-11-05):
[0001437749-19-021592:note_history:1]
September 30, 2019

- removed (2019-11-05):
[0001437749-19-015632:note_history:2]
June 30, 2019


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2019-11-05):
[0001437749-19-021592:note_history:3]
American Superconductor Corporation (together with its subsidiaries, “AMSC®” or the “Company”) was founded on 
 April
  (was, 2019-08-06, similarity 0.9956):
[0001437749-19-015632:note_history:3]
American Superconductor Corporation (together with its subsidiaries, “AMSC®”or the “Company”) was founded on 
 April

- added (2019-11-05):
[0001437749-19-021592:note_history:4]
September 30, 2019

- added (2019-11-05):
[0001437749-19-021592:note_history:5]
September 30, 2019

- added (2019-11-05):
[0001437749-19-021592:note_history:6]
September 30, 2019

- added (2019-11-05):
[0001437749-19-021592:note_history:7]
September 30, 2019

- changed (2019-11-05):
[0001437749-19-021592:note_history:8]
, the Company had cash, cash equivalents, and marketable securities of $
  (was, 2019-08-06, similarity 0.7333):
[0001437749-19-015632:note_history:8]
, the Company had cash and cash equivalents of $

- changed (2019-11-05):
[0001437749-19-021592:note_history:9]
million, with 
no
 outstanding debt other than ordinary trade payables. Marketable securities include certificate of deposits with maturities between 
twelve
 and 
twenty-four
 months.  Cash used in operations for the
  (was, 2019-08-06, similarity 0.6495):
[0001437749-19-015632:note_history:9]
million, with 
no
 outstanding debt other than ordinary trade payables. Cash used in operations for the

- added (2019-11-05):
[0001437749-19-021592:note_history:10]
six

- added (2019-11-05):
[0001437749-19-021592:note_history:11]
September 30, 2019

- changed (2019-11-05):
[0001437749-19-021592:note_history:12]
In 
 December 2015, 
the Company entered into a set of strategic agreements valued at approximately 
$210.0
 million with Inox Wind Ltd. (“Inox” or “Inox Wind”), which includes a multi-year supply contract pursuant to which the Company will supply electrical control systems ("ECS") to Inox and a license agreement allowing Inox to manufacture a limited number of ECS. After Inox purchases the specified number of ECS required under the terms of the supply contract, Inox agreed that the Company will continue as Inox’s preferred supplier and Inox will be required to purchase from the Company a majority of its ECS requirements for an additional 
three
-year period. Pursuant to these strategic agreements, Inox must forecast future purchase orders of sets of ECS which become firm orders 
three
 months prior to shipment, and Inox must post letters of credit before the Company will ship such orders. Inox is currently delinquent on its obligation to post letters of credit for sets of ECS that Inox forecasted to purchase under the terms of the supply contract.  We cannot predict if and when Inox will post letters of credit consistent with the forecasted ECS quantities. Inox’s failure to post letters of credit and take delivery of forecasted ECS quantities would impact the Company’s revenues and liquidity.
  (was, 2019-08-06, similarity 0.6385):
[0001437749-19-015632:note_history:12]
In 
 December 2015, 
the Company entered into a set of strategic agreements valued at approximately 
$210.0
 million with Inox Wind Ltd. (“Inox” or “Inox Wind”), which includes a multi-year supply contract pursuant to which the Company will supply electrical control systems to Inox and a license agreement allowing Inox to manufacture a limited number of electrical control systems. After Inox purchases the specified number of electrical control systems required under the terms of the supply contract, Inox agreed that the Company will continue as Inox’s preferred supplier and Inox will be required to purchase from the Company a majority of its electrical control systems requirements for an additional 
three
-year period.

- added (2019-11-05):
[0001437749-19-021592:note_history:13]
six

- added (2019-11-05):
[0001437749-19-021592:note_history:14]
September 30, 2019

- removed (2019-11-05):
[0001437749-19-015632:note_history:15]
June 30, 2019

- removed (2019-11-05):
[0001437749-19-015632:note_history:16]
June 30, 2019

- removed (2019-11-05):
[0001437749-19-015632:note_history:17]
June 30, 2019

- removed (2019-11-05):
[0001437749-19-015632:note_history:18]
June 30, 2019

- removed (2019-11-05):
[0001437749-19-015632:note_history:19]
three

- removed (2019-11-05):
[0001437749-19-015632:note_history:20]
June 30, 2019

- removed (2019-11-05):
[0001437749-19-015632:note_history:21]
three

- removed (2019-11-05):
[0001437749-19-015632:note_history:22]
June 30, 2019


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- added (2019-11-05):
[0001437749-19-021592:note_history:23]
|  |  | Three Months Ended September 30, 2019 |  |  | Six Months Ended September 30, 2019 |  |
| Product Line: |  | Grid |  |  | Wind |  |  | Grid |  |  | Wind |  |
| Equipment and systems |  | $ | 10,044 |  |  | $ | 2,077 |  |  | $ | 18,399 |  |  | $ | 5,581 |  |
| Services and technology development |  |  | 1,445 |  |  |  | 446 |  |  |  | 2,946 |  |  |  | 856 |  |
| Total |  | $ | 11,489 |  |  | $ | 2,523 |  |  | $ | 21,345 |  |  | $ | 6,437 |  |
| Region: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas |  | $ | 10,698 |  |  | $ | 1 |  |  | $ | 18,499 |  |  | $ | 47 |  |
| Asia Pacific |  |  | 393 |  |  |  | 2,464 |  |  |  | 2,220 |  |  |  | 6,320 |  |
| EMEA |  |  | 398 |  |  |  | 58 |  |  |  | 626 |  |  |  | 70 |  |
| Total |  | $ | 11,489 |  |  | $ | 2,523 |  |  | $ | 21,345 |  |  | $ | 6,437 |  |

- added (2019-11-05):
[0001437749-19-021592:note_history:24]
|  |  | Three Months Ended September 30, 2018 |  |  | Six Months Ended September 30, 2018 |  |
| Product Line: |  | Grid |  |  | Wind |  |  | Grid |  |  | Wind |  |
| Equipment and systems |  | $ | 5,503 |  |  | $ | 7,219 |  |  | $ | 12,957 |  |  | $ | 10,711 |  |
| Services and technology development |  |  | 2,066 |  |  |  | 88 |  |  |  | 3,541 |  |  |  | 274 |  |
| Total |  | $ | 7,569 |  |  | $ | 7,307 |  |  | $ | 16,498 |  |  | $ | 10,985 |  |
| Region: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas |  | $ | 5,052 |  |  | $ | 24 |  |  | $ | 12,548 |  |  | $ | 47 |  |
| Asia Pacific |  |  | 2,308 |  |  |  | 7,278 |  |  |  | 3,115 |  |  |  | 10,873 |  |
| EMEA |  |  | 209 |  |  |  | 5 |  |  |  | 835 |  |  |  | 65 |  |
| Total |  | $ | 7,569 |  |  | $ | 7,307 |  |  | $ | 16,498 |  |  | $ | 10,985 |  |

- removed (2019-11-05):
[0001437749-19-015632:note_history:25]
|  |  | Three Months Ended June 30, 2019 |  |
| Product Line: |  | Grid |  |  | Wind |  |
| Equipment and systems |  | $ | 8,354 |  |  | $ | 3,505 |  |
| Services and technology development |  |  | 1,501 |  |  |  | 410 |  |
| Total |  | $ | 9,855 |  |  | $ | 3,915 |  |
| Region: |  |  |  |  |  |  |  |  |
| Americas |  | $ | 7,801 |  |  | $ | 46 |  |
| Asia Pacific |  |  | 1,827 |  |  |  | 3,856 |  |
| EMEA |  |  | 227 |  |  |  | 13 |  |
| Total |  | $ | 9,855 |  |  | $ | 3,915 |  |
|  |  | Three Months Ended June 30, 2018 |  |
| Product Line: |  | Grid |  |  | Wind |  |
| Equipment and systems |  | $ | 7,462 |  |  | $ | 3,492 |  |
| Services and technology development |  |  | 1,467 |  |  |  | 186 |  |
| Total |  | $ | 8,929 |  |  | $ | 3,678 |  |
| Region: |  |  |  |  |  |  |  |  |
| Americas |  | $ | 7,496 |  |  | $ | 23 |  |
| Asia Pacific |  |  | 808 |  |  |  | 3,595 |  |
| EMEA |  |  | 625 |  |  |  | 60 |  |
| Total |  | $ | 8,929 |  |  | $ | 3,678 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2019-11-05):
[0001437749-19-021592:note_history:26]
The Company’s revenues in its Grid segment are derived primarily through enabling the transmission and distribution of power, providing planning services that allow it to identify power grid needs and risks, and developing ship protection systems for the U.S. Navy. The Company’s revenues in its Wind segment are derived primarily through supplying advanced power electronics and control systems, licensing its highly engineered wind turbine designs, and providing extensive customer support services to wind turbine manufacturers. The Company records revenue based on a 
five
-step model in accordance with ASC 
606.
 For its customer contracts, the Company identifies the performance obligations, determines the transaction price, allocates the contract transaction price to the performance obligations, and recognizes the revenue when (or as) control of goods or services is transferred to the customer. In both the
  (was, 2019-08-06, similarity 0.9912):
[0001437749-19-015632:note_history:26]
The Company’s revenues in its Grid segment are derived primarily through enabling the transmission and distribution of power, providing planning services that allow it to identify power grid needs and risks, and developing ship protection systems for the U.S. Navy. The Company’s revenues in its Wind segment are derived primarily through supplying advanced power electronics and control systems, licensing its highly engineered wind turbine designs, and providing extensive customer support services to wind turbine manufacturers. The Company records revenue based on a 
five
-step model in accordance with ASC 
606.
 For its customer contracts, the Company identifies the performance obligations, determines the transaction price, allocates the contract transaction price to the performance obligations, and recognizes the revenue when (or as) control of goods or services is transferred to the customer. As of

- added (2019-11-05):
[0001437749-19-021592:note_history:27]
three
 and 
six

- added (2019-11-05):
[0001437749-19-021592:note_history:28]
September 30, 2019

- changed (2019-11-05):
[0001437749-19-021592:note_history:29]
In the Company's equipment and system product line, each contract with a customer summarizes each product sold to a customer, which typically represent distinct performance obligations. A contract's transaction price is allocated to each distinct performance obligation using the respective standalone selling price which is determined primarily using the cost-plus expected margin approach and recognized as revenue when, or as, the performance obligation is satisfied. The majority of the Company’s product sales transfer control to the customer in line with the contracted delivery terms and revenue is recorded at the point in time when title and risk transfer to the customer, as the Company has determined that this is the point in time that control transfers to the customer.
  (was, 2019-08-06, similarity 0.9987):
[0001437749-19-015632:note_history:29]
In the Company's equipment and system product line, each contract with a customer summarizes each product sold to a customer, which typically represent distinct performance obligations. A contract's transaction price is allocated to each distinct performance obligation using the respective standalone selling price which is determined primarily using the cost plus expected margin approach and recognized as revenue when, or as, the performance obligation is satisfied. The majority of the Company’s product sales transfer control to the customer in line with the contracted delivery terms and revenue is recorded at the point in time when title and risk transfer to the customer, as the Company has determined that this is the point in time that control transfers to the customer.

- changed (2019-11-05):
[0001437749-19-021592:note_history:30]
The Company's equipment and system product line includes certain contracts which do 
not
 meet the requirements of an exchange transaction and therefore do 
not
 fall within the scope of ASC 
606.
  As these non-exchange transaction contracts are considered grant revenue and do 
not
 fall within any specific accounting literature, the Company follows guidance within ASC 
606
 by analogy to recognize grant revenue over time.  In the
  (was, 2019-08-06, similarity 0.8192):
[0001437749-19-015632:note_history:30]
The Company's equipment and system product line includes contracts which do 
not
 meet the requirements of an exchange transaction and therefore do 
not
 fall within the scope of ASC 
606.
  As these non-exchange transaction contracts are considered grant revenue and do 
not
 fall within any specific accounting literature, the Company follows guidance within ASC 
606
 by analogy to recognize grant revenue over time.  In the 
three
 months ended 
 June 30, 2019 
the Company recorded 
$0.4
 million in grant revenue, which is included in the Company’s Grid Revenue. There was 
no
 grant revenue in the prior year.

- added (2019-11-05):
[0001437749-19-021592:note_history:31]
three
 and 
six
 months ended 
 September 30, 2019

- added (2019-11-05):
[0001437749-19-021592:note_history:32]
, the Company recorded 
$0.7
 million and 
$1.1
 million in grant revenue, respectively, which is included in the Company’s Grid revenue. There was 
no
 grant revenue in the

- added (2019-11-05):
[0001437749-19-021592:note_history:33]
three
 and 
six

- added (2019-11-05):
[0001437749-19-021592:note_history:34]
months ended

- added (2019-11-05):
[0001437749-19-021592:note_history:35]
September 30, 2018

- added (2019-11-05):
[0001437749-19-021592:note_history:36]
.

- changed (2019-11-05):
[0001437749-19-021592:note_history:37]
In the Company's service and technology development product line, there are several different types of transactions and each begins with a contract with a customer that summarizes each product sold to a customer, which typically represents distinct performance obligations. The technology development transactions are primarily for activities that have 
no
 alternative use and for which a profit can be expected throughout the life of the contract. In these cases, the revenue is recognized over time, but in the instances where the profit cannot be assured throughout the entire contract then the revenue is recognized at a point in time. Each contract's transaction price is allocated to each distinct performance obligation using the respective standalone selling price which is determined primarily using the cost-plus expected margin approach. The ongoing service transactions are for service contracts that provide benefit to the customer simultaneously as the Company performs its obligations, and therefore this revenue is recognized ratably over time throughout the effective period of these contracts. The transaction prices on these contracts are allocated based on an adjusted market approach which is re-assessed annually for reasonableness. The field service transactions include contracts for delivery of goods and completion of services made at the customer's requests, which are 
not
 deemed satisfied until the work has been completed and/or the requested goods have been delivered, so all of this revenue is recognized at the point in time when the control changes, and at allocated prices based on the adjusted market approach driven by standard price lists. The royalty transactions are related to certain contract terms on transactions in the Company's equipment and systems product line based on activity as specified in the contracts. The transaction prices of these agreements are calculated based on an adjusted market approach as specified in the contract. The Company reports royalty revenue for usage-based royalties when the sales have occurred. In circumstances when collectability is 
not
 assured and a contract does 
not
 exist under ASC 
606,
 revenue is deferred until a non-refundable payment has been received for substantially all the amount that is due and there are 
no
 further remaining performance obligations.
  (was, 2019-08-06, similarity 0.9996):
[0001437749-19-015632:note_history:37]
In the Company's service and technology development product line, there are several different types of transactions and each begins with a contract with a customer that summarizes each product sold to a customer, which typically represents distinct performance obligations. The technology development transactions are primarily for activities that have 
no
 alternative use and for which a profit can be expected throughout the life of the contract. In these cases, the revenue is recognized over time, but in the instances where the profit cannot be assured throughout the entire contract then the revenue is recognized at a point in time. Each contract's transaction price is allocated to each distinct performance obligation using the respective standalone selling price which is determined primarily using the cost plus expected margin approach. The ongoing service transactions are for service contracts that provide benefit to the customer simultaneously as the Company performs its obligations, and therefore this revenue is recognized ratably over time throughout the effective period of these contracts. The transaction prices on these contracts are allocated based on an adjusted market approach which is re-assessed annually for reasonableness. The field service transactions include contracts for delivery of goods and completion of services made at the customer's requests, which are 
not
 deemed satisfied until the work has been completed and/or the requested goods have been delivered, so all of this revenue is recognized at the point in time when the control changes, and at allocated prices based on the adjusted market approach driven by standard price lists. The royalty transactions are related to certain contract terms on transactions in the Company's equipment and systems product line based on activity as specified in the contracts. The transaction prices of these agreements are calculated based on an adjusted market approach as specified in the contract. The Company reports royalty revenue for usage-based royalties when the sales have occurred. In circumstances when collectability is 
not
 assured and a contract does 
not
 exist under ASC 
606,
 revenue is deferred until a non-refundable payment has been received for substantially all the amount that is due and there are 
no
 further remaining performance obligations.

- added (2019-11-05):
[0001437749-19-021592:note_history:38]
The Company's service contracts can include a purchase order from a customer for specific goods in which each item is a distinct performance obligation satisfied at a point in time at which control of the goods is transferred to the customer.  This transfer occurs based on the contracted delivery terms or when the requested service work has been completed. The transaction price for these goods is allocated based on the adjusted market approach considering similar transactions under similar circumstances. Service contracts are also derived from ongoing maintenance contracts and extended service-type warranty contracts. In these transactions, the Company is contracted to provide an ongoing service over a specified period of time. As the customer is consuming the benefits as the service is being provided, the revenue is recognized over time ratably.

- changed (2019-11-05):
[0001437749-19-021592:note_history:39]
The Company provides assurance-type warranties on all product sales for a term of typically 
one
 to 
two
 years, and extended service-type warranties at the customer's option for an additional term ranging up to 
four
 additional years. The Company accrues for the estimated warranty costs for assurance warranties at the time of sale based on historical warranty experience plus any known or expected changes in warranty exposure. For all extended service-type warranties, the Company recognizes the revenue ratably over time during the effective period of the services.
  (was, 2019-08-06, similarity 0.9965):
[0001437749-19-015632:note_history:39]
The Company provides assurance-type warranties on all product sales for a term of typically 
one
 to 
two
 years, and extended service-type warranties at the customers’ option for an additional term ranging up to 
four
 additional years. The Company accrues for the estimated warranty costs for assurance warranties at the time of sale based on historical warranty experience plus any known or expected changes in warranty exposure. For all extended service-type warranties, the Company recognizes the revenue ratably over time during the effective period of the services.

- changed (2019-11-05):
[0001437749-19-021592:note_history:40]
The Company records revenue net of sales tax, value added tax, excise tax and other taxes collected concurrent with revenue-producing activities. The Company has elected to recognize the cost for freight and shipping when control over the products sold passes to customers and revenue is recognized. The Company has elected to recognize incremental costs of obtaining a contract as expense when incurred except in contracts where the amortization period would exceed 
twelve
 months; in such cases the long-term amount will be assessed for materiality. The Company has elected to 
not
 adjust the promised amount of consideration for the effects of a significant financing component if the period of financing is 
twelve
 months or less.
  (was, 2019-08-06, similarity 0.9986):
[0001437749-19-015632:note_history:40]
The Company records revenue net of sales tax, value added tax, excise tax and other taxes collected concurrent with revenue-producing activities. The Company has elected to recognize the cost for freight and shipping when control over the products sold passes to customers and revenue is recognized. The Company has elected to recognize incremental costs of obtaining a contract as expense when incurred except in contracts where the amortization period would exceed 
twelve
 months; in such cases the long term amount will be assessed for materiality. The Company has elected to 
not
 adjust the promised amount of consideration for the effects of a significant financing component if the period of financing is 
twelve
 months or less.

- added (2019-11-05):
[0001437749-19-021592:note_history:41]
|  |  | Three Months Ended September 30, 2019 |  |  | Six Months Ended September 30, 2019 |  |
| Product Line: |  | Grid |  |  | Wind |  |  | Grid |  |  | Wind |  |
| Equipment and systems |  | $ | 10,044 |  |  | $ | 2,077 |  |  | $ | 18,399 |  |  | $ | 5,581 |  |
| Services and technology development |  |  | 1,445 |  |  |  | 446 |  |  |  | 2,946 |  |  |  | 856 |  |
| Total |  | $ | 11,489 |  |  | $ | 2,523 |  |  | $ | 21,345 |  |  | $ | 6,437 |  |
| Region: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas |  | $ | 10,698 |  |  | $ | 1 |  |  | $ | 18,499 |  |  | $ | 47 |  |
| Asia Pacific |  |  | 393 |  |  |  | 2,464 |  |  |  | 2,220 |  |  |  | 6,320 |  |
| EMEA |  |  | 398 |  |  |  | 58 |  |  |  | 626 |  |  |  | 70 |  |
| Total |  | $ | 11,489 |  |  | $ | 2,523 |  |  | $ | 21,345 |  |  | $ | 6,437 |  |

- added (2019-11-05):
[0001437749-19-021592:note_history:42]
|  |  | Three Months Ended September 30, 2018 |  |  | Six Months Ended September 30, 2018 |  |
| Product Line: |  | Grid |  |  | Wind |  |  | Grid |  |  | Wind |  |
| Equipment and systems |  | $ | 5,503 |  |  | $ | 7,219 |  |  | $ | 12,957 |  |  | $ | 10,711 |  |
| Services and technology development |  |  | 2,066 |  |  |  | 88 |  |  |  | 3,541 |  |  |  | 274 |  |
| Total |  | $ | 7,569 |  |  | $ | 7,307 |  |  | $ | 16,498 |  |  | $ | 10,985 |  |
| Region: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas |  | $ | 5,052 |  |  | $ | 24 |  |  | $ | 12,548 |  |  | $ | 47 |  |
| Asia Pacific |  |  | 2,308 |  |  |  | 7,278 |  |  |  | 3,115 |  |  |  | 10,873 |  |
| EMEA |  |  | 209 |  |  |  | 5 |  |  |  | 835 |  |  |  | 65 |  |
| Total |  | $ | 7,569 |  |  | $ | 7,307 |  |  | $ | 16,498 |  |  | $ | 10,985 |  |

- added (2019-11-05):
[0001437749-19-021592:note_history:43]
September 30, 2019

- changed (2019-11-05):
[0001437749-19-021592:note_history:44]
, and
  (was, 2019-08-06, similarity 0.75):
[0001437749-19-015632:note_history:44]
and

- added (2019-11-05):
[0001437749-19-021592:note_history:45]
September 30, 2018

- changed (2019-11-05):
[0001437749-19-021592:note_history:46]
, the Company’s contract assets and liabilities primarily relate to the timing differences between cash received from a customer in connection with contractual rights to invoicing and the timing of revenue recognition following completion of performance obligations. The Company's accounts receivable balance is made up entirely of customer contract related balances. Changes in the Company’s contract assets, which are included in “Unbilled Accounts Receivable” and “Deferred program costs” (see Note 
7,
 “Accounts Receivable” and Note 
8,
 “Inventory” for a reconciliation to the condensed consolidated balance sheets) and contract liabilities, which are included in the current portion and long term portion of deferred revenue in the Company’s condensed consolidated balance sheets, are as follows:
  (was, 2019-08-06, similarity 0.9975):
[0001437749-19-015632:note_history:46]
the Company’s contract assets and liabilities primarily relate to the timing differences between cash received from a customer in connection with contractual rights to invoicing and the timing of revenue recognition following completion of performance obligations. The Company's accounts receivable balance is made up entirely of customer contract related balances. Changes in the Company’s contract assets, which are included in “Unbilled Accounts Receivable” and “Deferred program costs” (see Note 
7,
 “Accounts Receivable” and Note 
8,
 “Inventory” for a reconciliation to the condensed consolidated balance sheets) and contract liabilities, which are included in the current portion and long term portion of “deferred revenue” in the Company’s condensed consolidated balance sheets, are as follows:

- added (2019-11-05):
[0001437749-19-021592:note_history:47]
|  |  | Unbilled Accounts Receivable |  |  | Deferred Program Costs |  |  | Contract Liabilities |  |
| Beginning balance as of March 31, 2019 |  | $ | 2,213 |  |  | $ | 318 |  |  | $ | 15,519 |  |
| Increases for costs incurred to fulfill performance obligations |  |  | — |  |  |  | 2,153 |  |  |  | — |  |
| Increase (decrease) due to customer billings |  |  | (2,926 | ) |  |  | — |  |  |  | 19,340 |  |
| Decrease due to cost recognition on completed performance obligations |  |  | — |  |  |  | (310 | ) |  |  | — |  |
| Increase (decrease) due to recognition of revenue based on transfer of control of performance obligations |  |  | 4,711 |  |  |  | — |  |  |  | (18,534 | ) |
| Other changes and FX impact |  |  | (4 | ) |  |  | (9 | ) |  |  | (313 | ) |
| Ending balance as of September 30, 2019 |  | $ | 3,994 |  |  | $ | 2,152 |  |  | $ | 16,012 |  |

- changed (2019-11-05):
[0001437749-19-021592:note_history:48]
|  |  | Unbilled Accounts Receivable |  |  | Deferred Program Costs |  |  | Contract Liabilities |  |
| Beginning balance as of March 31, 2018 |  | $ | 3,016 |  |  | $ | 2,567 |  |  | $ | 21,937 |  |
| Impact of adoption of ASC 606 |  |  | — |  |  |  | (1,599 | ) |  |  | (2,657 | ) |
| Increases for costs incurred to fulfill performance obligations |  |  | — |  |  |  | 1,267 |  |  |  | — |  |
| Increase (decrease) due to customer billings |  |  | (7,886 | ) |  |  | — |  |  |  | 7,828 |  |
| Decrease due to cost recognition on completed performance obligations |  |  | — |  |  |  | (1,033 | ) |  |  | — |  |
| Increase (decrease) due to recognition of revenue based on transfer of control of performance obligations |  |  | 7,439 |  |  |  | (9 | ) |  |  | (8,296 | ) |
| Other changes and FX impact |  |  | (19 | ) |  |  | 24 |  |  |  | (864 | ) |
| Ending balance as of September 30, 2018 |  | $ | 2,550 |  |  | $ | 1,217 |  |  | $ | 17,948 |  |
  (was, 2019-08-06, similarity 0.6834):
[0001437749-19-015632:note_history:48]
|  |  | Unbilled Accounts Receivable |  |  | Deferred Program Costs |  |  | Contract Liabilities |  |
| Beginning balance as of March 31, 2018 |  | $ | 3,016 |  |  | $ | 2,567 |  |  | $ | 21,937 |  |
| Impact of adoption of ASC 606 |  |  | — |  |  |  | (1,599 | ) |  |  | (2,657 | ) |
| Increases for costs incurred to fulfill performance obligations |  |  | — |  |  |  | 1,132 |  |  |  | — |  |
| Increase (decrease) due to customer billings |  |  | (3,221 | ) |  |  | — |  |  |  | 4,281 |  |
| Decrease due to cost recognition on completed performance obligations |  |  | — |  |  |  | (48 | ) |  |  | — |  |
| Increase (decrease) due to recognition of revenue based on transfer of control of performance obligations |  |  | 4,824 |  |  |  | (9 | ) |  |  | (3,324 | ) |
| Other changes and FX impact |  |  | (16 | ) |  |  | 34 |  |  |  | (764 | ) |
| Ending balance as of June 30, 2018 |  | $ | 4,603 |  |  | $ | 2,077 |  |  | $ | 19,473 |  |
|  |  | Unbilled Accounts Receivable |  |  | Deferred Program Costs |  |  | Contract Liabilities |  |
| Beginning balance as of March 31, 2019 |  | $ | 2,213 |  |  | $ | 318 |  |  | $ | 15,521 |  |
| Increases for costs incurred to fulfill performance obligations |  |  | 0 |  |  |  | 771 |  |  |  | 0 |  |
| Increase (decrease) due to customer billings |  |  | (1,584 | ) |  |  | 0 |  |  |  | 10,857 |  |
| Decrease due to cost recognition on completed performance obligations |  |  | 0 |  |  |  | (4 | ) |  |  | 0 |  |
| Increase (decrease) due to recognition of revenue based on transfer of control of performance obligations |  |  | 1,467 |  |  |  | 0 |  |  |  | (7,761 | ) |
| Other changes and FX impact |  |  | (3 | ) |  |  | 3 |  |  |  | 73 |  |
| Ending balance as of June 30, 2019 |  | $ | 2,093 |  |  | $ | 1,088 |  |  | $ | 18,690 |  |

- added (2019-11-05):
[0001437749-19-021592:note_history:49]
September 30, 2019

- added (2019-11-05):
[0001437749-19-021592:note_history:50]
million of outstanding performance obligations to be recognized over a period of 
thirteen
 to 
sixty
 months. The remaining performance obligations are subject to customer actions and therefore the timing of revenue recognition cannot be reasonably estimated. The 
twelve
-month performance obligations include anticipated shipments to Inox based on the 
twelve
-month rolling forecast provided by Inox on the multi-year supply contract. The quantities specified in any forecast provided by Inox related to the multi-year supply contract are firm and irrevocable for the 
first

- changed (2019-11-05):
[0001437749-19-021592:note_history:51]
three
 months of a 
twelve
-month rolling forecast. The timing of the performance obligations beyond the 
twelve
-month forecast provided by Inox are 
not
 determinable and therefore are 
not
 included in the total remaining performance obligations.
  (was, 2019-08-06, similarity 0.9959):
[0001437749-19-015632:note_history:51]
three
 months of a 
twelve
 month rolling forecast. The timing of the performance obligations beyond the 
twelve
 month forecast provided by Inox are 
not
 determinable and therefore are 
not
 included in the total remaining performance obligations.

- changed (2019-11-05):
[0001437749-19-021592:note_history:52]
The following table sets forth customers who represented 
10%
 or more of the Company’s total revenues for
  (was, 2019-08-06, similarity 0.981):
[0001437749-19-015632:note_history:52]
The following table sets forth customers who represented 
10%
 or more of the Company’s total revenues for the

- added (2019-11-05):
[0001437749-19-021592:note_history:53]
three
 and 
six
 months ended 
 September 30, 2019

- added (2019-11-05):
[0001437749-19-021592:note_history:54]
|  |  |  | Three Months Ended |  |  | Six Months Ended |  |
|  | Reportable |  | September 30, |  |  | September 30, |  |
|  | Segment |  | 2019 |  |  | 2018 |  |  | 2019 |  |  | 2018 |  |
| Inox Wind Limited | Wind |  |  | <10% |  |  |  | 45 | % |  |  | 17 | % |  |  | 36 | % |
| Micron Technology | Grid |  |  | <10% |  |  |  | <10% |  |  |  | 14 | % |  |  | <10% |  |
| Vestas | Grid |  |  | <10% |  |  |  | 11 | % |  |  | <10% |  |  |  | 23 | % |
| Quanta Power | Grid |  |  | — | % |  |  | 12 | % |  |  | — | % |  |  | <10% |  |
| Hoffman Construction | Grid |  |  | 25 | % |  |  | — | % |  |  | 12 | % |  |  | — | % |
| M.J. Electric, LLC | Grid |  |  | 25 | % |  |  | — | % |  |  | 13 | % |  |  | — | % |

- removed (2019-11-05):
[0001437749-19-015632:note_history:55]
June 30, 2019

- removed (2019-11-05):
[0001437749-19-015632:note_history:56]
The Company's service contracts can include a purchase order from a customer for specific goods in which each item is a distinct performance obligation satisfied at a point in time at which control of the goods is transferred to the customer which occurs based on the contracted delivery terms or when the requested service work has been completed. The transaction price for these goods is allocated based on the adjusted market approach considering similar transactions under similar circumstances. Service contracts are also derived from ongoing maintenance contracts and extended service-type warranty contracts. In these transactions, the Company is contracted to provide an ongoing service over a specified period of time. As the customer is consuming the benefits as the service is being provided the revenue is recognized over time ratably.

- removed (2019-11-05):
[0001437749-19-015632:note_history:57]
|  |  | Three Months Ended June 30, 2019 |  |
| Product Line: |  | Grid |  |  | Wind |  |
| Equipment and systems |  | $ | 8,354 |  |  | $ | 3,505 |  |
| Services and technology development |  |  | 1,501 |  |  |  | 410 |  |
| Total |  | $ | 9,855 |  |  | $ | 3,915 |  |
| Region: |  |  |  |  |  |  |  |  |
| Americas |  | $ | 7,801 |  |  | $ | 46 |  |
| Asia Pacific |  |  | 1,827 |  |  |  | 3,856 |  |
| EMEA |  |  | 227 |  |  |  | 13 |  |
| Total |  | $ | 9,855 |  |  | $ | 3,915 |  |
|  |  | Three Months Ended June 30, 2018 |  |
| Product Line: |  | Grid |  |  | Wind |  |
| Equipment and systems |  | $ | 7,462 |  |  | $ | 3,492 |  |
| Services and technology development |  |  | 1,467 |  |  |  | 186 |  |
| Total |  | $ | 8,929 |  |  | $ | 3,678 |  |
| Region: |  |  |  |  |  |  |  |  |
| Americas |  | $ | 7,496 |  |  | $ | 23 |  |
| Asia Pacific |  |  | 808 |  |  |  | 3,595 |  |
| EMEA |  |  | 625 |  |  |  | 60 |  |
| Total |  | $ | 8,929 |  |  | $ | 3,678 |  |

- removed (2019-11-05):
[0001437749-19-015632:note_history:58]
June 30, 2019

- removed (2019-11-05):
[0001437749-19-015632:note_history:59]
June 30, 2018

- removed (2019-11-05):
[0001437749-19-015632:note_history:60]
June 30, 2019

- removed (2019-11-05):
[0001437749-19-015632:note_history:61]
million of outstanding performance obligations to be recognized over a period of 
thirteen
 to 
sixty
 months. The remaining performance obligations are subject to customer actions and therefore the timing of revenue recognition cannot be reasonably estimated. The 
twelve
 month performance obligations include anticipated shipments to Inox based on the 
twelve
 month rolling forecast provided by Inox on the multi-year supply contract. The quantities specified in any forecast provided by Inox related to the multi-year supply contract are firm and irrevocable for the 
first

- removed (2019-11-05):
[0001437749-19-015632:note_history:62]
three

- removed (2019-11-05):
[0001437749-19-015632:note_history:63]
June 30, 2019

- removed (2019-11-05):
[0001437749-19-015632:note_history:64]
|  |  |  | Three Months Ended |  |
|  | Reportable |  | June 30, 2019 |  |
|  | Segment |  | 2019 |  |  | 2018 |  |
| Inox Wind Limited | Wind |  | 27% |  |  | 25% |  |
| Vestas | Grid |  | <10% |  |  | 36% |  |
| Micron Technology | Grid |  | 25% |  |  | <10% |  |


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: tag_name, score: 1.0

- changed (2019-11-05):
[0001437749-19-021592:note_history:65]
The Company has performed an evaluation of subsequent events through the time of filing this Quarterly Report on Form 
10
-Q with the SEC and has determined that there are 
no
 such events to report.
  (was, 2019-08-06, similarity 0.9176):
[0001437749-19-015632:note_history:65]
The Company has performed an evaluation of subsequent events through the time of filing this Quarterly Report on Form 
10
-Q with the SEC and has determined that there are 
no
 such events to report other than those already discussed.
