# AMSC MD&A — 0001437749-19-021592


## mdna

[0001437749-19-021592:mdna:1]
[same as prior period, unchanged from 0001437749-19-015632:mdna:1]

[0001437749-19-021592:mdna:2]
[same as prior period, unchanged from 0001437749-19-015632:mdna:2]

[0001437749-19-021592:mdna:3]
[same as prior period, unchanged from 0001437749-19-015632:mdna:3]

[0001437749-19-021592:mdna:4]
[same as prior period, unchanged from 0001437749-19-015632:mdna:4]

[0001437749-19-021592:mdna:5]
[same as prior period, unchanged from 0001437749-19-015632:mdna:5]

[0001437749-19-021592:mdna:6]
[same as prior period, unchanged from 0001437749-19-015632:mdna:6]

[0001437749-19-021592:mdna:7]
[same as prior period, unchanged from 0001437749-19-015632:mdna:7]

[0001437749-19-021592:mdna:8]
[same as prior period, unchanged from 0001437749-19-015632:mdna:8]

[0001437749-19-021592:mdna:9]
[same as prior period, unchanged from 0001437749-19-015632:mdna:9]

[0001437749-19-021592:mdna:10]
[same as prior period, unchanged from 0001437749-19-015632:mdna:10]

[0001437749-19-021592:mdna:11]
On July 3, 2018, we and our wholly-owned subsidiaries Suzhou AMSC Superconductor Co. Ltd. (“AMSC China”) and AMSC Austria GmbH (“AMSC Austria”) entered into a settlement agreement (the “Settlement Agreement”) with Sinovel Wind Group Co., Ltd. (“Sinovel”). The Settlement Agreement settles the litigation and arbitration proceedings between us and Sinovel listed on Schedule 2 of the Settlement Agreement (the “Proceedings”), and any other civil claims, counterclaims, causes of action, rights and obligations directly or indirectly relating to the subject matters of the Proceedings and the contracts between us and Sinovel listed on Schedules 1 and 4 of the Settlement Agreement (the “Contracts”), subject to the exception described in Section 1.1 of the Settlement Agreement. The Settlement Agreement was filed as Exhibit 10.1 to the Company’s Form 8-K filed with the Securities and Exchange Commission on July 9, 2018. Under the terms of the Settlement Agreement, Sinovel agreed to pay AMSC China an aggregate cash amount in Renminbi (“RMB”) equivalent to $57.5 million, consisting of two installments. Sinovel paid the first installment of the RMB equivalent of $32.5 million on July 4, 2018 and paid the second installment of the RMB equivalent of $25.0 million on December 27, 2018.

[0001437749-19-021592:mdna:12]
[same as prior period, unchanged from 0001437749-19-015632:mdna:12]

[0001437749-19-021592:mdna:13]
On October 31, 2018, we entered into a Subcontract Agreement with Commonwealth Edison Company (“ComEd”) (the “Subcontract Agreement”) for the manufacture and installation of the Company’s REG system within ComEd’s electric grid in Chicago, Illinois (the “Project”). As provided in the Subcontract Agreement, the Subcontract Agreement became effective upon the signing of an amendment by us and the U.S. Department of Homeland Security (“DHS”) to the existing contract (the “Prime Contract”) between us and DHS on June 20, 2019. Unless terminated earlier by us, ComEd or DHS according to the terms of the Subcontract Agreement, the term of the Subcontract Agreement will continue until we complete our warranty obligations under the Subcontract Agreement. Under the terms of the Subcontract Agreement, we have agreed, among other things, to provide the REG system and to supervise ComEd’s installation of the REG system in Chicago. As part of our separate cost sharing arrangement with DHS under the Prime Contract, we expect funding provided by DHS in connection with the Subcontract Agreement to be between $9.0 to $11.0 million, which represents the total amount of revenue we are expected to recognize over the term of the Subcontract Agreement and includes up to $1.0 million that we have agreed to reimburse ComEd for costs incurred by ComEd while undertaking its tasks under the Subcontract Agreement (the “Reimbursement Amount”). In addition, we are required to deliver an irrevocable letter of credit in the amount of $5.0 million to secure certain Company obligations under the Subcontract Agreement. ComEd has agreed to provide the site and provide all civil engineering work required to support the installation, operation and integration of the REG system into ComEd’s electric grid. Other than the Reimbursement Amount, ComEd is responsible for its own costs and expenses. Construction of the Project is expected to commence within six months after DHS’s approval, which was obtained on June 20, 2019. The REG system is expected to be operational in 2021.

[0001437749-19-021592:mdna:14]
[same as prior period, unchanged from 0001437749-19-015632:mdna:14]

[0001437749-19-021592:mdna:15]
The preparation of the unaudited condensed consolidated financial statements requires that we make estimates and judgments that affect the reported amounts of assets, liabilities, revenues and expenses, and related disclosure of contingent assets and liabilities. We base our estimates on historical experience and various other assumptions that are believed to be reasonable under the circumstances, the results of which form the basis for making judgments about the carrying values of assets and liabilities that are not readily apparent from other sources. Actual results may differ under different assumptions or conditions. Effective April 1, 2019, we adopted ASU 2016-02, which provides for new requirements in regards to leases. See Note 14, "Leases" for further details. Aside from the adoption of ASU 2016-02, there were no significant changes in the critical accounting policies that were disclosed in our Form 10-K for fiscal 2018, which ended on March 31, 2019.

[0001437749-19-021592:mdna:16]
[same as prior period, unchanged from 0001437749-19-015632:mdna:16]

[0001437749-19-021592:mdna:17]
Three and six months ended September 30, 2019 compared to the three and six months ended September 30, 2018

[0001437749-19-021592:mdna:18]
[same as prior period, unchanged from 0001437749-19-015632:mdna:18]

[0001437749-19-021592:mdna:19]
Total revenues decreased 6% and increased 1% to $14.0 million and $27.8 million for the three and six months ended September 30, 2019, compared to $14.9 million and $27.5 million for the three and six months ended September 30, 2018.  Our revenues are summarized as follows (in thousands):

[0001437749-19-021592:mdna:20]
|  |  | Three Months Ended September 30, |  |  | Six Months Ended September 30, |  |
|  |  | 2019 |  |  | 2018 |  |  | 2019 |  |  | 2018 |  |
| Revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Grid |  | $ | 11,489 |  |  | $ | 7,569 |  |  | $ | 21,345 |  |  | $ | 16,498 |  |
| Wind |  |  | 2,523 |  |  |  | 7,307 |  |  |  | 6,437 |  |  |  | 10,985 |  |
| Total |  | $ | 14,012 |  |  | $ | 14,876 |  |  | $ | 27,782 |  |  | $ | 27,483 |  |

[0001437749-19-021592:mdna:21]
Our Grid business unit accounted for 82% and 77% of total revenues for the three and six months ended September 30, 2019, respectively, compared to 51% and 60% for the three and six months ended September 30, 2018, respectively. Our Grid business unit revenues increased 52% and 29% to $11.5 million and $21.3 million in the three and six months ended September 30, 2019, respectively, from $7.6 million and $16.5 million in the three and six months ended September 30, 2018, respectively. Grid business unit revenue in both the three and six months ended September 30, 2019 increased primarily driven by higher D-VAR revenues and the commencement of the REG project with ComEd.

[0001437749-19-021592:mdna:22]
Our Wind business unit accounted for 18% and 23% of total revenues for the three and six months ended September 30, 2019, respectively, compared to 49% and 40% for the three and six months ended September 30, 2018, respectively. Revenues in the Wind business unit decreased 65% and 41% to $2.5 million and $6.4 million in the three and six months ended September 30, 2019, respectively, from $7.3 million and $11.0 million in the three and six months ended September 30, 2018, respectively. The decreases over the prior year period were driven primarily by decreased shipments of ECS to Inox offset slightly by increased development revenue for the 3MW wind turbine platform with Inox and the 5.5MW with Doosan.  As further described in Note 1 “Nature of the Business and Operations and Liquidity,” Inox is currently delinquent on its obligations to post letters of credit for sets of electrical control systems that Inox has agreed to purchase under the terms of the supply contract.  We cannot predict if and when Inox will resume posting letters of credit for payment of contracted-for shipments of electrical control systems. Any continued failure by Inox to post letters of credit and take delivery of contracted-for shipments of electrical control shipments would impact the Company’s revenues and liquidity.  Inox has been active in the new central and state government auction regime in India and has over 900 MW of orders from the first four SECI central government auctions, and 50 MW from the Maharashtra state government auction. However, we cannot predict if and how successful Inox will be in executing on these orders or in obtaining new orders under the new central and state auction regime. Any failure by Inox to succeed under this regime, or any delay in Inox’s ability to deliver its wind turbines, could result in fewer ECS shipments to Inox.

[0001437749-19-021592:mdna:23]
[same as prior period, unchanged from 0001437749-19-015632:mdna:23]

[0001437749-19-021592:mdna:24]
Cost of revenues decreased by 9% and increased by 12% to $10.2 million and $22.4 million for the three and six months ended September 30, 2019, respectively, compared to $11.3 million and $20.0 million for the three and six months ended September 30, 2018, respectively. Gross margin was 27% and 19% for the three and six months ended September 30, 2019, respectively, compared to 24% and 27% for the three and six months ended September 30, 2018, respectively. The increase in gross margin in the three months ended September 30, 2019 was primarily due to favorable product mix in the Grid product line.  The decrease in gross margin in the six months ended September 30, 2019 was primarily due to a less favorable product mix, primarily due to fewer ECS shipments in the Wind product line than in the prior year period.

[0001437749-19-021592:mdna:25]
[same as prior period, unchanged from 0001437749-19-015632:mdna:25]

[0001437749-19-021592:mdna:26]
[same as prior period, unchanged from 0001437749-19-015632:mdna:26]

[0001437749-19-021592:mdna:27]
R&D expenses increased 6% in the three months ended September 30, 2019 to $2.4 million from $2.3 million in the three months ended September 30, 2018.  The increase in R&D expense in the three month period was due primarily to higher material spending on engineering and product development. R&D expenses decreased 5% in the six months ended September 30, 2019 to $4.9 million from $5.1 million in the six months ended September 30, 2018.  The decrease in R&D expense in the six month period was primarily due to better labor absorption to cost of revenues to support revenue generating projects.

[0001437749-19-021592:mdna:28]
[same as prior period, unchanged from 0001437749-19-015632:mdna:28]

[0001437749-19-021592:mdna:29]
SG&A expenses increased 4% in the three months ended September 30, 2019 to $5.4 million from $5.2 million in the three months ended September 30, 2018. The increase in SG&A expense in the three month period was due primarily to higher spending on outside services.  SG&A expenses decreased 3% in the six months ended September 30, 2019 to $10.7 million from $11.0 million in the six months ended September 30, 2018. The decrease in SG&A expense in the six month period was due primarily to higher stock compensation in the prior fiscal year.

[0001437749-19-021592:mdna:30]
Gain on Sinovel settlement

[0001437749-19-021592:mdna:31]
We recorded a gain of $28.7 million, net of legal and other direct costs, in each of the three and six months ended September 30, 2018 as a result of the receipt of the first payment from Sinovel required by the Settlement Agreement in July 2018.

[0001437749-19-021592:mdna:32]
[same as prior period, unchanged from 0001437749-19-015632:mdna:30]

[0001437749-19-021592:mdna:33]
We recorded amortization expense related to our core technology and know-how, trade names and trademark, and intangible assets of $0.1 million and $0.2 million in the three and six month periods ended September 30, 2019, and 2018, respectively.

[0001437749-19-021592:mdna:34]
[same as prior period, unchanged from 0001437749-19-015632:mdna:32]

[0001437749-19-021592:mdna:35]
We recorded $0.1 million and $0.4 million for facility exit costs in the three and six months ended September 30, 2018, respectively, as a result of the relocation of the corporate office that was announced as part of our April 4, 2017 approved restructuring plan.  There was no restructuring activity in the three and six months ended September 30, 2019.

[0001437749-19-021592:mdna:36]
Operating (loss) income

[0001437749-19-021592:mdna:37]
Our operating (loss) income is summarized as follows (in thousands):

[0001437749-19-021592:mdna:38]
|  |  | Three Months Ended September 30, |  |  | Six Months Ended September 30, |  |
|  |  | 2019 |  |  | 2018 |  |  | 2019 |  |  | 2018 |  |
| Operating (loss) income: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Grid |  | $ | (1,324 | ) |  | $ | (2,870 | ) |  | $ | (5,988 | ) |  | $ | (5,537 | ) |
| Wind |  |  | (2,398 | ) |  |  | 28,515 |  |  |  | (3,721 | ) |  |  | 27,150 |  |
| Unallocated corporate expenses |  |  | (397 | ) |  |  | (918 | ) |  |  | (646 | ) |  |  | (2,013 | ) |
| Total |  | $ | (4,119 | ) |  | $ | 24,727 |  |  | $ | (10,355 | ) |  | $ | 19,600 |  |

[0001437749-19-021592:mdna:39]
Our Grid segment generated an operating loss of $1.3 million and $6.0 million in the three and six months ended September 30, 2019, respectively, compared to $2.9 million and $5.5 million in the three and six months ended September 30, 2018, respectively. The decrease in the Grid business unit operating loss in the three months ended September 30, 2019 was primarily due to the increase in DVAR revenue discussed above.  The increase in Grid business unit operating loss in the six months ended September 30, 2019 was primarily due to a less favorable product mix than in the prior year period.

[0001437749-19-021592:mdna:40]
Our Wind segment generated an operating loss of $2.4 million and $3.7 million in the three and six months ended September 30, 2019, respectively, compared to income of $28.5 million and $27.1 million in the three and six months ended September 30, 2018, respectively. The decrease in the Wind business unit operating income in both periods were due primarily to receipt of the payment from Sinovel required by the Settlement Agreement in the second quarter of fiscal 2018 and no such payment in fiscal 2019.

[0001437749-19-021592:mdna:41]
Unallocated corporate expenses primarily consist of stock-based compensation expense of $0.4 million and $0.8 million in the three months ended September 30, 2019 and 2018, respectively, and restructuring charges of $0.1 million in the three months ended September 30, 2018.  Unallocated corporate expenses primarily consist of stock-based compensation expense of $0.6 million and $1.6 million in the six months ended September 30, 2019 and 2018, respectively, and restructuring charges of $0.4 million in the six months ended September 30, 2018.

[0001437749-19-021592:mdna:42]
[same as prior period, unchanged from 0001437749-19-015632:mdna:40]

[0001437749-19-021592:mdna:43]
The change in fair value of warrants resulted in a gain of $1.1 million and $4.1 million in the three and six months ended September 30, 2019, respectively, compared to a gain of $0.3 million and a loss of $0.2 million in the three and six months ended September 30, 2018, respectively. The change in the fair value was primarily driven by changes in stock price, which is a key valuation metric.

[0001437749-19-021592:mdna:44]
[same as prior period, unchanged from 0001437749-19-015632:mdna:42]

[0001437749-19-021592:mdna:45]
Interest income, net, was $0.3 million and $0.8 million in the three and six months ended September 30, 2019, compared to $0.2 million and $0.4 million in the three and six months ended September 30, 2018. The increase in interest income was primarily related to higher cash balances earning higher interest rates than in prior periods as well as the non-cash interest income recognized from receipt of the final payment on the Devens facility note receivable.

[0001437749-19-021592:mdna:46]
Other income, net

[0001437749-19-021592:mdna:47]
Other income, net, was $1.5 million and $1.0 million in the three and six months ended September 30, 2019, compared to $0.3 million and $0.9 million in the three and six months ended September 30, 2018.  The increase in other income, net, was primarily driven by higher foreign currency gains.

[0001437749-19-021592:mdna:48]
[same as prior period, unchanged from 0001437749-19-015632:mdna:46]

[0001437749-19-021592:mdna:49]
Income tax benefit was $0.3 million and $0.1 million in the three and six months ended September 30, 2019, compared to income tax expense of $3.0 million in each of the three and six months ended September 30, 2018. The decrease in income tax expense is due primarily to the prior year repayment of previously reserved intercompany trade balances due to AMSC Austria from AMSC China, and a dividend paid by AMSC Austria to us in the three months ended September 30, 2018 following the Sinovel settlement.

[0001437749-19-021592:mdna:50]
Net (loss) income

[0001437749-19-021592:mdna:51]
Net loss was $0.8 million and $4.4 million in the three and six months ended September 30, 2019, respectively, compared to net income of $22.6 million and $17.8 million in the three and six months ended September 30, 2018, respectively.  The increase in net loss in both periods was primarily driven by the receipt of the first payment from Sinovel required by the Settlement Agreement in the second quarter of fiscal 2018 and no such payment in fiscal 2019.

[0001437749-19-021592:mdna:52]
Non-GAAP Financial Measure - Non-GAAP Net Loss

[0001437749-19-021592:mdna:53]
[same as prior period, unchanged from 0001437749-19-015632:mdna:49]

[0001437749-19-021592:mdna:54]
We define non-GAAP net loss as net loss before stock-based compensation, gain on Sinovel settlement, net, amortization of acquisition-related intangibles, changes in fair value of warrants, and other non-cash or unusual charges, and the tax effect of those adjustments calculated at the relevant rate for our non-GAAP metric, indicated in the table below. We believe non-GAAP net loss assists management and investors in comparing our performance across reporting periods on a consistent basis by excluding these non-cash or non-recurring charges that we do not believe are indicative of our core operating performance. A reconciliation of GAAP to non-GAAP net loss is set forth in the table below (in thousands, except per share data):

[0001437749-19-021592:mdna:55]
|  |  | Three Months Ended September 30, |  |  | Six Months Ended September 30, |  |
|  |  | 2019 |  |  | 2018 |  |  | 2019 |  |  | 2018 |  |
| Net (loss) income |  | $ | (825 | ) |  | $ | 22,558 |  |  | $ | (4,364 | ) |  | $ | 17,821 |  |
| Stock-based compensation |  |  | 397 |  |  |  | 825 |  |  |  | 646 |  |  |  | 1,610 |  |
| (Gain) on Sinovel settlement, net |  |  | — |  |  |  | (28,720 | ) |  |  | — |  |  |  | (28,720 | ) |
| Amortization of acquisition-related intangibles |  |  | 85 |  |  |  | 85 |  |  |  | 170 |  |  |  | 170 |  |
| Changes in fair value of warrants |  |  | (1,145 | ) |  |  | (282 | ) |  |  | (4,092 | ) |  |  | 182 |  |
| Tax effect of adjustments for (gain) on Sinovel settlement, net |  |  | — |  |  |  | 2,829 |  |  |  | — |  |  |  | 2,829 |  |
| Non-GAAP net loss |  | $ | (1,488 | ) |  | $ | (2,705 | ) |  | $ | (7,640 | ) |  | $ | (6,108 | ) |
| Non-GAAP net loss per share - basic |  | $ | (0.07 | ) |  | $ | (0.13 | ) |  | $ | (0.37 | ) |  | $ | (0.30 | ) |
| Non-GAAP net loss per share - diluted |  | $ | (0.07 | ) |  | $ | (0.13 | ) |  | $ | (0.37 | ) |  | $ | (0.30 | ) |
| Weighted average shares outstanding - basic |  |  | 20,656 |  |  |  | 20,313 |  |  |  | 20,586 |  |  |  | 20,240 |  |
| Weighted average shares outstanding - diluted |  |  | 20,723 |  |  |  | 20,313 |  |  |  | 20,736 |  |  |  | 20,240 |  |

[0001437749-19-021592:mdna:56]
We incurred non-GAAP net losses of $1.5 million and $7.6 million or $0.07 and $0.37 per share, for the three and six months ended September 30, 2019, respectively, compared to non-GAAP net losses of $2.7 million and $6.1 million, or $0.13 and $0.30 per share for the three and six months ended September 30, 2018 respectively. The changes in non-GAAP net loss were primarily due to the more favorable product mix in the three month periods as compared to the six month periods.

[0001437749-19-021592:mdna:57]
For a description and reconciliation of our other non-GAAP financial measure, non-GAAP operating cash flow, see the below under “Non-GAAP Financial Measure – Non-GAAP Operating Cash Flow.”

[0001437749-19-021592:mdna:58]
[same as prior period, unchanged from 0001437749-19-015632:mdna:55]

[0001437749-19-021592:mdna:59]
We have experienced recurring operating losses, and as of September 30, 2019, had an accumulated deficit of $965.9 million.

[0001437749-19-021592:mdna:60]
Our cash requirements depend on numerous factors, including whether Inox is successful in executing on SECI orders or in obtaining additional orders under the new central and state auction regime, whether and to the extent that Inox fulfills its purchase obligations under our supply contract, the successful completion of our product development activities, our ability to commercialize our REG and ship protection system solutions, the rate of customer and market adoption of our products, collecting receivables according to established terms, and the continued availability of U.S. government funding during the product development phase of our superconductor-based products. We continue to closely monitor our expenses and, if required, expect to further reduce our operating and capital spending to enhance liquidity.

[0001437749-19-021592:mdna:61]
As of September 30, 2019, we had cash, cash equivalents, restricted cash, and marketable securities of $68.6 million, compared to $78.2 million as of March 31, 2019, a decrease of $9.6 million. As of September 30, 2019, we had approximately $28.1 million of cash, cash equivalents, and restricted cash in foreign bank accounts. Our cash and cash equivalents, and restricted cash are summarized as follows (in thousands):

[0001437749-19-021592:mdna:62]
|  |  | September 30, 2019 |  |  | March 31, 2019 |  |
| Cash and cash equivalents |  | $ | 52,829 |  |  | $ | 77,483 |  |
| Restricted cash |  |  | 5,736 |  |  |  | 715 |  |
| Marketable securities |  |  | 10,000 |  |  |  | — |  |
| Total cash, cash equivalents, and restricted cash |  | $ | 68,565 |  |  | $ | 78,198 |  |

[0001437749-19-021592:mdna:63]
For the six months ended September 30, 2019, net cash used in operating activities was $10.5 million compared to net cash provided by operating activities of $23.6 million for the six months ended September 30, 2018. The decrease in net cash provided by operations was due primarily to the receipt of the first payment from the Sinovel settlement in the six months ended September 30, 2018 with no similar transaction in the six months ended September 30, 2019.

[0001437749-19-021592:mdna:64]
For the six months ended September 30, 2019, net cash used in investing activities was $8.7 million, compared to $0.4 million for the six months ended September 30, 2018. The increase in net cash used in investing activities was due primarily to the purchase of marketable securities and the higher purchases of property, plant and equipment related to improvements to the Ayer facility and factory equipment to support the Navy and REG projects, partially offset by the receipt of the second installment payment under the Notes Receivable from the Devens facility sale in the six months ended September 30, 2019.

[0001437749-19-021592:mdna:65]
For the six months ended September 30, 2019, net cash used in financing activities was $0.4 million compared to net cash used in financing activities of $0.3 million in the six months ended September 30, 2018.  The increase in net cash used in financing activities was due primarily to increased employee taxes paid related to net settlement of equity awards.

[0001437749-19-021592:mdna:66]
As of September 30, 2019, we had $5.7 million of restricted cash included in long-term assets. These amounts included in restricted cash primarily represent deposits to secure letters of credit for various supply contracts and long-term projects. These deposits are held in interest bearing accounts.

[0001437749-19-021592:mdna:67]
[same as prior period, unchanged from 0001437749-19-015632:mdna:64]

[0001437749-19-021592:mdna:68]
Non-GAAP Financial Measure – Non-GAAP Operating Cash Flow

[0001437749-19-021592:mdna:69]
[same as prior period, unchanged from 0001437749-19-015632:mdna:53]

[0001437749-19-021592:mdna:70]
|  |  |  | Six months ended |  |
|  |  | September 30, 2019 |  |  | September 30, 2018 |  |
| Operating cash flow |  | $ | (10,485 | ) |  | $ | 30,481 |  |
| Sinovel settlement (net of legal fees and expenses) |  |  | 1,000 |  |  |  | (30,336 | ) |
| Tax effect of adjustments |  |  | — |  |  |  | 1,247 |  |
| Non-GAAP operating cash flow |  | $ | (9,485 | ) |  | $ | 1,392 |  |

[0001437749-19-021592:mdna:71]
Legal Proceedings

[0001437749-19-021592:mdna:72]
We are involved in legal and administrative proceedings and claims of various types. See Part II, Item 1, “Legal Proceedings,” for additional information. We record a liability in our consolidated financial statements for these matters when a loss is known or considered probable and the amount can be reasonably estimated. We review these estimates each accounting period as additional information is known and adjust the loss provision when appropriate. If a matter is both probable to result in liability and the amounts of loss can be reasonably estimated, we estimate and disclose the possible loss or range of loss to the extent necessary to make the consolidated financial statements not misleading. If the loss is not probable or cannot be reasonably estimated, a liability is not recorded in our consolidated financial statements.

[0001437749-19-021592:mdna:73]
[same as prior period, unchanged from 0001437749-19-015632:mdna:67]

[0001437749-19-021592:mdna:74]
[same as prior period, unchanged from 0001437749-19-015632:mdna:68]

[0001437749-19-021592:mdna:75]
[same as prior period, unchanged from 0001437749-19-015632:mdna:69]

[0001437749-19-021592:mdna:76]
[same as prior period, unchanged from 0001437749-19-015632:mdna:70]

[0001437749-19-021592:mdna:77]
[same as prior period, unchanged from 0001437749-19-015632:mdna:71]

[0001437749-19-021592:mdna:78]
In February 2016, the FASB issued Accounting Standards Update ("ASU") 2016-02, Leases (Topic 842). The guidance in this ASU supersedes the leasing guidance in Topic 840, Leases. Under the new guidance, lessees are required to recognize lease assets and lease liabilities on the balance sheet for all leases with terms longer than 12 months. Leases will be classified as either finance or operating, with classification affecting the pattern of expense recognition in the income statement. This ASU and its amendments are effective for fiscal years beginning after December 15, 2018, including interim periods within those fiscal years.

[0001437749-19-021592:mdna:79]
|  | • | In July 2018, the FASB issued ASU 2018-10, Codification improvements to Topic 842, Leases. The amendments in ASU 2018-10 provide more clarification in regards to the application and requirements of ASU 2016-02. |

[0001437749-19-021592:mdna:80]
|  | • | In July 2018, the FASB issued ASU 2018-11, Topic 842, Leases - Targeted improvements. The amendments in ASU 2018-11 provide for the option to adopt the standard prospectively and recognize a cumulative-effect adjustment to the opening balance of retained earnings as well as offer a new practical expedient that will allow us to elect, by class of underlying asset, to not separate non-lease and lease components in certain circumstances and instead to account for those components as a single item. |

[0001437749-19-021592:mdna:81]
ASU 2016-02 became effective on April 1, 2019, and we adopted the standard using the modified retrospective transition method, which will impact all leases existing at, or entered into after, the period of adoption. For all leases existing at the time of adoption we recognized a right-of-use asset and lease liability on the balance sheet.  See Note 14 "Leases" for additional information.

[0001437749-19-021592:mdna:82]
In June 2016, the FASB issued ASU 2016-13, Financial Instruments-Credit Losses (Topic 326): Measurement of Credit Losses on Financial Instruments. The amendments in ASU 2016-13 provide more decision-useful information about the expected credit losses on financial instruments and other commitments to extend credit held by a reporting entity at each reporting date. The ASU is effective for annual reporting periods beginning after December 15, 2019, including interim periods within that year.  We are currently evaluating the impact, if any, the adoption of ASU 2016-13 may have on our consolidated financial statements.

[0001437749-19-021592:mdna:83]
In July 2017, the FASB issued ASU 2017-11, Earnings per Share (Topic 260), Distinguishing Liabilities from Equity (Topic 480), and Derivatives and Hedging (Topic 815). The amendments in ASU 2017-11 provide guidance for freestanding equity-linked financial instruments, such as warrants and conversion options in convertible debt or preferred stock, and should no longer be accounted for as a derivative liability at fair value as a result of the existence of a down round feature. The ASU is effective for annual reporting periods beginning after December 15, 2018, including interim periods within those periods. As of April 1, 2019 we have adopted ASU 2017-11 and noted no significant impact on our consolidated financial statements, primarily due to the put option feature which requires continued liability classification under ASC 840.

[0001437749-19-021592:mdna:84]
In August 2017, the FASB issued ASU 2017-12, Derivatives and Hedging (Topic 815): Targeted Improvements to Accounting for Hedging Activities. The amendments in ASU 2017-12 provide improved financial reporting of hedging relationships to better portray the economic results of an entity’s risk management activities in its financial statements. In addition, the amendments in this update make certain targeted improvements to simplify the application of the hedge accounting guidance. The ASU is effective for annual reporting periods beginning after December 15, 2018, including interim periods within those periods. As of April 1, 2019 we have adopted ASU 2017-12 and noted no significant impact on our consolidated financial statements, primarily due to the fact that there are no longer any hedging instruments included in our results.

[0001437749-19-021592:mdna:85]
In June 2018, the FASB issued ASU 2018-08, Not-For-Profit Entities (Topic 958): Clarifying the Scope and the Accounting Guidance for Contributions Received and Contributions Made.  The amendments in ASU 2018-08 assist entities in (1) evaluating whether transactions should be accounted for as contributions (nonreciprocal transactions) within the scope of Topic 958, Not-for-Profit Entities, or as exchange (reciprocal) transactions subject to other guidance and (2) determining whether a contribution is conditional.  The ASU is effective for annual reporting periods beginning after December 15, 2018, including interim periods within those periods. As of April 1, 2019, we have adopted ASU 2018-08 and noted additional disclosures within our revenue footnote to appropriately present the revenue related to our grant revenue.

[0001437749-19-021592:mdna:86]
In August 2018, the FASB issued ASU 2018-13, Fair Value Measurement (Topic 820): Changes to the Disclosure Requirements for Fair Value Measurement. The amendments in ASU 2018-13 provide for increased effectiveness of the disclosures made around fair value measurements while including consideration for costs and benefits. The ASU is effective for annual reporting periods beginning after December 15, 2019, including interim periods within those periods. We are currently evaluating the impact the adoption of ASU 2018-13 may have on our consolidated financial statements.

[0001437749-19-021592:mdna:87]
We do not believe that, outside of those disclosed here, there are any other recently issued accounting pronouncements that will have a material impact on our consolidated financial statements.
