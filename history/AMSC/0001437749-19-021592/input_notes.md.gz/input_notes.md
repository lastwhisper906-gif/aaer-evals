# AMSC notes — 0001437749-19-021592


## amsc:AccountsReceivableTableTextBlock

[0001437749-19-021592:notes:1]
|  |  | September 30, 2019 |  |  | March 31, 2019 |  |
| Accounts receivable (billed) |  | $ | 6,079 |  |  | $ | 5,642 |  |
| Accounts receivable (unbilled) |  |  | 3,994 |  |  |  | 2,213 |  |
| Accounts receivable, net |  | $ | 10,073 |  |  | $ | 7,855 |  |


## amsc:AccountsReceivableTextBlock

[0001437749-19-021592:notes:2]
[same as prior period, unchanged from 0001437749-19-015632:notes:2]

[0001437749-19-021592:notes:3]
[same as prior period, unchanged from 0001437749-19-015632:notes:3]

[0001437749-19-021592:notes:4]
September 30, 2019

[0001437749-19-021592:notes:5]
[same as prior period, unchanged from 0001437749-19-015632:notes:5]

[0001437749-19-021592:notes:6]
[same as prior period, unchanged from 0001437749-19-015632:notes:6]

[0001437749-19-021592:notes:7]
[same as prior period, unchanged from 0001437749-19-015632:notes:7]


## amsc:AssetsAndLiabilitiesLesseeTableTextBlock

[0001437749-19-021592:notes:8]
|  |  | September 30, 2019 |  |
| Operating Leases: |  |  |  |  |
| Right-of-use assets |  | $ | 3,607 |  |
| Total right-of-use assets |  |  | 3,607 |  |
| Lease liabilities - ST |  | $ | 424 |  |
| Lease liabilities - LT |  |  | 3,240 |  |
| Total operating lease liabilities |  |  | 3,664 |  |
| Weighted-average remaining lease term |  |  | 7.31 years |  |
| Weighted-average discount rate |  |  | 7.07 | % |


## amsc:LiquidityPolicyPolicyTextBlock

[0001437749-19-021592:notes:9]
[same as prior period, unchanged from 0001437749-19-015632:notes:9]

[0001437749-19-021592:notes:10]
[same as prior period, unchanged from 0001437749-19-015632:notes:10]

[0001437749-19-021592:notes:11]
[same as prior period, unchanged from 0001437749-19-015632:notes:11]

[0001437749-19-021592:notes:12]
965.9

[0001437749-19-021592:notes:13]
[same as prior period, unchanged from 0001437749-19-015632:notes:13]

[0001437749-19-021592:notes:14]
, the Company had cash, cash equivalents, and marketable securities of $

[0001437749-19-021592:notes:15]
62.8

[0001437749-19-021592:notes:16]
million, with 
no
 outstanding debt other than ordinary trade payables. Marketable securities include certificate of deposits with maturities between 
twelve
 and 
twenty-four
 months.  Cash used in operations for the

[0001437749-19-021592:notes:17]
six

[0001437749-19-021592:notes:18]
[same as prior period, unchanged from 0001437749-19-015632:notes:18]

[0001437749-19-021592:notes:19]
[same as prior period, unchanged from 0001437749-19-015632:notes:19]

[0001437749-19-021592:notes:20]
10.5

[0001437749-19-021592:notes:21]
[same as prior period, unchanged from 0001437749-19-015632:notes:21]

[0001437749-19-021592:notes:22]
[same as prior period, unchanged from 0001437749-19-015632:notes:22]

[0001437749-19-021592:notes:23]
[same as prior period, unchanged from 0001437749-19-015632:notes:23]

[0001437749-19-021592:notes:24]
2018,
 the Company and its wholly-owned subsidiaries Suzhou AMSC Superconductor Co. Ltd. (“AMSC China”) and AMSC Austria GMBH (“AMSC Austria”) entered into a settlement agreement (the “Settlement Agreement”) with Sinovel Wind Group Co., Ltd. (“Sinovel”). The Settlement Agreement settles the litigation and arbitration proceedings between the Company and Sinovel. Under the terms of the Settlement Agreement, Sinovel agreed to pay AMSC China an aggregate cash amount in Renminbi (“RMB”) equivalent to 
$57.5
 million, consisting of 
two
 installments. Sinovel paid the 
first
 installment of the RMB equivalent of 
$32.5
 million on 
 July

[0001437749-19-021592:notes:25]
[same as prior period, unchanged from 0001437749-19-015632:notes:25]

[0001437749-19-021592:notes:26]
[same as prior period, unchanged from 0001437749-19-015632:notes:26]

[0001437749-19-021592:notes:27]
[same as prior period, unchanged from 0001437749-19-015632:notes:27]

[0001437749-19-021592:notes:28]
2018
 and paid the 
second
 installment of the RMB equivalent of 
$25.0
 million on 
 December 27, 2018.  
The Company’s fiscal 
2018
 results included the net gain received from the settlement with Sinovel of 
$52.7
 million.

[0001437749-19-021592:notes:29]
[same as prior period, unchanged from 0001437749-19-015632:notes:29]

[0001437749-19-021592:notes:30]
[same as prior period, unchanged from 0001437749-19-015632:notes:30]

[0001437749-19-021592:notes:31]
[same as prior period, unchanged from 0001437749-19-015632:notes:31]

[0001437749-19-021592:notes:32]
In 
 December 2015, 
the Company entered into a set of strategic agreements valued at approximately 
$210.0
 million with Inox Wind Ltd. (“Inox” or “Inox Wind”), which includes a multi-year supply contract pursuant to which the Company will supply electrical control systems ("ECS") to Inox and a license agreement allowing Inox to manufacture a limited number of ECS. After Inox purchases the specified number of ECS required under the terms of the supply contract, Inox agreed that the Company will continue as Inox’s preferred supplier and Inox will be required to purchase from the Company a majority of its ECS requirements for an additional 
three
-year period. Pursuant to these strategic agreements, Inox must forecast future purchase orders of sets of ECS which become firm orders 
three
 months prior to shipment, and Inox must post letters of credit before the Company will ship such orders. Inox is currently delinquent on its obligation to post letters of credit for sets of ECS that Inox forecasted to purchase under the terms of the supply contract.  We cannot predict if and when Inox will post letters of credit consistent with the forecasted ECS quantities. Inox’s failure to post letters of credit and take delivery of forecasted ECS quantities would impact the Company’s revenues and liquidity.

[0001437749-19-021592:notes:33]
[same as prior period, unchanged from 0001437749-19-015632:notes:33]

[0001437749-19-021592:notes:34]
[same as prior period, unchanged from 0001437749-19-015632:notes:34]


## amsc:NatureOfBusinessAndOperationsPolicyPolicyTextBlock

[0001437749-19-021592:notes:35]
[same as prior period, unchanged from 0001437749-19-015632:notes:35]

[0001437749-19-021592:notes:36]
[same as prior period, unchanged from 0001437749-19-015632:notes:36]

[0001437749-19-021592:notes:37]
[same as prior period, unchanged from 0001437749-19-015632:notes:37]

[0001437749-19-021592:notes:38]
[same as prior period, unchanged from 0001437749-19-015632:notes:38]

[0001437749-19-021592:notes:39]
[same as prior period, unchanged from 0001437749-19-015632:notes:39]

[0001437749-19-021592:notes:40]
[same as prior period, unchanged from 0001437749-19-015632:notes:40]

[0001437749-19-021592:notes:41]
[same as prior period, unchanged from 0001437749-19-015632:notes:41]

[0001437749-19-021592:notes:42]
[same as prior period, unchanged from 0001437749-19-015632:notes:42]

[0001437749-19-021592:notes:43]
[same as prior period, unchanged from 0001437749-19-015632:notes:43]

[0001437749-19-021592:notes:44]
[same as prior period, unchanged from 0001437749-19-015632:notes:44]


## amsc:NotesReceivableTableTextBlock

[0001437749-19-021592:notes:45]
| Current assets |  | September 30, 2019 |  |  | March 31, 2019 |  |
| Note receivable, current |  | $ | — |  |  | $ | 3,000 |  |
| Note receivable discount |  |  | — |  |  |  | (112 | ) |
| Total current note receivable |  | $ | — |  |  | $ | 2,888 |  |


## amsc:NotesReceivableTextBlock

[0001437749-19-021592:notes:46]
[same as prior period, unchanged from 0001437749-19-015632:notes:46]

[0001437749-19-021592:notes:47]
The Company entered into the PSA dated 
 February 1, 2018, 
for the sale of the Devens facility (including land, building and building improvements) located at 
64
 Jackson Road, Devens, Massachusetts to 
64
 Jackson, LLC, a limited liability company (subsequently assigned to Jackson 
64
 MGI, LLC) in the amount of 
$23.0
 million. The terms for payment included a 
$1.0
 million security deposit, and a note receivable for 
$6.0
 million payable to the Company with the remaining cash, net of certain adjustments for closing costs, at the date of settlement. The note receivable was due in 
two

[0001437749-19-021592:notes:48]
[same as prior period, unchanged from 0001437749-19-015632:notes:48]

[0001437749-19-021592:notes:49]
The note receivable was discounted to its present value of 
$5.7
 million utilizing a discount rate of 
6%,
 which was based on management’s assessment of what an appropriate loan at current market rates would be. The 
$0.3
 million discount was recorded as an offset to the long-term portion of the note receivable. In addition, the resulting gain of 
$0.1
 million from the sale of the Devens property which was deferred previously was recorded as a component of the cumulative effect of an accounting change upon the adoption of Accounting Standards Update ("ASU") 
2017
-
05

[0001437749-19-021592:notes:50]
[same as prior period, unchanged from 0001437749-19-015632:notes:50]

[0001437749-19-021592:notes:51]
Revenue from Contracts with Customers (Topic 
606
)
. This gain was recorded as an offset to the opening accumulated deficit as of 
 April 1, 2018.

[0001437749-19-021592:notes:52]
[same as prior period, unchanged from 0001437749-19-015632:notes:52]


## us-gaap:AccountsPayableAndAccruedLiabilitiesDisclosureTextBlock

[0001437749-19-021592:notes:53]
[same as prior period, unchanged from 0001437749-19-015632:notes:53]

[0001437749-19-021592:notes:54]
[same as prior period, unchanged from 0001437749-19-015632:notes:54]

[0001437749-19-021592:notes:55]
|  |  | September 30, 2019 |  |  | March 31, 2019 |  |
| Accounts payable |  | $ | 6,164 |  |  | $ | 2,939 |  |
| Accrued inventories in-transit |  |  | 603 |  |  |  | 244 |  |
| Accrued other miscellaneous expenses |  |  | 1,772 |  |  |  | 1,759 |  |
| Advanced deposits |  |  | 1,771 |  |  |  | 631 |  |
| Accrued compensation |  |  | 3,730 |  |  |  | 5,404 |  |
| Income taxes payable |  |  | 3,043 |  |  |  | 3,363 |  |
| Accrued product warranty |  |  | 1,641 |  |  |  | 1,545 |  |
| Total |  | $ | 18,724 |  |  | $ | 15,885 |  |

[0001437749-19-021592:notes:56]
[same as prior period, unchanged from 0001437749-19-015632:notes:56]

[0001437749-19-021592:notes:57]
[same as prior period, unchanged from 0001437749-19-015632:notes:57]

[0001437749-19-021592:notes:58]
|  |  | Three Months Ended September 30, |  |  | Six Months Ended September 30, |  |
|  |  | 2019 |  |  | 2018 |  |  | 2019 |  |  | 2018 |  |
| Balance at beginning of period |  | $ | 1,606 |  |  | $ | 1,752 |  |  | $ | 1,545 |  |  | $ | 1,769 |  |
| Change in accruals for warranties during the period |  |  | 71 |  |  |  | 213 |  |  |  | 156 |  |  |  | 317 |  |
| Settlements during the period |  |  | (36 | ) |  |  | (205 | ) |  |  | (60 | ) |  |  | (326 | ) |
| Balance at end of period |  | $ | 1,641 |  |  | $ | 1,760 |  |  | $ | 1,641 |  |  | $ | 1,760 |  |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001437749-19-021592:notes:59]
15.
 Commitments and Contingencies

[0001437749-19-021592:notes:60]
Legal Contingencies

[0001437749-19-021592:notes:61]
From time to time, the Company is involved in legal and administrative proceedings and claims of various types. The Company records a liability in its consolidated financial statements for these matters when a loss is known or considered probable and the amount can be reasonably estimated. The Company reviews these estimates each accounting period as additional information is known and adjusts the loss provision when appropriate. If a matter is both probable to result in a liability and the amounts of loss can be reasonably estimated, the Company estimates and discloses the possible loss or range of loss to the extent necessary to make the consolidated financial statements 
not
 misleading. If the loss is 
not
 probable or cannot be reasonably estimated, a liability is 
not
 recorded in its consolidated financial statements.

[0001437749-19-021592:notes:62]
Other

[0001437749-19-021592:notes:63]
The Company enters into long-term construction contracts with customers that require the Company to obtain performance bonds. The Company is required to deposit an amount equivalent to some or all the face amount of the performance bonds into an escrow account until the termination of the bond. When the performance conditions are met, amounts deposited as collateral for the performance bonds are returned to the Company. In addition, the Company has various contractual arrangements in which minimum quantities of goods or services have been committed to be purchased on an annual basis.

[0001437749-19-021592:notes:64]
As of

[0001437749-19-021592:notes:65]
, the Company had $

[0001437749-19-021592:notes:66]
5.7

[0001437749-19-021592:notes:67]
million of restricted cash included in long-term assets. These amounts included in restricted cash primarily represent deposits to secure letters of credit for various supply contracts. These deposits are held in interest bearing accounts.  As part of the agreement with Commonwealth Edison Company to install the Resilient Electric Grid ("REG") system in Chicago, the Company agreed to deliver an irrevocable letter of credit in the amount of 
$5.0
 million to secure certain Company obligations under the Subcontract Agreement.  The funds to secure the 
$5.0
 million letter of credit were deposited in an escrow account on 
 July 1, 2019.


## us-gaap:ContractWithCustomerAssetAndLiabilityTableTextBlock

[0001437749-19-021592:notes:68]
|  |  | Unbilled Accounts Receivable |  |  | Deferred Program Costs |  |  | Contract Liabilities |  |
| Beginning balance as of March 31, 2019 |  | $ | 2,213 |  |  | $ | 318 |  |  | $ | 15,519 |  |
| Increases for costs incurred to fulfill performance obligations |  |  | — |  |  |  | 2,153 |  |  |  | — |  |
| Increase (decrease) due to customer billings |  |  | (2,926 | ) |  |  | — |  |  |  | 19,340 |  |
| Decrease due to cost recognition on completed performance obligations |  |  | — |  |  |  | (310 | ) |  |  | — |  |
| Increase (decrease) due to recognition of revenue based on transfer of control of performance obligations |  |  | 4,711 |  |  |  | — |  |  |  | (18,534 | ) |
| Other changes and FX impact |  |  | (4 | ) |  |  | (9 | ) |  |  | (313 | ) |
| Ending balance as of September 30, 2019 |  | $ | 3,994 |  |  | $ | 2,152 |  |  | $ | 16,012 |  |

[0001437749-19-021592:notes:69]
|  |  | Unbilled Accounts Receivable |  |  | Deferred Program Costs |  |  | Contract Liabilities |  |
| Beginning balance as of March 31, 2018 |  | $ | 3,016 |  |  | $ | 2,567 |  |  | $ | 21,937 |  |
| Impact of adoption of ASC 606 |  |  | — |  |  |  | (1,599 | ) |  |  | (2,657 | ) |
| Increases for costs incurred to fulfill performance obligations |  |  | — |  |  |  | 1,267 |  |  |  | — |  |
| Increase (decrease) due to customer billings |  |  | (7,886 | ) |  |  | — |  |  |  | 7,828 |  |
| Decrease due to cost recognition on completed performance obligations |  |  | — |  |  |  | (1,033 | ) |  |  | — |  |
| Increase (decrease) due to recognition of revenue based on transfer of control of performance obligations |  |  | 7,439 |  |  |  | (9 | ) |  |  | (8,296 | ) |
| Other changes and FX impact |  |  | (19 | ) |  |  | 24 |  |  |  | (864 | ) |
| Ending balance as of September 30, 2018 |  | $ | 2,550 |  |  | $ | 1,217 |  |  | $ | 17,948 |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001437749-19-021592:notes:70]
[same as prior period, unchanged from 0001437749-19-015632:notes:69]

[0001437749-19-021592:notes:71]
[same as prior period, unchanged from 0001437749-19-015632:notes:70]

[0001437749-19-021592:notes:72]
[same as prior period, unchanged from 0001437749-19-015632:notes:71]

[0001437749-19-021592:notes:73]
On 
 December 19, 2014, 
the Company entered into a 
second
 amendment to the Loan and Security Agreement with Hercules (the "Hercules Second Amendment"). In conjunction with the Hercules Second Amendment, the Company issued Hercules a warrant to purchase 
58,823
 shares of the Company’s common stock (the "Hercules Warrant") which replaced the First Warrant and the Second Warrant.  The Hercules Warrant was exercisable at any time after its issuance at an exercise price of 
$7.85
 per share, subject to certain price-based and other anti-dilution adjustments, including the equity offering in 
 May 2017, 
the acquisition of ITC with common stock in 
 September 2017 
and sales of common stock under the ATM entered into in 
 January 2017.  
This warrant had a fair value of 
$0.4
 million as of 
 March 31, 2019.  
On 
 April 8, 2019, 
Hercules notified the Company of its intent to exercise this warrant on a cashless basis.  Hercules received 
22,821
 shares of the Company's common stock on 
 April 17, 2019.  
As a result of this exercise the Company recorded a net gain of 
$0.1
 million to change in fair value of warrants, resulting from the decrease in the fair value upon exercise of the Hercules Warrant during the

[0001437749-19-021592:notes:74]
[same as prior period, unchanged from 0001437749-19-015632:notes:85]

[0001437749-19-021592:notes:75]
[same as prior period, unchanged from 0001437749-19-015632:notes:73]

[0001437749-19-021592:notes:76]
On 
 November 13, 2014, 
the Company completed an offering of 
909,090
 units of the Company’s common stock with Hudson Bay Capital. Each unit consisted of 
one
 share of the Company’s common stock and 
0.9
 of a warrant to purchase 
one
 share of common stock, or a warrant to purchase in the aggregate 
818,181
 shares (the 
 “November 2014 
Warrant”).  The 
 November 2014 
Warrant is exercisable at any time, at an exercise price equal to 
$7.81
 per share, subject to certain price-based and other anti-dilution adjustments including those noted above and expires on 
 November

[0001437749-19-021592:notes:77]
[same as prior period, unchanged from 0001437749-19-015632:notes:75]

[0001437749-19-021592:notes:78]
[same as prior period, unchanged from 0001437749-19-015632:notes:76]

[0001437749-19-021592:notes:79]
[same as prior period, unchanged from 0001437749-19-015632:notes:77]

[0001437749-19-021592:notes:80]
|  |  | September 30, |  |  | June 30, |  |
| Fiscal Year 2019 |  |  | 2019 |  |  |  | 2019 |  |
| Risk-free interest rate |  |  | 1.90 | % |  |  | 2.11 | % |
| Expected annual dividend yield |  |  | — |  |  |  | — |  |
| Expected volatility |  |  | 62.84 | % |  |  | 60.58 | % |
| Term (years) |  |  | 0.12 |  |  |  | 0.37 |  |
| Fair value |  | $0.6 million |  |  | $1.7 million |  |

[0001437749-19-021592:notes:81]
[same as prior period, unchanged from 0001437749-19-015632:notes:79]

[0001437749-19-021592:notes:82]
The Company recorded net 
gains 
of $

[0001437749-19-021592:notes:83]
1.1

[0001437749-19-021592:notes:84]
million and $

[0001437749-19-021592:notes:85]
4.1

[0001437749-19-021592:notes:86]
million resulting from the 
decreases 
in the fair value of the 
 November 2014 
Warrant during the

[0001437749-19-021592:notes:87]
three
 and 
six

[0001437749-19-021592:notes:88]
, respectively. The Company recorded a net gain of 
$0.3
 million and net loss of 
$0.2
 million resulting from the changes in the fair value of the 
 November 2014 
Warrant during the

[0001437749-19-021592:notes:89]
September 30, 2018

[0001437749-19-021592:notes:90]
, respectively.


## us-gaap:DisaggregationOfRevenueTableTextBlock

[0001437749-19-021592:notes:91]
|  |  | Three Months Ended September 30, 2019 |  |  | Six Months Ended September 30, 2019 |  |
| Product Line: |  | Grid |  |  | Wind |  |  | Grid |  |  | Wind |  |
| Equipment and systems |  | $ | 10,044 |  |  | $ | 2,077 |  |  | $ | 18,399 |  |  | $ | 5,581 |  |
| Services and technology development |  |  | 1,445 |  |  |  | 446 |  |  |  | 2,946 |  |  |  | 856 |  |
| Total |  | $ | 11,489 |  |  | $ | 2,523 |  |  | $ | 21,345 |  |  | $ | 6,437 |  |
| Region: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas |  | $ | 10,698 |  |  | $ | 1 |  |  | $ | 18,499 |  |  | $ | 47 |  |
| Asia Pacific |  |  | 393 |  |  |  | 2,464 |  |  |  | 2,220 |  |  |  | 6,320 |  |
| EMEA |  |  | 398 |  |  |  | 58 |  |  |  | 626 |  |  |  | 70 |  |
| Total |  | $ | 11,489 |  |  | $ | 2,523 |  |  | $ | 21,345 |  |  | $ | 6,437 |  |

[0001437749-19-021592:notes:92]
|  |  | Three Months Ended September 30, 2018 |  |  | Six Months Ended September 30, 2018 |  |
| Product Line: |  | Grid |  |  | Wind |  |  | Grid |  |  | Wind |  |
| Equipment and systems |  | $ | 5,503 |  |  | $ | 7,219 |  |  | $ | 12,957 |  |  | $ | 10,711 |  |
| Services and technology development |  |  | 2,066 |  |  |  | 88 |  |  |  | 3,541 |  |  |  | 274 |  |
| Total |  | $ | 7,569 |  |  | $ | 7,307 |  |  | $ | 16,498 |  |  | $ | 10,985 |  |
| Region: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas |  | $ | 5,052 |  |  | $ | 24 |  |  | $ | 12,548 |  |  | $ | 47 |  |
| Asia Pacific |  |  | 2,308 |  |  |  | 7,278 |  |  |  | 3,115 |  |  |  | 10,873 |  |
| EMEA |  |  | 209 |  |  |  | 5 |  |  |  | 835 |  |  |  | 65 |  |
| Total |  | $ | 7,569 |  |  | $ | 7,307 |  |  | $ | 16,498 |  |  | $ | 10,985 |  |


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001437749-19-021592:notes:93]
[same as prior period, unchanged from 0001437749-19-015632:notes:87]

[0001437749-19-021592:notes:94]
[same as prior period, unchanged from 0001437749-19-015632:notes:88]

[0001437749-19-021592:notes:95]
[same as prior period, unchanged from 0001437749-19-015632:notes:89]

[0001437749-19-021592:notes:96]
|  |  | Three Months Ended September 30, |  |  | Six Months Ended September 30, |  |
|  |  | 2019 |  |  | 2018 |  |  | 2019 |  |  | 2018 |  |
| Cost of revenues |  | $ | 21 |  |  | $ | 50 |  |  | $ | 24 |  |  | $ | 90 |  |
| Research and development |  |  | 92 |  |  |  | 70 |  |  |  | 103 |  |  |  | 121 |  |
| Selling, general and administrative |  |  | 283 |  |  |  | 705 |  |  |  | 519 |  |  |  | 1,399 |  |
| Total |  | $ | 397 |  |  | $ | 825 |  |  | $ | 646 |  |  | $ | 1,610 |  |

[0001437749-19-021592:notes:97]
[same as prior period, unchanged from 0001437749-19-015632:notes:91]

[0001437749-19-021592:notes:98]
[same as prior period, unchanged from 0001437749-19-015632:notes:92]

[0001437749-19-021592:notes:99]
[same as prior period, unchanged from 0001437749-19-015632:notes:93]

[0001437749-19-021592:notes:100]
170,500

[0001437749-19-021592:notes:101]
[same as prior period, unchanged from 0001437749-19-015632:notes:95]

[0001437749-19-021592:notes:102]
and issued

[0001437749-19-021592:notes:103]
37,075

[0001437749-19-021592:notes:104]
413,000

[0001437749-19-021592:notes:105]
[same as prior period, unchanged from 0001437749-19-015632:notes:99]

[0001437749-19-021592:notes:106]
[same as prior period, unchanged from 0001437749-19-015632:notes:100]

[0001437749-19-021592:notes:107]
[same as prior period, unchanged from 0001437749-19-015632:notes:101]

[0001437749-19-021592:notes:108]
[same as prior period, unchanged from 0001437749-19-015632:notes:102]

[0001437749-19-021592:notes:109]
[same as prior period, unchanged from 0001437749-19-015632:notes:103]

[0001437749-19-021592:notes:110]
1.7

[0001437749-19-021592:notes:111]
[same as prior period, unchanged from 0001437749-19-015632:notes:105]

[0001437749-19-021592:notes:112]
3.1

[0001437749-19-021592:notes:113]
[same as prior period, unchanged from 0001437749-19-015632:notes:107]

[0001437749-19-021592:notes:114]
1.4

[0001437749-19-021592:notes:115]
[same as prior period, unchanged from 0001437749-19-015632:notes:109]

[0001437749-19-021592:notes:116]
[same as prior period, unchanged from 0001437749-19-015632:notes:110]

[0001437749-19-021592:notes:117]
[same as prior period, unchanged from 0001437749-19-015632:notes:111]

[0001437749-19-021592:notes:118]
[same as prior period, unchanged from 0001437749-19-015632:notes:112]

[0001437749-19-021592:notes:119]
.  The Company did 
not
 grant any stock options during the 
three
 months ended

[0001437749-19-021592:notes:120]
or the

[0001437749-19-021592:notes:121]
[same as prior period, unchanged from 0001437749-19-015632:notes:114]

[0001437749-19-021592:notes:122]
[same as prior period, unchanged from 0001437749-19-015632:notes:115]

[0001437749-19-021592:notes:123]
[same as prior period, unchanged from 0001437749-19-015632:notes:116]

[0001437749-19-021592:notes:124]
[same as prior period, unchanged from 0001437749-19-015632:notes:117]

[0001437749-19-021592:notes:125]
|  |  | Three Months Ended September 30, |  |  | Six Months Ended September 30, |  |
|  |  | 2019 |  |  | 2018 |  |  | 2019 |  |  | 2018 |  |
| Expected volatility |  |  | N/A |  |  |  | N/A |  |  |  | 66.5 | % |  |  | N/A |  |
| Risk-free interest rate |  |  | N/A |  |  |  | N/A |  |  |  | 1.8 | % |  |  | N/A |  |
| Expected life (years) |  |  | N/A |  |  |  | N/A |  |  |  | 5.91 |  |  |  | N/A |  |
| Dividend yield |  | N/A |  |  |  | N/A |  |  | None |  |  |  | N/A |  |


## us-gaap:EarningsPerShareTextBlock

[0001437749-19-021592:notes:126]
[same as prior period, unchanged from 0001437749-19-015632:notes:119]

[0001437749-19-021592:notes:127]
Basic net loss per share (“EPS”) is computed by dividing net loss by the weighted-average number of common shares outstanding for the period. Where applicable, diluted EPS is computed by dividing the net loss by the weighted-average number of common shares and dilutive common equivalent shares outstanding during the period, calculated using the treasury stock method. Common equivalent shares include the effect of restricted stock, exercise of stock options and warrants and contingently issuable shares. Stock options and warrants that are out-of-the-money with exercise prices greater than the average market price of the underlying common shares and shares of performance based restricted stock where the contingency was 
not
 met are excluded from the computation of diluted EPS as the effect of their inclusion would be anti-dilutive. For both the 
three
 and

[0001437749-19-021592:notes:128]
[same as prior period, unchanged from 0001437749-19-015632:notes:121]

[0001437749-19-021592:notes:129]
[same as prior period, unchanged from 0001437749-19-015632:notes:124]

[0001437749-19-021592:notes:130]
million shares related to stock options were 
not
 included in the calculation of diluted EPS as they were considered anti-dilutive. For the 
three
 months ended

[0001437749-19-021592:notes:131]
, 
1.6
 million shares were 
not
 included in the calculation of diluted EPS as they were considered anti-dilutive, of which 
0.3
 million relate to outstanding stock options, 
0.9
 million relate to outstanding warrants and 
0.4
 million relate to outstanding unvested stock awards. For the

[0001437749-19-021592:notes:132]
, 
1.4
 million shares were 
not
 included in the calculation of diluted EPS as they were considered anti-dilutive, of which 
0.2
 million shares relate to outstanding stock options, 
0.9
 million shares relate to outstanding warrants and 
0.3
 million relate to outstanding unvested stock awards.

[0001437749-19-021592:notes:133]
[same as prior period, unchanged from 0001437749-19-015632:notes:129]

[0001437749-19-021592:notes:134]
[same as prior period, unchanged from 0001437749-19-015632:notes:130]

[0001437749-19-021592:notes:135]
|  |  | Three Months Ended September 30, |  |  | Six Months Ended September 30, |  |
|  |  | 2019 |  |  | 2018 |  |  | 2019 |  |  | 2018 |  |
| Numerator: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net (loss) income |  | $ | (825 | ) |  | $ | 22,558 |  |  | $ | (4,364 | ) |  | $ | 17,821 |  |
| Less: decrease in fair value of warrants, net of income tax |  |  | (1,145 | ) |  |  | 0 |  |  |  | (4,092 | ) |  |  | 0 |  |
| Plus: change in fair value due to exercise of warrants |  |  | 0 |  |  |  | 0 |  |  |  | 83 |  |  |  | 0 |  |
| Net income (loss) - diluted |  | $ | (1,970 | ) |  | $ | 22,558 |  |  | $ | (8,373 | ) |  | $ | 17,821 |  |
| Denominator: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Weighted-average shares of common stock outstanding |  |  | 21,678 |  |  |  | 21,252 |  |  |  | 21,538 |  |  |  | 21,126 |  |
| Weighted-average shares subject to repurchase |  |  | (1,022 | ) |  |  | (939 | ) |  |  | (952 | ) |  |  | (886 | ) |
| Shares used in per-share calculation ― basic |  |  | 20,656 |  |  |  | 20,313 |  |  |  | 20,586 |  |  |  | 20,240 |  |
| Common stock awards |  |  | 0 |  |  |  | 268 |  |  |  | 0 |  |  |  | 320 |  |
| Common stock warrants |  |  | 67 |  |  |  | 0 |  |  |  | 150 |  |  |  | 0 |  |
| Shares used in per-share calculation ― diluted |  |  | 20,723 |  |  |  | 20,581 |  |  |  | 20,736 |  |  |  | 20,560 |  |
| Net (loss) income per share ― basic |  | $ | (0.04 | ) |  | $ | 1.11 |  |  | $ | (0.21 | ) |  | $ | 0.88 |  |
| Net (loss) income per share ― diluted |  | $ | (0.10 | ) |  | $ | 1.10 |  |  | $ | (0.40 | ) |  | $ | 0.87 |  |

[0001437749-19-021592:notes:136]
For the 
three
 and 
six
 months ended 
 September 30, 2019, 
the diluted net loss per common share amounts under the treasury stock method were calculated based on the dilutive effect of the total number of shares of common stock related to the Hudson Warrant of

[0001437749-19-021592:notes:137]
818,181

[0001437749-19-021592:notes:138]
shares with an exercise price of 
$
7.81
.
  For the 
three
 and 
six
 month periods ended 
 September 30, 2019, 
the average stock price was 
$8.50
 and 
$9.56
 respectively, providing 
66,638
 and 
150,025
 dilutive shares respectively, for the Hudson Warrant. The decrease in the fair value of the warrant liability of 
$1.1
 million and 
$4.1
 million, respectively, is included in the net loss available to common shareholders for the diluted net loss per common share amount when the impact is dilutive.


## us-gaap:FairValueDisclosuresTextBlock

[0001437749-19-021592:notes:139]
[same as prior period, unchanged from 0001437749-19-015632:notes:132]

[0001437749-19-021592:notes:140]
[same as prior period, unchanged from 0001437749-19-015632:notes:133]

[0001437749-19-021592:notes:141]
[same as prior period, unchanged from 0001437749-19-015632:notes:134]

[0001437749-19-021592:notes:142]
[same as prior period, unchanged from 0001437749-19-015632:notes:135]

[0001437749-19-021592:notes:143]
[same as prior period, unchanged from 0001437749-19-015632:notes:136]

[0001437749-19-021592:notes:144]
[same as prior period, unchanged from 0001437749-19-015632:notes:137]

[0001437749-19-021592:notes:145]
|  |  | Total Carrying Value |  |  | Quoted Prices in Active Markets (Level 1) |  |  | Significant Other Observable Inputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |
| September 30, 2019: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash equivalents |  | $ | 49,034 |  |  | $ | 49,034 |  |  | $ | — |  |  | $ | — |  |
| Marketable securities |  | $ | 10,000 |  |  | $ | 10,000 |  |  | $ | — |  |  | $ | — |  |
| Derivative liabilities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Warrants |  | $ | 556 |  |  | $ | — |  |  | $ | — |  |  | $ | 556 |  |

[0001437749-19-021592:notes:146]
[same as prior period, unchanged from 0001437749-19-015632:notes:139]

[0001437749-19-021592:notes:147]
[same as prior period, unchanged from 0001437749-19-015632:notes:140]

[0001437749-19-021592:notes:148]
|  |  | Warrants |  |
| April 1, 2019 |  | $ | 4,942 |  |
| Mark to market adjustment |  |  | (4,092 | ) |
| Warrant exercise |  |  | (294 | ) |
| Balance at September 30, 2019 |  | $ | 556 |  |

[0001437749-19-021592:notes:149]
|  |  | Warrants |  |
| April 1, 2018 |  | $ | 1,217 |  |
| Mark to market adjustment |  |  | 182 |  |
| Balance at September 30, 2018 |  | $ | 1,399 |  |

[0001437749-19-021592:notes:150]
[same as prior period, unchanged from 0001437749-19-015632:notes:143]

[0001437749-19-021592:notes:151]
[same as prior period, unchanged from 0001437749-19-015632:notes:144]

[0001437749-19-021592:notes:152]
Cash equivalents consist of highly liquid instruments with maturities of 
three
 months or less that are regarded as high quality, low risk investments, are measured using such inputs as quoted prices and are classified within Level 
1
 of the valuation hierarchy. Cash equivalents consist principally of certificates of deposits and money market accounts.

[0001437749-19-021592:notes:153]
Marketable Securities

[0001437749-19-021592:notes:154]
Marketable securities consist of certificates of deposit with maturities of greater than 
12
 months that are measured using such inputs as quoted prices and are classified within Level 
1
 of the valuation hierarchy. The Company determines the appropriate classification of its marketable securities at the time of purchase and re-evaluates such classification as of each balance sheet date.  All marketable securities are considered available for sale and are carried at fair value.  The Company periodically reviews the realizability of each short and long term marketable security when impairment indicators exist with respect to the security.  If other than temporary impairment of value of the security exists, the carrying value of the security is written down to its estimated fair value.

[0001437749-19-021592:notes:155]
[same as prior period, unchanged from 0001437749-19-015632:notes:146]

[0001437749-19-021592:notes:156]
[same as prior period, unchanged from 0001437749-19-015632:notes:147]

[0001437749-19-021592:notes:157]
[same as prior period, unchanged from 0001437749-19-015632:notes:148]


## us-gaap:GoodwillDisclosureTextBlock

[0001437749-19-021592:notes:158]
[same as prior period, unchanged from 0001437749-19-015632:notes:149]

[0001437749-19-021592:notes:159]
[same as prior period, unchanged from 0001437749-19-015632:notes:150]

[0001437749-19-021592:notes:160]
[same as prior period, unchanged from 0001437749-19-015632:notes:151]


## us-gaap:IncomeTaxDisclosureTextBlock

[0001437749-19-021592:notes:161]
[same as prior period, unchanged from 0001437749-19-015632:notes:152]

[0001437749-19-021592:notes:162]
The Company recorded an income tax benefit of $

[0001437749-19-021592:notes:163]
0.3

[0001437749-19-021592:notes:164]
million and expense of 
$3.0
 million in the 
three
 months ended

[0001437749-19-021592:notes:165]
, respectively.  The Company recorded an income tax benefit of $

[0001437749-19-021592:notes:166]
million and expense of 
$3.0
 million in the

[0001437749-19-021592:notes:167]
Accounting for income taxes requires a 
two
-step approach to recognizing and measuring uncertain tax positions.  The 
first
 step is to evaluate the tax position for recognition by determining if, based on the technical merits, it is more likely than 
not
 the position will be sustained upon audit, including resolution of related appeals or litigation processes, if any.  The 
second
 step is to measure the tax benefit as the largest amount that is more than 
50%
 likely to be realized upon ultimate settlement.  The Company re-evaluates these uncertain tax positions on a quarterly basis.  The evaluation is based on factors including, but 
not
 limited to, changes in facts or circumstances, changes in tax law, effectively settled issues under audit and new audit activity.  Any changes in these factors could result in the recognition of a tax benefit or an additional charge to the tax provision.  The Company did 
not
 identify any uncertain tax positions in the

[0001437749-19-021592:notes:168]
[same as prior period, unchanged from 0001437749-19-015632:notes:157]


## us-gaap:InventoryDisclosureTextBlock

[0001437749-19-021592:notes:169]
[same as prior period, unchanged from 0001437749-19-015632:notes:158]

[0001437749-19-021592:notes:170]
[same as prior period, unchanged from 0001437749-19-015632:notes:159]

[0001437749-19-021592:notes:171]
|  |  | September 30, 2019 |  |  | March 31, 2019 |  |
| Raw materials |  | $ | 7,421 |  |  | $ | 5,474 |  |
| Work-in-process |  |  | 1,943 |  |  |  | 1,922 |  |
| Finished goods |  |  | 3,981 |  |  |  | 4,405 |  |
| Deferred program costs |  |  | 2,152 |  |  |  | 318 |  |
| Net inventory |  | $ | 15,497 |  |  | $ | 12,119 |  |

[0001437749-19-021592:notes:172]
[same as prior period, unchanged from 0001437749-19-015632:notes:161]

[0001437749-19-021592:notes:173]
million and 
$0.4
 million for the 
three
 months ended

[0001437749-19-021592:notes:174]
, respectively.  The Company recorded inventory write-downs of $

[0001437749-19-021592:notes:175]
million and 
$0.5
 million for the

[0001437749-19-021592:notes:176]
[same as prior period, unchanged from 0001437749-19-015632:notes:163]

[0001437749-19-021592:notes:177]
[same as prior period, unchanged from 0001437749-19-015632:notes:164]

[0001437749-19-021592:notes:178]
[same as prior period, unchanged from 0001437749-19-015632:notes:165]


## us-gaap:LeaseCostTableTextBlock

[0001437749-19-021592:notes:179]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | September 30, 2019 |  |  | September 30, 2019 |  |
| Operating Lease: |  |  |  |  |  |  |  |  |
| Operating lease costs - fixed |  | $ | 178 |  |  | $ | 356 |  |
| Operating lease costs - variable |  |  | 27 |  |  |  | 46 |  |
| Short-term lease costs |  |  | 176 |  |  |  | 214 |  |
| Total lease costs |  |  | 381 |  |  |  | 616 |  |


## us-gaap:LesseeOperatingLeaseLiabilityMaturityTableTextBlock

[0001437749-19-021592:notes:180]
|  |  | Operating Leases |  |
| Year ended March 31, |  |  |  |  |
| 2020 |  | $ | 331 |  |
| 2021 |  |  | 670 |  |
| 2022 |  |  | 650 |  |
| 2023 |  |  | 624 |  |
| 2024 |  |  | 562 |  |
| Thereafter |  |  | 1,896 |  |
| Total minimum lease payments |  |  | 4,733 |  |
| Less: interest |  |  | (1,069 | ) |
| Present value of lease liabilities |  |  | 3,664 |  |


## us-gaap:LesseeOperatingLeasesTextBlock

[0001437749-19-021592:notes:181]
[same as prior period, unchanged from 0001437749-19-015632:notes:168]

[0001437749-19-021592:notes:182]
[same as prior period, unchanged from 0001437749-19-015632:notes:169]

[0001437749-19-021592:notes:183]
Leases (Topic 
842
)
 ("ASC 
842"
), using the modified retrospective approach. The Company elected the package of practical expedients available in the standard and as a result, did 
not
 reassess the lease classification of existing contracts or leases or the initial direct costs associated with existing leases. The Company did 
not
 elect the hindsight practical expedient and evaluated lease terms for existing leases. The Company has also elected the practical expedient to 
not
 separate lease components and non-lease components and will account for the leases as a single lease component for all classes of leases.

[0001437749-19-021592:notes:184]
[same as prior period, unchanged from 0001437749-19-015632:notes:171]

[0001437749-19-021592:notes:185]
[same as prior period, unchanged from 0001437749-19-015632:notes:172]

[0001437749-19-021592:notes:186]
|  |  | March 31, 2019 |  |  | ASC 842 Adjustment |  |  | April 1, 2019 |  |
| Operating Leases: |  |  |  |  |  |  |  |  |  |  |  |  |
| Right of use asset |  | $ | — |  |  | $ | 3,795 |  |  | $ | 3,795 |  |
| Total operating lease right-of-use asset |  |  | — |  |  |  | 3,795 |  |  |  | 3,795 |  |
| Operating lease liabilities – ST |  | $ | — |  |  | $ | 309 |  |  | $ | 309 |  |
| Operating lease liabilities – LT |  |  | — |  |  |  | 3,512 |  |  |  | 3,512 |  |
| Total operating lease liabilities |  |  | — |  |  |  | 3,821 |  |  |  | 3,821 |  |
| Weighted-average remaining lease term |  |  |  |  |  |  |  |  |  | 7.69 years |  |
| Weighted-average discount rate |  |  |  |  |  |  |  |  |  |  | 7.06 | % |

[0001437749-19-021592:notes:187]
[same as prior period, unchanged from 0001437749-19-015632:notes:174]

[0001437749-19-021592:notes:188]
[same as prior period, unchanged from 0001437749-19-015632:notes:175]

[0001437749-19-021592:notes:189]
[same as prior period, unchanged from 0001437749-19-015632:notes:176]

[0001437749-19-021592:notes:190]
[same as prior period, unchanged from 0001437749-19-015632:notes:177]

[0001437749-19-021592:notes:191]
Supplemental balance sheet information related to leases at

[0001437749-19-021592:notes:192]
The costs related to the Company's leases for the

[0001437749-19-021592:notes:193]
[same as prior period, unchanged from 0001437749-19-015632:notes:182]


## us-gaap:NewAccountingPronouncementsAndChangesInAccountingPrinciplesTextBlock

[0001437749-19-021592:notes:194]
18.
 Recent Accounting Pronouncements

[0001437749-19-021592:notes:195]
In 
 February 2016, 
the FASB issued ASU 
2016
-
02,

[0001437749-19-021592:notes:196]
Leases (Topic 
842
)
. The guidance in this ASU supersedes the leasing guidance in Topic 
840,

[0001437749-19-021592:notes:197]
Leases
. Under the new guidance, lessees are required to recognize lease assets and lease liabilities on the balance sheet for all leases with terms longer than 
12
 months. Leases will be classified as either finance or operating, with classification affecting the pattern of expense recognition in the income statement. This ASU and its amendments are effective for fiscal years beginning after 
 December 15, 2018, 
including interim periods within those fiscal years.

[0001437749-19-021592:notes:198]
|  | • | In July 2018, the FASB issued ASU 2018-10, Codification improvements to Topic 842, Leases. The amendments in ASU 2018-10 provide more clarification in regards to the application and requirements of ASU 2016-02. |

[0001437749-19-021592:notes:199]
|  | • | In July 2018, the FASB issued ASU 2018-11, Topic 842, Leases - Targeted improvements. The amendments in ASU 2018-11 provide for the option to adopt the standard prospectively and recognize a cumulative-effect adjustment to the opening balance of retained earnings as well as offer a new practical expedient that will allow the Company to elect, by class of underlying asset, to not separate non-lease and lease components in certain circumstances and instead to account for those components as a single item. |

[0001437749-19-021592:notes:200]
ASU 
2016
-
02
 became effective on 
 April 1, 2019, 
and the Company adopted the standard using the modified retrospective transition method, which impacted all leases existing at, or entered into after, the period of adoption. For all leases existing at the time of adoption the Company recognized a right-of-use asset and lease liability on the balance sheet.  See Note 
14
 "Leases" for additional information.

[0001437749-19-021592:notes:201]
In 
 June 2016, 
the FASB issued ASU 
2016
-
13,

[0001437749-19-021592:notes:202]
Financial Instruments-Credit Losses (Topic 
326
): Measurement of Credit Losses on Financial Instruments
. The amendments in ASU 
2016
-
13
 will provide more decision-useful information about the expected credit losses on financial instruments and other commitments to extend credit held by a reporting entity at each reporting date. The ASU is effective for annual reporting periods beginning after 
 December 15, 2019, 
including interim periods within that year.  The Company is currently evaluating the impact, if any, the adoption of ASU 
2016
-
13

[0001437749-19-021592:notes:203]
may 
have on its consolidated financial statements.

[0001437749-19-021592:notes:204]
In 
 July 2017, 
the FASB issued ASU 
2017
-
11,

[0001437749-19-021592:notes:205]
Earnings per Share (Topic

[0001437749-19-021592:notes:206]
260
), 
Distinguishing Liabilities from Equity (Topic 
480
), and Derivatives and Hedging (Topic 
815
)
. The amendments in ASU 
2017
-
11
 provide guidance for freestanding equity-linked financial instruments, such as warrants and conversion options in convertible debt or preferred stock and should 
no
 longer be accounted for as a derivative liability at fair value as a result of the existence of a down round feature. The ASU is effective for annual reporting periods beginning after 
 December 15, 2018, 
including interim periods within those periods. As of 
 April 1, 2019, 
the Company has adopted ASU 
2017
-
11
 and noted 
no
 significant impact on its consolidated financial statements, primarily due to the put option feature within the Company's warrant agreements which requires continued liability classification under ASC 
480.

[0001437749-19-021592:notes:207]
In 
 August 2017, 
the FASB issued ASU 
2017
-
12,

[0001437749-19-021592:notes:208]
Derivatives and Hedging (Topic 
815
): Targeted Improvements to Accounting for Hedging Activities
. The amendments in ASU 
2017
-
12
 provide improved financial reporting of hedging relationships to better portray the economic results of an entity’s risk management activities in its financial statements. In addition, the amendments in this update make certain targeted improvements to simplify the application of the hedge accounting guidance. The ASU is effective for annual reporting periods beginning after 
 December 15, 2018, 
including interim periods within those periods. As of 
 April 1, 2019, 
the Company has adopted ASU 
2017
-
12
 and noted 
no
 significant impact on its consolidated financial statements, primarily due to the fact that there are 
no
 longer any hedging instruments included in its results.

[0001437749-19-021592:notes:209]
In 
 June 2018, 
the FASB issued ASU 
2018
-
08,

[0001437749-19-021592:notes:210]
Not
-For-Profit Entities (Topic 
958
): Clarifying the Scope and the Accounting Guidance for Contributions Received and Contributions Made
.  The amendments in ASU 
2018
-
08
 assist entities in (
1
) evaluating whether transactions should be accounted for as contributions (nonreciprocal transactions) within the scope of Topic 
958,

[0001437749-19-021592:notes:211]
Not
-for-Profit Entities, or as exchange (reciprocal) transactions subject to other guidance and (
2
) determining whether a contribution is conditional.  The ASU is effective for annual reporting periods beginning after 
 December 15, 2018, 
including interim periods within those periods. As of 
 April 1, 2019, 
the Company has adopted ASU 
2018
-
08
 and noted additional disclosures within its revenue footnote to appropriately present the revenue related to its grant revenue.

[0001437749-19-021592:notes:212]
In 
 August 2018, 
the FASB issued ASU 
2018
-
13,

[0001437749-19-021592:notes:213]
Fair Value Measurement (Topic 
820
): Changes to the Disclosure Requirements for Fair Value Measurement
. The amendments in ASU 
2018
-
13
 provide for increased effectiveness of the disclosures made around fair value measurements while including consideration for costs and benefits. The ASU is effective for annual reporting periods beginning after 
 December 15, 2019, 
including interim periods within those periods. The Company is currently evaluating the impact the adoption of ASU 
2018
-
13


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0001437749-19-021592:notes:214]
[same as prior period, unchanged from 0001437749-19-015632:notes:203]

[0001437749-19-021592:notes:215]
American Superconductor Corporation (together with its subsidiaries, “AMSC®” or the “Company”) was founded on 
 April


## us-gaap:PropertyPlantAndEquipmentDisclosureTextBlock

[0001437749-19-021592:notes:216]
[same as prior period, unchanged from 0001437749-19-015632:notes:204]

[0001437749-19-021592:notes:217]
The cost and accumulated depreciation of property, plant and equipment at

[0001437749-19-021592:notes:218]
[same as prior period, unchanged from 0001437749-19-015632:notes:206]

[0001437749-19-021592:notes:219]
|  |  | September 30, 2019 |  |  | March 31, 2019 |  |
| Construction in progress - equipment |  | $ | 2,223 |  |  | $ | 603 |  |
| Equipment and software |  |  | 45,127 |  |  |  | 45,705 |  |
| Furniture and fixtures |  |  | 1,259 |  |  |  | 1,269 |  |
| Leasehold improvements |  |  | 1,976 |  |  |  | 1,955 |  |
| Property, plant and equipment, gross |  |  | 50,585 |  |  |  | 49,532 |  |
| Less accumulated depreciation |  |  | (41,975 | ) |  |  | (40,560 | ) |
| Property, plant and equipment, net |  | $ | 8,610 |  |  | $ | 8,972 |  |

[0001437749-19-021592:notes:220]
[same as prior period, unchanged from 0001437749-19-015632:notes:208]

[0001437749-19-021592:notes:221]
1.0

[0001437749-19-021592:notes:222]
million and 
$1.1
 million for the 
three
 months ended

[0001437749-19-021592:notes:223]
, respectively. Depreciation expense was $

[0001437749-19-021592:notes:224]
2.1

[0001437749-19-021592:notes:225]
million and 
$2.1
 million for the

[0001437749-19-021592:notes:226]
[same as prior period, unchanged from 0001437749-19-015632:notes:211]


## us-gaap:ReconciliationOfAssetsFromSegmentToConsolidatedTextBlock

[0001437749-19-021592:notes:227]
|  |  | September 30, 2019 |  |  | March 31, 2019 |  |
| Grid |  | $ | 34,479 |  |  | $ | 31,075 |  |
| Wind |  |  | 12,474 |  |  |  | 8,167 |  |
| Corporate assets |  |  | 70,490 |  |  |  | 80,088 |  |
| Total |  | $ | 117,443 |  |  | $ | 119,330 |  |


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001437749-19-021592:notes:228]
[same as prior period, unchanged from 0001437749-19-015632:notes:213]

[0001437749-19-021592:notes:229]
[same as prior period, unchanged from 0001437749-19-015632:notes:214]

[0001437749-19-021592:notes:230]
[same as prior period, unchanged from 0001437749-19-015632:notes:215]

[0001437749-19-021592:notes:231]
[same as prior period, unchanged from 0001437749-19-015632:notes:216]

[0001437749-19-021592:notes:232]
The 
$0.4
 million charged to operations in the

[0001437749-19-021592:notes:233]
[same as prior period, unchanged from 0001437749-19-015632:notes:218]

[0001437749-19-021592:notes:234]
[same as prior period, unchanged from 0001437749-19-015632:notes:219]

[0001437749-19-021592:notes:235]
|  |  | Severance pay |  |  | Facility exit and |  |  |  |  |  |
|  |  | and benefits |  |  | Relocation costs |  |  | Total |  |
| Accrued restructuring balance at April 1, 2018 |  | $ | 262 |  |  | $ | 173 |  |  | $ | 435 |  |
| Charges to operations |  |  | — |  |  |  | 403 |  |  |  | 403 |  |
| Cash payments |  |  | (173 | ) |  |  | (576 | ) |  |  | (749 | ) |
| Accrued restructuring balance at September 30, 2018 |  | $ | 89 |  |  | $ | — |  |  | $ | 89 |  |

[0001437749-19-021592:notes:236]
All restructuring charges discussed above are included within restructuring in the Company’s unaudited condensed consolidated statements of operations. The Company includes accrued restructuring within accounts payable and accrued expenses.  There was 
no
 restructuring activity in the

[0001437749-19-021592:notes:237]
months ending

[0001437749-19-021592:notes:238]
or any remaining accrued restructuring balance as of


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001437749-19-021592:notes:239]
[same as prior period, unchanged from 0001437749-19-015632:notes:222]

[0001437749-19-021592:notes:240]
[same as prior period, unchanged from 0001437749-19-015632:notes:223]

[0001437749-19-021592:notes:241]
[same as prior period, unchanged from 0001437749-19-015632:notes:224]

[0001437749-19-021592:notes:242]
[same as prior period, unchanged from 0001437749-19-015632:notes:225]

[0001437749-19-021592:notes:243]
The Company’s revenues in its Grid segment are derived primarily through enabling the transmission and distribution of power, providing planning services that allow it to identify power grid needs and risks, and developing ship protection systems for the U.S. Navy. The Company’s revenues in its Wind segment are derived primarily through supplying advanced power electronics and control systems, licensing its highly engineered wind turbine designs, and providing extensive customer support services to wind turbine manufacturers. The Company records revenue based on a 
five
-step model in accordance with ASC 
606.
 For its customer contracts, the Company identifies the performance obligations, determines the transaction price, allocates the contract transaction price to the performance obligations, and recognizes the revenue when (or as) control of goods or services is transferred to the customer. In both the

[0001437749-19-021592:notes:244]
77

[0001437749-19-021592:notes:245]
[same as prior period, unchanged from 0001437749-19-015632:notes:228]

[0001437749-19-021592:notes:246]
In the Company's equipment and system product line, each contract with a customer summarizes each product sold to a customer, which typically represent distinct performance obligations. A contract's transaction price is allocated to each distinct performance obligation using the respective standalone selling price which is determined primarily using the cost-plus expected margin approach and recognized as revenue when, or as, the performance obligation is satisfied. The majority of the Company’s product sales transfer control to the customer in line with the contracted delivery terms and revenue is recorded at the point in time when title and risk transfer to the customer, as the Company has determined that this is the point in time that control transfers to the customer.

[0001437749-19-021592:notes:247]
The Company's equipment and system product line includes certain contracts which do 
not
 meet the requirements of an exchange transaction and therefore do 
not
 fall within the scope of ASC 
606.
  As these non-exchange transaction contracts are considered grant revenue and do 
not
 fall within any specific accounting literature, the Company follows guidance within ASC 
606
 by analogy to recognize grant revenue over time.  In the

[0001437749-19-021592:notes:248]
three
 and 
six
 months ended 
 September 30, 2019

[0001437749-19-021592:notes:249]
, the Company recorded 
$0.7
 million and 
$1.1
 million in grant revenue, respectively, which is included in the Company’s Grid revenue. There was 
no
 grant revenue in the

[0001437749-19-021592:notes:250]
In the Company's service and technology development product line, there are several different types of transactions and each begins with a contract with a customer that summarizes each product sold to a customer, which typically represents distinct performance obligations. The technology development transactions are primarily for activities that have 
no
 alternative use and for which a profit can be expected throughout the life of the contract. In these cases, the revenue is recognized over time, but in the instances where the profit cannot be assured throughout the entire contract then the revenue is recognized at a point in time. Each contract's transaction price is allocated to each distinct performance obligation using the respective standalone selling price which is determined primarily using the cost-plus expected margin approach. The ongoing service transactions are for service contracts that provide benefit to the customer simultaneously as the Company performs its obligations, and therefore this revenue is recognized ratably over time throughout the effective period of these contracts. The transaction prices on these contracts are allocated based on an adjusted market approach which is re-assessed annually for reasonableness. The field service transactions include contracts for delivery of goods and completion of services made at the customer's requests, which are 
not
 deemed satisfied until the work has been completed and/or the requested goods have been delivered, so all of this revenue is recognized at the point in time when the control changes, and at allocated prices based on the adjusted market approach driven by standard price lists. The royalty transactions are related to certain contract terms on transactions in the Company's equipment and systems product line based on activity as specified in the contracts. The transaction prices of these agreements are calculated based on an adjusted market approach as specified in the contract. The Company reports royalty revenue for usage-based royalties when the sales have occurred. In circumstances when collectability is 
not
 assured and a contract does 
not
 exist under ASC 
606,
 revenue is deferred until a non-refundable payment has been received for substantially all the amount that is due and there are 
no
 further remaining performance obligations.

[0001437749-19-021592:notes:251]
The Company's service contracts can include a purchase order from a customer for specific goods in which each item is a distinct performance obligation satisfied at a point in time at which control of the goods is transferred to the customer.  This transfer occurs based on the contracted delivery terms or when the requested service work has been completed. The transaction price for these goods is allocated based on the adjusted market approach considering similar transactions under similar circumstances. Service contracts are also derived from ongoing maintenance contracts and extended service-type warranty contracts. In these transactions, the Company is contracted to provide an ongoing service over a specified period of time. As the customer is consuming the benefits as the service is being provided, the revenue is recognized over time ratably.

[0001437749-19-021592:notes:252]
[same as prior period, unchanged from 0001437749-19-015632:notes:233]

[0001437749-19-021592:notes:253]
The Company provides assurance-type warranties on all product sales for a term of typically 
one
 to 
two
 years, and extended service-type warranties at the customer's option for an additional term ranging up to 
four
 additional years. The Company accrues for the estimated warranty costs for assurance warranties at the time of sale based on historical warranty experience plus any known or expected changes in warranty exposure. For all extended service-type warranties, the Company recognizes the revenue ratably over time during the effective period of the services.

[0001437749-19-021592:notes:254]
The Company records revenue net of sales tax, value added tax, excise tax and other taxes collected concurrent with revenue-producing activities. The Company has elected to recognize the cost for freight and shipping when control over the products sold passes to customers and revenue is recognized. The Company has elected to recognize incremental costs of obtaining a contract as expense when incurred except in contracts where the amortization period would exceed 
twelve
 months; in such cases the long-term amount will be assessed for materiality. The Company has elected to 
not
 adjust the promised amount of consideration for the effects of a significant financing component if the period of financing is 
twelve
 months or less.

[0001437749-19-021592:notes:255]
[same as prior period, unchanged from 0001437749-19-015632:notes:236]

[0001437749-19-021592:notes:256]
[same as prior period, unchanged from 0001437749-19-015632:notes:237]

[0001437749-19-021592:notes:257]
, and

[0001437749-19-021592:notes:258]
, the Company’s contract assets and liabilities primarily relate to the timing differences between cash received from a customer in connection with contractual rights to invoicing and the timing of revenue recognition following completion of performance obligations. The Company's accounts receivable balance is made up entirely of customer contract related balances. Changes in the Company’s contract assets, which are included in “Unbilled Accounts Receivable” and “Deferred program costs” (see Note 
7,
 “Accounts Receivable” and Note 
8,
 “Inventory” for a reconciliation to the condensed consolidated balance sheets) and contract liabilities, which are included in the current portion and long term portion of deferred revenue in the Company’s condensed consolidated balance sheets, are as follows:

[0001437749-19-021592:notes:259]
[same as prior period, unchanged from 0001437749-19-015632:notes:239]

[0001437749-19-021592:notes:260]
[same as prior period, unchanged from 0001437749-19-015632:notes:240]

[0001437749-19-021592:notes:261]
50.4

[0001437749-19-021592:notes:262]
[same as prior period, unchanged from 0001437749-19-015632:notes:242]

[0001437749-19-021592:notes:263]
7.2

[0001437749-19-021592:notes:264]
million of outstanding performance obligations to be recognized over a period of 
thirteen
 to 
sixty
 months. The remaining performance obligations are subject to customer actions and therefore the timing of revenue recognition cannot be reasonably estimated. The 
twelve
-month performance obligations include anticipated shipments to Inox based on the 
twelve
-month rolling forecast provided by Inox on the multi-year supply contract. The quantities specified in any forecast provided by Inox related to the multi-year supply contract are firm and irrevocable for the 
first

[0001437749-19-021592:notes:265]
three
 months of a 
twelve
-month rolling forecast. The timing of the performance obligations beyond the 
twelve
-month forecast provided by Inox are 
not
 determinable and therefore are 
not
 included in the total remaining performance obligations.

[0001437749-19-021592:notes:266]
The following table sets forth customers who represented 
10%
 or more of the Company’s total revenues for

[0001437749-19-021592:notes:267]
[same as prior period, unchanged from 0001437749-19-015632:notes:247]

[0001437749-19-021592:notes:268]
|  |  |  | Three Months Ended |  |  | Six Months Ended |  |
|  | Reportable |  | September 30, |  |  | September 30, |  |
|  | Segment |  | 2019 |  |  | 2018 |  |  | 2019 |  |  | 2018 |  |
| Inox Wind Limited | Wind |  |  | <10% |  |  |  | 45 | % |  |  | 17 | % |  |  | 36 | % |
| Micron Technology | Grid |  |  | <10% |  |  |  | <10% |  |  |  | 14 | % |  |  | <10% |  |
| Vestas | Grid |  |  | <10% |  |  |  | 11 | % |  |  | <10% |  |  |  | 23 | % |
| Quanta Power | Grid |  |  | — | % |  |  | 12 | % |  |  | — | % |  |  | <10% |  |
| Hoffman Construction | Grid |  |  | 25 | % |  |  | — | % |  |  | 12 | % |  |  | — | % |
| M.J. Electric, LLC | Grid |  |  | 25 | % |  |  | — | % |  |  | 13 | % |  |  | — | % |


## us-gaap:ScheduleOfSegmentReportingInformationBySegmentTextBlock

[0001437749-19-021592:notes:269]
|  |  | Three Months Ended September 30, |  |  | Six Months Ended September 30, |  |
|  |  | 2019 |  |  | 2018 |  |  | 2019 |  |  | 2018 |  |
| Revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Grid |  | $ | 11,489 |  |  | $ | 7,569 |  |  | $ | 21,345 |  |  | $ | 16,498 |  |
| Wind |  |  | 2,523 |  |  |  | 7,307 |  |  |  | 6,437 |  |  |  | 10,985 |  |
| Total |  | $ | 14,012 |  |  | $ | 14,876 |  |  | $ | 27,782 |  |  | $ | 27,483 |  |

[0001437749-19-021592:notes:270]
|  |  | Three Months Ended September 30, |  |  | Six Months Ended September 30, |  |
|  |  | 2019 |  |  | 2018 |  |  | 2019 |  |  | 2018 |  |
| Operating (loss) income: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Grid |  | $ | (1,324 | ) |  | $ | (2,870 | ) |  | $ | (5,988 | ) |  | $ | (5,537 | ) |
| Wind |  |  | (2,398 | ) |  |  | 28,515 |  |  |  | (3,721 | ) |  |  | 27,150 |  |
| Unallocated corporate expenses |  |  | (397 | ) |  |  | (918 | ) |  |  | (646 | ) |  |  | (2,013 | ) |
| Total |  | $ | (4,119 | ) |  | $ | 24,727 |  |  | $ | (10,355 | ) |  | $ | 19,600 |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001437749-19-021592:notes:271]
[same as prior period, unchanged from 0001437749-19-015632:notes:251]

[0001437749-19-021592:notes:272]
[same as prior period, unchanged from 0001437749-19-015632:notes:252]

[0001437749-19-021592:notes:273]
[same as prior period, unchanged from 0001437749-19-015632:notes:253]

[0001437749-19-021592:notes:274]
[same as prior period, unchanged from 0001437749-19-015632:notes:254]

[0001437749-19-021592:notes:275]
[same as prior period, unchanged from 0001437749-19-015632:notes:255]

[0001437749-19-021592:notes:276]
[same as prior period, unchanged from 0001437749-19-015632:notes:256]

[0001437749-19-021592:notes:277]
[same as prior period, unchanged from 0001437749-19-015632:notes:257]

[0001437749-19-021592:notes:278]
0.4

[0001437749-19-021592:notes:279]
million and 
$0.8
 million in the 
three
 months ended

[0001437749-19-021592:notes:280]
, respectively, and restructuring charges of 
$0.1
 million in the 
three
 months ended

[0001437749-19-021592:notes:281]
.  Unallocated corporate expenses primarily consist of stock-based compensation expense of $

[0001437749-19-021592:notes:282]
0.6

[0001437749-19-021592:notes:283]
million and 
$1.6
 million in the

[0001437749-19-021592:notes:284]
, respectively, and restructuring charges of 
$0.4
 million in the

[0001437749-19-021592:notes:285]
[same as prior period, unchanged from 0001437749-19-015632:notes:260]


## us-gaap:SubsequentEventsTextBlock

[0001437749-19-021592:notes:286]
19.
 Subsequent Events

[0001437749-19-021592:notes:287]
The Company has performed an evaluation of subsequent events through the time of filing this Quarterly Report on Form 
10
-Q with the SEC and has determined that there are 
no
 such events to report.
