# AMSC note change history — 0001628280-16-020601 → 0001628280-17-000901


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2017-02-06):
[0001628280-17-000901:note_history:1]
As of December 31, 2016, the Company had $0.8 million of restricted cash included in current assets and $0.1 million of restricted cash included in long-term assets. These amounts included in restricted cash primarily represent deposits to secure letters of credit for various supply contracts. These deposits are held in interest bearing accounts.
  (was, 2016-11-02, similarity 0.9897):
[0001628280-16-020601:note_history:1]
As of September 30, 2016, the Company had $0.5 million of restricted cash included in current assets and $0.9 million of restricted cash included in long-term assets. These amounts included in restricted cash primarily represent deposits to secure letters of credit for various supply contracts. These deposits are held in interest bearing accounts.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2017-02-06):
[0001628280-17-000901:note_history:2]
These unaudited condensed consolidated financial statements of the Company have been prepared on a going concern basis in accordance with United States generally accepted accounting principles (“GAAP”) and the Securities and Exchange Commission’s (“SEC”) instructions to Form 10-Q. The going concern basis of presentation assumes that the Company will continue operations and will be able to realize its assets and discharge its liabilities and commitments in the normal course of business. Certain information and footnote disclosures normally included in the financial statements prepared in accordance with GAAP have been condensed or omitted pursuant to those instructions. The year-end condensed balance sheet data was derived from audited financial statements but does not include all disclosures required by GAAP. The unaudited condensed consolidated financial statements, in the opinion of management, reflect all adjustments (consisting of normal recurring adjustments) necessary for a fair statement of the results for the interim periods ended December 31, 2016 and 2015 and the financial position at December 31, 2016.
  (was, 2016-11-02, similarity 0.9937):
[0001628280-16-020601:note_history:2]
These unaudited condensed consolidated financial statements of the Company have been prepared on a going concern basis in accordance with United States generally accepted accounting principles (“GAAP”) and the Securities and Exchange Commission’s (“SEC”) instructions to Form 10-Q. The going concern basis of presentation assumes that the Company will continue operations and will be able to realize its assets and discharge its liabilities and commitments in the normal course of business. Certain information and footnote disclosures normally included in the financial statements prepared in accordance with GAAP have been condensed or omitted pursuant to those instructions. The year-end condensed balance sheet data was derived from audited financial statements but does not include all disclosures required by GAAP. The unaudited condensed consolidated financial statements, in the opinion of management, reflect all adjustments (consisting of normal recurring adjustments) necessary for a fair statement of the results for the interim periods ended September 30, 2016 and 2015 and the financial position at September 30, 2016.

- changed (2017-02-06):
[0001628280-17-000901:note_history:3]
The Company has experienced recurring operating losses and as of December 31, 2016, the Company had an accumulated deficit of $948.6 million. In addition, the Company has experienced recurring negative operating cash flows.  At December 31, 2016, the Company had cash and cash equivalents of $25.1 million. Cash used in operations for the nine months ended December 31, 2016 was $10.5 million.
  (was, 2016-11-02, similarity 0.9235):
[0001628280-16-020601:note_history:3]
The Company has experienced recurring operating losses and as of September 30, 2016, the Company had an accumulated deficit of $945.9 million. In addition, the Company has experienced recurring negative operating cash flows.  At September 30, 2016, the Company had cash and cash equivalents of $25.3 million. Cash used in operations for the six months ended September 30, 2016 was $10.9 million.

- changed (2017-02-06):
[0001628280-17-000901:note_history:4]
From April 1, 2011 through the date of this filing, the Company has reduced its global workforce substantially.  The Company has taken actions to consolidate certain business operations to reduce facility costs.  As of December 31, 2016, the Company had a global workforce of 366 persons.  The Company plans to closely monitor its expenses and, if required, expects to further reduce operating costs and capital spending to enhance liquidity.
  (was, 2016-11-02, similarity 0.9918):
[0001628280-16-020601:note_history:4]
From April 1, 2011 through the date of this filing, the Company has reduced its global workforce substantially.  The Company has taken actions to consolidate certain business operations to reduce facility costs.  As of September 30, 2016, the Company had a global workforce of 366 persons.  The Company plans to closely monitor its expenses and, if required, expects to further reduce operating costs and capital spending to enhance liquidity.

- changed (2017-02-06):
[0001628280-17-000901:note_history:5]
Over the last several years, the Company has entered into several debt and equity financing arrangements in order to enhance liquidity.  Since April 1, 2012, the Company has generated aggregate cash flows from financing activities of $67.3 million.  This amount includes proceeds from an April 2015 equity offering, which generated net proceeds of approximately $22.3 million, after deducting underwriting discounts and commissions and estimated offering expenses payable by the Company.  See Note 9, “Debt”, and Note 11 “Stockholders Equity” for further discussion of these financing arrangements. The Company believes that it is in compliance with the covenants and restrictions included in the agreements governing its debt arrangements as of December 31, 2016.
  (was, 2016-11-02, similarity 0.9953):
[0001628280-16-020601:note_history:5]
Over the last several years, the Company has entered into several debt and equity financing arrangements in order to enhance liquidity.  Since April 1, 2012, the Company has generated aggregate cash flows from financing activities of $68.5 million.  This amount includes proceeds from an April 2015 equity offering, which generated net proceeds of approximately $22.3 million, after deducting underwriting discounts and commissions and estimated offering expenses payable by the Company.  See Note 9, “Debt”, and Note 11 “Stockholders Equity” for further discussion of these financing arrangements. The Company believes that it is in compliance with the covenants and restrictions included in the agreements governing its debt arrangements as of September 30, 2016.

- changed (2017-02-06):
[0001628280-17-000901:note_history:6]
In December 2015, the Company entered into a set of strategic agreements valued at approximately $210.0 million with Inox Wind Ltd. (“Inox”), which includes a multi-year supply contract pursuant to which the Company will supply electric control systems to Inox and a license agreement allowing Inox to manufacture a limited number of electrical control systems over the following three to four years.  After this initial three to four year period, Inox agreed that the Company will continue as Inox’s preferred supplier and Inox will be required to purchase from the Company a majority of its electric control systems requirements for an additional three-year period.  These agreements are expected to provide a foundation for the business as the Company pursues its longer-term objectives.
  (was, 2016-11-02, similarity 0.9916):
[0001628280-16-020601:note_history:6]
In December 2015, the Company entered into a set of strategic agreements valued at approximately $210.0 million with Inox Wind Ltd. (“Inox”), which includes a multi-year supply contract pursuant to which the Company will supply electric control systems to Inox and a license agreement allowing Inox to manufacture a limited number of electrical control systems over the next three to four years.  After this initial three to four year period, Inox agreed that the Company will continue as Inox’s preferred supplier and Inox will be required to purchase from the Company a majority of its electric control systems requirements for an additional three-year period.  These agreements are expected to provide a foundation for the business as the Company pursues its longer-term objectives.

- changed (2017-02-06):
[0001628280-17-000901:note_history:7]
On March 11, 2016, the Company sold 100% of its minority share investment in Tres Amigas LLC ("Tres Amigas") to an investor for $0.6 million.  The Company received $0.3 million according to the terms of the purchase agreement upon closing, which was recorded as a gain during the three months ended March 31, 2016.  The final $0.3 million was received and recorded as a gain during the third quarter of fiscal 2016.  See Note 13, “Minority Investments”, for further information about such investment.
  (was, 2016-11-02, similarity 0.8524):
[0001628280-16-020601:note_history:7]
On March 11, 2016, the Company sold 100% of its minority share investment in Tres Amigas LLC ("Tres Amigas") to an investor for $0.6 million.  The Company received $0.3 million according to the terms of the purchase agreement upon closing, which was recorded as a gain during the three months ended March 31, 2016.  The final $0.3 million is to be paid when Tres Amigas achieves the earlier of certain agreed-upon financing conditions, which is expected to occur during the third quarter of fiscal 2016.  See Note 13, “Minority Investments”, for further information about such investment.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2017-02-06):
[0001628280-17-000901:note_history:8]
On November 15, 2013, the Company amended its existing Loan and Security Agreement with Hercules and entered into a new term loan (the “Term Loan B”), borrowing $10.0 million. After closing fees and expenses, the net proceeds to the Company for the Term Loan B were $9.8 million.  The Term Loan B bears an interest rate of 11% plus the percentage, if any, by which the prime rate as reported by the Wall Street Journal exceeds 3.75%.  The Company repaid the Term Loan B in equal monthly installments ending on November 1, 2016, when the loan was repaid in full.  The Company paid an end of term fee of $0.5 million upon the maturity of the Term Loan B, which had been accrued at inception of the loan with a corresponding amount recorded into the debt discount.  In addition, the Company incurred $0.2 million of legal and origination costs at inception of the loan, which have been recorded as a debt discount.

- added (2017-02-06):
[0001628280-17-000901:note_history:9]
Under Term Loan B, the total debt discount including the Hercules Warrant, end of term fee and legal and origination costs of $1.0 million was amortized into interest expense over the term of the Term Loan B using the effective interest method.  During both the three and nine months ended December 31, 2016, the Company recorded non-cash interest expense for amortization of the debt discount related to the Term Loan B of less than $0.1 million.  During both the three and nine months ended December 31, 2015, the Company recorded non-cash interest expense for amortization of the debt discount related to the Term Loan B of $0.2 million  Under Term Loan C, the total debt discount, including the Hercules Warrant, end of term fee and legal and origination costs of $0.3 million is being amortized into interest expense over the term of the Term Loan C using the effective interest method.  During both the three and nine months ended December 31, 2016 and 2015, the Company recorded non-cash interest expense for amortization of the debt discount related to the Term Loan C of less than $0.1 million.

- changed (2017-02-06):
[0001628280-17-000901:note_history:10]
The Term Loans are secured by substantially all of the Company’s existing and future assets, including a mortgage on real property owned by the Company’s wholly-owned subsidiary, ASC Devens LLC, and located at 64 Jackson Road, Devens, Massachusetts.  The Term Loans contain certain covenants that restrict the Company’s ability to, among other things, incur or assume certain debt, merge or consolidate, materially change the nature of the Company’s business, make certain investments, acquire or dispose of certain assets, make guarantees or grant liens on its assets, make certain loans, advances or investments, declare dividends or make distributions or enter into transactions with affiliates. In addition, there is a covenant that requires the Company to maintain a minimum unrestricted cash balance (the “Minimum Threshold”) in the United States.  As a result of the Company’s April 2015 equity offering, the Minimum Threshold was reduced to the lesser of $2.0 million or the aggregate outstanding principal balance of the Term Loans.  As of December 31, 2016, the Minimum Threshold was $1.5 million.  The events of default under the Term Loans include, but are not limited to, failure to pay amounts due, breaches of covenants, bankruptcy events, cross defaults under other material indebtedness and the occurrence of a material adverse effect and/or change in control. In the case of a continuing event of default, Hercules may, among other remedies, declare due all unpaid principal amounts outstanding and any accrued but unpaid interest and foreclose on all collateral granted to Hercules as security under the Term Loans.
  (was, 2016-11-02, similarity 0.9978):
[0001628280-16-020601:note_history:10]
The Term Loans are secured by substantially all of the Company’s existing and future assets, including a mortgage on real property owned by the Company’s wholly-owned subsidiary, ASC Devens LLC, and located at 64 Jackson Road, Devens, Massachusetts.  The Term Loans contain certain covenants that restrict the Company’s ability to, among other things, incur or assume certain debt, merge or consolidate, materially change the nature of the Company’s business, make certain investments, acquire or dispose of certain assets, make guarantees or grant liens on its assets, make certain loans, advances or investments, declare dividends or make distributions or enter into transactions with affiliates. In addition, there is a covenant that requires the Company to maintain a minimum unrestricted cash balance (the “Minimum Threshold”) in the United States.  As a result of the Company’s April 2015 equity offering, the Minimum Threshold was reduced to the lesser of $2.0 million or the aggregate outstanding principal balance of the Term Loans.  As of September 30, 2016, the Minimum Threshold was $2.0 million.  The events of default under the Term Loans include, but are not limited to, failure to pay amounts due, breaches of covenants, bankruptcy events, cross defaults under other material indebtedness and the occurrence of a material adverse effect and/or change in control. In the case of a continuing event of default, Hercules may, among other remedies, declare due all unpaid principal amounts outstanding and any accrued but unpaid interest and foreclose on all collateral granted to Hercules as security under the Term Loans.

- changed (2017-02-06):
[0001628280-17-000901:note_history:11]
Interest expense on the Term Loans for the three months ended December 31, 2016 and 2015, was $0.1 million and $0.2 million, respectively, each of which included less than $0.1 million of non-cash interest expense related to the amortization of the debt discount on the respective Term Loans.  Interest expense on the Term Loans for the nine months ended December 31, 2016 and 2015, was $0.3 million and $0.8 million, respectively, each of which included $0.1 million and $0.3 million, respectively, of non-cash interest expense related to the amortization of the debt discount on the respective Term Loans
  (was, 2016-11-02, similarity 0.9573):
[0001628280-16-020601:note_history:11]
Interest expense on the Term Loans for the three months ended September 30, 2016 and 2015, was $0.1 million and $0.3 million, respectively, each of which included less than $0.1 million of non-cash interest expense related to the amortization of the debt discount on the respective Term Loans.  Interest expense on the Term Loans for the six months ended September 30, 2016 and 2015, was $0.3 million and $0.6 million, respectively, each of which included $0.1 million and $0.2 million, respectively, of non-cash interest expense related to the amortization of the debt discount on the respective Term Loans

- changed (2017-02-06):
[0001628280-17-000901:note_history:12]
Although the Company believes that it is in compliance with the covenants and restrictions under the Term Loans as of December 31, 2016, there can be no assurance that the Company will continue to be in compliance.
  (was, 2016-11-02, similarity 0.9832):
[0001628280-16-020601:note_history:12]
Although the Company believes that it is in compliance with the covenants and restrictions under the Term Loans as of September 30, 2016, there can be no assurance that the Company will continue to be in compliance.

- removed (2017-02-06):
[0001628280-16-020601:note_history:13]
On November 15, 2013, the Company amended its existing Loan and Security Agreement with Hercules and entered into a new term loan (the “Term Loan B”), borrowing $10.0 million. After closing fees and expenses, the net proceeds to the Company for the Term Loan B were $9.8 million.  The Term Loan B bears an interest rate of 11% plus the percentage, if any, by which the prime rate as reported by the Wall Street Journal exceeds 3.75%.  The Company is repaying the Term Loan B in equal monthly installments ending on November 1, 2016.  The principal balance of the Term Loan B is approximately $0.7 million as of September 30, 2016.  The Company will pay an end of term fee of $0.5 million upon the earlier of maturity or prepayment of the Term Loan B. The Company has accrued the end of term fee and recorded a corresponding amount into the debt discount.  The Term Loan B includes a mandatory prepayment feature which allows Hercules the right to use any of the Company’s net proceeds from specified asset dispositions greater than $1.0 million in a calendar year to pay off any outstanding accrued interest and principal balance on the Term Loan B.  The Company determined the fair value to be de-minimis for this feature. In addition, the Company incurred $0.2 million of legal and origination costs at inception of the loan, which have been recorded as a debt discount.

- removed (2017-02-06):
[0001628280-16-020601:note_history:14]
Under Term Loan B, the total debt discount including the Hercules Warrant, end of term fee and legal and origination costs of $1.0 million is being amortized into interest expense over the term of the Term Loan B using the effective interest method.  During both the three and six months ended September 30, 2016 the Company recorded non-cash interest expense for amortization of the debt discount related to the Term Loan B of less than $0.1 million.  During both the three and six months ended September 30, 2015 the Company recorded non-cash interest expense for amortization of the debt discount related to the Term Loan B of  $0.1 million  Under Term Loan C, the total debt discount, including the Hercules Warrant, end of term fee and legal and origination costs of $0.3 million is being amortized into interest expense over the term of the Term Loan C using the effective interest method.  During both the three and six months ended September 30, 2016 the Company recorded non-cash interest expense for amortization of the debt discount related to the Term Loan C of less than $0.1 million.  During both the three and six months ended September 30, 2015 the Company recorded non-cash interest expense for amortization of the debt discount related to the Term Loan C of less than $0.1 million.


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: tag_name, score: 1.0

- added (2017-02-06):
[0001628280-17-000901:note_history:15]
On January 27, 2017, the Company entered into an At Market Issuance Sales Agreement ("ATM") with FBR Capital Markets & Co ("FBR") under which the Company may, at its discretion, sell up to $10.0 million of its shares of common stock through FBR.  FBR has agreed to use its commercially reasonable efforts to sell the Company’s common stock from time to time, based upon the Company’s instructions (including any price, time or size limits or other customary parameters or conditions the Company may impose).  Sales under the ATM, if any, would be made pursuant to the prospectus supplement dated January 27, 2017, which supplements the prospectus dated October 1, 2014, included in the shelf registration statement that AMSC filed with the Securities and Exchange Commission (“SEC”) on September 19, 2014.

- changed (2017-02-06):
[0001628280-17-000901:note_history:16]
As of the time of filing this Quarterly Report on Form 10-Q with the SEC, and has determined that there are no other such events to report.
  (was, 2016-11-02, similarity 0.7928):
[0001628280-16-020601:note_history:16]
The Company has performed an evaluation of subsequent events through the time of filing this Quarterly Report on Form 10-Q with the SEC, and has determined that there are no such events to report.
