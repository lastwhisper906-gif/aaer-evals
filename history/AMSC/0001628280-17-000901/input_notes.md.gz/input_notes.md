# AMSC notes — 0001628280-17-000901


## us-gaap:AccountsPayableAndAccruedLiabilitiesDisclosureTextBlock

[0001628280-17-000901:notes:1]
[same as prior period, unchanged from 0001628280-16-020601:notes:1]

[0001628280-17-000901:notes:2]
Accounts payable and accrued expenses at December 31, 2016 and March 31, 2016 consisted of the following (in thousands):

[0001628280-17-000901:notes:3]
|  | December 31, 2016 |  | March 31, 2016 |
| Accounts payable | $ | 6,593 |  |  | $ | 5,837 |  |
| Accrued inventories in-transit | 1,259 |  |  | 1,908 |  |
| Accrued other miscellaneous expenses | 1,616 |  |  | 3,003 |  |
| Accrued compensation | 5,074 |  |  | 7,526 |  |
| Income taxes payable | 1,135 |  |  | 1,281 |  |
| Accrued warranty | 2,677 |  |  | 3,601 |  |
| Total | $ | 18,354 |  |  | $ | 23,156 |  |

[0001628280-17-000901:notes:4]
[same as prior period, unchanged from 0001628280-16-020601:notes:4]

[0001628280-17-000901:notes:5]
[same as prior period, unchanged from 0001628280-16-020601:notes:5]

[0001628280-17-000901:notes:6]
|  | Three months ended December 31, |  | Nine months ended December 31, |
|  | 2016 |  | 2015 |  | 2016 |  | 2015 |
| Balance at beginning of period | $ | 2,694 |  |  | $ | 3,273 |  |  | $ | 3,601 |  |  | $ | 3,934 |  |
| Change in accruals for warranties during the period | 591 |  |  | 595 |  |  | 1,009 |  |  | 1,018 |  |
| Settlements during the period | (608 | ) |  | (758 | ) |  | (1,933 | ) |  | (1,842 | ) |
| Balance at end of period | $ | 2,677 |  |  | $ | 3,110 |  |  | $ | 2,677 |  |  | $ | 3,110 |  |


## us-gaap:BasisOfAccountingPolicyPolicyTextBlock

[0001628280-17-000901:notes:7]
These unaudited condensed consolidated financial statements of the Company have been prepared on a going concern basis in accordance with United States generally accepted accounting principles (“GAAP”) and the Securities and Exchange Commission’s (“SEC”) instructions to Form 10-Q. The going concern basis of presentation assumes that the Company will continue operations and will be able to realize its assets and discharge its liabilities and commitments in the normal course of business. Certain information and footnote disclosures normally included in the financial statements prepared in accordance with GAAP have been condensed or omitted pursuant to those instructions. The year-end condensed balance sheet data was derived from audited financial statements but does not include all disclosures required by GAAP. The unaudited condensed consolidated financial statements, in the opinion of management, reflect all adjustments (consisting of normal recurring adjustments) necessary for a fair statement of the results for the interim periods ended December 31, 2016 and 2015 and the financial position at December 31, 2016.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001628280-17-000901:notes:8]
Commitments and Contingencies

[0001628280-17-000901:notes:9]
Legal Contingencies

[0001628280-17-000901:notes:10]
From time to time, the Company is involved in legal and administrative proceedings and claims of various types. The Company records a liability in its consolidated financial statements for these matters when a loss is known or considered probable and the amount can be reasonably estimated. The Company reviews these estimates each accounting period as additional information is known and adjusts the loss provision when appropriate. If a matter is both probable to result in a liability and the amounts of loss can be reasonably estimated, the Company estimates and discloses the possible loss or range of loss to the extent necessary to make the consolidated financial statements not misleading. If the loss is not probable or cannot be reasonably estimated, a liability is not recorded in its consolidated financial statements.

[0001628280-17-000901:notes:11]
On September 13, 2011, the Company commenced a series of legal actions in China against Sinovel Wind Group Co. Ltd. (“Sinovel”). The Company’s Chinese subsidiary, Suzhou AMSC Superconductor Co. Ltd., filed a claim for arbitration with the Beijing Arbitration Commission in accordance with the terms of the Company’s supply contracts with Sinovel. The case is captioned (2011) Jing Zhong An Zi No. 963.  The Company alleges that Sinovel committed various material breaches of its contracts with the Company and  Sinovel has refused to pay past due amounts for prior shipments of core electrical components and spare parts. The Company is seeking compensation for past product shipments and retention (including interest) in the amount of approximately RMB 485 million (approximately $73 million) due to Sinovel’s breaches of its contracts. The Company is also seeking specific performance of its existing contracts as well as reimbursement of all costs and reasonable expenses with respect to the arbitration. The value of the undelivered components under the existing contracts, including the deliveries refused by Sinovel in March 2011, amounts to approximately RMB 4.6 billion (approximately $690 million).

[0001628280-17-000901:notes:12]
On October 8, 2011, Sinovel filed with the Beijing Arbitration Commission an application under the caption (2011) Jing Zhong An Zi No. 963, for a counterclaim against the Company for breach of the same contracts under which the Company filed its original arbitration claim. Sinovel claims, among other things, that the goods supplied by the Company do not conform to the standards specified in the contracts and claims damages in the amount of approximately RMB 1.2 billion (approximately $180 million) upon Sinovel’s requests for change of counterclaim. On February 27, 2012, Sinovel filed with the Beijing Arbitration Commission an application under the caption (2012) Jing Zhong An Zi No. 157, against the Company for breach of the same contracts under which the Company filed its original arbitration claim. Sinovel claims, among other things, that the goods supplied by the Company do not conform to the standards specified in the contracts and claims damages in the amount of approximately RMB 105 million (approximately $16 million). The Company believes that Sinovel’s claims are without merit and it intends to defend these actions vigorously. Since the proceedings in this matter are still in the early technical review phase, the Company cannot reasonably estimate possible losses or range of losses at this time.

[0001628280-17-000901:notes:13]
Other

[0001628280-17-000901:notes:14]
The Company enters into long-term construction contracts with customers that require the Company to obtain performance bonds. The Company is required to deposit an amount equivalent to some or all the face amount of the performance bonds into an escrow account until the termination of the bond. When the performance conditions are met, amounts deposited as collateral for the performance bonds are returned to the Company. In addition, the Company has various contractual arrangements in which minimum quantities of goods or services have been committed to be purchased on an annual basis.

[0001628280-17-000901:notes:15]
As of December 31, 2016, the Company had $0.8 million of restricted cash included in current assets and $0.1 million of restricted cash included in long-term assets. These amounts included in restricted cash primarily represent deposits to secure letters of credit for various supply contracts. These deposits are held in interest bearing accounts.


## us-gaap:DebtDisclosureTextBlock

[0001628280-17-000901:notes:16]
Debt

[0001628280-17-000901:notes:17]
Senior Secured Term Loans

[0001628280-17-000901:notes:18]
On November 15, 2013, the Company amended its existing Loan and Security Agreement with Hercules and entered into a new term loan (the “Term Loan B”), borrowing $10.0 million. After closing fees and expenses, the net proceeds to the Company for the Term Loan B were $9.8 million.  The Term Loan B bears an interest rate of 11% plus the percentage, if any, by which the prime rate as reported by the Wall Street Journal exceeds 3.75%.  The Company repaid the Term Loan B in equal monthly installments ending on November 1, 2016, when the loan was repaid in full.  The Company paid an end of term fee of $0.5 million upon the maturity of the Term Loan B, which had been accrued at inception of the loan with a corresponding amount recorded into the debt discount.  In addition, the Company incurred $0.2 million of legal and origination costs at inception of the loan, which have been recorded as a debt discount.

[0001628280-17-000901:notes:19]
On December 19, 2014, the Company entered into a second amendment with Hercules (the “Hercules Second Amendment”) and entered into a new term loan, borrowing an additional $1.5 million (the “Term Loan C”).  After closing fees and expenses, the net proceeds to the Company for the Term Loan C were $1.4 million.  The Term Loan B and Term Loan C are collectively referred to as the “Term Loans”.  The Term Loan C also bears the same interest rate as the Term Loan B.  The Company will make interest only payments until maturity on June 1, 2017, when the loan is scheduled to be repaid in its entirety.  The maturity date of the Term Loan C was extended from March 1, 2017 to June 1, 2017 due to the Company’s April 2015 equity offering which raised more than $10 million in new capital before December 31, 2015.  The Company will pay an end of term fee of approximately $0.1 million upon earlier of maturity or prepayment of the Term Loan C.  The Company has accrued the end of term fee and recorded a corresponding amount in the debt discount.  The Term Loan C includes the same mandatory prepayment feature as the Term Loan B.   The Company determined the fair value to be de-minimus for this feature.  In addition, the Company incurred approximately $0.1 million of legal and origination costs at inception of the loan, which have been recorded as a debt discount.

[0001628280-17-000901:notes:20]
Hercules received warrants to purchase 13,927 shares of common stock (the “First Warrant”) and 25,641 shares of common stock (the “Second Warrant”) in conjunction with a prior term loan which has been repaid in full and the Term Loan B.  Due to certain adjustment provisions within the warrants, they qualified for liability accounting.  The fair value of the warrants, $0.4 million and $0.2 million, respectively, was recorded upon issuance to debt discount and a warrant liability. In conjunction with the Hercules Second Amendment, the First Warrant and Second Warrant were cancelled and replaced with the issuance of a new warrant (the “Hercules Warrant”) to purchase 58,823 shares of common stock at an exercise price of $11.00 per share, subject to adjustment.  The Hercules Warrant expires on June 30, 2020.  See Note 10, “Warrants and Derivative Liabilities”, for a discussion on the Hercules Warrant and the valuation assumptions used.

[0001628280-17-000901:notes:21]
Under Term Loan B, the total debt discount including the Hercules Warrant, end of term fee and legal and origination costs of $1.0 million was amortized into interest expense over the term of the Term Loan B using the effective interest method.  During both the three and nine months ended December 31, 2016, the Company recorded non-cash interest expense for amortization of the debt discount related to the Term Loan B of less than $0.1 million.  During both the three and nine months ended December 31, 2015, the Company recorded non-cash interest expense for amortization of the debt discount related to the Term Loan B of $0.2 million  Under Term Loan C, the total debt discount, including the Hercules Warrant, end of term fee and legal and origination costs of $0.3 million is being amortized into interest expense over the term of the Term Loan C using the effective interest method.  During both the three and nine months ended December 31, 2016 and 2015, the Company recorded non-cash interest expense for amortization of the debt discount related to the Term Loan C of less than $0.1 million.

[0001628280-17-000901:notes:22]
The Term Loans are secured by substantially all of the Company’s existing and future assets, including a mortgage on real property owned by the Company’s wholly-owned subsidiary, ASC Devens LLC, and located at 64 Jackson Road, Devens, Massachusetts.  The Term Loans contain certain covenants that restrict the Company’s ability to, among other things, incur or assume certain debt, merge or consolidate, materially change the nature of the Company’s business, make certain investments, acquire or dispose of certain assets, make guarantees or grant liens on its assets, make certain loans, advances or investments, declare dividends or make distributions or enter into transactions with affiliates. In addition, there is a covenant that requires the Company to maintain a minimum unrestricted cash balance (the “Minimum Threshold”) in the United States.  As a result of the Company’s April 2015 equity offering, the Minimum Threshold was reduced to the lesser of $2.0 million or the aggregate outstanding principal balance of the Term Loans.  As of December 31, 2016, the Minimum Threshold was $1.5 million.  The events of default under the Term Loans include, but are not limited to, failure to pay amounts due, breaches of covenants, bankruptcy events, cross defaults under other material indebtedness and the occurrence of a material adverse effect and/or change in control. In the case of a continuing event of default, Hercules may, among other remedies, declare due all unpaid principal amounts outstanding and any accrued but unpaid interest and foreclose on all collateral granted to Hercules as security under the Term Loans.

[0001628280-17-000901:notes:23]
Interest expense on the Term Loans for the three months ended December 31, 2016 and 2015, was $0.1 million and $0.2 million, respectively, each of which included less than $0.1 million of non-cash interest expense related to the amortization of the debt discount on the respective Term Loans.  Interest expense on the Term Loans for the nine months ended December 31, 2016 and 2015, was $0.3 million and $0.8 million, respectively, each of which included $0.1 million and $0.3 million, respectively, of non-cash interest expense related to the amortization of the debt discount on the respective Term Loans

[0001628280-17-000901:notes:24]
Although the Company believes that it is in compliance with the covenants and restrictions under the Term Loans as of December 31, 2016, there can be no assurance that the Company will continue to be in compliance.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001628280-17-000901:notes:25]
[same as prior period, unchanged from 0001628280-16-020601:notes:25]

[0001628280-17-000901:notes:26]
[same as prior period, unchanged from 0001628280-16-020601:notes:26]

[0001628280-17-000901:notes:27]
[same as prior period, unchanged from 0001628280-16-020601:notes:27]

[0001628280-17-000901:notes:28]
[same as prior period, unchanged from 0001628280-16-020601:notes:28]

[0001628280-17-000901:notes:29]
[same as prior period, unchanged from 0001628280-16-020601:notes:29]

[0001628280-17-000901:notes:30]
[same as prior period, unchanged from 0001628280-16-020601:notes:30]

[0001628280-17-000901:notes:31]
| Fiscal Year 16 | December 31, 2016 |  | September 30, 2016 |  | June 30,2016 |  |  |  |  |
| Risk-free interest rate | 0.56% |  | 0.59% |  | 0.48% |  |  |  |  |
| Expected annual dividend yield | — |  | — |  | — |  |  |  |  |
| Expected volatility | 58.04% |  | 70.50% |  | 76.30% |  |  |  |  |
| Term (years) | 0.76 |  | 1.01 |  | 1.26 |  |  |  |  |
| Fair value | $0.1 million |  | $0.2 million |  | $0.4 million |  |  |  |  |

[0001628280-17-000901:notes:32]
[same as prior period, unchanged from 0001628280-16-020601:notes:32]

[0001628280-17-000901:notes:33]
The Company recorded a net gain of $0.1 million and a net loss of $0.2 million, resulting from the changes in the fair value of the Exchanged Warrant during the three months ended December 31, 2016 and 2015, respectively.   The Company recorded a net gain of $0.3 million resulting from the decrease in the fair value of the Exchanged Warrant during the nine months ended December 31, 2016 and no change resulting from any changes in the fair value of the Exchanged Warrant during the nine months ended December 31, 2015.

[0001628280-17-000901:notes:34]
[same as prior period, unchanged from 0001628280-16-020601:notes:34]

[0001628280-17-000901:notes:35]
[same as prior period, unchanged from 0001628280-16-020601:notes:35]

[0001628280-17-000901:notes:36]
[same as prior period, unchanged from 0001628280-16-020601:notes:36]

[0001628280-17-000901:notes:37]
[same as prior period, unchanged from 0001628280-16-020601:notes:37]

[0001628280-17-000901:notes:38]
| Fiscal Year 16 | December 31, 2016 |  | September 30, 2016 |  | June 30,2016 |  |  |  |  |
| Risk-free interest rate | 1.57% |  | 0.97% |  | 0.86% |  |  |  |  |
| Expected annual dividend yield | — |  | — |  | — |  |  |  |  |
| Expected volatility | 67.28% |  | 67.98% |  | 68.34% |  |  |  |  |
| Term (years) | 3.50 |  | 3.75 |  | 4.00 |  |  |  |  |
| Fair value | $0.2 million |  | $0.2 million |  | $0.3 million |  |  |  |  |

[0001628280-17-000901:notes:39]
[same as prior period, unchanged from 0001628280-16-020601:notes:39]

[0001628280-17-000901:notes:40]
The Company recorded no change in fair value of derivatives and warrants during the three months ended December 31, 2016 and a net loss, resulting from an increase in the fair value of the Hercules Warrant of less than $0.1 million during the three months ended December 31, 2015.  The Company recorded net gains of less than $0.1 million in the fair value of the Hercules Warrant during each of the nine months ended December 31, 2016 and 2015.

[0001628280-17-000901:notes:41]
[same as prior period, unchanged from 0001628280-16-020601:notes:41]

[0001628280-17-000901:notes:42]
[same as prior period, unchanged from 0001628280-16-020601:notes:42]

[0001628280-17-000901:notes:43]
[same as prior period, unchanged from 0001628280-16-020601:notes:43]

[0001628280-17-000901:notes:44]
[same as prior period, unchanged from 0001628280-16-020601:notes:44]

[0001628280-17-000901:notes:45]
| Fiscal Year 16 | December 31, 2016 |  | September 30, 2016 |  | June 30,2016 |  |  |  |  |
| Risk-free interest rate | 1.43% |  | 0.93% |  | 0.77% |  |  |  |  |
| Expected annual dividend yield | — |  | — |  | — |  |  |  |  |
| Expected volatility | 69.31% |  | 68.96% |  | 70.01% |  |  |  |  |
| Term (years) | 2.87 |  | 3.12 |  | 3.37 |  |  |  |  |
| Fair value | $2.3 million |  | $2.3 million |  | $3.2 million |  |  |  |  |

[0001628280-17-000901:notes:46]
[same as prior period, unchanged from 0001628280-16-020601:notes:46]

[0001628280-17-000901:notes:47]
The Company recorded  no change resulting from any changes in the fair value of the November 2014 Warrant in the three months ended December 31, 2016 and a net loss, resulting from an increase in the fair value of the November 2014 Warrant of $0.8 million in the three months ended December 31, 2015.  The Company recorded net gains, resulting from a decrease in the fair value of the November 2014 Warrant of $0.3 million and $0.4 million during the nine months ended December 31, 2016 and 2015, respectively.

[0001628280-17-000901:notes:48]
[same as prior period, unchanged from 0001628280-16-020601:notes:48]


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001628280-17-000901:notes:49]
[same as prior period, unchanged from 0001628280-16-020601:notes:49]

[0001628280-17-000901:notes:50]
The Company accounts for its stock-based compensation at fair value. The following table summarizes stock-based compensation expense by financial statement line item for the three and nine months ended December 31, 2016 and 2015 (in thousands):

[0001628280-17-000901:notes:51]
|  | Three months ended December 31, |  | Nine months ended December 31, |
|  | 2016 |  | 2015 |  | 2016 |  | 2015 |
| Cost of revenues | $ | 40 |  |  | $ | 55 |  |  | $ | 139 |  |  | $ | 213 |  |
| Research and development | 61 |  |  | 89 |  |  | 153 |  |  | 373 |  |
| Selling, general and administrative | 512 |  |  | 564 |  |  | 1,974 |  |  | 1,956 |  |
| Total | $ | 613 |  |  | $ | 708 |  |  | $ | 2,266 |  |  | $ | 2,542 |  |

[0001628280-17-000901:notes:52]
The Company granted 9,703 stock options and 161,000 restricted stock awards during the nine months ended December 31, 2016, and 420,189 restricted stock awards during the nine months ended December 31, 2015.  These awards generally vest over 2-3 years.  Awards for restricted stock include both time-based and performance-based awards.  For options and awards that vest upon the passage of time, expense is being recorded over the vesting period.  Performance-based awards are expensed over the requisite service period based on probability of achievement.

[0001628280-17-000901:notes:53]
The estimated fair value of the Company’s stock-based awards, less expected annual forfeitures, is amortized over the awards’ service period. The total unrecognized compensation cost for unvested outstanding stock options was $0.5 million at December 31, 2016. This expense will be recognized over a weighted average expense period of approximately 2.2 years. The total unrecognized compensation cost for unvested outstanding restricted stock was $2.3 million at December 31, 2016. This expense will be recognized over a weighted-average expense period of approximately 1.6 years.

[0001628280-17-000901:notes:54]
The stock options granted during the nine months ended December 31, 2016 will vest over 2 years.  The weighted average assumptions used in the Black Scholes valuation model for stock options granted during the nine months ended December 31, 2016 are as follows:

[0001628280-17-000901:notes:55]
|  | Nine months ended December 31, |
|  | 2016 |  | 2015 |
| Expected volatility | 67.6 | % |  | N/A |
| Risk-free interest rate | 1.3 | % |  | N/A |
| Expected life (years) | 5.7 |  |  | N/A |
| Dividend yield | None |  |  | N/A |

[0001628280-17-000901:notes:56]
[same as prior period, unchanged from 0001628280-16-020601:notes:56]


## us-gaap:EarningsPerShareTextBlock

[0001628280-17-000901:notes:57]
[same as prior period, unchanged from 0001628280-16-020601:notes:57]

[0001628280-17-000901:notes:58]
Basic net loss per share (“EPS”) is computed by dividing net loss by the weighted-average number of common shares outstanding for the period. Where applicable, diluted EPS is computed by dividing the net loss by the weighted-average number of common shares and dilutive common equivalent shares outstanding during the period, calculated using the treasury stock method. Common equivalent shares include the effect of restricted stock, exercise of stock options and warrants and contingently issuable shares. For each of the three and nine months ended December 31, 2016 and 2015, 1.6 million shares were not included in the calculation of diluted EPS as they were considered anti-dilutive, of which 0.4 million relate to outstanding stock options, and 1.2 million relate to outstanding warrants, respectively.

[0001628280-17-000901:notes:59]
The following table reconciles the numerators and denominators of the earnings per share calculation for the three and nine months ended December 31, 2016 and 2015 (in thousands, except per share data):

[0001628280-17-000901:notes:60]
|  | Three months ended December 31, |  | Nine months ended December 31, |
|  | 2016 |  | 2015 |  | 2016 |  | 2015 |
| Numerator: |  |  |  |  |  |  |  |
| Net loss | $ | (2,768 | ) |  | $ | (2,957 | ) |  | $ | (20,448 | ) |  | $ | (19,777 | ) |
| Denominator: |  |  |  |  |  |  |  |
| Weighted-average shares of common stock outstanding | 14,203 |  |  | 14,010 |  |  | 14,175 |  |  | 13,181 |  |
| Weighted-average shares subject to repurchase | (411 | ) |  | (471 | ) |  | (429 | ) |  | (129 | ) |
| Shares used in per-share calculation ― basic | 13,792 |  |  | 13,539 |  |  | 13,746 |  |  | 13,052 |  |
| Shares used in per-share calculation ― diluted | 13,792 |  |  | 13,539 |  |  | 13,746 |  |  | 13,052 |  |
| Net loss per share ― basic | $ | (0.20 | ) |  | $ | (0.22 | ) |  | $ | (1.49 | ) |  | $ | (1.52 | ) |
| Net loss per share ― diluted | $ | (0.20 | ) |  | $ | (0.22 | ) |  | $ | (1.49 | ) |  | $ | (1.52 | ) |


## us-gaap:EquityMethodInvestmentsDisclosureTextBlock

[0001628280-17-000901:notes:61]
[same as prior period, unchanged from 0001628280-16-020601:notes:61]

[0001628280-17-000901:notes:62]
[same as prior period, unchanged from 0001628280-16-020601:notes:62]

[0001628280-17-000901:notes:63]
[same as prior period, unchanged from 0001628280-16-020601:notes:63]

[0001628280-17-000901:notes:64]
[same as prior period, unchanged from 0001628280-16-020601:notes:64]

[0001628280-17-000901:notes:65]
On March 11, 2016, the Company sold 100% of its minority share investment in Tres Amigas to an investor for $0.6 million.  The Company received $0.3 million according to the terms of the purchase agreement upon closing, which was recorded as a gain during the three months ended March 31, 2016.  The final $0.3 million was received and recorded as a gain during the third quarter of fiscal 2016.


## us-gaap:FairValueDisclosuresTextBlock

[0001628280-17-000901:notes:66]
[same as prior period, unchanged from 0001628280-16-020601:notes:66]

[0001628280-17-000901:notes:67]
[same as prior period, unchanged from 0001628280-16-020601:notes:67]

[0001628280-17-000901:notes:68]
[same as prior period, unchanged from 0001628280-16-020601:notes:68]

[0001628280-17-000901:notes:69]
The Company provides a gross presentation of activity within Level 3 measurement roll-forward and details of transfers in and out of Level 1 and 2 measurements.  A change in the hierarchy of an investment from its current level is reflected in the period during which the pricing methodology of such investment changes.  Disclosure of the transfer of securities from Level 1 to Level 2 or Level 3 is made in the event that the related security is significant to total cash and investments.  The Company did not have any transfers of assets and liabilities from Level 1 and Level 2 to Level 3 of the fair value measurement hierarchy during the three and nine months ended December 31, 2016.

[0001628280-17-000901:notes:70]
[same as prior period, unchanged from 0001628280-16-020601:notes:70]

[0001628280-17-000901:notes:71]
The following table provides the assets and liabilities carried at fair value on a recurring basis, measured as of December 31, 2016 and March 31, 2016 (in thousands):

[0001628280-17-000901:notes:72]
|  | TotalCarryingValue |  | Quoted Prices inActive Markets(Level 1) |  | Significant OtherObservable Inputs(Level 2) |  | SignificantUnobservable Inputs(Level 3) |
| December 31, 2016: |  |  |  |  |  |  |  |
| Assets: |  |  |  |  |  |  |  |
| Cash equivalents | $ | 14,088 |  |  | $ | 14,088 |  |  | $ | — |  |  | $ | — |  |
| Derivative liabilities: |  |  |  |  |  |  |  |
| Warrants | $ | 2,560 |  |  | $ | — |  |  | $ | — |  |  | $ | 2,560 |  |

[0001628280-17-000901:notes:73]
[same as prior period, unchanged from 0001628280-16-020601:notes:73]

[0001628280-17-000901:notes:74]
[same as prior period, unchanged from 0001628280-16-020601:notes:74]

[0001628280-17-000901:notes:75]
|  | Warrants |
| April 1, 2016 | $ | 3,227 |  |
| Mark to market adjustment | (667 | ) |
| Balance at December 31, 2016 | $ | 2,560 |  |

[0001628280-17-000901:notes:76]
[same as prior period, unchanged from 0001628280-16-020601:notes:76]

[0001628280-17-000901:notes:77]
[same as prior period, unchanged from 0001628280-16-020601:notes:77]

[0001628280-17-000901:notes:78]
[same as prior period, unchanged from 0001628280-16-020601:notes:78]

[0001628280-17-000901:notes:79]
[same as prior period, unchanged from 0001628280-16-020601:notes:79]

[0001628280-17-000901:notes:80]
[same as prior period, unchanged from 0001628280-16-020601:notes:80]

[0001628280-17-000901:notes:81]
[same as prior period, unchanged from 0001628280-16-020601:notes:81]

[0001628280-17-000901:notes:82]
[same as prior period, unchanged from 0001628280-16-020601:notes:82]


## us-gaap:IncomeTaxDisclosureTextBlock

[0001628280-17-000901:notes:83]
[same as prior period, unchanged from 0001628280-16-020601:notes:83]

[0001628280-17-000901:notes:84]
The Company recorded an income tax benefit of $0.1 million and income tax expense of $1.0 million in the three and nine months ended December 31, 2016, respectively, and income tax expense of $0.8 million and $2.3 million in the three and nine months ended December 31, 2015, respectively.  Income tax (benefit) expense was primarily due to dividend withholding taxes and income taxes in the Company’s foreign jurisdictions.

[0001628280-17-000901:notes:85]
Accounting for income taxes requires a two-step approach to recognizing and measuring uncertain tax positions.  The first step is to evaluate the tax position for recognition by determining if, based on the technical merits, it is more likely than not the position will be sustained upon audit, including resolution of related appeals or litigation processes, if any.  The second step is to measure the tax benefit as the largest amount that is more than 50% likely to be realized upon ultimate settlement.  The Company re-evaluates these uncertain tax positions on a quarterly basis.  The evaluation is based on factors including, but not limited to, changes in facts or circumstances, changes in tax law, effectively settled issues under audit and new audit activity.  Any changes in these factors could result in the recognition of a tax benefit or an additional charge to the tax provision.  The Company did not identify any uncertain tax positions in the nine months ended December 31, 2016 and did not have any gross unrecognized tax benefits as of March 31, 2016.


## us-gaap:InventoryDisclosureTextBlock

[0001628280-17-000901:notes:86]
[same as prior period, unchanged from 0001628280-16-020601:notes:86]

[0001628280-17-000901:notes:87]
Inventory at December 31, 2016 and March 31, 2016 consisted of the following (in thousands):

[0001628280-17-000901:notes:88]
|  | December 31, 2016 |  | March 31, 2016 |
| Raw materials | $ | 8,433 |  |  | $ | 9,665 |  |
| Work-in-process | 1,278 |  |  | 3,411 |  |
| Finished goods | 5,433 |  |  | 3,215 |  |
| Deferred program costs | 4,298 |  |  | 2,221 |  |
| Net inventory | $ | 19,442 |  |  | $ | 18,512 |  |

[0001628280-17-000901:notes:89]
The Company recorded inventory write-downs of $0.4 million and $1.0 million for each of the three months ended December 31, 2016 and 2015, respectively.  The Company recorded inventory write-downs of $1.1 million and $1.8 million for each of the nine months ended December 31, 2016, and 2015, respectively.  These write downs were based on evaluating its inventory on hand for excess quantities and obsolescence.

[0001628280-17-000901:notes:90]
Deferred program costs as of December 31, 2016 and March 31, 2016 primarily represent costs incurred on programs accounted for under contract accounting where the Company needs to complete development milestones before revenue and costs will be recognized.


## us-gaap:LoansNotesTradeAndOtherReceivablesDisclosureTextBlock

[0001628280-17-000901:notes:91]
[same as prior period, unchanged from 0001628280-16-020601:notes:91]

[0001628280-17-000901:notes:92]
Accounts receivable at December 31, 2016 and March 31, 2016 consisted of the following (in thousands):

[0001628280-17-000901:notes:93]
|  | December 31, 2016 |  | March 31, 2016 |
| Accounts receivable (billed) | $ | 15,329 |  |  | $ | 18,089 |  |
| Accounts receivable (unbilled) | 588 |  |  | 1,229 |  |
| Less: Allowance for doubtful accounts | (54 | ) |  | (54 | ) |
| Accounts receivable, net | $ | 15,863 |  |  | $ | 19,264 |  |


## us-gaap:NewAccountingPronouncementsAndChangesInAccountingPrinciplesTextBlock

[0001628280-17-000901:notes:94]
Recent Accounting Pronouncements

[0001628280-17-000901:notes:95]
In May 2014, the FASB and the International Accounting Standards Board (IASB) issued ASU 2014-09, ASU Revenue from Contracts with Customers (Topic 606), The guidance substantially converges final standards on revenue recognition between the FASB and IASB providing a framework on addressing revenue recognition issues and, upon its effective date, replaces almost all existing revenue recognition guidance, including industry-specific guidance, in current U.S. generally accepted accounting principles.  The ASU is effective for annual reporting periods beginning after December 15, 2017.  The Company is currently evaluating the impact the adoption of ASU 2014-09 may have on its current practices.

[0001628280-17-000901:notes:96]
In July 2014, the FASB issued ASU 2014-12, Compensation - Stock Compensation (Topic 718): Accounting for Share Based Payments When the Terms of an Award Provide that a Performance Target could be Achieved after the Requisite Service Period.  To account for such awards, a reporting entity should apply existing guidance in FASB Accounting Standards Codification Topic 718, Compensation - Stock Compensation, as it relates to awards with performance conditions that affect vesting.  As such, the performance target should not be reflected in estimating the grant-date fair value of the award. The Company adopted ASU 2014-12 effective April 1, 2016 and concludes that there is no material impact on its current practices.

[0001628280-17-000901:notes:97]
In August 2014, the FASB issued ASU 2014-15, Presentation of Financial Statements - Going Concern (Subtopic 205-40): Disclosure of Uncertainties About an Entity’s Ability to Continue as a Going Concern.  The new standard explicitly requires the assessment at interim and annual periods, and provides management with its own disclosure guidance.  This ASU is effective for annual reporting periods ending after December 15, 2016 and interim periods within annual periods beginning after December 15, 2016.  The Company expects to adopt ASU 2014-15 effective March 31, 2017 and is currently evaluating the impact, if any, the adoption of ASU 2014-15 may have on its current practices.

[0001628280-17-000901:notes:98]
In April 2015, the FASB issued ASU 2015-03 Interest-Imputation of Interest (Subtopic 835-30): Simplifying the Presentation of Debt Issuance Costs.  The amendments in ASU 2015-03 require an entity to present debt issuance costs on the balance sheet as a direct deduction from the related debt liability as opposed to an asset. Amortization of the costs will continue to be reported as interest expense. The Company adopted ASU 2015-03 effective April 1, 2016 and concludes that there is no material impact on its consolidated results of operations, financial condition, or cash flow.

[0001628280-17-000901:notes:99]
In June 2015, the FASB issued ASU 2015-10 Technical Corrections and Improvements.  The amendments in ASU 2015-10 clarify and correct some of the differences that arose between original guidance from FASB, EITF and other sources, and the translation into the new Codification. The Company adopted ASU 2015-10 effective April 1, 2016 and concludes that there is no material impact on its consolidated results of operations, financial condition, or cash flow.

[0001628280-17-000901:notes:100]
In July 2015, the FASB issued ASU 2015-11 Inventory (Topic 330): Simplifying the Measurement of Inventory.  The amendments in ASU 2015-11 clarify the proper way to identify market value in the use of lower of cost or market value valuation method.  As market value could be determined multiple ways under prior standards, it will now be considered as net realizable value. This ASU is effective for annual reporting periods beginning after December 15, 2016, and interim periods within those fiscal years.  The Company expects to adopt ASU 2015-11 effective March 31, 2017 and is currently evaluating the impact, if any, the adoption of ASU 2015-11 may have on its current practices.

[0001628280-17-000901:notes:101]
In September 2015, the FASB issued ASU 2015-16 Business Combinations (Topic 805): Simplifying the Accounting for Measurement-Period Adjustments.  The amendments in ASU 2015-16 require that an acquirer recognize adjustments to provisional amounts identified during the measurement period in the reporting period in which the adjustment amounts are determined. The Company adopted ASU 2015-16 effective April 1, 2016 and concludes that there is no material impact on its consolidated results of operations, financial condition, or cash flow.

[0001628280-17-000901:notes:102]
In January 2016, the FASB issued ASU 2016-01 Financial Instruments-Overall (Subtopic 825-10): Recognition and Measurement of Financial Assets and Financial Liabilities.  The amendments in ASU 2016-01 will enhance the reporting model for financial instruments to provide users of financial statements with more decision-useful information. This ASU is effective for annual reporting periods beginning after December 15, 2017, and interim periods within those fiscal years.  The Company is currently evaluating the impact, if any, the adoption of ASU 2016-01 may have on its current practices.

[0001628280-17-000901:notes:103]
In February 2016, the FASB issued ASU 2016-02, Leases (Topic 842). The guidance in this ASU supersedes the leasing guidance in Topic 840, Leases. Under the new guidance, lessees are required to recognize lease assets and lease liabilities on the balance sheet for all leases with terms longer than 12 months. Leases will be classified as either finance or operating, with classification affecting the pattern of expense recognition in the income statement. This ASU is effective for fiscal years beginning after December 15, 2018, including interim periods within those fiscal years. A modified retrospective transition approach is required for lessees for capital and operating leases existing at, or entered into after, the beginning of the earliest comparative period presented in the financial statements, with certain practical expedients available. The Company is currently evaluating the effects adoption of this guidance will have on its consolidated financial statements.

[0001628280-17-000901:notes:104]
In March 2016, the FASB issued ASU 2016-08 Revenue from Contracts with Customers (Topic 606): Principal versus Agent Considerations (Reporting Revenue Gross versus Net).  The amendments in ASU 2016-08 clarify the implementation guidance on principal versus agent consideration. The ASU is effective for annual reporting periods beginning after December 15, 2017.  The Company is currently evaluating the impact, if any, the adoption of ASU 2016-08 may have on its current practices.

[0001628280-17-000901:notes:105]
In March 2016, the FASB issued ASU 2016-09 Compensation-Stock Compensation (Topic 718): Improvements to Employee Share-Based Payment Accounting.  The amendments in ASU 2016-09 will simplify several aspects of the accounting for share-based payment transactions, including tax consequences, classification of awards as either equity or liabilities, and classification on the statement of cash flows. The ASU is effective for annual reporting periods beginning after December 15, 2016, and interim periods within those annual periods.  The Company expects to adopt ASU 2016-09 effective March 31, 2017 and is currently evaluating the impact, if any, the adoption of ASU 2016-09 may have on its current practices.

[0001628280-17-000901:notes:106]
In April 2016, the FASB issued ASU 2016-10 Revenue from Contracts with Customers (Topic 606): Identifying Performance Obligations and Licensing.  The amendments in ASU 2016-10 will clarify the identification of performance obligations and the licensing implementation guidance. The ASU is effective for annual reporting periods beginning after December 15, 2017.  The Company is currently evaluating the impact, if any, the adoption of ASU 2016-10 may have on its current practices.

[0001628280-17-000901:notes:107]
In April 2016, the FASB issued ASU 2016-12 Revenue from Contracts with Customers (Topic 606): Narrow-Scope Improvements and Practical Expedients.  The amendments in ASU 2016-12 will clarify the prior guidance surrounding collectability criteria, presentation of taxes collected, non-cash consideration, contract modifications, completed contracts at completion and retrospective application guidance. The ASU is effective for annual reporting periods beginning after December 15, 2017.  The Company is currently evaluating the impact the adoption of ASU 2016-12 may have on its current practices.

[0001628280-17-000901:notes:108]
In June 2016, the FASB issued ASU 2016-13 Financial Instruments—Credit Losses (Topic 326): Measurement of Credit Losses on Financial Instruments.  The amendments in ASU 2016-13 will provide more decision useful information about the expected credit losses on financial instruments and other commitments to extend credit held by a reporting entity at each reporting date. The ASU is effective for annual reporting periods beginning after December 15, 2019, including interim periods within that year.  The Company is currently evaluating the impact, if any, the adoption of ASU 2016-13 may have on its current practices.

[0001628280-17-000901:notes:109]
In August 2016, the FASB issued ASU 2016-15 Statement of Cash Flows (Topic 230): Classification of Certain Cash Receipts and Cash Payments.  The amendments in ASU 2016-15 will provide more guidance towards the classification of multiple different types of cash flows in order to reduce the diversity in reporting across entities. The ASU is effective for annual reporting periods beginning after December 15, 2017, including interim periods within that year.  The Company is currently evaluating the impact, if any, the adoption of ASU 2016-15 may have on its current practices.

[0001628280-17-000901:notes:110]
In October 2016, the FASB issued ASU 2016-16—Income Taxes (Topic 740): Intra-Entity Transfers of Assets Other Than Inventory.  The amendments in ASU 2016-16 will improve the accounting for the income tax consequences of intra-entity transfers of assets other than inventory. The ASU is effective for annual reporting periods beginning after December 15, 2017, including interim periods within that year.  The Company is currently evaluating the impact, if any, the adoption of ASU 2016-16 may have on its current practices.

[0001628280-17-000901:notes:111]
In November 2016, the FASB issued ASU 2016-18—Statement of Cash Flows (Topic 230): Restricted Cash.  The amendments in ASU 2016-18 will explain the change during the period in the total of cash, cash equivalents, and amounts generally described as restricted cash or restricted cash equivalents. Therefore, amounts generally described as restricted cash and restricted cash equivalents should be included with cash and cash equivalents when reconciling the beginning-of-period and end-of-period total amounts shown on the statement of cash flows.  The ASU is effective for annual reporting periods beginning after December 15, 2017, including interim periods within that year.  The Company is currently evaluating the impact, if any, the adoption of ASU 2016-18 may have on its current practices.

[0001628280-17-000901:notes:112]
In December 2016, the FASB issued ASU 2016-19—Technical Corrections and Improvements.  The amendments in ASU 2016-19 will improve the accounting for the income tax consequences of intra-entity transfers of assets other than inventory. The ASU is effective for annual reporting periods beginning after December 15, 2017, including interim periods within that year.  The Company is currently evaluating the impact, if any, the adoption of ASU 2016-19 may have on its current practices.

[0001628280-17-000901:notes:113]
In December 2016, the FASB issued ASU 2016-20—Technical Corrections and Improvements to Topic 606, Revenue from Contracts with Customers.  The amendments in ASU 2016-20 will clarify the codification and correct unintended application of guidance. These items generally are not expected to have a significant effect on current accounting practice or create a significant administrative cost for most entities. The ASU is effective for annual reporting periods beginning after December 15, 2017.  The Company is currently evaluating the impact the adoption of ASU 2014-09 may have on its current practices.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0001628280-17-000901:notes:114]
[same as prior period, unchanged from 0001628280-16-020601:notes:110]

[0001628280-17-000901:notes:115]
[same as prior period, unchanged from 0001628280-16-020601:notes:111]

[0001628280-17-000901:notes:116]
[same as prior period, unchanged from 0001628280-16-020601:notes:112]

[0001628280-17-000901:notes:117]
[same as prior period, unchanged from 0001628280-16-020601:notes:113]

[0001628280-17-000901:notes:118]
The Company has experienced recurring operating losses and as of December 31, 2016, the Company had an accumulated deficit of $948.6 million. In addition, the Company has experienced recurring negative operating cash flows.  At December 31, 2016, the Company had cash and cash equivalents of $25.1 million. Cash used in operations for the nine months ended December 31, 2016 was $10.5 million.

[0001628280-17-000901:notes:119]
From April 1, 2011 through the date of this filing, the Company has reduced its global workforce substantially.  The Company has taken actions to consolidate certain business operations to reduce facility costs.  As of December 31, 2016, the Company had a global workforce of 366 persons.  The Company plans to closely monitor its expenses and, if required, expects to further reduce operating costs and capital spending to enhance liquidity.

[0001628280-17-000901:notes:120]
Over the last several years, the Company has entered into several debt and equity financing arrangements in order to enhance liquidity.  Since April 1, 2012, the Company has generated aggregate cash flows from financing activities of $67.3 million.  This amount includes proceeds from an April 2015 equity offering, which generated net proceeds of approximately $22.3 million, after deducting underwriting discounts and commissions and estimated offering expenses payable by the Company.  See Note 9, “Debt”, and Note 11 “Stockholders Equity” for further discussion of these financing arrangements. The Company believes that it is in compliance with the covenants and restrictions included in the agreements governing its debt arrangements as of December 31, 2016.

[0001628280-17-000901:notes:121]
In December 2015, the Company entered into a set of strategic agreements valued at approximately $210.0 million with Inox Wind Ltd. (“Inox”), which includes a multi-year supply contract pursuant to which the Company will supply electric control systems to Inox and a license agreement allowing Inox to manufacture a limited number of electrical control systems over the following three to four years.  After this initial three to four year period, Inox agreed that the Company will continue as Inox’s preferred supplier and Inox will be required to purchase from the Company a majority of its electric control systems requirements for an additional three-year period.  These agreements are expected to provide a foundation for the business as the Company pursues its longer-term objectives.

[0001628280-17-000901:notes:122]
On March 11, 2016, the Company sold 100% of its minority share investment in Tres Amigas LLC ("Tres Amigas") to an investor for $0.6 million.  The Company received $0.3 million according to the terms of the purchase agreement upon closing, which was recorded as a gain during the three months ended March 31, 2016.  The final $0.3 million was received and recorded as a gain during the third quarter of fiscal 2016.  See Note 13, “Minority Investments”, for further information about such investment.

[0001628280-17-000901:notes:123]
The Company believes it has sufficient liquidity to fund its operations, capital expenditures and scheduled cash payments under its debt obligations for the next twelve months. The Company’s liquidity is highly dependent on its ability to increase revenues, its ability to control its operating costs, its ability to maintain compliance with the covenants and restrictions on its debt obligations (or obtain waivers from its lender in the event of non-compliance), and its ability to raise additional capital, if necessary. There can be no assurance that the Company will be able to continue to raise additional capital from other sources or execute on any other means of improving liquidity described above.


## us-gaap:ReconciliationOfAssetsFromSegmentToConsolidatedTextBlock

[0001628280-17-000901:notes:124]
Total assets for the two business segments as of December 31, 2016 and March 31, 2016 are as follows (in thousands):

[0001628280-17-000901:notes:125]
|  | December 31, 2016 |  | March 31, 2016 |
| Wind | $ | 26,075 |  |  | $ | 34,389 |  |
| Grid | 34,869 |  |  | 36,255 |  |
| Corporate assets | 49,297 |  |  | 64,674 |  |
| Total | $ | 110,241 |  |  | $ | 135,318 |  |


## us-gaap:ScheduleOfRevenueByMajorCustomersByReportingSegmentsTableTextBlock

[0001628280-17-000901:notes:126]
The following table sets forth customers who represented 10% or more of the Company’s total revenues for the three and nine months ended December 31, 2016 and 2015:

[0001628280-17-000901:notes:127]
|  | Three months ended December 31, |  | Nine months ended December 31, |
|  | 2016 |  | 2015 |  | 2016 |  | 2015 |
| INOX Wind Limited | 66 | % |  | 64 | % |  | 58 | % |  | 58 | % |
| Hidalgo Wind Farm LLC | 17 | % |  | — | % |  | <10% |  |  | — | % |
| Fuji Bridex Pte Ltd | <10% |  |  | 18 | % |  | <10% |  |  | <10% |  |


## us-gaap:ScheduleOfSegmentReportingInformationBySegmentTextBlock

[0001628280-17-000901:notes:128]
[same as prior period, unchanged from 0001628280-16-020601:notes:124]

[0001628280-17-000901:notes:129]
|  | Three months ended December 31, |  | Nine months ended December 31, |
|  | 2016 |  | 2015 |  | 2016 |  | 2015 |
| Revenues: |  |  |  |  |  |  |  |
| Wind | $ | 18,248 |  |  | $ | 17,229 |  |  | $ | 36,822 |  |  | $ | 48,976 |  |
| Grid | 8,900 |  |  | 8,543 |  |  | 22,178 |  |  | 19,523 |  |
| Total | $ | 27,148 |  |  | $ | 25,772 |  |  | $ | 59,000 |  |  | $ | 68,499 |  |

[0001628280-17-000901:notes:130]
|  | Three months ended December 31, |  | Nine months ended December 31, |
|  | 2016 |  | 2015 |  | 2016 |  | 2015 |
| Operating (loss) profit: |  |  |  |  |  |  |  |
| Wind | $ | 1,044 |  |  | $ | (263 | ) |  | $ | (3,220 | ) |  | $ | (2,127 | ) |
| Grid | (4,491 | ) |  | (2,342 | ) |  | (15,068 | ) |  | (12,963 | ) |
| Unallocated corporate expenses | (613 | ) |  | (707 | ) |  | (2,266 | ) |  | (3,321 | ) |
| Total | $ | (4,060 | ) |  | $ | (3,312 | ) |  | $ | (20,554 | ) |  | $ | (18,411 | ) |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001628280-17-000901:notes:131]
[same as prior period, unchanged from 0001628280-16-020601:notes:127]

[0001628280-17-000901:notes:132]
[same as prior period, unchanged from 0001628280-16-020601:notes:128]

[0001628280-17-000901:notes:133]
[same as prior period, unchanged from 0001628280-16-020601:notes:129]

[0001628280-17-000901:notes:134]
[same as prior period, unchanged from 0001628280-16-020601:notes:130]

[0001628280-17-000901:notes:135]
[same as prior period, unchanged from 0001628280-16-020601:notes:131]

[0001628280-17-000901:notes:136]
Unallocated corporate expenses primarily consist of stock-based compensation expense of $0.6 million and $0.7 million in the three months ended December 31, 2016 and 2015, respectively, and stock-based compensation expense of $2.3 million and $2.5 million in the nine months ended December 31, 2016 and 2015, respectively.  Additionally, unallocated corporate expenses include an impairment charge of $0.7 million for the nine months ended December 31, 2015.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001628280-17-000901:notes:137]
[same as prior period, unchanged from 0001628280-16-020601:notes:133]

[0001628280-17-000901:notes:138]
[same as prior period, unchanged from 0001628280-16-020601:notes:134]


## us-gaap:SubsequentEventsTextBlock

[0001628280-17-000901:notes:139]
Subsequent Events

[0001628280-17-000901:notes:140]
On January 27, 2017, the Company entered into an At Market Issuance Sales Agreement ("ATM") with FBR Capital Markets & Co ("FBR") under which the Company may, at its discretion, sell up to $10.0 million of its shares of common stock through FBR.  FBR has agreed to use its commercially reasonable efforts to sell the Company’s common stock from time to time, based upon the Company’s instructions (including any price, time or size limits or other customary parameters or conditions the Company may impose).  Sales under the ATM, if any, would be made pursuant to the prospectus supplement dated January 27, 2017, which supplements the prospectus dated October 1, 2014, included in the shelf registration statement that AMSC filed with the Securities and Exchange Commission (“SEC”) on September 19, 2014.

[0001628280-17-000901:notes:141]
As of the time of filing this Quarterly Report on Form 10-Q with the SEC, and has determined that there are no other such events to report.
