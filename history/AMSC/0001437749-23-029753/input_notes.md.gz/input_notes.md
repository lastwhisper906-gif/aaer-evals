# AMSC notes — 0001437749-23-029753


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0001437749-23-029753:notes:1]
AMERICAN SUPERCONDUCTOR CORPORATION

[0001437749-23-029753:notes:2]
NOTES TO UNAUDITED CONDENSED CONSOLIDATED FINANCIAL STATEMENTS

[0001437749-23-029753:notes:3]
[same as prior period, unchanged from 0001437749-23-022793:notes:1]

[0001437749-23-029753:notes:4]
[same as prior period, unchanged from 0001437749-23-022793:notes:2]

[0001437749-23-029753:notes:5]
[same as prior period, unchanged from 0001437749-23-022793:notes:3]

[0001437749-23-029753:notes:6]
These unaudited condensed consolidated financial statements of the Company have been prepared on a going concern basis in accordance with United States generally accepted accounting principles (“GAAP”) and the Securities and Exchange Commission’s (“SEC”) instructions to Form 10-Q. The going concern basis of presentation assumes that the Company will continue operations and will be able to realize its assets and discharge its liabilities and commitments in the normal course of business. Certain information and footnote disclosures normally included in the financial statements prepared in accordance with GAAP have been condensed or omitted pursuant to those instructions. The year-end condensed balance sheet data was derived from audited financial statements but does not include all disclosures required by GAAP. The unaudited condensed consolidated financial statements, in the opinion of management, reflect all adjustments (consisting of normal recurring adjustments) necessary for a fair statement of the results for the interim periods ended  September 30, 2023 and 2022 and the financial position at  September 30, 2023; however, these results are not necessarily indicative of results which  may be expected for the full year. The interim condensed consolidated financial statements, and notes thereto, should be read in conjunction with the audited consolidated financial statements for the year ended  March 31, 2023, and notes thereto, included in the Company’s Annual Report on Form 10-K for the year ended  March 31, 2023 filed with the SEC on  May 31, 2023.

[0001437749-23-029753:notes:7]
[same as prior period, unchanged from 0001437749-23-022793:notes:5]

[0001437749-23-029753:notes:8]
The Company has historically experienced recurring operating losses and as of  September 30, 2023, the Company had an accumulated deficit of $1,063.4 million. In addition, the Company has historically experienced recurring negative operating cash flows. At  September 30, 2023, the Company had cash and cash equivalents of $22.8 million. Cash used in operations for the six months ended  September 30, 2023 was $1.3 million.

[0001437749-23-029753:notes:9]
[same as prior period, unchanged from 0001437749-23-022793:notes:7]

[0001437749-23-029753:notes:10]
The Company continues to experience inflationary pressure in its supply chain and some delays in sourcing materials needed for its products resulting in some production disruption, both of which have increased the Company’s cost of revenues and decreased gross margin. While the impact of inflation has been challenging, the Company continues to take actions to limit this pressure, including adjusting the pricing of its products and services. Changes in macroeconomic conditions arising from the COVID-19 pandemic or for other reasons, such as the ongoing wars between Russia and Ukraine and Israel and Hamas, inflation, rising interest rates, labor force availability, sourcing, material delays and global supply chain disruptions could have a material adverse effect on the Company’s business, financial condition and results of operation.

[0001437749-23-029753:notes:11]
From time-to-time the Company  may undertake restructuring activities in order to align the global organization in a manner that the Company believes will better position it to achieve its long-term goals. In  January 2023, the Company undertook a reduction in force that involved approximately 5% of the global workforce. This restructuring is expected to incur $1.0 million of cash expenses, $0.8 million of which has been paid as of  September 30, 2023, and to result in annualized cost savings of approximately $5.0 million, beginning in fiscal 2023.

[0001437749-23-029753:notes:12]
The Company believes that based on the information presented above and its quarterly management assessment, it has sufficient liquidity to fund its operations and capital expenditures for the next twelve months following the issuance of the unaudited condensed consolidated financial statements for the six months ended  September 30, 2023. The Company’s liquidity is highly dependent on its ability to increase revenues, its ability to control its operating costs, and its ability to raise additional capital, if necessary. The impact of the COVID-19 pandemic and other sources of instability, including the wars between Russia and Ukraine and Israel and Hamas, on the global financing markets  may reduce the Company's ability to raise additional capital, if necessary, which could negatively impact the Company's liquidity.  There can be no assurance that the Company will be able to continue to raise additional capital, on favorable terms or at all, from other sources or execute on any other means of improving liquidity described above.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001437749-23-029753:notes:13]
[same as prior period, unchanged from 0001437749-23-022793:notes:11]

[0001437749-23-029753:notes:14]
The Company’s revenues in its Grid business segment are derived primarily through enabling the transmission and distribution of power, providing planning services that allow it to identify power grid needs and risks, and developing ship protection systems for the U.S. Navy. The Company’s revenues in its Wind business segment are derived primarily through supplying advanced power electronics and control systems, licensing its highly engineered wind turbine designs, and providing extensive customer support services to wind turbine manufacturers. The Company records revenue based on a five-step model in accordance with Accounting Standards Codification ("ASC") 606. For its customer contracts, the Company identifies the performance obligations, determines the transaction price, allocates the contract transaction price to the performance obligations, and recognizes the revenue when (or as) control of goods or services is transferred to the customer. In the three and six months ended  September 30, 2023, 79% and 78% of revenue, respectively, was recognized at the point in time when control transferred to the customer, with the remainder being recognized over time. In the three and six months ended  September 30, 2022, 83% and 77% of revenue, respectively, was recognized at the point in time when control transferred to the customer, with the remainder being recognized over time.

[0001437749-23-029753:notes:15]
[same as prior period, unchanged from 0001437749-23-022793:notes:13]

[0001437749-23-029753:notes:16]
[same as prior period, unchanged from 0001437749-23-022793:notes:15]

[0001437749-23-029753:notes:17]
[same as prior period, unchanged from 0001437749-23-022793:notes:16]

[0001437749-23-029753:notes:18]
[same as prior period, unchanged from 0001437749-23-022793:notes:17]

[0001437749-23-029753:notes:19]
The Company provides assurance-type warranties on all product sales for a term of typically one to three years, and extended service-type warranties are available for purchase at the customer's option for an additional term ranging up to four additional years. The Company accrues for the estimated warranty costs for assurance warranties at the time of sale based on historical warranty experience plus any known or expected changes in warranty exposure. For all extended service-type warranties, the Company recognizes the revenue ratably over time during the effective period of the services.

[0001437749-23-029753:notes:20]
The Company records revenue net of sales tax, value added tax, excise tax and other taxes collected concurrent with revenue-producing activities. The Company has elected to recognize the cost for freight and shipping when control over the products sold passes to customers and revenue is recognized. The Company has elected to recognize incremental costs of obtaining a contract as expense when incurred except in contracts where the amortization period would exceed twelve months; in such cases the long-term amount will be assessed for materiality. The Company has elected not to adjust the promised amount of consideration for the effects of a significant financing component if the period of financing is twelve months or less.  The Company has elected to recognize revenue based on the As Invoiced practical expedient if there is a right to consideration from a customer in an amount that corresponds directly with the value of the Company's performance.

[0001437749-23-029753:notes:21]
The Company monitors costs to meet its obligations on its customer contracts. When it is evident that there is a loss expected on a contract, a contract loss is accrued in the period. Several long-term contracts that were acquired from Neeltran, Inc. (“Neeltran”) were impacted by higher than planned costs due to required design changes and inflation on material costs, resulting in an increase to the contract loss accrual of $1.0 million and $1.2 million in the three and six months ended  September 30, 2022, respectively, which negatively impacted the Company's gross margins. The contract loss accrual decreased by $0.9 million in each of the three and six months ended  September 30, 2023, respectively, as projects have been completed.

[0001437749-23-029753:notes:22]
[same as prior period, unchanged from 0001437749-23-022793:notes:21]

[0001437749-23-029753:notes:23]
[same as prior period, unchanged from 0001437749-23-022793:notes:22]

[0001437749-23-029753:notes:24]
|  |  | Three Months Ended September 30, 2023 |  |  | Six Months Ended September 30, 2023 |  |
| Product Line: |  | Grid |  |  | Wind |  |  | Grid |  |  | Wind |  |
| Equipment and systems |  | $ | 22,682 |  |  | $ | 4,879 |  |  | $ | 45,808 |  |  | $ | 8,862 |  |
| Services and technology development |  |  | 5,833 |  |  |  | 610 |  |  |  | 8,443 |  |  |  | 1,145 |  |
| Total |  | $ | 28,515 |  |  | $ | 5,489 |  |  | $ | 54,251 |  |  | $ | 10,007 |  |
| Region: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas |  | $ | 24,696 |  |  | $ | 27 |  |  | $ | 47,856 |  |  | $ | 57 |  |
| Asia Pacific |  |  | 3,418 |  |  |  | 5,462 |  |  |  | 5,129 |  |  |  | 9,928 |  |
| EMEA |  |  | 401 |  |  |  | — |  |  |  | 1,266 |  |  |  | 22 |  |
| Total |  | $ | 28,515 |  |  | $ | 5,489 |  |  | $ | 54,251 |  |  | $ | 10,007 |  |

[0001437749-23-029753:notes:25]
|  |  | Three Months Ended September 30, 2022 |  |  | Six Months Ended September 30, 2022 |  |
| Product Line: |  | Grid |  |  | Wind |  |  | Grid |  |  | Wind |  |
| Equipment and systems |  | $ | 24,128 |  |  | $ | 1,330 |  |  | $ | 42,204 |  |  | $ | 3,302 |  |
| Services and technology development |  |  | 1,570 |  |  |  | 652 |  |  |  | 3,323 |  |  |  | 1,531 |  |
| Total |  | $ | 25,698 |  |  | $ | 1,982 |  |  | $ | 45,527 |  |  | $ | 4,833 |  |
| Region: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas |  | $ | 18,021 |  |  | $ | - |  |  | $ | 34,923 |  |  | $ | - |  |
| Asia Pacific |  |  | 6,178 |  |  |  | 1,912 |  |  |  | 8,855 |  |  |  | 4,763 |  |
| EMEA |  |  | 1,499 |  |  |  | 70 |  |  |  | 1,749 |  |  |  | 70 |  |
| Total |  | $ | 25,698 |  |  | $ | 1,982 |  |  | $ | 45,527 |  |  | $ | 4,833 |  |

[0001437749-23-029753:notes:26]
As of  September 30, 2023, and 2022, the Company’s contract assets and liabilities primarily relate to the timing differences between cash received from a customer in connection with contractual rights to invoicing and the timing of revenue recognition following completion of performance obligations. The Company's accounts receivable balance is made up entirely of customer contract related balances. Changes in the Company’s contract assets, which are included in “Unbilled accounts receivable” and “Deferred program costs” (see Note 7, “Accounts Receivable” and Note 8, “Inventory” for a reconciliation to the condensed consolidated balance sheets) and "Contract liabilities", which are included in the current portion and long-term portion of "Deferred revenue" in the Company’s condensed consolidated balance sheets, are as follows (in thousands):

[0001437749-23-029753:notes:27]
|  |  | Unbilled Accounts Receivable |  |  | Deferred Program Costs |  |  | Contract Liabilities |  |
| Beginning balance as of March 31, 2023 |  | $ | 9,958 |  |  | $ | 2,136 |  |  | $ | 50,760 |  |
| Increases for costs incurred to fulfill performance obligations |  |  | — |  |  |  | 2,110 |  |  |  | — |  |
| Increase (decrease) due to customer billings |  |  | (13,981 | ) |  |  | — |  |  |  | 34,284 |  |
| Decrease due to cost recognition on completed performance obligations |  |  | — |  |  |  | (2,160 | ) |  |  | — |  |
| Increase (decrease) due to recognition of revenue based on transfer of control of performance obligations |  |  | 10,351 |  |  |  | — |  |  |  | (25,710 | ) |
| Other changes and FX impact |  |  | 7 |  |  |  | (11 | ) |  |  | (288 | ) |
| Ending balance as of September 30, 2023 |  | $ | 6,335 |  |  | $ | 2,075 |  |  | $ | 59,046 |  |

[0001437749-23-029753:notes:28]
|  |  | Unbilled Accounts Receivable |  |  | Deferred Program Costs |  |  | Contract Liabilities |  |
| Beginning balance as of March 31, 2022 |  | $ | 6,492 |  |  | $ | 858 |  |  | $ | 30,034 |  |
| Increases for costs incurred to fulfill performance obligations |  |  | — |  |  |  | 782 |  |  |  | — |  |
| Increase (decrease) due to customer billings |  |  | (7,322 | ) |  |  | — |  |  |  | 33,141 |  |
| Decrease due to cost recognition on completed performance obligations |  |  | — |  |  |  | (697 | ) |  |  | — |  |
| Increase (decrease) due to recognition of revenue based on transfer of control of performance obligations |  |  | 7,342 |  |  |  | — |  |  |  | (26,857 | ) |
| Other changes and FX impact |  |  | — |  |  |  | (47 | ) |  |  | (863 | ) |
| Ending balance as of September 30, 2022 |  | $ | 6,512 |  |  | $ | 896 |  |  | $ | 35,455 |  |

[0001437749-23-029753:notes:29]
The Company’s remaining performance obligations represent the unrecognized revenue value of the Company’s contractual commitments. The Company’s performance obligations  may vary significantly each reporting period based on the timing of major new contractual commitments. As of  September 30, 2023, the Company had outstanding performance obligations on existing contracts under ASC 606 to be recognized in the next twelve months of approximately $128.3 million. There are also approximately $43.2 million of outstanding performance obligations to be recognized over a period of thirteen to sixty months. The remaining performance obligations are subject to customer actions and therefore the timing of revenue recognition cannot be reasonably estimated.

[0001437749-23-029753:notes:30]
The following table sets forth customers who represented 10% or more of the Company’s total revenues for the three and six months ended  September 30, 2023 and 2022:

[0001437749-23-029753:notes:31]
|  |  |  | Three Months Ended |  |  | Six Months Ended |  |
|  | Reportable |  | September 30, |  |  | September 30, |  |
|  | Segment |  | 2023 |  |  | 2022 |  |  | 2023 |  |  | 2022 |  |
| Inox Wind Limited | Wind |  |  | 12 | % |  | <10% |  |  |  | 12 | % |  | <10% |  |
| Fuji Bridex Pte Ltd | Grid |  |  | <10% |  |  |  | 17 | % |  |  | <10% |  |  |  | 13 | % |
| Gray Construction, Inc. | Grid |  |  | 11 | % |  |  | <10% |  |  |  | <10% |  |  |  | <10% |  |
| Ascend Performance Materials Ops LLC | Grid |  |  | <10% |  |  |  | 12 | % |  |  | <10% |  |  |  | <10% |  |


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001437749-23-029753:notes:32]
[same as prior period, unchanged from 0001437749-23-022793:notes:31]

[0001437749-23-029753:notes:33]
The Company accounts for its stock-based compensation at fair value. The following table summarizes stock-based compensation expense by financial statement line item for the three and six months ended  September 30, 2023 and 2022 (in thousands):

[0001437749-23-029753:notes:34]
|  |  | Three Months Ended September 30, |  |  | Six Months Ended September 30, |  |
|  |  | 2023 |  |  | 2022 |  |  | 2023 |  |  | 2022 |  |
| Cost of revenues |  | $ | 59 |  |  | $ | 78 |  |  | $ | 169 |  |  | $ | 107 |  |
| Research and development |  |  | 156 |  |  |  | 177 |  |  |  | 311 |  |  |  | 355 |  |
| Selling, general and administrative |  |  | 896 |  |  |  | 764 |  |  |  | 1,988 |  |  |  | 1,590 |  |
| Total |  | $ | 1,111 |  |  | $ | 1,019 |  |  | $ | 2,468 |  |  | $ | 2,052 |  |

[0001437749-23-029753:notes:35]
The Company issued 9,000 shares and 681,500 shares of restricted stock during the three and six months ended  September 30, 2023, respectively. The Company issued no shares of immediately vested common stock during the three months ended  September 30, 2023 and 53,675 shares of immediately vested common stock during the six months ended  September 30, 2023. The Company issued 338,500 shares of restricted stock during the three and six months ended  September 30, 2022. The Company issued no shares of immediately vested common stock during the three months ended  September 30, 2022 and 25,806 shares of immediately vested common stock during the six months ended  September 30, 2022. These restricted stock awards generally vest over 2-3 years. Awards for restricted stock include both time-based and performance-based awards. For options and restricted stock awards that vest upon the passage of time, expense is being recorded over the vesting period. Performance-based awards are expensed over the requisite service period based on probability of achievement.

[0001437749-23-029753:notes:36]
The estimated fair value of the Company’s stock-based awards, less expected annual forfeitures, is amortized over the awards’ service period. The total unrecognized compensation cost for unvested stock options was less than $0.1 million for the six months ended  September 30, 2023. This expense will be recognized over a weighted average of approximately 0.7 years. The total unrecognized compensation cost for unvested outstanding restricted stock was $6.8 million for the six months ended  September 30, 2023. This expense will be recognized over a weighted-average expense period of approximately 2.0 years.

[0001437749-23-029753:notes:37]
The Company granted no stock options during the three and six months ended  September 30, 2023. The Company granted no stock options in the three months ended  September 30, 2022, and 20,564 stock options during the six months ended  September 30, 2022. The stock options granted during the six months ended  September 30, 2022 will vest over 2 years. The weighted average assumptions used in the Black Scholes valuation model for stock options granted during the six months ended  September 30, 2022 are as follows:

[0001437749-23-029753:notes:38]
[same as prior period, unchanged from 0001437749-23-022793:notes:37]


## us-gaap:EarningsPerShareTextBlock

[0001437749-23-029753:notes:39]
[same as prior period, unchanged from 0001437749-23-022793:notes:38]

[0001437749-23-029753:notes:40]
Basic net loss per share (“EPS”) is computed by dividing net loss by the weighted-average number of common shares outstanding for the period. Where applicable, diluted EPS is computed by dividing the net loss by the weighted-average number of common shares and dilutive common equivalent shares outstanding during the period, calculated using the treasury stock method. Common equivalent shares include the effect of restricted stock, exercise of stock options and warrants and contingently issuable shares. Stock options and warrants that are out-of-the-money with exercise prices greater than the average market price of the underlying common shares and shares of performance-based restricted stock where the contingency was not met are excluded from the computation of diluted EPS as the effect of their inclusion would be anti-dilutive. For each of the three and six months ended  September 30, 2023, 1.0 million shares were not included in the calculation of diluted EPS. Of these, 1.0 million relate to shares tied to the contingent consideration derivative liability for which the contingency has not yet been met, and less than 0.1 million relate to outstanding stock options as they were considered anti-dilutive. For each of the three and six months ended  September 30, 2022, 1.1 million shares were not included in the calculation of diluted EPS. Of these, 1.0 million relate to shares tied to the contingent consideration derivative liability for which the contingency has not yet been met, and 0.1 million relate to outstanding stock options as they were considered anti-dilutive.

[0001437749-23-029753:notes:41]
The following table reconciles the numerators and denominators of the earnings per share calculation for the three and six months ended  September 30, 2023 and 2022 (in thousands, except per share data):

[0001437749-23-029753:notes:42]
|  |  | Three Months Ended September 30, |  |  | Six Months Ended September 30, |  |
|  |  | 2023 |  |  | 2022 |  |  | 2023 |  |  | 2022 |  |
| Numerator: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net loss |  | $ | (2,485 | ) |  | $ | (9,881 | ) |  | $ | (7,883 | ) |  | $ | (18,590 | ) |
| Denominator: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Weighted-average shares of common stock outstanding |  |  | 30,283 |  |  |  | 28,775 |  |  |  | 29,996 |  |  |  | 28,648 |  |
| Weighted-average shares subject to repurchase |  |  | (1,455 | ) |  |  | (908 | ) |  |  | (1,451 | ) |  |  | (934 | ) |
| Shares used in per-share calculation ― basic |  |  | 28,828 |  |  |  | 27,867 |  |  |  | 28,545 |  |  |  | 27,714 |  |
| Shares used in per-share calculation ― diluted |  |  | 28,828 |  |  |  | 27,867 |  |  |  | 28,545 |  |  |  | 27,714 |  |
| Net loss per share ― basic |  | $ | (0.09 | ) |  | $ | (0.35 | ) |  | $ | (0.28 | ) |  | $ | (0.67 | ) |
| Net loss per share ― diluted |  | $ | (0.09 | ) |  | $ | (0.35 | ) |  | $ | (0.28 | ) |  | $ | (0.67 | ) |


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001437749-23-029753:notes:43]
[same as prior period, unchanged from 0001437749-23-022793:notes:42]

[0001437749-23-029753:notes:44]
[same as prior period, unchanged from 0001437749-23-022793:notes:43]

[0001437749-23-029753:notes:45]
Goodwill represents the difference between the purchase price and the fair value of the identifiable tangible and intangible net assets when accounted for using the purchase method of accounting. Goodwill is not amortized but reviewed for impairment. Goodwill is reviewed annually on  February 28th and whenever events or changes in circumstances indicate that the carrying value of the goodwill might not be recoverable.

[0001437749-23-029753:notes:46]
There were no changes to goodwill during the six months ended  September 30, 2023 or year ended  March 31, 2023.

[0001437749-23-029753:notes:47]
The Company did not identify any triggering events in the three and six months ended  September 30, 2023 that would require interim impairment testing of goodwill.

[0001437749-23-029753:notes:48]
[same as prior period, unchanged from 0001437749-23-022793:notes:47]

[0001437749-23-029753:notes:49]
Intangible assets at  September 30, 2023 and  March 31, 2023 consisted of the following (in thousands):

[0001437749-23-029753:notes:50]
|  |  | September 30, 2023 |  |  | March 31, 2023 |  |  |  |  |  |
|  |  | Gross Amount |  |  | Accumulated Amortization |  |  | Net Book Value |  |  | Gross Amount |  |  | Accumulated Amortization |  |  | Net Book Value |  |  | Estimated Useful Life |  |
| Backlog |  |  | 681 |  |  |  | (681 | ) |  |  | — |  |  |  | 681 |  |  |  | (675 | ) |  | $ | 6 |  |  |  | 2 |  |
| Trade name and trademarks |  |  | 1,800 |  |  |  | — |  |  |  | 1,800 |  |  |  | 1,800 |  |  |  | — |  |  |  | 1,800 |  |  | Indefinite |  |
| Customer relationships |  |  | 9,600 |  |  |  | (5,815 | ) |  |  | 3,785 |  |  |  | 9,600 |  |  |  | (4,980 | ) |  |  | 4,620 |  |  |  | 7 |  |
| Core technology and know-how |  |  | 5,970 |  |  |  | (4,110 | ) |  |  | 1,860 |  |  |  | 5,970 |  |  |  | (3,869 | ) |  |  | 2,101 |  |  |  | 5-10 |  |
| Intangible assets |  | $ | 18,051 |  |  | $ | (10,606 | ) |  | $ | 7,445 |  |  | $ | 18,051 |  |  | $ | (9,524 | ) |  | $ | 8,527 |  |  |  |  |  |

[0001437749-23-029753:notes:51]
The Company recorded intangible amortization expense related to customer relationship and core technology and know-how of $0.5 million and $1.1 million, in the three and six months ended  September 30, 2023, respectively, and $0.7 million and $1.4 million in the three and six months ended  September 30, 2022, respectively. Additionally, the Company recorded no intangible amortization related to backlog that is reported in cost of revenues in the three months ended  September 30, 2023 and less than $0.1 million in the six months ended  September 30, 2023. The Company recorded no intangible amortization related to backlog in the three months ended  September 30, 2022 and the Company recorded less than $0.1 million related to backlog that is reported in cost of revenues in the six months ended  September 30, 2022, respectively.

[0001437749-23-029753:notes:52]
[same as prior period, unchanged from 0001437749-23-022793:notes:51]

[0001437749-23-029753:notes:53]
| Years ending March 31, |  | Total |  |
| 2024 |  |  | 1,076 |  |
| 2025 |  |  | 1,648 |  |
| 2026 |  |  | 1,221 |  |
| 2027 |  |  | 1,085 |  |
| 2028 |  |  | 543 |  |
| Thereafter |  |  | 72 |  |
| Total |  | $ | 5,645 |  |

[0001437749-23-029753:notes:54]
[same as prior period, unchanged from 0001437749-23-022793:notes:53]


## us-gaap:FairValueDisclosuresTextBlock

[0001437749-23-029753:notes:55]
[same as prior period, unchanged from 0001437749-23-022793:notes:54]

[0001437749-23-029753:notes:56]
[same as prior period, unchanged from 0001437749-23-022793:notes:55]

[0001437749-23-029753:notes:57]
[same as prior period, unchanged from 0001437749-23-022793:notes:56]

[0001437749-23-029753:notes:58]
The Company provides a gross presentation of activity within Level 3 measurement roll-forward and details of transfers in and out of Level 1 and 2 measurements. A change in the hierarchy of an investment from its current level is reflected in the period during which the pricing methodology of such investment changes. Disclosure of the transfer of securities from Level 1 to Level 2 or Level 3 is made in the event that the related security is significant to total cash and investments. The Company did not have any transfers of assets and liabilities from Level 1, Level 2 or Level 3 of the fair value measurement hierarchy during the six months ended  September 30, 2023.

[0001437749-23-029753:notes:59]
[same as prior period, unchanged from 0001437749-23-022793:notes:58]

[0001437749-23-029753:notes:60]
[same as prior period, unchanged from 0001437749-23-022793:notes:59]

[0001437749-23-029753:notes:61]
[same as prior period, unchanged from 0001437749-23-022793:notes:60]

[0001437749-23-029753:notes:62]
[same as prior period, unchanged from 0001437749-23-022793:notes:61]

[0001437749-23-029753:notes:63]
[same as prior period, unchanged from 0001437749-23-022793:notes:62]

[0001437749-23-029753:notes:64]
Contingent consideration relates to the earnout payment set forth in the Stock Purchase Agreement governing the acquisition of Northeast Power Systems, Inc ("NEPSI") that provides that the selling stockholders  may receive up to an additional 1,000,000 shares of common stock of the Company upon the achievement of certain specified revenue objectives over varying periods of up to four years following the NEPSI Acquisition Date. See Note 13, "Contingent Consideration" for further discussion. The Company relied on a Monte Carlo method to determine the fair value of the contingent consideration on the closing of the acquisition of NEPSI and continues to revalue the fair value of the contingent consideration using the same method at each subsequent balance sheet date until the contingencies are resolved and the shares to be issued are determined, with the change in fair value recorded in the current period operating loss.

[0001437749-23-029753:notes:65]
The following table provides the assets and liabilities carried at fair value on a recurring basis, measured as of  September 30, 2023 and  March 31, 2023 (in thousands):

[0001437749-23-029753:notes:66]
|  |  | Total Carrying Value |  |  | Quoted Prices in Active Markets (Level 1) |  |  | Significant Other Observable Inputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |
| September 30, 2023: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash equivalents |  | $ | 5,157 |  |  | $ | 5,157 |  |  | $ | — |  |  | $ | — |  |
| Derivative liabilities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Contingent consideration |  | $ | 3,470 |  |  | $ | — |  |  | $ | — |  |  | $ | 3,470 |  |

[0001437749-23-029753:notes:67]
[same as prior period, unchanged from 0001437749-23-022793:notes:66]

[0001437749-23-029753:notes:68]
The table below reflects the activity for the Company’s contingent consideration derivative liability measured at fair value on a recurring basis (in thousands):

[0001437749-23-029753:notes:69]
|  |  | Acquisition Contingent Consideration |  |
| Balance at March 31, 2022 |  | $ | 1,200 |  |
| Change in fair value |  |  | 70 |  |
| Balance at March 31, 2023 |  |  | 1,270 |  |
| Change in fair value |  |  | 2,200 |  |
| Balance at September 30, 2023 |  | $ | 3,470 |  |


## amsc:AccountsReceivableTextBlock

[0001437749-23-029753:notes:70]
[same as prior period, unchanged from 0001437749-23-022793:notes:69]

[0001437749-23-029753:notes:71]
Accounts receivable at  September 30, 2023 and  March 31, 2023 consisted of the following (in thousands):

[0001437749-23-029753:notes:72]
|  |  | September 30, 2023 |  |  | March 31, 2023 |  |
| Accounts receivable (billed) |  | $ | 21,174 |  |  | $ | 20,707 |  |
| Accounts receivable (unbilled) |  |  | 6,335 |  |  |  | 9,958 |  |
| Accounts receivable, net |  | $ | 27,509 |  |  | $ | 30,665 |  |


## us-gaap:InventoryDisclosureTextBlock

[0001437749-23-029753:notes:73]
[same as prior period, unchanged from 0001437749-23-022793:notes:72]

[0001437749-23-029753:notes:74]
Inventory, net of reserves, at  September 30, 2023 and  March 31, 2023 consisted of the following (in thousands):

[0001437749-23-029753:notes:75]
|  |  | September 30, 2023 |  |  | March 31, 2023 |  |
| Raw materials |  | $ | 19,337 |  |  | $ | 16,654 |  |
| Work-in-process |  |  | 22,714 |  |  |  | 15,200 |  |
| Finished goods |  |  | 3,709 |  |  |  | 2,996 |  |
| Deferred program costs |  |  | 2,075 |  |  |  | 2,136 |  |
| Net inventory |  | $ | 47,835 |  |  | $ | 36,986 |  |

[0001437749-23-029753:notes:76]
The Company recorded inventory write-downs of $0.7 million and $0.7 million for the three months ended  September 30, 2023 and 2022, respectively. The Company recorded inventory write-downs of $1.1 million and $1.0 million for the six months ended  September 30, 2023 and 2022, respectively. These write-downs were based on the Company's evaluation of its inventory on hand for excess quantities and obsolescence.

[0001437749-23-029753:notes:77]
Deferred program costs as of  September 30, 2023 and  March 31, 2023, primarily represent costs incurred on programs where the Company needs to complete performance obligations before the related revenue and costs will be recognized.


## amsc:PrepaidAndOtherCurrentAssetsTextBlock

[0001437749-23-029753:notes:78]
[same as prior period, unchanged from 0001437749-23-022793:notes:77]

[0001437749-23-029753:notes:79]
During fiscal 2022, the Company conducted an analysis as to whether it was entitled to employee retention credits (“ERC”) under the CARES Act as amended by the Taxpayer Certainty and Disaster Tax Relief Act of 2020 and the American Rescue Plan Act of 2021.  Based on the analysis, the Company determined that it was entitled to an ERC of approximately $3.3 million related to payroll taxes paid in the first and second quarters of 2021 and the first quarter of 2020.  The Company determined it met all the criteria required under the gross receipts test of the applicable Internal Revenue Service regulations related to ERCs.

[0001437749-23-029753:notes:80]
[same as prior period, unchanged from 0001437749-23-022793:notes:79]

[0001437749-23-029753:notes:81]
The Company recorded a $3.3 million receivable in Prepaid expenses and other current assets and a benefit of $1.8 million to Cost of revenues, $0.8 million to SG&A and $0.7 million to Research and development in the fiscal year ended  March 31, 2023 for the ERC that is expected to be received based on the amended filings. During the six months ended  September 30, 2023, the Company received $3.0 million for the initial claims that were processed. The remaining balance is expected to be received during the remainder of fiscal 2023.


## us-gaap:PropertyPlantAndEquipmentDisclosureTextBlock

[0001437749-23-029753:notes:82]
[same as prior period, unchanged from 0001437749-23-022793:notes:81]

[0001437749-23-029753:notes:83]
The cost and accumulated depreciation of property, plant and equipment at  September 30, 2023 and  March 31, 2023 are as follows (in thousands):

[0001437749-23-029753:notes:84]
|  |  | September 30, 2023 |  |  | March 31, 2023 |  |
| Land |  | $ | 980 |  |  | $ | 980 |  |
| Construction in progress - equipment |  |  | 342 |  |  |  | 748 |  |
| Buildings |  |  | 5,416 |  |  |  | 5,416 |  |
| Equipment and software |  |  | 43,915 |  |  |  | 43,156 |  |
| Finance lease - right of use asset |  |  | 1 |  |  |  | 1 |  |
| Furniture and fixtures |  |  | 1,531 |  |  |  | 1,535 |  |
| Leasehold improvements |  |  | 6,812 |  |  |  | 6,815 |  |
| Property, plant and equipment, gross |  |  | 58,997 |  |  |  | 58,651 |  |
| Less accumulated depreciation |  |  | (47,414 | ) |  |  | (46,342 | ) |
| Property, plant and equipment, net |  | $ | 11,583 |  |  | $ | 12,309 |  |

[0001437749-23-029753:notes:85]
Depreciation expense was $0.6 million and $0.7 million for the three months ended  September 30, 2023 and 2022, respectively. Depreciation expense was $1.2 million and $1.4 million for the six months ended  September 30, 2023 and 2022, respectively.


## us-gaap:AccountsPayableAndAccruedLiabilitiesDisclosureTextBlock

[0001437749-23-029753:notes:86]
[same as prior period, unchanged from 0001437749-23-022793:notes:85]

[0001437749-23-029753:notes:87]
Accounts payable and accrued expenses at  September 30, 2023 and  March 31, 2023 consisted of the following (in thousands):

[0001437749-23-029753:notes:88]
|  |  | September 30, 2023 |  |  | March 31, 2023 |  |
| Accounts payable |  | $ | 11,393 |  |  | $ | 13,935 |  |
| Accrued inventories in-transit |  |  | 1,123 |  |  |  | 2,267 |  |
| Accrued other miscellaneous expenses |  |  | 4,237 |  |  |  | 3,870 |  |
| Accrued contract loss |  |  | 2,584 |  |  |  | 3,464 |  |
| Advanced deposits |  |  | 1,156 |  |  |  | 5,653 |  |
| Accrued compensation |  |  | 6,041 |  |  |  | 5,430 |  |
| Income taxes payable |  |  | 297 |  |  |  | 409 |  |
| Accrued product warranty |  |  | 1,892 |  |  |  | 2,638 |  |
| Accrued restructuring |  |  | 226 |  |  |  | 717 |  |
| Total |  | $ | 28,949 |  |  | $ | 38,383 |  |

[0001437749-23-029753:notes:89]
[same as prior period, unchanged from 0001437749-23-022793:notes:88]

[0001437749-23-029753:notes:90]
[same as prior period, unchanged from 0001437749-23-022793:notes:89]

[0001437749-23-029753:notes:91]
|  |  | Three Months Ended September 30, |  |  | Six Months Ended September 30, |  |
|  |  | 2023 |  |  | 2022 |  |  | 2023 |  |  | 2022 |  |
| Balance at beginning of period |  | $ | 1,926 |  |  | $ | 1,942 |  |  | $ | 2,638 |  |  | $ | 2,066 |  |
| Provisions for warranties during the period |  |  | 644 |  |  |  | 479 |  |  |  | 852 |  |  |  | 656 |  |
| Settlements during the period |  |  | (678 | ) |  |  | (368 | ) |  |  | (1,598 | ) |  |  | (669 | ) |
| Balance at end of period |  | $ | 1,892 |  |  | $ | 2,053 |  |  | $ | 1,892 |  |  | $ | 2,053 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0001437749-23-029753:notes:92]
[same as prior period, unchanged from 0001437749-23-022793:notes:91]

[0001437749-23-029753:notes:93]
The Company recorded income tax expense of $0.1 million and $0.2 million in the three and six months ended  September 30, 2023, respectively. The Company recorded an income tax benefit of less than $0.1 million and an income tax expense of less than $0.1 million in the three and six months ended  September 30, 2022, respectively.

[0001437749-23-029753:notes:94]
Accounting for income taxes requires a two-step approach to recognizing and measuring uncertain tax positions. The first step is to evaluate the tax position for recognition by determining if, based on the technical merits, it is more likely than not the position will be sustained upon audit, including resolution of related appeals or litigation processes, if any. The second step is to measure the tax benefit as the largest amount that is more than 50% likely to be realized upon ultimate settlement.  The Company re-evaluates these uncertain tax positions on a quarterly basis. The evaluation is based on factors including, but not limited to, changes in facts or circumstances, changes in tax law, effectively settled issues under audit and new audit activity.  Any changes in these factors could result in the recognition of a tax benefit or an additional charge to the tax provision. The Company did not identify any uncertain tax positions in the six months ended  September 30, 2023 and did not have any gross unrecognized tax benefits as of  September 30, 2023.


## amsc:BusinessCombinationContingentConsiderationTextBlock

[0001437749-23-029753:notes:95]
[same as prior period, unchanged from 0001437749-23-022793:notes:94]

[0001437749-23-029753:notes:96]
[same as prior period, unchanged from 0001437749-23-022793:notes:95]

[0001437749-23-029753:notes:97]
On  October 1, 2020 (the "NEPSI Acquisition Date"), the Company entered into a Stock Purchase Agreement (the "NEPSI Stock Purchase Agreement") with the selling stockholders named therein. Pursuant to the terms of the NEPSI Stock Purchase Agreement and concurrently with entering into such agreement, the Company acquired all of the issued and outstanding (i) shares of capital stock of NEPSI, and (ii) membership interests of Northeast Power Realty, LLC, a New York limited liability company, which holds the real property that serves as NEPSI's headquarters (the "NEPSI Acquisition"). NEPSI is a U.S.-based global provider of medium-voltage metal-enclosed power capacitor banks and harmonic filter banks for use on electric power systems. NEPSI is a wholly-owned subsidiary of the Company and is operated by its Grid business unit. The purchase price was $26.0 million in cash and 873,657 restricted shares of common stock of the Company. As part of the transaction, the selling stockholders  may receive up to an additional 1,000,000 shares of common stock of the Company upon the achievement of certain specified revenue objectives during varying periods of up to four years following closing of the NEPSI Acquisition.  NEPSI has recognized revenues in excess of $75.0 million during the three years after the NEPSI Acquisition Date. As a result, the Company expects to issue 400,000 shares of common stock of the Company to the selling stockholders during the quarter ending  December 31, 2023, upon certification of the achievement of specified earnout revenue objectives.

[0001437749-23-029753:notes:98]
The Company evaluated the NEPSI Acquisition earnout payment set forth in the NEPSI Stock Purchase Agreement, which is expected to require settlement in the Company's common stock, and determined the contingent consideration qualified for liability classification and derivative treatment under ASC 815, Derivatives and Hedging. As a result, for each period, the fair value of the contingent consideration will be remeasured and the resulting gain or loss will be recognized in operating expenses until the share amount is fixed.

[0001437749-23-029753:notes:99]
[same as prior period, unchanged from 0001437749-23-022793:notes:98]

[0001437749-23-029753:notes:100]
|  |  |  | September 30, |  |  |  | June 30, |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Fiscal Year 2023 |  |  | 2023 |  |  |  | 2023 |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Revenue risk premium |  |  | 5.30 | % |  |  | 5.20 | % |  |  |  |  |  |  |  |  |  |  |  |  |
| Revenue volatility |  |  | 27.5 | % |  |  | 23 | % |  |  |  |  |  |  |  |  |  |  |  |  |
| Stock Price |  | $ | 7.55 |  |  | $ | 6.26 |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Payment delay (days) |  |  | 80 |  |  |  | 80 |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Fair value (millions) |  | $ | 3.5 |  |  | $ | 2.6 |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | March 31, |  |  | December 31, |  |  | September 30, |  |  | June 30, |  |  | March 31, |  |
| Fiscal Year 2022 |  | 2023 |  |  | 2022 |  |  | 2022 |  |  | 2022 |  |  | 2022 |  |
| Revenue risk premium |  |  | 5.30 | % |  |  | 5.30 | % |  |  | 5.20 | % |  |  | 6.60 | % |  |  | 6.50 | % |
| Revenue volatility |  |  | 25 | % |  |  | 25 | % |  |  | 25 | % |  |  | 30 | % |  |  | 33 | % |
| Stock Price |  | $ | 4.91 |  |  | $ | 3.68 |  |  | $ | 4.38 |  |  | $ | 5.18 |  |  | $ | 7.61 |  |
| Payment delay (days) |  |  | 80 |  |  |  | 80 |  |  |  | 80 |  |  |  | 80 |  |  |  | 80 |  |
| Fair value (millions) |  | $ | 1.3 |  |  | $ | 0.9 |  |  | $ | 1.1 |  |  | $ | 1.4 |  |  | $ | 1.2 |  |

[0001437749-23-029753:notes:101]
The Company recorded net losses of $0.9 million and $2.2 million resulting from the increases in the fair value of the contingent consideration in the three and six months ended  September 30, 2023, respectively. The Company recorded a net gain of $0.3 million and $0.1 million resulting from the decrease in the fair value of the contingent consideration in the three and six months ended  September 30, 2022, respectively.


## us-gaap:DebtDisclosureTextBlock

[0001437749-23-029753:notes:102]
14. Debt

[0001437749-23-029753:notes:103]
As part of the acquisition of Neeltran, the Company identified four equipment financing agreements that Neeltran had entered into prior to the acquisition of Neeltran on  May 6, 2021. The current debt balance is $0.1 million as of  September 30, 2023 and  March 31, 2023.


## us-gaap:LesseeOperatingLeasesTextBlock

[0001437749-23-029753:notes:104]
[same as prior period, unchanged from 0001437749-23-022793:notes:103]

[0001437749-23-029753:notes:105]
[same as prior period, unchanged from 0001437749-23-022793:notes:104]

[0001437749-23-029753:notes:106]
[same as prior period, unchanged from 0001437749-23-022793:notes:105]

[0001437749-23-029753:notes:107]
[same as prior period, unchanged from 0001437749-23-022793:notes:106]

[0001437749-23-029753:notes:108]
[same as prior period, unchanged from 0001437749-23-022793:notes:107]

[0001437749-23-029753:notes:109]
[same as prior period, unchanged from 0001437749-23-022793:notes:108]

[0001437749-23-029753:notes:110]
[same as prior period, unchanged from 0001437749-23-022793:notes:109]

[0001437749-23-029753:notes:111]
As of  September 30, 2023, the right-of-use asset related to the finance lease, net of accumulated amortization is less than $0.1 million, and is included in the property and equipment, net on the Company's condensed consolidated balance sheet.

[0001437749-23-029753:notes:112]
[same as prior period, unchanged from 0001437749-23-022793:notes:111]

[0001437749-23-029753:notes:113]
Supplemental balance sheet information related to leases at  September 30, 2023, and  March 31, 2023 are as follows (in thousands):

[0001437749-23-029753:notes:114]
|  |  | September 30, 2023 |  |  | March 31, 2023 |  |
| Leases: |  |  |  |  |  |  |  |  |
| Right-of-use assets - Financing |  | $ | - |  |  |  | 1 |  |
| Right-of-use assets - Operating |  |  | 2,493 |  |  |  | 2,857 |  |
| Total right-of-use assets |  |  | 2,493 |  |  |  | 2,858 |  |
| Lease liabilities - ST Financing |  | $ | - |  |  |  | 1 |  |
| Lease liabilities - ST Operating |  |  | 696 |  |  |  | 807 |  |
| Lease liabilities - LT Operating |  |  | 1,929 |  |  |  | 2,184 |  |
| Total lease liabilities |  | $ | 2,625 |  |  |  | 2,992 |  |
| Weighted-average remaining lease term |  |  | 3.7 years |  |  |  | 3.95 years |  |
| Weighted-average discount rate |  |  | 8.48 | % |  |  | 6.46 | % |

[0001437749-23-029753:notes:115]
The costs related to the Company's finance lease are not material. The costs related to the Company's operating leases for the three and six months ended  September 30, 2023 and 2022 are as follows (in thousands):

[0001437749-23-029753:notes:116]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | September 30, 2023 |  |  | September 30, 2023 |  |
| Operating Leases: |  |  |  |  |  |  |  |  |
| Operating lease costs - fixed |  | $ | 255 |  |  | $ | 514 |  |
| Operating lease costs - variable |  |  | 40 |  |  |  | 79 |  |
| Short-term lease costs |  |  | 37 |  |  |  | 74 |  |
| Total lease costs |  | $ | 332 |  |  | $ | 667 |  |

[0001437749-23-029753:notes:117]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | September 30, 2022 |  |  | September 30, 2022 |  |
| Operating Leases: |  |  |  |  |  |  |  |  |
| Operating lease costs - fixed |  | $ | 262 |  |  | $ | 504 |  |
| Operating lease costs - variable |  |  | 41 |  |  |  | 76 |  |
| Short-term lease costs |  |  | 30 |  |  |  | 61 |  |
| Total lease costs |  | $ | 333 |  |  | $ | 641 |  |

[0001437749-23-029753:notes:118]
[same as prior period, unchanged from 0001437749-23-022793:notes:117]

[0001437749-23-029753:notes:119]
|  |  | Leases |  |
| Year ending March 31, |  |  |  |  |
| 2024 |  | $ | 472 |  |
| 2025 |  |  | 803 |  |
| 2026 |  |  | 755 |  |
| 2027 |  |  | 614 |  |
| 2028 |  |  | 392 |  |
| Thereafter |  |  | 15 |  |
| Total minimum lease payments |  |  | 3,051 |  |
| Less: interest |  |  | (426 | ) |
| Present value of lease liabilities |  | $ | 2,625 |  |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001437749-23-029753:notes:120]
16. Commitments and Contingencies

[0001437749-23-029753:notes:121]
Legal Contingencies

[0001437749-23-029753:notes:122]
From time to time, the Company is involved in legal and administrative proceedings and claims of various types. The Company records a liability in its condensed consolidated financial statements for these matters when a loss is known or considered probable and the amount can be reasonably estimated. The Company reviews these estimates each accounting period as additional information is known and adjusts the loss provision when appropriate. If a matter is both probable to result in a liability and the amounts of loss can be reasonably estimated, the Company estimates and discloses the possible loss or range of loss to the extent necessary to make the condensed consolidated financial statements not misleading. If the loss is not probable or cannot be reasonably estimated, a liability is not recorded in its condensed consolidated financial statements.

[0001437749-23-029753:notes:123]
Other

[0001437749-23-029753:notes:124]
The Company enters into long-term construction contracts with customers that require the Company to obtain performance bonds. The Company is required to deposit an amount equivalent to some or all the face amount of the performance bonds into an escrow account until the termination of the bond. When the performance conditions are met, amounts deposited as collateral for the performance bonds are returned to the Company. In addition, the Company has various contractual arrangements in which minimum quantities of goods or services have been committed to be purchased on an annual basis.

[0001437749-23-029753:notes:125]
As of  September 30, 2023, the Company had $0.6 million of restricted cash included in long-term assets and $0.5 million of restricted cash included in current assets. As of  March 31, 2023, the Company had $0.6 million of restricted cash included in long term assets and $1.7 million of restricted cash included in current assets. These amounts included in restricted cash primarily represent deposits to secure letters of credit for various supply contracts and long-term projects or collateral deposits. These deposits are held in interest bearing accounts.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001437749-23-029753:notes:126]
[same as prior period, unchanged from 0001437749-23-022793:notes:125]

[0001437749-23-029753:notes:127]
The Company accounts for charges resulting from operational restructuring actions in accordance with ASC Topic 420, Exit or Disposal Cost Obligations (“ASC 420”) and ASC Topic 712, Compensation—Nonretirement Postemployment Benefits (“ASC 712”). In accounting for these obligations, the Company is required to make assumptions related to the amounts of employee severance, benefits, and related costs and the time period over which leased facilities will remain vacant, sublease terms, sublease rates and discount rates. Estimates and assumptions are based on the best information available at the time the obligation arises. These estimates are reviewed and revised as facts and circumstances dictate; changes in these estimates could have a material effect on the amount accrued on the condensed consolidated balance sheet.

[0001437749-23-029753:notes:128]
On  January 24, 2023, the Company approved a plan to reduce its global workforce by approximately 5%, effective as of such date. The purpose of the workforce reduction was to reduce operating expenses to better align with the Company’s current revenues. In fiscal 2022 through second quarter of fiscal 2023, the Company recorded restructuring charges of $1.0 million as a result of this reduction in force, which was comprised of severance pay. All amounts related to these restructuring activities are expected to be paid by  March 31, 2024.

[0001437749-23-029753:notes:129]
The following table presents restructuring charges and cash payments during the six months ended  September 30, 2023 and year ended  March 31, 2023 (in thousands):

[0001437749-23-029753:notes:130]
|  |  | Severance pay |  |
|  |  | and benefits |  |
| Accrued restructuring balance at April 1, 2023 |  | $ | 717 |  |
| Charges to operations |  |  | (14 | ) |
| Cash payments |  |  | (477 | ) |
| Accrued restructuring balance at September 30, 2023 |  | $ | 226 |  |

[0001437749-23-029753:notes:131]
[same as prior period, unchanged from 0001437749-23-022793:notes:130]

[0001437749-23-029753:notes:132]
All restructuring charges discussed above are included within restructuring in the Company’s condensed consolidated statements of operations. The Company includes accrued restructuring within accounts payable and accrued expenses in the condensed consolidated balance sheets.  The Company's restructuring charges relate primarily to the Grid business segment operations in the United States.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001437749-23-029753:notes:133]
[same as prior period, unchanged from 0001437749-23-022793:notes:132]

[0001437749-23-029753:notes:134]
[same as prior period, unchanged from 0001437749-23-022793:notes:133]

[0001437749-23-029753:notes:135]
[same as prior period, unchanged from 0001437749-23-022793:notes:134]

[0001437749-23-029753:notes:136]
[same as prior period, unchanged from 0001437749-23-022793:notes:135]

[0001437749-23-029753:notes:137]
[same as prior period, unchanged from 0001437749-23-022793:notes:136]

[0001437749-23-029753:notes:138]
|  |  | Three Months Ended September 30, |  |  | Six Months Ended September 30, |  |
|  |  | 2023 |  |  | 2022 |  |  | 2023 |  |  | 2022 |  |
| Revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Grid |  | $ | 28,515 |  |  | $ | 25,698 |  |  | $ | 54,251 |  |  | $ | 45,527 |  |
| Wind |  |  | 5,489 |  |  |  | 1,982 |  |  |  | 10,007 |  |  |  | 4,833 |  |
| Total |  | $ | 34,004 |  |  | $ | 27,680 |  |  | $ | 64,258 |  |  | $ | 50,360 |  |

[0001437749-23-029753:notes:139]
|  |  | Three Months Ended September 30, |  |  | Six Months Ended September 30, |  |
|  |  | 2023 |  |  | 2022 |  |  | 2023 |  |  | 2022 |  |
| Operating income (loss): |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Grid |  | $ | (679 | ) |  | $ | (6,495 | ) |  | $ | (2,649 | ) |  | $ | (13,776 | ) |
| Wind |  |  | 252 |  |  |  | (868 | ) |  |  | (398 | ) |  |  | (1,254 | ) |
| Unallocated corporate expenses |  |  | (1,942 | ) |  |  | (729 | ) |  |  | (4,655 | ) |  |  | (1,931 | ) |
| Total |  | $ | (2,369 | ) |  | $ | (8,092 | ) |  | $ | (7,702 | ) |  | $ | (16,961 | ) |

[0001437749-23-029753:notes:140]
[same as prior period, unchanged from 0001437749-23-022793:notes:139]

[0001437749-23-029753:notes:141]
Unallocated corporate expenses consisted of a loss on contingent consideration of $0.9 million and $2.2 million in the three and six months ended  September 30, 2023, respectively. Unallocated corporate expenses consisted of a gain on contingent consideration of $0.3 million and $0.1 million in the three and six months ended  September 30, 2022. Additionally, unallocated corporate expenses consisted of stock-based compensation expense of $1.1 million and $1.0 million in the three months ended  September 30, 2023 and 2022, respectively, and $2.5 million and $2.1 million in the six months ended  September 30, 2023 and 2022, respectively.

[0001437749-23-029753:notes:142]
Total assets for the two business segments as of  September 30, 2023 and  March 31, 2023, are as follows (in thousands):

[0001437749-23-029753:notes:143]
|  |  | September 30, 2023 |  |  | March 31, 2023 |  |
| Grid |  | $ | 137,607 |  |  | $ | 135,296 |  |
| Wind |  |  | 9,750 |  |  |  | 14,361 |  |
| Corporate assets |  |  | 23,970 |  |  |  | 25,904 |  |
| Total |  | $ | 171,327 |  |  | $ | 175,561 |  |


## us-gaap:NewAccountingPronouncementsAndChangesInAccountingPrinciplesTextBlock

[0001437749-23-029753:notes:144]
19. Recent Accounting Pronouncements

[0001437749-23-029753:notes:145]
In  June 2016, the Financial Accounting Standards Board ("FASB") issued Accounting Standards Update ("ASU") 2016-13, Financial Instruments-Credit Losses (Topic 326): Measurement of Credit Losses on Financial Instruments. The amendments in ASU 2016-13 will provide more decision-useful information about the expected credit losses on financial instruments and other commitments to extend credit held by a reporting entity at each reporting date. Following the release of ASU 2019-10 in  November 2019, the effective date, as long as the Company remains a smaller reporting company, was annual reporting periods beginning after  December 15, 2022.  As of  April 1, 2023, the Company has adopted ASU 2016-13 and noted no material impact on its condensed consolidated financial statements.

[0001437749-23-029753:notes:146]
In  October 2021, the FASB issued ASU 2021-08, Business Combinations (Topic 805): Accounting for Contract Assets and Contract Liabilities from Contracts with Customers. The amendments in ASU 2021-08 will improve the accounting for acquired revenue contracts with customers in a business combination. Following the release of ASU 2021-08 in  October 2021, the effective date was annual reporting periods beginning after  December 15, 2022. As of  April 1, 2023, the Company has adopted ASU 2021-08 and noted no material impact on its condensed consolidated financial statements.


## us-gaap:SubsequentEventsTextBlock

[0001437749-23-029753:notes:147]
20. Subsequent Events

[0001437749-23-029753:notes:148]
The Company has performed an evaluation of subsequent events through the time of filing this Quarterly Report on Form 10-Q with the SEC and has determined that there are no such events to report.
