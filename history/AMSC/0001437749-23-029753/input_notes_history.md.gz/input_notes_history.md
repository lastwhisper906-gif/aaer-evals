# AMSC note change history — 0001437749-23-022793 → 0001437749-23-029753


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2023-11-01):
[0001437749-23-029753:note_history:1]
As of  September 30, 2023, the Company had $0.6 million of restricted cash included in long-term assets and $0.5 million of restricted cash included in current assets. As of  March 31, 2023, the Company had $0.6 million of restricted cash included in long term assets and $1.7 million of restricted cash included in current assets. These amounts included in restricted cash primarily represent deposits to secure letters of credit for various supply contracts and long-term projects or collateral deposits. These deposits are held in interest bearing accounts.
  (was, 2023-08-09, similarity 0.9879):
[0001437749-23-022793:note_history:1]
As of  June 30, 2023, the Company had $0.6 million of restricted cash included in long-term assets and $0.5 million of restricted cash included in current assets. As of  March 31, 2023, the Company had $0.6 million of restricted cash included in long term assets and $1.7 million of restricted cash included in current assets. These amounts included in restricted cash primarily represent deposits to secure letters of credit for various supply contracts and long-term projects or collateral deposits.  These deposits are held in interest bearing accounts.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- added (2023-11-01):
[0001437749-23-029753:note_history:2]
AMERICAN SUPERCONDUCTOR CORPORATION

- added (2023-11-01):
[0001437749-23-029753:note_history:3]
NOTES TO UNAUDITED CONDENSED CONSOLIDATED FINANCIAL STATEMENTS

- changed (2023-11-01):
[0001437749-23-029753:note_history:4]
These unaudited condensed consolidated financial statements of the Company have been prepared on a going concern basis in accordance with United States generally accepted accounting principles (“GAAP”) and the Securities and Exchange Commission’s (“SEC”) instructions to Form 10-Q. The going concern basis of presentation assumes that the Company will continue operations and will be able to realize its assets and discharge its liabilities and commitments in the normal course of business. Certain information and footnote disclosures normally included in the financial statements prepared in accordance with GAAP have been condensed or omitted pursuant to those instructions. The year-end condensed balance sheet data was derived from audited financial statements but does not include all disclosures required by GAAP. The unaudited condensed consolidated financial statements, in the opinion of management, reflect all adjustments (consisting of normal recurring adjustments) necessary for a fair statement of the results for the interim periods ended  September 30, 2023 and 2022 and the financial position at  September 30, 2023; however, these results are not necessarily indicative of results which  may be expected for the full year. The interim condensed consolidated financial statements, and notes thereto, should be read in conjunction with the audited consolidated financial statements for the year ended  March 31, 2023, and notes thereto, included in the Company’s Annual Report on Form 10-K for the year ended  March 31, 2023 filed with the SEC on  May 31, 2023.
  (was, 2023-08-09, similarity 0.9883):
[0001437749-23-022793:note_history:4]
These unaudited condensed consolidated financial statements of the Company have been prepared on a going concern basis in accordance with United States generally accepted accounting principles (“GAAP”) and the Securities and Exchange Commission’s (“SEC”) instructions to Form 10-Q. The going concern basis of presentation assumes that the Company will continue operations and will be able to realize its assets and discharge its liabilities and commitments in the normal course of business. Certain information and footnote disclosures normally included in the financial statements prepared in accordance with GAAP have been condensed or omitted pursuant to those instructions. The year-end condensed balance sheet data was derived from audited financial statements but does not include all disclosures required by GAAP. The unaudited condensed consolidated financial statements, in the opinion of management, reflect all adjustments (consisting of normal recurring adjustments) necessary for a fair statement of the results for the interim periods ended  June 30, 2023 and 2022 and the financial position at  June 30, 2023; however, these results are not necessarily indicative of results which  may be expected for the full year. The interim condensed consolidated financial statements, and notes thereto, should be read in conjunction with the audited condensed consolidated financial statements for the year ended  March 31, 2023, and notes thereto, included in the Company’s Annual Report on Form 10-K for the year ended  March 31, 2023 filed with the SEC on  May 31, 2023.

- changed (2023-11-01):
[0001437749-23-029753:note_history:5]
The Company has historically experienced recurring operating losses and as of  September 30, 2023, the Company had an accumulated deficit of $1,063.4 million. In addition, the Company has historically experienced recurring negative operating cash flows. At  September 30, 2023, the Company had cash and cash equivalents of $22.8 million. Cash used in operations for the six months ended  September 30, 2023 was $1.3 million.
  (was, 2023-08-09, similarity 0.903):
[0001437749-23-022793:note_history:5]
The Company has historically experienced recurring operating losses and as of  June 30, 2023, the Company had an accumulated deficit of $1,061 million. In addition, the Company has historically experienced recurring negative operating cash flows. At  June 30, 2023, the Company had cash and cash equivalents of $22.0 million. Cash used in operations for the three months ended  June 30, 2023 was $2.2 million.

- changed (2023-11-01):
[0001437749-23-029753:note_history:6]
The Company continues to experience inflationary pressure in its supply chain and some delays in sourcing materials needed for its products resulting in some production disruption, both of which have increased the Company’s cost of revenues and decreased gross margin. While the impact of inflation has been challenging, the Company continues to take actions to limit this pressure, including adjusting the pricing of its products and services. Changes in macroeconomic conditions arising from the COVID-19 pandemic or for other reasons, such as the ongoing wars between Russia and Ukraine and Israel and Hamas, inflation, rising interest rates, labor force availability, sourcing, material delays and global supply chain disruptions could have a material adverse effect on the Company’s business, financial condition and results of operation.
  (was, 2023-08-09, similarity 0.9868):
[0001437749-23-022793:note_history:6]
The Company continues to experience inflationary pressure in its supply chain and some delays in sourcing materials needed for its products resulting in some production disruption, both of which have increased the Company’s cost of revenues and decreased gross margin. While the impact of inflation has been challenging, the Company continues to take actions to limit this pressure, including adjusting the pricing of its products and services. Changes in macroeconomic conditions arising from the COVID-19 pandemic or for other reasons, such as the ongoing war between Russia and Ukraine, inflation, rising interest rates, labor force availability, sourcing, material delays and global supply chain disruptions could have a material adverse effect on the Company’s business, financial condition and results of operation.

- changed (2023-11-01):
[0001437749-23-029753:note_history:7]
From time-to-time the Company  may undertake restructuring activities in order to align the global organization in a manner that the Company believes will better position it to achieve its long-term goals. In  January 2023, the Company undertook a reduction in force that involved approximately 5% of the global workforce. This restructuring is expected to incur $1.0 million of cash expenses, $0.8 million of which has been paid as of  September 30, 2023, and to result in annualized cost savings of approximately $5.0 million, beginning in fiscal 2023.
  (was, 2023-08-09, similarity 0.8098):
[0001437749-23-022793:note_history:7]
From time-to-time the Company  may undertake restructuring activities in order to align the global organization in a manner that the Company believes will better position it to achieve its long-term goals. In  January 2023, the Company undertook a reduction in force that involved approximately 5% of the global workforce. This restructuring is expected to incur $1.0 million of cash expenses, $0.7 million of which has been paid as of  June 30, 2023, and to result in annualized cost savings of approximately $5.0 million, beginning in fiscal 2023.

- changed (2023-11-01):
[0001437749-23-029753:note_history:8]
The Company believes that based on the information presented above and its quarterly management assessment, it has sufficient liquidity to fund its operations and capital expenditures for the next twelve months following the issuance of the unaudited condensed consolidated financial statements for the six months ended  September 30, 2023. The Company’s liquidity is highly dependent on its ability to increase revenues, its ability to control its operating costs, and its ability to raise additional capital, if necessary. The impact of the COVID-19 pandemic and other sources of instability, including the wars between Russia and Ukraine and Israel and Hamas, on the global financing markets  may reduce the Company's ability to raise additional capital, if necessary, which could negatively impact the Company's liquidity.  There can be no assurance that the Company will be able to continue to raise additional capital, on favorable terms or at all, from other sources or execute on any other means of improving liquidity described above.
  (was, 2023-08-09, similarity 0.9193):
[0001437749-23-022793:note_history:8]
The Company believes that based on the information presented above and its quarterly management assessment, it has sufficient liquidity to fund its operations and capital expenditures for the next twelve months following the issuance of the financial statements for the three months ended  June 30, 2023. The Company’s liquidity is highly dependent on its ability to increase revenues, its ability to control its operating costs, and its ability to raise additional capital, if necessary. The impact of the COVID-19 pandemic and other sources of instability, including the war between Russia and Ukraine, on the global financing markets  may reduce the Company's ability to raise additional capital, if necessary, which could negatively impact the Company's liquidity.  There can be no assurance that the Company will be able to continue to raise additional capital, on favorable terms or at all, from other sources or execute on any other means of improving liquidity described above.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2023-11-01):
[0001437749-23-029753:note_history:9]
As part of the acquisition of Neeltran, the Company identified four equipment financing agreements that Neeltran had entered into prior to the acquisition of Neeltran on  May 6, 2021. The current debt balance is $0.1 million as of  September 30, 2023 and  March 31, 2023.
  (was, 2023-08-09, similarity 0.8368):
[0001437749-23-022793:note_history:9]
As part of the acquisition of Neeltran, the Company identified four equipment financing agreements that Neeltran had entered into prior to the acquisition of Neeltran on  May 6, 2021. The current and long-term aggregate debt balance is $0.1 million as of  June 30, 2023 and  March 31, 2023, respectively.


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- added (2023-11-01):
[0001437749-23-029753:note_history:10]
|  |  | Three Months Ended September 30, 2023 |  |  | Six Months Ended September 30, 2023 |  |
| Product Line: |  | Grid |  |  | Wind |  |  | Grid |  |  | Wind |  |
| Equipment and systems |  | $ | 22,682 |  |  | $ | 4,879 |  |  | $ | 45,808 |  |  | $ | 8,862 |  |
| Services and technology development |  |  | 5,833 |  |  |  | 610 |  |  |  | 8,443 |  |  |  | 1,145 |  |
| Total |  | $ | 28,515 |  |  | $ | 5,489 |  |  | $ | 54,251 |  |  | $ | 10,007 |  |
| Region: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas |  | $ | 24,696 |  |  | $ | 27 |  |  | $ | 47,856 |  |  | $ | 57 |  |
| Asia Pacific |  |  | 3,418 |  |  |  | 5,462 |  |  |  | 5,129 |  |  |  | 9,928 |  |
| EMEA |  |  | 401 |  |  |  | — |  |  |  | 1,266 |  |  |  | 22 |  |
| Total |  | $ | 28,515 |  |  | $ | 5,489 |  |  | $ | 54,251 |  |  | $ | 10,007 |  |

- changed (2023-11-01):
[0001437749-23-029753:note_history:11]
|  |  | Three Months Ended September 30, 2022 |  |  | Six Months Ended September 30, 2022 |  |
| Product Line: |  | Grid |  |  | Wind |  |  | Grid |  |  | Wind |  |
| Equipment and systems |  | $ | 24,128 |  |  | $ | 1,330 |  |  | $ | 42,204 |  |  | $ | 3,302 |  |
| Services and technology development |  |  | 1,570 |  |  |  | 652 |  |  |  | 3,323 |  |  |  | 1,531 |  |
| Total |  | $ | 25,698 |  |  | $ | 1,982 |  |  | $ | 45,527 |  |  | $ | 4,833 |  |
| Region: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas |  | $ | 18,021 |  |  | $ | - |  |  | $ | 34,923 |  |  | $ | - |  |
| Asia Pacific |  |  | 6,178 |  |  |  | 1,912 |  |  |  | 8,855 |  |  |  | 4,763 |  |
| EMEA |  |  | 1,499 |  |  |  | 70 |  |  |  | 1,749 |  |  |  | 70 |  |
| Total |  | $ | 25,698 |  |  | $ | 1,982 |  |  | $ | 45,527 |  |  | $ | 4,833 |  |
  (was, 2023-08-09, similarity 0.6071):
[0001437749-23-022793:note_history:11]
|  |  | Three Months Ended June 30, 2023 |  |
| Product Line: |  | Grid |  |  | Wind |  |
| Equipment and systems |  | $ | 23,126 |  |  | $ | 3,982 |  |
| Services and technology development |  |  | 2,611 |  |  |  | 535 |  |
| Total |  | $ | 25,737 |  |  | $ | 4,517 |  |
| Region: |  |  |  |  |  |  |  |  |
| Americas |  | $ | 23,161 |  |  | $ | - |  |
| Asia Pacific |  |  | 1,711 |  |  |  | 4,465 |  |
| EMEA |  |  | 865 |  |  |  | 52 |  |
| Total |  | $ | 25,737 |  |  | $ | 4,517 |  |

- removed (2023-11-01):
[0001437749-23-022793:note_history:12]
|  |  | Three Months Ended June 30, 2022 |  |
| Product Line: |  | Grid |  |  | Wind |  |
| Equipment and systems |  | $ | 18,076 |  |  | $ | 1,973 |  |
| Services and technology development |  |  | 1,753 |  |  |  | 877 |  |
| Total |  | $ | 19,829 |  |  | $ | 2,850 |  |
| Region: |  |  |  |  |  |  |  |  |
| Americas |  | $ | 16,902 |  |  | $ | - |  |
| Asia Pacific |  |  | 2,677 |  |  |  | 2,850 |  |
| EMEA |  |  | 250 |  |  |  | - |  |
| Total |  | $ | 19,829 |  |  | $ | 2,850 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2023-11-01):
[0001437749-23-029753:note_history:13]
The Company’s revenues in its Grid business segment are derived primarily through enabling the transmission and distribution of power, providing planning services that allow it to identify power grid needs and risks, and developing ship protection systems for the U.S. Navy. The Company’s revenues in its Wind business segment are derived primarily through supplying advanced power electronics and control systems, licensing its highly engineered wind turbine designs, and providing extensive customer support services to wind turbine manufacturers. The Company records revenue based on a five-step model in accordance with Accounting Standards Codification ("ASC") 606. For its customer contracts, the Company identifies the performance obligations, determines the transaction price, allocates the contract transaction price to the performance obligations, and recognizes the revenue when (or as) control of goods or services is transferred to the customer. In the three and six months ended  September 30, 2023, 79% and 78% of revenue, respectively, was recognized at the point in time when control transferred to the customer, with the remainder being recognized over time. In the three and six months ended  September 30, 2022, 83% and 77% of revenue, respectively, was recognized at the point in time when control transferred to the customer, with the remainder being recognized over time.
  (was, 2023-08-09, similarity 0.6388):
[0001437749-23-022793:note_history:13]
The Company’s revenues in its Grid business segment are derived primarily through enabling the transmission and distribution of power, providing planning services that allow it to identify power grid needs and risks, and developing ship protection systems for the U.S. Navy. The Company’s revenues in its Wind business segment are derived primarily through supplying advanced power electronics and control systems, licensing its highly engineered wind turbine designs, and providing extensive customer support services to wind turbine manufacturers. The Company records revenue based on a five-step model in accordance with ASC 606. For its customer contracts, the Company identifies the performance obligations, determines the transaction price, allocates the contract transaction price to the performance obligations, and recognizes the revenue when (or as) control of goods or services is transferred to the customer. In the three months ended  June 30, 2023, and 2022, 76% and 70% of revenue, respectively, was recognized at the point in time when control transferred to the customer, with the remainder being recognized over time.

- added (2023-11-01):
[0001437749-23-029753:note_history:14]
The Company provides assurance-type warranties on all product sales for a term of typically one to three years, and extended service-type warranties are available for purchase at the customer's option for an additional term ranging up to four additional years. The Company accrues for the estimated warranty costs for assurance warranties at the time of sale based on historical warranty experience plus any known or expected changes in warranty exposure. For all extended service-type warranties, the Company recognizes the revenue ratably over time during the effective period of the services.

- changed (2023-11-01):
[0001437749-23-029753:note_history:15]
The Company records revenue net of sales tax, value added tax, excise tax and other taxes collected concurrent with revenue-producing activities. The Company has elected to recognize the cost for freight and shipping when control over the products sold passes to customers and revenue is recognized. The Company has elected to recognize incremental costs of obtaining a contract as expense when incurred except in contracts where the amortization period would exceed twelve months; in such cases the long-term amount will be assessed for materiality. The Company has elected not to adjust the promised amount of consideration for the effects of a significant financing component if the period of financing is twelve months or less.  The Company has elected to recognize revenue based on the As Invoiced practical expedient if there is a right to consideration from a customer in an amount that corresponds directly with the value of the Company's performance.
  (was, 2023-08-09, similarity 0.8656):
[0001437749-23-022793:note_history:15]
The Company records revenue net of sales tax, value added tax, excise tax and other taxes collected concurrent with revenue-producing activities. The Company has elected to recognize the cost for freight and shipping when control over the products sold passes to customers and revenue is recognized. The Company has elected to recognize incremental costs of obtaining a contract as expense when incurred except in contracts where the amortization period would exceed twelve months; in such cases the long-term amount will be assessed for materiality. The Company has elected not to adjust the promised amount of consideration for the effects of a significant financing component if the period of financing is twelve months or less.

- changed (2023-11-01):
[0001437749-23-029753:note_history:16]
The Company monitors costs to meet its obligations on its customer contracts. When it is evident that there is a loss expected on a contract, a contract loss is accrued in the period. Several long-term contracts that were acquired from Neeltran, Inc. (“Neeltran”) were impacted by higher than planned costs due to required design changes and inflation on material costs, resulting in an increase to the contract loss accrual of $1.0 million and $1.2 million in the three and six months ended  September 30, 2022, respectively, which negatively impacted the Company's gross margins. The contract loss accrual decreased by $0.9 million in each of the three and six months ended  September 30, 2023, respectively, as projects have been completed.
  (was, 2023-08-09, similarity 0.8353):
[0001437749-23-022793:note_history:16]
The Company monitors costs to meet its obligations on its customer contracts. When it is evident that there is a loss expected on a contract, a contract loss is accrued in the period. Several long-term contracts that were acquired from Neeltran, Inc. (“Neeltran”) were impacted by higher than planned costs due to required design changes and inflation on material costs, resulting in an increase to the contract loss accrual of $0.1 million and $0.2 million in the three month periods ended  June 30, 2023 and 2022, respectively, which negatively impacted the Company's gross margins.

- added (2023-11-01):
[0001437749-23-029753:note_history:17]
|  |  | Three Months Ended September 30, 2023 |  |  | Six Months Ended September 30, 2023 |  |
| Product Line: |  | Grid |  |  | Wind |  |  | Grid |  |  | Wind |  |
| Equipment and systems |  | $ | 22,682 |  |  | $ | 4,879 |  |  | $ | 45,808 |  |  | $ | 8,862 |  |
| Services and technology development |  |  | 5,833 |  |  |  | 610 |  |  |  | 8,443 |  |  |  | 1,145 |  |
| Total |  | $ | 28,515 |  |  | $ | 5,489 |  |  | $ | 54,251 |  |  | $ | 10,007 |  |
| Region: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas |  | $ | 24,696 |  |  | $ | 27 |  |  | $ | 47,856 |  |  | $ | 57 |  |
| Asia Pacific |  |  | 3,418 |  |  |  | 5,462 |  |  |  | 5,129 |  |  |  | 9,928 |  |
| EMEA |  |  | 401 |  |  |  | — |  |  |  | 1,266 |  |  |  | 22 |  |
| Total |  | $ | 28,515 |  |  | $ | 5,489 |  |  | $ | 54,251 |  |  | $ | 10,007 |  |

- changed (2023-11-01):
[0001437749-23-029753:note_history:18]
|  |  | Three Months Ended September 30, 2022 |  |  | Six Months Ended September 30, 2022 |  |
| Product Line: |  | Grid |  |  | Wind |  |  | Grid |  |  | Wind |  |
| Equipment and systems |  | $ | 24,128 |  |  | $ | 1,330 |  |  | $ | 42,204 |  |  | $ | 3,302 |  |
| Services and technology development |  |  | 1,570 |  |  |  | 652 |  |  |  | 3,323 |  |  |  | 1,531 |  |
| Total |  | $ | 25,698 |  |  | $ | 1,982 |  |  | $ | 45,527 |  |  | $ | 4,833 |  |
| Region: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas |  | $ | 18,021 |  |  | $ | - |  |  | $ | 34,923 |  |  | $ | - |  |
| Asia Pacific |  |  | 6,178 |  |  |  | 1,912 |  |  |  | 8,855 |  |  |  | 4,763 |  |
| EMEA |  |  | 1,499 |  |  |  | 70 |  |  |  | 1,749 |  |  |  | 70 |  |
| Total |  | $ | 25,698 |  |  | $ | 1,982 |  |  | $ | 45,527 |  |  | $ | 4,833 |  |
  (was, 2023-08-09, similarity 0.6071):
[0001437749-23-022793:note_history:18]
|  |  | Three Months Ended June 30, 2023 |  |
| Product Line: |  | Grid |  |  | Wind |  |
| Equipment and systems |  | $ | 23,126 |  |  | $ | 3,982 |  |
| Services and technology development |  |  | 2,611 |  |  |  | 535 |  |
| Total |  | $ | 25,737 |  |  | $ | 4,517 |  |
| Region: |  |  |  |  |  |  |  |  |
| Americas |  | $ | 23,161 |  |  | $ | - |  |
| Asia Pacific |  |  | 1,711 |  |  |  | 4,465 |  |
| EMEA |  |  | 865 |  |  |  | 52 |  |
| Total |  | $ | 25,737 |  |  | $ | 4,517 |  |

- changed (2023-11-01):
[0001437749-23-029753:note_history:19]
As of  September 30, 2023, and 2022, the Company’s contract assets and liabilities primarily relate to the timing differences between cash received from a customer in connection with contractual rights to invoicing and the timing of revenue recognition following completion of performance obligations. The Company's accounts receivable balance is made up entirely of customer contract related balances. Changes in the Company’s contract assets, which are included in “Unbilled accounts receivable” and “Deferred program costs” (see Note 7, “Accounts Receivable” and Note 8, “Inventory” for a reconciliation to the condensed consolidated balance sheets) and "Contract liabilities", which are included in the current portion and long-term portion of "Deferred revenue" in the Company’s condensed consolidated balance sheets, are as follows (in thousands):
  (was, 2023-08-09, similarity 0.9922):
[0001437749-23-022793:note_history:19]
As of  June 30, 2023, and 2022, the Company’s contract assets and liabilities primarily relate to the timing differences between cash received from a customer in connection with contractual rights to invoicing and the timing of revenue recognition following completion of performance obligations. The Company's accounts receivable balance is made up entirely of customer contract related balances. Changes in the Company’s contract assets, which are included in “Unbilled accounts receivable” and “Deferred program costs” (see Note 7, “Accounts Receivable” and Note 8, “Inventory” for a reconciliation to the condensed consolidated balance sheets) and "Contract liabilities", which are included in the current portion and long-term portion of "Deferred revenue" in the Company’s condensed consolidated balance sheets, are as follows (in thousands):

- changed (2023-11-01):
[0001437749-23-029753:note_history:20]
|  |  | Unbilled Accounts Receivable |  |  | Deferred Program Costs |  |  | Contract Liabilities |  |
| Beginning balance as of March 31, 2023 |  | $ | 9,958 |  |  | $ | 2,136 |  |  | $ | 50,760 |  |
| Increases for costs incurred to fulfill performance obligations |  |  | — |  |  |  | 2,110 |  |  |  | — |  |
| Increase (decrease) due to customer billings |  |  | (13,981 | ) |  |  | — |  |  |  | 34,284 |  |
| Decrease due to cost recognition on completed performance obligations |  |  | — |  |  |  | (2,160 | ) |  |  | — |  |
| Increase (decrease) due to recognition of revenue based on transfer of control of performance obligations |  |  | 10,351 |  |  |  | — |  |  |  | (25,710 | ) |
| Other changes and FX impact |  |  | 7 |  |  |  | (11 | ) |  |  | (288 | ) |
| Ending balance as of September 30, 2023 |  | $ | 6,335 |  |  | $ | 2,075 |  |  | $ | 59,046 |  |
  (was, 2023-08-09, similarity 0.9898):
[0001437749-23-022793:note_history:20]
|  |  | Unbilled Accounts Receivable |  |  | Deferred Program Costs |  |  | Contract Liabilities |  |
| Beginning balance as of March 31, 2022 |  | $ | 6,492 |  |  | $ | 858 |  |  | $ | 30,034 |  |
| Increases for costs incurred to fulfill performance obligations |  |  | — |  |  |  | 406 |  |  |  | — |  |
| Increase (decrease) due to customer billings |  |  | (4,710 | ) |  |  | — |  |  |  | 17,852 |  |
| Decrease due to cost recognition on completed performance obligations |  |  | — |  |  |  | (365 | ) |  |  | — |  |
| Increase (decrease) due to recognition of revenue based on transfer of control of performance obligations |  |  | 2,128 |  |  |  | — |  |  |  | (13,737 | ) |
| Other changes and FX impact |  |  | — |  |  |  | (25 | ) |  |  | (394 | ) |
| Ending balance as of June 30, 2022 |  | $ | 3,910 |  |  | $ | 874 |  |  | $ | 33,755 |  |

- changed (2023-11-01):
[0001437749-23-029753:note_history:21]
|  |  | Unbilled Accounts Receivable |  |  | Deferred Program Costs |  |  | Contract Liabilities |  |
| Beginning balance as of March 31, 2022 |  | $ | 6,492 |  |  | $ | 858 |  |  | $ | 30,034 |  |
| Increases for costs incurred to fulfill performance obligations |  |  | — |  |  |  | 782 |  |  |  | — |  |
| Increase (decrease) due to customer billings |  |  | (7,322 | ) |  |  | — |  |  |  | 33,141 |  |
| Decrease due to cost recognition on completed performance obligations |  |  | — |  |  |  | (697 | ) |  |  | — |  |
| Increase (decrease) due to recognition of revenue based on transfer of control of performance obligations |  |  | 7,342 |  |  |  | — |  |  |  | (26,857 | ) |
| Other changes and FX impact |  |  | — |  |  |  | (47 | ) |  |  | (863 | ) |
| Ending balance as of September 30, 2022 |  | $ | 6,512 |  |  | $ | 896 |  |  | $ | 35,455 |  |
  (was, 2023-08-09, similarity 0.9471):
[0001437749-23-022793:note_history:21]
|  |  | Unbilled Accounts Receivable |  |  | Deferred Program Costs |  |  | Contract Liabilities |  |
| Beginning balance as of March 31, 2023 |  | $ | 9,958 |  |  | $ | 2,136 |  |  | $ | 50,760 |  |
| Increases for costs incurred to fulfill performance obligations |  |  | — |  |  |  | 1,084 |  |  |  | — |  |
| Increase (decrease) due to customer billings |  |  | (9,479 | ) |  |  | — |  |  |  | 16,308 |  |
| Decrease due to cost recognition on completed performance obligations |  |  | — |  |  |  | (1,234 | ) |  |  | — |  |
| Increase (decrease) due to recognition of revenue based on transfer of control of performance obligations |  |  | 5,092 |  |  |  | — |  |  |  | (8,974 | ) |
| Other changes and FX impact |  |  | 1 |  |  |  | — |  |  |  | (11 | ) |
| Ending balance as of June 30, 2023 |  | $ | 5,572 |  |  | $ | 1,986 |  |  | $ | 58,083 |  |

- changed (2023-11-01):
[0001437749-23-029753:note_history:22]
The Company’s remaining performance obligations represent the unrecognized revenue value of the Company’s contractual commitments. The Company’s performance obligations  may vary significantly each reporting period based on the timing of major new contractual commitments. As of  September 30, 2023, the Company had outstanding performance obligations on existing contracts under ASC 606 to be recognized in the next twelve months of approximately $128.3 million. There are also approximately $43.2 million of outstanding performance obligations to be recognized over a period of thirteen to sixty months. The remaining performance obligations are subject to customer actions and therefore the timing of revenue recognition cannot be reasonably estimated.
  (was, 2023-08-09, similarity 0.9912):
[0001437749-23-022793:note_history:22]
The Company’s remaining performance obligations represent the unrecognized revenue value of the Company’s contractual commitments. The Company’s performance obligations  may vary significantly each reporting period based on the timing of major new contractual commitments. As of  June 30, 2023, the Company had outstanding performance obligations on existing contracts under ASC 606 to be recognized in the next twelve months of approximately $123.3 million. There are also approximately $41.5 million of outstanding performance obligations to be recognized over a period of thirteen to sixty months. The remaining performance obligations are subject to customer actions and therefore the timing of revenue recognition cannot be reasonably estimated.

- changed (2023-11-01):
[0001437749-23-029753:note_history:23]
The following table sets forth customers who represented 10% or more of the Company’s total revenues for the three and six months ended  September 30, 2023 and 2022:
  (was, 2023-08-09, similarity 0.936):
[0001437749-23-022793:note_history:23]
The following table sets forth customers who represented 10% or more of the Company’s total revenues for the three months ended  June 30, 2023 and 2022:

- added (2023-11-01):
[0001437749-23-029753:note_history:24]
|  |  |  | Three Months Ended |  |  | Six Months Ended |  |
|  | Reportable |  | September 30, |  |  | September 30, |  |
|  | Segment |  | 2023 |  |  | 2022 |  |  | 2023 |  |  | 2022 |  |
| Inox Wind Limited | Wind |  |  | 12 | % |  | <10% |  |  |  | 12 | % |  | <10% |  |
| Fuji Bridex Pte Ltd | Grid |  |  | <10% |  |  |  | 17 | % |  |  | <10% |  |  |  | 13 | % |
| Gray Construction, Inc. | Grid |  |  | 11 | % |  |  | <10% |  |  |  | <10% |  |  |  | <10% |  |
| Ascend Performance Materials Ops LLC | Grid |  |  | <10% |  |  |  | 12 | % |  |  | <10% |  |  |  | <10% |  |

- removed (2023-11-01):
[0001437749-23-022793:note_history:25]
The Company's equipment and system product line includes certain contracts which do not meet the requirements of an exchange transaction and therefore do not fall within the scope of ASC 606.  As these non-exchange transaction contracts are considered grant revenue and do not fall within any specific accounting literature, the Company follows guidance within ASC 606 by analogy to recognize grant revenue over time. The Company recorded no grant revenue in the three month periods ended  June 30, 2023, and 2022.

- removed (2023-11-01):
[0001437749-23-022793:note_history:26]
The Company provides assurance-type warranties on all product sales for a term of typically one to three years, and extended service-type warranties at the customer's option for an additional term ranging up to four additional years. The Company accrues for the estimated warranty costs for assurance warranties at the time of sale based on historical warranty experience plus any known or expected changes in warranty exposure. For all extended service-type warranties, the Company recognizes the revenue ratably over time during the effective period of the services.

- removed (2023-11-01):
[0001437749-23-022793:note_history:27]
|  |  | Three Months Ended June 30, 2022 |  |
| Product Line: |  | Grid |  |  | Wind |  |
| Equipment and systems |  | $ | 18,076 |  |  | $ | 1,973 |  |
| Services and technology development |  |  | 1,753 |  |  |  | 877 |  |
| Total |  | $ | 19,829 |  |  | $ | 2,850 |  |
| Region: |  |  |  |  |  |  |  |  |
| Americas |  | $ | 16,902 |  |  | $ | - |  |
| Asia Pacific |  |  | 2,677 |  |  |  | 2,850 |  |
| EMEA |  |  | 250 |  |  |  | - |  |
| Total |  | $ | 19,829 |  |  | $ | 2,850 |  |

- removed (2023-11-01):
[0001437749-23-022793:note_history:28]
|  |  |  | Three Months Ended |  |
|  | Reportable |  | June 30, |  |
|  | Segment |  | 2023 |  |  | 2022 |  |
| Inox Wind Limited | Wind |  |  | 12 | % |  | <10% |  |
| SGL Carbon LLC | Grid |  | <10% |  |  |  | 10 | % |
