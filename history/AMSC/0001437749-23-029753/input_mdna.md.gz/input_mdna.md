# AMSC MD&A — 0001437749-23-029753


## mdna

[0001437749-23-029753:mdna:1]
[same as prior period, unchanged from 0001437749-23-022793:mdna:1]

[0001437749-23-029753:mdna:2]
[same as prior period, unchanged from 0001437749-23-022793:mdna:2]

[0001437749-23-029753:mdna:3]
[same as prior period, unchanged from 0001437749-23-022793:mdna:3]

[0001437749-23-029753:mdna:4]
[same as prior period, unchanged from 0001437749-23-022793:mdna:4]

[0001437749-23-029753:mdna:5]
[same as prior period, unchanged from 0001437749-23-022793:mdna:5]

[0001437749-23-029753:mdna:6]
[same as prior period, unchanged from 0001437749-23-022793:mdna:6]

[0001437749-23-029753:mdna:7]
[same as prior period, unchanged from 0001437749-23-022793:mdna:7]

[0001437749-23-029753:mdna:8]
|  | • | Grid. Through our Gridtec™ Solutions, our Grid business segment enables electric utilities, industrial facilities, and renewable energy project developers to connect, transmit and distribute power with exceptional efficiency, reliability, security and affordability. We provide transmission planning services that allow us to identify power grid congestion, poor power quality, and other risks, which help us determine how our solutions can improve network performance. These services often lead to sales of our grid interconnection solutions for wind farms and solar power plants, power quality systems and transmission and distribution cable systems. We also sell ship protection products to the U.S. Navy through our Grid business segment. |

[0001437749-23-029753:mdna:9]
|  | • | Wind. Through our Windtec™ Solutions, our Wind business segment enables manufacturers to field wind turbines with exceptional power output, reliability and affordability. We supply advanced power electronics and control systems, license our highly engineered wind turbine designs, and provide extensive customer support services to wind turbine manufacturers. Our design portfolio includes a broad range of drivetrains and power ratings of 2 megawatts ("MWs") and higher. We provide a broad range of power electronics and software-based control systems that are highly integrated and designed for optimized performance, efficiency, and grid compatibility. |

[0001437749-23-029753:mdna:10]
[same as prior period, unchanged from 0001437749-23-022793:mdna:10]

[0001437749-23-029753:mdna:11]
We continue to experience some inflationary pressure in our supply chain and some delays in sourcing materials needed for our products, resulting in some production disruption, both of which have increased our cost of revenues and decreased gross margin.  While the impact of inflation has been challenging, we continue to take actions to limit this pressure including adjusting the pricing of our products and services. Changes in macroeconomic and market conditions arising from the COVID-19 pandemic, or for other reasons, such as the ongoing wars between Russia and Ukraine or Israel and Hamas, inflation, rising interest rates, labor force availability, sourcing, material delays and global supply chain disruptions could have a material adverse effect on our business, financial condition and results of operation.

[0001437749-23-029753:mdna:12]
From time-to-time we may undertake restructuring activities in order to align our global organization in a manner that we believe will better position us to achieve our long-term goals. In January 2023, we undertook a reduction in force that involved approximately 5% of our global workforce. This restructuring is expected to incur $1.0 million of cash expenses, $0.8 million of which has been paid as of September 30, 2023, and to result in annualized cost savings of approximately $5.0 million, beginning in fiscal 2023.

[0001437749-23-029753:mdna:13]
In February 2023, we completed the process of determining and verifying our eligibility and amount of payroll tax credits known as the Employee Retention Credit (“ERC”) under the CARES Act which Congress enacted as part of the Taxpayer Certainty and Disaster Tax Relief Act of 2020. This resulted in filing certain amended payroll tax forms for eligible quarters in 2020 and 2021, which, in the aggregate, totaled $3.3 million. We recognized a receivable in prepaid expenses and other current assets and a benefit to cost of revenues and operating expenses in the quarter ended March 31, 2023. During the six months ended September 30, 2023, we received $3.0 million in payments for the initial claims that were processed. The remaining balance is expected to be paid during the remainder of fiscal 2023.

[0001437749-23-029753:mdna:14]
[same as prior period, unchanged from 0001437749-23-022793:mdna:15]

[0001437749-23-029753:mdna:15]
[same as prior period, unchanged from 0001437749-23-022793:mdna:16]

[0001437749-23-029753:mdna:16]
[same as prior period, unchanged from 0001437749-23-022793:mdna:17]

[0001437749-23-029753:mdna:17]
Three and six months ended September 30, 2023, compared to the three and six months ended September 30, 2022

[0001437749-23-029753:mdna:18]
[same as prior period, unchanged from 0001437749-23-022793:mdna:19]

[0001437749-23-029753:mdna:19]
Total revenues increased 23% to $34.0 million for the three months ended September 30, 2023 and total revenues increased 28% to $64.3 million for the six months ended September 30, 2023, compared to $27.7 million and $50.4 million for the three and six months ended September 30, 2022, respectively. Our revenues are summarized as follows (in thousands):

[0001437749-23-029753:mdna:20]
|  |  | Three Months Ended September 30, |  |  | Six Months Ended September 30, |  |
|  |  | 2023 |  |  | 2022 |  |  | 2023 |  |  | 2022 |  |
| Revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Grid |  | $ | 28,515 |  |  | $ | 25,698 |  |  | $ | 54,251 |  |  | $ | 45,527 |  |
| Wind |  |  | 5,489 |  |  |  | 1,982 |  |  |  | 10,007 |  |  |  | 4,833 |  |
| Total |  | $ | 34,004 |  |  | $ | 27,680 |  |  | $ | 64,258 |  |  | $ | 50,360 |  |

[0001437749-23-029753:mdna:21]
Our Grid business unit accounted for 84% of total revenues for each of the three and six months ended September 30, 2023, respectively, compared to 93% and 90% for the three and six months ended September 30, 2022, respectively. Our Grid business unit revenues increased 11% to $28.5 million in the three months ended September 30, 2023, from $25.7 million in the three months ended September 30, 2022. Our Grid business unit revenues increased 19% to $54.3 million in the six months ended September 30, 2023, from $45.5 million in the six months ended September 30, 2022. The increase in the Grid business unit revenue in the three and six months ended September 30, 2023, compared to the three and six months ended September 30, 2022 was primarily driven by increased shipments of new energy power systems and ship protection systems revenues than in the prior year periods.

[0001437749-23-029753:mdna:22]
Our Wind business unit accounted for 16% of total revenues for each of the three and six months ended September 30, 2023, respectively, compared to 7% and 10% for the three and six months ended September 30, 2022, respectively. Revenues in the Wind business unit increased 177% and 107% to $5.5 million and $10.0 million in the three and six months ended September 30, 2023, from $2.0 million and $4.8 million in the three and six months ended September 30, 2022, respectively. The increase in the three and six months ended September 30, 2023, compared to the three and six months ended September 30, 2022, was driven by additional shipments of electrical control systems ("ECS") at increased prices in the three and six months ended September 30, 2023.

[0001437749-23-029753:mdna:23]
[same as prior period, unchanged from 0001437749-23-022793:mdna:24]

[0001437749-23-029753:mdna:24]
Cost of revenues decreased by 1% to $25.4 million for the three months ended September 30, 2023, compared to $25.7 million for the three months ended September 30, 2022. Cost of revenues increased by 7% to $49.4 million for the six months ended September 30, 2023, compared to $46.2 million for the six months ended September 30, 2022. Gross margin was 25% and 23% for the three and six months ended September 30, 2023, respectively, compared to 7% and 8% for the three and six months ended September 30, 2022, respectively. The increase in gross margin in the three and six months ended September 30, 2023, was due to higher revenues, a more favorable product mix including increased spares and service revenues and favorable impacts across the business due to pricing increases across our product lines.

[0001437749-23-029753:mdna:25]
[same as prior period, unchanged from 0001437749-23-022793:mdna:26]

[0001437749-23-029753:mdna:26]
[same as prior period, unchanged from 0001437749-23-022793:mdna:27]

[0001437749-23-029753:mdna:27]
Research and development ("R&D") expenses decreased 29% and 30% in the three and six months ended September 30, 2023, respectively, to $1.6 million from $2.3 million in the three months ended September 30, 2022, and to $3.5 million from $5.0 million in the six months ended September 30, 2022. The decrease in both periods was driven primarily by decreased compensation expense as well as increased labor charges reclassified to cost of goods sold to support revenue generating projects.

[0001437749-23-029753:mdna:28]
[same as prior period, unchanged from 0001437749-23-022793:mdna:29]

[0001437749-23-029753:mdna:29]
Selling, general and administrative ("SG&A") expenses increased 8% in the three months ended September 30, 2023, to $7.9 million from $7.3 million in the three months ended September 30, 2022. The increase in SG&A expense in the three months ended September 30, 2023, was due to higher compensation and stock compensation expense than in the prior year period. SG&A expenses increased 6% to $15.8 million in the six months ended September 30, 2023, compared to $14.9 million in the six months ended September 30, 2022. The increase in SG&A expense in the six months ended September 30, 2023, was due to higher overall compensation expense than in the prior year period.

[0001437749-23-029753:mdna:30]
[same as prior period, unchanged from 0001437749-23-022793:mdna:31]

[0001437749-23-029753:mdna:31]
We recorded amortization expense related to our core technology and know-how, customer relationships, and other intangible assets of $0.5 million and $1.1 million in the three and six months ended September 30, 2023, respectively, and $0.7 million and $1.4 million in the three and six months ended September 30, 2022, respectively. The decrease in amortization expense in both periods is a result of using the economic consumption method as the basis to amortize the acquired customer relationship intangible assets from Northeast Power Systems, Inc ("NEPSI") and Neeltran.

[0001437749-23-029753:mdna:32]
[same as prior period, unchanged from 0001437749-23-022793:mdna:33]

[0001437749-23-029753:mdna:33]
The change in fair value of our contingent consideration for the earnout payment on the acquisition of NEPSI resulted in a loss of $0.9 million and $2.2 million in the three and six months ended September 30, 2023, respectively, compared to a gain of $0.3 million and $0.1 million in the three and six months ended September 30, 2022, respectively. The change in the fair value was driven by an increased likelihood of achieving certain revenue targets and an increase in the Company's stock price.

[0001437749-23-029753:mdna:34]
NEPSI has recognized revenues in excess of $75 million during the three years after the NEPSI Acquisition Date.  As a result, we expect to issue 400,000 shares of common stock of the Company to the selling stockholders during the quarter ending December 31, 2023 upon certification of the achievement of specified earnout revenue objectives.

[0001437749-23-029753:mdna:35]
Operating income (loss)

[0001437749-23-029753:mdna:36]
Our operating income (loss) is summarized as follows (in thousands):

[0001437749-23-029753:mdna:37]
|  |  | Three Months Ended September 30, |  |  | Six Months Ended September 30, |  |
|  |  | 2023 |  |  | 2022 |  |  | 2023 |  |  | 2022 |  |
| Operating income (loss): |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Grid |  | $ | (679 | ) |  | $ | (6,495 | ) |  | $ | (2,649 | ) |  | $ | (13,776 | ) |
| Wind |  |  | 252 |  |  |  | (868 | ) |  |  | (398 | ) |  |  | (1,254 | ) |
| Unallocated corporate expenses |  |  | (1,942 | ) |  |  | (729 | ) |  |  | (4,655 | ) |  |  | (1,931 | ) |
| Total |  | $ | (2,369 | ) |  | $ | (8,092 | ) |  | $ | (7,702 | ) |  | $ | (16,961 | ) |

[0001437749-23-029753:mdna:38]
Our Grid business segment generated operating losses of $0.7 million and $2.6 million in the three and six months ended September 30, 2023, respectively, compared to operating losses of $6.5 million and $13.8 million in the three and six months ended September 30, 2022, respectively.  The decrease in the Grid business unit operating loss in the three and six months ended September 30, 2023, was due to higher revenues and gross margins due to a favorable product mix as well as the reduction of the remaining acquired Neeltran backlog.

[0001437749-23-029753:mdna:39]
Our Wind business segment generated operating income of $0.3 million and operating loss of $0.4 million in the three and six months ended September 30, 2023, respectively, compared to operating losses of $0.9 million and $1.3 million in the three and six months ended September 30, 2022, respectively. The improvement in the Wind business unit operating margin in the three and six months ended September 30, 2023 was due to higher revenues and gross margins from increased sales of ECS units.

[0001437749-23-029753:mdna:40]
Unallocated corporate expenses included a loss on contingent consideration of $0.9 million and $2.2 million in the three and six months ended September 30, 2023, respectively, and a gain on contingent consideration of $0.3 million and $0.1 million in the three and six months ended September 30, 2022, respectively. Additionally, unallocated corporate expenses primarily consisted of stock-based compensation expense of $1.1 million and $2.5 million in the three and six months ended September 30, 2023, respectively, and $1.0 million and $2.1 million in the three and six months ended September 30, 2022, respectively.

[0001437749-23-029753:mdna:41]
[same as prior period, unchanged from 0001437749-23-022793:mdna:41]

[0001437749-23-029753:mdna:42]
Interest income, net, was $0.2 million and $0.4 million in the three and six months ended September 30, 2023, respectively, compared to less than $0.1 million and $0.1 million in the three and six months ended September 30, 2022, respectively, due to higher earned interest at increased rates in the fiscal year 2023 periods.

[0001437749-23-029753:mdna:43]
China dissolution

[0001437749-23-029753:mdna:44]
China dissolution expense was $1.9 million in each of the three and six months ended September 30, 2022, and there was no similar transaction in the three and six months ended September 30, 2023. The impact of the China dissolution expense during the three and six months ended September 30, 2022, was driven by the liquidation of our China entity, resulting in a foreign currency loss from the cumulative translation release of $1.9 million.

[0001437749-23-029753:mdna:45]
[same as prior period, unchanged from 0001437749-23-022793:mdna:43]

[0001437749-23-029753:mdna:46]
Other expense, net, was $0.2 million and $0.3 million in the three and six months ended September 30, 2023, respectively, compared to other income, net, of $0.1 million and $0.2 million in the three and six months ended September 30, 2022, respectively. The increase in other expense, net, during the three and six months ended September 30, 2023, compared to the three and six months ended September 30, 2022, was driven by the impacts of unfavorable fluctuations in foreign currencies during the periods.

[0001437749-23-029753:mdna:47]
[same as prior period, unchanged from 0001437749-23-022793:mdna:45]

[0001437749-23-029753:mdna:48]
Income tax expense was $0.1 million and $0.2 million in the three and six months ended September 30, 2023, respectively. Income tax benefit was less than $0.1 million in the three months ended September 30, 2022 and income tax expense was less than $0.1 million in the six months ended September 30, 2022.

[0001437749-23-029753:mdna:49]
[same as prior period, unchanged from 0001437749-23-022793:mdna:47]

[0001437749-23-029753:mdna:50]
Net loss was $2.5 million and $7.9 million in the three and six months ended September 30, 2023, respectively, compared to $9.9 million and $18.6 million in the three and six months ended September 30, 2022, respectively. The decrease in net loss in both periods was driven primarily by the increased revenues and gross margins.

[0001437749-23-029753:mdna:51]
Non-GAAP Financial Measure - Non-GAAP Net Income (Loss)

[0001437749-23-029753:mdna:52]
[same as prior period, unchanged from 0001437749-23-022793:mdna:50]

[0001437749-23-029753:mdna:53]
We define non-GAAP net income (loss) as net loss before, China dissolution, stock-based compensation, amortization of acquisition-related intangibles, change in fair value of contingent consideration, and other non-cash or unusual charges.  We believe non-GAAP net income (loss) assists management and investors in comparing our performance across reporting periods on a consistent basis by excluding these non-cash charges and other items that we do not believe are indicative of our core operating performance. In addition, we use non-GAAP net income (loss) as a factor to evaluate the effectiveness of our business strategies. A reconciliation of GAAP to non-GAAP net income (loss) is set forth in the table below (in thousands, except per share data):

[0001437749-23-029753:mdna:54]
|  |  | Three Months Ended September 30, |  |  | Six Months Ended September 30, |  |
|  |  | 2023 |  |  | 2022 |  |  | 2023 |  |  | 2022 |  |
| Net loss |  | $ | (2,485 | ) |  | $ | (9,881 | ) |  | $ | (7,883 | ) |  | $ | (18,590 | ) |
| China dissolution |  |  | - |  |  |  | 1,921 |  |  |  | - |  |  |  | 1,921 |  |
| Stock-based compensation |  |  | 1,111 |  |  |  | 1,019 |  |  |  | 2,468 |  |  |  | 2,052 |  |
| Amortization of acquisition-related intangibles |  |  | 538 |  |  |  | 688 |  |  |  | 1,082 |  |  |  | 1,400 |  |
| Change in fair value of contingent consideration |  |  | 850 |  |  |  | (290 | ) |  |  | 2,200 |  |  |  | (120 | ) |
| Non-GAAP net income (loss) |  | $ | 14 |  |  | $ | (6,542 | ) |  | $ | (2,133 | ) |  | $ | (13,337 | ) |
| Non-GAAP net income (loss) per share - basic |  | $ | 0.00 |  |  | $ | (0.23 | ) |  | $ | (0.07 | ) |  | $ | (0.48 | ) |
| Weighted average shares outstanding - basic |  |  | 28,828 |  |  |  | 27,867 |  |  |  | 28,545 |  |  |  | 27,714 |  |

[0001437749-23-029753:mdna:55]
We incurred non-GAAP net income of less than $0.1 million and a non-GAAP net loss of $2.1 million, or $0.00 and $0.07 per share, for the three and six months ended September 30, 2023, respectively, compared to non-GAAP net losses of $6.5 million and $13.3 million, or $0.23 and $0.48 per share, for the three and six months ended September 30, 2022, respectively. The improvement in the non-GAAP net loss for the three and six months ended September 30, 2023 was due to a lower operating loss driven by higher revenues and gross margins.

[0001437749-23-029753:mdna:56]
32

[0001437749-23-029753:mdna:57]
[same as prior period, unchanged from 0001437749-23-022793:mdna:54]

[0001437749-23-029753:mdna:58]
We have experienced recurring operating losses and, as of September 30, 2023, had an accumulated deficit of $1,063.4 million.

[0001437749-23-029753:mdna:59]
[same as prior period, unchanged from 0001437749-23-022793:mdna:56]

[0001437749-23-029753:mdna:60]
[same as prior period, unchanged from 0001437749-23-022793:mdna:57]

[0001437749-23-029753:mdna:61]
As of September 30, 2023, we had cash, cash equivalents and restricted cash of $24.0 million, compared to $25.7 million as of March 31, 2023, a decrease of $1.7 million. As of September 30, 2023, we had $2.6 million in cash, cash equivalents, and restricted cash in foreign bank accounts. Our cash, cash equivalents, and restricted cash are summarized as follows (in thousands):

[0001437749-23-029753:mdna:62]
|  |  | September 30, 2023 |  |  | March 31, 2023 |  |
| Cash and cash equivalents |  | $ | 22,818 |  |  | $ | 23,360 |  |
| Restricted cash |  |  | 1,162 |  |  |  | 2,315 |  |
| Total cash, cash equivalents, and restricted cash |  | $ | 23,980 |  |  | $ | 25,675 |  |

[0001437749-23-029753:mdna:63]
For the six months ended September 30, 2023, net cash used in operating activities was $1.3 million, compared to $11.6 million for the six months ended September 30, 2022. The decrease in net cash used in operations was due primarily to decrease in prepaid expenses and other current asset as well as accounts receivable in the six months ended September 30, 2023 as compared to September 30, 2022. Cash flows from operating activities in the six months ended September 30, 2023 included a reimbursement of $3.0 million for the ERC receivable in prepaid expenses and other current assets at March 31, 2023.

[0001437749-23-029753:mdna:64]
For the six months ended September 30, 2023, net cash used in investing activities was $0.4 million, compared to $0.7 million for the six months ended September 30, 2022. The decrease in net cash used in investing activities was primarily due to a decrease in purchases of property, plant and equipment.

[0001437749-23-029753:mdna:65]
For the six months ended September 30, 2023 and 2022, respectively, net cash provided by financing activities remained consistent at $0.1 million.

[0001437749-23-029753:mdna:66]
As of September 30, 2023, we had $0.6 million of restricted cash included in long-term assets and $0.5 million of restricted cash included in current assets. At March 31, 2023, we had $0.6 million of restricted cash included in long-term assets and $1.7 million of restricted cash in current assets. These amounts included in restricted cash primarily represent collateral deposits to secure surety bonds and letters of credit for various customer contracts. These deposits are held in interest bearing accounts.

[0001437749-23-029753:mdna:67]
We are a party to many contractual obligations involving commitments to make payments to third parties. These obligations impact our short-term and long-term liquidity and capital resource needs. Certain contractual obligations are reflected on the consolidated balance sheet as of September 30, 2023, while others are considered future commitments. We have various contractual arrangements, under which we have committed to purchase certain minimum quantities of goods or services on an annual basis. For information regarding our other contractual obligations, refer to Note 13, "Contingent Consideration," Note 14, "Debt," Note 15, "Leases" and Note 16, "Commitments and Contingencies" to our condensed consolidated financial statements included elsewhere in this Quarterly Report on Form 10-Q.

[0001437749-23-029753:mdna:68]
We believe we have sufficient available liquidity to fund our operations and capital expenditures for the next twelve months. In addition, we may seek to raise additional capital, which could be in the form of loans, convertible debt or equity, to fund our operating requirements and capital expenditures. Our liquidity is highly dependent on our ability to increase revenues, control our operating costs, and raise additional capital, if necessary. There can be no assurance that we will be able to raise additional capital on favorable terms or at all or execute on any other means of improving our liquidity as described above.  Additionally, the impact of the COVID-19 pandemic or other sources of instability, including the ongoing wars between Russia and Ukraine or Israel and Hamas, instability of financial institutions and political instability in the United States, on the global financial markets may reduce our ability to raise additional capital, if necessary, which could negatively impact our liquidity. We also continue to closely monitor our expenses and, if required, we intend to reduce our operating and capital spending to enhance liquidity.

[0001437749-23-029753:mdna:69]
Legal Proceedings

[0001437749-23-029753:mdna:70]
[same as prior period, unchanged from 0001437749-23-022793:mdna:67]

[0001437749-23-029753:mdna:71]
[same as prior period, unchanged from 0001437749-23-022793:mdna:68]

[0001437749-23-029753:mdna:72]
In June 2016, the Financial Accounting Standards Board ("FASB") issued Accounting Standards Update ("ASU") 2016-13, Financial Instruments-Credit Losses (Topic 326): Measurement of Credit Losses on Financial Instruments. The amendments in ASU 2016-13 will provide more decision-useful information about the expected credit losses on financial instruments and other commitments to extend credit held by a reporting entity at each reporting date. Following the release of ASU 2019-10 in November 2019, the effective date, as long as we remain a smaller reporting company, was annual reporting periods beginning after December 15, 2022.  As of April 1, 2023, we have adopted ASU 2016-13 and noted no material impact on our condensed consolidated financial statements.

[0001437749-23-029753:mdna:73]
In October 2021, the FASB issued ASU 2021-08, Business Combinations (Topic 805): Accounting for Contract Assets and Contract Liabilities from Contracts with Customers. The amendments in ASU 2021-08 will improve the accounting for acquired revenue contracts with customers in a business combination. Following the release of ASU 2021-08 in October 2021, the effective date was annual reporting periods beginning after December 15, 2022. As of April 1, 2023, we have adopted ASU 2021-08 and noted no material impact on our condensed consolidated financial statements.

[0001437749-23-029753:mdna:74]
We do not believe that, outside of those disclosed here, there are any other recently issued accounting pronouncements that will have a material impact on our condensed consolidated financial statements.
