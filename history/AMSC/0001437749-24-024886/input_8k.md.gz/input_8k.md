# AMSC 8-K — 0001437749-24-024881 filed 2024-08-06

## item codes, every 8-K on or before 2024-08-06

- 2024-08-06 0001437749-24-024924 — 9.01 — amendment of 0001193125-24-193425
- 2024-08-06 0001437749-24-024881 — 2.02, 9.01
- 2024-08-05 0001193125-24-193965 — 5.02, 5.07, 9.01
- 2024-08-05 0001193125-24-193425 — 1.01, 2.01, 8.01, 9.01
- 2024-05-29 0001437749-24-018599 — 2.02, 5.02, 9.01
- 2024-01-31 0001193125-24-020938 — 8.01, 9.01
- 2024-01-24 0001437749-24-002040 — 2.02, 9.01
- 2023-11-01 0001437749-23-029749 — 2.02, 9.01
- 2023-08-11 0001437749-23-023329 — 5.07
- 2023-08-09 0001437749-23-022786 — 2.02, 9.01
- 2023-06-21 0001193125-23-171201 — 5.02, 9.01
- 2023-05-31 0001437749-23-016264 — 2.02, 9.01
- 2023-02-01 0001437749-23-002268 — 2.02, 9.01
- 2022-11-01 0001437749-22-025365 — 2.02, 9.01
- 2022-08-05 0001193125-22-213651 — 5.02, 5.07, 9.01
- 2022-08-03 0001437749-22-018628 — 2.02, 9.01
- 2022-06-10 0001437749-22-014780 — 5.02, 9.01
- 2022-06-01 0001437749-22-014033 — 2.02, 9.01
- 2022-02-02 0001437749-22-002207 — 2.02, 9.01
- 2021-11-08 0001437749-21-025697 — 2.02, 9.01
- 2021-08-04 0001437749-21-018522 — 2.02, 9.01
- 2021-08-02 0001193125-21-233260 — 5.07
- 2021-06-02 0001437749-21-013955 — 2.02, 9.01
- 2021-05-25 0001437749-21-013279 — 5.02, 9.01
- 2021-05-21 0001193125-21-168626 — 8.01, 9.01
- 2021-05-10 0001193125-21-156251 — 1.01, 9.01
- 2021-02-26 0001193125-21-060434 — 8.01, 9.01
- 2021-02-03 0001437749-21-001859 — 2.02, 9.01
- 2021-02-01 0001437749-21-001681 — 5.03, 9.01
- 2020-12-14 0001437749-20-025291 — 9.01 — amendment, the index does not say of what
- 2020-11-04 0001437749-20-022520 — 2.02, 9.01
- 2020-10-26 0001193125-20-276900 — 8.01, 9.01
- 2020-10-05 0001437749-20-020735 — 2.02
- 2020-10-05 0001437749-20-020734 — 1.01, 2.01, 3.02, 9.01
- 2020-10-02 0001437749-20-020660 — 8.01
- 2020-09-16 0001437749-20-019767 — 8.01
- 2020-08-05 0001437749-20-016665 — 2.02, 5.07, 9.01
- 2020-06-02 0001437749-20-012274 — 2.02, 9.01
- 2020-05-27 0001437749-20-011837 — 5.02, 9.01
- 2020-02-05 0001437749-20-001788 — 2.02, 9.01
- 2019-11-05 0001437749-19-021590 — 2.02, 9.01
- 2019-08-06 0001437749-19-015631 — 2.02, 9.01
- 2019-08-06 0001193125-19-214189 — 5.02, 5.07, 9.01
- 2019-06-05 0001437749-19-011476 — 2.02, 5.02, 9.01
- 2019-05-24 0001437749-19-010833 — 5.02
- 2019-02-05 0001628280-19-000964 — 2.02, 8.01, 9.01
- 2018-11-06 0001628280-18-013765 — 2.02, 9.01
- 2018-10-31 0001628280-18-013204 — 1.01
- 2018-08-01 0001628280-18-010196 — 5.07
- 2018-07-31 0001628280-18-009846 — 2.02, 9.01
- 2018-07-09 0001193125-18-214745 — 1.01, 9.01
- 2018-07-03 0001628280-18-009075 — 5.02, 9.01
- 2018-06-14 0001628280-18-007877 — 5.02
- 2018-06-06 0001628280-18-007643 — 2.02, 9.01
- 2018-04-10 0001628280-18-004141 — 5.02
- 2018-04-03 0001628280-18-003952 — 2.01, 9.01
- 2018-02-05 0001628280-18-000989 — 2.02, 9.01
- 2018-02-01 0001628280-18-000826 — 1.01, 9.01
- 2017-11-07 0001628280-17-011076 — 2.02, 9.01
- 2017-09-26 0001628280-17-009444 — 3.02, 8.01
- 2017-08-08 0001628280-17-008329 — 2.02, 9.01
- 2017-08-01 0001628280-17-007765 — 5.02, 5.07
- 2017-07-03 0001193125-17-221140 — 5.02, 9.01
- 2017-05-26 0001193125-17-185503 — 8.01, 9.01
- 2017-05-25 0001628280-17-005914 — 2.02, 9.01 — amendment of 0001628280-17-005884
- 2017-05-25 0001628280-17-005884 — 2.02, 9.01
- 2017-05-10 0001193125-17-165924 — 8.01, 9.01
- 2017-05-09 0001193125-17-164273 — 5.02
- 2017-05-04 0001193125-17-158639 — 1.02, 8.01
- 2017-04-26 0001193125-17-139493 — 2.02, 9.01
- 2017-04-04 0001193125-17-109748 — 2.05, 5.02, 9.01
- 2017-02-06 0001628280-17-000899 — 2.02, 9.01
- 2017-01-27 0001193125-17-021808 — 1.01, 2.02, 9.01
- 2016-11-02 0001628280-16-020598 — 2.02, 9.01
- 2016-09-16 0001193125-16-712301 — 5.02
- 2016-08-23 0001193125-16-688767 — 8.01
- 2016-08-09 0001628280-16-018763 — 2.02, 9.01
- 2016-08-02 0001193125-16-668417 — 5.02, 5.07, 9.01
- 2016-05-31 0001564590-16-020114 — 2.02, 9.01
- 2016-05-18 0001193125-16-594515 — 5.02
- 2016-03-08 0001193125-16-496113 — 1.01
- 2016-02-09 0001193125-16-454775 — 2.02, 9.01
- 2015-12-17 0001193125-15-405566 — 1.01
- 2015-11-03 0001193125-15-363413 — 2.02, 9.01
- 2015-08-31 0001193125-15-307558 — 1.01
- 2015-08-05 0001193125-15-277824 — 2.02, 9.01
- 2015-07-31 0001193125-15-273009 — 5.07
- 2015-06-26 0001193125-15-237190 — 5.02
- 2015-06-09 0001193125-15-218028 — 8.01
- 2015-05-28 0001193125-15-202933 — 2.02, 9.01
- 2015-04-28 0001193125-15-153319 — 8.01, 9.01
- 2015-04-23 0001193125-15-144123 — 2.02, 8.01, 9.01
- 2015-04-23 0001193125-15-143608 — 8.01
- 2015-04-10 0001193125-15-126160 — 8.01
- 2015-03-24 0001193125-15-103436 — 5.03, 9.01
- 2015-03-18 0001193125-15-097034 — 5.07
- 2015-02-05 0001193125-15-034499 — 2.02, 9.01
- 2015-01-29 0001193125-15-024629 — 2.02, 9.01
- 2015-01-21 0001193125-15-016287 — 3.01, 8.01
- 2015-01-06 0001193125-15-002902 — 5.02
- 2014-12-22 0001193125-14-450591 — 1.01, 2.03, 3.02, 9.01
- 2014-11-13 0001193125-14-410207 — 1.01, 9.01
- 2014-11-07 0001193125-14-402383 — 1.02, 7.01, 9.01
- 2014-11-06 0001193125-14-399779 — 2.02, 9.01
- 2014-10-01 0001193125-14-360072 — 2.02, 8.01, 9.01
- 2014-09-04 0001193125-14-331411 — 8.01
- 2014-08-21 0001193125-14-317133 — 1.01
- 2014-08-06 0001193125-14-298306 — 5.02, 5.07, 9.01
- 2014-08-05 0001193125-14-294647 — 2.02, 9.01
- 2014-07-16 0001193125-14-269902 — 8.01
- 2014-06-23 0001193125-14-244592 — 3.02, 8.01
- 2014-06-05 0001193125-14-226459 — 2.02, 9.01
- 2014-06-05 0001193125-14-226457 — 1.01, 9.01
- 2014-03-19 0001193125-14-106558 — 2.05
- 2014-03-03 0001193125-14-078917 — 1.01, 3.02, 9.01
- 2014-02-28 0001193125-14-077480 — 8.01, 9.01
- 2014-02-06 0001193125-14-037960 — 2.02, 8.01, 9.01
- 2013-11-20 0001193125-13-447829 — 3.02, 8.01
- 2013-11-18 0001193125-13-444697 — 1.01, 2.03, 3.02, 9.01
- 2013-11-07 0001193125-13-431705 — 2.02, 9.01
- 2013-10-09 0001193125-13-395362 — 1.01, 2.03, 3.02, 9.01
- 2013-09-25 0001193125-13-378481 — 5.02, 9.01
- 2013-08-21 0001193125-13-341566 — 4.01, 9.01
- 2013-08-07 0001193125-13-323082 — 2.02, 9.01
- 2013-08-02 0001193125-13-317278 — 5.02, 5.07
- 2013-06-14 0001193125-13-258758 — 2.02, 9.01
- 2013-04-01 0001193125-13-136714 — 2.02, 8.01, 9.01
- 2013-02-20 0001193125-13-067218 — 5.02, 9.01
- 2013-02-14 0001193125-13-060131 — 1.01, 9.01
- 2013-02-11 0001193125-13-048784 — 2.02, 9.01
- 2013-01-08 0001193125-13-006861 — 5.02, 9.01
- 2012-12-21 0001193125-12-511592 — 1.01, 2.03, 3.02, 9.01
- 2012-11-28 0001193125-12-483317 — 2.05, 5.02, 7.01, 9.01
- 2012-11-06 0001193125-12-453359 — 2.02, 9.01
- 2012-08-02 0001193125-12-330534 — 2.02, 9.01
- 2012-07-27 0001193125-12-318790 — 5.02, 5.07, 9.01
- 2012-06-06 0001193125-12-261030 — 1.01, 2.02, 2.03, 3.02, 5.02, 9.01
- 2012-05-09 0001193125-12-222210 — 5.02
- 2012-04-20 0001193125-12-172045 — 8.01
- 2012-04-13 0001193125-12-162694 — 2.02, 8.01, 9.01
- 2012-04-04 0001193125-12-149102 — 1.01, 2.02, 2.03, 3.02, 9.01
- 2012-02-09 0001193125-12-048009 — 2.02, 9.01
- 2012-02-06 0001193125-12-041344 — 5.07 — amendment of 0000950123-11-102495
- 2011-12-08 0000950123-11-102495 — 5.07
- 2011-11-29 0000950123-11-100822 — 2.05
- 2011-11-09 0000950123-11-096775 — 2.02, 9.01
- 2011-10-31 0000950123-11-093390 — 1.02, 9.01
- 2011-10-07 0000950123-11-089221 — 8.01
- 2011-10-03 0000950123-11-088315 — 7.01
- 2011-09-23 0000950123-11-086288 — 2.02, 9.01
- 2011-09-15 0000950123-11-084585 — 7.01
- 2011-09-06 0000950123-11-082736 — 7.01
- 2011-08-18 0000950123-11-078526 — 3.01, 7.01, 9.01
- 2011-08-11 0000950123-11-075905 — 5.02
- 2011-08-11 0000950123-11-075904 — 2.02, 2.05, 9.01
- 2011-07-11 0000950123-11-064934 — 2.02, 4.02, 9.01
- 2011-06-30 0000950123-11-063287 — 1.01, 3.02, 9.01
- 2011-06-21 0000950123-11-060491 — 3.01, 7.01, 9.01
- 2011-06-13 0000950123-11-058656 — 1.01, 9.01
- 2011-05-24 0000950123-11-053517 — 5.02, 9.01
- 2011-04-05 0001299933-11-001020 — 2.02, 9.01
- 2011-03-15 0000950123-11-025580 — 5.02
- 2011-03-14 0000950123-11-025205 — 1.01, 3.02, 9.01
- 2011-02-01 0001299933-11-000333 — 2.02, 9.01
- 2010-11-12 0000950123-10-104604 — 8.01, 9.01
- 2010-11-08 0000950123-10-102424 — 8.01, 9.01
- 2010-11-02 0001299933-10-003878 — 2.02, 9.01
- 2010-09-15 0000950123-10-086373 — 1.01, 9.01 — amendment, the index does not say of what
- 2010-08-06 0000950123-10-074362 — 5.07
- 2010-07-29 0001299933-10-002860 — 2.02, 9.01
- 2010-05-17 0000950123-10-050424 — 1.01, 9.01
- 2010-05-14 0001299933-10-001972 — 5.02
- 2010-05-13 0001299933-10-001943 — 2.02, 9.01
- 2010-02-08 0001299933-10-000506 — 8.01
- 2010-02-02 0001299933-10-000386 — 2.02, 9.01
- 2009-12-15 0001299933-09-004928 — 5.02
- 2009-10-29 0001299933-09-004267 — 2.02, 9.01
- 2009-08-12 0001193125-09-173026 — 5.02, 9.01
- 2009-07-30 0001193125-09-158842 — 1.01, 2.02, 9.01
- 2009-05-15 0001193125-09-113158 — 5.02
- 2009-05-14 0001193125-09-110619 — 2.02, 9.01
- 2009-04-20 0001193125-09-082590 — 5.02
- 2009-02-03 0001193125-09-016992 — 2.02, 9.01
- 2009-01-22 0001193125-09-009777 — 2.02, 9.01
- 2008-11-04 0001193125-08-223730 — 2.02, 9.01
- 2008-08-11 0001193125-08-173616 — 8.01
- 2008-08-07 0001193125-08-170325 — 8.01
- 2008-08-05 0001193125-08-165888 — 2.02, 9.01
- 2008-06-11 0001193125-08-132049 — 1.01, 9.01
- 2008-05-20 0001193125-08-119372 — 5.02, 9.01
- 2008-05-08 0001193125-08-107052 — 2.02, 9.01
- 2008-01-31 0001193125-08-016233 — 2.02, 9.01
- 2008-01-30 0001193125-08-015494 — 5.03, 9.01
- 2007-11-01 0001193125-07-231866 — 2.02, 9.01
- 2007-10-31 0001193125-07-231225 — 2.05
- 2007-10-29 0001193125-07-228284 — 5.03, 9.01
- 2007-09-27 0001193125-07-208950 — 5.02
- 2007-08-09 0001193125-07-176553 — 2.02, 9.01
- 2007-08-07 0001193125-07-173829 — 1.01, 5.02, 9.01
- 2007-07-02 0001193125-07-148303 — 5.02, 9.01
- 2007-06-20 0001193125-07-139068 — 8.01, 9.01
- 2007-06-14 0001193125-07-135550 — 9.01 — amendment of 0001193125-07-005297
- 2007-06-14 0001193125-07-135340 — 5.02
- 2007-05-24 0001193125-07-122148 — 2.02, 9.01
- 2007-03-30 0001193125-07-070154 — 2.05, 9.01
- 2007-03-23 0001193125-07-062978 — 9.01 — amendment of 0001193125-07-005297
- 2007-02-01 0001193125-07-017883 — 2.02, 9.01
- 2007-01-11 0001193125-07-005297 — 2.01, 9.01
- 2006-12-05 0001181431-06-067500 — 5.02
- 2006-11-29 0001193125-06-243360 — 1.01, 3.02, 9.01
- 2006-11-02 0001193125-06-221464 — 2.02, 9.01
- 2006-09-21 0001193125-06-194526 — 5.02
- 2006-08-08 0001193125-06-164819 — 2.02, 9.01
- 2006-08-02 0001193125-06-159113 — 1.01, 9.01
- 2006-07-28 0001193125-06-156172 — 1.01
- 2006-06-26 0001193125-06-135913 — 1.01, 3.03, 9.01
- 2006-05-11 0001193125-06-108489 — 2.02, 9.01
- 2006-05-05 0001193125-06-102270 — 1.01, 9.01
- 2006-05-01 0001193125-06-094941 — 2.02, 2.06, 9.01
- 2006-02-24 0001193125-06-038281 — 5.02, 9.01
- 2006-02-02 0001181431-06-007665 — 2.02, 9.01
- 2005-11-09 0001181431-05-060304 — 2.02, 9.01
- 2005-08-04 0001181431-05-044420 — 2.02, 9.01
- 2005-07-28 0001193125-05-151272 — 5.02, 9.01
- 2005-06-14 0001193125-05-125148 — 5.02, 9.01
- 2005-05-12 0001181431-05-027410 — 2.02, 9.01
- 2005-05-10 0001193125-05-102795 — 1.01
- 2005-04-05 0001181431-05-020680 — 1.01, 2.02, 3.02, 9.01
- 2005-02-03 0001181431-05-006678 — 2.02, 9.01
- 2004-11-09 0001181431-04-051381 — 2.02, 9.01 — amendment, the index does not say of what
- 2004-11-04 0001181431-04-050706 — 2.02, 9.01
- 2004-10-15 0001193125-04-172458 — 1.01, 9.01
- 2004-08-05 0001193125-04-132162 — 12
- 2004-05-13 0001193125-04-086853 — 12
- 2004-02-05 0001193125-04-015060 — 12
- 2003-11-06 0001193125-03-074000 — 12
- 2003-09-26 0001193125-03-054624 — 5
- 2003-08-06 0001193125-03-029666 — 12
- 2003-05-14 0000927016-03-002619 — 9
- 2002-12-31 0000927016-02-006114 — 5
- 2000-01-24 0000927016-00-000150 — 5, 7
- 1998-11-02 0000950135-98-005625 — 5, 7
- 1998-03-24 0000950135-98-001743 — 5, 7
- 1997-09-05 0000950135-97-003729 — 5, 7
- 1997-06-23 0000950135-97-002785 — 1 — amendment of 0000950135-97-001972
- 1997-04-23 0000950135-97-001972 — 2, 7

## late-filing notifications on or before 2024-08-06

- 2011-08-10 0000950123-11-075677 — NT 10-Q, for the period ended 2011-06-30
- 2011-05-31 0000950123-11-055465 — NT 10-K, for the period ended 2011-03-31

## item 2.02 — earnings release, exhibit 99.1

[0001437749-24-024881:8k_2_02:1]
EX-99.1
2
ex_679608.htm
EXHIBIT 99.1

[0001437749-24-024881:8k_2_02:2]
ex_679608.htm

[0001437749-24-024881:8k_2_02:3]
Exhibit 99.1

[0001437749-24-024881:8k_2_02:4]
AMSC Reports First Quarter Fiscal Year 2024 Financial Results and Provides Business Outlook

[0001437749-24-024881:8k_2_02:5]
|  | Q1 Financial Highlights: |
|  | • Revenues Increased Over 33% Year Over Year to $40 Million • Reported Expanded Gross Margin and Achieved Non-GAAP Net Income • Generated $3.4 Million of Operating Cash Flow |

[0001437749-24-024881:8k_2_02:6]
Company to host conference call tomorrow, August 7th, at 10:00 am ET

[0001437749-24-024881:8k_2_02:7]
Ayer, MA – August 6, 2024 – AMSC (Nasdaq: AMSC), a leading system provider of megawatt-scale power resiliency solutions that orchestrate the rhythm and harmony of power on the grid™ and protect and expand the capability and resiliency of our Navy’s fleet, today reported financial results for its first quarter of fiscal year 2024 ended June 30, 2024.

[0001437749-24-024881:8k_2_02:8]
Revenues for the first quarter of fiscal 2024 were $40.3 million compared with $30.3 million for the same period of fiscal 2023. The year-over-year increase was driven by increased shipments of new energy power systems and electrical control system shipments, versus the year ago period.

[0001437749-24-024881:8k_2_02:9]
AMSC’s net loss for the first quarter of fiscal 2024 was $2.5 million, or $0.07 per share, compared to a net loss of $5.4 million, or $0.19 per share, for the same period of fiscal 2023. The Company’s non-GAAP net income for the first quarter of fiscal 2024 was $3.0 million, or $0.09 per share, compared with a non-GAAP net loss of $2.1 million, or $0.08 per share, in the same period of fiscal 2023. Please refer to the financial table below for a reconciliation of GAAP to non-GAAP results.

[0001437749-24-024881:8k_2_02:10]
Cash, cash equivalents, and restricted cash on June 30, 2024, totaled $95.5 million, compared with $92.3 million at March 31, 2024.

[0001437749-24-024881:8k_2_02:11]
"We are building a fundamentally stronger company and reporting another quarter of solid results to start our fiscal 2024. AMSC delivered over $3 million of operating cash flow, expanded gross margins and grew revenue by over 30% when compared to the same period last year,” said Daniel P. McGahn, Chairman, President and CEO, AMSC. “During the first quarter of fiscal 2024, we booked over $127 million of new orders, including our first Ship Protection System contract with an allied navy and our third 3MW ECS order from Inox Wind. We ended the quarter with $160 million in 12-month backlog and $250 million in total backlog. Our performance reflects our ability to deliver business diversification, financial growth and expanded scale, which we intend to leverage further in 2024 with our recent acquisition announcement. We believe we are in a strong position for continued diversified Grid growth in the industrial and military sectors."

[0001437749-24-024881:8k_2_02:12]
| AMSC Reports Q1 FY24 Results | Page 2 |

[0001437749-24-024881:8k_2_02:13]
Business Outlook

[0001437749-24-024881:8k_2_02:14]
For the second quarter ending September 30, 2024, AMSC expects that its revenues will be in the range of $38.0 million to $42.0 million. The Company’s net loss for the second quarter of fiscal 2024 is expected not to exceed $1.7 million, or $0.05 per share. The Company’s net loss guidance assumes no changes in fair value of contingent consideration. The Company's non-GAAP net loss (as defined below) is expected to be at least breakeven on a total and per share basis. The Company expects operating cash flow to be breakeven to a positive cash generation of $2.0 million in the second quarter of fiscal 2024. The Company's guidance does not include the impact of the recently announced acquisition of NWL.

[0001437749-24-024881:8k_2_02:15]
Conference Call Reminder

[0001437749-24-024881:8k_2_02:16]
In conjunction with this announcement, AMSC management will participate in a conference call with investors beginning at 10:00 a.m. Eastern Time on Wednesday, August 7, 2024, to discuss the Company’s financial results and business outlook. Those who wish to listen to the live or archived conference call webcast should visit the “Investors” section of the Company’s website at https://ir.amsc.com. The live call can be accessed by dialing 1-844-481-2802 or 1-412-317- 0675 and asking to join the AMSC call. A replay of the call may be accessed 2 hours following the call by dialing 1-877-344-7529 and using conference passcode 9653245.

[0001437749-24-024881:8k_2_02:17]
About AMSC (Nasdaq: AMSC)

[0001437749-24-024881:8k_2_02:18]
AMSC generates the ideas, technologies and solutions that meet the world’s demand for smarter, cleaner … better energy™. Through its Gridtec™ Solutions, AMSC provides the engineering planning services and advanced grid systems that optimize network reliability, efficiency and performance.  Through its Marinetec™ Solutions, AMSC provides ship protection systems and is developing propulsion and power management solutions designed to help fleets increase system efficiencies, enhance power quality and boost operational safety.  Through its Windtec® Solutions, AMSC provides wind turbine electronic controls and systems, designs and engineering services that reduce the cost of wind energy. The Company’s solutions are enhancing the performance and reliability of power networks, increasing the operational safety of navy fleets, and powering gigawatts of renewable energy globally. Founded in 1987, AMSC is headquartered near Boston, Massachusetts with operations in Asia, Australia, Europe and North America. For more information, please visit www.amsc.com.

[0001437749-24-024881:8k_2_02:19]
AMSC, American Superconductor, D-VAR, D-VAR VVO, Gridtec, Marinetec, Windtec, Neeltran, NEPSI, Smarter, Cleaner … Better Energy, and Orchestrate the Rhythm and Harmony of Power on the Grid are trademarks or registered trademarks of American Superconductor Corporation. All other brand names, product names, trademarks or service marks belong to their respective holders.

[0001437749-24-024881:8k_2_02:20]
| AMSC Reports Q1 FY24 Results | Page 3 |

[0001437749-24-024881:8k_2_02:21]
Forward-Looking Statements

[0001437749-24-024881:8k_2_02:22]
| AMSC Reports Q1 FY24 Results | Page 4 |

[0001437749-24-024881:8k_2_02:23]
UNAUDITED CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS

[0001437749-24-024881:8k_2_02:24]
(In thousands, except per share data)

[0001437749-24-024881:8k_2_02:25]
|  |  | Three Months Ended |  |
|  |  | June 30, |  |
|  |  | 2024 |  |  | 2023 |  |
| Revenues |  |  |  |  |  |  |  |  |
| Grid |  | $ | 32,336 |  |  | $ | 25,737 |  |
| Wind |  |  | 7,954 |  |  |  | 4,517 |  |
| Total revenues |  |  | 40,290 |  |  |  | 30,254 |  |
| Cost of revenues |  |  | 28,065 |  |  |  | 23,972 |  |
| Gross margin |  |  | 12,225 |  |  |  | 6,282 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |
| Research and development |  |  | 2,286 |  |  |  | 1,853 |  |
| Selling, general and administrative |  |  | 8,898 |  |  |  | 7,868 |  |
| Amortization of acquisition-related intangibles |  |  | 412 |  |  |  | 538 |  |
| Change in fair value of contingent consideration |  |  | 3,920 |  |  |  | 1,350 |  |
| Restructuring |  |  | — |  |  |  | 6 |  |
| Total operating expenses |  |  | 15,516 |  |  |  | 11,615 |  |
| Operating loss |  |  | (3,291 | ) |  |  | (5,333 | ) |
| Interest income, net |  |  | 1,120 |  |  |  | 174 |  |
| Other expense, net |  |  | (160 | ) |  |  | (118 | ) |
| Loss before income tax expense |  |  | (2,331 | ) |  |  | (5,277 | ) |
| Income tax expense |  |  | 193 |  |  |  | 121 |  |
| Net loss |  | $ | (2,524 | ) |  | $ | (5,398 | ) |
| Net loss per common share |  |  |  |  |  |  |  |  |
| Basic |  | $ | (0.07 | ) |  | $ | (0.19 | ) |
| Diluted |  | $ | (0.07 | ) |  | $ | (0.19 | ) |
| Weighted average number of common shares outstanding |  |  |  |  |  |  |  |  |
| Basic |  |  | 35,676 |  |  |  | 28,258 |  |
| Diluted |  |  | 35,676 |  |  |  | 28,258 |  |

[0001437749-24-024881:8k_2_02:26]
| AMSC Reports Q1 FY24 Results | Page 5 |

[0001437749-24-024881:8k_2_02:27]
UNAUDITED CONDENSED CONSOLIDATED BALANCE SHEETS

[0001437749-24-024881:8k_2_02:28]
(In thousands, except per share data)

[0001437749-24-024881:8k_2_02:29]
|  |  | June 30, 2024 |  |  | March 31, 2024 |  |
| ASSETS |  |  |  |  |  |  |  |  |
| Current assets: |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 93,455 |  |  | $ | 90,522 |  |
| Accounts receivable, net |  |  | 23,529 |  |  |  | 26,325 |  |
| Inventory, net |  |  | 45,149 |  |  |  | 41,857 |  |
| Prepaid expenses and other current assets |  |  | 10,424 |  |  |  | 7,295 |  |
| Restricted cash |  |  | 468 |  |  |  | 468 |  |
| Total current assets |  |  | 173,025 |  |  |  | 166,467 |  |
| Property, plant and equipment, net |  |  | 10,529 |  |  |  | 10,861 |  |
| Intangibles, net |  |  | 5,957 |  |  |  | 6,369 |  |
| Right-of-use assets |  |  | 4,096 |  |  |  | 2,557 |  |
| Goodwill |  |  | 43,471 |  |  |  | 43,471 |  |
| Restricted cash |  |  | 1,600 |  |  |  | 1,290 |  |
| Deferred tax assets |  |  | 1,114 |  |  |  | 1,119 |  |
| Other assets |  |  | 351 |  |  |  | 637 |  |
| Total assets |  | $ | 240,143 |  |  | $ | 232,771 |  |
| LIABILITIES AND STOCKHOLDERS' EQUITY |  |  |  |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |  |  |  |
| Accounts payable and accrued expenses |  | $ | 22,309 |  |  | $ | 24,235 |  |
| Lease liability, current portion |  |  | 862 |  |  |  | 716 |  |
| Debt, current portion |  |  | 9 |  |  |  | 25 |  |
| Contingent consideration |  |  | 7,020 |  |  |  | 3,100 |  |
| Deferred revenue, current portion |  |  | 55,984 |  |  |  | 50,732 |  |
| Total current liabilities |  |  | 86,184 |  |  |  | 78,808 |  |
| Deferred revenue, long term portion |  |  | 6,929 |  |  |  | 7,097 |  |
| Lease liability, long term portion |  |  | 3,359 |  |  |  | 1,968 |  |
| Deferred tax liabilities |  |  | 300 |  |  |  | 300 |  |
| Other liabilities |  |  | 27 |  |  |  | 27 |  |
| Total liabilities |  |  | 96,799 |  |  |  | 88,200 |  |
| Stockholders' equity: |  |  |  |  |  |  |  |  |
| Common stock |  |  | 374 |  |  |  | 373 |  |
| Additional paid-in capital |  |  | 1,214,320 |  |  |  | 1,212,913 |  |
| Treasury stock |  |  | (3,765 | ) |  |  | (3,639 | ) |
| Accumulated other comprehensive income |  |  | 1,597 |  |  |  | 1,582 |  |
| Accumulated deficit |  |  | (1,069,182 | ) |  |  | (1,066,658 | ) |
| Total stockholders' equity |  |  | 143,344 |  |  |  | 144,571 |  |
| Total liabilities and stockholders' equity |  | $ | 240,143 |  |  | $ | 232,771 |  |

[0001437749-24-024881:8k_2_02:30]
| AMSC Reports Q1 FY24 Results | Page 6 |

[0001437749-24-024881:8k_2_02:31]
UNAUDITED CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS

[0001437749-24-024881:8k_2_02:32]
(In thousands)

[0001437749-24-024881:8k_2_02:33]
|  |  | Three Months Ended June 30, |  |
|  |  | 2024 |  |  | 2023 |  |
| Cash flows from operating activities: |  |  |  |  |  |  |  |  |
| Net loss |  | $ | (2,524 | ) |  | $ | (5,398 | ) |
| Adjustments to reconcile net loss to net cash provided by (used in) operations: |  |  |  |  |  |  |  |  |
| Depreciation and amortization |  |  | 1,008 |  |  |  | 1,119 |  |
| Stock-based compensation expense |  |  | 1,229 |  |  |  | 1,357 |  |
| Provision for excess and obsolete inventory |  |  | 503 |  |  |  | 384 |  |
| Amortization of operating lease right-of-use assets |  |  | 192 |  |  |  | 195 |  |
| Deferred income taxes |  |  | (2 | ) |  |  | (1 | ) |
| Change in fair value of contingent consideration |  |  | 3,920 |  |  |  | 1,350 |  |
| Other non-cash items |  |  | (3 | ) |  |  | 5 |  |
| Changes in operating asset and liability accounts: |  |  |  |  |  |  |  |  |
| Accounts receivable |  |  | 2,786 |  |  |  | 549 |  |
| Inventory |  |  | (3,799 | ) |  |  | (6,272 | ) |
| Prepaid expenses and other assets |  |  | (3,099 | ) |  |  | 6,738 |  |
| Operating leases |  |  | (195 | ) |  |  | (195 | ) |
| Accounts payable and accrued expenses |  |  | (1,734 | ) |  |  | (9,394 | ) |
| Deferred revenue |  |  | 5,127 |  |  |  | 7,318 |  |
| Net cash provided by (used in) operating activities |  |  | 3,409 |  |  |  | (2,245 | ) |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |
| Purchases of property, plant and equipment |  |  | (265 | ) |  |  | (214 | ) |
| Change in other assets |  |  | 245 |  |  |  | (79 | ) |
| Net cash used in investing activities |  |  | (20 | ) |  |  | (293 | ) |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |
| Repayment of debt |  |  | (16 | ) |  |  | (17 | ) |
| Employee taxes paid related to net settlement of equity awards |  |  | (126 | ) |  |  | — |  |
| Net cash used in financing activities |  |  | (142 | ) |  |  | (17 | ) |
| Effect of exchange rate changes on cash |  |  | (4 | ) |  |  | 2 |  |
| Net increase (decrease) in cash, cash equivalents and restricted cash |  |  | 3,243 |  |  |  | (2,553 | ) |
| Cash, cash equivalents and restricted cash at beginning of period |  |  | 92,280 |  |  |  | 25,675 |  |
| Cash, cash equivalents and restricted cash at end of period |  | $ | 95,523 |  |  | $ | 23,122 |  |

[0001437749-24-024881:8k_2_02:34]
| AMSC Reports Q1 FY24 Results | Page 7 |

[0001437749-24-024881:8k_2_02:35]
RECONCILIATION OF GAAP NET LOSS TO NON-GAAP NET INCOME (LOSS)

[0001437749-24-024881:8k_2_02:36]
(In thousands, except per share data)

[0001437749-24-024881:8k_2_02:37]
|  |  | Three Months Ended June 30, |  |
|  |  | 2024 |  |  | 2023 |  |
| Net loss |  | $ | (2,524 | ) |  | $ | (5,398 | ) |
| Stock-based compensation |  |  | 1,229 |  |  |  | 1,357 |  |
| Amortization of acquisition-related intangibles |  |  | 412 |  |  |  | 544 |  |
| Change in fair value of contingent consideration |  |  | 3,920 |  |  |  | 1,350 |  |
| Non-GAAP net income (loss) |  | $ | 3,037 |  |  | $ | (2,147 | ) |
| Non-GAAP net income (loss) per share - basic |  | $ | 0.09 |  |  | $ | (0.08 | ) |
| Non-GAAP net income (loss) per share - diluted |  | $ | 0.08 |  |  | $ | (0.08 | ) |
| Weighted average shares outstanding - basic |  |  | 35,676 |  |  |  | 28,258 |  |
| Weighted average shares outstanding - diluted |  |  | 37,032 |  |  |  | 28,258 |  |

[0001437749-24-024881:8k_2_02:38]
Reconciliation of Forecast GAAP Net Loss to Non-GAAP Net Loss

[0001437749-24-024881:8k_2_02:39]
(In millions, except per share data)

[0001437749-24-024881:8k_2_02:40]
|  |  | Three Months Ending |  |
|  |  | September 30, 2024 |  |
| Net loss |  | $ | (1.7 | ) |
| Stock-based compensation |  |  | 1.3 |  |
| Amortization of acquisition-related intangibles |  |  | 0.4 |  |
| Non-GAAP net loss |  | $ | 0.0 |  |
| Non-GAAP net loss per share |  | $ | 0.0 |  |
| Shares outstanding |  |  | 35.9 |  |

[0001437749-24-024881:8k_2_02:41]
| AMSC Reports Q1 FY24 Results | Page 8 |

[0001437749-24-024881:8k_2_02:42]
Note: Non-GAAP net income (loss) is defined by the Company as net loss before; stock-based compensation; amortization of acquisition-related intangibles; change in fair value of contingent consideration; other non-cash or unusual charges, and the tax effect of adjustments calculated at the relevant rate for our non-GAAP metric. The Company believes non-GAAP net income (loss) and non-GAAP net income (loss) per share assist management and investors in comparing the Company’s performance across reporting periods on a consistent basis by excluding these non-cash, non-recurring or other charges that it does not believe are indicative of its core operating performance. Actual GAAP and non-GAAP net loss for the fiscal quarter ending September 30, 2024, including the above adjustments, may differ materially from those forecasted in the table above, including as a result of changes in the fair value of contingent consideration. Generally, a non-GAAP financial measure is a numerical measure of a company's performance, financial position or cash flow that either excludes or includes amounts that are not normally excluded or included in the most directly comparable measure calculated and presented in accordance with GAAP. The non-GAAP measure included in this release, however, should be considered in addition to, and not as a substitute for or superior to, operating income or other measures of financial performance prepared in accordance with GAAP. A reconciliation of GAAP to non-GAAP net loss is set forth in the table above.

[0001437749-24-024881:8k_2_02:43]
AMSC Contacts

[0001437749-24-024881:8k_2_02:44]
Investor Relations Contact:

[0001437749-24-024881:8k_2_02:45]
LHA Investor Relations

[0001437749-24-024881:8k_2_02:46]
Carolyn Capaccio

[0001437749-24-024881:8k_2_02:47]
(212) 838-3777

[0001437749-24-024881:8k_2_02:48]
amscIR@lhai.com

[0001437749-24-024881:8k_2_02:49]
AMSC Director, Communications:

[0001437749-24-024881:8k_2_02:50]
Nicol Golez

[0001437749-24-024881:8k_2_02:51]
978-399-8344

[0001437749-24-024881:8k_2_02:52]
Nicol.Golez@amsc.com
