# AMSC notes — 0001437749-24-024886


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0001437749-24-024886:notes:1]
[same as prior period, unchanged from 0001437749-24-002041:notes:3]

[0001437749-24-024886:notes:2]
[same as prior period, unchanged from 0001437749-24-002041:notes:4]

[0001437749-24-024886:notes:3]
American Superconductor Corporation (together with its subsidiaries, “AMSC®” or the “Company”) was founded on  April 9, 1987. The Company is a leading system provider of megawatt-scale power resiliency solutions that orchestrate the rhythm and harmony of power on the grid™ and protect and expand the capability of the Navy’s fleet. The Company’s system level products leverage its proprietary “smart materials” and “smart software and controls” to provide enhanced resiliency and improved performance of megawatt-scale power flow.

[0001437749-24-024886:notes:4]
These unaudited condensed consolidated financial statements of the Company have been prepared on a going concern basis in accordance with United States generally accepted accounting principles (“GAAP”) and the Securities and Exchange Commission’s (“SEC”) instructions to Form 10-Q. Certain prior period amounts were reclassified to conform to the presentation in the current period. The going concern basis of presentation assumes that the Company will continue operations and will be able to realize its assets and discharge its liabilities and commitments in the normal course of business. Certain information and footnote disclosures normally included in the condensed consolidated financial statements prepared in accordance with GAAP have been or omitted pursuant to those instructions. The year-end balance sheet data was derived from audited financial statements but does not include all disclosures required by GAAP. The unaudited condensed consolidated financial statements, in the opinion of management, reflect all adjustments (consisting of normal recurring adjustments) necessary for a fair statement of the results for the interim periods ended  June 30, 2024 and 2023 and the financial position at  June 30, 2024; however, these results are not necessarily indicative of results which  may be expected for the full year. The interim condensed consolidated financial statements, and notes thereto, should be read in conjunction with the audited condensed consolidated financial statements for the year ended  March 31, 2024, and notes thereto, included in the Company’s Annual Report on Form 10-K for the year ended  March 31, 2024 filed with the SEC on  May 29, 2024.

[0001437749-24-024886:notes:5]
[same as prior period, unchanged from 0001437749-24-002041:notes:7]

[0001437749-24-024886:notes:6]
The Company has historically experienced recurring operating losses and as of  June 30, 2024, the Company had an accumulated deficit of $1,069.2 million. In addition, the Company has historically experienced recurring negative operating cash flows. At  June 30, 2024, the Company had cash and cash equivalents of $93.5 million. Cash provided by operations for the three months ended  June 30, 2024 was $3.4 million.

[0001437749-24-024886:notes:7]
In  January 2024, the Company filed a shelf registration statement on Form S-3 that will expire three years from the date on which it was declared effective,  March 15, 2027 (the “Form S-3”). The Form S-3 allows the Company to offer and sell from time-to-time up to $250 million of common stock, debt securities, warrants or units comprised of any combination of these securities. The Form S-3 is intended to provide the Company flexibility to conduct registered sales of its securities, subject to market conditions, in order to fund its future capital needs. The terms of any future offering under the Form S-3 will be established at the time of such offering and will be described in a prospectus supplement filed with the SEC prior to the completion of any such offering.

[0001437749-24-024886:notes:8]
On  January 31, 2024, the Company entered into an underwriting agreement with Oppenheimer & Co. Inc., as a representative of the several underwriters named therein, relating to the issuance and sale (the "2024 Offering") of 6,210,000 shares of the Company's common stock at a public offering price of $11.25 per share. The net proceeds to the Company from the 2024 Offering were approximately $65.2 million, after deducting underwriting discounts and commissions and offering expenses payable by the Company. The 2024 Offering closed on  February 14, 2024.

[0001437749-24-024886:notes:9]
On  August 1, 2024, the Company entered into a Stock Purchase Agreement (the “Stock Purchase Agreement”) with the selling stockholders named therein.  Pursuant to the terms of the Stock Purchase Agreement and concurrently with entering into such agreement, the Company acquired all of the issued and outstanding shares of Megatran ("the "Acquisition"), for aggregate consideration in an amount equal to $61,350,000 (the “Purchase Price”), which consideration amount shall be subject to various adjustments set forth in the Stock Purchase Agreement (including those described below) and consists of: (a) (i) $25,000,000, minus (ii) the Indebtedness (as defined in the Stock Purchase Agreement) outstanding as of immediately prior to the closing, minus (iii) Company Expenses (as defined in the Stock Purchase Agreement) (collectively, the “Cash Purchase Price”); (b) a number of restricted shares (rounded up or down to the nearest whole share, as applicable) (the “Company Shares”) of the Company’s common stock, $.01 par value per share (“Common Stock”) equal to the quotient obtained by dividing (x) $31,350,000 (the “Share Purchase Price”) by (y) the closing price per share of Common Stock on the Nasdaq Global Select Market on the last trading day immediately preceding the Closing Date; and (c) an additional cash payment equal to $5,000,000, as adjusted pursuant to Sections 5.6(c), (d), and (f) of the Stock Purchase Agreement (the “Additional Cash Purchase Price”). Megatran is now a wholly-owned subsidiary of the Company and is operated and reported as a component of its Grid business unit.

[0001437749-24-024886:notes:10]
In recent periods, the Company has experienced inflationary pressure in its supply chain and some delays in sourcing materials needed for its products resulting in some production disruption, both of which have increased the Company’s cost of revenues and decreased gross margin. While the impact of inflation has been challenging, the Company has taken actions to limit this pressure, including adjusting the pricing of its products and services. Changes in macroeconomic conditions arising from various reasons, such as the ongoing wars between Russia and Ukraine and Israel and Hamas, inflation, rising interest rates, labor force availability, sourcing, material delays and global supply chain disruptions could have a material adverse effect on the Company’s business, financial condition and results of operation.

[0001437749-24-024886:notes:11]
The Company believes that based on the information presented above and its quarterly management assessment, it has sufficient liquidity to fund its operations and capital expenditures for the next twelve months following the issuance of the unaudited condensed consolidated financial statements for the three months ended  June 30, 2024. The Company’s liquidity is highly dependent on its ability to increase revenues, its ability to control its operating costs, and its ability to raise additional capital, if necessary. The impact of global sources of instability, including the wars between Russia and Ukraine and Israel and Hamas, on the global financing markets  may reduce the Company's ability to raise additional capital, if necessary, which could negatively impact the Company's liquidity.  There can be no assurance that the Company will be able to continue to raise additional capital, on favorable terms or at all, from other sources or execute on any other means of improving liquidity described above.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001437749-24-024886:notes:12]
[same as prior period, unchanged from 0001437749-24-002041:notes:13]

[0001437749-24-024886:notes:13]
The Company’s revenues in its Grid segment are derived primarily through enabling the transmission and distribution of power, providing planning services that allow it to identify power grid needs and risks, and developing ship protection systems for the U.S. Navy. The Company’s revenues in its Wind segment are derived primarily through supplying advanced power electronics and control systems, licensing its highly engineered wind turbine designs, and providing extensive customer support services to wind turbine manufacturers. The Company records revenue based on a five-step model in accordance with Accounting Standards Codification ("ASC") 606. For its customer contracts, the Company identifies the performance obligations, determines the transaction price, allocates the contract transaction price to the performance obligations, and recognizes the revenue when (or as) control of goods or services is transferred to the customer. For the three months ended  June 30, 2024 and 2023, 88% and 76% of revenue, respectively, was recognized at the point in time when control transferred to the customer, with the remainder being recognized over time.

[0001437749-24-024886:notes:14]
[same as prior period, unchanged from 0001437749-24-002041:notes:15]

[0001437749-24-024886:notes:15]
In the Company's service and technology development product line, there are several different types of transactions and each begins with a contract with a customer that summarizes each product sold to a customer, which typically represents distinct performance obligations. The technology development transactions are primarily for activities that have no alternative use and for which a profit can be expected throughout the life of the contract. In these cases, the revenue is recognized over time, but in the instances where the profit cannot be assured throughout the entire contract then the revenue is recognized at a point in time. Each contract's transaction price is allocated to each distinct performance obligation using the respective standalone selling price which is determined primarily using the cost-plus expected margin approach. The ongoing service transactions are for service contracts that provide benefit to the customer simultaneously as the Company performs its obligations, and therefore this revenue is recognized ratably over time throughout the effective period of these contracts. The transaction prices on these contracts are allocated based on an adjusted market approach which is re-assessed annually for reasonableness. The field service transactions include contracts for delivery of goods and completion of services made at the customer's requests, which are not deemed satisfied until the work has been completed and/or the requested goods have been delivered, so all of this revenue is recognized at the point in time when the control changes, and at allocated prices based on the adjusted market approach driven by standard price lists. The royalty transactions are related to certain contract terms on transactions in the Company's equipment and systems product line based on activity as specified in the contracts. The transaction prices of these agreements are calculated based on an adjusted market approach as specified in the contract. The Company reports royalty revenue for usage-based royalties when the sales have occurred. In circumstances when collectability is not assured and a contract does not exist under ASC 606, revenue is deferred until a non-refundable payment has been received for substantially all the amount that is due and there are no further remaining performance obligations.

[0001437749-24-024886:notes:16]
[same as prior period, unchanged from 0001437749-24-002041:notes:17]

[0001437749-24-024886:notes:17]
[same as prior period, unchanged from 0001437749-24-002041:notes:18]

[0001437749-24-024886:notes:18]
[same as prior period, unchanged from 0001437749-24-002041:notes:19]

[0001437749-24-024886:notes:19]
The Company records revenue net of sales tax, value added tax, excise tax and other taxes collected concurrent with revenue-producing activities. The Company has elected to recognize the cost for freight and shipping when control over the products sold passes to customers and revenue is recognized. The Company has elected to recognize incremental costs of obtaining a contract as expense when incurred except in contracts where the amortization period would exceed twelve months. In such cases the long term amount will be assessed for materiality. As of  June 30, 2024 and  March 31, 2024, the Company's capitalized incremental contract costs were not material. The Company has elected not to adjust the promised amount of consideration for the effects of a significant financing component if the period of financing is twelve months or less.  The Company has elected to recognize revenue based on the as invoiced practical expedient if there is a right to consideration from a customer in an amount that corresponds directly with the value of the Company's performance.

[0001437749-24-024886:notes:20]
[same as prior period, unchanged from 0001437749-24-002041:notes:22]

[0001437749-24-024886:notes:21]
[same as prior period, unchanged from 0001437749-24-002041:notes:23]

[0001437749-24-024886:notes:22]
|  |  | Three Months Ended June 30, 2024 |  |
| Product Line: |  | Grid |  |  | Wind |  |
| Equipment and systems |  | $ | 29,726 |  |  | $ | 7,424 |  |
| Services and technology development |  |  | 2,610 |  |  |  | 530 |  |
| Total |  | $ | 32,336 |  |  | $ | 7,954 |  |
| Region: |  |  |  |  |  |  |  |  |
| Americas |  | $ | 30,479 |  |  | $ | — |  |
| Asia Pacific |  |  | 1,199 |  |  |  | 7,952 |  |
| EMEA |  |  | 658 |  |  |  | 2 |  |
| Total |  | $ | 32,336 |  |  | $ | 7,954 |  |

[0001437749-24-024886:notes:23]
|  |  | Three Months Ended June 30, 2023 |  |
| Product Line: |  | Grid |  |  | Wind |  |
| Equipment and systems |  | $ | 23,126 |  |  | $ | 3,982 |  |
| Services and technology development |  |  | 2,611 |  |  |  | 535 |  |
| Total |  | $ | 25,737 |  |  | $ | 4,517 |  |
| Region: |  |  |  |  |  |  |  |  |
| Americas |  | $ | 23,161 |  |  | $ | — |  |
| Asia Pacific |  |  | 1,711 |  |  |  | 4,465 |  |
| EMEA |  |  | 865 |  |  |  | 52 |  |
| Total |  | $ | 25,737 |  |  | $ | 4,517 |  |

[0001437749-24-024886:notes:24]
As of  June 30, 2024 and 2023, the Company’s contract assets and liabilities primarily relate to the timing differences between cash received from a customer in connection with contractual rights to invoicing and the timing of revenue recognition following completion of performance obligations. The Company's accounts receivable balance is made up entirely of customer contract related balances. Changes in the Company’s contract assets, which are included in “Unbilled accounts receivable” and “Deferred program costs” (see Note 7, “Accounts Receivable” and Note 8, “Inventory” for a reconciliation to the condensed consolidated balance sheets) and "Contract liabilities", which are included in the current portion and long-term portion of "Deferred revenue" in the Company’s condensed consolidated balance sheets, are as follows (in thousands):

[0001437749-24-024886:notes:25]
|  |  | Unbilled Accounts Receivable |  |  | Deferred Program Costs |  |  | Contract Liabilities |  |
| Beginning balance as of March 31, 2024 |  | $ | 6,150 |  |  | $ | 2,523 |  |  | $ | 57,829 |  |
| Increases for costs incurred to fulfill performance obligations |  |  | — |  |  |  | 2,119 |  |  |  | — |  |
| Increase (decrease) due to customer billings |  |  | (3,521 | ) |  |  | — |  |  |  | 27,577 |  |
| Decrease due to cost recognition on completed performance obligations |  |  | — |  |  |  | (606 | ) |  |  | — |  |
| Increase (decrease) due to recognition of revenue based on transfer of control of performance obligations |  |  | 2,291 |  |  |  | — |  |  |  | (22,443 | ) |
| Other changes and FX impact |  |  | (2 | ) |  |  | (2 | ) |  |  | (50 | ) |
| Ending balance as of June 30, 2024 |  | $ | 4,918 |  |  | $ | 4,034 |  |  | $ | 62,913 |  |

[0001437749-24-024886:notes:26]
|  |  | Unbilled Accounts Receivable |  |  | Deferred Program Costs |  |  | Contract Liabilities |  |
| Beginning balance as of March 31, 2023 |  | $ | 9,958 |  |  | $ | 2,136 |  |  | $ | 50,760 |  |
| Increases for costs incurred to fulfill performance obligations |  |  | — |  |  |  | 1,084 |  |  |  | — |  |
| Increase (decrease) due to customer billings |  |  | (9,479 | ) |  |  | — |  |  |  | 16,308 |  |
| Decrease due to cost recognition on completed performance obligations |  |  | — |  |  |  | (1,234 | ) |  |  | — |  |
| Increase (decrease) due to recognition of revenue based on transfer of control of performance obligations |  |  | 5,092 |  |  |  | — |  |  |  | (8,974 | ) |
| Other changes and FX impact |  |  | 1 |  |  |  | — |  |  |  | (11 | ) |
| Ending balance as of June 30, 2023 |  | $ | 5,572 |  |  | $ | 1,986 |  |  | $ | 58,083 |  |

[0001437749-24-024886:notes:27]
The Company’s remaining performance obligations represent the unrecognized revenue value of the Company’s contractual commitments. The Company’s performance obligations  may vary significantly each reporting period based on the timing of major new contractual commitments. As of  June 30, 2024, the Company had outstanding performance obligations on existing contracts under ASC 606 to be recognized in the next twelve months of approximately $161.0 million. There are also approximately $90.0 million of outstanding performance obligations to be recognized over a period of thirteen to sixty months. The remaining performance obligations are subject to customer actions and therefore the timing of revenue recognition cannot be reasonably estimated.

[0001437749-24-024886:notes:28]
The following table sets forth customers who represented 10% or more of the Company’s total revenues for the three months ended  June 30, 2024 and 2023:

[0001437749-24-024886:notes:29]
|  |  |  | Three Months Ended |  |
|  | Reportable |  | June 30, |  |
|  | Segment |  | 2024 |  |  | 2023 |  |
| Inox Wind Limited | Wind |  |  | 18 | % |  |  | 12 | % |


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001437749-24-024886:notes:30]
[same as prior period, unchanged from 0001437749-24-002041:notes:32]

[0001437749-24-024886:notes:31]
The Company accounts for its stock-based compensation at fair value. The following table summarizes stock-based compensation expense by financial statement line item for the three months ended  June 30, 2024 and 2023 (in thousands):

[0001437749-24-024886:notes:32]
|  |  | Three Months Ended June 30, |  |
|  |  | 2024 |  |  | 2023 |  |
| Cost of revenues |  | $ | 58 |  |  | $ | 109 |  |
| Research and development |  |  | 143 |  |  |  | 156 |  |
| Selling, general and administrative |  |  | 1,028 |  |  |  | 1,092 |  |
| Total |  | $ | 1,229 |  |  | $ | 1,357 |  |

[0001437749-24-024886:notes:33]
The Company issued 25,000 shares of restricted stock and 19,200 shares of immediately vested common stock during the three months ended  June 30, 2024. The Company issued 672,500 shares of restricted stock and 53,675 shares of immediately vested common stock during the three months ended  June 30, 2023. These restricted stock awards generally vest over 2-3 years. Awards for restricted stock include both time-based and performance-based awards. For options and restricted stock awards that vest upon the passage of time, expense is being recorded over the vesting period. Performance-based awards are expensed over the requisite service period based on probability of achievement.

[0001437749-24-024886:notes:34]
The estimated fair value of the Company’s stock-based awards, less expected annual forfeitures, is amortized over the awards’ service period. There were no unrecognized compensation costs for unvested stock options as of  June 30, 2024. The total unrecognized compensation cost for unvested outstanding restricted stock was $4.1 million as of  June 30, 2024. This expense will be recognized over a weighted-average expense period of approximately 1.4 years.

[0001437749-24-024886:notes:35]
The Company granted no stock options during the three months ended  June 30, 2024 and 2023.


## us-gaap:EarningsPerShareTextBlock

[0001437749-24-024886:notes:36]
[same as prior period, unchanged from 0001437749-24-002041:notes:39]

[0001437749-24-024886:notes:37]
Basic net loss per share (“EPS”) is computed by dividing net loss by the weighted-average number of common shares outstanding for the period. Where applicable, diluted EPS is computed by dividing the net loss by the weighted-average number of common shares and dilutive common equivalent shares outstanding during the period, calculated using the treasury stock method. Common equivalent shares include the effect of restricted stock, exercise of stock options and warrants and contingently issuable shares. Stock options and warrants that are out-of-the-money with exercise prices greater than the average market price of the underlying common shares and shares of performance-based restricted stock where the contingency was not met are excluded from the computation of diluted EPS as the effect of their inclusion would be anti-dilutive. For the three months ended  June 30, 2024, 336,206 shares were not included in the calculation of diluted EPS. Of these, 300,000 relate to shares associated with the contingent consideration derivative liability for which the contingency has not yet been met, and 36,206 relate to outstanding stock options as they were considered anti-dilutive. For the three months ended  June 30, 2023, 1,071,504 million shares were not included in the calculation of diluted EPS. Of these, 1,000,000 relate to shares associated with the contingent consideration derivative liability for which the contingency has not yet been met, and 71,504 relate to outstanding stock options as they were considered anti-dilutive.

[0001437749-24-024886:notes:38]
The following table reconciles the numerators and denominators of the earnings per share calculation for the three months ended  June 30, 2024 and 2023 (in thousands, except per share data):

[0001437749-24-024886:notes:39]
|  |  | Three Months Ended June 30, |  |
|  |  | 2024 |  |  | 2023 |  |
| Numerator: |  |  |  |  |  |  |  |  |
| Net loss |  | $ | (2,524 | ) |  | $ | (5,398 | ) |
| Denominator: |  |  |  |  |  |  |  |  |
| Weighted-average shares of common stock outstanding |  |  | 36,991 |  |  |  | 29,706 |  |
| Weighted-average shares subject to repurchase |  |  | (1,315 | ) |  |  | (1,448 | ) |
| Shares used in per-share calculation ― basic |  |  | 35,676 |  |  |  | 28,258 |  |
| Shares used in per-share calculation ― diluted |  |  | 35,676 |  |  |  | 28,258 |  |
| Net loss per share ― basic |  | $ | (0.07 | ) |  | $ | (0.19 | ) |
| Net loss per share ― diluted |  | $ | (0.07 | ) |  | $ | (0.19 | ) |


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001437749-24-024886:notes:40]
[same as prior period, unchanged from 0001437749-24-002041:notes:43]

[0001437749-24-024886:notes:41]
[same as prior period, unchanged from 0001437749-24-002041:notes:44]

[0001437749-24-024886:notes:42]
[same as prior period, unchanged from 0001437749-24-002041:notes:45]

[0001437749-24-024886:notes:43]
There were no changes to goodwill during the three months ended  June 30, 2024 or the year ended  March 31, 2024.

[0001437749-24-024886:notes:44]
The Company did not identify any triggering events in the three months ended  June 30, 2024 that would require interim impairment testing of goodwill.

[0001437749-24-024886:notes:45]
[same as prior period, unchanged from 0001437749-24-002041:notes:48]

[0001437749-24-024886:notes:46]
Intangible assets at  June 30, 2024 and  March 31, 2024 consisted of the following (in thousands):

[0001437749-24-024886:notes:47]
|  |  | June 30, 2024 |  |  | March 31, 2024 |  |  |  |  |  |
|  |  | Gross Amount |  |  | Accumulated Amortization |  |  | Net Book Value |  |  | Gross Amount |  |  | Accumulated Amortization |  |  | Net Book Value |  |  | Estimated Useful Life |  |
| Backlog |  |  | 681 |  |  |  | (681 | ) |  |  | — |  |  |  | 681 |  |  |  | (681 | ) |  | $ | — |  |  |  | 2 |  |
| Trade name and trademarks |  |  | 1,800 |  |  |  | — |  |  |  | 1,800 |  |  |  | 1,800 |  |  |  | — |  |  |  | 1,800 |  |  | Indefinite |  |
| Customer relationships |  |  | 9,600 |  |  |  | (6,941 | ) |  |  | 2,659 |  |  |  | 9,600 |  |  |  | (6,649 | ) |  |  | 2,951 |  |  |  | 7 |  |
| Core technology and know-how |  |  | 5,970 |  |  |  | (4,472 | ) |  |  | 1,498 |  |  |  | 5,970 |  |  |  | (4,352 | ) |  |  | 1,618 |  |  |  | 5-10 |  |
| Intangible assets |  | $ | 18,051 |  |  | $ | (12,094 | ) |  | $ | 5,957 |  |  | $ | 18,051 |  |  | $ | (11,682 | ) |  | $ | 6,369 |  |  |  |  |  |

[0001437749-24-024886:notes:48]
The Company recorded intangible amortization expense related to customer relationship and core technology and know-how of $0.4 million in the three months ended  June 30, 2024 and $0.5 million in the three months ended  June 30, 2023. The Company recorded no intangible amortization related to backlog during the three months ended  June 30, 2024 as the asset is fully amortized. Amortization expense of less than $0.1 million was reported in cost of revenues during the three months ended  June 30, 2023.

[0001437749-24-024886:notes:49]
[same as prior period, unchanged from 0001437749-24-002041:notes:52]

[0001437749-24-024886:notes:50]
| Years ending March 31, |  | Total |  |
| 2025 |  |  | 1,236 |  |
| 2026 |  |  | 1,221 |  |
| 2027 |  |  | 1,085 |  |
| 2028 |  |  | 543 |  |
| 2029 |  |  | 72 |  |
| Total |  | $ | 4,157 |  |

[0001437749-24-024886:notes:51]
[same as prior period, unchanged from 0001437749-24-002041:notes:54]


## us-gaap:FairValueDisclosuresTextBlock

[0001437749-24-024886:notes:52]
[same as prior period, unchanged from 0001437749-24-002041:notes:55]

[0001437749-24-024886:notes:53]
[same as prior period, unchanged from 0001437749-24-002041:notes:56]

[0001437749-24-024886:notes:54]
[same as prior period, unchanged from 0001437749-24-002041:notes:57]

[0001437749-24-024886:notes:55]
The Company provides a gross presentation of activity within Level 3 measurement roll-forward and details of transfers in and out of Level 1 and 2 measurements. A change in the hierarchy of an investment from its current level is reflected in the period during which the pricing methodology of such investment changes. Disclosure of the transfer of securities from Level 1 to Level 2 or Level 3 is made in the event that the related security is significant to total cash and investments. The Company did not have any transfers of assets and liabilities from Level 1, Level 2 or Level 3 of the fair value measurement hierarchy during the three months ended  June 30, 2024.

[0001437749-24-024886:notes:56]
[same as prior period, unchanged from 0001437749-24-002041:notes:59]

[0001437749-24-024886:notes:57]
[same as prior period, unchanged from 0001437749-24-002041:notes:60]

[0001437749-24-024886:notes:58]
[same as prior period, unchanged from 0001437749-24-002041:notes:61]

[0001437749-24-024886:notes:59]
Cash equivalents consist of highly liquid instruments with maturities of three months or less that are regarded as high quality, low risk investments and are measured using such inputs as quoted prices and are classified within Level 1 of the valuation hierarchy. Cash equivalents consist principally of certificates of deposits and money market accounts.

[0001437749-24-024886:notes:60]
[same as prior period, unchanged from 0001437749-24-002041:notes:63]

[0001437749-24-024886:notes:61]
Contingent consideration relates to the earnout payment set forth in the Stock Purchase Agreement governing the acquisition of Northeast Power Systems, Inc ("NEPSI") that provides that the selling stockholders  may receive up to an additional 1,000,000 shares of common stock of the Company upon the achievement of certain specified revenue objectives over varying periods of up to four years following the NEPSI Acquisition Date which must occur by  September 30, 2024. See Note 13, "Contingent Consideration" for further discussion. The Company relied on a Monte Carlo method to determine the fair value of the contingent consideration on the closing of the acquisition of NEPSI and continues to revalue the fair value of the contingent consideration using the same method at each subsequent balance sheet date until the contingencies are resolved and the shares to be issued are determined, with the change in fair value recorded in the current period operating loss.

[0001437749-24-024886:notes:62]
The following table provides the assets and liabilities carried at fair value on a recurring basis, measured as of  June 30, 2024 and  March 31, 2024 (in thousands):

[0001437749-24-024886:notes:63]
|  |  | Total Carrying Value |  |  | Quoted Prices in Active Markets (Level 1) |  |  | Significant Other Observable Inputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |
| June 30, 2024: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash equivalents |  | $ | 70,272 |  |  | $ | 70,272 |  |  | $ | — |  |  | $ | — |  |
| Derivative liabilities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Contingent consideration |  | $ | 7,020 |  |  | $ | — |  |  | $ | — |  |  | $ | 7,020 |  |

[0001437749-24-024886:notes:64]
|  |  | Total Carrying Value |  |  | Quoted Prices in Active Markets (Level 1) |  |  | Significant Other Observable Inputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |
| March 31, 2024 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash equivalents |  | $ | 72,832 |  |  | $ | 72,832 |  |  | $ | — |  |  | $ | — |  |
| Derivative liabilities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Contingent consideration |  | $ | 3,100 |  |  | $ | — |  |  | $ | — |  |  | $ | 3,100 |  |

[0001437749-24-024886:notes:65]
[same as prior period, unchanged from 0001437749-24-002041:notes:68]

[0001437749-24-024886:notes:66]
|  |  | Acquisition Contingent Consideration |  |
| Balance at March 31, 2023 |  | $ | 1,270 |  |
| Change in fair value |  |  | 4,922 |  |
| Settlement of contingent consideration |  |  | (3,092 | ) |
| Balance at March 31, 2024 |  |  | 3,100 |  |
| Change in fair value |  |  | 3,920 |  |
| Balance at June 30, 2024 |  | $ | 7,020 |  |


## amsc:AccountsReceivableTextBlock

[0001437749-24-024886:notes:67]
[same as prior period, unchanged from 0001437749-24-002041:notes:70]

[0001437749-24-024886:notes:68]
Accounts receivable at  June 30, 2024 and  March 31, 2024 consisted of the following (in thousands):

[0001437749-24-024886:notes:69]
|  |  | June 30, 2024 |  |  | March 31, 2024 |  |
| Accounts receivable (billed) |  | $ | 18,611 |  |  | $ | 20,175 |  |
| Accounts receivable (unbilled) |  |  | 4,918 |  |  |  | 6,150 |  |
| Accounts receivable, net |  | $ | 23,529 |  |  | $ | 26,325 |  |


## us-gaap:InventoryDisclosureTextBlock

[0001437749-24-024886:notes:70]
[same as prior period, unchanged from 0001437749-24-002041:notes:73]

[0001437749-24-024886:notes:71]
Inventory, net of reserves, at  June 30, 2024 and  March 31, 2024 consisted of the following (in thousands):

[0001437749-24-024886:notes:72]
|  |  | June 30, 2024 |  |  | March 31, 2024 |  |
| Raw materials |  | $ | 21,340 |  |  | $ | 20,622 |  |
| Work-in-process |  |  | 15,455 |  |  |  | 14,872 |  |
| Finished goods |  |  | 4,320 |  |  |  | 3,840 |  |
| Deferred program costs |  |  | 4,034 |  |  |  | 2,523 |  |
| Net inventory |  | $ | 45,149 |  |  | $ | 41,857 |  |

[0001437749-24-024886:notes:73]
The Company recorded inventory write-downs of $0.5 million and $0.4 million for the three months ended  June 30, 2024 and 2023, respectively. These write-downs were based on the Company's evaluation of its inventory on hand for excess quantities and obsolescence.

[0001437749-24-024886:notes:74]
Deferred program costs as of  June 30, 2024 and  March 31, 2024 primarily represent costs incurred on programs where the Company needs to complete performance obligations before the related revenue and costs will be recognized.


## amsc:PrepaidAndOtherCurrentAssetsTextBlock

[0001437749-24-024886:notes:75]
[same as prior period, unchanged from 0001437749-24-002041:notes:78]

[0001437749-24-024886:notes:76]
[same as prior period, unchanged from 0001437749-24-002041:notes:79]

[0001437749-24-024886:notes:77]
As accounting for payroll tax credits are not within the scope of ASC 740, Income Taxes, the Company has chosen to account for the ERCs by analogizing to the International Accounting Standards Board IAS 20, Accounting for Government Grants and Disclosure of Government Assistance.  In accordance with IAS 20, an entity recognizes government grants only when there is reasonable assurance that the entity will comply with the conditions attached to them and the grants will be received.  The Company evaluated its eligibility for the ERC and determined that it met all the criteria to claim a refundable tax credit against the employer portion of Social Security taxes for up to 70% of the qualified wages the Company paid to employees for the three month periods ended  March 31, 2021 and  June 30, 2021 and for up to 50% of the qualified wages the Company paid to employees for the three month period ended  March 31, 2020.

[0001437749-24-024886:notes:78]
The Company recorded a $3.3 million receivable in prepaid expenses and other current assets and a benefit of $1.8 million to cost of revenues, $0.8 million to selling, general, and administrative and $0.7 million to research and development in the fiscal year ended  March 31, 2023 for the ERC that was expected to be received based on the amended filings. During the year ended  March 31, 2024, the Company received $3.0 million for the initial claims that were processed. During the three months ended  June 30, 2024, the Company did not receive any cash for the remaining $0.3 million balance of initial claims that were processed. The remaining balance is expected to be received during the remainder of fiscal 2024.


## us-gaap:PropertyPlantAndEquipmentDisclosureTextBlock

[0001437749-24-024886:notes:79]
[same as prior period, unchanged from 0001437749-24-002041:notes:82]

[0001437749-24-024886:notes:80]
The cost and accumulated depreciation of property, plant and equipment at  June 30, 2024 and  March 31, 2024 are as follows (in thousands):

[0001437749-24-024886:notes:81]
|  |  | June 30, 2024 |  |  | March 31, 2024 |  |
| Land |  | $ | 980 |  |  | $ | 980 |  |
| Construction in progress – equipment |  |  | 291 |  |  |  | 226 |  |
| Buildings |  |  | 5,515 |  |  |  | 5,416 |  |
| Equipment and software |  |  | 44,159 |  |  |  | 44,095 |  |
| Furniture and fixtures |  |  | 1,553 |  |  |  | 1,526 |  |
| Leasehold improvements |  |  | 6,990 |  |  |  | 6,990 |  |
| Property, plant and equipment, gross |  |  | 59,488 |  |  |  | 59,233 |  |
| Less accumulated depreciation |  |  | (48,959 | ) |  |  | (48,372 | ) |
| Property, plant and equipment, net |  | $ | 10,529 |  |  | $ | 10,861 |  |

[0001437749-24-024886:notes:82]
Depreciation expense was $0.6 million for each of the three months ended  June 30, 2024 and 2023, respectively.


## us-gaap:AccountsPayableAndAccruedLiabilitiesDisclosureTextBlock

[0001437749-24-024886:notes:83]
[same as prior period, unchanged from 0001437749-24-002041:notes:86]

[0001437749-24-024886:notes:84]
Accounts payable and accrued expenses at  June 30, 2024 and  March 31, 2024 consisted of the following (in thousands):

[0001437749-24-024886:notes:85]
|  |  | June 30, 2024 |  |  | March 31, 2024 |  |
| Accounts payable |  | $ | 3,754 |  |  | $ | 4,476 |  |
| Accrued inventories in-transit |  |  | 2,672 |  |  |  | 539 |  |
| Accrued other miscellaneous expenses |  |  | 2,548 |  |  |  | 2,366 |  |
| Accrued contract loss |  |  | 97 |  |  |  | 97 |  |
| Advanced deposits |  |  | 4,242 |  |  |  | 2,270 |  |
| Accrued compensation |  |  | 5,059 |  |  |  | 10,326 |  |
| Income taxes payable |  |  | 170 |  |  |  | 346 |  |
| Accrued product warranty |  |  | 2,542 |  |  |  | 2,363 |  |
| Accrued commissions |  |  | 1,225 |  |  |  | 1,452 |  |
| Total |  | $ | 22,309 |  |  | $ | 24,235 |  |

[0001437749-24-024886:notes:86]
[same as prior period, unchanged from 0001437749-24-002041:notes:89]

[0001437749-24-024886:notes:87]
[same as prior period, unchanged from 0001437749-24-002041:notes:90]

[0001437749-24-024886:notes:88]
|  |  | Three Months Ended June 30, |  |
|  |  | 2024 |  |  | 2023 |  |
| Balance at beginning of period |  | $ | 2,363 |  |  | $ | 2,638 |  |
| Provisions for warranties during the period |  |  | 476 |  |  |  | 208 |  |
| Settlements during the period |  |  | (297 | ) |  |  | (920 | ) |
| Balance at end of period |  | $ | 2,542 |  |  | $ | 1,926 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0001437749-24-024886:notes:89]
[same as prior period, unchanged from 0001437749-24-002041:notes:92]

[0001437749-24-024886:notes:90]
The Company recorded income tax expense of $0.2 million in the three months ended  June 30, 2024 and $0.1 million in the three months ended  June 30, 2023.

[0001437749-24-024886:notes:91]
Accounting for income taxes requires a two-step approach to recognizing and measuring uncertain tax positions. The first step is to evaluate the tax position for recognition by determining if, based on the technical merits, it is more likely than not the position will be sustained upon audit, including resolution of related appeals or litigation processes, if any. The second step is to measure the tax benefit as the largest amount that is more than 50% likely to be realized upon ultimate settlement. The Company re-evaluates these uncertain tax positions on a quarterly basis. The evaluation is based on factors including, but not limited to, changes in facts or circumstances, changes in tax law, effectively settled issues under audit and new audit activity.  Any changes in these factors could result in the recognition of a tax benefit or an additional charge to the tax provision. The Company did not identify any uncertain tax positions in the three months ended  June 30, 2024 and did not have any gross unrecognized tax benefits as of  June 30, 2024.


## amsc:BusinessCombinationContingentConsiderationTextBlock

[0001437749-24-024886:notes:92]
[same as prior period, unchanged from 0001437749-24-002041:notes:95]

[0001437749-24-024886:notes:93]
On  October 1, 2020 (the "NEPSI Acquisition Date"), the Company entered into a Stock Purchase Agreement (the "NEPSI Stock Purchase Agreement") with the selling stockholders named therein. Pursuant to the terms of the NEPSI Stock Purchase Agreement and concurrently with entering into such agreement, the Company acquired all of the issued and outstanding (i) shares of capital stock of NEPSI, and (ii) membership interests of Northeast Power Realty, LLC, a New York limited liability company, which holds the real property that serves as NEPSI's headquarters (the "NEPSI Acquisition"). NEPSI is a U.S.-based global provider of medium-voltage metal-enclosed power capacitor banks and harmonic filter banks for use on electric power systems. NEPSI is a wholly-owned subsidiary of the Company and is operated by its Grid business unit. The purchase price was $26.0 million in cash and 873,657 restricted shares of common stock of the Company. As part of the transaction, the selling stockholders  may receive up to an additional 1,000,000 shares of common stock of the Company upon the achievement of certain specified revenue objectives during varying periods of up to four years following closing of the NEPSI Acquisition. During the year ended  March 31, 2024, the Company issued 399,999 shares of common stock and cash in lieu of a fractional share of common stock, related to the achievement of specified revenue objectives in connection with the NEPSI Acquisition. One specified revenue objective, which would have earned the selling stockholders 300,000 shares of the Company’s common stock, was not achieved, leaving 300,000 shares of common stock remaining for potential issuance upon the achievement of the last specified revenue objective by  September 30, 2024.

[0001437749-24-024886:notes:94]
[same as prior period, unchanged from 0001437749-24-002041:notes:97]

[0001437749-24-024886:notes:95]
[same as prior period, unchanged from 0001437749-24-002041:notes:98]

[0001437749-24-024886:notes:96]
|  |  | June 30, |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Fiscal Year 2024 |  | 2024 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Revenue risk premium |  |  | 5.50 | % |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Revenue volatility |  |  | 27.5 | % |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Stock Price |  | $ | 23.39 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Payment delay (days) |  |  | 80 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Fair value (millions) |  | $ | 7.0 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | March 31, |  |  | December 31, |  |  | September 30, |  |  | June 30, |  |  | March 31, |  |
| Fiscal Year 2023 |  | 2024 |  |  | 2023 |  |  | 2023 |  |  | 2023 |  |  | 2023 |  |
| Revenue risk premium |  |  | 5.50 | % |  |  | 5.70 | % |  |  | 5.30 | % |  |  | 5.20 | % |  |  | 5.30 | % |
| Revenue volatility |  |  | 24.8 | % |  |  | 24.8 | % |  |  | 27.5 | % |  |  | 22.5 | % |  |  | 25 | % |
| Stock Price |  | $ | 13.51 |  |  | $ | 11.14 |  |  | $ | 7.55 |  |  | $ | 6.26 |  |  | $ | 4.91 |  |
| Payment delay (days) |  |  | 80 |  |  |  | 80 |  |  |  | 80 |  |  |  | 80 |  |  |  | 80 |  |
| Fair value (millions) |  | $ | 3.1 |  |  | $ | 1.2 |  |  | $ | 3.5 |  |  | $ | 2.6 |  |  | $ | 1.3 |  |

[0001437749-24-024886:notes:97]
The Company recorded losses of $3.9 million and $1.3 million resulting from the increases in the fair value of the contingent consideration in the three months ended  June 30, 2024 and 2023, respectively.


## us-gaap:DebtDisclosureTextBlock

[0001437749-24-024886:notes:98]
14. Debt

[0001437749-24-024886:notes:99]
As part of the acquisition of Neeltran, the Company identified four equipment financing agreements that Neeltran had entered into prior to the acquisition of Neeltran on  May 6, 2021. The current debt balance was less than $0.1 million as of both  June 30, 2024 and  March 31, 2024.


## us-gaap:LesseeOperatingLeasesTextBlock

[0001437749-24-024886:notes:100]
[same as prior period, unchanged from 0001437749-24-002041:notes:103]

[0001437749-24-024886:notes:101]
[same as prior period, unchanged from 0001437749-24-002041:notes:106]

[0001437749-24-024886:notes:102]
[same as prior period, unchanged from 0001437749-24-002041:notes:107]

[0001437749-24-024886:notes:103]
[same as prior period, unchanged from 0001437749-24-002041:notes:108]

[0001437749-24-024886:notes:104]
[same as prior period, unchanged from 0001437749-24-002041:notes:109]

[0001437749-24-024886:notes:105]
As of  June 30, 2024, the right-of-use asset related to the finance lease is fully amortized, and is included in the property and equipment, net on the Company's condensed consolidated balance sheet.

[0001437749-24-024886:notes:106]
Finance lease right-of-use assets and lease liabilities are recognized similar to an operating lease, at the lease commencement date or the date the lessor makes the leased asset available for use. Finance lease right-of-use assets are generally amortized on a straight-line basis over the lease term, and the carrying amount of the finance lease liabilities are (1) accreted to reflect interest using the incremental borrowing rate if the rate implicit in the lease is not readily determinable, and (2) reduced to reflect lease payments made during the period. Amortization expense for finance lease right-of-use assets and interest accretion on finance lease liabilities are recorded to depreciation expense and interest expense, respectively in the Company's condensed consolidated statement of operations.

[0001437749-24-024886:notes:107]
Supplemental balance sheet information related to leases at  June 30, 2024, and  March 31, 2024 are as follows (in thousands):

[0001437749-24-024886:notes:108]
|  |  | June 30, 2024 |  |  | March 31, 2024 |  |
| Leases: |  |  |  |  |  |  |  |  |
| Right-of-use assets – Operating |  | $ | 4,096 |  |  | $ | 2,557 |  |
| Total right-of-use assets |  |  | 4,096 |  |  |  | 2,557 |  |
| Lease liabilities – ST Operating |  | $ | 862 |  |  | $ | 716 |  |
| Lease liabilities – LT Operating |  |  | 3,359 |  |  |  | 1,968 |  |
| Total lease liabilities |  | $ | 4,221 |  |  | $ | 2,684 |  |
| Weighted-average remaining lease term |  |  | 5.41 |  |  |  | 3.49 |  |
| Weighted-average discount rate |  |  | 12.65 | % |  |  | 9.83 | % |

[0001437749-24-024886:notes:109]
The costs related to the Company's finance lease are not material. The costs related to the Company's operating leases for the three months ended  June 30, 2024 and 2023 are as follows (in thousands):

[0001437749-24-024886:notes:110]
|  |  | Three Months Ended |  |
|  |  | June 30, 2024 |  |
| Operating Leases: |  |  |  |  |
| Operating lease costs – fixed |  | $ | 309 |  |
| Operating lease costs – variable |  |  | 45 |  |
| Short-term lease costs |  |  | 38 |  |
| Total lease costs |  | $ | 392 |  |

[0001437749-24-024886:notes:111]
|  |  | Three Months Ended |  |
|  |  | June 30, 2023 |  |
| Operating Leases: |  |  |  |  |
| Operating lease costs – fixed |  | $ | 259 |  |
| Operating lease costs – variable |  |  | 40 |  |
| Short-term lease costs |  |  | 37 |  |
| Total lease costs |  | $ | 336 |  |

[0001437749-24-024886:notes:112]
[same as prior period, unchanged from 0001437749-24-002041:notes:117]

[0001437749-24-024886:notes:113]
|  |  | Leases |  |
| Year ending March 31, |  |  |  |  |
| 2025 |  | $ | 986 |  |
| 2026 |  |  | 1,319 |  |
| 2027 |  |  | 1,181 |  |
| 2028 |  |  | 823 |  |
| 2029 |  |  | 404 |  |
| Thereafter |  |  | 1,511 |  |
| Total minimum lease payments |  |  | 6,224 |  |
| Less: interest |  |  | (2,003 | ) |
| Present value of lease liabilities |  | $ | 4,221 |  |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001437749-24-024886:notes:114]
16. Commitments and Contingencies

[0001437749-24-024886:notes:115]
Legal Contingencies

[0001437749-24-024886:notes:116]
From time to time, the Company is involved in legal and administrative proceedings and claims of various types. The Company records a liability in its condensed consolidated financial statements for these matters when a loss is known or considered probable and the amount can be reasonably estimated. The Company reviews these estimates each accounting period as additional information is known and adjusts the loss provision when appropriate. If a matter is both probable to result in a liability and the amounts of loss can be reasonably estimated, the Company estimates and discloses the possible loss or range of loss to the extent necessary to make the condensed consolidated financial statements not misleading. If the loss is not probable or cannot be reasonably estimated, a liability is not recorded in its condensed consolidated financial statements.

[0001437749-24-024886:notes:117]
Other

[0001437749-24-024886:notes:118]
The Company enters into long-term construction contracts with customers that require the Company to obtain performance bonds. The Company is required to deposit an amount equivalent to some or all the face amount of the performance bonds into an escrow account until the termination of the bond. When the performance conditions are met, amounts deposited as collateral for the performance bonds are returned to the Company. In addition, the Company has various contractual arrangements in which minimum quantities of goods or services have been committed to be purchased on an annual basis.

[0001437749-24-024886:notes:119]
As of  June 30, 2024, the Company had $1.6 million of restricted cash included in long-term assets and $0.5 million of restricted cash included in current assets. As of  March 31, 2024, the Company had $1.3 million of restricted cash included in long term assets and $0.5 million of restricted cash included in current assets. These amounts included in restricted cash primarily represent deposits to secure letters of credit for various supply contracts and long-term projects or collateral deposits. These deposits are held in interest bearing accounts.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001437749-24-024886:notes:120]
17. Business Segments

[0001437749-24-024886:notes:121]
The Company reports its financial results in two reportable business segments: Grid and Wind. In accordance with ASC 280, Segment Reporting, the Company aggregates four operating segments into one reporting segment for financial reporting purposes due to their similar operating and financial characteristics. The Company's operating segments reflect the way in which internally-reported financial information is used to make decisions and allocate resources.

[0001437749-24-024886:notes:122]
[same as prior period, unchanged from 0001437749-24-002041:notes:134]

[0001437749-24-024886:notes:123]
[same as prior period, unchanged from 0001437749-24-002041:notes:135]

[0001437749-24-024886:notes:124]
[same as prior period, unchanged from 0001437749-24-002041:notes:136]

[0001437749-24-024886:notes:125]
|  |  | Three Months Ended June 30, |  |
|  |  | 2024 |  |  | 2023 |  |
| Revenues: |  |  |  |  |  |  |  |  |
| Grid |  | $ | 32,336 |  |  | $ | 25,737 |  |
| Wind |  |  | 7,954 |  |  |  | 4,517 |  |
| Total |  | $ | 40,290 |  |  | $ | 30,254 |  |

[0001437749-24-024886:notes:126]
|  |  | Three Months Ended June 30, |  |
|  |  | 2024 |  |  | 2023 |  |
| Operating income (loss): |  |  |  |  |  |  |  |  |
| Grid |  | $ | 859 |  |  | $ | (1,971 | ) |
| Wind |  |  | 999 |  |  |  | (649 | ) |
| Unallocated corporate expenses |  |  | (5,149 | ) |  |  | (2,713 | ) |
| Total |  | $ | (3,291 | ) |  | $ | (5,333 | ) |

[0001437749-24-024886:notes:127]
[same as prior period, unchanged from 0001437749-24-002041:notes:139]

[0001437749-24-024886:notes:128]
Unallocated corporate expenses consisted of net losses of $3.9 million and $1.3 million resulting from the increases in the fair value of contingent consideration in the three months ended  June 30, 2024 and 2023, respectively. There are 300,000 shares remaining for potential issuance upon the achievement of the last specified revenue objective under the NEPSI Stock Purchase Agreement by  September 30, 2024. Additionally, unallocated corporate expenses consisted of stock-based compensation expense of $1.2 million and $1.4 million in the three months ended  June 30, 2024 and 2023, respectively.

[0001437749-24-024886:notes:129]
Total assets for the two business segments as of  June 30, 2024 and  March 31, 2024, are as follows (in thousands):

[0001437749-24-024886:notes:130]
|  |  | June 30, 2024 |  |  | March 31, 2024 |  |
| Grid |  | $ | 128,296 |  |  | $ | 125,878 |  |
| Wind |  |  | 16,355 |  |  |  | 14,733 |  |
| Corporate assets |  |  | 95,492 |  |  |  | 92,160 |  |
| Total |  | $ | 240,143 |  |  | $ | 232,771 |  |


## us-gaap:NewAccountingPronouncementsAndChangesInAccountingPrinciplesTextBlock

[0001437749-24-024886:notes:131]
18. Recent Accounting Pronouncements

[0001437749-24-024886:notes:132]
In  November 2023, the FASB issued ASU 2023-07, Segment Reporting (Topic 280): Improvements to Reportable Segment Disclosures. The amendments in ASU 2023-07 improve the disclosures about a public entity’s reportable segments and address requests from investors for additional, more detailed information about a reportable segment’s expenses. Following the release of ASU 2023-07 in  November 2023, the effective date will be annual reporting periods beginning after  December 15, 2024. As of  June 30, 2024, the Company is evaluating the impact on its condensed consolidated financial statements.

[0001437749-24-024886:notes:133]
In  December 2023, the FASB issued ASU 2023-09, Income Taxes (Topic 740): Improvements to Income Tax Disclosures. The amendments in ASU 2023-09 address investor requests for more transparency about income tax information through improvements to income tax disclosures primarily related to the rate reconciliation and income taxes paid information. Following the release of ASU 2023-09 in  December 2023, the effective date will be annual reporting periods beginning after  December 15, 2024. As of  June 30, 2024, the Company is evaluating the impact on its condensed consolidated financial statements.

[0001437749-24-024886:notes:134]
In  March 2024, the FASB issued ASU 2024-02, Codification Improvements—Amendments to Remove References to the Concepts Statements. The amendments in ASU 2024-02 contain amendments to the Codification that remove references to various FASB Concepts Statements. Following the release of ASU 2024-02 in  March 2024, the effective date will be annual reporting periods beginning after  December 15, 2024. As of  June 30, 2024, the Company is evaluating the impact on its condensed consolidated financial statements.


## us-gaap:SubsequentEventsTextBlock

[0001437749-24-024886:notes:135]
19. Subsequent Events

[0001437749-24-024886:notes:136]
The Company has performed an evaluation of subsequent events through the time of filing this Quarterly Report on Form 10-Q with the SEC and has determined that, other than as reported herein and described below, there are no such events to report.

[0001437749-24-024886:notes:137]
Acquisition of Megatran

[0001437749-24-024886:notes:138]
As described in Note 1, Nature of the Business and Operations and Liquidity, on the Acquisition Date, the Company acquired all of the issued and outstanding shares of capital stock of Megatran. Megatran is a U.S.-based global provider of engineered power conversion solutions for demanding industrial and military applications.

[0001437749-24-024886:notes:139]
Pursuant to the Stock Purchase Agreement, the Company acquired all of the issued and outstanding shares of Megatran, for aggregate consideration in an amount equal to $61,350,000 (the “Purchase Price”), which consideration amount shall be subject to various adjustments set forth in the Stock Purchase Agreement (including those described below) and consists of: (a) (i) $25,000,000, minus (ii) the Indebtedness (as defined in the Stock Purchase Agreement) outstanding as of immediately prior to the closing, minus (iii) Company Expenses (as defined in the Stock Purchase Agreement) (collectively, the “Cash Purchase Price”); (b) a number of restricted shares (rounded up or down to the nearest whole share, as applicable) (the “Company Shares”) of the Company’s common stock, $.01 par value per share (“Common Stock”) equal to the quotient obtained by dividing (x) $31,350,000 (the “Share Purchase Price”) by (y) the closing price per share of Common Stock on the Nasdaq Global Select Market on the last trading day immediately preceding the Closing Date; and (c) an additional cash payment equal to $5,000,000, as adjusted pursuant to Sections 5.6(c), (d), and (f) of the Stock Purchase Agreement (the “Additional Cash Purchase Price”). Megatran is now a wholly-owned subsidiary of the Company and is operated and reported as a component of its Grid business unit.

[0001437749-24-024886:notes:140]
The Acquisition completed by the Company subsequent to the three months ended  June 30, 2024 has been accounted for under the purchase method of accounting in accordance with ASC 805, Business Combinations. The Company allocated the purchase price to the assets acquired and liabilities assumed at their estimated fair values as of the date of acquisition. The excess of the purchase price paid by the Company over the estimated fair value of net assets acquired has been recorded as goodwill.

[0001437749-24-024886:notes:141]
The total purchase price of approximately $61.4 million includes the fair value of shares of the Company’s common stock issued at closing, and cash paid, as follows (in millions):

[0001437749-24-024886:notes:142]
| Cash payment | 30.0 |
| Issuance of 1,297,600 shares of Company’s Common Stock | 31.4 |

[0001437749-24-024886:notes:143]
At the Acquisition Date, in addition to the $30.0 million cash, the Company valued the Company’s common stock, using $24.16 per share, which was the closing price on the day prior to the day that the Company acquired Megatran. Acquisition costs are expected to be $0.8 million and will be recorded in selling, general and administrative ("SG&A") costs. Acquisition costs are of $0.2 million were included in SG&A for the three months ended  June 30, 2024.

[0001437749-24-024886:notes:144]
The following table summarizes the allocation of the purchase price based on the estimated fair values of the assets acquired and liabilities assumed and related deferred income taxes in connection with the Acquisition (in millions):

[0001437749-24-024886:notes:145]
| Cash and cash equivalents |  | $ | 0.5 |  |
| Investment in joint venture |  |  | 1.2 |  |
| Prepaid and other current assets |  |  | 1.4 |  |
| Accounts receivable |  |  | 16.7 |  |
| Inventory |  |  | 22.6 |  |
| Property plant and equipment |  |  | 28.4 |  |
| Accrued expenses |  |  | (3.2 | ) |
| Accounts payable |  |  | (4.4 | ) |
| Deferred revenue |  |  | (4.5 | ) |
| Other |  |  | (0.1 | ) |
| Deferred tax liability |  |  | (6.5 | ) |
| Net tangible assets/(liabilities) |  |  | 52.1 |  |
| Backlog |  |  | 0.7 |  |
| Customer relationships |  |  | 1.3 |  |
| Net identifiable intangible assets |  |  | 2.0 |  |
| Goodwill |  |  | 7.3 |  |
| Total purchase consideration |  | $ | 61.4 |  |

[0001437749-24-024886:notes:146]
The fair value of the financial assets acquired includes receivables with a fair value of $16.7 million. The gross amount due is $17.5 million, of which $0.8 million is expected to be uncollectible.

[0001437749-24-024886:notes:147]
Inventory includes a $0.7 million adjustment to step up the inventory balance to fair value consistent with the purchase price allocation. The fair value was determined based on the estimated selling price of the inventory, less the remaining manufacturing and selling cost and a normal profit margin on those manufacturing and selling efforts.

[0001437749-24-024886:notes:148]
Backlog of $0.7 million was evaluated using the multi period excess earnings method under the income approach. The contracts with customers do not provide for any guarantees to source all future requirements from the Company. The amortization method being utilized is economic consumption estimated over a two-year period with the expense being allocated to cost of revenues.

[0001437749-24-024886:notes:149]
Customer relationships of $1.3 million relates to customers currently under contract and was determined based on a multi period excess earnings method under the income approach. The method of amortization being utilized is the economic consumption over 10 years with the expense being allocated to SG&A.

[0001437749-24-024886:notes:150]
Goodwill represents the value associated with the acquired workforce and expected synergies related to the business combination of the two companies. Goodwill resulting from the Acquisition was assigned to the Company’s Grid segment. Goodwill recognized in the Acquisition is not deductible for tax purposes. This purchase price allocation is preliminary and has not been finalized as the analysis on the assets and liabilities acquired, primarily the tax related liability  may require further adjustments to our purchase accounting that could result in a measurement period adjustment that would impact the Company's reported net assets and goodwill as of  August 1, 2024. Material changes, if any, to the preliminary allocation summarized above will be reported once the related uncertainties are resolved, but no later than  August 1, 2025. The $6.5 million of deferred tax liability is primarily related to property plant and equipment.

[0001437749-24-024886:notes:151]
Unaudited Pro Forma Operating Results

[0001437749-24-024886:notes:152]
The unaudited pro forma condensed consolidated statement of operations for the year ended  March 31, 2024 and three months ended  June 30, 2024 is presented as if the Acquisition had occurred on  April 1, 2023 and  April 1, 2024, respectively.

[0001437749-24-024886:notes:153]
|  |  | Three months ended June 30, |  |  | Year Ended March 31, |  |
|  |  | 2024 |  |  | 2024 |  |
| Revenues |  | $ | 59,310 |  |  | $ | 217,954 |  |
| Operating loss |  |  | (2,702 | ) |  |  | (7,140 | ) |
| Net loss |  | $ | (1,760 | ) |  | $ | (4,152 | ) |
| Net loss per common share |  |  |  |  |  |  |  |  |
| Basic |  |  | 36,974 |  |  |  | 31,123 |  |
| Diluted |  |  | 36,974 |  |  |  | 31,123 |  |
| Shares - basic |  | $ | (0.05 | ) |  | $ | (0.13 | ) |
| Shares - diluted |  | $ | (0.05 | ) |  | $ | (0.13 | ) |

[0001437749-24-024886:notes:154]
The pro forma amounts include the historical operating results of the Company and Megatran with appropriate adjustments that give effect to acquisition related costs, income taxes, intangible amortization resulting from the Acquisition and certain conforming accounting policies of the Company.   The pro forma amounts are not necessarily indicative of the operating results that would have occurred if the Acquisition and related transactions had been completed at the beginning of the applicable periods presented. In addition, the pro forma amounts are not necessarily indicative of operating results in future periods.


## ecd:MtrlTermsOfTrdArrTextBlock

[0001437749-24-024886:notes:155]
[same as prior period, unchanged from 0001437749-24-002041:notes:150]

[0001437749-24-024886:notes:156]
(a) None

[0001437749-24-024886:notes:157]
(b) None

[0001437749-24-024886:notes:158]
(c) During the three months ended  June 30, 2024, no director or officer of the Company adopted or terminated a “Rule 10b5-1 trading arrangement” or “non-Rule 10b5-1 trading arrangement,” as each term is defined in Item 408(a) of Regulation
