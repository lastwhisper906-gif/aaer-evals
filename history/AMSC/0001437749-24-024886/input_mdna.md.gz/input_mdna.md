# AMSC MD&A — 0001437749-24-024886


## mdna

[0001437749-24-024886:mdna:1]
[same as prior period, unchanged from 0001437749-24-002041:mdna:1]

[0001437749-24-024886:mdna:2]
American Superconductor®, Amperium®, AMSC®, D-VAR®, PowerModule™, D-VAR VVO®, PQ-IVR®, SeaTitan®, Gridtec™ Solutions, Windtec™ Solutions, Smarter, Cleaner...Better Energy™, orchestrate the rhythm and harmony of power on the grid™, actiVAR®, armorVAR™, NEPSI™ and Neeltran™ and SafetyLOCK™ are trademarks or registered trademarks of American Superconductor Corporation or our subsidiaries. We reserve all of our rights with respect to our trademarks or registered trademarks regardless of whether they are so designated in this Quarterly Report on Form 10-Q by an ® or ™ symbol. All other brand names, product names, trademarks or service marks appearing in this Quarterly Report on Form 10-Q are the property of their respective holders.

[0001437749-24-024886:mdna:3]
[same as prior period, unchanged from 0001437749-24-002041:mdna:3]

[0001437749-24-024886:mdna:4]
We are a leading system provider of megawatt-scale power resiliency solutions that orchestrate the rhythm and harmony of power on the grid™, and protect and expand the capability of our Navy's fleet. Our solutions enhance the performance of the power grid, protect our Navy’s fleet, and lower the cost of wind power.  In the power grid market, we enable electric utilities, industrial facilities, and renewable energy project developers to connect, transmit and distribute smarter, cleaner and better power through our transmission planning services and power electronics and superconductor-based systems. In the wind power market, we enable manufacturers to field highly competitive wind turbines through our advanced power electronics and control system products, engineering, and support services. Our power grid and wind products and services provide exceptional reliability, security, efficiency and affordability to our customers.

[0001437749-24-024886:mdna:5]
Our power system solutions help to improve energy efficiency, alleviate power grid capacity constraints, improve system resiliency, and increase the adoption of renewable energy generation. Demand for our solutions is driven by the growing needs for modernized smart grids that improve power reliability, security and quality, the U.S. Navy's effort to upgrade onboard power systems to support fleet electrification, and the needs for increased renewable sources of electricity, such as wind and solar energy. Concerns about these factors have led to increased spending by corporations and the military, as well as supportive government regulations and initiatives on local, state, and national levels, including renewable portfolio standards, tax incentives and international treaties.

[0001437749-24-024886:mdna:6]
We manufacture products using two proprietary core technologies: PowerModule™ programmable power electronic converters and our Amperium® high temperature superconductor ("HTS") wires. These technologies and our system-level solutions are protected by a robust intellectual property portfolio consisting of patents and patent applications worldwide and rights through exclusive and non-exclusive licenses.

[0001437749-24-024886:mdna:7]
[same as prior period, unchanged from 0001437749-24-002041:mdna:7]

[0001437749-24-024886:mdna:8]
[same as prior period, unchanged from 0001437749-24-002041:mdna:8]

[0001437749-24-024886:mdna:9]
[same as prior period, unchanged from 0001437749-24-002041:mdna:9]

[0001437749-24-024886:mdna:10]
Our fiscal year begins on April 1 and ends on March 31. When we refer to a particular fiscal year, we are referring to the fiscal year that began on April 1 of that same year. For example, fiscal 2024 refers to the fiscal year that began on April 1, 2024. Other fiscal years follow similarly.

[0001437749-24-024886:mdna:11]
We continue to experience some inflationary pressure in our supply chain and some delays in sourcing materials needed for our products, resulting in some production disruption, both of which have increased our cost of revenues and decreased gross margin.  While the impact of inflation has been challenging, we continue to take actions to limit this pressure including adjusting the pricing of our products and services. Changes in macroeconomic conditions arising from various reasons, such as the ongoing wars between Russia and Ukraine and Israel and Hamas, inflation, rising interest rates, labor force availability, sourcing, material delays and global supply chain disruptions, could have a material adverse effect on the Company’s business, financial condition and results of operation.

[0001437749-24-024886:mdna:12]
In February 2023, we completed the process of determining and verifying our eligibility and amount of payroll tax credits known as the Employee Retention Credit (“ERC”) under the CARES Act which Congress enacted as part of the Taxpayer Certainty and Disaster Tax Relief Act of 2020. This resulted in filing certain amended payroll tax forms for eligible quarters in 2020 and 2021, which, in the aggregate, totaled $3.3 million. We recognized a receivable in prepaid expenses and other current assets and a benefit to cost of revenues and operating expenses in the quarter ended March 31, 2023. In the year ended March 31, 2024, the Company received $3.0 million in payments for the initial claims that were processed. The remaining balance is expected to be paid during fiscal 2024.

[0001437749-24-024886:mdna:13]
On February 2, 2024, we completed an offering of 6,210,000 shares of our common stock at a public offering price of $11.25 per share under our then-existing Registration Statement on Form S-3. We received net proceeds of approximately $65.2 million after deducting underwriting discounts and commissions and offering expenses.  See Note 1, “Nature of the Business and Operations and Liquidity,” for further information about this offering.

[0001437749-24-024886:mdna:14]
On August 1, 2024, we entered into a Stock Purchase Agreement (the “Stock Purchase Agreement”) with the selling stockholders named therein.  Pursuant to the terms of the Stock Purchase Agreement and concurrently with entering into such agreement, the Company acquired all of the issued and outstanding shares of Megatran, for aggregate consideration in an amount equal to $61,350,000 (the “Purchase Price”).  The Megatran purchase price was $30.0 million in cash on hand, and 1,297,600 restricted shares of our common stock.  Megatran is a U.S.-based global provider of engineered power conversion solutions for demanding industrial and military applications.  As a result of this transaction, Megatran became a wholly-owned subsidiary and will be operated by our Grid business unit.

[0001437749-24-024886:mdna:15]
[same as prior period, unchanged from 0001437749-24-002041:mdna:14]

[0001437749-24-024886:mdna:16]
The preparation of the unaudited condensed consolidated financial statements requires that we make estimates and judgments that affect the reported amounts of assets, liabilities, revenues and expenses, and related disclosure of contingent assets and liabilities. We base our estimates on historical experience and various other assumptions that are believed to be reasonable under the circumstances, the results of which form the basis for making judgments about the carrying values of assets and liabilities that are not readily apparent from other sources. Actual results may differ under different assumptions or conditions. Certain prior period amounts were reclassified to conform to the presentation in the current period. There were no significant changes in the critical accounting policies that were disclosed in our Annual Report on Form 10-K for the fiscal year ended March 31, 2024.

[0001437749-24-024886:mdna:17]
[same as prior period, unchanged from 0001437749-24-002041:mdna:16]

[0001437749-24-024886:mdna:18]
Three months ended June 30, 2024, compared to the three months ended June 30, 2023

[0001437749-24-024886:mdna:19]
[same as prior period, unchanged from 0001437749-24-002041:mdna:18]

[0001437749-24-024886:mdna:20]
Total revenues increased 33% to $40.3 million for the three months ended June 30, 2024, compared $30.3 million for the three months ended June 30, 2023. Our revenues are summarized as follows (in thousands):

[0001437749-24-024886:mdna:21]
|  |  | Three Months Ended June 30, |  |
|  |  | 2024 |  |  | 2023 |  |
| Revenues: |  |  |  |  |  |  |  |  |
| Grid |  | $ | 32,336 |  |  | $ | 25,737 |  |
| Wind |  |  | 7,954 |  |  |  | 4,517 |  |
| Total |  | $ | 40,290 |  |  | $ | 30,254 |  |

[0001437749-24-024886:mdna:22]
Our Grid business unit accounted for 80% of total revenues for the three months ended June 30, 2024, compared to 85% for the three months ended June 30, 2023. Our Grid business unit revenues increased 26% to $32.3 million in the three months ended June 30, 2024, from $25.7 million in the three months ended June 30, 2023. The increase in the Grid business unit revenues in the three months ended June 30, 2024, compared to the three months ended June 30, 2023 was primarily driven by increased shipments of new energy power systems than in the prior year period.

[0001437749-24-024886:mdna:23]
Our Wind business unit accounted for 20% of total revenues for the three months ended June 30, 2024, compared to 15% for the three months ended June 30, 2023. Revenues in the Wind business unit increased 76% to $8.0 million in the three months ended June 30, 2024, from $4.5 million in the three months ended June 30, 2023. The increase during the three months ended June 30, 2024, compared to the three months ended June 30, 2023, was driven by additional shipments of electrical control systems ("ECS") at increased prices.

[0001437749-24-024886:mdna:24]
[same as prior period, unchanged from 0001437749-24-002041:mdna:23]

[0001437749-24-024886:mdna:25]
Cost of revenues increased by 17% to $28.1 million for the three months ended June 30, 2024, compared to $24.0 million for the three months ended June 30, 2023. Gross margin was 30% for the three months ended June 30, 2024, compared to 21% for the three months ended June 30, 2023. The increase in gross margin in the three months ended June 30, 2024 was due to higher revenues, a more favorable product mix and favorable impacts across the business due to pricing increases across our product lines.

[0001437749-24-024886:mdna:26]
[same as prior period, unchanged from 0001437749-24-002041:mdna:25]

[0001437749-24-024886:mdna:27]
[same as prior period, unchanged from 0001437749-24-002041:mdna:26]

[0001437749-24-024886:mdna:28]
Research and development ("R&D") expenses increased 23% in the three months ended June 30, 2024 to $2.3 million from $1.9 million in the three months ended June 30, 2023. The increase was driven primarily by higher overall compensation expense and additional supplies and materials.

[0001437749-24-024886:mdna:29]
[same as prior period, unchanged from 0001437749-24-002041:mdna:28]

[0001437749-24-024886:mdna:30]
Selling, general and administrative ("SG&A") expenses increased 13% in the three months ended June 30, 2024 to $8.9 million from $7.9 million in the three months ended June 30, 2023.  The increase in SG&A expense in the three months ended June 30, 2024, was due to higher overall compensation expense and higher outside services expense.

[0001437749-24-024886:mdna:31]
[same as prior period, unchanged from 0001437749-24-002041:mdna:30]

[0001437749-24-024886:mdna:32]
We recorded amortization expense related to our core technology and know-how, customer relationships, and other intangible assets of $0.4 million in the three months ended June 30, 2024, and $0.5 million in the three months ended June 30, 2023. The decrease in amortization expense is a result of using the economic consumption method as the basis to amortize the acquired customer relationship intangible assets from NEPSI and Neeltran.

[0001437749-24-024886:mdna:33]
[same as prior period, unchanged from 0001437749-24-002041:mdna:32]

[0001437749-24-024886:mdna:34]
The change in fair value of our contingent consideration for the earnout payment on the acquisition of NEPSI resulted in losses of $3.9 million and $1.3 million in the three months ended June 30, 2024 and 2023, respectively. The change in the fair value was primarily driven by an increased likelihood of achieving certain revenue targets and an increase in our stock price.

[0001437749-24-024886:mdna:35]
[same as prior period, unchanged from 0001437749-24-002041:mdna:34]

[0001437749-24-024886:mdna:36]
[same as prior period, unchanged from 0001437749-24-002041:mdna:35]

[0001437749-24-024886:mdna:37]
|  |  | Three Months Ended June 30, |  |
|  |  | 2024 |  |  | 2023 |  |
| Operating income (loss): |  |  |  |  |  |  |  |  |
| Grid |  | $ | 859 |  |  | $ | (1,971 | ) |
| Wind |  |  | 999 |  |  |  | (649 | ) |
| Unallocated corporate expenses |  |  | (5,149 | ) |  |  | (2,713 | ) |
| Total |  | $ | (3,291 | ) |  | $ | (5,333 | ) |

[0001437749-24-024886:mdna:38]
Our Grid business segment generated operating income of $0.9 million in the three months ended June 30, 2024, compared to operating losses of $2.0 million in the three months ended June 30, 2023.  The increase in the Grid business unit operating income in the three months ended June 30, 2024 was due to higher revenues and gross margins due to a favorable product mix.

[0001437749-24-024886:mdna:39]
Our Wind business segment generated operating income of $1.0 million in the three months ended June 30, 2024, compared to operating losses of $0.6 million in the three months ended June 30, 2023. The improvement in the Wind business unit operating income in the three months ended June 30, 2024 was due to higher revenues and gross margins from increased sales of ECS units.

[0001437749-24-024886:mdna:40]
Unallocated corporate expenses included net losses on contingent consideration of $3.9 million and $1.3 million in the three months ended June 30, 2024 and 2023, respectively. Additionally, unallocated corporate expenses consisted of stock-based compensation expense of $1.2 million and $1.4 million in the three months ended June 30, 2024 and 2023, respectively.

[0001437749-24-024886:mdna:41]
[same as prior period, unchanged from 0001437749-24-002041:mdna:40]

[0001437749-24-024886:mdna:42]
Interest income, net, was $1.1 million in the three months ended June 30, 2024, compared to $0.2 million in the three months ended June 30, 2023. The increase in interest income, net, in the three months ended June 30, 2024 was due to higher cash balances earning higher interest rates.

[0001437749-24-024886:mdna:43]
Other expense, net

[0001437749-24-024886:mdna:44]
Other expense, net, was $0.2 million in the three months ended June 30, 2024, compared to $0.1 million in the three months ended June 30, 2023. The increase in other expense, net, during the three months ended June 30, 2024, compared to the three months ended June 30, 2023, was driven by the impacts of unfavorable fluctuations in foreign currencies during the periods.

[0001437749-24-024886:mdna:45]
[same as prior period, unchanged from 0001437749-24-002041:mdna:46]

[0001437749-24-024886:mdna:46]
Income tax expense was $0.2 million in the three months ended June 30, 2024. Income tax expense was $0.1 million in the three months ended June 30, 2023.

[0001437749-24-024886:mdna:47]
[same as prior period, unchanged from 0001437749-24-002041:mdna:48]

[0001437749-24-024886:mdna:48]
Net loss was $2.5 million in the three months ended June 30, 2024, compared to $5.4 million in the three months ended June 30, 2023. The decrease in net loss was driven primarily by the increased revenues and gross margins.

[0001437749-24-024886:mdna:49]
[same as prior period, unchanged from 0001437749-24-002041:mdna:50]

[0001437749-24-024886:mdna:50]
[same as prior period, unchanged from 0001437749-24-002041:mdna:51]

[0001437749-24-024886:mdna:51]
We define non-GAAP net income (loss) as net loss before stock-based compensation, amortization of acquisition-related intangibles, change in fair value of contingent consideration, and other non-cash or unusual charges.  We believe non-GAAP net income (loss) assists management and investors in comparing our performance across reporting periods on a consistent basis by excluding these non-cash charges and other items that we do not believe are indicative of our core operating performance. In addition, we use non-GAAP net income (loss) as a factor to evaluate the effectiveness of our business strategies. A reconciliation of GAAP to non-GAAP net income (loss) is set forth in the table below (in thousands, except per share data):

[0001437749-24-024886:mdna:52]
|  |  | Three Months Ended June 30, |  |
|  |  | 2024 |  |  | 2023 |  |
| Net loss |  | $ | (2,524 | ) |  | $ | (5,398 | ) |
| Stock-based compensation |  |  | 1,229 |  |  |  | 1,357 |  |
| Amortization of acquisition-related intangibles |  |  | 412 |  |  |  | 544 |  |
| Change in fair value of contingent consideration |  |  | 3,920 |  |  |  | 1,350 |  |
| Non-GAAP net income (loss) |  | $ | 3,037 |  |  | $ | (2,147 | ) |
| Non-GAAP net income (loss) per share - basic |  | $ | 0.09 |  |  | $ | (0.08 | ) |
| Non-GAAP net income (loss) per share - diluted |  | $ | 0.08 |  |  | $ | (0.08 | ) |
| Weighted average shares outstanding - basic |  |  | 35,676 |  |  |  | 28,258 |  |
| Weighted average shares outstanding - diluted |  |  | 37,032 |  |  |  | 28,258 |  |

[0001437749-24-024886:mdna:53]
We incurred non-GAAP net income of $3.0 million, or $0.09 per share, for the three months ended June 30, 2024, compared to non-GAAP net losses of $2.1 million, or $(0.08) per share, for the three months ended June 30, 2023. The improvement in the non-GAAP net income (loss) for the three months ended June 30, 2024 was due to a lower operating loss driven by higher revenues and gross margins.

[0001437749-24-024886:mdna:54]
[same as prior period, unchanged from 0001437749-24-002041:mdna:55]

[0001437749-24-024886:mdna:55]
[same as prior period, unchanged from 0001437749-24-002041:mdna:56]

[0001437749-24-024886:mdna:56]
We have experienced recurring operating losses and, as of June 30, 2024, had an accumulated deficit of $1,069.2 million.

[0001437749-24-024886:mdna:57]
[same as prior period, unchanged from 0001437749-24-002041:mdna:58]

[0001437749-24-024886:mdna:58]
In January 2024, we filed a shelf registration statement on Form S-3 that will expire three years from the date on which it was declared effective, March 15, 2027 (the “Form S-3”). The Form S-3 allows us to offer and sell from time-to-time up to $250 million of common stock, debt securities, warrants or units comprised of any combination of these securities. The Form S-3 is intended to provide us flexibility to conduct registered sales of our securities, subject to market conditions, in order to fund our future capital needs. The terms of any future offering under the Form S-3 will be established at the time of such offering and will be described in a prospectus supplement filed with the SEC prior to the completion of any such offering.

[0001437749-24-024886:mdna:59]
On February 14, 2024, we completed a public offering of 6,210,000 shares of our common stock at a price of $11.25 per share under our then-existing Registration Statement on Form S-3. We received net proceeds of approximately $65.2 million after deducting underwriting discounts and commissions and offering expenses.

[0001437749-24-024886:mdna:60]
As of June 30, 2024, we had cash, cash equivalents and restricted cash of $95.5 million, compared to $92.3 million as of March 31, 2024, an increase of $3.2 million. As of June 30, 2024, we had $3.2 million in cash, cash equivalents, and restricted cash in foreign bank accounts. Our cash, cash equivalents, and restricted cash are summarized as follows (in thousands):

[0001437749-24-024886:mdna:61]
|  |  | June 30, 2024 |  |  | March 31, 2024 |  |
| Cash and cash equivalents |  | $ | 93,455 |  |  | $ | 90,522 |  |
| Restricted cash |  |  | 2,068 |  |  |  | 1,758 |  |
| Total cash, cash equivalents, and restricted cash |  | $ | 95,523 |  |  | $ | 92,280 |  |

[0001437749-24-024886:mdna:62]
For the three months ended June 30, 2024, net cash provided by operating activities was $3.4 million, compared to cash used in operations of $2.2 million for the three months ended June 30, 2023. The increase in cash flows from operating activities in the three months ended June 30, 2024 was due primarily to improvement in net loss, increase in the change in fair value of contingent consideration, and less cash used to settle accounts payable and accrued expenses, slightly offset by cash used for prepaid expenses and other assets.

[0001437749-24-024886:mdna:63]
For the three months ended June 30, 2024, net cash used in investing activities was less than $0.1 million, compared to $0.3 million for the three months ended June 30, 2023. The decrease in net cash used in investing activities was primarily due to changes in other assets.

[0001437749-24-024886:mdna:64]
For the three months ended June 30, 2024, net cash used in financing activities was $0.1 million compared to less than $0.1 million for the three months ended June 30, 2023. The increase was in the repurchase of common stock in connection with employee tax obligations upon the vesting of stock awards.

[0001437749-24-024886:mdna:65]
As of June 30, 2024, we had $1.6 million of restricted cash included in long-term assets and $0.5 million of restricted cash included in current assets. At March 31, 2024, we had $1.3 million of restricted cash included in long-term assets and $0.5 million of restricted cash in current assets. These amounts included in restricted cash primarily represent collateral deposits to secure surety bonds and letters of credit for various customer contracts. These deposits are held in interest bearing accounts.

[0001437749-24-024886:mdna:66]
We are a party to many contractual obligations involving commitments to make payments to third parties. These obligations impact our short-term and long-term liquidity and capital resource needs. Certain contractual obligations are reflected on the condensed consolidated balance sheet as of June 30, 2024, while others are considered future commitments. We have various contractual arrangements, under which we have committed to purchase certain minimum quantities of goods or services on an annual basis. For information regarding our other contractual obligations, refer to Note 13, "Contingent Consideration," Note 14, "Debt," Note 15, "Leases" and Note 16, "Commitments and Contingencies" to our condensed consolidated financial statements included elsewhere in this Quarterly Report on Form 10-Q.

[0001437749-24-024886:mdna:67]
We believe we have sufficient available liquidity to fund our operations and capital expenditures for the next twelve months. We recently raised $65.2 million, net of offering expenses, through an equity raise in February 2024. In addition, we may seek to raise additional capital, which could be in the form of loans, convertible debt or equity, to fund our operating requirements and capital expenditures. Our liquidity is highly dependent on our ability to increase revenues, control our operating costs, and raise additional capital, if necessary. There can be no assurance that we will be able to raise additional capital on favorable terms or at all or execute on any other means of improving our liquidity as described above.  Additionally, the impact of global sources of instability, including the ongoing wars between Russia and Ukraine and Israel and Hamas, instability of financial institutions and political instability in the United States, on the global financial markets may reduce our ability to raise additional capital, if necessary, which could negatively impact our liquidity. We also continue to closely monitor our expenses and, if required, we intend to reduce our operating and capital spending to enhance liquidity.

[0001437749-24-024886:mdna:68]
Legal Proceedings

[0001437749-24-024886:mdna:69]
From time to time, we are involved in legal and administrative proceedings and claims of various types. We record a liability in our condensed consolidated financial statements for these matters when a loss is known or considered probable and the amount can be reasonably estimated. We review these estimates each accounting period as additional information is known and adjust the loss provision when appropriate. If a matter is both probable to result in liability and the amounts of loss can be reasonably estimated, we estimate and disclose the possible loss or range of loss to the extent necessary to make the condensed consolidated financial statements not misleading. If the loss is not probable or cannot be reasonably estimated, a liability is not recorded in our condensed consolidated financial statements.

[0001437749-24-024886:mdna:70]
[same as prior period, unchanged from 0001437749-24-002041:mdna:70]

[0001437749-24-024886:mdna:71]
In November 2023, the FASB issued ASU 2023-07, Segment Reporting (Topic 280): Improvements to Reportable Segment Disclosures. The amendments in ASU 2023-07 improve the disclosures about a public entity’s reportable segments and address requests from investors for additional, more detailed information about a reportable segment’s expenses. Following the release of ASU 2023-07 in November 2023, the effective date will be annual reporting periods beginning after December 15, 2024. As of June 30, 2024, we are evaluating the impact on our condensed consolidated financial statements.

[0001437749-24-024886:mdna:72]
In December 2023, the FASB issued ASU 2023-09, Income Taxes (Topic 740): Improvements to Income Tax Disclosures. The amendments in ASU 2023-09 address investor requests for more transparency about income tax information through improvements to income tax disclosures primarily related to the rate reconciliation and income taxes paid information. Following the release of ASU 2023-09 in December 2023, the effective date will be annual reporting periods beginning after December 15, 2024. As of June 30, 2024, we are evaluating the impact on our condensed consolidated financial statements.

[0001437749-24-024886:mdna:73]
In March 2024, the FASB issued ASU 2024-02, Codification Improvements—Amendments to Remove References to the Concepts Statements. The amendments in ASU 2024-02 contain amendments to the Codification that remove references to various FASB Concepts Statements. Following the release of ASU 2024-02 in March 2024, the effective date will be annual reporting periods beginning after December 15, 2024. As of June 30, 2024, we are evaluating the impact on our condensed consolidated financial statements.

[0001437749-24-024886:mdna:74]
We do not believe that, outside of those disclosed here, there are any other recently issued accounting pronouncements that will have a material impact on our condensed consolidated financial statements.
