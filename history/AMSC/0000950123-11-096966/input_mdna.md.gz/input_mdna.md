# AMSC MD&A — 0000950123-11-096966


## mdna

[0000950123-11-096966:mdna:1]
ITEM 2. MANAGEMENT’S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS

[0000950123-11-096966:mdna:2]
due and owing and are in dispute; Sinovel has filed a counterclaim in the arbitration claiming
damages; we cannot be certain as to the outcome of the proceedings against Sinovel; we have been
named as a party to purported stockholder class actions and shareholder derivative complaints, and
we may be named in additional litigation, all of which will require significant management time and
attention, result in significant legal expenses and may result in an unfavorable outcome, which
could have a material adverse effect on our business, operating results and financial condition;
our technology and products could infringe intellectual property rights of others, which may
require costly litigation and, if we are not successful, could cause us to pay substantial damages
and disrupt our business; our patents may not provide meaningful protection for our technology,
which could result in us losing some or all of our market position; third parties have or may
acquire patents that cover the materials, processes and technologies we use or may use in the
future to manufacture our Amperium products, and our success depends on our ability to license such
patents or other proprietary rights; and our common stock has experienced, and may continue to
experience, significant market price and volume fluctuations, which may prevent our stockholders
from selling our common stock at a profit and could lead to costly litigation against us that could
divert our management’s attention. These and the important factors discussed under the caption
“Risk Factors” in Part II. Item 1A and Part 1. Item 1A of our Form 10-K for the fiscal year ended
March 31, 2011, among others, could cause actual results to differ materially from those indicated
by forward-looking statements made herein and presented elsewhere by management from time to time.
Any such forward-looking statements represent management’s estimates as of the date of this
Quarterly Report on Form 10-Q. While we may elect to update such forward-looking statements at some
point in the future, we disclaim any obligation to do so, even if subsequent events cause our views
to change. These forward-looking statements should not be relied upon as representing our views as
of any date subsequent to the date of this Quarterly Report on Form 10-Q.

[0000950123-11-096966:mdna:3]
AMSC, American Superconductor, Amperium, dSVC, DataPark, D-VAR, D-VAR-RT, FaultBlocker,
Gridtec Solutions, PowerModule, PowerPipelines, PQ-IVR, SafetyLock, SeaTitan, SolarTie, SuperGEAR,
Wind-RT, Windtec, Windtec Solutions, wtCMS, wtSCADA, wtWPC, and “smarter, cleaner ... better
energy,” are trademarks or registered trademarks of American Superconductor Corporation or its
subsidiaries. All other brand names, product names, trademarks or service marks appearing in this
Quarterly Report on Form 10-Q are the property of their respective holders.

[0000950123-11-096966:mdna:4]
[same as prior period, unchanged from 0000950123-11-086250:mdna:4]

[0000950123-11-096966:mdna:5]
American Superconductor Corporation (“AMSC”) was founded in 1987. We are a leading provider of
megawatt-scale solutions that lower the cost of wind power and enhance the performance of the power
grid. In the wind power market, we enable manufacturers to field wind turbines through our
advanced engineering, support services and power electronics products. In the power grid market,
we enable electric utilities and renewable energy project developers to connect, transmit and
distribute power through our transmission planning services and power electronics and
superconductor based products. Our wind and power grid products and services provide exceptional
reliability, security, efficiency and affordability to our customers.

[0000950123-11-096966:mdna:6]
[same as prior period, unchanged from 0000950123-11-086250:mdna:6]

[0000950123-11-096966:mdna:7]
[same as prior period, unchanged from 0000950123-11-086250:mdna:7]

[0000950123-11-096966:mdna:8]
We operate our business in two market-facing business units: Wind and Grid. We believe this
market-centric structure enables us to more effectively anticipate and meet the needs of wind
turbine manufacturers, power generation project developers and electric utilities.

[0000950123-11-096966:mdna:9]
|  | • |  | Wind. Through our Windtec Solutions, our Wind business segment enables manufacturers to field wind turbines with exceptional power output, reliability and affordability. We license our highly engineered wind turbine designs, provide extensive customer support services and supply advanced power electronics and control systems to wind turbine manufactures. Our design portfolio includes a broad range of drive trains and power ratings up to 10 megawatts. We believe our unique engineering capabilities, ranging from bearings to advanced synchronous generators to blades, enables us to provide our partners with highly-optimized wind turbine platforms. Furthermore, these designs and support services typically lead to sales of our power electronics and software-based control systems, which are designed for optimized performance, efficiency and grid compatibility. |

[0000950123-11-096966:mdna:10]
|  | • |  | Grid. Through our Gridtec Solutions, our Grid business segment enables electric utilities and renewable energy project developers to connect, transmit and distribute power with exceptional efficiency, reliability and affordability. We provide transmission planning services that allow us to identify power grid congestion, poor power quality and other risks, which help us determine how our solutions can improve network performance. These services often lead to sales of grid interconnection solutions for wind farms and solar power plants, power quality systems and transmission and distribution cable systems. |

[0000950123-11-096966:mdna:11]
Our fiscal year begins on April 1 and ends on March 31. This document refers to fiscal 2011,
which is defined as the period beginning on April 1, 2011 and concluding on March 31, 2012. The
second quarter of fiscal 2011 began on July 1, 2011 and concluded on September 30, 2011.

[0000950123-11-096966:mdna:12]
[same as prior period, unchanged from 0000950123-11-086250:mdna:15]

[0000950123-11-096966:mdna:13]
As of September 30, 2011 and March 31, 2011, we had backlog of approximately $298.2 million
and $228.4 million, respectively, excluding Sinovel. On March 31, 2011, Sinovel refused to accept
contracted shipments of 1.5-MW and 3-MW wind turbine core electrical components and spare parts
that we were prepared to deliver. As a result, we have not made shipments to Sinovel since
February 2011. Additionally, we are pursuing litigation against Sinovel for the theft of our
intellectual property (as discussed below). Consequently, our reported backlog excludes purchase
contracts with Sinovel.

[0000950123-11-096966:mdna:14]
[same as prior period, unchanged from 0000950123-11-086250:mdna:17]

[0000950123-11-096966:mdna:15]
While we have had several discussions with Sinovel since March 31, 2011, as of the date of
this filing, we have not received payment for any outstanding receivables nor have we been notified
as to when, if ever, they will accept contracted shipments that were scheduled for delivery after
March 31, 2011. Additionally, based in part upon evidence obtained through an internal
investigation and a criminal investigation conducted by Austrian authorities regarding the actions
of a former employee of our AMSC Windtec subsidiary, we believe that Sinovel illegally obtained and
used our intellectual property in violation of civil and criminal intellectual property laws. In
July 2011, the former employee was arrested in Austria and in September 2011, pled guilty to
charges of economic espionage and fraudulent manipulation of data. The evidence presented during
the court hearing showed that this former employee was contracted by Sinovel through an
intermediary while employed by us and improperly obtained and transferred to Sinovel portions of
our wind turbine control software source code developed for Sinovel’s 1.5MW wind turbines. Except
for portions of this 1.5MW wind turbine software, we do not believe that the source code for any
other turbines, such as the 3MW, 5MW and 6MW wind turbines that were designed by and co-developed
with us have been transferred to Sinovel. Moreover, we believe the evidence shows this former
employee illegally used source code to develop for Sinovel a software modification to circumvent
the encryption and remove technical protection measures on the PM3000 power converters in 1.5MW
wind turbines in the field. We believe that only the binary code, or upper layer, of the PM3000
software developed to circumvent the encryption and remove technical protection measures was
transferred to Sinovel. We do not believe that any PM3000 source code was transferred to Sinovel.
These actions potentially enable Sinovel to deploy, independent of us, wind turbine control
software, including a low voltage ride through solution, on all of its 1.5MW wind turbines in the
field. In addition, by having the wind turbine control source code, Sinovel could potentially
modify the source code to allow the use of core electrical components, including power converters,
from other manufacturers.

[0000950123-11-096966:mdna:16]
On September 13, 2011, we commenced a series of legal actions in China against Sinovel. We
filed a claim for arbitration in Beijing, China to compel Sinovel to pay us for past product
shipments and to accept all contracted but not yet delivered core electrical components and spare
parts under all existing contracts with us. The arbitration claim was filed with the Beijing
Arbitration Commission in accordance with the terms of our supply contracts with Sinovel. We have
also filed civil and criminal complaints against Sinovel. On September 16, 2011, we filed a civil
complaint in China against Dalian

[0000950123-11-096966:mdna:17]
Guotong Electric, Co., Ltd. and other parties. The complaints
allege the illegal use of our intellectual property. We are seeking to compel Sinovel and the other parties to cease and desist from infringing our
intellectual property and are also seeking monetary damages to compensate us for our economic
losses resulting from the infringement.

[0000950123-11-096966:mdna:18]
[same as prior period, unchanged from 0000950123-11-086250:mdna:21]

[0000950123-11-096966:mdna:19]
[same as prior period, unchanged from 0000950123-11-086250:mdna:22]

[0000950123-11-096966:mdna:20]
[same as prior period, unchanged from 0000950123-11-086250:mdna:23]

[0000950123-11-096966:mdna:21]
[same as prior period, unchanged from 0000950123-11-086250:mdna:24]

[0000950123-11-096966:mdna:22]
Three and six months ended September 30, 2011 compared to the three and six months ended September
30, 2010

[0000950123-11-096966:mdna:23]
Beginning on April 1, 2011, management revised its reportable business segments into Wind and
Grid as a result of changes in the manner in which we disaggregate the Company’s operations for
making operating decisions and assessing performance of our business segments. Previously, we had
two reportable business segments, AMSC Power Systems and AMSC Superconductors. All prior period
segment disclosures have been revised to conform to management’s current view of its business
segments.

[0000950123-11-096966:mdna:24]
As discussed above, the disruption in our relationship with Sinovel has materially and
adversely affected our business and results of operations. Because Sinovel has accounted for more
than two-thirds of our revenues over each of the past three fiscal years, we experienced
significantly lower revenues and significant operating losses during the three and six months ended
September 30, 2011. Revenues to Sinovel represented 82% and 77% of total revenues for the three and
six months ended September 30, 2010, respectively. Since no cash payments were made by Sinovel in
the three and six months ended September 30, 2011, no revenue was recognized from Sinovel in the
three and six months ended September 30, 2011.

[0000950123-11-096966:mdna:25]
[same as prior period, unchanged from 0000950123-11-086250:mdna:28]

[0000950123-11-096966:mdna:26]
Total revenues decreased by 79% and 85% to $20.8 million and $29.9 million for the three and
six months ended September 30, 2011, respectively, compared to $98.1 million and $195.3 million for
the three and six months ended September 30, 2010, respectively. Our revenues are summarized as
follows (in thousands):

[0000950123-11-096966:mdna:27]
|  |  | Three months ended |  |  | Six months ended |  |
|  |  | September 30, |  |  | September 30, |  |
|  |  | 2011 |  |  | 2010 |  |  | 2011 |  |  | 2010 |  |
| Revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Wind |  | $ | 13,449 |  |  | $ | 89,316 |  |  | $ | 17,712 |  |  | $ | 172,323 |  |
| Grid |  |  | 7,351 |  |  |  | 8,757 |  |  |  | 12,146 |  |  |  | 22,960 |  |
| Total |  | $ | 20,800 |  |  | $ | 98,073 |  |  | $ | 29,858 |  |  | $ | 195,283 |  |

[0000950123-11-096966:mdna:28]
Our Wind business unit accounted for 65% and 59% of total revenues for the three and six
months ended September 30, 2011, respectively, compared to 91% and 88% for the three and six months
ended September 30, 2010. Revenues in the Wind business unit decreased 85% and 90% to $13.5 million
and $17.7 million in the three and six months ended September 30, 2011, respectively, from $89.3
million and $172.3 million in the three and six months ended September 30, 2010, respectively. The
decrease in Wind business unit revenues was primarily due to the disruption in our relationship
with Sinovel, as described above.

[0000950123-11-096966:mdna:29]
Our Grid business unit accounted for 35% and 41% of total revenues for the three and six
months ended September 30, 2011, respectively, compared to 9% and 12% for the three and six months
ended September 30, 2010. Revenues in the Grid business unit decreased 16% and 47% to $7.4 million
and $12.1 million in the three and six months ended September 30, 2011, respectively, from $8.8
million and $23.0 million in the three and six months ended September 30, 2010, respectively.

[0000950123-11-096966:mdna:30]
The
decrease in Grid business unit revenues for the three months ended September 30, 2011 was due
primarily to reduced HTS product sales, partially offset by higher D-VAR product sales. The decrease in Grid
business unit revenues for the six months ended September 30, 2011 was due primarily to reduced
D-VAR and HTS product sales.

[0000950123-11-096966:mdna:31]
[same as prior period, unchanged from 0000950123-11-086250:mdna:33]

[0000950123-11-096966:mdna:32]
|  |  |  |  |  |  | Revenue earned |  |  | Three months ended |  |  | Six months ended |  |
|  |  | Expected total |  |  | through |  |  | September 30, |  |  | September 30, |  |
| Project name |  | contract value |  |  | September 30, 2011 |  |  | 2011 |  |  | 2010 |  |  | 2011 |  |  | 2010 |  |
| HYDRA |  | $ | 24,908 |  |  | $ | 11,249 |  |  | $ | 286 |  |  | $ | 388 |  |  | $ | 697 |  |  | $ | 509 |  |
| LIPA I and II |  |  | 40,141 |  |  |  | 39,784 |  |  |  | 74 |  |  |  | 1,366 |  |  |  | 1,383 |  |  |  | 2,148 |  |
| DOE-FCL |  |  | 7,898 |  |  |  | 6,867 |  |  |  | 82 |  |  |  | 416 |  |  |  | 314 |  |  |  | 987 |  |
| NAVSEA Motor Study |  |  | 6,511 |  |  |  | 6,492 |  |  |  | — |  |  |  | 42 |  |  |  | — |  |  |  | 149 |  |
| Total |  | $ | 79,458 |  |  | $ | 64,392 |  |  | $ | 442 |  |  | $ | 2,212 |  |  | $ | 2,394 |  |  | $ | 3,793 |  |

[0000950123-11-096966:mdna:33]
These significant projects represented 6% and 20% of the Grid business unit revenues for
the three and six months ended September 30, 2011, respectively, compared to 25% and 17% for the
three and six months ended September 30, 2010, respectively.

[0000950123-11-096966:mdna:34]
Project HYDRA is a contract with Consolidated Edison, Inc. which is being partially funded by
the U.S. Department of Homeland Security (“DHS”). DHS is expected to invest up to a total of $24.9
million in the development of a new high temperature superconductor power grid technology called
FaultBlocker™ cable systems. FaultBlocker cable systems are designed to utilize customized
Amperium™ HTS wires, and ancillary controls to deliver more power through the grid while also being
able to suppress power surges that can disrupt service. On September 15, 2011, the DHS committed an
additional $3.0 million in funding on Project HYDRA. Of the total $24.9 million in funding
expected from DHS, it has committed funding of $15.6 million to us as of September 30, 2011.
Consolidated Edison and Southwire Company are subcontractors to us on this project.

[0000950123-11-096966:mdna:35]
LIPA II is a project to install an HTS power cable utilizing our Amperium™ wire for the Long
Island Power Authority. DOE-FCL is a project to develop and demonstrate a transmission voltage
SuperLimiter fault current limiter (“FCL”). The NAVSEA Motor Study is a project designed to test
the 36.5 MW superconductor motor developed for the U.S. Navy.

[0000950123-11-096966:mdna:36]
Based on the average Euro and Renminbi exchange rates for the second quarter of fiscal 2011,
revenues denominated in these foreign currencies translated into U.S. dollars were $0.2 million
higher compared to the translation of these revenues using the average exchange rates of these
currencies for the second quarter of fiscal 2010.

[0000950123-11-096966:mdna:37]
The following table sets forth customers who represented 10% or more of the Company’s total
revenues:

[0000950123-11-096966:mdna:38]
|  |  | Three months ended |  |  | Six months ended |  |
|  |  | September 30, |  |  | September 30, |  |
|  |  | 2011 |  |  | 2010 |  |  | 2011 |  |  | 2010 |  |
| Inox Wind, Ltd. |  |  | 24 | % |  |  | <10 | % |  |  | 17 | % |  |  | <10 | % |
| Doosan Heavy Industries & Construction Co Ltd. |  |  | 17 | % |  |  | <10 | % |  |  | 16 | % |  |  | <10 | % |
| Dongfang Electric Machinery Co. |  |  | 11 | % |  |  | — | % |  |  | <10 | % |  |  | — | % |
| Sinovel Wind Co., Ltd |  |  | — | % |  |  | 82 | % |  |  | — | % |  |  | 77 | % |

[0000950123-11-096966:mdna:39]
[same as prior period, unchanged from 0000950123-11-086250:mdna:41]

[0000950123-11-096966:mdna:40]
Cost of revenues decreased by 63% and 67% to $21.9 million and $38.9 million for the three and
six months ended September 30, 2011, compared to $59.4 million and $117.6 million for the three and
six months ended September 30, 2010. Gross margin was (5.5%) and (30.3%) for the three and six
months ended September 30, 2011, respectively, compared to 39.4% and 39.8% for the three and six
months ended September 30, 2010, respectively. The decrease in gross margin and cost of revenues in
the three and six months ended September 30, 2011 as compared to the same period in fiscal 2010 was
a result of lower sales due to the disruption in our relationship with Sinovel and unabsorbed fixed
overhead due to idle capacity. This is expected to improve in the future quarters as the wind
market in China recovers.

[0000950123-11-096966:mdna:41]
24

[0000950123-11-096966:mdna:42]
Based on the average Euro and Renminbi exchange rates for the second quarter of fiscal 2011,
cost of revenues denominated in these foreign currencies translated into U.S. dollars was $0.5
million higher compared to the translation of cost of revenues using the average exchange rates of
these currencies for the second quarter of fiscal 2010.

[0000950123-11-096966:mdna:43]
[same as prior period, unchanged from 0000950123-11-086250:mdna:44]

[0000950123-11-096966:mdna:44]
[same as prior period, unchanged from 0000950123-11-086250:mdna:45]

[0000950123-11-096966:mdna:45]
[same as prior period, unchanged from 0000950123-11-086250:mdna:46]

[0000950123-11-096966:mdna:46]
|  |  | Three months ended |  |  | Six months ended |  |
|  |  | September 30, |  |  | September 30, |  |
|  |  | 2011 |  |  | 2010 |  |  | 2011 |  |  | 2010 |  |
| R&D expenses per condensed consolidated statements of operations |  | $ | 7,276 |  |  | $ | 7,857 |  |  | $ | 15,411 |  |  | $ | 15,192 |  |
| R&D expenditures reclassified as cost of revenues |  |  | 3,263 |  |  |  | 2,510 |  |  |  | 7,303 |  |  |  | 5,879 |  |
| R&D expenditures offset by cost-sharing funding |  |  | 46 |  |  |  | 133 |  |  |  | 81 |  |  |  | 274 |  |
| Aggregated R&D expenses |  | $ | 10,585 |  |  | $ | 10,500 |  |  | $ | 22,795 |  |  | $ | 21,345 |  |

[0000950123-11-096966:mdna:47]
R&D expenses (exclusive of amounts classified as cost of revenues and amounts offset by
cost-sharing funding) decreased by 7% to $7.3 million from $7.9 million for the three months ended
September 30, 2011 and increased 1% to $15.4 million from $15.2 million for the six months ended
September 30, 2011. Lower R&D expenditures for the three months ended September 30, 2011 was
primarily due to the impact of our cost reduction activities. Higher R&D expenditures for the six
months ended September 30, 2011 was primarily due to increased spending in the first quarter to
support new product development in our Wind segment, partially offset by savings from cost
reduction activities in the second quarter of fiscal 2011. The increase in R&D expenditures
reclassified to costs of revenue was a result of increased efforts under license and development
contracts for wind turbine designs compared to the prior year. Aggregated R&D expenses, which
include amounts classified as cost of revenues and amounts offset by cost-sharing funding,
increased 1% and 7% to $10.6 million and $22.8 million, or 51% and 76% of revenues for the three
and six months ended September 30, 2011, respectively, compared to $10.5 million and $21.3 million,
or 11% of revenues, for each of the three and six months ended September 30, 2010, respectively.
Growth in R&D expenses is expected to moderate going forward as a result of the restructuring
actions undertaken in fiscal 2011.

[0000950123-11-096966:mdna:48]
[same as prior period, unchanged from 0000950123-11-086250:mdna:49]

[0000950123-11-096966:mdna:49]
[same as prior period, unchanged from 0000950123-11-086250:mdna:50]

[0000950123-11-096966:mdna:50]
SG&A expenses increased by 1% and 22% to $17.6 million and $39.6 million, or 84% and 132% of
revenues, for the three and six months ended September 30, 2011, respectively, from $17.3 million
and $32.5 million, or 18% and 17% of revenues, for each of the three and six months ended September
30, 2010, respectively. The increases in SG&A expenses were due primarily to increases in legal
fees associated with ongoing litigation as discussed in Part II, Item 1, “Legal Proceedings,” of
this Quarterly Report on Form 10-Q. During the three and six months ended September 30, 2011, we
incurred $3.3 million in legal fees related to Sinovel litigation. Higher legal expenses are
expected for the next several quarters as we expect to continue pursuing litigation against
Sinovel.

[0000950123-11-096966:mdna:51]
Write-off of advance payment

[0000950123-11-096966:mdna:52]
In October 2011, we terminated our previously planned acquisition of The Switch due to adverse
market conditions for a financing required to fund the acquisition. As a result, The Switch
retained a $20.6 million advance payment as a break-up fee, and we recorded a write-off of the
advance payment during the three months ended September 30, 2011.

[0000950123-11-096966:mdna:53]
[same as prior period, unchanged from 0000950123-11-086250:mdna:52]

[0000950123-11-096966:mdna:54]
We recorded amortization expense related to our core technology and know-how, trade names and
trademark intangible assets of $0.3 million and $0.6 million in the three and six months ended
September 30, 2011, respectively, compared to $0.4 million and $0.8 million in the three months
ended September 30, 2010. These intangible assets are primarily a result of our AMSC Windtec
acquisition.

[0000950123-11-096966:mdna:55]
Restructuring and impairments

[0000950123-11-096966:mdna:56]
We recorded restructuring and impairment charges of $4.3 million in the three and six months
ended September 30, 2011. These amounts consist primarily of employee severance and benefit costs
of $3.3 million related to the August 2011 restructuring plan, facility exit costs of $0.1 million
associated with portions of the leased space in Klagenfurt, Austria, and impairment charges of $0.9
million on long-lived assets for which there is no remaining future economic benefit as of
September 30, 2011.

[0000950123-11-096966:mdna:57]
[same as prior period, unchanged from 0000950123-11-086250:mdna:54]

[0000950123-11-096966:mdna:58]
Our operating (loss) income is summarized as follows (in thousands):

[0000950123-11-096966:mdna:59]
|  |  | Three months ended |  |  | Six months ended |  |
|  |  | September 30, |  |  | September 30, |  |
|  |  | 2011 |  |  | 2010 |  |  | 2011 |  |  | 2010 |  |
| Operating (loss) income: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Wind |  | $ | (16,336 | ) |  | $ | 32,655 |  |  | $ | (40,705 | ) |  | $ | 63,994 |  |
| Grid |  | $ | (7,645 | ) |  | $ | (15,213 | ) |  | $ | (18,197 | ) |  | $ | (26,998 | ) |
| Unallocated corporate expenses |  | $ | (27,144 | ) |  | $ | (4,362 | ) |  | $ | (30,549 | ) |  | $ | (7,836 | ) |
| Total |  | $ | (51,125 | ) |  | $ | 13,080 |  |  | $ | (89,451 | ) |  | $ | 29,160 |  |

[0000950123-11-096966:mdna:60]
Operating (loss) income for the Wind business unit decreased to an operating loss of
$16.3 million and $40.7 million in the three and six months ended September 30, 2011, respectively,
from an operating income of $32.7 million and $64.0 million in the three and six months ended
September 30, 2010, respectively. The decrease in Wind business unit operating income was primarily
due to the disruption in our relationship with Sinovel, as described above.

[0000950123-11-096966:mdna:61]
Operating (loss) income for the Grid business unit decreased to an operating loss of $7.6
million and $18.2 million in the three and six months ended September 30, 2011, respectively, from
an operating loss of $15.2 million and $27.0 million in the three and six months ended September
30, 2010, respectively. The decrease in Grid business unit operating loss was primarily due to
lower operating expenses as a result of the reductions in force, reduced discretionary spending and
changes to corporate allocations, partially offset by reduced DVAR revenues.

[0000950123-11-096966:mdna:62]
Unallocated corporate expenses primarily consist of the write-off of an advance payment to The
Switch of $20.6 million and restructuring and impairment charges of $4.3 million for the three and
six months ended September 30, 2011 and stock-based compensation expense of $2.1 million and $5.6
million for the three and six months ended September 30, 2011, respectively. Unallocated corporate
expenses primarily consist of stock-based compensation expense of $4.3 million and $7.8 million for
the three and six months ended September 30, 2010, respectively.

[0000950123-11-096966:mdna:63]
[same as prior period, unchanged from 0000950123-11-086250:mdna:60]

[0000950123-11-096966:mdna:64]
Interest income, net, was less than $0.1 million and $0.2 million in the three and six months
ended September 30, 2011, respectively, compared to $0.2 million and $0.4 million in the three and
six months ended September 30, 2010, respectively. The decreases are due primarily to lower
interest-bearing cash balances.

[0000950123-11-096966:mdna:65]
[same as prior period, unchanged from 0000950123-11-086250:mdna:62]

[0000950123-11-096966:mdna:66]
Other income, net, was $0.4 million and $0.9 million in the three and six months ended
September 30, 2011, respectively, compared to $2.4 million and $2.6 million for the three and six
months ended September 30, 2010. The decrease

[0000950123-11-096966:mdna:67]
in other income, net primarily relates to a decrease
in foreign currency gains of $1.8 million and $0.9 million, respectively, and an increase in losses
on minority interest investments of $0.3 million and $0.7 million, respectively.

[0000950123-11-096966:mdna:68]
[same as prior period, unchanged from 0000950123-11-086250:mdna:64]

[0000950123-11-096966:mdna:69]
In the three and six months ended September 30, 2011, we recorded income tax expense of $0.9
million and $1.1 million, respectively, compared to $7.9 million and $15.1 million in the three and
six months ended September 30, 2010, respectively. Income tax expense decreased primarily due to
the pretax losses in the three and six months ended September 30, 2011 and a full valuation
allowance against our deferred tax assets. We have provided a valuation allowance against all
deferred tax assets as of September 30, 2011, as it is more likely than not that our deferred tax
assets are not currently realizable due to the net operating losses incurred since our inception in
the U.S. and the significant write-offs in certain foreign jurisdictions in the fiscal year ended
March 31, 2011.

[0000950123-11-096966:mdna:70]
[same as prior period, unchanged from 0000950123-11-086250:mdna:66]

[0000950123-11-096966:mdna:71]
[same as prior period, unchanged from 0000950123-11-086250:mdna:67]

[0000950123-11-096966:mdna:72]
We define non-GAAP net (loss) income as net (loss) income before amortization of
acquisition-related intangibles, restructuring and impairments, stock-based compensation, other
unusual charges and any tax effects related to these items. We believe non-GAAP net (loss) income
assists management and investors in comparing our performance across reporting periods on a
consistent basis by excluding these non-cash or non-recurring charges that we do not believe are
indicative of our core operating performance. We also regard non-GAAP net (loss) income as a useful
measure of operating performance which more closely aligns net (loss) income with cash used
in/provided by continuing operations. In addition, we use non-GAAP net (loss) income as a factor in
evaluating management’s performance when determining incentive compensation and to evaluate the
effectiveness of our business strategies. A reconciliation of non-GAAP to GAAP net (loss) income is
set forth in the table below (in thousands, except per share data):

[0000950123-11-096966:mdna:73]
|  |  | Three months ended |  |  | Six months ended |  |
|  |  | September 30, |  |  | September 30, |  |
|  |  | 2011 |  |  | 2010 |  |  | 2011 |  |  | 2010 |  |
| Net (loss) income |  | $ | (51,709 | ) |  | $ | 7,839 |  |  | $ | (89,388 | ) |  | $ | 17,008 |  |
| Write-off of advance payment |  |  | 20,551 |  |  |  | — |  |  |  | 20,551 |  |  |  | — |  |
| Stock-based compensation |  |  | 2,113 |  |  |  | 4,326 |  |  |  | 5,579 |  |  |  | 7,825 |  |
| Restructuring and impairment charges |  |  | 4,301 |  |  |  | — |  |  |  | 4,301 |  |  |  | — |  |
| Executive severance |  |  | — |  |  |  | — |  |  |  | 2,066 |  |  |  | — |  |
| Sinovel litigation |  |  | 3,334 |  |  |  | — |  |  |  | 3,334 |  |  |  | — |  |
| Provision for excess and obsolete inventory |  |  | — |  |  |  | 580 |  |  |  | — |  |  |  | 580 |  |
| Adverse purchase commitment (recoveries) losses, net |  |  | (904 | ) |  |  | — |  |  |  | 167 |  |  |  | — |  |
| Margin on zero cost-basis inventory |  |  | (127 | ) |  |  | — |  |  |  | (127 | ) |  |  | — |  |
| Value-added tax write-off |  |  | — |  |  |  | 221 |  |  |  | — |  |  |  | 432 |  |
| Amortization of acquisition-related intangibles |  |  | 300 |  |  |  | 374 |  |  |  | 604 |  |  |  | 762 |  |
| Tax effects |  |  | — |  |  |  | (84 | ) |  |  | — |  |  |  | (167 | ) |
| Non-GAAP net (loss) income |  | $ | (22,141 | ) |  | $ | 13,256 |  |  | $ | (52,913 | ) |  | $ | 26,440 |  |
| Non-GAAP (loss) earnings per share |  | $ | (0.44 | ) |  | $ | 0.29 |  |  | $ | (1.04 | ) |  | $ | 0.57 |  |
| Weighted average shares outstanding * |  |  | 50,876 |  |  |  | 46,217 |  |  |  | 50,716 |  |  |  | 46,099 |  |

[0000950123-11-096966:mdna:74]
[same as prior period, unchanged from 0000950123-11-086250:mdna:71]

[0000950123-11-096966:mdna:75]
We incurred non-GAAP net losses of ($22.1) million and ($52.9) million, or ($0.44) and
($1.04) per share, for the three months and six months ended September 30, 2011, compared to
non-GAAP net income of $13.3 million and $26.4 or $0.29 and $0.57 per diluted share, for the three
and six months ended September 30, 2010. The decrease in non-GAAP net income was driven primarily
by a decrease in net income as described above, partially offset by the write-off of the advance
payment to The Switch, Sinovel litigation expenses and restructuring and impairment charges.

[0000950123-11-096966:mdna:76]
[same as prior period, unchanged from 0000950123-11-086250:mdna:73]

[0000950123-11-096966:mdna:77]
At September 30, 2011, we had cash, cash equivalents, marketable securities and restricted
cash of $108.3 million, compared to $245.5 million at March 31, 2011, a decrease of $137.3 million.
Our cash and cash equivalents, marketable securities and restricted cash are summarized as follows
(in thousands):

[0000950123-11-096966:mdna:78]
|  |  | September 30, |  |  | March 31, |  |
|  |  | 2011 |  |  | 2011 |  |
| Cash and cash equivalents |  | $ | 93,511 |  |  | $ | 123,783 |  |
| Marketable securities |  |  | 5,378 |  |  |  | 116,126 |  |
| Restricted cash |  |  | 9,374 |  |  |  | 5,566 |  |
| Total cash, cash equivalents, marketable securities and restricted cash |  | $ | 108,263 |  |  | $ | 245,475 |  |

[0000950123-11-096966:mdna:79]
For the six months ended September 30, 2011, net cash used in operating activities was
$106.9 million compared to $1.9 million in the six months ended September 30, 2010. The increase in
net cash used in operations is due primarily to a decrease in net income of $106.4 million and an
increase in cash used for working capital of $23.2 million, partially offset by the write-off of
the advance payment to The Switch of $20.6 million.

[0000950123-11-096966:mdna:80]
For the six months ended September 30, 2011, net cash provided by investing activities was
$76.2 million compared to net cash used in investing activities of $37.3 million in the six months
ended September 30, 2010. The increase in net cash provided by investing activities for the six
months ended September 30, 2011 was driven primarily by an increase in net maturities and sales of
marketable securities of $120.9 million, a decrease in capital expenditures of $10.6 million and
decrease in purchased minority investments of $6.2 million, partially offset by the $20.6 million
advance payment to The Switch and an increase in restricted cash of $4.0 million.

[0000950123-11-096966:mdna:81]
For the six months ended September 30, 2011, net cash used in financing activities was $0.1
million compared to cash provided by financing activities of $1.6 million in the six months ended
September 30, 2010. The decrease in net cash provided by financing activities is primarily due to a
decrease in proceeds from exercise of employee stock options and ESPP of $1.4 million and payments
in lieu of issuance of common stock for payroll taxes of $0.3 million.

[0000950123-11-096966:mdna:82]
As of September 30, 2011, we had seven performance bonds in support of customer contracts to
guarantee supply of core components and software. The total value of the outstanding performance
bonds is $1.8 million with various expiration dates through March 2014. In the event that the
payment is made in accordance with the requirements of any of these performance bonds, we would
record the payment as an offset to revenue.

[0000950123-11-096966:mdna:83]
At September 30, 2011 and March 31, 2011, we had $8.3 million and $5.6 million, respectively,
of restricted cash included in current assets. At September 30, 2011, we had $1.1 million of
restricted cash included in long-term assets. These amounts included in restricted cash represent
deposits to secure letters of credit for various supply contracts. These deposits are held in
interest bearing accounts. We had an additional $2.2 million in unsecured letters of credit, at
September 30, 2011 and March 31, 2011, also in support of various supply contracts.

[0000950123-11-096966:mdna:84]
We had unused, unsecured lines of credit consisting of RMB 17.6 million (approximately $2.7
million) in China and €1.6 million (approximately $2.2 million) in Austria as of September 30,
2011. During the three months ended September 30, 2011, our unsecured credit line with the Bank of
China expired and we repaid borrowings on lines of credit of $4.6 million and there were no
borrowings outstanding as of September 30, 2011.

[0000950123-11-096966:mdna:85]
Our business plan anticipates a substantial decline in revenues and a substantial use of cash
from operations in our fiscal year ending March 31, 2012, particularly in light of the difficult
and uncertain current economic environment particularly in China, the significant restructuring
actions undertaken and the slowdown in the Chinese wind power market, which has accounted for more
than two-thirds of our revenues in recent fiscal years. Our plan includes a significant
restructuring undertaken in August 2011, resulting in the elimination of approximately 150
positions worldwide. Since April 1, 2011, we have eliminated approximately 30% of our workforce
and we expect to reduce annualized expenses by approximately $30 million annually as a result of
these reductions. We plan to continue to closely monitor our expenses and if required, will further
reduce operating costs and capital spending to enhance liquidity. We believe that our available
cash, together with additional reductions in operating costs and capital expenditures as necessary
will be sufficient to fund our operations, capital expenditures and other cash requirements for at
least the next twelve months. Our long-term liquidity is dependent on our ability to profitably
grow our revenues or raise additional capital as required. If necessary, we may seek

[0000950123-11-096966:mdna:86]
financing
through public or private equity offerings, debt financings, or other financing alternatives.
However, there can be no assurance that financing will be available on acceptable terms or at all.

[0000950123-11-096966:mdna:87]
[same as prior period, unchanged from 0000950123-11-086250:mdna:83]

[0000950123-11-096966:mdna:88]
On April 27, 2011, a putative shareholder derivative complaint was filed against us (as a
nominal defendant) and each of our current directors in Superior Court for the Commonwealth of
Massachusetts, Worcester County. The case is captioned Segel v. Yurek, et al., Docket No. 11-0787.
Between May 4, 2011 and June 17, 2011, four additional putative shareholder derivative complaints
were filed in the United States District Court for the District of Massachusetts against us and
certain of our directors and officers. The cases are captioned Weakley v. Yurek, et al., Docket
No. 1:11-cv-10784; Marlborough Family Revocable Trust v. Yurek, et al., Docket No. 1:11-cv-10825;
Connors v. Yurek, et al., Docket No. 1:11-cv-10910; and Hurd v. Yurek, et al., Docket No.
1:11-cv-11102. On June 1, 2011, the plaintiff in Marlborough Family Revocable Trust v. Yurek, et
al. moved to voluntarily dismiss its complaint and refiled its complaint in Superior Court for the
Commonwealth of Massachusetts, Middlesex County, on June 3, 2011. The case is now captioned
Marlborough Family Revocable Trust v. Yurek, et al., Docket No. 11-1961. The Superior Court in
Worcester County granted the plaintiff’s motion to transfer in Segel v. Yurek et al. to the
Superior Court for the Commonwealth of Massachusetts, Middlesex County on June 23, 2011, and that
matter is now captioned Segel v. Yurek et al., Docket No. 11-2269. On July 5, 2011, the Weakley,
Connors and Hurd actions were consolidated in United States District Court for the District of
Massachusetts. That matter is now captioned In re American Superconductor Corporation Derivative
Litigation, Docket No. 1:11-cv-10784. On June 1, 2011, the plaintiff in Marlborough Family
Revocable Trust v. Yurek, et al. moved to voluntarily dismiss its complaint and, on June 3, 2011,
refiled its complaint in Superior Court for the Commonwealth of Massachusetts, Middlesex County.
The Superior Court in Worcester County granted the plaintiff’s motion to transfer in Segel v. Yurek
et al. to the Superior Court for the Commonwealth of Massachusetts, Middlesex County on June 23,
2011. On September 7, 2011, the Marlborough and Segel actions were consolidated in Superior Court
for the Commonwealth of Massachusetts, Middlesex County. The case is now captioned Marlborough
Family Revocable Trust v. Yurek, et al., Docket No. 11-1961. The allegations of the derivative
complaints mirror the allegations made in the putative class action complaints described above.
The plaintiffs purport to assert claims against the director defendants for breach of fiduciary
duty, abuse of control, gross mismanagement and corporate waste. The plaintiffs seek unspecified
damages on behalf of us, as well as an award of costs and expenses, including attorney’s fees.

[0000950123-11-096966:mdna:89]
If a matter is both probable to result in liability and the amounts of loss can be reasonably
estimated, we estimate and disclose the possible loss or range of loss. With respect to the above
referenced litigation matters, such an estimate cannot be made. There are numerous factors that
make it difficult to meaningfully estimate possible loss or range of loss at this stage of these
litigation matters, including that: the proceedings are in relatively early stages, there are
significant factual and legal issues to be resolved, information obtained or rulings made during
the lawsuits could affect the methodology for calculation of rescission and the related statutory
interest rate. In addition, with respect to claims where damages are the requested relief, no
amount of loss or damages has been specified. Therefore, we are unable at this time to estimate
possible losses. We believe that these litigations are without merit, and we intend to defend
these actions vigorously.

[0000950123-11-096966:mdna:90]
On September 13, 2011, we commenced a series of legal actions in China against Sinovel Wind
Group Co. Ltd. (“Sinovel”). Our Chinese subsidiary, Suzhou AMSC Superconductor Co. Ltd., filed a
claim for arbitration with the Beijing Arbitration Commission in accordance with the terms of our
supply contracts with Sinovel. The case is captioned (2011) Jin Zhong An Zi No. 0693. On March 31,
2011, Sinovel refused to accept contracted shipments of 1.5 megawatt (MW) and 3

[0000950123-11-096966:mdna:91]
29

[0000950123-11-096966:mdna:92]
MW wind turbine
core electrical components and spare parts that we were prepared to deliver. We allege that these
actions constitute material breaches of our contracts because Sinovel did not give us notice that
it intended to delay deliveries as required under the contracts. Moreover, we allege that Sinovel
has refused to pay past due amounts for prior shipments of core electrical components and spare parts. We are seeking compensation for past product
shipments (including interest) and monetary damages in the amount of approximately RMB
430 million ($67 million) due to Sinovel’s breaches of our contracts. We are also seeking specific
performance of our existing contracts as well as reimbursement of all costs and reasonable expenses
with respect to the arbitration. The value of the undelivered components under the
existing contracts, including the deliveries refused by Sinovel in March 2011, amounts to
approximately RMB 4.6 billion ($720 million).

[0000950123-11-096966:mdna:93]
On October 8, 2011, Sinovel filed with the Beijing Arbitration Commission an application under
the caption (2011) Jin Zhong An Zi No. 0693, for a counterclaim against the Company for breach of
the same contracts under which the Company filed its original arbitration claim. Sinovel claimed,
among other things, that the goods supplied by the Company do not conform to the standards
specified in the contracts and claimed damages in the amount of approximately RMB 370 millon ($58
million). On October 17, 2011, Sinovel filed with the Beijing Arbitration Commission a request for
change of counterclaim to increase its damage claim to approximately RMB 1 billion ($157 million).
Deducting the RMB 430 million ($67 million) claimed by the Company, the net amount of damages
claimed by Sinovel is approximately RMB 570 million ($89 million). We believe that Sinovel’s
claims are without merit and we intend to defend these actions vigorously. Since the proceedings in
this matter are in relatively early stages, we cannot reasonably estimate possible losses or range
of losses at this time.

[0000950123-11-096966:mdna:94]
We also submitted a civil action application to the Beijing No. 1 Intermediate People’s Court
under the caption (2011) Yi Zhong Min Chu Zi No. 15524, against Sinovel for software copyright
infringement on September 13, 2011. The application alleges Sinovel’s unauthorized use of portions
of our wind turbine control software source code developed for Sinovel’s 1.5MW wind turbines and
the binary code, or upper layer, of our software for the PM3000 power converters in 1.5MW wind
turbines. In July 2011, a former employee of our AMSC Windtec GmbH subsidiary was arrested in
Austria on charges of economic espionage and fraudulent manipulation of data. In September 2011,
the former employee pled guilty to the charges, and he is currently serving a prison sentence. As
a result of our internal investigation and a criminal investigation conducted by Austrian
authorities, we believe that this former employee was contracted by Sinovel through an intermediary
while employed by us and improperly obtained and transferred to Sinovel portions of our wind
turbine control software source code developed for Sinovel’s 1.5MW wind turbines. Moreover, we
believe the former employee illegally used source code to develop for Sinovel a software
modification to circumvent the encryption and remove technical protection measures on the PM3000
power converters in 1.5MW wind turbines in the field. We are seeking a cease and desist order with
respect to the unauthorized copying, installation and use of our software, monetary damages of
approximately RMB 38 million ($6 million) for our economic losses and reimbursement of all costs
and reasonable expenses. The court has accepted the case, which was necessary in order for the
case to proceed.

[0000950123-11-096966:mdna:95]
We submitted a civil action application to the Beijing Higher People’s Court against Sinovel
and certain of its employees for trade secret infringement on September 13 2011 under the caption
(2011) Gao Min Chu Zi No. 4193. The application alleges the defendants’ unauthorized use of
portions of our wind turbine control software source code developed for Sinovel’s 1.5MW wind
turbines as described above with respect to the Copyright Action. We are seeking monetary damages
of RMB 2.9 billion ($453 million) for the trade secret infringement as well as reimbursement of all
costs and reasonable expenses. The court has accepted the case, which was necessary in order for
the case to proceed.

[0000950123-11-096966:mdna:96]
On September 16, 2011, we filed a civil copyright infringement complaint in the Hainan
Province No. 1 Intermediate People’s Court against Dalian Guotong Electric Co. Ltd. (“Guotong”), a
supplier of power converter products to Sinovel, and Huaneng Hainan Power, Inc., a wind farm
operator that has purchased Sinovel wind turbines containing Goutong power converter products. The
case is captioned (2011) Hainan Yi Zhong Min Chu Zi No. 62. The application alleges that our
PM1000 converters in certain Sinovel wind turbines have been replaced by converters produced by
Guotong. Because the Guotong converters are being used in wind turbines containing our wind turbine
control software, we believe that our copyrighted software is being infringed. We are seeking a
cease and desist order with respect to the unauthorized use of our software, monetary damages of
RMB 1.2 million ($0.2 million) for our economic losses (with respect to Guotong only) and
reimbursement of all costs and reasonable expenses. The court has accepted the case, which was
necessary in order for the case to proceed. In addition, upon the request of the defendant Huaneng
Hainan Power, Inc, Sinovel has been added by the court to this case as a defendant.

[0000950123-11-096966:mdna:97]
Ghodawat Energy Pvt Ltd (“Ghodawat”), a company registered in India carrying on the business
of wind power development, lodged a Request for Arbitration with the Secretariat of the ICC
International Court of Arbitration on May 12, 2011 and named AMSC Windtec GmbH (“AMSC Windtec”) as
the Respondent. Under the Request for Arbitration, Ghodawat alleges that AMSC Windtec breached an
agreement dated March 19, 2008 pursuant to which AMSC Windtec
granted a license to Ghodawat to manufacture, use, sell, market, erect, commission and
maintain certain wind turbines using its technical information and wind turbine design (the
“License Agreement”). Under the Request for Arbitration, Ghodawat’s claims in this arbitration
amount to approximately €18 million ($24 million). AMSC Windtec filed an Answer to Request for
Arbitration and Counterclaim (“Answer and Counterclaim”), in which AMSC Windtec denied Ghodawat’s
claims in their entirety. AMSC Windtec has also submitted counterclaims under the License
Agreement against Ghodawat in the amount of approximately €6 million ($9 million). Ghodawat has
filed a Reply to Answer to Request for Arbitration and Counterclaim in which it denies AMSC
Windtec’s counterclaims. The arbitration proceedings are currently ongoing. We have recorded a
loss contingency based on our assessment of probable losses on this claim, however this amount is
immaterial to our consolidated financial statements.

[0000950123-11-096966:mdna:98]
[same as prior period, unchanged from 0000950123-11-086250:mdna:93]

[0000950123-11-096966:mdna:99]
[same as prior period, unchanged from 0000950123-11-086250:mdna:94]

[0000950123-11-096966:mdna:100]
[same as prior period, unchanged from 0000950123-11-086250:mdna:95]

[0000950123-11-096966:mdna:101]
[same as prior period, unchanged from 0000950123-11-086250:mdna:96]

[0000950123-11-096966:mdna:102]
[same as prior period, unchanged from 0000950123-11-086250:mdna:97]

[0000950123-11-096966:mdna:103]
In January 2010, we adopted Accounting Standards Update (ASU) No. 2010-06, Fair Value
Measurements and Disclosures (Topic 820): Improving Disclosures about Fair Value Measurements. This
standard amends the disclosure guidance with respect to fair value measurements for both interim
and annual reporting periods. Specifically, this standard requires new disclosures for significant
transfers of assets or liabilities between Level 1 and Level 2 in the fair value hierarchy;
separate disclosures for purchases, sales, issuance and settlements of Level 3 fair value items on
a gross, rather than net basis; and more robust disclosure of the valuation techniques and inputs
used to measure Level 2 and Level 3 assets and liabilities. We have included these new disclosures,
as applicable, in Note 3, “Marketable Securities and Fair Value Disclosures,” of our consolidated
financial statements.

[0000950123-11-096966:mdna:104]
In December 2010, the FASB issued Accounting Standards Update (ASU) No. 2010-29, Business
Combinations (Topic 805), Disclosure of Supplementary Pro forma Information for Business
Combinations a consensus of the FASB Emerging Issues Task Force (ASC 2010-29). This amendment
clarifies the periods for which pro forma financial information is presented. The disclosures
include pro forma revenue and earnings of the combined entity for the current reporting period as
though the acquisition date for all business combinations that occurred during the year had been as
of the beginning of the annual reporting period. If comparative financial statements are presented,
the pro forma revenue and earnings of the combined entity for the comparable prior reporting period
should be reported as though the acquisition date for all business combinations that occurred
during the current year had been as of the beginning of the comparable prior annual reporting
period. ASU 2010-29 is effective prospectively for business combinations that occur on or after
the beginning of the first annual reporting period beginning after December 15, 2010. We do not
expect the adoption of ASU 2011-04 to have a material impact on our consolidated results of
operations, financial condition, or cash flows.

[0000950123-11-096966:mdna:105]
In June 2011, the FASB issued Accounting Standards Update (ASU) No. 2011-05, Comprehensive
Income (Topic 220): Presentation of Comprehensive Income. ASU 2011-05 requires entities to present
net income and other comprehensive income in either a single continuous statement or in two
separate, but consecutive, statements of net income and other comprehensive income. ASU 2011-05 is
effective for fiscal years and interim periods beginning after December 15, 2011. We do not expect
the adoption of ASU 2011-04 to have a material impact on our consolidated results of operations,
financial condition, or cash flows.
