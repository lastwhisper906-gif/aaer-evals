# AMSC notes — 0000950123-11-096966


## amsc:BusinessCombinationsPolicyPolicyTextBlock

[0000950123-11-096966:notes:1]
In December 2010, the FASB issued Accounting Standards Update (ASU) No. 2010-29, Business Combinations (Topic 805), Disclosure of Supplementary Pro forma Information for Business Combinations a consensus of the FASB Emerging Issues Task Force (ASC 2010-29). This amendment clarifies the periods for which pro forma financial information is presented. The disclosures include pro forma revenue and earnings of the combined entity for the current reporting period as though the acquisition date for all business combinations that occurred during the year had been as of the beginning of the annual reporting period. If comparative financial statements are presented, the pro forma revenue and earnings of the combined entity for the comparable prior reporting period should be reported as though the acquisition date for all business combinations that occurred during the current year had been as of the beginning of the comparable prior annual reporting period. ASU 2010-29 is effective prospectively for business combinations that occur on or after the beginning of the first annual reporting period beginning after December 15, 2010. The Company does not expect the adoption of ASU 2011-04 to have a material impact on the Company's consolidated results of operations, financial condition, or cash flows.


## amsc:ComprehensiveIncomePolicyPolicyTextBlock

[0000950123-11-096966:notes:2]
In June 2011, the FASB issued Accounting Standards Update (ASU) No. 2011-05, Comprehensive Income (Topic 220): Presentation of Comprehensive Income. ASU 2011-05 requires entities to present net income and other comprehensive income in either a single continuous statement or in two separate, but consecutive, statements of net income and other comprehensive income. ASU 2011-05 is effective for fiscal years and interim periods beginning after December 15, 2011. The Company does not expect the adoption of ASU 2011-04 to have a material impact on the Company's consolidated results of operations, financial condition, or cash flows.


## amsc:FairValueOfFinancialInstrumentsPolicyPolicyTextBlock

[0000950123-11-096966:notes:3]
In January 2010, the Company adopted Accounting Standards Update (ASU) No. 2010-06, Fair Value Measurements and Disclosures (Topic 820): Improving Disclosures about Fair Value Measurements. This standard amends the disclosure guidance with respect to fair value measurements for both interim and annual reporting periods. Specifically, this standard requires new disclosures for significant transfers of assets or liabilities between Level 1 and Level 2 in the fair value hierarchy; separate disclosures for purchases, sales, issuance and settlements of Level 3 fair value items on a gross, rather than net basis; and more robust disclosure of the valuation techniques and inputs used to measure Level 2 and Level 3 assets and liabilities. The Company has included these new disclosures, as applicable, in Note 3, "Marketable Securities and Fair Value Disclosures," of the consolidated financial statements.


## amsc:RecentAccountingPronouncementsTextBlock

[0000950123-11-096966:notes:4]
13. Recent Accounting Pronouncements


## amsc:RestructuringImpairmentAndOtherActivitiesDisclosureTextBlock

[0000950123-11-096966:notes:5]
9 .        Restructuring and Impairments

[0000950123-11-096966:notes:6]
The Company accounts for charges resulting from operational restructuring actions in accordance with ASC Topic 420, Exit or Disposal Cost Obligations ("ASC 420") and ASC Topic 712, Compensation—Nonretirement Postemployment Benefits ("ASC 712"). In accounting for these obligations, the Company is required to make assumptions related to the amounts of employee severance, benefits, and related costs and to the time period over which leased facilities will remain vacant, sublease terms, sublease rates and discount rates. Estimates and assumptions are based on the best information available at the time the obligation arises. These estimates are reviewed and revised as facts and circumstances dictate; changes in these estimates could have a material effect on the amount accrued on the consolidated balance sheet.

[0000950123-11-096966:notes:7]
The Company initiated a restructuring plan in August 2011 (the "2011 Plan") to reorganize global operations, streamline various functions of the business, and reduce its global workforce to better reflect the demand for its products. The 2011 Plan resulted in a headcount reduction of approximately 150 employees. From April 1, 2011 through the date of this filing, the Company has reduced its global workforce by approximately 30%, which is expected to reduce expenses by approximately $30 million annually. During the three months ended September 30, 2011, the Company incurred costs associated with the workforce reduction which include employee separation costs consisting of severance pay, outplacement services, medical benefits, and other related benefits for the Company's workforce. As a result, the Company recorded employee severance and benefit costs of $3.3 million. These charges are expected to be paid through fiscal 2012.

[0000950123-11-096966:notes:8]
In addition, during the three months ended September 30, 2011, the Company consolidated certain of its business operations to reduce overall facility costs. The consolidation plan entailed vacating approximately 8,937 square feet of occupied space in Klagenfurt, Austria. This facility closure was accounted for in accordance with ASC 420, pursuant to which the Company recorded a liability equal to the fair value of the remaining lease payments as of the cease-use date. Fair value was determined based upon the discounted present value of remaining lease rentals (using a discount rate of 10.1%) for the space no longer occupied, considering future estimated potential sublease income. As a result, the Company recorded facility exit costs of $0.1 million related to the remaining lease commitment on the leased space. These charges are expected to be paid through fiscal 2012. All  restructuring charges discussed above are included within restructuring and impairments in the Company's unaudited condensed consolidated statements of operations.

[0000950123-11-096966:notes:9]
The following table presents the restructuring charges and cash payments (in thousands):

[0000950123-11-096966:notes:10]
|  | Severance pay and benefits | Facility exit costs | Total |
| Accrued restructuring balance at April 1, 2011 | $ - | $ - | $ - |
| Charges to operations | 3,256 | 127 | 3,383 |
| Cash payments | (1,209) | - | (1,209) |
| Accrued restructuring balance at September 30, 2011 | $ 2,047 | $ 127 | $ 2,174 |

[0000950123-11-096966:notes:11]
In addition, the Company recorded impairment charges of $0.9 million on long-lived assets for which there is no remaining future economic benefit as of September 30, 2011.


## amsc:ScheduleOfAccountsReceivableTextBlock

[0000950123-11-096966:notes:12]
|  | September 30,2011 | March 31,2011 |
| Accounts receivable (billed) | $ 15,398 | $ 10,938 |
| Accounts receivable (unbilled) | 3,054 | 5,004 |
| Less: Allowance for doubtful accounts | (302) | (683 ) |
| Accounts receivable, net | $ 18,150 | $ 15,259 |


## amsc:ScheduleOfBusinessSegmentAssetsTextBlock

[0000950123-11-096966:notes:13]
|  | September 30,2011 | March 31,2011 |
| Wind | $ 113,092 | $ 145,464 |
| Grid | 72,303 | 67,081 |
| Corporate assets | 140,333 | 228,664 |
| Total | $ 325,728 | $ 441,209 |


## amsc:ScheduleOfBusinessSegmentOperatingResultsTextBlock

[0000950123-11-096966:notes:14]
|  | Three months ended | Six months ended |  |
| September 30, | September 30, |  |
|  | 2011 | 2010 | 2011 | 2010 |  |
| Revenues: |  |  |  |  |  |
| Wind | $13,449 | $89,316 | $17,712 | $172,323 |  |
| Grid | 7,351 | 8,757 | 12,146 | 22,960 |  |
| Total | $20,800 | $98,073 | $29,858 | $195,283 |  |
|  | Three months ended | Six months ended |  |
| September 30, | September 30, |  |
|  | 2011 | 2010 | 2011 | 2010 |  |
| Operating (loss) income: |  |  |  |  |  |
| Wind | ($16,336) | $32,655 | ($40,705) | $63,994 |  |
| Grid | ($7,645) | ($15,213) | ($18,197) | ($26,998) |  |
| Unallocated corporate expenses | ($27,144) | ($4,362) | ($30,549) | ($7,836) |  |
| Total | ($51,125) | $13,080 | ($89,451) | $29,160 |  |


## amsc:ScheduleOfEarningsPerShareBasicAndDilutedTextBlock

[0000950123-11-096966:notes:15]
|  |  | Three months ended September 30, | Six months ended September 30, |
|  |  | 2011 | 2010 | 2011 | 2010 |
| Numerator: |  |  |  |  |
|  | Net (loss) income | $ (51,709) | $ 7,839 | $ (89,388) | $ 17,008 |
| Denominator: |  |  |  |  |
|  | Weighted-average shares of common stock outstanding | 51,232 | 45,694 | 51,090 | 45,597 |
|  | Weighted-average shares subject to repurchase | (356) | (212) | (374) | (234) |
| Shares used in per-share calculation ― basic | 50,876 | 45,482 | 50,716 | 45,363 |
|  | Dilutive effect of employee equity incentive plans | - | 735 | - | 736 |
| Shares used in per-share calculation ― diluted | 50,876 | 46,217 | 50,716 | 46,099 |
| Net (loss) income per share ― basic | $ (1.02) | $ 0.17 | $ (1.76) | $ 0.37 |
| Net (loss) income per share ― diluted | $ (1.02) | $ 0.17 | $ (1.76) | $ 0.37 |


## amsc:ScheduleOfInventoryCurrentTableTextBlock

[0000950123-11-096966:notes:16]
|  | September 30,2011 | March 31,2011 |
| Raw materials | $ 18,683 | $ 17,100 |
| Work-in-process | 3,711 | 2,432 |
| Finished goods | 6,738 | 3,915 |
| Deferred program costs | 2,152 | 2,381 |
| Net inventory | $ 31,284 | $ 25,828 |


## amsc:ScheduleOfProductWarrantyLiabilityTableTextBlock

[0000950123-11-096966:notes:17]
|  | Three months endedSeptember 30, | Six months endedSeptember 30, |
|  |  | 2011 | 2010 | 2011 | 2010 |
|  | Balance at beginning of period | $ 7,334 | $ 6,375 | $7,907 | $6,431 |
|  | Change in accruals for warranties during the period | (69) | 2,020 | (474) | 4,332 |
|  | Settlements during the period | (210) | (1,021) | (378) | (3,389) |
|  | Balance at end of period | $ 7,055 | $ 7,374 | $ 7,055 | $7,374 |


## amsc:ScheduleOfRevenueByMajorCustomersByReportingSegmentsTableTextBlock

[0000950123-11-096966:notes:18]
|  | Three months endedSeptember 30, | Six months endedSeptember 30, |
|  | 2011 | 2010 | 2011 | 2010 |
| Inox Wind, Ltd. | 24% | <10% | 17% | <10% |
| Doosan Heavy Industries & Construction Co Ltd. | 17% | <10% | 16% | <10% |
| Dongfang Electric Machinery Co. | 11% | — % | <10% | — % |
| Sinovel Wind Co., Ltd | — % | 82% | — % | 77% |


## amsc:ScheduleOfStockBasedCompensationExpensesIncludedInConsolidatedStatementOfIncomeTextBlock

[0000950123-11-096966:notes:19]
|  | Three months endedSeptember 30, | Six months endedSeptember 30, |
|  | 2011 | 2010 | 2011 | 2010 |
| Cost of revenues | $ 440 | $ 452 | $ 769 | $ 835 |
| Research and development | 665 | 690 | 1,325 | 1,159 |
| Selling, general and administrative | 1,008 | 3,286 | 3,485 | 6,012 |
| Total | $ 2,113 | $ 4,428 | $ 5,579 | $ 8,006 |


## amsc:ScheduleOfWeightedAverageAssumptionsUsedInBlackScholesValuationModelForStockOptionsGrantedTextBlock

[0000950123-11-096966:notes:20]
|  | Three months endedSeptember 30, | Six months endedSeptember 30, |  |
|  | 2011 | 2010 | 2011 | 2010 |  |
| Expected volatility | 77.6% | 61.5% | 69.3% | 65.6% |  |
| Risk-free interest rate | 1.2% | 1.6% | 1.8% | 2.1% |  |
| Expected life (years) | 5.9 | 6.2 | 5.9 | 6.2 |  |
| Dividend yield | None | None | None | None |  |


## amsc:SubsequentEventsTextBlock

[0000950123-11-096966:notes:21]
14.     Subsequent Events

[0000950123-11-096966:notes:22]
The Company has performed an evaluation of subsequent events through the time of filing this Quarterly Report on Form 10-Q with the SEC, and has determined that there are no such events that are required to be disclosed.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000950123-11-096966:notes:23]
10.     Commitments and Contingencies

[0000950123-11-096966:notes:24]
Commitments

[0000950123-11-096966:notes:25]
The Company periodically enters into non-cancelable purchase contracts in order to ensure the availability of materials to support production of its products. Purchase commitments represent enforceable and legally binding agreements with suppliers to purchase goods or services. Any commitments for products ordered but not yet received is included as purchase commitments in its contractual obligations table. The Company periodically assesses the need to provide for impairment on these purchase contracts and record a loss on purchase commitments when required. As of September 30, 2011, the Company has $34.5 million of adverse purchase commitments in excess of its estimated future demand from certain of its customers in China, which the Company has recorded as a liability. The Company recorded adverse purchase commitment recoveries of $0.9 million and losses of $0.2 million during the three and six months ended September 30, 2011, respectively. Adverse purchase commitment recoveries in the three months ended September 30, 2011 are as a result of reductions in commitments to purchase materials due to renegotiations with certain suppliers and are recorded against cost of revenues.

[0000950123-11-096966:notes:26]
Contingencies

[0000950123-11-096966:notes:27]
From time to time, the Company is involved in legal and administrative proceedings and claims of various types. The Company records a liability in its consolidated financial statements for these matters when a loss is known or considered probable and the amount can be reasonably estimated. The Company reviews these estimates each accounting period as additional information is known and adjusts the loss provision when appropriate. If a matter is both probable to result in liability and the amounts of loss can be reasonably estimated, the Company estimates and discloses the possible loss or range of loss. If the loss is not probable or cannot be reasonably estimated, a liability is not recorded in its consolidated financial statements.

[0000950123-11-096966:notes:28]
Between April 6, 2011 and April 29, 2011, six putative securities class action complaints were filed against the Company and two of its officers in the United States District Court for the District of Massachusetts. On May 12, 2011, an additional complaint was filed against the Company, its officers and directors, and the underwriters who participated in its November 12, 2010 securities offering. On June 7, 2011, the United States District Court for the District of Massachusetts consolidated these actions under the caption Lenartz v. American Superconductor Corporation, et al. Docket No. 1:11-cv-10582-WGY. On June 16, 2011, the court appointed the law firm Robbins Geller Rudman & Dowd LLP as Lead Counsel and the Plumbers and Pipefitters National Pension Fund as Lead Plaintiff. On August 31, 2011, the Lead Plaintiff filed a consolidated amended complaint against the Company, its officers and directors, and the underwriters who participated in its November 12, 2010 securities offering, asserting claims under sections 10(b) and 20(a) of the Securities Exchange Act of 1934 and Rule 10b-5 promulgated under the Securities Exchange Act of 1934, as well as under sections 11, 12(a)(2) and 15 of the Securities Act of 1933. The complaint alleges that during the relevant class period, the Company and its officers omitted to state material facts and made materially false and misleading statements relating to, among other things, its projected and recognized revenues and earnings, as well as its relationship with Sinovel Wind Group Co., Ltd. that artificially inflated the value of its stock price. The complaint further alleges that the Company's November 12, 2010 securities offering contained untrue statements of material facts and omitted to state material facts required to be stated therein. The plaintiffs seek unspecified damages, rescindment of its November 12, 2010 securities offering, and an award of costs and expenses, including attorney's fees.

[0000950123-11-096966:notes:29]
On April 27, 2011, a putative shareholder derivative complaint was filed against the Company (as a nominal defendant) and each of its current directors in Superior Court for the Commonwealth of Massachusetts, Worcester County.  The case is captioned Segel v. Yurek, et al., Docket No. 11-0787.  Between May 4, 2011 and June 17, 2011, four additional putative shareholder derivative complaints were filed in the United States District Court for the District of Massachusetts against the Company and certain of the its directors and officers.  The cases are captioned Weakley v. Yurek, et al., Docket No. 1:11-cv-10784; Marlborough Family Revocable Trust v. Yurek, et al., Docket No. 1:11-cv-10825; Connors v. Yurek, et al., Docket No. 1:11-cv-10910; and Hurd v. Yurek, et al., Docket No. 1:11-cv-11102.  On June 1, 2011, the plaintiff in Marlborough Family Revocable Trust v. Yurek, et al. moved to voluntarily dismiss its complaint and refiled its complaint in Superior Court for the Commonwealth of Massachusetts, Middlesex County, on June 3, 2011.  The case is now captioned Marlborough Family Revocable Trust v. Yurek, et al., Docket No. 11-1961.  The Superior Court in Worcester County granted the plaintiff's motion to transfer in Segel v. Yurek et al. to the Superior Court for the Commonwealth of Massachusetts, Middlesex County on June 23, 2011, and that matter is now captioned Segel v. Yurek et al., Docket No. 11-2269.   On July 5, 2011, the Weakley, Connors and Hurd actions were consolidated in United States District Court for the District of Massachusetts.   That matter is now captioned In re American Superconductor Corporation Derivative Litigation, Docket No. 1:11-cv-10784.  On June 1, 2011, the plaintiff in Marlborough Family Revocable Trust v. Yurek, et al. moved to voluntarily dismiss its complaint and, on June 3, 2011, refiled its complaint in Superior Court for the Commonwealth of Massachusetts, Middlesex County.  The Superior Court in Worcester County granted the plaintiff's motion to transfer in Segel v. Yurek et al. to the Superior Court for the Commonwealth of Massachusetts, Middlesex County on June 23, 2011.   On September 7, 2011, the Marlborough and Segel actions were consolidated in Superior Court for the Commonwealth of Massachusetts, Middlesex County.  The case is now captioned Marlborough Family Revocable Trust v. Yurek, et al., Docket No. 11-1961.  The allegations of the derivative complaints mirror the allegations made in the putative class action complaints described above.  The plaintiffs purport to assert claims against the director defendants for breach of fiduciary duty, abuse of control, gross mismanagement and corporate waste.  The plaintiffs seek unspecified damages on behalf of the Company, as well as an award of costs and expenses, including attorney's fees.

[0000950123-11-096966:notes:30]
If a matter is both probable to result in liability and the amounts of loss can be reasonably estimated, the Company estimates and discloses the possible loss or range of loss. With respect to the above referenced litigation matters, such an estimate cannot be made. There are numerous factors that make it difficult to meaningfully estimate possible loss or range of loss at this stage of these litigation matters, including that: the proceedings are in relatively early stages, there are significant factual and legal issues to be resolved, information obtained or rulings made during the lawsuits could affect the methodology for calculation of rescission and the related statutory interest rate. In addition, with respect to claims where damages are the requested relief, no amount of loss or damages has been specified. Therefore, the Company is unable at this time to estimate possible losses. The Company believes that these litigations are without merit, and it intends to defend these actions vigorously.

[0000950123-11-096966:notes:31]
On September 13, 2011, the Company commenced a series of legal actions in China against Sinovel Wind Group Co. Ltd. ("Sinovel"). The Company's Chinese subsidiary, Suzhou AMSC Superconductor Co. Ltd., filed a claim for arbitration with the Beijing Arbitration Commission in accordance with the terms of the Company's supply contracts with Sinovel. The case is captioned (2011) Jin Zhong An Zi No. 0693. On March 31, 2011, Sinovel refused to accept contracted shipments of 1.5 megawatt (MW) and 3 MW wind turbine core electrical components and spare parts that the Company was prepared to deliver. The Company alleges that these actions constitute material breaches of its contracts because Sinovel did not give it notice that it intended to delay deliveries as required under the contracts. Moreover, the Company alleges that Sinovel has refused to pay past due amounts for prior shipments of core electrical components and spare parts. The Company is seeking compensation for past product shipments (including interest) and monetary damages in the amount of approximately RMB 430 million ($67 million) due to Sinovel's breaches of its contracts. The Company is also seeking specific performance of our existing contracts as well as reimbursement of all costs and reasonable expenses with respect to the arbitration. The value of the undelivered components under the existing contracts, including the deliveries refused by Sinovel in March 2011, amounts to approximately RMB 4.6 billion ($720 million).

[0000950123-11-096966:notes:32]
On October 8, 2011, Sinovel filed with the Beijing Arbitration Commission an application under the caption (2011) Jin Zhong An Zi No. 0693, for a counterclaim against the Company for breach of the same contracts under which the Company filed its original arbitration claim. Sinovel claimed, among other things, that the goods supplied by the Company do not conform to the standards specified in the contracts and claimed damages in the amount of approximately RMB 370 millon ($58 million). On October 17, 2011, Sinovel filed with the Beijing Arbitration Commission a request for change of counterclaim to increase its damage claim to approximately RMB 1 billion ($157 million). Deducting the RMB 430 million ($67 million) claimed by the Company, the net amount of damages claimed by Sinovel is approximately RMB 570 million ($89 million). The Company believes that Sinovel's claims are without merit and it intends to defend these actions vigorously. Since the proceedings in this matter are in relatively early stages, the Company cannot reasonably estimate possible losses or range of losses at this time.

[0000950123-11-096966:notes:33]
The Company also submitted a civil action application to the Beijing No. 1 Intermediate People's Court under the caption (2011) Yi Zhong Min Chu Zi No. 15524, against Sinovel for software copyright infringement on September 13, 2011. The application alleges Sinovel's unauthorized use of portions of the Company's wind turbine control software source code developed for Sinovel's 1.5MW wind turbines and the binary code, or upper layer, of the Company's software for the PM3000 power converters in 1.5MW wind turbines. In July 2011, a former employee of the Company's AMSC Windtec GmbH subsidiary was arrested in Austria on charges of economic espionage and fraudulent manipulation of data. In September 2011, the former employee pled guilty to the charges, and he is currently serving a prison sentence. As a result of the Company's internal investigation and a criminal investigation conducted by Austrian authorities, the Company believes that this former employee was contracted by Sinovel through an intermediary while employed by the Company and improperly obtained and transferred to Sinovel portions of its wind turbine control software source code developed for Sinovel's 1.5MW wind turbines. Moreover, the Company believes the former employee illegally used source code to develop for Sinovel a software modification to circumvent the encryption and remove technical protection measures on the PM3000 power converters in 1.5MW wind turbines in the field. The Company is seeking a cease and desist order with respect to the unauthorized copying, installation and use of its software, monetary damages of approximately RMB 38 million ($6 million) for our economic losses and reimbursement of all costs and reasonable expenses. The court has accepted the case, which was necessary in order for the case to proceed.

[0000950123-11-096966:notes:34]
The Company submitted a civil action application to the Beijing Higher People's Court against Sinovel and certain of its employees for trade secret infringement on September 13, 2011 under the caption (2011) Gao Min Chu Zi No. 4193. The application alleges the defendants' unauthorized use of portions of the Company's wind turbine control software source code developed for Sinovel's 1.5MW wind turbines as described above with respect to the Copyright Action. The Company is seeking monetary damages of RMB 2.9 billion ($453 million) for the trade secret infringement as well as reimbursement of all costs and reasonable expenses. The court has accepted the case, which was necessary in order for the case to proceed.

[0000950123-11-096966:notes:35]
On September 16, 2011, the Company filed a civil copyright infringement complaint in the Hainan Province No. 1 Intermediate People's Court against Dalian Guotong Electric Co. Ltd. ("Guotong"), a supplier of power converter products to Sinovel, and Huaneng Hainan Power, Inc., a wind farm operator that has purchased Sinovel wind turbines containing Goutong power converter products. The case is captioned (2011) Hainan Yi Zhong Min Chu Zi No. 62. The application alleges that the Company's PM1000 converters in certain Sinovel wind turbines have been replaced by converters produced by Guotong. Because the Guotong converters are being used in wind turbines containing the Company's wind turbine control software, the Company believes that its copyrighted software is being infringed. The Company is seeking a cease and desist order with respect to the unauthorized use of its software, monetary damages of RMB 1.2 million ($0.2 million) for its economic losses (with respect to Guotong only) and reimbursement of all costs and reasonable expenses. The court has accepted the case, which was necessary in order for the case to proceed. In addition, upon the request of the defendant Huaneng Hainan Power, Inc, Sinovel has been added by the court to this case as a defendant.

[0000950123-11-096966:notes:36]
Ghodawat Energy Pvt Ltd ("Ghodawat"), a company registered in India carrying on the business of wind power development, lodged a Request for Arbitration with the Secretariat of the ICC International Court of Arbitration on May 12, 2011 and named AMSC Windtec GmbH ("AMSC Windtec") as the Respondent.  Under the Request for Arbitration, Ghodawat alleges that AMSC Windtec breached an agreement dated March 19, 2008 pursuant to which AMSC Windtec granted a license to Ghodawat to manufacture, use, sell, market, erect, commission and maintain certain wind turbines using its technical information and wind turbine design (the "License Agreement").  Under the Request for Arbitration, Ghodawat's claims in this arbitration amount to approximately €18 million ($24 million).  AMSC Windtec filed an Answer to Request for Arbitration and Counterclaim ("Answer and Counterclaim"), in which AMSC Windtec denied Ghodawat's claims in their entirety.  AMSC Windtec has also submitted counterclaims under the License Agreement against Ghodawat in the amount of approximately €6 million ($9 million).  Ghodawat has filed a Reply to Answer to Request for Arbitration and Counterclaim in which it denies AMSC Windtec's counterclaims. The arbitration proceedings are currently ongoing. The Company has recorded a loss contingency based on its assessment of probable losses on this claim, however this amount is immaterial to its consolidated financial statements.

[0000950123-11-096966:notes:37]
Other

[0000950123-11-096966:notes:38]
The Company enters into long-term construction contracts with customers that require the Company to obtain performance bonds. The Company is required to deposit an amount equivalent to some or all the face amount of the performance bonds into an escrow account until the termination of the bond. When the performance conditions are met, amounts deposited as collateral for the performance bonds are returned to the Company. In addition, the Company has various contractual arrangements in which minimum quantities of goods or services have been committed to be purchased on an annual basis.

[0000950123-11-096966:notes:39]
As of September 30, 2011, the Company had seven performance bonds in support of customer contracts to guarantee supply of core components and software. The total value of the outstanding performance bonds is $1.8 million with various expiration dates through March 2014. In the event that the payment is made in accordance with the requirements of any of these performance bonds, the Company would record the payment as an offset to revenue.

[0000950123-11-096966:notes:40]
At September 30, 2011, the Company had $8.3 million of restricted cash included in current assets. At September 30, 2011, the Company had $1.1 million of restricted cash included in long-term assets. These amounts included in restricted cash represent deposits to secure letters of credit for various supply contracts. These deposits are held in an interest bearing account. The Company had an additional $2.2 million in unsecured letters of credit at September 30, 2011 in support of various supply contracts.

[0000950123-11-096966:notes:41]
The Company had unused, unsecured lines of credit consisting of RMB 17.6 million (approximately $2.7 million) in China and €1.6 million (approximately $2.2 million) in Austria as of September 30, 2011. During the three months ended September 30, 2011, the Company's unsecured credit line with the Bank of China expired and it repaid borrowings on lines of credit of $4.6 million and there were no borrowings outstanding as of September 30, 2011.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000950123-11-096966:notes:42]
2.        Stock-Based Compensation

[0000950123-11-096966:notes:43]
The Company accounts for its stock-based compensation at fair value. The following table summarizes stock-based compensation expense by financial statement line item for the three months ended September 30, 2011 and 2010 (in thousands):

[0000950123-11-096966:notes:44]
During the six months ended September 30, 2011, the Company granted approximately 785,000 and 387,000 shares of stock options and restricted stock, respectively, to employees under the 2007 Stock Incentive Plan. The restricted stock granted during the six months ended September 30, 2011 includes approximately 100,000 shares of performance-based restricted stock, which will vest upon achievement of certain financial performance measurements. The Company recognizes the fair value of the performance based awards over the estimated period of each award for which the achievement of the performance measures are probable to occur. The remaining shares granted vest upon the passage of time, generally three years. For awards that vest upon the passage of time, expense is being recorded over the vesting period.

[0000950123-11-096966:notes:45]
The estimated fair value of the Company's stock-based awards, less expected annual forfeitures, is amortized over the awards' service period. The total unrecognized compensation cost for unvested outstanding stock options was $9.5 million as of September 30, 2011. This expense will be recognized over a weighted average expense period of approximately 2.4 years. The total unrecognized compensation cost for unvested outstanding restricted stock was $5.2 million as of September 30, 2011. This expense will be recognized over a weighted average expense period of approximately 1.9 years.

[0000950123-11-096966:notes:46]
The weighted-average assumptions used in the Black-Scholes valuation model for stock options granted during the three and six months ended September 30, 2011 and 2010 are as follows:

[0000950123-11-096966:notes:47]
[same as prior period, unchanged from 0000950123-11-086250:notes:54]

[0000950123-11-096966:notes:48]
In conjunction with the departure of certain former executive officers, the Company agreed to modify certain vested awards by extending the period over which each former officer would be entitled to exercise stock options and accelerated the vesting of certain other outstanding awards. Accordingly, the Company recorded stock-based compensation expense related to these modifications of $0.3 million and $0.9 million in the three and six months ended September 30, 2011, respectively.


## us-gaap:EarningsPerShareTextBlock

[0000950123-11-096966:notes:49]
3.        Computation of Net (Loss) Income per Common Share

[0000950123-11-096966:notes:50]
Basic net (loss) income per share ("EPS") is computed by dividing net (loss) income by the weighted-average number of common shares outstanding for the period. Where applicable, diluted EPS is computed by dividing the net (loss) income by the weighted-average number of common shares and dilutive common equivalent shares outstanding during the period, calculated using the treasury stock method. Common equivalent shares include the effect of restricted stock, exercise of stock options and warrants and contingently issuable shares. For the three and six months ended September 30, 2011 and 2010, common equivalent shares of 2.6 million shares and 1.3 million shares, respectively, and 2.6 million shares and 0.9 million shares, respectively, were not included in the calculation of diluted EPS as they were considered anti-dilutive.

[0000950123-11-096966:notes:51]
The following table reconciles the numerators and denominators of the earnings per share calculation for the three and six months ended September 30, 2011 and 2010 (in thousands, except per share data):


## us-gaap:EquityMethodInvestmentsDisclosureTextBlock

[0000950123-11-096966:notes:52]
[same as prior period, unchanged from 0000950123-11-086250:notes:59]

[0000950123-11-096966:notes:53]
[same as prior period, unchanged from 0000950123-11-086250:notes:60]

[0000950123-11-096966:notes:54]
On October 9, 2009, the Company made an investment in Tres Amigas LLC, ("Tres Amigas"), a merchant transmission company, for $1.8 million, consisting of $0.8 million in cash and $1.0 million in AMSC common stock. On January 6, 2011 and May 20, 2011, the Company increased its minority position in Tres Amigas by an additional $1.8 million on each date. As of September 30, 2011, the Company holds a 37% ownership interest.

[0000950123-11-096966:notes:55]
The Company has determined that Tres Amigas is a variable interest entity ("VIE") and that the Company is not the primary beneficiary of the VIE. Therefore, the Company has not consolidated Tres Amigas as of September 30, 2011. The investment is carried at the acquisition cost, plus the Company's equity in undistributed earnings or losses. The Company's maximum exposure to loss is limited to the Company's recorded investment in this VIE. The Company's investment in Tres Amigas is included in other assets on the consolidated balance sheet and the equity in undistributed losses of Tres Amigas is included in other income, net, on the consolidated statements of operations.

[0000950123-11-096966:notes:56]
The net investment activity for the six months ended September 30, 2011 is as follows (in thousands):

[0000950123-11-096966:notes:57]
| Balance at April 1, 2011 |  | $ | 3,026 |  |
| Purchase of minority investment |  |  | 1,800 |  |
| Minority interest in net losses |  |  | (428) |  |
| Balance at September 30, 2011 |  | $ | 4,398 |  |

[0000950123-11-096966:notes:58]
[same as prior period, unchanged from 0000950123-11-086250:notes:65]

[0000950123-11-096966:notes:59]
On August 12, 2010, the Company acquired (through its Austrian subsidiary), a minority ownership position in Blade Dynamics Ltd. ("Blade Dynamics"), a designer and manufacturer of advanced wind turbine blades based on proprietary materials and structural technologies, for $8.0 million in cash. The Company uses the equity method of accounting for this investment since it does not have a controlling ownership interest in the operating and financial policies of Blade Dynamics. As such, the investment is carried at the acquisition cost, plus the Company's equity in undistributed earnings or losses. The Company's investment is included in other assets on the unaudited condensed consolidated balance sheet and the minority interest in net losses of Blade Dynamics is included in other income, net, on the unaudited condensed consolidated statements of operations. As of September 30, 2011, the Company holds a 25% ownership interest. The net investment activity for the six months ended September 30, 2011 is as follows (in thousands):

[0000950123-11-096966:notes:60]
| Balance at April 1, 2011 |  | $ | 7,903 |  |
| Minority interest in net losses |  |  | (924) |  |
| Net foreign exchange rate impact |  |  | (238) |  |
| Balance at September 30, 2011 |  | $ | 6,741 |  |


## us-gaap:FairValueAssetsAndLiabilitiesMeasuredOnRecurringBasisGainLossIncludedInEarningsTextBlock

[0000950123-11-096966:notes:61]
|  | TotalCarryingValue | Quoted Prices inActive Markets(Level 1) | Using Significant OtherObservable Inputs(Level 2) | Using SignificantUnobservable Inputs(Level 3) |
| September 30, 2011: |  |  |  |  |
| Assets: |  |  |  |  |
| Cash equivalents | $ 58,360 | $ 58,360 | $ — | $ — |
| Short-term commercial paper | 5,378 | — | 5,378 | — |
|  | TotalCarryingValue | Quoted Prices inActive Markets(Level 1) | Using Significant OtherObservable Inputs(Level 2) | Using SignificantUnobservable Inputs(Level 3) |
| March 31, 2011: |  |  |  |  |
| Assets: |  |  |  |  |
| Cash equivalents | $ 49,837 | $ 49,837 | $ — | $ — |
| Short-term government-backed securities.. | 76,371 | — | 76,371 | — |
| Short-term commercial paper | 39,755 | — | 39,755 | — |
| Derivatives ties | 3,087 | — | 3,087 | — |


## us-gaap:FairValueDisclosuresTextBlock

[0000950123-11-096966:notes:62]
4. Fair Value Measurements

[0000950123-11-096966:notes:63]
In January 2010, the Financial Accounting Standards Board ("FASB") issued guidance related to disclosures of fair value measurements. The guidance requires gross presentation of activity within the Level 3 measurement roll-forward and details of transfers in and out of Level 1 and 2 measurements. It also clarifies two existing disclosure requirements on the level of disaggregation of fair value measurements and disclosures on inputs and valuation techniques. A change in the hierarchy of an investment from its current level will be reflected in the period during which the pricing methodology of such investment changes. Disclosure of the transfer of securities from Level 1 to Level 2 or Level 3 will be made in the event that the related security is significant to total cash and investments. The Company did not have any transfers of assets and liabilities between Level 1 and Level 2 of the fair value measurement hierarchy during the three months ended September 30, 2011.

[0000950123-11-096966:notes:64]
[same as prior period, unchanged from 0000950123-11-086250:notes:71]

[0000950123-11-096966:notes:65]
[same as prior period, unchanged from 0000950123-11-086250:notes:72]

[0000950123-11-096966:notes:66]
[same as prior period, unchanged from 0000950123-11-086250:notes:73]

[0000950123-11-096966:notes:67]
The following table provides the assets carried at fair value, measured as of September 30, 2011 and March 31, 2011 (in thousands):

[0000950123-11-096966:notes:68]
[same as prior period, unchanged from 0000950123-11-086250:notes:75]

[0000950123-11-096966:notes:69]
[same as prior period, unchanged from 0000950123-11-086250:notes:76]

[0000950123-11-096966:notes:70]
Cash equivalents consist of highly liquid instruments with maturities of three months or less that are regarded as high quality, low risk investments and are measured using such inputs as quoted prices, and are classified within Level 1 of the valuation hierarchy. Cash equivalents consist principally of certificates of deposits and money market accounts.

[0000950123-11-096966:notes:71]
[same as prior period, unchanged from 0000950123-11-086250:notes:78]

[0000950123-11-096966:notes:72]
Marketable securities consist primarily of government-backed securities and commercial paper and are measured using such inputs as quoted prices for identical or similar assets in markets that are not active, inputs other than quoted prices that are observable for the asset (for example, interest rates and yield curves observable at commonly quoted intervals), and inputs that are derived principally from or corroborated by observable market data by correlation or other means, and are classified within Level 2 of the valuation hierarchy. The Company's marketable securities generally have maturities of greater than three months from original purchase date but less than twelve months from the date of the balance sheet. The Company determines the appropriate classification of its marketable securities at the time of purchase and re-evaluates such classification as of each balance sheet date. All marketable securities are considered available-for-sale and are carried at fair value. The Company periodically reviews the realizability of each short-term and long-term marketable security when impairment indicators exist with respect to the security. If an other-than-temporary impairment of value of the security exists, the carrying value of the security is written down to its estimated fair value.

[0000950123-11-096966:notes:73]
[same as prior period, unchanged from 0000950123-11-086250:notes:80]

[0000950123-11-096966:notes:74]
[same as prior period, unchanged from 0000950123-11-086250:notes:81]


## us-gaap:IncomeTaxDisclosureTextBlock

[0000950123-11-096966:notes:75]
8.        Income Taxes

[0000950123-11-096966:notes:76]
The Company recorded income tax expense of $0.9 million and $1.1 million for the three and six months ended September 30, 2011, respectively, and $7.9 million and $15.1 million for the three and six months ended September 30, 2010, respectively. The Company has provided a valuation allowance against all net deferred tax assets as of September 30, 2011, as it is more likely than not that its net deferred tax assets are not currently realizable due to the net operating losses incurred by the Company since its inception in the U.S. and the significant write-offs in the fiscal year ended March 31, 2011 and the losses that are forecasted in certain foreign jurisdictions in the future.

[0000950123-11-096966:notes:77]
During the three months ended September 30, 2011, the Company recorded additional income tax expense of $0.5 million for uncertain tax positions related to its Austrian subsidiary.


## us-gaap:InventoryDisclosureTextBlock

[0000950123-11-096966:notes:78]
6.        Inventory

[0000950123-11-096966:notes:79]
[same as prior period, unchanged from 0000950123-11-086250:notes:85]

[0000950123-11-096966:notes:80]
The Company recorded inventory writedowns of approximately $1.1 million and $1.5 million in the three and six months ended September 30, 2011.

[0000950123-11-096966:notes:81]
Deferred program costs as of September 30, 2011 and March 31 2011 primarily represent costs incurred on D-VAR turnkey projects and programs accounted for under contract accounting where the Company needs to complete development programs before revenue and costs will be recognized, respectively.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0000950123-11-096966:notes:82]
[same as prior period, unchanged from 0000950123-11-086250:notes:87]

[0000950123-11-096966:notes:83]
American Superconductor Corporation ("AMSC" or the "Company") was founded on April 9, 1987. The Company is a leading provider of megawatt-scale solutions that lower the cost of wind power and enhance the performance of the power grid. In the wind power market, the Company enables manufacturers to field wind turbines through its advanced engineering, support services and power electronics products. In the power grid market, the Company enables electric utilities and renewable energy project developers to connect, transmit and distribute power through its transmission planning services and power electronics and superconductor based products. The Company's wind and power grid products and services provide exceptional reliability, security, efficiency and affordability to its customers.

[0000950123-11-096966:notes:84]
These unaudited condensed consolidated financial statements of the Company have been prepared in accordance with the Securities and Exchange Commission's ("SEC") instructions to Form 10-Q. Certain information and footnote disclosures normally included in the financial statements prepared in accordance with accounting principles generally accepted in the United States ("GAAP") have been condensed or omitted pursuant to those instructions. The year-end condensed balance sheet data was derived from audited financial statements but does not include all disclosures required by GAAP. The unaudited condensed consolidated financial statements, in the opinion of management, reflect all adjustments (consisting of normal recurring adjustments) necessary for a fair statement of the results for the interim periods ended September 30, 2011 and 2010 and the financial position at September 30, 2011. The unaudited condensed consolidated financial statements include the accounts of the Company and its wholly-owned subsidiaries. All significant intercompany balances and transactions are eliminated in consolidation. Certain reclassifications of prior year amounts have been made to conform to current year presentation.  These reclassifications had no effect on net income, cash flows from operating activities or stockholders' equity.

[0000950123-11-096966:notes:85]
The Company operates its business in two market-facing business units: Wind and Grid. The Company believes this market-centric structure enables it to effectively anticipate and meet the needs of wind turbine manufacturers, power generation project developers and electric utilities.

[0000950123-11-096966:notes:86]
·         Wind. Through its Windtec Solutions, the Wind business segment enables manufacturers to field wind turbines with exceptional power output, reliability and affordability. The Company licenses its highly engineered wind turbine designs, provides extensive customer support services and supplies advanced power electronics and control systems to wind turbine manufactures. The Company's design portfolio includes a broad range of drive trains and power ratings up to 10 megawatts. The Company believes its unique engineering capabilities, ranging from bearings to advanced synchronous generators to blades, enables it to provide its partners with highly-optimized wind turbine platforms. Furthermore, these designs and support services typically lead to sales of its power electronics and software-based control systems, which are designed for optimized performance, efficiency and grid compatibility.

[0000950123-11-096966:notes:87]
·         Grid. Through its Gridtec Solutions, the Grid business segment enables electric utilities and renewable energy project developers to connect, transmit and distribute power with exceptional efficiency, reliability and affordability. The Company provides transmission planning services that allows it to identify power grid congestion, poor power quality and other risks, which helps it determine how its solutions can improve network performance. These services often lead to sales of grid interconnection solutions for wind farms and solar power plants, power quality systems and transmission and distribution cable systems.

[0000950123-11-096966:notes:88]
On March 12, 2011, the Company entered into a Share Purchase Agreement, by and among the Company and the shareholders of The Switch Engineering Oy, a power technologies company headquartered in Finland ("The Switch"), which was amended on June 29, 2011 (as amended, the "Agreement"). Pursuant to the Agreement, the Company agreed to acquire all of the outstanding shares of The Switch. On October 28, 2011, the Company and The Switch entered into a termination agreement pursuant to which the parties mutually agreed to terminate the Agreement due to adverse market conditions for a financing required to fund the acquisition. Under the termination agreement, The Switch retained a $20.6 million advance payment as a break-up fee. As a result, the Company recorded a write-off of the advance payment during the three months ended September 30, 2011.

[0000950123-11-096966:notes:89]
At September 30, 2011, the Company had cash, cash equivalents, marketable securities and restricted cash of $108.3 million. The Company's business plan anticipates a substantial decline in revenues and a substantial use of cash from operations in its fiscal year ending March 31, 2012, particularly in light of the difficult and uncertain current economic environment, particularly in China, the significant restructuring actions undertaken and the slowdown in the Chinese wind power market, which has accounted for more than two-thirds of the Company's revenues in recent fiscal years. The Company's plan includes a significant restructuring undertaken in August 2011, resulting in the elimination of approximately 150 positions worldwide. Since April 1, 2011, the Company has eliminated approximately 30% of its workforce and it expects to reduce annualized expenses by $30 million annually as a result of these reductions. The Company plans to continue to closely monitor its expenses and if required, will further reduce operating costs and capital spending to enhance liquidity. The Company believes that its available cash, together with additional reductions in operating costs and capital expenditures as necessary will be sufficient to fund its operations, capital expenditures and other cash requirements for at least the next twelve months. The Company's long-term liquidity is dependent on its ability to profitably grow its revenues or raise additional capital as required. If necessary, the Company may seek financing through public or private equity offerings, debt financings, or other financing alternatives. However, there can be no assurance that financing will be available on acceptable terms or at all.

[0000950123-11-096966:notes:90]
[same as prior period, unchanged from 0000950123-11-086250:notes:96]

[0000950123-11-096966:notes:91]
The Company's fiscal year begins on April 1 and ends on March 31. This document refers to fiscal 2011, which is defined as the period beginning on April 1, 2011 and concluding on March 31, 2012. The second quarter of fiscal 2011 began on July 1, 2011 and concluded on September 30, 2011.


## us-gaap:ProductWarrantyDisclosureTextBlock

[0000950123-11-096966:notes:92]
7.        Product Warranty

[0000950123-11-096966:notes:93]
The Company generally provides a one to three-year warranty on its products, commencing upon installation. A provision is recorded upon revenue recognition to cost of revenues for estimated warranty expense based on historical experience.

[0000950123-11-096966:notes:94]
[same as prior period, unchanged from 0000950123-11-086250:notes:100]

[0000950123-11-096966:notes:95]
The Company includes warranty period expirations as changes in accruals for warranties in the table above.


## us-gaap:ScheduleOfAccountsNotesLoansAndFinancingReceivableTextBlock

[0000950123-11-096966:notes:96]
5.        Accounts Receivable

[0000950123-11-096966:notes:97]
[same as prior period, unchanged from 0000950123-11-086250:notes:102]

[0000950123-11-096966:notes:98]
The Company records bank acceptance notes receivable arranged with third-party financial institutions by certain customers to settle their transactions within prepaid expenses and other current assets. These notes are typically non-interest bearing and generally have maturities of less than six months. The carrying amount of notes receivable approximate their fair values. The Company had notes receivable outstanding of $2.4 million and $2.0 million as of September 30, 2011 and March 31, 2011, respectively.


## us-gaap:SegmentReportingDisclosureTextBlock

[0000950123-11-096966:notes:99]
[same as prior period, unchanged from 0000950123-11-086250:notes:103]

[0000950123-11-096966:notes:100]
[same as prior period, unchanged from 0000950123-11-086250:notes:104]

[0000950123-11-096966:notes:101]
The Company operates its business into two market-facing business units: Wind and Grid. The Company believes this market-centric structure enables it to more effectively anticipate and meet the needs of wind turbine manufacturers, power generation project developers and electric utilities.

[0000950123-11-096966:notes:102]
·         Grid. Through its Gridtec Solutions, the Grid business segment enables electric utilities and renewable energy project developers to connect, transmit and distribute power with exceptional efficiency, reliability and affordability. The Grid business unit provides transmission planning services that allow us to identify power grid congestion, poor power quality and other risks, which helps the Company determine how its solutions can improve network performance. These services often lead to sales of grid interconnection solutions for wind farms and solar power plants, power quality systems and transmission and distribution cable systems.

[0000950123-11-096966:notes:103]
Prior to April 1, 2011, the Company segmented its operations through two technology-centric business units: AMSC Power Systems and AMSC Superconductors. AMSC Power Systems included all of its Wind products, as well as Grid products that regulate voltage for wind farm voltage electric utilities, renewable generation project developers and industrial operations. Solutions from the Company's AMSC Superconductors business unit have been incorporated into its Grid business unit. All prior period segment disclosures have been revised to conform to management's current view of the Company's business segments.

[0000950123-11-096966:notes:104]
[same as prior period, unchanged from 0000950123-11-086250:notes:108]

[0000950123-11-096966:notes:105]
The accounting policies of the business segments are the same as those for the consolidated Company. The Company's business segments have been determined in accordance with the Company's internal management structure, which is organized based on operating activities.  The Company evaluates performance based upon several factors, of which the primary financial measures are segment revenues and segment operating (loss) income. The disaggregated financial results of the segments reflect allocation of certain functional expense categories consistent with the basis and manner in which Company management internally disaggregates financial information for the purpose of assisting in making internal operating decisions. In addition, certain corporate expenses which the Company does not believe are specifically attributable or allocable to either of the two business segments have been excluded from the segment operating (loss) income.

[0000950123-11-096966:notes:106]
Unallocated corporate expenses primarily consist of the write-off of an advance payment to The Switch of $20.6 million and restructuring and impairment charges of $4.3 million for the three and six months ended September 30, 2011 and stock-based compensation expense of $2.1 million and $5.6 million for the three and six months ended September 30, 2011, respectively. Unallocated corporate expenses primarily consist of stock-based compensation expense of $4.3 million and $7.8 million for the three and six months ended September 30, 2010, respectively.

[0000950123-11-096966:notes:107]
[same as prior period, unchanged from 0000950123-11-086250:notes:111]

[0000950123-11-096966:notes:108]
The following table sets forth customers who represented 10% or more of the Company's total revenues:
