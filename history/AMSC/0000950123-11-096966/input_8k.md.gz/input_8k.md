# AMSC 8-K — 0000950123-11-096775 filed 2011-11-09

## item codes, every 8-K on or before 2011-11-09

- 2011-11-09 0000950123-11-096775 — 2.02, 9.01
- 2011-10-31 0000950123-11-093390 — 1.02, 9.01
- 2011-10-07 0000950123-11-089221 — 8.01
- 2011-10-03 0000950123-11-088315 — 7.01
- 2011-09-23 0000950123-11-086288 — 2.02, 9.01
- 2011-09-15 0000950123-11-084585 — 7.01
- 2011-09-06 0000950123-11-082736 — 7.01
- 2011-08-18 0000950123-11-078526 — 3.01, 7.01, 9.01
- 2011-08-11 0000950123-11-075905 — 5.02
- 2011-08-11 0000950123-11-075904 — 2.02, 2.05, 9.01
- 2011-07-11 0000950123-11-064934 — 2.02, 4.02, 9.01
- 2011-06-30 0000950123-11-063287 — 1.01, 3.02, 9.01
- 2011-06-21 0000950123-11-060491 — 3.01, 7.01, 9.01
- 2011-06-13 0000950123-11-058656 — 1.01, 9.01
- 2011-05-24 0000950123-11-053517 — 5.02, 9.01
- 2011-04-05 0001299933-11-001020 — 2.02, 9.01
- 2011-03-15 0000950123-11-025580 — 5.02
- 2011-03-14 0000950123-11-025205 — 1.01, 3.02, 9.01
- 2011-02-01 0001299933-11-000333 — 2.02, 9.01
- 2010-11-12 0000950123-10-104604 — 8.01, 9.01
- 2010-11-08 0000950123-10-102424 — 8.01, 9.01
- 2010-11-02 0001299933-10-003878 — 2.02, 9.01
- 2010-09-15 0000950123-10-086373 — 1.01, 9.01 — amendment, the index does not say of what
- 2010-08-06 0000950123-10-074362 — 5.07
- 2010-07-29 0001299933-10-002860 — 2.02, 9.01
- 2010-05-17 0000950123-10-050424 — 1.01, 9.01
- 2010-05-14 0001299933-10-001972 — 5.02
- 2010-05-13 0001299933-10-001943 — 2.02, 9.01
- 2010-02-08 0001299933-10-000506 — 8.01
- 2010-02-02 0001299933-10-000386 — 2.02, 9.01
- 2009-12-15 0001299933-09-004928 — 5.02
- 2009-10-29 0001299933-09-004267 — 2.02, 9.01
- 2009-08-12 0001193125-09-173026 — 5.02, 9.01
- 2009-07-30 0001193125-09-158842 — 1.01, 2.02, 9.01
- 2009-05-15 0001193125-09-113158 — 5.02
- 2009-05-14 0001193125-09-110619 — 2.02, 9.01
- 2009-04-20 0001193125-09-082590 — 5.02
- 2009-02-03 0001193125-09-016992 — 2.02, 9.01
- 2009-01-22 0001193125-09-009777 — 2.02, 9.01
- 2008-11-04 0001193125-08-223730 — 2.02, 9.01
- 2008-08-11 0001193125-08-173616 — 8.01
- 2008-08-07 0001193125-08-170325 — 8.01
- 2008-08-05 0001193125-08-165888 — 2.02, 9.01
- 2008-06-11 0001193125-08-132049 — 1.01, 9.01
- 2008-05-20 0001193125-08-119372 — 5.02, 9.01
- 2008-05-08 0001193125-08-107052 — 2.02, 9.01
- 2008-01-31 0001193125-08-016233 — 2.02, 9.01
- 2008-01-30 0001193125-08-015494 — 5.03, 9.01
- 2007-11-01 0001193125-07-231866 — 2.02, 9.01
- 2007-10-31 0001193125-07-231225 — 2.05
- 2007-10-29 0001193125-07-228284 — 5.03, 9.01
- 2007-09-27 0001193125-07-208950 — 5.02
- 2007-08-09 0001193125-07-176553 — 2.02, 9.01
- 2007-08-07 0001193125-07-173829 — 1.01, 5.02, 9.01
- 2007-07-02 0001193125-07-148303 — 5.02, 9.01
- 2007-06-20 0001193125-07-139068 — 8.01, 9.01
- 2007-06-14 0001193125-07-135550 — 9.01 — amendment of 0001193125-07-005297
- 2007-06-14 0001193125-07-135340 — 5.02
- 2007-05-24 0001193125-07-122148 — 2.02, 9.01
- 2007-03-30 0001193125-07-070154 — 2.05, 9.01
- 2007-03-23 0001193125-07-062978 — 9.01 — amendment of 0001193125-07-005297
- 2007-02-01 0001193125-07-017883 — 2.02, 9.01
- 2007-01-11 0001193125-07-005297 — 2.01, 9.01
- 2006-12-05 0001181431-06-067500 — 5.02
- 2006-11-29 0001193125-06-243360 — 1.01, 3.02, 9.01
- 2006-11-02 0001193125-06-221464 — 2.02, 9.01
- 2006-09-21 0001193125-06-194526 — 5.02
- 2006-08-08 0001193125-06-164819 — 2.02, 9.01
- 2006-08-02 0001193125-06-159113 — 1.01, 9.01
- 2006-07-28 0001193125-06-156172 — 1.01
- 2006-06-26 0001193125-06-135913 — 1.01, 3.03, 9.01
- 2006-05-11 0001193125-06-108489 — 2.02, 9.01
- 2006-05-05 0001193125-06-102270 — 1.01, 9.01
- 2006-05-01 0001193125-06-094941 — 2.02, 2.06, 9.01
- 2006-02-24 0001193125-06-038281 — 5.02, 9.01
- 2006-02-02 0001181431-06-007665 — 2.02, 9.01
- 2005-11-09 0001181431-05-060304 — 2.02, 9.01
- 2005-08-04 0001181431-05-044420 — 2.02, 9.01
- 2005-07-28 0001193125-05-151272 — 5.02, 9.01
- 2005-06-14 0001193125-05-125148 — 5.02, 9.01
- 2005-05-12 0001181431-05-027410 — 2.02, 9.01
- 2005-05-10 0001193125-05-102795 — 1.01
- 2005-04-05 0001181431-05-020680 — 1.01, 2.02, 3.02, 9.01
- 2005-02-03 0001181431-05-006678 — 2.02, 9.01
- 2004-11-09 0001181431-04-051381 — 2.02, 9.01 — amendment, the index does not say of what
- 2004-11-04 0001181431-04-050706 — 2.02, 9.01
- 2004-10-15 0001193125-04-172458 — 1.01, 9.01
- 2004-08-05 0001193125-04-132162 — 12
- 2004-05-13 0001193125-04-086853 — 12
- 2004-02-05 0001193125-04-015060 — 12
- 2003-11-06 0001193125-03-074000 — 12
- 2003-09-26 0001193125-03-054624 — 5
- 2003-08-06 0001193125-03-029666 — 12
- 2003-05-14 0000927016-03-002619 — 9
- 2002-12-31 0000927016-02-006114 — 5
- 2000-01-24 0000927016-00-000150 — 5, 7
- 1998-11-02 0000950135-98-005625 — 5, 7
- 1998-03-24 0000950135-98-001743 — 5, 7
- 1997-09-05 0000950135-97-003729 — 5, 7
- 1997-06-23 0000950135-97-002785 — 1 — amendment of 0000950135-97-001972
- 1997-04-23 0000950135-97-001972 — 2, 7

## late-filing notifications on or before 2011-11-09

- 2011-08-10 0000950123-11-075677 — NT 10-Q, for the period ended 2011-06-30
- 2011-05-31 0000950123-11-055465 — NT 10-K, for the period ended 2011-03-31

## item 2.02 — earnings release, exhibit 99.1

[0000950123-11-096775:8k_2_02:1]
EX-99.1
2
b88905exv99w1.htm
EX-99.1

[0000950123-11-096775:8k_2_02:2]
exv99w1

[0000950123-11-096775:8k_2_02:3]
Exhibit 99.1

[0000950123-11-096775:8k_2_02:4]
AMSC Reports Second Quarter Fiscal 2011 Financial Results

[0000950123-11-096775:8k_2_02:5]
Devens, MA — November 9, 2011 — AMSC (NASDAQ: AMSC), a global solutions provider serving
wind and grid leaders, today reported financial results for its second quarter of fiscal year 2011
ended September 30, 2011.

[0000950123-11-096775:8k_2_02:6]
Revenues for the second quarter of fiscal 2011 were $20.8 million. This compares with $98.1 million
for the second quarter of fiscal 2010 and $9.1 million for the first quarter of fiscal 2011. The
year-over-year decline is due primarily to a lack of revenue from AMSC’s former customer, Sinovel
Wind Group Co., Ltd. (Sinovel), while the quarter-over-quarter increase was driven by solid growth
in both of the company’s reporting segments (Wind and Grid).

[0000950123-11-096775:8k_2_02:7]
AMSC reported a net loss for the quarter of $51.7 million, or $1.02 per share. This figure includes
approximately $28.2 million in charges related to the previously announced termination of AMSC’s
proposed acquisition of The Switch Engineering Oy, Sinovel litigation expenses and corporate
restructuring activities and impairments. For the second quarter of fiscal year 2010, AMSC reported
net income of $7.8 million, or $0.17 per diluted share. The company’s non-GAAP net loss for the
second quarter of fiscal 2011 was $22.1 million, or $0.44 per share. This compares with non-GAAP
net income of $13.3 million, or $0.29 per diluted share, for the second quarter of fiscal 2010.
Please refer to the financial table below for a reconciliation of GAAP to non-GAAP results.

[0000950123-11-096775:8k_2_02:8]
Cash, cash equivalents, marketable securities and restricted cash at September 30, 2011 were $108.3
million. This compares with $166.2 million as of June 30, 2011.

[0000950123-11-096775:8k_2_02:9]
The company’s total backlog as of September 30, 2011, excluding contracts related to Sinovel, was
approximately $298 million, which compares with approximately $225 million as of June 30, 2011.

[0000950123-11-096775:8k_2_02:10]
“AMSC executed successfully on its plan in the second fiscal quarter,” said AMSC President and
Chief Executive Officer Daniel P. McGahn. “We generated a sequential increase in revenues while
also reducing our non-GAAP net loss and cash usage compared with the prior quarter. Among our key
contributors to revenue during the quarter were wind turbine manufacturing customers such as Inox
Wind in India, Doosan Heavy Industries in Korea and Dongfang Turbine
Company in China. On the Grid side of our business, we grew our D-VAR® revenues and reached several
recent milestones. These milestones include the energization of South Korea’s first superconductor
power cable system with our partners Korea Electric Power Corporation and LS Cable & System, the
successful testing of a transmission-
voltage fault current limiter with the U.S. Department of Energy and our partners Nexans, Siemens
and Air Liquide, and the restart of Project HYDRA in New York with the Department of Homeland
Security’s Science and Technology Directorate and our partners ConEdison and Southwire.”

[0000950123-11-096775:8k_2_02:11]
| AMSC Reports Second Quarter Results |  | Page 2 |

[0000950123-11-096775:8k_2_02:12]
Looking Forward

[0000950123-11-096775:8k_2_02:13]
“A diversified mix of Wind and Grid bookings enabled us to increase our total backlog by over 30
percent sequentially in the second quarter,” McGahn continued. “This has helped position us for a
stronger second half of fiscal 2011 from both a revenue and bottom-line perspective. On a
go-forward basis we will continue to carefully manage our expenses and our cash.”

[0000950123-11-096775:8k_2_02:14]
For the quarter ending December 31, 2011, AMSC expects that its revenues will exceed $15 million.
AMSC expects that its net loss for the third quarter of fiscal 2011 will be less than $30 million,
or $0.59 per share. AMSC expects that its non-GAAP net loss for the third fiscal quarter will be
less than $24 million, or $0.47 per share. For the fourth fiscal quarter of 2011, the company
expects that its revenues will be roughly double its third-quarter estimate and that its GAAP and
non-GAAP net loss will be significantly reduced quarter over quarter.

[0000950123-11-096775:8k_2_02:15]
AMSC estimates that its balance of cash, cash equivalents, marketable securities and restricted
cash will exceed $75 million on December 31, 2011. The company expects to further reduce cash usage
in the fourth fiscal quarter.

[0000950123-11-096775:8k_2_02:16]
Conference Call Reminder

[0000950123-11-096775:8k_2_02:17]
In conjunction with this announcement, AMSC management will participate in a conference call with
investors beginning at 10:00 a.m. Eastern Time to discuss the company’s results and its business
outlook. Those who wish to listen to the live conference call webcast should visit the “Investors”
section of the company’s website at http://www.amsc.com/investors. The live call also can be
accessed by dialing 719-325-4841 and using conference ID 5584535. A telephonic playback of the call
will be available from 1:00 p.m. ET on November 9 through 1:00 p.m. ET on November 14. Please call
719-457-0820 and refer to conference ID 5584535 to access the playback.

[0000950123-11-096775:8k_2_02:18]
About AMSC (NASDAQ: AMSC)

[0000950123-11-096775:8k_2_02:19]
AMSC generates the ideas, technologies and solutions that meet the world’s demand for smarter,
cleaner ... better energy. Through its Windtec™ Solutions, AMSC enables manufacturers to launch
best-in-class wind turbines quickly, effectively and profitably. Through its Gridtec™ Solutions,
AMSC provides the engineering planning services and advanced grid systems that optimize network
reliability, efficiency and performance. The company’s solutions are now powering gigawatts of
renewable energy globally and enhancing the performance and reliability of power networks in more
than a dozen countries. Founded in 1987, AMSC is headquartered near Boston, Massachusetts with
operations in Asia, Australia, Europe and North America. For more information, please visit
www.amsc.com.

[0000950123-11-096775:8k_2_02:20]
AMSC Contact:

[0000950123-11-096775:8k_2_02:21]
Jason Fredette

[0000950123-11-096775:8k_2_02:22]
Phone: 978-842-3177

[0000950123-11-096775:8k_2_02:23]
Email: jfredette@amsc.com

[0000950123-11-096775:8k_2_02:24]
AMSC, D-VAR, Windtec and Gridtec are trademarks or registered trademarks of American
Superconductor Corporation. All other brand names, product names, trademarks or service marks
belong to their respective holders.

[0000950123-11-096775:8k_2_02:25]
| AMSC Reports Second Quarter Results |  | Page 3 |

[0000950123-11-096775:8k_2_02:26]
forward-looking statements. Such factors include: a significant portion of our revenues has
been derived from Sinovel Wind Group Co. Ltd., (“Sinovel”), which has stopped accepting scheduled
deliveries and refused to pay amounts outstanding; the disruption in our relationship with Sinovel
has materially and adversely affected our business and results of operations and if, as we expect,
Sinovel continues to refuse to accept shipments from us, our business and results of operations
will be further materially and adversely affected; we may require additional funding in the future
and may be unable to raise capital when needed; we have a history of operating losses, and we may
incur additional losses in the future; our operating results may fluctuate significantly from
quarter to quarter and may fall below expectations in any particular fiscal quarter; changes in
exchange rates could adversely affect our results from operations; we have identified material
weaknesses in our internal control over financial reporting and if we fail to remediate these
weaknesses and maintain proper and effective internal controls over financial reporting, our
ability to produce accurate and timely financial statements could be impaired and may lead
investors and other users to lose confidence in our financial data; if we fail to implement our
business strategy successfully, our financial performance could be harmed; we may not realize all
of the sales expected from our backlog of orders and contracts; many of our revenue opportunities
are dependent upon subcontractors and other business collaborators; our products face intense
competition, which could limit our ability to acquire or retain customers; our success is dependent
upon attracting and retaining qualified personnel and our inability to do so could significantly
damage our business and prospects; we may acquire additional complementary businesses or
technologies, which may require us to incur substantial costs for which we may never realize the
anticipated benefits; our international operations are subject to risks that we do not face in the
United States, which could have an adverse effect on our operating results; we depend on sales to
customers in China, and global conditions could negatively affect our operating results or limit
our ability to expand our operations outside of China; changes in China’s political, social,
regulatory and economic environment may affect our financial performance; many of our customer
relationships outside of the United States are, either directly or indirectly, with governmental
entities, and we could be adversely affected by violations of the United States Foreign Corrupt
Practices Act and similar worldwide anti-bribery laws outside the United States; we rely upon third
party suppliers for the components and subassemblies of many of our Wind and Grid products, making
us vulnerable to supply shortages and price fluctuations, which could harm our business; we are
becoming increasingly reliant on contracts that require the issuance of performance bonds; problems
with product quality or product performance may cause us to incur warranty expenses and may damage
our market reputation and prevent us from achieving increased sales and market share; our success
in addressing the wind energy market is dependent on the manufacturers that license our designs;
growth of the wind energy market depends largely on the availability and size of government
subsidies and economic incentives; there are a number of technological challenges that must be
successfully addressed before our superconductor products can gain widespread commercial
acceptance, and our inability to address such technological challenges could adversely affect our
ability to acquire customers for our products; we have not manufactured our Amperium wire in
commercial quantities, and a failure to manufacture our Amperium wire in commercial quantities
at acceptable cost and quality levels would substantially limit our future revenue and profit
potential; the commercial uses of superconductor products are limited today, and a widespread
commercial market for our products may not develop; we have limited experience in marketing and
selling our superconductor products and system-level solutions, and our failure to effectively
market and sell our products and solutions could lower our revenue and cash flow; our contracts
with the U.S. government are subject to audit, modification or termination by the U.S. government
and include certain other provisions in favor of the government; the continued funding of such
contracts remains subject to annual congressional appropriation which, if not approved, could
reduce our revenue and lower or eliminate our profit; we may be unable to adequately prevent
disclosure of trade secrets and other proprietary information; we have filed a demand for
arbitration and other lawsuits against Sinovel regarding amounts we contend are due and owing and
are in dispute; we cannot be certain as to the outcome of the proceedings against Sinovel; we have
been named as a party to purported stockholder class actions and shareholder derivative complaints,
and we may be named in additional litigation, all of which will require significant management time
and attention, result in significant legal expenses and may result in an unfavorable outcome, which
could have a material adverse effect on our business, operating results and financial condition;
our technology and products could infringe intellectual property rights of others, which may
require costly litigation and, if we are not successful, could cause us to pay substantial damages
and disrupt our business; our patents may not provide meaningful protection for our technology,
which could result in us losing some or all of our market position; third parties have or may
acquire patents that cover the materials, processes and technologies we use or may use in the
future to manufacture our Amperium products, and our success depends on our ability to license such
patents or other proprietary rights; and our common stock has experienced, and may continue to
experience, significant market price and volume fluctuations, which may prevent our stockholders
from selling our common stock at a profit and could lead to costly litigation against us that could
divert our management’s attention. Reference is made to many of these factors and others in the
“Risk Factors” section of the company’s most recent quarterly or annual report filed with the
Securities and Exchange Commission. In addition, any forward-looking statements included in this
release represent the company’s expectations as of the date of this release. While the company
anticipates that subsequent events and developments may cause the company’s views to change, the
company specifically disclaims any obligation to update these forward-looking statements. These
forward-looking statements should not be relied upon as representing the company’s views as of any
date subsequent to the date of this release.

[0000950123-11-096775:8k_2_02:27]
| AMSC Reports Second Quarter Results |  | Page 4 |

[0000950123-11-096775:8k_2_02:28]
AMERICAN SUPERCONDUCTOR CORPORATION

[0000950123-11-096775:8k_2_02:29]
UNAUDITED CONSOLIDATED STATEMENTS OF OPERATIONS

[0000950123-11-096775:8k_2_02:30]
(In thousands, except per share data)

[0000950123-11-096775:8k_2_02:31]
|  |  | Three months ended |  |  | Six months ended |  |
|  |  | September 30, |  |  | September 30, |  |
|  |  | 2011 |  |  | 2010 |  |  | 2011 |  |  | 2010 |  |
| Revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Wind |  | $ | 13,449 |  |  | $ | 89,316 |  |  | $ | 17,712 |  |  | $ | 172,323 |  |
| Grid |  |  | 7,351 |  |  |  | 8,757 |  |  |  | 12,146 |  |  |  | 22,960 |  |
| Total revenues |  |  | 20,800 |  |  |  | 98,073 |  |  |  | 29,858 |  |  |  | 195,283 |  |
| Cost of revenues |  |  | 21,937 |  |  |  | 59,416 |  |  |  | 38,892 |  |  |  | 117,640 |  |
| Gross profit |  |  | (1,137 | ) |  |  | 38,657 |  |  |  | (9,034 | ) |  |  | 77,643 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Research and development |  |  | 7,276 |  |  |  | 7,857 |  |  |  | 15,411 |  |  |  | 15,192 |  |
| Selling, general and administrative |  |  | 17,560 |  |  |  | 17,346 |  |  |  | 39,550 |  |  |  | 32,529 |  |
| Write-off of advance payment |  |  | 20,551 |  |  |  | — |  |  |  | 20,551 |  |  |  | — |  |
| Amortization of acquisition related intangibles |  |  | 300 |  |  |  | 374 |  |  |  | 604 |  |  |  | 762 |  |
| Restructuring and impairments |  |  | 4,301 |  |  |  | — |  |  |  | 4,301 |  |  |  | — |  |
| Total operating expenses |  |  | 49,988 |  |  |  | 25,577 |  |  |  | 80,417 |  |  |  | 48,483 |  |
| Operating (loss) income |  |  | (51,125 | ) |  |  | 13,080 |  |  |  | (89,451 | ) |  |  | 29,160 |  |
| Interest income, net |  |  | 2 |  |  |  | 191 |  |  |  | 243 |  |  |  | 367 |  |
| Other income, net |  |  | 355 |  |  |  | 2,448 |  |  |  | 920 |  |  |  | 2,618 |  |
| Income (loss) before income tax expense |  |  | (50,768 | ) |  |  | 15,719 |  |  |  | (88,288 | ) |  |  | 32,145 |  |
| Income tax expense |  |  | 941 |  |  |  | 7,880 |  |  |  | 1,100 |  |  |  | 15,137 |  |
| Net (loss) income |  | $ | (51,709 | ) |  | $ | 7,839 |  |  | $ | (89,388 | ) |  | $ | 17,008 |  |
| Net (loss) income per common share |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | (1.02 | ) |  | $ | 0.17 |  |  | $ | (1.76 | ) |  | $ | 0.37 |  |
| Diluted |  | $ | (1.02 | ) |  | $ | 0.17 |  |  | $ | (1.76 | ) |  | $ | 0.37 |  |
| Weighted average number of common shares outstanding |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  |  | 50,876 |  |  |  | 45,482 |  |  |  | 50,716 |  |  |  | 45,363 |  |
| Diluted |  |  | 50,876 |  |  |  | 46,217 |  |  |  | 50,716 |  |  |  | 46,099 |  |

[0000950123-11-096775:8k_2_02:32]
| AMSC Reports Second Quarter Results |  | Page 5 |

[0000950123-11-096775:8k_2_02:33]
AMERICAN SUPERCONDUCTOR CORPORATION

[0000950123-11-096775:8k_2_02:34]
UNAUDITED CONDENSED CONSOLIDATED BALANCE SHEETS

[0000950123-11-096775:8k_2_02:35]
(In thousands)

[0000950123-11-096775:8k_2_02:36]
|  |  | September 30, |  |  | March 31, |  |
|  |  | 2011 |  |  | 2011 |  |
| ASSETS |  |  |  |  |  |  |  |  |
| Current assets: |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 93,511 |  |  | $ | 123,783 |  |
| Marketable securities |  |  | 5,378 |  |  |  | 116,126 |  |
| Accounts receivable, net |  |  | 18,150 |  |  |  | 15,259 |  |
| Inventory |  |  | 31,284 |  |  |  | 25,828 |  |
| Prepaid expenses and other current assets |  |  | 44,982 |  |  |  | 32,759 |  |
| Restricted cash |  |  | 8,261 |  |  |  | 5,566 |  |
| Deferred tax assets |  |  | 484 |  |  |  | 484 |  |
| Total current assets |  |  | 202,050 |  |  |  | 319,805 |  |
| Property, plant and equipment, net |  |  | 97,509 |  |  |  | 96,494 |  |
| Intangibles, net |  |  | 6,391 |  |  |  | 7,054 |  |
| Restricted cash |  |  | 1,113 |  |  |  | — |  |
| Deferred tax assets |  |  | 5,840 |  |  |  | 5,840 |  |
| Other assets |  |  | 12,825 |  |  |  | 12,016 |  |
| Total assets |  | $ | 325,728 |  |  | $ | 441,209 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |  |  |  |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |  |  |  |
| Accounts payable and accrued expenses |  | $ | 59,609 |  |  | $ | 90,273 |  |
| Adverse purchase commitments |  |  | 34,456 |  |  |  | 38,763 |  |
| Deferred revenue |  |  | 14,196 |  |  |  | 10,304 |  |
| Deferred tax liabilities |  |  | 5,840 |  |  |  | 5,840 |  |
| Total current liabilities |  |  | 114,101 |  |  |  | 145,180 |  |
| Deferred revenue |  |  | 1,904 |  |  |  | 2,181 |  |
| Deferred tax liabilities |  |  | 484 |  |  |  | 484 |  |
| Other |  |  | 1,012 |  |  |  | 509 |  |
| Total liabilities |  |  | 117,501 |  |  |  | 148,354 |  |
| Commitments and contingencies |  |  |  |  |  |  |  |  |
| Stockholders’ equity: |  |  |  |  |  |  |  |  |
| Common stock |  |  | 515 |  |  |  | 507 |  |
| Additional paid-in capital |  |  | 891,845 |  |  |  | 885,704 |  |
| Treasury stock |  |  | (271 | ) |  |  | — |  |
| Accumulated other comprehensive income |  |  | 2,699 |  |  |  | 3,817 |  |
| Accumulated deficit |  |  | (686,561 | ) |  |  | (597,173 | ) |
| Total stockholders’ equity |  |  | 208,227 |  |  |  | 292,855 |  |
| Total liabilities and stockholders’ equity |  | $ | 325,728 |  |  | $ | 441,209 |  |

[0000950123-11-096775:8k_2_02:37]
| AMSC Reports Second Quarter Results |  | Page 6 |

[0000950123-11-096775:8k_2_02:38]
AMERICAN SUPERCONDUCTOR CORPORATION

[0000950123-11-096775:8k_2_02:39]
UNAUDITED CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS

[0000950123-11-096775:8k_2_02:40]
(In thousands)

[0000950123-11-096775:8k_2_02:41]
|  |  | Six months ended September 30, |  |
|  |  | 2011 |  |  | 2010 |  |
| Cash flows from operating activities: |  |  |  |  |  |  |  |  |
| Net (loss) income |  | $ | (89,388 | ) |  | $ | 17,008 |  |
| Adjustments to reconcile net (loss) income to net cash used in operations: |  |  |  |  |  |  |  |  |
| Depreciation and amortization |  |  | 6,670 |  |  |  | 5,428 |  |
| Stock-based compensation expense |  |  | 5,579 |  |  |  | 8,006 |  |
| Provision for excess and obsolete inventory |  |  | 1,503 |  |  |  | 580 |  |
| Adverse purchase commitment losses, net |  |  | 167 |  |  |  | — |  |
| Allowance for doubtful accounts |  |  | — |  |  |  | (4 | ) |
| Write-off of advance payment |  |  | 20,551 |  |  |  | — |  |
| Write-off of prepaid value added taxes |  |  | — |  |  |  | 431 |  |
| Restructuring charges |  |  | 2,174 |  |  |  | — |  |
| Impairment of long-lived assets |  |  | 918 |  |  |  | — |  |
| Deferred income taxes |  |  | — |  |  |  | (793 | ) |
| Other non-cash items |  |  | 1,792 |  |  |  | 1,107 |  |
| Changes in operating asset and liability accounts: |  |  |  |  |  |  |  |  |
| Accounts receivable |  |  | (3,709 | ) |  |  | (32,504 | ) |
| Inventory |  |  | (6,800 | ) |  |  | (10,348 | ) |
| Prepaid expenses and other current assets |  |  | (12,529 | ) |  |  | (6,620 | ) |
| Accounts payable and accrued expenses |  |  | (37,633 | ) |  |  | 8,011 |  |
| Deferred revenue |  |  | 3,809 |  |  |  | 7,820 |  |
| Net cash used in operating activities |  |  | (106,896 | ) |  |  | (1,878 | ) |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |
| Purchase of property, plant and equipment |  |  | (7,303 | ) |  |  | (17,950 | ) |
| Purchase of marketable securities |  |  | — |  |  |  | (25,283 | ) |
| Proceeds from maturities of marketable securities |  |  | 111,070 |  |  |  | 15,482 |  |
| Change in restricted cash |  |  | (3,781 | ) |  |  | 253 |  |
| Purchase of intangible assets |  |  | (768 | ) |  |  | (1,615 | ) |
| Purchase of minority investments |  |  | (1,800 | ) |  |  | (8,000 | ) |
| Advance payment for previously planned acquisition |  |  | (20,551 | ) |  |  | — |  |
| Change in other assets |  |  | (639 | ) |  |  | (182 | ) |
| Net cash provided by (used in) investing activities |  |  | 76,228 |  |  |  | (37,295 | ) |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |
| Payments in lieu of issuance of common stock for payroll taxes |  |  | (271 | ) |  |  | — |  |
| Proceeds from exercise of employee stock options and ESPP |  |  | 150 |  |  |  | 1,574 |  |
| Net cash (used in) provided by financing activities |  |  | (121 | ) |  |  | 1,574 |  |
| Effect of exchange rate changes on cash and cash equivalents |  |  | 517 |  |  |  | 2,620 |  |
| Net decrease in cash and cash equivalents |  |  | (30,272 | ) |  |  | (34,979 | ) |
| Cash and cash equivalents at beginning of period |  |  | 123,783 |  |  |  | 87,594 |  |
| Cash and cash equivalents at end of period |  | $ | 93,511 |  |  | $ | 52,615 |  |
| Supplemental schedule of cash flow information: |  |  |  |  |  |  |  |  |
| Cash paid for income taxes |  |  | 18,147 |  |  | $ | 10,003 |  |
| Non-cash contingent consideration in connection with acquisitions |  |  | — |  |  |  | 6,925 |  |
| Non-cash issuance of common stock |  |  | 421 |  |  |  | 419 |  |

[0000950123-11-096775:8k_2_02:42]
| AMSC Reports Second Quarter Results |  | Page 7 |

[0000950123-11-096775:8k_2_02:43]
AMERICAN SUPERCONDUCTOR CORPORATION

[0000950123-11-096775:8k_2_02:44]
Reconciliation of GAAP Net (Loss) Income to Non-GAAP Net (Loss) Income

[0000950123-11-096775:8k_2_02:45]
(In thousands, except per share data)

[0000950123-11-096775:8k_2_02:46]
|  |  | Three months ended |  |  | Six months ended |  |
|  |  | September 30, |  |  | September 30, |  |
|  |  | 2011 |  |  | 2010 |  |  | 2011 |  |  | 2010 |  |
| Net (loss) income |  | $ | (51,709 | ) |  | $ | 7,839 |  |  | $ | (89,388 | ) |  | $ | 17,008 |  |
| Write-off of advance payment |  |  | 20,551 |  |  |  | — |  |  |  | 20,551 |  |  |  | — |  |
| Stock-based compensation |  |  | 2,113 |  |  |  | 4,326 |  |  |  | 5,579 |  |  |  | 7,825 |  |
| Restructuring and impairment charges |  |  | 4,301 |  |  |  | — |  |  |  | 4,301 |  |  |  | — |  |
| Executive severance |  |  | — |  |  |  | — |  |  |  | 2,066 |  |  |  | — |  |
| Sinovel litigation |  |  | 3,334 |  |  |  | — |  |  |  | 3,334 |  |  |  | — |  |
| Provision for excess and obsolete inventory |  |  | — |  |  |  | 580 |  |  |  | — |  |  |  | 580 |  |
| Adverse purchase commitment (recoveries) losses, net |  |  | (904 | ) |  |  | — |  |  |  | 167 |  |  |  | — |  |
| Margin on zero cost-basis inventory |  |  | (127 | ) |  |  | — |  |  |  | (127 | ) |  |  | — |  |
| Value-added tax write-off |  |  | — |  |  |  | 221 |  |  |  | — |  |  |  | 432 |  |
| Amortization of acquisition-related intangibles |  |  | 300 |  |  |  | 374 |  |  |  | 604 |  |  |  | 762 |  |
| Tax effects |  |  | — |  |  |  | (84 | ) |  |  | — |  |  |  | (167 | ) |
| Non-GAAP net (loss) income |  | $ | (22,141 | ) |  | $ | 13,256 |  |  | $ | (52,913 | ) |  | $ | 26,440 |  |
| Non-GAAP (loss) earnings per share |  | $ | (0.44 | ) |  | $ | 0.29 |  |  | $ | (1.04 | ) |  | $ | 0.57 |  |
| Weighted average shares outstanding * |  |  | 50,876 |  |  |  | 46,217 |  |  |  | 50,716 |  |  |  | 46,099 |  |

[0000950123-11-096775:8k_2_02:47]
| * |  | Diluted shares are used for periods where net income is generated. |

[0000950123-11-096775:8k_2_02:48]
AMERICAN SUPERCONDUCTOR CORPORATION

[0000950123-11-096775:8k_2_02:49]
Reconciliation of Forecast GAAP Net Loss to Non-GAAP Net Loss

[0000950123-11-096775:8k_2_02:50]
(In millions, except per share data)

[0000950123-11-096775:8k_2_02:51]
|  |  | Three months ending |  |
|  |  | December 31, 2011 |  |
| Net loss |  | $ | (30.0 | ) |
| Amortization of acquisition-related intangibles |  |  | 0.3 |  |
| Stock-based compensation |  |  | 2.7 |  |
| Sinovel litigation expenses |  |  | 3.0 |  |
| Tax effects |  |  | — |  |
| Non-GAAP net loss |  | $ | (24.0 | ) |
| Non-GAAP net loss per share |  | $ | (0.47 | ) |
| Shares outstanding |  |  | 51.0 |  |

[0000950123-11-096775:8k_2_02:52]
Note: Non-GAAP net income (loss) is defined by the company as net income (loss) before amortization
of acquisition-related intangibles, restructuring and impairments, stock-based compensation,
severance and other unusual charges, and any tax effects related to these items. The company
believes non-GAAP net income (loss) assists management and investors in comparing the company’s
performance across reporting periods on a consistent basis by excluding these non-cash or
non-recurring charges that it does not believe are indicative of its core operating performance.
The company also regards non-GAAP net income (loss) as a useful measure of operating performance
and cash flow to complement operating income, net income

[0000950123-11-096775:8k_2_02:53]
| AMSC Reports Second Quarter Results |  | Page 8 |

[0000950123-11-096775:8k_2_02:54]
(loss) and other GAAP financial
performance measures. In addition, the company uses non-GAAP net (loss) income as a factor in
evaluating management’s performance when determining incentive compensation and to evaluate the
effectiveness of its business strategies.

[0000950123-11-096775:8k_2_02:55]
Generally, a non-GAAP financial measure is a numerical measure of a company’s performance,
financial position or cash flow that either excludes or includes amounts that are not normally
excluded or included in the most directly comparable measure calculated and presented in accordance
with GAAP. The non-GAAP measures included in this release, however, should be considered in
addition to, and not as a substitute for or superior to, operating income, cash flows, or other
measures of financial performance prepared in accordance with GAAP. A reconciliation of non-GAAP to
GAAP net income is set forth in the table above.
