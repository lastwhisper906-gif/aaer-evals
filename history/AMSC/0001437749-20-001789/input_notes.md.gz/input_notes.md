# AMSC notes — 0001437749-20-001789


## amsc:AccountsReceivableTableTextBlock

[0001437749-20-001789:notes:1]
|  |  | December 31, 2019 |  |  | March 31, 2019 |  |
| Accounts receivable (billed) |  | $ | 11,878 |  |  | $ | 5,642 |  |
| Accounts receivable (unbilled) |  |  | 4,613 |  |  |  | 2,213 |  |
| Accounts receivable, net |  | $ | 16,491 |  |  | $ | 7,855 |  |


## amsc:AccountsReceivableTextBlock

[0001437749-20-001789:notes:2]
[same as prior period, unchanged from 0001437749-19-021592:notes:2]

[0001437749-20-001789:notes:3]
[same as prior period, unchanged from 0001437749-19-021592:notes:3]

[0001437749-20-001789:notes:4]
December 31, 2019

[0001437749-20-001789:notes:5]
[same as prior period, unchanged from 0001437749-19-021592:notes:5]

[0001437749-20-001789:notes:6]
[same as prior period, unchanged from 0001437749-19-021592:notes:6]

[0001437749-20-001789:notes:7]
[same as prior period, unchanged from 0001437749-19-021592:notes:7]


## amsc:AssetsAndLiabilitiesLesseeTableTextBlock

[0001437749-20-001789:notes:8]
|  |  | December 31, 2019 |  |
| Operating Leases: |  |  |  |  |
| Right-of-use assets |  | $ | 3,495 |  |
| Total right-of-use assets |  |  | 3,495 |  |
| Lease liabilities - ST |  | $ | 436 |  |
| Lease liabilities - LT |  |  | 3,128 |  |
| Total operating lease liabilities |  |  | 3,564 |  |
| Weighted-average remaining lease term |  |  | 7.1 years |  |
| Weighted-average discount rate |  |  | 7.07 | % |


## amsc:LiquidityPolicyPolicyTextBlock

[0001437749-20-001789:notes:9]
[same as prior period, unchanged from 0001437749-19-021592:notes:9]

[0001437749-20-001789:notes:10]
[same as prior period, unchanged from 0001437749-19-021592:notes:10]

[0001437749-20-001789:notes:11]
[same as prior period, unchanged from 0001437749-19-021592:notes:11]

[0001437749-20-001789:notes:12]
972.7

[0001437749-20-001789:notes:13]
[same as prior period, unchanged from 0001437749-19-021592:notes:13]

[0001437749-20-001789:notes:14]
[same as prior period, unchanged from 0001437749-19-021592:notes:14]

[0001437749-20-001789:notes:15]
60.5

[0001437749-20-001789:notes:16]
million, with 
no
 outstanding debt other than ordinary trade payables. Marketable securities include certificate of deposits with maturities between 
eleven
 and 
twenty-four
 months.  Cash used in operations for the

[0001437749-20-001789:notes:17]
nine

[0001437749-20-001789:notes:18]
[same as prior period, unchanged from 0001437749-19-021592:notes:18]

[0001437749-20-001789:notes:19]
[same as prior period, unchanged from 0001437749-19-021592:notes:19]

[0001437749-20-001789:notes:20]
17.8

[0001437749-20-001789:notes:21]
[same as prior period, unchanged from 0001437749-19-021592:notes:21]

[0001437749-20-001789:notes:22]
[same as prior period, unchanged from 0001437749-19-021592:notes:22]

[0001437749-20-001789:notes:23]
[same as prior period, unchanged from 0001437749-19-021592:notes:23]

[0001437749-20-001789:notes:24]
2018,
 the Company and its wholly-owned subsidiaries Suzhou AMSC Superconductor Co. Ltd. (“AMSC China”) and AMSC Austria GMBH (“AMSC Austria”) entered into a settlement agreement (the “Settlement Agreement”) with Sinovel Wind Group Co., Ltd. (“Sinovel”). The Settlement Agreement settles the litigation and arbitration proceedings between the Company and Sinovel. Under the terms of the Settlement Agreement, Sinovel agreed to pay AMSC China an aggregate cash amount in Renminbi (“RMB”) equivalent to 
$57.5
 million, consisting of 
two
 installments. Sinovel paid the 
first
 installment of the RMB equivalent of 
$32.5
 million on 
 July

[0001437749-20-001789:notes:25]
[same as prior period, unchanged from 0001437749-19-021592:notes:25]

[0001437749-20-001789:notes:26]
[same as prior period, unchanged from 0001437749-19-021592:notes:26]

[0001437749-20-001789:notes:27]
[same as prior period, unchanged from 0001437749-19-021592:notes:27]

[0001437749-20-001789:notes:28]
[same as prior period, unchanged from 0001437749-19-021592:notes:28]

[0001437749-20-001789:notes:29]
[same as prior period, unchanged from 0001437749-19-021592:notes:29]

[0001437749-20-001789:notes:30]
[same as prior period, unchanged from 0001437749-19-021592:notes:30]

[0001437749-20-001789:notes:31]
[same as prior period, unchanged from 0001437749-19-021592:notes:31]

[0001437749-20-001789:notes:32]
[same as prior period, unchanged from 0001437749-19-021592:notes:32]

[0001437749-20-001789:notes:33]
The Company issued warrants in conjunction with an equity offering to Hudson Bay Capital ("Hudson") in 
 November 2014 (
the "Hudson Warrant").  The Hudson Warrant was partially exercised on 
 November 13, 2019 
with an exercise price of 
$7.81.
 The Company received 
$6.1
 million in cash for 
786,000
 warrants. The remaining 
32,181
 warrants expired on 
 November 13, 2019.

[0001437749-20-001789:notes:34]
[same as prior period, unchanged from 0001437749-19-021592:notes:33]

[0001437749-20-001789:notes:35]
[same as prior period, unchanged from 0001437749-19-021592:notes:34]


## amsc:NatureOfBusinessAndOperationsPolicyPolicyTextBlock

[0001437749-20-001789:notes:36]
[same as prior period, unchanged from 0001437749-19-021592:notes:35]

[0001437749-20-001789:notes:37]
American Superconductor Corporation (together with its subsidiaries, “AMSC®” or the “Company”) was founded on 
 April

[0001437749-20-001789:notes:38]
[same as prior period, unchanged from 0001437749-19-021592:notes:37]

[0001437749-20-001789:notes:39]
[same as prior period, unchanged from 0001437749-19-021592:notes:38]

[0001437749-20-001789:notes:40]
[same as prior period, unchanged from 0001437749-19-021592:notes:39]

[0001437749-20-001789:notes:41]
[same as prior period, unchanged from 0001437749-19-021592:notes:40]

[0001437749-20-001789:notes:42]
[same as prior period, unchanged from 0001437749-19-021592:notes:41]

[0001437749-20-001789:notes:43]
[same as prior period, unchanged from 0001437749-19-021592:notes:42]

[0001437749-20-001789:notes:44]
[same as prior period, unchanged from 0001437749-19-021592:notes:43]

[0001437749-20-001789:notes:45]
[same as prior period, unchanged from 0001437749-19-021592:notes:44]


## amsc:NotesReceivableTableTextBlock

[0001437749-20-001789:notes:46]
| Current assets |  | December 31, 2019 |  |  | March 31, 2019 |  |
| Note receivable, current |  | $ | — |  |  | $ | 3,000 |  |
| Note receivable discount |  |  | — |  |  |  | (112 | ) |
| Total current note receivable |  | $ | — |  |  | $ | 2,888 |  |


## amsc:NotesReceivableTextBlock

[0001437749-20-001789:notes:47]
[same as prior period, unchanged from 0001437749-19-021592:notes:46]

[0001437749-20-001789:notes:48]
[same as prior period, unchanged from 0001437749-19-021592:notes:47]

[0001437749-20-001789:notes:49]
[same as prior period, unchanged from 0001437749-19-021592:notes:48]

[0001437749-20-001789:notes:50]
The note receivable was discounted to its present value of 
$5.7
 million utilizing a discount rate of 
6%,
 which was based on management’s assessment of what an appropriate loan at current market rates would be. The 
$0.3
 million discount was recorded as an offset to the long-term portion of the note receivable. In addition, the resulting gain of 
$0.1
 million from the sale of the Devens property which was deferred previously was recorded as a component of the cumulative effect of an accounting change upon the adoption of Accounting Standards Update ("ASU") 
2017
-
05

[0001437749-20-001789:notes:51]
[same as prior period, unchanged from 0001437749-19-021592:notes:50]

[0001437749-20-001789:notes:52]
[same as prior period, unchanged from 0001437749-19-021592:notes:51]

[0001437749-20-001789:notes:53]
[same as prior period, unchanged from 0001437749-19-021592:notes:52]


## us-gaap:AccountsPayableAndAccruedLiabilitiesDisclosureTextBlock

[0001437749-20-001789:notes:54]
[same as prior period, unchanged from 0001437749-19-021592:notes:53]

[0001437749-20-001789:notes:55]
[same as prior period, unchanged from 0001437749-19-021592:notes:54]

[0001437749-20-001789:notes:56]
|  |  | December 31, 2019 |  |  | March 31, 2019 |  |
| Accounts payable |  | $ | 7,349 |  |  | $ | 2,939 |  |
| Accrued inventories in-transit |  |  | 894 |  |  |  | 244 |  |
| Accrued other miscellaneous expenses |  |  | 2,588 |  |  |  | 1,759 |  |
| Advanced deposits |  |  | 986 |  |  |  | 631 |  |
| Accrued compensation |  |  | 4,448 |  |  |  | 5,404 |  |
| Income taxes payable |  |  | 1,408 |  |  |  | 3,363 |  |
| Accrued product warranty |  |  | 1,706 |  |  |  | 1,545 |  |
| Total |  | $ | 19,379 |  |  | $ | 15,885 |  |

[0001437749-20-001789:notes:57]
The Company generally provides a 
one
 to 
two
 year warranty on its products, commencing upon delivery or installation where applicable. A provision is recorded upon revenue recognition to cost of revenues for estimated warranty expense based on historical experience.

[0001437749-20-001789:notes:58]
[same as prior period, unchanged from 0001437749-19-021592:notes:57]

[0001437749-20-001789:notes:59]
|  |  | Three Months Ended December 31, |  |  | Nine Months Ended December 31, |  |
|  |  | 2019 |  |  | 2018 |  |  | 2019 |  |  | 2018 |  |
| Balance at beginning of period |  | $ | 1,641 |  |  | $ | 1,760 |  |  | $ | 1,545 |  |  | $ | 1,769 |  |
| Change in accruals for warranties during the period |  |  | 93 |  |  |  | 260 |  |  |  | 247 |  |  |  | 577 |  |
| Settlements during the period |  |  | (28 | ) |  |  | (524 | ) |  |  | (86 | ) |  |  | (850 | ) |
| Balance at end of period |  | $ | 1,706 |  |  | $ | 1,496 |  |  | $ | 1,706 |  |  | $ | 1,496 |  |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001437749-20-001789:notes:60]
15.
 Commitments and Contingencies

[0001437749-20-001789:notes:61]
Legal Contingencies

[0001437749-20-001789:notes:62]
From time to time, the Company is involved in legal and administrative proceedings and claims of various types. The Company records a liability in its consolidated financial statements for these matters when a loss is known or considered probable and the amount can be reasonably estimated. The Company reviews these estimates each accounting period as additional information is known and adjusts the loss provision when appropriate. If a matter is both probable to result in a liability and the amounts of loss can be reasonably estimated, the Company estimates and discloses the possible loss or range of loss to the extent necessary to make the consolidated financial statements 
not
 misleading. If the loss is 
not
 probable or cannot be reasonably estimated, a liability is 
not
 recorded in its consolidated financial statements.

[0001437749-20-001789:notes:63]
Other

[0001437749-20-001789:notes:64]
The Company enters into long-term construction contracts with customers that require the Company to obtain performance bonds. The Company is required to deposit an amount equivalent to some or all the face amount of the performance bonds into an escrow account until the termination of the bond. When the performance conditions are met, amounts deposited as collateral for the performance bonds are returned to the Company. In addition, the Company has various contractual arrangements in which minimum quantities of goods or services have been committed to be purchased on an annual basis.

[0001437749-20-001789:notes:65]
As of

[0001437749-20-001789:notes:66]
, the Company had $

[0001437749-20-001789:notes:67]
5.8

[0001437749-20-001789:notes:68]
million of restricted cash included in long-term assets. These amounts included in restricted cash primarily represent deposits to secure letters of credit for various supply contracts. These deposits are held in interest bearing accounts.  As part of the agreement with Commonwealth Edison Company to install the Resilient Electric Grid ("REG") system in Chicago, the Company agreed to deliver an irrevocable letter of credit in the amount of 
$5.0
 million to secure certain Company obligations under the Subcontract Agreement.  The funds to secure the 
$5.0
 million letter of credit were deposited in an escrow account on 
 July 1, 2019.


## us-gaap:ContractWithCustomerAssetAndLiabilityTableTextBlock

[0001437749-20-001789:notes:69]
|  |  | Unbilled Accounts Receivable |  |  | Deferred Program Costs |  |  | Contract Liabilities |  |
| Beginning balance as of March 31, 2019 |  | $ | 2,213 |  |  | $ | 318 |  |  | $ | 15,519 |  |
| Increases for costs incurred to fulfill performance obligations |  |  | — |  |  |  | 3,001 |  |  |  | — |  |
| Increase (decrease) due to customer billings |  |  | (7,417 | ) |  |  | — |  |  |  | 36,461 |  |
| Decrease due to cost recognition on completed performance obligations |  |  | — |  |  |  | (2,221 | ) |  |  | — |  |
| Increase (decrease) due to recognition of revenue based on transfer of control of performance obligations |  |  | 9,820 |  |  |  | — |  |  |  | (28,768 | ) |
| Other changes and FX impact |  |  | (3 | ) |  |  | (1 | ) |  |  | (69 | ) |
| Ending balance as of December 31, 2019 |  | $ | 4,613 |  |  | $ | 1,097 |  |  | $ | 23,143 |  |

[0001437749-20-001789:notes:70]
|  |  | Unbilled Accounts Receivable |  |  | Deferred Program Costs |  |  | Contract Liabilities |  |
| Beginning balance as of March 31, 2018 |  | $ | 3,016 |  |  | $ | 2,567 |  |  | $ | 21,937 |  |
| Impact of adoption of ASC 606 |  |  | — |  |  |  | (1,599 | ) |  |  | (2,657 | ) |
| Increases for costs incurred to fulfill performance obligations |  |  | — |  |  |  | 1,461 |  |  |  | — |  |
| Increase (decrease) due to customer billings |  |  | (11,063 | ) |  |  | — |  |  |  | 11,167 |  |
| Decrease due to cost recognition on completed performance obligations |  |  | — |  |  |  | (1,132 | ) |  |  | — |  |
| Increase (decrease) due to recognition of revenue based on transfer of control of performance obligations |  |  | 9,722 |  |  |  | (9 | ) |  |  | (11,345 | ) |
| Other changes and FX impact |  |  | (53 | ) |  |  | 8 |  |  |  | (1,040 | ) |
| Ending balance as of December 31, 2018 |  | $ | 1,622 |  |  | $ | 1,296 |  |  | $ | 18,062 |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001437749-20-001789:notes:71]
[same as prior period, unchanged from 0001437749-19-021592:notes:70]

[0001437749-20-001789:notes:72]
[same as prior period, unchanged from 0001437749-19-021592:notes:71]

[0001437749-20-001789:notes:73]
[same as prior period, unchanged from 0001437749-19-021592:notes:72]

[0001437749-20-001789:notes:74]
On 
 December 19, 2014, 
the Company entered into a 
second
 amendment to the Loan and Security Agreement with Hercules (the "Hercules Second Amendment"). In conjunction with the Hercules Second Amendment, the Company issued Hercules a warrant to purchase 
58,823
 shares of the Company’s common stock (the "Hercules Warrant") which replaced the First Warrant and the Second Warrant.  The Hercules Warrant was exercisable at any time after its issuance at an exercise price of 
$7.85
 per share, subject to certain price-based and other anti-dilution adjustments, including the equity offering in 
 May 2017, 
the acquisition of ITC with common stock in 
 September 2017 
and sales of common stock under the ATM entered into in 
 January 2017.  
This warrant had a fair value of 
$0.4
 million as of 
 March 31, 2019.  
On 
 April 8, 2019, 
Hercules notified the Company of its intent to exercise this warrant on a cashless basis.  Hercules received 
22,821
 shares of the Company's common stock on 
 April 17, 2019.  
As a result of this exercise the Company recorded a net gain of 
$0.1
 million to change in fair value of warrants, resulting from the decrease in the fair value of the Hercules Warrant during the 
nine
 months ended 
 December 31, 2019.  
The Company recorded a net loss of 
$0.2
 million to change in fair value of warrants, resulting from the increase in the fair value of the Hercules Warrant during the 
nine
 months ended 
 December 31, 2018.

[0001437749-20-001789:notes:75]
[same as prior period, unchanged from 0001437749-19-021592:notes:75]

[0001437749-20-001789:notes:76]
On 
 November 13, 2014, 
the Company completed an offering of 
909,090
 units of the Company’s common stock with Hudson Bay Capital. Each unit consisted of 
one
 share of the Company’s common stock and 
0.9
 of a warrant to purchase 
one
 share of common stock, or a warrant to purchase in the aggregate 
818,181
 shares (the 
 “November 2014 
Warrant”).  The 
 November 2014 
Warrant is exercisable at any time, at an exercise price equal to 
$7.81
 per share, subject to certain price-based and other anti-dilution adjustments including those noted above.  On 
 November 13, 2019, 
Hudson partially exercised the 
 November 2014 
Warrant for 
786,000
 restricted shares of Company common stock at 
$7.81
 per share
.  
The remaining 
32,181
 warrants expired on

[0001437749-20-001789:notes:77]
November 13, 2019
. 
As a result of this exercise the Company recorded net gains of 
$0.5
 million and 
$4.6
 million to change in fair value of warrants, resulting from the decrease in the fair value of the Hudson Warrant during the 
three
 and

[0001437749-20-001789:notes:78]
, respectively.  As of 
 December 31, 2019, 
the Company has 
no
 remaining outstanding warrants

[0001437749-20-001789:notes:79]
[same as prior period, unchanged from 0001437749-19-021592:notes:79]

[0001437749-20-001789:notes:80]
[same as prior period, unchanged from 0001437749-19-021592:notes:80]

[0001437749-20-001789:notes:81]
[same as prior period, unchanged from 0001437749-19-021592:notes:81]

[0001437749-20-001789:notes:82]
[same as prior period, unchanged from 0001437749-19-021592:notes:82]

[0001437749-20-001789:notes:83]
0.6

[0001437749-20-001789:notes:84]
[same as prior period, unchanged from 0001437749-19-021592:notes:84]

[0001437749-20-001789:notes:85]
4.6

[0001437749-20-001789:notes:86]
[same as prior period, unchanged from 0001437749-19-021592:notes:86]

[0001437749-20-001789:notes:87]
three
 and 
nine

[0001437749-20-001789:notes:88]
, respectively. The Company recorded net losses of 
$2.3
 million and 
$2.5
 million resulting from the increase in the fair value of the 
 November 2014 
Warrant during the

[0001437749-20-001789:notes:89]
December 31, 2018

[0001437749-20-001789:notes:90]
[same as prior period, unchanged from 0001437749-19-021592:notes:90]


## us-gaap:DisaggregationOfRevenueTableTextBlock

[0001437749-20-001789:notes:91]
|  |  | Three Months Ended December 31, 2019 |  |  | Nine Months Ended December 31, 2019 |  |
| Product Line: |  | Grid |  |  | Wind |  |  | Grid |  |  | Wind |  |
| Equipment and systems |  | $ | 14,040 |  |  | $ | 2,160 |  |  | $ | 32,438 |  |  | $ | 7,742 |  |
| Services and technology development |  |  | 1,192 |  |  |  | 523 |  |  |  | 4,139 |  |  |  | 1,379 |  |
| Total |  | $ | 15,232 |  |  | $ | 2,683 |  |  | $ | 36,577 |  |  | $ | 9,120 |  |
| Region: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas |  | $ | 10,164 |  |  | $ | 2 |  |  | $ | 28,663 |  |  | $ | 49 |  |
| Asia Pacific |  |  | 330 |  |  |  | 2,647 |  |  |  | 2,550 |  |  |  | 8,968 |  |
| EMEA |  |  | 4,738 |  |  |  | 34 |  |  |  | 5,364 |  |  |  | 104 |  |
| Total |  | $ | 15,232 |  |  | $ | 2,683 |  |  | $ | 36,577 |  |  | $ | 9,120 |  |

[0001437749-20-001789:notes:92]
|  |  | Three Months Ended December 31, 2018 |  |  | Nine Months Ended December 31, 2018 |  |
| Product Line: |  | Grid |  |  | Wind |  |  | Grid |  |  | Wind |  |
| Equipment and systems |  | $ | 4,614 |  |  | $ | 7,215 |  |  | $ | 17,571 |  |  | $ | 17,925 |  |
| Services and technology development |  |  | 2,212 |  |  |  | 93 |  |  |  | 5,754 |  |  |  | 368 |  |
| Total |  | $ | 6,826 |  |  | $ | 7,308 |  |  | $ | 23,325 |  |  | $ | 18,293 |  |
| Region: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas |  | $ | 3,771 |  |  | $ | 36 |  |  | $ | 16,319 |  |  | $ | 82 |  |
| Asia Pacific |  |  | 2,815 |  |  |  | 7,263 |  |  |  | 5,930 |  |  |  | 18,136 |  |
| EMEA |  |  | 240 |  |  |  | 9 |  |  |  | 1,076 |  |  |  | 75 |  |
| Total |  | $ | 6,826 |  |  | $ | 7,308 |  |  | $ | 23,325 |  |  | $ | 18,293 |  |


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001437749-20-001789:notes:93]
[same as prior period, unchanged from 0001437749-19-021592:notes:93]

[0001437749-20-001789:notes:94]
[same as prior period, unchanged from 0001437749-19-021592:notes:94]

[0001437749-20-001789:notes:95]
[same as prior period, unchanged from 0001437749-19-021592:notes:95]

[0001437749-20-001789:notes:96]
|  |  | Three Months Ended December 31, |  |  | Nine Months Ended December 31, |  |
|  |  | 2019 |  |  | 2018 |  |  | 2019 |  |  | 2018 |  |
| Cost of revenues |  | $ | 21 |  |  | $ | 42 |  |  | $ | 45 |  |  | $ | 132 |  |
| Research and development |  |  | 117 |  |  |  | 168 |  |  |  | 219 |  |  |  | 289 |  |
| Selling, general and administrative |  |  | 452 |  |  |  | 582 |  |  |  | 971 |  |  |  | 1,981 |  |
| Total |  | $ | 590 |  |  | $ | 792 |  |  | $ | 1,236 |  |  | $ | 2,402 |  |

[0001437749-20-001789:notes:97]
[same as prior period, unchanged from 0001437749-19-021592:notes:97]

[0001437749-20-001789:notes:98]
[same as prior period, unchanged from 0001437749-19-021592:notes:98]

[0001437749-20-001789:notes:99]
[same as prior period, unchanged from 0001437749-19-021592:notes:99]

[0001437749-20-001789:notes:100]
366,000

[0001437749-20-001789:notes:101]
[same as prior period, unchanged from 0001437749-19-021592:notes:101]

[0001437749-20-001789:notes:102]
and issued 
4

[0001437749-20-001789:notes:103]
7,075

[0001437749-20-001789:notes:104]
463,000

[0001437749-20-001789:notes:105]
[same as prior period, unchanged from 0001437749-19-021592:notes:105]

[0001437749-20-001789:notes:106]
[same as prior period, unchanged from 0001437749-19-021592:notes:106]

[0001437749-20-001789:notes:107]
[same as prior period, unchanged from 0001437749-19-021592:notes:107]

[0001437749-20-001789:notes:108]
[same as prior period, unchanged from 0001437749-19-021592:notes:108]

[0001437749-20-001789:notes:109]
[same as prior period, unchanged from 0001437749-19-021592:notes:109]

[0001437749-20-001789:notes:110]
[same as prior period, unchanged from 0001437749-19-021592:notes:114]

[0001437749-20-001789:notes:111]
[same as prior period, unchanged from 0001437749-19-021592:notes:111]

[0001437749-20-001789:notes:112]
3.9

[0001437749-20-001789:notes:113]
[same as prior period, unchanged from 0001437749-19-021592:notes:113]

[0001437749-20-001789:notes:114]
[same as prior period, unchanged from 0001437749-19-021592:notes:115]

[0001437749-20-001789:notes:115]
[same as prior period, unchanged from 0001437749-19-021592:notes:116]

[0001437749-20-001789:notes:116]
[same as prior period, unchanged from 0001437749-19-021592:notes:117]

[0001437749-20-001789:notes:117]
[same as prior period, unchanged from 0001437749-19-021592:notes:118]

[0001437749-20-001789:notes:118]
.  The Company did

[0001437749-20-001789:notes:119]
not

[0001437749-20-001789:notes:120]
grant any stock options during the 
three
 months ended

[0001437749-20-001789:notes:121]
[same as prior period, unchanged from 0001437749-19-021592:notes:120]

[0001437749-20-001789:notes:122]
[same as prior period, unchanged from 0001437749-19-021592:notes:121]

[0001437749-20-001789:notes:123]
[same as prior period, unchanged from 0001437749-19-021592:notes:122]

[0001437749-20-001789:notes:124]
[same as prior period, unchanged from 0001437749-19-021592:notes:123]

[0001437749-20-001789:notes:125]
[same as prior period, unchanged from 0001437749-19-021592:notes:124]

[0001437749-20-001789:notes:126]
|  |  | Three Months Ended December 31, |  |  | Nine Months Ended December 31, |  |
|  |  | 2019 |  |  | 2018 |  |  | 2019 |  |  | 2018 |  |
| Expected volatility |  |  | N/A |  |  |  | N/A |  |  |  | 66.5 | % |  |  | N/A |  |
| Risk-free interest rate |  |  | N/A |  |  |  | N/A |  |  |  | 1.8 | % |  |  | N/A |  |
| Expected life (years) |  |  | N/A |  |  |  | N/A |  |  |  | 5.91 |  |  |  | N/A |  |
| Dividend yield |  | N/A |  |  |  | N/A |  |  | None |  |  |  | N/A |  |


## us-gaap:EarningsPerShareTextBlock

[0001437749-20-001789:notes:127]
[same as prior period, unchanged from 0001437749-19-021592:notes:126]

[0001437749-20-001789:notes:128]
Basic net loss per share (“EPS”) is computed by dividing net loss by the weighted-average number of common shares outstanding for the period. Where applicable, diluted EPS is computed by dividing the net loss by the weighted-average number of common shares and dilutive common equivalent shares outstanding during the period, calculated using the treasury stock method. Common equivalent shares include the effect of restricted stock, exercise of stock options and warrants and contingently issuable shares. Stock options and warrants that are out-of-the-money with exercise prices greater than the average market price of the underlying common shares and shares of performance based restricted stock where the contingency was 
not
 met are excluded from the computation of diluted EPS as the effect of their inclusion would be anti-dilutive.  For the 
three
 months ended

[0001437749-20-001789:notes:129]
[same as prior period, unchanged from 0001437749-19-021592:notes:128]

[0001437749-20-001789:notes:130]
million shares related to outstanding stock options were 
not
 included in the calculation of diluted EPS as they were considered anti-dilutive
.
 For the

[0001437749-20-001789:notes:131]
million shares related to outstanding stock options were 
not
 included in the calculation of diluted EPS as they were considered anti-dilutive. For the 
three
 months ended

[0001437749-20-001789:notes:132]
, 
0.5
 million shares were 
not
 included in the calculation of diluted EPS as they were considered anti-dilutive, of which 
0.3
 million relate to outstanding stock options, and 
0.2
 million relate to outstanding unvested stock awards. For the

[0001437749-20-001789:notes:133]
, 
1.1
 million shares were 
not
 included in the calculation of diluted EPS as they were considered anti-dilutive, of which 
0.3
 million shares relate to outstanding stock options, 
0.6
 million shares relate to outstanding warrants and 
0.2
 million relate to outstanding unvested stock awards.

[0001437749-20-001789:notes:134]
[same as prior period, unchanged from 0001437749-19-021592:notes:133]

[0001437749-20-001789:notes:135]
[same as prior period, unchanged from 0001437749-19-021592:notes:134]

[0001437749-20-001789:notes:136]
|  |  | Three Months Ended December 31, |  |  | Nine Months Ended December 31, |  |
|  |  | 2019 |  |  | 2018 |  |  | 2019 |  |  | 2018 |  |
| Numerator: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net (loss) income |  | $ | (6,845 | ) |  | $ | 17,293 |  |  | $ | (11,209 | ) |  | $ | 35,114 |  |
| Less: decrease in fair value of warrants, net of income tax |  |  | (556 | ) |  |  | 0 |  |  |  | (4,648 | ) |  |  | 0 |  |
| Plus: change in fair value due to exercise of warrants |  |  | 0 |  |  |  | 0 |  |  |  | 83 |  |  |  | 0 |  |
| Net income (loss) - diluted |  | $ | (7,401 | ) |  | $ | 17,293 |  |  | $ | (15,774 | ) |  | $ | 35,114 |  |
| Denominator: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Weighted-average shares of common stock outstanding |  |  | 22,110 |  |  |  | 21,396 |  |  |  | 21,729 |  |  |  | 21,216 |  |
| Weighted-average shares subject to repurchase |  |  | (925 | ) |  |  | (977 | ) |  |  | (943 | ) |  |  | (916 | ) |
| Shares used in per-share calculation ― basic |  |  | 21,185 |  |  |  | 20,419 |  |  |  | 20,786 |  |  |  | 20,300 |  |
| Common stock awards |  |  | 0 |  |  |  | 445 |  |  |  | 0 |  |  |  | 238 |  |
| Common stock warrants |  |  | 18 |  |  |  | 0 |  |  |  | 108 |  |  |  | 0 |  |
| Shares used in per-share calculation ― diluted |  |  | 21,203 |  |  |  | 20,864 |  |  |  | 20,894 |  |  |  | 20,538 |  |
| Net (loss) income per share ― basic |  | $ | (0.32 | ) |  | $ | 0.85 |  |  | $ | (0.54 | ) |  | $ | 1.73 |  |
| Net (loss) income per share ― diluted |  | $ | (0.35 | ) |  | $ | 0.83 |  |  | $ | (0.75 | ) |  | $ | 1.71 |  |

[0001437749-20-001789:notes:137]
For the 
nine
 months ended 
 December 31, 2019, 
the diluted net loss per common share amounts under the treasury stock method were calculated based on the dilutive effect of the total number of shares of common stock related to the Hudson Warrant of 
818,181
 shares with an exerc
ise price of 
$7.81.
  For the 
three
 and 
nine
 month periods ended 
 December 31, 2019, 
the average stock price was 
$8.19
 and 
$9.29
 respectively through 
 November 13, 2019 
when the Hudson Warrant was partially exercised for 
786,000
 shares, providing 
37,962
 and 
130,345
 dilutive shares respectively. The increase of 
$0.6
 million and the decrease of 
$4.6
 million in the fair valu
e of the warrant liability, respectively, is included in the net loss available to common shareholders for the diluted net loss per common share amount when the impact is dilutive.


## us-gaap:FairValueDisclosuresTextBlock

[0001437749-20-001789:notes:138]
[same as prior period, unchanged from 0001437749-19-021592:notes:139]

[0001437749-20-001789:notes:139]
[same as prior period, unchanged from 0001437749-19-021592:notes:140]

[0001437749-20-001789:notes:140]
[same as prior period, unchanged from 0001437749-19-021592:notes:141]

[0001437749-20-001789:notes:141]
[same as prior period, unchanged from 0001437749-19-021592:notes:142]

[0001437749-20-001789:notes:142]
.

[0001437749-20-001789:notes:143]
[same as prior period, unchanged from 0001437749-19-021592:notes:143]

[0001437749-20-001789:notes:144]
[same as prior period, unchanged from 0001437749-19-021592:notes:144]

[0001437749-20-001789:notes:145]
|  |  | Total Carrying Value |  |  | Quoted Prices in Active Markets (Level 1) |  |  | Significant Other Observable Inputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |
| December 31, 2019: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash equivalents |  | $ | 21,230 |  |  | $ | 21,230 |  |  | $ | — |  |  | $ | — |  |
| Marketable securities |  | $ | 35,047 |  |  | $ | 35,047 |  |  | $ | — |  |  | $ | — |  |

[0001437749-20-001789:notes:146]
[same as prior period, unchanged from 0001437749-19-021592:notes:146]

[0001437749-20-001789:notes:147]
[same as prior period, unchanged from 0001437749-19-021592:notes:147]

[0001437749-20-001789:notes:148]
|  |  | Warrants |  |
| April 1, 2019 |  | $ | 4,942 |  |
| Mark to market adjustment |  |  | (4,648 | ) |
| Exercise of in-the-money warrants |  |  | (294 | ) |
| Balance at December 31, 2019 |  | $ | - |  |

[0001437749-20-001789:notes:149]
|  |  | Warrants |  |
| April 1, 2018 |  | $ | 1,217 |  |
| Mark to market adjustment |  |  | 2,658 |  |
| Balance at December 31, 2018 |  | $ | 3,875 |  |

[0001437749-20-001789:notes:150]
[same as prior period, unchanged from 0001437749-19-021592:notes:150]

[0001437749-20-001789:notes:151]
[same as prior period, unchanged from 0001437749-19-021592:notes:151]

[0001437749-20-001789:notes:152]
[same as prior period, unchanged from 0001437749-19-021592:notes:152]

[0001437749-20-001789:notes:153]
[same as prior period, unchanged from 0001437749-19-021592:notes:153]

[0001437749-20-001789:notes:154]
Marketable securities consist of certificates of deposit with maturities of greater than 
12
 months that are measured using such inputs as quoted prices and are classified within Level 
1
 of the valuation hierarchy. The Company determines the appropriate classification of its marketable securities at the time of purchase and re-evaluates such classification as of each balance sheet date.  All marketable securities are considered available for sale and are carried at fair value.   Changes in fair value would be recorded to other income/expense, net.   The Company periodically reviews the realizability of each short and long term marketable security when impairment indicators exist with respect to the security.  If other than temporary impairment of value of the security exists, the carrying value of the security is written down to its estimated fair value.

[0001437749-20-001789:notes:155]
[same as prior period, unchanged from 0001437749-19-021592:notes:155]

[0001437749-20-001789:notes:156]
The Company issued warrants in conjunction with an equity offering to Hudson Bay Capital in 
 November 2014 
and a Loan and Security Agreement with Hercules Technology Growth Capital, Inc. (“Hercules”). The warrants issued to Hercules were exercised on 
 April 8, 2019.  
The warrants issued to Hudson were partially exercised on 
 November 13, 2019 
and the remaining unexercised warrants expired on 
 November 13, 2019.  
As of 
 December 31, 2019 
the Company has 
no
 remaining outstanding warrants.

[0001437749-20-001789:notes:157]
The Company relied on various assumptions in a lattice model to determine the fair value of warrants. The Company had valued the warrants within Level 
3
 of the valuation hierarchy. See Note 
13,
 “Warrants and Derivative Liabilities,” for additional information including a discussion of the warrants and the valuation assumptions used.


## us-gaap:GoodwillDisclosureTextBlock

[0001437749-20-001789:notes:158]
[same as prior period, unchanged from 0001437749-19-021592:notes:158]

[0001437749-20-001789:notes:159]
The Company did

[0001437749-20-001789:notes:160]
identify any triggering events in the

[0001437749-20-001789:notes:161]
[same as prior period, unchanged from 0001437749-19-021592:notes:160]


## us-gaap:IncomeTaxDisclosureTextBlock

[0001437749-20-001789:notes:162]
[same as prior period, unchanged from 0001437749-19-021592:notes:161]

[0001437749-20-001789:notes:163]
The Company recorded an income tax expense of $

[0001437749-20-001789:notes:164]
million and 
$1.6
 million in the 
three
 months ended

[0001437749-20-001789:notes:165]
, respectively.  The Company recorded an income tax expense of less than $

[0001437749-20-001789:notes:166]
million and 
$4.5
 million in the

[0001437749-20-001789:notes:167]
Accounting for income taxes requires a 
two
-step approach to recognizing and measuring uncertain tax positions.  The 
first
 step is to evaluate the tax position for recognition by determining if, based on the technical merits, it is more likely than 
not
 the position will be sustained upon audit, including resolution of related appeals or litigation processes, if any.  The 
second
 step is to measure the tax benefit as the largest amount that is more than 
50%
 likely to be realized upon ultimate settlement.  The Company re-evaluates these uncertain tax positions on a quarterly basis.  The evaluation is based on factors including, but 
not
 limited to, changes in facts or circumstances, changes in tax law, effectively settled issues under audit and new audit activity.  Any changes in these factors could result in the recognition of a tax benefit or an additional charge to the tax provision.  The Company did 
not
 identify any uncertain tax positions in the

[0001437749-20-001789:notes:168]
[same as prior period, unchanged from 0001437749-19-021592:notes:168]


## us-gaap:InventoryDisclosureTextBlock

[0001437749-20-001789:notes:169]
[same as prior period, unchanged from 0001437749-19-021592:notes:169]

[0001437749-20-001789:notes:170]
[same as prior period, unchanged from 0001437749-19-021592:notes:170]

[0001437749-20-001789:notes:171]
|  |  | December 31, 2019 |  |  | March 31, 2019 |  |
| Raw materials |  | $ | 11,456 |  |  | $ | 5,474 |  |
| Work-in-process |  |  | 2,072 |  |  |  | 1,922 |  |
| Finished goods |  |  | 3,967 |  |  |  | 4,405 |  |
| Deferred program costs |  |  | 1,096 |  |  |  | 318 |  |
| Net inventory |  | $ | 18,591 |  |  | $ | 12,119 |  |

[0001437749-20-001789:notes:172]
[same as prior period, unchanged from 0001437749-19-021592:notes:172]

[0001437749-20-001789:notes:173]
0.3

[0001437749-20-001789:notes:174]
million and 
$0.2
 million for the 
three
 months ended

[0001437749-20-001789:notes:175]
[same as prior period, unchanged from 0001437749-19-021592:notes:174]

[0001437749-20-001789:notes:176]
0.5

[0001437749-20-001789:notes:177]
million and 
$0.7
 million for the

[0001437749-20-001789:notes:178]
[same as prior period, unchanged from 0001437749-19-021592:notes:176]

[0001437749-20-001789:notes:179]
[same as prior period, unchanged from 0001437749-19-021592:notes:177]

[0001437749-20-001789:notes:180]
[same as prior period, unchanged from 0001437749-19-021592:notes:178]


## us-gaap:LeaseCostTableTextBlock

[0001437749-20-001789:notes:181]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | December 31, 2019 |  |  | December 31, 2019 |  |
| Operating Lease: |  |  |  |  |  |  |  |  |
| Operating lease costs - fixed |  | $ | 179 |  |  | $ | 535 |  |
| Operating lease costs - variable |  |  | 27 |  |  |  | 73 |  |
| Short-term lease costs |  |  | 164 |  |  |  | 378 |  |
| Total lease costs |  |  | 370 |  |  |  | 986 |  |


## us-gaap:LesseeOperatingLeaseLiabilityMaturityTableTextBlock

[0001437749-20-001789:notes:182]
|  |  | Operating Leases |  |
| Year ended March 31, |  |  |  |  |
| 2020 |  | $ | 167 |  |
| 2021 |  |  | 672 |  |
| 2022 |  |  | 651 |  |
| 2023 |  |  | 624 |  |
| 2024 |  |  | 562 |  |
| Thereafter |  |  | 1,896 |  |
| Total minimum lease payments |  |  | 4,572 |  |
| Less: interest |  |  | (1,008 | ) |
| Present value of lease liabilities |  |  | 3,564 |  |


## us-gaap:LesseeOperatingLeasesTextBlock

[0001437749-20-001789:notes:183]
[same as prior period, unchanged from 0001437749-19-021592:notes:181]

[0001437749-20-001789:notes:184]
[same as prior period, unchanged from 0001437749-19-021592:notes:182]

[0001437749-20-001789:notes:185]
[same as prior period, unchanged from 0001437749-19-021592:notes:183]

[0001437749-20-001789:notes:186]
[same as prior period, unchanged from 0001437749-19-021592:notes:184]

[0001437749-20-001789:notes:187]
[same as prior period, unchanged from 0001437749-19-021592:notes:185]

[0001437749-20-001789:notes:188]
[same as prior period, unchanged from 0001437749-19-021592:notes:186]

[0001437749-20-001789:notes:189]
[same as prior period, unchanged from 0001437749-19-021592:notes:187]

[0001437749-20-001789:notes:190]
[same as prior period, unchanged from 0001437749-19-021592:notes:188]

[0001437749-20-001789:notes:191]
[same as prior period, unchanged from 0001437749-19-021592:notes:189]

[0001437749-20-001789:notes:192]
[same as prior period, unchanged from 0001437749-19-021592:notes:190]

[0001437749-20-001789:notes:193]
[same as prior period, unchanged from 0001437749-19-021592:notes:191]

[0001437749-20-001789:notes:194]
[same as prior period, unchanged from 0001437749-19-021592:notes:192]

[0001437749-20-001789:notes:195]
[same as prior period, unchanged from 0001437749-19-021592:notes:193]


## us-gaap:NewAccountingPronouncementsAndChangesInAccountingPrinciplesTextBlock

[0001437749-20-001789:notes:196]
18.
 Recent Accounting Pronouncements

[0001437749-20-001789:notes:197]
In 
 February 2016, 
the FASB issued ASU 
2016
-
02,

[0001437749-20-001789:notes:198]
Leases (Topic 
842
)
. The guidance in this ASU supersedes the leasing guidance in Topic 
840,

[0001437749-20-001789:notes:199]
Leases
. Under the new guidance, lessees are required to recognize lease assets and lease liabilities on the balance sheet for all leases with terms longer than 
12
 months. Leases will be classified as either finance or operating, with classification affecting the pattern of expense recognition in the income statement. This ASU and its amendments are effective for fiscal years beginning after 
 December 15, 2018, 
including interim periods within those fiscal years.

[0001437749-20-001789:notes:200]
|  | • | In July 2018, the FASB issued ASU 2018-10, Codification improvements to Topic 842, Leases. The amendments in ASU 2018-10 provide more clarification in regards to the application and requirements of ASU 2016-02. |

[0001437749-20-001789:notes:201]
|  | • | In July 2018, the FASB issued ASU 2018-11, Topic 842, Leases - Targeted improvements. The amendments in ASU 2018-11 provide for the option to adopt the standard prospectively and recognize a cumulative-effect adjustment to the opening balance of retained earnings as well as offer a new practical expedient that will allow the Company to elect, by class of underlying asset, to not separate non-lease and lease components in certain circumstances and instead to account for those components as a single item. |

[0001437749-20-001789:notes:202]
ASU 
2016
-
02
 became effective on 
 April 1, 2019, 
and the Company adopted the standard using the modified retrospective transition method, which impacted all leases existing at, or entered into after, the period of adoption. For all leases existing at the time of adoption the Company recognized a right-of-use asset and lease liability on the balance sheet.  See Note 
14
 "Leases" for additional information.

[0001437749-20-001789:notes:203]
In 
 June 2016, 
the FASB issued ASU 
2016
-
13,

[0001437749-20-001789:notes:204]
Financial Instruments-Credit Losses (Topic 
326
): Measurement of Credit Losses on Financial Instruments
. The amendments in ASU 
2016
-
13
 will provide more decision-useful information about the expected credit losses on financial instruments and other commitments to extend credit held by a reporting entity at each reporting date. The ASU is effective for annual reporting periods beginning after 
 December 15, 2019, 
including interim periods within that year.  Following the release of ASU 
2019
-
10
 in 
 November 2019, 
the new effective date, as long as the Company remains a smaller reporting company, would be annual reporting periods beginning after 
 December 15, 2022.  
The Company is currently evaluating the impact, if any, the adoption of ASU 
2016
-
13

[0001437749-20-001789:notes:205]
may 
have on its consolidated financial statements.

[0001437749-20-001789:notes:206]
In 
 July 2017, 
the FASB issued ASU 
2017
-
11,

[0001437749-20-001789:notes:207]
Earnings per Share (Topic

[0001437749-20-001789:notes:208]
260
), 
Distinguishing Liabilities from Equity (Topic 
480
), and Derivatives and Hedging (Topic 
815
)
. The amendments in ASU 
2017
-
11
 provide guidance for freestanding equity-linked financial instruments, such as warrants and conversion options in convertible debt or preferred stock and should 
no
 longer be accounted for as a derivative liability at fair value as a result of the existence of a down round feature. The ASU is effective for annual reporting periods beginning after 
 December 15, 2018, 
including interim periods within those periods. As of 
 April 1, 2019, 
the Company has adopted ASU 
2017
-
11
 and noted 
no
 significant impact on its consolidated financial statements, primarily due to the put option feature within the Company's warrant agreements which required continued liability classification under ASC 
480.

[0001437749-20-001789:notes:209]
In 
 August 2017, 
the FASB issued ASU 
2017
-
12,

[0001437749-20-001789:notes:210]
Derivatives and Hedging (Topic 
815
): Targeted Improvements to Accounting for Hedging Activities
. The amendments in ASU 
2017
-
12
 provide improved financial reporting of hedging relationships to better portray the economic results of an entity’s risk management activities in its financial statements. In addition, the amendments in this update make certain targeted improvements to simplify the application of the hedge accounting guidance. The ASU is effective for annual reporting periods beginning after 
 December 15, 2018, 
including interim periods within those periods. As of 
 April 1, 2019, 
the Company has adopted ASU 
2017
-
12
 and noted 
no
 significant impact on its consolidated financial statements, primarily due to the fact that there are 
no
 longer any hedging instruments included in its results.

[0001437749-20-001789:notes:211]
In 
 June 2018, 
the FASB issued ASU 
2018
-
08,

[0001437749-20-001789:notes:212]
Not
-For-Profit Entities (Topic 
958
): Clarifying the Scope and the Accounting Guidance for Contributions Received and Contributions Made
.  The amendments in ASU 
2018
-
08
 assist entities in (
1
) evaluating whether transactions should be accounted for as contributions (nonreciprocal transactions) within the scope of Topic 
958,

[0001437749-20-001789:notes:213]
Not
-for-Profit Entities, or as exchange (reciprocal) transactions subject to other guidance and (
2
) determining whether a contribution is conditional.  The ASU is effective for annual reporting periods beginning after 
 December 15, 2018, 
including interim periods within those periods. As of 
 April 1, 2019, 
the Company has adopted ASU 
2018
-
08
 and noted additional disclosures within its revenue footnote to appropriately present the revenue related to its grant revenue.

[0001437749-20-001789:notes:214]
In 
 August 2018, 
the FASB issued ASU 
2018
-
13,

[0001437749-20-001789:notes:215]
Fair Value Measurement (Topic 
820
): Changes to the Disclosure Requirements for Fair Value Measurement
. The amendments in ASU 
2018
-
13
 provide for increased effectiveness of the disclosures made around fair value measurements while including consideration for costs and benefits. The ASU is effective for annual reporting periods beginning after 
 December 15, 2019, 
including interim periods within those periods. The Company is currently evaluating the impact the adoption of ASU 
2018
-
13

[0001437749-20-001789:notes:216]
In 
 December 2019, 
the FASB issued ASU 
2019
-
12,

[0001437749-20-001789:notes:217]
Income Taxes (Topic 
740
): Simplifying the Accounting for Income Taxes
. The amendments in ASU 
2019
-
12
 provide for simplified accounting to several income tax situations and removal of certain accounting exceptions. The ASU is effective for annual reporting periods beginning after 
 December 15, 2020, 
including interim periods within those periods. The Company does 
not
 expect the impact of the adoption of ASU 
2019
-
12
 to be material to its consolidated financial statements.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0001437749-20-001789:notes:218]
[same as prior period, unchanged from 0001437749-19-021592:notes:214]


## us-gaap:PropertyPlantAndEquipmentDisclosureTextBlock

[0001437749-20-001789:notes:219]
[same as prior period, unchanged from 0001437749-19-021592:notes:216]

[0001437749-20-001789:notes:220]
[same as prior period, unchanged from 0001437749-19-021592:notes:217]

[0001437749-20-001789:notes:221]
[same as prior period, unchanged from 0001437749-19-021592:notes:218]

[0001437749-20-001789:notes:222]
|  |  | December 31, 2019 |  |  | March 31, 2019 |  |
| Construction in progress - equipment |  | $ | 2,812 |  |  | $ | 603 |  |
| Equipment and software |  |  | 45,301 |  |  |  | 45,705 |  |
| Furniture and fixtures |  |  | 1,245 |  |  |  | 1,269 |  |
| Leasehold improvements |  |  | 2,485 |  |  |  | 1,955 |  |
| Property, plant and equipment, gross |  |  | 51,843 |  |  |  | 49,532 |  |
| Less accumulated depreciation |  |  | (43,003 | ) |  |  | (40,560 | ) |
| Property, plant and equipment, net |  | $ | 8,840 |  |  | $ | 8,972 |  |

[0001437749-20-001789:notes:223]
[same as prior period, unchanged from 0001437749-19-021592:notes:220]

[0001437749-20-001789:notes:224]
[same as prior period, unchanged from 0001437749-19-021592:notes:221]

[0001437749-20-001789:notes:225]
[same as prior period, unchanged from 0001437749-19-021592:notes:222]

[0001437749-20-001789:notes:226]
[same as prior period, unchanged from 0001437749-19-021592:notes:223]

[0001437749-20-001789:notes:227]
3.1

[0001437749-20-001789:notes:228]
million and 
$3.2
 million for the

[0001437749-20-001789:notes:229]
, respectively. Construction in progress - equipment primarily includes capital investments in our HTS equipment and leasehold improvements in the Company's leased facility in Ayer, Massachusetts.


## us-gaap:ReconciliationOfAssetsFromSegmentToConsolidatedTextBlock

[0001437749-20-001789:notes:230]
|  |  | December 31, 2019 |  |  | March 31, 2019 |  |
| Grid |  | $ | 43,638 |  |  | $ | 31,075 |  |
| Wind |  |  | 11,772 |  |  |  | 8,167 |  |
| Corporate assets |  |  | 68,081 |  |  |  | 80,088 |  |
| Total |  | $ | 123,491 |  |  | $ | 119,330 |  |


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001437749-20-001789:notes:231]
[same as prior period, unchanged from 0001437749-19-021592:notes:228]

[0001437749-20-001789:notes:232]
[same as prior period, unchanged from 0001437749-19-021592:notes:229]

[0001437749-20-001789:notes:233]
[same as prior period, unchanged from 0001437749-19-021592:notes:230]

[0001437749-20-001789:notes:234]
[same as prior period, unchanged from 0001437749-19-021592:notes:231]

[0001437749-20-001789:notes:235]
[same as prior period, unchanged from 0001437749-19-021592:notes:232]

[0001437749-20-001789:notes:236]
[same as prior period, unchanged from 0001437749-19-021592:notes:233]

[0001437749-20-001789:notes:237]
[same as prior period, unchanged from 0001437749-19-021592:notes:234]

[0001437749-20-001789:notes:238]
|  |  | Severance pay |  |  | Facility exit and |  |  |  |  |  |
|  |  | and benefits |  |  | Relocation costs |  |  | Total |  |
| Accrued restructuring balance at April 1, 2018 |  | $ | 262 |  |  | $ | 173 |  |  | $ | 435 |  |
| Charges to operations |  |  | — |  |  |  | 450 |  |  |  | 450 |  |
| Cash payments |  |  | (262 | ) |  |  | (623 | ) |  |  | (885 | ) |
| Accrued restructuring balance at December 31, 2018 |  | $ | — |  |  | $ | — |  |  | $ | — |  |

[0001437749-20-001789:notes:239]
[same as prior period, unchanged from 0001437749-19-021592:notes:236]

[0001437749-20-001789:notes:240]
[same as prior period, unchanged from 0001437749-19-021592:notes:237]

[0001437749-20-001789:notes:241]
[same as prior period, unchanged from 0001437749-19-021592:notes:238]


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001437749-20-001789:notes:242]
[same as prior period, unchanged from 0001437749-19-021592:notes:239]

[0001437749-20-001789:notes:243]
[same as prior period, unchanged from 0001437749-19-021592:notes:240]

[0001437749-20-001789:notes:244]
[same as prior period, unchanged from 0001437749-19-021592:notes:241]

[0001437749-20-001789:notes:245]
[same as prior period, unchanged from 0001437749-19-021592:notes:242]

[0001437749-20-001789:notes:246]
The Company’s revenues in its Grid segment are derived primarily through enabling the transmission and distribution of power, providing planning services that allow it to identify power grid needs and risks, and developing ship protection systems for the U.S. Navy. The Company’s revenues in its Wind segment are derived primarily through supplying advanced power electronics and control systems, licensing its highly engineered wind turbine designs, and providing extensive customer support services to wind turbine manufacturers. The Company records revenue based on a 
five
-step model in accordance with ASC 
606.
 For its customer contracts, the Company identifies the performance obligations, determines the transaction price, allocates the contract transaction price to the performance obligations, and recognizes the revenue when (or as) control of goods or services is transferred to the customer. In the

[0001437749-20-001789:notes:247]
57

[0001437749-20-001789:notes:248]
% and

[0001437749-20-001789:notes:249]
69

[0001437749-20-001789:notes:250]
% of revenue, respectively, was recognized at the point in time when control transferred to the customer, with the remainder being recognized over time.

[0001437749-20-001789:notes:251]
In the Company's equipment and system product line, each contract with a customer summarizes each product sold to a customer, which typically represents distinct performance obligations. A contract's transaction price is allocated to each distinct performance obligation using the respective standalone selling price which is determined primarily using the cost-plus expected margin approach and recognized as revenue when, or as, the performance obligation is satisfied. The majority of the Company’s product sales transfer control to the customer in line with the contracted delivery terms and revenue is recorded at the point in time when title and risk transfer to the customer, as the Company has determined that this is the point in time that control transfers to the customer.

[0001437749-20-001789:notes:252]
[same as prior period, unchanged from 0001437749-19-021592:notes:247]

[0001437749-20-001789:notes:253]
three
 and 
nine
 months ended 
 December 31, 2019

[0001437749-20-001789:notes:254]
, the Company recorded $

[0001437749-20-001789:notes:255]
5.3

[0001437749-20-001789:notes:256]
million in grant revenue, respectively, which is included in the Company’s Grid revenue. There was

[0001437749-20-001789:notes:257]
no

[0001437749-20-001789:notes:258]
grant revenue in the

[0001437749-20-001789:notes:259]
In the Company's service and technology development product line, there are several different types of transactions and each begins with a contract with a customer that summarizes each product sold to a customer, which typically represents distinct performance obligations. The technology development transactions are primarily for activities that have 
no
 alternative use and for which a profit can be expected throughout the life of the contract. In these cases, the revenue is recognized over time, but in the instances where the profit cannot be assured throughout the entire contract, the revenue is recognized at a point in time. Each contract's transaction price is allocated to each distinct performance obligation using the respective standalone selling price which is determined primarily using the cost-plus expected margin approach. The ongoing service transactions are for service contracts that provide benefit to the customer simultaneously as the Company performs its obligations, and therefore this revenue is recognized ratably over time throughout the effective period of these contracts. The transaction prices on these contracts are allocated based on an adjusted market approach which is re-assessed annually for reasonableness. The field service transactions include contracts for delivery of goods and completion of services made at the customer's requests, which are 
not
 deemed satisfied until the work has been completed and/or the requested goods have been delivered, so all of this revenue is recognized at the point in time when the control changes, and at allocated prices based on the adjusted market approach driven by standard price lists. The royalty transactions are related to certain contract terms on transactions in the Company's equipment and systems product line based on activity as specified in the contracts. The transaction prices of these agreements are calculated based on an adjusted market approach as specified in the contract. The Company reports royalty revenue for usage-based royalties when the sales have occurred. In circumstances when collectability is 
not
 assured and a contract does 
not
 exist under ASC 
606,
 revenue is deferred until a non-refundable payment has been received for substantially all the amount that is due and there are 
no
 further remaining performance obligations.

[0001437749-20-001789:notes:260]
[same as prior period, unchanged from 0001437749-19-021592:notes:251]

[0001437749-20-001789:notes:261]
[same as prior period, unchanged from 0001437749-19-021592:notes:252]

[0001437749-20-001789:notes:262]
[same as prior period, unchanged from 0001437749-19-021592:notes:253]

[0001437749-20-001789:notes:263]
The Company records revenue net of sales tax, value added tax, excise tax and other taxes collected concurrent with revenue-producing activities. The Company has elected to recognize the cost for freight and shipping when control over the products sold passes to customers and revenue is recognized. The Company has elected to recognize incremental costs of obtaining a contract as expense when incurred except in contracts where the amortization period would exceed 
twelve
 months; in such cases the long-term amount will be assessed for materiality. The Company has elected 
not
 to adjust the promised amount of consideration for the effects of a significant financing component if the period of financing is 
twelve
 months or less.

[0001437749-20-001789:notes:264]
[same as prior period, unchanged from 0001437749-19-021592:notes:255]

[0001437749-20-001789:notes:265]
[same as prior period, unchanged from 0001437749-19-021592:notes:256]

[0001437749-20-001789:notes:266]
[same as prior period, unchanged from 0001437749-19-021592:notes:257]

[0001437749-20-001789:notes:267]
, the Company’s contract assets and liabilities primarily relate to the timing differences between cash received from a customer in connection with contractual rights to invoicing and the timing of revenue recognition following completion of performance obligations. The Company's accounts receivable balance is made up entirely of customer contract related balances. Changes in the Company’s contract assets, which are included in “Accounts Receivable (unbilled)” and “Deferred program costs” (see Note 
7,
 “Accounts Receivable” and Note 
8,
 “Inventory” for a reconciliation to the condensed consolidated balance sheets) and contract liabilities, which are included in the current portion and long term portion of deferred revenue in the Company’s condensed consolidated balance sheets, are as follows:

[0001437749-20-001789:notes:268]
[same as prior period, unchanged from 0001437749-19-021592:notes:259]

[0001437749-20-001789:notes:269]
[same as prior period, unchanged from 0001437749-19-021592:notes:260]

[0001437749-20-001789:notes:270]
76.2

[0001437749-20-001789:notes:271]
[same as prior period, unchanged from 0001437749-19-021592:notes:262]

[0001437749-20-001789:notes:272]
7.0

[0001437749-20-001789:notes:273]
[same as prior period, unchanged from 0001437749-19-021592:notes:264]

[0001437749-20-001789:notes:274]
[same as prior period, unchanged from 0001437749-19-021592:notes:265]

[0001437749-20-001789:notes:275]
[same as prior period, unchanged from 0001437749-19-021592:notes:266]

[0001437749-20-001789:notes:276]
[same as prior period, unchanged from 0001437749-19-021592:notes:267]

[0001437749-20-001789:notes:277]
|  |  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  | Reportable |  | December 31, |  |  | December 31, |  |
|  | Segment |  | 2019 |  |  | 2018 |  |  | 2019 |  |  | 2018 |  |
| Inox Wind Limited | Wind |  |  | <10% |  |  |  | 47 | % |  |  | 11 | % |  |  | 40 | % |
| Department of Homeland Security | Grid |  |  | 22 | % |  |  | <10% |  |  |  | 12 | % |  |  | <10% |  |
| Vestas | Grid |  |  | 25 | % |  |  | <10% |  |  |  | 10 | % |  |  | 15 | % |
| Fuji Bridex Pte. Ltd. | Grid |  |  | <10% |  |  |  | 17 | % |  |  | <10% |  |  |  | <10% |  |


## us-gaap:ScheduleOfSegmentReportingInformationBySegmentTextBlock

[0001437749-20-001789:notes:278]
|  |  | Three Months Ended December 31, |  |  | Nine Months Ended December 31, |  |
|  |  | 2019 |  |  | 2018 |  |  | 2019 |  |  | 2018 |  |
| Revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Grid |  | $ | 15,232 |  |  | $ | 6,826 |  |  | $ | 36,577 |  |  | $ | 23,325 |  |
| Wind |  |  | 2,683 |  |  |  | 7,308 |  |  |  | 9,120 |  |  |  | 18,293 |  |
| Total |  | $ | 17,915 |  |  | $ | 14,134 |  |  | $ | 45,697 |  |  | $ | 41,618 |  |

[0001437749-20-001789:notes:279]
|  |  | Three Months Ended December 31, |  |  | Nine Months Ended December 31, |  |
|  |  | 2019 |  |  | 2018 |  |  | 2019 |  |  | 2018 |  |
| Operating (loss) income: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Grid |  | $ | (3,732 | ) |  | $ | (2,665 | ) |  | $ | (9,723 | ) |  | $ | (8,202 | ) |
| Wind |  |  | (2,297 | ) |  |  | 24,269 |  |  |  | (6,015 | ) |  |  | 51,419 |  |
| Unallocated corporate expenses |  |  | (590 | ) |  |  | (839 | ) |  |  | (1,236 | ) |  |  | (2,851 | ) |
| Total |  | $ | (6,619 | ) |  | $ | 20,765 |  |  | $ | (16,974 | ) |  | $ | 40,366 |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001437749-20-001789:notes:280]
[same as prior period, unchanged from 0001437749-19-021592:notes:271]

[0001437749-20-001789:notes:281]
[same as prior period, unchanged from 0001437749-19-021592:notes:272]

[0001437749-20-001789:notes:282]
[same as prior period, unchanged from 0001437749-19-021592:notes:273]

[0001437749-20-001789:notes:283]
[same as prior period, unchanged from 0001437749-19-021592:notes:274]

[0001437749-20-001789:notes:284]
[same as prior period, unchanged from 0001437749-19-021592:notes:275]

[0001437749-20-001789:notes:285]
[same as prior period, unchanged from 0001437749-19-021592:notes:276]

[0001437749-20-001789:notes:286]
[same as prior period, unchanged from 0001437749-19-021592:notes:277]

[0001437749-20-001789:notes:287]
million and

[0001437749-20-001789:notes:288]
$0.8

[0001437749-20-001789:notes:289]
million in the 
three
 months ended

[0001437749-20-001789:notes:290]
, respectively, and restructuring charges of less than 
$0.1
 million in the 
three
 months ended

[0001437749-20-001789:notes:291]
[same as prior period, unchanged from 0001437749-19-021592:notes:281]

[0001437749-20-001789:notes:292]
1.2

[0001437749-20-001789:notes:293]
million and 
$2.4
 million in the

[0001437749-20-001789:notes:294]
, respectively, and restructuring charges of 
$0.5
 million in the

[0001437749-20-001789:notes:295]
[same as prior period, unchanged from 0001437749-19-021592:notes:285]


## us-gaap:SubsequentEventsTextBlock

[0001437749-20-001789:notes:296]
19.
 Subsequent Events

[0001437749-20-001789:notes:297]
The Company has performed an evaluation of subsequent events through the time of filing this Quarterly Report on Form 
10
-Q with the SEC and has determined that there are 
no
 such events to report.
