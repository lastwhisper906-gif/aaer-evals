# AMSC note change history — 0001437749-19-021592 → 0001437749-20-001789


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2020-02-05):
[0001437749-20-001789:note_history:1]
December 31, 2019
  (was, 2019-11-05, similarity 0.8):
[0001437749-19-021592:note_history:1]
September 30, 2019


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2020-02-05):
[0001437749-20-001789:note_history:2]
December 31, 2019
  (was, 2019-11-05, similarity 0.8):
[0001437749-19-021592:note_history:2]
September 30, 2019

- changed (2020-02-05):
[0001437749-20-001789:note_history:3]
December 31, 2019
  (was, 2019-11-05, similarity 0.8):
[0001437749-19-021592:note_history:3]
September 30, 2019

- changed (2020-02-05):
[0001437749-20-001789:note_history:4]
December 31, 2019
  (was, 2019-11-05, similarity 0.8):
[0001437749-19-021592:note_history:4]
September 30, 2019

- changed (2020-02-05):
[0001437749-20-001789:note_history:5]
December 31, 2019
  (was, 2019-11-05, similarity 0.8):
[0001437749-19-021592:note_history:5]
September 30, 2019

- changed (2020-02-05):
[0001437749-20-001789:note_history:6]
million, with 
no
 outstanding debt other than ordinary trade payables. Marketable securities include certificate of deposits with maturities between 
eleven
 and 
twenty-four
 months.  Cash used in operations for the
  (was, 2019-11-05, similarity 0.981):
[0001437749-19-021592:note_history:6]
million, with 
no
 outstanding debt other than ordinary trade payables. Marketable securities include certificate of deposits with maturities between 
twelve
 and 
twenty-four
 months.  Cash used in operations for the

- added (2020-02-05):
[0001437749-20-001789:note_history:7]
nine

- changed (2020-02-05):
[0001437749-20-001789:note_history:8]
December 31, 2019
  (was, 2019-11-05, similarity 0.8):
[0001437749-19-021592:note_history:8]
September 30, 2019

- added (2020-02-05):
[0001437749-20-001789:note_history:9]
The Company issued warrants in conjunction with an equity offering to Hudson Bay Capital ("Hudson") in 
 November 2014 (
the "Hudson Warrant").  The Hudson Warrant was partially exercised on 
 November 13, 2019 
with an exercise price of 
$7.81.
 The Company received 
$6.1
 million in cash for 
786,000
 warrants. The remaining 
32,181
 warrants expired on 
 November 13, 2019.

- added (2020-02-05):
[0001437749-20-001789:note_history:10]
nine

- changed (2020-02-05):
[0001437749-20-001789:note_history:11]
December 31, 2019
  (was, 2019-11-05, similarity 0.8):
[0001437749-19-021592:note_history:11]
September 30, 2019

- removed (2020-02-05):
[0001437749-19-021592:note_history:12]
six

- removed (2020-02-05):
[0001437749-19-021592:note_history:13]
six


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2020-02-05):
[0001437749-20-001789:note_history:14]
|  |  | Three Months Ended December 31, 2019 |  |  | Nine Months Ended December 31, 2019 |  |
| Product Line: |  | Grid |  |  | Wind |  |  | Grid |  |  | Wind |  |
| Equipment and systems |  | $ | 14,040 |  |  | $ | 2,160 |  |  | $ | 32,438 |  |  | $ | 7,742 |  |
| Services and technology development |  |  | 1,192 |  |  |  | 523 |  |  |  | 4,139 |  |  |  | 1,379 |  |
| Total |  | $ | 15,232 |  |  | $ | 2,683 |  |  | $ | 36,577 |  |  | $ | 9,120 |  |
| Region: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas |  | $ | 10,164 |  |  | $ | 2 |  |  | $ | 28,663 |  |  | $ | 49 |  |
| Asia Pacific |  |  | 330 |  |  |  | 2,647 |  |  |  | 2,550 |  |  |  | 8,968 |  |
| EMEA |  |  | 4,738 |  |  |  | 34 |  |  |  | 5,364 |  |  |  | 104 |  |
| Total |  | $ | 15,232 |  |  | $ | 2,683 |  |  | $ | 36,577 |  |  | $ | 9,120 |  |
  (was, 2019-11-05, similarity 0.9831):
[0001437749-19-021592:note_history:14]
|  |  | Three Months Ended September 30, 2019 |  |  | Six Months Ended September 30, 2019 |  |
| Product Line: |  | Grid |  |  | Wind |  |  | Grid |  |  | Wind |  |
| Equipment and systems |  | $ | 10,044 |  |  | $ | 2,077 |  |  | $ | 18,399 |  |  | $ | 5,581 |  |
| Services and technology development |  |  | 1,445 |  |  |  | 446 |  |  |  | 2,946 |  |  |  | 856 |  |
| Total |  | $ | 11,489 |  |  | $ | 2,523 |  |  | $ | 21,345 |  |  | $ | 6,437 |  |
| Region: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas |  | $ | 10,698 |  |  | $ | 1 |  |  | $ | 18,499 |  |  | $ | 47 |  |
| Asia Pacific |  |  | 393 |  |  |  | 2,464 |  |  |  | 2,220 |  |  |  | 6,320 |  |
| EMEA |  |  | 398 |  |  |  | 58 |  |  |  | 626 |  |  |  | 70 |  |
| Total |  | $ | 11,489 |  |  | $ | 2,523 |  |  | $ | 21,345 |  |  | $ | 6,437 |  |

- changed (2020-02-05):
[0001437749-20-001789:note_history:15]
|  |  | Three Months Ended December 31, 2018 |  |  | Nine Months Ended December 31, 2018 |  |
| Product Line: |  | Grid |  |  | Wind |  |  | Grid |  |  | Wind |  |
| Equipment and systems |  | $ | 4,614 |  |  | $ | 7,215 |  |  | $ | 17,571 |  |  | $ | 17,925 |  |
| Services and technology development |  |  | 2,212 |  |  |  | 93 |  |  |  | 5,754 |  |  |  | 368 |  |
| Total |  | $ | 6,826 |  |  | $ | 7,308 |  |  | $ | 23,325 |  |  | $ | 18,293 |  |
| Region: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas |  | $ | 3,771 |  |  | $ | 36 |  |  | $ | 16,319 |  |  | $ | 82 |  |
| Asia Pacific |  |  | 2,815 |  |  |  | 7,263 |  |  |  | 5,930 |  |  |  | 18,136 |  |
| EMEA |  |  | 240 |  |  |  | 9 |  |  |  | 1,076 |  |  |  | 75 |  |
| Total |  | $ | 6,826 |  |  | $ | 7,308 |  |  | $ | 23,325 |  |  | $ | 18,293 |  |
  (was, 2019-11-05, similarity 0.9831):
[0001437749-19-021592:note_history:15]
|  |  | Three Months Ended September 30, 2018 |  |  | Six Months Ended September 30, 2018 |  |
| Product Line: |  | Grid |  |  | Wind |  |  | Grid |  |  | Wind |  |
| Equipment and systems |  | $ | 5,503 |  |  | $ | 7,219 |  |  | $ | 12,957 |  |  | $ | 10,711 |  |
| Services and technology development |  |  | 2,066 |  |  |  | 88 |  |  |  | 3,541 |  |  |  | 274 |  |
| Total |  | $ | 7,569 |  |  | $ | 7,307 |  |  | $ | 16,498 |  |  | $ | 10,985 |  |
| Region: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas |  | $ | 5,052 |  |  | $ | 24 |  |  | $ | 12,548 |  |  | $ | 47 |  |
| Asia Pacific |  |  | 2,308 |  |  |  | 7,278 |  |  |  | 3,115 |  |  |  | 10,873 |  |
| EMEA |  |  | 209 |  |  |  | 5 |  |  |  | 835 |  |  |  | 65 |  |
| Total |  | $ | 7,569 |  |  | $ | 7,307 |  |  | $ | 16,498 |  |  | $ | 10,985 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2020-02-05):
[0001437749-20-001789:note_history:16]
The Company’s revenues in its Grid segment are derived primarily through enabling the transmission and distribution of power, providing planning services that allow it to identify power grid needs and risks, and developing ship protection systems for the U.S. Navy. The Company’s revenues in its Wind segment are derived primarily through supplying advanced power electronics and control systems, licensing its highly engineered wind turbine designs, and providing extensive customer support services to wind turbine manufacturers. The Company records revenue based on a 
five
-step model in accordance with ASC 
606.
 For its customer contracts, the Company identifies the performance obligations, determines the transaction price, allocates the contract transaction price to the performance obligations, and recognizes the revenue when (or as) control of goods or services is transferred to the customer. In the
  (was, 2019-11-05, similarity 0.994):
[0001437749-19-021592:note_history:16]
The Company’s revenues in its Grid segment are derived primarily through enabling the transmission and distribution of power, providing planning services that allow it to identify power grid needs and risks, and developing ship protection systems for the U.S. Navy. The Company’s revenues in its Wind segment are derived primarily through supplying advanced power electronics and control systems, licensing its highly engineered wind turbine designs, and providing extensive customer support services to wind turbine manufacturers. The Company records revenue based on a 
five
-step model in accordance with ASC 
606.
 For its customer contracts, the Company identifies the performance obligations, determines the transaction price, allocates the contract transaction price to the performance obligations, and recognizes the revenue when (or as) control of goods or services is transferred to the customer. In both the

- changed (2020-02-05):
[0001437749-20-001789:note_history:17]
three
 and 
nine
  (was, 2019-11-05, similarity 0.8148):
[0001437749-19-021592:note_history:17]
three
 and 
six

- changed (2020-02-05):
[0001437749-20-001789:note_history:18]
December 31, 2019
  (was, 2019-11-05, similarity 0.8):
[0001437749-19-021592:note_history:18]
September 30, 2019

- added (2020-02-05):
[0001437749-20-001789:note_history:19]
% and

- changed (2020-02-05):
[0001437749-20-001789:note_history:20]
% of revenue, respectively, was recognized at the point in time when control transferred to the customer, with the remainder being recognized over time.
  (was, 2019-11-05, similarity 0.9481):
[0001437749-19-021592:note_history:20]
% of revenue was recognized at the point in time when control transferred to the customer, with the remainder being recognized over time.

- changed (2020-02-05):
[0001437749-20-001789:note_history:21]
In the Company's equipment and system product line, each contract with a customer summarizes each product sold to a customer, which typically represents distinct performance obligations. A contract's transaction price is allocated to each distinct performance obligation using the respective standalone selling price which is determined primarily using the cost-plus expected margin approach and recognized as revenue when, or as, the performance obligation is satisfied. The majority of the Company’s product sales transfer control to the customer in line with the contracted delivery terms and revenue is recorded at the point in time when title and risk transfer to the customer, as the Company has determined that this is the point in time that control transfers to the customer.
  (was, 2019-11-05, similarity 0.9994):
[0001437749-19-021592:note_history:21]
In the Company's equipment and system product line, each contract with a customer summarizes each product sold to a customer, which typically represent distinct performance obligations. A contract's transaction price is allocated to each distinct performance obligation using the respective standalone selling price which is determined primarily using the cost-plus expected margin approach and recognized as revenue when, or as, the performance obligation is satisfied. The majority of the Company’s product sales transfer control to the customer in line with the contracted delivery terms and revenue is recorded at the point in time when title and risk transfer to the customer, as the Company has determined that this is the point in time that control transfers to the customer.

- changed (2020-02-05):
[0001437749-20-001789:note_history:22]
three
 and 
nine
 months ended 
 December 31, 2019
  (was, 2019-11-05, similarity 0.875):
[0001437749-19-021592:note_history:22]
three
 and 
six
 months ended 
 September 30, 2019

- added (2020-02-05):
[0001437749-20-001789:note_history:23]
, the Company recorded $

- added (2020-02-05):
[0001437749-20-001789:note_history:24]
million and $

- changed (2020-02-05):
[0001437749-20-001789:note_history:25]
million in grant revenue, respectively, which is included in the Company’s Grid revenue. There was
  (was, 2019-11-05, similarity 0.751):
[0001437749-19-021592:note_history:25]
, the Company recorded 
$0.7
 million and 
$1.1
 million in grant revenue, respectively, which is included in the Company’s Grid revenue. There was 
no
 grant revenue in the

- added (2020-02-05):
[0001437749-20-001789:note_history:26]
no

- added (2020-02-05):
[0001437749-20-001789:note_history:27]
grant revenue in the

- changed (2020-02-05):
[0001437749-20-001789:note_history:28]
three
 and 
nine
  (was, 2019-11-05, similarity 0.8148):
[0001437749-19-021592:note_history:28]
three
 and 
six

- changed (2020-02-05):
[0001437749-20-001789:note_history:29]
December 31, 2018
  (was, 2019-11-05, similarity 0.8):
[0001437749-19-021592:note_history:29]
September 30, 2018

- changed (2020-02-05):
[0001437749-20-001789:note_history:30]
In the Company's service and technology development product line, there are several different types of transactions and each begins with a contract with a customer that summarizes each product sold to a customer, which typically represents distinct performance obligations. The technology development transactions are primarily for activities that have 
no
 alternative use and for which a profit can be expected throughout the life of the contract. In these cases, the revenue is recognized over time, but in the instances where the profit cannot be assured throughout the entire contract, the revenue is recognized at a point in time. Each contract's transaction price is allocated to each distinct performance obligation using the respective standalone selling price which is determined primarily using the cost-plus expected margin approach. The ongoing service transactions are for service contracts that provide benefit to the customer simultaneously as the Company performs its obligations, and therefore this revenue is recognized ratably over time throughout the effective period of these contracts. The transaction prices on these contracts are allocated based on an adjusted market approach which is re-assessed annually for reasonableness. The field service transactions include contracts for delivery of goods and completion of services made at the customer's requests, which are 
not
 deemed satisfied until the work has been completed and/or the requested goods have been delivered, so all of this revenue is recognized at the point in time when the control changes, and at allocated prices based on the adjusted market approach driven by standard price lists. The royalty transactions are related to certain contract terms on transactions in the Company's equipment and systems product line based on activity as specified in the contracts. The transaction prices of these agreements are calculated based on an adjusted market approach as specified in the contract. The Company reports royalty revenue for usage-based royalties when the sales have occurred. In circumstances when collectability is 
not
 assured and a contract does 
not
 exist under ASC 
606,
 revenue is deferred until a non-refundable payment has been received for substantially all the amount that is due and there are 
no
 further remaining performance obligations.
  (was, 2019-11-05, similarity 0.9987):
[0001437749-19-021592:note_history:30]
In the Company's service and technology development product line, there are several different types of transactions and each begins with a contract with a customer that summarizes each product sold to a customer, which typically represents distinct performance obligations. The technology development transactions are primarily for activities that have 
no
 alternative use and for which a profit can be expected throughout the life of the contract. In these cases, the revenue is recognized over time, but in the instances where the profit cannot be assured throughout the entire contract then the revenue is recognized at a point in time. Each contract's transaction price is allocated to each distinct performance obligation using the respective standalone selling price which is determined primarily using the cost-plus expected margin approach. The ongoing service transactions are for service contracts that provide benefit to the customer simultaneously as the Company performs its obligations, and therefore this revenue is recognized ratably over time throughout the effective period of these contracts. The transaction prices on these contracts are allocated based on an adjusted market approach which is re-assessed annually for reasonableness. The field service transactions include contracts for delivery of goods and completion of services made at the customer's requests, which are 
not
 deemed satisfied until the work has been completed and/or the requested goods have been delivered, so all of this revenue is recognized at the point in time when the control changes, and at allocated prices based on the adjusted market approach driven by standard price lists. The royalty transactions are related to certain contract terms on transactions in the Company's equipment and systems product line based on activity as specified in the contracts. The transaction prices of these agreements are calculated based on an adjusted market approach as specified in the contract. The Company reports royalty revenue for usage-based royalties when the sales have occurred. In circumstances when collectability is 
not
 assured and a contract does 
not
 exist under ASC 
606,
 revenue is deferred until a non-refundable payment has been received for substantially all the amount that is due and there are 
no
 further remaining performance obligations.

- changed (2020-02-05):
[0001437749-20-001789:note_history:31]
The Company records revenue net of sales tax, value added tax, excise tax and other taxes collected concurrent with revenue-producing activities. The Company has elected to recognize the cost for freight and shipping when control over the products sold passes to customers and revenue is recognized. The Company has elected to recognize incremental costs of obtaining a contract as expense when incurred except in contracts where the amortization period would exceed 
twelve
 months; in such cases the long-term amount will be assessed for materiality. The Company has elected 
not
 to adjust the promised amount of consideration for the effects of a significant financing component if the period of financing is 
twelve
 months or less.
  (was, 2019-11-05, similarity 0.9918):
[0001437749-19-021592:note_history:31]
The Company records revenue net of sales tax, value added tax, excise tax and other taxes collected concurrent with revenue-producing activities. The Company has elected to recognize the cost for freight and shipping when control over the products sold passes to customers and revenue is recognized. The Company has elected to recognize incremental costs of obtaining a contract as expense when incurred except in contracts where the amortization period would exceed 
twelve
 months; in such cases the long-term amount will be assessed for materiality. The Company has elected to 
not
 adjust the promised amount of consideration for the effects of a significant financing component if the period of financing is 
twelve
 months or less.

- changed (2020-02-05):
[0001437749-20-001789:note_history:32]
|  |  | Three Months Ended December 31, 2019 |  |  | Nine Months Ended December 31, 2019 |  |
| Product Line: |  | Grid |  |  | Wind |  |  | Grid |  |  | Wind |  |
| Equipment and systems |  | $ | 14,040 |  |  | $ | 2,160 |  |  | $ | 32,438 |  |  | $ | 7,742 |  |
| Services and technology development |  |  | 1,192 |  |  |  | 523 |  |  |  | 4,139 |  |  |  | 1,379 |  |
| Total |  | $ | 15,232 |  |  | $ | 2,683 |  |  | $ | 36,577 |  |  | $ | 9,120 |  |
| Region: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas |  | $ | 10,164 |  |  | $ | 2 |  |  | $ | 28,663 |  |  | $ | 49 |  |
| Asia Pacific |  |  | 330 |  |  |  | 2,647 |  |  |  | 2,550 |  |  |  | 8,968 |  |
| EMEA |  |  | 4,738 |  |  |  | 34 |  |  |  | 5,364 |  |  |  | 104 |  |
| Total |  | $ | 15,232 |  |  | $ | 2,683 |  |  | $ | 36,577 |  |  | $ | 9,120 |  |
  (was, 2019-11-05, similarity 0.9831):
[0001437749-19-021592:note_history:32]
|  |  | Three Months Ended September 30, 2019 |  |  | Six Months Ended September 30, 2019 |  |
| Product Line: |  | Grid |  |  | Wind |  |  | Grid |  |  | Wind |  |
| Equipment and systems |  | $ | 10,044 |  |  | $ | 2,077 |  |  | $ | 18,399 |  |  | $ | 5,581 |  |
| Services and technology development |  |  | 1,445 |  |  |  | 446 |  |  |  | 2,946 |  |  |  | 856 |  |
| Total |  | $ | 11,489 |  |  | $ | 2,523 |  |  | $ | 21,345 |  |  | $ | 6,437 |  |
| Region: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas |  | $ | 10,698 |  |  | $ | 1 |  |  | $ | 18,499 |  |  | $ | 47 |  |
| Asia Pacific |  |  | 393 |  |  |  | 2,464 |  |  |  | 2,220 |  |  |  | 6,320 |  |
| EMEA |  |  | 398 |  |  |  | 58 |  |  |  | 626 |  |  |  | 70 |  |
| Total |  | $ | 11,489 |  |  | $ | 2,523 |  |  | $ | 21,345 |  |  | $ | 6,437 |  |

- changed (2020-02-05):
[0001437749-20-001789:note_history:33]
|  |  | Three Months Ended December 31, 2018 |  |  | Nine Months Ended December 31, 2018 |  |
| Product Line: |  | Grid |  |  | Wind |  |  | Grid |  |  | Wind |  |
| Equipment and systems |  | $ | 4,614 |  |  | $ | 7,215 |  |  | $ | 17,571 |  |  | $ | 17,925 |  |
| Services and technology development |  |  | 2,212 |  |  |  | 93 |  |  |  | 5,754 |  |  |  | 368 |  |
| Total |  | $ | 6,826 |  |  | $ | 7,308 |  |  | $ | 23,325 |  |  | $ | 18,293 |  |
| Region: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas |  | $ | 3,771 |  |  | $ | 36 |  |  | $ | 16,319 |  |  | $ | 82 |  |
| Asia Pacific |  |  | 2,815 |  |  |  | 7,263 |  |  |  | 5,930 |  |  |  | 18,136 |  |
| EMEA |  |  | 240 |  |  |  | 9 |  |  |  | 1,076 |  |  |  | 75 |  |
| Total |  | $ | 6,826 |  |  | $ | 7,308 |  |  | $ | 23,325 |  |  | $ | 18,293 |  |
  (was, 2019-11-05, similarity 0.9831):
[0001437749-19-021592:note_history:33]
|  |  | Three Months Ended September 30, 2018 |  |  | Six Months Ended September 30, 2018 |  |
| Product Line: |  | Grid |  |  | Wind |  |  | Grid |  |  | Wind |  |
| Equipment and systems |  | $ | 5,503 |  |  | $ | 7,219 |  |  | $ | 12,957 |  |  | $ | 10,711 |  |
| Services and technology development |  |  | 2,066 |  |  |  | 88 |  |  |  | 3,541 |  |  |  | 274 |  |
| Total |  | $ | 7,569 |  |  | $ | 7,307 |  |  | $ | 16,498 |  |  | $ | 10,985 |  |
| Region: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas |  | $ | 5,052 |  |  | $ | 24 |  |  | $ | 12,548 |  |  | $ | 47 |  |
| Asia Pacific |  |  | 2,308 |  |  |  | 7,278 |  |  |  | 3,115 |  |  |  | 10,873 |  |
| EMEA |  |  | 209 |  |  |  | 5 |  |  |  | 835 |  |  |  | 65 |  |
| Total |  | $ | 7,569 |  |  | $ | 7,307 |  |  | $ | 16,498 |  |  | $ | 10,985 |  |

- changed (2020-02-05):
[0001437749-20-001789:note_history:34]
December 31, 2019
  (was, 2019-11-05, similarity 0.8):
[0001437749-19-021592:note_history:34]
September 30, 2019

- changed (2020-02-05):
[0001437749-20-001789:note_history:35]
December 31, 2018
  (was, 2019-11-05, similarity 0.8):
[0001437749-19-021592:note_history:35]
September 30, 2018

- changed (2020-02-05):
[0001437749-20-001789:note_history:36]
, the Company’s contract assets and liabilities primarily relate to the timing differences between cash received from a customer in connection with contractual rights to invoicing and the timing of revenue recognition following completion of performance obligations. The Company's accounts receivable balance is made up entirely of customer contract related balances. Changes in the Company’s contract assets, which are included in “Accounts Receivable (unbilled)” and “Deferred program costs” (see Note 
7,
 “Accounts Receivable” and Note 
8,
 “Inventory” for a reconciliation to the condensed consolidated balance sheets) and contract liabilities, which are included in the current portion and long term portion of deferred revenue in the Company’s condensed consolidated balance sheets, are as follows:
  (was, 2019-11-05, similarity 0.9875):
[0001437749-19-021592:note_history:36]
, the Company’s contract assets and liabilities primarily relate to the timing differences between cash received from a customer in connection with contractual rights to invoicing and the timing of revenue recognition following completion of performance obligations. The Company's accounts receivable balance is made up entirely of customer contract related balances. Changes in the Company’s contract assets, which are included in “Unbilled Accounts Receivable” and “Deferred program costs” (see Note 
7,
 “Accounts Receivable” and Note 
8,
 “Inventory” for a reconciliation to the condensed consolidated balance sheets) and contract liabilities, which are included in the current portion and long term portion of deferred revenue in the Company’s condensed consolidated balance sheets, are as follows:

- changed (2020-02-05):
[0001437749-20-001789:note_history:37]
|  |  | Unbilled Accounts Receivable |  |  | Deferred Program Costs |  |  | Contract Liabilities |  |
| Beginning balance as of March 31, 2019 |  | $ | 2,213 |  |  | $ | 318 |  |  | $ | 15,519 |  |
| Increases for costs incurred to fulfill performance obligations |  |  | — |  |  |  | 3,001 |  |  |  | — |  |
| Increase (decrease) due to customer billings |  |  | (7,417 | ) |  |  | — |  |  |  | 36,461 |  |
| Decrease due to cost recognition on completed performance obligations |  |  | — |  |  |  | (2,221 | ) |  |  | — |  |
| Increase (decrease) due to recognition of revenue based on transfer of control of performance obligations |  |  | 9,820 |  |  |  | — |  |  |  | (28,768 | ) |
| Other changes and FX impact |  |  | (3 | ) |  |  | (1 | ) |  |  | (69 | ) |
| Ending balance as of December 31, 2019 |  | $ | 4,613 |  |  | $ | 1,097 |  |  | $ | 23,143 |  |
  (was, 2019-11-05, similarity 0.9953):
[0001437749-19-021592:note_history:37]
|  |  | Unbilled Accounts Receivable |  |  | Deferred Program Costs |  |  | Contract Liabilities |  |
| Beginning balance as of March 31, 2019 |  | $ | 2,213 |  |  | $ | 318 |  |  | $ | 15,519 |  |
| Increases for costs incurred to fulfill performance obligations |  |  | — |  |  |  | 2,153 |  |  |  | — |  |
| Increase (decrease) due to customer billings |  |  | (2,926 | ) |  |  | — |  |  |  | 19,340 |  |
| Decrease due to cost recognition on completed performance obligations |  |  | — |  |  |  | (310 | ) |  |  | — |  |
| Increase (decrease) due to recognition of revenue based on transfer of control of performance obligations |  |  | 4,711 |  |  |  | — |  |  |  | (18,534 | ) |
| Other changes and FX impact |  |  | (4 | ) |  |  | (9 | ) |  |  | (313 | ) |
| Ending balance as of September 30, 2019 |  | $ | 3,994 |  |  | $ | 2,152 |  |  | $ | 16,012 |  |

- changed (2020-02-05):
[0001437749-20-001789:note_history:38]
|  |  | Unbilled Accounts Receivable |  |  | Deferred Program Costs |  |  | Contract Liabilities |  |
| Beginning balance as of March 31, 2018 |  | $ | 3,016 |  |  | $ | 2,567 |  |  | $ | 21,937 |  |
| Impact of adoption of ASC 606 |  |  | — |  |  |  | (1,599 | ) |  |  | (2,657 | ) |
| Increases for costs incurred to fulfill performance obligations |  |  | — |  |  |  | 1,461 |  |  |  | — |  |
| Increase (decrease) due to customer billings |  |  | (11,063 | ) |  |  | — |  |  |  | 11,167 |  |
| Decrease due to cost recognition on completed performance obligations |  |  | — |  |  |  | (1,132 | ) |  |  | — |  |
| Increase (decrease) due to recognition of revenue based on transfer of control of performance obligations |  |  | 9,722 |  |  |  | (9 | ) |  |  | (11,345 | ) |
| Other changes and FX impact |  |  | (53 | ) |  |  | 8 |  |  |  | (1,040 | ) |
| Ending balance as of December 31, 2018 |  | $ | 1,622 |  |  | $ | 1,296 |  |  | $ | 18,062 |  |
  (was, 2019-11-05, similarity 0.9957):
[0001437749-19-021592:note_history:38]
|  |  | Unbilled Accounts Receivable |  |  | Deferred Program Costs |  |  | Contract Liabilities |  |
| Beginning balance as of March 31, 2018 |  | $ | 3,016 |  |  | $ | 2,567 |  |  | $ | 21,937 |  |
| Impact of adoption of ASC 606 |  |  | — |  |  |  | (1,599 | ) |  |  | (2,657 | ) |
| Increases for costs incurred to fulfill performance obligations |  |  | — |  |  |  | 1,267 |  |  |  | — |  |
| Increase (decrease) due to customer billings |  |  | (7,886 | ) |  |  | — |  |  |  | 7,828 |  |
| Decrease due to cost recognition on completed performance obligations |  |  | — |  |  |  | (1,033 | ) |  |  | — |  |
| Increase (decrease) due to recognition of revenue based on transfer of control of performance obligations |  |  | 7,439 |  |  |  | (9 | ) |  |  | (8,296 | ) |
| Other changes and FX impact |  |  | (19 | ) |  |  | 24 |  |  |  | (864 | ) |
| Ending balance as of September 30, 2018 |  | $ | 2,550 |  |  | $ | 1,217 |  |  | $ | 17,948 |  |

- changed (2020-02-05):
[0001437749-20-001789:note_history:39]
December 31, 2019
  (was, 2019-11-05, similarity 0.8):
[0001437749-19-021592:note_history:39]
September 30, 2019

- added (2020-02-05):
[0001437749-20-001789:note_history:40]
76.2

- added (2020-02-05):
[0001437749-20-001789:note_history:41]
7.0

- changed (2020-02-05):
[0001437749-20-001789:note_history:42]
three
 and 
nine
 months ended 
 December 31, 2019
  (was, 2019-11-05, similarity 0.875):
[0001437749-19-021592:note_history:42]
three
 and 
six
 months ended 
 September 30, 2019

- added (2020-02-05):
[0001437749-20-001789:note_history:43]
2018

- added (2020-02-05):
[0001437749-20-001789:note_history:44]
|  |  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  | Reportable |  | December 31, |  |  | December 31, |  |
|  | Segment |  | 2019 |  |  | 2018 |  |  | 2019 |  |  | 2018 |  |
| Inox Wind Limited | Wind |  |  | <10% |  |  |  | 47 | % |  |  | 11 | % |  |  | 40 | % |
| Department of Homeland Security | Grid |  |  | 22 | % |  |  | <10% |  |  |  | 12 | % |  |  | <10% |  |
| Vestas | Grid |  |  | 25 | % |  |  | <10% |  |  |  | 10 | % |  |  | 15 | % |
| Fuji Bridex Pte. Ltd. | Grid |  |  | <10% |  |  |  | 17 | % |  |  | <10% |  |  |  | <10% |  |

- removed (2020-02-05):
[0001437749-19-021592:note_history:45]
|  |  |  | Three Months Ended |  |  | Six Months Ended |  |
|  | Reportable |  | September 30, |  |  | September 30, |  |
|  | Segment |  | 2019 |  |  | 2018 |  |  | 2019 |  |  | 2018 |  |
| Inox Wind Limited | Wind |  |  | <10% |  |  |  | 45 | % |  |  | 17 | % |  |  | 36 | % |
| Micron Technology | Grid |  |  | <10% |  |  |  | <10% |  |  |  | 14 | % |  |  | <10% |  |
| Vestas | Grid |  |  | <10% |  |  |  | 11 | % |  |  | <10% |  |  |  | 23 | % |
| Quanta Power | Grid |  |  | — | % |  |  | 12 | % |  |  | — | % |  |  | <10% |  |
| Hoffman Construction | Grid |  |  | 25 | % |  |  | — | % |  |  | 12 | % |  |  | — | % |
| M.J. Electric, LLC | Grid |  |  | 25 | % |  |  | — | % |  |  | 13 | % |  |  | — | % |
