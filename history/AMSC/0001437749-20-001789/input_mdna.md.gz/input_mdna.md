# AMSC MD&A — 0001437749-20-001789


## mdna

[0001437749-20-001789:mdna:1]
[same as prior period, unchanged from 0001437749-19-021592:mdna:1]

[0001437749-20-001789:mdna:2]
[same as prior period, unchanged from 0001437749-19-021592:mdna:2]

[0001437749-20-001789:mdna:3]
[same as prior period, unchanged from 0001437749-19-021592:mdna:3]

[0001437749-20-001789:mdna:4]
[same as prior period, unchanged from 0001437749-19-021592:mdna:4]

[0001437749-20-001789:mdna:5]
[same as prior period, unchanged from 0001437749-19-021592:mdna:5]

[0001437749-20-001789:mdna:6]
[same as prior period, unchanged from 0001437749-19-021592:mdna:6]

[0001437749-20-001789:mdna:7]
[same as prior period, unchanged from 0001437749-19-021592:mdna:7]

[0001437749-20-001789:mdna:8]
[same as prior period, unchanged from 0001437749-19-021592:mdna:8]

[0001437749-20-001789:mdna:9]
[same as prior period, unchanged from 0001437749-19-021592:mdna:9]

[0001437749-20-001789:mdna:10]
[same as prior period, unchanged from 0001437749-19-021592:mdna:10]

[0001437749-20-001789:mdna:11]
On July 3, 2018, we and our wholly-owned subsidiaries Suzhou AMSC Superconductor Co. Ltd. (“AMSC China”) and AMSC Austria GmbH (“AMSC Austria”) entered into a settlement agreement (the “Settlement Agreement”) with Sinovel Wind Group Co., Ltd. (“Sinovel”). The Settlement Agreement settles the litigation and arbitration proceedings between us and Sinovel listed on Schedule 2 of the Settlement Agreement (the “Proceedings”), and any other civil claims, counterclaims, causes of action, rights and obligations directly or indirectly relating to the subject matters of the Proceedings and the contracts between us and Sinovel listed on Schedules 1 and 4 of the Settlement Agreement, subject to the exception described in Section 1.1 of the Settlement Agreement. The Settlement Agreement was filed as Exhibit 10.1 to the Company’s Form 8-K filed with the Securities and Exchange Commission on July 9, 2018. Under the terms of the Settlement Agreement, Sinovel agreed to pay AMSC China an aggregate cash amount in Renminbi (“RMB”) equivalent to $57.5 million, consisting of two installments. Sinovel paid the first installment of the RMB equivalent of $32.5 million on July 4, 2018 and paid the second installment of the RMB equivalent of $25.0 million on December 27, 2018.

[0001437749-20-001789:mdna:12]
[same as prior period, unchanged from 0001437749-19-021592:mdna:12]

[0001437749-20-001789:mdna:13]
On October 31, 2018, we entered into a Subcontract Agreement with Commonwealth Edison Company (“ComEd”) (the “Subcontract Agreement”) for the manufacture and installation of the Company’s REG system within ComEd’s electric grid in Chicago, Illinois (the “Project”). As provided in the Subcontract Agreement, the Subcontract Agreement became effective upon the signing of an amendment by us and the U.S. Department of Homeland Security (“DHS”) to the existing contract (the “Prime Contract”) between us and DHS on June 20, 2019. Unless terminated earlier by us, ComEd or DHS according to the terms of the Subcontract Agreement, the term of the Subcontract Agreement will continue until we complete our warranty obligations under the Subcontract Agreement. Under the terms of the Subcontract Agreement, we have agreed, among other things, to provide the REG system and to supervise ComEd’s installation of the REG system in Chicago. As part of our separate cost sharing arrangement with DHS under the Prime Contract, we expect funding provided by DHS in connection with the Subcontract Agreement to be between $9.0 to $11.0 million, which represents the total amount of revenue we are expected to recognize over the term of the Subcontract Agreement and includes up to $1.0 million that we have agreed to reimburse ComEd for costs incurred by ComEd while undertaking its tasks under the Subcontract Agreement (the “Reimbursement Amount”). In addition, we are required to deliver an irrevocable letter of credit in the amount of $5.0 million to secure certain Company obligations under the Subcontract Agreement. ComEd has agreed to provide the site and provide all civil engineering work required to support the installation, operation and integration of the REG system into ComEd’s electric grid. Other than the Reimbursement Amount, ComEd is responsible for its own costs and expenses. DHS’s approval to commence with construction was obtained on June 20, 2019. Substation work on the project began in late 2019.  The REG system is expected to be operational in 2021.

[0001437749-20-001789:mdna:14]
[same as prior period, unchanged from 0001437749-19-021592:mdna:14]

[0001437749-20-001789:mdna:15]
The preparation of the unaudited condensed consolidated financial statements requires that we make estimates and judgments that affect the reported amounts of assets, liabilities, revenues and expenses, and related disclosure of contingent assets and liabilities. We base our estimates on historical experience and various other assumptions that are believed to be reasonable under the circumstances, the results of which form the basis for making judgments about the carrying values of assets and liabilities that are not readily apparent from other sources. Actual results may differ under different assumptions or conditions. Effective April 1, 2019, we adopted ASU 2016-02, which provides for new requirements in regards to leases. See Note 14, "Leases" for further details. Aside from the adoption of ASU 2016-02, there were no significant changes in the critical accounting policies that were disclosed in our Form 10-K for fiscal 2018, which ended on March 31, 2019.

[0001437749-20-001789:mdna:16]
[same as prior period, unchanged from 0001437749-19-021592:mdna:16]

[0001437749-20-001789:mdna:17]
Three and nine months ended December 31, 2019 compared to the three and nine months ended December 31, 2018

[0001437749-20-001789:mdna:18]
[same as prior period, unchanged from 0001437749-19-021592:mdna:18]

[0001437749-20-001789:mdna:19]
Total revenues increased 27% and 10% to $17.9 million and $45.7 million for the three and nine months ended December 31, 2019, compared to $14.1 million and $41.6 million for the three and nine months ended December 31, 2018.  Our revenues are summarized as follows (in thousands):

[0001437749-20-001789:mdna:20]
|  |  | Three Months Ended December 31, |  |  | Nine Months Ended December 31, |  |
|  |  | 2019 |  |  | 2018 |  |  | 2019 |  |  | 2018 |  |
| Revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Grid |  | $ | 15,232 |  |  | $ | 6,826 |  |  | $ | 36,577 |  |  | $ | 23,325 |  |
| Wind |  |  | 2,683 |  |  |  | 7,308 |  |  |  | 9,120 |  |  |  | 18,293 |  |
| Total |  | $ | 17,915 |  |  | $ | 14,134 |  |  | $ | 45,697 |  |  | $ | 41,618 |  |

[0001437749-20-001789:mdna:21]
Our Grid business unit accounted for 85% and 80% of total revenues for the three and nine months ended December 31, 2019, respectively, compared to 48% and 56% for the three and nine months ended December 31, 2018, respectively. Our Grid business unit revenues increased 123% and 57% to $15.2 million and $36.6 million in the three and nine months ended December 31, 2019, respectively, from $6.8 million and $23.3 million in the three and nine months ended December 31, 2018, respectively. Grid business unit revenue in both the three and nine months ended December 31, 2019 increased primarily driven by growth in D-VAR, SPS and REG revenue.

[0001437749-20-001789:mdna:22]
Our Wind business unit accounted for 15% and 20% of total revenues for the three and nine months ended December 31, 2019, respectively, compared to 52% and 44% for the three and nine months ended December 31, 2018, respectively. Revenues in the Wind business unit decreased 63% and 50% to $2.7 million and $9.1 million in the three and nine months ended December 31, 2019, respectively, from $7.3 million and $18.3 million in the three and nine months ended December 31, 2018, respectively. The decreases over the prior year period were driven primarily by decreased shipments of ECS to Inox offset slightly by increased development revenue for the 3MW wind turbine platform with Inox and the 5.5MW with Doosan.  As further described in Note 1 “Nature of the Business and Operations and Liquidity,” Inox is currently delinquent on its obligations to post letters of credit for sets of electrical control systems that Inox has agreed to purchase under the terms of the supply contract.  We cannot predict if and when Inox will resume posting letters of credit for payment of contracted-for shipments of electrical control systems. Any continued failure by Inox to post letters of credit and take delivery of contracted-for shipments of electrical control shipments would impact the Company’s revenues and liquidity.  Inox has been active in the new central and state government auction regime in India and has over 900 MW of orders from the first four SECI central government auctions, and 50 MW from the Maharashtra state government auction. However, we cannot predict if and how successful Inox will be in executing on these orders or in obtaining new orders under the new central and state auction regime. Any failure by Inox to succeed under this regime, or any delay in Inox’s ability to deliver its wind turbines, could result in fewer ECS shipments to Inox.

[0001437749-20-001789:mdna:23]
[same as prior period, unchanged from 0001437749-19-021592:mdna:23]

[0001437749-20-001789:mdna:24]
Cost of revenues increased by 57% and 28% to $16.3 million and $38.8 million for the three and nine months ended December 31, 2019, respectively, compared to $10.4 million and $30.4 million for the three and nine months ended December 31, 2018, respectively. Gross margin was 9% and 15% for the three and nine months ended December 31, 2019, respectively, compared to 26% and 27% for the three and nine months ended December 31, 2018, respectively.  The decrease in gross margin in the three and nine months ended December 31, 2019 was primarily due to increased revenue from cost share projects with DHS and a less favorable product mix in the current year periods.

[0001437749-20-001789:mdna:25]
[same as prior period, unchanged from 0001437749-19-021592:mdna:25]

[0001437749-20-001789:mdna:26]
[same as prior period, unchanged from 0001437749-19-021592:mdna:26]

[0001437749-20-001789:mdna:27]
R&D expenses decreased 17% in the three months ended December 31, 2019 to $2.0 million from $2.5 million in the three months ended December 31, 2018.  R&D expenses decreased 9% in the nine months ended December 31, 2019 to $6.9 million from $7.6 million in the nine months ended December 31, 2018.  The decreases in R&D expense in both the three and  nine month periods were primarily due to better labor absorption to cost of revenues to support revenue generating projects.

[0001437749-20-001789:mdna:28]
[same as prior period, unchanged from 0001437749-19-021592:mdna:28]

[0001437749-20-001789:mdna:29]
SG&A expenses increased 14% in the three months ended December 31, 2019 to $6.1 million from $5.3 million in the three months ended December 31, 2018. SG&A expenses increased 3% in the nine months ended December 31, 2019 to $16.7 million from $16.3 million in the nine months ended December 31, 2018. The increases in SG&A expense in the both the three and nine month periods was due primarily to higher overall compensation expense than the prior fiscal year.

[0001437749-20-001789:mdna:30]
[same as prior period, unchanged from 0001437749-19-021592:mdna:30]

[0001437749-20-001789:mdna:31]
We recorded a gain of $25.0 million and $53.7 million, net of legal and other direct costs, in the three and nine months ended December 31, 2018, respectively, as a result of the receipt of the payments from Sinovel required by the Settlement Agreement.

[0001437749-20-001789:mdna:32]
[same as prior period, unchanged from 0001437749-19-021592:mdna:32]

[0001437749-20-001789:mdna:33]
We recorded amortization expense related to our core technology and know-how, trade names and trademark, and intangible assets of $0.1 million and $0.3 million in the three and nine month periods ended December 31, 2019, respectively, and $0.1 million and $0.3 million in the three and nine months ended December 31, 2018 respectively.

[0001437749-20-001789:mdna:34]
[same as prior period, unchanged from 0001437749-19-021592:mdna:34]

[0001437749-20-001789:mdna:35]
We recorded $0.1 million and $0.4 million for facility exit costs in the three and nine months ended December 31, 2018, respectively, as a result of the relocation of the corporate office that was announced as part of our April 4, 2017 approved restructuring plan.  There was no restructuring activity in the three and nine months ended December 31, 2019.

[0001437749-20-001789:mdna:36]
[same as prior period, unchanged from 0001437749-19-021592:mdna:36]

[0001437749-20-001789:mdna:37]
[same as prior period, unchanged from 0001437749-19-021592:mdna:37]

[0001437749-20-001789:mdna:38]
|  |  | Three Months Ended December 31, |  |  | Nine Months Ended December 31, |  |
|  |  | 2019 |  |  | 2018 |  |  | 2019 |  |  | 2018 |  |
| Operating (loss) income: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Grid |  | $ | (3,732 | ) |  | $ | (2,665 | ) |  | $ | (9,723 | ) |  | $ | (8,202 | ) |
| Wind |  |  | (2,297 | ) |  |  | 24,269 |  |  |  | (6,015 | ) |  |  | 51,419 |  |
| Unallocated corporate expenses |  |  | (590 | ) |  |  | (839 | ) |  |  | (1,236 | ) |  |  | (2,851 | ) |
| Total |  | $ | (6,619 | ) |  | $ | 20,765 |  |  | $ | (16,974 | ) |  | $ | 40,366 |  |

[0001437749-20-001789:mdna:39]
Our Grid segment generated an operating loss of $3.7 million and $9.7 million in the three and nine months ended December 31, 2019, respectively, compared to $2.7 million and $8.2 million in the three and nine months ended December 31, 2018, respectively. The increase in the Grid business unit operating loss in the three and nine months ended December 31, 2019 was primarily due to a less favorable product mix than in the prior year period.

[0001437749-20-001789:mdna:40]
Our Wind segment generated an operating loss of $2.3 million and $6.0 million in the three and nine months ended December 31, 2019, respectively, compared to income of $24.3 million and $51.4 million in the three and nine months ended December 31, 2018, respectively. The decreases in the Wind business unit operating income in both periods were due primarily to receipt of the payments from Sinovel required by the Settlement Agreement in the second and third quarters of fiscal 2018 and no such payment in fiscal 2019.

[0001437749-20-001789:mdna:41]
Unallocated corporate expenses primarily consist of stock-based compensation expense of $0.6 million and $0.8 million in the three months ended December 31, 2019 and 2018, respectively, and restructuring charges of $0.1 million in the three months ended December 31, 2018.  Unallocated corporate expenses primarily consist of stock-based compensation expense of $1.2 million and $2.4 million in the nine months ended December 31, 2019 and 2018, respectively, and restructuring charges of $0.4 million in the nine months ended December 31, 2018.

[0001437749-20-001789:mdna:42]
[same as prior period, unchanged from 0001437749-19-021592:mdna:42]

[0001437749-20-001789:mdna:43]
The change in fair value of warrants resulted in gains of $0.6 million and $4.6 million in the three and nine months ended December 31, 2019, respectively, compared to losses of $2.5 million and $2.7 million in the three and nine months ended December 31, 2018, respectively. The change in the fair value was primarily driven by changes in stock price, which is a key valuation metric, as well as the exercise of the Hercules warrant in June 2019 and Hudson warrants in November 2019.

[0001437749-20-001789:mdna:44]
Minority Interest

[0001437749-20-001789:mdna:45]
The gain on sale of minority interest was $0.1 million in each of the three and nine months ended December 31, 2018.  There was no minority interest activity in the three and nine months ended December 31, 2019.

[0001437749-20-001789:mdna:46]
[same as prior period, unchanged from 0001437749-19-021592:mdna:44]

[0001437749-20-001789:mdna:47]
Interest income, net, was $0.3 million and $1.1 million in the three and nine months ended December 31, 2019, compared to $0.3 million and $0.8 million in the three and nine months ended December 31, 2018. The increase in interest income in the nine months ended December 31, 2019 was primarily related to higher cash balances earning higher interest rates than in prior periods as well as the non-cash interest income recognized from receipt of the final payment on the Devens facility note receivable.

[0001437749-20-001789:mdna:48]
Other (expense) income, net

[0001437749-20-001789:mdna:49]
Other expense, net, was $0.9 million and other income, net was less than $0.1 million in the three and nine months ended December 31, 2019, compared to other income, net of $0.1 million and $1.1 million in the three and nine months ended December 31, 2018.  The increase in other expense, net, in the three month period was primarily driven by higher foreign losses.  The decrease in other income, net, in the nine month period was primarily driven by foreign exchange gains and higher interest income.

[0001437749-20-001789:mdna:50]
[same as prior period, unchanged from 0001437749-19-021592:mdna:48]

[0001437749-20-001789:mdna:51]
Income tax expense was $0.1 million and less than $0.1 million in the three and nine months ended December 31, 2019, compared to $1.6 million and $4.5 million in the three and nine months ended December 31, 2018. The decrease in income tax expense is due primarily to the prior year repayment of previously reserved intercompany trade balances due to AMSC Austria from AMSC China, and a dividend paid by AMSC Austria to us in the nine months ended December 31, 2018 following the Sinovel settlement.

[0001437749-20-001789:mdna:52]
[same as prior period, unchanged from 0001437749-19-021592:mdna:50]

[0001437749-20-001789:mdna:53]
Net loss was $6.8 million and $11.2 million in the three and nine months ended December 31, 2019, respectively, compared to net income of $17.3 million and $35.1 million in the three and nine months ended December 31, 2018, respectively.  The increase in net loss in both periods was primarily driven by the receipt of the payments from Sinovel required by the Settlement Agreement in the second and third quarters of fiscal 2018 and no such payments in fiscal 2019.

[0001437749-20-001789:mdna:54]
[same as prior period, unchanged from 0001437749-19-021592:mdna:52]

[0001437749-20-001789:mdna:55]
Generally, a non-GAAP financial measure is a numerical measure of a company’s performance, financial position or cash flow that either excludes or includes amounts that are not normally excluded or included in the most directly comparable measure calculated and presented in accordance with GAAP. The non-GAAP measures included in this Form 10-Q, however, should be considered in addition to, and not as a substitute for or superior to the comparable measures prepared in accordance with GAAP.

[0001437749-20-001789:mdna:56]
We define non-GAAP net loss as net loss before sale of minority investments, stock-based compensation, gain on Sinovel settlement, net, amortization of acquisition-related intangibles, changes in fair value of warrants, and other non-cash or unusual charges, and the tax effect of those adjustments calculated at the relevant rate for our non-GAAP metric, indicated in the table below. We believe non-GAAP net loss assists management and investors in comparing our performance across reporting periods on a consistent basis by excluding these non-cash or non-recurring charges that we do not believe are indicative of our core operating performance. A reconciliation of GAAP to non-GAAP net loss is set forth in the table below (in thousands, except per share data):

[0001437749-20-001789:mdna:57]
|  |  | Three Months Ended December 31, |  |  | Nine Months Ended December 31, |  |
|  |  | 2019 |  |  | 2018 |  |  | 2019 |  |  | 2018 |  |
| Net (loss) income |  | $ | (6,845 | ) |  | $ | 17,293 |  |  | $ | (11,209 | ) |  | $ | 35,114 |  |
| Sale of minority investments |  |  | 0 |  |  |  | (127 | ) |  |  | 0 |  |  |  | (127 | ) |
| Stock-based compensation |  |  | 590 |  |  |  | 792 |  |  |  | 1,236 |  |  |  | 2,402 |  |
| (Gain) on Sinovel settlement, net |  |  | — |  |  |  | (24,978 | ) |  |  | — |  |  |  | (53,698 | ) |
| Amortization of acquisition-related intangibles |  |  | 85 |  |  |  | 85 |  |  |  | 255 |  |  |  | 255 |  |
| Changes in fair value of warrants |  |  | (556 | ) |  |  | 2,475 |  |  |  | (4,648 | ) |  |  | 2,658 |  |
| Tax effect of adjustments for (gain) on Sinovel settlement, net |  |  | — |  |  |  | 2,163 |  |  |  | — |  |  |  | 4,991 |  |
| Non-GAAP net loss |  | $ | (6,726 | ) |  | $ | (2,297 | ) |  | $ | (14,366 | ) |  | $ | (8,405 | ) |
| Non-GAAP net loss per share - basic |  | $ | (0.32 | ) |  | $ | (0.11 | ) |  | $ | (0.69 | ) |  | $ | (0.41 | ) |
| Weighted average shares outstanding - basic |  |  | 21,185 |  |  |  | 20,419 |  |  |  | 20,786 |  |  |  | 20,300 |  |

[0001437749-20-001789:mdna:58]
We incurred non-GAAP net losses of $6.7 million and $14.4 million or $0.32 and $0.69 per share, for the three and nine months ended December 31, 2019, respectively, compared to non-GAAP net losses of $2.3 million and $8.4 million, or $0.11 and $0.41 per share for the three and nine months ended December 31, 2018 respectively. The increases in non-GAAP net loss were primarily due to the more favorable product mix in the prior year period.

[0001437749-20-001789:mdna:59]
[same as prior period, unchanged from 0001437749-19-021592:mdna:57]

[0001437749-20-001789:mdna:60]
[same as prior period, unchanged from 0001437749-19-021592:mdna:58]

[0001437749-20-001789:mdna:61]
We have experienced recurring operating losses, and as of December 31, 2019, had an accumulated deficit of $972.7 million.

[0001437749-20-001789:mdna:62]
[same as prior period, unchanged from 0001437749-19-021592:mdna:60]

[0001437749-20-001789:mdna:63]
As of December 31, 2019, we had cash, cash equivalents, restricted cash, and marketable securities of $66.3 million, compared to $78.2 million as of March 31, 2019, a decrease of $11.9 million. As of December 31, 2019, we had approximately $8.4 million of cash, cash equivalents, and restricted cash in foreign bank accounts. Our cash and cash equivalents, marketable securities and restricted cash are summarized as follows (in thousands):

[0001437749-20-001789:mdna:64]
|  |  | December 31, 2019 |  |  | March 31, 2019 |  |
| Cash and cash equivalents |  | $ | 25,481 |  |  | $ | 77,483 |  |
| Marketable securities |  |  | 35,047 |  |  |  | 0 |  |
| Restricted cash |  |  | 5,754 |  |  |  | 715 |  |
| Total cash, cash equivalents, marketable securities and restricted cash |  | $ | 66,283 |  |  | $ | 78,198 |  |

[0001437749-20-001789:mdna:65]
For the nine months ended December 31, 2019, net cash used in operating activities was $17.8 million compared to net cash provided by operating activities of $47.8 million for the nine months ended December 31, 2018. The decrease in net cash provided by operations was due primarily to the receipt of the first and second payments from the Sinovel settlement in the nine months ended December 31, 2018 with no similar transaction in the nine months ended December 31, 2019.

[0001437749-20-001789:mdna:66]
For the nine months ended December 31, 2019, net cash used in investing activities was $34.9 million, compared to $0.7 million for the nine months ended December 31, 2018. The increase in net cash used in investing activities was due primarily to the purchase of marketable securities and increased purchases of property, plant and equipment related to improvements to the Ayer facility and factory equipment to support the Navy and REG projects, partially offset by the receipt of the second installment payment under the Note Receivable from the Devens facility sale in the nine months ended December 31, 2019.

[0001437749-20-001789:mdna:67]
For the nine months ended December 31, 2019, net cash provided by financing activities was $5.7 million compared to net cash used in financing activities of $0.4 million in the nine months ended December 31, 2018.  The increase in net cash provided by financing activities was due primarily to proceeds received from the exercise of the Hudson warrants during the nine months ended December 31, 2019.

[0001437749-20-001789:mdna:68]
As of December 31, 2019, we had $5.8 million of restricted cash included in long-term assets. These amounts included in restricted cash primarily represent deposits to secure letters of credit for various supply contracts and long-term projects. These deposits are held in interest bearing accounts.

[0001437749-20-001789:mdna:69]
[same as prior period, unchanged from 0001437749-19-021592:mdna:67]

[0001437749-20-001789:mdna:70]
[same as prior period, unchanged from 0001437749-19-021592:mdna:68]

[0001437749-20-001789:mdna:71]
[same as prior period, unchanged from 0001437749-19-021592:mdna:69]

[0001437749-20-001789:mdna:72]
|  |  |  | Nine months ended |  |
|  |  | December 31, 2019 |  |  | December 31, 2018 |  |
| Operating cash flow |  | $ | (17,779 | ) |  | $ | 47,786 |  |
| Sinovel settlement (net of legal fees and expenses) |  |  | 1,000 |  |  |  | (54,724 | ) |
| Tax effect of adjustments |  |  | 2,724 |  |  |  | 2,377 |  |
| Non-GAAP operating cash flow |  | $ | (14,055 | ) |  | $ | (4,561 | ) |

[0001437749-20-001789:mdna:73]
Legal Proceedings

[0001437749-20-001789:mdna:74]
We are involved in legal and administrative proceedings and claims of various types. See Part II, Item 1, “Legal Proceedings,” for additional information. We record a liability in our consolidated financial statements for these matters when a loss is known or considered probable and the amount can be reasonably estimated. We review these estimates each accounting period as additional information is known and adjust the loss provision when appropriate. If a matter is both probable to result in liability and the amounts of loss can be reasonably estimated, we estimate and disclose the possible loss or range of loss to the extent necessary to make the consolidated financial statements not misleading. If the loss is not probable or cannot be reasonably estimated, a liability is not recorded in our consolidated financial statements.

[0001437749-20-001789:mdna:75]
[same as prior period, unchanged from 0001437749-19-021592:mdna:73]

[0001437749-20-001789:mdna:76]
[same as prior period, unchanged from 0001437749-19-021592:mdna:74]

[0001437749-20-001789:mdna:77]
[same as prior period, unchanged from 0001437749-19-021592:mdna:75]

[0001437749-20-001789:mdna:78]
[same as prior period, unchanged from 0001437749-19-021592:mdna:76]

[0001437749-20-001789:mdna:79]
[same as prior period, unchanged from 0001437749-19-021592:mdna:77]

[0001437749-20-001789:mdna:80]
In February 2016, the FASB issued Accounting Standards Update ("ASU") 2016-02, Leases (Topic 842). The guidance in this ASU supersedes the leasing guidance in Topic 840, Leases. Under the new guidance, lessees are required to recognize lease assets and lease liabilities on the balance sheet for all leases with terms longer than 12 months. Leases will be classified as either finance or operating, with classification affecting the pattern of expense recognition in the income statement. This ASU and its amendments are effective for fiscal years beginning after December 15, 2018, including interim periods within those fiscal years.

[0001437749-20-001789:mdna:81]
|  | • | In July 2018, the FASB issued ASU 2018-10, Codification improvements to Topic 842, Leases. The amendments in ASU 2018-10 provide more clarification in regards to the application and requirements of ASU 2016-02. |

[0001437749-20-001789:mdna:82]
|  | • | In July 2018, the FASB issued ASU 2018-11, Topic 842, Leases - Targeted improvements. The amendments in ASU 2018-11 provide for the option to adopt the standard prospectively and recognize a cumulative-effect adjustment to the opening balance of retained earnings as well as offer a new practical expedient that will allow us to elect, by class of underlying asset, to not separate non-lease and lease components in certain circumstances and instead to account for those components as a single item. |

[0001437749-20-001789:mdna:83]
ASU 2016-02 became effective on April 1, 2019, and we adopted the standard using the modified retrospective transition method, which will impact all leases existing at, or entered into after, the period of adoption. For all leases existing at the time of adoption we recognized a right-of-use asset and lease liability on the balance sheet.  See Note 14 "Leases" for additional information.

[0001437749-20-001789:mdna:84]
In June 2016, the FASB issued ASU 2016-13, Financial Instruments-Credit Losses (Topic 326): Measurement of Credit Losses on Financial Instruments. The amendments in ASU 2016-13 provide more decision-useful information about the expected credit losses on financial instruments and other commitments to extend credit held by a reporting entity at each reporting date. The ASU is effective for annual reporting periods beginning after December 15, 2019, including interim periods within that year.  Following the release of ASU 2019-10 in November 2019, the new effective date, as long as the Company remains a smaller reporting company, would be annual reporting periods beginning after December 15, 2022.   We are currently evaluating the impact, if any, the adoption of ASU 2016-13 may have on our consolidated financial statements.

[0001437749-20-001789:mdna:85]
In July 2017, the FASB issued ASU 2017-11, Earnings per Share (Topic 260), Distinguishing Liabilities from Equity (Topic 480), and Derivatives and Hedging (Topic 815). The amendments in ASU 2017-11 provide guidance for freestanding equity-linked financial instruments, such as warrants and conversion options in convertible debt or preferred stock, and should no longer be accounted for as a derivative liability at fair value as a result of the existence of a down round feature. The ASU is effective for annual reporting periods beginning after December 15, 2018, including interim periods within those periods. As of April 1, 2019 we have adopted ASU 2017-11 and noted no significant impact on our consolidated financial statements, primarily due to the put option feature which required continued liability classification under ASC 840.

[0001437749-20-001789:mdna:86]
In August 2017, the FASB issued ASU 2017-12, Derivatives and Hedging (Topic 815): Targeted Improvements to Accounting for Hedging Activities. The amendments in ASU 2017-12 provide improved financial reporting of hedging relationships to better portray the economic results of an entity’s risk management activities in its financial statements. In addition, the amendments in this update make certain targeted improvements to simplify the application of the hedge accounting guidance. The ASU is effective for annual reporting periods beginning after December 15, 2018, including interim periods within those periods. As of April 1, 2019 we have adopted ASU 2017-12 and noted no significant impact on our consolidated financial statements, primarily due to the fact that there are no longer any hedging instruments included in our results.

[0001437749-20-001789:mdna:87]
In June 2018, the FASB issued ASU 2018-08, Not-For-Profit Entities (Topic 958): Clarifying the Scope and the Accounting Guidance for Contributions Received and Contributions Made.  The amendments in ASU 2018-08 assist entities in (1) evaluating whether transactions should be accounted for as contributions (nonreciprocal transactions) within the scope of Topic 958, Not-for-Profit Entities, or as exchange (reciprocal) transactions subject to other guidance and (2) determining whether a contribution is conditional.  The ASU is effective for annual reporting periods beginning after December 15, 2018, including interim periods within those periods. As of April 1, 2019, we have adopted ASU 2018-08 and noted additional disclosures within our revenue footnote to appropriately present the revenue related to our grant revenue.

[0001437749-20-001789:mdna:88]
In August 2018, the FASB issued ASU 2018-13, Fair Value Measurement (Topic 820): Changes to the Disclosure Requirements for Fair Value Measurement. The amendments in ASU 2018-13 provide for increased effectiveness of the disclosures made around fair value measurements while including consideration for costs and benefits. The ASU is effective for annual reporting periods beginning after December 15, 2019, including interim periods within those periods. We are currently evaluating the impact the adoption of ASU 2018-13 may have on our consolidated financial statements.

[0001437749-20-001789:mdna:89]
In December 2019, the FASB issued ASU 2019-12, Income Taxes (Topic 740): Simplifying the Accounting for Income Taxes. The amendments in ASU 2019-12 provide for simplified accounting to several income tax situations and removal of certain accounting exceptions. The ASU is effective for annual reporting periods beginning after December 15, 2020, including interim periods within those periods. We do not expect the impact of the adoption of ASU 2019-12 to be material to our consolidated financial statements.

[0001437749-20-001789:mdna:90]
We do not believe that, outside of those disclosed here, there are any other recently issued accounting pronouncements that will have a material impact on our consolidated financial statements.
