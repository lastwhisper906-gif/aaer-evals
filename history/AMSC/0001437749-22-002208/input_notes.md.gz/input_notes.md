# AMSC notes — 0001437749-22-002208


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0001437749-22-002208:notes:1]
[same as prior period, unchanged from 0001437749-21-025699:notes:1]

[0001437749-22-002208:notes:2]
[same as prior period, unchanged from 0001437749-21-025699:notes:2]

[0001437749-22-002208:notes:3]
[same as prior period, unchanged from 0001437749-21-025699:notes:3]

[0001437749-22-002208:notes:4]
These unaudited condensed consolidated financial statements of the Company have been prepared on a going concern basis in accordance with United States generally accepted accounting principles (“GAAP”) and the Securities and Exchange Commission’s (“SEC”) instructions to Form 10-Q. The going concern basis of presentation assumes that the Company will continue operations and will be able to realize its assets and discharge its liabilities and commitments in the normal course of business. Certain information and footnote disclosures normally included in the financial statements prepared in accordance with GAAP have been condensed or omitted pursuant to those instructions. The year-end condensed balance sheet data was derived from audited financial statements but does not include all disclosures required by GAAP. The unaudited condensed consolidated financial statements, in the opinion of management, reflect all adjustments (consisting of normal recurring adjustments) necessary for a fair statement of the results for the interim periods ended  December 31, 2021 and 2020 and the financial position at  December 31, 2021; however, these results are not necessarily indicative of results which  may be expected for the full year. The interim condensed consolidated financial statements, and notes thereto, should be read in conjunction with the audited consolidated financial statements for the year ended  March 31, 2021, and notes thereto, included in the Company’s Annual Report on Form 10-K for the year ended  March 31, 2021 filed with the SEC on  June 2, 2021.

[0001437749-22-002208:notes:5]
[same as prior period, unchanged from 0001437749-21-025699:notes:5]

[0001437749-22-002208:notes:6]
The Company has historically experienced recurring operating losses and as of  December 31, 2021, the Company had an accumulated deficit of $1,015 million. In addition, the Company has historically experienced recurring negative operating cash flows.  At  December 31, 2021, the Company had cash and cash equivalents of $43.9 million. Cash used in operations for the nine months ended  December 31, 2021 was $15.9 million.

[0001437749-22-002208:notes:7]
[same as prior period, unchanged from 0001437749-21-025699:notes:7]

[0001437749-22-002208:notes:8]
[same as prior period, unchanged from 0001437749-21-025699:notes:8]

[0001437749-22-002208:notes:9]
[same as prior period, unchanged from 0001437749-21-025699:notes:9]

[0001437749-22-002208:notes:10]
While the COVID-19 pandemic continues to rapidly evolve, the Company is experiencing some inflation pressure in its supply chains, some delays in sourcing materials needed for its products, and some production disruption resulting from higher than typical employee absenteeism due to the highly contagious omicron variant. The Company continues to assess the impact of the COVID-19 pandemic to best mitigate risk and continue the operations of the Company’s business. The extent to which the outbreak impacts the Company’s business, liquidity, results of operations and financial condition will depend on future developments, which are highly uncertain and cannot be predicted with confidence, including new information that  may emerge concerning the severity of the COVID-19 pandemic, the spread of new variations of the virus, the actions to contain it or treat its impact and the effectiveness and adoption of vaccines and treatments, among others.  If the Company, its customers or suppliers experience prolonged shutdowns or other business disruptions, including global supply chain disruptions, the Company’s business, liquidity, results of operations and financial condition are likely to be materially adversely affected, and the Company’s ability to access the capital markets  may be limited.

[0001437749-22-002208:notes:11]
The Company believes that based on the information presented above and its quarterly management assessment, it has sufficient liquidity to fund its operations and capital expenditures for the next twelve months following the issuance of the financial statements for the nine months ended  December 31, 2021. The Company’s liquidity is highly dependent on its ability to increase revenues and gross margin, its ability to control its operating costs, and its ability to raise additional capital, if necessary.  The impact of the COVID-19 pandemic on the global financing markets  may reduce the Company's ability to raise additional capital, if necessary, which could negatively impact the Company's liquidity.  There can be no assurance that the Company will be able to continue to raise additional capital, on favorable terms or at all, from other sources or execute on any other means of improving liquidity described above.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001437749-22-002208:notes:12]
[same as prior period, unchanged from 0001437749-21-025699:notes:12]

[0001437749-22-002208:notes:13]
[same as prior period, unchanged from 0001437749-21-025699:notes:13]

[0001437749-22-002208:notes:14]
[same as prior period, unchanged from 0001437749-21-025699:notes:14]

[0001437749-22-002208:notes:15]
[same as prior period, unchanged from 0001437749-21-025699:notes:15]

[0001437749-22-002208:notes:16]
[same as prior period, unchanged from 0001437749-21-025699:notes:16]

[0001437749-22-002208:notes:17]
The Neeltran Acquisition completed by the Company during the nine months ended  December 31, 2021 has been accounted for under the purchase method of accounting in accordance with ASC 805, Business Combinations. The Company allocated the purchase price to the assets acquired and liabilities assumed at their estimated fair values as of the date of Neeltran Acquisition. The excess of the purchase price paid by the Company over the estimated fair value of net assets acquired has been recorded as goodwill. As Neeltran was previously a private company, the adoption of Accounting Standards Codification 842 ("ASC 842") was completed as part of the Neeltran Acquisition. See Note 15 "Leases" for further details. Neeltran had previously adopted Accounting Standards Codification 606, Revenue from Contracts with Customers ("ASC 606") as part of prior year audited financial statements.

[0001437749-22-002208:notes:18]
[same as prior period, unchanged from 0001437749-21-025699:notes:18]

[0001437749-22-002208:notes:19]
[same as prior period, unchanged from 0001437749-21-025699:notes:19]

[0001437749-22-002208:notes:20]
Inventory include
     s a $0.6 million adjustment to step up the inventory balance to fair value consistent with the purchase price allocation. The fair value was based on the estimated selling price of the inventory, less the remaining manufacturing and selling cost and a normal profit margin on those manufacturing and selling efforts. The inventory step up adjustment increased cost of revenue $0.6 million in the nine month period ended  December 31, 2021 as the inventory was sold. This increase is not reflected in the pro forma condensed combined statements of operations because it does not have a continuing impact beyond the
     first year.

[0001437749-22-002208:notes:21]
[same as prior period, unchanged from 0001437749-21-025699:notes:21]

[0001437749-22-002208:notes:22]
[same as prior period, unchanged from 0001437749-21-025699:notes:22]

[0001437749-22-002208:notes:23]
[same as prior period, unchanged from 0001437749-21-025699:notes:23]

[0001437749-22-002208:notes:24]
[same as prior period, unchanged from 0001437749-21-025699:notes:24]

[0001437749-22-002208:notes:25]
The results of Neeltran's operations, are included in the Company's consolidated results from the date of the Neeltran Acquisition of
      May 6, 2021, for the
     nine months ended
      December 31, 2021. In the unaudited consolidated results for the
     nine months ended
      December 31, 2021, Neeltran contributed $
     17.1 million of revenue and
      $1.2 million in net loss for the Company.

[0001437749-22-002208:notes:26]
[same as prior period, unchanged from 0001437749-21-025699:notes:26]

[0001437749-22-002208:notes:27]
[same as prior period, unchanged from 0001437749-21-025699:notes:27]

[0001437749-22-002208:notes:28]
[same as prior period, unchanged from 0001437749-21-025699:notes:28]

[0001437749-22-002208:notes:29]
[same as prior period, unchanged from 0001437749-21-025699:notes:29]

[0001437749-22-002208:notes:30]
[same as prior period, unchanged from 0001437749-21-025699:notes:30]

[0001437749-22-002208:notes:31]
[same as prior period, unchanged from 0001437749-21-025699:notes:31]

[0001437749-22-002208:notes:32]
[same as prior period, unchanged from 0001437749-21-025699:notes:32]

[0001437749-22-002208:notes:33]
The fair value of the contingent consideration was determined using a Monte Carlo model and is accounted for as a derivative liability which is revalued at the fair value determined at each subsequent balance sheet date until the contingencies are resolved and the shares to be issued are determined, with the change in fair value recorded in the current period operating loss or (income).  See Note 13, "Contingent Consideration" for further details and a summary of key assumptions used to determine fair value in each period.

[0001437749-22-002208:notes:34]
[same as prior period, unchanged from 0001437749-21-025699:notes:34]

[0001437749-22-002208:notes:35]
[same as prior period, unchanged from 0001437749-21-025699:notes:35]

[0001437749-22-002208:notes:36]
[same as prior period, unchanged from 0001437749-21-025699:notes:36]

[0001437749-22-002208:notes:37]
[same as prior period, unchanged from 0001437749-21-025699:notes:37]

[0001437749-22-002208:notes:38]
[same as prior period, unchanged from 0001437749-21-025699:notes:38]

[0001437749-22-002208:notes:39]
[same as prior period, unchanged from 0001437749-21-025699:notes:39]

[0001437749-22-002208:notes:40]
Goodwill represents the value associated with the acquired workforce and expected synergies related to the business combination of the two companies. Goodwill resulting from the NEPSI Acquisition was assigned to the Company’s Grid business segment.  Goodwill recognized in the NEPSI Acquisition is not deductible for tax purposes. The $1.7 million of deferred tax liability is primarily related to inventory step up and intangibles.

[0001437749-22-002208:notes:41]
[same as prior period, unchanged from 0001437749-21-025699:notes:41]

[0001437749-22-002208:notes:42]
The unaudited pro forma condensed consolidated statement of operations for the
     three and nine months ended
      December 31, 2021 and 
     2020 is presented as if the NEPSI Acquisition and Neeltran Acquisition had occurred on
      April 1, 2020.

[0001437749-22-002208:notes:43]
|  |  | Three Months Ended December 31, |  |  | Nine Months Ended December 31, |  |
|  |  | 2021 |  |  | 2020 |  |  | 2021 |  |  | 2020 |  |
| Revenues |  |  | $ 26,799 |  |  |  | $ 26,528 |  |  |  | $ 82,957 |  |  |  | $ 91,387 |  |
| Operating loss |  |  | (4,390) |  |  |  | (12,509) |  |  |  | (15,521) |  |  |  | (21,100) |  |
| Net loss |  |  | $ (4,333) |  |  |  | $ (13,137) |  |  |  | $ (16,142) |  |  |  | $ (16,883) |  |
| Net loss per common share |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  |  | $ (0.16) |  |  |  | $ (0.51) |  |  |  | $ (0.59) |  |  |  | $ (0.71) |  |
| Diluted |  |  | $ (0.16) |  |  |  | $ (0.51) |  |  |  | $ (0.59) |  |  |  | $ (0.71) |  |
| Shares - basic |  |  | 27,351 |  |  |  | 25,772 |  |  |  | 27,185 |  |  |  | 23,898 |  |
| Shares - diluted |  |  | 27,351 |  |  |  | 25,772 |  |  |  | 27,185 |  |  |  | 23,898 |  |

[0001437749-22-002208:notes:44]
[same as prior period, unchanged from 0001437749-21-025699:notes:44]


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001437749-22-002208:notes:45]
[same as prior period, unchanged from 0001437749-21-025699:notes:45]

[0001437749-22-002208:notes:46]
The Company’s revenues in its Grid business segment are derived primarily through enabling the transmission and distribution of power, providing planning services that allow it to identify power grid needs and risks, and developing ship protection systems for the U.S. Navy. The Company’s revenues in its Wind business segment are derived primarily through supplying advanced power electronics and control systems, licensing its highly engineered wind turbine designs, and providing extensive customer support services to wind turbine manufacturers. The Company records revenue based on a five-step model in accordance with ASC 606. For its customer contracts, the Company identifies the performance obligations, determines the transaction price, allocates the contract transaction price to the performance obligations, and recognizes the revenue when (or as) control of goods or services is transferred to the customer. In the three and nine months ended  December 31, 2021, 79% and 76% of revenue, respectively, was recognized at the point in time when control transferred to the customer, with the remainder being recognized over time. In the three and nine months ended  December 31, 2020, 78% and 79% of revenue, respectively, was recognized at the point in time when control transferred to the customer, with the remainder being recognized over time.

[0001437749-22-002208:notes:47]
[same as prior period, unchanged from 0001437749-21-025699:notes:47]

[0001437749-22-002208:notes:48]
The Company's equipment and system product line includes certain contracts which do not meet the requirements of an exchange transaction and therefore do not fall within the scope of ASC 606.  As these non-exchange transaction contracts are considered grant revenue and do not fall within any specific accounting literature, the Company follows guidance within ASC 606 by analogy to recognize grant revenue over time.  In the three and nine months ended  December 31, 2021, the Company recorded $0.1 million and $0.9 million in grant revenue, respectively, which is included in the Company’s Grid business segment revenue. In the three and nine months ended  December 31, 2020, the Company recorded $1.1 million and $1.8 million in grant revenue, respectively, which is included in the Company's Grid segment revenue.

[0001437749-22-002208:notes:49]
[same as prior period, unchanged from 0001437749-21-025699:notes:49]

[0001437749-22-002208:notes:50]
[same as prior period, unchanged from 0001437749-21-025699:notes:50]

[0001437749-22-002208:notes:51]
[same as prior period, unchanged from 0001437749-21-025699:notes:51]

[0001437749-22-002208:notes:52]
[same as prior period, unchanged from 0001437749-21-025699:notes:52]

[0001437749-22-002208:notes:53]
[same as prior period, unchanged from 0001437749-21-025699:notes:53]

[0001437749-22-002208:notes:54]
[same as prior period, unchanged from 0001437749-21-025699:notes:54]

[0001437749-22-002208:notes:55]
[same as prior period, unchanged from 0001437749-21-025699:notes:55]

[0001437749-22-002208:notes:56]
|  |  | Three Months Ended December 31, 2021 |  |  | Nine Months Ended December 31, 2021 |  |
| Product Line: |  | Grid |  |  | Wind |  |  | Grid |  |  | Wind |  |
| Equipment and systems |  | $ | 23,416 |  |  | $ | 1,309 |  |  | $ | 67,605 |  |  | $ | 4,168 |  |
| Services and technology development |  |  | 1,634 |  |  |  | 440 |  |  |  | 5,564 |  |  |  | 2,789 |  |
| Total |  | $ | 25,050 |  |  | $ | 1,749 |  |  | $ | 73,169 |  |  | $ | 6,957 |  |
| Region: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas |  | $ | 16,739 |  |  | $ | 56 |  |  | $ | 57,498 |  |  | $ | 134 |  |
| Asia Pacific |  |  | 7,064 |  |  |  | 1,690 |  |  |  | 10,931 |  |  |  | 6,781 |  |
| EMEA |  |  | 1,247 |  |  |  | 3 |  |  |  | 4,740 |  |  |  | 42 |  |
| Total |  | $ | 25,050 |  |  | $ | 1,749 |  |  | $ | 73,169 |  |  | $ | 6,957 |  |

[0001437749-22-002208:notes:57]
|  |  | Three Months Ended December 31, 2020 |  |  | Nine Months Ended December 31, 2020 |  |
| Product Line: |  | Grid |  |  | Wind |  |  | Grid |  |  | Wind |  |
| Equipment and systems |  | $ | 15,930 |  |  | $ | 6,153 |  |  | $ | 47,729 |  |  | $ | 12,828 |  |
| Services and technology development |  |  | 1,156 |  |  |  | 393 |  |  |  | 3,420 |  |  |  | 1,984 |  |
| Total |  | $ | 17,086 |  |  | $ | 6,546 |  |  | $ | 51,149 |  |  | $ | 14,812 |  |
| Region: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas |  | $ | 13,394 |  |  | $ | 14 |  |  | $ | 39,626 |  |  | $ | 56 |  |
| Asia Pacific |  |  | 351 |  |  |  | 6,461 |  |  |  | 6,736 |  |  |  | 14,463 |  |
| EMEA |  |  | 3,341 |  |  |  | 71 |  |  |  | 4,787 |  |  |  | 293 |  |
| Total |  | $ | 17,086 |  |  | $ | 6,546 |  |  | $ | 51,149 |  |  | $ | 14,812 |  |

[0001437749-22-002208:notes:58]
As of  December 31, 2021, and 2020, the Company’s contract assets and liabilities primarily relate to the timing differences between cash received from a customer in connection with contractual rights to invoicing and the timing of revenue recognition following completion of performance obligations. The Company's accounts receivable balance is made up entirely of customer contract related balances. Changes in the Company’s contract assets, which are included in “Unbilled accounts receivable” and “Deferred program costs” (see Note 8, “Accounts Receivable” and Note 9, “Inventory” for a reconciliation to the condensed consolidated balance sheets) and "Contract liabilities", which are included in the current portion and long-term portion of "Deferred revenue" in the Company’s condensed consolidated balance sheets, are as follows (in thousands):

[0001437749-22-002208:notes:59]
|  |  | Unbilled Accounts Receivable |  |  | Deferred Program Costs |  |  | Contract Liabilities |  |
| Beginning balance as of March 31, 2021 |  | $ | 5,765 |  |  | $ | 977 |  |  | $ | 21,257 |  |
| Increases for costs incurred to fulfill performance obligations |  |  | — |  |  |  | 3,140 |  |  |  | — |  |
| Increase for balances acquired |  |  | — |  |  |  | 634 |  |  |  | 10,048 |  |
| Increase (decrease) due to customer billings |  |  | (11,214 | ) |  |  | — |  |  |  | 55,354 |  |
| Decrease due to cost recognition on completed performance obligations |  |  | — |  |  |  | (4,128 | ) |  |  | — |  |
| Increase (decrease) due to recognition of revenue based on transfer of control of performance obligations |  |  | 12,186 |  |  |  | — |  |  |  | (55,318 | ) |
| Other changes and FX impact |  |  | — |  |  |  | (8 | ) |  |  | 137 |  |
| Ending balance as of December 31, 2021 |  | $ | 6,737 |  |  | $ | 615 |  |  | $ | 31,478 |  |

[0001437749-22-002208:notes:60]
|  |  | Unbilled Accounts Receivable |  |  | Deferred Program Costs |  |  | Contract Liabilities |  |
| Beginning balance as of March 31, 2020 |  | $ | 5,711 |  |  | $ | 1,631 |  |  | $ | 26,142 |  |
| Increases for costs incurred to fulfill performance obligations |  |  | — |  |  |  | 6,635 |  |  |  | — |  |
| Increase for balance acquired |  |  | 101 |  |  |  | — |  |  |  | 2,700 |  |
| Increase (decrease) due to customer billings |  |  | (8,255 | ) |  |  | — |  |  |  | 42,785 |  |
| Decrease due to cost recognition on completed performance obligations |  |  | — |  |  |  | (6,969 | ) |  |  | — |  |
| Increase (decrease) due to recognition of revenue based on transfer of control of performance obligations |  |  | 6,644 |  |  |  | — |  |  |  | (48,274 | ) |
| Other changes and FX impact |  |  | — |  |  |  | 33 |  |  |  | 1,025 |  |
| Ending balance as of December 31, 2020 |  | $ | 4,201 |  |  | $ | 1,330 |  |  | $ | 24,378 |  |

[0001437749-22-002208:notes:61]
The Company’s remaining performance obligations represent the unrecognized revenue value of the Company’s contractual commitments. The Company’s performance obligations  may vary significantly each reporting period based on the timing of major new contractual commitments. As of  December 31, 2021, the Company had outstanding performance obligations on existing contracts under ASC 606 to be recognized in the next twelve months of approximately $80.6 million. There are also approximately $8.0 million of outstanding performance obligations to be recognized over a period of thirteen to sixty months. The remaining performance obligations are subject to customer actions and therefore the timing of revenue recognition cannot be reasonably estimated. The twelve-month performance obligations include anticipated shipments to Inox based on the twelve-month rolling forecast provided by Inox on the multi-year supply contract. The quantities specified in any forecast provided by Inox related to the multi-year supply contract are firm and irrevocable for the first three months of a twelve-month rolling forecast. The timing of the performance obligations beyond the twelve-month forecast provided by Inox are not determinable and therefore are not included in the total remaining performance obligations.

[0001437749-22-002208:notes:62]
The following table sets forth customers who represented 10% or more of the Company’s total revenues for the three and nine months ended  December 31, 2021 and 2020:

[0001437749-22-002208:notes:63]
|  |  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  | Reportable |  | December 31, |  |  | December 31, |  |
|  | Segment |  | 2021 |  |  | 2020 |  |  | 2021 |  |  | 2020 |  |
| Inox Wind Limited | Wind |  | <10% |  |  |  | 24 | % |  |  | <10% |  |  |  | 12 | % |
| Fuji Bridex PTE Ltd | Grid |  | 20 | % |  |  | <10% |  |  |  | 10 | % |  |  | <10% |  |
| EPC Services | Grid |  | <10% |  |  |  | 14 | % |  |  | <10% |  |  |  | 17 | % |


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001437749-22-002208:notes:64]
[same as prior period, unchanged from 0001437749-21-025699:notes:64]

[0001437749-22-002208:notes:65]
The Company accounts for its stock-based compensation at fair value. The following table summarizes stock-based compensation expense by financial statement line item for the three and nine months ended  December 31, 2021 and 2020 (in thousands):

[0001437749-22-002208:notes:66]
|  |  | Three Months Ended December 31, |  |  | Nine Months Ended December 31, |  |
|  |  | 2021 |  |  | 2020 |  |  | 2021 |  |  | 2020 |  |
| Cost of revenues |  | $ | 36 |  |  | $ | (23 | ) |  | $ | 148 |  |  | $ | 35 |  |
| Research and development |  |  | 190 |  |  |  | 179 |  |  |  | 629 |  |  |  | 470 |  |
| Selling, general and administrative |  |  | 894 |  |  |  | 683 |  |  |  | 2,736 |  |  |  | 2,092 |  |
| Total |  | $ | 1,120 |  |  | $ | 839 |  |  | $ | 3,513 |  |  | $ | 2,597 |  |

[0001437749-22-002208:notes:67]
The Company issued 370,700 shares of restricted stock awards and 166,648 shares of immediately vested common stock, of which 158,356 shares were issued in-lieu of cash bonuses during the nine months ended  December 31, 2021. The Company issued 27,341 shares of immediately vested common stock and 697,167 shares of restricted stock awards during the nine months ended  December 31, 2020. These restricted stock awards generally vest over 2-3 years.  Awards for restricted stock include both time-based and performance-based awards.  For options and restricted stock awards that vest upon the passage of time, expense is being recorded over the vesting period.  Performance-based awards are expensed over the requisite service period based on probability of achievement.

[0001437749-22-002208:notes:68]
The estimated fair value of the Company’s stock-based awards, less expected annual forfeitures, is amortized over the awards’ service period. The Company has no unrecognized compensation cost for unvested outstanding stock options at  December 31, 2021. The total unrecognized compensation cost for unvested outstanding restricted stock was $6.5 million at  December 31, 2021. This expense will be recognized over a weighted-average expense period of approximately 1.6 years.

[0001437749-22-002208:notes:69]
The Company did not grant any stock options during the three and nine months ended  December 31, 2021 or  December 31, 2020.


## us-gaap:EarningsPerShareTextBlock

[0001437749-22-002208:notes:70]
[same as prior period, unchanged from 0001437749-21-025699:notes:70]

[0001437749-22-002208:notes:71]
Basic net loss per share (“EPS”) is computed by dividing net loss by the weighted-average number of common shares outstanding for the period. Where applicable, diluted EPS is computed by dividing the net loss by the weighted-average number of common shares and dilutive common equivalent shares outstanding during the period, calculated using the treasury stock method. Common equivalent shares include the effect of restricted stock, exercise of stock options and warrants and contingently issuable shares. Stock options and warrants that are out-of-the-money with exercise prices greater than the average market price of the underlying common shares and shares of performance-based restricted stock where the contingency was not met are excluded from the computation of diluted EPS as the effect of their inclusion would be anti-dilutive.  For each of the three and nine months ended  December 31, 2021, and 2020, 1.1 million shares were not included in the calculation of diluted EPS.  Of these, 1.0 million relate to shares tied to the derivative liability for which the contingency has not yet been met, and 0.1 million relate to outstanding stock options as they were considered anti-dilutive.

[0001437749-22-002208:notes:72]
The following table reconciles the numerators and denominators of the earnings per share calculation for the three and nine months ended  December 31, 2021 and 2020 (in thousands, except per share data):

[0001437749-22-002208:notes:73]
|  |  | Three Months Ended December 31, |  |  | Nine Months Ended December 31, |  |
|  |  | 2021 |  |  | 2020 |  |  | 2021 |  |  | 2020 |  |
| Numerator: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net loss |  | $ | (4,324 | ) |  | $ | (7,933 | ) |  | $ | (14,161 | ) |  | $ | (15,062 | ) |
| Denominator: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Weighted-average shares of common stock outstanding |  |  | 28,418 |  |  |  | 26,532 |  |  |  | 28,234 |  |  |  | 24,143 |  |
| Weighted-average shares subject to repurchase |  |  | (1,066 | ) |  |  | (1,062 | ) |  |  | (1,089 | ) |  |  | (1,132 | ) |
| Shares used in per-share calculation ― basic |  |  | 27,352 |  |  |  | 25,470 |  |  |  | 27,145 |  |  |  | 23,011 |  |
| Shares used in per-share calculation ― diluted |  |  | 27,352 |  |  |  | 25,470 |  |  |  | 27,145 |  |  |  | 23,011 |  |
| Net loss per share ― basic |  | $ | (0.16 | ) |  | $ | (0.31 | ) |  | $ | (0.52 | ) |  | $ | (0.65 | ) |
| Net loss per share ― diluted |  | $ | (0.16 | ) |  | $ | (0.31 | ) |  | $ | (0.52 | ) |  | $ | (0.65 | ) |


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001437749-22-002208:notes:74]
[same as prior period, unchanged from 0001437749-21-025699:notes:74]

[0001437749-22-002208:notes:75]
[same as prior period, unchanged from 0001437749-21-025699:notes:75]

[0001437749-22-002208:notes:76]
Goodwill represents the difference between the purchase price and the fair value of the identifiable tangible and intangible net assets when accounted for using the purchase method of accounting. The Company's goodwill balance relates to the Neeltran Acquisition in the current fiscal year, the NEPSI Acquisition in fiscal 2020, and the acquisition of Infinia Technology Corporation in fiscal 2017 and is reported in the Grid business segment. Goodwill is not amortized but reviewed for impairment. Goodwill is reviewed annually and whenever events or changes in circumstances indicate that the carrying value of the goodwill might not be recoverable.

[0001437749-22-002208:notes:77]
[same as prior period, unchanged from 0001437749-21-025699:notes:77]

[0001437749-22-002208:notes:78]
|  |  | Goodwill |  |
| March 31, 2021 |  | $ | 34,634 |  |
| Neeltran Acquisition |  |  | 8,837 |  |
| Less impairment loss |  |  | - |  |
| December 31, 2021 |  | $ | 43,471 |  |

[0001437749-22-002208:notes:79]
The Company did not identify any triggering events in the three and nine months ended  December 31, 2021 that would require interim impairment testing of goodwill.

[0001437749-22-002208:notes:80]
[same as prior period, unchanged from 0001437749-21-025699:notes:80]

[0001437749-22-002208:notes:81]
Intangible assets at  December 31, 2021 and  March 31, 2021 consisted of the following (in thousands):

[0001437749-22-002208:notes:82]
|  |  | December 31, 2021 |  |  | March 31, 2021 |  |  |  |  |  |
|  |  | Gross Amount |  |  | Accumulated Amortization |  |  | Net Book Value |  |  | Gross Amount |  |  | Accumulated Amortization |  |  | Net Book Value |  |  | Estimated Useful Life |  |
| Backlog |  | $ | 681 |  |  | $ | (614 | ) |  | $ | 67 |  |  | $ | 600 |  |  | $ | (475 | ) |  | $ | 125 |  |  |  | 2 |  |
| Trade name |  |  | 1,800 |  |  |  | — |  |  |  | 1,800 |  |  |  | 600 |  |  |  | — |  |  |  | 600 |  |  |  | Indefinite |  |
| Customer relationships |  |  | 9,600 |  |  |  | (2,217 | ) |  |  | 7,383 |  |  |  | 6,100 |  |  |  | (739 | ) |  |  | 5,361 |  |  |  | 7 |  |
| Core technology and know-how |  |  | 5,970 |  |  |  | (3,265 | ) |  |  | 2,705 |  |  |  | 5,970 |  |  |  | (2,903 | ) |  |  | 3,067 |  |  |  | 5-10 |  |
| Intangible assets |  | $ | 18,051 |  |  | $ | (6,096 | ) |  | $ | 11,955 |  |  | $ | 13,270 |  |  | $ | (4,117 | ) |  | $ | 9,153 |  |  |  |  |  |

[0001437749-22-002208:notes:83]
The Company recorded intangible amortization expense related to customer relationship and core technology and know-how of $0.6 million and $1.8 million, in the three and nine months ended  December 31, 2021, respectively, and $0.4 million and $0.6 million in the three and nine months ended  December 31, 2020, respectively. Additionally, the Company recorded intangible amortization related to backlog that is reported in cost of revenues of $0.1 million in each of the three and nine months ended  December 31, 2021, respectively, and $0.3 million in each of the three and nine months ended  December 31, 2020.

[0001437749-22-002208:notes:84]
[same as prior period, unchanged from 0001437749-21-025699:notes:84]

[0001437749-22-002208:notes:85]
| Years ended March 31, |  | Total |  |
| 2022 |  |  | 672 |  |
| 2023 |  |  | 2,772 |  |
| 2024 |  |  | 2,152 |  |
| 2025 |  |  | 1,648 |  |
| 2026 |  |  | 1,221 |  |
| Thereafter |  |  | 1,690 |  |
| Total |  | $ | 10,155 |  |

[0001437749-22-002208:notes:86]
[same as prior period, unchanged from 0001437749-21-025699:notes:86]


## us-gaap:FairValueDisclosuresTextBlock

[0001437749-22-002208:notes:87]
[same as prior period, unchanged from 0001437749-21-025699:notes:87]

[0001437749-22-002208:notes:88]
[same as prior period, unchanged from 0001437749-21-025699:notes:88]

[0001437749-22-002208:notes:89]
[same as prior period, unchanged from 0001437749-21-025699:notes:89]

[0001437749-22-002208:notes:90]
The Company provides a gross presentation of activity within Level 3 measurement roll-forward and details of transfers in and out of Level 1 and 2 measurements.  A change in the hierarchy of an investment from its current level is reflected in the period during which the pricing methodology of such investment changes.  Disclosure of the transfer of securities from Level 1 to Level 2 or Level 3 is made in the event that the related security is significant to total cash and investments.  The Company did not have any transfers of assets and liabilities from Level 1, Level 2 or Level 3 of the fair value measurement hierarchy during the nine months ended  December 31, 2021.

[0001437749-22-002208:notes:91]
[same as prior period, unchanged from 0001437749-21-025699:notes:91]

[0001437749-22-002208:notes:92]
[same as prior period, unchanged from 0001437749-21-025699:notes:92]

[0001437749-22-002208:notes:93]
[same as prior period, unchanged from 0001437749-21-025699:notes:93]

[0001437749-22-002208:notes:94]
[same as prior period, unchanged from 0001437749-21-025699:notes:94]

[0001437749-22-002208:notes:95]
[same as prior period, unchanged from 0001437749-21-025699:notes:95]

[0001437749-22-002208:notes:96]
Marketable securities consist of certificates of deposit that are measured using such inputs as quoted prices and are classified within Level 1 of the valuation hierarchy. The Company determines the appropriate classification of its marketable securities at the time of purchase and re-evaluates such classification as of each balance sheet date.  All marketable securities are considered available for sale and are carried at fair value. Changes in fair value are recorded to other income (expense), net.  The Company had no outstanding marketable securities as of  December 31, 2021 and the Company recognized no change in the three and nine months ended  December 31, 2021. The Company recognized no change in the three months ended  December 31, 2020 and $0.2 million in unrealized losses on marketable securities, which is recorded in other income (expense), net, for the nine months ended  December 30, 2020 and less than a $0.1 million gain which was recognized during the nine months ended  December 31, 2020 upon the sale of one of the certificates of deposit. The Company periodically reviews the realizability of each short and long term marketable security when impairment indicators exist with respect to the security. If other than temporary impairment of value of the security exists, the carrying value of the security is written down to its estimated fair value.

[0001437749-22-002208:notes:97]
[same as prior period, unchanged from 0001437749-21-025699:notes:97]

[0001437749-22-002208:notes:98]
Contingent consideration relates to the earnout payment set forth in the NEPSI Stock Purchase Agreement that provides that the selling stockholders  may receive up to an additional 1,000,000 shares of common stock of the Company upon the achievement of certain specified revenue objectives over varying periods of up to four years following the NEPSI Acquisition Date. See Note 13, "Contingent Consideration" and Note 2, “Acquisitions” for further discussion. The Company relied on a Monte Carlo method to determine the fair value of the contingent consideration on the NEPSI Acquisition Date and will continue to revalue the fair value of the contingent consideration using the same method at each subsequent balance sheet date until the contingencies are resolved and the shares to be issued are determined, with the change in fair value recorded in the current period operating loss.

[0001437749-22-002208:notes:99]
The following table provides the assets and liabilities carried at fair value on a recurring basis, measured as of  December 31, 2021 and  March 31, 2021 (in thousands):

[0001437749-22-002208:notes:100]
|  |  | Total Carrying Value |  |  | Quoted Prices in Active Markets (Level 1) |  |  | Significant Other Observable Inputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |
| December 31, 2021: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash equivalents |  | $ | 20,110 |  |  | $ | 20,110 |  |  | $ | — |  |  | $ | — |  |
| Marketable securities |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Derivative liabilities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Contingent consideration |  | $ | 2,610 |  |  | $ | — |  |  | $ | — |  |  | $ | 2,610 |  |

[0001437749-22-002208:notes:101]
[same as prior period, unchanged from 0001437749-21-025699:notes:101]

[0001437749-22-002208:notes:102]
[same as prior period, unchanged from 0001437749-21-025699:notes:102]

[0001437749-22-002208:notes:103]
|  |  | Acquisition Contingent Consideration |  |
| Balance at March 31, 2021 |  | $ | 7,050 |  |
| Change in fair value |  |  | (4,440 | ) |
| Balance at December 31, 2021 |  | $ | 2,610 |  |


## amsc:AccountsReceivableTextBlock

[0001437749-22-002208:notes:104]
[same as prior period, unchanged from 0001437749-21-025699:notes:104]

[0001437749-22-002208:notes:105]
Accounts receivable at  December 31, 2021 and  March 31, 2021 consisted of the following (in thousands):

[0001437749-22-002208:notes:106]
|  |  | December 31, 2021 |  |  | March 31, 2021 |  |
| Accounts receivable (billed) |  | $ | 14,312 |  |  | $ | 7,502 |  |
| Accounts receivable (unbilled) |  |  | 6,737 |  |  |  | 5,765 |  |
| Accounts receivable, net |  | $ | 21,049 |  |  | $ | 13,267 |  |


## us-gaap:InventoryDisclosureTextBlock

[0001437749-22-002208:notes:107]
[same as prior period, unchanged from 0001437749-21-025699:notes:107]

[0001437749-22-002208:notes:108]
Inventory, net of reserves, at  December 31, 2021 and  March 31, 2021 consisted of the following (in thousands):

[0001437749-22-002208:notes:109]
|  |  | December 31, 2021 |  |  | March 31, 2021 |  |
| Raw materials |  | $ | 11,409 |  |  | $ | 8,255 |  |
| Work-in-process |  |  | 7,762 |  |  |  | 3,297 |  |
| Finished goods |  |  | 1,156 |  |  |  | 777 |  |
| Deferred program costs |  |  | 615 |  |  |  | 977 |  |
| Net inventory |  | $ | 20,942 |  |  | $ | 13,306 |  |

[0001437749-22-002208:notes:110]
The Company recorded inventory write-downs of $0.4 million in each of the three months ended  December 31, 2021 and 2020, respectively. The Company recorded inventory write-downs of $1.6 million in each of the nine months ended  December 31, 2021 and 2020, respectively.  These write-downs were based on the Company's evaluation of its inventory on hand for excess quantities and obsolescence.

[0001437749-22-002208:notes:111]
Deferred program costs as of  December 31, 2021, and  March 31, 2021, primarily represent costs incurred on programs where the Company needs to complete performance obligations before the related revenue and costs will be recognized.


## us-gaap:PropertyPlantAndEquipmentDisclosureTextBlock

[0001437749-22-002208:notes:112]
[same as prior period, unchanged from 0001437749-21-025699:notes:112]

[0001437749-22-002208:notes:113]
The cost and accumulated depreciation of property, plant and equipment at  December 31, 2021 and  March 31, 2021 are as follows (in thousands):

[0001437749-22-002208:notes:114]
|  |  | December 31, 2021 |  |  | March 31, 2021 |  |
| Construction in progress - equipment |  | $ | 506 |  |  | $ | 220 |  |
| Land |  |  | 980 |  |  |  | 270 |  |
| Building |  |  | 5,270 |  |  |  | 1,630 |  |
| Equipment and software |  |  | 43,721 |  |  |  | 41,652 |  |
| Finance lease - right of use asset |  |  | 9 |  |  |  | — |  |
| Furniture and fixtures |  |  | 1,381 |  |  |  | 1,333 |  |
| Leasehold improvements |  |  | 6,594 |  |  |  | 6,308 |  |
| Property, plant and equipment, gross |  |  | 58,461 |  |  |  | 51,413 |  |
| Less accumulated depreciation |  |  | (44,343 | ) |  |  | (42,416 | ) |
| Property, plant and equipment, net |  | $ | 14,118 |  |  | $ | 8,997 |  |

[0001437749-22-002208:notes:115]
Depreciation expense was $0.7 million and $1.2 million for the three months ended  December 31, 2021 and 2020, respectively. Depreciation expense was $2.0 million and $2.9 million for the nine months ended  December 31, 2021 and 2020, respectively. The increase in land and building relates to the property added as part of the Neeltran Acquisition.


## us-gaap:AccountsPayableAndAccruedLiabilitiesDisclosureTextBlock

[0001437749-22-002208:notes:116]
[same as prior period, unchanged from 0001437749-21-025699:notes:116]

[0001437749-22-002208:notes:117]
Accounts payable and accrued expenses at  December 31, 2021 and  March 31, 2021 consisted of the following (in thousands):

[0001437749-22-002208:notes:118]
|  |  | December 31, 2021 |  |  | March 31, 2021 |  |
| Accounts payable |  | $ | 10,438 |  |  | $ | 5,353 |  |
| Accrued inventories in-transit |  |  | 1,711 |  |  |  | 1,460 |  |
| Accrued other miscellaneous expenses |  |  | 3,517 |  |  |  | 2,369 |  |
| Advanced deposits |  |  | 2,153 |  |  |  | 1,035 |  |
| Accrued compensation |  |  | 3,691 |  |  |  | 7,018 |  |
| Income taxes payable |  |  | 604 |  |  |  | 522 |  |
| Accrued product warranty |  |  | 2,218 |  |  |  | 2,053 |  |
| Total |  | $ | 24,332 |  |  | $ | 19,810 |  |

[0001437749-22-002208:notes:119]
[same as prior period, unchanged from 0001437749-21-025699:notes:119]

[0001437749-22-002208:notes:120]
[same as prior period, unchanged from 0001437749-21-025699:notes:120]

[0001437749-22-002208:notes:121]
|  |  | Three Months Ended December 31, |  |  | Nine Months Ended December 31, |  |
|  |  | 2021 |  |  | 2020 |  |  | 2021 |  |  | 2020 |  |
| Balance at beginning of period |  | $ | 2,155 |  |  | $ | 2,109 |  |  | $ | 2,053 |  |  | $ | 2,015 |  |
| Acquired warranty obligations |  |  | - |  |  |  | 147 |  |  |  | 248 |  |  |  | 147 |  |
| Change in accruals for warranties during the period |  |  | 206 |  |  |  | 124 |  |  |  | 520 |  |  |  | 507 |  |
| Settlements during the period |  |  | (143 | ) |  |  | (360 | ) |  |  | (603 | ) |  |  | (649 | ) |
| Balance at end of period |  | $ | 2,218 |  |  | $ | 2,020 |  |  | $ | 2,218 |  |  | $ | 2,020 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0001437749-22-002208:notes:122]
[same as prior period, unchanged from 0001437749-21-025699:notes:122]

[0001437749-22-002208:notes:123]
The Company recorded an income tax expense of $1.0 thousand and income tax benefit of $1.9 million in the three and nine months ended  December 31, 2021, respectively. The Company recorded an income tax benefit of $1.5 million and $1.2 million in the three and nine months period ended  December 31, 2020, respectively.

[0001437749-22-002208:notes:124]
As a result of a difference in book and tax basis related to the intangible assets acquired in the Neeltran Acquisition (see Note 2, "Acquisitions"), the Company recorded a deferred tax liability of $2.3 million. As a result, the Company was able to benefit from additional deferred tax assets and therefore released a corresponding valuation allowance of $2.3 million during the nine months ended  December 31, 2021.  The purchase price allocation is preliminary and has not been finalized as the analysis on the assets and liabilities acquired, primarily the tax related liability,  may require further adjustments to the Company's purchase accounting that could result in measurement period adjustments that would impact the Company's reported net assets and goodwill as of  May 6, 2021. Material changes, if any, to the preliminary allocation summarized in Note 2, "Acquisitions" will be reported once the related uncertainties are resolved, but no later than  May 6, 2022.  As a result of a difference in book and tax basis related to the intangible assets acquired in the NEPSI Acquisition, the Company recorded a deferred tax liability of $1.7 million. As a result, the Company was able to benefit from additional deferred tax assets and therefore released a corresponding valuation allowance of $1.7 million during the three and nine months ended  December 31, 2020. The purchase price allocation was final as of  October 1, 2021. Goodwill recognized in the Neeltran Acquisition and the NEPSI Acquisition is not deductible for tax purposes.

[0001437749-22-002208:notes:125]
Accounting for income taxes requires a two-step approach to recognizing and measuring uncertain tax positions.  The first step is to evaluate the tax position for recognition by determining if, based on the technical merits, it is more likely than not the position will be sustained upon audit, including resolution of related appeals or litigation processes, if any.  The second step is to measure the tax benefit as the largest amount that is more than 50% likely to be realized upon ultimate settlement.  The Company re-evaluates these uncertain tax positions on a quarterly basis.  The evaluation is based on factors including, but not limited to, changes in facts or circumstances, changes in tax law, effectively settled issues under audit and new audit activity.  Any changes in these factors could result in the recognition of a tax benefit or an additional charge to the tax provision.  The Company did not identify any uncertain tax positions in the nine months ended  December 31, 2021 and did not have any gross unrecognized tax benefits as of  December 31, 2021.


## amsc:BusinessCombinationContingentConsiderationTextBlock

[0001437749-22-002208:notes:126]
[same as prior period, unchanged from 0001437749-21-025699:notes:126]

[0001437749-22-002208:notes:127]
[same as prior period, unchanged from 0001437749-21-025699:notes:127]

[0001437749-22-002208:notes:128]
[same as prior period, unchanged from 0001437749-21-025699:notes:128]

[0001437749-22-002208:notes:129]
|  |  | December 31, |  |  | September 30, |  |  | June 30, |  |
| Fiscal Year 2021 |  | 2021 |  |  | 2021 |  |  | 2021 |  |
| Revenue risk premium |  |  | 6.60% |  |  |  | 6.60% |  |  |  | 6.60% |  |
| Revenue volatility |  |  | 33% |  |  |  | 30% |  |  |  | 30% |  |
| Stock Price |  |  | $10.88 |  |  |  | $14.58 |  |  |  | $17.39 |  |
| Payment delay (days) |  |  | 80 |  |  |  | 80 |  |  |  | 80 |  |
| Fair value (millions) |  |  | $2.6 |  |  |  | $4.7 |  |  |  | $7.2 |  |
|  |  | March 31, |  |  | December 31, |  |  | October 1, |  |
| Fiscal Year 2020 |  | 2021 |  |  | 2020 |  |  | 2020 |  |
| Revenue risk premium |  |  | 6.70% |  |  |  | 6.90% |  |  |  | 7.10% |  |
| Revenue volatility |  |  | 30% |  |  |  | 30% |  |  |  | 30% |  |
| Stock Price |  |  | $18.96 |  |  |  | $23.42 |  |  |  | $14.23 |  |
| Payment delay (days) |  |  | 80 |  |  |  | 80 |  |  |  | — |  |
| Fair value (millions) |  |  | $7.1 |  |  |  | $6.7 |  |  |  | $4.0 |  |

[0001437749-22-002208:notes:130]
The Company recorded a net gain of $2.1 million and $4.4 million resulting from the decrease in the fair value of the contingent consideration in the three and nine months ended  December 31, 2021, respectively. The Company recorded a net loss of $2.7 million resulting from the increase in the fair value of the contingent consideration in both the three and nine months period ended  December 31, 2020.


## us-gaap:DebtDisclosureTextBlock

[0001437749-22-002208:notes:131]
14. Debt

[0001437749-22-002208:notes:132]
As part of the Neeltran Acquisition, the Company identified four equipment financing agreements that Neeltran had entered into prior to the acquisition on  May 6, 2021. The Company determined to account for these agreements as a debt transaction and recorded current and long-term debt liabilities of $0.1 million each during the nine months ended  December 31, 2021.


## us-gaap:LesseeOperatingLeasesTextBlock

[0001437749-22-002208:notes:133]
[same as prior period, unchanged from 0001437749-21-025699:notes:133]

[0001437749-22-002208:notes:134]
[same as prior period, unchanged from 0001437749-21-025699:notes:134]

[0001437749-22-002208:notes:135]
[same as prior period, unchanged from 0001437749-21-025699:notes:135]

[0001437749-22-002208:notes:136]
[same as prior period, unchanged from 0001437749-21-025699:notes:136]

[0001437749-22-002208:notes:137]
[same as prior period, unchanged from 0001437749-21-025699:notes:137]

[0001437749-22-002208:notes:138]
[same as prior period, unchanged from 0001437749-21-025699:notes:138]

[0001437749-22-002208:notes:139]
[same as prior period, unchanged from 0001437749-21-025699:notes:139]

[0001437749-22-002208:notes:140]
[same as prior period, unchanged from 0001437749-21-025699:notes:140]

[0001437749-22-002208:notes:141]
As part of the adoption of ASC 842 at Neeltran, the Company identified one lease contract that is classified as a financing lease. In  February 2020, Neeltran entered into a contract to lease a copy machine for an initial term of 39 months, or through  May 2023. The Company concluded that the lease should be classified and accounted for as a finance lease as the total value of the lease payments are greater than fair value of the asset. Accordingly, on  May 6, 2021, the Company recognized a finance lease right-of-use asset and a finance lease liability of $13.2 thousand on the Neeltran opening balance sheet. As of  December 31, 2021, the right-of-use asset related to the finance lease was $9.1 thousand, net of accumulated amortization of $4.1 thousand, and is included in the property and equipment, net on the Company's consolidated balance sheet.

[0001437749-22-002208:notes:142]
[same as prior period, unchanged from 0001437749-21-025699:notes:142]

[0001437749-22-002208:notes:143]
Supplemental balance sheet information related to leases at  December 31, 2021, and  March 31, 2021 are as follows (in thousands):

[0001437749-22-002208:notes:144]
|  |  | December 31, 2021 |  |  | March 31, 2021 |  |
| Leases: |  |  |  |  |  |  |  |  |
| Right-of-use assets - Financing |  | $ | 9 |  |  |  | — |  |
| Right-of-use assets - Operating |  |  | 3,408 |  |  |  | 3,747 |  |
| Total right-of-use assets |  |  | 3,417 |  |  |  | 3,747 |  |
| Lease liabilities - ST Financing |  | $ | 5 |  |  |  | — |  |
| Lease liabilities - ST Operating |  |  | 696 |  |  |  | 612 |  |
| Lease liabilities - LT Financing |  |  | 4 |  |  |  | — |  |
| Lease liabilities - LT Operating |  |  | 2,838 |  |  |  | 3,246 |  |
| Total lease liabilities |  |  | 3,543 |  |  |  | 3,858 |  |
| Weighted-average remaining lease term |  |  | 5.09 |  |  |  | 5.82 |  |
| Weighted-average discount rate |  |  | 6.60 | % |  |  | 6.72 | % |

[0001437749-22-002208:notes:145]
The costs related to the Company's finance lease are not material. The costs related to the Company's operating leases for the three and nine months ended  December 31, 2021 and 2020 are as follows (in thousands):

[0001437749-22-002208:notes:146]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | December 31, 2021 |  |  | December 31, 2021 |  |
| Operating Leases: |  |  |  |  |  |  |  |  |
| Operating lease costs - fixed |  | $ | 238 |  |  | $ | 707 |  |
| Operating lease costs - variable |  |  | 33 |  |  |  | 97 |  |
| Short-term lease costs |  |  | 64 |  |  |  | 195 |  |
| Total lease costs |  |  | 335 |  |  |  | 999 |  |

[0001437749-22-002208:notes:147]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | December 31, 2020 |  |  | December 31, 2020 |  |
| Operating Leases: |  |  |  |  |  |  |  |  |
| Operating lease costs - fixed |  | $ | 226 |  |  | $ | 618 |  |
| Operating lease costs - variable |  |  | 31 |  |  |  | 87 |  |
| Short-term lease costs |  |  | 338 |  |  |  | 989 |  |
| Total lease costs |  |  | 595 |  |  |  | 1,694 |  |

[0001437749-22-002208:notes:148]
[same as prior period, unchanged from 0001437749-21-025699:notes:148]

[0001437749-22-002208:notes:149]
|  |  | Leases |  |
| Year ended March 31, |  |  |  |  |
| 2022 |  | $ | 229 |  |
| 2023 |  |  | 886 |  |
| 2024 |  |  | 798 |  |
| 2025 |  |  | 673 |  |
| 2026 |  |  | 672 |  |
| Thereafter |  |  | 934 |  |
| Total minimum lease payments |  |  | 4,192 |  |
| Less: interest |  |  | 649 |  |
| Present value of lease liabilities |  |  | 3,543 |  |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001437749-22-002208:notes:150]
16. Commitments and Contingencies

[0001437749-22-002208:notes:151]
Legal Contingencies

[0001437749-22-002208:notes:152]
From time to time, the Company is involved in legal and administrative proceedings and claims of various types. The Company records a liability in its consolidated financial statements for these matters when a loss is known or considered probable and the amount can be reasonably estimated. The Company reviews these estimates each accounting period as additional information is known and adjusts the loss provision when appropriate. If a matter is both probable to result in a liability and the amounts of loss can be reasonably estimated, the Company estimates and discloses the possible loss or range of loss to the extent necessary to make the consolidated financial statements not misleading. If the loss is not probable or cannot be reasonably estimated, a liability is not recorded in its consolidated financial statements.

[0001437749-22-002208:notes:153]
Other

[0001437749-22-002208:notes:154]
The Company enters into long-term construction contracts with customers that require the Company to obtain performance bonds. The Company is required to deposit an amount equivalent to some or all the face amount of the performance bonds into an escrow account until the termination of the bond. When the performance conditions are met, amounts deposited as collateral for the performance bonds are returned to the Company. In addition, the Company has various contractual arrangements in which minimum quantities of goods or services have been committed to be purchased on an annual basis.

[0001437749-22-002208:notes:155]
As of  December 31, 2021, the Company had $6.0 million of restricted cash included in long-term assets and $2.7 million of restricted cash included in current assets. As of  March 31, 2021, the Company had $5.6 million of restricted cash included in long term assets and $2.2 million of restricted cash included in current assets. These amounts included in restricted cash primarily represent deposits to secure letters of credit for various supply contracts and long-term projects, including the irrevocable letter of credit in the amount of $5.0 million to secure certain of the Company's obligations under a subcontract agreement with ComEd.  These deposits are held in interest bearing accounts.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001437749-22-002208:notes:156]
[same as prior period, unchanged from 0001437749-21-025699:notes:156]

[0001437749-22-002208:notes:157]
[same as prior period, unchanged from 0001437749-21-025699:notes:157]

[0001437749-22-002208:notes:158]
[same as prior period, unchanged from 0001437749-21-025699:notes:158]

[0001437749-22-002208:notes:159]
[same as prior period, unchanged from 0001437749-21-025699:notes:159]

[0001437749-22-002208:notes:160]
[same as prior period, unchanged from 0001437749-21-025699:notes:160]

[0001437749-22-002208:notes:161]
|  |  | Three Months Ended December 31, |  |  | Nine Months Ended December 31, |  |
|  |  | 2021 |  |  | 2020 |  |  | 2021 |  |  | 2020 |  |
| Revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Grid |  | $ | 25,050 |  |  | $ | 17,086 |  |  | $ | 73,169 |  |  | $ | 51,149 |  |
| Wind |  |  | 1,749 |  |  |  | 6,546 |  |  |  | 6,957 |  |  |  | 14,812 |  |
| Total |  | $ | 26,799 |  |  | $ | 23,632 |  |  | $ | 80,126 |  |  | $ | 65,961 |  |

[0001437749-22-002208:notes:162]
|  |  | Three Months Ended December 31, |  |  | Nine Months Ended December 31, |  |
|  |  | 2021 |  |  | 2020 |  |  | 2021 |  |  | 2020 |  |
| Operating Income (loss): |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Grid |  | $ | (3,691 | ) |  | $ | (5,826 | ) |  | $ | (14,873 | ) |  | $ | (8,388 | ) |
| Wind |  |  | (1,678 | ) |  |  | 147 |  |  |  | (2,236 | ) |  |  | (1,956 | ) |
| Unallocated corporate gain (expenses) |  |  | 989 |  |  |  | (3,579 | ) |  |  | 927 |  |  |  | (5,337 | ) |
| Total |  | $ | (4,380 | ) |  | $ | (9,258 | ) |  | $ | (16,182 | ) |  | $ | (15,681 | ) |

[0001437749-22-002208:notes:163]
[same as prior period, unchanged from 0001437749-21-025699:notes:163]

[0001437749-22-002208:notes:164]
Unallocated corporate expenses consist of a gain on contingent consideration of $2.1 million and $4.4 million in the three and nine months ended  December 31, 2021, respectively. Unallocated corporate expenses consist of a loss on contingent consideration of $2.7 million in both the three and nine months ended  December 31, 2020. Additionally, unallocated corporate expenses consist of stock-based compensation expense of $1.1 million and $0.8 million in the three months ended  December 31, 2021, and 2020, respectively, and $3.5 million and $2.6 million in the nine months ended  December 31, 2021, and 2020, respectively.

[0001437749-22-002208:notes:165]
Total assets for the two business segments as of  December 31, 2021, and  March 31, 2021, are as follows (in thousands):

[0001437749-22-002208:notes:166]
|  |  | December 31, 2021 |  |  | March 31, 2021 |  |
| Grid |  | $ | 113,512 |  |  | $ | 81,253 |  |
| Wind |  |  | 8,641 |  |  |  | 6,098 |  |
| Corporate assets |  |  | 53,143 |  |  |  | 81,515 |  |
| Total |  | $ | 175,296 |  |  | $ | 168,866 |  |


## us-gaap:NewAccountingPronouncementsAndChangesInAccountingPrinciplesTextBlock

[0001437749-22-002208:notes:167]
18. Recent Accounting Pronouncements

[0001437749-22-002208:notes:168]
In  June 2016, the FASB issued ASU 2016-13, Financial Instruments-Credit Losses (Topic 326): Measurement of Credit Losses on Financial Instruments. The amendments in ASU 2016-13 will provide more decision-useful information about the expected credit losses on financial instruments and other commitments to extend credit held by a reporting entity at each reporting date. Following the release of ASU 2019-10 in  November 2019, the new effective date, as long as the Company remains a smaller reporting company, would be annual reporting periods beginning after  December 15, 2022.  The Company is currently evaluating the impact, if any, that the adoption of ASU 2016-13  may have on its consolidated financial statements.

[0001437749-22-002208:notes:169]
In  December 2019, the FASB issued ASU 2019-12, Income Taxes (Topic 740): Simplifying the Accounting for Income Taxes. The amendments in ASU 2019-12 provide for simplified accounting to several income tax situations and removal of certain accounting exceptions. As of  April 1, 2021, we have adopted ASU 2019-12 and noted no material impact on our consolidated financial statements.

[0001437749-22-002208:notes:170]
In  October 2021, the FASB issued ASU 2021-08, Business Combinations (Topic 805): Accounting for Contract Assets and Contract Liabilities from Contracts with Customers. The amendments in ASU 2021-08 will improve the accounting for acquired revenue contracts with customers in a business combination. Following the release of ASU 2021-08 in  October 2021, the new effective date will be annual reporting periods beginning after  December 15, 2022. The Company is currently evaluating the impact, if any, that the adoption of ASU 2021-08  may have on its consolidated financial statements.

[0001437749-22-002208:notes:171]
In  November 2021, the FASB issued ASU 2021-10, Government Assistance (Topic 832): Disclosures by Business Entities about Government Assistance. The amendments in ASU 2021-10 will improve financial reporting by requiring disclosures that increase the transparency of transactions with government accounted for by applying a grant or contribution accounting model by analogy. Following the release of ASU 2021-10 in  November 2021, the new effective date will be annual reporting periods beginning after  December 15, 2021. The Company is currently evaluating the impact, if any, that the adoption of ASU 2021-10  may have on its consolidated financial statements.


## us-gaap:SubsequentEventsTextBlock

[0001437749-22-002208:notes:172]
19. Subsequent Events

[0001437749-22-002208:notes:173]
The Company has performed an evaluation of subsequent events through the time of filing this Quarterly Report on Form 10-Q with the SEC and has determined that there are no such events to report.
