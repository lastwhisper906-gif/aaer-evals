# AMSC note change history — 0001437749-21-025699 → 0001437749-22-002208


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2022-02-02):
[0001437749-22-002208:note_history:1]
As of  December 31, 2021, the Company had $6.0 million of restricted cash included in long-term assets and $2.7 million of restricted cash included in current assets. As of  March 31, 2021, the Company had $5.6 million of restricted cash included in long term assets and $2.2 million of restricted cash included in current assets. These amounts included in restricted cash primarily represent deposits to secure letters of credit for various supply contracts and long-term projects, including the irrevocable letter of credit in the amount of $5.0 million to secure certain of the Company's obligations under a subcontract agreement with ComEd.  These deposits are held in interest bearing accounts.
  (was, 2021-11-08, similarity 0.9948):
[0001437749-21-025699:note_history:1]
As of  September 30, 2021, the Company had $6.2 million of restricted cash included in long-term assets and $2.3 million of restricted cash included in current assets. As of  March 31, 2021, the Company had $5.6 million of restricted cash included in long term assets and $2.2 million of restricted cash included in current assets. These amounts included in restricted cash primarily represent deposits to secure letters of credit for various supply contracts and long-term projects, including the irrevocable letter of credit in the amount of $5.0 million to secure certain of the Company's obligations under a subcontract agreement with ComEd.  These deposits are held in interest bearing accounts.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2022-02-02):
[0001437749-22-002208:note_history:2]
These unaudited condensed consolidated financial statements of the Company have been prepared on a going concern basis in accordance with United States generally accepted accounting principles (“GAAP”) and the Securities and Exchange Commission’s (“SEC”) instructions to Form 10-Q. The going concern basis of presentation assumes that the Company will continue operations and will be able to realize its assets and discharge its liabilities and commitments in the normal course of business. Certain information and footnote disclosures normally included in the financial statements prepared in accordance with GAAP have been condensed or omitted pursuant to those instructions. The year-end condensed balance sheet data was derived from audited financial statements but does not include all disclosures required by GAAP. The unaudited condensed consolidated financial statements, in the opinion of management, reflect all adjustments (consisting of normal recurring adjustments) necessary for a fair statement of the results for the interim periods ended  December 31, 2021 and 2020 and the financial position at  December 31, 2021; however, these results are not necessarily indicative of results which  may be expected for the full year. The interim condensed consolidated financial statements, and notes thereto, should be read in conjunction with the audited consolidated financial statements for the year ended  March 31, 2021, and notes thereto, included in the Company’s Annual Report on Form 10-K for the year ended  March 31, 2021 filed with the SEC on  June 2, 2021.
  (was, 2021-11-08, similarity 0.9955):
[0001437749-21-025699:note_history:2]
These unaudited condensed consolidated financial statements of the Company have been prepared on a going concern basis in accordance with United States generally accepted accounting principles (“GAAP”) and the Securities and Exchange Commission’s (“SEC”) instructions to Form 10-Q. The going concern basis of presentation assumes that the Company will continue operations and will be able to realize its assets and discharge its liabilities and commitments in the normal course of business. Certain information and footnote disclosures normally included in the financial statements prepared in accordance with GAAP have been condensed or omitted pursuant to those instructions. The year-end condensed balance sheet data was derived from audited financial statements but does not include all disclosures required by GAAP. The unaudited condensed consolidated financial statements, in the opinion of management, reflect all adjustments (consisting of normal recurring adjustments) necessary for a fair statement of the results for the interim periods ended  September 30, 2021 and 2020 and the financial position at  September 30, 2021; however, these results are not necessarily indicative of results which  may be expected for the full year. The interim condensed consolidated financial statements, and notes thereto, should be read in conjunction with the audited consolidated financial statements for the year ended  March 31, 2021, and notes thereto, included in the Company’s Annual Report on Form 10-K for the year ended  March 31, 2021 filed with the SEC on  June 2, 2021.

- changed (2022-02-02):
[0001437749-22-002208:note_history:3]
The Company has historically experienced recurring operating losses and as of  December 31, 2021, the Company had an accumulated deficit of $1,015 million. In addition, the Company has historically experienced recurring negative operating cash flows.  At  December 31, 2021, the Company had cash and cash equivalents of $43.9 million. Cash used in operations for the nine months ended  December 31, 2021 was $15.9 million.
  (was, 2021-11-08, similarity 0.9286):
[0001437749-21-025699:note_history:3]
The Company has historically experienced recurring operating losses and as of  September 30, 2021, the Company had an accumulated deficit of $1,011.1 million. In addition, the Company has historically experienced recurring negative operating cash flows.  At  September 30, 2021, the Company had cash and cash equivalents of $48.5 million. Cash used in operations for the six months ended  September 30, 2021 was $11.7 million.

- changed (2022-02-02):
[0001437749-22-002208:note_history:4]
While the COVID-19 pandemic continues to rapidly evolve, the Company is experiencing some inflation pressure in its supply chains, some delays in sourcing materials needed for its products, and some production disruption resulting from higher than typical employee absenteeism due to the highly contagious omicron variant. The Company continues to assess the impact of the COVID-19 pandemic to best mitigate risk and continue the operations of the Company’s business. The extent to which the outbreak impacts the Company’s business, liquidity, results of operations and financial condition will depend on future developments, which are highly uncertain and cannot be predicted with confidence, including new information that  may emerge concerning the severity of the COVID-19 pandemic, the spread of new variations of the virus, the actions to contain it or treat its impact and the effectiveness and adoption of vaccines and treatments, among others.  If the Company, its customers or suppliers experience prolonged shutdowns or other business disruptions, including global supply chain disruptions, the Company’s business, liquidity, results of operations and financial condition are likely to be materially adversely affected, and the Company’s ability to access the capital markets  may be limited.
  (was, 2021-11-08, similarity 0.8595):
[0001437749-21-025699:note_history:4]
While the COVID-19 pandemic continues to rapidly evolve, the Company is starting to experience inflation pressure in its supply chains and some delays in sourcing materials needed for its products. The Company continues to assess the impact of the COVID-19 pandemic to best mitigate risk and continue the operations of the Company’s business. The extent to which the outbreak impacts the Company’s business, liquidity, results of operations and financial condition will depend on future developments, which are highly uncertain and cannot be predicted with confidence, including new information that  may emerge concerning the severity of the COVID-19 pandemic, the spread of new variations of the virus, the actions to contain it or treat its impact and the effectiveness and adoption of vaccines and treatments, among others.  If the Company, its customers or suppliers experience prolonged shutdowns or other business disruptions, including global supply chain disruptions, the Company’s business, liquidity, results of operations and financial condition are likely to be materially adversely affected, and the Company’s ability to access the capital markets  may be limited.

- changed (2022-02-02):
[0001437749-22-002208:note_history:5]
The Company believes that based on the information presented above and its quarterly management assessment, it has sufficient liquidity to fund its operations and capital expenditures for the next twelve months following the issuance of the financial statements for the nine months ended  December 31, 2021. The Company’s liquidity is highly dependent on its ability to increase revenues and gross margin, its ability to control its operating costs, and its ability to raise additional capital, if necessary.  The impact of the COVID-19 pandemic on the global financing markets  may reduce the Company's ability to raise additional capital, if necessary, which could negatively impact the Company's liquidity.  There can be no assurance that the Company will be able to continue to raise additional capital, on favorable terms or at all, from other sources or execute on any other means of improving liquidity described above.
  (was, 2021-11-08, similarity 0.9316):
[0001437749-21-025699:note_history:5]
The Company believes that based on the information presented above and its quarterly management assessment, it has sufficient liquidity to fund its operations and capital expenditures for the next twelve months following the issuance of the financial statements for the six months ended  September 30, 2021. The Company’s liquidity is highly dependent on its ability to increase revenues, including its ability to collect revenues under its agreements with Inox, its ability to control its operating costs, and its ability to raise additional capital, if necessary.  The impact of the COVID-19 pandemic on the global financing markets  may reduce the Company's ability to raise additional capital, if necessary, which could negatively impact the Company's liquidity.  There can be no assurance that the Company will be able to continue to raise additional capital, on favorable terms or at all, from other sources or execute on any other means of improving liquidity described above.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2022-02-02):
[0001437749-22-002208:note_history:6]
As part of the Neeltran Acquisition, the Company identified four equipment financing agreements that Neeltran had entered into prior to the acquisition on  May 6, 2021. The Company determined to account for these agreements as a debt transaction and recorded current and long-term debt liabilities of $0.1 million each during the nine months ended  December 31, 2021.
  (was, 2021-11-08, similarity 0.9403):
[0001437749-21-025699:note_history:6]
As part of the Neeltran Acquisition, the Company identified four equipment financing agreements that Neeltran had entered into prior to the acquisition on  May 6, 2021. The Company determined to account for these agreements as a debt transaction and recorded current and long-term debt liabilities of $0.1 million each during the six months ended  September 30, 2021.


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2022-02-02):
[0001437749-22-002208:note_history:7]
|  |  | Three Months Ended December 31, 2021 |  |  | Nine Months Ended December 31, 2021 |  |
| Product Line: |  | Grid |  |  | Wind |  |  | Grid |  |  | Wind |  |
| Equipment and systems |  | $ | 23,416 |  |  | $ | 1,309 |  |  | $ | 67,605 |  |  | $ | 4,168 |  |
| Services and technology development |  |  | 1,634 |  |  |  | 440 |  |  |  | 5,564 |  |  |  | 2,789 |  |
| Total |  | $ | 25,050 |  |  | $ | 1,749 |  |  | $ | 73,169 |  |  | $ | 6,957 |  |
| Region: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas |  | $ | 16,739 |  |  | $ | 56 |  |  | $ | 57,498 |  |  | $ | 134 |  |
| Asia Pacific |  |  | 7,064 |  |  |  | 1,690 |  |  |  | 10,931 |  |  |  | 6,781 |  |
| EMEA |  |  | 1,247 |  |  |  | 3 |  |  |  | 4,740 |  |  |  | 42 |  |
| Total |  | $ | 25,050 |  |  | $ | 1,749 |  |  | $ | 73,169 |  |  | $ | 6,957 |  |
  (was, 2021-11-08, similarity 0.9831):
[0001437749-21-025699:note_history:7]
|  |  | Three Months Ended September 30, 2021 |  |  | Six Months Ended September 30, 2021 |  |
| Product Line: |  | Grid |  |  | Wind |  |  | Grid |  |  | Wind |  |
| Equipment and systems |  | $ | 23,031 |  |  | $ | 1,826 |  |  | $ | 44,189 |  |  | $ | 2,860 |  |
| Services and technology development |  |  | 1,588 |  |  |  | 1,463 |  |  |  | 3,930 |  |  |  | 2,349 |  |
| Total |  | $ | 24,619 |  |  | $ | 3,289 |  |  | $ | 48,119 |  |  | $ | 5,209 |  |
| Region: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas |  | $ | 18,115 |  |  | $ | 59 |  |  | $ | 40,760 |  |  | $ | 78 |  |
| Asia Pacific |  |  | 3,269 |  |  |  | 3,220 |  |  |  | 3,867 |  |  |  | 5,091 |  |
| EMEA |  |  | 3,235 |  |  |  | 10 |  |  |  | 3,492 |  |  |  | 40 |  |
| Total |  | $ | 24,619 |  |  | $ | 3,289 |  |  | $ | 48,119 |  |  | $ | 5,209 |  |

- changed (2022-02-02):
[0001437749-22-002208:note_history:8]
|  |  | Three Months Ended December 31, 2020 |  |  | Nine Months Ended December 31, 2020 |  |
| Product Line: |  | Grid |  |  | Wind |  |  | Grid |  |  | Wind |  |
| Equipment and systems |  | $ | 15,930 |  |  | $ | 6,153 |  |  | $ | 47,729 |  |  | $ | 12,828 |  |
| Services and technology development |  |  | 1,156 |  |  |  | 393 |  |  |  | 3,420 |  |  |  | 1,984 |  |
| Total |  | $ | 17,086 |  |  | $ | 6,546 |  |  | $ | 51,149 |  |  | $ | 14,812 |  |
| Region: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas |  | $ | 13,394 |  |  | $ | 14 |  |  | $ | 39,626 |  |  | $ | 56 |  |
| Asia Pacific |  |  | 351 |  |  |  | 6,461 |  |  |  | 6,736 |  |  |  | 14,463 |  |
| EMEA |  |  | 3,341 |  |  |  | 71 |  |  |  | 4,787 |  |  |  | 293 |  |
| Total |  | $ | 17,086 |  |  | $ | 6,546 |  |  | $ | 51,149 |  |  | $ | 14,812 |  |
  (was, 2021-11-08, similarity 0.9831):
[0001437749-21-025699:note_history:8]
|  |  | Three Months Ended September 30, 2020 |  |  | Six Months Ended September 30, 2020 |  |
| Product Line: |  | Grid |  |  | Wind |  |  | Grid |  |  | Wind |  |
| Equipment and systems |  | $ | 15,261 |  |  | $ | 4,059 |  |  | $ | 31,798 |  |  | $ | 6,676 |  |
| Services and technology development |  |  | 1,086 |  |  |  | 711 |  |  |  | 2,264 |  |  |  | 1,591 |  |
| Total |  | $ | 16,347 |  |  | $ | 4,770 |  |  | $ | 34,062 |  |  | $ | 8,267 |  |
| Region: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas |  | $ | 15,677 |  |  | $ | 30 |  |  | $ | 26,231 |  |  | $ | 42 |  |
| Asia Pacific |  |  | 370 |  |  |  | 4,734 |  |  |  | 6,385 |  |  |  | 8,002 |  |
| EMEA |  |  | 300 |  |  |  | 6 |  |  |  | 1,446 |  |  |  | 223 |  |
| Total |  | $ | 16,347 |  |  | $ | 4,770 |  |  | $ | 34,062 |  |  | $ | 8,267 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2022-02-02):
[0001437749-22-002208:note_history:9]
The Company’s revenues in its Grid business segment are derived primarily through enabling the transmission and distribution of power, providing planning services that allow it to identify power grid needs and risks, and developing ship protection systems for the U.S. Navy. The Company’s revenues in its Wind business segment are derived primarily through supplying advanced power electronics and control systems, licensing its highly engineered wind turbine designs, and providing extensive customer support services to wind turbine manufacturers. The Company records revenue based on a five-step model in accordance with ASC 606. For its customer contracts, the Company identifies the performance obligations, determines the transaction price, allocates the contract transaction price to the performance obligations, and recognizes the revenue when (or as) control of goods or services is transferred to the customer. In the three and nine months ended  December 31, 2021, 79% and 76% of revenue, respectively, was recognized at the point in time when control transferred to the customer, with the remainder being recognized over time. In the three and nine months ended  December 31, 2020, 78% and 79% of revenue, respectively, was recognized at the point in time when control transferred to the customer, with the remainder being recognized over time.
  (was, 2021-11-08, similarity 0.9685):
[0001437749-21-025699:note_history:9]
The Company’s revenues in its Grid business segment are derived primarily through enabling the transmission and distribution of power, providing planning services that allow it to identify power grid needs and risks, and developing ship protection systems for the U.S. Navy. The Company’s revenues in its Wind business segment are derived primarily through supplying advanced power electronics and control systems, licensing its highly engineered wind turbine designs, and providing extensive customer support services to wind turbine manufacturers. The Company records revenue based on a five-step model in accordance with ASC 606. For its customer contracts, the Company identifies the performance obligations, determines the transaction price, allocates the contract transaction price to the performance obligations, and recognizes the revenue when (or as) control of goods or services is transferred to the customer. In the three and six months ended  September 30, 2021, 86% and 82% of revenue, respectively, was recognized at the point in time when control transferred to the customer, with the remainder being recognized over time. In the three and six months ended  September 30, 2020, 78% and 79% of revenue, respectively, was recognized at the point in time when control transferred to the customer, with the remainder being recognized over time.

- changed (2022-02-02):
[0001437749-22-002208:note_history:10]
The Company's equipment and system product line includes certain contracts which do not meet the requirements of an exchange transaction and therefore do not fall within the scope of ASC 606.  As these non-exchange transaction contracts are considered grant revenue and do not fall within any specific accounting literature, the Company follows guidance within ASC 606 by analogy to recognize grant revenue over time.  In the three and nine months ended  December 31, 2021, the Company recorded $0.1 million and $0.9 million in grant revenue, respectively, which is included in the Company’s Grid business segment revenue. In the three and nine months ended  December 31, 2020, the Company recorded $1.1 million and $1.8 million in grant revenue, respectively, which is included in the Company's Grid segment revenue.
  (was, 2021-11-08, similarity 0.9467):
[0001437749-21-025699:note_history:10]
The Company's equipment and system product line includes certain contracts which do not meet the requirements of an exchange transaction and therefore do not fall within the scope of ASC 606.  As these non-exchange transaction contracts are considered grant revenue and do not fall within any specific accounting literature, the Company follows guidance within ASC 606 by analogy to recognize grant revenue over time.  In the three and six months ended  September 30, 2021, the Company recorded $0.3 million and $0.8 million in grant revenue, respectively, which is included in the Company’s Grid business segment revenue. In the three and six months ended  September 30, 2020, the Company recorded $0.4 million and $0.8 million in grant revenue, respectively, which is included in the Company's Grid segment revenue.

- changed (2022-02-02):
[0001437749-22-002208:note_history:11]
|  |  | Three Months Ended December 31, 2021 |  |  | Nine Months Ended December 31, 2021 |  |
| Product Line: |  | Grid |  |  | Wind |  |  | Grid |  |  | Wind |  |
| Equipment and systems |  | $ | 23,416 |  |  | $ | 1,309 |  |  | $ | 67,605 |  |  | $ | 4,168 |  |
| Services and technology development |  |  | 1,634 |  |  |  | 440 |  |  |  | 5,564 |  |  |  | 2,789 |  |
| Total |  | $ | 25,050 |  |  | $ | 1,749 |  |  | $ | 73,169 |  |  | $ | 6,957 |  |
| Region: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas |  | $ | 16,739 |  |  | $ | 56 |  |  | $ | 57,498 |  |  | $ | 134 |  |
| Asia Pacific |  |  | 7,064 |  |  |  | 1,690 |  |  |  | 10,931 |  |  |  | 6,781 |  |
| EMEA |  |  | 1,247 |  |  |  | 3 |  |  |  | 4,740 |  |  |  | 42 |  |
| Total |  | $ | 25,050 |  |  | $ | 1,749 |  |  | $ | 73,169 |  |  | $ | 6,957 |  |
  (was, 2021-11-08, similarity 0.9831):
[0001437749-21-025699:note_history:11]
|  |  | Three Months Ended September 30, 2021 |  |  | Six Months Ended September 30, 2021 |  |
| Product Line: |  | Grid |  |  | Wind |  |  | Grid |  |  | Wind |  |
| Equipment and systems |  | $ | 23,031 |  |  | $ | 1,826 |  |  | $ | 44,189 |  |  | $ | 2,860 |  |
| Services and technology development |  |  | 1,588 |  |  |  | 1,463 |  |  |  | 3,930 |  |  |  | 2,349 |  |
| Total |  | $ | 24,619 |  |  | $ | 3,289 |  |  | $ | 48,119 |  |  | $ | 5,209 |  |
| Region: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas |  | $ | 18,115 |  |  | $ | 59 |  |  | $ | 40,760 |  |  | $ | 78 |  |
| Asia Pacific |  |  | 3,269 |  |  |  | 3,220 |  |  |  | 3,867 |  |  |  | 5,091 |  |
| EMEA |  |  | 3,235 |  |  |  | 10 |  |  |  | 3,492 |  |  |  | 40 |  |
| Total |  | $ | 24,619 |  |  | $ | 3,289 |  |  | $ | 48,119 |  |  | $ | 5,209 |  |

- changed (2022-02-02):
[0001437749-22-002208:note_history:12]
|  |  | Three Months Ended December 31, 2020 |  |  | Nine Months Ended December 31, 2020 |  |
| Product Line: |  | Grid |  |  | Wind |  |  | Grid |  |  | Wind |  |
| Equipment and systems |  | $ | 15,930 |  |  | $ | 6,153 |  |  | $ | 47,729 |  |  | $ | 12,828 |  |
| Services and technology development |  |  | 1,156 |  |  |  | 393 |  |  |  | 3,420 |  |  |  | 1,984 |  |
| Total |  | $ | 17,086 |  |  | $ | 6,546 |  |  | $ | 51,149 |  |  | $ | 14,812 |  |
| Region: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas |  | $ | 13,394 |  |  | $ | 14 |  |  | $ | 39,626 |  |  | $ | 56 |  |
| Asia Pacific |  |  | 351 |  |  |  | 6,461 |  |  |  | 6,736 |  |  |  | 14,463 |  |
| EMEA |  |  | 3,341 |  |  |  | 71 |  |  |  | 4,787 |  |  |  | 293 |  |
| Total |  | $ | 17,086 |  |  | $ | 6,546 |  |  | $ | 51,149 |  |  | $ | 14,812 |  |
  (was, 2021-11-08, similarity 0.9831):
[0001437749-21-025699:note_history:12]
|  |  | Three Months Ended September 30, 2020 |  |  | Six Months Ended September 30, 2020 |  |
| Product Line: |  | Grid |  |  | Wind |  |  | Grid |  |  | Wind |  |
| Equipment and systems |  | $ | 15,261 |  |  | $ | 4,059 |  |  | $ | 31,798 |  |  | $ | 6,676 |  |
| Services and technology development |  |  | 1,086 |  |  |  | 711 |  |  |  | 2,264 |  |  |  | 1,591 |  |
| Total |  | $ | 16,347 |  |  | $ | 4,770 |  |  | $ | 34,062 |  |  | $ | 8,267 |  |
| Region: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas |  | $ | 15,677 |  |  | $ | 30 |  |  | $ | 26,231 |  |  | $ | 42 |  |
| Asia Pacific |  |  | 370 |  |  |  | 4,734 |  |  |  | 6,385 |  |  |  | 8,002 |  |
| EMEA |  |  | 300 |  |  |  | 6 |  |  |  | 1,446 |  |  |  | 223 |  |
| Total |  | $ | 16,347 |  |  | $ | 4,770 |  |  | $ | 34,062 |  |  | $ | 8,267 |  |

- changed (2022-02-02):
[0001437749-22-002208:note_history:13]
As of  December 31, 2021, and 2020, the Company’s contract assets and liabilities primarily relate to the timing differences between cash received from a customer in connection with contractual rights to invoicing and the timing of revenue recognition following completion of performance obligations. The Company's accounts receivable balance is made up entirely of customer contract related balances. Changes in the Company’s contract assets, which are included in “Unbilled accounts receivable” and “Deferred program costs” (see Note 8, “Accounts Receivable” and Note 9, “Inventory” for a reconciliation to the condensed consolidated balance sheets) and "Contract liabilities", which are included in the current portion and long-term portion of "Deferred revenue" in the Company’s condensed consolidated balance sheets, are as follows (in thousands):
  (was, 2021-11-08, similarity 0.9958):
[0001437749-21-025699:note_history:13]
As of  September 30, 2021, and 2020, the Company’s contract assets and liabilities primarily relate to the timing differences between cash received from a customer in connection with contractual rights to invoicing and the timing of revenue recognition following completion of performance obligations. The Company's accounts receivable balance is made up entirely of customer contract related balances. Changes in the Company’s contract assets, which are included in “Unbilled accounts receivable” and “Deferred program costs” (see Note 8, “Accounts Receivable” and Note 9, “Inventory” for a reconciliation to the condensed consolidated balance sheets) and "Contract liabilities", which are included in the current portion and long-term portion of "Deferred revenue" in the Company’s condensed consolidated balance sheets, are as follows (in thousands):

- changed (2022-02-02):
[0001437749-22-002208:note_history:14]
|  |  | Unbilled Accounts Receivable |  |  | Deferred Program Costs |  |  | Contract Liabilities |  |
| Beginning balance as of March 31, 2021 |  | $ | 5,765 |  |  | $ | 977 |  |  | $ | 21,257 |  |
| Increases for costs incurred to fulfill performance obligations |  |  | — |  |  |  | 3,140 |  |  |  | — |  |
| Increase for balances acquired |  |  | — |  |  |  | 634 |  |  |  | 10,048 |  |
| Increase (decrease) due to customer billings |  |  | (11,214 | ) |  |  | — |  |  |  | 55,354 |  |
| Decrease due to cost recognition on completed performance obligations |  |  | — |  |  |  | (4,128 | ) |  |  | — |  |
| Increase (decrease) due to recognition of revenue based on transfer of control of performance obligations |  |  | 12,186 |  |  |  | — |  |  |  | (55,318 | ) |
| Other changes and FX impact |  |  | — |  |  |  | (8 | ) |  |  | 137 |  |
| Ending balance as of December 31, 2021 |  | $ | 6,737 |  |  | $ | 615 |  |  | $ | 31,478 |  |
  (was, 2021-11-08, similarity 0.9956):
[0001437749-21-025699:note_history:14]
|  |  | Unbilled Accounts Receivable |  |  | Deferred Program Costs |  |  | Contract Liabilities |  |
| Beginning balance as of March 31, 2021 |  | $ | 5,765 |  |  | $ | 977 |  |  | $ | 21,257 |  |
| Increases for costs incurred to fulfill performance obligations |  |  | — |  |  |  | 2,277 |  |  |  | — |  |
| Increase for balances acquired |  |  | — |  |  |  | 634 |  |  |  | 10,048 |  |
| Increase (decrease) due to customer billings |  |  | (4,807 | ) |  |  | — |  |  |  | 34,344 |  |
| Decrease due to cost recognition on completed performance obligations |  |  | — |  |  |  | (3,055 | ) |  |  | — |  |
| Increase (decrease) due to recognition of revenue based on transfer of control of performance obligations |  |  | 7,838 |  |  |  | — |  |  |  | (34,169 | ) |
| Other changes and FX impact |  |  | — |  |  |  | (3 | ) |  |  | 38 |  |
| Ending balance as of September 30, 2021 |  | $ | 8,796 |  |  | $ | 830 |  |  | $ | 31,518 |  |

- added (2022-02-02):
[0001437749-22-002208:note_history:15]
|  |  | Unbilled Accounts Receivable |  |  | Deferred Program Costs |  |  | Contract Liabilities |  |
| Beginning balance as of March 31, 2020 |  | $ | 5,711 |  |  | $ | 1,631 |  |  | $ | 26,142 |  |
| Increases for costs incurred to fulfill performance obligations |  |  | — |  |  |  | 6,635 |  |  |  | — |  |
| Increase for balance acquired |  |  | 101 |  |  |  | — |  |  |  | 2,700 |  |
| Increase (decrease) due to customer billings |  |  | (8,255 | ) |  |  | — |  |  |  | 42,785 |  |
| Decrease due to cost recognition on completed performance obligations |  |  | — |  |  |  | (6,969 | ) |  |  | — |  |
| Increase (decrease) due to recognition of revenue based on transfer of control of performance obligations |  |  | 6,644 |  |  |  | — |  |  |  | (48,274 | ) |
| Other changes and FX impact |  |  | — |  |  |  | 33 |  |  |  | 1,025 |  |
| Ending balance as of December 31, 2020 |  | $ | 4,201 |  |  | $ | 1,330 |  |  | $ | 24,378 |  |

- changed (2022-02-02):
[0001437749-22-002208:note_history:16]
The Company’s remaining performance obligations represent the unrecognized revenue value of the Company’s contractual commitments. The Company’s performance obligations  may vary significantly each reporting period based on the timing of major new contractual commitments. As of  December 31, 2021, the Company had outstanding performance obligations on existing contracts under ASC 606 to be recognized in the next twelve months of approximately $80.6 million. There are also approximately $8.0 million of outstanding performance obligations to be recognized over a period of thirteen to sixty months. The remaining performance obligations are subject to customer actions and therefore the timing of revenue recognition cannot be reasonably estimated. The twelve-month performance obligations include anticipated shipments to Inox based on the twelve-month rolling forecast provided by Inox on the multi-year supply contract. The quantities specified in any forecast provided by Inox related to the multi-year supply contract are firm and irrevocable for the first three months of a twelve-month rolling forecast. The timing of the performance obligations beyond the twelve-month forecast provided by Inox are not determinable and therefore are not included in the total remaining performance obligations.
  (was, 2021-11-08, similarity 0.9973):
[0001437749-21-025699:note_history:16]
The Company’s remaining performance obligations represent the unrecognized revenue value of the Company’s contractual commitments. The Company’s performance obligations  may vary significantly each reporting period based on the timing of major new contractual commitments. As of  September 30, 2021, the Company had outstanding performance obligations on existing contracts under ASC 606 to be recognized in the next twelve months of approximately $89.5 million. There are also approximately $10.5 million of outstanding performance obligations to be recognized over a period of thirteen to sixty months. The remaining performance obligations are subject to customer actions and therefore the timing of revenue recognition cannot be reasonably estimated. The twelve-month performance obligations include anticipated shipments to Inox based on the twelve-month rolling forecast provided by Inox on the multi-year supply contract. The quantities specified in any forecast provided by Inox related to the multi-year supply contract are firm and irrevocable for the first three months of a twelve-month rolling forecast. The timing of the performance obligations beyond the twelve-month forecast provided by Inox are not determinable and therefore are not included in the total remaining performance obligations.

- changed (2022-02-02):
[0001437749-22-002208:note_history:17]
The following table sets forth customers who represented 10% or more of the Company’s total revenues for the three and nine months ended  December 31, 2021 and 2020:
  (was, 2021-11-08, similarity 0.9677):
[0001437749-21-025699:note_history:17]
The following table sets forth customers who represented 10% or more of the Company’s total revenues for the three and six months ended  September 30, 2021 and 2020:

- added (2022-02-02):
[0001437749-22-002208:note_history:18]
|  |  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  | Reportable |  | December 31, |  |  | December 31, |  |
|  | Segment |  | 2021 |  |  | 2020 |  |  | 2021 |  |  | 2020 |  |
| Inox Wind Limited | Wind |  | <10% |  |  |  | 24 | % |  |  | <10% |  |  |  | 12 | % |
| Fuji Bridex PTE Ltd | Grid |  | 20 | % |  |  | <10% |  |  |  | 10 | % |  |  | <10% |  |
| EPC Services | Grid |  | <10% |  |  |  | 14 | % |  |  | <10% |  |  |  | 17 | % |

- removed (2022-02-02):
[0001437749-21-025699:note_history:19]
|  |  | Unbilled Accounts Receivable |  |  | Deferred Program Costs |  |  | Contract Liabilities |  |
| Beginning balance as of March 31, 2020 |  | $ | 5,711 |  |  | $ | 1,631 |  |  | $ | 26,142 |  |
| Increases for costs incurred to fulfill performance obligations |  |  | — |  |  |  | 3,279 |  |  |  | — |  |
| Increase (decrease) due to customer billings |  |  | (5,929 | ) |  |  | — |  |  |  | 23,931 |  |
| Decrease due to cost recognition on completed performance obligations |  |  | — |  |  |  | (3,314 | ) |  |  | — |  |
| Increase (decrease) due to recognition of revenue based on transfer of control of performance obligations |  |  | 6,186 |  |  |  | — |  |  |  | (28,678 | ) |
| Other changes and FX impact |  |  | 0 |  |  |  | 18 |  |  |  | 561 |  |
| Ending balance as of September 30, 2020 |  | $ | 5,968 |  |  | $ | 1,614 |  |  | $ | 21,956 |  |

- removed (2022-02-02):
[0001437749-21-025699:note_history:20]
|  |  |  | Three Months Ended |  |  | Six Months Ended |  |
|  | Reportable |  | September 30, |  |  | September 30, |  |
|  | Segment |  | 2021 |  |  | 2020 |  |  | 2021 |  |  | 2020 |  |
| EPC Services | Grid |  | <10% |  |  |  | 12 | % |  |  | <10% |  |  |  | 18 | % |
| Inox Wind Limited | Wind |  | 10 | % |  |  | <10% |  |  |  | <10% |  |  |  | <10% |  |
| Tri-State Generation and Transmission Association, Inc. | Grid |  | 12 | % |  |  | — |  |  |  | <10% |  |  |  | — |  |
| Micron Technology | Grid |  | <10% |  |  |  | <10% |  |  |  | 10 | % |  |  | <10% |  |
| Reed & Reed Inc. | Grid |  |  | <10% |  |  | 25 | % |  |  | <10% |  |  |  | 12 | % |
| Siemens Gamesa Renewable Energy Pty. Ltd. | Grid |  | <10% |  |  |  | <10% |  |  |  | <10% |  |  |  | 13 | % |
