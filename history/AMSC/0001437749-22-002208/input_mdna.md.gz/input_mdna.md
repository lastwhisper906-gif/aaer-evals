# AMSC MD&A — 0001437749-22-002208


## mdna

[0001437749-22-002208:mdna:1]
[same as prior period, unchanged from 0001437749-21-025699:mdna:1]

[0001437749-22-002208:mdna:2]
[same as prior period, unchanged from 0001437749-21-025699:mdna:2]

[0001437749-22-002208:mdna:3]
[same as prior period, unchanged from 0001437749-21-025699:mdna:3]

[0001437749-22-002208:mdna:4]
[same as prior period, unchanged from 0001437749-21-025699:mdna:4]

[0001437749-22-002208:mdna:5]
[same as prior period, unchanged from 0001437749-21-025699:mdna:5]

[0001437749-22-002208:mdna:6]
[same as prior period, unchanged from 0001437749-21-025699:mdna:6]

[0001437749-22-002208:mdna:7]
[same as prior period, unchanged from 0001437749-21-025699:mdna:7]

[0001437749-22-002208:mdna:8]
[same as prior period, unchanged from 0001437749-21-025699:mdna:8]

[0001437749-22-002208:mdna:9]
[same as prior period, unchanged from 0001437749-21-025699:mdna:9]

[0001437749-22-002208:mdna:10]
[same as prior period, unchanged from 0001437749-21-025699:mdna:10]

[0001437749-22-002208:mdna:11]
On October 31, 2018, we entered into a Subcontract Agreement with Commonwealth Edison Company (“ComEd”) (the “Subcontract Agreement”) for the manufacture and installation of the Company’s REG system within ComEd’s electric grid in Chicago, Illinois (the “Project”). As provided in the Subcontract Agreement, the Subcontract Agreement became effective upon the signing of an amendment by us and the U.S. Department of Homeland Security (“DHS”) to the existing contract (the “Prime Contract”) between us and DHS on June 20, 2019. Unless terminated earlier by us, ComEd or DHS according to the terms of the Subcontract Agreement, the term of the Subcontract Agreement will continue until we complete our warranty obligations under the Subcontract Agreement. Under the terms of the Subcontract Agreement, we have agreed, among other things, to provide the REG system and to supervise ComEd’s installation of the REG system in Chicago. As part of our separate cost sharing arrangement with DHS under the Prime Contract, we expect funding provided by DHS in connection with the Subcontract Agreement to be between $9.0 to $11.0 million, which represents the total amount of revenue we are expected to recognize over the term of the Subcontract Agreement and includes up to $1.0 million that we have agreed to reimburse ComEd for costs incurred by ComEd while undertaking its tasks under the Subcontract Agreement (the “Reimbursement Amount”). In addition, we are required to deliver an irrevocable letter of credit in the amount of $5.0 million to secure certain Company obligations under the Subcontract Agreement, which we have done, and deposited $5.0 million in an escrow account as collateral to secure such letter of credit.  ComEd has agreed to provide the site and provide all civil engineering work required to support the installation, operation and integration of the REG system into ComEd’s electric grid. Other than the Reimbursement Amount, ComEd is responsible for its own costs and expenses. DHS’s approval to commence with construction was obtained on June 20, 2019. Substation work on the project began in late 2019 and we successfully integrated the REG system on Com Ed's electric power grid and the REG system became fully operational in August 2021. The REG system was placed into operation during the nine months ended December 31, 2021.

[0001437749-22-002208:mdna:12]
[same as prior period, unchanged from 0001437749-21-025699:mdna:12]

[0001437749-22-002208:mdna:13]
[same as prior period, unchanged from 0001437749-21-025699:mdna:13]

[0001437749-22-002208:mdna:14]
[same as prior period, unchanged from 0001437749-21-025699:mdna:14]

[0001437749-22-002208:mdna:15]
[same as prior period, unchanged from 0001437749-21-025699:mdna:15]

[0001437749-22-002208:mdna:16]
The COVID-19 pandemic continues to rapidly evolve. We are experiencing some inflation pressure in our supply chain, some delays in sourcing materials needed for our products and some production disruption resulting from higher than typical employee absenteeism due to the highly contagious omicron variant which have increased our cost of revenues and decreased gross margin. The extent to which the outbreak impacts our business, liquidity, results of operations and financial condition will depend on future developments, which are highly uncertain and cannot be predicted with confidence, including the continued geographic spread of the disease, the duration of the pandemic, the location, duration and magnitude of future waves of infection, new variants of the virus, availability and adoption of vaccines and treatments, effectiveness of vaccines against the virus and its mutations, travel restrictions and social distancing in the United States, the European Union, India and other countries, the duration and extent of business closures or business disruptions including global supply chain disruptions and the effectiveness of actions taken to contain and treat the disease. Changes in macroeconomic and market conditions arising from the COVID-19 pandemic, including inflation, labor force availability, sourcing, material delays and global supply chain disruptions could have a material adverse effect on our business, financial condition and results of operation.

[0001437749-22-002208:mdna:17]
[same as prior period, unchanged from 0001437749-21-025699:mdna:17]

[0001437749-22-002208:mdna:18]
[same as prior period, unchanged from 0001437749-21-025699:mdna:18]

[0001437749-22-002208:mdna:19]
[same as prior period, unchanged from 0001437749-21-025699:mdna:19]

[0001437749-22-002208:mdna:20]
Three and nine months ended December 31, 2021, compared to the three and nine months ended December 31, 2020

[0001437749-22-002208:mdna:21]
[same as prior period, unchanged from 0001437749-21-025699:mdna:21]

[0001437749-22-002208:mdna:22]
Total revenues increased 13% and21% to $26.8 million and $80.1 million for the three and nine months ended December 31, 2021, respectively, compared to $23.6 million and $66.0 million for the three and nine months ended December 31, 2020, respectively.  Our revenues are summarized as follows (in thousands):

[0001437749-22-002208:mdna:23]
|  |  | Three Months Ended December 31, |  |  | Nine Months Ended December 31, |  |
|  |  | 2021 |  |  | 2020 |  |  | 2021 |  |  | 2020 |  |
| Revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Grid |  | $ | 25,050 |  |  | $ | 17,086 |  |  | $ | 73,169 |  |  | $ | 51,149 |  |
| Wind |  |  | 1,749 |  |  |  | 6,546 |  |  |  | 6,957 |  |  |  | 14,812 |  |
| Total |  | $ | 26,799 |  |  | $ | 23,632 |  |  | $ | 80,126 |  |  | $ | 65,961 |  |

[0001437749-22-002208:mdna:24]
Our Grid business unit accounted for 93% and 91% of total revenues for the three and nine months ended December 31, 2021, respectively, compared to 72% and 78% for the three and nine months ended December 31, 2020, respectively. Our Grid business unit revenues increased 47% and43% to $25.0 million and $73.2 million in the three and nine months ended December 31, 2021, respectively, from $17.1 million and $51.1 million in the three and nine months ended December 31, 2020, respectively. The increase in the Grid business unit revenue in the three months ended December 31, 2021, was primarily driven by the contribution from the Neeltran Acquisition. The increase in the Grid business unit revenue in the nine months ended December 31, 2021, was primarily driven by the contributions from the acquisitions of NEPSI and Neeltran.

[0001437749-22-002208:mdna:25]
Our Wind business unit accounted for 7% and 9% of total revenues for the three and nine months ended December 31, 2021, respectively, compared to 28% and 22% for the three and nine months ended December 31, 2020, respectively.  Revenues in the Wind business unit decreased 73% and 53% to $1.7 million and $7.0 million in the three and nine months ended December 31, 2021, from $6.5 million and $14.8 million in the three and nine months ended December 31, 2020. The decrease in the three and nine months ended December 31, 2021, was driven by shipments of electrical control systems ("ECS") to Doosan in the three and nine months ended December 31, 2020 with no similar shipments in the current year period. Inox, historically one of the largest customers of our Wind business unit has had and may in the future have its ability to perform under our ECS supply contract hampered by the prolonged impacts of the COVID-19 pandemic. Inox has been active in the new central and state government auction regime in India and has a cumulative order book of over 1.4 GW. We are parties to a technology transfer & license agreement dated as of April 17, 2009, as amended (the “2009 TTLA”) with Inox for a 2 MW class wind turbine, the manufacture of which requires our ECS.  On November 9, 2021, we sent written notice to Inox notifying Inox of its default under the 2009 TTLA due to Inox’s failure to pay royalties for commissioned 2 MW wind turbines in the amount of €0.1 million that Inox is obligated to pay under the terms of the 2009 TTLA.  Inox subsequently paid the royalties during the cure period. On December 1, 2021, we sent written notice to Inox notifying Inox of its default under our supply contract for 2 MW ECS due to Inox's failure to post letters of credit in the amount of €0.9 million for payment of ECS that Inox is obligated to purchase under the terms of the supply contract. If Inox fails to post letters of credit in the amount of €0.9 million in accordance with the terms of the supply contract within the ninety-day cure period after receipt of the default notice, then we may terminate the supply contract by providing written notice of such termination to Inox. We cannot predict if and when Inox will pay royalties due and payable under the 2009 TTLA or if or when Inox will resume posting letters of credit for payment of contracted shipments of ECS in the future. In the event we were to terminate the 2009 TTLA in connection with Inox's failure to pay royalties under such agreement, Inox would no longer be able to manufacture 2 MW wind turbines, likely resulting in a decrease in Inox’s demand for our ECS and our revenues and liquidity could be impacted. In the event we were to terminate the 2 MW ECS supply contract, our revenues and liquidity could also be negatively impacted. We cannot predict if and how successful Inox will be in executing on these orders or in obtaining new orders under the new central and state auction regime. Any failure by Inox to succeed under this regime, or any delay in Inox’s ability to deliver its wind turbines, could result in fewer ECS shipments to Inox.

[0001437749-22-002208:mdna:26]
[same as prior period, unchanged from 0001437749-21-025699:mdna:26]

[0001437749-22-002208:mdna:27]
Cost of revenues increased by 18% and 36% to $23.2 million and $69.9 million for the three and nine months ended December 31, 2021, compared to $19.7 million and $51.4 million for the three and nine months ended December 31, 2020. Gross margin was 13% for both the three and nine months ended December 31, 2021, compared to 17% and 22% for the three and nine months ended December 31, 2020.  The decrease in gross margin in the three and nine months ended December 31, 2021, was due to an unfavorable product mix, inflation pressure in our supply chain and some delays in sourcing materials due to the COVID-19 pandemic and additional costs related to purchase accounting adjustments associated with the Neeltran Acquisition. Cost of revenues includes total amortization expense of $0.1 million in both of the three and nine months ended December 31, 2021 as a result of each of the NEPSI and Neeltran acquired backlog intangible assets. In addition, a fair value purchase adjustment of approximately $0.1 million and $0.6 million for the step-up basis assigned to acquired inventory, to properly reflect the fair value in purchase accounting, was charged to cost of revenues in the three and nine months ended December 31, 2021, respectively.

[0001437749-22-002208:mdna:28]
[same as prior period, unchanged from 0001437749-21-025699:mdna:28]

[0001437749-22-002208:mdna:29]
[same as prior period, unchanged from 0001437749-21-025699:mdna:29]

[0001437749-22-002208:mdna:30]
Research and development ("R&D") expense decreased 12% in the three months ended December 31, 2021 to $2.7 million from $3.0 million in the three months ended December 31, 2020. The decrease in R&D expense was due to lower overall compensation expense. R&D expenses increased 1% in the nine months ended December 31, 2021 to $8.4 million from $8.2 million in the nine  months ended December 31, 2020. The increase in R&D expense in the nine month period was due to higher travel and stock compensation expense.

[0001437749-22-002208:mdna:31]
[same as prior period, unchanged from 0001437749-21-025699:mdna:31]

[0001437749-22-002208:mdna:32]
Selling, general and administrative ("SG&A") expenses decreased 4% in the three months ended December 31, 2021, to $6.8 million from $7.1 million in the three months ended December 31, 2020. The decrease in SG&A expense in the three months ended December 31, 2021 was due to lower overall compensation expense than in the prior year period. SG&A expenses increased 11% to $20.6 million in the nine months ended December 31, 2021 compared to $18.6 million in the nine months ended December 31, 2020. The increase in SG&A expense in the nine months ended December 31, 2021 was due to the addition of NEPSI and Neeltran in the current year period.

[0001437749-22-002208:mdna:33]
[same as prior period, unchanged from 0001437749-21-025699:mdna:33]

[0001437749-22-002208:mdna:34]
We recorded amortization expense related to our core technology and know-how, customer relationships, and other intangible assets of $0.6 million and $1.8 million in the three and nine months ended December 31, 2021, respectively, and $0.4 million and $0.6 million in the three and nine months ended December 31, 2020, respectively.  The increase in amortization expense is a result of the acquisitions of NEPSI and Neeltran.

[0001437749-22-002208:mdna:35]
[same as prior period, unchanged from 0001437749-21-025699:mdna:35]

[0001437749-22-002208:mdna:36]
The change in fair value of our contingent consideration for the earnout payment on the NEPSI Acquisition resulted in a gain of $2.1 million and $4.4 million in the three and nine months ended December 31, 2021, respectively, compared to a loss of $2.7 million in both the three and nine months ended December 31, 2020. The change in the fair value was primarily driven by a decreased likelihood of achieving certain revenue targets and a decline in the Company's stock price.

[0001437749-22-002208:mdna:37]
[same as prior period, unchanged from 0001437749-21-025699:mdna:37]

[0001437749-22-002208:mdna:38]
[same as prior period, unchanged from 0001437749-21-025699:mdna:38]

[0001437749-22-002208:mdna:39]
|  |  | Three Months Ended December 31, |  |  | Nine Months Ended December 31, |  |
|  |  | 2021 |  |  | 2020 |  |  | 2021 |  |  | 2020 |  |
| Operating Income (loss): |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Grid |  | $ | (3,691 | ) |  | $ | (5,826 | ) |  | $ | (14,873 | ) |  | $ | (8,388 | ) |
| Wind |  |  | (1,678 | ) |  |  | 147 |  |  |  | (2,236 | ) |  |  | (1,956 | ) |
| Unallocated corporate expenses |  |  | 989 |  |  |  | (3,579 | ) |  |  | 927 |  |  |  | (5,337 | ) |
| Total |  | $ | (4,380 | ) |  | $ | (9,258 | ) |  | $ | (16,182 | ) |  | $ | (15,681 | ) |

[0001437749-22-002208:mdna:40]
Our Grid business segment generated operating losses of $3.7 million and $14.9 million in the three and nine months ended December 31, 2021, compared to $5.8 million and $8.4 million in the three and nine months ended December 31, 2020. The decrease in the Grid business unit operating loss in the three months ended December 31, 2021 against the prior year period was due to increased revenues, in part related to the acquisition of Neeltran, and improved gross margins. The increase in the Grid business unit operating loss in the nine months ended December 31, 2021, was due to a less favorable product mix and the impact of the purchase accounting adjustments recorded as part of the Neeltran Acquisition, including the inventory step up charge noted above and an adjustment to recognize the fair value adjustment related to the acquired customer deposits, in order to properly reflect pre-acquisition activities, which reduced revenue by $0.6 million less than the contract value.

[0001437749-22-002208:mdna:41]
Our Wind business segment generated operating losses of $1.7 million and $2.2 million in the three and nine months ended December 31, 2021, compared to an operating profit of $0.1 million and an operating loss of $2.0 million in the three and nine months ended December 31, 2020. The increase in the Wind business unit operating loss in the three and nine month periods was due to lower revenues and gross margins driven by fewer shipments of ECS than in the year ago periods.

[0001437749-22-002208:mdna:42]
Unallocated corporate expenses consisted of a gain on contingent consideration of $2.1 million and $4.4 million in the three and nine months ended December 31, 2021, respectively. Unallocated corporate expenses consisted of a loss on contingent consideration of $2.7 million in both the three and nine months ended December 31, 2020. Additionally, unallocated corporate expenses consisted of stock-based compensation expense of $1.1 million and $0.8 million in the three months ended December 31, 2021 and 2020, respectively, and $3.5 million and $2.6 million in the nine months ended December 31, 2021 and 2020, respectively.

[0001437749-22-002208:mdna:43]
[same as prior period, unchanged from 0001437749-21-025699:mdna:43]

[0001437749-22-002208:mdna:44]
Interest income, net, was less than $0.1 million and $0.1 million in the three and nine months ended December 31, 2021, compared to $0.1 million and $0.4 million in the three and nine months ended December 31, 2020. The decrease in interest income in the three and nine months ended December 31, 2021 was related to a lower cash balance earning lower interest rates than in the prior periods.

[0001437749-22-002208:mdna:45]
[same as prior period, unchanged from 0001437749-21-025699:mdna:45]

[0001437749-22-002208:mdna:46]
Other income, net, was less than $0.1 million in both the three and nine months ended December 31, 2021, compared to other expense, net, of $0.3 million and $0.9 million in the three and nine months ended December 31, 2020. The decrease in other expense during both periods was driven by the impacts of favorable fluctuations in foreign currencies during the respective period.

[0001437749-22-002208:mdna:47]
[same as prior period, unchanged from 0001437749-21-025699:mdna:47]

[0001437749-22-002208:mdna:48]
Income tax expense was less than $0.1 million in the three months ended December 31, 2021 and income tax benefit was $1.9 million in the nine months ended December 31, 2021. Income tax benefit was $1.5 million and $1.2 million in the three and nine months ended December 31, 2020.  The income tax benefit in the nine months ended December 31, 2021 and the three and nine months ended December 31, 2020 is a result of releasing valuation allowances to offset the recording of deferred tax liabilities from the Neeltran Acquisition in the nine month period ended December 31, 2021 and the NEPSI Acquisition in the three and nine months ended December 31, 2020. The increase in income tax benefit in the nine month period ended December 31, 2021 is due primarily to higher foreign taxes in the prior year offsetting the tax benefit from the NEPSI Acquisition.

[0001437749-22-002208:mdna:49]
[same as prior period, unchanged from 0001437749-21-025699:mdna:49]

[0001437749-22-002208:mdna:50]
Net loss was $4.3 million and $14.2 million in the three and nine months ended December 31, 2021, compared to $7.9 million and $15.1 million in the three and nine months ended December 31, 2020.  The decrease in net loss was driven primarily by the change in fair value of the contingent consideration for the earnout payment on the NEPSI Acquisition.

[0001437749-22-002208:mdna:51]
[same as prior period, unchanged from 0001437749-21-025699:mdna:51]

[0001437749-22-002208:mdna:52]
[same as prior period, unchanged from 0001437749-21-025699:mdna:52]

[0001437749-22-002208:mdna:53]
We define non-GAAP net loss as net loss before stock-based compensation, amortization of acquisition-related intangibles, acquisition costs, change in fair value of contingent consideration, and other non-cash or unusual charges.  We believe non-GAAP net loss assists management and investors in comparing our performance across reporting periods on a consistent basis by excluding these non-cash charges and other items that we do not believe are indicative of our core operating performance. In addition, we use non-GAAP net loss as a factor to evaluate the effectiveness of our business strategies. A reconciliation of GAAP to non-GAAP net loss is set forth in the table below (in thousands, except per share data):

[0001437749-22-002208:mdna:54]
|  |  | Three Months Ended December 31, |  |  | Nine Months Ended December 31, |  |
|  |  | 2021 |  |  | 2020 |  |  | 2021 |  |  | 2020 |  |
| Net loss |  | $ | (4,324 | ) |  | $ | (7,933 | ) |  | $ | (14,161 | ) |  | $ | (15,062 | ) |
| Stock-based compensation |  |  | 1,120 |  |  |  | 839 |  |  |  | 3,513 |  |  |  | 2,597 |  |
| Amortization of acquisition-related intangibles |  |  | 690 |  |  |  | 645 |  |  |  | 1,979 |  |  |  | 886 |  |
| Acquisition costs |  |  | — |  |  |  | 313 |  |  |  | 681 |  |  |  | 313 |  |
| Change in fair value of contingent consideration |  |  | (2,110 | ) |  |  | 2,740 |  |  |  | (4,440 | ) |  |  | 2,740 |  |
| Non-GAAP net loss |  | $ | (4,624 | ) |  | $ | (3,396 | ) |  | $ | (12,428 | ) |  | $ | (8,526 | ) |
| Non-GAAP net loss per share - basic |  | $ | (0.17 | ) |  | $ | (0.13 | ) |  | $ | (0.46 | ) |  | $ | (0.37 | ) |
| Weighted average shares outstanding - basic |  |  | 27,352 |  |  |  | 25,470 |  |  |  | 27,145 |  |  |  | 23,011 |  |

[0001437749-22-002208:mdna:55]
We incurred non-GAAP net losses of $4.6 million and $12.4 million or $0.17 and $0.46 per share, for the three and nine months ended December 31, 2021, compared to $3.4 million and $8.5 million, or $0.13 and $0.37 per share, for the three and nine months ended December 31, 2020. The increase in the non-GAAP net loss for the three and nine months ended December 31, 2021 was due to a higher operating loss driven by lower gross margin and higher operating expenses.

[0001437749-22-002208:mdna:56]
[same as prior period, unchanged from 0001437749-21-025699:mdna:56]

[0001437749-22-002208:mdna:57]
We have experienced recurring operating losses, and as of December 31, 2021, had an accumulated deficit of $1,015 million.

[0001437749-22-002208:mdna:58]
[same as prior period, unchanged from 0001437749-21-025699:mdna:58]

[0001437749-22-002208:mdna:59]
[same as prior period, unchanged from 0001437749-21-025699:mdna:59]

[0001437749-22-002208:mdna:60]
[same as prior period, unchanged from 0001437749-21-025699:mdna:60]

[0001437749-22-002208:mdna:61]
[same as prior period, unchanged from 0001437749-21-025699:mdna:61]

[0001437749-22-002208:mdna:62]
As of December 31, 2021, we had cash, cash equivalents, marketable securities and restricted cash of $52.6 million, compared to $80.7 million as of March 31, 2021, a decrease of $28.1 million. As of December 31, 2021, we had approximately $1.3 million of cash, cash equivalents, and restricted cash in foreign bank accounts. Our cash, cash equivalents, marketable securities and restricted cash are summarized as follows (in thousands):

[0001437749-22-002208:mdna:63]
|  |  | December 31, 2021 |  |  | March 31, 2021 |  |
| Cash and cash equivalents |  | $ | 43,887 |  |  | $ | 67,814 |  |
| Marketable securities |  |  | - |  |  |  | 5,140 |  |
| Restricted cash |  |  | 8,669 |  |  |  | 7,725 |  |
| Total cash, cash equivalents, marketable securities and restricted cash |  | $ | 52,556 |  |  | $ | 80,679 |  |

[0001437749-22-002208:mdna:64]
For the nine months ended December 31, 2021, net cash used in operating activities was $15.9 million, compared to $4.9 million for the nine months ended December 31, 2020.  The increase in net cash used in operations was due primarily to an increase in inventory purchases and accounts receivable activity in the nine months ended December 31, 2021 as compared to December 31, 2020.

[0001437749-22-002208:mdna:65]
For the nine months ended December 31, 2021, net cash used in investing activities was $7.1 million, compared to $2.6 million for the nine months ended December 31, 2020. The increase in net cash used in investing activities was primarily due to the cash that was used to pay for the Neeltran Acquisition.

[0001437749-22-002208:mdna:66]
For the nine months ended December 31, 2021, net cash provided by financing activities was less than $0.1 million compared to $50.6 million in the nine months ended December 31, 2020.  The decrease in net cash provided by financing activities was due to the prior year period including $51.5 million in proceeds from our October 2020 offering of common stock. There was no such transaction in the nine months ended December 31, 2021.

[0001437749-22-002208:mdna:67]
As of December 31, 2021, we had $6.0 million of restricted cash included in long-term assets and $2.7 million of restricted cash included in current assets.  These amounts of restricted cash primarily represent deposits to secure letters of credit for various supply contracts and long-term projects, including the irrevocable letter of credit in the amount of $5.0 million to secure certain of our obligations under the Subcontract Agreement with ComEd. These deposits are held in interest bearing accounts.

[0001437749-22-002208:mdna:68]
We believe we have sufficient available liquidity to fund our operations and capital expenditures for the next twelve months. In addition, we may seek to raise additional capital, which could be in the form of loans, convertible debt or equity, to fund our operating requirements and capital expenditures. Our liquidity is highly dependent on our ability to increase revenues, improve upon gross margins, control our operating costs, and raise additional capital, if necessary. There can be no assurance that we will be able to raise additional capital on favorable terms or at all, or execute on any other means of improving our liquidity as described above.  Additionally, the impact of the COVID-19 pandemic on the global financial markets may reduce our ability to raise additional capital, if necessary, which could negatively impact our liquidity.

[0001437749-22-002208:mdna:69]
Legal Proceedings

[0001437749-22-002208:mdna:70]
We are involved in legal and administrative proceedings and claims of various types. See Part II, Item 1, “Legal Proceedings,” for additional information. We record a liability in our consolidated financial statements for these matters when a loss is known or considered probable and the amount can be reasonably estimated. We review these estimates each accounting period as additional information is known and adjust the loss provision when appropriate. If a matter is both probable to result in liability and the amounts of loss can be reasonably estimated, we estimate and disclose the possible loss or range of loss to the extent necessary to make the consolidated financial statements not misleading. If the loss is not probable or cannot be reasonably estimated, a liability is not recorded in our consolidated financial statements.

[0001437749-22-002208:mdna:71]
[same as prior period, unchanged from 0001437749-21-025699:mdna:71]

[0001437749-22-002208:mdna:72]
[same as prior period, unchanged from 0001437749-21-025699:mdna:72]

[0001437749-22-002208:mdna:73]
[same as prior period, unchanged from 0001437749-21-025699:mdna:73]

[0001437749-22-002208:mdna:74]
[same as prior period, unchanged from 0001437749-21-025699:mdna:74]

[0001437749-22-002208:mdna:75]
[same as prior period, unchanged from 0001437749-21-025699:mdna:75]

[0001437749-22-002208:mdna:76]
In June 2016, the FASB issued ASU 2016-13, Financial Instruments-Credit Losses (Topic 326): Measurement of Credit Losses on Financial Instruments. The amendments in ASU 2016-13 provide more decision-useful information about the expected credit losses on financial instruments and other commitments to extend credit held by a reporting entity at each reporting date. Following the release of ASU 2019-10 in November 2019, the new effective date, as long as we remain a smaller reporting company, would be annual reporting periods beginning after December 15, 2022.   We are currently evaluating the impact, if any, that the adoption of ASU 2016-13 may have on our consolidated financial statements.

[0001437749-22-002208:mdna:77]
In December 2019, the FASB issued ASU 2019-12, Income Taxes (Topic 740): Simplifying the Accounting for Income Taxes. The amendments in ASU 2019-12 provide for simplified accounting to several income tax situations and removal of certain accounting exceptions.  As of April 1, 2021, we have adopted ASU 2019-12 and noted no material impact on our consolidated financial statements.

[0001437749-22-002208:mdna:78]
In October 2021, the FASB issued ASU 2021-08, Business Combinations (Topic 805): Accounting for Contract Assets and Contract Liabilities from Contracts with Customers. The amendments in ASU 2021-08 will improve the accounting for acquired revenue contracts with customers in a business combination. Following the release of ASU 2021-08 in October 2021, the new effective date will be annual reporting periods beginning after December 15, 2022. We are currently evaluating the impact, if any, that the adoption of ASU 2021-08 may have on our consolidated financial statements.

[0001437749-22-002208:mdna:79]
In November 2021, the FASB issued ASU 2021-10, Government Assistance (Topic 832): Disclosures by Business Entities about Government Assistance. The amendments in ASU 2021-10 will improve financial reporting by requiring disclosures that increase the transparency of transactions with government accounted for by applying a grant or contribution accounting model by analogy. Following the release of ASU 2021-10 in November 2021, the new effective date will be annual reporting periods beginning after December 15, 2021. We are currently evaluating the impact, if any, that the adoption of ASU 2021-10 may have on our consolidated financial statements.

[0001437749-22-002208:mdna:80]
We do not believe that, outside of those disclosed here, there are any other recently issued accounting pronouncements that will have a material impact on our consolidated financial statements.
