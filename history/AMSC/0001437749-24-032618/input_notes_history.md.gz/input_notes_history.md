# AMSC note change history — 0001437749-24-024886 → 0001437749-24-032618


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2024-10-30):
[0001437749-24-032618:note_history:1]
As of  September 30, 2024, the Company had $1.5 million of restricted cash included in long-term assets and $1.2 million of restricted cash included in current assets. As of  March 31, 2024, the Company had $1.3 million of restricted cash included in long term assets and $0.5 million of restricted cash included in current assets. These amounts included in restricted cash primarily represent deposits to secure letters of credit for various supply contracts and long-term projects or collateral deposits. These deposits are held in interest bearing accounts.
  (was, 2024-08-06, similarity 0.9879):
[0001437749-24-024886:note_history:1]
As of  June 30, 2024, the Company had $1.6 million of restricted cash included in long-term assets and $0.5 million of restricted cash included in current assets. As of  March 31, 2024, the Company had $1.3 million of restricted cash included in long term assets and $0.5 million of restricted cash included in current assets. These amounts included in restricted cash primarily represent deposits to secure letters of credit for various supply contracts and long-term projects or collateral deposits. These deposits are held in interest bearing accounts.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2024-10-30):
[0001437749-24-032618:note_history:2]
These unaudited condensed consolidated financial statements of the Company have been prepared on a going concern basis in accordance with United States generally accepted accounting principles (“GAAP”) and the Securities and Exchange Commission’s (“SEC”) instructions to Form 10-Q. Certain prior period amounts were reclassified to conform to the presentation in the current period. The going concern basis of presentation assumes that the Company will continue operations and will be able to realize its assets and discharge its liabilities and commitments in the normal course of business. Certain information and footnote disclosures normally included in the condensed consolidated financial statements prepared in accordance with GAAP have been or omitted pursuant to those instructions. The year-end balance sheet data was derived from audited financial statements but does not include all disclosures required by GAAP. The unaudited condensed consolidated financial statements, in the opinion of management, reflect all adjustments (consisting of normal recurring adjustments) necessary for a fair statement of the results for the interim periods ended  September 30, 2024 and 2023 and the financial position at  September 30, 2024; however, these results are not necessarily indicative of results which  may be expected for the full year. The interim condensed consolidated financial statements, and notes thereto, should be read in conjunction with the audited condensed consolidated financial statements for the year ended  March 31, 2024, and notes thereto, included in the Company’s Annual Report on Form 10-K for the year ended  March 31, 2024 filed with the SEC on  May 29, 2024.
  (was, 2024-08-06, similarity 0.9921):
[0001437749-24-024886:note_history:2]
These unaudited condensed consolidated financial statements of the Company have been prepared on a going concern basis in accordance with United States generally accepted accounting principles (“GAAP”) and the Securities and Exchange Commission’s (“SEC”) instructions to Form 10-Q. Certain prior period amounts were reclassified to conform to the presentation in the current period. The going concern basis of presentation assumes that the Company will continue operations and will be able to realize its assets and discharge its liabilities and commitments in the normal course of business. Certain information and footnote disclosures normally included in the condensed consolidated financial statements prepared in accordance with GAAP have been or omitted pursuant to those instructions. The year-end balance sheet data was derived from audited financial statements but does not include all disclosures required by GAAP. The unaudited condensed consolidated financial statements, in the opinion of management, reflect all adjustments (consisting of normal recurring adjustments) necessary for a fair statement of the results for the interim periods ended  June 30, 2024 and 2023 and the financial position at  June 30, 2024; however, these results are not necessarily indicative of results which  may be expected for the full year. The interim condensed consolidated financial statements, and notes thereto, should be read in conjunction with the audited condensed consolidated financial statements for the year ended  March 31, 2024, and notes thereto, included in the Company’s Annual Report on Form 10-K for the year ended  March 31, 2024 filed with the SEC on  May 29, 2024.

- added (2024-10-30):
[0001437749-24-032618:note_history:3]
The Company has historically experienced recurring operating losses and as of  September 30, 2024, the Company had an accumulated deficit of $1,064.3 million. In addition, the Company has historically experienced recurring negative operating cash flows. At  September 30, 2024, the Company had cash and cash equivalents of $72.1 million. Cash provided by operations for the six months ended  September 30, 2024 was $16.1 million.

- changed (2024-10-30):
[0001437749-24-032618:note_history:4]
In  January 2024, the Company filed a shelf registration statement on Form S-3 that will expire three years from the date on which it was declared effective,  March 15, 2027 (the “First Form S-3”). The First Form S-3 allows the Company to offer and sell from time-to-time up to $250 million of common stock, debt securities, warrants or units comprised of any combination of these securities, with $250 million available for future offerings as of  September 30, 2024. The First Form S-3 is intended to provide the Company flexibility to conduct registered sales of its securities, subject to market conditions, in order to fund its future capital needs. The terms of any future offering under the First Form S-3 will be established at the time of such offering and will be described in a prospectus supplement filed with the SEC prior to the completion of any such offering.
  (was, 2024-08-06, similarity 0.9375):
[0001437749-24-024886:note_history:4]
In  January 2024, the Company filed a shelf registration statement on Form S-3 that will expire three years from the date on which it was declared effective,  March 15, 2027 (the “Form S-3”). The Form S-3 allows the Company to offer and sell from time-to-time up to $250 million of common stock, debt securities, warrants or units comprised of any combination of these securities. The Form S-3 is intended to provide the Company flexibility to conduct registered sales of its securities, subject to market conditions, in order to fund its future capital needs. The terms of any future offering under the Form S-3 will be established at the time of such offering and will be described in a prospectus supplement filed with the SEC prior to the completion of any such offering.

- changed (2024-10-30):
[0001437749-24-032618:note_history:5]
On  August 1, 2024 (the "Acquisition Date"), the Company entered into a Stock Purchase Agreement (the “Stock Purchase Agreement”) with the selling stockholders named therein. Pursuant to the terms of the Stock Purchase Agreement and concurrently with entering into such agreement, the Company acquired all of the issued and outstanding shares of Megatran Industries, Inc. ("Megatran") (the "Acquisition"), for aggregate consideration in an amount equal to $61.4 million (the “Purchase Price”), which consideration amount was subject to various adjustments set forth in the Stock Purchase Agreement (including those described below) and consisted of: (a) (i) $25.0 million, minus (ii) the Indebtedness (as defined in the Stock Purchase Agreement) outstanding as of immediately prior to the closing, minus (iii) Company Expenses (as defined in the Stock Purchase Agreement) (collectively, the “Cash Purchase Price”); (b) a number of restricted shares (rounded up or down to the nearest whole share, as applicable) (the “Company Shares”) of the Company’s common stock, $.01 par value per share (“Common Stock”) equal to the quotient obtained by dividing (x) $31.4 million (the “Share Purchase Price”) by (y) the closing price per share of Common Stock on the Nasdaq Global Select Market on the last trading day immediately preceding the Closing Date; and (c) an additional cash payment equal to $5.0 million, as adjusted pursuant to Sections 5.6(c), (d), and (f) of the Stock Purchase Agreement (the “Additional Cash Purchase Price”). Megatran is now a wholly-owned subsidiary of the Company and, together with its wholly-owned subsidiaries and affiliates, is operated and reported as a component of its Grid business unit. On  September 23, 2024, the Company paid $3.3 million to the selling stockholders, which was calculated based on the agreed upon formula set forth in the Stock Purchase Agreement. This amount is reflected as the change in fair value of this contingent consideration in the three and six months ended  September 30, 2024. As of  September 30, 2024, there are no remaining obligations to the selling stockholders of Megatran.
  (was, 2024-08-06, similarity 0.6251):
[0001437749-24-024886:note_history:5]
On  August 1, 2024, the Company entered into a Stock Purchase Agreement (the “Stock Purchase Agreement”) with the selling stockholders named therein.  Pursuant to the terms of the Stock Purchase Agreement and concurrently with entering into such agreement, the Company acquired all of the issued and outstanding shares of Megatran ("the "Acquisition"), for aggregate consideration in an amount equal to $61,350,000 (the “Purchase Price”), which consideration amount shall be subject to various adjustments set forth in the Stock Purchase Agreement (including those described below) and consists of: (a) (i) $25,000,000, minus (ii) the Indebtedness (as defined in the Stock Purchase Agreement) outstanding as of immediately prior to the closing, minus (iii) Company Expenses (as defined in the Stock Purchase Agreement) (collectively, the “Cash Purchase Price”); (b) a number of restricted shares (rounded up or down to the nearest whole share, as applicable) (the “Company Shares”) of the Company’s common stock, $.01 par value per share (“Common Stock”) equal to the quotient obtained by dividing (x) $31,350,000 (the “Share Purchase Price”) by (y) the closing price per share of Common Stock on the Nasdaq Global Select Market on the last trading day immediately preceding the Closing Date; and (c) an additional cash payment equal to $5,000,000, as adjusted pursuant to Sections 5.6(c), (d), and (f) of the Stock Purchase Agreement (the “Additional Cash Purchase Price”). Megatran is now a wholly-owned subsidiary of the Company and is operated and reported as a component of its Grid business unit.

- added (2024-10-30):
[0001437749-24-032618:note_history:6]
In  August 2024, the Company filed an automatically-effective shelf registration statement on Form S-3 that will expire no later than  August 12, 2027 (the “Second Form S-3”). The Second Form S-3 allows the Company to offer and sell from time-to-time unspecified amounts of common stock, debt securities, warrants or units comprised of any combination of these securities and allows certain selling stockholders to offer and sell from time-to-time common stock. The Second Form S-3 is intended to assist the selling stockholders in the resale of their common stock and to provide the Company flexibility to conduct registered sales of its securities, subject to market conditions, in order to fund its future capital needs. The terms of any future offering under the Second Form S-3 will be established at the time of such offering and will be described in a prospectus supplement filed with the SEC prior to the completion of any such offering.

- changed (2024-10-30):
[0001437749-24-032618:note_history:7]
In recent periods, the Company has experienced inflationary pressure in its supply chain and some delays in sourcing materials needed for its products resulting in some production disruption, both of which have increased the Company’s cost of revenues and decreased gross margin. While the impact of inflation has been challenging, the Company has taken actions to limit this pressure, including adjusting the pricing of its products and services. Changes in macroeconomic conditions arising from various reasons, such as the ongoing wars between Russia and Ukraine and Israel and Hamas, inflation, rising interest rates, labor force availability, sourcing, material delays and global supply chain disruptions could have a material adverse effect on the Company’s business, financial condition and results of operations.
  (was, 2024-08-06, similarity 0.9994):
[0001437749-24-024886:note_history:7]
In recent periods, the Company has experienced inflationary pressure in its supply chain and some delays in sourcing materials needed for its products resulting in some production disruption, both of which have increased the Company’s cost of revenues and decreased gross margin. While the impact of inflation has been challenging, the Company has taken actions to limit this pressure, including adjusting the pricing of its products and services. Changes in macroeconomic conditions arising from various reasons, such as the ongoing wars between Russia and Ukraine and Israel and Hamas, inflation, rising interest rates, labor force availability, sourcing, material delays and global supply chain disruptions could have a material adverse effect on the Company’s business, financial condition and results of operation.

- added (2024-10-30):
[0001437749-24-032618:note_history:8]
The Company believes that based on the information presented above and its quarterly management assessment, it has sufficient liquidity to fund its operations and capital expenditures for the next twelve months following the issuance of the unaudited condensed consolidated financial statements for the six months ended  September 30, 2024. The Company’s liquidity is highly dependent on its ability to increase revenues, its ability to control its operating costs, and its ability to raise additional capital, if necessary. The impact of global sources of instability, including the wars between Russia and Ukraine and Israel and Hamas, on the global financing markets  may reduce the Company's ability to raise additional capital, if necessary, which could negatively impact the Company's liquidity.  There can be no assurance that the Company will be able to continue to raise additional capital, on favorable terms or at all, from other sources or execute on any other means of improving liquidity described above.

- removed (2024-10-30):
[0001437749-24-024886:note_history:9]
The Company has historically experienced recurring operating losses and as of  June 30, 2024, the Company had an accumulated deficit of $1,069.2 million. In addition, the Company has historically experienced recurring negative operating cash flows. At  June 30, 2024, the Company had cash and cash equivalents of $93.5 million. Cash provided by operations for the three months ended  June 30, 2024 was $3.4 million.

- removed (2024-10-30):
[0001437749-24-024886:note_history:10]
The Company believes that based on the information presented above and its quarterly management assessment, it has sufficient liquidity to fund its operations and capital expenditures for the next twelve months following the issuance of the unaudited condensed consolidated financial statements for the three months ended  June 30, 2024. The Company’s liquidity is highly dependent on its ability to increase revenues, its ability to control its operating costs, and its ability to raise additional capital, if necessary. The impact of global sources of instability, including the wars between Russia and Ukraine and Israel and Hamas, on the global financing markets  may reduce the Company's ability to raise additional capital, if necessary, which could negatively impact the Company's liquidity.  There can be no assurance that the Company will be able to continue to raise additional capital, on favorable terms or at all, from other sources or execute on any other means of improving liquidity described above.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2024-10-30):
[0001437749-24-032618:note_history:11]
As part of the acquisition of Neeltran, the Company identified four equipment financing agreements that Neeltran had entered into prior to the acquisition of Neeltran on  May 6, 2021. The Company did not have a current debt balance as of  September 30, 2024 and had a balance of less than $0.1 million as of  March 31, 2024.
  (was, 2024-08-06, similarity 0.7234):
[0001437749-24-024886:note_history:11]
As part of the acquisition of Neeltran, the Company identified four equipment financing agreements that Neeltran had entered into prior to the acquisition of Neeltran on  May 6, 2021. The current debt balance was less than $0.1 million as of both  June 30, 2024 and  March 31, 2024.


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- added (2024-10-30):
[0001437749-24-032618:note_history:12]
|  |  | Three Months Ended September 30, 2024 |  |  | Six Months Ended September 30, 2024 |  |
| Product Line: |  | Grid |  |  | Wind |  |  | Grid |  |  | Wind |  |
| Equipment and systems |  | $ | 43,747 |  |  | $ | 7,166 |  |  | $ | 74,452 |  |  | $ | 14,591 |  |
| Services and technology development |  |  | 3,189 |  |  |  | 369 |  |  |  | 4,820 |  |  |  | 898 |  |
| Total |  | $ | 46,936 |  |  | $ | 7,535 |  |  | $ | 79,272 |  |  | $ | 15,489 |  |
| Region: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas |  | $ | 43,479 |  |  | $ | 1 |  |  | $ | 73,957 |  |  | $ | 1 |  |
| Asia Pacific |  |  | 790 |  |  |  | 7,531 |  |  |  | 1,989 |  |  |  | 15,483 |  |
| EMEA |  |  | 2,667 |  |  |  | 3 |  |  |  | 3,326 |  |  |  | 5 |  |
| Total |  | $ | 46,936 |  |  | $ | 7,535 |  |  | $ | 79,272 |  |  | $ | 15,489 |  |

- added (2024-10-30):
[0001437749-24-032618:note_history:13]
|  |  | Three Months Ended September 30, 2023 |  |  | Six Months Ended September 30, 2023 |  |
| Product Line: |  | Grid |  |  | Wind |  |  | Grid |  |  | Wind |  |
| Equipment and systems |  | $ | 22,682 |  |  | $ | 4,879 |  |  | $ | 45,808 |  |  | $ | 8,862 |  |
| Services and technology development |  |  | 5,833 |  |  |  | 610 |  |  |  | 8,443 |  |  |  | 1,145 |  |
| Total |  | $ | 28,515 |  |  | $ | 5,489 |  |  | $ | 54,251 |  |  | $ | 10,007 |  |
| Region: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas |  | $ | 24,696 |  |  | $ | 27 |  |  | $ | 47,856 |  |  | $ | 57 |  |
| Asia Pacific |  |  | 3,418 |  |  |  | 5,462 |  |  |  | 5,129 |  |  |  | 9,928 |  |
| EMEA |  |  | 401 |  |  |  | - |  |  |  | 1,266 |  |  |  | 22 |  |
| Total |  | $ | 28,515 |  |  | $ | 5,489 |  |  | $ | 54,251 |  |  | $ | 10,007 |  |

- removed (2024-10-30):
[0001437749-24-024886:note_history:14]
|  |  | Three Months Ended June 30, 2024 |  |
| Product Line: |  | Grid |  |  | Wind |  |
| Equipment and systems |  | $ | 29,726 |  |  | $ | 7,424 |  |
| Services and technology development |  |  | 2,610 |  |  |  | 530 |  |
| Total |  | $ | 32,336 |  |  | $ | 7,954 |  |
| Region: |  |  |  |  |  |  |  |  |
| Americas |  | $ | 30,479 |  |  | $ | — |  |
| Asia Pacific |  |  | 1,199 |  |  |  | 7,952 |  |
| EMEA |  |  | 658 |  |  |  | 2 |  |
| Total |  | $ | 32,336 |  |  | $ | 7,954 |  |

- removed (2024-10-30):
[0001437749-24-024886:note_history:15]
|  |  | Three Months Ended June 30, 2023 |  |
| Product Line: |  | Grid |  |  | Wind |  |
| Equipment and systems |  | $ | 23,126 |  |  | $ | 3,982 |  |
| Services and technology development |  |  | 2,611 |  |  |  | 535 |  |
| Total |  | $ | 25,737 |  |  | $ | 4,517 |  |
| Region: |  |  |  |  |  |  |  |  |
| Americas |  | $ | 23,161 |  |  | $ | — |  |
| Asia Pacific |  |  | 1,711 |  |  |  | 4,465 |  |
| EMEA |  |  | 865 |  |  |  | 52 |  |
| Total |  | $ | 25,737 |  |  | $ | 4,517 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2024-10-30):
[0001437749-24-032618:note_history:16]
The Company’s revenues in its Grid segment are derived primarily through enabling the transmission and distribution of power, providing planning services that allow it to identify power grid needs and risks, and developing ship protection systems for the U.S. Navy. The Company’s revenues in its Wind segment are derived primarily through supplying advanced power electronics and control systems, licensing its highly engineered wind turbine designs, and providing extensive customer support services to wind turbine manufacturers. The Company records revenue based on a five-step model in accordance with Accounting Standards Codification ("ASC") 606. For its customer contracts, the Company identifies the performance obligations, determines the transaction price, allocates the contract transaction price to the performance obligations, and recognizes the revenue when (or as) control of goods or services is transferred to the customer. For the three and six months ended  September 30, 2024, 90% and 89% of revenue, respectively, was recognized at the point in time when control transferred to the customer, with the remainder being recognized over time. For the three and six months ended  September 30, 2023, 79% and 78% of revenue, respectively, was recognized at the point in time when control transferred to the customer, with the remainder being recognized over time.
  (was, 2024-08-06, similarity 0.8947):
[0001437749-24-024886:note_history:16]
The Company’s revenues in its Grid segment are derived primarily through enabling the transmission and distribution of power, providing planning services that allow it to identify power grid needs and risks, and developing ship protection systems for the U.S. Navy. The Company’s revenues in its Wind segment are derived primarily through supplying advanced power electronics and control systems, licensing its highly engineered wind turbine designs, and providing extensive customer support services to wind turbine manufacturers. The Company records revenue based on a five-step model in accordance with Accounting Standards Codification ("ASC") 606. For its customer contracts, the Company identifies the performance obligations, determines the transaction price, allocates the contract transaction price to the performance obligations, and recognizes the revenue when (or as) control of goods or services is transferred to the customer. For the three months ended  June 30, 2024 and 2023, 88% and 76% of revenue, respectively, was recognized at the point in time when control transferred to the customer, with the remainder being recognized over time.

- changed (2024-10-30):
[0001437749-24-032618:note_history:17]
The Company records revenue net of sales tax, value added tax, excise tax and other taxes collected concurrent with revenue-producing activities. The Company has elected to recognize the cost for freight and shipping when control over the products sold passes to customers and revenue is recognized. The Company has elected to recognize incremental costs of obtaining a contract as expense when incurred except in contracts where the amortization period would exceed twelve months. As of  September 30, 2024 and  March 31, 2024, the Company's capitalized incremental contract costs were not material. The Company has elected not to adjust the promised amount of consideration for the effects of a significant financing component if the period of financing is twelve months or less.  The Company has elected to recognize revenue based on the as invoiced practical expedient if there is a right to consideration from a customer in an amount that corresponds directly with the value of the Company's performance.
  (was, 2024-08-06, similarity 0.9562):
[0001437749-24-024886:note_history:17]
The Company records revenue net of sales tax, value added tax, excise tax and other taxes collected concurrent with revenue-producing activities. The Company has elected to recognize the cost for freight and shipping when control over the products sold passes to customers and revenue is recognized. The Company has elected to recognize incremental costs of obtaining a contract as expense when incurred except in contracts where the amortization period would exceed twelve months. In such cases the long term amount will be assessed for materiality. As of  June 30, 2024 and  March 31, 2024, the Company's capitalized incremental contract costs were not material. The Company has elected not to adjust the promised amount of consideration for the effects of a significant financing component if the period of financing is twelve months or less.  The Company has elected to recognize revenue based on the as invoiced practical expedient if there is a right to consideration from a customer in an amount that corresponds directly with the value of the Company's performance.

- added (2024-10-30):
[0001437749-24-032618:note_history:18]
|  |  | Three Months Ended September 30, 2024 |  |  | Six Months Ended September 30, 2024 |  |
| Product Line: |  | Grid |  |  | Wind |  |  | Grid |  |  | Wind |  |
| Equipment and systems |  | $ | 43,747 |  |  | $ | 7,166 |  |  | $ | 74,452 |  |  | $ | 14,591 |  |
| Services and technology development |  |  | 3,189 |  |  |  | 369 |  |  |  | 4,820 |  |  |  | 898 |  |
| Total |  | $ | 46,936 |  |  | $ | 7,535 |  |  | $ | 79,272 |  |  | $ | 15,489 |  |
| Region: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas |  | $ | 43,479 |  |  | $ | 1 |  |  | $ | 73,957 |  |  | $ | 1 |  |
| Asia Pacific |  |  | 790 |  |  |  | 7,531 |  |  |  | 1,989 |  |  |  | 15,483 |  |
| EMEA |  |  | 2,667 |  |  |  | 3 |  |  |  | 3,326 |  |  |  | 5 |  |
| Total |  | $ | 46,936 |  |  | $ | 7,535 |  |  | $ | 79,272 |  |  | $ | 15,489 |  |

- added (2024-10-30):
[0001437749-24-032618:note_history:19]
|  |  | Three Months Ended September 30, 2023 |  |  | Six Months Ended September 30, 2023 |  |
| Product Line: |  | Grid |  |  | Wind |  |  | Grid |  |  | Wind |  |
| Equipment and systems |  | $ | 22,682 |  |  | $ | 4,879 |  |  | $ | 45,808 |  |  | $ | 8,862 |  |
| Services and technology development |  |  | 5,833 |  |  |  | 610 |  |  |  | 8,443 |  |  |  | 1,145 |  |
| Total |  | $ | 28,515 |  |  | $ | 5,489 |  |  | $ | 54,251 |  |  | $ | 10,007 |  |
| Region: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas |  | $ | 24,696 |  |  | $ | 27 |  |  | $ | 47,856 |  |  | $ | 57 |  |
| Asia Pacific |  |  | 3,418 |  |  |  | 5,462 |  |  |  | 5,129 |  |  |  | 9,928 |  |
| EMEA |  |  | 401 |  |  |  | - |  |  |  | 1,266 |  |  |  | 22 |  |
| Total |  | $ | 28,515 |  |  | $ | 5,489 |  |  | $ | 54,251 |  |  | $ | 10,007 |  |

- changed (2024-10-30):
[0001437749-24-032618:note_history:20]
As of  September 30, 2024 and 2023, the Company’s contract assets and liabilities primarily relate to the timing differences between cash received from a customer in connection with contractual rights to invoicing and the timing of revenue recognition following completion of performance obligations. The Company's accounts receivable balance is made up entirely of customer contract related balances. Changes in the Company’s contract assets, which are included in “Unbilled accounts receivable” and “Deferred program costs” (see Note 8, “Accounts Receivable” and Note 9, “Inventory” for a reconciliation to the condensed consolidated balance sheets) and "Contract liabilities", which are included in the current portion and long-term portion of "Deferred revenue" in the Company’s condensed consolidated balance sheets, are as follows (in thousands):
  (was, 2024-08-06, similarity 0.9922):
[0001437749-24-024886:note_history:20]
As of  June 30, 2024 and 2023, the Company’s contract assets and liabilities primarily relate to the timing differences between cash received from a customer in connection with contractual rights to invoicing and the timing of revenue recognition following completion of performance obligations. The Company's accounts receivable balance is made up entirely of customer contract related balances. Changes in the Company’s contract assets, which are included in “Unbilled accounts receivable” and “Deferred program costs” (see Note 7, “Accounts Receivable” and Note 8, “Inventory” for a reconciliation to the condensed consolidated balance sheets) and "Contract liabilities", which are included in the current portion and long-term portion of "Deferred revenue" in the Company’s condensed consolidated balance sheets, are as follows (in thousands):

- changed (2024-10-30):
[0001437749-24-032618:note_history:21]
|  |  | Unbilled Accounts Receivable |  |  | Deferred Program Costs |  |  | Contract Liabilities |  |
| Beginning balance as of March 31, 2024 |  | $ | 6,150 |  |  | $ | 2,523 |  |  | $ | 57,829 |  |
| Increase for balance acquired |  |  | — |  |  |  | — |  |  |  | 5,049 |  |
| Increases for costs incurred to fulfill performance obligations |  |  | — |  |  |  | 4,866 |  |  |  | — |  |
| Increase (decrease) due to customer billings |  |  | (6,241 | ) |  |  | — |  |  |  | 70,133 |  |
| Decrease due to cost recognition on completed performance obligations |  |  | — |  |  |  | (2,553 | ) |  |  | — |  |
| Increase (decrease) due to recognition of revenue based on transfer of control of performance obligations |  |  | 4,607 |  |  |  | — |  |  |  | (52,084 | ) |
| Other changes and FX impact |  |  | 7 |  |  |  | 12 |  |  |  | 344 |  |
| Ending balance as of September 30, 2024 |  | $ | 4,523 |  |  | $ | 4,848 |  |  | $ | 81,271 |  |
  (was, 2024-08-06, similarity 0.8969):
[0001437749-24-024886:note_history:21]
|  |  | Unbilled Accounts Receivable |  |  | Deferred Program Costs |  |  | Contract Liabilities |  |
| Beginning balance as of March 31, 2023 |  | $ | 9,958 |  |  | $ | 2,136 |  |  | $ | 50,760 |  |
| Increases for costs incurred to fulfill performance obligations |  |  | — |  |  |  | 1,084 |  |  |  | — |  |
| Increase (decrease) due to customer billings |  |  | (9,479 | ) |  |  | — |  |  |  | 16,308 |  |
| Decrease due to cost recognition on completed performance obligations |  |  | — |  |  |  | (1,234 | ) |  |  | — |  |
| Increase (decrease) due to recognition of revenue based on transfer of control of performance obligations |  |  | 5,092 |  |  |  | — |  |  |  | (8,974 | ) |
| Other changes and FX impact |  |  | 1 |  |  |  | — |  |  |  | (11 | ) |
| Ending balance as of June 30, 2023 |  | $ | 5,572 |  |  | $ | 1,986 |  |  | $ | 58,083 |  |

- changed (2024-10-30):
[0001437749-24-032618:note_history:22]
|  |  | Unbilled Accounts Receivable |  |  | Deferred Program Costs |  |  | Contract Liabilities |  |
| Beginning balance as of March 31, 2023 |  | $ | 9,958 |  |  | $ | 2,136 |  |  | $ | 50,760 |  |
| Increases for costs incurred to fulfill performance obligations |  |  | — |  |  |  | 2,110 |  |  |  | — |  |
| Increase (decrease) due to customer billings |  |  | (13,981 | ) |  |  | — |  |  |  | 34,284 |  |
| Decrease due to cost recognition on completed performance obligations |  |  | — |  |  |  | (2,160 | ) |  |  | — |  |
| Increase (decrease) due to recognition of revenue based on transfer of control of performance obligations |  |  | 10,351 |  |  |  | — |  |  |  | (25,710 | ) |
| Other changes and FX impact |  |  | 7 |  |  |  | (11 | ) |  |  | (288 | ) |
| Ending balance as of September 30, 2023 |  | $ | 6,335 |  |  | $ | 2,075 |  |  | $ | 59,046 |  |
  (was, 2024-08-06, similarity 0.9473):
[0001437749-24-024886:note_history:22]
|  |  | Unbilled Accounts Receivable |  |  | Deferred Program Costs |  |  | Contract Liabilities |  |
| Beginning balance as of March 31, 2024 |  | $ | 6,150 |  |  | $ | 2,523 |  |  | $ | 57,829 |  |
| Increases for costs incurred to fulfill performance obligations |  |  | — |  |  |  | 2,119 |  |  |  | — |  |
| Increase (decrease) due to customer billings |  |  | (3,521 | ) |  |  | — |  |  |  | 27,577 |  |
| Decrease due to cost recognition on completed performance obligations |  |  | — |  |  |  | (606 | ) |  |  | — |  |
| Increase (decrease) due to recognition of revenue based on transfer of control of performance obligations |  |  | 2,291 |  |  |  | — |  |  |  | (22,443 | ) |
| Other changes and FX impact |  |  | (2 | ) |  |  | (2 | ) |  |  | (50 | ) |
| Ending balance as of June 30, 2024 |  | $ | 4,918 |  |  | $ | 4,034 |  |  | $ | 62,913 |  |

- changed (2024-10-30):
[0001437749-24-032618:note_history:23]
The Company’s remaining performance obligations represent the unrecognized revenue value of the Company’s contractual commitments. The Company’s performance obligations  may vary significantly each reporting period based on the timing of major new contractual commitments. As of  September 30, 2024, the Company had outstanding performance obligations on existing contracts under ASC 606 to be recognized in the next twelve months of approximately $205.0 million. There are also approximately $102.3 million of outstanding performance obligations to be recognized over a period of thirteen to sixty months. The remaining performance obligations are subject to customer actions and therefore the timing of revenue recognition cannot be reasonably estimated.
  (was, 2024-08-06, similarity 0.9912):
[0001437749-24-024886:note_history:23]
The Company’s remaining performance obligations represent the unrecognized revenue value of the Company’s contractual commitments. The Company’s performance obligations  may vary significantly each reporting period based on the timing of major new contractual commitments. As of  June 30, 2024, the Company had outstanding performance obligations on existing contracts under ASC 606 to be recognized in the next twelve months of approximately $161.0 million. There are also approximately $90.0 million of outstanding performance obligations to be recognized over a period of thirteen to sixty months. The remaining performance obligations are subject to customer actions and therefore the timing of revenue recognition cannot be reasonably estimated.

- changed (2024-10-30):
[0001437749-24-032618:note_history:24]
The following table sets forth customers who represented 10% or more of the Company’s total revenues for the three and six months ended  September 30, 2024 and 2023:
  (was, 2024-08-06, similarity 0.936):
[0001437749-24-024886:note_history:24]
The following table sets forth customers who represented 10% or more of the Company’s total revenues for the three months ended  June 30, 2024 and 2023:

- changed (2024-10-30):
[0001437749-24-032618:note_history:25]
|  |  |  | Three Months Ended |  |  | Six Months Ended |  |
|  | Reportable |  | September 30, |  |  | September 30, |  |
|  | Segment |  | 2024 |  |  | 2023 |  |  | 2024 |  |  | 2023 |  |
| Inox Wind Limited | Wind |  |  | 12 | % |  |  | 12 | % |  |  | 14 | % |  |  | 12 | % |
| Gray Construction, Inc. | Grid |  |  | <10% |  |  |  | 11 | % |  |  | <10% |  |  |  | <10% |  |
  (was, 2024-08-06, similarity 0.6154):
[0001437749-24-024886:note_history:25]
|  |  |  | Three Months Ended |  |
|  | Reportable |  | June 30, |  |
|  | Segment |  | 2024 |  |  | 2023 |  |
| Inox Wind Limited | Wind |  |  | 18 | % |  |  | 12 | % |

- removed (2024-10-30):
[0001437749-24-024886:note_history:26]
|  |  | Three Months Ended June 30, 2024 |  |
| Product Line: |  | Grid |  |  | Wind |  |
| Equipment and systems |  | $ | 29,726 |  |  | $ | 7,424 |  |
| Services and technology development |  |  | 2,610 |  |  |  | 530 |  |
| Total |  | $ | 32,336 |  |  | $ | 7,954 |  |
| Region: |  |  |  |  |  |  |  |  |
| Americas |  | $ | 30,479 |  |  | $ | — |  |
| Asia Pacific |  |  | 1,199 |  |  |  | 7,952 |  |
| EMEA |  |  | 658 |  |  |  | 2 |  |
| Total |  | $ | 32,336 |  |  | $ | 7,954 |  |

- removed (2024-10-30):
[0001437749-24-024886:note_history:27]
|  |  | Three Months Ended June 30, 2023 |  |
| Product Line: |  | Grid |  |  | Wind |  |
| Equipment and systems |  | $ | 23,126 |  |  | $ | 3,982 |  |
| Services and technology development |  |  | 2,611 |  |  |  | 535 |  |
| Total |  | $ | 25,737 |  |  | $ | 4,517 |  |
| Region: |  |  |  |  |  |  |  |  |
| Americas |  | $ | 23,161 |  |  | $ | — |  |
| Asia Pacific |  |  | 1,711 |  |  |  | 4,465 |  |
| EMEA |  |  | 865 |  |  |  | 52 |  |
| Total |  | $ | 25,737 |  |  | $ | 4,517 |  |


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: tag_name, score: 1.0

- changed (2024-10-30):
[0001437749-24-032618:note_history:28]
The Company has performed an evaluation of subsequent events through the time of filing this Quarterly Report on Form 10-Q with the SEC and has determined that there are no such events to report.
  (was, 2024-08-06, similarity 0.8818):
[0001437749-24-024886:note_history:28]
The Company has performed an evaluation of subsequent events through the time of filing this Quarterly Report on Form 10-Q with the SEC and has determined that, other than as reported herein and described below, there are no such events to report.

- removed (2024-10-30):
[0001437749-24-024886:note_history:29]
Acquisition of Megatran

- removed (2024-10-30):
[0001437749-24-024886:note_history:30]
As described in Note 1, Nature of the Business and Operations and Liquidity, on the Acquisition Date, the Company acquired all of the issued and outstanding shares of capital stock of Megatran. Megatran is a U.S.-based global provider of engineered power conversion solutions for demanding industrial and military applications.

- removed (2024-10-30):
[0001437749-24-024886:note_history:31]
Pursuant to the Stock Purchase Agreement, the Company acquired all of the issued and outstanding shares of Megatran, for aggregate consideration in an amount equal to $61,350,000 (the “Purchase Price”), which consideration amount shall be subject to various adjustments set forth in the Stock Purchase Agreement (including those described below) and consists of: (a) (i) $25,000,000, minus (ii) the Indebtedness (as defined in the Stock Purchase Agreement) outstanding as of immediately prior to the closing, minus (iii) Company Expenses (as defined in the Stock Purchase Agreement) (collectively, the “Cash Purchase Price”); (b) a number of restricted shares (rounded up or down to the nearest whole share, as applicable) (the “Company Shares”) of the Company’s common stock, $.01 par value per share (“Common Stock”) equal to the quotient obtained by dividing (x) $31,350,000 (the “Share Purchase Price”) by (y) the closing price per share of Common Stock on the Nasdaq Global Select Market on the last trading day immediately preceding the Closing Date; and (c) an additional cash payment equal to $5,000,000, as adjusted pursuant to Sections 5.6(c), (d), and (f) of the Stock Purchase Agreement (the “Additional Cash Purchase Price”). Megatran is now a wholly-owned subsidiary of the Company and is operated and reported as a component of its Grid business unit.

- removed (2024-10-30):
[0001437749-24-024886:note_history:32]
The Acquisition completed by the Company subsequent to the three months ended  June 30, 2024 has been accounted for under the purchase method of accounting in accordance with ASC 805, Business Combinations. The Company allocated the purchase price to the assets acquired and liabilities assumed at their estimated fair values as of the date of acquisition. The excess of the purchase price paid by the Company over the estimated fair value of net assets acquired has been recorded as goodwill.

- removed (2024-10-30):
[0001437749-24-024886:note_history:33]
The total purchase price of approximately $61.4 million includes the fair value of shares of the Company’s common stock issued at closing, and cash paid, as follows (in millions):

- removed (2024-10-30):
[0001437749-24-024886:note_history:34]
| Cash payment | 30.0 |
| Issuance of 1,297,600 shares of Company’s Common Stock | 31.4 |

- removed (2024-10-30):
[0001437749-24-024886:note_history:35]
At the Acquisition Date, in addition to the $30.0 million cash, the Company valued the Company’s common stock, using $24.16 per share, which was the closing price on the day prior to the day that the Company acquired Megatran. Acquisition costs are expected to be $0.8 million and will be recorded in selling, general and administrative ("SG&A") costs. Acquisition costs are of $0.2 million were included in SG&A for the three months ended  June 30, 2024.

- removed (2024-10-30):
[0001437749-24-024886:note_history:36]
The following table summarizes the allocation of the purchase price based on the estimated fair values of the assets acquired and liabilities assumed and related deferred income taxes in connection with the Acquisition (in millions):

- removed (2024-10-30):
[0001437749-24-024886:note_history:37]
| Cash and cash equivalents |  | $ | 0.5 |  |
| Investment in joint venture |  |  | 1.2 |  |
| Prepaid and other current assets |  |  | 1.4 |  |
| Accounts receivable |  |  | 16.7 |  |
| Inventory |  |  | 22.6 |  |
| Property plant and equipment |  |  | 28.4 |  |
| Accrued expenses |  |  | (3.2 | ) |
| Accounts payable |  |  | (4.4 | ) |
| Deferred revenue |  |  | (4.5 | ) |
| Other |  |  | (0.1 | ) |
| Deferred tax liability |  |  | (6.5 | ) |
| Net tangible assets/(liabilities) |  |  | 52.1 |  |
| Backlog |  |  | 0.7 |  |
| Customer relationships |  |  | 1.3 |  |
| Net identifiable intangible assets |  |  | 2.0 |  |
| Goodwill |  |  | 7.3 |  |
| Total purchase consideration |  | $ | 61.4 |  |

- removed (2024-10-30):
[0001437749-24-024886:note_history:38]
The fair value of the financial assets acquired includes receivables with a fair value of $16.7 million. The gross amount due is $17.5 million, of which $0.8 million is expected to be uncollectible.

- removed (2024-10-30):
[0001437749-24-024886:note_history:39]
Inventory includes a $0.7 million adjustment to step up the inventory balance to fair value consistent with the purchase price allocation. The fair value was determined based on the estimated selling price of the inventory, less the remaining manufacturing and selling cost and a normal profit margin on those manufacturing and selling efforts.

- removed (2024-10-30):
[0001437749-24-024886:note_history:40]
Backlog of $0.7 million was evaluated using the multi period excess earnings method under the income approach. The contracts with customers do not provide for any guarantees to source all future requirements from the Company. The amortization method being utilized is economic consumption estimated over a two-year period with the expense being allocated to cost of revenues.

- removed (2024-10-30):
[0001437749-24-024886:note_history:41]
Customer relationships of $1.3 million relates to customers currently under contract and was determined based on a multi period excess earnings method under the income approach. The method of amortization being utilized is the economic consumption over 10 years with the expense being allocated to SG&A.

- removed (2024-10-30):
[0001437749-24-024886:note_history:42]
Goodwill represents the value associated with the acquired workforce and expected synergies related to the business combination of the two companies. Goodwill resulting from the Acquisition was assigned to the Company’s Grid segment. Goodwill recognized in the Acquisition is not deductible for tax purposes. This purchase price allocation is preliminary and has not been finalized as the analysis on the assets and liabilities acquired, primarily the tax related liability  may require further adjustments to our purchase accounting that could result in a measurement period adjustment that would impact the Company's reported net assets and goodwill as of  August 1, 2024. Material changes, if any, to the preliminary allocation summarized above will be reported once the related uncertainties are resolved, but no later than  August 1, 2025. The $6.5 million of deferred tax liability is primarily related to property plant and equipment.

- removed (2024-10-30):
[0001437749-24-024886:note_history:43]
Unaudited Pro Forma Operating Results

- removed (2024-10-30):
[0001437749-24-024886:note_history:44]
The unaudited pro forma condensed consolidated statement of operations for the year ended  March 31, 2024 and three months ended  June 30, 2024 is presented as if the Acquisition had occurred on  April 1, 2023 and  April 1, 2024, respectively.

- removed (2024-10-30):
[0001437749-24-024886:note_history:45]
|  |  | Three months ended June 30, |  |  | Year Ended March 31, |  |
|  |  | 2024 |  |  | 2024 |  |
| Revenues |  | $ | 59,310 |  |  | $ | 217,954 |  |
| Operating loss |  |  | (2,702 | ) |  |  | (7,140 | ) |
| Net loss |  | $ | (1,760 | ) |  | $ | (4,152 | ) |
| Net loss per common share |  |  |  |  |  |  |  |  |
| Basic |  |  | 36,974 |  |  |  | 31,123 |  |
| Diluted |  |  | 36,974 |  |  |  | 31,123 |  |
| Shares - basic |  | $ | (0.05 | ) |  | $ | (0.13 | ) |
| Shares - diluted |  | $ | (0.05 | ) |  | $ | (0.13 | ) |

- removed (2024-10-30):
[0001437749-24-024886:note_history:46]
The pro forma amounts include the historical operating results of the Company and Megatran with appropriate adjustments that give effect to acquisition related costs, income taxes, intangible amortization resulting from the Acquisition and certain conforming accounting policies of the Company.   The pro forma amounts are not necessarily indicative of the operating results that would have occurred if the Acquisition and related transactions had been completed at the beginning of the applicable periods presented. In addition, the pro forma amounts are not necessarily indicative of operating results in future periods.
