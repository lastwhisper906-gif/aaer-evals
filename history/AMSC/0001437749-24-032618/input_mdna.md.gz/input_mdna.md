# AMSC MD&A — 0001437749-24-032618


## mdna

[0001437749-24-032618:mdna:1]
[same as prior period, unchanged from 0001437749-24-024886:mdna:1]

[0001437749-24-032618:mdna:2]
[same as prior period, unchanged from 0001437749-24-024886:mdna:2]

[0001437749-24-032618:mdna:3]
[same as prior period, unchanged from 0001437749-24-024886:mdna:3]

[0001437749-24-032618:mdna:4]
[same as prior period, unchanged from 0001437749-24-024886:mdna:4]

[0001437749-24-032618:mdna:5]
[same as prior period, unchanged from 0001437749-24-024886:mdna:5]

[0001437749-24-032618:mdna:6]
[same as prior period, unchanged from 0001437749-24-024886:mdna:6]

[0001437749-24-032618:mdna:7]
[same as prior period, unchanged from 0001437749-24-024886:mdna:7]

[0001437749-24-032618:mdna:8]
[same as prior period, unchanged from 0001437749-24-024886:mdna:8]

[0001437749-24-032618:mdna:9]
[same as prior period, unchanged from 0001437749-24-024886:mdna:9]

[0001437749-24-032618:mdna:10]
[same as prior period, unchanged from 0001437749-24-024886:mdna:10]

[0001437749-24-032618:mdna:11]
We continue to experience some inflationary pressure in our supply chain and some delays in sourcing materials needed for our products, resulting in some production disruption, both of which have increased our cost of revenues and decreased gross margin.  While the impact of inflation has been challenging, we continue to take actions to limit this pressure including adjusting the pricing of our products and services. Changes in macroeconomic conditions arising from various reasons, such as the ongoing wars between Russia and Ukraine and Israel and Hamas, inflation, rising interest rates, labor force availability, sourcing, material delays and global supply chain disruptions, could have a material adverse effect on the Company’s business, financial condition and results of operations.

[0001437749-24-032618:mdna:12]
[same as prior period, unchanged from 0001437749-24-024886:mdna:12]

[0001437749-24-032618:mdna:13]
[same as prior period, unchanged from 0001437749-24-024886:mdna:13]

[0001437749-24-032618:mdna:14]
On August 1, 2024, we entered into a Stock Purchase Agreement (the “Stock Purchase Agreement”) with the selling stockholders named therein. Pursuant to the terms of the Stock Purchase Agreement and concurrently with entering into such agreement, the Company acquired all of the issued and outstanding shares of Megatran, for aggregate consideration in an amount equal to $61.4 million, as may be adjusted pursuant to the Stock Purchase Agreement (the “Purchase Price”), including a cash payment after closing of $5.0 million, as adjusted pursuant to Sections 5.6(c), (d), and (f) of the Stock Purchase Agreement (the “Additional Cash Purchase Price”). At closing, we paid to Megatran's selling stockholders $25.0 million in cash on hand, and 1,297,600 restricted shares of our common stock. On September 23, 2024, the Company paid the Additional Cash Purchase Price to the selling stockholders, which was calculated based on the agreed upon formula set forth in the Stock Purchase Agreement, in the amount of $8.3 million. Megatran's wholly-owned subsidiary, NWL, Inc. ("NWL"), is a U.S.-based global provider of engineered power conversion solutions for demanding industrial and military applications.  As a result of this transaction, Megatran became a wholly-owned subsidiary and is operated by our Grid business unit.

[0001437749-24-032618:mdna:15]
[same as prior period, unchanged from 0001437749-24-024886:mdna:15]

[0001437749-24-032618:mdna:16]
The preparation of the unaudited condensed consolidated financial statements requires that we make estimates and judgments that affect the reported amounts of assets, liabilities, revenues and expenses, and related disclosure of contingent assets and liabilities. We base our estimates on historical experience and various other assumptions that are believed to be reasonable under the circumstances, the results of which form the basis for making judgments about the carrying values of assets and liabilities that are not readily apparent from other sources. Actual results may differ under different assumptions or conditions.

[0001437749-24-032618:mdna:17]
Equity Method Investments

[0001437749-24-032618:mdna:18]
We treat the equity investment in the condensed consolidated financial statements under the equity method. Equity method investments are equity securities in entities we do not control but over which we have the ability to exercise significant influence. These investments are accounted for under the equity method of accounting in accordance with ASC 323, Investments — Equity Method and Joint Ventures. Equity method investments are measured at cost minus impairment, if any, plus or minus the Company’s share of an investee’s income or loss, less distributions received. Other than those noted here, there were no significant changes in the critical accounting policies that were disclosed in our Annual Report on Form 10-K for the fiscal year ended March 31, 2024.

[0001437749-24-032618:mdna:19]
[same as prior period, unchanged from 0001437749-24-024886:mdna:17]

[0001437749-24-032618:mdna:20]
Three and six months ended September 30, 2024, compared to the three and six months ended September 30, 2023

[0001437749-24-032618:mdna:21]
[same as prior period, unchanged from 0001437749-24-024886:mdna:19]

[0001437749-24-032618:mdna:22]
Total revenues increased 60% to $54.5 million for the three months ended September 30, 2024 and total revenues increased 47% to $94.8 million for the six months ended September 30, 2024, compared to $34.0 million and $64.3 million for the three and six months ended September 30, 2023, respectively. Our revenues are summarized as follows (in thousands):

[0001437749-24-032618:mdna:23]
|  |  | Three Months Ended September 30, |  |  | Six Months Ended September 30, |  |
|  |  | 2024 |  |  | 2023 |  |  | 2024 |  |  | 2023 |  |
| Revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Grid |  | $ | 46,936 |  |  | $ | 28,515 |  |  | $ | 79,272 |  |  | $ | 54,251 |  |
| Wind |  |  | 7,535 |  |  |  | 5,489 |  |  |  | 15,489 |  |  |  | 10,007 |  |
| Total |  | $ | 54,471 |  |  | $ | 34,004 |  |  | $ | 94,761 |  |  | $ | 64,258 |  |

[0001437749-24-032618:mdna:24]
Our Grid business unit accounted for 86% and 84% of total revenues for the three and six months ended September 30, 2024, respectively, compared to 84% for each of the three and six months ended September 30, 2023. Our Grid business unit revenues increased 65% to $46.9 million in the three months ended September 30, 2024, from $28.5 million in the three months ended September 30, 2023. Our Grid business unit revenues increased 46% to $79.3 million in the six months ended September 30, 2024, from $54.3 million in the six months ended September 30, 2023. The increase in the Grid business unit revenues in the three and six months ended September 30, 2024, compared to the three and six months ended September 30, 2023 was primarily driven by the acquisition of Megatran and increased shipments of new energy power systems than in the prior year periods.

[0001437749-24-032618:mdna:25]
Our Wind business unit accounted for 14% and 16% of total revenues for the three and six months ended September 30, 2024, respectively, compared to 16% for each of the three and six months ended September 30, 2023. Revenues in the Wind business unit increased 37% and 55% to $7.5 million and $15.5 million in the three and six months ended September 30, 2024, respectively, from $5.5 million and $10.0 million in the three and six months ended September 30, 2023, respectively. The increase during the three and six months ended September 30, 2024, compared to the three and six months ended September 30, 2023, was driven by additional shipments of electrical control systems ("ECS") at increased prices.

[0001437749-24-032618:mdna:26]
[same as prior period, unchanged from 0001437749-24-024886:mdna:24]

[0001437749-24-032618:mdna:27]
Cost of revenues increased by 53% to $38.9 million for the three months ended September 30, 2024, compared to $25.4 million for the three months ended September 30, 2023. Cost of revenues increased by 35% to $66.9 million for the six months ended September 30, 2024, compared to $49.4 million for the six months ended September 30, 2023. Gross margin was 29% and 29% for the three and six months ended September 30, 2024, respectively, compared to 25% and 23% for the three and six months ended September 30, 2023, respectively. Cost of revenues includes total amortization expense of $0.2 million in the three months ended September 30, 2024, as a result of the Megatran acquired backlog intangible assets. In addition, a fair value purchase adjustment of approximately $0.7 million for the step-up basis assigned to acquired inventory, to properly reflect the fair value in purchase accounting. Of this adjustment, $0.3 million was charged to cost of revenues in the three months ended September 30, 2024, when the inventory sold. The increase in gross margin in the three and six months ended September 30, 2024 was due to higher revenues, a favorable product mix and favorable impacts across the business due to pricing increases across our product lines.

[0001437749-24-032618:mdna:28]
[same as prior period, unchanged from 0001437749-24-024886:mdna:26]

[0001437749-24-032618:mdna:29]
[same as prior period, unchanged from 0001437749-24-024886:mdna:27]

[0001437749-24-032618:mdna:30]
Research and development ("R&D") expenses increased 61% and 41% in the three and six months ended September 30, 2024, respectively, to $2.6 million and $4.9 million from $1.6 million and $3.5 million in the three and six months ended September 30, 2023, respectively. The increase was driven primarily by higher overall compensation expense and additional supplies and materials.

[0001437749-24-032618:mdna:31]
[same as prior period, unchanged from 0001437749-24-024886:mdna:29]

[0001437749-24-032618:mdna:32]
Selling, general and administrative ("SG&A") expenses increased 32% and 23% in the three and six months ended September 30, 2024, respectively, to $10.5 million and $19.4 million from $7.9 million and $15.8 million in the three and six months ended September 30, 2023, respectively. The increase in SG&A expense in the three and six months ended September 30, 2024, respectively, was due to higher overall compensation expense and higher acquisition costs.

[0001437749-24-032618:mdna:33]
[same as prior period, unchanged from 0001437749-24-024886:mdna:31]

[0001437749-24-032618:mdna:34]
We recorded amortization expense related to our core technology and know-how, customer relationships, and other intangible assets of $0.4 million and $0.8 million in the three and six months ended September 30, 2024, respectively, and $0.5 million and $1.1 million in the three and six months ended September 30, 2023, respectively. The decrease in amortization expense is a result of using the economic consumption method as the basis to amortize the acquired customer relationship intangible assets from Northeast Power Systems, Inc. ("NEPSI") and Neeltran.

[0001437749-24-032618:mdna:35]
[same as prior period, unchanged from 0001437749-24-024886:mdna:33]

[0001437749-24-032618:mdna:36]
The change in fair value of our contingent consideration for the earnout payment on the acquisition of NEPSI resulted in a gain of $0.5 million from a decrease in fair value and a loss of $3.4 million resulting from an increase in fair value in the three and six months ended September 30, 2024, respectively. During the three and six months ended September 30, 2024, we issued 300,000 shares of common stock of the Company to the selling stockholders following certification of the achievement of specified earnout revenue objectives. We recorded the above noted changes, compared to losses of $0.9 million and $2.2 million in the three and six months ended September 30, 2023, respectively. We also recorded a $3.3 million payment relating to the Megatran acquisition, as a payment to settle the remaining obligations after the acquisition. The value of this contingent consideration was de minimus at the Acquisition Date and the resulting change in fair value was recorded during the three and six months ended September 30, 2024

[0001437749-24-032618:mdna:37]
.

[0001437749-24-032618:mdna:38]
[same as prior period, unchanged from 0001437749-24-024886:mdna:35]

[0001437749-24-032618:mdna:39]
[same as prior period, unchanged from 0001437749-24-024886:mdna:36]

[0001437749-24-032618:mdna:40]
|  |  | Three Months Ended September 30, |  |  | Six Months Ended September 30, |  |
|  |  | 2024 |  |  | 2023 |  |  | 2024 |  |  | 2023 |  |
| Operating income (loss): |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Grid |  | $ | 2,336 |  |  | $ | (679 | ) |  | $ | 3,195 |  |  | $ | (2,649 | ) |
| Wind |  |  | 516 |  |  |  | 252 |  |  |  | 1,515 |  |  |  | (398 | ) |
| Unallocated corporate expenses |  |  | (3,605 | ) |  |  | (1,942 | ) |  |  | (8,753 | ) |  |  | (4,655 | ) |
| Total |  | $ | (753 | ) |  | $ | (2,369 | ) |  | $ | (4,043 | ) |  | $ | (7,702 | ) |

[0001437749-24-032618:mdna:41]
Our Grid business segment generated operating income of $2.3 million and $3.2 million in the three and six months ended September 30, 2024, respectively, compared to operating losses of $0.7 million and $2.6 million in the three and six months ended September 30, 2023, respectively. The increase in the Grid business unit operating income in the three and six months ended September 30, 2024 was due to higher revenues and gross margins in part due to a favorable product mix.

[0001437749-24-032618:mdna:42]
Our Wind business segment generated operating income of $0.5 million and $1.5 million in the three and six months ended September 30, 2024, respectively, compared to operating income of $0.3 million and operating loss of $0.4 million in the three and six months ended September 30, 2023, respectively. The improvement in the Wind business unit operating income in the three and six months ended September 30, 2024 was due to higher revenues and gross margins from increased sales of ECS units.

[0001437749-24-032618:mdna:43]
Unallocated corporate expenses included net losses on contingent consideration of $2.8 million and $6.7 million in the three and six months ended September 30, 2024, respectively, and net losses of $0.9 million and $2.2 million in the three and six months ended September 30, 2023, respectively. Additionally, unallocated corporate expenses consisted of stock-based compensation expense of $0.8 million and $2.1 million in the three and six months ended September 30, 2024, respectively, and $1.1 million and $2.5 million in the three and six months ended September 30, 2023, respectively.

[0001437749-24-032618:mdna:44]
[same as prior period, unchanged from 0001437749-24-024886:mdna:41]

[0001437749-24-032618:mdna:45]
Interest income, net, was $1.0 million and $2.1 million in the three and six months ended September 30, 2024, respectively, compared to $0.2 million and $0.4 million in the three and six months ended September 30, 2023, respectively. The increase in interest income, net, in the three and six months ended September 30, 2024 was due to higher cash balances.

[0001437749-24-032618:mdna:46]
[same as prior period, unchanged from 0001437749-24-024886:mdna:43]

[0001437749-24-032618:mdna:47]
Other expense, net, was $0.3 million and $0.5 million in the three and six months ended September 30, 2024, respectively, compared to $0.2 million and $0.3 million in the three and six months ended September 30, 2023, respectively. The increase in other expense, net, during the three and six months ended September 30, 2024, compared to the three and six months ended September 30, 2023, was driven by the impacts of unfavorable fluctuations in foreign currencies during the periods.

[0001437749-24-032618:mdna:48]
[same as prior period, unchanged from 0001437749-24-024886:mdna:45]

[0001437749-24-032618:mdna:49]
Income tax benefit was $5.0 million and $4.8 million in the three and six months ended September 30, 2024, respectively. Income tax expense was $0.1 million and $0.2 million in the three and six months ended September 30, 2023, respectively. The improvement in income tax benefit was a result of the release of the valuation allowance due to the recording of the deferred tax liability from the acquisition of Megatran.

[0001437749-24-032618:mdna:50]
Net income (loss)

[0001437749-24-032618:mdna:51]
Net income was $4.9 million and $2.4 million in the three and six months ended September 30, 2024, respectively, compared to net losses of $2.5 million and $7.9 million in the three and six months ended September 30, 2023, respectively. The improvement in net loss was driven primarily by deferred tax liability recorded as a result of the Megatran acquisition as well as increased revenues and gross margins.

[0001437749-24-032618:mdna:52]
[same as prior period, unchanged from 0001437749-24-024886:mdna:49]

[0001437749-24-032618:mdna:53]
[same as prior period, unchanged from 0001437749-24-024886:mdna:50]

[0001437749-24-032618:mdna:54]
We define non-GAAP net income (loss) as net income (loss) before stock-based compensation, acquisition costs, amortization of acquisition-related intangibles, change in fair value of contingent consideration, and other non-cash or unusual charges. We believe non-GAAP net income (loss) assists management and investors in comparing our performance across reporting periods on a consistent basis by excluding these non-cash charges and other items that we do not believe are indicative of our core operating performance. In addition, we use non-GAAP net income (loss) as a factor to evaluate the effectiveness of our business strategies. A reconciliation of GAAP to non-GAAP net income (loss) is set forth in the table below (in thousands, except per share data):

[0001437749-24-032618:mdna:55]
|  |  | Three Months Ended September 30, |  |  | Six Months Ended September 30, |  |
|  |  | 2024 |  |  | 2023 |  |  | 2024 |  |  | 2023 |  |
| Net income (loss) |  | $ | 4,887 |  |  | $ | (2,485 | ) |  | $ | 2,363 |  |  | $ | (7,883 | ) |
| Stock-based compensation |  |  | 843 |  |  |  | 1,111 |  |  |  | 2,072 |  |  |  | 2,468 |  |
| Acquisition costs |  |  | 850 |  |  |  | — |  |  |  | 1,080 |  |  |  | — |  |
| Amortization of acquisition-related intangibles |  |  | 608 |  |  |  | 538 |  |  |  | 1,020 |  |  |  | 1,082 |  |
| Change in fair value of contingent consideration |  |  | 2,762 |  |  |  | 850 |  |  |  | 6,682 |  |  |  | 2,200 |  |
| Non-GAAP net income (loss) |  | $ | 9,950 |  |  | $ | 14 |  |  | $ | 13,217 |  |  | $ | (2,133 | ) |
| Non-GAAP net income (loss) per share - basic |  | $ | 0.27 |  |  | $ | - |  |  | $ | 0.36 |  |  | $ | (0.07 | ) |
| Non-GAAP net income (loss) per share - diluted |  | $ | 0.27 |  |  | $ | - |  |  | $ | 0.36 |  |  | $ | (0.07 | ) |
| Weighted average shares outstanding - basic |  |  | 36,952 |  |  |  | 28,828 |  |  |  | 36,317 |  |  |  | 28,545 |  |
| Weighted average shares outstanding - diluted |  |  | 37,499 |  |  |  | 28,828 |  |  |  | 36,951 |  |  |  | 28,545 |  |

[0001437749-24-032618:mdna:56]
We incurred non-GAAP net income of $10.0 million and $13.2 million, or $0.27 and $0.36 per share, for the three and six months ended September 30, 2024, respectively, compared to a non-GAAP net income of less than $0.1 million and a non-GAAP net loss of $2.1 million, or $0.00 and $0.07 per share, for the three and six months ended September 30, 2023, respectively. The improvement in the non-GAAP net income (loss) for the three and six months ended September 30, 2024 was due to a lower operating loss driven by higher revenues and gross margins. In the three months ended June 30, 2024, we excluded acquisition costs from the reconciliation of GAAP to non-GAAP net income (loss) as there was no definitive agreement with respect to the acquisition of Megatran as of June 30, 2024.

[0001437749-24-032618:mdna:57]
[same as prior period, unchanged from 0001437749-24-024886:mdna:54]

[0001437749-24-032618:mdna:58]
[same as prior period, unchanged from 0001437749-24-024886:mdna:55]

[0001437749-24-032618:mdna:59]
We have experienced recurring operating losses and, as of September 30, 2024, had an accumulated deficit of $1,064.3 million.

[0001437749-24-032618:mdna:60]
[same as prior period, unchanged from 0001437749-24-024886:mdna:57]

[0001437749-24-032618:mdna:61]
In January 2024, we filed a shelf registration statement on Form S-3 that will expire three years from the date on which it was declared effective, March 15, 2027 (the “First Form S-3”). The First Form S-3 allows us to offer and sell from time-to-time up to $250 million of common stock, debt securities, warrants or units comprised of any combination of these securities. The First Form S-3 is intended to provide us flexibility to conduct registered sales of our securities, subject to market conditions, in order to fund our future capital needs. The terms of any future offering under the First Form S-3 will be established at the time of such offering and will be described in a prospectus supplement filed with the SEC prior to the completion of any such offering.

[0001437749-24-032618:mdna:62]
[same as prior period, unchanged from 0001437749-24-024886:mdna:59]

[0001437749-24-032618:mdna:63]
As described above, on August 1, 2024, we acquired all of the issued and outstanding shares of Megatran, for aggregate consideration in an amount equal to $61.4 million (the “Purchase Price”), which consideration amount was subject to various adjustments set forth in the Stock Purchase Agreement (including those described below) and consisted of: (a) (i) $25.0 million, minus (ii) the Indebtedness (as defined in the Stock Purchase Agreement) outstanding as of immediately prior to the closing, minus (iii) Company Expenses (as defined in the Stock Purchase Agreement) (collectively, the “Cash Purchase Price”); (b) a number of restricted shares (rounded up or down to the nearest whole share, as applicable) (the “Company Shares”) of our common stock equal to the quotient obtained by dividing (x) $31.4 million by (y) the closing price per share of Common Stock on the Nasdaq Global Select Market on the last trading day immediately preceding August 1, 2024; and (c) an additional cash payment equal to $5.0 million, as adjusted pursuant to Sections 5.6(c), (d), and (f) of the Stock Purchase Agreement. Megatran is now a wholly-owned subsidiary of the Company and, together with its wholly-owned subsidiaries and affiliates, is operated and reported as a component of its Grid business unit. On September 23, 2024, the Company paid the Additional Cash Purchase Price to the selling stockholders, which was calculated based on the agreed upon formula, in the amount of $8.3 million.

[0001437749-24-032618:mdna:64]
In August 2024, we filed an automatically-effective shelf registration statement on Form S-3 that will expire no later than August 12, 2027 (the “Second Form S-3”). The Second Form S-3 allows us to offer and sell from time-to-time common stock, debt securities, warrants or units comprised of any combination of these securities and allows certain selling stockholders to offer and sell from time-to-time common stock. The Second Form S-3 is intended to assist the selling stockholders in the resale of their common stock and to provide us flexibility to conduct registered sales of its securities, subject to market conditions, in order to fund our future capital needs. The terms of any future offering under the Second Form S-3 will be established at the time of such offering and will be described in a prospectus supplement filed with the SEC prior to the completion of any such offering.

[0001437749-24-032618:mdna:65]
As of September 30, 2024, we had cash, cash equivalents and restricted cash of $74.8 million, compared to $92.3 million as of March 31, 2024, a decrease of $17.5 million. As of September 30, 2024, we had $3.9 million in cash, cash equivalents, and restricted cash in foreign bank accounts. Our cash, cash equivalents, and restricted cash are summarized as follows (in thousands):

[0001437749-24-032618:mdna:66]
|  |  | September 30, 2024 |  |  | March 31, 2024 |  |
| Cash and cash equivalents |  | $ | 72,131 |  |  | $ | 90,522 |  |
| Restricted cash |  |  | 2,655 |  |  |  | 1,758 |  |
| Total cash, cash equivalents, and restricted cash |  | $ | 74,786 |  |  | $ | 92,280 |  |

[0001437749-24-032618:mdna:67]
For the six months ended September 30, 2024, net cash provided by operating activities was $16.1 million, compared to cash used in operations of $1.3 million for the six months ended September 30, 2023. The increase in cash flows provided by operating activities in the six months ended September 30, 2024 was due primarily to increased net income, increased deferred revenue, decrease in cash spent on accounts payable and accrued expenses, and a decrease in inventory purchases, and change in fair value of contingent consideration, offset by cash spent on prepaid expenses, deferred income taxes, decreased accounts receivable, and a decrease in operating leases.

[0001437749-24-032618:mdna:68]
For the six months ended September 30, 2024, net cash used in investing activities was $33.5 million, compared to $0.4 million for the six months ended September 30, 2023. The increase in net cash used in investing activities was primarily due to cash paid for the acquisition of Megatran.

[0001437749-24-032618:mdna:69]
For the six months ended September 30, 2024, net cash used in financing activities was $0.1 million compared to net cash provided by financing activities of $0.1 million for the six months ended September 30, 2023. The decrease was due to the repurchase of common stock in connection with employee tax obligations upon the vesting of stock awards, offset by proceeds related to ESPP.

[0001437749-24-032618:mdna:70]
As of September 30, 2024, we had $1.5 million of restricted cash included in long-term assets and $1.2 million of restricted cash included in current assets. At March 31, 2024, we had $1.3 million of restricted cash included in long-term assets and $0.5 million of restricted cash in current assets. These amounts included in restricted cash primarily represent collateral deposits to secure surety bonds and letters of credit for various customer contracts. These deposits are held in interest bearing accounts.

[0001437749-24-032618:mdna:71]
We are a party to many contractual obligations involving commitments to make payments to third parties. These obligations impact our short-term and long-term liquidity and capital resource needs. Certain contractual obligations are reflected on the condensed consolidated balance sheet as of September 30, 2024, while others are considered future commitments. We have various contractual arrangements, under which we have committed to purchase certain minimum quantities of goods or services on an annual basis. For information regarding our other contractual obligations, refer to Note 15, "Contingent Consideration," Note 16, "Debt," Note 17, "Leases" and Note 18, "Commitments and Contingencies" to our condensed consolidated financial statements included elsewhere in this Quarterly Report on Form 10-Q.

[0001437749-24-032618:mdna:72]
[same as prior period, unchanged from 0001437749-24-024886:mdna:67]

[0001437749-24-032618:mdna:73]
Legal Proceedings

[0001437749-24-032618:mdna:74]
[same as prior period, unchanged from 0001437749-24-024886:mdna:69]

[0001437749-24-032618:mdna:75]
[same as prior period, unchanged from 0001437749-24-024886:mdna:70]

[0001437749-24-032618:mdna:76]
In November 2023, the FASB issued ASU 2023-07, Segment Reporting (Topic 280): Improvements to Reportable Segment Disclosures. The amendments in ASU 2023-07 improve the disclosures about a public entity’s reportable segments and address requests from investors for additional, more detailed information about a reportable segment’s expenses. Following the release of ASU 2023-07 in November 2023, the effective date will be annual reporting periods beginning after December 15, 2024. As of September 30, 2024, we are evaluating the impact on our condensed consolidated financial statements.

[0001437749-24-032618:mdna:77]
In December 2023, the FASB issued ASU 2023-09, Income Taxes (Topic 740): Improvements to Income Tax Disclosures. The amendments in ASU 2023-09 address investor requests for more transparency about income tax information through improvements to income tax disclosures primarily related to the rate reconciliation and income taxes paid information. Following the release of ASU 2023-09 in December 2023, the effective date will be annual reporting periods beginning after December 15, 2024. As of September 30, 2024, we are evaluating the impact on our condensed consolidated financial statements.

[0001437749-24-032618:mdna:78]
In March 2024, the FASB issued ASU 2024-02, Codification Improvements—Amendments to Remove References to the Concepts Statements. The amendments in ASU 2024-02 contain amendments to the Codification that remove references to various FASB Concepts Statements. Following the release of ASU 2024-02 in March 2024, the effective date will be annual reporting periods beginning after December 15, 2024. As of September 30, 2024, we are evaluating the impact on our condensed consolidated financial statements.

[0001437749-24-032618:mdna:79]
We do not believe that, outside of those disclosed here, there are any other recently issued accounting pronouncements that will have a material impact on our condensed consolidated financial statements.
