# AMSC notes — 0001437749-24-032618


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0001437749-24-032618:notes:1]
[same as prior period, unchanged from 0001437749-24-024886:notes:1]

[0001437749-24-032618:notes:2]
[same as prior period, unchanged from 0001437749-24-024886:notes:2]

[0001437749-24-032618:notes:3]
[same as prior period, unchanged from 0001437749-24-024886:notes:3]

[0001437749-24-032618:notes:4]
These unaudited condensed consolidated financial statements of the Company have been prepared on a going concern basis in accordance with United States generally accepted accounting principles (“GAAP”) and the Securities and Exchange Commission’s (“SEC”) instructions to Form 10-Q. Certain prior period amounts were reclassified to conform to the presentation in the current period. The going concern basis of presentation assumes that the Company will continue operations and will be able to realize its assets and discharge its liabilities and commitments in the normal course of business. Certain information and footnote disclosures normally included in the condensed consolidated financial statements prepared in accordance with GAAP have been or omitted pursuant to those instructions. The year-end balance sheet data was derived from audited financial statements but does not include all disclosures required by GAAP. The unaudited condensed consolidated financial statements, in the opinion of management, reflect all adjustments (consisting of normal recurring adjustments) necessary for a fair statement of the results for the interim periods ended  September 30, 2024 and 2023 and the financial position at  September 30, 2024; however, these results are not necessarily indicative of results which  may be expected for the full year. The interim condensed consolidated financial statements, and notes thereto, should be read in conjunction with the audited condensed consolidated financial statements for the year ended  March 31, 2024, and notes thereto, included in the Company’s Annual Report on Form 10-K for the year ended  March 31, 2024 filed with the SEC on  May 29, 2024.

[0001437749-24-032618:notes:5]
[same as prior period, unchanged from 0001437749-24-024886:notes:5]

[0001437749-24-032618:notes:6]
The Company has historically experienced recurring operating losses and as of  September 30, 2024, the Company had an accumulated deficit of $1,064.3 million. In addition, the Company has historically experienced recurring negative operating cash flows. At  September 30, 2024, the Company had cash and cash equivalents of $72.1 million. Cash provided by operations for the six months ended  September 30, 2024 was $16.1 million.

[0001437749-24-032618:notes:7]
In  January 2024, the Company filed a shelf registration statement on Form S-3 that will expire three years from the date on which it was declared effective,  March 15, 2027 (the “First Form S-3”). The First Form S-3 allows the Company to offer and sell from time-to-time up to $250 million of common stock, debt securities, warrants or units comprised of any combination of these securities, with $250 million available for future offerings as of  September 30, 2024. The First Form S-3 is intended to provide the Company flexibility to conduct registered sales of its securities, subject to market conditions, in order to fund its future capital needs. The terms of any future offering under the First Form S-3 will be established at the time of such offering and will be described in a prospectus supplement filed with the SEC prior to the completion of any such offering.

[0001437749-24-032618:notes:8]
[same as prior period, unchanged from 0001437749-24-024886:notes:8]

[0001437749-24-032618:notes:9]
On  August 1, 2024 (the "Acquisition Date"), the Company entered into a Stock Purchase Agreement (the “Stock Purchase Agreement”) with the selling stockholders named therein. Pursuant to the terms of the Stock Purchase Agreement and concurrently with entering into such agreement, the Company acquired all of the issued and outstanding shares of Megatran Industries, Inc. ("Megatran") (the "Acquisition"), for aggregate consideration in an amount equal to $61.4 million (the “Purchase Price”), which consideration amount was subject to various adjustments set forth in the Stock Purchase Agreement (including those described below) and consisted of: (a) (i) $25.0 million, minus (ii) the Indebtedness (as defined in the Stock Purchase Agreement) outstanding as of immediately prior to the closing, minus (iii) Company Expenses (as defined in the Stock Purchase Agreement) (collectively, the “Cash Purchase Price”); (b) a number of restricted shares (rounded up or down to the nearest whole share, as applicable) (the “Company Shares”) of the Company’s common stock, $.01 par value per share (“Common Stock”) equal to the quotient obtained by dividing (x) $31.4 million (the “Share Purchase Price”) by (y) the closing price per share of Common Stock on the Nasdaq Global Select Market on the last trading day immediately preceding the Closing Date; and (c) an additional cash payment equal to $5.0 million, as adjusted pursuant to Sections 5.6(c), (d), and (f) of the Stock Purchase Agreement (the “Additional Cash Purchase Price”). Megatran is now a wholly-owned subsidiary of the Company and, together with its wholly-owned subsidiaries and affiliates, is operated and reported as a component of its Grid business unit. On  September 23, 2024, the Company paid $3.3 million to the selling stockholders, which was calculated based on the agreed upon formula set forth in the Stock Purchase Agreement. This amount is reflected as the change in fair value of this contingent consideration in the three and six months ended  September 30, 2024. As of  September 30, 2024, there are no remaining obligations to the selling stockholders of Megatran.

[0001437749-24-032618:notes:10]
In  August 2024, the Company filed an automatically-effective shelf registration statement on Form S-3 that will expire no later than  August 12, 2027 (the “Second Form S-3”). The Second Form S-3 allows the Company to offer and sell from time-to-time unspecified amounts of common stock, debt securities, warrants or units comprised of any combination of these securities and allows certain selling stockholders to offer and sell from time-to-time common stock. The Second Form S-3 is intended to assist the selling stockholders in the resale of their common stock and to provide the Company flexibility to conduct registered sales of its securities, subject to market conditions, in order to fund its future capital needs. The terms of any future offering under the Second Form S-3 will be established at the time of such offering and will be described in a prospectus supplement filed with the SEC prior to the completion of any such offering.

[0001437749-24-032618:notes:11]
In recent periods, the Company has experienced inflationary pressure in its supply chain and some delays in sourcing materials needed for its products resulting in some production disruption, both of which have increased the Company’s cost of revenues and decreased gross margin. While the impact of inflation has been challenging, the Company has taken actions to limit this pressure, including adjusting the pricing of its products and services. Changes in macroeconomic conditions arising from various reasons, such as the ongoing wars between Russia and Ukraine and Israel and Hamas, inflation, rising interest rates, labor force availability, sourcing, material delays and global supply chain disruptions could have a material adverse effect on the Company’s business, financial condition and results of operations.

[0001437749-24-032618:notes:12]
The Company believes that based on the information presented above and its quarterly management assessment, it has sufficient liquidity to fund its operations and capital expenditures for the next twelve months following the issuance of the unaudited condensed consolidated financial statements for the six months ended  September 30, 2024. The Company’s liquidity is highly dependent on its ability to increase revenues, its ability to control its operating costs, and its ability to raise additional capital, if necessary. The impact of global sources of instability, including the wars between Russia and Ukraine and Israel and Hamas, on the global financing markets  may reduce the Company's ability to raise additional capital, if necessary, which could negatively impact the Company's liquidity.  There can be no assurance that the Company will be able to continue to raise additional capital, on favorable terms or at all, from other sources or execute on any other means of improving liquidity described above.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001437749-24-032618:notes:13]
2. Acquisition

[0001437749-24-032618:notes:14]
Acquisition of Megatran

[0001437749-24-032618:notes:15]
As described in Note 1, Nature of the Business and Operations and Liquidity, on the Acquisition Date, the Company acquired all of the issued and outstanding shares of capital stock of Megatran. Megatran's wholly-owned subsidiary, NWL, Inc. ("NWL"), is a U.S.-based global provider of engineered power conversion solutions for demanding industrial and military applications.

[0001437749-24-032618:notes:16]
Pursuant to the Stock Purchase Agreement, the Company acquired all of the issued and outstanding shares of Megatran, for aggregate consideration in an amount equal to $61.4 million, which consideration amount was subject to various adjustments set forth in the Stock Purchase Agreement (including those described below) and consisted of: (a) (i) $25.0 million, minus (ii) the Indebtedness (as defined in the Stock Purchase Agreement) outstanding as of immediately prior to the closing, minus (iii) Company Expenses (as defined in the Stock Purchase Agreement); (b) a number of restricted shares (rounded up or down to the nearest whole share, as applicable) of Common Stock equal to the quotient obtained by dividing (x) $31.4 million by (y) the closing price per share of Common Stock on the Nasdaq Global Select Market on the last trading day immediately preceding the Closing Date; and (c) an additional cash payment equal to $5.0 million, as adjusted pursuant to Sections 5.6(c), (d), and (f) of the Stock Purchase Agreement. Megatran is now a wholly-owned subsidiary of the Company and, together with its wholly-owned subsidiaries and affiliates, is operated and reported as a component of its Grid business unit. On  September 23, 2024, the Company paid $3.3 million to the selling stockholders, which was calculated based on the agreed upon formula set forth in the Stock Purchase Agreement. This amount is reflected as the change in fair value of this contingent consideration in the three and six months ended  September 30, 2024. As of  September 30, 2024, there are no remaining obligations to the selling stockholders of Megatran.

[0001437749-24-032618:notes:17]
The Acquisition has been accounted for under the purchase method of accounting in accordance with ASC 805, Business Combinations. The Company allocated the purchase price to the assets acquired and liabilities assumed at their estimated fair values as of the date of acquisition. The excess of the purchase price paid by the Company over the estimated fair value of net assets acquired has been recorded as goodwill.

[0001437749-24-032618:notes:18]
The total purchase price of approximately $61.4 million includes the fair value of shares of the Company’s common stock issued at closing, and cash paid, as follows (in millions):

[0001437749-24-032618:notes:19]
| Cash payments | $30.0 |
| Issuance of 1,297,600 shares of Company’s Common Stock | $31.4 |

[0001437749-24-032618:notes:20]
At the Acquisition Date, in addition to the $30.0 million cash, the Company valued the Company’s common stock, using $24.16 per share, which was the closing price on the day prior to the day that the Company acquired Megatran. Acquisition costs of $0.9 million and $1.1 million were included in selling, general and administrative ("SG&A") for the three and six months ended  September 30, 2024, respectively.

[0001437749-24-032618:notes:21]
The following table summarizes the allocation of the purchase price based on the estimated fair values of the assets acquired and liabilities assumed and related deferred income taxes in connection with the Acquisition (in millions):

[0001437749-24-032618:notes:22]
| Cash and cash equivalents |  | $ | 0.4 |  |
| Equity-method investments |  |  | 1.2 |  |
| Prepaid expenses and other current assets |  |  | 1.7 |  |
| Accounts receivable |  |  | 16.1 |  |
| Inventory |  |  | 23.1 |  |
| Property, plant, and equipment |  |  | 28.4 |  |
| Accounts payable and accrued expenses |  |  | (5.6 | ) |
| Deferred revenue |  |  | (5.0 | ) |
| Deferred tax liability |  |  | (6.4 | ) |
| Net tangible assets/(liabilities) |  |  | 53.9 |  |
| Backlog |  |  | 0.7 |  |
| Customer relationships |  |  | 1.3 |  |
| Net identifiable intangible assets |  |  | 2.0 |  |
| Goodwill |  |  | 5.5 |  |
| Total purchase consideration |  | $ | 61.4 |  |

[0001437749-24-032618:notes:23]
The fair value of the financial assets acquired includes receivables with a fair value of $16.1 million. The gross amount due is $16.9 million, of which $0.8 million is expected to be uncollectible.

[0001437749-24-032618:notes:24]
Inventory includes a $0.7 million adjustment to step up the inventory balance to fair value consistent with the purchase price allocation. The fair value was determined based on the estimated selling price of the inventory, less the remaining manufacturing and selling cost and a normal profit margin on those manufacturing and selling efforts. The inventory step up adjustment increased cost of revenue $0.3 million in the three month period ended  September 30, 2024 as the inventory was sold.

[0001437749-24-032618:notes:25]
Backlog of $0.7 million was evaluated using the multi period excess earnings method under the income approach. The contracts with customers do not provide for any guarantees to source all future requirements from the Company. The amortization method being utilized is economic consumption estimated over an eight-month period with the expense being allocated to cost of revenues.

[0001437749-24-032618:notes:26]
Customer relationships of $1.3 million relates to customers currently under contract and was determined based on a multi period excess earnings method under the income approach. The method of amortization being utilized is straight line over 10 years, as the results were not materially different from the economic consumption method, with the expense being allocated to SG&A.

[0001437749-24-032618:notes:27]
Goodwill represents the value associated with the acquired workforce and expected synergies related to the business combination of the two companies. Goodwill resulting from the Acquisition was assigned to the Company’s Grid segment. Goodwill recognized in the Acquisition is not deductible for tax purposes. This purchase price allocation is preliminary and has not been finalized as the analysis on the assets and liabilities acquired, primarily the tax related liability  may require further adjustments to our purchase accounting that could result in a measurement period adjustment that would impact the Company's reported net assets and goodwill as of  August 1, 2024. Material changes, if any, to the preliminary allocation summarized above will be reported once the related uncertainties are resolved, but no later than  August 1, 2025. The $6.4 million of deferred tax liability is primarily related to basis difference of property, plant, and equipment.

[0001437749-24-032618:notes:28]
Unaudited Pro Forma Operating Results

[0001437749-24-032618:notes:29]
The unaudited pro forma condensed consolidated statement of operations for the three and six months ended  September 30, 2024 and 2023 presented as if the Acquisition had occurred on  April 1, 2024 and 2023, respectively, is as follows:

[0001437749-24-032618:notes:30]
|  |  | Three Months Ended September 30, |  |  | Six Months Ended September 30, |  |
|  |  | 2024 |  |  | 2023 |  |  | 2024 |  |  | 2023 |  |
| Net Revenue |  | $ | 58,722 |  |  | $ | 50,929 |  |  | $ | 118,032 |  |  | $ | 99,915 |  |
| Operating income (loss) |  |  | 81 |  |  |  | (1,783 | ) |  |  | (4,079 | ) |  |  | (7,193 | ) |
| Net income (loss) |  | $ | 635 |  |  | $ | (311 | ) |  | $ | (2,748 | ) |  | $ | (633 | ) |
| Net income (loss) per common share |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.02 |  |  | $ | (0.01 | ) |  | $ | (0.07 | ) |  | $ | (0.02 | ) |
| Diluted |  | $ | 0.02 |  |  | $ | (0.01 | ) |  | $ | (0.07 | ) |  | $ | (0.02 | ) |
| Shares - basic |  |  | 37,404 |  |  |  | 30,126 |  |  |  | 37,189 |  |  |  | 29,843 |  |
| Shares - diluted |  |  | 37,950 |  |  |  | 30,126 |  |  |  | 37,189 |  |  |  | 29,843 |  |

[0001437749-24-032618:notes:31]
The pro forma amounts include the historical operating results of the Company and Megatran with appropriate adjustments that give effect to acquisition related costs, income taxes, intangible amortization resulting from the Acquisition and certain conforming accounting policies of the Company. The pro forma amounts are not necessarily indicative of the operating results that would have occurred if the Acquisition and related transactions had been completed at the beginning of the applicable periods presented. In addition, the pro forma amounts are not necessarily indicative of operating results in future periods.

[0001437749-24-032618:notes:32]
In the unaudited consolidated results for the three and six months ended  September 30, 2024, Megatran’s operations are included in the Company’s consolidated results from the date of Acquisition of  August 1, 2024. Megatran contributed $14.3 million of revenue and $2.1 million in net income for the Company for the three and six month periods ended  September 30, 2024.  Amortization expense of $0.2 million is included in the three and six months ended  September 30, 2024, as a result of the Megatran acquired intangible assets.  In addition, $0.3 million for the step-up basis assigned to acquired inventory was charged to cost of revenues in the three and six months ended  September 30, 2024.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001437749-24-032618:notes:33]
3. Revenue Recognition

[0001437749-24-032618:notes:34]
The Company’s revenues in its Grid segment are derived primarily through enabling the transmission and distribution of power, providing planning services that allow it to identify power grid needs and risks, and developing ship protection systems for the U.S. Navy. The Company’s revenues in its Wind segment are derived primarily through supplying advanced power electronics and control systems, licensing its highly engineered wind turbine designs, and providing extensive customer support services to wind turbine manufacturers. The Company records revenue based on a five-step model in accordance with Accounting Standards Codification ("ASC") 606. For its customer contracts, the Company identifies the performance obligations, determines the transaction price, allocates the contract transaction price to the performance obligations, and recognizes the revenue when (or as) control of goods or services is transferred to the customer. For the three and six months ended  September 30, 2024, 90% and 89% of revenue, respectively, was recognized at the point in time when control transferred to the customer, with the remainder being recognized over time. For the three and six months ended  September 30, 2023, 79% and 78% of revenue, respectively, was recognized at the point in time when control transferred to the customer, with the remainder being recognized over time.

[0001437749-24-032618:notes:35]
[same as prior period, unchanged from 0001437749-24-024886:notes:14]

[0001437749-24-032618:notes:36]
[same as prior period, unchanged from 0001437749-24-024886:notes:15]

[0001437749-24-032618:notes:37]
[same as prior period, unchanged from 0001437749-24-024886:notes:16]

[0001437749-24-032618:notes:38]
[same as prior period, unchanged from 0001437749-24-024886:notes:17]

[0001437749-24-032618:notes:39]
[same as prior period, unchanged from 0001437749-24-024886:notes:18]

[0001437749-24-032618:notes:40]
The Company records revenue net of sales tax, value added tax, excise tax and other taxes collected concurrent with revenue-producing activities. The Company has elected to recognize the cost for freight and shipping when control over the products sold passes to customers and revenue is recognized. The Company has elected to recognize incremental costs of obtaining a contract as expense when incurred except in contracts where the amortization period would exceed twelve months. As of  September 30, 2024 and  March 31, 2024, the Company's capitalized incremental contract costs were not material. The Company has elected not to adjust the promised amount of consideration for the effects of a significant financing component if the period of financing is twelve months or less.  The Company has elected to recognize revenue based on the as invoiced practical expedient if there is a right to consideration from a customer in an amount that corresponds directly with the value of the Company's performance.

[0001437749-24-032618:notes:41]
[same as prior period, unchanged from 0001437749-24-024886:notes:20]

[0001437749-24-032618:notes:42]
[same as prior period, unchanged from 0001437749-24-024886:notes:21]

[0001437749-24-032618:notes:43]
|  |  | Three Months Ended September 30, 2024 |  |  | Six Months Ended September 30, 2024 |  |
| Product Line: |  | Grid |  |  | Wind |  |  | Grid |  |  | Wind |  |
| Equipment and systems |  | $ | 43,747 |  |  | $ | 7,166 |  |  | $ | 74,452 |  |  | $ | 14,591 |  |
| Services and technology development |  |  | 3,189 |  |  |  | 369 |  |  |  | 4,820 |  |  |  | 898 |  |
| Total |  | $ | 46,936 |  |  | $ | 7,535 |  |  | $ | 79,272 |  |  | $ | 15,489 |  |
| Region: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas |  | $ | 43,479 |  |  | $ | 1 |  |  | $ | 73,957 |  |  | $ | 1 |  |
| Asia Pacific |  |  | 790 |  |  |  | 7,531 |  |  |  | 1,989 |  |  |  | 15,483 |  |
| EMEA |  |  | 2,667 |  |  |  | 3 |  |  |  | 3,326 |  |  |  | 5 |  |
| Total |  | $ | 46,936 |  |  | $ | 7,535 |  |  | $ | 79,272 |  |  | $ | 15,489 |  |

[0001437749-24-032618:notes:44]
|  |  | Three Months Ended September 30, 2023 |  |  | Six Months Ended September 30, 2023 |  |
| Product Line: |  | Grid |  |  | Wind |  |  | Grid |  |  | Wind |  |
| Equipment and systems |  | $ | 22,682 |  |  | $ | 4,879 |  |  | $ | 45,808 |  |  | $ | 8,862 |  |
| Services and technology development |  |  | 5,833 |  |  |  | 610 |  |  |  | 8,443 |  |  |  | 1,145 |  |
| Total |  | $ | 28,515 |  |  | $ | 5,489 |  |  | $ | 54,251 |  |  | $ | 10,007 |  |
| Region: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas |  | $ | 24,696 |  |  | $ | 27 |  |  | $ | 47,856 |  |  | $ | 57 |  |
| Asia Pacific |  |  | 3,418 |  |  |  | 5,462 |  |  |  | 5,129 |  |  |  | 9,928 |  |
| EMEA |  |  | 401 |  |  |  | - |  |  |  | 1,266 |  |  |  | 22 |  |
| Total |  | $ | 28,515 |  |  | $ | 5,489 |  |  | $ | 54,251 |  |  | $ | 10,007 |  |

[0001437749-24-032618:notes:45]
As of  September 30, 2024 and 2023, the Company’s contract assets and liabilities primarily relate to the timing differences between cash received from a customer in connection with contractual rights to invoicing and the timing of revenue recognition following completion of performance obligations. The Company's accounts receivable balance is made up entirely of customer contract related balances. Changes in the Company’s contract assets, which are included in “Unbilled accounts receivable” and “Deferred program costs” (see Note 8, “Accounts Receivable” and Note 9, “Inventory” for a reconciliation to the condensed consolidated balance sheets) and "Contract liabilities", which are included in the current portion and long-term portion of "Deferred revenue" in the Company’s condensed consolidated balance sheets, are as follows (in thousands):

[0001437749-24-032618:notes:46]
|  |  | Unbilled Accounts Receivable |  |  | Deferred Program Costs |  |  | Contract Liabilities |  |
| Beginning balance as of March 31, 2024 |  | $ | 6,150 |  |  | $ | 2,523 |  |  | $ | 57,829 |  |
| Increase for balance acquired |  |  | — |  |  |  | — |  |  |  | 5,049 |  |
| Increases for costs incurred to fulfill performance obligations |  |  | — |  |  |  | 4,866 |  |  |  | — |  |
| Increase (decrease) due to customer billings |  |  | (6,241 | ) |  |  | — |  |  |  | 70,133 |  |
| Decrease due to cost recognition on completed performance obligations |  |  | — |  |  |  | (2,553 | ) |  |  | — |  |
| Increase (decrease) due to recognition of revenue based on transfer of control of performance obligations |  |  | 4,607 |  |  |  | — |  |  |  | (52,084 | ) |
| Other changes and FX impact |  |  | 7 |  |  |  | 12 |  |  |  | 344 |  |
| Ending balance as of September 30, 2024 |  | $ | 4,523 |  |  | $ | 4,848 |  |  | $ | 81,271 |  |

[0001437749-24-032618:notes:47]
|  |  | Unbilled Accounts Receivable |  |  | Deferred Program Costs |  |  | Contract Liabilities |  |
| Beginning balance as of March 31, 2023 |  | $ | 9,958 |  |  | $ | 2,136 |  |  | $ | 50,760 |  |
| Increases for costs incurred to fulfill performance obligations |  |  | — |  |  |  | 2,110 |  |  |  | — |  |
| Increase (decrease) due to customer billings |  |  | (13,981 | ) |  |  | — |  |  |  | 34,284 |  |
| Decrease due to cost recognition on completed performance obligations |  |  | — |  |  |  | (2,160 | ) |  |  | — |  |
| Increase (decrease) due to recognition of revenue based on transfer of control of performance obligations |  |  | 10,351 |  |  |  | — |  |  |  | (25,710 | ) |
| Other changes and FX impact |  |  | 7 |  |  |  | (11 | ) |  |  | (288 | ) |
| Ending balance as of September 30, 2023 |  | $ | 6,335 |  |  | $ | 2,075 |  |  | $ | 59,046 |  |

[0001437749-24-032618:notes:48]
The Company’s remaining performance obligations represent the unrecognized revenue value of the Company’s contractual commitments. The Company’s performance obligations  may vary significantly each reporting period based on the timing of major new contractual commitments. As of  September 30, 2024, the Company had outstanding performance obligations on existing contracts under ASC 606 to be recognized in the next twelve months of approximately $205.0 million. There are also approximately $102.3 million of outstanding performance obligations to be recognized over a period of thirteen to sixty months. The remaining performance obligations are subject to customer actions and therefore the timing of revenue recognition cannot be reasonably estimated.

[0001437749-24-032618:notes:49]
The following table sets forth customers who represented 10% or more of the Company’s total revenues for the three and six months ended  September 30, 2024 and 2023:

[0001437749-24-032618:notes:50]
|  |  |  | Three Months Ended |  |  | Six Months Ended |  |
|  | Reportable |  | September 30, |  |  | September 30, |  |
|  | Segment |  | 2024 |  |  | 2023 |  |  | 2024 |  |  | 2023 |  |
| Inox Wind Limited | Wind |  |  | 12 | % |  |  | 12 | % |  |  | 14 | % |  |  | 12 | % |
| Gray Construction, Inc. | Grid |  |  | <10% |  |  |  | 11 | % |  |  | <10% |  |  |  | <10% |  |


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001437749-24-032618:notes:51]
4. Stock-Based Compensation

[0001437749-24-032618:notes:52]
The Company accounts for its stock-based compensation at fair value. The following table summarizes stock-based compensation expense by financial statement line item for the three and six months ended  September 30, 2024 and 2023 (in thousands):

[0001437749-24-032618:notes:53]
|  |  | Three Months Ended September 30, |  |  | Six Months Ended September 30, |  |
|  |  | 2024 |  |  | 2023 |  |  | 2024 |  |  | 2023 |  |
| Cost of revenues |  | $ | 39 |  |  | $ | 59 |  |  | $ | 97 |  |  | $ | 169 |  |
| Research and development |  |  | 113 |  |  |  | 156 |  |  |  | 256 |  |  |  | 311 |  |
| Selling, general and administrative |  |  | 691 |  |  |  | 896 |  |  |  | 1,719 |  |  |  | 1,988 |  |
| Total |  | $ | 843 |  |  | $ | 1,111 |  |  | $ | 2,072 |  |  | $ | 2,468 |  |

[0001437749-24-032618:notes:54]
The Company issued 817,500 shares and 842,500 shares of restricted stock during the three and six months ended  September 30, 2024, respectively. The Company issued no shares and 19,200 shares of immediately vested common stock during the three and six months ended  September 30, 2024, respectively. The Company issued 9,000 shares and 681,500 shares of restricted stock during the three and six months ended  September 30, 2023, respectively. No shares of immediately vested common stock were issued during the three months ended  September 30, 2023 and 53,675 shares of immediately vested common stock during the six months ended  September 30, 2023. These restricted stock awards generally vest over 2-3 years. Awards for restricted stock include both time-based and performance-based awards. For options and restricted stock awards that vest upon the passage of time, expense is being recorded over the vesting period. Performance-based awards are expensed over the requisite service period based on probability of achievement.

[0001437749-24-032618:notes:55]
The estimated fair value of the Company’s stock-based awards, less expected annual forfeitures, is amortized over the awards’ service period. There were no unrecognized compensation costs for unvested stock options as of  September 30, 2024. The total unrecognized compensation cost for unvested outstanding restricted stock was $17.8 million as of  September 30, 2024. This expense will be recognized over a weighted-average expense period of approximately 1.8 years.

[0001437749-24-032618:notes:56]
The Company granted no stock options during the three and six months ended  September 30, 2024 and 2023.


## us-gaap:EarningsPerShareTextBlock

[0001437749-24-032618:notes:57]
5. Computation of Net Income (Loss) per Common Share

[0001437749-24-032618:notes:58]
Basic net income (loss) per share (“EPS”) is computed by dividing net income (loss) by the weighted-average number of common shares outstanding for the period. Where applicable, diluted EPS is computed by dividing the net income by the weighted-average number of common shares and dilutive common equivalent shares outstanding during the period, calculated using the treasury stock method. Common equivalent shares include the effect of restricted stock, exercise of stock options and warrants and contingently issuable shares. Stock options and warrants that are out-of-the-money with exercise prices greater than the average market price of the underlying common shares and shares of performance-based restricted stock where the contingency was not met are excluded from the computation of diluted EPS as the effect of their inclusion would be anti-dilutive. For the three months ended  September 30, 2024, 535,001 shares were not included in the calculation of diluted EPS. Of these, 526,333 were shares of performance-based restricted stock where the contingency was not met. Of the remaining shares, 652 shares relate to outstanding stock awards that were considered anti-dilutive, and 8,016 shares related to ESPP shares and were excluded as they were considered anti-dilutive. For the six months ended  September 30, 2024, 479,341 shares were not included in the calculation of diluted EPS. Of these, 469,667 were shares of performance-based restricted stock where the contingency was not met. Of the remaining shares, 326 shares relate to outstanding stock awards that were considered anti-dilutive, and 9,348 shares related to ESPP shares and were excluded as they were considered anti-dilutive. For each of the three and six months ended  September 30, 2023, 1,036,206 shares were not included in the calculation of diluted EPS. Of these, 1,000,000 relate to shares associated with the contingent consideration derivative liability for which the contingency has not yet been met, and 36,206 relate to outstanding stock options as they were considered anti-dilutive.

[0001437749-24-032618:notes:59]
The following table reconciles the numerators and denominators of the earnings per share calculation for the three and six months ended  September 30, 2024 and 2023 (in thousands, except per share data):

[0001437749-24-032618:notes:60]
|  |  | Three Months Ended September 30, |  |  | Six Months Ended September 30, |  |
|  |  | 2024 |  |  | 2023 |  |  | 2024 |  |  | 2023 |  |
| Numerator: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income (loss) |  | $ | 4,887 |  |  | $ | (2,485 | ) |  | $ | 2,363 |  |  | $ | (7,883 | ) |
| Denominator: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Weighted-average shares of common stock outstanding |  |  | 37,931 |  |  |  | 30,283 |  |  |  | 37,463 |  |  |  | 29,996 |  |
| Weighted-average shares subject to repurchase |  |  | (979 | ) |  |  | (1,455 | ) |  |  | (1,146 | ) |  |  | (1,451 | ) |
| Shares used in per-share calculation ― basic |  |  | 36,952 |  |  |  | 28,828 |  |  |  | 36,317 |  |  |  | 28,545 |  |
| Shares used in per-share calculation ― diluted |  |  | 37,499 |  |  |  | 28,828 |  |  |  | 36,951 |  |  |  | 28,545 |  |
| Net income (loss) per share ― basic |  | $ | 0.13 |  |  | $ | (0.09 | ) |  | $ | 0.07 |  |  | $ | (0.28 | ) |
| Net income (loss) per share ― diluted |  | $ | 0.13 |  |  | $ | (0.09 | ) |  | $ | 0.06 |  |  | $ | (0.28 | ) |


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001437749-24-032618:notes:61]
6. Goodwill and Other Intangibles

[0001437749-24-032618:notes:62]
[same as prior period, unchanged from 0001437749-24-024886:notes:41]

[0001437749-24-032618:notes:63]
Goodwill represents the difference between the purchase price and the fair value of the identifiable tangible and intangible net assets when accounted for using the purchase method of accounting. Goodwill is not amortized but reviewed for impairment. The Company's goodwill balance relates to the Megatran Acquisition in fiscal 2024, the Neeltran acquisition in fiscal 2021, the Northeast Power Systems, Inc. ("NEPSI") acquisition in fiscal 2020, and the acquisition of Infinia Technology Corporation in fiscal 2017 and is reported in the Grid business segment. Goodwill is reviewed annually on  February 28th and whenever events or changes in circumstances indicate that the carrying value of the goodwill might not be recoverable. There were no changes to goodwill during the year ended  March 31, 2024.

[0001437749-24-032618:notes:64]
|  |  | Goodwill |  |
| March 31, 2024 |  | $ | 43,471 |  |
| Megatran Acquisition |  |  | 5,479 |  |
| September 30, 2024 |  | $ | 48,950 |  |

[0001437749-24-032618:notes:65]
The Company did not record impairment in the three and six months ended  September 30, 2024 that would require interim impairment testing of goodwill.

[0001437749-24-032618:notes:66]
[same as prior period, unchanged from 0001437749-24-024886:notes:45]

[0001437749-24-032618:notes:67]
Intangible assets at  September 30, 2024 and  March 31, 2024 consisted of the following (in thousands):

[0001437749-24-032618:notes:68]
|  |  | September 30, 2024 |  |  | March 31, 2024 |  |  |  |  |  |
|  |  | Gross Amount |  |  | Accumulated Amortization |  |  | Net Book Value |  |  | Gross Amount |  |  | Accumulated Amortization |  |  | Net Book Value |  |  | Estimated Useful Life |  |
| Backlog |  |  | 1,381 |  |  |  | (856 | ) |  |  | 525 |  |  |  | 681 |  |  |  | (681 | ) |  |  | — |  |  |  | 2 |  |
| Trade name and trademarks |  |  | 1,800 |  |  |  | — |  |  |  | 1,800 |  |  |  | 1,800 |  |  |  | — |  |  |  | 1,800 |  |  | Indefinite |  |
| Customer relationships |  |  | 10,880 |  |  |  | (7,253 | ) |  |  | 3,627 |  |  |  | 9,600 |  |  |  | (6,649 | ) |  |  | 2,951 |  |  |  | 7-10 |  |
| Core technology and know-how |  |  | 5,970 |  |  |  | (4,593 | ) |  |  | 1,377 |  |  |  | 5,970 |  |  |  | (4,352 | ) |  |  | 1,618 |  |  |  | 5-10 |  |
| Intangible assets |  | $ | 20,031 |  |  | $ | (12,702 | ) |  | $ | 7,329 |  |  | $ | 18,051 |  |  | $ | (11,682 | ) |  | $ | 6,369 |  |  |  |  |  |

[0001437749-24-032618:notes:69]
The Company recorded intangible amortization expense related to customer relationship and core technology and know-how of $0.4 million and $0.8 million in the three and six months ended  September 30, 2024, respectively. The Company recorded intangible amortization expense related to customer relationship and core technology and know-how of $0.5 million and $1.1 million in the three and six months ended  September 30, 2023, respectively. The Company recorded $0.2 million of intangible amortization in cost of revenue related to backlog during both the three and six  months ended  September 30, 2024. The Company recorded no amortization expense related to backlog during the three months ended  September 30, 2023 and less than $0.1 million related to backlog was reported in cost of revenues during the six months ended  September 30, 2023.

[0001437749-24-032618:notes:70]
[same as prior period, unchanged from 0001437749-24-024886:notes:49]

[0001437749-24-032618:notes:71]
| Years ending March 31, |  | Total |  |
| 2025 |  |  | 1,413 |  |
| 2026 |  |  | 1,349 |  |
| 2027 |  |  | 1,213 |  |
| 2028 |  |  | 671 |  |
| 2029 |  |  | 201 |  |
| Thereafter |  |  | 682 |  |
| Total |  | $ | 5,529 |  |

[0001437749-24-032618:notes:72]
[same as prior period, unchanged from 0001437749-24-024886:notes:51]


## us-gaap:FairValueDisclosuresTextBlock

[0001437749-24-032618:notes:73]
7. Fair Value Measurements

[0001437749-24-032618:notes:74]
[same as prior period, unchanged from 0001437749-24-024886:notes:53]

[0001437749-24-032618:notes:75]
[same as prior period, unchanged from 0001437749-24-024886:notes:54]

[0001437749-24-032618:notes:76]
The Company provides a gross presentation of activity within Level 3 measurement roll-forward and details of transfers in and out of Level 1 and 2 measurements. A change in the hierarchy of an investment from its current level is reflected in the period during which the pricing methodology of such investment changes. Disclosure of the transfer of securities from Level 1 to Level 2 or Level 3 is made in the event that the related security is significant to total cash and investments. The Company did not have any transfers of assets and liabilities from Level 1, Level 2 or Level 3 of the fair value measurement hierarchy during the six months ended  September 30, 2024.

[0001437749-24-032618:notes:77]
[same as prior period, unchanged from 0001437749-24-024886:notes:56]

[0001437749-24-032618:notes:78]
[same as prior period, unchanged from 0001437749-24-024886:notes:57]

[0001437749-24-032618:notes:79]
[same as prior period, unchanged from 0001437749-24-024886:notes:58]

[0001437749-24-032618:notes:80]
[same as prior period, unchanged from 0001437749-24-024886:notes:59]

[0001437749-24-032618:notes:81]
[same as prior period, unchanged from 0001437749-24-024886:notes:60]

[0001437749-24-032618:notes:82]
Contingent consideration related to the earnout payment set forth in the NEPSI Stock Purchase Agreement governing the acquisition of NEPSI provided that the selling stockholders  may have received up to an additional 1,000,000 shares of common stock of the Company upon the achievement of certain specified revenue objectives over varying periods of up to four years following the NEPSI acquisition date which must have occurred by  September 30, 2024. Contingent consideration related to the make whole payment set forth in the Megatran Stock Purchase Agreement provided that the selling stockholders would be made whole for any costs or taxes as a result of the orderly distribution process. See Note 15, "Contingent Consideration" for further discussion. As of  September 30, 2024, the Company has settled all outstanding contingent consideration.

[0001437749-24-032618:notes:83]
The following table provides the assets and liabilities carried at fair value on a recurring basis, measured as of  September 30, 2024 and  March 31, 2024 (in thousands):

[0001437749-24-032618:notes:84]
|  |  | Total Carrying Value |  |  | Quoted Prices in Active Markets (Level 1) |  |  | Significant Other Observable Inputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |
| September 30, 2024: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash equivalents |  | $ | 41,731 |  |  | $ | 41,731 |  |  | $ | — |  |  | $ | — |  |

[0001437749-24-032618:notes:85]
[same as prior period, unchanged from 0001437749-24-024886:notes:64]

[0001437749-24-032618:notes:86]
[same as prior period, unchanged from 0001437749-24-024886:notes:65]

[0001437749-24-032618:notes:87]
|  |  | NEPSI Acquisition Contingent Consideration |  |  | Megatran Acquisition Contingent Consideration |  |
| Balance at March 31, 2023 |  | $ | 1,270 |  |  | $ | — |  |
| Change in fair value |  |  | 4,922 |  |  |  | — |  |
| Settlement of contingent consideration |  |  | (3,092 | ) |  |  | — |  |
| Balance at March 31, 2024 |  |  | 3,100 |  |  |  | — |  |
| Change in fair value |  |  | 3,404 |  |  |  | 3,278 |  |
| Settlement of contingent consideration |  |  | (6,504 | ) |  |  | (3,278 | ) |
| Balance at September 30, 2024 |  | $ | — |  |  | $ | — |  |


## amsc:AccountsReceivableTextBlock

[0001437749-24-032618:notes:88]
8. Accounts Receivable

[0001437749-24-032618:notes:89]
Accounts receivable at  September 30, 2024 and  March 31, 2024 consisted of the following (in thousands):

[0001437749-24-032618:notes:90]
|  |  | September 30, 2024 |  |  | March 31, 2024 |  |
| Accounts receivable (billed) |  |  | 35,536 |  |  | $ | 20,175 |  |
| Accounts receivable (unbilled) |  |  | 4,523 |  |  |  | 6,150 |  |
| Accounts receivable |  | $ | 40,059 |  |  | $ | 26,325 |  |


## us-gaap:InventoryDisclosureTextBlock

[0001437749-24-032618:notes:91]
9. Inventory

[0001437749-24-032618:notes:92]
Inventory, net of reserves, at  September 30, 2024 and  March 31, 2024 consisted of the following (in thousands):

[0001437749-24-032618:notes:93]
|  |  | September 30, 2024 |  |  | March 31, 2024 |  |
| Raw materials |  | $ | 37,336 |  |  | $ | 20,622 |  |
| Work-in-process |  |  | 23,819 |  |  |  | 14,872 |  |
| Finished goods |  |  | 4,877 |  |  |  | 3,840 |  |
| Deferred program costs |  |  | 4,848 |  |  |  | 2,523 |  |
| Net inventory |  | $ | 70,880 |  |  | $ | 41,857 |  |

[0001437749-24-032618:notes:94]
The Company recorded inventory write-downs of $0.3 million and $0.7 million for the three months ended  September 30, 2024 and 2023, respectively. The Company recorded inventory write-downs of $0.8 million and $1.1 million for the six months ended  September 30, 2024 and 2023, respectively. These write-downs were based on the Company's evaluation of its inventory on hand for excess quantities and obsolescence.

[0001437749-24-032618:notes:95]
Deferred program costs as of  September 30, 2024 and  March 31, 2024 primarily represent costs incurred on programs where the Company needs to complete performance obligations before the related revenue and costs will be recognized.


## amsc:PrepaidAndOtherCurrentAssetsTextBlock

[0001437749-24-032618:notes:96]
10. Prepaid and Other Current Assets

[0001437749-24-032618:notes:97]
During fiscal 2022, the Company conducted an analysis as to whether it was entitled to employee retention credits (“ERC”) under the CARES Act as amended by the Taxpayer Certainty and Disaster Tax Relief Act of 2020 and the American Rescue Plan Act of 2021.  Based on the analysis, the Company determined that it was entitled to an ERC of approximately $3.3 million related to payroll taxes paid in the first and second quarters of 2021 and the first quarter of 2020. The Company determined it met all the criteria required under the gross receipts test of the applicable Internal Revenue Service regulations related to ERCs.

[0001437749-24-032618:notes:98]
[same as prior period, unchanged from 0001437749-24-024886:notes:77]

[0001437749-24-032618:notes:99]
The Company recorded a $3.3 million receivable in prepaid expenses and other current assets and a benefit of $1.8 million to cost of revenues, $0.8 million to selling, general, and administrative and $0.7 million to research and development in the fiscal year ended  March 31, 2023 for the ERC that was expected to be received based on the amended filings. During the year ended  March 31, 2024, the Company received $3.0 million for the initial claims that were processed. During the six months ended  September 30, 2024, the Company did not receive any cash for the remaining $0.3 million balance of initial claims that were processed. The remaining balance is expected to be received during the remainder of fiscal 2024.


## us-gaap:PropertyPlantAndEquipmentDisclosureTextBlock

[0001437749-24-032618:notes:100]
11. Property, Plant and Equipment

[0001437749-24-032618:notes:101]
The cost and accumulated depreciation of property, plant and equipment at  September 30, 2024 and  March 31, 2024 are as follows (in thousands):

[0001437749-24-032618:notes:102]
|  |  | September 30, 2024 |  |  | March 31, 2024 |  |
| Land |  | $ | 22,650 |  |  | $ | 980 |  |
| Construction in progress – equipment |  |  | 851 |  |  |  | 226 |  |
| Buildings |  |  | 7,445 |  |  |  | 5,416 |  |
| Equipment and software |  |  | 47,766 |  |  |  | 44,095 |  |
| Furniture and fixtures |  |  | 1,635 |  |  |  | 1,526 |  |
| Leasehold improvements |  |  | 7,813 |  |  |  | 6,990 |  |
| Property, plant and equipment, gross |  |  | 88,160 |  |  |  | 59,233 |  |
| Less accumulated depreciation |  |  | (49,395 | ) |  |  | (48,372 | ) |
| Property, plant and equipment, net |  | $ | 38,765 |  |  | $ | 10,861 |  |

[0001437749-24-032618:notes:103]
Depreciation expense was $0.8 million and $0.6 million for the three months ended  September 30, 2024 and 2023, respectively. Depreciation expense was $1.4 million and $1.2 million for the six months ended  September 30, 2024 and 2023, respectively. The increase in land relates to the property added as part of the Megatran Acquisition.


## us-gaap:EquityMethodInvestmentsDisclosureTextBlock

[0001437749-24-032618:notes:104]
12. Equity-Method Investments

[0001437749-24-032618:notes:105]
Investment in NWL Pacific Inc. Co., LTD

[0001437749-24-032618:notes:106]
The Company has a 50% ownership in NWL Pacific Inc. Co., LTD ("NWL Pacific"). The investment represents the Company's interest in NWL Pacific. The investment is a joint venture in South Korea established on  May 12, 1998.

[0001437749-24-032618:notes:107]
The Company treats the equity investment in the condensed consolidated financial statements under the equity method. Equity method investments are equity securities in entities the Company does not control but over which it has the ability to exercise significant influence. These investments are accounted for under the equity method of accounting in accordance with ASC 323, Investments — Equity Method and Joint Ventures. Equity method investments are measured at cost minus impairment, if any, plus or minus the Company’s share of an investee’s income or loss, less distributions received. As of  September 30, 2024 the Company did not have material accounts receivable nor accounts payable balances with NWL Pacific.

[0001437749-24-032618:notes:108]
The tables below present the summarized financial information from the date of acquisition through  September 30, 2024, as provided to the Company by the investee, for the unconsolidated company (in thousands):

[0001437749-24-032618:notes:109]
|  |  | 2024 |  |
| Net Revenue |  | $ | 857 |  |
| Gross Profit |  |  | 308 |  |
| Income from operation |  |  | 157 |  |
| Net income |  | $ | 148 |  |


## us-gaap:AccountsPayableAndAccruedLiabilitiesDisclosureTextBlock

[0001437749-24-032618:notes:110]
13. Accounts Payable and Accrued Expenses

[0001437749-24-032618:notes:111]
Accounts payable and accrued expenses at  September 30, 2024 and  March 31, 2024 consisted of the following (in thousands):

[0001437749-24-032618:notes:112]
|  |  | September 30, 2024 |  |  | March 31, 2024 |  |
| Accounts payable |  | $ | 3,831 |  |  | $ | 4,476 |  |
| Accrued inventories in-transit |  |  | 2,587 |  |  |  | 539 |  |
| Accrued other miscellaneous expenses |  |  | 3,983 |  |  |  | 2,366 |  |
| Accrued contract loss |  |  | 97 |  |  |  | 97 |  |
| Advanced deposits |  |  | 1,540 |  |  |  | 2,270 |  |
| Accrued compensation |  |  | 8,293 |  |  |  | 10,326 |  |
| Income taxes payable |  |  | 220 |  |  |  | 346 |  |
| Accrued product warranty |  |  | 3,110 |  |  |  | 2,363 |  |
| Accrued commissions |  |  | 1,497 |  |  |  | 1,452 |  |
| Total |  | $ | 25,158 |  |  | $ | 24,235 |  |

[0001437749-24-032618:notes:113]
[same as prior period, unchanged from 0001437749-24-024886:notes:86]

[0001437749-24-032618:notes:114]
[same as prior period, unchanged from 0001437749-24-024886:notes:87]

[0001437749-24-032618:notes:115]
|  |  | Three Months Ended September 30, |  |  | Six Months Ended September 30, |  |
|  |  | 2024 |  |  | 2023 |  |  | 2024 |  |  | 2023 |  |
| Balance at beginning of period |  | $ | 2,542 |  |  | $ | 1,926 |  |  | $ | 2,363 |  |  | $ | 2,638 |  |
| Acquired warranty obligations |  |  | 637 |  |  |  | — |  |  |  | 637 |  |  |  | — |  |
| Provisions for warranties during the period |  |  | 298 |  |  |  | 644 |  |  |  | 774 |  |  |  | 852 |  |
| Settlements during the period |  |  | (367 | ) |  |  | (678 | ) |  |  | (664 | ) |  |  | (1,598 | ) |
| Balance at end of period |  | $ | 3,110 |  |  | $ | 1,892 |  |  | $ | 3,110 |  |  | $ | 1,892 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0001437749-24-032618:notes:116]
14. Income Taxes

[0001437749-24-032618:notes:117]
The Company recorded income tax benefit of $5.0 million and $4.8 million in the three and six months ended  September 30, 2024, respectively, and income tax expense of $0.1 million and $0.2 million in the three and six months ended  September 30, 2023, respectively.

[0001437749-24-032618:notes:118]
As a result of a difference in book and tax basis related to the intangible assets acquired in the Acquisition (see Note 2, "Acquisition"), the Company recorded a deferred tax liability of $6.4 million. As a result, the Company was able to benefit from additional deferred tax assets and therefore released a corresponding valuation allowance of $5.2 million during the three months ended  September 30, 2024. The purchase price allocation is preliminary and has not been finalized as the analysis on the assets and liabilities acquired, primarily the tax related liability,  may require further adjustments to the Company's purchase accounting that could result in measurement period adjustments that would impact the Company's reported net assets and goodwill as of  August 1, 2024. Material changes, if any, to the preliminary allocation summarized in Note 2, "Acquisition" will be reported once the related uncertainties are resolved, but no later than  August 1, 2025.  Goodwill recognized in the Acquisition, is not deductible for tax purposes.

[0001437749-24-032618:notes:119]
Accounting for income taxes requires a two-step approach to recognizing and measuring uncertain tax positions. The first step is to evaluate the tax position for recognition by determining if, based on the technical merits, it is more likely than not the position will be sustained upon audit, including resolution of related appeals or litigation processes, if any. The second step is to measure the tax benefit as the largest amount that is more than 50% likely to be realized upon ultimate settlement. The Company re-evaluates these uncertain tax positions on a quarterly basis. The evaluation is based on factors including, but not limited to, changes in facts or circumstances, changes in tax law, effectively settled issues under audit and new audit activity. Any changes in these factors could result in the recognition of a tax benefit or an additional charge to the tax provision. The Company did not identify any uncertain tax positions in the six months ended  September 30, 2024 and did not have any gross unrecognized tax benefits as of  September 30, 2024.


## amsc:BusinessCombinationContingentConsiderationTextBlock

[0001437749-24-032618:notes:120]
15. Contingent Consideration

[0001437749-24-032618:notes:121]
NEPSI Contingent Considerations

[0001437749-24-032618:notes:122]
On  October 1, 2020 (the "NEPSI Acquisition Date"), the Company entered into a Stock Purchase Agreement (the "NEPSI Stock Purchase Agreement") with the selling stockholders named therein. Pursuant to the terms of the NEPSI Stock Purchase Agreement and concurrently with entering into such agreement, the Company acquired all of the issued and outstanding (i) shares of capital stock of NEPSI, and (ii) membership interests of Northeast Power Realty, LLC, a New York limited liability company, which holds the real property that serves as NEPSI's headquarters (the "NEPSI Acquisition"). NEPSI is a U.S.-based global provider of medium-voltage metal-enclosed power capacitor banks and harmonic filter banks for use on electric power systems. NEPSI is a wholly-owned subsidiary of the Company and is operated by its Grid business unit. The purchase price was $26.0 million in cash and 873,657 restricted shares of common stock of the Company. As part of the transaction, the selling stockholders were entitled to  receive up to an additional 1,000,000 shares of common stock of the Company upon the achievement of certain specified revenue objectives during varying periods of up to four years following closing of the NEPSI Acquisition. During the year ended  March 31, 2024, the Company issued 399,999 shares of common stock and cash in lieu of a fractional share of common stock, related to the achievement of specified revenue objectives in connection with the NEPSI Acquisition. NEPSI recognized revenues in excess of $120.0 million during the four years after the NEPSI Acquisition Date. As a result, during the quarter ended  September 30, 2024, the Company issued 300,000 shares of common stock of the Company to the selling stockholders, following certification of the achievement of the specified earnout revenue objective. As of  September 30, 2024, the Company has settled all outstanding contingent consideration under the NEPSI Stock Purchase Agreement.

[0001437749-24-032618:notes:123]
The Company evaluated the NEPSI Acquisition earnout payment set forth in the NEPSI Stock Purchase Agreement, which was expected to require settlement in the Company's common stock, and determined the contingent consideration qualified for liability classification and derivative treatment under ASC 815, Derivatives and Hedging. As a result, for each period, the fair value of the contingent consideration was remeasured and the resulting gain or loss was recognized in operating expenses until the share amount is fixed.

[0001437749-24-032618:notes:124]
Megatran Contingent Consideration

[0001437749-24-032618:notes:125]
On  August 1, 2024, the Company entered into a Stock Purchase Agreement with the selling stockholders of Megatran named therein. Pursuant to the terms of the Stock Purchase Agreement and concurrently with entering into such agreement, the Company acquired all of the issued and outstanding shares of Megatran for aggregate consideration in an amount equal to $61.4 million which consideration amount was subject to various adjustments set forth in the Stock Purchase Agreement. The value of the contingent consideration to make the sellers whole was determined to be de minimus at the time of the Acquisition. On  September 23, 2024, the Company paid $3.3 million to the selling stockholders, which was calculated based on the agreed upon formula set forth in the Stock Purchase Agreement. This amount is reflected as the change in fair value of this contingent consideration in the three and six months ended  September 30, 2024. As of  September 30, 2024, there are no remaining obligations to the selling stockholders of Megatran. In the three and six months ended  September 30, 2024 the Company completed the payment of $3.3 million to selling stockholders of Megatran to settle the remaining obligations of the acquisition.

[0001437749-24-032618:notes:126]
[same as prior period, unchanged from 0001437749-24-024886:notes:95]

[0001437749-24-032618:notes:127]
|  |  |  | June 30, |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Fiscal Year 2024 |  |  | 2024 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Revenue risk premium |  |  | 5.50 | % |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Revenue volatility |  |  | 27.5 | % |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Stock Price |  | $ | 23.39 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Payment delay (days) |  |  | 80 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Fair value (millions) |  | $ | 7.0 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | March 31, |  |  | December 31, |  |  | September 30, |  |  | June 30, |  |  | March 31, |  |
| Fiscal Year 2023 |  | 2024 |  |  | 2023 |  |  | 2023 |  |  | 2023 |  |  | 2023 |  |
| Revenue risk premium |  |  | 5.50 | % |  |  | 5.70 | % |  |  | 5.30 | % |  |  | 5.20 | % |  |  | 5.30 | % |
| Revenue volatility |  |  | 24.8 | % |  |  | 24.8 | % |  |  | 27.5 | % |  |  | 22.5 | % |  |  | 25 | % |
| Stock Price |  | $ | 13.51 |  |  | $ | 11.14 |  |  | $ | 7.55 |  |  | $ | 6.26 |  |  | $ | 4.91 |  |
| Payment delay (days) |  |  | 80 |  |  |  | 80 |  |  |  | 80 |  |  |  | 80 |  |  |  | 80 |  |
| Fair value (millions) |  | $ | 3.1 |  |  | $ | 1.2 |  |  | $ | 3.5 |  |  | $ | 2.6 |  |  | $ | 1.3 |  |

[0001437749-24-032618:notes:128]
During the three and six months ended  September 30, 2024 the Company issued 300,000 shares of common stock related to the achievement of specified revenue objectives at a fair value of $6.5 million. The Company recorded a gain resulting from the decrease in fair value of $0.5 million and a loss of $3.4 million resulting from the increases in the fair value of the contingent consideration in the three and six months ended  September 30, 2024, respectively. The Company recorded losses of $0.9 million and $2.2 million resulting from the increases in the fair value of the contingent consideration in the three and six months ended  September 30, 2023, respectively.


## us-gaap:DebtDisclosureTextBlock

[0001437749-24-032618:notes:129]
16. Debt

[0001437749-24-032618:notes:130]
As part of the acquisition of Neeltran, the Company identified four equipment financing agreements that Neeltran had entered into prior to the acquisition of Neeltran on  May 6, 2021. The Company did not have a current debt balance as of  September 30, 2024 and had a balance of less than $0.1 million as of  March 31, 2024.


## us-gaap:LesseeOperatingLeasesTextBlock

[0001437749-24-032618:notes:131]
17. Leases

[0001437749-24-032618:notes:132]
[same as prior period, unchanged from 0001437749-24-024886:notes:101]

[0001437749-24-032618:notes:133]
All significant lease arrangements are recognized at lease commencement. Operating lease right–of-use assets and lease liabilities are recognized at commencement. The operating lease right-of-use asset includes any lease payments related to initial direct cost and prepayments and excludes any lease incentives. Lease expense is recognized on a straight-line basis over the lease term.  The Company enters into a variety of operating lease agreements through the normal course of its business, but primarily real estate leases to support its operations. The real estate lease agreements generally provide for fixed minimum rental payments and the payment of real estate taxes and insurance. Many of these real estate leases have one or more renewal options that allow the Company, at its discretion, to renew the lease for varying periods up to five years or to terminate the lease. Only renewal options or termination rights that the Company believed were likely to be exercised were included in the lease calculations.

[0001437749-24-032618:notes:134]
[same as prior period, unchanged from 0001437749-24-024886:notes:103]

[0001437749-24-032618:notes:135]
[same as prior period, unchanged from 0001437749-24-024886:notes:104]

[0001437749-24-032618:notes:136]
As of  September 30, 2024, the right-of-use asset related to the finance lease is fully amortized, and is included in the property and equipment, net on the Company's condensed consolidated balance sheet.

[0001437749-24-032618:notes:137]
[same as prior period, unchanged from 0001437749-24-024886:notes:106]

[0001437749-24-032618:notes:138]
Supplemental balance sheet information related to leases at  September 30, 2024, and  March 31, 2024 are as follows (in thousands):

[0001437749-24-032618:notes:139]
|  |  | September 30, 2024 |  |  | March 31, 2024 |  |
| Leases: |  |  |  |  |  |  |  |  |
| Right-of-use assets – Operating |  | $ | 3,744 |  |  | $ | 2,557 |  |
| Total right-of-use assets |  |  | 3,744 |  |  |  | 2,557 |  |
| Lease liabilities – ST Operating |  | $ | 555 |  |  | $ | 716 |  |
| Lease liabilities – LT Operating |  |  | 2,814 |  |  |  | 1,968 |  |
| Total lease liabilities |  | $ | 3,369 |  |  | $ | 2,684 |  |
| Weighted-average remaining lease term |  |  | 5.33 |  |  |  | 3.49 |  |
| Weighted-average discount rate |  |  | 14.84 | % |  |  | 9.83 | % |

[0001437749-24-032618:notes:140]
The costs related to the Company's finance lease are not material. The costs related to the Company's operating leases for the three and six months ended  September 30, 2024 and 2023 are as follows (in thousands):

[0001437749-24-032618:notes:141]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | September 30, 2024 |  |  | September 30, 2024 |  |
| Operating Leases: |  |  |  |  |  |  |  |  |
| Operating lease costs – fixed |  | $ | 336 |  |  | $ | 645 |  |
| Operating lease costs – variable |  |  | 45 |  |  |  | 91 |  |
| Short-term lease costs |  |  | 39 |  |  |  | 78 |  |
| Total lease costs |  | $ | 420 |  |  | $ | 814 |  |

[0001437749-24-032618:notes:142]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | September 30, 2023 |  |  | September 30, 2023 |  |
| Operating Leases: |  |  |  |  |  |  |  |  |
| Operating lease costs – fixed |  | $ | 255 |  |  | $ | 514 |  |
| Operating lease costs – variable |  |  | 40 |  |  |  | 79 |  |
| Short-term lease costs |  |  | 37 |  |  |  | 74 |  |
| Total lease costs |  | $ | 332 |  |  | $ | 667 |  |

[0001437749-24-032618:notes:143]
[same as prior period, unchanged from 0001437749-24-024886:notes:112]

[0001437749-24-032618:notes:144]
|  |  | Leases |  |
| Year ending March 31, |  |  |  |  |
| 2025 |  | $ | 321 |  |
| 2026 |  |  | 1,113 |  |
| 2027 |  |  | 1,164 |  |
| 2028 |  |  | 805 |  |
| 2029 |  |  | 385 |  |
| Thereafter |  |  | 1,497 |  |
| Total minimum lease payments |  |  | 5,285 |  |
| Less: interest |  |  | (1,916 | ) |
| Present value of lease liabilities |  | $ | 3,369 |  |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001437749-24-032618:notes:145]
18. Commitments and Contingencies

[0001437749-24-032618:notes:146]
Legal Contingencies

[0001437749-24-032618:notes:147]
From time to time, the Company is involved in legal and administrative proceedings and claims of various types. The Company records a liability in its condensed consolidated financial statements for these matters when a loss is known or considered probable and the amount can be reasonably estimated. The Company reviews these estimates each accounting period as additional information is known and adjusts the loss provision when appropriate. If a matter is both probable to result in a liability and the amounts of loss can be reasonably estimated, the Company estimates and discloses the possible loss or range of loss to the extent necessary to make the condensed consolidated financial statements not misleading. If the loss is not probable or cannot be reasonably estimated, a liability is not recorded in its condensed consolidated financial statements.

[0001437749-24-032618:notes:148]
Other

[0001437749-24-032618:notes:149]
The Company enters into long-term construction contracts with customers that require the Company to obtain performance bonds. The Company is required to deposit an amount equivalent to some or all the face amount of the performance bonds into an escrow account until the termination of the bond. When the performance conditions are met, amounts deposited as collateral for the performance bonds are returned to the Company. In addition, the Company has various contractual arrangements in which minimum quantities of goods or services have been committed to be purchased on an annual basis.

[0001437749-24-032618:notes:150]
As of  September 30, 2024, the Company had $1.5 million of restricted cash included in long-term assets and $1.2 million of restricted cash included in current assets. As of  March 31, 2024, the Company had $1.3 million of restricted cash included in long term assets and $0.5 million of restricted cash included in current assets. These amounts included in restricted cash primarily represent deposits to secure letters of credit for various supply contracts and long-term projects or collateral deposits. These deposits are held in interest bearing accounts.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001437749-24-032618:notes:151]
19. Business Segments

[0001437749-24-032618:notes:152]
[same as prior period, unchanged from 0001437749-24-024886:notes:121]

[0001437749-24-032618:notes:153]
[same as prior period, unchanged from 0001437749-24-024886:notes:122]

[0001437749-24-032618:notes:154]
[same as prior period, unchanged from 0001437749-24-024886:notes:123]

[0001437749-24-032618:notes:155]
[same as prior period, unchanged from 0001437749-24-024886:notes:124]

[0001437749-24-032618:notes:156]
|  |  | Three Months Ended September 30, |  |  | Six Months Ended September 30, |  |
|  |  | 2024 |  |  | 2023 |  |  | 2024 |  |  | 2023 |  |
| Revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Grid |  | $ | 46,936 |  |  | $ | 28,515 |  |  | $ | 79,272 |  |  | $ | 54,251 |  |
| Wind |  |  | 7,535 |  |  |  | 5,489 |  |  |  | 15,489 |  |  |  | 10,007 |  |
| Total |  | $ | 54,471 |  |  | $ | 34,004 |  |  | $ | 94,761 |  |  | $ | 64,258 |  |

[0001437749-24-032618:notes:157]
|  |  | Three Months Ended September 30, |  |  | Six Months Ended September 30, |  |
|  |  | 2024 |  |  | 2023 |  |  | 2024 |  |  | 2023 |  |
| Operating income (loss): |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Grid |  | $ | 2,336 |  |  | $ | (679 | ) |  | $ | 3,195 |  |  | $ | (2,649 | ) |
| Wind |  |  | 516 |  |  |  | 252 |  |  |  | 1,515 |  |  |  | (398 | ) |
| Unallocated corporate expenses |  |  | (3,605 | ) |  |  | (1,942 | ) |  |  | (8,753 | ) |  |  | (4,655 | ) |
| Total |  | $ | (753 | ) |  | $ | (2,369 | ) |  | $ | (4,043 | ) |  | $ | (7,702 | ) |

[0001437749-24-032618:notes:158]
[same as prior period, unchanged from 0001437749-24-024886:notes:127]

[0001437749-24-032618:notes:159]
Unallocated corporate expenses consisted of net losses resulting from activity relating to both the NEPSI earnout and the Megatran make whole payment which resulted in $2.8 million and $6.7 million in increases in the fair value of contingent consideration in the three and six months ended  September 30, 2024, respectively. Unallocated corporate expenses consisted of a loss on contingent consideration of $0.9 million and $2.2 million in the three and six months ended  September 30, 2023, respectively. Additionally, unallocated corporate expenses consisted of stock-based compensation expense of $0.8 million and $2.1 million in the three and six months ended  September 30, 2024, respectively, and $1.1 million and $2.5 million in the three and six months ended  September 30, 2023, respectively.

[0001437749-24-032618:notes:160]
Total assets for the two business segments as of  September 30, 2024 and  March 31, 2024, are as follows (in thousands):

[0001437749-24-032618:notes:161]
|  |  | September 30, 2024 |  |  | March 31, 2024 |  |
| Grid |  | $ | 212,985 |  |  | $ | 125,878 |  |
| Wind |  |  | 11,475 |  |  |  | 14,733 |  |
| Corporate assets |  |  | 73,988 |  |  |  | 92,160 |  |
| Total |  | $ | 298,448 |  |  | $ | 232,771 |  |


## us-gaap:NewAccountingPronouncementsAndChangesInAccountingPrinciplesTextBlock

[0001437749-24-032618:notes:162]
20. Recent Accounting Pronouncements

[0001437749-24-032618:notes:163]
In  November 2023, the FASB issued ASU 2023-07, Segment Reporting (Topic 280): Improvements to Reportable Segment Disclosures. The amendments in ASU 2023-07 improve the disclosures about a public entity’s reportable segments and address requests from investors for additional, more detailed information about a reportable segment’s expenses. Following the release of ASU 2023-07 in  November 2023, the effective date will be annual reporting periods beginning after  December 15, 2024. As of  September 30, 2024, the Company is evaluating the impact on its condensed consolidated financial statements.

[0001437749-24-032618:notes:164]
In  December 2023, the FASB issued ASU 2023-09, Income Taxes (Topic 740): Improvements to Income Tax Disclosures. The amendments in ASU 2023-09 address investor requests for more transparency about income tax information through improvements to income tax disclosures primarily related to the rate reconciliation and income taxes paid information. Following the release of ASU 2023-09 in  December 2023, the effective date will be annual reporting periods beginning after  December 15, 2024. As of  September 30, 2024, the Company is evaluating the impact on its condensed consolidated financial statements.

[0001437749-24-032618:notes:165]
In  March 2024, the FASB issued ASU 2024-02, Codification Improvements—Amendments to Remove References to the Concepts Statements. The amendments in ASU 2024-02 contain amendments to the Codification that remove references to various FASB Concepts Statements. Following the release of ASU 2024-02 in  March 2024, the effective date will be annual reporting periods beginning after  December 15, 2024. As of  September 30, 2024, the Company is evaluating the impact on its condensed consolidated financial statements.


## us-gaap:SubsequentEventsTextBlock

[0001437749-24-032618:notes:166]
21. Subsequent Events

[0001437749-24-032618:notes:167]
The Company has performed an evaluation of subsequent events through the time of filing this Quarterly Report on Form 10-Q with the SEC and has determined that there are no such events to report.


## ecd:MtrlTermsOfTrdArrTextBlock

[0001437749-24-032618:notes:168]
[same as prior period, unchanged from 0001437749-24-024886:notes:155]

[0001437749-24-032618:notes:169]
[same as prior period, unchanged from 0001437749-24-024886:notes:156]

[0001437749-24-032618:notes:170]
[same as prior period, unchanged from 0001437749-24-024886:notes:157]

[0001437749-24-032618:notes:171]
(c) During the three months ended  September 30, 2024, no director or officer of the Company adopted or terminated a “Rule 10b5-1 trading arrangement” or “non-Rule 10b5-1 trading arrangement,” as each term is defined in Item 408(a) of Regulation S-K.
