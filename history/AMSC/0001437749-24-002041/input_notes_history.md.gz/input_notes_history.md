# AMSC note change history — 0001437749-23-029753 → 0001437749-24-002041


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2024-01-24):
[0001437749-24-002041:note_history:1]
As of  December 31, 2023, the Company had $0.4 million of restricted cash included in long-term assets and $0.7 million of restricted cash included in current assets. As of  March 31, 2023, the Company had $0.6 million of restricted cash included in long term assets and $1.7 million of restricted cash included in current assets. These amounts included in restricted cash primarily represent deposits to secure letters of credit for various supply contracts and long-term projects or collateral deposits. These deposits are held in interest bearing accounts.
  (was, 2023-11-01, similarity 0.9935):
[0001437749-23-029753:note_history:1]
As of  September 30, 2023, the Company had $0.6 million of restricted cash included in long-term assets and $0.5 million of restricted cash included in current assets. As of  March 31, 2023, the Company had $0.6 million of restricted cash included in long term assets and $1.7 million of restricted cash included in current assets. These amounts included in restricted cash primarily represent deposits to secure letters of credit for various supply contracts and long-term projects or collateral deposits. These deposits are held in interest bearing accounts.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2024-01-24):
[0001437749-24-002041:note_history:2]
These unaudited condensed consolidated financial statements of the Company have been prepared on a going concern basis in accordance with United States generally accepted accounting principles (“GAAP”) and the Securities and Exchange Commission’s (“SEC”) instructions to Form 10-Q. Certain prior period amounts were reclassified to conform to the presentation in the current period. The going concern basis of presentation assumes that the Company will continue operations and will be able to realize its assets and discharge its liabilities and commitments in the normal course of business. Certain information and footnote disclosures normally included in the financial statements prepared in accordance with GAAP have been condensed or omitted pursuant to those instructions. The year-end condensed balance sheet data was derived from audited financial statements but does not include all disclosures required by GAAP. The unaudited condensed consolidated financial statements, in the opinion of management, reflect all adjustments (consisting of normal recurring adjustments) necessary for a fair statement of the results for the interim periods ended  December 31, 2023 and 2022 and the financial position at  December 31, 2023; however, these results are not necessarily indicative of results which  may be expected for the full year. The interim condensed consolidated financial statements, and notes thereto, should be read in conjunction with the audited consolidated financial statements for the year ended  March 31, 2023, and notes thereto, included in the Company’s Annual Report on Form 10-K for the year ended  March 31, 2023 filed with the SEC on  May 31, 2023.
  (was, 2023-11-01, similarity 0.9638):
[0001437749-23-029753:note_history:2]
These unaudited condensed consolidated financial statements of the Company have been prepared on a going concern basis in accordance with United States generally accepted accounting principles (“GAAP”) and the Securities and Exchange Commission’s (“SEC”) instructions to Form 10-Q. The going concern basis of presentation assumes that the Company will continue operations and will be able to realize its assets and discharge its liabilities and commitments in the normal course of business. Certain information and footnote disclosures normally included in the financial statements prepared in accordance with GAAP have been condensed or omitted pursuant to those instructions. The year-end condensed balance sheet data was derived from audited financial statements but does not include all disclosures required by GAAP. The unaudited condensed consolidated financial statements, in the opinion of management, reflect all adjustments (consisting of normal recurring adjustments) necessary for a fair statement of the results for the interim periods ended  September 30, 2023 and 2022 and the financial position at  September 30, 2023; however, these results are not necessarily indicative of results which  may be expected for the full year. The interim condensed consolidated financial statements, and notes thereto, should be read in conjunction with the audited consolidated financial statements for the year ended  March 31, 2023, and notes thereto, included in the Company’s Annual Report on Form 10-K for the year ended  March 31, 2023 filed with the SEC on  May 31, 2023.

- changed (2024-01-24):
[0001437749-24-002041:note_history:3]
The Company has historically experienced recurring operating losses and as of  December 31, 2023, the Company had an accumulated deficit of $1,065.1 million. In addition, the Company has historically experienced recurring negative operating cash flows. At  December 31, 2023, the Company had cash and cash equivalents of $24.0 million. Cash used in operations for the nine months ended  December 31, 2023 was $0.1 million.
  (was, 2023-11-01, similarity 0.9286):
[0001437749-23-029753:note_history:3]
The Company has historically experienced recurring operating losses and as of  September 30, 2023, the Company had an accumulated deficit of $1,063.4 million. In addition, the Company has historically experienced recurring negative operating cash flows. At  September 30, 2023, the Company had cash and cash equivalents of $22.8 million. Cash used in operations for the six months ended  September 30, 2023 was $1.3 million.

- changed (2024-01-24):
[0001437749-24-002041:note_history:4]
In recent periods, the Company has experienced inflationary pressure in its supply chain and some delays in sourcing materials needed for its products resulting in some production disruption, both of which have increased the Company’s cost of revenues and decreased gross margin. While the impact of inflation has been challenging, the Company has taken actions to limit this pressure, including adjusting the pricing of its products and services. Changes in macroeconomic conditions arising from various reasons, such as the ongoing wars between Russia and Ukraine and Israel and Hamas, inflation, COVID-19, rising interest rates, labor force availability, sourcing, material delays and global supply chain disruptions, could have a material adverse effect on the Company’s business, financial condition and results of operation.
  (was, 2023-11-01, similarity 0.7928):
[0001437749-23-029753:note_history:4]
The Company continues to experience inflationary pressure in its supply chain and some delays in sourcing materials needed for its products resulting in some production disruption, both of which have increased the Company’s cost of revenues and decreased gross margin. While the impact of inflation has been challenging, the Company continues to take actions to limit this pressure, including adjusting the pricing of its products and services. Changes in macroeconomic conditions arising from the COVID-19 pandemic or for other reasons, such as the ongoing wars between Russia and Ukraine and Israel and Hamas, inflation, rising interest rates, labor force availability, sourcing, material delays and global supply chain disruptions could have a material adverse effect on the Company’s business, financial condition and results of operation.

- changed (2024-01-24):
[0001437749-24-002041:note_history:5]
From time-to-time the Company  may undertake restructuring activities in order to align the global organization in a manner that the Company believes will better position it to achieve its long-term goals. In  January 2023, the Company undertook a reduction in force that involved approximately 5% of the global workforce. This restructuring is expected to incur $1.0 million of cash expenses, of which $0.9 million has been paid as of  December 31, 2023 and the remaining $0.1 million is expected to be paid by  March 31, 2024, and to result in annualized cost savings of approximately $5.0 million, beginning in fiscal 2023.
  (was, 2023-11-01, similarity 0.7602):
[0001437749-23-029753:note_history:5]
From time-to-time the Company  may undertake restructuring activities in order to align the global organization in a manner that the Company believes will better position it to achieve its long-term goals. In  January 2023, the Company undertook a reduction in force that involved approximately 5% of the global workforce. This restructuring is expected to incur $1.0 million of cash expenses, $0.8 million of which has been paid as of  September 30, 2023, and to result in annualized cost savings of approximately $5.0 million, beginning in fiscal 2023.

- changed (2024-01-24):
[0001437749-24-002041:note_history:6]
The Company believes that based on the information presented above and its quarterly management assessment, it has sufficient liquidity to fund its operations and capital expenditures for the next twelve months following the issuance of the unaudited condensed consolidated financial statements for the nine months ended  December 31, 2023. The Company’s liquidity is highly dependent on its ability to increase revenues, its ability to control its operating costs, and its ability to raise additional capital, if necessary. The impact of COVID-19 and other sources of instability, including the wars between Russia and Ukraine and Israel and Hamas, on the global financing markets  may reduce the Company's ability to raise additional capital, if necessary, which could negatively impact the Company's liquidity.  There can be no assurance that the Company will be able to continue to raise additional capital, on favorable terms or at all, from other sources or execute on any other means of improving liquidity described above.
  (was, 2023-11-01, similarity 0.9732):
[0001437749-23-029753:note_history:6]
The Company believes that based on the information presented above and its quarterly management assessment, it has sufficient liquidity to fund its operations and capital expenditures for the next twelve months following the issuance of the unaudited condensed consolidated financial statements for the six months ended  September 30, 2023. The Company’s liquidity is highly dependent on its ability to increase revenues, its ability to control its operating costs, and its ability to raise additional capital, if necessary. The impact of the COVID-19 pandemic and other sources of instability, including the wars between Russia and Ukraine and Israel and Hamas, on the global financing markets  may reduce the Company's ability to raise additional capital, if necessary, which could negatively impact the Company's liquidity.  There can be no assurance that the Company will be able to continue to raise additional capital, on favorable terms or at all, from other sources or execute on any other means of improving liquidity described above.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2024-01-24):
[0001437749-24-002041:note_history:7]
As part of the acquisition of Neeltran, the Company identified four equipment financing agreements that Neeltran had entered into prior to the acquisition of Neeltran on  May 6, 2021. The current debt balance is less than $0.1 million as of  December 31, 2023 and was $0.1 million as of  March 31, 2023.
  (was, 2023-11-01, similarity 0.8943):
[0001437749-23-029753:note_history:7]
As part of the acquisition of Neeltran, the Company identified four equipment financing agreements that Neeltran had entered into prior to the acquisition of Neeltran on  May 6, 2021. The current debt balance is $0.1 million as of  September 30, 2023 and  March 31, 2023.


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2024-01-24):
[0001437749-24-002041:note_history:8]
|  |  | Three Months Ended December 31, 2023 |  |  | Nine Months Ended December 31, 2023 |  |
| Product Line: |  | Grid |  |  | Wind |  |  | Grid |  |  | Wind |  |
| Equipment and systems |  | $ | 31,210 |  |  | $ | 4,983 |  |  | $ | 81,181 |  |  | $ | 13,844 |  |
| Services and technology development |  |  | 2,393 |  |  |  | 767 |  |  |  | 6,673 |  |  |  | 1,913 |  |
| Total |  | $ | 33,603 |  |  | $ | 5,750 |  |  | $ | 87,854 |  |  | $ | 15,757 |  |
| Region: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas |  | $ | 26,782 |  |  | $ | 45 |  |  | $ | 74,640 |  |  | $ | 102 |  |
| Asia Pacific |  |  | 3,704 |  |  |  | 5,660 |  |  |  | 8,832 |  |  |  | 15,587 |  |
| EMEA |  |  | 3,117 |  |  |  | 45 |  |  |  | 4,382 |  |  |  | 68 |  |
| Total |  | $ | 33,603 |  |  | $ | 5,750 |  |  | $ | 87,854 |  |  | $ | 15,757 |  |
  (was, 2023-11-01, similarity 0.9815):
[0001437749-23-029753:note_history:8]
|  |  | Three Months Ended September 30, 2023 |  |  | Six Months Ended September 30, 2023 |  |
| Product Line: |  | Grid |  |  | Wind |  |  | Grid |  |  | Wind |  |
| Equipment and systems |  | $ | 22,682 |  |  | $ | 4,879 |  |  | $ | 45,808 |  |  | $ | 8,862 |  |
| Services and technology development |  |  | 5,833 |  |  |  | 610 |  |  |  | 8,443 |  |  |  | 1,145 |  |
| Total |  | $ | 28,515 |  |  | $ | 5,489 |  |  | $ | 54,251 |  |  | $ | 10,007 |  |
| Region: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas |  | $ | 24,696 |  |  | $ | 27 |  |  | $ | 47,856 |  |  | $ | 57 |  |
| Asia Pacific |  |  | 3,418 |  |  |  | 5,462 |  |  |  | 5,129 |  |  |  | 9,928 |  |
| EMEA |  |  | 401 |  |  |  | — |  |  |  | 1,266 |  |  |  | 22 |  |
| Total |  | $ | 28,515 |  |  | $ | 5,489 |  |  | $ | 54,251 |  |  | $ | 10,007 |  |

- changed (2024-01-24):
[0001437749-24-002041:note_history:9]
|  |  | Three Months Ended December 31, 2022 |  |  | Nine Months Ended December 31, 2022 |  |
| Product Line: |  | Grid |  |  | Wind |  |  | Grid |  |  | Wind |  |
| Equipment and systems |  | $ | 19,475 |  |  | $ | 2,842 |  |  | $ | 61,680 |  |  | $ | 6,144 |  |
| Services and technology development |  |  | 1,334 |  |  |  | 230 |  |  |  | 4,657 |  |  |  | 1,760 |  |
| Total |  | $ | 20,809 |  |  | $ | 3,072 |  |  | $ | 66,337 |  |  | $ | 7,904 |  |
| Region: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas |  | $ | 17,010 |  |  | $ | 19 |  |  | $ | 51,934 |  |  | $ | 19 |  |
| Asia Pacific |  |  | 1,760 |  |  |  | 3,053 |  |  |  | 10,615 |  |  |  | 7,815 |  |
| EMEA |  |  | 2,039 |  |  |  | — |  |  |  | 3,788 |  |  |  | 70 |  |
| Total |  | $ | 20,809 |  |  | $ | 3,072 |  |  | $ | 66,337 |  |  | $ | 7,904 |  |
  (was, 2023-11-01, similarity 0.9413):
[0001437749-23-029753:note_history:9]
|  |  | Three Months Ended September 30, 2022 |  |  | Six Months Ended September 30, 2022 |  |
| Product Line: |  | Grid |  |  | Wind |  |  | Grid |  |  | Wind |  |
| Equipment and systems |  | $ | 24,128 |  |  | $ | 1,330 |  |  | $ | 42,204 |  |  | $ | 3,302 |  |
| Services and technology development |  |  | 1,570 |  |  |  | 652 |  |  |  | 3,323 |  |  |  | 1,531 |  |
| Total |  | $ | 25,698 |  |  | $ | 1,982 |  |  | $ | 45,527 |  |  | $ | 4,833 |  |
| Region: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas |  | $ | 18,021 |  |  | $ | - |  |  | $ | 34,923 |  |  | $ | - |  |
| Asia Pacific |  |  | 6,178 |  |  |  | 1,912 |  |  |  | 8,855 |  |  |  | 4,763 |  |
| EMEA |  |  | 1,499 |  |  |  | 70 |  |  |  | 1,749 |  |  |  | 70 |  |
| Total |  | $ | 25,698 |  |  | $ | 1,982 |  |  | $ | 45,527 |  |  | $ | 4,833 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2024-01-24):
[0001437749-24-002041:note_history:10]
The Company’s revenues in its Grid business segment are derived primarily through enabling the transmission and distribution of power, providing planning services that allow it to identify power grid needs and risks, and developing ship protection systems for the U.S. Navy. The Company’s revenues in its Wind business segment are derived primarily through supplying advanced power electronics and control systems, licensing its highly engineered wind turbine designs, and providing extensive customer support services to wind turbine manufacturers. The Company records revenue based on a five-step model in accordance with Accounting Standards Codification ("ASC") 606. For its customer contracts, the Company identifies the performance obligations, determines the transaction price, allocates the contract transaction price to the performance obligations, and recognizes the revenue when (or as) control of goods or services is transferred to the customer. In the three and nine months ended  December 31, 2023, 85% and 80% of revenue, respectively, was recognized at the point in time when control transferred to the customer, with the remainder being recognized over time. In the three and nine months ended  December 31, 2022, 87% and 80% of revenue, respectively, was recognized at the point in time when control transferred to the customer, with the remainder being recognized over time.
  (was, 2023-11-01, similarity 0.9694):
[0001437749-23-029753:note_history:10]
The Company’s revenues in its Grid business segment are derived primarily through enabling the transmission and distribution of power, providing planning services that allow it to identify power grid needs and risks, and developing ship protection systems for the U.S. Navy. The Company’s revenues in its Wind business segment are derived primarily through supplying advanced power electronics and control systems, licensing its highly engineered wind turbine designs, and providing extensive customer support services to wind turbine manufacturers. The Company records revenue based on a five-step model in accordance with Accounting Standards Codification ("ASC") 606. For its customer contracts, the Company identifies the performance obligations, determines the transaction price, allocates the contract transaction price to the performance obligations, and recognizes the revenue when (or as) control of goods or services is transferred to the customer. In the three and six months ended  September 30, 2023, 79% and 78% of revenue, respectively, was recognized at the point in time when control transferred to the customer, with the remainder being recognized over time. In the three and six months ended  September 30, 2022, 83% and 77% of revenue, respectively, was recognized at the point in time when control transferred to the customer, with the remainder being recognized over time.

- changed (2024-01-24):
[0001437749-24-002041:note_history:11]
The Company monitors costs to meet its obligations on its customer contracts. When it is evident that there is a loss expected on a contract, a contract loss is accrued in the period. Several long-term contracts that were acquired from Neeltran, Inc. (“Neeltran”) were impacted by higher than planned costs due to required design changes and inflation on material costs, resulting in an increase to the contract loss accrual of $1.6 million and $3.2 million in the three and nine months ended  December 31, 2022, respectively, which negatively impacted the Company's gross margins. The contract loss accrual decreased by $2.5 million and $3.4 million in each of the three and nine months ended  December 31, 2023, respectively, as projects have been completed.
  (was, 2023-11-01, similarity 0.9322):
[0001437749-23-029753:note_history:11]
The Company monitors costs to meet its obligations on its customer contracts. When it is evident that there is a loss expected on a contract, a contract loss is accrued in the period. Several long-term contracts that were acquired from Neeltran, Inc. (“Neeltran”) were impacted by higher than planned costs due to required design changes and inflation on material costs, resulting in an increase to the contract loss accrual of $1.0 million and $1.2 million in the three and six months ended  September 30, 2022, respectively, which negatively impacted the Company's gross margins. The contract loss accrual decreased by $0.9 million in each of the three and six months ended  September 30, 2023, respectively, as projects have been completed.

- changed (2024-01-24):
[0001437749-24-002041:note_history:12]
|  |  | Three Months Ended December 31, 2023 |  |  | Nine Months Ended December 31, 2023 |  |
| Product Line: |  | Grid |  |  | Wind |  |  | Grid |  |  | Wind |  |
| Equipment and systems |  | $ | 31,210 |  |  | $ | 4,983 |  |  | $ | 81,181 |  |  | $ | 13,844 |  |
| Services and technology development |  |  | 2,393 |  |  |  | 767 |  |  |  | 6,673 |  |  |  | 1,913 |  |
| Total |  | $ | 33,603 |  |  | $ | 5,750 |  |  | $ | 87,854 |  |  | $ | 15,757 |  |
| Region: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas |  | $ | 26,782 |  |  | $ | 45 |  |  | $ | 74,640 |  |  | $ | 102 |  |
| Asia Pacific |  |  | 3,704 |  |  |  | 5,660 |  |  |  | 8,832 |  |  |  | 15,587 |  |
| EMEA |  |  | 3,117 |  |  |  | 45 |  |  |  | 4,382 |  |  |  | 68 |  |
| Total |  | $ | 33,603 |  |  | $ | 5,750 |  |  | $ | 87,854 |  |  | $ | 15,757 |  |
  (was, 2023-11-01, similarity 0.9815):
[0001437749-23-029753:note_history:12]
|  |  | Three Months Ended September 30, 2023 |  |  | Six Months Ended September 30, 2023 |  |
| Product Line: |  | Grid |  |  | Wind |  |  | Grid |  |  | Wind |  |
| Equipment and systems |  | $ | 22,682 |  |  | $ | 4,879 |  |  | $ | 45,808 |  |  | $ | 8,862 |  |
| Services and technology development |  |  | 5,833 |  |  |  | 610 |  |  |  | 8,443 |  |  |  | 1,145 |  |
| Total |  | $ | 28,515 |  |  | $ | 5,489 |  |  | $ | 54,251 |  |  | $ | 10,007 |  |
| Region: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas |  | $ | 24,696 |  |  | $ | 27 |  |  | $ | 47,856 |  |  | $ | 57 |  |
| Asia Pacific |  |  | 3,418 |  |  |  | 5,462 |  |  |  | 5,129 |  |  |  | 9,928 |  |
| EMEA |  |  | 401 |  |  |  | — |  |  |  | 1,266 |  |  |  | 22 |  |
| Total |  | $ | 28,515 |  |  | $ | 5,489 |  |  | $ | 54,251 |  |  | $ | 10,007 |  |

- changed (2024-01-24):
[0001437749-24-002041:note_history:13]
|  |  | Three Months Ended December 31, 2022 |  |  | Nine Months Ended December 31, 2022 |  |
| Product Line: |  | Grid |  |  | Wind |  |  | Grid |  |  | Wind |  |
| Equipment and systems |  | $ | 19,475 |  |  | $ | 2,842 |  |  | $ | 61,680 |  |  | $ | 6,144 |  |
| Services and technology development |  |  | 1,334 |  |  |  | 230 |  |  |  | 4,657 |  |  |  | 1,760 |  |
| Total |  | $ | 20,809 |  |  | $ | 3,072 |  |  | $ | 66,337 |  |  | $ | 7,904 |  |
| Region: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas |  | $ | 17,010 |  |  | $ | 19 |  |  | $ | 51,934 |  |  | $ | 19 |  |
| Asia Pacific |  |  | 1,760 |  |  |  | 3,053 |  |  |  | 10,615 |  |  |  | 7,815 |  |
| EMEA |  |  | 2,039 |  |  |  | — |  |  |  | 3,788 |  |  |  | 70 |  |
| Total |  | $ | 20,809 |  |  | $ | 3,072 |  |  | $ | 66,337 |  |  | $ | 7,904 |  |
  (was, 2023-11-01, similarity 0.9413):
[0001437749-23-029753:note_history:13]
|  |  | Three Months Ended September 30, 2022 |  |  | Six Months Ended September 30, 2022 |  |
| Product Line: |  | Grid |  |  | Wind |  |  | Grid |  |  | Wind |  |
| Equipment and systems |  | $ | 24,128 |  |  | $ | 1,330 |  |  | $ | 42,204 |  |  | $ | 3,302 |  |
| Services and technology development |  |  | 1,570 |  |  |  | 652 |  |  |  | 3,323 |  |  |  | 1,531 |  |
| Total |  | $ | 25,698 |  |  | $ | 1,982 |  |  | $ | 45,527 |  |  | $ | 4,833 |  |
| Region: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas |  | $ | 18,021 |  |  | $ | - |  |  | $ | 34,923 |  |  | $ | - |  |
| Asia Pacific |  |  | 6,178 |  |  |  | 1,912 |  |  |  | 8,855 |  |  |  | 4,763 |  |
| EMEA |  |  | 1,499 |  |  |  | 70 |  |  |  | 1,749 |  |  |  | 70 |  |
| Total |  | $ | 25,698 |  |  | $ | 1,982 |  |  | $ | 45,527 |  |  | $ | 4,833 |  |

- changed (2024-01-24):
[0001437749-24-002041:note_history:14]
As of  December 31, 2023, and 2022, the Company’s contract assets and liabilities primarily relate to the timing differences between cash received from a customer in connection with contractual rights to invoicing and the timing of revenue recognition following completion of performance obligations. The Company's accounts receivable balance is made up entirely of customer contract related balances. Changes in the Company’s contract assets, which are included in “Unbilled accounts receivable” and “Deferred program costs” (see Note 7, “Accounts Receivable” and Note 8, “Inventory” for a reconciliation to the condensed consolidated balance sheets) and "Contract liabilities", which are included in the current portion and long-term portion of "Deferred revenue" in the Company’s condensed consolidated balance sheets, are as follows (in thousands):
  (was, 2023-11-01, similarity 0.9958):
[0001437749-23-029753:note_history:14]
As of  September 30, 2023, and 2022, the Company’s contract assets and liabilities primarily relate to the timing differences between cash received from a customer in connection with contractual rights to invoicing and the timing of revenue recognition following completion of performance obligations. The Company's accounts receivable balance is made up entirely of customer contract related balances. Changes in the Company’s contract assets, which are included in “Unbilled accounts receivable” and “Deferred program costs” (see Note 7, “Accounts Receivable” and Note 8, “Inventory” for a reconciliation to the condensed consolidated balance sheets) and "Contract liabilities", which are included in the current portion and long-term portion of "Deferred revenue" in the Company’s condensed consolidated balance sheets, are as follows (in thousands):

- changed (2024-01-24):
[0001437749-24-002041:note_history:15]
|  |  | Unbilled Accounts Receivable |  |  | Deferred Program Costs |  |  | Contract Liabilities |  |
| Beginning balance as of March 31, 2023 |  | $ | 9,958 |  |  | $ | 2,136 |  |  | $ | 50,760 |  |
| Increases for costs incurred to fulfill performance obligations |  |  | — |  |  |  | 2,714 |  |  |  | — |  |
| Increase (decrease) due to customer billings |  |  | (18,354 | ) |  |  | — |  |  |  | 55,018 |  |
| Decrease due to cost recognition on completed performance obligations |  |  | — |  |  |  | (3,518 | ) |  |  | — |  |
| Increase (decrease) due to recognition of revenue based on transfer of control of performance obligations |  |  | 12,969 |  |  |  | — |  |  |  | (46,190 | ) |
| Other changes and FX impact |  |  | 15 |  |  |  | 5 |  |  |  | 155 |  |
| Ending balance as of December 31, 2023 |  | $ | 4,588 |  |  | $ | 1,337 |  |  | $ | 59,743 |  |
  (was, 2023-11-01, similarity 0.9383):
[0001437749-23-029753:note_history:15]
|  |  | Unbilled Accounts Receivable |  |  | Deferred Program Costs |  |  | Contract Liabilities |  |
| Beginning balance as of March 31, 2023 |  | $ | 9,958 |  |  | $ | 2,136 |  |  | $ | 50,760 |  |
| Increases for costs incurred to fulfill performance obligations |  |  | — |  |  |  | 2,110 |  |  |  | — |  |
| Increase (decrease) due to customer billings |  |  | (13,981 | ) |  |  | — |  |  |  | 34,284 |  |
| Decrease due to cost recognition on completed performance obligations |  |  | — |  |  |  | (2,160 | ) |  |  | — |  |
| Increase (decrease) due to recognition of revenue based on transfer of control of performance obligations |  |  | 10,351 |  |  |  | — |  |  |  | (25,710 | ) |
| Other changes and FX impact |  |  | 7 |  |  |  | (11 | ) |  |  | (288 | ) |
| Ending balance as of September 30, 2023 |  | $ | 6,335 |  |  | $ | 2,075 |  |  | $ | 59,046 |  |

- changed (2024-01-24):
[0001437749-24-002041:note_history:16]
|  |  | Unbilled Accounts Receivable |  |  | Deferred Program Costs |  |  | Contract Liabilities |  |
| Beginning balance as of March 31, 2022 |  | $ | 6,492 |  |  | $ | 858 |  |  | $ | 30,034 |  |
| Increases for costs incurred to fulfill performance obligations |  |  | — |  |  |  | 909 |  |  |  | — |  |
| Increase (decrease) due to customer billings |  |  | (11,723 | ) |  |  | — |  |  |  | 48,013 |  |
| Decrease due to cost recognition on completed performance obligations |  |  | — |  |  |  | (791 | ) |  |  | — |  |
| Increase (decrease) due to recognition of revenue based on transfer of control of performance obligations |  |  | 9,544 |  |  |  | — |  |  |  | (36,452 | ) |
| Other changes and FX impact |  |  | — |  |  |  | (15 | ) |  |  | (180 | ) |
| Ending balance as of December 31, 2022 |  | $ | 4,313 |  |  | $ | 961 |  |  | $ | 41,415 |  |
  (was, 2023-11-01, similarity 0.9953):
[0001437749-23-029753:note_history:16]
|  |  | Unbilled Accounts Receivable |  |  | Deferred Program Costs |  |  | Contract Liabilities |  |
| Beginning balance as of March 31, 2022 |  | $ | 6,492 |  |  | $ | 858 |  |  | $ | 30,034 |  |
| Increases for costs incurred to fulfill performance obligations |  |  | — |  |  |  | 782 |  |  |  | — |  |
| Increase (decrease) due to customer billings |  |  | (7,322 | ) |  |  | — |  |  |  | 33,141 |  |
| Decrease due to cost recognition on completed performance obligations |  |  | — |  |  |  | (697 | ) |  |  | — |  |
| Increase (decrease) due to recognition of revenue based on transfer of control of performance obligations |  |  | 7,342 |  |  |  | — |  |  |  | (26,857 | ) |
| Other changes and FX impact |  |  | — |  |  |  | (47 | ) |  |  | (863 | ) |
| Ending balance as of September 30, 2022 |  | $ | 6,512 |  |  | $ | 896 |  |  | $ | 35,455 |  |

- changed (2024-01-24):
[0001437749-24-002041:note_history:17]
The Company’s remaining performance obligations represent the unrecognized revenue value of the Company’s contractual commitments. The Company’s performance obligations  may vary significantly each reporting period based on the timing of major new contractual commitments. As of  December 31, 2023, the Company had outstanding performance obligations on existing contracts under ASC 606 to be recognized in the next twelve months of approximately $137.2 million. There are also approximately $30.2 million of outstanding performance obligations to be recognized over a period of thirteen to sixty months. The remaining performance obligations are subject to customer actions and therefore the timing of revenue recognition cannot be reasonably estimated.
  (was, 2023-11-01, similarity 0.9953):
[0001437749-23-029753:note_history:17]
The Company’s remaining performance obligations represent the unrecognized revenue value of the Company’s contractual commitments. The Company’s performance obligations  may vary significantly each reporting period based on the timing of major new contractual commitments. As of  September 30, 2023, the Company had outstanding performance obligations on existing contracts under ASC 606 to be recognized in the next twelve months of approximately $128.3 million. There are also approximately $43.2 million of outstanding performance obligations to be recognized over a period of thirteen to sixty months. The remaining performance obligations are subject to customer actions and therefore the timing of revenue recognition cannot be reasonably estimated.

- changed (2024-01-24):
[0001437749-24-002041:note_history:18]
The following table sets forth customers who represented 10% or more of the Company’s total revenues for the three and nine months ended  December 31, 2023 and 2022:
  (was, 2023-11-01, similarity 0.9677):
[0001437749-23-029753:note_history:18]
The following table sets forth customers who represented 10% or more of the Company’s total revenues for the three and six months ended  September 30, 2023 and 2022:

- changed (2024-01-24):
[0001437749-24-002041:note_history:19]
|  |  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  | Reportable |  | December 31, |  |  | December 31, |  |
|  | Segment |  | 2023 |  |  | 2022 |  |  | 2023 |  |  | 2022 |  |
| Inox Wind Limited | Wind |  |  | 11 | % |  |  | 11 | % |  |  | 12 | % |  | <10% |  |
| Fuji Bridex Pte Ltd | Grid |  | <10% |  |  | <10% |  |  | <10% |  |  |  | 10 | % |
  (was, 2023-11-01, similarity 0.6215):
[0001437749-23-029753:note_history:19]
|  |  |  | Three Months Ended |  |  | Six Months Ended |  |
|  | Reportable |  | September 30, |  |  | September 30, |  |
|  | Segment |  | 2023 |  |  | 2022 |  |  | 2023 |  |  | 2022 |  |
| Inox Wind Limited | Wind |  |  | 12 | % |  | <10% |  |  |  | 12 | % |  | <10% |  |
| Fuji Bridex Pte Ltd | Grid |  |  | <10% |  |  |  | 17 | % |  |  | <10% |  |  |  | 13 | % |
| Gray Construction, Inc. | Grid |  |  | 11 | % |  |  | <10% |  |  |  | <10% |  |  |  | <10% |  |
| Ascend Performance Materials Ops LLC | Grid |  |  | <10% |  |  |  | 12 | % |  |  | <10% |  |  |  | <10% |  |
