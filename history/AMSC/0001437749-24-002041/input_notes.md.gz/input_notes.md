# AMSC notes — 0001437749-24-002041


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0001437749-24-002041:notes:1]
[same as prior period, unchanged from 0001437749-23-029753:notes:1]

[0001437749-24-002041:notes:2]
[same as prior period, unchanged from 0001437749-23-029753:notes:2]

[0001437749-24-002041:notes:3]
[same as prior period, unchanged from 0001437749-23-029753:notes:3]

[0001437749-24-002041:notes:4]
[same as prior period, unchanged from 0001437749-23-029753:notes:4]

[0001437749-24-002041:notes:5]
[same as prior period, unchanged from 0001437749-23-029753:notes:5]

[0001437749-24-002041:notes:6]
These unaudited condensed consolidated financial statements of the Company have been prepared on a going concern basis in accordance with United States generally accepted accounting principles (“GAAP”) and the Securities and Exchange Commission’s (“SEC”) instructions to Form 10-Q. Certain prior period amounts were reclassified to conform to the presentation in the current period. The going concern basis of presentation assumes that the Company will continue operations and will be able to realize its assets and discharge its liabilities and commitments in the normal course of business. Certain information and footnote disclosures normally included in the financial statements prepared in accordance with GAAP have been condensed or omitted pursuant to those instructions. The year-end condensed balance sheet data was derived from audited financial statements but does not include all disclosures required by GAAP. The unaudited condensed consolidated financial statements, in the opinion of management, reflect all adjustments (consisting of normal recurring adjustments) necessary for a fair statement of the results for the interim periods ended  December 31, 2023 and 2022 and the financial position at  December 31, 2023; however, these results are not necessarily indicative of results which  may be expected for the full year. The interim condensed consolidated financial statements, and notes thereto, should be read in conjunction with the audited consolidated financial statements for the year ended  March 31, 2023, and notes thereto, included in the Company’s Annual Report on Form 10-K for the year ended  March 31, 2023 filed with the SEC on  May 31, 2023.

[0001437749-24-002041:notes:7]
[same as prior period, unchanged from 0001437749-23-029753:notes:7]

[0001437749-24-002041:notes:8]
The Company has historically experienced recurring operating losses and as of  December 31, 2023, the Company had an accumulated deficit of $1,065.1 million. In addition, the Company has historically experienced recurring negative operating cash flows. At  December 31, 2023, the Company had cash and cash equivalents of $24.0 million. Cash used in operations for the nine months ended  December 31, 2023 was $0.1 million.

[0001437749-24-002041:notes:9]
[same as prior period, unchanged from 0001437749-23-029753:notes:9]

[0001437749-24-002041:notes:10]
In recent periods, the Company has experienced inflationary pressure in its supply chain and some delays in sourcing materials needed for its products resulting in some production disruption, both of which have increased the Company’s cost of revenues and decreased gross margin. While the impact of inflation has been challenging, the Company has taken actions to limit this pressure, including adjusting the pricing of its products and services. Changes in macroeconomic conditions arising from various reasons, such as the ongoing wars between Russia and Ukraine and Israel and Hamas, inflation, COVID-19, rising interest rates, labor force availability, sourcing, material delays and global supply chain disruptions, could have a material adverse effect on the Company’s business, financial condition and results of operation.

[0001437749-24-002041:notes:11]
From time-to-time the Company  may undertake restructuring activities in order to align the global organization in a manner that the Company believes will better position it to achieve its long-term goals. In  January 2023, the Company undertook a reduction in force that involved approximately 5% of the global workforce. This restructuring is expected to incur $1.0 million of cash expenses, of which $0.9 million has been paid as of  December 31, 2023 and the remaining $0.1 million is expected to be paid by  March 31, 2024, and to result in annualized cost savings of approximately $5.0 million, beginning in fiscal 2023.

[0001437749-24-002041:notes:12]
The Company believes that based on the information presented above and its quarterly management assessment, it has sufficient liquidity to fund its operations and capital expenditures for the next twelve months following the issuance of the unaudited condensed consolidated financial statements for the nine months ended  December 31, 2023. The Company’s liquidity is highly dependent on its ability to increase revenues, its ability to control its operating costs, and its ability to raise additional capital, if necessary. The impact of COVID-19 and other sources of instability, including the wars between Russia and Ukraine and Israel and Hamas, on the global financing markets  may reduce the Company's ability to raise additional capital, if necessary, which could negatively impact the Company's liquidity.  There can be no assurance that the Company will be able to continue to raise additional capital, on favorable terms or at all, from other sources or execute on any other means of improving liquidity described above.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001437749-24-002041:notes:13]
[same as prior period, unchanged from 0001437749-23-029753:notes:13]

[0001437749-24-002041:notes:14]
The Company’s revenues in its Grid business segment are derived primarily through enabling the transmission and distribution of power, providing planning services that allow it to identify power grid needs and risks, and developing ship protection systems for the U.S. Navy. The Company’s revenues in its Wind business segment are derived primarily through supplying advanced power electronics and control systems, licensing its highly engineered wind turbine designs, and providing extensive customer support services to wind turbine manufacturers. The Company records revenue based on a five-step model in accordance with Accounting Standards Codification ("ASC") 606. For its customer contracts, the Company identifies the performance obligations, determines the transaction price, allocates the contract transaction price to the performance obligations, and recognizes the revenue when (or as) control of goods or services is transferred to the customer. In the three and nine months ended  December 31, 2023, 85% and 80% of revenue, respectively, was recognized at the point in time when control transferred to the customer, with the remainder being recognized over time. In the three and nine months ended  December 31, 2022, 87% and 80% of revenue, respectively, was recognized at the point in time when control transferred to the customer, with the remainder being recognized over time.

[0001437749-24-002041:notes:15]
[same as prior period, unchanged from 0001437749-23-029753:notes:15]

[0001437749-24-002041:notes:16]
[same as prior period, unchanged from 0001437749-23-029753:notes:16]

[0001437749-24-002041:notes:17]
[same as prior period, unchanged from 0001437749-23-029753:notes:17]

[0001437749-24-002041:notes:18]
[same as prior period, unchanged from 0001437749-23-029753:notes:18]

[0001437749-24-002041:notes:19]
[same as prior period, unchanged from 0001437749-23-029753:notes:19]

[0001437749-24-002041:notes:20]
The Company records revenue net of sales tax, value added tax, excise tax and other taxes collected concurrent with revenue-producing activities. The Company has elected to recognize the cost for freight and shipping when control over the products sold passes to customers and revenue is recognized. The Company has elected to recognize incremental costs of obtaining a contract as expense when incurred except in contracts where the amortization period would exceed twelve months; in such cases the long-term amount will be assessed for materiality. The Company has elected not to adjust the promised amount of consideration for the effects of a significant financing component if the period of financing is twelve months or less.  The Company has elected to recognize revenue based on the As invoiced practical expedient if there is a right to consideration from a customer in an amount that corresponds directly with the value of the Company's performance.

[0001437749-24-002041:notes:21]
The Company monitors costs to meet its obligations on its customer contracts. When it is evident that there is a loss expected on a contract, a contract loss is accrued in the period. Several long-term contracts that were acquired from Neeltran, Inc. (“Neeltran”) were impacted by higher than planned costs due to required design changes and inflation on material costs, resulting in an increase to the contract loss accrual of $1.6 million and $3.2 million in the three and nine months ended  December 31, 2022, respectively, which negatively impacted the Company's gross margins. The contract loss accrual decreased by $2.5 million and $3.4 million in each of the three and nine months ended  December 31, 2023, respectively, as projects have been completed.

[0001437749-24-002041:notes:22]
[same as prior period, unchanged from 0001437749-23-029753:notes:22]

[0001437749-24-002041:notes:23]
[same as prior period, unchanged from 0001437749-23-029753:notes:23]

[0001437749-24-002041:notes:24]
|  |  | Three Months Ended December 31, 2023 |  |  | Nine Months Ended December 31, 2023 |  |
| Product Line: |  | Grid |  |  | Wind |  |  | Grid |  |  | Wind |  |
| Equipment and systems |  | $ | 31,210 |  |  | $ | 4,983 |  |  | $ | 81,181 |  |  | $ | 13,844 |  |
| Services and technology development |  |  | 2,393 |  |  |  | 767 |  |  |  | 6,673 |  |  |  | 1,913 |  |
| Total |  | $ | 33,603 |  |  | $ | 5,750 |  |  | $ | 87,854 |  |  | $ | 15,757 |  |
| Region: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas |  | $ | 26,782 |  |  | $ | 45 |  |  | $ | 74,640 |  |  | $ | 102 |  |
| Asia Pacific |  |  | 3,704 |  |  |  | 5,660 |  |  |  | 8,832 |  |  |  | 15,587 |  |
| EMEA |  |  | 3,117 |  |  |  | 45 |  |  |  | 4,382 |  |  |  | 68 |  |
| Total |  | $ | 33,603 |  |  | $ | 5,750 |  |  | $ | 87,854 |  |  | $ | 15,757 |  |

[0001437749-24-002041:notes:25]
|  |  | Three Months Ended December 31, 2022 |  |  | Nine Months Ended December 31, 2022 |  |
| Product Line: |  | Grid |  |  | Wind |  |  | Grid |  |  | Wind |  |
| Equipment and systems |  | $ | 19,475 |  |  | $ | 2,842 |  |  | $ | 61,680 |  |  | $ | 6,144 |  |
| Services and technology development |  |  | 1,334 |  |  |  | 230 |  |  |  | 4,657 |  |  |  | 1,760 |  |
| Total |  | $ | 20,809 |  |  | $ | 3,072 |  |  | $ | 66,337 |  |  | $ | 7,904 |  |
| Region: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas |  | $ | 17,010 |  |  | $ | 19 |  |  | $ | 51,934 |  |  | $ | 19 |  |
| Asia Pacific |  |  | 1,760 |  |  |  | 3,053 |  |  |  | 10,615 |  |  |  | 7,815 |  |
| EMEA |  |  | 2,039 |  |  |  | — |  |  |  | 3,788 |  |  |  | 70 |  |
| Total |  | $ | 20,809 |  |  | $ | 3,072 |  |  | $ | 66,337 |  |  | $ | 7,904 |  |

[0001437749-24-002041:notes:26]
As of  December 31, 2023, and 2022, the Company’s contract assets and liabilities primarily relate to the timing differences between cash received from a customer in connection with contractual rights to invoicing and the timing of revenue recognition following completion of performance obligations. The Company's accounts receivable balance is made up entirely of customer contract related balances. Changes in the Company’s contract assets, which are included in “Unbilled accounts receivable” and “Deferred program costs” (see Note 7, “Accounts Receivable” and Note 8, “Inventory” for a reconciliation to the condensed consolidated balance sheets) and "Contract liabilities", which are included in the current portion and long-term portion of "Deferred revenue" in the Company’s condensed consolidated balance sheets, are as follows (in thousands):

[0001437749-24-002041:notes:27]
|  |  | Unbilled Accounts Receivable |  |  | Deferred Program Costs |  |  | Contract Liabilities |  |
| Beginning balance as of March 31, 2023 |  | $ | 9,958 |  |  | $ | 2,136 |  |  | $ | 50,760 |  |
| Increases for costs incurred to fulfill performance obligations |  |  | — |  |  |  | 2,714 |  |  |  | — |  |
| Increase (decrease) due to customer billings |  |  | (18,354 | ) |  |  | — |  |  |  | 55,018 |  |
| Decrease due to cost recognition on completed performance obligations |  |  | — |  |  |  | (3,518 | ) |  |  | — |  |
| Increase (decrease) due to recognition of revenue based on transfer of control of performance obligations |  |  | 12,969 |  |  |  | — |  |  |  | (46,190 | ) |
| Other changes and FX impact |  |  | 15 |  |  |  | 5 |  |  |  | 155 |  |
| Ending balance as of December 31, 2023 |  | $ | 4,588 |  |  | $ | 1,337 |  |  | $ | 59,743 |  |

[0001437749-24-002041:notes:28]
|  |  | Unbilled Accounts Receivable |  |  | Deferred Program Costs |  |  | Contract Liabilities |  |
| Beginning balance as of March 31, 2022 |  | $ | 6,492 |  |  | $ | 858 |  |  | $ | 30,034 |  |
| Increases for costs incurred to fulfill performance obligations |  |  | — |  |  |  | 909 |  |  |  | — |  |
| Increase (decrease) due to customer billings |  |  | (11,723 | ) |  |  | — |  |  |  | 48,013 |  |
| Decrease due to cost recognition on completed performance obligations |  |  | — |  |  |  | (791 | ) |  |  | — |  |
| Increase (decrease) due to recognition of revenue based on transfer of control of performance obligations |  |  | 9,544 |  |  |  | — |  |  |  | (36,452 | ) |
| Other changes and FX impact |  |  | — |  |  |  | (15 | ) |  |  | (180 | ) |
| Ending balance as of December 31, 2022 |  | $ | 4,313 |  |  | $ | 961 |  |  | $ | 41,415 |  |

[0001437749-24-002041:notes:29]
The Company’s remaining performance obligations represent the unrecognized revenue value of the Company’s contractual commitments. The Company’s performance obligations  may vary significantly each reporting period based on the timing of major new contractual commitments. As of  December 31, 2023, the Company had outstanding performance obligations on existing contracts under ASC 606 to be recognized in the next twelve months of approximately $137.2 million. There are also approximately $30.2 million of outstanding performance obligations to be recognized over a period of thirteen to sixty months. The remaining performance obligations are subject to customer actions and therefore the timing of revenue recognition cannot be reasonably estimated.

[0001437749-24-002041:notes:30]
The following table sets forth customers who represented 10% or more of the Company’s total revenues for the three and nine months ended  December 31, 2023 and 2022:

[0001437749-24-002041:notes:31]
|  |  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  | Reportable |  | December 31, |  |  | December 31, |  |
|  | Segment |  | 2023 |  |  | 2022 |  |  | 2023 |  |  | 2022 |  |
| Inox Wind Limited | Wind |  |  | 11 | % |  |  | 11 | % |  |  | 12 | % |  | <10% |  |
| Fuji Bridex Pte Ltd | Grid |  | <10% |  |  | <10% |  |  | <10% |  |  |  | 10 | % |


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001437749-24-002041:notes:32]
[same as prior period, unchanged from 0001437749-23-029753:notes:32]

[0001437749-24-002041:notes:33]
The Company accounts for its stock-based compensation at fair value. The following table summarizes stock-based compensation expense by financial statement line item for the three and nine months ended  December 31, 2023 and 2022 (in thousands):

[0001437749-24-002041:notes:34]
|  |  | Three Months Ended December 31, |  |  | Nine Months Ended December 31, |  |
|  |  | 2023 |  |  | 2022 |  |  | 2023 |  |  | 2022 |  |
| Cost of revenues |  | $ | 62 |  |  | $ | 89 |  |  | $ | 230 |  |  | $ | 195 |  |
| Research and development |  |  | 158 |  |  |  | 214 |  |  |  | 469 |  |  |  | 570 |  |
| Selling, general and administrative |  |  | 920 |  |  |  | 1,137 |  |  |  | 2,909 |  |  |  | 2,727 |  |
| Total |  | $ | 1,140 |  |  | $ | 1,440 |  |  | $ | 3,608 |  |  | $ | 3,492 |  |

[0001437749-24-002041:notes:35]
The Company issued no shares and 681,500 shares of restricted stock during the three and nine months ended  December 31, 2023, respectively. The Company issued no shares of immediately vested common stock during the three months ended  December 31, 2023 and 53,675 shares of immediately vested common stock during the nine months ended  December 31, 2023. The Company issued 550,000 shares of restricted stock and no shares of immediately vested common stock during the three months ended  December 31, 2022 and 888,500 shares of restricted stock and 25,806 shares of immediately vested common stock during the nine months ended  December 31, 2022. These restricted stock awards generally vest over 2-3 years. Awards for restricted stock include both time-based and performance-based awards. For options and restricted stock awards that vest upon the passage of time, expense is being recorded over the vesting period. Performance-based awards are expensed over the requisite service period based on probability of achievement.

[0001437749-24-002041:notes:36]
The estimated fair value of the Company’s stock-based awards, less expected annual forfeitures, is amortized over the awards’ service period. The total unrecognized compensation cost for unvested stock options was less than $0.1 million as of  December 31, 2023. This expense will be recognized over a weighted average of approximately 0.4 years. The total unrecognized compensation cost for unvested outstanding restricted stock was $5.8 million as of  December 31, 2023. This expense will be recognized over a weighted-average expense period of approximately 1.7 years.

[0001437749-24-002041:notes:37]
The Company granted no stock options during the three and nine months ended  December 31, 2023. The Company granted no stock options in the three months ended  December 31, 2022, and 20,564 stock options during the nine months ended  December 31, 2022. The stock options granted during the nine months ended  December 31, 2022 will vest in equal annual installments over 2 years. The weighted average assumptions used in the Black Scholes valuation model for stock options granted during the nine months ended  December 31, 2022 are as follows:

[0001437749-24-002041:notes:38]
[same as prior period, unchanged from 0001437749-23-029753:notes:38]


## us-gaap:EarningsPerShareTextBlock

[0001437749-24-002041:notes:39]
[same as prior period, unchanged from 0001437749-23-029753:notes:39]

[0001437749-24-002041:notes:40]
Basic net loss per share (“EPS”) is computed by dividing net loss by the weighted-average number of common shares outstanding for the period. Where applicable, diluted EPS is computed by dividing the net loss by the weighted-average number of common shares and dilutive common equivalent shares outstanding during the period, calculated using the treasury stock method. Common equivalent shares include the effect of restricted stock, exercise of stock options and warrants and contingently issuable shares. Stock options and warrants that are out-of-the-money with exercise prices greater than the average market price of the underlying common shares and shares of performance-based restricted stock where the contingency was not met are excluded from the computation of diluted EPS as the effect of their inclusion would be anti-dilutive. For each of the three and nine months ended  December 31, 2023, 0.3 million shares were not included in the calculation of diluted EPS. Of these, 0.3 million relate to shares associated with the contingent consideration derivative liability for which the contingency has not yet been met, and less than 0.1 million relate to outstanding stock options as they were considered anti-dilutive. For each of the three and nine months ended  December 31, 2022, 1.1 million shares were not included in the calculation of diluted EPS. Of these, 1.0 million relate to shares associated with the contingent consideration derivative liability for which the contingency has not yet been met, and 0.1 million relate to outstanding stock options as they were considered anti-dilutive.

[0001437749-24-002041:notes:41]
The following table reconciles the numerators and denominators of the earnings per share calculation for the three and nine months ended  December 31, 2023 and 2022 (in thousands, except per share data):

[0001437749-24-002041:notes:42]
|  |  | Three Months Ended December 31, |  |  | Nine Months Ended December 31, |  |
|  |  | 2023 |  |  | 2022 |  |  | 2023 |  |  | 2022 |  |
| Numerator: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net loss |  | $ | (1,649 | ) |  | $ | (9,581 | ) |  | $ | (9,532 | ) |  | $ | (28,171 | ) |
| Denominator: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Weighted-average shares of common stock outstanding |  |  | 30,547 |  |  |  | 29,354 |  |  |  | 30,180 |  |  |  | 28,884 |  |
| Weighted-average shares subject to repurchase |  |  | (1,455 | ) |  |  | (1,400 | ) |  |  | (1,452 | ) |  |  | (1,090 | ) |
| Shares used in per-share calculation ― basic |  |  | 29,092 |  |  |  | 27,954 |  |  |  | 28,728 |  |  |  | 27,794 |  |
| Shares used in per-share calculation ― diluted |  |  | 29,092 |  |  |  | 27,954 |  |  |  | 28,728 |  |  |  | 27,794 |  |
| Net loss per share ― basic |  | $ | (0.06 | ) |  | $ | (0.34 | ) |  | $ | (0.33 | ) |  | $ | (1.01 | ) |
| Net loss per share ― diluted |  | $ | (0.06 | ) |  | $ | (0.34 | ) |  | $ | (0.33 | ) |  | $ | (1.01 | ) |


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001437749-24-002041:notes:43]
[same as prior period, unchanged from 0001437749-23-029753:notes:43]

[0001437749-24-002041:notes:44]
[same as prior period, unchanged from 0001437749-23-029753:notes:44]

[0001437749-24-002041:notes:45]
[same as prior period, unchanged from 0001437749-23-029753:notes:45]

[0001437749-24-002041:notes:46]
There were no changes to goodwill during the nine months ended  December 31, 2023 or year ended  March 31, 2023.

[0001437749-24-002041:notes:47]
The Company did not identify any triggering events in the three and nine months ended  December 31, 2023 that would require interim impairment testing of goodwill.

[0001437749-24-002041:notes:48]
[same as prior period, unchanged from 0001437749-23-029753:notes:48]

[0001437749-24-002041:notes:49]
Intangible assets at  December 31, 2023 and  March 31, 2023 consisted of the following (in thousands):

[0001437749-24-002041:notes:50]
|  |  | December 31, 2023 |  |  | March 31, 2023 |  |  |  |  |  |
|  |  | Gross Amount |  |  | Accumulated Amortization |  |  | Net Book Value |  |  | Gross Amount |  |  | Accumulated Amortization |  |  | Net Book Value |  |  | Estimated Useful Life |  |
| Backlog |  |  | 681 |  |  |  | (681 | ) |  |  | — |  |  |  | 681 |  |  |  | (675 | ) |  | $ | 6 |  |  |  | 2 |  |
| Trade name and trademarks |  |  | 1,800 |  |  |  | — |  |  |  | 1,800 |  |  |  | 1,800 |  |  |  | — |  |  |  | 1,800 |  |  | Indefinite |  |
| Customer relationships |  |  | 9,600 |  |  |  | (6,232 | ) |  |  | 3,368 |  |  |  | 9,600 |  |  |  | (4,980 | ) |  |  | 4,620 |  |  |  | 7 |  |
| Core technology and know-how |  |  | 5,970 |  |  |  | (4,231 | ) |  |  | 1,739 |  |  |  | 5,970 |  |  |  | (3,869 | ) |  |  | 2,101 |  |  |  | 5-10 |  |
| Intangible assets |  | $ | 18,051 |  |  | $ | (11,144 | ) |  | $ | 6,907 |  |  | $ | 18,051 |  |  | $ | (9,524 | ) |  | $ | 8,527 |  |  |  |  |  |

[0001437749-24-002041:notes:51]
The Company recorded intangible amortization expense related to customer relationship and core technology and know-how of $0.5 million and $1.6 million, in the three and nine months ended  December 31, 2023, respectively, and $0.7 million and $2.1 million in the three and nine months ended  December 31, 2022, respectively. Additionally, the Company recorded no intangible amortization related to backlog that is reported in cost of revenues in the three months ended  December 31, 2023 and less than $0.1 million in the nine months ended  December 31, 2023. The Company recorded less than $0.1 million related to backlog that is reported in cost of revenues in the three and nine months ended  December 31, 2022, respectively.

[0001437749-24-002041:notes:52]
[same as prior period, unchanged from 0001437749-23-029753:notes:52]

[0001437749-24-002041:notes:53]
| Years ending March 31, |  | Total |  |
| 2024 |  |  | 538 |  |
| 2025 |  |  | 1,648 |  |
| 2026 |  |  | 1,221 |  |
| 2027 |  |  | 1,085 |  |
| 2028 |  |  | 543 |  |
| Thereafter |  |  | 72 |  |
| Total |  | $ | 5,107 |  |

[0001437749-24-002041:notes:54]
[same as prior period, unchanged from 0001437749-23-029753:notes:54]


## us-gaap:FairValueDisclosuresTextBlock

[0001437749-24-002041:notes:55]
[same as prior period, unchanged from 0001437749-23-029753:notes:55]

[0001437749-24-002041:notes:56]
[same as prior period, unchanged from 0001437749-23-029753:notes:56]

[0001437749-24-002041:notes:57]
[same as prior period, unchanged from 0001437749-23-029753:notes:57]

[0001437749-24-002041:notes:58]
The Company provides a gross presentation of activity within Level 3 measurement roll-forward and details of transfers in and out of Level 1 and 2 measurements. A change in the hierarchy of an investment from its current level is reflected in the period during which the pricing methodology of such investment changes. Disclosure of the transfer of securities from Level 1 to Level 2 or Level 3 is made in the event that the related security is significant to total cash and investments. The Company did not have any transfers of assets and liabilities from Level 1, Level 2 or Level 3 of the fair value measurement hierarchy during the nine months ended  December 31, 2023.

[0001437749-24-002041:notes:59]
[same as prior period, unchanged from 0001437749-23-029753:notes:59]

[0001437749-24-002041:notes:60]
[same as prior period, unchanged from 0001437749-23-029753:notes:60]

[0001437749-24-002041:notes:61]
[same as prior period, unchanged from 0001437749-23-029753:notes:61]

[0001437749-24-002041:notes:62]
[same as prior period, unchanged from 0001437749-23-029753:notes:62]

[0001437749-24-002041:notes:63]
[same as prior period, unchanged from 0001437749-23-029753:notes:63]

[0001437749-24-002041:notes:64]
Contingent consideration relates to the earnout payment set forth in the Stock Purchase Agreement governing the acquisition of Northeast Power Systems, Inc ("NEPSI") that provides that the selling stockholders  may receive up to an additional 300,000 shares of common stock of the Company upon the achievement of certain specified revenue objectives over varying periods of up to four years following the NEPSI Acquisition Date. See Note 13, "Contingent Consideration" for further discussion. The Company relied on a Monte Carlo method to determine the fair value of the contingent consideration on the closing of the acquisition of NEPSI and continues to revalue the fair value of the contingent consideration using the same method at each subsequent balance sheet date until the contingencies are resolved and the shares to be issued are determined, with the change in fair value recorded in the current period operating loss.

[0001437749-24-002041:notes:65]
The following table provides the assets and liabilities carried at fair value on a recurring basis, measured as of  December 31, 2023 and  March 31, 2023 (in thousands):

[0001437749-24-002041:notes:66]
|  |  | Total Carrying Value |  |  | Quoted Prices in Active Markets (Level 1) |  |  | Significant Other Observable Inputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |
| December 31, 2023: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash equivalents |  | $ | 9,936 |  |  | $ | 9,936 |  |  | $ | — |  |  | $ | — |  |
| Derivative liabilities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Contingent consideration |  | $ | 1,230 |  |  | $ | — |  |  | $ | — |  |  | $ | 1,230 |  |

[0001437749-24-002041:notes:67]
[same as prior period, unchanged from 0001437749-23-029753:notes:67]

[0001437749-24-002041:notes:68]
[same as prior period, unchanged from 0001437749-23-029753:notes:68]

[0001437749-24-002041:notes:69]
|  |  | Acquisition Contingent Consideration |  |
| Balance at March 31, 2022 |  | $ | 1,200 |  |
| Change in fair value |  |  | 70 |  |
| Balance at March 31, 2023 |  |  | 1,270 |  |
| Settlement of contingent consideration |  |  | (3,092 | ) |
| Change in fair value |  |  | 3,052 |  |
| Balance at December 31, 2023 |  | $ | 1,230 |  |


## amsc:AccountsReceivableTextBlock

[0001437749-24-002041:notes:70]
[same as prior period, unchanged from 0001437749-23-029753:notes:70]

[0001437749-24-002041:notes:71]
Accounts receivable at  December 31, 2023 and  March 31, 2023 consisted of the following (in thousands):

[0001437749-24-002041:notes:72]
|  |  | December 31, 2023 |  |  | March 31, 2023 |  |
| Accounts receivable (billed) |  | $ | 20,133 |  |  | $ | 20,707 |  |
| Accounts receivable (unbilled) |  |  | 4,588 |  |  |  | 9,958 |  |
| Accounts receivable, net |  | $ | 24,721 |  |  | $ | 30,665 |  |


## us-gaap:InventoryDisclosureTextBlock

[0001437749-24-002041:notes:73]
[same as prior period, unchanged from 0001437749-23-029753:notes:73]

[0001437749-24-002041:notes:74]
Inventory, net of reserves, at  December 31, 2023 and  March 31, 2023 consisted of the following (in thousands):

[0001437749-24-002041:notes:75]
|  |  | December 31, 2023 |  |  | March 31, 2023 |  |
| Raw materials |  | $ | 21,197 |  |  | $ | 16,654 |  |
| Work-in-process |  |  | 16,571 |  |  |  | 15,200 |  |
| Finished goods |  |  | 5,092 |  |  |  | 2,996 |  |
| Deferred program costs |  |  | 1,337 |  |  |  | 2,136 |  |
| Net inventory |  | $ | 44,197 |  |  | $ | 36,986 |  |

[0001437749-24-002041:notes:76]
The Company recorded inventory write-downs of $0.5 million and $0.2 million for the three months ended  December 31, 2023 and 2022, respectively. The Company recorded inventory write-downs of $1.5 million and $1.2 million for the nine months ended  December 31, 2023 and 2022, respectively. These write-downs were based on the Company's evaluation of its inventory on hand for excess quantities and obsolescence.

[0001437749-24-002041:notes:77]
Deferred program costs as of  December 31, 2023 and  March 31, 2023, primarily represent costs incurred on programs where the Company needs to complete performance obligations before the related revenue and costs will be recognized.


## amsc:PrepaidAndOtherCurrentAssetsTextBlock

[0001437749-24-002041:notes:78]
[same as prior period, unchanged from 0001437749-23-029753:notes:78]

[0001437749-24-002041:notes:79]
[same as prior period, unchanged from 0001437749-23-029753:notes:79]

[0001437749-24-002041:notes:80]
[same as prior period, unchanged from 0001437749-23-029753:notes:80]

[0001437749-24-002041:notes:81]
The Company recorded a $3.3 million receivable in Prepaid expenses and other current assets and a benefit of $1.8 million to Cost of revenues, $0.8 million to SG&A and $0.7 million to Research and development in the fiscal year ended  March 31, 2023 for the ERC that is expected to be received based on the amended filings. During the nine months ended  December 31, 2023, the Company received $3.0 million for the initial claims that were processed. The remaining balance is expected to be received during the remainder of fiscal 2023.


## us-gaap:PropertyPlantAndEquipmentDisclosureTextBlock

[0001437749-24-002041:notes:82]
[same as prior period, unchanged from 0001437749-23-029753:notes:82]

[0001437749-24-002041:notes:83]
The cost and accumulated depreciation of property, plant and equipment at  December 31, 2023 and  March 31, 2023 are as follows (in thousands):

[0001437749-24-002041:notes:84]
|  |  | December 31, 2023 |  |  | March 31, 2023 |  |
| Land |  | $ | 980 |  |  | $ | 980 |  |
| Construction in progress - equipment |  |  | 245 |  |  |  | 748 |  |
| Buildings |  |  | 5,416 |  |  |  | 5,416 |  |
| Equipment and software |  |  | 44,203 |  |  |  | 43,156 |  |
| Finance lease - right of use asset |  |  | — |  |  |  | 1 |  |
| Furniture and fixtures |  |  | 1,537 |  |  |  | 1,535 |  |
| Leasehold improvements |  |  | 6,897 |  |  |  | 6,815 |  |
| Property, plant and equipment, gross |  |  | 59,278 |  |  |  | 58,651 |  |
| Less accumulated depreciation |  |  | (48,073 | ) |  |  | (46,342 | ) |
| Property, plant and equipment, net |  | $ | 11,205 |  |  | $ | 12,309 |  |

[0001437749-24-002041:notes:85]
Depreciation expense was $0.6 million and $0.6 million for the three months ended  December 31, 2023 and 2022, respectively. Depreciation expense was $1.7 million and $2.0 million for the nine months ended  December 31, 2023 and 2022, respectively.


## us-gaap:AccountsPayableAndAccruedLiabilitiesDisclosureTextBlock

[0001437749-24-002041:notes:86]
[same as prior period, unchanged from 0001437749-23-029753:notes:86]

[0001437749-24-002041:notes:87]
Accounts payable and accrued expenses at  December 31, 2023 and  March 31, 2023 consisted of the following (in thousands):

[0001437749-24-002041:notes:88]
|  |  | December 31, 2023 |  |  | March 31, 2023 |  |
| Accounts payable |  | $ | 5,867 |  |  | $ | 13,935 |  |
| Accrued inventories in-transit |  |  | 928 |  |  |  | 2,267 |  |
| Accrued other miscellaneous expenses |  |  | 4,363 |  |  |  | 3,870 |  |
| Accrued contract loss |  |  | 55 |  |  |  | 3,464 |  |
| Advanced deposits |  |  | 1,948 |  |  |  | 5,653 |  |
| Accrued compensation |  |  | 7,385 |  |  |  | 5,430 |  |
| Income taxes payable |  |  | 322 |  |  |  | 409 |  |
| Accrued product warranty |  |  | 2,031 |  |  |  | 2,638 |  |
| Accrued restructuring |  |  | 103 |  |  |  | 717 |  |
| Total |  | $ | 23,002 |  |  | $ | 38,383 |  |

[0001437749-24-002041:notes:89]
[same as prior period, unchanged from 0001437749-23-029753:notes:89]

[0001437749-24-002041:notes:90]
[same as prior period, unchanged from 0001437749-23-029753:notes:90]

[0001437749-24-002041:notes:91]
|  |  | Three Months Ended December 31, |  |  | Nine Months Ended December 31, |  |
|  |  | 2023 |  |  | 2022 |  |  | 2023 |  |  | 2022 |  |
| Balance at beginning of period |  | $ | 1,892 |  |  | $ | 2,053 |  |  | $ | 2,638 |  |  | $ | 2,066 |  |
| Provisions for warranties during the period |  |  | 360 |  |  |  | 535 |  |  |  | 1,212 |  |  |  | 1,191 |  |
| Settlements during the period |  |  | (221 | ) |  |  | (592 | ) |  |  | (1,819 | ) |  |  | (1,261 | ) |
| Balance at end of period |  | $ | 2,031 |  |  | $ | 1,996 |  |  | $ | 2,031 |  |  | $ | 1,996 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0001437749-24-002041:notes:92]
[same as prior period, unchanged from 0001437749-23-029753:notes:92]

[0001437749-24-002041:notes:93]
The Company recorded income tax expense of $0.1 million and $0.3 million in the three and nine months ended  December 31, 2023, respectively. The Company recorded an income tax expense of $0.1 million in each of the three and nine months ended  December 31, 2022, respectively.

[0001437749-24-002041:notes:94]
Accounting for income taxes requires a two-step approach to recognizing and measuring uncertain tax positions. The first step is to evaluate the tax position for recognition by determining if, based on the technical merits, it is more likely than not the position will be sustained upon audit, including resolution of related appeals or litigation processes, if any. The second step is to measure the tax benefit as the largest amount that is more than 50% likely to be realized upon ultimate settlement. The Company re-evaluates these uncertain tax positions on a quarterly basis. The evaluation is based on factors including, but not limited to, changes in facts or circumstances, changes in tax law, effectively settled issues under audit and new audit activity.  Any changes in these factors could result in the recognition of a tax benefit or an additional charge to the tax provision. The Company did not identify any uncertain tax positions in the nine months ended  December 31, 2023 and did not have any gross unrecognized tax benefits as of  December 31, 2023.


## amsc:BusinessCombinationContingentConsiderationTextBlock

[0001437749-24-002041:notes:95]
[same as prior period, unchanged from 0001437749-23-029753:notes:95]

[0001437749-24-002041:notes:96]
On  October 1, 2020 (the "NEPSI Acquisition Date"), the Company entered into a Stock Purchase Agreement (the "NEPSI Stock Purchase Agreement") with the selling stockholders named therein. Pursuant to the terms of the NEPSI Stock Purchase Agreement and concurrently with entering into such agreement, the Company acquired all of the issued and outstanding (i) shares of capital stock of NEPSI, and (ii) membership interests of Northeast Power Realty, LLC, a New York limited liability company, which holds the real property that serves as NEPSI's headquarters (the "NEPSI Acquisition"). NEPSI is a U.S.-based global provider of medium-voltage metal-enclosed power capacitor banks and harmonic filter banks for use on electric power systems. NEPSI is a wholly-owned subsidiary of the Company and is operated by its Grid business unit. The purchase price was $26.0 million in cash and 873,657 restricted shares of common stock of the Company. As part of the transaction, the selling stockholders  may receive up to an additional 1,000,000 shares of common stock of the Company upon the achievement of certain specified revenue objectives during varying periods of up to four years following closing of the NEPSI Acquisition.  NEPSI has recognized revenues in excess of $75.0 million during the three years after the NEPSI Acquisition Date. As a result, the Company issued 399,999 shares of common stock of the Company and cash in lieu of a fractional share of common stock to the selling stockholders during the quarter ended  December 31, 2023, following certification of the achievement of specified earnout revenue objectives.

[0001437749-24-002041:notes:97]
[same as prior period, unchanged from 0001437749-23-029753:notes:98]

[0001437749-24-002041:notes:98]
[same as prior period, unchanged from 0001437749-23-029753:notes:99]

[0001437749-24-002041:notes:99]
|  |  |  | December 31, |  |  |  | September 30, |  |  |  | June 30, |  |  |  |  |  |  |  |  |  |
| Fiscal Year 2023 |  |  | 2023 |  |  |  | 2023 |  |  |  | 2023 |  |  |  |  |  |  |  |  |  |
| Revenue risk premium |  |  | 5.70 | % |  |  | 5.30 | % |  |  | 5.20 | % |  |  |  |  |  |  |  |  |
| Revenue volatility |  |  | 24.8 | % |  |  | 27.5 | % |  |  | 23 | % |  |  |  |  |  |  |  |  |
| Stock Price |  | $ | 11.14 |  |  | $ | 7.55 |  |  | $ | 6.26 |  |  |  |  |  |  |  |  |  |
| Payment delay (days) |  |  | 80 |  |  |  | 80 |  |  |  | 80 |  |  |  |  |  |  |  |  |  |
| Fair value (millions) |  | $ | 1.2 |  |  | $ | 3.5 |  |  | $ | 2.6 |  |  |  |  |  |  |  |  |  |
|  |  | March 31, |  |  | December 31, |  |  | September 30, |  |  | June 30, |  |  | March 31, |  |
| Fiscal Year 2022 |  | 2023 |  |  | 2022 |  |  | 2022 |  |  | 2022 |  |  | 2022 |  |
| Revenue risk premium |  |  | 5.30 | % |  |  | 5.30 | % |  |  | 5.20 | % |  |  | 6.60 | % |  |  | 6.50 | % |
| Revenue volatility |  |  | 25 | % |  |  | 25 | % |  |  | 25 | % |  |  | 30 | % |  |  | 33 | % |
| Stock Price |  | $ | 4.91 |  |  | $ | 3.68 |  |  | $ | 4.38 |  |  | $ | 5.18 |  |  | $ | 7.61 |  |
| Payment delay (days) |  |  | 80 |  |  |  | 80 |  |  |  | 80 |  |  |  | 80 |  |  |  | 80 |  |
| Fair value (millions) |  | $ | 1.3 |  |  | $ | 0.9 |  |  | $ | 1.1 |  |  | $ | 1.4 |  |  | $ | 1.2 |  |

[0001437749-24-002041:notes:100]
During the three and nine months ended  December 31, 2023 the Company issued 399,999 shares and cash in lieu of a fractional share of common stock related to the achievement of specified revenue objectives at a fair value of $3.1 million. One specified revenue objective, which would have earned the selling stockholders 300,000 shares of Company common stock, was not achieved, leaving 300,000 shares of common stock remaining for potential issuance upon the achievement of the last specified revenue objective by  September 30, 2024. The Company recorded losses of $0.9 million and $3.1 million resulting from the increases in the fair value of the contingent consideration in the three and nine months ended  December 31, 2023, respectively.


## us-gaap:DebtDisclosureTextBlock

[0001437749-24-002041:notes:101]
14. Debt

[0001437749-24-002041:notes:102]
As part of the acquisition of Neeltran, the Company identified four equipment financing agreements that Neeltran had entered into prior to the acquisition of Neeltran on  May 6, 2021. The current debt balance is less than $0.1 million as of  December 31, 2023 and was $0.1 million as of  March 31, 2023.


## us-gaap:LesseeOperatingLeasesTextBlock

[0001437749-24-002041:notes:103]
[same as prior period, unchanged from 0001437749-23-029753:notes:104]

[0001437749-24-002041:notes:104]
[same as prior period, unchanged from 0001437749-23-029753:notes:105]

[0001437749-24-002041:notes:105]
[same as prior period, unchanged from 0001437749-23-029753:notes:106]

[0001437749-24-002041:notes:106]
[same as prior period, unchanged from 0001437749-23-029753:notes:107]

[0001437749-24-002041:notes:107]
[same as prior period, unchanged from 0001437749-23-029753:notes:108]

[0001437749-24-002041:notes:108]
[same as prior period, unchanged from 0001437749-23-029753:notes:109]

[0001437749-24-002041:notes:109]
[same as prior period, unchanged from 0001437749-23-029753:notes:110]

[0001437749-24-002041:notes:110]
As of  December 31, 2023, the right-of-use asset related to the finance lease, net of accumulated amortization is $0.0 million, and is included in the property and equipment, net on the Company's condensed consolidated balance sheet.

[0001437749-24-002041:notes:111]
[same as prior period, unchanged from 0001437749-23-029753:notes:112]

[0001437749-24-002041:notes:112]
Supplemental balance sheet information related to leases at  December 31, 2023, and  March 31, 2023 are as follows (in thousands):

[0001437749-24-002041:notes:113]
|  |  | December 31, 2023 |  |  | March 31, 2023 |  |
| Leases: |  |  |  |  |  |  |  |  |
| Right-of-use assets - Financing |  | $ | - |  |  |  | 1 |  |
| Right-of-use assets - Operating |  |  | 2,401 |  |  |  | 2,857 |  |
| Total right-of-use assets |  |  | 2,401 |  |  |  | 2,858 |  |
| Lease liabilities - ST Financing |  | $ | - |  |  |  | 1 |  |
| Lease liabilities - ST Operating |  |  | 680 |  |  |  | 807 |  |
| Lease liabilities - LT Operating |  |  | 1,861 |  |  |  | 2,184 |  |
| Total lease liabilities |  | $ | 2,541 |  |  |  | 2,992 |  |
| Weighted-average remaining lease term |  |  | 3.5 years |  |  |  | 3.95 years |  |
| Weighted-average discount rate |  |  | 8.68 | % |  |  | 6.46 | % |

[0001437749-24-002041:notes:114]
The costs related to the Company's finance lease are not material. The costs related to the Company's operating leases for the three and nine months ended  December 31, 2023 and 2022 are as follows (in thousands):

[0001437749-24-002041:notes:115]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | December 31, 2023 |  |  | December 31, 2023 |  |
| Operating Leases: |  |  |  |  |  |  |  |  |
| Operating lease costs - fixed |  | $ | 303 |  |  | $ | 817 |  |
| Operating lease costs - variable |  |  | 39 |  |  |  | 119 |  |
| Short-term lease costs |  |  | 37 |  |  |  | 111 |  |
| Total lease costs |  | $ | 379 |  |  | $ | 1,047 |  |

[0001437749-24-002041:notes:116]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | December 31, 2022 |  |  | December 31, 2022 |  |
| Operating Leases: |  |  |  |  |  |  |  |  |
| Operating lease costs - fixed |  | $ | 256 |  |  | $ | 765 |  |
| Operating lease costs - variable |  |  | 41 |  |  |  | 118 |  |
| Short-term lease costs |  |  | 30 |  |  |  | 92 |  |
| Total lease costs |  | $ | 327 |  |  | $ | 975 |  |

[0001437749-24-002041:notes:117]
[same as prior period, unchanged from 0001437749-23-029753:notes:118]

[0001437749-24-002041:notes:118]
|  |  | Leases |  |
| Year ending March 31, |  |  |  |  |
| 2024 |  | $ | 234 |  |
| 2025 |  |  | 841 |  |
| 2026 |  |  | 793 |  |
| 2027 |  |  | 646 |  |
| 2028 |  |  | 392 |  |
| Thereafter |  |  | 15 |  |
| Total minimum lease payments |  |  | 2,921 |  |
| Less: interest |  |  | (380 | ) |
| Present value of lease liabilities |  |  | 2,541 |  |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001437749-24-002041:notes:119]
16. Commitments and Contingencies

[0001437749-24-002041:notes:120]
Legal Contingencies

[0001437749-24-002041:notes:121]
From time to time, the Company is involved in legal and administrative proceedings and claims of various types. The Company records a liability in its condensed consolidated financial statements for these matters when a loss is known or considered probable and the amount can be reasonably estimated. The Company reviews these estimates each accounting period as additional information is known and adjusts the loss provision when appropriate. If a matter is both probable to result in a liability and the amounts of loss can be reasonably estimated, the Company estimates and discloses the possible loss or range of loss to the extent necessary to make the condensed consolidated financial statements not misleading. If the loss is not probable or cannot be reasonably estimated, a liability is not recorded in its condensed consolidated financial statements.

[0001437749-24-002041:notes:122]
Other

[0001437749-24-002041:notes:123]
The Company enters into long-term construction contracts with customers that require the Company to obtain performance bonds. The Company is required to deposit an amount equivalent to some or all the face amount of the performance bonds into an escrow account until the termination of the bond. When the performance conditions are met, amounts deposited as collateral for the performance bonds are returned to the Company. In addition, the Company has various contractual arrangements in which minimum quantities of goods or services have been committed to be purchased on an annual basis.

[0001437749-24-002041:notes:124]
As of  December 31, 2023, the Company had $0.4 million of restricted cash included in long-term assets and $0.7 million of restricted cash included in current assets. As of  March 31, 2023, the Company had $0.6 million of restricted cash included in long term assets and $1.7 million of restricted cash included in current assets. These amounts included in restricted cash primarily represent deposits to secure letters of credit for various supply contracts and long-term projects or collateral deposits. These deposits are held in interest bearing accounts.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001437749-24-002041:notes:125]
[same as prior period, unchanged from 0001437749-23-029753:notes:126]

[0001437749-24-002041:notes:126]
[same as prior period, unchanged from 0001437749-23-029753:notes:127]

[0001437749-24-002041:notes:127]
On  January 24, 2023, the Company approved a plan to reduce its global workforce by approximately 5%, effective as of such date. The purpose of the workforce reduction was to reduce operating expenses to better align with the Company’s current revenues. In fiscal 2022, the Company recorded restructuring charges of $1.0 million as a result of this reduction in force, which was comprised of severance pay. All amounts related to these restructuring activities are expected to be paid by  March 31, 2024.

[0001437749-24-002041:notes:128]
The following table presents restructuring charges and cash payments during the nine months ended  December 31, 2023 and year ended  March 31, 2023 (in thousands):

[0001437749-24-002041:notes:129]
|  |  | Severance pay |  |
|  |  | and benefits |  |
| Accrued restructuring balance at April 1, 2023 |  | $ | 717 |  |
| Charges to operations |  |  | (14 | ) |
| Cash payments |  |  | (600 | ) |
| Accrued restructuring balance at December 31, 2023 |  | $ | 103 |  |

[0001437749-24-002041:notes:130]
[same as prior period, unchanged from 0001437749-23-029753:notes:131]

[0001437749-24-002041:notes:131]
[same as prior period, unchanged from 0001437749-23-029753:notes:132]


## us-gaap:SegmentReportingDisclosureTextBlock

[0001437749-24-002041:notes:132]
[same as prior period, unchanged from 0001437749-23-029753:notes:133]

[0001437749-24-002041:notes:133]
[same as prior period, unchanged from 0001437749-23-029753:notes:134]

[0001437749-24-002041:notes:134]
[same as prior period, unchanged from 0001437749-23-029753:notes:135]

[0001437749-24-002041:notes:135]
[same as prior period, unchanged from 0001437749-23-029753:notes:136]

[0001437749-24-002041:notes:136]
[same as prior period, unchanged from 0001437749-23-029753:notes:137]

[0001437749-24-002041:notes:137]
|  |  | Three Months Ended December 31, |  |  | Nine Months Ended December 31, |  |
|  |  | 2023 |  |  | 2022 |  |  | 2023 |  |  | 2022 |  |
| Revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Grid |  | $ | 33,603 |  |  | $ | 20,809 |  |  | $ | 87,854 |  |  | $ | 66,337 |  |
| Wind |  |  | 5,750 |  |  |  | 3,072 |  |  |  | 15,757 |  |  |  | 7,904 |  |
| Total |  | $ | 39,353 |  |  | $ | 23,881 |  |  | $ | 103,611 |  |  | $ | 74,241 |  |

[0001437749-24-002041:notes:138]
|  |  | Three Months Ended December 31, |  |  | Nine Months Ended December 31, |  |
|  |  | 2023 |  |  | 2022 |  |  | 2023 |  |  | 2022 |  |
| Operating income (loss): |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Grid |  | $ | 268 |  |  | $ | (7,064 | ) |  | $ | (2,383 | ) |  | $ | (20,840 | ) |
| Wind |  |  | 286 |  |  |  | (924 | ) |  |  | (112 | ) |  |  | (2,178 | ) |
| Unallocated corporate expenses |  |  | (1,992 | ) |  |  | (1,221 | ) |  |  | (6,646 | ) |  |  | (3,152 | ) |
| Total |  | $ | (1,438 | ) |  | $ | (9,209 | ) |  | $ | (9,141 | ) |  | $ | (26,170 | ) |

[0001437749-24-002041:notes:139]
[same as prior period, unchanged from 0001437749-23-029753:notes:140]

[0001437749-24-002041:notes:140]
Unallocated corporate expenses consisted of net losses of $0.9 million and $3.1 million resulting from the increases in the fair value of contingent consideration in the three and nine months ended  December 31, 2023, respectively. There are 300,000 shares remaining for potential issuance upon the achievement of the last specified revenue objective under the NEPSI Stock Purchase Agreement by  September 30, 2024. Unallocated corporate expenses consisted of a gain on contingent consideration of $0.2 million and $0.3 million in the three and nine months ended  December 31, 2022, respectively. Additionally, unallocated corporate expenses consisted of stock-based compensation expense of $1.1 million and $1.4 million in the three months ended  December 31, 2023 and 2022, respectively, and $3.6 million and $3.5 million in the nine months ended  December 31, 2023 and 2022, respectively.

[0001437749-24-002041:notes:141]
Total assets for the two business segments as of  December 31, 2023 and  March 31, 2023, are as follows (in thousands):

[0001437749-24-002041:notes:142]
|  |  | December 31, 2023 |  |  | March 31, 2023 |  |
| Grid |  | $ | 128,395 |  |  | $ | 135,296 |  |
| Wind |  |  | 12,933 |  |  |  | 14,361 |  |
| Corporate assets |  |  | 25,015 |  |  |  | 25,904 |  |
| Total |  | $ | 166,343 |  |  | $ | 175,561 |  |


## us-gaap:NewAccountingPronouncementsAndChangesInAccountingPrinciplesTextBlock

[0001437749-24-002041:notes:143]
19. Recent Accounting Pronouncements

[0001437749-24-002041:notes:144]
In  June 2016, the Financial Accounting Standards Board ("FASB") issued Accounting Standards Update ("ASU") 2016-13, Financial Instruments-Credit Losses (Topic 326): Measurement of Credit Losses on Financial Instruments. The amendments in ASU 2016-13 will provide more decision-useful information about the expected credit losses on financial instruments and other commitments to extend credit held by a reporting entity at each reporting date. Following the release of ASU 2019-10 in  November 2019, the effective date, as long as the Company remains a smaller reporting company, was annual reporting periods beginning after  December 15, 2022.  As of  April 1, 2023, the Company has adopted ASU 2016-13 and noted no material impact on its condensed consolidated financial statements.

[0001437749-24-002041:notes:145]
In  October 2021, the FASB issued ASU 2021-08, Business Combinations (Topic 805): Accounting for Contract Assets and Contract Liabilities from Contracts with Customers. The amendments in ASU 2021-08 will improve the accounting for acquired revenue contracts with customers in a business combination. Following the release of ASU 2021-08 in  October 2021, the effective date was annual reporting periods beginning after  December 15, 2022. As of  April 1, 2023, the Company has adopted ASU 2021-08 and noted no material impact on its condensed consolidated financial statements.

[0001437749-24-002041:notes:146]
In  November 2023, the FASB issued ASU 2023-07, Segment Reporting (Topic 280): Improvements to Reportable Segment Disclosures. The amendments in ASU 2023-07 improve the disclosures about a public entity’s reportable segments and address requests from investors for additional, more detailed information about a reportable segment’s expenses. Following the release of ASU 2023-07 in  November 2023, the effective date will be annual reporting periods beginning after  December 15, 2024. As of  December 31, 2023, the Company is evaluating the impact on its condensed consolidated financial statements.

[0001437749-24-002041:notes:147]
In  December 2023, the FASB issued ASU 2023-09, Income Taxes (Topic 740): Improvements to Income Tax Disclosures. The amendments in ASU 2023-09 address investor requests for more transparency about income tax information through improvements to income tax disclosures primarily related to the rate reconciliation and income taxes paid information. Following the release of ASU 2023-09 in  December 2023, the effective date will be annual reporting periods beginning after  December 15, 2024. As of  December 31, 2023, the Company is evaluating the impact on its condensed consolidated financial statements.


## us-gaap:SubsequentEventsTextBlock

[0001437749-24-002041:notes:148]
20. Subsequent Events

[0001437749-24-002041:notes:149]
The Company has performed an evaluation of subsequent events through the time of filing this Quarterly Report on Form 10-Q with the SEC and has determined that there are no such events to report.


## ecd:MtrlTermsOfTrdArrTextBlock

[0001437749-24-002041:notes:150]
| ITEM 5. | OTHER INFORMATION |

[0001437749-24-002041:notes:151]
On  December 13, 2023, Daniel P. McGahn, Chairman, President and Chief Executive Officer, adopted a Rule 10b5-1 trading arrangement that is intended to satisfy the affirmative defense of Rule 10b5-1(c) for the sale of up to 57,724 shares of the Company’s common stock until the earlier of (i)  June 28, 2024, or (ii) the date in which all shares under the trading arrangement are sold.

[0001437749-24-002041:notes:152]
On  December 6, 2023, John W. Kosiba, Jr., Senior Vice President, Chief Financial Officer and Treasurer, adopted a Rule 10b5-1 trading arrangement that is intended to satisfy the affirmative defense of Rule 10b5-1(c) for the sale of up to 61,000 shares of the Company’s common stock until the earlier of (i)  June 28, 2024, or (ii) the date in which all shares under the trading arrangement are sold.
