# AMSC 8-K — 0001437749-24-002040 filed 2024-01-24

## item codes, every 8-K on or before 2024-01-24

- 2024-01-24 0001437749-24-002040 — 2.02, 9.01
- 2023-11-01 0001437749-23-029749 — 2.02, 9.01
- 2023-08-11 0001437749-23-023329 — 5.07
- 2023-08-09 0001437749-23-022786 — 2.02, 9.01
- 2023-06-21 0001193125-23-171201 — 5.02, 9.01
- 2023-05-31 0001437749-23-016264 — 2.02, 9.01
- 2023-02-01 0001437749-23-002268 — 2.02, 9.01
- 2022-11-01 0001437749-22-025365 — 2.02, 9.01
- 2022-08-05 0001193125-22-213651 — 5.02, 5.07, 9.01
- 2022-08-03 0001437749-22-018628 — 2.02, 9.01
- 2022-06-10 0001437749-22-014780 — 5.02, 9.01
- 2022-06-01 0001437749-22-014033 — 2.02, 9.01
- 2022-02-02 0001437749-22-002207 — 2.02, 9.01
- 2021-11-08 0001437749-21-025697 — 2.02, 9.01
- 2021-08-04 0001437749-21-018522 — 2.02, 9.01
- 2021-08-02 0001193125-21-233260 — 5.07
- 2021-06-02 0001437749-21-013955 — 2.02, 9.01
- 2021-05-25 0001437749-21-013279 — 5.02, 9.01
- 2021-05-21 0001193125-21-168626 — 8.01, 9.01
- 2021-05-10 0001193125-21-156251 — 1.01, 9.01
- 2021-02-26 0001193125-21-060434 — 8.01, 9.01
- 2021-02-03 0001437749-21-001859 — 2.02, 9.01
- 2021-02-01 0001437749-21-001681 — 5.03, 9.01
- 2020-12-14 0001437749-20-025291 — 9.01 — amendment, the index does not say of what
- 2020-11-04 0001437749-20-022520 — 2.02, 9.01
- 2020-10-26 0001193125-20-276900 — 8.01, 9.01
- 2020-10-05 0001437749-20-020735 — 2.02
- 2020-10-05 0001437749-20-020734 — 1.01, 2.01, 3.02, 9.01
- 2020-10-02 0001437749-20-020660 — 8.01
- 2020-09-16 0001437749-20-019767 — 8.01
- 2020-08-05 0001437749-20-016665 — 2.02, 5.07, 9.01
- 2020-06-02 0001437749-20-012274 — 2.02, 9.01
- 2020-05-27 0001437749-20-011837 — 5.02, 9.01
- 2020-02-05 0001437749-20-001788 — 2.02, 9.01
- 2019-11-05 0001437749-19-021590 — 2.02, 9.01
- 2019-08-06 0001437749-19-015631 — 2.02, 9.01
- 2019-08-06 0001193125-19-214189 — 5.02, 5.07, 9.01
- 2019-06-05 0001437749-19-011476 — 2.02, 5.02, 9.01
- 2019-05-24 0001437749-19-010833 — 5.02
- 2019-02-05 0001628280-19-000964 — 2.02, 8.01, 9.01
- 2018-11-06 0001628280-18-013765 — 2.02, 9.01
- 2018-10-31 0001628280-18-013204 — 1.01
- 2018-08-01 0001628280-18-010196 — 5.07
- 2018-07-31 0001628280-18-009846 — 2.02, 9.01
- 2018-07-09 0001193125-18-214745 — 1.01, 9.01
- 2018-07-03 0001628280-18-009075 — 5.02, 9.01
- 2018-06-14 0001628280-18-007877 — 5.02
- 2018-06-06 0001628280-18-007643 — 2.02, 9.01
- 2018-04-10 0001628280-18-004141 — 5.02
- 2018-04-03 0001628280-18-003952 — 2.01, 9.01
- 2018-02-05 0001628280-18-000989 — 2.02, 9.01
- 2018-02-01 0001628280-18-000826 — 1.01, 9.01
- 2017-11-07 0001628280-17-011076 — 2.02, 9.01
- 2017-09-26 0001628280-17-009444 — 3.02, 8.01
- 2017-08-08 0001628280-17-008329 — 2.02, 9.01
- 2017-08-01 0001628280-17-007765 — 5.02, 5.07
- 2017-07-03 0001193125-17-221140 — 5.02, 9.01
- 2017-05-26 0001193125-17-185503 — 8.01, 9.01
- 2017-05-25 0001628280-17-005914 — 2.02, 9.01 — amendment of 0001628280-17-005884
- 2017-05-25 0001628280-17-005884 — 2.02, 9.01
- 2017-05-10 0001193125-17-165924 — 8.01, 9.01
- 2017-05-09 0001193125-17-164273 — 5.02
- 2017-05-04 0001193125-17-158639 — 1.02, 8.01
- 2017-04-26 0001193125-17-139493 — 2.02, 9.01
- 2017-04-04 0001193125-17-109748 — 2.05, 5.02, 9.01
- 2017-02-06 0001628280-17-000899 — 2.02, 9.01
- 2017-01-27 0001193125-17-021808 — 1.01, 2.02, 9.01
- 2016-11-02 0001628280-16-020598 — 2.02, 9.01
- 2016-09-16 0001193125-16-712301 — 5.02
- 2016-08-23 0001193125-16-688767 — 8.01
- 2016-08-09 0001628280-16-018763 — 2.02, 9.01
- 2016-08-02 0001193125-16-668417 — 5.02, 5.07, 9.01
- 2016-05-31 0001564590-16-020114 — 2.02, 9.01
- 2016-05-18 0001193125-16-594515 — 5.02
- 2016-03-08 0001193125-16-496113 — 1.01
- 2016-02-09 0001193125-16-454775 — 2.02, 9.01
- 2015-12-17 0001193125-15-405566 — 1.01
- 2015-11-03 0001193125-15-363413 — 2.02, 9.01
- 2015-08-31 0001193125-15-307558 — 1.01
- 2015-08-05 0001193125-15-277824 — 2.02, 9.01
- 2015-07-31 0001193125-15-273009 — 5.07
- 2015-06-26 0001193125-15-237190 — 5.02
- 2015-06-09 0001193125-15-218028 — 8.01
- 2015-05-28 0001193125-15-202933 — 2.02, 9.01
- 2015-04-28 0001193125-15-153319 — 8.01, 9.01
- 2015-04-23 0001193125-15-144123 — 2.02, 8.01, 9.01
- 2015-04-23 0001193125-15-143608 — 8.01
- 2015-04-10 0001193125-15-126160 — 8.01
- 2015-03-24 0001193125-15-103436 — 5.03, 9.01
- 2015-03-18 0001193125-15-097034 — 5.07
- 2015-02-05 0001193125-15-034499 — 2.02, 9.01
- 2015-01-29 0001193125-15-024629 — 2.02, 9.01
- 2015-01-21 0001193125-15-016287 — 3.01, 8.01
- 2015-01-06 0001193125-15-002902 — 5.02
- 2014-12-22 0001193125-14-450591 — 1.01, 2.03, 3.02, 9.01
- 2014-11-13 0001193125-14-410207 — 1.01, 9.01
- 2014-11-07 0001193125-14-402383 — 1.02, 7.01, 9.01
- 2014-11-06 0001193125-14-399779 — 2.02, 9.01
- 2014-10-01 0001193125-14-360072 — 2.02, 8.01, 9.01
- 2014-09-04 0001193125-14-331411 — 8.01
- 2014-08-21 0001193125-14-317133 — 1.01
- 2014-08-06 0001193125-14-298306 — 5.02, 5.07, 9.01
- 2014-08-05 0001193125-14-294647 — 2.02, 9.01
- 2014-07-16 0001193125-14-269902 — 8.01
- 2014-06-23 0001193125-14-244592 — 3.02, 8.01
- 2014-06-05 0001193125-14-226459 — 2.02, 9.01
- 2014-06-05 0001193125-14-226457 — 1.01, 9.01
- 2014-03-19 0001193125-14-106558 — 2.05
- 2014-03-03 0001193125-14-078917 — 1.01, 3.02, 9.01
- 2014-02-28 0001193125-14-077480 — 8.01, 9.01
- 2014-02-06 0001193125-14-037960 — 2.02, 8.01, 9.01
- 2013-11-20 0001193125-13-447829 — 3.02, 8.01
- 2013-11-18 0001193125-13-444697 — 1.01, 2.03, 3.02, 9.01
- 2013-11-07 0001193125-13-431705 — 2.02, 9.01
- 2013-10-09 0001193125-13-395362 — 1.01, 2.03, 3.02, 9.01
- 2013-09-25 0001193125-13-378481 — 5.02, 9.01
- 2013-08-21 0001193125-13-341566 — 4.01, 9.01
- 2013-08-07 0001193125-13-323082 — 2.02, 9.01
- 2013-08-02 0001193125-13-317278 — 5.02, 5.07
- 2013-06-14 0001193125-13-258758 — 2.02, 9.01
- 2013-04-01 0001193125-13-136714 — 2.02, 8.01, 9.01
- 2013-02-20 0001193125-13-067218 — 5.02, 9.01
- 2013-02-14 0001193125-13-060131 — 1.01, 9.01
- 2013-02-11 0001193125-13-048784 — 2.02, 9.01
- 2013-01-08 0001193125-13-006861 — 5.02, 9.01
- 2012-12-21 0001193125-12-511592 — 1.01, 2.03, 3.02, 9.01
- 2012-11-28 0001193125-12-483317 — 2.05, 5.02, 7.01, 9.01
- 2012-11-06 0001193125-12-453359 — 2.02, 9.01
- 2012-08-02 0001193125-12-330534 — 2.02, 9.01
- 2012-07-27 0001193125-12-318790 — 5.02, 5.07, 9.01
- 2012-06-06 0001193125-12-261030 — 1.01, 2.02, 2.03, 3.02, 5.02, 9.01
- 2012-05-09 0001193125-12-222210 — 5.02
- 2012-04-20 0001193125-12-172045 — 8.01
- 2012-04-13 0001193125-12-162694 — 2.02, 8.01, 9.01
- 2012-04-04 0001193125-12-149102 — 1.01, 2.02, 2.03, 3.02, 9.01
- 2012-02-09 0001193125-12-048009 — 2.02, 9.01
- 2012-02-06 0001193125-12-041344 — 5.07 — amendment of 0000950123-11-102495
- 2011-12-08 0000950123-11-102495 — 5.07
- 2011-11-29 0000950123-11-100822 — 2.05
- 2011-11-09 0000950123-11-096775 — 2.02, 9.01
- 2011-10-31 0000950123-11-093390 — 1.02, 9.01
- 2011-10-07 0000950123-11-089221 — 8.01
- 2011-10-03 0000950123-11-088315 — 7.01
- 2011-09-23 0000950123-11-086288 — 2.02, 9.01
- 2011-09-15 0000950123-11-084585 — 7.01
- 2011-09-06 0000950123-11-082736 — 7.01
- 2011-08-18 0000950123-11-078526 — 3.01, 7.01, 9.01
- 2011-08-11 0000950123-11-075905 — 5.02
- 2011-08-11 0000950123-11-075904 — 2.02, 2.05, 9.01
- 2011-07-11 0000950123-11-064934 — 2.02, 4.02, 9.01
- 2011-06-30 0000950123-11-063287 — 1.01, 3.02, 9.01
- 2011-06-21 0000950123-11-060491 — 3.01, 7.01, 9.01
- 2011-06-13 0000950123-11-058656 — 1.01, 9.01
- 2011-05-24 0000950123-11-053517 — 5.02, 9.01
- 2011-04-05 0001299933-11-001020 — 2.02, 9.01
- 2011-03-15 0000950123-11-025580 — 5.02
- 2011-03-14 0000950123-11-025205 — 1.01, 3.02, 9.01
- 2011-02-01 0001299933-11-000333 — 2.02, 9.01
- 2010-11-12 0000950123-10-104604 — 8.01, 9.01
- 2010-11-08 0000950123-10-102424 — 8.01, 9.01
- 2010-11-02 0001299933-10-003878 — 2.02, 9.01
- 2010-09-15 0000950123-10-086373 — 1.01, 9.01 — amendment, the index does not say of what
- 2010-08-06 0000950123-10-074362 — 5.07
- 2010-07-29 0001299933-10-002860 — 2.02, 9.01
- 2010-05-17 0000950123-10-050424 — 1.01, 9.01
- 2010-05-14 0001299933-10-001972 — 5.02
- 2010-05-13 0001299933-10-001943 — 2.02, 9.01
- 2010-02-08 0001299933-10-000506 — 8.01
- 2010-02-02 0001299933-10-000386 — 2.02, 9.01
- 2009-12-15 0001299933-09-004928 — 5.02
- 2009-10-29 0001299933-09-004267 — 2.02, 9.01
- 2009-08-12 0001193125-09-173026 — 5.02, 9.01
- 2009-07-30 0001193125-09-158842 — 1.01, 2.02, 9.01
- 2009-05-15 0001193125-09-113158 — 5.02
- 2009-05-14 0001193125-09-110619 — 2.02, 9.01
- 2009-04-20 0001193125-09-082590 — 5.02
- 2009-02-03 0001193125-09-016992 — 2.02, 9.01
- 2009-01-22 0001193125-09-009777 — 2.02, 9.01
- 2008-11-04 0001193125-08-223730 — 2.02, 9.01
- 2008-08-11 0001193125-08-173616 — 8.01
- 2008-08-07 0001193125-08-170325 — 8.01
- 2008-08-05 0001193125-08-165888 — 2.02, 9.01
- 2008-06-11 0001193125-08-132049 — 1.01, 9.01
- 2008-05-20 0001193125-08-119372 — 5.02, 9.01
- 2008-05-08 0001193125-08-107052 — 2.02, 9.01
- 2008-01-31 0001193125-08-016233 — 2.02, 9.01
- 2008-01-30 0001193125-08-015494 — 5.03, 9.01
- 2007-11-01 0001193125-07-231866 — 2.02, 9.01
- 2007-10-31 0001193125-07-231225 — 2.05
- 2007-10-29 0001193125-07-228284 — 5.03, 9.01
- 2007-09-27 0001193125-07-208950 — 5.02
- 2007-08-09 0001193125-07-176553 — 2.02, 9.01
- 2007-08-07 0001193125-07-173829 — 1.01, 5.02, 9.01
- 2007-07-02 0001193125-07-148303 — 5.02, 9.01
- 2007-06-20 0001193125-07-139068 — 8.01, 9.01
- 2007-06-14 0001193125-07-135550 — 9.01 — amendment of 0001193125-07-005297
- 2007-06-14 0001193125-07-135340 — 5.02
- 2007-05-24 0001193125-07-122148 — 2.02, 9.01
- 2007-03-30 0001193125-07-070154 — 2.05, 9.01
- 2007-03-23 0001193125-07-062978 — 9.01 — amendment of 0001193125-07-005297
- 2007-02-01 0001193125-07-017883 — 2.02, 9.01
- 2007-01-11 0001193125-07-005297 — 2.01, 9.01
- 2006-12-05 0001181431-06-067500 — 5.02
- 2006-11-29 0001193125-06-243360 — 1.01, 3.02, 9.01
- 2006-11-02 0001193125-06-221464 — 2.02, 9.01
- 2006-09-21 0001193125-06-194526 — 5.02
- 2006-08-08 0001193125-06-164819 — 2.02, 9.01
- 2006-08-02 0001193125-06-159113 — 1.01, 9.01
- 2006-07-28 0001193125-06-156172 — 1.01
- 2006-06-26 0001193125-06-135913 — 1.01, 3.03, 9.01
- 2006-05-11 0001193125-06-108489 — 2.02, 9.01
- 2006-05-05 0001193125-06-102270 — 1.01, 9.01
- 2006-05-01 0001193125-06-094941 — 2.02, 2.06, 9.01
- 2006-02-24 0001193125-06-038281 — 5.02, 9.01
- 2006-02-02 0001181431-06-007665 — 2.02, 9.01
- 2005-11-09 0001181431-05-060304 — 2.02, 9.01
- 2005-08-04 0001181431-05-044420 — 2.02, 9.01
- 2005-07-28 0001193125-05-151272 — 5.02, 9.01
- 2005-06-14 0001193125-05-125148 — 5.02, 9.01
- 2005-05-12 0001181431-05-027410 — 2.02, 9.01
- 2005-05-10 0001193125-05-102795 — 1.01
- 2005-04-05 0001181431-05-020680 — 1.01, 2.02, 3.02, 9.01
- 2005-02-03 0001181431-05-006678 — 2.02, 9.01
- 2004-11-09 0001181431-04-051381 — 2.02, 9.01 — amendment, the index does not say of what
- 2004-11-04 0001181431-04-050706 — 2.02, 9.01
- 2004-10-15 0001193125-04-172458 — 1.01, 9.01
- 2004-08-05 0001193125-04-132162 — 12
- 2004-05-13 0001193125-04-086853 — 12
- 2004-02-05 0001193125-04-015060 — 12
- 2003-11-06 0001193125-03-074000 — 12
- 2003-09-26 0001193125-03-054624 — 5
- 2003-08-06 0001193125-03-029666 — 12
- 2003-05-14 0000927016-03-002619 — 9
- 2002-12-31 0000927016-02-006114 — 5
- 2000-01-24 0000927016-00-000150 — 5, 7
- 1998-11-02 0000950135-98-005625 — 5, 7
- 1998-03-24 0000950135-98-001743 — 5, 7
- 1997-09-05 0000950135-97-003729 — 5, 7
- 1997-06-23 0000950135-97-002785 — 1 — amendment of 0000950135-97-001972
- 1997-04-23 0000950135-97-001972 — 2, 7

## late-filing notifications on or before 2024-01-24

- 2011-08-10 0000950123-11-075677 — NT 10-Q, for the period ended 2011-06-30
- 2011-05-31 0000950123-11-055465 — NT 10-K, for the period ended 2011-03-31

## item 2.02 — earnings release, exhibit 99.1

[0001437749-24-002040:8k_2_02:1]
EX-99.1
2
ex_599688.htm
EXHIBIT 99.1

[0001437749-24-002040:8k_2_02:2]
ex_599688.htm

[0001437749-24-002040:8k_2_02:3]
Exhibit 99.1

[0001437749-24-002040:8k_2_02:4]
AMSC Reports Third Quarter Fiscal Year 2023 Financial Results and Provides Business Outlook

[0001437749-24-002040:8k_2_02:5]
|  | Q3 Financial Highlights: |
|  | • Revenues Increased Over 60% Year Over Year to $39 Million • Reported 25% Gross Margin and Achieved Non-GAAP Net Income • Generated $1.3 Million of Operating Cash Flow |

[0001437749-24-002040:8k_2_02:6]
Company to host conference call tomorrow, January 25th at 10:00 am ET

[0001437749-24-002040:8k_2_02:7]
Ayer, MA – January 24, 2024 – AMSC (Nasdaq: AMSC), a leading system provider of megawatt-scale power resiliency solutions that orchestrate the rhythm and harmony of power on the grid™ and protect and expand the capability and resiliency of our Navy’s fleet, today reported financial results for its third quarter of fiscal year 2023 ended December 31, 2023.

[0001437749-24-002040:8k_2_02:8]
Revenues for the third quarter of fiscal 2023 were $39.4 million compared with $23.9 million for the same period of fiscal 2022. The year-over-year increase was driven by increased shipments of new energy power systems and electrical control system shipments, versus the year ago period.

[0001437749-24-002040:8k_2_02:9]
AMSC’s net loss for the third quarter of fiscal 2023 was $1.6 million, or $0.06 per share, compared to a net loss of $9.6 million, or $0.34 per share, for the same period of fiscal 2022.  The Company’s non-GAAP net income for the third quarter of fiscal 2023 was $0.9 million, or $0.03 per share, compared with a non-GAAP net loss of $7.7 million, or $0.27 per share, in the same period of fiscal 2022. Please refer to the financial table below for a reconciliation of GAAP to non-GAAP results.

[0001437749-24-002040:8k_2_02:10]
Cash, cash equivalents, and restricted cash on December 31, 2023, totaled $25.0 million, compared with $24.0 million at September 30, 2023.

[0001437749-24-002040:8k_2_02:11]
"We outperformed expectations during the third quarter of fiscal 2023 with year-over-year revenue growth of over 60%, reporting non-GAAP net income for a second consecutive quarter and $1.3 million in operating cash flow. Our team achieved this thanks to strong customer demand, our pricing initiatives and a favorable product mix,” said Daniel P. McGahn, Chairman, President and CEO, AMSC. “We booked over $34 million of new orders during the quarter including our second 3MW ECS order from Inox Wind. We ended the quarter with over $137 million in 12-month backlog, nearly 25% year-over-year growth. Given this backlog position, strong demand in our end markets, and shortening customer lead times, we believe we are very well positioned for the fourth fiscal quarter which will end March 2024. We are proud of these results, which represent our deliberate diversification into growing markets, and look forward to delivering year over year revenue growth for fiscal 2023."

[0001437749-24-002040:8k_2_02:12]
| AMSC Reports Q3 FY23 Results | Page 2 |

[0001437749-24-002040:8k_2_02:13]
Business Outlook

[0001437749-24-002040:8k_2_02:14]
For the fourth quarter ending March 31, 2024, AMSC expects that its revenues will be in the range of $36.0 million to $40.0 million. The Company’s net loss for the fourth quarter of fiscal 2023 is expected not to exceed $3.5 million, or $0.12 per share. The Company’s net loss guidance assumes no changes in fair value of contingent consideration. The Company's non-GAAP net loss (as defined below) is expected not to exceed $1.7 million, or $0.06 per share. The Company expects operating cash flow to be breakeven to a positive cash generation of $2.0 million in the fourth quarter of fiscal 2023. The Company expects cash, cash equivalents, and restricted cash on March 31, 2024, to be no less than $25 million.

[0001437749-24-002040:8k_2_02:15]
Conference Call Reminder

[0001437749-24-002040:8k_2_02:16]
In conjunction with this announcement, AMSC management will participate in a conference call with investors beginning at 10:00 a.m. Eastern Time on Thursday, January 25, 2024, to discuss the Company’s financial results and business outlook. Those who wish to listen to the live or archived conference call webcast should visit the “Investors” section of the Company’s website at https://ir.amsc.com. The live call can be accessed by dialing 1-844-481-2802 or 1-412-317- 0675 and asking to join the AMSC call. A replay of the call may be accessed 2 hours following the call by dialing 1-877-344-7529 and using conference passcode 8370084.

[0001437749-24-002040:8k_2_02:17]
About AMSC (Nasdaq: AMSC)

[0001437749-24-002040:8k_2_02:18]
AMSC generates the ideas, technologies and solutions that meet the world’s demand for smarter, cleaner … better energy™. Through its Gridtec™ Solutions, AMSC provides the engineering planning services and advanced grid systems that optimize network reliability, efficiency and performance.  Through its Marinetec™ Solutions, AMSC provides ship protection systems and is developing propulsion and power management solutions designed to help fleets increase system efficiencies, enhance power quality and boost operational safety.  Through its Windtec® Solutions, AMSC provides wind turbine electronic controls and systems, designs and engineering services that reduce the cost of wind energy. The Company’s solutions are enhancing the performance and reliability of power networks, increasing the operational safety of navy fleets, and powering gigawatts of renewable energy globally. Founded in 1987, AMSC is headquartered near Boston, Massachusetts with operations in Asia, Australia, Europe and North America. For more information, please visit www.amsc.com.

[0001437749-24-002040:8k_2_02:19]
AMSC, American Superconductor, D-VAR, D-VAR VVO, Gridtec, Marinetec, Windtec, Neeltran, NEPSI, Smarter, Cleaner … Better Energy, and Orchestrate the Rhythm and Harmony of Power on the Grid are trademarks or registered trademarks of American Superconductor Corporation. All other brand names, product names, trademarks or service marks belong to their respective holders.

[0001437749-24-002040:8k_2_02:20]
| AMSC Reports Q3 FY23 Results | Page 3 |

[0001437749-24-002040:8k_2_02:21]
Forward-Looking Statements

[0001437749-24-002040:8k_2_02:22]
| AMSC Reports Q3 FY23 Results | Page 4 |

[0001437749-24-002040:8k_2_02:23]
UNAUDITED CONSOLIDATED STATEMENTS OF OPERATIONS

[0001437749-24-002040:8k_2_02:24]
(In thousands, except per share data)

[0001437749-24-002040:8k_2_02:25]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | December 31, |  |  | December 31, |  |
|  |  | 2023 |  |  | 2022 |  |  | 2023 |  |  | 2022 |  |
| Revenues |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Grid |  | $ | 33,603 |  |  | $ | 20,809 |  |  | $ | 87,854 |  |  | $ | 66,337 |  |
| Wind |  |  | 5,750 |  |  |  | 3,072 |  |  |  | 15,757 |  |  |  | 7,904 |  |
| Total revenues |  |  | 39,353 |  |  |  | 23,881 |  |  |  | 103,611 |  |  |  | 74,241 |  |
| Cost of revenues |  |  | 29,369 |  |  |  | 23,364 |  |  |  | 78,759 |  |  |  | 69,533 |  |
| Gross margin |  |  | 9,984 |  |  |  | 517 |  |  |  | 24,852 |  |  |  | 4,708 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Research and development |  |  | 2,199 |  |  |  | 2,083 |  |  |  | 5,693 |  |  |  | 7,076 |  |
| Selling, general and administrative |  |  | 7,833 |  |  |  | 7,173 |  |  |  | 23,648 |  |  |  | 22,084 |  |
| Amortization of acquisition-related intangibles |  |  | 538 |  |  |  | 690 |  |  |  | 1,614 |  |  |  | 2,058 |  |
| Change in fair value of contingent consideration |  |  | 852 |  |  |  | (220 | ) |  |  | 3,052 |  |  |  | (340 | ) |
| Restructuring |  |  | — |  |  |  | - |  |  |  | (14 | ) |  |  | - |  |
| Total operating expenses |  |  | 11,422 |  |  |  | 9,726 |  |  |  | 33,993 |  |  |  | 30,878 |  |
| Operating loss |  |  | (1,438 | ) |  |  | (9,209 | ) |  |  | (9,141 | ) |  |  | (26,170 | ) |
| Interest income, net |  |  | 150 |  |  |  | 42 |  |  |  | 518 |  |  |  | 112 |  |
| China dissolution |  |  | - |  |  |  | — |  |  |  | - |  |  |  | (1,921 | ) |
| Other expense, net |  |  | (298 | ) |  |  | (287 | ) |  |  | (618 | ) |  |  | (48 | ) |
| Loss before income tax expense |  |  | (1,586 | ) |  |  | (9,454 | ) |  |  | (9,241 | ) |  |  | (28,027 | ) |
| Income tax expense |  |  | 63 |  |  |  | 127 |  |  |  | 291 |  |  |  | 144 |  |
| Net loss |  | $ | (1,649 | ) |  | $ | (9,581 | ) |  | $ | (9,532 | ) |  | $ | (28,171 | ) |
| Net loss per common share |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | (0.06 | ) |  | $ | (0.34 | ) |  | $ | (0.33 | ) |  | $ | (1.01 | ) |
| Diluted |  | $ | (0.06 | ) |  | $ | (0.34 | ) |  | $ | (0.33 | ) |  | $ | (1.01 | ) |
| Weighted average number of common shares outstanding |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  |  | 29,092 |  |  |  | 27,954 |  |  |  | 28,728 |  |  |  | 27,794 |  |
| Diluted |  |  | 29,092 |  |  |  | 27,954 |  |  |  | 28,728 |  |  |  | 27,794 |  |

[0001437749-24-002040:8k_2_02:26]
| AMSC Reports Q3 FY23 Results | Page 5 |

[0001437749-24-002040:8k_2_02:27]
UNAUDITED CONSOLIDATED BALANCE SHEETS

[0001437749-24-002040:8k_2_02:28]
(In thousands, except per share data)

[0001437749-24-002040:8k_2_02:29]
|  |  | December 31, 2023 |  |  | March 31, 2023 |  |
| ASSETS |  |  |  |  |  |  |  |  |
| Current assets: |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 23,979 |  |  | $ | 23,360 |  |
| Accounts receivable, net |  |  | 24,721 |  |  |  | 30,665 |  |
| Inventory, net |  |  | 44,197 |  |  |  | 36,986 |  |
| Prepaid expenses and other current assets |  |  | 6,635 |  |  |  | 13,429 |  |
| Restricted cash |  |  | 667 |  |  |  | 1,733 |  |
| Total current assets |  |  | 100,199 |  |  |  | 106,173 |  |
| Property, plant and equipment, net |  |  | 11,205 |  |  |  | 12,309 |  |
| Intangibles, net |  |  | 6,907 |  |  |  | 8,527 |  |
| Right-of-use assets |  |  | 2,401 |  |  |  | 2,857 |  |
| Goodwill |  |  | 43,471 |  |  |  | 43,471 |  |
| Restricted cash |  |  | 379 |  |  |  | 582 |  |
| Deferred tax assets |  |  | 1,141 |  |  |  | 1,114 |  |
| Other assets |  |  | 640 |  |  |  | 528 |  |
| Total assets |  | $ | 166,343 |  |  | $ | 175,561 |  |
| LIABILITIES AND STOCKHOLDERS' EQUITY |  |  |  |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |  |  |  |
| Accounts payable and accrued expenses |  | $ | 23,002 |  |  | $ | 38,383 |  |
| Lease liability, current portion |  |  | 680 |  |  |  | 808 |  |
| Debt, current portion |  |  | 41 |  |  |  | 75 |  |
| Contingent consideration |  |  | 1,230 |  |  |  | 1,270 |  |
| Deferred revenue, current portion |  |  | 52,598 |  |  |  | 43,572 |  |
| Total current liabilities |  |  | 77,551 |  |  |  | 84,108 |  |
| Deferred revenue, long term portion |  |  | 7,145 |  |  |  | 7,188 |  |
| Lease liability, long term portion |  |  | 1,861 |  |  |  | 2,184 |  |
| Deferred tax liabilities |  |  | 235 |  |  |  | 243 |  |
| Debt, long-term portion |  |  | — |  |  |  | 15 |  |
| Other liabilities |  |  | 26 |  |  |  | 26 |  |
| Total liabilities |  |  | 86,818 |  |  |  | 93,764 |  |
| Stockholders' equity: |  |  |  |  |  |  |  |  |
| Common stock |  |  | 311 |  |  |  | 299 |  |
| Additional paid-in capital |  |  | 1,146,405 |  |  |  | 1,139,113 |  |
| Treasury stock |  |  | (3,639 | ) |  |  | (3,639 | ) |
| Accumulated other comprehensive income |  |  | 1,527 |  |  |  | 1,571 |  |
| Accumulated deficit |  |  | (1,065,079 | ) |  |  | (1,055,547 | ) |
| Total stockholders' equity |  |  | 79,525 |  |  |  | 81,797 |  |
| Total liabilities and stockholders' equity |  | $ | 166,343 |  |  | $ | 175,561 |  |

[0001437749-24-002040:8k_2_02:30]
| AMSC Reports Q3 FY23 Results | Page 6 |

[0001437749-24-002040:8k_2_02:31]
UNAUDITED CONSOLIDATED STATEMENTS OF CASH FLOWS

[0001437749-24-002040:8k_2_02:32]
(In thousands)

[0001437749-24-002040:8k_2_02:33]
|  |  | Nine Months Ended December 31, |  |
|  |  | 2023 |  |  | 2022 |  |
| Cash flows from operating activities: |  |  |  |  |  |  |  |  |
| Net loss |  | $ | (9,532 | ) |  | $ | (28,171 | ) |
| Adjustments to reconcile net loss to net cash used in operations: |  |  |  |  |  |  |  |  |
| Depreciation and amortization |  |  | 3,360 |  |  |  | 4,104 |  |
| Stock-based compensation expense |  |  | 3,608 |  |  |  | 3,492 |  |
| Provision for excess and obsolete inventory |  |  | 1,536 |  |  |  | 1,247 |  |
| Deferred income taxes |  |  | 3 |  |  |  | 65 |  |
| Change in fair value of contingent consideration |  |  | 3,052 |  |  |  | (340 | ) |
| China dissolution |  |  | — |  |  |  | 1,921 |  |
| Other non-cash items |  |  | 495 |  |  |  | 185 |  |
| Unrealized foreign exchange loss on cash and cash equivalents |  |  | (1 | ) |  |  | (3 | ) |
| Changes in operating asset and liability accounts: |  |  |  |  |  |  |  |  |
| Accounts receivable |  |  | 5,945 |  |  |  | 2,738 |  |
| Inventory |  |  | (8,737 | ) |  |  | (16,324 | ) |
| Prepaid expenses and other assets |  |  | 7,139 |  |  |  | (165 | ) |
| Accounts payable and accrued expenses |  |  | (15,859 | ) |  |  | 2,565 |  |
| Deferred revenue |  |  | 8,894 |  |  |  | 11,619 |  |
| Net cash used in operating activities |  |  | (97 | ) |  |  | (17,067 | ) |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |
| Purchase of property, plant and equipment |  |  | (635 | ) |  |  | (970 | ) |
| Change in other assets |  |  | (8 | ) |  |  | (194 | ) |
| Net cash used in investing activities |  |  | (643 | ) |  |  | (1,164 | ) |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |
| Repayment of debt |  |  | (49 | ) |  |  | (56 | ) |
| Proceeds from exercise of employee stock options and ESPP |  |  | 136 |  |  |  | 127 |  |
| Net cash provided by financing activities |  |  | 87 |  |  |  | 71 |  |
| Effect of exchange rate changes on cash |  |  | 3 |  |  |  | 25 |  |
| Net decrease in cash, cash equivalents and restricted cash |  |  | (650 | ) |  |  | (18,135 | ) |
| Cash, cash equivalents and restricted cash at beginning of period |  |  | 25,675 |  |  |  | 49,486 |  |
| Cash, cash equivalents and restricted cash at end of period |  | $ | 25,025 |  |  | $ | 31,351 |  |

[0001437749-24-002040:8k_2_02:34]
| AMSC Reports Q3 FY23 Results | Page 7 |

[0001437749-24-002040:8k_2_02:35]
RECONCILIATION OF GAAP NET LOSS TO NON-GAAP NET INCOME (LOSS)

[0001437749-24-002040:8k_2_02:36]
(In thousands, except per share data)

[0001437749-24-002040:8k_2_02:37]
|  |  | Three Months Ended December 31, |  |  | Nine Months Ended December 31, |  |
|  |  | 2023 |  |  | 2022 |  |  | 2023 |  |  | 2022 |  |
| Net loss |  | $ | (1,649 | ) |  | $ | (9,581 | ) |  | $ | (9,532 | ) |  | $ | (28,171 | ) |
| China dissolution |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 1,921 |  |
| Stock-based compensation |  |  | 1,140 |  |  |  | 1,440 |  |  |  | 3,608 |  |  |  | 3,492 |  |
| Amortization of acquisition-related intangibles |  |  | 538 |  |  |  | 696 |  |  |  | 1,620 |  |  |  | 2,096 |  |
| Change in fair value of contingent consideration |  |  | 852 |  |  |  | (220 | ) |  |  | 3,052 |  |  |  | (340 | ) |
| Non-GAAP net income (loss) |  | $ | 881 |  |  | $ | (7,665 | ) |  | $ | (1,252 | ) |  | $ | (21,002 | ) |
| Non-GAAP net income (loss) per share - basic |  | $ | 0.03 |  |  | $ | (0.27 | ) |  | $ | (0.04 | ) |  | $ | (0.76 | ) |
| Weighted average shares outstanding - basic |  |  | 29,092 |  |  |  | 27,954 |  |  |  | 28,728 |  |  |  | 27,794 |  |

[0001437749-24-002040:8k_2_02:38]
Reconciliation of Forecast GAAP Net Loss to Non-GAAP Net Loss

[0001437749-24-002040:8k_2_02:39]
(In millions, except per share data)

[0001437749-24-002040:8k_2_02:40]
|  |  | Three Months Ending |  |
|  |  | March 31, 2024 |  |
| Net loss |  | $ | (3.5) |  |
| Stock-based compensation |  |  | 1.3 |  |
| Amortization of acquisition-related intangibles |  |  | 0.5 |  |
| Non-GAAP net loss |  | $ | (1.7) |  |
| Non-GAAP net loss per share |  | $ | (0.06) |  |
| Shares outstanding |  |  | 29.3 |  |

[0001437749-24-002040:8k_2_02:41]
| AMSC Reports Q3 FY23 Results | Page 8 |

[0001437749-24-002040:8k_2_02:42]
Note: Non-GAAP net income (loss) is defined by the Company as net loss before; China dissolution; stock-based compensation; amortization of acquisition-related intangibles; change in fair value of contingent consideration; other non-cash or unusual charges, and the tax effect of adjustments calculated at the relevant rate for our non-GAAP metric. The Company believes non-GAAP net income (loss) and non-GAAP net income (loss) per share assist management and investors in comparing the Company’s performance across reporting periods on a consistent basis by excluding these non-cash, non-recurring or other charges that it does not believe are indicative of its core operating performance. Actual GAAP and non-GAAP net loss for the fiscal quarter ending March 31, 2024, including the above adjustments, may differ materially from those forecasted in the table above, including as a result of changes in the fair value of contingent consideration. Generally, a non-GAAP financial measure is a numerical measure of a company's performance, financial position or cash flow that either excludes or includes amounts that are not normally excluded or included in the most directly comparable measure calculated and presented in accordance with GAAP. The non-GAAP measure included in this release, however, should be considered in addition to, and not as a substitute for or superior to, operating income or other measures of financial performance prepared in accordance with GAAP. A reconciliation of GAAP to non-GAAP net loss is set forth in the table above.

[0001437749-24-002040:8k_2_02:43]
AMSC Contacts

[0001437749-24-002040:8k_2_02:44]
Investor Relations Contact:

[0001437749-24-002040:8k_2_02:45]
LHA Investor Relations

[0001437749-24-002040:8k_2_02:46]
Carolyn Capaccio

[0001437749-24-002040:8k_2_02:47]
(212) 838-3777

[0001437749-24-002040:8k_2_02:48]
amscIR@lhai.com

[0001437749-24-002040:8k_2_02:49]
AMSC Senior Communications Manager:

[0001437749-24-002040:8k_2_02:50]
Nicol Golez

[0001437749-24-002040:8k_2_02:51]
978-399-8344

[0001437749-24-002040:8k_2_02:52]
Nicol.Golez@amsc.com
