# AMSC MD&A — 0001437749-24-002041


## mdna

[0001437749-24-002041:mdna:1]
[same as prior period, unchanged from 0001437749-23-029753:mdna:1]

[0001437749-24-002041:mdna:2]
[same as prior period, unchanged from 0001437749-23-029753:mdna:2]

[0001437749-24-002041:mdna:3]
[same as prior period, unchanged from 0001437749-23-029753:mdna:3]

[0001437749-24-002041:mdna:4]
[same as prior period, unchanged from 0001437749-23-029753:mdna:4]

[0001437749-24-002041:mdna:5]
[same as prior period, unchanged from 0001437749-23-029753:mdna:5]

[0001437749-24-002041:mdna:6]
[same as prior period, unchanged from 0001437749-23-029753:mdna:6]

[0001437749-24-002041:mdna:7]
[same as prior period, unchanged from 0001437749-23-029753:mdna:7]

[0001437749-24-002041:mdna:8]
[same as prior period, unchanged from 0001437749-23-029753:mdna:8]

[0001437749-24-002041:mdna:9]
[same as prior period, unchanged from 0001437749-23-029753:mdna:9]

[0001437749-24-002041:mdna:10]
[same as prior period, unchanged from 0001437749-23-029753:mdna:10]

[0001437749-24-002041:mdna:11]
We continue to experience some inflationary pressure in our supply chain and some delays in sourcing materials needed for our products, resulting in some production disruption, both of which have increased our cost of revenues and decreased gross margin.  While the impact of inflation has been challenging, we continue to take actions to limit this pressure including adjusting the pricing of our products and services. Changes in macroeconomic conditions arising from various reasons, such as the ongoing wars between Russia and Ukraine and Israel and Hamas, inflation, COVID-19, rising interest rates, labor force availability, sourcing, material delays and global supply chain disruptions, could have a material adverse effect on the Company’s business, financial condition and results of operation.

[0001437749-24-002041:mdna:12]
From time-to-time we may undertake restructuring activities in order to align our global organization in a manner that we believe will better position us to achieve our long-term goals. In January 2023, we undertook a reduction in force that involved approximately 5% of our global workforce. This restructuring is expected to incur $1.0 million of cash expenses, of which $0.9 million has been paid as of December 31, 2023 and the remaining $0.1 million is expected to be paid by March 31, 2024, and to result in annualized cost savings of approximately $5.0 million, beginning in fiscal 2023.

[0001437749-24-002041:mdna:13]
In February 2023, we completed the process of determining and verifying our eligibility and amount of payroll tax credits known as the Employee Retention Credit (“ERC”) under the CARES Act which Congress enacted as part of the Taxpayer Certainty and Disaster Tax Relief Act of 2020. This resulted in filing certain amended payroll tax forms for eligible quarters in 2020 and 2021, which, in the aggregate, totaled $3.3 million. We recognized a receivable in prepaid expenses and other current assets and a benefit to cost of revenues and operating expenses in the quarter ended March 31, 2023. During the nine months ended December 31, 2023, we received $3.0 million in payments for the initial claims that were processed. The remaining balance is expected to be paid during the remainder of fiscal 2023.

[0001437749-24-002041:mdna:14]
[same as prior period, unchanged from 0001437749-23-029753:mdna:14]

[0001437749-24-002041:mdna:15]
The preparation of the unaudited condensed consolidated financial statements requires that we make estimates and judgments that affect the reported amounts of assets, liabilities, revenues and expenses, and related disclosure of contingent assets and liabilities. We base our estimates on historical experience and various other assumptions that are believed to be reasonable under the circumstances, the results of which form the basis for making judgments about the carrying values of assets and liabilities that are not readily apparent from other sources. Actual results may differ under different assumptions or conditions. Certain prior period amounts were reclassified to conform to the presentation in the current period. There were no significant changes in the critical accounting policies that were disclosed in our Annual Report on Form 10-K for the fiscal year ended March 31, 2023.

[0001437749-24-002041:mdna:16]
[same as prior period, unchanged from 0001437749-23-029753:mdna:16]

[0001437749-24-002041:mdna:17]
Three and nine months ended December 31, 2023, compared to the three and nine months ended December 31, 2022

[0001437749-24-002041:mdna:18]
[same as prior period, unchanged from 0001437749-23-029753:mdna:18]

[0001437749-24-002041:mdna:19]
Total revenues increased 65% to $39.4 million for the three months ended December 31, 2023 and total revenues increased 40% to $103.6 million for the nine months ended December 31, 2023, compared to $23.9 million and $74.2 million for the three and nine months ended December 31, 2022, respectively. Our revenues are summarized as follows (in thousands):

[0001437749-24-002041:mdna:20]
|  |  | Three Months Ended December 31, |  |  | Nine Months Ended December 31, |  |
|  |  | 2023 |  |  | 2022 |  |  | 2023 |  |  | 2022 |  |
| Revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Grid |  | $ | 33,603 |  |  | $ | 20,809 |  |  | $ | 87,854 |  |  | $ | 66,337 |  |
| Wind |  |  | 5,750 |  |  |  | 3,072 |  |  |  | 15,757 |  |  |  | 7,904 |  |
| Total |  | $ | 39,353 |  |  | $ | 23,881 |  |  | $ | 103,611 |  |  | $ | 74,241 |  |

[0001437749-24-002041:mdna:21]
Our Grid business unit accounted for 85% of total revenues for each of the three and nine months ended December 31, 2023, respectively, compared to 87% and 89% for the three and nine months ended December 31, 2022, respectively. Our Grid business unit revenues increased 61% to $33.6 million in the three months ended December 31, 2023, from $20.8 million in the three months ended December 31, 2022. Our Grid business unit revenues increased 32% to $87.9 million in the nine months ended December 31, 2023, from $66.3 million in the nine months ended December 31, 2022. The increase in the Grid business unit revenues in the three and nine months ended December 31, 2023, compared to the three and nine months ended December 31, 2022 was primarily driven by increased shipments of new energy power systems and increased ship protection systems revenues than in the prior year periods.

[0001437749-24-002041:mdna:22]
Our Wind business unit accounted for 15% of total revenues for each of the three and nine months ended December 31, 2023, respectively, compared to 13% and 11% for the three and nine months ended December 31, 2022, respectively. Revenues in the Wind business unit increased 87% and 99% to $5.8 million and $15.8 million in the three and nine months ended December 31, 2023, from $3.1 million and $7.9 million in the three and nine months ended December 31, 2022, respectively. The increase during the three and nine months ended December 31, 2023, compared to the three and nine months ended December 31, 2022, was driven by additional shipments of electrical control systems ("ECS") at increased prices.

[0001437749-24-002041:mdna:23]
[same as prior period, unchanged from 0001437749-23-029753:mdna:23]

[0001437749-24-002041:mdna:24]
Cost of revenues increased by 26% to $29.4 million for the three months ended December 31, 2023, compared to $23.4 million for the three months ended December 31, 2022. Cost of revenues increased by 13% to $78.8 million for the nine months ended December 31, 2023, compared to $69.5 million for the nine months ended December 31, 2022. Gross margin was 25% and 24% for the three and nine months ended December 31, 2023, respectively, compared to 2% and 6% for the three and nine months ended December 31, 2022, respectively. The increase in gross margin in the three and nine months ended December 31, 2023 was due to higher revenues, a more favorable product mix and favorable impacts across the business due to pricing increases across our product lines.

[0001437749-24-002041:mdna:25]
[same as prior period, unchanged from 0001437749-23-029753:mdna:25]

[0001437749-24-002041:mdna:26]
[same as prior period, unchanged from 0001437749-23-029753:mdna:26]

[0001437749-24-002041:mdna:27]
Research and development ("R&D") expenses increased 6% in the three months ended December 31, 2023 to $2.2 million from $2.1 million in the three months ended December 31, 2022. The increase was driven primarily by lower cost share revenue. R&D expense decreased 20% in the nine months ended December 31, 2023 to $5.7 million from $7.1 million in the nine months ended December 31, 2022. The decrease was driven primarily by decreased compensation, materials and supplies expenses.

[0001437749-24-002041:mdna:28]
[same as prior period, unchanged from 0001437749-23-029753:mdna:28]

[0001437749-24-002041:mdna:29]
Selling, general and administrative ("SG&A") expenses increased 9% in the three months ended December 31, 2023 to $7.8 million from $7.2 million in the three months ended December 31, 2022. SG&A expenses increased 7% to $23.6 million in the nine months ended December 31, 2023, compared to $22.1 million in the nine months ended December 31, 2022. The increase in SG&A expense in the three and nine months ended December 31, 2023, was due to higher overall compensation expense than in each of the prior year periods.

[0001437749-24-002041:mdna:30]
[same as prior period, unchanged from 0001437749-23-029753:mdna:30]

[0001437749-24-002041:mdna:31]
We recorded amortization expense related to our core technology and know-how, customer relationships, and other intangible assets of $0.5 million and $1.6 million in the three and nine months ended December 31, 2023, respectively, and $0.7 million and $2.1 million in the three and nine months ended December 31, 2022, respectively. The decrease in amortization expense in both periods is a result of using the economic consumption method as the basis to amortize the acquired customer relationship intangible assets from Northeast Power Systems, Inc ("NEPSI") and Neeltran.

[0001437749-24-002041:mdna:32]
[same as prior period, unchanged from 0001437749-23-029753:mdna:32]

[0001437749-24-002041:mdna:33]
The change in fair value of our contingent consideration for the earnout payment on the acquisition of NEPSI resulted in losses of $0.9 million and $3.1 million resulting from the increase in the fair value of the contingent consideration in the three and nine months ended December 31, 2023, respectively. During the three and nine months ended December 31, 2023 we issued 399,999 shares and cash in lieu of a fractional share of common stock related to the achievement of specified revenue objectives in connection with the acquisition of NEPSI at a fair value of $3.1 million. One specified revenue objective, which would have earned the selling stockholders 300,000 shares of our common stock, was not achieved, leaving 300,000 shares of common stock remaining for potential issuance upon the achievement of the last specified revenue objective by September 30, 2024. We recorded the above noted losses, compared to a gain of $0.2 million and $0.3 million in the three and nine months ended December 31, 2022, respectively. The change in the fair value was driven by an increased likelihood of achieving certain revenue targets and an increase in our stock price.

[0001437749-24-002041:mdna:34]
[same as prior period, unchanged from 0001437749-23-029753:mdna:35]

[0001437749-24-002041:mdna:35]
[same as prior period, unchanged from 0001437749-23-029753:mdna:36]

[0001437749-24-002041:mdna:36]
|  |  | Three Months Ended December 31, |  |  | Nine Months Ended December 31, |  |
|  |  | 2023 |  |  | 2022 |  |  | 2023 |  |  | 2022 |  |
| Operating income (loss): |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Grid |  | $ | 268 |  |  | $ | (7,064 | ) |  | $ | (2,383 | ) |  | $ | (20,840 | ) |
| Wind |  |  | 286 |  |  |  | (924 | ) |  |  | (112 | ) |  |  | (2,178 | ) |
| Unallocated corporate expenses |  |  | (1,992 | ) |  |  | (1,221 | ) |  |  | (6,646 | ) |  |  | (3,152 | ) |
| Total |  | $ | (1,438 | ) |  | $ | (9,209 | ) |  | $ | (9,141 | ) |  | $ | (26,170 | ) |

[0001437749-24-002041:mdna:37]
Our Grid business segment generated operating income of $0.3 million and operating loss of $2.4 million in the three and nine months ended December 31, 2023, respectively, compared to operating losses of $7.1 million and $20.9 million in the three and nine months ended December 31, 2022, respectively.  The increase in the Grid business unit operating income in the three and nine months ended December 31, 2023 was due to higher revenues and gross margins due to a favorable product mix as well as the reduction of the remaining acquired Neeltran backlog.

[0001437749-24-002041:mdna:38]
Our Wind business segment generated operating income of $0.3 million and operating loss of $0.1 million in the three and nine months ended December 31, 2023, respectively, compared to operating losses of $0.9 million and $2.2 million in the three and nine months ended December 31, 2022, respectively. The improvement in the Wind business unit operating income in the three and nine months ended December 31, 2023 was due to higher revenues and gross margins from increased sales of ECS units.

[0001437749-24-002041:mdna:39]
Unallocated corporate expenses included net losses of $0.9 million and $3.1 million resulting from the increases in the fair value of the NEPSI contingent consideration in the three and nine months ended December 31, 2023, respectively. Additionally, unallocated corporate expenses consisted of stock-based compensation expense of $1.1 million and $3.6 million in the three and nine months ended December 31, 2023, respectively, and $1.4 million and $3.5 million in the three and nine months ended December 31, 2022, respectively.

[0001437749-24-002041:mdna:40]
[same as prior period, unchanged from 0001437749-23-029753:mdna:41]

[0001437749-24-002041:mdna:41]
Interest income, net, was $0.2 million and $0.5 million in the three and nine months ended December 31, 2023, respectively, compared to less than $0.1 million and $0.1 million in the three and nine months ended December 31, 2022, respectively, due to higher earned interest at increased interest rates in the fiscal year 2023 periods.

[0001437749-24-002041:mdna:42]
[same as prior period, unchanged from 0001437749-23-029753:mdna:43]

[0001437749-24-002041:mdna:43]
China dissolution expense was $1.9 million in the nine months ended December 31, 2022, and there was no similar transaction in the three and nine months ended December 31, 2023, or the three months ended December 31, 2022. The impact of the China dissolution expense during the nine months ended December 31, 2022 was driven by the liquidation of our China entity, resulting in a foreign currency loss from the cumulative translation release of $1.9 million.

[0001437749-24-002041:mdna:44]
[same as prior period, unchanged from 0001437749-23-029753:mdna:45]

[0001437749-24-002041:mdna:45]
Other expense, net, was $0.3 million and $0.6 million in the three and nine months ended December 31, 2023, respectively, compared to other expense, net, of $0.3 million and less than $0.1 million in the three and nine months ended December 31, 2022, respectively. The increase in other expense, net, during the three and nine months ended December 31, 2023, compared to the three and nine months ended December 31, 2022, was driven by the impacts of unfavorable fluctuations in foreign currencies during the periods.

[0001437749-24-002041:mdna:46]
[same as prior period, unchanged from 0001437749-23-029753:mdna:47]

[0001437749-24-002041:mdna:47]
Income tax expense was $0.1 million and $0.3 million in the three and nine months ended December 31, 2023, respectively. Income tax expense was $0.1 million in each of the three and nine months ended December 31, 2022.

[0001437749-24-002041:mdna:48]
[same as prior period, unchanged from 0001437749-23-029753:mdna:49]

[0001437749-24-002041:mdna:49]
Net loss was $1.6 million and $9.5 million in the three and nine months ended December 31, 2023, respectively, compared to $9.6 million and $28.2 million in the three and nine months ended December 31, 2022, respectively. The decrease in net loss in both periods was driven primarily by the increased revenues and gross margins.

[0001437749-24-002041:mdna:50]
[same as prior period, unchanged from 0001437749-23-029753:mdna:51]

[0001437749-24-002041:mdna:51]
[same as prior period, unchanged from 0001437749-23-029753:mdna:52]

[0001437749-24-002041:mdna:52]
We define non-GAAP net income (loss) as net loss before China dissolution, stock-based compensation, amortization of acquisition-related intangibles, change in fair value of contingent consideration, and other non-cash or unusual charges.  We believe non-GAAP net income (loss) assists management and investors in comparing our performance across reporting periods on a consistent basis by excluding these non-cash charges and other items that we do not believe are indicative of our core operating performance. In addition, we use non-GAAP net income (loss) as a factor to evaluate the effectiveness of our business strategies. A reconciliation of GAAP to non-GAAP net income (loss) is set forth in the table below (in thousands, except per share data):

[0001437749-24-002041:mdna:53]
|  |  | Three Months Ended December 31, |  |  | Nine Months Ended December 31, |  |
|  |  | 2023 |  |  | 2022 |  |  | 2023 |  |  | 2022 |  |
| Net loss |  | $ | (1,649 | ) |  | $ | (9,581 | ) |  | $ | (9,532 | ) |  | $ | (28,171 | ) |
| China dissolution |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 1,921 |  |
| Stock-based compensation |  |  | 1,140 |  |  |  | 1,440 |  |  |  | 3,608 |  |  |  | 3,492 |  |
| Amortization of acquisition-related intangibles |  |  | 538 |  |  |  | 696 |  |  |  | 1,620 |  |  |  | 2,096 |  |
| Change in fair value of contingent consideration |  |  | 852 |  |  |  | (220 | ) |  |  | 3,052 |  |  |  | (340 | ) |
| Non-GAAP net income (loss) |  | $ | 881 |  |  | $ | (7,665 | ) |  | $ | (1,252 | ) |  | $ | (21,002 | ) |
| Non-GAAP net income (loss) per share - basic |  | $ | 0.03 |  |  | $ | (0.27 | ) |  | $ | (0.04 | ) |  | $ | (0.76 | ) |
| Weighted average shares outstanding - basic |  |  | 29,092 |  |  |  | 27,954 |  |  |  | 28,728 |  |  |  | 27,794 |  |

[0001437749-24-002041:mdna:54]
We incurred non-GAAP net income of $0.9 million and a non-GAAP net loss of $1.3 million, or $0.03 and $(0.04) per share, for the three and nine months ended December 31, 2023, respectively, compared to non-GAAP net losses of $7.7 million and $21.0 million, or $(0.27) and $(0.76) per share, for the three and nine months ended December 31, 2022, respectively. The improvement in the non-GAAP net income (loss) for the three and nine months ended December 31, 2023 was due to a lower operating loss driven by higher revenues and gross margins.

[0001437749-24-002041:mdna:55]
[same as prior period, unchanged from 0001437749-23-029753:mdna:56]

[0001437749-24-002041:mdna:56]
[same as prior period, unchanged from 0001437749-23-029753:mdna:57]

[0001437749-24-002041:mdna:57]
We have experienced recurring operating losses and, as of December 31, 2023, had an accumulated deficit of $1,065.1 million.

[0001437749-24-002041:mdna:58]
Our cash requirements depend on numerous factors, including the successful completion of our product development activities, our ability to commercialize our Resilient Electric Grid and ship protection system solutions, the rate of customer and market adoption of our products, collecting receivables according to established terms, the continued availability of U.S. government funding during the product development phase of our superconductor-based products and whether Inox is successful in executing on Solar Energy Corporation of India Limited orders or in obtaining additional orders under the new central and state auction regime. We continue to closely monitor our expenses and, if required, expect to reduce our operating and capital spending to enhance liquidity.

[0001437749-24-002041:mdna:59]
[same as prior period, unchanged from 0001437749-23-029753:mdna:60]

[0001437749-24-002041:mdna:60]
As of December 31, 2023, we had cash, cash equivalents and restricted cash of $25.0 million, compared to $25.7 million as of March 31, 2023, a decrease of $0.7 million. As of December 31, 2023, we had $2.4 million in cash, cash equivalents, and restricted cash in foreign bank accounts. Our cash, cash equivalents, and restricted cash are summarized as follows (in thousands):

[0001437749-24-002041:mdna:61]
|  |  | December 31, 2023 |  |  | March 31, 2023 |  |
| Cash and cash equivalents |  | $ | 23,979 |  |  | $ | 23,360 |  |
| Restricted cash |  |  | 1,046 |  |  |  | 2,315 |  |
| Total cash, cash equivalents, and restricted cash |  | $ | 25,025 |  |  | $ | 25,675 |  |

[0001437749-24-002041:mdna:62]
For the nine months ended December 31, 2023, net cash used in operating activities was $0.1 million, compared to $17.1 million for the nine months ended December 31, 2022. The decrease in net cash used in operations was due primarily to decreases in net loss and in prepaid expenses and other current assets in the nine months ended December 31, 2023 as compared to December 31, 2022. Cash flows from operating activities in the nine months ended December 31, 2023 included a reimbursement of $3.0 million for the ERC receivable included in prepaid expenses and other current assets at March 31, 2023.

[0001437749-24-002041:mdna:63]
For the nine months ended December 31, 2023, net cash used in investing activities was $0.6 million, compared to $1.2 million for the nine months ended December 31, 2022. The decrease in net cash used in investing activities was primarily due to a decrease in purchases of property, plant and equipment.

[0001437749-24-002041:mdna:64]
For the nine months ended December 31, 2023, net cash provided by financing activities was $0.1 million. For the nine months ended December 31, 2022, net cash provided by financing activities was less than $0.1 million.

[0001437749-24-002041:mdna:65]
As of December 31, 2023, we had $0.4 million of restricted cash included in long-term assets and $0.7 million of restricted cash included in current assets. At March 31, 2023, we had $0.6 million of restricted cash included in long-term assets and $1.7 million of restricted cash in current assets. These amounts included in restricted cash primarily represent collateral deposits to secure surety bonds and letters of credit for various customer contracts. These deposits are held in interest bearing accounts.

[0001437749-24-002041:mdna:66]
We are a party to many contractual obligations involving commitments to make payments to third parties. These obligations impact our short-term and long-term liquidity and capital resource needs. Certain contractual obligations are reflected on the consolidated balance sheet as of December 31, 2023, while others are considered future commitments. We have various contractual arrangements, under which we have committed to purchase certain minimum quantities of goods or services on an annual basis. For information regarding our other contractual obligations, refer to Note 13, "Contingent Consideration," Note 14, "Debt," Note 15, "Leases" and Note 16, "Commitments and Contingencies" to our condensed consolidated financial statements included elsewhere in this Quarterly Report on Form 10-Q.

[0001437749-24-002041:mdna:67]
We believe we have sufficient available liquidity to fund our operations and capital expenditures for the next twelve months. In addition, we may seek to raise additional capital, which could be in the form of loans, convertible debt or equity, to fund our operating requirements and capital expenditures. Our liquidity is highly dependent on our ability to increase revenues, control our operating costs, and raise additional capital, if necessary. There can be no assurance that we will be able to raise additional capital on favorable terms or at all or execute on any other means of improving our liquidity as described above.  Additionally, the impact of COVID-19 or other sources of instability, including the ongoing wars between Russia and Ukraine or Israel and Hamas, instability of financial institutions and political instability in the United States, on the global financial markets may reduce our ability to raise additional capital, if necessary, which could negatively impact our liquidity. We also continue to closely monitor our expenses and, if required, we intend to reduce our operating and capital spending to enhance liquidity.

[0001437749-24-002041:mdna:68]
Legal Proceedings

[0001437749-24-002041:mdna:69]
[same as prior period, unchanged from 0001437749-23-029753:mdna:70]

[0001437749-24-002041:mdna:70]
[same as prior period, unchanged from 0001437749-23-029753:mdna:71]

[0001437749-24-002041:mdna:71]
In June 2016, the Financial Accounting Standards Board ("FASB") issued Accounting Standards Update ("ASU") 2016-13, Financial Instruments-Credit Losses (Topic 326): Measurement of Credit Losses on Financial Instruments. The amendments in ASU 2016-13 will provide more decision-useful information about the expected credit losses on financial instruments and other commitments to extend credit held by a reporting entity at each reporting date. Following the release of ASU 2019-10 in November 2019, the effective date, as long as the Company remains a smaller reporting company, was annual reporting periods beginning after December 15, 2022.  As of April 1, 2023, we have adopted ASU 2016-13 and noted no material impact on our condensed consolidated financial statements.

[0001437749-24-002041:mdna:72]
In October 2021, the FASB issued ASU 2021-08, Business Combinations (Topic 805): Accounting for Contract Assets and Contract Liabilities from Contracts with Customers. The amendments in ASU 2021-08 will improve the accounting for acquired revenue contracts with customers in a business combination. Following the release of ASU 2021-08 in October 2021, the effective date was annual reporting periods beginning after December 15, 2022. As of April 1, 2023, we have adopted ASU 2021-08 and noted no material impact on our condensed consolidated financial statements.

[0001437749-24-002041:mdna:73]
In November 2023, the FASB issued ASU 2023-07, Segment Reporting (Topic 280): Improvements to Reportable Segment Disclosures. The amendments in ASU 2023-07 improve the disclosures about a public entity’s reportable segments and address requests from investors for additional, more detailed information about a reportable segment’s expenses. Following the release of ASU 2023-07 in November 2023, the effective date will be annual reporting periods beginning after December 15, 2024. As of December 31, 2023, we are evaluating the impact on our condensed consolidated financial statements.

[0001437749-24-002041:mdna:74]
In December 2023, the FASB issued ASU 2023-09, Income Taxes (Topic 740): Improvements to Income Tax Disclosures. The amendments in ASU 2023-09 address investor requests for more transparency about income tax information through improvements to income tax disclosures primarily related to the rate reconciliation and income taxes paid information. Following the release of ASU 2023-09 in December 2023, the effective date will be annual reporting periods beginning after December 15, 2024. As of December 31, 2023, we are evaluating the impact on our condensed consolidated financial statements.

[0001437749-24-002041:mdna:75]
We do not believe that, outside of those disclosed here, there are any other recently issued accounting pronouncements that will have a material impact on our condensed consolidated financial statements.
