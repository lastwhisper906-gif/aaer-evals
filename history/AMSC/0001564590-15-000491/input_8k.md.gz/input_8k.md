# AMSC 8-K — 0001193125-15-034499 filed 2015-02-05

## item codes, every 8-K on or before 2015-02-05

- 2015-02-05 0001193125-15-034499 — 2.02, 9.01
- 2015-01-29 0001193125-15-024629 — 2.02, 9.01
- 2015-01-21 0001193125-15-016287 — 3.01, 8.01
- 2015-01-06 0001193125-15-002902 — 5.02
- 2014-12-22 0001193125-14-450591 — 1.01, 2.03, 3.02, 9.01
- 2014-11-13 0001193125-14-410207 — 1.01, 9.01
- 2014-11-07 0001193125-14-402383 — 1.02, 7.01, 9.01
- 2014-11-06 0001193125-14-399779 — 2.02, 9.01
- 2014-10-01 0001193125-14-360072 — 2.02, 8.01, 9.01
- 2014-09-04 0001193125-14-331411 — 8.01
- 2014-08-21 0001193125-14-317133 — 1.01
- 2014-08-06 0001193125-14-298306 — 5.02, 5.07, 9.01
- 2014-08-05 0001193125-14-294647 — 2.02, 9.01
- 2014-07-16 0001193125-14-269902 — 8.01
- 2014-06-23 0001193125-14-244592 — 3.02, 8.01
- 2014-06-05 0001193125-14-226459 — 2.02, 9.01
- 2014-06-05 0001193125-14-226457 — 1.01, 9.01
- 2014-03-19 0001193125-14-106558 — 2.05
- 2014-03-03 0001193125-14-078917 — 1.01, 3.02, 9.01
- 2014-02-28 0001193125-14-077480 — 8.01, 9.01
- 2014-02-06 0001193125-14-037960 — 2.02, 8.01, 9.01
- 2013-11-20 0001193125-13-447829 — 3.02, 8.01
- 2013-11-18 0001193125-13-444697 — 1.01, 2.03, 3.02, 9.01
- 2013-11-07 0001193125-13-431705 — 2.02, 9.01
- 2013-10-09 0001193125-13-395362 — 1.01, 2.03, 3.02, 9.01
- 2013-09-25 0001193125-13-378481 — 5.02, 9.01
- 2013-08-21 0001193125-13-341566 — 4.01, 9.01
- 2013-08-07 0001193125-13-323082 — 2.02, 9.01
- 2013-08-02 0001193125-13-317278 — 5.02, 5.07
- 2013-06-14 0001193125-13-258758 — 2.02, 9.01
- 2013-04-01 0001193125-13-136714 — 2.02, 8.01, 9.01
- 2013-02-20 0001193125-13-067218 — 5.02, 9.01
- 2013-02-14 0001193125-13-060131 — 1.01, 9.01
- 2013-02-11 0001193125-13-048784 — 2.02, 9.01
- 2013-01-08 0001193125-13-006861 — 5.02, 9.01
- 2012-12-21 0001193125-12-511592 — 1.01, 2.03, 3.02, 9.01
- 2012-11-28 0001193125-12-483317 — 2.05, 5.02, 7.01, 9.01
- 2012-11-06 0001193125-12-453359 — 2.02, 9.01
- 2012-08-02 0001193125-12-330534 — 2.02, 9.01
- 2012-07-27 0001193125-12-318790 — 5.02, 5.07, 9.01
- 2012-06-06 0001193125-12-261030 — 1.01, 2.02, 2.03, 3.02, 5.02, 9.01
- 2012-05-09 0001193125-12-222210 — 5.02
- 2012-04-20 0001193125-12-172045 — 8.01
- 2012-04-13 0001193125-12-162694 — 2.02, 8.01, 9.01
- 2012-04-04 0001193125-12-149102 — 1.01, 2.02, 2.03, 3.02, 9.01
- 2012-02-09 0001193125-12-048009 — 2.02, 9.01
- 2012-02-06 0001193125-12-041344 — 5.07 — amendment of 0000950123-11-102495
- 2011-12-08 0000950123-11-102495 — 5.07
- 2011-11-29 0000950123-11-100822 — 2.05
- 2011-11-09 0000950123-11-096775 — 2.02, 9.01
- 2011-10-31 0000950123-11-093390 — 1.02, 9.01
- 2011-10-07 0000950123-11-089221 — 8.01
- 2011-10-03 0000950123-11-088315 — 7.01
- 2011-09-23 0000950123-11-086288 — 2.02, 9.01
- 2011-09-15 0000950123-11-084585 — 7.01
- 2011-09-06 0000950123-11-082736 — 7.01
- 2011-08-18 0000950123-11-078526 — 3.01, 7.01, 9.01
- 2011-08-11 0000950123-11-075905 — 5.02
- 2011-08-11 0000950123-11-075904 — 2.02, 2.05, 9.01
- 2011-07-11 0000950123-11-064934 — 2.02, 4.02, 9.01
- 2011-06-30 0000950123-11-063287 — 1.01, 3.02, 9.01
- 2011-06-21 0000950123-11-060491 — 3.01, 7.01, 9.01
- 2011-06-13 0000950123-11-058656 — 1.01, 9.01
- 2011-05-24 0000950123-11-053517 — 5.02, 9.01
- 2011-04-05 0001299933-11-001020 — 2.02, 9.01
- 2011-03-15 0000950123-11-025580 — 5.02
- 2011-03-14 0000950123-11-025205 — 1.01, 3.02, 9.01
- 2011-02-01 0001299933-11-000333 — 2.02, 9.01
- 2010-11-12 0000950123-10-104604 — 8.01, 9.01
- 2010-11-08 0000950123-10-102424 — 8.01, 9.01
- 2010-11-02 0001299933-10-003878 — 2.02, 9.01
- 2010-09-15 0000950123-10-086373 — 1.01, 9.01 — amendment, the index does not say of what
- 2010-08-06 0000950123-10-074362 — 5.07
- 2010-07-29 0001299933-10-002860 — 2.02, 9.01
- 2010-05-17 0000950123-10-050424 — 1.01, 9.01
- 2010-05-14 0001299933-10-001972 — 5.02
- 2010-05-13 0001299933-10-001943 — 2.02, 9.01
- 2010-02-08 0001299933-10-000506 — 8.01
- 2010-02-02 0001299933-10-000386 — 2.02, 9.01
- 2009-12-15 0001299933-09-004928 — 5.02
- 2009-10-29 0001299933-09-004267 — 2.02, 9.01
- 2009-08-12 0001193125-09-173026 — 5.02, 9.01
- 2009-07-30 0001193125-09-158842 — 1.01, 2.02, 9.01
- 2009-05-15 0001193125-09-113158 — 5.02
- 2009-05-14 0001193125-09-110619 — 2.02, 9.01
- 2009-04-20 0001193125-09-082590 — 5.02
- 2009-02-03 0001193125-09-016992 — 2.02, 9.01
- 2009-01-22 0001193125-09-009777 — 2.02, 9.01
- 2008-11-04 0001193125-08-223730 — 2.02, 9.01
- 2008-08-11 0001193125-08-173616 — 8.01
- 2008-08-07 0001193125-08-170325 — 8.01
- 2008-08-05 0001193125-08-165888 — 2.02, 9.01
- 2008-06-11 0001193125-08-132049 — 1.01, 9.01
- 2008-05-20 0001193125-08-119372 — 5.02, 9.01
- 2008-05-08 0001193125-08-107052 — 2.02, 9.01
- 2008-01-31 0001193125-08-016233 — 2.02, 9.01
- 2008-01-30 0001193125-08-015494 — 5.03, 9.01
- 2007-11-01 0001193125-07-231866 — 2.02, 9.01
- 2007-10-31 0001193125-07-231225 — 2.05
- 2007-10-29 0001193125-07-228284 — 5.03, 9.01
- 2007-09-27 0001193125-07-208950 — 5.02
- 2007-08-09 0001193125-07-176553 — 2.02, 9.01
- 2007-08-07 0001193125-07-173829 — 1.01, 5.02, 9.01
- 2007-07-02 0001193125-07-148303 — 5.02, 9.01
- 2007-06-20 0001193125-07-139068 — 8.01, 9.01
- 2007-06-14 0001193125-07-135550 — 9.01 — amendment of 0001193125-07-005297
- 2007-06-14 0001193125-07-135340 — 5.02
- 2007-05-24 0001193125-07-122148 — 2.02, 9.01
- 2007-03-30 0001193125-07-070154 — 2.05, 9.01
- 2007-03-23 0001193125-07-062978 — 9.01 — amendment of 0001193125-07-005297
- 2007-02-01 0001193125-07-017883 — 2.02, 9.01
- 2007-01-11 0001193125-07-005297 — 2.01, 9.01
- 2006-12-05 0001181431-06-067500 — 5.02
- 2006-11-29 0001193125-06-243360 — 1.01, 3.02, 9.01
- 2006-11-02 0001193125-06-221464 — 2.02, 9.01
- 2006-09-21 0001193125-06-194526 — 5.02
- 2006-08-08 0001193125-06-164819 — 2.02, 9.01
- 2006-08-02 0001193125-06-159113 — 1.01, 9.01
- 2006-07-28 0001193125-06-156172 — 1.01
- 2006-06-26 0001193125-06-135913 — 1.01, 3.03, 9.01
- 2006-05-11 0001193125-06-108489 — 2.02, 9.01
- 2006-05-05 0001193125-06-102270 — 1.01, 9.01
- 2006-05-01 0001193125-06-094941 — 2.02, 2.06, 9.01
- 2006-02-24 0001193125-06-038281 — 5.02, 9.01
- 2006-02-02 0001181431-06-007665 — 2.02, 9.01
- 2005-11-09 0001181431-05-060304 — 2.02, 9.01
- 2005-08-04 0001181431-05-044420 — 2.02, 9.01
- 2005-07-28 0001193125-05-151272 — 5.02, 9.01
- 2005-06-14 0001193125-05-125148 — 5.02, 9.01
- 2005-05-12 0001181431-05-027410 — 2.02, 9.01
- 2005-05-10 0001193125-05-102795 — 1.01
- 2005-04-05 0001181431-05-020680 — 1.01, 2.02, 3.02, 9.01
- 2005-02-03 0001181431-05-006678 — 2.02, 9.01
- 2004-11-09 0001181431-04-051381 — 2.02, 9.01 — amendment, the index does not say of what
- 2004-11-04 0001181431-04-050706 — 2.02, 9.01
- 2004-10-15 0001193125-04-172458 — 1.01, 9.01
- 2004-08-05 0001193125-04-132162 — 12
- 2004-05-13 0001193125-04-086853 — 12
- 2004-02-05 0001193125-04-015060 — 12
- 2003-11-06 0001193125-03-074000 — 12
- 2003-09-26 0001193125-03-054624 — 5
- 2003-08-06 0001193125-03-029666 — 12
- 2003-05-14 0000927016-03-002619 — 9
- 2002-12-31 0000927016-02-006114 — 5
- 2000-01-24 0000927016-00-000150 — 5, 7
- 1998-11-02 0000950135-98-005625 — 5, 7
- 1998-03-24 0000950135-98-001743 — 5, 7
- 1997-09-05 0000950135-97-003729 — 5, 7
- 1997-06-23 0000950135-97-002785 — 1 — amendment of 0000950135-97-001972
- 1997-04-23 0000950135-97-001972 — 2, 7

## late-filing notifications on or before 2015-02-05

- 2011-08-10 0000950123-11-075677 — NT 10-Q, for the period ended 2011-06-30
- 2011-05-31 0000950123-11-055465 — NT 10-K, for the period ended 2011-03-31

## item 2.02 — earnings release, exhibit 99.1

[0001193125-15-034499:8k_2_02:1]
EX-99.1
2
d865294dex991.htm
EX-99.1

[0001193125-15-034499:8k_2_02:2]
EX-99.1

[0001193125-15-034499:8k_2_02:3]
Exhibit 99.1

[0001193125-15-034499:8k_2_02:4]
AMSC Reports Third Quarter

[0001193125-15-034499:8k_2_02:5]
Fiscal 2014 Financial Results and Provides

[0001193125-15-034499:8k_2_02:6]
Business Outlook

[0001193125-15-034499:8k_2_02:7]
Company to host conference call today at 10:00 am ET

[0001193125-15-034499:8k_2_02:8]
Devens, MA – February 5, 2015 – AMSC (NASDAQ: AMSC), a global solutions provider serving wind and power grid industry leaders, today
reported financial results for its third quarter of fiscal 2014 ended December 31, 2014.

[0001193125-15-034499:8k_2_02:9]
Revenues for the third quarter of fiscal 2014 were $21.3
million, compared with $20.6 million for the same period of fiscal 2013. The year over year increase in revenues was due to higher Wind segment revenues, partially offset by lower Grid segment revenues versus year ago results.

[0001193125-15-034499:8k_2_02:10]
AMSC’s net loss for the third quarter of fiscal 2014 decreased to $6.4 million, or $0.07 per share, from $8.4 million, or $0.14 per share, for the same
period of fiscal 2013. Net loss for the third quarter of fiscal 2014 included a gain from a decrease in the fair value of derivatives and warrants of $2.3 million, as well as a charge of $0.5 million relating to the Company’s ongoing
restructuring initiative.

[0001193125-15-034499:8k_2_02:11]
Excluding these and other non-cash charges, the Company’s non-GAAP net loss for the third quarter of fiscal 2014 was $9.6
million, or $0.11 per share, compared with a non-GAAP net loss of $5.7 million, or $0.09 per share, in the same period of fiscal 2013. Please refer to the financial table below for a reconciliation of GAAP to non-GAAP results.

[0001193125-15-034499:8k_2_02:12]
Cash, cash equivalents, and restricted cash at December 31, 2014 totaled $37.6 million, compared with $38.2 million at September 30, 2014. During
the third quarter of fiscal 2014, the Company received net proceeds under its At-Market Sales Facility (ATM), after deducting sales commissions, of $1.0 million from the issuance of approximately 0.8 million shares of common stock at an average
sales price of $1.22 per share. The ATM arrangement was terminated on November 5, 2014. Also during the third fiscal quarter, the Company completed an equity offering to a new investor, under which it sold approximately 9.1 million units
of common stock at an offering price of $1.10 per common stock unit. Each unit consisted of one share of common stock and 0.9 of a warrant to purchase one share of common stock, or a warrant to purchase in the aggregate of 8.2 million shares.
Net proceeds after deducting underwriting commissions and expenses were approximately $9.1 million. The Company also amended its senior term loan with Hercules Technology Growth Capital, which provided for a new term loan of $1.5 million.

[0001193125-15-034499:8k_2_02:13]
The Company is also announcing that its wholly-owned subsidiary, AMSC Austria GmbH, has reached an agreement with Ghodawat Energy Pvd Ltd (Ghodawat) to fully
settle any and all disputes and claims between the parties (including their respective parent and affiliated companies), including all claims relating to the arbitration award and the arbitration award for 7.45 million Euro (approximately $8.5
million at current exchange rates). Payment is expected to be made during the fourth quarter of fiscal 2014.

[0001193125-15-034499:8k_2_02:14]
| AMSC Reports Q3 Results |  | Page 2 |

[0001193125-15-034499:8k_2_02:15]
“During the third fiscal quarter, we grew revenues by 70% sequentially. We’ve also put the
arbitration with Ghodawat behind us so that we can remain focused on the products, markets, and customers that will drive our future growth,” said Daniel P. McGahn, President and CEO, AMSC. “Our baseline revenue is driven by our two
established product lines: electrical control systems for wind turbines and D-VAR® reactive compensation systems. We also remain focused on the proliferation of our two disruptive solutions:
ship protection systems for the U.S. Navy and Resilient Electric Grid systems for electric utilities.”

[0001193125-15-034499:8k_2_02:16]
Business Outlook

[0001193125-15-034499:8k_2_02:17]
For the fourth quarter ending March 31, 2015, AMSC expects that its revenues will be in the range of $23 million to $25 million. The Company’s net
loss for the fourth quarter of fiscal 2014 is expected to be less than $6.0 million, or $0.06 per share. Forecasted GAAP net loss in the fourth quarter includes non-recurring gains of $2.0 million related to the recent settlement with the
Company’s insurer pertaining to the Ghodawat matter and $1.3 million related to the settlement with Ghodawat itself that was announced today. AMSC expects that its non-GAAP net loss (as defined below) for the fourth quarter of fiscal 2014 will
be less than $7.0 million, or $0.07 per share. For the full fiscal year 2014, the Company expects revenues to be in the range of $68 million to $70 million.

[0001193125-15-034499:8k_2_02:18]
Conference Call Reminder

[0001193125-15-034499:8k_2_02:19]
In conjunction with this
announcement, AMSC management will participate in a conference call with investors beginning at 10:00 a.m. Eastern Time today to discuss the Company’s results and its business outlook. Those who wish to listen to the live or archived conference
call webcast should visit the “Investors” section of the Company’s website at http://www.amsc.com/investors. The live call also can be accessed by dialing 785-830-7991 and using conference ID 2701273.

[0001193125-15-034499:8k_2_02:20]
About AMSC (NASDAQ: AMSC)

[0001193125-15-034499:8k_2_02:21]
AMSC generates the
ideas, technologies and solutions that meet the world’s demand for smarter, cleaner … better energy™. Through its Windtec™ Solutions, AMSC provides wind turbine electronic controls and systems, designs and engineering services
that reduce the cost of wind energy. Through its Gridtec™ Solutions, AMSC provides the engineering planning services and advanced grid systems that optimize network reliability, efficiency and performance. The Company’s solutions are now
powering gigawatts of renewable energy globally and are enhancing the performance and reliability of power networks in more than a dozen countries. Founded in 1987, AMSC is headquartered near Boston, Massachusetts with operations in Asia, Australia,
Europe and North America. For more information, please visit www.amsc.com.

[0001193125-15-034499:8k_2_02:22]
AMSC, Windtec, Gridtec, and Smarter, Cleaner … Better Energy
are trademarks or registered trademarks of American Superconductor Corporation. All other brand names, product names, trademarks or service marks belong to their respective holders.

[0001193125-15-034499:8k_2_02:23]
Forward-Looking Statements

[0001193125-15-034499:8k_2_02:24]
| AMSC Reports Q3 Results |  | Page 3 |

[0001193125-15-034499:8k_2_02:25]
| AMSC Reports Q3 Results |  | Page 4 |

[0001193125-15-034499:8k_2_02:26]
and volume fluctuations, which may prevent our stockholders from selling our common stock at a profit and
could lead to costly litigation against us that could divert our management’s attention; and we will not be able to maintain our listing on The Nasdaq Global Select Market if we are unable to regain compliance with The NASDAQ Stock Market
LLC’s minimum bid price requirement of $1.00 per share.

[0001193125-15-034499:8k_2_02:27]
These and the important factors discussed under the caption “Risk Factors”
in Part 1. Item 1A of our Form 10-K for the fiscal year ended March 31, 2014, and our other reports filed with the SEC, among others, could cause actual results to differ materially from those indicated by forward-looking statements made
herein and presented elsewhere by management from time to time. Any such forward-looking statements represent management’s estimates as of the date of this press release. While we may elect to update such forward-looking statements at some
point in the future, we disclaim any obligation to do so, even if subsequent events cause our views to change. These forward-looking statements should not be relied upon as representing our views as of any date subsequent to the date of this press
release.

[0001193125-15-034499:8k_2_02:28]
UNAUDITED CONSOLIDATED STATEMENTS OF OPERATIONS

[0001193125-15-034499:8k_2_02:29]
(In thousands, except per share data)

[0001193125-15-034499:8k_2_02:30]
|  |  | Three months ended |  |  | Nine months ended |  |
|  |  | December 31, |  |  | December 31, |  |
|  |  | 2014 |  |  | 2013 |  |  | 2014 |  |  | 2013 |  |
| Revenues |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Wind |  | $ | 15,131 |  |  | $ | 13,545 |  |  | $ | 30,244 |  |  | $ | 42,937 |  |
| Grid |  |  | 6,119 |  |  |  | 7,018 |  |  |  | 15,157 |  |  |  | 24,893 |  |
| Total Revenues |  |  | 21,250 |  |  |  | 20,563 |  |  |  | 45,401 |  |  |  | 67,830 |  |
| Cost of revenues |  |  | 18,094 |  |  |  | 15,863 |  |  |  | 43,953 |  |  |  | 56,461 |  |
| Gross profit |  |  | 3,156 |  |  |  | 4,700 |  |  |  | 1,448 |  |  |  | 11,369 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Research and development |  |  | 2,795 |  |  |  | 2,951 |  |  |  | 8,993 |  |  |  | 9,061 |  |
| Selling, general and administrative |  |  | 7,550 |  |  |  | 8,232 |  |  |  | 23,534 |  |  |  | 27,741 |  |
| Arbitration award expense |  |  | — |  |  |  | — |  |  |  | 10,188 |  |  |  | — |  |
| Restructuring and impairments |  |  | 507 |  |  |  | 108 |  |  |  | 5,416 |  |  |  | 872 |  |
| Amortization of acquisition related intangibles |  |  | 39 |  |  |  | 84 |  |  |  | 118 |  |  |  | 247 |  |
| Total operating expenses |  |  | 10,891 |  |  |  | 11,375 |  |  |  | 48,249 |  |  |  | 37,921 |  |
| Operating loss |  |  | (7,735 | ) |  |  | (6,675 | ) |  |  | (46,801 | ) |  |  | (26,552 | ) |
| Change in fair value of derivatives and warrants |  |  | 2,288 |  |  |  | 535 |  |  |  | 3,048 |  |  |  | 1,890 |  |
| Interest expense, net |  |  | (525 | ) |  |  | (1,634 | ) |  |  | (1,555 | ) |  |  | (7,250 | ) |
| Other (expense) income, net |  |  | (209 | ) |  |  | (341 | ) |  |  | 379 |  |  |  | (908 | ) |
| Loss before income tax expense |  |  | (6,181 | ) |  |  | (8,115 | ) |  |  | (44,929 | ) |  |  | (32,820 | ) |
| Income tax expense |  |  | 172 |  |  |  | 302 |  |  |  | 363 |  |  |  | 733 |  |
| Net loss |  | $ | (6,353 | ) |  | $ | (8,417 | ) |  | $ | (45,292 | ) |  | $ | (33,553 | ) |
| Net loss per common share |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | (0.07 | ) |  | $ | (0.14 | ) |  | $ | (0.55 | ) |  | $ | (0.55 | ) |
| Diluted |  | $ | (0.07 | ) |  | $ | (0.14 | ) |  | $ | (0.55 | ) |  | $ | (0.55 | ) |
| Weighted average number of common shares outstanding |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  |  | 87,645 |  |  |  | 62,309 |  |  |  | 82,284 |  |  |  | 60,578 |  |
| Diluted |  |  | 87,645 |  |  |  | 62,309 |  |  |  | 82,284 |  |  |  | 60,578 |  |

[0001193125-15-034499:8k_2_02:31]
| AMSC Reports Q3 Results |  | Page 5 |

[0001193125-15-034499:8k_2_02:32]
UNAUDITED CONSOLIDATED BALANCE SHEETS

[0001193125-15-034499:8k_2_02:33]
(In thousands)

[0001193125-15-034499:8k_2_02:34]
|  |  | December 31, |  |  | March 31, |  |
|  |  | 2014 |  |  | 2014 |  |
| ASSETS |  |  |  |  |  |  |  |  |
| Current assets: |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 35,983 |  |  | $ | 43,114 |  |
| Accounts receivable, net |  |  | 10,778 |  |  |  | 7,556 |  |
| Inventory |  |  | 26,536 |  |  |  | 20,694 |  |
| Prepaid expenses and other current assets |  |  | 11,705 |  |  |  | 9,004 |  |
| Restricted cash |  |  | 1,508 |  |  |  | 2,913 |  |
| Total current assets |  |  | 86,510 |  |  |  | 83,281 |  |
| Property, plant and equipment, net |  |  | 58,257 |  |  |  | 64,574 |  |
| Intangibles, net |  |  | 1,565 |  |  |  | 1,995 |  |
| Restricted cash |  |  | 100 |  |  |  | 3,394 |  |
| Deferred tax assets |  |  | 7,724 |  |  |  | 7,724 |  |
| Other assets |  |  | 2,833 |  |  |  | 7,541 |  |
| Total assets |  | $ | 156,989 |  |  | $ | 168,509 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |  |  |  |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |  |  |  |
| Accounts payable and accrued expenses |  | $ | 24,805 |  |  | $ | 21,764 |  |
| Accrued arbitration liability |  |  | 10,323 |  |  |  | — |  |
| Note payable, current portion, net of discount of $306 as of December 31, 2014 and $555 as of March 31, 2014 |  |  | 3,694 |  |  |  | 6,240 |  |
| Derivative liabilities |  |  | 3,914 |  |  |  | 2,601 |  |
| Deferred revenue |  |  | 15,385 |  |  |  | 9,456 |  |
| Deferred tax liabilities |  |  | 7,724 |  |  |  | 7,761 |  |
| Total current liabilities |  |  | 65,845 |  |  |  | 47,822 |  |
| Note Payable, net of current portion and discount of $298 as of December 31, 2014 and $287 as of March 31, 2014 |  |  | 4,868 |  |  |  | 6,380 |  |
| Deferred revenue |  |  | 2,906 |  |  |  | 990 |  |
| Other liabilities |  |  | 895 |  |  |  | 1,058 |  |
| Total liabilities |  |  | 74,514 |  |  |  | 56,250 |  |
| Stockholders’ equity: |  |  |  |  |  |  |  |  |
| Common stock |  |  | 961 |  |  |  | 789 |  |
| Additional paid-in capital |  |  | 983,406 |  |  |  | 966,390 |  |
| Treasury stock |  |  | (771 | ) |  |  | (370 | ) |
| Accumulated other comprehensive income |  |  | 560 |  |  |  | 1,839 |  |
| Accumulated deficit |  |  | (901,681 | ) |  |  | (856,389 | ) |
| Total stockholders’ equity |  |  | 82,475 |  |  |  | 112,259 |  |
| Total liabilities and stockholders’ equity |  | $ | 156,989 |  |  | $ | 168,509 |  |

[0001193125-15-034499:8k_2_02:35]
| AMSC Reports Q3 Results |  | Page 6 |

[0001193125-15-034499:8k_2_02:36]
UNAUDITED CONSOLIDATED STATEMENTS OF CASH FLOWS

[0001193125-15-034499:8k_2_02:37]
(In thousands)

[0001193125-15-034499:8k_2_02:38]
|  |  | Nine months ended December 31, |  |
|  |  | 2014 |  |  | 2013 |  |
| Cash flows from operating activities: |  |  |  |  |  |  |  |  |
| Net loss |  | $ | (45,292 | ) |  | $ | (33,553 | ) |
| Adjustments to reconcile net loss to net cash used in operations: |  |  |  |  |  |  |  |  |
| Depreciation and amortization |  |  | 7,298 |  |  |  | 8,052 |  |
| Stock-based compensation expense |  |  | 4,620 |  |  |  | 7,328 |  |
| Impairment of long lived assets |  |  | 3,464 |  |  |  | — |  |
| Provision for excess and obsolete inventory |  |  | 1,401 |  |  |  | 287 |  |
| Loss on minority interest investments |  |  | 644 |  |  |  | 789 |  |
| Change in fair value of derivatives and warrants |  |  | (3,048 | ) |  |  | (1,890 | ) |
| Non-cash interest expense |  |  | 490 |  |  |  | 5,902 |  |
| Other non-cash items |  |  | (838 | ) |  |  | 1,181 |  |
| Changes in operating asset and liability accounts: |  |  |  |  |  |  |  |  |
| Accounts receivable |  |  | (3,434 | ) |  |  | 10,414 |  |
| Inventory |  |  | (7,598 | ) |  |  | 8,682 |  |
| Prepaid expenses and other current assets |  |  | (3,072 | ) |  |  | 3,462 |  |
| Accounts payable and accrued expenses |  |  | 5,694 |  |  |  | (8,445 | ) |
| Accrued arbitration liability |  |  | 10,328 |  |  |  | — |  |
| Deferred revenue |  |  | 8,409 |  |  |  | (20,575 | ) |
| Net cash used in operating activities |  |  | (20,934 | ) |  |  | (18,366 | ) |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |
| Net cash provided by investing activities |  |  | 4,355 |  |  |  | 4,398 |  |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |
| Net cash provided by financing activities |  |  | 9,747 |  |  |  | 9,750 |  |
| Effect of exchange rate changes on cash and cash equivalents |  |  | (299 | ) |  |  | 369 |  |
| Net decrease in cash and cash equivalents |  |  | (7,131 | ) |  |  | (3,849 | ) |
| Cash and cash equivalents at beginning of year |  |  | 43,114 |  |  |  | 39,243 |  |
| Cash and cash equivalents at end of period |  | $ | 35,983 |  |  | $ | 35,394 |  |

[0001193125-15-034499:8k_2_02:39]
| AMSC Reports Q3 Results |  | Page 7 |

[0001193125-15-034499:8k_2_02:40]
RECONCILIATION OF GAAP NET INCOME (LOSS) TO NON-GAAP NET INCOME (LOSS)

[0001193125-15-034499:8k_2_02:41]
(In thousands, except per share data)

[0001193125-15-034499:8k_2_02:42]
|  |  | Three months ended December 31, |  |  | Nine months ended December 31, |  |
|  |  | 2014 |  |  | 2013 |  |  | 2014 |  |  | 2013 |  |
| Net loss |  | $ | (6,353 | ) |  | $ | (8,417 | ) |  | $ | (45,292 | ) |  | $ | (33,553 | ) |
| Stock-based compensation |  |  | 1,521 |  |  |  | 3,040 |  |  |  | 4,620 |  |  |  | 7,328 |  |
| Arbitration award expense |  |  | — |  |  |  | — |  |  |  | 10,188 |  |  |  | — |  |
| Amortization of acquisition-related intangibles |  |  | 39 |  |  |  | 84 |  |  |  | 118 |  |  |  | 247 |  |
| Restructuring and impairment charges |  |  | 507 |  |  |  | 108 |  |  |  | 5,416 |  |  |  | 872 |  |
| Sinovel litigation |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (7 | ) |
| Consumption of zero cost-basis inventory |  |  | (3,143 | ) |  |  | (1,142 | ) |  |  | (5,710 | ) |  |  | (3,635 | ) |
| Change of fair value of derivatives and warrants |  |  | (2,288 | ) |  |  | (535 | ) |  |  | (3,048 | ) |  |  | (1,890 | ) |
| Non-cash interest expense |  |  | 147 |  |  |  | 1,137 |  |  |  | 490 |  |  |  | 5,902 |  |
| Non-GAAP net loss |  | $ | (9,570 | ) |  | $ | (5,725 | ) |  | $ | (33,218 | ) |  | $ | (24,736 | ) |
| Non-GAAP loss per share |  | $ | (0.11 | ) |  | $ | (0.09 | ) |  | $ | (0.40 | ) |  | $ | (0.41 | ) |
| Weighted average shares outstanding |  |  | 87,645 |  |  |  | 62,309 |  |  |  | 82,284 |  |  |  | 60,578 |  |

[0001193125-15-034499:8k_2_02:43]
RECONCILIATION OF FORECAST GAAP NET LOSS TO NON-GAAP

[0001193125-15-034499:8k_2_02:44]
NET LOSS

[0001193125-15-034499:8k_2_02:45]
(In millions,
except per share data)

[0001193125-15-034499:8k_2_02:46]
|  |  | Three months endingMarch 31, 2015 |  |
| Net loss |  | $ | (6.0 | ) |
| Stock-based compensation |  |  | 1.5 |  |
| Arbitration award expense |  |  | (1.3 | ) |
| Restructuring and impairment charges |  |  | 0.1 |  |
| Non-cash interest expense |  |  | 0.1 |  |
| Consumption of zero-cost inventory |  |  | (1.4 | ) |
| Non-GAAP net loss |  | $ | (7.0 | ) |
| Non-GAAP net loss per share |  | $ | (0.07 | ) |
| Shares outstanding |  |  | 95.8 |  |

[0001193125-15-034499:8k_2_02:47]
Note: Non-GAAP net loss is defined by the Company as net loss before stock-based compensation; arbitration award expense;
amortization of acquisition-related intangibles; restructuring and impairment charges; Sinovel litigation; consumption of zero

[0001193125-15-034499:8k_2_02:48]
| AMSC Reports Q3 Results |  | Page 8 |

[0001193125-15-034499:8k_2_02:49]
cost-basis inventory; non-cash interest expense; change in fair value of derivatives and warrants; and other unusual charges, net of any tax effects related to these items. The Company believes
non-GAAP net loss assists management and investors in comparing the Company’s performance across reporting periods on a consistent basis by excluding these non-cash, non-recurring or other charges that it does not believe are indicative of its
core operating performance. The Company also regards non-GAAP net loss as a useful measure of operating performance to complement operating loss, net loss and other GAAP financial performance measures. In addition, the Company uses non-GAAP net loss
as a factor in evaluating management’s performance when determining incentive compensation and to evaluate the effectiveness of its business strategies.

[0001193125-15-034499:8k_2_02:50]
Generally, a non-GAAP financial measure is a numerical measure of a company’s performance, financial position or cash flow that either excludes or
includes amounts that are not normally excluded or included in the most directly comparable measure calculated and presented in accordance with GAAP. The non-GAAP measures included in this release, however, should be considered in addition to, and
not as a substitute for or superior to, operating income, cash flows, or other measures of financial performance prepared in accordance with GAAP. A reconciliation of non-GAAP to GAAP net loss is set forth in the table above.

[0001193125-15-034499:8k_2_02:51]
AMSC Contact:

[0001193125-15-034499:8k_2_02:52]
Kerry Farrell

[0001193125-15-034499:8k_2_02:53]
Phone: 978-842-3247

[0001193125-15-034499:8k_2_02:54]
Email: kerry.farrell @ amsc.com
