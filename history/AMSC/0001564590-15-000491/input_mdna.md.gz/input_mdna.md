# AMSC MD&A — 0001564590-15-000491


## mdna

[0001564590-15-000491:mdna:1]
[same as prior period, unchanged from 0001564590-14-005096:mdna:1]

[0001564590-15-000491:mdna:2]
ability to license such patents or other proprietary rights; Our technology and products could infringe intellectual property rights of others, which may require costly litigation and, if we are not successful, could cause us to pay substantial damages and disrupt our business; We have filed a demand for arbitration and other lawsuits against our former largest customer, Sinovel, regarding amounts we contend are overdue. We cannot be certain as to the outcome of these proceedings; We have been named as a party in various legal proceedings, and we may be named in additional litigation, all of which will require significant management time and attention, result in significant legal expenses and may result in an unfavorable outcome, which could have a material adverse effect on our business, operating results and financial condition; Our common stock has experienced, and may continue to experience, significant market price and volume fluctuations, which may prevent our stockholders from selling our common stock at a profit and could lead to costly litigation against us that could divert our management’s attention; we will not be able to maintain our listing on The Nasdaq Global Select Market if we are unable to regain compliance with The NASDAQ Stock Market LLC’s minimum bid price requirement of $1.00 per share.  These and the important factors discussed under the caption “Risk Factors” in Part 1. Item 1A of our Form 10-K for the fiscal year ended March 31, 2014, among others, could cause actual results to differ materially from those indicated by forward-looking statements made herein and presented elsewhere by management from time to time. Any such forward-looking statements represent management’s estimates as of the date of this Quarterly Report on Form 10-Q. While we may elect to update such forward-looking statements at some point in the future, we disclaim any obligation to do so, even if subsequent events cause our views to change. These forward-looking statements should not be relied upon as representing our views as of any date subsequent to the date of this Quarterly Report on Form 10-Q.

[0001564590-15-000491:mdna:3]
[same as prior period, unchanged from 0001564590-14-005096:mdna:4]

[0001564590-15-000491:mdna:4]
[same as prior period, unchanged from 0001564590-14-005096:mdna:5]

[0001564590-15-000491:mdna:5]
[same as prior period, unchanged from 0001564590-14-005096:mdna:6]

[0001564590-15-000491:mdna:6]
[same as prior period, unchanged from 0001564590-14-005096:mdna:7]

[0001564590-15-000491:mdna:7]
[same as prior period, unchanged from 0001564590-14-005096:mdna:8]

[0001564590-15-000491:mdna:8]
[same as prior period, unchanged from 0001564590-14-005096:mdna:9]

[0001564590-15-000491:mdna:9]
| ● | Wind. Through our Windtec Solutions, our Wind business segment enables manufacturers to field wind turbines with exceptional power output, reliability and affordability. We supply advanced power electronics and control systems, license our highly engineered wind turbine designs, and provide extensive customer support services to wind turbine manufacturers. Our design portfolio includes a broad range of drive trains and power ratings. We provide a broad range of power electronics and software-based control systems that are highly integrated and redesigned for optimized performance, efficiency, and grid compatibility. |

[0001564590-15-000491:mdna:10]
| ● | Grid. Through our Gridtec Solutions, our Grid business segment enables electric utilities and renewable energy project developers to connect, transmit and distribute power with exceptional efficiency, reliability, security and affordability. We provide transmission planning services that allow us to identify power grid congestion, poor power quality and other risks, which help us determine how our solutions can improve network performance. These services often lead to sales of grid interconnection solutions for wind farms and solar power plants, power quality systems and transmission and distribution cable systems. |

[0001564590-15-000491:mdna:11]
[same as prior period, unchanged from 0001564590-14-005096:mdna:12]

[0001564590-15-000491:mdna:12]
On June 5, 2012 we entered into a $10.0 million Loan and Security Agreement (“Term Loan”) with Hercules Technology Growth Capital, Inc. (“Hercules”).  This loan was repaid in full during the three months ended December 31, 2014.  On November 15, 2013, we amended the Term Loan with Hercules and entered into a new term loan (“New Term Loan B”), borrowing an additional $10.0 million.  On December 19, 2014 we further amended the Term Loan and entered into a new term loan (“New Term Loan C”), borrowing an additional $1.5 million.    The outstanding principal balance of the Term Loans is approximately $9.2 million as of December 31, 2014.

[0001564590-15-000491:mdna:13]
On November 15, 2013, we entered into an At Market Sales Arrangement (“ATM”) under which we were able to, at our discretion, sell up to $30.0 million of shares of our common stock (before expenses) through our sales agent, MLV & Co. LLC (“MLV”). Under this arrangement, we raised approximately $13.5 million in net proceeds.  We terminated the ATM on November 5, 2014.

[0001564590-15-000491:mdna:14]
On November 13, 2014, we completed an offering of approximately 9.1 million shares of common stock at $1.10 per share with a new investor (the “November 2014 offering”).  The offering was in the form of units, with each unit consisting of one share of stock and 0.9 of a warrant to purchase one share of common stock, or a warrant to purchase in the aggregate 8.2 million shares.  See “Liquidity and Capital Resources” below for further discussion of this and our other financing arrangements.

[0001564590-15-000491:mdna:15]
We have experienced recurring operating losses and as of December 31, 2014, had an accumulated deficit of $901.7 million. In addition, we have experienced recurring negative operating cash flows. At December 31, 2014, we had cash and cash equivalents of $36.0 million. Cash used in operations for the nine months ended December 31, 2014 was $20.9 million.

[0001564590-15-000491:mdna:16]
On August 29, 2014, the Arbitration Tribunal for the ICC International Court of Arbitration (the “ICC Court”) found us liable for damages in our breach of contract arbitration against Ghodawat Energy Pvt Ltd (“Ghodawat”) and awarded Ghodawat approximately €8.3 million (approximately $10.1 million) plus interest of 5.33%, which accrues from the date of award.

[0001564590-15-000491:mdna:17]
On February 4, 2015, our wholly-owned Austrian subsidiary AMSC Austria GmbH (“AMSC Austria”) entered into a Settlement Agreement with Ghodawat, which provided for, among other things, (i) a payment by AMSC Austria to Ghodawat of  €7.45 million (approximately $8.5 million), and (ii) upon payment by AMSC Austria to Ghodawat, the full settlement of any and all disputes and claims between the parties (including their respective parent and affiliated companies), in particular relating to or arising out of the award.  We expect to pay the settlement amount during the fourth quarter of fiscal 2014.  As a result of this agreement, we expect to reverse a portion of the accrued arbitration liability and record a gain of approximately $1.3 million in the fourth quarter of fiscal 2014.  See Part II, Item 1, “Legal Proceedings” for further information.  Our insurer, Catlin Specialty Insurance Company (“Catlin”) sought and received a ruling from the Massachusetts Superior Court that coverage does not apply to the arbitration award liability.  On January 14, 2015, we and our subsidiary AMSC Austria entered into a Settlement Agreement and Release with Catlin, which provided for, among other things, (i) our and AMSC Austria’s release of all claims against Catlin relating to the arbitration award liability and (ii) Catlin’s release of all claims against us and AMSC Austria relating to approximately $2.3 million reimbursed to date under the insurance policy for expenses incurred in connection with the arbitration proceedings.  As a result of the settlement with Catlin, in the fourth quarter of fiscal 2014, the Company expects to reverse an accrual of $2.0 million for expenses previously reimbursed by Catlin under the policy.

[0001564590-15-000491:mdna:18]
We are actively seeking to sell our minority investment in Tres Amigas, LLC, a Delaware limited liability company (“Tres Amigas”).  We no longer believe our investment in Blade Dynamics is recoverable and therefore fully impaired our remaining investment in Blade Dynamics Ltd. (“Blade Dynamics”) during the nine months ended December 31, 2014. There can be no assurance that we will be able to sell these investments on commercially reasonable terms or at all.

[0001564590-15-000491:mdna:19]
[same as prior period, unchanged from 0001564590-14-005096:mdna:16]

[0001564590-15-000491:mdna:20]
[same as prior period, unchanged from 0001564590-14-005096:mdna:17]

[0001564590-15-000491:mdna:21]
[same as prior period, unchanged from 0001564590-14-005096:mdna:18]

[0001564590-15-000491:mdna:22]
[same as prior period, unchanged from 0001564590-14-005096:mdna:19]

[0001564590-15-000491:mdna:23]
We cannot provide any assurance as to the outcome of these legal actions. For more information about these legal proceedings, see Part II, Item 1, “Legal Proceedings.”

[0001564590-15-000491:mdna:24]
On January 14, 2015, we received a letter from The NASDAQ Stock Market LLC (“Nasdaq”) notifying us that we are no longer in compliance with the $1.00 per share minimum bid price requirement set forth in Nasdaq Listing Rule 5450(a)(1) for continued listing on The Nasdaq Global Select Market. We were provided 180 calendar days, or until July 13, 2015, to regain compliance with the minimum bid price requirement.  In accordance with Listing Rule 5810(c)(3)(A), we can regain compliance if the closing bid price of our common stock meets or exceeds $1.00 per share for at least 10 consecutive business days. If we are unable to demonstrate compliance by July 13, 2015, we may be eligible for additional time to regain compliance. If we are not eligible for an additional compliance period, the Nasdaq staff will provide notice that our securities will be subject to delisting from The Nasdaq Global Select Market.  The delisting of our common stock could have a negative effect on our business, results of operations, financial condition and the market price of our common stock.  To facilitate our efforts to regain compliance with the minimum bid price requirement, we filed a preliminary proxy statement with the Securities and Exchange Commission (“SEC”) on January 21, 2015 which includes a proposal seeking stockholder approval of amendments to our restated certificate of incorporation to effect a reverse stock split.  There can be no assurance that the proposal will be approved by stockholders, or that the proposal, if approved, would be sufficient to permit us to regain compliance with the minimum bid price requirement.

[0001564590-15-000491:mdna:25]
[same as prior period, unchanged from 0001564590-14-005096:mdna:21]

[0001564590-15-000491:mdna:26]
The preparation of the unaudited condensed consolidated financial statements requires that we make estimates and judgments that affect the reported amounts of assets, liabilities, revenues and expenses, and related disclosure of contingent assets and liabilities. We base our estimates on historical experience and various other assumptions that are believed to be reasonable under the circumstances, the results of which form the basis for making judgments about the carrying values of assets and liabilities that are not readily apparent from other sources. Actual results may differ under different assumptions or conditions. There were no significant changes in the critical accounting policies during the nine months ended December 31, 2014 that were disclosed in our Form 10-K for fiscal 2013, which ended on March 31, 2014.

[0001564590-15-000491:mdna:27]
[same as prior period, unchanged from 0001564590-14-005096:mdna:23]

[0001564590-15-000491:mdna:28]
Three and nine months ended December 31, 2014 compared to the three and nine months ended December 31, 2013

[0001564590-15-000491:mdna:29]
[same as prior period, unchanged from 0001564590-14-005096:mdna:25]

[0001564590-15-000491:mdna:30]
Total revenues increased 3% to $21.3 million for the three months ended December 21, 2014, compared to $20.6 million for the three months ended December 31, 2013.  Total revenues decreased 33% to $45.4 million for the nine months ended December 31, 2014, compared to $67.8 million for the nine months ended December 31, 2013. Our revenues are summarized as follows (in thousands):

[0001564590-15-000491:mdna:31]
|  | Three Months Ended December 31, |  |  | Nine months ended December 31, |  |
|  | 2014 |  |  | 2013 |  |  | 2014 |  |  | 2013 |  |
| Revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Wind | $ | 15,131 |  |  | $ | 13,545 |  |  | $ | 30,244 |  |  | $ | 42,937 |  |
| Grid |  | 6,119 |  |  |  | 7,018 |  |  |  | 15,157 |  |  |  | 24,893 |  |
| Total | $ | 21,250 |  |  | $ | 20,563 |  |  | $ | 45,401 |  |  | $ | 67,830 |  |

[0001564590-15-000491:mdna:32]
Our Wind business unit accounted for 71% and 67% of total revenues for the three and nine months ended December 31, 2014, respectively compared to 66% and 63% for the three and nine months ended December 31, 2013, respectively. Revenues in the Wind business unit increased 12% to $15.1 million in the three months ended December 31, 2014, from $13.5 million in the three months ended December 31, 2013. Wind business unit revenues during the three months ended December 31, 2014 increased primarily due to higher revenues from INOX Wind Limited (“Inox”) in India.  Revenues in the Wind business unit decreased 30% to $30.2 million in the nine months ended December 31, 2014, from $42.9 million in the nine months ended December 31, 2013.  Wind business unit revenues during the nine months ended December 31, 2014 decreased due to lower revenues from customers in China, partially offset by higher revenues from Inox in India.

[0001564590-15-000491:mdna:33]
Our Grid business unit accounted for 29% and 33% of total revenues for the three and nine months ended December 31, 2014, respectively, compared to 34% and 37% for the three and nine months ended December 31, 2013, respectively. Our Grid business unit revenues decreased 13% and 39% to $6.1 million and $15.2 million in the three and nine months ended December 31, 2014, respectively, from $7.0 million and $24.9 million in the three and nine months ended December 31, 2013, respectively. Grid business unit revenues decreased in the three and nine months ended December 31, 2014 primarily due to lower D-VAR system revenues.

[0001564590-15-000491:mdna:34]
Project HYDRA is a project with Consolidated Edison, Inc. which is being partially funded by the Department of Homeland Security (“DHS”). DHS is expected to invest up to a total of $29.0 million in the development of a new HTS power grid technology called Resilient Electric Grid systems. This fault current limiting cable system is designed to utilize customized Amperium® HTS wires, and ancillary controls to deliver more power through the grid while also being able to suppress power surges that can disrupt service. DHS has now committed 100% of the total expected funding for this project. Consolidated Edison and Southwire Company are our subcontractors on this project. We recorded $0.5 million and $1.0 million of revenue on this project for the three and nine month periods ended December 31, 2014, respectively, compared to $0.5 million and $1.6 million for the three and nine months ended December 31, 2013, respectively.

[0001564590-15-000491:mdna:35]
The following table sets forth customers who represented 10% or more of our total revenues for the three and nine months ended December 31, 2014 and 2013:

[0001564590-15-000491:mdna:36]
|  | Three months ended December 31, |  |  | Nine months ended December 31, |  |
|  | 2014 |  |  | 2013 |  |  | 2014 |  |  | 2013 |  |
| INOX Wind Limited |  | 61 | % |  |  | 35 | % |  |  | 54 | % |  |  | 25 | % |
| Beijing JINGCHENG New Energy Co., Ltd | <10 | % |  | <10 | % |  | <10 | % |  |  | 22 | % |
| CSR Zhuzhou Institute Co., Ltd |  | — | % |  |  | 18 | % |  |  | — | % |  | <10 | % |

[0001564590-15-000491:mdna:37]
[same as prior period, unchanged from 0001564590-14-005096:mdna:33]

[0001564590-15-000491:mdna:38]
Cost of revenues was $18.1 million and $44.0 million for the three and nine months ended December 31, 2014, respectively, compared to $15.9 million and $56.5 million for the three and nine months ended December 31, 2013, respectively. Gross margin was 14.9% and 3.2% for the three and nine months ended December 31, 2014, respectively, compared to 22.9% and 16.8% for the three and nine months ended December 31, 2013, respectively. The decreases in gross margin for the three and nine months ended December 31, 2014 as compared to the same periods in fiscal 2013 were primarily due to 100% margin revenue during the three and nine months ended December 31, 2013, the completion and recording of deferred retention on a large D-VAR project, partially offset by higher usage of previously written off inventory, during the three and nine months ended December 31, 2014.

[0001564590-15-000491:mdna:39]
[same as prior period, unchanged from 0001564590-14-005096:mdna:35]

[0001564590-15-000491:mdna:40]
[same as prior period, unchanged from 0001564590-14-005096:mdna:36]

[0001564590-15-000491:mdna:41]
[same as prior period, unchanged from 0001564590-14-005096:mdna:37]

[0001564590-15-000491:mdna:42]
|  | Three months ended December 31, |  |  | Nine months ended December 31, |  |
|  | 2014 |  |  | 2013 |  |  | 2014 |  |  | 2013 |  |
| R&D expenses per consolidated statements of operations | $ | 2,795 |  |  | $ | 2,951 |  |  | $ | 8,993 |  |  | $ | 9,061 |  |
| R&D expenditures reclassified as cost of revenues |  | 2,299 |  |  |  | 2,740 |  |  |  | 6,199 |  |  |  | 7,675 |  |
| R&D expenditures offset by cost-sharing funding |  | 24 |  |  |  | 80 |  |  |  | 59 |  |  |  | 279 |  |
| Aggregated R&D expenses | $ | 5,118 |  |  | $ | 5,771 |  |  | $ | 15,251 |  |  | $ | 17,015 |  |

[0001564590-15-000491:mdna:43]
R&D expenses (exclusive of amounts classified as cost of revenues and amounts offset by cost-sharing funding) decreased by 5% and 1% to $2.8 million and $9.0 million for the three and nine months ended December 31, 2014, respectively, from $3.0 million and $9.1 million for the three and nine months ended December 31, 2013, respectively.   The decreases in R&D expenses for the three and nine months ended December 31, 2014 were driven primarily by decreases in controllable expenses.  The decreases in R&D expenditures reclassified to cost of revenue for the three and nine month periods was a result of decreased activity under government funded contracts in our Grid business unit compared to the prior year periods.  Aggregated R&D expenses, which include amounts classified as cost of revenues and amounts offset by cost-sharing funding decreased 11% and 10% to $5.1 million and $15.3 million for the three and nine months ended December 31, 2014, respectively, from $5.8 million and $17.0 million for the three and nine months ended December 31, 2013 respectively.

[0001564590-15-000491:mdna:44]
[same as prior period, unchanged from 0001564590-14-005096:mdna:40]

[0001564590-15-000491:mdna:45]
[same as prior period, unchanged from 0001564590-14-005096:mdna:41]

[0001564590-15-000491:mdna:46]
SG&A expenses decreased by 8% and 15% to $7.6 million and $23.5 million in the three and nine months ended December 31, 2014, respectively, from $8.2 million and $27.7 million in the three and nine months ended December 31, 2013, respectively. The decreases in SG&A expenses were due primarily to the realization of savings from cost reduction actions that were implemented in prior periods as well as a reduction in stock compensation, audit and legal costs.

[0001564590-15-000491:mdna:47]
[same as prior period, unchanged from 0001564590-14-005096:mdna:43]

[0001564590-15-000491:mdna:48]
We recorded an arbitration award expense of $10.2 million in the nine months ended December 31, 2014 following a decision by the ICC Court on August 29, 2014, finding us liable for damages under a breach of contract proceeding against Ghodawat.

[0001564590-15-000491:mdna:49]
[same as prior period, unchanged from 0001564590-14-005096:mdna:45]

[0001564590-15-000491:mdna:50]
We recorded amortization expense related to our core technology and know-how, trade names and trademark intangible assets of less than $0.1 million and $0.1 million in the three and nine months ended December 31, 2014 compared to $0.1 million and $0.2 million in the three and nine months ended December 31, 2013, respectively.

[0001564590-15-000491:mdna:51]
[same as prior period, unchanged from 0001564590-14-005096:mdna:48]

[0001564590-15-000491:mdna:52]
We recorded $0.5 million and $5.4 million of restructuring and impairment charges in the three and nine months ended December 31, 2014, respectively. We recorded restructuring and impairment charges of $0.1 million and $0.9 million in the three and nine months ended December 31, 2013, respectively. This amount includes restructuring charges of $0.5 million and $1.9 million which were recorded during the three and nine months ended December 31, 2014.  These amounts include severance, relocation, lease termination and other costs associated with the consolidation of our facility in Middleton, WI into our facility in Devens, MA, as well as headcount reductions in our China operation, primarily during the nine months ended December 31, 2014.  In addition, the $5.4 million recorded in the nine months ended December 31, 2014 includes of an impairment charge of $3.5 million on our minority investment in Blade Dynamics.  The impairment charge followed an analysis in which we determined that this investment is not recoverable due to a dilutive financing which resulted in the loss of certain of our shareholder rights, as well as certain operational issues in the company.  The amounts in the three months ended December 31, 2013 consist primarily of employee severance and benefit costs.

[0001564590-15-000491:mdna:53]
Operating profit (loss)

[0001564590-15-000491:mdna:54]
Our operating profit (loss) is summarized as follows (in thousands):

[0001564590-15-000491:mdna:55]
|  | Three months ended December 31, |  |  | Nine months ended December 31, |  |
|  | 2014 |  |  | 2013 |  |  | 2014 |  |  | 2013 |  |
| Operating profit (loss): |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Wind | $ | 1,301 |  |  | $ | 1,067 |  |  | $ | (16,790 | ) |  | $ | (3,207 | ) |
| Grid |  | (7,050 | ) |  |  | (4,670 | ) |  |  | (20,016 | ) |  |  | (15,287 | ) |
| Unallocated corporate expenses |  | (1,986 | ) |  |  | (3,072 | ) |  |  | (9,995 | ) |  |  | (8,058 | ) |
| Total | $ | (7,735 | ) |  | $ | (6,675 | ) |  | $ | (46,801 | ) |  | $ | (26,552 | ) |

[0001564590-15-000491:mdna:56]
Our Wind segment generated an operating profit of $1.3 million and an operating loss of $16.8 million in the three and nine months ended December 31, 2014, respectively, compared to an operating profit of $1.1 million and an operating loss of $3.2 million in the three and nine months ended December 31, 2013, respectively. The increase in Wind business unit operating profit during the three months ended December 31, 2014 was due primarily to increased usage of previously written off inventory, partially offset by 100% margin revenue in the three months ended December 31, 2013.  The increase in Wind business unit operating loss during the nine months ended December 31, 2014 was due primarily to the Ghodawat arbitration award and lower revenues.

[0001564590-15-000491:mdna:57]
The operating loss in our Grid segment increased to $7.1 million and $20.0 million in the three and nine months ended December 31, 2014, respectively, compared to $4.7 million and $15.3 million in the three and nine months ended December 31, 2013, respectively. The increases in the Grid business unit operating losses were primarily due to lower revenue, as previously discussed.

[0001564590-15-000491:mdna:58]
Unallocated corporate expenses primarily include stock-based compensation expense of $1.5 million and $4.6 million, and restructuring and impairment charges of $0.5 million and $5.4 million, for the three and nine months ended December 31, 2014, respectively.  Unallocated corporate expenses primarily consist of stock-based compensation expense of $3.0 million and $7.3 million,  and restructuring and impairment charges of $0.1 million and $0.9 million for the three and nine months ended December 31, 2013, respectively.

[0001564590-15-000491:mdna:59]
[same as prior period, unchanged from 0001564590-14-005096:mdna:56]

[0001564590-15-000491:mdna:60]
The change in fair value of derivatives and warrants resulted in gains of $2.3 million and $3.0 million in the three and nine months ended December 31, 2014, respectively, compared to gains of $0.5 million and $1.9 million for the three and nine months ended December 31, 2013, respectively. The increases were primarily driven by a lower stock price, which is a key valuation metric, and revaluation of new warrants issued as part of the November 2014 offering, partially offset by the extinguishment of the derivative liability associated with our convertible note in the prior year.

[0001564590-15-000491:mdna:61]
[same as prior period, unchanged from 0001564590-14-005096:mdna:58]

[0001564590-15-000491:mdna:62]
Interest expense, net, was $0.5 million and $1.6 million in the three and nine months ended December 31, 2014, respectively, compared to $1.6 million and $7.3 million in the three and nine months ended December 31, 2013, respectively. The decreases in interest expense, net were due primarily to the extinguishment of our convertible note in March 2014.

[0001564590-15-000491:mdna:63]
35

[0001564590-15-000491:mdna:64]
Other (expense) income, net

[0001564590-15-000491:mdna:65]
Other expense, net, was $0.2 million and other income, net was $0.4 million in the three and nine months ended December 31, 2014, respectively, compared to other expense, net, of $0.3 million and $0.9 million in the three and nine months ended December 31, 2013, respectively.  The decreases in other expense, net are primarily related to foreign currency gains offset by financing costs associated with the warrants issued in the three month period ended December 31, 2014.

[0001564590-15-000491:mdna:66]
[same as prior period, unchanged from 0001564590-14-005096:mdna:62]

[0001564590-15-000491:mdna:67]
Income tax expense was $0.2 million and $0.4 million in the three and nine months ended December 31, 2014, respectively, compared to $0.3 million and $0.7 million in the three and nine months ended December 31, 2013, respectively. Income tax expense in both periods was primarily due to income taxes in foreign jurisdictions.

[0001564590-15-000491:mdna:68]
[same as prior period, unchanged from 0001564590-14-005096:mdna:64]

[0001564590-15-000491:mdna:69]
[same as prior period, unchanged from 0001564590-14-005096:mdna:65]

[0001564590-15-000491:mdna:70]
We define non-GAAP net loss as net loss before stock-based compensation, arbitration award expense, amortization of acquisition-related intangibles, restructuring and impairment charges, Sinovel litigation, consumption of zero cost-basis inventory, changes in fair value of derivatives and warrants, non-cash interest expense, and the other non-cash or unusual, net of any tax effects related to these items, indicated in the table below. We believe non-GAAP net loss assists management and investors in comparing our performance across reporting periods on a consistent basis by excluding these non-cash or non-recurring charges that we do not believe are indicative of our core operating performance. We also regard non-GAAP net loss as a useful measure of operating performance which more closely aligns net loss with cash used in/provided by continuing operations. In addition, we use non-GAAP net loss as a factor in evaluating management’s performance when determining incentive compensation and to evaluate the effectiveness of our business strategies. A reconciliation of non-GAAP to GAAP net loss is set forth in the table below (in thousands, except per share data):

[0001564590-15-000491:mdna:71]
|  | Three months ended December 31, |  |  | Nine months ended December 31, |
|  | 2014 |  |  | 2013 |  |  | 2014 |  |  | 2013 |  |  |
| Net loss | $ | (6,353 | ) |  | $ | (8,417 | ) |  | $ | (45,292 | ) |  | $ | (33,553 | ) |  |
| Stock-based compensation |  | 1,521 |  |  |  | 3,040 |  |  |  | 4,620 |  |  |  | 7,328 |  |  |
| Arbitration award expense |  | - |  |  |  | - |  |  |  | 10,188 |  |  |  | - |  |  |
| Amortization of acquisition-related intangibles |  | 39 |  |  |  | 84 |  |  |  | 118 |  |  |  | 247 |  |  |
| Restructuring and impairment charges |  | 507 |  |  |  | 108 |  |  |  | 5,416 |  |  |  | 872 |  |  |
| Sinovel litigation |  | - |  |  |  | - |  |  |  | - |  |  |  | (7 | ) |  |
| Consumption of zero cost-basis inventory |  | (3,143 | ) |  |  | (1,142 | ) |  |  | (5,710 | ) |  |  | (3,635 | ) |  |
| Change in fair value of derivatives and warrants |  | (2,288 | ) |  |  | (535 | ) |  |  | (3,048 | ) |  |  | (1,890 | ) |  |
| Non-cash interest expense |  | 147 |  |  |  | 1,137 |  |  |  | 490 |  |  |  | 5,902 |  |  |
| Non-GAAP net loss | $ | (9,570 | ) |  | $ | (5,725 | ) |  | $ | (33,218 | ) |  | $ | (24,736 | ) |  |
| Non-GAAP loss per share | $ | (0.11 | ) |  | $ | (0.09 | ) |  | $ | (0.40 | ) |  | $ | (0.41 | ) |  |
| Weighted average shares outstanding - basic and diluted |  | 87,645 |  |  |  | 62,309 |  |  |  | 82,284 |  |  |  | 60,578 |  |  |

[0001564590-15-000491:mdna:72]
We incurred non-GAAP net losses of $9.6 million and $33.2 million or $0.11 and $0.40 per share, for the three and nine months ended December 31, 2014, respectively, compared to non-GAAP net losses of $5.7 million and $24.7 million, or $0.09 and $0.41 per share, for the three and nine months ended December 31, 2013, respectively. The increases in non-GAAP net loss were driven primarily by the increased operating losses in our business units excluding usage of previously written off inventory and the arbitration award expense, which are part of the operating losses in our Wind segment for the three and nine months ended December 31, 2014.

[0001564590-15-000491:mdna:73]
[same as prior period, unchanged from 0001564590-14-005096:mdna:70]

[0001564590-15-000491:mdna:74]
At December 31, 2014, we had cash, cash equivalents, and restricted cash of $37.6 million, compared to $49.4 million at March 31, 2014, a decrease of $11.8 million. Our cash and cash equivalents, and restricted cash are summarized as follows (in thousands):

[0001564590-15-000491:mdna:75]
|  | December 31, |  |  | March 31, |  |
|  | 2014 |  |  | 2014 |  |
| Cash and cash equivalents | $ | 35,983 |  |  | $ | 43,114 |  |
| Restricted cash |  | 1,608 |  |  |  | 6,307 |  |
| Total cash, cash equivalents, and restricted cash | $ | 37,591 |  |  | $ | 49,421 |  |

[0001564590-15-000491:mdna:76]
For the nine months ended December 31, 2014, net cash used in operating activities was $20.9 million compared to $18.4 million for the nine months ended December 31, 2013. The increase in net cash used in operations was due primarily to lower revenues combined with a lower gross margin during the nine months ended December 31, 2014, partially offset by higher cash generated by changes in asset and liability accounts, excluding the arbitration award liability due primarily to a net increase in cash from deferred revenues in the nine months ended December 31, 2014 compared to a net decrease in the nine months ended December 31, 2013.

[0001564590-15-000491:mdna:77]
For the nine months ended December 31, 2014, net cash provided by investing activities was $4.4 million, compared to $4.4 million for the nine months ended December 31, 2013.

[0001564590-15-000491:mdna:78]
For the nine months ended December 31, 2014, net cash provided by financing activities was $9.7 million compared to net cash provided by financing activities of $9.8 million in the nine months ended December 31, 2013. The decrease in net cash provided by financing activities was primarily due to net proceeds from the issuance of 9.1 million shares of common stock to a single investor in November 2014, and an increase in common stock issued under the ATM, offset by a decrease in net proceeds from the issuance of debt and higher amounts repaid for debt compared to the prior period.

[0001564590-15-000491:mdna:79]
At December 31, 2014, we had $1.5 million of restricted cash included in current assets, and $0.1 million of restricted cash included in long-term assets. These amounts included in restricted cash primarily represent deposits to secure letters of credit for various supply contracts. These deposits are held in interest bearing accounts.

[0001564590-15-000491:mdna:80]
We have experienced recurring operating losses and as of December 31, 2014, had an accumulated deficit of $901.7 million. In addition, we have experienced recurring negative operating cash flows. At December 31, 2014, we had cash and cash equivalents of $36.0 million.  On August 29, 2014, the ICC Court found our wholly-owned Austrian subsidiary, AMSC Austria, liable for damages in AMSC Austria’s breach of contract proceeding against Ghodawat and awarded Ghodawat approximately €8.3 million (approximately $10.1 million) plus interest of 5.33%, which accrues from the date of the award.

[0001564590-15-000491:mdna:81]
On February 4, 2015, AMSC Austria entered into a Settlement Agreement with Ghodawat, which provided for, among other things, (i) a payment by AMSC Austria to Ghodawat of €7.45 million (approximately $8.5 million), and (ii) upon payment by AMSC Austria to Ghodawat, the full settlement of any and all disputes and claims between the parties (including their respective parent and affiliated companies), in particular relating to or arising out of the award.  We expect to pay the settlement amount during the fourth quarter of fiscal 2014.  As a result of this Settlement Agreement, we expect to reverse a portion of the accrued arbitration liability and record a gain of approximately $1.3 million in the fourth quarter of fiscal 2014.  In addition, we are actively seeking to sell our minority investment in Tres Amigas.  We no longer believe our remaining investment in Blade Dynamics is recoverable and have fully impaired our investment in Blade Dynamics during the nine months ended December 31, 2014.  There can be no assurance that we will be able to sell these investments on commercially reasonable terms or at all.

[0001564590-15-000491:mdna:82]
On June 5, 2012, we entered into the Term Loan with Hercules, under which we borrowed $10.0 million. After the closing fees and expenses, the net proceeds were $9.7 million. The Term Loan bears an interest rate equal to 11% plus the percentage, if any, in which the prime rate as reported by The Wall Street Journal exceeds 3.75%. We made interest only payments from July 1, 2012 through October 31, 2012, after which we began paying the Term Loan in equal monthly installments ending on December 1, 2014.  As of December 31, 2014, this loan has been repaid in full.

[0001564590-15-000491:mdna:83]
On November 15, 2013, we amended the Term Loan with Hercules and entered into the New Term Loan B, borrowing an additional $10.0 million. After closing fees and expenses, we received net proceeds of $9.8 million.  The New Term Loan B bears the same interest rate as the Term Loan.  We made interest-only payments from December 1, 2013 to May 31, 2014.  If we achieved certain revenue targets for the six-month period ending March 31, 2014, interest only payments would continue through August 31, 2014.  We did not meet these revenue targets.  As a result, we are repaying the New Term Loan B in equal monthly installments ending on November 1, 2016.

[0001564590-15-000491:mdna:84]
On December 19, 2014, we entered into an amendment with Hercules (the “Hercules Second Amendment”) and entered into the New Term Loan C, borrowing an additional $1.5 million.  After closing fees and expenses, the net proceeds to us for the New Term Loan C were $1.4 million.  The New Term Loan C also bears the same interest rate as the other Term Loans.  We will make interest only payments until maturity on March 1, 2017, when the loan is scheduled to be repaid in its entirety.  If we raise an additional $10 million in new capital by December 31, 2015, the maturity date of the loan will be extended to June 1, 2017.  The outstanding principal balance of the Term Loans is approximately $9.2 million as of December 31, 2014.

[0001564590-15-000491:mdna:85]
The Term Loans are secured by substantially all of our existing and future assets, including a mortgage on real property owned by our wholly owned subsidiary, ASC Devens LLC, and located at 64 Jackson Road, Devens, Massachusetts. The Term Loans contain certain covenants that restrict our ability to, among other things, incur or assume certain debt, merge or consolidate, materially change the nature of our business, make certain investments, acquire or dispose of certain assets, make guaranties or grant liens on our assets, make certain loans, advances or investments, declare dividends or make distributions or enter into transactions with affiliates. In addition, the Term Loans contain a covenant which requires us to maintain a minimum unrestricted cash balance (“Minimum Threshold”) in the United States.  As part of the Hercules Second Amendment, this Minimum Threshold was amended to be the lower of $5.0 million or the aggregate outstanding principal balance of the Term Loans.  As of December 31, 2014, the Minimum Threshold was $5.0 million.  If we raise $10.0 million in new capital by June 30, 2015, the Minimum Threshold will be reduced to the lesser of $2.0 million or the aggregate outstanding principal balance of the Term Loans.  The events of default under the Term Loans include, but are not limited to, failure to pay amounts due, breaches of covenants, bankruptcy events, cross defaults under other material indebtedness and the occurrence of a material adverse effect and/or change in control. In the case of a continuing event of default, the lender may, among other remedies, declare due all unpaid principal amounts outstanding and any accrued but unpaid interest and foreclose on all collateral granted to the lender as security under the Term Loans.

[0001564590-15-000491:mdna:86]
We believe we are in and expect to remain in compliance with the covenants and restrictions under the Term Loans as of the date of this Quarterly Report on Form 10-Q. If we fail to stay in compliance with our covenants or experience some other event of default, we may be forced to repay the outstanding principal of the Term Loans.

[0001564590-15-000491:mdna:87]
On November 15, 2013, we entered into an ATM arrangement, pursuant to which, we were able to, at our discretion, sell up to $30.0 million of our common stock through our sales agent, MLV & Co. LLC (“MLV”).  Sales of common stock made under the ATM were made on the Nasdaq Global Select Market under our previously filed and currently effective Registration Statement on Form S-3 (File No. 333-191153) by means of ordinary brokers’ transactions at market prices. Additionally, under the terms of the ATM, we were also able to sell shares of our common stock through MLV, on the Nasdaq Global Select Market or otherwise, at negotiated prices or at prices related to the prevailing market price. Under the terms of the ATM, MLV could not engage in any proprietary trading or trading as principal for MLV’s own account. MLV used its commercially reasonable efforts to sell our common stock from time to time, based upon the our instructions (including any price, time or size limits or other customary parameters or conditions we may impose). We paid MLV a commission of up to 3% of the gross proceeds from the sale of shares of our common stock under the ATM. We also agreed to provide MLV with customary indemnification rights. During the three months ended December 31, 2014, we received net proceeds of $1.0 million, including sales commissions and offering expenses, from sales of approximately 0.8 million shares of our common stock at an average sales price of approximately $1.22 per share under the ATM.  We terminated the ATM arrangement on November 5, 2014.  During the term of the arrangement, we received aggregate net proceeds of approximately $13.5 million from the sale of approximately 8.6 million shares of our common stock.

[0001564590-15-000491:mdna:88]
On November 13, 2014, we completed an equity offering to a new investor, under which we sold 9.1 million units of our common stock at $1.10 per share.  Each unit consisted of one share of common stock and 0.9 of a warrant to purchase one share of common stock, or a warrant to purchase in the aggregate 8.2 million shares of common stock.  After commissions and expenses, we received net proceeds from the offering of approximately $9.1 million.

[0001564590-15-000491:mdna:89]
As a result of the financings completed during the three months ended December 31, 2014, we believe we have sufficient available liquidity to fund our operations, including the arbitration award liability, capital expenditures and scheduled cash payments under our debt obligations through December 31, 2015. Our liquidity is highly dependent on our ability to increase revenues, our ability to control our operating costs, our ability to maintain compliance with the covenants and restrictions on our debt obligations (or obtain waivers from our lender in the event of non-compliance), and our ability to raise additional capital, if necessary. There can be no assurance that we will be able to continue to raise additional capital from other sources or execute on any other means of improving our liquidity as described above.

[0001564590-15-000491:mdna:90]
[same as prior period, unchanged from 0001564590-14-005096:mdna:84]

[0001564590-15-000491:mdna:91]
Legal Proceedings

[0001564590-15-000491:mdna:92]
We are involved in legal and administrative proceedings and claims of various types. See Part II, Item 1, “Legal Proceedings,” for additional information. We record a liability in our consolidated financial statements for these matters when a loss is known or considered probable and the amount can be reasonably estimated. We review these estimates each accounting period as additional information is known and adjust the loss provision when appropriate. If a matter is both probable to result in liability and the amounts of loss can be reasonably estimated, we estimate and disclose the possible loss or range of loss. If the loss is not probable or cannot be reasonably estimated, a liability is not recorded in our consolidated financial statements.

[0001564590-15-000491:mdna:93]
[same as prior period, unchanged from 0001564590-14-005096:mdna:87]

[0001564590-15-000491:mdna:94]
[same as prior period, unchanged from 0001564590-14-005096:mdna:88]

[0001564590-15-000491:mdna:95]
[same as prior period, unchanged from 0001564590-14-005096:mdna:89]

[0001564590-15-000491:mdna:96]
[same as prior period, unchanged from 0001564590-14-005096:mdna:90]

[0001564590-15-000491:mdna:97]
[same as prior period, unchanged from 0001564590-14-005096:mdna:91]

[0001564590-15-000491:mdna:98]
In May 2014, the FASB and the International Accounting Standards Board (IASB) issued, ASU Revenue from Contracts with Customers 2014-09 (Topic 606). The guidance substantially converges final standards on revenue recognition between the FASB and IASB providing a framework on addressing revenue recognition issues and, upon its effective date, replaces almost all existing revenue recognition guidance, including industry-specific guidance, in current U.S. generally accepted accounting principles.  The ASU is effective for annual reporting periods beginning after December 15, 2016.  We are currently evaluating the impact of adopting ASU 2014-09 to determine the impact, if any, it may have on our current practices.

[0001564590-15-000491:mdna:99]
In July 2014, the FASB issued ASU 2014-12, Compensation – Stock Compensation (Topic 718): Accounting for Share Based Payments When the Terms of an Award Provide that a Performance Target Could be Achieved after the Requisite Service Period.    To account for such awards, a reporting entity should apply existing guidance in FASB Accounting Standards Codification Topic 718, Compensation – Stock Compensation, as it relates to awards with performance conditions that affect vesting.  As such, the performance target should not be reflected in estimating the grant-date fair value of the award. This ASU is effective for annual reporting periods and interim periods, within those annual periods beginning after December 15, 2015.  We are currently evaluating the impact of adopting ASU 2014-12 to determine the impact, if any, it may have on our current practices.

[0001564590-15-000491:mdna:100]
In August 2014, the FASB issued ASU 2014-13, Consolidation (Topic 810): Measuring the Financial Assets and Financial Liabilities of a Consolidated Collateralized Financing Entity.  The new standard applies to reporting entities that are required to consolidate a collateralized financing entity under the variable interest entities subsection of subtopic 810-10.  This ASU is effective for annual reporting periods ending after December 15, 2016, and interim periods within annual periods beginning after December 15, 2016.  We are currently evaluating the impact of adopting ASU 2014-13, but currently do not believe there will be an impact on our consolidated results of operations, financial condition, or cash flow.

[0001564590-15-000491:mdna:101]
In August 2014, the FASB issued ASU 2014-15, Presentation of Financial Statements – Going Concern (Subtopic 205-40): Disclosure of Uncertainties About an Entity’s Ability to Continue as a Going Concern.  The new standard explicitly requires the assessment at interim and annual periods, and provides management with its own disclosure guidance. This ASU is effective for annual reporting periods and interim periods, within those annual periods ending after December 15, 2016.  We are currently evaluating the impact of ASU 2014-15, if any, may have on our current practices.

[0001564590-15-000491:mdna:102]
In January 2015, the FASB issued ASU 2015-01 Income Statement—Extraordinary and Unusual Items (Subtopic 225-20): Simplifying Income Statement Presentation by Eliminating the Concept of Extraordinary Items.  The amendments in ASU 2015-01 eliminate from US GAAP the concept of extraordinary items.  Subtopic 225-20, income Statement – Extraordinary and Unusual items, required that an entity separately classify, present, and disclose extraordinary events and transactions. This ASU is effective for annual reporting periods and interim periods, within those annual periods beginning after December 15, 2015.  We are currently evaluating the impact of adopting ASU 2015-01 to determine the impact, but currently do not believe there will be an impact on our consolidated results of operations, financial condition, or cash flow.

[0001564590-15-000491:mdna:103]
39
