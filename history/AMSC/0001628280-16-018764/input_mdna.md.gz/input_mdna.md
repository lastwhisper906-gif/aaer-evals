# AMSC MD&A — 0001628280-16-018764


## mdna

[0001628280-16-018764:mdna:1]
[same as prior period, unchanged from 0001564590-16-012481:mdna:1]

[0001628280-16-018764:mdna:2]
depends on our ability to license such patents or other proprietary rights; Our technology and products could infringe intellectual property rights of others, which may require costly litigation and, if we are not successful, could cause us to pay substantial damages and disrupt our business; We have filed a demand for arbitration and other lawsuits against our former largest customer, Sinovel, regarding amounts we contend are overdue. We cannot be certain as to the outcome of these proceedings; We have been named as a party in various legal proceedings, and we may be named in additional litigation, all of which will require significant management time and attention, result in significant legal expenses and may result in an unfavorable outcome, which could have a material adverse effect on our business, operating results and financial condition; and our common stock has experienced, and may continue to experience, significant market price and volume fluctuations, which may prevent our stockholders from selling our common stock at a profit and could lead to costly litigation against us that could divert our management’s attention.  These and the important factors discussed under the caption “Risk Factors” in Part 1. Item 1A of our Form 10-K for the fiscal year ended March 31, 2016, among others, could cause actual results to differ materially from those indicated by forward-looking statements made herein and presented elsewhere by management from time to time. Any such forward-looking statements represent management’s estimates as of the date of this Quarterly Report on Form 10-Q. While we may elect to update such forward-looking statements at some point in the future, we disclaim any obligation to do so, even if subsequent events cause our views to change. These forward-looking statements should not be relied upon as representing our views as of any date subsequent to the date of this Quarterly Report on Form 10-Q.

[0001628280-16-018764:mdna:3]
American Superconductor®, Amperium®, AMSC®, D-VAR®, PowerModule™, PQ-IVR®, SeaTitan™, Gridtec Solutions™, Windtec Solutions™ and Smarter, Cleaner... Better Energy™ are trademarks or registered trademarks of American Superconductor Corporation or our subsidiaries. We reserve all of our rights with respect to our trademarks or registered trademarks regardless of whether they are so designated in this Quarterly Report on Form 10-Q by an ® or ™ symbol. All other brand names, product names, trademarks or service marks appearing in this Quarterly Report on Form 10-Q are the property of their respective holders.

[0001628280-16-018764:mdna:4]
[same as prior period, unchanged from 0001564590-16-012481:mdna:4]

[0001628280-16-018764:mdna:5]
We are a leading provider of megawatt-scale solutions that lower the cost of wind power and enhance the performance of the power grid. In the wind power market, we enable manufacturers to field highly competitive wind turbines through our advanced power electronics products, engineering, and support services. In the power grid market, we enable electric utilities and renewable energy project developers to connect, transmit and distribute power through our transmission planning services and power electronics and superconductor-based products. Our wind and power grid products and services provide exceptional reliability, security, efficiency and affordability to our customers.

[0001628280-16-018764:mdna:6]
[same as prior period, unchanged from 0001564590-16-012481:mdna:6]

[0001628280-16-018764:mdna:7]
[same as prior period, unchanged from 0001564590-16-012481:mdna:7]

[0001628280-16-018764:mdna:8]
[same as prior period, unchanged from 0001564590-16-012481:mdna:8]

[0001628280-16-018764:mdna:9]
| • | Wind. Through our Windtec Solutions™, our Wind business segment enables manufacturers to field wind turbines with exceptional power output, reliability and affordability. We supply advanced power electronics and control systems, license our highly engineered wind turbine designs, and provide extensive customer support services to wind turbine manufacturers. Our design portfolio includes a broad range of drive trains and power ratings of 2 megawatts (“MW”) and higher. We provide a broad range of power electronics and software-based control systems that are highly integrated and designed for optimized performance, efficiency, and grid compatibility. |

[0001628280-16-018764:mdna:10]
| • | Grid. Through our Gridtec Solutions™, our Grid business segment enables electric utilities and renewable energy project developers to connect, transmit and distribute power with exceptional efficiency, reliability, security and affordability. We provide transmission planning services that allow us to identify power grid congestion, poor power quality, and other risks, which help us determine how our solutions can improve network performance. |

[0001628280-16-018764:mdna:11]
These services often lead to sales of our grid interconnection solutions for wind farms and solar power plants, power quality systems and transmission and distribution cable systems.  We also sell ship protection products to the U.S. Navy through our Grid business segment.

[0001628280-16-018764:mdna:12]
Our fiscal year begins on April 1 and ends on March 31. When we refer to a particular fiscal year, we are referring to the fiscal year beginning on April 1 of that same year. For example, fiscal 2016 refers to the fiscal year beginning on April 1, 2016. Other fiscal years follow similarly.

[0001628280-16-018764:mdna:13]
We have experienced recurring operating losses and as of June 30, 2016, had an accumulated deficit of $938.5 million. In addition, we have experienced recurring negative operating cash flows.  At June 30, 2016, we had cash and cash equivalents of $35.2 million. Cash used in operations for the three months ended June 30, 2016 was $2.1 million.

[0001628280-16-018764:mdna:14]
Over the last several years, we have entered into several debt and equity financing arrangements in order to enhance liquidity.  Since April 1, 2012, we generated aggregate cash flows from financing activities of $69.5 million.  This amount includes proceeds from our April 2015 equity offering, which generated net proceeds of approximately $22.3 million, after deducting underwriting discounts and commissions and estimated offering expenses.  See Note 9, “Debt”, and Note 11 “Stockholders Equity” for further discussion of these financing arrangements. We believe that we are in compliance with the covenants and restrictions included in the agreements governing our debt arrangements as of June 30, 2016.

[0001628280-16-018764:mdna:15]
In March 2016, we entered into a set of agreements to jointly develop an advanced low cost manufacturing process for second generation high temperature superconductor wire with BASF Corporation (“BASF“). Under the joint development agreement, our manufacturing know-how for our Amperium® superconductor wire and BASF's chemical solution deposition production technology will be combined. As part of the agreements, we also entered into a royalty-bearing, non-exclusive license under which we agreed to provide BASF a specified portion of our second generation (2G) high temperature superconductor (HTS) wire manufacturing technology.

[0001628280-16-018764:mdna:16]
Our cash requirements depend on numerous factors, including the successful completion of our product development activities, our ability to commercialize our Resilient Electric Grid (“REG“) and ship protection system solutions, rate of customer and market adoption of our products, collecting receivables according to established terms, and the continued availability of U.S. government funding during the product development phase of our Superconductors based products. In December 2015, we entered into a set of strategic agreements valued at approximately $210.0 million with Inox Wind Limited (“Inox“), which includes a multi-year supply contract pursuant to which we will supply electric control systems to Inox and a license agreement allowing Inox to manufacture a limited number of electrical control systems over the next three to four years.  After this initial three to four year period, Inox agreed that we will continue as Inox’s preferred supplier and Inox will be required to purchase from us a majority of its electric control systems requirements for an additional three-year period.  These agreements are expected to provide a foundation for the business as we pursue our longer-term objectives.  As of the date of this Quarterly Report on Form 10-Q, Inox has made all of the pre-payments necessary to allow us to begin shipping electrical control systems under the supply contract, which triggers the effectiveness of both contracts. Significant deviations to our business plan with regard to these factors and events, including any prolonged disruption in our revenues with our largest customers, which are important drivers to our business, could have a material adverse effect on our operating performance, financial condition, and future business prospects. We expect to pursue the expansion of our operations through internal growth, diversification of our customer base, and potential strategic alliances. See “Liquidity and Capital Resources” below for additional discussion.

[0001628280-16-018764:mdna:17]
On March 11, 2016, we sold 100% of our minority investment in Tres Amigas to an investor for $0.6 million. We received $0.3 million according to the terms of the purchase agreement upon closing, which was recorded as a gain during the three months ended March 31, 2016.  The final $0.3 million is to be paid when Tres Amigas achieves the earlier of certain agreed-upon financing conditions which is expected to occur during the third quarter of fiscal 2016. See Note 13, “Minority Investments”, for further information about such investment.

[0001628280-16-018764:mdna:18]
[same as prior period, unchanged from 0001564590-16-012481:mdna:20]

[0001628280-16-018764:mdna:19]
The preparation of the unaudited condensed consolidated financial statements requires that we make estimates and judgments that affect the reported amounts of assets, liabilities, revenues and expenses, and related disclosure of contingent assets and liabilities. We base our estimates on historical experience and various other assumptions that are believed to be reasonable under the circumstances, the results of which form the basis for making judgments about the carrying values of assets and liabilities that are not readily apparent from other sources. Actual results may differ under different assumptions or conditions. There were no significant changes in the critical accounting policies during the three months ended June 30, 2016 that were disclosed in our Form 10-K for fiscal 2015, which ended on March 31, 2016.

[0001628280-16-018764:mdna:20]
[same as prior period, unchanged from 0001564590-16-012481:mdna:22]

[0001628280-16-018764:mdna:21]
Three months ended June 30, 2016 compared to the three months ended June 30, 2015

[0001628280-16-018764:mdna:22]
[same as prior period, unchanged from 0001564590-16-012481:mdna:24]

[0001628280-16-018764:mdna:23]
Total revenues decreased 44% to $13.3 million for the three months ended June 30, 2016, compared to $23.7 million for the three months ended June 30, 2015.  Our revenues are summarized as follows (in thousands):

[0001628280-16-018764:mdna:24]
|  | Three months ended June 30, |
|  | 2016 |  | 2015 |
| Revenues: |  |  |  |  |
| Wind | $ | 5,675 |  |  | $ | 18,164 |  |
| Grid | 7,670 |  |  | 5,559 |  |
| Total | $ | 13,345 |  |  | $ | 23,723 |  |

[0001628280-16-018764:mdna:25]
Our Wind business unit accounted for 43% of total revenues for the three months ended June 30, 2016, compared to 77% for the three months ended June 30, 2015.  Revenues in the Wind business unit decreased 69% to $5.7 million in the three months ended June 30, 2016, from $18.2 million in the three months ended June 30, 2015. Wind business unit revenues decreased primarily due to lower volume of sales to Inox in India.

[0001628280-16-018764:mdna:26]
Our Grid business unit accounted for 57% of total revenues for the three months ended June 30, 2016, compared to 23% for the three months ended June 30, 2015. Our Grid business unit revenues increased 38% to $7.7 million in the three months ended June 30, 2016, from $5.6 million in the three months ended June 30, 2015. Grid business unit revenues increased primarily due to higher D-VAR system revenues, revenues from the BASF contract and higher revenues from a project with the U.S. Navy.

[0001628280-16-018764:mdna:27]
Revenues from Project HYDRA and Project REG represented 13% and 11% of our Grid business unit’s revenue for the three months ended June 30, 2016 and 2015, respectively. Our revenues for these projects are derived by funding from the Department of Homeland Security (“DHS”).  Project HYDRA is a project with Consolidated Edison, Inc. (“ConEd”) to demonstrate our REG product in ConEd’s electric grid.  Project REG is a project with Commonwealth Edison, Inc. (“ComEd”) to permanently install our REG product in ComEd’s electric grid.  This fault current limiting cable system is designed to utilize customized Amperium® HTS wire, and ancillary controls to deliver more power through the grid while also being able to suppress power surges that can disrupt service. DHS has committed 100% of the total expected funding of $29.0 million for Project HYDRA.  Under Project REG, DHS is expected to invest up to $60.0 million to enable the deployment of the REG system in Chicago’s electric grid.  We have substantially completed the first phase of the project which among other things, has resulted in the creation of a detailed deployment plan.  In the fiscal year ended March 31, 2015, DHS committed funding of $1.5 million for this phase of the project.  During the fiscal year ended March 31, 2016, DHS committed funding of an additional $3.7 million, for a total of $5.2 million.  This additional funding serves as a bridge between the detailed deployment plan and construction phases of the project.  The period of performance to complete the engineering work extends through May 31, 2017.  The final phase of the project involves the delivery of the REG system and the associated construction and deployment of the system in ComEd’s grid.  We will not begin this phase of the project until all parties agree to proceed.  There can be no assurance that all parties will agree to proceed with the project.

[0001628280-16-018764:mdna:28]
The following table sets forth customers who represented 10% or more of our total revenues for the three months ended June 30, 2016 and 2015:

[0001628280-16-018764:mdna:29]
|  | Three months ended June 30, |
|  | 2016 |  | 2015 |
| INOX Wind Limited | 27 | % |  | 47 | % |
| Reed & Reed Inc. | 17 | % |  | — | % |
| Essential Energy | 13 | % |  | — | % |
| XJ Group Corporation | 12 | % |  | — | % |
| Beijing JINGCHECG New Energy Co., Ltd | — | % |  | 25 | % |
| M.A. Mortenson Company | — | % |  | 11 | % |

[0001628280-16-018764:mdna:30]
[same as prior period, unchanged from 0001564590-16-012481:mdna:32]

[0001628280-16-018764:mdna:31]
Cost of revenues decreased by 39% to $12.5 million for the three months ended June 30, 2016, compared to $20.5 million for the three months ended June 30, 2015. Gross margin was 6.5% for the three months ended June 30, 2016, compared to 13.6% for the three months ended June 30, 2015. The decrease in gross margin was primarily due to lower wind revenues in the three months ended June 30, 2016, and higher royalty revenue, which contributed 100% gross margin, in the three months ended June 30, 2015.

[0001628280-16-018764:mdna:32]
[same as prior period, unchanged from 0001564590-16-012481:mdna:34]

[0001628280-16-018764:mdna:33]
[same as prior period, unchanged from 0001564590-16-012481:mdna:35]

[0001628280-16-018764:mdna:34]
R&D expenses decreased by 7% to $3.0 million for the three months ended June 30, 2016, from $3.2 million for the three months ended June 30, 2015.  The decrease is primarily the result of lower stock compensation expense partially offset by new product development expenses in our Grid segment.

[0001628280-16-018764:mdna:35]
[same as prior period, unchanged from 0001564590-16-012481:mdna:37]

[0001628280-16-018764:mdna:36]
SG&A expenses decreased by 4% to $7.2 million in the three months ended June 30, 2016, from $7.5 million in the three months ended June 30, 2015. The decrease in SG&A expenses was due primarily to reductions in stock compensation and legal costs.

[0001628280-16-018764:mdna:37]
Impairment of minority interest investment

[0001628280-16-018764:mdna:38]
We recorded an impairment charge of $0.7 million in the three months ended June 30, 2015, to fully impair our investment in Tres Amigas as our investment was no longer deemed recoverable.

[0001628280-16-018764:mdna:39]
[same as prior period, unchanged from 0001564590-16-012481:mdna:41]

[0001628280-16-018764:mdna:40]
We recorded amortization expense related to our core technology and know-how, trade names and trademark intangible assets of less than $0.1 million in each of the three months ended June 30, 2016 and 2015.

[0001628280-16-018764:mdna:41]
[same as prior period, unchanged from 0001564590-16-012481:mdna:45]

[0001628280-16-018764:mdna:42]
[same as prior period, unchanged from 0001564590-16-012481:mdna:46]

[0001628280-16-018764:mdna:43]
|  | Three months ended June 30, |
|  | 2016 |  | 2015 |
| Operating (loss) profit: |  |  |  |
| Wind | $ | (3,030 | ) |  | $ | 127 |  |
| Grid | (5,315 | ) |  | (6,508 | ) |
| Unallocated corporate expenses | (999 | ) |  | (1,876 | ) |
| Total | $ | (9,344 | ) |  | $ | (8,257 | ) |

[0001628280-16-018764:mdna:44]
Our Wind segment generated an operating loss of $3.0 million in the three months ended June 30, 2016, compared to an operating profit of $0.1 million in the three months ended June 30, 2015. The increase in the Wind business unit operating loss was due primarily to the lower shipments to Inox as previously discussed.

[0001628280-16-018764:mdna:45]
The operating loss in our Grid segment decreased to $5.3 million in the three months ended June 30, 2016, compared to $6.5 million in the three months ended June 30, 2015. The decrease in the Grid business unit operating loss during the three months ended June 30, 2016 was driven primarily by increased revenues in the current year period.

[0001628280-16-018764:mdna:46]
Unallocated corporate expenses primarily include stock-based compensation expense of $1.0 million and $1.1 million for the three months ended June 30, 2016 and 2015, respectively, and an impairment charge of $0.7 million, for the three months ended June 30, 2015.

[0001628280-16-018764:mdna:47]
25

[0001628280-16-018764:mdna:48]
[same as prior period, unchanged from 0001564590-16-012481:mdna:51]

[0001628280-16-018764:mdna:49]
The change in fair value of derivatives and warrants resulted in a loss of $0.7 million in the three months ended June 30, 2016, compared to a gain of $0.8 million in the three months ended June 30, 2015.  The changes in the fair value were primarily driven by changes in stock price, which is a key valuation metric.

[0001628280-16-018764:mdna:50]
[same as prior period, unchanged from 0001564590-16-012481:mdna:55]

[0001628280-16-018764:mdna:51]
Interest expense, net, was $0.1 million in the three months ended June 30, 2016, compared to $0.3 million in the three months ended June 30, 2015. The interest expense is related to the remaining balances on our Term Loan B and Term Loan C with Hercules Technology Growth Capital, Inc. ("Hercules") which will mature in November 2016 and June 2017, respectively.

[0001628280-16-018764:mdna:52]
Other income (expense), net

[0001628280-16-018764:mdna:53]
Other income, net, was other income, net of $0.1 million in the three months ended June 30, 2016, compared to other expense, net of $0.8 million in the three months ended June 30, 2015.  The increase in other income, net during the three months ended June 30, 2016, was primarily driven by lower foreign currency losses.

[0001628280-16-018764:mdna:54]
[same as prior period, unchanged from 0001564590-16-012481:mdna:59]

[0001628280-16-018764:mdna:55]
Income tax expense was $0.3 million in the three months ended June 30, 2016, compared to $0.6 million in the three months ended June 30, 2015. The decrease in income tax expense was primarily due to lower taxes in our foreign jurisdictions.

[0001628280-16-018764:mdna:56]
[same as prior period, unchanged from 0001564590-16-012481:mdna:61]

[0001628280-16-018764:mdna:57]
[same as prior period, unchanged from 0001564590-16-012481:mdna:62]

[0001628280-16-018764:mdna:58]
We define non-GAAP net loss as net loss before stock-based compensation, amortization of acquisition-related intangibles, restructuring and impairment charges, consumption of zero cost-basis inventory, changes in fair value of derivatives and warrants, non-cash interest expense, and the other non-cash or unusual charges, net of any tax effects related to these items, indicated in the table below. We believe non-GAAP net loss assists management and investors in comparing our performance across reporting periods on a consistent basis by excluding these non-cash or non-recurring charges that we do not believe are indicative of our core operating performance. We also regard non-GAAP net loss as a useful measure of operating performance which more closely aligns net loss with cash used in/provided by continuing operations. In addition, we use non-GAAP net loss as a factor in evaluating management’s performance when determining incentive compensation and to evaluate the effectiveness of our business strategies. A reconciliation of non-GAAP to GAAP net loss is set forth in the table below (in thousands, except per share data):

[0001628280-16-018764:mdna:59]
|  | Three months ended June 30, |
|  | 2016 |  | 2015 |
| Net loss | $ | (10,355 | ) |  | $ | (9,121 | ) |
| Stock-based compensation | 999 |  |  | 1,128 |  |
| Amortization of acquisition-related intangibles | 39 |  |  | 39 |  |
| Impairment of minority interest investment | — |  |  | 741 |  |
| Consumption of zero cost-basis inventory | (158 | ) |  | (846 | ) |
| Change in fair value of derivatives and warrants | 678 |  |  | (800 | ) |
| Non-cash interest expense | 56 |  |  | 111 |  |
| Tax effect of adjustments | 25 |  |  | — |  |
| Non-GAAP net loss | $ | (8,716 | ) |  | $ | (8,748 | ) |
| Non-GAAP loss per share | $ | (0.64 | ) |  | $ | (0.72 | ) |
| Weighted average shares outstanding - basic and diluted | 13,676 |  |  | 12,111 |  |

[0001628280-16-018764:mdna:60]
We incurred a non-GAAP net loss of $8.7 million or $0.64 per share, for the three months ended June 30, 2016, compared to a non-GAAP net loss of $8.7 million or $0.72 per share, for the three months ended June 30, 2015. The slight decrease in non-GAAP net loss was driven primarily by an increase in net loss driven in part by changes in the fair value of derivatives, and moderated by lower usage of zero cost inventory in the three months ended June 30, 2016.

[0001628280-16-018764:mdna:61]
[same as prior period, unchanged from 0001564590-16-012481:mdna:66]

[0001628280-16-018764:mdna:62]
At June 30, 2016, we had cash, cash equivalents, and restricted cash of $36.6 million, compared to $40.7 million at March 31, 2016, a decrease of $4.1 million. Our cash and cash equivalents, and restricted cash are summarized as follows (in thousands):

[0001628280-16-018764:mdna:63]
|  | June 30,2016 |  | March 31,2016 |
| Cash and cash equivalents | $ | 35,211 |  |  | $ | 39,330 |  |
| Restricted cash | 1,375 |  |  | 1,391 |  |
| Total cash, cash equivalents, and restricted cash | $ | 36,586 |  |  | $ | 40,721 |  |

[0001628280-16-018764:mdna:64]
As of June 30, 2016, we had approximately $15.3 million of cash, cash equivalents, and restricted cash in foreign bank accounts, with a majority of this cash located in Europe.  The decrease in total cash and cash equivalents, and restricted cash was due primarily to cash used by operating and by financing activities. See further discussion below.

[0001628280-16-018764:mdna:65]
For the three months ended June 30, 2016, net cash used in operating activities was $2.1 million compared to $3.0 million for the three months ended June 30, 2015. The decrease in net cash used in operations was due primarily to an increase in cash from changes in operating asset and liability accounts.

[0001628280-16-018764:mdna:66]
For the three months ended June 30, 2016, net cash used in investing activities was $0.3 million, compared to $0.1 million for the three months ended June 30, 2015. The increase in net cash used in investing activities was due primarily to changes in other assets and increased purchases of property, plant and equipment.

[0001628280-16-018764:mdna:67]
For the three months ended June 30, 2016, net cash used in financing activities was $1.5 million compared to net cash provided by financing activities of $21.2 million in the three months ended June 30, 2015. The increase in net cash used in financing activities was primarily due to net proceeds of $22.3 million from the issuance of 4.0 million shares of common stock on April 29, 2015, with no such capital raise in the current year period.

[0001628280-16-018764:mdna:68]
At June 30, 2016, we had $0.4 million of restricted cash included in current assets and $0.9 million of restricted cash included in long-term assets. These amounts included in restricted cash primarily represent deposits to secure letters of credit for various supply contracts and customs authorities. These deposits are held in interest bearing accounts.

[0001628280-16-018764:mdna:69]
On November 15, 2013, we amended our Loan and Security Agreement with Hercules and entered into a new term loan (the “Term Loan B”), borrowing $10.0 million. After closing fees and expenses, we received net proceeds of $9.8 million. The Term Loan B bears an interest rate equal to 11% plus the percentage, if any, in which the prime rate as reported by The Wall Street Journal exceeds 3.75%. We made interest-only payments from December 1, 2013 to May 31, 2014. If we achieved certain revenue targets for the six-month period ending March 31, 2014, interest only payments would continue through August 31, 2014. We did not achieve the revenue required to extend this interest only period.  Beginning June 1, 2014, we began making payments on the Term Loan B in equal monthly installments which will end on November 1, 2016.

[0001628280-16-018764:mdna:70]
On December 19, 2014, we entered into a second amendment with Hercules (the “Hercules Second Amendment”) and entered into a new term loan (the “Term Loan C”), borrowing an additional $1.5 million (we collectively refer to the Term Loan B and Term Loan C as the “Term Loans”).  After closing fees and expenses, the net proceeds from the Term Loan C were $1.4 million.  The Term Loan C bears the same interest rate as the Term Loan B.  We are making interest only payments until maturity on June 1, 2017, when the loan is scheduled to be repaid in its entirety.

[0001628280-16-018764:mdna:71]
27

[0001628280-16-018764:mdna:72]
The Term Loans are secured by substantially all of our existing and future assets, including a mortgage on real property owned by our wholly-owned subsidiary, ASC Devens LLC, and located at 64 Jackson Road, Devens, Massachusetts.  The Term Loans contain certain covenants that restrict our ability to, among other things, incur or assume certain debt, merge or consolidate, materially change the nature of our business, make certain investments, acquire or dispose of certain assets, make guarantees or grant liens on our assets, make certain loans, advances or investments, declare dividends or make distributions or enter into transactions with affiliates. In addition, there is a covenant that requires us to maintain a minimum unrestricted cash balance (the “Minimum Threshold”) in the United States.  As a result of the April 2015 offering (see discussion below), the Minimum Threshold was reduced to the lesser of $2.0 million or the aggregate outstanding principal balance of the Term Loans.  As of June 30, 2016, the Minimum Threshold was $2.0 million.  The events of default under the Term Loans include, but are not limited to, failure to pay amounts due, breaches of covenants, bankruptcy events, cross defaults under other material indebtedness and the occurrence of a material adverse effect and/or change in control. In the case of a continuing event of default, Hercules may, among other remedies, declare due all unpaid principal amounts outstanding and any accrued but unpaid interest and foreclose on all collateral granted to Hercules as security under the Term Loans.

[0001628280-16-018764:mdna:73]
We believe we are in and expect to remain in compliance with the covenants and restrictions under the Term Loans as of the date of this Quarterly Report on Form 10-Q. If we fail to stay in compliance with our covenants or experience some other event of default, we may be forced to repay the outstanding principal on the Term Loans.

[0001628280-16-018764:mdna:74]
We have experienced recurring operating losses and as of June 30, 2016, had an accumulated deficit of $938.5 million. In addition, we have experienced recurring negative operating cash flows. At June 30, 2016, we had cash and cash equivalents of $35.2 million, as compared to cash used in operations of $2.1 million for the three months ended June 30, 2016. In April 2015, we completed an equity offering which raised net proceeds of $22.3 million after deducting underwriting discounts and commissions and estimated offering expenses payable by us from the sale of 4.0 million shares of our common stock at a public offering price of $6.00 per share. On March 11, 2016, we sold 100% of our minority investment in Tres Amigas to an investor for $0.6 million. We received $0.3 million according to the terms of the purchase agreement upon closing, which was recorded as a gain during the three months ended March 31, 2016.  The final $0.3 million is to be paid when Tres Amigas achieves the earlier of certain agreed-upon financing conditions which is expected to occur during the third quarter of fiscal 2016.  In addition, in December 2015, we entered into a set of strategic agreements valued at approximately $210.0 million with Inox, as discussed above.  These agreements are expected to provide a foundation for the business as we pursue our longer-term objectives.

[0001628280-16-018764:mdna:75]
We believe we have sufficient available liquidity to fund our operations, capital expenditures and scheduled cash payments under our debt obligations for the next twelve months. Our liquidity is highly dependent on our ability to increase revenues, control our operating costs, and our ability to maintain compliance with the covenants and restrictions on our debt obligations (or obtain waivers from our lender in the event of non-compliance), and our ability to raise additional capital, if necessary.  There can be no assurance that we will be able to continue to raise additional capital from other sources or execute on any other means of improving our liquidity as described above.

[0001628280-16-018764:mdna:76]
Legal Proceedings

[0001628280-16-018764:mdna:77]
We are involved in legal and administrative proceedings and claims of various types. See Part II, Item 1, “Legal Proceedings,” for additional information. We record a liability in our consolidated financial statements for these matters when a loss is known or considered probable and the amount can be reasonably estimated. We review these estimates each accounting period as additional information is known and adjust the loss provision when appropriate. If a matter is both probable to result in liability and the amounts of loss can be reasonably estimated, we estimate and disclose the possible loss or range of loss to the extent necessary to make the consolidated financial statements not misleading. If the loss is not probable or cannot be reasonably estimated, a liability is not recorded in our consolidated financial statements.

[0001628280-16-018764:mdna:78]
[same as prior period, unchanged from 0001564590-16-012481:mdna:82]

[0001628280-16-018764:mdna:79]
[same as prior period, unchanged from 0001564590-16-012481:mdna:83]

[0001628280-16-018764:mdna:80]
[same as prior period, unchanged from 0001564590-16-012481:mdna:84]

[0001628280-16-018764:mdna:81]
[same as prior period, unchanged from 0001564590-16-012481:mdna:85]

[0001628280-16-018764:mdna:82]
[same as prior period, unchanged from 0001564590-16-012481:mdna:86]

[0001628280-16-018764:mdna:83]
In May 2014, the Financial Accounting Standards Board (“FASB”) and the International Accounting Standards Board (IASB) issued, ASU Revenue from Contracts with Customers 2014-09 (Topic 606). The guidance substantially converges final standards on revenue recognition between the FASB and IASB providing a framework on addressing revenue recognition issues and, upon its effective date, replaces almost all existing revenue recognition guidance, including industry-specific guidance, in current U.S. generally accepted accounting principles.  The ASU is effective for annual reporting periods beginning after December 15, 2017.  We are currently evaluating the impact, if any, the adoption of ASU 2014-09 may have on our current practices.

[0001628280-16-018764:mdna:84]
In July 2014, the FASB issued ASU 2014-12, Compensation - Stock Compensation (Topic 718): Accounting for Share Based Payments When the Terms of an Award Provide that a Performance Target Could be Achieved after the Requisite Service Period.  To account for such awards, a reporting entity should apply existing guidance in FASB Accounting Standards Codification Topic 718, Compensation - Stock Compensation, as it relates to awards with performance conditions that affect vesting.  As such, the performance target should not be reflected in estimating the grant-date fair value of the award. As such, the performance target should not be reflected in estimating the grant-date fair value of the award. We adopted ASU 2014-12 effective April 1, 2016 and conclude that there is no material impact on our current practices.

[0001628280-16-018764:mdna:85]
In August 2014, the FASB issued ASU 2014-15, Presentation of Financial Statements - Going Concern (Subtopic 205-40): Disclosure of Uncertainties About an Entity’s Ability to Continue as a Going Concern.  The new standard explicitly requires the assessment at interim and annual periods, and provides management with its own disclosure guidance. This ASU is effective for annual reporting periods and interim periods, within those annual periods ending after December 15, 2016.  We are currently evaluating the impact, if any, the adoption of ASU 2014-15 may have on our current practices.

[0001628280-16-018764:mdna:86]
In April 2015, the FASB issued ASU 2015-03 Interest-Imputation of Interest (Subtopic 835-30): Simplifying the Presentation of Debt Issuance Costs.  The amendments in ASU 2015-03 require an entity to present debt issuance costs on the balance sheet as a direct deduction from the related debt liability as opposed to an asset. Amortization of the costs will continue to be reported as interest expense. We adopted ASU 2015-03 effective April 1, 2016 and conclude that there is no material impact on our consolidated results of operations, financial condition, or cash flow.

[0001628280-16-018764:mdna:87]
In June 2015, the FASB issued ASU 2015-10 Technical Corrections and Improvements.  The amendments in ASU 2015-10 clarify and correct some of the difference that arose between original guidance from FASB, EITF and other sources, and the translation into the new Codification. We adopted ASU 2015-10 effective April 1, 2016 and conclude that there is no material impact on our consolidated results of operations, financial condition, or cash flow.

[0001628280-16-018764:mdna:88]
In July 2015, the FASB issued ASU 2015-11 Inventory (Topic 330): Simplifying the Measurement of Inventory.  The amendments in ASU 2015-11 clarify the proper way to identify market value in the use of lower of cost or market value valuation method.  As market value could be determined multiple ways under prior standards, it will now be considered as net realizable value. This ASU is effective for annual reporting periods beginning after December 15, 2016, and interim periods within those fiscal years.  We are currently evaluating the impact, if any, the adoption of ASU 2015-11 may have on our current practices.

[0001628280-16-018764:mdna:89]
In September 2015, the FASB issued ASU 2015-16 Business Combinations (Topic 805): Simplifying the Accounting for Measurement-Period Adjustments.  The amendments in ASU 2015-16 require that an acquirer recognize adjustments to provisional amounts identified during the measurement period in the reporting period in which the adjustment amounts are determined. We adopted ASU 2015-16 effective April 1, 2016 and conclude that there is no material impact on our consolidated results of operations, financial condition, or cash flow.

[0001628280-16-018764:mdna:90]
In January 2016, the FASB issued ASU 2016-01 Financial Instruments-Overall (Subtopic 825-10): Recognition and Measurement of Financial Assets and Financial Liabilities.  The amendments in ASU 2016-01 will enhance the reporting model for financial instruments to provide users of financial statements with more decision-useful information. This ASU is effective for annual reporting periods beginning after December 15, 2017, and interim periods within those fiscal years.  We are currently evaluating the impact, if any, the adoption of ASU 2016-01 may have on our current practices.

[0001628280-16-018764:mdna:91]
In February 2016, the FASB issued ASU 2016-02, Leases (Topic 842). The guidance in this ASU supersedes the leasing guidance in Topic 840, Leases. Under the new guidance, lessees are required to recognize lease assets and lease liabilities on the balance sheet for all leases with terms longer than 12 months. Leases will be classified as either finance or operating, with classification affecting the pattern of expense recognition in the income statement. This ASU is effective for fiscal years beginning after December 15, 2019, including interim periods within those fiscal years. A modified retrospective transition approach is required for lessees for capital and operating leases existing at, or entered into after, the beginning of the earliest comparative period presented in the financial statements, with certain practical expedients available. We are currently evaluating the effects adoption of this guidance will have on our consolidated financial statements.

[0001628280-16-018764:mdna:92]
In March 2016, the FASB issued ASU 2016-08 Revenue from Contracts with Customers (Topic 606): Principal versus Agent Considerations (Reporting Revenue Gross versus Net).  The amendments in ASU 2016-08 clarify the implementation guidance on principal versus agent consideration. The ASU is effective for annual reporting periods beginning after December 15, 2017.  We are currently evaluating the impact, if any, the adoption of ASU 2016-08 may have on our current practices.

[0001628280-16-018764:mdna:93]
In March 2016, the FASB issued ASU 2016-09 Compensation-Stock Compensation (Topic 718): Improvements to Employee Share-Based Payment Accounting.  The amendments in ASU 2016-09 will simplify several aspects of the accounting for share-based payment transactions, including tax consequences, classification of awards as either equity or liabilities, and classification on the statement of cash flows. The ASU is effective for annual reporting periods beginning after December 15, 2017, and interim periods within annual periods beginning after December 15, 2018.  We are currently evaluating the impact, if any, the adoption of ASU 2016-09 may have on our current practices.

[0001628280-16-018764:mdna:94]
In April 2016, the FASB issued ASU 2016-10 Revenue from Contracts with Customers (Topic 606): Identifying Performance Obligations and Licensing.  The amendments in ASU 2016-10 will clarify the identification of performance obligations and the licensing implementation guidance. The ASU is effective for annual reporting periods beginning after December 15, 2017.  We are currently evaluating the impact, if any, the adoption of ASU 2016-10 may have on our current practices.

[0001628280-16-018764:mdna:95]
In April 2016, the FASB issued ASU 2016-12 Revenue from Contracts with Customers (Topic 606): Narrow-Scope Improvements and Practical Expedients.  The amendments in ASU 2016-12 will clarify the prior guidance surrounding collectability criteria, presentation of taxes collected, non-cash consideration, contract modifications, completed contracts at completion and retrospective application guidance. The ASU is effective for annual reporting periods beginning after December 15, 2017.  We are currently evaluating the impact, if any, the adoption of ASU 2016-12 may have on our current practices.

[0001628280-16-018764:mdna:96]
In June 2016, the FASB issued ASU 2016-13 Financial Instruments—Credit Losses (Topic 326): Measurement of Credit Losses on Financial Instruments.  The amendments in ASU 2016-13 will provide more decision useful information about the expected credit losses on financial instruments and other commitments to extend credit held by a reporting entity at each reporting date. The ASU is effective for annual reporting periods beginning after December 15, 2019, including interim periods within that year.  We are currently evaluating the impact, if any, the adoption of ASU 2016-13 may have on our current practices.

[0001628280-16-018764:mdna:97]
We do not believe that other recently issued accounting pronouncements will have a material impact on our financial statements.
