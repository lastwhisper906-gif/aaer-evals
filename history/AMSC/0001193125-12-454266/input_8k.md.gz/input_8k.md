# AMSC 8-K — 0001193125-12-453359 filed 2012-11-06

## item codes, every 8-K on or before 2012-11-06

- 2012-11-06 0001193125-12-453359 — 2.02, 9.01
- 2012-08-02 0001193125-12-330534 — 2.02, 9.01
- 2012-07-27 0001193125-12-318790 — 5.02, 5.07, 9.01
- 2012-06-06 0001193125-12-261030 — 1.01, 2.02, 2.03, 3.02, 5.02, 9.01
- 2012-05-09 0001193125-12-222210 — 5.02
- 2012-04-20 0001193125-12-172045 — 8.01
- 2012-04-13 0001193125-12-162694 — 2.02, 8.01, 9.01
- 2012-04-04 0001193125-12-149102 — 1.01, 2.02, 2.03, 3.02, 9.01
- 2012-02-09 0001193125-12-048009 — 2.02, 9.01
- 2012-02-06 0001193125-12-041344 — 5.07 — amendment of 0000950123-11-102495
- 2011-12-08 0000950123-11-102495 — 5.07
- 2011-11-29 0000950123-11-100822 — 2.05
- 2011-11-09 0000950123-11-096775 — 2.02, 9.01
- 2011-10-31 0000950123-11-093390 — 1.02, 9.01
- 2011-10-07 0000950123-11-089221 — 8.01
- 2011-10-03 0000950123-11-088315 — 7.01
- 2011-09-23 0000950123-11-086288 — 2.02, 9.01
- 2011-09-15 0000950123-11-084585 — 7.01
- 2011-09-06 0000950123-11-082736 — 7.01
- 2011-08-18 0000950123-11-078526 — 3.01, 7.01, 9.01
- 2011-08-11 0000950123-11-075905 — 5.02
- 2011-08-11 0000950123-11-075904 — 2.02, 2.05, 9.01
- 2011-07-11 0000950123-11-064934 — 2.02, 4.02, 9.01
- 2011-06-30 0000950123-11-063287 — 1.01, 3.02, 9.01
- 2011-06-21 0000950123-11-060491 — 3.01, 7.01, 9.01
- 2011-06-13 0000950123-11-058656 — 1.01, 9.01
- 2011-05-24 0000950123-11-053517 — 5.02, 9.01
- 2011-04-05 0001299933-11-001020 — 2.02, 9.01
- 2011-03-15 0000950123-11-025580 — 5.02
- 2011-03-14 0000950123-11-025205 — 1.01, 3.02, 9.01
- 2011-02-01 0001299933-11-000333 — 2.02, 9.01
- 2010-11-12 0000950123-10-104604 — 8.01, 9.01
- 2010-11-08 0000950123-10-102424 — 8.01, 9.01
- 2010-11-02 0001299933-10-003878 — 2.02, 9.01
- 2010-09-15 0000950123-10-086373 — 1.01, 9.01 — amendment, the index does not say of what
- 2010-08-06 0000950123-10-074362 — 5.07
- 2010-07-29 0001299933-10-002860 — 2.02, 9.01
- 2010-05-17 0000950123-10-050424 — 1.01, 9.01
- 2010-05-14 0001299933-10-001972 — 5.02
- 2010-05-13 0001299933-10-001943 — 2.02, 9.01
- 2010-02-08 0001299933-10-000506 — 8.01
- 2010-02-02 0001299933-10-000386 — 2.02, 9.01
- 2009-12-15 0001299933-09-004928 — 5.02
- 2009-10-29 0001299933-09-004267 — 2.02, 9.01
- 2009-08-12 0001193125-09-173026 — 5.02, 9.01
- 2009-07-30 0001193125-09-158842 — 1.01, 2.02, 9.01
- 2009-05-15 0001193125-09-113158 — 5.02
- 2009-05-14 0001193125-09-110619 — 2.02, 9.01
- 2009-04-20 0001193125-09-082590 — 5.02
- 2009-02-03 0001193125-09-016992 — 2.02, 9.01
- 2009-01-22 0001193125-09-009777 — 2.02, 9.01
- 2008-11-04 0001193125-08-223730 — 2.02, 9.01
- 2008-08-11 0001193125-08-173616 — 8.01
- 2008-08-07 0001193125-08-170325 — 8.01
- 2008-08-05 0001193125-08-165888 — 2.02, 9.01
- 2008-06-11 0001193125-08-132049 — 1.01, 9.01
- 2008-05-20 0001193125-08-119372 — 5.02, 9.01
- 2008-05-08 0001193125-08-107052 — 2.02, 9.01
- 2008-01-31 0001193125-08-016233 — 2.02, 9.01
- 2008-01-30 0001193125-08-015494 — 5.03, 9.01
- 2007-11-01 0001193125-07-231866 — 2.02, 9.01
- 2007-10-31 0001193125-07-231225 — 2.05
- 2007-10-29 0001193125-07-228284 — 5.03, 9.01
- 2007-09-27 0001193125-07-208950 — 5.02
- 2007-08-09 0001193125-07-176553 — 2.02, 9.01
- 2007-08-07 0001193125-07-173829 — 1.01, 5.02, 9.01
- 2007-07-02 0001193125-07-148303 — 5.02, 9.01
- 2007-06-20 0001193125-07-139068 — 8.01, 9.01
- 2007-06-14 0001193125-07-135550 — 9.01 — amendment of 0001193125-07-005297
- 2007-06-14 0001193125-07-135340 — 5.02
- 2007-05-24 0001193125-07-122148 — 2.02, 9.01
- 2007-03-30 0001193125-07-070154 — 2.05, 9.01
- 2007-03-23 0001193125-07-062978 — 9.01 — amendment of 0001193125-07-005297
- 2007-02-01 0001193125-07-017883 — 2.02, 9.01
- 2007-01-11 0001193125-07-005297 — 2.01, 9.01
- 2006-12-05 0001181431-06-067500 — 5.02
- 2006-11-29 0001193125-06-243360 — 1.01, 3.02, 9.01
- 2006-11-02 0001193125-06-221464 — 2.02, 9.01
- 2006-09-21 0001193125-06-194526 — 5.02
- 2006-08-08 0001193125-06-164819 — 2.02, 9.01
- 2006-08-02 0001193125-06-159113 — 1.01, 9.01
- 2006-07-28 0001193125-06-156172 — 1.01
- 2006-06-26 0001193125-06-135913 — 1.01, 3.03, 9.01
- 2006-05-11 0001193125-06-108489 — 2.02, 9.01
- 2006-05-05 0001193125-06-102270 — 1.01, 9.01
- 2006-05-01 0001193125-06-094941 — 2.02, 2.06, 9.01
- 2006-02-24 0001193125-06-038281 — 5.02, 9.01
- 2006-02-02 0001181431-06-007665 — 2.02, 9.01
- 2005-11-09 0001181431-05-060304 — 2.02, 9.01
- 2005-08-04 0001181431-05-044420 — 2.02, 9.01
- 2005-07-28 0001193125-05-151272 — 5.02, 9.01
- 2005-06-14 0001193125-05-125148 — 5.02, 9.01
- 2005-05-12 0001181431-05-027410 — 2.02, 9.01
- 2005-05-10 0001193125-05-102795 — 1.01
- 2005-04-05 0001181431-05-020680 — 1.01, 2.02, 3.02, 9.01
- 2005-02-03 0001181431-05-006678 — 2.02, 9.01
- 2004-11-09 0001181431-04-051381 — 2.02, 9.01 — amendment, the index does not say of what
- 2004-11-04 0001181431-04-050706 — 2.02, 9.01
- 2004-10-15 0001193125-04-172458 — 1.01, 9.01
- 2004-08-05 0001193125-04-132162 — 12
- 2004-05-13 0001193125-04-086853 — 12
- 2004-02-05 0001193125-04-015060 — 12
- 2003-11-06 0001193125-03-074000 — 12
- 2003-09-26 0001193125-03-054624 — 5
- 2003-08-06 0001193125-03-029666 — 12
- 2003-05-14 0000927016-03-002619 — 9
- 2002-12-31 0000927016-02-006114 — 5
- 2000-01-24 0000927016-00-000150 — 5, 7
- 1998-11-02 0000950135-98-005625 — 5, 7
- 1998-03-24 0000950135-98-001743 — 5, 7
- 1997-09-05 0000950135-97-003729 — 5, 7
- 1997-06-23 0000950135-97-002785 — 1 — amendment of 0000950135-97-001972
- 1997-04-23 0000950135-97-001972 — 2, 7

## late-filing notifications on or before 2012-11-06

- 2011-08-10 0000950123-11-075677 — NT 10-Q, for the period ended 2011-06-30
- 2011-05-31 0000950123-11-055465 — NT 10-K, for the period ended 2011-03-31

## item 2.02 — earnings release, exhibit 99.1

[0001193125-12-453359:8k_2_02:1]
EX-99.1
2
d435435dex991.htm
PRESS RELEASE

[0001193125-12-453359:8k_2_02:2]
Press Release

[0001193125-12-453359:8k_2_02:3]
Exhibit 99.1

[0001193125-12-453359:8k_2_02:4]
AMSC Reports Second Quarter Financial Results

[0001193125-12-453359:8k_2_02:5]
Company to host conference call today at 10 a.m. ET

[0001193125-12-453359:8k_2_02:6]
Devens, MA – November 6, 2012 – AMSC (NASDAQ: AMSC), a global solutions provider serving wind and grid leaders, today reported financial results for its second quarter of fiscal year
2012 ended September 30, 2012.

[0001193125-12-453359:8k_2_02:7]
Revenues for the second quarter of fiscal 2012 were $20.9 million, which compares with $20.8 million for
the second quarter of fiscal 2011. AMSC increased revenues from its Grid business segment by approximately 20 percent while revenues from the company’s Wind segment declined by approximately 10 percent year over year.

[0001193125-12-453359:8k_2_02:8]
For the second quarter of fiscal 2012, AMSC reported a net loss of $15.9 million, or $0.31 per share. This figure includes a $3.3 million non-cash
“mark-to-market” benefit driven by the re-valuation of the derivative liability and warrants associated with the company’s debt financings. For the second quarter of fiscal 2011, AMSC’s net loss was $51.7 million, or $1.02 per
share. This figure included approximately $28.2 million in charges related to the termination of a proposed acquisition, litigation expenses against Sinovel Wind Group Co., Ltd. and corporate restructuring activities and impairments.

[0001193125-12-453359:8k_2_02:9]
The company’s non-GAAP net loss for the second quarter of fiscal 2012 was $15.2 million, or $0.29 per share. This compares with a non-GAAP net loss
of $22.1 million, or $0.44 per share, for the second quarter of fiscal 2011. Please refer to the financial table below for a reconciliation of GAAP to non-GAAP results.

[0001193125-12-453359:8k_2_02:10]
AMSC’s cash, cash equivalents, marketable securities and restricted cash at September 30, 2012 totaled $73.1 million. This compares with $66.2 million as of March 31, 2012. The increase in
cash, cash equivalents, marketable securities and restricted cash was driven by the financings that were completed and announced in the first quarter of fiscal 2012.

[0001193125-12-453359:8k_2_02:11]
“AMSC delivered on its stated financial targets in the second fiscal quarter,” said AMSC President and Chief Executive Officer Daniel P. McGahn. “Our Grid business segment performed well,
capitalizing on stable spending in the Transmission & Distribution market, generating year-over-year growth and nearly filling its order book for fiscal 2012. As has been previously reported, conditions in the wind power market are
currently challenging, with increased government oversight slowing installations in China and global installations flattening. While second-quarter wind turbine electrical control system shipments from our Wind business segment declined year over
year, we are expecting to increase shipments in the second half of the fiscal year based on our existing orders and discussions with our customers.”

[0001193125-12-453359:8k_2_02:12]
| AMSC Reports Q2 Results |  | Page 2 |

[0001193125-12-453359:8k_2_02:13]
Looking Forward

[0001193125-12-453359:8k_2_02:14]
“We expect to improve our top- and bottom-line performance both sequentially and year over year in the third fiscal quarter,” said McGahn. “As we strive to extend our track record of
execution, we will also continue to closely monitor the macro environment, manage our expenses and conserve our cash with the aim to continue improving our financial performance.”

[0001193125-12-453359:8k_2_02:15]
For the third fiscal quarter ending December 31, 2012, AMSC expects that its revenues will exceed $26 million. AMSC expects that its net loss for the quarter will be less than $19 million, or $0.36
per share. This guidance assumes no impact from mark-to-market adjustments related to the derivative liability and warrants. AMSC expects that its non-GAAP (as defined below) net loss for the third quarter of fiscal 2012 will be less than $14
million, or $0.26 per share. AMSC expects to reduce its balance of restricted cash in the third fiscal quarter by paying or settling the majority of its remaining liabilities for adverse purchase commitments, which amounted to approximately $12
million as of September 30, 2012. Factoring in these expected payments and settlements, AMSC expects to have more than $52 million in cash, cash equivalents, marketable securities and restricted cash on December 31, 2012.

[0001193125-12-453359:8k_2_02:16]
Conference Call Reminder

[0001193125-12-453359:8k_2_02:17]
In conjunction
with this announcement, AMSC management will participate in a conference call with investors beginning at 10:00 a.m. Eastern Time today to discuss the company’s results and its business outlook. Those who wish to listen to the live or archived
conference call webcast should visit the “Investors” section of the company’s website at http://www.amsc.com/investors. The live call also can be accessed by dialing 785-830-1924 and using conference ID 9404141.

[0001193125-12-453359:8k_2_02:18]
About AMSC (NASDAQ: AMSC)

[0001193125-12-453359:8k_2_02:19]
AMSC
generates the ideas, technologies and solutions that meet the world’s demand for smarter, cleaner … better energy. Through its Windtec™ Solutions, AMSC provides wind turbine electronic controls and systems, designs and engineering
services that reduce the cost of wind energy. Through its Gridtec™ Solutions, AMSC provides the engineering planning services and advanced grid systems that optimize network reliability, efficiency and performance. The company’s solutions
are now powering gigawatts of renewable energy globally and enhancing the performance and reliability of power networks in more than a dozen countries. Founded in 1987, AMSC is headquartered near Boston, Massachusetts with operations in Asia,
Australia, Europe and North America. For more information, please visit www.amsc.com.

[0001193125-12-453359:8k_2_02:20]
AMSC, Windtec and Gridtec are trademarks or
registered trademarks of American Superconductor Corporation. All other brand names, product names, trademarks or service marks belong to their respective holders.

[0001193125-12-453359:8k_2_02:21]
| AMSC Reports Q2 Results |  | Page 3 |

[0001193125-12-453359:8k_2_02:22]
subassemblies of many of our Wind and Grid products, making us vulnerable to supply shortages and price fluctuations, which could harm our business; many of our revenue opportunities are
dependent upon subcontractors and other business collaborators; if we fail to implement our business strategy successfully, our financial performance could be harmed; problems with product quality or product performance may cause us to incur
warranty expenses and may damage our market reputation and prevent us from achieving increased sales and market share; our contracts with the United States government are subject to audit, modification or termination by the United States government
and include certain other provisions in favor of the government; the continued funding of such contracts remains subject to annual congressional appropriation which, if not approved, could reduce our revenue and lower or eliminate our profit; we may
acquire additional complementary businesses or technologies, which may require us to incur substantial costs for which we may never realize the anticipated benefits; many of our customers outside of the United States are, either directly or
indirectly, related to governmental entities, and we could be adversely affected by violations of the United States Foreign Corrupt Practices Act and similar worldwide anti-bribery laws outside the United States; we have limited experience in
marketing and selling our superconductor products and system-level solutions, and our failure to effectively market and sell our products and solutions could lower our revenue and cash flow; we have a history of operating losses, and we may incur
additional losses in the future; our operating results may fluctuate significantly from quarter to quarter and may fall below expectations in any particular fiscal quarter; we may require additional funding in the future and may be unable to raise
capital when needed; our new debt obligations include certain covenants and other events of default. Should we not comply with the covenants or incur an event of default, we may be required to repay our debt obligations in cash, which could have an
adverse effect on our liquidity; we have recorded a liability for adverse purchase commitments with certain of our vendors; should we be required to settle these liabilities in cash, our liquidity could be adversely affected; if we fail to maintain
proper and effective internal controls over financial reporting, our ability to produce accurate and timely financial statements could be impaired and may lead investors and other users to lose confidence in our financial data; we may be required to
issue performance bonds or provide letters of credit, which restricts our ability to access any cash used as collateral for the bonds or letters of credit; changes in exchange rates could adversely affect our results from operations; growth of the
wind energy market depends largely on the availability and size of government subsidies and economic incentives; we depend on sales to customers in China, and global conditions could negatively affect our operating results or limit our ability to
expand our operations outside of China; changes in China’s political, social, regulatory and economic environment may affect our financial performance; our products face intense competition, which could limit our ability to acquire or retain
customers; our international operations are subject to risks that we do not face in the United States, which could have an adverse effect on our operating results; adverse changes in domestic and global economic conditions could adversely affect our
operating results; we may be unable to adequately prevent disclosure of trade secrets and other proprietary information; our patents may not provide meaningful protection for our technology, which could result in us losing some or all of our market
position; the commercial uses of superconductor products are limited today, and a widespread commercial market for our products may not develop; there are a number of technological challenges that must be successfully addressed before our
superconductor products can gain widespread commercial acceptance, and our inability to address such technological challenges could adversely affect our ability to acquire customers for our products; we have not manufactured our Amperium wire in
commercial quantities, and a failure to manufacture our Amperium wire in commercial quantities at acceptable cost and quality levels would substantially limit our future revenue and profit potential; third parties have or may acquire patents that
cover the materials, processes and technologies we use or may use in the future to manufacture our Amperium products, and our success depends on our ability to license such patents or other proprietary rights; our technology and products could
infringe intellectual property rights of others, which may require costly litigation and, if we are not successful, could cause us to pay substantial damages and disrupt our business; we have filed a demand for arbitration and other lawsuits against
our former largest customer, Sinovel, regarding amounts we contend are overdue. We cannot be certain as to the outcome of these proceedings; we have been named as a party to purported stockholder class actions and stockholder derivative complaints,
and we may be named in additional litigation, all of which will require significant management time and attention, result in significant legal expenses and may result in an unfavorable outcome, which could have a material adverse effect on our
business, operating results and financial condition; our 7% convertible note contains warrants and provisions that could limit our ability to repay the note in shares of common stock and should the note be repaid in stock, shareholders could
experience significant dilution; our common stock has experienced, and may continue to experience, significant market price and volume fluctuations, which may prevent our stockholders from selling our common stock at a profit and could lead to
costly litigation against us that could divert our management’s attention; and new regulations related to conflict-free minerals may force us to incur additional expenses. These and the important factors discussed under the caption “Risk
Factors” in Part II. Item 1A and Part 1. Item 1A of our Form 10-K/A for the fiscal year ended March 31, 2012, among others, could cause actual results to differ materially from those indicated by forward-looking statements made
herein and presented elsewhere by management from time to time. Any such forward-looking statements represent management’s estimates as of the date of this press release. While we may elect to update such forward-looking statements at some
point in the future, we disclaim any obligation to do so, even if subsequent events cause our views to change. These forward-looking statements should not be relied upon as representing our views as of any date subsequent to the date of this press
release.

[0001193125-12-453359:8k_2_02:23]
| AMSC Reports Q2 Results |  | Page 4 |

[0001193125-12-453359:8k_2_02:24]
CONSOLIDATED STATEMENTS OF OPERATIONS

[0001193125-12-453359:8k_2_02:25]
(In thousands, except per share data)

[0001193125-12-453359:8k_2_02:26]
|  |  | Three months endedSeptember 30, |  |  | Six months endedSeptember 30, |  |
|  |  | 2012 |  |  | 2011 |  |  | 2012 |  |  | 2011 |  |
| Revenues |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Wind |  | $ | 12,002 |  |  | $ | 13,449 |  |  | $ | 28,513 |  |  | $ | 17,712 |  |
| Grid |  |  | 8,865 |  |  |  | 7,351 |  |  |  | 21,070 |  |  |  | 12,146 |  |
| Total Revenues |  |  | 20,867 |  |  |  | 20,800 |  |  |  | 49,583 |  |  |  | 29,858 |  |
| Cost of revenues |  |  | 20,384 |  |  |  | 21,937 |  |  |  | 37,310 |  |  |  | 38,892 |  |
| Gross profit (loss) |  |  | 483 |  |  |  | (1,137 | ) |  |  | 12,273 |  |  |  | (9,034 | ) |
| Cost and operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Research and development |  |  | 3,621 |  |  |  | 7,276 |  |  |  | 7,532 |  |  |  | 15,411 |  |
| Selling, general and administrative |  |  | 11,736 |  |  |  | 17,560 |  |  |  | 25,535 |  |  |  | 39,550 |  |
| Restructuring and impairments |  |  | 16 |  |  |  | 4,301 |  |  |  | 143 |  |  |  | 4,301 |  |
| Write-off of advance payment |  |  | — |  |  |  | 20,551 |  |  |  | — |  |  |  | 20,551 |  |
| Amortization of acquisition related intangibles |  |  | 80 |  |  |  | 300 |  |  |  | 161 |  |  |  | 604 |  |
| Total cost and operating expenses |  |  | 15,453 |  |  |  | 49,988 |  |  |  | 33,371 |  |  |  | 80,417 |  |
| Operating loss |  |  | (14,970 | ) |  |  | (51,125 | ) |  |  | (21,098 | ) |  |  | (89,451 | ) |
| Change in fair value of derivatives and warrants |  |  | 3,285 |  |  |  | — |  |  |  | 897 |  |  |  | — |  |
| Interest (expense) income, net |  |  | (2,919 | ) |  |  | 2 |  |  |  | (5,637 | ) |  |  | 243 |  |
| Other (expense) income, net |  |  | (1,266 | ) |  |  | 355 |  |  |  | (1,143 | ) |  |  | 920 |  |
| Loss before income tax expense |  |  | (15,870 | ) |  |  | (50,768 | ) |  |  | (26,981 | ) |  |  | (88,288 | ) |
| Income tax (benefit) expense |  |  | 79 |  |  |  | 941 |  |  |  | (757 | ) |  |  | 1,100 |  |
| Net loss |  | $ | (15,949 | ) |  | $ | (51,709 | ) |  | $ | (26,224 | ) |  | $ | (89,388 | ) |
| Net loss per common share |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | (0.31 | ) |  | $ | (1.02 | ) |  | $ | (0.51 | ) |  | $ | (1.76 | ) |
| Diluted |  | $ | (0.31 | ) |  | $ | (1.02 | ) |  | $ | (0.51 | ) |  | $ | (1.76 | ) |
| Weighted average number of common shares outstanding |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  |  | 51,907 |  |  |  | 50,876 |  |  |  | 51,551 |  |  |  | 50,716 |  |
| Diluted |  |  | 51,907 |  |  |  | 50,876 |  |  |  | 51,551 |  |  |  | 50,716 |  |

[0001193125-12-453359:8k_2_02:27]
| AMSC Reports Q2 Results |  | Page 5 |

[0001193125-12-453359:8k_2_02:28]
CONSOLIDATED BALANCE SHEETS

[0001193125-12-453359:8k_2_02:29]
(In thousands)

[0001193125-12-453359:8k_2_02:30]
|  |  | September 30,2012 |  |  | March 31,2012 |  |
| ASSETS |  |  |  |  |  |  |  |  |
| Current assets: |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 49,136 |  |  | $ | 46,279 |  |
| Marketable securities |  |  | 5,220 |  |  |  | 5,304 |  |
| Accounts receivable, net |  |  | 15,224 |  |  |  | 18,999 |  |
| Inventory |  |  | 29,674 |  |  |  | 29,256 |  |
| Prepaid expenses and other current assets |  |  | 22,564 |  |  |  | 31,444 |  |
| Restricted cash |  |  | 13,620 |  |  |  | 12,086 |  |
| Deferred tax assets |  |  | 203 |  |  |  | 203 |  |
| Total current assets |  |  | 135,641 |  |  |  | 143,571 |  |
| Property, plant and equipment, net |  |  | 85,462 |  |  |  | 90,828 |  |
| Intangibles, net |  |  | 3,251 |  |  |  | 3,772 |  |
| Restricted cash |  |  | 5,142 |  |  |  | 2,540 |  |
| Deferred tax assets |  |  | 3,129 |  |  |  | 3,129 |  |
| Other assets |  |  | 9,688 |  |  |  | 11,216 |  |
| Total assets |  | $ | 242,313 |  |  | $ | 255,056 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |  |  |  |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |  |  |  |
| Accounts payable and accrued expenses |  | $ | 26,595 |  |  | $ | 37,582 |  |
| Note payable, current portion, net of discount of $647 as of September 30, 2012 |  |  | 3,584 |  |  |  | — |  |
| Current portion of convertible note, net of discount of $6,060 as of September 30, 2012 |  |  | 5,978 |  |  |  | — |  |
| Derivative liability |  |  | 10,280 |  |  |  | — |  |
| Adverse purchase commitments |  |  | 12,080 |  |  |  | 25,894 |  |
| Deferred revenue |  |  | 17,328 |  |  |  | 19,718 |  |
| Deferred tax liabilities |  |  | 3,129 |  |  |  | 3,129 |  |
| Total current liabilities |  |  | 78,974 |  |  |  | 86,323 |  |
| Note Payable, net of discount of $276 as of September 30, 2012 |  |  | 5,493 |  |  |  | — |  |
| Convertible note net of discount of $2,357 as of September 30, 2012 |  |  | 9,681 |  |  |  | — |  |
| Deferred revenue |  |  | 1,521 |  |  |  | 1,558 |  |
| Deferred tax liabilities |  |  | 203 |  |  |  | 203 |  |
| Other liabilities |  |  | 1,658 |  |  |  | 2,093 |  |
| Total liabilities |  |  | 97,530 |  |  |  | 90,177 |  |
| Stockholders’ equity: |  |  |  |  |  |  |  |  |
| Common stock |  |  | 531 |  |  |  | 520 |  |
| Additional paid-in capital |  |  | 903,485 |  |  |  | 896,603 |  |
| Treasury stock |  |  | (307 | ) |  |  | (271 | ) |
| Accumulated other comprehensive income |  |  | 1,298 |  |  |  | 2,027 |  |
| Accumulated deficit |  |  | (760,224 | ) |  |  | (734,000 | ) |
| Total stockholders’ equity |  |  | 144,783 |  |  |  | 164,879 |  |
| Total liabilities and stockholders’ equity |  | $ | 242,313 |  |  | $ | 255,056 |  |

[0001193125-12-453359:8k_2_02:31]
| AMSC Reports Q2 Results |  | Page 6 |

[0001193125-12-453359:8k_2_02:32]
CONSOLIDATED STATEMENTS OF CASH FLOWS

[0001193125-12-453359:8k_2_02:33]
(In thousands)

[0001193125-12-453359:8k_2_02:34]
|  |  | Three Months ended September 30, |  |
|  |  | 2012 |  |  | 2011 |  |
| Cash flows from operating activities: |  |  |  |  |  |  |  |  |
| Net (loss) income |  | $ | (26,224 | ) |  | $ | (89,388 | ) |
| Adjustments to reconcile net (loss) income to net cash (used in) provided by operations: |  |  |  |  |  |  |  |  |
| Depreciation and amortization |  |  | 6,628 |  |  |  | 6,670 |  |
| Stock-based compensation expense |  |  | 4,039 |  |  |  | 5,579 |  |
| Write-off of advanced payment to The Switch |  |  | — |  |  |  | 20,551 |  |
| Restructuring charges, net of payments |  |  | (49 | ) |  |  | 2,174 |  |
| Impairment of long-lived and intangible assets |  |  | — |  |  |  | 918 |  |
| Provision for excess and obsolete inventory |  |  | 421 |  |  |  | 1,503 |  |
| Adverse purchase commitment losses (recoveries), net |  |  | (8,309 | ) |  |  | 167 |  |
| Loss on minority interest investments |  |  | 1,490 |  |  |  | 1,351 |  |
| Change in fair value of convertible notes and warrants |  |  | 897 |  |  |  | — |  |
| Non-cash interest expense |  |  | 4,443 |  |  |  | — |  |
| Other non-cash items |  |  | 350 |  |  |  | 441 |  |
| Changes in operating asset and liability accounts: |  |  |  |  |  |  |  |  |
| Accounts receivable |  |  | 2,856 |  |  |  | (3,709 | ) |
| Inventory |  |  | (971 | ) |  |  | (6,800 | ) |
| Prepaid expenses and other current assets |  |  | 8,394 |  |  |  | (12,529 | ) |
| Accounts payable and accrued expenses |  |  | (14,900 | ) |  |  | (37,633 | ) |
| Deferred revenue |  |  | (2,236 | ) |  |  | 3,809 |  |
| Net cash used in operating activities |  |  | (23,171 | ) |  |  | (106,896 | ) |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |
| Net cash (used in) provided by investing activities |  |  | (4,935 | ) |  |  | 76,228 |  |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |
| Net cash provided by (used in) financing activities |  |  | 31,243 |  |  |  | (121 | ) |
| Effect of exchange rate changes on cash and cash equivalents |  |  | (280 | ) |  |  | 517 |  |
| Net increase (decrease) in cash and cash equivalents |  |  | 2,857 |  |  |  | (30,272 | ) |
| Cash and cash equivalents at beginning of year |  |  | 46,279 |  |  |  | 123,783 |  |
| Cash and cash equivalents at end of year |  | $ | 49,136 |  |  | $ | 93,511 |  |
| Supplemental schedule of cash flow information: |  |  |  |  |  |  |  |  |
| Cash paid for income taxes, net of refunds |  | $ | (752 | ) |  | $ | 18,147 |  |
| Issuance of common stock to settle liabilities |  |  | 2,676 |  |  |  | 421 |  |
| Cash paid for interest expense |  |  | 269 |  |  |  | — |  |

[0001193125-12-453359:8k_2_02:35]
| AMSC Reports Q2 Results |  | Page 7 |

[0001193125-12-453359:8k_2_02:36]
RECONCILIATION OF GAAP NET (LOSS) INCOME TO NON-GAAP NET (LOSS) INCOME

[0001193125-12-453359:8k_2_02:37]
(In thousands, except per share data)

[0001193125-12-453359:8k_2_02:38]
|  |  | Three months endedSeptember 30, |  |  | Six months endedSeptember 30, |  |
|  |  | 2012 |  |  | 2011 |  |  | 2012 |  |  | 2011 |  |
| Net loss |  | $ | (15,949 | ) |  | $ | (51,709 | ) |  | $ | (26,224 | ) |  | $ | (89,388 | ) |
| Adverse purchase commitment (recoveries) losses, net |  |  | (1,009 | ) |  |  | (904 | ) |  |  | (8,309 | ) |  |  | 167 |  |
| Stock-based compensation |  |  | 2,044 |  |  |  | 2,113 |  |  |  | 4,039 |  |  |  | 5,579 |  |
| Amortization of acquisition-related intangibles |  |  | 80 |  |  |  | 300 |  |  |  | 161 |  |  |  | 604 |  |
| Restructuring and impairment charges |  |  | 16 |  |  |  | 4,301 |  |  |  | 143 |  |  |  | 4,301 |  |
| Executive severance |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 2,066 |  |
| Sinovel litigation |  |  | 304 |  |  |  | 3,334 |  |  |  | 424 |  |  |  | 3,334 |  |
| Consumption of zero cost-basis inventory |  |  | 401 |  |  |  | (127 | ) |  |  | 788 |  |  |  | (127 | ) |
| Change in fair value of derivatives and warrants |  |  | (3,285 | ) |  |  | — |  |  |  | (897 | ) |  |  | — |  |
| Non-cash interest expense |  |  | 2,161 |  |  |  | — |  |  |  | 4,443 |  |  |  | — |  |
| Write-off of advance payment |  |  | — |  |  |  | 20,551 |  |  |  | — |  |  |  | 20,551 |  |
| Non-GAAP net loss |  | $ | (15,237 | ) |  | $ | (22,141 | ) |  | $ | (25,432 | ) |  | $ | (52,913 | ) |
| Non-GAAP loss earnings per share |  | $ | (0.29 | ) |  | $ | (0.44 | ) |  | $ | (0.49 | ) |  | $ | (1.04 | ) |
| Weighted average shares outstanding * |  |  | 51,907 |  |  |  | 50,876 |  |  |  | 51,551 |  |  |  | 50,716 |  |

[0001193125-12-453359:8k_2_02:39]
| * | Diluted shares are used for periods where net income is generated. |

[0001193125-12-453359:8k_2_02:40]
RECONCILIATION OF FORECAST GAAP NET LOSS TO NON-GAAP NET LOSS

[0001193125-12-453359:8k_2_02:41]
(In
millions, except per share data)

[0001193125-12-453359:8k_2_02:42]
|  |  | Three months endingDecember 31, 2012 |  |
| Net loss |  | $ | (19.0 | ) |
| Amortization of acquisition-related intangibles |  |  | 0.3 |  |
| Stock-based compensation |  |  | 2.5 |  |
| Non-cash interest expense |  |  | 2.2 |  |
| Non-GAAP net loss |  | $ | (14.0 | ) |
| Non-GAAP net loss per share |  | $ | (0.26 | ) |
| Shares outstanding |  |  | 52.9 |  |

[0001193125-12-453359:8k_2_02:43]
Note: Non-GAAP net income (loss) is defined by the company as net income (loss) before adverse purchase commitments
(recoveries) losses, net; stock-based compensation; amortization of acquisition-related intangibles; restructuring and impairment charges; executive severance; Sinovel litigation costs; margin on zero cost-basis accounting; non-cash interest
expense; change in fair value of derivative liability and warrants and other unusual charges; net of any tax effects related to these items. The company believes non-GAAP net income (loss) assists management and investors in comparing the
company’s performance across reporting periods on a consistent basis by excluding these non-cash or non-recurring charges that it does not believe are indicative of its core operating performance. The company also regards non-GAAP net income
(loss) as a useful measure of operating performance and cash flow to complement operating income, net income (loss) and other GAAP financial performance measures. In addition, the company uses non-GAAP net (loss) income as a factor in evaluating
management’s performance when determining incentive compensation and to evaluate the effectiveness of its business strategies.

[0001193125-12-453359:8k_2_02:44]
| AMSC Reports Q2 Results |  | Page 8 |

[0001193125-12-453359:8k_2_02:45]
Generally, a non-GAAP financial measure is a numerical measure of a company’s performance,
financial position or cash flow that either excludes or includes amounts that are not normally excluded or included in the most directly comparable measure calculated and presented in accordance with GAAP. The non-GAAP measures included in this
release, however, should be considered in addition to, and not as a substitute for or superior to, operating income, cash flows, or other measures of financial performance prepared in accordance with GAAP. A reconciliation of non-GAAP to GAAP net
income is set forth in the table above.

[0001193125-12-453359:8k_2_02:46]
AMSC Contact:

[0001193125-12-453359:8k_2_02:47]
Jason Fredette

[0001193125-12-453359:8k_2_02:48]
Phone: 978-842-3177

[0001193125-12-453359:8k_2_02:49]
Email: jason.fredette@amsc.com
