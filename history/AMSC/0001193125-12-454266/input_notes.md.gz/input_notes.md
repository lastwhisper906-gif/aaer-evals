# AMSC notes — 0001193125-12-454266


## amsc:PrepaidAndOtherCurrentAssetsDisclosureTextBlock

[0001193125-12-454266:notes:1]
7. Prepaid and Other Current Assets

[0001193125-12-454266:notes:2]
Prepaid and other current assets consisted of the following (in thousands):

[0001193125-12-454266:notes:3]
|  |  | September 30, |  |  | March 31, |
|  |  | 2012 |  |  | 2012 |
| Non-Trade Receivables | $ | 983 |  |  | 3,922 |
| Prepaid Expenses |  | 3,094 |  |  | 4,707 |
| Prepaid VAT and Other Taxes |  | 16,784 |  |  | 18,273 |
| Notes Receivable |  | 1,674 |  |  | 4,526 |
| Other Current Assets |  | 29 |  |  | 16 |
| Total | $ | 22,564 |  | $ | 31,444 |


## amsc:ScheduleOfBusinessSegmentAssetsTextBlock

[0001193125-12-454266:notes:4]
|  |  | September 30, |  |  | March 31, |
|  |  | 2012 |  |  | 2012 |
| Wind | $ | 60,065 |  | $ | 70,054 |
| Grid |  | 80,826 |  |  | 89,091 |
| Corporate assets |  | 101,422 |  |  | 95,911 |
| Total | $ | 242,313 |  | $ | 255,056 |


## amsc:ScheduleOfBusinessSegmentOperatingResultsTextBlock

[0001193125-12-454266:notes:5]
|  |  | Three months ended |  |  | Six months ended |
|  |  | September 30, |  |  | September 30, |
|  |  | 2012 |  | 2011 |  |  | 2012 |  | 2011 |
| Revenues: |  |  |  |  |  |  |  |  |  |
| Wind | $ | 12,002 | $ | 13,449 |  | $ | 28,513 | $ | 17,712 |
| Grid |  | 8,865 |  | 7,351 |  |  | 21,070 |  | 12,146 |
| Total | $ | 20,867 | $ | 20,800 |  | $ | 49,583 | $ | 29,858 |

[0001193125-12-454266:notes:6]
|  |  | Three months ended |  |  | Six months ended |
|  |  | September 30, |  |  | September 30, |
|  |  | 2012 |  | 2011 |  |  | 2012 |  | 2011 |
| Operating (loss) income: |  |  |  |  |  |  |  |  |  |
| Wind | $ | (6,449) | $ | (16,336) |  | $ | (5,148) | $ | (40,705) |
| Grid |  | (6,572) |  | (7,645) |  |  | (11,915) |  | (18,197) |
| Unallocated corporate expenses |  | (1,949) |  | (27,144) |  |  | (4,035) |  | (30,549) |
| Total | $ | (14,970) | $ | (51,125) |  | $ | (21,098) | $ | (89,451) |


## amsc:ScheduleOfLiabilitiesMeasuredAtFairValueTableTextBlock

[0001193125-12-454266:notes:7]
|  |  | Derivative |  |  |  |
|  |  | Liability |  |  | Warrants |
| April 1, 2012 | $ | - |  | $ | - |
| Valuation of derivative liability |  | 3,779 |  |  | - |
| Warrant issuance with Senior Convertible Notes |  | - |  |  | 7,018 |
| Warrant issuance with Senior Secured Term Loan |  | - |  |  | 380 |
| Mark to market adjustment |  | (1,016) |  |  | 119 |
| Balance at September 30, 2012 | $ | 2,763 |  | $ | 7,517 |


## us-gaap:AccountsPayableAndAccruedLiabilitiesDisclosureTextBlock

[0001193125-12-454266:notes:8]
8. Accounts Payable and Accrued Expenses

[0001193125-12-454266:notes:9]
Accounts payable and accrued expenses consisted of the following (in thousands):

[0001193125-12-454266:notes:10]
|  |  | September 30, |  |  | March 31, |
|  |  | 2012 |  |  | 2012 |
| Accounts payable | $ | 3,390 |  | $ | 8,191 |
| Accrued inventories in-transit |  | 2,954 |  |  | 3,330 |
| Accrued miscellaneous expenses |  | 8,806 |  |  | 9,708 |
| Accrued subcontractor program costs |  | 1,642 |  |  | 1,885 |
| Accrued compensation |  | 4,930 |  |  | 8,380 |
| Income taxes payable |  | 81 |  |  | 192 |
| Accrued warranty |  | 4,792 |  |  | 5,896 |
| Total | $ | 26,595 |  | $ | 37,582 |

[0001193125-12-454266:notes:11]
Product Warranty

[0001193125-12-454266:notes:12]
The Company generally provides a one to three year warranty on its products, commencing upon installation. A provision is recorded upon revenue recognition to cost of revenues for estimated warranty expense based on historical experience.

[0001193125-12-454266:notes:13]
Product warranty activity was as follows (in thousands):

[0001193125-12-454266:notes:14]
|  |  | Three months ended |  |  | Six months ended |
|  |  | September 30, |  |  | September 30, |
|  |  | 2012 |  | 2011 |  |  | 2012 |  | 2011 |
| Balance at beginning of period | $ | 5,500 | $ | 7,334 |  | $ | 5,896 | $ | 7,907 |
| Change in accruals for warranties during the period |  | (384) |  | (69) |  |  | (551) |  | (474) |
| Settlements during the period |  | (324) |  | (210) |  |  | (553) |  | (378) |
| Balance at end of period | $ | 4,792 | $ | 7,055 |  | $ | 4,792 | $ | 7,055 |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001193125-12-454266:notes:15]
13.  Commitments and Contingencies

[0001193125-12-454266:notes:16]
Commitments

[0001193125-12-454266:notes:17]
Purchase Commitments

[0001193125-12-454266:notes:18]
The Company periodically enters into non-cancelable purchase contracts in order to ensure the availability of materials to support production of its products. Purchase commitments represent enforceable and legally binding agreements with suppliers to purchase goods or services. The Company periodically assesses the need to provide for impairment on these purchase contracts and record a loss on purchase commitments when required.  As of September 30, 2012, the Company recorded a liability for adverse purchase commitments of $12.1 million. During the three and six months ended September 30, 2012, the Company adjusted its accrual for adverse purchase commitments by $1.0 million and $8.3 million, respectively due to settlements with certain vendors.

[0001193125-12-454266:notes:19]
During the fourth quarter of the year ended March 31, 2012, several vendors notified the Company that they had suffered losses as a result of procuring safety stock in anticipation of receiving future purchase orders or contracts from the Company.  Subsequently three vendors filed lawsuits through the Chinese legal system seeking payment for inventories held to be delivered under purchase orders and safety stock. One of these lawsuits has been settled and dismissed.  The Company has accrued outstanding adverse purchase commitments based on legally binding contracts and purchase orders that were placed with its vendors for parts with no future demand.  The vendor claims for safety stock were not supported by valid purchase orders or valid executed contracts and are not considered part of the adverse purchase commitment liability. The claims for safety stock have not been accrued as of September 30, 2012.  The Company has determined that, although it believes that there is no legally enforceable contract for safety stock and will continue to defend its legal position that it does not owe amounts for safety stock, it is reasonably possible that a case may be made against the Company under certain situations. As the loss is reasonably possible but not probable, the Company has not accounted for the loss.  The Company has determined that the range for this potential loss is between $0 and $4 million.

[0001193125-12-454266:notes:20]
Contingencies

[0001193125-12-454266:notes:21]
From time to time, the Company is involved in legal and administrative proceedings and claims of various types.  The Company records a liability in its consolidated financial statements for these matters when a loss is known or considered probable and the amount can be reasonably estimated. The Company reviews these estimates each accounting period as additional information is known and adjusts the loss provision when appropriate. If a matter is both probable to result in liability and the amounts of loss can be reasonably estimated, the Company estimates and discloses the possible loss or range of loss. If the loss is not probable or cannot be reasonably estimated, a liability is not recorded in its consolidated financial statements.

[0001193125-12-454266:notes:22]
Between April 6, 2011 and May 12, 2011, seven putative securities class action complaints were filed against the Company and two of its officers in the United States District Court for the District of Massachusetts; one complaint additionally asserted claims against the underwriters who participated in our November 12, 2010 securities offering.  On June 7, 2011, the United States District Court for the District of Massachusetts consolidated these actions under the caption Lenartz v. American Superconductor Corporation, et al., Docket No. 1:11-cv-10582-WGY.  On August 31, 2011, Lead Plaintiff, the Plumbers and Pipefitters National Pension Fund, filed a consolidated amended complaint against the Company, its officers and directors, and the underwriters who participated in our November 12, 2010 securities offering, asserting claims under sections 10(b) and 20(a) of the Securities Exchange Act of 1934 and Rule 10b-5 promulgated under the Securities Exchange Act of 1934 (the “Exchange Act”), as well as under sections 11, 12(a)(2) and 15 of the Securities Act of 1933 (the “Securities Act”).  The complaint alleges that during the relevant class period, the Company and its officers omitted to state material facts and made materially false and misleading statements relating to, among other things, its projected and recognized revenues and earnings, as well as its relationship with Sinovel Wind Group Co., Ltd. that artificially inflated the value of the Company’s stock price.  The complaint further alleges that the Company’s November 12, 2010 securities offering contained untrue statements of material facts and omitted to state material facts required to be stated therein.  The plaintiffs seek unspecified damages, rescindment of the Company’s November 12, 2010 securities offering, and an award of costs and expenses, including attorney’s fees.  All defendants moved to dismiss the consolidated amended complaint.  On December 16, 2011, the district court issued a summary order declining to dismiss the Securities Act claims against the Company and its officers, and taking under advisement the motion to dismiss the Exchange Act claims against the Company and its officers and the motion to dismiss the Securities Act claims made against the underwriters. On July 26, 2012, the district court dismissed the Exchange Act claims against the Company and its officers and denied the motion to dismiss the Securities Act claims made against the underwriters.

[0001193125-12-454266:notes:23]
Between May 4, 2011 and June 17, 2011, four putative shareholder derivative complaints were filed against the Company (as a nominal defendant) and certain of its directors in the United States District Court for the District of Massachusetts.  On July 5, 2011, the District Court consolidated three of these actions, and that matter is now captioned In re American Superconductor Corporation Derivative Litigation, Docket No. 1:11-cv-10784-WGY.  On June 1, 2011, the plaintiff in the fourth action, Marlborough Family Revocable Trust v. Yurek, et al., moved to voluntarily dismiss its complaint and refiled its complaint in Superior Court for the Commonwealth of Massachusetts, Middlesex County.  On September 7, 2011, the Marlborough action and another putative shareholder derivative complaint filed in Superior Court for the Commonwealth of Massachusetts were consolidated.  That consolidated matter is captioned Marlborough Family Revocable Trust v. Yurek, et al., Docket No. 11-1961.  On January 12, 2012, an additional shareholder derivative complaint was filed in the Court of Chancery for the State of Delaware.  That matter is captioned Krasnoff v. Budhraja, et al., Docket No. 7171.  The allegations of the derivative complaints mirror the allegations made in the putative class action complaints described above.  The plaintiffs purport to assert claims against the director defendants for breach of fiduciary duty, abuse of control, gross mismanagement, unjust enrichment and corporate waste.  The plaintiffs seek unspecified damages on behalf of the Company, as well as an award of costs and expenses, including attorney’s fees.

[0001193125-12-454266:notes:24]
With respect to the above referenced litigation matters, an estimate of loss or range of loss cannot be made. There are numerous factors that make it difficult to meaningfully estimate possible loss or range of loss at this stage of these litigation matters, including that: the proceedings are in relatively early stages, there are significant factual and legal issues to be resolved, information obtained or rulings made during the lawsuits could affect the methodology for calculation of rescission and the related statutory interest rate. In addition, with respect to claims where damages are the requested relief, no amount of loss or damages has been specified. Therefore, the Company is unable at this time to estimate possible losses.  The Company believes that these litigations are without merit, and it intends to defend these actions vigorously. Therefore no adjustment has been made to the financial statements to reflect the outcome of these uncertainties.

[0001193125-12-454266:notes:25]
On September 13, 2011, the Company commenced a series of legal actions in China against Sinovel Wind Group Co. Ltd. (“Sinovel”).  The Company’s Chinese subsidiary, Suzhou AMSC Superconductor Co. Ltd., filed a claim for arbitration with the Beijing Arbitration Commission in accordance with the terms of the Company’s supply contracts with Sinovel.  The case is captioned (2011) Jin Zhong An Zi No. 0963. On March 31, 2011, Sinovel refused to accept contracted shipments of 1.5 megawatt (MW) and 3 MW wind turbine core electrical components and spare parts that the Company was prepared to deliver. The Company alleges that these actions constitute material breaches of its contracts because Sinovel did not give it notice that it intended to delay deliveries as required under the contracts. Moreover, the Company alleges that Sinovel has refused to pay past due amounts for prior shipments of core electrical components and spare parts. The Company is seeking compensation for past product shipments and retention (including interest) in the amount of approximately RMB 485 million ($76 million) due to Sinovel’s breaches of its contracts. The Company is also seeking specific performance of our existing contracts as well as reimbursement of all costs and reasonable expenses with respect to the arbitration. The value of the undelivered components under the existing contracts, including the deliveries refused by Sinovel in March 2011, amounts to approximately RMB 4.6 billion ($720 million).

[0001193125-12-454266:notes:26]
On October 8, 2011, Sinovel filed with the Beijing Arbitration Commission an application under the caption (2011) Jing Zhong An Zi No. 0963, for a counterclaim against the Company for breach of the same contracts under which the Company filed its original arbitration claim.  Sinovel claimed, among other things, that the goods supplied by the Company do not conform to the standards specified in the contracts and claimed damages in the amount of approximately RMB 370 million ($58 million).  On October 17, 2011, Sinovel filed with the Beijing Arbitration Commission a request for change of counterclaim to increase its damage claim to approximately RMB 1 billion ($157 million).  On December 22, 2011, Sinovel filed with the Beijing Arbitration Commission an additional request for change of counterclaim to increase its damages claim to approximately RMB 1.2 billion ($190 million). On February 27, 2012, Sinovel filed with the Beijing Arbitration Commission an application under the caption (2012) Jing Zhong An Zi No. 0157, against the Company for breach of the same contracts under which the Company filed its original arbitration claim.  Sinovel claimed, among other things, that the goods supplied by the Company do not conform to the standards specified in the contracts and claimed damages in the amount of approximately RMB 105 million ($17 million). The Company believes that Sinovel’s claims are without merit and it intends to defend these actions vigorously. Since the proceedings in this matter are in relatively early stages, the Company cannot reasonably estimate possible losses or range of losses at this time.

[0001193125-12-454266:notes:27]
The Company also submitted a civil action application to the Beijing No. 1 Intermediate People’s Court under the caption (2011) Yi Zhong Min Chu Zi No. 15524, against Sinovel for software copyright infringement on September 13, 2011.  The application alleges Sinovel’s unauthorized use of portions of the Company’s wind turbine control software source code developed for Sinovel’s 1.5MW wind turbines and the binary code, or upper layer, of the Company’s software for the PM3000 power converters in 1.5MW wind turbines. In July 2011, a former employee of the Company’s Austrian subsidiary was arrested in Austria on charges of economic espionage and fraudulent manipulation of data. In September 2011, the former employee pled guilty to the charges, and was imprisoned.  As a result of the Company’s internal investigation and a criminal investigation conducted by Austrian authorities, the Company believes that this former employee was contracted by Sinovel through an intermediary while employed by the Company and improperly obtained and transferred to Sinovel portions of its wind turbine control software source code developed for Sinovel’s 1.5MW wind turbines. Moreover, the Company believes the former employee illegally used source code to develop for Sinovel a software modification to circumvent the encryption and remove technical protection measures on the Company’s PM3000 power converters in 1.5MW wind turbines in the field.  The Company is seeking a cease and desist order with respect to the unauthorized copying, installation and use of its software, monetary damages of approximately RMB 38 million ($6 million) for our economic losses and reimbursement of all costs and reasonable expenses.  The No. 1 Intermediate People’s Court accepted the case, which was necessary in order for the case to proceed.  In November 2011, Sinovel filed a motion to remove this case from the Beijing No. 1 Intermediate People’s Court and transfer the matter to the Beijing Arbitration Commission.  On February 14, 2012, the court denied Sinovel’s motion to remove the case.  On February 21, 2012, Sinovel filed an appeal of the Beijing No. 1 Intermediate People’s Court decision to the Beijing Higher People’s Court.  On April 25, 2012, the Beijing Higher People’s Court issued a final Civil Ruling which supports the Beijing No.1 Intermediate People’s Court’s civil ruling and rejected Sinovel’s appeal. Sinovel filed an appeal of the Beijing Higher People’s Court’s decision with China’s Supreme People’s Court. A hearing regarding this appeal was held at the Chinese Supreme People’s Court on October 26, 2012. The Court’s decision will follow.

[0001193125-12-454266:notes:28]
Sinovel filed a new motion on June 18, 2012, to remove this case from the Beijing No. 1 Intermediate People’s Court to the court located in Gansu Province. On October 19, 2012, the Court disallowed Sinovel’s motion due to its late filing.

[0001193125-12-454266:notes:29]
The Company submitted a civil action application to the Beijing Higher People’s Court against Sinovel and certain of its employees for trade secret infringement on September 13, 2011 under the caption (2011) Gao Min Chu Zi No. 4193.  The application alleges the defendants’ unauthorized use of portions of the Company’s wind turbine control software source code developed for Sinovel’s 1.5MW wind turbines as described above with respect to the Copyright Action. The Company is seeking monetary damages of RMB 2.9 billion ($453 million) for the trade secret infringement as well as reimbursement of all costs and reasonable expenses.  The Beijing Higher People’s Court accepted the case, which was necessary in order for the case to proceed.  On December 22, 2011, the Beijing Higher People’s Court transferred this case to the Beijing No. 1 Intermediate People’s Court under the caption (2011) Gao Min Chu Zi No. 4193. On June 7, 2012, the Company received an Acceptance Notice from the Beijing No.1 Intermediate People’s Court under the caption (2012) Yi Zhong Min Chu Zi No.6833. The Company is currently awaiting notice from the Beijing No. 1 Intermediate People’s Court regarding the first hearing date. In August 2012, Sinovel filed a motion to remove this case from the Beijing No. 1 Intermediate People’s Court and transfer the matter to the Beijing Arbitration Commission.

[0001193125-12-454266:notes:30]
On September 16, 2011, the Company filed a civil copyright infringement complaint in the Hainan Province No. 1 Intermediate People’s Court against Dalian Guotong Electric Co. Ltd. (“Guotong”), a supplier of power converter products to Sinovel, and Huaneng Hainan Power, Inc. (“Huaneng”), a wind farm operator that has purchased Sinovel wind turbines containing Guotong power converter products.  The case is captioned (2011)  Hainan Yi Zhong Min Chu Zi No. 62.  The application alleges that the Company’s PM1000 converters in certain Sinovel wind turbines have been replaced by converters produced by Guotong. Because the Guotong converters are being used in wind turbines containing the Company’s wind turbine control software, the Company believes that its copyrighted software is being infringed.  The Company is seeking a cease and desist order with respect to the unauthorized use of its software, monetary damages of RMB 1.2 million ($0.2 million) for its economic losses (with respect to Guotong only) and reimbursement of all costs and reasonable expenses.  The court has accepted the case, which was necessary in order for the case to proceed.  In addition, upon the request of the defendant Huaneng, Sinovel has been added by the court to this case as a defendant and Huaneng has been released from this case.  In December 2011, Sinovel filed a jurisdiction opposition motion requesting dismissal by the Hainan Province No. 1 Intermediate People’s Court, saying the case should be governed by the Beijing Arbitration Commission. On February 3, 2012, the Company received the Civil Ruling from the court, which granted Sinovel’s motion, and dismissed the entire case. The Company appealed the court’s ruling to the Hainan Higher Court, which on April 5, 2012 upheld the decision of the Hainan Province No. 1 Intermediate People’s Court.  On April 9, 2012, the Company filed an appeal of the Hainan Higher Court’s decision with China’s Supreme People’s Court. The Supreme Court accepted the appeal on May 23, 2012. The case is captioned, (2012) Min Shen Zi No. 630.

[0001193125-12-454266:notes:31]
Ghodawat Energy Pvt Ltd (“Ghodawat”), a company registered in India carrying on the business of wind power development, lodged a Request for Arbitration with the Secretariat of the ICC International Court of Arbitration on May 12, 2011 and named AMSC Windtec GmbH (“AMSC Austria”) as the Respondent.  Under the Request for Arbitration, Ghodawat alleges that AMSC Austria breached an agreement dated March 19, 2008 pursuant to which AMSC Austria granted a license to Ghodawat to manufacture, use, sell, market, erect, commission and maintain certain wind turbines using its technical information and wind turbine design (the “License Agreement”).  Under the Request for Arbitration, Ghodawat’s claims in this arbitration amount to approximately €18 million ($24 million).  AMSC Austria filed an Answer to Request for Arbitration and Counterclaim (“Answer and Counterclaim”), in which AMSC Austria denied Ghodawat’s claims in their entirety.  AMSC Austria has also submitted counterclaims under the License Agreement against Ghodawat in the amount of approximately €6 million ($9 million).  Ghodawat has filed a Reply to Answer to Request for Arbitration and Counterclaim in which it denies AMSC Austria’s counterclaims.  The arbitration proceedings are currently ongoing.  The Company has recorded a loss contingency based on its assessment of probable losses on this claim; however this amount is immaterial to its consolidated financial statements.

[0001193125-12-454266:notes:32]
Other

[0001193125-12-454266:notes:33]
The Company enters into long-term construction contracts with customers that require the Company to obtain performance bonds. The Company is required to deposit an amount equivalent to some or all the face amount of the performance bonds into an escrow account until the termination of the bond. When the performance conditions are met, amounts deposited as collateral for the performance bonds are returned to the Company. In addition, the Company has various contractual arrangements in which minimum quantities of goods or services have been committed to be purchased on an annual basis.

[0001193125-12-454266:notes:34]
At September 30, 2012, the Company had $13.6 million of restricted cash included in current assets, and $5.1 million of restricted cash included in long-term assets. These amounts included in restricted cash represent deposits to secure letters of credit for various supply contracts, and are held in interest bearing accounts.  The Company is working with its inventory suppliers to delay cash settlements and to reduce the gross liability associated with its adverse purchase commitments, which is approximately $12.1 million as of September 30, 2012.  During the three and six months ended September 30, 2012, the Company agreed to settle adverse purchase commitments with certain of its vendors. In conjunction with certain of these settlements, the Company agreed to provide letters of credit and bank guarantees in the amount of approximately $9.0 million with expirations through January 31, 2013. The letters of credit and bank guarantees were secured with cash collateral of $8.5 million. Settlements of adverse purchase commitments with certain vendors have resulted in a reduction of its adverse purchase commitments liability of $1.0 million and $8.3 million, during the three and six months ended September 30, 2012, respectively.

[0001193125-12-454266:notes:35]
As of September 30, 2012, the Company had three performance bonds in support of customer contracts. The total value of the outstanding performance bonds is $3.5 million with expiration dates through March 2014.  In the event that the payment is made in accordance with the requirements of any of these performance bonds, the Company would record the payment as an offset to revenue.


## us-gaap:DebtDisclosureTextBlock

[0001193125-12-454266:notes:36]
11.  Debt

[0001193125-12-454266:notes:37]
Senior Convertible Notes

[0001193125-12-454266:notes:38]
On April 4, 2012, the Company entered into a Securities Purchase Agreement and completed a private placement of $25.0 million of 7% senior convertible notes with Capital Ventures International (“CVI”), an affiliate of Heights Capital Management. After fees and expenses, the net proceeds were $23.2 million.  The Convertible Notes have an initial conversion price of $4.85 per share, representing a premium of approximately 20% over AMSC’s closing price on April 3, 2012. The Convertible Notes are payable in monthly installments beginning four months from issuance and ending on October 4, 2014.  Monthly payments are payable in cash or common stock at the option of the Company, subject to certain trading volume, stock price and other conditions. CVI can also elect to defer receipt of monthly installment payments at its option. Any deferred installment payments will continue to accrue interest. CVI elected to defer the installment payment due September 4, 2012 of $1.1 million. The Company registered 10,262,311 shares of common stock which may be used as payment for principal and interest in lieu of cash for resale under the Securities Act as required under a Registration Rights Agreement with CVI.

[0001193125-12-454266:notes:39]
The Company has accounted for the Convertible Notes as an instrument that has the characteristics of a debt host contract containing several embedded derivative features that would require bifurcation and separate accounting as a derivative instrument pursuant to the provisions of ASC 815. The Company elected not to use the fair value option for the payable of $25.0 million and will record the liability at the stated value under the loan agreement on the date of issuance with no changes in fair value reported in subsequent periods.

[0001193125-12-454266:notes:40]
The Company has identified the following derivatives associated with the Convertible Notes: holder change of control redemption rights; issuer optional redemption rights; sale redemption rights and a feature to convert the Convertible Note into equity at the holder’s option.  The Company valued these derivatives at $3.8 million upon issuance  and recorded the value as a debt discount and a derivative liability. See Note 12, “Warrants and Derivative Liabilities”, for additional information regarding derivative liabilities.

[0001193125-12-454266:notes:41]
In addition, CVI received a warrant to purchase approximately 3.1 million additional shares of common stock exercisable at a strike price of $5.45 per share, subject to adjustment, until October 4, 2017. Due to certain adjustment provisions within the warrant, it qualified for liability accounting and had a fair value of $7.0 million upon issuance. The Company recorded the value as a debt discount and a warrant liability. See Note 12, “Warrants and Derivative Liabilities”, for additional information regarding the warrant.

[0001193125-12-454266:notes:42]
The process of valuing financial and derivative instruments utilizes facts and circumstances as of the measurement date as well as certain inputs, assumptions, and judgments that may affect the estimated fair value of the instruments. Upon issuance of the Convertible Notes, the Company determined the initial carrying value of the Convertible Notes to be $25.0 million. In addition, the Company also incurred $1.8 million of legal and origination costs as of the six months ended September 30, 2012, which have been recorded as a discount on the Convertible Notes. The total debt discount, including the embedded derivatives, warrant and legal and origination costs of $12.6 million is being amortized into interest expense over the term of the Convertible Notes using the effective interest method. Under this method, interest expense is recognized each period until the debt instruments reach maturity.  If the maturity of the Convertible Notes is accelerated because of prepayment, then the amortization will be accelerated.   During the three and six months ended September 30, 2012, the Company recorded non-cash interest expense for amortization of the debt discount related to the Convertible Notes of $2.1 million and $4.2 million, respectively.

[0001193125-12-454266:notes:43]
The Convertible Notes contain certain covenants and restrictions, including, among others, that for so long as the Convertible Notes are outstanding, the Company will not incur any indebtedness (other than permitted indebtedness under the Convertible Notes), permit liens on its properties (other than permitted liens under the Convertible Notes), make payments on junior securities or declare dividends.  The Convertible Notes also contain limitations on the transfer of certain assets.  Events of default under the Convertible Notes include failure to pay principal or interest as due on the Convertible Notes, failure to deliver registered shares of common stock upon the holders request for conversion of part or all of the Convertible Notes, failure to maintain the Company's common stock eligible for trading on defined markets, cross defaults to other material indebtedness, receipt of uninsured judgments against the Company in excess of defined limits and other administrative covenants, as defined in the Convertible Notes and related documentation. Upon an event of default, the holders may require the Company to redeem all or any portion of the outstanding principal amount of the Convertible Notes in cash plus a penalty as specified in the agreement.  Also, if the Company fails to maintain an effective registration statement covering common stock to be used in settling obligations under the Convertible Notes, the Company will be required to pay a penalty as specified in the agreement.

[0001193125-12-454266:notes:44]
In addition, under the Convertible Notes agreements, on October 4, 2012, the Company had the right to issue an additional $15 million aggregate principal amount of convertible notes and warrant to the same investor, subject to certain conditions.   Because the Company did not meet these conditions, it no longer has the right to compel the investor to purchase additional Convertible Notes on the terms contained in the agreement.

[0001193125-12-454266:notes:45]
Senior Secured Term Loan

[0001193125-12-454266:notes:46]
On June 5, 2012, the Company entered into a Term Loan with Hercules Technology Growth Capital, Inc. (“Hercules”), under which the Company borrowed $10.0 million (the “Term Loan”). After the closing fees and expenses, the net proceeds to the Company were $9.7 million. The Term Loan bears an interest rate equal to 11% plus the percentage, if any, by which the prime rate as reported by The Wall Street Journal exceeds 3.75%.  The Company made interest-only payments from July 1, 2012 through October 31, 2012, after which the Company will repay the loan in equal monthly installments ending on December 1, 2014. The Term Loan is secured by substantially all of the Company’s existing and future assets, including a mortgage on real property owned by the Company’s wholly-owned subsidiary, ASC Devens LLC, and located at 64 Jackson Road, Devens, Massachusetts. In addition, Hercules received a warrant to purchase 139,276 shares of common stock, exercisable at an initial strike price of $3.59 per share, subject to adjustment, until December 5, 2017.  Due to certain adjustment provisions within the warrant, it qualified for liability accounting and the fair value of $0.4 million was recorded upon issuance, which the Company recorded as a debt discount and a warrant liability. See Note 12, “Warrants and Derivative Liabilities”, for a discussion on warrants and the valuation assumptions used.  The Company will pay an end of term fee of $0.5 million upon the earlier of maturity or prepayment of the loan.  The Company has accrued this as of the six months ended September 30, 2012 and recorded a corresponding amount into the debt discount.   In addition, the Company incurred $0.3 million of legal and origination costs in the six months ended September 30, 2012, which have been recorded as a debt discount. The total debt discount including the warrant, end of term fee and legal and origination costs of $1.2 million is being amortized into interest expense over the term of the Term Loan using the effective interest method. Under this method, interest expense is recognized each period until the debt instrument reaches maturity. If the maturity of the Term Loan is accelerated because of prepayment, then the amortization will be accelerated.  During the three and six months ended September 30, 2012, the Company recorded non-cash interest expense for amortization of the debt discount related to the Term Loan of $0.2 million and $0.3 million, respectively.

[0001193125-12-454266:notes:47]
The Term Loan contains certain covenants that restrict the Company’s ability to, among other things, incur or assume certain debt, merge or consolidate, materially change the nature of our business, make certain investments, acquire or dispose of certain assets, make guaranties or grant liens on its assets, make certain loans, advances or investments, declare dividends or make distributions or enter into transactions with affiliates. In addition, the Term Loan contains a covenant that requires the Company to maintain a minimum unrestricted cash balance in the United States of at least $10.0 million at the inception of the Term Loan, which will decrease starting November 1, 2012 and monthly thereafter by the amount of principal paid.  The events of default under the Term Loan include, but are not limited to, failure to pay amounts due, breaches of covenants, bankruptcy events, cross defaults under other material indebtedness and the occurrence of a material adverse effect and/or change in control. In the case of a continuing event of default, the Lender may, among other remedies, declare due all unpaid principal amounts outstanding and any accrued but unpaid interest and foreclose on all collateral granted to the Lender as security under the Term Loan.

[0001193125-12-454266:notes:48]
Although the Company is in compliance with the covenants and restrictions under the Convertible Notes and Term Loan as of the date of this Quarterly Report on Form 10-Q, there can be no assurance that the Company will continue to be in compliance.

[0001193125-12-454266:notes:49]
Interest expense on the Convertible Notes and Term Loan for the three and six months ended September 30, 2012 was $3.0 million and $5.7 million respectively, which included $2.3 million and $4.4 million of non-cash interest expense related to the amortization of the debt discount on the Convertible Notes and Term Loan, respectively.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001193125-12-454266:notes:50]
[same as prior period, unchanged from 0001193125-12-334096:notes:55]

[0001193125-12-454266:notes:51]
The Company accounts for its stock-based compensation at fair value. The following table summarizes stock-based compensation expense by financial statement line item for the three and six months ended September 30, 2012 and 2011 (in thousands):

[0001193125-12-454266:notes:52]
|  |  | Three months ended |  |  | Six months ended |
|  |  | September 30, |  |  | September 30, |
|  |  | 2012 |  | 2011 |  |  | 2012 |  | 2011 |
| Cost of revenues | $ | 213 | $ | 440 |  | $ | 383 | $ | 769 |
| Research and development |  | 591 |  | 665 |  |  | 1,154 |  | 1,325 |
| Selling, general and administrative |  | 1,240 |  | 1,008 |  |  | 2,502 |  | 3,485 |
| Total | $ | 2,044 | $ | 2,113 |  | $ | 4,039 | $ | 5,579 |

[0001193125-12-454266:notes:53]
During the six months ended September 30, 2012, the Company granted approximately 852,000 stock options, and 287,000 restricted stock awards, as well as issued approximately 215,000 shares of common stock in-lieu of cash bonuses, which vested immediately, to employees under the 2007 Stock Incentive Plan. The Company recorded the issuance of stock in-lieu of cash bonuses as a non-cash issuance of stock to settle liabilities in the unaudited consolidated condensed statement of cash flows. The options granted vest upon the passage of time, generally 3 years. For awards that vest upon the passage of time, expense is being recorded over the vesting period.

[0001193125-12-454266:notes:54]
The estimated fair value of the Company’s stock-based awards, less expected annual forfeitures, is amortized over the awards’ service period. The total unrecognized compensation cost for unvested outstanding stock options was $6.1 million for the six months ended September 30, 2012. This expense will be recognized over a weighted average expense period of approximately 2.1 years.  The total unrecognized compensation cost for unvested outstanding restricted stock was $3.9 million for the six months ended September 30, 2012. This expense will be recognized over a weighted average expense period of approximately 1.2 years.

[0001193125-12-454266:notes:55]
The weighted-average assumptions used in the Black-Scholes valuation model for stock options granted during the three and six months ended September 30, 2012 and 2011 are as follows:

[0001193125-12-454266:notes:56]
|  | Three months ended |  |  | Six months ended |  |
|  | September 30, |  |  | September 30, |  |
|  | 2012 |  | 2011 |  |  | 2012 |  | 2011 |  |
| Expected volatility | 71.9 | % | 77.6 | % |  | 71.9 | % | 69.3 | % |
| Risk-free interest rate | 0.8 | % | 1.2 | % |  | 0.9 | % | 1.8 | % |
| Expected life (years) | 5.9 |  | 5.9 |  |  | 5.9 |  | 5.9 |  |
| Dividend yield | None |  | None |  |  | None |  | None |  |

[0001193125-12-454266:notes:57]
The expected volatility rate was estimated based on an equal weighting of the historical volatility of the Company’s common stock and the implied volatility of the Company’s traded options. The expected term was estimated based on an analysis of the Company’s historical experience of exercise, cancellation, and expiration patterns. The risk-free interest rate is based on the average of the five and seven year United States Treasury rates.


## us-gaap:EarningsPerShareTextBlock

[0001193125-12-454266:notes:58]
[same as prior period, unchanged from 0001193125-12-334096:notes:63]

[0001193125-12-454266:notes:59]
Basic net (loss) income per share (“EPS”) is computed by dividing net (loss) income by the weighted-average number of common shares outstanding for the period. Where applicable, diluted EPS is computed by dividing the net (loss) income by the weighted-average number of common shares and dilutive common equivalent shares outstanding during the period, calculated using the treasury stock method. Common equivalent shares include the effect of restricted stock, exercise of stock options and warrants and contingently issuable shares. For both the three and six months ended September 30, 2012, 8.8 million shares, were not included in the calculation of diluted EPS as they were considered anti-dilutive, of which 3.0 million shares relate to unvested stock options, 3.2 million shares relate to the issuance of warrants, and 2.6 million shares relate to the convertible feature of the Company’s Convertible Notes. For both the three and six months ended September 30, 2011, 2.6 million shares of unvested stock options were not included in the calculation of diluted EPS as they were considered anti-dilutive.

[0001193125-12-454266:notes:60]
The following table reconciles the numerators and denominators of the earnings per share calculation for the three and six months ended September 30, 2012 and 2011 (in thousands, except per share data):

[0001193125-12-454266:notes:61]
|  |  | Three months ended |  |  | Six months ended |
|  |  | September 30, |  |  | September 30, |
|  |  | 2012 |  | 2011 |  |  | 2012 |  | 2011 |
| Numerator: |  |  |  |  |  |  |  |  |  |
| Net loss | $ | (15,949) | $ | (51,709) |  | $ | (26,224) | $ | (89,388) |
| Denominator: |  |  |  |  |  |  |  |  |  |
| Weighted-average shares of common stock outstanding |  | 52,606 |  | 51,232 |  |  | 52,202 |  | 51,090 |
| Weighted-average shares subject to repurchase |  | (699) |  | (356) |  |  | (651) |  | (374) |
| Shares used in per-share calculation ― basic |  | 51,907 |  | 50,876 |  |  | 51,551 |  | 50,716 |
| Shares used in per-share calculation ― diluted |  | 51,907 |  | 50,876 |  |  | 51,551 |  | 50,716 |
| Net loss per share ― basic | $ | (0.31) | $ | (1.02) |  | $ | (0.51) | $ | (1.76) |
| Net loss per share ― diluted | $ | (0.31) | $ | (1.02) |  | $ | (0.51) | $ | (1.76) |


## us-gaap:EquityMethodInvestmentsDisclosureTextBlock

[0001193125-12-454266:notes:62]
14. Equity Investments

[0001193125-12-454266:notes:63]
[same as prior period, unchanged from 0001193125-12-334096:notes:68]

[0001193125-12-454266:notes:64]
On October 9, 2009, the Company made an investment in Tres Amigas LLC, a Delaware limited liability company (“Tres Amigas”), focused on providing the first common interconnection of America's three power grids to help the country achieve its renewable energy goals and facilitate the smooth, reliable and efficient transfer of green power from region to region, for $1.8 million, consisting of $0.8 million in cash and $1.0 million in AMSC common stock. On January 6, 2011 and May 20, 2011, the Company increased its minority position in Tres Amigas by investing an additional $1.8 million in cash on each date. As of September 30, 2012, the Company holds a 26% ownership interest in Tres Amigas.

[0001193125-12-454266:notes:65]
The Company’s investment in Tres Amigas is included in other assets on the unaudited condensed consolidated balance sheet and the equity in undistributed losses of Tres Amigas is included in other income, net, on the unaudited condensed consolidated statements of operations.

[0001193125-12-454266:notes:66]
The net investment activity for the six months ended September 30, 2012 is as follows (in thousands):

[0001193125-12-454266:notes:67]
| Balance at April 1, 2012 | $ | 3,859 |
| Minority interest in net losses |  | (476) |
| Balance at September 30, 2012 | $ | 3,383 |

[0001193125-12-454266:notes:68]
[same as prior period, unchanged from 0001193125-12-334096:notes:73]

[0001193125-12-454266:notes:69]
On August 12, 2010, the Company acquired (through its Austrian subsidiary), a minority ownership position in Blade Dynamics Ltd. (“Blade Dynamics”), a designer and manufacturer of advanced wind turbine blades based on proprietary materials and structural technologies, for $8.0 million in cash.  As of September 30, 2012, the Company holds a 24% ownership interest in Blade Dynamics.

[0001193125-12-454266:notes:70]
The Company has determined that Blade Dynamics is a variable interest entity (“VIE”) and that the Company is not the primary beneficiary of the VIE. Therefore, the Company has not consolidated Blade Dynamics as of September 30, 2012. The investment is carried at the acquisition cost, plus the Company’s equity in undistributed earnings or losses. The Company’s maximum exposure to loss is limited to the Company’s recorded investment in this VIE. The Company’s investment in Blade Dynamics is included in other assets on the unaudited condensed consolidated balance sheet and the equity in undistributed losses of Blade Dynamics is included in other income, net, on the unaudited condensed consolidated statements of operations.

[0001193125-12-454266:notes:71]
| Balance at April 1, 2012 | $ | 6,083 |
| Minority interest in net losses |  | (1,018) |
| Net foreign exchange rate impact |  | (232) |
| Balance at September 30, 2012 | $ | 4,833 |


## us-gaap:FairValueAssetsAndLiabilitiesMeasuredOnRecurringBasisGainLossIncludedInEarningsTextBlock

[0001193125-12-454266:notes:72]
|  |  | Total |  | Quoted Prices in |  | Significant Other |  | Significant |
|  |  | Carrying |  | Active Markets |  | Observable Inputs |  | Unobservable Inputs |
|  |  | Value |  | (Level 1) |  | (Level 2) |  | (Level 3) |
| September 30, 2012: |  |  |  |  |  |  |  |  |
| Assets: |  |  |  |  |  |  |  |  |
| Cash equivalents | $ | 30,400 | $ | 30,400 | $ | - | $ | - |
| Short-term commercial paper |  | 5,220 |  | - |  | 5,220 |  | - |
| Liabilities: |  |  |  |  |  |  |  |  |
| Derivative liability | $ | 2,763 | $ | - | $ | - | $ | 2,763 |
| Warrants |  | 7,517 |  | - |  | - |  | 7,517 |
|  |  | Total |  | Quoted Prices in |  | Significant Other |  | Significant |
|  |  | Carrying |  | Active Markets |  | Observable Inputs |  | Unobservable Inputs |
|  |  | Value |  | (Level 1) |  | (Level 2) |  | (Level 3) |
| March 31, 2012: |  |  |  |  |  |  |  |  |
| Assets: |  |  |  |  |  |  |  |  |
| Cash equivalents | $ | 23,485 | $ | 23,485 | $ | - | $ | - |
| Short-term commercial paper |  | 5,304 |  | - |  | 5,304 |  | - |


## us-gaap:FairValueByBalanceSheetGroupingTextBlock

[0001193125-12-454266:notes:73]
|  |  | September 30, |  | June 30, |  | April 4, |  |
|  |  | 2012 |  | 2012 |  | 2012 |  |
| Expected Volatility |  | 70.0 | % | 71.0 | % | 75.0 | % |
| Risk Free Rate |  | 0.23 | % | 0.33 | % | 0.44 | % |
| Bond Yield |  | 15.0 | % | 16.0 | % | 15.0 | % |
| Recovery Rate |  | 30.0 | % | 30.0 | % | 30.0 | % |
| Redeemable |  | yes |  | yes |  | yes |  |
| Total Time (years) |  | 2.01 |  | 2.28 |  | 2.5 |  |
| Dilution Effect |  | yes |  | yes |  | yes |  |
| Indicated Percent of Par |  | 108.0 | % | 121.0 | % | 117.0 | % |
| Fair Value | $ | 2.8 million | $ | 4.5 million | $ | 3.8 million |  |


## us-gaap:FairValueDisclosuresTextBlock

[0001193125-12-454266:notes:74]
[same as prior period, unchanged from 0001193125-12-334096:notes:79]

[0001193125-12-454266:notes:75]
In January 2010, the Financial Accounting Standards Board (“FASB”) issued guidance related to disclosures of fair value measurements. The guidance requires gross presentation of activity within the Level 3 measurement roll-forward and details of transfers in and out of Level 1 and 2 measurements. It also clarifies two existing disclosure requirements on the level of disaggregation of fair value measurements and disclosures on inputs and valuation techniques. A change in the hierarchy of an investment from its current level will be reflected in the period during which the pricing methodology of such investment changes. Disclosure of the transfer of securities from Level 1 to Level 2 or Level 3 will be made in the event that the related security is significant to total cash and investments. The Company did not have any transfers of assets and liabilities between Level 1, Level 2 and Level 3 of the fair value measurement hierarchy during the three months ended September 30, 2012.

[0001193125-12-454266:notes:76]
[same as prior period, unchanged from 0001193125-12-334096:notes:81]

[0001193125-12-454266:notes:77]
| Level 1 - | Inputs are unadjusted quoted prices in active markets for identical assets or liabilities that the Company has the ability to access at the measurement date. |
| Level 2 - | Inputs include quoted prices for similar assets and liabilities in active markets, quoted prices for identical or similar assets or liabilities in markets that are not active, inputs other than quoted prices that are observable for the asset or liability, and inputs that are derived principally from or corroborated by observable market data by correlation or other means (market corroborated inputs). |
| Level 3 - | Unobservable inputs that reflect the Company’s assumptions that market participants would use in pricing the asset or liability. The Company develops these inputs based on the best information available, including its own data. |

[0001193125-12-454266:notes:78]
A financial asset’s or liability’s classification within the hierarchy is determined based on the lowest level input that is significant to the fair value measurement.

[0001193125-12-454266:notes:79]
The following table provides the assets carried at fair value, measured as of September 30, 2012 and March 31, 2012 (in thousands):

[0001193125-12-454266:notes:80]
The table below reflects the activity for the Company’s major classes of liabilities measured at fair value for the period ended September 30, 2012 (in thousands):

[0001193125-12-454266:notes:81]
[same as prior period, unchanged from 0001193125-12-334096:notes:88]

[0001193125-12-454266:notes:82]
[same as prior period, unchanged from 0001193125-12-334096:notes:89]

[0001193125-12-454266:notes:83]
Cash equivalents consist of highly liquid instruments with maturities of three months or less that are regarded as high quality, low risk investments and are measured using such inputs as quoted prices, and are classified within Level 1 of the valuation hierarchy.  Cash equivalents consist principally of certificates of deposits and money market accounts.

[0001193125-12-454266:notes:84]
[same as prior period, unchanged from 0001193125-12-334096:notes:91]

[0001193125-12-454266:notes:85]
Marketable securities consist primarily of government-backed securities and commercial paper and are measured using such inputs as quoted prices for identical or similar assets in markets that are not active, inputs other than quoted prices that are observable for the asset (for example, interest rates and yield curves observable at commonly quoted intervals), and inputs that are derived principally from or corroborated by observable market data by correlation or other means, and are classified within Level 2 of the valuation hierarchy. The Company’s marketable securities generally have maturities of greater than three months from original purchase date but less than twelve months from the date of the balance sheet.  The Company determines the appropriate classification of its marketable securities at the time of purchase and re-evaluates such classification as of each balance sheet date. All marketable securities are considered available-for-sale and are carried at fair value. The Company periodically reviews the realizability of each short-term and long-term marketable security when impairment indicators exist with respect to the security. If an other-than-temporary impairment of value of the security exists, the carrying value of the security is written down to its estimated fair value.

[0001193125-12-454266:notes:86]
[same as prior period, unchanged from 0001193125-12-334096:notes:93]

[0001193125-12-454266:notes:87]
The Company has identified all of the derivatives (“Derivative Liability”) associated with the Convertible Notes which include holder change of control redemption rights, issuer optional redemption rights, sale redemption rights and a feature to convert the Convertible Notes into equity at the holder’s option. The Derivative Liability is subject to revaluation at each balance sheet date, and any change in fair value will be recorded as a change in fair value in other income (expense) until the earlier of its exercise or expiration. The Company relies on assumptions in a lattice model to determine the fair value of Derivative Liability. The Company has appropriately valued the Derivative Liability within Level 3 of the valuation hierarchy.  See Note 11, “Debt”, for discussion on the Convertible Notes, Derivative Liability and valuation assumptions used.

[0001193125-12-454266:notes:88]
[same as prior period, unchanged from 0001193125-12-334096:notes:95]

[0001193125-12-454266:notes:89]
Warrants were issued in conjunction with the Convertible Notes and the Term Loan. See Note 11, “Debt”, for additional information on warrants.  These warrants are subject to revaluation at each balance sheet date, and any change in fair value will be recorded as a change in fair value in other income (expense) until the earlier of their exercise or expiration.

[0001193125-12-454266:notes:90]
The Company relies on various assumptions to determine the fair value of warrants. The Company has appropriately valued the warrants within Level 3 of the valuation hierarchy.  See Note 12, “Warrants and Derivative Liabilities”, for a discussion of the warrants and the valuation assumptions used.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001193125-12-454266:notes:91]
9. Income Taxes

[0001193125-12-454266:notes:92]
For the three and six months ended September 30, 2012, the Company recorded income tax expense of $0.1 million and an income tax benefit of $0.8 million, respectively. For the three and six months ended September 30, 2011, the Company recorded income tax expense of $0.9 million and $1.1 million, respectively.  The income tax expense for the three months ended September 30, 2012, was primarily due to income taxes in foreign jurisdictions. The income tax benefit for the six months ended September 30, 2012 was primarily due to a refund of income taxes paid in China. The Company has provided a valuation allowance against all existing and newly created deferred tax assets as of September 30, 2012, as it is more likely than not that its deferred tax assets are not currently realizable due to the net operating losses incurred by the Company since its inception.


## us-gaap:InventoryDisclosureTextBlock

[0001193125-12-454266:notes:93]
[same as prior period, unchanged from 0001193125-12-334096:notes:100]

[0001193125-12-454266:notes:94]
The components of inventory at September 30, 2012 and March 31, 2012 are as follows (in thousands):

[0001193125-12-454266:notes:95]
|  |  | September 30, |  |  | March 31, |
|  |  | 2012 |  |  | 2012 |
| Raw materials | $ | 8,138 |  | $ | 9,962 |
| Work-in-process |  | 4,263 |  |  | 2,390 |
| Finished goods |  | 15,374 |  |  | 14,438 |
| Deferred program costs |  | 1,899 |  |  | 2,466 |
| Net inventory | $ | 29,674 |  | $ | 29,256 |

[0001193125-12-454266:notes:96]
For the three and six months ended September 30, 2012, the Company recorded an inventory write-down of approximately $0.2 million and $0.4 million respectively based on evaluating its ending inventory on hand for excess quantities and obsolescence.

[0001193125-12-454266:notes:97]
Deferred program costs as of September 30, 2012 and March 31, 2012 primarily represent costs incurred on D-VAR turnkey projects and programs accounted for under contract accounting where the Company needs to complete development programs before revenue and costs will be recognized, respectively.


## us-gaap:LoansNotesTradeAndOtherReceivablesDisclosureTextBlock

[0001193125-12-454266:notes:98]
[same as prior period, unchanged from 0001193125-12-334096:notes:105]

[0001193125-12-454266:notes:99]
Accounts receivable at September 30, 2012 and March 31, 2012 consisted of the following (in thousands):

[0001193125-12-454266:notes:100]
|  |  | September 30, |  |  | March 31, |
|  |  | 2012 |  |  | 2012 |
| Accounts receivable (billed) | $ | 12,307 |  | $ | 16,240 |
| Accounts receivable (unbilled) |  | 2,927 |  |  | 2,811 |
| Less: Allowance for doubtful accounts |  | (10) |  |  | (52) |
| Accounts receivable, net | $ | 15,224 |  | $ | 18,999 |


## us-gaap:NewAccountingPronouncementsAndChangesInAccountingPrinciplesTextBlock

[0001193125-12-454266:notes:101]
16. Recent Accounting Pronouncements

[0001193125-12-454266:notes:102]
In June 2011, the FASB issued Accounting Standards Update (ASU) No. 2011-05, Comprehensive Income (Topic 220): Presentation of Comprehensive Income. ASU 2011-05 requires entities to present net income and other comprehensive income in either a single continuous statement or in two separate, but consecutive, statements of net income and other comprehensive income. ASU 2011-05 is effective for fiscal years and interim periods beginning after December 15, 2011. The Company early adopted ASU 2011-05 and it did not have a material impact on the Company’s consolidated results of operations, financial condition, or cash flows.

[0001193125-12-454266:notes:103]
In September 2011, the FASB issued Accounting Standards Update No. 2011-08, Intangibles — Goodwill and Other (Topic 350). ASU 2011-08 allows entities to first assess qualitatively whether it is necessary to perform the two-step goodwill impairment test. If an entity believes, as a result of its qualitative assessment, that it is more likely than not that the fair value of a reporting unit is less than its carrying amount, the quantitative two-step goodwill impairment test is required. An entity has the unconditional option to bypass the qualitative assessment and proceed directly to performing the first step of the goodwill impairment test. ASU 2011-08 is effective for our first quarter of fiscal 2013 but is eligible for early adoption. The Company does not believe adoption of this standard will have an impact on its consolidated results of operations, financial condition, or cash flows.

[0001193125-12-454266:notes:104]
In December 2011, the FASB issued Accounting Standards Update No. 2011-11, Balance Sheet (Topic 210)-Disclosures about Offsetting Assets and Liabilities (ASU 2011-11). The update requires entities to disclose information about offsetting and related arrangements of financial instruments and derivative instruments. ASU 2011-11 is effective for our first quarter of fiscal 2014. The Company is currently evaluating the impact of adopting ASU 2011-11, but currently does not believe there will be a significant impact on its consolidated results of operations, financial condition, or cash flows.

[0001193125-12-454266:notes:105]
The Company does not believe that other recently issued accounting pronouncements will have a material impact on its financial statements.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001193125-12-454266:notes:106]
10. Restructuring

[0001193125-12-454266:notes:107]
The Company accounts for charges resulting from operational restructuring actions in accordance with ASC Topic 420, Exit or Disposal Cost Obligations (“ASC 420”) and ASC Topic 712, Compensation—Nonretirement Postemployment Benefits (“ASC 712”). In accounting for these obligations, the Company is required to make assumptions related to the amounts of employee severance, benefits, and related costs and the time period over which leased facilities will remain vacant, sublease terms, sublease rates and discount rates. Estimates and assumptions are based on the best information available at the time the obligation arises. These estimates are reviewed and revised as facts and circumstances dictate; changes in these estimates could have a material effect on the amount accrued on the consolidated balance sheet.

[0001193125-12-454266:notes:108]
During the year ended March 31, 2012, the Company initiated restructuring activities in order to reorganize its global operations, streamline various functions of the business, and reduce its global workforce to better reflect the demand for its products. These activities resulted in the reduction of its global workforce by approximately 50%. During the six months ended September 30, 2012, the Company incurred restructuring costs of $0.1 million. These additional charges were paid as of September 30, 2012 and the remaining balance of accrued restructuring is expected to be paid through March 2013.

[0001193125-12-454266:notes:109]
[same as prior period, unchanged from 0001193125-12-334096:notes:120]

[0001193125-12-454266:notes:110]
|  |  | Severance pay |  | Facility |  |  |
|  |  | and benefits |  | exit costs |  | Total |
| Accrued restructuring balance at April 1, 2012 | $ | 680 | $ | 294 | $ | 974 |
| Charges to operations |  | 182 |  | (39) |  | 143 |
| Cash payments |  | (560) |  | (255) |  | (815) |
| Accrued restructuring balance at September 30, 2012 | $ | 302 | $ | (0) | $ | 302 |

[0001193125-12-454266:notes:111]
All restructuring charges discussed above are included within restructuring and impairments in the Company’s unaudited condensed consolidated statements of operations.  The Company includes accrued restructuring within accounts payable and accrued expenses in the unaudited condensed consolidated balance sheets.


## us-gaap:ScheduleOfDerivativeInstrumentsTextBlock

[0001193125-12-454266:notes:112]
|  |  | September 30, |  | June 30, |  | June 5, |  |
|  |  | 2012 |  | 2012 |  | 2012 |  |
| Risk-free interest rate |  | 0.64 | % | 0.80 | % | 0.77 | % |
| Expected annual dividend yield |  | 0.0 | % | 0.0 | % | 0.0 | % |
| Expected volatility |  | 81.18 | % | 80.32 | % | 79.90 | % |
| Term |  | 5.18 |  | 5.44 years |  | 5.5 |  |
| Fair Value | $ | 0.4 million | $ | 0.5 million | $ | 0.4 million |  |

[0001193125-12-454266:notes:113]
|  |  | September 30, |  | June 30, |  | April 4, |  |
|  |  | 2012 |  | 2012 |  | 2012 |  |
| Risk-free interest rate |  | 0.63 | % | 0.77 | % | 1.19 | % |
| Expected annual dividend yield |  | 0.0 | % | 0.0 | % | 0.0 | % |
| Expected volatility |  | 80.9 | % | 80.8 | % | 80.0 | % |
| Term |  | 5.01 years |  | 5.28 years |  | 5.5 years |  |
| Fair Value | $ | 7.1 million | $ | 8.6 million | $ | 7.0 million |  |


## us-gaap:ScheduleOfRevenueByMajorCustomersByReportingSegmentsTableTextBlock

[0001193125-12-454266:notes:114]
|  | Three months ended |  |  | Six months ended |  |
|  | September 30, |  |  | September 30, |  |
|  | 2012 |  | 2011 |  |  | 2012 |  | 2011 |  |
| Beijing JINGCHENG New Energy Co., Ltd. | 26 | % | <10 | % |  | 22 | % | <10 | % |
| INOX Wind Limited | 19 | % | 24 | % |  | 17 | % | 17 | % |
| Karara Mining Ltd. | <10 | % | - | % |  | 13 | % | - | % |
| Doosan Heavy Industries & Construction Co Ltd. | <10 | % | 17 | % |  | <10 | % | 16 | % |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001193125-12-454266:notes:115]
15. Business Segments

[0001193125-12-454266:notes:116]
The Company reported its financial results in two reportable business segments: Wind and Grid.

[0001193125-12-454266:notes:117]
Through its Windtec Solutions, the Wind business segment enables manufacturers to field wind turbines with exceptional power output, reliability and affordability.  The Company supplies advanced power electronics and control systems, licenses its highly engineered wind turbine designs, and provides extensive customer support services to wind turbine manufactures. Its design portfolio includes a broad range of drive trains and power ratings up to 10 megawatts.  It provides a broad range of power electronics and software based control systems that are highly integrated and redesigned for optimized performance, efficiency, and grid compatibility.

[0001193125-12-454266:notes:118]
Through its Gridtec Solutions, the Grid business segment enables electric utilities and renewable energy project developers to connect, transmit and distribute power with exceptional efficiency, reliability and affordability.  The Company provides transmission planning services that allow it to identify power grid congestion, poor power quality and other risks, which help the Company determine how its solutions can improve network performance.  These services often lead to sales of grid interconnection solutions for wind farms and solar power plants, power quality systems and transmission and distribution cable systems.

[0001193125-12-454266:notes:119]
[same as prior period, unchanged from 0001193125-12-334096:notes:128]

[0001193125-12-454266:notes:120]
The accounting policies of the business segments are the same as those for the consolidated Company.  The Company’s business segments have been determined in accordance with the Company’s internal management structure, which is organized based on operating activities.  The Company evaluates performance based upon several factors, of which the primary financial measures are segment revenues and segment operating (loss) income. The disaggregated financial results of the segments reflect allocation of certain functional expense categories consistent with the basis and manner in which Company management internally disaggregates financial information for the purpose of assisting in making internal operating decisions. In addition, certain corporate expenses which the Company does not believe are specifically attributable or allocable to either of the two business segments have been excluded from the segment operating income.

[0001193125-12-454266:notes:121]
Unallocated corporate expenses primarily consist of stock-based compensation expense of $2.0 million and $4.0 million for the three and six months ended September 30, 2012, respectively.  Unallocated corporate expenses primarily consist of the write-off of an advance payment to The Switch Engineering Oy of $20.6 million, which constituted a break-up fee resulting from the termination of the planned acquisition of The Switch due to adverse market conditions, and restructuring and impairment charges of $4.3 million for the three and six months ended September 30, 2011 and stock-based compensation expense of $2.1 million and $5.6 million for the three and six months ended September 30, 2011, respectively.

[0001193125-12-454266:notes:122]
[same as prior period, unchanged from 0001193125-12-334096:notes:131]

[0001193125-12-454266:notes:123]
The following table sets forth customers who represented 10% or more of the Company’s total revenues for the three and six months ended September 30, 2012 and 2011:


## us-gaap:SubsequentEventsTextBlock

[0001193125-12-454266:notes:124]
17. Subsequent Events

[0001193125-12-454266:notes:125]
On May 16, 2012, the Company entered into an agreement with one of its vendors to settle certain of its adverse purchase commitments.  The agreement was amended on November 6, 2012 (as amended, the “Settlement Agreement”).  In conjunction with the Settlement Agreement, the Company agreed to pay the vendor approximately €2.2 million (the “Settlement Amount”). Under the Settlement Agreement, the Company has the option, at its sole discretion, to pay the settlement amount in cash, shares of the Company’s common stock, or a combination of cash and common stock.  Accordingly, the Company plans to issue 765,301 shares of common stock to the vendor and has agreed to file a registration statement on Form S-3 to register the vendor’s resale of such shares of common stock.  The net proceeds from the vendor’s resale of the shares of common stock during a specified period plus any other cash payments made by the Company subsequent to the date of the Settlement Agreement will be less than the Settlement Amount, the Company agreed to make an additional payment equal to the shortfall in cash to the vendor no later than December 31, 2012.  As security for the Company’s obligations, the Company has provided the vendor with a letter of credit in the amount of approximately €2.2 million with an expiration of December 31, 2012. The letter of credit is secured with cash collateral of approximately $3.0 million.
