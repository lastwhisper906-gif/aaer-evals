# AMSC notes — 0001437749-22-018630


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0001437749-22-018630:notes:1]
[same as prior period, unchanged from 0001437749-22-002208:notes:1]

[0001437749-22-018630:notes:2]
[same as prior period, unchanged from 0001437749-22-002208:notes:2]

[0001437749-22-018630:notes:3]
[same as prior period, unchanged from 0001437749-22-002208:notes:3]

[0001437749-22-018630:notes:4]
These unaudited condensed consolidated financial statements of the Company have been prepared on a going concern basis in accordance with United States generally accepted accounting principles (“GAAP”) and the Securities and Exchange Commission’s (“SEC”) instructions to Form 10-Q. The going concern basis of presentation assumes that the Company will continue operations and will be able to realize its assets and discharge its liabilities and commitments in the normal course of business. Certain information and footnote disclosures normally included in the financial statements prepared in accordance with GAAP have been condensed or omitted pursuant to those instructions. The year-end condensed balance sheet data was derived from audited financial statements but does not include all disclosures required by GAAP. The unaudited condensed consolidated financial statements, in the opinion of management, reflect all adjustments (consisting of normal recurring adjustments) necessary for a fair statement of the results for the interim periods ended  June 30, 2022 and 2021 and the financial position at  June 30, 2022; however, these results are not necessarily indicative of results which  may be expected for the full year. The interim condensed consolidated financial statements, and notes thereto, should be read in conjunction with the audited consolidated financial statements for the year ended  March 31, 2022, and notes thereto, included in the Company’s Annual Report on Form 10-K for the year ended  March 31, 2022 filed with the SEC on  June 1, 2022.

[0001437749-22-018630:notes:5]
[same as prior period, unchanged from 0001437749-22-002208:notes:5]

[0001437749-22-018630:notes:6]
The Company has historically experienced recurring operating losses and as of  June 30, 2022, the Company had an accumulated deficit of $1,029 million. In addition, the Company has historically experienced recurring negative operating cash flows.  At  June 30, 2022, the Company had cash and cash equivalents of $33.4 million. Cash used in operations for the three months ended  June 30, 2022 was $5.9 million.

[0001437749-22-018630:notes:7]
[same as prior period, unchanged from 0001437749-22-002208:notes:7]

[0001437749-22-018630:notes:8]
In  March 2020, the World Health Organization declared the disease caused by the novel coronavirus (“COVID-19“) to be a pandemic. COVID-19 has spread throughout the globe, including in the Commonwealth of Massachusetts where the Company’s headquarters are located, and in other areas where the Company has business operations. In response to the pandemic, the Company has followed the guidelines of the U.S. Centers for Disease Control and Prevention (“CDC”) and applicable state government authorities to protect the health and safety of the Company’s employees, families, suppliers, customers and communities. While these existing measures and, COVID-19 generally, have not materially disrupted the Company’s business to date, any future actions necessitated by the COVID-19 pandemic  may result in disruption to the Company’s business.

[0001437749-22-018630:notes:9]
The COVID-19 pandemic continues to rapidly evolve. The Company is experiencing substantial inflationary pressure in its supply chain, some delays in sourcing materials needed for its products and some production disruption resulting from higher than typical employee absenteeism, all of which have increased the Company’s cost of revenues and decreased gross margin. The extent to which the pandemic impacts the Company’s business, liquidity, results of operations and financial condition will depend on future developments, which are highly uncertain and cannot be predicted with confidence.  Changes in macroeconomic conditions arising from the COVID-19 pandemic or for other reasons, such as the ongoing war between Russia and Ukraine, including inflation, labor force availability, sourcing, material delays and global supply chain disruptions could have a material adverse effect on the Company’s business, financial condition and results of operation.

[0001437749-22-018630:notes:10]
The Company believes that based on the information presented above and its quarterly management assessment, it has sufficient liquidity to fund its operations and capital expenditures for the next twelve months following the issuance of the financial statements for the three months ended  June 30, 2022. The Company’s liquidity is highly dependent on its ability to increase revenues, its ability to control its operating costs, and its ability to raise additional capital, if necessary. The impact of the COVID-19 pandemic and other sources of instability, including the war between Russia and Ukraine, on the global financing markets  may reduce the Company's ability to raise additional capital, if necessary, which could negatively impact the Company's liquidity.  There can be no assurance that the Company will be able to continue to raise additional capital, on favorable terms or at all, from other sources or execute on any other means of improving liquidity described above.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001437749-22-018630:notes:11]
[same as prior period, unchanged from 0001437749-22-002208:notes:12]

[0001437749-22-018630:notes:12]
[same as prior period, unchanged from 0001437749-22-002208:notes:13]

[0001437749-22-018630:notes:13]
On  May 6, 2021, the Company entered into a Purchase and Sale Agreement (the "Real Property Purchase Agreement") and a Stock Purchase Agreement (the "Neeltran Stock Purchase Agreement") with the selling equity holders named therein. Also on  May 6, 2021, pursuant to the terms of the Real Property Purchase Agreement, the Company's wholly-owned Connecticut limited liability company, AMSC Husky LLC ("AMSC Husky"), purchased the real property that serves as Neeltran's headquarters for $4.3 million, of which (a) $2.4 million was paid in immediately available funds by AMSC Husky to the owners of such real property, and (b) $1.9 million was paid directly to TD Bank as full payment for the outstanding indebtedness secured by the mortgage on such real property.

[0001437749-22-018630:notes:14]
Pursuant to the terms of the Neeltran Stock Purchase Agreement, the Company purchased all of the issued and outstanding shares of capital stock of Neeltran, Inc., a Connecticut corporation ("Neeltran") and Neeltran International, Inc., a Connecticut corporation ("International") for $1.0 million in cash and 301,556 shares of the Company's common stock, $.01 par value per share ("AMSC Shares"), that were paid and issued, respectively, to the Neeltran selling stockholders. The Company also paid $1.1 million to International selling stockholders to pay off previous loans made by them to Neeltran.

[0001437749-22-018630:notes:15]
Additionally, the Company paid approximately $7.6 million, including $1.9 million of indebtedness secured by the mortgage on the real property as described above, directly to Neeltran lenders at closing to extinguish outstanding Neeltran indebtedness to third parties. The total purchase price of $16.4 million includes cash paid, the fair value of the AMSC Shares issued at closing and the debt payoff on behalf of the sellers as follows (in millions):

[0001437749-22-018630:notes:16]
[same as prior period, unchanged from 0001437749-22-002208:notes:16]

[0001437749-22-018630:notes:17]
The Neeltran Acquisition completed by the Company during the fiscal year ended  March 31, 2022 has been accounted for under the purchase method of accounting in accordance with ASC 805, Business Combinations. The Company allocated the purchase price to the assets acquired and liabilities assumed at their estimated fair values as of the date of Neeltran Acquisition. The excess of the purchase price paid by the Company over the estimated fair value of net assets acquired has been recorded as goodwill. As Neeltran was previously a private company, the adoption of Accounting Standards Codification 842 ("ASC 842") was completed as part of the Neeltran Acquisition. See Note 15, "Leases" for further details. Neeltran had previously adopted Accounting Standards Codification 606, Revenue from Contracts with Customers ("ASC 606") as part of prior year audited financial statements.

[0001437749-22-018630:notes:18]
[same as prior period, unchanged from 0001437749-22-002208:notes:18]

[0001437749-22-018630:notes:19]
[same as prior period, unchanged from 0001437749-22-002208:notes:19]

[0001437749-22-018630:notes:20]
Inventory include
     s a $0.6 million adjustment to step up the inventory balance to fair value consistent with the purchase price allocation. The fair value was based on the estimated selling price of the inventory, less the remaining manufacturing and selling cost and a normal profit margin on those manufacturing and selling efforts. The inventory step up adjustment increased cost of revenue by $0.6 million in the twelve month period ended  March 31, 2022 as the inventory was sold. This increase is not reflected in the pro forma condensed combined statements of operations because it does not have a continuing impact beyond the
     first year.

[0001437749-22-018630:notes:21]
[same as prior period, unchanged from 0001437749-22-002208:notes:21]

[0001437749-22-018630:notes:22]
[same as prior period, unchanged from 0001437749-22-002208:notes:22]

[0001437749-22-018630:notes:23]
[same as prior period, unchanged from 0001437749-22-002208:notes:23]

[0001437749-22-018630:notes:24]
The goodwill represents the value associated with the acquired workforce and expected synergies related to the business combinations of the two companies. Goodwill resulting from the Neeltran Acquisition was assigned to the Company's Grid business segment. Goodwill recognized in the Neeltran Acquisition is not deductible for tax purposes. The Company has finalized its purchase price allocation for the Neeltran Acquisition, and there were no changes to the net assets and goodwill recorded by the Company as of  May 6, 2021.

[0001437749-22-018630:notes:25]
[same as prior period, unchanged from 0001437749-22-002208:notes:41]

[0001437749-22-018630:notes:26]
The unaudited pro forma condensed consolidated statement of operations for the
        three months ended
         June 30, 2022 and 
        2021 is presented as if the Neeltran Acquisition had occurred on
         April 1, 2021.

[0001437749-22-018630:notes:27]
|  | Three Months Ended June 30, |
|  | 2022 | 2021 |
| Revenues | $ 22,679 | $ 28,250 |
| Operating loss | (8,883) | (7,384) |
| Net loss | $ (8,724) | $ (7,693) |
| Net loss per common share |  |  |
| Basic | $ (0.32) | $ (0.29) |
| Diluted | $ (0.32) | $ (0.29) |
| Shares - basic | 27,560 | 26,948 |
| Shares - diluted | 27,560 | 26,948 |

[0001437749-22-018630:notes:28]
The pro forma amounts include the historical operating results of the Company, and Neeltran, with appropriate adjustments that give effect to acquisition related costs, income taxes, intangible amortization resulting from the Neeltran Acquisition and certain conforming accounting policies of the Company. The pro forma amounts are not necessarily indicative of the operating results that would have occurred if the Neeltran Acquisition and related transactions had been completed at the beginning of the applicable periods presented. In addition, the pro forma amounts are not necessarily indicative of operating results in future periods.

[0001437749-22-018630:notes:29]
Acquisition of NEPSI

[0001437749-22-018630:notes:30]
[same as prior period, unchanged from 0001437749-22-002208:notes:27]

[0001437749-22-018630:notes:31]
[same as prior period, unchanged from 0001437749-22-002208:notes:28]

[0001437749-22-018630:notes:32]
The NEPSI Acquisition completed by the Company during the fiscal year ended  March 31, 2021 has been accounted for under the purchase method of accounting in accordance with ASC 805, Business Combinations. The Company allocated the purchase price to the assets acquired and liabilities assumed at their estimated fair values as of the date of NEPSI Acquisition. The excess of the purchase price paid by the Company over the estimated fair value of net assets acquired has been recorded as goodwill.  As NEPSI was previously a private company, the adoption of ASC 606 was completed as part of the NEPSI Acquisition.  See Note 3, "Revenue Recognition" for further details.  There were no leases acquired and the NEPSI Acquisition had no impact to the Company's reporting under ASC 842.

[0001437749-22-018630:notes:33]
[same as prior period, unchanged from 0001437749-22-002208:notes:30]

[0001437749-22-018630:notes:34]
[same as prior period, unchanged from 0001437749-22-002208:notes:31]

[0001437749-22-018630:notes:35]
[same as prior period, unchanged from 0001437749-22-002208:notes:32]

[0001437749-22-018630:notes:36]
The fair value of the contingent consideration was determined using a Monte Carlo model and is accounted for as a derivative liability which is revalued at the fair value determined at each subsequent balance sheet date until the contingencies are resolved and the shares to be issued are determined, with the change in fair value recorded in the current period operating loss or (income).  See Note 13, "Contingent Consideration" for further details and a summary of key assumptions used to determine fair value in each period.

[0001437749-22-018630:notes:37]
[same as prior period, unchanged from 0001437749-22-002208:notes:34]

[0001437749-22-018630:notes:38]
[same as prior period, unchanged from 0001437749-22-002208:notes:35]

[0001437749-22-018630:notes:39]
[same as prior period, unchanged from 0001437749-22-002208:notes:36]

[0001437749-22-018630:notes:40]
[same as prior period, unchanged from 0001437749-22-002208:notes:37]

[0001437749-22-018630:notes:41]
[same as prior period, unchanged from 0001437749-22-002208:notes:38]

[0001437749-22-018630:notes:42]
[same as prior period, unchanged from 0001437749-22-002208:notes:39]

[0001437749-22-018630:notes:43]
[same as prior period, unchanged from 0001437749-22-002208:notes:40]


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001437749-22-018630:notes:44]
[same as prior period, unchanged from 0001437749-22-002208:notes:45]

[0001437749-22-018630:notes:45]
The Company’s revenues in its Grid business segment are derived primarily through enabling the transmission and distribution of power, providing planning services that allow it to identify power grid needs and risks, and developing ship protection systems for the U.S. Navy. The Company’s revenues in its Wind business segment are derived primarily through supplying advanced power electronics and control systems, licensing its highly engineered wind turbine designs, and providing extensive customer support services to wind turbine manufacturers. The Company records revenue based on a five-step model in accordance with ASC 606. For its customer contracts, the Company identifies the performance obligations, determines the transaction price, allocates the contract transaction price to the performance obligations, and recognizes the revenue when (or as) control of goods or services is transferred to the customer. In the three months ended  June 30, 2022 and 2021, 70% and 78% of revenue, respectively, was recognized at the point in time when control transferred to the customer, with the remainder being recognized over time.

[0001437749-22-018630:notes:46]
[same as prior period, unchanged from 0001437749-22-002208:notes:47]

[0001437749-22-018630:notes:47]
The Company's equipment and system product line includes certain contracts which do not meet the requirements of an exchange transaction and therefore do not fall within the scope of ASC 606.  As these non-exchange transaction contracts are considered grant revenue and do not fall within any specific accounting literature, the Company follows guidance within ASC 606 by analogy to recognize grant revenue over time.  The Company recorded no grant revenue in the three months ended  June 30, 2022 and $0.5 million in grant revenue in the three months ended  June 30, 2021.

[0001437749-22-018630:notes:48]
In the Company's service and technology development product line, there are several different types of transactions and each begins with a contract with a customer that summarizes each product sold to a customer, which typically represent distinct performance obligations. The technology development transactions are primarily for activities that have no alternative use and for which a profit can be expected throughout the life of the contract. In these cases, the revenue is recognized over time, but in the instances where a reasonable profit margin cannot be assured throughout the entire contract, the revenue is recognized at a point in time. Each contract's transaction price is allocated to each distinct performance obligation using the respective standalone selling price which is determined primarily using the cost-plus expected margin approach. The ongoing service transactions are for service contracts that provide benefit to the customer simultaneously as the Company performs its obligations, and therefore this revenue is recognized ratably over time throughout the effective period of these contracts. The transaction prices on these contracts are allocated based on an adjusted market approach which is reassessed annually for reasonableness. The field service transactions include contracts for delivery of goods and completion of services made at the customer's requests, which are not deemed satisfied until the work has been completed and/or the requested goods have been delivered, so all of this revenue is recognized at the point in time when the control changes, and at allocated prices based on the adjusted market approach driven by standard price lists. The royalty transactions are related to certain contract terms on transactions in the Company's equipment and systems product line based on activity as specified in the contracts. The transaction prices of these agreements are calculated based on an adjusted market approach as specified in the contract. The Company reports royalty revenue for usage-based royalties when the sales have occurred. In circumstances when collectability is not assured and a contract does not exist under ASC 606, revenue is deferred until a non-refundable payment has been received for substantially all the amount that is due and there are no further remaining performance obligations.

[0001437749-22-018630:notes:49]
[same as prior period, unchanged from 0001437749-22-002208:notes:50]

[0001437749-22-018630:notes:50]
[same as prior period, unchanged from 0001437749-22-002208:notes:51]

[0001437749-22-018630:notes:51]
[same as prior period, unchanged from 0001437749-22-002208:notes:52]

[0001437749-22-018630:notes:52]
[same as prior period, unchanged from 0001437749-22-002208:notes:53]

[0001437749-22-018630:notes:53]
[same as prior period, unchanged from 0001437749-22-002208:notes:54]

[0001437749-22-018630:notes:54]
[same as prior period, unchanged from 0001437749-22-002208:notes:55]

[0001437749-22-018630:notes:55]
|  |  | Three Months Ended June 30, 2022 |  |
| Product Line: |  | Grid |  |  | Wind |  |
| Equipment and systems |  | $ | 18,077 |  |  | $ | 1,973 |  |
| Services and technology development |  |  | 1,753 |  |  |  | 877 |  |
| Total |  | $ | 19,829 |  |  | $ | 2,850 |  |
| Region: |  |  |  |  |  |  |  |  |
| Americas |  | $ | 16,902 |  |  |  | — |  |
| Asia Pacific |  |  | 2,677 |  |  |  | 2,850 |  |
| EMEA |  |  | 250 |  |  |  | — |  |
| Total |  | $ | 19,829 |  |  | $ | 2,850 |  |

[0001437749-22-018630:notes:56]
|  |  | Three Months Ended June 30, 2021 |  |
| Product Line: |  | Grid |  |  | Wind |  |
| Equipment and systems |  | $ | 21,159 |  |  | $ | 1,033 |  |
| Services and technology development |  |  | 2,342 |  |  |  | 886 |  |
| Total |  | $ | 23,501 |  |  | $ | 1,919 |  |
| Region: |  |  |  |  |  |  |  |  |
| Americas |  | $ | 22,645 |  |  | $ | 19 |  |
| Asia Pacific |  |  | 598 |  |  |  | 1,870 |  |
| EMEA |  |  | 258 |  |  |  | 30 |  |
| Total |  | $ | 23,501 |  |  | $ | 1,919 |  |

[0001437749-22-018630:notes:57]
As of  June 30, 2022, and 2021, the Company’s contract assets and liabilities primarily relate to the timing differences between cash received from a customer in connection with contractual rights to invoicing and the timing of revenue recognition following completion of performance obligations. The Company's accounts receivable balance is made up entirely of customer contract related balances. Changes in the Company’s contract assets, which are included in “Unbilled accounts receivable” and “Deferred program costs” (see Note 8, “Accounts Receivable” and Note 9, “Inventory” for a reconciliation to the condensed consolidated balance sheets) and "Contract liabilities", which are included in the current portion and long-term portion of "Deferred revenue" in the Company’s condensed consolidated balance sheets, are as follows (in thousands):

[0001437749-22-018630:notes:58]
|  |  | Unbilled Accounts Receivable |  |  | Deferred Program Costs |  |  | Contract Liabilities |  |
| Beginning balance as of March 31, 2022 |  | $ | 6,492 |  |  | $ | 858 |  |  | $ | 30,034 |  |
| Increases for costs incurred to fulfill performance obligations |  |  | — |  |  |  | 406 |  |  |  |  |  |
| Increase (decrease) due to customer billings |  |  | (4,710 | ) |  |  |  |  |  |  | 17,852 |  |
| Decrease due to cost recognition on completed performance obligations |  |  | — |  |  |  | (365 | ) |  |  |  |  |
| Increase (decrease) due to recognition of revenue based on transfer of control of performance obligations |  |  | 2,128 |  |  |  |  |  |  |  | (13,737 | ) |
| Other changes and FX impact |  |  | — |  |  |  | (25 | ) |  |  | (394 | ) |
| Ending balance as of June 30, 2022 |  | $ | 3,910 |  |  | $ | 874 |  |  | $ | 33,755 |  |

[0001437749-22-018630:notes:59]
|  |  | Unbilled Accounts Receivable |  |  | Deferred Program Costs |  |  | Contract Liabilities |  |
| Beginning balance as of March 31, 2021 |  | $ | 5,765 |  |  | $ | 978 |  |  | $ | 21,258 |  |
| Increases for costs incurred to fulfill performance obligations |  |  | — |  |  |  | 1,434 |  |  |  | — |  |
| Increase for balance acquired |  |  | — |  |  |  | 634 |  |  |  | 10,048 |  |
| Increase (decrease) due to customer billings |  |  | (1,564 | ) |  |  | — |  |  |  | 21,425 |  |
| Decrease due to cost recognition on completed performance obligations |  |  | — |  |  |  | (2,041 | ) |  |  | — |  |
| Increase (decrease) due to recognition of revenue based on transfer of control of performance obligations |  |  | 4,360 |  |  |  | — |  |  |  | (24,355 | ) |
| Other changes and FX impact |  |  | — |  |  |  | 3 |  |  |  | 246 |  |
| Ending balance as of June 30, 2021 |  | $ | 8,561 |  |  | $ | 1,008 |  |  | $ | 28,622 |  |

[0001437749-22-018630:notes:60]
The Company’s remaining performance obligations represent the unrecognized revenue value of the Company’s contractual commitments. The Company’s performance obligations  may vary significantly each reporting period based on the timing of major new contractual commitments. As of  June 30, 2022, the Company had outstanding performance obligations on existing contracts under ASC 606 to be recognized in the next twelve months of approximately $101.5 million. There are also approximately $13.1 million of outstanding performance obligations to be recognized over a period of thirteen to sixty months. The remaining performance obligations are subject to customer actions and therefore the timing of revenue recognition cannot be reasonably estimated. The twelve-month performance obligations include anticipated shipments to Inox based on the twelve-month rolling forecast provided by Inox on the multi-year supply contract. The quantities specified in any forecast provided by Inox related to the multi-year supply contract are firm and irrevocable for the first three months of a twelve-month rolling forecast. The timing of the performance obligations beyond the twelve-month forecast provided by Inox are not determinable and therefore are not included in the total remaining performance obligations.

[0001437749-22-018630:notes:61]
The following table sets forth customers who represented 10% or more of the Company’s total revenues for the three months ended  June 30, 2022 and 2021:

[0001437749-22-018630:notes:62]
|  |  |  | Three Months Ended |  |
|  | Reportable |  | June 30, |  |
|  | Segment |  | 2022 |  |  | 2021 |  |
| Micron Technology | Grid |  |  | <10 | % |  |  | 21 | % |
| Nextera Energy Resources | Grid |  |  | — |  |  |  | 12 | % |
| SGL Carbon LLC | Grid |  |  | 10 | % |  |  | <10 | % |
| Ascend Performance Materials Ops LLC | Grid |  |  | <10 | % |  |  | 10 | % |


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001437749-22-018630:notes:63]
[same as prior period, unchanged from 0001437749-22-002208:notes:64]

[0001437749-22-018630:notes:64]
The Company accounts for its stock-based compensation at fair value. The following table summarizes stock-based compensation expense by financial statement line item for the three months ended  June 30, 2022 and 2021 (in thousands):

[0001437749-22-018630:notes:65]
|  |  | Three Months Ended June 30, |  |
|  |  | 2022 |  |  | 2021 |  |
| Cost of revenues |  | $ | 29 |  |  | $ | 91 |  |
| Research and development |  |  | 179 |  |  |  | 247 |  |
| Selling, general and administrative |  |  | 825 |  |  |  | 954 |  |
| Total |  | $ | 1,033 |  |  | $ | 1,292 |  |

[0001437749-22-018630:notes:66]
The Company issued 25,806 shares of immediately vested common stock during the three months ended  June 30, 2022. The Company issued 119,044 shares of immediately vested common stock, of which 110,752 shares were issued in-lieu of cash bonuses in the period, and 309,700 shares of restricted stock awards during the three months ended  June 30, 2021. These restricted stock awards generally vest over 2-3 years.  Awards for restricted stock include both time-based and performance-based awards.  For options and restricted stock awards that vest upon the passage of time, expense is being recorded over the vesting period.  Performance-based awards are expensed over the requisite service period based on probability of achievement.

[0001437749-22-018630:notes:67]
The estimated fair value of the Company’s stock-based awards, less expected annual forfeitures, is amortized over the awards’ service period. The total unrecognized compensation cost for unvested stock options was $0.1 million at  June 30, 2022. This expense will be recognized over a weighted average of approximately 2.0 years. The total unrecognized compensation cost for unvested outstanding restricted stock was $4.3 million at  June 30, 2022. This expense will be recognized over a weighted-average expense period of approximately 1.2 years.

[0001437749-22-018630:notes:68]
The Company granted 20,564 stock options during the three months ended  June 30, 2022. The Company did not grant any stock options during the three months ended  June 30, 2021. The stock options granted during the three months ended  June 30, 2022 will vest over 2 years. The weighted average assumptions used in the Black Scholes valuation model for stock options granted during the three months ended  June 30, 2022 are as follows:

[0001437749-22-018630:notes:69]
|  |  | Three Months Ended June 30, |
|  |  | 2022 |  | 2021 |
| Expected volatility |  | 71.4% |  | N/A |
| Risk-free interest rate |  | 3.1% |  | N/A |
| Expected life (years) |  | 6.14 |  | N/A |
| Dividend yield |  | None |  | N/A |


## us-gaap:EarningsPerShareTextBlock

[0001437749-22-018630:notes:70]
[same as prior period, unchanged from 0001437749-22-002208:notes:70]

[0001437749-22-018630:notes:71]
Basic net loss per share (“EPS”) is computed by dividing net loss by the weighted-average number of common shares outstanding for the period. Where applicable, diluted EPS is computed by dividing the net loss by the weighted-average number of common shares and dilutive common equivalent shares outstanding during the period, calculated using the treasury stock method. Common equivalent shares include the effect of restricted stock, exercise of stock options and warrants and contingently issuable shares. Stock options and warrants that are out-of-the-money with exercise prices greater than the average market price of the underlying common shares and shares of performance-based restricted stock where the contingency was not met are excluded from the computation of diluted EPS as the effect of their inclusion would be anti-dilutive.  For each of the three months ended  June 30, 2022, and 2021, 1.1 million shares were not included in the calculation of diluted EPS.  Of these, 1.0 million relate to shares tied to the derivative liability for which the contingency has not yet been met, and 0.1 million relate to outstanding stock options as they were considered anti-dilutive.

[0001437749-22-018630:notes:72]
The following table reconciles the numerators and denominators of the earnings per share calculation for the three months ended  June 30, 2022 and 2021 (in thousands, except per share data):

[0001437749-22-018630:notes:73]
|  |  | Three Months Ended June 30, |  |
|  |  | 2022 |  |  | 2021 |  |
| Numerator: |  |  |  |  |  |  |  |  |
| Net loss |  | $ | (8,710 | ) |  | $ | (5,403 | ) |
| Denominator: |  |  |  |  |  |  |  |  |
| Weighted-average shares of common stock outstanding |  |  | 28,520 |  |  |  | 27,919 |  |
| Weighted-average shares subject to repurchase |  |  | (960 | ) |  |  | (1,093 | ) |
| Shares used in per-share calculation ― basic |  |  | 27,560 |  |  |  | 26,826 |  |
| Shares used in per-share calculation ― diluted |  |  | 27,560 |  |  |  | 26,826 |  |
| Net loss per share ― basic |  | $ | (0.32 | ) |  | $ | (0.20 | ) |
| Net loss per share ― diluted |  | $ | (0.32 | ) |  | $ | (0.20 | ) |


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001437749-22-018630:notes:74]
[same as prior period, unchanged from 0001437749-22-002208:notes:74]

[0001437749-22-018630:notes:75]
[same as prior period, unchanged from 0001437749-22-002208:notes:75]

[0001437749-22-018630:notes:76]
Goodwill represents the difference between the purchase price and the fair value of the identifiable tangible and intangible net assets when accounted for using the purchase method of accounting. The Company's goodwill balance relates to the Neeltran Acquisition in fiscal 2021, the NEPSI Acquisition in fiscal 2020, and the acquisition of Infinia Technology Corporation in fiscal 2017 and is reported in the Grid business segment. Goodwill is not amortized but reviewed for impairment. Goodwill is reviewed annually and whenever events or changes in circumstances indicate that the carrying value of the goodwill might not be recoverable.

[0001437749-22-018630:notes:77]
[same as prior period, unchanged from 0001437749-22-002208:notes:77]

[0001437749-22-018630:notes:78]
|  |  | Goodwill |  |
| March 31, 2021 |  | $ | 34,634 |  |
| Neeltran Acquisition |  |  | 8,837 |  |
| March 31, 2022 |  | $ | 43,471 |  |
| Less impairment loss |  |  | - |  |
| June 30, 2022 |  | $ | 43,471 |  |

[0001437749-22-018630:notes:79]
The Company did not identify any triggering events in the three months ended  June 30, 2022 that would require interim impairment testing of goodwill.

[0001437749-22-018630:notes:80]
[same as prior period, unchanged from 0001437749-22-002208:notes:80]

[0001437749-22-018630:notes:81]
Intangible assets at  June 30, 2022 and  March 31, 2022 consisted of the following (in thousands):

[0001437749-22-018630:notes:82]
|  |  | June 30, 2022 |  |  | March 31, 2022 |  |  |  |  |  |
|  |  | Gross Amount |  |  | Accumulated Amortization |  |  | Net Book Value |  |  | Gross Amount |  |  | Accumulated Amortization |  |  | Net Book Value |  |  | Estimated Useful Life |  |
| Licenses |  | $ | 3,610 |  |  | $ | (3,610 | ) |  |  | — |  |  | $ | 3,610 |  |  | $ | (3,610 | ) |  |  | — |  |  |  | 7 |  |
| Backlog |  | $ | 681 |  |  | $ | (668 | ) |  | $ | 13 |  |  | $ | 681 |  |  | $ | (631 | ) |  | $ | 50 |  |  |  | 2 |  |
| Trade name and trademarks |  |  | 1,800 |  |  |  | — |  |  |  | 1,800 |  |  |  | 1,800 |  |  |  | — |  |  |  | 1,800 |  |  | Indefinite |  |
| Customer relationships |  |  | 9,600 |  |  |  | (3,278 | ) |  |  | 6,322 |  |  |  | 9,600 |  |  |  | (2,723 | ) |  |  | 6,877 |  |  |  | 7 |  |
| Core technology and know-how |  |  | 5,970 |  |  |  | (3,506 | ) |  |  | 2,464 |  |  |  | 5,970 |  |  |  | (3,386 | ) |  |  | 2,584 |  |  |  | 5-10 |  |
| Intangible assets |  | $ | 21,661 |  |  | $ | (11,062 | ) |  | $ | 10,599 |  |  | $ | 21,661 |  |  | $ | (10,350 | ) |  | $ | 11,311 |  |  |  |  |  |

[0001437749-22-018630:notes:83]
The Company recorded intangible amortization expense related to customer relationship and core technology and know-how of $0.7 million and $0.6 million, in the three months ended  June 30, 2022, and 2021 respectively. Additionally, in the three months ended  June 30, 2022 and 2021, the Company recorded less than $0.1 million related to intangible amortization related to backlog that is reported in cost of revenues.

[0001437749-22-018630:notes:84]
[same as prior period, unchanged from 0001437749-22-002208:notes:84]

[0001437749-22-018630:notes:85]
| Years ended March 31, |  | Total |  |
| 2023 |  |  | 2,078 |  |
| 2024 |  |  | 2,152 |  |
| 2025 |  |  | 1,648 |  |
| 2026 |  |  | 1,221 |  |
| 2027 |  |  | 1,085 |  |
| Thereafter |  |  | 615 |  |
| Total |  | $ | 8,799 |  |

[0001437749-22-018630:notes:86]
[same as prior period, unchanged from 0001437749-22-002208:notes:86]


## us-gaap:FairValueDisclosuresTextBlock

[0001437749-22-018630:notes:87]
[same as prior period, unchanged from 0001437749-22-002208:notes:87]

[0001437749-22-018630:notes:88]
[same as prior period, unchanged from 0001437749-22-002208:notes:88]

[0001437749-22-018630:notes:89]
[same as prior period, unchanged from 0001437749-22-002208:notes:89]

[0001437749-22-018630:notes:90]
The Company provides a gross presentation of activity within Level 3 measurement roll-forward and details of transfers in and out of Level 1 and 2 measurements.  A change in the hierarchy of an investment from its current level is reflected in the period during which the pricing methodology of such investment changes.  Disclosure of the transfer of securities from Level 1 to Level 2 or Level 3 is made in the event that the related security is significant to total cash and investments.  The Company did not have any transfers of assets and liabilities from Level 1, Level 2 or Level 3 of the fair value measurement hierarchy during the three months ended  June 30, 2022.

[0001437749-22-018630:notes:91]
[same as prior period, unchanged from 0001437749-22-002208:notes:91]

[0001437749-22-018630:notes:92]
[same as prior period, unchanged from 0001437749-22-002208:notes:92]

[0001437749-22-018630:notes:93]
[same as prior period, unchanged from 0001437749-22-002208:notes:93]

[0001437749-22-018630:notes:94]
[same as prior period, unchanged from 0001437749-22-002208:notes:94]

[0001437749-22-018630:notes:95]
[same as prior period, unchanged from 0001437749-22-002208:notes:95]

[0001437749-22-018630:notes:96]
Marketable securities consist of certificates of deposit that are measured using such inputs as quoted prices and are classified within Level 1 of the valuation hierarchy. The Company determines the appropriate classification of its marketable securities at the time of purchase and re-evaluates such classification as of each balance sheet date.  All marketable securities are considered available for sale and are carried at fair value. Changes in fair value are recorded to other income (expense), net.  The Company had no outstanding marketable securities as of  June 30, 2022 and the Company recognized no change in the three months ended  June 30, 2022. The Company recognized $0.1 million in unrealized losses on marketable securities, which is recorded in other income (expense), net, for the three months ended  June 30, 2021. The Company periodically reviews the realizability of each short and long term marketable security when impairment indicators exist with respect to the security. If other than temporary impairment of value of the security exists, the carrying value of the security is written down to its estimated fair value.

[0001437749-22-018630:notes:97]
[same as prior period, unchanged from 0001437749-22-002208:notes:97]

[0001437749-22-018630:notes:98]
Contingent consideration relates to the earnout payment set forth in the NEPSI Stock Purchase Agreement that provides that the selling stockholders  may receive up to an additional 1,000,000 shares of common stock of the Company upon the achievement of certain specified revenue objectives over varying periods of up to four years following the NEPSI Acquisition Date. See Note 13, "Contingent Consideration" and Note 2, “Acquisitions” for further discussion. The Company relied on a Monte Carlo method to determine the fair value of the contingent consideration on the NEPSI Acquisition Date and will continue to revalue the fair value of the contingent consideration using the same method at each subsequent balance sheet date until the contingencies are resolved and the shares to be issued are determined, with the change in fair value recorded in the current period operating loss.

[0001437749-22-018630:notes:99]
The following table provides the assets and liabilities carried at fair value on a recurring basis, measured as of  June 30, 2022 and  March 31, 2022 (in thousands):

[0001437749-22-018630:notes:100]
|  |  | Total Carrying Value |  |  | Quoted Prices in Active Markets (Level 1) |  |  | Significant Other Observable Inputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |
| June 30, 2022: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash equivalents |  | $ | 12,893 |  |  | $ | 12,893 |  |  | $ | — |  |  | $ | — |  |
| Derivative liabilities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Contingent consideration |  | $ | 1,370 |  |  | $ | — |  |  | $ | — |  |  | $ | 1,370 |  |

[0001437749-22-018630:notes:101]
|  |  | Total Carrying Value |  |  | Quoted Prices in Active Markets (Level 1) |  |  | Significant Other Observable Inputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |
| March 31, 2022: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash equivalents |  | $ | 17,641 |  |  | $ | 17,641 |  |  | $ | — |  |  | $ | — |  |
| Derivative liabilities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Contingent consideration |  | $ | 1,200 |  |  | $ | — |  |  | $ | — |  |  | $ | 1,200 |  |

[0001437749-22-018630:notes:102]
[same as prior period, unchanged from 0001437749-22-002208:notes:102]

[0001437749-22-018630:notes:103]
|  |  | Acquisition Contingent Consideration |  |
| Balance at March 31, 2021 |  | $ | 7,050 |  |
| Change in fair value |  |  | (5,850 | ) |
| Balance at March 31, 2022 |  |  | 1,200 |  |
| Change in fair value |  |  | 170 |  |
| Balance at June 30, 2022 |  | $ | 1,370 |  |


## amsc:AccountsReceivableTextBlock

[0001437749-22-018630:notes:104]
[same as prior period, unchanged from 0001437749-22-002208:notes:104]

[0001437749-22-018630:notes:105]
Accounts receivable at  June 30, 2022 and  March 31, 2022 consisted of the following (in thousands):

[0001437749-22-018630:notes:106]
|  |  | June 30, 2022 |  |  | March 31, 2022 |  |
| Accounts receivable (billed) |  | $ | 17,821 |  |  | $ | 13,788 |  |
| Accounts receivable (unbilled) |  |  | 3,910 |  |  |  | 6,492 |  |
| Accounts receivable, net |  | $ | 21,731 |  |  | $ | 20,280 |  |


## us-gaap:InventoryDisclosureTextBlock

[0001437749-22-018630:notes:107]
[same as prior period, unchanged from 0001437749-22-002208:notes:107]

[0001437749-22-018630:notes:108]
Inventory, net of reserves, at  June 30, 2022 and  March 31, 2022 consisted of the following (in thousands):

[0001437749-22-018630:notes:109]
|  |  | June 30, 2022 |  |  | March 31, 2022 |  |
| Raw materials |  | $ | 15,239 |  |  | $ | 11,020 |  |
| Work-in-process |  |  | 12,077 |  |  |  | 10,462 |  |
| Finished goods |  |  | 4,734 |  |  |  | 1,326 |  |
| Deferred program costs |  |  | 874 |  |  |  | 858 |  |
| Net inventory |  | $ | 32,924 |  |  | $ | 23,666 |  |

[0001437749-22-018630:notes:110]
The Company recorded inventory write-downs of $0.3 million and $0.6 million for the three months ended  June 30, 2022 and 2021, respectively. These write-downs were based on the Company's evaluation of its inventory on hand for excess quantities and obsolescence.

[0001437749-22-018630:notes:111]
Deferred program costs as of  June 30, 2022, and  March 31, 2022, primarily represent costs incurred on programs where the Company needs to complete performance obligations before the related revenue and costs will be recognized.


## us-gaap:PropertyPlantAndEquipmentDisclosureTextBlock

[0001437749-22-018630:notes:112]
[same as prior period, unchanged from 0001437749-22-002208:notes:112]

[0001437749-22-018630:notes:113]
The cost and accumulated depreciation of property, plant and equipment at  June 30, 2022 and  March 31, 2022 are as follows (in thousands):

[0001437749-22-018630:notes:114]
|  |  | June 30, 2022 |  |  | March 31, 2022 |  |
| Construction in progress - equipment |  | $ | 523 |  |  | $ | 573 |  |
| Land |  |  | 980 |  |  |  | 980 |  |
| Building |  |  | 5,397 |  |  |  | 5,270 |  |
| Equipment and software |  |  | 43,737 |  |  |  | 43,668 |  |
| Finance lease - right of use asset |  |  | 6 |  |  |  | 8 |  |
| Furniture and fixtures |  |  | 1,505 |  |  |  | 1,379 |  |
| Leasehold improvements |  |  | 6,648 |  |  |  | 6,634 |  |
| Property, plant and equipment, gross |  |  | 58,796 |  |  |  | 58,512 |  |
| Less accumulated depreciation |  |  | (45,399 | ) |  |  | (44,856 | ) |
| Property, plant and equipment, net |  | $ | 13,397 |  |  | $ | 13,656 |  |

[0001437749-22-018630:notes:115]
Depreciation expense was $0.7 million and $0.6 million for the three months ended  June 30, 2022 and 2021, respectively.


## us-gaap:AccountsPayableAndAccruedLiabilitiesDisclosureTextBlock

[0001437749-22-018630:notes:116]
[same as prior period, unchanged from 0001437749-22-002208:notes:116]

[0001437749-22-018630:notes:117]
Accounts payable and accrued expenses at  June 30, 2022 and  March 31, 2022 consisted of the following (in thousands):

[0001437749-22-018630:notes:118]
|  |  | June 30, 2022 |  |  | March 31, 2022 |  |
| Accounts payable |  | $ | 19,213 |  |  | $ | 13,192 |  |
| Accrued inventories in-transit |  |  | 2,206 |  |  |  | 2,212 |  |
| Accrued other miscellaneous expenses |  |  | 3,697 |  |  |  | 3,602 |  |
| Advanced deposits |  |  | 2,607 |  |  |  | 3,021 |  |
| Accrued compensation |  |  | 5,384 |  |  |  | 4,642 |  |
| Income taxes payable |  |  | 355 |  |  |  | 405 |  |
| Accrued product warranty |  |  | 1,942 |  |  |  | 2,066 |  |
| Total |  | $ | 35,404 |  |  | $ | 29,140 |  |

[0001437749-22-018630:notes:119]
[same as prior period, unchanged from 0001437749-22-002208:notes:119]

[0001437749-22-018630:notes:120]
[same as prior period, unchanged from 0001437749-22-002208:notes:120]

[0001437749-22-018630:notes:121]
|  |  | Three Months Ended June 30, |  |
|  |  | 2022 |  |  | 2021 |  |
| Balance at beginning of period |  | $ | 2,066 |  |  | $ | 2,053 |  |
| Acquired warranty obligations |  |  | - |  |  |  | 248 |  |
| Change in accruals for warranties during the period |  |  | 178 |  |  |  | 107 |  |
| Settlements during the period |  |  | (302 | ) |  |  | (222 | ) |
| Balance at end of period |  | $ | 1,942 |  |  | $ | 2,186 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0001437749-22-018630:notes:122]
[same as prior period, unchanged from 0001437749-22-002208:notes:122]

[0001437749-22-018630:notes:123]
The Company recorded an income tax expense of less than $0.1 million in the three months ended  June 30, 2022. The Company recorded an income tax benefit of $2.1 million in the three months ended  June 30, 2021.

[0001437749-22-018630:notes:124]
As a result of a difference in book and tax basis related to the intangible assets acquired in the Neeltran Acquisition (see Note 2, "Acquisitions"), the Company recorded a deferred tax liability of $2.3 million during the three months ended  June 30, 2021. As a result, the Company was able to benefit from additional deferred tax assets and therefore released a corresponding valuation allowance of $2.3 million during the three months ended  June 30 2021. Goodwill recognized in the Neeltran Acquisition is not deductible for tax purposes.

[0001437749-22-018630:notes:125]
Accounting for income taxes requires a two-step approach to recognizing and measuring uncertain tax positions.  The first step is to evaluate the tax position for recognition by determining if, based on the technical merits, it is more likely than not the position will be sustained upon audit, including resolution of related appeals or litigation processes, if any.  The second step is to measure the tax benefit as the largest amount that is more than 50% likely to be realized upon ultimate settlement.  The Company re-evaluates these uncertain tax positions on a quarterly basis.  The evaluation is based on factors including, but not limited to, changes in facts or circumstances, changes in tax law, effectively settled issues under audit and new audit activity.  Any changes in these factors could result in the recognition of a tax benefit or an additional charge to the tax provision.  The Company did not identify any uncertain tax positions in the three months ended  June 30, 2022 and did not have any gross unrecognized tax benefits as of  June 30, 2022.


## amsc:BusinessCombinationContingentConsiderationTextBlock

[0001437749-22-018630:notes:126]
[same as prior period, unchanged from 0001437749-22-002208:notes:126]

[0001437749-22-018630:notes:127]
[same as prior period, unchanged from 0001437749-22-002208:notes:127]

[0001437749-22-018630:notes:128]
[same as prior period, unchanged from 0001437749-22-002208:notes:128]

[0001437749-22-018630:notes:129]
|  |  | June 30, |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Fiscal Year 2022 |  | 2022 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Revenue risk premium |  |  | 6.60 | % |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Revenue volatility |  |  | 30 | % |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Stock Price |  | $ | 5.18 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Payment delay (days) |  |  | 80 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Fair value (millions) |  | $ | 1.4 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | March 31, |  |  | December 31, |  |  | September 30, |  |  | June 30, |  |  | March 31, |  |
| Fiscal Year 2021 |  | 2022 |  |  | 2021 |  |  | 2021 |  |  | 2021 |  |  | 2021 |  |
| Revenue risk premium |  |  | 6.50 | % |  |  | 6.60 | % |  |  | 6.60 | % |  |  | 6.60 | % |  |  | 6.70 | % |
| Revenue volatility |  |  | 33 | % |  |  | 33 | % |  |  | 30 | % |  |  | 30 | % |  |  | 30 | % |
| Stock Price |  | $ | 7.61 |  |  | $ | 10.88 |  |  | $ | 14.58 |  |  | $ | 17.39 |  |  | $ | 18.96 |  |
| Payment delay (days) |  |  | 80 |  |  |  | 80 |  |  |  | 80 |  |  |  | 80 |  |  |  | 80 |  |
| Fair value (millions) |  | $ | 1.2 |  |  | $ | 2.6 |  |  | $ | 4.7 |  |  | $ | 7.2 |  |  | $ | 7.1 |  |

[0001437749-22-018630:notes:130]
The Company recorded a net loss of $0.2 million resulting from the increase in the fair value of the contingent consideration in the three months ended  June 30, 2022. The Company recorded a net loss of $0.1 million resulting from the increase in the fair value of the contingent consideration in the three months ended  June 30, 2021.


## us-gaap:DebtDisclosureTextBlock

[0001437749-22-018630:notes:131]
14. Debt

[0001437749-22-018630:notes:132]
As part of the Neeltran Acquisition, the Company identified four equipment financing agreements that Neeltran had entered into prior to the acquisition on  May 6, 2021. The Company determined to account for these agreements as a debt transaction and recorded current and long-term debt liabilities of $0.1 million each during the three months ended  June 30, 2021. The current and long term debt balance is $0.1 million each as of the three months ended  June 30, 2022.


## us-gaap:LesseeOperatingLeasesTextBlock

[0001437749-22-018630:notes:133]
[same as prior period, unchanged from 0001437749-22-002208:notes:133]

[0001437749-22-018630:notes:134]
The Company determines whether a contract is or contains a lease at inception of a contract. The Company defines a lease as a contract, or part of a contract, that conveys the right to control the use of identified property or equipment (an identified asset) for a period of time in exchange for consideration. Control over the use of the identified asset means that the Company has both the right to obtain substantially all of the economic benefits from the use of the asset and the right to direct the use of the asset.

[0001437749-22-018630:notes:135]
[same as prior period, unchanged from 0001437749-22-002208:notes:135]

[0001437749-22-018630:notes:136]
[same as prior period, unchanged from 0001437749-22-002208:notes:136]

[0001437749-22-018630:notes:137]
[same as prior period, unchanged from 0001437749-22-002208:notes:137]

[0001437749-22-018630:notes:138]
[same as prior period, unchanged from 0001437749-22-002208:notes:138]

[0001437749-22-018630:notes:139]
[same as prior period, unchanged from 0001437749-22-002208:notes:139]

[0001437749-22-018630:notes:140]
[same as prior period, unchanged from 0001437749-22-002208:notes:140]

[0001437749-22-018630:notes:141]
As part of the adoption of ASC 842 at Neeltran, the Company identified one lease contract that is classified as a finance lease. In  February 2020, Neeltran entered into a contract to lease a copy machine for an initial term of 39 months, or through  May 2023. The Company concluded that the lease should be classified and accounted for as a finance lease as the total value of the lease payments are greater than fair value of the asset. Accordingly, on  May 6, 2021, the Company recognized a finance lease right-of-use asset and a finance lease liability of $13.2 thousand on the Neeltran opening balance sheet. As of  June 30, 2022, the right-of-use asset related to the finance lease was $5.8 thousand, net of accumulated amortization of $7.4 thousand, and is included in the property and equipment, net on the Company's consolidated balance sheet.

[0001437749-22-018630:notes:142]
Finance lease right-of-use assets and lease liabilities are recognized similar to an operating lease, at the lease commencement date or the date the lessor makes the leased asset available for use. Finance lease right-of-use assets are generally amortized on a straight-line basis over the lease term, and the carrying amount of the finance lease liabilities are (1) accreted to reflect interest using the incremental borrowing rate if the rate implicit in the lease is not readily determinable, and (2) reduced to reflect lease payments made during the period. Amortization expense for finance lease right-of-use assets and interest accretion on finance lease liabilities are recorded to depreciation expense and interest expense, respectively in the Company's consolidated statement of operations.

[0001437749-22-018630:notes:143]
Supplemental balance sheet information related to leases at  June 30, 2022, and  March 31, 2022 are as follows (in thousands):

[0001437749-22-018630:notes:144]
|  |  | June 30, 2022 |  |  | March 31, 2022 |  |
| Leases: |  |  |  |  |  |  |  |  |
| Right-of-use assets - Financing |  | $ | 6 |  |  |  | 8 |  |
| Right-of-use assets - Operating |  |  | 3,484 |  |  |  | 3,502 |  |
| Total right-of-use assets |  |  | 3,490 |  |  |  | 3,510 |  |
| Lease liabilities - ST Financing |  | $ | 6 |  |  |  | 7 |  |
| Lease liabilities - ST Operating |  |  | 821 |  |  |  | 740 |  |
| Lease liabilities - LT Financing |  |  | — |  |  |  | 1 |  |
| Lease liabilities - LT Operating |  |  | 2,783 |  |  |  | 2,900 |  |
| Total lease liabilities |  |  | 3,610 |  |  |  | 3,648 |  |
| Weighted-average remaining lease term |  |  | 4.52 |  |  |  | 4.93 |  |
| Weighted-average discount rate |  |  | 6.33 | % |  |  | 6.36 | % |

[0001437749-22-018630:notes:145]
The costs related to the Company's finance lease are not material. The costs related to the Company's operating leases for the three months ended  June 30, 2022 and 2021 are as follows (in thousands):

[0001437749-22-018630:notes:146]
|  |  | Three Months Ended |  |
|  |  | June 30, 2022 |  |
| Operating Leases: |  |  |  |  |
| Operating lease costs - fixed |  | $ | 242 |  |
| Operating lease costs - variable |  |  | 38 |  |
| Short-term lease costs |  |  | 31 |  |
| Total lease costs |  |  | 311 |  |

[0001437749-22-018630:notes:147]
|  |  | Three Months Ended |  |
|  |  | June 30, 2021 |  |
| Operating Leases: |  |  |  |  |
| Operating lease costs - fixed |  | $ | 231 |  |
| Operating lease costs - variable |  |  | 32 |  |
| Short-term lease costs |  |  | 67 |  |
| Total lease costs |  |  | 330 |  |

[0001437749-22-018630:notes:148]
[same as prior period, unchanged from 0001437749-22-002208:notes:148]

[0001437749-22-018630:notes:149]
|  |  | Leases |  |
| Year ended March 31, |  |  |  |  |
| 2023 |  | $ | 762 |  |
| 2024 |  |  | 974 |  |
| 2025 |  |  | 780 |  |
| 2026 |  |  | 719 |  |
| 2027 |  |  | 579 |  |
| Thereafter |  |  | 357 |  |
| Total minimum lease payments |  |  | 4,171 |  |
| Less: interest |  |  | 567 |  |
| Present value of lease liabilities |  |  | 3,604 |  |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001437749-22-018630:notes:150]
16. Commitments and Contingencies

[0001437749-22-018630:notes:151]
Legal Contingencies

[0001437749-22-018630:notes:152]
From time to time, the Company is involved in legal and administrative proceedings and claims of various types. The Company records a liability in its consolidated financial statements for these matters when a loss is known or considered probable and the amount can be reasonably estimated. The Company reviews these estimates each accounting period as additional information is known and adjusts the loss provision when appropriate. If a matter is both probable to result in a liability and the amounts of loss can be reasonably estimated, the Company estimates and discloses the possible loss or range of loss to the extent necessary to make the consolidated financial statements not misleading. If the loss is not probable or cannot be reasonably estimated, a liability is not recorded in its consolidated financial statements.

[0001437749-22-018630:notes:153]
Other

[0001437749-22-018630:notes:154]
The Company enters into long-term construction contracts with customers that require the Company to obtain performance bonds. The Company is required to deposit an amount equivalent to some or all the face amount of the performance bonds into an escrow account until the termination of the bond. When the performance conditions are met, amounts deposited as collateral for the performance bonds are returned to the Company. In addition, the Company has various contractual arrangements in which minimum quantities of goods or services have been committed to be purchased on an annual basis.

[0001437749-22-018630:notes:155]
As of  June 30, 2022, the Company had $6.0 million of restricted cash included in long-term assets and $3.8 million of restricted cash included in current assets. As of  March 31, 2022, the Company had $6.1 million of restricted cash included in long term assets and $2.8 million of restricted cash included in current assets. These amounts included in restricted cash primarily represent deposits to secure letters of credit for various supply contracts and long-term projects, including the irrevocable letter of credit in the amount of $5.0 million to secure certain of the Company's obligations under a subcontract agreement with ComEd.  These deposits are held in interest bearing accounts.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001437749-22-018630:notes:156]
[same as prior period, unchanged from 0001437749-22-002208:notes:156]

[0001437749-22-018630:notes:157]
[same as prior period, unchanged from 0001437749-22-002208:notes:157]

[0001437749-22-018630:notes:158]
[same as prior period, unchanged from 0001437749-22-002208:notes:158]

[0001437749-22-018630:notes:159]
[same as prior period, unchanged from 0001437749-22-002208:notes:159]

[0001437749-22-018630:notes:160]
[same as prior period, unchanged from 0001437749-22-002208:notes:160]

[0001437749-22-018630:notes:161]
|  |  | Three Months Ended June 30, |  |
|  |  | 2022 |  |  | 2021 |  |
| Revenues: |  |  |  |  |  |  |  |  |
| Grid |  | $ | 19,829 |  |  | $ | 23,501 |  |
| Wind |  |  | 2,850 |  |  |  | 1,919 |  |
| Total |  | $ | 22,679 |  |  | $ | 25,420 |  |

[0001437749-22-018630:notes:162]
|  |  | Three Months Ended June 30, |  |
|  |  | 2022 |  |  | 2021 |  |
| Operating loss: |  |  |  |  |  |  |  |  |
| Grid |  | $ | (7,281 | ) |  | $ | (5,345 | ) |
| Wind |  |  | (386 | ) |  |  | (763 | ) |
| Unallocated corporate expenses |  |  | (1,202 | ) |  |  | (1,391 | ) |
| Total |  | $ | (8,869 | ) |  | $ | (7,499 | ) |

[0001437749-22-018630:notes:163]
[same as prior period, unchanged from 0001437749-22-002208:notes:163]

[0001437749-22-018630:notes:164]
Unallocated corporate expenses consist of a loss on contingent consideration of $0.2 million in the three months ended  June 30, 2022. Unallocated corporate expenses consist of a loss on contingent consideration of $0.1 million in the three months ended  June 30, 2021. Additionally, unallocated corporate expenses consist of stock-based compensation expense of $1.0 million and $1.3 million in the three months ended  June 30, 2022, and 2021, respectively.

[0001437749-22-018630:notes:165]
Total assets for the two business segments as of  June 30, 2022, and  March 31, 2022, are as follows (in thousands):

[0001437749-22-018630:notes:166]
|  |  | June 30, 2022 |  |  | March 31, 2022 |  |
| Grid |  | $ | 120,583 |  |  | $ | 114,053 |  |
| Wind |  |  | 9,433 |  |  |  | 9,866 |  |
| Corporate assets |  |  | 46,492 |  |  |  | 49,968 |  |
| Total |  | $ | 176,508 |  |  | $ | 173,887 |  |


## us-gaap:NewAccountingPronouncementsAndChangesInAccountingPrinciplesTextBlock

[0001437749-22-018630:notes:167]
18. Recent Accounting Pronouncements

[0001437749-22-018630:notes:168]
In  June 2016, the FASB issued ASU 2016-13, Financial Instruments-Credit Losses (Topic 326): Measurement of Credit Losses on Financial Instruments. The amendments in ASU 2016-13 will provide more decision-useful information about the expected credit losses on financial instruments and other commitments to extend credit held by a reporting entity at each reporting date. Following the release of ASU 2019-10 in  November 2019, the new effective date, as long as the Company remains a smaller reporting company, would be annual reporting periods beginning after  December 15, 2022.The Company is currently evaluating the impact, if any, that the adoption of ASU 2016-13  may have on its consolidated financial statements.

[0001437749-22-018630:notes:169]
In  October 2021, the FASB issued ASU 2021-08, Business Combinations (Topic 805): Accounting for Contract Assets and Contract Liabilities from Contracts with Customers. The amendments in ASU 2021-08 will improve the accounting for acquired revenue contracts with customers in a business combination. Following the release of ASU 2021-08 in  October 2021, the new effective date will be annual reporting periods beginning after  December 15, 2022. The Company is currently evaluating the impact, if any, that the adoption of ASU 2021-08  may have on its consolidated financial statements.

[0001437749-22-018630:notes:170]
In  November 2021, the FASB issued ASU 2021-10, Government Assistance (Topic 832): Disclosures by Business Entities about Government Assistance. The amendments in ASU 2021-10 will improve financial reporting by requiring disclosures that increase the transparency of transactions with government accounted for by applying a grant or contribution accounting model by analogy. Following the release of ASU 2021-10 in  November 2021, the new effective date will be annual reporting periods beginning after  December 15, 2021. As of  April 1, 2022, the Company has adopted ASU 2021-10 and noted no material impact on its consolidated financial statements.


## us-gaap:SubsequentEventsTextBlock

[0001437749-22-018630:notes:171]
19. Subsequent Events

[0001437749-22-018630:notes:172]
The Company has performed an evaluation of subsequent events through the time of filing this Quarterly Report on Form 10-Q with the SEC and has determined that there are no such events to report.
