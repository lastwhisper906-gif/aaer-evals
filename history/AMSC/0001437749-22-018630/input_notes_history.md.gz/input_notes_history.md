# AMSC note change history — 0001437749-22-002208 → 0001437749-22-018630


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2022-08-03):
[0001437749-22-018630:note_history:1]
As of  June 30, 2022, the Company had $6.0 million of restricted cash included in long-term assets and $3.8 million of restricted cash included in current assets. As of  March 31, 2022, the Company had $6.1 million of restricted cash included in long term assets and $2.8 million of restricted cash included in current assets. These amounts included in restricted cash primarily represent deposits to secure letters of credit for various supply contracts and long-term projects, including the irrevocable letter of credit in the amount of $5.0 million to secure certain of the Company's obligations under a subcontract agreement with ComEd.  These deposits are held in interest bearing accounts.
  (was, 2022-02-02, similarity 0.9911):
[0001437749-22-002208:note_history:1]
As of  December 31, 2021, the Company had $6.0 million of restricted cash included in long-term assets and $2.7 million of restricted cash included in current assets. As of  March 31, 2021, the Company had $5.6 million of restricted cash included in long term assets and $2.2 million of restricted cash included in current assets. These amounts included in restricted cash primarily represent deposits to secure letters of credit for various supply contracts and long-term projects, including the irrevocable letter of credit in the amount of $5.0 million to secure certain of the Company's obligations under a subcontract agreement with ComEd.  These deposits are held in interest bearing accounts.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2022-08-03):
[0001437749-22-018630:note_history:2]
These unaudited condensed consolidated financial statements of the Company have been prepared on a going concern basis in accordance with United States generally accepted accounting principles (“GAAP”) and the Securities and Exchange Commission’s (“SEC”) instructions to Form 10-Q. The going concern basis of presentation assumes that the Company will continue operations and will be able to realize its assets and discharge its liabilities and commitments in the normal course of business. Certain information and footnote disclosures normally included in the financial statements prepared in accordance with GAAP have been condensed or omitted pursuant to those instructions. The year-end condensed balance sheet data was derived from audited financial statements but does not include all disclosures required by GAAP. The unaudited condensed consolidated financial statements, in the opinion of management, reflect all adjustments (consisting of normal recurring adjustments) necessary for a fair statement of the results for the interim periods ended  June 30, 2022 and 2021 and the financial position at  June 30, 2022; however, these results are not necessarily indicative of results which  may be expected for the full year. The interim condensed consolidated financial statements, and notes thereto, should be read in conjunction with the audited consolidated financial statements for the year ended  March 31, 2022, and notes thereto, included in the Company’s Annual Report on Form 10-K for the year ended  March 31, 2022 filed with the SEC on  June 1, 2022.
  (was, 2022-02-02, similarity 0.9922):
[0001437749-22-002208:note_history:2]
These unaudited condensed consolidated financial statements of the Company have been prepared on a going concern basis in accordance with United States generally accepted accounting principles (“GAAP”) and the Securities and Exchange Commission’s (“SEC”) instructions to Form 10-Q. The going concern basis of presentation assumes that the Company will continue operations and will be able to realize its assets and discharge its liabilities and commitments in the normal course of business. Certain information and footnote disclosures normally included in the financial statements prepared in accordance with GAAP have been condensed or omitted pursuant to those instructions. The year-end condensed balance sheet data was derived from audited financial statements but does not include all disclosures required by GAAP. The unaudited condensed consolidated financial statements, in the opinion of management, reflect all adjustments (consisting of normal recurring adjustments) necessary for a fair statement of the results for the interim periods ended  December 31, 2021 and 2020 and the financial position at  December 31, 2021; however, these results are not necessarily indicative of results which  may be expected for the full year. The interim condensed consolidated financial statements, and notes thereto, should be read in conjunction with the audited consolidated financial statements for the year ended  March 31, 2021, and notes thereto, included in the Company’s Annual Report on Form 10-K for the year ended  March 31, 2021 filed with the SEC on  June 2, 2021.

- changed (2022-08-03):
[0001437749-22-018630:note_history:3]
The Company has historically experienced recurring operating losses and as of  June 30, 2022, the Company had an accumulated deficit of $1,029 million. In addition, the Company has historically experienced recurring negative operating cash flows.  At  June 30, 2022, the Company had cash and cash equivalents of $33.4 million. Cash used in operations for the three months ended  June 30, 2022 was $5.9 million.
  (was, 2022-02-02, similarity 0.9053):
[0001437749-22-002208:note_history:3]
The Company has historically experienced recurring operating losses and as of  December 31, 2021, the Company had an accumulated deficit of $1,015 million. In addition, the Company has historically experienced recurring negative operating cash flows.  At  December 31, 2021, the Company had cash and cash equivalents of $43.9 million. Cash used in operations for the nine months ended  December 31, 2021 was $15.9 million.

- changed (2022-08-03):
[0001437749-22-018630:note_history:4]
In  March 2020, the World Health Organization declared the disease caused by the novel coronavirus (“COVID-19“) to be a pandemic. COVID-19 has spread throughout the globe, including in the Commonwealth of Massachusetts where the Company’s headquarters are located, and in other areas where the Company has business operations. In response to the pandemic, the Company has followed the guidelines of the U.S. Centers for Disease Control and Prevention (“CDC”) and applicable state government authorities to protect the health and safety of the Company’s employees, families, suppliers, customers and communities. While these existing measures and, COVID-19 generally, have not materially disrupted the Company’s business to date, any future actions necessitated by the COVID-19 pandemic  may result in disruption to the Company’s business.
  (was, 2022-02-02, similarity 0.9812):
[0001437749-22-002208:note_history:4]
In  March 2020, the World Health Organization declared the disease caused by the novel coronavirus, COVID-19, to be a pandemic. COVID-19 has spread throughout the globe, including in the Commonwealth of Massachusetts where the Company’s headquarters are located, and in other areas where the Company has business operations. In response to the outbreak, the Company has followed the guidelines of the U.S. Centers for Disease Control and Prevention and applicable state government authorities to protect the health and safety of the Company’s employees, families, suppliers, customers and communities. While these existing measures and, COVID-19 generally, have not materially disrupted the Company’s business to date, any future actions necessitated by the COVID-19 pandemic  may result in disruption to the Company’s business.

- added (2022-08-03):
[0001437749-22-018630:note_history:5]
The COVID-19 pandemic continues to rapidly evolve. The Company is experiencing substantial inflationary pressure in its supply chain, some delays in sourcing materials needed for its products and some production disruption resulting from higher than typical employee absenteeism, all of which have increased the Company’s cost of revenues and decreased gross margin. The extent to which the pandemic impacts the Company’s business, liquidity, results of operations and financial condition will depend on future developments, which are highly uncertain and cannot be predicted with confidence.  Changes in macroeconomic conditions arising from the COVID-19 pandemic or for other reasons, such as the ongoing war between Russia and Ukraine, including inflation, labor force availability, sourcing, material delays and global supply chain disruptions could have a material adverse effect on the Company’s business, financial condition and results of operation.

- added (2022-08-03):
[0001437749-22-018630:note_history:6]
The Company believes that based on the information presented above and its quarterly management assessment, it has sufficient liquidity to fund its operations and capital expenditures for the next twelve months following the issuance of the financial statements for the three months ended  June 30, 2022. The Company’s liquidity is highly dependent on its ability to increase revenues, its ability to control its operating costs, and its ability to raise additional capital, if necessary. The impact of the COVID-19 pandemic and other sources of instability, including the war between Russia and Ukraine, on the global financing markets  may reduce the Company's ability to raise additional capital, if necessary, which could negatively impact the Company's liquidity.  There can be no assurance that the Company will be able to continue to raise additional capital, on favorable terms or at all, from other sources or execute on any other means of improving liquidity described above.

- removed (2022-08-03):
[0001437749-22-002208:note_history:7]
On  May 6, 2021 (the "Neeltran Acquisition Date"), the Company entered into a Purchase and Sale Agreement (the "Real Property Purchase Agreement") and a Stock Purchase Agreement (the "Neeltran Stock Purchase Agreement") with the selling equity holders named therein. Also on  May 6, 2021, pursuant to the Real Property Purchase Agreement, the Company's wholly-owned Connecticut limited liability company, AMSC Husky LLC ("AMSC Husky"), purchased the real property that served as Neeltran's headquarters for $4.3 million, of which (a) $2.4 million was paid in immediately available funds by AMSC Husky to the owners of such real property, and (b) $1.9 million was paid directly to TD Bank as full payment for the outstanding indebtedness secured by the mortgage on such real property.  Pursuant to the terms of the Neeltran Stock Purchase Agreement and concurrently with entering into such agreement, the Company purchased all of the issued and outstanding shares of capital stock of (i) Neeltran, Inc., a Connecticut corporation ("Neeltran") that supplies rectifiers and transformers to industrial customers, and (ii) Neeltran International, Inc., a Connecticut corporation ("International"), for: (a) $1.0 million in cash, and (b) 301,556 shares of the Company's common stock, $.01 par value per share (the "AMSC Shares"), that were paid and issued to the Neeltran selling stockholders, respectively at closing (the "Neeltran Acquisition"). The Company also paid $1.1 million to International selling stockholders at closing to pay off previous loans made by them to Neeltran. Additionally, the Company paid approximately $7.6 million on behalf of the selling equity holders, including $1.9 million of indebtedness secured by the mortgage on the real property as described above, directly to Neeltran lenders at closing to extinguish outstanding Neeltran indebtedness to third parties on behalf of the sellers.

- removed (2022-08-03):
[0001437749-22-002208:note_history:8]
While the COVID-19 pandemic continues to rapidly evolve, the Company is experiencing some inflation pressure in its supply chains, some delays in sourcing materials needed for its products, and some production disruption resulting from higher than typical employee absenteeism due to the highly contagious omicron variant. The Company continues to assess the impact of the COVID-19 pandemic to best mitigate risk and continue the operations of the Company’s business. The extent to which the outbreak impacts the Company’s business, liquidity, results of operations and financial condition will depend on future developments, which are highly uncertain and cannot be predicted with confidence, including new information that  may emerge concerning the severity of the COVID-19 pandemic, the spread of new variations of the virus, the actions to contain it or treat its impact and the effectiveness and adoption of vaccines and treatments, among others.  If the Company, its customers or suppliers experience prolonged shutdowns or other business disruptions, including global supply chain disruptions, the Company’s business, liquidity, results of operations and financial condition are likely to be materially adversely affected, and the Company’s ability to access the capital markets  may be limited.

- removed (2022-08-03):
[0001437749-22-002208:note_history:9]
The Company believes that based on the information presented above and its quarterly management assessment, it has sufficient liquidity to fund its operations and capital expenditures for the next twelve months following the issuance of the financial statements for the nine months ended  December 31, 2021. The Company’s liquidity is highly dependent on its ability to increase revenues and gross margin, its ability to control its operating costs, and its ability to raise additional capital, if necessary.  The impact of the COVID-19 pandemic on the global financing markets  may reduce the Company's ability to raise additional capital, if necessary, which could negatively impact the Company's liquidity.  There can be no assurance that the Company will be able to continue to raise additional capital, on favorable terms or at all, from other sources or execute on any other means of improving liquidity described above.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2022-08-03):
[0001437749-22-018630:note_history:10]
As part of the Neeltran Acquisition, the Company identified four equipment financing agreements that Neeltran had entered into prior to the acquisition on  May 6, 2021. The Company determined to account for these agreements as a debt transaction and recorded current and long-term debt liabilities of $0.1 million each during the three months ended  June 30, 2021. The current and long term debt balance is $0.1 million each as of the three months ended  June 30, 2022.
  (was, 2022-02-02, similarity 0.8105):
[0001437749-22-002208:note_history:10]
As part of the Neeltran Acquisition, the Company identified four equipment financing agreements that Neeltran had entered into prior to the acquisition on  May 6, 2021. The Company determined to account for these agreements as a debt transaction and recorded current and long-term debt liabilities of $0.1 million each during the nine months ended  December 31, 2021.


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2022-08-03):
[0001437749-22-018630:note_history:11]
|  |  | Three Months Ended June 30, 2022 |  |
| Product Line: |  | Grid |  |  | Wind |  |
| Equipment and systems |  | $ | 18,077 |  |  | $ | 1,973 |  |
| Services and technology development |  |  | 1,753 |  |  |  | 877 |  |
| Total |  | $ | 19,829 |  |  | $ | 2,850 |  |
| Region: |  |  |  |  |  |  |  |  |
| Americas |  | $ | 16,902 |  |  |  | — |  |
| Asia Pacific |  |  | 2,677 |  |  |  | 2,850 |  |
| EMEA |  |  | 250 |  |  |  | — |  |
| Total |  | $ | 19,829 |  |  | $ | 2,850 |  |
  (was, 2022-02-02, similarity 0.6269):
[0001437749-22-002208:note_history:11]
|  |  | Three Months Ended December 31, 2021 |  |  | Nine Months Ended December 31, 2021 |  |
| Product Line: |  | Grid |  |  | Wind |  |  | Grid |  |  | Wind |  |
| Equipment and systems |  | $ | 23,416 |  |  | $ | 1,309 |  |  | $ | 67,605 |  |  | $ | 4,168 |  |
| Services and technology development |  |  | 1,634 |  |  |  | 440 |  |  |  | 5,564 |  |  |  | 2,789 |  |
| Total |  | $ | 25,050 |  |  | $ | 1,749 |  |  | $ | 73,169 |  |  | $ | 6,957 |  |
| Region: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas |  | $ | 16,739 |  |  | $ | 56 |  |  | $ | 57,498 |  |  | $ | 134 |  |
| Asia Pacific |  |  | 7,064 |  |  |  | 1,690 |  |  |  | 10,931 |  |  |  | 6,781 |  |
| EMEA |  |  | 1,247 |  |  |  | 3 |  |  |  | 4,740 |  |  |  | 42 |  |
| Total |  | $ | 25,050 |  |  | $ | 1,749 |  |  | $ | 73,169 |  |  | $ | 6,957 |  |

- changed (2022-08-03):
[0001437749-22-018630:note_history:12]
|  |  | Three Months Ended June 30, 2021 |  |
| Product Line: |  | Grid |  |  | Wind |  |
| Equipment and systems |  | $ | 21,159 |  |  | $ | 1,033 |  |
| Services and technology development |  |  | 2,342 |  |  |  | 886 |  |
| Total |  | $ | 23,501 |  |  | $ | 1,919 |  |
| Region: |  |  |  |  |  |  |  |  |
| Americas |  | $ | 22,645 |  |  | $ | 19 |  |
| Asia Pacific |  |  | 598 |  |  |  | 1,870 |  |
| EMEA |  |  | 258 |  |  |  | 30 |  |
| Total |  | $ | 23,501 |  |  | $ | 1,919 |  |
  (was, 2022-02-02, similarity 0.7051):
[0001437749-22-002208:note_history:12]
|  |  | Three Months Ended December 31, 2020 |  |  | Nine Months Ended December 31, 2020 |  |
| Product Line: |  | Grid |  |  | Wind |  |  | Grid |  |  | Wind |  |
| Equipment and systems |  | $ | 15,930 |  |  | $ | 6,153 |  |  | $ | 47,729 |  |  | $ | 12,828 |  |
| Services and technology development |  |  | 1,156 |  |  |  | 393 |  |  |  | 3,420 |  |  |  | 1,984 |  |
| Total |  | $ | 17,086 |  |  | $ | 6,546 |  |  | $ | 51,149 |  |  | $ | 14,812 |  |
| Region: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas |  | $ | 13,394 |  |  | $ | 14 |  |  | $ | 39,626 |  |  | $ | 56 |  |
| Asia Pacific |  |  | 351 |  |  |  | 6,461 |  |  |  | 6,736 |  |  |  | 14,463 |  |
| EMEA |  |  | 3,341 |  |  |  | 71 |  |  |  | 4,787 |  |  |  | 293 |  |
| Total |  | $ | 17,086 |  |  | $ | 6,546 |  |  | $ | 51,149 |  |  | $ | 14,812 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2022-08-03):
[0001437749-22-018630:note_history:13]
The Company’s revenues in its Grid business segment are derived primarily through enabling the transmission and distribution of power, providing planning services that allow it to identify power grid needs and risks, and developing ship protection systems for the U.S. Navy. The Company’s revenues in its Wind business segment are derived primarily through supplying advanced power electronics and control systems, licensing its highly engineered wind turbine designs, and providing extensive customer support services to wind turbine manufacturers. The Company records revenue based on a five-step model in accordance with ASC 606. For its customer contracts, the Company identifies the performance obligations, determines the transaction price, allocates the contract transaction price to the performance obligations, and recognizes the revenue when (or as) control of goods or services is transferred to the customer. In the three months ended  June 30, 2022 and 2021, 70% and 78% of revenue, respectively, was recognized at the point in time when control transferred to the customer, with the remainder being recognized over time.
  (was, 2022-02-02, similarity 0.8932):
[0001437749-22-002208:note_history:13]
The Company’s revenues in its Grid business segment are derived primarily through enabling the transmission and distribution of power, providing planning services that allow it to identify power grid needs and risks, and developing ship protection systems for the U.S. Navy. The Company’s revenues in its Wind business segment are derived primarily through supplying advanced power electronics and control systems, licensing its highly engineered wind turbine designs, and providing extensive customer support services to wind turbine manufacturers. The Company records revenue based on a five-step model in accordance with ASC 606. For its customer contracts, the Company identifies the performance obligations, determines the transaction price, allocates the contract transaction price to the performance obligations, and recognizes the revenue when (or as) control of goods or services is transferred to the customer. In the three and nine months ended  December 31, 2021, 79% and 76% of revenue, respectively, was recognized at the point in time when control transferred to the customer, with the remainder being recognized over time. In the three and nine months ended  December 31, 2020, 78% and 79% of revenue, respectively, was recognized at the point in time when control transferred to the customer, with the remainder being recognized over time.

- changed (2022-08-03):
[0001437749-22-018630:note_history:14]
The Company's equipment and system product line includes certain contracts which do not meet the requirements of an exchange transaction and therefore do not fall within the scope of ASC 606.  As these non-exchange transaction contracts are considered grant revenue and do not fall within any specific accounting literature, the Company follows guidance within ASC 606 by analogy to recognize grant revenue over time.  The Company recorded no grant revenue in the three months ended  June 30, 2022 and $0.5 million in grant revenue in the three months ended  June 30, 2021.
  (was, 2022-02-02, similarity 0.6348):
[0001437749-22-002208:note_history:14]
The Company's equipment and system product line includes certain contracts which do not meet the requirements of an exchange transaction and therefore do not fall within the scope of ASC 606.  As these non-exchange transaction contracts are considered grant revenue and do not fall within any specific accounting literature, the Company follows guidance within ASC 606 by analogy to recognize grant revenue over time.  In the three and nine months ended  December 31, 2021, the Company recorded $0.1 million and $0.9 million in grant revenue, respectively, which is included in the Company’s Grid business segment revenue. In the three and nine months ended  December 31, 2020, the Company recorded $1.1 million and $1.8 million in grant revenue, respectively, which is included in the Company's Grid segment revenue.

- changed (2022-08-03):
[0001437749-22-018630:note_history:15]
In the Company's service and technology development product line, there are several different types of transactions and each begins with a contract with a customer that summarizes each product sold to a customer, which typically represent distinct performance obligations. The technology development transactions are primarily for activities that have no alternative use and for which a profit can be expected throughout the life of the contract. In these cases, the revenue is recognized over time, but in the instances where a reasonable profit margin cannot be assured throughout the entire contract, the revenue is recognized at a point in time. Each contract's transaction price is allocated to each distinct performance obligation using the respective standalone selling price which is determined primarily using the cost-plus expected margin approach. The ongoing service transactions are for service contracts that provide benefit to the customer simultaneously as the Company performs its obligations, and therefore this revenue is recognized ratably over time throughout the effective period of these contracts. The transaction prices on these contracts are allocated based on an adjusted market approach which is reassessed annually for reasonableness. The field service transactions include contracts for delivery of goods and completion of services made at the customer's requests, which are not deemed satisfied until the work has been completed and/or the requested goods have been delivered, so all of this revenue is recognized at the point in time when the control changes, and at allocated prices based on the adjusted market approach driven by standard price lists. The royalty transactions are related to certain contract terms on transactions in the Company's equipment and systems product line based on activity as specified in the contracts. The transaction prices of these agreements are calculated based on an adjusted market approach as specified in the contract. The Company reports royalty revenue for usage-based royalties when the sales have occurred. In circumstances when collectability is not assured and a contract does not exist under ASC 606, revenue is deferred until a non-refundable payment has been received for substantially all the amount that is due and there are no further remaining performance obligations.
  (was, 2022-02-02, similarity 0.9998):
[0001437749-22-002208:note_history:15]
In the Company's service and technology development product line, there are several different types of transactions and each begins with a contract with a customer that summarizes each product sold to a customer, which typically represent distinct performance obligations. The technology development transactions are primarily for activities that have no alternative use and for which a profit can be expected throughout the life of the contract. In these cases, the revenue is recognized over time, but in the instances where a reasonable profit margin cannot be assured throughout the entire contract, the revenue is recognized at a point in time. Each contract's transaction price is allocated to each distinct performance obligation using the respective standalone selling price which is determined primarily using the cost-plus expected margin approach. The ongoing service transactions are for service contracts that provide benefit to the customer simultaneously as the Company performs its obligations, and therefore this revenue is recognized ratably over time throughout the effective period of these contracts. The transaction prices on these contracts are allocated based on an adjusted market approach which is re-assessed annually for reasonableness. The field service transactions include contracts for delivery of goods and completion of services made at the customer's requests, which are not deemed satisfied until the work has been completed and/or the requested goods have been delivered, so all of this revenue is recognized at the point in time when the control changes, and at allocated prices based on the adjusted market approach driven by standard price lists. The royalty transactions are related to certain contract terms on transactions in the Company's equipment and systems product line based on activity as specified in the contracts. The transaction prices of these agreements are calculated based on an adjusted market approach as specified in the contract. The Company reports royalty revenue for usage-based royalties when the sales have occurred. In circumstances when collectability is not assured and a contract does not exist under ASC 606, revenue is deferred until a non-refundable payment has been received for substantially all the amount that is due and there are no further remaining performance obligations.

- changed (2022-08-03):
[0001437749-22-018630:note_history:16]
|  |  | Three Months Ended June 30, 2022 |  |
| Product Line: |  | Grid |  |  | Wind |  |
| Equipment and systems |  | $ | 18,077 |  |  | $ | 1,973 |  |
| Services and technology development |  |  | 1,753 |  |  |  | 877 |  |
| Total |  | $ | 19,829 |  |  | $ | 2,850 |  |
| Region: |  |  |  |  |  |  |  |  |
| Americas |  | $ | 16,902 |  |  |  | — |  |
| Asia Pacific |  |  | 2,677 |  |  |  | 2,850 |  |
| EMEA |  |  | 250 |  |  |  | — |  |
| Total |  | $ | 19,829 |  |  | $ | 2,850 |  |
  (was, 2022-02-02, similarity 0.6269):
[0001437749-22-002208:note_history:16]
|  |  | Three Months Ended December 31, 2021 |  |  | Nine Months Ended December 31, 2021 |  |
| Product Line: |  | Grid |  |  | Wind |  |  | Grid |  |  | Wind |  |
| Equipment and systems |  | $ | 23,416 |  |  | $ | 1,309 |  |  | $ | 67,605 |  |  | $ | 4,168 |  |
| Services and technology development |  |  | 1,634 |  |  |  | 440 |  |  |  | 5,564 |  |  |  | 2,789 |  |
| Total |  | $ | 25,050 |  |  | $ | 1,749 |  |  | $ | 73,169 |  |  | $ | 6,957 |  |
| Region: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas |  | $ | 16,739 |  |  | $ | 56 |  |  | $ | 57,498 |  |  | $ | 134 |  |
| Asia Pacific |  |  | 7,064 |  |  |  | 1,690 |  |  |  | 10,931 |  |  |  | 6,781 |  |
| EMEA |  |  | 1,247 |  |  |  | 3 |  |  |  | 4,740 |  |  |  | 42 |  |
| Total |  | $ | 25,050 |  |  | $ | 1,749 |  |  | $ | 73,169 |  |  | $ | 6,957 |  |

- changed (2022-08-03):
[0001437749-22-018630:note_history:17]
|  |  | Three Months Ended June 30, 2021 |  |
| Product Line: |  | Grid |  |  | Wind |  |
| Equipment and systems |  | $ | 21,159 |  |  | $ | 1,033 |  |
| Services and technology development |  |  | 2,342 |  |  |  | 886 |  |
| Total |  | $ | 23,501 |  |  | $ | 1,919 |  |
| Region: |  |  |  |  |  |  |  |  |
| Americas |  | $ | 22,645 |  |  | $ | 19 |  |
| Asia Pacific |  |  | 598 |  |  |  | 1,870 |  |
| EMEA |  |  | 258 |  |  |  | 30 |  |
| Total |  | $ | 23,501 |  |  | $ | 1,919 |  |
  (was, 2022-02-02, similarity 0.7051):
[0001437749-22-002208:note_history:17]
|  |  | Three Months Ended December 31, 2020 |  |  | Nine Months Ended December 31, 2020 |  |
| Product Line: |  | Grid |  |  | Wind |  |  | Grid |  |  | Wind |  |
| Equipment and systems |  | $ | 15,930 |  |  | $ | 6,153 |  |  | $ | 47,729 |  |  | $ | 12,828 |  |
| Services and technology development |  |  | 1,156 |  |  |  | 393 |  |  |  | 3,420 |  |  |  | 1,984 |  |
| Total |  | $ | 17,086 |  |  | $ | 6,546 |  |  | $ | 51,149 |  |  | $ | 14,812 |  |
| Region: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas |  | $ | 13,394 |  |  | $ | 14 |  |  | $ | 39,626 |  |  | $ | 56 |  |
| Asia Pacific |  |  | 351 |  |  |  | 6,461 |  |  |  | 6,736 |  |  |  | 14,463 |  |
| EMEA |  |  | 3,341 |  |  |  | 71 |  |  |  | 4,787 |  |  |  | 293 |  |
| Total |  | $ | 17,086 |  |  | $ | 6,546 |  |  | $ | 51,149 |  |  | $ | 14,812 |  |

- changed (2022-08-03):
[0001437749-22-018630:note_history:18]
As of  June 30, 2022, and 2021, the Company’s contract assets and liabilities primarily relate to the timing differences between cash received from a customer in connection with contractual rights to invoicing and the timing of revenue recognition following completion of performance obligations. The Company's accounts receivable balance is made up entirely of customer contract related balances. Changes in the Company’s contract assets, which are included in “Unbilled accounts receivable” and “Deferred program costs” (see Note 8, “Accounts Receivable” and Note 9, “Inventory” for a reconciliation to the condensed consolidated balance sheets) and "Contract liabilities", which are included in the current portion and long-term portion of "Deferred revenue" in the Company’s condensed consolidated balance sheets, are as follows (in thousands):
  (was, 2022-02-02, similarity 0.9928):
[0001437749-22-002208:note_history:18]
As of  December 31, 2021, and 2020, the Company’s contract assets and liabilities primarily relate to the timing differences between cash received from a customer in connection with contractual rights to invoicing and the timing of revenue recognition following completion of performance obligations. The Company's accounts receivable balance is made up entirely of customer contract related balances. Changes in the Company’s contract assets, which are included in “Unbilled accounts receivable” and “Deferred program costs” (see Note 8, “Accounts Receivable” and Note 9, “Inventory” for a reconciliation to the condensed consolidated balance sheets) and "Contract liabilities", which are included in the current portion and long-term portion of "Deferred revenue" in the Company’s condensed consolidated balance sheets, are as follows (in thousands):

- changed (2022-08-03):
[0001437749-22-018630:note_history:19]
|  |  | Unbilled Accounts Receivable |  |  | Deferred Program Costs |  |  | Contract Liabilities |  |
| Beginning balance as of March 31, 2022 |  | $ | 6,492 |  |  | $ | 858 |  |  | $ | 30,034 |  |
| Increases for costs incurred to fulfill performance obligations |  |  | — |  |  |  | 406 |  |  |  |  |  |
| Increase (decrease) due to customer billings |  |  | (4,710 | ) |  |  |  |  |  |  | 17,852 |  |
| Decrease due to cost recognition on completed performance obligations |  |  | — |  |  |  | (365 | ) |  |  |  |  |
| Increase (decrease) due to recognition of revenue based on transfer of control of performance obligations |  |  | 2,128 |  |  |  |  |  |  |  | (13,737 | ) |
| Other changes and FX impact |  |  | — |  |  |  | (25 | ) |  |  | (394 | ) |
| Ending balance as of June 30, 2022 |  | $ | 3,910 |  |  | $ | 874 |  |  | $ | 33,755 |  |
  (was, 2022-02-02, similarity 0.9046):
[0001437749-22-002208:note_history:19]
|  |  | Unbilled Accounts Receivable |  |  | Deferred Program Costs |  |  | Contract Liabilities |  |
| Beginning balance as of March 31, 2021 |  | $ | 5,765 |  |  | $ | 977 |  |  | $ | 21,257 |  |
| Increases for costs incurred to fulfill performance obligations |  |  | — |  |  |  | 3,140 |  |  |  | — |  |
| Increase for balances acquired |  |  | — |  |  |  | 634 |  |  |  | 10,048 |  |
| Increase (decrease) due to customer billings |  |  | (11,214 | ) |  |  | — |  |  |  | 55,354 |  |
| Decrease due to cost recognition on completed performance obligations |  |  | — |  |  |  | (4,128 | ) |  |  | — |  |
| Increase (decrease) due to recognition of revenue based on transfer of control of performance obligations |  |  | 12,186 |  |  |  | — |  |  |  | (55,318 | ) |
| Other changes and FX impact |  |  | — |  |  |  | (8 | ) |  |  | 137 |  |
| Ending balance as of December 31, 2021 |  | $ | 6,737 |  |  | $ | 615 |  |  | $ | 31,478 |  |

- changed (2022-08-03):
[0001437749-22-018630:note_history:20]
|  |  | Unbilled Accounts Receivable |  |  | Deferred Program Costs |  |  | Contract Liabilities |  |
| Beginning balance as of March 31, 2021 |  | $ | 5,765 |  |  | $ | 978 |  |  | $ | 21,258 |  |
| Increases for costs incurred to fulfill performance obligations |  |  | — |  |  |  | 1,434 |  |  |  | — |  |
| Increase for balance acquired |  |  | — |  |  |  | 634 |  |  |  | 10,048 |  |
| Increase (decrease) due to customer billings |  |  | (1,564 | ) |  |  | — |  |  |  | 21,425 |  |
| Decrease due to cost recognition on completed performance obligations |  |  | — |  |  |  | (2,041 | ) |  |  | — |  |
| Increase (decrease) due to recognition of revenue based on transfer of control of performance obligations |  |  | 4,360 |  |  |  | — |  |  |  | (24,355 | ) |
| Other changes and FX impact |  |  | — |  |  |  | 3 |  |  |  | 246 |  |
| Ending balance as of June 30, 2021 |  | $ | 8,561 |  |  | $ | 1,008 |  |  | $ | 28,622 |  |
  (was, 2022-02-02, similarity 0.9799):
[0001437749-22-002208:note_history:20]
|  |  | Unbilled Accounts Receivable |  |  | Deferred Program Costs |  |  | Contract Liabilities |  |
| Beginning balance as of March 31, 2020 |  | $ | 5,711 |  |  | $ | 1,631 |  |  | $ | 26,142 |  |
| Increases for costs incurred to fulfill performance obligations |  |  | — |  |  |  | 6,635 |  |  |  | — |  |
| Increase for balance acquired |  |  | 101 |  |  |  | — |  |  |  | 2,700 |  |
| Increase (decrease) due to customer billings |  |  | (8,255 | ) |  |  | — |  |  |  | 42,785 |  |
| Decrease due to cost recognition on completed performance obligations |  |  | — |  |  |  | (6,969 | ) |  |  | — |  |
| Increase (decrease) due to recognition of revenue based on transfer of control of performance obligations |  |  | 6,644 |  |  |  | — |  |  |  | (48,274 | ) |
| Other changes and FX impact |  |  | — |  |  |  | 33 |  |  |  | 1,025 |  |
| Ending balance as of December 31, 2020 |  | $ | 4,201 |  |  | $ | 1,330 |  |  | $ | 24,378 |  |

- changed (2022-08-03):
[0001437749-22-018630:note_history:21]
The Company’s remaining performance obligations represent the unrecognized revenue value of the Company’s contractual commitments. The Company’s performance obligations  may vary significantly each reporting period based on the timing of major new contractual commitments. As of  June 30, 2022, the Company had outstanding performance obligations on existing contracts under ASC 606 to be recognized in the next twelve months of approximately $101.5 million. There are also approximately $13.1 million of outstanding performance obligations to be recognized over a period of thirteen to sixty months. The remaining performance obligations are subject to customer actions and therefore the timing of revenue recognition cannot be reasonably estimated. The twelve-month performance obligations include anticipated shipments to Inox based on the twelve-month rolling forecast provided by Inox on the multi-year supply contract. The quantities specified in any forecast provided by Inox related to the multi-year supply contract are firm and irrevocable for the first three months of a twelve-month rolling forecast. The timing of the performance obligations beyond the twelve-month forecast provided by Inox are not determinable and therefore are not included in the total remaining performance obligations.
  (was, 2022-02-02, similarity 0.9953):
[0001437749-22-002208:note_history:21]
The Company’s remaining performance obligations represent the unrecognized revenue value of the Company’s contractual commitments. The Company’s performance obligations  may vary significantly each reporting period based on the timing of major new contractual commitments. As of  December 31, 2021, the Company had outstanding performance obligations on existing contracts under ASC 606 to be recognized in the next twelve months of approximately $80.6 million. There are also approximately $8.0 million of outstanding performance obligations to be recognized over a period of thirteen to sixty months. The remaining performance obligations are subject to customer actions and therefore the timing of revenue recognition cannot be reasonably estimated. The twelve-month performance obligations include anticipated shipments to Inox based on the twelve-month rolling forecast provided by Inox on the multi-year supply contract. The quantities specified in any forecast provided by Inox related to the multi-year supply contract are firm and irrevocable for the first three months of a twelve-month rolling forecast. The timing of the performance obligations beyond the twelve-month forecast provided by Inox are not determinable and therefore are not included in the total remaining performance obligations.

- changed (2022-08-03):
[0001437749-22-018630:note_history:22]
The following table sets forth customers who represented 10% or more of the Company’s total revenues for the three months ended  June 30, 2022 and 2021:
  (was, 2022-02-02, similarity 0.936):
[0001437749-22-002208:note_history:22]
The following table sets forth customers who represented 10% or more of the Company’s total revenues for the three and nine months ended  December 31, 2021 and 2020:

- added (2022-08-03):
[0001437749-22-018630:note_history:23]
|  |  |  | Three Months Ended |  |
|  | Reportable |  | June 30, |  |
|  | Segment |  | 2022 |  |  | 2021 |  |
| Micron Technology | Grid |  |  | <10 | % |  |  | 21 | % |
| Nextera Energy Resources | Grid |  |  | — |  |  |  | 12 | % |
| SGL Carbon LLC | Grid |  |  | 10 | % |  |  | <10 | % |
| Ascend Performance Materials Ops LLC | Grid |  |  | <10 | % |  |  | 10 | % |

- removed (2022-08-03):
[0001437749-22-002208:note_history:24]
|  |  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  | Reportable |  | December 31, |  |  | December 31, |  |
|  | Segment |  | 2021 |  |  | 2020 |  |  | 2021 |  |  | 2020 |  |
| Inox Wind Limited | Wind |  | <10% |  |  |  | 24 | % |  |  | <10% |  |  |  | 12 | % |
| Fuji Bridex PTE Ltd | Grid |  | 20 | % |  |  | <10% |  |  |  | 10 | % |  |  | <10% |  |
| EPC Services | Grid |  | <10% |  |  |  | 14 | % |  |  | <10% |  |  |  | 17 | % |
