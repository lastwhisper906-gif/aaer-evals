# AMSC MD&A — 0001437749-22-018630


## mdna

[0001437749-22-018630:mdna:1]
[same as prior period, unchanged from 0001437749-22-002208:mdna:1]

[0001437749-22-018630:mdna:2]
American Superconductor®, Amperium®, AMSC®, D-VAR®, PowerModule™, D-VAR VVO®, PQ-IVR®, SeaTitan®, Gridtec™ Solutions, Windtec™ Solutions, Smarter, Cleaner...Better Energy™, Orchestrate the Rhythm and Harmony of Power on the Grid™, actiVAR®, armorVAR™, NEPSI™ and Neeltran™ and SafetyLOCK™ are trademarks or registered trademarks of American Superconductor Corporation or our subsidiaries. We reserve all of our rights with respect to our trademarks or registered trademarks regardless of whether they are so designated in this Quarterly Report on Form 10-Q by an ® or ™ symbol. All other brand names, product names, trademarks or service marks appearing in this Quarterly Report on Form 10-Q are the property of their respective holders.

[0001437749-22-018630:mdna:3]
[same as prior period, unchanged from 0001437749-22-002208:mdna:3]

[0001437749-22-018630:mdna:4]
[same as prior period, unchanged from 0001437749-22-002208:mdna:4]

[0001437749-22-018630:mdna:5]
[same as prior period, unchanged from 0001437749-22-002208:mdna:5]

[0001437749-22-018630:mdna:6]
[same as prior period, unchanged from 0001437749-22-002208:mdna:6]

[0001437749-22-018630:mdna:7]
[same as prior period, unchanged from 0001437749-22-002208:mdna:7]

[0001437749-22-018630:mdna:8]
|  | • | Grid. Through our Gridtec™ Solutions, our Grid business segment enables electric utilities and renewable energy project developers to connect, transmit and distribute power with exceptional efficiency, reliability, security and affordability. We provide transmission planning services that allow us to identify power grid congestion, poor power quality, and other risks, which help us determine how our solutions can improve network performance. These services often lead to sales of our grid interconnection solutions for wind farms and solar power plants, power quality systems and transmission and distribution cable systems. We also sell ship protection products to the U.S. Navy through our Grid business segment. |

[0001437749-22-018630:mdna:9]
|  | • | Wind. Through our Windtec™ Solutions, our Wind business segment enables manufacturers to field wind turbines with exceptional power output, reliability and affordability. We supply advanced power electronics and control systems, license our highly engineered wind turbine designs, and provide extensive customer support services to wind turbine manufacturers. Our design portfolio includes a broad range of drivetrains and power ratings of 2 MW and higher. We provide a broad range of power electronics and software-based control systems that are highly integrated and designed for optimized performance, efficiency, and grid compatibility. |

[0001437749-22-018630:mdna:10]
Our fiscal year begins on April 1 and ends on March 31. When we refer to a particular fiscal year, we are referring to the fiscal year that began on April 1 of that same year. For example, fiscal 2022 refers to the fiscal year that began on April 1, 2022. Other fiscal years follow similarly.

[0001437749-22-018630:mdna:11]
On October 31, 2018, we entered into a Subcontract Agreement with Commonwealth Edison Company (“ComEd”) (the “Subcontract Agreement”) for the manufacture and installation of the Company’s resilient electric grid ("REG") system within ComEd’s electric grid in Chicago, Illinois (the “Project”). As provided in the Subcontract Agreement, the Subcontract Agreement became effective upon the signing of an amendment by us and the U.S. Department of Homeland Security (“DHS”) to the existing contract (the “Prime Contract”) between us and DHS on June 20, 2019. Unless terminated earlier by us, ComEd or DHS according to the terms of the Subcontract Agreement, the term of the Subcontract Agreement will continue until we complete our warranty obligations under the Subcontract Agreement. Under the terms of the Subcontract Agreement, we agreed, among other things, to provide the REG system and to supervise ComEd’s installation of the REG system in Chicago. As part of our separate cost sharing arrangement with DHS under the Prime Contract, we received funding provided by DHS in connection with the Subcontract Agreement of approximately $10.0 million, which represents the total amount of revenue we recognized over the term of the Subcontract Agreement and includes $1.0 million that we have agreed to reimburse ComEd for costs incurred by ComEd while undertaking its tasks under the Subcontract Agreement (the “Reimbursement Amount”). In addition, we are required to deliver an irrevocable letter of credit in the amount of $5.0 million to secure certain Company obligations under the Subcontract Agreement, which we have done, and deposited $5.0 million in an escrow account as collateral to secure such letter of credit.  ComEd has agreed to provide the site and provide all civil engineering work required to support the operation and integration of the REG system into ComEd’s electric grid. Other than the Reimbursement Amount, ComEd is responsible for its own costs and expenses. DHS’s approval to commence with construction was obtained on June 20, 2019. Substation work on the project began in late 2019 and we successfully integrated the REG system on Com Ed's electric power grid and the REG system became fully operational in August 2021.

[0001437749-22-018630:mdna:12]
The COVID-19 pandemic continues to rapidly evolve. We are experiencing substantial inflationary pressure in our supply chain, some delays in sourcing materials needed for our products and some production disruption resulting from higher than typical employee absenteeism which have increased our cost of revenues and decreased gross margin. The extent to which the pandemic impacts our business, liquidity, results of operations and financial condition will depend on future developments, which are highly uncertain and cannot be predicted with confidence. Changes in macroeconomic and market conditions arising from the COVID-19 pandemic, or for other reasons, such as the ongoing war between Russia and Ukraine, including inflation, labor force availability, sourcing, material delays and global supply chain disruptions could have a material adverse effect on our business, financial condition and results of operation.

[0001437749-22-018630:mdna:13]
[same as prior period, unchanged from 0001437749-22-002208:mdna:17]

[0001437749-22-018630:mdna:14]
The preparation of the unaudited condensed consolidated financial statements requires that we make estimates and judgments that affect the reported amounts of assets, liabilities, revenues and expenses, and related disclosure of contingent assets and liabilities. We base our estimates on historical experience and various other assumptions that are believed to be reasonable under the circumstances, the results of which form the basis for making judgments about the carrying values of assets and liabilities that are not readily apparent from other sources. Actual results may differ under different assumptions or conditions. There were no significant changes in the critical accounting policies that were disclosed in our Annual Report on Form 10-K for the fiscal year ended March 31, 2022.

[0001437749-22-018630:mdna:15]
[same as prior period, unchanged from 0001437749-22-002208:mdna:19]

[0001437749-22-018630:mdna:16]
Three months ended June 30, 2022, compared to the three months ended June 30, 2021

[0001437749-22-018630:mdna:17]
[same as prior period, unchanged from 0001437749-22-002208:mdna:21]

[0001437749-22-018630:mdna:18]
Total revenues decreased 11% to $22.7 million for the three months ended June 30, 2022, compared to $25.4 million for the three months ended June 30, 2021.  Our revenues are summarized as follows (in thousands):

[0001437749-22-018630:mdna:19]
|  |  | Three Months Ended June 30, |  |
|  |  | 2022 |  |  | 2021 |  |
| Revenues: |  |  |  |  |  |  |  |  |
| Grid |  | $ | 19,829 |  |  | $ | 23,501 |  |
| Wind |  |  | 2,850 |  |  |  | 1,919 |  |
| Total |  | $ | 22,679 |  |  | $ | 25,420 |  |

[0001437749-22-018630:mdna:20]
Our Grid business unit accounted for 87% of total revenues for the three months ended June 30, 2022, compared to 92% for the three months ended June 30, 2021. Our Grid business unit revenues decreased 16% to $19.8 million in the three months ended June 30, 2022, from $23.5 million in the three months ended June 30, 2021. The decrease in the Grid business unit revenue in the three months ended June 30, 2022, was primarily driven by lower D-VAR revenues than in the prior year period.

[0001437749-22-018630:mdna:21]
Our Wind business unit accounted for 13% of total revenues for the three months ended June 30, 2022, compared to 8% for the three months ended June 30, 2021.  Revenues in the Wind business unit increased 49% to $2.9 million in the three months ended June 30, 2022, from $1.9 million in the three months ended June 30, 2021. The increase in the three months ended June 30, 2022, was driven by additional shipments of electrical control systems ("ECS") to Inox in the period ended June 30, 2022.

[0001437749-22-018630:mdna:22]
[same as prior period, unchanged from 0001437749-22-002208:mdna:26]

[0001437749-22-018630:mdna:23]
Cost of revenues decreased by 7% to $20.5 million for the three months ended June 30, 2022, compared to $22.1 million for the three months ended June 30, 2021. Gross margin was 10% for the three months ended June 30, 2022, compared to 13% for the three months ended June 30, 2021.  The decrease in gross margin in the three months ended June 30, 2022, was due to lower revenues, an unfavorable product mix, inflation pressure in our supply chain and some delays in sourcing materials due to the COVID-19 pandemic.

[0001437749-22-018630:mdna:24]
[same as prior period, unchanged from 0001437749-22-002208:mdna:28]

[0001437749-22-018630:mdna:25]
[same as prior period, unchanged from 0001437749-22-002208:mdna:29]

[0001437749-22-018630:mdna:26]
Research and development ("R&D") expense decreased 12% in the three months ended June 30, 2022 to $2.7 million from $3.0 million in the three months ended June 30, 2021. The decrease in R&D expense was due to lower overall compensation expense.

[0001437749-22-018630:mdna:27]
[same as prior period, unchanged from 0001437749-22-002208:mdna:31]

[0001437749-22-018630:mdna:28]
Selling, general and administrative ("SG&A") expenses increased 6% in the three months ended June 30, 2022, to $7.6 million from $7.1 million in the three months ended June 30, 2021. The increase in SG&A expense in the three months ended June 30, 2022, was due to higher overall compensation expense than in the prior year period.

[0001437749-22-018630:mdna:29]
[same as prior period, unchanged from 0001437749-22-002208:mdna:33]

[0001437749-22-018630:mdna:30]
We recorded amortization expense related to our core technology and know-how, customer relationships, and other intangible assets of $0.7 million in the three months ended June 30, 2022 and $0.6 million in the three months ended June 30, 2021.  The increase in amortization expense is a result of additional expense relating to Neeltran.

[0001437749-22-018630:mdna:31]
[same as prior period, unchanged from 0001437749-22-002208:mdna:35]

[0001437749-22-018630:mdna:32]
The change in fair value of our contingent consideration for the earnout payment on the NEPSI Acquisition resulted in a loss of $0.2 million in the three months ended June 30, 2022, compared to a loss of $0.1 million in the three months ended June 30, 2021. The change in the fair value was primarily driven by an increased likelihood of achieving certain revenue targets.

[0001437749-22-018630:mdna:33]
[same as prior period, unchanged from 0001437749-22-002208:mdna:37]

[0001437749-22-018630:mdna:34]
[same as prior period, unchanged from 0001437749-22-002208:mdna:38]

[0001437749-22-018630:mdna:35]
|  |  | Three Months Ended June 30, |  |
|  |  | 2022 |  |  | 2021 |  |
| Operating loss: |  |  |  |  |  |  |  |  |
| Grid |  | $ | (7,281 | ) |  | $ | (5,345 | ) |
| Wind |  |  | (386 | ) |  |  | (763 | ) |
| Unallocated corporate expenses |  |  | (1,202 | ) |  |  | (1,391 | ) |
| Total |  | $ | (8,869 | ) |  | $ | (7,499 | ) |

[0001437749-22-018630:mdna:36]
Our Grid business segment generated operating losses of $7.3 million in the three months ended June 30, 2022, compared to $5.3 million in the three months ended June 30, 2021. The increase in the Grid business unit operating loss in the three months ended June 30, 2022 was due to lower revenues and gross margins, and additional operating expenses.

[0001437749-22-018630:mdna:37]
Our Wind business segment generated operating losses of $0.4 million in the three months ended June 30, 2022, compared to an operating loss of $0.8 million in the three months ended June 30, 2021. The decrease in the Wind business unit operating loss was due to additional revenues and higher gross margins driven by additional shipments of ECS than in the year ago period.

[0001437749-22-018630:mdna:38]
Unallocated corporate expenses included a loss on contingent consideration of $0.2 million in the three months ended June 30, 2022. Unallocated corporate expenses included a loss on contingent consideration of $0.1 million in the three months ended June 30, 2021. Additionally, unallocated corporate expenses included stock-based compensation expense of $1.0 million and $1.3 million in the three months ended June 30, 2022 and 2021, respectively.

[0001437749-22-018630:mdna:39]
[same as prior period, unchanged from 0001437749-22-002208:mdna:43]

[0001437749-22-018630:mdna:40]
Interest income, net, was less than $0.1 million in both the three months ended June 30, 2022 and June 30, 2021, respectively.

[0001437749-22-018630:mdna:41]
[same as prior period, unchanged from 0001437749-22-002208:mdna:45]

[0001437749-22-018630:mdna:42]
Other income, net, was $0.2 million in the three months ended June 30, 2022, compared to other expense, net, of less than $0.1 million in the three months ended June 30, 2021. The increase in other income during the period ended June 30, 2022, was driven by the impacts of favorable fluctuations in foreign currencies.

[0001437749-22-018630:mdna:43]
[same as prior period, unchanged from 0001437749-22-002208:mdna:47]

[0001437749-22-018630:mdna:44]
Income tax expense was less than $0.1 million in the three months ended June 30, 2022. Income tax benefit was $2.1 million in the three months ended June 30, 2021. The increase in income tax expense in the three month period ended June 30, 2022 is due primarily to the tax benefit from the acquisition of all of the issued and outstanding shares of capital stock of Neeltran and International (the "Neeltran Acquisition") in the period ended June 30, 2021.

[0001437749-22-018630:mdna:45]
[same as prior period, unchanged from 0001437749-22-002208:mdna:49]

[0001437749-22-018630:mdna:46]
Net loss was $8.7 million in the three months ended June 30, 2022, compared to $5.4 million in the three months ended June 30, 2021.  The increase in net loss was driven primarily by the income tax benefit of $2.1 million from the acquisition of Neeltran in the period ended June 30, 2021.

[0001437749-22-018630:mdna:47]
[same as prior period, unchanged from 0001437749-22-002208:mdna:51]

[0001437749-22-018630:mdna:48]
Generally, a non-GAAP financial measure is a numerical measure of a company’s performance, financial position or cash flow that either excludes or includes amounts that are not normally excluded or included in the most directly comparable measure calculated and presented in accordance with GAAP. The non-GAAP measures included in this Quarterly Report on Form 10-Q, however, should be considered in addition to, and not as a substitute for or superior to the comparable measures prepared in accordance with GAAP.

[0001437749-22-018630:mdna:49]
[same as prior period, unchanged from 0001437749-22-002208:mdna:53]

[0001437749-22-018630:mdna:50]
|  |  | Three Months Ended June 30, |  |
|  |  | 2022 |  |  | 2021 |  |
| Net loss |  | $ | (8,710 | ) |  | $ | (5,403 | ) |
| Stock-based compensation |  |  | 1,033 |  |  |  | 1,292 |  |
| Amortization of acquisition-related intangibles |  |  | 712 |  |  |  | 622 |  |
| Acquisition costs |  |  | — |  |  |  | 688 |  |
| Change in fair value of contingent consideration |  |  | 170 |  |  |  | 100 |  |
| Non-GAAP net loss |  | $ | (6,795 | ) |  | $ | (2,701 | ) |
| Non-GAAP net loss per share - basic |  | $ | (0.25 | ) |  | $ | (0.10 | ) |
| Weighted average shares outstanding - basic |  |  | 27,560 |  |  |  | 26,826 |  |

[0001437749-22-018630:mdna:51]
We incurred non-GAAP net losses of $6.8 million or $0.25 per share, for the three months ended June 30, 2022, compared to $2.7 million or $0.10, for the three months ended June 30, 2021. The increase in the non-GAAP net loss for the three months ended June 30, 2022 was due to a higher operating loss driven by lower gross margin and higher operating expenses.

[0001437749-22-018630:mdna:52]
[same as prior period, unchanged from 0001437749-22-002208:mdna:56]

[0001437749-22-018630:mdna:53]
We have experienced recurring operating losses, and as of June 30, 2022, had an accumulated deficit of $1,029 million.

[0001437749-22-018630:mdna:54]
[same as prior period, unchanged from 0001437749-22-002208:mdna:58]

[0001437749-22-018630:mdna:55]
[same as prior period, unchanged from 0001437749-22-002208:mdna:59]

[0001437749-22-018630:mdna:56]
As of June 30, 2022, we had cash, cash equivalents and restricted cash of $43.1 million, compared to $49.5 million as of March 31, 2022, a decrease of $6.4 million. As of June 30, 2022, we had approximately $2.1 million of cash, cash equivalents, and restricted cash in foreign bank accounts. Our cash, cash equivalents, and restricted cash are summarized as follows (in thousands):

[0001437749-22-018630:mdna:57]
|  |  | June 30, 2022 |  |  | March 31, 2022 |  |
| Cash and cash equivalents |  | $ | 33,355 |  |  | $ | 40,584 |  |
| Restricted cash |  |  | 9,735 |  |  |  | 8,902 |  |
| Total cash, cash equivalents, and restricted cash |  | $ | 43,090 |  |  | $ | 49,486 |  |

[0001437749-22-018630:mdna:58]
For the three months ended June 30, 2022, net cash used in operating activities was $5.9 million, compared to $5.8 million for the three months ended June 30, 2021.  The increase in net cash used in operations was due primarily to an increase in inventory purchases offset by accounts receivable collections in the three months ended June 30, 2022 as compared to June 30, 2021.

[0001437749-22-018630:mdna:59]
For the three months ended June 30, 2022, net cash used in investing activities was $0.5 million, compared to $11.7 million for the three months ended June 30, 2021. The decrease in net cash used in investing activities was primarily due to the cash that was used to pay for the Neeltran Acquisition in the three months ended June 30, 2021. There was no such transaction in the three months ended June 30, 2022.

[0001437749-22-018630:mdna:60]
For the three months ended June 30, 2022 and 2021, respectively, net cash used in financing activities remained consistent at less than $0.1 million.

[0001437749-22-018630:mdna:61]
As of June 30, 2022, we had $6.0 million of restricted cash included in long-term assets and $3.8 million of restricted cash included in current assets.  These amounts of restricted cash primarily represent deposits to secure letters of credit for various supply contracts and long-term projects, including the irrevocable letter of credit in the amount of $5.0 million to secure certain of our obligations under the Subcontract Agreement with ComEd. These deposits are held in interest bearing accounts.

[0001437749-22-018630:mdna:62]
We are a party to many contractual obligations involving commitments to make payments to third parties. These obligations impact our short-term and long-term liquidity and capital resource needs. Certain contractual obligations are reflected on the consolidated balance sheet as of June 30, 2022, while others are considered future commitments. We have various contractual arrangements, under which we have committed to purchase certain minimum quantities of goods or services on an annual basis. For information regarding our other contractual obligations, refer to Note 13, "Contingent Consideration," Note 14, "Debt," Note 15, "Leases" and Note 16, "Commitments and Contingencies" to our condensed consolidated financial statements included elsewhere in this Quarterly Report on Form 10-Q.

[0001437749-22-018630:mdna:63]
[same as prior period, unchanged from 0001437749-22-002208:mdna:68]

[0001437749-22-018630:mdna:64]
Legal Proceedings

[0001437749-22-018630:mdna:65]
We are involved in legal and administrative proceedings and claims of various types. See Part II, Item 1, “Legal Proceedings,” for additional information. We record a liability in our consolidated financial statements for these matters when a loss is known or considered probable and the amount can be reasonably estimated. We review these estimates each accounting period as additional information is known and adjust the loss provision when appropriate. If a matter is both probable to result in liability and the amounts of loss can be reasonably estimated, we estimate and disclose the possible loss or range of loss to the extent necessary to make the consolidated financial statements not misleading. If the loss is not probable or cannot be reasonably estimated, a liability is not recorded in our consolidated financial statements.

[0001437749-22-018630:mdna:66]
[same as prior period, unchanged from 0001437749-22-002208:mdna:75]

[0001437749-22-018630:mdna:67]
In June 2016, the FASB issued ASU 2016-13, Financial Instruments-Credit Losses (Topic 326): Measurement of Credit Losses on Financial Instruments. The amendments in ASU 2016-13 will provide more decision-useful information about the expected credit losses on financial instruments and other commitments to extend credit held by a reporting entity at each reporting date. Following the release of ASU 2019-10 in November 2019, the new effective date, as long as we remain a smaller reporting company, would be annual reporting periods beginning after December 15, 2022. We are currently evaluating the impact, if any, that the adoption of ASU 2016-13 may have on our consolidated financial statements.

[0001437749-22-018630:mdna:68]
In October 2021, the FASB issued ASU 2021-08, Business Combinations (Topic 805): Accounting for Contract Assets and Contract Liabilities from Contracts with Customers. The amendments in ASU 2021-08 will improve the accounting for acquired revenue contracts with customers in a business combination. Following the release of ASU 2021-08 in October 2021, the new effective date will be annual reporting periods beginning after December 15, 2022. We are currently evaluating the impact, if any, that the adoption of ASU 2021-08 may have on our consolidated financial statements.

[0001437749-22-018630:mdna:69]
In November 2021, the FASB issued ASU 2021-10, Government Assistance (Topic 832): Disclosures by Business Entities about Government Assistance. The amendments in ASU 2021-10 improve financial reporting by requiring disclosures that increase the transparency of transactions with government accounted for by applying a grant or contribution accounting model by analogy. Following the release of ASU 2021-10 in November 2021, the effective date was annual reporting periods beginning after December 15, 2021. As of April 1, 2022, we have adopted ASU 2021-10 and noted no material impact on our consolidated financial statements.

[0001437749-22-018630:mdna:70]
We do not believe that, outside of those disclosed here, there are any other recently issued accounting pronouncements that will have a material impact on our consolidated financial statements.
