# AMSC MD&A — 0001564590-13-001183


## mdna

[0001564590-13-001183:mdna:1]
[same as prior period, unchanged from 0001193125-13-324142:mdna:1]

[0001564590-13-001183:mdna:2]
commercial uses of superconductor products are limited today, and a widespread commercial market for our products may not develop; there are a number of technological challenges that must be successfully addressed before our superconductor products can gain widespread commercial acceptance, and our inability to address such technological challenges could adversely affect our ability to acquire customers for our products; we have not manufactured our Amperium wire in commercial quantities, and a failure to manufacture our Amperium wire in commercial quantities at acceptable cost and quality levels would substantially limit our future revenue and profit potential; third parties have or may acquire patents that cover the materials, processes and technologies we use or may use in the future to manufacture our Amperium products, and our success depends on our ability to license such patents or other proprietary rights; our technology and products could infringe intellectual property rights of others, which may require costly litigation and, if we are not successful, could cause us to pay substantial damages and disrupt our business; we have filed a demand for arbitration and other lawsuits against our former largest customer, Sinovel, regarding amounts we contend are overdue. We cannot be certain as to the outcome of these proceedings; we have been named as a party to purported stockholder class actions and stockholder derivative complaints, and we may be named in additional litigation, all of which will require significant management time and attention, result in significant legal expenses and may result in an unfavorable outcome, which could have a material adverse effect on our business, operating results and financial condition; our 7% convertible note contains warrants and provisions that could limit our ability to repay the note in shares of common stock and should the note be repaid in stock, shareholders could experience significant dilution; our common stock has experienced, and may continue to experience, significant market price and volume fluctuations, which may prevent our stockholders from selling our common stock at a profit and could lead to costly litigation against us that could divert our management’s attention. These and the important factors discussed under the caption “Risk Factors” in Part 1. Item 1A of our Form 10-K for the fiscal year ended March 31, 2013, among others, could cause actual results to differ materially from those indicated by forward-looking statements made herein and presented elsewhere by management from time to time. Any such forward-looking statements represent management’s estimates as of the date of this Quarterly Report on Form 10-Q. While we may elect to update such forward-looking statements at some point in the future, we disclaim any obligation to do so, even if subsequent events cause our views to change. These forward-looking statements should not be relied upon as representing our views as of any date subsequent to the date of this Quarterly Report on Form 10-Q.

[0001564590-13-001183:mdna:3]
American Superconductor®, Amperium®, AMSC®, D-VAR®, PowerModuleTM, PQ-IVR®, SeaTitanTM, Gridtec SolutionsTM, Windtec SolutionsTM and Smarter, Cleaner... Better EnergyTM are trademarks or registered trademarks of American Superconductor Corporation or its subsidiaries. We reserve all of our rights with respect to our trademarks or registered trademarks regardless of whether they are so designated in this Quarterly Report on Form 10-Q by an ® or TM symbol. All other brand names, product names, trademarks or service marks appearing in this Quarterly Report on Form 10-Q are the property of their respective holders.

[0001564590-13-001183:mdna:4]
[same as prior period, unchanged from 0001193125-13-324142:mdna:4]

[0001564590-13-001183:mdna:5]
American Superconductor Corporation was founded on April 9, 1987. We are a leading provider of megawatt-scale solutions that lower the cost of wind power and enhance the performance of the power grid. In the wind power market, we enable manufacturers to field highly competitive wind turbines through our advanced power electronics products, engineering, and support services. In the power grid market, we enable electric utilities and renewable energy project developers to connect, transmit and distribute power through our transmission planning services and power electronics and superconductor-based products. Our wind and power grid products and services provide exceptional reliability, security, efficiency and affordability to our customers.

[0001564590-13-001183:mdna:6]
Our wind and power grid solutions help to improve energy efficiency, alleviate power grid capacity constraints and increase the adoption of renewable energy generation. Demand for our solutions is driven by the growing needs for renewable sources of electricity, such as wind and solar energy, and for modernized smart grids that improve power reliability and quality. Concerns about these factors have led to increased spending by corporations as well as supportive government regulations and initiatives on local, state, national and global levels, including renewable portfolio standards, tax incentives and international treaties.

[0001564590-13-001183:mdna:7]
We manufacture products using two proprietary core technologies: PowerModule™ programmable power electronic converters and our Amperium® HTS (High Temperature Superconductor) wires. These technologies and our system-level solutions are protected by a broad and deep intellectual property portfolio consisting of hundreds of patents and licenses worldwide.

[0001564590-13-001183:mdna:8]
30

[0001564590-13-001183:mdna:9]
We operate our business under two market-facing business units: Wind and Grid. We believe this market-centric structure enables us to more effectively anticipate and meet the needs of wind turbine manufacturers, power generation project developers and electric utilities.

[0001564590-13-001183:mdna:10]
| · | Wind. Through our Windtec Solutions, our Wind business segment enables manufacturers to field wind turbines with exceptional power output, reliability and affordability. We supply advanced power electronics and control systems, license our highly engineered wind turbine designs, and provide extensive customer support services to wind turbine manufacturers. Our design portfolio includes a broad range of drive trains and power ratings. We provide a broad range of power electronics and software-based control systems that are highly integrated and redesigned for optimized performance, efficiency, and grid compatibility. |

[0001564590-13-001183:mdna:11]
| · | Grid. Through our Gridtec Solutions, our Grid business segment enables electric utilities and renewable energy project developers to connect, transmit and distribute power with exceptional efficiency, reliability and affordability. We provide transmission planning services that allow us to identify power grid congestion, poor power quality and other risks, which help us determine how our solutions can improve network performance. These services often lead to sales of grid interconnection solutions for wind farms and solar power plants, power quality systems and transmission and distribution cable systems. |

[0001564590-13-001183:mdna:12]
Our fiscal year begins on April 1 and ends on March 31. When we refer to a particular fiscal year, we are referring to the fiscal year beginning on April 1 of that same year. For example, fiscal 2013 refers to the fiscal year beginning on April 1, 2013. Other fiscal years follow similarly.

[0001564590-13-001183:mdna:13]
On April 4, 2012, we completed a private placement of a $25.0 million senior convertible note (the “Initial Note”) with Capital Ventures International (“CVI”), an affiliate of Heights Capital Management. On December 20, 2012, we entered into an Amendment and Exchange Agreement (the “Amendment”) with CVI, pursuant to which we exchanged the Initial Note for a new unsecured, senior convertible note (the “Exchanged Note”), which had the same principal amount and accrued interest as the Initial Note at the time of the exchange. On October 9, 2013, we entered into a Second Amendment and Warrant Exchange Agreement (the “Second Amendment”) with CVI which (i) waived certain provisions of the Amended Purchase Agreement, (ii) amended certain provisions of the Exchanged Note, and (iii) exchanged the warrant for a new warrant (the “Exchanged Warrant”), with a reduced exercise price of $2.61 per share of common stock. Other than the reduced exercise price, the Exchanged Warrant has the same terms and conditions as the original warrant. On June 5, 2012, we entered into a $10.0 million Loan and Security Agreement (“Term Loan”) with Hercules Technology Growth Capital, Inc. See Liquidity and Capital Resources below for further discussion of these financing arrangements.

[0001564590-13-001183:mdna:14]
We have experienced recurring operating losses and as of September 30, 2013, had an accumulated deficit of $825.3 million. In addition, we have experienced recurring negative operating cash flows, which have resulted in a reduction of our cash balance. These factors raise substantial doubt regarding our ability to continue as a going concern. Our financial statements do not include any adjustments that might result from the outcome of this uncertainty. At September 30, 2013, we had cash and cash equivalents of $25.9 million. Cash used in operations for the six months ended September 30, 2013 was $14.8 million.

[0001564590-13-001183:mdna:15]
In order for us to continue operations beyond the next twelve months and be able to discharge our liabilities and commitments in the normal course of business, we need to increase sales through executing our strategy to broaden our customer base, enter new markets, and commercialize our superconductor product line. In addition, we may need to further reduce operating expenses in line with business conditions in order to decrease the amount of cash used in operations.  We must also seek new financing arrangements, including, but not limited to, new debt and/or equity financing, and continue to work with the holder of our convertible note in order to maintain the ability to make monthly amortization payments on the convertible note in shares of common stock. In addition, we are actively seeking to sell our minority investments in Tres Amigas and Blade Dynamics and have recently engaged a financial advisor to assist with that effort. There can be no assurance that we will be able to raise additional capital or sell one or both of these investments on commercially reasonable terms or at all.

[0001564590-13-001183:mdna:16]
In response to the Sinovel situation discussed below and challenging market conditions, particularly in the wind power market, from April 1, 2011 through the date of this filing, the Company has substantially reduced its global workforce. In addition, we plan to consolidate certain of our office locations. These workforce reductions and planned office consolidations are expected to lower operating costs and enhance liquidity.

[0001564590-13-001183:mdna:17]
31

[0001564590-13-001183:mdna:18]
Our cash requirements depend on numerous factors, including the ability to pay the principal and interest on the Exchanged Note in stock, successful completion of our product development activities, ability to commercialize our product prototypes, rate of customer and market adoption of our products, collecting receivables according to established terms, and the continued availability of U.S. government funding during the product development phase in our Superconductors business. Significant deviations to our business plan with regard to these factors, which are important drivers to our business, could have a material adverse effect on our operating performance, financial condition, and future business prospects. We expect to pursue the expansion of our operations through internal growth, diversification of our customer base, and potential strategic alliances. See below for a discussion of liquidity and capital resources.

[0001564590-13-001183:mdna:19]
During March 2011, we engaged in discussions with Sinovel regarding the acceptance of its scheduled shipments, outstanding receivables, and the delivery of a custom solution desired by Sinovel for low voltage ride through (“LVRT”) that required a modification to our existing LVRT design. The custom design required modified software and additional hardware. Toward the end of March, Sinovel requested that we provide them with the additional hardware without additional cost. On March 31, 2011, we proposed to Sinovel that we would provide the additional hardware without additional cost if Sinovel would accept the scheduled shipments. Sinovel rejected this proposal due to what we were told was excess inventory of our components. Since Sinovel did not give us the requisite notice under our contracts that they intended to delay deliveries, we believe that these actions constitute material breaches of our contracts.

[0001564590-13-001183:mdna:20]
As of the date of this filing, we have not received payment from Sinovel for any outstanding receivables nor have we been notified as to when, if ever, Sinovel will accept contracted shipments that were scheduled for delivery after March 31, 2011. Additionally, based, in part, upon evidence obtained through an internal investigation and a criminal investigation conducted by Austrian authorities regarding the actions of a former employee of our Austrian subsidiary, we believe that Sinovel illegally obtained and used our intellectual property in violation of civil and criminal intellectual property laws. In July 2011, a former employee of our Austrian subsidiary was arrested in Austria on charges of economic espionage and fraudulent manipulation of data. In September 2011, the former employee pled guilty to the charges, and was imprisoned. The evidence presented during the court hearing showed that this former employee was contracted by Sinovel through an intermediary while employed by us and improperly obtained and transferred to Sinovel portions of our wind turbine control software source code developed for Sinovel’s 1.5MW wind turbines. On June 27, 2013, the U.S. Department of Justice, following an investigation by the Federal Bureau of Investigation, charged Sinovel and two of its employees with the theft of our proprietary software code and the use of that intellectual property in four 1.5 MW Sinovel turbines that have been installed in the Massachusetts towns of Charlestown, Fairhaven, and Scituate. These parties that have installed Sinovel turbines and their contractors are not implicated in any way. Except for portions of this 1.5MW wind turbine software, we do not believe that the source code for any other turbines, such as the 3MW, 5MW and 6MW wind turbines that were designed by and co-developed with us have been transferred to Sinovel. Moreover, we believe the evidence shows this former employee illegally used source code to develop, for Sinovel, a software modification to circumvent the encryption and remove technical protection measures on the PM3000 power converters in 1.5MW wind turbines in the field. We believe that only the binary code, or upper layer, of the PM3000 software developed to circumvent the encryption and remove technical protection measures was transferred to Sinovel. We do not believe that any PM3000 source code was transferred to Sinovel. These actions potentially enable Sinovel to deploy, independent of us, wind turbine control software, including a low voltage ride through solution, on all of its 1.5MW wind turbines in the field. In addition, by having the wind turbine control source code, Sinovel could potentially modify the source code to allow the use of core electrical components, including power converters, from other manufacturers.

[0001564590-13-001183:mdna:21]
On September 13, 2011, we commenced a series of legal actions in China against Sinovel. We filed a claim for arbitration in Beijing, China to compel Sinovel to pay us for past product shipments and to accept all contracted but not yet delivered core electrical components and spare parts under all existing contracts with us. The arbitration claim was filed with the Beijing Arbitration Commission in accordance with the terms of our supply contracts with Sinovel. We also filed civil and criminal complaints against Sinovel.

[0001564590-13-001183:mdna:22]
We cannot provide any assurance as to the outcome of these legal actions. For more information about these legal proceedings, see Part II, Item 1, “Legal Proceedings.”

[0001564590-13-001183:mdna:23]
32

[0001564590-13-001183:mdna:24]
[same as prior period, unchanged from 0001193125-13-324142:mdna:23]

[0001564590-13-001183:mdna:25]
The preparation of the unaudited condensed consolidated financial statements requires that we make estimates and judgments that affect the reported amounts of assets, liabilities, revenues and expenses, and related disclosure of contingent assets and liabilities. We base our estimates on historical experience and various other assumptions that are believed to be reasonable under the circumstances, the results of which form the basis for making judgments about the carrying values of assets and liabilities that are not readily apparent from other sources. Actual results may differ under different assumptions or conditions. There were no significant changes in the critical accounting policies during the six months ended September 30, 2013 that were disclosed in our Form 10-K for fiscal 2012, which ended on March 31, 2013.

[0001564590-13-001183:mdna:26]
[same as prior period, unchanged from 0001193125-13-324142:mdna:25]

[0001564590-13-001183:mdna:27]
Three and six months ended September 30, 2013 compared to the three and six months ended September 30, 2012

[0001564590-13-001183:mdna:28]
[same as prior period, unchanged from 0001193125-13-324142:mdna:27]

[0001564590-13-001183:mdna:29]
Total revenues increased by 16% and decreased by 5% to $24.2 million and $47.3 million, respectively, for the three and six months ended September 30, 2013, respectively, compared to $20.9 million and $49.6 million for the three and six months ended September 30, 2012, respectively. Our revenues are summarized as follows (in thousands):

[0001564590-13-001183:mdna:30]
|  | Three months ended September 30, |  |  | Six months ended September 30, |  |
|  | 2013 |  |  | 2012 |  |  | 2013 |  |  | 2012 |  |
| Revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Wind | $ | 14,691 |  |  | $ | 12,002 |  |  | $ | 29,392 |  |  | $ | 28,513 |  |
| Grid |  | 9.490 |  |  |  | 8,865 |  |  |  | 17,875 |  |  |  | 21,070 |  |
| Total | $ | 24,181 |  |  | $ | 20,867 |  |  | $ | 47,267 |  |  | $ | 49,583 |  |

[0001564590-13-001183:mdna:31]
Our Wind business unit accounted for 61% and 62% of total revenues for the three and six months ended September 30, 2013, respectively, compared to 58% for both the three and six months ended September 30, 2012. Revenues in the Wind business unit increased 22% and 3% to $14.7 million and $29.4 million in the three and six months ended September 30, 2013, respectively, from $12.0 million and $28.5 million in the three and six months ended September 30, 2012, respectively. Wind business unit revenues during the three and six months ended September 30, 2013 increased primarily due to higher revenues from customers in both India and China for our electrical control systems, partially offset by lower revenues in Korea.

[0001564590-13-001183:mdna:32]
Our Grid business unit accounted for 39% and 38% of total revenues for the three and six months ended September 30, 2013, respectively, compared to 42% for both the three and six months ended September 30, 2012. Our Grid business unit revenues increased 7% and decreased 15% to $9.5 million and $17.9 million in the three and six months ended September 30, 2013, respectively, from $8.9 million and $21.1 million in the three and six months ended September 30, 2012, respectively. Grid business unit revenues increased in the three months ended September 30, 2013 primarily due to a large Amperium® wire shipment to a customer in Korea, while decreasing for the six months ended September 30, 2013 due primarily to lower D-VAR system revenues as a result of a large project in Australia in the prior year period.

[0001564590-13-001183:mdna:33]
Project HYDRA is a project with Consolidated Edison, Inc. which is being partially funded by the Department of Homeland Security (“DHS”). DHS is expected to invest up to a total of $29.0 million in the development of a new HTS power grid technology called Resilient Electric Grid systems. This fault current limiting cable system is designed to utilize customized Amperium® HTS wires, and ancillary controls to deliver more power through the grid while also being able to suppress power surges that can disrupt service. On July 8, 2013, DHS committed the additional $8.6 million in funding on Project HYDRA. DHS has now committed 100% of the total expected funding for this project. Consolidated Edison and Southwire Company are our subcontractors on this project. We recorded $1.0 million and $1.1 million of revenue on this project for the three and six months ended September 30, 2013, respectively, and $0.8 million and $1.1 million for the three and six months ended September 30, 2012, respectively.

[0001564590-13-001183:mdna:34]
The following table sets forth customers who represented 10% or more of our total revenues for the three and six months ended September 30, 2013 and 2012:

[0001564590-13-001183:mdna:35]
|  | Three months ended September 30, |  |  | Six months ended September 30, |  |
|  | 2013 |  |  | 2012 |  |  | 2013 |  |  | 2012 |  |
| Beijing JINGCHENG New Energy Co., Ltd |  | 28 | % |  |  | 26 | % |  |  | 31 | % |  |  | 22 | % |
| INOX Wind Limited |  | 27 | % |  |  | 19 | % |  |  | 21 | % |  |  | 17 | % |
| Karara Mining Ltd |  | <10 | % |  |  | <10 | % |  |  | <10 | % |  |  | 13 | % |

[0001564590-13-001183:mdna:36]
[same as prior period, unchanged from 0001193125-13-324142:mdna:35]

[0001564590-13-001183:mdna:37]
Cost of revenues was $22.6 million and $40.6 million for the three and six months ended September 30, 2013, respectively, compared to $20.4 million and $37.3 million for the three and six months ended September 30, 2012, respectively. Gross margin was 6.5% and 14.1% for the three and six months ended September 30, 2013, respectively, compared to 2.3% and 24.8% for the three and six months ended September 30, 2012, respectively. The increase in gross margin for the three months ended September 30, 2013 as compared to the same period in fiscal 2012 was primarily due to increased consumption of previously written off inventory in the current year period, partially offset by settlements of certain adverse purchase order liabilities resulting in a benefit to cost of revenues of $1.0 million in the prior year period which did not recur. The decrease in gross margin for the six months ended September 30, 2013 was primarily due to non-recurring settlements of certain adverse purchase order liabilities resulting in a benefit to cost of revenues of $8.3 million in the prior year period.  In addition there were lower payments received in the current year period from certain Chinese customers for past shipments for which revenue is recognized upon cash collection as compared to the six month period ended September 30, 2012. Costs associated with this revenue were recorded in prior periods when the inventory was shipped and therefore such revenue contributes 100% gross margin.

[0001564590-13-001183:mdna:38]
[same as prior period, unchanged from 0001193125-13-324142:mdna:37]

[0001564590-13-001183:mdna:39]
[same as prior period, unchanged from 0001193125-13-324142:mdna:38]

[0001564590-13-001183:mdna:40]
A portion of our R&D expenditures related to externally funded development contracts has been classified as cost of revenues (rather than as R&D expenses). Additionally, a portion of R&D expenses was offset by cost-sharing funding. Our R&D expenditures are summarized as follows (in thousands):

[0001564590-13-001183:mdna:41]
|  | Three months ended September 30, |  |  | Six months ended September 30, |  |
|  | 2013 |  |  | 2012 |  |  | 2013 |  |  | 2012 |  |
| R&D expenses per unaudited condensed consolidated statements of operations | $ | 3,083 |  |  | $ | 3,621 |  |  | $ | 6,110 |  |  | $ | 7,532 |  |
| R&D expenditures reclassified as cost of revenues |  | 3,009 |  |  |  | 4,280 |  |  |  | 4,935 |  |  |  | 7,140 |  |
| R&D expenditures offset by cost-sharing funding |  | 117 |  |  |  | 100 |  |  |  | 199 |  |  |  | 193 |  |
| Aggregated R&D expenses | $ | 6,209 |  |  | $ | 8,001 |  |  | $ | 11,244 |  |  | $ | 14,865 |  |

[0001564590-13-001183:mdna:42]
R&D expenses (exclusive of amounts classified as cost of revenues and amounts offset by cost-sharing funding) decreased by 15% and 19% to $3.1 million and $6.1 million for the three and six months ended September 30, 2013, respectively, from $3.6 million and $7.5 million for the three and six months ended September 30, 2012, respectively. The decreases in R&D expenses were driven primarily by the realization of savings from cost reduction actions that were implemented in fiscal 2012. The decreases in R&D expenditures reclassified to costs of revenue were a result of decreased activity under license and development contracts for wind turbine designs compared to the prior year periods. Aggregated R&D expenses, which include amounts classified as cost of revenues and amounts offset by cost-sharing funding, decreased 22% and 24% to $6.2 million and $11.2 million for the three and six months ended September 30, 2013, respectively, from $8.0 million and $14.9 million for the three and six months ended September 30, 2012, respectively.

[0001564590-13-001183:mdna:43]
We present aggregated R&D, which is a non-GAAP measure, because we believe this presentation provides useful information on our aggregate R&D spending and because R&D expenses as reported on the unaudited condensed consolidated statements of income have been, and may in the future be, subject to significant fluctuations solely as a result of changes in the level of externally funded contract development work, resulting in significant changes in the amount of the costs recorded as costs of revenues rather than as R&D expenses, as discussed above.

[0001564590-13-001183:mdna:44]
[same as prior period, unchanged from 0001193125-13-324142:mdna:43]

[0001564590-13-001183:mdna:45]
SG&A expenses decreased by 26% and 24% to $8.7 million and $19.5 million in the three and six months ended September 30, 2013, respectively, from $11.7 million and $25.5 million in the three and six months ended September 30, 2012, respectively. The decreases in SG&A expenses were due primarily to the realization of savings from cost reductions actions that were implemented in fiscal 2012 as well as a reduction in legal costs.

[0001564590-13-001183:mdna:46]
[same as prior period, unchanged from 0001193125-13-324142:mdna:45]

[0001564590-13-001183:mdna:47]
We recorded amortization expense related to our core technology and know-how, trade names and trademark intangible assets of $0.1 million and $0.2 million in the three and six month periods ended September 30, 2013, respectively, compared to $0.1 million and $0.2 million in the three and six month periods ended September 30, 2012, respectively.

[0001564590-13-001183:mdna:48]
[same as prior period, unchanged from 0001193125-13-324142:mdna:47]

[0001564590-13-001183:mdna:49]
We recorded $0.8 million of restructuring charges in both the three and six months ended September 30, 2013. We recorded restructuring and impairment charges of $0.1 million in the six months ended September 30, 2012. These amounts in the three and six months ended September 30, 2013 consist primarily of employee severance and benefit costs related to our reduction in force undertaken in July 2013.

[0001564590-13-001183:mdna:50]
Operating loss

[0001564590-13-001183:mdna:51]
Our operating loss is summarized as follows (in thousands):

[0001564590-13-001183:mdna:52]
|  | Three months ended September 30, |  |  | Six months ended September 30, |  |
|  | 2013 |  |  | 2012 |  |  | 2013 |  |  | 2012 |  |
| Operating loss: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Wind | $ | (2,449 | ) |  | $ | (6,449 | ) |  | $ | (4,274 | ) |  | $ | (5,148 | ) |
| Grid |  | (5,750 | ) |  |  | (6,572 | ) |  |  | (10,618 | ) |  |  | (11,915 | ) |
| Unallocated corporate expenses |  | (2,829 | ) |  |  | (1,949 | ) |  |  | (4,985 | ) |  |  | (4,035 | ) |
| Total | $ | (11,028 | ) |  | $ | (14,970 | ) |  | $ | (19,877 | ) |  | $ | (21,098 | ) |

[0001564590-13-001183:mdna:53]
Our Wind segment generated operating losses of $2.5 million and $4.3 million in the three and six months ended September 30, 2013, respectively, compared to operating losses of $6.4 million and $5.1 million in the three and six months ended September 30, 2012, respectively. The decreases in Wind business unit operating losses were primarily due to higher gross profit in the three and six months ended September 30, 2013, due to the impact of cost reductions and a favorable sales mix as well as lower operating expenses as a result of cost reduction efforts during fiscal 2012 and 2013, partially offset by the settlement of certain adverse purchase order liabilities in the prior year.

[0001564590-13-001183:mdna:54]
The operating losses of our Grid segment decreased to $5.8 million and $10.6 million in the three and six months ended September 30, 2013, respectively, compared to $6.6 million and $11.9 million in the three and six months ended September 30, 2012, respectively. The decreases in the Grid business unit operating losses were primarily due to lower operating expenses in the three and six months ended September 30, 2013, as a result of the reductions in force and reduced discretionary spending, and for the six months ended September 30, 2013, partially offset by lower D-VAR revenue.

[0001564590-13-001183:mdna:55]
Unallocated corporate expenses primarily include stock-based compensation expense of $2.2 million and $4.3 million for the three and six months ended September 30, 2013, respectively, and $2.0 million and $4.0 million for the three and six months ended September 30, 2012, respectively. In addition, $0.7 million was included in unallocated corporate expenses for restructuring charges in the current year periods primarily as a result of a reduction in force taken during the second quarter ended September 30, 2013.

[0001564590-13-001183:mdna:56]
[same as prior period, unchanged from 0001193125-13-324142:mdna:55]

[0001564590-13-001183:mdna:57]
The change in fair value of derivatives and warrants resulted in gains of $0.9 million and $1.4 million in the three and six months ended September 30, 2013, respectively, compared to gains of $3.3 million and $0.9 million for the three and six months ended September 30, 2012, respectively. The changes were primarily driven by a lower stock price during the three and six months ended September 30, 2013, compared to a higher stock price during the same periods in fiscal 2012, which is a key valuation variable, as well as a reduction in the principal outstanding on the convertible note due to payments to the note holder in shares of common stock.

[0001564590-13-001183:mdna:58]
Interest expense, net

[0001564590-13-001183:mdna:59]
Interest expense, net, was $3.5 million and $5.6 million in the three and six months ended September 30, 2013, respectively, compared to $2.9 million and $5.6 million in the three and six months ended September 30, 2012, respectively. The increases in interest expense were due primarily to additional non-cash interest expense of $1.8 million and $0.2 million in the three months ended September 30, 2013 and 2012, resulting from the discount available to CVI on stock used to settle principal and interest on the convertible note. The higher non-cash interest expense was partially offset by lower cash interest expense and debt discount amortization due to lower debt balances in the current fiscal year.

[0001564590-13-001183:mdna:60]
Other expense, net

[0001564590-13-001183:mdna:61]
Other expense, net, was $0.6 million in both the three and six months ended September 30, 2013, compared to $1.3 million and $1.1 million in the three and six months ended September 30, 2012, respectively. The decreases in other expense, net, were driven primarily by lower minority interest recorded from our investment in Blade Dynamics, as we no longer meet the criteria to account for our investment under the equity method.

[0001564590-13-001183:mdna:62]
[same as prior period, unchanged from 0001193125-13-324142:mdna:61]

[0001564590-13-001183:mdna:63]
In the three and six months ended September 30, 2013, we recorded an income tax expense of $0.3 million and $0.4 million, respectively, compared to income tax expense of $0.1 million and a benefit of $0.8 million in the three and six months ended September 30, 2012, respectively. The increases in income tax expense were primarily due to increased income taxes in foreign jurisdictions as well as withholding taxes for repatriation of funds from certain foreign jurisdictions. The income benefit for the six months ended September 30, 2012 was due to a refund of Chinese income taxes.

[0001564590-13-001183:mdna:64]
Non-GAAP Measures

[0001564590-13-001183:mdna:65]
Generally, a non-GAAP financial measure is a numerical measure of a company’s performance, financial position or cash flow that either excludes or includes amounts that are not normally excluded or included in the most directly comparable measure calculated and presented in accordance with GAAP. The non-GAAP measures included in this Form 10-Q, however, should be considered in addition to, and not as a substitute for or superior to the comparable measure prepared in accordance with GAAP.

[0001564590-13-001183:mdna:66]
We define non-GAAP net loss as net loss before adverse purchase commitment (recoveries) losses, net, stock-based compensation, amortization of acquisition-related intangibles, restructuring and impairment charges, changes in fair value of derivatives and warrants, non-cash interest expense, and the other non-cash or unusual items indicated in the table below. We believe non-GAAP net loss assists management and investors in comparing our performance across reporting periods on a consistent basis by excluding these non-cash or non-recurring charges that we do not believe are indicative of our core operating performance. We also regard non-GAAP net loss as a useful measure of operating performance which more closely aligns net loss with cash used in/provided by continuing operations. In addition, we use non-GAAP net loss as a factor in evaluating management’s performance when determining incentive compensation and to evaluate the effectiveness of our business strategies. A reconciliation of non-GAAP to GAAP net loss is set forth in the table below (in thousands, except per share data):

[0001564590-13-001183:mdna:67]
|  | Three months ended September 30, |  |  | Six months ended September 30, |  |
|  | 2013 |  |  | 2012 |  |  | 2013 |  |  | 2012 |  |
| Net loss | $ | (14,623 | ) |  | $ | (15,949 | ) |  | $ | (25,135 | ) |  | $ | (26,224 | ) |
| Adverse purchase commitment recoveries, net |  | — |  |  |  | (1,009 | ) |  |  | — |  |  |  | (8,309 | ) |
| Stock-based compensation |  | 2,152 |  |  |  | 2,044 |  |  |  | 4,287 |  |  |  | 4,039 |  |
| Amortization of acquisition-related intangibles |  | 82 |  |  |  | 80 |  |  |  | 164 |  |  |  | 161 |  |
| Restructuring and impairment charges |  | 751 |  |  |  | 16 |  |  |  | 764 |  |  |  | 143 |  |
| Sinovel litigation |  | (5 | ) |  |  | 304 |  |  |  | (7 | ) |  |  | 424 |  |
| Consumption of zero cost-basis inventory |  | (1,319 | ) |  |  | (401 | ) |  |  | (2,493 | ) |  |  | (788 | ) |
| Change in fair value of derivatives and warrants |  | (886 | ) |  |  | (3,285 | ) |  |  | (1,355 | ) |  |  | (897 | ) |
| Non-cash interest expense |  | 3,093 |  |  |  | 2,161 |  |  |  | 4,765 |  |  |  | 4,443 |  |
| Non-GAAP net loss | $ | (10,755 | ) |  | $ | (16,039 | ) |  | $ | (19,010 | ) |  | $ | (27,008 | ) |
| Non-GAAP loss per share | $ | (0.18 | ) |  | $ | (0.31 | ) |  | $ | (0.32 | ) |  | $ | (0.52 | ) |
| Weighted average shares outstanding |  | 61,116 |  |  |  | 51,907 |  |  |  | 59,712 |  |  |  | 51,551 |  |

[0001564590-13-001183:mdna:68]
We incurred a non-GAAP net loss of $10.8 million and $19.0 million or $0.18 and $0.32 per share, for the three and six months ended September 30, 2013, respectively, compared to a non-GAAP net loss of $16.0 million and $27.0 million, or $0.31 and $0.52 per share, for the three and six months ended September 30, 2012, respectively. The decreases in the non-GAAP net loss were driven primarily by lower net losses as a result of cost saving reductions undertaken in fiscal 2012 and 2013, partially offset by a decrease in adverse purchase commitment recovery from the prior year and higher gains resulting from the change in fair value of derivative and warrants.

[0001564590-13-001183:mdna:69]
[same as prior period, unchanged from 0001193125-13-324142:mdna:68]

[0001564590-13-001183:mdna:70]
At September 30, 2013, we had cash, cash equivalents, and restricted cash of $32.8 million, compared to $50.2 million at March 31, 2013, a decrease of $17.4 million. Our cash and cash equivalents, and restricted cash are summarized as follows (in thousands):

[0001564590-13-001183:mdna:71]
|  | September 30, 2013 |  |  | March 31, 2013 |  |
| Cash and cash equivalents | $ | 25,867 |  |  | $ | 39,243 |  |
| Restricted cash |  | 6,922 |  |  |  | 10,956 |  |
| Total cash, cash equivalents, marketable securities and restricted cash | $ | 32,789 |  |  | $ | 50,199 |  |

[0001564590-13-001183:mdna:72]
With respect to the unaudited condensed consolidated statement of cash flows, for the six months ended September 30, 2013, net cash used in operating activities was $14.8 million compared to $25.0 million for the six months ended September 30, 2012. The decrease in net cash used in operations is due primarily to a lower net loss, net of non-cash adjustments, as well as less cash used for changes in operating asset and liability accounts.

[0001564590-13-001183:mdna:73]
For the six months ended September 30, 2013, net cash provided by investing activities was $3.4 million, compared to net cash used in investing activities of $4.9 million for the six months ended September 30, 2012. The increase in net cash provided by investing activities for the six months ended September 30, 2013 was driven primarily by the net reduction in restricted cash.

[0001564590-13-001183:mdna:74]
37

[0001564590-13-001183:mdna:75]
For the six months ended September 30, 2013, net cash used in financing activities was $2.3 million compared to $33.0 million cash provided by financing activities in the six months ended September 30, 2012. The decrease in net cash provided by financing activities is primarily due to the repayment of debt of $2.3 million during the period ended September 30, 2013 and the net proceeds from our financings during the period ended September 30, 2012 of $32.9 million.

[0001564590-13-001183:mdna:76]
At September 30, 2013, we had $2.0 million of restricted cash included in current assets, and $4.9 million of restricted cash included in long-term assets. These amounts included in restricted cash primarily represent deposits to secure letters of credit for various supply contracts. These deposits are held in interest bearing accounts.

[0001564590-13-001183:mdna:77]
We have experienced recurring operating losses and as of September 30, 2013, had an accumulated deficit of $825.3 million. In addition, we have experienced recurring negative operating cash flows, which have resulted in a decrease in our cash balance. These factors raise substantial doubt regarding our ability to continue as a going concern. Our financial statements do not include any adjustments that might result from this outcome of this uncertainty. At September 30, 2013 we had cash and cash equivalents of $25.9 million. Cash used in operations for the six months ended September 30, 2013, was $14.8 million.

[0001564590-13-001183:mdna:78]
On April 4, 2012, we entered into a Securities Purchase Agreement with Capital Ventures International (“CVI”), an affiliate of Heights Capital Management (the “Purchase Agreement”) and completed a private placement of a $25.0 million 7% senior convertible note (the “Initial Note”). After fees and expenses, the net proceeds were $23.2 million. The Initial Note had an initial conversion price of $4.85 per share, representing a premium of approximately 20% over our closing price on April 3, 2012. The Initial Note was payable in monthly installments beginning four months from issuance and ending on October 4, 2014. Monthly payments were payable in cash or shares of our common stock at our option, subject to certain trading volume, stock price and other conditions. CVI could also elect to defer receipt of monthly installment payments at its option. Any deferred installment payments would continue to accrue interest. We registered 10,262,311 shares of our common stock which may be used as payment for principal and interest in lieu of cash for resale under the Securities Act as required under a Registration Rights Agreement with CVI.

[0001564590-13-001183:mdna:79]
On December 20, 2012, we entered into an Amendment and Exchange Agreement, (the “First Amendment”) with CVI, which amended the Purchase Agreement. Pursuant to the First Amendment, the Company and CVI exchanged the Initial Note for a new unsecured, senior convertible note, (the “Exchanged Note”). At the time of the exchange, the Exchanged Note had the same principal amount and accrued interest as the Initial Note. The Exchanged Note is convertible into our common stock and has the same scheduled monthly installment payments as the Initial Note. The Exchanged Note provides us with additional flexibility to make monthly installment payments in shares of our common stock. We retain the ability to repay the Exchanged Note in cash. Specifically, the amendments to the Exchanged Note:

[0001564590-13-001183:mdna:80]
| — | Allowed us to convert, subject to the satisfaction of certain conditions set forth in the Exchanged Note, (a) at least $2.5 million of the approximately $5.3 million installment amount payable with respect to the January 2013 installment date (including approximately $4.2 million of deferred installment amounts from the period September 4, 2012 to December 3, 2012) into shares of the Company’s common stock (on December 21, 2012 we converted $3.8 million in deferred installment amount principal and interest and issued 1,715,443 shares of common stock), and (b) the balance of the January 2013 installment amount in equal amounts on each of the February and March 2013 installment dates; |

[0001564590-13-001183:mdna:81]
| — | Reduced the price failure equity condition with respect to a particular date of determination from $2.50 to $1.00; |

[0001564590-13-001183:mdna:82]
| — | Reduced the aggregate daily dollar trading volume equity condition required for at least 25 of the 30 consecutive trading days immediately preceding a date of determination from $1,500,000 to $850,000 per trading day. In addition, if the aggregate daily dollar trading volume is between $50,000 and $850,000, the Company may still convert into common stock a portion of an installment amount payable with respect to an installment date equal to the quotient of (x) the aggregate daily dollar trading volume, divided by (y) $850,000; |

[0001564590-13-001183:mdna:83]
| — | Increased CVI’s beneficial ownership limitation under the Exchanged Note from 4.99% to 9.99%; and |

[0001564590-13-001183:mdna:84]
| — | Reduced the conversion price, from $4.85 per share of our common stock to $3.19 per share of our common stock, subject to certain price-based and other anti-dilution adjustments. |

[0001564590-13-001183:mdna:85]
On October 9, 2013, we entered into a Second Amendment and Warrant Exchange Agreement (the “Second Amendment”) with CVI. The Second Amendment further amended the Securities Purchase Agreement, as amended by the First Amendment and Exchange Agreement dated December 20, 2012 (collectively, the “Amended Purchase Agreement”), that we previously entered into with the Purchaser.

[0001564590-13-001183:mdna:86]
Pursuant to the Second Amendment, we and/or CVI (i) waived certain provisions of the Amended Purchase Agreement, and (ii) amended certain provisions of the Exchanged Note, specifically,

[0001564590-13-001183:mdna:87]
| · | CVI waived its rights under the Amended Purchase Agreement to participate in (i) specific types of offerings that may be conducted by the Company with respect to our currently effective Registration Statement on Form S-3 (Registration No. 333-191153), and (ii) the issuance of shares of common stock in connection with any settlement of currently outstanding litigation involving us; |

[0001564590-13-001183:mdna:88]
| · | we and CVI amended the Exchanged Note: |

[0001564590-13-001183:mdna:89]
| · | to increase the period during which CVI is allowed to accelerate payment in shares of common stock at the then current installment date conversion price from such installment date until the trading day before the next installment notice due date to the entire period from such installment date until the trading day before the next installment date; and |

[0001564590-13-001183:mdna:90]
| · | to increase the aggregate outstanding principal amount under the definition of “permitted senior indebtedness” from $10 million to $15 million. |

[0001564590-13-001183:mdna:91]
On June 5, 2012, we entered into a Term Loan with Hercules Technology Growth Capital, Inc. (“Hercules”), under which we borrowed $10.0 million. After the closing fees and expenses, the net proceeds were $9.7 million. The Term Loan bears an interest rate equal to 11% plus the percentage, if any, in which the prime rate as reported by The Wall Street Journal exceeds 3.75%. We made interest only payments from July 1, 2012 through October 31, 2012, after which we began paying the Term Loan in equal monthly installments ending on December 1, 2014. The Term Loan is secured by substantially all of our existing and future assets, including a mortgage on real property owned by our wholly owned subsidiary, ASC Devens LLC, and located at 64 Jackson Road, Devens, Massachusetts. The Term Loan contains certain covenants that restrict our ability to, among other things, incur or assume certain debt, merge or consolidate, materially change the nature of our business, make certain investments, acquire or dispose of certain assets, make guaranties or grant liens on its assets, make certain loans, advances or investments, declare dividends or make distributions or enter into transactions with affiliates. In addition, the Term Loan contains a covenant which requires us to maintain a minimum unrestricted cash balance in the United States of at least $10.0 million at the inception of the Term Loan, which decreased starting November 1, 2012 and monthly thereafter by the amount of principal paid. The events of default under the Term Loan include, but are not limited to, failure to pay amounts due, breaches of covenants, bankruptcy events, cross defaults under other material indebtedness and the occurrence of a material adverse effect and/or change in control. In the case of a continuing event of default, the lender may, among other remedies, declare due all unpaid principal amounts outstanding and any accrued but unpaid interest and foreclose on all collateral granted to the lender as security under the Term Loan.

[0001564590-13-001183:mdna:92]
We believe we are in and expect to remain in compliance with the covenants and restrictions under the Exchanged Note and the Term Loan as of the date of this Quarterly Report on Form 10-Q. If we fail to stay in compliance with our covenants or experience some other event of default, we may be forced to repay the outstanding principal of one or both of our debt obligations. In the case of the Exchanged Note, such an event of default would also include the requirement to pay a penalty as defined in the agreement. Should this occur, our liquidity would be adversely affected.

[0001564590-13-001183:mdna:93]
In order for us to continue operations beyond the next twelve months and be able to discharge our liabilities and commitments in the normal course of business, we need to increase sales through executing our strategy to broaden our customer base, enter new markets, and commercialize our superconductor product line. In addition, we may need to further reduce operating expenses in line with business conditions in order to decrease the amount of cash used in operations. We must also seek new financing arrangements, including, but not limited to, new debt and/or equity financing, and continue to work with the holder of our convertible note in order to maintain the ability to make monthly amortization payments on the convertible note in shares of common stock. In addition, we are actively seeking to sell our minority investments in Tres Amigas and Blade Dynamics and have recently engaged a financial advisor to assist with that effort. There can be no assurance that we will be able to raise additional capital or sell one or both of these investments on commercially reasonable terms or at all.

[0001564590-13-001183:mdna:94]
39

[0001564590-13-001183:mdna:95]
We must successfully execute on our plans to improve operating performance discussed above and raise additional capital through financings or aother means to ensure that we have sufficient cash to fund our operations, capital expenditures and scheduled cash payments under our debt obligations through September 30, 2014. Our ability to pay required monthly installment payments under the Exchanged Note in equity instead of cash is based on certain stock price and trading volume conditions that are outside of our control. If one or both of these equity conditions are not met (absent a waiver from the lender), we may be required to make required monthly installment payments in cash. As of the date of this Quarterly Report on Form 10-Q, we have only made payments to the lender in shares of common stock and as a result the principal balance has been reduced by $14.6 million to $10.4 million through September 30, 2013. If we fail one or both of the equity conditions, we can still make required payments in stock if the lender agrees to waive our compliance with the relevant equity conditions, which it has done in the past. There is no assurance that the lender will provide any waivers in the future. Our liquidity is highly dependent on our ability to profitably grow revenues through both the acquisition of new customers and growth from our existing customers, manage our operating expenses, maintain compliance with the covenants and restrictions on our debt obligations (or obtain waivers from our lenders in the event of non-compliance), and raise additional capital through new financing arrangements or the sale of our minority investments in Tres Amigas and Blade Dynamics.  There can be no assurance that we will be able to raise additional capital or sell one or both of these investments on commercially reasonable terms or at all.

[0001564590-13-001183:mdna:96]
Legal Proceedings

[0001564590-13-001183:mdna:97]
We are involved in legal and administrative proceedings and claims of various types. See Part II, Item 1, “Legal Proceedings,” for additional information. We record a liability in our consolidated financial statements for these matters when a loss is known or considered probable and the amount can be reasonably estimated. We review these estimates each accounting period as additional information is known and adjust the loss provision when appropriate. If a matter is both probable to result in liability and the amounts of loss can be reasonably estimated, we estimate and disclose the possible loss or range of loss. If the loss is not probable or cannot be reasonably estimated, a liability is not recorded in its consolidated financial statements.

[0001564590-13-001183:mdna:98]
[same as prior period, unchanged from 0001193125-13-324142:mdna:90]

[0001564590-13-001183:mdna:99]
We do not have any off-balance sheet arrangements, as defined under SEC rules, such as relationships with unconsolidated entities or financial partnerships, which are often referred to as structured finance or special purpose entities, established for the purpose of facilitating transactions that are not required to be reflected on our balance sheet except as discussed below.

[0001564590-13-001183:mdna:100]
We occasionally enter into construction contracts that include a performance bond. As these contracts progress, we continually assess the probability of a payout from the performance bond. Should we determine that such a payout is probable, we would record a liability.

[0001564590-13-001183:mdna:101]
In addition, we have various contractual arrangements in which minimum quantities of goods or services have been committed to be purchased on an annual basis.

[0001564590-13-001183:mdna:102]
[same as prior period, unchanged from 0001193125-13-324142:mdna:94]

[0001564590-13-001183:mdna:103]
In January 2013, the FASB issued Accounting Standards Update No. 2013-01, Balance Sheet (Topic 210): Clarifying the Scope of Disclosures about Offsetting Assets and Liabilities (ASU 2013-01). The main objective in developing this update is to address implementation issues about the scope of Accounting Standards Update No. 2011-11, Balance Sheet (Topic 210): Disclosures about Offsetting Assets and Liabilities. The update requires entities to disclose information about offsetting and related arrangements of financial instruments and derivative instruments. ASU 2013-01 is effective for our first quarter of fiscal 2013.  We adopted ASU 2013-01 and it did not have a material impact on our consolidated results of operations, financial condition, or cash flow.

[0001564590-13-001183:mdna:104]
In February 2013, the FASB issued Accounting Standards Update No. 2013-02, Comprehensive Income (Topic 220): Reporting of Amounts Reclassified Out of Accumulated Other Comprehensive Income (ASU 2013-02). The amendments of this ASU require an entity to provide information about the amounts reclassified out of accumulated other comprehensive income (“AOCI”) by component. In addition, an entity is required to present, either on the face of the statement where net income (loss) is presented or in the notes, significant amounts reclassified out of AOCI by the respective line items of net income but only if the amount reclassified is required under U.S. GAAP to be reclassified to net income in its entirety in the same reporting period. For other amounts that are not required under U.S. GAAP to be reclassified in their entirety to net income, an entity is required to cross-reference to other disclosures required under U.S. GAAP that provide additional detail about those amounts. ASU 2013-02 is effective for fiscal years and interim periods beginning after December 15, 2012. We adopted ASU 2013-02 and it did not have a material impact on our consolidated results of operations, financial condition, or cash flows.

[0001564590-13-001183:mdna:105]
In March 2013, the FASB issued Accounting Standards Update No. 2013-05, Foreign Currency Matters (Topic 830): Parent’s Accounting for the Cumulative Translation Adjustment upon Derecognition of Certain Subsidiaries or Groups of Assets within a Foreign Entity or of an Investment in a Foreign Entity (ASU 2013-05). The objective of the amendments in this update is to resolve the diversity in practice about whether Subtopic 810-10, Consolidation—Overall, or Subtopic 830-30, Foreign Currency Matters—Translation of Financial Statements, applies to the release of the cumulative translation adjustment into net income when a parent either sells a part or all of its investment in a foreign entity or no longer holds a controlling financial interest in a subsidiary or group of assets that is a nonprofit activity or a business (other than a sale of in substance real estate or conveyance of oil and gas mineral rights) within a foreign entity. In addition, the amendments in this update resolve the diversity in practice for the treatment of business combinations achieved in involving a foreign entity. ASU 2013-05 is effective for fiscal years and interim periods beginning after December 15, 2013. We are currently evaluating the impact of ASU 2013-05, but currently do not believe there will be a significant impact on our consolidated results of operations, financial condition, or cash flows.

[0001564590-13-001183:mdna:106]
In June 2013, the FASB issued ASU 2013-07, Liquidation Basis of Accounting, to require entities to begin preparing financial statements on a liquidation basis when liquidation is imminent. The guidance requires liquidation accounting when liquidation is imminent, unless an entity is outside the scope of the guidance or it is following a liquidation plan established at its inception. The guidance says liquidation is imminent when either, the party or parties with the authority to approve a liquidation plan do so or other forces (e.g., involuntary bankruptcy) impose a plan for liquidation, and the likelihood that the entity will return from liquidation is remote. The guidance also requires entities using the liquidation basis of accounting to measure their assets at the amount they expect to collect upon sale and liabilities are not remeasured to reflect any anticipation that the entity will be legally released from the obligation. ASU 2013-07 is effective for annual periods beginning after December 15, 2013. We are currently evaluating the impact of adopting ASU 2013-07, but currently do not believe there will be an impact on our consolidated results of operations, financial condition, or cash flows.

[0001564590-13-001183:mdna:107]
In September 2013, the FASB issued ASU 2013-11, Income Taxes (Topic 740): Presentation of an Unrecognized Tax Benefit When a Net Operating Loss Carryforward, a Similar Tax Loss, or a Tax Credit Carryforward Exists. The guidance states that an unrecognized tax benefit, or a portion of an unrecognized tax benefit, should be presented in the financial statements as a reduction to a deferred tax asset for a net operating loss carryforward, a similar tax loss, or a tax credit carryforward, except as follows. To the extent a net operating loss carryforward, a similar tax loss, or a tax credit carryforward is not available at the reporting date under the tax law of the applicable jurisdiction to settle any additional income taxes that would result from the disallowance of a tax position or the tax law of the applicable jurisdiction does not require the entity to use, and the entity does not intend to use, the deferred tax asset for such purpose, the unrecognized tax benefit should be presented in the financial statements as a liability and should not be combined with deferred tax assets. This ASU applies to all entities that have unrecognized tax benefits when a net operating loss carrforward, a similar tax loss, or a tax credit carryforward exists at the reporting date. The amendments in this ASU are effective for fiscal years, and interim periods within those years, beginning after December 15, 2013. We are currently evaluating the impact of adopting ASU 2013-11, but currently do not believe there will be an impact on our consolidated results of operations, financial condition, or cash flow

[0001564590-13-001183:mdna:108]
We do not believe that other recently issued accounting pronouncements will have a material impact on our financial statements.

[0001564590-13-001183:mdna:109]
41
