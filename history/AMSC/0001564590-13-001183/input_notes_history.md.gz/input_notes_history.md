# AMSC note change history — 0001193125-13-324142 → 0001564590-13-001183


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2013-11-12):
[0001564590-13-001183:note_history:1]
12. Commitments and Contingencies
  (was, 2013-08-07, similarity 0.9118):
[0001193125-13-324142:note_history:1]
| 12. | Commitments and Contingencies |

- changed (2013-11-12):
[0001564590-13-001183:note_history:2]
The Company periodically enters into non-cancelable purchase contracts in order to ensure the availability of materials to support production of its products. Purchase commitments represent enforceable and legally binding agreements with suppliers to purchase goods or services. The Company periodically assesses the need to provide for impairment on these purchase contracts and record a loss on purchase commitments when required. As of September 30, 2013, the Company reported a liability for adverse purchase commitments of $1.0 million. During the three and six months ended September 30, 2013, the Company reduced its accrual for adverse purchase commitments by $0.2 million and $0.5 million, respectively, due to payments to certain vendors.
  (was, 2013-08-07, similarity 0.898):
[0001193125-13-324142:note_history:2]
The Company
periodically enters into non-cancelable purchase contracts in order
to ensure the availability of materials to support production of
its products. Purchase commitments represent enforceable and
legally binding agreements with suppliers to purchase goods or
services. The Company periodically assesses the need to provide for
impairment on these purchase contracts and record a loss on
purchase commitments when required. As of June 30, 2013, the
Company reported a liability for adverse purchase commitments of
$1.2 million. During the three months ended June 30, 2013, the
Company reduced its accrual for adverse purchase commitments by
$0.3 million due to payments to certain vendors.

- changed (2013-11-12):
[0001564590-13-001183:note_history:3]
Between April 6, 2011 and May 12, 2011, seven putative securities class action complaints were filed against the Company and two of its officers in the United States District Court for the District of Massachusetts; one complaint additionally asserted claims against the underwriters who participated in our November 12, 2010 securities offering. On June 7, 2011, the United States District Court for the District of Massachusetts consolidated these actions under the caption Lenartz v. American Superconductor Corporation, et al., Docket No. 1:11-cv-10582-WGY. On August 31, 2011, Lead Plaintiff, the Plumbers and Pipefitters National Pension Fund, filed a consolidated amended complaint against the Company, its officers and directors, and the underwriters who participated in our November 12, 2010 securities offering, asserting claims under sections 10(b) and 20(a) of the Securities Exchange Act of 1934 (the “Exchange Act”) and Rule 10b-5 promulgated under the Exchange Act, as well as under sections 11, 12(a)(2) and 15 of the Securities Act of 1933 (the “Securities Act”). The complaint alleges that during the relevant class period, the Company and its officers omitted to state material facts and made materially false and misleading statements relating to, among other things, its projected and recognized revenues and earnings, as well as its relationship with Sinovel Wind Group Co., Ltd. that artificially inflated the value of the Company’s stock price. The complaint further alleges that the Company’s November 12, 2010 securities offering contained untrue statements of material facts and omitted to state material facts required to be stated therein. The plaintiffs seek unspecified damages, rescindment of the Company’s November 12, 2010 securities offering, and an award of costs and expenses, including attorney’s fees. All defendants moved to dismiss the consolidated amended complaint. On December 16, 2011, the district court issued a summary order declining to dismiss the Securities Act claims against the Company and its officers, and taking under advisement the motion to dismiss the Exchange Act claims against the Company and its officers and the motion to dismiss the Securities Act claims made against the underwriters. On July 26, 2012, the district court dismissed the Exchange Act claims against the Company and its officers and denied the motion to dismiss the Securities Act claims made against the underwriters. On May 17, 2013, the parties informed the district court that they had reached a settlement in principle, and requested a 30-day stay of the proceedings while the specific terms of the settlement continue to be negotiated. Based on the Company’s assessment of the probable losses on this claim, the Company has recorded a loss contingency of $1.8 million as of September 30, 2013.
  (was, 2013-08-07, similarity 0.9755):
[0001193125-13-324142:note_history:3]
Between
April 6, 2011 and May 12, 2011, seven putative securities
class action complaints were filed against the Company and two of
its officers in the United States District Court for the District
of Massachusetts; one complaint additionally asserted claims
against the underwriters who participated in our November 12,
2010 securities offering. On June 7, 2011, the United
States District Court for the District of Massachusetts
consolidated these actions under the caption Lenartz v. American
Superconductor Corporation, et al., Docket
No. 1:11-cv-10582-WGY. On August 31, 2011, Lead
Plaintiff, the Plumbers and Pipefitters National Pension Fund,
filed a consolidated amended complaint against the Company, its
officers and directors, and the underwriters who participated in
our November 12, 2010 securities offering, asserting claims
under sections 10(b) and 20(a) of the Securities Exchange Act of
1934 and Rule 10b-5 promulgated under the Securities Exchange Act
of 1934 (the “Exchange Act”), as well as under
sections 11, 12(a)(2) and 15 of the Securities Act of 1933
(the “Securities Act”). The complaint alleges that
during the relevant class period, the Company and its officers
omitted to state material facts and made materially false and
misleading statements relating to, among other things, its
projected and recognized revenues and earnings, as well as its
relationship with Sinovel Wind Group Co., Ltd. that artificially
inflated the value of the Company’s stock price. The
complaint further alleges that the Company’s
November 12, 2010 securities offering contained untrue
statements of material facts and omitted to state material facts
required to be stated therein. The plaintiffs seek unspecified
damages, rescindment of the Company’s November 12, 2010
securities offering, and an award of costs and expenses, including
attorney’s fees. All defendants moved to dismiss the
consolidated amended complaint. On December 16, 2011, the
district court issued a summary order declining to dismiss the
Securities Act claims against the Company and its officers, and
taking under advisement the motion to dismiss the Exchange Act
claims against the Company and its officers and the motion to
dismiss the Securities Act claims made against the underwriters. On
July 26, 2012, the district court dismissed the Exchange Act
claims against the Company and its officers and denied the motion
to dismiss the Securities Act claims made against the underwriters.
On May 17, 2013, the parties informed the district court that
they had reached a settlement in principle, and requested a 30-day
stay of the proceedings while the specific terms of the settlement
continue to be negotiated. Based on the Company’s assessment
of the probable losses on this claim, the Company has recorded a
loss contingency of $1.8 million as of June 30,
2013.

- changed (2013-11-12):
[0001564590-13-001183:note_history:4]
Between May 4, 2011 and June 17, 2011, four putative shareholder derivative complaints were filed against the Company (as a nominal defendant) and certain of its directors in the United States District Court for the District of Massachusetts. On July 5, 2011, the District Court consolidated three of these actions, and that matter is now captioned In re American Superconductor Corporation Derivative Litigation, Docket No. 1:11-cv-10784-WGY. On June 1, 2011, the plaintiff in the fourth action, Marlborough Family Revocable Trust v. Yurek, et al., moved to voluntarily dismiss its complaint and refiled its complaint in Superior Court for the Commonwealth of Massachusetts, Middlesex County. On September 7, 2011, the Marlborough action and another putative shareholder derivative complaint filed in Superior Court for the Commonwealth of Massachusetts were consolidated. That consolidated matter is captioned In re American Superconductor Corporation Shareholder Derivative Litigation, Docket No. 11-1961. On January 12, 2012, an additional shareholder derivative complaint was filed in the Court of Chancery for the State of Delaware. That matter is captioned Krasnoff v. Budhraja, et al., Docket No. 7171. The allegations of the derivative complaints mirror the allegations made in the putative class action complaints described above. The plaintiffs purport to assert claims against the director defendants for breach of fiduciary duty, abuse of control, gross mismanagement, unjust enrichment and corporate waste. On October 23, 2013, the parties informed the Massachusetts state court that the derivative plaintiffs, including those in the federal district court and the Delaware Court of Chancery, had reached a settlement in principle, and requested a 90-day stay of the proceedings while the specific terms of the settlement continue to be negotiated. The plaintiffs seek unspecified damages on behalf of the Company, as well as an award of costs and expenses, including attorney’s fees.  Based on the Company’s assessment that the probable losses on this claim are insignificant, no loss contingency was recorded as of September 30, 2013.
  (was, 2013-08-07, similarity 0.8374):
[0001193125-13-324142:note_history:4]
Between
May 4, 2011 and June 17, 2011, four putative shareholder
derivative complaints were filed against the Company (as a nominal
defendant) and certain of its directors in the United States
District Court for the District of Massachusetts. On
July 5, 2011, the District Court consolidated three of these
actions, and that matter is now captioned In re American
Superconductor Corporation Derivative Litigation, Docket
No. 1:11-cv-10784-WGY. On June 1, 2011, the
plaintiff in the fourth action, Marlborough Family Revocable
Trust v. Yurek, et al., moved to voluntarily dismiss its
complaint and refiled its complaint in Superior Court for the
Commonwealth of Massachusetts, Middlesex County. On
September 7, 2011, the Marlborough action and another
putative shareholder derivative complaint filed in Superior Court
for the Commonwealth of Massachusetts were consolidated. That
consolidated matter is captioned In re American Superconductor
Corporation Shareholder Derivative Litigation, Docket
No. 11-1961. On January 12, 2012, an additional
shareholder derivative complaint was filed in the Court of Chancery
for the State of Delaware. That matter is captioned Krasnoff v.
Budhraja, et al., Docket No. 7171. The allegations
of the derivative complaints mirror the allegations made in the
putative class action complaints described above. The
plaintiffs purport to assert claims against the director defendants
for breach of fiduciary duty, abuse of control, gross
mismanagement, unjust enrichment and corporate waste. The
plaintiffs seek unspecified damages on behalf of the Company, as
well as an award of costs and expenses, including attorney’s
fees.

- changed (2013-11-12):
[0001564590-13-001183:note_history:5]
Ghodawat Energy Pvt Ltd (“Ghodawat”), a company registered in India carrying on the business of wind power development, lodged a Request for Arbitration with the Secretariat of the ICC International Court of Arbitration on May 12, 2011 and named AMSC Windtec GmbH (“AMSC Austria”) as the Respondent. Under the Request for Arbitration, Ghodawat alleges that AMSC Austria breached an agreement dated March 19, 2008 pursuant to which AMSC Austria granted a license to Ghodawat to manufacture, use, sell, market, erect, commission and maintain certain wind turbines using its technical information and wind turbine design (the “License Agreement”). Under the Request for Arbitration, Ghodawat’s claims in this arbitration amount to approximately €18 million ($24 million). AMSC Austria filed an Answer to Request for Arbitration and Counterclaim (“Answer and Counterclaim”), in which AMSC Austria denied Ghodawat’s claims in their entirety. AMSC Austria has also submitted counterclaims under the License Agreement against Ghodawat in the amount of approximately €6 million ($9 million). Ghodawat has filed a Reply to Answer to Request for Arbitration and Counterclaim in which it denies AMSC Austria’s counterclaims. On June 3, 2013, the final oral submissions’ hearing was conducted and the Company believes it will take several months for the Tribunal to render a decision. The Company has recorded a loss contingency based on its assessment of probable losses on this claim; however this amount of loss contingency that has been recorded is immaterial to its consolidated financial statements.
  (was, 2013-08-07, similarity 0.9858):
[0001193125-13-324142:note_history:5]
Ghodawat Energy
Pvt Ltd (“Ghodawat”), a company registered in India
carrying on the business of wind power development, lodged a
Request for Arbitration with the Secretariat of the ICC
International Court of Arbitration on May 12, 2011 and named
AMSC Windtec GmbH (“AMSC Austria”) as the Respondent.
Under the Request for Arbitration, Ghodawat alleges that AMSC
Austria breached an agreement dated March 19, 2008 pursuant to
which AMSC Austria granted a license to Ghodawat to manufacture,
use, sell, market, erect, commission and maintain certain wind
turbines using its technical information and wind turbine design
(the “License Agreement”). Under the Request for
Arbitration, Ghodawat’s claims in this arbitration amount to
approximately €18 million ($24 million). AMSC Austria
filed an Answer to Request for Arbitration and Counterclaim
(“Answer and Counterclaim”), in which AMSC Austria
denied Ghodawat’s claims in their entirety. AMSC Austria
has also submitted counterclaims under the License Agreement
against Ghodawat in the amount of approximately
€6 million ($9 million). Ghodawat has filed a Reply
to Answer to Request for Arbitration and Counterclaim in which it
denies AMSC Austria’s counterclaims. On June 3, 2013,
the final oral submissions hearing was conducted and the Company
believes it will take several months for the Tribunal to render a
decision. The Company has recorded a loss contingency based on its
assessment of probable losses on this claim; however this amount is
immaterial to its consolidated financial statements.

- changed (2013-11-12):
[0001564590-13-001183:note_history:6]
As of September 30, 2013 the Company had $2.0 million of restricted cash included in current assets, and $4.9 million of restricted cash included in long-term assets. These amounts included in restricted cash represent deposits to secure letters of credit for various supply contracts. These deposits are held in interest bearing accounts.
  (was, 2013-08-07, similarity 0.9802):
[0001193125-13-324142:note_history:6]
As of
June 30, 2013 the Company had $0.8 million of restricted cash
included in current assets, and $6.1 million of restricted cash
included in long-term assets. These amounts included in restricted
cash represent deposits to secure letters of credit for various
supply contracts. These deposits are held in interest bearing
accounts.

- changed (2013-11-12):
[0001564590-13-001183:note_history:7]
As of September 30, 2013, the Company had one performance bond in support of customer contracts. The total value of the outstanding performance bond is $0.2 million with an expiration date of March 2014. In the event that the payment is made in accordance with the requirements of any of these performance bonds, the Company would record the payment as an offset to revenue.
  (was, 2013-08-07, similarity 0.9819):
[0001193125-13-324142:note_history:7]
As of
June 30, 2013, the Company had one performance bond in support
of customer contracts. The total value of the outstanding
performance bond is $0.2 million with an expiration date of March
2014. In the event that the payment is made in accordance with the
requirements of any of these performance bonds, the Company would
record the payment as an offset to revenue.

- changed (2013-11-12):
[0001564590-13-001183:note_history:8]
The Company had an unused, unsecured line of credit consisting of €2.7 million (approximately $3.6 million) in Austria as of September 30, 2013.
  (was, 2013-08-07, similarity 0.9582):
[0001193125-13-324142:note_history:8]
The Company had
an unused, unsecured line of credit consisting of
€2.7 million (approximately $3.5 million) in Austria as
of June 30, 2013.

- removed (2013-11-12):
[0001193125-13-324142:note_history:9]
If a matter is
both probable to result in liability and the amount of loss can be
reasonably estimated, we estimate and disclose the possible loss or
range of possible loss. With respect to the above referenced
shareholder derivative litigation matters, an estimate of loss or
range of loss cannot be made. There are numerous factors that make
it difficult to meaningfully estimate possible loss or range of
loss at this stage of these litigation matters, including that: the
proceedings are in relatively early stages, there are significant
factual and legal issues to be resolved, information obtained or
rulings made during the lawsuits could affect the methodology for
calculation of rescission and the related statutory interest rate.
In addition, with respect to claims where damages are the requested
relief, no amount of loss or damages has been specified. Therefore,
the Company is unable at this time to estimate possible losses. The
Company believes that these litigations are without merit, and it
intends to defend these actions vigorously.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2013-11-12):
[0001564590-13-001183:note_history:10]
10. Debt
  (was, 2013-08-07, similarity 0.6667):
[0001193125-13-324142:note_history:10]
| 10. | Debt |

- changed (2013-11-12):
[0001564590-13-001183:note_history:11]
On December 20, 2012, the Company entered into an Amendment and Exchange Agreement, (the “First Amendment”) with CVI, which amended the Purchase Agreement. Pursuant to the First Amendment, the Company and CVI exchanged the Initial Note for the Exchanged Note. At the time of the exchange, the Exchanged Note had the same principal amount and accrued interest as the Initial Note. The Exchanged Note is convertible into the Company’s common stock and has the same scheduled monthly installment payments as the Initial Note. The Exchanged Note provides the Company with additional flexibility to make monthly installment payments in shares of the Company’s common stock. The Company retains the ability to repay the Exchanged Note in cash. Specifically, the amendments to the Exchanged Note:
  (was, 2013-08-07, similarity 0.9923):
[0001193125-13-324142:note_history:11]
On
December 20, 2012, the Company entered into an Amendment and
Exchange Agreement, (the “Amendment”) with CVI, which
amended the Purchase Agreement. Pursuant to the Amendment, the
Company and CVI exchanged the Initial Note for the Exchanged Note.
At the time of the exchange, the Exchanged Note had the same
principal amount and accrued interest as the Initial Note. The
Exchanged Note is convertible into the Company’s common stock
and has the same scheduled monthly installment payments as the
Initial Note. The Exchanged Note provides the Company with
additional flexibility to make monthly installment payments in
shares of the Company’s common stock. The Company retains the
ability to repay the Exchanged Note in cash. Specifically, the
amendments to the Exchanged Note:

- changed (2013-11-12):
[0001564590-13-001183:note_history:12]
     Allowed the Company to convert, subject to the satisfaction of certain conditions set forth in the Exchanged Note, (a) at least $2.5 million of the approximately $5.3 million installment amount payable with respect to the January 2013 installment date (including approximately $4.2 million of deferred installment amounts from the period September 4, 2012 to December 3, 2012) into shares of the Company’s common stock (on December 21, 2012 the Company converted $3.8 million in deferred installment amount principal and interest and issued 1,715,443 shares of common stock), and (b) the balance of the January 2013 installment amount in equal amounts on each of the February and March 2013 installment dates;
  (was, 2013-08-07, similarity 0.9897):
[0001193125-13-324142:note_history:12]
|  | • |  | Allow the Company to convert, subject to the satisfaction of certain conditions set forth in the Exchanged Note, (a) at least $2.5 million of the approximately $5.3 million installment amount payable with respect to the January 2013 installment date (including approximately $4.2 million of deferred installment amounts from the period September 4, 2012 to December 3, 2012) into shares of the Company’s common stock (on December 21, 2012 the Company converted $3.8 million in deferred installment amount principal and interest and issued 1,715,443 shares of common stock), and (b) the balance of the January 2013 installment amount in equal amounts on each of the February and March 2013 installment dates; |

- changed (2013-11-12):
[0001564590-13-001183:note_history:13]
     Reduced the price failure equity condition with respect to a particular date of determination from $2.50 to $1.00;
  (was, 2013-08-07, similarity 0.9432):
[0001193125-13-324142:note_history:13]
|  | • |  | Reduce the price failure equity condition with respect to a particular date of determination from $2.50 to $1.00; |

- changed (2013-11-12):
[0001564590-13-001183:note_history:14]
     Reduced the aggregate daily dollar trading volume equity condition required for at least 25 of the 30 consecutive trading days immediately preceding a date of determination from $1,500,000 to $850,000 per trading day. In addition, if the aggregate daily dollar trading volume is between $50,000 and $850,000, the Company may still convert into common stock a portion of an installment amount payable with respect to an installment date equal to the quotient of (x) the aggregate daily dollar trading volume, divided by (y) $850,000;
  (was, 2013-08-07, similarity 0.9732):
[0001193125-13-324142:note_history:14]
|  | • |  | Reduce the aggregate daily dollar trading volume equity condition required for at least 25 of the 30 consecutive trading days immediately preceding a date of determination from $1,500,000 to $850,000 per trading day. In addition, if the aggregate daily dollar trading volume is between $50,000 and $850,000, the Company may still convert into common stock a portion of an installment amount payable with respect to an installment date equal to the quotient of (x) the aggregate daily dollar trading volume, divided by (y) $850,000; |

- changed (2013-11-12):
[0001564590-13-001183:note_history:15]
     Increased CVI’s beneficial ownership limitation under the Exchanged Note from 4.99% to 9.99%; and
  (was, 2013-08-07, similarity 0.9333):
[0001193125-13-324142:note_history:15]
|  | • |  | Increase CVI’s beneficial ownership limitation under the Exchanged Note from 4.99% to 9.99%; and |

- changed (2013-11-12):
[0001564590-13-001183:note_history:16]
     Reduced the conversion price, from $4.85 per share of the Company’s common stock to $3.19 per share of the Company’s common stock, subject to certain price-based and other anti-dilution adjustments.
  (was, 2013-08-07, similarity 0.932):
[0001193125-13-324142:note_history:16]
|  | • |  | Reduce the conversion price, from $4.85 per share of the Company’s common stock to $3.19 per share of the Company’s common stock, subject to certain price-based and other anti-dilution adjustments. |

- changed (2013-11-12):
[0001564590-13-001183:note_history:17]
The Company assessed the changes in the Exchanged Note and accounted for it as a modification of the Initial Note. Therefore, the Company determined the incremental value of the derivative instruments, as a result of the Exchanged Note having a reduced conversion price. As a result of the re-valuation, the Company recorded a $0.5 million increase in the value of the derivative liability and additional debt discount. At the modification date, the value of the derivative liability was $1.5 million. The total debt discount, including the embedded derivatives in the Initial Note, the incremental value of embedded derivatives in the Exchanged Note, warrant and legal and origination costs of $13.1 million is being amortized into interest expense over the term of the Exchanged Note using the effective interest method. Under this method, interest expense is recognized each period until the debt instruments reach maturity. If the maturity of the Exchanged Note is accelerated because of prepayment, then the amortization will be accelerated. During the three and six months ended September 30, 2013, the Company recorded non-cash interest expense for amortization of the debt discount related to the convertible note of $1.2 million and $2.7 million, respectively. During the three and six months ended September 30, 2012, the Company recorded non-cash interest expense for amortization of the debt discount related to the convertible note of $2.1 million and $4.2 million, respectively.
  (was, 2013-08-07, similarity 0.9002):
[0001193125-13-324142:note_history:17]
The Company
assessed the changes in the Exchanged Note and accounted for it as
a modification of the Initial Note. Therefore, the Company
determined the incremental value of the derivative instruments, as
a result of the Exchanged Note, as having a reduced conversion
price. As a result of the re-valuation, the Company recorded a $0.5
million increase in the value of the derivative liability and
additional debt discount. At the modification date, the value of
the derivative liability was $1.5 million. The total debt discount,
including the embedded derivatives in the Initial Note, the
incremental value of embedded derivatives in the Exchanged Note,
warrant and legal and origination costs of $13.1 million is being
amortized into interest expense over the term of the Exchanged Note
using the effective interest method. Under this method, interest
expense is recognized each period until the debt instruments reach
maturity. If the maturity of the Exchanged Note is accelerated
because of prepayment, then the amortization will be accelerated.
During the three months ended June 30, 2013, and 2012 the
Company recorded non-cash interest expense for amortization of the
debt discount related to the convertible notes of $1.5 million and
$2.2 million, respectively.

- added (2013-11-12):
[0001564590-13-001183:note_history:18]
On October 9, 2013, the Company entered into a Second Amendment and Warrant Exchange Agreement (the “Second Amendment”) with CVI. The Second Amendment further amended the Securities Purchase Agreement, as amended by the First Amendment (collectively, the “Amended Purchase Agreement”), that the Company previously entered into with CVI.

- added (2013-11-12):
[0001564590-13-001183:note_history:19]
Pursuant to the Second Amendment, the Company and/or CVI waived certain provisions of the Amended Purchase Agreement and amended certain provisions of the Exchanged Note, specifically,

- added (2013-11-12):
[0001564590-13-001183:note_history:20]
     CVI waived its rights under the Amended Purchase Agreement to participate in (i) specific types of offerings that may be conducted by the Company with respect to the Company’s currently effective Registration Statement on Form S-3 (Registration No. 333-191153), and (ii) the issuance of shares of common stock in connection with any settlement of currently outstanding litigation involving the Company; and

- added (2013-11-12):
[0001564590-13-001183:note_history:21]
     the Company and CVI amended the Exchanged Note:

- added (2013-11-12):
[0001564590-13-001183:note_history:22]
     to increase the period during which CVI is allowed to accelerate payment in shares of common stock at the then current installment date conversion price from such installment date until the trading day before the next installment notice due date to the entire period from such installment date until the trading day before the next installment date; and

- added (2013-11-12):
[0001564590-13-001183:note_history:23]
     to increase the aggregate outstanding principal amount under the definition of “permitted senior indebtedness” from $10.0 million to $15.0 million.

- changed (2013-11-12):
[0001564590-13-001183:note_history:24]
Provided certain equity conditions are met, the Company may elect to repay principal and interest in shares of the Company’s common stock. If the Company elects to make a payment in shares of the Company’s common stock, the number of shares to be issued is determined by dividing the amount of such payment by 85% of the lessor of the average volume-weighted average price (“VWAP”) of the 10 consecutive days immediately preceding the payment date or the VWAP price on the day preceding the payment date (the “Market Price”). The Company records the difference between the closing price of its common stock on the day preceding the payment date and the Market Price as a discount on the fair value of its shares. During both the three and six months ended September 30, 2013, the Company recorded $1.8 million of non-cash interest expense related to installment payments made by issuing the Company’s common stock at a discount, compared to $0.2 million during both the three and six months ended September 30, 2012.
  (was, 2013-08-07, similarity 0.9189):
[0001193125-13-324142:note_history:24]
Provided
certain equity conditions are met, the Company may elect to repay
principal and interest in shares of the Company’s common
stock. If the Company elects to make a payment in shares of the
Company’s common stock, the number of shares to be issued is
determined by dividing the amount of such payment by 85% of the
lessor of the average volume-weighted average price
(“VWAP”) of the 10 consecutive days immediately
preceding the payment date or the VWAP price on the day preceding
the payment date (the “Market Price”). The Company
records the difference between the closing price of its common
stock on the day preceding the payment date and the Market Price as
a discount on the fair value of its shares. During the three months
ended June 30, 2013, the Company recorded $0.1 million of
non-cash interest expense related to installment payments made by
issuing the Company’s common stock at a discount.

- changed (2013-11-12):
[0001564590-13-001183:note_history:25]
The Exchanged Note and the Amended Purchase Agreement contain certain covenants and restrictions, including, among others, that for so long as the Exchanged Note is outstanding, the Company will not incur any indebtedness (other than permitted indebtedness under the Exchanged Note), permit liens on its properties (other than permitted liens under the Exchanged Note), make payments on junior securities or declare dividends. The Exchanged Note also contains limitations on the transfer of certain assets. Events of default under the Exchanged Note include failure to pay principal or interest as due on the Exchanged Note, failure to deliver registered shares of common stock upon the holders request for conversion of part or all of the Exchanged Note, failure to maintain the Company’s common stock eligible for trading on defined markets, cross defaults to other material indebtedness, receipt of uninsured judgments against the Company in excess of defined limits and other administrative covenants, including the Term Loan discussed below, as defined in the Exchanged Note and related documentation. Upon an event of default, the holders may require the Company to redeem all or any portion of the outstanding principal amount of the Exchanged Note in cash plus a penalty as specified in the agreement. Also, if the Company fails to maintain an effective registration statement covering common stock to be used in settling obligations under the Exchanged Note, the Company will be required to pay a penalty as specified in the agreement.
  (was, 2013-08-07, similarity 0.9961):
[0001193125-13-324142:note_history:25]
The Exchanged
Note and Purchase Agreement contain certain covenants and
restrictions, including, among others, that for so long as the
Exchanged Note is outstanding, the Company will not incur any
indebtedness (other than permitted indebtedness under the Exchanged
Note), permit liens on its properties (other than permitted liens
under the Exchanged Note), make payments on junior securities or
declare dividends. The Exchanged Note also contains limitations on
the transfer of certain assets. Events of default under the
Exchanged Note include failure to pay principal or interest as due
on the Exchanged Note, failure to deliver registered shares of
common stock upon the holders request for conversion of part or all
of the Exchanged Note, failure to maintain the Company’s
common stock eligible for trading on defined markets, cross
defaults to other material indebtedness, receipt of uninsured
judgments against the Company in excess of defined limits and other
administrative covenants, including the Term Loan discussed below,
as defined in the Exchanged Note and related documentation. Upon an
event of default, the holders may require the Company to redeem all
or any portion of the outstanding principal amount of the Exchanged
Note in cash plus a penalty as specified in the agreement. Also, if
the Company fails to maintain an effective registration statement
covering common stock to be used in settling obligations under the
Exchanged Note, the Company will be required to pay a penalty as
specified in the agreement.

- changed (2013-11-12):
[0001564590-13-001183:note_history:26]
On June 5, 2012, the Company entered into a Term Loan with Hercules Technology Growth Capital, Inc. (“Hercules”), under which the Company borrowed $10.0 million (the “Term Loan”). After the closing fees and expenses, the net proceeds to the Company were $9.7 million. The Term Loan bears an interest rate equal to 11% plus the percentage, if any, by which the prime rate as reported by The Wall Street Journal exceeds 3.75%. The Company made interest-only payments from July 1, 2012 through October 31, 2012, after which the Company began repaying the Term Loan in equal monthly installments ending on December 1, 2014. The Term Loan is secured by substantially all of the Company’s existing and future assets, including a mortgage on real property owned by the Company’s wholly-owned subsidiary, ASC Devens LLC, and located at 64 Jackson Road, Devens, Massachusetts. In addition, Hercules received a warrant to purchase 139,276 shares of common stock, exercisable at an initial strike price of $3.59 per share, subject to adjustment, until December 5, 2017. Due to certain adjustment provisions within the warrant, it qualified for liability accounting and the fair value of $0.4 million was recorded upon issuance, which the Company recorded as a debt discount and a warrant liability. (See Note 11, “Warrants and Derivative Liabilities,” for a discussion on warrants and the valuation assumptions used.) The Company will pay an end of term fee of $0.5 million upon the earlier of maturity or prepayment of the loan. The Company has accrued the term fee and recorded a corresponding amount into the debt discount. In addition, the Company incurred $0.3 million of legal and origination costs in the year ended March 31, 2013, which have been recorded as a debt discount. The total debt discount including the warrant, end of term fee and legal and origination costs of $1.2 million is being amortized into interest expense over the term of the Term Loan using the effective interest method. Under this method, interest expense is recognized each period until the debt instrument reaches maturity. If the maturity of the Term Loan is accelerated because of prepayment, then the amortization will be accelerated. During the three and six months ended September 30, 2013, the Company recorded non-cash interest expense for amortization of the debt discount related to the Term Loan of $0.1 million and $0.3 million, respectively. During the three and six months ended September 30, 2012, the Company recorded non-cash interest expense for amortization of the debt discount related to the Term Loan of $0.2 million and $0.3 million, respectively.
  (was, 2013-08-07, similarity 0.9137):
[0001193125-13-324142:note_history:26]
On June 5,
2012, the Company entered into a Term Loan with Hercules Technology
Growth Capital, Inc. (“Hercules”), under which the
Company borrowed $10.0 million (the “Term Loan”). After
the closing fees and expenses, the net proceeds to the Company were
$9.7 million. The Term Loan bears an interest rate equal to 11%
plus the percentage, if any, by which the prime rate as reported by
The Wall Street Journal exceeds 3.75%. The Company made
interest-only payments from July 1, 2012 through
October 31, 2012, after which the Company repays the loan in
equal monthly installments ending on December 1, 2014. The
Term Loan is secured by substantially all of the Company’s
existing and future assets, including a mortgage on real property
owned by the Company’s wholly-owned subsidiary, ASC Devens
LLC, and located at 64 Jackson Road, Devens, Massachusetts. In
addition, Hercules received a warrant to purchase 139,276 shares of
common stock, exercisable at an initial strike price of $3.59 per
share, subject to adjustment, until December 5, 2017. Due to
certain adjustment provisions within the warrant, it qualified for
liability accounting and the fair value of $0.4 million was
recorded upon issuance, which the Company recorded as a debt
discount and a warrant liability. (See Note 11, “Warrants and
Derivative Liabilities,” for a discussion on warrants and the
valuation assumptions used.) The Company will pay an end of term
fee of $0.5 million upon the earlier of maturity or prepayment of
the loan. The Company has accrued this as of the year ended
March 31, 2013 and recorded a corresponding amount into the
debt discount. In addition, the Company incurred $0.3 million of
legal and origination costs in the year ended March 31, 2013,
which have been recorded as a debt discount. The total debt
discount including the warrant, end of term fee and legal and
origination costs of $1.2 million is being amortized into interest
expense over the term of the Term Loan using the effective interest
method. Under this method, interest expense is recognized each
period until the debt instrument reaches maturity. If the maturity
of the Term Loan is accelerated because of prepayment, then the
amortization will be accelerated. During the three months ended
June 30, 2013 and 2012, the Company recorded non-cash interest
expense for amortization of the debt discount related to the Term
Loan of $0.1 million and $0.1 million, respectively.

- changed (2013-11-12):
[0001564590-13-001183:note_history:27]
The Term Loan contains certain covenants that restrict the Company’s ability to, among other things, incur or assume certain debt, merge or consolidate, materially change the nature of the Company’s business, make certain investments, acquire or dispose of certain assets, make guaranties or grant liens on its assets, make certain loans, advances or investments, declare dividends or make distributions or enter into transactions with affiliates. In addition, the Term Loan contains a covenant that requires the Company to maintain a minimum unrestricted cash balance in the United States of at least $10.0 million at the inception of the Term Loan, which decreased starting November 1, 2012 and monthly thereafter by the amount of principal paid. The events of default under the Term Loan include, but are not limited to, failure to pay amounts due, breaches of covenants, bankruptcy events, cross defaults under other material indebtedness and the occurrence of a material adverse effect and/or change in control. In the case of a continuing event of default, Hercules may, among other remedies, declare due all unpaid principal amounts outstanding and any accrued but unpaid interest and foreclose on all collateral granted to Hercules as security under the Term Loan.
  (was, 2013-08-07, similarity 0.9794):
[0001193125-13-324142:note_history:27]
The Term Loan
contains certain covenants that restrict the Company’s
ability to, among other things, incur or assume certain debt, merge
or consolidate, materially change the nature of our business, make
certain investments, acquire or dispose of certain assets, make
guaranties or grant liens on its assets, make certain loans,
advances or investments, declare dividends or make distributions or
enter into transactions with affiliates. In addition, the Term Loan
contains a covenant that requires the Company to maintain a minimum
unrestricted cash balance in the United States of at least $10.0
million at the inception of the Term Loan, which decreased starting
November 1, 2012 and monthly thereafter by the amount of
principal paid. The events of default under the Term Loan include,
but are not limited to, failure to pay amounts due, breaches of
covenants, bankruptcy events, cross defaults under other material
indebtedness and the occurrence of a material adverse effect and/or
change in control. In the case of a continuing event of
default, the Lender may, among other remedies, declare due all
unpaid principal amounts outstanding and any accrued but unpaid
interest and foreclose on all collateral granted to the Lender as
security under the Term Loan.

- added (2013-11-12):
[0001564590-13-001183:note_history:28]
Interest expense on the Exchanged Note and Term Loan for the three and six months ended September 30, 2013 was $3.5 million and $5.6 million, respectively, which included $3.1 million and $4.8 million, respectively, of non-cash interest expense related to the amortization of the debt discount on the Exchanged Note and Term Loan and payment of the Exchanged Note in Company common stock at a discount. Interest expense on the Exchanged Note and Term Loan for the three and six months ended September 30, 2012 was $3.0 million, and $5.7 million, respectively, which included $2.3 million and $4.4 million, of non-cash interest expense related to the amortization of the debt discount on the Exchanged Note and Term Loan, respectively.

- removed (2013-11-12):
[0001193125-13-324142:note_history:29]
Interest
expense on the Exchanged Note and Term Loan for the three months
ended June 30, 2013 and 2012 was $2.1 million, and $2.7
million, respectively, which included $1.7 million and $2.3
million, respectively, of non-cash interest expense related to the
amortization of the debt discount on the Exchanged Note and Term
Loan and payment of the Exchanged Note in Company common stock at a
discount.


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: tag_name, score: 1.0

- changed (2013-11-12):
[0001564590-13-001183:note_history:30]
16. Subsequent Events
  (was, 2013-08-07, similarity 0.8636):
[0001193125-13-324142:note_history:30]
| 16. | Subsequent Events |

- added (2013-11-12):
[0001564590-13-001183:note_history:31]
On October 9, 2013, the Company entered into a Second Amendment with CVI.  (See Note 10 “Debt” and Note 11 “Warrant and Derivative Liabilities”.)

- removed (2013-11-12):
[0001193125-13-324142:note_history:32]
On
July 24, 2013, the Company undertook an action to reduce
headcount as part of its plan to reduce operating expenses in order
to enhance liquidity. The Company reduced its workforce by
approximately 7%, impacting primarily selling, engineering and
general and administrative functions. The Company expects to record
a restructuring charge for severance and other costs of
approximately $1.0 million in the second quarter of fiscal
2013.
