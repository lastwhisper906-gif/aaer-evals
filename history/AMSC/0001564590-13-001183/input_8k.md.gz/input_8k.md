# AMSC 8-K — 0001193125-13-431705 filed 2013-11-07

## item codes, every 8-K on or before 2013-11-12

- 2013-11-07 0001193125-13-431705 — 2.02, 9.01
- 2013-10-09 0001193125-13-395362 — 1.01, 2.03, 3.02, 9.01
- 2013-09-25 0001193125-13-378481 — 5.02, 9.01
- 2013-08-21 0001193125-13-341566 — 4.01, 9.01
- 2013-08-07 0001193125-13-323082 — 2.02, 9.01
- 2013-08-02 0001193125-13-317278 — 5.02, 5.07
- 2013-06-14 0001193125-13-258758 — 2.02, 9.01
- 2013-04-01 0001193125-13-136714 — 2.02, 8.01, 9.01
- 2013-02-20 0001193125-13-067218 — 5.02, 9.01
- 2013-02-14 0001193125-13-060131 — 1.01, 9.01
- 2013-02-11 0001193125-13-048784 — 2.02, 9.01
- 2013-01-08 0001193125-13-006861 — 5.02, 9.01
- 2012-12-21 0001193125-12-511592 — 1.01, 2.03, 3.02, 9.01
- 2012-11-28 0001193125-12-483317 — 2.05, 5.02, 7.01, 9.01
- 2012-11-06 0001193125-12-453359 — 2.02, 9.01
- 2012-08-02 0001193125-12-330534 — 2.02, 9.01
- 2012-07-27 0001193125-12-318790 — 5.02, 5.07, 9.01
- 2012-06-06 0001193125-12-261030 — 1.01, 2.02, 2.03, 3.02, 5.02, 9.01
- 2012-05-09 0001193125-12-222210 — 5.02
- 2012-04-20 0001193125-12-172045 — 8.01
- 2012-04-13 0001193125-12-162694 — 2.02, 8.01, 9.01
- 2012-04-04 0001193125-12-149102 — 1.01, 2.02, 2.03, 3.02, 9.01
- 2012-02-09 0001193125-12-048009 — 2.02, 9.01
- 2012-02-06 0001193125-12-041344 — 5.07 — amendment of 0000950123-11-102495
- 2011-12-08 0000950123-11-102495 — 5.07
- 2011-11-29 0000950123-11-100822 — 2.05
- 2011-11-09 0000950123-11-096775 — 2.02, 9.01
- 2011-10-31 0000950123-11-093390 — 1.02, 9.01
- 2011-10-07 0000950123-11-089221 — 8.01
- 2011-10-03 0000950123-11-088315 — 7.01
- 2011-09-23 0000950123-11-086288 — 2.02, 9.01
- 2011-09-15 0000950123-11-084585 — 7.01
- 2011-09-06 0000950123-11-082736 — 7.01
- 2011-08-18 0000950123-11-078526 — 3.01, 7.01, 9.01
- 2011-08-11 0000950123-11-075905 — 5.02
- 2011-08-11 0000950123-11-075904 — 2.02, 2.05, 9.01
- 2011-07-11 0000950123-11-064934 — 2.02, 4.02, 9.01
- 2011-06-30 0000950123-11-063287 — 1.01, 3.02, 9.01
- 2011-06-21 0000950123-11-060491 — 3.01, 7.01, 9.01
- 2011-06-13 0000950123-11-058656 — 1.01, 9.01
- 2011-05-24 0000950123-11-053517 — 5.02, 9.01
- 2011-04-05 0001299933-11-001020 — 2.02, 9.01
- 2011-03-15 0000950123-11-025580 — 5.02
- 2011-03-14 0000950123-11-025205 — 1.01, 3.02, 9.01
- 2011-02-01 0001299933-11-000333 — 2.02, 9.01
- 2010-11-12 0000950123-10-104604 — 8.01, 9.01
- 2010-11-08 0000950123-10-102424 — 8.01, 9.01
- 2010-11-02 0001299933-10-003878 — 2.02, 9.01
- 2010-09-15 0000950123-10-086373 — 1.01, 9.01 — amendment, the index does not say of what
- 2010-08-06 0000950123-10-074362 — 5.07
- 2010-07-29 0001299933-10-002860 — 2.02, 9.01
- 2010-05-17 0000950123-10-050424 — 1.01, 9.01
- 2010-05-14 0001299933-10-001972 — 5.02
- 2010-05-13 0001299933-10-001943 — 2.02, 9.01
- 2010-02-08 0001299933-10-000506 — 8.01
- 2010-02-02 0001299933-10-000386 — 2.02, 9.01
- 2009-12-15 0001299933-09-004928 — 5.02
- 2009-10-29 0001299933-09-004267 — 2.02, 9.01
- 2009-08-12 0001193125-09-173026 — 5.02, 9.01
- 2009-07-30 0001193125-09-158842 — 1.01, 2.02, 9.01
- 2009-05-15 0001193125-09-113158 — 5.02
- 2009-05-14 0001193125-09-110619 — 2.02, 9.01
- 2009-04-20 0001193125-09-082590 — 5.02
- 2009-02-03 0001193125-09-016992 — 2.02, 9.01
- 2009-01-22 0001193125-09-009777 — 2.02, 9.01
- 2008-11-04 0001193125-08-223730 — 2.02, 9.01
- 2008-08-11 0001193125-08-173616 — 8.01
- 2008-08-07 0001193125-08-170325 — 8.01
- 2008-08-05 0001193125-08-165888 — 2.02, 9.01
- 2008-06-11 0001193125-08-132049 — 1.01, 9.01
- 2008-05-20 0001193125-08-119372 — 5.02, 9.01
- 2008-05-08 0001193125-08-107052 — 2.02, 9.01
- 2008-01-31 0001193125-08-016233 — 2.02, 9.01
- 2008-01-30 0001193125-08-015494 — 5.03, 9.01
- 2007-11-01 0001193125-07-231866 — 2.02, 9.01
- 2007-10-31 0001193125-07-231225 — 2.05
- 2007-10-29 0001193125-07-228284 — 5.03, 9.01
- 2007-09-27 0001193125-07-208950 — 5.02
- 2007-08-09 0001193125-07-176553 — 2.02, 9.01
- 2007-08-07 0001193125-07-173829 — 1.01, 5.02, 9.01
- 2007-07-02 0001193125-07-148303 — 5.02, 9.01
- 2007-06-20 0001193125-07-139068 — 8.01, 9.01
- 2007-06-14 0001193125-07-135550 — 9.01 — amendment of 0001193125-07-005297
- 2007-06-14 0001193125-07-135340 — 5.02
- 2007-05-24 0001193125-07-122148 — 2.02, 9.01
- 2007-03-30 0001193125-07-070154 — 2.05, 9.01
- 2007-03-23 0001193125-07-062978 — 9.01 — amendment of 0001193125-07-005297
- 2007-02-01 0001193125-07-017883 — 2.02, 9.01
- 2007-01-11 0001193125-07-005297 — 2.01, 9.01
- 2006-12-05 0001181431-06-067500 — 5.02
- 2006-11-29 0001193125-06-243360 — 1.01, 3.02, 9.01
- 2006-11-02 0001193125-06-221464 — 2.02, 9.01
- 2006-09-21 0001193125-06-194526 — 5.02
- 2006-08-08 0001193125-06-164819 — 2.02, 9.01
- 2006-08-02 0001193125-06-159113 — 1.01, 9.01
- 2006-07-28 0001193125-06-156172 — 1.01
- 2006-06-26 0001193125-06-135913 — 1.01, 3.03, 9.01
- 2006-05-11 0001193125-06-108489 — 2.02, 9.01
- 2006-05-05 0001193125-06-102270 — 1.01, 9.01
- 2006-05-01 0001193125-06-094941 — 2.02, 2.06, 9.01
- 2006-02-24 0001193125-06-038281 — 5.02, 9.01
- 2006-02-02 0001181431-06-007665 — 2.02, 9.01
- 2005-11-09 0001181431-05-060304 — 2.02, 9.01
- 2005-08-04 0001181431-05-044420 — 2.02, 9.01
- 2005-07-28 0001193125-05-151272 — 5.02, 9.01
- 2005-06-14 0001193125-05-125148 — 5.02, 9.01
- 2005-05-12 0001181431-05-027410 — 2.02, 9.01
- 2005-05-10 0001193125-05-102795 — 1.01
- 2005-04-05 0001181431-05-020680 — 1.01, 2.02, 3.02, 9.01
- 2005-02-03 0001181431-05-006678 — 2.02, 9.01
- 2004-11-09 0001181431-04-051381 — 2.02, 9.01 — amendment, the index does not say of what
- 2004-11-04 0001181431-04-050706 — 2.02, 9.01
- 2004-10-15 0001193125-04-172458 — 1.01, 9.01
- 2004-08-05 0001193125-04-132162 — 12
- 2004-05-13 0001193125-04-086853 — 12
- 2004-02-05 0001193125-04-015060 — 12
- 2003-11-06 0001193125-03-074000 — 12
- 2003-09-26 0001193125-03-054624 — 5
- 2003-08-06 0001193125-03-029666 — 12
- 2003-05-14 0000927016-03-002619 — 9
- 2002-12-31 0000927016-02-006114 — 5
- 2000-01-24 0000927016-00-000150 — 5, 7
- 1998-11-02 0000950135-98-005625 — 5, 7
- 1998-03-24 0000950135-98-001743 — 5, 7
- 1997-09-05 0000950135-97-003729 — 5, 7
- 1997-06-23 0000950135-97-002785 — 1 — amendment of 0000950135-97-001972
- 1997-04-23 0000950135-97-001972 — 2, 7

## late-filing notifications on or before 2013-11-12

- 2011-08-10 0000950123-11-075677 — NT 10-Q, for the period ended 2011-06-30
- 2011-05-31 0000950123-11-055465 — NT 10-K, for the period ended 2011-03-31

## item 2.02 — earnings release, exhibit 99.1

[0001193125-13-431705:8k_2_02:1]
EX-99.1
2
d623766dex991.htm
EX-99.1

[0001193125-13-431705:8k_2_02:2]
EX-99.1

[0001193125-13-431705:8k_2_02:3]
Exhibit 99.1

[0001193125-13-431705:8k_2_02:4]
AMSC Reports Fiscal Second Quarter 2013

[0001193125-13-431705:8k_2_02:5]
Financial Results

[0001193125-13-431705:8k_2_02:6]
Focused on Achieving Positive Net Cash Flows by the Fourth Quarter

[0001193125-13-431705:8k_2_02:7]
Of Fiscal Year 2014

[0001193125-13-431705:8k_2_02:8]
Devens, MA – November 7, 2013 – AMSC (NASDAQ: AMSC), a global solutions provider serving wind and power grid industry leaders, today
reported financial results for its fiscal second quarter ended September 30, 2013.

[0001193125-13-431705:8k_2_02:9]
Revenues for the second quarter of fiscal 2013 were
$24.2 million, compared with $20.9 million for the same period of fiscal 2012. The year-over-year growth is due to higher revenues in both the Company’s Wind and Grid segments.

[0001193125-13-431705:8k_2_02:10]
AMSC’s net loss for the second quarter of fiscal 2013 narrowed to $14.6 million, or $0.24 per share, compared with a net loss of $15.9 million, or $0.31 per share, for the same period of fiscal 2012.

[0001193125-13-431705:8k_2_02:11]
The Company’s non-GAAP net loss for the second quarter of fiscal 2013 was $10.8 million, or $0.18 per share, compared with a non-GAAP
net loss of $16.0 million, or $0.31 per share, for the second quarter of fiscal 2012. Please refer to the financial table below for a reconciliation of GAAP to non-GAAP results.

[0001193125-13-431705:8k_2_02:12]
Cash, cash equivalents, and restricted cash at September 30, 2013 totaled $32.8 million, compared with $39.5 million as of June 30, 2013.

[0001193125-13-431705:8k_2_02:13]
“We are pleased with the year-over-year revenue growth and improved operating performance that we delivered during the second fiscal quarter,”
said Daniel P. McGahn, AMSC President and CEO. “We grew revenues by 16 percent year over year, improved gross margins nearly threefold and reduced our non-GAAP net loss by more than 30 percent. We continue to be focused on achieving our target
of positive net cash flows on a quarterly basis by the end of fiscal year 2014.”

[0001193125-13-431705:8k_2_02:14]
“Looking forward, we believe there are risks to
achieving our full year revenue target, as a result of governmental factors impacting the renewable industries in Australia, China, and India. Wind projects in Australia are being impacted by political uncertainty from the recent election, causing
delays for projects in our Grid segment. The recovery of the Chinese wind market is being slowed by the continued grid infrastructure challenges. In India, the regulatory framework intended to stimulate the wind industry was put in place six months
after the beginning of the Indian fiscal year, which created uncertainty,” continued McGahn. “We see these challenges as short-term and we continue to believe that the long-term growth opportunities remain for both our wind and grid
businesses in established and emerging markets.”

[0001193125-13-431705:8k_2_02:15]
| AMSC Reports Q2 Results |  | Page 2 |

[0001193125-13-431705:8k_2_02:16]
Financing Arrangements

[0001193125-13-431705:8k_2_02:17]
During the second fiscal quarter, AMSC filed a shelf registration statement and amended certain terms of its convertible note with the note holder. As a result of this amendment, AMSC is now permitted to
increase the amount of senior debt from $10 million to $15 million. In order to enhance liquidity, the Company may, subject to market and other considerations, seek additional debt and/or equity financing arrangements. There can be no assurance that
the Company will be able to consummate any such financings on acceptable terms, if at all.

[0001193125-13-431705:8k_2_02:18]
Financial Guidance

[0001193125-13-431705:8k_2_02:19]
For the third fiscal quarter ending December 31, 2013, AMSC expects that its revenues will exceed $18 million and that its net loss will be less than
$17 million, or $0.28 per share. This forecast excludes any impact from mark-to-market adjustments related to the Company’s derivative liability and warrants. AMSC expects that its non-GAAP net loss for its third quarter of fiscal 2013 will be
less than $12 million, or $0.19 per share. AMSC expects to have more than $25 million in cash, cash equivalents and restricted cash on December 31, 2013.

[0001193125-13-431705:8k_2_02:20]
Conference Call Reminder

[0001193125-13-431705:8k_2_02:21]
In conjunction with this announcement, AMSC management will host
a conference call with investors beginning at 10:00 a.m. Eastern Time today to discuss the Company’s results and its business outlook. To listen to the live or archived conference call webcast please visit the “Investors” section of
the Company’s website at http://www.amsc.com/investors. The live call also can be accessed by dialing 647-438-1131 and using conference ID 2611527.

[0001193125-13-431705:8k_2_02:22]
About AMSC (NASDAQ: AMSC)

[0001193125-13-431705:8k_2_02:23]
AMSC generates the ideas, technologies and solutions that
meet the world’s demand for smarter, cleaner … better energy™. Through its Windtec™ Solutions, AMSC provides wind turbine electronic controls and systems, designs and engineering services that reduce the cost of wind energy.
Through its Gridtec™ Solutions, AMSC provides the engineering planning services and advanced grid systems that optimize network reliability, efficiency and performance. The Company’s solutions are now powering gigawatts of renewable energy
globally and are enhancing the performance and reliability of power networks in more than a dozen countries. Founded in 1987, AMSC is headquartered near Boston, Massachusetts with operations in Asia, Australia, Europe and North America. For more
information, please visit www.amsc.com.

[0001193125-13-431705:8k_2_02:24]
AMSC, Windtec, Gridtec, D-VAR, and Smarter, Cleaner … Better Energy are trademarks or
registered trademarks of American Superconductor Corporation. All other brand names, product names, trademarks or service marks belong to their respective holders.

[0001193125-13-431705:8k_2_02:25]
There are a number of important factors that could materially impact the value of our common stock or cause actual results to differ materially from
those indicated by such forward-looking statements. Such factors include: We have experienced recurring operating losses and recurring negative cash flows from operations which raise substantial doubt about our ability to continue

[0001193125-13-431705:8k_2_02:26]
| AMSC Reports Q2 Results |  | Page 3 |

[0001193125-13-431705:8k_2_02:27]
as a going concern. This substantial doubt has resulted in a qualified opinion from our auditors with an explanatory paragraph regarding our ability to continue as a going concern. We believe
this opinion may have an adverse effect on our customer and supplier relationships; our success in addressing the wind energy market is dependent on the manufacturers that license our designs; we may not realize all of the sales expected from our
backlog of orders and contracts; our business and operations would be adversely impacted in the event of a failure or security breach of our information technology infrastructure; our success is dependent upon attracting and retaining qualified
personnel and our inability to do so could significantly damage our business and prospects; we rely upon third-party suppliers for the components and subassemblies of many of our Wind and Grid products, making us vulnerable to supply shortages and
price fluctuations, which could harm our business; many of our revenue opportunities are dependent upon subcontractors and other business collaborators; if we fail to implement our business strategy successfully, our financial performance could be
harmed; problems with product quality or product performance may cause us to incur warranty expenses and may damage our market reputation and prevent us from achieving increased sales and market share; new regulations related to conflict-free
minerals may force us to incur significant additional expenses; our contracts with the U. S. government are subject to audit, modification or termination by the U.S. government and include certain other provisions in favor of the government; the
continued funding of such contracts remains subject to annual congressional appropriation which, if not approved, could reduce our revenue and lower or eliminate our profit; we may acquire additional complementary businesses or technologies, which
may require us to incur substantial costs for which we may never realize the anticipated benefits; many of our customers outside of the United States are, either directly or indirectly, related to governmental entities, and we could be adversely
affected by violations of the United States Foreign Corrupt Practices Act and similar worldwide anti-bribery laws outside the United States; we have limited experience in marketing and selling our superconductor products and system-level solutions,
and our failure to effectively market and sell our products and solutions could lower our revenue and cash flow; we have experienced recurring losses from operations and negative operating cash flow; these factors raise substantial doubt regarding
our ability to continue as a going concern; we have a history of operating losses, and we may incur additional losses in the future; our operating results may fluctuate significantly from quarter to quarter and may fall below expectations in any
particular fiscal quarter; we may require additional funding in the future and may be unable to raise capital when needed; our debt obligations include certain covenants and other events of default;. Should we not comply with the covenants or incur
an event of default, we may be required to repay our debt obligations in cash, which could have an adverse effect on our liquidity; if we fail to maintain proper and effective internal controls over financial reporting, our ability to produce
accurate and timely financial statements could be impaired and may lead investors and other users to lose confidence in our financial data; we may be required to issue performance bonds or provide letters of credit, which restricts our ability to
access any cash used as collateral for the bonds or letters of credit; changes in exchange rates could adversely affect our results from operations; growth of the wind energy market depends largely on the availability and size of government
subsidies and economic incentives; we depend on sales to customers in China, and global conditions could negatively affect our operating results or limit our ability to expand our operations outside of China; changes in China’s political,
social, regulatory and economic environment may affect our financial performance; our products face intense competition, which could limit our ability to acquire or retain customers; our international operations are subject to risks that we do not
face in the United States, which could have an adverse effect on our operating results; adverse changes in domestic and global economic conditions could adversely affect our operating results; we may be unable to adequately prevent disclosure of
trade secrets and other proprietary information; our patents may not provide meaningful protection for our technology, which could result in us losing some or all of our market position; the commercial uses of superconductor products are limited
today, and a widespread commercial market for our products may not develop; there are a number of technological challenges that must be successfully addressed before our superconductor products can gain widespread commercial acceptance, and our
inability to address such technological challenges could adversely affect our ability to acquire customers for our products; we have not manufactured our Amperium wire in commercial quantities, and a failure to manufacture our Amperium wire in
commercial quantities at acceptable cost and quality levels would substantially limit our future revenue and profit potential; third parties have or may acquire patents that cover the materials, processes and technologies we use or may use in the
future to manufacture our Amperium products, and our success depends on our ability to license such patents or other proprietary rights; our technology and products could infringe intellectual property rights of others, which may require costly
litigation and, if we are not successful, could cause us to pay substantial damages and disrupt our business; we have filed a demand for arbitration and other lawsuits against our former largest customer, Sinovel, regarding amounts we contend are
overdue. We cannot be certain as to the outcome of these proceedings; we have been named as a party to purported stockholder class actions and stockholder derivative complaints, and we may be named in additional litigation, all of which will require
significant management time and attention, result in significant legal expenses and may result in an unfavorable outcome, which could have a material adverse effect on our business, operating results and financial condition; our 7% convertible note
contains warrants and provisions that could limit our ability to repay the note in shares of common stock and should the note be repaid in stock, shareholders could experience significant dilution; our common stock has experienced, and may continue
to experience, significant market price and volume fluctuations, which may prevent our stockholders from selling our common stock at a profit and could lead to costly litigation against us that could divert our management’s attention;. These
and the important factors discussed under the caption “Risk Factors” in Part 1. Item 1A of our Form 10-K for the fiscal year ended March 31, 2013, and our other reports filed with the SEC,

[0001193125-13-431705:8k_2_02:28]
| AMSC Reports Q2 Results |  | Page 4 |

[0001193125-13-431705:8k_2_02:29]
among others, could cause actual results to differ materially from those indicated by forward-looking statements made herein and presented elsewhere by management from time to time. Any such
forward-looking statements represent management’s estimates as of the date of this press release. While we may elect to update such forward-looking statements at some point in the future, we disclaim any obligation to do so, even if subsequent
events cause our views to change. These forward-looking statements should not be relied upon as representing our views as of any date subsequent to the date of this press release.

[0001193125-13-431705:8k_2_02:30]
UNAUDITED CONSOLIDATED STATEMENTS OF OPERATIONS

[0001193125-13-431705:8k_2_02:31]
(In thousands, except per share data)

[0001193125-13-431705:8k_2_02:32]
|  |  | Three months ended |  |  | Six months ended |  |
|  |  | September 30, |  |  | September 30, |  |
|  |  | 2013 |  |  | 2012 |  |  | 2013 |  |  | 2012 |  |
| Revenues |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Wind |  | $ | 14,691 |  |  | $ | 12,002 |  |  | $ | 29,392 |  |  | $ | 28,513 |  |
| Grid |  |  | 9,490 |  |  |  | 8,865 |  |  |  | 17,875 |  |  |  | 21,070 |  |
| Total Revenues |  |  | 24,181 |  |  |  | 20,867 |  |  |  | 47,267 |  |  |  | 49,583 |  |
| Cost of revenues |  |  | 22,611 |  |  |  | 20,384 |  |  |  | 40,598 |  |  |  | 37,310 |  |
| Gross profit (loss) |  |  | 1,570 |  |  |  | 483 |  |  |  | 6,669 |  |  |  | 12,273 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Research and development |  |  | 3,083 |  |  |  | 3,621 |  |  |  | 6,110 |  |  |  | 7,532 |  |
| Selling, general and administrative |  |  | 8,682 |  |  |  | 11,736 |  |  |  | 19,508 |  |  |  | 25,535 |  |
| Restructuring and impairments |  |  | 751 |  |  |  | 16 |  |  |  | 764 |  |  |  | 143 |  |
| Amortization of acquisition related intangibles |  |  | 82 |  |  |  | 80 |  |  |  | 164 |  |  |  | 161 |  |
| Total operating expenses |  |  | 12,598 |  |  |  | 15,453 |  |  |  | 26,546 |  |  |  | 33,371 |  |
| Operating loss |  |  | (11,028 | ) |  |  | (14,970 | ) |  |  | (19,877 | ) |  |  | (21,098 | ) |
| Change in fair value of derivatives and warrants |  |  | 886 |  |  |  | 3,285 |  |  |  | 1,355 |  |  |  | 897 |  |
| Interest expense, net |  |  | (3,505 | ) |  |  | (2,919 | ) |  |  | (5,617 | ) |  |  | (5,637 | ) |
| Other expense, net |  |  | (635 | ) |  |  | (1,266 | ) |  |  | (566 | ) |  |  | (1,143 | ) |
| Loss before income tax expense |  |  | (14,282 | ) |  |  | (15,870 | ) |  |  | (24,705 | ) |  |  | (26,981 | ) |
| Income tax (benefit) expense |  |  | 341 |  |  |  | 79 |  |  |  | 430 |  |  |  | (757 | ) |
| Net loss |  | $ | (14,623 | ) |  | $ | (15,949 | ) |  | $ | (25,135 | ) |  | $ | (26,224 | ) |
| Net loss per common share |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | (0.24 | ) |  | $ | (0.31 | ) |  | $ | (0.42 | ) |  | $ | (0.51 | ) |
| Diluted |  | $ | (0.24 | ) |  | $ | (0.31 | ) |  | $ | (0.42 | ) |  | $ | (0.51 | ) |
| Weighted average number of common shares outstanding |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  |  | 61,116 |  |  |  | 51,907 |  |  |  | 59,712 |  |  |  | 51,551 |  |
| Diluted |  |  | 61,116 |  |  |  | 51,907 |  |  |  | 59,712 |  |  |  | 51,551 |  |

[0001193125-13-431705:8k_2_02:33]
| AMSC Reports Q2 Results |  | Page 5 |

[0001193125-13-431705:8k_2_02:34]
UNAUDITED CONSOLIDATED BALANCE SHEETS

[0001193125-13-431705:8k_2_02:35]
(In thousands)

[0001193125-13-431705:8k_2_02:36]
|  |  | September 30, |  |  | March 31, |  |
|  |  | 2013 |  |  | 2013 |  |
| ASSETS |  |  |  |  |  |  |  |  |
| Current assets: |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 25,867 |  |  | $ | 39,243 |  |
| Accounts receivable, net |  |  | 9,289 |  |  |  | 18,864 |  |
| Inventory |  |  | 24,474 |  |  |  | 33,473 |  |
| Prepaid expenses and other current assets |  |  | 19,337 |  |  |  | 22,469 |  |
| Restricted cash |  |  | 2,021 |  |  |  | 6,136 |  |
| Total current assets |  |  | 80,988 |  |  |  | 120,185 |  |
| Property, plant and equipment, net |  |  | 69,584 |  |  |  | 74,626 |  |
| Intangibles, net |  |  | 2,348 |  |  |  | 2,749 |  |
| Restricted cash |  |  | 4,901 |  |  |  | 4,820 |  |
| Deferred tax assets |  |  | 5,421 |  |  |  | 5,354 |  |
| Other assets |  |  | 9,283 |  |  |  | 9,020 |  |
| Total assets |  | $ | 172,525 |  |  | $ | 216,754 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |  |  |  |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |  |  |  |
| Accounts payable and accrued expenses |  | $ | 22,724 |  |  | $ | 30,138 |  |
| Note payable, current portion, net of discount of $260 as of September 30, 2013 and $458 as of March 31, 2013 |  |  | 4,355 |  |  |  | 4,158 |  |
| Convertible note, current portion, net of discount of $2,230 as of September 30, 2013 and $4,289 as of March 31, 2013 |  |  | 7,255 |  |  |  | 4,610 |  |
| Derivative liability |  |  | 2,807 |  |  |  | 4,162 |  |
| Adverse purchase commitments |  |  | 962 |  |  |  | 1,440 |  |
| Deferred revenue, current portion |  |  | 11,490 |  |  |  | 29,805 |  |
| Deferred tax liabilities |  |  | 5,452 |  |  |  | 5,444 |  |
| Total current liabilities |  |  | 55,045 |  |  |  | 79,757 |  |
| Note payable, net of discount of $16 as of September 30, 2013 and $95 as of March 31, 2013 |  |  | 1,138 |  |  |  | 3,367 |  |
| Convertible note net of discount of $0 as of September 30, 2013 and $600 as of March 31, 2013 |  |  | 926 |  |  |  | 5,881 |  |
| Deferred revenue |  |  | 1,374 |  |  |  | 1,340 |  |
| Other liabilities |  |  | 1,184 |  |  |  | 1,291 |  |
| Total liabilities |  |  | 59,667 |  |  |  | 91,636 |  |
| Stockholders’ equity: |  |  |  |  |  |  |  |  |
| Common stock |  |  | 640 |  |  |  | 603 |  |
| Additional paid-in capital |  |  | 936,086 |  |  |  | 923,847 |  |
| Treasury stock |  |  | (370 | ) |  |  | (313 | ) |
| Accumulated other comprehensive income |  |  | 1,768 |  |  |  | 1,112 |  |
| Accumulated deficit |  |  | (825,266 | ) |  |  | (800,131 | ) |
| Total stockholders’ equity |  |  | 112,858 |  |  |  | 125,118 |  |
| Total liabilities and stockholders’ equity |  | $ | 172,525 |  |  | $ | 216,754 |  |

[0001193125-13-431705:8k_2_02:37]
| AMSC Reports Q2 Results |  | Page 6 |

[0001193125-13-431705:8k_2_02:38]
UNAUDITED CONSOLIDATED STATEMENTS OF CASH FLOWS

[0001193125-13-431705:8k_2_02:39]
(In thousands)

[0001193125-13-431705:8k_2_02:40]
|  |  | Six months ended September 30, |  |
|  |  | 2013 |  |  | 2012 |  |
| Cash flows from operating activities: |  |  |  |  |  |  |  |  |
| Net loss |  | $ | (25,135 | ) |  | $ | (26,224 | ) |
| Adjustments to reconcile net income to net cash used in operations: |  |  |  |  |  |  |  |  |
| Depreciation and amortization |  |  | 5,343 |  |  |  | 6,628 |  |
| Stock-based compensation expense |  |  | 4,287 |  |  |  | 4,039 |  |
| Restructuring charges, net of payments |  |  | 161 |  |  |  | (49 | ) |
| Provision for excess and obsolete inventory |  |  | 192 |  |  |  | 421 |  |
| Adverse purchase commitment recoveries, net |  |  | — |  |  |  | (8,309 | ) |
| Loss on minority interest investments |  |  | 499 |  |  |  | 1,490 |  |
| Change in fair value of derivatives and warrants |  |  | (1,355 | ) |  |  | (897 | ) |
| Non-cash interest expense |  |  | 4,765 |  |  |  | 4,443 |  |
| Other non-cash items |  |  | 892 |  |  |  | 350 |  |
| Changes in operating asset and liability accounts: |  |  |  |  |  |  |  |  |
| Accounts receivable |  |  | 10,704 |  |  |  | 2,856 |  |
| Inventory |  |  | 9,315 |  |  |  | (971 | ) |
| Prepaid expenses and other current assets |  |  | 3,531 |  |  |  | 8,394 |  |
| Accounts payable and accrued expenses |  |  | (9,105 | ) |  |  | (14,900 | ) |
| Deferred revenue |  |  | (18,873 | ) |  |  | (2,236 | ) |
| Net cash used in operating activities |  |  | (14,779 | ) |  |  | (24,965 | ) |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |
| Net cash provided by (used in) investing activities |  |  | 3,443 |  |  |  | (4,935 | ) |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |
| Net cash (used in) provided by financing activities |  |  | (2,266 | ) |  |  | 33,037 |  |
| Effect of exchange rate changes on cash and cash equivalents |  |  | 226 |  |  |  | (280 | ) |
| Net (decrease) increase in cash and cash equivalents |  |  | (13,376 | ) |  |  | 2,857 |  |
| Cash and cash equivalents at beginning of year |  |  | 39,243 |  |  |  | 46,279 |  |
| Cash and cash equivalents at end of period |  | $ | 25,867 |  |  | $ | 49,136 |  |

[0001193125-13-431705:8k_2_02:41]
| AMSC Reports Q2 Results |  | Page 7 |

[0001193125-13-431705:8k_2_02:42]
RECONCILIATION OF GAAP NET INCOME (LOSS) TO NON-GAAP NET INCOME (LOSS)

[0001193125-13-431705:8k_2_02:43]
(In thousands, except per share data)

[0001193125-13-431705:8k_2_02:44]
|  |  | Three months ended September 30, |  |  | Six months ended September 30, |  |
|  |  | 2013 |  |  | 2012 |  |  | 2013 |  |  | 2012 |  |
| Net loss |  | $ | (14,623 | ) |  | $ | (15,949 | ) |  | $ | (25,135 | ) |  | $ | (26,224 | ) |
| Adverse purchase commitment recoveries, net |  |  | — |  |  |  | (1,009 | ) |  |  | — |  |  |  | (8,309 | ) |
| Stock-based compensation |  |  | 2,152 |  |  |  | 2,044 |  |  |  | 4,287 |  |  |  | 4,039 |  |
| Amortization of acquisition-related intangibles |  |  | 82 |  |  |  | 80 |  |  |  | 164 |  |  |  | 161 |  |
| Restructuring and impairment charges |  |  | 751 |  |  |  | 16 |  |  |  | 764 |  |  |  | 143 |  |
| Sinovel litigation |  |  | (5 | ) |  |  | 304 |  |  |  | (7 | ) |  |  | 424 |  |
| Consumption of zero cost-basis inventory |  |  | (1,319 | ) |  |  | (401 | ) |  |  | (2,493 | ) |  |  | (788 | ) |
| Change of fair value of derivatives and warrants |  |  | (886 | ) |  |  | (3,285 | ) |  |  | (1,355 | ) |  |  | (897 | ) |
| Non-cash interest expense |  |  | 3,093 |  |  |  | 2,161 |  |  |  | 4,765 |  |  |  | 4,443 |  |
| Non-GAAP net loss |  | $ | (10,755 | ) |  | $ | (16,039 | ) |  | $ | (19,010 | ) |  | $ | (27,008 | ) |
| Non-GAAP loss per share |  | $ | (0.18 | ) |  | $ | (0.31 | ) |  | $ | (0.32 | ) |  | $ | (0.52 | ) |
| Weighted average shares outstanding |  |  | 61,116 |  |  |  | 51,907 |  |  |  | 59,712 |  |  |  | 51,551 |  |

[0001193125-13-431705:8k_2_02:45]
RECONCILIATION OF FORECAST GAAP NET LOSS TO NON-GAAP

[0001193125-13-431705:8k_2_02:46]
NET LOSS

[0001193125-13-431705:8k_2_02:47]
(In millions, except per share data)

[0001193125-13-431705:8k_2_02:48]
|  |  | Three months endingDec. 31, 2013 |  |
| Net loss |  | $ | (17.0 | ) |
| Amortization of acquisition-related intangibles |  |  | 0.1 |  |
| Stock-based compensation |  |  | 2.8 |  |
| Non-cash interest expense |  |  | 3.3 |  |
| Consumption of zero-cost inventory |  |  | (1.2 | ) |
| Non-GAAP net loss |  | $ | (12.0 | ) |
| Non-GAAP net loss per share |  | $ | (0.19 | ) |
| Shares outstanding |  |  | 61.8 |  |

[0001193125-13-431705:8k_2_02:49]
| AMSC Reports Q2 Results |  | Page 8 |

[0001193125-13-431705:8k_2_02:50]
Note: Non-GAAP net loss is defined by the company as net loss before adverse purchase commitments
(recoveries) losses, net; stock-based compensation; amortization of acquisition-related intangibles; restructuring and impairment charges; Sinovel litigation costs; consumption of zero cost-basis inventory; non-cash interest expense; change in fair
value of derivatives and warrants and other unusual charges; net of any tax effects related to these items. The company believes non-GAAP net loss assists management and investors in comparing the company’s performance across reporting periods
on a consistent basis by excluding these non-cash or other non-recurring charges that it does not believe are indicative of its core operating performance. The company also regards non-GAAP net loss as a useful measure of operating performance and
cash flow to complement operating loss, net loss and other GAAP financial performance measures. In addition, the company uses non-GAAP net loss as a factor in evaluating management’s performance when determining incentive compensation and to
evaluate the effectiveness of its business strategies.

[0001193125-13-431705:8k_2_02:51]
Generally, a non-GAAP financial measure is a numerical measure of a
company’s performance, financial position or cash flow that either excludes or includes amounts that are not normally excluded or included in the most directly comparable measure calculated and presented in accordance with GAAP. The non-GAAP
measures included in this release, however, should be considered in addition to, and not as a substitute for or superior to, operating income, cash flows, or other measures of financial performance prepared in accordance with GAAP. A reconciliation
of non-GAAP to GAAP net loss is set forth in the table above.

[0001193125-13-431705:8k_2_02:52]
AMSC Contact:

[0001193125-13-431705:8k_2_02:53]
Kerry Farrell

[0001193125-13-431705:8k_2_02:54]
Phone: 978-842-3247

[0001193125-13-431705:8k_2_02:55]
Email: kerry.farrell@amsc.com
