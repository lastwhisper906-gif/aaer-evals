# AMSC MD&A — 0001628280-16-020601


## mdna

[0001628280-16-020601:mdna:1]
[same as prior period, unchanged from 0001628280-16-018764:mdna:1]

[0001628280-16-020601:mdna:2]
depends on our ability to license such patents or other proprietary rights; Our technology and products could infringe intellectual property rights of others, which may require costly litigation and, if we are not successful, could cause us to pay substantial damages and disrupt our business; We have filed a demand for arbitration and other lawsuits against our former largest customer, Sinovel, regarding amounts we contend are overdue. We cannot be certain as to the outcome of these proceedings; We have been named as a party in various legal proceedings, and we may be named in additional litigation, all of which will require significant management time and attention, result in significant legal expenses and may result in an unfavorable outcome, which could have a material adverse effect on our business, operating results and financial condition; and our common stock has experienced, and may continue to experience, significant market price and volume fluctuations, which may prevent our stockholders from selling our common stock at a profit and could lead to costly litigation against us that could divert our management’s attention.  These and the important factors discussed under the caption “Risk Factors” in Part 1. Item 1A of our Form 10-K for the fiscal year ended March 31, 2016, among others, could cause actual results to differ materially from those indicated by forward-looking statements made herein and presented elsewhere by management from time to time. Any such forward-looking statements represent management’s estimates as of the date of this Quarterly Report on Form 10-Q. While we may elect to update such forward-looking statements at some point in the future, we disclaim any obligation to do so, even if subsequent events cause our views to change. These forward-looking statements should not be relied upon as representing our views as of any date subsequent to the date of this Quarterly Report on Form 10-Q.

[0001628280-16-020601:mdna:3]
[same as prior period, unchanged from 0001628280-16-018764:mdna:3]

[0001628280-16-020601:mdna:4]
[same as prior period, unchanged from 0001628280-16-018764:mdna:4]

[0001628280-16-020601:mdna:5]
[same as prior period, unchanged from 0001628280-16-018764:mdna:5]

[0001628280-16-020601:mdna:6]
[same as prior period, unchanged from 0001628280-16-018764:mdna:6]

[0001628280-16-020601:mdna:7]
[same as prior period, unchanged from 0001628280-16-018764:mdna:7]

[0001628280-16-020601:mdna:8]
[same as prior period, unchanged from 0001628280-16-018764:mdna:8]

[0001628280-16-020601:mdna:9]
[same as prior period, unchanged from 0001628280-16-018764:mdna:9]

[0001628280-16-020601:mdna:10]
[same as prior period, unchanged from 0001628280-16-018764:mdna:10]

[0001628280-16-020601:mdna:11]
[same as prior period, unchanged from 0001628280-16-018764:mdna:11]

[0001628280-16-020601:mdna:12]
[same as prior period, unchanged from 0001628280-16-018764:mdna:12]

[0001628280-16-020601:mdna:13]
We have experienced recurring operating losses and as of September 30, 2016, had an accumulated deficit of $945.9 million. In addition, we have experienced recurring negative operating cash flows.  At September 30, 2016, we had cash and cash equivalents of $25.3 million. Cash used in operations for the six months ended September 30, 2016 was $10.9 million.  We expect to use less cash for operations in the second half of the fiscal year ending March 31, 2017 compared to the first half.  See "Liquidity and Capital Resources" below for additional discussion.

[0001628280-16-020601:mdna:14]
Over the last several years, we have entered into several debt and equity financing arrangements in order to enhance liquidity.  Since April 1, 2012, we generated aggregate cash flows from financing activities of $68.5 million.  This amount includes proceeds from our April 2015 equity offering, which generated net proceeds of approximately $22.3 million, after deducting underwriting discounts, commissions and offering expenses.  See Note 9, “Debt”, and Note 11 “Stockholders Equity” for further discussion of these financing arrangements. We believe that we are in compliance with the covenants and restrictions included in the agreements governing our debt arrangements as of September 30, 2016.

[0001628280-16-020601:mdna:15]
In March 2016, we entered into a set of agreements (collectively, the "Joint Development Agreement") to jointly develop an advanced low cost manufacturing process for second generation high temperature superconductor wire with BASF Corporation ("BASF"). Under the Joint Development Agreement, our manufacturing know-how for our Amperium® superconductor wire and BASF's chemical solution deposition production technology will be combined. As part of the Joint Development Agreement, we also entered into a royalty-bearing, non-exclusive license under which we agreed to provide BASF a specified portion of our second generation (2G) HTS wire manufacturing technology.

[0001628280-16-020601:mdna:16]
Our cash requirements depend on numerous factors, including the successful completion of our product development activities, our ability to commercialize our Resilient Electric Grid (“REG“) and ship protection system solutions, rate of customer and market adoption of our products, collecting receivables according to established terms, and the continued availability of U.S. government funding during the product development phase of our Superconductors based products. In December 2015, we entered into a set of strategic agreements valued at approximately $210.0 million with Inox Wind Limited ("Inox"), which includes a multi-year supply contract pursuant to which we will supply electric control systems to Inox and a license agreement allowing Inox to manufacture a limited number of electrical control systems over the next three to four years.  After this initial three to four year period, Inox agreed that we will continue as Inox’s preferred supplier and Inox will be required to purchase from us a majority of its electric control systems requirements for an additional three-year period.  These agreements are expected to provide a foundation for the business as we pursue our longer-term objectives.  Significant deviations to our business plan with regard to these factors and events, including any prolonged disruption in our revenues with our largest customers, which are important drivers to our business, could have a material adverse effect on our operating performance, financial condition, and future business prospects. We expect to pursue the expansion of our operations through internal growth, diversification of our customer base, and potential strategic alliances. See “Liquidity and Capital Resources” below for additional discussion.

[0001628280-16-020601:mdna:17]
[same as prior period, unchanged from 0001628280-16-018764:mdna:17]

[0001628280-16-020601:mdna:18]
[same as prior period, unchanged from 0001628280-16-018764:mdna:18]

[0001628280-16-020601:mdna:19]
The preparation of the unaudited condensed consolidated financial statements requires that we make estimates and judgments that affect the reported amounts of assets, liabilities, revenues and expenses, and related disclosure of contingent assets and liabilities. We base our estimates on historical experience and various other assumptions that are believed to be reasonable under the circumstances, the results of which form the basis for making judgments about the carrying values of assets and liabilities that are not readily apparent from other sources. Actual results may differ under different assumptions or conditions.  During the six months ended September 30, 2016 there were no significant changes in the critical accounting policies that were disclosed in our Form 10-K for fiscal 2015, which ended on March 31, 2016.

[0001628280-16-020601:mdna:20]
[same as prior period, unchanged from 0001628280-16-018764:mdna:20]

[0001628280-16-020601:mdna:21]
Three and six months ended September 30, 2016 compared to the three and six months ended September 30, 2015

[0001628280-16-020601:mdna:22]
[same as prior period, unchanged from 0001628280-16-018764:mdna:22]

[0001628280-16-020601:mdna:23]
Total revenues decreased 3% and 25% to $18.5 million and $31.9 million for the three and six months ended September 30, 2016, respectively, compared to $19.0 million and $42.7 million for the three and six months ended September 30, 2015, respectively.  Our revenues are summarized as follows (in thousands):

[0001628280-16-020601:mdna:24]
|  | Three months ended September 30, |  | Six months ended September 30, |
|  | 2016 |  | 2015 |  | 2016 |  | 2015 |
| Revenues: |  |  |  |  |  |  |  |  |  |
| Wind | $ | 12,898 |  |  | $ | 13,583 |  |  | $ | 18,573 |  |  | $ | 31,747 |  |
| Grid | 5,609 |  |  | 5,421 |  |  | 13,279 |  |  | 10,980 |  |
| Total | $ | 18,507 |  |  | $ | 19,004 |  |  | $ | 31,852 |  |  | $ | 42,727 |  |

[0001628280-16-020601:mdna:25]
Our Wind business unit accounted for 70% and 58% of total revenues for the three and six months ended September 30, 2016, respectively, compared to 71% and 74% for the three and six months ended September 30, 2015, respectively.  Revenues in the Wind business unit decreased 5% and 41% to $12.9 million and $18.6 million in the three and six months ended September 30, 2016, respectively, from $13.6 million and $31.7 million in the three and six months ended September 30, 2015, respectively. Wind business unit revenues in the three months ended September 30, 2016 compared to the three months ended September 30, 2015 decreased primarily due to lower license development and royalty revenue from Inox in India and lower spare part sales in China.  Wind business unit revenues in the six months ended September 30, 2016 as compared to the six months ended September 30, 2015 decreased primarily due to a lower volume of sales to Inox in India in the first quarter of fiscal 2016, lower royalty revenues, and lower sales of spare parts.

[0001628280-16-020601:mdna:26]
Our Grid business unit accounted for 30% and 42% of total revenues for the three and six months ended September 30, 2016, respectively, compared to 29% and 26% for the three and six months ended September 30, 2015, respectively. Our Grid business unit revenues increased 3% and 21% to $5.6 million and $13.3 million in the three and six months ended September 30, 2016, respectively, from $5.4 million and $11.0 million in the three and six months ended September 30, 2015, respectively. Grid business unit revenues in the three months ended September 30, 2016 increased primarily due to revenue from the Joint Development Agreement with BASF.  Grid business unit revenues in the six months ended September 30, 2016 increased primarily due to  higher revenues from the Joint Development Agreement and higher revenues from a project with the U.S. Navy.

[0001628280-16-020601:mdna:27]
Revenues from Project HYDRA and Project REG represented 13% of our Grid business unit’s revenue for each of the three and six months ended September 30, 2016 and 6% and 9% for the three and six months ended September 30, 2015, respectively. Our revenues for these projects are derived by funding from the Department of Homeland Security (“DHS”).  Project HYDRA is a project with Consolidated Edison, Inc. (“ConEd”) to demonstrate our REG product in ConEd’s electric grid.  Project REG is a project with Commonwealth Edison, Inc. (“ComEd”) to permanently install our REG product in ComEd’s electric grid.  This fault current limiting cable system is designed to utilize customized Amperium® HTS wire, and ancillary controls to deliver more power through the grid while also being able to suppress power surges that can disrupt service. DHS has committed 100% of the total expected funding of $29.0 million for Project HYDRA.  Under Project REG, DHS is expected to invest up to $60.0 million to enable the deployment of the REG system in Chicago’s electric grid.  We have substantially completed the first phase of the project which among other things, has resulted in the creation of a detailed deployment plan.  In the fiscal year ended March 31, 2015, DHS committed funding of $1.5 million for this phase of the project.  During the fiscal year ended March 31, 2016, DHS committed funding of an additional $3.7 million, for a total of $5.2 million.  This additional funding serves as a bridge between the detailed deployment plan and construction phases of the project.  The period of performance to complete the engineering work extends through May 31, 2017.  The final phase of the project involves the delivery of the REG system and the associated construction and deployment of the system in ComEd’s grid.  We will not begin this phase of the project until all parties agree to proceed.  There can be no assurance that all parties will agree to proceed with the project.

[0001628280-16-020601:mdna:28]
The following table sets forth customers who represented 10% or more of our total revenues for the three and six months ended September 30, 2016 and 2015:

[0001628280-16-020601:mdna:29]
|  | Three months ended September 30, |  | Six months ended September 30, |
|  | 2016 |  | 2015 |  | 2016 |  | 2015 |
| INOX Wind Limited | 68 | % |  | 66 | % |  | 51 | % |  | 55 | % |
| Beijing JINGCHENG New Energy Co., Ltd | — | % |  | <10% |  |  | <10% |  |  | 15 | % |

[0001628280-16-020601:mdna:30]
[same as prior period, unchanged from 0001628280-16-018764:mdna:30]

[0001628280-16-020601:mdna:31]
Cost of revenues increased by 3% and decreased by 21% to $16.4 million and $28.9 million for the three and six months ended September 30, 2016, respectively, compared to $16.0 million and $36.5 million for the three and six months ended September 30, 2015, respectively. Gross margin was 11.4% and 9.3% for the three and six months ended September 30, 2016, respectively, compared to 15.8% and 14.6% for the three and six months ended September 30, 2015, respectively. The decreases in gross margin were primarily due to lower Wind revenues, particularly in the three months ended June 30, 2016, as well as lower royalty revenue in the three and six months ended September 30, 2016, which is reflected as 100% gross margin.

[0001628280-16-020601:mdna:32]
[same as prior period, unchanged from 0001628280-16-018764:mdna:32]

[0001628280-16-020601:mdna:33]
[same as prior period, unchanged from 0001628280-16-018764:mdna:33]

[0001628280-16-020601:mdna:34]
R&D expenses decreased by 5% and 6% to $2.9 million and $5.8 million for the three and six months ended September 30, 2016, respectively, from $3.0 million and $6.2 million for the three and six months ended September 30, 2015, respectively.  The decrease in the three months ended September 30, 2016 compared to the three months ended September 30, 2015 is primarily due to lower supplies and materials consumed in the current-year period on internal development projects.  The decrease in the six months ended September 30, 2016 compared to the six months ended September 30, 2015 is primarily the result of lower stock compensation expense, partially offset by new product development expenses in our Grid segment in the first quarter of fiscal 2016.

[0001628280-16-020601:mdna:35]
[same as prior period, unchanged from 0001628280-16-018764:mdna:35]

[0001628280-16-020601:mdna:36]
SG&A expenses decreased by 6% and 5% to $6.3 million and $13.6 million in the three and six months ended September 30, 2016, respectively, from $6.8 million and $14.3 million in the three and six months ended September 30, 2015, respectively. The decrease in SG&A expenses in the three months ended September 30, 2016 was due primarily to cost reductions in China and lower software license fees.  The decreased SG&A expense in the six months ended September 30, 2016 compared to the six months ended September 30, 2015 was due to lower compensation expense and legal costs.

[0001628280-16-020601:mdna:37]
[same as prior period, unchanged from 0001628280-16-018764:mdna:37]

[0001628280-16-020601:mdna:38]
We recorded an impairment charge of $0.7 million in the six months ended September 30, 2015, to fully impair our investment in Tres Amigas as our investment was no longer deemed recoverable.

[0001628280-16-020601:mdna:39]
[same as prior period, unchanged from 0001628280-16-018764:mdna:39]

[0001628280-16-020601:mdna:40]
We recorded amortization expense related to our core technology and know-how, trade names and trademark intangible assets of less than $0.1 million in each of the three and six months ended September 30, 2016 and 2015.

[0001628280-16-020601:mdna:41]
[same as prior period, unchanged from 0001628280-16-018764:mdna:41]

[0001628280-16-020601:mdna:42]
[same as prior period, unchanged from 0001628280-16-018764:mdna:42]

[0001628280-16-020601:mdna:43]
|  | Three months ended September 30, |  | Six months ended September 30, |
|  | 2016 |  | 2015 |  | 2016 |  | 2015 |
| Operating (loss) profit: |  |  |  |  |  |  |  |
| Wind | $ | (1,235 | ) |  | $ | (1,991 | ) |  | $ | (4,264 | ) |  | $ | (1,864 | ) |
| Grid | (5,262 | ) |  | (4,113 | ) |  | (10,577 | ) |  | (10,621 | ) |
| Unallocated corporate expenses | (653 | ) |  | (737 | ) |  | (1,653 | ) |  | (2,613 | ) |
| Total | $ | (7,150 | ) |  | $ | (6,841 | ) |  | $ | (16,494 | ) |  | $ | (15,098 | ) |

[0001628280-16-020601:mdna:44]
Our Wind segment generated operating losses of $1.2 million and $4.3 million in the three and six months ended September 30, 2016, respectively, compared to $2.0 million and $1.9 million in the three and six months ended September 30, 2015, respectively. The decrease in the Wind business unit operating loss in the three months ended September 30, 2016 as compared to the three months ended September 30, 2015 was due primarily to costs arising from the transitioning of manufacturing from China to Romania in the prior fiscal year. The increase in Wind business unit operating loss in the six months ended September 30, 2016 as compared to the six months ended September 30, 2015 was due primarily to lower revenues as previously discussed.

[0001628280-16-020601:mdna:45]
The operating loss in our Grid segment increased to $5.3 million in the three months ended September 30, 2016 from $4.1 million in the three months ended September 30, 2015, due primarily to lower gross margin.  Operating loss was $10.6 million in each of the six months ended September 30, 2016 and 2015, respectively, as higher revenue and gross margin, was offset by higher engineering and sales and marketing expenses.

[0001628280-16-020601:mdna:46]
Unallocated corporate expenses primarily include stock-based compensation expense of $0.7 million and $1.7 million for the three and six months ended September 30, 2016, respectively, and  $0.7 million and $1.8 million for the three and six months ended September 30, 2015, respectively, and an impairment charge of $0.7 million, for the six months ended September 30, 2015.

[0001628280-16-020601:mdna:47]
[same as prior period, unchanged from 0001628280-16-018764:mdna:48]

[0001628280-16-020601:mdna:48]
The change in fair value of derivatives and warrants resulted in gains of $1.2 million and $0.6 million in the three and six months ended September 30, 2016, respectively, compared to gains of $0.7 million and $1.5 million in the three and six months ended September 30, 2015, respectively.  The changes in the fair value were primarily driven by changes in stock price, which is a key valuation metric.

[0001628280-16-020601:mdna:49]
[same as prior period, unchanged from 0001628280-16-018764:mdna:50]

[0001628280-16-020601:mdna:50]
Interest expense, net, was $0.1 million and $0.2 million in the three and six months ended September 30, 2016, respectively, compared to $0.3 million and $0.6 million in the three and six months ended September 30, 2015, respectively. The interest expense is related to the remaining balances on our Term Loan B and Term Loan C with Hercules Technology Growth Capital, Inc. ("Hercules") which will mature in November 2016 and June 2017, respectively.

[0001628280-16-020601:mdna:51]
Other expense, net

[0001628280-16-020601:mdna:52]
Other expense, net, was $0.5 million and $0.4 million in the three and six months ended September 30, 2016, respectively, compared to $0.4 million and $1.2 million in the three and six months ended September 30, 2015, respectively.  The increase in other expense, net during the three months ended September 30, 2016, was primarily driven by higher foreign currency losses.  The decrease in other expense, net during the six months ended September 30, 2016 was primarily the result of lower charges for minority interest in the current year period following the impairment of our minority interest in Tres Amigas in the prior year period.

[0001628280-16-020601:mdna:53]
[same as prior period, unchanged from 0001628280-16-018764:mdna:54]

[0001628280-16-020601:mdna:54]
Income tax expense was $0.8 million and $1.1 million in the three and six months ended September 30, 2016, respectively, compared to $0.9 million and $1.5 million in the three and six months ended September 30, 2015, respectively. The decreases in income tax expense during the three and six months ended September 30, 2016 were primarily due to lower taxes in our foreign jurisdictions.

[0001628280-16-020601:mdna:55]
[same as prior period, unchanged from 0001628280-16-018764:mdna:56]

[0001628280-16-020601:mdna:56]
[same as prior period, unchanged from 0001628280-16-018764:mdna:57]

[0001628280-16-020601:mdna:57]
We define non-GAAP net loss as net loss before stock-based compensation, amortization of acquisition-related intangibles, restructuring and impairment charges, consumption of zero cost-basis inventory, changes in fair value of derivatives and warrants, non-cash interest expense, and the other non-cash or unusual charges, net of any tax effects related to these items, indicated in the table below. We believe non-GAAP net loss assists management and investors in comparing our performance across reporting periods on a consistent basis by excluding these non-cash or non-recurring charges that we do not believe are indicative of our core operating performance. In addition, we use non-GAAP net loss as a factor in evaluating management’s performance when determining incentive compensation and to evaluate the effectiveness of our business strategies. A reconciliation of GAAP net loss to non-GAAP net loss is set forth in the table below (in thousands, except per share data):

[0001628280-16-020601:mdna:58]
|  | Three months ended September 30, |  | Six months ended September 30, |
|  | 2016 |  | 2015 |  | 2016 |  | 2015 |
| Net loss | $ | (7,325 | ) |  | $ | (7,698 | ) |  | $ | (17,680 | ) |  | $ | (16,819 | ) |
| Stock-based compensation | 653 |  |  | 706 |  |  | 1,653 |  |  | 1,834 |  |
| Amortization of acquisition-related intangibles | 39 |  |  | 39 |  |  | 78 |  |  | 78 |  |
| Restructuring and impairment charges | — |  |  | 38 |  |  | — |  |  | 779 |  |
| Consumption of zero cost-basis inventory | (482 | ) |  | (1,223 | ) |  | (640 | ) |  | (2,069 | ) |
| Change in fair value of derivatives and warrants | (1,244 | ) |  | (701 | ) |  | (567 | ) |  | (1,501 | ) |
| Non-cash interest expense | 42 |  |  | 96 |  |  | 98 |  |  | 207 |  |
| Tax effect of adjustments | 77 |  |  | — |  |  | 102 |  |  | — |  |
| Non-GAAP net loss | $ | (8,240 | ) |  | $ | (8,743 | ) |  | $ | (16,956 | ) |  | $ | (17,491 | ) |
| Non-GAAP net loss per share | $ | (0.60 | ) |  | $ | (0.64 | ) |  | $ | (1.24 | ) |  | $ | (1.37 | ) |
| Weighted average shares outstanding - basic and diluted | 13,769 |  |  | 13,595 |  |  | 13,723 |  |  | 12,808 |  |

[0001628280-16-020601:mdna:59]
We incurred non-GAAP net losses of $8.2 million or $0.60 per share, and $17.0 million or $1.24 per share, for the three and six months ended September 30, 2016, respectively, compared to non-GAAP net losses of $8.7 million or $0.64 per share, and $17.5 million or $1.37 per share, for the three and six months ended September 30, 2015, respectively. The decrease in non-GAAP net loss in the three month period ended September 30, 2016  compared to the three month period ended September 30, 2015 was driven primarily by a decrease in net loss and by lower consumption of zero-cost basis inventory.  The decrease in non-GAAP net loss in the six months ended September 30, 2016 compared to the six month period ended September 30, 2015 was driven primarily by lower addbacks to net loss from the change in the fair value of derivatives and by lower consumption of zero cost-basis inventory.

[0001628280-16-020601:mdna:60]
[same as prior period, unchanged from 0001628280-16-018764:mdna:61]

[0001628280-16-020601:mdna:61]
At September 30, 2016, we had cash, cash equivalents, and restricted cash of $26.6 million, compared to $40.7 million at March 31, 2016, a decrease of $14.1 million. Our cash and cash equivalents, and restricted cash are summarized as follows (in thousands):

[0001628280-16-020601:mdna:62]
|  | September 30, 2016 |  | March 31,2016 |
| Cash and cash equivalents | $ | 25,262 |  |  | $ | 39,330 |  |
| Restricted cash | 1,386 |  |  | 1,391 |  |
| Total cash, cash equivalents, and restricted cash | $ | 26,648 |  |  | $ | 40,721 |  |

[0001628280-16-020601:mdna:63]
As of September 30, 2016, we had approximately $4.4 million of cash, cash equivalents, and restricted cash in foreign bank accounts, with a majority of this cash located in Europe.  The decrease in total cash and cash equivalents, and restricted cash was due primarily to cash used by operating and by financing activities. See further discussion below.

[0001628280-16-020601:mdna:64]
For the six months ended September 30, 2016, net cash used in operating activities was $10.9 million compared to $7.8 million for the six months ended September 30, 2015. The increase in net cash used in operations was due primarily to an increased net loss as well as a use of cash for changes in operating asset and liability accounts, particularly in the three months ended September 30, 2016, due to a gap in revenues and collections from Inox due to their stated working capital constraints, as well as payments for inventory purchased prior to curtailing our supply chain for electrical control systems, which has negatively impacted

[0001628280-16-020601:mdna:65]
[same as prior period, unchanged from 0001628280-16-018764:mdna:71]

[0001628280-16-020601:mdna:66]
revenues and cash flows during the first half of fiscal 2016.  During the second quarter of fiscal 2016, shipments to Inox began to return to a more normal level.

[0001628280-16-020601:mdna:67]
For the six months ended September 30, 2016, net cash used in investing activities was $0.4 million, compared to $0.2 million for the six months ended September 30, 2015. The increase in net cash used in investing activities was due primarily to a use of cash for a change in other assets, compared to a source of cash in the six months ended September 30, 2015.

[0001628280-16-020601:mdna:68]
For the six months ended September 30, 2016, net cash used in financing activities was $2.5 million compared to net cash provided by financing activities of $20.2 million in the six months ended September 30, 2015. The increase in net cash used in financing activities was primarily due to net proceeds of $22.3 million from the issuance of 4.0 million shares of common stock on April 29, 2015, with no such capital raise in the current year period.

[0001628280-16-020601:mdna:69]
At September 30, 2016, we had $0.5 million of restricted cash included in current assets and $0.9 million of restricted cash included in long-term assets. These amounts included in restricted cash primarily represent deposits to secure letters of credit for various supply contracts and customs authorities. These deposits are held in interest bearing accounts.

[0001628280-16-020601:mdna:70]
On November 15, 2013, we amended our Loan and Security Agreement with Hercules and entered into a new term loan (the “Term Loan B”), borrowing $10.0 million. After closing fees and expenses, we received net proceeds of $9.8 million. The Term Loan B bears an interest rate equal to 11% plus the percentage, if any, in which the prime rate as reported by The Wall Street Journal exceeds 3.75%. We made interest-only payments from December 1, 2013 to May 31, 2014. If we achieved certain revenue targets for the six-month period ending March 31, 2014, interest only payments would continue through August 31, 2014. We did not achieve the revenue required to extend this interest only period.  Beginning June 1, 2014, we began making payments on the Term Loan B in equal monthly installments which ended on November 1, 2016.

[0001628280-16-020601:mdna:71]
[same as prior period, unchanged from 0001628280-16-018764:mdna:70]

[0001628280-16-020601:mdna:72]
The Term Loans are secured by substantially all of our existing and future assets, including a mortgage on real property owned by our wholly-owned subsidiary, ASC Devens LLC, and located at 64 Jackson Road, Devens, Massachusetts.  The Term Loans contain certain covenants that restrict our ability to, among other things, incur or assume certain debt, merge or consolidate, materially change the nature of our business, acquire or dispose of certain assets, make guarantees or grant liens on our assets, make certain loans, advances or investments, declare dividends or make distributions or enter into transactions with affiliates. In addition, there is a covenant that requires us to maintain a minimum unrestricted cash balance (the “Minimum Threshold”) in the United States.  As a result of the April 2015 offering (see discussion below), the Minimum Threshold was reduced to the lesser of $2.0 million or the aggregate outstanding principal balance of the Term Loans.  As of September 30, 2016, the Minimum Threshold was $2.0 million.  The events of default under the Term Loans include, but are not limited to, failure to pay amounts due, breaches of covenants, bankruptcy events, cross defaults under other material indebtedness and the occurrence of a material adverse effect and/or change in control. In the case of a continuing event of default, Hercules may, among other remedies, declare due all unpaid principal amounts outstanding and any accrued but unpaid interest and foreclose on all collateral granted to Hercules as security under the Term Loans.

[0001628280-16-020601:mdna:73]
We believe we are in and expect to remain in compliance with the covenants and restrictions under the Term Loans as of the date of this Quarterly Report on Form 10-Q. If we fail to stay in compliance with our covenants or experience some other event of default, we may be forced to repay the outstanding principal on the Term Loans.

[0001628280-16-020601:mdna:74]
We have experienced recurring operating losses and as of September 30, 2016, had an accumulated deficit of $945.9 million. In addition, we have experienced recurring negative operating cash flows. At September 30, 2016, we had cash and cash equivalents of $25.3 million, as compared to cash used in operations of $10.9 million for the six months ended September 30, 2016.  We expect to use less cash for operations in the second half of fiscal 2016 compared to the first half.  In April 2015, we completed an equity offering which raised net proceeds of $22.3 million after deducting underwriting discounts, commissions and offering expenses payable by us from the sale of 4.0 million shares of our common stock at a public offering price of $6.00 per share. On March 11, 2016, we sold 100% of our minority investment in Tres Amigas to an investor for $0.6 million. We received $0.3 million according to the terms of the purchase agreement upon closing, which was recorded as a gain during the three months ended March 31, 2016.  The final $0.3 million is to be paid when Tres Amigas achieves the earlier of certain agreed-upon financing conditions which is expected to occur during the third quarter of fiscal 2016.  In addition, in December 2015, we entered into a set of strategic agreements

[0001628280-16-020601:mdna:75]
valued at approximately $210.0 million with Inox, as discussed above.  These agreements are expected to provide a foundation for the business as we pursue our longer-term objectives.

[0001628280-16-020601:mdna:76]
We believe we have sufficient available liquidity to fund our operations, capital expenditures and scheduled cash payments under our debt obligations for the next twelve months. Our liquidity is highly dependent on our ability to increase revenues, control our operating costs, and our ability to maintain compliance with the covenants and restrictions on our debt obligations (or obtain waivers from our lender in the event of non-compliance), and our ability to raise additional capital, if necessary.  There can be no assurance that we will be able to continue to raise additional capital from other sources or execute on any other means of improving our liquidity as described above.

[0001628280-16-020601:mdna:77]
Legal Proceedings

[0001628280-16-020601:mdna:78]
We are involved in legal and administrative proceedings and claims of various types. See Part II, Item 1, “Legal Proceedings,” for additional information. We record a liability in our consolidated financial statements for these matters when a loss is known or considered probable and the amount can be reasonably estimated. We review these estimates each accounting period as additional information is known and adjust the loss provision when appropriate. If a matter is both probable to result in liability and the amounts of loss can be reasonably estimated, we estimate and disclose the possible loss or range of loss to the extent necessary to make the consolidated financial statements not misleading. If the loss is not probable or cannot be reasonably estimated, a liability is not recorded in our consolidated financial statements.

[0001628280-16-020601:mdna:79]
[same as prior period, unchanged from 0001628280-16-018764:mdna:78]

[0001628280-16-020601:mdna:80]
[same as prior period, unchanged from 0001628280-16-018764:mdna:79]

[0001628280-16-020601:mdna:81]
[same as prior period, unchanged from 0001628280-16-018764:mdna:80]

[0001628280-16-020601:mdna:82]
[same as prior period, unchanged from 0001628280-16-018764:mdna:81]

[0001628280-16-020601:mdna:83]
[same as prior period, unchanged from 0001628280-16-018764:mdna:82]

[0001628280-16-020601:mdna:84]
In May 2014, the Financial Accounting Standards Board (“FASB”) and the International Accounting Standards Board (IASB) issued, ASU Revenue from Contracts with Customers 2014-09 (Topic 606). The guidance substantially converges final standards on revenue recognition between the FASB and IASB providing a framework on addressing revenue recognition issues and, upon its effective date, replaces almost all existing revenue recognition guidance, including industry-specific guidance, in current U.S. generally accepted accounting principles.  The ASU is effective for annual reporting periods beginning after December 15, 2017.  We are currently evaluating the impact the adoption of ASU 2014-09 may have on our current practices.

[0001628280-16-020601:mdna:85]
In July 2014, the FASB issued ASU 2014-12, Compensation - Stock Compensation (Topic 718): Accounting for Share Based Payments When the Terms of an Award Provide that a Performance Target Could be Achieved after the Requisite Service Period.  To account for such awards, a reporting entity should apply existing guidance in FASB Accounting Standards Codification Topic 718, Compensation - Stock Compensation, as it relates to awards with performance conditions that affect vesting.  As such, the performance target should not be reflected in estimating the grant-date fair value of the award. We adopted ASU 2014-12 effective April 1, 2016 and conclude that there is no material impact on our current practices.

[0001628280-16-020601:mdna:86]
In August 2014, the FASB issued ASU 2014-15, Presentation of Financial Statements - Going Concern (Subtopic 205-40): Disclosure of Uncertainties About an Entity’s Ability to Continue as a Going Concern.  The new standard explicitly requires the assessment at interim and annual periods, and provides management with its own disclosure guidance. This ASU is effective for annual reporting periods ending after December 15, 2016 and interim periods within annual periods beginning after December 15, 2016.  We are currently evaluating the impact, if any, the adoption of ASU 2014-15 may have on our current practices.

[0001628280-16-020601:mdna:87]
In April 2015, the FASB issued ASU 2015-03 Interest-Imputation of Interest (Subtopic 835-30): Simplifying the Presentation of Debt Issuance Costs.  The amendments in ASU 2015-03 require an entity to present debt issuance costs on the balance sheet as a direct deduction from the related debt liability as opposed to an asset. Amortization of the costs will continue to be reported as interest expense. We adopted ASU 2015-03 effective April 1, 2016 and conclude that there is no material impact on our consolidated results of operations, financial condition, or cash flow.

[0001628280-16-020601:mdna:88]
In June 2015, the FASB issued ASU 2015-10 Technical Corrections and Improvements.  The amendments in ASU 2015-10 clarify and correct some of the difference that arose between original guidance from FASB, EITF and other sources, and the translation into the new Codification. We adopted ASU 2015-10 effective April 1, 2016 and conclude that there is no material impact on our consolidated results of operations, financial condition, or cash flow.

[0001628280-16-020601:mdna:89]
In July 2015, the FASB issued ASU 2015-11 Inventory (Topic 330): Simplifying the Measurement of Inventory.  The amendments in ASU 2015-11 clarify the proper way to identify market value in the use of lower of cost or market value valuation method.  As market value could be determined multiple ways under prior standards, it will now be considered as net realizable value. This ASU is effective for annual reporting periods beginning after December 15, 2016, and interim periods within those fiscal years.  We are currently evaluating the impact, if any, the adoption of ASU 2015-11 may have on our current practices.

[0001628280-16-020601:mdna:90]
In September 2015, the FASB issued ASU 2015-16 Business Combinations (Topic 805): Simplifying the Accounting for Measurement-Period Adjustments.  The amendments in ASU 2015-16 require that an acquirer recognize adjustments to provisional amounts identified during the measurement period in the reporting period in which the adjustment amounts are determined. We adopted ASU 2015-16 effective April 1, 2016 and conclude that there is no material impact on our consolidated results of operations, financial condition, or cash flow.

[0001628280-16-020601:mdna:91]
In January 2016, the FASB issued ASU 2016-01 Financial Instruments-Overall (Subtopic 825-10): Recognition and Measurement of Financial Assets and Financial Liabilities.  The amendments in ASU 2016-01 will enhance the reporting model for financial instruments to provide users of financial statements with more decision-useful information. This ASU is effective for annual reporting periods beginning after December 15, 2017, and interim periods within those fiscal years.  We are currently evaluating the impact, if any, the adoption of ASU 2016-01 may have on our current practices.

[0001628280-16-020601:mdna:92]
In February 2016, the FASB issued ASU 2016-02, Leases (Topic 842). The guidance in this ASU supersedes the leasing guidance in Topic 840, Leases. Under the new guidance, lessees are required to recognize lease assets and lease liabilities on the balance sheet for all leases with terms longer than 12 months. Leases will be classified as either finance or operating, with classification affecting the pattern of expense recognition in the income statement. This ASU is effective for fiscal years beginning after December 15, 2018, including interim periods within those fiscal years. A modified retrospective transition approach is required for lessees for capital and operating leases existing at, or entered into after, the beginning of the earliest comparative period presented in the financial statements, with certain practical expedients available. We are currently evaluating the effects adoption of this guidance will have on our consolidated financial statements.

[0001628280-16-020601:mdna:93]
In March 2016, the FASB issued ASU 2016-08 Revenue from Contracts with Customers (Topic 606): Principal versus Agent Considerations (Reporting Revenue Gross versus Net).  The amendments in ASU 2016-08 clarify the implementation guidance on principal versus agent consideration. The ASU is effective for annual reporting periods beginning after December 15, 2017.  We are currently evaluating the impact, if any, the adoption of ASU 2016-08 may have on our current practices.

[0001628280-16-020601:mdna:94]
In March 2016, the FASB issued ASU 2016-09 Compensation-Stock Compensation (Topic 718): Improvements to Employee Share-Based Payment Accounting.  The amendments in ASU 2016-09 will simplify several aspects of the accounting for share-based payment transactions, including tax consequences, classification of awards as either equity or liabilities, and classification on the statement of cash flows. The ASU is effective for annual reporting periods beginning after December 15, 2016, and interim periods within those annual periods.  We are currently evaluating the impact, if any, the adoption of ASU 2016-09 may have on our current practices.

[0001628280-16-020601:mdna:95]
In April 2016, the FASB issued ASU 2016-10 Revenue from Contracts with Customers (Topic 606): Identifying Performance Obligations and Licensing.  The amendments in ASU 2016-10 will clarify the identification of performance obligations and the licensing implementation guidance. The ASU is effective for annual reporting periods beginning after December 15, 2017.  We are currently evaluating the impact, if any, the adoption of ASU 2016-10 may have on our current practices.

[0001628280-16-020601:mdna:96]
In April 2016, the FASB issued ASU 2016-12 Revenue from Contracts with Customers (Topic 606): Narrow-Scope Improvements and Practical Expedients.  The amendments in ASU 2016-12 will clarify the prior guidance surrounding collectability criteria, presentation of taxes collected, non-cash consideration, contract modifications, completed contracts at completion and retrospective application guidance. The ASU is effective for annual reporting periods beginning after December 15, 2017.  We are currently evaluating the impact the adoption of ASU 2016-12 may have on our current practices.

[0001628280-16-020601:mdna:97]
In June 2016, the FASB issued ASU 2016-13 Financial Instruments—Credit Losses (Topic 326): Measurement of Credit Losses on Financial Instruments.  The amendments in ASU 2016-13 will provide more decision useful information about the expected credit losses on financial instruments and other commitments to extend credit held by a reporting entity at each reporting date. The ASU is effective for annual reporting periods beginning after December 15, 2019, including interim periods within that year.  We are currently evaluating the impact, if any, the adoption of ASU 2016-13 may have on our current practices.

[0001628280-16-020601:mdna:98]
In August 2016, the FASB issued ASU 2016-15 Statement of Cash Flows (Topic 230): Classification of Certain Cash Receipts and Cash Payments.  The amendments in ASU 2016-15 will provide more guidance towards the classification of multiple different types of cash flows in order to reduce the diversity in reporting across entities. The ASU is effective for annual reporting periods beginning after December 15, 2017, including interim periods within that year.  We are currently evaluating the impact, if any, the adoption of ASU 2016-15 may have on our current practices.

[0001628280-16-020601:mdna:99]
We do not believe that other recently issued accounting pronouncements will have a material impact on our financial statements.
