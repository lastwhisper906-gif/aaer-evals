# AMSC 8-K — 0001628280-16-020598 filed 2016-11-02

## item codes, every 8-K on or before 2016-11-02

- 2016-11-02 0001628280-16-020598 — 2.02, 9.01
- 2016-09-16 0001193125-16-712301 — 5.02
- 2016-08-23 0001193125-16-688767 — 8.01
- 2016-08-09 0001628280-16-018763 — 2.02, 9.01
- 2016-08-02 0001193125-16-668417 — 5.02, 5.07, 9.01
- 2016-05-31 0001564590-16-020114 — 2.02, 9.01
- 2016-05-18 0001193125-16-594515 — 5.02
- 2016-03-08 0001193125-16-496113 — 1.01
- 2016-02-09 0001193125-16-454775 — 2.02, 9.01
- 2015-12-17 0001193125-15-405566 — 1.01
- 2015-11-03 0001193125-15-363413 — 2.02, 9.01
- 2015-08-31 0001193125-15-307558 — 1.01
- 2015-08-05 0001193125-15-277824 — 2.02, 9.01
- 2015-07-31 0001193125-15-273009 — 5.07
- 2015-06-26 0001193125-15-237190 — 5.02
- 2015-06-09 0001193125-15-218028 — 8.01
- 2015-05-28 0001193125-15-202933 — 2.02, 9.01
- 2015-04-28 0001193125-15-153319 — 8.01, 9.01
- 2015-04-23 0001193125-15-144123 — 2.02, 8.01, 9.01
- 2015-04-23 0001193125-15-143608 — 8.01
- 2015-04-10 0001193125-15-126160 — 8.01
- 2015-03-24 0001193125-15-103436 — 5.03, 9.01
- 2015-03-18 0001193125-15-097034 — 5.07
- 2015-02-05 0001193125-15-034499 — 2.02, 9.01
- 2015-01-29 0001193125-15-024629 — 2.02, 9.01
- 2015-01-21 0001193125-15-016287 — 3.01, 8.01
- 2015-01-06 0001193125-15-002902 — 5.02
- 2014-12-22 0001193125-14-450591 — 1.01, 2.03, 3.02, 9.01
- 2014-11-13 0001193125-14-410207 — 1.01, 9.01
- 2014-11-07 0001193125-14-402383 — 1.02, 7.01, 9.01
- 2014-11-06 0001193125-14-399779 — 2.02, 9.01
- 2014-10-01 0001193125-14-360072 — 2.02, 8.01, 9.01
- 2014-09-04 0001193125-14-331411 — 8.01
- 2014-08-21 0001193125-14-317133 — 1.01
- 2014-08-06 0001193125-14-298306 — 5.02, 5.07, 9.01
- 2014-08-05 0001193125-14-294647 — 2.02, 9.01
- 2014-07-16 0001193125-14-269902 — 8.01
- 2014-06-23 0001193125-14-244592 — 3.02, 8.01
- 2014-06-05 0001193125-14-226459 — 2.02, 9.01
- 2014-06-05 0001193125-14-226457 — 1.01, 9.01
- 2014-03-19 0001193125-14-106558 — 2.05
- 2014-03-03 0001193125-14-078917 — 1.01, 3.02, 9.01
- 2014-02-28 0001193125-14-077480 — 8.01, 9.01
- 2014-02-06 0001193125-14-037960 — 2.02, 8.01, 9.01
- 2013-11-20 0001193125-13-447829 — 3.02, 8.01
- 2013-11-18 0001193125-13-444697 — 1.01, 2.03, 3.02, 9.01
- 2013-11-07 0001193125-13-431705 — 2.02, 9.01
- 2013-10-09 0001193125-13-395362 — 1.01, 2.03, 3.02, 9.01
- 2013-09-25 0001193125-13-378481 — 5.02, 9.01
- 2013-08-21 0001193125-13-341566 — 4.01, 9.01
- 2013-08-07 0001193125-13-323082 — 2.02, 9.01
- 2013-08-02 0001193125-13-317278 — 5.02, 5.07
- 2013-06-14 0001193125-13-258758 — 2.02, 9.01
- 2013-04-01 0001193125-13-136714 — 2.02, 8.01, 9.01
- 2013-02-20 0001193125-13-067218 — 5.02, 9.01
- 2013-02-14 0001193125-13-060131 — 1.01, 9.01
- 2013-02-11 0001193125-13-048784 — 2.02, 9.01
- 2013-01-08 0001193125-13-006861 — 5.02, 9.01
- 2012-12-21 0001193125-12-511592 — 1.01, 2.03, 3.02, 9.01
- 2012-11-28 0001193125-12-483317 — 2.05, 5.02, 7.01, 9.01
- 2012-11-06 0001193125-12-453359 — 2.02, 9.01
- 2012-08-02 0001193125-12-330534 — 2.02, 9.01
- 2012-07-27 0001193125-12-318790 — 5.02, 5.07, 9.01
- 2012-06-06 0001193125-12-261030 — 1.01, 2.02, 2.03, 3.02, 5.02, 9.01
- 2012-05-09 0001193125-12-222210 — 5.02
- 2012-04-20 0001193125-12-172045 — 8.01
- 2012-04-13 0001193125-12-162694 — 2.02, 8.01, 9.01
- 2012-04-04 0001193125-12-149102 — 1.01, 2.02, 2.03, 3.02, 9.01
- 2012-02-09 0001193125-12-048009 — 2.02, 9.01
- 2012-02-06 0001193125-12-041344 — 5.07 — amendment of 0000950123-11-102495
- 2011-12-08 0000950123-11-102495 — 5.07
- 2011-11-29 0000950123-11-100822 — 2.05
- 2011-11-09 0000950123-11-096775 — 2.02, 9.01
- 2011-10-31 0000950123-11-093390 — 1.02, 9.01
- 2011-10-07 0000950123-11-089221 — 8.01
- 2011-10-03 0000950123-11-088315 — 7.01
- 2011-09-23 0000950123-11-086288 — 2.02, 9.01
- 2011-09-15 0000950123-11-084585 — 7.01
- 2011-09-06 0000950123-11-082736 — 7.01
- 2011-08-18 0000950123-11-078526 — 3.01, 7.01, 9.01
- 2011-08-11 0000950123-11-075905 — 5.02
- 2011-08-11 0000950123-11-075904 — 2.02, 2.05, 9.01
- 2011-07-11 0000950123-11-064934 — 2.02, 4.02, 9.01
- 2011-06-30 0000950123-11-063287 — 1.01, 3.02, 9.01
- 2011-06-21 0000950123-11-060491 — 3.01, 7.01, 9.01
- 2011-06-13 0000950123-11-058656 — 1.01, 9.01
- 2011-05-24 0000950123-11-053517 — 5.02, 9.01
- 2011-04-05 0001299933-11-001020 — 2.02, 9.01
- 2011-03-15 0000950123-11-025580 — 5.02
- 2011-03-14 0000950123-11-025205 — 1.01, 3.02, 9.01
- 2011-02-01 0001299933-11-000333 — 2.02, 9.01
- 2010-11-12 0000950123-10-104604 — 8.01, 9.01
- 2010-11-08 0000950123-10-102424 — 8.01, 9.01
- 2010-11-02 0001299933-10-003878 — 2.02, 9.01
- 2010-09-15 0000950123-10-086373 — 1.01, 9.01 — amendment, the index does not say of what
- 2010-08-06 0000950123-10-074362 — 5.07
- 2010-07-29 0001299933-10-002860 — 2.02, 9.01
- 2010-05-17 0000950123-10-050424 — 1.01, 9.01
- 2010-05-14 0001299933-10-001972 — 5.02
- 2010-05-13 0001299933-10-001943 — 2.02, 9.01
- 2010-02-08 0001299933-10-000506 — 8.01
- 2010-02-02 0001299933-10-000386 — 2.02, 9.01
- 2009-12-15 0001299933-09-004928 — 5.02
- 2009-10-29 0001299933-09-004267 — 2.02, 9.01
- 2009-08-12 0001193125-09-173026 — 5.02, 9.01
- 2009-07-30 0001193125-09-158842 — 1.01, 2.02, 9.01
- 2009-05-15 0001193125-09-113158 — 5.02
- 2009-05-14 0001193125-09-110619 — 2.02, 9.01
- 2009-04-20 0001193125-09-082590 — 5.02
- 2009-02-03 0001193125-09-016992 — 2.02, 9.01
- 2009-01-22 0001193125-09-009777 — 2.02, 9.01
- 2008-11-04 0001193125-08-223730 — 2.02, 9.01
- 2008-08-11 0001193125-08-173616 — 8.01
- 2008-08-07 0001193125-08-170325 — 8.01
- 2008-08-05 0001193125-08-165888 — 2.02, 9.01
- 2008-06-11 0001193125-08-132049 — 1.01, 9.01
- 2008-05-20 0001193125-08-119372 — 5.02, 9.01
- 2008-05-08 0001193125-08-107052 — 2.02, 9.01
- 2008-01-31 0001193125-08-016233 — 2.02, 9.01
- 2008-01-30 0001193125-08-015494 — 5.03, 9.01
- 2007-11-01 0001193125-07-231866 — 2.02, 9.01
- 2007-10-31 0001193125-07-231225 — 2.05
- 2007-10-29 0001193125-07-228284 — 5.03, 9.01
- 2007-09-27 0001193125-07-208950 — 5.02
- 2007-08-09 0001193125-07-176553 — 2.02, 9.01
- 2007-08-07 0001193125-07-173829 — 1.01, 5.02, 9.01
- 2007-07-02 0001193125-07-148303 — 5.02, 9.01
- 2007-06-20 0001193125-07-139068 — 8.01, 9.01
- 2007-06-14 0001193125-07-135550 — 9.01 — amendment of 0001193125-07-005297
- 2007-06-14 0001193125-07-135340 — 5.02
- 2007-05-24 0001193125-07-122148 — 2.02, 9.01
- 2007-03-30 0001193125-07-070154 — 2.05, 9.01
- 2007-03-23 0001193125-07-062978 — 9.01 — amendment of 0001193125-07-005297
- 2007-02-01 0001193125-07-017883 — 2.02, 9.01
- 2007-01-11 0001193125-07-005297 — 2.01, 9.01
- 2006-12-05 0001181431-06-067500 — 5.02
- 2006-11-29 0001193125-06-243360 — 1.01, 3.02, 9.01
- 2006-11-02 0001193125-06-221464 — 2.02, 9.01
- 2006-09-21 0001193125-06-194526 — 5.02
- 2006-08-08 0001193125-06-164819 — 2.02, 9.01
- 2006-08-02 0001193125-06-159113 — 1.01, 9.01
- 2006-07-28 0001193125-06-156172 — 1.01
- 2006-06-26 0001193125-06-135913 — 1.01, 3.03, 9.01
- 2006-05-11 0001193125-06-108489 — 2.02, 9.01
- 2006-05-05 0001193125-06-102270 — 1.01, 9.01
- 2006-05-01 0001193125-06-094941 — 2.02, 2.06, 9.01
- 2006-02-24 0001193125-06-038281 — 5.02, 9.01
- 2006-02-02 0001181431-06-007665 — 2.02, 9.01
- 2005-11-09 0001181431-05-060304 — 2.02, 9.01
- 2005-08-04 0001181431-05-044420 — 2.02, 9.01
- 2005-07-28 0001193125-05-151272 — 5.02, 9.01
- 2005-06-14 0001193125-05-125148 — 5.02, 9.01
- 2005-05-12 0001181431-05-027410 — 2.02, 9.01
- 2005-05-10 0001193125-05-102795 — 1.01
- 2005-04-05 0001181431-05-020680 — 1.01, 2.02, 3.02, 9.01
- 2005-02-03 0001181431-05-006678 — 2.02, 9.01
- 2004-11-09 0001181431-04-051381 — 2.02, 9.01 — amendment, the index does not say of what
- 2004-11-04 0001181431-04-050706 — 2.02, 9.01
- 2004-10-15 0001193125-04-172458 — 1.01, 9.01
- 2004-08-05 0001193125-04-132162 — 12
- 2004-05-13 0001193125-04-086853 — 12
- 2004-02-05 0001193125-04-015060 — 12
- 2003-11-06 0001193125-03-074000 — 12
- 2003-09-26 0001193125-03-054624 — 5
- 2003-08-06 0001193125-03-029666 — 12
- 2003-05-14 0000927016-03-002619 — 9
- 2002-12-31 0000927016-02-006114 — 5
- 2000-01-24 0000927016-00-000150 — 5, 7
- 1998-11-02 0000950135-98-005625 — 5, 7
- 1998-03-24 0000950135-98-001743 — 5, 7
- 1997-09-05 0000950135-97-003729 — 5, 7
- 1997-06-23 0000950135-97-002785 — 1 — amendment of 0000950135-97-001972
- 1997-04-23 0000950135-97-001972 — 2, 7

## late-filing notifications on or before 2016-11-02

- 2011-08-10 0000950123-11-075677 — NT 10-Q, for the period ended 2011-06-30
- 2011-05-31 0000950123-11-055465 — NT 10-K, for the period ended 2011-03-31

## item 2.02 — earnings release, exhibit 99.1

[0001628280-16-020598:8k_2_02:1]
EX-99.1
2
amsc20160930ex991.htm
EXHIBIT 99.1

[0001628280-16-020598:8k_2_02:2]
Exhibit

[0001628280-16-020598:8k_2_02:3]
AMSC Reports Second Quarter Fiscal 2016 Financial Results and Provides Business Outlook

[0001628280-16-020598:8k_2_02:4]
Company to host conference call today at 10:00 am ET

[0001628280-16-020598:8k_2_02:5]
Devens, MA – November 2, 2016 – AMSC (NASDAQ: AMSC), a global solutions provider serving wind and power grid industry leaders, today reported financial results for its second quarter of fiscal 2016 ended September 30, 2016.

[0001628280-16-020598:8k_2_02:6]
Revenues for the second quarter of fiscal 2016 were $18.5 million, compared with $19.0 million for the same period of fiscal 2015. The year-over-year decrease in revenues was due to modestly lower Wind segment revenues during the second quarter of fiscal 2016.

[0001628280-16-020598:8k_2_02:7]
AMSC’s net loss for the second quarter of fiscal 2016 decreased to $7.3 million, or $0.53 per share, from $7.7 million, or $0.57 per share, for the same period of fiscal 2015. The Company’s non-GAAP net loss for the second quarter of fiscal 2016 was $8.2 million, or $0.60 per share, which was improved compared with a non-GAAP net loss of $8.7 million, or $0.64 per share, in the same period of fiscal 2015. Please refer to the financial table below for a reconciliation of GAAP to non-GAAP results.

[0001628280-16-020598:8k_2_02:8]
Cash, cash equivalents and restricted cash at September 30, 2016 totaled $26.6 million, compared with $36.6 million at June 30, 2016.

[0001628280-16-020598:8k_2_02:9]
“Revenues in our Wind segment returned to a more normal run-rate in the second quarter, while our Grid revenues continued to achieve year-over-year growth,” said Daniel P. McGahn, President and CEO, AMSC. “While the first half of the fiscal year was challenging, we expect a stronger second half of the fiscal year, with growing revenues and minimal cash burn.”

[0001628280-16-020598:8k_2_02:10]
Business Outlook

[0001628280-16-020598:8k_2_02:11]
“We anticipate higher Wind revenues and that our Grid revenues remain strong in the third quarter,” said McGahn. For the third quarter ending December 31, 2016, AMSC expects that its revenues will be in the range of $23.0 million to $25.0 million. The Company’s net loss and non-GAAP loss (as defined below) for the third quarter of fiscal 2016 are each expected to be less than $8.0 million, or $0.57 per share.

[0001628280-16-020598:8k_2_02:12]
Conference Call Reminder

[0001628280-16-020598:8k_2_02:13]
| AMSC Reports Q2FY16 Results |  | Page 2 |

[0001628280-16-020598:8k_2_02:14]
In conjunction with this announcement, AMSC management will participate in a conference call with investors beginning at 10:00 a.m. Eastern Time today to discuss the Company’s financial results and business outlook. Those who wish to listen to the live or archived conference call webcast should visit the “Investors” section of the Company’s website at http://www.amsc.com/investors. The live call also can be accessed by dialing 785-830-7989 and using conference ID 1601966.

[0001628280-16-020598:8k_2_02:15]
About AMSC (NASDAQ: AMSC)

[0001628280-16-020598:8k_2_02:16]
AMSC generates the ideas, technologies and solutions that meet the world’s demand for smarter, cleaner … better energy™. Through its Windtec™ Solutions, AMSC provides wind turbine electronic controls and systems, designs and engineering services that reduce the cost of wind energy. Through its Gridtec™ Solutions, AMSC provides the engineering planning services and advanced grid systems that optimize network reliability, efficiency and performance. The Company’s solutions are now powering gigawatts of renewable energy globally and are enhancing the performance and reliability of power networks in more than a dozen countries. Founded in 1987, AMSC is headquartered near Boston, Massachusetts with operations in Asia, Australia, Europe and North America. For more information, please visit www.amsc.com.

[0001628280-16-020598:8k_2_02:17]
AMSC, Windtec, Gridtec, and Smarter, Cleaner … Better Energy are trademarks or registered trademarks of American Superconductor Corporation. All other brand names, product names, trademarks or service marks belong to their respective holders.

[0001628280-16-020598:8k_2_02:18]
Forward-Looking Statements

[0001628280-16-020598:8k_2_02:19]
| AMSC Reports Q2FY16 Results |  | Page 3 |

[0001628280-16-020598:8k_2_02:20]
UNAUDITED CONSOLIDATED STATEMENTS OF OPERATIONS

[0001628280-16-020598:8k_2_02:21]
(In thousands, except per share data)

[0001628280-16-020598:8k_2_02:22]
|  | Three months endedSeptember 30, |  | Six months ended September 30, |
|  | 2016 |  | 2015 |  | 2016 |  | 2015 |
| Revenues |  |  |  |  |  |  |  |
| Wind | $ | 12,898 |  |  | $ | 13,583 |  |  | $ | 18,573 |  |  | $ | 31,747 |  |
| Grid | 5,609 |  |  | 5,421 |  |  | 13,279 |  |  | 10,980 |  |
| Total revenues | 18,507 |  |  | 19,004 |  |  | 31,852 |  |  | 42,727 |  |
| Cost of revenues | 16,404 |  |  | 15,992 |  |  | 28,886 |  |  | 36,495 |  |
| Gross profit | 2,103 |  |  | 3,012 |  |  | 2,966 |  |  | 6,232 |  |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | 2,867 |  |  | 3,003 |  |  | 5,819 |  |  | 6,165 |  |
| Selling, general and administrative | 6,347 |  |  | 6,773 |  |  | 13,563 |  |  | 14,308 |  |
| Impairment of minority interest investment | — |  |  | 38 |  |  | — |  |  | 779 |  |
| Amortization of acquisition related intangibles | 39 |  |  | 39 |  |  | 78 |  |  | 78 |  |
| Total operating expenses | 9,253 |  |  | 9,853 |  |  | 19,460 |  |  | 21,330 |  |
| Operating loss | (7,150 | ) |  | (6,841 | ) |  | (16,494 | ) |  | (15,098 | ) |
| Change in fair value of derivatives and warrants | 1,244 |  |  | 701 |  |  | 567 |  |  | 1,501 |  |
| Interest expense, net | (107 | ) |  | (286 | ) |  | (243 | ) |  | (603 | ) |
| Other expense, net | (518 | ) |  | (397 | ) |  | (393 | ) |  | (1,169 | ) |
| Loss before income tax expense | (6,531 | ) |  | (6,823 | ) |  | (16,563 | ) |  | (15,369 | ) |
| Income tax expense | 794 |  |  | 875 |  |  | 1,117 |  |  | 1,450 |  |
| Net loss | $ | (7,325 | ) |  | $ | (7,698 | ) |  | $ | (17,680 | ) |  | $ | (16,819 | ) |
| Net loss per common share |  |  |  |  |  |  |  |
| Basic | $ | (0.53 | ) |  | $ | (0.57 | ) |  | $ | (1.29 | ) |  | $ | (1.31 | ) |
| Diluted | $ | (0.53 | ) |  | $ | (0.57 | ) |  | $ | (1.29 | ) |  | $ | (1.31 | ) |
| Weighted average number of common shares outstanding |  |  |  |  |  |  |  |
| Basic | 13,769 |  |  | 13,595 |  |  | 13,723 |  |  | 12,808 |  |
| Diluted | 13,769 |  |  | 13,595 |  |  | 13,723 |  |  | 12,808 |  |

[0001628280-16-020598:8k_2_02:23]
| AMSC Reports Q2FY16 Results |  | Page 4 |

[0001628280-16-020598:8k_2_02:24]
UNAUDITED CONSOLIDATED BALANCE SHEET

[0001628280-16-020598:8k_2_02:25]
(In thousands, except per share data)

[0001628280-16-020598:8k_2_02:26]
|  | September 30, 2016 |  | March 31, 2016 |
| ASSETS |  |  |  |
| Current assets: |  |  |  |
| Cash and cash equivalents | $ | 25,262 |  |  | $ | 39,330 |  |
| Accounts receivable, net | 12,130 |  |  | 19,264 |  |
| Inventory | 26,448 |  |  | 18,512 |  |
| Prepaid expenses and other current assets | 2,847 |  |  | 5,778 |  |
| Restricted cash | 452 |  |  | 457 |  |
| Total current assets | 67,139 |  |  | 83,341 |  |
| Property, plant and equipment, net | 46,677 |  |  | 49,778 |  |
| Intangibles, net | 571 |  |  | 854 |  |
| Restricted cash | 934 |  |  | 934 |  |
| Deferred tax assets | 96 |  |  | 96 |  |
| Other assets | 336 |  |  | 315 |  |
| Total assets | $ | 115,753 |  |  | $ | 135,318 |  |
| LIABILITIES AND STOCKHOLDERS' EQUITY |  |  |  |
| Current liabilities: |  |  |  |
| Accounts payable and accrued expenses | $ | 18,581 |  |  | $ | 23,156 |  |
| Note payable, current portion, net of discount of $77 as of September 30, 2016 and $42 as of March 31, 2016 | 2,089 |  |  | 2,624 |  |
| Derivative liabilities | 2,660 |  |  | 3,227 |  |
| Deferred revenue | 17,341 |  |  | 12,000 |  |
| Total current liabilities | 40,671 |  |  | 41,007 |  |
| Note payable, net of discount of $133 as of March 31, 2016 | — |  |  | 1,367 |  |
| Deferred revenue | 8,262 |  |  | 9,269 |  |
| Deferred tax liabilities | 63 |  |  | 63 |  |
| Other liabilities | 54 |  |  | 63 |  |
| Total liabilities | 49,050 |  |  | 51,769 |  |
| Stockholders' equity: |  |  |  |
| Common stock | 143 |  |  | 141 |  |
| Additional paid-in capital | 1,013,676 |  |  | 1,011,813 |  |
| Treasury stock | (1,371 | ) |  | (881 | ) |
| Accumulated other comprehensive income | 119 |  |  | 660 |  |
| Accumulated deficit | (945,864 | ) |  | (928,184 | ) |
| Total stockholders' equity | 66,703 |  |  | 83,549 |  |
| Total liabilities and stockholders' equity | $ | 115,753 |  |  | $ | 135,318 |  |

[0001628280-16-020598:8k_2_02:27]
| AMSC Reports Q2FY16 Results |  | Page 5 |

[0001628280-16-020598:8k_2_02:28]
UNAUDITED CONSOLIDATED STATEMENTS OF CASH FLOWS

[0001628280-16-020598:8k_2_02:29]
(In thousands)

[0001628280-16-020598:8k_2_02:30]
|  | Six months endedSeptember 30, |
|  | 2016 |  | 2015 |
| Cash flows from operating activities: |  |  |  |
| Net loss | $ | (17,680 | ) |  | $ | (16,819 | ) |
| Adjustments to reconcile net loss to net cash used in operations: |  |  |  |
| Depreciation and amortization | 3,735 |  |  | 4,009 |  |
| Stock-based compensation expense | 1,653 |  |  | 1,834 |  |
| Impairment of minority interest investments | — |  |  | 746 |  |
| Provision for excess and obsolete inventory | 671 |  |  | 829 |  |
| Write-off prepaid taxes | — |  |  | 511 |  |
| Loss from minority interest investments | — |  |  | 356 |  |
| Change in fair value of derivatives and warrants | (567 | ) |  | (1,501 | ) |
| Non-cash interest expense | 98 |  |  | 207 |  |
| Other non-cash items | (103 | ) |  | 921 |  |
| Changes in operating asset and liability accounts: |  |  |  |
| Accounts receivable | 7,118 |  |  | (1,196 | ) |
| Inventory | (8,696 | ) |  | 3,478 |  |
| Prepaid expenses and other current assets | 2,843 |  |  | 2,957 |  |
| Accounts payable and accrued expenses | (4,481 | ) |  | (3,337 | ) |
| Deferred revenue | 4,497 |  |  | (762 | ) |
| Net cash used in operating activities | (10,912 | ) |  | (7,767 | ) |
| Cash flows from investing activities: |  |  |  |
| Net cash used in investing activities | (368 | ) |  | (228 | ) |
| Cash flows from financing activities: |  |  |  |
| Net cash (used in)/provided by financing activities | (2,490 | ) |  | 20,202 |  |
| Effect of exchange rate changes on cash and cash equivalents | (298 | ) |  | (125 | ) |
| Net (decrease)/increase in cash and cash equivalents | (14,068 | ) |  | 12,082 |  |
| Cash and cash equivalents at beginning of year | 39,330 |  |  | 20,490 |  |
| Cash and cash equivalents at end of year | $ | 25,262 |  |  | $ | 32,572 |  |

[0001628280-16-020598:8k_2_02:31]
| AMSC Reports Q2FY16 Results |  | Page 6 |

[0001628280-16-020598:8k_2_02:32]
RECONCILIATION OF GAAP NET INCOME (LOSS) TO NON-GAAP NET INCOME (LOSS)

[0001628280-16-020598:8k_2_02:33]
(In thousands, except per share data)

[0001628280-16-020598:8k_2_02:34]
|  | Three months ended September 30, |  | Six months ended September 30, |
|  | 2016 |  | 2015 |  | 2016 |  | 2015 |
| Net loss | $ | (7,325 | ) |  | $ | (7,698 | ) |  | $ | (17,680 | ) |  | $ | (16,819 | ) |
| Stock-based compensation | 653 |  |  | 706 |  |  | 1,653 |  |  | 1,834 |  |
| Amortization of acquisition-related intangibles | 39 |  |  | 39 |  |  | 78 |  |  | 78 |  |
| Restructuring and impairment charges | — |  |  | 38 |  |  | — |  |  | 779 |  |
| Consumption of zero cost-basis inventory | (482 | ) |  | (1,223 | ) |  | (640 | ) |  | (2,069 | ) |
| Change in fair value of derivatives and warrants | (1,244 | ) |  | (701 | ) |  | (567 | ) |  | (1,501 | ) |
| Non-cash interest expense | 42 |  |  | 96 |  |  | 98 |  |  | 207 |  |
| Tax effect of adjustments | 77 |  |  | $ | — |  |  | 102 |  |  | — |  |
| Non-GAAP net loss | $ | (8,240 | ) |  | $ | (8,743 | ) |  | $ | (16,956 | ) |  | $ | (17,491 | ) |
| Non-GAAP net loss per share | $ | (0.60 | ) |  | $ | (0.64 | ) |  | $ | (1.24 | ) |  | $ | (1.37 | ) |
| Weighted average shares outstanding - basic and diluted | 13,769 |  |  | 13,595 |  |  | 13,723 |  |  | 12,808 |  |

[0001628280-16-020598:8k_2_02:35]
Reconciliation of Forecast GAAP Net Loss to Non-GAAP Net Loss

[0001628280-16-020598:8k_2_02:36]
(In millions, except per share data)

[0001628280-16-020598:8k_2_02:37]
|  | Three months ending |
| December 31, 2016 |
| Net loss | $(8.0) |
| Stock-based compensation | 0.6 |  |
| Consumption of zero-cost inventory | (0.6 | ) |
| Non-GAAP net loss | $(8.0) |
| Non-GAAP net loss per share | $(0.57) |
| Shares outstanding | 14.0 |  |

[0001628280-16-020598:8k_2_02:38]
Note: Non-GAAP net loss is defined by the Company as net loss before stock-based compensation; amortization of acquisition-related intangibles; consumption of zero cost-basis inventory; non-cash interest expense; change in fair value of derivatives and warrants; and other unusual charges, net of any tax effects related to these items. The Company believes non-GAAP net loss assists management and investors in comparing the Company’s performance across reporting periods on a consistent basis by excluding these non-cash, non-recurring or other charges that it does not believe are indicative of its core operating performance. The Company also regards non-GAAP net loss as a useful measure of operating performance to complement operating loss, net loss and other GAAP financial performance measures. In addition, the Company uses non-GAAP net loss as a factor in evaluating management’s performance when determining incentive compensation and to evaluate the effectiveness of its business strategies.

[0001628280-16-020598:8k_2_02:39]
Generally, a non-GAAP financial measure is a numerical measure of a company's performance, financial position or cash flow that either excludes or includes amounts that are not normally excluded or included in the most directly comparable measure calculated and presented in accordance with GAAP. The non-GAAP measures included in this release, however, should be considered in addition to, and not as a substitute for or superior to, operating income, cash flows, or other measures of financial performance prepared in accordance with GAAP. A reconciliation of non-GAAP to GAAP net loss is set forth in the table above.

[0001628280-16-020598:8k_2_02:40]
AMSC Contact:

[0001628280-16-020598:8k_2_02:41]
Brion D. Tanous

[0001628280-16-020598:8k_2_02:42]
AMSC Investor Relations

[0001628280-16-020598:8k_2_02:43]
Phone: 424-634-8592

[0001628280-16-020598:8k_2_02:44]
| AMSC Reports Q2FY16 Results |  | Page 7 |

[0001628280-16-020598:8k_2_02:45]
Email: Brion.Tanous@amsc.com
