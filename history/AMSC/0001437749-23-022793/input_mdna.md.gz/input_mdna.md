# AMSC MD&A — 0001437749-23-022793


## mdna

[0001437749-23-022793:mdna:1]
[same as prior period, unchanged from 0001437749-23-002270:mdna:1]

[0001437749-23-022793:mdna:2]
[same as prior period, unchanged from 0001437749-23-002270:mdna:2]

[0001437749-23-022793:mdna:3]
[same as prior period, unchanged from 0001437749-23-002270:mdna:3]

[0001437749-23-022793:mdna:4]
We are a leading system provider of megawatt-scale power resiliency solutions that Orchestrate the Rhythm and Harmony of Power on the Grid™, and protect and expand the capability of our Navy's fleet. Our solutions enhance the performance of the power grid, protect our Navy’s fleet, and lower the cost of wind power.  In the power grid market, we enable electric utilities, industrial facilities, and renewable energy project developers to connect, transmit and distribute smarter, cleaner and better power through our transmission planning services and power electronics and superconductor-based systems. In the wind power market, we enable manufacturers to field highly competitive wind turbines through our advanced power electronics and control system products, engineering, and support services. Our power grid and wind products and services provide exceptional reliability, security, efficiency and affordability to our customers.

[0001437749-23-022793:mdna:5]
Our power system solutions help to improve energy efficiency, alleviate power grid capacity constraints, improve system resiliency, and increase the adoption of renewable energy generation. Demand for our solutions is driven by the growing needs for modernized smart grids that improve power reliability, security and quality, the U.S. Navy's effort to upgrade in-board power systems to support fleet electrification, and the need for increased renewable sources of electricity, such as wind and solar energy. Concerns about these factors have led to increased spending by corporations and the military, as well as supportive government regulations and initiatives on local, state, and national levels, including renewable portfolio standards, tax incentives and international treaties.

[0001437749-23-022793:mdna:6]
[same as prior period, unchanged from 0001437749-23-002270:mdna:6]

[0001437749-23-022793:mdna:7]
We operate our business under two market-facing business units: Grid and Wind. We believe this market-centric structure enables us to more effectively anticipate and meet the needs of power generation project developers, the Navy's ship protection systems, electric utilities and wind turbine manufacturers.

[0001437749-23-022793:mdna:8]
|  | • | Grid. Through our Gridtec™ Solutions, our Grid business segment enables electric utilities and renewable energy project developers to connect, transmit and distribute power with exceptional efficiency, reliability, security and affordability. We provide transmission planning services that allow us to identify power grid congestion, poor power quality, and other risks, which help us determine how our solutions can improve network performance. These services often lead to sales of our grid interconnection solutions for wind farms and solar power plants, power quality systems and transmission and distribution cable systems. We also sell ship protection products to the U.S. Navy through our Grid business segment. |

[0001437749-23-022793:mdna:9]
[same as prior period, unchanged from 0001437749-23-002270:mdna:9]

[0001437749-23-022793:mdna:10]
Our fiscal year begins on April 1 and ends on March 31. When we refer to a particular fiscal year, we are referring to the fiscal year that began on April 1 of that same year. For example, fiscal 2023 refers to the fiscal year that began on April 1, 2023. Other fiscal years follow similarly.

[0001437749-23-022793:mdna:11]
22

[0001437749-23-022793:mdna:12]
We continue to experience inflationary pressure in our supply chain and some delays in sourcing materials needed for our products, resulting in some production disruption, both of which have increased our cost of revenues and decreased gross margin.  While the impact of inflation has been challenging, we continue to take actions to limit this pressure including adjusting the pricing of our products and services. Changes in macroeconomic and market conditions arising from the COVID-19 pandemic, or for other reasons, such as the ongoing war between Russia and Ukraine, inflation, rising interest rates, labor force availability, sourcing, material delays and global supply chain disruptions could have a material adverse effect on our business, financial condition and results of operation.

[0001437749-23-022793:mdna:13]
From time-to-time we may undertake restructuring activities in order to align our global organization in a manner that we believe will better position us to achieve our long-term goals. In January 2023, we undertook a reduction in force that involved approximately 5% of our global workforce. This restructuring is expected to incur $1.0 million of cash expenses, $0.7 million of which has been paid as of June 30, 2023 and to result in annualized cost savings of approximately $5.0 million, beginning in fiscal 2023.

[0001437749-23-022793:mdna:14]
In February 2023, we completed the process of determining and verifying our eligibility and amount of payroll tax credits known as the Employee Retention Credit (“ERC”) under the CARES Act which Congress enacted as part of the Taxpayer Certainty and Disaster Tax Relief Act of 2020.  This resulted in filing certain amended payroll tax forms for eligible quarters in 2020 and 2021, which, in the aggregate, totaled $3.3 million. We recognized a receivable in prepaid expenses and other current assets and a benefit to cost of revenues and operating expenses in the quarter ended March 31, 2023. During the quarter ended June 30, 2023, we received $2.2 million in payments for the initial claims that were processed.  The remaining balance is expected to be paid during fiscal 2023.

[0001437749-23-022793:mdna:15]
[same as prior period, unchanged from 0001437749-23-002270:mdna:14]

[0001437749-23-022793:mdna:16]
The preparation of the unaudited condensed consolidated financial statements requires that we make estimates and judgments that affect the reported amounts of assets, liabilities, revenues and expenses, and related disclosure of contingent assets and liabilities. We base our estimates on historical experience and various other assumptions that are believed to be reasonable under the circumstances, the results of which form the basis for making judgments about the carrying values of assets and liabilities that are not readily apparent from other sources. Actual results may differ under different assumptions or conditions. There were no significant changes in the critical accounting policies that were disclosed in our Annual Report on Form 10-K for the fiscal year ended March 31, 2023.

[0001437749-23-022793:mdna:17]
[same as prior period, unchanged from 0001437749-23-002270:mdna:16]

[0001437749-23-022793:mdna:18]
Three months ended June 30, 2023, compared to the three months ended June 30, 2022

[0001437749-23-022793:mdna:19]
[same as prior period, unchanged from 0001437749-23-002270:mdna:18]

[0001437749-23-022793:mdna:20]
Total revenues increased 33% to $30.3 million for the three months ended June 30, 2023, compared to $22.7 for the three months ended June 30, 2022. Our revenues are summarized as follows (in thousands):

[0001437749-23-022793:mdna:21]
|  |  | Three Months Ended June 30, |  |
|  |  | 2023 |  |  | 2022 |  |
| Revenues: |  |  |  |  |  |  |  |  |
| Grid |  | $ | 25,737 |  |  | $ | 19,829 |  |
| Wind |  |  | 4,517 |  |  |  | 2,850 |  |
| Total |  | $ | 30,254 |  |  | $ | 22,679 |  |

[0001437749-23-022793:mdna:22]
Our Grid business unit accounted for 85% of total revenues for the three months ended June 30, 2023, compared to 87% for the three months ended June 30, 2022. Our Grid business unit revenues increased 30% to $25.7 million in the three months ended June 30, 2023, from $19.8 million in the three months ended June 30, 2022. The increase in the Grid business unit revenue in the three months ended June 30, 2023, compared to the three months ended June 30, 2022 was primarily driven by higher new energy power systems revenues than in the prior year period.

[0001437749-23-022793:mdna:23]
Our Wind business unit accounted for 15% of total revenues for the three months ended June 30, 2023, compared to 13% for the three months ended June 30, 2022. Revenues in the Wind business unit increased 58% to $4.5 million in the three months ended June 30, 2023, from $2.9 million in the three months ended June 30, 2022. The increase in the three months ended June 30, 2023, was driven by additional shipments of electrical control systems ("ECS") to Inox in the three months ended June 30, 2023.

[0001437749-23-022793:mdna:24]
[same as prior period, unchanged from 0001437749-23-002270:mdna:23]

[0001437749-23-022793:mdna:25]
Cost of revenues increased by 17% to $24.0 million for the three months ended June 30, 2023, compared to $20.5 million for the three months ended June 30, 2022. Gross margin was 21% for the three months ended June 30, 2023, compared to 10% for the three months ended June 30, 2022.  The increase in gross margin in the three months ended June 30, 2023, was due to higher revenues, and a more favorable product mix in our Grid business unit.

[0001437749-23-022793:mdna:26]
[same as prior period, unchanged from 0001437749-23-002270:mdna:25]

[0001437749-23-022793:mdna:27]
[same as prior period, unchanged from 0001437749-23-002270:mdna:26]

[0001437749-23-022793:mdna:28]
Research and development ("R&D") expenses decreased 30% in the three months ended June 30, 2023, to $1.9 million from $2.7 million in the three months ended June 30, 2022. The decrease was driven by decreased compensation expense as well as increased labor charges reclassified to cost of goods sold for revenue generating projects.

[0001437749-23-022793:mdna:29]
[same as prior period, unchanged from 0001437749-23-002270:mdna:28]

[0001437749-23-022793:mdna:30]
Selling, general and administrative ("SG&A") expenses increased 4% in the three months ended June 30, 2023, to $7.9 million from $7.6 million in the three months ended June 30, 2022. The increase in SG&A expense in the three months ended June 30, 2023, was due to higher compensation and stock compensation expense than in the prior year period.

[0001437749-23-022793:mdna:31]
[same as prior period, unchanged from 0001437749-23-002270:mdna:30]

[0001437749-23-022793:mdna:32]
We recorded amortization expense related to our core technology and know-how, customer relationships, and other intangible assets of $0.5 million in the three months ended June 30, 2023, and $0.7 million in the three months ended June 30, 2022. The decrease in amortization expense in the three months ended June 30, 2023 is a result of using the economic consumption method as the basis to amortize the acquired customer relationship intangible assets from Northeast Power Systems, Inc. ("NEPSI") and Neeltran, Inc. (“Neeltran”).

[0001437749-23-022793:mdna:33]
[same as prior period, unchanged from 0001437749-23-002270:mdna:32]

[0001437749-23-022793:mdna:34]
The change in fair value of our contingent consideration for the earnout payment on the acquisition of NEPSI resulted in a loss of $1.3 million and $0.2 million in the three months ended June 30, 2023, and June 30, 2022 respectively. The change in the fair value was primarily driven by an increased likelihood of achieving certain revenue targets and an increase in the Company's stock price.

[0001437749-23-022793:mdna:35]
[same as prior period, unchanged from 0001437749-23-002270:mdna:34]

[0001437749-23-022793:mdna:36]
[same as prior period, unchanged from 0001437749-23-002270:mdna:35]

[0001437749-23-022793:mdna:37]
|  |  | Three Months Ended June 30, |  |
|  |  | 2023 |  |  | 2022 |  |
| Operating loss: |  |  |  |  |  |  |  |  |
| Grid |  | $ | (1,971 | ) |  | $ | (7,281 | ) |
| Wind |  |  | (649 | ) |  |  | (386 | ) |
| Unallocated corporate expenses |  |  | (2,713 | ) |  |  | (1,202 | ) |
| Total |  | $ | (5,333 | ) |  | $ | (8,869 | ) |

[0001437749-23-022793:mdna:38]
Our Grid business segment generated operating losses of $2.0 million in the three months ended June 30, 2023, compared to operating losses of $7.3 million in the three months ended June 30, 2022. The decrease in the Grid business unit operating loss in the three months ended June 30, 2023, was due to higher gross revenues and gross margins due to a favorable product mix as well as reduction of remaining acquired Neeltran backlog.

[0001437749-23-022793:mdna:39]
Our Wind business segment generated operating losses of $0.6 million in the three months ended June 30, 2023, compared to operating losses of $0.4 million in the three months ended June 30, 2022. The increase in the Wind business unit operating loss was due to lower gross margins.

[0001437749-23-022793:mdna:40]
Unallocated corporate expenses included a loss on contingent consideration of $1.3 million and $0.2 million in the three months ended June 30, 2023 and 2022, respectively. Additionally, unallocated corporate expenses primarily consisted of stock-based compensation expense of $1.4 million and $1.0 million in the three months ended June 30, 2023 and 2022, respectively.

[0001437749-23-022793:mdna:41]
[same as prior period, unchanged from 0001437749-23-002270:mdna:40]

[0001437749-23-022793:mdna:42]
Interest income, net, was $0.2 million in the three months ended June 30, 2023 compared to less than $0.1 million in the three months ended June 30, 2022.

[0001437749-23-022793:mdna:43]
[same as prior period, unchanged from 0001437749-23-002270:mdna:44]

[0001437749-23-022793:mdna:44]
Other expense, net, was $0.1 million in the three months ended June 30, 2023, compared to other income, net, of $0.2 million in the three months ended June 30, 2022. The increase in other expense, net, during the three months ended June 30, 2023, was driven by the impacts of unfavorable fluctuations in foreign currencies during the period.

[0001437749-23-022793:mdna:45]
[same as prior period, unchanged from 0001437749-23-002270:mdna:46]

[0001437749-23-022793:mdna:46]
Income tax expense was $0.1 million in the three months ended June 30, 2023 compared to less than $0.1 million in the three months ended June 30, 2022.

[0001437749-23-022793:mdna:47]
[same as prior period, unchanged from 0001437749-23-002270:mdna:48]

[0001437749-23-022793:mdna:48]
Net loss was $5.4 million in the three months ended June 30, 2023, compared to $8.7 million in the three months ended June 30, 2022. The decrease in net loss was driven primarily by the increased revenues and gross margins.

[0001437749-23-022793:mdna:49]
[same as prior period, unchanged from 0001437749-23-002270:mdna:50]

[0001437749-23-022793:mdna:50]
[same as prior period, unchanged from 0001437749-23-002270:mdna:51]

[0001437749-23-022793:mdna:51]
We define non-GAAP net loss as net loss before, stock-based compensation, amortization of acquisition-related intangibles, change in fair value of contingent consideration, and other non-cash or unusual charges.  We believe non-GAAP net loss assists management and investors in comparing our performance across reporting periods on a consistent basis by excluding these non-cash charges and other items that we do not believe are indicative of our core operating performance. In addition, we use non-GAAP net loss as a factor to evaluate the effectiveness of our business strategies. A reconciliation of GAAP to non-GAAP net loss is set forth in the table below (in thousands, except per share data):

[0001437749-23-022793:mdna:52]
|  |  | Three Months Ended June 30, |  |
|  |  | 2023 |  |  | 2022 |  |
| Net loss |  | $ | (5,398 | ) |  | $ | (8,710 | ) |
| Stock-based compensation |  |  | 1,357 |  |  |  | 1,033 |  |
| Amortization of acquisition-related intangibles |  |  | 544 |  |  |  | 712 |  |
| Change in fair value of contingent consideration |  |  | 1,350 |  |  |  | 170 |  |
| Non-GAAP net loss |  | $ | (2,147 | ) |  | $ | (6,795 | ) |
| Non-GAAP net loss per share - basic |  | $ | (0.08 | ) |  | $ | (0.25 | ) |
| Weighted average shares outstanding - basic |  |  | 28,258 |  |  |  | 27,560 |  |

[0001437749-23-022793:mdna:53]
We incurred non-GAAP net losses of $2.1 million, or $0.08 per share, for the three months ended June 30, 2023, compared to $6.8 million, or $0.25 per share, for the three months ended June 30, 2022. The improvement in the non-GAAP net loss for the three months ended June 30, 2023 was due to a lower operating loss driven by higher revenues and gross margins.

[0001437749-23-022793:mdna:54]
[same as prior period, unchanged from 0001437749-23-002270:mdna:55]

[0001437749-23-022793:mdna:55]
We have experienced recurring operating losses and, as of June 30, 2023, had an accumulated deficit of $1,061 million.

[0001437749-23-022793:mdna:56]
[same as prior period, unchanged from 0001437749-23-002270:mdna:57]

[0001437749-23-022793:mdna:57]
[same as prior period, unchanged from 0001437749-23-002270:mdna:58]

[0001437749-23-022793:mdna:58]
As of June 30, 2023, we had cash, cash equivalents and restricted cash of $23.1 million, compared to $25.7 million as of March 31, 2023, a decrease of $2.6 million. As of June 30, 2023, we had approximately $2.3 million of cash, cash equivalents, and restricted cash in foreign bank accounts. Our cash, cash equivalents, and restricted cash are summarized as follows (in thousands):

[0001437749-23-022793:mdna:59]
|  |  | June 30, 2023 |  |  | March 31, 2023 |  |
| Cash and cash equivalents |  | $ | 22,005 |  |  | $ | 23,360 |  |
| Restricted cash |  |  | 1,118 |  |  |  | 2,315 |  |
| Total cash, cash equivalents, and restricted cash |  | $ | 23,123 |  |  | $ | 25,675 |  |

[0001437749-23-022793:mdna:60]
For the three months ended June 30, 2023, net cash used in operating activities was $2.2 million, compared to $5.9 million for the three months ended June 30, 2022. The decrease in net cash used in operations was due primarily to a decrease in prepaid expenses and other current assets and deferred revenue in the three months ended June 30, 2023 as compared to June 30, 2022. Cash flows from operating activities included a reimbursement of $2.1 million in the three months ended June 30, 2023 for the ERC receivable in prepaid expenses and other current assets at March 31, 2023.

[0001437749-23-022793:mdna:61]
For the three months ended June 30, 2023, net cash used in investing activities was $0.3 million, compared to $0.5 million for the three months ended June 30, 2022. The decrease in net cash used in investing activities was primarily due to a decrease in purchases of property, plant and equipment.

[0001437749-23-022793:mdna:62]
For the three months ended June 30, 2023 and 2022, respectively, net cash used in financing activities remained consistent at less than $0.1 million.

[0001437749-23-022793:mdna:63]
As of June 30, 2023, we had $0.6 million of restricted cash included in long-term assets and $0.5 million of restricted cash included in current assets.  At March 31, 2023, we had $0.6 million of restricted cash included in long-term assets and $1.7 million of restricted cash in current assets.  These amounts included in restricted cash primarily represent collateral deposits to secure surety bonds and letters of credit for various customer contracts. These deposits are held in interest bearing accounts.

[0001437749-23-022793:mdna:64]
We are a party to many contractual obligations involving commitments to make payments to third parties. These obligations impact our short-term and long-term liquidity and capital resource needs. Certain contractual obligations are reflected on the consolidated balance sheet as of June 30, 2023, while others are considered future commitments. We have various contractual arrangements, under which we have committed to purchase certain minimum quantities of goods or services on an annual basis. For information regarding our other contractual obligations, refer to Note 13, "Contingent Consideration," Note 14, "Debt," Note 15, "Leases" and Note 16, "Commitments and Contingencies" to our condensed consolidated financial statements included elsewhere in this Quarterly Report on Form 10-Q.

[0001437749-23-022793:mdna:65]
We believe we have sufficient available liquidity to fund our operations and capital expenditures for the next twelve months. In addition, we may seek to raise additional capital, which could be in the form of loans, convertible debt or equity, to fund our operating requirements and capital expenditures. Our liquidity is highly dependent on our ability to increase revenues, control our operating costs, and raise additional capital, if necessary. There can be no assurance that we will be able to raise additional capital on favorable terms or at all or execute on any other means of improving our liquidity as described above.  Additionally, the impact of the COVID-19 pandemic or other sources of instability, including the ongoing war between Russia and Ukraine, instability of financial institutions and political instability in the United States, on the global financial markets may reduce our ability to raise additional capital, if necessary, which could negatively impact our liquidity. We also continue to closely monitor our expenses and, if required, we intend to reduce our operating and capital spending to enhance liquidity.

[0001437749-23-022793:mdna:66]
Legal Proceedings

[0001437749-23-022793:mdna:67]
From time to time, we are involved in legal and administrative proceedings and claims of various types. We record a liability in our condensed consolidated financial statements for these matters when a loss is known or considered probable and the amount can be reasonably estimated. We review these estimates each accounting period as additional information is known and adjust the loss provision when appropriate. If a matter is both probable to result in liability and the amounts of loss can be reasonably estimated, we estimate and disclose the possible loss or range of loss to the extent necessary to make the condensed consolidated financial statements not misleading. If the loss is not probable or cannot be reasonably estimated, a liability is not recorded in our condensed consolidated financial statements.

[0001437749-23-022793:mdna:68]
[same as prior period, unchanged from 0001437749-23-002270:mdna:69]

[0001437749-23-022793:mdna:69]
In June 2016, the FASB issued ASU 2016-13, Financial Instruments-Credit Losses (Topic 326): Measurement of Credit Losses on Financial Instruments. The amendments in ASU 2016-13 will provide more decision-useful information about the expected credit losses on financial instruments and other commitments to extend credit held by a reporting entity at each reporting date. Following the release of ASU 2019-10 in November 2019, the effective date, as long as we remain a smaller reporting company, was annual reporting periods beginning after December 15, 2022.  As of April 1, 2023, we have adopted ASU 2016-13 and noted no material impact on our condensed consolidated financial statements.

[0001437749-23-022793:mdna:70]
In October 2021, the FASB issued ASU 2021-08, Business Combinations (Topic 805): Accounting for Contract Assets and Contract Liabilities from Contracts with Customers. The amendments in ASU 2021-08 will improve the accounting for acquired revenue contracts with customers in a business combination. Following the release of ASU 2021-08 in October 2021, the effective date was annual reporting periods beginning after December 15, 2022. As of April 1, 2023, we have adopted ASU 2021-08 and noted no material impact on our condensed consolidated financial statements.

[0001437749-23-022793:mdna:71]
We do not believe that, outside of those disclosed here, there are any other recently issued accounting pronouncements that will have a material impact on our condensed consolidated financial statements.

[0001437749-23-022793:mdna:72]
27
