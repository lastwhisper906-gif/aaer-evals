# AMSC note change history — 0001437749-23-002270 → 0001437749-23-022793


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2023-08-09):
[0001437749-23-022793:note_history:1]
From time to time, the Company is involved in legal and administrative proceedings and claims of various types. The Company records a liability in its condensed consolidated financial statements for these matters when a loss is known or considered probable and the amount can be reasonably estimated. The Company reviews these estimates each accounting period as additional information is known and adjusts the loss provision when appropriate. If a matter is both probable to result in a liability and the amounts of loss can be reasonably estimated, the Company estimates and discloses the possible loss or range of loss to the extent necessary to make the condensed consolidated financial statements not misleading. If the loss is not probable or cannot be reasonably estimated, a liability is not recorded in its condensed consolidated financial statements.
  (was, 2023-02-01, similarity 0.9822):
[0001437749-23-002270:note_history:1]
From time to time, the Company is involved in legal and administrative proceedings and claims of various types. The Company records a liability in its consolidated financial statements for these matters when a loss is known or considered probable and the amount can be reasonably estimated. The Company reviews these estimates each accounting period as additional information is known and adjusts the loss provision when appropriate. If a matter is both probable to result in a liability and the amounts of loss can be reasonably estimated, the Company estimates and discloses the possible loss or range of loss to the extent necessary to make the consolidated financial statements not misleading. If the loss is not probable or cannot be reasonably estimated, a liability is not recorded in its consolidated financial statements.

- changed (2023-08-09):
[0001437749-23-022793:note_history:2]
As of  June 30, 2023, the Company had $0.6 million of restricted cash included in long-term assets and $0.5 million of restricted cash included in current assets. As of  March 31, 2023, the Company had $0.6 million of restricted cash included in long term assets and $1.7 million of restricted cash included in current assets. These amounts included in restricted cash primarily represent deposits to secure letters of credit for various supply contracts and long-term projects or collateral deposits.  These deposits are held in interest bearing accounts.
  (was, 2023-02-01, similarity 0.8384):
[0001437749-23-002270:note_history:2]
As of  December 31, 2022, the Company had $1.0 million of restricted cash included in long-term assets and $6.6 million of restricted cash included in current assets. As of  March 31, 2022, the Company had $6.1 million of restricted cash included in long term assets and $2.8 million of restricted cash included in current assets. These amounts included in restricted cash primarily represent deposits to secure letters of credit for various supply contracts and long-term projects, including the irrevocable letter of credit in the amount of $5.0 million to secure certain of the Company's obligations under a subcontract agreement with ComEd.  These deposits are held in interest bearing accounts.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2023-08-09):
[0001437749-23-022793:note_history:3]
These unaudited condensed consolidated financial statements of the Company have been prepared on a going concern basis in accordance with United States generally accepted accounting principles (“GAAP”) and the Securities and Exchange Commission’s (“SEC”) instructions to Form 10-Q. The going concern basis of presentation assumes that the Company will continue operations and will be able to realize its assets and discharge its liabilities and commitments in the normal course of business. Certain information and footnote disclosures normally included in the financial statements prepared in accordance with GAAP have been condensed or omitted pursuant to those instructions. The year-end condensed balance sheet data was derived from audited financial statements but does not include all disclosures required by GAAP. The unaudited condensed consolidated financial statements, in the opinion of management, reflect all adjustments (consisting of normal recurring adjustments) necessary for a fair statement of the results for the interim periods ended  June 30, 2023 and 2022 and the financial position at  June 30, 2023; however, these results are not necessarily indicative of results which  may be expected for the full year. The interim condensed consolidated financial statements, and notes thereto, should be read in conjunction with the audited condensed consolidated financial statements for the year ended  March 31, 2023, and notes thereto, included in the Company’s Annual Report on Form 10-K for the year ended  March 31, 2023 filed with the SEC on  May 31, 2023.
  (was, 2023-02-01, similarity 0.9867):
[0001437749-23-002270:note_history:3]
These unaudited condensed consolidated financial statements of the Company have been prepared on a going concern basis in accordance with United States generally accepted accounting principles (“GAAP”) and the Securities and Exchange Commission’s (“SEC”) instructions to Form 10-Q. The going concern basis of presentation assumes that the Company will continue operations and will be able to realize its assets and discharge its liabilities and commitments in the normal course of business. Certain information and footnote disclosures normally included in the financial statements prepared in accordance with GAAP have been condensed or omitted pursuant to those instructions. The year-end condensed balance sheet data was derived from audited financial statements but does not include all disclosures required by GAAP. The unaudited condensed consolidated financial statements, in the opinion of management, reflect all adjustments (consisting of normal recurring adjustments) necessary for a fair statement of the results for the interim periods ended  December 31, 2022 and 2021 and the financial position at  December 31, 2022; however, these results are not necessarily indicative of results which  may be expected for the full year. The interim condensed consolidated financial statements, and notes thereto, should be read in conjunction with the audited consolidated financial statements for the year ended  March 31, 2022, and notes thereto, included in the Company’s Annual Report on Form 10-K for the year ended  March 31, 2022 filed with the SEC on  June 1, 2022.

- changed (2023-08-09):
[0001437749-23-022793:note_history:4]
The Company has historically experienced recurring operating losses and as of  June 30, 2023, the Company had an accumulated deficit of $1,061 million. In addition, the Company has historically experienced recurring negative operating cash flows. At  June 30, 2023, the Company had cash and cash equivalents of $22.0 million. Cash used in operations for the three months ended  June 30, 2023 was $2.2 million.
  (was, 2023-02-01, similarity 0.9053):
[0001437749-23-002270:note_history:4]
The Company has historically experienced recurring operating losses and as of  December 31, 2022, the Company had an accumulated deficit of $1,049 million. In addition, the Company has historically experienced recurring negative operating cash flows. At  December 31, 2022, the Company had cash and cash equivalents of $23.7 million. Cash used in operations for the nine months ended  December 31, 2022 was $17.1 million.

- changed (2023-08-09):
[0001437749-23-022793:note_history:5]
The Company continues to experience inflationary pressure in its supply chain and some delays in sourcing materials needed for its products resulting in some production disruption, both of which have increased the Company’s cost of revenues and decreased gross margin. While the impact of inflation has been challenging, the Company continues to take actions to limit this pressure, including adjusting the pricing of its products and services. Changes in macroeconomic conditions arising from the COVID-19 pandemic or for other reasons, such as the ongoing war between Russia and Ukraine, inflation, rising interest rates, labor force availability, sourcing, material delays and global supply chain disruptions could have a material adverse effect on the Company’s business, financial condition and results of operation.
  (was, 2023-02-01, similarity 0.6608):
[0001437749-23-002270:note_history:5]
The Company is experiencing substantial inflationary pressure in its supply chain and some delays in sourcing materials needed for its products resulting in some production disruption, both of which have increased the Company’s cost of revenues and decreased gross margin. Changes in macroeconomic conditions arising from the COVID-19 pandemic or for other reasons, such as the ongoing war between Russia and Ukraine, inflation, rising interest rates, labor force availability, sourcing, material delays and global supply chain disruptions could have a material adverse effect on the Company’s business, financial condition and results of operation.

- changed (2023-08-09):
[0001437749-23-022793:note_history:6]
From time-to-time the Company  may undertake restructuring activities in order to align the global organization in a manner that the Company believes will better position it to achieve its long-term goals. In  January 2023, the Company undertook a reduction in force that involved approximately 5% of the global workforce. This restructuring is expected to incur $1.0 million of cash expenses, $0.7 million of which has been paid as of  June 30, 2023, and to result in annualized cost savings of approximately $5.0 million, beginning in fiscal 2023.
  (was, 2023-02-01, similarity 0.7283):
[0001437749-23-002270:note_history:6]
From time-to-time the Company  may undertake restructuring activities in order to align the global organization in a manner that the Company believes will better position it to achieve its long-term goals. In  January 2023, the Company undertook a reduction in force that involved approximately 5% of the global workforce. This restructuring is expected to incur an immaterial amount of cash expense and to result in annualized cost savings of approximately $5 million, beginning in fiscal year 2023.

- changed (2023-08-09):
[0001437749-23-022793:note_history:7]
The Company believes that based on the information presented above and its quarterly management assessment, it has sufficient liquidity to fund its operations and capital expenditures for the next twelve months following the issuance of the financial statements for the three months ended  June 30, 2023. The Company’s liquidity is highly dependent on its ability to increase revenues, its ability to control its operating costs, and its ability to raise additional capital, if necessary. The impact of the COVID-19 pandemic and other sources of instability, including the war between Russia and Ukraine, on the global financing markets  may reduce the Company's ability to raise additional capital, if necessary, which could negatively impact the Company's liquidity.  There can be no assurance that the Company will be able to continue to raise additional capital, on favorable terms or at all, from other sources or execute on any other means of improving liquidity described above.
  (was, 2023-02-01, similarity 0.9749):
[0001437749-23-002270:note_history:7]
The Company believes that based on the information presented above and its quarterly management assessment, it has sufficient liquidity to fund its operations and capital expenditures for the next twelve months following the issuance of the financial statements for the nine months ended  December 31, 2022. The Company’s liquidity is highly dependent on its ability to increase revenues, its ability to control its operating costs, and its ability to raise additional capital, if necessary. The impact of the COVID-19 pandemic and other sources of instability, including the war between Russia and Ukraine, on the global financing markets  may reduce the Company's ability to raise additional capital, if necessary, which could negatively impact the Company's liquidity.  There can be no assurance that the Company will be able to continue to raise additional capital, on favorable terms or at all, from other sources or execute on any other means of improving liquidity described above.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2023-08-09):
[0001437749-23-022793:note_history:8]
As part of the acquisition of Neeltran, the Company identified four equipment financing agreements that Neeltran had entered into prior to the acquisition of Neeltran on  May 6, 2021. The current and long-term aggregate debt balance is $0.1 million as of  June 30, 2023 and  March 31, 2023, respectively.

- removed (2023-08-09):
[0001437749-23-002270:note_history:9]
As part of the Neeltran Acquisition, the Company identified four equipment financing agreements that Neeltran had entered into prior to the acquisition on  May 6, 2021. The Company determined to account for these agreements as a debt transaction and recorded current and long-term debt liabilities of $0.1 million each during the three months ended  June 30, 2021. The current and long-term debt balance is $0.1 million and less than $0.1 million as of  December 31, 2022, respectively.


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2023-08-09):
[0001437749-23-022793:note_history:10]
|  |  | Three Months Ended June 30, 2023 |  |
| Product Line: |  | Grid |  |  | Wind |  |
| Equipment and systems |  | $ | 23,126 |  |  | $ | 3,982 |  |
| Services and technology development |  |  | 2,611 |  |  |  | 535 |  |
| Total |  | $ | 25,737 |  |  | $ | 4,517 |  |
| Region: |  |  |  |  |  |  |  |  |
| Americas |  | $ | 23,161 |  |  | $ | - |  |
| Asia Pacific |  |  | 1,711 |  |  |  | 4,465 |  |
| EMEA |  |  | 865 |  |  |  | 52 |  |
| Total |  | $ | 25,737 |  |  | $ | 4,517 |  |
  (was, 2023-02-01, similarity 0.6614):
[0001437749-23-002270:note_history:10]
|  |  | Three Months Ended December 31, 2021 |  |  | Nine Months Ended December 31, 2021 |  |
| Product Line: |  | Grid |  |  | Wind |  |  | Grid |  |  | Wind |  |
| Equipment and systems |  | $ | 23,416 |  |  | $ | 1,309 |  |  | $ | 67,605 |  |  | $ | 4,168 |  |
| Services and technology development |  |  | 1,634 |  |  |  | 440 |  |  |  | 5,564 |  |  |  | 2,789 |  |
| Total |  | $ | 25,050 |  |  | $ | 1,749 |  |  | $ | 73,169 |  |  | $ | 6,957 |  |
| Region: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas |  | $ | 16,739 |  |  | $ | 56 |  |  | $ | 57,498 |  |  | $ | 134 |  |
| Asia Pacific |  |  | 7,064 |  |  |  | 1,690 |  |  |  | 10,931 |  |  |  | 6,781 |  |
| EMEA |  |  | 1,247 |  |  |  | 3 |  |  |  | 4,740 |  |  |  | 42 |  |
| Total |  | $ | 25,050 |  |  | $ | 1,749 |  |  | $ | 73,169 |  |  | $ | 6,957 |  |

- added (2023-08-09):
[0001437749-23-022793:note_history:11]
|  |  | Three Months Ended June 30, 2022 |  |
| Product Line: |  | Grid |  |  | Wind |  |
| Equipment and systems |  | $ | 18,076 |  |  | $ | 1,973 |  |
| Services and technology development |  |  | 1,753 |  |  |  | 877 |  |
| Total |  | $ | 19,829 |  |  | $ | 2,850 |  |
| Region: |  |  |  |  |  |  |  |  |
| Americas |  | $ | 16,902 |  |  | $ | - |  |
| Asia Pacific |  |  | 2,677 |  |  |  | 2,850 |  |
| EMEA |  |  | 250 |  |  |  | - |  |
| Total |  | $ | 19,829 |  |  | $ | 2,850 |  |

- removed (2023-08-09):
[0001437749-23-002270:note_history:12]
|  |  | Three Months Ended December 31, 2022 |  |  | Nine Months Ended December 31, 2022 |  |
| Product Line: |  | Grid |  |  | Wind |  |  | Grid |  |  | Wind |  |
| Equipment and systems |  | $ | 19,475 |  |  | $ | 2,842 |  |  | $ | 61,680 |  |  | $ | 6,144 |  |
| Services and technology development |  |  | 1,334 |  |  |  | 230 |  |  |  | 4,657 |  |  |  | 1,760 |  |
| Total |  | $ | 20,809 |  |  | $ | 3,072 |  |  | $ | 66,337 |  |  | $ | 7,904 |  |
| Region: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas |  | $ | 17,010 |  |  |  | 19 |  |  | $ | 51,934 |  |  | $ | 19 |  |
| Asia Pacific |  |  | 1,760 |  |  |  | 3,053 |  |  |  | 10,615 |  |  |  | 7,815 |  |
| EMEA |  |  | 2,039 |  |  |  | - |  |  |  | 3,788 |  |  |  | 70 |  |
| Total |  | $ | 20,809 |  |  | $ | 3,072 |  |  | $ | 66,337 |  |  | $ | 7,904 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2023-08-09):
[0001437749-23-022793:note_history:13]
The Company’s revenues in its Grid business segment are derived primarily through enabling the transmission and distribution of power, providing planning services that allow it to identify power grid needs and risks, and developing ship protection systems for the U.S. Navy. The Company’s revenues in its Wind business segment are derived primarily through supplying advanced power electronics and control systems, licensing its highly engineered wind turbine designs, and providing extensive customer support services to wind turbine manufacturers. The Company records revenue based on a five-step model in accordance with ASC 606. For its customer contracts, the Company identifies the performance obligations, determines the transaction price, allocates the contract transaction price to the performance obligations, and recognizes the revenue when (or as) control of goods or services is transferred to the customer. In the three months ended  June 30, 2023, and 2022, 76% and 70% of revenue, respectively, was recognized at the point in time when control transferred to the customer, with the remainder being recognized over time.
  (was, 2023-02-01, similarity 0.8932):
[0001437749-23-002270:note_history:13]
The Company’s revenues in its Grid business segment are derived primarily through enabling the transmission and distribution of power, providing planning services that allow it to identify power grid needs and risks, and developing ship protection systems for the U.S. Navy. The Company’s revenues in its Wind business segment are derived primarily through supplying advanced power electronics and control systems, licensing its highly engineered wind turbine designs, and providing extensive customer support services to wind turbine manufacturers. The Company records revenue based on a five-step model in accordance with ASC 606. For its customer contracts, the Company identifies the performance obligations, determines the transaction price, allocates the contract transaction price to the performance obligations, and recognizes the revenue when (or as) control of goods or services is transferred to the customer. In the three and nine months ended  December 31, 2022, 87% and 80% of revenue, respectively, was recognized at the point in time when control transferred to the customer, with the remainder being recognized over time. In the three and nine months ended  December 31, 2021, 79% and 76% of revenue, respectively, was recognized at the point in time when control transferred to the customer, with the remainder being recognized over time.

- changed (2023-08-09):
[0001437749-23-022793:note_history:14]
The Company's equipment and system product line includes certain contracts which do not meet the requirements of an exchange transaction and therefore do not fall within the scope of ASC 606.  As these non-exchange transaction contracts are considered grant revenue and do not fall within any specific accounting literature, the Company follows guidance within ASC 606 by analogy to recognize grant revenue over time. The Company recorded no grant revenue in the three month periods ended  June 30, 2023, and 2022.
  (was, 2023-02-01, similarity 0.7582):
[0001437749-23-002270:note_history:14]
The Company's equipment and system product line includes certain contracts which do not meet the requirements of an exchange transaction and therefore do not fall within the scope of ASC 606.  As these non-exchange transaction contracts are considered grant revenue and do not fall within any specific accounting literature, the Company follows guidance within ASC 606 by analogy to recognize grant revenue over time. The Company recorded no grant revenue in each of the three and nine months ended  December 31, 2022. In the three and nine months ended  December 31, 2021, the Company recorded $0.1 million and $0.9 million in grant revenue, respectively, which is included in the Company’s Grid business segment revenue.

- added (2023-08-09):
[0001437749-23-022793:note_history:15]
In the Company's service and technology development product line, there are several different types of transactions, and each begins with a contract with a customer that summarizes each product sold to a customer, which typically represents distinct performance obligations. The technology development transactions are primarily for activities that have no alternative use and for which a profit can be expected throughout the life of the contract. In these cases, the revenue is recognized over time, but in the instances where the profit cannot be assured throughout the entire contract then the revenue is recognized at a point in time. Each contract's transaction price is allocated to each distinct performance obligation using the respective standalone selling price which is determined primarily using the cost-plus expected margin approach. The ongoing service transactions are for service contracts that provide benefit to the customer simultaneously as the Company performs its obligations, and therefore this revenue is recognized ratably over time throughout the effective period of these contracts. The transaction prices on these contracts are allocated based on an adjusted market approach which is re-assessed annually for reasonableness. The field service transactions include contracts for delivery of goods and completion of services made at the customer's requests, which are not deemed satisfied until the work has been completed and/or the requested goods have been delivered, so all of this revenue is recognized at the point in time when the control changes, and at allocated prices based on the adjusted market approach driven by standard price lists. The royalty transactions are related to certain contract terms on transactions in the Company's equipment and systems product line based on activity as specified in the contracts. The transaction prices of these agreements are calculated based on an adjusted market approach as specified in the contract. The Company reports royalty revenue for usage-based royalties when the sales have occurred. In circumstances when collectability is not assured and a contract does not exist under ASC 606, revenue is deferred until a non-refundable payment has been received for substantially all the amount that is due and there are no further remaining performance obligations.

- changed (2023-08-09):
[0001437749-23-022793:note_history:16]
The Company monitors costs to meet its obligations on its customer contracts. When it is evident that there is a loss expected on a contract, a contract loss is accrued in the period. Several long-term contracts that were acquired from Neeltran, Inc. (“Neeltran”) were impacted by higher than planned costs due to required design changes and inflation on material costs, resulting in an increase to the contract loss accrual of $0.1 million and $0.2 million in the three month periods ended  June 30, 2023 and 2022, respectively, which negatively impacted the Company's gross margins.
  (was, 2023-02-01, similarity 0.9003):
[0001437749-23-002270:note_history:16]
The Company monitors costs to meet our obligations on our customer contracts. When it is evident that there is a loss expected on a contract, a contract loss is accrued in the period. Several long-term contracts that were acquired from Neeltran were impacted by higher than planned costs due to required design changes and inflation on material costs, resulting in an increase to the contract loss accrual of $1.6 million and $3.2 million in the three and nine month period ended  December 31, 2022 which negatively impacted the Company's gross margins.

- changed (2023-08-09):
[0001437749-23-022793:note_history:17]
|  |  | Three Months Ended June 30, 2023 |  |
| Product Line: |  | Grid |  |  | Wind |  |
| Equipment and systems |  | $ | 23,126 |  |  | $ | 3,982 |  |
| Services and technology development |  |  | 2,611 |  |  |  | 535 |  |
| Total |  | $ | 25,737 |  |  | $ | 4,517 |  |
| Region: |  |  |  |  |  |  |  |  |
| Americas |  | $ | 23,161 |  |  | $ | - |  |
| Asia Pacific |  |  | 1,711 |  |  |  | 4,465 |  |
| EMEA |  |  | 865 |  |  |  | 52 |  |
| Total |  | $ | 25,737 |  |  | $ | 4,517 |  |
  (was, 2023-02-01, similarity 0.6614):
[0001437749-23-002270:note_history:17]
|  |  | Three Months Ended December 31, 2021 |  |  | Nine Months Ended December 31, 2021 |  |
| Product Line: |  | Grid |  |  | Wind |  |  | Grid |  |  | Wind |  |
| Equipment and systems |  | $ | 23,416 |  |  | $ | 1,309 |  |  | $ | 67,605 |  |  | $ | 4,168 |  |
| Services and technology development |  |  | 1,634 |  |  |  | 440 |  |  |  | 5,564 |  |  |  | 2,789 |  |
| Total |  | $ | 25,050 |  |  | $ | 1,749 |  |  | $ | 73,169 |  |  | $ | 6,957 |  |
| Region: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas |  | $ | 16,739 |  |  | $ | 56 |  |  | $ | 57,498 |  |  | $ | 134 |  |
| Asia Pacific |  |  | 7,064 |  |  |  | 1,690 |  |  |  | 10,931 |  |  |  | 6,781 |  |
| EMEA |  |  | 1,247 |  |  |  | 3 |  |  |  | 4,740 |  |  |  | 42 |  |
| Total |  | $ | 25,050 |  |  | $ | 1,749 |  |  | $ | 73,169 |  |  | $ | 6,957 |  |

- added (2023-08-09):
[0001437749-23-022793:note_history:18]
|  |  | Three Months Ended June 30, 2022 |  |
| Product Line: |  | Grid |  |  | Wind |  |
| Equipment and systems |  | $ | 18,076 |  |  | $ | 1,973 |  |
| Services and technology development |  |  | 1,753 |  |  |  | 877 |  |
| Total |  | $ | 19,829 |  |  | $ | 2,850 |  |
| Region: |  |  |  |  |  |  |  |  |
| Americas |  | $ | 16,902 |  |  | $ | - |  |
| Asia Pacific |  |  | 2,677 |  |  |  | 2,850 |  |
| EMEA |  |  | 250 |  |  |  | - |  |
| Total |  | $ | 19,829 |  |  | $ | 2,850 |  |

- changed (2023-08-09):
[0001437749-23-022793:note_history:19]
As of  June 30, 2023, and 2022, the Company’s contract assets and liabilities primarily relate to the timing differences between cash received from a customer in connection with contractual rights to invoicing and the timing of revenue recognition following completion of performance obligations. The Company's accounts receivable balance is made up entirely of customer contract related balances. Changes in the Company’s contract assets, which are included in “Unbilled accounts receivable” and “Deferred program costs” (see Note 7, “Accounts Receivable” and Note 8, “Inventory” for a reconciliation to the condensed consolidated balance sheets) and "Contract liabilities", which are included in the current portion and long-term portion of "Deferred revenue" in the Company’s condensed consolidated balance sheets, are as follows (in thousands):
  (was, 2023-02-01, similarity 0.9928):
[0001437749-23-002270:note_history:19]
As of  December 31, 2022, and 2021, the Company’s contract assets and liabilities primarily relate to the timing differences between cash received from a customer in connection with contractual rights to invoicing and the timing of revenue recognition following completion of performance obligations. The Company's accounts receivable balance is made up entirely of customer contract related balances. Changes in the Company’s contract assets, which are included in “Unbilled accounts receivable” and “Deferred program costs” (see Note 8, “Accounts Receivable” and Note 9, “Inventory” for a reconciliation to the condensed consolidated balance sheets) and "Contract liabilities", which are included in the current portion and long-term portion of "Deferred revenue" in the Company’s condensed consolidated balance sheets, are as follows (in thousands):

- changed (2023-08-09):
[0001437749-23-022793:note_history:20]
|  |  | Unbilled Accounts Receivable |  |  | Deferred Program Costs |  |  | Contract Liabilities |  |
| Beginning balance as of March 31, 2023 |  | $ | 9,958 |  |  | $ | 2,136 |  |  | $ | 50,760 |  |
| Increases for costs incurred to fulfill performance obligations |  |  | — |  |  |  | 1,084 |  |  |  | — |  |
| Increase (decrease) due to customer billings |  |  | (9,479 | ) |  |  | — |  |  |  | 16,308 |  |
| Decrease due to cost recognition on completed performance obligations |  |  | — |  |  |  | (1,234 | ) |  |  | — |  |
| Increase (decrease) due to recognition of revenue based on transfer of control of performance obligations |  |  | 5,092 |  |  |  | — |  |  |  | (8,974 | ) |
| Other changes and FX impact |  |  | 1 |  |  |  | — |  |  |  | (11 | ) |
| Ending balance as of June 30, 2023 |  | $ | 5,572 |  |  | $ | 1,986 |  |  | $ | 58,083 |  |
  (was, 2023-02-01, similarity 0.9477):
[0001437749-23-002270:note_history:20]
|  |  | Unbilled Accounts Receivable |  |  | Deferred Program Costs |  |  | Contract Liabilities |  |
| Beginning balance as of March 31, 2022 |  | $ | 6,492 |  |  | $ | 858 |  |  | $ | 30,034 |  |
| Increases for costs incurred to fulfill performance obligations |  |  | — |  |  |  | 909 |  |  |  | — |  |
| Increase (decrease) due to customer billings |  |  | (11,723 | ) |  |  | — |  |  |  | 48,013 |  |
| Decrease due to cost recognition on completed performance obligations |  |  | — |  |  |  | (791 | ) |  |  | — |  |
| Increase (decrease) due to recognition of revenue based on transfer of control of performance obligations |  |  | 9,544 |  |  |  | — |  |  |  | (36,452 | ) |
| Other changes and FX impact |  |  | — |  |  |  | (15 | ) |  |  | (180 | ) |
| Ending balance as of December 31, 2022 |  | $ | 4,313 |  |  | $ | 961 |  |  | $ | 41,415 |  |

- changed (2023-08-09):
[0001437749-23-022793:note_history:21]
|  |  | Unbilled Accounts Receivable |  |  | Deferred Program Costs |  |  | Contract Liabilities |  |
| Beginning balance as of March 31, 2022 |  | $ | 6,492 |  |  | $ | 858 |  |  | $ | 30,034 |  |
| Increases for costs incurred to fulfill performance obligations |  |  | — |  |  |  | 406 |  |  |  | — |  |
| Increase (decrease) due to customer billings |  |  | (4,710 | ) |  |  | — |  |  |  | 17,852 |  |
| Decrease due to cost recognition on completed performance obligations |  |  | — |  |  |  | (365 | ) |  |  | — |  |
| Increase (decrease) due to recognition of revenue based on transfer of control of performance obligations |  |  | 2,128 |  |  |  | — |  |  |  | (13,737 | ) |
| Other changes and FX impact |  |  | — |  |  |  | (25 | ) |  |  | (394 | ) |
| Ending balance as of June 30, 2022 |  | $ | 3,910 |  |  | $ | 874 |  |  | $ | 33,755 |  |
  (was, 2023-02-01, similarity 0.9109):
[0001437749-23-002270:note_history:21]
|  |  | Unbilled Accounts Receivable |  |  | Deferred Program Costs |  |  | Contract Liabilities |  |
| Beginning balance as of March 31, 2021 |  | $ | 5,765 |  |  | $ | 977 |  |  | $ | 21,257 |  |
| Increases for costs incurred to fulfill performance obligations |  |  | — |  |  |  | 3,140 |  |  |  | — |  |
| Increase for balance acquired |  |  | — |  |  |  | 634 |  |  |  | 10,048 |  |
| Increase (decrease) due to customer billings |  |  | (11,214 | ) |  |  | — |  |  |  | 55,354 |  |
| Decrease due to cost recognition on completed performance obligations |  |  | — |  |  |  | (4,128 | ) |  |  | — |  |
| Increase (decrease) due to recognition of revenue based on transfer of control of performance obligations |  |  | 12,186 |  |  |  | — |  |  |  | (55,318 | ) |
| Other changes and FX impact |  |  | — |  |  |  | (8 | ) |  |  | 137 |  |
| Ending balance as of December 31, 2021 |  | $ | 6,737 |  |  | $ | 615 |  |  | $ | 31,478 |  |

- changed (2023-08-09):
[0001437749-23-022793:note_history:22]
The Company’s remaining performance obligations represent the unrecognized revenue value of the Company’s contractual commitments. The Company’s performance obligations  may vary significantly each reporting period based on the timing of major new contractual commitments. As of  June 30, 2023, the Company had outstanding performance obligations on existing contracts under ASC 606 to be recognized in the next twelve months of approximately $123.3 million. There are also approximately $41.5 million of outstanding performance obligations to be recognized over a period of thirteen to sixty months. The remaining performance obligations are subject to customer actions and therefore the timing of revenue recognition cannot be reasonably estimated.
  (was, 2023-02-01, similarity 0.7204):
[0001437749-23-002270:note_history:22]
The Company’s remaining performance obligations represent the unrecognized revenue value of the Company’s contractual commitments. The Company’s performance obligations  may vary significantly each reporting period based on the timing of major new contractual commitments. As of  December 31, 2022, the Company had outstanding performance obligations on existing contracts under ASC 606 to be recognized in the next twelve months of approximately $112.1 million. There are also approximately $30.4 million of outstanding performance obligations to be recognized over a period of thirteen to sixty months. The remaining performance obligations are subject to customer actions and therefore the timing of revenue recognition cannot be reasonably estimated. The twelve-month performance obligations include anticipated shipments to Inox based on the twelve-month rolling forecast provided by Inox on the multi-year supply contract. The quantities specified in any forecast provided by Inox related to the multi-year supply contract are firm and irrevocable for the first three months of a twelve-month rolling forecast. The timing of the performance obligations beyond the twelve-month forecast provided by Inox are not determinable and therefore are not included in the total remaining performance obligations.

- changed (2023-08-09):
[0001437749-23-022793:note_history:23]
The following table sets forth customers who represented 10% or more of the Company’s total revenues for the three months ended  June 30, 2023 and 2022:
  (was, 2023-02-01, similarity 0.936):
[0001437749-23-002270:note_history:23]
The following table sets forth customers who represented 10% or more of the Company’s total revenues for the three and nine months ended  December 31, 2022 and 2021:

- added (2023-08-09):
[0001437749-23-022793:note_history:24]
|  |  |  | Three Months Ended |  |
|  | Reportable |  | June 30, |  |
|  | Segment |  | 2023 |  |  | 2022 |  |
| Inox Wind Limited | Wind |  |  | 12 | % |  | <10% |  |
| SGL Carbon LLC | Grid |  | <10% |  |  |  | 10 | % |

- removed (2023-08-09):
[0001437749-23-002270:note_history:25]
In the Company's service and technology development product line, there are several different types of transactions and each begins with a contract with a customer that summarizes each product sold to a customer, which typically represent distinct performance obligations. The technology development transactions are primarily for activities that have no alternative use and for which a profit can be expected throughout the life of the contract. In these cases, the revenue is recognized over time, but in the instances where a reasonable profit margin cannot be assured throughout the entire contract, the revenue is recognized at a point in time. Each contract's transaction price is allocated to each distinct performance obligation using the respective standalone selling price which is determined primarily using the cost-plus expected margin approach. The ongoing service transactions are for service contracts that provide benefit to the customer simultaneously as the Company performs its obligations, and therefore this revenue is recognized ratably over time throughout the effective period of these contracts. The transaction prices on these contracts are allocated based on an adjusted market approach which is reassessed annually for reasonableness. The field service transactions include contracts for delivery of goods and completion of services made at the customer's requests, which are not deemed satisfied until the work has been completed and/or the requested goods have been delivered, so all of this revenue is recognized at the point in time when the control changes, and at allocated prices based on the adjusted market approach driven by standard price lists. The royalty transactions are related to certain contract terms on transactions in the Company's equipment and systems product line based on activity as specified in the contracts. The transaction prices of these agreements are calculated based on an adjusted market approach as specified in the contract. The Company reports royalty revenue for usage-based royalties when the sales have occurred. In circumstances when collectability is not assured and a contract does not exist under ASC 606, revenue is deferred until a non-refundable payment has been received for substantially all the amount that is due and there are no further remaining performance obligations.

- removed (2023-08-09):
[0001437749-23-002270:note_history:26]
|  |  | Three Months Ended December 31, 2022 |  |  | Nine Months Ended December 31, 2022 |  |
| Product Line: |  | Grid |  |  | Wind |  |  | Grid |  |  | Wind |  |
| Equipment and systems |  | $ | 19,475 |  |  | $ | 2,842 |  |  | $ | 61,680 |  |  | $ | 6,144 |  |
| Services and technology development |  |  | 1,334 |  |  |  | 230 |  |  |  | 4,657 |  |  |  | 1,760 |  |
| Total |  | $ | 20,809 |  |  | $ | 3,072 |  |  | $ | 66,337 |  |  | $ | 7,904 |  |
| Region: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas |  | $ | 17,010 |  |  |  | 19 |  |  | $ | 51,934 |  |  | $ | 19 |  |
| Asia Pacific |  |  | 1,760 |  |  |  | 3,053 |  |  |  | 10,615 |  |  |  | 7,815 |  |
| EMEA |  |  | 2,039 |  |  |  | - |  |  |  | 3,788 |  |  |  | 70 |  |
| Total |  | $ | 20,809 |  |  | $ | 3,072 |  |  | $ | 66,337 |  |  | $ | 7,904 |  |

- removed (2023-08-09):
[0001437749-23-002270:note_history:27]
|  |  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  | Reportable |  | December 31, |  |  | December 31, |  |
|  | Segment |  | 2022 |  |  | 2021 |  |  | 2022 |  |  | 2021 |  |
| Inox Wind Limited | Wind |  |  | 11 | % |  | <10% |  |  | <10% |  |  | <10% |  |
| Fuji Bridex Pte Ltd | Grid |  | <10% |  |  |  | 20 | % |  |  | 10 | % |  |  | 10 | % |
