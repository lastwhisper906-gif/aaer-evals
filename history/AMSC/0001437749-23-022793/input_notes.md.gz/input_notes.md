# AMSC notes — 0001437749-23-022793


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0001437749-23-022793:notes:1]
[same as prior period, unchanged from 0001437749-23-002270:notes:1]

[0001437749-23-022793:notes:2]
[same as prior period, unchanged from 0001437749-23-002270:notes:2]

[0001437749-23-022793:notes:3]
[same as prior period, unchanged from 0001437749-23-002270:notes:3]

[0001437749-23-022793:notes:4]
These unaudited condensed consolidated financial statements of the Company have been prepared on a going concern basis in accordance with United States generally accepted accounting principles (“GAAP”) and the Securities and Exchange Commission’s (“SEC”) instructions to Form 10-Q. The going concern basis of presentation assumes that the Company will continue operations and will be able to realize its assets and discharge its liabilities and commitments in the normal course of business. Certain information and footnote disclosures normally included in the financial statements prepared in accordance with GAAP have been condensed or omitted pursuant to those instructions. The year-end condensed balance sheet data was derived from audited financial statements but does not include all disclosures required by GAAP. The unaudited condensed consolidated financial statements, in the opinion of management, reflect all adjustments (consisting of normal recurring adjustments) necessary for a fair statement of the results for the interim periods ended  June 30, 2023 and 2022 and the financial position at  June 30, 2023; however, these results are not necessarily indicative of results which  may be expected for the full year. The interim condensed consolidated financial statements, and notes thereto, should be read in conjunction with the audited condensed consolidated financial statements for the year ended  March 31, 2023, and notes thereto, included in the Company’s Annual Report on Form 10-K for the year ended  March 31, 2023 filed with the SEC on  May 31, 2023.

[0001437749-23-022793:notes:5]
[same as prior period, unchanged from 0001437749-23-002270:notes:5]

[0001437749-23-022793:notes:6]
The Company has historically experienced recurring operating losses and as of  June 30, 2023, the Company had an accumulated deficit of $1,061 million. In addition, the Company has historically experienced recurring negative operating cash flows. At  June 30, 2023, the Company had cash and cash equivalents of $22.0 million. Cash used in operations for the three months ended  June 30, 2023 was $2.2 million.

[0001437749-23-022793:notes:7]
[same as prior period, unchanged from 0001437749-23-002270:notes:7]

[0001437749-23-022793:notes:8]
The Company continues to experience inflationary pressure in its supply chain and some delays in sourcing materials needed for its products resulting in some production disruption, both of which have increased the Company’s cost of revenues and decreased gross margin. While the impact of inflation has been challenging, the Company continues to take actions to limit this pressure, including adjusting the pricing of its products and services. Changes in macroeconomic conditions arising from the COVID-19 pandemic or for other reasons, such as the ongoing war between Russia and Ukraine, inflation, rising interest rates, labor force availability, sourcing, material delays and global supply chain disruptions could have a material adverse effect on the Company’s business, financial condition and results of operation.

[0001437749-23-022793:notes:9]
From time-to-time the Company  may undertake restructuring activities in order to align the global organization in a manner that the Company believes will better position it to achieve its long-term goals. In  January 2023, the Company undertook a reduction in force that involved approximately 5% of the global workforce. This restructuring is expected to incur $1.0 million of cash expenses, $0.7 million of which has been paid as of  June 30, 2023, and to result in annualized cost savings of approximately $5.0 million, beginning in fiscal 2023.

[0001437749-23-022793:notes:10]
The Company believes that based on the information presented above and its quarterly management assessment, it has sufficient liquidity to fund its operations and capital expenditures for the next twelve months following the issuance of the financial statements for the three months ended  June 30, 2023. The Company’s liquidity is highly dependent on its ability to increase revenues, its ability to control its operating costs, and its ability to raise additional capital, if necessary. The impact of the COVID-19 pandemic and other sources of instability, including the war between Russia and Ukraine, on the global financing markets  may reduce the Company's ability to raise additional capital, if necessary, which could negatively impact the Company's liquidity.  There can be no assurance that the Company will be able to continue to raise additional capital, on favorable terms or at all, from other sources or execute on any other means of improving liquidity described above.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001437749-23-022793:notes:11]
2. Revenue Recognition

[0001437749-23-022793:notes:12]
The Company’s revenues in its Grid business segment are derived primarily through enabling the transmission and distribution of power, providing planning services that allow it to identify power grid needs and risks, and developing ship protection systems for the U.S. Navy. The Company’s revenues in its Wind business segment are derived primarily through supplying advanced power electronics and control systems, licensing its highly engineered wind turbine designs, and providing extensive customer support services to wind turbine manufacturers. The Company records revenue based on a five-step model in accordance with ASC 606. For its customer contracts, the Company identifies the performance obligations, determines the transaction price, allocates the contract transaction price to the performance obligations, and recognizes the revenue when (or as) control of goods or services is transferred to the customer. In the three months ended  June 30, 2023, and 2022, 76% and 70% of revenue, respectively, was recognized at the point in time when control transferred to the customer, with the remainder being recognized over time.

[0001437749-23-022793:notes:13]
[same as prior period, unchanged from 0001437749-23-002270:notes:46]

[0001437749-23-022793:notes:14]
The Company's equipment and system product line includes certain contracts which do not meet the requirements of an exchange transaction and therefore do not fall within the scope of ASC 606.  As these non-exchange transaction contracts are considered grant revenue and do not fall within any specific accounting literature, the Company follows guidance within ASC 606 by analogy to recognize grant revenue over time. The Company recorded no grant revenue in the three month periods ended  June 30, 2023, and 2022.

[0001437749-23-022793:notes:15]
In the Company's service and technology development product line, there are several different types of transactions, and each begins with a contract with a customer that summarizes each product sold to a customer, which typically represents distinct performance obligations. The technology development transactions are primarily for activities that have no alternative use and for which a profit can be expected throughout the life of the contract. In these cases, the revenue is recognized over time, but in the instances where the profit cannot be assured throughout the entire contract then the revenue is recognized at a point in time. Each contract's transaction price is allocated to each distinct performance obligation using the respective standalone selling price which is determined primarily using the cost-plus expected margin approach. The ongoing service transactions are for service contracts that provide benefit to the customer simultaneously as the Company performs its obligations, and therefore this revenue is recognized ratably over time throughout the effective period of these contracts. The transaction prices on these contracts are allocated based on an adjusted market approach which is re-assessed annually for reasonableness. The field service transactions include contracts for delivery of goods and completion of services made at the customer's requests, which are not deemed satisfied until the work has been completed and/or the requested goods have been delivered, so all of this revenue is recognized at the point in time when the control changes, and at allocated prices based on the adjusted market approach driven by standard price lists. The royalty transactions are related to certain contract terms on transactions in the Company's equipment and systems product line based on activity as specified in the contracts. The transaction prices of these agreements are calculated based on an adjusted market approach as specified in the contract. The Company reports royalty revenue for usage-based royalties when the sales have occurred. In circumstances when collectability is not assured and a contract does not exist under ASC 606, revenue is deferred until a non-refundable payment has been received for substantially all the amount that is due and there are no further remaining performance obligations.

[0001437749-23-022793:notes:16]
[same as prior period, unchanged from 0001437749-23-002270:notes:49]

[0001437749-23-022793:notes:17]
[same as prior period, unchanged from 0001437749-23-002270:notes:50]

[0001437749-23-022793:notes:18]
[same as prior period, unchanged from 0001437749-23-002270:notes:51]

[0001437749-23-022793:notes:19]
[same as prior period, unchanged from 0001437749-23-002270:notes:52]

[0001437749-23-022793:notes:20]
The Company monitors costs to meet its obligations on its customer contracts. When it is evident that there is a loss expected on a contract, a contract loss is accrued in the period. Several long-term contracts that were acquired from Neeltran, Inc. (“Neeltran”) were impacted by higher than planned costs due to required design changes and inflation on material costs, resulting in an increase to the contract loss accrual of $0.1 million and $0.2 million in the three month periods ended  June 30, 2023 and 2022, respectively, which negatively impacted the Company's gross margins.

[0001437749-23-022793:notes:21]
[same as prior period, unchanged from 0001437749-23-002270:notes:54]

[0001437749-23-022793:notes:22]
[same as prior period, unchanged from 0001437749-23-002270:notes:55]

[0001437749-23-022793:notes:23]
|  |  | Three Months Ended June 30, 2023 |  |
| Product Line: |  | Grid |  |  | Wind |  |
| Equipment and systems |  | $ | 23,126 |  |  | $ | 3,982 |  |
| Services and technology development |  |  | 2,611 |  |  |  | 535 |  |
| Total |  | $ | 25,737 |  |  | $ | 4,517 |  |
| Region: |  |  |  |  |  |  |  |  |
| Americas |  | $ | 23,161 |  |  | $ | - |  |
| Asia Pacific |  |  | 1,711 |  |  |  | 4,465 |  |
| EMEA |  |  | 865 |  |  |  | 52 |  |
| Total |  | $ | 25,737 |  |  | $ | 4,517 |  |

[0001437749-23-022793:notes:24]
|  |  | Three Months Ended June 30, 2022 |  |
| Product Line: |  | Grid |  |  | Wind |  |
| Equipment and systems |  | $ | 18,076 |  |  | $ | 1,973 |  |
| Services and technology development |  |  | 1,753 |  |  |  | 877 |  |
| Total |  | $ | 19,829 |  |  | $ | 2,850 |  |
| Region: |  |  |  |  |  |  |  |  |
| Americas |  | $ | 16,902 |  |  | $ | - |  |
| Asia Pacific |  |  | 2,677 |  |  |  | 2,850 |  |
| EMEA |  |  | 250 |  |  |  | - |  |
| Total |  | $ | 19,829 |  |  | $ | 2,850 |  |

[0001437749-23-022793:notes:25]
As of  June 30, 2023, and 2022, the Company’s contract assets and liabilities primarily relate to the timing differences between cash received from a customer in connection with contractual rights to invoicing and the timing of revenue recognition following completion of performance obligations. The Company's accounts receivable balance is made up entirely of customer contract related balances. Changes in the Company’s contract assets, which are included in “Unbilled accounts receivable” and “Deferred program costs” (see Note 7, “Accounts Receivable” and Note 8, “Inventory” for a reconciliation to the condensed consolidated balance sheets) and "Contract liabilities", which are included in the current portion and long-term portion of "Deferred revenue" in the Company’s condensed consolidated balance sheets, are as follows (in thousands):

[0001437749-23-022793:notes:26]
|  |  | Unbilled Accounts Receivable |  |  | Deferred Program Costs |  |  | Contract Liabilities |  |
| Beginning balance as of March 31, 2023 |  | $ | 9,958 |  |  | $ | 2,136 |  |  | $ | 50,760 |  |
| Increases for costs incurred to fulfill performance obligations |  |  | — |  |  |  | 1,084 |  |  |  | — |  |
| Increase (decrease) due to customer billings |  |  | (9,479 | ) |  |  | — |  |  |  | 16,308 |  |
| Decrease due to cost recognition on completed performance obligations |  |  | — |  |  |  | (1,234 | ) |  |  | — |  |
| Increase (decrease) due to recognition of revenue based on transfer of control of performance obligations |  |  | 5,092 |  |  |  | — |  |  |  | (8,974 | ) |
| Other changes and FX impact |  |  | 1 |  |  |  | — |  |  |  | (11 | ) |
| Ending balance as of June 30, 2023 |  | $ | 5,572 |  |  | $ | 1,986 |  |  | $ | 58,083 |  |

[0001437749-23-022793:notes:27]
|  |  | Unbilled Accounts Receivable |  |  | Deferred Program Costs |  |  | Contract Liabilities |  |
| Beginning balance as of March 31, 2022 |  | $ | 6,492 |  |  | $ | 858 |  |  | $ | 30,034 |  |
| Increases for costs incurred to fulfill performance obligations |  |  | — |  |  |  | 406 |  |  |  | — |  |
| Increase (decrease) due to customer billings |  |  | (4,710 | ) |  |  | — |  |  |  | 17,852 |  |
| Decrease due to cost recognition on completed performance obligations |  |  | — |  |  |  | (365 | ) |  |  | — |  |
| Increase (decrease) due to recognition of revenue based on transfer of control of performance obligations |  |  | 2,128 |  |  |  | — |  |  |  | (13,737 | ) |
| Other changes and FX impact |  |  | — |  |  |  | (25 | ) |  |  | (394 | ) |
| Ending balance as of June 30, 2022 |  | $ | 3,910 |  |  | $ | 874 |  |  | $ | 33,755 |  |

[0001437749-23-022793:notes:28]
The Company’s remaining performance obligations represent the unrecognized revenue value of the Company’s contractual commitments. The Company’s performance obligations  may vary significantly each reporting period based on the timing of major new contractual commitments. As of  June 30, 2023, the Company had outstanding performance obligations on existing contracts under ASC 606 to be recognized in the next twelve months of approximately $123.3 million. There are also approximately $41.5 million of outstanding performance obligations to be recognized over a period of thirteen to sixty months. The remaining performance obligations are subject to customer actions and therefore the timing of revenue recognition cannot be reasonably estimated.

[0001437749-23-022793:notes:29]
The following table sets forth customers who represented 10% or more of the Company’s total revenues for the three months ended  June 30, 2023 and 2022:

[0001437749-23-022793:notes:30]
|  |  |  | Three Months Ended |  |
|  | Reportable |  | June 30, |  |
|  | Segment |  | 2023 |  |  | 2022 |  |
| Inox Wind Limited | Wind |  |  | 12 | % |  | <10% |  |
| SGL Carbon LLC | Grid |  | <10% |  |  |  | 10 | % |


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001437749-23-022793:notes:31]
3. Stock-Based Compensation

[0001437749-23-022793:notes:32]
The Company accounts for its stock-based compensation at fair value. The following table summarizes stock-based compensation expense by financial statement line item for the three months ended  June 30, 2023 and 2022 (in thousands):

[0001437749-23-022793:notes:33]
|  |  | Three Months Ended June 30, |  |
|  |  | 2023 |  |  | 2022 |  |
| Cost of revenues |  | $ | 109 |  |  | $ | 29 |  |
| Research and development |  |  | 156 |  |  |  | 179 |  |
| Selling, general and administrative |  |  | 1,092 |  |  |  | 825 |  |
| Total |  | $ | 1,357 |  |  | $ | 1,033 |  |

[0001437749-23-022793:notes:34]
The Company issued 672,500 shares of restricted stock and 53,675 shares of immediately vested common stock during the three months ended  June 30, 2023. The Company issued 25,806 shares of immediately vested common stock during the three months ended  June 30, 2022. These restricted stock awards generally vest over 2-3 years.  Awards for restricted stock include both time-based and performance-based awards.  For options and restricted stock awards that vest upon the passage of time, expense is being recorded over the vesting period.  Performance-based awards are expensed over the requisite service period based on probability of achievement.

[0001437749-23-022793:notes:35]
The estimated fair value of the Company’s stock-based awards, less expected annual forfeitures, is amortized over the awards’ service period. The total unrecognized compensation cost for unvested stock options was less than $0.1 million at  June 30, 2023.  This expense will be recognized over a weighted average of approximately 0.9 years. The total unrecognized compensation cost for unvested outstanding restricted stock was $7.7 million at  June 30, 2023. This expense will be recognized over a weighted-average expense period of approximately 2.2 years.

[0001437749-23-022793:notes:36]
The Company granted no stock options during the three months ended  June 30, 2023. The Company granted 20,564 stock options during the three months ended  June 30, 2022.  The stock options granted during the three months ended  June 30, 2022, will vest over 2 years. The weighted average assumptions used in the Black Scholes valuation model for stock options granted during the three months ended  June 30, 2022 are as follows:

[0001437749-23-022793:notes:37]
| Expected volatility |  |  | 71.40 | % |
| Risk-free interest rate |  |  | 3.10 | % |
| Expected life (years) |  |  | 6.14 |  |
| Dividend yield |  | None |  |


## us-gaap:EarningsPerShareTextBlock

[0001437749-23-022793:notes:38]
4. Computation of Net Loss per Common Share

[0001437749-23-022793:notes:39]
Basic net loss per share (“EPS”) is computed by dividing net loss by the weighted-average number of common shares outstanding for the period. Where applicable, diluted EPS is computed by dividing the net loss by the weighted-average number of common shares and dilutive common equivalent shares outstanding during the period, calculated using the treasury stock method. Common equivalent shares include the effect of restricted stock, exercise of stock options and warrants and contingently issuable shares. Stock options and warrants that are out-of-the-money with exercise prices greater than the average market price of the underlying common shares and shares of performance-based restricted stock where the contingency was not met are excluded from the computation of diluted EPS as the effect of their inclusion would be anti-dilutive.  For each of the three months ended  June 30, 2023, and 2022, 1.1 million shares were not included in the calculation of diluted EPS. Of these, 1.0 million relate to shares tied to the derivative liability for which the contingency has not yet been met, and 0.1 million relate to outstanding stock options as they were considered anti-dilutive.

[0001437749-23-022793:notes:40]
The following table reconciles the numerators and denominators of the earnings per share calculation for the three months ended  June 30, 2023 and 2022 (in thousands, except per share data):

[0001437749-23-022793:notes:41]
|  |  | Three Months Ended June 30, |  |
|  |  | 2023 |  |  | 2022 |  |
| Numerator: |  |  |  |  |  |  |  |  |
| Net loss |  | $ | (5,398 | ) |  | $ | (8,710 | ) |
| Denominator: |  |  |  |  |  |  |  |  |
| Weighted-average shares of common stock outstanding |  |  | 29,706 |  |  |  | 28,520 |  |
| Weighted-average shares subject to repurchase |  |  | (1,448 | ) |  |  | (960 | ) |
| Shares used in per-share calculation ― basic |  |  | 28,258 |  |  |  | 27,560 |  |
| Shares used in per-share calculation ― diluted |  |  | 28,258 |  |  |  | 27,560 |  |
| Net loss per share ― basic |  | $ | (0.19 | ) |  | $ | (0.32 | ) |
| Net loss per share ― diluted |  | $ | (0.19 | ) |  | $ | (0.32 | ) |


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001437749-23-022793:notes:42]
5. Goodwill and Other Intangibles

[0001437749-23-022793:notes:43]
[same as prior period, unchanged from 0001437749-23-002270:notes:76]

[0001437749-23-022793:notes:44]
Goodwill represents the difference between the purchase price and the fair value of the identifiable tangible and intangible net assets when accounted for using the purchase method of accounting.  Goodwill is not amortized but reviewed for impairment. Goodwill is reviewed annually on  February 28th and whenever events or changes in circumstances indicate that the carrying value of the goodwill might not be recoverable.

[0001437749-23-022793:notes:45]
There were no changes to goodwill during the three months ended  June 30, 2023 or year ended  March 31, 2023.

[0001437749-23-022793:notes:46]
The Company did not identify any triggering events in the three months ended  June 30, 2023 that would require interim impairment testing of goodwill.

[0001437749-23-022793:notes:47]
[same as prior period, unchanged from 0001437749-23-002270:notes:81]

[0001437749-23-022793:notes:48]
Intangible assets at  June 30, 2023 and  March 31, 2023 consisted of the following (in thousands):

[0001437749-23-022793:notes:49]
|  |  | June 30, 2023 |  |  | March 31, 2023 |  |  |  |  |  |
|  |  | Gross Amount |  |  | Accumulated Amortization |  |  | Net Book Value |  |  | Gross Amount |  |  | Accumulated Amortization |  |  | Net Book Value |  |  | Estimated Useful Life |  |
| Licenses |  | $ | 3,610 |  |  | $ | (3,610 | ) |  | $ | — |  |  | $ | 3,610 |  |  | $ | (3,610 | ) |  | $ | — |  |  |  | 7 |  |
| Backlog |  |  | 681 |  |  |  | (681 | ) |  |  | — |  |  |  | 681 |  |  |  | (675 | ) |  | $ | 6 |  |  |  | 2 |  |
| Trade name and trademarks |  |  | 1,800 |  |  |  | — |  |  |  | 1,800 |  |  |  | 1,800 |  |  |  | — |  |  |  | 1,800 |  |  |  | Indefinite |  |
| Customer relationships |  |  | 9,600 |  |  |  | (5,397 | ) |  |  | 4,203 |  |  |  | 9,600 |  |  |  | (4,980 | ) |  |  | 4,620 |  |  |  | 7 |  |
| Core technology and know-how |  |  | 5,970 |  |  |  | (3,990 | ) |  |  | 1,980 |  |  |  | 5,970 |  |  |  | (3,869 | ) |  |  | 2,101 |  |  |  | 5-10 |  |
| Intangible assets |  | $ | 21,661 |  |  | $ | (13,678 | ) |  | $ | 7,983 |  |  | $ | 21,661 |  |  | $ | (13,134 | ) |  | $ | 8,527 |  |  |  |  |  |

[0001437749-23-022793:notes:50]
The Company recorded intangible amortization expense related to customer relationship and core technology and know-how of $0.5 million and $0.7 million, in the three months ended  June 30, 2023 and 2022 respectively. Additionally, the Company recorded intangible amortization related to backlog that is reported in cost of revenues of less than $0.1 million in each of the three months ended  June 30, 2023 and 2022.

[0001437749-23-022793:notes:51]
[same as prior period, unchanged from 0001437749-23-002270:notes:85]

[0001437749-23-022793:notes:52]
| Years ended March 31, |  | Total |  |
| 2024 |  |  | 1,614 |  |
| 2025 |  |  | 1,648 |  |
| 2026 |  |  | 1,221 |  |
| 2027 |  |  | 1,085 |  |
| 2028 |  |  | 543 |  |
| Thereafter |  |  | 72 |  |
| Total |  | $ | 6,183 |  |

[0001437749-23-022793:notes:53]
[same as prior period, unchanged from 0001437749-23-002270:notes:87]


## us-gaap:FairValueDisclosuresTextBlock

[0001437749-23-022793:notes:54]
6. Fair Value Measurements

[0001437749-23-022793:notes:55]
[same as prior period, unchanged from 0001437749-23-002270:notes:89]

[0001437749-23-022793:notes:56]
[same as prior period, unchanged from 0001437749-23-002270:notes:90]

[0001437749-23-022793:notes:57]
The Company provides a gross presentation of activity within Level 3 measurement roll-forward and details of transfers in and out of Level 1 and 2 measurements.  A change in the hierarchy of an investment from its current level is reflected in the period during which the pricing methodology of such investment changes.  Disclosure of the transfer of securities from Level 1 to Level 2 or Level 3 is made in the event that the related security is significant to total cash and investments.  The Company did not have any transfers of assets and liabilities from Level 1, Level 2 or Level 3 of the fair value measurement hierarchy during the three months ended  June 30, 2023.

[0001437749-23-022793:notes:58]
[same as prior period, unchanged from 0001437749-23-002270:notes:92]

[0001437749-23-022793:notes:59]
[same as prior period, unchanged from 0001437749-23-002270:notes:93]

[0001437749-23-022793:notes:60]
[same as prior period, unchanged from 0001437749-23-002270:notes:94]

[0001437749-23-022793:notes:61]
[same as prior period, unchanged from 0001437749-23-002270:notes:95]

[0001437749-23-022793:notes:62]
[same as prior period, unchanged from 0001437749-23-002270:notes:96]

[0001437749-23-022793:notes:63]
Contingent consideration relates to the earnout payment set forth in the Stock Purchase Agreement governing the acquisition of NEPSI that provides that the selling stockholders  may receive up to an additional 1,000,000 shares of common stock of the Company upon the achievement of certain specified revenue objectives over varying periods of up to four years following the NEPSI Acquisition Date. See Note 13, "Contingent Consideration" for further discussion. The Company relied on a Monte Carlo method to determine the fair value of the contingent consideration on the closing of the acquisition of NEPSI and continues to revalue the fair value of the contingent consideration using the same method at each subsequent balance sheet date until the contingencies are resolved and the shares to be issued are determined, with the change in fair value recorded in the current period operating loss.

[0001437749-23-022793:notes:64]
The following table provides the assets and liabilities carried at fair value on a recurring basis, measured as of  June 30, 2023 and  March 31, 2023 (in thousands):

[0001437749-23-022793:notes:65]
|  |  | Total Carrying Value |  |  | Quoted Prices in Active Markets (Level 1) |  |  | Significant Other Observable Inputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |
| June 30, 2023: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash equivalents |  | $ | 7,658 |  |  | $ | 7,658 |  |  | $ | — |  |  | $ | — |  |
| Derivative liabilities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Contingent consideration |  | $ | 2,620 |  |  | $ | — |  |  | $ | — |  |  | $ | 2,620 |  |

[0001437749-23-022793:notes:66]
|  |  | Total Carrying Value |  |  | Quoted Prices in Active Markets (Level 1) |  |  | Significant Other Observable Inputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |
| March 31, 2023: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash equivalents |  | $ | 7,913 |  |  | $ | 7,913 |  |  | $ | — |  |  | $ | — |  |
| Derivative liabilities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Contingent consideration |  | $ | 1,270 |  |  | $ | — |  |  | $ | — |  |  | $ | 1,270 |  |

[0001437749-23-022793:notes:67]
[same as prior period, unchanged from 0001437749-23-002270:notes:101]

[0001437749-23-022793:notes:68]
|  |  | Acquisition Contingent Consideration |  |
| Balance at March 31, 2022 |  | $ | 1,200 |  |
| Change in fair value |  |  | 70 |  |
| Balance at March 31, 2023 |  |  | 1,270 |  |
| Change in fair value |  |  | 1,350 |  |
| Balance at June 30, 2023 |  | $ | 2,620 |  |


## amsc:AccountsReceivableTextBlock

[0001437749-23-022793:notes:69]
7. Accounts Receivable

[0001437749-23-022793:notes:70]
Accounts receivable at  June 30, 2023 and  March 31, 2023 consisted of the following (in thousands):

[0001437749-23-022793:notes:71]
|  |  | June 30, 2023 |  |  | March 31, 2023 |  |
| Accounts receivable (billed) |  | $ | 24,544 |  |  | $ | 20,707 |  |
| Accounts receivable (unbilled) |  |  | 5,572 |  |  |  | 9,958 |  |
| Accounts receivable, net |  | $ | 30,116 |  |  | $ | 30,665 |  |


## us-gaap:InventoryDisclosureTextBlock

[0001437749-23-022793:notes:72]
8. Inventory

[0001437749-23-022793:notes:73]
Inventory, net of reserves, at  June 30, 2023 and  March 31, 2023 consisted of the following (in thousands):

[0001437749-23-022793:notes:74]
|  |  | June 30, 2023 |  |  | March 31, 2023 |  |
| Raw materials |  | $ | 19,141 |  |  | $ | 16,654 |  |
| Work-in-process |  |  | 17,294 |  |  |  | 15,200 |  |
| Finished goods |  |  | 4,453 |  |  |  | 2,996 |  |
| Deferred program costs |  |  | 1,986 |  |  |  | 2,136 |  |
| Net inventory |  | $ | 42,874 |  |  | $ | 36,986 |  |

[0001437749-23-022793:notes:75]
The Company recorded inventory write-downs of $0.4 million and $0.3 million for the three months ended  June 30, 2023 and 2022, respectively. These write-downs were based on the Company's evaluation of its inventory on hand for excess quantities and obsolescence.

[0001437749-23-022793:notes:76]
Deferred program costs as of  June 30, 2023 and  March 31, 2023, primarily represent costs incurred on programs where the Company needs to complete performance obligations before the related revenue and costs will be recognized.


## amsc:PrepaidAndOtherCurrentAssetsTextBlock

[0001437749-23-022793:notes:77]
9. Prepaid and Other Current Assets

[0001437749-23-022793:notes:78]
During fiscal 2022, the Company conducted an analysis as to whether it was entitled to employee retention credits (“ERC”) under the CARES Act as amended by the Taxpayer Certainty and Disaster Tax Relief Act of 2020 and the American Plan Act of 2021.  Based on the analysis, the Company determined that it was entitled to an ERC of approximately $3.3 million related to payroll taxes paid in the first and second quarters of 2021 and the first quarter of 2020.  The Company determined it met all the criteria required under the gross receipts test of the applicable Internal Revenue Service regulations related to ERCs.

[0001437749-23-022793:notes:79]
As accounting for payroll tax credits are not within the scope of ASC 740, Income Taxes, the Company has chosen to account for the ERCs by analogizing to the International Accounting Standards Board IAS 20, Accounting for Government Grants and Disclosure of Government Assistance.  In accordance with IAS 20, an entity recognizes government grants only when there is reasonable assurance that the entity will comply with the conditions attached to them and the grants will be received.  The  Company evaluated its eligibility for the ERC and determined that it met all the criteria to claim a refundable tax credit against the employer portion of Social Security taxes for up to 70% of the qualified wages the Company paid to  employees for the three month periods ended  March 31, 2021 and  June 30, 2021 and for up to 50%  of the qualified wages the Company paid to employees for the three month period ended  March 31, 2020.

[0001437749-23-022793:notes:80]
The Company recorded a $3.3 million receivable in Prepaid expenses and other current assets and a benefit of $1.8 million to Cost of revenues, $0.8 million to SG&A and $0.7 million to Research and development in the fiscal year ended  March 31, 2023 for the ERC that is expected to be received based on the amended filings.  During the three months ended  June 30, 2023, the Company received $2.2 million for the initial claims that were processed.  The remaining balance is expected to be received during fiscal 2023.


## us-gaap:PropertyPlantAndEquipmentDisclosureTextBlock

[0001437749-23-022793:notes:81]
[same as prior period, unchanged from 0001437749-23-002270:notes:111]

[0001437749-23-022793:notes:82]
The cost and accumulated depreciation of property, plant and equipment at  June 30, 2023 and  March 31, 2023 are as follows (in thousands):

[0001437749-23-022793:notes:83]
|  |  | June 30, 2023 |  |  | March 31, 2023 |  |
| Land |  | $ | 980 |  |  | $ | 980 |  |
| Construction in progress - equipment |  |  | 687 |  |  |  | 748 |  |
| Buildings |  |  | 5,416 |  |  |  | 5,416 |  |
| Equipment and software |  |  | 43,416 |  |  |  | 43,156 |  |
| Finance lease - right of use asset |  |  | — |  |  |  | 1 |  |
| Furniture and fixtures |  |  | 1,535 |  |  |  | 1,535 |  |
| Leasehold improvements |  |  | 6,815 |  |  |  | 6,815 |  |
| Property, plant and equipment, gross |  |  | 58,849 |  |  |  | 58,651 |  |
| Less accumulated depreciation |  |  | (46,902 | ) |  |  | (46,342 | ) |
| Property, plant and equipment, net |  | $ | 11,947 |  |  | $ | 12,309 |  |

[0001437749-23-022793:notes:84]
Depreciation expense was $0.6 million and $0.7 million for the three months ended  June 30, 2023 and 2022, respectively.


## us-gaap:AccountsPayableAndAccruedLiabilitiesDisclosureTextBlock

[0001437749-23-022793:notes:85]
[same as prior period, unchanged from 0001437749-23-002270:notes:115]

[0001437749-23-022793:notes:86]
Accounts payable and accrued expenses at  June 30, 2023 and  March 31, 2023 consisted of the following (in thousands):

[0001437749-23-022793:notes:87]
|  |  | June 30, 2023 |  |  | March 31, 2023 |  |
| Accounts payable |  | $ | 10,878 |  |  | $ | 13,935 |  |
| Accrued inventories in-transit |  |  | 2,023 |  |  |  | 2,267 |  |
| Accrued other miscellaneous expenses |  |  | 3,646 |  |  |  | 3,870 |  |
| Accrued contract loss |  |  | 3,530 |  |  |  | 3,464 |  |
| Advanced deposits |  |  | 1,730 |  |  |  | 5,653 |  |
| Accrued compensation |  |  | 4,443 |  |  |  | 5,430 |  |
| Income taxes payable |  |  | 256 |  |  |  | 409 |  |
| Accrued product warranty |  |  | 1,926 |  |  |  | 2,638 |  |
| Accrued restructuring |  |  | 396 |  |  |  | 717 |  |
| Total |  | $ | 28,828 |  |  | $ | 38,383 |  |

[0001437749-23-022793:notes:88]
[same as prior period, unchanged from 0001437749-23-002270:notes:118]

[0001437749-23-022793:notes:89]
[same as prior period, unchanged from 0001437749-23-002270:notes:119]

[0001437749-23-022793:notes:90]
|  |  | Three Months Ended June 30, |  |
|  |  | 2023 |  |  | 2022 |  |
| Balance at beginning of period |  | $ | 2,638 |  |  | $ | 2,066 |  |
| Provisions for warranties during the period |  |  | 208 |  |  |  | 178 |  |
| Settlements during the period |  |  | (920 | ) |  |  | (302 | ) |
| Balance at end of period |  | $ | 1,926 |  |  | $ | 1,942 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0001437749-23-022793:notes:91]
[same as prior period, unchanged from 0001437749-23-002270:notes:121]

[0001437749-23-022793:notes:92]
The Company recorded income tax expense of $0.1 million and less than $0.1 million in the three months ended  June 30, 2023 and 2022, respectively.

[0001437749-23-022793:notes:93]
Accounting for income taxes requires a two-step approach to recognizing and measuring uncertain tax positions.  The first step is to evaluate the tax position for recognition by determining if, based on the technical merits, it is more likely than not the position will be sustained upon audit, including resolution of related appeals or litigation processes, if any.  The second step is to measure the tax benefit as the largest amount that is more than 50% likely to be realized upon ultimate settlement.  The Company re-evaluates these uncertain tax positions on a quarterly basis.  The evaluation is based on factors including, but not limited to, changes in facts or circumstances, changes in tax law, effectively settled issues under audit and new audit activity.  Any changes in these factors could result in the recognition of a tax benefit or an additional charge to the tax provision.  The Company did not identify any uncertain tax positions in the three months ended  June 30, 2023 and did not have any gross unrecognized tax benefits as of  June 30, 2023.


## amsc:BusinessCombinationContingentConsiderationTextBlock

[0001437749-23-022793:notes:94]
[same as prior period, unchanged from 0001437749-23-002270:notes:125]

[0001437749-23-022793:notes:95]
Acquisition of NEPSI

[0001437749-23-022793:notes:96]
On  October 1, 2020 (the "NEPSI Acquisition Date"), the Company entered into a Stock Purchase Agreement (the "NEPSI Stock Purchase Agreement") with the selling stockholders named therein. Pursuant to the terms of the NEPSI Stock Purchase Agreement and concurrently with entering into such agreement, the Company acquired all of the issued and outstanding (i) shares of capital stock of NEPSI, and (ii) membership interests of Northeast Power Realty, LLC, a New York limited liability company, which holds the real property that serves as NEPSI's headquarters (the "NEPSI Acquisition"). NEPSI is a U.S.-based global provider of medium-voltage metal-enclosed power capacitor banks and harmonic filter banks for use on electric power systems. NEPSI is a wholly-owned subsidiary of the Company and is operated by its Grid business unit. The purchase price was $26.0 million in cash and 873,657 restricted shares of common stock of the Company. As part of the transaction, the selling stockholders  may receive up to an additional 1,000,000 shares of common stock of the Company upon the achievement of certain specified revenue objectives during varying periods of up to four years following closing of the NEPSI Acquisition.

[0001437749-23-022793:notes:97]
The Company evaluated the NEPSI Acquisition earnout payment set forth in the NEPSI Stock Purchase Agreement, which  may require settlement in the Company's common stock, and determined the contingent consideration qualified for liability classification and derivative treatment under ASC 815, Derivatives and Hedging. As a result, for each period, the fair value of the contingent consideration will be remeasured and the resulting gain or loss will be recognized in operating expenses until the share amount is fixed.

[0001437749-23-022793:notes:98]
[same as prior period, unchanged from 0001437749-23-002270:notes:127]

[0001437749-23-022793:notes:99]
|  |  | June 30, |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Fiscal Year 2023 |  | 2023 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Revenue risk premium |  |  | 5.20 | % |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Revenue volatility |  |  | 23 | % |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Stock Price |  | $ | 6.26 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Payment delay (days) |  |  | 80 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Fair value (millions) |  | $ | 2.6 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | March 31, |  |  | December 31, |  |  | September 30, |  |  | June 30, |  |  | March 31, |  |
| Fiscal Year 2022 |  | 2023 |  |  | 2022 |  |  | 2022 |  |  | 2022 |  |  | 2022 |  |
| Revenue risk premium |  |  | 5.30 | % |  |  | 5.30 | % |  |  | 5.20 | % |  |  | 6.60 | % |  |  | 6.50 | % |
| Revenue volatility |  |  | 25 | % |  |  | 25 | % |  |  | 25 | % |  |  | 30 | % |  |  | 33 | % |
| Stock Price |  | $ | 4.91 |  |  | $ | 3.68 |  |  | $ | 4.38 |  |  | $ | 5.18 |  |  | $ | 7.61 |  |
| Payment delay (days) |  |  | 80 |  |  |  | 80 |  |  |  | 80 |  |  |  | 80 |  |  |  | 80 |  |
| Fair value (millions) |  | $ | 1.3 |  |  | $ | 0.9 |  |  | $ | 1.1 |  |  | $ | 1.4 |  |  | $ | 1.2 |  |

[0001437749-23-022793:notes:100]
The Company recorded net losses of $1.3 million and $0.2 million resulting from the increases in the fair value of the contingent consideration in the three months ended  June 30, 2023 and 2022, respectively.


## us-gaap:DebtDisclosureTextBlock

[0001437749-23-022793:notes:101]
14. Debt

[0001437749-23-022793:notes:102]
As part of the acquisition of Neeltran, the Company identified four equipment financing agreements that Neeltran had entered into prior to the acquisition of Neeltran on  May 6, 2021. The current and long-term aggregate debt balance is $0.1 million as of  June 30, 2023 and  March 31, 2023, respectively.


## us-gaap:LesseeOperatingLeasesTextBlock

[0001437749-23-022793:notes:103]
[same as prior period, unchanged from 0001437749-23-002270:notes:132]

[0001437749-23-022793:notes:104]
[same as prior period, unchanged from 0001437749-23-002270:notes:133]

[0001437749-23-022793:notes:105]
The discount rate was calculated using an incremental borrowing rate based on an assessment prepared by the Company through the use of Company credit ratings, consideration of its lease populations potential risk to its total capital structure, and a market rate for a collateralized loan for its risk profile, calculated by a third party.

[0001437749-23-022793:notes:106]
[same as prior period, unchanged from 0001437749-23-002270:notes:136]

[0001437749-23-022793:notes:107]
[same as prior period, unchanged from 0001437749-23-002270:notes:137]

[0001437749-23-022793:notes:108]
The Company also enters into leases for vehicles, IT equipment and service agreements, and other leases related to its manufacturing operations that are also included in the right-of-use assets and lease liability accounts if they are for a term of longer than twelve months. However, many of these leases are either short-term in nature or immaterial. The Company has made the policy election to exclude short-term leases from the condensed consolidated balance sheet.

[0001437749-23-022793:notes:109]
[same as prior period, unchanged from 0001437749-23-002270:notes:139]

[0001437749-23-022793:notes:110]
As of  June 30, 2023, the right-of-use asset related to the finance lease, net of accumulated amortization is $13.2 thousand, and is included in the property and equipment, net on the Company's condensed consolidated balance sheet.

[0001437749-23-022793:notes:111]
Finance lease right-of-use assets and lease liabilities are recognized similar to an operating lease, at the lease commencement date or the date the lessor makes the leased asset available for use. Finance lease right-of-use assets are generally amortized on a straight-line basis over the lease term, and the carrying amount of the finance lease liabilities are (1) accreted to reflect interest using the incremental borrowing rate if the rate implicit in the lease is not readily determinable, and (2) reduced to reflect lease payments made during the period. Amortization expense for finance lease right-of-use assets and interest accretion on finance lease liabilities are recorded to depreciation expense and interest expense, respectively in the Company's condensed consolidated statement of operations.

[0001437749-23-022793:notes:112]
Supplemental balance sheet information related to leases at  June 30, 2023, and  March 31, 2023 are as follows (in thousands):

[0001437749-23-022793:notes:113]
|  |  | June 30, 2023 |  |  | March 31, 2023 |  |
| Leases: |  |  |  |  |  |  |  |  |
| Right-of-use assets - Financing |  | $ | - |  |  |  | 1 |  |
| Right-of-use assets - Operating |  |  | 2,694 |  |  |  | 2,857 |  |
| Total right-of-use assets |  |  | 2,694 |  |  |  | 2,858 |  |
| Lease liabilities - ST Financing |  | $ | - |  |  |  | 1 |  |
| Lease liabilities - ST Operating |  |  | 781 |  |  |  | 807 |  |
| Lease liabilities - LT Operating |  |  | 2,047 |  |  |  | 2,184 |  |
| Total lease liabilities |  | $ | 2,828 |  |  |  | 2,992 |  |
| Weighted-average remaining lease term |  |  | 3.79 years |  |  |  | 3.95 years |  |
| Weighted-average discount rate |  |  | 6.67 | % |  |  | 6.46 | % |

[0001437749-23-022793:notes:114]
The costs related to the Company's finance lease are not material. The costs related to the Company's operating leases for the three months ended  June 30, 2023 and 2022 are as follows (in thousands):

[0001437749-23-022793:notes:115]
|  |  | Three Months Ended |  |
|  |  | June 30, 2023 |  |
| Operating Leases: |  |  |  |  |
| Operating lease costs - fixed |  | $ | 259 |  |
| Operating lease costs - variable |  |  | 40 |  |
| Short-term lease costs |  |  | 37 |  |
| Total lease costs |  | $ | 336 |  |

[0001437749-23-022793:notes:116]
|  |  | Three Months Ended |  |
|  |  | June 30, 2022 |  |
| Operating Leases: |  |  |  |  |
| Operating lease costs - fixed |  | $ | 242 |  |
| Operating lease costs - variable |  |  | 38 |  |
| Short-term lease costs |  |  | 31 |  |
| Total lease costs |  | $ | 311 |  |

[0001437749-23-022793:notes:117]
[same as prior period, unchanged from 0001437749-23-002270:notes:147]

[0001437749-23-022793:notes:118]
|  |  | Leases |  |
| Year ended March 31, |  |  |  |  |
| 2024 |  | $ | 519 |  |
| 2025 |  |  | 793 |  |
| 2026 |  |  | 732 |  |
| 2027 |  |  | 592 |  |
| 2028 |  |  | 369 |  |
| Thereafter |  |  | 3 |  |
| Total minimum lease payments |  |  | 3,008 |  |
| Less: interest |  |  | 180 |  |
| Present value of lease liabilities |  | $ | 2,828 |  |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001437749-23-022793:notes:119]
16. Commitments and Contingencies

[0001437749-23-022793:notes:120]
Legal Contingencies

[0001437749-23-022793:notes:121]
From time to time, the Company is involved in legal and administrative proceedings and claims of various types. The Company records a liability in its condensed consolidated financial statements for these matters when a loss is known or considered probable and the amount can be reasonably estimated. The Company reviews these estimates each accounting period as additional information is known and adjusts the loss provision when appropriate. If a matter is both probable to result in a liability and the amounts of loss can be reasonably estimated, the Company estimates and discloses the possible loss or range of loss to the extent necessary to make the condensed consolidated financial statements not misleading. If the loss is not probable or cannot be reasonably estimated, a liability is not recorded in its condensed consolidated financial statements.

[0001437749-23-022793:notes:122]
Other

[0001437749-23-022793:notes:123]
The Company enters into long-term construction contracts with customers that require the Company to obtain performance bonds. The Company is required to deposit an amount equivalent to some or all the face amount of the performance bonds into an escrow account until the termination of the bond. When the performance conditions are met, amounts deposited as collateral for the performance bonds are returned to the Company. In addition, the Company has various contractual arrangements in which minimum quantities of goods or services have been committed to be purchased on an annual basis.

[0001437749-23-022793:notes:124]
As of  June 30, 2023, the Company had $0.6 million of restricted cash included in long-term assets and $0.5 million of restricted cash included in current assets. As of  March 31, 2023, the Company had $0.6 million of restricted cash included in long term assets and $1.7 million of restricted cash included in current assets. These amounts included in restricted cash primarily represent deposits to secure letters of credit for various supply contracts and long-term projects or collateral deposits.  These deposits are held in interest bearing accounts.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001437749-23-022793:notes:125]
17. Restructuring

[0001437749-23-022793:notes:126]
The Company accounts for charges resulting from operational restructuring actions in accordance with ASC Topic 420, Exit or Disposal Cost Obligations (“ASC 420”) and ASC Topic 712, Compensation—Nonretirement Postemployment Benefits (“ASC 712”). In accounting for these obligations, the Company is required to make assumptions related to the amounts of employee severance, benefits, and related costs and the time period over which leased facilities will remain vacant, sublease terms, sublease rates and discount rates. Estimates and assumptions are based on the best information available at the time the obligation arises. These estimates are reviewed and revised as facts and circumstances dictate; changes in these estimates could have a material effect on the amount accrued on the consolidated balance sheet.

[0001437749-23-022793:notes:127]
On  January 24, 2023, the Company approved a plan to reduce its global workforce by approximately 5%, effective as of such date. The purpose of the workforce reduction was to reduce operating expenses to better align with the Company’s current revenues. In fiscal 2022, the Company recorded restructuring charges of $1.0 million as a result of this reduction in force, which was comprised of severance pay. All amounts related to these restructuring activities are expected to be paid by  March 31, 2024.

[0001437749-23-022793:notes:128]
The following table presents restructuring charges and cash payments during the three months ended  June 30, 2023 and year ended  March 31, 2023 (in thousands):

[0001437749-23-022793:notes:129]
|  |  | Severance pay |  |
|  |  | and benefits |  |
| Accrued restructuring balance at April 1, 2023 |  | $ | 717 |  |
| Charges to operations |  |  | 6 |  |
| Cash payments |  |  | (327 | ) |
| Accrued restructuring balance at June 30, 2023 |  | $ | 396 |  |

[0001437749-23-022793:notes:130]
|  |  | Severance pay |  |
|  |  | and benefits |  |
| Accrued restructuring balance at April 1, 2022 |  | $ | — |  |
| Charges to operations |  |  | 1,048 |  |
| Cash payments |  |  | (331 | ) |
| Accrued restructuring balance at March 31, 2023 |  | $ | 717 |  |

[0001437749-23-022793:notes:131]
All restructuring charges discussed above are included within restructuring in the Company’s condensed consolidated statements of operations. The Company includes accrued restructuring within accounts payable and accrued expenses in the consolidated balance sheets.  The Company's restructuring charges relate primarily to the Grid business segment operations in the United States.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001437749-23-022793:notes:132]
18. Business Segments

[0001437749-23-022793:notes:133]
The Company reports its financial results in two reportable business segments: Grid and Wind. In accordance with ASC 280, Segment Reporting, we aggregate four operating segments into one reporting segment for financial reporting purposes due to their similar operating and financial characteristics. Our operating segments reflect the way in which internally-reported financial information is used to make decisions and allocate resources.

[0001437749-23-022793:notes:134]
Through the Company’s power grid offerings, the Grid business segment enables electric utilities, industrial facilities, and renewable energy project developers to connect, transmit and distribute smarter, cleaner and better power through its transmission planning services, power electronics, and superconductor-based systems. The sales process is enabled by transmission planning services that allow it to identify power grid congestion, poor power quality and other risks, which helps the Company determine how its solutions can improve network performance. These services often lead to sales of grid interconnection solutions for wind farms and solar power plants, power quality systems, and transmission and distribution cable systems.  The Company also sells ship protection products to the U.S. Navy through its Grid business segment.

[0001437749-23-022793:notes:135]
Through the Company’s wind power offerings, the Wind business segment enables manufacturers to field highly competitive wind turbines through its advanced power electronics and control system products, engineered designs, and support services. The Company supplies advanced power electronics and control systems, licenses its highly engineered wind turbine designs, and provides extensive customer support services to wind turbine manufacturers. The Company’s design portfolio includes a broad range of drive trains and power ratings of 2 megawatts ("MWs") and higher. The Company provides a broad range of power electronics and software-based control systems that are highly integrated and designed for optimized performance, efficiency, and grid compatibility.

[0001437749-23-022793:notes:136]
[same as prior period, unchanged from 0001437749-23-002270:notes:159]

[0001437749-23-022793:notes:137]
|  |  | Three Months Ended June 30, |  |
|  |  | 2023 |  |  | 2022 |  |
| Revenues: |  |  |  |  |  |  |  |  |
| Grid |  | $ | 25,737 |  |  | $ | 19,829 |  |
| Wind |  |  | 4,517 |  |  |  | 2,850 |  |
| Total |  | $ | 30,254 |  |  | $ | 22,679 |  |

[0001437749-23-022793:notes:138]
|  |  | Three Months Ended June 30, |  |
|  |  | 2023 |  |  | 2022 |  |
| Operating loss: |  |  |  |  |  |  |  |  |
| Grid |  | $ | (1,971 | ) |  | $ | (7,281 | ) |
| Wind |  |  | (649 | ) |  |  | (386 | ) |
| Unallocated corporate expenses |  |  | (2,713 | ) |  |  | (1,202 | ) |
| Total |  | $ | (5,333 | ) |  | $ | (8,869 | ) |

[0001437749-23-022793:notes:139]
[same as prior period, unchanged from 0001437749-23-002270:notes:162]

[0001437749-23-022793:notes:140]
Unallocated corporate expenses consist of a loss on contingent consideration of $1.3 million and $0.2 million in the three months ended  June 30, 2023 and 2022, respectively. Additionally, unallocated corporate expenses consist of stock-based compensation expense of $1.4 million and $1.0 million in the three months ended  June 30, 2023 and 2022, respectively.

[0001437749-23-022793:notes:141]
Total assets for the two business segments as of  June 30, 2023 and  March 31, 2023, are as follows (in thousands):

[0001437749-23-022793:notes:142]
|  |  | June 30, 2023 |  |  | March 31, 2023 |  |
| Grid |  | $ | 136,941 |  |  | $ | 135,296 |  |
| Wind |  |  | 10,374 |  |  |  | 14,361 |  |
| Corporate assets |  |  | 23,319 |  |  |  | 25,904 |  |
| Total |  | $ | 170,634 |  |  | $ | 175,561 |  |


## us-gaap:NewAccountingPronouncementsAndChangesInAccountingPrinciplesTextBlock

[0001437749-23-022793:notes:143]
19. Recent Accounting Pronouncements

[0001437749-23-022793:notes:144]
In  June 2016, the FASB issued ASU 2016-13, Financial Instruments-Credit Losses (Topic 326): Measurement of Credit Losses on Financial Instruments. The amendments in ASU 2016-13 will provide more decision-useful information about the expected credit losses on financial instruments and other commitments to extend credit held by a reporting entity at each reporting date. Following the release of ASU 2019-10 in  November 2019, the effective date, as long as the Company remains a smaller reporting company, was annual reporting periods beginning after  December 15, 2022.  As of  April 1, 2023, the Company has adopted ASU 2016-13 and noted no material impact on its condensed consolidated financial statements.

[0001437749-23-022793:notes:145]
In  October 2021, the FASB issued ASU 2021-08, Business Combinations (Topic 805): Accounting for Contract Assets and Contract Liabilities from Contracts with Customers. The amendments in ASU 2021-08 will improve the accounting for acquired revenue contracts with customers in a business combination. Following the release of ASU 2021-08 in  October 2021, the effective date was annual reporting periods beginning after  December 15, 2022. As of  April 1, 2023, the Company has adopted ASU 2021-08 and noted no material impact on its condensed consolidated financial statements.


## us-gaap:SubsequentEventsTextBlock

[0001437749-23-022793:notes:146]
20. Subsequent Events

[0001437749-23-022793:notes:147]
The Company has performed an evaluation of subsequent events through the time of filing this Quarterly Report on Form 10-Q with the SEC and has determined that there are no such events to report.
