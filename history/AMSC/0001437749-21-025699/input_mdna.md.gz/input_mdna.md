# AMSC MD&A — 0001437749-21-025699


## mdna

[0001437749-21-025699:mdna:1]
[same as prior period, unchanged from 0001437749-21-018523:mdna:1]

[0001437749-21-025699:mdna:2]
[same as prior period, unchanged from 0001437749-21-018523:mdna:2]

[0001437749-21-025699:mdna:3]
[same as prior period, unchanged from 0001437749-21-018523:mdna:3]

[0001437749-21-025699:mdna:4]
[same as prior period, unchanged from 0001437749-21-018523:mdna:4]

[0001437749-21-025699:mdna:5]
[same as prior period, unchanged from 0001437749-21-018523:mdna:5]

[0001437749-21-025699:mdna:6]
[same as prior period, unchanged from 0001437749-21-018523:mdna:6]

[0001437749-21-025699:mdna:7]
[same as prior period, unchanged from 0001437749-21-018523:mdna:7]

[0001437749-21-025699:mdna:8]
[same as prior period, unchanged from 0001437749-21-018523:mdna:8]

[0001437749-21-025699:mdna:9]
[same as prior period, unchanged from 0001437749-21-018523:mdna:9]

[0001437749-21-025699:mdna:10]
[same as prior period, unchanged from 0001437749-21-018523:mdna:10]

[0001437749-21-025699:mdna:11]
On October 31, 2018, we entered into a Subcontract Agreement with Commonwealth Edison Company (“ComEd”) (the “Subcontract Agreement”) for the manufacture and installation of the Company’s REG system within ComEd’s electric grid in Chicago, Illinois (the “Project”). As provided in the Subcontract Agreement, the Subcontract Agreement became effective upon the signing of an amendment by us and the U.S. Department of Homeland Security (“DHS”) to the existing contract (the “Prime Contract”) between us and DHS on June 20, 2019. Unless terminated earlier by us, ComEd or DHS according to the terms of the Subcontract Agreement, the term of the Subcontract Agreement will continue until we complete our warranty obligations under the Subcontract Agreement. Under the terms of the Subcontract Agreement, we have agreed, among other things, to provide the REG system and to supervise ComEd’s installation of the REG system in Chicago. As part of our separate cost sharing arrangement with DHS under the Prime Contract, we expect funding provided by DHS in connection with the Subcontract Agreement to be between $9.0 to $11.0 million, which represents the total amount of revenue we are expected to recognize over the term of the Subcontract Agreement and includes up to $1.0 million that we have agreed to reimburse ComEd for costs incurred by ComEd while undertaking its tasks under the Subcontract Agreement (the “Reimbursement Amount”). In addition, we are required to deliver an irrevocable letter of credit in the amount of $5.0 million to secure certain Company obligations under the Subcontract Agreement, which we have done, and deposited $5.0 million in an escrow account as collateral to secure such letter of credit.  ComEd has agreed to provide the site and provide all civil engineering work required to support the installation, operation and integration of the REG system into ComEd’s electric grid. Other than the Reimbursement Amount, ComEd is responsible for its own costs and expenses. DHS’s approval to commence with construction was obtained on June 20, 2019. Substation work on the project began in late 2019 and we successfully integrated the REG system on Com Ed's electric power grid and the REG system became fully operational in August 2021. The REG system was placed into operation during the three months ended September 30, 2021.

[0001437749-21-025699:mdna:12]
On October 1, 2020, we entered into a Stock Purchase Agreement (the “NEPSI Stock Purchase Agreement”) with the selling stockholders named therein.  Pursuant to the terms of the NEPSI Stock Purchase Agreement and concurrently with entering into such agreement, we acquired all of the issued and outstanding (i) shares of capital stock of Northeast Power Systems, Inc., a New York corporation (“NEPSI"), and (ii) membership interests of Northeast Power Realty, LLC, a New York limited liability company, which holds the real property that serves as NEPSI’s headquarters (the "NEPSI Acquisition"). NEPSI is a U.S.-based global provider of medium-voltage metal-enclosed power capacitor banks and harmonic filter banks for use on electric power systems.  As a result of this transaction, NEPSI became a wholly-owned subsidiary and is operated by our Grid business segment.

[0001437749-21-025699:mdna:13]
[same as prior period, unchanged from 0001437749-21-018523:mdna:13]

[0001437749-21-025699:mdna:14]
On May 6, 2021, we acquired all of the issued and outstanding shares of capital stock of (i) Neeltran, Inc. a Connecticut corporation ("Neeltran") that supplies rectifiers and transformers to industrial customers, and (ii) Neeltran International, Inc., a Connecticut corporation (“International”), as well as the real property that served as Neeltran’s headquarters ("the Neeltran Acquisition"). For additional information, see “Liquidity and Capital Resources” below.

[0001437749-21-025699:mdna:15]
[same as prior period, unchanged from 0001437749-21-018523:mdna:15]

[0001437749-21-025699:mdna:16]
The COVID-19 pandemic continues to rapidly evolve. We are starting to experience inflation pressure in our supply chain and some delays in sourcing materials needed for our products which has increased our cost of revenues and decreased gross margin. The extent to which the outbreak impacts our business, liquidity, results of operations and financial condition will depend on future developments, which are highly uncertain and cannot be predicted with confidence, including the continued geographic spread of the disease, the duration of the pandemic, the location, duration and magnitude of future waves of infection, new variants of the virus, availability and adoption of vaccines and treatments, effectiveness of vaccines against the virus and its mutations, travel restrictions and social distancing in the United States, the European Union, India and other countries, the duration and extent of business closures or business disruptions including global supply chain disruptions and the effectiveness of actions taken to contain and treat the disease. Changes in macroeconomic and market conditions arising from the COVID-19 pandemic, including inflation, sourcing, material delays and global supply chain disruptions could have a material adverse effect on our business financial condition and results of operation.

[0001437749-21-025699:mdna:17]
[same as prior period, unchanged from 0001437749-21-018523:mdna:17]

[0001437749-21-025699:mdna:18]
[same as prior period, unchanged from 0001437749-21-018523:mdna:18]

[0001437749-21-025699:mdna:19]
[same as prior period, unchanged from 0001437749-21-018523:mdna:19]

[0001437749-21-025699:mdna:20]
Three and six months ended September 30, 2021, compared to the three and six months ended September 30, 2020

[0001437749-21-025699:mdna:21]
[same as prior period, unchanged from 0001437749-21-018523:mdna:21]

[0001437749-21-025699:mdna:22]
Total revenues increased 32% and 26% to $27.9 million and $53.3 million for the three and six months ended September 30, 2021, respectively, compared to $21.1 million and $42.3 million for the three and six months ended September 30, 2020, respectively.  Our revenues are summarized as follows (in thousands):

[0001437749-21-025699:mdna:23]
|  |  | Three Months Ended September 30, |  |  | Six Months Ended September 30, |  |
|  |  | 2021 |  |  | 2020 |  |  | 2021 |  |  | 2020 |  |
| Revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Grid |  | $ | 24,619 |  |  | $ | 16,347 |  |  | $ | 48,119 |  |  | $ | 34,062 |  |
| Wind |  |  | 3,289 |  |  |  | 4,770 |  |  |  | 5,209 |  |  |  | 8,267 |  |
| Total |  | $ | 27,908 |  |  | $ | 21,117 |  |  | $ | 53,328 |  |  | $ | 42,329 |  |

[0001437749-21-025699:mdna:24]
Our Grid business unit accounted for 88% and 90% of total revenues for the three and six months ended September 30, 2021, respectively, compared to 77% and 80% for the three and six months ended September 30, 2020, respectively. Our Grid business unit revenues increased 51% and 41% to $24.6 million and $48.1 million in the three and six months ended September 30, 2021, respectively, from $16.3 million and $34.1 million in the three and six months ended September 30, 2020, respectively. The increase in the Grid business unit revenue in the three and six months ended September 30, 2021, was primarily driven by the contributions from the acquisitions of NEPSI and Neeltran.

[0001437749-21-025699:mdna:25]
Our Wind business unit accounted for 12% and 10% of total revenues for the three and six months ended September 30, 2021, respectively, compared to 23% and 20% for the three and six months ended September 30, 2020, respectively.  Revenues in the Wind business unit decreased 31% and 37% to $3.3 million and $5.2 million in the three and six months ended September 30, 2021, from $4.8 million and $8.3 million in the three and six months ended September 30, 2020. The decrease in the three and six months ended September 30, 2021, was driven by shipments of electrical control systems ("ECS") to Doosan in the three and six months ended September 30, 2020 with no similar shipments in the current year period. Inox, historically one of the largest customers of our Wind business unit has had and may in the future have its ability to perform under our ECS supply contract hampered by the prolonged impacts of the COVID-19 pandemic. Inox has been active in the new central and state government auction regime in India and has a cumulative order book of over 1.4 GW. We are parties to a technology transfer & license agreement dated as of April 17, 2009, as amended (the “2009 TTLA”) with Inox for a 2 MW class wind turbine, the manufacture of which requires our ECS.  On July 21, 2021, we sent written notice to Inox notifying Inox of its default under the 2009 TTLA due to Inox’s failure to pay royalties for commissioned 2 MW wind turbines in the amount of €0.7 million that Inox is obligated to pay under the terms of the 2009 TTLA.  Inox subsequently paid the royalties during the cure period. If Inox in the future fails to pay such royalties in accordance with the terms of the 2009 TTLA within the thirty working day cure period after receipt of the default notice, then we may terminate the 2009 TTLA by providing written notice of such termination to Inox.  We cannot predict if and when Inox will pay royalties due and payable under the 2009 TTLA in the future. In the event we were to terminate the 2009 TTLA in connection with Inox's failure to pay royalties under such agreement, Inox would no longer be able to manufacture 2 MW wind turbines, likely result in a decrease in Inox’s demand for our ECS and our revenues and liquidity could be impacted. We cannot predict if and how successful Inox will be in executing on these orders or in obtaining new orders under the new central and state auction regime. Any failure by Inox to succeed under this regime, or any delay in Inox’s ability to deliver its wind turbines, could result in fewer ECS shipments to Inox.

[0001437749-21-025699:mdna:26]
[same as prior period, unchanged from 0001437749-21-018523:mdna:26]

[0001437749-21-025699:mdna:27]
Cost of revenues increased by 58% and 47% to $24.6 million and $46.7 million for the three and six months ended September 30, 2021, compared to $15.6 million and $31.8 million for the three and six months ended September 30, 2020. Gross margin was 12% and 13% for the three and six months ended September 30, 2021, compared to 26% and 25% for the three and six months ended September 30, 2020.  The decrease in gross margin in the three and six months ended September 30, 2021, was due to an unfavorable product mix, higher raw materials cost and additional costs related to purchase accounting adjustments associated with the Neeltran Acquisition. Cost of revenues includes total amortization expense of less than $0.1 million and $0.1 million in the three and six months ended September 30, 2021 as a result of each of the NEPSI and Neeltran acquired backlog intangible assets.  In addition, a fair value purchase adjustment of approximately $0.3 million and $0.6 million for the step-up basis assigned to acquired inventory, to properly reflect the fair value in purchase accounting, was charged to cost of revenues in the three and six months ended September 30, 2021.

[0001437749-21-025699:mdna:28]
[same as prior period, unchanged from 0001437749-21-018523:mdna:28]

[0001437749-21-025699:mdna:29]
[same as prior period, unchanged from 0001437749-21-018523:mdna:29]

[0001437749-21-025699:mdna:30]
Research and development ("R&D") expense remained relatively flat at $2.7 million in the three months ended September 30, 2021 and September 30, 2020, respectively. The slight decrease in R&D expense was due to higher overall compensation expense and less allocation of expenses to cost of goods sold for revenue generating projects in the three months ended September 30, 2020, compared to the three months ended September 30, 2021. Research and development expenses increased 9% in the six months ended September 30, 2021 to $5.7 million from $5.2 million in the six months ended September 30, 2020. The increase in R&D expense in the six month period was due to less allocation of expenses to cost of goods sold for revenue generating projects.

[0001437749-21-025699:mdna:31]
[same as prior period, unchanged from 0001437749-21-018523:mdna:31]

[0001437749-21-025699:mdna:32]
Selling, general and administrative ("SG&A") expenses increased 14% in the three months ended September 30, 2021, to $6.7 million from $5.9 million in the three months ended September 30, 2020. The increase in SG&A expense in the three months ended September 30, 2021 was due to higher overall compensation expense due to the additions of NEPSI and Neeltran, as well as higher stock compensation expense than in the prior year period. Selling, general and administrative expenses increased 20% to $13.8 million in the six months ended September 30, 2021 compared to $11.5 million in the six months ended September 30, 2020. The increase in SG&A expense in the six months ended September 30, 2021 was due to higher overall compensation expense due to the additions of NEPSI and Neeltran than in the prior year period.

[0001437749-21-025699:mdna:33]
[same as prior period, unchanged from 0001437749-21-018523:mdna:33]

[0001437749-21-025699:mdna:34]
We recorded amortization expense related to our core technology and know-how, customer relationships, and other intangible assets of $0.6 million and $1.2 million in the three and six months ended September 30, 2021, respectively, and $0.1 million and $0.2 million in the three and six months ended September 30, 2020, respectively.  The increase in amortization expense is primarily a result of the acquisitions of NEPSI and Neeltran.

[0001437749-21-025699:mdna:35]
[same as prior period, unchanged from 0001437749-21-018523:mdna:35]

[0001437749-21-025699:mdna:36]
The change in fair value of our contingent consideration for the earnout payment on the NEPSI Acquisition resulted in a gain of $2.4 million and $2.3 million in the three and six months ended September 30, 2021. The change in the fair value was primarily driven by a decreased likelihood of achieving certain revenue targets.

[0001437749-21-025699:mdna:37]
[same as prior period, unchanged from 0001437749-21-018523:mdna:37]

[0001437749-21-025699:mdna:38]
[same as prior period, unchanged from 0001437749-21-018523:mdna:38]

[0001437749-21-025699:mdna:39]
|  |  | Three Months Ended September 30, |  |  | Six Months Ended September 30, |  |
|  |  | 2021 |  |  | 2020 |  |  | 2021 |  |  | 2020 |  |
| Operating Income (loss): |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Grid |  | $ | (5,836 | ) |  | $ | (1,374 | ) |  | $ | (11,180 | ) |  | $ | (2,562 | ) |
| Wind |  |  | 205 |  |  |  | (983 | ) |  |  | (558 | ) |  |  | (2,103 | ) |
| Unallocated corporate expenses |  |  | 1,329 |  |  |  | (849 | ) |  |  | (63 | ) |  |  | (1,758 | ) |
| Total |  | $ | (4,302 | ) |  | $ | (3,206 | ) |  | $ | (11,801 | ) |  | $ | (6,423 | ) |

[0001437749-21-025699:mdna:40]
Our Grid business segment generated operating losses of $5.8 million and $11.1 million in the three and six months ended September 30, 2021, compared to $1.4 million and $2.6 million in the three and six months ended September 30, 2020. The increase in the Grid business unit operating loss in the three and six months ended September 30, 2021, was due to a less favorable product mix and the impact of the purchase accounting adjustments recorded as part of the Neeltran Acquisition including the inventory step up charge noted above and an adjustment which reduced revenue by $0.6 million less than the contract value, to recognize the fair value adjustment related to the acquired customer deposits, in order to properly reflect pre-acquisition activities.

[0001437749-21-025699:mdna:41]
Our Wind business segment generated an operating profit of $0.2 million and an operating loss of $0.6 million in the three and six months ended September 30, 2021, compared to operating losses of $1.0 million and $2.1 million in the three and six months ended September 30, 2020. The decrease in the Wind business unit operating loss in the three and six month periods was due to reduced manufacturing overhead associated with consolidating wind manufacturing into our Ayer manufacturing facility in Massachusetts.

[0001437749-21-025699:mdna:42]
Unallocated corporate expenses consist of a gain on contingent consideration of $2.4 million and $2.3 million in the three and six months ended September 30, 2021. Additionally, unallocated corporate expenses primarily consisted of stock-based compensation expense of $1.1 million and $0.8 million in the three months ended September 30, 2021 and 2020, respectively and $2.4 million and $1.8 million in the six months ended September 30, 2021 and 2020, respectively.

[0001437749-21-025699:mdna:43]
[same as prior period, unchanged from 0001437749-21-018523:mdna:43]

[0001437749-21-025699:mdna:44]
Interest income, net, was less than $0.1 million and $0.1 million in the three and six months ended September 30, 2021, compared to $0.2 million and $0.3 million in the three and six months ended September 30, 2020. The decrease in interest income in the three and six months ended September 30, 2021 was related to a lower cash balance earning lower interest rates than in the prior period.

[0001437749-21-025699:mdna:45]
[same as prior period, unchanged from 0001437749-21-018523:mdna:45]

[0001437749-21-025699:mdna:46]
Other income, net was less than $0.1 million and other expense, net was less than $0.1 million in the three and six months ended September 30, 2021, compared to other expense, net of $0.5 million and $0.6 million in the three and six months ended September 30, 2020. The decrease in other expense during both periods was driven by the impacts of favorable fluctuations in foreign currencies during the respective period.

[0001437749-21-025699:mdna:47]
[same as prior period, unchanged from 0001437749-21-018523:mdna:47]

[0001437749-21-025699:mdna:48]
Income tax expense was $0.2 million in the three months ended September 30, 2021 and income tax benefit was $1.9 million in the six months ended September 30, 2021. Income tax expense was $0.2 million and $0.4 million in the three and six months ended September 30, 2020.  The decrease in income tax expense is a result of the release of the valuation allowance to offset the recording of the deferred tax liability from the Neeltran Acquisition in the six months ended September 30, 2021.

[0001437749-21-025699:mdna:49]
[same as prior period, unchanged from 0001437749-21-018523:mdna:49]

[0001437749-21-025699:mdna:50]
Net loss was $4.4 million and $9.8 million in the three and six months ended September 30, 2021, compared to $3.7 million and $7.1 million in the three and six months ended September 30, 2020.  The increase in net loss was driven by lower gross margin and higher operating expenses primarily due to acquisition costs and purchase accounting adjustments in the three and six months ended September 30, 2021.

[0001437749-21-025699:mdna:51]
[same as prior period, unchanged from 0001437749-21-018523:mdna:51]

[0001437749-21-025699:mdna:52]
[same as prior period, unchanged from 0001437749-21-018523:mdna:52]

[0001437749-21-025699:mdna:53]
We define non-GAAP net loss as net loss before stock-based compensation, amortization of acquisition-related intangibles, change in fair value of contingent consideration, acquisition costs, and other non-cash or unusual charges.  We believe non-GAAP net loss assists management and investors in comparing our performance across reporting periods on a consistent basis by excluding these non-cash charges and other items that we do not believe are indicative of our core operating performance. In addition, we use non-GAAP net loss as a factor to evaluate the effectiveness of our business strategies. A reconciliation of GAAP to non-GAAP net loss is set forth in the table below (in thousands, except per share data):

[0001437749-21-025699:mdna:54]
|  |  | Three Months Ended September 30, |  |  | Six Months Ended September 30, |  |
|  |  | 2021 |  |  | 2020 |  |  | 2021 |  |  | 2020 |  |
| Net loss |  | $ | (4,434 | ) |  | $ | (3,712 | ) |  | $ | (9,837 | ) |  | $ | (7,129 | ) |
| Stock-based compensation |  |  | 1,100 |  |  |  | 849 |  |  |  | 2,393 |  |  |  | 1,758 |  |
| Amortization of acquisition-related intangibles |  |  | 668 |  |  |  | 121 |  |  |  | 1,289 |  |  |  | 242 |  |
| Change in fair value of contingent consideration |  |  | (2,430 | ) |  |  | — |  |  |  | (2,330 | ) |  |  | — |  |
| Acquisition costs |  |  | (7 | ) |  |  | — |  |  |  | 681 |  |  |  | — |  |
| Non-GAAP net loss |  | $ | (5,103 | ) |  | $ | (2,742 | ) |  | $ | (7,804 | ) |  | $ | (5,129 | ) |
| Non-GAAP net loss per share - basic |  | $ | (0.19 | ) |  | $ | (0.13 | ) |  | $ | (0.29 | ) |  | $ | (0.24 | ) |
| Weighted average shares outstanding - basic |  |  | 27,252 |  |  |  | 21,860 |  |  |  | 27,040 |  |  |  | 21,775 |  |

[0001437749-21-025699:mdna:55]
We incurred non-GAAP net losses of $5.1 million and $7.8 million or $0.19 and $0.29 per share, for the three and six months ended September 30, 2021, compared to $2.7 million and $5.1 million, or $0.13 and $0.24 per share, for the three and six months ended September 30, 2020. The increase in the non-GAAP net loss for the three and six months ended September 30, 2021 was due to a higher operating loss driven by lower gross margin and higher operating expenses.

[0001437749-21-025699:mdna:56]
[same as prior period, unchanged from 0001437749-21-018523:mdna:56]

[0001437749-21-025699:mdna:57]
We have experienced recurring operating losses, and as of September 30, 2021, had an accumulated deficit of $1,011.1 million.

[0001437749-21-025699:mdna:58]
[same as prior period, unchanged from 0001437749-21-018523:mdna:58]

[0001437749-21-025699:mdna:59]
[same as prior period, unchanged from 0001437749-21-018523:mdna:59]

[0001437749-21-025699:mdna:60]
As described above, on May 6, 2021, we acquired all of the issued and outstanding shares of capital stock of (i) Neeltran and (ii) International, for: (a) $1.0 million in cash, and (b) 301,556 shares of the Company’s common stock, which were paid and issued to the selling stockholders of Neeltran. We also paid $1.1 million to the selling stockholders of International at closing to pay off previous loans made by them to Neeltran.

[0001437749-21-025699:mdna:61]
[same as prior period, unchanged from 0001437749-21-018523:mdna:61]

[0001437749-21-025699:mdna:62]
As of September 30, 2021, we had cash, cash equivalents, marketable securities and restricted cash of $57.0 million, compared to $80.7 million as of March 31, 2021, a decrease of $23.7 million. As of September 30, 2021, we had approximately $2.3 million of cash, cash equivalents, and restricted cash in foreign bank accounts. Our cash, cash equivalents, marketable securities and restricted cash are summarized as follows (in thousands):

[0001437749-21-025699:mdna:63]
|  |  | September 30, 2021 |  |  | March 31, 2021 |  |
| Cash and cash equivalents |  | $ | 48,501 |  |  | $ | 67,814 |  |
| Marketable securities |  |  | - |  |  |  | 5,140 |  |
| Restricted cash |  |  | 8,488 |  |  |  | 7,725 |  |
| Total cash, cash equivalents, marketable securities and restricted cash |  | $ | 56,989 |  |  | $ | 80,679 |  |

[0001437749-21-025699:mdna:64]
For the six months ended September 30, 2021, net cash used in operating activities was $11.7 million, compared to $6.6 million for the six months ended September 30, 2020.  The increase in net cash used in operations was due primarily to the overall impact of increased sales activities on operating activities during the current year period.

[0001437749-21-025699:mdna:65]
For the six months ended September 30, 2021, net cash used in investing activities was $6.8 million, compared to net cash provided by investing activities of $23.7 million for the six months ended September 30, 2020. The increase in net cash used in investing activities was primarily due to the cash that was used to pay for the Neeltran Acquisition. Additionally the prior year period included $25 million for settlement of a certificate deposit that was used to fund the acquisition of NEPSI. There was no such transaction in the six months ended September 30, 2021.

[0001437749-21-025699:mdna:66]
For the six months ended September 30, 2021, net cash provided by financing activities was less than $0.1 million compared to net cash used in financing activities of $0.6 million in the six months ended September 30, 2020.  The decrease in net cash used in financing activities was due primarily to a decrease in the repurchase of common stock in connection with employee tax obligations upon the vesting of stock awards.

[0001437749-21-025699:mdna:67]
As of September 30, 2021, we had $6.2 million of restricted cash included in long-term assets and $2.3 million of restricted cash included in current assets.  These amounts of restricted cash primarily represent deposits to secure letters of credit for various supply contracts and long-term projects, including the irrevocable letter of credit in the amount of $5.0 million to secure certain of our obligations under the Subcontract Agreement with ComEd. These deposits are held in interest bearing accounts.

[0001437749-21-025699:mdna:68]
[same as prior period, unchanged from 0001437749-21-018523:mdna:68]

[0001437749-21-025699:mdna:69]
Legal Proceedings

[0001437749-21-025699:mdna:70]
We are involved in legal and administrative proceedings and claims of various types. See Part II, Item 1, “Legal Proceedings,” for additional information. We record a liability in our consolidated financial statements for these matters when a loss is known or considered probable and the amount can be reasonably estimated. We review these estimates each accounting period as additional information is known and adjust the loss provision when appropriate. If a matter is both probable to result in liability and the amounts of loss can be reasonably estimated, we estimate and disclose the possible loss or range of loss to the extent necessary to make the consolidated financial statements not misleading. If the loss is not probable or cannot be reasonably estimated, a liability is not recorded in our consolidated financial statements.

[0001437749-21-025699:mdna:71]
[same as prior period, unchanged from 0001437749-21-018523:mdna:71]

[0001437749-21-025699:mdna:72]
[same as prior period, unchanged from 0001437749-21-018523:mdna:72]

[0001437749-21-025699:mdna:73]
[same as prior period, unchanged from 0001437749-21-018523:mdna:73]

[0001437749-21-025699:mdna:74]
[same as prior period, unchanged from 0001437749-21-018523:mdna:74]

[0001437749-21-025699:mdna:75]
[same as prior period, unchanged from 0001437749-21-018523:mdna:75]

[0001437749-21-025699:mdna:76]
In June 2016, the FASB issued ASU 2016-13, Financial Instruments-Credit Losses (Topic 326): Measurement of Credit Losses on Financial Instruments. The amendments in ASU 2016-13 provide more decision-useful information about the expected credit losses on financial instruments and other commitments to extend credit held by a reporting entity at each reporting date. Following the release of ASU 2019-10 in November 2019, the new effective date, as long as the Company remains a smaller reporting company, would be annual reporting periods beginning after December 15, 2022.   We are currently evaluating the impact, if any, that the adoption of ASU 2016-13 may have on our consolidated financial statements.

[0001437749-21-025699:mdna:77]
In December 2019, the FASB issued ASU 2019-12, Income Taxes (Topic 740): Simplifying the Accounting for Income Taxes. The amendments in ASU 2019-12 provide for simplified accounting to several income tax situations and removal of certain accounting exceptions.  As of April 1, 2021, we have adopted ASU 2019-12 and noted no material impact on our consolidated financial statements.

[0001437749-21-025699:mdna:78]
We do not believe that, outside of those disclosed here, there are any other recently issued accounting pronouncements that will have a material impact on our consolidated financial statements.
