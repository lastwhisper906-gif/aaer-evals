# AMSC notes — 0001437749-21-025699


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0001437749-21-025699:notes:1]
[same as prior period, unchanged from 0001437749-21-018523:notes:1]

[0001437749-21-025699:notes:2]
[same as prior period, unchanged from 0001437749-21-018523:notes:2]

[0001437749-21-025699:notes:3]
[same as prior period, unchanged from 0001437749-21-018523:notes:3]

[0001437749-21-025699:notes:4]
These unaudited condensed consolidated financial statements of the Company have been prepared on a going concern basis in accordance with United States generally accepted accounting principles (“GAAP”) and the Securities and Exchange Commission’s (“SEC”) instructions to Form 10-Q. The going concern basis of presentation assumes that the Company will continue operations and will be able to realize its assets and discharge its liabilities and commitments in the normal course of business. Certain information and footnote disclosures normally included in the financial statements prepared in accordance with GAAP have been condensed or omitted pursuant to those instructions. The year-end condensed balance sheet data was derived from audited financial statements but does not include all disclosures required by GAAP. The unaudited condensed consolidated financial statements, in the opinion of management, reflect all adjustments (consisting of normal recurring adjustments) necessary for a fair statement of the results for the interim periods ended  September 30, 2021 and 2020 and the financial position at  September 30, 2021; however, these results are not necessarily indicative of results which  may be expected for the full year. The interim condensed consolidated financial statements, and notes thereto, should be read in conjunction with the audited consolidated financial statements for the year ended  March 31, 2021, and notes thereto, included in the Company’s Annual Report on Form 10-K for the year ended  March 31, 2021 filed with the SEC on  June 2, 2021.

[0001437749-21-025699:notes:5]
[same as prior period, unchanged from 0001437749-21-018523:notes:5]

[0001437749-21-025699:notes:6]
The Company has historically experienced recurring operating losses and as of  September 30, 2021, the Company had an accumulated deficit of $1,011.1 million. In addition, the Company has historically experienced recurring negative operating cash flows.  At  September 30, 2021, the Company had cash and cash equivalents of $48.5 million. Cash used in operations for the six months ended  September 30, 2021 was $11.7 million.

[0001437749-21-025699:notes:7]
[same as prior period, unchanged from 0001437749-21-018523:notes:7]

[0001437749-21-025699:notes:8]
[same as prior period, unchanged from 0001437749-21-018523:notes:8]

[0001437749-21-025699:notes:9]
[same as prior period, unchanged from 0001437749-21-018523:notes:9]

[0001437749-21-025699:notes:10]
While the COVID-19 pandemic continues to rapidly evolve, the Company is starting to experience inflation pressure in its supply chains and some delays in sourcing materials needed for its products. The Company continues to assess the impact of the COVID-19 pandemic to best mitigate risk and continue the operations of the Company’s business. The extent to which the outbreak impacts the Company’s business, liquidity, results of operations and financial condition will depend on future developments, which are highly uncertain and cannot be predicted with confidence, including new information that  may emerge concerning the severity of the COVID-19 pandemic, the spread of new variations of the virus, the actions to contain it or treat its impact and the effectiveness and adoption of vaccines and treatments, among others.  If the Company, its customers or suppliers experience prolonged shutdowns or other business disruptions, including global supply chain disruptions, the Company’s business, liquidity, results of operations and financial condition are likely to be materially adversely affected, and the Company’s ability to access the capital markets  may be limited.

[0001437749-21-025699:notes:11]
The Company believes that based on the information presented above and its quarterly management assessment, it has sufficient liquidity to fund its operations and capital expenditures for the next twelve months following the issuance of the financial statements for the six months ended  September 30, 2021. The Company’s liquidity is highly dependent on its ability to increase revenues, including its ability to collect revenues under its agreements with Inox, its ability to control its operating costs, and its ability to raise additional capital, if necessary.  The impact of the COVID-19 pandemic on the global financing markets  may reduce the Company's ability to raise additional capital, if necessary, which could negatively impact the Company's liquidity.  There can be no assurance that the Company will be able to continue to raise additional capital, on favorable terms or at all, from other sources or execute on any other means of improving liquidity described above.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001437749-21-025699:notes:12]
[same as prior period, unchanged from 0001437749-21-018523:notes:12]

[0001437749-21-025699:notes:13]
[same as prior period, unchanged from 0001437749-21-018523:notes:13]

[0001437749-21-025699:notes:14]
[same as prior period, unchanged from 0001437749-21-018523:notes:14]

[0001437749-21-025699:notes:15]
Additionally, the Company paid approximately $7.6 million, including $1.9 million of indebtedness secured by the mortgage on the real property as described below, directly to Neeltran lenders at closing to extinguish outstanding Neeltran indebtedness to third parties. Pursuant to the terms of the Real Property Purchase Agreement, AMSC Husky purchased the real property that serves as Neeltran's headquarters for $4.3 million, of which (a) $2.4 million was paid from immediately available funds by AMSC Husky to the selling parties, and (b) $1.9 million was paid directly to TD Bank as full payment for the outstanding indebtedness secured by the mortgage on such real property. The total purchase price of $16.4 million includes cash paid, the fair value of the AMSC Shares issued at closing and the debt payoff on behalf of the sellers as follows (in millions):

[0001437749-21-025699:notes:16]
[same as prior period, unchanged from 0001437749-21-018523:notes:16]

[0001437749-21-025699:notes:17]
The Neeltran Acquisition completed by the Company during the six months ended  September 30, 2021 has been accounted for under the purchase method of accounting in accordance with ASC 805, Business Combinations. The Company allocated the purchase price to the assets acquired and liabilities assumed at their estimated fair values as of the date of Neeltran Acquisition. The excess of the purchase price paid by the Company over the estimated fair value of net assets acquired has been recorded as goodwill. As Neeltran was previously a private company, the adoption of Accounting Standards Codification 842 ("ASC 842") was completed as part of the Neeltran Acquisition. See Note 15 "Leases" for further details. Neeltran had previously adopted Accounting Standards Codification 606, Revenue from Contracts with Customers ("ASC 606") as part of prior year audited financial statements.

[0001437749-21-025699:notes:18]
The following table summarizes the allocation of the purchase price based on the estimated fair value of the assets acquired and liabilities assumed in connection with the Neeltran Acquisition (in millions):

[0001437749-21-025699:notes:19]
[same as prior period, unchanged from 0001437749-21-018523:notes:19]

[0001437749-21-025699:notes:20]
Inventory includes a
     $0.6 million adjustment to step up the inventory balance to fair value consistent with the purchase price allocation. The fair value was based on the estimated selling price of the inventory, less the remaining manufacturing and selling cost and a normal profit margin on those manufacturing and selling efforts. The inventory step up adjustment increased cost of revenue
     $0.6 million in the
     six month period ended
      September 30, 2021 as the inventory was sold. This increase is
     not reflected in the pro forma condensed combined statements of operations because it does
     not have a continuing impact beyond the
     first year.

[0001437749-21-025699:notes:21]
[same as prior period, unchanged from 0001437749-21-018523:notes:21]

[0001437749-21-025699:notes:22]
[same as prior period, unchanged from 0001437749-21-018523:notes:22]

[0001437749-21-025699:notes:23]
[same as prior period, unchanged from 0001437749-21-018523:notes:23]

[0001437749-21-025699:notes:24]
The goodwill represents the value associated with the acquired workforce and expected synergies related to the business combinations of the
      two companies. Goodwill resulting from the Neeltran Acquisition was assigned to the Company's Grid business segment. Goodwill recognized in the Neeltran Acquisition is
      not deductible for tax purposes. This purchase price allocation is preliminary and has
      not been finalized as the analysis on the assets and liabilities acquired, primarily the tax liability
       may require further adjustments to our purchase accounting that could result in a measurement period adjustment that would impact our recorded net assets and goodwill as of
       May 6, 2021. Material changes, if any, to the preliminary allocation summarized above will be reported once the related uncertainties are resolved but
      no later than
       May 6, 2022.  The
      $2.3 million of deferred tax liability is primarily related to inventory step up and intangibles.

[0001437749-21-025699:notes:25]
The results of Neeltran's operations, are included in the Company's consolidated results from the date of the Neeltran Acquisition of
      May 6, 2021, for the
     six months ended
      September 30, 2021. In the unaudited consolidated results for the
     six months ended
      September 30, 2021, Neeltran contributed
     $12.5 million of revenue and
      $0.4 million in net loss for the Company.

[0001437749-21-025699:notes:26]
[same as prior period, unchanged from 0001437749-21-018523:notes:26]

[0001437749-21-025699:notes:27]
[same as prior period, unchanged from 0001437749-21-018523:notes:27]

[0001437749-21-025699:notes:28]
[same as prior period, unchanged from 0001437749-21-018523:notes:28]

[0001437749-21-025699:notes:29]
[same as prior period, unchanged from 0001437749-21-018523:notes:29]

[0001437749-21-025699:notes:30]
[same as prior period, unchanged from 0001437749-21-018523:notes:30]

[0001437749-21-025699:notes:31]
[same as prior period, unchanged from 0001437749-21-018523:notes:31]

[0001437749-21-025699:notes:32]
Total consideration consists of (a) cash of $26.0 million, (b) issuance of the Company's common stock, using $14.23 per share, which was the closing price on the day that the Company acquired NEPSI, and (c) $4.0 million of contingent consideration for the earnout liability valued as of the NEPSI Acquisition Date. NEPSI Acquisition costs of $0.3 million were recorded in selling, general and administrative ("SG&A") costs for the fiscal year ended  March 31, 2021.

[0001437749-21-025699:notes:33]
The fair value of the contingent consideration was determined using a Monte Carlo model and is accounted for as a derivative liability which is revalued at the fair value determined at each subsequent balance sheet date until the contingencies are resolved and the shares to be issued are determined, with the change in fair value recorded in the current period operating loss or (income).  See Note 13, "Contingent Consideration" for further details and a summary of key assumptions used to determine fair value in each period.

[0001437749-21-025699:notes:34]
[same as prior period, unchanged from 0001437749-21-018523:notes:34]

[0001437749-21-025699:notes:35]
[same as prior period, unchanged from 0001437749-21-018523:notes:35]

[0001437749-21-025699:notes:36]
[same as prior period, unchanged from 0001437749-21-018523:notes:36]

[0001437749-21-025699:notes:37]
[same as prior period, unchanged from 0001437749-21-018523:notes:37]

[0001437749-21-025699:notes:38]
[same as prior period, unchanged from 0001437749-21-018523:notes:38]

[0001437749-21-025699:notes:39]
[same as prior period, unchanged from 0001437749-21-018523:notes:39]

[0001437749-21-025699:notes:40]
Goodwill represents the value associated with the acquired workforce and expected synergies related to the business combination of the two companies. Goodwill resulting from the NEPSI Acquisition was assigned to the Company’s Grid business segment.  Goodwill recognized in the NEPSI Acquisition is not deductible for tax purposes. This purchase price allocation is preliminary and has not been finalized as the analysis on the assets and liabilities acquired, primarily the tax related liability  may require further adjustments to our purchase accounting that could result in a measurement period adjustment that would impact the Company's reported net assets and goodwill as of  October 1, 2020. The $1.7 million of deferred tax liability is primarily related to inventory step up and intangibles.

[0001437749-21-025699:notes:41]
[same as prior period, unchanged from 0001437749-21-018523:notes:41]

[0001437749-21-025699:notes:42]
The unaudited pro forma condensed consolidated statement of operations for the
     three and six months ended
      September 30, 2021 and 
     2020 is presented as if the NEPSI Acquisition and Neeltran Acquisition had occurred on
      April 1, 2020.

[0001437749-21-025699:notes:43]
|  |  | Three Months Ended September 30, |  |  | Six Months Ended September 30, |  |
|  |  | 2021 |  |  | 2020 |  |  | 2021 |  |  | 2020 |  |
| Revenues |  | $ | 27,908 |  |  | $ | 32,233 |  |  | $ | 56,158 |  |  | $ | 64,860 |  |
| Operating loss |  |  | (4,346 | ) |  |  | (4,963 | ) |  |  | (11,131 | ) |  |  | (8,591 | ) |
| Net loss |  | $ | (4,548 | ) |  | $ | (3,855 | ) |  | $ | (11,809 | ) |  | $ | (3,746 | ) |
| Net loss per common share |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | (0.17 | ) |  | $ | (0.17 | ) |  | $ | (0.44 | ) |  | $ | (0.16 | ) |
| Diluted |  | $ | (0.17 | ) |  | $ | (0.17 | ) |  | $ | (0.44 | ) |  | $ | (0.16 | ) |
| Shares - basic |  |  | 27,253 |  |  |  | 23,036 |  |  |  | 27,101 |  |  |  | 22,951 |  |
| Shares - diluted |  |  | 27,253 |  |  |  | 23,036 |  |  |  | 27,101 |  |  |  | 22,951 |  |

[0001437749-21-025699:notes:44]
The pro forma amounts include the historical operating results of the Company, NEPSI and Neeltran, with appropriate adjustments that give effect to acquisition related costs, income taxes, intangible amortization resulting from the NEPSI Acquisition and Neeltran Acquisition and certain conforming accounting policies of the Company. The pro forma amounts are
      not necessarily indicative of the operating results that would have occurred if the NEPSI Acquisition and Neeltran Acquisition and related transactions had been completed at the beginning of the applicable periods presented. In addition, the pro forma amounts are
      not necessarily indicative of operating results in future periods.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001437749-21-025699:notes:45]
[same as prior period, unchanged from 0001437749-21-018523:notes:45]

[0001437749-21-025699:notes:46]
The Company’s revenues in its Grid business segment are derived primarily through enabling the transmission and distribution of power, providing planning services that allow it to identify power grid needs and risks, and developing ship protection systems for the U.S. Navy. The Company’s revenues in its Wind business segment are derived primarily through supplying advanced power electronics and control systems, licensing its highly engineered wind turbine designs, and providing extensive customer support services to wind turbine manufacturers. The Company records revenue based on a five-step model in accordance with ASC 606. For its customer contracts, the Company identifies the performance obligations, determines the transaction price, allocates the contract transaction price to the performance obligations, and recognizes the revenue when (or as) control of goods or services is transferred to the customer. In the three and six months ended  September 30, 2021, 86% and 82% of revenue, respectively, was recognized at the point in time when control transferred to the customer, with the remainder being recognized over time. In the three and six months ended  September 30, 2020, 78% and 79% of revenue, respectively, was recognized at the point in time when control transferred to the customer, with the remainder being recognized over time.

[0001437749-21-025699:notes:47]
[same as prior period, unchanged from 0001437749-21-018523:notes:47]

[0001437749-21-025699:notes:48]
The Company's equipment and system product line includes certain contracts which do not meet the requirements of an exchange transaction and therefore do not fall within the scope of ASC 606.  As these non-exchange transaction contracts are considered grant revenue and do not fall within any specific accounting literature, the Company follows guidance within ASC 606 by analogy to recognize grant revenue over time.  In the three and six months ended  September 30, 2021, the Company recorded $0.3 million and $0.8 million in grant revenue, respectively, which is included in the Company’s Grid business segment revenue. In the three and six months ended  September 30, 2020, the Company recorded $0.4 million and $0.8 million in grant revenue, respectively, which is included in the Company's Grid segment revenue.

[0001437749-21-025699:notes:49]
In the Company's service and technology development product line, there are several different types of transactions and each begins with a contract with a customer that summarizes each product sold to a customer, which typically represent distinct performance obligations. The technology development transactions are primarily for activities that have no alternative use and for which a profit can be expected throughout the life of the contract. In these cases, the revenue is recognized over time, but in the instances where a reasonable profit margin cannot be assured throughout the entire contract, the revenue is recognized at a point in time. Each contract's transaction price is allocated to each distinct performance obligation using the respective standalone selling price which is determined primarily using the cost-plus expected margin approach. The ongoing service transactions are for service contracts that provide benefit to the customer simultaneously as the Company performs its obligations, and therefore this revenue is recognized ratably over time throughout the effective period of these contracts. The transaction prices on these contracts are allocated based on an adjusted market approach which is re-assessed annually for reasonableness. The field service transactions include contracts for delivery of goods and completion of services made at the customer's requests, which are not deemed satisfied until the work has been completed and/or the requested goods have been delivered, so all of this revenue is recognized at the point in time when the control changes, and at allocated prices based on the adjusted market approach driven by standard price lists. The royalty transactions are related to certain contract terms on transactions in the Company's equipment and systems product line based on activity as specified in the contracts. The transaction prices of these agreements are calculated based on an adjusted market approach as specified in the contract. The Company reports royalty revenue for usage-based royalties when the sales have occurred. In circumstances when collectability is not assured and a contract does not exist under ASC 606, revenue is deferred until a non-refundable payment has been received for substantially all the amount that is due and there are no further remaining performance obligations.

[0001437749-21-025699:notes:50]
[same as prior period, unchanged from 0001437749-21-018523:notes:50]

[0001437749-21-025699:notes:51]
[same as prior period, unchanged from 0001437749-21-018523:notes:51]

[0001437749-21-025699:notes:52]
[same as prior period, unchanged from 0001437749-21-018523:notes:52]

[0001437749-21-025699:notes:53]
[same as prior period, unchanged from 0001437749-21-018523:notes:53]

[0001437749-21-025699:notes:54]
[same as prior period, unchanged from 0001437749-21-018523:notes:54]

[0001437749-21-025699:notes:55]
[same as prior period, unchanged from 0001437749-21-018523:notes:55]

[0001437749-21-025699:notes:56]
|  |  | Three Months Ended September 30, 2021 |  |  | Six Months Ended September 30, 2021 |  |
| Product Line: |  | Grid |  |  | Wind |  |  | Grid |  |  | Wind |  |
| Equipment and systems |  | $ | 23,031 |  |  | $ | 1,826 |  |  | $ | 44,189 |  |  | $ | 2,860 |  |
| Services and technology development |  |  | 1,588 |  |  |  | 1,463 |  |  |  | 3,930 |  |  |  | 2,349 |  |
| Total |  | $ | 24,619 |  |  | $ | 3,289 |  |  | $ | 48,119 |  |  | $ | 5,209 |  |
| Region: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas |  | $ | 18,115 |  |  | $ | 59 |  |  | $ | 40,760 |  |  | $ | 78 |  |
| Asia Pacific |  |  | 3,269 |  |  |  | 3,220 |  |  |  | 3,867 |  |  |  | 5,091 |  |
| EMEA |  |  | 3,235 |  |  |  | 10 |  |  |  | 3,492 |  |  |  | 40 |  |
| Total |  | $ | 24,619 |  |  | $ | 3,289 |  |  | $ | 48,119 |  |  | $ | 5,209 |  |

[0001437749-21-025699:notes:57]
|  |  | Three Months Ended September 30, 2020 |  |  | Six Months Ended September 30, 2020 |  |
| Product Line: |  | Grid |  |  | Wind |  |  | Grid |  |  | Wind |  |
| Equipment and systems |  | $ | 15,261 |  |  | $ | 4,059 |  |  | $ | 31,798 |  |  | $ | 6,676 |  |
| Services and technology development |  |  | 1,086 |  |  |  | 711 |  |  |  | 2,264 |  |  |  | 1,591 |  |
| Total |  | $ | 16,347 |  |  | $ | 4,770 |  |  | $ | 34,062 |  |  | $ | 8,267 |  |
| Region: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas |  | $ | 15,677 |  |  | $ | 30 |  |  | $ | 26,231 |  |  | $ | 42 |  |
| Asia Pacific |  |  | 370 |  |  |  | 4,734 |  |  |  | 6,385 |  |  |  | 8,002 |  |
| EMEA |  |  | 300 |  |  |  | 6 |  |  |  | 1,446 |  |  |  | 223 |  |
| Total |  | $ | 16,347 |  |  | $ | 4,770 |  |  | $ | 34,062 |  |  | $ | 8,267 |  |

[0001437749-21-025699:notes:58]
As of  September 30, 2021, and 2020, the Company’s contract assets and liabilities primarily relate to the timing differences between cash received from a customer in connection with contractual rights to invoicing and the timing of revenue recognition following completion of performance obligations. The Company's accounts receivable balance is made up entirely of customer contract related balances. Changes in the Company’s contract assets, which are included in “Unbilled accounts receivable” and “Deferred program costs” (see Note 8, “Accounts Receivable” and Note 9, “Inventory” for a reconciliation to the condensed consolidated balance sheets) and "Contract liabilities", which are included in the current portion and long-term portion of "Deferred revenue" in the Company’s condensed consolidated balance sheets, are as follows (in thousands):

[0001437749-21-025699:notes:59]
|  |  | Unbilled Accounts Receivable |  |  | Deferred Program Costs |  |  | Contract Liabilities |  |
| Beginning balance as of March 31, 2021 |  | $ | 5,765 |  |  | $ | 977 |  |  | $ | 21,257 |  |
| Increases for costs incurred to fulfill performance obligations |  |  | — |  |  |  | 2,277 |  |  |  | — |  |
| Increase for balances acquired |  |  | — |  |  |  | 634 |  |  |  | 10,048 |  |
| Increase (decrease) due to customer billings |  |  | (4,807 | ) |  |  | — |  |  |  | 34,344 |  |
| Decrease due to cost recognition on completed performance obligations |  |  | — |  |  |  | (3,055 | ) |  |  | — |  |
| Increase (decrease) due to recognition of revenue based on transfer of control of performance obligations |  |  | 7,838 |  |  |  | — |  |  |  | (34,169 | ) |
| Other changes and FX impact |  |  | — |  |  |  | (3 | ) |  |  | 38 |  |
| Ending balance as of September 30, 2021 |  | $ | 8,796 |  |  | $ | 830 |  |  | $ | 31,518 |  |

[0001437749-21-025699:notes:60]
|  |  | Unbilled Accounts Receivable |  |  | Deferred Program Costs |  |  | Contract Liabilities |  |
| Beginning balance as of March 31, 2020 |  | $ | 5,711 |  |  | $ | 1,631 |  |  | $ | 26,142 |  |
| Increases for costs incurred to fulfill performance obligations |  |  | — |  |  |  | 3,279 |  |  |  | — |  |
| Increase (decrease) due to customer billings |  |  | (5,929 | ) |  |  | — |  |  |  | 23,931 |  |
| Decrease due to cost recognition on completed performance obligations |  |  | — |  |  |  | (3,314 | ) |  |  | — |  |
| Increase (decrease) due to recognition of revenue based on transfer of control of performance obligations |  |  | 6,186 |  |  |  | — |  |  |  | (28,678 | ) |
| Other changes and FX impact |  |  | 0 |  |  |  | 18 |  |  |  | 561 |  |
| Ending balance as of September 30, 2020 |  | $ | 5,968 |  |  | $ | 1,614 |  |  | $ | 21,956 |  |

[0001437749-21-025699:notes:61]
The Company’s remaining performance obligations represent the unrecognized revenue value of the Company’s contractual commitments. The Company’s performance obligations  may vary significantly each reporting period based on the timing of major new contractual commitments. As of  September 30, 2021, the Company had outstanding performance obligations on existing contracts under ASC 606 to be recognized in the next twelve months of approximately $89.5 million. There are also approximately $10.5 million of outstanding performance obligations to be recognized over a period of thirteen to sixty months. The remaining performance obligations are subject to customer actions and therefore the timing of revenue recognition cannot be reasonably estimated. The twelve-month performance obligations include anticipated shipments to Inox based on the twelve-month rolling forecast provided by Inox on the multi-year supply contract. The quantities specified in any forecast provided by Inox related to the multi-year supply contract are firm and irrevocable for the first three months of a twelve-month rolling forecast. The timing of the performance obligations beyond the twelve-month forecast provided by Inox are not determinable and therefore are not included in the total remaining performance obligations.

[0001437749-21-025699:notes:62]
The following table sets forth customers who represented 10% or more of the Company’s total revenues for the three and six months ended  September 30, 2021 and 2020:

[0001437749-21-025699:notes:63]
|  |  |  | Three Months Ended |  |  | Six Months Ended |  |
|  | Reportable |  | September 30, |  |  | September 30, |  |
|  | Segment |  | 2021 |  |  | 2020 |  |  | 2021 |  |  | 2020 |  |
| EPC Services | Grid |  | <10% |  |  |  | 12 | % |  |  | <10% |  |  |  | 18 | % |
| Inox Wind Limited | Wind |  | 10 | % |  |  | <10% |  |  |  | <10% |  |  |  | <10% |  |
| Tri-State Generation and Transmission Association, Inc. | Grid |  | 12 | % |  |  | — |  |  |  | <10% |  |  |  | — |  |
| Micron Technology | Grid |  | <10% |  |  |  | <10% |  |  |  | 10 | % |  |  | <10% |  |
| Reed & Reed Inc. | Grid |  |  | <10% |  |  | 25 | % |  |  | <10% |  |  |  | 12 | % |
| Siemens Gamesa Renewable Energy Pty. Ltd. | Grid |  | <10% |  |  |  | <10% |  |  |  | <10% |  |  |  | 13 | % |


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001437749-21-025699:notes:64]
[same as prior period, unchanged from 0001437749-21-018523:notes:64]

[0001437749-21-025699:notes:65]
The Company accounts for its stock-based compensation at fair value. The following table summarizes stock-based compensation expense by financial statement line item for the three and six months ended  September 30, 2021 and 2020 (in thousands):

[0001437749-21-025699:notes:66]
|  |  | Three Months Ended September 30, |  |  | Six Months Ended September 30, |  |
|  |  | 2021 |  |  | 2020 |  |  | 2021 |  |  | 2020 |  |
| Cost of revenues |  | $ | 21 |  |  | $ | 30 |  |  | $ | 112 |  |  | $ | 59 |  |
| Research and development |  |  | 192 |  |  |  | 161 |  |  |  | 439 |  |  |  | 291 |  |
| Selling, general and administrative |  |  | 888 |  |  |  | 658 |  |  |  | 1,842 |  |  |  | 1,408 |  |
| Total |  | $ | 1,101 |  |  | $ | 849 |  |  | $ | 2,393 |  |  | $ | 1,758 |  |

[0001437749-21-025699:notes:67]
The Company issued 47,604 shares of immediately vested common stock, all of which were issued in lieu of cash bonuses, during the three months ended  September 30, 2021, and 166,648 shares of immediately vested common stock, of which 158,356 shares were issued in-lieu of cash bonuses and 309,700 shares of restricted stock awards during the six months ended  September 30, 2021. The Company issued 32,500 shares of restricted stock awards during the three months ended  September 30, 2020, and 27,341 shares of immediately vested common stock and 688,167 shares of restricted stock awards during the six months ended  September 30, 2020.  These restricted stock awards generally vest over 2-3 years.  Awards for restricted stock include both time-based and performance-based awards.  For options and restricted stock awards that vest upon the passage of time, expense is being recorded over the vesting period.  Performance-based awards are expensed over the requisite service period based on probability of achievement.

[0001437749-21-025699:notes:68]
The estimated fair value of the Company’s stock-based awards, less expected annual forfeitures, is amortized over the awards’ service period. The Company has no unrecognized compensation cost for unvested outstanding stock options at  September 30, 2021. The total unrecognized compensation cost for unvested outstanding restricted stock was $6.8 million at  September 30, 2021. This expense will be recognized over a weighted-average expense period of approximately 1.7 years.

[0001437749-21-025699:notes:69]
The Company did not grant any stock options during the three and six months ended  September 30, 2021 or  September 30, 2020.


## us-gaap:EarningsPerShareTextBlock

[0001437749-21-025699:notes:70]
[same as prior period, unchanged from 0001437749-21-018523:notes:70]

[0001437749-21-025699:notes:71]
Basic net loss per share (“EPS”) is computed by dividing net loss by the weighted-average number of common shares outstanding for the period. Where applicable, diluted EPS is computed by dividing the net loss by the weighted-average number of common shares and dilutive common equivalent shares outstanding during the period, calculated using the treasury stock method. Common equivalent shares include the effect of restricted stock, exercise of stock options and warrants and contingently issuable shares. Stock options and warrants that are out-of-the-money with exercise prices greater than the average market price of the underlying common shares and shares of performance-based restricted stock where the contingency was not met are excluded from the computation of diluted EPS as the effect of their inclusion would be anti-dilutive.  For the three and six months ended  September 30, 2021, 1.1 million shares were not included in the calculation of diluted EPS.  Of these, 1.0 million relate to shares tied to the derivative liability for which the contingency has not yet been met, and 0.1 million relate to outstanding stock options as they were considered anti-dilutive. For the three and six months ended  September 30, 2020, 0.1 million shares related to outstanding stock options were not included in the calculation of diluted EPS as they were considered anti-dilutive.

[0001437749-21-025699:notes:72]
The following table reconciles the numerators and denominators of the earnings per share calculation for the three and six months ended  September 30, 2021 and 2020 (in thousands, except per share data):

[0001437749-21-025699:notes:73]
|  |  | Three Months Ended September 30, |  |  | Six Months Ended September 30, |  |
|  |  | 2021 |  |  | 2020 |  |  | 2021 |  |  | 2020 |  |
| Numerator: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net loss |  | $ | (4,434 | ) |  | $ | (3,712 | ) |  | $ | (9,837 | ) |  | $ | (7,129 | ) |
| Denominator: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Weighted-average shares of common stock outstanding |  |  | 28,360 |  |  |  | 23,057 |  |  |  | 28,141 |  |  |  | 22,943 |  |
| Weighted-average shares subject to repurchase |  |  | (1,108 | ) |  |  | (1,197 | ) |  |  | (1,101 | ) |  |  | (1,168 | ) |
| Shares used in per-share calculation ― basic |  |  | 27,252 |  |  |  | 21,860 |  |  |  | 27,040 |  |  |  | 21,775 |  |
| Shares used in per-share calculation ― diluted |  |  | 27,252 |  |  |  | 21,860 |  |  |  | 27,040 |  |  |  | 21,775 |  |
| Net loss per share ― basic |  | $ | (0.16 | ) |  | $ | (0.17 | ) |  | $ | (0.36 | ) |  | $ | (0.33 | ) |
| Net loss per share ― diluted |  | $ | (0.16 | ) |  | $ | (0.17 | ) |  | $ | (0.36 | ) |  | $ | (0.33 | ) |


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001437749-21-025699:notes:74]
[same as prior period, unchanged from 0001437749-21-018523:notes:74]

[0001437749-21-025699:notes:75]
[same as prior period, unchanged from 0001437749-21-018523:notes:75]

[0001437749-21-025699:notes:76]
[same as prior period, unchanged from 0001437749-21-018523:notes:76]

[0001437749-21-025699:notes:77]
[same as prior period, unchanged from 0001437749-21-018523:notes:77]

[0001437749-21-025699:notes:78]
|  |  | Goodwill |  |
| March 31, 2021 |  | $ | 34,634 |  |
| Neeltran Acquisition |  |  | 8,837 |  |
| Less impairment loss |  |  | - |  |
| September 30, 2021 |  | $ | 43,471 |  |

[0001437749-21-025699:notes:79]
The Company did not identify any triggering events in the three and six months ended  September 30, 2021 that would require interim impairment testing of goodwill.

[0001437749-21-025699:notes:80]
[same as prior period, unchanged from 0001437749-21-018523:notes:80]

[0001437749-21-025699:notes:81]
Intangible assets at  September 30, 2021 and  March 31, 2021 consisted of the following (in thousands):

[0001437749-21-025699:notes:82]
|  |  | September 30, 2021 |  |  | March 31, 2021 |  |  |  |  |  |
|  |  | Gross Amount |  |  | Accumulated Amortization |  |  | Net Book Value |  |  | Gross Amount |  |  | Accumulated Amortization |  |  | Net Book Value |  |  | Estimated Useful Life |  |
| Backlog |  | $ | 681 |  |  | $ | (552 | ) |  | $ | 129 |  |  | $ | 600 |  |  | $ | (475 | ) |  | $ | 125 |  |  |  | 2 |  |
| Trade name |  |  | 1,800 |  |  |  | — |  |  |  | 1,800 |  |  |  | 600 |  |  |  | — |  |  |  | 600 |  |  |  | Indefinite |  |
| Customer relationships |  |  | 9,600 |  |  |  | (1,710 | ) |  |  | 7,890 |  |  |  | 6,100 |  |  |  | (739 | ) |  |  | 5,361 |  |  |  | 7 |  |
| Core technology and know-how |  |  | 5,970 |  |  |  | (3,144 | ) |  |  | 2,826 |  |  |  | 5,970 |  |  |  | (2,903 | ) |  |  | 3,067 |  |  |  | 5-10 |  |
| Intangible assets |  | $ | 18,051 |  |  | $ | (5,406 | ) |  | $ | 12,645 |  |  | $ | 13,270 |  |  | $ | (4,117 | ) |  | $ | 9,153 |  |  |  |  |  |

[0001437749-21-025699:notes:83]
The Company recorded intangible amortization expense related to customer relationship and core technology and know-how of $0.6 million and $1.2 million, in the three and six months ended  September 30, 2021, respectively, and $0.1 million and $0.2 million in the three and six months ended  September 30, 2020, respectively. Additionally, the Company recorded intangible amortization related to backlog that is reported in cost of revenues of less than $0.1 million and $0.1 million in the three and six months ended  September 30, 2021, respectively.

[0001437749-21-025699:notes:84]
[same as prior period, unchanged from 0001437749-21-018523:notes:84]

[0001437749-21-025699:notes:85]
| Years ended March 31, |  | Total |  |
| 2022 |  |  | 1,358 |  |
| 2023 |  |  | 2,772 |  |
| 2024 |  |  | 2,152 |  |
| 2025 |  |  | 1,648 |  |
| 2026 |  |  | 1,221 |  |
| Thereafter |  |  | 1,694 |  |
| Total |  | $ | 10,845 |  |

[0001437749-21-025699:notes:86]
[same as prior period, unchanged from 0001437749-21-018523:notes:86]


## us-gaap:FairValueDisclosuresTextBlock

[0001437749-21-025699:notes:87]
[same as prior period, unchanged from 0001437749-21-018523:notes:87]

[0001437749-21-025699:notes:88]
[same as prior period, unchanged from 0001437749-21-018523:notes:88]

[0001437749-21-025699:notes:89]
[same as prior period, unchanged from 0001437749-21-018523:notes:89]

[0001437749-21-025699:notes:90]
The Company provides a gross presentation of activity within Level 3 measurement roll-forward and details of transfers in and out of Level 1 and 2 measurements.  A change in the hierarchy of an investment from its current level is reflected in the period during which the pricing methodology of such investment changes.  Disclosure of the transfer of securities from Level 1 to Level 2 or Level 3 is made in the event that the related security is significant to total cash and investments.  The Company did not have any transfers of assets and liabilities from Level 1, Level 2 or Level 3 of the fair value measurement hierarchy during the six months ended  September 30, 2021.

[0001437749-21-025699:notes:91]
[same as prior period, unchanged from 0001437749-21-018523:notes:91]

[0001437749-21-025699:notes:92]
[same as prior period, unchanged from 0001437749-21-018523:notes:92]

[0001437749-21-025699:notes:93]
[same as prior period, unchanged from 0001437749-21-018523:notes:93]

[0001437749-21-025699:notes:94]
[same as prior period, unchanged from 0001437749-21-018523:notes:94]

[0001437749-21-025699:notes:95]
[same as prior period, unchanged from 0001437749-21-018523:notes:95]

[0001437749-21-025699:notes:96]
Marketable securities consist of certificates of deposit that are measured using such inputs as quoted prices and are classified within Level 1 of the valuation hierarchy. The Company determines the appropriate classification of its marketable securities at the time of purchase and re-evaluates such classification as of each balance sheet date.  All marketable securities are considered available for sale and are carried at fair value. Changes in fair value are recorded to other income (expense), net.  The Company had no outstanding marketable securities as of  September 30, 2021 and the Company recognized no change in the three and six months ended  September 30, 2021. The Company recognized $0.2 million and $0.1 million in unrealized losses on marketable securities, which is recorded in other income (expense), net, for the three and six months ended  September 30, 2020 and less than a $0.1 million gain which was recognized during the three and six months ended  September 30, 2020 upon the sale of one of the certificates of deposit. The Company periodically reviews the realizability of each short and long term marketable security when impairment indicators exist with respect to the security. If other than temporary impairment of value of the security exists, the carrying value of the security is written down to its estimated fair value.

[0001437749-21-025699:notes:97]
[same as prior period, unchanged from 0001437749-21-018523:notes:97]

[0001437749-21-025699:notes:98]
Contingent consideration relates to the earnout payment set forth in the NEPSI Stock Purchase Agreement that provides that the selling stockholders  may receive up to an additional 1,000,000 shares of common stock of the Company upon the achievement of certain specified revenue objectives over varying periods of up to four years following the NEPSI Acquisition Date. See Note 13, "Contingent Consideration" and Note 2, “Acquisitions” for further discussion. The Company relied on a Monte Carlo method to determine the fair value of the contingent consideration on the NEPSI Acquisition Date and will continue to revalue the fair value of the contingent consideration using the same method at each subsequent balance sheet date until the contingencies are resolved and the shares to be issued are determined, with the change in fair value recorded in the current period operating loss.

[0001437749-21-025699:notes:99]
The following table provides the assets and liabilities carried at fair value on a recurring basis, measured as of  September 30, 2021 and  March 31, 2021 (in thousands):

[0001437749-21-025699:notes:100]
|  |  | Total Carrying Value |  |  | Quoted Prices in Active Markets (Level 1) |  |  | Significant Other Observable Inputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |
| September 30, 2021: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash equivalents |  | $ | 20,108 |  |  | $ | 20,108 |  |  | $ | — |  |  | $ | — |  |
| Marketable securities |  | $ | - |  |  | $ | - |  |  | $ | — |  |  | $ | — |  |
| Derivative liabilities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Contingent consideration |  | $ | 4,720 |  |  | $ | — |  |  | $ | — |  |  | $ | 4,720 |  |

[0001437749-21-025699:notes:101]
[same as prior period, unchanged from 0001437749-21-018523:notes:101]

[0001437749-21-025699:notes:102]
[same as prior period, unchanged from 0001437749-21-018523:notes:102]

[0001437749-21-025699:notes:103]
|  |  | Acquisition Contingent Consideration |  |
| Balance at March 31, 2021 |  | $ | 7,050 |  |
| Change in fair value |  |  | (2,330 | ) |
| Balance at September 30, 2021 |  | $ | 4,720 |  |


## amsc:AccountsReceivableTextBlock

[0001437749-21-025699:notes:104]
[same as prior period, unchanged from 0001437749-21-018523:notes:104]

[0001437749-21-025699:notes:105]
Accounts receivable at  September 30, 2021 and  March 31, 2021 consisted of the following (in thousands):

[0001437749-21-025699:notes:106]
|  |  | September 30, 2021 |  |  | March 31, 2021 |  |
| Accounts receivable (billed) |  | $ | 16,381 |  |  | $ | 7,502 |  |
| Accounts receivable (unbilled) |  |  | 8,796 |  |  |  | 5,765 |  |
| Accounts receivable, net |  | $ | 25,177 |  |  | $ | 13,267 |  |


## us-gaap:InventoryDisclosureTextBlock

[0001437749-21-025699:notes:107]
[same as prior period, unchanged from 0001437749-21-018523:notes:107]

[0001437749-21-025699:notes:108]
Inventory, net of reserves, at  September 30, 2021 and  March 31, 2021 consisted of the following (in thousands):

[0001437749-21-025699:notes:109]
|  |  | September 30, 2021 |  |  | March 31, 2021 |  |
| Raw materials |  | $ | 11,396 |  |  | $ | 8,255 |  |
| Work-in-process |  |  | 7,533 |  |  |  | 3,297 |  |
| Finished goods |  |  | 1,815 |  |  |  | 777 |  |
| Deferred program costs |  |  | 830 |  |  |  | 977 |  |
| Net inventory |  | $ | 21,574 |  |  | $ | 13,306 |  |

[0001437749-21-025699:notes:110]
The Company recorded inventory write-downs of $0.6 million and $0.5 million for the three months ended  September 30, 2021, and 2020, respectively. The Company recorded inventory write-downs of $1.2 million and $1.3 million for the six months ended  September 30, 2021 and 2020, respectively.  These write-downs were based on the Company's evaluation of its inventory on hand for excess quantities and obsolescence.

[0001437749-21-025699:notes:111]
Deferred program costs as of  September 30, 2021, and  March 31, 2021, primarily represent costs incurred on programs where the Company needs to complete performance obligations before the related revenue and costs will be recognized.


## us-gaap:PropertyPlantAndEquipmentDisclosureTextBlock

[0001437749-21-025699:notes:112]
[same as prior period, unchanged from 0001437749-21-018523:notes:112]

[0001437749-21-025699:notes:113]
The cost and accumulated depreciation of property, plant and equipment at  September 30, 2021 and  March 31, 2021 are as follows (in thousands):

[0001437749-21-025699:notes:114]
|  |  | September 30, 2021 |  |  | March 31, 2021 |  |
| Construction in progress - equipment |  | $ | 432 |  |  | $ | 220 |  |
| Land |  |  | 980 |  |  |  | 270 |  |
| Building |  |  | 5,270 |  |  |  | 1,630 |  |
| Equipment and software |  |  | 43,714 |  |  |  | 41,652 |  |
| Finance lease - right of use asset |  |  | 11 |  |  |  | — |  |
| Furniture and fixtures |  |  | 1,385 |  |  |  | 1,333 |  |
| Leasehold improvements |  |  | 6,523 |  |  |  | 6,308 |  |
| Property, plant and equipment, gross |  |  | 58,315 |  |  |  | 51,413 |  |
| Less accumulated depreciation |  |  | (43,704 | ) |  |  | (42,416 | ) |
| Property, plant and equipment, net |  | $ | 14,611 |  |  | $ | 8,997 |  |

[0001437749-21-025699:notes:115]
Depreciation expense was $0.7 million and $0.9 million for the three months ended  September 30, 2021 and 2020, respectively. Depreciation expense was $1.3 million and $1.8 million for the six months ended  September 30, 2021 and 2020, respectively. The increase in land and building relates to the property added as part of the Neeltran Acquisition.


## us-gaap:AccountsPayableAndAccruedLiabilitiesDisclosureTextBlock

[0001437749-21-025699:notes:116]
[same as prior period, unchanged from 0001437749-21-018523:notes:116]

[0001437749-21-025699:notes:117]
Accounts payable and accrued expenses at  September 30, 2021 and  March 31, 2021 consisted of the following (in thousands):

[0001437749-21-025699:notes:118]
|  |  | September 30, 2021 |  |  | March 31, 2021 |  |
| Accounts payable |  | $ | 14,920 |  |  | $ | 5,353 |  |
| Accrued inventories in-transit |  |  | 1,772 |  |  |  | 1,460 |  |
| Accrued other miscellaneous expenses |  |  | 2,993 |  |  |  | 2,369 |  |
| Advanced deposits |  |  | 1,479 |  |  |  | 1,035 |  |
| Accrued compensation |  |  | 3,932 |  |  |  | 7,018 |  |
| Income taxes payable |  |  | 640 |  |  |  | 522 |  |
| Accrued product warranty |  |  | 2,155 |  |  |  | 2,053 |  |
| Total |  | $ | 27,891 |  |  | $ | 19,810 |  |

[0001437749-21-025699:notes:119]
[same as prior period, unchanged from 0001437749-21-018523:notes:119]

[0001437749-21-025699:notes:120]
[same as prior period, unchanged from 0001437749-21-018523:notes:120]

[0001437749-21-025699:notes:121]
|  |  | Three Months Ended September 30, |  |  | Six Months Ended September 30, |  |
|  |  | 2021 |  |  | 2020 |  |  | 2021 |  |  | 2020 |  |
| Balance at beginning of period |  | $ | 2,187 |  |  | $ | 2,168 |  |  | $ | 2,053 |  |  | $ | 2,015 |  |
| Acquired warranty obligations |  |  | - |  |  |  | — |  |  |  | 248 |  |  |  | — |  |
| Change in accruals for warranties during the period |  |  | 206 |  |  |  | 148 |  |  |  | 314 |  |  |  | 384 |  |
| Settlements during the period |  |  | (238 | ) |  |  | (207 | ) |  |  | (460 | ) |  |  | (290 | ) |
| Balance at end of period |  | $ | 2,155 |  |  | $ | 2,109 |  |  | $ | 2,155 |  |  | $ | 2,109 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0001437749-21-025699:notes:122]
[same as prior period, unchanged from 0001437749-21-018523:notes:122]

[0001437749-21-025699:notes:123]
The Company recorded an income tax expense of $0.2 million and income tax benefit of $1.9 million in the three and six months ended  September 30, 2021, respectively. The Company recorded income tax expense of $0.2 million and $0.4 million in the three and six months ended  September 30, 2020, respectively.

[0001437749-21-025699:notes:124]
As a result of a difference in book and tax basis related to the intangible assets acquired in the Neeltran Acquisition (see Note 2, "Acquisitions"), the Company recorded a deferred tax liability of $2.3 million. As a result, the Company was able to benefit from additional deferred tax assets and therefore released a corresponding valuation allowance of $2.3 million during the six months ended  September 30, 2021.  The purchase price allocation is preliminary and has not been finalized as the analysis on the assets and liabilities acquired, primarily the tax related liability,  may require further adjustments to the Company's purchase accounting that could result in measurement period adjustments that would impact the Company's reported net assets and goodwill as of  May 6, 2021. Material changes, if any, to the preliminary allocation summarized in Note 2, "Acquisitions" will be reported once the related uncertainties are resolved, but no later than  May 6, 2022.  Goodwill recognized in the Neeltran Acquisition and the NEPSI Acquisition is not deductible for tax purposes.

[0001437749-21-025699:notes:125]
Accounting for income taxes requires a two-step approach to recognizing and measuring uncertain tax positions.  The first step is to evaluate the tax position for recognition by determining if, based on the technical merits, it is more likely than not the position will be sustained upon audit, including resolution of related appeals or litigation processes, if any.  The second step is to measure the tax benefit as the largest amount that is more than 50% likely to be realized upon ultimate settlement.  The Company re-evaluates these uncertain tax positions on a quarterly basis.  The evaluation is based on factors including, but not limited to, changes in facts or circumstances, changes in tax law, effectively settled issues under audit and new audit activity.  Any changes in these factors could result in the recognition of a tax benefit or an additional charge to the tax provision.  The Company did not identify any uncertain tax positions in the six months ended  September 30, 2021 and did not have any gross unrecognized tax benefits as of  September 30, 2021.


## amsc:BusinessCombinationContingentConsiderationTextBlock

[0001437749-21-025699:notes:126]
[same as prior period, unchanged from 0001437749-21-018523:notes:126]

[0001437749-21-025699:notes:127]
[same as prior period, unchanged from 0001437749-21-018523:notes:127]

[0001437749-21-025699:notes:128]
[same as prior period, unchanged from 0001437749-21-018523:notes:128]

[0001437749-21-025699:notes:129]
|  |  | September 30, |  |  | June 30, |  |  |  |  |  |
| Fiscal Year 2021 |  | 2021 |  |  | 2021 |  |  |  |  |  |
| Revenue risk premium |  |  | 6.60 | % |  |  | 6.60 | % |  |  |  |  |
| Revenue volatility |  |  | 30 | % |  |  | 30 | % |  |  |  |  |
| Stock Price |  | $ | 14.58 |  |  | $ | 17.39 |  |  |  |  |  |
| Payment delay (days) |  |  | 80 |  |  |  | 80 |  |  |  |  |  |
| Fair value |  |  | 4.7 |  |  |  | 7.2 |  |  |  |  |  |
|  |  | March 31, |  |  | December 31, |  |  | October 1, |  |
| Fiscal Year 2020 |  | 2021 |  |  | 2020 |  |  | 2020 |  |
| Revenue risk premium |  |  | 6.70 | % |  |  | 6.90 | % |  |  | 7.10 | % |
| Revenue volatility |  |  | 30 | % |  |  | 30 | % |  |  | 30 | % |
| Stock Price |  | $ | 18.96 |  |  | $ | 23.42 |  |  | $ | 14.23 |  |
| Payment delay (days) |  |  | 80 |  |  |  | 80 |  |  |  | — |  |
| Fair value |  |  | 7.1 |  |  |  | 6.7 |  |  |  | 4.0 |  |

[0001437749-21-025699:notes:130]
The Company recorded a net gain of $2.4 million and $2.3 million resulting from the decrease in the fair value of the contingent consideration in the three and six months ended  September 30, 2021, respectively.


## us-gaap:DebtDisclosureTextBlock

[0001437749-21-025699:notes:131]
14. Debt

[0001437749-21-025699:notes:132]
As part of the Neeltran Acquisition, the Company identified four equipment financing agreements that Neeltran had entered into prior to the acquisition on  May 6, 2021. The Company determined to account for these agreements as a debt transaction and recorded current and long-term debt liabilities of $0.1 million each during the six months ended  September 30, 2021.


## us-gaap:LesseeOperatingLeasesTextBlock

[0001437749-21-025699:notes:133]
[same as prior period, unchanged from 0001437749-21-018523:notes:133]

[0001437749-21-025699:notes:134]
[same as prior period, unchanged from 0001437749-21-018523:notes:134]

[0001437749-21-025699:notes:135]
[same as prior period, unchanged from 0001437749-21-018523:notes:135]

[0001437749-21-025699:notes:136]
Following the Neeltran Acquisition, the Company evaluated all open Neeltran contracts at the date of the acquisition to determine if any applied under ASC 842 as Neeltran, a private company, had deferred adopting ASC 842 prior to the Neeltran Acquisition, as permitted. The Company identified nine lease contracts with terms greater than twelve months and evaluated them under ASC 842 guidance. As part of the implementation, the Company identified one lease contract that classified as a financing lease. The Company does not expect a material impact to the financial statements on an ongoing basis resulting from the adoption of the ASC 842 standard for the Neeltran business and Neeltran will follow the existing policies below.

[0001437749-21-025699:notes:137]
[same as prior period, unchanged from 0001437749-21-018523:notes:137]

[0001437749-21-025699:notes:138]
[same as prior period, unchanged from 0001437749-21-018523:notes:138]

[0001437749-21-025699:notes:139]
[same as prior period, unchanged from 0001437749-21-018523:notes:139]

[0001437749-21-025699:notes:140]
[same as prior period, unchanged from 0001437749-21-018523:notes:140]

[0001437749-21-025699:notes:141]
As part of the adoption of ASC 842 at Neeltran, the Company identified one lease contract that is classified as a financing lease. In  February 2020, Neeltran entered into a contract to lease a copy machine for an initial term of 39 months, or through  May 2023. The Company concluded that the lease should be classified and accounted for as a finance lease as the total value of the lease payments are greater than fair value of the asset. Accordingly, on  May 6, 2021, the Company recognized a finance lease right-of-use asset and a finance lease liability of $13.2 thousand on the Neeltran opening balance sheet. As of  September 30, 2021, the right-of-use asset related to the finance lease was $10.7 thousand, net of accumulated amortization of $2.5 thousand, and is included in the property and equipment, net on the Company's consolidated balance sheet.

[0001437749-21-025699:notes:142]
[same as prior period, unchanged from 0001437749-21-018523:notes:142]

[0001437749-21-025699:notes:143]
Supplemental balance sheet information related to leases at  September 30, 2021, and  March 31, 2021 are as follows (in thousands):

[0001437749-21-025699:notes:144]
|  |  | September 30, 2021 |  |  | March 31, 2021 |  |
| Leases: |  |  |  |  |  |  |  |  |
| Right-of-use assets - Financing |  | $ | 11 |  |  |  | — |  |
| Right-of-use assets - Operating |  |  | 3,588 |  |  |  | 3,747 |  |
| Total right-of-use assets |  |  | 3,599 |  |  |  | 3,747 |  |
| Lease liabilities - ST Financing |  | $ | 5 |  |  |  | — |  |
| Lease liabilities - ST Operating |  |  | 700 |  |  |  | 612 |  |
| Lease liabilities - LT Financing |  |  | 5 |  |  |  | — |  |
| Lease liabilities - LT Operating |  |  | 3,007 |  |  |  | 3,246 |  |
| Total lease liabilities |  |  | 3,717 |  |  |  | 3,858 |  |
| Weighted-average remaining lease term |  |  | 5.29 |  |  |  | 5.82 |  |
| Weighted-average discount rate |  |  | 6.58 | % |  |  | 6.72 | % |

[0001437749-21-025699:notes:145]
The costs related to the Company's finance lease are not material. The costs related to the Company's operating leases for the three and six months ended  September 30, 2021, and 2020 are as follows (in thousands):

[0001437749-21-025699:notes:146]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | September 30, 2021 |  |  | September 30, 2021 |  |
| Operating Leases: |  |  |  |  |  |  |  |  |
| Operating lease costs - fixed |  | $ | 238 |  |  | $ | 469 |  |
| Operating lease costs - variable |  |  | 32 |  |  |  | 63 |  |
| Short-term lease costs |  |  | 65 |  |  |  | 131 |  |
| Total lease costs |  |  | 335 |  |  |  | 663 |  |

[0001437749-21-025699:notes:147]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | September 30, 2020 |  |  | September 30, 2020 |  |
| Operating Leases: |  |  |  |  |  |  |  |  |
| Operating lease costs - fixed |  | $ | 214 |  |  | $ | 392 |  |
| Operating lease costs - variable |  |  | 28 |  |  |  | 55 |  |
| Short-term lease costs |  |  | 510 |  |  |  | 678 |  |
| Total lease costs |  |  | 752 |  |  |  | 1,125 |  |

[0001437749-21-025699:notes:148]
[same as prior period, unchanged from 0001437749-21-018523:notes:148]

[0001437749-21-025699:notes:149]
|  |  | Leases |  |
| Year ended March 31, |  |  |  |  |
| 2022 |  | $ | 460 |  |
| 2023 |  |  | 886 |  |
| 2024 |  |  | 798 |  |
| 2025 |  |  | 674 |  |
| 2026 |  |  | 672 |  |
| Thereafter |  |  | 934 |  |
| Total minimum lease payments |  |  | 4,424 |  |
| Less: interest |  |  | 707 |  |
| Present value of lease liabilities |  |  | 3,717 |  |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001437749-21-025699:notes:150]
16. Commitments and Contingencies

[0001437749-21-025699:notes:151]
Legal Contingencies

[0001437749-21-025699:notes:152]
From time to time, the Company is involved in legal and administrative proceedings and claims of various types. The Company records a liability in its consolidated financial statements for these matters when a loss is known or considered probable and the amount can be reasonably estimated. The Company reviews these estimates each accounting period as additional information is known and adjusts the loss provision when appropriate. If a matter is both probable to result in a liability and the amounts of loss can be reasonably estimated, the Company estimates and discloses the possible loss or range of loss to the extent necessary to make the consolidated financial statements not misleading. If the loss is not probable or cannot be reasonably estimated, a liability is not recorded in its consolidated financial statements.

[0001437749-21-025699:notes:153]
Other

[0001437749-21-025699:notes:154]
The Company enters into long-term construction contracts with customers that require the Company to obtain performance bonds. The Company is required to deposit an amount equivalent to some or all the face amount of the performance bonds into an escrow account until the termination of the bond. When the performance conditions are met, amounts deposited as collateral for the performance bonds are returned to the Company. In addition, the Company has various contractual arrangements in which minimum quantities of goods or services have been committed to be purchased on an annual basis.

[0001437749-21-025699:notes:155]
As of  September 30, 2021, the Company had $6.2 million of restricted cash included in long-term assets and $2.3 million of restricted cash included in current assets. As of  March 31, 2021, the Company had $5.6 million of restricted cash included in long term assets and $2.2 million of restricted cash included in current assets. These amounts included in restricted cash primarily represent deposits to secure letters of credit for various supply contracts and long-term projects, including the irrevocable letter of credit in the amount of $5.0 million to secure certain of the Company's obligations under a subcontract agreement with ComEd.  These deposits are held in interest bearing accounts.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001437749-21-025699:notes:156]
[same as prior period, unchanged from 0001437749-21-018523:notes:156]

[0001437749-21-025699:notes:157]
[same as prior period, unchanged from 0001437749-21-018523:notes:157]

[0001437749-21-025699:notes:158]
[same as prior period, unchanged from 0001437749-21-018523:notes:158]

[0001437749-21-025699:notes:159]
[same as prior period, unchanged from 0001437749-21-018523:notes:159]

[0001437749-21-025699:notes:160]
[same as prior period, unchanged from 0001437749-21-018523:notes:160]

[0001437749-21-025699:notes:161]
|  |  | Three Months Ended September 30, |  |  | Six Months Ended September 30, |  |
|  |  | 2021 |  |  | 2020 |  |  | 2021 |  |  | 2020 |  |
| Revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Grid |  | $ | 24,619 |  |  | $ | 16,347 |  |  | $ | 48,119 |  |  | $ | 34,062 |  |
| Wind |  |  | 3,289 |  |  |  | 4,770 |  |  |  | 5,209 |  |  |  | 8,267 |  |
| Total |  | $ | 27,908 |  |  | $ | 21,117 |  |  | $ | 53,328 |  |  | $ | 42,329 |  |

[0001437749-21-025699:notes:162]
|  |  | Three Months Ended September 30, |  |  | Six Months Ended September 30, |  |
|  |  | 2021 |  |  | 2020 |  |  | 2021 |  |  | 2020 |  |
| Operating Income (loss): |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Grid |  | $ | (5,836 | ) |  | $ | (1,374 | ) |  | $ | (11,180 | ) |  | $ | (2,562 | ) |
| Wind |  |  | 205 |  |  |  | (983 | ) |  |  | (558 | ) |  |  | (2,103 | ) |
| Unallocated corporate gain (expenses) |  |  | 1,329 |  |  |  | (849 | ) |  |  | (63 | ) |  |  | (1,758 | ) |
| Total |  | $ | (4,302 | ) |  | $ | (3,206 | ) |  | $ | (11,801 | ) |  | $ | (6,423 | ) |

[0001437749-21-025699:notes:163]
[same as prior period, unchanged from 0001437749-21-018523:notes:163]

[0001437749-21-025699:notes:164]
Unallocated corporate expenses consist of a gain on contingent consideration of $2.4 million and $2.3 million in the three and six months ended  September 30, 2021, respectively. Additionally, unallocated corporate expenses consist of stock-based compensation expense of $1.1 million and $0.8 million in the three months ended  September 30, 2021, and 2020, respectively and $2.4 million and $1.8 million in the six months ended  September 30, 2021 and 2020, respectively.

[0001437749-21-025699:notes:165]
Total assets for the two business segments as of  September 30, 2021, and  March 31, 2021, are as follows (in thousands):

[0001437749-21-025699:notes:166]
|  |  | September 30, 2021 |  |  | March 31, 2021 |  |
| Grid |  | $ | 118,503 |  |  | $ | 81,253 |  |
| Wind |  |  | 8,221 |  |  |  | 6,098 |  |
| Corporate assets |  |  | 57,649 |  |  |  | 81,515 |  |
| Total |  | $ | 184,373 |  |  | $ | 168,866 |  |


## us-gaap:NewAccountingPronouncementsAndChangesInAccountingPrinciplesTextBlock

[0001437749-21-025699:notes:167]
18. Recent Accounting Pronouncements

[0001437749-21-025699:notes:168]
In  June 2016, the FASB issued ASU 2016-13, Financial Instruments-Credit Losses (Topic 326): Measurement of Credit Losses on Financial Instruments. The amendments in ASU 2016-13 will provide more decision-useful information about the expected credit losses on financial instruments and other commitments to extend credit held by a reporting entity at each reporting date. Following the release of ASU 2019-10 in  November 2019, the new effective date, as long as the Company remains a smaller reporting company, would be annual reporting periods beginning after  December 15, 2022.  The Company is currently evaluating the impact, if any, that the adoption of ASU 2016-13  may have on its consolidated financial statements.

[0001437749-21-025699:notes:169]
In  December 2019, the FASB issued ASU 2019-12, Income Taxes (Topic 740): Simplifying the Accounting for Income Taxes. The amendments in ASU 2019-12 provide for simplified accounting to several income tax situations and removal of certain accounting exceptions. As of  April 1, 2021, we have adopted ASU 2019-12 and noted no material impact on our consolidated financial statements.


## us-gaap:SubsequentEventsTextBlock

[0001437749-21-025699:notes:170]
19. Subsequent Events

[0001437749-21-025699:notes:171]
The Company has performed an evaluation of subsequent events through the time of filing this Quarterly Report on Form 10-Q with the SEC and has determined that there are no such events to report.
