# AMSC MD&A — 0001437749-22-025367


## mdna

[0001437749-22-025367:mdna:1]
[same as prior period, unchanged from 0001437749-22-018630:mdna:1]

[0001437749-22-025367:mdna:2]
[same as prior period, unchanged from 0001437749-22-018630:mdna:2]

[0001437749-22-025367:mdna:3]
[same as prior period, unchanged from 0001437749-22-018630:mdna:3]

[0001437749-22-025367:mdna:4]
[same as prior period, unchanged from 0001437749-22-018630:mdna:4]

[0001437749-22-025367:mdna:5]
[same as prior period, unchanged from 0001437749-22-018630:mdna:5]

[0001437749-22-025367:mdna:6]
[same as prior period, unchanged from 0001437749-22-018630:mdna:6]

[0001437749-22-025367:mdna:7]
[same as prior period, unchanged from 0001437749-22-018630:mdna:7]

[0001437749-22-025367:mdna:8]
|  | • | Grid. Through our Gridtec™ Solutions, our Grid business segment enables electric utilities, industrial facilities, and renewable energy project developers to connect, transmit and distribute power with exceptional efficiency, reliability, security and affordability. We provide transmission planning services that allow us to identify power grid congestion, poor power quality, and other risks, which help us determine how our solutions can improve network performance. These services often lead to sales of our grid interconnection solutions for wind farms and solar power plants, power quality systems and transmission and distribution cable systems. We also sell ship protection products to the U.S. Navy through our Grid business segment. |

[0001437749-22-025367:mdna:9]
[same as prior period, unchanged from 0001437749-22-018630:mdna:9]

[0001437749-22-025367:mdna:10]
[same as prior period, unchanged from 0001437749-22-018630:mdna:10]

[0001437749-22-025367:mdna:11]
[same as prior period, unchanged from 0001437749-22-018630:mdna:11]

[0001437749-22-025367:mdna:12]
The COVID-19 pandemic continues to rapidly evolve. We are experiencing substantial inflationary pressure in our supply chain, some delays in sourcing materials needed for our products and some production disruption resulting from higher than typical employee absenteeism which have increased our cost of revenues and decreased gross margin. The extent to which the pandemic impacts our business, liquidity, results of operations and financial condition will depend on future developments, which are highly uncertain and cannot be predicted with confidence. Changes in macroeconomic and market conditions arising from the COVID-19 pandemic, or for other reasons, such as the ongoing war between Russia and Ukraine, inflation, rising interest rates, labor force availability, sourcing, material delays and global supply chain disruptions could have a material adverse effect on our business, financial condition and results of operation.

[0001437749-22-025367:mdna:13]
[same as prior period, unchanged from 0001437749-22-018630:mdna:13]

[0001437749-22-025367:mdna:14]
[same as prior period, unchanged from 0001437749-22-018630:mdna:14]

[0001437749-22-025367:mdna:15]
[same as prior period, unchanged from 0001437749-22-018630:mdna:15]

[0001437749-22-025367:mdna:16]
Three and six months ended September 30, 2022, compared to the three and six months ended September 30, 2021

[0001437749-22-025367:mdna:17]
[same as prior period, unchanged from 0001437749-22-018630:mdna:17]

[0001437749-22-025367:mdna:18]
Total revenues decreased 1% to $27.7 million for the three months ended September 30, 2022 and total revenues decreased 6% to $50.4 million for the six months ended September 30, 2022, compared to $27.9 million and $53.3 million for the three and six months ended September 30, 2021, respectively. Our revenues are summarized as follows (in thousands):

[0001437749-22-025367:mdna:19]
|  |  | Three Months Ended September 30, |  |  | Six Months Ended September 30, |  |
|  |  | 2022 |  |  | 2021 |  |  | 2022 |  |  | 2021 |  |
| Revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Grid |  | $ | 25,698 |  |  | $ | 24,619 |  |  | $ | 45,527 |  |  | $ | 48,119 |  |
| Wind |  |  | 1,982 |  |  |  | 3,289 |  |  |  | 4,833 |  |  |  | 5,209 |  |
| Total |  | $ | 27,680 |  |  | $ | 27,908 |  |  | $ | 50,360 |  |  | $ | 53,328 |  |

[0001437749-22-025367:mdna:20]
Our Grid business unit accounted for 93% and 90% of total revenues for the three and six months ended September 30, 2022, respectively, compared to 88% and 90% for the three and six months ended September 30, 2021, respectively. Our Grid business unit revenues increased 4% to $25.7 million in the three months ended September 30, 2022, from $24.6 million in the three months ended September 30, 2021. Our Grid business unit revenues decreased 5% to $45.5 million in the six months ended September 30, 2022, from $48.1 million in the six months ended September 30, 2021. The increase in the Grid business unit revenue in the three months ended September 30, 2022, was primarily driven by higher NEPSI revenues than in the prior year period. The decrease in the Grid business unit revenue in the six months ended September 30, 2022, was primarily driven by lower D-VAR revenues than in the prior year period.

[0001437749-22-025367:mdna:21]
Our Wind business unit accounted for 7% and 10% of total revenues for the three and six months ended September 30, 2022, respectively, compared to 12% and 10% for the three and six months ended September 30, 2021, respectively. Revenues in the Wind business unit decreased 40% and 7% to $2.0 million and $4.8 million in the three and six months ended September 30, 2022, from $3.3 million and $5.2 million in the three and six months ended September 30, 2021, respectively. The decrease in the three months ended September 30, 2022, was driven by fewer royalty collections and shipments of electrical control systems ("ECS") to Inox in the three months ended September 30, 2022. The decrease in the six months ended September 30, 2022 was driven by lower license and development revenue as well as fewer royalty collections than in the prior year period.

[0001437749-22-025367:mdna:22]
[same as prior period, unchanged from 0001437749-22-018630:mdna:22]

[0001437749-22-025367:mdna:23]
Cost of revenues increased by 4% to $25.7 million for the three months ended September 30, 2022, compared to $24.6 for the three months ended September 30, 2021. Cost of revenues decreased by 1% to $46.2 million for the six months ended September 30, 2022, compared to $46.7 million for the six months ended September 30, 2021. Gross margin was 7% and 8% for the three and six months ended September 30, 2022, respectively compared to 12% and 13% for the three and six months ended September 30, 2021.  The decrease in gross margin in the three and six months ended September 30, 2022, was due to lower revenues, an unfavorable product mix and inflation pressure in our supply chain.

[0001437749-22-025367:mdna:24]
[same as prior period, unchanged from 0001437749-22-018630:mdna:24]

[0001437749-22-025367:mdna:25]
[same as prior period, unchanged from 0001437749-22-018630:mdna:25]

[0001437749-22-025367:mdna:26]
Research and development ("R&D") expense decreased 13% in each of the three and six months ended September 30, 2022, to $2.3 million from $2.7 million in the three months ended September 30, 2021, and to $5.0 million from $5.7 million in the six months ended September 30, 2021. The decrease in R&D expense was due to an increase in cost share revenues and a higher utilization of our research engineers supporting funded projects.

[0001437749-22-025367:mdna:27]
[same as prior period, unchanged from 0001437749-22-018630:mdna:27]

[0001437749-22-025367:mdna:28]
Selling, general and administrative ("SG&A") expenses increased 10% in the three months ended September 30, 2022, to $7.3 million from $6.7 million in the three months ended September 30, 2021. The increase in SG&A expense in the three months ended September 30, 2022, was due to higher overall compensation expense than in the prior year period. SG&A expenses increased 8% to $14.9 million in the six months ended September 30, 2022, compared to $13.8 million in the six months ended September 30, 2021. The increase in SG&A expense in the six months ended September 30, 2022, was due to higher overall compensation expense than in the prior year period.

[0001437749-22-025367:mdna:29]
[same as prior period, unchanged from 0001437749-22-018630:mdna:29]

[0001437749-22-025367:mdna:30]
We recorded amortization expense related to our core technology and know-how, customer relationships, and other intangible assets of $0.7 million and $1.4 million in the three and six months ended September 30, 2022, respectively, and $0.6 million and $1.2 million in the three and six months ended September 30, 2021, respectively. The increase in amortization expense is a result of additional expense tied to the acquisition of Neeltran.

[0001437749-22-025367:mdna:31]
[same as prior period, unchanged from 0001437749-22-018630:mdna:31]

[0001437749-22-025367:mdna:32]
The change in fair value of our contingent consideration for the earnout payment on the NEPSI Acquisition resulted in a gain of $0.3 million and $0.1 million in the three and six months ended September 30, 2022, respectively, compared to a gain of $2.4 million and $2.3 million in the three and six months ended September 30, 2021, respectively. The change in the fair value was primarily driven by a decreased likelihood of achieving certain revenue targets and a decline in the Company's stock price.

[0001437749-22-025367:mdna:33]
[same as prior period, unchanged from 0001437749-22-018630:mdna:33]

[0001437749-22-025367:mdna:34]
[same as prior period, unchanged from 0001437749-22-018630:mdna:34]

[0001437749-22-025367:mdna:35]
|  |  | Three Months Ended September 30, |  |  | Six Months Ended September 30, |  |
|  |  | 2022 |  |  | 2021 |  |  | 2022 |  |  | 2021 |  |
| Operating loss: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Grid |  | $ | (6,495 | ) |  | $ | (5,836 | ) |  | $ | (13,776 | ) |  | $ | (11,180 | ) |
| Wind |  |  | (868 | ) |  |  | 205 |  |  |  | (1,254 | ) |  |  | (558 | ) |
| Unallocated corporate expenses |  |  | (729 | ) |  |  | 1,329 |  |  |  | (1,931 | ) |  |  | (63 | ) |
| Total |  | $ | (8,092 | ) |  | $ | (4,302 | ) |  | $ | (16,961 | ) |  | $ | (11,801 | ) |

[0001437749-22-025367:mdna:36]
Our Grid business segment generated operating losses of $6.5 million and $13.8 million in the three and six months ended September 30, 2022, compared to $5.8 million and $11.2 million in the three and six months ended September 30, 2021. The increase in the Grid business unit operating loss in the three months ended September 30, 2022, was due to lower gross margins due to an unfavorable product mix, and higher operating expenses. The increase in the grid business unit operating loss in the six months ended September 30, 2022 was due to lower revenues and gross margins due to an unfavorable product mix, and higher operating expenses.

[0001437749-22-025367:mdna:37]
Our Wind business segment generated operating losses of $0.9 million and $1.3 million in the three and six months ended September 30, 2022, compared to an operating profit of $0.2 million and an operating loss of $0.6 million in the three and six months ended September 30, 2021, respectively. The increase in the Wind business unit operating loss was due to lower revenues and gross margins, and higher operating expenses.

[0001437749-22-025367:mdna:38]
Unallocated corporate expenses included a gain on contingent consideration of $0.3 million and $0.1 million in the three and six months ended September 30, 2022. Additionally, unallocated corporate expenses primarily consisted of stock-based compensation expense of $1.0 million and $1.1 million in the three months ended September 30, 2022 and 2021, respectively, and $2.1 million and $2.4 million in the six months ended September 30, 2022 and 2021, respectively.

[0001437749-22-025367:mdna:39]
[same as prior period, unchanged from 0001437749-22-018630:mdna:39]

[0001437749-22-025367:mdna:40]
Interest income, net, was less than $0.1 million in both the three and six months ended September 30, 2022 and September 30, 2021, respectively.

[0001437749-22-025367:mdna:41]
China dissolution

[0001437749-22-025367:mdna:42]
China dissolution, was
    $1.9 million in each of the 
    three and six months ended
    September 30, 2022, respectively, compared to no activity in each of the

[0001437749-22-025367:mdna:43]
three and six
     months ended 
    September 30, 2021
    . The increase in China dissolution during the three and six months ended September 30, 2022, was driven by the liquidation of our China entity, resulting in a foreign currency gain/loss from the cumulative translation release of $1.9 million in the three and six months ended September 30, 2022 in which there was no similar transaction in the three and six months ended September 30, 2021.

[0001437749-22-025367:mdna:44]
Other income (expense), net

[0001437749-22-025367:mdna:45]
Other income, net, was $0.1 million and $0.2 million in the three and six months ended September 30, 2022, respectively, compared to other income, net, of less than $0.1 million in the three months ended September 30, 2021 and other expense, net of less than $0.1 million in the six months ended September 30, 2021. The decrease in other expense during the three and six months ended September 30, 2022, was driven by the impacts of favorable fluctuations in foreign currencies during the respective period.

[0001437749-22-025367:mdna:46]
[same as prior period, unchanged from 0001437749-22-018630:mdna:43]

[0001437749-22-025367:mdna:47]
Income tax benefit was less than $0.1 million in the three months ended September 30, 2022 and income tax expense was less than $0.1 million in the six months ended September 30, 2022. Income tax expense was $0.2 million in the three months ended September 30, 2021 and income tax benefit was $1.9 million in the six months ended September 30, 2021. The increase in income tax benefit in the three months ended September 30, 2022 compared to the same period in fiscal 2021 was primarily due to lower withholding taxes from foreign jurisdictions in the three months ended September 30, 2022. The increase in income tax expense in the six months ended September 30, 2022 compared to the same period in fiscal 2021 was a result of the release of the valuation allowance to offset the recording of the deferred tax liability from the Neeltran Acquisition in the six months ended September 30, 2021.

[0001437749-22-025367:mdna:48]
[same as prior period, unchanged from 0001437749-22-018630:mdna:45]

[0001437749-22-025367:mdna:49]
Net loss was $9.9 million and $18.6 million in the three and six months ended September 30, 2022, compared to $4.4 million and $9.8 million in the three and six months ended September 30, 2021. The increase in net loss was driven primarily by the increased operating loss due to lower revenues and gross margins.

[0001437749-22-025367:mdna:50]
[same as prior period, unchanged from 0001437749-22-018630:mdna:47]

[0001437749-22-025367:mdna:51]
[same as prior period, unchanged from 0001437749-22-018630:mdna:48]

[0001437749-22-025367:mdna:52]
We define non-GAAP net loss as net loss before China dissolution, stock-based compensation, amortization of acquisition-related intangibles, acquisition costs, change in fair value of contingent consideration, and other non-cash or unusual charges.  We believe non-GAAP net loss assists management and investors in comparing our performance across reporting periods on a consistent basis by excluding these non-cash charges and other items that we do not believe are indicative of our core operating performance. In addition, we use non-GAAP net loss as a factor to evaluate the effectiveness of our business strategies. A reconciliation of GAAP to non-GAAP net loss is set forth in the table below (in thousands, except per share data):

[0001437749-22-025367:mdna:53]
|  |  | Three Months Ended September 30, |  |  | Six Months Ended September 30, |  |
|  |  | 2022 |  |  | 2021 |  |  | 2022 |  |  | 2021 |  |
| Net loss |  | $ | (9,881 | ) |  | $ | (4,434 | ) |  | $ | (18,590 | ) |  | $ | (9,837 | ) |
| China dissolution |  |  | 1,921 |  |  |  | — |  |  |  | 1,921 |  |  |  | — |  |
| Stock-based compensation |  |  | 1,019 |  |  |  | 1,100 |  |  |  | 2,052 |  |  |  | 2,393 |  |
| Amortization of acquisition-related intangibles |  |  | 688 |  |  |  | 668 |  |  |  | 1,400 |  |  |  | 1,289 |  |
| Acquisition costs |  |  | — |  |  |  | (7 | ) |  |  | — |  |  |  | (2,330 | ) |
| Change in fair value of contingent consideration |  |  | (290 | ) |  |  | (2,430 | ) |  |  | (120 | ) |  |  | 681 |  |
| Non-GAAP net loss |  | $ | (6,542 | ) |  | $ | (5,103 | ) |  | $ | (13,337 | ) |  | $ | (7,804 | ) |
| Non-GAAP net loss per share - basic |  | $ | (0.23 | ) |  | $ | (0.19 | ) |  | $ | (0.48 | ) |  | $ | (0.29 | ) |
| Weighted average shares outstanding - basic |  |  | 27,867 |  |  |  | 27,252 |  |  |  | 27,714 |  |  |  | 27,040 |  |

[0001437749-22-025367:mdna:54]
We incurred non-GAAP net losses of $6.5 million and $13.3 million, or $0.23 and $0.48 per share, for the three and six months ended September 30, 2022, compared to $5.1 million and $7.8 million, or $0.19 and $0.29 per share, for the three and six months ended September 30, 2021. The increase in the non-GAAP net loss for the three and six months ended September 30, 2022 was due to a higher operating loss driven by lower gross margin and higher operating expenses.

[0001437749-22-025367:mdna:55]
[same as prior period, unchanged from 0001437749-22-018630:mdna:52]

[0001437749-22-025367:mdna:56]
We have experienced recurring operating losses and, as of September 30, 2022, had an accumulated deficit of $1,039 million.

[0001437749-22-025367:mdna:57]
[same as prior period, unchanged from 0001437749-22-018630:mdna:54]

[0001437749-22-025367:mdna:58]
[same as prior period, unchanged from 0001437749-22-018630:mdna:55]

[0001437749-22-025367:mdna:59]
As of September 30, 2022, we had cash, cash equivalents and restricted cash of $37.4 million, compared to $49.5 million as of March 31, 2022, a decrease of $12.1 million. As of September 30, 2022, we had approximately $1.9 million of cash, cash equivalents, and restricted cash in foreign bank accounts. Our cash, cash equivalents, and restricted cash are summarized as follows (in thousands):

[0001437749-22-025367:mdna:60]
|  |  | September 30, 2022 |  |  | March 31, 2022 |  |
| Cash and cash equivalents |  | $ | 27,811 |  |  | $ | 40,584 |  |
| Restricted cash |  |  | 9,542 |  |  |  | 8,902 |  |
| Total cash, cash equivalents, and restricted cash |  | $ | 37,354 |  |  | $ | 49,486 |  |

[0001437749-22-025367:mdna:61]
For the six months ended September 30, 2022, net cash used in operating activities was $11.6 million, compared to $11.7 million for the six months ended September 30, 2021.  The decrease in net cash used in operations was due primarily to an increase in inventory purchases offset by accounts receivable collections in the six months ended September 30, 2022 as compared to September 30, 2021.

[0001437749-22-025367:mdna:62]
For the six months ended September 30, 2022, net cash used in investing activities was $0.7 million, compared to $6.8 million for the six months ended September 30, 2021. The decrease in net cash used in investing activities was primarily due to the cash that was used to pay for the Neeltran Acquisition in the six months ended September 30, 2021. There was no such transaction in the six months ended September 30, 2022.

[0001437749-22-025367:mdna:63]
For the six months ended September 30, 2022 and 2021, respectively, net cash provided by financing activities remained consistent at less than $0.1 million.

[0001437749-22-025367:mdna:64]
As of September 30, 2022, we had $6.0 million of restricted cash included in long-term assets and $3.6 million of restricted cash included in current assets.  These amounts of restricted cash primarily represent deposits to secure letters of credit for various supply contracts and long-term projects, including the irrevocable letter of credit in the amount of $5.0 million to secure certain of our obligations under the Subcontract Agreement with ComEd. These deposits are held in interest bearing accounts.

[0001437749-22-025367:mdna:65]
We are a party to many contractual obligations involving commitments to make payments to third parties. These obligations impact our short-term and long-term liquidity and capital resource needs. Certain contractual obligations are reflected on the consolidated balance sheet as of September 30, 2022, while others are considered future commitments. We have various contractual arrangements, under which we have committed to purchase certain minimum quantities of goods or services on an annual basis. For information regarding our other contractual obligations, refer to Note 13, "Contingent Consideration," Note 14, "Debt," Note 15, "Leases" and Note 16, "Commitments and Contingencies" to our condensed consolidated financial statements included elsewhere in this Quarterly Report on Form 10-Q.

[0001437749-22-025367:mdna:66]
We believe we have sufficient available liquidity to fund our operations and capital expenditures for the next twelve months. In addition, we may seek to raise additional capital, which could be in the form of loans, convertible debt or equity, to fund our operating requirements and capital expenditures. Our liquidity is highly dependent on our ability to increase revenues, improve upon gross margins, control our operating costs, and raise additional capital, if necessary. There can be no assurance that we will be able to raise additional capital on favorable terms or at all, or execute on any other means of improving our liquidity as described above.  Additionally, the impact of the COVID-19 pandemic and adverse macroeconomic conditions on the global financial markets may reduce our ability to raise additional capital, if necessary, which could negatively impact our liquidity.

[0001437749-22-025367:mdna:67]
Legal Proceedings

[0001437749-22-025367:mdna:68]
We are involved in legal and administrative proceedings and claims of various types. See Part II, Item 1, “Legal Proceedings,” for additional information. We record a liability in our consolidated financial statements for these matters when a loss is known or considered probable and the amount can be reasonably estimated. We review these estimates each accounting period as additional information is known and adjust the loss provision when appropriate. If a matter is both probable to result in liability and the amounts of loss can be reasonably estimated, we estimate and disclose the possible loss or range of loss to the extent necessary to make the consolidated financial statements not misleading. If the loss is not probable or cannot be reasonably estimated, a liability is not recorded in our consolidated financial statements.

[0001437749-22-025367:mdna:69]
[same as prior period, unchanged from 0001437749-22-018630:mdna:66]

[0001437749-22-025367:mdna:70]
In June 2016, the FASB issued ASU 2016-13, Financial Instruments-Credit Losses (Topic 326): Measurement of Credit Losses on Financial Instruments. The amendments in ASU 2016-13 will provide more decision-useful information about the expected credit losses on financial instruments and other commitments to extend credit held by a reporting entity at each reporting date. Following the release of ASU 2019-10 in November 2019, the new effective date, as long as we remain a smaller reporting company, would be annual reporting periods beginning after December 15, 2022. We have evaluated the impact of the adoption of ASU 2016-13, and do not expect it to have a material impact on our consolidated financial statements.

[0001437749-22-025367:mdna:71]
In October 2021, the FASB issued ASU 2021-08, Business Combinations (Topic 805): Accounting for Contract Assets and Contract Liabilities from Contracts with Customers. The amendments in ASU 2021-08 will improve the accounting for acquired revenue contracts with customers in a business combination. Following the release of ASU 2021-08 in October 2021, the new effective date will be annual reporting periods beginning after December 15, 2022. We are currently evaluating the impact, if any, that the adoption of ASU 2021-08 may have on our consolidated financial statements.

[0001437749-22-025367:mdna:72]
In November 2021, the FASB issued ASU 2021-10, Government Assistance (Topic 832): Disclosures by Business Entities about Government Assistance. The amendments in ASU 2021-10 improve financial reporting by requiring disclosures that increase the transparency of transactions with government accounted for by applying a grant or contribution accounting model by analogy. Following the release of ASU 2021-10 in November 2021, the effective date was annual reporting periods beginning after December 15, 2021. As of April 1, 2022, we have adopted ASU 2021-10 and noted no material impact on our consolidated financial statements.

[0001437749-22-025367:mdna:73]
We do not believe that, outside of those disclosed here, there are any other recently issued accounting pronouncements that will have a material impact on our consolidated financial statements.
