# AMSC MD&A — 0001628280-18-009847


## mdna

[0001628280-18-009847:mdna:1]
[same as prior period, unchanged from 0001628280-18-000993:mdna:1]

[0001628280-18-009847:mdna:2]
American Superconductor®, Amperium®, AMSC®, D-VAR®, PowerModule™, D-VAR® VVO, PQ-IVR®, SeaTitan™, Gridtec Solutions™, Windtec Solutions™ and Smarter, Cleaner...Better Energy™ are trademarks or registered trademarks of American Superconductor Corporation or our subsidiaries. We reserve all of our rights with respect to our trademarks or registered trademarks regardless of whether they are so designated in this Quarterly Report on Form 10-Q by an ® or ™ symbol. All other

[0001628280-18-009847:mdna:3]
brand names, product names, trademarks or service marks appearing in this Quarterly Report on Form 10-Q are the property of their respective holders.

[0001628280-18-009847:mdna:4]
[same as prior period, unchanged from 0001628280-18-000993:mdna:3]

[0001628280-18-009847:mdna:5]
We are a leading provider of megawatt-scale solutions that lower the cost of wind power and enhance the performance of the power grid. In the wind power market, we enable manufacturers to field highly competitive wind turbines through our advanced power electronics products, engineering, and support services. In the power grid market, we enable electric utilities and renewable energy project developers to connect, transmit and distribute power through our transmission planning services and power electronics and superconductor-based products. Our wind and power grid products and services provide exceptional reliability, security, efficiency and affordability to our customers.

[0001628280-18-009847:mdna:6]
[same as prior period, unchanged from 0001628280-18-000993:mdna:6]

[0001628280-18-009847:mdna:7]
[same as prior period, unchanged from 0001628280-18-000993:mdna:7]

[0001628280-18-009847:mdna:8]
[same as prior period, unchanged from 0001628280-18-000993:mdna:8]

[0001628280-18-009847:mdna:9]
[same as prior period, unchanged from 0001628280-18-000993:mdna:9]

[0001628280-18-009847:mdna:10]
[same as prior period, unchanged from 0001628280-18-000993:mdna:10]

[0001628280-18-009847:mdna:11]
Our fiscal year begins on April 1 and ends on March 31. When we refer to a particular fiscal year, we are referring to the fiscal year beginning on April 1 of that same year. For example, fiscal 2018 refers to the fiscal year beginning on April 1, 2018. Other fiscal years follow similarly.

[0001628280-18-009847:mdna:12]
On July 3, 2018, we and our wholly-owned subsidiaries Suzhou AMSC Superconductor Co. Ltd. (“AMSC China”) and AMSC Austria GMBH (“AMSC Austria”) entered into a settlement agreement (the “Settlement Agreement”) with Sinovel Wind Group Co., Ltd. (“Sinovel”). The Settlement Agreement settles the litigation and arbitration proceedings between us and Sinovel listed on Schedule 2 of the Settlement Agreement (the “Proceedings”), and any other civil claims, counterclaims, causes of action, rights and obligations directly or indirectly relating to the subject matters of the Proceedings and the contracts between us and Sinovel listed on Schedules 1 and 4 of the Settlement Agreement (the “Contracts”), subject to the exception described in Section 1.1 of the Settlement Agreement. The Settlement Agreement was filed as Exhibit 10.1 to the Company’s Form 8-K filed with the Securities and Exchange Commission on July 9, 2018. Under the terms of the Settlement Agreement, Sinovel agreed to pay AMSC China an aggregate cash amount in Renminbi (RMB) equivalent to $57.5 million, consisting of two installments. Sinovel paid the first installment of $32.5 million on July 4, 2018, and has agreed to pay the second installment of $25.0 million (the “Second Payment”) within ten (10) months after the U.S. District Court for the Western District of Wisconsin (the “District Court”) delivers the first sentence against Sinovel in the criminal case entitled United States v. Sinovel Wind Co., Ltd., Case Number 3:13-cr-00084-jdp. On July 6, 2018, the District Court delivered such sentence, and therefore the Second Payment is due by May 6, 2019. Mr.

[0001628280-18-009847:mdna:13]
25

[0001628280-18-009847:mdna:14]
Wenyuan Wei, former Sinovel chairman and a current Sinovel shareholder, has delivered a letter of guarantee to us for the Second Payment should Sinovel fail to make such payment by the Second Payment Due Date.

[0001628280-18-009847:mdna:15]
In addition, pursuant to the terms of the Settlement Agreement, we and AMSC Austria have granted Sinovel a non-exclusive license for certain of our intellectual property to be used solely in Sinovel’s doubly fed wind turbines (the “License”). We have agreed not to sue Sinovel, Sinovel’s power converter suppliers or Sinovel’s customers for use of the technology covered by the License. In the event that Sinovel or Mr. Wei does not make the Second Payment by the Second Payment Due Date, the Settlement Agreement provides that the License will terminate.  See Note 15 “Commitments and Contingencies” for additional information on the terms of the Settlement Agreement.

[0001628280-18-009847:mdna:16]
On July 25, 2018, we received notice from BASF Corporation (“BASF”) that BASF will not be extending the term of the Joint Development Agreement dated March 4, 2016 (“JDA”) by and between BASF and us beyond March 3, 2019.  As a result, BASF will not be required to pay $1.0 million in 2019 to us as otherwise would have been required pursuant to the terms of the JDA.  To date, BASF has paid $6.0 million to us under the JDA.

[0001628280-18-009847:mdna:17]
[same as prior period, unchanged from 0001628280-18-000993:mdna:19]

[0001628280-18-009847:mdna:18]
The preparation of the unaudited condensed consolidated financial statements requires that we make estimates and judgments that affect the reported amounts of assets, liabilities, revenues and expenses, and related disclosure of contingent assets and liabilities. We base our estimates on historical experience and various other assumptions that are believed to be reasonable under the circumstances, the results of which form the basis for making judgments about the carrying values of assets and liabilities that are not readily apparent from other sources. Actual results may differ under different assumptions or conditions.  During the three months ended June 30, 2018, we adopted ASU 2014-09, which provides for new requirements in regards to revenue recognition.  See Note 2, "Revenue Recognition" for further details.  Aside from the adoption of ASU 2014-09, there were no significant changes in the critical accounting policies that were disclosed in our Form 10-K for fiscal 2017, which ended on March 31, 2018.

[0001628280-18-009847:mdna:19]
[same as prior period, unchanged from 0001628280-18-000993:mdna:21]

[0001628280-18-009847:mdna:20]
Three months ended June 30, 2018 compared to the three months ended June 30, 2017

[0001628280-18-009847:mdna:21]
[same as prior period, unchanged from 0001628280-18-000993:mdna:23]

[0001628280-18-009847:mdna:22]
Total revenues increased 41% to $12.6 million for the three months ended June 30, 2018, compared to $8.9 million for the three months ended June 30, 2017.  Our revenues are summarized as follows (in thousands):

[0001628280-18-009847:mdna:23]
|  | Three months ended June 30, |
|  | 2018 |  | 2017 |
| Revenues: |  |  |  |  |
| Wind | $ | 3,678 |  |  | $ | 2,278 |  |
| Grid | 8,929 |  |  | 6,645 |  |
| Total | $ | 12,607 |  |  | $ | 8,923 |  |

[0001628280-18-009847:mdna:24]
Our Wind business unit accounted for 29% of total revenues for the three months ended June 30, 2018, compared to 26% for the three months ended June 30, 2017.  Revenues in the Wind business unit increased 61% to $3.7 million in the three months ended June 30, 2018, from $2.3 million in the three months ended June 30, 2017. Wind business unit revenues increased due to increased ECS shipments to Inox during the period. Although shipments to Inox increased during the three months ended June 30, 2018 compared to the three months ended June 30, 2017, Inox has experienced a reduction in demand for the past several quarters that we believe has been caused by the transition in India from a local fixed tariff policy regime to a central and state government auction regime, which has had an adverse impact on the Wind industry in India.   We cannot predict if and when this demand dislocation will be fully resolved, and to the extent resolved, how successful Inox will be under the new central and state auction regime.

[0001628280-18-009847:mdna:25]
Our Grid business unit accounted for 71% of total revenues for the three months ended June 30, 2018, compared to 74% for the three months ended June 30, 2017.  Our Grid business unit revenues increased 34% to $8.9 million in the three months ended June 30, 2018, from $6.6 million in the three months ended June 30, 2017.  Grid business unit revenues increased primarily due to higher D-VAR system revenues.

[0001628280-18-009847:mdna:26]
The following table sets forth customers who represented 10% or more of our total revenues for the three months ended June 30, 2018 and 2017:

[0001628280-18-009847:mdna:27]
|  | Reportable | Three months ended June 30, |
|  | Segment | 2018 |  | 2017 |
| Inox Wind Limited | Wind | 25 | % |  | 22 | % |
| Vestas | Grid | 36 | % |  | — | % |
| U.S. Navy | Grid | <10% |  |  | 35 | % |

[0001628280-18-009847:mdna:28]
[same as prior period, unchanged from 0001628280-18-000993:mdna:31]

[0001628280-18-009847:mdna:29]
Cost of revenues decreased by 35% to $8.7 million for the three months ended June 30, 2018, compared to $13.4 million for the three months ended June 30, 2017. Gross margin was 31% for the three months ended June 30, 2018, compared to (50)% for the three months ended June 30, 2017. The increase in the gross margin was due to increased revenue at a more favorable product mix in both business units compared to the prior year period along with accelerated depreciation in the prior year period related to revised estimates of the remaining lives on certain pieces of manufacturing equipment, as well as reduced fixed factory overhead as a result of the factory move to our newly leased Ayer facility.

[0001628280-18-009847:mdna:30]
[same as prior period, unchanged from 0001628280-18-000993:mdna:34]

[0001628280-18-009847:mdna:31]
[same as prior period, unchanged from 0001628280-18-000993:mdna:35]

[0001628280-18-009847:mdna:32]
R&D expenses increased in the three months ended June 30, 2018 by 5% to $2.8 million from $2.7 million for the three months ended June 30, 2017.  The increase in R&D expenses was primarily due to higher compensation expense.

[0001628280-18-009847:mdna:33]
[same as prior period, unchanged from 0001628280-18-000993:mdna:37]

[0001628280-18-009847:mdna:34]
SG&A expenses decreased by 6% to $5.8 million in the three months ended June 30, 2018, from $6.1 million in the three months ended June 30, 2017. The decrease in SG&A expenses was due primarily to reduced overall compensation expense.

[0001628280-18-009847:mdna:35]
[same as prior period, unchanged from 0001628280-18-000993:mdna:39]

[0001628280-18-009847:mdna:36]
We recorded amortization expense related to our core technology and know-how, trade names and trademark intangible assets of less than $0.1 million in each of the three months ended June 30, 2018 and 2017.

[0001628280-18-009847:mdna:37]
[same as prior period, unchanged from 0001628280-18-000993:mdna:43]

[0001628280-18-009847:mdna:38]
We recorded $0.3 million for facility exit costs in the three months ended June 30, 2018 as a result of the move of the corporate office that was announced as part of our April 4, 2017 approved restructuring plan.  We recorded a restructuring charge of $1.3 million for severance costs in the three months ended June 30, 2017 as a result of the reduction in force also announced on April 4, 2017. Included in the $1.3 million severance pay charged to operations in the three months ended June 30, 2017, is $0.5 million of severance pay for one of our former executive officers pursuant to the terms of a severance agreement dated June 30, 2017.  Under the terms of the severance agreement, our former executive officer is entitled to eighteen months of his base salary, which is expected to be paid by December 31, 2018.  From and after January 1, 2018, at our discretion, we may settle any remaining unpaid cash severance owed to our former executive officer through the issuance of a number of immediately vested shares of our common stock, determined by multiplying the remaining unpaid cash severance owed by 120%, and then dividing by the closing stock price per share of our common stock as of the last business day prior to the issuance of the shares.

[0001628280-18-009847:mdna:39]
[same as prior period, unchanged from 0001628280-18-000993:mdna:45]

[0001628280-18-009847:mdna:40]
[same as prior period, unchanged from 0001628280-18-000993:mdna:46]

[0001628280-18-009847:mdna:41]
|  | Three months ended June 30, |
|  | 2018 |  | 2017 |
| Operating loss: |  |  |  |
| Wind | $ | (1,367 | ) |  | $ | (4,433 | ) |
| Grid | (2,666 | ) |  | (8,167 | ) |
| Unallocated corporate expenses | (1,095 | ) |  | (2,093 | ) |
| Total | $ | (5,128 | ) |  | $ | (14,693 | ) |

[0001628280-18-009847:mdna:42]
Our Wind segment generated operating losses of $1.4 million in the three months ended June 30, 2018, compared to $4.4 million in the three months ended June 30, 2017. The decrease in the Wind business unit operating loss was due primarily to increased shipments of ECS to Inox.

[0001628280-18-009847:mdna:43]
Our Grid segment generated operating losses of $2.7 million in the three months ended June 30, 2018, compared to $8.2 million in the three months ended June 30, 2017.  The decrease in the Grid business unit operating loss was due primarily to increased D-VAR revenues compared to the prior year period as well as decreased costs as noted above.

[0001628280-18-009847:mdna:44]
Unallocated corporate expenses primarily consist of stock-based compensation expense of $0.8 million and restructuring charges of $0.3 million for the three months ended June 30, 2018, and $0.8 million of stock based compensation expense and $1.3 million of restructuring charges, primarily for severance costs as a result of the restructuring action announced on April 4, 2017, in the three months ended June 30, 2017.

[0001628280-18-009847:mdna:45]
[same as prior period, unchanged from 0001628280-18-000993:mdna:51]

[0001628280-18-009847:mdna:46]
The change in fair value of warrants resulted in a loss of $0.5 million in the three months ended June 30, 2018, compared to a gain of $0.9 million in the three months ended June 30, 2017.  The change in the fair value was primarily driven by changes in stock price, which is a key valuation metric.

[0001628280-18-009847:mdna:47]
[same as prior period, unchanged from 0001628280-18-000993:mdna:55]

[0001628280-18-009847:mdna:48]
Interest income (expense), net, was income of     less than $0.2 million in the three months ended June 30, 2018, compared to expense of less than $0.1 million in the three months ended June 30, 2017. The increase in interest income was primarily related to imputed interest earned in relation to the outstanding note receivable for the sale of the 64 Jackson Road building.

[0001628280-18-009847:mdna:49]
Other income (expense), net

[0001628280-18-009847:mdna:50]
Other income (expense), net, was income of $0.6 million in the three months ended June 30, 2018, compared to expense of $1.4 million in the three months ended June 30, 2017.  The increase in other income, net, during the three months ended June 30, 2018, was primarily driven by higher foreign currency gains.

[0001628280-18-009847:mdna:51]
[same as prior period, unchanged from 0001628280-18-000993:mdna:59]

[0001628280-18-009847:mdna:52]
Income tax benefit was less than $0.1 million in the three months ended June 30, 2018, compared to income tax expense of $0.1 million in the three months ended June 30, 2017. The increase in income tax benefit was primarily due to taxes earned in our foreign locations.

[0001628280-18-009847:mdna:53]
[same as prior period, unchanged from 0001628280-18-000993:mdna:61]

[0001628280-18-009847:mdna:54]
[same as prior period, unchanged from 0001628280-18-000993:mdna:62]

[0001628280-18-009847:mdna:55]
We define non-GAAP net loss as net loss before stock-based compensation, amortization of acquisition-related intangibles, consumption of zero cost-basis inventory, changes in fair value of warrants, non-cash interest expense, tax effect of adjustments, and the other non-cash or unusual charges, indicated in the table below. We believe non-GAAP net loss assists management and investors in comparing our performance across reporting periods on a consistent basis by excluding these non-cash or non-recurring charges that we do not believe are indicative of our core operating performance. A reconciliation of GAAP to non-GAAP net loss is set forth in the table below (in thousands, except per share data):

[0001628280-18-009847:mdna:56]
|  | Three months ended June 30, |
|  | 2018 |  | 2017 |
| Net loss | $ | (4,737 | ) |  | $ | (15,252 | ) |
| Stock-based compensation | 785 |  |  | 754 |  |
| Amortization of acquisition-related intangibles | 85 |  |  | 13 |  |
| Consumption of zero cost-basis inventory | (249 | ) |  | (57 | ) |
| Change in fair value of warrants | 464 |  |  | (925 | ) |
| Non-cash interest expense | — |  |  | 19 |  |
| Tax effect of adjustments | 40 |  |  | 9 |  |
| Non-GAAP net loss | $ | (3,612 | ) |  | $ | (15,439 | ) |
| Non-GAAP net loss per share | $ | (0.18 | ) |  | $ | (0.92 | ) |
| Weighted average shares outstanding - basic and diluted | 20,167 |  |  | 16,778 |  |

[0001628280-18-009847:mdna:57]
We incurred non-GAAP net losses of $3.6 million or $0.18 per share, for the three months ended June 30, 2018, compared to non-GAAP net losses of $15.4 million or $0.92 per share for the three months ended June 30, 2017. The decrease in non-GAAP net loss was driven primarily by a decrease in net loss, as previously discussed.

[0001628280-18-009847:mdna:58]
[same as prior period, unchanged from 0001628280-18-000993:mdna:66]

[0001628280-18-009847:mdna:59]
We have experienced recurring operating losses and as of June 30, 2018 had an accumulated deficit of $993.0 million. In addition, we have experienced recurring negative operating cash flows, which continued in the three months ended June 30, 2018. Although our sales to Inox increased in the three months ended June 30, 2018 compared to the three months ended June 30, 2017, we cannot predict if and when Inox's demand dislocation will be fully resolved and to the extent resolved, how successful Inox will be under the new central and state auction regime.

[0001628280-18-009847:mdna:60]
Our cash requirements depend on numerous factors, including if and when the Inox demand dislocation is fully resolved, whether Inox is successful under the new central and state auction regime, our ability to collect the Second Payment from Sinovel, the successful completion of our product development activities, our ability to commercialize our Resilient Electric Grid (“REG”) and ship protection system solutions, rate of customer and market adoption of our products, collecting receivables according to established terms, and the continued availability of U.S. government funding during the product development phase of our Superconductors-based products.  We continue to closely monitor our expenses and, if required, expect to further reduce our operating and capital spending to enhance liquidity.

[0001628280-18-009847:mdna:61]
As of June 30, 2018, we had cash, cash equivalents, and restricted cash of $26.9 million, compared to $34.2 million as of March 31, 2018, a decrease of $7.3 million.  On July 4, 2018, Sinovel paid AMSC China an aggregate cash amount in Renminbi (RMB) equivalent to $32.5 million pursuant to the terms of the Settlement Agreement.  On July 24, 2018, AMSC China paid $30.7 million to AMSC Austria to settle outstanding intercompany balances.Our cash and cash equivalents, and restricted cash are summarized as follows (in thousands):

[0001628280-18-009847:mdna:62]
|  | June 30, 2018 |  | March 31,2018 |
| Cash and cash equivalents | $ | 26,750 |  |  | $ | 34,084 |  |
| Restricted cash | 165 |  |  | 165 |  |
| Total cash, cash equivalents, and restricted cash | $ | 26,915 |  |  | $ | 34,249 |  |

[0001628280-18-009847:mdna:63]
As of June 30, 2018, we had approximately $0.8 million of cash, cash equivalents, and restricted cash in foreign bank accounts.  As discussed above, the $30.7 million payment from AMSC China to AMSC Austria on July 24, 2018 is held in a foreign bank account.

[0001628280-18-009847:mdna:64]
For the three months ended June 30, 2018, net cash used in operating activities was $6.9 million compared to $5.4 million of cash used for the three months ended June 30, 2017. The increase in net cash used in operations was due primarily to an increase in accounts receivable in the three months ended June 30, 2018 compared to the prior year period.

[0001628280-18-009847:mdna:65]
For the three months ended June 30, 2018, net cash used in investing activities was $0.2 million, compared to $0.1 million for the three months ended June 30, 2017. The increase in net cash used in investing activities was due primarily to increased purchases of property, plant and equipment compared to the prior year period.

[0001628280-18-009847:mdna:66]
For the three months ended June 30, 2018, net cash used in financing activities was $0.2 million compared to net cash provided by financing activities of $15.1 million in the three months ended June 30, 2017. The decrease in net cash provided by financing activities was primarily due to net proceeds of $17.0 million from the issuance of 4.6 million shares of common stock in May 2017, with no such equity offering in the current year period.  See the discussion regarding the May 2017 equity offering below.

[0001628280-18-009847:mdna:67]
As of June 30, 2018, we had $0.2 million of restricted cash included in long-term assets. These amounts included in restricted cash primarily represent deposits to secure letters of credit for various supply contracts. These deposits are held in interest bearing accounts.

[0001628280-18-009847:mdna:68]
[same as prior period, unchanged from 0001628280-18-000993:mdna:77]

[0001628280-18-009847:mdna:69]
[same as prior period, unchanged from 0001628280-18-000993:mdna:78]

[0001628280-18-009847:mdna:70]
We believe we have sufficient available liquidity to fund our operations and capital expenditures for the next twelve months. In addition, we may seek to raise additional capital, which could be in the form of loans, convertible debt or equity, to fund our operating requirements and capital expenditures.  Our liquidity is highly dependent on our ability to increase revenues, including our ability to collect revenues under our agreements with Inox, control our operating costs, and our ability to raise additional capital, if necessary.  There can be no assurance that we will be able to raise additional capital, on favorable terms or at all, or execute on any other means of improving our liquidity as described above.

[0001628280-18-009847:mdna:71]
Legal Proceedings

[0001628280-18-009847:mdna:72]
We are involved in legal and administrative proceedings and claims of various types. See Part II, Item 1, “Legal Proceedings,” for additional information. We record a liability in our consolidated financial statements for these matters when a loss is known or considered probable and the amount can be reasonably estimated. We review these estimates each accounting period as additional information is known and adjust the loss provision when appropriate. If a matter is both probable to result in liability and the amounts of loss can be reasonably estimated, we estimate and disclose the possible loss or range of loss to the extent necessary to make the consolidated financial statements not misleading. If the loss is not probable or cannot be reasonably estimated, a liability is not recorded in our consolidated financial statements.

[0001628280-18-009847:mdna:73]
[same as prior period, unchanged from 0001628280-18-000993:mdna:82]

[0001628280-18-009847:mdna:74]
[same as prior period, unchanged from 0001628280-18-000993:mdna:83]

[0001628280-18-009847:mdna:75]
[same as prior period, unchanged from 0001628280-18-000993:mdna:84]

[0001628280-18-009847:mdna:76]
[same as prior period, unchanged from 0001628280-18-000993:mdna:85]

[0001628280-18-009847:mdna:77]
[same as prior period, unchanged from 0001628280-18-000993:mdna:86]

[0001628280-18-009847:mdna:78]
In May 2014, the Financial Accounting Standards Board (“FASB”) and the International Accounting Standards Board (IASB) issued ASU 2014-09, Revenue from Contracts with Customers (Topic 606). The guidance substantially converges final standards on revenue recognition between the FASB and IASB providing a framework on addressing revenue recognition issues and, upon its effective date, replaces almost all existing revenue recognition guidance, including industry-specific guidance, in current U.S. generally accepted accounting principles. The FASB has subsequently issued the following multiple amendments to ASU 2014-09 which are all effective for annual reporting periods beginning after December 15, 2017.

[0001628280-18-009847:mdna:79]
As of April 1, 2018, we have adopted ASU 2014-09 and its amendments, reported the impact in our consolidated financial statements, and have implemented changes to our business processes, systems and controls to support revenue recognition and the related disclosures under this ASU.  Our assessment included a detailed review of representative contracts from each of our revenue streams and a comparison of our historical accounting policies and practices to the new standard. We adopted the new standards retrospectively with the cumulative effect of initially applying the guidance recognized at the date of initial application (the modified retrospective transition method) to all existing contracts that have remaining obligations as of April 1, 2018.  Accordingly, we have elected to retroactively adjust only those contracts that do not meet the definition of a complete contract at the date of the initial application.  This guidance will lead to recognizing certain revenue transactions sooner than in the past on certain contracts, as we will need to estimate the revenue we will be entitled to upon contract completion, and later on other contracts, such as Consulting and Statement of Work transactions, due to the lack of an enforceable right to payment for performance obligations satisfied over time. There are no changes in the accounting for our largest revenue stream which includes Inox Wind Ltd as our primary customer.  Across other revenue streams such as DVAR Equipment and DVAR Turnkey, the timing of revenue recognition will be affected for multiple types of contracts, primarily multiple performance obligation contracts in our Grid business unit, but those differences did not have a material impact on our consolidated financial statements.  The adjustment to opening retained earnings was not significant for the period commencing on April 1, 2018.  Additionally, the adoption of this new standard is not expected to have any tax impact on the consolidated financial statements. As part of this analysis, we evaluated our information technology capabilities and systems, and did not incur significant information technology costs to modify systems currently in place.

[0001628280-18-009847:mdna:80]
In January 2016, the FASB issued ASU 2016-01, Financial Instruments-Overall (Subtopic 825-10): Recognition and Measurement of Financial Assets and Financial Liabilities.  The amendments in ASU 2016-01 enhance the reporting model for financial instruments to provide users of financial statements with more decision-useful information. This ASU is effective for annual reporting periods beginning after December 15, 2017, and interim periods within those fiscal years.  We adopted ASU 2016-01 effective April 1, 2018 and noted no significant impact to our consolidated financial statements.

[0001628280-18-009847:mdna:81]
In February 2016, the FASB issued ASU 2016-02, Leases (Topic 842). The guidance in this ASU supersedes the leasing guidance in Topic 840, Leases. Under the new guidance, lessees are required to recognize lease assets and lease liabilities on the balance sheet for all leases with terms longer than 12 months. Leases will be classified as either finance or operating, with classification affecting the pattern of expense recognition in the income statement.

[0001628280-18-009847:mdna:82]
| • | In July 2018, the FASB issued ASU 2018-10, Codification improvements to Topic 842, Leases. The amendments in ASU 2018-10 provide more clarification in regards to the application and requirements of ASU 2016-02. |

[0001628280-18-009847:mdna:83]
This ASU and its amendments are effective for fiscal years beginning after December 15, 2019, including interim periods within those fiscal years. A modified retrospective transition approach is required for lessees for capital and operating leases existing at, or entered into after, the beginning of the earliest comparative period presented in the financial statements, with certain practical expedients available. We are currently evaluating the effects adoption of this guidance will have on our consolidated financial statements.

[0001628280-18-009847:mdna:84]
In June 2016, the FASB issued ASU 2016-13, Financial Instruments-Credit Losses (Topic 326): Measurement of Credit Losses on Financial Instruments.  The amendments in ASU 2016-13 provide more decision-useful information about the expected credit losses on financial instruments and other commitments to extend credit held by a reporting entity at each reporting date. The ASU is effective for annual reporting periods beginning after December 15, 2019, including interim periods within that year.  We are currently evaluating the impact, if any, the adoption of ASU 2016-13 may have on our consolidated financial statements.

[0001628280-18-009847:mdna:85]
[same as prior period, unchanged from 0001628280-18-000993:mdna:98]

[0001628280-18-009847:mdna:86]
| • | In August 2016, the FASB issued ASU 2016-15, Statement of Cash Flows (Topic 230): Classification of Certain Cash Receipts and Cash Payments. The amendments in ASU 2016-15 provide more guidance towards the classification of multiple different types of cash flows in order to reduce the diversity in reporting across entities. |

[0001628280-18-009847:mdna:87]
| • | In November 2016, the FASB issued ASU 2016-18, Statement of Cash Flows (Topic 230): Restricted Cash. The amendments in ASU 2016-18 explain the change during the period in the total of cash, cash equivalents, and amounts generally described as restricted cash or restricted cash equivalents. Therefore, amounts generally described as restricted cash and restricted cash equivalents should be included with cash and cash equivalents when reconciling the beginning-of-period and end-of-period total amounts shown on the statement of cash flows. |

[0001628280-18-009847:mdna:88]
We adopted ASU 2016-15 and ASU 2016-18 effective April 1, 2018 and noted no significant impact to our consolidated financial statements.

[0001628280-18-009847:mdna:89]
In October 2016, the FASB issued ASU 2016-16, Income Taxes (Topic 740): Intra-Entity Transfers of Assets Other Than Inventory.  The amendments in ASU 2016-16 improve the accounting for the income tax consequences of intra-entity transfers of assets other than inventory. The ASU is effective for annual reporting periods beginning after December 15, 2017, including interim periods within that year.  We adopted of ASU 2016-16 effective April 1, 2018 and noted no significant impact to our consolidated financial statements.

[0001628280-18-009847:mdna:90]
In January 2017, the FASB issued ASU 2017-03, Accounting Changes and Error Corrections (Topic 250) and Investments - Equity Method and Joint Ventures.  The amendments in ASU 2017-03 provide additional detail surrounding disclosures required related to adoption of new pronouncements. The ASU is effective for the periods of each related pronouncement.  We are currently evaluating the impact the adoption of ASU 2017-03 may have on our consolidated financial statements.

[0001628280-18-009847:mdna:91]
In February 2017, the FASB issued ASU 2017-05, Other Income - Gains and Losses from the Derecognition of Non-financial Assets (Subtopic 610-20).  The amendments in ASU 2017-05 clarify the scope of Subtopic 610-20, Other Income-Gains and Losses from the Derecognition of Non-financial Assets, and to add guidance for partial sales of non-financial assets. Subtopic 610-20, which was issued in May 2014 as a part of ASU No. 2014-09, Revenue from Contracts with Customers (Topic 606), provides guidance for recognizing gains and losses from the transfer of non-financial assets in contracts with non-customers.  We adopted ASU 2017-05 effective April 1, 2018 and adjusted the opening balance of accumulated deficit for $0.1 million for recognition of the deferred gain on the sale of the 64 Jackson Road building that occurred on March 28, 2018.

[0001628280-18-009847:mdna:92]
In May 2017, the FASB issued ASU 2017-09, Compensation - Stock Compensation (Subtopic 718) Scope of Modification Accounting.  The amendments in ASU 2017-09 provide clarity and reduce both (1) diversity in practice and (2) cost and complexity when applying the guidance in Topic 718, Compensation—Stock Compensation, to a change to the terms or conditions of a share-based payment award.  The ASU is effective for annual reporting periods beginning after December 15, 2017, including interim periods within those periods. We adopted ASU 2017-09 effective April 1, 2018 and noted no significant impact to our consolidated financial statements.

[0001628280-18-009847:mdna:93]
In July 2017, the FASB issued ASU 2017-11, Earnings per Share (Topic 260), Distinguishing Liabilities from Equity (Topic   480), and Derivatives and Hedging (Topic 815).  The amendments in ASU 2017-11 provide guidance for freestanding equity-linked financial instruments, such as warrants and conversion options in convertible debt or preferred stock, and should no longer be accounted for as a derivative liability at fair value as a result of the existence of a down round feature.  The ASU is effective for annual reporting periods beginning after December 15, 2018, including interim periods within those periods. We are currently evaluating the impact the adoption of ASU 2017-11 may have on our consolidated financial statements.

[0001628280-18-009847:mdna:94]
In August 2017, the FASB issued ASU 2017-12, Derivatives and Hedging (Topic 815): Targeted Improvements to Accounting for Hedging Activities.  The amendments in ASU 2017-12 provide improved financial reporting of hedging relationships to better portray the economic results of an entity’s risk management activities in its financial statements. In addition, the amendments in this update make certain targeted improvements to simplify the application of the hedge accounting guidance.  The ASU is effective for annual reporting periods beginning after December 15, 2018, including interim periods within those periods. We are currently evaluating the impact the adoption of ASU 2017-12 may have on our consolidated financial statements.

[0001628280-18-009847:mdna:95]
In June 2018, the FASB issued ASU 2018-07, Compensation - Stock Compensation (Topic 718): Improvements to Non-Employee Share Based Payment Accounting.  The amendments in ASU 2018-07 provide for the simplification of the measurement of share-based payment transactions for acquiring goods and services from non-employees.  The ASU is effective for annual reporting periods beginning after December 15, 2018, including interim periods within those periods. We are currently evaluating the impact the adoption of ASU 2018-07 may have on our consolidated financial statements.

[0001628280-18-009847:mdna:96]
We do not believe that, outside of those disclosed here, there are any other recently issued accounting pronouncements that will have a material impact on our consolidated financial statements.

[0001628280-18-009847:mdna:97]
33
