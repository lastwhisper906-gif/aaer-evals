# AMSC 10-Q controls and the auditor's report


## item_4_controls

[0001628280-18-009847:item_4_controls:1]
| ITEM 4. | CONTROLS AND PROCEDURES |

[0001628280-18-009847:item_4_controls:2]
Evaluation of Disclosure Controls and Procedures

[0001628280-18-009847:item_4_controls:3]
Our management, with the participation of our Chief Executive Officer and Chief Financial Officer, evaluated the effectiveness of our disclosure controls and procedures as of June 30, 2018. The term “disclosure controls and procedures,” as defined in Rules 13a-15(e) and 15d-15(e) under the Exchange Act, means controls and other procedures of a company that are designed to ensure that information required to be disclosed by a company in the reports that it files or submits under the Exchange Act is recorded, processed, summarized and reported within the time periods specified in the SEC’s rules and forms. Disclosure controls and procedures include, without limitation, controls and procedures designed to ensure that information required to be disclosed by a company in the reports that it files or submits under the Exchange Act is accumulated and communicated to the Company’s management, including its principal executive and principal financial officers, as appropriate to allow timely decisions regarding required disclosure. Management recognizes that any controls and procedures, no matter how well designed and operated, can provide only reasonable assurance of achieving their objectives and management necessarily applies its judgment in evaluating the cost-benefit relationship of possible controls and procedures. Based on that evaluation of our disclosure controls and procedures as of June 30, 2018, our Chief Executive Officer and Chief Financial Officer concluded that, as of such date, our disclosure controls and procedures were effective at the reasonable assurance level.

[0001628280-18-009847:item_4_controls:4]
Changes in Internal Control over Financial Reporting

[0001628280-18-009847:item_4_controls:5]
We implemented internal controls to ensure that we adequately evaluated our contracts and accurately account for revenue recognition under ASU 2014-09, Revenue from Contracts with Customers, as amended.  Apart from the foregoing, there were no other changes to our internal control over financial reporting during the quarter ended June 30, 2018, that have materially affected, or are reasonably likely to materially affect, our internal control over financial reporting.
