# AMSC notes — 0001628280-18-009847


## us-gaap:AccountsPayableAndAccruedLiabilitiesDisclosureTextBlock

[0001628280-18-009847:notes:1]
[same as prior period, unchanged from 0001628280-18-000993:notes:1]

[0001628280-18-009847:notes:2]
Accounts payable and accrued expenses at June 30, 2018 and March 31, 2018 consisted of the following (in thousands):

[0001628280-18-009847:notes:3]
|  | June 30, 2018 |  | March 31, 2018 |
| Accounts payable | $ | 3,863 |  |  | $ | 3,096 |  |
| Accrued inventories in-transit | 144 |  |  | 1,207 |  |
| Accrued other miscellaneous expenses | 1,999 |  |  | 2,412 |  |
| Advanced deposits | 2,729 |  |  | — |  |
| Accrued compensation | 4,348 |  |  | 3,605 |  |
| Income taxes payable | 309 |  |  | 536 |  |
| Accrued warranty | 1,752 |  |  | 1,769 |  |
| Total | $ | 15,144 |  |  | $ | 12,625 |  |

[0001628280-18-009847:notes:4]
The Company generally provides a one to two year warranty on its products, commencing upon delivery or installation where applicable. A provision is recorded upon revenue recognition to cost of revenues for estimated warranty expense based on historical experience.

[0001628280-18-009847:notes:5]
[same as prior period, unchanged from 0001628280-18-000993:notes:5]

[0001628280-18-009847:notes:6]
|  | Three months ended June 30, |
|  | 2018 |  | 2017 |
| Balance at beginning of period | $ | 1,769 |  |  | $ | 2,344 |  |
| Change in accruals for warranties during the period | 104 |  |  | 41 |  |
| Settlements during the period | (121 | ) |  | (359 | ) |
| Balance at end of period | $ | 1,752 |  |  | $ | 2,026 |  |


## us-gaap:BasisOfAccountingPolicyPolicyTextBlock

[0001628280-18-009847:notes:7]
These unaudited condensed consolidated financial statements of the Company have been prepared on a going concern basis in accordance with United States generally accepted accounting principles (“GAAP”) and the Securities and Exchange Commission’s (“SEC”) instructions to Form 10-Q. The going concern basis of presentation assumes that the Company will continue operations and will be able to realize its assets and discharge its liabilities and commitments in the normal course of business. Certain information and footnote disclosures normally included in the financial statements prepared in accordance with GAAP have been condensed or omitted pursuant to those instructions. The year-end condensed balance sheet data was derived from audited financial statements but does not include all disclosures required by GAAP. The unaudited condensed consolidated financial statements, in the opinion of management, reflect all adjustments (consisting of normal recurring adjustments) necessary for a fair statement of the results for the interim periods ended June 30, 2018 and 2017 and the financial position at June 30, 2018; however, these results are not necessarily indicative of results which may be expected for the full year. The interim condensed consolidated financial statements, and notes thereto, should be read in conjunction with the audited consolidated financial statements for the year ended March 31, 2018, and notes thereto, included in the Company’s annual report on Form 10-K for the year ended March 31, 2018 filed with the Securities and Exchange Commission on June 6, 2018.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001628280-18-009847:notes:8]
[same as prior period, unchanged from 0001628280-18-000993:notes:8]

[0001628280-18-009847:notes:9]
[same as prior period, unchanged from 0001628280-18-000993:notes:9]

[0001628280-18-009847:notes:10]
On September 25, 2017, the Company acquired Infinia Technology Corporation ("ITC") for approximately $3.8 million (the "Acquisition").  Located in Richmond, Washington, ITC is a technology firm founded in 2009 specializing in the design, development and commercialization of cryo-coolers for a wide range of applications. This technology supports the Company's efforts with the U.S. Navy and Ship Protection Systems (“SPS”) products.

[0001628280-18-009847:notes:11]
The results of ITC's operations, which were not significant from the date of acquisition until June 30, 2018, are included in the Company’s consolidated results from the date of Acquisition of September 25, 2017, through the three months ended June 30, 2018. Assuming the Acquisition had occurred on April 1, 2017 and 2016, the impact on the consolidated results of the Company would not have been significant.

[0001628280-18-009847:notes:12]
[same as prior period, unchanged from 0001628280-18-000993:notes:17]

[0001628280-18-009847:notes:13]
[same as prior period, unchanged from 0001628280-18-000993:notes:18]

[0001628280-18-009847:notes:14]
The Company did not identify any triggering events in the three months ended June 30, 2018, that would require interim impairment testing of goodwill.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001628280-18-009847:notes:15]
Commitments and Contingencies

[0001628280-18-009847:notes:16]
Legal Contingencies

[0001628280-18-009847:notes:17]
From time to time, the Company is involved in legal and administrative proceedings and claims of various types. The Company records a liability in its consolidated financial statements for these matters when a loss is known or considered probable and the amount can be reasonably estimated. The Company reviews these estimates each accounting period as additional information is known and adjusts the loss provision when appropriate. If a matter is both probable to result in a liability and the amounts of loss can be reasonably estimated, the Company estimates and discloses the possible loss or range of loss to the extent necessary to make the consolidated financial statements not misleading. If the loss is not probable or cannot be reasonably estimated, a liability is not recorded in its consolidated financial statements.

[0001628280-18-009847:notes:18]
On July 3, 2018, the Company, AMSC China and AMSC Austria entered into the Settlement Agreement with Sinovel. The Settlement Agreement settles the litigation and arbitration proceedings between the Company and Sinovel listed on Schedule 2 of the Settlement Agreement (the “Proceedings”), and any other civil claims, counterclaims, causes of action, rights and obligations directly or indirectly relating to the subject matters of the Proceedings and the contracts between the Company and Sinovel listed on Schedules 1 and 4 of the Settlement Agreement (the “Contracts”), subject to the exception described in Section 1.1 of the Settlement Agreement.  The Settlement Agreement was filed as Exhibit 10.1 to the Company’s Form 8-K filed with the Securities and Exchange Commission on July 9, 2018.

[0001628280-18-009847:notes:19]
Under the terms of the Settlement Agreement, Sinovel has agreed to pay AMSC China an aggregate cash amount in Renminbi (RMB) equivalent to $57.5 million, consisting of two installments. Sinovel paid the first installment of $32.5 million on July 4, 2018, and has agreed to pay the second installment of $25.0 million (the “Second Payment”) within ten (10) months after the U.S. District Court for the Western District of Wisconsin (the “District Court”) delivers the first sentence against Sinovel in the criminal case entitled United States v. Sinovel Wind Co., Ltd., Case Number 3:13-cr-00084-jdp. On July 6, 2018, the District Court delivered such sentence, and therefore the Second Payment is due by May 6, 2019 (the “Second Payment Due Date”). Mr. Wenyuan Wei, former Sinovel chairman and a current Sinovel shareholder, has delivered a letter of guarantee (the “Guarantee”) to the Company for the Second Payment should Sinovel fail to make such payment by the Second Payment Due Date.

[0001628280-18-009847:notes:20]
In addition, pursuant to the terms of the Settlement Agreement, the Company and AMSC Austria have granted Sinovel a non-exclusive license for certain AMSC intellectual property to be used solely in Sinovel’s doubly fed wind turbines (the “License”). AMSC has agreed not to sue Sinovel, Sinovel’s power converter suppliers or Sinovel’s customers for use of the technology covered by the License. In the event that Sinovel or Mr. Wei does not make the Second Payment by the Second Payment Due Date, the Settlement Agreement provides that the License will terminate.

[0001628280-18-009847:notes:21]
The Company and Sinovel have submitted withdrawal applications to terminate the Proceedings to the relevant Chinese courts and the Beijing Arbitration Commission. Subject to the Company and Sinovel complying with the terms of the Settlement Agreement, the Company and Sinovel have agreed not to re-institute any of the Proceedings. In addition, the Company and Sinovel have agreed to a mutual release and covenant not to sue covering all subject matters of the Proceedings and Contracts, effective upon the completion of the Second Payment.

[0001628280-18-009847:notes:22]
Other

[0001628280-18-009847:notes:23]
The Company enters into long-term construction contracts with customers that require the Company to obtain performance bonds. The Company is required to deposit an amount equivalent to some or all the face amount of the performance bonds into an escrow account until the termination of the bond. When the performance conditions are met, amounts deposited as collateral for the performance bonds are returned to the Company. In addition, the Company has various contractual arrangements in which minimum quantities of goods or services have been committed to be purchased on an annual basis.

[0001628280-18-009847:notes:24]
As of June 30, 2018, the Company had $0.2 million of restricted cash included in long-term assets. These amounts included in restricted cash primarily represent deposits to secure letters of credit for various supply contracts. These deposits are held in interest bearing accounts.


## us-gaap:ContractWithCustomerAssetAndLiabilityTableTextBlock

[0001628280-18-009847:notes:25]
Changes in the Company’s contract assets, which are included in “Unbilled AR” and "Deferred program costs" (see Note 7, “Accounts Receivable” and Note 8, "Inventory" for a reconciliation to the condensed consolidated balance sheet) and contract liabilities, which are included in the current portion and long term portion of “deferred revenue” in the Company’s condensed consolidated balance sheets, are as follows:

[0001628280-18-009847:notes:26]
|  | Unbilled AR |  | Deferred Program Costs |  | Contract Liabilities |
| Beginning balance as of March 31, 2018 | $ | 3,016 |  |  | $ | 2,567 |  |  | $ | 21,937 |  |
| Impact of adoption of ASC 606 | — |  |  | (1,599 | ) |  | (2,657 | ) |
| Increases for costs incurred to fulfill performance obligations | — |  |  | 1,132 |  |  | — |  |
| Increase (decrease) due to customer billings | (3,221 | ) |  | — |  |  | 4,281 |  |
| Decrease due to cost recognition on completed performance obligations | — |  |  | (48 | ) |  | — |  |
| Increase (decrease) due to recognition of revenue based on transfer of control of performance obligations | 4,824 |  |  | (9 | ) |  | (3,324 | ) |
| Other changes and FX impact | (16 | ) |  | 34 |  |  | (764 | ) |
| Ending balance as of June 30, 2018 | $ | 4,603 |  |  | $ | 2,077 |  |  | $ | 19,473 |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001628280-18-009847:notes:27]
[same as prior period, unchanged from 0001628280-18-000993:notes:37]

[0001628280-18-009847:notes:28]
The Company accounts for its warrants and contingent consideration as liabilities due to certain adjustment provisions within the instruments, which require that they be recorded at fair value. The warrants are subject to revaluation at each balance sheet date and any change in fair value is recorded as a change in fair value of warrants until the earlier of its expiration or its exercise at which time the warrant liability will be reclassified to equity. The Company calculated the fair value of the warrants utilizing an integrated lattice model.    See Note 6, "Fair Value Measurements", for further discussion.

[0001628280-18-009847:notes:29]
Hercules Warrants

[0001628280-18-009847:notes:30]
The Company issued Hercules warrants to purchase 13,927 shares of common stock (the “First Warrant”) and 25,641 shares of common stock (the “Second Warrant”) in conjunction with prior term loans that have been repaid in full.  On December 19, 2014, the Company entered into the Hercules Second Amendment.  In conjunction with the agreement, the Company issued the Hercules Warrant to purchase 58,823 shares of the Company’s common stock.  The Hercules Warrant is exercisable at any time after its issuance at an exercise price of $7.85 per share, subject to certain price-based and other anti-dilution adjustments, including the equity offering in May 2017, the acquisition of ITC with common stock in September 2017 and sales of common stock under the ATM entered into in January 2017, and expires on June 30, 2020.  This warrant had a fair value of $0.1 million as of June 30, 2018 and March 31, 2018.

[0001628280-18-009847:notes:31]
[same as prior period, unchanged from 0001628280-18-000993:notes:51]

[0001628280-18-009847:notes:32]
On November 13, 2014, the Company completed an offering of 909,090 units of the Company’s common stock with Hudson Bay Capital. Each unit consisted of one share of the Company’s common stock and 0.9 of a warrant to purchase one share of common stock, or a warrant to purchase in the aggregate 818,181 shares (the “November 2014 Warrant”).  The November 2014 Warrant is exercisable at any time, at an exercise price equal to $7.81 per share, subject to certain price-based and other anti-dilution adjustments including those noted above, and expires on November 13, 2019.

[0001628280-18-009847:notes:33]
[same as prior period, unchanged from 0001628280-18-000993:notes:53]

[0001628280-18-009847:notes:34]
| Fiscal Year 18 | June 30, 2018 |
| Risk-free interest rate | 2.40% |
| Expected annual dividend yield | — |
| Expected volatility | 67.40% |
| Term (years) | 1.37 |
| Fair value | $1.6 million |

[0001628280-18-009847:notes:35]
| Fiscal Year 17 | March 31, 2018 |  | December 31, 2017 |  | September 30, 2017 |  | June 30, 2017 |
| Risk-free interest rate | 2.20% |  | 1.87% |  | 1.49% |  | 1.44% |
| Expected annual dividend yield | — |  | — |  | — |  | — |
| Expected volatility | 65.86% |  | 65.86% |  | 65.64% |  | 67.21% |
| Term (years) | 1.62 |  | 1.87 |  | 2.12 |  | 2.37 |
| Fair value | $1.1 million |  | $0.4 million |  | $0.8 million |  | $0.9 million |

[0001628280-18-009847:notes:36]
The Company recorded a net loss of $0.5 million and a net gain of $0.9 million, resulting from an increase and decrease in the fair value of the November 2014 Warrant during the three months ended June 30, 2018 and 2017, respectively.


## us-gaap:DisaggregationOfRevenueTableTextBlock

[0001628280-18-009847:notes:37]
The following tables disaggregate the Company’s revenue by product line and by shipment destination:

[0001628280-18-009847:notes:38]
|  | Three months endedJune 30, 2018 |
| Product Line: | Grid |  | Wind |
| Equipment and systems | $ | 7,462 |  |  | $ | 3,492 |  |
| Services and technology development | 1,467 |  |  | 186 |  |
| Total | $ | 8,929 |  |  | $ | 3,678 |  |
| Region: |  |  |  |
| Americas | $ | 7,496 |  |  | $ | 23 |  |
| Asia Pacific | 808 |  |  | 3,595 |  |
| EMEA | 625 |  |  | 60 |  |
| Total | $ | 8,929 |  |  | $ | 3,678 |  |


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001628280-18-009847:notes:39]
[same as prior period, unchanged from 0001628280-18-000993:notes:62]

[0001628280-18-009847:notes:40]
The Company accounts for its stock-based compensation at fair value. The following table summarizes stock-based compensation expense by financial statement line item for the three months ended June 30, 2018 and 2017 (in thousands):

[0001628280-18-009847:notes:41]
|  | Three months ended June 30, |
|  | 2018 |  | 2017 |
| Cost of revenues | $ | 40 |  |  | $ | 36 |  |
| Research and development | 51 |  |  | 49 |  |
| Selling, general and administrative | 694 |  |  | 669 |  |
| Total | $ | 785 |  |  | $ | 754 |  |

[0001628280-18-009847:notes:42]
The Company issued 34,480 shares of immediately vested common stock and 276,000 shares of restricted stock awards during the three months ended June 30, 2018, and issued 33,487 shares of immediately vested common stock during the three months ended June 30, 2017.  These restricted stock awards generally vest over 2-3 years.  Awards for restricted stock include both time-based and performance-based awards.  For options and awards that vest upon the passage of time, expense is being recorded over the vesting period.  Performance-based awards are expensed over the requisite service period based on probability of achievement.  In addition, the Company issued 16,667 restricted stock units under the 2007 Stock Incentive Plan during the three months ended June 30, 2017, each of which represents the right to receive one share of common stock in connection with a severance agreement entered into with one of the Company's former executive officers. These restricted stock units vested and were settled in shares of common stock on the eighth day after receipt of an irrevocable release.

[0001628280-18-009847:notes:43]
The estimated fair value of the Company’s stock-based awards, less expected annual forfeitures, is amortized over the awards’ service period. The total unrecognized compensation cost for unvested outstanding stock options was $0.2 million at June 30, 2018. This expense will be recognized over a weighted average expense period of approximately 0.7 years. The total unrecognized compensation cost for unvested outstanding restricted stock was $3.5 million at June 30, 2018. This expense will be recognized over a weighted-average expense period of approximately 2.1 years.

[0001628280-18-009847:notes:44]
The Company did not grant any stock options during the three months ended June 30, 2018 or 2017.


## us-gaap:EarningsPerShareTextBlock

[0001628280-18-009847:notes:45]
[same as prior period, unchanged from 0001628280-18-000993:notes:69]

[0001628280-18-009847:notes:46]
Basic net loss per share (“EPS”) is computed by dividing net loss by the weighted-average number of common shares outstanding for the period. Where applicable, diluted EPS is computed by dividing the net loss by the weighted-average number of common shares and dilutive common equivalent shares outstanding during the period, calculated using the treasury stock method. Common equivalent shares include the effect of restricted stock, exercise of stock options and warrants and contingently issuable shares. For the three months ended June 30, 2018, 1.1 million shares were not included in the calculation of diluted EPS as they were considered anti-dilutive, of which 0.2 million relate to outstanding stock options, and 0.9 million relate to outstanding warrants.  For the three months ended June 30, 2017, 1.5 million shares were not included in the calculation of diluted EPS as they were considered anti-dilutive, of which 0.3 million relate to outstanding stock options, and 1.2 million relate to outstanding warrants.

[0001628280-18-009847:notes:47]
The following table reconciles the numerators and denominators of the earnings per share calculation for the three months ended June 30, 2018 and 2017 (in thousands, except per share data):

[0001628280-18-009847:notes:48]
|  | Three months ended June 30, |
|  | 2018 |  | 2017 |
| Numerator: |  |  |  |
| Net loss | $ | (4,737 | ) |  | $ | (15,252 | ) |
| Denominator: |  |  |  |
| Weighted-average shares of common stock outstanding | 20,999 |  |  | 17,089 |  |
| Weighted-average shares subject to repurchase | (832 | ) |  | (311 | ) |
| Shares used in per-share calculation ― basic | 20,167 |  |  | 16,778 |  |
| Shares used in per-share calculation ― diluted | 20,167 |  |  | 16,778 |  |
| Net loss per share ― basic | $ | (0.23 | ) |  | $ | (0.91 | ) |
| Net loss per share ― diluted | $ | (0.23 | ) |  | $ | (0.91 | ) |


## us-gaap:FairValueDisclosuresTextBlock

[0001628280-18-009847:notes:49]
[same as prior period, unchanged from 0001628280-18-000993:notes:73]

[0001628280-18-009847:notes:50]
[same as prior period, unchanged from 0001628280-18-000993:notes:74]

[0001628280-18-009847:notes:51]
[same as prior period, unchanged from 0001628280-18-000993:notes:75]

[0001628280-18-009847:notes:52]
The Company provides a gross presentation of activity within Level 3 measurement roll-forward and details of transfers in and out of Level 1 and 2 measurements.  A change in the hierarchy of an investment from its current level is reflected in the period during which the pricing methodology of such investment changes.  Disclosure of the transfer of securities from Level 1 to Level 2 or Level 3 is made in the event that the related security is significant to total cash and investments.  The Company did not have any transfers of assets and liabilities from Level 1, Level 2 or Level 3 of the fair value measurement hierarchy during the three months ended June 30, 2018.

[0001628280-18-009847:notes:53]
[same as prior period, unchanged from 0001628280-18-000993:notes:77]

[0001628280-18-009847:notes:54]
The following table provides the assets and liabilities carried at fair value on a recurring basis, measured as of June 30, 2018 and March 31, 2018 (in thousands):

[0001628280-18-009847:notes:55]
|  | TotalCarryingValue |  | Quoted Prices inActive Markets(Level 1) |  | Significant OtherObservable Inputs(Level 2) |  | SignificantUnobservable Inputs(Level 3) |
| June 30, 2018: |  |  |  |  |  |  |  |
| Assets: |  |  |  |  |  |  |  |
| Cash equivalents | $ | 24,704 |  |  | $ | 24,704 |  |  | $ | — |  |  | $ | — |  |
| Derivative liabilities: |  |  |  |  |  |  |  |
| Warrants | 1,681 |  |  | — |  |  | — |  |  | 1,681 |  |

[0001628280-18-009847:notes:56]
|  | TotalCarryingValue |  | Quoted Prices inActive Markets(Level 1) |  | Significant OtherObservable Inputs(Level 2) |  | SignificantUnobservable Inputs(Level 3) |
| March 31, 2018: |  |  |  |  |  |  |  |
| Assets: |  |  |  |  |  |  |  |
| Cash equivalents | $ | 32,589 |  |  | $ | 32,589 |  |  | $ | — |  |  | $ | — |  |
| Derivative liabilities: |  |  |  |  |  |  |  |
| Warrants | $ | 1,217 |  |  | $ | — |  |  | $ | — |  |  | $ | 1,217 |  |

[0001628280-18-009847:notes:57]
[same as prior period, unchanged from 0001628280-18-000993:notes:81]

[0001628280-18-009847:notes:58]
|  | Warrants |
| April 1, 2018 | $ | 1,217 |  |
| Mark to market adjustment | 464 |  |
| Balance at June 30, 2018 | $ | 1,681 |  |

[0001628280-18-009847:notes:59]
|  | Warrants |
| April 1, 2017 | $ | 1,923 |  |
| Mark to market adjustment | (925 | ) |
| Balance at June 30, 2017 | $ | 998 |  |

[0001628280-18-009847:notes:60]
[same as prior period, unchanged from 0001628280-18-000993:notes:84]

[0001628280-18-009847:notes:61]
[same as prior period, unchanged from 0001628280-18-000993:notes:85]

[0001628280-18-009847:notes:62]
[same as prior period, unchanged from 0001628280-18-000993:notes:86]

[0001628280-18-009847:notes:63]
[same as prior period, unchanged from 0001628280-18-000993:notes:87]

[0001628280-18-009847:notes:64]
Warrants were issued in conjunction with a Securities Purchase Agreement (the “Purchase Agreement”) with Capital Ventures International (“CVI”), an equity offering to Hudson Bay Capital in November 2014, and a Loan and Security Agreement with Hercules Technology Growth Capital, Inc. (“Hercules”).  These warrants issued to CVI expired on October 4, 2017.  See Note 13 “Warrants and Derivative Liabilities,” for additional information. Outstanding warrants are subject to revaluation at each balance sheet date, and any change in fair value will be recorded as a change in fair value in derivatives and warrants until the earlier of their exercise or expiration.

[0001628280-18-009847:notes:65]
The Company relies on various assumptions in a lattice model to determine the fair value of warrants. The Company has valued the warrants within Level 3 of the valuation hierarchy. See Note 13, “Warrants and Derivative Liabilities,” for a discussion of the warrants and the valuation assumptions used.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001628280-18-009847:notes:66]
[same as prior period, unchanged from 0001628280-18-000993:notes:91]

[0001628280-18-009847:notes:67]
The Company recorded an income tax benefit of less than $0.1 million in the three months ended June 30, 2018.  The Company recorded income tax expense of $0.1 million in the three months ended June 30, 2017.

[0001628280-18-009847:notes:68]
On December 22, 2017, the Tax Cuts and Jobs Act of 2017 (the “Act”) was signed into law. ASC Topic 740 requires deferred tax assets and liabilities to be measured using the enacted rate for the period in which they are expected to reverse.   Accordingly, the new 21% U.S. Federal corporate tax rate was used to measure the U.S. deferred tax assets and liabilities that will reverse in future periods. The Company's deferred tax attributes are generally subject to a full valuation allowance in the U.S. and thus, this adjustment to the attributes did not impact the tax provision.  In addition, the new legislation includes a one-time transition tax in which all foreign earnings are deemed to be repatriated to the U.S. and taxable at specified rates included within the Act. The Company reviewed the accumulated foreign earnings aggregated across all non U.S. subsidiaries, net of foreign deficits.  The Company believes it is in an aggregate net foreign deficit position for U.S. tax purposes and therefore not liable for the transition tax.  The SEC staff issued Staff Accounting Bulletin No. 118, which provides guidance for companies that have not completed their accounting for the income tax effects of the Act in the period of enactment, allowing for a measurement period of up to one year after the enactment date to finalize the recording of the related tax impacts.  The Company made reasonable estimates and does not anticipate significant revisions to the accounting for the tax impact of the Act, but has not completed the accounting for the tax effects of the Act at June 30, 2018.  The Company will continue to assess its provision for income taxes as future guidance is issued, but does not currently anticipate significant revisions will be necessary. The ultimate impact may differ from the Company's provisional estimates, possibly materially, due to additional analysis, changes in interpretations and assumptions the Company has made, additional regulatory guidance that may be used and actions the Company may take as a result of the Act. The accounting is expected to be complete within the one year measurement period in accordance with the measurement period guidance outlined in Staff Accounting Bulletin No. 118.

[0001628280-18-009847:notes:69]
Accounting for income taxes requires a two-step approach to recognizing and measuring uncertain tax positions.  The first step is to evaluate the tax position for recognition by determining if, based on the technical merits, it is more likely than not the position will be sustained upon audit, including resolution of related appeals or litigation processes, if any.  The second step is to measure the tax benefit as the largest amount that is more than 50% likely to be realized upon ultimate settlement.  The Company re-evaluates these uncertain tax positions on a quarterly basis.  The evaluation is based on factors including, but not limited to, changes in facts or circumstances, changes in tax law, effectively settled issues under audit and new audit activity.  Any changes in these factors could result in the recognition of a tax benefit or an additional charge to the tax provision.  The Company did not identify any uncertain tax positions in the three months ended June 30, 2018 and did not have any gross unrecognized tax benefits as of March 31, 2018.


## us-gaap:InventoryDisclosureTextBlock

[0001628280-18-009847:notes:70]
[same as prior period, unchanged from 0001628280-18-000993:notes:97]

[0001628280-18-009847:notes:71]
Inventory, net of reserves, at June 30, 2018 and March 31, 2018 consisted of the following (in thousands):

[0001628280-18-009847:notes:72]
|  | June 30, 2018 |  | March 31, 2018 |
| Raw materials | $ | 6,316 |  |  | $ | 7,526 |  |
| Work-in-process | 1,327 |  |  | 920 |  |
| Finished goods | 8,633 |  |  | 8,767 |  |
| Deferred program costs | 2,077 |  |  | 2,567 |  |
| Net inventory | $ | 18,353 |  |  | $ | 19,780 |  |

[0001628280-18-009847:notes:73]
The Company recorded inventory write-downs of $0.1 million and $0.3 million for the three months ended June 30, 2018 and 2017, respectively.  These write downs were based on evaluating its inventory on hand for excess quantities and obsolescence.

[0001628280-18-009847:notes:74]
Deferred program costs as of June 30, 2018 and March 31, 2018 primarily represent costs incurred on programs where the Company needs to complete performance obligations before the related revenue and costs will be recognized.


## us-gaap:LoansNotesTradeAndOtherReceivablesDisclosureTextBlock

[0001628280-18-009847:notes:75]
[same as prior period, unchanged from 0001628280-18-000993:notes:102]

[0001628280-18-009847:notes:76]
Accounts receivable at June 30, 2018 and March 31, 2018 consisted of the following (in thousands):

[0001628280-18-009847:notes:77]
|  | June 30, 2018 |  | March 31, 2018 |
| Accounts receivable (billed) | $ | 6,983 |  |  | $ | 4,403 |  |
| Accounts receivable (unbilled) | 4,603 |  |  | 3,016 |  |
| Less: Allowance for doubtful accounts | (54 | ) |  | (54 | ) |
| Accounts receivable, net | $ | 11,532 |  |  | $ | 7,365 |  |

[0001628280-18-009847:notes:78]
Note Receivable

[0001628280-18-009847:notes:79]
The Company entered into a purchase and sale agreement dated February 1, 2018, for the sale of the Devens facility (including land, building and building improvements) located at 64 Jackson Road, Devens, Massachusetts to 64 Jackson Road, LLC, a limited liability company, in the amount of $23.0 million. The terms for payment included a $1.0 million security deposit, and a note receivable for $6.0 million payable to the Company with the remaining cash net of certain adjustments for closing costs at the date of settlement.  The note receivable is due in two $3.0 million installments plus accrued interest at a rate of 1.96% on March 31, 2019 and March 31, 2020. The note is subordinate to East Boston Savings Bank's mortgage on the Devens property.

[0001628280-18-009847:notes:80]
The note receivable was discounted to its present value of $5.7 million utilizing a discount rate of 6%, which was based on management’s assessment of what an appropriate loan at current market rates would be. The $0.3 million discount was recorded as an offset to the long term portion of the note receivable, and is being amortized to interest income over the term of the note. In addition, the resulting gain of $0.1 million from the sale of the Devens property which was deferred previously was recorded as a component of the cumulative effect of an accounting change upon the adoption of ASU 2017-05 which was issued as a part of ASU 2014-09.  This gain was recorded as an offset to the opening accumulated deficit.

[0001628280-18-009847:notes:81]
Note receivable as of June 30, 2018 and March 31, 2018 consisted of the following (in thousands):

[0001628280-18-009847:notes:82]
| Current assets | June 30, 2018 |  | March 31, 2018 |
| Note receivable, current | $ | 3,000 |  |  | $ | 3,000 |  |
| Total current note receivable | $ | 3,000 |  |  | $ | 3,000 |  |
| Long term assets |  |  |  |
| Note receivable, long term | $ | 3,000 |  |  | $ | 3,000 |  |
| Note receivable discount | (280 | ) |  | (336 | ) |
| Deferred gain on sale | — |  |  | (105 | ) |
| Total long term note receivable | $ | 2,720 |  |  | $ | 2,559 |  |


## us-gaap:NewAccountingPronouncementsAndChangesInAccountingPrinciplesTextBlock

[0001628280-18-009847:notes:83]
Recent Accounting Pronouncements

[0001628280-18-009847:notes:84]
In May 2014, the Financial Accounting Standards Board (“FASB”) and the International Accounting Standards Board ("IASB") issued, ASU 2014-09, Revenue from Contracts with Customers (Topic 606). The guidance substantially converges final standards on revenue recognition between the FASB and IASB providing a framework on addressing revenue recognition issues and, upon its effective date, replaces almost all existing revenue recognition guidance, including industry-specific guidance, in current U.S. generally accepted accounting principles. The FASB has subsequently issued multiple amendments to ASU 2014-09 which are all effective for annual reporting periods beginning after December 15, 2017.

[0001628280-18-009847:notes:85]
As of April 1, 2018, the Company has adopted ASU 2014-09 and its amendments, reported the impact in its consolidated financial statements, and has implemented changes to its business processes, systems and controls to support revenue recognition and the related disclosures under this ASU.  The Company’s assessment included a detailed review of representative contracts from each of the Company’s revenue streams and a comparison of its historical accounting policies and practices to the new standard. The Company adopted the new standards retrospectively with the cumulative effect of initially applying the guidance recognized at the date of initial application (the modified retrospective transition method) to all existing contracts that have remaining obligations as of April 1, 2018.  Accordingly, the Company has elected to retroactively adjust only those contracts that do not meet the definition of a complete contract at the date of the initial application.  This guidance will lead to recognizing certain revenue transactions sooner than in the past on certain contracts, as the Company will need to estimate the revenue it will be entitled to upon contract completion, and later on other contracts, such as Consulting and Statement of Work transactions, due to the lack of an enforceable right to payment for performance obligations satisfied over time. There are no changes in the accounting for its largest revenue stream which includes Inox Wind Ltd as its primary customer.  Across other revenue streams such as DVAR Equipment and DVAR Turnkey, the timing of revenue recognition will be affected for multiple types of contracts, primarily multiple performance obligation contracts in its Grid business unit, but those differences did not have a material impact on its consolidated financial statements.  The adjustment to opening accumulated deficit was not significant in the period commencing on April 1, 2018.  Additionally, the adoption of this new standard is not expected to have any tax impact on the consolidated financial statements. As part of this analysis, the Company evaluated its information technology capabilities and systems, and did not incur significant information technology costs to modify systems currently in place.

[0001628280-18-009847:notes:86]
In January 2016, the FASB issued ASU 2016-01, Financial Instruments-Overall (Subtopic 825-10): Recognition and Measurement of Financial Assets and Financial Liabilities.  The amendments in ASU 2016-01 will enhance the reporting model for financial instruments to provide users of financial statements with more decision-useful information. This ASU is effective for annual reporting periods beginning after December 15, 2017, and interim periods within those fiscal years.  The Company adopted ASU 2016-01 effective April 1, 2018 and noted no significant impact to its consolidated financial statements.

[0001628280-18-009847:notes:87]
In February 2016, the FASB issued ASU 2016-02, Leases (Topic 842). The guidance in this ASU supersedes the leasing guidance in Topic 840, Leases. Under the new guidance, lessees are required to recognize lease assets and lease liabilities on the balance sheet for all leases with terms longer than 12 months. Leases will be classified as either finance or operating, with classification affecting the pattern of expense recognition in the income statement.

[0001628280-18-009847:notes:88]
| • | In July 2018, the FASB issued ASU 2018-10, Codification improvements to Topic 842, Leases. The amendments in ASU 2018-10 provide more clarification in regards to the application and requirements of ASU 2016-02. |

[0001628280-18-009847:notes:89]
This ASU and its amendments are effective for fiscal years beginning after December 15, 2019, including interim periods within those fiscal years. A modified retrospective transition approach is required for lessees for capital and operating leases existing at, or entered into after, the beginning of the earliest comparative period presented in the financial statements, with certain practical expedients available. The Company is currently evaluating the effects adoption of this guidance will have on its consolidated financial statements.

[0001628280-18-009847:notes:90]
In June 2016, the FASB issued ASU 2016-13, Financial Instruments-Credit Losses (Topic 326): Measurement of Credit Losses on Financial Instruments.  The amendments in ASU 2016-13 will provide more decision-useful information about the expected credit losses on financial instruments and other commitments to extend credit held by a reporting entity at each reporting date. The ASU is effective for annual reporting periods beginning after December 15, 2019, including interim periods within that year.  The Company is currently evaluating the impact, if any, the adoption of ASU 2016-13 may have on its consolidated financial statements.

[0001628280-18-009847:notes:91]
In 2016, the FASB issued the following two ASU's on Statement of Cash Flows (Topic 230).  Both amendments are effective for annual reporting periods beginning after December 15, 2017, including interim periods within that year.

[0001628280-18-009847:notes:92]
| • | In August 2016, the FASB issued ASU 2016-15, Statement of Cash Flows (Topic 230): Classification of Certain Cash Receipts and Cash Payments. The amendments in ASU 2016-15 provide more guidance towards the classification of multiple different types of cash flows in order to reduce the diversity in reporting across entities. |

[0001628280-18-009847:notes:93]
| • | In November 2016, the FASB issued ASU 2016-18, Statement of Cash Flows (Topic 230): Restricted Cash. The amendments in ASU 2016-18 explain the change during the period in the total of cash, cash equivalents, and amounts generally described as restricted cash or restricted cash equivalents. Therefore, amounts generally described as restricted cash and restricted cash equivalents should be included with cash and cash equivalents when reconciling the beginning-of-period and end-of-period total amounts shown on the statement of cash flows. |

[0001628280-18-009847:notes:94]
The Company adopted ASU 2016-15 and ASU 2016-18 effective April 1, 2018 and noted no significant impact to its consolidated financial statements.

[0001628280-18-009847:notes:95]
In October 2016, the FASB issued ASU 2016-16, Income Taxes (Topic 740): Intra-Entity Transfers of Assets Other Than Inventory.  The amendments in ASU 2016-16 will improve the accounting for the income tax consequences of intra-entity transfers of assets other than inventory. The ASU is effective for annual reporting periods beginning after December 15, 2017, including interim periods within that year.  The Company adopted ASU 2016-16 effective April 1, 2018 and noted no significant impact to its consolidated financial statements.

[0001628280-18-009847:notes:96]
In January 2017, the FASB issued ASU 2017-03, Accounting Changes and Error Corrections (Topic 250) and Investments - Equity Method and Joint Ventures.  The amendments in ASU 2017-03 provide additional detail surrounding disclosures required related to adoption of new pronouncements. The ASU is effective for the periods of each related pronouncement.  The Company is currently evaluating the impact the adoption of ASU 2017-03 may have on its consolidated financial statements.

[0001628280-18-009847:notes:97]
In February 2017, the FASB issued ASU 2017-05, Other Income - Gains and Losses from the Derecognition of Non-financial Assets (Subtopic 610-20).  The amendments in ASU 2017-05 clarify the scope of Subtopic 610-20, Other Income-Gains and Losses from the Derecognition of Non-financial Assets, and to add guidance for partial sales of non-financial assets. Subtopic 610-20, which was issued in May 2014 as a part of ASU No. 2014-09, Revenue from Contracts with Customers (Topic 606), provides guidance for recognizing gains and losses from the transfer of non-financial assets in contracts with non-customers.  The Company adopted ASU 2017-05 effective April 1, 2018 and adjusted the opening balance of accumulated deficit for $0.1 million for recognition of the deferred gain on the sale of the 64 Jackson Road building that occurred on March 28, 2018.

[0001628280-18-009847:notes:98]
In May 2017, the FASB issued ASU 2017-09, Compensation - Stock Compensation (Subtopic 718) Scope of Modification Accounting.  The amendments in ASU 2017-09 provide clarity and reduce both (1) diversity in practice and (2) cost and complexity when applying the guidance in Topic 718, Compensation—Stock Compensation, to a change to the terms or conditions of a share-based payment award.  The ASU is effective for annual reporting periods beginning after December 15, 2017, including interim periods within those periods. The Company adopted ASU 2017-09 effective April 1, 2018 and noted no significant impact to its consolidated financial statements.

[0001628280-18-009847:notes:99]
In July 2017, the FASB issued ASU 2017-11, Earnings per Share (Topic 260), Distinguishing Liabilities from Equity (Topic   480), and Derivatives and Hedging (Topic 815).  The amendments in ASU 2017-11 provide guidance for freestanding equity-linked financial instruments, such as warrants and conversion options in convertible debt or preferred stock, and should no longer be accounted for as a derivative liability at fair value as a result of the existence of a down round feature.  The ASU is effective for annual reporting periods beginning after December 15, 2018, including interim periods within those periods. The Company is currently evaluating the impact the adoption of ASU 2017-11 may have on its consolidated financial statements.

[0001628280-18-009847:notes:100]
In August 2017, the FASB issued ASU 2017-12, Derivatives and Hedging (Topic 815): Targeted Improvements to Accounting for Hedging Activities.  The amendments in ASU 2017-12 provide improved financial reporting of hedging relationships to better portray the economic results of an entity’s risk management activities in its financial statements. In addition, the amendments in this update make certain targeted improvements to simplify the application of the hedge accounting guidance.  The ASU is effective for annual reporting periods beginning after December 15, 2018, including interim periods within those periods. The Company is currently evaluating the impact the adoption of ASU 2017-12 may have on its consolidated financial statements.

[0001628280-18-009847:notes:101]
In June 2018, the FASB issued ASU 2018-07, Compensation - Stock Compensation (Topic 718): Improvements to Non-Employee Share Based Payment Accounting.  The amendments in ASU 2018-07 provide for the simplification of the measurement of share-based payment transactions for acquiring goods and services from non-employees.  The ASU is effective for annual reporting periods beginning after December 15, 2018, including interim periods within those periods. The Company is currently evaluating the impact the adoption of ASU 2018-07 may have on its consolidated financial statements.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0001628280-18-009847:notes:102]
[same as prior period, unchanged from 0001628280-18-000993:notes:128]

[0001628280-18-009847:notes:103]
[same as prior period, unchanged from 0001628280-18-000993:notes:129]

[0001628280-18-009847:notes:104]
[same as prior period, unchanged from 0001628280-18-000993:notes:130]

[0001628280-18-009847:notes:105]
[same as prior period, unchanged from 0001628280-18-000993:notes:132]

[0001628280-18-009847:notes:106]
The Company has experienced recurring operating losses and as of June 30, 2018, the Company had an accumulated deficit of $993.0 million. In addition, the Company has experienced recurring negative operating cash flows.  At June 30, 2018, the Company had cash and cash equivalents of $26.8 million, with no outstanding debt other than ordinary trade payables. Cash used in operations for the three months ended June 30, 2018 was $6.9 million.

[0001628280-18-009847:notes:107]
From April 1, 2011 through the date of this filing, the Company has reduced its global workforce substantially.  As of June 30, 2018, the Company had a global workforce of 231 persons.  The Company plans to closely monitor its expenses and, if required, expects to further reduce operating costs and capital spending to enhance liquidity.

[0001628280-18-009847:notes:108]
Over the last several years, the Company has entered into several debt and equity financing arrangements in order to raise capital.  Since April 1, 2012, the Company has generated aggregate cash flows from financing activities of $85.0 million.  Included in this amount are proceeds of approximately $17.0 million after deducting underwriting discounts and commissions and offering expenses payable by the Company, from the Company's equity offering completed on May 10, 2017, which includes the subsequent exercise by the underwriters of their option in full to purchase additional shares.  The Company terminated its At Market Issuance Sales Agreement ("ATM") with FBR Capital Markets & Co. in conjunction with this equity offering.  See Note 14 “Stockholders' Equity” for further discussion of these financing arrangements.

[0001628280-18-009847:notes:109]
On July 3, 2018, the Company and its wholly-owned subsidiaries Suzhou AMSC Superconductor Co. Ltd. (“AMSC China”) and AMSC Austria GMBH (“AMSC Austria”) entered into a settlement agreement (the “Settlement Agreement”) with Sinovel Wind Group Co., Ltd. (“Sinovel”). The Settlement Agreement settles the litigation and arbitration proceedings between the Company and Sinovel, as further described in Note 15 “Commitments and Contingencies".  Under the terms of the Settlement Agreement, Sinovel has agreed to pay AMSC China an aggregate cash amount in Renminbi (RMB) equivalent to $57.5 million, consisting of two installments. Sinovel paid the first installment of $32.5 million on July 4, 2018, and has agreed to pay the second installment of $25.0 million (the “Second Payment”) within ten (10) months after the U.S. District Court for the Western District of Wisconsin (the “District Court”) delivers the first sentence against Sinovel in the criminal case entitled United States v. Sinovel Wind Co., Ltd., Case Number 3:13-cr-00084-jdp. On July 6, 2018, the District Court delivered such sentence, and therefore the Second Payment is due by May 6, 2019 (the “Second Payment Due Date”). On July 24, 2018, AMSC China paid $30.7 million to AMSC Austria to settle outstanding inter-company balances.

[0001628280-18-009847:notes:110]
On February 5, 2018, the Company entered into a Purchase and Sale Agreement (the “PSA”) with 64 Jackson, LLC (the “Purchaser”) and Stewart Title Guaranty Company (“Escrow Agent”), to effectuate the sale of certain real property located at 64 Jackson Road, Devens, Massachusetts, including the building that had served as the Company’s headquarters (collectively, the “Property”), in exchange for total consideration of $23.0 million, composed of (i) cash consideration of $17.0 million, and (ii) a $6.0 million subordinated secured commercial promissory note payable to the Company (the "Seller Note"). Subsequently, the Seller, the Purchaser and Jackson 64 MGI, LLC (“Assignee”) entered into an Assignment of Purchase and Sale Agreement (the “Assignment Agreement”), pursuant to which the Purchaser assigned all of its rights and interests in the PSA to the Assignee and the Assignee agreed to assume all of the Purchaser’s obligations and liabilities under the PSA. The transaction closed on March 28, 2018, at which time the Company received, from the Assignee, cash consideration, net of certain agreed upon closing costs, of $16.9 million, and the Seller Note at an interest rate of 1.96%. The Seller Note is secured by a subordinated second mortgage on the Property and a subordinated second assignment of leases and rents.

[0001628280-18-009847:notes:111]
[same as prior period, unchanged from 0001628280-18-000993:notes:136]

[0001628280-18-009847:notes:112]
The Company believes that based on the information presented above and its quarterly management assessment, it has sufficient liquidity to fund its operations and capital expenditures for the next twelve months following the issuance of the financial statements for the three months ended June 30, 2018. The Company’s liquidity is highly dependent on its ability to increase revenues, including its ability to collect revenues under our agreements with Inox, its ability to control its operating costs, and its ability to raise additional capital, if necessary. There can be no assurance that the Company will be able to continue to raise additional capital, on favorable terms or at all, from other sources or execute on any other means of improving liquidity described above.


## us-gaap:PropertyPlantAndEquipmentDisclosureTextBlock

[0001628280-18-009847:notes:113]
[same as prior period, unchanged from 0001628280-18-000993:notes:138]

[0001628280-18-009847:notes:114]
The cost and accumulated depreciation of property and equipment at June 30, 2018 and March 31, 2018 are as follows (in thousands):

[0001628280-18-009847:notes:115]
|  | June 30, 2018 |  | March 31, 2018 |
| Construction in progress - equipment | 528 |  |  | 654 |  |
| Equipment and software | 72,466 |  |  | 72,760 |  |
| Furniture and fixtures | 1,890 |  |  | 1,878 |  |
| Leasehold improvements | 1,632 |  |  | 1,426 |  |
| Property, plant and equipment, gross | 76,516 |  |  | 76,718 |  |
| Less accumulated depreciation | (64,962 | ) |  | (64,205 | ) |
| Property, plant and equipment, net | $ | 11,554 |  |  | $ | 12,513 |  |

[0001628280-18-009847:notes:116]
Depreciation expense was $1.1 million and $4.2 million for the three months ended June 30, 2018 and 2017, respectively.   Included in depreciation expense for the three months ended June 30, 2017 is $2.5 million of accelerated depreciation recorded to cost of revenues related to revised estimates of the remaining useful lives of certain pieces of manufacturing equipment. Construction in progress - equipment primarily includes capital investments in the Company's newly leased facility in Ayer, Massachusetts.


## us-gaap:ReconciliationOfAssetsFromSegmentToConsolidatedTextBlock

[0001628280-18-009847:notes:117]
Total assets for the two business segments as of June 30, 2018 and March 31, 2018 are as follows (in thousands):

[0001628280-18-009847:notes:118]
|  | June 30, 2018 |  | March 31, 2018 |
| Wind | $ | 14,830 |  |  | $ | 16,790 |  |
| Grid | 42,701 |  |  | 37,012 |  |
| Corporate assets | 26,915 |  |  | 34,373 |  |
| Total | $ | 84,446 |  |  | $ | 88,175 |  |


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001628280-18-009847:notes:119]
[same as prior period, unchanged from 0001628280-18-000993:notes:144]

[0001628280-18-009847:notes:120]
[same as prior period, unchanged from 0001628280-18-000993:notes:145]

[0001628280-18-009847:notes:121]
The $0.3 million charged to operations in the three months ended June 30, 2018 is related to exit costs incurred for the move of the Company's corporate office.

[0001628280-18-009847:notes:122]
On April 3, 2017, the Board of Directors approved a plan to reduce the Company’s global workforce by approximately 8%, effective April 4, 2017.  The purpose of the workforce reduction was to reduce operating expenses to better align with the Company’s current revenues. Included in the $1.3 million severance pay, charged to operations in the three months ended June 30, 2017, is $0.5 million of severance pay for one of the Company's former executive officers pursuant to the terms of a severance agreement dated June 30, 2017.  Under the terms of the severance agreement, the Company's former executive officer is entitled to 18 months of his base salary, which is expected to be paid by December 31, 2018. From and after January 1, 2018, the Company, at its discretion, may settle any remaining unpaid cash severance owed to its former executive officer through the issuance of a number of immediately vested shares of the Company’s common stock, determined by multiplying the remaining unpaid cash severance owed by 120%, and then dividing by the closing stock price per share of the Company's common stock as of the last business day prior to the issuance of the shares.

[0001628280-18-009847:notes:123]
[same as prior period, unchanged from 0001628280-18-000993:notes:147]

[0001628280-18-009847:notes:124]
The following table presents restructuring charges and cash payments for the three months ended June 30, 2018 and 2017(in thousands):

[0001628280-18-009847:notes:125]
|  | Severance pay |  | Facility exit and |  |  |
|  | and benefits |  | Relocation costs |  | Total |
| Accrued restructuring balance at April 1, 2018 | $ | 262 |  |  | $ | 173 |  |  | $ | 435 |  |
| Charges to operations | — |  |  | 310 |  |  | 310 |  |
| Cash payments | (97 | ) |  | (483 | ) |  | (580 | ) |
| Accrued restructuring balance at June 30, 2018 | $ | 165 |  |  | $ | — |  |  | $ | 165 |  |

[0001628280-18-009847:notes:126]
|  | Severance pay |  | Facility exit and |  |  |
|  | and benefits |  | Relocation costs |  | Total |
| Accrued restructuring balance at April 1, 2017 | $ | — |  |  | $ | — |  |  | $ | — |  |
| Charges to operations | 1,339 |  |  | — |  |  | 1,339 |  |
| Cash payments | (423 | ) |  | — |  |  | (423 | ) |
| Accrued restructuring balance at June 30, 2017 | $ | 916 |  |  | $ | — |  |  | $ | 916 |  |

[0001628280-18-009847:notes:127]
[same as prior period, unchanged from 0001628280-18-000993:notes:150]


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001628280-18-009847:notes:128]
Revenue Recognition

[0001628280-18-009847:notes:129]
On April 1, 2018, the Company adopted ASC 606, Revenue from Contracts with Customers, and all the related amendments and applied it to all contracts that were not completed as of April 1, 2018 using the modified retrospective method. The Company recognized the cumulative effect of initially applying the new revenue standard as an adjustment of less than $0.1 million to the opening balance of accumulated deficit. Prior period amounts have not been restated and continue to be reported under the accounting standards in effect for those periods.

[0001628280-18-009847:notes:130]
The adoption of this guidance will lead to recognizing certain revenue transactions sooner than in the past on certain contracts, as the Company will need to estimate the revenue it will be entitled to upon contract completion, and later on other contracts, such as Consulting and Statement of Work transactions, due to the lack of an enforceable right to payment for performance obligations satisfied over time, specifically in the technology product line.  The Company does not expect a material impact to its consolidated statements of operations on an ongoing basis from the adoption of the new standard.

[0001628280-18-009847:notes:131]
In addition, the FASB issued ASU 2017-05, Other Income - Gains and Losses from the Derecognition of Non-financial Assets (Subtopic 610-20), in February 2017, to amend ASC 610-20, Other Income - Gains and Losses from the Derecognition of Non-financial Assets, (issued at the same time as ASC 606), which provides a model for the measurement and recognition of gains and losses on the sale of nonfinancial assets, such as property and equipment, including real estate. As a result of adopting ASU 2017-05 on April 1, 2018, the Company recognized an adjustment to the opening balance of accumulated deficit for the deferred gain from the March 28, 2018, sale of the Company's former headquarters in Devens, Massachusetts in the amount of $0.1 million.

[0001628280-18-009847:notes:132]
The cumulative effect to the Company’s consolidated April 1, 2018 balance sheet from the adoption of the new revenue standard and the sale of nonfinancial assets was as follows (in thousands):

[0001628280-18-009847:notes:133]
|  | March 31, 2018 |  | Opening Adjustment |  | April 1, 2018 |
| Assets: |  |  |  |  |  |
| Inventory | $ | 19,780 |  |  | $ | (1,599 | ) |  | $ | 18,181 |  |
| Prepaid expenses and other current assets | 2,947 |  |  | 1,599 |  |  | 4,546 |  |
| Notes receivable, long term portion | 2,559 |  |  | 105 |  |  | 2,664 |  |
| Liabilities and Stockholders' Equity: |  |  |  |  |  |
| Accounts payable and accrued expenses | $ | (12,625 | ) |  | $ | (2,729 | ) |  | $ | (15,354 | ) |
| Deferred revenue | (13,483 | ) |  | 2,657 |  |  | (10,826 | ) |
| Accumulated deficit | $ | (988,333 | ) |  | $ | (33 | ) |  | $ | (988,366 | ) |

[0001628280-18-009847:notes:134]
Included in the opening adjustment are reclassifications for deferred program costs and deferred revenue for previous balances related to agreements that no longer meet the definition of a customer contract under ASC 606.  The impact of adoption on the Company’s opening balances and for the three months ended June 30, 2018, in all financial statement line items impacted by ASC 606 was immaterial from the amount that would have been reported under the previous guidance.

[0001628280-18-009847:notes:135]
The Company’s revenues in its Grid segment are derived primarily through transmitting and distributing power, providing planning services that allow it to identify power grid needs and risks, and developing ship protection systems for the US Navy. The Company’s revenues in its Wind segment are derived primarily through supplying advanced power electronics and control systems, licensing our highly engineered wind turbine designs, and providing extensive customer support services to wind turbine manufacturers.  The Company records revenue based on a five-step model in accordance with ASC 606. For its customer contracts, the Company identifies the performance obligations, determines the transaction price, allocates the contract transaction price to the performance obligations, and recognizes the revenue when (or as) control of goods or services is transferred to the customer.  As of June 30, 2018, 82% of revenue was recognized at the point in time when control transferred to the customer, with the remainder being recognized over time.

[0001628280-18-009847:notes:136]
In the Company's equipment and system product line each contract with a customer summarizes each product sold to a customer, which typically represent distinct performance obligations.  A contracts' transaction price is allocated to each distinct performance obligation using the respective standalone selling price which is determined primarily using the cost plus expected margin approach and recognized as revenue when, or as, the performance obligation is satisfied. The majority of the Company’s product sales transfer control to the customer in line with the contracted delivery terms and revenue is recorded at the point in time when products are transferred to the freight forwarder, as the Company has determined that this is the point in time that control transfers to the customer.

[0001628280-18-009847:notes:137]
In the Company's service and technology development product line, there are multiple different types of transactions but each of them begins with a contract with a customer that summarizes each product sold to a customer, which typically represents distinct performance obligations.  The technology development transactions are primarily for activities that have no alternative use and for which a profit can be expected throughout the life of the contract.  In these cases, the revenue is recognized over time, but in the instances where the profit cannot be assured throughout the entire contract then the revenue is recognized at a point in time.   Each contract's transaction price is allocated to each distinct performance obligation using the respective standalone selling price which is determined primarily using the cost plus expected margin approach.  The ongoing service transactions are for service contracts that provide benefit to the customer simultaneously as the Company performs its obligations, and therefore this revenue is recognized ratably over time throughout the effective period of these contracts.  The transaction prices on these contracts are allocated based on an adjusted market approach which is re-assessed annually for reasonableness.  The field service transactions include contracts for delivery of goods and completion of services made at the customer's requests, which are not deemed satisfied until the work has been completed and/or the requested goods have been delivered, so all of this revenue is recognized at the point in time when the control changes, and at allocated prices based on the adjusted market approach driven by standard price lists. The royalty transactions are related to certain contract terms on transactions in the Company's equipment and systems product line based on activity as specified in the contracts.  The transaction prices of these agreements are calculated based on an adjusted market approach as specified in the contract.  The Company reports royalty revenue for usage-based royalties when the sales have occurred.  In circumstances when collectability is not assured and a contract does not exist under ASC 606, revenue is deferred until a non-refundable payment has been received for substantially all the amount that is due and there are no further remaining performance obligations.

[0001628280-18-009847:notes:138]
The Company's service contracts can include a purchase order from a customer for specific goods in which each item is a distinct performance obligation satisfied at a point in time at which control of the goods is transferred to the customer which occurs based on the contracted delivery terms or when the requested service work has been completed.  The transaction price for these goods is allocated based on the adjusted market approach considering similar transactions under similar circumstances.  Service contracts are also derived from ongoing maintenance contracts and extended service-type warranty contracts.  In these transactions, the Company is contracted to provide an ongoing service over a specified period of time.  As the customer is consuming the benefits as the service is being provided the revenue is recognized over time ratably.

[0001628280-18-009847:notes:139]
The Company’s policy is to not accept volume discounts, product returns, or rebates and allowances within its contracts.  In the event a contract was approved with any of these terms, it would be evaluated for variable consideration, estimated and recorded as a reduction of revenue in the same period the related product revenue was recorded.

[0001628280-18-009847:notes:140]
The Company provides assurance-type warranties on all product sales for a term of typically one to two years, and extended service-type warranties at the customers’ option for an additional term ranging up to four additional years. The Company accrues for the estimated warranty costs for assurance warranties at the time of sale based on historical warranty experience plus any known or expected changes in warranty exposure.  For all extended service-type warranties, the Company recognizes the revenue ratably over time during the effective period of the services.

[0001628280-18-009847:notes:141]
The Company records revenue net of sales tax, value added tax, excise tax and other taxes collected concurrent with revenue-producing activities. The Company has elected to recognize the cost for freight and shipping when control over the products sold passes to customers and revenue is recognized.  The Company has elected to recognize incremental costs of obtaining a contract as expense when incurred except in contracts where the amortization period would exceed twelve months; in such cases the long term amount will be assessed for materiality.  The Company has elected to not adjust the promised amount of consideration for the effects of a significant financing component if the period of financing is twelve months or less.

[0001628280-18-009847:notes:142]
The Company’s contracts with customers do not typically include extended payment terms and may include milestone billing over the life of the contract.  Payment terms vary by contract type and type of customer and generally range from 30 to 60 days from delivery.

[0001628280-18-009847:notes:143]
As of June 30, 2018 and March 31, 2018, the Company’s contract assets and liabilities primarily relate to the timing differences between cash received from a customer in connection with contractual rights to invoicing and the timing of revenue recognition following completion of performance obligations. The Company's accounts receivable balance is made up entirely of customer contract related balances.  Changes in the Company’s contract assets, which are included in “Unbilled AR” and "Deferred program costs" (see Note 7, “Accounts Receivable” and Note 8, "Inventory" for a reconciliation to the condensed consolidated balance sheet) and contract liabilities, which are included in the current portion and long term portion of “deferred revenue” in the Company’s condensed consolidated balance sheets, are as follows:

[0001628280-18-009847:notes:144]
The Company’s remaining performance obligations represent the unrecognized revenue value of the Company’s contractual commitments. The Company’s performance obligations may vary significantly each reporting period based on the timing of major new contractual commitments. As of June 30, 2018, the Company had outstanding performance obligations on existing contracts under ASC 606 to be recognized in the next twelve months of approximately $50.6 million.  There is also approximately $8.1 million of outstanding performance obligations to be recognized over a period of thirteen to sixty months.  The remaining performance obligations are subject to customer actions and therefore the timing of revenue recognition cannot be reasonably estimated.  The twelve month performance obligations include anticipated shipments to Inox based on the twelve month rolling forecast provided by Inox on the multi-year supply contract. The quantities specified in any forecast provided by Inox related to the multi-year supply contract are firm and irrevocable for the first three months of a twelve month rolling forecast. The timing of the performance obligations beyond the Inox twelve month provided forecast are not determinable and therefore are not included in the total remaining performance obligations.

[0001628280-18-009847:notes:145]
The following table sets forth customers who represented 10% or more of the Company’s total revenues for the three months ended June 30, 2018 and 2017:

[0001628280-18-009847:notes:146]
|  | Reportable Segment |  | June 30, 2018 |  | June 30, 2017 |
| Inox Wind Limited | Wind |  | 25 | % |  | 22 | % |
| Vestas | Grid |  | 36 | % |  | — | % |
| U.S. Navy | Grid |  | <10% |  |  | 35 | % |


## us-gaap:ScheduleOfSegmentReportingInformationBySegmentTextBlock

[0001628280-18-009847:notes:147]
[same as prior period, unchanged from 0001628280-18-000993:notes:153]

[0001628280-18-009847:notes:148]
|  | Three months ended June 30, |
|  | 2018 |  | 2017 |
| Revenues: |  |  |  |
| Wind | $ | 3,678 |  |  | $ | 2,278 |  |
| Grid | 8,929 |  |  | 6,645 |  |
| Total | $ | 12,607 |  |  | $ | 8,923 |  |

[0001628280-18-009847:notes:149]
|  | Three months ended June 30, |
|  | 2018 |  | 2017 |
| Operating loss: |  |  |  |
| Wind | $ | (1,367 | ) |  | $ | (4,433 | ) |
| Grid | (2,666 | ) |  | (8,167 | ) |
| Unallocated corporate expenses | (1,095 | ) |  | (2,093 | ) |
| Total | $ | (5,128 | ) |  | $ | (14,693 | ) |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001628280-18-009847:notes:150]
[same as prior period, unchanged from 0001628280-18-000993:notes:156]

[0001628280-18-009847:notes:151]
[same as prior period, unchanged from 0001628280-18-000993:notes:157]

[0001628280-18-009847:notes:152]
[same as prior period, unchanged from 0001628280-18-000993:notes:158]

[0001628280-18-009847:notes:153]
[same as prior period, unchanged from 0001628280-18-000993:notes:159]

[0001628280-18-009847:notes:154]
[same as prior period, unchanged from 0001628280-18-000993:notes:160]

[0001628280-18-009847:notes:155]
Unallocated corporate expenses primarily consist of stock-based compensation expense of $0.8 million and $0.8 million in the three months ended June 30, 2018 and 2017, respectively.  Additionally, restructuring charges of $0.3 million and $1.3 million are included in the three months ended June 30, 2018 and 2017, respectively.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001628280-18-009847:notes:156]
[same as prior period, unchanged from 0001628280-18-000993:notes:162]

[0001628280-18-009847:notes:157]
[same as prior period, unchanged from 0001628280-18-000993:notes:163]

[0001628280-18-009847:notes:158]
On May 5, 2017, the Company entered into an underwriting agreement with Oppenheimer & Co. Inc., as representative of several underwriters named therein, relating to the issuance and sale (the "Offering") of 4.0 million shares of the Company's common stock at a public offering price of $4.00 per share. The net proceeds to the Company from the Offering were approximately $14.7 million, after deducting underwriting discounts and commissions and offering expenses payable by the Company. The Offering closed on May 10, 2017. In addition, the Company granted the underwriters a 30-day option (the “Option”) to purchase up to an additional 600,000 shares of common stock at the public offering price.  On May 24, 2017, the underwriters notified the Company that they had exercised their Option in full.  The net proceeds to the Company from the Option were approximately $2.3 million, after deducting underwriting discounts and commissions and offering expenses payable by the Company.  The total net proceeds to the Company from the Offering and the Option were approximately $17.0 million, after deducting underwriting discounts and commissions and offering expenses payable by the Company. The Option closed on May 26, 2017. In conjunction with the equity offering, the Company terminated a previous At Market Issuance Sales Agreement ("ATM) with FBR Capital Markets & Co. where the Company could, at its discretion, sell up to $10.0 million of the Company's common stock.


## us-gaap:SubsequentEventsTextBlock

[0001628280-18-009847:notes:159]
Subsequent Events

[0001628280-18-009847:notes:160]
The Company has performed an evaluation of subsequent events through the time of filing this Quarterly Report on Form 10-Q with the SEC, apart from the Settlement Agreement with Sinovel described in Note 15, "Commitments and Contingencies," the Company has determined that there are no such events to report.
