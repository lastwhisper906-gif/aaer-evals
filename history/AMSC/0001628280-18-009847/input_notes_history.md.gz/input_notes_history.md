# AMSC note change history — 0001628280-18-000993 → 0001628280-18-009847


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- added (2018-07-31):
[0001628280-18-009847:note_history:1]
On July 3, 2018, the Company, AMSC China and AMSC Austria entered into the Settlement Agreement with Sinovel. The Settlement Agreement settles the litigation and arbitration proceedings between the Company and Sinovel listed on Schedule 2 of the Settlement Agreement (the “Proceedings”), and any other civil claims, counterclaims, causes of action, rights and obligations directly or indirectly relating to the subject matters of the Proceedings and the contracts between the Company and Sinovel listed on Schedules 1 and 4 of the Settlement Agreement (the “Contracts”), subject to the exception described in Section 1.1 of the Settlement Agreement.  The Settlement Agreement was filed as Exhibit 10.1 to the Company’s Form 8-K filed with the Securities and Exchange Commission on July 9, 2018.

- added (2018-07-31):
[0001628280-18-009847:note_history:2]
Under the terms of the Settlement Agreement, Sinovel has agreed to pay AMSC China an aggregate cash amount in Renminbi (RMB) equivalent to $57.5 million, consisting of two installments. Sinovel paid the first installment of $32.5 million on July 4, 2018, and has agreed to pay the second installment of $25.0 million (the “Second Payment”) within ten (10) months after the U.S. District Court for the Western District of Wisconsin (the “District Court”) delivers the first sentence against Sinovel in the criminal case entitled United States v. Sinovel Wind Co., Ltd., Case Number 3:13-cr-00084-jdp. On July 6, 2018, the District Court delivered such sentence, and therefore the Second Payment is due by May 6, 2019 (the “Second Payment Due Date”). Mr. Wenyuan Wei, former Sinovel chairman and a current Sinovel shareholder, has delivered a letter of guarantee (the “Guarantee”) to the Company for the Second Payment should Sinovel fail to make such payment by the Second Payment Due Date.

- added (2018-07-31):
[0001628280-18-009847:note_history:3]
In addition, pursuant to the terms of the Settlement Agreement, the Company and AMSC Austria have granted Sinovel a non-exclusive license for certain AMSC intellectual property to be used solely in Sinovel’s doubly fed wind turbines (the “License”). AMSC has agreed not to sue Sinovel, Sinovel’s power converter suppliers or Sinovel’s customers for use of the technology covered by the License. In the event that Sinovel or Mr. Wei does not make the Second Payment by the Second Payment Due Date, the Settlement Agreement provides that the License will terminate.

- added (2018-07-31):
[0001628280-18-009847:note_history:4]
The Company and Sinovel have submitted withdrawal applications to terminate the Proceedings to the relevant Chinese courts and the Beijing Arbitration Commission. Subject to the Company and Sinovel complying with the terms of the Settlement Agreement, the Company and Sinovel have agreed not to re-institute any of the Proceedings. In addition, the Company and Sinovel have agreed to a mutual release and covenant not to sue covering all subject matters of the Proceedings and Contracts, effective upon the completion of the Second Payment.

- changed (2018-07-31):
[0001628280-18-009847:note_history:5]
As of June 30, 2018, the Company had $0.2 million of restricted cash included in long-term assets. These amounts included in restricted cash primarily represent deposits to secure letters of credit for various supply contracts. These deposits are held in interest bearing accounts.
  (was, 2018-02-05, similarity 0.9782):
[0001628280-18-000993:note_history:5]
As of December 31, 2017, the Company had $0.2 million of restricted cash included in long-term assets. These amounts included in restricted cash primarily represent deposits to secure letters of credit for various supply contracts. These deposits are held in interest bearing accounts.

- removed (2018-07-31):
[0001628280-18-000993:note_history:6]
On September 13, 2011, the Company commenced a series of legal actions in China against Sinovel Wind Group Co. Ltd. (“Sinovel”). The Company’s Chinese subsidiary, Suzhou AMSC Superconductor Co. Ltd., filed a claim for arbitration with the Beijing Arbitration Commission in accordance with the terms of the Company’s supply contracts with Sinovel. The case is captioned (2011) Jing Zhong An Zi No. 963.  The Company alleges that Sinovel committed various material breaches of its contracts with the Company and Sinovel has refused to pay past due amounts for prior shipments of core electrical components and spare parts. The Company is seeking compensation for past product shipments and retention (including interest) in the amount of approximately RMB 485 million (approximately $75 million) due to Sinovel’s breaches of its contracts. The Company is also seeking specific performance of its existing contracts as well as reimbursement of all costs and reasonable expenses with respect to the arbitration. The value of the undelivered components under the existing contracts, including the deliveries refused by Sinovel in March 2011, amounts to approximately RMB 4.6 billion (approximately $707 million).

- removed (2018-07-31):
[0001628280-18-000993:note_history:7]
On October 8, 2011, Sinovel filed with the Beijing Arbitration Commission an application under the caption (2011) Jing Zhong An Zi No. 963, for a counterclaim against the Company for breach of the same contracts under which the Company filed its original arbitration claim. Sinovel claims, among other things, that the goods supplied by the Company do not conform to the standards specified in the contracts and claims damages in the amount of approximately RMB 1.2 billion (approximately $184 million) upon Sinovel’s requests for change of counterclaim. On February 27, 2012, Sinovel filed with the Beijing Arbitration Commission an application under the caption (2012) Jing Zhong An Zi No. 157, against the Company for breach of the same contracts under which the Company filed its original arbitration claim. Sinovel claims, among other things, that the goods supplied by the Company do not conform to the standards specified in the contracts and claims damages in the amount of approximately RMB 105 million (approximately $16 million). The Company believes that Sinovel’s claims are without merit and it intends to defend these actions vigorously. Since the proceedings in this matter are still in the early technical review phase, the Company cannot reasonably estimate possible losses or range of losses at this time.

- removed (2018-07-31):
[0001628280-18-000993:note_history:8]
During the nine months ended December 31, 2017, the Company received $1.0 million related to the achievement of certain milestones following the previous sale of the Company's minority interest in Blade Dynamics Limited.

- removed (2018-07-31):
[0001628280-18-000993:note_history:9]
On September 25, 2017, the Company acquired ITC for a purchase price of approximately $3.8 million, consisting of $0.1 million in cash and the AMSC Shares. The Company paid certain selling stockholders the Make Whole Payment given that the value of the AMSC Shares sold was less than the agreed upon purchase price.  The amount of this payment, which was made on January 5, 2018, was $0.7 million and settled the related contingent liability. See Note 4, “Acquisitions and Related Goodwill” for further discussion.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2018-07-31):
[0001628280-18-009847:note_history:10]
These unaudited condensed consolidated financial statements of the Company have been prepared on a going concern basis in accordance with United States generally accepted accounting principles (“GAAP”) and the Securities and Exchange Commission’s (“SEC”) instructions to Form 10-Q. The going concern basis of presentation assumes that the Company will continue operations and will be able to realize its assets and discharge its liabilities and commitments in the normal course of business. Certain information and footnote disclosures normally included in the financial statements prepared in accordance with GAAP have been condensed or omitted pursuant to those instructions. The year-end condensed balance sheet data was derived from audited financial statements but does not include all disclosures required by GAAP. The unaudited condensed consolidated financial statements, in the opinion of management, reflect all adjustments (consisting of normal recurring adjustments) necessary for a fair statement of the results for the interim periods ended June 30, 2018 and 2017 and the financial position at June 30, 2018; however, these results are not necessarily indicative of results which may be expected for the full year. The interim condensed consolidated financial statements, and notes thereto, should be read in conjunction with the audited consolidated financial statements for the year ended March 31, 2018, and notes thereto, included in the Company’s annual report on Form 10-K for the year ended March 31, 2018 filed with the Securities and Exchange Commission on June 6, 2018.
  (was, 2018-02-05, similarity 0.9901):
[0001628280-18-000993:note_history:10]
These unaudited condensed consolidated financial statements of the Company have been prepared on a going concern basis in accordance with United States generally accepted accounting principles (“GAAP”) and the Securities and Exchange Commission’s (“SEC”) instructions to Form 10-Q. The going concern basis of presentation assumes that the Company will continue operations and will be able to realize its assets and discharge its liabilities and commitments in the normal course of business. Certain information and footnote disclosures normally included in the financial statements prepared in accordance with GAAP have been condensed or omitted pursuant to those instructions. The year-end condensed balance sheet data was derived from audited financial statements but does not include all disclosures required by GAAP. The unaudited condensed consolidated financial statements, in the opinion of management, reflect all adjustments (consisting of normal recurring adjustments) necessary for a fair statement of the results for the interim periods ended December 31, 2017 and 2016 and the financial position at December 31, 2017; however, these results are not necessarily indicative of results which may be expected for the full year. The interim condensed consolidated financial statements, and notes thereto, should be read in conjunction with the audited consolidated financial statements for the year ended March 31, 2017, and notes thereto, included in the Company’s annual report on Form 10-K for the year ended March 31, 2017 filed with the Securities and Exchange Commission on May 25, 2017.

- changed (2018-07-31):
[0001628280-18-009847:note_history:11]
The Company has experienced recurring operating losses and as of June 30, 2018, the Company had an accumulated deficit of $993.0 million. In addition, the Company has experienced recurring negative operating cash flows.  At June 30, 2018, the Company had cash and cash equivalents of $26.8 million, with no outstanding debt other than ordinary trade payables. Cash used in operations for the three months ended June 30, 2018 was $6.9 million.
  (was, 2018-02-05, similarity 0.9132):
[0001628280-18-000993:note_history:11]
The Company has experienced recurring operating losses and as of December 31, 2017, the Company had an accumulated deficit of $982.3 million. In addition, the Company has experienced recurring negative operating cash flows.  At December 31, 2017, the Company had cash and cash equivalents of $22.1 million, with no outstanding debt other than ordinary trade payables. Cash used in operations for the nine months ended December 31, 2017 was $20.2 million.

- changed (2018-07-31):
[0001628280-18-009847:note_history:12]
From April 1, 2011 through the date of this filing, the Company has reduced its global workforce substantially.  As of June 30, 2018, the Company had a global workforce of 231 persons.  The Company plans to closely monitor its expenses and, if required, expects to further reduce operating costs and capital spending to enhance liquidity.
  (was, 2018-02-05, similarity 0.6013):
[0001628280-18-000993:note_history:12]
From April 1, 2011 through the date of this filing, the Company has reduced its global workforce substantially, including a restructuring action announced on April 4, 2017 which led to a $1.3 million restructuring charge in the nine months ended December 31, 2017.  See Note 15 "Restructuring" for further discussion of this action.  The Company has taken actions to consolidate certain business operations to reduce facility costs.  As of December 31, 2017, the Company had a global workforce of 275 persons.  The Company plans to closely monitor its expenses and, if required, expects to further reduce operating costs and capital spending to enhance liquidity.

- changed (2018-07-31):
[0001628280-18-009847:note_history:13]
Over the last several years, the Company has entered into several debt and equity financing arrangements in order to raise capital.  Since April 1, 2012, the Company has generated aggregate cash flows from financing activities of $85.0 million.  Included in this amount are proceeds of approximately $17.0 million after deducting underwriting discounts and commissions and offering expenses payable by the Company, from the Company's equity offering completed on May 10, 2017, which includes the subsequent exercise by the underwriters of their option in full to purchase additional shares.  The Company terminated its At Market Issuance Sales Agreement ("ATM") with FBR Capital Markets & Co. in conjunction with this equity offering.  See Note 14 “Stockholders' Equity” for further discussion of these financing arrangements.
  (was, 2018-02-05, similarity 0.9693):
[0001628280-18-000993:note_history:13]
Over the last several years, the Company has entered into equity financing arrangements in order to enhance liquidity.  Since April 1, 2012, the Company has generated aggregate cash flows from financing activities of $85.1 million.  Included in this amount are proceeds of approximately $17.0 million after deducting underwriting discounts and commissions and offering expenses payable by the Company, from the Company's equity offering completed on May 10, 2017, which includes the subsequent exercise by the underwriters of their option in full to purchase additional shares.  The Company terminated its At Market Issuance Sales Agreement ("ATM") with FBR Capital Markets & Co. in conjunction with this equity offering.  See Note 13 “Stockholder's Equity” for further discussion of these financing arrangements.

- added (2018-07-31):
[0001628280-18-009847:note_history:14]
On July 3, 2018, the Company and its wholly-owned subsidiaries Suzhou AMSC Superconductor Co. Ltd. (“AMSC China”) and AMSC Austria GMBH (“AMSC Austria”) entered into a settlement agreement (the “Settlement Agreement”) with Sinovel Wind Group Co., Ltd. (“Sinovel”). The Settlement Agreement settles the litigation and arbitration proceedings between the Company and Sinovel, as further described in Note 15 “Commitments and Contingencies".  Under the terms of the Settlement Agreement, Sinovel has agreed to pay AMSC China an aggregate cash amount in Renminbi (RMB) equivalent to $57.5 million, consisting of two installments. Sinovel paid the first installment of $32.5 million on July 4, 2018, and has agreed to pay the second installment of $25.0 million (the “Second Payment”) within ten (10) months after the U.S. District Court for the Western District of Wisconsin (the “District Court”) delivers the first sentence against Sinovel in the criminal case entitled United States v. Sinovel Wind Co., Ltd., Case Number 3:13-cr-00084-jdp. On July 6, 2018, the District Court delivered such sentence, and therefore the Second Payment is due by May 6, 2019 (the “Second Payment Due Date”). On July 24, 2018, AMSC China paid $30.7 million to AMSC Austria to settle outstanding inter-company balances.

- added (2018-07-31):
[0001628280-18-009847:note_history:15]
On February 5, 2018, the Company entered into a Purchase and Sale Agreement (the “PSA”) with 64 Jackson, LLC (the “Purchaser”) and Stewart Title Guaranty Company (“Escrow Agent”), to effectuate the sale of certain real property located at 64 Jackson Road, Devens, Massachusetts, including the building that had served as the Company’s headquarters (collectively, the “Property”), in exchange for total consideration of $23.0 million, composed of (i) cash consideration of $17.0 million, and (ii) a $6.0 million subordinated secured commercial promissory note payable to the Company (the "Seller Note"). Subsequently, the Seller, the Purchaser and Jackson 64 MGI, LLC (“Assignee”) entered into an Assignment of Purchase and Sale Agreement (the “Assignment Agreement”), pursuant to which the Purchaser assigned all of its rights and interests in the PSA to the Assignee and the Assignee agreed to assume all of the Purchaser’s obligations and liabilities under the PSA. The transaction closed on March 28, 2018, at which time the Company received, from the Assignee, cash consideration, net of certain agreed upon closing costs, of $16.9 million, and the Seller Note at an interest rate of 1.96%. The Seller Note is secured by a subordinated second mortgage on the Property and a subordinated second assignment of leases and rents.

- added (2018-07-31):
[0001628280-18-009847:note_history:16]
The Company believes that based on the information presented above and its quarterly management assessment, it has sufficient liquidity to fund its operations and capital expenditures for the next twelve months following the issuance of the financial statements for the three months ended June 30, 2018. The Company’s liquidity is highly dependent on its ability to increase revenues, including its ability to collect revenues under our agreements with Inox, its ability to control its operating costs, and its ability to raise additional capital, if necessary. There can be no assurance that the Company will be able to continue to raise additional capital, on favorable terms or at all, from other sources or execute on any other means of improving liquidity described above.

- removed (2018-07-31):
[0001628280-18-000993:note_history:17]
The Company believes that based on the information presented above and its quarterly management assessment, it has sufficient liquidity to fund its operations and capital expenditures for the next twelve months following the issuance of the financial statements for the nine months ended December 31, 2017. The Company’s liquidity is highly dependent on its ability to increase revenues, its ability to control its operating costs, and its ability to raise additional capital, if necessary. There can be no assurance that the Company will be able to continue to raise additional capital from other sources or execute on any other means of improving liquidity described above.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: no_current_note, score: 0.0

- removed (2018-07-31):
[0001628280-18-000993:note_history:18]
Debt

- removed (2018-07-31):
[0001628280-18-000993:note_history:19]
Senior Secured Term Loans

- removed (2018-07-31):
[0001628280-18-000993:note_history:20]
On December 19, 2014, the Company entered into a second amendment to its Loan and Security Agreement with Hercules (the “Hercules Second Amendment”) and entered into a new term loan, borrowing an additional $1.5 million (the “Term Loan C”).  After closing fees and expenses, the net proceeds to the Company for the Term Loan C were $1.4 million. The Company made interest only payments at an interest rate of 11% through March 16, 2017 when the interest rate was increased to 11.25%, until maturity on June 1, 2017, when Term Loan C was repaid in its entirety.

- removed (2018-07-31):
[0001628280-18-000993:note_history:21]
Hercules received warrants to purchase 13,927 shares of common stock (the “First Warrant”) and 25,641 shares of common stock (the “Second Warrant”) in conjunction with prior term loans that have been repaid in full.  Due to certain adjustment provisions within the warrants, they qualified for liability accounting.  The fair value of the warrants, $0.4 million and $0.2 million, respectively, was recorded upon issuance to debt discount and a warrant liability. In conjunction with the Hercules Second Amendment, the First Warrant and Second Warrant were canceled and replaced with the issuance of a new warrant (the “Hercules Warrant”) to purchase 58,823 shares of common stock at an exercise price of $7.85 per share, subject to certain price-based and other anti-dilution adjustments.  The Hercules Warrant expires on June 30, 2020.  See Note 12, “Warrants and Derivative Liabilities”, for a discussion on the Hercules Warrant and the valuation assumptions used.

- removed (2018-07-31):
[0001628280-18-000993:note_history:22]
The Company recorded no interest expense for the three months ended December 31, 2017 and less than $0.1 million for the three months ended December 31, 2016.  Included in the prior year period was less than $0.1 million of non-cash interest expense related to the amortization of the debt discount on the respective term loans.  Interest expense on the Term Loans for the nine months ended December 31, 2017 and 2016, was less than $0.1 million and $0.3 million, respectively.  Included in the nine months ended December 31, 2017 and 2016 were less than $0.1 million and $0.1 million, respectively, of non-cash interest expense related to the amortization of debt discount on the respective Term Loans.


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: no_prior_note, score: 0.0

- added (2018-07-31):
[0001628280-18-009847:note_history:23]
The following tables disaggregate the Company’s revenue by product line and by shipment destination:

- added (2018-07-31):
[0001628280-18-009847:note_history:24]
|  | Three months endedJune 30, 2018 |
| Product Line: | Grid |  | Wind |
| Equipment and systems | $ | 7,462 |  |  | $ | 3,492 |  |
| Services and technology development | 1,467 |  |  | 186 |  |
| Total | $ | 8,929 |  |  | $ | 3,678 |  |
| Region: |  |  |  |
| Americas | $ | 7,496 |  |  | $ | 23 |  |
| Asia Pacific | 808 |  |  | 3,595 |  |
| EMEA | 625 |  |  | 60 |  |
| Total | $ | 8,929 |  |  | $ | 3,678 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: no_prior_note, score: 0.0

- added (2018-07-31):
[0001628280-18-009847:note_history:25]
Revenue Recognition

- added (2018-07-31):
[0001628280-18-009847:note_history:26]
On April 1, 2018, the Company adopted ASC 606, Revenue from Contracts with Customers, and all the related amendments and applied it to all contracts that were not completed as of April 1, 2018 using the modified retrospective method. The Company recognized the cumulative effect of initially applying the new revenue standard as an adjustment of less than $0.1 million to the opening balance of accumulated deficit. Prior period amounts have not been restated and continue to be reported under the accounting standards in effect for those periods.

- added (2018-07-31):
[0001628280-18-009847:note_history:27]
The adoption of this guidance will lead to recognizing certain revenue transactions sooner than in the past on certain contracts, as the Company will need to estimate the revenue it will be entitled to upon contract completion, and later on other contracts, such as Consulting and Statement of Work transactions, due to the lack of an enforceable right to payment for performance obligations satisfied over time, specifically in the technology product line.  The Company does not expect a material impact to its consolidated statements of operations on an ongoing basis from the adoption of the new standard.

- added (2018-07-31):
[0001628280-18-009847:note_history:28]
In addition, the FASB issued ASU 2017-05, Other Income - Gains and Losses from the Derecognition of Non-financial Assets (Subtopic 610-20), in February 2017, to amend ASC 610-20, Other Income - Gains and Losses from the Derecognition of Non-financial Assets, (issued at the same time as ASC 606), which provides a model for the measurement and recognition of gains and losses on the sale of nonfinancial assets, such as property and equipment, including real estate. As a result of adopting ASU 2017-05 on April 1, 2018, the Company recognized an adjustment to the opening balance of accumulated deficit for the deferred gain from the March 28, 2018, sale of the Company's former headquarters in Devens, Massachusetts in the amount of $0.1 million.

- added (2018-07-31):
[0001628280-18-009847:note_history:29]
The cumulative effect to the Company’s consolidated April 1, 2018 balance sheet from the adoption of the new revenue standard and the sale of nonfinancial assets was as follows (in thousands):

- added (2018-07-31):
[0001628280-18-009847:note_history:30]
|  | March 31, 2018 |  | Opening Adjustment |  | April 1, 2018 |
| Assets: |  |  |  |  |  |
| Inventory | $ | 19,780 |  |  | $ | (1,599 | ) |  | $ | 18,181 |  |
| Prepaid expenses and other current assets | 2,947 |  |  | 1,599 |  |  | 4,546 |  |
| Notes receivable, long term portion | 2,559 |  |  | 105 |  |  | 2,664 |  |
| Liabilities and Stockholders' Equity: |  |  |  |  |  |
| Accounts payable and accrued expenses | $ | (12,625 | ) |  | $ | (2,729 | ) |  | $ | (15,354 | ) |
| Deferred revenue | (13,483 | ) |  | 2,657 |  |  | (10,826 | ) |
| Accumulated deficit | $ | (988,333 | ) |  | $ | (33 | ) |  | $ | (988,366 | ) |

- added (2018-07-31):
[0001628280-18-009847:note_history:31]
Included in the opening adjustment are reclassifications for deferred program costs and deferred revenue for previous balances related to agreements that no longer meet the definition of a customer contract under ASC 606.  The impact of adoption on the Company’s opening balances and for the three months ended June 30, 2018, in all financial statement line items impacted by ASC 606 was immaterial from the amount that would have been reported under the previous guidance.

- added (2018-07-31):
[0001628280-18-009847:note_history:32]
The Company’s revenues in its Grid segment are derived primarily through transmitting and distributing power, providing planning services that allow it to identify power grid needs and risks, and developing ship protection systems for the US Navy. The Company’s revenues in its Wind segment are derived primarily through supplying advanced power electronics and control systems, licensing our highly engineered wind turbine designs, and providing extensive customer support services to wind turbine manufacturers.  The Company records revenue based on a five-step model in accordance with ASC 606. For its customer contracts, the Company identifies the performance obligations, determines the transaction price, allocates the contract transaction price to the performance obligations, and recognizes the revenue when (or as) control of goods or services is transferred to the customer.  As of June 30, 2018, 82% of revenue was recognized at the point in time when control transferred to the customer, with the remainder being recognized over time.

- added (2018-07-31):
[0001628280-18-009847:note_history:33]
In the Company's equipment and system product line each contract with a customer summarizes each product sold to a customer, which typically represent distinct performance obligations.  A contracts' transaction price is allocated to each distinct performance obligation using the respective standalone selling price which is determined primarily using the cost plus expected margin approach and recognized as revenue when, or as, the performance obligation is satisfied. The majority of the Company’s product sales transfer control to the customer in line with the contracted delivery terms and revenue is recorded at the point in time when products are transferred to the freight forwarder, as the Company has determined that this is the point in time that control transfers to the customer.

- added (2018-07-31):
[0001628280-18-009847:note_history:34]
In the Company's service and technology development product line, there are multiple different types of transactions but each of them begins with a contract with a customer that summarizes each product sold to a customer, which typically represents distinct performance obligations.  The technology development transactions are primarily for activities that have no alternative use and for which a profit can be expected throughout the life of the contract.  In these cases, the revenue is recognized over time, but in the instances where the profit cannot be assured throughout the entire contract then the revenue is recognized at a point in time.   Each contract's transaction price is allocated to each distinct performance obligation using the respective standalone selling price which is determined primarily using the cost plus expected margin approach.  The ongoing service transactions are for service contracts that provide benefit to the customer simultaneously as the Company performs its obligations, and therefore this revenue is recognized ratably over time throughout the effective period of these contracts.  The transaction prices on these contracts are allocated based on an adjusted market approach which is re-assessed annually for reasonableness.  The field service transactions include contracts for delivery of goods and completion of services made at the customer's requests, which are not deemed satisfied until the work has been completed and/or the requested goods have been delivered, so all of this revenue is recognized at the point in time when the control changes, and at allocated prices based on the adjusted market approach driven by standard price lists. The royalty transactions are related to certain contract terms on transactions in the Company's equipment and systems product line based on activity as specified in the contracts.  The transaction prices of these agreements are calculated based on an adjusted market approach as specified in the contract.  The Company reports royalty revenue for usage-based royalties when the sales have occurred.  In circumstances when collectability is not assured and a contract does not exist under ASC 606, revenue is deferred until a non-refundable payment has been received for substantially all the amount that is due and there are no further remaining performance obligations.

- added (2018-07-31):
[0001628280-18-009847:note_history:35]
The Company's service contracts can include a purchase order from a customer for specific goods in which each item is a distinct performance obligation satisfied at a point in time at which control of the goods is transferred to the customer which occurs based on the contracted delivery terms or when the requested service work has been completed.  The transaction price for these goods is allocated based on the adjusted market approach considering similar transactions under similar circumstances.  Service contracts are also derived from ongoing maintenance contracts and extended service-type warranty contracts.  In these transactions, the Company is contracted to provide an ongoing service over a specified period of time.  As the customer is consuming the benefits as the service is being provided the revenue is recognized over time ratably.

- added (2018-07-31):
[0001628280-18-009847:note_history:36]
The Company’s policy is to not accept volume discounts, product returns, or rebates and allowances within its contracts.  In the event a contract was approved with any of these terms, it would be evaluated for variable consideration, estimated and recorded as a reduction of revenue in the same period the related product revenue was recorded.

- added (2018-07-31):
[0001628280-18-009847:note_history:37]
The Company provides assurance-type warranties on all product sales for a term of typically one to two years, and extended service-type warranties at the customers’ option for an additional term ranging up to four additional years. The Company accrues for the estimated warranty costs for assurance warranties at the time of sale based on historical warranty experience plus any known or expected changes in warranty exposure.  For all extended service-type warranties, the Company recognizes the revenue ratably over time during the effective period of the services.

- added (2018-07-31):
[0001628280-18-009847:note_history:38]
The Company records revenue net of sales tax, value added tax, excise tax and other taxes collected concurrent with revenue-producing activities. The Company has elected to recognize the cost for freight and shipping when control over the products sold passes to customers and revenue is recognized.  The Company has elected to recognize incremental costs of obtaining a contract as expense when incurred except in contracts where the amortization period would exceed twelve months; in such cases the long term amount will be assessed for materiality.  The Company has elected to not adjust the promised amount of consideration for the effects of a significant financing component if the period of financing is twelve months or less.

- added (2018-07-31):
[0001628280-18-009847:note_history:39]
The Company’s contracts with customers do not typically include extended payment terms and may include milestone billing over the life of the contract.  Payment terms vary by contract type and type of customer and generally range from 30 to 60 days from delivery.

- added (2018-07-31):
[0001628280-18-009847:note_history:40]
The following tables disaggregate the Company’s revenue by product line and by shipment destination:

- added (2018-07-31):
[0001628280-18-009847:note_history:41]
|  | Three months endedJune 30, 2018 |
| Product Line: | Grid |  | Wind |
| Equipment and systems | $ | 7,462 |  |  | $ | 3,492 |  |
| Services and technology development | 1,467 |  |  | 186 |  |
| Total | $ | 8,929 |  |  | $ | 3,678 |  |
| Region: |  |  |  |
| Americas | $ | 7,496 |  |  | $ | 23 |  |
| Asia Pacific | 808 |  |  | 3,595 |  |
| EMEA | 625 |  |  | 60 |  |
| Total | $ | 8,929 |  |  | $ | 3,678 |  |

- added (2018-07-31):
[0001628280-18-009847:note_history:42]
As of June 30, 2018 and March 31, 2018, the Company’s contract assets and liabilities primarily relate to the timing differences between cash received from a customer in connection with contractual rights to invoicing and the timing of revenue recognition following completion of performance obligations. The Company's accounts receivable balance is made up entirely of customer contract related balances.  Changes in the Company’s contract assets, which are included in “Unbilled AR” and "Deferred program costs" (see Note 7, “Accounts Receivable” and Note 8, "Inventory" for a reconciliation to the condensed consolidated balance sheet) and contract liabilities, which are included in the current portion and long term portion of “deferred revenue” in the Company’s condensed consolidated balance sheets, are as follows:

- added (2018-07-31):
[0001628280-18-009847:note_history:43]
|  | Unbilled AR |  | Deferred Program Costs |  | Contract Liabilities |
| Beginning balance as of March 31, 2018 | $ | 3,016 |  |  | $ | 2,567 |  |  | $ | 21,937 |  |
| Impact of adoption of ASC 606 | — |  |  | (1,599 | ) |  | (2,657 | ) |
| Increases for costs incurred to fulfill performance obligations | — |  |  | 1,132 |  |  | — |  |
| Increase (decrease) due to customer billings | (3,221 | ) |  | — |  |  | 4,281 |  |
| Decrease due to cost recognition on completed performance obligations | — |  |  | (48 | ) |  | — |  |
| Increase (decrease) due to recognition of revenue based on transfer of control of performance obligations | 4,824 |  |  | (9 | ) |  | (3,324 | ) |
| Other changes and FX impact | (16 | ) |  | 34 |  |  | (764 | ) |
| Ending balance as of June 30, 2018 | $ | 4,603 |  |  | $ | 2,077 |  |  | $ | 19,473 |  |

- added (2018-07-31):
[0001628280-18-009847:note_history:44]
The Company’s remaining performance obligations represent the unrecognized revenue value of the Company’s contractual commitments. The Company’s performance obligations may vary significantly each reporting period based on the timing of major new contractual commitments. As of June 30, 2018, the Company had outstanding performance obligations on existing contracts under ASC 606 to be recognized in the next twelve months of approximately $50.6 million.  There is also approximately $8.1 million of outstanding performance obligations to be recognized over a period of thirteen to sixty months.  The remaining performance obligations are subject to customer actions and therefore the timing of revenue recognition cannot be reasonably estimated.  The twelve month performance obligations include anticipated shipments to Inox based on the twelve month rolling forecast provided by Inox on the multi-year supply contract. The quantities specified in any forecast provided by Inox related to the multi-year supply contract are firm and irrevocable for the first three months of a twelve month rolling forecast. The timing of the performance obligations beyond the Inox twelve month provided forecast are not determinable and therefore are not included in the total remaining performance obligations.

- added (2018-07-31):
[0001628280-18-009847:note_history:45]
The following table sets forth customers who represented 10% or more of the Company’s total revenues for the three months ended June 30, 2018 and 2017:

- added (2018-07-31):
[0001628280-18-009847:note_history:46]
|  | Reportable Segment |  | June 30, 2018 |  | June 30, 2017 |
| Inox Wind Limited | Wind |  | 25 | % |  | 22 | % |
| Vestas | Grid |  | 36 | % |  | — | % |
| U.S. Navy | Grid |  | <10% |  |  | 35 | % |


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: tag_name, score: 1.0

- changed (2018-07-31):
[0001628280-18-009847:note_history:47]
The Company has performed an evaluation of subsequent events through the time of filing this Quarterly Report on Form 10-Q with the SEC, apart from the Settlement Agreement with Sinovel described in Note 15, "Commitments and Contingencies," the Company has determined that there are no such events to report.
  (was, 2018-02-05, similarity 0.6417):
[0001628280-18-000993:note_history:47]
The Company has performed an evaluation of subsequent events through the time of filing this Quarterly Report on Form 10-Q with the SEC and has determined that other than those disclosed above, there are no such events to report.

- removed (2018-07-31):
[0001628280-18-000993:note_history:48]
On February 1, 2018, ASC Devens, LLC (the “Seller”), a wholly owned subsidiary of American Superconductor Corporation (the “Company”), entered into a Purchase and Sale Agreement (the “PSA”) with 64 Jackson LLC (the “Purchaser”) and Stewart Title Guaranty Company (“Escrow Agent”), pursuant to which the Seller has agreed to sell to the Purchaser certain real property located at 64 Jackson Road, Devens, Massachusetts, as described in the PSA, including the building that has served as the Company’s headquarters (collectively, the “Property”), in exchange for total consideration of $23.0 million, which is composed of (i) cash consideration of $17.0 million, and (ii) a $6.0 million subordinated secured commercial promissory note payable to the Seller (the “Seller Note”) at an interest rate equal to the short-term applicable federal rate then in effect at closing (the “Transaction”). The cash consideration includes a deposit of $500,000 (the “First Deposit”), which the Purchaser has agreed to deposit with the Escrow Agent within three business days after the execution of the PSA, and a second deposit (together with the First Deposit, the “Deposit”) of $500,000, which the Purchaser has agreed to deposit with the Escrow Agent on February 15, 2018, provided that the Seller has not terminated the PSA by that date. The PSA contains customary representations, warranties and covenants of the Seller and the Purchaser.  The Transaction is anticipated to close on March 30, 2018.  Pursuant to the PSA, at closing, the Escrow Agent has agreed to deliver the Deposit to the Seller, and Purchaser has agreed to deliver the remaining cash consideration and the Seller Note to the Seller. The closing of the Transaction is not contingent on any due diligence investigations (other than title), permitting, or financing, however, there is no guarantee that the Transaction will close in the timeframe the Company expects, or at all.

- removed (2018-07-31):
[0001628280-18-000993:note_history:49]
According to the Seller Note, the form of which is attached as Exhibit B to the PSA, $3,000,000 in principal, together with all accrued interest, is due and payable to the Seller on March 31, 2019, and $3,000,000 in principal, together with all accrued interest, is due and payable to the Seller on March 31, 2020, provided that, if the Purchaser sells the Property, all unpaid principal and accrued interest must be repaid in full.
