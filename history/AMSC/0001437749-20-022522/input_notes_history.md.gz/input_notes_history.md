# AMSC note change history — 0001437749-20-016667 → 0001437749-20-022522


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- added (2020-11-04):
[0001437749-20-022522:note_history:1]
September 30, 2020,

- removed (2020-11-04):
[0001437749-20-016667:note_history:2]
June 30, 2020


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- added (2020-11-04):
[0001437749-20-022522:note_history:3]
September 30, 2020

- added (2020-11-04):
[0001437749-20-022522:note_history:4]
September 30, 2020

- added (2020-11-04):
[0001437749-20-022522:note_history:5]
September 30, 2020

- added (2020-11-04):
[0001437749-20-022522:note_history:6]
September 30, 2020

- changed (2020-11-04):
[0001437749-20-022522:note_history:7]
million. Marketable securities include certificate of deposits with maturities between 
six
 and 
eleven
 months.  Cash used in operations for the
  (was, 2020-08-05, similarity 0.9375):
[0001437749-20-016667:note_history:7]
million. Marketable securities include certificate of deposits with maturities between 
eight
 and 
twenty-one
 months.  Cash used in operations for the

- added (2020-11-04):
[0001437749-20-022522:note_history:8]
six

- added (2020-11-04):
[0001437749-20-022522:note_history:9]
September 30, 2020

- changed (2020-11-04):
[0001437749-20-022522:note_history:10]
In 
 December 2015, 
the Company entered into a set of strategic agreements valued at approximately 
$210.0
 million with Inox Wind Ltd. (“Inox” or “Inox Wind”), which includes a multi-year supply contract pursuant to which the Company will supply electrical control systems ("ECS") to Inox and a license agreement allowing Inox to manufacture a limited number of ECS. After Inox purchases the specified number of ECS required under the terms of the supply contract, Inox agreed that the Company will continue as Inox's preferred supplier and Inox will be required to purchase from the Company a majority of its ECS requirements for an additional 
three
-year period. Pursuant to these strategic agreements, Inox must forecast future purchase orders of sets of ECS which become firm orders 
three
 months prior to shipment, and Inox must post letters of credit before the Company will ship such orders. Inox had been delinquent on its obligation to post letters of credit for sets of ECS that Inox forecasted to purchase under the terms of the supply contract.  On 
 May 29, 2020, 
the Company sent written notice to Inox notifying Inox of its default under the supply contract due to Inox's failure to post letters of credit in the amount of 
€6.0
 million for the payment of ECS that Inox is obligated to purchase under the terms of the supply contract.  If Inox failed to post letters of credit in the amount of 
€6.0
 million in accordance with the terms of the supply contract within the 
ninety
 day cure period after receipt of the default notice, then the Company could have terminated the supply contract by providing written notice of such termination to Inox.  On 
 September 2, 2020, 
Inox delivered approved letters of credit in the amount of 
€1.3
 million for the payment of a portion of the ECS that Inox was obligated to purchase under the terms of the supply contract.  On 
 September 11, 2020, 
the Company notified Inox that due to (i) the Company's business relationship with Inox, and (ii) Inox's delivery of approved letters of credit in the amount of 
€1.3
 million as described above, the Company gave Inox until 
 October 5, 2020 
to regain compliance with the terms of the supply contract by providing approved letters of credit in the amount of 
€4.7
 million for payment of the remaining ECS that Inox currently was obligated to purchase under the terms of the supply contract.  On 
 October 1, 2020, 
Inox delivered approved letters of credit for payment of the remaining ECS that Inox was obligated to purchase under the terms of the supply contract and cured the default set forth in the 
 May 29, 2020 
default notice.
  (was, 2020-08-05, similarity 0.6705):
[0001437749-20-016667:note_history:10]
In 
 December 2015, 
the Company entered into a set of strategic agreements valued at approximately 
$210.0
 million with Inox Wind Ltd. (“Inox” or “Inox Wind”), which includes a multi-year supply contract pursuant to which the Company will supply electrical control systems ("ECS") to Inox and a license agreement allowing Inox to manufacture a limited number of ECS. After Inox purchases the specified number of ECS required under the terms of the supply contract, Inox agreed that the Company will continue as Inox's preferred supplier and Inox will be required to purchase from the Company a majority of its ECS requirements for an additional 
three
-year period. Pursuant to these strategic agreements, Inox must forecast future purchase orders of sets of ECS which become firm orders 
three
 months prior to shipment, and Inox must post letters of credit before the Company will ship such orders. Inox is currently delinquent on its obligation to post letters of credit for sets of ECS that Inox forecasted to purchase under the terms of the supply contract.  On 
 May 29, 2020, 
the Company sent written notice to Inox notifying Inox of its default under the supply contract due to Inox's failure to post letters of credit in the amount of 
€6.0
 million for the payment of ECS that Inox is obligated to purchase under the terms of the supply contract.  If Inox fails to post letters of credit in the amount of 
€6.0
 million in accordance with the terms of the supply contract within the 
ninety
 day cure period after receipt of the default notice, then the Company 
 may 
terminate the supply contract by providing written notice of such termination to Inox.  We cannot predict if and when Inox will post letters of credit consistent with the forecasted ECS quantities. Inox's failure to post letters of credit and take delivery of forecasted ECS quantities would impact the Company's revenues and liquidity.  In the event the Company were to terminate the supply contract, the Company's revenues and liquidity would also be impacted.

- added (2020-11-04):
[0001437749-20-022522:note_history:11]
On 
 October 1, 2020, 
the Company entered into a Stock Purchase Agreement (the “Stock Purchase Agreement”) with the selling stockholders named therein.  Pursuant to the terms of the Stock Purchase Agreement and concurrently with entering into such agreement, the Company acquired all of the issued and outstanding (i) shares of capital stock of Northeast Power Systems, Inc., a New York corporation (“NEPSI”), and (ii) membership interests of Northeast Power Realty, LLC, a New York limited liability company, which holds the real property that serves as NEPSI's headquarters. NEPSI is a U.S.-based global provider of medium-voltage metal-enclosed power capacitor banks and harmonic filter banks for use on electric power systems. NEPSI is now a wholly-owned subsidiary of the Company and will be operated by its Grid business unit. The purchase price was 
$26.0
 million in cash and 
873,657
 restricted shares of common stock of the Company.  As part of the transaction, the selling stockholders 
 may 
receive up to an additional 
1,000,000
 shares of common stock of the Company upon the achievement of certain specified revenue objectives in the future.

- added (2020-11-04):
[0001437749-20-022522:note_history:12]
On 
 October 22, 2020, 
the Company entered into an underwriting agreement with Oppenheimer & Co. Inc., as representative of the several underwriters named therein, relating to the issuance and sale (the “Offering”) of 
3,670,000
 shares of the Company's common stock at a public offering price of 
$15.00
 per share. The net proceeds to the Company from the Offering were approximately 
$51.4
 million, after deducting underwriting discounts and commissions and estimated offering expenses payable by the Company. The Offering closed on 
 October 26, 2020. 
In addition, the Company has granted the underwriters a 
30
-day option to purchase up to an additional 
550,500
 shares of common stock at the public offering price.

- added (2020-11-04):
[0001437749-20-022522:note_history:13]
six

- added (2020-11-04):
[0001437749-20-022522:note_history:14]
September 30, 2020

- removed (2020-11-04):
[0001437749-20-016667:note_history:15]
June 30, 2020

- removed (2020-11-04):
[0001437749-20-016667:note_history:16]
June 30, 2020

- removed (2020-11-04):
[0001437749-20-016667:note_history:17]
June 30, 2020

- removed (2020-11-04):
[0001437749-20-016667:note_history:18]
June 30, 2020

- removed (2020-11-04):
[0001437749-20-016667:note_history:19]
three

- removed (2020-11-04):
[0001437749-20-016667:note_history:20]
June 30, 2020

- removed (2020-11-04):
[0001437749-20-016667:note_history:21]
three

- removed (2020-11-04):
[0001437749-20-016667:note_history:22]
June 30, 2020


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- added (2020-11-04):
[0001437749-20-022522:note_history:23]
|  |  | Three Months Ended September 30, 2020 |  |  | Six Months Ended September 30, 2020 |  |
| Product Line: |  | Grid |  |  | Wind |  |  | Grid |  |  | Wind |  |
| Equipment and systems |  | $ | 15,261 |  |  | $ | 4,059 |  |  | $ | 31,798 |  |  | $ | 6,676 |  |
| Services and technology development |  |  | 1,086 |  |  |  | 711 |  |  |  | 2,264 |  |  |  | 1,591 |  |
| Total |  | $ | 16,347 |  |  | $ | 4,770 |  |  | $ | 34,062 |  |  | $ | 8,267 |  |
| Region: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas |  | $ | 15,677 |  |  | $ | 30 |  |  | $ | 26,231 |  |  | $ | 42 |  |
| Asia Pacific |  |  | 370 |  |  |  | 4,734 |  |  |  | 6,385 |  |  |  | 8,002 |  |
| EMEA |  |  | 300 |  |  |  | 6 |  |  |  | 1,446 |  |  |  | 223 |  |
| Total |  | $ | 16,347 |  |  | $ | 4,770 |  |  | $ | 34,062 |  |  | $ | 8,267 |  |

- added (2020-11-04):
[0001437749-20-022522:note_history:24]
|  |  | Three Months Ended September 30, 2019 |  |  | Six Months Ended September 30, 2019 |  |
| Product Line: |  | Grid |  |  | Wind |  |  | Grid |  |  | Wind |  |
| Equipment and systems |  | $ | 10,044 |  |  | $ | 2,077 |  |  | $ | 18,399 |  |  | $ | 5,581 |  |
| Services and technology development |  |  | 1,445 |  |  |  | 446 |  |  |  | 2,946 |  |  |  | 856 |  |
| Total |  | $ | 11,489 |  |  | $ | 2,523 |  |  | $ | 21,345 |  |  | $ | 6,437 |  |
| Region: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas |  | $ | 10,698 |  |  | $ | 1 |  |  | $ | 18,499 |  |  | $ | 47 |  |
| Asia Pacific |  |  | 393 |  |  |  | 2,464 |  |  |  | 2,220 |  |  |  | 6,320 |  |
| EMEA |  |  | 398 |  |  |  | 58 |  |  |  | 626 |  |  |  | 70 |  |
| Total |  | $ | 11,489 |  |  | $ | 2,523 |  |  | $ | 21,345 |  |  | $ | 6,437 |  |

- removed (2020-11-04):
[0001437749-20-016667:note_history:25]
|  |  | Three Months Ended June 30, 2020 |  |
| Product Line: |  | Grid |  |  | Wind |  |
| Equipment and systems |  | $ | 16,537 |  |  | $ | 2,618 |  |
| Services and technology development |  |  | 1,178 |  |  |  | 880 |  |
| Total |  | $ | 17,715 |  |  | $ | 3,498 |  |
| Region: |  |  |  |  |  |  |  |  |
| Americas |  | $ | 10,554 |  |  | $ | 12 |  |
| Asia Pacific |  |  | 6,015 |  |  |  | 3,269 |  |
| EMEA |  |  | 1,146 |  |  |  | 217 |  |
| Total |  | $ | 17,715 |  |  | $ | 3,498 |  |

- removed (2020-11-04):
[0001437749-20-016667:note_history:26]
|  |  | Three Months Ended June 30, 2019 |  |
| Product Line: |  | Grid |  |  | Wind |  |
| Equipment and systems |  | $ | 8,354 |  |  | $ | 3,505 |  |
| Services and technology development |  |  | 1,501 |  |  |  | 410 |  |
| Total |  | $ | 9,855 |  |  | $ | 3,915 |  |
| Region: |  |  |  |  |  |  |  |  |
| Americas |  | $ | 7,801 |  |  | $ | 46 |  |
| Asia Pacific |  |  | 1,827 |  |  |  | 3,856 |  |
| EMEA |  |  | 227 |  |  |  | 13 |  |
| Total |  | $ | 9,855 |  |  | $ | 3,915 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- added (2020-11-04):
[0001437749-20-022522:note_history:27]
three
 and 
six

- added (2020-11-04):
[0001437749-20-022522:note_history:28]
September 30, 2020

- changed (2020-11-04):
[0001437749-20-022522:note_history:29]
% of revenue, respectively, was recognized at the point in time when control transferred to the customer, with the remainder being recognized over time.  In both the 
three
 and 
six
 months ended
  (was, 2020-08-05, similarity 0.8863):
[0001437749-20-016667:note_history:29]
% of revenue, respectively, was recognized at the point in time when control transferred to the customer, with the remainder being recognized over time.

- added (2020-11-04):
[0001437749-20-022522:note_history:30]
September 30, 2019

- added (2020-11-04):
[0001437749-20-022522:note_history:31]
,

- changed (2020-11-04):
[0001437749-20-022522:note_history:32]
77%
  (was, 2020-08-05, similarity 0.6667):
[0001437749-20-016667:note_history:32]
2019

- added (2020-11-04):
[0001437749-20-022522:note_history:33]
of revenue was recognized at the point in time when control transferred to the customer, with the remainder being recognized over time.

- changed (2020-11-04):
[0001437749-20-022522:note_history:34]
The Company's equipment and system product line includes certain contracts which do 
not
 meet the requirements of an exchange transaction and therefore do 
not
 fall within the scope of ASC 
606.
  As these non-exchange transaction contracts are considered grant revenue and do 
not
 fall within any specific accounting literature, the Company follows guidance within ASC 
606
 by analogy to recognize grant revenue over time.  In the
  (was, 2020-08-05, similarity 0.9834):
[0001437749-20-016667:note_history:34]
The Company's equipment and system product line includes certain contracts which do 
not
 meet the requirements of an exchange transaction and therefore do 
not
 fall within the scope of ASC 
606.
  As these non-exchange transaction contracts are considered grant revenue and do 
not
 fall within any specific accounting literature, the Company follows guidance within ASC 
606
 by analogy to recognize grant revenue over time.  In each of the

- changed (2020-11-04):
[0001437749-20-022522:note_history:35]
three
 and 
six
 months ended 
 September 30, 2020
  (was, 2020-08-05, similarity 0.7164):
[0001437749-20-016667:note_history:35]
three
 months ended 
 June 30, 2020

- added (2020-11-04):
[0001437749-20-022522:note_history:36]
million and $

- changed (2020-11-04):
[0001437749-20-022522:note_history:37]
million in grant revenue, respectively, which is included in the Company's Grid segment revenue.  In the 
three
 and 
six
 months ended
  (was, 2020-08-05, similarity 0.7736):
[0001437749-20-016667:note_history:37]
million in grant revenue, which is included in the Company's Grid segment revenue.

- added (2020-11-04):
[0001437749-20-022522:note_history:38]
September 30, 2019

- added (2020-11-04):
[0001437749-20-022522:note_history:39]
, the Company recorded 
$0.7
 million and 
$1.1
 million in grant revenue, respectively, which is included in the Company's Grid revenue.

- added (2020-11-04):
[0001437749-20-022522:note_history:40]
|  |  | Three Months Ended September 30, 2020 |  |  | Six Months Ended September 30, 2020 |  |
| Product Line: |  | Grid |  |  | Wind |  |  | Grid |  |  | Wind |  |
| Equipment and systems |  | $ | 15,261 |  |  | $ | 4,059 |  |  | $ | 31,798 |  |  | $ | 6,676 |  |
| Services and technology development |  |  | 1,086 |  |  |  | 711 |  |  |  | 2,264 |  |  |  | 1,591 |  |
| Total |  | $ | 16,347 |  |  | $ | 4,770 |  |  | $ | 34,062 |  |  | $ | 8,267 |  |
| Region: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas |  | $ | 15,677 |  |  | $ | 30 |  |  | $ | 26,231 |  |  | $ | 42 |  |
| Asia Pacific |  |  | 370 |  |  |  | 4,734 |  |  |  | 6,385 |  |  |  | 8,002 |  |
| EMEA |  |  | 300 |  |  |  | 6 |  |  |  | 1,446 |  |  |  | 223 |  |
| Total |  | $ | 16,347 |  |  | $ | 4,770 |  |  | $ | 34,062 |  |  | $ | 8,267 |  |

- added (2020-11-04):
[0001437749-20-022522:note_history:41]
|  |  | Three Months Ended September 30, 2019 |  |  | Six Months Ended September 30, 2019 |  |
| Product Line: |  | Grid |  |  | Wind |  |  | Grid |  |  | Wind |  |
| Equipment and systems |  | $ | 10,044 |  |  | $ | 2,077 |  |  | $ | 18,399 |  |  | $ | 5,581 |  |
| Services and technology development |  |  | 1,445 |  |  |  | 446 |  |  |  | 2,946 |  |  |  | 856 |  |
| Total |  | $ | 11,489 |  |  | $ | 2,523 |  |  | $ | 21,345 |  |  | $ | 6,437 |  |
| Region: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas |  | $ | 10,698 |  |  | $ | 1 |  |  | $ | 18,499 |  |  | $ | 47 |  |
| Asia Pacific |  |  | 393 |  |  |  | 2,464 |  |  |  | 2,220 |  |  |  | 6,320 |  |
| EMEA |  |  | 398 |  |  |  | 58 |  |  |  | 626 |  |  |  | 70 |  |
| Total |  | $ | 11,489 |  |  | $ | 2,523 |  |  | $ | 21,345 |  |  | $ | 6,437 |  |

- added (2020-11-04):
[0001437749-20-022522:note_history:42]
September 30, 2020

- changed (2020-11-04):
[0001437749-20-022522:note_history:43]
, and
  (was, 2020-08-05, similarity 0.75):
[0001437749-20-016667:note_history:43]
and

- changed (2020-11-04):
[0001437749-20-022522:note_history:44]
|  |  | Unbilled Accounts Receivable |  |  | Deferred Program Costs |  |  | Contract Liabilities |  |
| Beginning balance as of March 31, 2020 |  | $ | 5,711 |  |  | $ | 1,631 |  |  | $ | 26,142 |  |
| Increases for costs incurred to fulfill performance obligations |  |  | — |  |  |  | 3,279 |  |  |  | — |  |
| Increase (decrease) due to customer billings |  |  | (5,929 | ) |  |  | — |  |  |  | 23,931 |  |
| Decrease due to cost recognition on completed performance obligations |  |  | — |  |  |  | (3,314 | ) |  |  | — |  |
| Increase (decrease) due to recognition of revenue based on transfer of control of performance obligations |  |  | 6,186 |  |  |  | — |  |  |  | (28,678 | ) |
| Other changes and FX impact |  |  | 0 |  |  |  | 18 |  |  |  | 561 |  |
| Ending balance as of September 30, 2020 |  | $ | 5,968 |  |  | $ | 1,614 |  |  | $ | 21,956 |  |
  (was, 2020-08-05, similarity 0.9911):
[0001437749-20-016667:note_history:44]
|  |  | Unbilled Accounts Receivable |  |  | Deferred Program Costs |  |  | Contract Liabilities |  |
| Beginning balance as of March 31, 2020 |  | $ | 5,711 |  |  | $ | 1,631 |  |  | $ | 26,142 |  |
| Increases for costs incurred to fulfill performance obligations |  |  | — |  |  |  | 1,978 |  |  |  | — |  |
| Increase (decrease) due to customer billings |  |  | (3,620 | ) |  |  | — |  |  |  | 12,276 |  |
| Decrease due to cost recognition on completed performance obligations |  |  | — |  |  |  | (2,815 | ) |  |  | — |  |
| Increase (decrease) due to recognition of revenue based on transfer of control of performance obligations |  |  | 2,033 |  |  |  | — |  |  |  | (16,227 | ) |
| Other changes and FX impact |  |  | 1 |  |  |  | 7 |  |  |  | 194 |  |
| Ending balance as of June 30, 2020 |  | $ | 4,125 |  |  | $ | 801 |  |  | $ | 22,385 |  |

- changed (2020-11-04):
[0001437749-20-022522:note_history:45]
|  |  | Unbilled Accounts Receivable |  |  | Deferred Program Costs |  |  | Contract Liabilities |  |
| Beginning balance as of March 31, 2019 |  | $ | 2,213 |  |  | $ | 318 |  |  | $ | 15,519 |  |
| Increases for costs incurred to fulfill performance obligations |  |  | — |  |  |  | 2,153 |  |  |  | — |  |
| Increase (decrease) due to customer billings |  |  | (2,926 | ) |  |  | — |  |  |  | 19,340 |  |
| Decrease due to cost recognition on completed performance obligations |  |  | — |  |  |  | (310 | ) |  |  | — |  |
| Increase (decrease) due to recognition of revenue based on transfer of control of performance obligations |  |  | 4,711 |  |  |  | — |  |  |  | (18,534 | ) |
| Other changes and FX impact |  |  | (4 | ) |  |  | (9 | ) |  |  | (313 | ) |
| Ending balance as of September 30, 2019 |  | $ | 3,994 |  |  | $ | 2,152 |  |  | $ | 16,012 |  |
  (was, 2020-08-05, similarity 0.9343):
[0001437749-20-016667:note_history:45]
|  |  | Unbilled Accounts Receivable |  |  | Deferred Program Costs |  |  | Contract Liabilities |  |
| Beginning balance as of March 31, 2019 |  | $ | 2,213 |  |  | $ | 318 |  |  | $ | 15,521 |  |
| Increases for costs incurred to fulfill performance obligations |  |  | — |  |  |  | 771 |  |  |  | — |  |
| Increase (decrease) due to customer billings |  |  | (1,584 | ) |  |  | — |  |  |  | 10,857 |  |
| Decrease due to cost recognition on completed performance obligations |  |  | — |  |  |  | (4 | ) |  |  | — |  |
| Increase (decrease) due to recognition of revenue based on transfer of control of performance obligations |  |  | 1,467 |  |  |  | — |  |  |  | (7,761 | ) |
| Other changes and FX impact |  |  | (3 | ) |  |  | 3 |  |  |  | 73 |  |
| Ending balance as of June 30, 2019 |  | $ | 2,093 |  |  | $ | 1,088 |  |  | $ | 18,690 |  |

- added (2020-11-04):
[0001437749-20-022522:note_history:46]
September 30, 2020

- changed (2020-11-04):
[0001437749-20-022522:note_history:47]
three
 months of a 
twelve
-month rolling forecast. The timing of the performance obligations beyond the 
twelve
-month forecast provided by Inox are 
not
 determinable and therefore are 
not
 included in the total remaining performance obligations.
  (was, 2020-08-05, similarity 0.6261):
[0001437749-20-016667:note_history:47]
three
 months of a 
twelve
-month rolling forecast. The timing of the performance obligations beyond the 
twelve
-month forecast provided by Inox are 
not
 determinable and therefore are 
not
 included in the total remaining performance obligations.  See Note 
1,
 “Nature of the Business and Operations and Liquidity,” for further information regarding the uncertainty of timing of the performance obligations as a result of the written notice that the Company sent to Inox on 
 May 29, 2020 
notifying Inox of its default under the supply contract.

- changed (2020-11-04):
[0001437749-20-022522:note_history:48]
three
 and 
six
 months ended 
 September 30, 2020
  (was, 2020-08-05, similarity 0.7164):
[0001437749-20-016667:note_history:48]
three
 months ended 
 June 30, 2020

- added (2020-11-04):
[0001437749-20-022522:note_history:49]
|  |  |  | Three Months Ended |  |  | Six Months Ended |  |
|  | Reportable |  | September 30, |  |  | September 30, |  |
|  | Segment |  | 2020 |  |  | 2019 |  |  | 2020 |  |  | 2019 |  |
| EPC Services | Grid |  |  | 12 | % |  |  | 0 | % |  |  | 18 | % |  |  | 0 | % |
| Hoffman Construction | Grid |  |  | <10% |  |  |  | 25 | % |  |  | <10% |  |  |  | 12 | % |
| Inox Wind Limited | Wind |  |  | <10% |  |  |  | <10% |  |  |  | <10% |  |  |  | 17 | % |
| M.J. Electric, LLC | Grid |  |  | <10% |  |  |  | 25 | % |  |  | <10% |  |  |  | 13 | % |
| Micron Technology | Grid |  |  | <10% |  |  |  | <10% |  |  |  | <10% |  |  |  | 14 | % |
| Reed & Reed Inc. | Grid |  |  | 25 | % |  |  | 0 | % |  |  | 12 | % |  |  | 0 | % |
| Siemens Gamesa Renewable Energy Pty. Ltd. | Grid |  |  | <10% |  |  |  | 0 | % |  |  | 13 | % |  |  | 0 | % |

- removed (2020-11-04):
[0001437749-20-016667:note_history:50]
three

- removed (2020-11-04):
[0001437749-20-016667:note_history:51]
June 30, 2020

- removed (2020-11-04):
[0001437749-20-016667:note_history:52]
|  |  | Three Months Ended June 30, 2020 |  |
| Product Line: |  | Grid |  |  | Wind |  |
| Equipment and systems |  | $ | 16,537 |  |  | $ | 2,618 |  |
| Services and technology development |  |  | 1,178 |  |  |  | 880 |  |
| Total |  | $ | 17,715 |  |  | $ | 3,498 |  |
| Region: |  |  |  |  |  |  |  |  |
| Americas |  | $ | 10,554 |  |  | $ | 12 |  |
| Asia Pacific |  |  | 6,015 |  |  |  | 3,269 |  |
| EMEA |  |  | 1,146 |  |  |  | 217 |  |
| Total |  | $ | 17,715 |  |  | $ | 3,498 |  |

- removed (2020-11-04):
[0001437749-20-016667:note_history:53]
|  |  | Three Months Ended June 30, 2019 |  |
| Product Line: |  | Grid |  |  | Wind |  |
| Equipment and systems |  | $ | 8,354 |  |  | $ | 3,505 |  |
| Services and technology development |  |  | 1,501 |  |  |  | 410 |  |
| Total |  | $ | 9,855 |  |  | $ | 3,915 |  |
| Region: |  |  |  |  |  |  |  |  |
| Americas |  | $ | 7,801 |  |  | $ | 46 |  |
| Asia Pacific |  |  | 1,827 |  |  |  | 3,856 |  |
| EMEA |  |  | 227 |  |  |  | 13 |  |
| Total |  | $ | 9,855 |  |  | $ | 3,915 |  |

- removed (2020-11-04):
[0001437749-20-016667:note_history:54]
June 30, 2020

- removed (2020-11-04):
[0001437749-20-016667:note_history:55]
, and 
 June 30,

- removed (2020-11-04):
[0001437749-20-016667:note_history:56]
June 30, 2020

- removed (2020-11-04):
[0001437749-20-016667:note_history:57]
and

- removed (2020-11-04):
[0001437749-20-016667:note_history:58]
|  |  |  | Three Months Ended |  |
|  | Reportable |  | June 30, |  |
|  | Segment |  | 2020 |  |  | 2019 |  |
| Inox Wind Limited | Wind |  | <10% |  |  | 27% |  |
| Micron Technology | Grid |  | 0% |  |  | 25% |  |
| Siemens Gamesa Renewable Energy | Grid |  | 25% |  |  | 0% |  |
| EPC Services Company | Grid |  | 24% |  |  | 0% |  |


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: tag_name, score: 1.0

- added (2020-11-04):
[0001437749-20-022522:note_history:59]
The Company has performed an evaluation of subsequent events through the time of filing this Quarterly Report on Form 
10
-Q with the SEC and has determined that other than the following information, there are 
no
 such events to report.

- added (2020-11-04):
[0001437749-20-022522:note_history:60]
On 
 October 1, 2020, 
the Company entered into the Stock Purchase Agreement with the selling stockholders named therein.  Pursuant to the terms of the Stock Purchase Agreement and concurrently with entering into such agreement, the Company acquired all of the issued and outstanding (i) shares of capital stock of NEPSI, and (ii) membership interests of Northeast Power Realty, LLC, a New York limited liability company, which holds the real property that serves as NEPSI's headquarters.  NEPSI is a U.S.-based global provider of medium-voltage metal-enclosed power capacitor banks and harmonic filter banks for use on electric power systems. NEPSI is now a wholly-owned subsidiary of the Company and will be operated by the Grid business unit. The NEPSI purchase price was 
$26.0
 million in cash on hand, including cash from the settlement of the Company's 
$25
 million certificate of deposit during the 
three
 months ended 
 September 30, 2020, 
and 
873,657
 restricted shares of common stock of the Company.  The transaction also includes an earn-out opportunity with the potential for the issuance of up to an additional 
1.0
 million shares of common stock of the Company to the selling stockholders based on the achievement by NEPSI of certain revenue targets for the fiscal years ending 
 March 31, 2021 
through 
 March 31, 2024. 
The Company assumed 
no
 debt in this transaction. NEPSI's results of operations will be included in the Company's consolidated financial statements beginning on 
 October 1, 2020.

- added (2020-11-04):
[0001437749-20-022522:note_history:61]
On 
 October 26, 2020, 
the Company completed the Offering of 
3,670,000
 shares of common stock of the Company at a public offering price of 
$15.00
 per share.  The net proceeds to the Company from the Offering were approximately 
$51.4
 million, after deducting underwriting discounts and commissions and estimated offering expenses payable by the Company. In addition, the Company has granted the underwriters a 
30
-day option to purchase up to an additional 
550,500
 shares of common stock at the public offering price.

- removed (2020-11-04):
[0001437749-20-016667:note_history:62]
The Company has performed an evaluation of subsequent events through the time of filing this Quarterly Report on Form 
10
-Q with the SEC and has determined that other than the following information, there are 
no
 such events to report.  In 
 July 2020, 
the Company undertook restructuring activities, approved by the Board of Directors, in order to reorganize its global manufacturing operations and reduce its workforce to better reflect the current demand for its wind products.  Over the remainder of fiscal 
2020
 the Company intends to consolidate Wind manufacturing activities into its Massachusetts facilities and as a result reduced the headcount at its operation in Romania.   The cost
s
 associated with this restructuring event are 
not
 expected to be material to the consolidated financial statements.
