# AMSC MD&A — 0001437749-20-022522


## mdna

[0001437749-20-022522:mdna:1]
[same as prior period, unchanged from 0001437749-20-016667:mdna:1]

[0001437749-20-022522:mdna:2]
American Superconductor®, Amperium®, AMSC®, D-VAR®, PowerModule™, D-VAR VVO®, PQ-IVR®, SeaTitan®, Gridtec Solutions™, Windtec Solutions™, Smarter, Cleaner...Better Energy™ and Orchestrate the Rhythm and Harmony of Power on the Grid™ are trademarks or registered trademarks of American Superconductor Corporation or our subsidiaries. We reserve all of our rights with respect to our trademarks or registered trademarks regardless of whether they are so designated in this Quarterly Report on Form 10-Q by an ® or ™ symbol. All other brand names, product names, trademarks or service marks appearing in this Quarterly Report on Form 10-Q are the property of their respective holders.

[0001437749-20-022522:mdna:3]
[same as prior period, unchanged from 0001437749-20-016667:mdna:3]

[0001437749-20-022522:mdna:4]
We are a leading system provider of megawatt-scale resiliency solutions that orchestrate the rhythm and harmony of power on the grid™, and that protect and expand the capability of the U.S. Navy's fleet. In the power grid market, we enable electric utilities, industrial facilities, and renewable energy project developers to connect, transmit and distribute smarter, cleaner and better power through our transmission planning services and power electronics and superconductor-based systems. In the wind power market, we enable manufacturers to field highly competitive wind turbines through our advanced power electronics and control system products, engineering, and support services. Our power grid and wind products and services provide exceptional reliability, security, efficiency and affordability to our customers.

[0001437749-20-022522:mdna:5]
[same as prior period, unchanged from 0001437749-20-016667:mdna:5]

[0001437749-20-022522:mdna:6]
[same as prior period, unchanged from 0001437749-20-016667:mdna:6]

[0001437749-20-022522:mdna:7]
[same as prior period, unchanged from 0001437749-20-016667:mdna:7]

[0001437749-20-022522:mdna:8]
[same as prior period, unchanged from 0001437749-20-016667:mdna:8]

[0001437749-20-022522:mdna:9]
[same as prior period, unchanged from 0001437749-20-016667:mdna:9]

[0001437749-20-022522:mdna:10]
[same as prior period, unchanged from 0001437749-20-016667:mdna:10]

[0001437749-20-022522:mdna:11]
[same as prior period, unchanged from 0001437749-20-016667:mdna:11]

[0001437749-20-022522:mdna:12]
On October 1, 2020, we entered into a Stock Purchase Agreement (the “Stock Purchase Agreement”) with the selling stockholders named therein.  Pursuant to the terms of the Stock Purchase Agreement and concurrently with entering into such agreement, we acquired all of the issued and outstanding (i) shares of capital stock of Northeast Power Systems, Inc., a New York corporation (“NEPSI”), and (ii) membership interests of Northeast Power Realty, LLC, a New York limited liability company, which holds the real property that serves as NEPSI’s headquarters. NEPSI is a U.S.-based global provider of medium-voltage metal-enclosed power capacitor banks and harmonic filter banks for use on electric power systems.  As a result of this transaction, NEPSI became a wholly-owned subsidiary and will be operated by our Grid business unit.

[0001437749-20-022522:mdna:13]
The NEPSI purchase price was $26.0 million in cash on hand, including cash from the settlement of our $25 million certificate of deposit during the three months ended September 30, 2020, and 873,657 restricted shares of our common stock.  As part of the transaction, in the future the selling stockholders may receive up to an additional 1,000,000 million restricted shares of our common stock upon the achievement of certain specified revenue objectives.

[0001437749-20-022522:mdna:14]
On October 26, 2020, we completed the Offering of 3,670,000 shares of our common stock at a public offering price of $15.00 per share. We received net proceeds of approximately $51.4 million after deducting underwriting discounts and commissions and estimated offering expenses.  See Note 1, “Nature of the Business and Operations and Liquidity,” for further information about this offering.

[0001437749-20-022522:mdna:15]
[same as prior period, unchanged from 0001437749-20-016667:mdna:12]

[0001437749-20-022522:mdna:16]
[same as prior period, unchanged from 0001437749-20-016667:mdna:13]

[0001437749-20-022522:mdna:17]
[same as prior period, unchanged from 0001437749-20-016667:mdna:14]

[0001437749-20-022522:mdna:18]
[same as prior period, unchanged from 0001437749-20-016667:mdna:15]

[0001437749-20-022522:mdna:19]
[same as prior period, unchanged from 0001437749-20-016667:mdna:16]

[0001437749-20-022522:mdna:20]
Three and six months ended September 30, 2020 compared to the three and six months ended September 30, 2019

[0001437749-20-022522:mdna:21]
[same as prior period, unchanged from 0001437749-20-016667:mdna:18]

[0001437749-20-022522:mdna:22]
Total revenues increased 51% and 52% to $21.1 million and $42.3 million for the three and six months ended September 30, 2020, respectively, compared to $14.0 million and $27.8 million for the three and six months ended September 30, 2019, respectively.  Our revenues are summarized as follows (in thousands):

[0001437749-20-022522:mdna:23]
|  |  | Three Months Ended September 30, |  |  | Six Months Ended September 30, |  |
|  |  | 2020 |  |  | 2019 |  |  | 2020 |  |  | 2019 |  |
| Revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Grid |  | $ | 16,347 |  |  | $ | 11,489 |  |  | $ | 34,062 |  |  | $ | 21,345 |  |
| Wind |  |  | 4,770 |  |  |  | 2,523 |  |  |  | 8,267 |  |  |  | 6,437 |  |
| Total |  | $ | 21,117 |  |  | $ | 14,012 |  |  | $ | 42,329 |  |  | $ | 27,782 |  |

[0001437749-20-022522:mdna:24]
Our Grid business unit accounted for 77% and 80% of total revenues for the three and six months ended September 30, 2020, respectively, compared to 82% and 77% for the three and six months ended September 30, 2019, respectively. Our Grid business unit revenues increased 42% and 60% to $16.3 million and $34.1 million in the three and six months ended September 30, 2020, respectively, from $11.5 million and $21.3 million in the three and six months ended September 30, 2019, respectively. Grid business unit revenue in the three and six months ended September 30, 2020 was driven by stronger D-VAR, VVO and ship protection systems revenue.

[0001437749-20-022522:mdna:25]
Our Wind business unit accounted for 23% and 20% of total revenues for the three and six months ended September 30, 2020, respectively, compared to 18% and 23% for the three and six months ended September 30, 2019, respectively. Revenues in the Wind business unit increased 89% and 28% to $4.8 million and $8.3 million in the three and six months ended September 30, 2020, from $2.5 million and $6.4 million in the three and six months ended September 30, 2019. The increase over the prior year period was driven by increased shipments of electrical control systems ("ECS") to Doosan and an increase in spares revenue.  As further described in Note 1 “Nature of the Business and Operations and Liquidity,” Inox was delinquent on its obligations to post letters of credit for sets of ECS that Inox has agreed to purchase under the terms of the supply contract, and on May 29, 2020, we sent written notice to Inox notifying Inox of its default under the supply contract due to Inox’s failure to post letters of credit in the amount of €6.0 million for the payment of ECS that Inox is obligated to purchase under the terms of the supply contract. On October 1, 2020, Inox delivered approved letters of credit for payment of the remaining ECS that Inox had been obligated to purchase under the terms of the Supply Contract and has cured the default set forth in the May 29, 2020 default notice.  Despite curing the default, Inox’s ability to perform under the supply contract has been and may continue in the future to be hampered by the prolonged impacts of the COVID-19 pandemic. Inox has been active in the new central and state government auction regime in India and has a cumulative order book of over 1.4 GW.  However, we cannot predict if and how successful Inox will be in executing on these orders or in obtaining new orders under the new central and state auction regime. Any failure by Inox to succeed under this regime, or any delay in Inox’s ability to deliver its wind turbines, could result in fewer ECS shipments to Inox.

[0001437749-20-022522:mdna:26]
[same as prior period, unchanged from 0001437749-20-016667:mdna:23]

[0001437749-20-022522:mdna:27]
Cost of revenues increased by 52% and 42% to $15.6 million and $31.8 million for the three and six months ended September 30, 2020, compared to $10.2 million and $22.4 million for the three and six months ended September 30, 2019. Gross margin was 26% and 25% for the three and six months ended September 30, 2020, compared to 27% and 19% for the three and six months ended September 30, 2019.  The three month period remained relatively flat and there was an increase in gross margin in the six months ended September 30, 2020 which was due to higher revenue and a more favorable product mix.

[0001437749-20-022522:mdna:28]
[same as prior period, unchanged from 0001437749-20-016667:mdna:25]

[0001437749-20-022522:mdna:29]
[same as prior period, unchanged from 0001437749-20-016667:mdna:26]

[0001437749-20-022522:mdna:30]
Research and development ("R&D") expenses increased 13% in the three months ended September 30, 2020 to $2.7 million from $2.4 million in the three months ended September 30, 2019.  The increase in R&D expense was due to a higher overall compensation expense in the three months ended September 30, 2020 compared to the three months ended September 30, 2019.  Research and development expenses increased 7% in the six months ended September 30, 2020 to $5.2 million from $4.9 million in the six months ended September 30, 2019. The increase in R&D expense in the six month period was due to higher overall compensation expense than in the prior year period.

[0001437749-20-022522:mdna:31]
[same as prior period, unchanged from 0001437749-20-016667:mdna:28]

[0001437749-20-022522:mdna:32]
Selling, general and administrative ("SG&A") expenses increased 9% in the three months ended September 30, 2020 to $5.9 million from $5.4 million in the three months ended September 30, 2019. The increase in SG&A expense in the three months ended September 30, 2020 was due to higher overall compensation expense than in the prior year period.  Selling, general and administrative expenses increased 8% to $11.5 in the six months ended September 30, 2020 compared to $10.7 million in the six months ended September 30, 2019. The increase in SG&A expense in the six months ended September 30, 2020 was due to higher overall compensation expense than in the prior year period.

[0001437749-20-022522:mdna:33]
[same as prior period, unchanged from 0001437749-20-016667:mdna:30]

[0001437749-20-022522:mdna:34]
We recorded amortization expense related to our core technology and know-how, trade names and trademark, and intangible assets of $0.1 million in each of the three month periods ended September 30, 2020 and 2019, respectively, and $0.2 million in each of the six month periods ended September 30, 2020 and 2019 respectively.

[0001437749-20-022522:mdna:35]
[same as prior period, unchanged from 0001437749-20-016667:mdna:32]

[0001437749-20-022522:mdna:36]
[same as prior period, unchanged from 0001437749-20-016667:mdna:33]

[0001437749-20-022522:mdna:37]
|  |  | Three Months Ended September 30, |  |  | Six Months Ended September 30, |  |
|  |  | 2020 |  |  | 2019 |  |  | 2020 |  |  | 2019 |  |
| Operating loss: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Grid |  | $ | (1,374 | ) |  | $ | (1,324 | ) |  | $ | (2,562 | ) |  | $ | (5,988 | ) |
| Wind |  |  | (983 | ) |  |  | (2,398 | ) |  |  | (2,103 | ) |  |  | (3,721 | ) |
| Unallocated corporate expenses |  |  | (849 | ) |  |  | (397 | ) |  |  | (1,758 | ) |  |  | (646 | ) |
| Total |  | $ | (3,206 | ) |  | $ | (4,119 | ) |  | $ | (6,423 | ) |  | $ | (10,355 | ) |

[0001437749-20-022522:mdna:38]
Our Grid segment generated operating losses of $1.4 million and $2.6 million in the three and six months ended September 30, 2020, compared to $1.3 million and $6.0 million in the three and six months ended September 30, 2019. The increase in the Grid business unit operating loss in the three months ended September 30, 2020 was due to higher revenues and a more favorable product mix offset by increased overall compensation expense.  The decrease in the Grid business unit operating loss in the six months ended September 30, 2020 was due to higher revenues and a more favorable product mix.

[0001437749-20-022522:mdna:39]
Our Wind segment generated operating losses of $1.0 million and $2.1 million in the three and six months ended September 30, 2020, compared to $2.4 million and $3.7 million in the three and six months ended September 30, 2019. The decrease in the Wind business unit operating loss in both periods was due to higher revenues and a more favorable product mix.

[0001437749-20-022522:mdna:40]
Unallocated corporate expenses primarily consisted of stock-based compensation expense of $0.8 million and $0.4 million in the three months ended September 30, 2020 and 2019 respectively.  Unallocated corporate expenses primarily consisted of stock-based compensation expense of $1.8 million and $0.6 million in the six months ended September 30, 2020 and 2019, respectively.

[0001437749-20-022522:mdna:41]
[same as prior period, unchanged from 0001437749-20-016667:mdna:38]

[0001437749-20-022522:mdna:42]
There were no warrants outstanding in the three and six months ended September 30, 2020.  The change in fair value of warrants resulted in gains of $1.1 million and $4.1 million in the three and six months ended September 30, 2019. The change in the fair value was primarily driven by changes in stock price, which is a key valuation metric.

[0001437749-20-022522:mdna:43]
[same as prior period, unchanged from 0001437749-20-016667:mdna:40]

[0001437749-20-022522:mdna:44]
Interest income, net, was $0.2 million and $0.3 million in the three and six months ended September 30, 2020, compared to $0.3 million and $0.8 million in the three and six months ended September 30, 2019. The decreases in interest income in the three and six months ended September 30, 2020 were related to lower cash balances earning lower interest rates than in the prior period, as well as interest recorded related to the sale of the Devens facility for the six months ended September 30, 2019 with no such transaction in the current year.

[0001437749-20-022522:mdna:45]
Other (expense)/income, net

[0001437749-20-022522:mdna:46]
Other expense, net, was $0.5 million and $0.6 million in the three and six months ended September 30, 2020, compared to other income, net of $1.5 million and $1.0 million in the three and six months ended September 30, 2019.  The decreases in other income, net, were driven by higher foreign currency losses.

[0001437749-20-022522:mdna:47]
[same as prior period, unchanged from 0001437749-20-016667:mdna:44]

[0001437749-20-022522:mdna:48]
Income tax expense was $0.2 million and $0.4 in the three and six months ended September 30, 2020. Income tax benefit was $0.3 million and $0.1 million in the three and six months ended September 30, 2019. The income tax expense is due primarily to taxes incurred in foreign jurisdictions.

[0001437749-20-022522:mdna:49]
[same as prior period, unchanged from 0001437749-20-016667:mdna:46]

[0001437749-20-022522:mdna:50]
Net loss was $3.7 million and $7.1 million in the three and six months ended September 30, 2020, compared to $0.8 million and $4.4 million in the three and six months ended September 30, 2019.  The increases in net loss were driven by the gain on fair value of warrants in the prior year period that did not recur in the six months ended September 30, 2020 as well as decreases in other income as discussed above.

[0001437749-20-022522:mdna:51]
[same as prior period, unchanged from 0001437749-20-016667:mdna:48]

[0001437749-20-022522:mdna:52]
[same as prior period, unchanged from 0001437749-20-016667:mdna:49]

[0001437749-20-022522:mdna:53]
We define non-GAAP net loss as net loss before stock-based compensation, amortization of acquisition-related intangibles, change in fair value of warrants, and other non-cash or unusual charges, and the tax effect of those adjustments calculated at the relevant rate for our non-GAAP metric, if applicable.  We believe non-GAAP net loss assists management and investors in comparing our performance across reporting periods on a consistent basis by excluding these non-cash charges and other items that we do not believe are indicative of our core operating performance. In addition, we use non-GAAP net loss as a factor to evaluate the effectiveness of our business strategies. A reconciliation of GAAP to non-GAAP net loss is set forth in the table below (in thousands, except per share data):

[0001437749-20-022522:mdna:54]
|  |  | Three Months Ended September 30, |  |  | Six Months Ended September 30, |  |
|  |  | 2020 |  |  | 2019 |  |  | 2020 |  |  | 2019 |  |
| Net loss |  | $ | (3,712 | ) |  | $ | (825 | ) |  | $ | (7,129 | ) |  | $ | (4,364 | ) |
| Stock-based compensation |  |  | 849 |  |  |  | 397 |  |  |  | 1,758 |  |  |  | 646 |  |
| Amortization of acquisition-related intangibles |  |  | 121 |  |  |  | 85 |  |  |  | 242 |  |  |  | 170 |  |
| Change in fair value of warrants |  |  | — |  |  |  | (1,145 | ) |  |  | — |  |  |  | (4,092 | ) |
| Non-GAAP net loss |  | $ | (2,743 | ) |  | $ | (1,488 | ) |  | $ | (5,129 | ) |  | $ | (7,640 | ) |
| Non-GAAP net loss per share - basic |  | $ | (0.13 | ) |  | $ | (0.07 | ) |  | $ | (0.24 | ) |  | $ | (0.37 | ) |
| Non-GAAP net loss per share - diluted |  | $ | (0.13 | ) |  | $ | (0.07 | ) |  | $ | (0.24 | ) |  | $ | (0.37 | ) |
| Weighted average shares outstanding - basic |  |  | 21,860 |  |  |  | 20,656 |  |  |  | 21,775 |  |  |  | 20,586 |  |
| Weighted average shares outstanding - diluted |  |  | 21,860 |  |  |  | 20,723 |  |  |  | 21,775 |  |  |  | 20,736 |  |

[0001437749-20-022522:mdna:55]
We incurred non-GAAP net losses of $2.7 million and $5.1  million or $0.13 and $0.24  per share, for the three and six months ended September 30, 2020, compared to $1.5 million and $7.6 million, or $0.07 and $0.37 per share for the three and six months ended September 30, 2019. The decrease in the six month non-GAAP net loss was due to lower operating loss driven by higher revenues and a more favorable product mix.  The increase in the three month period was driven by increased net loss as a result of higher foreign currency losses during the three months ended September 30, 2020.

[0001437749-20-022522:mdna:56]
[same as prior period, unchanged from 0001437749-20-016667:mdna:53]

[0001437749-20-022522:mdna:57]
[same as prior period, unchanged from 0001437749-20-016667:mdna:54]

[0001437749-20-022522:mdna:58]
We have experienced recurring operating losses, and as of September 30, 2020, had an accumulated deficit of $985.8 million.

[0001437749-20-022522:mdna:59]
Our cash requirements depend on numerous factors, including the successful completion of our product development activities, our ability to commercialize our REG and ship protection system solutions, the rate of customer and market adoption of our products, collecting receivables according to established terms, the continued availability of U.S. government funding during the product development phase of our superconductor-based products and whether Inox is successful in executing on Solar Energy Corporation of India Limited orders or in obtaining additional orders under the new central and state auction regime. We continue to closely monitor our expenses and, if required, expect to further reduce our operating and capital spending to enhance liquidity.

[0001437749-20-022522:mdna:60]
As described above, on October 1, 2020, we acquired NEPSI. The NEPSI purchase price was $26.0 million in cash on hand, including cash from the settlement of our $25 million certificate of deposit during the three months ended September 30, 2020, and 873,657 restricted shares of common stock of the Company.  As part of the transaction, the selling stockholders may receive additional restricted shares of common stock of the Company upon the achievement of certain specified revenue objectives in the future.

[0001437749-20-022522:mdna:61]
As described above, on October 26, 2020, we completed an offering of 3,670,000 shares of our common stock at a public offering price of $15.00 per share. We received net proceeds of approximately $51.4 million after deducting underwriting discounts and commissions and estimated offering expenses.  In addition, we have granted the underwriters a 30-day option to purchase up to an additional 550,500 shares of common stock at the public offering price.

[0001437749-20-022522:mdna:62]
As of September 30, 2020, we had cash, cash equivalents, marketable securities and restricted cash of $57.7 million, compared to $66.1 million as of March 31, 2020, a decrease of $8.3 million. As of September 30, 2020, we had approximately $6.1 million of cash, cash equivalents, and restricted cash in foreign bank accounts. Our cash, cash equivalents, marketable securities and restricted cash are summarized as follows (in thousands):

[0001437749-20-022522:mdna:63]
|  |  | September 30, 2020 |  |  | March 31, 2020 |  |
| Cash and cash equivalents |  | $ | 41,246 |  |  | $ | 24,699 |  |
| Marketable securities |  |  | 10,191 |  |  |  | 35,195 |  |
| Restricted cash |  |  | 6,290 |  |  |  | 6,165 |  |
| Total cash, cash equivalents, marketable securities and restricted cash |  | $ | 57,726 |  |  | $ | 66,059 |  |

[0001437749-20-022522:mdna:64]
For the six months ended September 30, 2020, net cash used in operating activities was $6.6 million, compared to $10.5 million for the six months ended September 30, 2019 The decrease in net cash used in operations was due primarily to the overall impact of increased sales activities on the operating activities, partially offset by higher payments on accounts payable and higher accrued expenses in the six months ended September 30, 2020 as compared to September 30, 2019.

[0001437749-20-022522:mdna:65]
For the six months ended September 30, 2020, net cash provided by investing activities was $23.7 million, compared to net cash used in investing activities of $8.7 million for the six months ended September 30, 2019. The increase in net cash provided by investing activities was due primarily to the settlement of the $25.0 million certificate of deposit which was used to fund the acquisition of NEPSI on October 1, 2020 in the six months ended September 30, 2020 with no such transaction in the prior fiscal year.

[0001437749-20-022522:mdna:66]
For the six months ended September 30, 2020, net cash used in financing activities was $0.6 million compared to $0.4 million in the six months ended September 30, 2019.  The increase in net cash used in financing activities was due primarily to the repurchase of common stock in connection with employee tax obligations upon the vesting of stock awards.

[0001437749-20-022522:mdna:67]
As of September 30, 2020, we had $5.8 million of restricted cash included in long-term assets and $0.5 million of restricted cash included in current assets.  These amounts included in restricted cash primarily represent deposits to secure letters of credit for various supply contracts and long-term projects, including the irrevocable letter of credit in the amount of $5.0 million to secure certain of the Company's obligations under the Subcontract Agreement with ComEd. These deposits are held in interest bearing accounts.

[0001437749-20-022522:mdna:68]
We believe we have sufficient available liquidity to fund our operations and capital expenditures for the next twelve months. In addition, we may seek to raise additional capital, which could be in the form of loans, convertible debt or equity, to fund our operating requirements and capital expenditures. We have no outstanding warrants as of September 30, 2020. Our liquidity is highly dependent on our ability to increase revenues, including our ability to collect revenues under our agreements with Inox, control our operating costs, and raise additional capital, if necessary. There can be no assurance that we will be able to raise additional capital on favorable terms or at all, or execute on any other means of improving our liquidity as described above.  Additionally, the impact of the COVID-19 pandemic on the global financial markets may reduce our ability to raise additional capital, if necessary, which could negatively impact our liquidity.

[0001437749-20-022522:mdna:69]
[same as prior period, unchanged from 0001437749-20-016667:mdna:64]

[0001437749-20-022522:mdna:70]
[same as prior period, unchanged from 0001437749-20-016667:mdna:65]

[0001437749-20-022522:mdna:71]
|  |  | Six months ended |  |
|  |  | September 30, 2020 |  |  | September 30, 2019 |  |
| Operating cash flow |  | $ | (6,553 | ) |  | $ | (10,485 | ) |
| Sinovel settlement (net of legal fees and expenses) |  |  | — |  |  |  | 1,000 |  |
| Non-GAAP operating cash flow |  | $ | (6,553 | ) |  | $ | (9,485 | ) |

[0001437749-20-022522:mdna:72]
Legal Proceedings

[0001437749-20-022522:mdna:73]
We are involved in legal and administrative proceedings and claims of various types. See Part II, Item 1, “Legal Proceedings,” for additional information. We record a liability in our consolidated financial statements for these matters when a loss is known or considered probable and the amount can be reasonably estimated. We review these estimates each accounting period as additional information is known and adjust the loss provision when appropriate. If a matter is both probable to result in liability and the amounts of loss can be reasonably estimated, we estimate and disclose the possible loss or range of loss to the extent necessary to make the consolidated financial statements not misleading. If the loss is not probable or cannot be reasonably estimated, a liability is not recorded in our consolidated financial statements.

[0001437749-20-022522:mdna:74]
[same as prior period, unchanged from 0001437749-20-016667:mdna:69]

[0001437749-20-022522:mdna:75]
[same as prior period, unchanged from 0001437749-20-016667:mdna:70]

[0001437749-20-022522:mdna:76]
[same as prior period, unchanged from 0001437749-20-016667:mdna:71]

[0001437749-20-022522:mdna:77]
[same as prior period, unchanged from 0001437749-20-016667:mdna:72]

[0001437749-20-022522:mdna:78]
[same as prior period, unchanged from 0001437749-20-016667:mdna:73]

[0001437749-20-022522:mdna:79]
In June 2016, the FASB issued ASU 2016-13, Financial Instruments-Credit Losses (Topic 326): Measurement of Credit Losses on Financial Instruments. The amendments in ASU 2016-13 provide more decision-useful information about the expected credit losses on financial instruments and other commitments to extend credit held by a reporting entity at each reporting date. The ASU is effective for annual reporting periods beginning after December 15, 2019, including interim periods within that year.  Following the release of ASU 2019-10 in November 2019, the new effective date, as long as the Company remains a smaller reporting company, would be annual reporting periods beginning after December 15, 2022.   We are currently evaluating the impact, if any, that the adoption of ASU 2016-13 may have on our consolidated financial statements.

[0001437749-20-022522:mdna:80]
In August 2018, the FASB issued ASU 2018-13, Fair Value Measurement (Topic 820): Changes to the Disclosure Requirements for Fair Value Measurement. The amendments in ASU 2018-13 provide for increased effectiveness of the disclosures made around fair value measurements while including consideration for costs and benefits. The ASU is effective for annual reporting periods beginning after December 15, 2019, including interim periods within those periods.  As of April 1, 2020, we have adopted ASU 2018-13 and noted no material impact on our consolidated financial statements, primarily due to the fact that we do not currently report any Level 3 fair value measurements.

[0001437749-20-022522:mdna:81]
In December 2019, the FASB issued ASU 2019-12, Income Taxes (Topic 740): Simplifying the Accounting for Income Taxes. The amendments in ASU 2019-12 provide for simplified accounting to several income tax situations and removal of certain accounting exceptions. The ASU is effective for annual reporting periods beginning after December 15, 2020, including interim periods within those periods. We do not expect the impact of the adoption of ASU 2019-12 to be material to our consolidated financial statements.

[0001437749-20-022522:mdna:82]
We do not believe that, outside of those disclosed here, there are any other recently issued accounting pronouncements that will have a material impact on our consolidated financial statements.
