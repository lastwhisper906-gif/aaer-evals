# AMSC notes — 0001437749-20-022522


## amsc:AccountsReceivableTableTextBlock

[0001437749-20-022522:notes:1]
|  |  | September 30, 2020 |  |  | March 31, 2020 |  |
| Accounts receivable (billed) |  | $ | 10,865 |  |  | $ | 11,276 |  |
| Accounts receivable (unbilled) |  |  | 5,968 |  |  |  | 5,711 |  |
| Less: Allowance for doubtful accounts |  |  | (23 | ) |  |  | — |  |
| Accounts receivable, net |  | $ | 16,810 |  |  | $ | 16,987 |  |


## amsc:AccountsReceivableTextBlock

[0001437749-20-022522:notes:2]
[same as prior period, unchanged from 0001437749-20-016667:notes:2]

[0001437749-20-022522:notes:3]
[same as prior period, unchanged from 0001437749-20-016667:notes:3]

[0001437749-20-022522:notes:4]
September 30, 2020

[0001437749-20-022522:notes:5]
[same as prior period, unchanged from 0001437749-20-016667:notes:5]

[0001437749-20-022522:notes:6]
[same as prior period, unchanged from 0001437749-20-016667:notes:6]

[0001437749-20-022522:notes:7]
[same as prior period, unchanged from 0001437749-20-016667:notes:7]

[0001437749-20-022522:notes:8]
The Company recorded allowance for doubtful accounts of less than

[0001437749-20-022522:notes:9]
$0.1

[0001437749-20-022522:notes:10]
million for the 
three
 months and 
six
 months ended

[0001437749-20-022522:notes:11]
no

[0001437749-20-022522:notes:12]
allowance for the 
three
 or 
six
 months ended

[0001437749-20-022522:notes:13]
September 30, 2019

[0001437749-20-022522:notes:14]
.  The allowances are based on evaluation of customer accounts that are past due.


## amsc:AssetsAndLiabilitiesLesseeTableTextBlock

[0001437749-20-022522:notes:15]
|  |  | September 30, 2020 |  |  | March 31, 2020 |  |
| Operating Leases: |  |  |  |  |  |  |  |  |
| Right-of-use assets |  | $ | 3,907 |  |  | $ | 3,359 |  |
| Total right-of-use assets |  |  | 3,907 |  |  |  | 3,359 |  |
| Lease liabilities - ST |  | $ | 568 |  |  | $ | 439 |  |
| Lease liabilities - LT |  |  | 3,430 |  |  |  | 3,000 |  |
| Total operating lease liabilities |  |  | 3,997 |  |  |  | 3,439 |  |
| Weighted-average remaining lease term |  |  | 6.31 |  |  |  | 6.91 |  |
| Weighted-average discount rate |  |  | 6.79 | % |  |  | 7.08 | % |


## us-gaap:AccountsPayableAndAccruedLiabilitiesDisclosureTextBlock

[0001437749-20-022522:notes:16]
[same as prior period, unchanged from 0001437749-20-016667:notes:9]

[0001437749-20-022522:notes:17]
[same as prior period, unchanged from 0001437749-20-016667:notes:10]

[0001437749-20-022522:notes:18]
|  |  | September 30, 2020 |  |  | March 31, 2020 |  |
| Accounts payable |  | $ | 7,655 |  |  | $ | 10,045 |  |
| Accrued inventories in-transit |  |  | 316 |  |  |  | 763 |  |
| Accrued other miscellaneous expenses |  |  | 2,383 |  |  |  | 1,986 |  |
| Advanced deposits |  |  | 691 |  |  |  | 666 |  |
| Accrued compensation |  |  | 4,349 |  |  |  | 5,683 |  |
| Income taxes payable |  |  | 967 |  |  |  | 933 |  |
| Accrued product warranty |  |  | 2,109 |  |  |  | 2,015 |  |
| Total |  | $ | 18,470 |  |  | $ | 22,091 |  |

[0001437749-20-022522:notes:19]
[same as prior period, unchanged from 0001437749-20-016667:notes:12]

[0001437749-20-022522:notes:20]
[same as prior period, unchanged from 0001437749-20-016667:notes:13]

[0001437749-20-022522:notes:21]
|  |  | Three Months Ended September 30, |  |  | Six Months Ended September 30, |  |
|  |  | 2020 |  |  | 2019 |  |  | 2020 |  |  | 2019 |  |
| Balance at beginning of period |  | $ | 2,168 |  |  | $ | 1,606 |  |  | $ | 2,015 |  |  | $ | 1,545 |  |
| Change in accruals for warranties during the period |  |  | 148 |  |  |  | 71 |  |  |  | 384 |  |  |  | 156 |  |
| Settlements during the period |  |  | (207 | ) |  |  | (36 | ) |  |  | (290 | ) |  |  | (60 | ) |
| Balance at end of period |  | $ | 2,109 |  |  | $ | 1,641 |  |  | $ | 2,109 |  |  | $ | 1,641 |  |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001437749-20-022522:notes:22]
14.
 Commitments and Contingencies

[0001437749-20-022522:notes:23]
Legal Contingencies

[0001437749-20-022522:notes:24]
From time to time, the Company is involved in legal and administrative proceedings and claims of various types. The Company records a liability in its consolidated financial statements for these matters when a loss is known or considered probable and the amount can be reasonably estimated. The Company reviews these estimates each accounting period as additional information is known and adjusts the loss provision when appropriate. If a matter is both probable to result in a liability and the amounts of loss can be reasonably estimated, the Company estimates and discloses the possible loss or range of loss to the extent necessary to make the consolidated financial statements 
not
 misleading. If the loss is 
not
 probable or cannot be reasonably estimated, a liability is 
not
 recorded in its consolidated financial statements.

[0001437749-20-022522:notes:25]
Other

[0001437749-20-022522:notes:26]
The Company enters into long-term construction contracts with customers that require the Company to obtain performance bonds. The Company is required to deposit an amount equivalent to some or all the face amount of the performance bonds into an escrow account until the termination of the bond. When the performance conditions are met, amounts deposited as collateral for the performance bonds are returned to the Company. In addition, the Company has various contractual arrangements in which minimum quantities of goods or services have been committed to be purchased on an annual basis.

[0001437749-20-022522:notes:27]
As of

[0001437749-20-022522:notes:28]
September 30, 2020,

[0001437749-20-022522:notes:29]
, the Company had $

[0001437749-20-022522:notes:30]
5.8

[0001437749-20-022522:notes:31]
million of restricted cash included in long-term assets and $

[0001437749-20-022522:notes:32]
0.5

[0001437749-20-022522:notes:33]
million of restricted cash included in current assets, respectively. These amounts included in restricted cash primarily represent deposits to secure letters of credit for various supply contracts and long-term projects, including the irrevocable letter of credit in the amount of 
$5.0
 million to secure certain of the Company's obligations under the Subcontract Agreement with ComEd.  These deposits are held in interest bearing accounts.


## us-gaap:ContractWithCustomerAssetAndLiabilityTableTextBlock

[0001437749-20-022522:notes:34]
|  |  | Unbilled Accounts Receivable |  |  | Deferred Program Costs |  |  | Contract Liabilities |  |
| Beginning balance as of March 31, 2020 |  | $ | 5,711 |  |  | $ | 1,631 |  |  | $ | 26,142 |  |
| Increases for costs incurred to fulfill performance obligations |  |  | — |  |  |  | 3,279 |  |  |  | — |  |
| Increase (decrease) due to customer billings |  |  | (5,929 | ) |  |  | — |  |  |  | 23,931 |  |
| Decrease due to cost recognition on completed performance obligations |  |  | — |  |  |  | (3,314 | ) |  |  | — |  |
| Increase (decrease) due to recognition of revenue based on transfer of control of performance obligations |  |  | 6,186 |  |  |  | — |  |  |  | (28,678 | ) |
| Other changes and FX impact |  |  | 0 |  |  |  | 18 |  |  |  | 561 |  |
| Ending balance as of September 30, 2020 |  | $ | 5,968 |  |  | $ | 1,614 |  |  | $ | 21,956 |  |

[0001437749-20-022522:notes:35]
|  |  | Unbilled Accounts Receivable |  |  | Deferred Program Costs |  |  | Contract Liabilities |  |
| Beginning balance as of March 31, 2019 |  | $ | 2,213 |  |  | $ | 318 |  |  | $ | 15,519 |  |
| Increases for costs incurred to fulfill performance obligations |  |  | — |  |  |  | 2,153 |  |  |  | — |  |
| Increase (decrease) due to customer billings |  |  | (2,926 | ) |  |  | — |  |  |  | 19,340 |  |
| Decrease due to cost recognition on completed performance obligations |  |  | — |  |  |  | (310 | ) |  |  | — |  |
| Increase (decrease) due to recognition of revenue based on transfer of control of performance obligations |  |  | 4,711 |  |  |  | — |  |  |  | (18,534 | ) |
| Other changes and FX impact |  |  | (4 | ) |  |  | (9 | ) |  |  | (313 | ) |
| Ending balance as of September 30, 2019 |  | $ | 3,994 |  |  | $ | 2,152 |  |  | $ | 16,012 |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001437749-20-022522:notes:36]
[same as prior period, unchanged from 0001437749-20-016667:notes:28]

[0001437749-20-022522:notes:37]
The Company accounted for its warrants as liabilities due to certain adjustment provisions within the instruments, which required that they be recorded at fair value. The warrants were subject to revaluation at each balance sheet date and any change in fair value was recorded as a change in fair value of warrants until the earlier of its expiration or its exercise at which time the warrant liability was reclassified to equity. The Company calculated the fair value of the warrants utilizing an integrated lattice model. See Note 
6,
 "Fair Value Measurements", for further discussion.  As of

[0001437749-20-022522:notes:38]
[same as prior period, unchanged from 0001437749-20-016667:notes:39]

[0001437749-20-022522:notes:39]
[same as prior period, unchanged from 0001437749-20-016667:notes:30]

[0001437749-20-022522:notes:40]
On 
 December 19, 2014, 
the Company entered into a 
second
 amendment to the Loan and Security Agreement with Hercules (the "Hercules Second Amendment"). In conjunction with the Hercules Second Amendment, the Company issued the Hercules Warrant which replaced the First Warrant and the Second Warrant.  The Hercules Warrant was exercisable at any time after its issuance at an exercise price of 
$7.85
 per share, subject to certain price-based and other anti-dilution adjustments, including the equity offering in 
 May 2017, 
the acquisition of Infinia Technology Corporation ("ITC") with common stock in 
 September 2017 
and sales of common stock under the ATM entered into in 
 January 2017.  
This warrant had a fair value of 
$0.4
 million as of 
 March 31, 2019.  
On 
 April 8, 2019, 
Hercules notified the Company of its intent to exercise this warrant on a cashless basis.  Hercules received 
22,821
 shares of the Company's common stock on 
 April 17, 2019.  
As a result of this exercise the Company recorded a net gain of 
$0.1
 million to change in fair value of warrants, resulting from the decrease in the fair value of the Hercules Warrant during the

[0001437749-20-022522:notes:41]
six

[0001437749-20-022522:notes:42]
[same as prior period, unchanged from 0001437749-20-016667:notes:33]

[0001437749-20-022522:notes:43]
[same as prior period, unchanged from 0001437749-20-016667:notes:35]

[0001437749-20-022522:notes:44]
[same as prior period, unchanged from 0001437749-20-016667:notes:36]

[0001437749-20-022522:notes:45]
On 
 November 13, 2014, 
the Company completed an offering of 
909,090
 units of the Company's common stock with Hudson Bay Capital. Each unit consisted of 
one
 share of the Company's common stock and 
0.9
 of a warrant to purchase 
one
 share of common stock, or a warrant to purchase in the aggregate 
818,181
 shares.  The Hudson Warrants were exercisable at any time, at an exercise price equal to 
$7.81
 per share, subject to certain price-based and other anti-dilution adjustments including those noted above.  On 
 November 13, 2019, 
Hudson partially exercised the Hudson Warrants for 
786,000
 restricted shares of Company common stock at 
$7.81
 per share
.  
The remaining 
32,181
 warrants expired on 
 November 13, 2019. 
The Company recorded net gains of 
$1.1
 million and 
$4.1
 million to change in fair value of warrants, resulting from the decrease in the fair value of the Hudson Warrants during the 
three
 and

[0001437749-20-022522:notes:46]
respectively.


## us-gaap:DisaggregationOfRevenueTableTextBlock

[0001437749-20-022522:notes:47]
|  |  | Three Months Ended September 30, 2020 |  |  | Six Months Ended September 30, 2020 |  |
| Product Line: |  | Grid |  |  | Wind |  |  | Grid |  |  | Wind |  |
| Equipment and systems |  | $ | 15,261 |  |  | $ | 4,059 |  |  | $ | 31,798 |  |  | $ | 6,676 |  |
| Services and technology development |  |  | 1,086 |  |  |  | 711 |  |  |  | 2,264 |  |  |  | 1,591 |  |
| Total |  | $ | 16,347 |  |  | $ | 4,770 |  |  | $ | 34,062 |  |  | $ | 8,267 |  |
| Region: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas |  | $ | 15,677 |  |  | $ | 30 |  |  | $ | 26,231 |  |  | $ | 42 |  |
| Asia Pacific |  |  | 370 |  |  |  | 4,734 |  |  |  | 6,385 |  |  |  | 8,002 |  |
| EMEA |  |  | 300 |  |  |  | 6 |  |  |  | 1,446 |  |  |  | 223 |  |
| Total |  | $ | 16,347 |  |  | $ | 4,770 |  |  | $ | 34,062 |  |  | $ | 8,267 |  |

[0001437749-20-022522:notes:48]
|  |  | Three Months Ended September 30, 2019 |  |  | Six Months Ended September 30, 2019 |  |
| Product Line: |  | Grid |  |  | Wind |  |  | Grid |  |  | Wind |  |
| Equipment and systems |  | $ | 10,044 |  |  | $ | 2,077 |  |  | $ | 18,399 |  |  | $ | 5,581 |  |
| Services and technology development |  |  | 1,445 |  |  |  | 446 |  |  |  | 2,946 |  |  |  | 856 |  |
| Total |  | $ | 11,489 |  |  | $ | 2,523 |  |  | $ | 21,345 |  |  | $ | 6,437 |  |
| Region: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas |  | $ | 10,698 |  |  | $ | 1 |  |  | $ | 18,499 |  |  | $ | 47 |  |
| Asia Pacific |  |  | 393 |  |  |  | 2,464 |  |  |  | 2,220 |  |  |  | 6,320 |  |
| EMEA |  |  | 398 |  |  |  | 58 |  |  |  | 626 |  |  |  | 70 |  |
| Total |  | $ | 11,489 |  |  | $ | 2,523 |  |  | $ | 21,345 |  |  | $ | 6,437 |  |


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001437749-20-022522:notes:49]
[same as prior period, unchanged from 0001437749-20-016667:notes:42]

[0001437749-20-022522:notes:50]
[same as prior period, unchanged from 0001437749-20-016667:notes:43]

[0001437749-20-022522:notes:51]
three
 and 
six

[0001437749-20-022522:notes:52]
[same as prior period, unchanged from 0001437749-20-016667:notes:44]

[0001437749-20-022522:notes:53]
[same as prior period, unchanged from 0001437749-20-016667:notes:45]

[0001437749-20-022522:notes:54]
|  |  | Three Months Ended September 30, |  |  | Six Months Ended September 30, |  |
|  |  | 2020 |  |  | 2019 |  |  | 2020 |  |  | 2019 |  |
| Cost of revenues |  | $ | 30 |  |  | $ | 21 |  |  | $ | 59 |  |  | $ | 24 |  |
| Research and development |  |  | 161 |  |  |  | 92 |  |  |  | 291 |  |  |  | 103 |  |
| Selling, general and administrative |  |  | 658 |  |  |  | 283 |  |  |  | 1,408 |  |  |  | 519 |  |
| Total |  | $ | 849 |  |  | $ | 397 |  |  | $ | 1,758 |  |  | $ | 646 |  |

[0001437749-20-022522:notes:55]
[same as prior period, unchanged from 0001437749-20-016667:notes:47]

[0001437749-20-022522:notes:56]
[same as prior period, unchanged from 0001437749-20-016667:notes:48]

[0001437749-20-022522:notes:57]
[same as prior period, unchanged from 0001437749-20-016667:notes:49]

[0001437749-20-022522:notes:58]
688,167

[0001437749-20-022522:notes:59]
[same as prior period, unchanged from 0001437749-20-016667:notes:51]

[0001437749-20-022522:notes:60]
[same as prior period, unchanged from 0001437749-20-016667:notes:52]

[0001437749-20-022522:notes:61]
170,500

[0001437749-20-022522:notes:62]
[same as prior period, unchanged from 0001437749-20-016667:notes:54]

[0001437749-20-022522:notes:63]
[same as prior period, unchanged from 0001437749-20-016667:notes:55]

[0001437749-20-022522:notes:64]
[same as prior period, unchanged from 0001437749-20-016667:notes:56]

[0001437749-20-022522:notes:65]
[same as prior period, unchanged from 0001437749-20-016667:notes:57]

[0001437749-20-022522:notes:66]
[same as prior period, unchanged from 0001437749-20-016667:notes:58]

[0001437749-20-022522:notes:67]
0.6

[0001437749-20-022522:notes:68]
[same as prior period, unchanged from 0001437749-20-016667:notes:60]

[0001437749-20-022522:notes:69]
5.9

[0001437749-20-022522:notes:70]
[same as prior period, unchanged from 0001437749-20-016667:notes:62]

[0001437749-20-022522:notes:71]
2.2

[0001437749-20-022522:notes:72]
[same as prior period, unchanged from 0001437749-20-016667:notes:64]

[0001437749-20-022522:notes:73]
The Company did

[0001437749-20-022522:notes:74]
not

[0001437749-20-022522:notes:75]
grant any stock options during the 
three
 or 
six
 months ended

[0001437749-20-022522:notes:76]
.  The Company granted 
5,939
 stock options during the

[0001437749-20-022522:notes:77]
[same as prior period, unchanged from 0001437749-20-016667:notes:69]

[0001437749-20-022522:notes:78]
[same as prior period, unchanged from 0001437749-20-016667:notes:70]

[0001437749-20-022522:notes:79]
[same as prior period, unchanged from 0001437749-20-016667:notes:71]

[0001437749-20-022522:notes:80]
[same as prior period, unchanged from 0001437749-20-016667:notes:72]

[0001437749-20-022522:notes:81]
|  |  | Three Months Ended September 30, |  |  | Six Months Ended September 30, |  |
|  |  | 2020 |  |  | 2019 |  |  | 2020 |  |  | 2019 |  |
| Expected volatility |  |  | N/A |  |  |  | N/A |  |  |  | N/A |  |  |  | 66.5 | % |
| Risk-free interest rate |  |  | N/A |  |  |  | N/A |  |  |  | N/A |  |  |  | 1.8 | % |
| Expected life (years) |  |  | N/A |  |  |  | N/A |  |  |  | N/A |  |  |  | 5.91 |  |
| Dividend yield |  |  | N/A |  |  |  | N/A |  |  |  | N/A |  |  | None |  |


## us-gaap:EarningsPerShareTextBlock

[0001437749-20-022522:notes:82]
[same as prior period, unchanged from 0001437749-20-016667:notes:74]

[0001437749-20-022522:notes:83]
Basic net loss per share (“EPS”) is computed by dividing net loss by the weighted-average number of common shares outstanding for the period. Where applicable, diluted EPS is computed by dividing the net loss by the weighted-average number of common shares and dilutive common equivalent shares outstanding during the period, calculated using the treasury stock method. Common equivalent shares include the effect of restricted stock, exercise of stock options and warrants and contingently issuable shares. Stock options and warrants that are out-of-the-money with exercise prices greater than the average market price of the underlying common shares and shares of performance based restricted stock where the contingency was 
not
 met are excluded from the computation of diluted EPS as the effect of their inclusion would be anti-dilutive.  For the 
three
 and 
six
 months ended

[0001437749-20-022522:notes:84]
[same as prior period, unchanged from 0001437749-20-016667:notes:76]

[0001437749-20-022522:notes:85]
million shares related to outstanding stock options were 
not
 included in the calculation of diluted EPS as they were considered anti-dilutive
.
 For the 
three
 and 
six
 months ended

[0001437749-20-022522:notes:86]
0.2

[0001437749-20-022522:notes:87]
million shares were 
not
 included in the calculation of diluted EPS as they were considered anti-dilutive.

[0001437749-20-022522:notes:88]
[same as prior period, unchanged from 0001437749-20-016667:notes:79]

[0001437749-20-022522:notes:89]
[same as prior period, unchanged from 0001437749-20-016667:notes:80]

[0001437749-20-022522:notes:90]
|  |  | Three Months Ended September 30, |  |  | Six Months Ended September 30, |  |
|  |  | 2020 |  |  | 2019 |  |  | 2020 |  |  | 2019 |  |
| Numerator: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net loss |  | $ | (3,712 | ) |  | $ | (825 | ) |  | $ | (7,129 | ) |  | $ | (4,364 | ) |
| Less: decrease in fair value of warrants, net of income tax |  |  | — |  |  |  | (1,145 | ) |  |  | — |  |  |  | (4,092 | ) |
| Plus: change in fair value due to exercise of warrants |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 83 |  |
| Net income (loss) - diluted |  | $ | (3,712 | ) |  | $ | (1,970 | ) |  | $ | (7,129 | ) |  | $ | (8,373 | ) |
| Denominator: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Weighted-average shares of common stock outstanding |  |  | 23,057 |  |  |  | 21,678 |  |  |  | 22,943 |  |  |  | 21,538 |  |
| Weighted-average shares subject to repurchase |  |  | (1,197 | ) |  |  | (1,022 | ) |  |  | (1,168 | ) |  |  | (952 | ) |
| Shares used in per-share calculation ― basic |  |  | 21,860 |  |  |  | 20,656 |  |  |  | 21,775 |  |  |  | 20,586 |  |
| Common stock warrants |  |  | — |  |  |  | 67 |  |  |  | — |  |  |  | 150 |  |
| Shares used in per-share calculation ― diluted |  |  | 21,860 |  |  |  | 20,723 |  |  |  | 21,775 |  |  |  | 20,736 |  |
| Net loss per share ― basic |  | $ | (0.17 | ) |  | $ | (0.04 | ) |  | $ | (0.33 | ) |  | $ | (0.21 | ) |
| Net loss per share ― diluted |  | $ | (0.17 | ) |  | $ | (0.10 | ) |  | $ | (0.33 | ) |  | $ | (0.40 | ) |

[0001437749-20-022522:notes:91]
For the

[0001437749-20-022522:notes:92]
, the diluted net loss per common share amounts under the treasury stock method were calculated based on the dilutive effect of the total number of shares of common stock related to the warrants issued to Hudson Bay Capital (the “Hudson Warrants”) for 
818,181
 shares with an exercise price of 
$7.81.
  For the 
three
 and 
six
 month periods ended 
 September 30, 2019, 
the average stock price was 
$8.50
 and 
$9.56
 respectively, providing 
66,638
 and 
150,025
 dilutive shares respectively, for the Hudson Warrants. The decrease in the fair value of the warrant liability of 
$1.1
 million and 
$4.1
 million, respectively, is included in the net loss available to common shareholders for the diluted net loss per common share amount when the impact is dilutive.


## us-gaap:FairValueDisclosuresTextBlock

[0001437749-20-022522:notes:93]
[same as prior period, unchanged from 0001437749-20-016667:notes:82]

[0001437749-20-022522:notes:94]
[same as prior period, unchanged from 0001437749-20-016667:notes:83]

[0001437749-20-022522:notes:95]
[same as prior period, unchanged from 0001437749-20-016667:notes:84]

[0001437749-20-022522:notes:96]
[same as prior period, unchanged from 0001437749-20-016667:notes:85]

[0001437749-20-022522:notes:97]
[same as prior period, unchanged from 0001437749-20-016667:notes:86]

[0001437749-20-022522:notes:98]
[same as prior period, unchanged from 0001437749-20-016667:notes:87]

[0001437749-20-022522:notes:99]
[same as prior period, unchanged from 0001437749-20-016667:notes:88]

[0001437749-20-022522:notes:100]
[same as prior period, unchanged from 0001437749-20-016667:notes:89]

[0001437749-20-022522:notes:101]
[same as prior period, unchanged from 0001437749-20-016667:notes:90]

[0001437749-20-022522:notes:102]
Marketable securities consist of certificates of deposit that are measured using such inputs as quoted prices and are classified within Level 
1
 of the valuation hierarchy. The Company determines the appropriate classification of its marketable securities at the time of purchase and re-evaluates such classification as of each balance sheet date.  All marketable securities are considered available for sale and are carried at fair value.   Changes in fair value are recorded to other income (expense), net.  The Company recognized 
$0.2
 million and 
$0.1
 million in unrealized losses on marketable securities, which is recorded in other income (expense), net, for the

[0001437749-20-022522:notes:103]
months ended

[0001437749-20-022522:notes:104]
and less than a

[0001437749-20-022522:notes:105]
million gain which was recognized during the 
three
 and 
six
 months ended 
 September 30, 2020 
upon the sale of 
one
 of the certificates of deposit.  The Company did

[0001437749-20-022522:notes:106]
recognize any gains or losses on marketable securities in the

[0001437749-20-022522:notes:107]
. 
 The Company periodically reviews the realizability of each short and long term marketable security when impairment indicators exist with respect to the security.  If other than temporary impairment of value of the security exists, the carrying value of the security is written down to its estimated fair value.

[0001437749-20-022522:notes:108]
[same as prior period, unchanged from 0001437749-20-016667:notes:94]

[0001437749-20-022522:notes:109]
The Company issued the Hudson Warrants in conjunction with an equity offering to Hudson Bay Capital in 
 November 2014 
and issued warrants to purchase 
58,823
 shares of the Company's common stock in conjunction a Loan and Security Agreement with Hercules Technology Growth Capital, Inc. (“Hercules Warrants”). The Hercules Warrants were exercised on 
 April 8, 2019.  
The Hudson Warrants were partially exercised on 
 November 13, 2019 
and the remaining unexercised warrants expired on 
 November 13, 2019.  
As of

[0001437749-20-022522:notes:110]
[same as prior period, unchanged from 0001437749-20-016667:notes:96]

[0001437749-20-022522:notes:111]
[same as prior period, unchanged from 0001437749-20-016667:notes:97]

[0001437749-20-022522:notes:112]
[same as prior period, unchanged from 0001437749-20-016667:notes:98]

[0001437749-20-022522:notes:113]
|  |  | Total Carrying Value |  |  | Quoted Prices in Active Markets (Level 1) |  |  | Significant Other Observable Inputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |
| September 30, 2020: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash equivalents |  | $ | 35,613 |  |  | $ | 35,613 |  |  | $ | — |  |  | $ | — |  |
| Marketable securities |  | $ | 10,191 |  |  | $ | 10,191 |  |  | $ | — |  |  | $ | — |  |

[0001437749-20-022522:notes:114]
[same as prior period, unchanged from 0001437749-20-016667:notes:100]


## us-gaap:GoodwillDisclosureTextBlock

[0001437749-20-022522:notes:115]
[same as prior period, unchanged from 0001437749-20-016667:notes:101]

[0001437749-20-022522:notes:116]
[same as prior period, unchanged from 0001437749-20-016667:notes:102]

[0001437749-20-022522:notes:117]
[same as prior period, unchanged from 0001437749-20-016667:notes:103]


## us-gaap:IncomeTaxDisclosureTextBlock

[0001437749-20-022522:notes:118]
[same as prior period, unchanged from 0001437749-20-016667:notes:104]

[0001437749-20-022522:notes:119]
[same as prior period, unchanged from 0001437749-20-016667:notes:105]

[0001437749-20-022522:notes:120]
million and $

[0001437749-20-022522:notes:121]
0.4

[0001437749-20-022522:notes:122]
million in the

[0001437749-20-022522:notes:123]
month periods ended

[0001437749-20-022522:notes:124]
.  
The Company recorded income tax benefits of 
$0.3
 million and 
$0.1
 million in the

[0001437749-20-022522:notes:125]
Accounting for income taxes requires a 
two
-step approach to recognizing and measuring uncertain tax positions.  The 
first
 step is to evaluate the tax position for recognition by determining if, based on the technical merits, it is more likely than 
not
 the position will be sustained upon audit, including resolution of related appeals or litigation processes, if any.  The 
second
 step is to measure the tax benefit as the largest amount that is more than 
50%
 likely to be realized upon ultimate settlement.  The Company re-evaluates these uncertain tax positions on a quarterly basis.  The evaluation is based on factors including, but 
not
 limited to, changes in facts or circumstances, changes in tax law, effectively settled issues under audit and new audit activity.  Any changes in these factors could result in the recognition of a tax benefit or an additional charge to the tax provision.  The Company did 
not
 identify any uncertain tax positions in the

[0001437749-20-022522:notes:126]
[same as prior period, unchanged from 0001437749-20-016667:notes:109]


## us-gaap:InventoryDisclosureTextBlock

[0001437749-20-022522:notes:127]
[same as prior period, unchanged from 0001437749-20-016667:notes:110]

[0001437749-20-022522:notes:128]
[same as prior period, unchanged from 0001437749-20-016667:notes:111]

[0001437749-20-022522:notes:129]
|  |  | September 30, 2020 |  |  | March 31, 2020 |  |
| Raw materials |  | $ | 4,989 |  |  | $ | 10,739 |  |
| Work-in-process |  |  | 2,283 |  |  |  | 1,345 |  |
| Finished goods |  |  | 5,269 |  |  |  | 5,260 |  |
| Deferred program costs |  |  | 1,614 |  |  |  | 1,631 |  |
| Net inventory |  | $ | 14,155 |  |  | $ | 18,975 |  |

[0001437749-20-022522:notes:130]
[same as prior period, unchanged from 0001437749-20-016667:notes:113]

[0001437749-20-022522:notes:131]
[same as prior period, unchanged from 0001437749-20-016667:notes:115]

[0001437749-20-022522:notes:132]
, respectively.  The Company recorded inventory write-downs of $

[0001437749-20-022522:notes:133]
1.3

[0001437749-20-022522:notes:134]
million and 
$0.2
 million for the

[0001437749-20-022522:notes:135]
[same as prior period, unchanged from 0001437749-20-016667:notes:116]

[0001437749-20-022522:notes:136]
[same as prior period, unchanged from 0001437749-20-016667:notes:117]

[0001437749-20-022522:notes:137]
[same as prior period, unchanged from 0001437749-20-016667:notes:118]


## us-gaap:LeaseCostTableTextBlock

[0001437749-20-022522:notes:138]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | September 30, 2020 |  |  | September 30, 2020 |  |
| Operating Leases: |  |  |  |  |  |  |  |  |
| Operating lease costs - fixed |  | $ | 214 |  |  | $ | 392 |  |
| Operating lease costs - variable |  |  | 28 |  |  |  | 55 |  |
| Short-term lease costs |  |  | 510 |  |  |  | 678 |  |
| Total lease costs |  |  | 752 |  |  |  | 1,125 |  |

[0001437749-20-022522:notes:139]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | September 30, 2019 |  |  | September 30, 2019 |  |
| Operating Leases: |  |  |  |  |  |  |  |  |
| Operating lease costs - fixed |  | $ | 178 |  |  | $ | 356 |  |
| Operating lease costs - variable |  |  | 27 |  |  |  | 46 |  |
| Short-term lease costs |  |  | 176 |  |  |  | 214 |  |
| Total lease costs |  |  | 381 |  |  |  | 616 |  |


## us-gaap:LesseeOperatingLeaseLiabilityMaturityTableTextBlock

[0001437749-20-022522:notes:140]
|  |  | Operating Leases |  |
| Year ended March 31, |  |  |  |  |
| 2021 |  | $ | 416 |  |
| 2022 |  |  | 791 |  |
| 2023 |  |  | 764 |  |
| 2024 |  |  | 709 |  |
| 2025 |  |  | 647 |  |
| Thereafter |  |  | 1,597 |  |
| Total minimum lease payments |  |  | 4,924 |  |
| Less: interest |  |  | 927 |  |
| Present value of lease liabilities |  |  | 3,997 |  |


## us-gaap:LesseeOperatingLeasesTextBlock

[0001437749-20-022522:notes:141]
[same as prior period, unchanged from 0001437749-20-016667:notes:121]

[0001437749-20-022522:notes:142]
[same as prior period, unchanged from 0001437749-20-016667:notes:122]

[0001437749-20-022522:notes:143]
[same as prior period, unchanged from 0001437749-20-016667:notes:123]

[0001437749-20-022522:notes:144]
[same as prior period, unchanged from 0001437749-20-016667:notes:124]

[0001437749-20-022522:notes:145]
The Company also enters into leases for vehicles, IT equipment and service agreements, and other leases related to its manufacturing operations that are also included in the right-of-use assets and lease liability accounts if they are for a term of longer than 
twelve
 months. However, many of these leases are either short-term in nature or immaterial. The Company has made the policy election to exclude short-term leases from the balance sheet.

[0001437749-20-022522:notes:146]
[same as prior period, unchanged from 0001437749-20-016667:notes:126]

[0001437749-20-022522:notes:147]
[same as prior period, unchanged from 0001437749-20-016667:notes:127]

[0001437749-20-022522:notes:148]
[same as prior period, unchanged from 0001437749-20-016667:notes:128]

[0001437749-20-022522:notes:149]
[same as prior period, unchanged from 0001437749-20-016667:notes:129]

[0001437749-20-022522:notes:150]
[same as prior period, unchanged from 0001437749-20-016667:notes:130]


## us-gaap:NewAccountingPronouncementsAndChangesInAccountingPrinciplesTextBlock

[0001437749-20-022522:notes:151]
16.
 Recent Accounting Pronouncements

[0001437749-20-022522:notes:152]
In 
 June 2016, 
the FASB issued ASU 
2016
-
13,

[0001437749-20-022522:notes:153]
Financial Instruments-Credit Losses (Topic 
326
): Measurement of Credit Losses on Financial Instruments
. The amendments in ASU 
2016
-
13
 will provide more decision-useful information about the expected credit losses on financial instruments and other commitments to extend credit held by a reporting entity at each reporting date. The ASU is effective for annual reporting periods beginning after 
 December 15, 2019, 
including interim periods within that year.  Following the release of ASU 
2019
-
10
 in 
 November 2019, 
the new effective date, as long as the Company remains a smaller reporting company, would be annual reporting periods beginning after 
 December 15, 2022.  
The Company is currently evaluating the impact, if any, that the adoption of ASU 
2016
-
13

[0001437749-20-022522:notes:154]
may 
have on its consolidated financial statements.

[0001437749-20-022522:notes:155]
In 
 August 2018, 
the FASB issued ASU 
2018
-
13,

[0001437749-20-022522:notes:156]
Fair Value Measurement (Topic 
820
): Changes to the Disclosure Requirements for Fair Value Measurement
. The amendments in ASU 
2018
-
13
 provide for increased effectiveness of the disclosures made around fair value measurements while including consideration for costs and benefits. The ASU is effective for annual reporting periods beginning after 
 December 15, 2019, 
including interim periods within those periods. As of 
 April 1, 2020, 
the Company has adopted ASU 
2018
-
13
 and noted 
no
 material impact on its consolidated financial statements, primarily due to the fact that the Company does 
not
 currently report any Level 
3
 fair value measurements.

[0001437749-20-022522:notes:157]
In 
 December 2019, 
the FASB issued ASU 
2019
-
12,

[0001437749-20-022522:notes:158]
Income Taxes (Topic 
740
): Simplifying the Accounting for Income Taxes
. The amendments in ASU 
2019
-
12
 provide for simplified accounting to several income tax situations and removal of certain accounting exceptions. The ASU is effective for annual reporting periods beginning after 
 December 15, 2020, 
including interim periods within those periods. The Company does 
not
 expect the impact of the adoption of ASU 
2019
-
12
 to be material to its consolidated financial statements.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0001437749-20-022522:notes:159]
[same as prior period, unchanged from 0001437749-20-016667:notes:139]

[0001437749-20-022522:notes:160]
[same as prior period, unchanged from 0001437749-20-016667:notes:140]

[0001437749-20-022522:notes:161]
[same as prior period, unchanged from 0001437749-20-016667:notes:141]

[0001437749-20-022522:notes:162]
[same as prior period, unchanged from 0001437749-20-016667:notes:142]

[0001437749-20-022522:notes:163]
[same as prior period, unchanged from 0001437749-20-016667:notes:143]

[0001437749-20-022522:notes:164]
[same as prior period, unchanged from 0001437749-20-016667:notes:144]

[0001437749-20-022522:notes:165]
[same as prior period, unchanged from 0001437749-20-016667:notes:145]

[0001437749-20-022522:notes:166]
[same as prior period, unchanged from 0001437749-20-016667:notes:146]

[0001437749-20-022522:notes:167]
[same as prior period, unchanged from 0001437749-20-016667:notes:147]

[0001437749-20-022522:notes:168]
[same as prior period, unchanged from 0001437749-20-016667:notes:148]

[0001437749-20-022522:notes:169]
[same as prior period, unchanged from 0001437749-20-016667:notes:149]

[0001437749-20-022522:notes:170]
[same as prior period, unchanged from 0001437749-20-016667:notes:150]

[0001437749-20-022522:notes:171]
[same as prior period, unchanged from 0001437749-20-016667:notes:151]

[0001437749-20-022522:notes:172]
985.8

[0001437749-20-022522:notes:173]
[same as prior period, unchanged from 0001437749-20-016667:notes:153]

[0001437749-20-022522:notes:174]
[same as prior period, unchanged from 0001437749-20-016667:notes:154]

[0001437749-20-022522:notes:175]
51.4

[0001437749-20-022522:notes:176]
million. Marketable securities include certificate of deposits with maturities between 
six
 and 
eleven
 months.  Cash used in operations for the

[0001437749-20-022522:notes:177]
[same as prior period, unchanged from 0001437749-20-016667:notes:157]

[0001437749-20-022522:notes:178]
6.6

[0001437749-20-022522:notes:179]
[same as prior period, unchanged from 0001437749-20-016667:notes:159]

[0001437749-20-022522:notes:180]
In 
 December 2015, 
the Company entered into a set of strategic agreements valued at approximately 
$210.0
 million with Inox Wind Ltd. (“Inox” or “Inox Wind”), which includes a multi-year supply contract pursuant to which the Company will supply electrical control systems ("ECS") to Inox and a license agreement allowing Inox to manufacture a limited number of ECS. After Inox purchases the specified number of ECS required under the terms of the supply contract, Inox agreed that the Company will continue as Inox's preferred supplier and Inox will be required to purchase from the Company a majority of its ECS requirements for an additional 
three
-year period. Pursuant to these strategic agreements, Inox must forecast future purchase orders of sets of ECS which become firm orders 
three
 months prior to shipment, and Inox must post letters of credit before the Company will ship such orders. Inox had been delinquent on its obligation to post letters of credit for sets of ECS that Inox forecasted to purchase under the terms of the supply contract.  On 
 May 29, 2020, 
the Company sent written notice to Inox notifying Inox of its default under the supply contract due to Inox's failure to post letters of credit in the amount of 
€6.0
 million for the payment of ECS that Inox is obligated to purchase under the terms of the supply contract.  If Inox failed to post letters of credit in the amount of 
€6.0
 million in accordance with the terms of the supply contract within the 
ninety
 day cure period after receipt of the default notice, then the Company could have terminated the supply contract by providing written notice of such termination to Inox.  On 
 September 2, 2020, 
Inox delivered approved letters of credit in the amount of 
€1.3
 million for the payment of a portion of the ECS that Inox was obligated to purchase under the terms of the supply contract.  On 
 September 11, 2020, 
the Company notified Inox that due to (i) the Company's business relationship with Inox, and (ii) Inox's delivery of approved letters of credit in the amount of 
€1.3
 million as described above, the Company gave Inox until 
 October 5, 2020 
to regain compliance with the terms of the supply contract by providing approved letters of credit in the amount of 
€4.7
 million for payment of the remaining ECS that Inox currently was obligated to purchase under the terms of the supply contract.  On 
 October 1, 2020, 
Inox delivered approved letters of credit for payment of the remaining ECS that Inox was obligated to purchase under the terms of the supply contract and cured the default set forth in the 
 May 29, 2020 
default notice.

[0001437749-20-022522:notes:181]
On 
 October 1, 2020, 
the Company entered into a Stock Purchase Agreement (the “Stock Purchase Agreement”) with the selling stockholders named therein.  Pursuant to the terms of the Stock Purchase Agreement and concurrently with entering into such agreement, the Company acquired all of the issued and outstanding (i) shares of capital stock of Northeast Power Systems, Inc., a New York corporation (“NEPSI”), and (ii) membership interests of Northeast Power Realty, LLC, a New York limited liability company, which holds the real property that serves as NEPSI's headquarters. NEPSI is a U.S.-based global provider of medium-voltage metal-enclosed power capacitor banks and harmonic filter banks for use on electric power systems. NEPSI is now a wholly-owned subsidiary of the Company and will be operated by its Grid business unit. The purchase price was 
$26.0
 million in cash and 
873,657
 restricted shares of common stock of the Company.  As part of the transaction, the selling stockholders 
 may 
receive up to an additional 
1,000,000
 shares of common stock of the Company upon the achievement of certain specified revenue objectives in the future.

[0001437749-20-022522:notes:182]
On 
 October 22, 2020, 
the Company entered into an underwriting agreement with Oppenheimer & Co. Inc., as representative of the several underwriters named therein, relating to the issuance and sale (the “Offering”) of 
3,670,000
 shares of the Company's common stock at a public offering price of 
$15.00
 per share. The net proceeds to the Company from the Offering were approximately 
$51.4
 million, after deducting underwriting discounts and commissions and estimated offering expenses payable by the Company. The Offering closed on 
 October 26, 2020. 
In addition, the Company has granted the underwriters a 
30
-day option to purchase up to an additional 
550,500
 shares of common stock at the public offering price.

[0001437749-20-022522:notes:183]
[same as prior period, unchanged from 0001437749-20-016667:notes:161]

[0001437749-20-022522:notes:184]
[same as prior period, unchanged from 0001437749-20-016667:notes:162]

[0001437749-20-022522:notes:185]
[same as prior period, unchanged from 0001437749-20-016667:notes:163]

[0001437749-20-022522:notes:186]
[same as prior period, unchanged from 0001437749-20-016667:notes:164]


## us-gaap:PropertyPlantAndEquipmentDisclosureTextBlock

[0001437749-20-022522:notes:187]
[same as prior period, unchanged from 0001437749-20-016667:notes:165]

[0001437749-20-022522:notes:188]
[same as prior period, unchanged from 0001437749-20-016667:notes:166]

[0001437749-20-022522:notes:189]
[same as prior period, unchanged from 0001437749-20-016667:notes:167]

[0001437749-20-022522:notes:190]
|  |  | September 30, 2020 |  |  | March 31, 2020 |  |
| Construction in progress - equipment |  | $ | 718 |  |  | $ | 3,130 |  |
| Equipment and software |  |  | 42,015 |  |  |  | 41,737 |  |
| Furniture and fixtures |  |  | 1,326 |  |  |  | 1,302 |  |
| Leasehold improvements |  |  | 6,114 |  |  |  | 2,477 |  |
| Property, plant and equipment, gross |  |  | 50,173 |  |  |  | 48,646 |  |
| Less accumulated depreciation |  |  | (42,033 | ) |  |  | (40,081 | ) |
| Property, plant and equipment, net |  | $ | 8,140 |  |  | $ | 8,565 |  |

[0001437749-20-022522:notes:191]
[same as prior period, unchanged from 0001437749-20-016667:notes:169]

[0001437749-20-022522:notes:192]
0.9

[0001437749-20-022522:notes:193]
million and 
$1.0
 million for the 
three
 months ended

[0001437749-20-022522:notes:194]
, respectively. Depreciation expense was $

[0001437749-20-022522:notes:195]
1.8

[0001437749-20-022522:notes:196]
million and 
$2.1
 million for the

[0001437749-20-022522:notes:197]
, respectively.  The decrease in construction in progress primarily relates to the completion of capital investments in the Company's HTS equipment and leasehold improvements in the Company's leased facilities in Westminster and Ayer, Massachusetts.


## us-gaap:ReconciliationOfAssetsFromSegmentToConsolidatedTextBlock

[0001437749-20-022522:notes:198]
|  |  | September 30, 2020 |  |  | March 31, 2020 |  |
| Grid |  | $ | 40,358 |  |  | $ | 44,044 |  |
| Wind |  |  | 11,760 |  |  |  | 14,250 |  |
| Corporate assets |  |  | 59,109 |  |  |  | 65,815 |  |
| Total |  | $ | 111,227 |  |  | $ | 124,109 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001437749-20-022522:notes:199]
[same as prior period, unchanged from 0001437749-20-016667:notes:173]

[0001437749-20-022522:notes:200]
[same as prior period, unchanged from 0001437749-20-016667:notes:174]

[0001437749-20-022522:notes:201]
[same as prior period, unchanged from 0001437749-20-016667:notes:175]

[0001437749-20-022522:notes:202]
[same as prior period, unchanged from 0001437749-20-016667:notes:178]

[0001437749-20-022522:notes:203]
[same as prior period, unchanged from 0001437749-20-016667:notes:177]

[0001437749-20-022522:notes:204]
79

[0001437749-20-022522:notes:205]
% of revenue, respectively, was recognized at the point in time when control transferred to the customer, with the remainder being recognized over time.  In both the 
three
 and 
six
 months ended

[0001437749-20-022522:notes:206]
77%

[0001437749-20-022522:notes:207]
of revenue was recognized at the point in time when control transferred to the customer, with the remainder being recognized over time.

[0001437749-20-022522:notes:208]
[same as prior period, unchanged from 0001437749-20-016667:notes:180]

[0001437749-20-022522:notes:209]
The Company's equipment and system product line includes certain contracts which do 
not
 meet the requirements of an exchange transaction and therefore do 
not
 fall within the scope of ASC 
606.
  As these non-exchange transaction contracts are considered grant revenue and do 
not
 fall within any specific accounting literature, the Company follows guidance within ASC 
606
 by analogy to recognize grant revenue over time.  In the

[0001437749-20-022522:notes:210]
three
 and 
six
 months ended 
 September 30, 2020

[0001437749-20-022522:notes:211]
[same as prior period, unchanged from 0001437749-20-016667:notes:183]

[0001437749-20-022522:notes:212]
0.8

[0001437749-20-022522:notes:213]
million in grant revenue, respectively, which is included in the Company's Grid segment revenue.  In the 
three
 and 
six
 months ended

[0001437749-20-022522:notes:214]
, the Company recorded 
$0.7
 million and 
$1.1
 million in grant revenue, respectively, which is included in the Company's Grid revenue.

[0001437749-20-022522:notes:215]
[same as prior period, unchanged from 0001437749-20-016667:notes:186]

[0001437749-20-022522:notes:216]
[same as prior period, unchanged from 0001437749-20-016667:notes:187]

[0001437749-20-022522:notes:217]
[same as prior period, unchanged from 0001437749-20-016667:notes:188]

[0001437749-20-022522:notes:218]
[same as prior period, unchanged from 0001437749-20-016667:notes:189]

[0001437749-20-022522:notes:219]
[same as prior period, unchanged from 0001437749-20-016667:notes:190]

[0001437749-20-022522:notes:220]
[same as prior period, unchanged from 0001437749-20-016667:notes:191]

[0001437749-20-022522:notes:221]
[same as prior period, unchanged from 0001437749-20-016667:notes:192]

[0001437749-20-022522:notes:222]
, and

[0001437749-20-022522:notes:223]
[same as prior period, unchanged from 0001437749-20-016667:notes:194]

[0001437749-20-022522:notes:224]
[same as prior period, unchanged from 0001437749-20-016667:notes:195]

[0001437749-20-022522:notes:225]
[same as prior period, unchanged from 0001437749-20-016667:notes:196]

[0001437749-20-022522:notes:226]
48.5

[0001437749-20-022522:notes:227]
[same as prior period, unchanged from 0001437749-20-016667:notes:198]

[0001437749-20-022522:notes:228]
10.7

[0001437749-20-022522:notes:229]
[same as prior period, unchanged from 0001437749-20-016667:notes:200]

[0001437749-20-022522:notes:230]
three
 months of a 
twelve
-month rolling forecast. The timing of the performance obligations beyond the 
twelve
-month forecast provided by Inox are 
not
 determinable and therefore are 
not
 included in the total remaining performance obligations.

[0001437749-20-022522:notes:231]
[same as prior period, unchanged from 0001437749-20-016667:notes:202]

[0001437749-20-022522:notes:232]
[same as prior period, unchanged from 0001437749-20-016667:notes:203]

[0001437749-20-022522:notes:233]
|  |  |  | Three Months Ended |  |  | Six Months Ended |  |
|  | Reportable |  | September 30, |  |  | September 30, |  |
|  | Segment |  | 2020 |  |  | 2019 |  |  | 2020 |  |  | 2019 |  |
| EPC Services | Grid |  |  | 12 | % |  |  | 0 | % |  |  | 18 | % |  |  | 0 | % |
| Hoffman Construction | Grid |  |  | <10% |  |  |  | 25 | % |  |  | <10% |  |  |  | 12 | % |
| Inox Wind Limited | Wind |  |  | <10% |  |  |  | <10% |  |  |  | <10% |  |  |  | 17 | % |
| M.J. Electric, LLC | Grid |  |  | <10% |  |  |  | 25 | % |  |  | <10% |  |  |  | 13 | % |
| Micron Technology | Grid |  |  | <10% |  |  |  | <10% |  |  |  | <10% |  |  |  | 14 | % |
| Reed & Reed Inc. | Grid |  |  | 25 | % |  |  | 0 | % |  |  | 12 | % |  |  | 0 | % |
| Siemens Gamesa Renewable Energy Pty. Ltd. | Grid |  |  | <10% |  |  |  | 0 | % |  |  | 13 | % |  |  | 0 | % |


## us-gaap:ScheduleOfSegmentReportingInformationBySegmentTextBlock

[0001437749-20-022522:notes:234]
|  |  | Three Months Ended September 30, |  |  | Six Months Ended September 30, |  |
|  |  | 2020 |  |  | 2019 |  |  | 2020 |  |  | 2019 |  |
| Revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Grid |  | $ | 16,347 |  |  | $ | 11,489 |  |  | $ | 34,062 |  |  | $ | 21,345 |  |
| Wind |  |  | 4,770 |  |  |  | 2,523 |  |  |  | 8,267 |  |  |  | 6,437 |  |
| Total |  | $ | 21,117 |  |  | $ | 14,012 |  |  | $ | 42,329 |  |  | $ | 27,782 |  |

[0001437749-20-022522:notes:235]
|  |  | Three Months Ended September 30, |  |  | Six Months Ended September 30, |  |
|  |  | 2020 |  |  | 2019 |  |  | 2020 |  |  | 2019 |  |
| Operating loss: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Grid |  | $ | (1,374 | ) |  | $ | (1,324 | ) |  | $ | (2,562 | ) |  | $ | (5,988 | ) |
| Wind |  |  | (983 | ) |  |  | (2,398 | ) |  |  | (2,103 | ) |  |  | (3,721 | ) |
| Unallocated corporate expenses |  |  | (849 | ) |  |  | (397 | ) |  |  | (1,758 | ) |  |  | (646 | ) |
| Total |  | $ | (3,206 | ) |  | $ | (4,119 | ) |  | $ | (6,423 | ) |  | $ | (10,355 | ) |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001437749-20-022522:notes:236]
[same as prior period, unchanged from 0001437749-20-016667:notes:207]

[0001437749-20-022522:notes:237]
[same as prior period, unchanged from 0001437749-20-016667:notes:208]

[0001437749-20-022522:notes:238]
[same as prior period, unchanged from 0001437749-20-016667:notes:209]

[0001437749-20-022522:notes:239]
[same as prior period, unchanged from 0001437749-20-016667:notes:210]

[0001437749-20-022522:notes:240]
[same as prior period, unchanged from 0001437749-20-016667:notes:211]

[0001437749-20-022522:notes:241]
[same as prior period, unchanged from 0001437749-20-016667:notes:212]

[0001437749-20-022522:notes:242]
[same as prior period, unchanged from 0001437749-20-016667:notes:213]

[0001437749-20-022522:notes:243]
[same as prior period, unchanged from 0001437749-20-016667:notes:214]

[0001437749-20-022522:notes:244]
$0.4

[0001437749-20-022522:notes:245]
[same as prior period, unchanged from 0001437749-20-016667:notes:216]

[0001437749-20-022522:notes:246]
, respectively.  Unallocated corporate expenses primarily consist of stock-based compensation expense of $

[0001437749-20-022522:notes:247]
million and 
$0.6
 million in the

[0001437749-20-022522:notes:248]
[same as prior period, unchanged from 0001437749-20-016667:notes:217]

[0001437749-20-022522:notes:249]
[same as prior period, unchanged from 0001437749-20-016667:notes:218]


## us-gaap:SubsequentEventsTextBlock

[0001437749-20-022522:notes:250]
17.
 Subsequent Events

[0001437749-20-022522:notes:251]
The Company has performed an evaluation of subsequent events through the time of filing this Quarterly Report on Form 
10
-Q with the SEC and has determined that other than the following information, there are 
no
 such events to report.

[0001437749-20-022522:notes:252]
On 
 October 1, 2020, 
the Company entered into the Stock Purchase Agreement with the selling stockholders named therein.  Pursuant to the terms of the Stock Purchase Agreement and concurrently with entering into such agreement, the Company acquired all of the issued and outstanding (i) shares of capital stock of NEPSI, and (ii) membership interests of Northeast Power Realty, LLC, a New York limited liability company, which holds the real property that serves as NEPSI's headquarters.  NEPSI is a U.S.-based global provider of medium-voltage metal-enclosed power capacitor banks and harmonic filter banks for use on electric power systems. NEPSI is now a wholly-owned subsidiary of the Company and will be operated by the Grid business unit. The NEPSI purchase price was 
$26.0
 million in cash on hand, including cash from the settlement of the Company's 
$25
 million certificate of deposit during the 
three
 months ended 
 September 30, 2020, 
and 
873,657
 restricted shares of common stock of the Company.  The transaction also includes an earn-out opportunity with the potential for the issuance of up to an additional 
1.0
 million shares of common stock of the Company to the selling stockholders based on the achievement by NEPSI of certain revenue targets for the fiscal years ending 
 March 31, 2021 
through 
 March 31, 2024. 
The Company assumed 
no
 debt in this transaction. NEPSI's results of operations will be included in the Company's consolidated financial statements beginning on 
 October 1, 2020.

[0001437749-20-022522:notes:253]
On 
 October 26, 2020, 
the Company completed the Offering of 
3,670,000
 shares of common stock of the Company at a public offering price of 
$15.00
 per share.  The net proceeds to the Company from the Offering were approximately 
$51.4
 million, after deducting underwriting discounts and commissions and estimated offering expenses payable by the Company. In addition, the Company has granted the underwriters a 
30
-day option to purchase up to an additional 
550,500
 shares of common stock at the public offering price.
