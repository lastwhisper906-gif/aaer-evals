# AMSC 8-K — 0001437749-25-023965 filed 2025-07-30

## item codes, every 8-K on or before 2025-07-30

- 2025-07-30 0001437749-25-023965 — 2.02, 9.01
- 2025-07-29 0001437749-25-023783 — 5.07, 9.01
- 2025-06-11 0001193125-25-139243 — 8.01, 9.01
- 2025-05-21 0001437749-25-017983 — 2.02, 5.02, 9.01
- 2025-02-05 0001437749-25-002901 — 2.02, 5.03, 9.01
- 2024-10-30 0001437749-24-032617 — 2.02, 9.01
- 2024-08-13 0001193125-24-199141 — 8.01, 9.01
- 2024-08-06 0001437749-24-024924 — 9.01 — amendment of 0001193125-24-193425
- 2024-08-06 0001437749-24-024881 — 2.02, 9.01
- 2024-08-05 0001193125-24-193965 — 5.02, 5.07, 9.01
- 2024-08-05 0001193125-24-193425 — 1.01, 2.01, 8.01, 9.01
- 2024-05-29 0001437749-24-018599 — 2.02, 5.02, 9.01
- 2024-01-31 0001193125-24-020938 — 8.01, 9.01
- 2024-01-24 0001437749-24-002040 — 2.02, 9.01
- 2023-11-01 0001437749-23-029749 — 2.02, 9.01
- 2023-08-11 0001437749-23-023329 — 5.07
- 2023-08-09 0001437749-23-022786 — 2.02, 9.01
- 2023-06-21 0001193125-23-171201 — 5.02, 9.01
- 2023-05-31 0001437749-23-016264 — 2.02, 9.01
- 2023-02-01 0001437749-23-002268 — 2.02, 9.01
- 2022-11-01 0001437749-22-025365 — 2.02, 9.01
- 2022-08-05 0001193125-22-213651 — 5.02, 5.07, 9.01
- 2022-08-03 0001437749-22-018628 — 2.02, 9.01
- 2022-06-10 0001437749-22-014780 — 5.02, 9.01
- 2022-06-01 0001437749-22-014033 — 2.02, 9.01
- 2022-02-02 0001437749-22-002207 — 2.02, 9.01
- 2021-11-08 0001437749-21-025697 — 2.02, 9.01
- 2021-08-04 0001437749-21-018522 — 2.02, 9.01
- 2021-08-02 0001193125-21-233260 — 5.07
- 2021-06-02 0001437749-21-013955 — 2.02, 9.01
- 2021-05-25 0001437749-21-013279 — 5.02, 9.01
- 2021-05-21 0001193125-21-168626 — 8.01, 9.01
- 2021-05-10 0001193125-21-156251 — 1.01, 9.01
- 2021-02-26 0001193125-21-060434 — 8.01, 9.01
- 2021-02-03 0001437749-21-001859 — 2.02, 9.01
- 2021-02-01 0001437749-21-001681 — 5.03, 9.01
- 2020-12-14 0001437749-20-025291 — 9.01 — amendment, the index does not say of what
- 2020-11-04 0001437749-20-022520 — 2.02, 9.01
- 2020-10-26 0001193125-20-276900 — 8.01, 9.01
- 2020-10-05 0001437749-20-020735 — 2.02
- 2020-10-05 0001437749-20-020734 — 1.01, 2.01, 3.02, 9.01
- 2020-10-02 0001437749-20-020660 — 8.01
- 2020-09-16 0001437749-20-019767 — 8.01
- 2020-08-05 0001437749-20-016665 — 2.02, 5.07, 9.01
- 2020-06-02 0001437749-20-012274 — 2.02, 9.01
- 2020-05-27 0001437749-20-011837 — 5.02, 9.01
- 2020-02-05 0001437749-20-001788 — 2.02, 9.01
- 2019-11-05 0001437749-19-021590 — 2.02, 9.01
- 2019-08-06 0001437749-19-015631 — 2.02, 9.01
- 2019-08-06 0001193125-19-214189 — 5.02, 5.07, 9.01
- 2019-06-05 0001437749-19-011476 — 2.02, 5.02, 9.01
- 2019-05-24 0001437749-19-010833 — 5.02
- 2019-02-05 0001628280-19-000964 — 2.02, 8.01, 9.01
- 2018-11-06 0001628280-18-013765 — 2.02, 9.01
- 2018-10-31 0001628280-18-013204 — 1.01
- 2018-08-01 0001628280-18-010196 — 5.07
- 2018-07-31 0001628280-18-009846 — 2.02, 9.01
- 2018-07-09 0001193125-18-214745 — 1.01, 9.01
- 2018-07-03 0001628280-18-009075 — 5.02, 9.01
- 2018-06-14 0001628280-18-007877 — 5.02
- 2018-06-06 0001628280-18-007643 — 2.02, 9.01
- 2018-04-10 0001628280-18-004141 — 5.02
- 2018-04-03 0001628280-18-003952 — 2.01, 9.01
- 2018-02-05 0001628280-18-000989 — 2.02, 9.01
- 2018-02-01 0001628280-18-000826 — 1.01, 9.01
- 2017-11-07 0001628280-17-011076 — 2.02, 9.01
- 2017-09-26 0001628280-17-009444 — 3.02, 8.01
- 2017-08-08 0001628280-17-008329 — 2.02, 9.01
- 2017-08-01 0001628280-17-007765 — 5.02, 5.07
- 2017-07-03 0001193125-17-221140 — 5.02, 9.01
- 2017-05-26 0001193125-17-185503 — 8.01, 9.01
- 2017-05-25 0001628280-17-005914 — 2.02, 9.01 — amendment of 0001628280-17-005884
- 2017-05-25 0001628280-17-005884 — 2.02, 9.01
- 2017-05-10 0001193125-17-165924 — 8.01, 9.01
- 2017-05-09 0001193125-17-164273 — 5.02
- 2017-05-04 0001193125-17-158639 — 1.02, 8.01
- 2017-04-26 0001193125-17-139493 — 2.02, 9.01
- 2017-04-04 0001193125-17-109748 — 2.05, 5.02, 9.01
- 2017-02-06 0001628280-17-000899 — 2.02, 9.01
- 2017-01-27 0001193125-17-021808 — 1.01, 2.02, 9.01
- 2016-11-02 0001628280-16-020598 — 2.02, 9.01
- 2016-09-16 0001193125-16-712301 — 5.02
- 2016-08-23 0001193125-16-688767 — 8.01
- 2016-08-09 0001628280-16-018763 — 2.02, 9.01
- 2016-08-02 0001193125-16-668417 — 5.02, 5.07, 9.01
- 2016-05-31 0001564590-16-020114 — 2.02, 9.01
- 2016-05-18 0001193125-16-594515 — 5.02
- 2016-03-08 0001193125-16-496113 — 1.01
- 2016-02-09 0001193125-16-454775 — 2.02, 9.01
- 2015-12-17 0001193125-15-405566 — 1.01
- 2015-11-03 0001193125-15-363413 — 2.02, 9.01
- 2015-08-31 0001193125-15-307558 — 1.01
- 2015-08-05 0001193125-15-277824 — 2.02, 9.01
- 2015-07-31 0001193125-15-273009 — 5.07
- 2015-06-26 0001193125-15-237190 — 5.02
- 2015-06-09 0001193125-15-218028 — 8.01
- 2015-05-28 0001193125-15-202933 — 2.02, 9.01
- 2015-04-28 0001193125-15-153319 — 8.01, 9.01
- 2015-04-23 0001193125-15-144123 — 2.02, 8.01, 9.01
- 2015-04-23 0001193125-15-143608 — 8.01
- 2015-04-10 0001193125-15-126160 — 8.01
- 2015-03-24 0001193125-15-103436 — 5.03, 9.01
- 2015-03-18 0001193125-15-097034 — 5.07
- 2015-02-05 0001193125-15-034499 — 2.02, 9.01
- 2015-01-29 0001193125-15-024629 — 2.02, 9.01
- 2015-01-21 0001193125-15-016287 — 3.01, 8.01
- 2015-01-06 0001193125-15-002902 — 5.02
- 2014-12-22 0001193125-14-450591 — 1.01, 2.03, 3.02, 9.01
- 2014-11-13 0001193125-14-410207 — 1.01, 9.01
- 2014-11-07 0001193125-14-402383 — 1.02, 7.01, 9.01
- 2014-11-06 0001193125-14-399779 — 2.02, 9.01
- 2014-10-01 0001193125-14-360072 — 2.02, 8.01, 9.01
- 2014-09-04 0001193125-14-331411 — 8.01
- 2014-08-21 0001193125-14-317133 — 1.01
- 2014-08-06 0001193125-14-298306 — 5.02, 5.07, 9.01
- 2014-08-05 0001193125-14-294647 — 2.02, 9.01
- 2014-07-16 0001193125-14-269902 — 8.01
- 2014-06-23 0001193125-14-244592 — 3.02, 8.01
- 2014-06-05 0001193125-14-226459 — 2.02, 9.01
- 2014-06-05 0001193125-14-226457 — 1.01, 9.01
- 2014-03-19 0001193125-14-106558 — 2.05
- 2014-03-03 0001193125-14-078917 — 1.01, 3.02, 9.01
- 2014-02-28 0001193125-14-077480 — 8.01, 9.01
- 2014-02-06 0001193125-14-037960 — 2.02, 8.01, 9.01
- 2013-11-20 0001193125-13-447829 — 3.02, 8.01
- 2013-11-18 0001193125-13-444697 — 1.01, 2.03, 3.02, 9.01
- 2013-11-07 0001193125-13-431705 — 2.02, 9.01
- 2013-10-09 0001193125-13-395362 — 1.01, 2.03, 3.02, 9.01
- 2013-09-25 0001193125-13-378481 — 5.02, 9.01
- 2013-08-21 0001193125-13-341566 — 4.01, 9.01
- 2013-08-07 0001193125-13-323082 — 2.02, 9.01
- 2013-08-02 0001193125-13-317278 — 5.02, 5.07
- 2013-06-14 0001193125-13-258758 — 2.02, 9.01
- 2013-04-01 0001193125-13-136714 — 2.02, 8.01, 9.01
- 2013-02-20 0001193125-13-067218 — 5.02, 9.01
- 2013-02-14 0001193125-13-060131 — 1.01, 9.01
- 2013-02-11 0001193125-13-048784 — 2.02, 9.01
- 2013-01-08 0001193125-13-006861 — 5.02, 9.01
- 2012-12-21 0001193125-12-511592 — 1.01, 2.03, 3.02, 9.01
- 2012-11-28 0001193125-12-483317 — 2.05, 5.02, 7.01, 9.01
- 2012-11-06 0001193125-12-453359 — 2.02, 9.01
- 2012-08-02 0001193125-12-330534 — 2.02, 9.01
- 2012-07-27 0001193125-12-318790 — 5.02, 5.07, 9.01
- 2012-06-06 0001193125-12-261030 — 1.01, 2.02, 2.03, 3.02, 5.02, 9.01
- 2012-05-09 0001193125-12-222210 — 5.02
- 2012-04-20 0001193125-12-172045 — 8.01
- 2012-04-13 0001193125-12-162694 — 2.02, 8.01, 9.01
- 2012-04-04 0001193125-12-149102 — 1.01, 2.02, 2.03, 3.02, 9.01
- 2012-02-09 0001193125-12-048009 — 2.02, 9.01
- 2012-02-06 0001193125-12-041344 — 5.07 — amendment of 0000950123-11-102495
- 2011-12-08 0000950123-11-102495 — 5.07
- 2011-11-29 0000950123-11-100822 — 2.05
- 2011-11-09 0000950123-11-096775 — 2.02, 9.01
- 2011-10-31 0000950123-11-093390 — 1.02, 9.01
- 2011-10-07 0000950123-11-089221 — 8.01
- 2011-10-03 0000950123-11-088315 — 7.01
- 2011-09-23 0000950123-11-086288 — 2.02, 9.01
- 2011-09-15 0000950123-11-084585 — 7.01
- 2011-09-06 0000950123-11-082736 — 7.01
- 2011-08-18 0000950123-11-078526 — 3.01, 7.01, 9.01
- 2011-08-11 0000950123-11-075905 — 5.02
- 2011-08-11 0000950123-11-075904 — 2.02, 2.05, 9.01
- 2011-07-11 0000950123-11-064934 — 2.02, 4.02, 9.01
- 2011-06-30 0000950123-11-063287 — 1.01, 3.02, 9.01
- 2011-06-21 0000950123-11-060491 — 3.01, 7.01, 9.01
- 2011-06-13 0000950123-11-058656 — 1.01, 9.01
- 2011-05-24 0000950123-11-053517 — 5.02, 9.01
- 2011-04-05 0001299933-11-001020 — 2.02, 9.01
- 2011-03-15 0000950123-11-025580 — 5.02
- 2011-03-14 0000950123-11-025205 — 1.01, 3.02, 9.01
- 2011-02-01 0001299933-11-000333 — 2.02, 9.01
- 2010-11-12 0000950123-10-104604 — 8.01, 9.01
- 2010-11-08 0000950123-10-102424 — 8.01, 9.01
- 2010-11-02 0001299933-10-003878 — 2.02, 9.01
- 2010-09-15 0000950123-10-086373 — 1.01, 9.01 — amendment, the index does not say of what
- 2010-08-06 0000950123-10-074362 — 5.07
- 2010-07-29 0001299933-10-002860 — 2.02, 9.01
- 2010-05-17 0000950123-10-050424 — 1.01, 9.01
- 2010-05-14 0001299933-10-001972 — 5.02
- 2010-05-13 0001299933-10-001943 — 2.02, 9.01
- 2010-02-08 0001299933-10-000506 — 8.01
- 2010-02-02 0001299933-10-000386 — 2.02, 9.01
- 2009-12-15 0001299933-09-004928 — 5.02
- 2009-10-29 0001299933-09-004267 — 2.02, 9.01
- 2009-08-12 0001193125-09-173026 — 5.02, 9.01
- 2009-07-30 0001193125-09-158842 — 1.01, 2.02, 9.01
- 2009-05-15 0001193125-09-113158 — 5.02
- 2009-05-14 0001193125-09-110619 — 2.02, 9.01
- 2009-04-20 0001193125-09-082590 — 5.02
- 2009-02-03 0001193125-09-016992 — 2.02, 9.01
- 2009-01-22 0001193125-09-009777 — 2.02, 9.01
- 2008-11-04 0001193125-08-223730 — 2.02, 9.01
- 2008-08-11 0001193125-08-173616 — 8.01
- 2008-08-07 0001193125-08-170325 — 8.01
- 2008-08-05 0001193125-08-165888 — 2.02, 9.01
- 2008-06-11 0001193125-08-132049 — 1.01, 9.01
- 2008-05-20 0001193125-08-119372 — 5.02, 9.01
- 2008-05-08 0001193125-08-107052 — 2.02, 9.01
- 2008-01-31 0001193125-08-016233 — 2.02, 9.01
- 2008-01-30 0001193125-08-015494 — 5.03, 9.01
- 2007-11-01 0001193125-07-231866 — 2.02, 9.01
- 2007-10-31 0001193125-07-231225 — 2.05
- 2007-10-29 0001193125-07-228284 — 5.03, 9.01
- 2007-09-27 0001193125-07-208950 — 5.02
- 2007-08-09 0001193125-07-176553 — 2.02, 9.01
- 2007-08-07 0001193125-07-173829 — 1.01, 5.02, 9.01
- 2007-07-02 0001193125-07-148303 — 5.02, 9.01
- 2007-06-20 0001193125-07-139068 — 8.01, 9.01
- 2007-06-14 0001193125-07-135550 — 9.01 — amendment of 0001193125-07-005297
- 2007-06-14 0001193125-07-135340 — 5.02
- 2007-05-24 0001193125-07-122148 — 2.02, 9.01
- 2007-03-30 0001193125-07-070154 — 2.05, 9.01
- 2007-03-23 0001193125-07-062978 — 9.01 — amendment of 0001193125-07-005297
- 2007-02-01 0001193125-07-017883 — 2.02, 9.01
- 2007-01-11 0001193125-07-005297 — 2.01, 9.01
- 2006-12-05 0001181431-06-067500 — 5.02
- 2006-11-29 0001193125-06-243360 — 1.01, 3.02, 9.01
- 2006-11-02 0001193125-06-221464 — 2.02, 9.01
- 2006-09-21 0001193125-06-194526 — 5.02
- 2006-08-08 0001193125-06-164819 — 2.02, 9.01
- 2006-08-02 0001193125-06-159113 — 1.01, 9.01
- 2006-07-28 0001193125-06-156172 — 1.01
- 2006-06-26 0001193125-06-135913 — 1.01, 3.03, 9.01
- 2006-05-11 0001193125-06-108489 — 2.02, 9.01
- 2006-05-05 0001193125-06-102270 — 1.01, 9.01
- 2006-05-01 0001193125-06-094941 — 2.02, 2.06, 9.01
- 2006-02-24 0001193125-06-038281 — 5.02, 9.01
- 2006-02-02 0001181431-06-007665 — 2.02, 9.01
- 2005-11-09 0001181431-05-060304 — 2.02, 9.01
- 2005-08-04 0001181431-05-044420 — 2.02, 9.01
- 2005-07-28 0001193125-05-151272 — 5.02, 9.01
- 2005-06-14 0001193125-05-125148 — 5.02, 9.01
- 2005-05-12 0001181431-05-027410 — 2.02, 9.01
- 2005-05-10 0001193125-05-102795 — 1.01
- 2005-04-05 0001181431-05-020680 — 1.01, 2.02, 3.02, 9.01
- 2005-02-03 0001181431-05-006678 — 2.02, 9.01
- 2004-11-09 0001181431-04-051381 — 2.02, 9.01 — amendment, the index does not say of what
- 2004-11-04 0001181431-04-050706 — 2.02, 9.01
- 2004-10-15 0001193125-04-172458 — 1.01, 9.01
- 2004-08-05 0001193125-04-132162 — 12
- 2004-05-13 0001193125-04-086853 — 12
- 2004-02-05 0001193125-04-015060 — 12
- 2003-11-06 0001193125-03-074000 — 12
- 2003-09-26 0001193125-03-054624 — 5
- 2003-08-06 0001193125-03-029666 — 12
- 2003-05-14 0000927016-03-002619 — 9
- 2002-12-31 0000927016-02-006114 — 5
- 2000-01-24 0000927016-00-000150 — 5, 7
- 1998-11-02 0000950135-98-005625 — 5, 7
- 1998-03-24 0000950135-98-001743 — 5, 7
- 1997-09-05 0000950135-97-003729 — 5, 7
- 1997-06-23 0000950135-97-002785 — 1 — amendment of 0000950135-97-001972
- 1997-04-23 0000950135-97-001972 — 2, 7

## late-filing notifications on or before 2025-07-30

- 2011-08-10 0000950123-11-075677 — NT 10-Q, for the period ended 2011-06-30
- 2011-05-31 0000950123-11-055465 — NT 10-K, for the period ended 2011-03-31

## item 2.02 — earnings release, exhibit 99.1

[0001437749-25-023965:8k_2_02:1]
EX-99.1
2
ex_819091.htm
EXHIBIT 99.1

[0001437749-25-023965:8k_2_02:2]
ex_819091.htm

[0001437749-25-023965:8k_2_02:3]
Exhibit 99.1

[0001437749-25-023965:8k_2_02:4]
AMSC Reports First Quarter Fiscal Year 2025 Financial Results and Business Outlook

[0001437749-25-023965:8k_2_02:5]
|  | First Quarter Financial Highlights: |
|  | • Increased Revenue by 80% Year Over Year to Above $70 Million • Reported Net Income of Over $6 Million and Non-GAAP Net Income Exceeding $11 million • Achieved Gross Margin Greater than 30% |

[0001437749-25-023965:8k_2_02:6]
Company to host conference call tomorrow, July 31, at 10:00 am ET

[0001437749-25-023965:8k_2_02:7]
Ayer, MA – July 30, 2025 – AMSC (Nasdaq: AMSC), a leading system provider of megawatt-scale power resiliency solutions that orchestrate the rhythm and harmony of power on the grid™ and protect and expand the capability and resiliency of our Navy’s fleet, today reported financial results for its first quarter of fiscal year 2025 ended June 30, 2025.

[0001437749-25-023965:8k_2_02:8]
Revenues for the first quarter of fiscal 2025 were $72.4 million compared with $40.3 million for the same period of fiscal 2024. The year-over-year increase was driven by organic growth and the acquisition of NWL, Inc.

[0001437749-25-023965:8k_2_02:9]
AMSC’s net income for the first quarter of fiscal 2025 was $6.7 million, or $0.17 per share, compared to a net loss of $2.5 million, or $0.07 per share, for the same period of fiscal 2024. The Company’s non-GAAP net income for the first quarter of fiscal 2025 was $11.6 million, or $0.30 per share, compared with a non-GAAP net income of $3.0 million, or $0.09 per share, in the same period of fiscal 2024. Please refer to the financial table below for a reconciliation of GAAP to non-GAAP results.

[0001437749-25-023965:8k_2_02:10]
Cash, cash equivalents, and restricted cash on June 30, 2025, totaled $213.4 million, compared with $85.4 million at March 31, 2025.

[0001437749-25-023965:8k_2_02:11]
"We’ve kicked off fiscal 2025 with accelerated growth, delivering a standout first quarter marked by significant progress and exceptional execution that surpassed our expectations," said Daniel P. McGahn, Chairman, President and CEO, AMSC. "AMSC grew fiscal first quarter revenue by 80% year-over-year, generated net income of over $6 million marking our fourth consecutive quarter of profitability, and achieved expanded gross margins surpassing 30%. Strength in the semiconductor market—driven by growing demand for applications such as artificial intelligence and data centers—contributed to our momentum, while bookings and backlog remained steady. These results highlight our continued progress in scaling the business, diversifying revenue streams, and driving outstanding financial performance. We approach the remainder of fiscal 2025 with confidence in our team and business."

[0001437749-25-023965:8k_2_02:12]
| AMSC Reports Q1 FY25 Results | Page 2 |

[0001437749-25-023965:8k_2_02:13]
Business Outlook

[0001437749-25-023965:8k_2_02:14]
For the second quarter ending September 30, 2025, AMSC expects that its revenues will be in the range of $65.0 million to $70.0 million. The Company’s net income for the second quarter of fiscal 2025 is expected to exceed $2.0 million, or $0.05 per share. The Company's non-GAAP net income (as defined below) is expected to exceed $6.0 million, or $0.14 per share.

[0001437749-25-023965:8k_2_02:15]
Conference Call Reminder

[0001437749-25-023965:8k_2_02:16]
In conjunction with this announcement, AMSC management will participate in a conference call with investors beginning at 10:00 a.m. Eastern Time on Thursday, July 31, 2025, to discuss the Company’s financial results and business outlook. Those who wish to listen to the live or archived conference call webcast should visit the “Investors” section of the Company’s website at https://ir.amsc.com. The live call can be accessed by dialing 1-844-481-2802 or 1-412-317-0675 and asking to join the AMSC call. A replay of the call may be accessed 2 hours following the call by dialing 1-877-344-7529 and using conference passcode 4291224.

[0001437749-25-023965:8k_2_02:17]
About AMSC (Nasdaq: AMSC)

[0001437749-25-023965:8k_2_02:18]
AMSC generates the ideas, technologies and solutions that meet the world’s demand for smarter, cleaner … better energy™. Through its Gridtec™ Solutions, AMSC provides the engineering planning services and advanced grid systems that optimize network reliability, efficiency and performance.  Through its Marinetec™ Solutions, AMSC provides ship protection systems and is developing propulsion and power management solutions designed to help fleets increase system efficiencies, enhance power quality and boost operational safety. Through its Windtecc™ Solutions, AMSC provides wind turbine electronic controls and systems, designs and engineering services that reduce the cost of wind energy. The Company’s solutions are enhancing the performance and reliability of power networks, increasing the operational safety of navy fleets, and powering gigawatts of renewable energy globally. Founded in 1987, AMSC is headquartered near Boston, Massachusetts with operations in Asia, Australia, Europe and North America. For more information, please visit www.amsc.com.

[0001437749-25-023965:8k_2_02:19]
AMSC, American Superconductor, D-VAR, D-VAR VVO, Gridtec, Marinetec, Windtec, Neeltran, NEPSI, NWL, Smarter, Cleaner … Better Energy, and Orchestrate the Rhythm and Harmony of Power on the Grid are trademarks or registered trademarks of American Superconductor Corporation. All other brand names, product names, trademarks or service marks belong to their respective holders.

[0001437749-25-023965:8k_2_02:20]
| AMSC Reports Q1 FY25 Results | Page 3 |

[0001437749-25-023965:8k_2_02:21]
Forward-Looking Statements

[0001437749-25-023965:8k_2_02:22]
| AMSC Reports Q1 FY25 Results | Page 4 |

[0001437749-25-023965:8k_2_02:23]
UNAUDITED CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS

[0001437749-25-023965:8k_2_02:24]
(In thousands, except per share data)

[0001437749-25-023965:8k_2_02:25]
|  |  | Three Months Ended |  |
|  |  | June 30, |  |
|  |  | 2025 |  |  | 2024 |  |
| Revenues |  |  |  |  |  |  |  |  |
| Grid |  | $ | 60,087 |  |  | $ | 32,336 |  |
| Wind |  |  | 12,271 |  |  |  | 7,954 |  |
| Total revenues |  |  | 72,358 |  |  |  | 40,290 |  |
| Cost of revenues |  |  | 47,869 |  |  |  | 28,065 |  |
| Gross margin |  |  | 24,489 |  |  |  | 12,225 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |
| Research and development |  |  | 4,304 |  |  |  | 2,286 |  |
| Selling, general and administrative |  |  | 14,204 |  |  |  | 8,898 |  |
| Amortization of acquisition-related intangibles |  |  | 337 |  |  |  | 412 |  |
| Change in fair value of contingent consideration |  |  | — |  |  |  | 3,920 |  |
| Total operating expenses |  |  | 18,845 |  |  |  | 15,516 |  |
| Operating income (loss) |  |  | 5,644 |  |  |  | (3,291 | ) |
| Interest income, net |  |  | 932 |  |  |  | 1,120 |  |
| Other income (expense), net |  |  | 347 |  |  |  | (160 | ) |
| Income (loss) before income tax expense |  |  | 6,923 |  |  |  | (2,331 | ) |
| Income tax expense |  |  | 199 |  |  |  | 193 |  |
| Net income (loss) |  | $ | 6,724 |  |  | $ | (2,524 | ) |
| Net income (loss) per common share |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.17 |  |  | $ | (0.07 | ) |
| Diluted |  | $ | 0.17 |  |  | $ | (0.07 | ) |
| Weighted average number of common shares outstanding |  |  |  |  |  |  |  |  |
| Basic |  |  | 38,875 |  |  |  | 35,676 |  |
| Diluted |  |  | 39,742 |  |  |  | 35,676 |  |

[0001437749-25-023965:8k_2_02:26]
| AMSC Reports Q1 FY25 Results | Page 5 |

[0001437749-25-023965:8k_2_02:27]
UNAUDITED CONDENSED CONSOLIDATED BALANCE SHEETS

[0001437749-25-023965:8k_2_02:28]
(In thousands, except per share data)

[0001437749-25-023965:8k_2_02:29]
|  |  | June 30, 2025 |  |  | March 31, 2025 |  |
| ASSETS |  |  |  |  |  |  |  |  |
| Current assets: |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 207,890 |  |  | $ | 79,494 |  |
| Accounts receivable, net |  |  | 54,684 |  |  |  | 46,186 |  |
| Inventory, net |  |  | 71,602 |  |  |  | 71,169 |  |
| Prepaid expenses and other current assets |  |  | 13,332 |  |  |  | 8,055 |  |
| Restricted cash |  |  | 1,349 |  |  |  | 1,613 |  |
| Total current assets |  |  | 348,857 |  |  |  | 206,517 |  |
| Property, plant and equipment, net |  |  | 38,521 |  |  |  | 38,572 |  |
| Intangibles, net |  |  | 5,579 |  |  |  | 5,916 |  |
| Right-of-use assets |  |  | 4,041 |  |  |  | 3,829 |  |
| Goodwill |  |  | 48,164 |  |  |  | 48,164 |  |
| Restricted cash |  |  | 4,180 |  |  |  | 4,274 |  |
| Deferred tax assets |  |  | 1,262 |  |  |  | 1,178 |  |
| Equity-method investments |  |  | 1,406 |  |  |  | 1,113 |  |
| Other assets |  |  | 836 |  |  |  | 958 |  |
| Total assets |  | $ | 452,846 |  |  | $ | 310,521 |  |
| LIABILITIES AND STOCKHOLDERS' EQUITY |  |  |  |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |  |  |  |
| Accounts payable and accrued expenses |  | $ | 38,401 |  |  | $ | 32,282 |  |
| Lease liability, current portion |  |  | 854 |  |  |  | 685 |  |
| Deferred revenue, current portion |  |  | 66,055 |  |  |  | 66,797 |  |
| Total current liabilities |  |  | 105,310 |  |  |  | 99,764 |  |
| Deferred revenue, long term portion |  |  | 9,836 |  |  |  | 9,336 |  |
| Lease liability, long term portion |  |  | 2,906 |  |  |  | 2,684 |  |
| Deferred tax liabilities |  |  | 1,647 |  |  |  | 1,595 |  |
| Other liabilities |  |  | 31 |  |  |  | 28 |  |
| Total liabilities |  |  | 119,730 |  |  |  | 113,407 |  |
| Stockholders' equity: |  |  |  |  |  |  |  |  |
| Common stock, $0.01 par value, 75,000,000 shares authorized; 45,564,273 and 39,887,536 shares issued and 45,160,922 and 39,484,185 shares outstanding at June 30, 2025 and March 31, 2025, respectively |  |  | 456 |  |  |  | 399 |  |
| Additional paid-in capital |  |  | 1,388,948 |  |  |  | 1,259,540 |  |
| Treasury stock, at cost, 403,351 at June 30, 2025 and March 31, 2025 |  |  | (3,765 | ) |  |  | (3,765 | ) |
| Accumulated other comprehensive income |  |  | 1,378 |  |  |  | 1,565 |  |
| Accumulated deficit |  |  | (1,053,901 | ) |  |  | (1,060,625 | ) |
| Total stockholders' equity |  |  | 333,116 |  |  |  | 197,114 |  |
| Total liabilities and stockholders' equity |  | $ | 452,846 |  |  | $ | 310,521 |  |

[0001437749-25-023965:8k_2_02:30]
| AMSC Reports Q1 FY25 Results | Page 6 |

[0001437749-25-023965:8k_2_02:31]
UNAUDITED CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS

[0001437749-25-023965:8k_2_02:32]
(In thousands)

[0001437749-25-023965:8k_2_02:33]
|  |  | Three Months Ended June 30, |  |
|  |  | 2025 |  |  | 2024 |  |
| Cash flows from operating activities: |  |  |  |  |  |  |  |  |
| Net income (loss) |  | $ | 6,724 |  |  | $ | (2,524 | ) |
| Adjustments to reconcile net income (loss) to net cash provided by operations: |  |  |  |  |  |  |  |  |
| Depreciation and amortization |  |  | 1,229 |  |  |  | 1,008 |  |
| Stock-based compensation expense |  |  | 4,526 |  |  |  | 1,229 |  |
| Provision for excess and obsolete inventory |  |  | 711 |  |  |  | 503 |  |
| Amortization of operating lease right-of-use assets |  |  | 243 |  |  |  | 192 |  |
| Deferred income taxes |  |  | 7 |  |  |  | (2 | ) |
| Earnings from equity method investments |  |  | (293 | ) |  |  | — |  |
| Change in fair value of contingent consideration |  |  | — |  |  |  | 3,920 |  |
| Other non-cash items |  |  | 140 |  |  |  | (3 | ) |
| Changes in operating asset and liability accounts: |  |  |  |  |  |  |  |  |
| Accounts receivable |  |  | (8,512 | ) |  |  | 2,786 |  |
| Inventory |  |  | (1,046 | ) |  |  | (3,799 | ) |
| Prepaid expenses and other assets |  |  | (5,084 | ) |  |  | (3,099 | ) |
| Operating leases |  |  | (64 | ) |  |  | (195 | ) |
| Accounts payable and accrued expenses |  |  | 6,321 |  |  |  | (1,734 | ) |
| Deferred revenue |  |  | (777 | ) |  |  | 5,127 |  |
| Net cash provided by operating activities |  |  | 4,125 |  |  |  | 3,409 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |
| Purchases of property, plant and equipment |  |  | (814 | ) |  |  | (265 | ) |
| Change in other assets |  |  | 79 |  |  |  | 245 |  |
| Net cash used in investing activities |  |  | (735 | ) |  |  | (20 | ) |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |
| Repayment of debt |  |  | — |  |  |  | (16 | ) |
| Employee taxes paid related to net settlement of equity awards |  |  | — |  |  |  | (126 | ) |
| Proceeds from public equity offering, net of offering expenses |  |  | 124,577 |  |  |  | — |  |
| Net cash provided by (used in) financing activities |  |  | 124,577 |  |  |  | (142 | ) |
| Effect of exchange rate changes on cash |  |  | 71 |  |  |  | (4 | ) |
| Net increase in cash, cash equivalents and restricted cash |  |  | 128,038 |  |  |  | 3,243 |  |
| Cash, cash equivalents and restricted cash at beginning of period |  |  | 85,381 |  |  |  | 92,280 |  |
| Cash, cash equivalents and restricted cash at end of period |  | $ | 213,419 |  |  | $ | 95,523 |  |

[0001437749-25-023965:8k_2_02:34]
| AMSC Reports Q1 FY25 Results | Page 7 |

[0001437749-25-023965:8k_2_02:35]
RECONCILIATION OF GAAP NET INCOME (LOSS) TO NON-GAAP NET INCOME

[0001437749-25-023965:8k_2_02:36]
(In thousands, except per share data)

[0001437749-25-023965:8k_2_02:37]
|  |  | Three Months Ended June 30, |  |
|  |  | 2025 |  |  | 2024 |  |
| Net income (loss) |  | $ | 6,724 |  |  | $ | (2,524 | ) |
| Stock-based compensation |  |  | 4,526 |  |  |  | 1,229 |  |
| Amortization of acquisition-related intangibles |  |  | 337 |  |  |  | 412 |  |
| Change in fair value of contingent consideration |  |  | — |  |  |  | 3,920 |  |
| Non-GAAP net income |  | $ | 11,587 |  |  | $ | 3,037 |  |
| Non-GAAP net income per share - basic |  | $ | 0.30 |  |  | $ | 0.09 |  |
| Non-GAAP net income per share - diluted |  | $ | 0.29 |  |  | $ | 0.08 |  |
| Weighted average shares outstanding - basic |  |  | 38,875 |  |  |  | 35,676 |  |
| Weighted average shares outstanding - diluted |  |  | 39,742 |  |  |  | 37,032 |  |

[0001437749-25-023965:8k_2_02:38]
Reconciliation of Forecast GAAP Net Income to Non-GAAP Net Income

[0001437749-25-023965:8k_2_02:39]
(In millions, except per share data)

[0001437749-25-023965:8k_2_02:40]
|  |  | Three Months Ending |  |
|  |  | September 30, 2025 |  |
| Net income |  | $ | 2.0 |  |
| Stock-based compensation |  |  | 3.7 |  |
| Amortization of acquisition-related intangibles |  |  | 0.3 |  |
| Non-GAAP net income |  | $ | 6.0 |  |
| Non-GAAP net income per share |  | $ | 0.14 |  |
| Shares outstanding |  |  | 43.5 |  |

[0001437749-25-023965:8k_2_02:41]
| AMSC Reports Q1 FY25 Results | Page 8 |

[0001437749-25-023965:8k_2_02:42]
Note: Non-GAAP net income is defined by the Company as net income before stock-based compensation; amortization of acquisition-related intangibles; change in fair value of contingent consideration, other non-cash or unusual charges, and the tax effect of adjustments calculated at the relevant rate for our non-GAAP metric. The Company believes non-GAAP net income and non-GAAP net income per share assist management and investors in comparing the Company’s performance across reporting periods on a consistent basis by excluding these non-cash, non-recurring or other charges that it does not believe are indicative of its core operating performance. Actual GAAP and non-GAAP net income for the fiscal quarter ending September 30, 2025, including the above adjustments, may differ materially from those forecasted in the table above. Generally, a non-GAAP financial measure is a numerical measure of a company's performance, financial position or cash flow that either excludes or includes amounts that are not normally excluded or included in the most directly comparable measure calculated and presented in accordance with GAAP. The non-GAAP measure included in this release, however, should be considered in addition to, and not as a substitute for or superior to, net income or other measures of financial performance prepared in accordance with GAAP. A reconciliation of GAAP to non-GAAP net income is set forth in the table above.

[0001437749-25-023965:8k_2_02:43]
Contacts:

[0001437749-25-023965:8k_2_02:44]
AMSC Director, Communications:

[0001437749-25-023965:8k_2_02:45]
Nicol Golez

[0001437749-25-023965:8k_2_02:46]
978-399-8344

[0001437749-25-023965:8k_2_02:47]
Nicol.Golez@amsc.com

[0001437749-25-023965:8k_2_02:48]
Investor Relations:

[0001437749-25-023965:8k_2_02:49]
Carolyn Capaccio

[0001437749-25-023965:8k_2_02:50]
Phone: (212) 838-3777

[0001437749-25-023965:8k_2_02:51]
amscIR@allianceadvisors.com

[0001437749-25-023965:8k_2_02:52]
Public Relations:

[0001437749-25-023965:8k_2_02:53]
Joe Luongo

[0001437749-25-023965:8k_2_02:54]
(914) 906-5903

[0001437749-25-023965:8k_2_02:55]
jluongo@rooneypartners.com
