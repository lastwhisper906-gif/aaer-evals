# AMSC MD&A — 0001437749-25-023968


## mdna

[0001437749-25-023968:mdna:1]
[same as prior period, unchanged from 0001437749-25-002900:mdna:1]

[0001437749-25-023968:mdna:2]
American Superconductor®, Amperium®, AMSC®, D-VAR®, PowerModule™, D-VAR VVO®, PQ-IVR®, SeaTitan®, Gridtec™ Solutions, Windtec™ Solutions, Smarter, Cleaner...Better Energy™, orchestrate the rhythm and harmony of power on the grid™, actiVAR®, armorVAR™, NEPSI™ and Neeltran™, NWL™ and SafetyLOCK™ are trademarks or registered trademarks of American Superconductor Corporation or our subsidiaries. We reserve all of our rights with respect to our trademarks or registered trademarks regardless of whether they are so designated in this Quarterly Report on Form 10-Q by an ® or ™ symbol. All other brand names, product names, trademarks or service marks appearing in this Quarterly Report on Form 10-Q are the property of their respective holders.

[0001437749-25-023968:mdna:3]
[same as prior period, unchanged from 0001437749-25-002900:mdna:3]

[0001437749-25-023968:mdna:4]
[same as prior period, unchanged from 0001437749-25-002900:mdna:4]

[0001437749-25-023968:mdna:5]
[same as prior period, unchanged from 0001437749-25-002900:mdna:5]

[0001437749-25-023968:mdna:6]
[same as prior period, unchanged from 0001437749-25-002900:mdna:6]

[0001437749-25-023968:mdna:7]
[same as prior period, unchanged from 0001437749-25-002900:mdna:7]

[0001437749-25-023968:mdna:8]
[same as prior period, unchanged from 0001437749-25-002900:mdna:8]

[0001437749-25-023968:mdna:9]
[same as prior period, unchanged from 0001437749-25-002900:mdna:9]

[0001437749-25-023968:mdna:10]
Our fiscal year begins on April 1 and ends on March 31. When we refer to a particular fiscal year, we are referring to the fiscal year that began on April 1 of that same year. For example, fiscal 2025 refers to the fiscal year that began on April 1, 2025. Other fiscal years follow similarly.

[0001437749-25-023968:mdna:11]
Changes in macroeconomic conditions arising from various reasons, such as the ongoing wars between Russia and Ukraine and Israel and Hamas, tariffs, trade restrictions and resulting trade conflicts, labor force availability, sourcing, material delays and global supply chain disruptions, could have a material adverse effect on our business, financial condition and results of operations.

[0001437749-25-023968:mdna:12]
On August 1, 2024, we entered into a Stock Purchase Agreement (the “Stock Purchase Agreement”) with the selling stockholders named therein. Pursuant to the terms of the Stock Purchase Agreement and concurrently with entering into such agreement, we acquired all of the issued and outstanding shares of Megatran, Industries, Inc. ("Megatran"), for aggregate consideration in an amount equal to $61.4 million, as may be adjusted pursuant to the Stock Purchase Agreement (the “Purchase Price”), including a cash payment after closing of $5.0 million, as adjusted pursuant to Sections 5.6(c), (d), and (f) of the Stock Purchase Agreement (the “Additional Cash Purchase Price”). At closing, we paid to Megatran's selling stockholders $25.0 million in cash on hand, and 1,297,600 restricted shares of our common stock. On September 23, 2024, we paid the Additional Cash Purchase Price to the selling stockholders, which was calculated based on the agreed upon formula set forth in the Stock Purchase Agreement, in the amount of $8.3 million which includes the Additional Cash Purchase Price and the make whole payment. Megatran's wholly-owned subsidiary, NWL, Inc. (together with Megatran, "NWL"), is a U.S.-based global provider of engineered power conversion solutions for demanding industrial and military applications.  As a result of this transaction, Megatran became a wholly-owned subsidiary and is operated by our Grid business segment. We refer to this transaction as the "acquisition of NWL".

[0001437749-25-023968:mdna:13]
In June 2025, we completed an offering of 4,743,750 shares of our common stock at a public offering price of $28.00 per share under our Registration Statement on Form S-3. We received aggregate net proceeds of approximately $124.6 million after deducting underwriting discounts and commissions and offering expenses.

[0001437749-25-023968:mdna:14]
[same as prior period, unchanged from 0001437749-25-002900:mdna:15]

[0001437749-25-023968:mdna:15]
[same as prior period, unchanged from 0001437749-25-002900:mdna:16]

[0001437749-25-023968:mdna:16]
[same as prior period, unchanged from 0001437749-25-002900:mdna:19]

[0001437749-25-023968:mdna:17]
Three months ended June 30, 2025, compared to the three months ended June 30, 2024

[0001437749-25-023968:mdna:18]
[same as prior period, unchanged from 0001437749-25-002900:mdna:21]

[0001437749-25-023968:mdna:19]
Total revenues increased 80% to $72.4 million for the three months ended June 30, 2025, compared to $40.3 million for the three months ended June 30, 2024. Our revenues are summarized as follows (in thousands):

[0001437749-25-023968:mdna:20]
|  |  | Three Months Ended June 30, |  |
|  |  | 2025 |  |  | 2024 |  |
| Revenues: |  |  |  |  |  |  |  |  |
| Grid |  | $ | 60,087 |  |  | $ | 32,336 |  |
| Wind |  |  | 12,271 |  |  |  | 7,954 |  |
| Total |  | $ | 72,358 |  |  | $ | 40,290 |  |

[0001437749-25-023968:mdna:21]
Our Grid business segment accounted for 83% of total revenues for the three months ended June 30, 2025, compared to 80% for the three months ended June 30, 2024. Our Grid business segment revenues increased 86% to $60.1 million in the three months ended June 30, 2025, from $32.3 million in the three months ended June 30, 2024. The increase in the Grid business segment revenues in the three months ended June 30, 2025, compared to the three months ended June 30, 2024 was primarily driven by the acquisition of NWL and increased shipments of new energy power systems than in the prior year period.

[0001437749-25-023968:mdna:22]
Our Wind business segment accounted for 17% of total revenues for the three months ended June 30, 2025, compared to 20% for the three months ended June 30, 2024. Revenues in the Wind business segment increased 54% to $12.3 million in the three months ended June 30, 2025, from $8.0 million in the three months ended June 30, 2024. The increase during the three months ended June 30, 2025, compared to the three months ended June 30, 2024, was driven by additional shipments of electrical control systems ("ECS").

[0001437749-25-023968:mdna:23]
[same as prior period, unchanged from 0001437749-25-002900:mdna:26]

[0001437749-25-023968:mdna:24]
Cost of revenues increased by 71% to $47.9 million for the three months ended June 30, 2025, compared to $28.1 million for the three months ended June 30, 2024. Gross margin was 34% for the three months ended June 30, 2025, compared to 30% for the three months ended June 30, 2024. The increase in gross margin in the three months ended June 30, 2025 was due to higher revenues, a favorable product mix and favorable impacts across the business due to pricing increases across our product lines.

[0001437749-25-023968:mdna:25]
[same as prior period, unchanged from 0001437749-25-002900:mdna:28]

[0001437749-25-023968:mdna:26]
[same as prior period, unchanged from 0001437749-25-002900:mdna:29]

[0001437749-25-023968:mdna:27]
Research and development ("R&D") expenses increased 88% in the three months ended June 30, 2025, to $4.3 million from $2.3 million in the three months ended June 30, 2024. The increase in the three months ended June 30, 2025 was driven primarily by the addition of NWL R&D expenses, higher overall compensation expense and additional stock-based compensation expense.

[0001437749-25-023968:mdna:28]
[same as prior period, unchanged from 0001437749-25-002900:mdna:31]

[0001437749-25-023968:mdna:29]
Selling, general and administrative ("SG&A") expenses increased 60% in the three months ended June 30, 2025, to $14.2 million from $8.9 million in the three months ended June 30, 2024. The increase in SG&A expense in the three months ended June 30, 2025 was driven primarily by the addition of NWL SG&A expenses, higher overall compensation expense and additional stock-based compensation expense.

[0001437749-25-023968:mdna:30]
Amortization of acquisition-related intangibles

[0001437749-25-023968:mdna:31]
We recorded amortization expense related to our core technology and know-how and customer relationships of $0.3 million in the three months ended June 30, 2025, and $0.4 million in the three months ended June 30, 2024. The decrease in amortization expense is a result of using the economic consumption method as the basis to amortize the acquired customer relationship intangible assets from Northeast Power Systems, Inc. ("NEPSI") and Neeltran, Inc.

[0001437749-25-023968:mdna:32]
[same as prior period, unchanged from 0001437749-25-002900:mdna:35]

[0001437749-25-023968:mdna:33]
The change in fair value of our contingent consideration for the earnout payment on the acquisition of NEPSI resulted in a loss of $3.9 million in the three months ended June 30, 2024 driven from an increase in fair value. There was no activity in the three months ended June 30, 2025 as the contingent consideration was settled during the prior fiscal year.

[0001437749-25-023968:mdna:34]
[same as prior period, unchanged from 0001437749-25-002900:mdna:37]

[0001437749-25-023968:mdna:35]
[same as prior period, unchanged from 0001437749-25-002900:mdna:38]

[0001437749-25-023968:mdna:36]
|  |  | Three Months Ended June 30, |  |
|  |  | 2025 |  |  | 2024 |  |
| Operating income (loss): |  |  |  |  |  |  |  |  |
| Grid |  | $ | 4,155 |  |  | $ | (237 | ) |
| Wind |  |  | 1,489 |  |  |  | 866 |  |
| Unallocated corporate expenses |  |  | — |  |  |  | (3,920 | ) |
| Total |  | $ | 5,644 |  |  | $ | (3,291 | ) |

[0001437749-25-023968:mdna:37]
Our Grid business segment generated operating income of $4.2 million in the three months ended June 30, 2025, compared to an operating loss of $0.2 million in the three months ended June 30, 2024. The improvement in the Grid business segment operating income in the three months ended June 30, 2025 was due to higher revenues and gross margins.

[0001437749-25-023968:mdna:38]
Our Wind business segment generated operating income of $1.5 million in the three months ended June 30, 2025, compared to operating income of $0.9 million in the three months ended June 30, 2024. The increase in the Wind business segment operating income in the three months ended June 30, 2025 was due to higher revenues and gross margins from increased sales of ECS units.

[0001437749-25-023968:mdna:39]
Unallocated corporate expenses included a net loss on contingent consideration of $3.9 million in the three months ended June 30, 2024.

[0001437749-25-023968:mdna:40]
[same as prior period, unchanged from 0001437749-25-002900:mdna:43]

[0001437749-25-023968:mdna:41]
Interest income, net, was $0.9 million in the three months ended June 30, 2025, compared to $1.1 million in the three months ended June 30, 2024. The decrease in interest income, net, in the three months ended June 30, 2025 was due to lower interest rates.

[0001437749-25-023968:mdna:42]
[same as prior period, unchanged from 0001437749-25-002900:mdna:45]

[0001437749-25-023968:mdna:43]
Other income, net, was $0.3 million in the three months ended June 30, 2025, compared to other expense, net of $0.2 million in the three months ended June 30, 2024. The improvement in other income, net, during the three months ended June 30, 2025, compared to the three months ended June 30, 2024, was driven by the impacts of favorable fluctuations in foreign currencies and gain on earnings from our NWL Pacific joint venture during the periods.

[0001437749-25-023968:mdna:44]
[same as prior period, unchanged from 0001437749-25-002900:mdna:47]

[0001437749-25-023968:mdna:45]
Income tax expense was $0.2 million in both the three months ended June 30, 2025 and June 30, 2024.

[0001437749-25-023968:mdna:46]
[same as prior period, unchanged from 0001437749-25-002900:mdna:49]

[0001437749-25-023968:mdna:47]
Net income was $6.7 million in the three months ended June 30, 2025, compared to a net loss of $2.5 million in the three months ended June 30, 2024. The improvement in net income was driven primarily by increased revenues and gross margins.

[0001437749-25-023968:mdna:48]
Non-GAAP Financial Measure - Non-GAAP Net Income

[0001437749-25-023968:mdna:49]
[same as prior period, unchanged from 0001437749-25-002900:mdna:52]

[0001437749-25-023968:mdna:50]
We define non-GAAP net income as net income (loss) before stock-based compensation, amortization of acquisition-related intangibles, change in fair value of contingent consideration, and other non-cash or unusual charges. We believe non-GAAP net income assists management and investors in comparing our performance across reporting periods on a consistent basis by excluding these non-cash charges and other items that we do not believe are indicative of our core operating performance. In addition, we use non-GAAP net income as a factor to evaluate the effectiveness of our business strategies. A reconciliation of GAAP to non-GAAP net income is set forth in the table below (in thousands, except per share data):

[0001437749-25-023968:mdna:51]
|  |  | Three Months Ended June 30, |  |
|  |  | 2025 |  |  | 2024 |  |
| Net income (loss) |  | $ | 6,724 |  |  | $ | (2,524 | ) |
| Stock-based compensation |  |  | 4,526 |  |  |  | 1,229 |  |
| Amortization of acquisition-related intangibles |  |  | 337 |  |  |  | 412 |  |
| Change in fair value of contingent consideration |  |  | — |  |  |  | 3,920 |  |
| Non-GAAP net income |  | $ | 11,587 |  |  | $ | 3,037 |  |
| Non-GAAP net income per share - basic |  | $ | 0.30 |  |  | $ | 0.09 |  |
| Non-GAAP net income per share - diluted |  | $ | 0.29 |  |  | $ | 0.08 |  |
| Weighted average shares outstanding - basic |  |  | 38,875 |  |  |  | 35,676 |  |
| Weighted average shares outstanding - diluted |  |  | 39,742 |  |  |  | 37,032 |  |

[0001437749-25-023968:mdna:52]
We generated non-GAAP net income of $11.6 million, or $0.30 per share, for the three months ended June 30, 2025, compared to a non-GAAP net income of $3.0 million, or $0.09 per share, for the three months ended June 30, 2024. The improvement in the non-GAAP net income for the three months ended June 30, 2025 was due to higher revenues and gross margins.

[0001437749-25-023968:mdna:53]
[same as prior period, unchanged from 0001437749-25-002900:mdna:56]

[0001437749-25-023968:mdna:54]
[same as prior period, unchanged from 0001437749-25-002900:mdna:57]

[0001437749-25-023968:mdna:55]
The Company’s primary sources of liquidity are internally generated cash provided by operating activities, our cash and cash equivalents on hand, along with access to capital markets, including through our currently effective Registration Statements on Form S-3. We believe that these sources of liquidity are sufficient to meet both our short-term and reasonably foreseeable long-term requirements and obligations. As of June 30, 2025, we had cash and cash equivalents of $207.9 million.

[0001437749-25-023968:mdna:56]
Our cash requirements depend on numerous factors, including the successful completion of our product development activities, our ability to commercialize our Resilient Electric Grid and ship protection system solutions, the rate of customer and market adoption of our products, collecting receivables according to established terms, the continued availability of U.S. government funding during the product development phase of our superconductor-based products and whether Inox is successful in executing on Solar Energy Corporation of India Limited orders or in obtaining additional orders under the new central and state auction regime. We continue to closely monitor our expenses and, if required, may reduce our operating and capital spending to enhance liquidity.

[0001437749-25-023968:mdna:57]
On June 10, 2025, we completed an offering of 4,125,000 shares of our common stock at a public offering price of $28.00 per share under our Registration Statement on Form S-3. We received net proceeds of approximately $108.2 million after deducting underwriting discounts and commissions and offering expenses. The offering included an option to purchase an additional 618,750 shares over the initial offering of 4,125,000 shares at the public offering price, less underwriting discounts and commission. This option was fully exercised on June 16, 2025 resulting in an additional $16.3 million in net proceeds, after deducting underwriting discounts and commissions and offering expenses payable by the Company, for total net proceeds of approximately $124.6 million. The offering closed on June 16, 2025.

[0001437749-25-023968:mdna:58]
As of June 30, 2025, we had cash, cash equivalents and restricted cash of $213.4 million, compared to $85.4 million as of March 31, 2025, an increase of $128.0 million. As of June 30, 2025, we had $3.3 million in cash, cash equivalents, and restricted cash in foreign bank accounts. Our cash, cash equivalents, and restricted cash are summarized as follows (in thousands):

[0001437749-25-023968:mdna:59]
|  |  | June 30, 2025 |  |  | March 31, 2025 |  |
| Cash and cash equivalents |  | $ | 207,890 |  |  | $ | 79,494 |  |
| Restricted cash |  |  | 5,529 |  |  |  | 5,887 |  |
| Total cash, cash equivalents, and restricted cash |  | $ | 213,419 |  |  | $ | 85,381 |  |

[0001437749-25-023968:mdna:60]
For the three months ended June 30, 2025, net cash provided by operating activities was $4.1 million, compared to cash provided by operating activities of $3.4 million for the three months ended June 30, 2024. The increase in cash flows provided by operating activities in the three months ended June 30, 2025 was due primarily to increased net income, decrease in cash spent on accounts payable and accrued expenses as well as inventory, offset by an increase in accounts receivable, cash spent on prepaid expenses, and change in deferred revenue.

[0001437749-25-023968:mdna:61]
For the three months ended June 30, 2025, net cash used in investing activities was $0.7 million, compared to less than $0.1 million for the three months ended June 30, 2024. The increase in net cash used in investing activities was primarily due to purchases of property, plant and equipment.

[0001437749-25-023968:mdna:62]
For the three months ended June 30, 2025, net cash provided by financing activities was $124.6 million compared to cash used in financing activities of $0.1 million for the three months ended June 30, 2024. The improvement was due to the equity raise in June 2025.

[0001437749-25-023968:mdna:63]
As of June 30, 2025, we had $4.2 million of restricted cash included in long-term assets and $1.3 million of restricted cash included in current assets. At March 31, 2025, we had $4.3 million of restricted cash included in long-term assets and $1.6 million of restricted cash in current assets. These amounts included in restricted cash primarily represent collateral deposits to secure surety bonds and letters of credit for various customer contracts. These deposits are held in interest bearing accounts.

[0001437749-25-023968:mdna:64]
We are a party to many contractual obligations involving commitments to make payments to third parties. These obligations impact our short-term and long-term liquidity and capital resource needs. Certain contractual obligations are reflected on the condensed consolidated balance sheet as of June 30, 2025, while others are considered future commitments. We have various contractual arrangements, under which we have committed to purchase certain minimum quantities of goods or services on an annual basis. For information regarding our other contractual obligations, refer to Note 14, "Contingent Consideration," Note 15, "Leases" and Note 16, "Commitments and Contingencies" to our condensed consolidated financial statements included elsewhere in this Quarterly Report on Form 10-Q. There have been no material changes to our contractual obligations from those disclosed in our Annual Report on Form 10-K for the fiscal year ended March 31, 2025.

[0001437749-25-023968:mdna:65]
We believe we have sufficient available liquidity to fund our operations and capital expenditures for the next twelve months. We raised $124.6 million, net of offering expenses, through an equity raise in June 2025. In addition, we may seek to raise additional capital, which could be in the form of loans, convertible debt or equity, to fund our operating requirements and capital expenditures. There can be no assurance that we will be able to raise additional capital on favorable terms or at all or execute on any other means of improving our liquidity as described above.  Additionally, the impact of global sources of instability, including the ongoing wars between Russia and Ukraine and Israel and Hamas, tariffs, trade restrictions and resulting trade conflicts, instability of financial institutions and political instability in the United States, on the global financial markets may reduce our ability to raise additional capital, if necessary, which could negatively impact our liquidity.

[0001437749-25-023968:mdna:66]
Legal Proceedings

[0001437749-25-023968:mdna:67]
[same as prior period, unchanged from 0001437749-25-002900:mdna:73]

[0001437749-25-023968:mdna:68]
[same as prior period, unchanged from 0001437749-25-002900:mdna:74]

[0001437749-25-023968:mdna:69]
In December 2023, the FASB issued ASU 2023-09, 
    Income Taxes (Topic 740): Improvements to Income Tax Disclosures. The amendments in ASU 2023-09 address investor requests for more transparency about income tax information through improvements to income tax disclosures primarily related to the rate reconciliation and income taxes paid information. Following the release of ASU 2023-09 in December 2023, the effective date was annual reporting periods beginning after December 15, 2024. As of
    June 30, 2025, we are evaluating the impact on our condensed consolidated financial statements.

[0001437749-25-023968:mdna:70]
In March 2024, the FASB issued ASU 2024-02, Codification Improvements—Amendments to Remove References to the Concepts Statements. The amendments in ASU 2024-02 contain amendments to the Codification that remove references to various FASB Concepts Statements. Following the release of ASU 2024-02 in March 2024, the effective date was annual reporting periods beginning after December 15, 2024. As of June 30, 2025, we are evaluating the impact on our condensed consolidated financial statements.

[0001437749-25-023968:mdna:71]
In November 2024, the FASB issued ASU 2024-03, Income Statement—Reporting Comprehensive Income—Expense Disaggregation Disclosures. The amendments in ASU 2024-03 address investor requests for more disclosure of disaggregated financial reporting information about expenses presented in the income statement. Following the release of ASU 2024-03 in November 2024, the effective date will be annual reporting periods beginning after December 15, 2026. As of June 30, 2025, we are evaluating the impact on our condensed consolidated financial statements.

[0001437749-25-023968:mdna:72]
We do not believe that, outside of those disclosed here, there are any other recently issued accounting pronouncements that will have a material impact on our condensed consolidated financial statements.
