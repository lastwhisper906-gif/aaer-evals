# AMSC notes — 0001437749-25-023968


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0001437749-25-023968:notes:1]
1. Nature of the Business and Operations

[0001437749-25-023968:notes:2]
[same as prior period, unchanged from 0001437749-25-002900:notes:2]

[0001437749-25-023968:notes:3]
[same as prior period, unchanged from 0001437749-25-002900:notes:3]

[0001437749-25-023968:notes:4]
These unaudited condensed consolidated financial statements of the Company have been prepared on a going concern basis in accordance with United States generally accepted accounting principles (“GAAP”) and the Securities and Exchange Commission’s (“SEC”) instructions to Form 10-Q. All significant intercompany accounts and transactions are eliminated in consolidation. Investments in entities in which we do not have a controlling interest are accounted for under the equity method of accounting. The going concern basis of presentation assumes that the Company will continue operations and will be able to realize its assets and discharge its liabilities and commitments in the normal course of business. Certain information and footnote disclosures normally included in the condensed consolidated financial statements prepared in accordance with GAAP have been omitted pursuant to those instructions. The year-end balance sheet data was derived from audited financial statements but does not include all disclosures required by GAAP. The unaudited condensed consolidated financial statements, in the opinion of management, reflect all adjustments (consisting of normal recurring adjustments) necessary for a fair statement of the results for the interim periods ended  June 30, 2025 and 2024, and the financial position at  June 30, 2025; however, these results are not necessarily indicative of results which  may be expected for the full year. The interim condensed consolidated financial statements, and notes thereto, should be read in conjunction with the audited condensed consolidated financial statements for the year ended  March 31, 2025, and notes thereto, included in the Company’s Annual Report on Form 10-K for the year ended  March 31, 2025 filed with the SEC on  May 21, 2025.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001437749-25-023968:notes:5]
[same as prior period, unchanged from 0001437749-25-002900:notes:13]

[0001437749-25-023968:notes:6]
Acquisition of NWL

[0001437749-25-023968:notes:7]
On  August 1, 2024 (the "Acquisition Date"), the Company entered into a Stock Purchase Agreement (the “Stock Purchase Agreement”) with the selling stockholders named therein. Pursuant to the terms of the Stock Purchase Agreement and concurrently with entering into such agreement, the Company acquired all of the issued and outstanding shares of capital stock of Megatran Industries, Inc. ("Megatran") (the "NWL Acquisition"). Megatran's wholly-owned subsidiary, NWL, Inc. (together with Megatran, "NWL"), is a U.S.-based global provider of engineered power conversion solutions for demanding industrial and military applications.

[0001437749-25-023968:notes:8]
The NWL Acquisition has been accounted for under the purchase method of accounting in accordance with ASC 805, Business Combinations. The Company allocated the purchase price to the assets acquired and liabilities assumed at their estimated fair values as of the Acquisition Date. The excess of the purchase price paid by the Company over the estimated fair value of net assets acquired has been recorded as goodwill.

[0001437749-25-023968:notes:9]
[same as prior period, unchanged from 0001437749-25-002900:notes:18]

[0001437749-25-023968:notes:10]
| Cash payments | $30.0 |
| Issuance of 1,297,600 shares of Company’s common stock | $31.4 |

[0001437749-25-023968:notes:11]
At the Acquisition Date, in addition to the $30.0 million cash, the Company valued the Company’s common stock, using $24.16 per share, which was the closing price on the day prior to the day that the Company completed the NWL Acquisition. Acquisition costs of $1.1 million were included in selling, general and administrative ("SG&A") for the fiscal year ended  March 31, 2025.

[0001437749-25-023968:notes:12]
The following table summarizes the allocation of the purchase price based on the estimated fair values of the assets acquired and liabilities assumed and related deferred income taxes in connection with the NWL Acquisition as of the Acquisition Date and reflective of measurement period adjustments (in millions):

[0001437749-25-023968:notes:13]
| Cash and cash equivalents |  | $ | 0.4 |  |
| Equity-method investments |  |  | 1.2 |  |
| Prepaid expenses and other current assets |  |  | 1.7 |  |
| Accounts receivable |  |  | 16.1 |  |
| Inventory |  |  | 23.1 |  |
| Property, plant, and equipment |  |  | 28.4 |  |
| Accounts payable and accrued expenses |  |  | (5.6 | ) |
| Deferred revenue |  |  | (5.0 | ) |
| Deferred tax liability |  |  | (5.6 | ) |
| Net tangible assets/(liabilities) |  |  | 54.7 |  |
| Backlog |  |  | 0.7 |  |
| Customer relationships |  |  | 1.3 |  |
| Net identifiable intangible assets |  |  | 2.0 |  |
| Goodwill |  |  | 4.7 |  |
| Total purchase consideration |  | $ | 61.4 |  |

[0001437749-25-023968:notes:14]
[same as prior period, unchanged from 0001437749-25-002900:notes:23]

[0001437749-25-023968:notes:15]
Inventory includes a $0.7 million adjustment to step up the inventory balance to fair value consistent with the purchase price allocation. The fair value was determined based on the estimated selling price of the inventory, less the remaining manufacturing and selling cost and a normal profit margin on those manufacturing and selling efforts. The inventory step up adjustment increased cost of revenue $0.7 million for the fiscal year ended  March 31, 2025 as the inventory was sold.

[0001437749-25-023968:notes:16]
[same as prior period, unchanged from 0001437749-25-002900:notes:25]

[0001437749-25-023968:notes:17]
[same as prior period, unchanged from 0001437749-25-002900:notes:26]

[0001437749-25-023968:notes:18]
Goodwill represents the value associated with the acquired workforce and expected synergies related to the business combination of the two companies. Goodwill resulting from the NWL Acquisition was assigned to the Company’s Grid business segment. Goodwill recognized in the NWL Acquisition is not deductible for tax purposes. This purchase price allocation is preliminary and has not been finalized as the analysis on the assets and liabilities acquired, primarily the tax related liability  may require further adjustments to our purchase accounting that could result in a measurement period adjustment that would impact the Company's reported net assets and goodwill as of  August 1, 2024. Material changes, if any, to the preliminary allocation summarized above will be reported once the related uncertainties are resolved, but no later than  August 1, 2025.

[0001437749-25-023968:notes:19]
[same as prior period, unchanged from 0001437749-25-002900:notes:28]

[0001437749-25-023968:notes:20]
The unaudited pro forma condensed consolidated statement of operations for the three months ended  June 30, 2025, and 2024 presented as if the NWL Acquisition had occurred on  April 1, 2024, is as follows:

[0001437749-25-023968:notes:21]
|  |  | Three Months Ended June 30, 2024 |  |
| Net Revenue |  | $ | 59,310 |  |
| Operating income (loss) |  |  | (3,342 | ) |
| Net income |  | $ | 1,791 |  |
| Net income per common share |  |  |  |  |
| Basic |  | $ | 0.05 |  |
| Diluted |  | $ | 0.05 |  |
| Shares - basic |  |  | 36,972 |  |
| Shares - diluted |  |  | 37,994 |  |

[0001437749-25-023968:notes:22]
The pro forma amounts include the historical operating results of the Company and NWL with appropriate adjustments that give effect to acquisition related costs, income taxes, intangible amortization resulting from the NWL Acquisition and certain conforming accounting policies of the Company. The pro forma amounts are not necessarily indicative of the operating results that would have occurred if the NWL Acquisition and related transactions had been completed at the beginning of the applicable periods presented. In addition, the pro forma amounts are not necessarily indicative of operating results in future periods.

[0001437749-25-023968:notes:23]
NWL contributed $17.8 million of revenue and $2.5 million in net income for the Company for the three months ended  June 30, 2025. Amortization expense of less than $0.1 million is included in the three months ended  June 30, 2025, as a result of the acquired intangible assets from the NWL Acquisition.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001437749-25-023968:notes:24]
[same as prior period, unchanged from 0001437749-25-002900:notes:33]

[0001437749-25-023968:notes:25]
The Company’s revenues in its Grid segment are derived primarily through enabling the transmission and distribution of power, providing planning services that allow it to identify power grid needs and risks, and developing ship protection systems for the U.S. Navy. The Company’s revenues in its Wind segment are derived primarily through supplying advanced power electronics and control systems, licensing its highly engineered wind turbine designs, and providing extensive customer support services to wind turbine manufacturers. The Company records revenue based on a five-step model in accordance with Accounting Standards Codification ("ASC") 606. For its customer contracts, the Company identifies the performance obligations, determines the transaction price, allocates the contract transaction price to the performance obligations, and recognizes the revenue when (or as) control of goods or services is transferred to the customer. For the three months ended  June 30, 2025, 91% of revenue, was recognized at the point in time when control transferred to the customer, with the remainder being recognized over time. For the three months ended  June 30, 2024, 88% of revenue was recognized at the point in time when control transferred to the customer, with the remainder being recognized over time.

[0001437749-25-023968:notes:26]
[same as prior period, unchanged from 0001437749-25-002900:notes:35]

[0001437749-25-023968:notes:27]
[same as prior period, unchanged from 0001437749-25-002900:notes:36]

[0001437749-25-023968:notes:28]
[same as prior period, unchanged from 0001437749-25-002900:notes:37]

[0001437749-25-023968:notes:29]
[same as prior period, unchanged from 0001437749-25-002900:notes:38]

[0001437749-25-023968:notes:30]
[same as prior period, unchanged from 0001437749-25-002900:notes:39]

[0001437749-25-023968:notes:31]
The Company records revenue net of sales tax, value added tax, excise tax and other taxes collected concurrent with revenue-producing activities. The Company has elected to recognize the cost for freight and shipping when control over the products sold passes to customers and revenue is recognized. The Company has elected to recognize incremental costs of obtaining a contract as expense when incurred except in contracts where the amortization period would exceed twelve months. As of  June 30, 2025 and  March 31, 2025, the Company's capitalized incremental contract costs were not material. The Company has elected not to adjust the promised amount of consideration for the effects of a significant financing component if the period of financing is twelve months or less.  The Company has elected to recognize revenue based on the as invoiced practical expedient if there is a right to consideration from a customer in an amount that corresponds directly with the value of the Company's performance.

[0001437749-25-023968:notes:32]
[same as prior period, unchanged from 0001437749-25-002900:notes:41]

[0001437749-25-023968:notes:33]
[same as prior period, unchanged from 0001437749-25-002900:notes:42]

[0001437749-25-023968:notes:34]
|  |  | Three Months Ended June 30, 2025 |  |
| Product Line: |  | Grid |  |  | Wind |  |
| Equipment and systems |  | $ | 55,521 |  |  | $ | 11,881 |  |
| Services and technology development |  |  | 4,566 |  |  |  | 390 |  |
| Total |  | $ | 60,087 |  |  | $ | 12,271 |  |
| Region: |  |  |  |  |  |  |  |  |
| Americas |  | $ | 38,020 |  |  | $ | — |  |
| Asia Pacific |  |  | 18,304 |  |  |  | 12,271 |  |
| EMEA |  |  | 3,763 |  |  |  | — |  |
| Total |  | $ | 60,087 |  |  | $ | 12,271 |  |

[0001437749-25-023968:notes:35]
|  |  | Three Months Ended June 30, 2024 |  |
| Product Line: |  | Grid |  |  | Wind |  |
| Equipment and systems |  | $ | 29,726 |  |  | $ | 7,424 |  |
| Services and technology development |  |  | 2,610 |  |  |  | 530 |  |
| Total |  | $ | 32,336 |  |  | $ | 7,954 |  |
| Region: |  |  |  |  |  |  |  |  |
| Americas |  | $ | 30,479 |  |  | $ | — |  |
| Asia Pacific |  |  | 1,199 |  |  |  | 7,952 |  |
| EMEA |  |  | 658 |  |  |  | 2 |  |
| Total |  | $ | 32,336 |  |  | $ | 7,954 |  |

[0001437749-25-023968:notes:36]
As of  June 30, 2025 and 2024, the Company’s contract assets and liabilities primarily relate to the timing differences between cash received from a customer in connection with contractual rights to invoicing and the timing of revenue recognition following completion of performance obligations. The Company's accounts receivable balance is made up entirely of customer contract related balances. Changes in the Company’s contract assets, which are included in “Unbilled accounts receivable” and “Deferred program costs” (see Note 8, “Accounts Receivable” and Note 9, “Inventory” for a reconciliation to the condensed consolidated balance sheets) and "Contract liabilities", which are included in the current portion and long-term portion of "Deferred revenue" in the Company’s condensed consolidated balance sheets, are as follows (in thousands):

[0001437749-25-023968:notes:37]
|  |  | Unbilled Accounts Receivable |  |  | Deferred Program Costs |  |  | Contract Liabilities |  |
| Beginning balance as of March 31, 2025 |  | $ | 6,376 |  |  | $ | 5,756 |  |  | $ | 76,133 |  |
| Increases for costs incurred to fulfill performance obligations |  |  | — |  |  |  | 3,907 |  |  |  | — |  |
| Increase (decrease) due to customer billings |  |  | (3,189 | ) |  |  | — |  |  |  | 30,863 |  |
| Decrease due to cost recognition on completed performance obligations |  |  | — |  |  |  | (4,093 | ) |  |  | — |  |
| Increase (decrease) due to recognition of revenue based on transfer of control of performance obligations |  |  | 6,876 |  |  |  | — |  |  |  | (32,108 | ) |
| Other changes and FX impact |  |  | 20 |  |  |  | 46 |  |  |  | 1,003 |  |
| Ending balance as of June 30, 2025 |  | $ | 10,083 |  |  | $ | 5,616 |  |  | $ | 75,891 |  |

[0001437749-25-023968:notes:38]
|  |  | Unbilled Accounts Receivable |  |  | Deferred Program Costs |  |  | Contract Liabilities |  |
| Beginning balance as of March 31, 2024 |  | $ | 6,150 |  |  | $ | 2,523 |  |  | $ | 57,829 |  |
| Increases for costs incurred to fulfill performance obligations |  |  | — |  |  |  | 2,119 |  |  |  | — |  |
| Increase (decrease) due to customer billings |  |  | (3,521 | ) |  |  | — |  |  |  | 27,577 |  |
| Decrease due to cost recognition on completed performance obligations |  |  | — |  |  |  | (606 | ) |  |  | — |  |
| Increase (decrease) due to recognition of revenue based on transfer of control of performance obligations |  |  | 2,291 |  |  |  | — |  |  |  | (22,443 | ) |
| Other changes and FX impact |  |  | (2 | ) |  |  | (2 | ) |  |  | (50 | ) |
| Ending balance as of June 30, 2024 |  | $ | 4,918 |  |  | $ | 4,034 |  |  | $ | 62,913 |  |

[0001437749-25-023968:notes:39]
The Company’s remaining performance obligations represent the unrecognized revenue value of the Company’s contractual commitments. The Company’s performance obligations  may vary significantly each reporting period based on the timing of major new contractual commitments. As of  June 30, 2025, the Company had outstanding performance obligations on existing contracts under ASC 606 to be recognized in the next twelve months of approximately $215.2 million. There are also approximately $88.4 million of outstanding performance obligations to be recognized over a period of thirteen to sixty months. The remaining performance obligations are subject to customer actions and therefore the timing of revenue recognition cannot be reasonably estimated.

[0001437749-25-023968:notes:40]
The following table sets forth customers who represented 10% or more of the Company’s total revenues for the three months ended  June 30, 2025, and 2024:

[0001437749-25-023968:notes:41]
|  |  |  | Three Months Ended |  |
|  | Reportable |  | June 30, |  |
|  | Segment |  | 2025 |  |  | 2024 |  |
| Fuji Bridex Pte Ltd | Grid |  |  | 21 | % |  | <10 | % |
| Inox Wind Limited | Wind |  |  | 16 | % |  |  | 18 | % |


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001437749-25-023968:notes:42]
[same as prior period, unchanged from 0001437749-25-002900:notes:51]

[0001437749-25-023968:notes:43]
The Company accounts for its stock-based compensation at fair value. The following table summarizes stock-based compensation expense by financial statement line item for the three months ended  June 30, 2025, and 2024 (in thousands):

[0001437749-25-023968:notes:44]
|  |  | Three Months Ended June 30, |  |
|  |  | 2025 |  |  | 2024 |  |
| Cost of revenues |  | $ | 340 |  |  | $ | 58 |  |
| Research and development |  |  | 687 |  |  |  | 143 |  |
| Selling, general and administrative |  |  | 3,499 |  |  |  | 1,028 |  |
| Total |  | $ | 4,526 |  |  | $ | 1,229 |  |

[0001437749-25-023968:notes:45]
The Company issued 880,000 shares of restricted stock and 39,445 shares of immediately vested common stock during the three months ended  June 30, 2025. The Company issued 25,000 shares of restricted stock and 19,200 shares of immediately vested common stock during the three months ended  June 30, 2024. These restricted stock awards generally vest over 2-3 years. Awards for restricted stock include both time-based and performance-based awards. For options and restricted stock awards that vest upon the passage of time, expense is being recorded over the vesting period. Performance-based awards are expensed over the requisite service period based on probability of achievement.

[0001437749-25-023968:notes:46]
The Company granted 2,112 stock options during the three months ended  June 30, 2025. The Company granted no stock options during the three months ended  June 30, 2024. The stock options granted during the three months ended  June 30, 2025 will vest over 2 years. The estimated fair value of the Company’s stock-based awards, less expected annual forfeitures, is amortized over the awards’ service period. There were less than $0.1 million of unrecognized compensation costs for unvested stock options as of  June 30, 2025. This expense will be recognized over a weighted average period of approximately 1.9 years. The total unrecognized compensation cost for unvested outstanding restricted stock was $31.4 million as of  June 30, 2025. This expense will be recognized over a weighted-average expense period of approximately 2.1 years.

[0001437749-25-023968:notes:47]
The weighted average assumptions used in the Black Scholes valuation model for stock options granted during the three months ended  June 30, 2025 are as follows:

[0001437749-25-023968:notes:48]
|  |  | Three Months Ended June 30, |  |
|  |  | 2025 |  |
| Expected volatility |  |  | 74.01 | % |
| Risk-free interest rate |  |  | 4.19 | % |
| Expected life (years) |  |  | 6.31 |  |
| Dividend yield |  | None |  |


## us-gaap:EarningsPerShareTextBlock

[0001437749-25-023968:notes:49]
[same as prior period, unchanged from 0001437749-25-002900:notes:57]

[0001437749-25-023968:notes:50]
Basic net income (loss) per share (“EPS”) is computed by dividing net income (loss) by the weighted-average number of common shares outstanding for the period. Where applicable, diluted EPS is computed by dividing the net income by the weighted-average number of common shares and dilutive common equivalent shares outstanding during the period, calculated using the treasury stock method. Common equivalent shares include the effect of restricted stock, exercise of stock options and warrants and contingently issuable shares. Stock options and warrants that are out-of-the-money with exercise prices greater than the average market price of the underlying common shares and shares of performance-based restricted stock where the contingency was not met are excluded from the computation of diluted EPS as the effect of their inclusion would be anti-dilutive. For the three months ended  June 30, 2025, 475,329 shares were not included in the calculation of diluted EPS. Of these, 474,517 were shares of performance-based restricted stock where the contingency was not met and 812 shares relate to outstanding stock awards that were considered anti-dilutive. For the three months ended  June 30, 2024, 336,206 shares were not included in the calculation of diluted EPS. Of these, 300,000 relate to shares associated with the contingent consideration derivative liability for which the contingency has not yet been met, and 36,206 relate to outstanding stock options as they were considered anti-dilutive.

[0001437749-25-023968:notes:51]
The following table reconciles the numerators and denominators of the earnings per share calculation for the three months ended  June 30, 2025, and 2024 (in thousands, except per share data):

[0001437749-25-023968:notes:52]
|  |  | Three Months Ended June 30, |  |
|  |  | 2025 |  |  | 2024 |  |
| Numerator: |  |  |  |  |  |  |  |  |
| Net income (loss) |  | $ | 6,724 |  |  | $ | (2,524 | ) |
| Denominator: |  |  |  |  |  |  |  |  |
| Weighted-average shares of common stock outstanding |  |  | 40,863 |  |  |  | 36,991 |  |
| Weighted-average shares subject to repurchase |  |  | (1,988 | ) |  |  | (1,315 | ) |
| Shares used in per-share calculation ― basic |  |  | 38,875 |  |  |  | 35,676 |  |
| Shares used in per-share calculation ― diluted |  |  | 39,742 |  |  |  | 35,676 |  |
| Net income (loss) per share ― basic |  | $ | 0.17 |  |  | $ | (0.07 | ) |
| Net income (loss) per share ― diluted |  | $ | 0.17 |  |  | $ | (0.07 | ) |


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001437749-25-023968:notes:53]
[same as prior period, unchanged from 0001437749-25-002900:notes:61]

[0001437749-25-023968:notes:54]
[same as prior period, unchanged from 0001437749-25-002900:notes:62]

[0001437749-25-023968:notes:55]
Goodwill represents the difference between the purchase price and the fair value of the identifiable tangible and intangible net assets when accounted for using the purchase method of accounting. Goodwill is not amortized but reviewed for impairment. The Company's goodwill balance relates to the NWL Acquisition in fiscal 2024, the acquisition of Neeltran, Inc. in fiscal 2021, the Northeast Power Systems, Inc. ("NEPSI") acquisition in fiscal 2020, and the acquisition of Infinia Technology Corporation in fiscal 2017 and is reported in the Grid business segment. Goodwill is reviewed annually on  February 28th and whenever events or changes in circumstances indicate that the carrying value of the goodwill might not be recoverable. Goodwill increased by $4.7 million during the fiscal year ended  March 31, 2025, related to the NWL Acquisition. There were no changes to Goodwill during the three months ended  June 30, 2025.

[0001437749-25-023968:notes:56]
The Company did not identify any triggers to assess impairment in the three months ended  June 30, 2025 or 2024.

[0001437749-25-023968:notes:57]
[same as prior period, unchanged from 0001437749-25-002900:notes:66]

[0001437749-25-023968:notes:58]
Intangible assets at  June 30, 2025 and  March 31, 2025 consisted of the following (in thousands):

[0001437749-25-023968:notes:59]
|  |  | June 30, 2025 |  |  | March 31, 2025 |  |  |  |  |  |
|  |  | Gross Amount |  |  | Accumulated Amortization |  |  | Net Book Value |  |  | Gross Amount |  |  | Accumulated Amortization |  |  | Net Book Value |  |  | Estimated Useful Life |  |
| Backlog |  |  | 1,381 |  |  |  | (1,381 | ) |  |  | — |  |  |  | 1,381 |  |  |  | (1,381 | ) |  |  | — |  |  |  | 2 |  |
| Trade name and trademarks |  |  | 1,800 |  |  |  | — |  |  |  | 1,800 |  |  |  | 1,800 |  |  |  | — |  |  |  | 1,800 |  |  | Indefinite |  |
| Customer relationships |  |  | 10,880 |  |  |  | (8,116 | ) |  |  | 2,764 |  |  |  | 10,880 |  |  |  | (7,901 | ) |  |  | 2,980 |  |  |  | 7-10 |  |
| Core technology and know-how |  |  | 5,970 |  |  |  | (4,955 | ) |  |  | 1,015 |  |  |  | 5,970 |  |  |  | (4,834 | ) |  |  | 1,136 |  |  |  | 5-10 |  |
| Intangible assets |  | $ | 20,031 |  |  | $ | (14,452 | ) |  | $ | 5,579 |  |  | $ | 20,031 |  |  | $ | (14,116 | ) |  | $ | 5,916 |  |  |  |  |  |

[0001437749-25-023968:notes:60]
The Company recorded intangible amortization expense related to customer relationship and core technology and know-how of $0.3 million in the three months ended  June 30, 2025. The Company recorded intangible amortization expense related to customer relationship and core technology and know-how of $0.4 million in the three months ended  June 30, 2024.

[0001437749-25-023968:notes:61]
[same as prior period, unchanged from 0001437749-25-002900:notes:70]

[0001437749-25-023968:notes:62]
| Years ending March 31, |  | Total |  |
| 2026 (remaining) |  |  | 1,012 |  |
| 2027 |  |  | 1,213 |  |
| 2028 |  |  | 671 |  |
| 2029 |  |  | 201 |  |
| 2030 |  |  | 128 |  |
| Thereafter |  |  | 554 |  |
| Total |  | $ | 3,779 |  |

[0001437749-25-023968:notes:63]
[same as prior period, unchanged from 0001437749-25-002900:notes:72]


## us-gaap:FairValueDisclosuresTextBlock

[0001437749-25-023968:notes:64]
[same as prior period, unchanged from 0001437749-25-002900:notes:73]

[0001437749-25-023968:notes:65]
[same as prior period, unchanged from 0001437749-25-002900:notes:74]

[0001437749-25-023968:notes:66]
[same as prior period, unchanged from 0001437749-25-002900:notes:75]

[0001437749-25-023968:notes:67]
The Company provides a gross presentation of activity within Level 3 measurement roll-forward and details of transfers in and out of Level 1 and 2 measurements. A change in the hierarchy of an investment from its current level is reflected in the period during which the pricing methodology of such investment changes. Disclosure of the transfer of securities from Level 1 to Level 2 or Level 3 is made in the event that the related security is significant to total cash and investments. The Company did not have any transfers of assets and liabilities from Level 1, Level 2 or Level 3 of the fair value measurement hierarchy during the three months ended  June 30, 2025.

[0001437749-25-023968:notes:68]
[same as prior period, unchanged from 0001437749-25-002900:notes:77]

[0001437749-25-023968:notes:69]
[same as prior period, unchanged from 0001437749-25-002900:notes:78]

[0001437749-25-023968:notes:70]
[same as prior period, unchanged from 0001437749-25-002900:notes:79]

[0001437749-25-023968:notes:71]
Cash equivalents consist of highly liquid instruments with maturities of three months or less that are regarded as high quality, low risk investments and are measured using such inputs as quoted prices, and are classified within Level 1 of the valuation hierarchy. Cash equivalents consist principally of money market accounts.

[0001437749-25-023968:notes:72]
Short-term Cash Instruments

[0001437749-25-023968:notes:73]
Short-term cash instruments consist of highly liquid instruments with maturities of three months or less that are regarded as high quality, low risk investments and are measured using such inputs as quoted prices in markets that are not active, and are classified within Level 2 of the valuation hierarchy. Short-term cash instruments consist principally of certificates of deposits.

[0001437749-25-023968:notes:74]
The following table provides the assets and liabilities carried at fair value on a recurring basis, measured as of  June 30, 2025 and  March 31, 2025 (in thousands):

[0001437749-25-023968:notes:75]
|  |  | Total Carrying Value |  |  | Quoted Prices in Active Markets (Level 1) |  |  | Significant Other Observable Inputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |
| June 30, 2025: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash equivalents |  | $ | 175,654 |  |  | $ | 175,654 |  |  | $ | — |  |  | $ | — |  |
| Short-term cash instruments |  | $ | 1,401 |  |  | $ | — |  |  | $ | 1,401 |  |  | $ | — |  |

[0001437749-25-023968:notes:76]
|  |  | Total Carrying Value |  |  | Quoted Prices in Active Markets (Level 1) |  |  | Significant Other Observable Inputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |
| March 31, 2025 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash equivalents |  | $ | 51,230 |  |  | $ | 51,230 |  |  | $ | — |  |  | $ | — |  |
| Short-term cash instruments |  | $ | 1,404 |  |  | $ | — |  |  | $ | 1,404 |  |  | $ | — |  |


## amsc:AccountsReceivableTextBlock

[0001437749-25-023968:notes:77]
[same as prior period, unchanged from 0001437749-25-002900:notes:88]

[0001437749-25-023968:notes:78]
Accounts receivable at  June 30, 2025 and  March 31, 2025 consisted of the following (in thousands):

[0001437749-25-023968:notes:79]
|  |  | June 30, 2025 |  |  | March 31, 2025 |  |
| Accounts receivable (billed) |  | $ | 44,601 |  |  | $ | 39,810 |  |
| Accounts receivable (unbilled) |  |  | 10,083 |  |  |  | 6,376 |  |
| Accounts receivable |  | $ | 54,684 |  |  | $ | 46,186 |  |


## us-gaap:InventoryDisclosureTextBlock

[0001437749-25-023968:notes:80]
[same as prior period, unchanged from 0001437749-25-002900:notes:91]

[0001437749-25-023968:notes:81]
Inventory, net of reserves, at  June 30, 2025 and  March 31, 2025 consisted of the following (in thousands):

[0001437749-25-023968:notes:82]
|  |  | June 30, 2025 |  |  | March 31, 2025 |  |
| Raw materials |  | $ | 37,184 |  |  | $ | 35,892 |  |
| Work-in-process |  |  | 22,459 |  |  |  | 19,633 |  |
| Finished goods |  |  | 6,343 |  |  |  | 9,888 |  |
| Deferred program costs |  |  | 5,616 |  |  |  | 5,756 |  |
| Net inventory |  | $ | 71,602 |  |  | $ | 71,169 |  |

[0001437749-25-023968:notes:83]
The Company recorded inventory write-downs of $0.7 million and $0.5 million for the three months ended  June 30, 2025 and 2024, respectively. These write-downs were based on the Company's evaluation of its inventory on hand for excess quantities and obsolescence.

[0001437749-25-023968:notes:84]
Deferred program costs as of  June 30, 2025 and  March 31, 2025 primarily represent costs incurred on programs where the Company needs to complete performance obligations before the related revenue and costs will be recognized.


## us-gaap:PropertyPlantAndEquipmentDisclosureTextBlock

[0001437749-25-023968:notes:85]
10. Property, Plant and Equipment

[0001437749-25-023968:notes:86]
The cost and accumulated depreciation of property, plant and equipment at  June 30, 2025 and  March 31, 2025 are as follows (in thousands):

[0001437749-25-023968:notes:87]
|  |  | June 30, 2025 |  |  | March 31, 2025 |  |
| Land |  | $ | 22,650 |  |  | $ | 22,650 |  |
| Construction in progress – equipment |  |  | 1,544 |  |  |  | 1,371 |  |
| Buildings |  |  | 7,532 |  |  |  | 7,528 |  |
| Equipment and software |  |  | 48,375 |  |  |  | 47,774 |  |
| Furniture and fixtures |  |  | 1,682 |  |  |  | 1,672 |  |
| Leasehold improvements |  |  | 8,026 |  |  |  | 7,969 |  |
| Property, plant and equipment, gross |  |  | 89,809 |  |  |  | 88,964 |  |
| Less accumulated depreciation |  |  | (51,288 | ) |  |  | (50,392 | ) |
| Property, plant and equipment, net |  | $ | 38,521 |  |  | $ | 38,572 |  |

[0001437749-25-023968:notes:88]
Depreciation expense was $0.9 million and $0.6 million for the three months ended  June 30, 2025 and 2024, respectively.


## us-gaap:EquityMethodInvestmentsDisclosureTextBlock

[0001437749-25-023968:notes:89]
11. Equity-Method Investments

[0001437749-25-023968:notes:90]
[same as prior period, unchanged from 0001437749-25-002900:notes:105]

[0001437749-25-023968:notes:91]
[same as prior period, unchanged from 0001437749-25-002900:notes:106]

[0001437749-25-023968:notes:92]
The Company treats the equity investment in the condensed consolidated financial statements under the equity method. Equity method investments are equity securities in entities the Company does not control but over which it has the ability to exercise significant influence. These investments are accounted for under the equity method of accounting in accordance with ASC 323, Investments — Equity Method and Joint Ventures. Equity method investments are measured at cost minus impairment, if any, plus or minus the Company’s share of an investee’s income or loss, less distributions received. As of  June 30, 2025 the Company did not have material accounts receivable nor accounts payable balances with NWL Pacific. The Company's investment in NWL Pacific was $1.4 million and $1.1 million as of  June 30, 2025 and  March 31, 2025, respectively.

[0001437749-25-023968:notes:93]
The table below presents the summarized financial information for periods presented post acquisition, as provided to the Company by the investee, for the unconsolidated company (in thousands):

[0001437749-25-023968:notes:94]
|  |  | Three Months Ended June 30, |  |
|  |  | 2025 |  |
| Net Revenue |  | $ | 2,599 |  |
| Gross Profit |  |  | 1,160 |  |
| Income from operation |  |  | 657 |  |
| Net income |  | $ | 745 |  |


## us-gaap:AccountsPayableAndAccruedLiabilitiesDisclosureTextBlock

[0001437749-25-023968:notes:95]
12. Accounts Payable and Accrued Expenses

[0001437749-25-023968:notes:96]
Accounts payable and accrued expenses at  June 30, 2025 and  March 31, 2025 consisted of the following (in thousands):

[0001437749-25-023968:notes:97]
|  |  | June 30, 2025 |  |  | March 31, 2025 |  |
| Accounts payable |  | $ | 11,861 |  |  | $ | 6,733 |  |
| Accrued inventories in-transit |  |  | 2,238 |  |  |  | 2,111 |  |
| Accrued other miscellaneous expenses |  |  | 5,144 |  |  |  | 3,600 |  |
| Accrued contract loss |  |  | 97 |  |  |  | 97 |  |
| Advanced deposits |  |  | 4,636 |  |  |  | 1,267 |  |
| Accrued compensation |  |  | 9,307 |  |  |  | 13,418 |  |
| Income taxes payable |  |  | 452 |  |  |  | 305 |  |
| Accrued product warranty |  |  | 3,240 |  |  |  | 3,033 |  |
| Accrued commissions |  |  | 1,426 |  |  |  | 1,718 |  |
| Total |  | $ | 38,401 |  |  | $ | 32,282 |  |

[0001437749-25-023968:notes:98]
[same as prior period, unchanged from 0001437749-25-002900:notes:113]

[0001437749-25-023968:notes:99]
[same as prior period, unchanged from 0001437749-25-002900:notes:114]

[0001437749-25-023968:notes:100]
|  |  | Three Months Ended June 30, |  |
|  |  | 2025 |  |  | 2024 |  |
| Balance at beginning of period |  | $ | 3,033 |  |  | $ | 2,363 |  |
| Provisions for warranties during the period |  |  | 549 |  |  |  | 476 |  |
| Settlements during the period |  |  | (342 | ) |  |  | (297 | ) |
| Balance at end of period |  | $ | 3,240 |  |  | $ | 2,542 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0001437749-25-023968:notes:101]
13. Income Taxes

[0001437749-25-023968:notes:102]
The Company recorded income tax expense of $0.2 million in both the three months ended  June 30, 2025 and 2024.

[0001437749-25-023968:notes:103]
On  July 4, 2025, the reconciliation bill, commonly referred to as the One Big Beautiful Bill (OBBB) was signed into law, which includes a broad range of tax reform provisions that  may affect the company's financial results. The OBBB allows an elective deduction for domestic Research and Development (R&D), a reinstatement of elective 100% first-year bonus depreciation, and a more favorable tax rate on Foreign-derived Deduction Eligible Income and income from non-U.S. subsidiaries (Net CFC Tested Income), among other provisions. The Company is currently evaluating the impact of these provisions which could affect the Company's effective tax rate and deferred tax assets in 2025 and future periods. A quantitative estimate of the specific financial effects cannot be reasonably determined at this time due to the complexity of the changes in the tax reform. The impact of those tax provisions in the OBBB will depend on our facts in each year and anticipated guidance from the U.S. Department of the Treasury.

[0001437749-25-023968:notes:104]
Accounting for income taxes requires a two-step approach to recognizing and measuring uncertain tax positions. The first step is to evaluate the tax position for recognition by determining if, based on the technical merits, it is more likely than not the position will be sustained upon audit, including resolution of related appeals or litigation processes, if any. The second step is to measure the tax benefit as the largest amount that is more than 50% likely to be realized upon ultimate settlement. The Company re-evaluates these uncertain tax positions on a quarterly basis. The evaluation is based on factors including, but not limited to, changes in facts or circumstances, changes in tax law, effectively settled issues under audit and new audit activity. Any changes in these factors could result in the recognition of a tax benefit or an additional charge to the tax provision. The Company did not identify any uncertain tax positions in the three months ended  June 30, 2025 and did not have any gross unrecognized tax benefits as of  June 30, 2025.

[0001437749-25-023968:notes:105]
On a quarterly basis, the Company reassesses the valuation allowance on deferred income tax assets, weighing positive and negative evidence to assess the recoverability of the deferred tax assets. As of  June 30, 2025, the Company continues to maintain a valuation allowance to reduce the U.S. federal and state deferred tax assets to the amount that will more likely than not be realized. Given the Company’s positive trend in earnings, the Company will assess during fiscal year 2025 whether sufficient positive evidence will exist to allow the Company to reach a conclusion that some or all of the U.S. valuation allowance will no longer be needed. A release of the valuation allowance would result in the recognition of deferred tax assets and a corresponding decrease to income tax expense in the period the release is recorded, the effect of which would be an increase in reported net income.


## amsc:BusinessCombinationContingentConsiderationTextBlock

[0001437749-25-023968:notes:106]
14. Contingent Consideration

[0001437749-25-023968:notes:107]
NEPSI Contingent Consideration

[0001437749-25-023968:notes:108]
On  October 1, 2020 (the "NEPSI Acquisition Date"), the Company entered into a Stock Purchase Agreement (the "NEPSI Stock Purchase Agreement") with the selling stockholders named therein. Pursuant to the terms of the NEPSI Stock Purchase Agreement and concurrently with entering into such agreement, the Company acquired all of the issued and outstanding (i) shares of capital stock of NEPSI, and (ii) membership interests of Northeast Power Realty, LLC, a New York limited liability company, which holds the real property that serves as NEPSI's headquarters (the "NEPSI Acquisition"). NEPSI is a U.S.-based global provider of medium-voltage metal-enclosed power capacitor banks and harmonic filter banks for use on electric power systems. NEPSI is a wholly-owned subsidiary of the Company and is operated by its Grid business segment. The purchase price was $26.0 million in cash and 873,657 restricted shares of common stock of the Company. As part of the transaction, the selling stockholders were entitled to receive up to an additional 1,000,000 shares of common stock of the Company upon the achievement of certain specified revenue objectives during varying periods of up to four years following closing of the NEPSI Acquisition. During the year ended  March 31, 2024, the Company issued 399,999 shares of common stock and cash in lieu of a fractional share of common stock, related to the achievement of specified revenue objectives in connection with the NEPSI Acquisition. One specified revenue objective, which would have earned the selling stockholders 300,000 shares of Company common stock, was not achieved. NEPSI recognized revenues in excess of $120.0 million during the four years after the NEPSI Acquisition Date. As a result, during the quarter ended  September 30, 2024, the Company issued 300,000 shares of common stock of the Company to the selling stockholders, following certification of the achievement of the specified earnout revenue objective. As of  September 30, 2024, the Company had settled all outstanding contingent consideration under the NEPSI Stock Purchase Agreement.

[0001437749-25-023968:notes:109]
The Company evaluated the NEPSI Acquisition earnout payment set forth in the NEPSI Stock Purchase Agreement, which was expected to require settlement in the Company's common stock, and determined the contingent consideration qualified for liability classification and derivative treatment under ASC 815, Derivatives and Hedging. As a result, for the periods in which the Company had outstanding contingent consideration, the fair value of the contingent consideration was remeasured and the resulting gain or loss was recognized in operating expenses until the share amount was fixed.

[0001437749-25-023968:notes:110]
NWL Contingent Consideration

[0001437749-25-023968:notes:111]
On  August 1, 2024, the Company entered into the Stock Purchase Agreement with the selling stockholders named therein. Pursuant to the terms of the Stock Purchase Agreement and concurrently with entering into such agreement, the Company acquired all of the issued and outstanding shares of Megatran for aggregate consideration in an amount equal to $61.4 million which consideration amount was subject to various adjustments set forth in the Stock Purchase Agreement. The value of the contingent consideration to make the sellers whole was determined to be de minimis at the time of the NWL Acquisition. On  September 23, 2024, the Company paid $3.3 million to the selling stockholders, which was calculated based on the agreed upon formula set forth in the Stock Purchase Agreement. As of  September 30, 2024, there were no remaining obligations to the selling stockholders of Megatran.

[0001437749-25-023968:notes:112]
[same as prior period, unchanged from 0001437749-25-002900:notes:126]

[0001437749-25-023968:notes:113]
|  |  | June 30, |  |  | March 31, |  |
| Fiscal Year 2024 |  | 2024 |  |  | 2024 |  |
| Revenue risk premium |  |  | 5.50 | % |  |  | 5.50 | % |
| Revenue volatility |  |  | 27.5 | % |  |  | 24.8 | % |
| Stock Price |  | $ | 23.39 |  |  | $ | 13.51 |  |
| Payment delay (days) |  |  | 80 |  |  |  | 80 |  |
| Fair value (millions) |  | $ | 7.0 |  |  | $ | 3.1 |  |

[0001437749-25-023968:notes:114]
The Company did not record any activity related to contingent consideration in the three months ended  June 30, 2025 as the liability was settled in the prior fiscal year. The Company recorded a loss of $3.9 million resulting from the increases in the fair value of the contingent consideration in the three months ended  June 30, 2024.


## us-gaap:LesseeOperatingLeasesTextBlock

[0001437749-25-023968:notes:115]
15. Leases

[0001437749-25-023968:notes:116]
[same as prior period, unchanged from 0001437749-25-002900:notes:132]

[0001437749-25-023968:notes:117]
All significant lease arrangements are recognized at lease commencement. Operating lease right–of-use assets and lease liabilities are recognized at commencement. The operating lease right-of-use asset includes any lease payments related to initial direct cost and prepayments and excludes any lease incentives. Lease expense is recognized on a straight-line basis over the lease term. The Company enters into a variety of operating lease agreements through the normal course of its business, but primarily real estate leases to support its operations. The real estate lease agreements generally provide for fixed minimum rental payments and the payment of real estate taxes and insurance. Many of these real estate leases have one or more renewal options that allow the Company, at its discretion, to renew the lease for varying periods up to five years or to terminate the lease. Only renewal options or termination rights that the Company believed were likely to be exercised were included in the lease calculations.

[0001437749-25-023968:notes:118]
The Company also enters into leases for vehicles, IT equipment and service agreements, and other leases related to its manufacturing operations that are also included in the right-of-use assets and lease liability accounts if they are for a term of longer than twelve months. However, many of these leases are either short-term in nature or immaterial. The Company has made the policy election to exclude short-term leases from the condensed consolidated balance sheets.

[0001437749-25-023968:notes:119]
Supplemental balance sheet information related to leases at  June 30, 2025, and  March 31, 2025 are as follows (in thousands):

[0001437749-25-023968:notes:120]
|  |  | June 30, 2025 |  |  | March 31, 2025 |  |
| Leases: |  |  |  |  |  |  |  |  |
| Right-of-use assets – Operating |  | $ | 4,041 |  |  | $ | 3,829 |  |
| Total right-of-use assets |  |  | 4,041 |  |  |  | 3,829 |  |
| Lease liabilities – ST Operating |  | $ | 854 |  |  | $ | 685 |  |
| Lease liabilities – LT Operating |  |  | 2,906 |  |  |  | 2,684 |  |
| Total lease liabilities |  | $ | 3,760 |  |  | $ | 3,369 |  |
| Weighted-average remaining lease term |  |  | 4.85 |  |  |  | 4.94 |  |
| Weighted-average discount rate |  |  | 14.57 | % |  |  | 14.94 | % |

[0001437749-25-023968:notes:121]
The costs related to the Company's operating leases for the three months ended  June 30, 2025 and 2024, are as follows (in thousands):

[0001437749-25-023968:notes:122]
|  |  | Three Months Ended |  |
|  |  | June 30, 2025 |  |
| Operating Leases: |  |  |  |  |
| Operating lease costs – fixed |  | $ | 416 |  |
| Operating lease costs – variable |  |  | 45 |  |
| Short-term lease costs |  |  | 41 |  |
| Total lease costs |  | $ | 502 |  |

[0001437749-25-023968:notes:123]
|  |  | Three Months Ended |  |
|  |  | June 30, 2024 |  |
| Operating Leases: |  |  |  |  |
| Operating lease costs – fixed |  | $ | 309 |  |
| Operating lease costs – variable |  |  | 45 |  |
| Short-term lease costs |  |  | 38 |  |
| Total lease costs |  | $ | 392 |  |

[0001437749-25-023968:notes:124]
[same as prior period, unchanged from 0001437749-25-002900:notes:143]

[0001437749-25-023968:notes:125]
|  |  | Leases |  |
| Year ending March 31, |  |  |  |  |
| 2026 (remaining) |  | $ | 896 |  |
| 2027 |  |  | 1,562 |  |
| 2028 |  |  | 1,007 |  |
| 2029 |  |  | 397 |  |
| 2030 |  |  | 326 |  |
| Thereafter |  |  | 1,228 |  |
| Total minimum lease payments |  |  | 5,416 |  |
| Less: interest |  |  | (1,656 | ) |
| Present value of lease liabilities |  | $ | 3,760 |  |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001437749-25-023968:notes:126]
16. Commitments and Contingencies

[0001437749-25-023968:notes:127]
Legal Contingencies

[0001437749-25-023968:notes:128]
From time to time, the Company is involved in legal and administrative proceedings and claims of various types. The Company records a liability in its condensed consolidated financial statements for these matters when a loss is known or considered probable and the amount can be reasonably estimated. The Company reviews these estimates each accounting period as additional information is known and adjusts the loss provision when appropriate. If a matter is both probable to result in a liability and the amounts of loss can be reasonably estimated, the Company estimates and discloses the possible loss or range of loss to the extent necessary to make the condensed consolidated financial statements not misleading. If the loss is not probable or cannot be reasonably estimated, a liability is not recorded in its condensed consolidated financial statements.

[0001437749-25-023968:notes:129]
Other

[0001437749-25-023968:notes:130]
The Company enters into long-term construction contracts with customers that require the Company to obtain performance bonds. The Company is required to deposit an amount equivalent to some or all the face amount of the performance bonds into an escrow account until the termination of the bond. When the performance conditions are met, amounts deposited as collateral for the performance bonds are returned to the Company. In addition, the Company has various contractual arrangements in which minimum quantities of goods or services have been committed to be purchased on an annual basis.

[0001437749-25-023968:notes:131]
As of  June 30, 2025, the Company had $4.2 million of restricted cash included in long-term assets and $1.3 million of restricted cash included in current assets. As of  March 31, 2025, the Company had $4.3 million of restricted cash included in long term assets and $1.6 million of restricted cash included in current assets. These amounts included in restricted cash primarily represent deposits to secure letters of credit for various supply contracts and long-term projects or collateral deposits. These deposits are held in interest bearing accounts.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001437749-25-023968:notes:132]
17. Business Segments

[0001437749-25-023968:notes:133]
The Company reports its financial results in two reportable business segments: Grid and Wind. In accordance with ASC 280, Segment Reporting, the Company has identified two operating segments. The Company's operating segments reflect the way in which internally-reported financial information is used to make decisions and allocate resources.

[0001437749-25-023968:notes:134]
[same as prior period, unchanged from 0001437749-25-002900:notes:153]

[0001437749-25-023968:notes:135]
[same as prior period, unchanged from 0001437749-25-002900:notes:154]

[0001437749-25-023968:notes:136]
AMSC’s Chief Executive Officer Daniel McGahn is the chief operating decision maker. The chief operating decision maker uses segment operating income (loss) to allocate resources (including employees, property, and financial or capital resources) for each segment predominantly in the annual budget and forecasting process. The chief operating decision maker considers budget-to-actual variances on a monthly basis for segment operating income (loss) when making decisions about allocating capital and personnel to the segments. The chief operating decision maker also uses segment operating income or loss to assess the performance for each segment by comparing the results and return on assets of each segment with one another and in the compensation of certain employees.

[0001437749-25-023968:notes:137]
The following tables (i) summarize total sales by segment and (ii) reconcile each segment's sales to their respective segment operating income, including segment operating expenses, for each of the three months ended  June 30, 2025 and 2024 (in thousands):

[0001437749-25-023968:notes:138]
|  |  | Three Months Ended June 30, 2025 |  |
|  |  | Grid |  |  | Wind |  |  | Unallocated |  |  | Total |  |
| Segment operating income: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Revenues |  | $ | 60,087 |  |  | $ | 12,271 |  |  | $ | - |  |  | $ | 72,358 |  |
| Less (a) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Segment other operating expenses (b) |  |  | 55,932 |  |  |  | 10,782 |  |  |  | - |  |  |  | 66,714 |  |
| Segment operating income |  | $ | 4,155 |  |  | $ | 1,489 |  |  | $ | - |  |  | $ | 5,644 |  |

[0001437749-25-023968:notes:139]
(a) The significant expense categories and amounts align with the segment-level information that is regularly provided to the chief operating decision maker.

[0001437749-25-023968:notes:140]
(b) Segment other operating expense includes cost of sales, research and development expense, selling general, and administrative expense, and amortization of acquisition related intangibles.

[0001437749-25-023968:notes:141]
|  |  | Three Months Ended June 30, 2024 |  |
|  |  | Grid |  |  | Wind |  |  | Unallocated |  |  | Total |  |
| Segment operating income: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Revenues |  | $ | 32,336 |  |  | $ | 7,954 |  |  | $ | - |  |  | $ | 40,290 |  |
| Less (a) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Segment other operating expenses (b) |  |  | 32,573 |  |  |  | 7,088 |  |  |  | 3,920 |  |  |  | 43,581 |  |
| Segment operating income (loss) |  | $ | (237 | ) |  | $ | 866 |  |  | $ | (3,920 | ) |  | $ | (3,291 | ) |

[0001437749-25-023968:notes:142]
(b) Segment other operating expense includes cost of sales, research and development expense, selling general, and administrative expense, amortization of acquisition related intangibles, and gain/loss on contingent consideration.

[0001437749-25-023968:notes:143]
Unallocated corporate expenses included a net loss on contingent consideration $3.9 million in the three months ended  June 30, 2024.

[0001437749-25-023968:notes:144]
The reconciliation of segment operating loss to consolidated income before income taxes for the three months ended  June 30, 2025, and 2024, respectively, is as follows (in thousands):

[0001437749-25-023968:notes:145]
|  |  | Three Months Ended June 30, |  |
|  |  | 2025 |  |  | 2024 |  |
| Operating income (loss): |  | $ | 5,644 |  |  | $ | (3,291 | ) |
| Interest income, net |  |  | 932 |  |  |  | 1,120 |  |
| Other income (expense), net |  |  | 347 |  |  |  | (160 | ) |
| Income (loss) before income tax expense |  | $ | 6,923 |  |  | $ | (2,331 | ) |

[0001437749-25-023968:notes:146]
Depreciation and amortization expense by segment for the three months ended  June 30, 2025, and 2024, respectively, is as follows (in thousands):

[0001437749-25-023968:notes:147]
|  |  | Three Months Ended June 30, |  |
|  |  | 2025 |  |  | 2024 |  |
| Grid |  | $ | 1,202 |  |  | $ | 987 |  |
| Wind |  |  | 27 |  |  |  | 21 |  |
| Total |  | $ | 1,229 |  |  | $ | 1,008 |  |

[0001437749-25-023968:notes:148]
[same as prior period, unchanged from 0001437749-25-002900:notes:158]

[0001437749-25-023968:notes:149]
Total assets for the two business segments as of  June 30, 2025 and  March 31, 2025, are as follows (in thousands):

[0001437749-25-023968:notes:150]
|  |  | June 30, 2025 |  |  | March 31, 2025 |  |
| Grid |  | $ | 221,959 |  |  | $ | 211,520 |  |
| Wind |  |  | 17,437 |  |  |  | 13,697 |  |
| Corporate assets |  |  | 213,450 |  |  |  | 85,304 |  |
| Total |  | $ | 452,846 |  |  | $ | 310,521 |  |


## us-gaap:NewAccountingPronouncementsAndChangesInAccountingPrinciplesTextBlock

[0001437749-25-023968:notes:151]
18. Recent Accounting Pronouncements

[0001437749-25-023968:notes:152]
In  December 2023, the FASB issued ASU 2023-09, Income Taxes (Topic 740): Improvements to Income Tax Disclosures. The amendments in ASU 2023-09 address investor requests for more transparency about income tax information through improvements to income tax disclosures primarily related to the rate reconciliation and income taxes paid information. Following the release of ASU 2023-09 in  December 2023, the effective date was annual reporting periods beginning after  December 15, 2024. As of  June 30, 2025, the Company is evaluating the impact on its condensed consolidated financial statements.

[0001437749-25-023968:notes:153]
In  March 2024, the FASB issued ASU 2024-02, Codification Improvements—Amendments to Remove References to the Concepts Statements. The amendments in ASU 2024-02 contain amendments to the Codification that remove references to various FASB Concepts Statements. Following the release of ASU 2024-02 in  March 2024, the effective date was annual reporting periods beginning after  December 15, 2024. As of  June 30, 2025, the Company is evaluating the impact on its condensed consolidated financial statements.

[0001437749-25-023968:notes:154]
In  November 2024, the FASB issued ASU 2024-03, Income Statement—Reporting Comprehensive Income—Expense Disaggregation Disclosures. The amendments in ASU 2024-03 address investor requests for more disclosure of disaggregated financial reporting information about expenses presented in the income statement. Following the release of ASU 2024-03 in  November 2024, the effective date will be annual reporting periods beginning after  December 15, 2026. As of  June 30, 2025, the Company is evaluating the impact on its condensed consolidated financial statements.


## us-gaap:SubsequentEventsTextBlock

[0001437749-25-023968:notes:155]
19. Subsequent Events

[0001437749-25-023968:notes:156]
The Company has performed an evaluation of subsequent events through the time of filing this Quarterly Report on Form 10-Q with the SEC and has determined that there are no such events to report.
