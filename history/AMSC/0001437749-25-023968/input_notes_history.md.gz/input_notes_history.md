# AMSC note change history — 0001437749-25-002900 → 0001437749-25-023968


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2025-07-30):
[0001437749-25-023968:note_history:1]
As of  June 30, 2025, the Company had $4.2 million of restricted cash included in long-term assets and $1.3 million of restricted cash included in current assets. As of  March 31, 2025, the Company had $4.3 million of restricted cash included in long term assets and $1.6 million of restricted cash included in current assets. These amounts included in restricted cash primarily represent deposits to secure letters of credit for various supply contracts and long-term projects or collateral deposits. These deposits are held in interest bearing accounts.
  (was, 2025-02-05, similarity 0.9888):
[0001437749-25-002900:note_history:1]
As of  December 31, 2024, the Company had $3.5 million of restricted cash included in long-term assets and $1.3 million of restricted cash included in current assets. As of  March 31, 2024, the Company had $1.3 million of restricted cash included in long term assets and $0.5 million of restricted cash included in current assets. These amounts included in restricted cash primarily represent deposits to secure letters of credit for various supply contracts and long-term projects or collateral deposits. These deposits are held in interest bearing accounts.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2025-07-30):
[0001437749-25-023968:note_history:2]
1. Nature of the Business and Operations
  (was, 2025-02-05, similarity 0.8478):
[0001437749-25-002900:note_history:2]
1. Nature of the Business and Operations and Liquidity

- changed (2025-07-30):
[0001437749-25-023968:note_history:3]
These unaudited condensed consolidated financial statements of the Company have been prepared on a going concern basis in accordance with United States generally accepted accounting principles (“GAAP”) and the Securities and Exchange Commission’s (“SEC”) instructions to Form 10-Q. All significant intercompany accounts and transactions are eliminated in consolidation. Investments in entities in which we do not have a controlling interest are accounted for under the equity method of accounting. The going concern basis of presentation assumes that the Company will continue operations and will be able to realize its assets and discharge its liabilities and commitments in the normal course of business. Certain information and footnote disclosures normally included in the condensed consolidated financial statements prepared in accordance with GAAP have been omitted pursuant to those instructions. The year-end balance sheet data was derived from audited financial statements but does not include all disclosures required by GAAP. The unaudited condensed consolidated financial statements, in the opinion of management, reflect all adjustments (consisting of normal recurring adjustments) necessary for a fair statement of the results for the interim periods ended  June 30, 2025 and 2024, and the financial position at  June 30, 2025; however, these results are not necessarily indicative of results which  may be expected for the full year. The interim condensed consolidated financial statements, and notes thereto, should be read in conjunction with the audited condensed consolidated financial statements for the year ended  March 31, 2025, and notes thereto, included in the Company’s Annual Report on Form 10-K for the year ended  March 31, 2025 filed with the SEC on  May 21, 2025.
  (was, 2025-02-05, similarity 0.9655):
[0001437749-25-002900:note_history:3]
These unaudited condensed consolidated financial statements of the Company have been prepared on a going concern basis in accordance with United States generally accepted accounting principles (“GAAP”) and the Securities and Exchange Commission’s (“SEC”) instructions to Form 10-Q. Certain prior period amounts were reclassified to conform to the presentation in the current period. All significant intercompany accounts and transactions are eliminated in consolidation. Investments in entities in which we do not have a controlling interest are accounted for under the equity method of accounting. The going concern basis of presentation assumes that the Company will continue operations and will be able to realize its assets and discharge its liabilities and commitments in the normal course of business. Certain information and footnote disclosures normally included in the condensed consolidated financial statements prepared in accordance with GAAP have been omitted pursuant to those instructions. The year-end balance sheet data was derived from audited financial statements but does not include all disclosures required by GAAP. The unaudited condensed consolidated financial statements, in the opinion of management, reflect all adjustments (consisting of normal recurring adjustments) necessary for a fair statement of the results for the interim periods ended  December 31, 2024 and 2023 and the financial position at  December 31, 2024; however, these results are not necessarily indicative of results which  may be expected for the full year. The interim condensed consolidated financial statements, and notes thereto, should be read in conjunction with the audited condensed consolidated financial statements for the year ended  March 31, 2024, and notes thereto, included in the Company’s Annual Report on Form 10-K for the year ended  March 31, 2024 filed with the SEC on  May 29, 2024.

- removed (2025-07-30):
[0001437749-25-002900:note_history:4]
Liquidity

- removed (2025-07-30):
[0001437749-25-002900:note_history:5]
The Company has historically experienced recurring operating losses and as of  December 31, 2024, the Company had an accumulated deficit of $1,061.8 million. In addition, the Company has historically experienced recurring negative operating cash flows. At  December 31, 2024, the Company had cash and cash equivalents of $75.2 million. Cash provided by operations for the nine months ended  December 31, 2024 was $22.0 million.

- removed (2025-07-30):
[0001437749-25-002900:note_history:6]
In  January 2024, the Company filed a shelf registration statement on Form S-3 that will expire three years from the date on which it was declared effective,  March 15, 2027 (the “First Form S-3”). The First Form S-3 allows the Company to offer and sell from time-to-time up to $250 million of common stock, debt securities, warrants or units comprised of any combination of these securities, with $250 million available for future offerings as of  December 31, 2024. The First Form S-3 is intended to provide the Company flexibility to conduct registered sales of its securities, subject to market conditions, in order to fund its future capital needs. The terms of any future offering under the First Form S-3 will be established at the time of such offering and will be described in a prospectus supplement filed with the SEC prior to the completion of any such offering.

- removed (2025-07-30):
[0001437749-25-002900:note_history:7]
On  January 31, 2024, the Company entered into an underwriting agreement with Oppenheimer & Co. Inc., as a representative of the several underwriters named therein, relating to the issuance and sale (the "2024 Offering") of 6,210,000 shares of the Company's common stock at a public offering price of $11.25 per share. The net proceeds to the Company from the 2024 Offering were approximately $65.2 million, after deducting underwriting discounts and commissions and offering expenses payable by the Company. The 2024 Offering closed on  February 14, 2024.

- removed (2025-07-30):
[0001437749-25-002900:note_history:8]
On  August 1, 2024 (the "Acquisition Date"), the Company entered into a Stock Purchase Agreement (the “Stock Purchase Agreement”) with the selling stockholders named therein. Pursuant to the terms of the Stock Purchase Agreement and concurrently with entering into such agreement, the Company acquired all of the issued and outstanding shares of Megatran Industries, Inc. ("Megatran") (the "Acquisition"), for aggregate consideration in an amount equal to $61.4 million (the “Purchase Price”), which consideration amount was subject to various adjustments set forth in the Stock Purchase Agreement (including those described below) and consisted of: (a) (i) $25.0 million, minus (ii) the Indebtedness (as defined in the Stock Purchase Agreement) outstanding as of immediately prior to the closing, minus (iii) Company Expenses (as defined in the Stock Purchase Agreement) (collectively, the “Cash Purchase Price”); (b) a number of restricted shares (rounded up or down to the nearest whole share, as applicable) (the “Company Shares”) of the Company’s common stock, $.01 par value per share (“Common Stock”) equal to the quotient obtained by dividing (x) $31.4 million (the “Share Purchase Price”) by (y) the closing price per share of Common Stock on the Nasdaq Global Select Market on the last trading day immediately preceding the Acquisition Date; and (c) an additional cash payment equal to $5.0 million, as adjusted pursuant to Sections 5.6(c), (d), and (f) of the Stock Purchase Agreement (the “Additional Cash Purchase Price”). Megatran is now a wholly-owned subsidiary of the Company and, together with its wholly-owned subsidiaries and affiliates, is operated and reported as a component of its Grid business segment. On  September 23, 2024, the Company paid $3.3 million to the selling stockholders, which was calculated based on the agreed upon formula set forth in the Stock Purchase Agreement. This amount is reflected as the change in fair value of this contingent consideration in the nine months ended  December 31, 2024. As of  December 31, 2024, there are no remaining obligations to the selling stockholders of Megatran.

- removed (2025-07-30):
[0001437749-25-002900:note_history:9]
In  August 2024, the Company filed an automatically-effective shelf registration statement on Form S-3 that will expire no later than  August 12, 2027 (the “Second Form S-3”). The Second Form S-3 allows the Company to offer and sell from time-to-time unspecified amounts of common stock, debt securities, warrants or units comprised of any combination of these securities and allows certain selling stockholders to offer and sell from time-to-time common stock. The Second Form S-3 assisted the Megatran selling stockholders in the resale of their common stock and is intended to provide the Company flexibility to conduct registered sales of its securities, subject to market conditions, in order to fund its future capital needs. The terms of any future offering under the Second Form S-3 will be established at the time of such offering and will be described in a prospectus supplement filed with the SEC prior to the completion of any such offering.

- removed (2025-07-30):
[0001437749-25-002900:note_history:10]
Changes in macroeconomic conditions arising from various reasons, such as the ongoing wars between Russia and Ukraine and Israel and Hamas, labor force availability, sourcing, material delays and global supply chain disruptions could have a material adverse effect on the Company’s business, financial condition and results of operations.

- removed (2025-07-30):
[0001437749-25-002900:note_history:11]
The Company believes that based on the information presented above and its quarterly management assessment, it has sufficient liquidity to fund its operations and capital expenditures for the next twelve months following the issuance of the unaudited condensed consolidated financial statements for the nine months ended  December 31, 2024. The Company’s liquidity is highly dependent on its ability to increase revenues, its ability to control its operating costs, and its ability to raise additional capital, if necessary. The impact of global sources of instability, including the wars between Russia and Ukraine and Israel and Hamas, on the global financing markets  may reduce the Company's ability to raise additional capital, if necessary, which could negatively impact the Company's liquidity.  There can be no assurance that the Company will be able to continue to raise additional capital, on favorable terms or at all, from other sources or execute on any other means of improving liquidity described above.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: no_current_note, score: 0.0

- removed (2025-07-30):
[0001437749-25-002900:note_history:12]
16. Debt

- removed (2025-07-30):
[0001437749-25-002900:note_history:13]
As part of the acquisition of Neeltran, the Company identified four equipment financing agreements that Neeltran had entered into prior to the acquisition of Neeltran on  May 6, 2021. The Company did not have a current debt balance as of  December 31, 2024 and had a balance of less than $0.1 million as of  March 31, 2024.


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2025-07-30):
[0001437749-25-023968:note_history:14]
|  |  | Three Months Ended June 30, 2025 |  |
| Product Line: |  | Grid |  |  | Wind |  |
| Equipment and systems |  | $ | 55,521 |  |  | $ | 11,881 |  |
| Services and technology development |  |  | 4,566 |  |  |  | 390 |  |
| Total |  | $ | 60,087 |  |  | $ | 12,271 |  |
| Region: |  |  |  |  |  |  |  |  |
| Americas |  | $ | 38,020 |  |  | $ | — |  |
| Asia Pacific |  |  | 18,304 |  |  |  | 12,271 |  |
| EMEA |  |  | 3,763 |  |  |  | — |  |
| Total |  | $ | 60,087 |  |  | $ | 12,271 |  |
  (was, 2025-02-05, similarity 0.6852):
[0001437749-25-002900:note_history:14]
|  |  | Three Months Ended December 31, 2024 |  |  | Nine Months Ended December 31, 2024 |  |
| Product Line: |  | Grid |  |  | Wind |  |  | Grid |  |  | Wind |  |
| Equipment and systems |  | $ | 48,979 |  |  | $ | 8,768 |  |  | $ | 123,431 |  |  | $ | 23,357 |  |
| Services and technology development |  |  | 3,327 |  |  |  | 329 |  |  |  | 8,147 |  |  |  | 1,228 |  |
| Total |  | $ | 52,306 |  |  | $ | 9,097 |  |  | $ | 131,578 |  |  | $ | 24,585 |  |
| Region: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas |  | $ | 47,737 |  |  | $ | — |  |  | $ | 121,696 |  |  | $ | 1 |  |
| Asia Pacific |  |  | 2,293 |  |  |  | 9,080 |  |  |  | 4,280 |  |  |  | 24,562 |  |
| EMEA |  |  | 2,276 |  |  |  | 17 |  |  |  | 5,602 |  |  |  | 22 |  |
| Total |  | $ | 52,306 |  |  | $ | 9,097 |  |  | $ | 131,578 |  |  | $ | 24,585 |  |

- changed (2025-07-30):
[0001437749-25-023968:note_history:15]
|  |  | Three Months Ended June 30, 2024 |  |
| Product Line: |  | Grid |  |  | Wind |  |
| Equipment and systems |  | $ | 29,726 |  |  | $ | 7,424 |  |
| Services and technology development |  |  | 2,610 |  |  |  | 530 |  |
| Total |  | $ | 32,336 |  |  | $ | 7,954 |  |
| Region: |  |  |  |  |  |  |  |  |
| Americas |  | $ | 30,479 |  |  | $ | — |  |
| Asia Pacific |  |  | 1,199 |  |  |  | 7,952 |  |
| EMEA |  |  | 658 |  |  |  | 2 |  |
| Total |  | $ | 32,336 |  |  | $ | 7,954 |  |
  (was, 2025-02-05, similarity 0.6614):
[0001437749-25-002900:note_history:15]
|  |  | Three Months Ended December 31, 2023 |  |  | Nine Months Ended December 31, 2023 |  |
| Product Line: |  | Grid |  |  | Wind |  |  | Grid |  |  | Wind |  |
| Equipment and systems |  | $ | 31,210 |  |  | $ | 4,983 |  |  | $ | 81,181 |  |  | $ | 13,844 |  |
| Services and technology development |  |  | 2,393 |  |  |  | 767 |  |  |  | 6,673 |  |  |  | 1,913 |  |
| Total |  | $ | 33,603 |  |  | $ | 5,750 |  |  | $ | 87,854 |  |  | $ | 15,757 |  |
| Region: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas |  | $ | 26,782 |  |  | $ | 45 |  |  | $ | 74,640 |  |  | $ | 102 |  |
| Asia Pacific |  |  | 3,704 |  |  |  | 5,660 |  |  |  | 8,832 |  |  |  | 15,587 |  |
| EMEA |  |  | 3,117 |  |  |  | 45 |  |  |  | 4,382 |  |  |  | 68 |  |
| Total |  | $ | 33,603 |  |  | $ | 5,750 |  |  | $ | 87,854 |  |  | $ | 15,757 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2025-07-30):
[0001437749-25-023968:note_history:16]
The Company’s revenues in its Grid segment are derived primarily through enabling the transmission and distribution of power, providing planning services that allow it to identify power grid needs and risks, and developing ship protection systems for the U.S. Navy. The Company’s revenues in its Wind segment are derived primarily through supplying advanced power electronics and control systems, licensing its highly engineered wind turbine designs, and providing extensive customer support services to wind turbine manufacturers. The Company records revenue based on a five-step model in accordance with Accounting Standards Codification ("ASC") 606. For its customer contracts, the Company identifies the performance obligations, determines the transaction price, allocates the contract transaction price to the performance obligations, and recognizes the revenue when (or as) control of goods or services is transferred to the customer. For the three months ended  June 30, 2025, 91% of revenue, was recognized at the point in time when control transferred to the customer, with the remainder being recognized over time. For the three months ended  June 30, 2024, 88% of revenue was recognized at the point in time when control transferred to the customer, with the remainder being recognized over time.
  (was, 2025-02-05, similarity 0.8254):
[0001437749-25-002900:note_history:16]
The Company’s revenues in its Grid business segment are derived primarily through enabling the transmission and distribution of power, providing planning services that allow it to identify power grid needs and risks, and developing ship protection systems for the U.S. Navy. The Company’s revenues in its Wind business segment are derived primarily through supplying advanced power electronics and control systems, licensing its highly engineered wind turbine designs, and providing extensive customer support services to wind turbine manufacturers. The Company records revenue based on a five-step model in accordance with Accounting Standards Codification ("ASC") 606. For its customer contracts, the Company identifies the performance obligations, determines the transaction price, allocates the contract transaction price to the performance obligations, and recognizes the revenue when (or as) control of goods or services is transferred to the customer. For the three and nine months ended  December 31, 2024, 87% and 88% of revenue, respectively, was recognized at the point in time when control transferred to the customer, with the remainder being recognized over time. For the three and nine months ended  December 31, 2023, 85% and 80% of revenue, respectively, was recognized at the point in time when control transferred to the customer, with the remainder being recognized over time.

- changed (2025-07-30):
[0001437749-25-023968:note_history:17]
The Company records revenue net of sales tax, value added tax, excise tax and other taxes collected concurrent with revenue-producing activities. The Company has elected to recognize the cost for freight and shipping when control over the products sold passes to customers and revenue is recognized. The Company has elected to recognize incremental costs of obtaining a contract as expense when incurred except in contracts where the amortization period would exceed twelve months. As of  June 30, 2025 and  March 31, 2025, the Company's capitalized incremental contract costs were not material. The Company has elected not to adjust the promised amount of consideration for the effects of a significant financing component if the period of financing is twelve months or less.  The Company has elected to recognize revenue based on the as invoiced practical expedient if there is a right to consideration from a customer in an amount that corresponds directly with the value of the Company's performance.
  (was, 2025-02-05, similarity 0.994):
[0001437749-25-002900:note_history:17]
The Company records revenue net of sales tax, value added tax, excise tax and other taxes collected concurrent with revenue-producing activities. The Company has elected to recognize the cost for freight and shipping when control over the products sold passes to customers and revenue is recognized. The Company has elected to recognize incremental costs of obtaining a contract as expense when incurred except in contracts where the amortization period would exceed twelve months. As of  December 31, 2024 and  March 31, 2024, the Company's capitalized incremental contract costs were not material. The Company has elected not to adjust the promised amount of consideration for the effects of a significant financing component if the period of financing is twelve months or less.  The Company has elected to recognize revenue based on the as invoiced practical expedient if there is a right to consideration from a customer in an amount that corresponds directly with the value of the Company's performance.

- changed (2025-07-30):
[0001437749-25-023968:note_history:18]
|  |  | Three Months Ended June 30, 2025 |  |
| Product Line: |  | Grid |  |  | Wind |  |
| Equipment and systems |  | $ | 55,521 |  |  | $ | 11,881 |  |
| Services and technology development |  |  | 4,566 |  |  |  | 390 |  |
| Total |  | $ | 60,087 |  |  | $ | 12,271 |  |
| Region: |  |  |  |  |  |  |  |  |
| Americas |  | $ | 38,020 |  |  | $ | — |  |
| Asia Pacific |  |  | 18,304 |  |  |  | 12,271 |  |
| EMEA |  |  | 3,763 |  |  |  | — |  |
| Total |  | $ | 60,087 |  |  | $ | 12,271 |  |
  (was, 2025-02-05, similarity 0.6852):
[0001437749-25-002900:note_history:18]
|  |  | Three Months Ended December 31, 2024 |  |  | Nine Months Ended December 31, 2024 |  |
| Product Line: |  | Grid |  |  | Wind |  |  | Grid |  |  | Wind |  |
| Equipment and systems |  | $ | 48,979 |  |  | $ | 8,768 |  |  | $ | 123,431 |  |  | $ | 23,357 |  |
| Services and technology development |  |  | 3,327 |  |  |  | 329 |  |  |  | 8,147 |  |  |  | 1,228 |  |
| Total |  | $ | 52,306 |  |  | $ | 9,097 |  |  | $ | 131,578 |  |  | $ | 24,585 |  |
| Region: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas |  | $ | 47,737 |  |  | $ | — |  |  | $ | 121,696 |  |  | $ | 1 |  |
| Asia Pacific |  |  | 2,293 |  |  |  | 9,080 |  |  |  | 4,280 |  |  |  | 24,562 |  |
| EMEA |  |  | 2,276 |  |  |  | 17 |  |  |  | 5,602 |  |  |  | 22 |  |
| Total |  | $ | 52,306 |  |  | $ | 9,097 |  |  | $ | 131,578 |  |  | $ | 24,585 |  |

- changed (2025-07-30):
[0001437749-25-023968:note_history:19]
|  |  | Three Months Ended June 30, 2024 |  |
| Product Line: |  | Grid |  |  | Wind |  |
| Equipment and systems |  | $ | 29,726 |  |  | $ | 7,424 |  |
| Services and technology development |  |  | 2,610 |  |  |  | 530 |  |
| Total |  | $ | 32,336 |  |  | $ | 7,954 |  |
| Region: |  |  |  |  |  |  |  |  |
| Americas |  | $ | 30,479 |  |  | $ | — |  |
| Asia Pacific |  |  | 1,199 |  |  |  | 7,952 |  |
| EMEA |  |  | 658 |  |  |  | 2 |  |
| Total |  | $ | 32,336 |  |  | $ | 7,954 |  |
  (was, 2025-02-05, similarity 0.6614):
[0001437749-25-002900:note_history:19]
|  |  | Three Months Ended December 31, 2023 |  |  | Nine Months Ended December 31, 2023 |  |
| Product Line: |  | Grid |  |  | Wind |  |  | Grid |  |  | Wind |  |
| Equipment and systems |  | $ | 31,210 |  |  | $ | 4,983 |  |  | $ | 81,181 |  |  | $ | 13,844 |  |
| Services and technology development |  |  | 2,393 |  |  |  | 767 |  |  |  | 6,673 |  |  |  | 1,913 |  |
| Total |  | $ | 33,603 |  |  | $ | 5,750 |  |  | $ | 87,854 |  |  | $ | 15,757 |  |
| Region: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas |  | $ | 26,782 |  |  | $ | 45 |  |  | $ | 74,640 |  |  | $ | 102 |  |
| Asia Pacific |  |  | 3,704 |  |  |  | 5,660 |  |  |  | 8,832 |  |  |  | 15,587 |  |
| EMEA |  |  | 3,117 |  |  |  | 45 |  |  |  | 4,382 |  |  |  | 68 |  |
| Total |  | $ | 33,603 |  |  | $ | 5,750 |  |  | $ | 87,854 |  |  | $ | 15,757 |  |

- changed (2025-07-30):
[0001437749-25-023968:note_history:20]
As of  June 30, 2025 and 2024, the Company’s contract assets and liabilities primarily relate to the timing differences between cash received from a customer in connection with contractual rights to invoicing and the timing of revenue recognition following completion of performance obligations. The Company's accounts receivable balance is made up entirely of customer contract related balances. Changes in the Company’s contract assets, which are included in “Unbilled accounts receivable” and “Deferred program costs” (see Note 8, “Accounts Receivable” and Note 9, “Inventory” for a reconciliation to the condensed consolidated balance sheets) and "Contract liabilities", which are included in the current portion and long-term portion of "Deferred revenue" in the Company’s condensed consolidated balance sheets, are as follows (in thousands):
  (was, 2025-02-05, similarity 0.9928):
[0001437749-25-002900:note_history:20]
As of  December 31, 2024 and 2023, the Company’s contract assets and liabilities primarily relate to the timing differences between cash received from a customer in connection with contractual rights to invoicing and the timing of revenue recognition following completion of performance obligations. The Company's accounts receivable balance is made up entirely of customer contract related balances. Changes in the Company’s contract assets, which are included in “Unbilled accounts receivable” and “Deferred program costs” (see Note 8, “Accounts Receivable” and Note 9, “Inventory” for a reconciliation to the condensed consolidated balance sheets) and "Contract liabilities", which are included in the current portion and long-term portion of "Deferred revenue" in the Company’s condensed consolidated balance sheets, are as follows (in thousands):

- changed (2025-07-30):
[0001437749-25-023968:note_history:21]
|  |  | Unbilled Accounts Receivable |  |  | Deferred Program Costs |  |  | Contract Liabilities |  |
| Beginning balance as of March 31, 2025 |  | $ | 6,376 |  |  | $ | 5,756 |  |  | $ | 76,133 |  |
| Increases for costs incurred to fulfill performance obligations |  |  | — |  |  |  | 3,907 |  |  |  | — |  |
| Increase (decrease) due to customer billings |  |  | (3,189 | ) |  |  | — |  |  |  | 30,863 |  |
| Decrease due to cost recognition on completed performance obligations |  |  | — |  |  |  | (4,093 | ) |  |  | — |  |
| Increase (decrease) due to recognition of revenue based on transfer of control of performance obligations |  |  | 6,876 |  |  |  | — |  |  |  | (32,108 | ) |
| Other changes and FX impact |  |  | 20 |  |  |  | 46 |  |  |  | 1,003 |  |
| Ending balance as of June 30, 2025 |  | $ | 10,083 |  |  | $ | 5,616 |  |  | $ | 75,891 |  |
  (was, 2025-02-05, similarity 0.9918):
[0001437749-25-002900:note_history:21]
|  |  | Unbilled Accounts Receivable |  |  | Deferred Program Costs |  |  | Contract Liabilities |  |
| Beginning balance as of March 31, 2023 |  | $ | 9,958 |  |  | $ | 2,136 |  |  | $ | 50,760 |  |
| Increases for costs incurred to fulfill performance obligations |  |  | — |  |  |  | 2,714 |  |  |  | — |  |
| Increase (decrease) due to customer billings |  |  | (18,354 | ) |  |  | — |  |  |  | 55,018 |  |
| Decrease due to cost recognition on completed performance obligations |  |  | — |  |  |  | (3,518 | ) |  |  | — |  |
| Increase (decrease) due to recognition of revenue based on transfer of control of performance obligations |  |  | 12,969 |  |  |  | — |  |  |  | (46,190 | ) |
| Other changes and FX impact |  |  | 15 |  |  |  | 5 |  |  |  | 155 |  |
| Ending balance as of December 31, 2023 |  | $ | 4,588 |  |  | $ | 1,337 |  |  | $ | 59,743 |  |

- changed (2025-07-30):
[0001437749-25-023968:note_history:22]
|  |  | Unbilled Accounts Receivable |  |  | Deferred Program Costs |  |  | Contract Liabilities |  |
| Beginning balance as of March 31, 2024 |  | $ | 6,150 |  |  | $ | 2,523 |  |  | $ | 57,829 |  |
| Increases for costs incurred to fulfill performance obligations |  |  | — |  |  |  | 2,119 |  |  |  | — |  |
| Increase (decrease) due to customer billings |  |  | (3,521 | ) |  |  | — |  |  |  | 27,577 |  |
| Decrease due to cost recognition on completed performance obligations |  |  | — |  |  |  | (606 | ) |  |  | — |  |
| Increase (decrease) due to recognition of revenue based on transfer of control of performance obligations |  |  | 2,291 |  |  |  | — |  |  |  | (22,443 | ) |
| Other changes and FX impact |  |  | (2 | ) |  |  | (2 | ) |  |  | (50 | ) |
| Ending balance as of June 30, 2024 |  | $ | 4,918 |  |  | $ | 4,034 |  |  | $ | 62,913 |  |
  (was, 2025-02-05, similarity 0.9508):
[0001437749-25-002900:note_history:22]
|  |  | Unbilled Accounts Receivable |  |  | Deferred Program Costs |  |  | Contract Liabilities |  |
| Beginning balance as of March 31, 2024 |  | $ | 6,150 |  |  | $ | 2,523 |  |  | $ | 57,829 |  |
| Increase for balance acquired |  |  | — |  |  |  | — |  |  |  | 5,049 |  |
| Increases for costs incurred to fulfill performance obligations |  |  | — |  |  |  | 10,876 |  |  |  | — |  |
| Increase (decrease) due to customer billings |  |  | (7,139 | ) |  |  | — |  |  |  | 96,400 |  |
| Decrease due to cost recognition on completed performance obligations |  |  | — |  |  |  | (6,133 | ) |  |  | — |  |
| Increase (decrease) due to recognition of revenue based on transfer of control of performance obligations |  |  | 6,120 |  |  |  | — |  |  |  | (75,410 | ) |
| Other changes and FX impact |  |  | (18 | ) |  |  | (11 | ) |  |  | (540 | ) |
| Ending balance as of December 31, 2024 |  | $ | 5,113 |  |  | $ | 7,255 |  |  | $ | 83,328 |  |

- changed (2025-07-30):
[0001437749-25-023968:note_history:23]
The Company’s remaining performance obligations represent the unrecognized revenue value of the Company’s contractual commitments. The Company’s performance obligations  may vary significantly each reporting period based on the timing of major new contractual commitments. As of  June 30, 2025, the Company had outstanding performance obligations on existing contracts under ASC 606 to be recognized in the next twelve months of approximately $215.2 million. There are also approximately $88.4 million of outstanding performance obligations to be recognized over a period of thirteen to sixty months. The remaining performance obligations are subject to customer actions and therefore the timing of revenue recognition cannot be reasonably estimated.
  (was, 2025-02-05, similarity 0.9918):
[0001437749-25-002900:note_history:23]
The Company’s remaining performance obligations represent the unrecognized revenue value of the Company’s contractual commitments. The Company’s performance obligations  may vary significantly each reporting period based on the timing of major new contractual commitments. As of  December 31, 2024, the Company had outstanding performance obligations on existing contracts under ASC 606 to be recognized in the next twelve months of approximately $204.2 million. There are also approximately $96.6 million of outstanding performance obligations to be recognized over a period of thirteen to sixty months. The remaining performance obligations are subject to customer actions and therefore the timing of revenue recognition cannot be reasonably estimated.

- changed (2025-07-30):
[0001437749-25-023968:note_history:24]
The following table sets forth customers who represented 10% or more of the Company’s total revenues for the three months ended  June 30, 2025, and 2024:
  (was, 2025-02-05, similarity 0.936):
[0001437749-25-002900:note_history:24]
The following table sets forth customers who represented 10% or more of the Company’s total revenues for the three and nine months ended  December 31, 2024 and 2023:

- added (2025-07-30):
[0001437749-25-023968:note_history:25]
|  |  |  | Three Months Ended |  |
|  | Reportable |  | June 30, |  |
|  | Segment |  | 2025 |  |  | 2024 |  |
| Fuji Bridex Pte Ltd | Grid |  |  | 21 | % |  | <10 | % |
| Inox Wind Limited | Wind |  |  | 16 | % |  |  | 18 | % |

- removed (2025-07-30):
[0001437749-25-002900:note_history:26]
|  |  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  | Reportable |  | December 31, |  |  | December 31, |  |
|  | Segment |  | 2024 |  |  | 2023 |  |  | 2024 |  |  | 2023 |  |
| Inox Wind Limited | Wind |  |  | 10 | % |  |  | 11 | % |  |  | 13 | % |  |  | 12 | % |
| Innomotics LLC | Grid |  |  | 14 | % |  |  | <10% |  |  |  | <10% |  |  |  | <10% |  |
