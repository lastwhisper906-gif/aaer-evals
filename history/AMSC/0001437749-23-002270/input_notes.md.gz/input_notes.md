# AMSC notes — 0001437749-23-002270


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0001437749-23-002270:notes:1]
[same as prior period, unchanged from 0001437749-22-025367:notes:1]

[0001437749-23-002270:notes:2]
[same as prior period, unchanged from 0001437749-22-025367:notes:2]

[0001437749-23-002270:notes:3]
American Superconductor Corporation (together with its subsidiaries, “AMSC®” or the “Company”) was founded on  April 9, 1987. The Company is a leading system provider of megawatt-scale power resiliency solutions that orchestrate the rhythm and harmony of power on the grid™ and that protect and expand the capability of the Navy’s fleet. The Company’s system level products leverage its proprietary “smart materials” and “smart software and controls” to provide enhanced resiliency and improved performance of megawatt-scale power flow.

[0001437749-23-002270:notes:4]
These unaudited condensed consolidated financial statements of the Company have been prepared on a going concern basis in accordance with United States generally accepted accounting principles (“GAAP”) and the Securities and Exchange Commission’s (“SEC”) instructions to Form 10-Q. The going concern basis of presentation assumes that the Company will continue operations and will be able to realize its assets and discharge its liabilities and commitments in the normal course of business. Certain information and footnote disclosures normally included in the financial statements prepared in accordance with GAAP have been condensed or omitted pursuant to those instructions. The year-end condensed balance sheet data was derived from audited financial statements but does not include all disclosures required by GAAP. The unaudited condensed consolidated financial statements, in the opinion of management, reflect all adjustments (consisting of normal recurring adjustments) necessary for a fair statement of the results for the interim periods ended  December 31, 2022 and 2021 and the financial position at  December 31, 2022; however, these results are not necessarily indicative of results which  may be expected for the full year. The interim condensed consolidated financial statements, and notes thereto, should be read in conjunction with the audited consolidated financial statements for the year ended  March 31, 2022, and notes thereto, included in the Company’s Annual Report on Form 10-K for the year ended  March 31, 2022 filed with the SEC on  June 1, 2022.

[0001437749-23-002270:notes:5]
[same as prior period, unchanged from 0001437749-22-025367:notes:5]

[0001437749-23-002270:notes:6]
The Company has historically experienced recurring operating losses and as of  December 31, 2022, the Company had an accumulated deficit of $1,049 million. In addition, the Company has historically experienced recurring negative operating cash flows. At  December 31, 2022, the Company had cash and cash equivalents of $23.7 million. Cash used in operations for the nine months ended  December 31, 2022 was $17.1 million.

[0001437749-23-002270:notes:7]
[same as prior period, unchanged from 0001437749-22-025367:notes:7]

[0001437749-23-002270:notes:8]
The Company is experiencing substantial inflationary pressure in its supply chain and some delays in sourcing materials needed for its products resulting in some production disruption, both of which have increased the Company’s cost of revenues and decreased gross margin. Changes in macroeconomic conditions arising from the COVID-19 pandemic or for other reasons, such as the ongoing war between Russia and Ukraine, inflation, rising interest rates, labor force availability, sourcing, material delays and global supply chain disruptions could have a material adverse effect on the Company’s business, financial condition and results of operation.

[0001437749-23-002270:notes:9]
From time-to-time the Company  may undertake restructuring activities in order to align the global organization in a manner that the Company believes will better position it to achieve its long-term goals. In  January 2023, the Company undertook a reduction in force that involved approximately 5% of the global workforce. This restructuring is expected to incur an immaterial amount of cash expense and to result in annualized cost savings of approximately $5 million, beginning in fiscal year 2023.

[0001437749-23-002270:notes:10]
The Company believes that based on the information presented above and its quarterly management assessment, it has sufficient liquidity to fund its operations and capital expenditures for the next twelve months following the issuance of the financial statements for the nine months ended  December 31, 2022. The Company’s liquidity is highly dependent on its ability to increase revenues, its ability to control its operating costs, and its ability to raise additional capital, if necessary. The impact of the COVID-19 pandemic and other sources of instability, including the war between Russia and Ukraine, on the global financing markets  may reduce the Company's ability to raise additional capital, if necessary, which could negatively impact the Company's liquidity.  There can be no assurance that the Company will be able to continue to raise additional capital, on favorable terms or at all, from other sources or execute on any other means of improving liquidity described above.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001437749-23-002270:notes:11]
[same as prior period, unchanged from 0001437749-22-025367:notes:10]

[0001437749-23-002270:notes:12]
[same as prior period, unchanged from 0001437749-22-025367:notes:11]

[0001437749-23-002270:notes:13]
[same as prior period, unchanged from 0001437749-22-025367:notes:12]

[0001437749-23-002270:notes:14]
[same as prior period, unchanged from 0001437749-22-025367:notes:13]

[0001437749-23-002270:notes:15]
[same as prior period, unchanged from 0001437749-22-025367:notes:14]

[0001437749-23-002270:notes:16]
[same as prior period, unchanged from 0001437749-22-025367:notes:15]

[0001437749-23-002270:notes:17]
[same as prior period, unchanged from 0001437749-22-025367:notes:16]

[0001437749-23-002270:notes:18]
[same as prior period, unchanged from 0001437749-22-025367:notes:17]

[0001437749-23-002270:notes:19]
[same as prior period, unchanged from 0001437749-22-025367:notes:18]

[0001437749-23-002270:notes:20]
[same as prior period, unchanged from 0001437749-22-025367:notes:19]

[0001437749-23-002270:notes:21]
[same as prior period, unchanged from 0001437749-22-025367:notes:20]

[0001437749-23-002270:notes:22]
[same as prior period, unchanged from 0001437749-22-025367:notes:21]

[0001437749-23-002270:notes:23]
[same as prior period, unchanged from 0001437749-22-025367:notes:22]

[0001437749-23-002270:notes:24]
[same as prior period, unchanged from 0001437749-22-025367:notes:23]

[0001437749-23-002270:notes:25]
[same as prior period, unchanged from 0001437749-22-025367:notes:24]

[0001437749-23-002270:notes:26]
The unaudited pro forma condensed consolidated statement of operations for the
        three and nine months ended
         December 31, 2022 and 
        2021 is presented as if the Neeltran Acquisition had occurred on
         April 1, 2021.

[0001437749-23-002270:notes:27]
|  |  | Three Months Ended December 31, |  |  | Nine Months Ended December 31, |  |
|  |  | 2022 |  |  | 2021 |  |  | 2022 |  |  | 2021 |  |
| Revenues |  | $ | 23,881 |  |  | $ | 26,799 |  |  | $ | 74,241 |  |  | $ | 82,957 |  |
| Operating loss |  |  | (9,209 | ) |  |  | (4,380 | ) |  |  | (26,184 | ) |  |  | (16,066 | ) |
| Net loss |  | $ | (9,581 | ) |  | $ | (4,324 | ) |  | $ | (28,186 | ) |  | $ | (14,323 | ) |
| Net loss per common share |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | (0.34 | ) |  | $ | (0.16 | ) |  | $ | (1.01 | ) |  | $ | (0.53 | ) |
| Diluted |  | $ | (0.34 | ) |  | $ | (0.16 | ) |  | $ | (1.01 | ) |  | $ | (0.53 | ) |
| Shares - basic |  |  | 27,954 |  |  |  | 27,352 |  |  |  | 27,794 |  |  |  | 27,185 |  |
| Shares - diluted |  |  | 27,954 |  |  |  | 27,352 |  |  |  | 27,794 |  |  |  | 27,185 |  |

[0001437749-23-002270:notes:28]
[same as prior period, unchanged from 0001437749-22-025367:notes:27]

[0001437749-23-002270:notes:29]
[same as prior period, unchanged from 0001437749-22-025367:notes:28]

[0001437749-23-002270:notes:30]
[same as prior period, unchanged from 0001437749-22-025367:notes:29]

[0001437749-23-002270:notes:31]
[same as prior period, unchanged from 0001437749-22-025367:notes:30]

[0001437749-23-002270:notes:32]
[same as prior period, unchanged from 0001437749-22-025367:notes:31]

[0001437749-23-002270:notes:33]
[same as prior period, unchanged from 0001437749-22-025367:notes:32]

[0001437749-23-002270:notes:34]
[same as prior period, unchanged from 0001437749-22-025367:notes:33]

[0001437749-23-002270:notes:35]
[same as prior period, unchanged from 0001437749-22-025367:notes:34]

[0001437749-23-002270:notes:36]
The fair value of the contingent consideration was determined using a Monte Carlo model and is accounted for as a derivative liability which is revalued at the fair value determined at each subsequent balance sheet date until the contingencies are resolved and the shares to be issued are determined, with the change in fair value recorded in the current period operating loss or (income).  See Note 13, "Contingent Consideration" for further details and a summary of key assumptions used to determine fair value in each period.

[0001437749-23-002270:notes:37]
[same as prior period, unchanged from 0001437749-22-025367:notes:36]

[0001437749-23-002270:notes:38]
[same as prior period, unchanged from 0001437749-22-025367:notes:37]

[0001437749-23-002270:notes:39]
[same as prior period, unchanged from 0001437749-22-025367:notes:38]

[0001437749-23-002270:notes:40]
[same as prior period, unchanged from 0001437749-22-025367:notes:39]

[0001437749-23-002270:notes:41]
[same as prior period, unchanged from 0001437749-22-025367:notes:40]

[0001437749-23-002270:notes:42]
[same as prior period, unchanged from 0001437749-22-025367:notes:41]

[0001437749-23-002270:notes:43]
[same as prior period, unchanged from 0001437749-22-025367:notes:42]


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001437749-23-002270:notes:44]
[same as prior period, unchanged from 0001437749-22-025367:notes:43]

[0001437749-23-002270:notes:45]
The Company’s revenues in its Grid business segment are derived primarily through enabling the transmission and distribution of power, providing planning services that allow it to identify power grid needs and risks, and developing ship protection systems for the U.S. Navy. The Company’s revenues in its Wind business segment are derived primarily through supplying advanced power electronics and control systems, licensing its highly engineered wind turbine designs, and providing extensive customer support services to wind turbine manufacturers. The Company records revenue based on a five-step model in accordance with ASC 606. For its customer contracts, the Company identifies the performance obligations, determines the transaction price, allocates the contract transaction price to the performance obligations, and recognizes the revenue when (or as) control of goods or services is transferred to the customer. In the three and nine months ended  December 31, 2022, 87% and 80% of revenue, respectively, was recognized at the point in time when control transferred to the customer, with the remainder being recognized over time. In the three and nine months ended  December 31, 2021, 79% and 76% of revenue, respectively, was recognized at the point in time when control transferred to the customer, with the remainder being recognized over time.

[0001437749-23-002270:notes:46]
[same as prior period, unchanged from 0001437749-22-025367:notes:45]

[0001437749-23-002270:notes:47]
The Company's equipment and system product line includes certain contracts which do not meet the requirements of an exchange transaction and therefore do not fall within the scope of ASC 606.  As these non-exchange transaction contracts are considered grant revenue and do not fall within any specific accounting literature, the Company follows guidance within ASC 606 by analogy to recognize grant revenue over time. The Company recorded no grant revenue in each of the three and nine months ended  December 31, 2022. In the three and nine months ended  December 31, 2021, the Company recorded $0.1 million and $0.9 million in grant revenue, respectively, which is included in the Company’s Grid business segment revenue.

[0001437749-23-002270:notes:48]
[same as prior period, unchanged from 0001437749-22-025367:notes:47]

[0001437749-23-002270:notes:49]
[same as prior period, unchanged from 0001437749-22-025367:notes:48]

[0001437749-23-002270:notes:50]
[same as prior period, unchanged from 0001437749-22-025367:notes:49]

[0001437749-23-002270:notes:51]
[same as prior period, unchanged from 0001437749-22-025367:notes:50]

[0001437749-23-002270:notes:52]
[same as prior period, unchanged from 0001437749-22-025367:notes:51]

[0001437749-23-002270:notes:53]
The Company monitors costs to meet our obligations on our customer contracts. When it is evident that there is a loss expected on a contract, a contract loss is accrued in the period. Several long-term contracts that were acquired from Neeltran were impacted by higher than planned costs due to required design changes and inflation on material costs, resulting in an increase to the contract loss accrual of $1.6 million and $3.2 million in the three and nine month period ended  December 31, 2022 which negatively impacted the Company's gross margins.

[0001437749-23-002270:notes:54]
[same as prior period, unchanged from 0001437749-22-025367:notes:52]

[0001437749-23-002270:notes:55]
[same as prior period, unchanged from 0001437749-22-025367:notes:53]

[0001437749-23-002270:notes:56]
|  |  | Three Months Ended December 31, 2022 |  |  | Nine Months Ended December 31, 2022 |  |
| Product Line: |  | Grid |  |  | Wind |  |  | Grid |  |  | Wind |  |
| Equipment and systems |  | $ | 19,475 |  |  | $ | 2,842 |  |  | $ | 61,680 |  |  | $ | 6,144 |  |
| Services and technology development |  |  | 1,334 |  |  |  | 230 |  |  |  | 4,657 |  |  |  | 1,760 |  |
| Total |  | $ | 20,809 |  |  | $ | 3,072 |  |  | $ | 66,337 |  |  | $ | 7,904 |  |
| Region: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas |  | $ | 17,010 |  |  |  | 19 |  |  | $ | 51,934 |  |  | $ | 19 |  |
| Asia Pacific |  |  | 1,760 |  |  |  | 3,053 |  |  |  | 10,615 |  |  |  | 7,815 |  |
| EMEA |  |  | 2,039 |  |  |  | - |  |  |  | 3,788 |  |  |  | 70 |  |
| Total |  | $ | 20,809 |  |  | $ | 3,072 |  |  | $ | 66,337 |  |  | $ | 7,904 |  |

[0001437749-23-002270:notes:57]
|  |  | Three Months Ended December 31, 2021 |  |  | Nine Months Ended December 31, 2021 |  |
| Product Line: |  | Grid |  |  | Wind |  |  | Grid |  |  | Wind |  |
| Equipment and systems |  | $ | 23,416 |  |  | $ | 1,309 |  |  | $ | 67,605 |  |  | $ | 4,168 |  |
| Services and technology development |  |  | 1,634 |  |  |  | 440 |  |  |  | 5,564 |  |  |  | 2,789 |  |
| Total |  | $ | 25,050 |  |  | $ | 1,749 |  |  | $ | 73,169 |  |  | $ | 6,957 |  |
| Region: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas |  | $ | 16,739 |  |  | $ | 56 |  |  | $ | 57,498 |  |  | $ | 134 |  |
| Asia Pacific |  |  | 7,064 |  |  |  | 1,690 |  |  |  | 10,931 |  |  |  | 6,781 |  |
| EMEA |  |  | 1,247 |  |  |  | 3 |  |  |  | 4,740 |  |  |  | 42 |  |
| Total |  | $ | 25,050 |  |  | $ | 1,749 |  |  | $ | 73,169 |  |  | $ | 6,957 |  |

[0001437749-23-002270:notes:58]
As of  December 31, 2022, and 2021, the Company’s contract assets and liabilities primarily relate to the timing differences between cash received from a customer in connection with contractual rights to invoicing and the timing of revenue recognition following completion of performance obligations. The Company's accounts receivable balance is made up entirely of customer contract related balances. Changes in the Company’s contract assets, which are included in “Unbilled accounts receivable” and “Deferred program costs” (see Note 8, “Accounts Receivable” and Note 9, “Inventory” for a reconciliation to the condensed consolidated balance sheets) and "Contract liabilities", which are included in the current portion and long-term portion of "Deferred revenue" in the Company’s condensed consolidated balance sheets, are as follows (in thousands):

[0001437749-23-002270:notes:59]
|  |  | Unbilled Accounts Receivable |  |  | Deferred Program Costs |  |  | Contract Liabilities |  |
| Beginning balance as of March 31, 2022 |  | $ | 6,492 |  |  | $ | 858 |  |  | $ | 30,034 |  |
| Increases for costs incurred to fulfill performance obligations |  |  | — |  |  |  | 909 |  |  |  | — |  |
| Increase (decrease) due to customer billings |  |  | (11,723 | ) |  |  | — |  |  |  | 48,013 |  |
| Decrease due to cost recognition on completed performance obligations |  |  | — |  |  |  | (791 | ) |  |  | — |  |
| Increase (decrease) due to recognition of revenue based on transfer of control of performance obligations |  |  | 9,544 |  |  |  | — |  |  |  | (36,452 | ) |
| Other changes and FX impact |  |  | — |  |  |  | (15 | ) |  |  | (180 | ) |
| Ending balance as of December 31, 2022 |  | $ | 4,313 |  |  | $ | 961 |  |  | $ | 41,415 |  |

[0001437749-23-002270:notes:60]
|  |  | Unbilled Accounts Receivable |  |  | Deferred Program Costs |  |  | Contract Liabilities |  |
| Beginning balance as of March 31, 2021 |  | $ | 5,765 |  |  | $ | 977 |  |  | $ | 21,257 |  |
| Increases for costs incurred to fulfill performance obligations |  |  | — |  |  |  | 3,140 |  |  |  | — |  |
| Increase for balance acquired |  |  | — |  |  |  | 634 |  |  |  | 10,048 |  |
| Increase (decrease) due to customer billings |  |  | (11,214 | ) |  |  | — |  |  |  | 55,354 |  |
| Decrease due to cost recognition on completed performance obligations |  |  | — |  |  |  | (4,128 | ) |  |  | — |  |
| Increase (decrease) due to recognition of revenue based on transfer of control of performance obligations |  |  | 12,186 |  |  |  | — |  |  |  | (55,318 | ) |
| Other changes and FX impact |  |  | — |  |  |  | (8 | ) |  |  | 137 |  |
| Ending balance as of December 31, 2021 |  | $ | 6,737 |  |  | $ | 615 |  |  | $ | 31,478 |  |

[0001437749-23-002270:notes:61]
The Company’s remaining performance obligations represent the unrecognized revenue value of the Company’s contractual commitments. The Company’s performance obligations  may vary significantly each reporting period based on the timing of major new contractual commitments. As of  December 31, 2022, the Company had outstanding performance obligations on existing contracts under ASC 606 to be recognized in the next twelve months of approximately $112.1 million. There are also approximately $30.4 million of outstanding performance obligations to be recognized over a period of thirteen to sixty months. The remaining performance obligations are subject to customer actions and therefore the timing of revenue recognition cannot be reasonably estimated. The twelve-month performance obligations include anticipated shipments to Inox based on the twelve-month rolling forecast provided by Inox on the multi-year supply contract. The quantities specified in any forecast provided by Inox related to the multi-year supply contract are firm and irrevocable for the first three months of a twelve-month rolling forecast. The timing of the performance obligations beyond the twelve-month forecast provided by Inox are not determinable and therefore are not included in the total remaining performance obligations.

[0001437749-23-002270:notes:62]
The following table sets forth customers who represented 10% or more of the Company’s total revenues for the three and nine months ended  December 31, 2022 and 2021:

[0001437749-23-002270:notes:63]
|  |  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  | Reportable |  | December 31, |  |  | December 31, |  |
|  | Segment |  | 2022 |  |  | 2021 |  |  | 2022 |  |  | 2021 |  |
| Inox Wind Limited | Wind |  |  | 11 | % |  | <10% |  |  | <10% |  |  | <10% |  |
| Fuji Bridex Pte Ltd | Grid |  | <10% |  |  |  | 20 | % |  |  | 10 | % |  |  | 10 | % |


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001437749-23-002270:notes:64]
[same as prior period, unchanged from 0001437749-22-025367:notes:62]

[0001437749-23-002270:notes:65]
The Company accounts for its stock-based compensation at fair value. The following table summarizes stock-based compensation expense by financial statement line item for the three and nine months ended  December 31, 2022 and 2021 (in thousands):

[0001437749-23-002270:notes:66]
|  |  | Three Months Ended December 31, |  |  | Nine Months Ended December 31, |  |
|  |  | 2022 |  |  | 2021 |  |  | 2022 |  |  | 2021 |  |
| Cost of revenues |  | $ | 89 |  |  | $ | 36 |  |  | $ | 195 |  |  | $ | 148 |  |
| Research and development |  |  | 214 |  |  |  | 190 |  |  |  | 570 |  |  |  | 629 |  |
| Selling, general and administrative |  |  | 1,137 |  |  |  | 894 |  |  |  | 2,727 |  |  |  | 2,736 |  |
| Total |  | $ | 1,440 |  |  | $ | 1,120 |  |  | $ | 3,492 |  |  | $ | 3,513 |  |

[0001437749-23-002270:notes:67]
The Company issued 550,000 shares of restricted stock during the three months ended  December 31, 2022, and 888,500 shares of restricted stock and 25,806 shares of immediately vested common stock during the nine months ended  December 31, 2022. The Company issued 61,000 shares of restricted stock during the three months ended  December 31, 2021, and 370,700 shares of restricted stock and 166,648 shares of immediately vested common stock, of which 158,356 shares were issued in-lieu of cash bonuses during the nine months ended  December 31, 2021. These restricted stock awards generally vest over 2-3 years.  Awards for restricted stock include both time-based and performance-based awards.  For options and restricted stock awards that vest upon the passage of time, expense is being recorded over the vesting period.  Performance-based awards are expensed over the requisite service period based on probability of achievement.

[0001437749-23-002270:notes:68]
The estimated fair value of the Company’s stock-based awards, less expected annual forfeitures, is amortized over the awards’ service period. The total unrecognized compensation cost for unvested stock options was $0.1 million during the nine months ended  December 31, 2022. This expense will be recognized over a weighted average of approximately 1.4 years. The total unrecognized compensation cost for unvested outstanding restricted stock was $6.1 million at  December 31, 2022. This expense will be recognized over a weighted-average expense period of approximately 1.7 years.

[0001437749-23-002270:notes:69]
The Company granted 20,564 stock options during the nine months ended  December 31, 2022. The Company did not grant any stock options during the three months ended  December 31, 2022 or the three and nine months ended  December 31, 2021. The stock options granted during the nine months ended  December 31, 2022 will vest over 2 years. The weighted average assumptions used in the Black Scholes valuation model for stock options granted during the nine months ended  December 31, 2022 are as follows:

[0001437749-23-002270:notes:70]
|  |  | Three Months Ended December 31, |  |  | Nine Months Ended December 31, |  |
|  |  | 2022 |  |  | 2021 |  |  | 2022 |  |  | 2021 |  |
| Expected volatility |  |  | N/A |  |  |  | N/A |  |  |  | 71.40 | % |  |  | N/A |  |
| Risk-free interest rate |  |  | N/A |  |  |  | N/A |  |  |  | 3.10 | % |  |  | N/A |  |
| Expected life (years) |  |  | N/A |  |  |  | N/A |  |  |  | 6.14 |  |  |  | N/A |  |
| Dividend yield |  |  | N/A |  |  |  | N/A |  |  |  | None |  |  |  | N/A |  |


## us-gaap:EarningsPerShareTextBlock

[0001437749-23-002270:notes:71]
[same as prior period, unchanged from 0001437749-22-025367:notes:69]

[0001437749-23-002270:notes:72]
Basic net loss per share (“EPS”) is computed by dividing net loss by the weighted-average number of common shares outstanding for the period. Where applicable, diluted EPS is computed by dividing the net loss by the weighted-average number of common shares and dilutive common equivalent shares outstanding during the period, calculated using the treasury stock method. Common equivalent shares include the effect of restricted stock, exercise of stock options and warrants and contingently issuable shares. Stock options and warrants that are out-of-the-money with exercise prices greater than the average market price of the underlying common shares and shares of performance-based restricted stock where the contingency was not met are excluded from the computation of diluted EPS as the effect of their inclusion would be anti-dilutive.  For each of the three and nine months ended  December 31, 2022, and 2021, 1.1 million shares were not included in the calculation of diluted EPS. Of these, 1.0 million relate to shares tied to the derivative liability for which the contingency has not yet been met, and 0.1 million relate to outstanding stock options as they were considered anti-dilutive.

[0001437749-23-002270:notes:73]
The following table reconciles the numerators and denominators of the earnings per share calculation for the three and nine months ended  December 31, 2022 and 2021 (in thousands, except per share data):

[0001437749-23-002270:notes:74]
|  |  | Three Months Ended December 31, |  |  | Nine Months Ended December 31, |  |
|  |  | 2022 |  |  | 2021 |  |  | 2022 |  |  | 2021 |  |
| Numerator: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net loss |  | $ | (9,581 | ) |  | $ | (4,324 | ) |  | $ | (28,171 | ) |  | $ | (14,161 | ) |
| Denominator: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Weighted-average shares of common stock outstanding |  |  | 29,354 |  |  |  | 28,418 |  |  |  | 28,884 |  |  |  | 28,234 |  |
| Weighted-average shares subject to repurchase |  |  | (1,400 | ) |  |  | (1,066 | ) |  |  | (1,090 | ) |  |  | (1,089 | ) |
| Shares used in per-share calculation ― basic |  |  | 27,954 |  |  |  | 27,352 |  |  |  | 27,794 |  |  |  | 27,145 |  |
| Shares used in per-share calculation ― diluted |  |  | 27,954 |  |  |  | 27,352 |  |  |  | 27,794 |  |  |  | 27,145 |  |
| Net loss per share ― basic |  | $ | (0.34 | ) |  | $ | (0.16 | ) |  | $ | (1.01 | ) |  | $ | (0.52 | ) |
| Net loss per share ― diluted |  | $ | (0.34 | ) |  | $ | (0.16 | ) |  | $ | (1.01 | ) |  | $ | (0.52 | ) |


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001437749-23-002270:notes:75]
[same as prior period, unchanged from 0001437749-22-025367:notes:73]

[0001437749-23-002270:notes:76]
[same as prior period, unchanged from 0001437749-22-025367:notes:74]

[0001437749-23-002270:notes:77]
[same as prior period, unchanged from 0001437749-22-025367:notes:75]

[0001437749-23-002270:notes:78]
[same as prior period, unchanged from 0001437749-22-025367:notes:76]

[0001437749-23-002270:notes:79]
|  |  | Goodwill |  |
| March 31, 2021 |  | $ | 34,634 |  |
| Neeltran Acquisition |  |  | 8,837 |  |
| March 31, 2022 |  | $ | 43,471 |  |
| Less impairment loss |  |  | - |  |
| December 31, 2022 |  | $ | 43,471 |  |

[0001437749-23-002270:notes:80]
The Company did not identify any triggering events in the three and nine months ended  December 31, 2022 that would require interim impairment testing of goodwill.

[0001437749-23-002270:notes:81]
[same as prior period, unchanged from 0001437749-22-025367:notes:79]

[0001437749-23-002270:notes:82]
Intangible assets at  December 31, 2022 and  March 31, 2022 consisted of the following (in thousands):

[0001437749-23-002270:notes:83]
|  |  | December 31, 2022 |  |  | March 31, 2022 |  |  |  |  |  |
|  |  | Gross Amount |  |  | Accumulated Amortization |  |  | Net Book Value |  |  | Gross Amount |  |  | Accumulated Amortization |  |  | Net Book Value |  |  | Estimated Useful Life |  |
| Licenses |  | $ | 3,610 |  |  | $ | (3,610 | ) |  |  | — |  |  | $ | 3,610 |  |  | $ | (3,610 | ) |  |  | — |  |  |  | 7 |  |
| Backlog |  | $ | 681 |  |  | $ | (675 | ) |  | $ | 6 |  |  | $ | 681 |  |  | $ | (631 | ) |  | $ | 50 |  |  |  | 2 |  |
| Trade name and trademarks |  |  | 1,800 |  |  |  | — |  |  |  | 1,800 |  |  |  | 1,800 |  |  |  | — |  |  |  | 1,800 |  |  |  | Indefinite |  |
| Customer relationships |  |  | 9,600 |  |  |  | (4,413 | ) |  |  | 5,187 |  |  |  | 9,600 |  |  |  | (2,723 | ) |  |  | 6,877 |  |  |  | 7 |  |
| Core technology and know-how |  |  | 5,970 |  |  |  | (3,748 | ) |  |  | 2,222 |  |  |  | 5,970 |  |  |  | (3,386 | ) |  |  | 2,584 |  |  |  | 5-10 |  |
| Intangible assets |  | $ | 21,661 |  |  | $ | (12,446 | ) |  | $ | 9,215 |  |  | $ | 21,661 |  |  | $ | (10,350 | ) |  | $ | 11,311 |  |  |  |  |  |

[0001437749-23-002270:notes:84]
The Company recorded intangible amortization expense related to customer relationship and core technology and know-how of $0.7 million and $2.1 million, in the three and nine months ended  December 31, 2022, respectively, and $0.6 million and $1.8 million in the three and nine months ended  December 31, 2021, respectively. Additionally, the Company recorded intangible amortization related to backlog that is reported in cost of revenues of less than $0.1 million in each of the three and nine months ended  December 31, 2022. The Company recorded intangible amortization related to backlog that is reported in cost of revenues of $0.1 million in each of the three and nine months ended  December 31, 2021, respectively.

[0001437749-23-002270:notes:85]
[same as prior period, unchanged from 0001437749-22-025367:notes:83]

[0001437749-23-002270:notes:86]
| Years ended March 31, |  | Total |  |
| 2023 |  |  | 688 |  |
| 2024 |  |  | 2,158 |  |
| 2025 |  |  | 1,648 |  |
| 2026 |  |  | 1,221 |  |
| 2027 |  |  | 1,085 |  |
| Thereafter |  |  | 615 |  |
| Total |  | $ | 7,415 |  |

[0001437749-23-002270:notes:87]
[same as prior period, unchanged from 0001437749-22-025367:notes:85]


## us-gaap:FairValueDisclosuresTextBlock

[0001437749-23-002270:notes:88]
[same as prior period, unchanged from 0001437749-22-025367:notes:86]

[0001437749-23-002270:notes:89]
[same as prior period, unchanged from 0001437749-22-025367:notes:87]

[0001437749-23-002270:notes:90]
[same as prior period, unchanged from 0001437749-22-025367:notes:88]

[0001437749-23-002270:notes:91]
The Company provides a gross presentation of activity within Level 3 measurement roll-forward and details of transfers in and out of Level 1 and 2 measurements.  A change in the hierarchy of an investment from its current level is reflected in the period during which the pricing methodology of such investment changes.  Disclosure of the transfer of securities from Level 1 to Level 2 or Level 3 is made in the event that the related security is significant to total cash and investments.  The Company did not have any transfers of assets and liabilities from Level 1, Level 2 or Level 3 of the fair value measurement hierarchy during the nine months ended  December 31, 2022.

[0001437749-23-002270:notes:92]
[same as prior period, unchanged from 0001437749-22-025367:notes:90]

[0001437749-23-002270:notes:93]
[same as prior period, unchanged from 0001437749-22-025367:notes:91]

[0001437749-23-002270:notes:94]
[same as prior period, unchanged from 0001437749-22-025367:notes:92]

[0001437749-23-002270:notes:95]
[same as prior period, unchanged from 0001437749-22-025367:notes:93]

[0001437749-23-002270:notes:96]
[same as prior period, unchanged from 0001437749-22-025367:notes:96]

[0001437749-23-002270:notes:97]
Contingent consideration relates to the earnout payment set forth in the NEPSI Stock Purchase Agreement that provides that the selling stockholders  may receive up to an additional 1,000,000 shares of common stock of the Company upon the achievement of certain specified revenue objectives over varying periods of up to four years following the NEPSI Acquisition Date. See Note 13, "Contingent Consideration" and Note 2, “Acquisitions” for further discussion. The Company relied on a Monte Carlo method to determine the fair value of the contingent consideration on the NEPSI Acquisition Date and will continue to revalue the fair value of the contingent consideration using the same method at each subsequent balance sheet date until the contingencies are resolved and the shares to be issued are determined, with the change in fair value recorded in the current period operating loss.

[0001437749-23-002270:notes:98]
The following table provides the assets and liabilities carried at fair value on a recurring basis, measured as of  December 31, 2022 and  March 31, 2022 (in thousands):

[0001437749-23-002270:notes:99]
|  |  | Total Carrying Value |  |  | Quoted Prices in Active Markets (Level 1) |  |  | Significant Other Observable Inputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |
| December 31, 2022: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash equivalents |  | $ | 6,392 |  |  | $ | 6,392 |  |  | $ | — |  |  | $ | — |  |
| Derivative liabilities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Contingent consideration |  | $ | 860 |  |  | $ | — |  |  | $ | — |  |  | $ | 860 |  |

[0001437749-23-002270:notes:100]
[same as prior period, unchanged from 0001437749-22-025367:notes:100]

[0001437749-23-002270:notes:101]
[same as prior period, unchanged from 0001437749-22-025367:notes:101]

[0001437749-23-002270:notes:102]
|  |  | Acquisition Contingent Consideration |  |
| Balance at March 31, 2021 |  | $ | 7,050 |  |
| Change in fair value |  |  | (5,850 | ) |
| Balance at March 31, 2022 |  |  | 1,200 |  |
| Change in fair value |  |  | (340 | ) |
| Balance at December 31, 2022 |  | $ | 860 |  |


## amsc:AccountsReceivableTextBlock

[0001437749-23-002270:notes:103]
[same as prior period, unchanged from 0001437749-22-025367:notes:103]

[0001437749-23-002270:notes:104]
Accounts receivable at  December 31, 2022 and  March 31, 2022 consisted of the following (in thousands):

[0001437749-23-002270:notes:105]
|  |  | December 31, 2022 |  |  | March 31, 2022 |  |
| Accounts receivable (billed) |  | $ | 13,255 |  |  | $ | 13,788 |  |
| Accounts receivable (unbilled) |  |  | 4,313 |  |  |  | 6,492 |  |
| Accounts receivable, net |  | $ | 17,568 |  |  | $ | 20,280 |  |


## us-gaap:InventoryDisclosureTextBlock

[0001437749-23-002270:notes:106]
[same as prior period, unchanged from 0001437749-22-025367:notes:106]

[0001437749-23-002270:notes:107]
Inventory, net of reserves, at  December 31, 2022 and  March 31, 2022 consisted of the following (in thousands):

[0001437749-23-002270:notes:108]
|  |  | December 31, 2022 |  |  | March 31, 2022 |  |
| Raw materials |  | $ | 18,122 |  |  | $ | 11,020 |  |
| Work-in-process |  |  | 12,496 |  |  |  | 10,462 |  |
| Finished goods |  |  | 7,146 |  |  |  | 1,326 |  |
| Deferred program costs |  |  | 961 |  |  |  | 858 |  |
| Net inventory |  | $ | 38,725 |  |  | $ | 23,666 |  |

[0001437749-23-002270:notes:109]
The Company recorded inventory write-downs of $0.2 million and $0.4 million for the three months ended  December 31, 2022 and 2021, respectively. The Company recorded inventory write-downs of $1.2 million and $1.6 million for the nine months ended  December 31, 2022 and 2021, respectively. These write-downs were based on the Company's evaluation of its inventory on hand for excess quantities and obsolescence.

[0001437749-23-002270:notes:110]
Deferred program costs as of  December 31, 2022 and  March 31, 2022, primarily represent costs incurred on programs where the Company needs to complete performance obligations before the related revenue and costs will be recognized.


## us-gaap:PropertyPlantAndEquipmentDisclosureTextBlock

[0001437749-23-002270:notes:111]
[same as prior period, unchanged from 0001437749-22-025367:notes:111]

[0001437749-23-002270:notes:112]
The cost and accumulated depreciation of property, plant and equipment at  December 31, 2022 and  March 31, 2022 are as follows (in thousands):

[0001437749-23-002270:notes:113]
|  |  | December 31, 2022 |  |  | March 31, 2022 |  |
| Construction in progress - equipment |  | $ | 844 |  |  | $ | 573 |  |
| Land |  |  | 980 |  |  |  | 980 |  |
| Building |  |  | 5,416 |  |  |  | 5,270 |  |
| Equipment and software |  |  | 43,938 |  |  |  | 43,668 |  |
| Finance lease - right of use asset |  |  | 3 |  |  |  | 8 |  |
| Furniture and fixtures |  |  | 1,530 |  |  |  | 1,379 |  |
| Leasehold improvements |  |  | 6,650 |  |  |  | 6,634 |  |
| Property, plant and equipment, gross |  | $ | 59,361 |  |  |  | 58,512 |  |
| Less accumulated depreciation |  |  | (46,750 | ) |  |  | (44,856 | ) |
| Property, plant and equipment, net |  | $ | 12,611 |  |  | $ | 13,656 |  |

[0001437749-23-002270:notes:114]
Depreciation expense was $0.6 million and $0.7 million for the three months ended  December 31, 2022 and 2021, respectively. Depreciation expense was $2.0 million for each of the nine months ended  December 31, 2022 and 2021, respectively.


## us-gaap:AccountsPayableAndAccruedLiabilitiesDisclosureTextBlock

[0001437749-23-002270:notes:115]
[same as prior period, unchanged from 0001437749-22-025367:notes:115]

[0001437749-23-002270:notes:116]
Accounts payable and accrued expenses at  December 31, 2022 and  March 31, 2022 consisted of the following (in thousands):

[0001437749-23-002270:notes:117]
|  |  | December 31, 2022 |  |  | March 31, 2022 |  |
| Accounts payable |  | $ | 13,548 |  |  | $ | 13,192 |  |
| Accrued inventories in-transit |  |  | 2,126 |  |  |  | 2,212 |  |
| Accrued other miscellaneous expenses |  |  | 6,539 |  |  |  | 3,602 |  |
| Advanced deposits |  |  | 3,152 |  |  |  | 3,021 |  |
| Accrued compensation |  |  | 4,281 |  |  |  | 4,642 |  |
| Income taxes payable |  |  | 418 |  |  |  | 405 |  |
| Accrued product warranty |  |  | 1,996 |  |  |  | 2,066 |  |
| Total |  | $ | 32,060 |  |  | $ | 29,140 |  |

[0001437749-23-002270:notes:118]
[same as prior period, unchanged from 0001437749-22-025367:notes:118]

[0001437749-23-002270:notes:119]
[same as prior period, unchanged from 0001437749-22-025367:notes:119]

[0001437749-23-002270:notes:120]
|  |  | Three Months Ended December 31, |  |  | Nine Months Ended December 31, |  |
|  |  | 2022 |  |  | 2021 |  |  | 2022 |  |  | 2021 |  |
| Balance at beginning of period |  | $ | 2,053 |  |  | $ | 2,155 |  |  | $ | 2,066 |  |  | $ | 2,053 |  |
| Acquired warranty obligations |  |  | - |  |  |  | - |  |  |  | - |  |  |  | 248 |  |
| Change in accruals for warranties during the period |  |  | 535 |  |  |  | 206 |  |  |  | 1,191 |  |  |  | 520 |  |
| Settlements during the period |  |  | (592 | ) |  |  | (143 | ) |  |  | (1,261 | ) |  |  | (603 | ) |
| Balance at end of period |  | $ | 1,996 |  |  | $ | 2,218 |  |  | $ | 1,996 |  |  | $ | 2,218 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0001437749-23-002270:notes:121]
[same as prior period, unchanged from 0001437749-22-025367:notes:121]

[0001437749-23-002270:notes:122]
The Company recorded an income tax expense of $0.1 million in each of the three and nine months ended  December 31, 2022. The Company recorded an income tax expense of less than $0.1 million and income tax benefit of $1.9 million in the three and nine months ended  December 31, 2021, respectively.

[0001437749-23-002270:notes:123]
As a result of a difference in book and tax basis related to the intangible assets acquired in the Neeltran Acquisition (see Note 2, "Acquisitions"), the Company recorded a deferred tax liability of $2.3 million during the nine months ended  December 31, 2021. As a result, the Company was able to benefit from additional deferred tax assets and therefore released a corresponding valuation allowance of $2.3 million during the nine months ended  December 31, 2021. Goodwill recognized in the Neeltran Acquisition is not deductible for tax purposes.

[0001437749-23-002270:notes:124]
Accounting for income taxes requires a two-step approach to recognizing and measuring uncertain tax positions.  The first step is to evaluate the tax position for recognition by determining if, based on the technical merits, it is more likely than not the position will be sustained upon audit, including resolution of related appeals or litigation processes, if any.  The second step is to measure the tax benefit as the largest amount that is more than 50% likely to be realized upon ultimate settlement.  The Company re-evaluates these uncertain tax positions on a quarterly basis.  The evaluation is based on factors including, but not limited to, changes in facts or circumstances, changes in tax law, effectively settled issues under audit and new audit activity.  Any changes in these factors could result in the recognition of a tax benefit or an additional charge to the tax provision.  The Company did not identify any uncertain tax positions in the nine months ended  December 31, 2022 and did not have any gross unrecognized tax benefits as of  December 31, 2022.


## amsc:BusinessCombinationContingentConsiderationTextBlock

[0001437749-23-002270:notes:125]
[same as prior period, unchanged from 0001437749-22-025367:notes:125]

[0001437749-23-002270:notes:126]
[same as prior period, unchanged from 0001437749-22-025367:notes:126]

[0001437749-23-002270:notes:127]
[same as prior period, unchanged from 0001437749-22-025367:notes:127]

[0001437749-23-002270:notes:128]
|  |  |  | December 31, |  |  |  | September 30, |  |  |  | June 30, |  |  |  |  |  |  |  |  |  |
| Fiscal Year 2022 |  |  | 2022 |  |  |  | 2022 |  |  |  | 2022 |  |  |  |  |  |  |  |  |  |
| Revenue risk premium |  |  | 5.30 | % |  |  | 5.20 | % |  |  | 6.60 | % |  |  |  |  |  |  |  |  |
| Revenue volatility |  |  | 25 | % |  |  | 25 | % |  |  | 30 | % |  |  |  |  |  |  |  |  |
| Stock Price |  | $ | 3.68 |  |  | $ | 4.38 |  |  | $ | 5.18 |  |  |  |  |  |  |  |  |  |
| Payment delay (days) |  |  | 80 |  |  |  | 80 |  |  |  | 80 |  |  |  |  |  |  |  |  |  |
| Fair value (millions) |  | $ | 0.9 |  |  | $ | 1.1 |  |  | $ | 1.4 |  |  |  |  |  |  |  |  |  |
|  |  | March 31, |  |  | December 31, |  |  | September 30, |  |  | June 30, |  |  | March 31, |  |
| Fiscal Year 2021 |  | 2022 |  |  | 2021 |  |  | 2021 |  |  | 2021 |  |  | 2021 |  |
| Revenue risk premium |  |  | 6.50 | % |  |  | 6.60 | % |  |  | 6.60 | % |  |  | 6.60 | % |  |  | 6.70 | % |
| Revenue volatility |  |  | 33 | % |  |  | 33 | % |  |  | 30 | % |  |  | 30 | % |  |  | 30 | % |
| Stock Price |  | $ | 7.61 |  |  | $ | 10.88 |  |  | $ | 14.58 |  |  | $ | 17.39 |  |  | $ | 18.96 |  |
| Payment delay (days) |  |  | 80 |  |  |  | 80 |  |  |  | 80 |  |  |  | 80 |  |  |  | 80 |  |
| Fair value (millions) |  | $ | 1.2 |  |  | $ | 2.6 |  |  | $ | 4.7 |  |  | $ | 7.2 |  |  | $ | 7.1 |  |

[0001437749-23-002270:notes:129]
The Company recorded a net gain of $0.2 million and $0.3 million resulting from the decrease in the fair value of the contingent consideration in the three and nine months ended  December 31, 2022. The Company recorded a net gain of $2.1 million and $4.4 million resulting from the decrease in the fair value of the contingent consideration in the three and nine months ended  December 31, 2021, respectively.


## us-gaap:DebtDisclosureTextBlock

[0001437749-23-002270:notes:130]
14. Debt

[0001437749-23-002270:notes:131]
As part of the Neeltran Acquisition, the Company identified four equipment financing agreements that Neeltran had entered into prior to the acquisition on  May 6, 2021. The Company determined to account for these agreements as a debt transaction and recorded current and long-term debt liabilities of $0.1 million each during the three months ended  June 30, 2021. The current and long-term debt balance is $0.1 million and less than $0.1 million as of  December 31, 2022, respectively.


## us-gaap:LesseeOperatingLeasesTextBlock

[0001437749-23-002270:notes:132]
[same as prior period, unchanged from 0001437749-22-025367:notes:132]

[0001437749-23-002270:notes:133]
[same as prior period, unchanged from 0001437749-22-025367:notes:133]

[0001437749-23-002270:notes:134]
[same as prior period, unchanged from 0001437749-22-025367:notes:134]

[0001437749-23-002270:notes:135]
[same as prior period, unchanged from 0001437749-22-025367:notes:135]

[0001437749-23-002270:notes:136]
[same as prior period, unchanged from 0001437749-22-025367:notes:136]

[0001437749-23-002270:notes:137]
[same as prior period, unchanged from 0001437749-22-025367:notes:137]

[0001437749-23-002270:notes:138]
[same as prior period, unchanged from 0001437749-22-025367:notes:138]

[0001437749-23-002270:notes:139]
[same as prior period, unchanged from 0001437749-22-025367:notes:139]

[0001437749-23-002270:notes:140]
As part of the adoption of ASC 842 at Neeltran, the Company identified one lease contract that is classified as a finance lease. In  February 2020, Neeltran entered into a contract to lease a copy machine for an initial term of 39 months, or through  May 2023. The Company concluded that the lease should be classified and accounted for as a finance lease as the total value of the lease payments are greater than fair value of the asset. Accordingly, on  May 6, 2021, the Company recognized a finance lease right-of-use asset and a finance lease liability of $13.2 thousand on the Neeltran opening balance sheet. As of  December 31, 2022, the right-of-use asset related to the finance lease was $2.6 thousand, net of accumulated amortization of $10.6 thousand, and is included in the property and equipment, net on the Company's consolidated balance sheet.

[0001437749-23-002270:notes:141]
[same as prior period, unchanged from 0001437749-22-025367:notes:141]

[0001437749-23-002270:notes:142]
Supplemental balance sheet information related to leases at  December 31, 2022, and  March 31, 2022 are as follows (in thousands):

[0001437749-23-002270:notes:143]
|  |  | December 31, 2022 |  |  | March 31, 2022 |  |
| Leases: |  |  |  |  |  |  |  |  |
| Right-of-use assets - Financing |  | $ | 3 |  |  |  | 8 |  |
| Right-of-use assets - Operating |  |  | 3,068 |  |  |  | 3,502 |  |
| Total right-of-use assets |  |  | 3,071 |  |  |  | 3,510 |  |
| Lease liabilities - ST Financing |  | $ | 3 |  |  |  | 7 |  |
| Lease liabilities - ST Operating |  |  | 819 |  |  |  | 740 |  |
| Lease liabilities - LT Financing |  |  | - |  |  |  | 1 |  |
| Lease liabilities - LT Operating |  |  | 2,375 |  |  |  | 2,900 |  |
| Total lease liabilities |  |  | 3,197 |  |  |  | 3,648 |  |
| Weighted-average remaining lease term |  |  | 4.12 |  |  |  | 4.93 |  |
| Weighted-average discount rate |  |  | 6.42 | % |  |  | 6.36 | % |

[0001437749-23-002270:notes:144]
The costs related to the Company's finance lease are not material. The costs related to the Company's operating leases for the three and nine months ended  December 31, 2022 and 2021 are as follows (in thousands):

[0001437749-23-002270:notes:145]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | December 31, 2022 |  |  | December 31, 2022 |  |
| Operating Leases: |  |  |  |  |  |  |  |  |
| Operating lease costs - fixed |  | $ | 256 |  |  | $ | 765 |  |
| Operating lease costs - variable |  |  | 41 |  |  |  | 118 |  |
| Short-term lease costs |  |  | 30 |  |  |  | 92 |  |
| Total lease costs |  |  | 327 |  |  |  | 975 |  |

[0001437749-23-002270:notes:146]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | December 31, 2021 |  |  | December 31, 2021 |  |
| Operating Leases: |  |  |  |  |  |  |  |  |
| Operating lease costs - fixed |  | $ | 238 |  |  | $ | 707 |  |
| Operating lease costs - variable |  |  | 33 |  |  |  | 97 |  |
| Short-term lease costs |  |  | 64 |  |  |  | 195 |  |
| Total lease costs |  |  | 335 |  |  |  | 999 |  |

[0001437749-23-002270:notes:147]
[same as prior period, unchanged from 0001437749-22-025367:notes:147]

[0001437749-23-002270:notes:148]
|  |  | Leases |  |
| Year ended March 31, |  |  |  |  |
| 2023 |  | $ | 256 |  |
| 2024 |  |  | 973 |  |
| 2025 |  |  | 780 |  |
| 2026 |  |  | 720 |  |
| 2027 |  |  | 579 |  |
| Thereafter |  |  | 357 |  |
| Total minimum lease payments |  |  | 3,665 |  |
| Less: interest |  |  | 468 |  |
| Present value of lease liabilities |  |  | 3,197 |  |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001437749-23-002270:notes:149]
16. Commitments and Contingencies

[0001437749-23-002270:notes:150]
Legal Contingencies

[0001437749-23-002270:notes:151]
From time to time, the Company is involved in legal and administrative proceedings and claims of various types. The Company records a liability in its consolidated financial statements for these matters when a loss is known or considered probable and the amount can be reasonably estimated. The Company reviews these estimates each accounting period as additional information is known and adjusts the loss provision when appropriate. If a matter is both probable to result in a liability and the amounts of loss can be reasonably estimated, the Company estimates and discloses the possible loss or range of loss to the extent necessary to make the consolidated financial statements not misleading. If the loss is not probable or cannot be reasonably estimated, a liability is not recorded in its consolidated financial statements.

[0001437749-23-002270:notes:152]
Other

[0001437749-23-002270:notes:153]
The Company enters into long-term construction contracts with customers that require the Company to obtain performance bonds. The Company is required to deposit an amount equivalent to some or all the face amount of the performance bonds into an escrow account until the termination of the bond. When the performance conditions are met, amounts deposited as collateral for the performance bonds are returned to the Company. In addition, the Company has various contractual arrangements in which minimum quantities of goods or services have been committed to be purchased on an annual basis.

[0001437749-23-002270:notes:154]
As of  December 31, 2022, the Company had $1.0 million of restricted cash included in long-term assets and $6.6 million of restricted cash included in current assets. As of  March 31, 2022, the Company had $6.1 million of restricted cash included in long term assets and $2.8 million of restricted cash included in current assets. These amounts included in restricted cash primarily represent deposits to secure letters of credit for various supply contracts and long-term projects, including the irrevocable letter of credit in the amount of $5.0 million to secure certain of the Company's obligations under a subcontract agreement with ComEd.  These deposits are held in interest bearing accounts.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001437749-23-002270:notes:155]
[same as prior period, unchanged from 0001437749-22-025367:notes:155]

[0001437749-23-002270:notes:156]
[same as prior period, unchanged from 0001437749-22-025367:notes:156]

[0001437749-23-002270:notes:157]
[same as prior period, unchanged from 0001437749-22-025367:notes:157]

[0001437749-23-002270:notes:158]
[same as prior period, unchanged from 0001437749-22-025367:notes:158]

[0001437749-23-002270:notes:159]
[same as prior period, unchanged from 0001437749-22-025367:notes:159]

[0001437749-23-002270:notes:160]
|  |  | Three Months Ended December 31, |  |  | Nine Months Ended December 31, |  |
|  |  | 2022 |  |  | 2021 |  |  | 2022 |  |  | 2021 |  |
| Revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Grid |  | $ | 20,809 |  |  | $ | 25,050 |  |  | $ | 66,337 |  |  | $ | 73,169 |  |
| Wind |  |  | 3,072 |  |  |  | 1,749 |  |  |  | 7,904 |  |  |  | 6,957 |  |
| Total |  | $ | 23,881 |  |  | $ | 26,799 |  |  | $ | 74,241 |  |  | $ | 80,126 |  |

[0001437749-23-002270:notes:161]
|  |  | Three Months Ended December 31, |  |  | Nine Months Ended December 31, |  |
|  |  | 2022 |  |  | 2021 |  |  | 2022 |  |  | 2021 |  |
| Operating loss: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Grid |  | $ | (7,064 | ) |  | $ | (3,691 | ) |  | $ | (20,840 | ) |  | $ | (14,873 | ) |
| Wind |  |  | (924 | ) |  |  | (1,678 | ) |  |  | (2,178 | ) |  |  | (2,236 | ) |
| Unallocated corporate expenses |  |  | (1,221 | ) |  |  | 989 |  |  |  | (3,152 | ) |  |  | 927 |  |
| Total |  | $ | (9,209 | ) |  | $ | (4,380 | ) |  | $ | (26,170 | ) |  | $ | (16,182 | ) |

[0001437749-23-002270:notes:162]
[same as prior period, unchanged from 0001437749-22-025367:notes:162]

[0001437749-23-002270:notes:163]
Unallocated corporate expenses consist of a gain on contingent consideration of $0.2 million and $0.3 million in the three and nine months ended  December 31, 2022. Unallocated corporate expenses consist of a gain on contingent consideration of $2.1 million and $4.4 million in the three and nine months ended  December 31, 2021. Additionally, unallocated corporate expenses consist of stock-based compensation expense of $1.4 million and $1.1 million in the three months ended  December 31, 2022, and 2021, respectively and $3.5 million in each of the nine months ended  December 31, 2022 and 2021, respectively.

[0001437749-23-002270:notes:164]
Total assets for the two business segments as of  December 31, 2022, and  March 31, 2022, are as follows (in thousands):

[0001437749-23-002270:notes:165]
|  |  | December 31, 2022 |  |  | March 31, 2022 |  |
| Grid |  | $ | 123,664 |  |  | $ | 114,053 |  |
| Wind |  |  | 10,005 |  |  |  | 9,866 |  |
| Corporate assets |  |  | 31,403 |  |  |  | 49,968 |  |
| Total |  | $ | 165,072 |  |  | $ | 173,887 |  |


## us-gaap:NewAccountingPronouncementsAndChangesInAccountingPrinciplesTextBlock

[0001437749-23-002270:notes:166]
18. Recent Accounting Pronouncements

[0001437749-23-002270:notes:167]
In  June 2016, the FASB issued ASU 2016-13, Financial Instruments-Credit Losses (Topic 326): Measurement of Credit Losses on Financial Instruments. The amendments in ASU 2016-13 will provide more decision-useful information about the expected credit losses on financial instruments and other commitments to extend credit held by a reporting entity at each reporting date. Following the release of ASU 2019-10 in  November 2019, the new effective date, as long as the Company remains a smaller reporting company, would be annual reporting periods beginning after  December 15, 2022. The Company evaluated the impact of the adoption of ASU 2016-13, and does not expect it to have a material impact on its consolidated financial statements.

[0001437749-23-002270:notes:168]
In  October 2021, the FASB issued ASU 2021-08, Business Combinations (Topic 805): Accounting for Contract Assets and Contract Liabilities from Contracts with Customers. The amendments in ASU 2021-08 will improve the accounting for acquired revenue contracts with customers in a business combination. Following the release of ASU 2021-08 in  October 2021, the new effective date will be annual reporting periods beginning after  December 15, 2022. The Company evaluated the impact of the adoption of ASU 2021-08, and does not expect it to have a material impact on its consolidated financial statements.

[0001437749-23-002270:notes:169]
In  November 2021, the FASB issued ASU 2021-10, Government Assistance (Topic 832): Disclosures by Business Entities about Government Assistance. The amendments in ASU 2021-10 will improve financial reporting by requiring disclosures that increase the transparency of transactions with government accounted for by applying a grant or contribution accounting model by analogy. Following the release of ASU 2021-10 in  November 2021, the new effective date will be annual reporting periods beginning after  December 15, 2021. As of  April 1, 2022, the Company has adopted ASU 2021-10 and noted no material impact on its consolidated financial statements.


## us-gaap:SubsequentEventsTextBlock

[0001437749-23-002270:notes:170]
19. Subsequent Events

[0001437749-23-002270:notes:171]
The Company has performed an evaluation of subsequent events through the time of filing this Quarterly Report on Form 10-Q with the SEC and has determined that there are no such events to report.
