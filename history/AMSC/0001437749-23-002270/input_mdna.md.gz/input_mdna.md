# AMSC MD&A — 0001437749-23-002270


## mdna

[0001437749-23-002270:mdna:1]
[same as prior period, unchanged from 0001437749-22-025367:mdna:1]

[0001437749-23-002270:mdna:2]
[same as prior period, unchanged from 0001437749-22-025367:mdna:2]

[0001437749-23-002270:mdna:3]
[same as prior period, unchanged from 0001437749-22-025367:mdna:3]

[0001437749-23-002270:mdna:4]
[same as prior period, unchanged from 0001437749-22-025367:mdna:4]

[0001437749-23-002270:mdna:5]
[same as prior period, unchanged from 0001437749-22-025367:mdna:5]

[0001437749-23-002270:mdna:6]
[same as prior period, unchanged from 0001437749-22-025367:mdna:6]

[0001437749-23-002270:mdna:7]
[same as prior period, unchanged from 0001437749-22-025367:mdna:7]

[0001437749-23-002270:mdna:8]
[same as prior period, unchanged from 0001437749-22-025367:mdna:8]

[0001437749-23-002270:mdna:9]
[same as prior period, unchanged from 0001437749-22-025367:mdna:9]

[0001437749-23-002270:mdna:10]
[same as prior period, unchanged from 0001437749-22-025367:mdna:10]

[0001437749-23-002270:mdna:11]
On October 31, 2018, we entered into a Subcontract Agreement with Commonwealth Edison Company (“ComEd”) (the “Subcontract Agreement”) for the manufacture and installation of the Company’s resilient electric grid ("REG") system within ComEd’s electric grid in Chicago, Illinois (the “Project”). As provided in the Subcontract Agreement, the Subcontract Agreement became effective upon the signing of an amendment by us and the U.S. Department of Homeland Security (“DHS”) to the existing contract (the “Prime Contract”) between us and DHS on June 20, 2019. Unless terminated earlier by us, ComEd or DHS according to the terms of the Subcontract Agreement, the term of the Subcontract Agreement will continue until we complete our warranty obligations under the Subcontract Agreement. Under the terms of the Subcontract Agreement, we agreed, among other things, to provide the REG system and to supervise ComEd’s installation of the REG system in Chicago. As part of our separate cost sharing arrangement with DHS under the Prime Contract, we received funding provided by DHS in connection with the Subcontract Agreement of approximately $10.0 million, which represents the total amount of revenue we recognized over the term of the Subcontract Agreement and includes $1.0 million that we have agreed to reimburse ComEd for costs incurred by ComEd while undertaking its tasks under the Subcontract Agreement (the “Reimbursement Amount”). In addition, we are required to deliver an irrevocable letter of credit in the amount of $5.0 million to secure certain Company obligations under the Subcontract Agreement, which we have done, and deposited $5.0 million in an escrow account as collateral to secure such letter of credit. We expect that this irrevocable letter of credit will be terminated and the full $5.0 million will be returned from escrow to us during the quarter ending March 31, 2023. ComEd has agreed to provide the site and provide all civil engineering work required to support the operation and integration of the REG system into ComEd’s electric grid. Other than the Reimbursement Amount, ComEd is responsible for its own costs and expenses. DHS’s approval to commence with construction was obtained on June 20, 2019. Substation work on the project began in late 2019 and we successfully integrated the REG system on Com Ed's electric power grid and the REG system became fully operational in August 2021.

[0001437749-23-002270:mdna:12]
We are experiencing substantial inflationary pressure in our supply chain and some delays in sourcing materials needed for our products, resulting in some production disruption both of which have increased our cost of revenues and decreased gross margin. Changes in macroeconomic and market conditions arising from the COVID-19 pandemic, or for other reasons, such as the ongoing war between Russia and Ukraine, inflation, rising interest rates, labor force availability, sourcing, material delays and global supply chain disruptions could have a material adverse effect on our business, financial condition and results of operation.

[0001437749-23-002270:mdna:13]
From time-to-time we may undertake restructuring activities in order to align our global organization in a manner that we believe will better position us to achieve our long-term goals. In January 2023, we undertook a reduction in force that involved approximately 5% of our global workforce. This restructuring is expected to incur an immaterial amount of cash expense and to result in annualized cost savings of approximately $5 million, beginning in fiscal year 2023.

[0001437749-23-002270:mdna:14]
[same as prior period, unchanged from 0001437749-22-025367:mdna:13]

[0001437749-23-002270:mdna:15]
[same as prior period, unchanged from 0001437749-22-025367:mdna:14]

[0001437749-23-002270:mdna:16]
[same as prior period, unchanged from 0001437749-22-025367:mdna:15]

[0001437749-23-002270:mdna:17]
Three and nine months ended December 31, 2022, compared to the three and nine months ended December 31, 2021

[0001437749-23-002270:mdna:18]
[same as prior period, unchanged from 0001437749-22-025367:mdna:17]

[0001437749-23-002270:mdna:19]
Total revenues decreased 11% to $23.9 million for the three months ended December 31, 2022 and total revenues decreased 7% to $74.2 million for the nine months ended December 31, 2022 compared to $26.8 million and $80.1 million for the three and nine months ended December 31, 2021, respectively. Our revenues are summarized as follows (in thousands):

[0001437749-23-002270:mdna:20]
|  |  | Three Months Ended December 31, |  |  | Nine Months Ended December 31, |  |
|  |  | 2022 |  |  | 2021 |  |  | 2022 |  |  | 2021 |  |
| Revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Grid |  | $ | 20,809 |  |  | $ | 25,050 |  |  | $ | 66,337 |  |  | $ | 73,169 |  |
| Wind |  |  | 3,072 |  |  |  | 1,749 |  |  |  | 7,904 |  |  |  | 6,957 |  |
| Total |  | $ | 23,881 |  |  | $ | 26,799 |  |  | $ | 74,241 |  |  | $ | 80,126 |  |

[0001437749-23-002270:mdna:21]
Our Grid business unit accounted for 87% and 89% of total revenues for the three and nine months ended December 31, 2022, respectively, compared to 93% and 91% for the three and nine months ended December 31, 2021, respectively. Our Grid business unit revenues decreased 17% to $20.8 million in the three months ended December 31, 2022, from $25.0 million in the three months ended December 31, 2021. Our Grid business unit revenues decreased 9% to $66.3 million in the nine months ended December 31, 2022, from $73.2 million in the nine months ended December 31, 2021. The decrease in the Grid business unit revenue in the three and nine months ended December 31, 2022, was primarily driven by lower D-VAR revenues than in the prior year periods.

[0001437749-23-002270:mdna:22]
Our Wind business unit accounted for 13% and 11% of total revenues for the three and nine months ended December 31, 2022, respectively, compared to 7% and 9% for the three and nine months ended December 31, 2021, respectively. Revenues in the Wind business unit increased 76% and 14% to $3.1 million and $7.9 million in the three and nine months ended December 31, 2022, from $1.7 million and $7.0 million in the three and nine months ended December 31, 2021, respectively. The increase in the three and nine months ended December 31, 2022, was driven by additional shipments of electrical control systems ("ECS") to Inox in the three months ended December 31, 2022.

[0001437749-23-002270:mdna:23]
[same as prior period, unchanged from 0001437749-22-025367:mdna:22]

[0001437749-23-002270:mdna:24]
Cost of revenues increased by 1% to $23.4 million for the three months ended December 31, 2022, compared to $23.2 million for the three months ended December 31, 2021. Cost of revenues decreased by less than 1% to $69.5 million for the nine months ended December 31, 2022, compared to $69.9 million for the nine months ended December 31, 2021. Gross margin was 2% and 6% for the three and nine months ended December 31, 2022, respectively, compared to 13% for both the three and nine months ended December 31, 2021.  The decrease in gross margin in the three and nine months ended December 31, 2022, was due to lower revenues, contract losses, an unfavorable product mix and inflation pressure in our supply chain.

[0001437749-23-002270:mdna:25]
[same as prior period, unchanged from 0001437749-22-025367:mdna:24]

[0001437749-23-002270:mdna:26]
[same as prior period, unchanged from 0001437749-22-025367:mdna:25]

[0001437749-23-002270:mdna:27]
Research and development ("R&D") expense decreased 22% in the three months ended December 31, 2022, to $2.1 million from $2.7 million in the three months ended December 31, 2021. R&D expense decreased 15% in the nine months ended December 31, 2022, to $7.1 million from $8.4 million in the nine months ended December 31, 2021. The decrease in R&D expense was due to lower overall compensation expense and an increase in utilization of our research engineers supporting funded projects.

[0001437749-23-002270:mdna:28]
[same as prior period, unchanged from 0001437749-22-025367:mdna:27]

[0001437749-23-002270:mdna:29]
Selling, general and administrative ("SG&A") expenses increased 6% in the three months ended December 31, 2022, to $7.2 million from $6.8 million in the three months ended December 31, 2021. The increase in SG&A expense in the three months ended December 31, 2022, was due to higher stock compensation expense than in the prior year period. SG&A expenses increased 7% to $22.1 million in the nine months ended December 31, 2022, compared to $20.6 million in the nine months ended December 31, 2021. The increase in SG&A expense in the nine months ended December 31, 2022, was due to higher overall sales expense than in the prior year period.

[0001437749-23-002270:mdna:30]
[same as prior period, unchanged from 0001437749-22-025367:mdna:29]

[0001437749-23-002270:mdna:31]
We recorded amortization expense related to our core technology and know-how, customer relationships, and other intangible assets of $0.7 million and $2.1 million in the three and nine months ended December 31, 2022, respectively, and $0.6 million and $1.8 million in the three and nine months ended December 31, 2021, respectively. The increase in amortization expense is a result of additional expense tied to the acquisition of Neeltran.

[0001437749-23-002270:mdna:32]
[same as prior period, unchanged from 0001437749-22-025367:mdna:31]

[0001437749-23-002270:mdna:33]
The change in fair value of our contingent consideration for the earnout payment on the NEPSI Acquisition resulted in a gain of $0.2 million and $0.3 million in the three and nine months ended December 31, 2022, respectively, compared to a gain of $2.1 million and $4.4 million in the three and nine months ended December 31, 2021, respectively. The change in the fair value was primarily driven by a decreased likelihood of achieving certain revenue targets and a decline in the Company's stock price.

[0001437749-23-002270:mdna:34]
[same as prior period, unchanged from 0001437749-22-025367:mdna:33]

[0001437749-23-002270:mdna:35]
[same as prior period, unchanged from 0001437749-22-025367:mdna:34]

[0001437749-23-002270:mdna:36]
|  |  | Three Months Ended December 31, |  |  | Nine Months Ended December 31, |  |
|  |  | 2022 |  |  | 2021 |  |  | 2022 |  |  | 2021 |  |
| Operating loss: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Grid |  | $ | (7,064 | ) |  | $ | (3,691 | ) |  | $ | (20,840 | ) |  | $ | (14,873 | ) |
| Wind |  |  | (924 | ) |  |  | (1,678 | ) |  |  | (2,178 | ) |  |  | (2,236 | ) |
| Unallocated corporate expenses |  |  | (1,221 | ) |  |  | 989 |  |  |  | (3,152 | ) |  |  | 927 |  |
| Total |  | $ | (9,209 | ) |  | $ | (4,380 | ) |  | $ | (26,170 | ) |  | $ | (16,182 | ) |

[0001437749-23-002270:mdna:37]
Our Grid business segment generated operating losses of $7.1 million and $20.9 million in the three and nine months ended December 31, 2022, compared to operating losses of $3.7 million and $14.9 million in the three and nine months ended December 31, 2021. The increase in the Grid business unit operating loss in the three months ended December 31, 2022, was due to lower gross margins due to an unfavorable product mix, and higher operating expenses. The increase in the Grid business unit operating loss in the nine months ended December 31, 2022 was due to lower revenues and gross margins.

[0001437749-23-002270:mdna:38]
Our Wind business segment generated operating losses of $0.9 million and $2.2 million in the three and nine months ended December 31, 2022, compared to operating losses of $1.7 million and $2.2 million in the three and nine months ended December 31, 2021, respectively. The decrease in the Wind business unit operating loss was due to higher revenues and gross margins.

[0001437749-23-002270:mdna:39]
Unallocated corporate expenses included a gain on contingent consideration of $0.2 million and $0.3 million in the three and nine months ended December 31, 2022. Unallocated corporate expenses consisted of a gain on contingent consideration of $2.1 million and $4.4 million in the three and nine months ended December 31, 2021, respectively. Additionally, unallocated corporate expenses primarily consisted of stock-based compensation expense of $1.4 million and $1.1 million in the three months ended December 31, 2022 and 2021, respectively, and $3.5 million in each of the nine months ended December 31, 2022 and 2021, respectively.

[0001437749-23-002270:mdna:40]
[same as prior period, unchanged from 0001437749-22-025367:mdna:39]

[0001437749-23-002270:mdna:41]
Interest income, net, was less than $0.1 million in the three months ended December 31, 2022 and 2021, respectively. Interest income, net, was $0.1 million in the nine months ended December 31, 2022 and less than $0.1 million in the nine months ended December 31, 2021.

[0001437749-23-002270:mdna:42]
[same as prior period, unchanged from 0001437749-22-025367:mdna:41]

[0001437749-23-002270:mdna:43]
China dissolution was
    $1.9 million in the nine months ended
    December 31, 2022 compared to no activity in the 
    three and nine
     months ended 
    December 31, 2021
    . The increase in China dissolution during the nine months ended December 31, 2022, was driven by the liquidation of our China entity, resulting in a foreign currency gain/loss from the cumulative translation release of $1.9 million in the nine months ended December 31, 2022 in which there was no similar transaction in the three and nine months ended December 31, 2021.

[0001437749-23-002270:mdna:44]
[same as prior period, unchanged from 0001437749-22-025367:mdna:44]

[0001437749-23-002270:mdna:45]
Other expense, net, was $0.3 million and less than $0.1 million in the three and nine months ended December 31, 2022, respectively, compared to other income, net, of less than $0.1 million in both the three and nine months ended December 31, 2021. The increase in other expense during the three and nine months ended December 31, 2022, was driven by the impacts of unfavorable fluctuations in foreign currencies during the respective periods.

[0001437749-23-002270:mdna:46]
[same as prior period, unchanged from 0001437749-22-025367:mdna:46]

[0001437749-23-002270:mdna:47]
Income tax expense was $0.1 million in each of the three and nine months ended December 31, 2022. Income tax expense was less than $0.1 million in the three months ended December 31, 2021 and income tax benefit was $1.9 million in the nine months ended December 31, 2021. The increase in income tax expense in the three months ended December 31, 2022 compared to the same period in fiscal 2021 was primarily due to lower withholding taxes from foreign jurisdictions in the three months ended December 31, 2022. The increase in income tax expense in the nine months ended December 31, 2022 compared to the same period in fiscal 2021 was a result of the release of the valuation allowance to offset the recording of the deferred tax liability from the Neeltran Acquisition in the nine months ended December 31, 2021.

[0001437749-23-002270:mdna:48]
[same as prior period, unchanged from 0001437749-22-025367:mdna:48]

[0001437749-23-002270:mdna:49]
Net loss was $9.6 million and $28.2 million in the three and nine months ended December 31, 2022, compared to $4.3 million and $14.2 million in the three and nine months ended December 31, 2021. The increase in net loss was driven primarily by the increased operating loss due to lower revenues and gross margins.

[0001437749-23-002270:mdna:50]
[same as prior period, unchanged from 0001437749-22-025367:mdna:50]

[0001437749-23-002270:mdna:51]
[same as prior period, unchanged from 0001437749-22-025367:mdna:51]

[0001437749-23-002270:mdna:52]
[same as prior period, unchanged from 0001437749-22-025367:mdna:52]

[0001437749-23-002270:mdna:53]
|  |  | Three Months Ended December 31, |  |  | Nine Months Ended December 31, |  |
|  |  | 2022 |  |  | 2021 |  |  | 2022 |  |  | 2021 |  |
| Net loss |  | $ | (9,581 | ) |  | $ | (4,324 | ) |  | $ | (28,171 | ) |  | $ | (14,161 | ) |
| China dissolution |  |  | — |  |  |  | — |  |  |  | 1,921 |  |  |  | — |  |
| Stock-based compensation |  |  | 1,440 |  |  |  | 1,120 |  |  |  | 3,492 |  |  |  | 3,513 |  |
| Amortization of acquisition-related intangibles |  |  | 696 |  |  |  | 690 |  |  |  | 2,096 |  |  |  | 1,979 |  |
| Acquisition costs |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 681 |  |
| Change in fair value of contingent consideration |  |  | (220 | ) |  |  | (2,110 | ) |  |  | (340 | ) |  |  | (4,440 | ) |
| Non-GAAP net loss |  | $ | (7,665 | ) |  | $ | (4,624 | ) |  | $ | (21,002 | ) |  | $ | (12,428 | ) |
| Non-GAAP net loss per share - basic |  | $ | (0.27 | ) |  | $ | (0.17 | ) |  | $ | (0.76 | ) |  | $ | (0.46 | ) |
| Weighted average shares outstanding - basic |  |  | 27,954 |  |  |  | 27,352 |  |  |  | 27,794 |  |  |  | 27,145 |  |

[0001437749-23-002270:mdna:54]
We incurred non-GAAP net losses of $7.7 million and $21.0 million, or $0.27 and $0.76 per share, for the three and nine months ended December 31, 2022, compared to $4.6 million and $12.4 million, or $0.17 and $0.46 per share, for the three and nine months ended December 31, 2021. The increase in the non-GAAP net loss for the three and nine months ended December 31, 2022 was due to a higher operating loss driven by lower gross margin and higher operating expenses.

[0001437749-23-002270:mdna:55]
[same as prior period, unchanged from 0001437749-22-025367:mdna:55]

[0001437749-23-002270:mdna:56]
We have experienced recurring operating losses and, as of December 31, 2022, had an accumulated deficit of $1,049 million.

[0001437749-23-002270:mdna:57]
[same as prior period, unchanged from 0001437749-22-025367:mdna:57]

[0001437749-23-002270:mdna:58]
[same as prior period, unchanged from 0001437749-22-025367:mdna:58]

[0001437749-23-002270:mdna:59]
As of December 31, 2022, we had cash, cash equivalents and restricted cash of $31.4 million, compared to $49.5 million as of March 31, 2022, a decrease of $18.1 million. As of December 31, 2022, we had approximately $1.8 million of cash, cash equivalents, and restricted cash in foreign bank accounts. Our cash, cash equivalents, and restricted cash are summarized as follows (in thousands):

[0001437749-23-002270:mdna:60]
|  |  | December 31, 2022 |  |  | March 31, 2022 |  |
| Cash and cash equivalents |  | $ | 23,685 |  |  | $ | 40,584 |  |
| Restricted cash |  |  | 7,666 |  |  |  | 8,902 |  |
| Total cash, cash equivalents, and restricted cash |  | $ | 31,351 |  |  | $ | 49,486 |  |

[0001437749-23-002270:mdna:61]
For the nine months ended December 31, 2022, net cash used in operating activities was $17.1 million, compared to $15.9 million for the nine months ended December 31, 2021.  The increase in net cash used in operations was due primarily to an increase in inventory purchases offset by accounts receivable collections in the nine months ended December 31, 2022 as compared to December 31, 2021.

[0001437749-23-002270:mdna:62]
For the nine months ended December 31, 2022, net cash used in investing activities was $1.2 million, compared to $7.1 million for the nine months ended December 31, 2021. The decrease in net cash used in investing activities was primarily due to the cash that was used to pay for the Neeltran Acquisition in the nine months ended December 31, 2021. There was no such transaction in the nine months ended December 31, 2022.

[0001437749-23-002270:mdna:63]
For the nine months ended December 31, 2022 and 2021, respectively, net cash provided by financing activities remained consistent at less than $0.1 million.

[0001437749-23-002270:mdna:64]
As of December 31, 2022, we had $1.0 million of restricted cash included in long-term assets and $6.6 million of restricted cash included in current assets.  These amounts of restricted cash primarily represent deposits to secure letters of credit for various supply contracts and long-term projects, including the irrevocable letter of credit in the amount of $5.0 million to secure certain of our obligations under the Subcontract Agreement with ComEd. These deposits are held in interest bearing accounts.

[0001437749-23-002270:mdna:65]
We are a party to many contractual obligations involving commitments to make payments to third parties. These obligations impact our short-term and long-term liquidity and capital resource needs. Certain contractual obligations are reflected on the consolidated balance sheet as of December 31, 2022, while others are considered future commitments. We have various contractual arrangements, under which we have committed to purchase certain minimum quantities of goods or services on an annual basis. For information regarding our other contractual obligations, refer to Note 13, "Contingent Consideration," Note 14, "Debt," Note 15, "Leases" and Note 16, "Commitments and Contingencies" to our condensed consolidated financial statements included elsewhere in this Quarterly Report on Form 10-Q.

[0001437749-23-002270:mdna:66]
[same as prior period, unchanged from 0001437749-22-025367:mdna:66]

[0001437749-23-002270:mdna:67]
Legal Proceedings

[0001437749-23-002270:mdna:68]
We are involved in legal and administrative proceedings and claims of various types. See Part II, Item 1, “Legal Proceedings,” for additional information. We record a liability in our consolidated financial statements for these matters when a loss is known or considered probable and the amount can be reasonably estimated. We review these estimates each accounting period as additional information is known and adjust the loss provision when appropriate. If a matter is both probable to result in liability and the amounts of loss can be reasonably estimated, we estimate and disclose the possible loss or range of loss to the extent necessary to make the consolidated financial statements not misleading. If the loss is not probable or cannot be reasonably estimated, a liability is not recorded in our consolidated financial statements.

[0001437749-23-002270:mdna:69]
[same as prior period, unchanged from 0001437749-22-025367:mdna:69]

[0001437749-23-002270:mdna:70]
In June 2016, the FASB issued ASU 2016-13, Financial Instruments-Credit Losses (Topic 326): Measurement of Credit Losses on Financial Instruments. The amendments in ASU 2016-13 will provide more decision-useful information about the expected credit losses on financial instruments and other commitments to extend credit held by a reporting entity at each reporting date. Following the release of ASU 2019-10 in November 2019, the new effective date, as long as we remain a smaller reporting company, would be annual reporting periods beginning after December 15, 2022. We have evaluated the impact of the adoption of ASU 2016-13, and do not expect it to have a material impact on our consolidated financial statements.

[0001437749-23-002270:mdna:71]
In October 2021, the FASB issued ASU 2021-08, Business Combinations (Topic 805): Accounting for Contract Assets and Contract Liabilities from Contracts with Customers. The amendments in ASU 2021-08 will improve the accounting for acquired revenue contracts with customers in a business combination. Following the release of ASU 2021-08 in October 2021, the new effective date will be annual reporting periods beginning after December 15, 2022. We have evaluated the impact of the adoption of ASU 2021-08, and do not expect it to have a material impact on our consolidated financial statements.

[0001437749-23-002270:mdna:72]
In November 2021, the FASB issued ASU 2021-10, Government Assistance (Topic 832): Disclosures by Business Entities about Government Assistance. The amendments in ASU 2021-10 improve financial reporting by requiring disclosures that increase the transparency of transactions with government accounted for by applying a grant or contribution accounting model by analogy. Following the release of ASU 2021-10 in November 2021, the effective date was annual reporting periods beginning after December 15, 2021. As of April 1, 2022, we have adopted ASU 2021-10 and noted no material impact on our consolidated financial statements.

[0001437749-23-002270:mdna:73]
We do not believe that, outside of those disclosed here, there are any other recently issued accounting pronouncements that will have a material impact on our consolidated financial statements.
