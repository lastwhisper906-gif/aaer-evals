# AMSC 8-K — 0001437749-23-002268 filed 2023-02-01

## item codes, every 8-K on or before 2023-02-01

- 2023-02-01 0001437749-23-002268 — 2.02, 9.01
- 2022-11-01 0001437749-22-025365 — 2.02, 9.01
- 2022-08-05 0001193125-22-213651 — 5.02, 5.07, 9.01
- 2022-08-03 0001437749-22-018628 — 2.02, 9.01
- 2022-06-10 0001437749-22-014780 — 5.02, 9.01
- 2022-06-01 0001437749-22-014033 — 2.02, 9.01
- 2022-02-02 0001437749-22-002207 — 2.02, 9.01
- 2021-11-08 0001437749-21-025697 — 2.02, 9.01
- 2021-08-04 0001437749-21-018522 — 2.02, 9.01
- 2021-08-02 0001193125-21-233260 — 5.07
- 2021-06-02 0001437749-21-013955 — 2.02, 9.01
- 2021-05-25 0001437749-21-013279 — 5.02, 9.01
- 2021-05-21 0001193125-21-168626 — 8.01, 9.01
- 2021-05-10 0001193125-21-156251 — 1.01, 9.01
- 2021-02-26 0001193125-21-060434 — 8.01, 9.01
- 2021-02-03 0001437749-21-001859 — 2.02, 9.01
- 2021-02-01 0001437749-21-001681 — 5.03, 9.01
- 2020-12-14 0001437749-20-025291 — 9.01 — amendment, the index does not say of what
- 2020-11-04 0001437749-20-022520 — 2.02, 9.01
- 2020-10-26 0001193125-20-276900 — 8.01, 9.01
- 2020-10-05 0001437749-20-020735 — 2.02
- 2020-10-05 0001437749-20-020734 — 1.01, 2.01, 3.02, 9.01
- 2020-10-02 0001437749-20-020660 — 8.01
- 2020-09-16 0001437749-20-019767 — 8.01
- 2020-08-05 0001437749-20-016665 — 2.02, 5.07, 9.01
- 2020-06-02 0001437749-20-012274 — 2.02, 9.01
- 2020-05-27 0001437749-20-011837 — 5.02, 9.01
- 2020-02-05 0001437749-20-001788 — 2.02, 9.01
- 2019-11-05 0001437749-19-021590 — 2.02, 9.01
- 2019-08-06 0001437749-19-015631 — 2.02, 9.01
- 2019-08-06 0001193125-19-214189 — 5.02, 5.07, 9.01
- 2019-06-05 0001437749-19-011476 — 2.02, 5.02, 9.01
- 2019-05-24 0001437749-19-010833 — 5.02
- 2019-02-05 0001628280-19-000964 — 2.02, 8.01, 9.01
- 2018-11-06 0001628280-18-013765 — 2.02, 9.01
- 2018-10-31 0001628280-18-013204 — 1.01
- 2018-08-01 0001628280-18-010196 — 5.07
- 2018-07-31 0001628280-18-009846 — 2.02, 9.01
- 2018-07-09 0001193125-18-214745 — 1.01, 9.01
- 2018-07-03 0001628280-18-009075 — 5.02, 9.01
- 2018-06-14 0001628280-18-007877 — 5.02
- 2018-06-06 0001628280-18-007643 — 2.02, 9.01
- 2018-04-10 0001628280-18-004141 — 5.02
- 2018-04-03 0001628280-18-003952 — 2.01, 9.01
- 2018-02-05 0001628280-18-000989 — 2.02, 9.01
- 2018-02-01 0001628280-18-000826 — 1.01, 9.01
- 2017-11-07 0001628280-17-011076 — 2.02, 9.01
- 2017-09-26 0001628280-17-009444 — 3.02, 8.01
- 2017-08-08 0001628280-17-008329 — 2.02, 9.01
- 2017-08-01 0001628280-17-007765 — 5.02, 5.07
- 2017-07-03 0001193125-17-221140 — 5.02, 9.01
- 2017-05-26 0001193125-17-185503 — 8.01, 9.01
- 2017-05-25 0001628280-17-005914 — 2.02, 9.01 — amendment of 0001628280-17-005884
- 2017-05-25 0001628280-17-005884 — 2.02, 9.01
- 2017-05-10 0001193125-17-165924 — 8.01, 9.01
- 2017-05-09 0001193125-17-164273 — 5.02
- 2017-05-04 0001193125-17-158639 — 1.02, 8.01
- 2017-04-26 0001193125-17-139493 — 2.02, 9.01
- 2017-04-04 0001193125-17-109748 — 2.05, 5.02, 9.01
- 2017-02-06 0001628280-17-000899 — 2.02, 9.01
- 2017-01-27 0001193125-17-021808 — 1.01, 2.02, 9.01
- 2016-11-02 0001628280-16-020598 — 2.02, 9.01
- 2016-09-16 0001193125-16-712301 — 5.02
- 2016-08-23 0001193125-16-688767 — 8.01
- 2016-08-09 0001628280-16-018763 — 2.02, 9.01
- 2016-08-02 0001193125-16-668417 — 5.02, 5.07, 9.01
- 2016-05-31 0001564590-16-020114 — 2.02, 9.01
- 2016-05-18 0001193125-16-594515 — 5.02
- 2016-03-08 0001193125-16-496113 — 1.01
- 2016-02-09 0001193125-16-454775 — 2.02, 9.01
- 2015-12-17 0001193125-15-405566 — 1.01
- 2015-11-03 0001193125-15-363413 — 2.02, 9.01
- 2015-08-31 0001193125-15-307558 — 1.01
- 2015-08-05 0001193125-15-277824 — 2.02, 9.01
- 2015-07-31 0001193125-15-273009 — 5.07
- 2015-06-26 0001193125-15-237190 — 5.02
- 2015-06-09 0001193125-15-218028 — 8.01
- 2015-05-28 0001193125-15-202933 — 2.02, 9.01
- 2015-04-28 0001193125-15-153319 — 8.01, 9.01
- 2015-04-23 0001193125-15-144123 — 2.02, 8.01, 9.01
- 2015-04-23 0001193125-15-143608 — 8.01
- 2015-04-10 0001193125-15-126160 — 8.01
- 2015-03-24 0001193125-15-103436 — 5.03, 9.01
- 2015-03-18 0001193125-15-097034 — 5.07
- 2015-02-05 0001193125-15-034499 — 2.02, 9.01
- 2015-01-29 0001193125-15-024629 — 2.02, 9.01
- 2015-01-21 0001193125-15-016287 — 3.01, 8.01
- 2015-01-06 0001193125-15-002902 — 5.02
- 2014-12-22 0001193125-14-450591 — 1.01, 2.03, 3.02, 9.01
- 2014-11-13 0001193125-14-410207 — 1.01, 9.01
- 2014-11-07 0001193125-14-402383 — 1.02, 7.01, 9.01
- 2014-11-06 0001193125-14-399779 — 2.02, 9.01
- 2014-10-01 0001193125-14-360072 — 2.02, 8.01, 9.01
- 2014-09-04 0001193125-14-331411 — 8.01
- 2014-08-21 0001193125-14-317133 — 1.01
- 2014-08-06 0001193125-14-298306 — 5.02, 5.07, 9.01
- 2014-08-05 0001193125-14-294647 — 2.02, 9.01
- 2014-07-16 0001193125-14-269902 — 8.01
- 2014-06-23 0001193125-14-244592 — 3.02, 8.01
- 2014-06-05 0001193125-14-226459 — 2.02, 9.01
- 2014-06-05 0001193125-14-226457 — 1.01, 9.01
- 2014-03-19 0001193125-14-106558 — 2.05
- 2014-03-03 0001193125-14-078917 — 1.01, 3.02, 9.01
- 2014-02-28 0001193125-14-077480 — 8.01, 9.01
- 2014-02-06 0001193125-14-037960 — 2.02, 8.01, 9.01
- 2013-11-20 0001193125-13-447829 — 3.02, 8.01
- 2013-11-18 0001193125-13-444697 — 1.01, 2.03, 3.02, 9.01
- 2013-11-07 0001193125-13-431705 — 2.02, 9.01
- 2013-10-09 0001193125-13-395362 — 1.01, 2.03, 3.02, 9.01
- 2013-09-25 0001193125-13-378481 — 5.02, 9.01
- 2013-08-21 0001193125-13-341566 — 4.01, 9.01
- 2013-08-07 0001193125-13-323082 — 2.02, 9.01
- 2013-08-02 0001193125-13-317278 — 5.02, 5.07
- 2013-06-14 0001193125-13-258758 — 2.02, 9.01
- 2013-04-01 0001193125-13-136714 — 2.02, 8.01, 9.01
- 2013-02-20 0001193125-13-067218 — 5.02, 9.01
- 2013-02-14 0001193125-13-060131 — 1.01, 9.01
- 2013-02-11 0001193125-13-048784 — 2.02, 9.01
- 2013-01-08 0001193125-13-006861 — 5.02, 9.01
- 2012-12-21 0001193125-12-511592 — 1.01, 2.03, 3.02, 9.01
- 2012-11-28 0001193125-12-483317 — 2.05, 5.02, 7.01, 9.01
- 2012-11-06 0001193125-12-453359 — 2.02, 9.01
- 2012-08-02 0001193125-12-330534 — 2.02, 9.01
- 2012-07-27 0001193125-12-318790 — 5.02, 5.07, 9.01
- 2012-06-06 0001193125-12-261030 — 1.01, 2.02, 2.03, 3.02, 5.02, 9.01
- 2012-05-09 0001193125-12-222210 — 5.02
- 2012-04-20 0001193125-12-172045 — 8.01
- 2012-04-13 0001193125-12-162694 — 2.02, 8.01, 9.01
- 2012-04-04 0001193125-12-149102 — 1.01, 2.02, 2.03, 3.02, 9.01
- 2012-02-09 0001193125-12-048009 — 2.02, 9.01
- 2012-02-06 0001193125-12-041344 — 5.07 — amendment of 0000950123-11-102495
- 2011-12-08 0000950123-11-102495 — 5.07
- 2011-11-29 0000950123-11-100822 — 2.05
- 2011-11-09 0000950123-11-096775 — 2.02, 9.01
- 2011-10-31 0000950123-11-093390 — 1.02, 9.01
- 2011-10-07 0000950123-11-089221 — 8.01
- 2011-10-03 0000950123-11-088315 — 7.01
- 2011-09-23 0000950123-11-086288 — 2.02, 9.01
- 2011-09-15 0000950123-11-084585 — 7.01
- 2011-09-06 0000950123-11-082736 — 7.01
- 2011-08-18 0000950123-11-078526 — 3.01, 7.01, 9.01
- 2011-08-11 0000950123-11-075905 — 5.02
- 2011-08-11 0000950123-11-075904 — 2.02, 2.05, 9.01
- 2011-07-11 0000950123-11-064934 — 2.02, 4.02, 9.01
- 2011-06-30 0000950123-11-063287 — 1.01, 3.02, 9.01
- 2011-06-21 0000950123-11-060491 — 3.01, 7.01, 9.01
- 2011-06-13 0000950123-11-058656 — 1.01, 9.01
- 2011-05-24 0000950123-11-053517 — 5.02, 9.01
- 2011-04-05 0001299933-11-001020 — 2.02, 9.01
- 2011-03-15 0000950123-11-025580 — 5.02
- 2011-03-14 0000950123-11-025205 — 1.01, 3.02, 9.01
- 2011-02-01 0001299933-11-000333 — 2.02, 9.01
- 2010-11-12 0000950123-10-104604 — 8.01, 9.01
- 2010-11-08 0000950123-10-102424 — 8.01, 9.01
- 2010-11-02 0001299933-10-003878 — 2.02, 9.01
- 2010-09-15 0000950123-10-086373 — 1.01, 9.01 — amendment, the index does not say of what
- 2010-08-06 0000950123-10-074362 — 5.07
- 2010-07-29 0001299933-10-002860 — 2.02, 9.01
- 2010-05-17 0000950123-10-050424 — 1.01, 9.01
- 2010-05-14 0001299933-10-001972 — 5.02
- 2010-05-13 0001299933-10-001943 — 2.02, 9.01
- 2010-02-08 0001299933-10-000506 — 8.01
- 2010-02-02 0001299933-10-000386 — 2.02, 9.01
- 2009-12-15 0001299933-09-004928 — 5.02
- 2009-10-29 0001299933-09-004267 — 2.02, 9.01
- 2009-08-12 0001193125-09-173026 — 5.02, 9.01
- 2009-07-30 0001193125-09-158842 — 1.01, 2.02, 9.01
- 2009-05-15 0001193125-09-113158 — 5.02
- 2009-05-14 0001193125-09-110619 — 2.02, 9.01
- 2009-04-20 0001193125-09-082590 — 5.02
- 2009-02-03 0001193125-09-016992 — 2.02, 9.01
- 2009-01-22 0001193125-09-009777 — 2.02, 9.01
- 2008-11-04 0001193125-08-223730 — 2.02, 9.01
- 2008-08-11 0001193125-08-173616 — 8.01
- 2008-08-07 0001193125-08-170325 — 8.01
- 2008-08-05 0001193125-08-165888 — 2.02, 9.01
- 2008-06-11 0001193125-08-132049 — 1.01, 9.01
- 2008-05-20 0001193125-08-119372 — 5.02, 9.01
- 2008-05-08 0001193125-08-107052 — 2.02, 9.01
- 2008-01-31 0001193125-08-016233 — 2.02, 9.01
- 2008-01-30 0001193125-08-015494 — 5.03, 9.01
- 2007-11-01 0001193125-07-231866 — 2.02, 9.01
- 2007-10-31 0001193125-07-231225 — 2.05
- 2007-10-29 0001193125-07-228284 — 5.03, 9.01
- 2007-09-27 0001193125-07-208950 — 5.02
- 2007-08-09 0001193125-07-176553 — 2.02, 9.01
- 2007-08-07 0001193125-07-173829 — 1.01, 5.02, 9.01
- 2007-07-02 0001193125-07-148303 — 5.02, 9.01
- 2007-06-20 0001193125-07-139068 — 8.01, 9.01
- 2007-06-14 0001193125-07-135550 — 9.01 — amendment of 0001193125-07-005297
- 2007-06-14 0001193125-07-135340 — 5.02
- 2007-05-24 0001193125-07-122148 — 2.02, 9.01
- 2007-03-30 0001193125-07-070154 — 2.05, 9.01
- 2007-03-23 0001193125-07-062978 — 9.01 — amendment of 0001193125-07-005297
- 2007-02-01 0001193125-07-017883 — 2.02, 9.01
- 2007-01-11 0001193125-07-005297 — 2.01, 9.01
- 2006-12-05 0001181431-06-067500 — 5.02
- 2006-11-29 0001193125-06-243360 — 1.01, 3.02, 9.01
- 2006-11-02 0001193125-06-221464 — 2.02, 9.01
- 2006-09-21 0001193125-06-194526 — 5.02
- 2006-08-08 0001193125-06-164819 — 2.02, 9.01
- 2006-08-02 0001193125-06-159113 — 1.01, 9.01
- 2006-07-28 0001193125-06-156172 — 1.01
- 2006-06-26 0001193125-06-135913 — 1.01, 3.03, 9.01
- 2006-05-11 0001193125-06-108489 — 2.02, 9.01
- 2006-05-05 0001193125-06-102270 — 1.01, 9.01
- 2006-05-01 0001193125-06-094941 — 2.02, 2.06, 9.01
- 2006-02-24 0001193125-06-038281 — 5.02, 9.01
- 2006-02-02 0001181431-06-007665 — 2.02, 9.01
- 2005-11-09 0001181431-05-060304 — 2.02, 9.01
- 2005-08-04 0001181431-05-044420 — 2.02, 9.01
- 2005-07-28 0001193125-05-151272 — 5.02, 9.01
- 2005-06-14 0001193125-05-125148 — 5.02, 9.01
- 2005-05-12 0001181431-05-027410 — 2.02, 9.01
- 2005-05-10 0001193125-05-102795 — 1.01
- 2005-04-05 0001181431-05-020680 — 1.01, 2.02, 3.02, 9.01
- 2005-02-03 0001181431-05-006678 — 2.02, 9.01
- 2004-11-09 0001181431-04-051381 — 2.02, 9.01 — amendment, the index does not say of what
- 2004-11-04 0001181431-04-050706 — 2.02, 9.01
- 2004-10-15 0001193125-04-172458 — 1.01, 9.01
- 2004-08-05 0001193125-04-132162 — 12
- 2004-05-13 0001193125-04-086853 — 12
- 2004-02-05 0001193125-04-015060 — 12
- 2003-11-06 0001193125-03-074000 — 12
- 2003-09-26 0001193125-03-054624 — 5
- 2003-08-06 0001193125-03-029666 — 12
- 2003-05-14 0000927016-03-002619 — 9
- 2002-12-31 0000927016-02-006114 — 5
- 2000-01-24 0000927016-00-000150 — 5, 7
- 1998-11-02 0000950135-98-005625 — 5, 7
- 1998-03-24 0000950135-98-001743 — 5, 7
- 1997-09-05 0000950135-97-003729 — 5, 7
- 1997-06-23 0000950135-97-002785 — 1 — amendment of 0000950135-97-001972
- 1997-04-23 0000950135-97-001972 — 2, 7

## late-filing notifications on or before 2023-02-01

- 2011-08-10 0000950123-11-075677 — NT 10-Q, for the period ended 2011-06-30
- 2011-05-31 0000950123-11-055465 — NT 10-K, for the period ended 2011-03-31

## item 2.02 — earnings release, exhibit 99.1

[0001437749-23-002268:8k_2_02:1]
EX-99.1
2
ex_446744.htm
EXHIBIT 99.1

[0001437749-23-002268:8k_2_02:2]
ex_446744.htm

[0001437749-23-002268:8k_2_02:3]
Exhibit 99.1

[0001437749-23-002268:8k_2_02:4]
AMSC Reports Third Quarter Fiscal Year 2022 Financial Results and Provides Business Outlook

[0001437749-23-002268:8k_2_02:5]
|  | ● | Expected cost savings of approximately $5 million annually from recent action to improve future operating leverage |
|  | ● | Reg system milestone achieved, expected release of $5 million restricted cash performance bond in fourth quarter of fiscal year 2022 |
|  | ● | Company to host conference call tomorrow, February 2 at 10:00 am ET |

[0001437749-23-002268:8k_2_02:6]
Ayer, MA – February 1, 2023 – AMSC (Nasdaq: AMSC), a leading system provider of megawatt-scale power resiliency solutions that orchestrate the rhythm and harmony of power on the grid™ and protect and expand the capability and resiliency of our Navy’s fleet, today reported financial results for its third quarter of fiscal year 2022 ended December 31, 2022.

[0001437749-23-002268:8k_2_02:7]
Revenues for the third quarter of fiscal 2022 were $23.9 million compared with $26.8 million for the same period of fiscal 2021. The year-over-year decrease was driven by lower Grid segment revenues, versus the year ago period.

[0001437749-23-002268:8k_2_02:8]
AMSC’s net loss for the third quarter of fiscal 2022 was $9.6 million, or $0.34 per share, compared to a net loss of $4.3 million, or $0.16 per share, for the same period of fiscal 2021.  The Company’s non-GAAP net loss for the third quarter of fiscal 2022 was $7.7 million, or $0.27 per share, compared with a non-GAAP net loss of $4.6 million, or $0.17 per share, in the same period of fiscal 2021. Please refer to the financial table below for a reconciliation of GAAP to non-GAAP results.

[0001437749-23-002268:8k_2_02:9]
Cash, cash equivalents, and restricted cash on December 31, 2022, totaled $31.4 million, compared with $49.5 million at March 31, 2022.

[0001437749-23-002268:8k_2_02:10]
“During our third quarter of fiscal year 2022, we achieved progress on our strategic priority of a more diversified business. We believe we are well positioned to not only take advantage in the renewables, but also in semiconductor, mining and materials, and defense markets,” said Daniel P. McGahn, Chairman, President and CEO, AMSC. “We booked $43 million of total orders, including $26 million of new energy power systems orders. We secured our fifth ship protection system for the amphibious ship platform LPD-32 and ended our third quarter with a backlog of over $110 million. Our pipeline of prospective orders, driven mainly by macro-trends such as climate and environmental policies, is diversified and expected to position us for future growth."

[0001437749-23-002268:8k_2_02:11]
| AMSC Reports Q3 FY22 Results | Page 2 |

[0001437749-23-002268:8k_2_02:12]
Business Outlook

[0001437749-23-002268:8k_2_02:13]
For the fourth quarter ending March 31, 2023, AMSC expects that its revenues will be in the range of $27 million to $30 million. The Company’s net loss for the fourth quarter of fiscal 2022 is expected not to exceed $8.0 million, or $0.28 per share. The Company’s net loss guidance assumes no changes in contingent consideration and does not contemplate any severance related expenses associated with cost reduction actions highlighted above. The Company's non-GAAP net loss (as defined below) is expected not to exceed $6.0 million, or $0.21 per share.  The Company expects operating cash flow to be a burn of $4.0 million to $6.0 million in the fourth quarter of fiscal 2022. The Company expects cash, cash equivalents, and restricted cash on March 31, 2023, to be greater than $25 million.

[0001437749-23-002268:8k_2_02:14]
Conference Call Reminder

[0001437749-23-002268:8k_2_02:15]
In conjunction with this announcement, AMSC management will participate in a conference call with investors beginning at 10:00 a.m. Eastern Time on Thursday, February 2, 2023, to discuss the Company’s financial results and business outlook. Those who wish to listen to the live or archived conference call webcast should visit the “Investors” section of the Company’s website at https://ir.amsc.com. The live call can be accessed by dialing 1-844-481-2802 or 1-412-317- 0675 and asking to join the AMSC call. A replay of the call may be accessed 2 hours following the call by dialing 1-877-344-7529 and using conference passcode 5492389.

[0001437749-23-002268:8k_2_02:16]
About AMSC (Nasdaq: AMSC)

[0001437749-23-002268:8k_2_02:17]
AMSC generates the ideas, technologies and solutions that meet the world’s demand for smarter, cleaner … better energy™. Through its Gridtec™ Solutions, AMSC provides the engineering planning services and advanced grid systems that optimize network reliability, efficiency and performance.  Through its Marinetec™ Solutions, AMSC provides ship protection systems and is developing propulsion and power management solutions designed to help fleets increase system efficiencies, enhance power quality and boost operational safety.  Through its Windtec® Solutions, AMSC provides wind turbine electronic controls and systems, designs and engineering services that reduce the cost of wind energy. The Company’s solutions are enhancing the performance and reliability of power networks, increasing the operational safety of navy fleets, and powering gigawatts of renewable energy globally. Founded in 1987, AMSC is headquartered near Boston, Massachusetts with operations in Asia, Australia, Europe and North America. For more information, please visit www.amsc.com.

[0001437749-23-002268:8k_2_02:18]
AMSC, American Superconductor, D-VAR, D-VAR VVO, Gridtec, Marinetec, Windtec, Neeltran, NEPSI, Smarter, Cleaner … Better Energy, and Orchestrate the Rhythm and Harmony of Power on the Grid are trademarks or registered trademarks of American Superconductor Corporation. All other brand names, product names, trademarks or service marks belong to their respective holders.

[0001437749-23-002268:8k_2_02:19]
| AMSC Reports Q3 FY22 Results | Page 3 |

[0001437749-23-002268:8k_2_02:20]
Forward-Looking Statements

[0001437749-23-002268:8k_2_02:21]
| AMSC Reports Q3 FY22 Results | Page 4 |

[0001437749-23-002268:8k_2_02:22]
UNAUDITED CONSOLIDATED STATEMENTS OF OPERATIONS

[0001437749-23-002268:8k_2_02:23]
(In thousands, except per share data)

[0001437749-23-002268:8k_2_02:24]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | December 31, |  |  | December 31, |  |
|  |  | 2022 |  |  | 2021 |  |  | 2022 |  |  | 2021 |  |
| Revenues |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Grid |  | $ | 20,809 |  |  | $ | 25,050 |  |  | $ | 66,337 |  |  | $ | 73,169 |  |
| Wind |  |  | 3,072 |  |  |  | 1,749 |  |  |  | 7,904 |  |  |  | 6,957 |  |
| Total revenues |  |  | 23,881 |  |  |  | 26,799 |  |  |  | 74,241 |  |  |  | 80,126 |  |
| Cost of revenues |  |  | 23,364 |  |  |  | 23,227 |  |  |  | 69,533 |  |  |  | 69,925 |  |
| Gross margin |  |  | 517 |  |  |  | 3,572 |  |  |  | 4,708 |  |  |  | 10,201 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Research and development |  |  | 2,083 |  |  |  | 2,657 |  |  |  | 7,076 |  |  |  | 8,368 |  |
| Selling, general and administrative |  |  | 7,173 |  |  |  | 6,777 |  |  |  | 22,084 |  |  |  | 20,615 |  |
| Amortization of acquisition-related intangibles |  |  | 690 |  |  |  | 628 |  |  |  | 2,058 |  |  |  | 1,840 |  |
| Change in fair value of contingent consideration |  |  | (220 | ) |  |  | (2,110 | ) |  |  | (340 | ) |  |  | (4,440 | ) |
| Total operating expenses |  |  | 9,726 |  |  |  | 7,952 |  |  |  | 30,878 |  |  |  | 26,383 |  |
| Operating loss |  |  | (9,209 | ) |  |  | (4,380 | ) |  |  | (26,170 | ) |  |  | (16,182 | ) |
| Interest income, net |  |  | 42 |  |  |  | 12 |  |  |  | 112 |  |  |  | 68 |  |
| China dissolution |  |  | - |  |  |  | - |  |  |  | (1,921 | ) |  |  | - |  |
| Other income (expense), net |  |  | (287 | ) |  |  | 45 |  |  |  | (48 | ) |  |  | 7 |  |
| Loss before income tax expense |  |  | (9,454 | ) |  |  | (4,323 | ) |  |  | (28,027 | ) |  |  | (16,107 | ) |
| Income tax expense (benefit) |  |  | 127 |  |  |  | 1 |  |  |  | 144 |  |  |  | (1,946 | ) |
| Net loss |  | $ | (9,581 | ) |  | $ | (4,324 | ) |  | $ | (28,171 | ) |  | $ | (14,161 | ) |
| Net loss per common share |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | (0.34 | ) |  | $ | (0.16 | ) |  | $ | (1.01 | ) |  | $ | (0.52 | ) |
| Diluted |  | $ | (0.34 | ) |  | $ | (0.16 | ) |  | $ | (1.01 | ) |  | $ | (0.52 | ) |
| Weighted average number of common shares outstanding |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  |  | 27,954 |  |  |  | 27,352 |  |  |  | 27,794 |  |  |  | 27,145 |  |
| Diluted |  |  | 27,954 |  |  |  | 27,352 |  |  |  | 27,794 |  |  |  | 27,145 |  |

[0001437749-23-002268:8k_2_02:25]
| AMSC Reports Q3 FY22 Results | Page 5 |

[0001437749-23-002268:8k_2_02:26]
UNAUDITED CONSOLIDATED BALANCE SHEET

[0001437749-23-002268:8k_2_02:27]
(In thousands, except per share data)

[0001437749-23-002268:8k_2_02:28]
|  |  | December 31, 2022 |  |  | March 31, 2022 |  |
| ASSETS |  |  |  |  |  |  |  |  |
| Current assets: |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 23,685 |  |  | $ | 40,584 |  |
| Accounts receivable, net |  |  | 17,568 |  |  |  | 20,280 |  |
| Inventory, net |  |  | 38,725 |  |  |  | 23,666 |  |
| Prepaid expenses and other current assets |  |  | 7,544 |  |  |  | 7,052 |  |
| Restricted cash |  |  | 6,643 |  |  |  | 2,754 |  |
| Total current assets |  |  | 94,165 |  |  |  | 94,336 |  |
| Property, plant and equipment, net |  |  | 12,611 |  |  |  | 13,656 |  |
| Intangibles, net |  |  | 9,215 |  |  |  | 11,311 |  |
| Right-of-use assets |  |  | 3,068 |  |  |  | 3,502 |  |
| Goodwill |  |  | 43,471 |  |  |  | 43,471 |  |
| Restricted cash |  |  | 1,023 |  |  |  | 6,148 |  |
| Deferred tax assets |  |  | 1,086 |  |  |  | 1,224 |  |
| Other assets |  |  | 433 |  |  |  | 239 |  |
| Total assets |  | $ | 165,072 |  |  | $ | 173,887 |  |
| LIABILITIES AND STOCKHOLDERS' EQUITY |  |  |  |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |  |  |  |
| Accounts payable and accrued expenses |  | $ | 32,060 |  |  | $ | 29,140 |  |
| Lease liability, current portion |  |  | 822 |  |  |  | 740 |  |
| Debt, current portion |  |  | 72 |  |  |  | 72 |  |
| Contingent consideration |  |  | 860 |  |  |  | 1,200 |  |
| Deferred revenue, current portion |  |  | 34,239 |  |  |  | 22,812 |  |
| Total current liabilities |  |  | 68,053 |  |  |  | 53,964 |  |
| Deferred revenue, long term portion |  |  | 7,176 |  |  |  | 7,222 |  |
| Lease liability, long term portion |  |  | 2,375 |  |  |  | 2,900 |  |
| Deferred tax liabilities |  |  | 202 |  |  |  | 297 |  |
| Debt, long-term portion |  |  | 35 |  |  |  | 90 |  |
| Other liabilities |  |  | 24 |  |  |  | 25 |  |
| Total liabilities |  |  | 77,865 |  |  |  | 64,498 |  |
| Stockholders' equity: |  |  |  |  |  |  |  |  |
| Common stock |  |  | 299 |  |  |  | 289 |  |
| Additional paid-in capital |  |  | 1,137,622 |  |  |  | 1,133,536 |  |
| Treasury stock |  |  | (3,639 | ) |  |  | (3,639 | ) |
| Accumulated other comprehensive gain (loss) |  |  | 1,603 |  |  |  | (291 | ) |
| Accumulated deficit |  |  | (1,048,678 | ) |  |  | (1,020,506 | ) |
| Total stockholders' equity |  |  | 87,207 |  |  |  | 109,389 |  |
| Total liabilities and stockholders' equity |  | $ | 165,072 |  |  | $ | 173,887 |  |

[0001437749-23-002268:8k_2_02:29]
| AMSC Reports Q3 FY22 Results | Page 6 |

[0001437749-23-002268:8k_2_02:30]
UNAUDITED CONSOLIDATED STATEMENTS OF CASH FLOWS

[0001437749-23-002268:8k_2_02:31]
(In thousands)

[0001437749-23-002268:8k_2_02:32]
|  |  | Nine Months Ended December 31, |  |
|  |  | 2022 |  |  | 2021 |  |
| Cash flows from operating activities: |  |  |  |  |  |  |  |  |
| Net loss |  | $ | (28,171 | ) |  | $ | (14,161 | ) |
| Adjustments to reconcile net loss to net cash used in operations: |  |  |  |  |  |  |  |  |
| Depreciation and amortization |  |  | 4,104 |  |  |  | 4,009 |  |
| Stock-based compensation expense |  |  | 3,492 |  |  |  | 3,513 |  |
| Provision for excess and obsolete inventory |  |  | 1,247 |  |  |  | 1,627 |  |
| Deferred income taxes |  |  | 65 |  |  |  | (2,136 | ) |
| Change in fair value of contingent consideration |  |  | (340 | ) |  |  | (4,440 | ) |
| China dissolution |  |  | 1,921 |  |  |  | - |  |
| Non-cash interest income |  |  | - |  |  |  | (49 | ) |
| Other non-cash items |  |  | 185 |  |  |  | 407 |  |
| Unrealized foreign exchange loss on cash and cash equivalents |  |  | (3 | ) |  |  | (118 | ) |
| Changes in operating asset and liability accounts: |  |  |  |  |  |  |  |  |
| Accounts receivable |  |  | 2,738 |  |  |  | (4,528 | ) |
| Inventory |  |  | (16,324 | ) |  |  | (279 | ) |
| Prepaid expenses and other assets |  |  | (165 | ) |  |  | 85 |  |
| Accounts payable and accrued expenses |  |  | 2,565 |  |  |  | (236 | ) |
| Deferred revenue |  |  | 11,619 |  |  |  | 381 |  |
| Net cash used in operating activities |  |  | (17,067 | ) |  |  | (15,925 | ) |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |
| Purchase of property, plant and equipment |  |  | (970 | ) |  |  | (710 | ) |
| Cash paid for acquisition, net of cash acquired |  |  | - |  |  |  | (11,479 | ) |
| Proceeds from the maturity of marketable securities |  |  | - |  |  |  | 5,189 |  |
| Change in other assets |  |  | (194 | ) |  |  | (56 | ) |
| Net cash used in investing activities |  |  | (1,164 | ) |  |  | (7,056 | ) |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |
| Repurchase of treasury stock |  |  | - |  |  |  | (46 | ) |
| Repayment of debt |  |  | (56 | ) |  |  | (30 | ) |
| Proceeds from exercise of employee stock options and ESPP |  |  | 127 |  |  |  | 125 |  |
| Net cash provided by financing activities |  |  | 71 |  |  |  | 49 |  |
| Effect of exchange rate changes on cash |  |  | 25 |  |  |  | (51 | ) |
| Net decrease in cash, cash equivalents and restricted cash |  |  | (18,135 | ) |  |  | (22,983 | ) |
| Cash, cash equivalents and restricted cash at beginning of period |  |  | 49,486 |  |  |  | 75,539 |  |
| Cash, cash equivalents and restricted cash at end of period |  | $ | 31,351 |  |  | $ | 52,556 |  |

[0001437749-23-002268:8k_2_02:33]
| AMSC Reports Q3 FY22 Results | Page 7 |

[0001437749-23-002268:8k_2_02:34]
RECONCILIATION OF GAAP NET LOSS TO NON-GAAP NET LOSS

[0001437749-23-002268:8k_2_02:35]
(In thousands, except per share data)

[0001437749-23-002268:8k_2_02:36]
|  |  | Three Months Ended December 31, |  |  | Nine Months Ended December 31, |  |
|  |  | 2022 |  |  | 2021 |  |  | 2022 |  |  | 2021 |  |
| Net loss |  | $ | (9,581 | ) |  | $ | (4,324 | ) |  | $ | (28,171 | ) |  | $ | (14,161 | ) |
| China dissolution |  |  | — |  |  |  | — |  |  |  | 1,921 |  |  |  | — |  |
| Stock-based compensation |  |  | 1,440 |  |  |  | 1,120 |  |  |  | 3,492 |  |  |  | 3,513 |  |
| Amortization of acquisition-related intangibles |  |  | 696 |  |  |  | 690 |  |  |  | 2,096 |  |  |  | 1,979 |  |
| Acquisition costs |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 681 |  |
| Change in fair value of contingent consideration |  |  | (220 | ) |  |  | (2,110 | ) |  |  | (340 | ) |  |  | (4,440 | ) |
| Non-GAAP net loss |  | $ | (7,665 | ) |  | $ | (4,624 | ) |  | $ | (21,002 | ) |  | $ | (12,428 | ) |
| Non-GAAP net loss per share - basic |  | $ | (0.27 | ) |  | $ | (0.17 | ) |  | $ | (0.76 | ) |  | $ | (0.46 | ) |
| Weighted average shares outstanding - basic |  |  | 27,954 |  |  |  | 27,352 |  |  |  | 27,794 |  |  |  | 27,145 |  |

[0001437749-23-002268:8k_2_02:37]
Reconciliation of Forecast GAAP Net Loss to Non-GAAP Net Loss

[0001437749-23-002268:8k_2_02:38]
(In millions, except per share data)

[0001437749-23-002268:8k_2_02:39]
|  |  | Three months ending |  |
|  |  | March 31, 2023 |  |
| Net loss |  | $ | (8.0) |  |
| Stock-based compensation |  |  | 1.3 |  |
| Amortization of acquisition-related intangibles |  |  | 0.7 |  |
| Non-GAAP net loss |  | $ | (6.0) |  |
| Non-GAAP net loss per share |  | $ | (0.21 | ) |
| Shares outstanding |  |  | 28.2 |  |

[0001437749-23-002268:8k_2_02:40]
| AMSC Reports Q3 FY22 Results | Page 8 |

[0001437749-23-002268:8k_2_02:41]
Note: Non-GAAP net loss is defined by the Company as net loss before: China dissolution; stock-based compensation; amortization of acquisition-related intangibles; acquisition costs; change in fair value of contingent consideration; other non-cash or unusual charges, and the tax effect of adjustments calculated at the relevant rate for our non-GAAP metric. The Company believes non-GAAP net loss assists management and investors in comparing the Company’s performance across reporting periods on a consistent basis by excluding these non-cash, non-recurring or other charges that it does not believe are indicative of its core operating performance. Actual GAAP and non-GAAP net loss for the fiscal quarter ending March 31, 2023, including the above adjustments, may differ materially from those forecasted in the table above, including as a result of the inclusion of the change in fair value of contingent consideration.

[0001437749-23-002268:8k_2_02:42]
Generally, a non-GAAP financial measure is a numerical measure of a company's performance, financial position or cash flow that either excludes or includes amounts that are not normally excluded or included in the most directly comparable measure calculated and presented in accordance with GAAP. The non-GAAP measure included in this release, however, should be considered in addition to, and not as a substitute for or superior to, operating income or other measures of financial performance prepared in accordance with GAAP. A reconciliation of GAAP to non-GAAP net loss is set forth in the table above.

[0001437749-23-002268:8k_2_02:43]
AMSC Contacts

[0001437749-23-002268:8k_2_02:44]
Investor Relations Contact:

[0001437749-23-002268:8k_2_02:45]
LHA Investor Relations

[0001437749-23-002268:8k_2_02:46]
Carolyn Capaccio

[0001437749-23-002268:8k_2_02:47]
(212) 838-3777

[0001437749-23-002268:8k_2_02:48]
amscIR@lhai.com

[0001437749-23-002268:8k_2_02:49]
Public Relations Contact:

[0001437749-23-002268:8k_2_02:50]
RooneyPartners LLC

[0001437749-23-002268:8k_2_02:51]
Joe Luongo

[0001437749-23-002268:8k_2_02:52]
(914) 906-5903

[0001437749-23-002268:8k_2_02:53]
jluongo@rooneyco.com

[0001437749-23-002268:8k_2_02:54]
AMSC Communications Manager:

[0001437749-23-002268:8k_2_02:55]
Nicol Golez

[0001437749-23-002268:8k_2_02:56]
978-399-8344

[0001437749-23-002268:8k_2_02:57]
Nicol.Golez@amsc.com
