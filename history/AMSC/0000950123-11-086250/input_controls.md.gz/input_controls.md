# AMSC 10-Q controls and the auditor's report


## item_4_controls

[0000950123-11-086250:item_4_controls:1]
| ITEM 4. |  | CONTROLS AND PROCEDURES |

[0000950123-11-086250:item_4_controls:2]
Overview

[0000950123-11-086250:item_4_controls:3]
Our management previously identified material weaknesses in internal control over financial
reporting related to revenues and accounts receivable balances as fees were not fixed or
determinable or collectability was not reasonably assured at the time revenue was recognized, which
is described in our Annual Report on Form 10-K for the year ended March 31, 2011. During fiscal
2011 through the date of this filing, management has been focused on remediating these material
weaknesses. The remediation process is ongoing but it is not yet complete. There was no change in
internal control over financial reporting during the quarter ended June 30, 2011 that has
materially affected, or is reasonably likely to materially affect, our internal control over
financial reporting. The following discussion sets forth a summary of management’s evaluation of
our disclosure controls and procedures as of June 30, 2011.

[0000950123-11-086250:item_4_controls:4]
Evaluation of Disclosure Controls and Procedures

[0000950123-11-086250:item_4_controls:5]
Our management, with the participation of our Chief Executive Officer and Chief Financial
Officer, evaluated the effectiveness of our disclosure controls and procedures as of June 30, 2011.
The term “disclosure controls and procedures,” as defined in Rules 13a-15(e) and 15d-15(e) under
the Exchange Act, means controls and other procedures of a company that are designed to ensure that
information required to be disclosed by a company in the reports that it files or submits under the
Exchange Act is recorded, processed, summarized and reported within the time periods specified in
the SEC’s rules and forms. Disclosure controls and procedures include, without limitation, controls
and procedures designed to ensure that information required to be disclosed by a company in the
reports that it files or submits under the Exchange Act is accumulated and communicated to the
company’s management, including its principal executive and principal financial officers, as
appropriate to allow timely decisions regarding required disclosure. Management recognizes that any
controls and procedures, no matter how well designed and operated, can provide only reasonable
assurance of achieving their objectives and management necessarily applies its judgment in
evaluating the cost-benefit relationship of possible controls and procedures. Based on that
evaluation, our Chief Executive Officer and Chief Financial Officer have concluded that our
disclosure controls and procedures were not effective as of June 30, 2011 because of the previously
identified material weaknesses in internal control over financial reporting discussed below.

[0000950123-11-086250:item_4_controls:6]
Notwithstanding the material weaknesses described below, management believes that the
unaudited condensed consolidated financial statements included in this Quarterly Report on Form
10-Q fairly present, in all material respects, our financial condition, results of operations and
cash flows for the periods presented in conformity with accounting principles generally accepted in
the United States (“GAAP”).

[0000950123-11-086250:item_4_controls:7]
This section of Item 4, “Controls and Procedures,” should be read in conjunction with Item 9A.
“Controls and Procedures,” included in our Annual Report on Form 10-K for the fiscal year ended
March 31, 2011.

[0000950123-11-086250:item_4_controls:8]
Material Weaknesses

[0000950123-11-086250:item_4_controls:9]
As of June 30, 2011, the unremediated material weaknesses were as follows:

[0000950123-11-086250:item_4_controls:10]
|  | • |  | we did not maintain adequately designed controls to ensure accurate recognition of revenue in accordance with GAAP. Specifically, controls were not effective to ensure that deviations from contractually established payment terms were identified, communicated and authorized; |

[0000950123-11-086250:item_4_controls:11]
|  | • |  | we did not maintain adequate controls to ensure proper monitoring and evaluation of customer creditworthiness, including the collectability of amounts due from customers and appropriate revenue recognition; |

[0000950123-11-086250:item_4_controls:12]
|  | • |  | we did not maintain a sufficient complement of personnel involved with business in our foreign locations with the appropriate level of knowledge, experience and training in the application of GAAP to ensure revenue transactions were appropriately reflected in the financial statements based on the terms and conditions of the sales contracts; and |

[0000950123-11-086250:item_4_controls:13]
|  | • |  | we did not establish and maintain, procedures to ensure proper oversight and review, by senior management, of customer relationships to ensure appropriate communication of relevant considerations to determine accounting judgments with respect to revenue recognition. |

[0000950123-11-086250:item_4_controls:14]
34

[0000950123-11-086250:item_4_controls:15]
Remediation of Material Weaknesses

[0000950123-11-086250:item_4_controls:16]
|  |  | We are in the process of remediating the above material weaknesses through the following initiatives: |

[0000950123-11-086250:item_4_controls:17]
|  | • |  | establishing formal, written policies and procedures governing the customer credit process; |

[0000950123-11-086250:item_4_controls:18]
|  | • |  | improving procedures to ensure the proper review and documentation of customer creditworthiness; |

[0000950123-11-086250:item_4_controls:19]
|  | • |  | establishing a new worldwide revenue manager position in finance with GAAP experience to ensure accuracy of revenue recognition; |

[0000950123-11-086250:item_4_controls:20]
|  | • |  | improving procedures to ensure the proper communication, approval and accounting review of deviations from sales contracts; |

[0000950123-11-086250:item_4_controls:21]
|  | • |  | providing additional and on-going training to product managers and others involved in negotiating contractual arrangements and accounting for revenue transactions, in order to heighten awareness of revenue recognition concepts under GAAP; and |

[0000950123-11-086250:item_4_controls:22]
|  | • |  | improving the internal communication process for senior management. During monthly operations reviews time will be devoted to senior management review of pending operational and accounting issues for the current quarter. |

[0000950123-11-086250:item_4_controls:23]
Management is committed to a strong internal control environment and believes that, when fully
implemented and tested, the measures described above will improve our internal control over
financial reporting. We will continue to assess the effectiveness of our remediation efforts in
connection with our future assessments of the effectiveness of internal control over financial
reporting.

[0000950123-11-086250:item_4_controls:24]
Changes in Internal Control over Financial Reporting

[0000950123-11-086250:item_4_controls:25]
Except as discussed above, there were no changes in our internal control over financial
reporting during the quarter ended June 30, 2011 that have materially affected, or are reasonably
likely to materially affect, our internal control over financial reporting.

[0000950123-11-086250:item_4_controls:26]
35
