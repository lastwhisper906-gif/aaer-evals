# AMSC 8-K — 0000950123-11-086288 filed 2011-09-23

## item codes, every 8-K on or before 2011-09-23

- 2011-09-23 0000950123-11-086288 — 2.02, 9.01
- 2011-09-15 0000950123-11-084585 — 7.01
- 2011-09-06 0000950123-11-082736 — 7.01
- 2011-08-18 0000950123-11-078526 — 3.01, 7.01, 9.01
- 2011-08-11 0000950123-11-075905 — 5.02
- 2011-08-11 0000950123-11-075904 — 2.02, 2.05, 9.01
- 2011-07-11 0000950123-11-064934 — 2.02, 4.02, 9.01
- 2011-06-30 0000950123-11-063287 — 1.01, 3.02, 9.01
- 2011-06-21 0000950123-11-060491 — 3.01, 7.01, 9.01
- 2011-06-13 0000950123-11-058656 — 1.01, 9.01
- 2011-05-24 0000950123-11-053517 — 5.02, 9.01
- 2011-04-05 0001299933-11-001020 — 2.02, 9.01
- 2011-03-15 0000950123-11-025580 — 5.02
- 2011-03-14 0000950123-11-025205 — 1.01, 3.02, 9.01
- 2011-02-01 0001299933-11-000333 — 2.02, 9.01
- 2010-11-12 0000950123-10-104604 — 8.01, 9.01
- 2010-11-08 0000950123-10-102424 — 8.01, 9.01
- 2010-11-02 0001299933-10-003878 — 2.02, 9.01
- 2010-09-15 0000950123-10-086373 — 1.01, 9.01 — amendment, the index does not say of what
- 2010-08-06 0000950123-10-074362 — 5.07
- 2010-07-29 0001299933-10-002860 — 2.02, 9.01
- 2010-05-17 0000950123-10-050424 — 1.01, 9.01
- 2010-05-14 0001299933-10-001972 — 5.02
- 2010-05-13 0001299933-10-001943 — 2.02, 9.01
- 2010-02-08 0001299933-10-000506 — 8.01
- 2010-02-02 0001299933-10-000386 — 2.02, 9.01
- 2009-12-15 0001299933-09-004928 — 5.02
- 2009-10-29 0001299933-09-004267 — 2.02, 9.01
- 2009-08-12 0001193125-09-173026 — 5.02, 9.01
- 2009-07-30 0001193125-09-158842 — 1.01, 2.02, 9.01
- 2009-05-15 0001193125-09-113158 — 5.02
- 2009-05-14 0001193125-09-110619 — 2.02, 9.01
- 2009-04-20 0001193125-09-082590 — 5.02
- 2009-02-03 0001193125-09-016992 — 2.02, 9.01
- 2009-01-22 0001193125-09-009777 — 2.02, 9.01
- 2008-11-04 0001193125-08-223730 — 2.02, 9.01
- 2008-08-11 0001193125-08-173616 — 8.01
- 2008-08-07 0001193125-08-170325 — 8.01
- 2008-08-05 0001193125-08-165888 — 2.02, 9.01
- 2008-06-11 0001193125-08-132049 — 1.01, 9.01
- 2008-05-20 0001193125-08-119372 — 5.02, 9.01
- 2008-05-08 0001193125-08-107052 — 2.02, 9.01
- 2008-01-31 0001193125-08-016233 — 2.02, 9.01
- 2008-01-30 0001193125-08-015494 — 5.03, 9.01
- 2007-11-01 0001193125-07-231866 — 2.02, 9.01
- 2007-10-31 0001193125-07-231225 — 2.05
- 2007-10-29 0001193125-07-228284 — 5.03, 9.01
- 2007-09-27 0001193125-07-208950 — 5.02
- 2007-08-09 0001193125-07-176553 — 2.02, 9.01
- 2007-08-07 0001193125-07-173829 — 1.01, 5.02, 9.01
- 2007-07-02 0001193125-07-148303 — 5.02, 9.01
- 2007-06-20 0001193125-07-139068 — 8.01, 9.01
- 2007-06-14 0001193125-07-135550 — 9.01 — amendment of 0001193125-07-005297
- 2007-06-14 0001193125-07-135340 — 5.02
- 2007-05-24 0001193125-07-122148 — 2.02, 9.01
- 2007-03-30 0001193125-07-070154 — 2.05, 9.01
- 2007-03-23 0001193125-07-062978 — 9.01 — amendment of 0001193125-07-005297
- 2007-02-01 0001193125-07-017883 — 2.02, 9.01
- 2007-01-11 0001193125-07-005297 — 2.01, 9.01
- 2006-12-05 0001181431-06-067500 — 5.02
- 2006-11-29 0001193125-06-243360 — 1.01, 3.02, 9.01
- 2006-11-02 0001193125-06-221464 — 2.02, 9.01
- 2006-09-21 0001193125-06-194526 — 5.02
- 2006-08-08 0001193125-06-164819 — 2.02, 9.01
- 2006-08-02 0001193125-06-159113 — 1.01, 9.01
- 2006-07-28 0001193125-06-156172 — 1.01
- 2006-06-26 0001193125-06-135913 — 1.01, 3.03, 9.01
- 2006-05-11 0001193125-06-108489 — 2.02, 9.01
- 2006-05-05 0001193125-06-102270 — 1.01, 9.01
- 2006-05-01 0001193125-06-094941 — 2.02, 2.06, 9.01
- 2006-02-24 0001193125-06-038281 — 5.02, 9.01
- 2006-02-02 0001181431-06-007665 — 2.02, 9.01
- 2005-11-09 0001181431-05-060304 — 2.02, 9.01
- 2005-08-04 0001181431-05-044420 — 2.02, 9.01
- 2005-07-28 0001193125-05-151272 — 5.02, 9.01
- 2005-06-14 0001193125-05-125148 — 5.02, 9.01
- 2005-05-12 0001181431-05-027410 — 2.02, 9.01
- 2005-05-10 0001193125-05-102795 — 1.01
- 2005-04-05 0001181431-05-020680 — 1.01, 2.02, 3.02, 9.01
- 2005-02-03 0001181431-05-006678 — 2.02, 9.01
- 2004-11-09 0001181431-04-051381 — 2.02, 9.01 — amendment, the index does not say of what
- 2004-11-04 0001181431-04-050706 — 2.02, 9.01
- 2004-10-15 0001193125-04-172458 — 1.01, 9.01
- 2004-08-05 0001193125-04-132162 — 12
- 2004-05-13 0001193125-04-086853 — 12
- 2004-02-05 0001193125-04-015060 — 12
- 2003-11-06 0001193125-03-074000 — 12
- 2003-09-26 0001193125-03-054624 — 5
- 2003-08-06 0001193125-03-029666 — 12
- 2003-05-14 0000927016-03-002619 — 9
- 2002-12-31 0000927016-02-006114 — 5
- 2000-01-24 0000927016-00-000150 — 5, 7
- 1998-11-02 0000950135-98-005625 — 5, 7
- 1998-03-24 0000950135-98-001743 — 5, 7
- 1997-09-05 0000950135-97-003729 — 5, 7
- 1997-06-23 0000950135-97-002785 — 1 — amendment of 0000950135-97-001972
- 1997-04-23 0000950135-97-001972 — 2, 7

## late-filing notifications on or before 2011-09-23

- 2011-08-10 0000950123-11-075677 — NT 10-Q, for the period ended 2011-06-30
- 2011-05-31 0000950123-11-055465 — NT 10-K, for the period ended 2011-03-31

## item 2.02 — earnings release, exhibit 99.1

[0000950123-11-086288:8k_2_02:1]
EX-99.1
2
b88337exv99w1.htm
EX-99.1

[0000950123-11-086288:8k_2_02:2]
exv99w1

[0000950123-11-086288:8k_2_02:3]
Exhibit 99.1

[0000950123-11-086288:8k_2_02:4]
|  |  | Press Release |

[0000950123-11-086288:8k_2_02:5]
AMSC REPORTS FULL-YEAR FISCAL 2010 AND

[0000950123-11-086288:8k_2_02:6]
FIRST QUARTER FISCAL 2011 FINANCIAL RESULTS

[0000950123-11-086288:8k_2_02:7]
Company Regains Compliance with SEC Reporting Requirements

[0000950123-11-086288:8k_2_02:8]
DEVENS, Mass., September 23, 2011 — American Superconductor Corporation (NASDAQ: AMSC), a global
power technologies company, today reported financial results for fiscal year 2010 ended March 31,
2011, and the first quarter of fiscal year 2011 ended June 30, 2011. The company’s fiscal 2010
results include previously announced restatements of results for the second and third quarters of
fiscal 2010. The company has filed its Annual Report on Form 10-K for the year ended March 31,
2011 and its Quarterly Report on Form 10-Q for the quarter ended June 30, 2011 with the Securities
and Exchange Commission and, as a result, the company expects to regain compliance with NASDAQ
Listing Rules.

[0000950123-11-086288:8k_2_02:9]
Fiscal 2010 revenues were $286.6 million, which compares with $316.0 million for fiscal 2009. The
company reported a net loss of $186.3 million, or $3.95 per diluted share, for fiscal 2010. Fiscal
2010 revenues include the impact of applying a cash basis of accounting to recognize revenue for
shipments to certain customers in China as of September 1, 2010 and for shipments to Sinovel Wind
Group Co., Ltd. (Sinovel) as of October 1, 2010. The company’s fiscal 2010 net loss includes
$158.5 million in aggregate one-time asset write-downs, impairments and accrued charges recorded
primarily in the fourth quarter of fiscal 2010 associated with the company’s accounting judgment
that its relationship with Sinovel will not continue. This compares with net income of $16.2
million, or $0.36 per diluted share, for fiscal year 2009. The company’s non-GAAP net loss for
fiscal 2010 was $12.8 million, or $0.27 per diluted share. This compares with non-GAAP net income
of $31.7 million, or $0.70 per diluted share, for fiscal 2009. Please refer to the financial table
included below for a reconciliation of GAAP to non-GAAP results.

[0000950123-11-086288:8k_2_02:10]
Revenues for the first quarter of fiscal 2011 were $9.1 million. This compares with $97.2 million
for the first quarter of fiscal 2010. The decline is due primarily to a lack of revenue from
Sinovel. The company reported a net loss for the quarter of $37.7 million, $0.74 per diluted
share. This compares with net income of $9.2 million, or $0.20 per diluted share, for the first
quarter of fiscal 2010. The company’s non-GAAP net loss for the first quarter of fiscal 2011 was
$30.8 million, or $0.61 per diluted share. This compares with non-GAAP net income of $13.0
million, or $0.28 per diluted share, for the first quarter of fiscal 2010. Please refer to the
financial table included below for a reconciliation of GAAP to non-GAAP results.

[0000950123-11-086288:8k_2_02:11]
Net of the advance payment of approximately $20.6 million for the company’s proposed acquisition of
The Switch Engineering Oy, the company’s balance of cash, cash equivalents, marketable securities
and restricted cash on June 30, 2011 was $166.2 million. This compares with $245.5 million on
March 31, 2011 and $120.7 million on June 30, 2010.

[0000950123-11-086288:8k_2_02:12]
“Our financial results for fiscal 2010 and the first quarter of fiscal 2011 are a reflection of our
past,” said AMSC President and Chief Executive Officer Daniel McGahn. “Our efforts to build

[0000950123-11-086288:8k_2_02:13]
a better AMSC are now well underway. We have reduced our cost structure by more than $30 million
annually and realigned our business into market-facing Wind and Grid segments. We
also have won nearly $100 million in new contracts since the start of our fiscal year, which we
believe will help expand our customer base, diversify our revenue streams and return the company to
growth (see separate press release issued today).”

[0000950123-11-086288:8k_2_02:14]
Looking Forward

[0000950123-11-086288:8k_2_02:15]
For the quarter ending September 30, 2011, AMSC currently expects that its revenues will exceed $18
million. Including charges for its litigation against Sinovel and its previously announced
restructuring, among other charges, AMSC expects that its net loss for the second quarter of fiscal
2011 will be less than $38 million, or $0.75 per diluted share. AMSC expects that its non-GAAP net
loss for the second fiscal quarter will be less than $27 million, or $0.53 per diluted share.

[0000950123-11-086288:8k_2_02:16]
Despite the company’s expenses related to severance, litigation against Sinovel and supply-chain
liabilities, AMSC expects to end the second quarter of fiscal year 2011 with more than $100 million
in cash, cash equivalents, marketable securities and restricted cash. Cash usage is expected to
further slow in the second half of the year as savings from the company’s restructuring actions
begin to be realized and as the use of cash for Sinovel-related litigation and supply chain
liabilities decreases.

[0000950123-11-086288:8k_2_02:17]
“We have taken decisive action to immediately lower our expenses, significantly reduce our cash
burn in the second half of the fiscal year and put AMSC back on the path to profitability,” McGahn
said. “We have a holistic set of Wind and Grid solutions that lower the cost of energy and make
our power supplies cleaner, smarter and more reliable, positioning us well within addressable
markets that approach $10 billion annually. We believe we have the right people, products and
partners to capitalize on these opportunities and ultimately deliver sustainable profits.”

[0000950123-11-086288:8k_2_02:18]
Conference Call Reminder

[0000950123-11-086288:8k_2_02:19]
In conjunction with this announcement, AMSC management will participate in a conference call with
investors beginning at 9:00 a.m. Eastern Time to discuss the company’s results and its business
outlook. Those who wish to listen to the live conference call webcast
should visit the “Investors”
section of the company’s website at www.amsc.com/investors. The live call also can be accessed by
dialing 719-457-2703 and using conference ID 8645945. A telephonic playback of the call will be
available from 12:00 p.m. ET on September 23 through 12:00 p.m. ET on September 28. Please call
719-457-0820 and refer to conference ID 8645945 to access the playback.

[0000950123-11-086288:8k_2_02:20]
About American Superconductor (NASDAQ: AMSC)

[0000950123-11-086288:8k_2_02:21]
AMSC offers an array of proprietary technologies and solutions spanning the electric power
infrastructure — from generation to delivery to end use. The company is a leader in renewable
energy, providing proven, megawatt-scale wind turbine designs and electrical control systems.
The company also offers a host of Smart Grid technologies for power grid operators that
enhance the reliability, efficiency and capacity of the grid, and seamlessly integrate renewable
energy

[0000950123-11-086288:8k_2_02:22]
sources into the power infrastructure. These include superconductor power cable systems,
grid-level surge protectors and power electronics-based voltage stabilization systems. AMSC’s
technologies are protected by a broad and deep intellectual property portfolio consisting of
hundreds of patents and licenses worldwide. More information is available at www.amsc.com.

[0000950123-11-086288:8k_2_02:23]
# # #

[0000950123-11-086288:8k_2_02:24]
American Superconductor and design, Revolutionizing the Way the World Uses Electricity, AMSC,
Powered by AMSC, Amperium, D-VAR, dSVC, FaultBlocker, PowerModule, PowerPipelines, PQ-IVR, PQ-SVC,
SeaTitan, SuperGEAR and Windtec and design are trademarks or registered trademarks of American
Superconductor Corporation or its subsidiaries. All other brand names, product names or trademarks
belong to their respective holders.

[0000950123-11-086288:8k_2_02:25]
components and subassemblies of many of our Wind and Grid products, making us vulnerable to supply
shortages and price fluctuations, which could harm our business; we are becoming increasingly
reliant on contracts that require the issuance of performance bonds; problems with product quality
or product performance may cause us to incur warranty expenses and may damage our market reputation
and prevent us from achieving increased sales and market share; our success in addressing the wind
energy market is dependent on the manufacturers that license our designs; growth of the wind energy
market depends largely on the availability and size of government subsidies and economic
incentives; there are a number of technological challenges that must be successfully addressed
before our superconductor products can gain widespread commercial acceptance, and our inability to
address such technological challenges could adversely affect our ability to acquire customers for
our products; we have not manufactured our Amperium wire in commercial quantities, and a failure to
manufacture our Amperium wire in commercial quantities at acceptable cost and quality levels would
substantially limit our future revenue and profit potential; the commercial uses of superconductor
products are limited today, and a widespread commercial market for our products may not develop; we
have limited experience in marketing and selling our superconductor products and system-level
solutions, and our failure to effectively market and sell our products and solutions could lower
our revenue and cash flow; our contracts with the U.S. government are subject to audit,
modification or termination by the U.S. government and include certain other provisions in favor of
the government; the continued funding of such contracts remains subject to annual congressional
appropriation which, if not approved, could reduce our revenue and lower or eliminate our profit;
we may be unable to adequately prevent disclosure of trade secrets and other proprietary
information; we have filed a

[0000950123-11-086288:8k_2_02:26]
demand for arbitration and other lawsuits against Sinovel regarding
amounts we contend are due and owing and are in dispute; we cannot be certain as to the outcome of
the proceedings against Sinovel; we have been named as a party to purported
stockholder class actions and shareholder derivative complaints, and we may be named in additional
litigation, all of which will require significant management time and attention, result in
significant legal expenses and may result in an unfavorable outcome, which could have a material
adverse effect on our business, operating results and financial condition; our technology and
products could infringe intellectual property rights of others, which may require costly litigation
and, if we are not successful, could cause us to pay substantial damages and disrupt our business;
our patents may not provide meaningful protection for our technology, which could result in us
losing some or all of our market position; third parties have or may acquire patents that cover the
materials, processes and technologies we use or may use in the future to manufacture our Amperium
products, and our success depends on our ability to license such patents or other proprietary
rights; and our common stock has experienced, and may continue to experience, significant market
price and volume fluctuations, which may prevent our stockholders from selling our common stock at
a profit and could lead to costly litigation against us that could divert our management’s
attention. Reference is made to many of these factors and others in the “Risk Factors” section of
the company’s most recent quarterly or annual report filed with the Securities and Exchange
Commission. In addition, any forward-looking statements included in this release represent the
company’s expectations as of the date of this release. While the company anticipates that
subsequent events and developments may cause the company’s views to change, the company
specifically disclaims any obligation to update these forward-looking statements. These
forward-looking statements should not be relied upon as representing the company’s views as of any
date subsequent to the date of this release.

[0000950123-11-086288:8k_2_02:27]
UNAUDITED CONSOLIDATED STATEMENTS OF OPERATIONS

[0000950123-11-086288:8k_2_02:28]
(In thousands, except per share data)

[0000950123-11-086288:8k_2_02:29]
|  |  | Three months ended |  |  | Year ended |  |
|  |  | March 31, |  |  | March 31, |  |
|  |  | 2011 |  |  | 2010 |  |  | 2011 |  |  | 2010 |  |
| Revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Power Systems |  | $ | 56,938 |  |  | $ | 84,763 |  |  | $ | 276,440 |  |  | $ | 304,276 |  |
| Superconductors |  |  | 2,813 |  |  |  | 2,861 |  |  |  | 10,163 |  |  |  | 11,679 |  |
| Total revenues |  |  | 59,751 |  |  |  | 87,624 |  |  |  | 286,603 |  |  |  | 315,955 |  |
| Cost of revenues |  |  | 159,016 |  |  |  | 54,479 |  |  |  | 308,183 |  |  |  | 200,977 |  |
| Gross profit |  |  | (99,265 | ) |  |  | 33,145 |  |  |  | (21,580 | ) |  |  | 114,978 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Research and development |  |  | 8,908 |  |  |  | 7,228 |  |  |  | 32,517 |  |  |  | 23,593 |  |
| Selling, general and administrative |  |  | 25,662 |  |  |  | 13,968 |  |  |  | 72,382 |  |  |  | 50,446 |  |
| Goodwill and long-lived asset impairment |  |  | 49,955 |  |  |  | — |  |  |  | 49,955 |  |  |  | — |  |
| Amortization of acquisition related intangibles |  |  | 394 |  |  |  | 449 |  |  |  | 1,549 |  |  |  | 1,827 |  |
| Restructuring |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 451 |  |
| Total operating expenses |  |  | 84,919 |  |  |  | 21,645 |  |  |  | 156,403 |  |  |  | 76,317 |  |
| Operating (loss) income |  |  | (184,184 | ) |  |  | 11,500 |  |  |  | (177,983 | ) |  |  | 38,661 |  |
| Interest income, net |  |  | 281 |  |  |  | 160 |  |  |  | 830 |  |  |  | 788 |  |
| Other income (expense), net |  |  | 2,079 |  |  |  | (39 | ) |  |  | 6,822 |  |  |  | (2,693 | ) |
| (Loss) income before income tax expense |  |  | (181,824 | ) |  |  | 11,621 |  |  |  | (170,331 | ) |  |  | 36,756 |  |
| Income tax expense |  |  | 3,311 |  |  |  | 6,684 |  |  |  | 15,953 |  |  |  | 20,508 |  |
| Net (loss) income |  | $ | (185,135 | ) |  | $ | 4,937 |  |  | $ | (186,284 | ) |  | $ | 16,248 |  |
| Net (loss) income per common share |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | (3.67 | ) |  | $ | 0.11 |  |  | $ | (3.95 | ) |  | $ | 0.37 |  |
| Diluted |  | $ | (3.67 | ) |  | $ | 0.11 |  |  | $ | (3.95 | ) |  | $ | 0.36 |  |
| Weighted average number of common shares outstanding |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  |  | 50,423 |  |  |  | 45,133 |  |  |  | 47,103 |  |  |  | 44,445 |  |
| Diluted |  |  | 50,423 |  |  |  | 45,955 |  |  |  | 47,103 |  |  |  | 45,290 |  |

[0000950123-11-086288:8k_2_02:30]
UNAUDITED CONSOLIDATED STATEMENTS OF OPERATIONS

[0000950123-11-086288:8k_2_02:31]
(In thousands, except per share data)

[0000950123-11-086288:8k_2_02:32]
|  |  | Three months ended |  |
|  |  | June 30, |  |
|  |  | 2011 |  |  | 2010 |  |
| Revenues: |  |  |  |  |  |  |  |  |
| Wind |  | $ | 4,262 |  |  | $ | 83,006 |  |
| Grid |  |  | 4,796 |  |  |  | 14,203 |  |
| Total revenues |  |  | 9,058 |  |  |  | 97,209 |  |
| Cost of revenues |  |  | 16,955 |  |  |  | 58,224 |  |
| Gross profit |  |  | (7,897 | ) |  |  | 38,985 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |
| Research and development |  |  | 8,136 |  |  |  | 7,335 |  |
| Selling, general and administrative |  |  | 21,990 |  |  |  | 15,183 |  |
| Amortization of acquisition related intangibles |  |  | 304 |  |  |  | 386 |  |
| Total operating expenses |  |  | 30,430 |  |  |  | 22,904 |  |
| Operating (loss) income |  |  | (38,327 | ) |  |  | 16,081 |  |
| Interest income, net |  |  | 241 |  |  |  | 175 |  |
| Other income, net |  |  | 566 |  |  |  | 171 |  |
| (Loss) income before income tax expense |  |  | (37,520 | ) |  |  | 16,427 |  |
| Income tax expense |  |  | 159 |  |  |  | 7,257 |  |
| Net (loss) income |  | $ | (37,679 | ) |  | $ | 9,170 |  |
| Net (loss) income per common share |  |  |  |  |  |  |  |  |
| Basic |  | $ | (0.74 | ) |  | $ | 0.20 |  |
| Diluted |  | $ | (0.74 | ) |  | $ | 0.20 |  |
| Weighted average number of common shares outstanding |  |  |  |  |  |  |  |  |
| Basic |  |  | 50,709 |  |  |  | 45,242 |  |
| Diluted |  |  | 50,709 |  |  |  | 45,983 |  |

[0000950123-11-086288:8k_2_02:33]
UNAUDITED CONSOLIDATED BALANCE SHEETS

[0000950123-11-086288:8k_2_02:34]
(In thousands)

[0000950123-11-086288:8k_2_02:35]
|  |  | June 30, |  |  | March 31, |  |  | March 31, |  |
|  |  | 2011 |  |  | 2011 |  |  | 2010 |  |
| ASSETS |  |  |  |  |  |  |  |  |  |  |  |  |
| Current assets: |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 130,885 |  |  | $ | 123,783 |  |  | $ | 87,594 |  |
| Marketable securities |  |  | 25,894 |  |  |  | 116,126 |  |  |  | 54,469 |  |
| Accounts receivable, net |  |  | 11,652 |  |  |  | 17,233 |  |  |  | 57,290 |  |
| Inventory |  |  | 31,068 |  |  |  | 25,828 |  |  |  | 35,858 |  |
| Prepaid expenses and other current assets |  |  | 39,073 |  |  |  | 30,785 |  |  |  | 20,294 |  |
| Advance payment for planned acquisition |  |  | 20,551 |  |  |  | — |  |  |  | — |  |
| Restricted cash |  |  | 6,516 |  |  |  | 5,566 |  |  |  | 5,713 |  |
| Deferred tax assets |  |  | 484 |  |  |  | 484 |  |  |  | 1,776 |  |
| Total current assets |  |  | 266,123 |  |  |  | 319,805 |  |  |  | 262,994 |  |
| Property, plant and equipment, net |  |  | 98,615 |  |  |  | 96,494 |  |  |  | 64,315 |  |
| Goodwill |  |  | — |  |  |  | — |  |  |  | 36,696 |  |
| Intangibles, net |  |  | 6,650 |  |  |  | 7,054 |  |  |  | 7,770 |  |
| Marketable securities |  |  | — |  |  |  | — |  |  |  | 7,342 |  |
| Restricted cash |  |  | 2,857 |  |  |  | — |  |  |  | — |  |
| Deferred tax assets |  |  | 5,840 |  |  |  | 5,840 |  |  |  | 3,043 |  |
| Other assets |  |  | 13,577 |  |  |  | 12,016 |  |  |  | 18,024 |  |
| Total assets |  | $ | 393,662 |  |  | $ | 441,209 |  |  | $ | 400,184 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |  |  |  |  |  |  |  |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |  |  |  |  |  |  |  |
| Accounts payable and accrued expenses |  | $ | 66,395 |  |  | $ | 90,273 |  |  | $ | 84,319 |  |
| Adverse purchase commitments |  |  | 40,292 |  |  |  | 38,763 |  |  |  | — |  |
| Line of credit |  |  | 4,641 |  |  |  | — |  |  |  | — |  |
| Deferred revenue |  |  | 13,676 |  |  |  | 10,304 |  |  |  | 19,970 |  |
| Deferred tax liabilities |  |  | 5,840 |  |  |  | 5,840 |  |  |  | 471 |  |
| Total current liabilities |  |  | 130,844 |  |  |  | 145,180 |  |  |  | 104,760 |  |
| Deferred revenue |  |  | 2,063 |  |  |  | 2,181 |  |  |  | 13,302 |  |
| Deferred tax liabilities |  |  | 484 |  |  |  | 484 |  |  |  | 777 |  |
| Other |  |  | 530 |  |  |  | 509 |  |  |  | 380 |  |
| Total liabilities |  |  | 133,921 |  |  |  | 148,354 |  |  |  | 119,219 |  |
| Stockholders’ equity: |  |  |  |  |  |  |  |  |  |  |  |  |
| Common stock |  |  | 509 |  |  |  | 507 |  |  |  | 448 |  |
| Additional paid-in capital |  |  | 889,394 |  |  |  | 885,704 |  |  |  | 698,417 |  |
| Treasury stock |  |  | (271 | ) |  |  | — |  |  |  | — |  |
| Accumulated other comprehensive income (loss) |  |  | 4,961 |  |  |  | 3,817 |  |  |  | (7,011 | ) |
| Accumulated deficit |  |  | (634,852 | ) |  |  | (597,173 | ) |  |  | (410,889 | ) |
| Total stockholders’ equity |  |  | 259,741 |  |  |  | 292,855 |  |  |  | 280,965 |  |
| Total liabilities and stockholders’ equity |  | $ | 393,662 |  |  | $ | 441,209 |  |  | $ | 400,184 |  |

[0000950123-11-086288:8k_2_02:36]
UNAUDITED CONSOLIDATED STATEMENTS OF CASH FLOWS

[0000950123-11-086288:8k_2_02:37]
(In thousands)

[0000950123-11-086288:8k_2_02:38]
|  |  | Three months ended June 30, |  |  | Year ended March 31, |  |
|  |  | 2011 |  |  | 2010 |  |  | 2011 |  |  | 2010 |  |
| Cash flows from operating activities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net (loss) income |  | $ | (37,679 | ) |  | $ | 9,170 |  |  | $ | (186,284 | ) |  | $ | 16,248 |  |
| Adjustments to reconcile net (loss) income to net cash used in operations: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Depreciation and amortization |  |  | 3,242 |  |  |  | 2,654 |  |  |  | 11,300 |  |  |  | 9,789 |  |
| Stock-based compensation expense |  |  | 3,466 |  |  |  | 3,578 |  |  |  | 13,443 |  |  |  | 13,632 |  |
| Impairment of goodwill and long-lived assets |  |  | — |  |  |  | — |  |  |  | 49,955 |  |  |  | — |  |
| Provision for excess and obsolete inventory |  |  | 413 |  |  |  | — |  |  |  | 63,882 |  |  |  | — |  |
| Losses on purchase commitments |  |  | 1,071 |  |  |  | — |  |  |  | 38,763 |  |  |  | — |  |
| Allowance for doubtful accounts |  |  | — |  |  |  | 957 |  |  |  | 25 |  |  |  | (523 | ) |
| Write-off of prepaid value added taxes |  |  | — |  |  |  | — |  |  |  | 5,905 |  |  |  | — |  |
| Deferred income taxes |  |  | — |  |  |  | 2,027 |  |  |  | 3,660 |  |  |  | (2,717 | ) |
| Other non-cash items |  |  | 827 |  |  |  | 320 |  |  |  | 2,345 |  |  |  | 1,155 |  |
| Changes in operating asset and liability accounts: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Accounts receivable |  |  | 670 |  |  |  | (35,848 | ) |  |  | 63,175 |  |  |  | (16,993 | ) |
| Inventory |  |  | (5,324 | ) |  |  | (5,654 | ) |  |  | (51,942 | ) |  |  | (656 | ) |
| Prepaid expenses and other current assets |  |  | (7,812 | ) |  |  | (1,616 | ) |  |  | (15,428 | ) |  |  | (10,051 | ) |
| Accounts payable and accrued expenses |  |  | (19,732 | ) |  |  | (2,140 | ) |  |  | (222 | ) |  |  | 23,775 |  |
| Deferred revenue |  |  | 3,084 |  |  |  | 8,073 |  |  |  | (21,398 | ) |  |  | 7,021 |  |
| Net cash (used in) provided by operating activities |  |  | (57,774 | ) |  |  | (18,479 | ) |  |  | (22,821 | ) |  |  | 40,680 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net cash provided by (used in) investing activities |  |  | 59,753 |  |  |  | (41 | ) |  |  | (104,833 | ) |  |  | (39,996 | ) |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net cash provided by financing activities |  |  | 4,376 |  |  |  | 561 |  |  |  | 163,058 |  |  |  | 19,003 |  |
| Effect of exchange rate changes on cash and cash equivalents |  |  | 747 |  |  |  | (4,791 | ) |  |  | 785 |  |  |  | (2,767 | ) |
| Net increase (decrease) in cash and cash equivalents |  |  | 7,102 |  |  |  | (22,750 | ) |  |  | 36,189 |  |  |  | 16,920 |  |
| Cash and cash equivalents at beginning of period |  |  | 123,783 |  |  |  | 87,594 |  |  |  | 87,594 |  |  |  | 70,674 |  |
| Cash and cash equivalents at end of period |  | $ | 130,885 |  |  | $ | 64,844 |  |  | $ | 123,783 |  |  | $ | 87,594 |  |

[0000950123-11-086288:8k_2_02:39]
Reconciliation of GAAP Net (Loss) Income to Non-GAAP Net (Loss) Income

[0000950123-11-086288:8k_2_02:40]
(In thousands, except per share data)

[0000950123-11-086288:8k_2_02:41]
|  |  | Three months ended March 31, |  |  | Year ended March 31, |  |
|  |  | 2011 |  |  | 2010 |  |  | 2011 |  |  | 2010 |  |
| Net (loss) income |  | $ | (185,135 | ) |  | $ | 4,937 |  |  | $ | (186,284 | ) |  | $ | 16,248 |  |
| Goodwill and long-lived asset impairment |  |  | 49,955 |  |  |  | — |  |  |  | 49,955 |  |  |  | 451 |  |
| Provision for excess and obsolete inventory |  |  | 61,216 |  |  |  | — |  |  |  | 63,882 |  |  |  | — |  |
| Losses on purchase commitments |  |  | 38,763 |  |  |  | — |  |  |  | 38,763 |  |  |  | — |  |
| Write-off of prepaid value added taxes |  |  | 5,355 |  |  |  | — |  |  |  | 5,905 |  |  |  | — |  |
| Stock-based compensation |  |  | 3,338 |  |  |  | 3,054 |  |  |  | 13,412 |  |  |  | 13,494 |  |
| Amortization of acquisition-related intangibles |  |  | 394 |  |  |  | 449 |  |  |  | 1,549 |  |  |  | 1,827 |  |
| Tax effects |  |  | — |  |  |  | (90 | ) |  |  | — |  |  |  | (367 | ) |
| Non-GAAP net income (loss) |  | $ | (26,114 | ) |  | $ | 8,350 |  |  | $ | (12,818 | ) |  | $ | 31,653 |  |
| Non-GAAP (loss) earnings per share |  | $ | (0.52 | ) |  | $ | 0.18 |  |  | $ | (0.27 | ) |  | $ | 0.70 |  |
| Weighted average shares outstanding * |  |  | 50,423 |  |  |  | 45,955 |  |  |  | 47,103 |  |  |  | 45,290 |  |

[0000950123-11-086288:8k_2_02:42]
| * |  | Diluted shares are used for periods where net income is generated. |

[0000950123-11-086288:8k_2_02:43]
Reconciliation of GAAP Net (Loss) Income to Non-GAAP Net (Loss) Income

[0000950123-11-086288:8k_2_02:44]
(In thousands, except per share data)

[0000950123-11-086288:8k_2_02:45]
|  |  | Three months ended |  |
|  |  | June 30, |  |
|  |  | 2011 |  |  | 2010 |  |
| Net (loss) income |  | $ | (37,679 | ) |  | $ | 9,170 |  |
| Stock-based compensation |  |  | 3,466 |  |  |  | 3,499 |  |
| Severance costs |  |  | 2,066 |  |  |  | — |  |
| Losses on purchase commitments |  |  | 1,071 |  |  |  | — |  |
| Amortization of acquisition-related intangibles |  |  | 304 |  |  |  | 386 |  |
| Tax effects |  |  | — |  |  |  | (83 | ) |
| Non-GAAP net (loss) income |  | $ | (30,772 | ) |  | $ | 12,972 |  |
| Non-GAAP (loss) earnings per share |  | $ | (0.61 | ) |  | $ | 0.28 |  |
| Weighted average shares outstanding * |  |  | 50,709 |  |  |  | 45,983 |  |

[0000950123-11-086288:8k_2_02:46]
| * |  | Diluted shares are used for periods where net income is generated. |

[0000950123-11-086288:8k_2_02:47]
Reconciliation of Forecast GAAP Net Loss to Non-GAAP Net

[0000950123-11-086288:8k_2_02:48]
Loss for the Quarter Ended September 30, 2011

[0000950123-11-086288:8k_2_02:49]
(In millions, except per share data)

[0000950123-11-086288:8k_2_02:50]
| Net loss |  | $ | (38.0 | ) |
| Amortization of acquisition-related intangibles |  |  | 0.3 |  |
| Stock-based compensation |  |  | 2.5 |  |
| Sinovel litigation expenses |  |  | 5.2 |  |
| Restructuring charges |  |  | 3.0 |  |
| Tax effects |  |  | — |  |
| Non-GAAP net loss |  | $ | (27.0 | ) |
| Non-GAAP net loss per share |  | $ | (0.53 | ) |
| Shares outstanding |  |  | 50.9 |  |

[0000950123-11-086288:8k_2_02:51]
Note: Non-GAAP net income (loss) is defined by the company as net income (loss) before
amortization of acquisition-related intangibles, restructuring and impairments, stock-based
compensation, severance and other unusual charges, and any tax effects related to these items. The
company believes non-GAAP net income (loss) assists management and investors in comparing the
company’s performance across reporting periods on a consistent basis by excluding these non-cash or
non-recurring charges that it does not believe are indicative of its core operating performance.
The company also regards non-GAAP net income (loss) as a useful measure of operating performance
and cash flow to complement operating income, net income (loss) and other GAAP financial
performance measures. In addition, the company uses non-GAAP net (loss) income as a factor in
evaluating management’s performance when determining incentive compensation and to evaluate the
effectiveness of its business strategies.

[0000950123-11-086288:8k_2_02:52]
Generally, a non-GAAP financial measure is a numerical measure of a company’s performance,
financial position or cash flow that either excludes or includes amounts that are not normally
excluded or included in the most directly comparable measure calculated and presented in accordance
with GAAP. The non-GAAP measures included in this release, however, should be considered in
addition to, and not as a substitute for or superior to, operating income, cash flows, or other
measures of financial performance prepared in accordance with GAAP. A reconciliation of non-GAAP to
GAAP net income is set forth in the table above.

[0000950123-11-086288:8k_2_02:53]
AMSC Contact:

[0000950123-11-086288:8k_2_02:54]
Jason Fredette

[0000950123-11-086288:8k_2_02:55]
Phone: 978-842-3177

[0000950123-11-086288:8k_2_02:56]
Email: jfredette@amsc.com
