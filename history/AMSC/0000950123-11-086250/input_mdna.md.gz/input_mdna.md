# AMSC MD&A — 0000950123-11-086250


## mdna

[0000950123-11-086250:mdna:1]
[same as prior period, unchanged from 0000950123-11-008765:mdna:1]

[0000950123-11-086250:mdna:2]
of such contracts remains subject to annual congressional appropriation which, if not
approved, could reduce our revenue and lower or eliminate our profit; we may be unable to
adequately prevent disclosure of trade secrets and other proprietary information; we have filed a
demand for arbitration and other lawsuits against Sinovel regarding amounts we contend are due and
owing and are in dispute; we cannot be certain as to the outcome of the proceedings against
Sinovel; we have been named as a party to purported stockholder class actions and shareholder
derivative complaints, and we may be named in additional litigation, all of which will require
significant management time and attention, result in significant legal expenses and may result in
an unfavorable outcome, which could have a material adverse effect on our business, operating
results and financial condition; our technology and products could infringe intellectual property
rights of others, which may require costly litigation and, if we are not successful, could cause us
to pay substantial damages and disrupt our business; our patents may not provide meaningful
protection for our technology, which could result in us losing some or all of our market position;
third parties have or may acquire patents that cover the materials, processes and technologies we
use or may use in the future to manufacture our Amperium products, and our success depends on our
ability to license such patents or other proprietary rights; and our common stock has experienced,
and may continue to experience, significant market price and volume fluctuations, which may prevent
our stockholders from selling our common stock at a profit and could lead to costly litigation
against us that could divert our management’s attention. These and the important factors discussed
under the caption “Risk Factors” in Part II. Item 1A and Part 1. Item 1A of our Form 10-K for the
fiscal year ended March 31, 2011, among others, could cause actual results to differ materially
from those indicated by forward-looking statements made herein and presented elsewhere by
management from time to time. Any such forward-looking statements represent management’s estimates
as of the date of this Quarterly Report on Form 10-Q. While we may elect to update such
forward-looking statements at some point in the future, we disclaim any obligation to do so, even
if subsequent events cause our views to change. These forward-looking statements should not be
relied upon as representing our views as of any date subsequent to the date of this Quarterly
Report on Form 10-Q.

[0000950123-11-086250:mdna:3]
American Superconductor® and design, Revolutionizing the Way the World Uses Electricity®,
AmperiumTM, AMSC®, Powered by AMSC®, D-VAR®, dSVCTM,
FaultBlockerTM, PowerModuleTM, PowerPipelinesTM, PQ-IVR®, PQ-SVC®,
SeaTitanTM, SolarTieTM, Windtec and SuperGEARTM are trademarks or
registered trademarks of American Superconductor Corporation or its subsidiaries. The Windtec logo
and design is a registered European Union Community Trademark. We reserve all of our rights with
respect to our trademarks or registered trademarks regardless of whether they are so designated in
this Quarterly Report on Form 10-Q by an ® or TM symbol. All other brand names, product
names, trademarks or service marks appearing in this Quarterly Report on Form 10-Q are the property
of their respective holders.

[0000950123-11-086250:mdna:4]
[same as prior period, unchanged from 0000950123-11-008765:mdna:3]

[0000950123-11-086250:mdna:5]
American Superconductor Corporation was founded in 1987. We are a leading provider of
megawatt-scale solutions that lower the cost of wind power and enhance the performance of the power
grid. In the wind power market, we enable manufacturers to field wind turbines through our
advanced engineering, support services and power electronics products. In the power grid market,
we enable electric utilities and renewable energy project developers to connect, transmit and
distribute power through our transmission planning services and power electronics and
superconductor based products. Our wind and power grid products and services provide exceptional
reliability, security, efficiency and affordability to our customers.

[0000950123-11-086250:mdna:6]
Our wind and power grid solutions help to improve energy efficiency, alleviate power grid
capacity constraints and increase the adoption of renewable energy generation. Demand for our
solutions is driven by the growing needs for renewable sources of electricity, such as wind and
solar energy, and for modernized smart grids that improve power reliability and quality. Concerns
about these factors have led to increased spending by corporations as well as supportive government
regulations and initiatives on local, state, national and global levels, including renewable
portfolio standards, tax incentives and international treaties.

[0000950123-11-086250:mdna:7]
We manufacture products using two proprietary core technologies: PowerModule™ programmable
power electronic converters and our Amperium™ HTS wires. These technologies and our system-level
solutions are protected by a broad and deep intellectual property portfolio consisting of hundreds
of patents and licenses worldwide.

[0000950123-11-086250:mdna:8]
On March 12, 2011, we entered into a definitive agreement to acquire The Switch Engineering
Oy, (“The Switch”). The Switch designs, manufactures and markets wind power products, including
permanent magnet generators and power converter systems, as well as grid products such as
commercial and small utility-scale solar inverters to customers in Asia, including China, Europe
and North America.

[0000950123-11-086250:mdna:9]
As of April 1, 2011, we are segmenting our operations into two new market-facing business
units: Wind and Grid. We believe this market-centric structure enables us to more effectively
anticipate and meet the needs of wind turbine manufacturers, power generation project developers
and electric utilities.

[0000950123-11-086250:mdna:10]
|  | • |  | Wind. Through our Windtec brand, our Wind business enables manufacturers to field wind turbines with exceptional power output, reliability and affordability. We license our highly engineered wind turbine |

[0000950123-11-086250:mdna:11]
|  |  |  | designs, provide extensive customer support services and supply advanced power electronics and control systems to wind turbine manufactures. Our design portfolio includes a broad range of drive trains and power ratings up to 10 megawatts. We believe our unique engineering capabilities, ranging from bearings to advanced synchronous generators to blades, enables us to provide our partners with highly-optimized wind turbine platforms. Furthermore, these designs and support services typically lead to sales of our power electronics and software-based control systems, which are designed for optimized performance, efficiency and grid compatibility. |

[0000950123-11-086250:mdna:12]
|  | • |  | Grid. Our Grid segment enables electric utilities and renewable energy project developers to connect, transmit and distribute power with exceptional efficiency, reliability and affordability. We provide transmission planning services that allow us to identify power grid congestion, poor power quality and other risks, which help us determine how our solutions can improve network performance. These services often lead to sales of grid interconnection solutions for wind farms and solar power plants, power quality systems and transmission and distribution cable systems. |

[0000950123-11-086250:mdna:13]
Prior to April 1, 2011, we segmented our operations through two technology-centric business
units: AMSC Power Systems and AMSC Superconductors. AMSC Power Systems included all of our Wind
products, as well as Grid products that regulate voltage for wind farm voltage electric utilities,
renewable generation project developers and industrial operations. Solutions from our AMSC
Superconductors business unit have been incorporated into our Grid business unit.

[0000950123-11-086250:mdna:14]
Our fiscal year begins on April 1 and ends on March 31. This document refers to fiscal 2011,
which is defined as the period beginning on April 1, 2011 and concluding on March 31, 2012. The
first quarter of fiscal 2011 began on April 1, 2011 and concluded on June 30, 2011.

[0000950123-11-086250:mdna:15]
Our cash requirements depend on numerous factors, including successful completion of our
product development activities, ability to commercialize our product prototypes, rate of customer
and market adoption of our products, collecting receivables according to established terms, and the
continued availability of U.S. government funding during the product development phase. Significant
deviations to our business plan with regard to these factors, which are important drivers to our
business, could have a material adverse effect on our operating performance, financial condition,
and future business prospects. We expect to pursue the expansion of our operations through internal
growth and potential strategic alliances and acquisitions.

[0000950123-11-086250:mdna:16]
As of June 30, 2011 and March 31, 2011, we had backlog of approximately $225.4 million and
$228.4 million, respectively, excluding Sinovel. Including Sinovel, as of June 30, 2011 and March
31, 2011, we had backlog of approximately $925.7 million and $921.5 million, respectively. On
March 31, 2011, Sinovel refused to accept contracted shipments of 1.5-MW and 3-MW wind turbine core
electrical components and spare parts that we were prepared to deliver. As a result, we have not
made shipments to Sinovel since February 2011. If Sinovel continues not to accept these shipments,
or terminates, reduces or defers firm orders, we will not be able to complete these shipments and
we may not generate the revenue supported by these contracts.

[0000950123-11-086250:mdna:17]
During March 2011, we engaged in discussions with Sinovel regarding the acceptance of its
scheduled shipments, outstanding receivables, and the delivery of a custom solution desired by
Sinovel for low voltage ride through (“LVRT”) that required a modification to our existing LVRT
design. The custom design required modified software and additional hardware. Toward the end of
March, Sinovel requested that we provide them with the additional hardware without additional cost.
On March 31, 2011, we proposed to Sinovel that we would provide the additional hardware without
additional cost if Sinovel would accept the scheduled shipments. Sinovel rejected this proposal
due to what we were told was excess inventory of our components. Since Sinovel did not give us the
requisite notice under our contracts that they intended to delay deliveries, we believe that these
actions constitute material breaches of our contracts.

[0000950123-11-086250:mdna:18]
While we have had several discussions with Sinovel since March 31, 2011, as of the date of
this filing, we have not received payment for any outstanding receivables nor have we been notified
as to when, if ever, they will accept contracted shipments that were scheduled for delivery after
March 31, 2011. Additionally, based in part upon evidence obtained through an internal
investigation and a criminal investigation conducted by Austrian authorities regarding the actions
of a former employee of our AMSC Windtec subsidiary, we believe that Sinovel illegally obtained and
used our intellectual property in violation of civil and criminal intellectual property laws. In
July 2011, the former employee was arrested in Austria and is currently awaiting trial on charges
of economic espionage and fraudulent manipulation of data. As a result of the investigations, we
believe that this former employee was contracted by Sinovel through an intermediary while employed
by us and improperly obtained and transferred to Sinovel portions of our wind turbine control
software source code developed for Sinovel’s 1.5MW wind turbines. Except for portions of this 1.5
MW wind turbine software, we do not believe that the source code for any other turbines, such as
the 3MW, 5MW and 6MW wind turbines that were designed by and co-developed with us have been
transferred to Sinovel. Moreover, we believe the former employee illegally used source code to

[0000950123-11-086250:mdna:19]
develop for Sinovel a software modification to circumvent the encryption and remove technical
protection measures on the PM3000 power converters in 1.5MW wind turbines in the field. We believe
that only the binary code, or upper layer, of the PM3000 software developed to circumvent the
encryption and remove technical protection measures was transferred to Sinovel. We do not believe
that any PM3000 source code was transferred to Sinovel. These actions potentially enable Sinovel to
deploy, independent of us, wind turbine control software, including a low voltage ride through
solution, on all of its 1.5MW wind turbines in the field. In addition, by having the wind turbine
control source code, Sinovel could potentially modify the source code to allow the use of core
electrical components, including power converters, from other manufacturers.

[0000950123-11-086250:mdna:20]
On September 13, 2011, we commenced a series of legal actions in China against Sinovel. We
filed a claim for arbitration in Beijing, China to compel Sinovel to pay us for past product
shipments and to accept all contracted but not yet delivered core electrical components and spare
parts under all existing contracts with us. The arbitration claim was filed with the Beijing
Arbitration Commission in accordance with the terms of our supply contracts with Sinovel. We are
also in the process of filing civil and criminal complaints against Sinovel. On September 16,
2011, we filed a civil complaint in China against Dalian Guotong Electric, Co., Ltd. and other
parties. The complaints allege the illegal use of our intellectual property. We are seeking to
compel Sinovel and the other parties to cease and desist from infringing our intellectual property
and are also seeking monetary damages to compensate us for our economic losses resulting from the
infringement.

[0000950123-11-086250:mdna:21]
We cannot provide any assurance as to the outcome of these legal actions. We are now
operating our business under the assumption that Sinovel will not be a customer.

[0000950123-11-086250:mdna:22]
[same as prior period, unchanged from 0000950123-11-008765:mdna:13]

[0000950123-11-086250:mdna:23]
The preparation of the unaudited condensed consolidated financial statements requires that we
make estimates and judgments that affect the reported amounts of assets, liabilities, revenues and
expenses, and related disclosure of contingent assets and liabilities. We base our estimates on
historical experience and various other assumptions that are believed to be reasonable under the
circumstances, the results of which form the basis for making judgments about the carrying values
of assets and liabilities that are not readily apparent from other sources. Actual results may
differ under different assumptions or conditions. There were no significant changes in the first
quarter of fiscal 2011 in the critical accounting policies that were disclosed in our Form 10-K for
fiscal 2010, which ended on March 31, 2011.

[0000950123-11-086250:mdna:24]
[same as prior period, unchanged from 0000950123-11-008765:mdna:27]

[0000950123-11-086250:mdna:25]
Three months ended June 30, 2011 compared to the three ended June 30, 2010

[0000950123-11-086250:mdna:26]
Beginning on April 1, 2011, management revised its reportable business segments into Wind and
Grid as a result in changes in the manner in which we disaggregate the Company’s operations for
making operating decisions and assessing performance business segments. Previously, we had two
reportable business segments, AMSC Power Systems and AMSC Superconductors. All prior period
segment disclosures have been revised to conform to management’s current view of its business
segments.

[0000950123-11-086250:mdna:27]
As discussed above, the disruption in our relationship with Sinovel has materially and
adversely affected our business and results of operations. Because Sinovel has accounted for more
than two-thirds of our revenues over each of the past three fiscal years, we experienced
significantly lower revenues and significant operating losses during the three months ended June
30, 2011. Revenues to Sinovel represented 0% and 72% of total revenues for the three months ended
June 30, 2011 and 2010, respectively. Since no cash payments were made by Sinovel in the three
months ended June 30, 2011, no revenue was recognized from Sinovel in the three months ended June
30, 2011.

[0000950123-11-086250:mdna:28]
[same as prior period, unchanged from 0000950123-11-008765:mdna:29]

[0000950123-11-086250:mdna:29]
Total revenues decreased by 91% to $9.1 million for the three months ended June 30, 2011,
compared to $97.2 million for the three months ended June 30, 2010. Our revenues are summarized as
follows (in thousands):

[0000950123-11-086250:mdna:30]
|  |  | Three months ended |  |
|  |  | June 30, |  |
|  |  | 2011 |  |  | 2010 |  |
| Revenues: |  |  |  |  |  |  |  |  |
| Wind |  | $ | 4,262 |  |  | $ | 83,006 |  |
| Grid |  |  | 4,796 |  |  |  | 14,203 |  |
| Total |  | $ | 9,058 |  |  | $ | 97,209 |  |

[0000950123-11-086250:mdna:31]
Our Wind business unit accounted for 47% of total revenues for the three months ended
June 30, 2011, compared to 85% for the three months ended June 30, 2010. Revenues in the Wind
business unit decreased 95% to $4.3 million in the three months ended June 30, 2011 from $83.0
million in the three months ended June 30, 2010. The decrease in Wind business unit revenues was
primarily due to the disruption in our relationship with Sinovel, as described above, which
accounted for $70.3 million of revenue for the first quarter of fiscal 2010.

[0000950123-11-086250:mdna:32]
Our Grid business unit accounted for 53% of total revenues for the three months ended June 30,
2011, compared to 15% for the three months ended June 30, 2010. Our Grid business unit revenues
decreased 66% to $4.8 million in the three months ended June 30, 2011 from $14.2 million for the
three months ended June 30, 2010. The decrease in Grid business unit revenues were due primarily
to reduced DVAR product sales, due in part to strong shipments in the fourth quarter of quarter of
fiscal 2010.

[0000950123-11-086250:mdna:33]
Revenues from significant government-funded contracts are summarized as follows (in
thousands):

[0000950123-11-086250:mdna:34]
|  |  |  |  |  |  | Revenue Earned |  |  |  |  |
|  |  | Expected total |  |  | through |  |  | Three months ended June 30, |  |
| Project name |  | contract value |  |  | June 30, 2011 |  |  | 2011 |  |  | 2010 |  |
| HYDRA |  | $ | 24,908 |  |  | $ | 10,963 |  |  | $ | 411 |  |  | $ | 121 |  |
| LIPA I and II |  |  | 40,141 |  |  |  | 39,710 |  |  |  | 1,309 |  |  |  | 782 |  |
| DOE-FCL |  |  | 7,898 |  |  |  | 6,785 |  |  |  | 232 |  |  |  | 571 |  |
| NAVSEA Motor Study |  |  | 6,511 |  |  |  | 6,492 |  |  |  | — |  |  |  | 107 |  |
| Total |  | $ | 79,458 |  |  | $ | 63,950 |  |  | $ | 1,952 |  |  | $ | 1,581 |  |

[0000950123-11-086250:mdna:35]
These significant projects represented 41% and 11% of the Grid business unit revenues for
the three months ended June 30, 2011 and 2010.

[0000950123-11-086250:mdna:36]
Project HYDRA is a contract with Consolidated Edison, Inc. which is being partially funded by
the U.S. Department of Homeland Security (“DHS”). DHS is expected to invest up to a total of $24.9
million in the development of a new high temperature superconductor power grid technology called
FaultBlocker™ cable systems. FaultBlocker cable systems are designed to utilize customized
Amperium™ HTS wires, and ancillary controls to deliver more power through the grid while also being
able to suppress power surges that can disrupt service. Of the total $24.9 million in funding
expected from DHS, it has committed funding of $12.6 million to us as of June 30, 2011. On
September 15, 2011, the DHS committed an additional $3.0 million in funding on Project HYDRA.
Consolidated Edison and Southwire Company are subcontractors to us on this project.

[0000950123-11-086250:mdna:37]
[same as prior period, unchanged from 0000950123-11-008765:mdna:40]

[0000950123-11-086250:mdna:38]
Based on the average Euro and renminbi exchange rates for the first quarter of fiscal
2011, revenues denominated in these foreign currencies translated into U.S. dollars were $0.3
million higher compared to the translation of these revenues using the average exchange rates of
these currencies for the first quarter of fiscal 2010.

[0000950123-11-086250:mdna:39]
The following table sets forth customers who represented 10% or more of our total revenues for
the three months ended June 30, 2011 and 2010:

[0000950123-11-086250:mdna:40]
|  |  | Three months ended |  |
|  |  | June 30, |  |
|  |  | 2011 |  |  | 2010 |  |
| Department of Energy/NETL |  |  | 17 | % |  |  | <10 | % |
| Doosan Heavy Industries & Construction Co Ltd. |  |  | 15 | % |  |  | <10 | % |
| Shenyang Blower Works Group Wind Power Co.,Ltd. |  |  | 13 | % |  |  | <10 | % |
| Sinovel Wind Co., Ltd |  |  | — | % |  |  | 72 | % |

[0000950123-11-086250:mdna:41]
[same as prior period, unchanged from 0000950123-11-008765:mdna:44]

[0000950123-11-086250:mdna:42]
Cost of revenues decreased by 71% to $17.0 million for the three months ended June 30, 2011,
compared to $58.2 million for the three months ended June 30, 2010. Gross margin was (87.2%) and
40.1% for the three months ended June 30, 2011 and 2010, respectively. The decrease in gross margin
and cost of revenues in the three months ended June 30, 2011 as compared to the same period in
fiscal 2010 was a result of lower sales due to the disruption in our relationship with Sinovel and
unabsorbed fixed overhead due to idle capacity. This is expected to improve in the future quarters
as the wind market in China recovers.

[0000950123-11-086250:mdna:43]
Based on the average Euro and renminbi exchange rates for the first quarter of fiscal 2011,
cost of revenues denominated in these foreign currencies translated into U.S. dollars was $0.5
million higher compared to the translation of cost of revenues using the average exchange rates of
these currencies for the first quarter of fiscal 2010.

[0000950123-11-086250:mdna:44]
[same as prior period, unchanged from 0000950123-11-008765:mdna:46]

[0000950123-11-086250:mdna:45]
[same as prior period, unchanged from 0000950123-11-008765:mdna:47]

[0000950123-11-086250:mdna:46]
[same as prior period, unchanged from 0000950123-11-008765:mdna:48]

[0000950123-11-086250:mdna:47]
|  |  | Three months ended |  |
|  |  | June 30, |  |
|  |  | 2011 |  |  | 2010 |  |
| R&D expenses per unaudited condensed consolidated statements of operations |  | $ | 8,136 |  |  | $ | 7,335 |  |
| R&D expenditures reclassified as cost of revenues |  |  | 4,040 |  |  |  | 3,369 |  |
| R&D expenditures offset by cost-sharing funding |  |  | 34 |  |  |  | 141 |  |
| Aggregated R&D expenses |  | $ | 12,210 |  |  | $ | 10,845 |  |

[0000950123-11-086250:mdna:48]
R&D expenses (exclusive of amounts classified as cost of revenues and amounts offset by
cost-sharing funding) increased by 11% to $8.1 million for the three months ended June 30, 2011
from $7.3 million for the three months ended June 30, 2010. The increase in R&D expenses was driven
primarily by labor, material and overhead spending to support new product development in our Wind
business segment. The increase in R&D expenditures reclassified to costs of revenue was a result of
increased efforts under license and development contracts for wind turbine designs at AMSC Windtec
compared to the prior year. Aggregated R&D expenses, which include amounts classified as cost of
revenues and amounts offset by cost-sharing funding, increased 13% to $12.2 million for the three
months ended June 30, 2011, compared to $10.8 million for the three months ended June 30, 2010. The
increases in fiscal 2010 were driven primarily by the net impact of the factors described above.
Growth in R&D expenses is expected to moderate going forward as a result of the restructuring
actions undertaken in fiscal 2011.

[0000950123-11-086250:mdna:49]
We present aggregated R&D, which is a non-GAAP measure, because we believe this presentation
provides useful information on our aggregate R&D spending and because R&D expenses as reported on
the unaudited condensed consolidated statements of income have been, and may in the future, be
subject to significant fluctuations solely as a result of changes in the level of externally funded
contract development work, resulting in significant changes in the amount of the costs recorded as
costs of revenues rather than as R&D expenses, as discussed above.

[0000950123-11-086250:mdna:50]
[same as prior period, unchanged from 0000950123-11-008765:mdna:52]

[0000950123-11-086250:mdna:51]
SG&A expenses increased by 45% to $22.0 million in the three months ended June 30, 2011, from
$15.2 in the three months ended June 30, 2010. The increases in SG&A expenses were due primarily
to increases in legal fees associated with ongoing litigation as discussed in Part II, Item 1,
“Legal Proceedings,” of this Quarterly Report on Form 10-Q and severance and stock compensation
costs for our former Chief Executive Officer. Higher legal expenses are expected for the next
several quarters as we expect to continue pursuing litigation against Sinovel.

[0000950123-11-086250:mdna:52]
[same as prior period, unchanged from 0000950123-11-008765:mdna:54]

[0000950123-11-086250:mdna:53]
We recorded amortization expense related to our core technology and know-how, trade names and
trademark intangible assets of $0.3 million and $0.4 million in the three months ended June 30,
2011 and 2010, respectively. These intangible assets are primarily as a result of our AMSC Windtec
acquisition.

[0000950123-11-086250:mdna:54]
Operating (loss) income

[0000950123-11-086250:mdna:55]
|  |  | Our operating (loss) income is summarized as follows (in thousands): |

[0000950123-11-086250:mdna:56]
|  |  | Three months ended |  |
|  |  | June 30, |  |
|  |  | 2011 |  |  | 2010 |  |
| Wind |  | $ | (24,370 | ) |  | $ | 31,339 |  |
| Grid |  |  | (10,552 | ) |  |  | (11,764 | ) |
| Unallocated corporate expenses |  |  | (3,405 | ) |  |  | (3,494 | ) |
| Total |  | $ | (38,327 | ) |  | $ | 16,081 |  |

[0000950123-11-086250:mdna:57]
Operating (loss) income for the Wind business unit decreased to an operating loss of
$24.4 million in the three months ended June 30, 2011, from an operating income of $31.3 million in
the three months ended June 30, 2010. The decrease in Wind business unit operating income was
primarily due to the disruption in our relationship with Sinovel, as described above.

[0000950123-11-086250:mdna:58]
Operating loss for the Grid business unit decreased to $10.6 million in the three months ended
June 30, 2011, compared to $11.8 million in the three months ended June 30, 2010. The decrease in
Grid business unit operating loss was primarily due to lower operating expenses as a result of the
reductions in force and reduced discretionary spending, partially offset by reduced DVAR revenues.

[0000950123-11-086250:mdna:59]
Unallocated corporate expenses also include stock-based compensation expense of $3.5 million
and $3.5 million for the three months ended June 30, 2011 and 2010, respectively.

[0000950123-11-086250:mdna:60]
Interest income, net

[0000950123-11-086250:mdna:61]
Interest income, net, was $0.2 million in the three months ended June 30, 2011 and 2010. Due
to recent economic conditions and the United States monetary policy intended to promote growth, the
yields of our interest bearing assets are low as compared to prior periods.

[0000950123-11-086250:mdna:62]
Other income, net

[0000950123-11-086250:mdna:63]
Other income, net, was income of $0.6 million in the three months ended June 30, 2011 compared
to income of $0.2 million for the three months ended June 30, 2010. The increase in other income,
net primarily relates to an increase in foreign currency translation gains of $0.9 million,
partially offset by an increase in losses on minority interest investments of $0.5 million.

[0000950123-11-086250:mdna:64]
[same as prior period, unchanged from 0000950123-11-008765:mdna:67]

[0000950123-11-086250:mdna:65]
In the three months ended June 30, 2011, we recorded income tax expense of $0.2 million
compared to $7.3 million in the three months ended June 30, 2010. Income tax expense decreased due
to the pretax loss in the three months ended June 30, 2011 and a full valuation allowance against
our deferred tax assets.

[0000950123-11-086250:mdna:66]
[same as prior period, unchanged from 0000950123-11-008765:mdna:69]

[0000950123-11-086250:mdna:67]
Generally, a non-GAAP financial measure is a numerical measure of a company’s performance,
financial position or cash flow that either excludes or includes amounts that are not normally
excluded or included in the most directly comparable measure calculated and presented in accordance
with GAAP. The non-GAAP measures included in this Form 10-Q, however, should be considered in
addition to, and not as a substitute for or superior to the comparable measure prepared in
accordance with GAAP.

[0000950123-11-086250:mdna:68]
We define non-GAAP net (loss) income as net (loss) income before amortization of
acquisition-related intangibles, restructuring and impairments, stock-based compensation, other
unusual charges and any tax effects related to these items.

[0000950123-11-086250:mdna:69]
We believe non-GAAP net (loss) income assists management and investors in comparing our
performance across reporting periods on a consistent basis by excluding these non-cash or
non-recurring charges that we do not believe are indicative of our core operating performance. We
also regard non-GAAP net (loss) income as a useful measure of operating performance which more
closely aligns net (loss) income with cash used in/provided by continuing operations. In addition,
we use non-GAAP net (loss) income as a factor in evaluating management’s performance when
determining incentive compensation and to evaluate the effectiveness of our business strategies. A
reconciliation of non-GAAP to GAAP net (loss) income is set forth in the table below (in thousands,
except per share data):

[0000950123-11-086250:mdna:70]
|  |  | Three months ended |  |
|  |  | June 30, |  |
|  |  | 2011 |  |  | 2010 |  |
| Net (loss) income |  | $ | (37,679 | ) |  | $ | 9,170 |  |
| Stock-based compensation |  |  | 3,466 |  |  |  | 3,499 |  |
| Severance costs |  |  | 2,066 |  |  |  | — |  |
| Losses on purchase commitments |  |  | 1,071 |  |  |  | — |  |
| Amortization of acquisition-related intangibles |  |  | 304 |  |  |  | 386 |  |
| Tax effects |  |  | — |  |  |  | (83 | ) |
| Non-GAAP net (loss) income |  | $ | (30,772 | ) |  | $ | 12,972 |  |
| Non-GAAP (loss) earnings per share |  | $ | (0.61 | ) |  | $ | 0.28 |  |
| Weighted average shares outstanding * |  |  | 50,710 |  |  |  | 45,983 |  |

[0000950123-11-086250:mdna:71]
| * |  | Diluted shares are used for periods where net income is generated. |

[0000950123-11-086250:mdna:72]
We incurred non-GAAP net loss of ($30.8) million, or ($0.61) per share, for the three
months ended June 30, 2011, compared to a non-GAAP net income of $13.0 million, or $0.28 per
diluted share, for the three months ended June 30, 2010. The decrease in non-GAAP net income was
driven primarily by a decrease in net income, partially offset by severance costs and losses on
purchase commitments.

[0000950123-11-086250:mdna:73]
[same as prior period, unchanged from 0000950123-11-008765:mdna:74]

[0000950123-11-086250:mdna:74]
At June 30, 2011, we had cash, cash equivalents, marketable securities and restricted cash of
$166.2 million, compared to $245.5 million at March 31, 2011, a decrease of $79.3 million. Our
cash and cash equivalents, marketable securities and restricted cash are summarized as follows (in
thousands):

[0000950123-11-086250:mdna:75]
|  |  | June 30, |  |  | March 31, |  |
|  |  | 2011 |  |  | 2011 |  |
| Cash and cash equivalents |  | $ | 130,885 |  |  | $ | 123,783 |  |
| Marketable securities |  |  | 25,894 |  |  |  | 116,126 |  |
| Restricted cash |  |  | 9,373 |  |  |  | 5,566 |  |
| Total cash, cash equivalents, marketable securities and restricted cash |  | $ | 166,152 |  |  | $ | 245,475 |  |

[0000950123-11-086250:mdna:76]
For the three months ended June 30, 2011, net cash used in operating activities was $57.8
million compared to $18.5 million in the three months ended June 30, 2010. The increase in net cash
used in operations is due primarily to a decrease in net income of $46.8 million, partially offset
by a decrease in cash used for working capital of $8.1 million

[0000950123-11-086250:mdna:77]
For the three months ended June 30, 2011, net cash provided by investing activities was $59.8
million compared to net cash used in investing activities of less than $0.1 million in the three
months ended June 30, 2010. The increase in net cash provided by investing activities for the three
months ended June 30, 2011 was driven primarily by an increase in net maturities and sales of
marketable securities of $81.7 million and a decrease in capital expenditures of $3.7 million,
partially offset by the $20.6 million advance payment to The Switch, an increase in restricted cash
of $4.0 million and an increase in purchased minority investments of $1.8 million.

[0000950123-11-086250:mdna:78]
For the three months ended June 30, 2011, net cash provided by financing activities was $4.4
million compared to $0.6 million in the three months ended June 30, 2010. The increase in net cash
provided by financing activities is primarily due to net borrowings on lines credit of $4.6
million, partially offset by payments in lieu of issuance of common stock for payroll taxes of $0.3
in the three months ended June 30, 2011.

[0000950123-11-086250:mdna:79]
As of June 30, 2011, we had nine performance bonds on behalf of AMSC Windtec and our
wholly-owned Chinese subsidiary, Suzhou AMSC Superconductor Co. Ltd (“AMSC China”), in support of
customer contracts to guarantee supply of core components and software. The total value of the
outstanding performance bonds is $2.3 million with various expiration dates through March 2014. In
the event that the payment is made in accordance with the requirements of any of these performance
bonds, we would record the payment as an offset to revenue.

[0000950123-11-086250:mdna:80]
At June 30, 2011 and March 31, 2011, we had $6.5 million and $5.6 million, respectively, of
restricted cash included in current assets. At June 30, 2011, we had $2.9 million of restricted
cash included in long term assets with various expiration dates through March 2014. These amounts
included in restricted cash represent deposits to secure letters of credit for various supply
contracts. These deposits are held in an interest bearing account. We had an additional $2.5
million in unsecured letters of credit, at June 30, 2011 and March 31, 2011, also in support of
various supply contracts.

[0000950123-11-086250:mdna:81]
We had unused, unsecured lines of credit consisting of RMB 114.8 million (approximately $17.8
million) in China and €1.6 million (approximately $2.3 million) in Austria as of June 30, 2011. In
July 2011, the Bank of China informed us that our unsecured credit line of approximately RMB 100.0
million (approximately $15.5 million), which expired in August 2011, would not be renewed. As of
June 30, 2011, we had net borrowings on lines of credit outstanding of $4.6 million.

[0000950123-11-086250:mdna:82]
At June 30, 2011, we had cash, cash equivalents, marketable securities and restricted cash of
$166.2 million. Our business plan anticipates a substantial decline in revenues and a substantial
use of cash from operations in our fiscal year ending March 31, 2012, particularly in light of the
difficult and uncertain current economic environment, the significant restructuring actions
undertaken and the uncertainty surrounding Sinovel and certain of our other customers in China. Our
plan includes a significant restructuring undertaken in August 2011, resulting in the elimination
of approximately 150 positions worldwide. Since April 1, 2011, we have eliminated approximately
30% of our workforce and we expect to save approximately $30 million annually as a result of these
reductions. Additional actions include further monitoring of our operating results against
expectations and, if required, further reducing operating costs and capital spending if events
warrant in order to enhance liquidity. Due to the disruption in our relationship with Sinovel, we
will need to raise additional capital in order to complete the planned acquisition of The Switch in
order to leave sufficient cash to fund our working capital, capital expenditures and other cash
requirements. We may seek this financing through public or private equity offerings, debt
financings, or other financing alternatives, however, there can be no assurance that financing will
be available on acceptable terms or at all. If we fail to raise sufficient additional funds and
terminate the purchase agreement for the acquisition of The Switch, we will likely forfeit the
$20.6 million cash advance payment we paid to the shareholders of The Switch on June 29, 2011. In
the event that we do not receive any additional payments from Sinovel and we neither complete the
planned acquisition of The Switch, nor raise additional capital, we believe that our available
cash, together with additional reductions in operating costs and capital expenditures as necessary
will be sufficient to fund our operations, capital expenditures and other cash requirements through
at least March 31 2012. Our long-term liquidity is dependent on our ability to profitably grow our
revenues or raise additional capital as required.

[0000950123-11-086250:mdna:83]
Between April 6, 2011 and April 29, 2011, six putative securities class action complaints were
filed against us and two of our officers in the United States District Court for the District of
Massachusetts. On May 12, 2011, an additional complaint was filed against us, our officers and
directors, and the underwriters who participated in our November 12, 2010 securities offering. On
June 7, 2011, the United States District Court for the District of Massachusetts consolidated these
actions under the caption Lenartz v. American Superconductor Corporation, et al. Docket No.
1:11-cv-10582-WGY. On June 16, 2011, the court appointed the law firm Robbins Geller Rudman & Dowd
LLP as Lead Counsel and the Plumbers and Pipefitters National Pension Fund as Lead Plaintiff.
On August 31, 2011, the Lead Plaintiff filed a consolidated amended complaint against us, our
officers and directors, and the underwriters who participated in our November 12, 2010 securities
offering, asserting claims under sections 10(b) and 20(a) of the Securities Exchange Act of 1934
and Rule 10b-5 promulgated under the Securities Exchange Act of 1934, as well as under sections 11,
12(a)(2) and 15 of the Securities Act of 1933. The complaint alleges that during the relevant
class period, we and our officers omitted to state material facts and made materially false and
misleading statements relating to, among other things, our projected and recognized revenues and
earnings, as well as our relationship with Sinovel Wind Group Co., Ltd. that artificially inflated
the value of our stock price. The complaint further alleges that our November 12, 2010 securities
offering contained untrue statements of material facts and omitted to state material facts required
to be stated therein. The plaintiffs seek unspecified damages, rescindment of our November 12, 2010
securities offering, and an award of costs and expenses, including attorney’s fees.

[0000950123-11-086250:mdna:84]
On April 27, 2011, a putative shareholder derivative complaint was filed against us (as a
nominal defendant) and each of our current directors in Superior Court for the Commonwealth of
Massachusetts, Worcester County. The case is captioned Segel v. Yurek, et al., Docket No. 11-0787.
Between May 4, 2011 and June 17, 2011, four additional putative shareholder derivative complaints
were filed in the United States District Court for the District of Massachusetts against us and
certain of our directors and officers. The cases are captioned Weakley v. Yurek, et al., Docket
No. 1:11-cv-10784; Marlborough Family

[0000950123-11-086250:mdna:85]
Revocable Trust v. Yurek, et al., Docket No. 1:11-cv-10825; Connors v. Yurek, et al., Docket
No. 1:11-cv-10910; and Hurd v. Yurek, et al., Docket No. 1:11-cv-11102. On June 1, 2011, the
plaintiff in Marlborough Family Revocable Trust v. Yurek, et al. moved to voluntarily dismiss its
complaint and refiled its complaint in Superior Court for the Commonwealth of Massachusetts,
Middlesex County, on June 3, 2011. The case is now captioned Marlborough Family Revocable Trust v.
Yurek, et al., Docket No. 11-1961. The Superior Court in Worcester County granted the plaintiff’s
motion to transfer in Segel v. Yurek et al. to the Superior Court for the Commonwealth of
Massachusetts, Middlesex County on June 23, 2011, and that matter is now captioned Segel v. Yurek
et al., Docket No. 11-2269. On July 5, 2011, the Weakley, Connors and Hurd actions were
consolidated in United States District Court for the District of Massachusetts. That matter is
now captioned In re American Superconductor Corporation Derivative Litigation, Docket No.
1:11-cv-10784. On June 1, 2011, the plaintiff in Marlborough Family Revocable Trust v. Yurek, et
al. moved to voluntarily dismiss its complaint and, on June 3, 2011, refiled its complaint in
Superior Court for the Commonwealth of Massachusetts, Middlesex County. The Superior Court in
Worcester County granted the plaintiff’s motion to transfer in Segel v. Yurek et al. to the
Superior Court for the Commonwealth of Massachusetts, Middlesex County on June 23, 2011. On
September 7, 2011, the Marlborough and Segel actions were consolidated in Superior Court for the
Commonwealth of Massachusetts, Middlesex County. The case is now captioned Marlborough Family
Revocable Trust v. Yurek, et al., Docket No. 11-1961. The allegations of the derivative complaints
mirror the allegations made in the putative class action complaints described above. The
plaintiffs purport to assert claims against the director defendants for breach of fiduciary duty,
abuse of control, gross mismanagement and corporate waste. The plaintiffs seek unspecified damages
on behalf of us, as well as an award of costs and expenses, including attorney’s fees.

[0000950123-11-086250:mdna:86]
If a matter is both probable to result in liability and the amounts of loss can be reasonably
estimated, we estimate and disclose the possible loss or range of loss. With respect to the above
referenced litigation matters, such an estimate cannot be made. There are numerous factors that
make it difficult to meaningfully estimate possible loss or range of loss at this stage of these
litigation matters, including that: the proceedings are in relatively early stages, there are
significant factual and legal issues to be resolved, information obtained or rulings made during
the lawsuits could affect the methodology for calculation of rescission and the related statutory
interest rate. In addition, with respect to claims where damages are the requested relief, no
amount of loss or damages has been specified. Therefore, we are unable at this time to estimate
possible losses. We believe that these litigations are without merit, and we intend to defend
these actions vigorously.

[0000950123-11-086250:mdna:87]
On September 13, 2011, we commenced a series of legal actions in China against Sinovel Wind
Group Co. Ltd. (“Sinovel”). Our Chinese subsidiary, Suzhou AMSC Superconductor Co. Ltd. (“AMSC
China”), filed a claim for arbitration with the Beijing Arbitration Commission in accordance with
the terms of our supply contracts with Sinovel. On March 31, 2011, Sinovel refused to accept
contracted shipments of 1.5 megawatt (MW) and 3 MW wind turbine core electrical components and
spare parts that we were prepared to deliver. We allege that these actions constitute material
breaches of our contracts because Sinovel did not give us notice that it intended to delay
deliveries as required under the contracts. Moreover, we allege that Sinovel has refused to pay
past due amounts for prior shipments of core electrical components and spare parts. We are seeking
compensation for past product shipments (including interest) and monetary damages due to Sinovel’s
breaches of our contracts. We are also seeking specific performance of our existing contracts as
well as reimbursement of all costs and reasonable expenses with respect to the arbitration.

[0000950123-11-086250:mdna:88]
We also submitted a civil action application to the Beijing No. 1 Intermediate People’s Court
against Sinovel for software copyright infringement. The application alleges Sinovel’s
unauthorized use of portions of our wind turbine control software source code developed for
Sinovel’s 1.5MW wind turbines and the binary code, or upper layer, of our software for the PM3000
power converters in 1.5MW wind turbines. In July 2011, a former employee of our AMSC Windtec GmbH
subsidiary was arrested in Austria and is currently awaiting trial on charges of economic espionage
and fraudulent manipulation of data. As a result of our internal investigation and a criminal
investigation conducted by Austrian authorities, we believe that this former employee was
contracted by Sinovel through an intermediary while employed by us and improperly obtained and
transferred to Sinovel portions of our wind turbine control software source code developed for
Sinovel’s 1.5MW wind turbines. Moreover, we believe the former employee illegally used source code
to develop for Sinovel a software modification to circumvent the encryption and remove technical
protection measures on the PM3000 power converters in 1.5MW wind turbines in the field. We are
seeking a cease and desist order with respect to the unauthorized copying, installation and use of
our software, monetary damages for our economic losses and reimbursement of all costs and
reasonable expenses. The court must accept the application in order for the case to proceed, and
there can be no assurance that the court will do so.

[0000950123-11-086250:mdna:89]
We submitted a civil action application to the Beijing Higher People’s Court against Sinovel
and certain of its employees for trade secret infringement. The application alleges the
defendants’ unauthorized use of portions of our wind turbine control software source code developed
for Sinovel’s 1.5MW wind turbines as described above with respect to the

[0000950123-11-086250:mdna:90]
30

[0000950123-11-086250:mdna:91]
Copyright Action. We are seeking monetary damages for the trade secret infringement as well as
reimbursement of all costs and reasonable expenses. The court must accept the application in order
for the case to proceed, and there can be no assurance that the court will do so.

[0000950123-11-086250:mdna:92]
On September 16, 2011, AMSC China filed a civil copyright infringement complaint in the Hainan
Province No. 1 Intermediate People’s Court against Dalian Guotong Electric Co. Ltd. (“Guotong”), a
supplier of power converter products to Sinovel, and Huaneng Hainan Power, Inc., a wind farm
operator that has purchased Sinovel wind turbines containing Goutong power converter products. The
application alleges that our PM1000 converters in certain Sinovel wind turbines have been replaced
by converters produced by Guotong. Because the Guotong converters are being used in wind turbines
containing our wind turbine control software, we believe that our copyrighted software is being
infringed. We are seeking a cease and desist order with respect to the unauthorized use of our
software, monetary damages for our economic losses (with respect to Guotong only) and reimbursement
of all costs and reasonable expenses.

[0000950123-11-086250:mdna:93]
[same as prior period, unchanged from 0000950123-11-008765:mdna:85]

[0000950123-11-086250:mdna:94]
[same as prior period, unchanged from 0000950123-11-008765:mdna:86]

[0000950123-11-086250:mdna:95]
We occasionally enter into construction contracts that include a performance bond. As these
contracts progress, we continually assess the probability of a payout from the performance bond.
Should we determine that such a payout is probable, we would record a liability.

[0000950123-11-086250:mdna:96]
[same as prior period, unchanged from 0000950123-11-008765:mdna:88]

[0000950123-11-086250:mdna:97]
Recent Accounting Pronouncements

[0000950123-11-086250:mdna:98]
In October 2009, the FASB issued Accounting Standards Update (ASU) No. 2009-13,
Multiple-Deliverable Revenue Arrangements, pertaining to the accounting for revenue arrangements
with multiple deliverables. Specifically, the new standard requires an entity to allocate
consideration at the inception of an arrangement to all of its deliverables based on their relative
selling prices. In the absence of the vendor-specific objective evidence or third-party evidence of
the selling prices, consideration must be allocated to the deliverables based on management’s best
estimate of the selling prices. In addition, the new standard eliminates the use of the residual
method of allocation. The new accounting standard supersedes the prior multiple element revenue
arrangement accounting rules that were previously used by us. We adopted this new accounting
standard on April 1, 2010 using the prospective method and the adoption did not have a material
impact on our consolidated financial statements.

[0000950123-11-086250:mdna:99]
In January 2010, we adopted Accounting Standards Update (ASU) No. 2010-06, Fair Value
Measurements and Disclosures (Topic 820): Improving Disclosures about Fair Value Measurements. This
standard amends the disclosure guidance with respect to fair value measurements for both interim
and annual reporting periods. Specifically, this standard requires new disclosures for significant
transfers of assets or liabilities between Level 1 and Level 2 in the fair value hierarchy;
separate disclosures for purchases, sales, issuance and settlements of Level 3 fair value items on
a gross, rather than net basis; and more robust disclosure of the valuation techniques and inputs
used to measure Level 2 and Level 3 assets and liabilities. We have included these new disclosures,
as applicable, in Note 3, “Marketable Securities and Fair Value Disclosures,” of our consolidated
financial statements.

[0000950123-11-086250:mdna:100]
In December 2010, the FASB issued Accounting Standards Update (ASU) No. 2010-29, Business
Combinations (Topic 805), Disclosure of Supplementary Pro forma Information for Business
Combinations a consensus of the FASB Emerging Issues Task Force (ASC 2010-29). This amendment
clarifies the periods for which pro forma financial information is presented. The disclosures
include pro forma revenue and earnings of the combined entity for the current reporting period as
though the acquisition date for all business combinations that occurred during the year had been as
of the beginning of the annual reporting period. If comparative financial statements are presented,
the pro forma revenue and earnings of the combined entity for the comparable prior reporting period
should be reported as though the acquisition date for all business combinations that occurred
during the current year had been as of the beginning of the comparable prior annual reporting
period. ASU 2010-29 is effective prospectively for business combinations that occur on or after
the beginning of the first annual reporting period beginning after December 15, 2010. We do not
expect the adoption of ASU 2011-04 to have a material impact on our consolidated results of
operations, financial condition, or cash flows.

[0000950123-11-086250:mdna:101]
In June 2011, the FASB issued Accounting Standards Update (ASU) No. 2011-05, Comprehensive
Income (Topic 220): Presentation of Comprehensive Income. ASU 2011-05 requires entities to present
net income and other comprehensive income in either a single continuous statement or in two
separate, but consecutive, statements of net income and other comprehensive income. ASU 2011-05 is
effective for fiscal years and interim periods beginning after December 15, 2011. We do not expect
the adoption of ASU 2011-04 to have a material impact on our consolidated results of operations,
financial condition, or cash flows.

[0000950123-11-086250:mdna:102]
32
