# AMSC notes — 0000950123-11-086250


## amsc:BusinessCombinationsPolicyPolicyTextBlock

[0000950123-11-086250:notes:1]
In December 2010, the FASB issued Accounting Standards Update (ASU) No. 2010-29, Business Combinations (Topic 805), Disclosure of Supplementary Pro forma Information for Business Combinations a consensus of the FASB Emerging Issues Task Force (ASC 2010-29). This amendment clarifies the periods for which pro forma financial information is presented. The disclosures include pro forma revenue and earnings of the combined entity for the current reporting period as though the acquisition date for all business combinations that occurred during the year had been as of the beginning of the annual reporting period. If comparative financial statements are presented, the pro forma revenue and earnings of the combined entity for the comparable prior reporting period should be reported as though the acquisition date for all business combinations that occurred during the current year had been as of the beginning of the comparable prior annual reporting period.  ASU 2010-29 is effective prospectively for business combinations that occur on or after the beginning of the first annual reporting period beginning after December 15, 2010. The Company does not expect the adoption of ASU 2011-04 to have a material impact on the Company's consolidated results of operations, financial condition, or cash flows.


## amsc:ChiefExecutiveOfficerTransitionTextBlock

[0000950123-11-086250:notes:2]
14.     Chief Executive Officer Transition

[0000950123-11-086250:notes:3]
On May 24, 2011, the Company announced that Daniel P. McGahn, President and Chief Operating Officer, has been appointed Chief Executive Officer and a member of the Board of Directors, effective June 1, 2011. Mr. McGahn succeeds Gregory J. Yurek, who resigned from his position as Chief Executive Officer of the Company, effective on June 1, 2011.  In connection with his retirement and resignation, the Company entered into a retirement and services agreement (the "Agreement") with Mr. Yurek pursuant to which Mr. Yurek will serve as a senior advisor to the Company for up to 24 months. The Agreement includes a general release of claims and customary non-compete and non-solicit covenants for the three-year period ending May 31, 2014. Pursuant to this agreement, Mr. Yurek is entitled to receive the following payments and benefits: (i) a total of $2.0 million in cash, of which $83,333 is payable on the final day of each month from June 2011 to August 2012, $50,000 is payable on the final day of September 2012, and $50,000 is payable on the final day of each month from April 2013 to May 2014; and (ii) continued group medical, dental and vision insurance coverage through May 31, 2014. In accordance with the terms of Mr. Yurek's outstanding stock option and restricted stock agreements, the outstanding restricted stock that is unvested as of June 1, 2011 will be forfeited and the outstanding stock options will continue to vest for so long as he continues to serve as an advisor to the Company. Thereafter, any remaining unvested portions of Mr. Yurek's stock options will be cancelled for no consideration.  Mr. Yurek agreed to remain as Chairman of the Board until the annual meeting of stockholders or August 15, 2011, whichever occurred first; and will not stand for reelection to the Board at the annual meeting. Mr. Yurek ceased serving as our Chairman of the Board on August 15, 2011.  The  Agreement replaces and supersedes the Amended and Restated Executive Severance Agreement, dated as of December 23, 2008, between the Company and Mr. Yurek.

[0000950123-11-086250:notes:4]
The Company recorded costs of $2.7 million within selling, general and administrative expenses of the unaudited condensed consolidated statements of operations for the three months ended June 30, 2011 which consist of $2.1 million severance benefits under the Agreement and $0.6 million of stock compensation expense related to outstanding stock options.


## amsc:ComprehensiveIncomePolicyPolicyTextBlock

[0000950123-11-086250:notes:5]
In June 2011, the FASB issued Accounting Standards Update (ASU) No. 2011-05, Comprehensive Income (Topic 220): Presentation of Comprehensive Income. ASU 2011-05 requires entities to present net income and other comprehensive income in either a single continuous statement or in two separate, but consecutive, statements of net income and other comprehensive income. ASU 2011-05 is effective for fiscal years and interim periods beginning after December 15, 2011. The Company does not expect the adoption of ASU 2011-04 to have a material impact on the Company's consolidated results of operations, financial condition, or cash flows.


## amsc:FairValueOfFinancialInstrumentsPolicyPolicyTextBlock

[0000950123-11-086250:notes:6]
In January 2010, the Company adopted Accounting Standards Update (ASU) No. 2010-06, Fair Value Measurements and Disclosures (Topic 820): Improving Disclosures about Fair Value Measurements. This standard amends the disclosure guidance with respect to fair value measurements for both interim and annual reporting periods. Specifically, this standard requires new disclosures for significant transfers of assets or liabilities between Level 1 and Level 2 in the fair value hierarchy; separate disclosures for purchases, sales, issuance and settlements of Level 3 fair value items on a gross, rather than net basis; and more robust disclosure of the valuation techniques and inputs used to measure Level 2 and Level 3 assets and liabilities. The Company has included these new disclosures, as applicable, in Note 3, "Marketable Securities and Fair Value Disclosures," of the consolidated financial statements.


## amsc:RecentAccountingPronouncementsTextBlock

[0000950123-11-086250:notes:7]
15.     Recent Accounting Pronouncements

[0000950123-11-086250:notes:8]
In October 2009, the FASB issued Accounting Standards Update (ASU) No. 2009-13, Multiple-Deliverable Revenue Arrangements, pertaining to the accounting for revenue arrangements with multiple deliverables.  Specifically, the new standard requires an entity to allocate consideration at the inception of an arrangement to all of its deliverables based on their relative selling prices. In the absence of the vendor-specific objective evidence or third-party evidence of the selling prices, consideration must be allocated to the deliverables based on management's best estimate of the selling prices. In addition, the new standard eliminates the use of the residual method of allocation. The new accounting standard supersedes the prior multiple element revenue arrangement accounting rules that were previously used by the Company.  The Company adopted this new accounting standard on April 1, 2010 using the prospective method and the adoption did not have a material impact on its consolidated financial statements.


## amsc:RestatementOfPriorYearIncomeTextBlock

[0000950123-11-086250:notes:9]
2.        Restatement of Fiscal 2010 Unaudited Condensed Consolidated Financial Statements

[0000950123-11-086250:notes:10]
The Company previously restated its unaudited condensed consolidated financial statements for the fiscal quarters ended September 30, 2010 and December 31, 2010 as reflected in amended Quarterly Reports on Form 10-Q for the applicable periods. The restatements related to the Company's determination that revenues were incorrectly recorded in the second quarter of fiscal 2010 for certain of the Company's customers in China as the fee was not fixed or determinable or collectability was not reasonably assured at the time of shipment. Further, as a result of aging receivables and other negative events surrounding the customer relationship, the Company concluded that revenue related to shipments to Sinovel was incorrectly recorded in the third quarter of fiscal 2010 as collectability was not reasonably assured at the time of shipments. For Sinovel and certain other customers in China, the Company has restated revenues based on a cash basis of accounting with cash applied first against accounts receivable balances, as in the case of Sinovel as of September 30, 2010, then costs of shipments (inventory and value added taxes) before recognizing any gross margin. For certain Chinese customers other than Sinovel, the Company has determined that this method of accounting should have been applied for shipments after August 31, 2010.  For Sinovel, the Company has determined that this method of accounting should have been applied for shipments after September 30, 2010. The Company had previously recognized revenues in the quarters ended September 30, 2010 and December 31, 2010 based on the receipt of shipments by these customers but prior to the Company's receipt of payment for such shipments.

[0000950123-11-086250:notes:11]
In connection with the errors identified by the Company resulting in the restatement of the Company's unaudited condensed consolidated financial statements for the quarterly periods ending September 30, 2010 and December 31, 2010, the Company identified control deficiencies in its internal controls that constitute material weaknesses. The deficiencies center on its controls over its revenue and accounts receivable balances, as fees were not fixed or determinable or collectability was not reasonably assured at the time revenue was recognized. As a result of these deficiencies, the Company determined that its disclosure controls and procedures were ineffective as of September 30, 2010, December 31, 2010, March 31, 2011, and June 30, 2011.


## amsc:ScheduleOfAccountsReceivableTextBlock

[0000950123-11-086250:notes:12]
|  | June 30, | March 31, |
| 2011 | 2011 |
| Accounts receivable (billed) | $8,593 | $12,912 |
| Accounts receivable (unbilled) | 3,747 | 5,004 |
| Less: Allowance for doubtful accounts | (688) | (683) |
| Accounts receivable, net | $11,652 | $17,233 |


## amsc:ScheduleOfBusinessSegmentAssetsTextBlock

[0000950123-11-086250:notes:13]
|  | June 30, |  | March 31, |
| 2011 |  | 2011 |
| Wind | $127,360 |  | $145,464 |
| Grid | 64,252 |  | 67,081 |
| Corporate assets | 202,050 |  | 228,664 |
| Total | $393,662 |  | $441,209 |


## amsc:ScheduleOfBusinessSegmentOperatingResultsTextBlock

[0000950123-11-086250:notes:14]
|  | Three months ended |
| June 30, |
|  | 2011 |  | 2010 |
| Revenues: |  |  |  |
| Wind | $4,262 |  | $83,006 |
| Grid | 4,796 |  | 14,203 |
| Total | $9,058 |  | $97,209 |
| Three months ended |
| June 30, |
|  | 2011 |  | 2010 |
| Operating (loss) income: |  |  |  |
| Wind | ($24,370) |  | $31,339 |
| Grid | (10,552) |  | (11,764) |
| Unallocated corporate expenses | (3,405) |  | (3,494) |
| Total | ($38,327) |  | $16,081 |


## amsc:ScheduleOfEarningsPerShareBasicAndDilutedTextBlock

[0000950123-11-086250:notes:15]
|  |  | Three months ended June 30, |
|  |  | 2011 |  | 2010 |
| Numerator: |  |  |  |
|  | Net (loss) income | $ (37,679) |  | $ 9,170 |
| Denominator: |  |  |  |
|  | Weighted-average shares of common stock outstanding | 51,172 |  | 45,454 |
|  | Weighted-average shares subject to repurchase | (463) |  | (212) |
| Shares used in per-share calculation — basic | 50,709 |  | 45,242 |
|  | Dilutive effect of employee equity incentive plans | - |  | 741 |
| Shares used in per-share calculation — diluted | 50,709 |  | 45,983 |
| Net (loss) income per share — basic | $ (0.74) |  | $ 0.20 |
| Net (loss) income per share — diluted | $ (0.74) |  | $ 0.20 |


## amsc:ScheduleOfInventoryCurrentTableTextBlock

[0000950123-11-086250:notes:16]
|  | June 30, | March 31, |
|  | 2011 | 2011 |
| Raw materials | $19,800 | $17,100 |
| Work-in-process | 4,423 | 2,432 |
| Finished goods | 4,413 | 3,915 |
| Deferred program costs | 2,432 | 2,381 |
| Net inventory | $31,068 | $25,828 |


## amsc:ScheduleOfProductWarrantyLiabilityTableTextBlock

[0000950123-11-086250:notes:17]
|  | Three months ended |
|  | June 30, |  |
|  | 2011 | 2010 |
| Balance at beginning of period | $7,907 | $6,431 |
| Accruals for warranties during the period | (405) | 2,305 |
| Settlements during the period | (168) | (2,361) |
| Balance at end of period | $7,334 | $6,375 |


## amsc:ScheduleOfRevenueByMajorCustomersByReportingSegmentsTableTextBlock

[0000950123-11-086250:notes:18]
|  |  | Three months ended June 30, |  |
|  |  | 2011 |  | 2010 |  |
| Department of Energy |  | 17% |  | <10% |  |
| Doosan Heavy Industries & Construction Co Ltd. |  | 15% |  | <10% |  |
| Shenyang Blower Works Group Wind Power Co.,Ltd. |  | 13% |  | <10% |  |
| Sinovel Wind Co., Ltd |  | -% |  | 72% |  |


## amsc:ScheduleOfStockBasedCompensationExpensesIncludedInConsolidatedStatementOfIncomeTextBlock

[0000950123-11-086250:notes:19]
|  | Three months ended |
|  | June 30, |
|  | 2011 | 2010 |
| Cost of revenues | $329 | $383 |
| Research and development | 660 | 468 |
| Selling, general and administrative | 2,477 | 2,727 |
| Total | $3,466 | $3,578 |


## amsc:ScheduleOfWeightedAverageAssumptionsUsedInBlackScholesValuationModelForStockOptionsGrantedTextBlock

[0000950123-11-086250:notes:20]
|  | Three months ended |
|  | June 30, |
|  | 2011 | 2010 |
| Expected volatility | 67.5% | 66.4% |
| Risk-free interest rate | 1.9% | 2.2% |
| Expected life (years) | 5.9 | 6.1 |
| Dividend yield | None | None |


## amsc:SubsequentEventsTextBlock

[0000950123-11-086250:notes:21]
16.     Subsequent Events

[0000950123-11-086250:notes:22]
The Company has performed an evaluation of subsequent events through the time of filing this Quarterly Report on Form 10-Q with the SEC.

[0000950123-11-086250:notes:23]
NASDAQ Notices

[0000950123-11-086250:notes:24]
On June 17, 2011, the Company received notice from the NASDAQ Stock Market ("NASDAQ") stating that the Company is not in compliance with Listing Rule 5250(c)(1) for continued listing due to the Company's inability to file with the SEC the Company's Annual Report on Form 10-K for the year ended March 31, 2011 (the "Initial Delinquent Filing") on a timely basis. The notification was issued in accordance with standard NASDAQ procedures and has no immediate effect on the listing or trading of the Company's common stock on the NASDAQ Global Select Market. On August 16, 2011, the Company received notice from the NASDAQ stating that the Company is not in compliance with Listing Rule 5250(c)(1) for continued listing (i) due to the Company's inability to file with the SEC the Company's Quarterly Report on Form 10-Q for the period ended June 30, 2011, and (ii) because the Company remained delinquent in filing the Company's Annual Report on Form 10-K for the period ended March 31, 2011. The notification was issued in accordance with standard NASDAQ procedures and had no immediate effect on the listing or trading of the Company's common stock on the NASDAQ Global Select Market.  Pursuant to NASDAQ's letter dated June 17, 2011, which was disclosed in the Company's Current Report on Form 8-K filed with the SEC on June 21, 2011, the Company had until August 16, 2011 to submit a plan to regain compliance with respect to the Initial Delinquent Filing. The NASDAQ letter dated August 16, 2011 indicated that the Company had until August 30, 2011 to submit an updated plan explaining how it expected to regain compliance. On August 16, 2011, the Company submitted its plan to regain compliance. On August 31, 2011, the Company was informed that NASDAQ had granted an exception to its rules to enable the Company to regain compliance by September 30, 2011.  With the filing of the Quarterly Report on Form 10-Q for the quarter ended June 30, 2011, the Annual Report on Form 10-K for the year ended March 31, 2011 and the Amended Quarterly Reports on Form 10-Q as of and for the quarters ended September 30, 2010 and December 31, 2010 and subject to receipt of a confirmation of compliance, the Company will be in compliance with the NASDAQ listing requirements.

[0000950123-11-086250:notes:25]
Restructuring

[0000950123-11-086250:notes:26]
The Company initiated a restructuring plan in August 2011 (the "2011 Plan") to reorganize global operations, streamline various functions of the business, and reduce its global workforce to match the demand for its products. The 2011 Plan resulted in a headcount reduction of approximately 150 employees.  Coinciding with the 2011 Plan, on August 8, 2011, the Company and Charles W. Stankiewicz, Executive Vice President, Operations and Grid Segment, and Angelo R. Santamaria, Senior Vice President, Global Manufacturing Operations, mutually agreed to end their employment effective on August 23, 2011 and August 12, 2011, respectively. From April 1, 2011 through the date of this filing, the Company has reduced its global workforce by approximately 30%, which is expected to result in annual savings of approximately $30.0 million.  As a result of the 2011 Plan, the Company expects to recognize restructuring charges of $3.0 million to $4.0 million in the second quarter of fiscal 2011. These charges primarily relate to severance costs and are expected to be paid through fiscal 2012.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0000950123-11-086250:notes:27]
13.     Planned Acquisition of "The Switch"

[0000950123-11-086250:notes:28]
On March 12, 2011, the Company entered into a Share Purchase Agreement (the "Agreement"), by and among the Company and the shareholders of The Switch Engineering Oy, a power technologies company headquartered in Finland ("The Switch").

[0000950123-11-086250:notes:29]
On June 29, 2011, the Company entered into an amendment agreement (the "Amendment"), by and among the Company and the shareholders (the "Shareholders") of The Switch, amending the Agreement. Pursuant to the Agreement, as amended by the Amendment, the Company has agreed to acquire all of the outstanding shares of The Switch for an aggregate purchase price (based on an exchange rate of $1.44 per Euro) of (i) $273.6 million, payable as follows: (1) $20.6 million in cash in the form of an advance payment (the "Advance Payment"), which was paid on June 29, 2011 and is classified as advance payment for planned acquisition on the unaudited condensed consolidated balance sheet as of June 30, 2011, (2) $171.0 million in cash at the closing of the acquisition and (3) the issuance at the closing of the acquisition shares of our common stock, $0.01 par value per share, with a value of $82.1 million based on the average closing price of the common stock during the 20 trading days preceding the second business day prior to the closing of the acquisition and the U.S. dollar to euro exchange rate on the second business day prior to the closing of the acquisition, and (ii) in the event closing occurs after September 1, 2011, interest at an annual rate of 4% on $171.0 million, accruing from September 1, 2011 to and including the closing date, payable in cash at the closing of the acquisition. In the event that the total number of shares of common stock issuable to the shareholders of The Switch exceeds 19.9% of the total number of shares of common stock outstanding prior to such issuance, in lieu of the issuance of such excess shares, the Company agreed to pay additional cash at the closing to the Minor Sellers (as defined in the Agreement) and issue to the remaining shareholders unsecured promissory notes for such excess amount, payable on the first business day after the first anniversary of the closing date.

[0000950123-11-086250:notes:30]
Pursuant to the Amendment, the parties agreed that the escrow would terminate on June 10, 2012 rather than twelve months after the closing date. The parties also agreed that the closing would take place on the tenth business day after the date on which the Company informs the Shareholders that a financing resulting in post-acquisition net cash available to the Company of at least $100 million has been completed, provided that all other closing conditions have been satisfied or waived. In addition, pursuant to the Amendment, the parties agreed that the Advance Payment shall constitute a termination fee payable to the Shareholders in the event the Agreement, as amended by the Amendment, is terminated should the closing not take place on or before September 30, 2011 (subject to extension for up to two one-month periods, as described in Section 6.6), or 10 business days thereafter in the case of a breach and/or failure to remedy by the Shareholders under Section 6.3.1, (i) by the Shareholders pursuant to Section 6.6(i), or (ii) the Company pursuant to Section 6.6(ii) (which, in the case of Sections 6.6(i) and 6.6(ii), includes upon the occurrence of a Failed Financing Event (as defined in the Amendment) and, in the case of Section 6.6(ii), upon the occurrence of a Material Adverse Effect (as defined in the Share Purchase Agreement)). Upon any such termination and retention by the Shareholders of the Advance Payment, the parties shall have no right to make any further claims against each other.

[0000950123-11-086250:notes:31]
The Company will require proceeds from an additional financing to finance the planned acquisition of The Switch. Closing of the transaction, which has been approved by both companies' Boards of Directors, is subject to customary closing conditions.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000950123-11-086250:notes:32]
10.     Commitments and Contingencies

[0000950123-11-086250:notes:33]
Commitments

[0000950123-11-086250:notes:34]
The Company periodically enters into non-cancelable purchase contracts in order to ensure the availability of materials to support production of its products.  Purchase commitments represent enforceable and legally binding agreements with suppliers to purchase goods or services. Any commitments for products ordered but not yet received is included as purchase commitments in its contractual obligations table.  The Company periodically assesses the need to provide for impairment on these purchase contracts and record a loss on purchase commitments when required.  As of June 30, 2011, the Company has $40.3 million of adverse purchase commitments in excess of its estimated future demand from certain of its customers in China, which the Company has recorded as a liability.  During three months ended June 30, 2011, the Company recorded losses of $1.1 million to cost of revenues as a result of commitments to purchase materials that were in excess of its estimated future demand from certain of its customers in China.

[0000950123-11-086250:notes:35]
Contingencies

[0000950123-11-086250:notes:36]
From time to time, the Company is involved in legal and administrative proceedings and claims of various types.  The Company records a liability in its consolidated financial statements for these matters when a loss is known or considered probable and the amount can be reasonably estimated. The Company reviews these estimates each accounting period as additional information is known and adjusts the loss provision when appropriate. If the loss is not probable or cannot be reasonably estimated, a liability is not recorded in its consolidated financial statements.

[0000950123-11-086250:notes:37]
Between April 6, 2011 and April 29, 2011, six putative securities class action complaints were filed against the Company and two of its officers in the United States District Court for the District of Massachusetts.  On May 12, 2011, an additional complaint was filed against the Company, its officers and directors, and the underwriters who participated in the Company's November 12, 2010 securities offering.  On June 7, 2011, the United States District Court for the District of Massachusetts consolidated these actions under the caption Lenartz v. American Superconductor Corporation, et al. Docket No. 1:11-cv-10582-WGY.  On June 16, 2011, the court appointed the law firm Robbins Geller Rudman & Dowd LLP as Lead Counsel and the Plumbers and Pipefitters National Pension Fund as Lead Plaintiff.  On August 31, 2011, the Lead Plaintiff filed a consolidated amended complaint against the Company, its officers and directors, and the underwriters who participated in the Company's November 12, 2010 securities offering, asserting claims under sections 10(b) and 20(a) of the Securities Exchange Act of 1934 and Rule 10b-5 promulgated under the Securities Exchange Act of 1934, as well as under sections 11, 12(a)(2) and 15 of the Securities Act of 1933.  The complaint alleges that during the relevant class period, the Company and its officers omitted to state material facts and made materially false and misleading statements relating to, among other things, the Company's projected and recognized revenues and earnings, as well as the Company's relationship with Sinovel Wind Group Co., Ltd. that artificially inflated the value of the Company's stock price.  The complaint further alleges that the Company's November 12, 2010 securities offering contained untrue statements of material facts and omitted to state material facts required to be stated therein. The plaintiffs seek unspecified damages, rescindment of the Company's November 12, 2010 securities offering, and an award of costs and expenses, including attorney's fees.

[0000950123-11-086250:notes:38]
On April 27, 2011, a putative shareholder derivative complaint was filed against the Company (as a nominal defendant) and each of its current directors in Superior Court for the Commonwealth of Massachusetts, Worcester County.  The case is captioned Segel v. Yurek, et al., Docket No. 11-0787.  Between May 4, 2011 and June 17, 2011, four additional putative shareholder derivative complaints were filed in the United States District Court for the District of Massachusetts against the Company and certain of its directors and officers.  The cases are captioned Weakley v. Yurek, et al., Docket No. 1:11-cv-10784; Marlborough Family Revocable Trust v. Yurek, et al., Docket No. 1:11-cv-10825; Connors v. Yurek, et al., Docket No. 1:11-cv-10910; and Hurd v. Yurek, et al., Docket No. 1:11-cv-11102.  On June 1, 2011, the plaintiff in Marlborough Family Revocable Trust v. Yurek, et al. moved to voluntarily dismiss its complaint and refiled its complaint in Superior Court for the Commonwealth of Massachusetts, Middlesex County, on June 3, 2011.  The case is now captioned Marlborough Family Revocable Trust v. Yurek, et al., Docket No. 11-1961.  The Superior Court in Worcester County granted the plaintiff's motion to transfer in Segel v. Yurek et al. to the Superior Court for the Commonwealth of Massachusetts, Middlesex County on June 23, 2011, and that matter is now captioned Segel v. Yurek et al., Docket No. 11-2269.   On July 5, 2011, the Weakley, Connors and Hurd actions were consolidated in United States District Court for the District of Massachusetts.   That matter is now captioned In re American Superconductor Corporation Derivative Litigation, Docket No. 1:11-cv-10784.  On June 1, 2011, the plaintiff in Marlborough Family Revocable Trust v. Yurek, et al. moved to voluntarily dismiss its complaint and, on June 3, 2011, refiled its complaint in Superior Court for the Commonwealth of Massachusetts, Middlesex County.  The Superior Court in Worcester County granted the plaintiff's motion to transfer in Segel v. Yurek et al. to the Superior Court for the Commonwealth of Massachusetts, Middlesex County on June 23, 2011.   On September 7, 2011, the Marlborough and Segel actions were consolidated in Superior Court for the Commonwealth of Massachusetts, Middlesex County.  The case is now captioned Marlborough Family Revocable Trust v. Yurek, et al., Docket No. 11-1961.  The allegations of the derivative complaints mirror the allegations made in the putative class action complaints described above.  The plaintiffs purport to assert claims against the director defendants for breach of fiduciary duty, abuse of control, gross mismanagement and corporate waste.  The plaintiffs seek unspecified damages on behalf of the Company, as well as an award of costs and expenses, including attorney's fees.

[0000950123-11-086250:notes:39]
If a matter is both probable to result in liability and the amounts of loss can be reasonably estimated, the Company estimates and discloses the possible loss or range of loss. With respect to the above referenced litigation matters, such an estimate cannot be made. There are numerous factors that make it difficult to meaningfully estimate possible loss or range of loss at this stage of these litigation matters, including that: the proceedings are in relatively early stages, there are significant factual and legal issues to be resolved, information obtained or rulings made during the lawsuits could affect the methodology for calculation of rescission and the related statutory interest rate. In addition, with respect to claims where damages are the requested relief, no amount of loss or damages has been specified. Therefore, the Company is unable at this time to estimate possible losses.  The Company believes that these litigations are without merit, and it intends to defend these actions vigorously.

[0000950123-11-086250:notes:40]
On September 13, 2011, the Company commenced a series of legal actions in China against Sinovel Wind Group Co. Ltd. ("Sinovel").  The Company's Chinese subsidiary, Suzhou AMSC Superconductor Co. Ltd. ("AMSC China"), filed a claim for arbitration with the Beijing Arbitration Commission in accordance with the terms of the Company's supply contracts with Sinovel. On March 31, 2011, Sinovel refused to accept contracted shipments of 1.5 megawatt (MW) and 3 MW wind turbine core electrical components and spare parts that the Company was prepared to deliver. The Company alleges that these actions constitute material breaches of its contracts because Sinovel did not give the Company notice that it intended to delay deliveries as required under the contracts. Moreover, the Company alleges that Sinovel has refused to pay past due amounts for prior shipments of core electrical components and spare parts. The Company is seeking compensation for past product shipments (including interest) and monetary damages due to Sinovel's breaches of its contracts. The Company is also seeking specific performance of our existing contracts as well as reimbursement of all costs and reasonable expenses with respect to the arbitration.

[0000950123-11-086250:notes:41]
The Company also submitted a civil action application to the Beijing No. 1 Intermediate People's Court against Sinovel for software copyright infringement.  The application alleges Sinovel's unauthorized use of portions of the Company's wind turbine control software source code developed for Sinovel's 1.5MW wind turbines and the binary code, or upper layer, of the Company's software for the PM3000 power converters in 1.5MW wind turbines. In July 2011, a former employee of the Company's AMSC Windtec GmbH subsidiary was arrested in Austria and is currently awaiting trial on charges of economic espionage and fraudulent manipulation of data. As a result of the Company's internal investigation and a criminal investigation conducted by Austrian authorities, the Company believes that this former employee was contracted by Sinovel through an intermediary while employed by the Company and improperly obtained and transferred to Sinovel portions of its wind turbine control software source code developed for Sinovel's 1.5MW wind turbines. Moreover, the Company believes that the former employee illegally used source code to develop for Sinovel a software modification to circumvent the encryption and remove technical protection measures on the PM3000 power converters in 1.5MW wind turbines in the field.  The Company is seeking a cease and desist order with respect to the unauthorized copying, installation and use of its software, monetary damages for our economic losses and reimbursement of all costs and reasonable expenses.  The court must accept the application in order for the case to proceed, and there can be no assurance that the court will do so.

[0000950123-11-086250:notes:42]
The Company submitted a civil action application to the Beijing Higher People's Court against Sinovel and certain of its employees for trade secret infringement.  The application alleges the defendants' unauthorized use of portions of the Company's wind turbine control software source code developed for Sinovel's 1.5MW wind turbines as described above with respect to the Copyright Action. The Company is seeking monetary damages for the trade secret infringement as well as reimbursement of all costs and reasonable expenses.  The court must accept the application in order for the case to proceed, and there can be no assurance that the court will do so.

[0000950123-11-086250:notes:43]
On September 16, 2011, the Company filed a civil copyright infringement complaint in the Hainan Province No. 1 Intermediate People's Court against Dalian Guotong Electric Co. Ltd. ("Guotong"), a supplier of power converter products to Sinovel, and Huaneng Hainan Power, Inc., a wind farm operator that has purchased Sinovel wind turbines containing Goutong power converter products.  The application alleges that the Company's PM1000 converters in certain Sinovel wind turbines have been replaced by converters produced by Guotong. Because the Guotong converters are being used in wind turbines containing its wind turbine control software, the Company believes that its copyrighted software is being infringed.  The Company is seeking a cease and desist order with respect to the unauthorized use of its software, monetary damages for its economic losses (with respect to Guotong only) and reimbursement of all costs and reasonable expenses.

[0000950123-11-086250:notes:44]
Other

[0000950123-11-086250:notes:45]
The Company enters into long-term construction contracts with customers that require the Company to obtain performance bonds. The Company is required to deposit an amount equivalent to some or all the face amount of the performance bonds into an escrow account until the termination of the bond. When the performance conditions are met, amounts deposited as collateral for the performance bonds are returned to the Company. In addition, the Company has various contractual arrangements in which minimum quantities of goods or services have been committed to be purchased on an annual basis.

[0000950123-11-086250:notes:46]
As of June 30, 2011, the Company had nine performance bonds on behalf of AMSC Windtec and its wholly-owned Chinese subsidiary, Suzhou AMSC Superconductor Co. Ltd ("AMSC China"), in support of customer contracts to guarantee supply of core components and software. The total value of the outstanding performance bonds is $2.3 million with various expiration dates through March 2014.  In the event that the payment is made in accordance with the requirements of any of these performance bonds, the Company would record the payment as an offset to revenue.

[0000950123-11-086250:notes:47]
At June 30, 2011, the Company had $6.5 million of restricted cash included in current assets. At June 30, 2011, the Company had $2.9 million of restricted cash included in long term assets with various expiration dates through March 2014. These amounts included in restricted cash represent deposits to secure letters of credit for various supply contracts. These deposits are held in an interest bearing account. The Company had an additional $2.5 million in unsecured letters of credit at June 30, 2011 in support of various supply contracts.

[0000950123-11-086250:notes:48]
The Company had unused, unsecured lines of credit consisting of RMB 114.8 million (approximately $17.8 million) in China and €1.6 million (approximately $2.3 million) in Austria as of June 30, 2011.  In July 2011, the Bank of China informed the Company that its unsecured credit line of approximately RMB 100.0 million (approximately $15.5 million), which expired in August 2011, would not be renewed. As of June 30, 2011, the Company had net borrowings on lines of credit outstanding of $4.6 million.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000950123-11-086250:notes:49]
3.        Stock-Based Compensation
                     The Company accounts for its stock-based compensation at fair value. The following table summarizes stock-based compensation expense by financial statement line item for the three months ended June 30, 2011 and 2010 (in thousands):

[0000950123-11-086250:notes:50]
During the three months ended June 30, 2011, the Company granted approximately 634,000 and 213,000 shares of stock options and restricted stock, respectively, to employees under the 2007 Stock Incentive Plan. The restricted stock granted during the three months ended June 30, 2011 includes approximately 5,000 shares of performance-based restricted stock, which will vest upon achievement of certain financial performance measurements. At June 30, 2011, the Company determined that achievement of the performance measures are probable and as such, will recognize the fair value of the performance based awards over the estimated period of each award.  The remaining shares granted vest upon the passage of time, generally 3 years. For awards that vest upon the passage of time, expense is being recorded over the vesting period.

[0000950123-11-086250:notes:51]
In connection with the vesting of certain restricted stock awards issued to certain executive officers of the Company, these employees paid withholding taxes due by returning 23,861 shares valued at $0.3 million. The Company has recorded these shares as treasury stock as of June 30, 2011.

[0000950123-11-086250:notes:52]
The estimated fair value of the Company's stock-based awards, less expected annual forfeitures, is amortized over the awards' service period. The total unrecognized compensation cost for unvested outstanding stock options was $12.6 million for the three months ended June 30, 2011. This expense will be recognized over a weighted average expense period of approximately 2.6 years.  The total unrecognized compensation cost for unvested outstanding restricted stock was $6.5 million for the three months ended June 30, 2011. This expense will be recognized over a weighted average expense period of approximately 2.3 years.

[0000950123-11-086250:notes:53]
The weighted-average assumptions used in the Black-Scholes valuation model for stock options granted during the three months ended June 30, 2011 and 2010 are as follows:

[0000950123-11-086250:notes:54]
The expected volatility rate was estimated based on an equal weighting of the historical volatility of the Company's common stock and the implied volatility of the Company's traded options. The expected term was estimated based on an analysis of the Company's historical experience of exercise, cancellation, and expiration patterns. The risk-free interest rate is based on the average of the five and seven year U.S. Treasury rates.

[0000950123-11-086250:notes:55]
The Company recorded $0.6 million of stock compensation expense in the three months ended June 30, 2011 related to outstanding stock options of the former Chief Executive Officer as discussed in Note 14, "Chief Executive Officer Transition."


## us-gaap:EarningsPerShareTextBlock

[0000950123-11-086250:notes:56]
4.        Computation of Net (Loss) Income per Common Share

[0000950123-11-086250:notes:57]
Basic net (loss) income per share ("EPS") is computed by dividing net (loss) income by the weighted-average number of common shares outstanding for the period. Where applicable, diluted EPS is computed by dividing the net (loss) income by the weighted-average number of common shares and dilutive common equivalent shares outstanding during the period, calculated using the treasury stock method. Common equivalent shares include the effect of restricted stock, exercise of stock options and warrants and contingently issuable shares. For the three months ended June 30, 2011 and 2010, common equivalent shares of 3.0 million shares and 1.4 million shares, respectively, were not included in the calculation of diluted EPS as they were considered anti-dilutive.

[0000950123-11-086250:notes:58]
The following table reconciles the numerators and denominators of the earnings per share calculation for the three months ended June 30, 2011 and 2010 (in thousands, except per share data):


## us-gaap:EquityMethodInvestmentsDisclosureTextBlock

[0000950123-11-086250:notes:59]
11.          Equity Investments

[0000950123-11-086250:notes:60]
Investment in Tres Amigas

[0000950123-11-086250:notes:61]
On October 9, 2009, the Company made an investment in Tres Amigas LLC, ("Tres Amigas"), a merchant transmission company, for $1.8 million, consisting of $0.8 million in cash and $1.0 million in AMSC common stock. On January 6, 2011 and May 20, 2011, the Company increased its minority position in Tres Amigas by an additional $1.8 million on each date. As of June 30, 2011, the Company holds a 37% ownership interest.

[0000950123-11-086250:notes:62]
The Company has determined that Tres Amigas is a variable interest entity ("VIE") and that the Company is not the primary beneficiary of the VIE. Therefore, the Company has not consolidated Tres Amigas as of June 30, 2011. The investment is carried at the acquisition cost, plus the Company's equity in undistributed earnings or losses. The Company's maximum exposure to loss is limited to the Company's recorded investment in this VIE. The Company's investment in Tres Amigas is included in other assets on the consolidated balance sheet and the equity in undistributed losses of Tres Amigas is included in other income (expense), net, on the consolidated statements of operations.

[0000950123-11-086250:notes:63]
The net investment activity for the three months ended June 30, 2011 is as follows (in thousands):

[0000950123-11-086250:notes:64]
| Balance at April 1, 2011 |  | $ | 3,026 |  |
| Purchase of minority investment |  |  | 1,800 |  |
| Minority interest in net losses |  |  | (191) |  |
| Balance at June 30, 2011 |  | $ | 4,635 |  |

[0000950123-11-086250:notes:65]
Investment in Blade Dynamics Ltd.

[0000950123-11-086250:notes:66]
On August 12, 2010, the Company acquired (through AMSC Windtec), a minority ownership position in Blade Dynamics Ltd. ("Blade Dynamics"), a designer and manufacturer of advanced wind turbine blades based on proprietary materials and structural technologies, for $8.0 million in cash.  The Company uses the equity method of accounting for this investment since it does not have a controlling ownership interest in the operating and financial policies of Blade Dynamics.  As such, the investment is carried at the acquisition cost, plus the Company's equity in undistributed earnings or losses. The Company's investment is included in other assets on the unaudited condensed consolidated balance sheet and the minority interest in net losses of Blade Dynamics is included in other income (expense), net, on the unaudited condensed consolidated statements of operations.  As of June 30, 2011, the Company holds a 25% ownership interest. The net investment activity for the three months ended June 30, 2011 is as follows (in thousands):

[0000950123-11-086250:notes:67]
| Balance at April 1, 2011 |  | $ | 7,903 |  |
| Minority interest in net losses |  |  | (426) |  |
| Net foreign exchange rate impact |  |  | 164 |  |
| Balance at June 30, 2011 |  | $ | 7,641 |  |


## us-gaap:FairValueAssetsAndLiabilitiesMeasuredOnRecurringBasisGainLossIncludedInEarningsTextBlock

[0000950123-11-086250:notes:68]
|  | TotalCarryingValue | Quoted Prices inActive Markets(Level 1) | Using Significant OtherObservable Inputs(Level 2) | Using SignificantUnobservable Inputs(Level 3) |
| June 30, 2011: |  |  |  |  |
| Assets: |  |  |  |  |
| Cash equivalents | $ 99,546 | $ 99,546 | $ — | $ — |
| Short-term commercial paper | 5,373 | — | 5,373 | — |
| Short-term government-backed securities.. | 20,521 | — | 20,521 | — |
|  | TotalCarryingValue | Quoted Prices inActive Markets(Level 1) | Using Significant OtherObservable Inputs(Level 2) | Using SignificantUnobservable Inputs(Level 3) |
| March 31, 2011: |  |  |  |  |
| Assets: |  |  |  |  |
| Cash equivalents | $ 49,837 | $ 49,837 | $ — | $ — |
| Short-term government-backed securities | 76,371 | — | 76,371 | — |
| Short-term commercial paper | 39,755 | — | 39,755 | — |
| Derivatives | 3,087 | — | 3,087 | — |


## us-gaap:FairValueDisclosuresTextBlock

[0000950123-11-086250:notes:69]
5.             Fair Value Measurements

[0000950123-11-086250:notes:70]
In January 2010, the Financial Accounting Standards Board ("FASB") issued guidance related to disclosures of fair value measurements. The guidance requires gross presentation of activity within the Level 3 measurement roll-forward and details of transfers in and out of Level 1 and 2 measurements. It also clarifies two existing disclosure requirements on the level of disaggregation of fair value measurements and disclosures on inputs and valuation techniques. A change in the hierarchy of an investment from its current level will be reflected in the period during which the pricing methodology of such investment changes. Disclosure of the transfer of securities from Level 1 to Level 2 or Level 3 will be made in the event that the related security is significant to total cash and investments. The Company did not have any transfers of assets and liabilities between Level 1 and Level 2 of the fair value measurement hierarchy during the three months ended June 30, 2011.

[0000950123-11-086250:notes:71]
A valuation hierarchy for disclosure of the inputs to valuation used to measure fair value has been established. This hierarchy prioritizes the inputs into three broad levels as follows:

[0000950123-11-086250:notes:72]
[same as prior period, unchanged from 0000950123-11-008765:notes:48]

[0000950123-11-086250:notes:73]
[same as prior period, unchanged from 0000950123-11-008765:notes:49]

[0000950123-11-086250:notes:74]
The following table provides the assets carried at fair value, measured as of June 30, 2011 and March 31, 2011 (in thousands):

[0000950123-11-086250:notes:75]
[same as prior period, unchanged from 0000950123-11-008765:notes:52]

[0000950123-11-086250:notes:76]
[same as prior period, unchanged from 0000950123-11-008765:notes:53]

[0000950123-11-086250:notes:77]
Cash equivalents consist of highly liquid instruments with maturities of three months or less that are regarded as high quality, low risk investments and are measured using such inputs as quoted prices, and are classified within Level 1 of the valuation hierarchy.  Cash equivalents consist principally of certificates of deposits and money market accounts.

[0000950123-11-086250:notes:78]
[same as prior period, unchanged from 0000950123-11-008765:notes:55]

[0000950123-11-086250:notes:79]
Marketable securities consist primarily of government-backed securities and commercial paper and are measured using such inputs as quoted prices for identical or similar assets in markets that are not active, inputs other than quoted prices that are observable for the asset (for example, interest rates and yield curves observable at commonly quoted intervals), and inputs that are derived principally from or corroborated by observable market data by correlation or other means, and are classified within Level 2 of the valuation hierarchy. The Company's marketable securities generally have maturities of greater than three months from original purchase date but less than twelve months from the date of the balance sheet.  The Company determines the appropriate classification of its marketable securities at the time of purchase and re-evaluates such classification as of each balance sheet date. All marketable securities are considered available-for-sale and are carried at fair value. The Company periodically reviews the realizability of each short-term and long-term marketable security when impairment indicators exist with respect to the security. If an other-than-temporary impairment of value of the security exists, the carrying value of the security is written down to its estimated fair value.

[0000950123-11-086250:notes:80]
[same as prior period, unchanged from 0000950123-11-008765:notes:57]

[0000950123-11-086250:notes:81]
[same as prior period, unchanged from 0000950123-11-008765:notes:58]


## us-gaap:IncomeTaxDisclosureTextBlock

[0000950123-11-086250:notes:82]
9.        Income Taxes

[0000950123-11-086250:notes:83]
For the three months ended June 30, 2011 and 2010, the Company recorded an income tax expense of $0.2 million and $7.3 million, respectively. The Company has provided a valuation allowance against all deferred tax assets as of June 30, 2011, as it is more likely than not that its deferred tax assets are not currently realizable due to the net operating losses incurred by the Company since its inception.


## us-gaap:InventoryDisclosureTextBlock

[0000950123-11-086250:notes:84]
[same as prior period, unchanged from 0000950123-11-008765:notes:60]

[0000950123-11-086250:notes:85]
[same as prior period, unchanged from 0000950123-11-008765:notes:61]

[0000950123-11-086250:notes:86]
Deferred program costs as of June 30, 2011 and March 31 2011 primarily represent costs incurred on D-VAR turnkey projects and programs accounted for under contract accounting where the Company needs to complete development programs before revenue and costs will be recognized, respectively.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0000950123-11-086250:notes:87]
[same as prior period, unchanged from 0000950123-11-008765:notes:65]

[0000950123-11-086250:notes:88]
American Superconductor Corporation (the "Company" or "AMSC") was founded on April 9, 1987. The Company is a leading provider of megawatt-scale solutions that lower the cost of wind power and enhance the performance of the power grid.  In the wind power market, the Company enables manufacturers to field wind turbines through its advanced engineering, support services and power electronics products.  In the power grid market, the Company enables electric utilities and renewable energy project developers to connect, transmit and distribute power through its transmission planning services and power electronics and superconductor based products.  The Company's wind and power grid products and services provide exceptional reliability, security, efficiency and affordability to its customers. The Company operates in two business units: AMSC Power Systems and AMSC Superconductors.

[0000950123-11-086250:notes:89]
These unaudited condensed consolidated financial statements of the Company have been prepared in accordance with the Securities and Exchange Commission's ("SEC") instructions to Form 10-Q. Certain information and footnote disclosures normally included in the financial statements prepared in accordance with accounting principles generally accepted in the United States ("GAAP") have been condensed or omitted pursuant to those instructions. The year-end condensed balance sheet data was derived from audited financial statements but does not include all disclosures required by GAAP. The unaudited condensed consolidated financial statements, in the opinion of management, reflect all adjustments (consisting of normal recurring adjustments) necessary for a fair statement of the results for the interim periods ended June 30, 2011 and 2010 and the financial position at June 30, 2011. The unaudited condensed consolidated financial statements include the accounts of the Company and its wholly-owned subsidiaries. All significant intercompany balances and transactions are eliminated in consolidation.  Certain reclassifications of prior year amounts have been made to conform to current year presentation.  These reclassifications had no effect on net income, cash flows from operating activities or stockholders' equity.

[0000950123-11-086250:notes:90]
On March 12, 2011, the Company entered into a definitive agreement to acquire The Switch Engineering Oy, ("The Switch"), headquartered in Vantaa, Finland.  The Switch designs, manufactures and markets wind power products, including permanent magnet generators and power converter systems, as well as grid products such as commercial and small utility-scale solar inverters to customers in Asia, including China, Europe and North America.

[0000950123-11-086250:notes:91]
As of April 1, 2011, the Company segmented its operations into two new market-facing business units: Wind and Grid. The Company believes this market-centric structure enables it to more effectively anticipate and meet the needs of wind turbine manufacturers, power generation project developers and electric utilities.

[0000950123-11-086250:notes:92]
·Wind. Through the Windtec brand, the Wind business enables manufacturers to field wind turbines with exceptional power output, reliability and affordability.  The Company licenses its highly engineered wind turbine designs, provides extensive customer support services and supplies advanced power electronics and control systems to wind turbine manufactures. The Company's design portfolio includes a broad range of drive trains and power ratings up to 10 megawatts.  The Company believes its unique engineering capabilities, ranging from bearings to advanced synchronous generators to blades, enables it to provide its partners with highly-optimized wind turbine platforms.  Furthermore, these designs and support services typically lead to sales of its power electronics and software-based control systems, which are designed for optimized performance, efficiency and grid compatibility.

[0000950123-11-086250:notes:93]
·Grid. The Grid segment enables electric utilities and renewable energy project developers to connect, transmit and distribute power with exceptional efficiency, reliability and affordability.  The Company provides transmission planning services that allows it to identify power grid congestion, poor power quality and other risks, which helps it determine how its solutions can improve network performance.  These services often lead to sales of grid interconnection solutions for wind farms and solar power plants, power quality systems and transmission and distribution cable systems.

[0000950123-11-086250:notes:94]
Prior to April 1, 2011, the Company segmented its operations through two technology-centric business units: AMSC Power Systems and AMSC Superconductors.   AMSC Power Systems included all of its Wind products, as well as Grid products that regulate voltage for wind farm voltage electric utilities, renewable generation project developers and industrial operations.  Solutions from the Company's AMSC Superconductors business unit have been incorporated into its Grid business unit. All prior period segment disclosures have been revised to conform to management's current view of the Company's business segments.

[0000950123-11-086250:notes:95]
At June 30, 2011, the Company had cash, cash equivalents, marketable securities and restricted cash of  $166.2 million. The Company's business plan anticipates a substantial decline in revenues and a substantial use of cash from operations in its fiscal year ending March 31, 2012, particularly in light of the difficult and uncertain current economic environment, the significant restructuring actions undertaken and the uncertainty surrounding Sinovel Wind Group Co. Ltd. ("Sinovel"), which has historically accounted for more than two-thirds of the Company's revenues, and certain of its other customers in China. The Company's plan includes a significant restructuring undertaken in August 2011, resulting in the elimination of approximately 150 positions worldwide.  Since April 1, 2011, the Company has eliminated approximately 30% of its workforce and it expects to save approximately $30 million annually as a result of these reductions. Additional actions include further monitoring of its operating results against expectations and, if required, further reducing operating costs and capital spending if events warrant in order to enhance liquidity.  Due to the disruption in its relationship with Sinovel, the Company will need to raise additional capital in order to complete the planned acquisition of The Switch in order to have sufficient cash to fund its working capital, capital expenditures and other cash requirements.  The Company may seek this financing through public or private equity offerings, debt financings, or other financing alternatives, however, there can be no assurance that financing will be available on acceptable terms or at all.  If the Company fails to raise sufficient additional funds and terminates the purchase agreement for the acquisition of The Switch, it will likely forfeit the $20.6 million cash advance payment it paid to the shareholders of The Switch on June 29, 2011.  In the event that the Company does not receive any additional payments from Sinovel and it neither completes the planned acquisition of The Switch, nor raises additional capital, the Company believes that its available cash, together with additional reductions in operating costs and capital expenditures as necessary will be sufficient to fund its operations, capital expenditures and other cash requirements through at least March 31, 2012. The Company's long-term liquidity is dependent on its ability to profitably grow its revenues or raise additional capital as required.

[0000950123-11-086250:notes:96]
The results of operations for an interim period are not necessarily indicative of the results of operations to be expected for the fiscal year. These unaudited condensed consolidated financial statements should be read in conjunction with the audited consolidated financial statements for the fiscal year ended March 31, 2011 (fiscal 2010) which are contained in the Company's Annual Report on Form 10-K.

[0000950123-11-086250:notes:97]
The Company's fiscal year begins on April 1 and ends on March 31. This document refers to fiscal 2011, which is defined as the period beginning on April 1, 2011 and concluding on March 31, 2012. The first quarter of fiscal 2011 began on April 1, 2011 and concluded on June 30, 2011.


## us-gaap:ProductWarrantyDisclosureTextBlock

[0000950123-11-086250:notes:98]
[same as prior period, unchanged from 0000950123-11-008765:notes:73]

[0000950123-11-086250:notes:99]
The Company generally provides a one to three year warranty on its products, commencing upon installation. A provision is recorded upon revenue recognition to cost of revenues for estimated warranty expense based on historical experience.

[0000950123-11-086250:notes:100]
[same as prior period, unchanged from 0000950123-11-008765:notes:75]


## us-gaap:ScheduleOfAccountsNotesLoansAndFinancingReceivableTextBlock

[0000950123-11-086250:notes:101]
[same as prior period, unchanged from 0000950123-11-008765:notes:82]

[0000950123-11-086250:notes:102]
[same as prior period, unchanged from 0000950123-11-008765:notes:83]


## us-gaap:SegmentReportingDisclosureTextBlock

[0000950123-11-086250:notes:103]
12.          Business Segments

[0000950123-11-086250:notes:104]
Business segments are defined as components of an enterprise about which separate financial information is available that is evaluated regularly by the chief operating decision maker, or decision-making group, in assessing performance and deciding how to allocate resources.

[0000950123-11-086250:notes:105]
·Wind. Through the Windtec brand, the Wind business unit enables manufacturers to field wind turbines with exceptional power output, reliability and affordability.  The Company licenses its highly engineered wind turbine designs, provides extensive customer support services and supplies advanced power electronics and control systems to wind turbine manufactures. The Company's design portfolio includes a broad range of drive trains and power ratings up to 10 megawatts.  The Company believes its unique engineering capabilities, ranging from bearings to advanced synchronous generators to blades, enables it to provide its partners with highly-optimized wind turbine platforms.  Furthermore, these designs and support services typically lead to sales of its power electronics and software-based control systems, which are designed for optimized performance, efficiency and grid compatibility.

[0000950123-11-086250:notes:106]
·Grid. The Grid segment enables electric utilities and renewable energy project developers to connect, transmit and distribute power with exceptional efficiency, reliability and affordability.  The Grid business unit provides transmission planning services that allow us to identify power grid congestion, poor power quality and other risks, which helps the Company determine how its solutions can improve network performance.  These services often lead to sales of grid interconnection solutions for wind farms and solar power plants, power quality systems and transmission and distribution cable systems.

[0000950123-11-086250:notes:107]
Prior to April 1, 2011, the Company segmented its operations through two technology-centric business units: AMSC Power Systems and AMSC Superconductors. AMSC Power Systems included all of its Wind products, as well as Grid products that regulate voltage for wind farm voltage electric utilities, renewable generation project developers and industrial operations.  Solutions from the Company's AMSC Superconductors business unit have been incorporated into its Grid business unit. All prior period segment disclosures have been revised to conform to management's current view of the Company's business segments.

[0000950123-11-086250:notes:108]
[same as prior period, unchanged from 0000950123-11-008765:notes:90]

[0000950123-11-086250:notes:109]
The accounting policies of the business segments are the same as those for the consolidated Company.  The Company's business segments have been determined in accordance with the Company's internal management structure, which is organized based on operating activities.  The Company evaluates performance based upon several factors, of which the primary financial measures are segment revenues and segment operating (loss) income. The disaggregated financial results of the segments reflect allocation of certain functional expense categories consistent with the basis and manner in which Company management internally disaggregates financial information for the purpose of assisting in making internal operating decisions. In addition, certain corporate expenses which the Company does not believe are specifically attributable or allocable to either of the two business segments have been excluded from the segment operating income.

[0000950123-11-086250:notes:110]
Unallocated corporate expenses include stock-based compensation expense of $3.5 million for the three months ended June 30, 2011 and 2010.

[0000950123-11-086250:notes:111]
[same as prior period, unchanged from 0000950123-11-008765:notes:94]

[0000950123-11-086250:notes:112]
The following table sets forth customers who represented 10% or more of the Company's total revenues for the three months ended June 30, 2011 and 2010:
