# AMSC MD&A — 0001437749-19-015632


## mdna

[0001437749-19-015632:mdna:1]
[same as prior period, unchanged from 0001628280-19-000966:mdna:1]

[0001437749-19-015632:mdna:2]
American Superconductor®, Amperium®, AMSC®, D-VAR®, PowerModule™, D-VAR VVO®, PQ-IVR®, SeaTitan®, Gridtec Solutions™, Windtec Solutions™ and Smarter, Cleaner...Better Energy™ are trademarks or registered trademarks of American Superconductor Corporation or our subsidiaries. We reserve all of our rights with respect to our trademarks or registered trademarks regardless of whether they are so designated in this Quarterly Report on Form 10-Q by an ® or ™ symbol. All other brand names, product names, trademarks or service marks appearing in this Quarterly Report on Form 10-Q are the property of their respective holders.

[0001437749-19-015632:mdna:3]
[same as prior period, unchanged from 0001628280-19-000966:mdna:4]

[0001437749-19-015632:mdna:4]
We are a leading provider of megawatt-scale solutions that enhance the performance of the power grid, protect our Navy's fleet, and lower the cost of wind power. In the power grid market, we enable electric utilities, industrial facilities, and renewable energy project developers to connect, transmit and distribute power through our transmission planning services and power electronics and superconductor-based systems. In the wind power market, we enable manufacturers to field highly competitive wind turbines through our advanced power electronics and control system products, engineering, and support services. Our power grid and wind products and services provide exceptional reliability, security, efficiency and affordability to our customers.

[0001437749-19-015632:mdna:5]
Our power system solutions help to improve energy efficiency, alleviate power grid capacity constraints, improve system resiliency, and increase the adoption of renewable energy generation. Demand for our solutions is driven by the growing needs for modernized smart grids that improve power reliability, security and quality, the U.S. Navy's effort to upgrade in-board power systems to support fleet electrification, and the need for increased renewable sources of electricity, such as wind and solar energy. Concerns about these factors have led to increased spending by corporations and the military, as well as supportive government regulations and initiatives on local, state, and national levels, including renewable portfolio standards, tax incentives and international treaties.

[0001437749-19-015632:mdna:6]
[same as prior period, unchanged from 0001628280-19-000966:mdna:7]

[0001437749-19-015632:mdna:7]
We operate our business under two market-facing business units: Grid and Wind. We believe this market-centric structure enables us to more effectively anticipate and meet the needs of electric utilities, power generation project developers and wind turbine manufacturers.

[0001437749-19-015632:mdna:8]
|  | • | Grid. Through our Gridtec Solutions™, our Grid business segment enables electric utilities and renewable energy project developers to connect, transmit and distribute power with exceptional efficiency, reliability, security and affordability. We provide transmission planning services that allow us to identify power grid congestion, poor power quality, and other risks, which help us determine how our solutions can improve network performance. These services often lead to sales of our grid interconnection solutions for wind farms and solar power plants, power quality systems and transmission and distribution cable systems. We also sell ship protection products to the U.S. Navy through our Grid business segment. |

[0001437749-19-015632:mdna:9]
|  | • | Wind. Through our Windtec Solutions™, our Wind business segment enables manufacturers to field wind turbines with exceptional power output, reliability and affordability. We supply advanced power electronics and control systems, license our highly engineered wind turbine designs, and provide extensive customer support services to wind turbine manufacturers. Our design portfolio includes a broad range of drive trains and power ratings of 2 megawatts (“MW”) and higher. We provide a broad range of power electronics and software-based control systems that are highly integrated and designed for optimized performance, efficiency, and grid compatibility. |

[0001437749-19-015632:mdna:10]
Our fiscal year begins on April 1 and ends on March 31. When we refer to a particular fiscal year, we are referring to the fiscal year beginning on April 1 of that same year. For example, fiscal 2019 refers to the fiscal year beginning on April 1, 2019. Other fiscal years follow similarly.

[0001437749-19-015632:mdna:11]
On July 3, 2018, we and our wholly-owned subsidiaries Suzhou AMSC Superconductor Co. Ltd. (“AMSC China”) and AMSC Austria GmbH (“AMSC Austria”) entered into a settlement agreement (the “Settlement Agreement”) with Sinovel Wind Group Co., Ltd. (“Sinovel”). The Settlement Agreement settles the litigation and arbitration proceedings between us and Sinovel listed on Schedule 2 of the Settlement Agreement (the “Proceedings”), and any other civil claims, counterclaims, causes of action, rights and obligations directly or indirectly relating to the subject matters of the Proceedings and the contracts between us and Sinovel listed on Schedules 1 and 4 of the Settlement Agreement (the “Contracts”), subject to the exception described in Section 1.1 of the Settlement Agreement. The Settlement Agreement was filed as Exhibit 10.1 to the Company’s Form 8-K filed with the Securities and Exchange Commission on July 9, 2018. Under the terms of the Settlement Agreement, Sinovel agreed to pay AMSC China an aggregate cash amount in Renminbi (“RMB”) equivalent to $57.5 million, consisting of two installments. Sinovel paid the first installment of the RMB equivalent of $32.5 million on July 4, 2018, and paid the second installment of the RMB equivalent of $25.0 million on December 27, 2018.

[0001437749-19-015632:mdna:12]
[same as prior period, unchanged from 0001628280-19-000966:mdna:13]

[0001437749-19-015632:mdna:13]
On October 31, 2018, we entered into a Subcontract Agreement with Commonwealth Edison Company (“ComEd”) (the “Subcontract Agreement”) for the manufacture and installation of the Company’s REG system within ComEd’s electric grid in Chicago, Illinois (the “Project”). As provided in the Subcontract Agreement, the Subcontract Agreement became effective upon the signing of an amendment by us and the U.S. Department of Homeland Security (“DHS”) to the existing contract (the “Prime Contract”) between us and DHS on June 20, 2019. Unless terminated earlier by us or DHS according to the terms of the Subcontract Agreement, the term of the Subcontract Agreement will continue until we complete our warranty obligations under the Subcontract Agreement. Under the terms of the Subcontract Agreement, we have agreed, among other things, to provide the REG system and to supervise ComEd’s installation of the REG system in Chicago. As part of our separate cost sharing arrangement with DHS under the Prime Contract, we expect funding provided by DHS in connection with the Subcontract Agreement to be between $9.0 to $11.0 million, which represents the total amount of revenue we are expected to recognize over the term of the Subcontract Agreement and includes up to $1.0 million that we have agreed to reimburse ComEd for costs incurred by ComEd while undertaking its tasks under the Subcontract Agreement (the “Reimbursement Amount”). In addition, we have agreed to deliver an irrevocable letter of credit in the amount of $5.0 million to secure certain Company obligations under the Subcontract Agreement. ComEd has agreed to provide the site and provide all civil engineering work required to support the installation, operation and integration of the REG system into ComEd’s electric grid. Other than the Reimbursement Amount, ComEd is responsible for its own costs and expenses. Construction of the Project is expected to commence within six months after DHS’s approval, which was obtained on June 20, 2019. The REG system is expected to be operational in 2021.

[0001437749-19-015632:mdna:14]
[same as prior period, unchanged from 0001628280-19-000966:mdna:16]

[0001437749-19-015632:mdna:15]
The preparation of the unaudited condensed consolidated financial statements requires that we make estimates and judgments that affect the reported amounts of assets, liabilities, revenues and expenses, and related disclosure of contingent assets and liabilities. We base our estimates on historical experience and various other assumptions that are believed to be reasonable under the circumstances, the results of which form the basis for making judgments about the carrying values of assets and liabilities that are not readily apparent from other sources. Actual results may differ under different assumptions or conditions. Effective April, 1 2019, we adopted ASU 2016-02, which provides for new requirements in regards to leases. See Note 14, "Leases" for further details. Aside from the adoption of ASU 2016-02, there were no significant changes in the critical accounting policies that were disclosed in our Form 10-K for fiscal 2018, which ended on March 31, 2019.

[0001437749-19-015632:mdna:16]
[same as prior period, unchanged from 0001628280-19-000966:mdna:18]

[0001437749-19-015632:mdna:17]
Three months ended June 30, 2019 compared to the three months ended June 30, 2018

[0001437749-19-015632:mdna:18]
[same as prior period, unchanged from 0001628280-19-000966:mdna:20]

[0001437749-19-015632:mdna:19]
Total revenues increased 9% to $13.8 million for the three months ended June 30, 2019, compared to $12.6 million for the three months ended June 30, 2018.  Our revenues are summarized as follows (in thousands):

[0001437749-19-015632:mdna:20]
|  |  | Three Months Ended June 30, |  |
|  |  | 2019 |  |  | 2018 |  |
| Revenues: |  |  |  |  |  |  |  |  |
| Grid |  | $ | 9,855 |  |  | $ | 8,929 |  |
| Wind |  |  | 3,915 |  |  |  | 3,678 |  |
| Total |  | $ | 13,770 |  |  | $ | 12,607 |  |

[0001437749-19-015632:mdna:21]
Our Grid business unit accounted for 72% of total revenues for the three months ended June 30, 2019, compared to 71% for the three months ended June 30, 2018. Our Grid business unit revenues increased 10% to $9.9 million in the three months ended June 30, 2019, from $8.9 million in the three months ended June 30, 2018. Grid business unit revenue increased, primarily driven by higher D-VAR revenues and the commencement of the REG project with ComEd, partially offset by lower license revenue due to the joint venture agreement with BASF ending in fiscal 2018.

[0001437749-19-015632:mdna:22]
Our Wind business unit accounted for 28% of total revenues for the three months ended June 30, 2019, compared to 29% for the three months ended June 30, 2018. Revenues in the Wind business unit increased 6% to $3.9 million in the three months ended June 30, 2019, from $3.7 million in the three months ended June 30, 2018. The increase over the prior year period was driven by increased development revenue for the 3MW wind turbine platform with Inox.  Inox has been active in the new central and state government auction regime in India and has over 900 MW of orders from the first four SECI central government auctions, and 50 MW from the Maharashtra state government auction. However, we cannot predict if and how successful Inox will be in executing on these orders or in obtaining new orders under the new central and state auction regime. Any failure by Inox to succeed under this regime, or any delay in Inox’s ability to deliver its wind turbines, could result in fewer ECS shipments to Inox.

[0001437749-19-015632:mdna:23]
[same as prior period, unchanged from 0001628280-19-000966:mdna:28]

[0001437749-19-015632:mdna:24]
Cost of revenues increased by 40% to $12.2 million for the three months ended June 30, 2019, compared to $8.7 million for the three months ended June 30, 2018. Gross margin was 11% for the three months ended June 30, 2019, compared to 31% for the three months ended June 30, 2018. The decrease in gross margin in the three month period was driven by a less favorable product mix than in the prior year period, primarily driven by the Grid business unit.

[0001437749-19-015632:mdna:25]
[same as prior period, unchanged from 0001628280-19-000966:mdna:30]

[0001437749-19-015632:mdna:26]
[same as prior period, unchanged from 0001628280-19-000966:mdna:31]

[0001437749-19-015632:mdna:27]
R&D expenses decreased in the three months ended June 30, 2019 by 13% to $2.5 million from $2.8 million for the three months ended June 30, 2018.  The decrease in R&D expense was due primarily to decreased compensation expense.

[0001437749-19-015632:mdna:28]
[same as prior period, unchanged from 0001628280-19-000966:mdna:33]

[0001437749-19-015632:mdna:29]
SG&A expenses decreased by 9% to $5.3 million in the three months ended June 30, 2019, from $5.8 million in the three months ended June 30, 2018. The decrease in SG&A expense was due primarily to decreased compensation expense.

[0001437749-19-015632:mdna:30]
[same as prior period, unchanged from 0001628280-19-000966:mdna:37]

[0001437749-19-015632:mdna:31]
We recorded amortization expense related to our core technology and know-how, trade names and trademark intangible assets of $0.1 million in both of the three month periods ended June 30, 2019, and 2018, respectively.

[0001437749-19-015632:mdna:32]
[same as prior period, unchanged from 0001628280-19-000966:mdna:40]

[0001437749-19-015632:mdna:33]
We recorded less than $0.3 million for facility exit costs in the three months ended June 30, 2018 as a result of the move of the corporate office that was announced as part of our April 4, 2017 approved restructuring plan.  There was no restructuring activity in the three months ended June 30, 2019.

[0001437749-19-015632:mdna:34]
Operating loss

[0001437749-19-015632:mdna:35]
Our operating loss is summarized as follows (in thousands):

[0001437749-19-015632:mdna:36]
|  |  | Three Months Ended June 30, |  |
|  |  | 2019 |  |  | 2018 |  |
| Operating loss: |  |  |  |  |  |  |  |  |
| Grid |  | $ | (4,663 | ) |  | $ | (2,666 | ) |
| Wind |  |  | (1,324 | ) |  |  | (1,367 | ) |
| Unallocated corporate expenses |  |  | (249 | ) |  |  | (1,095 | ) |
| Total |  | $ | (6,236 | ) |  | $ | (5,128 | ) |

[0001437749-19-015632:mdna:37]
Our Grid segment generated an operating loss of $4.7 million in the three months ended June 30, 2019, compared to a loss of $2.7 million in the three months ended June 30, 2018. The increase in the Grid business unit operating loss in the three months ended June 30, 2019 was primarily due to a less favorable product mix and a higher cost of sales.

[0001437749-19-015632:mdna:38]
Our Wind segment generated an operating loss of $1.3 million in the three months ended June 30, 2019, compared to a loss of $1.4 million in the three months ended June 30, 2018. The slight decrease in the Wind business unit operating loss was due primarily to increased revenue related to the 3MW platform as discussed above.

[0001437749-19-015632:mdna:39]
Unallocated corporate expenses primarily consist of stock-based compensation expense of $0.2 million and $0.8 million, in the three months ended June 30, 2019 and 2018, respectively and restructuring charges of $0.3 million in the three months ended June 30, 2018.

[0001437749-19-015632:mdna:40]
[same as prior period, unchanged from 0001628280-19-000966:mdna:48]

[0001437749-19-015632:mdna:41]
The change in fair value of warrants resulted in a gain of $2.9 million in the three months ended June 30, 2019, compared to a loss of $0.5 million in the three months ended June 30, 2018. The change in the fair value was primarily driven by changes in stock price, which is a key valuation metric.

[0001437749-19-015632:mdna:42]
[same as prior period, unchanged from 0001628280-19-000966:mdna:52]

[0001437749-19-015632:mdna:43]
Interest income, net, was $0.5 million in the three months ended June 30, 2019, compared to $0.2 million in the three months ended June 30, 2018. The increase in interest income was primarily related to higher cash balances earning higher interest rates than in prior periods as well as the non-cash interest income recognized from receipt of the final payment on the Devens facility note receivable.

[0001437749-19-015632:mdna:44]
[same as prior period, unchanged from 0001628280-19-000966:mdna:54]

[0001437749-19-015632:mdna:45]
Other income (expense), net, was expense of $0.5 million in the three months ended June 30, 2019, compared to income of $0.6 million in the three months ended June 30, 2018.  The increase in other expense, net, was primarily driven by higher foreign currency gains.

[0001437749-19-015632:mdna:46]
[same as prior period, unchanged from 0001628280-19-000966:mdna:56]

[0001437749-19-015632:mdna:47]
Income tax expense was $0.2 million in the three months ended June 30, 2019, compared to income tax benefit of less than $0.1 million in the three months ended June 30, 2018. The increase in income tax expense is due primarily to taxable income in foreign jurisdictions.

[0001437749-19-015632:mdna:48]
[same as prior period, unchanged from 0001628280-19-000966:mdna:58]

[0001437749-19-015632:mdna:49]
[same as prior period, unchanged from 0001628280-19-000966:mdna:59]

[0001437749-19-015632:mdna:50]
We define non-GAAP net loss as net loss before stock-based compensation, amortization of acquisition-related intangibles, consumption of zero cost-basis inventory, changes in fair value of warrants, and other non-cash or unusual charges, and the tax effect of those adjustments calculated at the relevant rate for our non-GAAP metric, indicated in the table below. We believe non-GAAP net loss assists management and investors in comparing our performance across reporting periods on a consistent basis by excluding these non-cash or non-recurring charges that we do not believe are indicative of our core operating performance. A reconciliation of GAAP to non-GAAP net loss is set forth in the table below (in thousands, except per share data):

[0001437749-19-015632:mdna:51]
|  |  | Three Months Ended June 30, |  |
|  |  | 2019 |  |  | 2018 |  |
| Net loss |  | $ | (3,539 | ) |  | $ | (4,737 | ) |
| Stock-based compensation |  |  | 249 |  |  |  | 785 |  |
| Amortization of acquisition-related intangibles |  |  | 85 |  |  |  | 85 |  |
| Consumption of zero cost-basis inventory |  |  | 0 |  |  |  | (249 | ) |
| Changes in fair value of warrants |  |  | (2,946 | ) |  |  | 464 |  |
| Tax effect of adjustments for consumption of zero cost-basis inventory |  |  | 0 |  |  |  | 40 |  |
| Non-GAAP net loss |  | $ | (6,151 | ) |  | $ | (3,612 | ) |
| Non-GAAP net loss per share - basic |  | $ | (0.30 | ) |  | $ | (0.18 | ) |
| Weighted average shares outstanding - basic |  |  | 20,514 |  |  |  | 20,167 |  |

[0001437749-19-015632:mdna:52]
We incurred non-GAAP net loss of $6.2 million or $0.30 per share, for the three months ended June 30, 2019, compared to non-GAAP net loss of $3.6 million or $0.18 per share for the three months ended June 30, 2018. The increase in non-GAAP net loss was primarily due to the less favorable product mix compared to the prior year period, primarily driven by the Grid business unit.

[0001437749-19-015632:mdna:53]
We define non-GAAP operating cash flow as operating cash flow before the Sinovel settlement (net of legal fees and expenses); tax effect of adjustments; and other unusual cash flows or items. We believe non-GAAP operating cash flow assists management and investors in comparing our operating cash flow across reporting periods on a consistent basis by excluding these non-recurring cash items that it does not believe are indicative of our core operating cash flow. A reconciliation of GAAP to non-GAAP operating cash flow is set forth in the table below (in thousands).

[0001437749-19-015632:mdna:54]
|  |  | June 30, 2019 |  |  | March 31, 2019 |  |
| Operating cash flow |  | $ | (5,866 | ) |  | $ | 42,714 |  |
| Sinovel settlement (net of legal fees and expenses) |  |  | 1,000 |  |  |  | (52,740 | ) |
| Tax effect of adjustments |  |  | 0 |  |  |  | 2,377 |  |
| Non-GAAP operating cash flow |  | $ | (4,866 | ) |  | $ | (7,649 | ) |

[0001437749-19-015632:mdna:55]
[same as prior period, unchanged from 0001628280-19-000966:mdna:66]

[0001437749-19-015632:mdna:56]
We have experienced recurring operating losses, and as of June 30, 2019, had an accumulated deficit of $965.1 million.

[0001437749-19-015632:mdna:57]
Our cash requirements depend on numerous factors, including whether Inox is successful in executing on SECI orders or in obtaining additional orders under the new central and state auction regime, the successful completion of our product development activities, our ability to commercialize our REG and ship protection system solutions, the rate of customer and market adoption of our products, collecting receivables according to established terms, and the continued availability of U.S. government funding during the product development phase of our superconductor-based products. We continue to closely monitor our expenses and, if required, expect to further reduce our operating and capital spending to enhance liquidity.

[0001437749-19-015632:mdna:58]
As of June 30, 2019, we had cash, cash equivalents, and restricted cash of $74.7 million, compared to $78.2 million as of March 31, 2019, a decrease of $3.5 million. As of June 30, 2019, we had approximately $29.5 million of cash, cash equivalents, and restricted cash in foreign bank accounts. Our cash and cash equivalents, and restricted cash are summarized as follows (in thousands):

[0001437749-19-015632:mdna:59]
|  |  | June 30, 2019 |  |  | March 31, 2019 |  |
| Cash and cash equivalents |  | $ | 73,952 |  |  | $ | 77,483 |  |
| Restricted cash |  |  | 715 |  |  |  | 715 |  |
| Total cash, cash equivalents, and restricted cash |  | $ | 74,667 |  |  | $ | 78,198 |  |

[0001437749-19-015632:mdna:60]
For the three months ended June 30, 2019, net cash used in operating activities was $5.9 million compared to $6.9 million of net cash used for the three months ended June 30, 2018. The decrease in net cash used in operations was due primarily to the timing of our receipt of milestone payments on several Grid projects.

[0001437749-19-015632:mdna:61]
For the three months ended June 30, 2019, net cash provided by investing activities was $2.3 million, compared to net cash used in investing activities of $0.2 million for the three months ended June 30, 2018. The increase in net cash provided by investing activities was due primarily to the receipt of the second installment payment under the Notes Receivable from the Devens facility sale, partially offset by higher purchases of property, plant and equipment in the three months ended June 30, 2019 related to improvements to the Ayer facility and factory equipment to support the Navy and REG projects.

[0001437749-19-015632:mdna:62]
For the three months ended June 30, 2019, net cash used in financing activities was $0.3 million compared to net cash used in financing activities of $0.2 million in the three months ended June 30, 2018.  The increase in net cash used in financing activities was due primarily to increased employee taxes paid related to net settlement of equity awards.

[0001437749-19-015632:mdna:63]
As of June 30, 2019, we had $0.7 million of restricted cash included in long-term assets. These amounts included in restricted cash primarily represent deposits to secure letters of credit for various supply contracts. These deposits are held in interest bearing accounts.

[0001437749-19-015632:mdna:64]
We believe we have sufficient available liquidity to fund our operations and capital expenditures for the next twelve months. In addition, we may seek to raise additional capital, which could be in the form of loans, convertible debt or equity, to fund our operating requirements and capital expenditures. Our liquidity is highly dependent on our ability to increase revenues, including our ability to collect revenues under our agreements with Inox, control our operating costs, and our ability to raise additional capital, if necessary. There can be no assurance that we will be able to raise additional capital, on favorable terms or at all, or execute on any other means of improving our liquidity as described above.

[0001437749-19-015632:mdna:65]
Legal Proceedings

[0001437749-19-015632:mdna:66]
We are involved in legal and administrative proceedings and claims of various types. See Part II, Item 1, “Legal Proceedings,” for additional information. We record a liability in our consolidated financial statements for these matters when a loss is known or considered probable and the amount can be reasonably estimated. We review these estimates each accounting period as additional information is known and adjust the loss provision when appropriate. If a matter is both probable to result in liability and the amounts of loss can be reasonably estimated, we estimate and disclose the possible loss or range of loss to the extent necessary to make the consolidated financial statements not misleading. If the loss is not probable or cannot be reasonably estimated, a liability is not recorded in our consolidated financial statements.

[0001437749-19-015632:mdna:67]
[same as prior period, unchanged from 0001628280-19-000966:mdna:79]

[0001437749-19-015632:mdna:68]
[same as prior period, unchanged from 0001628280-19-000966:mdna:80]

[0001437749-19-015632:mdna:69]
[same as prior period, unchanged from 0001628280-19-000966:mdna:81]

[0001437749-19-015632:mdna:70]
[same as prior period, unchanged from 0001628280-19-000966:mdna:82]

[0001437749-19-015632:mdna:71]
[same as prior period, unchanged from 0001628280-19-000966:mdna:83]

[0001437749-19-015632:mdna:72]
In February 2016, the FASB issued Accounting Standards Update ("ASU") 2016-02, Leases (Topic 842). The guidance in this ASU supersedes the leasing guidance in Topic 840, Leases. Under the new guidance, lessees are required to recognize lease assets and lease liabilities on the balance sheet for all leases with terms longer than 12 months. Leases will be classified as either finance or operating, with classification affecting the pattern of expense recognition in the income statement. This ASU and its amendments are effective for fiscal years beginning after December 15, 2018, including interim periods within those fiscal years.

[0001437749-19-015632:mdna:73]
|  | • | In July 2018, the FASB issued ASU 2018-10, Codification improvements to Topic 842, Leases. The amendments in ASU 2018-10 provide more clarification in regards to the application and requirements of ASU 2016-02. |

[0001437749-19-015632:mdna:74]
|  | • | In July 2018, the FASB issued ASU 2018-11, Topic 842, Leases - Targeted improvements. The amendments in ASU 2018-11 provide for the option to adopt the standard prospectively and recognize a cumulative-effect adjustment to the opening balance of retained earnings as well as offer a new practical expedient that will allow us to elect, by class of underlying asset, to not separate non-lease and lease components in certain circumstances and instead to account for those components as a single item. |

[0001437749-19-015632:mdna:75]
ASU 2016-02 became effective on April 1, 2019, and we adopted the standard using the modified retrospective transition method, which will impact all leases existing at, or entered into after, the period of adoption. For all leases existing at the time of adoption we recognized a right-of-use asset and lease liability on the balance sheet.  See Note 14 "Leases" for additional information.

[0001437749-19-015632:mdna:76]
In June 2016, the FASB issued ASU 2016-13, Financial Instruments-Credit Losses (Topic 326): Measurement of Credit Losses on Financial Instruments. The amendments in ASU 2016-13 provide more decision-useful information about the expected credit losses on financial instruments and other commitments to extend credit held by a reporting entity at each reporting date. The ASU is effective for annual reporting periods beginning after December 15, 2019, including interim periods within that year.  We are currently evaluating the impact, if any, the adoption of ASU 2016-13 may have on our consolidated financial statements.

[0001437749-19-015632:mdna:77]
In July 2017, the FASB issued ASU 2017-11, Earnings per Share (Topic 260), Distinguishing Liabilities from Equity (Topic 480), and Derivatives and Hedging (Topic 815). The amendments in ASU 2017-11 provide guidance for freestanding equity-linked financial instruments, such as warrants and conversion options in convertible debt or preferred stock, and should no longer be accounted for as a derivative liability at fair value as a result of the existence of a down round feature. The ASU is effective for annual reporting periods beginning after December 15, 2018, including interim periods within those periods. As of April 1, 2019 we have adopted ASU 2017-11 and noted no significant impact on our consolidated financial statements, primarily due to the put option feature which requires continued liability classification under ASC 840.

[0001437749-19-015632:mdna:78]
In August 2017, the FASB issued ASU 2017-12, Derivatives and Hedging (Topic 815): Targeted Improvements to Accounting for Hedging Activities. The amendments in ASU 2017-12 provide improved financial reporting of hedging relationships to better portray the economic results of an entity’s risk management activities in its financial statements. In addition, the amendments in this update make certain targeted improvements to simplify the application of the hedge accounting guidance. The ASU is effective for annual reporting periods beginning after December 15, 2018, including interim periods within those periods. As of April 1, 2019 we have adopted ASU 2017-12 and noted no significant impact on our consolidated financial statements, primarily due to the fact that there are no longer any hedging instruments included in our results.

[0001437749-19-015632:mdna:79]
In June 2018, the FASB issued ASU 2018-08, Not-For-Profit Entities (Topic 958): Clarifying the Scope and the Accounting Guidance for Contributions Received and Contributions Made.  The amendments in ASU 2018-08 assist entities in (1) evaluating whether transactions should be accounted for as contributions (nonreciprocal transactions) within the scope of Topic 958, Not-for-Profit Entities, or as exchange (reciprocal) transactions subject to other guidance and (2) determining whether a contribution is conditional.  The ASU is effective for annual reporting periods beginning after December 15, 2018, including interim periods within those periods. As of April 1, 2019, we have adopted ASU 2018-08 and noted additional disclosures within our revenue footnote to appropriately present the revenue related to our grant revenue.

[0001437749-19-015632:mdna:80]
In August 2018, the FASB issued ASU 2018-13, Fair Value Measurement (Topic 820): Changes to the Disclosure Requirements for Fair Value Measurement. The amendments in ASU 2018-13 provide for increased effectiveness of the disclosures made around fair value measurements while including consideration for costs and benefits. The ASU is effective for annual reporting periods beginning after December 15, 2019, including interim periods within those periods. We are currently evaluating the impact the adoption of ASU 2018-13 may have on our consolidated financial statements.

[0001437749-19-015632:mdna:81]
We do not believe that, outside of those disclosed here, there are any other recently issued accounting pronouncements that will have a material impact on our consolidated financial statements.
