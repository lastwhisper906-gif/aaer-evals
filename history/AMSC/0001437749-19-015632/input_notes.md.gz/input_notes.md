# AMSC notes — 0001437749-19-015632


## amsc:AccountsReceivableTableTextBlock

[0001437749-19-015632:notes:1]
|  |  | June 30, 2019 |  |  | March 31, 2019 |  |
| Accounts receivable (billed) |  | $ | 8,643 |  |  | $ | 5,642 |  |
| Accounts receivable (unbilled) |  |  | 2,093 |  |  |  | 2,213 |  |
| Accounts receivable, net |  | $ | 10,736 |  |  | $ | 7,855 |  |


## amsc:AccountsReceivableTextBlock

[0001437749-19-015632:notes:2]
7.
 Accounts Receivable

[0001437749-19-015632:notes:3]
Accounts receivable at

[0001437749-19-015632:notes:4]
June 30, 2019

[0001437749-19-015632:notes:5]
and

[0001437749-19-015632:notes:6]
March 31, 2019

[0001437749-19-015632:notes:7]
consisted of the following (in thousands):


## amsc:AssetsAndLiabilitiesLesseeTableTextBlock

[0001437749-19-015632:notes:8]
|  |  | June 30, 2019 |  |
| Operating Leases: |  |  |  |  |
| Right-of-use assets |  | $ | 3,733 |  |
| Total right-of-use assets |  |  | 3,733 |  |
| Lease liabilities - ST |  | $ | 416 |  |
| Lease liabilities - LT |  |  | 3,357 |  |
| Total operating lease liabilities |  |  | 3,773 |  |
| Weighted-average remaining lease term |  | 7.55 years |  |
| Weighted-average discount rate |  |  | 7.06 | % |


## amsc:LiquidityPolicyPolicyTextBlock

[0001437749-19-015632:notes:9]
Liquidity

[0001437749-19-015632:notes:10]
The Company has historically experienced recurring operating losses and as of

[0001437749-19-015632:notes:11]
, the Company had an accumulated deficit of $

[0001437749-19-015632:notes:12]
965.1

[0001437749-19-015632:notes:13]
million. In addition, the Company has historically experienced recurring negative operating cash flows.  At

[0001437749-19-015632:notes:14]
, the Company had cash and cash equivalents of $

[0001437749-19-015632:notes:15]
74.0

[0001437749-19-015632:notes:16]
million, with 
no
 outstanding debt other than ordinary trade payables. Cash used in operations for the

[0001437749-19-015632:notes:17]
three

[0001437749-19-015632:notes:18]
months ended

[0001437749-19-015632:notes:19]
was $

[0001437749-19-015632:notes:20]
5.9

[0001437749-19-015632:notes:21]
million.

[0001437749-19-015632:notes:22]
On 
 July

[0001437749-19-015632:notes:23]
3,

[0001437749-19-015632:notes:24]
2018,
 the Company and its wholly-owned subsidiaries Suzhou AMSC Superconductor Co. Ltd. (“AMSC China”) and AMSC Austria GMBH (“AMSC Austria”) entered into a settlement agreement (the “Settlement Agreement”) with Sinovel Wind Group Co., Ltd. (“Sinovel”). The Settlement Agreement settles the litigation and arbitration proceedings between the Company and Sinovel. Under the terms of the Settlement Agreement, Sinovel agreed to pay AMSC China an aggregate cash amount in Renminbi (“RMB”) equivalent to 
$57.5
 million, consisting of 
two
 installments. Sinovel paid the 
first
 installment of the RMB equivalent of 
$32.5
 million on 
 July

[0001437749-19-015632:notes:25]
4,

[0001437749-19-015632:notes:26]
2018,
 which was repatriated to the Company during the 
nine
 months ended 
 December

[0001437749-19-015632:notes:27]
31,

[0001437749-19-015632:notes:28]
2018,
 and paid the 
second
 installment of the RMB equivalent of 
$25.0
 million on 
 December 27, 2018.  
The Company’s fiscal 
2018
 results included the net gain received from the settlement with Sinovel of 
$52.7
 million.

[0001437749-19-015632:notes:29]
On 
 February 1, 2018, 
ASC Devens LLC (the “Seller”), a wholly-owned subsidiary of the Company, entered into a Purchase and Sale Agreement (the “PSA”) with 
64
 Jackson, LLC (the “Purchaser”) and Stewart Title Guaranty Company (“Escrow Agent”), to effectuate the sale of certain real property located at 
64
 Jackson Road, Devens, Massachusetts, including the building that had served as the Company’s headquarters (collectively, the “Property”), in exchange for total consideration of 
$23.0
 million, composed of (i) cash consideration of 
$17.0
 million, and (ii) a 
$6.0
 million subordinated secured commercial promissory note payable to the Company (the “Seller Note”). Subsequently, the Seller, the Purchaser and Jackson 
64
 MGI, LLC (“Assignee”) entered into an Assignment of Purchase and Sale Agreement (the “Assignment Agreement”), pursuant to which the Purchaser assigned all of its rights and interests in the PSA to the Assignee and the Assignee agreed to assume all of the Purchaser’s obligations and liabilities under the PSA. The transaction closed on 
 March 28, 2018, 
at which time the Company received, from the Assignee, cash consideration, net of certain agreed upon closing costs, of 
$16.9
 million, and the Seller Note at an interest rate of 
1.96%.
 The Seller Note was secured by a subordinated 
second
 mortgage on the Property and a subordinated 
second
 assignment of leases and rents.  The Company received the 
first

[0001437749-19-015632:notes:30]
$3.0
 million payment due pursuant to the Seller Note on 
 March 28, 2019 
and the 
second

[0001437749-19-015632:notes:31]
$3.0
 million payment plus interest on 
 May 23, 2019.

[0001437749-19-015632:notes:32]
In 
 December 2015, 
the Company entered into a set of strategic agreements valued at approximately 
$210.0
 million with Inox Wind Ltd. (“Inox” or “Inox Wind”), which includes a multi-year supply contract pursuant to which the Company will supply electrical control systems to Inox and a license agreement allowing Inox to manufacture a limited number of electrical control systems. After Inox purchases the specified number of electrical control systems required under the terms of the supply contract, Inox agreed that the Company will continue as Inox’s preferred supplier and Inox will be required to purchase from the Company a majority of its electrical control systems requirements for an additional 
three
-year period.

[0001437749-19-015632:notes:33]
The Company believes that based on the information presented above and its quarterly management assessment, it has sufficient liquidity to fund its operations and capital expenditures for the next 
twelve
 months following the issuance of the financial statements for the

[0001437749-19-015632:notes:34]
. The Company’s liquidity is highly dependent on its ability to increase revenues, including its ability to collect revenues under its agreements with Inox, its ability to control its operating costs, and its ability to raise additional capital, if necessary. There can be 
no
 assurance that the Company will be able to continue to raise additional capital, on favorable terms or at all, from other sources or execute on any other means of improving liquidity described above.


## amsc:NatureOfBusinessAndOperationsPolicyPolicyTextBlock

[0001437749-19-015632:notes:35]
Nature of the Business and Operations

[0001437749-19-015632:notes:36]
American Superconductor Corporation (together with its subsidiaries, “AMSC®”or the “Company”) was founded on 
 April

[0001437749-19-015632:notes:37]
9,

[0001437749-19-015632:notes:38]
1987.
 The Company is a leading system provider of megawatt-scale power solutions that enhance the performance of the power grid, protect the Navy’s fleet, and lower the cost of wind power. The Company’s system level products leverage its proprietary “smart materials” and “smart software and controls” to provide enhanced resiliency and improved performance of megawatt-scale power flow.

[0001437749-19-015632:notes:39]
These unaudited condensed consolidated financial statements of the Company have been prepared on a going concern basis in accordance with United States generally accepted accounting principles (“GAAP”) and the Securities and Exchange Commission’s (“SEC”) instructions to Form 
10
-Q. The going concern basis of presentation assumes that the Company will continue operations and will be able to realize its assets and discharge its liabilities and commitments in the normal course of business. Certain information and footnote disclosures normally included in the financial statements prepared in accordance with GAAP have been condensed or omitted pursuant to those instructions. The year-end condensed balance sheet data was derived from audited financial statements but does 
not
 include all disclosures required by GAAP. The unaudited condensed consolidated financial statements, in the opinion of management, reflect all adjustments (consisting of normal recurring adjustments) necessary for a fair statement of the results for the interim periods ended

[0001437749-19-015632:notes:40]
2018

[0001437749-19-015632:notes:41]
and the financial position at

[0001437749-19-015632:notes:42]
; however, these results are 
not
 necessarily indicative of results which 
 may 
be expected for the full year. The interim condensed consolidated financial statements, and notes thereto, should be read in conjunction with the audited consolidated financial statements for the year ended

[0001437749-19-015632:notes:43]
, and notes thereto, included in the Company’s annual report on Form 
10
-K for the year ended

[0001437749-19-015632:notes:44]
filed with the Securities and Exchange Commission on 
 June 5, 2019.


## amsc:NotesReceivableTableTextBlock

[0001437749-19-015632:notes:45]
| Current assets |  | June 30, 2019 |  |  | March 31, 2019 |  |
| Note receivable, current |  | $ | - |  |  | $ | 3,000 |  |
| Note receivable discount |  |  | — |  |  |  | (112 | ) |
| Total current note receivable |  | $ | - |  |  | $ | 2,888 |  |


## amsc:NotesReceivableTextBlock

[0001437749-19-015632:notes:46]
9.
 Note Receivable

[0001437749-19-015632:notes:47]
The Company entered into the PSA dated 
 February 1, 2018, 
for the sale of the Devens facility (including land, building and building improvements) located at 
64
 Jackson Road, Devens, Massachusetts to 
64
 Jackson, LLC, a limited liability company (subsequently assigned to Jackson 
64
 MGI, LLC) in the amount of 
$23.0
 million. The terms for payment included a 
$1.0
 million security deposit, and a note receivable for 
$6.0
 million payable to the Company with the remaining cash net of certain adjustments for closing costs at the date of settlement. The note receivable was due in 
two

[0001437749-19-015632:notes:48]
$3.0
 million installments plus accrued interest at a rate of 
1.96%
 on 
 March 31, 2019 
and 
 March 31, 2020. 
The note was subordinate to East Boston Savings Bank's mortgage on the Devens property.  The 
first
 installment was paid on 
 March 28, 2019 
and the 
second
 installment was paid on 
 May 23, 2019.

[0001437749-19-015632:notes:49]
The note receivable was discounted to its present value of 
$5.7
 million utilizing a discount rate of 
6%,
 which was based on management’s assessment of what an appropriate loan at current market rates would be. The 
$0.3
 million discount was recorded as an offset to the long term portion of the note receivable. In addition, the resulting gain of 
$0.1
 million from the sale of the Devens property which was deferred previously was recorded as a component of the cumulative effect of an accounting change upon the adoption of Accounting Standards Update ("ASU") 
2017
-
05

[0001437749-19-015632:notes:50]
Other Income - Gains and Losses from the Derecognition of Non-financial Assets (Subtopic 
610
-
20
) 
which was issued as a part of ASU 
2014
-
09

[0001437749-19-015632:notes:51]
Revenue from Contracts with Customers (Topic 
606
)
. This gain was recorded as an offset to the opening accumulated deficit in the 
three
 months ended 
 June 30, 2018.

[0001437749-19-015632:notes:52]
Note receivable as of


## us-gaap:AccountsPayableAndAccruedLiabilitiesDisclosureTextBlock

[0001437749-19-015632:notes:53]
11.
 Accounts Payable and Accrued Expenses

[0001437749-19-015632:notes:54]
Accounts payable and accrued expenses at

[0001437749-19-015632:notes:55]
|  |  | June 30, 2019 |  |  | March 31, 2019 |  |
| Accounts payable |  | $ | 4,088 |  |  | $ | 2,939 |  |
| Accrued inventories in-transit |  |  | 307 |  |  |  | 244 |  |
| Accrued other miscellaneous expenses |  |  | 1,794 |  |  |  | 1,759 |  |
| Advanced deposits |  |  | 745 |  |  |  | 631 |  |
| Accrued compensation |  |  | 3,678 |  |  |  | 5,404 |  |
| Income taxes payable |  |  | 3,601 |  |  |  | 3,363 |  |
| Accrued warranty |  |  | 1,606 |  |  |  | 1,545 |  |
| Total |  | $ | 15,819 |  |  | $ | 15,885 |  |

[0001437749-19-015632:notes:56]
The Company generally provides a 
one
 to 
three
 year warranty on its products, commencing upon delivery or installation where applicable. A provision is recorded upon revenue recognition to cost of revenues for estimated warranty expense based on historical experience.

[0001437749-19-015632:notes:57]
[same as prior period, unchanged from 0001628280-19-000966:notes:5]

[0001437749-19-015632:notes:58]
|  |  | Three Months Ended June 30, |  |
|  |  | 2019 |  |  | 2018 |  |
| Balance at beginning of period |  | $ | 1,545 |  |  | $ | 1,769 |  |
| Change in accruals for warranties during the period |  |  | 85 |  |  |  | 104 |  |
| Settlements during the period |  |  | (24 | ) |  |  | (121 | ) |
| Balance at end of period |  | $ | 1,606 |  |  | $ | 1,752 |  |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001437749-19-015632:notes:59]
15.
 Commitments and Contingencies

[0001437749-19-015632:notes:60]
Legal Contingencies

[0001437749-19-015632:notes:61]
From time to time, the Company is involved in legal and administrative proceedings and claims of various types. The Company records a liability in its consolidated financial statements for these matters when a loss is known or considered probable and the amount can be reasonably estimated. The Company reviews these estimates each accounting period as additional information is known and adjusts the loss provision when appropriate. If a matter is both probable to result in a liability and the amounts of loss can be reasonably estimated, the Company estimates and discloses the possible loss or range of loss to the extent necessary to make the consolidated financial statements 
not
 misleading. If the loss is 
not
 probable or cannot be reasonably estimated, a liability is 
not
 recorded in its consolidated financial statements.

[0001437749-19-015632:notes:62]
Other

[0001437749-19-015632:notes:63]
The Company enters into long-term construction contracts with customers that require the Company to obtain performance bonds. The Company is required to deposit an amount equivalent to some or all the face amount of the performance bonds into an escrow account until the termination of the bond. When the performance conditions are met, amounts deposited as collateral for the performance bonds are returned to the Company. In addition, the Company has various contractual arrangements in which minimum quantities of goods or services have been committed to be purchased on an annual basis.

[0001437749-19-015632:notes:64]
As of

[0001437749-19-015632:notes:65]
, the Company had $

[0001437749-19-015632:notes:66]
0.7

[0001437749-19-015632:notes:67]
million of restricted cash included in long-term assets. These amounts included in restricted cash primarily represent deposits to secure letters of credit for various supply contracts. These deposits are held in interest bearing accounts.  As part of the agreement with Commonwealth Edison Company to install the Resilient Electric Grid ("REG") system in Chicago, the Company agreed to deliver an irrevocable letter of credit in the amount of 
$5.0
 million to secure certain Company obligations under the Subcontract Agreement.  The funds to secure the 
$5.0
 million letter of credit were deposited in an escrow account on 
 July 1, 2019.


## us-gaap:ContractWithCustomerAssetAndLiabilityTableTextBlock

[0001437749-19-015632:notes:68]
|  |  | Unbilled Accounts Receivable |  |  | Deferred Program Costs |  |  | Contract Liabilities |  |
| Beginning balance as of March 31, 2018 |  | $ | 3,016 |  |  | $ | 2,567 |  |  | $ | 21,937 |  |
| Impact of adoption of ASC 606 |  |  | — |  |  |  | (1,599 | ) |  |  | (2,657 | ) |
| Increases for costs incurred to fulfill performance obligations |  |  | — |  |  |  | 1,132 |  |  |  | — |  |
| Increase (decrease) due to customer billings |  |  | (3,221 | ) |  |  | — |  |  |  | 4,281 |  |
| Decrease due to cost recognition on completed performance obligations |  |  | — |  |  |  | (48 | ) |  |  | — |  |
| Increase (decrease) due to recognition of revenue based on transfer of control of performance obligations |  |  | 4,824 |  |  |  | (9 | ) |  |  | (3,324 | ) |
| Other changes and FX impact |  |  | (16 | ) |  |  | 34 |  |  |  | (764 | ) |
| Ending balance as of June 30, 2018 |  | $ | 4,603 |  |  | $ | 2,077 |  |  | $ | 19,473 |  |
|  |  | Unbilled Accounts Receivable |  |  | Deferred Program Costs |  |  | Contract Liabilities |  |
| Beginning balance as of March 31, 2019 |  | $ | 2,213 |  |  | $ | 318 |  |  | $ | 15,521 |  |
| Increases for costs incurred to fulfill performance obligations |  |  | 0 |  |  |  | 771 |  |  |  | 0 |  |
| Increase (decrease) due to customer billings |  |  | (1,584 | ) |  |  | 0 |  |  |  | 10,857 |  |
| Decrease due to cost recognition on completed performance obligations |  |  | 0 |  |  |  | (4 | ) |  |  | 0 |  |
| Increase (decrease) due to recognition of revenue based on transfer of control of performance obligations |  |  | 1,467 |  |  |  | 0 |  |  |  | (7,761 | ) |
| Other changes and FX impact |  |  | (3 | ) |  |  | 3 |  |  |  | 73 |  |
| Ending balance as of June 30, 2019 |  | $ | 2,093 |  |  | $ | 1,088 |  |  | $ | 18,690 |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001437749-19-015632:notes:69]
13.
 Warrants and Derivative Liabilities

[0001437749-19-015632:notes:70]
The Company accounts for its warrants and contingent consideration as liabilities due to certain adjustment provisions within the instruments, which require that they be recorded at fair value. The warrants are subject to revaluation at each balance sheet date and any change in fair value is recorded as a change in fair value of warrants until the earlier of its expiration or its exercise at which time the warrant liability will be reclassified to equity. The Company calculated the fair value of the warrants utilizing an integrated lattice model. See Note 
6,
 "Fair Value Measurements", for further discussion.

[0001437749-19-015632:notes:71]
[same as prior period, unchanged from 0001628280-19-000966:notes:25]

[0001437749-19-015632:notes:72]
On 
 December 19, 2014, 
the Company entered into a 
second
 amendment to the Loan and Security Agreement with Hercules (the "Hercules Second Amendment"). In conjunction with the Hercules Second Amendment, the Company issued Hercules a warrant to purchase 
58,823
 shares of the Company’s common stock (the "Hercules Warrant") which replaced the First Warrant and the Second Warrant.  The Hercules Warrant was exercisable at any time after its issuance at an exercise price of 
$7.85
 per share, subject to certain price-based and other anti-dilution adjustments, including the equity offering in 
 May 2017, 
the acquisition of ITC with common stock in 
 September 2017 
and sales of common stock under the ATM entered into in 
 January 2017.  
This warrant had a fair value of 
$0.4
 million as of 
 March 31, 2019.  
On 
 April 8, 2019 
Hercules notified the Company of its intent to exercise this warrant on a cashless basis.  Hercules received 
22,821
 shares of the Company's common stock on 
 April 17, 2019.  
As a result of this exercise the Company recorded a net gain of 
$0.1
 million to change in fair value of warrants, resulting from the decrease in the fair value upon exercise of the Hercules Warrant during the 
three
 months ended 
 June 30, 2019.

[0001437749-19-015632:notes:73]
November 2014 
Warrant

[0001437749-19-015632:notes:74]
On 
 November 13, 2014, 
the Company completed an offering of 
909,090
 units of the Company’s common stock with Hudson Bay Capital. Each unit consisted of 
one
 share of the Company’s common stock and 
0.9
 of a warrant to purchase 
one
 share of common stock, or a warrant to purchase in the aggregate 
818,181
 shares (the 
 “November 2014 
Warrant”).  The 
 November 2014 
Warrant is exercisable at any time, at an exercise price equal to 
$7.81
 per share, subject to certain price-based and other anti-dilution adjustments including those noted above, and expires on 
 November

[0001437749-19-015632:notes:75]
13,

[0001437749-19-015632:notes:76]
2019.

[0001437749-19-015632:notes:77]
Following is a summary of the key assumptions used to calculate the fair value of the 
 November 2014 
Warrant:

[0001437749-19-015632:notes:78]
| Fiscal Year 2019 |  | June 30, 2019 |  |
| Risk-free interest rate |  | 2.11% |  |
| Expected annual dividend yield |  | — |  |
| Expected volatility |  | 60.58% |  |
| Term (years) |  | 0.37 |  |
| Fair value |  | $1.7 million |  |

[0001437749-19-015632:notes:79]
|  |  | March 31, |  | December 31, |  | September 30, |  | June 30, |  | March 31, |
| Fiscal Year 2018 |  | 2019 |  | 2018 |  | 2018 |  | 2018 |  | 2018 |
| Risk-free interest rate |  | 2.43% |  | 2.61% |  | 2.62% |  | 2.40% |  | 2.20% |
| Expected annual dividend yield |  | — |  | — |  | — |  | — |  | — |
| Expected volatility |  | 75.61% |  | 70.29% |  | 63.66% |  | 67.40% |  | 65.86% |
| Term (years) |  | 0.62 |  | 0.87 |  | 1.12 |  | 1.37 |  | 1.62 |
| Fair value |  | $4.6 million |  | $3.6 million |  | $1.3 million |  | $1.6 million |  | $1.1 million |

[0001437749-19-015632:notes:80]
The Company recorded a net gain of $

[0001437749-19-015632:notes:81]
2.9

[0001437749-19-015632:notes:82]
million resulting from the 
decrease
 in the fair value of the 
 November 2014 
Warrant during the

[0001437749-19-015632:notes:83]
. The Company recorded a net loss of 
$0.5
 million resulting from the increase in the fair value of the 
 November 2014 
Warrant during the

[0001437749-19-015632:notes:84]
June 30, 2018

[0001437749-19-015632:notes:85]
.


## us-gaap:DisaggregationOfRevenueTableTextBlock

[0001437749-19-015632:notes:86]
|  |  | Three Months Ended June 30, 2019 |  |
| Product Line: |  | Grid |  |  | Wind |  |
| Equipment and systems |  | $ | 8,354 |  |  | $ | 3,505 |  |
| Services and technology development |  |  | 1,501 |  |  |  | 410 |  |
| Total |  | $ | 9,855 |  |  | $ | 3,915 |  |
| Region: |  |  |  |  |  |  |  |  |
| Americas |  | $ | 7,801 |  |  | $ | 46 |  |
| Asia Pacific |  |  | 1,827 |  |  |  | 3,856 |  |
| EMEA |  |  | 227 |  |  |  | 13 |  |
| Total |  | $ | 9,855 |  |  | $ | 3,915 |  |
|  |  | Three Months Ended June 30, 2018 |  |
| Product Line: |  | Grid |  |  | Wind |  |
| Equipment and systems |  | $ | 7,462 |  |  | $ | 3,492 |  |
| Services and technology development |  |  | 1,467 |  |  |  | 186 |  |
| Total |  | $ | 8,929 |  |  | $ | 3,678 |  |
| Region: |  |  |  |  |  |  |  |  |
| Americas |  | $ | 7,496 |  |  | $ | 23 |  |
| Asia Pacific |  |  | 808 |  |  |  | 3,595 |  |
| EMEA |  |  | 625 |  |  |  | 60 |  |
| Total |  | $ | 8,929 |  |  | $ | 3,678 |  |


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001437749-19-015632:notes:87]
3.
 Stock-Based Compensation

[0001437749-19-015632:notes:88]
The Company accounts for its stock-based compensation at fair value. The following table summarizes stock-based compensation expense by financial statement line item for the

[0001437749-19-015632:notes:89]
(in thousands):

[0001437749-19-015632:notes:90]
|  |  | Three Months Ended June 30, |  |
|  |  | 2019 |  |  | 2018 |  |
| Cost of revenues |  | $ | 3 |  |  | $ | 40 |  |
| Research and development |  |  | 10 |  |  |  | 51 |  |
| Selling, general and administrative |  |  | 236 |  |  |  | 694 |  |
| Total |  | $ | 249 |  |  | $ | 785 |  |

[0001437749-19-015632:notes:91]
The Company issued

[0001437749-19-015632:notes:92]
13,174

[0001437749-19-015632:notes:93]
shares of immediately vested common stock and

[0001437749-19-015632:notes:94]
160,500

[0001437749-19-015632:notes:95]
shares of restricted stock awards during the

[0001437749-19-015632:notes:96]
, and issued

[0001437749-19-015632:notes:97]
34,480

[0001437749-19-015632:notes:98]
276,000

[0001437749-19-015632:notes:99]
.  These restricted stock awards generally vest over 
2
-
3
 years.  Awards for restricted stock include both time-based and performance-based awards.  For options and restricted stock awards that vest upon the passage of time, expense is being recorded over the vesting period.  Performance-based awards are expensed over the requisite service period based on probability of achievement.

[0001437749-19-015632:notes:100]
The estimated fair value of the Company’s stock-based awards, less expected annual forfeitures, is amortized over the awards’ service period. The total unrecognized compensation cost for unvested outstanding stock options was less than $

[0001437749-19-015632:notes:101]
0.1

[0001437749-19-015632:notes:102]
million at

[0001437749-19-015632:notes:103]
. This expense will be recognized over a weighted average expense period of approximately

[0001437749-19-015632:notes:104]
1.9

[0001437749-19-015632:notes:105]
years. The total unrecognized compensation cost for unvested outstanding restricted stock was $

[0001437749-19-015632:notes:106]
3.4

[0001437749-19-015632:notes:107]
. This expense will be recognized over a weighted-average expense period of approximately

[0001437749-19-015632:notes:108]
1.5

[0001437749-19-015632:notes:109]
years.

[0001437749-19-015632:notes:110]
The Company granted

[0001437749-19-015632:notes:111]
5,939

[0001437749-19-015632:notes:112]
stock options during the

[0001437749-19-015632:notes:113]
.  The Company did 
not
 grant any stock options during the

[0001437749-19-015632:notes:114]
.  The stock options granted during the

[0001437749-19-015632:notes:115]
will vest over

[0001437749-19-015632:notes:116]
2
 ye
ars. The weighted average assumptions used in the Black Scholes valuation model for stock options granted during the

[0001437749-19-015632:notes:117]
are as follows:

[0001437749-19-015632:notes:118]
|  |  | Three Months Ended June 30, |  |
|  |  | 2019 |  |  | 2018 |  |
| Expected volatility |  |  | 66.5 | % |  |  | N/A |  |
| Risk-free interest rate |  |  | 1.8 | % |  |  | N/A |  |
| Expected life (years) |  |  | 5.91 |  |  |  | N/A |  |
| Dividend yield |  | None |  |  |  | N/A |  |


## us-gaap:EarningsPerShareTextBlock

[0001437749-19-015632:notes:119]
4.
 Computation of Net Loss per Common Share

[0001437749-19-015632:notes:120]
Basic net loss per share (“EPS”) is computed by dividing net loss by the weighted-average number of common shares outstanding for the period. Where applicable, diluted EPS is computed by dividing the net loss by the weighted-average number of common shares and dilutive common equivalent shares outstanding during the period, calculated using the treasury stock method. Common equivalent shares include the effect of restricted stock, exercise of stock options and warrants and contingently issuable shares. Stock options and warrants that are out-of-the-money with exercise prices greater than the average market price of the underlying Common Shares and shares of performance based restricted stock where the contingency was 
not
 met are excluded from the computation of diluted EPS as the effect of their inclusion would be anti-dilutive. For the

[0001437749-19-015632:notes:121]
,

[0001437749-19-015632:notes:122]
1.0

[0001437749-19-015632:notes:123]
million shares were 
not
 included in the calculation of diluted EPS as they were considered anti-dilutive, of which

[0001437749-19-015632:notes:124]
0.2

[0001437749-19-015632:notes:125]
million shares relate to outstanding stock options, and

[0001437749-19-015632:notes:126]
0.8

[0001437749-19-015632:notes:127]
million shares relate to outstanding warrants. For the

[0001437749-19-015632:notes:128]
, 
1.1
 million shares were 
not
 included in the calculation of diluted EPS as they were considered anti-dilutive, of which 
0.2
 million shares relate to outstanding stock options, and 
0.9
 million shares relate to outstanding warrants.

[0001437749-19-015632:notes:129]
The following table reconciles the numerators and denominators of the earnings per share calculation for the

[0001437749-19-015632:notes:130]
(in thousands, except per share data):

[0001437749-19-015632:notes:131]
|  |  | Three Months Ended June 30, |  |
|  |  | 2019 |  |  | 2018 |  |
| Numerator: |  |  |  |  |  |  |  |  |
| Net loss |  | $ | (3,539 | ) |  | $ | (4,737 | ) |
| Denominator: |  |  |  |  |  |  |  |  |
| Weighted-average shares of common stock outstanding |  |  | 21,499 |  |  |  | 20,999 |  |
| Weighted-average shares subject to repurchase |  |  | (985 | ) |  |  | (832 | ) |
| Shares used in per-share calculation — basic |  |  | 20,514 |  |  |  | 20,167 |  |
| Shares used in per-share calculation — diluted |  |  | 20,514 |  |  |  | 20,167 |  |
| Net loss per share — basic |  | $ | (0.17 | ) |  | $ | (0.23 | ) |
| Net loss per share — diluted |  | $ | (0.17 | ) |  | $ | (0.23 | ) |


## us-gaap:FairValueDisclosuresTextBlock

[0001437749-19-015632:notes:132]
6.
 Fair Value Measurements

[0001437749-19-015632:notes:133]
A valuation hierarchy for disclosure of the inputs to valuation used to measure fair value has been established. This hierarchy prioritizes the inputs into 
three
 broad levels as follows:

[0001437749-19-015632:notes:134]
| Level 1 | - | Inputs are unadjusted quoted prices in active markets for identical assets or liabilities that the Company has the ability to access at the measurement date. |
| Level 2 | - | Inputs include quoted prices for similar assets and liabilities in active markets, quoted prices for identical or similar assets or liabilities in markets that are not active, inputs other than quoted prices that are observable for the asset or liability, and inputs that are derived principally from or corroborated by observable market data by correlation or other means (market corroborated inputs). |
| Level 3 | - | Unobservable inputs that reflect the Company’s assumptions that market participants would use in pricing the asset or liability. The Company develops these inputs based on the best information available, including its own data. |

[0001437749-19-015632:notes:135]
The Company provides a gross presentation of activity within Level 
3
 measurement roll-forward and details of transfers in and out of Level 
1
 and 
2
 measurements.  A change in the hierarchy of an investment from its current level is reflected in the period during which the pricing methodology of such investment changes.  Disclosure of the transfer of securities from Level 
1
 to Level 
2
 or Level 
3
 is made in the event that the related security is significant to total cash and investments.  The Company did 
not
 have any transfers of assets and liabilities from Level 
1,
 Level 
2
 or Level 
3
 of the fair value measurement hierarchy during the

[0001437749-19-015632:notes:136]
[same as prior period, unchanged from 0001628280-19-000966:notes:49]

[0001437749-19-015632:notes:137]
The following table provides the assets and liabilities carried at fair value on a recurring basis, measured as of

[0001437749-19-015632:notes:138]
|  |  | Total Carrying Value |  |  | Quoted Prices in Active Markets (Level 1) |  |  | Significant Other Observable Inputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |
| June 30, 2019: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash equivalents |  | $ | 67,222 |  |  | $ | 67,222 |  |  | $ | — |  |  | $ | — |  |
| Derivative liabilities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Warrants |  | $ | 1,702 |  |  | $ | — |  |  | $ | — |  |  | $ | 1,702 |  |

[0001437749-19-015632:notes:139]
|  |  | Total Carrying Value |  |  | Quoted Prices in Active Markets (Level 1) |  |  | Significant Other Observable Inputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |
| March 31, 2019: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash equivalents |  | $ | 41,839 |  |  | $ | 41,839 |  |  | $ | — |  |  | $ | — |  |
| Derivative liabilities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Warrants |  | $ | 4,942 |  |  | $ | — |  |  | $ | — |  |  | $ | 4,942 |  |

[0001437749-19-015632:notes:140]
[same as prior period, unchanged from 0001628280-19-000966:notes:53]

[0001437749-19-015632:notes:141]
|  |  | Warrants |  |
| April 1, 2019 |  | $ | 4,942 |  |
| Mark to market adjustment |  |  | (2,946 | ) |
| Warrant exercise |  |  | (294 | ) |
| Balance at June 30, 2019 |  | $ | 1,702 |  |

[0001437749-19-015632:notes:142]
|  |  | Warrants |  |
| April 1, 2018 |  | $ | 1,217 |  |
| Mark to market adjustment |  |  | 464 |  |
| Balance at June 30, 2018 |  | $ | 1,681 |  |

[0001437749-19-015632:notes:143]
[same as prior period, unchanged from 0001628280-19-000966:notes:56]

[0001437749-19-015632:notes:144]
[same as prior period, unchanged from 0001628280-19-000966:notes:57]

[0001437749-19-015632:notes:145]
Cash equivalents consist of highly liquid instruments with maturities of 
three
 months or less that are regarded as high quality, low risk investments and are measured using such inputs as quoted prices, and are classified within Level 
1
 of the valuation hierarchy. Cash equivalents consist principally of certificates of deposits and money market accounts.

[0001437749-19-015632:notes:146]
[same as prior period, unchanged from 0001628280-19-000966:notes:59]

[0001437749-19-015632:notes:147]
Warrants were issued in conjunction with an equity offering to Hudson Bay Capital in 
 November 2014 
and a Loan and Security Agreement with Hercules Technology Growth Capital, Inc. (“Hercules”). The warrants issued to Hercules were exercised on 
 April 8, 2019.  
Outstanding warrants are subject to revaluation at each balance sheet date, and any change in fair value will be recorded as a change in fair value in derivatives and warrants until the earlier of their exercise or expiration.

[0001437749-19-015632:notes:148]
The Company relies on various assumptions in a lattice model to determine the fair value of warrants. The Company has valued the warrants within Level 
3
 of the valuation hierarchy. See Note 
13,
 “Warrants and Derivative Liabilities,” for additional information including a discussion of the warrants and the valuation assumptions used.


## us-gaap:GoodwillDisclosureTextBlock

[0001437749-19-015632:notes:149]
5.
 Goodwill

[0001437749-19-015632:notes:150]
The Company did 
not
 identify any triggering events in the

[0001437749-19-015632:notes:151]
, that would require interim impairment testing of goodwill.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001437749-19-015632:notes:152]
12.
 Income Taxes

[0001437749-19-015632:notes:153]
The Company recorded an income tax expense of $

[0001437749-19-015632:notes:154]
million and an income tax benefit of less than 
$0.1
 million in the

[0001437749-19-015632:notes:155]
, respectively.

[0001437749-19-015632:notes:156]
Accounting for income taxes requires a 
two
-step approach to recognizing and measuring uncertain tax positions.  The 
first
 step is to evaluate the tax position for recognition by determining if, based on the technical merits, it is more likely than 
not
 the position will be sustained upon audit, including resolution of related appeals or litigation processes, if any.  The 
second
 step is to measure the tax benefit as the largest amount that is more than 
50%
 likely to be realized upon ultimate settlement.  The Company re-evaluates these uncertain tax positions on a quarterly basis.  The evaluation is based on factors including, but 
not
 limited to, changes in facts or circumstances, changes in tax law, effectively settled issues under audit and new audit activity.  Any changes in these factors could result in the recognition of a tax benefit or an additional charge to the tax provision.  The Company did 
not
 identify any uncertain tax positions in the

[0001437749-19-015632:notes:157]
and did 
not
 have any gross unrecognized tax benefits as of


## us-gaap:InventoryDisclosureTextBlock

[0001437749-19-015632:notes:158]
8.
 Inventory

[0001437749-19-015632:notes:159]
Inventory, net of reserves, at

[0001437749-19-015632:notes:160]
|  |  | June 30, 2019 |  |  | March 31, 2019 |  |
| Raw materials |  | $ | 6,604 |  |  | $ | 5,474 |  |
| Work-in-process |  |  | 1,039 |  |  |  | 1,922 |  |
| Finished goods |  |  | 3,193 |  |  |  | 4,405 |  |
| Deferred program costs |  |  | 1,088 |  |  |  | 318 |  |
| Net inventory |  | $ | 11,924 |  |  | $ | 12,119 |  |

[0001437749-19-015632:notes:161]
The Company recorded inventory write-downs of $

[0001437749-19-015632:notes:162]
million and 
$0.1
 million for the

[0001437749-19-015632:notes:163]
, respectively. These write-downs were based on the Company's evaluation of its inventory on hand for excess quantities and obsolescence.

[0001437749-19-015632:notes:164]
Deferred program costs as of

[0001437749-19-015632:notes:165]
primarily represent costs incurred on programs where the Company needs to complete performance obligations before the related revenue and costs will be recognized.


## us-gaap:LeaseCostTableTextBlock

[0001437749-19-015632:notes:166]
|  |  | June 30, 2019 |  |
| Operating Lease: |  |  |  |  |
| Operating lease costs - fixed |  | $ | 178 |  |
| Operating lease costs - variable |  |  | 21 |  |
| Short-term lease costs |  |  | 233 |  |
| Total lease costs |  |  | 432 |  |


## us-gaap:LesseeOperatingLeaseLiabilityMaturityTableTextBlock

[0001437749-19-015632:notes:167]
|  |  | Operating Leases |  |
| Year ended March 31, |  |  |  |  |
| 2020 |  | $ | 496 |  |
| 2021 |  |  | 673 |  |
| 2022 |  |  | 653 |  |
| 2023 |  |  | 627 |  |
| 2024 |  |  | 564 |  |
| Thereafter |  |  | 1,896 |  |
| Total minimum lease payments |  |  | 4,909 |  |
| Less: interest |  |  | (1,136 | ) |
| Present value of lease liabilities |  |  | 3,773 |  |


## us-gaap:LesseeOperatingLeasesTextBlock

[0001437749-19-015632:notes:168]
14.
 Leases

[0001437749-19-015632:notes:169]
On 
 April 1, 2019, 
the Company adopted ASU 
2016
-
02,

[0001437749-19-015632:notes:170]
Leases (Topic 
842
)
 ("ASC 
842"
), using the modified retrospective approach. The Company elected the package of practical expedients available in the standard and as a result, did 
not
 reassess the lease classification of existing contracts or leases or the initial direct costs associated with existing leases. The Company did 
not
 elect the hindsight practical expedient, and evaluated lease terms for existing leases. The Company has also elected the practical expedient to 
not
 separate lease components and non-lease components and will account for the leases as a single lease component for all classes of leases.

[0001437749-19-015632:notes:171]
As a result of the adoption of ASC 
842,
 the Company recognized lease right-of-use assets of 
$3.8
 million, and operating lease liabilities of 
$3.8
 million. There was 
no
 impact to the condensed consolidated statements of operations or stockholders' equity for the adoption of ASC 
842.

[0001437749-19-015632:notes:172]
No
 impairment was recognized on the right-of-use asset upon adoption. These adjustments are detailed as follows:

[0001437749-19-015632:notes:173]
|  |  | March 31, 2019 |  |  | ASC 842 Adjustment |  |  | April 1, 2019 |  |
| Operating Leases: |  |  |  |  |  |  |  |  |  |  |  |  |
| Right of use asset |  | $ | - |  |  | $ | 3,795 |  |  | $ | 3,795 |  |
| Total operating lease right-of-use asset |  |  | 0 |  |  |  | 3,795 |  |  |  | 3,795 |  |
| Operating lease liabilities – ST |  | $ | - |  |  | $ | 309 |  |  | $ | 309 |  |
| Operating lease liabilities – LT |  |  | 0 |  |  |  | 3,512 |  |  |  | 3,512 |  |
| Total operating lease liabilities |  |  | 0 |  |  |  | 3,821 |  |  |  | 3,821 |  |
| Weighted-average remaining lease term |  |  |  |  |  |  |  |  |  | 7.69 years |  |
| Weighted-average discount rate |  |  |  |  |  |  |  |  |  |  | 7.06 | % |

[0001437749-19-015632:notes:174]
All significant lease arrangements are recognized at lease commencement.  Operating lease right–of-use assets and lease liabilities are recognized at commencement. The operating lease right-of-use asset includes any lease payments related to initial direct cost and prepayments and excludes any lease incentives. Lease expense is recognized on a straight-line basis over the lease term.  The Company enters into a variety of operating lease agreements through the normal course of its business, but primarily real estate leases to support its operations. The agreements generally provide for fixed minimum rental payments and the payment of real estate taxes and insurance. Many of these leases have 
one
 or more renewal options that allow the Company, at its discretion, to renew the lease for varying periods up to 
five
 years or to terminate the lease. Only renewal options or termination rights that the Company believed were likely to be exercised were included in the lease calculations.

[0001437749-19-015632:notes:175]
The Company also enters into leases for vehicles, IT equipment and service agreements, and other leases related to its manufacturing operations that are also included in the right-of-use asset and lease liability accounts if they are for a term of longer than 
twelve
 months. However, many of these leases are either short-term in nature or immaterial. The Company has made the policy election to exclude short term leases from the balance sheet.

[0001437749-19-015632:notes:176]
The discount rate was calculated using an incremental borrowing rate based on an assessment prepared by the Company through the use of Company credit ratings, consideration of its lease populations potential risk to its total capital structure, and a market rate for a collateralized loan for its risk profile, calculated by a 
third
 party. The Company elected to apply the discount rate using the remaining lease term at the date of adoption.

[0001437749-19-015632:notes:177]
The Company did 
not
 identify any leases that are classified as financing leases.

[0001437749-19-015632:notes:178]
Supplemental balance sheet information related to leases at 
 June 30, 2019 
are as follows:

[0001437749-19-015632:notes:179]
The costs related to the Company's leases for the 
three
 months ended 
 June

[0001437749-19-015632:notes:180]
30,

[0001437749-19-015632:notes:181]
2019
 are as follows:

[0001437749-19-015632:notes:182]
The Company’s estimated minimum future lease obligations under the Company's leases are as follows:


## us-gaap:NewAccountingPronouncementsAndChangesInAccountingPrinciplesTextBlock

[0001437749-19-015632:notes:183]
18.
 Recent Accounting Pronouncements

[0001437749-19-015632:notes:184]
In 
 February 2016, 
the FASB issued ASU 
2016
-
02,

[0001437749-19-015632:notes:185]
Leases (Topic 
842
)
. The guidance in this ASU supersedes the leasing guidance in Topic 
840,

[0001437749-19-015632:notes:186]
Leases
. Under the new guidance, lessees are required to recognize lease assets and lease liabilities on the balance sheet for all leases with terms longer than 
12
 months. Leases will be classified as either finance or operating, with classification affecting the pattern of expense recognition in the income statement. This ASU and its amendments are effective for fiscal years beginning after 
 December 15, 2018, 
including interim periods within those fiscal years.

[0001437749-19-015632:notes:187]
|  | • | In July 2018, the FASB issued ASU 2018-10, Codification improvements to Topic 842, Leases. The amendments in ASU 2018-10 provide more clarification in regards to the application and requirements of ASU 2016-02. |

[0001437749-19-015632:notes:188]
|  | • | In July 2018, the FASB issued ASU 2018-11, Topic 842, Leases - Targeted improvements. The amendments in ASU 2018-11 provide for the option to adopt the standard prospectively and recognize a cumulative-effect adjustment to the opening balance of retained earnings as well as offer a new practical expedient that will allow the Company to elect, by class of underlying asset, to not separate non-lease and lease components in certain circumstances and instead to account for those components as a single item. |

[0001437749-19-015632:notes:189]
ASU 
2016
-
02
 became effective on 
 April 1, 2019, 
and the Company adopted the standard using the modified retrospective transition method, which impacted all leases existing at, or entered into after, the period of adoption. For all leases existing at the time of adoption the Company recognized a right-of-use asset and lease liability on the balance sheet.  See Note 
14
 "Leases" for additional information.

[0001437749-19-015632:notes:190]
In 
 June 2016, 
the FASB issued ASU 
2016
-
13,

[0001437749-19-015632:notes:191]
Financial Instruments-Credit Losses (Topic 
326
): Measurement of Credit Losses on Financial Instruments
. The amendments in ASU 
2016
-
13
 will provide more decision-useful information about the expected credit losses on financial instruments and other commitments to extend credit held by a reporting entity at each reporting date. The ASU is effective for annual reporting periods beginning after 
 December 15, 2019, 
including interim periods within that year.  The Company is currently evaluating the impact, if any, the adoption of ASU 
2016
-
13

[0001437749-19-015632:notes:192]
may 
have on its consolidated financial statements.

[0001437749-19-015632:notes:193]
In 
 July 2017, 
the FASB issued ASU 
2017
-
11,

[0001437749-19-015632:notes:194]
Earnings per Share (Topic

[0001437749-19-015632:notes:195]
260
), 
Distinguishing Liabilities from Equity (Topic 
480
), and Derivatives and Hedging (Topic 
815
)
. The amendments in ASU 
2017
-
11
 provide guidance for freestanding equity-linked financial instruments, such as warrants and conversion options in convertible debt or preferred stock, and should 
no
 longer be accounted for as a derivative liability at fair value as a result of the existence of a down round feature. The ASU is effective for annual reporting periods beginning after 
 December 15, 2018, 
including interim periods within those periods. As of 
 April 1, 2019, 
the Company has adopted ASU 
2017
-
11
 and noted 
no
 significant impact on its consolidated financial statements, primarily due to the put option feature within the Company's warrant agreements which requires continued liability classification under ASC 
480.

[0001437749-19-015632:notes:196]
In 
 August 2017, 
the FASB issued ASU 
2017
-
12,

[0001437749-19-015632:notes:197]
Derivatives and Hedging (Topic 
815
): Targeted Improvements to Accounting for Hedging Activities
. The amendments in ASU 
2017
-
12
 provide improved financial reporting of hedging relationships to better portray the economic results of an entity’s risk management activities in its financial statements. In addition, the amendments in this update make certain targeted improvements to simplify the application of the hedge accounting guidance. The ASU is effective for annual reporting periods beginning after 
 December 15, 2018, 
including interim periods within those periods. As of 
 April 1, 2019, 
the Company has adopted ASU 
2017
-
12
 and noted 
no
 significant impact on its consolidated financial statements, primarily due to the fact that there are 
no
 longer any hedging instruments included in its results.

[0001437749-19-015632:notes:198]
In 
 June 2018, 
the FASB issued ASU 
2018
-
08,

[0001437749-19-015632:notes:199]
Not
-For-Profit Entities (Topic 
958
): Clarifying the Scope and the Accounting Guidance for Contributions Received and Contributions Made.  The amendments in ASU 
2018
-
08
 assist entities in (
1
) evaluating whether transactions should be accounted for as contributions (nonreciprocal transactions) within the scope of Topic 
958,

[0001437749-19-015632:notes:200]
Not
-for-Profit Entities, or as exchange (reciprocal) transactions subject to other guidance and (
2
) determining whether a contribution is conditional.  The ASU is effective for annual reporting periods beginning after 
 December 15, 2018, 
including interim periods within those periods. As of 
 April 1, 2019, 
the Company has adopted ASU 
2018
-
08
 and noted additional disclosures within its revenue footnote to appropriately present the revenue related to its grant revenue.

[0001437749-19-015632:notes:201]
In 
 August 2018, 
the FASB issued ASU 
2018
-
13,

[0001437749-19-015632:notes:202]
Fair Value Measurement (Topic 
820
): Changes to the Disclosure Requirements for Fair Value Measurement
. The amendments in ASU 
2018
-
13
 provide for increased effectiveness of the disclosures made around fair value measurements while including consideration for costs and benefits. The ASU is effective for annual reporting periods beginning after 
 December 15, 2019, 
including interim periods within those periods. The Company is currently evaluating the impact the adoption of ASU 
2018
-
13


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0001437749-19-015632:notes:203]
1.
 Nature of the Business and Operations and Liquidity


## us-gaap:PropertyPlantAndEquipmentDisclosureTextBlock

[0001437749-19-015632:notes:204]
10.
 Property, Plant and Equipment

[0001437749-19-015632:notes:205]
The cost and accumulated depreciation of property and equipment at

[0001437749-19-015632:notes:206]
are as follows (in thousands):

[0001437749-19-015632:notes:207]
|  |  | June 30, 2019 |  |  | March 31, 2019 |  |
| Construction in progress - equipment |  | $ | 1,336 |  |  | $ | 603 |  |
| Equipment and software |  |  | 45,791 |  |  |  | 45,705 |  |
| Furniture and fixtures |  |  | 1,271 |  |  |  | 1,269 |  |
| Leasehold improvements |  |  | 1,983 |  |  |  | 1,955 |  |
| Property, plant and equipment, gross |  |  | 50,380 |  |  |  | 49,532 |  |
| Less accumulated depreciation |  |  | (41,633 | ) |  |  | (40,560 | ) |
| Property, plant and equipment, net |  | $ | 8,747 |  |  | $ | 8,972 |  |

[0001437749-19-015632:notes:208]
Depreciation expense was $

[0001437749-19-015632:notes:209]
1.1

[0001437749-19-015632:notes:210]
million and 
$1.1
 million for the

[0001437749-19-015632:notes:211]
, respectively. Construction in progress - equipment primarily includes capital investments and leasehold improvements in the Company's leased facility in Ayer, Massachusetts.


## us-gaap:ReconciliationOfAssetsFromSegmentToConsolidatedTextBlock

[0001437749-19-015632:notes:212]
|  |  | June 30, 2019 |  |  | March 31, 2019 |  |
| Grid |  | $ | 32,169 |  |  | $ | 31,075 |  |
| Wind |  |  | 11,416 |  |  |  | 8,167 |  |
| Corporate assets |  |  | 76,565 |  |  |  | 80,088 |  |
| Total |  | $ | 120,150 |  |  | $ | 119,330 |  |


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001437749-19-015632:notes:213]
16.
 Restructuring

[0001437749-19-015632:notes:214]
The Company accounts for charges resulting from operational restructuring actions in accordance with ASC Topic 
420,

[0001437749-19-015632:notes:215]
Exit or Disposal Cost Obligations
 (“ASC 
420”
) and ASC Topic 
712,

[0001437749-19-015632:notes:216]
Compensation—Nonretirement Postemployment Benefits 
(“ASC 
712”
). In accounting for these obligations, the Company is required to make assumptions related to the amounts of employee severance, benefits, and related costs and the time period over which leased facilities will remain vacant, sublease terms, sublease rates and discount rates. Estimates and assumptions are based on the best information available at the time the obligation arises. These estimates are reviewed and revised as facts and circumstances dictate; changes in these estimates could have a material effect on the amount accrued on the consolidated balance sheet.

[0001437749-19-015632:notes:217]
The 
$0.3
 million charged to operations in the

[0001437749-19-015632:notes:218]
is related to exit costs incurred in connection with the move of the Company's corporate office.

[0001437749-19-015632:notes:219]
The following table presents restructuring charges and cash payments for the

[0001437749-19-015632:notes:220]
|  |  | Severance pay |  |  | Facility exit and |  |  |  |  |  |
|  |  | and benefits |  |  | Relocation costs |  |  | Total |  |
| Accrued restructuring balance at April 1, 2018 |  | $ | 262 |  |  | $ | 173 |  |  | $ | 435 |  |
| Charges to operations |  |  | 0 |  |  |  | 310 |  |  |  | 310 |  |
| Cash payments |  |  | (97 | ) |  |  | (483 | ) |  |  | (580 | ) |
| Accrued restructuring balance at June 30, 2018 |  | $ | 165 |  |  | $ | — |  |  | $ | 165 |  |

[0001437749-19-015632:notes:221]
All restructuring charges discussed above are included within restructuring in the Company’s unaudited condensed consolidated statements of operations. The Company includes accrued restructuring within accounts payable and accrued expenses.  There was 
no
 restructuring activity in the 
three
 months ending 
 June 30, 2019 
or any remaining accrued restructuring balance as of 
 June 30, 2019.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001437749-19-015632:notes:222]
2.
 Revenue Recognition

[0001437749-19-015632:notes:223]
On 
 April 1, 2018, 
the Company adopted Accounting Standards Codification (“ASC”) 
606,

[0001437749-19-015632:notes:224]
Revenue from Contracts with Customers,

[0001437749-19-015632:notes:225]
and all the related amendments and applied it to all contracts that were 
not
 completed as of 
 April 1, 2018 
using the modified retrospective method.

[0001437749-19-015632:notes:226]
The Company’s revenues in its Grid segment are derived primarily through enabling the transmission and distribution of power, providing planning services that allow it to identify power grid needs and risks, and developing ship protection systems for the U.S. Navy. The Company’s revenues in its Wind segment are derived primarily through supplying advanced power electronics and control systems, licensing its highly engineered wind turbine designs, and providing extensive customer support services to wind turbine manufacturers. The Company records revenue based on a 
five
-step model in accordance with ASC 
606.
 For its customer contracts, the Company identifies the performance obligations, determines the transaction price, allocates the contract transaction price to the performance obligations, and recognizes the revenue when (or as) control of goods or services is transferred to the customer. As of

[0001437749-19-015632:notes:227]
78

[0001437749-19-015632:notes:228]
% of revenue was recognized at the point in time when control transferred to the customer, with the remainder being recognized over time.

[0001437749-19-015632:notes:229]
In the Company's equipment and system product line, each contract with a customer summarizes each product sold to a customer, which typically represent distinct performance obligations. A contract's transaction price is allocated to each distinct performance obligation using the respective standalone selling price which is determined primarily using the cost plus expected margin approach and recognized as revenue when, or as, the performance obligation is satisfied. The majority of the Company’s product sales transfer control to the customer in line with the contracted delivery terms and revenue is recorded at the point in time when title and risk transfer to the customer, as the Company has determined that this is the point in time that control transfers to the customer.

[0001437749-19-015632:notes:230]
The Company's equipment and system product line includes contracts which do 
not
 meet the requirements of an exchange transaction and therefore do 
not
 fall within the scope of ASC 
606.
  As these non-exchange transaction contracts are considered grant revenue and do 
not
 fall within any specific accounting literature, the Company follows guidance within ASC 
606
 by analogy to recognize grant revenue over time.  In the 
three
 months ended 
 June 30, 2019 
the Company recorded 
$0.4
 million in grant revenue, which is included in the Company’s Grid Revenue. There was 
no
 grant revenue in the prior year.

[0001437749-19-015632:notes:231]
In the Company's service and technology development product line, there are several different types of transactions and each begins with a contract with a customer that summarizes each product sold to a customer, which typically represents distinct performance obligations. The technology development transactions are primarily for activities that have 
no
 alternative use and for which a profit can be expected throughout the life of the contract. In these cases, the revenue is recognized over time, but in the instances where the profit cannot be assured throughout the entire contract then the revenue is recognized at a point in time. Each contract's transaction price is allocated to each distinct performance obligation using the respective standalone selling price which is determined primarily using the cost plus expected margin approach. The ongoing service transactions are for service contracts that provide benefit to the customer simultaneously as the Company performs its obligations, and therefore this revenue is recognized ratably over time throughout the effective period of these contracts. The transaction prices on these contracts are allocated based on an adjusted market approach which is re-assessed annually for reasonableness. The field service transactions include contracts for delivery of goods and completion of services made at the customer's requests, which are 
not
 deemed satisfied until the work has been completed and/or the requested goods have been delivered, so all of this revenue is recognized at the point in time when the control changes, and at allocated prices based on the adjusted market approach driven by standard price lists. The royalty transactions are related to certain contract terms on transactions in the Company's equipment and systems product line based on activity as specified in the contracts. The transaction prices of these agreements are calculated based on an adjusted market approach as specified in the contract. The Company reports royalty revenue for usage-based royalties when the sales have occurred. In circumstances when collectability is 
not
 assured and a contract does 
not
 exist under ASC 
606,
 revenue is deferred until a non-refundable payment has been received for substantially all the amount that is due and there are 
no
 further remaining performance obligations.

[0001437749-19-015632:notes:232]
The Company's service contracts can include a purchase order from a customer for specific goods in which each item is a distinct performance obligation satisfied at a point in time at which control of the goods is transferred to the customer which occurs based on the contracted delivery terms or when the requested service work has been completed. The transaction price for these goods is allocated based on the adjusted market approach considering similar transactions under similar circumstances. Service contracts are also derived from ongoing maintenance contracts and extended service-type warranty contracts. In these transactions, the Company is contracted to provide an ongoing service over a specified period of time. As the customer is consuming the benefits as the service is being provided the revenue is recognized over time ratably.

[0001437749-19-015632:notes:233]
The Company’s policy is to 
not
 accept volume discounts, product returns, or rebates and allowances within its contracts. In the event a contract was approved with any of these terms, it would be evaluated for variable consideration, estimated and recorded as a reduction of revenue in the same period the related product revenue was recorded.

[0001437749-19-015632:notes:234]
The Company provides assurance-type warranties on all product sales for a term of typically 
one
 to 
two
 years, and extended service-type warranties at the customers’ option for an additional term ranging up to 
four
 additional years. The Company accrues for the estimated warranty costs for assurance warranties at the time of sale based on historical warranty experience plus any known or expected changes in warranty exposure. For all extended service-type warranties, the Company recognizes the revenue ratably over time during the effective period of the services.

[0001437749-19-015632:notes:235]
The Company records revenue net of sales tax, value added tax, excise tax and other taxes collected concurrent with revenue-producing activities. The Company has elected to recognize the cost for freight and shipping when control over the products sold passes to customers and revenue is recognized. The Company has elected to recognize incremental costs of obtaining a contract as expense when incurred except in contracts where the amortization period would exceed 
twelve
 months; in such cases the long term amount will be assessed for materiality. The Company has elected to 
not
 adjust the promised amount of consideration for the effects of a significant financing component if the period of financing is 
twelve
 months or less.

[0001437749-19-015632:notes:236]
The Company’s contracts with customers do 
not
 typically include extended payment terms and 
 may 
include milestone billing over the life of the contract. Payment terms vary by contract type and type of customer and generally range from 
30
 to 
60
 days from delivery.

[0001437749-19-015632:notes:237]
The following tables disaggregate the Company’s revenue by product line and by shipment destination:

[0001437749-19-015632:notes:238]
the Company’s contract assets and liabilities primarily relate to the timing differences between cash received from a customer in connection with contractual rights to invoicing and the timing of revenue recognition following completion of performance obligations. The Company's accounts receivable balance is made up entirely of customer contract related balances. Changes in the Company’s contract assets, which are included in “Unbilled Accounts Receivable” and “Deferred program costs” (see Note 
7,
 “Accounts Receivable” and Note 
8,
 “Inventory” for a reconciliation to the condensed consolidated balance sheets) and contract liabilities, which are included in the current portion and long term portion of “deferred revenue” in the Company’s condensed consolidated balance sheets, are as follows:

[0001437749-19-015632:notes:239]
The Company’s remaining performance obligations represent the unrecognized revenue value of the Company’s contractual commitments. The Company’s performance obligations 
 may 
vary significantly each reporting period based on the timing of major new contractual commitments. As of

[0001437749-19-015632:notes:240]
, the Company had outstanding performance obligations on existing contracts under ASC 
606
 to be recognized in the next 
twelve
 months of approximately $

[0001437749-19-015632:notes:241]
54.7

[0001437749-19-015632:notes:242]
million. There are also approximately $

[0001437749-19-015632:notes:243]
9.8

[0001437749-19-015632:notes:244]
million of outstanding performance obligations to be recognized over a period of 
thirteen
 to 
sixty
 months. The remaining performance obligations are subject to customer actions and therefore the timing of revenue recognition cannot be reasonably estimated. The 
twelve
 month performance obligations include anticipated shipments to Inox based on the 
twelve
 month rolling forecast provided by Inox on the multi-year supply contract. The quantities specified in any forecast provided by Inox related to the multi-year supply contract are firm and irrevocable for the 
first

[0001437749-19-015632:notes:245]
three
 months of a 
twelve
 month rolling forecast. The timing of the performance obligations beyond the 
twelve
 month forecast provided by Inox are 
not
 determinable and therefore are 
not
 included in the total remaining performance obligations.

[0001437749-19-015632:notes:246]
The following table sets forth customers who represented 
10%
 or more of the Company’s total revenues for the

[0001437749-19-015632:notes:247]
:

[0001437749-19-015632:notes:248]
|  |  |  | Three Months Ended |  |
|  | Reportable |  | June 30, 2019 |  |
|  | Segment |  | 2019 |  |  | 2018 |  |
| Inox Wind Limited | Wind |  | 27% |  |  | 25% |  |
| Vestas | Grid |  | <10% |  |  | 36% |  |
| Micron Technology | Grid |  | 25% |  |  | <10% |  |


## us-gaap:ScheduleOfSegmentReportingInformationBySegmentTextBlock

[0001437749-19-015632:notes:249]
|  |  | Three Months Ended June 30, |  |
|  |  | 2019 |  |  | 2018 |  |
| Revenues: |  |  |  |  |  |  |  |  |
| Grid |  | $ | 9,855 |  |  | $ | 8,929 |  |
| Wind |  |  | 3,915 |  |  |  | 3,678 |  |
| Total |  | $ | 13,770 |  |  | $ | 12,607 |  |

[0001437749-19-015632:notes:250]
|  |  | Three Months Ended June 30, |  |
|  |  | 2019 |  |  | 2018 |  |
| Operating loss: |  |  |  |  |  |  |  |  |
| Grid |  | $ | (4,663 | ) |  | $ | (2,666 | ) |
| Wind |  |  | (1,324 | ) |  |  | (1,367 | ) |
| Unallocated corporate expenses |  |  | (249 | ) |  |  | (1,095 | ) |
| Total |  | $ | (6,236 | ) |  | $ | (5,128 | ) |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001437749-19-015632:notes:251]
17.
 Business Segments

[0001437749-19-015632:notes:252]
The Company reports its financial results in 
two
 reportable business segments: Grid and Wind.

[0001437749-19-015632:notes:253]
Through the Company’s power grid offerings, the Grid business segment enables electric utilities, industrial facilities, and renewable energy project developers to connect, transmit and distribute power through our transmission planning services, power electronics, and superconductor-based systems. The sales process is enabled by transmission planning services that allow it to identify power grid congestion, poor power quality and other risks, which helps the Company determine how its solutions can improve network performance. These services often lead to sales of grid interconnection solutions for wind farms and solar power plants, power quality systems, and transmission and distribution cable systems.  The Company also sells ship protection products to the U.S. Navy through its Grid business segment.

[0001437749-19-015632:notes:254]
Through the Company’s wind power offerings, the Wind business segment enables manufacturers to field highly competitive wind turbines through our advanced power electronics and control system products, engineered designs, and support services. The Company supplies advanced power electronics and control systems, licenses its highly engineered wind turbine designs, and provides extensive customer support services to wind turbine manufacturers. The Company’s design portfolio includes a broad range of drive trains and power ratings of 
2
 megawatts ("MWs") and higher. The Company provides a broad range of power electronics and software-based control systems that are highly integrated and designed for optimized performance, efficiency, and grid compatibility.

[0001437749-19-015632:notes:255]
The operating results for the 
two
 business segments are as follows (in thousands):

[0001437749-19-015632:notes:256]
The accounting policies of the business segments are the same as those for the consolidated Company. The Company’s business segments have been determined in accordance with the Company’s internal management structure, which is organized based on operating activities. The Company evaluates performance based upon several factors, of which the primary financial measures are segment revenues and segment operating loss. The disaggregated financial results of the segments reflect allocation of certain functional expense categories consistent with the basis and manner in which Company management internally disaggregates financial information for the purpose of assisting in making internal operating decisions. In addition, certain corporate expenses which the Company does 
not
 believe are specifically attributable or allocable to either of the 
two
 business segments have been excluded from the segment operating loss.

[0001437749-19-015632:notes:257]
Unallocated corporate expenses primarily consist of stock-based compensation expense of $

[0001437749-19-015632:notes:258]
million and 
$0.8
 million in the

[0001437749-19-015632:notes:259]
, respectively, and restructuring charges of 
$0.3
 million in the

[0001437749-19-015632:notes:260]
Total assets for the 
two
 business segments as of


## us-gaap:SubsequentEventsTextBlock

[0001437749-19-015632:notes:261]
19.
 Subsequent Events

[0001437749-19-015632:notes:262]
The Company has performed an evaluation of subsequent events through the time of filing this Quarterly Report on Form 
10
-Q with the SEC and has determined that there are 
no
 such events to report other than those already discussed.
