# AMSC 8-K — 0001437749-19-015631 filed 2019-08-06

## item codes, every 8-K on or before 2019-08-06

- 2019-08-06 0001437749-19-015631 — 2.02, 9.01
- 2019-08-06 0001193125-19-214189 — 5.02, 5.07, 9.01
- 2019-06-05 0001437749-19-011476 — 2.02, 5.02, 9.01
- 2019-05-24 0001437749-19-010833 — 5.02
- 2019-02-05 0001628280-19-000964 — 2.02, 8.01, 9.01
- 2018-11-06 0001628280-18-013765 — 2.02, 9.01
- 2018-10-31 0001628280-18-013204 — 1.01
- 2018-08-01 0001628280-18-010196 — 5.07
- 2018-07-31 0001628280-18-009846 — 2.02, 9.01
- 2018-07-09 0001193125-18-214745 — 1.01, 9.01
- 2018-07-03 0001628280-18-009075 — 5.02, 9.01
- 2018-06-14 0001628280-18-007877 — 5.02
- 2018-06-06 0001628280-18-007643 — 2.02, 9.01
- 2018-04-10 0001628280-18-004141 — 5.02
- 2018-04-03 0001628280-18-003952 — 2.01, 9.01
- 2018-02-05 0001628280-18-000989 — 2.02, 9.01
- 2018-02-01 0001628280-18-000826 — 1.01, 9.01
- 2017-11-07 0001628280-17-011076 — 2.02, 9.01
- 2017-09-26 0001628280-17-009444 — 3.02, 8.01
- 2017-08-08 0001628280-17-008329 — 2.02, 9.01
- 2017-08-01 0001628280-17-007765 — 5.02, 5.07
- 2017-07-03 0001193125-17-221140 — 5.02, 9.01
- 2017-05-26 0001193125-17-185503 — 8.01, 9.01
- 2017-05-25 0001628280-17-005914 — 2.02, 9.01 — amendment of 0001628280-17-005884
- 2017-05-25 0001628280-17-005884 — 2.02, 9.01
- 2017-05-10 0001193125-17-165924 — 8.01, 9.01
- 2017-05-09 0001193125-17-164273 — 5.02
- 2017-05-04 0001193125-17-158639 — 1.02, 8.01
- 2017-04-26 0001193125-17-139493 — 2.02, 9.01
- 2017-04-04 0001193125-17-109748 — 2.05, 5.02, 9.01
- 2017-02-06 0001628280-17-000899 — 2.02, 9.01
- 2017-01-27 0001193125-17-021808 — 1.01, 2.02, 9.01
- 2016-11-02 0001628280-16-020598 — 2.02, 9.01
- 2016-09-16 0001193125-16-712301 — 5.02
- 2016-08-23 0001193125-16-688767 — 8.01
- 2016-08-09 0001628280-16-018763 — 2.02, 9.01
- 2016-08-02 0001193125-16-668417 — 5.02, 5.07, 9.01
- 2016-05-31 0001564590-16-020114 — 2.02, 9.01
- 2016-05-18 0001193125-16-594515 — 5.02
- 2016-03-08 0001193125-16-496113 — 1.01
- 2016-02-09 0001193125-16-454775 — 2.02, 9.01
- 2015-12-17 0001193125-15-405566 — 1.01
- 2015-11-03 0001193125-15-363413 — 2.02, 9.01
- 2015-08-31 0001193125-15-307558 — 1.01
- 2015-08-05 0001193125-15-277824 — 2.02, 9.01
- 2015-07-31 0001193125-15-273009 — 5.07
- 2015-06-26 0001193125-15-237190 — 5.02
- 2015-06-09 0001193125-15-218028 — 8.01
- 2015-05-28 0001193125-15-202933 — 2.02, 9.01
- 2015-04-28 0001193125-15-153319 — 8.01, 9.01
- 2015-04-23 0001193125-15-144123 — 2.02, 8.01, 9.01
- 2015-04-23 0001193125-15-143608 — 8.01
- 2015-04-10 0001193125-15-126160 — 8.01
- 2015-03-24 0001193125-15-103436 — 5.03, 9.01
- 2015-03-18 0001193125-15-097034 — 5.07
- 2015-02-05 0001193125-15-034499 — 2.02, 9.01
- 2015-01-29 0001193125-15-024629 — 2.02, 9.01
- 2015-01-21 0001193125-15-016287 — 3.01, 8.01
- 2015-01-06 0001193125-15-002902 — 5.02
- 2014-12-22 0001193125-14-450591 — 1.01, 2.03, 3.02, 9.01
- 2014-11-13 0001193125-14-410207 — 1.01, 9.01
- 2014-11-07 0001193125-14-402383 — 1.02, 7.01, 9.01
- 2014-11-06 0001193125-14-399779 — 2.02, 9.01
- 2014-10-01 0001193125-14-360072 — 2.02, 8.01, 9.01
- 2014-09-04 0001193125-14-331411 — 8.01
- 2014-08-21 0001193125-14-317133 — 1.01
- 2014-08-06 0001193125-14-298306 — 5.02, 5.07, 9.01
- 2014-08-05 0001193125-14-294647 — 2.02, 9.01
- 2014-07-16 0001193125-14-269902 — 8.01
- 2014-06-23 0001193125-14-244592 — 3.02, 8.01
- 2014-06-05 0001193125-14-226459 — 2.02, 9.01
- 2014-06-05 0001193125-14-226457 — 1.01, 9.01
- 2014-03-19 0001193125-14-106558 — 2.05
- 2014-03-03 0001193125-14-078917 — 1.01, 3.02, 9.01
- 2014-02-28 0001193125-14-077480 — 8.01, 9.01
- 2014-02-06 0001193125-14-037960 — 2.02, 8.01, 9.01
- 2013-11-20 0001193125-13-447829 — 3.02, 8.01
- 2013-11-18 0001193125-13-444697 — 1.01, 2.03, 3.02, 9.01
- 2013-11-07 0001193125-13-431705 — 2.02, 9.01
- 2013-10-09 0001193125-13-395362 — 1.01, 2.03, 3.02, 9.01
- 2013-09-25 0001193125-13-378481 — 5.02, 9.01
- 2013-08-21 0001193125-13-341566 — 4.01, 9.01
- 2013-08-07 0001193125-13-323082 — 2.02, 9.01
- 2013-08-02 0001193125-13-317278 — 5.02, 5.07
- 2013-06-14 0001193125-13-258758 — 2.02, 9.01
- 2013-04-01 0001193125-13-136714 — 2.02, 8.01, 9.01
- 2013-02-20 0001193125-13-067218 — 5.02, 9.01
- 2013-02-14 0001193125-13-060131 — 1.01, 9.01
- 2013-02-11 0001193125-13-048784 — 2.02, 9.01
- 2013-01-08 0001193125-13-006861 — 5.02, 9.01
- 2012-12-21 0001193125-12-511592 — 1.01, 2.03, 3.02, 9.01
- 2012-11-28 0001193125-12-483317 — 2.05, 5.02, 7.01, 9.01
- 2012-11-06 0001193125-12-453359 — 2.02, 9.01
- 2012-08-02 0001193125-12-330534 — 2.02, 9.01
- 2012-07-27 0001193125-12-318790 — 5.02, 5.07, 9.01
- 2012-06-06 0001193125-12-261030 — 1.01, 2.02, 2.03, 3.02, 5.02, 9.01
- 2012-05-09 0001193125-12-222210 — 5.02
- 2012-04-20 0001193125-12-172045 — 8.01
- 2012-04-13 0001193125-12-162694 — 2.02, 8.01, 9.01
- 2012-04-04 0001193125-12-149102 — 1.01, 2.02, 2.03, 3.02, 9.01
- 2012-02-09 0001193125-12-048009 — 2.02, 9.01
- 2012-02-06 0001193125-12-041344 — 5.07 — amendment of 0000950123-11-102495
- 2011-12-08 0000950123-11-102495 — 5.07
- 2011-11-29 0000950123-11-100822 — 2.05
- 2011-11-09 0000950123-11-096775 — 2.02, 9.01
- 2011-10-31 0000950123-11-093390 — 1.02, 9.01
- 2011-10-07 0000950123-11-089221 — 8.01
- 2011-10-03 0000950123-11-088315 — 7.01
- 2011-09-23 0000950123-11-086288 — 2.02, 9.01
- 2011-09-15 0000950123-11-084585 — 7.01
- 2011-09-06 0000950123-11-082736 — 7.01
- 2011-08-18 0000950123-11-078526 — 3.01, 7.01, 9.01
- 2011-08-11 0000950123-11-075905 — 5.02
- 2011-08-11 0000950123-11-075904 — 2.02, 2.05, 9.01
- 2011-07-11 0000950123-11-064934 — 2.02, 4.02, 9.01
- 2011-06-30 0000950123-11-063287 — 1.01, 3.02, 9.01
- 2011-06-21 0000950123-11-060491 — 3.01, 7.01, 9.01
- 2011-06-13 0000950123-11-058656 — 1.01, 9.01
- 2011-05-24 0000950123-11-053517 — 5.02, 9.01
- 2011-04-05 0001299933-11-001020 — 2.02, 9.01
- 2011-03-15 0000950123-11-025580 — 5.02
- 2011-03-14 0000950123-11-025205 — 1.01, 3.02, 9.01
- 2011-02-01 0001299933-11-000333 — 2.02, 9.01
- 2010-11-12 0000950123-10-104604 — 8.01, 9.01
- 2010-11-08 0000950123-10-102424 — 8.01, 9.01
- 2010-11-02 0001299933-10-003878 — 2.02, 9.01
- 2010-09-15 0000950123-10-086373 — 1.01, 9.01 — amendment, the index does not say of what
- 2010-08-06 0000950123-10-074362 — 5.07
- 2010-07-29 0001299933-10-002860 — 2.02, 9.01
- 2010-05-17 0000950123-10-050424 — 1.01, 9.01
- 2010-05-14 0001299933-10-001972 — 5.02
- 2010-05-13 0001299933-10-001943 — 2.02, 9.01
- 2010-02-08 0001299933-10-000506 — 8.01
- 2010-02-02 0001299933-10-000386 — 2.02, 9.01
- 2009-12-15 0001299933-09-004928 — 5.02
- 2009-10-29 0001299933-09-004267 — 2.02, 9.01
- 2009-08-12 0001193125-09-173026 — 5.02, 9.01
- 2009-07-30 0001193125-09-158842 — 1.01, 2.02, 9.01
- 2009-05-15 0001193125-09-113158 — 5.02
- 2009-05-14 0001193125-09-110619 — 2.02, 9.01
- 2009-04-20 0001193125-09-082590 — 5.02
- 2009-02-03 0001193125-09-016992 — 2.02, 9.01
- 2009-01-22 0001193125-09-009777 — 2.02, 9.01
- 2008-11-04 0001193125-08-223730 — 2.02, 9.01
- 2008-08-11 0001193125-08-173616 — 8.01
- 2008-08-07 0001193125-08-170325 — 8.01
- 2008-08-05 0001193125-08-165888 — 2.02, 9.01
- 2008-06-11 0001193125-08-132049 — 1.01, 9.01
- 2008-05-20 0001193125-08-119372 — 5.02, 9.01
- 2008-05-08 0001193125-08-107052 — 2.02, 9.01
- 2008-01-31 0001193125-08-016233 — 2.02, 9.01
- 2008-01-30 0001193125-08-015494 — 5.03, 9.01
- 2007-11-01 0001193125-07-231866 — 2.02, 9.01
- 2007-10-31 0001193125-07-231225 — 2.05
- 2007-10-29 0001193125-07-228284 — 5.03, 9.01
- 2007-09-27 0001193125-07-208950 — 5.02
- 2007-08-09 0001193125-07-176553 — 2.02, 9.01
- 2007-08-07 0001193125-07-173829 — 1.01, 5.02, 9.01
- 2007-07-02 0001193125-07-148303 — 5.02, 9.01
- 2007-06-20 0001193125-07-139068 — 8.01, 9.01
- 2007-06-14 0001193125-07-135550 — 9.01 — amendment of 0001193125-07-005297
- 2007-06-14 0001193125-07-135340 — 5.02
- 2007-05-24 0001193125-07-122148 — 2.02, 9.01
- 2007-03-30 0001193125-07-070154 — 2.05, 9.01
- 2007-03-23 0001193125-07-062978 — 9.01 — amendment of 0001193125-07-005297
- 2007-02-01 0001193125-07-017883 — 2.02, 9.01
- 2007-01-11 0001193125-07-005297 — 2.01, 9.01
- 2006-12-05 0001181431-06-067500 — 5.02
- 2006-11-29 0001193125-06-243360 — 1.01, 3.02, 9.01
- 2006-11-02 0001193125-06-221464 — 2.02, 9.01
- 2006-09-21 0001193125-06-194526 — 5.02
- 2006-08-08 0001193125-06-164819 — 2.02, 9.01
- 2006-08-02 0001193125-06-159113 — 1.01, 9.01
- 2006-07-28 0001193125-06-156172 — 1.01
- 2006-06-26 0001193125-06-135913 — 1.01, 3.03, 9.01
- 2006-05-11 0001193125-06-108489 — 2.02, 9.01
- 2006-05-05 0001193125-06-102270 — 1.01, 9.01
- 2006-05-01 0001193125-06-094941 — 2.02, 2.06, 9.01
- 2006-02-24 0001193125-06-038281 — 5.02, 9.01
- 2006-02-02 0001181431-06-007665 — 2.02, 9.01
- 2005-11-09 0001181431-05-060304 — 2.02, 9.01
- 2005-08-04 0001181431-05-044420 — 2.02, 9.01
- 2005-07-28 0001193125-05-151272 — 5.02, 9.01
- 2005-06-14 0001193125-05-125148 — 5.02, 9.01
- 2005-05-12 0001181431-05-027410 — 2.02, 9.01
- 2005-05-10 0001193125-05-102795 — 1.01
- 2005-04-05 0001181431-05-020680 — 1.01, 2.02, 3.02, 9.01
- 2005-02-03 0001181431-05-006678 — 2.02, 9.01
- 2004-11-09 0001181431-04-051381 — 2.02, 9.01 — amendment, the index does not say of what
- 2004-11-04 0001181431-04-050706 — 2.02, 9.01
- 2004-10-15 0001193125-04-172458 — 1.01, 9.01
- 2004-08-05 0001193125-04-132162 — 12
- 2004-05-13 0001193125-04-086853 — 12
- 2004-02-05 0001193125-04-015060 — 12
- 2003-11-06 0001193125-03-074000 — 12
- 2003-09-26 0001193125-03-054624 — 5
- 2003-08-06 0001193125-03-029666 — 12
- 2003-05-14 0000927016-03-002619 — 9
- 2002-12-31 0000927016-02-006114 — 5
- 2000-01-24 0000927016-00-000150 — 5, 7
- 1998-11-02 0000950135-98-005625 — 5, 7
- 1998-03-24 0000950135-98-001743 — 5, 7
- 1997-09-05 0000950135-97-003729 — 5, 7
- 1997-06-23 0000950135-97-002785 — 1 — amendment of 0000950135-97-001972
- 1997-04-23 0000950135-97-001972 — 2, 7

## late-filing notifications on or before 2019-08-06

- 2011-08-10 0000950123-11-075677 — NT 10-Q, for the period ended 2011-06-30
- 2011-05-31 0000950123-11-055465 — NT 10-K, for the period ended 2011-03-31

## item 2.02 — earnings release, exhibit 99.1

[0001437749-19-015631:8k_2_02:1]
EX-99.1
2
ex_151971.htm
EXHIBIT 99.1

[0001437749-19-015631:8k_2_02:2]
ex_151959.htm

[0001437749-19-015631:8k_2_02:3]
Exhibit 99.1

[0001437749-19-015631:8k_2_02:4]
AMSC Reports First Quarter Fiscal Year 2019 Financial Results and Provides Business Outlook

[0001437749-19-015631:8k_2_02:5]
Company to host conference call tomorrow, August 7 at 10:00 am ET

[0001437749-19-015631:8k_2_02:6]
Ayer, MA – August 6, 2019 – AMSC (Nasdaq: AMSC), a global solutions provider serving power grid and wind industry leaders, today reported financial results for its first quarter of fiscal year 2019 ended June 30, 2019.

[0001437749-19-015631:8k_2_02:7]
Revenues for the first quarter of fiscal 2019 were $13.8 million compared with $12.6 million for the same period of fiscal 2018. The year-over-year increase was driven by higher Grid segment revenues versus the year ago period. The higher Grid segment revenues are primarily due to increased D-VAR revenues.

[0001437749-19-015631:8k_2_02:8]
AMSC’s net loss for the first quarter of fiscal 2019 was $3.5 million, or $0.17 per share, compared to a net loss of $4.7 million, or $0.23 per share, for the same period of fiscal 2018. The Company’s non-GAAP net loss for the first quarter of fiscal 2019 was $6.2 million, or $0.30 per share, compared with a non-GAAP net loss of $3.6 million, or $0.18 per share, in the same period of fiscal 2018. Please refer to the financial table below for a reconciliation of GAAP to non-GAAP results.

[0001437749-19-015631:8k_2_02:9]
Cash, cash equivalents and restricted cash on June 30, 2019 totaled $74.7 million, compared with $78.2 million at March 31, 2019.

[0001437749-19-015631:8k_2_02:10]
“Our Grid business delivered a strong start to fiscal 2019,” said Daniel P. McGahn, Chairman, President and CEO, AMSC. “This is the second consecutive quarter in which Grid segment revenues comprised over 70% of total revenues. Growth in our Grid business for the quarter was driven by strong D-VAR shipments, revenue from our SPS product for the US Navy, and initial revenue from our REG deployment project. We expect D-VAR shipments to provide a strong base of grid revenues for the remainder of this fiscal year. We believe that we are on-track to deliver strong Grid revenue growth in fiscal year 2019.”

[0001437749-19-015631:8k_2_02:11]
| AMSC Reports Q1FY19 Results | Page 2 |

[0001437749-19-015631:8k_2_02:12]
Business Outlook

[0001437749-19-015631:8k_2_02:13]
For the second quarter ending September 30, 2019, AMSC expects that its revenues will be in the range of $12 million to $15 million.  The Company’s net loss for the second quarter of fiscal 2019 is expected not to exceed $8.5 million, or $0.41 per share.  The Company's non-GAAP net loss (as defined below) is expected not to exceed $7.5 million, or $0.36 per share.  The Company expects operating cash flow to be a burn of $5 million to $7 million in the second quarter of fiscal 2019.  This guidance does not include any tax payments or other cost related to the final settlement payment from Sinovel.  The Company expects cash, cash equivalents and restricted cash on September 30, 2019, to be no less than $67 million.

[0001437749-19-015631:8k_2_02:14]
Conference Call Reminder

[0001437749-19-015631:8k_2_02:15]
In conjunction with this announcement, AMSC management will participate in a conference call with investors beginning at 10:00 a.m. Eastern Time on Wednesday, August 7, 2019, to discuss the Company’s financial results and business outlook. Those who wish to listen to the live or archived conference call webcast should visit the “Investors” section of the Company’s website at http://www.amsc.com/investors. The live call also can be accessed by dialing  1-800-353-6461 and 1-334-323-0501 and using conference ID 1214713. A replay of the call may be accessed 2 hours following the call by dialing (888) 203-1112 or 719-457-0820 and using conference ID 1214713.

[0001437749-19-015631:8k_2_02:16]
About AMSC (Nasdaq: AMSC)

[0001437749-19-015631:8k_2_02:17]
AMSC generates the ideas, technologies and solutions that meet the world’s demand for smarter, cleaner … better energy™. Through its Gridtec™ Solutions, AMSC provides the engineering planning services and advanced grid systems that optimize network reliability, efficiency and performance. Through its Windtec™ Solutions, AMSC provides wind turbine electronic controls and systems, designs and engineering services that reduce the cost of wind energy. The Company’s solutions are now powering gigawatts of renewable energy globally and are enhancing the performance and reliability of power networks in more than a dozen countries. Founded in 1987, AMSC is headquartered near Boston, Massachusetts with operations in Asia, Australia, Europe and North America. For more information, please visit www.amsc.com.

[0001437749-19-015631:8k_2_02:18]
AMSC, D-VAR, D-VAR VVO, Gridtec, Windtec, and Smarter, Cleaner … Better Energy are trademarks or registered trademarks of American Superconductor Corporation. All other brand names, product names, trademarks or service marks belong to their respective holders.

[0001437749-19-015631:8k_2_02:19]
| AMSC Reports Q1FY19 Results | Page 3 |

[0001437749-19-015631:8k_2_02:20]
Forward-Looking Statements

[0001437749-19-015631:8k_2_02:21]
| AMSC Reports Q1FY19 Results | Page 4 |

[0001437749-19-015631:8k_2_02:22]
UNAUDITED CONSOLIDATED STATEMENTS OF OPERATIONS

[0001437749-19-015631:8k_2_02:23]
(In thousands, except per share data)

[0001437749-19-015631:8k_2_02:24]
|  |  | Three Months Ended June 30, |  |
|  |  | 2019 |  |  | 2018 |  |
| Revenues |  |  |  |  |  |  |  |  |
| Grid |  | $ | 9,855 |  |  | $ | 8,929 |  |
| Wind |  |  | 3,915 |  |  |  | 3,678 |  |
| Revenues |  |  | 13,770 |  |  |  | 12,607 |  |
| Cost of revenues |  |  | 12,193 |  |  |  | 8,714 |  |
| Gross margin |  |  | 1,577 |  |  |  | 3,893 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |
| Research and development |  |  | 2,473 |  |  |  | 2,840 |  |
| Selling, general and administrative |  |  | 5,255 |  |  |  | 5,786 |  |
| Amortization of acquisition related intangibles |  |  | 85 |  |  |  | 85 |  |
| Restructuring and impairment |  |  | — |  |  |  | 310 |  |
| Total operating expenses |  |  | 7,813 |  |  |  | 9,021 |  |
| Operating loss |  |  | (6,236 | ) |  |  | (5,128 | ) |
| Change in fair value of derivatives and warrants |  |  | 2,946 |  |  |  | (464 | ) |
| Interest income, net |  |  | 505 |  |  |  | 201 |  |
| Other income (expense), net |  |  | (543 | ) |  |  | 609 |  |
| Loss before income tax benefit expense (benefit) |  |  | (3,328 | ) |  |  | (4,782 | ) |
| Income tax expense (benefit) |  |  | 211 |  |  |  | (45 | ) |
| Net loss |  | $ | (3,539 | ) |  | $ | (4,737 | ) |
| Net loss per common share |  |  |  |  |  |  |  |  |
| Basic |  | $ | (0.17 | ) |  | $ | (0.23 | ) |
| Diluted |  | $ | (0.17 | ) |  | $ | (0.23 | ) |
| Weighted average number of common shares outstanding |  |  |  |  |  |  |  |  |
| Basic |  |  | 20,514 |  |  |  | 20,167 |  |
| Diluted |  |  | 20,514 |  |  |  | 20,167 |  |

[0001437749-19-015631:8k_2_02:25]
AMSC Reports Q1FY19 Results                                                                                                                                                                                                                             Page 5

[0001437749-19-015631:8k_2_02:26]
UNAUDITED CONSOLIDATED BALANCE SHEET

[0001437749-19-015631:8k_2_02:27]
(In thousands, except per share data)

[0001437749-19-015631:8k_2_02:28]
|  |  | June 30, 2019 |  |  | March 31, 2019 |  |
| ASSETS |  |  |  |  |  |  |  |  |
| Current assets: |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 73,952 |  |  | $ | 77,483 |  |
| Accounts receivable, net |  |  | 10,736 |  |  |  | 7,855 |  |
| Inventory |  |  | 11,924 |  |  |  | 12,119 |  |
| Note receivable, current portion |  |  | 0 |  |  |  | 2,888 |  |
| Prepaid expenses and other current assets |  |  | 4,102 |  |  |  | 3,053 |  |
| Total current assets |  |  | 100,714 |  |  |  | 103,398 |  |
| Property, plant and equipment, net |  |  | 8,747 |  |  |  | 8,972 |  |
| Intangibles, net |  |  | 2,805 |  |  |  | 2,890 |  |
| Goodwill |  |  | 1,719 |  |  |  | 1,719 |  |
| Restricted cash |  |  | 715 |  |  |  | 715 |  |
| Right-of-use asset |  |  | 3,733 |  |  |  | 0 |  |
| Deferred tax assets |  |  | 1,411 |  |  |  | 1,357 |  |
| Other assets |  |  | 306 |  |  |  | 279 |  |
| Total assets |  | $ | 120,150 |  |  | $ | 119,330 |  |
| LIABILITIES AND STOCKHOLDERS' EQUITY |  |  |  |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |  |  |  |
| Accounts payable and accrued expenses |  | $ | 15,819 |  |  | $ | 15,885 |  |
| Lease liability, current portion |  |  | 416 |  |  |  | 0 |  |
| Derivative liabilities |  |  | 1,702 |  |  |  | 4,942 |  |
| Deferred revenue, current portion |  |  | 10,806 |  |  |  | 7,557 |  |
| Total current liabilities |  |  | 28,743 |  |  |  | 28,384 |  |
| Deferred revenue, long term portion |  |  | 7,883 |  |  |  | 7,962 |  |
| Lease liability, long term portion |  |  | 3,357 |  |  |  | 0 |  |
| Deferred tax liabilities |  |  | 1,703 |  |  |  | 1,698 |  |
| Other liabilities |  |  | 51 |  |  |  | 93 |  |
| Total liabilities |  |  | 41,737 |  |  |  | 38,137 |  |
| Commitments and contingencies (Note 15) |  |  |  |  |  |  |  |  |
| Stockholders' equity: |  |  |  |  |  |  |  |  |
| Common stock |  |  | 218 |  |  |  | 216 |  |
| Additional paid-in capital |  |  | 1,045,244 |  |  |  | 1,044,622 |  |
| Treasury stock |  |  | (2,384 | ) |  |  | (2,101 | ) |
| Accumulated other comprehensive (loss) income |  |  | 413 |  |  |  | (5 | ) |
| Accumulated deficit |  |  | (965,078 | ) |  |  | (961,539 | ) |
| Total stockholders' equity |  |  | 78,413 |  |  |  | 81,193 |  |
| Total liabilities and stockholders' equity |  | $ | 120,150 |  |  | $ | 119,330 |  |

[0001437749-19-015631:8k_2_02:29]
AMSC Reports Q1FY19 Results                                                                                                                                                                                                                             Page 6

[0001437749-19-015631:8k_2_02:30]
UNAUDITED CONSOLIDATED STATEMENTS OF CASH FLOWS

[0001437749-19-015631:8k_2_02:31]
(In thousands)

[0001437749-19-015631:8k_2_02:32]
|  |  | Three Months ended June 30, |  |
|  |  | 2019 |  |  | 2018 |  |
| Cash flows from operating activities: |  |  |  |  |  |  |  |  |
| Net loss |  | $ | (3,539 | ) |  | $ | (4,737 | ) |
| Adjustments to reconcile net loss to net cash used in operations: |  |  |  |  |  |  |  |  |
| Depreciation and amortization |  |  | 1,149 |  |  |  | 1,150 |  |
| Stock-based compensation expense |  |  | 249 |  |  |  | 785 |  |
| Provision for excess and obsolete inventory |  |  | 89 |  |  |  | 144 |  |
| Change in fair value of warrants and contingent consideration |  |  | (2,946 | ) |  |  | 464 |  |
| Non-cash interest expense |  |  | (112 | ) |  |  | (56 | ) |
| Other non-cash items |  |  | 100 |  |  |  | (394 | ) |
| Changes in operating asset and liability accounts: |  |  |  |  |  |  |  |  |
| Accounts receivable |  |  | (2,874 | ) |  |  | (4,192 | ) |
| Inventory |  |  | 108 |  |  |  | (459 | ) |
| Prepaid expenses and other current assets |  |  | (1,002 | ) |  |  | (332 | ) |
| Accounts payable and accrued expenses |  |  | (181) |  |  |  | 75 |  |
| Deferred revenue |  |  | 3,093 |  |  |  | 666 |  |
| Net cash used in operating activities |  |  | (5,866 | ) |  |  | (6,886 | ) |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |
| Net cash provided by/(used in) investing activities |  |  | 2,259 |  |  |  | (166 | ) |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |
| Net cash used in financing activities |  |  | (283 | ) |  |  | (238 | ) |
| Effect of exchange rate changes on cash, cash equivalents and restricted cash |  |  | 359 |  |  |  | (44 | ) |
| Net decrease in cash, cash equivalents and restricted cash |  |  | (3,531 | ) |  |  | (7,334 | ) |
| Cash, cash equivalents and restricted cash at beginning of year |  |  | 78,198 |  |  |  | 34,249 |  |
| Cash, cash equivalents and restricted cash at end of year |  | $ | 74,667 |  |  | $ | 26,915 |  |

[0001437749-19-015631:8k_2_02:33]
AMSC Reports Q1FY19 Results                                                                                                                                                                                                                             Page 7

[0001437749-19-015631:8k_2_02:34]
RECONCILIATION OF GAAP NET INCOME (LOSS) TO NON-GAAP NET INCOME (LOSS)

[0001437749-19-015631:8k_2_02:35]
(In thousands, except per share data)

[0001437749-19-015631:8k_2_02:36]
|  |  | Three Months Ended June 30, |  |
|  |  | 2019 |  |  | 2018 |  |
| Net loss |  | $ | (3,539 | ) |  | $ | (4,737 | ) |
| Stock-based compensation |  |  | 249 |  |  |  | 785 |  |
| Amortization of acquisition-related intangibles |  |  | 85 |  |  |  | 85 |  |
| Consumption of zero cost-basis inventory |  |  | 0 |  |  |  | (249 | ) |
| Changes in fair value of warrants |  |  | (2,946 | ) |  |  | 464 |  |
| Tax effect of adjustments for consumption of zero cost-basis inventory |  |  | 0 |  |  |  | 40 |  |
| Non-GAAP net loss |  | $ | (6,151 | ) |  | $ | (3,612 | ) |
| Non-GAAP net loss per share - basic |  | $ | (0.30 | ) |  | $ | (0.18 | ) |
| Weighted average shares outstanding - basic |  |  | 20,514 |  |  |  | 20,167 |  |

[0001437749-19-015631:8k_2_02:37]
RECONCILIATION OF GAAP OPERATING CASH FLOW TO NON-GAAP OPERATING CASH FLOW

[0001437749-19-015631:8k_2_02:38]
(In thousands)

[0001437749-19-015631:8k_2_02:39]
|  |  | June 30, 2019 |  |  | March 31, 2019 |  |
| Operating cash flow |  | $ | (5,866 | ) |  | $ | 42,714 |  |
| Sinovel settlement (net of legal fees and expenses) |  |  | 1,000 |  |  |  | (52,740 | ) |
| Tax effect of adjustments |  |  | 0 |  |  |  | 2,377 |  |
| Non-GAAP operating cash flow |  | $ | (4,866 | ) |  | $ | (7,649 | ) |

[0001437749-19-015631:8k_2_02:40]
Reconciliation of Forecast GAAP Net Loss to Non-GAAP Net Loss

[0001437749-19-015631:8k_2_02:41]
(In millions, except per share data)

[0001437749-19-015631:8k_2_02:42]
|  |  | Three months ending |  |
|  |  | September 30, 2019 |  |
| Net loss |  | $ | (8.5 | ) |
| Stock-based compensation |  |  | 0.9 |  |
| Amortization of acquisition-related intangibles |  |  | 0.1 |  |
| Non-GAAP net loss |  | $ | (7.5 | ) |
| Non-GAAP net loss per share |  | $ | (0.36 | ) |
| Shares outstanding |  |  | 20.8 |  |

[0001437749-19-015631:8k_2_02:43]
AMSC Reports Q1FY19 Results                                                                                                                                                                                                                             Page 8

[0001437749-19-015631:8k_2_02:44]
Note: Non-GAAP net loss is defined by the Company as net income (loss) before; stock-based compensation; amortization of acquisition-related intangibles; consumption of zero cost-basis inventory; changes in fair value of warrants;  other unusual charges or items, and the tax effect of adjustments calculated at the relevant rate for our non-GAAP metric. The Company believes non-GAAP net loss assists management and investors in comparing the Company’s performance across reporting periods on a consistent basis by excluding these non-cash, non-recurring or other charges that it does not believe are indicative of its core operating performance. The Company is not able to provide the change in fair value of warrants on a forward-looking basis without unreasonable efforts because the calculation for that change is primarily driven by the closing price and volatility of the Company's stock at the end of each fiscal quarter, which cannot be reasonably estimated at this time, and therefore the Company's non-GAAP net loss guidance does not include the impact from any change in fair value of warrants.  The Company does not expect a further gain on sale of minority investments or gain on Sinovel Settlement, net, and therefore the Company's non-GAAP net loss guidance does not include the impact from these adjustments.  Actual non-GAAP net loss for the fiscal quarter ending September 30, 2019, including the above adjustments, may differ materially from those forecasted in the table above.

[0001437749-19-015631:8k_2_02:45]
Non-GAAP operating cash flow is defined by the Company as operating cash flow before: Sinovel settlement (net of legal fees and expenses); tax effect of adjustments; and other unusual cash flows or items. The Company believes non-GAAP operating cash flow assists management and investors in comparing the Company’s operating cash flow across reporting periods on a consistent basis by excluding these  non-recurring cash items that it does not believe are indicative of its core operating cash flow.

[0001437749-19-015631:8k_2_02:46]
Generally, a non-GAAP financial measure is a numerical measure of a company's performance, financial position or cash flow that either excludes or includes amounts that are not normally excluded or included in the most directly comparable measure calculated and presented in accordance with GAAP. The non-GAAP measures included in this release, however, should be considered in addition to, and not as a substitute for or superior to, operating income, cash flows, or other measures of financial performance prepared in accordance with GAAP. A reconciliation of GAAP to non-GAAP net loss is set forth in the table above.

[0001437749-19-015631:8k_2_02:47]
AMSC Contacts

[0001437749-19-015631:8k_2_02:48]
Investor Relations Contact:

[0001437749-19-015631:8k_2_02:49]
LHA Investor Relations

[0001437749-19-015631:8k_2_02:50]
Sanjay M. Hurry

[0001437749-19-015631:8k_2_02:51]
(212) 838-3777

[0001437749-19-015631:8k_2_02:52]
amscIR@lhai.com

[0001437749-19-015631:8k_2_02:53]
Public Relations Contact:

[0001437749-19-015631:8k_2_02:54]
RooneyPartners LLC

[0001437749-19-015631:8k_2_02:55]
Bob Cavosi

[0001437749-19-015631:8k_2_02:56]
646-638-9891

[0001437749-19-015631:8k_2_02:57]
rcavosi@rooneyco.com

[0001437749-19-015631:8k_2_02:58]
AMSC Communications Manager:

[0001437749-19-015631:8k_2_02:59]
Nicol Golez

[0001437749-19-015631:8k_2_02:60]
Phone: 978-399-8344

[0001437749-19-015631:8k_2_02:61]
Email: Nicol.Golez@amsc.com
