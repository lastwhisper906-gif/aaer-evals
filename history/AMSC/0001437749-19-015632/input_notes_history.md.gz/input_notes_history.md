# AMSC note change history — 0001628280-19-000966 → 0001437749-19-015632


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2019-08-06):
[0001437749-19-015632:note_history:1]
15.
 Commitments and Contingencies
  (was, 2019-02-05, similarity 0.9667):
[0001628280-19-000966:note_history:1]
Commitments and Contingencies

- added (2019-08-06):
[0001437749-19-015632:note_history:2]
As of

- added (2019-08-06):
[0001437749-19-015632:note_history:3]
June 30, 2019

- added (2019-08-06):
[0001437749-19-015632:note_history:4]
, the Company had $

- added (2019-08-06):
[0001437749-19-015632:note_history:5]
0.7

- added (2019-08-06):
[0001437749-19-015632:note_history:6]
million of restricted cash included in long-term assets. These amounts included in restricted cash primarily represent deposits to secure letters of credit for various supply contracts. These deposits are held in interest bearing accounts.  As part of the agreement with Commonwealth Edison Company to install the Resilient Electric Grid ("REG") system in Chicago, the Company agreed to deliver an irrevocable letter of credit in the amount of 
$5.0
 million to secure certain Company obligations under the Subcontract Agreement.  The funds to secure the 
$5.0
 million letter of credit were deposited in an escrow account on 
 July 1, 2019.

- removed (2019-08-06):
[0001628280-19-000966:note_history:7]
As of December 31, 2018, the Company had $0.2 million of restricted cash included in long-term assets. These amounts included in restricted cash primarily represent deposits to secure letters of credit for various supply contracts. These deposits are held in interest bearing accounts.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2019-08-06):
[0001437749-19-015632:note_history:8]
1.
 Nature of the Business and Operations and Liquidity
  (was, 2019-02-05, similarity 0.9808):
[0001628280-19-000966:note_history:8]
Nature of the Business and Operations and Liquidity

- added (2019-08-06):
[0001437749-19-015632:note_history:9]
American Superconductor Corporation (together with its subsidiaries, “AMSC®”or the “Company”) was founded on 
 April

- added (2019-08-06):
[0001437749-19-015632:note_history:10]
9,

- added (2019-08-06):
[0001437749-19-015632:note_history:11]
1987.
 The Company is a leading system provider of megawatt-scale power solutions that enhance the performance of the power grid, protect the Navy’s fleet, and lower the cost of wind power. The Company’s system level products leverage its proprietary “smart materials” and “smart software and controls” to provide enhanced resiliency and improved performance of megawatt-scale power flow.

- changed (2019-08-06):
[0001437749-19-015632:note_history:12]
These unaudited condensed consolidated financial statements of the Company have been prepared on a going concern basis in accordance with United States generally accepted accounting principles (“GAAP”) and the Securities and Exchange Commission’s (“SEC”) instructions to Form 
10
-Q. The going concern basis of presentation assumes that the Company will continue operations and will be able to realize its assets and discharge its liabilities and commitments in the normal course of business. Certain information and footnote disclosures normally included in the financial statements prepared in accordance with GAAP have been condensed or omitted pursuant to those instructions. The year-end condensed balance sheet data was derived from audited financial statements but does 
not
 include all disclosures required by GAAP. The unaudited condensed consolidated financial statements, in the opinion of management, reflect all adjustments (consisting of normal recurring adjustments) necessary for a fair statement of the results for the interim periods ended
  (was, 2019-02-05, similarity 0.8026):
[0001628280-19-000966:note_history:12]
These unaudited condensed consolidated financial statements of the Company have been prepared on a going concern basis in accordance with United States generally accepted accounting principles (“GAAP”) and the Securities and Exchange Commission’s (“SEC”) instructions to Form 10-Q. The going concern basis of presentation assumes that the Company will continue operations and will be able to realize its assets and discharge its liabilities and commitments in the normal course of business. Certain information and footnote disclosures normally included in the financial statements prepared in accordance with GAAP have been condensed or omitted pursuant to those instructions. The year-end condensed balance sheet data was derived from audited financial statements but does not include all disclosures required by GAAP. The unaudited condensed consolidated financial statements, in the opinion of management, reflect all adjustments (consisting of normal recurring adjustments) necessary for a fair statement of the results for the interim periods ended December 31, 2018 and 2017 and the financial position at December 31, 2018; however, these results are not necessarily indicative of results which may be expected for the full year. The interim condensed consolidated financial statements, and notes thereto, should be read in conjunction with the audited consolidated financial statements for the year ended March 31, 2018, and notes thereto, included in the Company’s annual report on Form 10-K for the year ended March 31, 2018 filed with the Securities and Exchange Commission on June 6, 2018.

- added (2019-08-06):
[0001437749-19-015632:note_history:13]
June 30, 2019

- added (2019-08-06):
[0001437749-19-015632:note_history:14]
and

- added (2019-08-06):
[0001437749-19-015632:note_history:15]
2018

- added (2019-08-06):
[0001437749-19-015632:note_history:16]
and the financial position at

- added (2019-08-06):
[0001437749-19-015632:note_history:17]
June 30, 2019

- added (2019-08-06):
[0001437749-19-015632:note_history:18]
; however, these results are 
not
 necessarily indicative of results which 
 may 
be expected for the full year. The interim condensed consolidated financial statements, and notes thereto, should be read in conjunction with the audited consolidated financial statements for the year ended

- added (2019-08-06):
[0001437749-19-015632:note_history:19]
March 31, 2019

- added (2019-08-06):
[0001437749-19-015632:note_history:20]
, and notes thereto, included in the Company’s annual report on Form 
10
-K for the year ended

- added (2019-08-06):
[0001437749-19-015632:note_history:21]
March 31, 2019

- added (2019-08-06):
[0001437749-19-015632:note_history:22]
filed with the Securities and Exchange Commission on 
 June 5, 2019.

- added (2019-08-06):
[0001437749-19-015632:note_history:23]
The Company has historically experienced recurring operating losses and as of

- added (2019-08-06):
[0001437749-19-015632:note_history:24]
June 30, 2019

- added (2019-08-06):
[0001437749-19-015632:note_history:25]
, the Company had an accumulated deficit of $

- added (2019-08-06):
[0001437749-19-015632:note_history:26]
965.1

- added (2019-08-06):
[0001437749-19-015632:note_history:27]
million. In addition, the Company has historically experienced recurring negative operating cash flows.  At

- added (2019-08-06):
[0001437749-19-015632:note_history:28]
June 30, 2019

- added (2019-08-06):
[0001437749-19-015632:note_history:29]
, the Company had cash and cash equivalents of $

- added (2019-08-06):
[0001437749-19-015632:note_history:30]
74.0

- added (2019-08-06):
[0001437749-19-015632:note_history:31]
million, with 
no
 outstanding debt other than ordinary trade payables. Cash used in operations for the

- added (2019-08-06):
[0001437749-19-015632:note_history:32]
three

- added (2019-08-06):
[0001437749-19-015632:note_history:33]
months ended

- added (2019-08-06):
[0001437749-19-015632:note_history:34]
June 30, 2019

- added (2019-08-06):
[0001437749-19-015632:note_history:35]
was $

- added (2019-08-06):
[0001437749-19-015632:note_history:36]
5.9

- added (2019-08-06):
[0001437749-19-015632:note_history:37]
million.

- added (2019-08-06):
[0001437749-19-015632:note_history:38]
On 
 July

- added (2019-08-06):
[0001437749-19-015632:note_history:39]
3,

- changed (2019-08-06):
[0001437749-19-015632:note_history:40]
2018,
 the Company and its wholly-owned subsidiaries Suzhou AMSC Superconductor Co. Ltd. (“AMSC China”) and AMSC Austria GMBH (“AMSC Austria”) entered into a settlement agreement (the “Settlement Agreement”) with Sinovel Wind Group Co., Ltd. (“Sinovel”). The Settlement Agreement settles the litigation and arbitration proceedings between the Company and Sinovel. Under the terms of the Settlement Agreement, Sinovel agreed to pay AMSC China an aggregate cash amount in Renminbi (“RMB”) equivalent to 
$57.5
 million, consisting of 
two
 installments. Sinovel paid the 
first
 installment of the RMB equivalent of 
$32.5
 million on 
 July
  (was, 2019-02-05, similarity 0.8747):
[0001628280-19-000966:note_history:40]
On July 3, 2018, the Company and its wholly-owned subsidiaries Suzhou AMSC Superconductor Co. Ltd. (“AMSC China”) and AMSC Austria GMBH (“AMSC Austria”) entered into a settlement agreement (the “Settlement Agreement”) with Sinovel Wind Group Co., Ltd. (“Sinovel”). The Settlement Agreement settles the litigation and arbitration proceedings between the Company and Sinovel.  Under the terms of the Settlement Agreement, Sinovel agreed to pay AMSC China an aggregate cash amount in Renminbi (“RMB”) equivalent to $57.5 million, consisting of two installments. Sinovel paid the first installment of the RMB equivalent of $32.5 million on July 4, 2018, which was repatriated to the Company during the nine months ended December 31, 2018, and paid the second installment of the RMB equivalent of $25.0 million on December 27, 2018.

- added (2019-08-06):
[0001437749-19-015632:note_history:41]
4,

- added (2019-08-06):
[0001437749-19-015632:note_history:42]
2018,
 which was repatriated to the Company during the 
nine
 months ended 
 December

- added (2019-08-06):
[0001437749-19-015632:note_history:43]
31,

- added (2019-08-06):
[0001437749-19-015632:note_history:44]
2018,
 and paid the 
second
 installment of the RMB equivalent of 
$25.0
 million on 
 December 27, 2018.  
The Company’s fiscal 
2018
 results included the net gain received from the settlement with Sinovel of 
$52.7
 million.

- changed (2019-08-06):
[0001437749-19-015632:note_history:45]
On 
 February 1, 2018, 
ASC Devens LLC (the “Seller”), a wholly-owned subsidiary of the Company, entered into a Purchase and Sale Agreement (the “PSA”) with 
64
 Jackson, LLC (the “Purchaser”) and Stewart Title Guaranty Company (“Escrow Agent”), to effectuate the sale of certain real property located at 
64
 Jackson Road, Devens, Massachusetts, including the building that had served as the Company’s headquarters (collectively, the “Property”), in exchange for total consideration of 
$23.0
 million, composed of (i) cash consideration of 
$17.0
 million, and (ii) a 
$6.0
 million subordinated secured commercial promissory note payable to the Company (the “Seller Note”). Subsequently, the Seller, the Purchaser and Jackson 
64
 MGI, LLC (“Assignee”) entered into an Assignment of Purchase and Sale Agreement (the “Assignment Agreement”), pursuant to which the Purchaser assigned all of its rights and interests in the PSA to the Assignee and the Assignee agreed to assume all of the Purchaser’s obligations and liabilities under the PSA. The transaction closed on 
 March 28, 2018, 
at which time the Company received, from the Assignee, cash consideration, net of certain agreed upon closing costs, of 
$16.9
 million, and the Seller Note at an interest rate of 
1.96%.
 The Seller Note was secured by a subordinated 
second
 mortgage on the Property and a subordinated 
second
 assignment of leases and rents.  The Company received the 
first
  (was, 2019-02-05, similarity 0.9877):
[0001628280-19-000966:note_history:45]
On February 1, 2018, ASC Devens LLC (the “Seller”), a wholly-owned subsidiary of the Company, entered into a Purchase and Sale Agreement (the “PSA”) with 64 Jackson, LLC (the “Purchaser”) and Stewart Title Guaranty Company (“Escrow Agent”), to effectuate the sale of certain real property located at 64 Jackson Road, Devens, Massachusetts, including the building that had served as the Company’s headquarters (collectively, the “Property”), in exchange for total consideration of $23.0 million, composed of (i) cash consideration of $17.0 million, and (ii) a $6.0 million subordinated secured commercial promissory note payable to the Company (the “Seller Note”). Subsequently, the Seller, the Purchaser and Jackson 64 MGI, LLC (“Assignee”) entered into an Assignment of Purchase and Sale Agreement (the “Assignment Agreement”), pursuant to which the Purchaser assigned all of its rights and interests in the PSA to the Assignee and the Assignee agreed to assume all of the Purchaser’s obligations and liabilities under the PSA. The transaction closed on March 28, 2018, at which time the Company received, from the Assignee, cash consideration, net of certain agreed upon closing costs, of $16.9 million, and the Seller Note at an interest rate of 1.96%. The Seller Note is secured by a subordinated second mortgage on the Property and a subordinated second assignment of leases and rents.

- added (2019-08-06):
[0001437749-19-015632:note_history:46]
$3.0
 million payment due pursuant to the Seller Note on 
 March 28, 2019 
and the 
second

- added (2019-08-06):
[0001437749-19-015632:note_history:47]
$3.0
 million payment plus interest on 
 May 23, 2019.

- changed (2019-08-06):
[0001437749-19-015632:note_history:48]
In 
 December 2015, 
the Company entered into a set of strategic agreements valued at approximately 
$210.0
 million with Inox Wind Ltd. (“Inox” or “Inox Wind”), which includes a multi-year supply contract pursuant to which the Company will supply electrical control systems to Inox and a license agreement allowing Inox to manufacture a limited number of electrical control systems. After Inox purchases the specified number of electrical control systems required under the terms of the supply contract, Inox agreed that the Company will continue as Inox’s preferred supplier and Inox will be required to purchase from the Company a majority of its electrical control systems requirements for an additional 
three
-year period.
  (was, 2019-02-05, similarity 0.9993):
[0001628280-19-000966:note_history:48]
In December 2015, the Company entered into a set of strategic agreements valued at approximately $210.0 million with Inox Wind Ltd. (“Inox” or “Inox Wind”), which includes a multi-year supply contract pursuant to which the Company will supply electrical control systems to Inox and a license agreement allowing Inox to manufacture a limited number of electrical control systems.  After Inox purchases the specified number of electrical control systems required under the terms of the supply contract, Inox agreed that the Company will continue as Inox’s preferred supplier and Inox will be required to purchase from the Company a majority of its electrical control systems requirements for an additional three-year period.

- added (2019-08-06):
[0001437749-19-015632:note_history:49]
The Company believes that based on the information presented above and its quarterly management assessment, it has sufficient liquidity to fund its operations and capital expenditures for the next 
twelve
 months following the issuance of the financial statements for the

- added (2019-08-06):
[0001437749-19-015632:note_history:50]
three

- added (2019-08-06):
[0001437749-19-015632:note_history:51]
months ended

- added (2019-08-06):
[0001437749-19-015632:note_history:52]
June 30, 2019

- changed (2019-08-06):
[0001437749-19-015632:note_history:53]
. The Company’s liquidity is highly dependent on its ability to increase revenues, including its ability to collect revenues under its agreements with Inox, its ability to control its operating costs, and its ability to raise additional capital, if necessary. There can be 
no
 assurance that the Company will be able to continue to raise additional capital, on favorable terms or at all, from other sources or execute on any other means of improving liquidity described above.
  (was, 2019-02-05, similarity 0.753):
[0001628280-19-000966:note_history:53]
The Company believes that based on the information presented above and its quarterly management assessment, it has sufficient liquidity to fund its operations and capital expenditures for the next twelve months following the issuance of the financial statements for the three and nine months ended December 31, 2018. The Company’s liquidity is highly dependent on its ability to increase revenues, including its ability to collect revenues under its agreements with Inox, its ability to control its operating costs, and its ability to raise additional capital, if necessary. There can be no assurance that the Company will be able to continue to raise additional capital, on favorable terms or at all, from other sources or execute on any other means of improving liquidity described above.

- removed (2019-08-06):
[0001628280-19-000966:note_history:54]
American Superconductor Corporation (“AMSC” or the “Company”) was founded on April 9, 1987. The Company is a leading provider of megawatt-scale solutions that lower the cost of wind power and enhance the performance of the power grid. In the wind power market, the Company enables manufacturers to field wind turbines through its advanced engineering, support services and power electronics products. In the power grid market, the Company enables electric utilities and renewable energy project developers to connect, transmit and distribute power through its transmission planning services and power electronics and superconductor-based products. The Company’s wind and power grid products and services provide exceptional reliability, security, efficiency and affordability to its customers.

- removed (2019-08-06):
[0001628280-19-000966:note_history:55]
The Company has experienced recurring operating losses and as of December 31, 2018, the Company had an accumulated deficit of $953.2 million. In addition, the Company has experienced recurring negative operating cash flows.  At December 31, 2018, the Company had cash and cash equivalents of $80.0 million, with no outstanding debt other than ordinary trade payables. Cash provided by operations for the nine months ended December 31, 2018 was $47.8 million.  The current period results include the net gain received from the first and second installments of the Sinovel settlement of $53.7 million in the nine month period ended December 31, 2018.


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- added (2019-08-06):
[0001437749-19-015632:note_history:56]
|  |  | Three Months Ended June 30, 2019 |  |
| Product Line: |  | Grid |  |  | Wind |  |
| Equipment and systems |  | $ | 8,354 |  |  | $ | 3,505 |  |
| Services and technology development |  |  | 1,501 |  |  |  | 410 |  |
| Total |  | $ | 9,855 |  |  | $ | 3,915 |  |
| Region: |  |  |  |  |  |  |  |  |
| Americas |  | $ | 7,801 |  |  | $ | 46 |  |
| Asia Pacific |  |  | 1,827 |  |  |  | 3,856 |  |
| EMEA |  |  | 227 |  |  |  | 13 |  |
| Total |  | $ | 9,855 |  |  | $ | 3,915 |  |
|  |  | Three Months Ended June 30, 2018 |  |
| Product Line: |  | Grid |  |  | Wind |  |
| Equipment and systems |  | $ | 7,462 |  |  | $ | 3,492 |  |
| Services and technology development |  |  | 1,467 |  |  |  | 186 |  |
| Total |  | $ | 8,929 |  |  | $ | 3,678 |  |
| Region: |  |  |  |  |  |  |  |  |
| Americas |  | $ | 7,496 |  |  | $ | 23 |  |
| Asia Pacific |  |  | 808 |  |  |  | 3,595 |  |
| EMEA |  |  | 625 |  |  |  | 60 |  |
| Total |  | $ | 8,929 |  |  | $ | 3,678 |  |

- removed (2019-08-06):
[0001628280-19-000966:note_history:57]
The following tables disaggregate the Company’s revenue by product line and by shipment destination:

- removed (2019-08-06):
[0001628280-19-000966:note_history:58]
|  | Three Months Ended December 31, 2018 |  | Nine Months Ended December 31, 2018 |
| Product Line: | Grid |  | Wind |  | Grid |  | Wind |
| Equipment and systems | $ | 4,614 |  |  | $ | 7,215 |  |  | $ | 17,571 |  |  | $ | 17,925 |  |
| Services and technology development | 2,212 |  |  | 93 |  |  | 5,754 |  |  | 368 |  |
| Total | $ | 6,826 |  |  | $ | 7,308 |  |  | $ | 23,325 |  |  | $ | 18,293 |  |
| Region: |  |  |  |  |  |  |  |
| Americas | $ | 3,771 |  |  | $ | 36 |  |  | $ | 16,319 |  |  | $ | 82 |  |
| Asia Pacific | 2,815 |  |  | 7,263 |  |  | 5,930 |  |  | 18,136 |  |
| EMEA | 240 |  |  | 9 |  |  | 1,076 |  |  | 75 |  |
| Total | $ | 6,826 |  |  | $ | 7,308 |  |  | $ | 23,325 |  |  | $ | 18,293 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2019-08-06):
[0001437749-19-015632:note_history:59]
2.
 Revenue Recognition
  (was, 2019-02-05, similarity 0.95):
[0001628280-19-000966:note_history:59]
Revenue Recognition

- added (2019-08-06):
[0001437749-19-015632:note_history:60]
On 
 April 1, 2018, 
the Company adopted Accounting Standards Codification (“ASC”) 
606,

- added (2019-08-06):
[0001437749-19-015632:note_history:61]
Revenue from Contracts with Customers,

- added (2019-08-06):
[0001437749-19-015632:note_history:62]
and all the related amendments and applied it to all contracts that were 
not
 completed as of 
 April 1, 2018 
using the modified retrospective method.

- changed (2019-08-06):
[0001437749-19-015632:note_history:63]
The Company’s revenues in its Grid segment are derived primarily through enabling the transmission and distribution of power, providing planning services that allow it to identify power grid needs and risks, and developing ship protection systems for the U.S. Navy. The Company’s revenues in its Wind segment are derived primarily through supplying advanced power electronics and control systems, licensing its highly engineered wind turbine designs, and providing extensive customer support services to wind turbine manufacturers. The Company records revenue based on a 
five
-step model in accordance with ASC 
606.
 For its customer contracts, the Company identifies the performance obligations, determines the transaction price, allocates the contract transaction price to the performance obligations, and recognizes the revenue when (or as) control of goods or services is transferred to the customer. As of
  (was, 2019-02-05, similarity 0.919):
[0001628280-19-000966:note_history:63]
The Company’s revenues in its Grid segment are derived primarily through enabling the transmission and distribution of power, providing planning services that allow it to identify power grid needs and risks, and developing ship protection systems for the U.S. Navy. The Company’s revenues in its Wind segment are derived primarily through supplying advanced power electronics and control systems, licensing our highly engineered wind turbine designs, and providing extensive customer support services to wind turbine manufacturers.  The Company records revenue based on a five-step model in accordance with ASC 606. For its customer contracts, the Company identifies the performance obligations, determines the transaction price, allocates the contract transaction price to the performance obligations, and recognizes the revenue when (or as) control of goods or services is transferred to the customer.  As of December 31, 2018, 87% of revenue was recognized at the point in time when control transferred to the customer, with the remainder being recognized over time.

- added (2019-08-06):
[0001437749-19-015632:note_history:64]
June 30, 2019

- added (2019-08-06):
[0001437749-19-015632:note_history:65]
,

- added (2019-08-06):
[0001437749-19-015632:note_history:66]
78

- added (2019-08-06):
[0001437749-19-015632:note_history:67]
% of revenue was recognized at the point in time when control transferred to the customer, with the remainder being recognized over time.

- changed (2019-08-06):
[0001437749-19-015632:note_history:68]
In the Company's equipment and system product line, each contract with a customer summarizes each product sold to a customer, which typically represent distinct performance obligations. A contract's transaction price is allocated to each distinct performance obligation using the respective standalone selling price which is determined primarily using the cost plus expected margin approach and recognized as revenue when, or as, the performance obligation is satisfied. The majority of the Company’s product sales transfer control to the customer in line with the contracted delivery terms and revenue is recorded at the point in time when title and risk transfer to the customer, as the Company has determined that this is the point in time that control transfers to the customer.
  (was, 2019-02-05, similarity 0.9466):
[0001628280-19-000966:note_history:68]
In the Company's equipment and system product line, each contract with a customer summarizes each product sold to a customer, which typically represent distinct performance obligations.  A contract's transaction price is allocated to each distinct performance obligation using the respective standalone selling price which is determined primarily using the cost plus expected margin approach and recognized as revenue when, or as, the performance obligation is satisfied. The majority of the Company’s product sales transfer control to the customer in line with the contracted delivery terms and revenue is recorded at the point in time when products are transferred to the freight forwarder, as the Company has determined that this is the point in time that control transfers to the customer.

- added (2019-08-06):
[0001437749-19-015632:note_history:69]
The Company's equipment and system product line includes contracts which do 
not
 meet the requirements of an exchange transaction and therefore do 
not
 fall within the scope of ASC 
606.
  As these non-exchange transaction contracts are considered grant revenue and do 
not
 fall within any specific accounting literature, the Company follows guidance within ASC 
606
 by analogy to recognize grant revenue over time.  In the 
three
 months ended 
 June 30, 2019 
the Company recorded 
$0.4
 million in grant revenue, which is included in the Company’s Grid Revenue. There was 
no
 grant revenue in the prior year.

- changed (2019-08-06):
[0001437749-19-015632:note_history:70]
In the Company's service and technology development product line, there are several different types of transactions and each begins with a contract with a customer that summarizes each product sold to a customer, which typically represents distinct performance obligations. The technology development transactions are primarily for activities that have 
no
 alternative use and for which a profit can be expected throughout the life of the contract. In these cases, the revenue is recognized over time, but in the instances where the profit cannot be assured throughout the entire contract then the revenue is recognized at a point in time. Each contract's transaction price is allocated to each distinct performance obligation using the respective standalone selling price which is determined primarily using the cost plus expected margin approach. The ongoing service transactions are for service contracts that provide benefit to the customer simultaneously as the Company performs its obligations, and therefore this revenue is recognized ratably over time throughout the effective period of these contracts. The transaction prices on these contracts are allocated based on an adjusted market approach which is re-assessed annually for reasonableness. The field service transactions include contracts for delivery of goods and completion of services made at the customer's requests, which are 
not
 deemed satisfied until the work has been completed and/or the requested goods have been delivered, so all of this revenue is recognized at the point in time when the control changes, and at allocated prices based on the adjusted market approach driven by standard price lists. The royalty transactions are related to certain contract terms on transactions in the Company's equipment and systems product line based on activity as specified in the contracts. The transaction prices of these agreements are calculated based on an adjusted market approach as specified in the contract. The Company reports royalty revenue for usage-based royalties when the sales have occurred. In circumstances when collectability is 
not
 assured and a contract does 
not
 exist under ASC 
606,
 revenue is deferred until a non-refundable payment has been received for substantially all the amount that is due and there are 
no
 further remaining performance obligations.
  (was, 2019-02-05, similarity 0.9949):
[0001628280-19-000966:note_history:70]
In the Company's service and technology development product line, there are several different types of transactions but each of them begins with a contract with a customer that summarizes each product sold to a customer, which typically represents distinct performance obligations.  The technology development transactions are primarily for activities that have no alternative use and for which a profit can be expected throughout the life of the contract.  In these cases, the revenue is recognized over time, but in the instances where the profit cannot be assured throughout the entire contract then the revenue is recognized at a point in time.   Each contract's transaction price is allocated to each distinct performance obligation using the respective standalone selling price which is determined primarily using the cost plus expected margin approach.  The ongoing service transactions are for service contracts that provide benefit to the customer simultaneously as the Company performs its obligations, and therefore this revenue is recognized ratably over time throughout the effective period of these contracts.  The transaction prices on these contracts are allocated based on an adjusted market approach which is re-assessed annually for reasonableness.  The field service transactions include contracts for delivery of goods and completion of services made at the customer's requests, which are not deemed satisfied until the work has been completed and/or the requested goods have been delivered, so all of this revenue is recognized at the point in time when the control changes, and at allocated prices based on the adjusted market approach driven by standard price lists. The royalty transactions are related to certain contract terms on transactions in the Company's equipment and systems product line based on activity as specified in the contracts.  The transaction prices of these agreements are calculated based on an adjusted market approach as specified in the contract.  The Company reports royalty revenue for usage-based royalties when the sales have occurred.  In circumstances when collectability is not assured and a contract does not exist under ASC 606, revenue is deferred until a non-refundable payment has been received for substantially all the amount that is due and there are no further remaining performance obligations.

- added (2019-08-06):
[0001437749-19-015632:note_history:71]
|  |  | Three Months Ended June 30, 2019 |  |
| Product Line: |  | Grid |  |  | Wind |  |
| Equipment and systems |  | $ | 8,354 |  |  | $ | 3,505 |  |
| Services and technology development |  |  | 1,501 |  |  |  | 410 |  |
| Total |  | $ | 9,855 |  |  | $ | 3,915 |  |
| Region: |  |  |  |  |  |  |  |  |
| Americas |  | $ | 7,801 |  |  | $ | 46 |  |
| Asia Pacific |  |  | 1,827 |  |  |  | 3,856 |  |
| EMEA |  |  | 227 |  |  |  | 13 |  |
| Total |  | $ | 9,855 |  |  | $ | 3,915 |  |
|  |  | Three Months Ended June 30, 2018 |  |
| Product Line: |  | Grid |  |  | Wind |  |
| Equipment and systems |  | $ | 7,462 |  |  | $ | 3,492 |  |
| Services and technology development |  |  | 1,467 |  |  |  | 186 |  |
| Total |  | $ | 8,929 |  |  | $ | 3,678 |  |
| Region: |  |  |  |  |  |  |  |  |
| Americas |  | $ | 7,496 |  |  | $ | 23 |  |
| Asia Pacific |  |  | 808 |  |  |  | 3,595 |  |
| EMEA |  |  | 625 |  |  |  | 60 |  |
| Total |  | $ | 8,929 |  |  | $ | 3,678 |  |

- added (2019-08-06):
[0001437749-19-015632:note_history:72]
As of

- added (2019-08-06):
[0001437749-19-015632:note_history:73]
June 30, 2019

- added (2019-08-06):
[0001437749-19-015632:note_history:74]
and

- added (2019-08-06):
[0001437749-19-015632:note_history:75]
June 30, 2018

- changed (2019-08-06):
[0001437749-19-015632:note_history:76]
the Company’s contract assets and liabilities primarily relate to the timing differences between cash received from a customer in connection with contractual rights to invoicing and the timing of revenue recognition following completion of performance obligations. The Company's accounts receivable balance is made up entirely of customer contract related balances. Changes in the Company’s contract assets, which are included in “Unbilled Accounts Receivable” and “Deferred program costs” (see Note 
7,
 “Accounts Receivable” and Note 
8,
 “Inventory” for a reconciliation to the condensed consolidated balance sheets) and contract liabilities, which are included in the current portion and long term portion of “deferred revenue” in the Company’s condensed consolidated balance sheets, are as follows:
  (was, 2019-02-05, similarity 0.9671):
[0001628280-19-000966:note_history:76]
As of December 31, 2018 and March 31, 2018, the Company’s contract assets and liabilities primarily relate to the timing differences between cash received from a customer in connection with contractual rights to invoicing and the timing of revenue recognition following completion of performance obligations. The Company's accounts receivable balance is made up entirely of customer contract related balances.  Changes in the Company’s contract assets, which are included in “Unbilled AR” and “Deferred program costs” (see Note 7, “Accounts Receivable” and Note 8, “Inventory” for a reconciliation to the condensed consolidated balance sheet) and contract liabilities, which are included in the current portion and long term portion of “deferred revenue” in the Company’s condensed consolidated balance sheets, are as follows:

- added (2019-08-06):
[0001437749-19-015632:note_history:77]
|  |  | Unbilled Accounts Receivable |  |  | Deferred Program Costs |  |  | Contract Liabilities |  |
| Beginning balance as of March 31, 2018 |  | $ | 3,016 |  |  | $ | 2,567 |  |  | $ | 21,937 |  |
| Impact of adoption of ASC 606 |  |  | — |  |  |  | (1,599 | ) |  |  | (2,657 | ) |
| Increases for costs incurred to fulfill performance obligations |  |  | — |  |  |  | 1,132 |  |  |  | — |  |
| Increase (decrease) due to customer billings |  |  | (3,221 | ) |  |  | — |  |  |  | 4,281 |  |
| Decrease due to cost recognition on completed performance obligations |  |  | — |  |  |  | (48 | ) |  |  | — |  |
| Increase (decrease) due to recognition of revenue based on transfer of control of performance obligations |  |  | 4,824 |  |  |  | (9 | ) |  |  | (3,324 | ) |
| Other changes and FX impact |  |  | (16 | ) |  |  | 34 |  |  |  | (764 | ) |
| Ending balance as of June 30, 2018 |  | $ | 4,603 |  |  | $ | 2,077 |  |  | $ | 19,473 |  |
|  |  | Unbilled Accounts Receivable |  |  | Deferred Program Costs |  |  | Contract Liabilities |  |
| Beginning balance as of March 31, 2019 |  | $ | 2,213 |  |  | $ | 318 |  |  | $ | 15,521 |  |
| Increases for costs incurred to fulfill performance obligations |  |  | 0 |  |  |  | 771 |  |  |  | 0 |  |
| Increase (decrease) due to customer billings |  |  | (1,584 | ) |  |  | 0 |  |  |  | 10,857 |  |
| Decrease due to cost recognition on completed performance obligations |  |  | 0 |  |  |  | (4 | ) |  |  | 0 |  |
| Increase (decrease) due to recognition of revenue based on transfer of control of performance obligations |  |  | 1,467 |  |  |  | 0 |  |  |  | (7,761 | ) |
| Other changes and FX impact |  |  | (3 | ) |  |  | 3 |  |  |  | 73 |  |
| Ending balance as of June 30, 2019 |  | $ | 2,093 |  |  | $ | 1,088 |  |  | $ | 18,690 |  |

- added (2019-08-06):
[0001437749-19-015632:note_history:78]
The Company’s remaining performance obligations represent the unrecognized revenue value of the Company’s contractual commitments. The Company’s performance obligations 
 may 
vary significantly each reporting period based on the timing of major new contractual commitments. As of

- added (2019-08-06):
[0001437749-19-015632:note_history:79]
June 30, 2019

- added (2019-08-06):
[0001437749-19-015632:note_history:80]
, the Company had outstanding performance obligations on existing contracts under ASC 
606
 to be recognized in the next 
twelve
 months of approximately $

- added (2019-08-06):
[0001437749-19-015632:note_history:81]
54.7

- added (2019-08-06):
[0001437749-19-015632:note_history:82]
million. There are also approximately $

- added (2019-08-06):
[0001437749-19-015632:note_history:83]
9.8

- added (2019-08-06):
[0001437749-19-015632:note_history:84]
million of outstanding performance obligations to be recognized over a period of 
thirteen
 to 
sixty
 months. The remaining performance obligations are subject to customer actions and therefore the timing of revenue recognition cannot be reasonably estimated. The 
twelve
 month performance obligations include anticipated shipments to Inox based on the 
twelve
 month rolling forecast provided by Inox on the multi-year supply contract. The quantities specified in any forecast provided by Inox related to the multi-year supply contract are firm and irrevocable for the 
first

- added (2019-08-06):
[0001437749-19-015632:note_history:85]
three
 months of a 
twelve
 month rolling forecast. The timing of the performance obligations beyond the 
twelve
 month forecast provided by Inox are 
not
 determinable and therefore are 
not
 included in the total remaining performance obligations.

- changed (2019-08-06):
[0001437749-19-015632:note_history:86]
The following table sets forth customers who represented 
10%
 or more of the Company’s total revenues for the
  (was, 2019-02-05, similarity 0.8168):
[0001628280-19-000966:note_history:86]
The following table sets forth customers who represented 10% or more of the Company’s total revenues for the three and nine months ended December 31, 2018 and 2017:

- added (2019-08-06):
[0001437749-19-015632:note_history:87]
three

- added (2019-08-06):
[0001437749-19-015632:note_history:88]
months ended

- added (2019-08-06):
[0001437749-19-015632:note_history:89]
June 30, 2019

- added (2019-08-06):
[0001437749-19-015632:note_history:90]
and

- added (2019-08-06):
[0001437749-19-015632:note_history:91]
2018

- added (2019-08-06):
[0001437749-19-015632:note_history:92]
:

- added (2019-08-06):
[0001437749-19-015632:note_history:93]
|  |  |  | Three Months Ended |  |
|  | Reportable |  | June 30, 2019 |  |
|  | Segment |  | 2019 |  |  | 2018 |  |
| Inox Wind Limited | Wind |  | 27% |  |  | 25% |  |
| Vestas | Grid |  | <10% |  |  | 36% |  |
| Micron Technology | Grid |  | 25% |  |  | <10% |  |

- removed (2019-08-06):
[0001628280-19-000966:note_history:94]
On April 1, 2018, the Company adopted Accounting Standards Codification (“ASC”) 606, Revenue from Contracts with Customers, and all the related amendments and applied it to all contracts that were not completed as of April 1, 2018 using the modified retrospective method. The Company recognized the cumulative effect of initially applying the new revenue standard as an adjustment of less than $0.1 million to the opening balance of accumulated deficit. Prior period amounts have not been restated and continue to be reported under the accounting standards in effect for those periods.

- removed (2019-08-06):
[0001628280-19-000966:note_history:95]
The adoption of this guidance has led to recognizing certain revenue transactions sooner than in the past on certain contracts, as the Company will need to estimate the revenue it will be entitled to upon contract completion, and later on other contracts, such as Consulting and Statement of Work transactions, due to the lack of an enforceable right to payment for performance obligations satisfied over time, specifically in the technology product line.  The Company does not expect a material impact to its consolidated statements of operations on an ongoing basis from the adoption of the new standard.

- removed (2019-08-06):
[0001628280-19-000966:note_history:96]
In addition, the FASB issued Accounting Standards Update (“ASU”) 2017-05, Other Income - Gains and Losses from the Derecognition of Non-financial Assets (Subtopic 610-20), in February 2017, to amend ASC 610-20, Other Income - Gains and Losses from the Derecognition of Non-financial Assets (issued at the same time as ASC 606), which provides a model for the measurement and recognition of gains and losses on the sale of non-financial assets, such as property and equipment, including real estate. As a result of adopting ASU 2017-05 on April 1, 2018, the Company recognized an adjustment to the opening balance of accumulated deficit for the deferred gain from the March 28, 2018 sale of the Company's former headquarters in Devens, Massachusetts in the amount of $0.1 million.

- removed (2019-08-06):
[0001628280-19-000966:note_history:97]
The cumulative effect to the Company’s consolidated April 1, 2018 balance sheet from the adoption of the new revenue standard and the sale of nonfinancial assets was as follows (in thousands):

- removed (2019-08-06):
[0001628280-19-000966:note_history:98]
|  | March 31, 2018 |  | Opening Adjustment |  | April 1, 2018 |
| Assets: |  |  |  |  |  |
| Accounts Receivable | $ | 7,365 |  |  | $ | (678 | ) |  | $ | 6,687 |  |
| Inventory | 19,780 |  |  | (1,599 | ) |  | 18,181 |  |
| Prepaid expenses and other current assets | 2,947 |  |  | 2,277 |  |  | 5,224 |  |
| Notes receivable, long term portion | 2,559 |  |  | 105 |  |  | 2,664 |  |
| Liabilities and Stockholders' Equity: |  |  |  |  |  |
| Accounts payable and accrued expenses | $ | (12,625 | ) |  | $ | (2,729 | ) |  | $ | (15,354 | ) |
| Deferred revenue | (13,483 | ) |  | 2,657 |  |  | (10,826 | ) |
| Accumulated deficit | $ | (988,333 | ) |  | $ | (33 | ) |  | $ | (988,366 | ) |

- removed (2019-08-06):
[0001628280-19-000966:note_history:99]
Included in the opening adjustment are reclassifications for accounts receivable, deferred program costs and deferred revenue for previous balances related to agreements that no longer meet the definition of a customer contract under ASC 606.  The impact of adoption on the Company’s opening balances and for the three and nine months ended December 31, 2018, in all financial statement line items impacted by ASC 606 was immaterial from the amount that would have been reported under the previous guidance.

- removed (2019-08-06):
[0001628280-19-000966:note_history:100]
|  | Three Months Ended December 31, 2018 |  | Nine Months Ended December 31, 2018 |
| Product Line: | Grid |  | Wind |  | Grid |  | Wind |
| Equipment and systems | $ | 4,614 |  |  | $ | 7,215 |  |  | $ | 17,571 |  |  | $ | 17,925 |  |
| Services and technology development | 2,212 |  |  | 93 |  |  | 5,754 |  |  | 368 |  |
| Total | $ | 6,826 |  |  | $ | 7,308 |  |  | $ | 23,325 |  |  | $ | 18,293 |  |
| Region: |  |  |  |  |  |  |  |
| Americas | $ | 3,771 |  |  | $ | 36 |  |  | $ | 16,319 |  |  | $ | 82 |  |
| Asia Pacific | 2,815 |  |  | 7,263 |  |  | 5,930 |  |  | 18,136 |  |
| EMEA | 240 |  |  | 9 |  |  | 1,076 |  |  | 75 |  |
| Total | $ | 6,826 |  |  | $ | 7,308 |  |  | $ | 23,325 |  |  | $ | 18,293 |  |

- removed (2019-08-06):
[0001628280-19-000966:note_history:101]
|  | Unbilled AR |  | Deferred Program Costs |  | Contract Liabilities |
| Beginning balance as of March 31, 2018 | $ | 3,016 |  |  | $ | 2,567 |  |  | $ | 21,937 |  |
| Impact of adoption of ASC 606 | — |  |  | (1,599 | ) |  | (2,657 | ) |
| Increases for costs incurred to fulfill performance obligations | — |  |  | 1,461 |  |  | — |  |
| Increase (decrease) due to customer billings | (11,063 | ) |  | — |  |  | 11,167 |  |
| Decrease due to cost recognition on completed performance obligations | — |  |  | (1,132 | ) |  | — |  |
| Increase (decrease) due to recognition of revenue based on transfer of control of performance obligations | 9,722 |  |  | (9 | ) |  | (11,345 | ) |
| Other changes and FX impact | (53 | ) |  | 8 |  |  | (1,040 | ) |
| Ending balance as of December 31, 2018 | $ | 1,622 |  |  | $ | 1,296 |  |  | $ | 18,062 |  |

- removed (2019-08-06):
[0001628280-19-000966:note_history:102]
The Company’s remaining performance obligations represent the unrecognized revenue value of the Company’s contractual commitments. The Company’s performance obligations may vary significantly each reporting period based on the timing of major new contractual commitments. As of December 31, 2018, the Company had outstanding performance obligations on existing contracts under ASC 606 to be recognized in the next twelve months of approximately $36.8 million.  There are also approximately $12.9 million of outstanding performance obligations to be recognized over a period of thirteen to sixty months.  The remaining performance obligations are subject to customer actions and therefore the timing of revenue recognition cannot be reasonably estimated.  The twelve month performance obligations include anticipated shipments to Inox based on the twelve month rolling forecast provided by Inox on the multi-year supply contract. The quantities specified in any forecast provided by Inox related to the multi-year supply contract are firm and irrevocable for the first three months of a twelve month rolling forecast. The timing of the performance obligations beyond the Inox twelve month provided forecast are not determinable and therefore are not included in the total remaining performance obligations.

- removed (2019-08-06):
[0001628280-19-000966:note_history:103]
|  | Reportable |  | Three Months EndedDecember 31, |  | Nine Months EndedDecember 31, |
|  | Segment |  | 2018 |  | 2017 |  | 2018 |  | 2017 |
| Inox Wind Limited | Wind |  | 47 | % |  | 15 | % |  | 40 | % |  | 27 | % |
| Vestas | Grid |  | <10 % |  |  | 27 | % |  | 15 | % |  | 11 | % |
| SSE Generation Ltd. | Grid |  | <10 % |  |  | 17 | % |  | <10 % |  |  | <10 % |  |
| Fuji Bridex Pte Ltd | Grid |  | 17 | % |  | — | % |  | <10 % |  |  | — | % |


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: tag_name, score: 1.0

- changed (2019-08-06):
[0001437749-19-015632:note_history:104]
19.
 Subsequent Events
  (was, 2019-02-05, similarity 0.9444):
[0001628280-19-000966:note_history:104]
Subsequent Events

- changed (2019-08-06):
[0001437749-19-015632:note_history:105]
The Company has performed an evaluation of subsequent events through the time of filing this Quarterly Report on Form 
10
-Q with the SEC and has determined that there are 
no
 such events to report other than those already discussed.
  (was, 2019-02-05, similarity 0.9151):
[0001628280-19-000966:note_history:105]
The Company has performed an evaluation of subsequent events through the time of filing this Quarterly Report on Form 10-Q with the SEC and has determined that there are no such events to report.
