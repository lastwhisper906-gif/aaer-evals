# PANW 8-K — 0001327567-22-000006 filed 2022-02-22

## item codes, every 8-K on or before 2022-02-23

- 2022-02-23 0001193125-22-049906 — 5.02
- 2022-02-22 0001327567-22-000006 — 2.02, 9.01
- 2021-12-15 0001193125-21-358074 — 5.02, 5.07
- 2021-11-18 0001327567-21-000037 — 2.02, 9.01
- 2021-10-12 0001193125-21-296438 — 3.01, 7.01, 9.01
- 2021-09-13 0001193125-21-270979 — 7.01, 9.01
- 2021-09-08 0001193125-21-267862 — 5.02, 9.01
- 2021-08-23 0001327567-21-000020 — 2.02, 9.01
- 2021-08-12 0001193125-21-244832 — 5.02, 9.01
- 2021-05-20 0001327567-21-000012 — 2.02, 9.01
- 2021-05-18 0001193125-21-164169 — 5.02 — amendment of 0001193125-21-162161
- 2021-05-14 0001193125-21-162161 — 5.02, 9.01
- 2021-03-19 0001193125-21-087516 — 5.02, 9.01
- 2021-02-22 0001628280-21-002659 — 2.02, 9.01
- 2021-02-22 0001193125-21-049293 — 5.02, 9.01
- 2020-12-18 0001193125-20-321568 — 8.01, 9.01
- 2020-12-16 0001193125-20-319091 — 3.02 — amendment of 0001193125-20-291707
- 2020-12-10 0001193125-20-314920 — 5.07
- 2020-12-08 0001193125-20-312056 — 5.02, 8.01, 9.01
- 2020-11-16 0001327567-20-000037 — 2.02, 9.01
- 2020-11-12 0001193125-20-291707 — 3.02
- 2020-10-19 0001193125-20-272060 — 5.02
- 2020-08-24 0001327567-20-000025 — 2.02, 9.01
- 2020-06-23 0001193125-20-176553 — 5.02, 9.01
- 2020-06-22 0001193125-20-175603 — 5.02, 9.01
- 2020-06-08 0001193125-20-163579 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2020-05-21 0001327567-20-000015 — 2.02, 9.01
- 2020-02-27 0001193125-20-050335 — 1.01, 2.03
- 2020-02-24 0001327567-20-000002 — 2.02, 9.01
- 2019-12-19 0001193125-19-319166 — 1.02, 9.01
- 2019-12-10 0001193125-19-310251 — 5.07
- 2019-11-25 0001327567-19-000036 — 2.02, 9.01
- 2019-11-25 0001193125-19-299886 — 5.02, 8.01 — amendment of 0001327567-19-000011
- 2019-10-22 0001193125-19-271660 — 5.02
- 2019-09-06 0001327567-19-000026 — 9.01 — amendment of 0001327567-19-000023
- 2019-09-04 0001327567-19-000023 — 2.02, 7.01, 9.01
- 2019-07-11 0001193125-19-192415 — 5.02, 9.01
- 2019-05-29 0001327567-19-000014 — 2.02, 9.01
- 2019-04-15 0001327567-19-000011 — 5.02, 9.01
- 2019-04-01 0001193125-19-094613 — 8.01, 9.01
- 2019-03-28 0001193125-19-090572 — 3.02 — amendment of 0001327567-19-000003
- 2019-02-26 0001327567-19-000006 — 2.02, 8.01, 9.01
- 2019-02-19 0001327567-19-000003 — 3.02
- 2018-12-11 0001327567-18-000033 — 5.07
- 2018-11-29 0001327567-18-000029 — 2.02, 9.01
- 2018-10-15 0001193125-18-299312 — 5.02, 9.01
- 2018-09-25 0001193125-18-282542 — 5.02
- 2018-09-14 0001193125-18-274239 — 5.03, 9.01
- 2018-09-06 0001327567-18-000018 — 1.01, 2.02, 2.03, 9.01
- 2018-07-13 0001193125-18-217281 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2018-06-04 0001327567-18-000011 — 2.02, 5.02, 9.01
- 2018-02-26 0001327567-18-000004 — 2.02, 5.02, 7.01, 9.01
- 2017-12-12 0001193125-17-367477 — 5.07
- 2017-11-20 0001327567-17-000032 — 2.02, 5.02, 9.01
- 2017-08-31 0001327567-17-000021 — 2.02, 5.02, 9.01
- 2017-05-31 0001327567-17-000016 — 2.02, 9.01
- 2017-02-28 0001327567-17-000005 — 2.02, 8.01, 9.01
- 2016-12-12 0001193125-16-790757 — 5.07
- 2016-11-21 0001327567-16-000071 — 2.02, 9.01
- 2016-10-24 0001193125-16-745121 — 5.02, 9.01
- 2016-08-30 0001327567-16-000057 — 2.02, 5.03, 8.01, 9.01
- 2016-08-22 0001193125-16-687588 — 5.02, 9.01
- 2016-05-26 0001327567-16-000051 — 2.02, 9.01
- 2016-02-25 0001327567-16-000044 — 2.02, 5.02, 9.01
- 2015-12-14 0001327567-15-000038 — 5.07
- 2015-12-14 0001193125-15-402588 — 1.01, 9.01
- 2015-11-23 0001327567-15-000033 — 2.02, 9.01
- 2015-10-19 0001193125-15-347005 — 1.01, 9.01 — amendment, the index does not say of what
- 2015-09-09 0001327567-15-000022 — 2.02, 9.01
- 2015-08-19 0001193125-15-296115 — 1.01, 2.03
- 2015-06-01 0001193125-15-207786 — 1.01, 2.03
- 2015-05-27 0001327567-15-000015 — 2.02, 9.01
- 2015-03-02 0001327567-15-000006 — 2.02, 9.01
- 2014-12-15 0001327567-14-000046 — 5.07
- 2014-11-24 0001327567-14-000040 — 2.02, 9.01
- 2014-09-22 0001193125-14-348581 — 5.02, 9.01
- 2014-09-09 0001327567-14-000025 — 2.02, 9.01
- 2014-07-01 0001193125-14-257824 — 1.01, 2.03, 3.02, 9.01
- 2014-06-26 0001193125-14-249529 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2014-06-20 0001327567-14-000020 — 9.01 — amendment of 0001193125-14-140511
- 2014-06-04 0001327567-14-000016 — 3.02
- 2014-05-30 0001193125-14-218158 — 2.02 — amendment, the index does not say of what
- 2014-05-28 0001193125-14-215060 — 1.01, 2.02, 3.02, 9.01
- 2014-04-11 0001193125-14-140511 — 2.01, 3.02, 7.01, 9.01
- 2014-03-24 0001193125-14-111318 — 1.01, 3.02, 7.01, 9.01
- 2014-03-13 0001327567-14-000009 — 5.02
- 2014-02-24 0001193125-14-063754 — 2.02, 9.01
- 2013-12-12 0001327567-13-000040 — 5.07
- 2013-11-25 0001327567-13-000033 — 2.02, 9.01
- 2013-09-30 0001193125-13-384966 — 8.01
- 2013-09-09 0001193125-13-361421 — 2.02, 9.01
- 2013-05-30 0001193125-13-241542 — 2.02, 5.02, 9.01
- 2013-03-11 0001193125-13-101082 — 5.02, 9.01
- 2013-02-28 0001193125-13-084193 — 2.02, 9.01
- 2012-12-14 0001193125-12-503335 — 5.07
- 2012-12-06 0001193125-12-493700 — 2.02, 9.01
- 2012-09-24 0001193125-12-401534 — 1.01, 2.03
- 2012-09-20 0001193125-12-398433 — 5.02, 9.01
- 2012-09-10 0001193125-12-386605 — 2.02, 9.01

## late-filing notifications on or before 2022-02-23

- none on or before 2022-02-23

## item 2.02 — earnings release, exhibit 99.1

[0001327567-22-000006:8k_2_02:1]
EX-99
2
ex991q222earningsrelease.htm
EX-99

[0001327567-22-000006:8k_2_02:2]
Document

[0001327567-22-000006:8k_2_02:3]
Exhibit 99.1

[0001327567-22-000006:8k_2_02:4]
Palo Alto Networks Reports Fiscal Second Quarter 2022 Financial Results.

[0001327567-22-000006:8k_2_02:5]
Live earnings call at 2pm Pacific Time today

[0001327567-22-000006:8k_2_02:6]
•Fiscal second quarter revenue grew 30% year over year to $1.3 billion

[0001327567-22-000006:8k_2_02:7]
•Fiscal second quarter billings grew 32% year over year to $1.6 billion

[0001327567-22-000006:8k_2_02:8]
•Remaining performance obligation grew 36% year over year to $6.3 billion

[0001327567-22-000006:8k_2_02:9]
SANTA CLARA, Calif., Feb. 22, 2022 — Palo Alto Networks (NASDAQ: PANW), the global cybersecurity leader, announced today financial results for its fiscal second quarter 2022, ended January 31, 2022.

[0001327567-22-000006:8k_2_02:10]
Total revenue for the fiscal second quarter 2022 grew 30% year over year to $1.3 billion, compared with total revenue of $1.0 billion for the fiscal second quarter 2021. GAAP net loss for the fiscal second quarter 2022 was $93.5 million, or $0.95 per diluted share, compared with GAAP net loss of $142.3 million, or $1.48 per diluted share, for the fiscal second quarter 2021.

[0001327567-22-000006:8k_2_02:11]
Non-GAAP net income for the fiscal second quarter 2022 was $185.0 million, or $1.74 per diluted share, compared with non-GAAP net income of $154.2 million, or $1.55 per diluted share, for the fiscal second quarter 2021. A reconciliation between GAAP and non-GAAP information is contained in the tables below.

[0001327567-22-000006:8k_2_02:12]
“In Q2, our company continued to benefit from strength across our three security platforms, driven by strong cybersecurity demand, organizations architecting for hybrid work and growing their hyperscale cloud footprints,” said Nikesh Arora, chairman and CEO of Palo Alto Networks. “On the back of this strength, notably in our next-generation security offerings, we are raising our guidance for the year across revenue, billings, and earnings per share.”

[0001327567-22-000006:8k_2_02:13]
“Total shareholder return was at the forefront of our Q2 results as we continued to deliver on accelerated revenue growth and strong cash flow generation as well as returned capital to shareholders,” said Dipak Golechha, chief financial officer of Palo Alto Networks.

[0001327567-22-000006:8k_2_02:14]
Financial Outlook

[0001327567-22-000006:8k_2_02:15]
Palo Alto Networks provides guidance based on current market conditions and expectations.

[0001327567-22-000006:8k_2_02:16]
For the fiscal third quarter 2022, we expect:

[0001327567-22-000006:8k_2_02:17]
•Total billings in the range of $1.59 billion to $1.61 billion, representing year-over-year growth of between 24% and 25%.

[0001327567-22-000006:8k_2_02:18]
•Total revenue in the range of $1.345 billion to $1.365 billion, representing year-over-year growth of between 25% and 27%.

[0001327567-22-000006:8k_2_02:19]
•Diluted non-GAAP net income per share in the range of $1.65 to $1.68, using 106 million to 108 million shares outstanding.

[0001327567-22-000006:8k_2_02:20]
For the fiscal year 2022, we are broadly raising guidance and expect:

[0001327567-22-000006:8k_2_02:21]
•Total billings in the range of $6.80 billion to $6.85 billion, representing year-over-year growth of between 25% and 26%.

[0001327567-22-000006:8k_2_02:22]
•Total revenue in the range of $5.425 billion to $5.475 billion, representing year-over-year growth of between 27% and 29%.

[0001327567-22-000006:8k_2_02:23]
•Diluted non-GAAP net income per share in the range of $7.23 to $7.30, using 106 million to 108 million shares.

[0001327567-22-000006:8k_2_02:24]
•Adjusted free cash flow margin in the range of 32% to 33%.

[0001327567-22-000006:8k_2_02:25]
Guidance for non-GAAP financial measures excludes share-based compensation-related charges (including share-based payroll tax expense), acquisition-related costs, amortization expense of acquired intangible assets, litigation-related charges, including legal settlements, non-cash charges related to convertible notes, and related foreign currency gains (losses) and income and other tax effects associated with these items, along with certain non-recurring expenses and certain non-recurring cash flows. We have not reconciled diluted non-GAAP net income per share guidance to GAAP net income (loss) per diluted share or adjusted free cash flow margin guidance to GAAP net cash from operating activities because we do not provide guidance on GAAP net income (loss) or net cash from operating activities and would not be able to present the various reconciling cash and non-cash items between GAAP and non-GAAP financial measures because certain items that impact these measures are uncertain or out of our control, or cannot be reasonably predicted, including share-based compensation expense, without unreasonable effort.

[0001327567-22-000006:8k_2_02:26]
The actual amounts of such reconciling items will have a significant impact on the company's GAAP net income (loss) per diluted share and GAAP net cash from operating activities.

[0001327567-22-000006:8k_2_02:27]
Earnings Call Information

[0001327567-22-000006:8k_2_02:28]
Palo Alto Networks will host a video webcast for analysts and investors to discuss the company’s fiscal second quarter 2022 results as well as the outlook for its fiscal third quarter 2022 today at 5:00 p.m. Eastern time/2:00 p.m. Pacific time. Open to the public, investors may access the webcast, supplemental financial information and earnings slides from the “Investors” section of the company’s website at investors.paloaltonetworks.com. A replay will be available three hours after the conclusion of the webcast and archived for one year.

[0001327567-22-000006:8k_2_02:29]
Forward-Looking Statements

[0001327567-22-000006:8k_2_02:30]
This press release contains forward-looking statements that involve risks, uncertainties, and assumptions including statements regarding our financial outlook for the fiscal third quarter 2022 and fiscal year 2022. There are a significant number of factors that could cause actual results to differ materially from statements made in this press release, including: developments and changes in general market, political, economic, and business conditions; the duration and global impact of COVID-19; risks associated with managing our growth; risks associated with new products and subscription and support offerings, including the discovery of software bugs; shifts in priorities or delays in the development or release of new subscription offerings, or the failure to timely develop and achieve market acceptance of new products and subscriptions as well as existing products and subscription and support offerings; rapidly evolving technological developments in the market for security products and subscription and support offerings; our customers’ purchasing decisions and the length of sales cycles; our competition; our ability to attract and retain new customers; our ability as an organization to acquire and integrate other companies, products, or technologies in a successful manner; the effects of supply chain constraints and the global chip and component shortages and other factors affecting the manufacture, delivery, and cost of certain of our products; our ability to obtain adequate supply of our products from our third-party manufacturing partners; our debt repayment obligations; and our share repurchase program, which may not be fully consummated or enhance shareholder value, and any share repurchases which could affect the price of our common stock.

[0001327567-22-000006:8k_2_02:31]
Additional risks and uncertainties that could affect our financial results are included under the captions "Risk Factors" and "Management's Discussion and Analysis of Financial Condition and

[0001327567-22-000006:8k_2_02:32]
3

[0001327567-22-000006:8k_2_02:33]
Results of Operations" in our Quarterly Report on Form 10-Q filed with the SEC on November 19, 2021, which is available on our website at investors.paloaltonetworks.com and on the SEC's website at www.sec.gov. Additional information will also be set forth in other filings that we make with the SEC from time to time. All forward-looking statements in this press release are based on information available to us as of the date hereof, and we do not assume any obligation to update the forward-looking statements provided to reflect events that occur or circumstances that exist after the date on which they were made.

[0001327567-22-000006:8k_2_02:34]
Non-GAAP Financial Measures and Other Key Metrics

[0001327567-22-000006:8k_2_02:35]
Palo Alto Networks has provided in this press release financial information that has not been prepared in accordance with generally accepted accounting principles in the United States (GAAP). The company uses these non-GAAP financial measures and other key metrics internally in analyzing its financial results and believes that the use of these non-GAAP financial measures and key metrics are useful to investors as an additional tool to evaluate ongoing operating results and trends, and in comparing the company’s financial results with other companies in its industry, many of which present similar non-GAAP financial measures or key metrics.

[0001327567-22-000006:8k_2_02:36]
The presentation of these non-GAAP financial measures and key metrics are not meant to be considered in isolation or as a substitute for comparable GAAP financial measures and should be read only in conjunction with the company’s consolidated financial statements prepared in accordance with GAAP. A reconciliation of the company’s historical non-GAAP financial measures to their most directly comparable GAAP measures has been provided in the financial statement tables included in this press release, and investors are encouraged to review these reconciliations.

[0001327567-22-000006:8k_2_02:37]
Non-GAAP net income and net income per share, diluted. Palo Alto Networks defines non-GAAP net income as net income (loss) plus share-based compensation-related charges, including share-based payroll tax expense, acquisition-related costs, amortization expense of acquired intangible assets, litigation-related charges, including legal settlements, gains (losses) related to facility exit, and non-cash charges related to convertible notes. The company also excludes from non-GAAP net income the foreign currency gains (losses) and tax effects associated with these items in order to provide a complete picture of the company’s recurring core business operating results. The company defines non-GAAP net income per share, diluted, as non-GAAP net income divided by the weighted-average diluted shares outstanding, which includes the potentially dilutive effect of the company’s employee equity incentive plan awards and the company’s convertible senior notes

[0001327567-22-000006:8k_2_02:38]
outstanding and related warrants, after giving effect to the anti-dilutive impact of the company’s note hedge agreements, which reduces the potential economic dilution that otherwise would occur upon conversion of the company’s convertible senior notes. Under GAAP, the anti-dilutive impact of the note hedge is not reflected in diluted shares outstanding. The company believes that excluding these items from non-GAAP net income and net income per share, diluted, provides management and investors with greater visibility into the underlying performance of the company’s core business operating results, meaning its operating performance excluding these items and, from time to time, other discrete charges that are infrequent in nature, over multiple periods.

[0001327567-22-000006:8k_2_02:39]
Billings. Palo Alto Networks defines billings as total revenue plus the change in total deferred revenue, net of acquired deferred revenue, during the period. The company considers billings to be a key metric used by management to manage the company’s business and believes billings provides investors with an important indicator of the health and visibility of the company’s business because it includes subscription and support revenue, which is recognized ratably over the contractual service period, and product revenue, which is recognized at the time of shipment, provided that all other conditions for revenue recognition have been met. The company considers billings to be a useful metric for management and investors, particularly if sales of subscriptions continue to increase and the company experiences strong renewal rates for subscriptions and support.

[0001327567-22-000006:8k_2_02:40]
Investors are cautioned that there are a number of limitations associated with the use of non-GAAP financial measures and key metrics as analytical tools. In particular, the billings metric reported by the company includes amounts that have not yet been recognized as revenue. Additionally, many of the adjustments to the company’s GAAP financial measures reflect the exclusion of items that are recurring and will be reflected in the company’s financial results for the foreseeable future, such as share-based compensation, which is an important part of Palo Alto Networks employees’ compensation and impacts their performance. Furthermore, these non-GAAP financial measures are not based on any standardized methodology prescribed by GAAP, and the components that Palo Alto Networks excludes in its calculation of non-GAAP financial measures may differ from the components that its peer companies exclude when they report their non-GAAP results of operations. Palo Alto Networks compensates for these limitations by providing specific information regarding the GAAP amounts excluded from these non-GAAP financial measures. In the future, the company may also exclude non-recurring expenses and other expenses that do not reflect the company’s core business operating results.

[0001327567-22-000006:8k_2_02:41]
5

[0001327567-22-000006:8k_2_02:42]
About Palo Alto Networks

[0001327567-22-000006:8k_2_02:43]
Palo Alto Networks, the global cybersecurity leader, is shaping the cloud-centric future with technology that is transforming the way people and organizations operate. Our mission is to be the cybersecurity partner of choice, protecting our digital way of life. We help address the world’s greatest security challenges with continuous innovation that seizes the latest breakthroughs in artificial intelligence, analytics, automation, and orchestration. By delivering an integrated platform and empowering a growing ecosystem of partners, we are at the forefront of protecting tens of thousands of organizations across clouds, networks, and mobile devices. Our vision is a world where each day is safer and more secure than the one before. For more information, visit www.paloaltonetworks.com.

[0001327567-22-000006:8k_2_02:44]
Palo Alto Networks and the Palo Alto Networks logo are trademarks of Palo Alto Networks, Inc. in the United States and in jurisdictions throughout the world. All other trademarks, trade names, or service marks used or mentioned herein belong to their respective owners.

[0001327567-22-000006:8k_2_02:45]
Media Contact:

[0001327567-22-000006:8k_2_02:46]
Andria Leaf

[0001327567-22-000006:8k_2_02:47]
Senior Manager of Corporate Communications, Palo Alto Networks

[0001327567-22-000006:8k_2_02:48]
press@paloaltonetworks.com

[0001327567-22-000006:8k_2_02:49]
Investor Relations Contact:

[0001327567-22-000006:8k_2_02:50]
Clay Bilby

[0001327567-22-000006:8k_2_02:51]
Head of Investor Relations, Palo Alto Networks

[0001327567-22-000006:8k_2_02:52]
ir@paloaltonetworks.com

[0001327567-22-000006:8k_2_02:53]
| Palo Alto Networks, Inc. |
| Preliminary Condensed Consolidated Statements of Operations |
| (In millions, except per share data) |
| (Unaudited) |
|  | Three Months Ended |  | Six Months Ended |
|  | January 31, |  | January 31, |
|  | 2022 |  | 2021 |  | 2022 |  | 2021 |
| Revenue: |  |  |  |  |  |  |  |
| Product | $ | 308.0 |  |  | $ | 254.7 |  |  | $ | 603.5 |  |  | $ | 492.0 |  |
| Subscription and support | 1,008.9 |  |  | 762.2 |  |  | 1,960.8 |  |  | 1,470.9 |  |
| Total revenue | 1,316.9 |  |  | 1,016.9 |  |  | 2,564.3 |  |  | 1,962.9 |  |
| Cost of revenue: |  |  |  |  |  |  |  |
| Product | 97.8 |  |  | 75.6 |  |  | 186.7 |  |  | 137.8 |  |
| Subscription and support | 307.5 |  |  | 232.0 |  |  | 599.2 |  |  | 447.6 |  |
| Total cost of revenue | 405.3 |  |  | 307.6 |  |  | 785.9 |  |  | 585.4 |  |
| Total gross profit | 911.6 |  |  | 709.3 |  |  | 1,778.4 |  |  | 1,377.5 |  |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | 359.0 |  |  | 266.7 |  |  | 698.5 |  |  | 504.1 |  |
| Sales and marketing | 528.8 |  |  | 427.4 |  |  | 1,034.7 |  |  | 816.0 |  |
| General and administrative | 97.7 |  |  | 104.0 |  |  | 201.8 |  |  | 190.7 |  |
| Total operating expenses | 985.5 |  |  | 798.1 |  |  | 1,935.0 |  |  | 1,510.8 |  |
| Operating loss | (73.9) |  |  | (88.8) |  |  | (156.6) |  |  | (133.3) |  |
| Interest expense | (6.8) |  |  | (40.7) |  |  | (13.7) |  |  | (80.9) |  |
| Other income (expense), net | (0.1) |  |  | (0.5) |  |  | (1.7) |  |  | 1.9 |  |
| Loss before income taxes | (80.8) |  |  | (130.0) |  |  | (172.0) |  |  | (212.3) |  |
| Provision for income taxes | 12.7 |  |  | 12.3 |  |  | 25.1 |  |  | 22.2 |  |
| Net loss | $ | (93.5) |  |  | $ | (142.3) |  |  | $ | (197.1) |  |  | $ | (234.5) |  |
| Net loss per share, basic and diluted | $ | (0.95) |  |  | $ | (1.48) |  |  | $ | (2.01) |  |  | $ | (2.45) |  |
| Weighted-average shares used to compute net loss per share, basic and diluted | 98.2 |  |  | 95.9 |  |  | 97.9 |  |  | 95.7 |  |

[0001327567-22-000006:8k_2_02:54]
7

[0001327567-22-000006:8k_2_02:55]
| Palo Alto Networks, Inc. |
| Reconciliation of GAAP to Non-GAAP Financial Measures |
| (In millions, except per share amounts) |
| (Unaudited) |
|  | Three Months Ended |  | Six Months Ended |
|  | January 31, |  | January 31, |
|  | 2022 |  | 2021 |  | 2022 |  | 2021 |
| GAAP net loss | $ | (93.5) |  |  | $ | (142.3) |  |  | $ | (197.1) |  |  | $ | (234.5) |  |
| Share-based compensation-related charges | 283.3 |  |  | 238.6 |  |  | 553.5 |  |  | 450.1 |  |
| Acquisition-related costs(1) | — |  |  | 20.6 |  |  | 3.1 |  |  | 33.7 |  |
| Amortization expense of acquired intangible assets | 31.5 |  |  | 29.6 |  |  | 63.1 |  |  | 53.1 |  |
| Litigation-related charges(2) | 1.8 |  |  | 1.8 |  |  | 3.6 |  |  | 3.6 |  |
| Non-cash charges related to convertible notes(3) | 1.8 |  |  | 35.5 |  |  | 3.6 |  |  | 70.6 |  |
| Foreign currency (gain) loss associated with non-GAAP adjustments | (0.5) |  |  | 1.7 |  |  | 0.6 |  |  | 1.6 |  |
| Income tax and other tax adjustments related to the above | (39.4) |  |  | (31.3) |  |  | (75.1) |  |  | (65.9) |  |
| Non-GAAP net income | $ | 185.0 |  |  | $ | 154.2 |  |  | $ | 355.3 |  |  | $ | 312.3 |  |
| GAAP net loss per share, diluted | $ | (0.95) |  |  | $ | (1.48) |  |  | $ | (2.01) |  |  | $ | (2.45) |  |
| Share-based compensation-related charges | 2.74 |  |  | 2.43 |  |  | 5.40 |  |  | 4.60 |  |
| Acquisition-related costs(1) | 0.00 |  |  | 0.21 |  |  | 0.03 |  |  | 0.35 |  |
| Amortization expense of acquired intangible assets | 0.32 |  |  | 0.31 |  |  | 0.64 |  |  | 0.55 |  |
| Litigation-related charges(2) | 0.02 |  |  | 0.02 |  |  | 0.04 |  |  | 0.04 |  |
| Non-cash charges related to convertible notes(3) | 0.02 |  |  | 0.37 |  |  | 0.04 |  |  | 0.74 |  |
| Foreign currency (gain) loss associated with non-GAAP adjustments | (0.01) |  |  | 0.02 |  |  | 0.01 |  |  | 0.02 |  |
| Income tax and other tax adjustments related to the above | (0.40) |  |  | (0.33) |  |  | (0.77) |  |  | (0.69) |  |
| Non-GAAP net income per share, diluted | $ | 1.74 |  |  | $ | 1.55 |  |  | $ | 3.38 |  |  | $ | 3.16 |  |
| GAAP weighted-average shares used to compute net loss per share, diluted | 98.2 |  |  | 95.9 |  |  | 97.9 |  |  | 95.7 |  |
| Weighted-average effect of potentially dilutive securities(4) | 8.1 |  |  | 3.7 |  |  | 7.2 |  |  | 3.0 |  |
| Non-GAAP weighted-average shares used to compute net income per share, diluted | 106.3 |  |  | 99.6 |  |  | 105.1 |  |  | 98.7 |  |

[0001327567-22-000006:8k_2_02:56]
(1)    Consists of acquisition transaction costs, share-based compensation related to the cash settlement of certain equity awards, and costs to terminate certain employment, operating lease, and other contracts of the acquired companies.

[0001327567-22-000006:8k_2_02:57]
(2)    Consists of the amortization of intellectual property licenses and covenant not to sue.

[0001327567-22-000006:8k_2_02:58]
(3)    Consists primarily of non-cash interest expense for amortization of debt discount and issuance costs related to the company's convertible senior notes. Effective Q1'22, the company no longer recognizes interest expense for amortization of debt discount as a result of the adoption of new debt guidance.

[0001327567-22-000006:8k_2_02:59]
(4)    Non-GAAP net income per share, diluted, includes the potentially dilutive effect of employee equity incentive plan awards and convertible senior notes outstanding and related warrants. In addition, non-GAAP net income per share, diluted includes the anti-dilutive impact of the company’s note hedge agreements, which reduced the potentially dilutive effect of the convertible notes by 6.0 million and 5.5 million for the three and six months ended January 31, 2022, respectively, and 2.7 million and 1.4 million for the three and six months ended January 31, 2021, respectively.

[0001327567-22-000006:8k_2_02:60]
8

[0001327567-22-000006:8k_2_02:61]
| Palo Alto Networks, Inc. |
| Calculation of Billings |
| (In millions) |
| (Unaudited) |
|  | Three Months Ended |  | Six Months Ended |
|  | January 31, |  | January 31, |
|  | 2022 |  | 2021 |  | 2022 |  | 2021 |
| Total revenue | $ | 1,316.9 |  |  | $ | 1,016.9 |  |  | $ | 2,564.3 |  |  | $ | 1,962.9 |  |
| Add: change in total deferred revenue, net of acquired deferred revenue | 291.0 |  |  | 197.8 |  |  | 425.2 |  |  | 334.6 |  |
| Billings | $ | 1,607.9 |  |  | $ | 1,214.7 |  |  | $ | 2,989.5 |  |  | $ | 2,297.5 |  |

[0001327567-22-000006:8k_2_02:62]
9

[0001327567-22-000006:8k_2_02:63]
| Palo Alto Networks, Inc. |
| Preliminary Condensed Consolidated Balance Sheets |
| (In millions) |
|  | January 31, 2022 |  | July 31, 2021 |
|  | (unaudited) |  |  |
| Assets |  |  |  |
| Current assets: |  |  |  |
| Cash and cash equivalents | $ | 1,922.7 |  |  | $ | 1,874.2 |  |
| Short-term investments | 1,417.6 |  |  | 1,026.9 |  |
| Accounts receivable, net | 952.2 |  |  | 1,240.4 |  |
| Short-term deferred contract costs | 278.1 |  |  | 276.5 |  |
| Prepaid expenses and other current assets | 298.0 |  |  | 229.3 |  |
| Total current assets | 4,868.6 |  |  | 4,647.3 |  |
| Property and equipment, net | 362.7 |  |  | 318.4 |  |
| Operating lease right-of-use assets | 238.8 |  |  | 262.9 |  |
| Long-term investments | 851.0 |  |  | 888.3 |  |
| Long-term deferred contract costs | 472.1 |  |  | 494.6 |  |
| Goodwill | 2,731.3 |  |  | 2,710.1 |  |
| Intangible assets, net | 443.9 |  |  | 498.6 |  |
| Other assets | 432.1 |  |  | 421.4 |  |
| Total assets | $ | 10,400.5 |  |  | $ | 10,241.6 |  |
| Liabilities, temporary equity and stockholders’ equity |  |  |  |
| Current liabilities: |  |  |  |
| Accounts payable | $ | 120.4 |  |  | $ | 56.9 |  |
| Accrued compensation | 329.9 |  |  | 430.6 |  |
| Accrued and other liabilities | 324.0 |  |  | 329.4 |  |
| Deferred revenue | 2,958.2 |  |  | 2,741.9 |  |
| Convertible senior notes, net | 3,673.9 |  |  | 1,557.9 |  |
| Total current liabilities | 7,406.4 |  |  | 5,116.7 |  |
| Convertible senior notes, net | — |  |  | 1,668.1 |  |
| Long-term deferred revenue | 2,491.0 |  |  | 2,282.1 |  |
| Long-term operating lease liabilities | 282.4 |  |  | 313.4 |  |
| Other long-term liabilities | 102.9 |  |  | 97.7 |  |
| Temporary equity | — |  |  | 129.1 |  |
| Stockholders’ equity: |  |  |  |
| Preferred stock | — |  |  | — |  |
| Common stock and additional paid-in capital | 1,745.2 |  |  | 2,311.2 |  |
| Accumulated other comprehensive loss | (30.2) |  |  | (9.9) |  |
| Accumulated deficit | (1,597.2) |  |  | (1,666.8) |  |
| Total stockholders’ equity | 117.8 |  |  | 634.5 |  |
| Total liabilities, temporary equity and stockholders’ equity | $ | 10,400.5 |  |  | $ | 10,241.6 |  |

[0001327567-22-000006:8k_2_02:64]
10
