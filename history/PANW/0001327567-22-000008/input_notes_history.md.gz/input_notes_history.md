# PANW note change history — 0001327567-21-000040 → 0001327567-22-000008


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2022-02-23):
[0001327567-22-000008:note_history:1]
In order to reduce manufacturing lead times and plan for adequate supply, we enter into agreements with manufacturing partners and component suppliers to procure inventory based on our demand forecasts. The following table presents details of the aggregate future purchase commitments under these arrangements, excluding obligations under contracts that we can cancel without a significant penalty as of January 31, 2022 (in millions):
  (was, 2021-11-19, similarity 0.9825):
[0001327567-21-000040:note_history:1]
In order to reduce manufacturing lead times and plan for adequate supply, we enter into agreements with manufacturing partners and component suppliers to procure inventory based on our demand forecasts. The following table presents details of the aggregate future purchase commitments under these arrangements excluding obligations under contracts that we can cancel without a significant penalty as of October 31, 2021 (in millions):

- changed (2022-02-23):
[0001327567-22-000008:note_history:2]
We have entered into various non-cancelable agreements with certain service providers, under which we are committed to minimum or fixed purchases. The following table presents details of the aggregate future non-cancelable purchase commitments under these agreements as of January 31, 2022 (in millions):
  (was, 2021-11-19, similarity 0.9766):
[0001327567-21-000040:note_history:2]
We have entered into various non-cancelable agreements with certain service providers, under which we are committed to minimum or fixed purchases. The following table presents details of the aggregate future non-cancelable purchase commitments under these agreements as of October 31, 2021 (in millions):

- changed (2022-02-23):
[0001327567-22-000008:note_history:3]
To the extent there is a reasonable possibility that a loss exceeding amounts already recognized may be incurred and the amount of such additional loss would be material, we will either disclose the estimated additional loss or state that such an estimate cannot be made. As of January 31, 2022, we have not recorded any significant accruals for loss contingencies associated with such legal proceedings, determined that an unfavorable outcome is probable or reasonably possible, or determined that the amount or range of any possible loss is reasonably estimable.
  (was, 2021-11-19, similarity 0.9875):
[0001327567-21-000040:note_history:3]
To the extent there is a reasonable possibility that a loss exceeding amounts already recognized may be incurred and the amount of such additional loss would be material, we will either disclose the estimated additional loss or state that such an estimate cannot be made. As of October 31, 2021, we have not recorded any significant accruals for loss contingencies associated with such legal proceedings, determined that an unfavorable outcome is probable or reasonably possible, or determined that the amount or range of any possible loss is reasonably estimable.

- removed (2022-02-23):
[0001327567-21-000040:note_history:4]
Land Purchase Agreement

- removed (2022-02-23):
[0001327567-21-000040:note_history:5]
During the three months ended October 31, 2021, we entered into an agreement to purchase 4.6 acres of land adjacent to our headquarters in Santa Clara, California for $38.9 million in cash. If consummated, the transaction would be expected to close during our fiscal quarter ending January 31, 2022.


## us-gaap:OrganizationConsolidationBasisOfPresentationBusinessDescriptionAndAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2022-02-23):
[0001327567-22-000008:note_history:6]
Palo Alto Networks, Inc. (the “Company,” “we,” “us,” or “our”), headquartered in Santa Clara, California, was incorporated in March 2005 under the laws of the State of Delaware and commenced operations in April 2005. We empower enterprises, service providers, and government entities to secure all users, applications, data, networks, clouds and devices with comprehensive visibility and context, continuously across all locations.
  (was, 2021-11-19, similarity 0.9988):
[0001327567-21-000040:note_history:6]
Palo Alto Networks, Inc. (the “Company,” “we,” “us,” or “our”), headquartered in Santa Clara, California, was incorporated in March 2005 under the laws of the State of Delaware and commenced operations in April 2005. We empower enterprises, service providers, and government entities to secure all users, applications, data, networks, clouds and devices with comprehensive visibility and context continuously across all locations.

- changed (2022-02-23):
[0001327567-22-000008:note_history:7]
There have been no material changes to our significant accounting policies as of and for the six months ended January 31, 2022, as compared to the significant accounting policies described in our Annual Report on Form 10-K for the fiscal year ended July 31, 2021, except for the change in our accounting policies due to our adoption of recently issued guidance. Refer to “Recently Adopted Accounting Pronouncements” below.
  (was, 2021-11-19, similarity 0.9732):
[0001327567-21-000040:note_history:7]
There have been no material changes to our significant accounting policies as of and for the three months ended October 31, 2021, as compared to the significant accounting policies described in our Annual Report on Form 10-K for the fiscal year ended July 31, 2021, except for the change in our accounting policies due to our adoption of recently issued guidance. Refer to “Recently Adopted Accounting Pronouncements” below.

- changed (2022-02-23):
[0001327567-22-000008:note_history:8]
We adopted this standard in our first quarter of fiscal 2022 using the modified-retrospective approach, under which financial results reported in periods prior to fiscal 2022 were not adjusted. The adoption of this standard resulted in an increase to convertible senior notes, net of $444.3 million, a decrease to accumulated deficit of $266.7 million, and a decrease to additional paid-in capital and temporary equity of $711.0 million upon adoption.
  (was, 2021-11-19, similarity 0.9988):
[0001327567-21-000040:note_history:8]
We adopted this standard in our first quarter of fiscal 2022 using the modified-retrospective approach, under which, financial results reported in periods prior to fiscal 2022 were not adjusted. The adoption of this standard resulted in an increase to convertible senior notes, net of $444.3 million, a decrease to accumulated deficit of $266.7 million, and a decrease to additional paid-in capital and temporary equity of $711.0 million upon adoption.

- added (2022-02-23):
[0001327567-22-000008:note_history:9]
Prior to August 1, 2021, our convertible senior notes were separated into a liability and an equity component. The carrying amount of the liability component was calculated by measuring the fair value of a similar liability that did not have an associated convertible feature, using a discounted cash flow model with a risk-adjusted yield. The carrying amount of the equity component representing the conversion option was determined by deducting the fair value of the liability component from the par value of the notes as a whole. This difference represented a debt discount that was amortized to interest expense using the effective interest method over the term of the notes. The equity component was not remeasured as it continued to meet the conditions for equity classification. Transaction costs related to the issuance of the notes were allocated to the liability and equity components using the same proportions as the proceeds from the notes. Transaction costs attributable to the liability component were netted with the liability component and amortized to interest expense using the effective interest method over the term of the notes. Transaction costs attributable to the equity component were netted with the equity component of the notes in additional paid-in capital. Upon the notes becoming convertible, the net carrying amount of the liability component was classified as a current liability and a portion of the equity component representing the conversion option was reclassified to temporary equity. The portion of the equity component classified as temporary equity was measured as the difference between the principal and net carrying amount of the notes, excluding debt issuance costs.
Upon adoption of the new debt guidance on August 1, 2021, our convertible senior notes are accounted for entirely as a liability and measured at their amortized cost. Transaction costs related to the issuance of the notes are netted with the liability and are amortized on a straight-line basis, which approximates the effective interest rate method, to interest expense over the term of the notes. Refer to Note 9. Debt for additional information.

- removed (2022-02-23):
[0001327567-21-000040:note_history:10]
Prior to August 1, 2021, our convertible senior notes were separated into a liability and an equity component. The carrying amount of the liability component was calculated by measuring the fair value of a similar liability that did not have an associated convertible feature, using a discounted cash flow model with a risk adjusted yield. The carrying amount of the equity component representing the conversion option was determined by deducting the fair value of the liability component from the par value of the notes as a whole. This difference represented a debt discount that was amortized to interest expense using the effective interest method over the term of the notes. The equity component was not remeasured as it continued to meet the conditions for equity classification. Transaction costs related to the issuance of the notes were allocated to the liability and equity components using the same proportions as the proceeds from the notes. Transaction costs attributable to the liability component were netted with the liability component and amortized to interest expense using the effective interest method over the term of the notes. Transaction costs attributable to the equity component were netted with the equity component of the notes in additional paid-in capital. Upon the notes becoming convertible, the net carrying amount of the liability component was classified as a current liability and a portion of the equity component representing the conversion option was reclassified to temporary equity. The portion of the equity component classified as temporary equity was measured as the difference between the principal and net carrying amount of the notes, excluding debt issuance costs.
Upon adoption of the new debt guidance on August 1, 2021, our convertible senior notes are accounted for entirely as a liability and measured at their amortized cost. Transaction costs related to the issuance of the notes are netted with the liability and are amortized on a straight-line basis, which approximates the effective interest rate method, to interest expense over the term of the notes. Refer to Note 9. Debt for additional information.


## panw:ConvertibleSeniorNotesPolicyPolicyTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2022-02-23):
[0001327567-22-000008:note_history:11]
Prior to August 1, 2021, our convertible senior notes were separated into a liability and an equity component. The carrying amount of the liability component was calculated by measuring the fair value of a similar liability that did not have an associated convertible feature, using a discounted cash flow model with a risk-adjusted yield. The carrying amount of the equity component representing the conversion option was determined by deducting the fair value of the liability component from the par value of the notes as a whole. This difference represented a debt discount that was amortized to interest expense using the effective interest method over the term of the notes. The equity component was not remeasured as it continued to meet the conditions for equity classification. Transaction costs related to the issuance of the notes were allocated to the liability and equity components using the same proportions as the proceeds from the notes. Transaction costs attributable to the liability component were netted with the liability component and amortized to interest expense using the effective interest method over the term of the notes. Transaction costs attributable to the equity component were netted with the equity component of the notes in additional paid-in capital. Upon the notes becoming convertible, the net carrying amount of the liability component was classified as a current liability and a portion of the equity component representing the conversion option was reclassified to temporary equity. The portion of the equity component classified as temporary equity was measured as the difference between the principal and net carrying amount of the notes, excluding debt issuance costs.
Upon adoption of the new debt guidance on August 1, 2021, our convertible senior notes are accounted for entirely as a liability and measured at their amortized cost. Transaction costs related to the issuance of the notes are netted with the liability and are amortized on a straight-line basis, which approximates the effective interest rate method, to interest expense over the term of the notes.

- removed (2022-02-23):
[0001327567-21-000040:note_history:12]
Prior to August 1, 2021, our convertible senior notes were separated into a liability and an equity component. The carrying amount of the liability component was calculated by measuring the fair value of a similar liability that did not have an associated convertible feature, using a discounted cash flow model with a risk adjusted yield. The carrying amount of the equity component representing the conversion option was determined by deducting the fair value of the liability component from the par value of the notes as a whole. This difference represented a debt discount that was amortized to interest expense using the effective interest method over the term of the notes. The equity component was not remeasured as it continued to meet the conditions for equity classification. Transaction costs related to the issuance of the notes were allocated to the liability and equity components using the same proportions as the proceeds from the notes. Transaction costs attributable to the liability component were netted with the liability component and amortized to interest expense using the effective interest method over the term of the notes. Transaction costs attributable to the equity component were netted with the equity component of the notes in additional paid-in capital. Upon the notes becoming convertible, the net carrying amount of the liability component was classified as a current liability and a portion of the equity component representing the conversion option was reclassified to temporary equity. The portion of the equity component classified as temporary equity was measured as the difference between the principal and net carrying amount of the notes, excluding debt issuance costs.
Upon adoption of the new debt guidance on August 1, 2021, our convertible senior notes are accounted for entirely as a liability and measured at their amortized cost. Transaction costs related to the issuance of the notes are netted with the liability and are amortized on a straight-line basis, which approximates the effective interest rate method, to interest expense over the term of the notes.


## us-gaap:ConvertibleDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2022-02-23):
[0001327567-22-000008:note_history:13]
The following table sets forth the components of the Notes as of January 31, 2022 and July 31, 2021 (in millions):
  (was, 2021-11-19, similarity 0.9423):
[0001327567-21-000040:note_history:13]
The following table sets forth the components of the Notes as of October 31, 2021 and July 31, 2021 (in millions):

- changed (2022-02-23):
[0001327567-22-000008:note_history:14]
|  | January 31, 2022 (1) | July 31, 2021 |
|  | 2023 Notes |  | 2025 Notes |  | Total |  | 2023 Notes |  | 2025 Notes |  | Total |
| Liability component: |  |  |  |  |  |  |  |  |  |  |  |
| Principal | $ | 1,692.0 |  |  | $ | 2,000.0 |  |  | $ | 3,692.0 |  |  | $ | 1,692.0 |  |  | $ | 2,000.0 |  |  | $ | 3,692.0 |  |
| Less: debt discount and debt issuance costs, net of amortization | (4.0) |  |  | (14.1) |  |  | (18.1) |  |  | (134.1) |  |  | (331.9) |  |  | (466.0) |  |
| Net carrying amount | $ | 1,688.0 |  |  | $ | 1,985.9 |  |  | $ | 3,673.9 |  |  | $ | 1,557.9 |  |  | $ | 1,668.1 |  |  | $ | 3,226.0 |  |
| Equity component (including amounts classified as temporary equity) | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 315.0 |  |  | $ | 403.0 |  |  | $ | 718.0 |  |
  (was, 2021-11-19, similarity 0.9883):
[0001327567-21-000040:note_history:14]
|  | October 31, 2021 (1) | July 31, 2021 |
|  | 2023 Notes |  | 2025 Notes |  | Total |  | 2023 Notes |  | 2025 Notes |  | Total |
| Liability component: |  |  |  |  |  |  |  |  |  |  |  |
| Principal | $ | 1,692.0 |  |  | $ | 2,000.0 |  |  | $ | 3,692.0 |  |  | $ | 1,692.0 |  |  | $ | 2,000.0 |  |  | $ | 3,692.0 |  |
| Less: debt discount and debt issuance costs, net of amortization | (4.7) |  |  | (15.2) |  |  | (19.9) |  |  | (134.1) |  |  | (331.9) |  |  | (466.0) |  |
| Net carrying amount | $ | 1,687.3 |  |  | $ | 1,984.8 |  |  | $ | 3,672.1 |  |  | $ | 1,557.9 |  |  | $ | 1,668.1 |  |  | $ | 3,226.0 |  |
| Equity component (including amounts classified as temporary equity) | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 315.0 |  |  | $ | 403.0 |  |  | $ | 718.0 |  |


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2022-02-23):
[0001327567-22-000008:note_history:15]
The sale price condition for the Notes was met during the fiscal quarter ended January 31, 2022, and as a result, holders may convert their Notes at any time during the fiscal quarter ending April 30, 2022. Accordingly, the net carrying amount of the Notes was classified as a current liability on our condensed consolidated balance sheet as of January 31, 2022.

- changed (2022-02-23):
[0001327567-22-000008:note_history:16]
The following table sets forth the components of the Notes as of January 31, 2022 and July 31, 2021 (in millions):
  (was, 2021-11-19, similarity 0.9423):
[0001327567-21-000040:note_history:16]
The following table sets forth the components of the Notes as of October 31, 2021 and July 31, 2021 (in millions):

- changed (2022-02-23):
[0001327567-22-000008:note_history:17]
|  | January 31, 2022 (1) | July 31, 2021 |
|  | 2023 Notes |  | 2025 Notes |  | Total |  | 2023 Notes |  | 2025 Notes |  | Total |
| Liability component: |  |  |  |  |  |  |  |  |  |  |  |
| Principal | $ | 1,692.0 |  |  | $ | 2,000.0 |  |  | $ | 3,692.0 |  |  | $ | 1,692.0 |  |  | $ | 2,000.0 |  |  | $ | 3,692.0 |  |
| Less: debt discount and debt issuance costs, net of amortization | (4.0) |  |  | (14.1) |  |  | (18.1) |  |  | (134.1) |  |  | (331.9) |  |  | (466.0) |  |
| Net carrying amount | $ | 1,688.0 |  |  | $ | 1,985.9 |  |  | $ | 3,673.9 |  |  | $ | 1,557.9 |  |  | $ | 1,668.1 |  |  | $ | 3,226.0 |  |
| Equity component (including amounts classified as temporary equity) | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 315.0 |  |  | $ | 403.0 |  |  | $ | 718.0 |  |
  (was, 2021-11-19, similarity 0.9883):
[0001327567-21-000040:note_history:17]
|  | October 31, 2021 (1) | July 31, 2021 |
|  | 2023 Notes |  | 2025 Notes |  | Total |  | 2023 Notes |  | 2025 Notes |  | Total |
| Liability component: |  |  |  |  |  |  |  |  |  |  |  |
| Principal | $ | 1,692.0 |  |  | $ | 2,000.0 |  |  | $ | 3,692.0 |  |  | $ | 1,692.0 |  |  | $ | 2,000.0 |  |  | $ | 3,692.0 |  |
| Less: debt discount and debt issuance costs, net of amortization | (4.7) |  |  | (15.2) |  |  | (19.9) |  |  | (134.1) |  |  | (331.9) |  |  | (466.0) |  |
| Net carrying amount | $ | 1,687.3 |  |  | $ | 1,984.8 |  |  | $ | 3,672.1 |  |  | $ | 1,557.9 |  |  | $ | 1,668.1 |  |  | $ | 3,226.0 |  |
| Equity component (including amounts classified as temporary equity) | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 315.0 |  |  | $ | 403.0 |  |  | $ | 718.0 |  |

- added (2022-02-23):
[0001327567-22-000008:note_history:18]
The total estimated fair value of the 2023 Notes and 2025 Notes were $3.3 billion and $3.6 billion at January 31, 2022, respectively and $2.6 billion and $2.9 billion at July 31, 2021, respectively. The fair value was determined based on the closing trading price per $100 of the applicable series of the Notes as of the last day of trading for the period. We consider the fair value of the Notes

- added (2022-02-23):
[0001327567-22-000008:note_history:19]
at January 31, 2022 and July 31, 2021 to be a Level 2 measurement. The fair value of the Notes is primarily affected by the trading price of our common stock and market interest rates.

- changed (2022-02-23):
[0001327567-22-000008:note_history:20]
|  | Three Months Ended January 31, |  | Six Months Ended January 31, |
|  | 2022 |  | 2021 |  | 2022 |  | 2021 |
|  | 2023 Notes |  | 2025 Notes |  | Total |  | 2023 Notes |  |  |  | 2025 Notes |  | Total |  | 2023 Notes |  | 2025 Notes |  | Total |  | 2023 Notes |  | 2025 Notes |  | Total |
| Contractual interest expense | $ | 3.1 |  | $ | 1.9 |  | $ | 5.0 |  |  | $ | 3.1 |  |  |  | $ | 1.9 |  | $ | 5.0 |  | $ | 6.3 |  | $ | 3.8 |  | $ | 10.1 |  |  | $ | 6.3 |  | $ | 3.8 |  | $ | 10.1 |  |
| Amortization of debt discount(1) | — |  | — |  | — |  |  | 15.7 |  |  |  | 18.5 |  | 34.2 |  | — |  | — |  | — |  |  | 31.4 |  | 36.7 |  | 68.1 |  |
| Amortization of debt issuance costs | 0.7 |  | 1.1 |  | 1.8 |  |  | 0.6 |  |  |  | 0.7 |  | 1.3 |  | 1.4 |  | 2.2 |  | 3.6 |  |  | 1.1 |  | 1.4 |  | 2.5 |  |
| Total interest expense | $ | 3.8 |  | $ | 3.0 |  | $ | 6.8 |  |  | $ | 19.4 |  |  |  | $ | 21.1 |  | $ | 40.5 |  | $ | 7.7 |  | $ | 6.0 |  | $ | 13.7 |  |  | $ | 38.8 |  | $ | 41.9 |  | $ | 80.7 |  |
| Effective interest rate | 0.9 | % |  | 0.6 | % |  |  |  | 5.2% |  |  |  | 5.4 | % |  |  |  | 0.9 | % |  | 0.6 | % |  |  |  | 5.2 | % |  | 5.4 | % |  |  |
  (was, 2021-11-19, similarity 0.6051):
[0001327567-21-000040:note_history:20]
|  | Three Months Ended October 31, |  |  |
|  | 2021 |  | 2020 |  |  |  |  |
|  | 2023 Notes |  | 2025 Notes |  | Total |  | 2023 Notes |  |  |  | 2025 Notes |  | Total |  |  |  |  |  |  |  |  |  |  |  |  |
| Contractual interest expense | $ | 3.2 |  | $ | 1.9 |  | $ | 5.1 |  |  | $ | 3.2 |  |  |  |  | $ | 1.9 |  | $ | 5.1 |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of debt discount(1) | — |  | — |  | — |  |  | 15.7 |  |  |  |  | 18.2 |  | 33.9 |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of debt issuance costs | 0.7 |  | 1.1 |  | 1.8 |  |  | 0.5 |  |  |  |  | 0.7 |  | 1.2 |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Total interest expense | $ | 3.9 |  | $ | 3.0 |  | $ | 6.9 |  |  | $ | 19.4 |  |  |  |  | $ | 20.8 |  | $ | 40.2 |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Effective interest rate | 0.9 | % |  | 0.6 | % |  |  |  | 5.2% |  |  |  | 5.4 | % |  |  |  |  |  |  |  |  |  |  |  |  |  |  |

- changed (2022-02-23):
[0001327567-22-000008:note_history:21]
The Note Hedges cover shares of our common stock at a strike price per share that corresponds to the initial applicable conversion price of the applicable series of the Notes, which are also subject to adjustment, and are exercisable upon conversion of the applicable series of the Notes. The Note Hedges will expire upon maturity of the applicable series of the Notes. The Note Hedges are separate transactions and are not part of the terms of the applicable series of the Notes. Holders of the Notes of either series will not have any rights with respect to the Note Hedges. Any shares of our common stock receivable by us under the Note Hedges are excluded from the calculation of diluted earnings per share as they are antidilutive. The aggregate amounts paid for the Note Hedges are included in additional paid-in capital on our condensed consolidated balance sheets.
  (was, 2021-11-19, similarity 0.9989):
[0001327567-21-000040:note_history:21]
The Note Hedges cover shares of our common stock at a strike price per share that corresponds to the initial applicable conversion price of the applicable series of the Notes, which are also subject to adjustment, and are exercisable upon conversion of the applicable series of the Notes. The Note Hedges will expire upon maturity of the applicable series of the Notes. The Note Hedges are separate transactions and are not part of the terms of the applicable series of the Notes. Holders of the Notes of either series will not have any rights with respect to the Note Hedges. Any shares of our common stock receivable by us under the Note Hedges are excluded from the calculation of diluted earnings per share as they are antidilutive. The aggregate amounts paid for the Note Hedges are included in additional paid-in capital in our condensed consolidated balance sheets.

- changed (2022-02-23):
[0001327567-22-000008:note_history:22]
The shares issuable under the Warrants will be included in the calculation of diluted earnings per share when the average market value per share of our common stock for the reporting period exceeds the applicable strike price for such series of Warrants. The Warrants are separate transactions and are not part of either series of Notes or Note Hedges and are not remeasured through earnings each reporting period. Holders of the Notes of either series will not have any rights with respect to the Warrants. The
  (was, 2021-11-19, similarity 0.8743):
[0001327567-21-000040:note_history:22]
The shares issuable under the Warrants will be included in the calculation of diluted earnings per share when the average market value per share of our common stock for the reporting period exceeds the applicable strike price for such series of Warrants. The Warrants are separate transactions and are not part of either series of Notes or Note Hedges and are not remeasured through earnings each reporting period. Holders of the Notes of either series will not have any rights with respect to the Warrants. The aggregate proceeds received from the sale of the Warrants are included in additional paid-in capital in our condensed consolidated balance sheets.

- added (2022-02-23):
[0001327567-22-000008:note_history:23]
aggregate proceeds received from the sale of the Warrants are included in additional paid-in capital on our condensed consolidated balance sheets.

- changed (2022-02-23):
[0001327567-22-000008:note_history:24]
On September 4, 2018, we entered into a credit agreement (the “Credit Agreement”) with certain institutional lenders that provides for a $400.0 million unsecured revolving credit facility (the “Credit Facility”), with an option to increase the amount of the Credit Facility by up to an additional $350.0 million, subject to certain conditions. The Credit Facility matures on the earlier of (i) September 4, 2023 and (ii) the date that is 91 days prior to the stated maturity of our 2023 Notes if (a) any of the 2023 Notes are still outstanding and (b) our unrestricted cash and cash equivalents are less than the then outstanding principal amount of our 2023 Notes plus $400.0 million.
  (was, 2021-11-19, similarity 0.8675):
[0001327567-21-000040:note_history:24]
On September 4, 2018, we entered into a credit agreement (the “Credit Agreement”) with certain institutional lenders that provides for a $400.0 million unsecured revolving credit facility (the “Credit Facility”), with an option to increase the amount of the Credit Facility by up to an additional $350.0 million, subject to certain conditions. The Credit Facility matures on the earlier of (i) September 4, 2023 and (ii) the date that is 91 days prior to the stated maturity of our 2023 Notes if (a) any of the 2023 Notes are

- changed (2022-02-23):
[0001327567-22-000008:note_history:25]
As of January 31, 2022, there were no amounts outstanding and we were in compliance with all covenants under the Credit Agreement.
  (was, 2021-11-19, similarity 0.9516):
[0001327567-21-000040:note_history:25]
As of October 31, 2021, there were no amounts outstanding and we were in compliance with all covenants under the Credit Agreement.

- removed (2022-02-23):
[0001327567-21-000040:note_history:26]
The sale price condition for the Notes was met during the fiscal quarter ended October 31, 2021, and as a result, holders may convert their Notes at any time during the fiscal quarter ending January 31, 2022. Accordingly, the net carrying amount of the Notes was classified as a current liability on our condensed consolidated balance sheet as of October 31, 2021.

- removed (2022-02-23):
[0001327567-21-000040:note_history:27]
The total estimated fair value of the 2023 Notes and 2025 Notes were $3.2 billion and $3.4 billion at October 31, 2021, respectively and $2.6 billion and $2.9 billion at July 31, 2021, respectively. The fair value was determined based on the closing trading price per $100 of the applicable series of the Notes as of the last day of trading for the period. We consider the fair value of the Notes at October 31, 2021 and July 31, 2021 to be a Level 2 measurement. The fair value of the Notes is primarily affected by the trading price of our common stock and market interest rates.

- removed (2022-02-23):
[0001327567-21-000040:note_history:28]
still outstanding and (b) our unrestricted cash and cash equivalents are less than the then outstanding principal amount of our 2023 Notes plus $400.0 million.


## us-gaap:DebtSecuritiesAvailableForSaleTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2022-02-23):
[0001327567-22-000008:note_history:29]
The following tables summarize the amortized cost, unrealized gains and losses, and fair value of our available-for-sale debt securities as of January 31, 2022 and July 31, 2021 (in millions):
  (was, 2021-11-19, similarity 0.967):
[0001327567-21-000040:note_history:29]
The following tables summarize the amortized cost, unrealized gains and losses, and fair value of our available-for-sale debt securities as of October 31, 2021 and July 31, 2021 (in millions):

- added (2022-02-23):
[0001327567-22-000008:note_history:30]
|  | January 31, 2022 |
|  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Fair Value |
| Cash equivalents: |  |  |  |  |  |  |  |
| Corporate debt securities | $ | 8.7 |  |  | $ | — |  |  | $ | — |  |  | $ | 8.7 |  |
| Total available-for-sale cash equivalents | $ | 8.7 |  |  | $ | — |  |  | $ | — |  |  | $ | 8.7 |  |
| Investments: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 305.6 |  |  | $ | — |  |  | $ | — |  |  | $ | 305.6 |  |
| Commercial paper | 1.2 |  |  | — |  |  | — |  |  | 1.2 |  |
| Corporate debt securities | 782.8 |  |  | 0.1 |  |  | (3.7) |  |  | 779.2 |  |
| U.S. government and agency securities | 1,102.6 |  |  | 0.1 |  |  | (5.7) |  |  | 1,097.0 |  |
| Non-U.S. government and agency securities | 60.5 |  |  | — |  |  | (0.2) |  |  | 60.3 |  |
| Asset-backed securities | 25.4 |  |  | — |  |  | (0.1) |  |  | 25.3 |  |
| Total available-for-sale investments | $ | 2,278.1 |  |  | $ | 0.2 |  |  | $ | (9.7) |  |  | $ | 2,268.6 |  |

- removed (2022-02-23):
[0001327567-21-000040:note_history:31]
|  | October 31, 2021 |
|  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Fair Value |
| Cash equivalents: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 150.5 |  |  | $ | — |  |  | $ | — |  |  | $ | 150.5 |  |
| Corporate debt securities | 26.1 |  |  | — |  |  | — |  |  | 26.1 |  |
| U.S. government and agency securities | 70.0 |  |  | — |  |  | — |  |  | 70.0 |  |
| Total available-for-sale cash equivalents | $ | 246.6 |  |  | $ | — |  |  | $ | — |  |  | $ | 246.6 |  |
| Investments: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 156.5 |  |  | $ | — |  |  | $ | — |  |  | $ | 156.5 |  |
| Corporate debt securities | 428.2 |  |  | 0.1 |  |  | (0.5) |  |  | 427.8 |  |
| U.S. government and agency securities | 1,442.6 |  |  | 0.6 |  |  | (0.9) |  |  | 1,442.3 |  |
| Non-U.S. government and agency securities | 60.7 |  |  | — |  |  | — |  |  | 60.7 |  |
| Total available-for-sale investments | $ | 2,088.0 |  |  | $ | 0.7 |  |  | $ | (1.4) |  |  | $ | 2,087.3 |  |


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2022-02-23):
[0001327567-22-000008:note_history:32]
The following tables summarize the amortized cost, unrealized gains and losses, and fair value of our available-for-sale debt securities as of January 31, 2022 and July 31, 2021 (in millions):
  (was, 2021-11-19, similarity 0.967):
[0001327567-21-000040:note_history:32]
The following tables summarize the amortized cost, unrealized gains and losses, and fair value of our available-for-sale debt securities as of October 31, 2021 and July 31, 2021 (in millions):

- added (2022-02-23):
[0001327567-22-000008:note_history:33]
|  | January 31, 2022 |
|  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Fair Value |
| Cash equivalents: |  |  |  |  |  |  |  |
| Corporate debt securities | $ | 8.7 |  |  | $ | — |  |  | $ | — |  |  | $ | 8.7 |  |
| Total available-for-sale cash equivalents | $ | 8.7 |  |  | $ | — |  |  | $ | — |  |  | $ | 8.7 |  |
| Investments: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 305.6 |  |  | $ | — |  |  | $ | — |  |  | $ | 305.6 |  |
| Commercial paper | 1.2 |  |  | — |  |  | — |  |  | 1.2 |  |
| Corporate debt securities | 782.8 |  |  | 0.1 |  |  | (3.7) |  |  | 779.2 |  |
| U.S. government and agency securities | 1,102.6 |  |  | 0.1 |  |  | (5.7) |  |  | 1,097.0 |  |
| Non-U.S. government and agency securities | 60.5 |  |  | — |  |  | (0.2) |  |  | 60.3 |  |
| Asset-backed securities | 25.4 |  |  | — |  |  | (0.1) |  |  | 25.3 |  |
| Total available-for-sale investments | $ | 2,278.1 |  |  | $ | 0.2 |  |  | $ | (9.7) |  |  | $ | 2,268.6 |  |

- changed (2022-02-23):
[0001327567-22-000008:note_history:34]
We do not intend to sell any of the securities in an unrealized loss position and it is not likely that we would be required to sell these securities before recovery of their amortized cost basis, which may be at maturity. We did not recognize any credit losses related to our available-for-sale debt securities during the three and six months ended January 31, 2022 and 2021.
  (was, 2021-11-19, similarity 0.9697):
[0001327567-21-000040:note_history:34]
We do not intend to sell any of the securities in an unrealized loss position and it is not likely that we would be required to sell these securities before recovery of their amortized cost basis, which may be at maturity. We did not recognize any credit losses related to our available-for-sale debt securities during the three months ended October 31, 2021 and 2020.

- changed (2022-02-23):
[0001327567-22-000008:note_history:35]
The following table summarizes the amortized cost and fair value of our available-for-sale debt securities as of January 31, 2022, by contractual years-to-maturity (in millions):
  (was, 2021-11-19, similarity 0.9651):
[0001327567-21-000040:note_history:35]
The following table summarizes the amortized cost and fair value of our available-for-sale debt securities as of October 31, 2021, by contractual years-to-maturity (in millions):

- changed (2022-02-23):
[0001327567-22-000008:note_history:36]
|  | Amortized Cost |  | Fair Value |
| Due within one year | $ | 1,429.2 |  |  | $ | 1,426.3 |  |
| Due between one and three years | 839.2 |  |  | 832.7 |  |
| Due between three to five years | 18.4 |  |  | 18.3 |  |
| Total | $ | 2,286.8 |  |  | $ | 2,277.3 |  |
  (was, 2021-11-19, similarity 0.867):
[0001327567-21-000040:note_history:36]
|  | Amortized Cost |  | Fair Value |
| Due within one year | $ | 1,434.5 |  |  | $ | 1,435.1 |  |
| Due between one and three years | 900.1 |  |  | 898.8 |  |
| Total | $ | 2,334.6 |  |  | $ | 2,333.9 |  |

- changed (2022-02-23):
[0001327567-22-000008:note_history:37]
Marketable equity securities consist of money market funds and are included in cash and cash equivalents on our condensed consolidated balance sheets. As of January 31, 2022 and July 31, 2021, the carrying values of our marketable equity securities were 
$475.0 million and $124.2 million, respectively. There were no unrealized gains or losses recognized for these securities during the three and six months ended January 31, 2022 and 2021.
  (was, 2021-11-19, similarity 0.8775):
[0001327567-21-000040:note_history:37]
Marketable equity securities consist of money market funds and are included in cash and cash equivalents on our condensed consolidated balance sheets. As of October 31, 2021 and July 31, 2021, the carrying values of our marketable equity securities were $161.8 million and $124.2 million, respectively. There were no unrealized gains or losses recognized for these securities during the three months ended October 31, 2021 and 2020.

- removed (2022-02-23):
[0001327567-21-000040:note_history:38]
|  | October 31, 2021 |
|  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Fair Value |
| Cash equivalents: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 150.5 |  |  | $ | — |  |  | $ | — |  |  | $ | 150.5 |  |
| Corporate debt securities | 26.1 |  |  | — |  |  | — |  |  | 26.1 |  |
| U.S. government and agency securities | 70.0 |  |  | — |  |  | — |  |  | 70.0 |  |
| Total available-for-sale cash equivalents | $ | 246.6 |  |  | $ | — |  |  | $ | — |  |  | $ | 246.6 |  |
| Investments: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 156.5 |  |  | $ | — |  |  | $ | — |  |  | $ | 156.5 |  |
| Corporate debt securities | 428.2 |  |  | 0.1 |  |  | (0.5) |  |  | 427.8 |  |
| U.S. government and agency securities | 1,442.6 |  |  | 0.6 |  |  | (0.9) |  |  | 1,442.3 |  |
| Non-U.S. government and agency securities | 60.7 |  |  | — |  |  | — |  |  | 60.7 |  |
| Total available-for-sale investments | $ | 2,088.0 |  |  | $ | 0.7 |  |  | $ | (1.4) |  |  | $ | 2,087.3 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- added (2022-02-23):
[0001327567-22-000008:note_history:39]
|  | Three Months Ended January 31, |  | Six Months Ended January 31, |
|  | 2022 |  | 2021 |  | 2022 |  | 2021 |
| Revenue: |  |  |  |  |  |  |  |
| Americas |  |  |  |  |  |  |  |
| United States | $ | 858.6 |  |  | $ | 642.8 |  |  | $ | 1,670.3 |  |  | $ | 1,267.2 |  |
| Other Americas | 57.3 |  |  | 47.0 |  |  | 112.3 |  |  | 89.1 |  |
| Total Americas | 915.9 |  |  | 689.8 |  |  | 1,782.6 |  |  | 1,356.3 |  |
| Europe, the Middle East, and Africa (“EMEA”) | 252.2 |  |  | 206.2 |  |  | 486.0 |  |  | 379.6 |  |
| Asia Pacific and Japan (“APAC”) | 148.8 |  |  | 120.9 |  |  | 295.7 |  |  | 227.0 |  |
| Total revenue | $ | 1,316.9 |  |  | $ | 1,016.9 |  |  | $ | 2,564.3 |  |  | $ | 1,962.9 |  |

- added (2022-02-23):
[0001327567-22-000008:note_history:40]
|  | Three Months Ended January 31, |  | Six Months Ended January 31, |
|  | 2022 |  | 2021 |  | 2022 |  | 2021 |
| Revenue: |  |  |  |  |  |  |  |
| Product | $ | 308.0 |  |  | $ | 254.7 |  |  | $ | 603.5 |  |  | $ | 492.0 |  |
| Subscription and support |  |  |  |  |  |  |  |
| Subscription | 618.0 |  |  | 461.7 |  |  | 1,196.8 |  |  | 889.7 |  |
| Support | 390.9 |  |  | 300.5 |  |  | 764.0 |  |  | 581.2 |  |
| Total subscription and support | 1,008.9 |  |  | 762.2 |  |  | 1,960.8 |  |  | 1,470.9 |  |
| Total revenue | $ | 1,316.9 |  |  | $ | 1,016.9 |  |  | $ | 2,564.3 |  |  | $ | 1,962.9 |  |

- changed (2022-02-23):
[0001327567-22-000008:note_history:41]
During the six months ended January 31, 2022 and 2021, we recognized approximately $1.6 billion and $1.2 billion of revenue pertaining to amounts that were deferred as of July 31, 2021 and 2020, respectively.
  (was, 2021-11-19, similarity 0.9358):
[0001327567-21-000040:note_history:41]
During the three months ended October 31, 2021 and 2020, we recognized approximately $840.0 million and $630.0 million of revenue pertaining to amounts that were deferred as of July 31, 2021 and 2020, respectively.

- changed (2022-02-23):
[0001327567-22-000008:note_history:42]
Revenue expected to be recognized from remaining performance obligations was $6.3 billion as of January 31, 2022, of which we expect to recognize approximately $3.4 billion over the next 12 months and the remainder thereafter.
  (was, 2021-11-19, similarity 0.7395):
[0001327567-21-000040:note_history:42]
Revenue expected to be recognized from remaining performance obligations was $6.0 billion as of October 31, 2021, of which we expect to recognize approximately $3.2 billion over the next 12 months and the remainder thereafter.

- removed (2022-02-23):
[0001327567-21-000040:note_history:43]
|  | Three Months Ended October 31, |  |  |
|  | 2021 |  | 2020 |  |  |  |  |
| Revenue: |  |  |  |  |  |  |  |
| Americas |  |  |  |  |  |  |  |
| United States | $ | 811.7 |  |  | $ | 624.4 |  |  |  |  |  |
| Other Americas | 55.0 |  |  | 42.1 |  |  |  |  |  |
| Total Americas | 866.7 |  |  | 666.5 |  |  |  |  |  |
| Europe, the Middle East, and Africa (“EMEA”) | 233.8 |  |  | 173.4 |  |  |  |  |  |
| Asia Pacific and Japan (“APAC”) | 146.9 |  |  | 106.1 |  |  |  |  |  |
| Total revenue | $ | 1,247.4 |  |  | $ | 946.0 |  |  |  |  |  |

- removed (2022-02-23):
[0001327567-21-000040:note_history:44]
|  | Three Months Ended October 31, |  |  |
|  | 2021 |  | 2020 |  |  |  |  |
| Revenue: |  |  |  |  |  |  |  |
| Product | $ | 295.5 |  |  | $ | 237.3 |  |  |  |  |  |
| Subscription and support |  |  |  |  |  |  |  |
| Subscription | 578.8 |  |  | 428.0 |  |  |  |  |  |
| Support | 373.1 |  |  | 280.7 |  |  |  |  |  |
| Total subscription and support | 951.9 |  |  | 708.7 |  |  |  |  |  |
| Total revenue | $ | 1,247.4 |  |  | $ | 946.0 |  |  |  |  |  |
