# PANW MD&A — 0001327567-22-000008


## mdna

[0001327567-22-000008:mdna:1]
[same as prior period, unchanged from 0001327567-21-000040:mdna:1]

[0001327567-22-000008:mdna:2]
[same as prior period, unchanged from 0001327567-21-000040:mdna:2]

[0001327567-22-000008:mdna:3]
[same as prior period, unchanged from 0001327567-21-000040:mdna:3]

[0001327567-22-000008:mdna:4]
[same as prior period, unchanged from 0001327567-21-000040:mdna:4]

[0001327567-22-000008:mdna:5]
•Results of Operations. A discussion of the nature and trends in our financial results and an analysis of our financial results comparing the three and six months ended January 31, 2022 to the three and six months ended January 31, 2021.

[0001327567-22-000008:mdna:6]
•Liquidity and Capital Resources. An analysis of changes on our balance sheets and cash flows, and a discussion of our financial condition and our ability to meet cash needs.

[0001327567-22-000008:mdna:7]
[same as prior period, unchanged from 0001327567-21-000040:mdna:7]

[0001327567-22-000008:mdna:8]
[same as prior period, unchanged from 0001327567-21-000040:mdna:8]

[0001327567-22-000008:mdna:9]
[same as prior period, unchanged from 0001327567-21-000040:mdna:9]

[0001327567-22-000008:mdna:10]
[same as prior period, unchanged from 0001327567-21-000040:mdna:10]

[0001327567-22-000008:mdna:11]
[same as prior period, unchanged from 0001327567-21-000040:mdna:11]

[0001327567-22-000008:mdna:12]
[same as prior period, unchanged from 0001327567-21-000040:mdna:12]

[0001327567-22-000008:mdna:13]
[same as prior period, unchanged from 0001327567-21-000040:mdna:28]

[0001327567-22-000008:mdna:14]
[same as prior period, unchanged from 0001327567-21-000040:mdna:14]

[0001327567-22-000008:mdna:15]
[same as prior period, unchanged from 0001327567-21-000040:mdna:15]

[0001327567-22-000008:mdna:16]
[same as prior period, unchanged from 0001327567-21-000040:mdna:16]

[0001327567-22-000008:mdna:17]
[same as prior period, unchanged from 0001327567-21-000040:mdna:17]

[0001327567-22-000008:mdna:18]
[same as prior period, unchanged from 0001327567-21-000040:mdna:18]

[0001327567-22-000008:mdna:19]
•Enabling cloud security through our Prisma security offerings. Prisma Cloud, the industry’s most comprehensive Cloud Native Application Protection Platform (“CNAPP”), secures multi- and hybrid-cloud environments and cloud native applications, integrating security across the full deployment lifecycle. VM-Series and CN-Series enforce in-line network security in multi- and hybrid-cloud environments.

[0001327567-22-000008:mdna:20]
[same as prior period, unchanged from 0001327567-21-000040:mdna:20]

[0001327567-22-000008:mdna:21]
[same as prior period, unchanged from 0001327567-21-000040:mdna:21]

[0001327567-22-000008:mdna:22]
[same as prior period, unchanged from 0001327567-21-000040:mdna:22]

[0001327567-22-000008:mdna:23]
[same as prior period, unchanged from 0001327567-21-000040:mdna:23]

[0001327567-22-000008:mdna:24]
For the second quarter of fiscal 2022 and 2021, total revenue was $1.3 billion and $1.0 billion, respectively, representing year-over-year growth of 29.5%. Our growth reflects the increased adoption of our portfolio, which consists of product, subscriptions, and support. We believe our portfolio will enable us to benefit from recurring revenues as we continue to grow our installed end-customer base. As of January 31, 2022, we had end-customers in over 170 countries. Our end-customers represent a broad range of industries, including education, energy, financial services, government entities, healthcare, Internet and media, manufacturing, public sector, and telecommunications, and include almost all of the Fortune 100 companies and a majority of the Global 2000 companies in the world. We maintain a field sales force that works closely with our channel partners in developing sales opportunities. We primarily use a two-tiered, indirect fulfillment model whereby we sell our products, subscriptions, and support to our distributors, which, in turn, sell to our resellers, which then sell to our end-customers.

[0001327567-22-000008:mdna:25]
Our product revenue grew to $308.0 million, or 23.4% of total revenue, for the second quarter of fiscal 2022, representing year-over-year growth of 20.9%. Product revenue is generated from sales of our appliances, primarily our ML-Powered Next-Generation Firewall, which is available in a number of form factors, including as physical, virtual, and containerized appliances. Our ML-Powered Next-Generation Firewall incorporates our PAN-OS operating system, which provides a consistent set of capabilities across our entire network security product line. Our products are designed for different performance requirements throughout an organization, ranging from our PA-410, which is designed for small organizations and remote or branch offices, to our top-of-the-line PA-7080, which is designed for large-scale data centers and service provider use. The same firewall functionality that is delivered in our physical appliances is also available in our VM-Series virtual firewalls, which secure virtualized and cloud-based computing environments, and in our CN-Series container firewalls, which secure container environments and traffic.

[0001327567-22-000008:mdna:26]
Our subscription and support revenue grew to $1.0 billion, or 76.6% of total revenue, for the second quarter of fiscal 2022, representing year-over-year growth of 32.4%. Our subscriptions provide our end-customers with near real-time access to the latest antivirus, intrusion prevention, web filtering, modern malware prevention, data loss prevention, and cloud access security broker capabilities across the network, endpoints, and the cloud. When end-customers purchase our physical, virtual, or container firewall appliances, or certain cloud offerings they typically purchase support in order to receive ongoing security updates, upgrades, bug fixes, and repairs. In addition to the subscriptions purchased with these appliances, end-customers may also purchase other subscriptions on a per-user, per-endpoint, or capacity-based basis. We also offer professional services, including incident response, risk management, and digital forensic services.

[0001327567-22-000008:mdna:27]
[same as prior period, unchanged from 0001327567-21-000040:mdna:27]

[0001327567-22-000008:mdna:28]
[same as prior period, unchanged from 0001327567-21-000040:mdna:35]

[0001327567-22-000008:mdna:29]
[same as prior period, unchanged from 0001327567-21-000040:mdna:29]

[0001327567-22-000008:mdna:30]
customers and improving our competitive position. For example, in November 2021, we launched Prisma Cloud 3.0, a single unified platform that secures infrastructure, applications, data and entitlements across cloud environments and Prisma Access 3.0 that delivers next generation cloud access security broker (“CASB”) protecting against threats that originate from SaaS applications.

[0001327567-22-000008:mdna:31]
[same as prior period, unchanged from 0001327567-21-000040:mdna:31]

[0001327567-22-000008:mdna:32]
[same as prior period, unchanged from 0001327567-21-000040:mdna:32]

[0001327567-22-000008:mdna:33]
We are actively monitoring, evaluating, and responding to developments relating to COVID-19, which has resulted in, and is expected to continue to result in significant global, social, and business disruption. While we instituted a global work-from-home policy beginning in March 2020, which has been modified to provide employees with the choice to work in certain of our offices when and as they feel comfortable, we have not experienced significant disruptions in our work operations. We are conducting business as usual with modifications to employee travel and continue to hold most of the marketing events virtually. We expect these changes will substantially remain in effect in the third quarter of fiscal 2022 and could extend to future quarters. We will continue to actively monitor the situation, including progress made through vaccinations, and we will make further changes to our business operations as may be required by federal, state, or local authorities or that we determine are in the best interests of our employees, end-customers, partners, suppliers, and stockholders. Our focus remains on the safety of our employees, and we strive to protect the health and well-being of the communities in which we operate, in part, by providing technology to our employees, end-customers, and partners to help them do their best work while working remotely.

[0001327567-22-000008:mdna:34]
Although some end-customers adopted Prisma Access as their secure work-from-home solution for the longer term, COVID-19 has affected our end-customers’ spending and could lead them to delay or defer purchasing decisions, and lengthen sales cycles and payment terms, which could materially adversely impact our business, results of operations, and overall financial performance. Also, certain of our end-customers or partners have been and others may become credit or cash constrained, making it difficult for them to fulfill their payment obligations to us. The extent of the impact of COVID-19 on our operational and financial performance will depend on developments, including the duration and spread of the virus and its variants, impact on our end-customers’ spending, volume of sales and length of our sales cycles, impact on our partners, suppliers, and employees, actions that may be taken by governmental authorities, and other factors identified in Part II, Item 1A “Risk Factors” in this Quarterly Report on Form 10-Q. The global supply chain and the semiconductor industry are experiencing significant challenges. We have seen supply chain challenges increase, including chip and component shortages, which have, in certain cases, caused delays for us in acquiring chips, components and inventory and have resulted in increased costs as compared to historic levels. While we incurred increased costs and experienced increased lead time for certain product deliveries to our end-customers, we continue to work to minimize the effects from supply chain challenges. Given the dynamic nature of these circumstances, the full impact of COVID-19 and other macroeconomic factors on our ongoing business, results of operations and overall financial performance cannot be reasonably estimated at this time.

[0001327567-22-000008:mdna:35]
[same as prior period, unchanged from 0001327567-21-000040:mdna:45]

[0001327567-22-000008:mdna:36]
[same as prior period, unchanged from 0001327567-21-000040:mdna:36]

[0001327567-22-000008:mdna:37]
[same as prior period, unchanged from 0001327567-21-000040:mdna:37]

[0001327567-22-000008:mdna:38]
[same as prior period, unchanged from 0001327567-21-000040:mdna:38]

[0001327567-22-000008:mdna:39]
|  | January 31, 2022 |  | July 31, 2021 |
|  | (in millions) |
| Total deferred revenue | $ | 5,449.2 |  |  | $ | 5,024.0 |  |
| Cash, cash equivalents, and investments | $ | 4,191.3 |  |  | $ | 3,789.4 |  |

[0001327567-22-000008:mdna:40]
|  | Three Months Ended January 31, |  | Six Months Ended January 31, |
|  | 2022 |  | 2021 |  | 2022 |  | 2021 |
|  | (dollars in millions) |
| Total revenue | $ | 1,316.9 |  |  | $ | 1,016.9 |  |  | $ | 2,564.3 |  |  | $ | 1,962.9 |  |
| Total revenue year-over-year percentage increase | 29.5 | % |  | 24.5 | % |  | 30.6 | % |  | 23.6 | % |
| Gross margin | 69.2 | % |  | 69.8 | % |  | 69.4 | % |  | 70.2 | % |
| Operating loss | $ | (73.9) |  |  | $ | (88.8) |  |  | $ | (156.6) |  |  | $ | (133.3) |  |
| Operating margin | (5.6) | % |  | (8.7) | % |  | (6.1) | % |  | (6.8) | % |
| Billings | $ | 1,607.9 |  |  | $ | 1,214.7 |  |  | $ | 2,989.5 |  |  | $ | 2,297.5 |  |
| Billings year-over-year percentage increase | 32.4 | % |  | 21.6 | % |  | 30.1 | % |  | 21.2 | % |
| Cash flow provided by operating activities |  |  |  |  | $ | 1,071.5 |  |  | $ | 899.4 |  |
| Free cash flow (non-GAAP) |  |  |  |  | $ | 956.2 |  |  | $ | 837.7 |  |

[0001327567-22-000008:mdna:41]
[same as prior period, unchanged from 0001327567-21-000040:mdna:41]

[0001327567-22-000008:mdna:42]
[same as prior period, unchanged from 0001327567-21-000040:mdna:42]

[0001327567-22-000008:mdna:43]
|  | Three Months Ended January 31, |  | Six Months Ended January 31, |
|  | 2022 |  | 2021 |  | 2022 |  | 2021 |
|  | (in millions) |  | (in millions) |
| Billings: |  |  |  |  |  |  |  |
| Total revenue | $ | 1,316.9 |  |  | $ | 1,016.9 |  |  | $ | 2,564.3 |  |  | $ | 1,962.9 |  |
| Add: change in total deferred revenue, net of acquired deferred revenue | 291.0 |  |  | 197.8 |  |  | 425.2 |  |  | 334.6 |  |
| Billings | $ | 1,607.9 |  |  | $ | 1,214.7 |  |  | $ | 2,989.5 |  |  | $ | 2,297.5 |  |

[0001327567-22-000008:mdna:44]
[same as prior period, unchanged from 0001327567-21-000040:mdna:44]

[0001327567-22-000008:mdna:45]
[same as prior period, unchanged from 0001327567-21-000040:mdna:49]

[0001327567-22-000008:mdna:46]
[same as prior period, unchanged from 0001327567-21-000040:mdna:46]

[0001327567-22-000008:mdna:47]
[same as prior period, unchanged from 0001327567-21-000040:mdna:47]

[0001327567-22-000008:mdna:48]
|  | Six Months Ended January 31, |
|  | 2022 |  | 2021 |
|  | (in millions) |
| Free cash flow (non-GAAP): |  |  |  |
| Net cash provided by operating activities | $ | 1,071.5 |  |  | $ | 899.4 |  |
| Less: purchases of property, equipment, and other assets | 115.3 |  |  | 61.7 |  |
| Free cash flow (non-GAAP) | $ | 956.2 |  |  | $ | 837.7 |  |
| Net cash used in investing activities | $ | (504.2) |  |  | $ | (1,270.6) |  |
| Net cash used in financing activities | $ | (519.8) |  |  | $ | (469.9) |  |

[0001327567-22-000008:mdna:49]
[same as prior period, unchanged from 0001327567-21-000040:mdna:59]

[0001327567-22-000008:mdna:50]
[same as prior period, unchanged from 0001327567-21-000040:mdna:50]

[0001327567-22-000008:mdna:51]
[same as prior period, unchanged from 0001327567-21-000040:mdna:51]

[0001327567-22-000008:mdna:52]
[same as prior period, unchanged from 0001327567-21-000040:mdna:52]

[0001327567-22-000008:mdna:53]
|  | Three Months Ended January 31, |  | Six Months Ended January 31, |
|  | 2022 |  | 2021 |  | 2022 |  | 2021 |
|  | Amount |  | % of Revenue |  | Amount |  | % of Revenue |  | Amount |  | % of Revenue |  | Amount |  | % of Revenue |
|  | (dollars in millions) |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product | $ | 308.0 |  |  | 23.4 | % |  | $ | 254.7 |  |  | 25.0 | % |  | $ | 603.5 |  | 23.5 | % |  | $ | 492.0 |  |  | 25.1 | % |
| Subscription and support | 1,008.9 |  |  | 76.6 | % |  | 762.2 |  |  | 75.0 | % |  | 1,960.8 |  | 76.5 | % |  | 1,470.9 |  |  | 74.9 | % |
| Total revenue | 1,316.9 |  |  | 100.0 | % |  | 1,016.9 |  |  | 100.0 | % |  | 2,564.3 |  | 100.0 | % |  | 1,962.9 |  |  | 100.0 | % |
| Cost of revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product | 97.8 |  |  | 7.4 | % |  | 75.6 |  |  | 7.4 | % |  | 186.7 |  | 7.3 | % |  | 137.8 |  |  | 7.0 | % |
| Subscription and support | 307.5 |  |  | 23.4 | % |  | 232.0 |  |  | 22.8 | % |  | 599.2 |  | 23.3 | % |  | 447.6 |  |  | 22.8 | % |
| Total cost of revenue(1) | 405.3 |  |  | 30.8 | % |  | 307.6 |  |  | 30.2 | % |  | 785.9 |  | 30.6 | % |  | 585.4 |  |  | 29.8 | % |
| Total gross profit | 911.6 |  |  | 69.2 | % |  | 709.3 |  |  | 69.8 | % |  | 1,778.4 |  | 69.4 | % |  | 1,377.5 |  |  | 70.2 | % |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Research and development | 359.0 |  |  | 27.3 | % |  | 266.7 |  |  | 26.2 | % |  | 698.5 |  | 27.2 | % |  | 504.1 |  |  | 25.7 | % |
| Sales and marketing | 528.8 |  |  | 40.1 | % |  | 427.4 |  |  | 42.1 | % |  | 1,034.7 |  | 40.4 | % |  | 816.0 |  |  | 41.6 | % |
| General and administrative | 97.7 |  |  | 7.4 | % |  | 104.0 |  |  | 10.2 | % |  | 201.8 |  | 7.9 | % |  | 190.7 |  |  | 9.7 | % |
| Total operating expenses(1) | 985.5 |  |  | 74.8 | % |  | 798.1 |  |  | 78.5 | % |  | 1,935.0 |  | 75.5 | % |  | 1,510.8 |  |  | 77.0 | % |
| Operating loss | (73.9) |  |  | (5.6) | % |  | (88.8) |  |  | (8.7) | % |  | (156.6) |  |  | (6.1) | % |  | (133.3) |  |  | (6.8) | % |
| Interest expense | (6.8) |  |  | (0.5) | % |  | (40.7) |  |  | (4.0) | % |  | (13.7) |  |  | (0.5) | % |  | (80.9) |  |  | (4.1) | % |
| Other income (expense), net | (0.1) |  |  | — | % |  | (0.5) |  |  | (0.1) | % |  | (1.7) |  |  | (0.1) | % |  | 1.9 |  |  | 0.1 | % |
| Loss before income taxes | (80.8) |  |  | (6.1) | % |  | (130.0) |  |  | (12.8) | % |  | (172.0) |  |  | (6.7) | % |  | (212.3) |  |  | (10.8) | % |
| Provision for income taxes | 12.7 |  |  | 1.0 | % |  | 12.3 |  |  | 1.2 | % |  | 25.1 |  |  | 1.0 | % |  | 22.2 |  |  | 1.1 | % |
| Net loss | $ | (93.5) |  |  | (7.1) | % |  | $ | (142.3) |  |  | (14.0) | % |  | $ | (197.1) |  |  | (7.7) | % |  | $ | (234.5) |  |  | (11.9) | % |

[0001327567-22-000008:mdna:54]
[same as prior period, unchanged from 0001327567-21-000040:mdna:54]

[0001327567-22-000008:mdna:55]
[same as prior period, unchanged from 0001327567-21-000040:mdna:55]

[0001327567-22-000008:mdna:56]
|  | Three Months Ended January 31, |  | Six Months Ended January 31, |
|  | 2022 |  | 2021 |  | 2022 |  | 2021 |
|  | (in millions) |
| Cost of product revenue | $ | 2.3 |  |  | $ | 1.6 |  |  | $ | 4.6 |  |  | $ | 3.1 |  |
| Cost of subscription and support revenue | 27.7 |  |  | 23.8 |  |  | 54.4 |  |  | 46.0 |  |
| Research and development | 123.6 |  |  | 103.6 |  |  | 249.2 |  |  | 199.0 |  |
| Sales and marketing | 79.8 |  |  | 69.7 |  |  | 153.1 |  |  | 134.6 |  |
| General and administrative | 31.7 |  |  | 42.4 |  |  | 64.1 |  |  | 71.3 |  |
| Total share-based compensation | $ | 265.1 |  |  | $ | 241.1 |  |  | $ | 525.4 |  |  | $ | 454.0 |  |

[0001327567-22-000008:mdna:57]
[same as prior period, unchanged from 0001327567-21-000040:mdna:57]

[0001327567-22-000008:mdna:58]
Our revenue consists of product revenue and subscription and support revenue. Revenue is recognized upon transfer of control of the corresponding promised products and subscriptions and support to our customers in an amount that reflects the consideration we expect to be entitled to in exchange for those products and subscriptions and support. We expect our revenue to vary from quarter to quarter based on seasonal and cyclical factors.

[0001327567-22-000008:mdna:59]
[same as prior period, unchanged from 0001327567-21-000040:mdna:74]

[0001327567-22-000008:mdna:60]
[same as prior period, unchanged from 0001327567-21-000040:mdna:60]

[0001327567-22-000008:mdna:61]
[same as prior period, unchanged from 0001327567-21-000040:mdna:61]

[0001327567-22-000008:mdna:62]
[same as prior period, unchanged from 0001327567-21-000040:mdna:62]

[0001327567-22-000008:mdna:63]
|  | Three Months Ended January 31, |  |  |  |  |  | Six Months Ended January 31, |  |  |  |  |
|  | 2022 |  | 2021 |  | Change |  | 2022 |  | 2021 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| Product | $ | 308.0 |  |  | $ | 254.7 |  |  | $ | 53.3 |  |  | 20.9 | % |  | $ | 603.5 |  |  | $ | 492.0 |  |  | $ | 111.5 |  |  | 22.7 | % |

[0001327567-22-000008:mdna:64]
Product revenue for the three and six months ended January 31, 2022 increased compared to the same periods in 2021 primarily due to increased demand for our new and existing product offerings in both periods.

[0001327567-22-000008:mdna:65]
[same as prior period, unchanged from 0001327567-21-000040:mdna:65]

[0001327567-22-000008:mdna:66]
[same as prior period, unchanged from 0001327567-21-000040:mdna:66]

[0001327567-22-000008:mdna:67]
|  | Three Months Ended January 31, |  |  |  |  |  | Six Months Ended January 31, |  |  |  |  |
|  | 2022 |  | 2021 |  | Change |  | 2022 |  | 2021 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| Subscription | $ | 618.0 |  |  | $ | 461.7 |  |  | $ | 156.3 |  |  | 33.9 | % |  | $ | 1,196.8 |  |  | $ | 889.7 |  |  | $ | 307.1 |  |  | 34.5 | % |
| Support | 390.9 |  |  | 300.5 |  |  | 90.4 |  |  | 30.1 | % |  | 764.0 |  |  | 581.2 |  |  | 182.8 |  |  | 31.5 | % |
| Total subscription and support | $ | 1,008.9 |  |  | $ | 762.2 |  |  | $ | 246.7 |  |  | 32.4 | % |  | $ | 1,960.8 |  |  | $ | 1,470.9 |  |  | $ | 489.9 |  |  | 33.3 | % |

[0001327567-22-000008:mdna:68]
Subscription and support revenue increased for the three and six months ended January 31, 2022 compared to the same periods in 2021. The increase in both periods was due to increased demand for our subscription and support offerings from our end-customers. The mix between subscription revenue and support revenue will fluctuate over time, depending on the introduction of new subscription offerings, renewals of support services, and our ability to increase sales to new and existing end-customers.

[0001327567-22-000008:mdna:69]
[same as prior period, unchanged from 0001327567-21-000040:mdna:69]

[0001327567-22-000008:mdna:70]
|  | Three Months Ended January 31, |  |  |  |  |  | Six Months Ended January 31, |  |  |  |  |
|  | 2022 |  | 2021 |  | Change |  | 2022 |  | 2021 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| Americas | $ | 915.9 |  |  | $ | 689.8 |  |  | $ | 226.1 |  |  | 32.8 | % |  | $ | 1,782.6 |  |  | $ | 1,356.3 |  |  | $ | 426.3 |  |  | 31.4 | % |
| EMEA | 252.2 |  |  | 206.2 |  |  | 46.0 |  |  | 22.3 | % |  | 486.0 |  |  | 379.6 |  |  | 106.4 |  |  | 28.0 | % |
| APAC | 148.8 |  |  | 120.9 |  |  | 27.9 |  |  | 23.1 | % |  | 295.7 |  |  | 227.0 |  |  | 68.7 |  |  | 30.3 | % |
| Total revenue | $ | 1,316.9 |  |  | $ | 1,016.9 |  |  | $ | 300.0 |  |  | 29.5 | % |  | $ | 2,564.3 |  |  | $ | 1,962.9 |  |  | $ | 601.4 |  |  | 30.6 | % |

[0001327567-22-000008:mdna:71]
With respect to geographic theaters, the increase in revenue for the three and six months ended January 31, 2022 compared to the same periods in 2021 was driven primarily by the Americas, due to its larger sales force and a larger percentage of our customers located in the Americas. Revenue from our other geographic theaters, both Europe, the Middle East, and Africa (“EMEA”) and Asia Pacific and Japan (“APAC”), increased for the three and six months ended January 31, 2022 compared to the same periods in 2021 due to continued investment in our global sales force to support our growth and increase our customer base in the regions.

[0001327567-22-000008:mdna:72]
[same as prior period, unchanged from 0001327567-21-000040:mdna:72]

[0001327567-22-000008:mdna:73]
[same as prior period, unchanged from 0001327567-21-000040:mdna:73]

[0001327567-22-000008:mdna:74]
[same as prior period, unchanged from 0001327567-21-000040:mdna:87]

[0001327567-22-000008:mdna:75]
[same as prior period, unchanged from 0001327567-21-000040:mdna:75]

[0001327567-22-000008:mdna:76]
[same as prior period, unchanged from 0001327567-21-000040:mdna:76]

[0001327567-22-000008:mdna:77]
[same as prior period, unchanged from 0001327567-21-000040:mdna:77]

[0001327567-22-000008:mdna:78]
|  | Three Months Ended January 31, |  |  |  |  |  | Six Months Ended January 31, |  |  |  |  |
|  | 2022 |  | 2021 |  | Change |  | 2022 |  | 2021 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| Cost of product revenue | $ | 97.8 |  |  | $ | 75.6 |  |  | $ | 22.2 |  |  | 29.4 | % |  | $ | 186.7 |  |  | $ | 137.8 |  |  | $ | 48.9 |  |  | 35.5 | % |
| Number of employees at period end | 134 |  |  | 118 |  |  | 16 |  |  | 13.6 | % |  | 134 |  |  | 118 |  |  | 16 |  |  | 13.6 | % |

[0001327567-22-000008:mdna:79]
Cost of product revenue increased for the three and six months ended January 31, 2022 compared to the same periods in 2021, primarily due to an increase in product volume in both periods. The remaining increase was due to higher costs related to our product offerings in both periods, primarily driven by supply chain challenges.

[0001327567-22-000008:mdna:80]
[same as prior period, unchanged from 0001327567-21-000040:mdna:80]

[0001327567-22-000008:mdna:81]
[same as prior period, unchanged from 0001327567-21-000040:mdna:81]

[0001327567-22-000008:mdna:82]
|  | Three Months Ended January 31, |  |  |  |  |  | Six Months Ended January 31, |  |  |  |  |
|  | 2022 |  | 2021 |  | Change |  | 2022 |  | 2021 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| Cost of subscription and support revenue | $ | 307.5 |  |  | $ | 232.0 |  |  | $ | 75.5 |  |  | 32.5 | % |  | $ | 599.2 |  |  | $ | 447.6 |  |  | $ | 151.6 |  |  | 33.9 | % |
| Number of employees at period end | 2,380 |  |  | 1,697 |  |  | 683 |  |  | 40.2 | % |  | 2,380 |  |  | 1,697 |  |  | 683 |  |  | 40.2 | % |

[0001327567-22-000008:mdna:83]
Cost of subscription and support revenue increased for the three and six months ended January 31, 2022 compared to the same periods in 2021, primarily due to personnel costs, which grew $38.4 million to $138.6 million for the three months ended January 31, 2022 compared to the same period in 2021, and grew $73.6 million to $261.4 million for the six months ended January 31, 2022 compared to the same period in 2021 primarily due to headcount growth. The remaining increase for both periods was primarily due to increased outside service costs for global customer support resulting from the expansions of our customer base and product portfolio, and cloud hosting service costs to support our cloud-based subscription offerings.

[0001327567-22-000008:mdna:84]
[same as prior period, unchanged from 0001327567-21-000040:mdna:84]

[0001327567-22-000008:mdna:85]
Gross margin, or gross profit as a percentage of revenue, has been and will continue to be affected by a variety of factors, including the introduction of new products, manufacturing costs, the average sales price of our products, cloud hosting service costs, personnel costs, the mix of products sold, and the mix of revenue between product and subscription and support offerings. For sales of our products, our virtual and higher-end firewall products generally have higher gross margins than our lower-end firewall products within each product series. We expect our gross margins to vary over time depending on the factors described above.

[0001327567-22-000008:mdna:86]
|  | Three Months Ended January 31, |  | Six Months Ended January 31, |
|  | 2022 |  | 2021 |  | 2022 |  | 2021 |
|  | Amount |  | Gross Margin |  | Amount |  | Gross Margin |  | Amount |  | Gross Margin |  | Amount |  | Gross Margin |
|  | (dollars in millions) |
| Product | $ | 210.2 |  |  | 68.2 | % |  | $ | 179.1 |  |  | 70.3 | % |  | $ | 416.8 |  |  | 69.1 | % |  | $ | 354.2 |  |  | 72.0 | % |
| Subscription and support | 701.4 |  |  | 69.5 | % |  | 530.2 |  |  | 69.6 | % |  | 1,361.6 |  |  | 69.4 | % |  | 1,023.3 |  |  | 69.6 | % |
| Total gross profit | $ | 911.6 |  |  | 69.2 | % |  | $ | 709.3 |  |  | 69.8 | % |  | $ | 1,778.4 |  |  | 69.4 | % |  | $ | 1,377.5 |  |  | 70.2 | % |

[0001327567-22-000008:mdna:87]
[same as prior period, unchanged from 0001327567-21-000040:mdna:101]

[0001327567-22-000008:mdna:88]
[same as prior period, unchanged from 0001327567-21-000040:mdna:88]

[0001327567-22-000008:mdna:89]
Product gross margin decreased for the three and six months ended January 31, 2022 compared to the same periods in 2021, primarily due to product mix and higher costs related to our product offerings in both periods, primarily driven by supply chain challenges.

[0001327567-22-000008:mdna:90]
Subscription and support gross margin was relatively flat for the three and six months ended January 31, 2022 compared to the same periods in 2021.

[0001327567-22-000008:mdna:91]
[same as prior period, unchanged from 0001327567-21-000040:mdna:91]

[0001327567-22-000008:mdna:92]
Our operating expenses consist of research and development, sales and marketing, and general and administrative expenses. Personnel costs are the most significant component of operating expenses and consist of salaries, benefits, bonuses, share-based compensation, travel and entertainment, and with regard to sales and marketing expense, sales commissions. Our operating expenses also include shared costs, which consist of certain facilities, depreciation, benefits, recruiting, and information technology costs that we allocate based on headcount to each department. In response to COVID-19, we made modifications to employee travel beginning in March 2020, and we continue to hold most of the marketing events virtually. We expect operating expenses generally to increase in absolute dollars and decrease over the long term as a percentage of revenue as we continue to scale our business.

[0001327567-22-000008:mdna:93]
[same as prior period, unchanged from 0001327567-21-000040:mdna:93]

[0001327567-22-000008:mdna:94]
[same as prior period, unchanged from 0001327567-21-000040:mdna:94]

[0001327567-22-000008:mdna:95]
|  | Three Months Ended January 31, |  |  |  |  |  | Six Months Ended January 31, |  |  |  |  |
|  | 2022 |  | 2021 |  | Change |  | 2022 |  | 2021 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| Research and development | $ | 359.0 |  |  | $ | 266.7 |  |  | $ | 92.3 |  |  | 34.6 | % |  | $ | 698.5 |  |  | $ | 504.1 |  |  | $ | 194.4 |  |  | 38.6 | % |
| Number of employees at period end | 2,880 |  |  | 2,195 |  |  | 685 |  |  | 31.2 | % |  | 2,880 |  |  | 2,195 |  |  | 685 |  |  | 31.2 | % |

[0001327567-22-000008:mdna:96]
Research and development expense increased for the three and six months ended January 31, 2022 compared to the same periods in 2021 primarily due to personnel costs, which grew $70.2 million to $286.2 million for the three months ended January 31, 2022 compared to the same period in 2021, and grew $149.1 million to $553.1 million for the six months ended January 31, 2022 compared to the same period in 2021. The increase in personnel costs in both periods was primarily due to headcount growth.

[0001327567-22-000008:mdna:97]
[same as prior period, unchanged from 0001327567-21-000040:mdna:97]

[0001327567-22-000008:mdna:98]
Sales and marketing expense consists primarily of personnel costs, including commission expense. Sales and marketing expense also includes costs for market development programs, promotional and other marketing costs, professional services, and allocated shared costs. We continue to strategically invest in headcount and have grown our sales presence. We expect sales and marketing expense to continue to increase in absolute dollars as we increase the size of our sales and marketing organizations to grow customer base, increase touch points with end-customers and expand our global presence, although our sales and marketing expense may fluctuate as a percentage of total revenue.

[0001327567-22-000008:mdna:99]
|  | Three Months Ended January 31, |  |  |  |  |  | Six Months Ended January 31, |  |  |  |  |
|  | 2022 |  | 2021 |  | Change |  | 2022 |  | 2021 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| Sales and marketing | $ | 528.8 |  |  | $ | 427.4 |  |  | $ | 101.4 |  |  | 23.7 | % |  | $ | 1,034.7 |  |  | $ | 816.0 |  |  | $ | 218.7 |  |  | 26.8 | % |
| Number of employees at period end | 4,826 |  |  | 4,065 |  | 761 |  |  | 18.7 | % |  | 4,826 |  |  | 4,065 |  |  | 761 |  |  | 18.7 | % |

[0001327567-22-000008:mdna:100]
Sales and marketing expense increased for the three and six months ended January 31, 2022 compared to the same periods in 2021, primarily due to personnel costs, which grew $79.8 million to $403.2 million for the three months ended January 31, 2022 compared to the same period in 2021, and grew $167.5 million to $784.2 million for the six months ended January 31, 2022 compared to the same period in 2021. The increase in personnel costs in both periods was largely due to headcount growth. The increase in the six months ended January 31, 2022 was also driven by an increase in costs associated with go-to-market initiatives, including advertising.

[0001327567-22-000008:mdna:101]
[same as prior period, unchanged from 0001327567-21-000040:mdna:103]

[0001327567-22-000008:mdna:102]
General and administrative expense consists primarily of personnel costs and allocated shared costs for our executive, finance, human resources, and legal organizations, and professional services costs, which consist primarily of legal, auditing, accounting, and

[0001327567-22-000008:mdna:103]
[same as prior period, unchanged from 0001327567-21-000040:mdna:115]

[0001327567-22-000008:mdna:104]
[same as prior period, unchanged from 0001327567-21-000040:mdna:102]

[0001327567-22-000008:mdna:105]
other consulting costs. General and administrative expense also includes certain non-recurring general expenses. We expect general and administrative expense to increase in absolute dollars due to additional costs associated with accounting, compliance, and insurance, although our general and administrative expense may fluctuate as a percentage of total revenue.

[0001327567-22-000008:mdna:106]
|  | Three Months Ended January 31, |  |  |  |  |  | Six Months Ended January 31, |  |  |  |  |
|  | 2022 |  | 2021 |  | Change |  | 2022 |  | 2021 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| General and administrative | $ | 97.7 |  |  | $ | 104.0 |  |  | $ | (6.3) |  |  | (6.1) | % |  | $ | 201.8 |  |  | $ | 190.7 |  |  | $ | 11.1 |  |  | 5.8 | % |
| Number of employees at period end | 1,307 |  |  | 963 |  |  | 344 |  |  | 35.7 | % |  | 1,307 |  |  | 963 |  |  | 344 |  |  | 35.7 | % |

[0001327567-22-000008:mdna:107]
General and administrative expense decreased for the three months ended January 31, 2022 compared to the same period in 2021. The decrease was primarily due to share-based compensation related to accelerated vesting of equity awards and transaction costs incurred in connection with acquisitions during the three months ended January 31, 2021, which did not recur in the three months ended January 31, 2022. The decrease was partially offset by an increase in personnel costs due to headcount growth in the three months ended January 31, 2022. Total personnel costs, including share-based compensation related to accelerated vesting of equity awards in connection with acquisitions, decreased by $2.9 million to $69.3 million for the three months ended January 31, 2022 compared to the same period in 2021. General and administrative expense increased for the six months ended January 31, 2022 compared to the same period in 2021 primarily due to personnel costs, which increased $11.0 million to $136.7 million for the six months ended January 31, 2022. The increase in personnel costs in the six months ended January 31, 2022 was primarily due to headcount growth, partially offset by lower share-based compensation related to accelerated vesting of equity awards in connection with acquisitions compared to the same period in 2021.

[0001327567-22-000008:mdna:108]
[same as prior period, unchanged from 0001327567-21-000040:mdna:107]

[0001327567-22-000008:mdna:109]
Interest expense primarily consists of interest expense related to our 0.75% Convertible Senior Notes due 2023 (the “2023 Notes”) and the 0.375% Convertible Senior Notes due 2025 (the “2025 Notes,” and together with “2023 Notes,” the “Notes”).

[0001327567-22-000008:mdna:110]
|  | Three Months Ended January 31, |  |  |  | Six Months Ended January 31, |  |  |
|  | 2022 |  | 2021 |  | Change |  | 2022 |  | 2021 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| Interest expense | $ | 6.8 |  |  | $ | 40.7 |  |  | $ | (33.9) |  |  | (83.3) | % |  | $ | 13.7 |  |  | $ | 80.9 |  |  | $ | (67.2) |  |  | (83.1) | % |

[0001327567-22-000008:mdna:111]
Interest expense decreased for the three and six months ended January 31, 2022 compared to the same periods in 2021 primarily because we no longer recognize interest expense for amortization of the debt discount as a result of the adoption of new debt guidance. Refer to Note 1. Description of Business and Summary of Significant Accounting Policies and Note 9. Debt in Part I, Item 1 of this Quarterly Report on Form 10-Q for more information.

[0001327567-22-000008:mdna:112]
[same as prior period, unchanged from 0001327567-21-000040:mdna:111]

[0001327567-22-000008:mdna:113]
Other income (expense), net includes interest income earned on our cash, cash equivalents, and investments, and gains and losses from foreign currency remeasurement and foreign currency transactions.

[0001327567-22-000008:mdna:114]
|  | Three Months Ended January 31, |  |  |  | Six Months Ended January 31, |  |  |
|  | 2022 |  | 2021 |  | Change |  | 2022 |  | 2021 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| Other income (expense), net | $ | (0.1) |  |  | $ | (0.5) |  |  | $ | 0.4 |  |  | (80.0) | % |  | $ | (1.7) |  |  | $ | 1.9 |  |  | $ | (3.6) |  |  | (189.5) | % |

[0001327567-22-000008:mdna:115]
The change in other income (expense), net for the three months ended January 31, 2022 compared to the same period in 2021 was primarily due to a decrease in foreign currency transaction losses. The change in other income (expense), net for the six months ended January 31, 2022 compared to the same period in 2021 was primarily due to an increase in foreign currency remeasurement losses.

[0001327567-22-000008:mdna:116]
[same as prior period, unchanged from 0001327567-21-000040:mdna:129]

[0001327567-22-000008:mdna:117]
[same as prior period, unchanged from 0001327567-21-000040:mdna:116]

[0001327567-22-000008:mdna:118]
[same as prior period, unchanged from 0001327567-21-000040:mdna:117]

[0001327567-22-000008:mdna:119]
Provision for income taxes consists primarily of income taxes in foreign jurisdictions in which we conduct business and withholding taxes. We maintain a full valuation allowance for domestic and certain foreign deferred tax assets, including net operating loss carryforwards and certain domestic tax credits. Our valuation allowance has caused, and may continue to cause, disproportionate relationships between our overall effective tax rate and other jurisdictional measures.

[0001327567-22-000008:mdna:120]
|  | Three Months Ended January 31, |  | Change |  | Six Months Ended January 31, |  | Change |
|  | 2022 |  | 2021 |  | Amount |  | % |  | 2022 |  | 2021 |  | Amount |  | % |
|  | (dollars in millions) |
| Provision for income taxes | $ | 12.7 |  |  | $ | 12.3 |  |  | $ | 0.4 |  |  | 3.3 | % |  | $ | 25.1 |  |  | $ | 22.2 |  |  | $ | 2.9 |  |  | 13.1 | % |
| Effective tax rate | (15.7) | % |  | (9.5) | % |  |  |  |  |  | (14.6) | % |  | (10.5) | % |  |  |  |  |

[0001327567-22-000008:mdna:121]
Our income taxes for the three and six months ended January 31, 2022 and 2021 were primarily due to foreign income taxes in profitable jurisdictions and withholding taxes. Our effective tax rate varied for the three and six months ended January 31, 2022 compared to the same periods in 2021 primarily due to our valuation allowance. Refer to Note 13. Income Taxes in Part I, Item 1 of this Quarterly Report on Form 10-Q for more information.

[0001327567-22-000008:mdna:122]
[same as prior period, unchanged from 0001327567-21-000040:mdna:121]

[0001327567-22-000008:mdna:123]
|  | January 31, 2022 |  | July 31, 2021 |
|  | (in millions) |
| Working capital(1) | $ | (2,537.8) |  |  | $ | (469.4) |  |
| Cash, cash equivalents, and investments: |  |  |  |
| Cash and cash equivalents | $ | 1,922.7 |  |  | $ | 1,874.2 |  |
| Investments | 2,268.6 |  |  | 1,915.2 |  |
| Total cash, cash equivalents, and investments | $ | 4,191.3 |  |  | $ | 3,789.4 |  |

[0001327567-22-000008:mdna:124]
[same as prior period, unchanged from 0001327567-21-000040:mdna:123]

[0001327567-22-000008:mdna:125]
(1)Current liabilities included net carrying amounts of convertible senior notes of $3.7 billion and $1.6 billion as of January 31, 2022 and July 31, 2021, respectively. Refer to Note 9. Debt in Part I, Item 1 of this Quarterly Report on Form 10-Q for information on the Notes.

[0001327567-22-000008:mdna:126]
As of January 31, 2022, our total cash, cash equivalents, and investments of $4.2 billion were held for general corporate purposes, of which approximately $854.2 million was held outside of the United States. As of January 31, 2022, we had no unremitted earnings when evaluating our outside basis difference relating to our U.S. investment in foreign subsidiaries. However, there could be local withholding taxes payable due to various foreign countries if certain lower tier earnings are distributed. Withholding taxes that would be payable upon remittance of these lower tier earnings are not expected to be material.

[0001327567-22-000008:mdna:127]
[same as prior period, unchanged from 0001327567-21-000040:mdna:126]

[0001327567-22-000008:mdna:128]
In July 2018, we issued the 2023 Notes with an aggregate principal amount of $1.7 billion. In June 2020, we issued the 2025 Notes with an aggregate principal amount of $2.0 billion. The 2023 Notes mature on July 1, 2023 and the 2025 Notes mature on June 1, 2025; however, under certain circumstances, holders may surrender their Notes of a series for conversion prior to the applicable maturity date. Upon conversion of the Notes of a series, we will pay cash equal to the aggregate principal amount of the Notes of such series to be converted, and, at our election, will pay or deliver cash and/or shares of our common stock for the amount of our conversion obligation in excess of the aggregate principal amount of the Notes of such series being converted. The sale price condition for the Notes was met during the fiscal quarter ended January 31, 2022, and as a result, holders may convert their Notes at any time during the fiscal quarter ending April 30, 2022. If all of the holders of the Notes converted their Notes during this period, we would be obligated to settle the $3.7 billion principal amount of the Notes in cash. We believe that our cash provided by operating activities, our existing cash, cash equivalents and investments, and existing sources of and access to financing will be sufficient to meet our anticipated cash needs should the holders choose to convert their Notes during the fiscal quarter ending April 30, 2022. As of January 31, 2022, substantially all of our Notes remained outstanding. Refer to Note 9. Debt in Part I, Item 1 of this Quarterly Report on Form 10-Q for more information on the Notes.

[0001327567-22-000008:mdna:129]
In September 2018, we entered into a credit agreement (the “Credit Agreement”) that provides for a $400.0 million unsecured revolving credit facility (the “Credit Facility”), with an option to increase the amount of the credit facility up to an additional $350.0 million, subject to certain conditions. As of January 31, 2022, there were no amounts outstanding and we were in compliance with all covenants under the Credit Agreement. Refer to Note 9. Debt in Part I, Item 1 of this Quarterly Report on Form 10-Q for more information on the Credit Agreement.

[0001327567-22-000008:mdna:130]
[same as prior period, unchanged from 0001327567-21-000040:mdna:144]

[0001327567-22-000008:mdna:131]
[same as prior period, unchanged from 0001327567-21-000040:mdna:130]

[0001327567-22-000008:mdna:132]
[same as prior period, unchanged from 0001327567-21-000040:mdna:131]

[0001327567-22-000008:mdna:133]
In February 2019, our board of directors authorized a $1.0 billion share repurchase program. In December 2020 and August 2021, our board of directors authorized an additional $700.0 million and $676.1 million increase, respectively, bringing the total authorization under this share repurchase program to $2.4 billion. Repurchases will be funded from available working capital and may be made at management’s discretion from time to time. The expiration date of this repurchase authorization was extended to December 31, 2022, and our repurchase program may be suspended or discontinued at any time. As of January 31, 2022, $450.0 million remained available for future share repurchases under this repurchase program. Refer to Note 11. Stockholders’ Equity in Part I, Item 1 of this Quarterly Report on Form 10-Q for more information on this repurchase program.

[0001327567-22-000008:mdna:134]
[same as prior period, unchanged from 0001327567-21-000040:mdna:133]

[0001327567-22-000008:mdna:135]
We have entered into various non-cancelable operating leases primarily for our facilities with original lease periods expiring through the year ending July 31, 2028, with the most significant leases relating to corporate headquarters in Santa Clara, California. As of January 31, 2022, we have total of $344.5 million operating lease obligations recorded on our condensed consolidated balance sheet.

[0001327567-22-000008:mdna:136]
As of January 31, 2022, our purchase obligations including commitments of products and components with our manufacturing partners and component suppliers, as well as minimum or fixed purchase commitments for our use of certain cloud and other services with third-party providers, totaled $2.6 billion. Refer to Note 10. Commitments and Contingencies in Part I, Item 1 of this Quarterly Report on Form 10-Q for more information on these commitments,

[0001327567-22-000008:mdna:137]
[same as prior period, unchanged from 0001327567-21-000040:mdna:136]

[0001327567-22-000008:mdna:138]
The following table summarizes our cash flows for the six months ended January 31, 2022 and 2021:

[0001327567-22-000008:mdna:139]
|  | Six Months Ended January 31, |
| 2022 |  | 2021 |
|  | (in millions) |
| Net cash provided by operating activities | $ | 1,071.5 |  |  | $ | 899.4 |  |
| Net cash used in investing activities | (504.2) |  |  | (1,270.6) |  |
| Net cash used in financing activities | (519.8) |  |  | (469.9) |  |
| Net increase (decrease) in cash, cash equivalents, and restricted cash | $ | 47.5 |  |  | $ | (841.1) |  |

[0001327567-22-000008:mdna:140]
Cash from operations could be affected by various risks and uncertainties, including, but not limited to, the effects of COVID-19 and other risks detailed in Part II, Item 1A “Risk Factors” in this Quarterly Report on Form 10-Q. We believe that our cash flow from operations with existing cash and cash equivalents will be sufficient to meet our anticipated cash needs for at least the next 12 months and thereafter for the foreseeable future. Our future capital requirements will depend on many factors, including our growth rate, the timing and extent of spending to support development efforts, the expansion of sales and marketing activities, the introduction of new and enhanced products and subscription and support offerings, the costs to acquire or invest in complementary businesses and technologies, the costs to ensure access to adequate manufacturing capacity, the investments in our infrastructure to support the adoption of our cloud-based subscription offerings, the repayment obligations associated with our Notes, the investments in our corporate headquarters, the continuing market acceptance of our products and subscription and support offerings, and macroeconomic events such as COVID-19. In addition, from time to time we may incur additional tax liability in connection with certain corporate structuring decisions.

[0001327567-22-000008:mdna:141]
[same as prior period, unchanged from 0001327567-21-000040:mdna:140]

[0001327567-22-000008:mdna:142]
[same as prior period, unchanged from 0001327567-21-000040:mdna:141]

[0001327567-22-000008:mdna:143]
[same as prior period, unchanged from 0001327567-21-000040:mdna:142]

[0001327567-22-000008:mdna:144]
Cash provided by operating activities during the six months ended January 31, 2022 was $1,071.5 million, an increase of $172.1 million compared to the same period in 2021. The increase was primarily due to growth of our business as reflected by an increase in billings, and an increase in collections during the six months ended January 31, 2022, partially offset by higher cash expenditure to support our business growth.

[0001327567-22-000008:mdna:145]
[same as prior period, unchanged from 0001327567-21-000040:mdna:146]

[0001327567-22-000008:mdna:146]
[same as prior period, unchanged from 0001327567-21-000040:mdna:147]

[0001327567-22-000008:mdna:147]
- 33 -

[0001327567-22-000008:mdna:148]
[same as prior period, unchanged from 0001327567-21-000040:mdna:145]

[0001327567-22-000008:mdna:149]
Cash used in investing activities during the six months ended January 31, 2022 was $504.2 million, a decrease of $766.4 million compared to the same period in 2021. The decrease was primarily due to a decrease in net cash payments for business acquisitions and an increase in proceeds from sales and maturities of investments during the six months ended January 31, 2022.

[0001327567-22-000008:mdna:150]
[same as prior period, unchanged from 0001327567-21-000040:mdna:149]

[0001327567-22-000008:mdna:151]
[same as prior period, unchanged from 0001327567-21-000040:mdna:150]

[0001327567-22-000008:mdna:152]
Cash used in financing activities during the six months ended January 31, 2022 was $519.8 million, an increase of $49.9 million compared to the same period in 2021. The increase was primarily due to higher repurchases of our common stock during the six months ended January 31, 2022.

[0001327567-22-000008:mdna:153]
[same as prior period, unchanged from 0001327567-21-000040:mdna:152]

[0001327567-22-000008:mdna:154]
[same as prior period, unchanged from 0001327567-21-000040:mdna:153]

[0001327567-22-000008:mdna:155]
[same as prior period, unchanged from 0001327567-21-000040:mdna:154]

[0001327567-22-000008:mdna:156]
[same as prior period, unchanged from 0001327567-21-000040:mdna:155]

[0001327567-22-000008:mdna:157]
[same as prior period, unchanged from 0001327567-21-000040:mdna:156]
