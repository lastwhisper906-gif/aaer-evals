# PANW MD&A — 0001327567-21-000014


## mdna

[0001327567-21-000014:mdna:1]
[same as prior period, unchanged from 0001327567-21-000004:mdna:1]

[0001327567-21-000014:mdna:2]
[same as prior period, unchanged from 0001327567-21-000004:mdna:2]

[0001327567-21-000014:mdna:3]
[same as prior period, unchanged from 0001327567-21-000004:mdna:3]

[0001327567-21-000014:mdna:4]
[same as prior period, unchanged from 0001327567-21-000004:mdna:4]

[0001327567-21-000014:mdna:5]
•Results of Operations. A discussion of the nature and trends in our financial results and an analysis of our financial results comparing the three and nine months ended April 30, 2021 to the three and nine months ended April 30, 2020.

[0001327567-21-000014:mdna:6]
[same as prior period, unchanged from 0001327567-21-000004:mdna:6]

[0001327567-21-000014:mdna:7]
[same as prior period, unchanged from 0001327567-21-000004:mdna:7]

[0001327567-21-000014:mdna:8]
[same as prior period, unchanged from 0001327567-21-000004:mdna:8]

[0001327567-21-000014:mdna:9]
[same as prior period, unchanged from 0001327567-21-000004:mdna:9]

[0001327567-21-000014:mdna:10]
We empower enterprises, service providers, and government entities to secure all users, applications, data, networks, clouds and devices with comprehensive visibility and context continuously across all locations. We deliver cybersecurity products covering a broad range of use cases, enabling our end-customers to secure their networks, remote workforce, access to the service edge, branch locations, public and private clouds, and to advance their Security Operations Centers (“SOC”). We believe our portfolio offers advanced prevention and security, while reducing the total cost of ownership for organizations by improving operational efficiency and eliminating the need for siloed point products. We do this with solutions focused on delivering value in four fundamental areas:

[0001327567-21-000014:mdna:11]
[same as prior period, unchanged from 0001327567-21-000004:mdna:11]

[0001327567-21-000014:mdna:12]
•Enabling zero trust network security through our ML-Powered Next-Generation Firewalls, available in a number of form factors, including physical, virtual, and containerized appliances, as well as a cloud-delivered service. This also includes our add-on Cloud-delivered Security Services (“Security Services”), such as Threat Prevention, WildFire, Advanced URL Filtering, DNS Security, IoT Security, GlobalProtect, SD-WAN, Enterprise Data Loss Prevention, and SaaS Security that secure applications, users, and devices across our ML-Powered Next-Generation Firewalls, Prisma, and

[0001327567-21-000014:mdna:13]
- 25 -

[0001327567-21-000014:mdna:14]
[same as prior period, unchanged from 0001327567-21-000004:mdna:14]

[0001327567-21-000014:mdna:15]
Cortex product lines. Panorama, our network security management solution, available as hardware or virtual machine, can centrally manage all of our firewalls irrespective of their form factor, location, or scale.

[0001327567-21-000014:mdna:16]
[same as prior period, unchanged from 0001327567-21-000004:mdna:16]

[0001327567-21-000014:mdna:17]
•Enabling cloud security through our Prisma security offerings. Prisma Cloud, the industry’s most comprehensive Cloud Native Security Platform (“CNSP”), secures multi- and hybrid-cloud environments and cloud native applications integrating security across the full deployment lifecycle. Prisma SaaS protects SaaS applications. Prisma Access, the industry’s most complete cloud-delivered security platform, together with Prisma SD-WAN (formerly Cloudgenix SD-WAN), the industry’s only next-generation SD-WAN solution, provide a comprehensive Secure Access Service Edge (“SASE”) offering that is used to secure remote workforces and enable the cloud-delivered branch. VM-Series and CN-Series enforce in-line network security in multi- and hybrid- cloud environments.

[0001327567-21-000014:mdna:18]
Security Analytics and Automation:

[0001327567-21-000014:mdna:19]
•Enabling security operations through our Cortex security offerings. These include Cortex XDR for prevention, detection, and response platforms to stop modern security attacks, Cortex XSOAR for security orchestration, automation, and response (“SOAR”), Expanse for attack surface management (“ASM”). These products are delivered as software or SaaS subscriptions.

[0001327567-21-000014:mdna:20]
Threat Intelligence and Security Consulting:

[0001327567-21-000014:mdna:21]
•Enabling security teams with up to date threat intelligence and deep cybersecurity expertise; before, during and after attacks through our Unit 42 threat research and security consulting team. Unit 42 offers incident response, risk management, board advisory and proactive cybersecurity assessment services.

[0001327567-21-000014:mdna:22]
For the third quarter of fiscal 2021 and 2020, total revenue was $1.1 billion and $869.4 million, respectively, representing year-over-year growth of 23.5%. Our growth reflects the increased adoption of our portfolio, which consists of product, subscriptions, and support. We believe our portfolio will enable us to benefit from recurring revenues as we continue to grow our installed end-customer base. As of April 30, 2021, we had end-customers in more than 170 countries. Our end-customers represent a broad range of industries including education, energy, financial services, government entities, healthcare, Internet and media, manufacturing, public sector, and telecommunications, and include some of the largest Fortune 100 and Global 2000 companies in the world. We maintain a field sales force that works closely with our channel partners in developing sales opportunities. We use a two-tiered, indirect fulfillment model whereby we sell our products, subscriptions, and support to our distributors, which, in turn, sell to our resellers, which then sell to our end-customers.

[0001327567-21-000014:mdna:23]
Our product revenue was $288.9 million, or 26.9% of total revenue, for the third quarter of fiscal 2021, representing year-over-year growth of 2.8%. Product revenue is generated from sales of our appliances, primarily our ML-Powered Next-Generation Firewall, which is available in a number of form factors, including as physical, virtual, and containerized appliances. Our ML-Powered Next-Generation Firewall incorporates our PAN-OS operating system, which provides a consistent set of capabilities across our entire network security product line. Our products are designed for different performance requirements throughout an organization, ranging from our PA-220, which is designed for small organizations and remote or branch offices, to our top-of-the-line PA-7080, which is designed for large-scale data centers and service provider use. The same firewall functionality that is delivered in our physical appliances is also available in our VM-Series virtual firewalls, which secure virtualized and cloud-based computing environments, and in our CN-Series container firewalls, which secure container environments and traffic.

[0001327567-21-000014:mdna:24]
Our subscription and support revenue grew to $785.0 million, or 73.1% of total revenue, for the third quarter of fiscal 2021, representing year-over-year growth of 33.4%. Our subscriptions provide our end-customers with near real-time access to the latest antivirus, intrusion prevention, web filtering, modern malware prevention, data loss prevention, and SaaS security capabilities across the network, endpoints, and the cloud. When end-customers purchase our physical, virtual, or container firewall appliances, they typically purchase support in order to receive ongoing security updates, upgrades, bug fixes, and repairs. In addition to the subscriptions purchased with these appliances, end-customers may also purchase other subscriptions on a per-user, per-endpoint, or capacity-based basis. We also offer professional services, including incident response, risk management, and digital forensic services.

[0001327567-21-000014:mdna:25]
We continue to invest in innovation as we evolve and further extend the capabilities of our platforms, as we believe that innovation and timely development of new features and products are essential to meeting the needs of our end-customers and improving our competitive position. For example, in March 2021, we acquired Bridgecrew Inc. (“Bridgecrew”), which we expect will expand our Prisma Cloud offering to deliver security across the full application lifecycle.

[0001327567-21-000014:mdna:26]
[same as prior period, unchanged from 0001327567-21-000004:mdna:24]

[0001327567-21-000014:mdna:27]
[same as prior period, unchanged from 0001327567-21-000004:mdna:13]

[0001327567-21-000014:mdna:28]
[same as prior period, unchanged from 0001327567-21-000004:mdna:26]

[0001327567-21-000014:mdna:29]
[same as prior period, unchanged from 0001327567-21-000004:mdna:27]

[0001327567-21-000014:mdna:30]
[same as prior period, unchanged from 0001327567-21-000004:mdna:28]

[0001327567-21-000014:mdna:31]
We are actively monitoring, evaluating, and responding to developments relating to COVID-19, which has and is expected to result in continued significant global, social, and business disruption. While we instituted a global work-from-home policy beginning in March 2020, we did not incur significant disruptions in our work operations during the third quarter of fiscal 2021. We are conducting business as usual with restrictions to employee travel, and we have transitioned in-person marketing events to virtual formats, among other modifications. We expect these changes will substantially remain in effect in the fourth quarter of fiscal 2021, and could extend to future quarters. We will continue to actively monitor the situation, including progress made through vaccinations, and we will make further changes to our business operations as may be required by federal, state, or local authorities or that we determine are in the best interests of our employees, end-customers, partners, suppliers, and stockholders. Our focus remains on the safety of our employees, and we strive to protect the health and well-being of the communities in which we operate, in part, by providing technology to our employees, end-customers, and partners to help them do their best work while remote.

[0001327567-21-000014:mdna:32]
Although some end-customers adopted Prisma Access as their secure work-from-home solution for the longer term, there continues to be uncertainty regarding the business outlook due to COVID-19, which may curtail our end-customers’ spending and could lead them to delay or defer purchasing decisions, and lengthen sales cycles and payment terms, which could materially adversely impact our business, results of operations, and overall financial performance. Also, certain of our end-customers or partners may be or may become credit or cash constrained, making it difficult for them to fulfill their payment obligations to us. The extent of the impact of COVID-19 on our operational and financial performance will depend on developments, including the duration and spread of the virus, impact on our end-customers’ spending, volume of sales and length of our sales cycles, impact on our partners, suppliers, and employees, actions that may be taken by governmental authorities, and other factors identified in Part II, Item 1A “Risk Factors” in this Form 10-Q. Given the dynamic nature of these circumstances, the full impact of COVID-19 on our ongoing business, results of operations, and overall financial performance cannot be reasonably estimated at this time.

[0001327567-21-000014:mdna:33]
[same as prior period, unchanged from 0001327567-21-000004:mdna:31]

[0001327567-21-000014:mdna:34]
We monitor the key financial metrics set forth in the tables below to help us evaluate growth trends, establish budgets, measure the effectiveness of our sales and marketing efforts, and assess operational efficiencies. We discuss revenue, gross margin, and the components of operating loss and margin below under “Results of Operations.”

[0001327567-21-000014:mdna:35]
|  | April 30, 2021 |  | July 31, 2020 |
|  | (in millions) |
| Total deferred revenue | $ | 4,375.0 |  |  | $ | 3,810.2 |  |
| Cash, cash equivalents, and investments | $ | 3,830.8 |  |  | $ | 4,302.2 |  |

[0001327567-21-000014:mdna:36]
|  | Three Months Ended April 30, |  | Nine Months Ended April 30, |
|  | 2021 |  | 2020 |  | 2021 |  | 2020 |
|  | (dollars in millions) |
| Total revenue | $ | 1,073.9 |  |  | $ | 869.4 |  |  | $ | 3,036.8 |  |  | $ | 2,458.0 |  |
| Total revenue year-over-year percentage increase | 23.5 | % |  | 19.7 | % |  | 23.5 | % |  | 17.4 | % |
| Gross margin | 69.2 | % |  | 70.3 | % |  | 69.8 | % |  | 71.2 | % |
| Operating loss | $ | (110.4) |  |  | $ | (56.5) |  |  | $ | (243.7) |  |  | $ | (161.2) |  |
| Operating margin | (10.3) | % |  | (6.5) | % |  | (8.0) | % |  | (6.6) | % |
| Billings | $ | 1,286.4 |  |  | $ | 1,015.4 |  |  | $ | 3,583.9 |  |  | $ | 2,911.7 |  |
| Billings year-over-year percentage increase | 26.7 | % |  | 23.5 | % |  | 23.1 | % |  | 19.7 | % |
| Cash flow provided by operating activities |  |  |  |  | $ | 1,177.2 |  |  | $ | 702.0 |  |
| Free cash flow (non-GAAP) |  |  |  |  | $ | 1,088.6 |  |  | $ | 519.4 |  |

[0001327567-21-000014:mdna:37]
[same as prior period, unchanged from 0001327567-21-000004:mdna:35]

[0001327567-21-000014:mdna:38]
[same as prior period, unchanged from 0001327567-21-000004:mdna:36]

[0001327567-21-000014:mdna:39]
[same as prior period, unchanged from 0001327567-21-000004:mdna:25]

[0001327567-21-000014:mdna:40]
[same as prior period, unchanged from 0001327567-21-000004:mdna:38]

[0001327567-21-000014:mdna:41]
[same as prior period, unchanged from 0001327567-21-000004:mdna:39]

[0001327567-21-000014:mdna:42]
|  | Three Months Ended April 30, |  | Nine Months Ended April 30, |
|  | 2021 |  | 2020 |  | 2021 |  | 2020 |
|  | (in millions) |  | (in millions) |
| Billings: |  |  |  |  |  |  |  |
| Total revenue | $ | 1,073.9 |  |  | $ | 869.4 |  |  | $ | 3,036.8 |  |  | $ | 2,458.0 |  |
| Add: change in total deferred revenue, net of acquired deferred revenue | 212.5 |  |  | 146.0 |  |  | 547.1 |  |  | 453.7 |  |
| Billings | $ | 1,286.4 |  |  | $ | 1,015.4 |  |  | $ | 3,583.9 |  |  | $ | 2,911.7 |  |

[0001327567-21-000014:mdna:43]
[same as prior period, unchanged from 0001327567-21-000004:mdna:41]

[0001327567-21-000014:mdna:44]
[same as prior period, unchanged from 0001327567-21-000004:mdna:42]

[0001327567-21-000014:mdna:45]
|  | Nine Months Ended April 30, |
|  | 2021 |  | 2020 |
|  | (in millions) |
| Free cash flow (non-GAAP): |  |  |  |
| Net cash provided by operating activities | $ | 1,177.2 |  |  | $ | 702.0 |  |
| Less: purchases of property, equipment, and other assets | 88.6 |  |  | 182.6 |  |
| Free cash flow (non-GAAP) | $ | 1,088.6 |  |  | $ | 519.4 |  |
| Net cash provided by (used in) investing activities | $ | (1,478.2) |  |  | $ | 955.6 |  |
| Net cash used in financing activities | $ | (768.4) |  |  | $ | (1,132.5) |  |

[0001327567-21-000014:mdna:46]
[same as prior period, unchanged from 0001327567-21-000004:mdna:37]

[0001327567-21-000014:mdna:47]
[same as prior period, unchanged from 0001327567-21-000004:mdna:45]

[0001327567-21-000014:mdna:48]
[same as prior period, unchanged from 0001327567-21-000004:mdna:46]

[0001327567-21-000014:mdna:49]
[same as prior period, unchanged from 0001327567-21-000004:mdna:47]

[0001327567-21-000014:mdna:50]
|  | Three Months Ended April 30, |  | Nine Months Ended April 30, |
|  | 2021 |  | 2020 |  | 2021 |  | 2020 |
|  | Amount |  | % of Revenue |  | Amount |  | % of Revenue |  | Amount |  | % of Revenue |  | Amount |  | % of Revenue |
|  | (dollars in millions) |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product | $ | 288.9 |  | 26.9 | % |  | $ | 280.9 |  |  | 32.3 | % |  | $ | 780.9 |  | 25.7 | % |  | $ | 758.6 |  |  | 30.9 | % |
| Subscription and support | 785.0 |  | 73.1 | % |  | 588.5 |  |  | 67.7 | % |  | 2,255.9 |  | 74.3 | % |  | 1,699.4 |  |  | 69.1 | % |
| Total revenue | 1,073.9 |  | 100.0 | % |  | 869.4 |  |  | 100.0 | % |  | 3,036.8 |  | 100.0 | % |  | 2,458.0 |  |  | 100.0 | % |
| Cost of revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product | 81.9 |  | 7.6 | % |  | 73.3 |  |  | 8.4 | % |  | 219.7 |  | 7.2 | % |  | 207.1 |  |  | 8.4 | % |
| Subscription and support | 248.7 |  | 23.2 | % |  | 185.0 |  |  | 21.3 | % |  | 696.3 |  | 23.0 | % |  | 502.0 |  |  | 20.4 | % |
| Total cost of revenue(1) | 330.6 |  | 30.8 | % |  | 258.3 |  |  | 29.7 | % |  | 916.0 |  | 30.2 | % |  | 709.1 |  |  | 28.8 | % |
| Total gross profit | 743.3 |  | 69.2 | % |  | 611.1 |  |  | 70.3 | % |  | 2,120.8 |  | 69.8 | % |  | 1,748.9 |  |  | 71.2 | % |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Research and development | 311.0 |  | 29.0 | % |  | 196.3 |  |  | 22.6 | % |  | 815.1 |  | 26.8 | % |  | 552.2 |  |  | 22.5 | % |
| Sales and marketing | 448.0 |  | 41.7 | % |  | 388.4 |  |  | 44.7 | % |  | 1,264.0 |  | 41.6 | % |  | 1,129.0 |  |  | 46.0 | % |
| General and administrative | 94.7 |  | 8.8 | % |  | 82.9 |  |  | 9.5 | % |  | 285.4 |  | 9.4 | % |  | 228.9 |  |  | 9.3 | % |
| Total operating expenses(1) | 853.7 |  | 79.5 | % |  | 667.6 |  |  | 76.8 | % |  | 2,364.5 |  | 77.8 | % |  | 1,910.1 |  |  | 77.8 | % |
| Operating loss | (110.4) |  | (10.3) | % |  | (56.5) |  |  | (6.5) | % |  | (243.7) |  |  | (8.0) | % |  | (161.2) |  |  | (6.6) | % |
| Interest expense | (41.0) |  | (3.8) | % |  | (19.4) |  |  | (2.2) | % |  | (121.9) |  |  | (4.0) | % |  | (57.3) |  |  | (2.3) | % |
| Other income, net | 1.0 |  | 0.1 | % |  | 8.1 |  |  | 0.9 | % |  | 2.9 |  |  | 0.1 | % |  | 35.1 |  |  | 1.4 | % |
| Loss before income taxes | (150.4) |  |  | (14.0) | % |  | (67.8) |  |  | (7.8) | % |  | (362.7) |  |  | (11.9) | % |  | (183.4) |  |  | (7.5) | % |
| Provision for (benefit from) income taxes | (5.3) |  |  | (0.5) | % |  | 7.0 |  |  | 0.8 | % |  | 16.9 |  |  | 0.6 | % |  | 24.7 |  |  | 1.0 | % |
| Net loss | $ | (145.1) |  |  | (13.5) | % |  | $ | (74.8) |  |  | (8.6) | % |  | $ | (379.6) |  |  | (12.5) | % |  | $ | (208.1) |  |  | (8.5) | % |

[0001327567-21-000014:mdna:51]
[same as prior period, unchanged from 0001327567-21-000004:mdna:49]

[0001327567-21-000014:mdna:52]
[same as prior period, unchanged from 0001327567-21-000004:mdna:50]

[0001327567-21-000014:mdna:53]
|  | Three Months Ended April 30, |  | Nine Months Ended April 30, |
|  | 2021 |  | 2020 |  | 2021 |  | 2020 |
|  | (in millions) |
| Cost of product revenue | $ | 1.6 |  |  | $ | 1.4 |  |  | $ | 4.7 |  |  | $ | 4.2 |  |
| Cost of subscription and support revenue | 23.3 |  |  | 18.8 |  |  | 69.3 |  |  | 57.6 |  |
| Research and development | 118.2 |  |  | 67.7 |  |  | 317.2 |  |  | 197.4 |  |
| Sales and marketing | 69.2 |  |  | 55.5 |  |  | 203.8 |  |  | 155.0 |  |
| General and administrative | 30.6 |  |  | 22.7 |  |  | 101.9 |  |  | 76.0 |  |
| Total share-based compensation | $ | 242.9 |  |  | $ | 166.1 |  |  | $ | 696.9 |  |  | $ | 490.2 |  |

[0001327567-21-000014:mdna:54]
[same as prior period, unchanged from 0001327567-21-000004:mdna:52]

[0001327567-21-000014:mdna:55]
[same as prior period, unchanged from 0001327567-21-000004:mdna:53]

[0001327567-21-000014:mdna:56]
[same as prior period, unchanged from 0001327567-21-000004:mdna:44]

[0001327567-21-000014:mdna:57]
[same as prior period, unchanged from 0001327567-21-000004:mdna:55]

[0001327567-21-000014:mdna:58]
[same as prior period, unchanged from 0001327567-21-000004:mdna:56]

[0001327567-21-000014:mdna:59]
[same as prior period, unchanged from 0001327567-21-000004:mdna:57]

[0001327567-21-000014:mdna:60]
|  | Three Months Ended April 30, |  |  |  |  |  | Nine Months Ended April 30, |  |  |  |  |
|  | 2021 |  | 2020 |  | Change |  | 2021 |  | 2020 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| Product | $ | 288.9 |  |  | $ | 280.9 |  |  | $ | 8.0 |  |  | 2.8 | % |  | $ | 780.9 |  |  | $ | 758.6 |  |  | $ | 22.3 |  |  | 2.9 | % |

[0001327567-21-000014:mdna:61]
The change in product revenue for the three and nine months ended April 30, 2021 compared to the same periods in 2020 represented a modest increase in product sales in both periods.

[0001327567-21-000014:mdna:62]
[same as prior period, unchanged from 0001327567-21-000004:mdna:60]

[0001327567-21-000014:mdna:63]
[same as prior period, unchanged from 0001327567-21-000004:mdna:61]

[0001327567-21-000014:mdna:64]
|  | Three Months Ended April 30, |  |  |  |  |  | Nine Months Ended April 30, |  |  |  |  |
|  | 2021 |  | 2020 |  | Change |  | 2021 |  | 2020 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| Subscription | $ | 473.8 |  |  | $ | 354.3 |  |  | $ | 119.5 |  |  | 33.7 | % |  | $ | 1,363.5 |  |  | $ | 1,015.5 |  |  | $ | 348.0 |  |  | 34.3 | % |
| Support | 311.2 |  |  | 234.2 |  |  | 77.0 |  |  | 32.9 | % |  | 892.4 |  |  | 683.9 |  |  | 208.5 |  |  | 30.5 | % |
| Total subscription and support | $ | 785.0 |  |  | $ | 588.5 |  |  | $ | 196.5 |  |  | 33.4 | % |  | $ | 2,255.9 |  |  | $ | 1,699.4 |  |  | $ | 556.5 |  |  | 32.7 | % |

[0001327567-21-000014:mdna:65]
Subscription and support revenue increased for the three and nine months ended April 30, 2021 compared to the same periods in 2020. The increase in both periods was due to increased demand for our subscription and support offerings from both new and existing end-customers. The mix between subscription revenue and support revenue will fluctuate over time, depending on the introduction of new subscription offerings, renewals of support services, and our ability to increase sales to new and existing end-customers. The change in subscription and support revenue due to changes in pricing was not significant for either period.

[0001327567-21-000014:mdna:66]
[same as prior period, unchanged from 0001327567-21-000004:mdna:64]

[0001327567-21-000014:mdna:67]
|  | Three Months Ended April 30, |  |  |  |  |  | Nine Months Ended April 30, |  |  |  |  |
|  | 2021 |  | 2020 |  | Change |  | 2021 |  | 2020 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| Americas | $ | 734.5 |  |  | $ | 594.2 |  |  | $ | 140.3 |  |  | 23.6 | % |  | $ | 2,095.7 |  |  | $ | 1,668.5 |  |  | $ | 427.2 |  |  | 25.6 | % |
| EMEA | 210.2 |  |  | 171.5 |  |  | 38.7 |  |  | 22.6 | % |  | 586.9 |  |  | 485.3 |  |  | 101.6 |  |  | 20.9 | % |
| APAC | 129.2 |  |  | 103.7 |  |  | 25.5 |  |  | 24.6 | % |  | 354.2 |  |  | 304.2 |  |  | 50.0 |  |  | 16.4 | % |
| Total revenue | $ | 1,073.9 |  |  | $ | 869.4 |  |  | $ | 204.5 |  |  | 23.5 | % |  | $ | 3,036.8 |  |  | $ | 2,458.0 |  |  | $ | 578.8 |  |  | 23.5 | % |

[0001327567-21-000014:mdna:68]
With respect to geographic theaters, the increase in revenue for the three and nine months ended April 30, 2021 compared to the same periods in 2020 was driven primarily by the Americas, due to its larger and more established sales force. Revenue from our other geographic theaters, both Europe, the Middle East, and Africa (“EMEA”) and Asia Pacific and Japan (“APAC”), increased for the three and nine months ended April 30, 2021 compared to the same periods in 2020 due to continued investment in our global sales force in order to support our growth and innovation.

[0001327567-21-000014:mdna:69]
[same as prior period, unchanged from 0001327567-21-000004:mdna:67]

[0001327567-21-000014:mdna:70]
[same as prior period, unchanged from 0001327567-21-000004:mdna:68]

[0001327567-21-000014:mdna:71]
[same as prior period, unchanged from 0001327567-21-000004:mdna:54]

[0001327567-21-000014:mdna:72]
[same as prior period, unchanged from 0001327567-21-000004:mdna:70]

[0001327567-21-000014:mdna:73]
[same as prior period, unchanged from 0001327567-21-000004:mdna:71]

[0001327567-21-000014:mdna:74]
[same as prior period, unchanged from 0001327567-21-000004:mdna:72]

[0001327567-21-000014:mdna:75]
|  | Three Months Ended April 30, |  |  |  |  |  | Nine Months Ended April 30, |  |  |  |  |
|  | 2021 |  | 2020 |  | Change |  | 2021 |  | 2020 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| Cost of product revenue | $ | 81.9 |  |  | $ | 73.3 |  |  | $ | 8.6 |  |  | 11.7 | % |  | $ | 219.7 |  |  | $ | 207.1 |  |  | $ | 12.6 |  |  | 6.1 | % |
| Number of employees at period end | 129 |  |  | 118 |  |  | 11 |  |  | 9.3 | % |  | 129 |  |  | 118 |  |  | 11 |  |  | 9.3 | % |

[0001327567-21-000014:mdna:76]
Cost of product revenue increased for the three months ended April 30, 2021 compared to the same period in 2020, primarily due to product mix and an increase in product volume. The increase in the nine months ended April 30, 2021 compared to the same period in 2020 was due to an increase in product volume and higher amortization of intellectual property licenses.

[0001327567-21-000014:mdna:77]
[same as prior period, unchanged from 0001327567-21-000004:mdna:75]

[0001327567-21-000014:mdna:78]
[same as prior period, unchanged from 0001327567-21-000004:mdna:76]

[0001327567-21-000014:mdna:79]
|  | Three Months Ended April 30, |  |  |  |  |  | Nine Months Ended April 30, |  |  |  |  |
|  | 2021 |  | 2020 |  | Change |  | 2021 |  | 2020 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| Cost of subscription and support revenue | $ | 248.7 |  |  | $ | 185.0 |  |  | $ | 63.7 |  |  | 34.4 | % |  | $ | 696.3 |  |  | $ | 502.0 |  |  | $ | 194.3 |  |  | 38.7 | % |
| Number of employees at period end | 1,871 |  |  | 1,403 |  |  | 468 |  |  | 33.4 | % |  | 1,871 |  |  | 1,403 |  |  | 468 |  |  | 33.4 | % |

[0001327567-21-000014:mdna:80]
Cost of subscription and support revenue increased for the three and nine months ended April 30, 2021 compared to the same periods in 2020, primarily due to increased costs to support the growth of our subscription and support offerings. Personnel costs grew $26.4 million to $107.9 million for the three months ended April 30, 2021 compared to the same period in 2020, and grew $60.8 million to $295.7 million for the nine months ended April 30, 2021 compared to the same period in 2020, primarily due to headcount growth. Cloud hosting service costs, which support the adoption of our cloud-based subscription offerings, increased $4.7 million for the three months ended April 30, 2021 compared to the same period in 2020, and increased $47.6 million for the nine months ended April 30, 2021 compared to the same period in 2020. The remaining increase for both the three and nine month periods was primarily due to increased outside service costs for global customer support from the expansion of our customer base, and the amortization of intangible assets from our recent acquisitions.

[0001327567-21-000014:mdna:81]
[same as prior period, unchanged from 0001327567-21-000004:mdna:79]

[0001327567-21-000014:mdna:82]
[same as prior period, unchanged from 0001327567-21-000004:mdna:80]

[0001327567-21-000014:mdna:83]
|  | Three Months Ended April 30, |  | Nine Months Ended April 30, |
|  | 2021 |  | 2020 |  | 2021 |  | 2020 |
|  | Amount |  | Gross Margin |  | Amount |  | Gross Margin |  | Amount |  | Gross Margin |  | Amount |  | Gross Margin |
|  | (dollars in millions) |
| Product | $ | 207.0 |  |  | 71.7 | % |  | $ | 207.6 |  |  | 73.9 | % |  | $ | 561.2 |  |  | 71.9 | % |  | $ | 551.5 |  |  | 72.7 | % |
| Subscription and support | 536.3 |  |  | 68.3 | % |  | 403.5 |  |  | 68.6 | % |  | 1,559.6 |  |  | 69.1 | % |  | 1,197.4 |  |  | 70.5 | % |
| Total gross profit | $ | 743.3 |  |  | 69.2 | % |  | $ | 611.1 |  |  | 70.3 | % |  | $ | 2,120.8 |  |  | 69.8 | % |  | $ | 1,748.9 |  |  | 71.2 | % |

[0001327567-21-000014:mdna:84]
[same as prior period, unchanged from 0001327567-21-000004:mdna:69]

[0001327567-21-000014:mdna:85]
[same as prior period, unchanged from 0001327567-21-000004:mdna:83]

[0001327567-21-000014:mdna:86]
Product gross margin decreased for the three months ended April 30, 2021 compared to the same period in 2020, primarily due to product mix. The decrease in the nine months ended April 30, 2021 compared to the same period in 2020 was primarily due to higher amortization of intellectual property licenses, as well as increased fulfillment cost partially related to COVID-19.

[0001327567-21-000014:mdna:87]
Subscription and support gross margin for the three months ended April 30, 2021 compared to the same period in 2020 was relatively flat. The decrease in the nine months ended April 30, 2021 compared to the same period in 2020 was primarily due to an increase in costs to support our cloud-based offerings.

[0001327567-21-000014:mdna:88]
[same as prior period, unchanged from 0001327567-21-000004:mdna:86]

[0001327567-21-000014:mdna:89]
Our operating expenses consist of research and development, sales and marketing, and general and administrative expense. Personnel costs are the most significant component of operating expenses and consist of salaries, benefits, bonuses, share-based compensation, travel and entertainment, and with regard to sales and marketing expense, sales commissions. Our operating expenses also include allocated costs, which consist of certain facilities, depreciation, benefits, recruiting, and information technology costs that we allocate based on headcount. We expect operating expenses generally to increase in absolute dollars and decrease over the long term as a percentage of revenue as we continue to scale our business. In response to COVID-19, we instituted a global work-from-home policy and limited employee travel beginning in March 2020. Further, we have canceled in-person events and either replaced them with virtual events or postponed them to future periods. As of April 30, 2021, we expect to recognize approximately $2.0 billion of share-based compensation expense over a weighted-average period of approximately 2.7 years, excluding additional share-based compensation expense related to any future grants of share-based awards. Share-based compensation expense is generally recognized on a straight-line basis over the requisite service periods of the awards.

[0001327567-21-000014:mdna:90]
[same as prior period, unchanged from 0001327567-21-000004:mdna:88]

[0001327567-21-000014:mdna:91]
[same as prior period, unchanged from 0001327567-21-000004:mdna:89]

[0001327567-21-000014:mdna:92]
|  | Three Months Ended April 30, |  |  |  |  |  | Nine Months Ended April 30, |  |  |  |  |
|  | 2021 |  | 2020 |  | Change |  | 2021 |  | 2020 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| Research and development | $ | 311.0 |  |  | $ | 196.3 |  |  | $ | 114.7 |  |  | 58.4 | % |  | $ | 815.1 |  |  | $ | 552.2 |  |  | $ | 262.9 |  |  | 47.6 | % |
| Number of employees at period end | 2,425 |  |  | 1,789 |  |  | 636 |  |  | 35.6 | % |  | 2,425 |  |  | 1,789 |  |  | 636 |  |  | 35.6 | % |

[0001327567-21-000014:mdna:93]
Research and development expense increased for the three and nine months ended April 30, 2021 compared to the same periods in 2020. The increase was primarily due to personnel costs, which grew $99.6 million to $251.9 million for the three months ended April 30, 2021 compared to the same period in 2020, and grew $226.7 million to $655.9 million for the nine months ended April 30, 2021 compared to the same period in 2020. The increase in personnel costs in both periods was primarily due to headcount growth.

[0001327567-21-000014:mdna:94]
[same as prior period, unchanged from 0001327567-21-000004:mdna:92]

[0001327567-21-000014:mdna:95]
Sales and marketing expense consists primarily of personnel costs, including commission expense. Sales and marketing expense also includes costs for market development programs, promotional and other marketing costs, professional services, and allocated costs. We continue to thoughtfully invest in headcount and have substantially grown our international sales presence. We expect sales and marketing expense to continue to increase in absolute dollars as we increase the size of our sales and marketing organizations to increase touch points with end-customers and to expand our global presence, although our sales and marketing expense may fluctuate as a percentage of total revenue.

[0001327567-21-000014:mdna:96]
|  | Three Months Ended April 30, |  |  |  |  |  | Nine Months Ended April 30, |  |  |  |  |
|  | 2021 |  | 2020 |  | Change |  | 2021 |  | 2020 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| Sales and marketing | $ | 448.0 |  |  | $ | 388.4 |  |  | $ | 59.6 |  |  | 15.3 | % |  | $ | 1,264.0 |  |  | $ | 1,129.0 |  |  | $ | 135.0 |  |  | 12.0 | % |
| Number of employees at period end | 4,237 |  |  | 3,853 |  | 384 |  |  | 10.0 | % |  | 4,237 |  |  | 3,853 |  |  | 384 |  |  | 10.0 | % |

[0001327567-21-000014:mdna:97]
Sales and marketing expense increased for the three and nine months ended April 30, 2021 compared to the same periods in 2020, primarily due to personnel costs, which grew $51.5 million to $342.1 million for the three months ended April 30, 2021 compared to the same period in 2020, and grew $116.6 million to $958.8 million for the nine months ended April 30, 2021 compared to the same period in 2020. The increase in personnel costs in both periods was largely due to headcount growth, partially offset by decreased travel expenses due to COVID-19. In addition, expenses increased in both periods as a result of go-to-market initiatives,

[0001327567-21-000014:mdna:98]
[same as prior period, unchanged from 0001327567-21-000004:mdna:82]

[0001327567-21-000014:mdna:99]
[same as prior period, unchanged from 0001327567-21-000004:mdna:97]

[0001327567-21-000014:mdna:100]
including advertising, which were partially offset by a decrease in trade shows and convention expenses as in-person events were replaced with virtual events due to COVID-19.

[0001327567-21-000014:mdna:101]
[same as prior period, unchanged from 0001327567-21-000004:mdna:99]

[0001327567-21-000014:mdna:102]
[same as prior period, unchanged from 0001327567-21-000004:mdna:100]

[0001327567-21-000014:mdna:103]
|  | Three Months Ended April 30, |  |  |  |  |  | Nine Months Ended April 30, |  |  |  |  |
|  | 2021 |  | 2020 |  | Change |  | 2021 |  | 2020 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| General and administrative | $ | 94.7 |  |  | $ | 82.9 |  |  | $ | 11.8 |  |  | 14.2 | % |  | $ | 285.4 |  |  | $ | 228.9 |  |  | $ | 56.5 |  |  | 24.7 | % |
| Number of employees at period end | 1,053 |  |  | 886 |  |  | 167 |  |  | 18.8 | % |  | 1,053 |  |  | 886 |  |  | 167 |  |  | 18.8 | % |

[0001327567-21-000014:mdna:104]
General and administrative expense increased for the three and nine months ended April 30, 2021 compared to the same periods in 2020, primarily due to personnel costs, which increased $6.2 million to $58.3 million for the three months ended April 30, 2021 compared to the same period in 2020, and grew $29.9 million to $184.0 million for the nine months ended April 30, 2021 compared to the same period in 2020. The increase in personnel costs in both periods was primarily due to the accelerated vesting of certain equity awards in connection with our acquisitions. Other increases in both periods included increased professional services expense to support our business growth.

[0001327567-21-000014:mdna:105]
[same as prior period, unchanged from 0001327567-21-000004:mdna:103]

[0001327567-21-000014:mdna:106]
Interest expense primarily consists of non-cash interest expense from the amortization of the debt discount and debt issuance costs related to our 0.75% Convertible Senior Notes due 2023 (the “2023 Notes”) and the 0.375% Convertible Senior Notes due 2025 (the “2025 Notes,” and together with “2023 Notes,” the “Notes”), and also includes the contractual interest expense related to our Notes.

[0001327567-21-000014:mdna:107]
|  | Three Months Ended April 30, |  |  |  | Nine Months Ended April 30, |  |  |
|  | 2021 |  | 2020 |  | Change |  | 2021 |  | 2020 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| Interest expense | $ | 41.0 |  |  | $ | 19.4 |  |  | $ | 21.6 |  |  | 111.3 | % |  | $ | 121.9 |  |  | $ | 57.3 |  |  | $ | 64.6 |  |  | 112.7 | % |

[0001327567-21-000014:mdna:108]
Interest expense increased for the three and nine months ended April 30, 2021 compared to the same periods in 2020 primarily due to our 2025 Notes issued in the fourth quarter of fiscal 2020. Refer to Note 10. Debt in Part I, Item 1 of this Quarterly Report on Form 10-Q for more information on our Notes.

[0001327567-21-000014:mdna:109]
Other Income, Net

[0001327567-21-000014:mdna:110]
Other income, net includes interest income earned on our cash, cash equivalents, and investments, foreign currency remeasurement gains and losses, and foreign currency transaction gains and losses.

[0001327567-21-000014:mdna:111]
|  | Three Months Ended April 30, |  |  |  | Nine Months Ended April 30, |  |  |
|  | 2021 |  | 2020 |  | Change |  | 2021 |  | 2020 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| Other income, net | $ | 1.0 |  |  | $ | 8.1 |  |  | $ | (7.1) |  |  | (87.7) | % |  | $ | 2.9 |  |  | $ | 35.1 |  |  | $ | (32.2) |  |  | (91.7) | % |

[0001327567-21-000014:mdna:112]
The change in other income, net for the three and nine months ended April 30, 2021 compared to the same periods in 2020 was primarily due to lower interest income earned on our cash, cash equivalent, and investment balances as a result of lower interest rates for the three and nine months ended April 30, 2021 compared to the same periods in 2020.

[0001327567-21-000014:mdna:113]
[same as prior period, unchanged from 0001327567-21-000004:mdna:96]

[0001327567-21-000014:mdna:114]
[same as prior period, unchanged from 0001327567-21-000004:mdna:112]

[0001327567-21-000014:mdna:115]
Provision for (Benefit from) Income Taxes

[0001327567-21-000014:mdna:116]
Provision for (benefit from) income taxes consists primarily of income taxes in foreign jurisdictions in which we conduct business and withholding taxes. We maintain a full valuation allowance for domestic and certain foreign deferred tax assets, including net operating loss carryforwards and certain domestic tax credits. In recent years, we reorganized our corporate structure and intercompany relationships to more closely align with the international nature of our business activities. Our corporate structure has caused, and may continue to cause, disproportionate relationships between our overall effective tax rate and other jurisdictional measures. To the extent we revisit our corporate structure, it may have an impact on our tax provision.

[0001327567-21-000014:mdna:117]
|  | Three Months Ended April 30, |  | Change |  | Nine Months Ended April 30, |  | Change |
|  | 2021 |  | 2020 |  | Amount |  | % |  | 2021 |  | 2020 |  | Amount |  | % |
|  | (dollars in millions) |
| Provision for (benefit from) income taxes | $ | (5.3) |  |  | $ | 7.0 |  |  | $ | (12.3) |  |  | (175.7) | % |  | $ | 16.9 |  |  | $ | 24.7 |  |  | $ | (7.8) |  |  | (31.6) | % |
| Effective tax rate | 3.5 | % |  | (10.3) | % |  |  |  |  |  | (4.7) | % |  | (13.5) | % |  |  |  |  |

[0001327567-21-000014:mdna:118]
We recorded an income tax benefit for the three months ended April 30, 2021 and income tax provision for the nine months ended April 30, 2021. Our income taxes are primarily due to foreign income taxes in profitable jurisdictions and withholding taxes. Our effective tax rate varied for the three and nine months ended April 30, 2021 compared to the same periods in 2020 primarily due to our valuation allowance. Refer to Note 14. Income Taxes in Part I, Item 1 of this Quarterly Report on Form 10-Q for more information.

[0001327567-21-000014:mdna:119]
[same as prior period, unchanged from 0001327567-21-000004:mdna:117]

[0001327567-21-000014:mdna:120]
|  | April 30, 2021 |  | July 31, 2020 |
|  | (in millions) |
| Working capital | $ | 1,133.6 |  |  | $ | 2,437.5 |  |
| Cash, cash equivalents, and investments: |  |  |  |
| Cash and cash equivalents | $ | 1,886.1 |  |  | $ | 2,958.0 |  |
| Investments | 1,944.7 |  |  | 1,344.2 |  |
| Total cash, cash equivalents, and investments | $ | 3,830.8 |  |  | $ | 4,302.2 |  |

[0001327567-21-000014:mdna:121]
As of April 30, 2021, our total cash, cash equivalents, and investments of $3.8 billion were held for general corporate purposes, of which approximately $785.7 million was held outside of the United States. As of April 30, 2021, we had no unremitted earnings when evaluating our outside basis difference relating to our U.S. investment in foreign subsidiaries. However, there could be local withholding taxes payable due to various foreign countries if certain lower tier earnings are distributed. Withholding taxes that would be payable upon remittance of these lower tier earnings are not expected to be material.

[0001327567-21-000014:mdna:122]
In July 2018, we issued the 2023 Notes with an aggregate principal amount of $1.7 billion. In June 2020, we issued the 2025 Notes with an aggregate principal amount of $2.0 billion. The 2023 Notes mature on July 1, 2023 and the 2025 Notes mature on June 1, 2025; however, under certain circumstances, holders may surrender their Notes of a series for conversion prior to the applicable maturity date. Upon conversion of the Notes of a series, we will pay cash equal to the aggregate principal amount of the Notes of such series to be converted, and, at our election, will pay or deliver cash and/or shares of our common stock for the amount of our conversion obligation in excess of the aggregate principal amount of the Notes of such series being converted. As of April 30, 2021, all of our Notes remained outstanding. Refer to Note 10. Debt in Part I, Item 1 of this Quarterly Report on Form 10-Q for more information on the Notes.

[0001327567-21-000014:mdna:123]
In September 2018, we entered into a credit agreement (the “Credit Agreement”) that provides for a $400.0 million unsecured revolving credit facility (the “Credit Facility”), with an option to increase the amount of the credit facility up to an additional $350.0 million, subject to certain conditions. As of April 30, 2021, there were no amounts outstanding and we were in compliance with all covenants under the Credit Agreement. Refer to Note 10. Debt in Part I, Item 1 of this Quarterly Report on Form 10-Q for more information on the Credit Agreement.

[0001327567-21-000014:mdna:124]
In February 2019, our board of directors authorized a $1.0 billion share repurchase program, and, in December 2020, our board of directors authorized a $700.0 million increase to our share repurchase program, bringing the total authorization to $1.7 billion. Repurchases are funded from available working capital and may be made at management’s discretion from time to time. The expiration date of this repurchase program was extended to December 31, 2021, and our repurchase program may be suspended or discontinued at any time. As of April 30, 2021, $651.9 million remained available for future share repurchases under this repurchase program. Refer to Note 12. Stockholders’ Equity in Part I, Item 1 of this Quarterly Report on Form 10-Q for more information on this repurchase program.

[0001327567-21-000014:mdna:125]
[same as prior period, unchanged from 0001327567-21-000004:mdna:111]

[0001327567-21-000014:mdna:126]
[same as prior period, unchanged from 0001327567-21-000004:mdna:126]

[0001327567-21-000014:mdna:127]
The following table summarizes our cash flows for the nine months ended April 30, 2021 and 2020:

[0001327567-21-000014:mdna:128]
|  | Nine Months Ended April 30, |
| 2021 |  | 2020 |
|  | (in millions) |
| Net cash provided by operating activities | $ | 1,177.2 |  |  | $ | 702.0 |  |
| Net cash provided by (used in) investing activities | (1,478.2) |  |  | 955.6 |  |
| Net cash used in financing activities | (768.4) |  |  | (1,132.5) |  |
| Net increase (decrease) in cash, cash equivalents, and restricted cash | $ | (1,069.4) |  |  | $ | 525.1 |  |

[0001327567-21-000014:mdna:129]
Cash from operations could be affected by various risks and uncertainties, including, but not limited to, the effects of COVID-19 and other risks detailed in Part II, Item 1A “Risk Factors” in this Form 10-Q. We believe that our cash flow from operations with existing cash and cash equivalents will be sufficient to meet our anticipated cash needs for at least the next 12 months and thereafter for the foreseeable future. Our future capital requirements will depend on many factors including our growth rate, the timing and extent of spending to support development efforts, the expansion of sales and marketing activities, the introduction of new and enhanced products and subscription and support offerings, the costs to acquire or invest in complementary businesses and technologies, the costs to ensure access to adequate manufacturing capacity, the investments in our infrastructure to support the adoption of our cloud-based subscription offerings, the investments in our new corporate headquarters, the continuing market acceptance of our products and subscription and support offerings, and macroeconomic events such as COVID-19. In addition, from time to time we may incur additional tax liability in connection with certain corporate structuring decisions.

[0001327567-21-000014:mdna:130]
[same as prior period, unchanged from 0001327567-21-000004:mdna:131]

[0001327567-21-000014:mdna:131]
[same as prior period, unchanged from 0001327567-21-000004:mdna:132]

[0001327567-21-000014:mdna:132]
[same as prior period, unchanged from 0001327567-21-000004:mdna:133]

[0001327567-21-000014:mdna:133]
Cash provided by operating activities during the nine months ended April 30, 2021 was $1,177.2 million, an increase of $475.2 million compared to the same period in 2020. The increase was primarily due to growth of our business as reflected by an increase in billings, and an increase in collections during the nine months ended April 30, 2021, partially offset by a decrease in cash due to timing of payments.

[0001327567-21-000014:mdna:134]
[same as prior period, unchanged from 0001327567-21-000004:mdna:135]

[0001327567-21-000014:mdna:135]
[same as prior period, unchanged from 0001327567-21-000004:mdna:136]

[0001327567-21-000014:mdna:136]
Cash used in investing activities during the nine months ended April 30, 2021 was $1,478.2 million, a net change of $2.4 billion compared to cash provided by investing activities of $955.6 million during the same period in 2020. The change was primarily due to higher purchases of investments, a decrease in proceeds from maturities and sales of investments, and an increase in net cash payments for business acquisitions during the nine months ended April 30, 2021.

[0001327567-21-000014:mdna:137]
[same as prior period, unchanged from 0001327567-21-000004:mdna:138]

[0001327567-21-000014:mdna:138]
[same as prior period, unchanged from 0001327567-21-000004:mdna:139]

[0001327567-21-000014:mdna:139]
Cash used in financing activities during the nine months ended April 30, 2021 was $768.4 million, a decrease of $364.1 million compared to the same period in 2020. The decrease was primarily due to lower repurchases of our common stock during the nine months ended April 30, 2021.

[0001327567-21-000014:mdna:140]
[same as prior period, unchanged from 0001327567-21-000004:mdna:141]

[0001327567-21-000014:mdna:141]
Except for those disclosed in Note 11. Commitments and Contingencies in Part I, Item 1 of this Quarterly Report on Form 10-Q, there have been no material changes outside of the ordinary course of business to our contractual obligations and commitments disclosed in our Annual Report on Form 10-K for the fiscal year ended July 31, 2020.

[0001327567-21-000014:mdna:142]
[same as prior period, unchanged from 0001327567-21-000004:mdna:145]

[0001327567-21-000014:mdna:143]
As of April 30, 2021, we did not have any relationships with unconsolidated organizations or financial partnerships, such as structured finance or special purpose entities that would have been established for the purpose of facilitating off-balance sheet arrangements or other contractually narrow or limited purposes.

[0001327567-21-000014:mdna:144]
[same as prior period, unchanged from 0001327567-21-000004:mdna:125]

[0001327567-21-000014:mdna:145]
[same as prior period, unchanged from 0001327567-21-000004:mdna:144]

[0001327567-21-000014:mdna:146]
[same as prior period, unchanged from 0001327567-21-000004:mdna:147]

[0001327567-21-000014:mdna:147]
[same as prior period, unchanged from 0001327567-21-000004:mdna:148]

[0001327567-21-000014:mdna:148]
[same as prior period, unchanged from 0001327567-21-000004:mdna:149]

[0001327567-21-000014:mdna:149]
[same as prior period, unchanged from 0001327567-21-000004:mdna:150]

[0001327567-21-000014:mdna:150]
For a discussion of the recent accounting pronouncements, refer to “Recently Adopted Accounting Pronouncements” and “Recently Issued Accounting Pronouncements” in Note 1. Description of Business and Summary of Significant Accounting Policies in Part I, Item 1 of this Quarterly Report on Form 10-Q.
