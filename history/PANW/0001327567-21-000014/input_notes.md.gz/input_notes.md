# PANW notes — 0001327567-21-000014


## us-gaap:OrganizationConsolidationBasisOfPresentationBusinessDescriptionAndAccountingPoliciesTextBlock

[0001327567-21-000014:notes:1]
[same as prior period, unchanged from 0001327567-21-000004:notes:1]

[0001327567-21-000014:notes:2]
Palo Alto Networks, Inc. (the “Company,” “we,” “us,” or “our”), located in Santa Clara, California, was incorporated in March 2005 under the laws of the State of Delaware and commenced operations in April 2005. We empower enterprises, service providers, and government entities to secure all users, applications, data, networks, clouds and devices with comprehensive visibility and context continuously across all locations.

[0001327567-21-000014:notes:3]
[same as prior period, unchanged from 0001327567-21-000004:notes:3]

[0001327567-21-000014:notes:4]
[same as prior period, unchanged from 0001327567-21-000004:notes:4]

[0001327567-21-000014:notes:5]
[same as prior period, unchanged from 0001327567-21-000004:notes:5]

[0001327567-21-000014:notes:6]
[same as prior period, unchanged from 0001327567-21-000004:notes:6]

[0001327567-21-000014:notes:7]
The preparation of condensed consolidated financial statements in conformity with GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities and disclosure of contingent assets and liabilities at the date of the condensed consolidated financial statements and the reported amounts of revenues and expenses during the reporting period. We base our estimates on historical experience and also on assumptions that we believe are reasonable. Actual results could differ materially from those estimates due to risks and uncertainties, including uncertainty in the current economic environment due to COVID-19.

[0001327567-21-000014:notes:8]
[same as prior period, unchanged from 0001327567-21-000004:notes:8]

[0001327567-21-000014:notes:9]
There have been no material changes to our significant accounting policies as of and for the nine months ended April 30, 2021, as compared to the significant accounting policies described in our Annual Report on Form 10-K for the fiscal year ended July 31, 2020, except for the change in our accounting policies for credit losses due to our adoption of the new credit losses guidance. Refer to “Recently Adopted Accounting Pronouncements” below.

[0001327567-21-000014:notes:10]
Recently Adopted Accounting Pronouncements

[0001327567-21-000014:notes:11]
[same as prior period, unchanged from 0001327567-21-000004:notes:11]

[0001327567-21-000014:notes:12]
[same as prior period, unchanged from 0001327567-21-000004:notes:12]

[0001327567-21-000014:notes:13]
[same as prior period, unchanged from 0001327567-21-000004:notes:13]

[0001327567-21-000014:notes:14]
[same as prior period, unchanged from 0001327567-21-000004:notes:14]

[0001327567-21-000014:notes:15]
[same as prior period, unchanged from 0001327567-21-000004:notes:15]

[0001327567-21-000014:notes:16]
[same as prior period, unchanged from 0001327567-21-000004:notes:16]

[0001327567-21-000014:notes:17]
recorded in other income, net in our condensed consolidated statements of operations. Impairment losses that are not credit-related are included in accumulated other comprehensive income (loss) (“AOCI”) in stockholders’ equity.

[0001327567-21-000014:notes:18]
[same as prior period, unchanged from 0001327567-21-000004:notes:18]

[0001327567-21-000014:notes:19]
Trade accounts receivable are recorded at the invoiced amount, net of allowances for credit losses for any potential uncollectible amounts. The allowance for credit losses is based on our assessment of the collectability of accounts. Management regularly reviews the adequacy of the allowance for credit losses on a collective basis by considering the age of each outstanding invoice, each customer’s expected ability to pay and collection history, current market conditions, and reasonable and supportable forecasts of future economic conditions to determine whether the allowance is appropriate. Accounts receivable deemed uncollectible are charged against the allowance for credit losses when identified. For the three and nine months ended April 30, 2021 and 2020, the allowance for credit losses activity was not significant.

[0001327567-21-000014:notes:20]
[same as prior period, unchanged from 0001327567-21-000004:notes:20]

[0001327567-21-000014:notes:21]
We provide financing arrangements, primarily loans, for certain qualified end-user customers to purchase our products and services. Payment terms on these financing arrangements are up to five years. We evaluate our allowance for credit losses by assessing the risks and losses inherent in our financing receivables on either an individual or a collective basis. Our assessment considers various factors, including lifetime expected losses determined using customer risk profile, current economic conditions that may affect a customer’s ability to pay, and forward-looking economic considerations. Financing receivables are written off when they are considered uncollectible, and related outstanding balances are reversed and charged against the allowance for credit losses. Short-term financing receivables are included in prepaid expenses and other current assets, and long-term financing receivables are included in other assets on our condensed consolidated balance sheets. Refer to Note 5. Financing Receivables for additional information.

[0001327567-21-000014:notes:22]
Recently Issued Accounting Pronouncements

[0001327567-21-000014:notes:23]
[same as prior period, unchanged from 0001327567-21-000004:notes:23]

[0001327567-21-000014:notes:24]
[same as prior period, unchanged from 0001327567-21-000004:notes:24]


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001327567-21-000014:notes:25]
[same as prior period, unchanged from 0001327567-21-000004:notes:25]

[0001327567-21-000014:notes:26]
[same as prior period, unchanged from 0001327567-21-000004:notes:26]

[0001327567-21-000014:notes:27]
|  | Three Months Ended April 30, |  | Nine Months Ended April 30, |
|  | 2021 |  | 2020 |  | 2021 |  | 2020 |
| Revenue: |  |  |  |  |  |  |  |
| Americas |  |  |  |  |  |  |  |
| United States | $ | 685.4 |  |  | $ | 553.5 |  |  | $ | 1,957.8 |  |  | $ | 1,554.0 |  |
| Other Americas | 49.1 |  |  | 40.7 |  |  | 137.9 |  |  | 114.5 |  |
| Total Americas | 734.5 |  |  | 594.2 |  |  | 2,095.7 |  |  | 1,668.5 |  |
| Europe, the Middle East, and Africa (“EMEA”) | 210.2 |  |  | 171.5 |  |  | 586.9 |  |  | 485.3 |  |
| Asia Pacific and Japan (“APAC”) | 129.2 |  |  | 103.7 |  |  | 354.2 |  |  | 304.2 |  |
| Total revenue | $ | 1,073.9 |  |  | $ | 869.4 |  |  | $ | 3,036.8 |  |  | $ | 2,458.0 |  |

[0001327567-21-000014:notes:28]
[same as prior period, unchanged from 0001327567-21-000004:notes:28]

[0001327567-21-000014:notes:29]
|  | Three Months Ended April 30, |  | Nine Months Ended April 30, |
|  | 2021 |  | 2020 |  | 2021 |  | 2020 |
| Revenue: |  |  |  |  |  |  |  |
| Product | $ | 288.9 |  |  | $ | 280.9 |  |  | $ | 780.9 |  |  | $ | 758.6 |  |
| Subscription and support |  |  |  |  |  |  |  |
| Subscription | 473.8 |  |  | 354.3 |  |  | 1,363.5 |  |  | 1,015.5 |  |
| Support | 311.2 |  |  | 234.2 |  |  | 892.4 |  |  | 683.9 |  |
| Total subscription and support | 785.0 |  |  | 588.5 |  |  | 2,255.9 |  |  | 1,699.4 |  |
| Total revenue | $ | 1,073.9 |  |  | $ | 869.4 |  |  | $ | 3,036.8 |  |  | $ | 2,458.0 |  |

[0001327567-21-000014:notes:30]
[same as prior period, unchanged from 0001327567-21-000004:notes:30]

[0001327567-21-000014:notes:31]
During the nine months ended April 30, 2021 and 2020, we recognized approximately $1.6 billion and $1.3 billion of revenue pertaining to amounts that were deferred as of July 31, 2020 and 2019, respectively.

[0001327567-21-000014:notes:32]
[same as prior period, unchanged from 0001327567-21-000004:notes:32]

[0001327567-21-000014:notes:33]
Revenue expected to be recognized from remaining performance obligations was $4.9 billion as of April 30, 2021, of which we expect to recognize approximately $2.6 billion over the next 12 months and the remainder thereafter.
Deferred Contract Costs
The following table presents details of our short-term and long-term deferred contract costs as of April 30, 2021 and July 31, 2020 (in millions):

[0001327567-21-000014:notes:34]
|  | April 30, 2021 |  | July 31, 2020 |
| Short-term deferred contract costs | $ | 235.0 |  |  | $ | 206.0 |  |
| Long-term deferred contract costs | 420.1 |  |  | 422.3 |  |
| Total deferred contract costs | $ | 655.1 |  |  | $ | 628.3 |  |

[0001327567-21-000014:notes:35]
We recognized amortization expense for our deferred contract costs of $73.9 million and $208.3 million during the three and nine months ended April 30, 2021, respectively, and $60.5 million and $171.4 million during the three and nine months ended 
April 30, 2020, respectively. We did not recognize any impairment losses on our deferred contract costs during the three and nine months ended April 30, 2021 or 2020.


## us-gaap:FairValueMeasurementPolicyPolicyTextBlock

[0001327567-21-000014:notes:36]
Fair Value Measurements 
We categorize assets and liabilities recorded or disclosed at fair value on our condensed consolidated balance sheets based upon the level of judgment associated with inputs used to measure their fair value. The categories are as follows:

[0001327567-21-000014:notes:37]
•Level 1—Inputs are unadjusted quoted prices in active markets for identical assets or liabilities.

[0001327567-21-000014:notes:38]
•Level 2—Inputs are quoted prices for similar assets and liabilities in active markets or inputs that are observable for the assets or liabilities, either directly or indirectly through market corroboration, for substantially the full term of the financial instruments.

[0001327567-21-000014:notes:39]
•Level 3—Inputs are unobservable inputs based on our own assumptions used to measure assets and liabilities at fair value. The inputs require significant management judgment or estimation.


## us-gaap:FairValueDisclosuresTextBlock

[0001327567-21-000014:notes:40]
The following table presents the fair value of our financial assets and liabilities measured at fair value on a recurring basis using the above input categories as of April 30, 2021 and July 31, 2020 (in millions):

[0001327567-21-000014:notes:41]
|  |  | April 30, 2021 |  | July 31, 2020 |
|  |  | Level 1 |  | Level 2 |  | Level 3 |  | Total |  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| Cash equivalents: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 265.0 |  |  | $ | — |  |  | $ | — |  |  | $ | 265.0 |  |  | $ | 1,589.5 |  |  | $ | — |  |  | $ | — |  |  | $ | 1,589.5 |  |
| Certificates of deposit |  | — |  |  | 150.2 |  |  | — |  |  | 150.2 |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Corporate debt securities |  | — |  |  | 2.0 |  |  | — |  |  | 2.0 |  |  | — |  |  | — |  |  | — |  |  | — |  |
| U.S. government and agency securities |  | — |  |  | 130.0 |  |  | — |  |  | 130.0 |  |  | — |  |  | 342.0 |  |  | — |  |  | 342.0 |  |
| Total cash equivalents |  | 265.0 |  |  | 282.2 |  |  | — |  |  | 547.2 |  |  | 1,589.5 |  |  | 342.0 |  |  | — |  |  | 1,931.5 |  |
| Short-term investments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Certificates of deposit |  | — |  |  | 18.5 |  |  | — |  |  | 18.5 |  |  | — |  |  | 26.9 |  |  | — |  |  | 26.9 |  |
| Corporate debt securities |  | — |  |  | 233.6 |  |  | — |  |  | 233.6 |  |  | — |  |  | 100.2 |  |  | — |  |  | 100.2 |  |
| U.S. government and agency securities |  | — |  |  | 775.3 |  |  | — |  |  | 775.3 |  |  | — |  |  | 645.6 |  |  | — |  |  | 645.6 |  |
| Non-U.S. government and agency securities |  |  |  | 31.9 |  |  |  |  | 31.9 |  |  |  |  | 17.1 |  |  |  |  | 17.1 |  |
| Total short-term investments |  | — |  |  | 1,059.3 |  |  | — |  |  | 1,059.3 |  |  | — |  |  | 789.8 |  |  | — |  |  | 789.8 |  |
| Long-term investments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Certificates of deposit |  | — |  |  | 5.0 |  |  | — |  |  | 5.0 |  |  | — |  |  | 5.0 |  |  | — |  |  | 5.0 |  |
| Corporate debt securities |  | — |  |  | 156.3 |  |  | — |  |  | 156.3 |  |  | — |  |  | 91.7 |  |  | — |  |  | 91.7 |  |
| U.S. government and agency securities |  | — |  |  | 691.5 |  |  | — |  |  | 691.5 |  |  | — |  |  | 447.4 |  |  | — |  |  | 447.4 |  |
| Non-U.S. government and agency securities |  | — |  |  | 32.6 |  |  | — |  |  | 32.6 |  |  | — |  |  | 10.3 |  |  | — |  |  | 10.3 |  |
| Total long-term investments |  | — |  |  | 885.4 |  |  | — |  |  | 885.4 |  |  | — |  |  | 554.4 |  |  | — |  |  | 554.4 |  |
| Prepaid expenses and other current assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency forward contracts |  | — |  |  | 11.3 |  |  | — |  |  | 11.3 |  |  | — |  |  | 13.6 |  |  | — |  |  | 13.6 |  |
| Total prepaid expenses and other current assets |  | — |  |  | 11.3 |  |  | — |  |  | 11.3 |  |  | — |  |  | 13.6 |  |  | — |  |  | 13.6 |  |
| Other assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency forward contracts |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 1.4 |  |  | — |  |  | 1.4 |  |
| Total other assets: |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 1.4 |  |  | — |  |  | 1.4 |  |
| Total assets measured at fair value |  | $ | 265.0 |  |  | $ | 2,238.2 |  |  | $ | — |  |  | $ | 2,503.2 |  |  | $ | 1,589.5 |  |  | $ | 1,701.2 |  |  | $ | — |  |  | $ | 3,290.7 |  |
| Accrued and other liabilities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency forward contracts |  | $ | — |  |  | $ | 0.1 |  |  | $ | — |  |  | $ | 0.1 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Total accrued and other liabilities |  | — |  |  | 0.1 |  |  | — |  |  | 0.1 |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Total liabilities measured at fair value |  | $ | — |  |  | $ | 0.1 |  |  | $ | — |  |  | $ | 0.1 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |

[0001327567-21-000014:notes:42]
Refer to Note 10. Debt for the carrying amount and estimated fair value of our convertible senior notes as of April 30, 2021 and July 31, 2020.


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock

[0001327567-21-000014:notes:43]
Cash Equivalents and Investments
Available-for-sale Debt Securities

[0001327567-21-000014:notes:44]
The following tables summarize the amortized cost, unrealized gains and losses, and fair value of our available-for-sale debt securities as of April 30, 2021 and July 31, 2020 (in millions):

[0001327567-21-000014:notes:45]
|  | April 30, 2021 |
|  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Fair Value |
| Cash equivalents: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 150.2 |  |  | $ | — |  |  | $ | — |  |  | $ | 150.2 |  |
| Corporate debt securities | 2.0 |  |  | — |  |  | — |  |  | 2.0 |  |
| U.S. government and agency securities | 130.0 |  |  | — |  |  | — |  |  | 130.0 |  |
| Total available-for-sale cash equivalents | $ | 282.2 |  |  | $ | — |  |  | $ | — |  |  | $ | 282.2 |  |
| Investments: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 23.5 |  |  | $ | — |  |  | $ | — |  |  | $ | 23.5 |  |
| Corporate debt securities | 389.4 |  |  | 0.6 |  |  | (0.1) |  |  | 389.9 |  |
| U.S. government and agency securities | 1,465.3 |  |  | 1.5 |  |  | — |  |  | 1,466.8 |  |
| Non-U.S. government and agency securities | 64.5 |  |  | — |  |  | — |  |  | 64.5 |  |
| Total available-for-sale investments | $ | 1,942.7 |  |  | $ | 2.1 |  |  | $ | (0.1) |  |  | $ | 1,944.7 |  |

[0001327567-21-000014:notes:46]
|  | July 31, 2020 |
|  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Fair Value |
| Cash equivalents: |  |  |  |  |  |  |  |
| U.S. government and agency securities | $ | 342.0 |  |  | $ | — |  |  | $ | — |  |  | $ | 342.0 |  |
| Total available-for-sale cash equivalents | $ | 342.0 |  |  | $ | — |  |  | $ | — |  |  | $ | 342.0 |  |
| Investments: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 31.9 |  |  | $ | — |  |  | $ | — |  |  | $ | 31.9 |  |
| Corporate debt securities | 190.1 |  |  | 1.8 |  |  | — |  |  | 191.9 |  |
| U.S. government and agency securities | 1,090.3 |  |  | 2.8 |  |  | (0.1) |  |  | 1,093.0 |  |
| Non-U.S. government and agency securities | 27.4 |  |  | — |  |  | — |  |  | 27.4 |  |
| Total available-for-sale investments | $ | 1,339.7 |  |  | $ | 4.6 |  |  | $ | (0.1) |  |  | $ | 1,344.2 |  |

[0001327567-21-000014:notes:47]
We do not intend to sell any of the securities in an unrealized loss position and it is not likely that we would be required to sell these securities before recovery of their amortized cost basis, which may be at maturity. We did not recognize any credit losses related to our available-for-sale debt securities during the three and nine months ended April 30, 2021.

[0001327567-21-000014:notes:48]
The following table summarizes the amortized cost and fair value of our available-for-sale debt securities as of April 30, 2021, by contractual years-to-maturity (in millions):

[0001327567-21-000014:notes:49]
|  | Amortized Cost |  | Fair Value |
| Due within one year | $ | 1,340.5 |  |  | $ | 1,341.5 |  |
| Due between one and three years | 884.4 |  |  | 885.4 |  |
| Total | $ | 2,224.9 |  |  | $ | 2,226.9 |  |

[0001327567-21-000014:notes:50]
Marketable Equity Securities

[0001327567-21-000014:notes:51]
Marketable equity securities consist of money market funds and are included in cash and cash equivalents on our condensed consolidated balance sheets. As of April 30, 2021 and July 31, 2020, the carrying values of our marketable equity securities were $265.0 million and $1.6 billion, respectively. There were no unrealized gains or losses recognized for these securities during the three and nine months ended April 30, 2021 and 2020.


## us-gaap:FinancingReceivablesTextBlock

[0001327567-21-000014:notes:52]
Financing Receivables
We provide financing arrangements, primarily loans, for certain qualified end-user customers to purchase our products and services. The following table summarizes our short-term and long-term financing receivables as of April 30, 2021 (in millions):

[0001327567-21-000014:notes:53]
|  |  | Amount |
| Short-term financing receivables, gross |  | $ | 32.1 |  |
| Allowance for credit losses |  | (0.7) |  |
| Short-term financing receivables, net |  | $ | 31.4 |  |
| Long-term financing receivables, gross |  | $ | 68.9 |  |
| Allowance for credit losses |  | (1.5) |  |
| Long-term financing receivables, net |  | $ | 67.4 |  |

[0001327567-21-000014:notes:54]
Through July 31, 2020, financing receivables were not significant to our condensed consolidated balance sheet. There was no significant activity in allowance for credit losses during the three and nine months ended April 30, 2021. Past due amounts on financing receivables were immaterial as of April 30, 2021 and July 31, 2020.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001327567-21-000014:notes:55]
[same as prior period, unchanged from 0001327567-21-000004:notes:55]

[0001327567-21-000014:notes:56]
As of April 30, 2021 and July 31, 2020, the total notional amount of our outstanding foreign currency forward contracts was $186.8 million and $443.6 million, respectively. Refer to Note 3. Fair Value Measurements for the fair value of our derivative instruments as reported on our condensed consolidated balance sheets as of April 30, 2021.

[0001327567-21-000014:notes:57]
During the three and nine months ended April 30, 2021 and 2020, both unrealized gains and losses recognized in AOCI related to our cash flow hedges and amounts reclassified into earnings were not material. Unrealized gains and losses in AOCI related to our cash flow hedges as of April 30, 2021 and 2020 were not material.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001327567-21-000014:notes:58]
Acquisitions
Bridgecrew Inc.

[0001327567-21-000014:notes:59]
On March 2, 2021, we completed our acquisition of Bridgecrew Inc. (“Bridgecrew”), a privately-held cloud security company. We expect the acquisition will expand our Prisma Cloud offering to deliver security across the full application lifecycle. The total purchase consideration for the acquisition of Bridgecrew was $156.9 million, which consisted of the following (in millions):

[0001327567-21-000014:notes:60]
|  | Amount |
| Cash | $ | 155.9 |  |
| Fair value of replacement awards | 1.0 |  |
| Total | $ | 156.9 |  |

[0001327567-21-000014:notes:61]
As part of the acquisition, we issued $42.5 million of replacement awards, of which the portion attributable to services performed prior to the acquisition date was allocated to purchase consideration. The remaining fair value was allocated to future services and will be expensed over the remaining service periods as share-based compensation.

[0001327567-21-000014:notes:62]
[same as prior period, unchanged from 0001327567-21-000004:notes:62]

[0001327567-21-000014:notes:63]
|  | Amount |
| Goodwill | $ | 129.6 |  |
| Identified intangible assets | 21.6 |  |
| Cash | 9.0 |  |
| Net liabilities assumed | (3.3) |  |
| Total | $ | 156.9 |  |

[0001327567-21-000014:notes:64]
Goodwill generated from this business combination is primarily attributable to the assembled workforce and expected post-acquisition synergies from integrating Bridgecrew technology into our platforms. The goodwill is not deductible for income tax purposes.

[0001327567-21-000014:notes:65]
The following table presents details of the identified intangible asset acquired (in millions, except years):

[0001327567-21-000014:notes:66]
|  | Fair Value |  | Estimated Useful Life |
| Developed technology | $ | 21.6 |  |  | 6 years |

[0001327567-21-000014:notes:67]
Expanse Inc.

[0001327567-21-000014:notes:68]
[same as prior period, unchanged from 0001327567-21-000004:notes:59]

[0001327567-21-000014:notes:69]
[same as prior period, unchanged from 0001327567-21-000004:notes:60]

[0001327567-21-000014:notes:70]
[same as prior period, unchanged from 0001327567-21-000004:notes:61]

[0001327567-21-000014:notes:71]
[same as prior period, unchanged from 0001327567-21-000004:notes:63]

[0001327567-21-000014:notes:72]
[same as prior period, unchanged from 0001327567-21-000004:notes:64]

[0001327567-21-000014:notes:73]
[same as prior period, unchanged from 0001327567-21-000004:notes:65]

[0001327567-21-000014:notes:74]
[same as prior period, unchanged from 0001327567-21-000004:notes:66]

[0001327567-21-000014:notes:75]
[same as prior period, unchanged from 0001327567-21-000004:notes:67]

[0001327567-21-000014:notes:76]
On November 24, 2020, we completed our acquisition of Sinefa Group, Inc. and its wholly owned subsidiaries (“Sinefa”), a privately-held digital experience monitoring company. We expect the acquisition will extend our Prisma Access offering. The total purchase consideration for the acquisition of Sinefa was $27.0 million, which consisted of the following (in millions):

[0001327567-21-000014:notes:77]
[same as prior period, unchanged from 0001327567-21-000004:notes:69]

[0001327567-21-000014:notes:78]
[same as prior period, unchanged from 0001327567-21-000004:notes:70]

[0001327567-21-000014:notes:79]
[same as prior period, unchanged from 0001327567-21-000004:notes:71]

[0001327567-21-000014:notes:80]
[same as prior period, unchanged from 0001327567-21-000004:notes:72]

[0001327567-21-000014:notes:81]
[same as prior period, unchanged from 0001327567-21-000004:notes:73]

[0001327567-21-000014:notes:82]
[same as prior period, unchanged from 0001327567-21-000004:notes:74]

[0001327567-21-000014:notes:83]
On September 17, 2020, we completed our acquisition of The Crypsis Group (“Crypsis”), an incident response, risk management, and digital forensics consulting firm. We expect the acquisition will expand our capabilities and strengthen our Cortex strategy. The total purchase consideration for the acquisition of Crypsis was $227.7 million, which consisted of the following (in millions):

[0001327567-21-000014:notes:84]
[same as prior period, unchanged from 0001327567-21-000004:notes:76]

[0001327567-21-000014:notes:85]
[same as prior period, unchanged from 0001327567-21-000004:notes:77]

[0001327567-21-000014:notes:86]
[same as prior period, unchanged from 0001327567-21-000004:notes:78]

[0001327567-21-000014:notes:87]
[same as prior period, unchanged from 0001327567-21-000004:notes:79]

[0001327567-21-000014:notes:88]
[same as prior period, unchanged from 0001327567-21-000004:notes:80]

[0001327567-21-000014:notes:89]
[same as prior period, unchanged from 0001327567-21-000004:notes:81]

[0001327567-21-000014:notes:90]
[same as prior period, unchanged from 0001327567-21-000004:notes:82]

[0001327567-21-000014:notes:91]
Additional information related to the acquired companies, such as that related to income tax and other contingencies, existing as of the respective acquisition dates but unknown to us, may become known during the remainders of the respective measurement periods, not to exceed 12 months from each such acquisition date, which may result in changes to the amounts and allocations recorded.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001327567-21-000014:notes:92]
[same as prior period, unchanged from 0001327567-21-000004:notes:84]

[0001327567-21-000014:notes:93]
The following table presents details of our goodwill during the nine months ended April 30, 2021 (in millions):

[0001327567-21-000014:notes:94]
|  | Amount |
| Balance as of July 31, 2020 | $ | 1,812.9 |  |
| Goodwill acquired | 902.1 |  |
| Measurement period adjustment | (1.9) |  |
| Balance as of April 30, 2021 | $ | 2,713.1 |  |

[0001327567-21-000014:notes:95]
[same as prior period, unchanged from 0001327567-21-000004:notes:87]

[0001327567-21-000014:notes:96]
The following table presents details of our purchased intangible assets as of April 30, 2021 and July 31, 2020 (in millions):

[0001327567-21-000014:notes:97]
|  | April 30, 2021 |  | July 31, 2020 |
|  | Gross Carrying Amount |  | Accumulated Amortization |  | Net Carrying Amount |  | Gross Carrying Amount |  | Accumulated Amortization |  | Net Carrying Amount |
| Intangible assets subject to amortization: |  |  |  |  |  |  |  |  |  |  |  |
| Developed technology | $ | 596.2 |  |  | $ | (217.7) |  |  | $ | 378.5 |  |  | $ | 425.9 |  |  | $ | (146.6) |  |  | $ | 279.3 |  |
| Customer relationships | 172.7 |  |  | (25.1) |  |  | 147.6 |  |  | 87.6 |  |  | (12.4) |  |  | 75.2 |  |
| Acquired intellectual property | 7.9 |  |  | (3.7) |  |  | 4.2 |  |  | 6.3 |  |  | (3.2) |  |  | 3.1 |  |
| Trade name and trademarks | 9.4 |  |  | (9.4) |  |  | — |  |  | 9.4 |  |  | (9.4) |  |  | — |  |
| Other | 2.8 |  |  | (2.8) |  |  | — |  |  | 3.1 |  |  | (2.5) |  |  | 0.6 |  |
| Total purchased intangible assets | $ | 789.0 |  |  | $ | (258.7) |  |  | $ | 530.3 |  |  | $ | 532.3 |  |  | $ | (174.1) |  |  | $ | 358.2 |  |

[0001327567-21-000014:notes:98]
We recognized amortization expense of $32.8 million and $86.1 million for the three and nine months ended April 30, 2021, respectively, and $19.3 million and $54.1 million for the three and nine months ended April 30, 2020, respectively.

[0001327567-21-000014:notes:99]
The following table summarizes estimated future amortization expense of our intangible assets as of April 30, 2021 (in millions):

[0001327567-21-000014:notes:100]
|  | Total |  | Remaining 2021 |  | 2022 |  | 2023 |  | 2024 |  | 2025 |  | 2026 and Thereafter |
| Future amortization expense | $ | 530.3 |  |  | $ | 31.7 |  |  | $ | 125.7 |  |  | $ | 99.6 |  |  | $ | 89.6 |  |  | $ | 75.9 |  |  | $ | 107.8 |  |


## us-gaap:DebtDisclosureTextBlock

[0001327567-21-000014:notes:101]
Debt
Convertible Senior Notes

[0001327567-21-000014:notes:102]
In July 2018, we issued $1.7 billion aggregate principal amount of 0.75% Convertible Senior Notes due 2023 (the “2023 Notes”) and in June 2020, we issued $2.0 billion aggregate principal amount of 0.375% Convertible Senior Notes due 2025 (the “2025 Notes,” and together with the 2023 Notes, the “Notes”). The 2023 Notes bear interest at a fixed rate of 0.75% per year, payable semi-annually in arrears on January 1 and July 1 of each year, beginning on January 1, 2019. The 2025 Notes bear interest at a fixed rate of 0.375% per year, payable semi-annually in arrears on June 1 and December 1 of each year, beginning on December 1, 2020. Each series of the convertible notes is governed by an indenture between us, as the issuer, and U.S. Bank National Association, as Trustee (individually, each an “Indenture,” and together, the “Indentures”). The Notes of each series are unsecured, unsubordinated obligations and the applicable Indenture governing each series of Notes does not contain any financial covenants or restrictions on the payments of dividends, the incurrence of indebtedness, or the issuance or repurchase of securities by us or any of our subsidiaries. The 2023 Notes and the 2025 Notes mature on July 1, 2023 and June 1, 2025, respectively. We cannot redeem the 2023 Notes prior to maturity. We may redeem for cash all or any portion of the 2025 Notes, at our option, on or after June 5, 2023, and prior to the 31st scheduled trading day immediately preceding the maturity date if the last reported sale price of our common stock has been at least 130% of the conversion price then in effect for at least 20 trading days during any 30 consecutive trading day period ending on and including the trading day preceding the date on which we provide notice of redemption. The redemption will be at a price equal to 100% of the principal amount of the 2025 Notes and adjusted for interest. If we call any or all of the 2025 Notes for redemption, holders may convert such 2025 Notes called for redemption at any time prior to the close of business on the second scheduled trading day immediately preceding the redemption date.

[0001327567-21-000014:notes:103]
The following table presents details of our Notes (number of shares in millions):

[0001327567-21-000014:notes:104]
|  | Conversion Rate per $1,000 Principal |  | Initial Conversion Price |  | Convertible Date |  | Initial Number of Shares |
| 2023 Notes | 3.7545 |  |  | $ | 266.35 |  |  | April 1, 2023 |  | 6.4 |  |
| 2025 Notes | 3.3602 |  |  | $ | 297.60 |  |  | March 1, 2025 |  | 6.7 |  |

[0001327567-21-000014:notes:105]
Holders of the Notes may surrender their Notes for conversion at their option at any time prior to the close of business on the business day immediately preceding their respective convertible dates only under the following circumstances:

[0001327567-21-000014:notes:106]
•during any fiscal quarter commencing after the fiscal quarters ending on October 31, 2018 and October 31, 2020 for the 2023 Notes and the 2025 Notes, respectively (and only during such fiscal quarter), if the last reported sale price of our common stock for at least 20 trading days (whether or not consecutive) during a period of 30 consecutive trading days ending on the last trading day of the immediately preceding fiscal quarter is greater than or equal to 130% of the applicable conversion price for the respective Notes on each applicable trading day (the “sale price condition”);

[0001327567-21-000014:notes:107]
•during the five business day period after any five consecutive trading day period (the “measurement period”) in which the trading price per $1,000 principal amount of the applicable series of Notes for each trading day of the measurement period was less than 98% of the product of the last reported sale price of our common stock and the applicable conversion rate for the respective Notes on each such trading day; or

[0001327567-21-000014:notes:108]
•upon the occurrence of specified corporate events.

[0001327567-21-000014:notes:109]
On or after the respective convertible date, holders may surrender all or any portion of their Notes for conversion at any time prior to the close of business on the second scheduled trading day immediately preceding the applicable maturity date regardless of the foregoing conditions, and such conversions will be settled upon the applicable maturity date. Upon conversion, holders of the Notes of a series will receive cash equal to the aggregate principal amount of the Notes of such series to be converted, and, at our election, cash and/or shares of our common stock for any amounts in excess of the aggregate principal amount of the Notes of such series being converted.

[0001327567-21-000014:notes:110]
The conversion price will be subject to adjustment in some events. Holders of the Notes of a series who convert their Notes of such series in connection with certain corporate events that constitute a “make-whole fundamental change” under the applicable Indenture are, under certain circumstances, entitled to an increase in the conversion rate for such series of Notes. Additionally, upon the occurrence of a corporate event that constitutes a “fundamental change” under the applicable Indenture, holders of the Notes of such series may require us to repurchase for cash all or a portion of the Notes of such series at a repurchase price equal to 100% of the principal amount of the Notes of such series plus accrued and unpaid interest to, but excluding, the fundamental change repurchase date.

[0001327567-21-000014:notes:111]
The sale price condition was not met for the Notes during the fiscal quarters ended April 30, 2021 and July 31, 2020. Since the Notes were not convertible, the net carrying amount of the Notes was classified as a long-term liability and the equity component was

[0001327567-21-000014:notes:112]
included in additional paid-in capital in our condensed consolidated balance sheets in the periods presented. As of April 30, 2021, all of the Notes remained outstanding.

[0001327567-21-000014:notes:113]
The following table sets forth the components of the Notes as of April 30, 2021 and July 31, 2020 (in millions):

[0001327567-21-000014:notes:114]
|  | April 30, 2021 | July 31, 2020 |
|  | 2023 Notes |  | 2025 Notes |  | Total |  | 2023 Notes |  | 2025 Notes |  | Total |
| Liability component: |  |  |  |  |  |  |  |  |  |  |  |
| Principal | $ | 1,693.0 |  |  | $ | 2,000.0 |  |  | $ | 3,693.0 |  |  | $ | 1,693.0 |  |  | $ | 2,000.0 |  |  | $ | 3,693.0 |  |
| Less: debt discount and debt issuance costs, net of amortization | 150.9 |  |  | 351.5 |  |  | 502.4 |  |  | 200.0 |  |  | 408.9 |  |  | 608.9 |  |
| Net carrying amount | $ | 1,542.1 |  |  | $ | 1,648.5 |  |  | $ | 3,190.6 |  |  | $ | 1,493.0 |  |  | $ | 1,591.1 |  |  | $ | 3,084.1 |  |
| Equity component | $ | 315.0 |  |  | $ | 403.0 |  |  | $ | 718.0 |  |  | $ | 315.0 |  |  | $ | 403.0 |  |  | $ | 718.0 |  |

[0001327567-21-000014:notes:115]
The total estimated fair value of the Notes was $5.0 billion and $4.1 billion at April 30, 2021 and July 31, 2020, respectively. The fair value was determined based on the closing trading price per $100 of the Notes as of the last day of trading for the period. We consider the fair value of the Notes at April 30, 2021 and July 31, 2020 to be a Level 2 measurement. The fair value of the Notes is primarily affected by the trading price of our common stock and market interest rates. Based on the closing price of our common stock on April 30, 2021, the if-converted values of the 2023 Notes and 2025 Notes exceeded their principal amounts by $488.4 million and $305.7 million, respectively.

[0001327567-21-000014:notes:116]
The following table sets forth interest expense recognized related to the Notes (dollars in millions):

[0001327567-21-000014:notes:117]
|  | Three Months Ended April 30, |  | Nine Months Ended April 30, |
|  | 2021 |  | 2020 |  | 2021 |  | 2020 |
|  | 2023 Notes |  | 2025 Notes |  | Total |  | 2023 Notes |  |  |  | Total |  | 2023 Notes |  | 2025 Notes |  | Total |  | 2023 Notes |  |  |  | Total |
| Contractual interest expense | $ | 3.2 |  | $ | 1.8 |  | $ | 5.0 |  |  | $ | 3.2 |  |  |  |  | $ | 3.2 |  |  | $ | 9.5 |  | $ | 5.6 |  | $ | 15.1 |  |  | $ | 9.5 |  |  |  | $ | 9.5 |  |
| Amortization of debt discount | 16.0 |  | 18.6 |  | 34.6 |  |  | 15.3 |  |  |  |  | 15.3 |  |  | 47.4 |  | 55.3 |  | 102.7 |  |  | 45.5 |  |  |  | 45.5 |  |
| Amortization of debt issuance costs | 0.6 |  | 0.7 |  | 1.3 |  |  | 0.5 |  |  |  |  | 0.5 |  |  | 1.7 |  | 2.1 |  | 3.8 |  |  | 1.5 |  |  |  | 1.5 |  |
| Total interest expense recognized | $ | 19.8 |  | $ | 21.1 |  | $ | 40.9 |  |  | $ | 19.0 |  |  |  |  | $ | 19.0 |  |  | $ | 58.6 |  | $ | 63.0 |  | $ | 121.6 |  |  | $ | 56.5 |  |  |  | $ | 56.5 |  |
| Effective interest rate of the liability component | 5.2 | % |  | 5.4 | % |  |  |  | 5.2% |  |  |  |  |  | 5.2 | % |  | 5.4 | % |  |  |  | 5.2 | % |  |  |  |  |

[0001327567-21-000014:notes:118]
Note Hedges

[0001327567-21-000014:notes:119]
To minimize the impact of potential economic dilution upon conversion of our Notes, we entered into separate convertible note hedge transactions (the “2023 Note Hedges,” with respect to the 2023 Notes, the “2025 Note Hedges,” with respect to the 2025 Notes, and the 2023 Notes Hedges together with 2025 Note Hedges, the “Note Hedges”) with respect to our common stock concurrent with the issuance of each series of the Notes.

[0001327567-21-000014:notes:120]
The following table presents details of our Note Hedges (in millions):

[0001327567-21-000014:notes:121]
|  | Initial Number of Shares |  | Aggregate Purchase |
| 2023 Note Hedges | 6.4 |  |  | $ | 332.0 |  |
| 2025 Note Hedges | 6.7 |  |  | $ | 370.8 |  |

[0001327567-21-000014:notes:122]
The Note Hedges cover shares of our common stock at a strike price per share that corresponds to the initial applicable conversion price of the applicable series of the Notes, which are also subject to adjustment, and are exercisable upon conversion of the applicable series of the Notes. The Note Hedges will expire upon maturity of the applicable series of the Notes. The Note Hedges are separate transactions and are not part of the terms of the applicable series of the Notes. Holders of the Notes of either series will not have any rights with respect to the Note Hedges. Any shares of our common stock receivable by us under the Note Hedges are excluded from the calculation of diluted earnings per share as they are antidilutive. The aggregate amounts paid for the Note Hedges are included in additional paid-in capital in our condensed consolidated balance sheets.

[0001327567-21-000014:notes:123]
Warrants

[0001327567-21-000014:notes:124]
Separately, but concurrently with the issuance of each series of our Notes, we entered into transactions whereby we sold warrants (the “2023 Warrants,” with respect to the 2023 Notes, the “2025 Warrants,” with respect to the 2025 Notes, and the 2023 Warrants together with the 2025 Warrants, the “Warrants”) to acquire shares of our common stock, subject to anti-dilution adjustments. The 2023 Warrants and 2025 Warrants are exercisable beginning October 2023 and September 2025, respectively.

[0001327567-21-000014:notes:125]
The following table presents details of the Warrants (in millions, except per share data):

[0001327567-21-000014:notes:126]
|  | Initial Number of Shares |  | Strike Price per Share |  | Aggregate Proceeds |
| 2023 Warrants | 6.4 |  |  | $ | 417.80 |  |  | $ | 145.4 |  |
| 2025 Warrants | 6.7 |  |  | $ | 408.47 |  |  | $ | 202.8 |  |

[0001327567-21-000014:notes:127]
The shares issuable under the Warrants will be included in the calculation of diluted earnings per share when the average market value per share of our common stock for the reporting period exceeds the applicable strike price for such series of Warrants. The Warrants are separate transactions and are not part of either series of Notes or Note Hedges and are not remeasured through earnings each reporting period. Holders of the Notes of either series will not have any rights with respect to the Warrants. The aggregate proceeds received from the sale of the Warrants are included in additional paid-in capital in our condensed consolidated balance sheets.

[0001327567-21-000014:notes:128]
Revolving Credit Facility

[0001327567-21-000014:notes:129]
On September 4, 2018, we entered into a credit agreement (the “Credit Agreement”) with certain institutional lenders that provides for a $400.0 million unsecured revolving credit facility (the “Credit Facility”), with an option to increase the amount of the Credit Facility by up to an additional $350.0 million, subject to certain conditions. The Credit Facility matures on the earlier of (i) September 4, 2023 and (ii) the date that is 91 days prior to the stated maturity of our 2023 Notes if (a) any of the 2023 Notes are still outstanding and (b) our unrestricted cash and cash equivalents are less than the then outstanding principal amount of our 2023 Notes plus $400.0 million.

[0001327567-21-000014:notes:130]
The borrowings under the Credit Facility currently bear interest, at our option, at a base rate plus a spread of 0.00% to 0.75%, or an adjusted LIBO Rate plus a spread of 1.00% to 1.75%, in each case with such spread being determined based on our leverage ratio. We are obligated to pay an ongoing commitment fee on undrawn amounts at a rate of 0.125% to 0.250%, depending on our leverage ratio. Regulatory authorities that oversee financial markets have announced that after the end of 2021, they would no longer compel banks currently reporting information used to set the LIBO Rate to continue to make rate submissions. As a result, it is possible that beginning in 2022, the LIBO Rate will no longer be available as a reference rate. Under the terms of our Credit Facility, in the event of the discontinuance of the LIBO Rate, a mutually agreed-upon alternative benchmark rate will be established to replace the LIBO Rate, which may include the Secured Overnight Financing Rate (“SOFR”). We do not anticipate that the discontinuance of the LIBO Rate will materially impact our liquidity or financial position.

[0001327567-21-000014:notes:131]
As of April 30, 2021, there were no amounts outstanding and we were in compliance with all covenants under the Credit Agreement.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001327567-21-000014:notes:132]
Commitments and Contingencies
Purchase Commitments

[0001327567-21-000014:notes:133]
Manufacturing Purchase Commitments

[0001327567-21-000014:notes:134]
In order to reduce manufacturing lead times and plan for adequate supply, we enter into agreements with manufacturing partners and component suppliers to procure inventory based on our demand forecasts. We are committed to minimum or fixed purchases through the year ending July 31, 2026. The following table presents details of the aggregate future purchase commitments under these arrangements excluding obligations under contracts that we can cancel without a significant penalty as of April 30, 2021 (in millions):

[0001327567-21-000014:notes:135]
|  | Total |  | Remaining 2021 |  | 2022 |  | 2023 |  | 2024 |  | 2025 |  | 2026 and Thereafter |
| Manufacturing purchase commitments | $ | 317.5 |  |  | $ | 47.0 |  |  | $ | 135.5 |  |  | $ | 30.0 |  |  | $ | 30.0 |  |  | $ | 35.0 |  |  | $ | 40.0 |  |

[0001327567-21-000014:notes:136]
Other Purchase Commitments

[0001327567-21-000014:notes:137]
We have entered into various non-cancelable agreements with certain service providers, under which we are committed to minimum or fixed purchases through the year ending July 31, 2026. The following table presents details of the aggregate future non-cancelable purchase commitments under these agreements as of April 30, 2021 (in millions):

[0001327567-21-000014:notes:138]
|  | Total |  | Remaining 2021 |  | 2022 |  | 2023 |  | 2024 |  | 2025 |  | 2026 and Thereafter |
| Other purchase commitments | $ | 1,504.8 |  |  | $ | — |  |  | $ | 95.5 |  |  | $ | 227.2 |  |  | $ | 285.7 |  |  | $ | 345.3 |  |  | $ | 551.1 |  |

[0001327567-21-000014:notes:139]
Litigation

[0001327567-21-000014:notes:140]
We are subject to legal proceedings, claims, and litigation arising in the ordinary course of business, including intellectual property litigation. Such matters are subject to many uncertainties and outcomes are not predictable with assurance. We accrue for contingencies when we believe that a loss is probable and that we can reasonably estimate the amount of any such loss.

[0001327567-21-000014:notes:141]
To the extent there is a reasonable possibility that a loss exceeding amounts already recognized may be incurred and the amount of such additional loss would be material, we will either disclose the estimated additional loss or state that such an estimate cannot be made. As of April 30, 2021, we have not recorded any significant accruals for loss contingencies associated with such legal proceedings, determined that an unfavorable outcome is probable or reasonably possible, or determined that the amount or range of any possible loss is reasonably estimable.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001327567-21-000014:notes:142]
[same as prior period, unchanged from 0001327567-21-000004:notes:135]

[0001327567-21-000014:notes:143]
In February 2019, our board of directors authorized a $1.0 billion share repurchase program, which is funded from available working capital. In December 2020, our board of directors authorized a $700.0 million increase to our share repurchase program, bringing the total authorization to $1.7 billion. The expiration date of this repurchase authorization was extended to December 31, 2021, and our repurchase program may be suspended or discontinued at any time. Repurchases under our program are to be made at management’s discretion from time to time on the open market, through privately negotiated transactions, transactions structured through investment banking institutions, block purchase techniques, 10b5-1 trading plans, or a combination of the foregoing.

[0001327567-21-000014:notes:144]
During the three months ended April 30, 2021, we repurchased and retired 1.0 million shares of our common stock under our current repurchase authorization for an aggregate purchase price of $350.0 million, including transaction costs, at an average price of $321.97 per share. During the nine months ended April 30, 2021, we repurchased and retired 3.1 million shares of our common stock under our current repurchase authorization for an aggregate purchase price of $850.0 million, including transaction costs, at an average price of $269.89 per share. The total price of the shares repurchased and related transaction costs were reflected as a reduction to common stock and additional paid-in capital on our condensed consolidated balance sheets. As of April 30, 2021, $651.9 million remained available for future share repurchases under our current repurchase authorization.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001327567-21-000014:notes:145]
[same as prior period, unchanged from 0001327567-21-000004:notes:138]

[0001327567-21-000014:notes:146]
In connection with our acquisition of Bridgecrew in March 2021, we assumed the Bridgecrew, Inc. 2019 Stock Incentive Plan (the “Bridgecrew Plan”), under which the assumed Bridgecrew equity awards were granted. In connection with our acquisition of Expanse in December 2020, we assumed the Expanse Holding Company, Inc. Amended and Restated 2012 Stock Incentive Plan (the “Expanse Plan”), under which the assumed Expanse equity awards were granted. In connection with our acquisition of Sinefa in November 2020, we assumed the Sinefa Group, Inc. 2020 Stock Plan (the “Sinefa Plan”), under which the assumed Sinefa equity awards were granted. In connection with our acquisition of Crypsis in September 2020, we assumed the Crypsis Group Holdings, LLC 2017 Equity Incentive Plan (the “Crypsis Group Plan”), under which the assumed Crypsis equity awards were granted. In aggregate, the assumed plans are referenced as “the Assumed Plans.”

[0001327567-21-000014:notes:147]
The assumed equity awards will be settled in shares of our common stock and will retain the terms and conditions under which they were originally granted; forfeited awards will not be returned to the Assumed Plans. No additional equity awards will be granted under the Assumed Plans. Refer to Note 7. Acquisitions for more information on our acquisitions and the related equity awards assumed.

[0001327567-21-000014:notes:148]
[same as prior period, unchanged from 0001327567-21-000004:notes:145]

[0001327567-21-000014:notes:149]
We have granted PSOs with both a market condition and a service condition to certain executives. The market condition for PSOs granted in the fiscal years 2018 and 2019 requires the price of our common stock to equal or exceed $297.75, $397.00, $496.25, and $595.50 based on the average closing price for 30 consecutive trading days during the four-, five-, six-, and seven-and-a-half-year periods following the date of grant in fiscal year 2018 and 2019, respectively. The market condition for PSOs granted in the nine months ended April 30, 2021 requires the price of our common stock to equal or exceed $397.00, $496.25, $595.50 and $700.00 based on the average closing price for 30 consecutive trading days during the three-, four-, five-, and six-and-a-half-year periods following

[0001327567-21-000014:notes:150]
the date of grant. To the extent that the market condition has been met, one-fourth of the PSOs will vest on the anniversary date of the grant date for such PSOs, subject to continued service. Certain outstanding PSOs may be exercised prior to vesting (“early exercise”). Shares of common stock issued upon early exercise of the PSOs will be restricted and, at our option, subject to repurchase if the option holder ceases to be a service provider. The maximum contractual term of our PSOs ranged from six and a half years to seven and a half years from the date of grant, depending on vesting period. During the nine months ended April 30, 2021, 0.3 million shares of our PSOs vested as the first stock price target for our PSOs granted in fiscal years 2018 and 2019 was satisfied and the service condition was met.

[0001327567-21-000014:notes:151]
[same as prior period, unchanged from 0001327567-21-000004:notes:147]

[0001327567-21-000014:notes:152]
|  |  |  | PSOs Outstanding |
|  |  |  |  |  |  |  |  |  | Number of Shares |  | Weighted-Average Exercise Price Per Share |  | Weighted-Average Remaining Contractual Term(Years) |  | Aggregate Intrinsic Value |
| Balance—July 31, 2020 |  |  |  |  |  |  |  |  | 2.8 |  |  | $ | 194.14 |  |  | 5.2 |  | $ | 170.9 |  |
| Granted |  |  |  |  |  |  |  |  | 0.2 |  |  | $ | 304.29 |  |  |  |  |  |
| Forfeited |  |  |  |  |  |  |  |  | (0.2) |  |  | $ | 304.29 |  |  |  |  |  |
| Balance—April 30, 2021 |  |  |  |  |  |  |  |  | 2.8 |  |  | $ | 194.14 |  |  | 4.4 |  | $ | 440.5 |  |
| Exercisable—April 30, 2021 |  |  |  |  |  |  |  |  | 2.8 |  |  | $ | 194.14 |  |  | 4.4 |  | $ | 440.5 |  |

[0001327567-21-000014:notes:153]
[same as prior period, unchanged from 0001327567-21-000004:notes:149]

[0001327567-21-000014:notes:154]
[same as prior period, unchanged from 0001327567-21-000004:notes:150]

[0001327567-21-000014:notes:155]
|  | RSUs Outstanding |  | PSUs Outstanding |
|  | Number of Shares |  | Weighted-Average Grant-Date Fair Value Per Share |  |  |  | Aggregate Intrinsic Value |  | Number of Shares |  | Weighted-Average Grant-Date Fair Value Per Share |  |  |  | Aggregate Intrinsic Value |
| Balance—July 31, 2020 | 6.6 |  |  | $ | 203.30 |  |  |  |  | $ | 1,688.1 |  |  | 0.6 |  |  | $ | 231.42 |  |  |  |  | $ | 147.2 |  |
| Granted | 3.6 |  |  | $ | 288.90 |  |  |  |  |  |  | 0.4 |  |  | $ | 255.43 |  |  |  |  |  |
| Vested | (2.2) |  |  | $ | 197.44 |  |  |  |  |  |  | (0.1) |  |  | $ | 199.27 |  |  |  |  |  |
| Forfeited | (0.6) |  |  | $ | 218.33 |  |  |  |  |  |  | 0.0 |  |  | $ | 232.85 |  |  |  |  |  |
| Balance—April 30, 2021 | 7.4 |  |  | $ | 246.00 |  |  |  |  | $ | 2,622.8 |  |  | 0.9 |  |  | $ | 245.62 |  |  |  |  | $ | 314.1 |  |

[0001327567-21-000014:notes:156]
[same as prior period, unchanged from 0001327567-21-000004:notes:152]

[0001327567-21-000014:notes:157]
[same as prior period, unchanged from 0001327567-21-000004:notes:153]

[0001327567-21-000014:notes:158]
[same as prior period, unchanged from 0001327567-21-000004:notes:154]

[0001327567-21-000014:notes:159]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 30, |  | April 30, |
|  | 2021 |  | 2020 |  | 2021 |  | 2020 |
| Cost of product revenue | $ | 1.6 |  |  | $ | 1.4 |  |  | $ | 4.7 |  |  | $ | 4.2 |  |
| Cost of subscription and support revenue | 23.3 |  |  | 18.8 |  |  | 69.3 |  |  | 57.6 |  |
| Research and development | 118.2 |  |  | 67.7 |  |  | 317.2 |  |  | 197.4 |  |
| Sales and marketing | 69.2 |  |  | 55.5 |  |  | 203.8 |  |  | 155.0 |  |
| General and administrative | 30.6 |  |  | 22.7 |  |  | 101.9 |  |  | 76.0 |  |
| Total share-based compensation | $ | 242.9 |  |  | $ | 166.1 |  |  | $ | 696.9 |  |  | $ | 490.2 |  |

[0001327567-21-000014:notes:160]
During the three and nine months ended April 30, 2021, we accelerated the vesting of certain equity awards in connection with our acquisitions; as a result, we recorded $9.8 million and $32.4 million, respectively, of share-based compensation within general and administrative expense in our condensed consolidated statements of operations.
As of April 30, 2021, total compensation cost related to unvested share-based awards not yet recognized was $2.0 billion. This cost is expected to be amortized over a weighted-average period of approximately 2.7 years.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001327567-21-000014:notes:161]
Income Taxes
For the three and nine months ended April 30, 2021, our provision for income taxes reflects an effective tax rate of 3.5% and negative 4.7%, respectively. Our taxes are primarily due to foreign income tax and withholding tax that are partially offset by tax benefits as a result of our acquisitions and acquisition-related activities. Our effective tax rates differ from the U.S. statutory tax rate primarily due to changes in our valuation allowance.

[0001327567-21-000014:notes:162]
Our provision for income taxes for the three and nine months ended April 30, 2020 reflects an effective tax rate of negative 10.3% and negative 13.5%, respectively. Our effective tax rate for the nine months ended April 30, 2020 was negative as we recorded a provision for income taxes on year-to-date losses. The provision for income taxes for the nine months ended April 30, 2020 was primarily due to income taxes in profitable foreign jurisdictions, U.S. state taxes, and withholding taxes. Our effective tax rates differ from the U.S. statutory tax rate primarily due to deductibility of our share-based compensation, foreign income at other than U.S. tax rates, and changes in our valuation allowance.


## us-gaap:EarningsPerShareTextBlock

[0001327567-21-000014:notes:163]
[same as prior period, unchanged from 0001327567-21-000004:notes:159]

[0001327567-21-000014:notes:164]
[same as prior period, unchanged from 0001327567-21-000004:notes:160]

[0001327567-21-000014:notes:165]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 30, |  | April 30, |
|  | 2021 |  | 2020 |  | 2021 |  | 2020 |
| Net loss | $ | (145.1) |  |  | $ | (74.8) |  |  | $ | (379.6) |  |  | $ | (208.1) |  |
| Weighted-average shares used to compute net loss per share, basic and diluted | 96.9 |  |  | 96.7 |  |  | 96.1 |  |  | 97.2 |  |
| Net loss per share, basic and diluted | $ | (1.50) |  |  | $ | (0.77) |  |  | $ | (3.95) |  |  | $ | (2.14) |  |

[0001327567-21-000014:notes:166]
[same as prior period, unchanged from 0001327567-21-000004:notes:162]

[0001327567-21-000014:notes:167]
|  | Three and Nine Months Ended |
|  | April 30, |
|  | 2021 |  | 2020 |
| Convertible senior notes | 13.1 |  |  | 6.4 |  |
| Warrants related to the issuance of convertible senior notes | 13.1 |  |  | 6.4 |  |
| RSUs and PSUs | 8.3 |  |  | 7.3 |  |
| Options to purchase common stock, including PSOs | 2.8 |  |  | 3.1 |  |
| Restricted stock awards and performance-based stock awards | 0.4 |  |  | 0.1 |  |
| ESPP shares | 0.1 |  |  | 0.1 |  |
| Total | 37.8 |  |  | 23.4 |  |


## us-gaap:OtherNonoperatingIncomeAndExpenseTextBlock

[0001327567-21-000014:notes:168]
Other Income, Net
The following table sets forth the components of other income, net (in millions):

[0001327567-21-000014:notes:169]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 30, |  | April 30, |
|  | 2021 |  | 2020 |  | 2021 |  | 2020 |
| Interest income | $ | 1.8 |  |  | $ | 8.3 |  |  | $ | 7.0 |  |  | $ | 38.0 |  |
| Foreign currency exchange losses, net | (0.9) |  |  | 0.2 |  |  | (2.5) |  |  | (1.8) |  |
| Other | 0.1 |  |  | (0.4) |  |  | (1.6) |  |  | (1.1) |  |
| Total other income, net | $ | 1.0 |  |  | $ | 8.1 |  |  | $ | 2.9 |  |  | $ | 35.1 |  |
