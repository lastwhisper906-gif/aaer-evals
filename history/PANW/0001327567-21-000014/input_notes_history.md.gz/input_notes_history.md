# PANW note change history — 0001327567-21-000004 → 0001327567-21-000014


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- added (2021-05-21):
[0001327567-21-000014:note_history:1]
In order to reduce manufacturing lead times and plan for adequate supply, we enter into agreements with manufacturing partners and component suppliers to procure inventory based on our demand forecasts. We are committed to minimum or fixed purchases through the year ending July 31, 2026. The following table presents details of the aggregate future purchase commitments under these arrangements excluding obligations under contracts that we can cancel without a significant penalty as of April 30, 2021 (in millions):

- added (2021-05-21):
[0001327567-21-000014:note_history:2]
|  | Total |  | Remaining 2021 |  | 2022 |  | 2023 |  | 2024 |  | 2025 |  | 2026 and Thereafter |
| Manufacturing purchase commitments | $ | 317.5 |  |  | $ | 47.0 |  |  | $ | 135.5 |  |  | $ | 30.0 |  |  | $ | 30.0 |  |  | $ | 35.0 |  |  | $ | 40.0 |  |

- changed (2021-05-21):
[0001327567-21-000014:note_history:3]
We have entered into various non-cancelable agreements with certain service providers, under which we are committed to minimum or fixed purchases through the year ending July 31, 2026. The following table presents details of the aggregate future non-cancelable purchase commitments under these agreements as of April 30, 2021 (in millions):
  (was, 2021-02-23, similarity 0.9818):
[0001327567-21-000004:note_history:3]
We have entered into various non-cancelable agreements with certain service providers, under which we are committed to minimum or fixed purchases through the year ending July 31, 2026. The following table presents details of the aggregate future non-cancelable purchase commitments under these agreements as of January 31, 2021 (in millions):

- added (2021-05-21):
[0001327567-21-000014:note_history:4]
|  | Total |  | Remaining 2021 |  | 2022 |  | 2023 |  | 2024 |  | 2025 |  | 2026 and Thereafter |
| Other purchase commitments | $ | 1,504.8 |  |  | $ | — |  |  | $ | 95.5 |  |  | $ | 227.2 |  |  | $ | 285.7 |  |  | $ | 345.3 |  |  | $ | 551.1 |  |

- added (2021-05-21):
[0001327567-21-000014:note_history:5]
To the extent there is a reasonable possibility that a loss exceeding amounts already recognized may be incurred and the amount of such additional loss would be material, we will either disclose the estimated additional loss or state that such an estimate cannot be made. As of April 30, 2021, we have not recorded any significant accruals for loss contingencies associated with such legal proceedings, determined that an unfavorable outcome is probable or reasonably possible, or determined that the amount or range of any possible loss is reasonably estimable.

- removed (2021-05-21):
[0001327567-21-000004:note_history:6]
Our electronics manufacturing service provider (“EMS provider”) procures components and assembles our products based on our forecasts. These forecasts are based on estimates of demand for our products primarily for the next 12 months, which are in turn based on historical trends and an analysis from our sales and product management organizations, adjusted for overall market conditions. In order to reduce manufacturing lead times and plan for adequate supply, we may issue non-cancelable orders for products and components to our manufacturing partners or component suppliers. As of January 31, 2021, our purchase commitments under such orders were $157.7 million excluding obligations under contracts that we can cancel without a significant penalty.

- removed (2021-05-21):
[0001327567-21-000004:note_history:7]
|  | Amount |
| Fiscal years ending July 31: |  |
| Remaining 2021 | $ | — |  |
| 2022 | 134.3 |  |
| 2023 | 227.2 |  |
| 2024 | 285.7 |  |
| 2025 | 345.3 |  |
| 2026 and thereafter | 551.1 |  |
| Total other purchase commitments | $ | 1,543.6 |  |

- removed (2021-05-21):
[0001327567-21-000004:note_history:8]
To the extent there is a reasonable possibility that a loss exceeding amounts already recognized may be incurred and the amount of such additional loss would be material, we will either disclose the estimated additional loss or state that such an estimate cannot be made. As of January 31, 2021, we have not recorded any significant accruals for loss contingencies associated with such legal proceedings, determined that an unfavorable outcome is probable or reasonably possible, or determined that the amount or range of any possible loss is reasonably estimable.


## us-gaap:OrganizationConsolidationBasisOfPresentationBusinessDescriptionAndAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2021-05-21):
[0001327567-21-000014:note_history:9]
Palo Alto Networks, Inc. (the “Company,” “we,” “us,” or “our”), located in Santa Clara, California, was incorporated in March 2005 under the laws of the State of Delaware and commenced operations in April 2005. We empower enterprises, service providers, and government entities to secure all users, applications, data, networks, clouds and devices with comprehensive visibility and context continuously across all locations.
  (was, 2021-02-23, similarity 0.8684):
[0001327567-21-000004:note_history:9]
Palo Alto Networks, Inc. (the “Company,” “we,” “us,” or “our”), located in Santa Clara, California, was incorporated in March 2005 under the laws of the State of Delaware and commenced operations in April 2005. We empower enterprises, service providers, and government entities to secure all users, applications, data, networks, and devices with comprehensive context at all times, across all locations.

- changed (2021-05-21):
[0001327567-21-000014:note_history:10]
The preparation of condensed consolidated financial statements in conformity with GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities and disclosure of contingent assets and liabilities at the date of the condensed consolidated financial statements and the reported amounts of revenues and expenses during the reporting period. We base our estimates on historical experience and also on assumptions that we believe are reasonable. Actual results could differ materially from those estimates due to risks and uncertainties, including uncertainty in the current economic environment due to COVID-19.
  (was, 2021-02-23, similarity 0.9924):
[0001327567-21-000004:note_history:10]
The preparation of condensed consolidated financial statements in conformity with GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities and disclosure of contingent assets and liabilities at the date of the consolidated financial statements and the reported amounts of revenues and expenses during the reporting period. We base our estimates on historical experience and also on assumptions that we believe are reasonable. Actual results could differ materially from those estimates due to risks and uncertainties, including uncertainty in the current economic environment due to COVID-19.

- changed (2021-05-21):
[0001327567-21-000014:note_history:11]
There have been no material changes to our significant accounting policies as of and for the nine months ended April 30, 2021, as compared to the significant accounting policies described in our Annual Report on Form 10-K for the fiscal year ended July 31, 2020, except for the change in our accounting policies for credit losses due to our adoption of the new credit losses guidance. Refer to “Recently Adopted Accounting Pronouncements” below.
  (was, 2021-02-23, similarity 0.978):
[0001327567-21-000004:note_history:11]
There have been no material changes to our significant accounting policies as of and for the six months ended January 31, 2021, as compared to the significant accounting policies described in our Annual Report on Form 10-K for the fiscal year ended July 31, 2020, except for the change in our accounting policies for credit losses due to our adoption of the new credit losses guidance. Refer to “Recently Adopted Accounting Pronouncements” below.

- changed (2021-05-21):
[0001327567-21-000014:note_history:12]
recorded in other income, net in our condensed consolidated statements of operations. Impairment losses that are not credit-related are included in accumulated other comprehensive income (loss) (“AOCI”) in stockholders’ equity.
  (was, 2021-02-23, similarity 0.9784):
[0001327567-21-000004:note_history:12]
recorded in other income (expense), net in our condensed consolidated statements of operations. Impairment losses that are not credit-related are included in accumulated other comprehensive income (loss) (“AOCI”) in stockholders’ equity.

- changed (2021-05-21):
[0001327567-21-000014:note_history:13]
Trade accounts receivable are recorded at the invoiced amount, net of allowances for credit losses for any potential uncollectible amounts. The allowance for credit losses is based on our assessment of the collectability of accounts. Management regularly reviews the adequacy of the allowance for credit losses on a collective basis by considering the age of each outstanding invoice, each customer’s expected ability to pay and collection history, current market conditions, and reasonable and supportable forecasts of future economic conditions to determine whether the allowance is appropriate. Accounts receivable deemed uncollectible are charged against the allowance for credit losses when identified. For the three and nine months ended April 30, 2021 and 2020, the allowance for credit losses activity was not significant.
  (was, 2021-02-23, similarity 0.9714):
[0001327567-21-000004:note_history:13]
Trade accounts receivable are recorded at the invoiced amount, net of allowances for credit losses for any potential uncollectible amounts. The allowance for credit losses is based on our assessment of the collectability of accounts. Management regularly reviews the adequacy of the allowance for credit losses on a collective basis by considering the age of each outstanding invoice, each customer’s expected ability to pay and collection history, current market conditions, and reasonable and supportable forecasts of future economic conditions to determine whether the allowance is appropriate. Accounts receivable deemed uncollectible are charged against the allowance for credit losses when identified. For the three and six months ended January 31, 2021 and 2020, the allowance for credit losses activity was not significant.

- changed (2021-05-21):
[0001327567-21-000014:note_history:14]
We provide financing arrangements, primarily loans, for certain qualified end-user customers to purchase our products and services. Payment terms on these financing arrangements are up to five years. We evaluate our allowance for credit losses by assessing the risks and losses inherent in our financing receivables on either an individual or a collective basis. Our assessment considers various factors, including lifetime expected losses determined using customer risk profile, current economic conditions that may affect a customer’s ability to pay, and forward-looking economic considerations. Financing receivables are written off when they are considered uncollectible, and related outstanding balances are reversed and charged against the allowance for credit losses. Short-term financing receivables are included in prepaid expenses and other current assets, and long-term financing receivables are included in other assets on our condensed consolidated balance sheets. Refer to Note 5. Financing Receivables for additional information.
  (was, 2021-02-23, similarity 0.9862):
[0001327567-21-000004:note_history:14]
We provide financing arrangements, primarily loans, for certain qualified end-user customers to purchase our products and services. Payment terms on these financing arrangements are generally up to three years. We evaluate our allowance for credit losses by assessing the risks and losses inherent in our financing receivables on either an individual or a collective basis. Our assessment considers various factors, including lifetime expected losses determined using customer risk profile, current economic conditions that may affect a customer’s ability to pay, and forward-looking economic considerations. Financing receivables are written off when they are considered uncollectible, and related outstanding balances are reversed and charged against the allowance for credit losses. Short-term financing receivables are included in prepaid expenses and other current assets, and long-term financing receivables are included in other assets on our condensed consolidated balance sheets. Refer to Note 5. Financing Receivables for additional information.


## us-gaap:ConvertibleDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2021-05-21):
[0001327567-21-000014:note_history:15]
The following table sets forth the components of the Notes as of April 30, 2021 and July 31, 2020 (in millions):
  (was, 2021-02-23, similarity 0.9612):
[0001327567-21-000004:note_history:15]
The following table sets forth the components of the Notes as of January 31, 2021 and July 31, 2020 (in millions):

- changed (2021-05-21):
[0001327567-21-000014:note_history:16]
|  | April 30, 2021 | July 31, 2020 |
|  | 2023 Notes |  | 2025 Notes |  | Total |  | 2023 Notes |  | 2025 Notes |  | Total |
| Liability component: |  |  |  |  |  |  |  |  |  |  |  |
| Principal | $ | 1,693.0 |  |  | $ | 2,000.0 |  |  | $ | 3,693.0 |  |  | $ | 1,693.0 |  |  | $ | 2,000.0 |  |  | $ | 3,693.0 |  |
| Less: debt discount and debt issuance costs, net of amortization | 150.9 |  |  | 351.5 |  |  | 502.4 |  |  | 200.0 |  |  | 408.9 |  |  | 608.9 |  |
| Net carrying amount | $ | 1,542.1 |  |  | $ | 1,648.5 |  |  | $ | 3,190.6 |  |  | $ | 1,493.0 |  |  | $ | 1,591.1 |  |  | $ | 3,084.1 |  |
| Equity component | $ | 315.0 |  |  | $ | 403.0 |  |  | $ | 718.0 |  |  | $ | 315.0 |  |  | $ | 403.0 |  |  | $ | 718.0 |  |
  (was, 2021-02-23, similarity 0.8148):
[0001327567-21-000004:note_history:16]
|  | January 31, 2021 | July 31, 2020 |
|  | 2023 Notes |  | 2025 Notes |  | Total |  | 2023 Notes |  | 2025 Notes |  | Total |
| Liability component: |  |  |  |  |  |  |  |  |  |  |  |
| Principal | $ | 1,693.0 |  |  | $ | 2,000.0 |  |  | $ | 3,693.0 |  |  | $ | 1,693.0 |  |  | $ | 2,000.0 |  |  | $ | 3,693.0 |  |
| Less: debt discount and debt issuance costs, net of amortization | 167.4 |  |  | 370.9 |  |  | 538.3 |  |  | 200.0 |  |  | 408.9 |  |  | 608.9 |  |
| Net carrying amount | $ | 1,525.6 |  |  | $ | 1,629.1 |  |  | $ | 3,154.7 |  |  | $ | 1,493.0 |  |  | $ | 1,591.1 |  |  | $ | 3,084.1 |  |
| Equity component (including amounts classified as temporary equity) | $ | 315.0 |  |  | $ | 403.0 |  |  | $ | 718.0 |  |  | $ | 315.0 |  |  | $ | 403.0 |  |  | $ | 718.0 |  |


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2021-05-21):
[0001327567-21-000014:note_history:17]
In July 2018, we issued $1.7 billion aggregate principal amount of 0.75% Convertible Senior Notes due 2023 (the “2023 Notes”) and in June 2020, we issued $2.0 billion aggregate principal amount of 0.375% Convertible Senior Notes due 2025 (the “2025 Notes,” and together with the 2023 Notes, the “Notes”). The 2023 Notes bear interest at a fixed rate of 0.75% per year, payable semi-annually in arrears on January 1 and July 1 of each year, beginning on January 1, 2019. The 2025 Notes bear interest at a fixed rate of 0.375% per year, payable semi-annually in arrears on June 1 and December 1 of each year, beginning on December 1, 2020. Each series of the convertible notes is governed by an indenture between us, as the issuer, and U.S. Bank National Association, as Trustee (individually, each an “Indenture,” and together, the “Indentures”). The Notes of each series are unsecured, unsubordinated obligations and the applicable Indenture governing each series of Notes does not contain any financial covenants or restrictions on the payments of dividends, the incurrence of indebtedness, or the issuance or repurchase of securities by us or any of our subsidiaries. The 2023 Notes and the 2025 Notes mature on July 1, 2023 and June 1, 2025, respectively. We cannot redeem the 2023 Notes prior to maturity. We may redeem for cash all or any portion of the 2025 Notes, at our option, on or after June 5, 2023, and prior to the 31st scheduled trading day immediately preceding the maturity date if the last reported sale price of our common stock has been at least 130% of the conversion price then in effect for at least 20 trading days during any 30 consecutive trading day period ending on and including the trading day preceding the date on which we provide notice of redemption. The redemption will be at a price equal to 100% of the principal amount of the 2025 Notes and adjusted for interest. If we call any or all of the 2025 Notes for redemption, holders may convert such 2025 Notes called for redemption at any time prior to the close of business on the second scheduled trading day immediately preceding the redemption date.
  (was, 2021-02-23, similarity 0.7074):
[0001327567-21-000004:note_history:17]
In July 2018, we issued $1.7 billion aggregate principal amount of 0.75% Convertible Senior Notes due 2023 (the “2023 Notes”) and, in June 2020, we issued $2.0 billion aggregate principal amount of 0.375% Convertible Senior Notes due 2025 (the “2025 Notes,” and together with the 2023 Notes, the “Notes”). The 2023 Notes bear interest at a fixed rate of 0.75% per year, payable semi-annually in arrears on January 1 and July 1 of each year, beginning on January 1, 2019. The 2025 Notes bear interest at a fixed rate of 0.375% per year, payable semi-annually in arrears on June 1 and December 1 of each year, beginning on December 1, 2020. Each series of the convertible notes is governed by an indenture between us, as the issuer, and U.S. Bank National Association, as Trustee (individually, each an “Indenture,” and together, the “Indentures”). The Notes of each series are unsecured, unsubordinated obligations and the applicable Indenture governing each series of Notes does not contain any financial covenants or restrictions on the payments of dividends, the incurrence of indebtedness, or the issuance or repurchase of securities by us or any of our subsidiaries. The

- added (2021-05-21):
[0001327567-21-000014:note_history:18]
The sale price condition was not met for the Notes during the fiscal quarters ended April 30, 2021 and July 31, 2020. Since the Notes were not convertible, the net carrying amount of the Notes was classified as a long-term liability and the equity component was

- added (2021-05-21):
[0001327567-21-000014:note_history:19]
included in additional paid-in capital in our condensed consolidated balance sheets in the periods presented. As of April 30, 2021, all of the Notes remained outstanding.

- changed (2021-05-21):
[0001327567-21-000014:note_history:20]
The following table sets forth the components of the Notes as of April 30, 2021 and July 31, 2020 (in millions):
  (was, 2021-02-23, similarity 0.9612):
[0001327567-21-000004:note_history:20]
The following table sets forth the components of the Notes as of January 31, 2021 and July 31, 2020 (in millions):

- changed (2021-05-21):
[0001327567-21-000014:note_history:21]
|  | April 30, 2021 | July 31, 2020 |
|  | 2023 Notes |  | 2025 Notes |  | Total |  | 2023 Notes |  | 2025 Notes |  | Total |
| Liability component: |  |  |  |  |  |  |  |  |  |  |  |
| Principal | $ | 1,693.0 |  |  | $ | 2,000.0 |  |  | $ | 3,693.0 |  |  | $ | 1,693.0 |  |  | $ | 2,000.0 |  |  | $ | 3,693.0 |  |
| Less: debt discount and debt issuance costs, net of amortization | 150.9 |  |  | 351.5 |  |  | 502.4 |  |  | 200.0 |  |  | 408.9 |  |  | 608.9 |  |
| Net carrying amount | $ | 1,542.1 |  |  | $ | 1,648.5 |  |  | $ | 3,190.6 |  |  | $ | 1,493.0 |  |  | $ | 1,591.1 |  |  | $ | 3,084.1 |  |
| Equity component | $ | 315.0 |  |  | $ | 403.0 |  |  | $ | 718.0 |  |  | $ | 315.0 |  |  | $ | 403.0 |  |  | $ | 718.0 |  |
  (was, 2021-02-23, similarity 0.8148):
[0001327567-21-000004:note_history:21]
|  | January 31, 2021 | July 31, 2020 |
|  | 2023 Notes |  | 2025 Notes |  | Total |  | 2023 Notes |  | 2025 Notes |  | Total |
| Liability component: |  |  |  |  |  |  |  |  |  |  |  |
| Principal | $ | 1,693.0 |  |  | $ | 2,000.0 |  |  | $ | 3,693.0 |  |  | $ | 1,693.0 |  |  | $ | 2,000.0 |  |  | $ | 3,693.0 |  |
| Less: debt discount and debt issuance costs, net of amortization | 167.4 |  |  | 370.9 |  |  | 538.3 |  |  | 200.0 |  |  | 408.9 |  |  | 608.9 |  |
| Net carrying amount | $ | 1,525.6 |  |  | $ | 1,629.1 |  |  | $ | 3,154.7 |  |  | $ | 1,493.0 |  |  | $ | 1,591.1 |  |  | $ | 3,084.1 |  |
| Equity component (including amounts classified as temporary equity) | $ | 315.0 |  |  | $ | 403.0 |  |  | $ | 718.0 |  |  | $ | 315.0 |  |  | $ | 403.0 |  |  | $ | 718.0 |  |

- changed (2021-05-21):
[0001327567-21-000014:note_history:22]
The total estimated fair value of the Notes was $5.0 billion and $4.1 billion at April 30, 2021 and July 31, 2020, respectively. The fair value was determined based on the closing trading price per $100 of the Notes as of the last day of trading for the period. We consider the fair value of the Notes at April 30, 2021 and July 31, 2020 to be a Level 2 measurement. The fair value of the Notes is primarily affected by the trading price of our common stock and market interest rates. Based on the closing price of our common stock on April 30, 2021, the if-converted values of the 2023 Notes and 2025 Notes exceeded their principal amounts by $488.4 million and $305.7 million, respectively.
  (was, 2021-02-23, similarity 0.9444):
[0001327567-21-000004:note_history:22]
The total estimated fair value of the Notes was $5.0 billion and $4.1 billion at January 31, 2021 and July 31, 2020, respectively. The fair value was determined based on the closing trading price per $100 of the Notes as of the last day of trading for the period. We consider the fair value of the Notes at January 31, 2021 and July 31, 2020 to be a Level 2 measurement. The fair value of the Notes is primarily affected by the trading price of our common stock and market interest rates. Based on the closing price of our common stock on January 31, 2021, the if-converted values of the 2023 Notes and 2025 Notes exceeded their principal amounts by $575.4 million and $398.1 million, respectively.

- changed (2021-05-21):
[0001327567-21-000014:note_history:23]
|  | Three Months Ended April 30, |  | Nine Months Ended April 30, |
|  | 2021 |  | 2020 |  | 2021 |  | 2020 |
|  | 2023 Notes |  | 2025 Notes |  | Total |  | 2023 Notes |  |  |  | Total |  | 2023 Notes |  | 2025 Notes |  | Total |  | 2023 Notes |  |  |  | Total |
| Contractual interest expense | $ | 3.2 |  | $ | 1.8 |  | $ | 5.0 |  |  | $ | 3.2 |  |  |  |  | $ | 3.2 |  |  | $ | 9.5 |  | $ | 5.6 |  | $ | 15.1 |  |  | $ | 9.5 |  |  |  | $ | 9.5 |  |
| Amortization of debt discount | 16.0 |  | 18.6 |  | 34.6 |  |  | 15.3 |  |  |  |  | 15.3 |  |  | 47.4 |  | 55.3 |  | 102.7 |  |  | 45.5 |  |  |  | 45.5 |  |
| Amortization of debt issuance costs | 0.6 |  | 0.7 |  | 1.3 |  |  | 0.5 |  |  |  |  | 0.5 |  |  | 1.7 |  | 2.1 |  | 3.8 |  |  | 1.5 |  |  |  | 1.5 |  |
| Total interest expense recognized | $ | 19.8 |  | $ | 21.1 |  | $ | 40.9 |  |  | $ | 19.0 |  |  |  |  | $ | 19.0 |  |  | $ | 58.6 |  | $ | 63.0 |  | $ | 121.6 |  |  | $ | 56.5 |  |  |  | $ | 56.5 |  |
| Effective interest rate of the liability component | 5.2 | % |  | 5.4 | % |  |  |  | 5.2% |  |  |  |  |  | 5.2 | % |  | 5.4 | % |  |  |  | 5.2 | % |  |  |  |  |
  (was, 2021-02-23, similarity 0.965):
[0001327567-21-000004:note_history:23]
|  | Three Months Ended January 31, |  | Six Months Ended January 31, |
|  | 2021 |  | 2020 |  | 2021 |  | 2020 |
|  | 2023 Notes |  | 2025 Notes |  | Total |  | 2023 Notes |  |  |  | Total |  | 2023 Notes |  | 2025 Notes |  | Total |  | 2023 Notes |  |  |  | Total |
| Contractual interest expense | $ | 3.1 |  | $ | 1.9 |  | $ | 5.0 |  |  | $3.1 |  |  |  | $ | 3.1 |  |  | $ | 6.3 |  | $ | 3.8 |  | $ | 10.1 |  |  | $ | 6.3 |  |  |  | $ | 6.3 |  |
| Amortization of debt discount | 15.7 |  | 18.5 |  | 34.2 |  |  | 15.2 |  |  |  | 15.2 |  |  | 31.4 |  | 36.7 |  | 68.1 |  |  | 30.2 |  |  |  | 30.2 |  |
| Amortization of debt issuance costs | 0.6 |  | 0.7 |  | 1.3 |  |  | 0.5 |  |  |  | 0.5 |  |  | 1.1 |  | 1.4 |  | 2.5 |  |  | 1.0 |  |  |  | 1.0 |  |
| Total interest expense recognized | $ | 19.4 |  | $ | 21.1 |  | $ | 40.5 |  |  | $ | 18.8 |  |  |  | $ | 18.8 |  |  | $ | 38.8 |  | $ | 41.9 |  | $ | 80.7 |  |  | $ | 37.5 |  |  |  | $ | 37.5 |  |
| Effective interest rate of the liability component | 5.2 | % |  | 5.4 | % |  |  |  | 5.2 | % |  |  |  |  |  | 5.2 | % |  | 5.4 | % |  |  |  | 5.2 | % |  |  |  |  |

- changed (2021-05-21):
[0001327567-21-000014:note_history:24]
As of April 30, 2021, there were no amounts outstanding and we were in compliance with all covenants under the Credit Agreement.
  (was, 2021-02-23, similarity 0.9675):
[0001327567-21-000004:note_history:24]
As of January 31, 2021, there were no amounts outstanding and we were in compliance with all covenants under the Credit Agreement.

- removed (2021-05-21):
[0001327567-21-000004:note_history:25]
2023 Notes and the 2025 Notes mature on July 1, 2023 and June 1, 2025, respectively. We cannot redeem the 2023 Notes prior to maturity. We may redeem for cash all or any portion of the 2025 Notes, at our option, on or after June 5, 2023, and prior to the 31st scheduled trading day immediately preceding the maturity date if the last reported sale price of our common stock has been at least 130% of the conversion price then in effect for at least 20 trading days during any 30 consecutive trading day period ending on and including the trading day preceding the date on which we provide notice of redemption. The redemption will be at a price equal to 100% of the principal amount of the 2025 Notes and adjusted for interest. If we call any or all of the 2025 Notes for redemption, holders may convert such 2025 Notes called for redemption at any time prior to the close of business on the second scheduled trading day immediately preceding the redemption date.

- removed (2021-05-21):
[0001327567-21-000004:note_history:26]
The sale price condition was met for the 2023 Notes during the fiscal quarter ended January 31, 2021, and as a result, holders may convert their 2023 Notes at any time during the fiscal quarter ending April 30, 2021. Accordingly, the net carrying amount of the 2023 Notes was reclassified into current liabilities and the portion of the equity component representing the conversion option was reclassified into temporary equity in our condensed consolidated balance sheet as of January 31, 2021. The portion of the equity component classified as temporary equity is measured as the difference between the principal and net carrying amount of the 2023 Notes, excluding debt issuance costs.

- removed (2021-05-21):
[0001327567-21-000004:note_history:27]
The sale price condition was not met for the 2025 Notes during the fiscal quarters ended January 31, 2021 and July 31, 2020 and was not met for the 2023 Notes during the fiscal quarter ended July 31, 2020. Since the 2025 Notes for both periods and the 2023 Notes as of July 31, 2020 were not convertible, the associated net carrying amount was classified as a long-term liability and the equity component was included in additional paid-in capital in our condensed consolidated balance sheets.

- removed (2021-05-21):
[0001327567-21-000004:note_history:28]
As of January 31, 2021, all of the Notes remained outstanding.


## us-gaap:DebtSecuritiesAvailableForSaleTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2021-05-21):
[0001327567-21-000014:note_history:29]
The following tables summarize the amortized cost, unrealized gains and losses, and fair value of our available-for-sale debt securities as of April 30, 2021 and July 31, 2020 (in millions):
  (was, 2021-02-23, similarity 0.9779):
[0001327567-21-000004:note_history:29]
The following tables summarize the amortized cost, unrealized gains and losses, and fair value of our available-for-sale debt securities as of January 31, 2021 and July 31, 2020 (in millions):

- changed (2021-05-21):
[0001327567-21-000014:note_history:30]
|  | April 30, 2021 |
|  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Fair Value |
| Cash equivalents: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 150.2 |  |  | $ | — |  |  | $ | — |  |  | $ | 150.2 |  |
| Corporate debt securities | 2.0 |  |  | — |  |  | — |  |  | 2.0 |  |
| U.S. government and agency securities | 130.0 |  |  | — |  |  | — |  |  | 130.0 |  |
| Total available-for-sale cash equivalents | $ | 282.2 |  |  | $ | — |  |  | $ | — |  |  | $ | 282.2 |  |
| Investments: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 23.5 |  |  | $ | — |  |  | $ | — |  |  | $ | 23.5 |  |
| Corporate debt securities | 389.4 |  |  | 0.6 |  |  | (0.1) |  |  | 389.9 |  |
| U.S. government and agency securities | 1,465.3 |  |  | 1.5 |  |  | — |  |  | 1,466.8 |  |
| Non-U.S. government and agency securities | 64.5 |  |  | — |  |  | — |  |  | 64.5 |  |
| Total available-for-sale investments | $ | 1,942.7 |  |  | $ | 2.1 |  |  | $ | (0.1) |  |  | $ | 1,944.7 |  |
  (was, 2021-02-23, similarity 0.9618):
[0001327567-21-000004:note_history:30]
|  | January 31, 2021 |
|  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Fair Value |
| Cash equivalents: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 150.1 |  |  | $ | — |  |  | $ | — |  |  | $ | 150.1 |  |
| Corporate debt securities | 1.9 |  |  | — |  |  | — |  |  | 1.9 |  |
| U.S. government and agency securities | 335.6 |  |  | — |  |  | — |  |  | 335.6 |  |
| Total available-for-sale cash equivalents | $ | 487.6 |  |  | $ | — |  |  | $ | — |  |  | $ | 487.6 |  |
| Investments: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 27.2 |  |  | $ | — |  |  | $ | — |  |  | $ | 27.2 |  |
| Corporate debt securities | 322.0 |  |  | 1.0 |  |  | — |  |  | 323.0 |  |
| U.S. government and agency securities | 1,491.9 |  |  | 2.0 |  |  | — |  |  | 1,493.9 |  |
| Non-U.S. government securities | 71.0 |  |  | — |  |  | — |  |  | 71.0 |  |
| Total available-for-sale investments | $ | 1,912.1 |  |  | $ | 3.0 |  |  | $ | — |  |  | $ | 1,915.1 |  |


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2021-05-21):
[0001327567-21-000014:note_history:31]
The following tables summarize the amortized cost, unrealized gains and losses, and fair value of our available-for-sale debt securities as of April 30, 2021 and July 31, 2020 (in millions):
  (was, 2021-02-23, similarity 0.9779):
[0001327567-21-000004:note_history:31]
The following tables summarize the amortized cost, unrealized gains and losses, and fair value of our available-for-sale debt securities as of January 31, 2021 and July 31, 2020 (in millions):

- changed (2021-05-21):
[0001327567-21-000014:note_history:32]
|  | April 30, 2021 |
|  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Fair Value |
| Cash equivalents: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 150.2 |  |  | $ | — |  |  | $ | — |  |  | $ | 150.2 |  |
| Corporate debt securities | 2.0 |  |  | — |  |  | — |  |  | 2.0 |  |
| U.S. government and agency securities | 130.0 |  |  | — |  |  | — |  |  | 130.0 |  |
| Total available-for-sale cash equivalents | $ | 282.2 |  |  | $ | — |  |  | $ | — |  |  | $ | 282.2 |  |
| Investments: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 23.5 |  |  | $ | — |  |  | $ | — |  |  | $ | 23.5 |  |
| Corporate debt securities | 389.4 |  |  | 0.6 |  |  | (0.1) |  |  | 389.9 |  |
| U.S. government and agency securities | 1,465.3 |  |  | 1.5 |  |  | — |  |  | 1,466.8 |  |
| Non-U.S. government and agency securities | 64.5 |  |  | — |  |  | — |  |  | 64.5 |  |
| Total available-for-sale investments | $ | 1,942.7 |  |  | $ | 2.1 |  |  | $ | (0.1) |  |  | $ | 1,944.7 |  |
  (was, 2021-02-23, similarity 0.9618):
[0001327567-21-000004:note_history:32]
|  | January 31, 2021 |
|  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Fair Value |
| Cash equivalents: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 150.1 |  |  | $ | — |  |  | $ | — |  |  | $ | 150.1 |  |
| Corporate debt securities | 1.9 |  |  | — |  |  | — |  |  | 1.9 |  |
| U.S. government and agency securities | 335.6 |  |  | — |  |  | — |  |  | 335.6 |  |
| Total available-for-sale cash equivalents | $ | 487.6 |  |  | $ | — |  |  | $ | — |  |  | $ | 487.6 |  |
| Investments: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 27.2 |  |  | $ | — |  |  | $ | — |  |  | $ | 27.2 |  |
| Corporate debt securities | 322.0 |  |  | 1.0 |  |  | — |  |  | 323.0 |  |
| U.S. government and agency securities | 1,491.9 |  |  | 2.0 |  |  | — |  |  | 1,493.9 |  |
| Non-U.S. government securities | 71.0 |  |  | — |  |  | — |  |  | 71.0 |  |
| Total available-for-sale investments | $ | 1,912.1 |  |  | $ | 3.0 |  |  | $ | — |  |  | $ | 1,915.1 |  |

- changed (2021-05-21):
[0001327567-21-000014:note_history:33]
We do not intend to sell any of the securities in an unrealized loss position and it is not likely that we would be required to sell these securities before recovery of their amortized cost basis, which may be at maturity. We did not recognize any credit losses related to our available-for-sale debt securities during the three and nine months ended April 30, 2021.
  (was, 2021-02-23, similarity 0.9736):
[0001327567-21-000004:note_history:33]
We do not intend to sell any of the securities in an unrealized loss position and it is not likely that we would be required to sell these securities before recovery of their amortized cost basis, which may be at maturity. We did not recognize any credit losses related to our available-for-sale debt securities during the three and six months ended January 31, 2021.

- changed (2021-05-21):
[0001327567-21-000014:note_history:34]
The following table summarizes the amortized cost and fair value of our available-for-sale debt securities as of April 30, 2021, by contractual years-to-maturity (in millions):
  (was, 2021-02-23, similarity 0.9766):
[0001327567-21-000004:note_history:34]
The following table summarizes the amortized cost and fair value of our available-for-sale debt securities as of January 31, 2021, by contractual years-to-maturity (in millions):

- added (2021-05-21):
[0001327567-21-000014:note_history:35]
Marketable equity securities consist of money market funds and are included in cash and cash equivalents on our condensed consolidated balance sheets. As of April 30, 2021 and July 31, 2020, the carrying values of our marketable equity securities were $265.0 million and $1.6 billion, respectively. There were no unrealized gains or losses recognized for these securities during the three and nine months ended April 30, 2021 and 2020.

- removed (2021-05-21):
[0001327567-21-000004:note_history:36]
Marketable equity securities consist of money market funds and are included in cash and cash equivalents on our condensed consolidated balance sheets. As of January 31, 2021 and July 31, 2020, the carrying value of our marketable equity securities were $310.2 million and $1.6 billion, respectively. There were no unrealized gains or losses recognized for these securities during the three and six months ended January 31, 2021 and 2020.


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2021-05-21):
[0001327567-21-000014:note_history:37]
|  | Three Months Ended April 30, |  | Nine Months Ended April 30, |
|  | 2021 |  | 2020 |  | 2021 |  | 2020 |
| Revenue: |  |  |  |  |  |  |  |
| Americas |  |  |  |  |  |  |  |
| United States | $ | 685.4 |  |  | $ | 553.5 |  |  | $ | 1,957.8 |  |  | $ | 1,554.0 |  |
| Other Americas | 49.1 |  |  | 40.7 |  |  | 137.9 |  |  | 114.5 |  |
| Total Americas | 734.5 |  |  | 594.2 |  |  | 2,095.7 |  |  | 1,668.5 |  |
| Europe, the Middle East, and Africa (“EMEA”) | 210.2 |  |  | 171.5 |  |  | 586.9 |  |  | 485.3 |  |
| Asia Pacific and Japan (“APAC”) | 129.2 |  |  | 103.7 |  |  | 354.2 |  |  | 304.2 |  |
| Total revenue | $ | 1,073.9 |  |  | $ | 869.4 |  |  | $ | 3,036.8 |  |  | $ | 2,458.0 |  |
  (was, 2021-02-23, similarity 0.9563):
[0001327567-21-000004:note_history:37]
|  | Three Months Ended January 31, |  | Six Months Ended January 31, |
|  | 2021 |  | 2020 |  | 2021 |  | 2020 |
| Revenue: |  |  |  |  |  |  |  |
| Americas |  |  |  |  |  |  |  |
| United States | $ | 644.0 |  |  | $ | 505.6 |  |  | $ | 1,272.4 |  |  | $ | 1,000.5 |  |
| Other Americas | 46.9 |  |  | 39.1 |  |  | 88.8 |  |  | 73.8 |  |
| Total Americas | 690.9 |  |  | 544.7 |  |  | 1,361.2 |  |  | 1,074.3 |  |
| Europe, the Middle East, and Africa (“EMEA”) | 205.8 |  |  | 166.2 |  |  | 376.7 |  |  | 313.8 |  |
| Asia Pacific and Japan (“APAC”) | 120.2 |  |  | 105.8 |  |  | 225.0 |  |  | 200.5 |  |
| Total revenue | $ | 1,016.9 |  |  | $ | 816.7 |  |  | $ | 1,962.9 |  |  | $ | 1,588.6 |  |

- added (2021-05-21):
[0001327567-21-000014:note_history:38]
|  | Three Months Ended April 30, |  | Nine Months Ended April 30, |
|  | 2021 |  | 2020 |  | 2021 |  | 2020 |
| Revenue: |  |  |  |  |  |  |  |
| Product | $ | 288.9 |  |  | $ | 280.9 |  |  | $ | 780.9 |  |  | $ | 758.6 |  |
| Subscription and support |  |  |  |  |  |  |  |
| Subscription | 473.8 |  |  | 354.3 |  |  | 1,363.5 |  |  | 1,015.5 |  |
| Support | 311.2 |  |  | 234.2 |  |  | 892.4 |  |  | 683.9 |  |
| Total subscription and support | 785.0 |  |  | 588.5 |  |  | 2,255.9 |  |  | 1,699.4 |  |
| Total revenue | $ | 1,073.9 |  |  | $ | 869.4 |  |  | $ | 3,036.8 |  |  | $ | 2,458.0 |  |

- changed (2021-05-21):
[0001327567-21-000014:note_history:39]
During the nine months ended April 30, 2021 and 2020, we recognized approximately $1.6 billion and $1.3 billion of revenue pertaining to amounts that were deferred as of July 31, 2020 and 2019, respectively.
  (was, 2021-02-23, similarity 0.9596):
[0001327567-21-000004:note_history:39]
During the six months ended January 31, 2021 and 2020, we recognized approximately $1.2 billion and $915.0 million of revenue pertaining to amounts that were deferred as of July 31, 2020 and 2019, respectively.

- changed (2021-05-21):
[0001327567-21-000014:note_history:40]
Revenue expected to be recognized from remaining performance obligations was $4.9 billion as of April 30, 2021, of which we expect to recognize approximately $2.6 billion over the next 12 months and the remainder thereafter.
Deferred Contract Costs
The following table presents details of our short-term and long-term deferred contract costs as of April 30, 2021 and July 31, 2020 (in millions):
  (was, 2021-02-23, similarity 0.9681):
[0001327567-21-000004:note_history:40]
Revenue expected to be recognized from remaining performance obligations was $4.6 billion as of January 31, 2021, of which we expect to recognize approximately $2.5 billion over the next 12 months and the remainder thereafter.
Deferred Contract Costs
The following table presents details of our short-term and long-term deferred contract costs as of January 31, 2021 and July 31, 2020 (in millions):

- changed (2021-05-21):
[0001327567-21-000014:note_history:41]
|  | April 30, 2021 |  | July 31, 2020 |
| Short-term deferred contract costs | $ | 235.0 |  |  | $ | 206.0 |  |
| Long-term deferred contract costs | 420.1 |  |  | 422.3 |  |
| Total deferred contract costs | $ | 655.1 |  |  | $ | 628.3 |  |
  (was, 2021-02-23, similarity 0.9798):
[0001327567-21-000004:note_history:41]
|  | January 31, 2021 |  | July 31, 2020 |
| Short-term deferred contract costs | $ | 224.4 |  |  | $ | 206.0 |  |
| Long-term deferred contract costs | 410.5 |  |  | 422.3 |  |
| Total deferred contract costs | $ | 634.9 |  |  | $ | 628.3 |  |

- added (2021-05-21):
[0001327567-21-000014:note_history:42]
We recognized amortization expense for our deferred contract costs of $73.9 million and $208.3 million during the three and nine months ended April 30, 2021, respectively, and $60.5 million and $171.4 million during the three and nine months ended 
April 30, 2020, respectively. We did not recognize any impairment losses on our deferred contract costs during the three and nine months ended April 30, 2021 or 2020.

- removed (2021-05-21):
[0001327567-21-000004:note_history:43]
|  | Three Months Ended January 31, |  | Six Months Ended January 31, |
|  | 2021 |  | 2020 |  | 2021 |  | 2020 |
| Revenue: |  |  |  |  |  |  |  |
| Product | $ | 254.7 |  |  | $ | 246.5 |  |  | $ | 492.0 |  |  | $ | 477.7 |  |
| Subscription and support |  |  |  |  |  |  |  |
| Subscription | 461.7 |  |  | 342.6 |  |  | 889.7 |  |  | 661.2 |  |
| Support | 300.5 |  |  | 227.6 |  |  | 581.2 |  |  | 449.7 |  |
| Total subscription and support | 762.2 |  |  | 570.2 |  |  | 1,470.9 |  |  | 1,110.9 |  |
| Total revenue | $ | 1,016.9 |  |  | $ | 816.7 |  |  | $ | 1,962.9 |  |  | $ | 1,588.6 |  |

- removed (2021-05-21):
[0001327567-21-000004:note_history:44]
We recognized amortization expense for our deferred contract costs of $68.6 million and $134.4 million during the three and six months ended January 31, 2021, respectively, and $55.3 million and $110.9 million during the three and six months ended January 31, 2020, respectively. We did not recognize any impairment losses on our deferred contract costs during the three and six months ended January 31, 2021 or 2020.


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: no_current_note, score: 0.0

- removed (2021-05-21):
[0001327567-21-000004:note_history:45]
Subsequent Events
Business Combination

- removed (2021-05-21):
[0001327567-21-000004:note_history:46]
In February 2021, we entered into a definitive agreement to acquire Bridgecrew Inc. (“Bridgecrew”), a privately-held cloud security company, for total consideration of approximately $200 million, including approximately $156 million in cash, and approximately $44 million in replacement equity awards, subject to adjustment. We expect the acquisition will expand our Prisma Cloud offering to deliver security across the full application lifecycle. The acquisition is expected to close during our third quarter of fiscal 2021.
