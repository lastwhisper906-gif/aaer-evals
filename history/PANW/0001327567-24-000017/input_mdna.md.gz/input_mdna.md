# PANW MD&A — 0001327567-24-000017


## mdna

[0001327567-24-000017:mdna:1]
[same as prior period, unchanged from 0001327567-24-000005:mdna:1]

[0001327567-24-000017:mdna:2]
[same as prior period, unchanged from 0001327567-24-000005:mdna:2]

[0001327567-24-000017:mdna:3]
[same as prior period, unchanged from 0001327567-24-000005:mdna:3]

[0001327567-24-000017:mdna:4]
[same as prior period, unchanged from 0001327567-24-000005:mdna:4]

[0001327567-24-000017:mdna:5]
•Results of Operations. A discussion of the nature and trends in our financial results and an analysis of our financial results comparing the three and nine months ended April 30, 2024 to the three and nine months ended April 30, 2023.

[0001327567-24-000017:mdna:6]
[same as prior period, unchanged from 0001327567-24-000005:mdna:6]

[0001327567-24-000017:mdna:7]
[same as prior period, unchanged from 0001327567-24-000005:mdna:7]

[0001327567-24-000017:mdna:8]
[same as prior period, unchanged from 0001327567-24-000005:mdna:8]

[0001327567-24-000017:mdna:9]
[same as prior period, unchanged from 0001327567-24-000005:mdna:9]

[0001327567-24-000017:mdna:10]
[same as prior period, unchanged from 0001327567-24-000005:mdna:10]

[0001327567-24-000017:mdna:11]
[same as prior period, unchanged from 0001327567-24-000005:mdna:11]

[0001327567-24-000017:mdna:12]
[same as prior period, unchanged from 0001327567-24-000005:mdna:12]

[0001327567-24-000017:mdna:13]
•Our network security platform, designed to deliver complete zero trust solutions to our customers, includes our hardware and software ML-Powered Next-Generation Firewalls, as well as a cloud-delivered Secure Access Service Edge (“SASE”). Prisma® Access, our Security Services Edge (“SSE”) solution, when combined with Prisma SD-WAN, provides a comprehensive single-vendor SASE offering that is used to secure remote workforces and securely enable the cloud-delivered branch. We have been recognized as a leader in network firewalls, SASE, SSE, and SD-WAN. Our network security platform also includes our cloud-delivered security services, such as Advanced Threat Prevention, Advanced WildFire®, Advanced URL Filtering, Advanced DNS Security, IoT/OT Security, GlobalProtect®, Enterprise Data Loss Prevention (“Enterprise DLP”), Artificial Intelligence for IT Operations (“AIOps”), SaaS Security API, SaaS Security Inline, and Artificial Intelligence (“AI”) Access Security. Through these add-on security services, our customers are able to secure their content, applications, users, and devices across their entire organization. Strata Cloud Manager, our network security management solution, can centrally manage our network security platform irrespective of form factor, location, or scale. Strata Cloud Manager includes the Strata Copilot which provides a natural language interface to simplify and accelerate platform management.

[0001327567-24-000017:mdna:14]
[same as prior period, unchanged from 0001327567-24-000005:mdna:14]

[0001327567-24-000017:mdna:15]
•We enable cloud-native security through our Prisma Cloud Code to CloudTM platform. As a comprehensive Cloud Native Application Protection Platform (“CNAPP”), Prisma Cloud secures multi- and hybrid-cloud environments for applications, data, and the entire cloud native technology stack across the full development lifecycle, from code to cloud. We also offer our VM-Series and CN-Series virtual firewalls for inline network security on multi- and hybrid-cloud environments.

[0001327567-24-000017:mdna:16]
[same as prior period, unchanged from 0001327567-24-000005:mdna:16]

[0001327567-24-000017:mdna:17]
•We deliver the next generation of security automation, security analytics, endpoint security, and attack surface management solutions through our Cortex portfolio. These include Cortex XSIAM, our AI-driven security operations platform, Cortex XDR® for the prevention, detection, and response to complex cybersecurity attacks, Cortex XSOAR® for security orchestration, automation, and response (“SOAR”), and Cortex XpanseTM for attack surface management (“ASM”). These products are delivered as SaaS or software subscriptions.

[0001327567-24-000017:mdna:18]
[same as prior period, unchanged from 0001327567-24-000005:mdna:18]

[0001327567-24-000017:mdna:19]
[same as prior period, unchanged from 0001327567-24-000005:mdna:19]

[0001327567-24-000017:mdna:20]
For the third quarter of fiscal 2024 and 2023, total revenue was $2.0 billion and $1.7 billion, respectively, representing year-over-year growth of 15.3%. Our growth reflects the increased adoption of our portfolio, which consists of product, subscriptions, and support. We believe our portfolio will enable us to benefit from recurring revenues and new revenues as we continue to grow our end-customer base. As of April 30, 2024, we had end-customers in over 180 countries. Our end-customers represent a broad range of industries, including education, energy, financial services, government entities, healthcare, Internet and media, manufacturing, public sector, and telecommunications, and include almost all of the Fortune 100 companies and a majority of the Global 2000 companies. We maintain a field sales force that works closely with our channel partners in developing sales opportunities. We primarily use a two-tiered, indirect fulfillment model whereby we sell our products, subscriptions, and support to our distributors, which, in turn, sell to our resellers, which then sell to our end-customers.

[0001327567-24-000017:mdna:21]
[same as prior period, unchanged from 0001327567-24-000005:mdna:21]

[0001327567-24-000017:mdna:22]
Our product revenue grew to $391.0 million, or 19.7% of total revenue, for the third quarter of fiscal 2024. Product revenue is derived from sales of our appliances, primarily our ML-Powered Next-Generation Firewall. Product revenue also includes revenue derived from software licenses of Panorama®, SD-WAN, and the VM-Series. Our ML-Powered Next-Generation Firewall incorporates our PAN-OS operating system, which provides a consistent set of capabilities across our entire network security product line. Our appliances and software licenses include a broad set of built-in networking and security features and functionalities. Our products are designed for different performance requirements throughout an organization, ranging from our PA-410, which is designed for small organizations and remote or branch offices, to our top-of-the-line PA-7500, which is designed for large-scale data centers and service provider use. The same firewall functionality that is delivered in our physical appliances is also available in our VM-Series virtual firewalls, which secure virtualized and cloud-based computing environments, and in our CN-Series container firewalls, which secure container environments and traffic.

[0001327567-24-000017:mdna:23]
Our subscription and support revenue grew to $1.6 billion, or 80.3% of total revenue, for the third quarter of fiscal 2024, representing year-over-year growth of 19.6%. Our subscriptions provide our end-customers with near real-time access to the latest antivirus, intrusion prevention, web filtering, modern malware prevention, data loss prevention, and cloud access security broker capabilities across the network, endpoints, and the cloud. When end-customers purchase our physical, virtual, or container firewall appliances, or certain cloud offerings, they typically purchase support in order to receive ongoing security updates, upgrades, bug fixes, and repairs. In addition to the subscriptions purchased with these appliances, end-customers may also purchase other subscriptions on a per-user, per-endpoint, or capacity-based basis. We also offer professional services, including incident response, risk management, and digital forensic services.

[0001327567-24-000017:mdna:24]
We continue to invest in innovation as we evolve and further extend the capabilities of our portfolio, as we believe that innovation and timely development of new features and products are essential to meeting the needs of our end-customers and improving our competitive position. For example, in April 2024, we introduced new Cortex XSIAM features that enable security operations teams to identify and remediate cloud threats in real-time.

[0001327567-24-000017:mdna:25]
We believe that the growth of our business and our short-term and long-term success are dependent upon many factors, including our ability to extend our technology leadership, grow our base of end-customers, expand deployment of our portfolio and support offerings within existing end-customers, focus on end-customer satisfaction, and address any product vulnerabilities. To manage any future growth effectively, we must continue to improve and expand our information technology and financial infrastructure, our operating and administrative systems and controls, and our ability to manage headcount, capital, and processes in an efficient manner. While these areas present significant opportunities for us, they also pose challenges and risks that we must successfully address in order to sustain the growth of our business and improve our operating results. For additional information regarding the challenges and risks we face, see the “Risk Factors” section in Part II, Item 1A of this Quarterly Report on Form 10-Q.

[0001327567-24-000017:mdna:26]
[same as prior period, unchanged from 0001327567-24-000005:mdna:26]

[0001327567-24-000017:mdna:27]
[same as prior period, unchanged from 0001327567-24-000005:mdna:27]

[0001327567-24-000017:mdna:28]
[same as prior period, unchanged from 0001327567-24-000005:mdna:28]

[0001327567-24-000017:mdna:29]
[same as prior period, unchanged from 0001327567-24-000005:mdna:29]

[0001327567-24-000017:mdna:30]
[same as prior period, unchanged from 0001327567-24-000005:mdna:30]

[0001327567-24-000017:mdna:31]
[same as prior period, unchanged from 0001327567-24-000005:mdna:31]

[0001327567-24-000017:mdna:32]
[same as prior period, unchanged from 0001327567-24-000005:mdna:32]

[0001327567-24-000017:mdna:33]
|  | April 30, 2024 |  | July 31, 2023 |
|  | (in millions) |
| Total deferred revenue | $ | 10,167.6 |  |  | $ | 9,296.4 |  |
| Cash, cash equivalents, and investments | $ | 6,394.8 |  |  | $ | 5,437.9 |  |

[0001327567-24-000017:mdna:34]
|  | Three Months Ended April 30, |  | Nine Months Ended April 30, |
|  | 2024 |  | 2023 |  | 2024 |  | 2023 |
|  | (dollars in millions) |
| Total revenue | $ | 1,984.8 |  |  | $ | 1,720.9 |  |  | $ | 5,838.0 |  |  | $ | 4,939.4 |  |
| Total revenue year-over-year percentage increase | 15.3 | % |  | 24.1 | % |  | 18.2 | % |  | 25.0 | % |
| Gross margin | 74.1 | % |  | 72.4 | % |  | 74.6 | % |  | 71.6 | % |
| Operating income | $ | 176.7 |  |  | $ | 78.7 |  |  | $ | 445.5 |  |  | $ | 133.8 |  |
| Operating margin | 8.9 | % |  | 4.6 | % |  | 7.6 | % |  | 2.7 | % |
| Billings | $ | 2,334.0 |  |  | $ | 2,256.2 |  |  | $ | 6,705.7 |  |  | $ | 6,034.3 |  |
| Billings year-over-year percentage increase | 3.4 | % |  | 25.6 | % |  | 11.1 | % |  | 26.1 | % |
| Cash flow provided by operating activities |  |  |  |  | $ | 2,744.9 |  |  | $ | 2,363.4 |  |
| Free cash flow (non-GAAP) |  |  |  |  | $ | 2,635.5 |  |  | $ | 2,254.3 |  |

[0001327567-24-000017:mdna:35]
[same as prior period, unchanged from 0001327567-24-000005:mdna:35]

[0001327567-24-000017:mdna:36]
[same as prior period, unchanged from 0001327567-24-000005:mdna:36]

[0001327567-24-000017:mdna:37]
|  | Three Months Ended April 30, |  | Nine Months Ended April 30, |
|  | 2024 |  | 2023 |  | 2024 |  | 2023 |
|  | (in millions) |
| Billings: |  |  |  |  |  |  |  |
| Total revenue | $ | 1,984.8 |  |  | $ | 1,720.9 |  |  | $ | 5,838.0 |  |  | $ | 4,939.4 |  |
| Add: change in total deferred revenue, net of acquired deferred revenue | 349.2 |  |  | 535.3 |  |  | 867.7 |  |  | 1,094.9 |  |
| Billings | $ | 2,334.0 |  |  | $ | 2,256.2 |  |  | $ | 6,705.7 |  |  | $ | 6,034.3 |  |

[0001327567-24-000017:mdna:38]
[same as prior period, unchanged from 0001327567-24-000005:mdna:38]

[0001327567-24-000017:mdna:39]
[same as prior period, unchanged from 0001327567-24-000005:mdna:39]

[0001327567-24-000017:mdna:40]
[same as prior period, unchanged from 0001327567-24-000005:mdna:40]

[0001327567-24-000017:mdna:41]
|  | Nine Months Ended April 30, |
|  | 2024 |  | 2023 |
|  | (in millions) |
| Free cash flow (non-GAAP): |  |  |  |
| Net cash provided by operating activities | $ | 2,744.9 |  |  | $ | 2,363.4 |  |
| Less: purchases of property, equipment, and other assets | 109.4 |  |  | 109.1 |  |
| Free cash flow (non-GAAP) | $ | 2,635.5 |  |  | $ | 2,254.3 |  |
| Net cash used in investing activities | $ | (1,341.4) |  |  | $ | (2,396.4) |  |
| Net cash used in financing activities | $ | (1,163.8) |  |  | $ | (91.5) |  |

[0001327567-24-000017:mdna:42]
[same as prior period, unchanged from 0001327567-24-000005:mdna:42]

[0001327567-24-000017:mdna:43]
[same as prior period, unchanged from 0001327567-24-000005:mdna:43]

[0001327567-24-000017:mdna:44]
[same as prior period, unchanged from 0001327567-24-000005:mdna:44]

[0001327567-24-000017:mdna:45]
|  | Three Months Ended April 30, |  | Nine Months Ended April 30, |
|  | 2024 |  | 2023 |  | 2024 |  | 2023 |
|  | Amount |  | % of Revenue |  | Amount |  | % of Revenue |  | Amount |  | % of Revenue |  | Amount |  | % of Revenue |
|  | (dollars in millions) |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product | $ | 391.0 |  |  | 19.7 | % |  | $ | 388.1 |  |  | 22.6 | % |  | $ | 1,122.8 |  |  | 19.2 | % |  | $ | 1,071.0 |  |  | 21.7 | % |
| Subscription and support | 1,593.8 |  |  | 80.3 | % |  | 1,332.8 |  |  | 77.4 | % |  | 4,715.2 |  |  | 80.8 | % |  | 3,868.4 |  |  | 78.3 | % |
| Total revenue | 1,984.8 |  |  | 100.0 | % |  | 1,720.9 |  |  | 100.0 | % |  | 5,838.0 |  |  | 100.0 | % |  | 4,939.4 |  |  | 100.0 | % |
| Cost of revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product | 77.9 |  |  | 3.9 | % |  | 93.4 |  |  | 5.4 | % |  | 243.5 |  |  | 4.2 | % |  | 314.0 |  |  | 6.4 | % |
| Subscription and support | 435.7 |  |  | 22.0 | % |  | 381.4 |  |  | 22.2 | % |  | 1,242.0 |  |  | 21.2 | % |  | 1,088.9 |  |  | 22.0 | % |
| Total cost of revenue(1) | 513.6 |  |  | 25.9 | % |  | 474.8 |  |  | 27.6 | % |  | 1,485.5 |  |  | 25.4 | % |  | 1,402.9 |  |  | 28.4 | % |
| Total gross profit | 1,471.2 |  |  | 74.1 | % |  | 1,246.1 |  |  | 72.4 | % |  | 4,352.5 |  |  | 74.6 | % |  | 3,536.5 |  |  | 71.6 | % |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Research and development | 457.2 |  |  | 23.0 | % |  | 413.7 |  |  | 24.0 | % |  | 1,314.6 |  |  | 22.5 | % |  | 1,189.6 |  |  | 24.1 | % |
| Sales and marketing | 718.7 |  |  | 36.2 | % |  | 639.5 |  |  | 37.2 | % |  | 2,052.2 |  |  | 35.2 | % |  | 1,880.0 |  |  | 38.1 | % |
| General and administrative | 118.6 |  |  | 6.0 | % |  | 114.2 |  |  | 6.6 | % |  | 540.2 |  |  | 9.3 | % |  | 333.1 |  |  | 6.7 | % |
| Total operating expenses(1) | 1,294.5 |  |  | 65.2 | % |  | 1,167.4 |  |  | 67.8 | % |  | 3,907.0 |  |  | 67.0 | % |  | 3,402.7 |  |  | 68.9 | % |
| Operating income | 176.7 |  |  | 8.9 | % |  | 78.7 |  |  | 4.6 | % |  | 445.5 |  |  | 7.6 | % |  | 133.8 |  |  | 2.7 | % |
| Interest expense | (2.3) |  |  | (0.1 | %) |  | (7.8) |  |  | (0.5) | % |  | (8.0) |  |  | (0.1 | %) |  | (21.5) |  |  | (0.4) | % |
| Other income, net | 76.8 |  |  | 3.9 | % |  | 60.1 |  |  | 3.5 | % |  | 231.8 |  |  | 4.0 | % |  | 137.5 |  |  | 2.8 | % |
| Income before income taxes | 251.2 |  |  | 12.7 | % |  | 131.0 |  |  | 7.6 | % |  | 669.3 |  |  | 11.5 | % |  | 249.8 |  |  | 5.1 | % |
| Provision for (benefit from) income taxes | (27.6) |  |  | (1.3 | %) |  | 23.2 |  |  | 1.3 | % |  | (1,550.6) |  |  | (26.5 | %) |  | 37.8 |  |  | 0.8 | % |
| Net income | $ | 278.8 |  |  | 14.0 | % |  | $ | 107.8 |  |  | 6.3 | % |  | $ | 2,219.9 |  |  | 38.0 | % |  | $ | 212.0 |  |  | 4.3 | % |

[0001327567-24-000017:mdna:46]
(1) Includes share-based compensation as follows:

[0001327567-24-000017:mdna:47]
|  | Three Months Ended April 30, |  | Nine Months Ended April 30, |
|  | 2024 |  | 2023 |  | 2024 |  | 2023 |
|  | (in millions) |
| Cost of product revenue | $ | 1.6 |  |  | $ | 2.5 |  |  | $ | 6.3 |  |  | $ | 7.5 |  |
| Cost of subscription and support revenue | 30.0 |  |  | 32.0 |  |  | 91.3 |  |  | 91.5 |  |
| Research and development | 128.2 |  |  | 125.4 |  |  | 386.9 |  |  | 373.1 |  |
| Sales and marketing | 74.3 |  |  | 80.5 |  |  | 229.1 |  |  | 256.3 |  |
| General and administrative | 29.4 |  |  | 36.8 |  |  | 96.2 |  |  | 104.7 |  |
| Total share-based compensation | $ | 263.5 |  |  | $ | 277.2 |  |  | $ | 809.8 |  |  | $ | 833.1 |  |

[0001327567-24-000017:mdna:48]
[same as prior period, unchanged from 0001327567-24-000005:mdna:48]

[0001327567-24-000017:mdna:49]
[same as prior period, unchanged from 0001327567-24-000005:mdna:49]

[0001327567-24-000017:mdna:50]
[same as prior period, unchanged from 0001327567-24-000005:mdna:50]

[0001327567-24-000017:mdna:51]
[same as prior period, unchanged from 0001327567-24-000005:mdna:51]

[0001327567-24-000017:mdna:52]
[same as prior period, unchanged from 0001327567-24-000005:mdna:52]

[0001327567-24-000017:mdna:53]
|  | Three Months Ended April 30, |  |  |  |  |  | Nine Months Ended April 30, |  |  |  |  |
|  | 2024 |  | 2023 |  | Change |  | 2024 |  | 2023 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| Product | $ | 391.0 |  |  | $ | 388.1 |  |  | $ | 2.9 |  |  | 0.7 | % |  | $ | 1,122.8 |  |  | $ | 1,071.0 |  |  | $ | 51.8 |  |  | 4.8 | % |

[0001327567-24-000017:mdna:54]
Product revenue was flat for the three months ended April 30, 2024 compared to the same period in 2023 driven by increased software revenue and increased demand for our new generation of hardware products, offset by decreased demand for our prior generation of hardware products. Product revenue increased for the nine months ended April 30, 2024 compared to the same period in 2023 driven by increased software revenue primarily due to a go-to-market strategy for certain Network Security offerings, and increased demand for our new generation of hardware products, partially offset by decreased demand for our prior generation of hardware products.

[0001327567-24-000017:mdna:55]
[same as prior period, unchanged from 0001327567-24-000005:mdna:55]

[0001327567-24-000017:mdna:56]
[same as prior period, unchanged from 0001327567-24-000005:mdna:56]

[0001327567-24-000017:mdna:57]
|  | Three Months Ended April 30, |  |  |  |  |  | Nine Months Ended April 30, |  |  |  |  |
|  | 2024 |  | 2023 |  | Change |  | 2024 |  | 2023 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| Subscription | $ | 1,045.6 |  |  | $ | 838.1 |  |  | $ | 207.5 |  |  | 24.8 | % |  | $ | 3,061.0 |  |  | $ | 2,417.5 |  |  | $ | 643.5 |  |  | 26.6 | % |
| Support | 548.2 |  |  | 494.7 |  |  | 53.5 |  |  | 10.8 | % |  | 1,654.2 |  |  | 1,450.9 |  |  | 203.3 |  |  | 14.0 | % |
| Total subscription and support | $ | 1,593.8 |  |  | $ | 1,332.8 |  |  | $ | 261.0 |  |  | 19.6 | % |  | $ | 4,715.2 |  |  | $ | 3,868.4 |  |  | $ | 846.8 |  |  | 21.9 | % |

[0001327567-24-000017:mdna:58]
Subscription and support revenue increased for the three and nine months ended April 30, 2024 compared to the same periods in 2023 primarily due to increased demand for our subscription and support offerings from our end-customers. The mix between subscription revenue and support revenue will fluctuate over time, depending on the introduction of new subscription offerings, renewals of support services, and our ability to increase sales to new and existing end-customers.

[0001327567-24-000017:mdna:59]
[same as prior period, unchanged from 0001327567-24-000005:mdna:59]

[0001327567-24-000017:mdna:60]
[same as prior period, unchanged from 0001327567-24-000005:mdna:60]

[0001327567-24-000017:mdna:61]
|  | Three Months Ended April 30, |  |  |  |  |  | Nine Months Ended April 30, |  |  |  |  |
|  | 2024 |  | 2023 |  | Change |  | 2024 |  | 2023 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| Americas | $ | 1,359.6 |  |  | $ | 1,179.2 |  |  | $ | 180.4 |  |  | 15.3 | % |  | $ | 3,980.4 |  |  | $ | 3,366.9 |  |  | $ | 613.5 |  |  | 18.2 | % |
| EMEA | 399.2 |  |  | 332.1 |  |  | 67.1 |  |  | 20.2 | % |  | 1,170.9 |  |  | 981.5 |  |  | 189.4 |  |  | 19.3 | % |
| APAC | 226.0 |  |  | 209.6 |  |  | 16.4 |  |  | 7.8 | % |  | 686.7 |  |  | 591.0 |  |  | 95.7 |  |  | 16.2 | % |
| Total revenue | $ | 1,984.8 |  |  | $ | 1,720.9 |  |  | $ | 263.9 |  |  | 15.3 | % |  | $ | 5,838.0 |  |  | $ | 4,939.4 |  |  | $ | 898.6 |  |  | 18.2 | % |

[0001327567-24-000017:mdna:62]
Revenue from the Americas, Europe, the Middle East, and Africa (“EMEA”), and Asia Pacific and Japan (“APAC”), increased for the three and nine months ended April 30, 2024 compared to the same periods in 2023 as we continued to increase investment in our global sales force in order to support our growth and innovation, with the Americas contributing the highest increase in revenue due to its larger scale.

[0001327567-24-000017:mdna:63]
[same as prior period, unchanged from 0001327567-24-000005:mdna:63]

[0001327567-24-000017:mdna:64]
[same as prior period, unchanged from 0001327567-24-000005:mdna:64]

[0001327567-24-000017:mdna:65]
[same as prior period, unchanged from 0001327567-24-000005:mdna:65]

[0001327567-24-000017:mdna:66]
[same as prior period, unchanged from 0001327567-24-000005:mdna:66]

[0001327567-24-000017:mdna:67]
|  | Three Months Ended April 30, |  |  |  |  |  | Nine Months Ended April 30, |  |  |  |  |
|  | 2024 |  | 2023 |  | Change |  | 2024 |  | 2023 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| Cost of product revenue | $ | 77.9 |  |  | $ | 93.4 |  |  | $ | (15.5) |  |  | (16.6) | % |  | $ | 243.5 |  |  | $ | 314.0 |  |  | $ | (70.5) |  |  | (22.5) | % |

[0001327567-24-000017:mdna:68]
Cost of product revenue decreased for the three months ended April 30, 2024 compared to the same period in 2023 primarily due to decreased demand for our prior generation of hardware products and lower other product costs, partially offset by increased demand for our new generation hardware products. Cost of product revenue decreased for the nine months ended April 30, 2024 compared to the same period in 2023 primarily due to decreased demand for our prior generation of hardware products and lower costs largely driven by an easing of supply chain challenges, partially offset by increased demand for our new generation hardware products.

[0001327567-24-000017:mdna:69]
[same as prior period, unchanged from 0001327567-24-000005:mdna:69]

[0001327567-24-000017:mdna:70]
[same as prior period, unchanged from 0001327567-24-000005:mdna:70]

[0001327567-24-000017:mdna:71]
[same as prior period, unchanged from 0001327567-24-000005:mdna:71]

[0001327567-24-000017:mdna:72]
|  | Three Months Ended April 30, |  |  |  |  |  | Nine Months Ended April 30, |  |  |  |  |
|  | 2024 |  | 2023 |  | Change |  | 2024 |  | 2023 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| Cost of subscription and support revenue | $ | 435.7 |  |  | $ | 381.4 |  |  | $ | 54.3 |  |  | 14.2 | % |  | $ | 1,242.0 |  |  | $ | 1,088.9 |  |  | $ | 153.1 |  |  | 14.1 | % |

[0001327567-24-000017:mdna:73]
Cost of subscription and support revenue increased for the three and nine months ended April 30, 2024 compared to the same periods in 2023 primarily due to increased costs to support the growth of our subscription and support offerings. Cloud hosting service costs, which support our cloud-based subscription offerings, increased $30.4 million for the three months ended April 30, 2024 compared to the same period in 2023, and increased $78.8 million for the nine months ended April 30, 2024 compared to the same period in 2023. Personnel costs grew $6.5 million for the three months ended April 30, 2024 compared to the same period in 2023, and grew $39.4 million for the nine months ended April 30, 2024 compared to the same period in 2023, primarily due to headcount growth. The increase in cost of subscription and support revenue for the three months ended April 30, 2024 was further driven by amortization of intangible assets from our recent acquisitions.

[0001327567-24-000017:mdna:74]
[same as prior period, unchanged from 0001327567-24-000005:mdna:74]

[0001327567-24-000017:mdna:75]
[same as prior period, unchanged from 0001327567-24-000005:mdna:75]

[0001327567-24-000017:mdna:76]
|  | Three Months Ended April 30, |  | Nine Months Ended April 30, |
|  | 2024 |  | 2023 |  | 2024 |  | 2023 |
|  | Amount |  | Gross Margin |  | Amount |  | Gross Margin |  | Amount |  | Gross Margin |  | Amount |  | Gross Margin |
|  | (dollars in millions) |
| Product | $ | 313.1 |  |  | 80.1 | % |  | $ | 294.7 |  |  | 75.9 | % |  | $ | 879.3 |  |  | 78.3 | % |  | $ | 757.0 |  |  | 70.7 | % |
| Subscription and support | 1,158.1 |  |  | 72.7 | % |  | 951.4 |  |  | 71.4 | % |  | 3,473.2 |  |  | 73.7 | % |  | 2,779.5 |  |  | 71.9 | % |
| Total gross profit | $ | 1,471.2 |  |  | 74.1 | % |  | $ | 1,246.1 |  |  | 72.4 | % |  | $ | 4,352.5 |  |  | 74.6 | % |  | $ | 3,536.5 |  |  | 71.6 | % |

[0001327567-24-000017:mdna:77]
Product gross margin increased for the three months ended April 30, 2024 compared to the same period in 2023 primarily due to lower other product costs and increased software revenue. Product gross margin increased for the nine months ended April 30, 2024 compared to the same period in 2023 primarily due to lower costs largely driven by an easing of supply chain challenges and increased software revenue.

[0001327567-24-000017:mdna:78]
Subscription and support gross margin increased for the three and nine months ended April 30, 2024 compared to the same periods in 2023 primarily due to our growth in subscription and support revenue, which outpaced the subscription and support costs.

[0001327567-24-000017:mdna:79]
[same as prior period, unchanged from 0001327567-24-000005:mdna:79]

[0001327567-24-000017:mdna:80]
[same as prior period, unchanged from 0001327567-24-000005:mdna:80]

[0001327567-24-000017:mdna:81]
Our operating expenses consist of research and development, sales and marketing, and general and administrative expenses. Personnel costs are the most significant component of operating expenses and consist of salaries, benefits, bonuses, share-based compensation, travel and entertainment, and with regard to sales and marketing expense, sales commissions. Our operating expenses also include shared costs, which consist of certain facilities, depreciation, benefits, recruiting, and information technology costs that we allocate based on headcount to each department. We expect operating expenses generally to increase in absolute dollars and to decrease over the long term as a percentage of revenue as we continue to scale our business. As of April 30, 2024, we expect to recognize approximately $2.2 billion of share-based compensation expense over a weighted-average period of approximately 2.7 years, excluding additional share-based compensation expense related to any future grants of share-based awards. Share-based compensation expense is generally recognized on a straight-line basis over the requisite service periods of the awards.

[0001327567-24-000017:mdna:82]
[same as prior period, unchanged from 0001327567-24-000005:mdna:82]

[0001327567-24-000017:mdna:83]
[same as prior period, unchanged from 0001327567-24-000005:mdna:83]

[0001327567-24-000017:mdna:84]
|  | Three Months Ended April 30, |  |  |  |  |  | Nine Months Ended April 30, |  |  |  |  |
|  | 2024 |  | 2023 |  | Change |  | 2024 |  | 2023 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| Research and development | $ | 457.2 |  |  | $ | 413.7 |  |  | $ | 43.5 |  |  | 10.5 | % |  | $ | 1,314.6 |  |  | $ | 1,189.6 |  |  | $ | 125.0 |  |  | 10.5 | % |

[0001327567-24-000017:mdna:85]
Research and development expense increased for the three and nine months ended April 30, 2024 compared to the same periods in 2023 primarily due to increased personnel costs, which grew $29.4 million for the three months ended April 30, 2024 compared to the same period in 2023, and grew $91.1 million for the nine months ended April 30, 2024 compared to the same period in 2023, largely due to headcount growth. The remaining increase in research and development expense was further driven by increased shared costs.

[0001327567-24-000017:mdna:86]
[same as prior period, unchanged from 0001327567-24-000005:mdna:86]

[0001327567-24-000017:mdna:87]
[same as prior period, unchanged from 0001327567-24-000005:mdna:87]

[0001327567-24-000017:mdna:88]
|  | Three Months Ended April 30, |  |  |  |  |  | Nine Months Ended April 30, |  |  |  |  |
|  | 2024 |  | 2023 |  | Change |  | 2024 |  | 2023 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| Sales and marketing | $ | 718.7 |  |  | $ | 639.5 |  |  | $ | 79.2 |  |  | 12.4 | % |  | $ | 2,052.2 |  |  | $ | 1,880.0 |  |  | $ | 172.2 |  |  | 9.2 | % |

[0001327567-24-000017:mdna:89]
Sales and marketing expense increased for the three and nine months ended April 30, 2024 compared to the same periods in 2023 primarily due to increased personnel costs and costs associated with sales and marketing events and go-to-market initiatives. Personnel costs grew $42.7 million for the three months ended April 30, 2024 compared to the same period in 2023, and grew $76.7 million for the nine months ended April 30, 2024 compared to the same period in 2023, largely due to headcount growth. Costs associated with sales and marketing events and go-to-market initiatives grew $22.3 million for the three months ended April 30, 2024 compared to the same period in 2023, and grew $83.7 million for the nine months ended April 30, 2024 compared to the same period in 2023.

[0001327567-24-000017:mdna:90]
[same as prior period, unchanged from 0001327567-24-000005:mdna:90]

[0001327567-24-000017:mdna:91]
[same as prior period, unchanged from 0001327567-24-000005:mdna:91]

[0001327567-24-000017:mdna:92]
[same as prior period, unchanged from 0001327567-24-000005:mdna:92]

[0001327567-24-000017:mdna:93]
|  | Three Months Ended April 30, |  |  |  |  |  | Nine Months Ended April 30, |  |  |  |  |
|  | 2024 |  | 2023 |  | Change |  | 2024 |  | 2023 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| General and administrative | $ | 118.6 |  |  | $ | 114.2 |  |  | $ | 4.4 |  |  | 3.9 | % |  | $ | 540.2 |  |  | $ | 333.1 |  |  | $ | 207.1 |  |  | 62.2 | % |

[0001327567-24-000017:mdna:94]
General and administrative expense was relatively flat for the three months ended April 30, 2024 compared to the same period in 2023. General and administrative expense increased for the nine months ended April 30, 2024 compared to the same period in 2023 primarily due to a litigation accrual of $180.5 million during the nine months ended April 30, 2024 relating to an ongoing patent infringement lawsuit.

[0001327567-24-000017:mdna:95]
[same as prior period, unchanged from 0001327567-24-000005:mdna:95]

[0001327567-24-000017:mdna:96]
Interest expense primarily consists of interest expense related to our 0.75% Convertible Senior Notes due 2023 (the “2023 Notes”) and our 0.375% Convertible Senior Notes due 2025 (the “2025 Notes,” and together with “2023 Notes,” the “Notes”).

[0001327567-24-000017:mdna:97]
|  | Three Months Ended April 30, |  |  |  | Nine Months Ended April 30, |  |  |
|  | 2024 |  | 2023 |  | Change |  | 2024 |  | 2023 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| Interest expense | $ | 2.3 |  |  | $ | 7.8 |  |  | $ | (5.5) |  |  | (70.5) | % |  | $ | 8.0 |  |  | $ | 21.5 |  |  | $ | (13.5) |  |  | (62.8) | % |

[0001327567-24-000017:mdna:98]
Interest expense decreased for the three and nine months ended April 30, 2024 compared to the same periods in 2023 primarily due to conversions of the 2023 Notes prior to or upon maturity in July 2023. Refer to Note 9. Debt in Part I, Item 1 of this Quarterly Report on Form 10-Q for more information on the Notes.

[0001327567-24-000017:mdna:99]
[same as prior period, unchanged from 0001327567-24-000005:mdna:99]

[0001327567-24-000017:mdna:100]
[same as prior period, unchanged from 0001327567-24-000005:mdna:100]

[0001327567-24-000017:mdna:101]
|  | Three Months Ended April 30, |  |  |  | Nine Months Ended April 30, |  |  |
|  | 2024 |  | 2023 |  | Change |  | 2024 |  | 2023 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| Other income, net | $ | 76.8 |  |  | $ | 60.1 |  |  | $ | 16.7 |  |  | 27.8 | % |  | $ | 231.8 |  |  | $ | 137.5 |  |  | $ | 94.3 |  |  | 68.6 | % |

[0001327567-24-000017:mdna:102]
Other income, net increased for the three and nine months ended April 30, 2024 compared to the same periods in 2023 primarily due to higher interest income as a result of higher interest rates and higher average cash, cash equivalent, and investment balances for the three and nine months ended April 30, 2024 compared to the same periods in 2023.

[0001327567-24-000017:mdna:103]
[same as prior period, unchanged from 0001327567-24-000005:mdna:103]

[0001327567-24-000017:mdna:104]
[same as prior period, unchanged from 0001327567-24-000005:mdna:104]

[0001327567-24-000017:mdna:105]
Provision for (benefit from) income taxes consists primarily of U.S. taxes, foreign income taxes, and withholding taxes. Our provision for income taxes during fiscal 2024 was offset by tax benefits from the release of our valuation allowance on U.S. federal, U.S. states other than California, and United Kingdom deferred tax assets. A portion of our valuation allowance release is included in our estimated annual effective tax rate. Accordingly, we will continue to realize related tax benefits for the remainder of fiscal 2024, in amounts much less than that recorded during the three months ended January 31, 2024. We continue to maintain a valuation allowance for California and certain foreign deferred tax assets, including net operating loss carryforwards and certain domestic tax credits.

[0001327567-24-000017:mdna:106]
|  | Three Months Ended April 30, |  |  |  |  |  | Nine Months Ended April 30, |  |  |  |  |
|  | 2024 |  | 2023 |  | Change |  | 2024 |  | 2023 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| Provision for (benefit from) income taxes | $ | (27.6) |  |  | $ | 23.2 |  |  | $ | (50.8) |  |  | (219.0 | %) |  | $ | (1,550.6) |  |  | $ | 37.8 |  |  | $ | (1,588.4) |  |  | * |
| Effective tax rate | (11.0 | %) |  | 17.7 | % |  |  |  |  |  | (231.7 | %) |  | 15.1 | % |  |  |  |  |

[0001327567-24-000017:mdna:107]
[same as prior period, unchanged from 0001327567-24-000005:mdna:107]

[0001327567-24-000017:mdna:108]
Our benefit from income taxes for the three months ended April 30, 2024 was primarily driven by excess tax benefits from share-based compensation and the release of our valuation allowance on U.S. federal, U.S. states other than California, and United Kingdom deferred tax assets. Our benefit from income taxes for the nine months ended April 30, 2024 was primarily driven by the release of our valuation allowance on U.S. federal, U.S. states other than California, and United Kingdom deferred tax assets. Refer to Note 13. Income Taxes in Part I, Item 1 of this Quarterly Report on Form 10-Q for more information.

[0001327567-24-000017:mdna:109]
[same as prior period, unchanged from 0001327567-24-000005:mdna:109]

[0001327567-24-000017:mdna:110]
|  | April 30, 2024 |  | July 31, 2023 |
|  | (in millions) |
| Working capital(1) | $ | (1,166.0) |  |  | $ | (1,689.5) |  |
| Cash, cash equivalents, and investments: |  |  |  |
| Cash and cash equivalents | $ | 1,373.7 |  |  | $ | 1,135.3 |  |
| Investments | 5,021.1 |  |  | 4,302.6 |  |
| Total cash, cash equivalents, and investments | $ | 6,394.8 |  |  | $ | 5,437.9 |  |

[0001327567-24-000017:mdna:111]
(1)Current liabilities included net carrying amounts of convertible senior notes of $1.2 billion and $2.0 billion as of April 30, 2024 and July 31, 2023, respectively. Refer to Note 9. Debt in Part I, Item 1 of this Quarterly Report on Form 10-Q for information on the Notes.

[0001327567-24-000017:mdna:112]
As of April 30, 2024, our total cash, cash equivalents, and investments of $6.4 billion were held for general corporate purposes. As of April 30, 2024, we had no unremitted earnings when evaluating our outside basis difference relating to our U.S. investment in foreign subsidiaries. However, there could be local withholding taxes due to various foreign countries if certain lower tier earnings are distributed. Withholding taxes that would be payable upon remittance of these lower tier earnings are not expected to be material.

[0001327567-24-000017:mdna:113]
Beginning in fiscal 2023, we were required to capitalize and amortize research and development expenses as required by the Tax Cuts and Jobs Act. As a result of this change, we have paid significantly more U.S. cash taxes during the nine months ended April 30, 2024 and we expect our cash tax payments to increase in future periods.

[0001327567-24-000017:mdna:114]
[same as prior period, unchanged from 0001327567-24-000005:mdna:114]

[0001327567-24-000017:mdna:115]
[same as prior period, unchanged from 0001327567-24-000005:mdna:115]

[0001327567-24-000017:mdna:116]
In June 2020, we issued the 2025 Notes with an aggregate principal amount of $2.0 billion. The 2025 Notes mature on June 1, 2025; however, under certain circumstances, holders may surrender their 2025 Notes for conversion prior to the maturity date. Upon conversion of the 2025 Notes, we will pay cash equal to the aggregate principal amount of the 2025 Notes to be converted, and, at our election, we will pay or deliver cash and/or shares of our common stock for the amount of our conversion obligation in excess of the aggregate principal amount of the 2025 Notes being converted. During the three and nine months ended April 30, 2024, holders of the 2025 Notes converted $661.8 million and $834.1 million, respectively, in aggregate principal amount of the 2025 Notes, which we repaid in cash. We also issued 4.6 million and 5.7 million shares of our common stock to the holders of the 2025 Notes during the three and nine months ended April 30, 2024, respectively, for the conversion value in excess of the principal amount of the 2025 Notes converted, which were fully offset by shares we received from the corresponding exercise of the note hedges. Subsequent to April 30, 2024, through the filing date of this Quarterly Report on Form 10-Q, $123.2 million in aggregate principal amount of the 2025 Notes was converted or had been submitted by the holders for conversion and will settle during the fiscal quarter ending July 31, 2024.

[0001327567-24-000017:mdna:117]
The sale price condition for the 2025 Notes was met during the fiscal quarter ended April 30, 2024, and as a result, holders may convert their 2025 Notes during the fiscal quarter ending July 31, 2024. If all of the holders convert their 2025 Notes during this period, we would be obligated to settle the $1.2 billion principal amount of the 2025 Notes in cash. We believe that our cash provided by operating activities, our existing cash, cash equivalents, and investments, and existing sources of and access to financing will be sufficient to meet our anticipated cash needs should the holders choose to convert their 2025 Notes during the fiscal quarter ending July 31, 2024 or hold the 2025 Notes until maturity on June 1, 2025. As of April 30, 2024, $1.2 billion of our 2025 Notes remained outstanding. Refer to Note 9. Debt in Part I, Item 1 of this Quarterly Report on Form 10-Q for more information on the Notes.

[0001327567-24-000017:mdna:118]
In April 2023, we entered into a credit agreement (the “Credit Agreement”) that provides for a $400.0 million unsecured revolving credit facility (the “Credit Facility”), with an option to increase the amount of the Credit Facility by up to an additional $350.0 million, subject to certain conditions. The interest rates and commitment fees are also subject to upward and downward adjustments based on our progress towards the achievement of certain sustainability goals related to greenhouse gas emissions. As of April 30, 2024, there were no amounts outstanding, and we were in compliance with all covenants under the Credit Agreement. Refer to Note 9. Debt in Part I, Item 1 of this Quarterly Report on Form 10-Q for more information on the Credit Agreement.

[0001327567-24-000017:mdna:119]
[same as prior period, unchanged from 0001327567-24-000005:mdna:119]

[0001327567-24-000017:mdna:120]
In February 2019, our board of directors authorized a $1.0 billion share repurchase program. In December 2020, August 2021, August 2022, and November 2023, our board of directors authorized additional $700.0 million, $676.1 million, $915.0 million, and $316.7 million increases to this share repurchase program, respectively, bringing the total authorization under this share repurchase program to $3.6 billion. Repurchases will be funded from available working capital and may be made at management’s discretion from time to time. As of April 30, 2024, $500.0 million remained available for future share repurchases under this repurchase program. The repurchase authorization will expire on December 31, 2024, and may be suspended or discontinued at any time without prior notice. Refer to Note 11. Stockholders’ Equity in Part I, Item 1 of this Quarterly Report on Form 10-Q for more information on this repurchase program.

[0001327567-24-000017:mdna:121]
[same as prior period, unchanged from 0001327567-24-000005:mdna:121]

[0001327567-24-000017:mdna:122]
We have entered into various non-cancelable operating leases, primarily for our facilities, with original lease periods expiring through the fiscal year ending July 31, 2036, with the most significant leases relating to our corporate headquarters in Santa Clara, California. As of April 30, 2024, we have total operating lease obligations of $432.3 million recorded on our condensed consolidated balance sheet.

[0001327567-24-000017:mdna:123]
As of April 30, 2024, our commitments to purchase products, components, cloud and other services totaled $4.7 billion. Refer to Note 10. Commitments and Contingencies in Part I, Item 1 of this Quarterly Report on Form 10-Q for more information on these commitments.

[0001327567-24-000017:mdna:124]
[same as prior period, unchanged from 0001327567-24-000005:mdna:124]

[0001327567-24-000017:mdna:125]
[same as prior period, unchanged from 0001327567-24-000005:mdna:125]

[0001327567-24-000017:mdna:126]
The following table summarizes our cash flows for the nine months ended April 30, 2024 and 2023:

[0001327567-24-000017:mdna:127]
|  | Nine Months Ended April 30, |
|  | 2024 |  | 2023 |
|  | (in millions) |
| Net cash provided by operating activities | $ | 2,744.9 |  |  | $ | 2,363.4 |  |
| Net cash used in investing activities | (1,341.4) |  |  | (2,396.4) |  |
| Net cash used in financing activities | (1,163.8) |  |  | (91.5) |  |
| Net increase (decrease) in cash, cash equivalents, and restricted cash | $ | 239.7 |  |  | $ | (124.5) |  |

[0001327567-24-000017:mdna:128]
[same as prior period, unchanged from 0001327567-24-000005:mdna:128]

[0001327567-24-000017:mdna:129]
[same as prior period, unchanged from 0001327567-24-000005:mdna:129]

[0001327567-24-000017:mdna:130]
[same as prior period, unchanged from 0001327567-24-000005:mdna:130]

[0001327567-24-000017:mdna:131]
[same as prior period, unchanged from 0001327567-24-000005:mdna:131]

[0001327567-24-000017:mdna:132]
Cash provided by operating activities during the nine months ended April 30, 2024 was $2.7 billion, an increase of $381.5 million compared to the same period in 2023. The increase was primarily due to growth of our business as reflected by increases in collections during the nine months ended April 30, 2024, partially offset by higher cash expenditure to support our business growth.

[0001327567-24-000017:mdna:133]
[same as prior period, unchanged from 0001327567-24-000005:mdna:133]

[0001327567-24-000017:mdna:134]
[same as prior period, unchanged from 0001327567-24-000005:mdna:134]

[0001327567-24-000017:mdna:135]
Cash used in investing activities during the nine months ended April 30, 2024 was $1.3 billion, a decrease of $1.1 billion compared to the same period in 2023. The decrease was primarily due to a decrease in purchases of investments, partially offset by an increase in net cash payments for business acquisitions and a decrease in proceeds from sales and maturities of investments during the nine months ended April 30, 2024.

[0001327567-24-000017:mdna:136]
[same as prior period, unchanged from 0001327567-24-000005:mdna:136]

[0001327567-24-000017:mdna:137]
Our financing activities have consisted of repayments of our convertible senior notes, cash used to repurchase shares of our common stock, proceeds from sales of shares through employee equity incentive plans, and payments for tax withholding obligations of certain employees related to the net share settlement of equity awards.

[0001327567-24-000017:mdna:138]
Cash used in financing activities during the nine months ended April 30, 2024 was $1.2 billion, an increase of $1.1 billion compared to the same period in 2023. The increase was primarily due to early repayments of our 2025 Notes and an increase in cash used to repurchase our common stock during the nine months ended April 30, 2024.

[0001327567-24-000017:mdna:139]
[same as prior period, unchanged from 0001327567-24-000005:mdna:139]

[0001327567-24-000017:mdna:140]
[same as prior period, unchanged from 0001327567-24-000005:mdna:140]

[0001327567-24-000017:mdna:141]
[same as prior period, unchanged from 0001327567-24-000005:mdna:141]

[0001327567-24-000017:mdna:142]
[same as prior period, unchanged from 0001327567-24-000005:mdna:142]

[0001327567-24-000017:mdna:143]
[same as prior period, unchanged from 0001327567-24-000005:mdna:143]

[0001327567-24-000017:mdna:144]
Refer to “Recently Issued Accounting Pronouncements” in Note 1. Description of Business and Summary of Significant Accounting Policies in Part I, Item 1 of this Quarterly Report on Form 10-Q for a description of recent accounting pronouncements and our expectation of their impact, if any, on our results of operations and financial condition.
