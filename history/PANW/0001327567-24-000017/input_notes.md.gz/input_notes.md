# PANW notes — 0001327567-24-000017


## us-gaap:OrganizationConsolidationBasisOfPresentationBusinessDescriptionAndAccountingPoliciesTextBlock

[0001327567-24-000017:notes:1]
[same as prior period, unchanged from 0001327567-24-000005:notes:1]

[0001327567-24-000017:notes:2]
[same as prior period, unchanged from 0001327567-24-000005:notes:2]

[0001327567-24-000017:notes:3]
[same as prior period, unchanged from 0001327567-24-000005:notes:3]

[0001327567-24-000017:notes:4]
[same as prior period, unchanged from 0001327567-24-000005:notes:4]

[0001327567-24-000017:notes:5]
[same as prior period, unchanged from 0001327567-24-000005:notes:5]

[0001327567-24-000017:notes:6]
[same as prior period, unchanged from 0001327567-24-000005:notes:6]

[0001327567-24-000017:notes:7]
[same as prior period, unchanged from 0001327567-24-000005:notes:7]

[0001327567-24-000017:notes:8]
[same as prior period, unchanged from 0001327567-24-000005:notes:8]

[0001327567-24-000017:notes:9]
[same as prior period, unchanged from 0001327567-24-000005:notes:9]

[0001327567-24-000017:notes:10]
[same as prior period, unchanged from 0001327567-24-000005:notes:10]

[0001327567-24-000017:notes:11]
There have been no material changes to our significant accounting policies as of and for the nine months ended April 30, 2024, as compared to the significant accounting policies described in our Annual Report on Form 10-K for the fiscal year ended July 31, 2023.

[0001327567-24-000017:notes:12]
Recently Issued Accounting Pronouncements

[0001327567-24-000017:notes:13]
[same as prior period, unchanged from 0001327567-24-000005:notes:13]

[0001327567-24-000017:notes:14]
[same as prior period, unchanged from 0001327567-24-000005:notes:14]

[0001327567-24-000017:notes:15]
[same as prior period, unchanged from 0001327567-24-000005:notes:15]

[0001327567-24-000017:notes:16]
[same as prior period, unchanged from 0001327567-24-000005:notes:16]


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001327567-24-000017:notes:17]
[same as prior period, unchanged from 0001327567-24-000005:notes:17]

[0001327567-24-000017:notes:18]
[same as prior period, unchanged from 0001327567-24-000005:notes:18]

[0001327567-24-000017:notes:19]
|  | Three Months Ended April 30, |  | Nine Months Ended April 30, |
|  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| Revenue: |  |  |  |  |  |  |  |
| Americas |  |  |  |  |  |  |  |
| United States | $ | 1,271.1 |  |  | $ | 1,105.2 |  |  | $ | 3,723.6 |  |  | $ | 3,153.8 |  |
| Other Americas | 88.5 |  |  | 74.0 |  |  | 256.8 |  |  | 213.1 |  |
| Total Americas | 1,359.6 |  |  | 1,179.2 |  |  | 3,980.4 |  |  | 3,366.9 |  |
| Europe, the Middle East, and Africa (“EMEA”) | 399.2 |  |  | 332.1 |  |  | 1,170.9 |  |  | 981.5 |  |
| Asia Pacific and Japan (“APAC”) | 226.0 |  |  | 209.6 |  |  | 686.7 |  |  | 591.0 |  |
| Total revenue | $ | 1,984.8 |  |  | $ | 1,720.9 |  |  | $ | 5,838.0 |  |  | $ | 4,939.4 |  |

[0001327567-24-000017:notes:20]
[same as prior period, unchanged from 0001327567-24-000005:notes:20]

[0001327567-24-000017:notes:21]
|  | Three Months Ended April 30, |  | Nine Months Ended April 30, |
|  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| Revenue: |  |  |  |  |  |  |  |
| Product | $ | 391.0 |  |  | $ | 388.1 |  |  | $ | 1,122.8 |  |  | $ | 1,071.0 |  |
| Subscription and support |  |  |  |  |  |  |  |
| Subscription | 1,045.6 |  |  | 838.1 |  |  | 3,061.0 |  |  | 2,417.5 |  |
| Support | 548.2 |  |  | 494.7 |  |  | 1,654.2 |  |  | 1,450.9 |  |
| Total subscription and support | 1,593.8 |  |  | 1,332.8 |  |  | 4,715.2 |  |  | 3,868.4 |  |
| Total revenue | $ | 1,984.8 |  |  | $ | 1,720.9 |  |  | $ | 5,838.0 |  |  | $ | 4,939.4 |  |

[0001327567-24-000017:notes:22]
[same as prior period, unchanged from 0001327567-24-000005:notes:22]

[0001327567-24-000017:notes:23]
During the nine months ended April 30, 2024 and 2023, we recognized approximately $3.7 billion and $2.9 billion of revenue pertaining to amounts that were deferred as of July 31, 2023 and 2022, respectively.

[0001327567-24-000017:notes:24]
[same as prior period, unchanged from 0001327567-24-000005:notes:24]

[0001327567-24-000017:notes:25]
Remaining performance obligations were $11.3 billion as of April 30, 2024, of which we expect to recognize as revenue approximately $5.4 billion over the next 12 months and the remainder thereafter.


## us-gaap:FairValueDisclosuresTextBlock

[0001327567-24-000017:notes:26]
Fair Value Measurements
The following table presents our financial assets and liabilities measured at fair value on a recurring basis as of April 30, 2024 and July 31, 2023 (in millions):

[0001327567-24-000017:notes:27]
|  | April 30, 2024 |  | July 31, 2023 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| Cash equivalents: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds | $ | 763.9 |  |  | $ | — |  |  | $ | — |  |  | $ | 763.9 |  |  | $ | 476.1 |  |  | $ | — |  |  | $ | — |  |  | $ | 476.1 |  |
| Commercial paper | — |  |  | 2.5 |  |  | — |  |  | 2.5 |  |  | — |  |  | 151.4 |  |  | — |  |  | 151.4 |  |
| Total cash equivalents | 763.9 |  |  | 2.5 |  |  | — |  |  | 766.4 |  |  | 476.1 |  |  | 151.4 |  |  | — |  |  | 627.5 |  |

[0001327567-24-000017:notes:28]
|  | April 30, 2024 |  | July 31, 2023 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| Short-term investments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Certificates of deposit | — |  |  | 25.5 |  |  | — |  |  | 25.5 |  |  | — |  |  | 48.1 |  |  | — |  |  | 48.1 |  |
| Commercial paper | — |  |  | 170.9 |  |  | — |  |  | 170.9 |  |  | — |  |  | 213.8 |  |  | — |  |  | 213.8 |  |
| Corporate debt securities | — |  |  | 1,251.4 |  |  | — |  |  | 1,251.4 |  |  | — |  |  | 798.0 |  |  | — |  |  | 798.0 |  |
| U.S. government and agency securities | — |  |  | 34.4 |  |  | — |  |  | 34.4 |  |  | — |  |  | 190.6 |  |  | — |  |  | 190.6 |  |
| Non-U.S. government and agency securities | — |  |  | 34.0 |  |  | — |  |  | 34.0 |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Asset-backed securities | — |  |  | 0.5 |  |  | — |  |  | 0.5 |  |  | — |  |  | 4.2 |  |  | — |  |  | 4.2 |  |
| Total short-term investments | — |  |  | 1,516.7 |  |  | — |  |  | 1,516.7 |  |  | — |  |  | 1,254.7 |  |  | — |  |  | 1,254.7 |  |
| Long-term investments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Corporate debt securities | — |  |  | 2,525.9 |  |  | — |  |  | 2,525.9 |  |  | — |  |  | 2,484.3 |  |  | — |  |  | 2,484.3 |  |
| U.S. government and agency securities | — |  |  | 50.2 |  |  | — |  |  | 50.2 |  |  | — |  |  | 22.0 |  |  | — |  |  | 22.0 |  |
| Non-U.S. government and agency securities | — |  |  | 53.0 |  |  | — |  |  | 53.0 |  |  | — |  |  | 36.6 |  |  | — |  |  | 36.6 |  |
| Asset-backed securities | — |  |  | 875.3 |  |  | — |  |  | 875.3 |  |  | — |  |  | 505.0 |  |  | — |  |  | 505.0 |  |
| Total long-term investments | — |  |  | 3,504.4 |  |  | — |  |  | 3,504.4 |  |  | — |  |  | 3,047.9 |  |  | — |  |  | 3,047.9 |  |
| Prepaid expenses and other current assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency forward contracts | — |  |  | 4.2 |  |  | — |  |  | 4.2 |  |  | — |  |  | 19.1 |  |  | — |  |  | 19.1 |  |
| Total prepaid expenses and other current assets | — |  |  | 4.2 |  |  | — |  |  | 4.2 |  |  | — |  |  | 19.1 |  |  | — |  |  | 19.1 |  |
| Other assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency forward contracts | — |  |  | 0.3 |  |  | — |  |  | 0.3 |  |  | — |  |  | 1.7 |  |  | — |  |  | 1.7 |  |
| Total other assets | — |  |  | 0.3 |  |  | — |  |  | 0.3 |  |  | — |  |  | 1.7 |  |  | — |  |  | 1.7 |  |
| Total assets measured at fair value | $ | 763.9 |  |  | $ | 5,028.1 |  |  | $ | — |  |  | $ | 5,792.0 |  |  | $ | 476.1 |  |  | $ | 4,474.8 |  |  | $ | — |  |  | $ | 4,950.9 |  |
| Accrued and other liabilities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency forward contracts | $ | — |  |  | $ | 25.3 |  |  | $ | — |  |  | $ | 25.3 |  |  | $ | — |  |  | $ | 18.7 |  |  | $ | — |  |  | $ | 18.7 |  |
| Total accrued and other liabilities | — |  |  | 25.3 |  |  | — |  |  | 25.3 |  |  | — |  |  | 18.7 |  |  | — |  |  | 18.7 |  |
| Other long-term liabilities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency forward contracts | — |  |  | 3.5 |  |  | — |  |  | 3.5 |  |  | — |  |  | 1.6 |  |  | — |  |  | 1.6 |  |
| Total other long-term liabilities | — |  |  | 3.5 |  |  | — |  |  | 3.5 |  |  | — |  |  | 1.6 |  |  | — |  |  | 1.6 |  |
| Total liabilities measured at fair value | $ | — |  |  | $ | 28.8 |  |  | $ | — |  |  | $ | 28.8 |  |  | $ | — |  |  | $ | 20.3 |  |  | $ | — |  |  | $ | 20.3 |  |

[0001327567-24-000017:notes:29]
Refer to Note 9. Debt for the carrying amount and estimated fair value of our convertible senior notes as of April 30, 2024 and July 31, 2023.


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock

[0001327567-24-000017:notes:30]
Cash Equivalents and Investments
Available-for-sale Debt Securities

[0001327567-24-000017:notes:31]
The following tables summarize the amortized cost, unrealized gains and losses, and fair value of our available-for-sale debt securities as of April 30, 2024 and July 31, 2023 (in millions):

[0001327567-24-000017:notes:32]
|  | April 30, 2024 |
|  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Fair Value |
| Cash equivalents: |  |  |  |  |  |  |  |
| Commercial paper | $ | 2.5 |  |  | $ | — |  |  | $ | — |  |  | $ | 2.5 |  |
| Total available-for-sale cash equivalents | $ | 2.5 |  |  | $ | — |  |  | $ | — |  |  | $ | 2.5 |  |
| Investments: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 25.5 |  |  | $ | — |  |  | $ | — |  |  | $ | 25.5 |  |
| Commercial paper | 171.0 |  |  | — |  |  | (0.1) |  |  | 170.9 |  |
| Corporate debt securities | 3,803.5 |  |  | 2.6 |  |  | (28.8) |  |  | 3,777.3 |  |
| U.S. government and agency securities | 85.0 |  |  | — |  |  | (0.4) |  |  | 84.6 |  |
| Non-U.S. government and agency securities | 87.9 |  |  | — |  |  | (0.9) |  |  | 87.0 |  |
| Asset-backed securities | 881.4 |  |  | 0.9 |  |  | (6.5) |  |  | 875.8 |  |
| Total available-for-sale investments | $ | 5,054.3 |  |  | $ | 3.5 |  |  | $ | (36.7) |  |  | $ | 5,021.1 |  |

[0001327567-24-000017:notes:33]
|  | July 31, 2023 |
|  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Fair Value |
| Cash equivalents: |  |  |  |  |  |  |  |
| Commercial paper | $ | 151.4 |  |  | $ | — |  |  | $ | — |  |  | $ | 151.4 |  |
| Total available-for-sale cash equivalents | $ | 151.4 |  |  | $ | — |  |  | $ | — |  |  | $ | 151.4 |  |
| Investments: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 48.1 |  |  | $ | — |  |  | $ | — |  |  | $ | 48.1 |  |
| Commercial paper | 214.1 |  |  | — |  |  | (0.3) |  |  | 213.8 |  |
| Corporate debt securities | 3,313.5 |  |  | 1.3 |  |  | (32.5) |  |  | 3,282.3 |  |
| U.S. government and agency securities | 214.2 |  |  | — |  |  | (1.6) |  |  | 212.6 |  |
| Non-U.S. government and agency securities | 37.2 |  |  | — |  |  | (0.6) |  |  | 36.6 |  |
| Asset-backed securities | 512.0 |  |  | 0.2 |  |  | (3.0) |  |  | 509.2 |  |
| Total available-for-sale investments | $ | 4,339.1 |  |  | $ | 1.5 |  |  | $ | (38.0) |  |  | $ | 4,302.6 |  |

[0001327567-24-000017:notes:34]
As of April 30, 2024, the gross unrealized losses that have been in a continuous unrealized loss position for less than 12 months were $30.3 million, which were related to $3.4 billion of available-for-sale debt securities, and the gross unrealized losses that have been in a continuous unrealized loss position for more than 12 months were $6.4 million, which were related to $722.1 million of available-for-sale debt securities. As of July 31, 2023 the gross unrealized losses that have been in a continuous unrealized loss position for less than 12 months were $30.7 million, which were related to $3.4 billion of available-for-sale debt securities, and the gross unrealized losses that have been in a continuous unrealized loss position for more than 12 months were $7.3 million, which were related to $481.8 million of available-for-sale debt securities.

[0001327567-24-000017:notes:35]
Unrealized losses related to our available-for-sale debt securities are primarily due to interest rate fluctuations as opposed to credit quality. We do not intend to sell any of the securities in an unrealized loss position and it is not likely that we would be required to sell these securities before recovery of their amortized cost basis, which may be at maturity. We did not recognize any credit losses related to our available-for-sale debt securities during the three and nine months ended April 30, 2024 and 2023.

[0001327567-24-000017:notes:36]
The following table summarizes the amortized cost and fair value of our available-for-sale debt securities as of April 30, 2024, by contractual years-to-maturity (in millions):

[0001327567-24-000017:notes:37]
|  | Amortized Cost |  | Fair Value |
| Due within one year | $ | 1,524.4 |  |  | $ | 1,519.2 |  |
| Due between one and three years | 2,125.5 |  |  | 2,109.2 |  |
| Due between three and five years | 1,134.1 |  |  | 1,124.7 |  |
| Due between five and ten years | 158.5 |  |  | 157.1 |  |
| Due after ten years | 114.3 |  |  | 113.4 |  |
| Total | $ | 5,056.8 |  |  | $ | 5,023.6 |  |

[0001327567-24-000017:notes:38]
Marketable Equity Securities

[0001327567-24-000017:notes:39]
Marketable equity securities consist of money market funds and are included in cash and cash equivalents on our condensed consolidated balance sheets. As of April 30, 2024 and July 31, 2023, the carrying values of our marketable equity securities were $763.9 million and $476.1 million, respectively. There were no unrealized gains or losses recognized for these securities during the three and nine months ended April 30, 2024 and 2023.


## us-gaap:FinancingReceivablesTextBlock

[0001327567-24-000017:notes:40]
Financing Receivables
The following table summarizes our short-term and long-term financing receivables as of April 30, 2024 and July 31, 2023 (in millions):

[0001327567-24-000017:notes:41]
|  | April 30, 2024 |  | July 31, 2023 |
| Short-term financing receivables, gross | $ | 649.5 |  |  | $ | 435.1 |  |
| Unearned income | (67.4) |  |  | (42.9) |  |
| Allowance for credit losses | (9.8) |  |  | (3.4) |  |
| Short-term financing receivables, net | $ | 572.3 |  |  | $ | 388.8 |  |
| Long-term financing receivables, gross | $ | 951.3 |  |  | $ | 698.6 |  |
| Unearned income | (59.9) |  |  | (39.2) |  |
| Allowance for credit losses | (8.9) |  |  | (6.1) |  |
| Long-term financing receivables, net | $ | 882.5 |  |  | $ | 653.3 |  |

[0001327567-24-000017:notes:42]
Our financing receivables portfolio primarily consisted of high-quality investment-grade receivables as of April 30, 2024 and July 31, 2023. There was no significant activity in allowance for credit losses during the three and nine months ended April 30, 2024 and 2023. Past due amounts on financing receivables were not material as of April 30, 2024 and July 31, 2023.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001327567-24-000017:notes:43]
[same as prior period, unchanged from 0001327567-24-000005:notes:43]

[0001327567-24-000017:notes:44]
As of April 30, 2024 and July 31, 2023, the total notional amount of our outstanding foreign currency forward contracts was $1.3 billion and $957.5 million, respectively. Refer to Note 3. Fair Value Measurements for the fair value of our derivative instruments as reported on our condensed consolidated balance sheets as of April 30, 2024 and July 31, 2023.

[0001327567-24-000017:notes:45]
As of April 30, 2024, unrealized gains and losses in accumulated other comprehensive income (“AOCI”) related to our cash flow hedges were a $19.1 million net loss, of which $13.7 million in losses are expected to be recognized into earnings within the next 12 months. As of July 31, 2023, unrealized gains and losses in AOCI related to our cash flow hedges were a $0.7 million net gain.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001327567-24-000017:notes:46]
[same as prior period, unchanged from 0001327567-24-000005:notes:46]

[0001327567-24-000017:notes:47]
[same as prior period, unchanged from 0001327567-24-000005:notes:47]

[0001327567-24-000017:notes:48]
[same as prior period, unchanged from 0001327567-24-000005:notes:48]

[0001327567-24-000017:notes:49]
[same as prior period, unchanged from 0001327567-24-000005:notes:49]

[0001327567-24-000017:notes:50]
[same as prior period, unchanged from 0001327567-24-000005:notes:50]

[0001327567-24-000017:notes:51]
[same as prior period, unchanged from 0001327567-24-000005:notes:51]

[0001327567-24-000017:notes:52]
[same as prior period, unchanged from 0001327567-24-000005:notes:52]

[0001327567-24-000017:notes:53]
[same as prior period, unchanged from 0001327567-24-000005:notes:53]

[0001327567-24-000017:notes:54]
[same as prior period, unchanged from 0001327567-24-000005:notes:54]

[0001327567-24-000017:notes:55]
[same as prior period, unchanged from 0001327567-24-000005:notes:55]

[0001327567-24-000017:notes:56]
[same as prior period, unchanged from 0001327567-24-000005:notes:56]

[0001327567-24-000017:notes:57]
[same as prior period, unchanged from 0001327567-24-000005:notes:57]

[0001327567-24-000017:notes:58]
[same as prior period, unchanged from 0001327567-24-000005:notes:58]

[0001327567-24-000017:notes:59]
[same as prior period, unchanged from 0001327567-24-000005:notes:59]

[0001327567-24-000017:notes:60]
[same as prior period, unchanged from 0001327567-24-000005:notes:60]

[0001327567-24-000017:notes:61]
[same as prior period, unchanged from 0001327567-24-000005:notes:61]


## us-gaap:ScheduleOfBusinessAcquisitionsByAcquisitionTextBlock

[0001327567-24-000017:notes:62]
[same as prior period, unchanged from 0001327567-24-000005:notes:62]

[0001327567-24-000017:notes:63]
[same as prior period, unchanged from 0001327567-24-000005:notes:63]


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001327567-24-000017:notes:64]
Goodwill and Intangible Assets
Goodwill

[0001327567-24-000017:notes:65]
The following table presents details of our goodwill during the nine months ended April 30, 2024 (in millions):

[0001327567-24-000017:notes:66]
|  | Amount |
| Balance as of July 31, 2023 | $ | 2,926.8 |  |
| Goodwill acquired | 445.9 |  |
| Balance as of April 30, 2024 | $ | 3,372.7 |  |

[0001327567-24-000017:notes:67]
[same as prior period, unchanged from 0001327567-24-000005:notes:67]

[0001327567-24-000017:notes:68]
The following table presents details of our purchased intangible assets as of April 30, 2024 and July 31, 2023 (in millions):

[0001327567-24-000017:notes:69]
|  | April 30, 2024 |  | July 31, 2023 |
|  | Gross Carrying Amount |  | Accumulated Amortization |  | Net Carrying Amount |  | Gross Carrying Amount |  | Accumulated Amortization |  | Net Carrying Amount |
| Intangible assets subject to amortization: |  |  |  |  |  |  |  |  |  |  |  |
| Developed technology | $ | 813.9 |  |  | $ | (498.7) |  |  | $ | 315.2 |  |  | $ | 633.2 |  |  | $ | (429.4) |  |  | $ | 203.8 |  |
| Customer relationships | 172.7 |  |  | (89.9) |  |  | 82.8 |  |  | 172.7 |  |  | (73.9) |  |  | 98.8 |  |
| Acquired intellectual property | 17.0 |  |  | (7.4) |  |  | 9.6 |  |  | 14.6 |  |  | (6.2) |  |  | 8.4 |  |
| Trade name and trademarks | 9.4 |  |  | (9.4) |  |  | — |  |  | 9.4 |  |  | (9.4) |  |  | — |  |
| Other | 0.9 |  |  | (0.6) |  |  | 0.3 |  |  | 0.9 |  |  | (0.4) |  |  | 0.5 |  |
| Total intangible assets subject to amortization | 1,013.9 |  |  | (606.0) |  |  | 407.9 |  |  | 830.8 |  |  | (519.3) |  |  | 311.5 |  |
| Intangible assets not subject to amortization: |  |  |  |  |  |  |  |  |  |  |  |
| In-process research and development | — |  |  | — |  |  | — |  |  | 3.9 |  | — |  |  | 3.9 |  |
| Total purchased intangible assets | $ | 1,013.9 |  |  | $ | (606.0) |  |  | $ | 407.9 |  |  | $ | 834.7 |  |  | $ | (519.3) |  |  | $ | 315.4 |  |

[0001327567-24-000017:notes:70]
We recognized amortization expense of $33.4 million and $86.7 million for the three and nine months ended April 30, 2024, respectively, and $25.8 million and $79.7 million for the three and nine months ended April 30, 2023, respectively.

[0001327567-24-000017:notes:71]
The following table summarizes estimated future amortization expense of our intangible assets subject to amortization as of April 30, 2024 (in millions):

[0001327567-24-000017:notes:72]
|  |  |  | Fiscal years ending July 31, |
|  | Total |  | Remaining 2024 |  | 2025 |  | 2026 |  | 2027 |  | 2028 |  | 2029 and Thereafter |
| Future amortization expense | $ | 407.9 |  |  | $ | 33.2 |  |  | $ | 120.7 |  |  | $ | 98.9 |  |  | $ | 71.8 |  |  | $ | 50.2 |  |  | $ | 33.1 |  |


## us-gaap:DebtDisclosureTextBlock

[0001327567-24-000017:notes:73]
Debt
Convertible Senior Notes

[0001327567-24-000017:notes:74]
In July 2018, we issued $1.7 billion aggregate principal amount of 0.75% Convertible Senior Notes due 2023 (the “2023 Notes”) and in June 2020, we issued $2.0 billion aggregate principal amount of 0.375% Convertible Senior Notes due 2025 (the “2025 Notes,” and together with the 2023 Notes, the “Notes”). The 2023 Notes were converted prior to or settled on the maturity date of July 1, 2023 in accordance with their terms. The 2025 Notes bear interest at a fixed rate of 0.375% per year, payable semi-annually in arrears on June 1 and December 1 of each year, beginning on December 1, 2020. The 2025 Notes are governed by an indenture between us, as the issuer, and U.S. Bank National Association, as Trustee (the “Indenture”). The 2025 Notes are unsecured, unsubordinated obligations and the Indenture governing the 2025 Notes does not contain any financial covenants or restrictions on the payments of dividends, the incurrence of indebtedness, or the issuance or repurchase of securities by us or any of our subsidiaries. The 2025 Notes mature on June 1, 2025. We may redeem for cash all or any portion of the 2025 Notes, at our option, on or after June 5, 2023 and prior to the 31st scheduled trading day immediately preceding the maturity date if the last reported sale price of our common stock has been at least 130% of the conversion price then in effect for at least 20 trading days during any 30 consecutive trading day period ending on and including the trading day preceding the date on which we provide notice of redemption. The redemption will be at a price equal to 100% of the principal amount of the 2025 Notes and adjusted for interest. If we call any or all of the 2025 Notes for redemption, holders may convert such 2025 Notes called for redemption at any time prior to the close of business on the second scheduled trading day immediately preceding the redemption date.

[0001327567-24-000017:notes:75]
The 2025 Notes are convertible for an initial 20.1 million shares of our common stock at a conversion rate of approximately 10.0806 shares of common stock per $1,000 principal amount, which is equal to an initial conversion price of approximately $99.20 per share of common stock, subject to adjustments. Holders of the 2025 Notes may surrender their 2025 Notes for conversion at their option at any time prior to the close of business on the business day immediately preceding March 1, 2025 only under the following circumstances:

[0001327567-24-000017:notes:76]
•during any fiscal quarter commencing after the fiscal quarters ending on October 31, 2020 (and only during such fiscal quarter), if the last reported sale price of our common stock for at least 20 trading days (whether or not consecutive) during a period of 30 consecutive trading days ending on the last trading day of the immediately preceding fiscal quarter is greater than or equal to 130% of the conversion price for the 2025 Notes on each applicable trading day (the “sale price condition”);

[0001327567-24-000017:notes:77]
•during the five business day period after any five consecutive trading day period (the “measurement period”) in which the trading price per $1,000 principal amount of the 2025 Notes for each trading day of the measurement period was less than 98% of the product of the last reported sale price of our common stock and the conversion rate for the 2025 Notes on each such trading day; or

[0001327567-24-000017:notes:78]
•upon the occurrence of specified corporate events.

[0001327567-24-000017:notes:79]
On or after March 1, 2025, holders may surrender all or any portion of their 2025 Notes for conversion at any time prior to the close of business on the second scheduled trading day immediately preceding the maturity date regardless of the foregoing conditions, and such conversions will be settled upon the maturity date. Upon conversion, holders of the 2025 Notes will receive cash equal to the aggregate principal amount of the 2025 Notes to be converted, and, at our election, cash and/or shares of our common stock for any amounts in excess of the aggregate principal amount of the 2025 Notes being converted.

[0001327567-24-000017:notes:80]
The conversion price will be subject to adjustment in some events. Holders of the 2025 Notes who convert their 2025 Notes in connection with certain corporate events that constitute a “make-whole fundamental change” under the Indenture are, under certain circumstances, entitled to an increase in the conversion rate. Additionally, upon the occurrence of a corporate event that constitutes a “fundamental change” under the Indenture, holders of the 2025 Notes may require us to repurchase for cash all or a portion of the 2025 Notes at a repurchase price equal to 100% of the principal amount of the 2025 Notes plus accrued and unpaid interest to, but excluding, the fundamental change repurchase date.

[0001327567-24-000017:notes:81]
Holders of the 2025 Notes were able to early convert their 2025 Notes during the fiscal quarter ended April 30, 2024 as the sales price condition had been met during the fiscal quarter ended January 31, 2024. During the three and nine months ended April 30, 2024, holders of the 2025 Notes converted $661.8 million and $834.1 million, respectively, in aggregate principal amount of the 2025 Notes, which we repaid in cash. We also issued 4.6 million and 5.7 million shares of our common stock to the holders of the 2025 Notes during the three and nine months ended April 30, 2024, respectively, for the conversion value in excess of the principal amount. These shares were fully offset by shares we received from the corresponding exercise of the note hedges. Refer to Note 16. Subsequent Event for additional information regarding conversion of the 2025 Notes after April 30, 2024 through the filing date of this Quarterly Report on Form 10-Q.

[0001327567-24-000017:notes:82]
The sale price condition for the 2025 Notes was met during the fiscal quarter ended April 30, 2024 and as a result, holders may convert their 2025 Notes during the fiscal quarter ending July 31, 2024. The net carrying amount of the 2025 Notes was classified as a current liability on our condensed consolidated balance sheet as of April 30, 2024.

[0001327567-24-000017:notes:83]
The following table sets forth the net carrying amount of our 2025 Notes (in millions):

[0001327567-24-000017:notes:84]
|  |  |  | April 30, 2024 | July 31, 2023 |
| Principal |  |  | $ | 1,165.2 |  |  |  |  |  |  | $ | 1,999.3 |  |  |  |
| Less: debt issuance costs, net of amortization |  |  | (2.7) |  |  |  |  |  |  | (7.8) |  |  |  |
| Net carrying amount |  |  | $ | 1,162.5 |  |  |  |  |  |  | $ | 1,991.5 |  |  |  |

[0001327567-24-000017:notes:85]
The total estimated fair value of the 2025 Notes was $3.4 billion as of April 30, 2024 and $5.0 billion as of July 31, 2023. The fair value was determined based on the closing trading price per $100 of the 2025 Notes as of the last day of trading for the period. We consider the fair value of the 2025 Notes as of April 30, 2024 and July 31, 2023 to be a Level 2 measurement. The fair value of the 2025 Notes is primarily affected by the trading price of our common stock and market interest rates.

[0001327567-24-000017:notes:86]
The following table sets forth interest expense recognized related to the Notes (dollars in millions):

[0001327567-24-000017:notes:87]
|  | Three Months Ended April 30, |  | Nine Months Ended April 30, |
|  | 2024 |  | 2023 |  | 2024 |  | 2023 |
|  | 2023 Notes |  | 2025 Notes |  | Total |  | 2023 Notes |  | 2025 Notes |  | Total |  | 2023 Notes |  | 2025 Notes |  | Total |  | 2023 Notes |  | 2025 Notes |  | Total |
| Contractual interest expense | $ | — |  |  | $ | 1.5 |  |  | $ | 1.5 |  |  | $ | 3.2 |  |  | $ | 1.8 |  |  | $ | 5.0 |  |  | $ | — |  |  | $ | 5.1 |  |  | $ | 5.1 |  |  | $ | 9.6 |  |  | $ | 5.6 |  |  | $ | 15.2 |  |
| Amortization of debt issuance costs | — |  |  | 0.8 |  |  | 0.8 |  |  | 0.7 |  |  | 1.1 |  |  | 1.8 |  |  | — |  |  | 2.9 |  |  | 2.9 |  |  | 2.1 |  |  | 3.2 |  |  | 5.3 |  |
| Total interest expense | $ | — |  |  | $ | 2.3 |  |  | $ | 2.3 |  |  | $ | 3.9 |  |  | $ | 2.9 |  |  | $ | 6.8 |  |  | $ | — |  |  | $ | 8.0 |  |  | $ | 8.0 |  |  | $ | 11.7 |  |  | $ | 8.8 |  |  | $ | 20.5 |  |
| Effective interest rate | — | % |  | 0.6 | % |  |  |  | 0.9 | % |  | 0.6 | % |  |  |  | — | % |  | 0.6 | % |  |  |  | 0.9 | % |  | 0.6 | % |  |  |

[0001327567-24-000017:notes:88]
Note Hedges

[0001327567-24-000017:notes:89]
To minimize the impact of potential economic dilution upon conversion of our convertible senior notes, we entered into separate convertible note hedge transactions (the “2023 Note Hedges,” with respect to the 2023 Notes, the “2025 Note Hedges,” with respect to the 2025 Notes, and the 2023 Note Hedges together with 2025 Note Hedges, the “Note Hedges”) with respect to our common stock concurrent with the issuance of each series of the Notes.

[0001327567-24-000017:notes:90]
Upon the settlement of the 2023 Notes, we exercised the corresponding portion of our 2023 Note Hedges during the year ended July 31, 2023 and received shares of our common stock that fully offset the shares issued in excess of the principal amount of the converted 2023 Notes. The 2023 Note Hedges expired upon maturity of the 2023 Notes.

[0001327567-24-000017:notes:91]
The 2025 Note Hedges cover up to 20.1 million shares of our common stock at a strike price per share that corresponds to the initial conversion price of the 2025 Notes, which are also subject to adjustment, and are exercisable upon conversion of the 2025 Notes. The 2025 Note Hedges will expire upon maturity of the 2025 Notes. The 2025 Note Hedges are separate transactions and are not part of the terms of the 2025 Notes. Holders of the 2025 Notes will not have any rights with respect to the 2025 Note Hedges. Any shares of our common stock receivable by us under the 2025 Note Hedges are excluded from the calculation of diluted earnings per share as they are antidilutive. We paid an aggregate amount of $370.8 million for the 2025 Note Hedges, which is included in additional paid-in capital on our condensed consolidated balance sheets.

[0001327567-24-000017:notes:92]
As a result of the conversions of the 2025 Notes settled during the three and nine months ended April 30, 2024, we exercised the corresponding portion of our 2025 Note Hedges and received 4.6 million and 5.7 million shares of our common stock during the respective periods.

[0001327567-24-000017:notes:93]
Warrants

[0001327567-24-000017:notes:94]
Separately, but concurrently with the issuance of each series of our convertible senior notes, we entered into transactions whereby we sold warrants (the “2023 Warrants,” with respect to the 2023 Notes, the “2025 Warrants,” with respect to the 2025 Notes, and the 2023 Warrants together with the 2025 Warrants, the “Warrants”) to acquire shares of our common stock, subject to anti-dilution adjustments. The 2023 Warrants and 2025 Warrants are exercisable over 60 scheduled trading days beginning October 2023 and September 2025, respectively.

[0001327567-24-000017:notes:95]
The following table presents details of our Warrants (in millions, except per share data):

[0001327567-24-000017:notes:96]
|  | Initial Number of Shares |  | Strike Price per Share |  | Aggregate Proceeds |
| 2023 Warrants | 19.1 |  |  | $ | 139.27 |  |  | $ | 145.4 |  |
| 2025 Warrants | 20.1 |  |  | $ | 136.16 |  |  | $ | 202.8 |  |

[0001327567-24-000017:notes:97]
The shares issuable under the Warrants are included in the calculation of diluted earnings per share when the average market value per share of our common stock for the reporting period exceeds the applicable strike price for such series of Warrants. The Warrants are separate transactions and are not part of either series of Notes or Note Hedges and are not remeasured through earnings each reporting period. Holders of the Notes of either series will not have any rights with respect to the Warrants. The aggregate proceeds received from the sale of the Warrants are included in additional paid-in capital on our condensed consolidated balance sheets.

[0001327567-24-000017:notes:98]
During the nine months ended April 30, 2024, we net settled all of the 2023 Warrants with 9.0 million shares of our common stock with a fair value of $2.4 billion. The number of net shares issued was determined based on the number of 2023 Warrants exercised multiplied by the difference between the strike price of the 2023 Warrants and their daily volume-weighted-average stock price.

[0001327567-24-000017:notes:99]
Revolving Credit Facility

[0001327567-24-000017:notes:100]
On April 13, 2023, we entered into a credit agreement (the “Credit Agreement”) with certain institutional lenders that provides for a $400.0 million unsecured revolving credit facility (the “Credit Facility”), with an option to increase the amount of the Credit Facility by up to an additional $350.0 million, subject to certain conditions. The Credit Facility matures on April 13, 2028.

[0001327567-24-000017:notes:101]
The borrowings under the Credit Facility bear interest, at our option, at a base rate plus a spread of 0.000% to 0.375%, or an adjusted term Secured Overnight Financing Rate (“SOFR”) plus a spread of 1.000% to 1.375%, in each case with such spread being determined based on our leverage ratio. We are obligated to pay an ongoing commitment fee on undrawn amounts at a rate of 0.090% to 0.150%, depending on our leverage ratio. The interest rates and commitment fees are also subject to upward and downward adjustments based on our progress towards the achievement of certain sustainability goals related to greenhouse gas emissions.

[0001327567-24-000017:notes:102]
As of April 30, 2024, there were no amounts outstanding and we were in compliance with all covenants under the Credit Agreement.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001327567-24-000017:notes:103]
Commitments and Contingencies
Purchase Commitments

[0001327567-24-000017:notes:104]
We have entered into various non-cancelable agreements with cloud service providers, under which we are committed to minimum or fixed purchases of certain cloud services. In addition, in order to reduce manufacturing lead times and plan for adequate supply, we have entered into agreements with manufacturing partners and component suppliers to procure inventory based on our demand forecasts. The following table presents details of the aggregate future non-cancelable purchase commitments under these agreements as of April 30, 2024 (in millions):

[0001327567-24-000017:notes:105]
|  |  |  | Fiscal years ending July 31, |
|  | Total |  | Remaining 2024 |  | 2025 |  | 2026 |  | 2027 |  | 2028 |  | 2029 and Thereafter |
| Cloud | $ | 4,338.4 |  |  | $ | 1.0 |  |  | $ | 251.8 |  |  | $ | 581.1 |  |  | $ | 518.1 |  |  | $ | 585.6 |  |  | $ | 2,400.8 |  |
| Manufacturing | 210.6 |  |  | 54.8 |  |  | 115.8 |  |  | 40.0 |  |  | — |  |  | — |  |  | — |  |
| Other | 48.5 |  |  | — |  |  | 15.6 |  |  | 13.2 |  |  | 6.3 |  |  | 6.7 |  |  | 6.7 |  |
| Total purchase commitments | $ | 4,597.5 |  |  | $ | 55.8 |  |  | $ | 383.2 |  |  | $ | 634.3 |  |  | $ | 524.4 |  |  | $ | 592.3 |  |  | $ | 2,407.5 |  |

[0001327567-24-000017:notes:106]
Additionally, we have a $146.7 million minimum purchase commitment with a cloud service provider through September 2027 with no specified annual commitments.

[0001327567-24-000017:notes:107]
Guarantee

[0001327567-24-000017:notes:108]
In October 2023, we established a multi-currency notional cash pool for a certain number of our entities with a third-party bank. As part of the notional cash pool agreement, the bank extends overdraft credit to our participating entities as needed, provided that the overall notionally pooled balance of all accounts in the pool at the end of each day is positive. In the unlikely event of a default, any overdraft balances incurred would be guaranteed by our collective entities participating in the pool.

[0001327567-24-000017:notes:109]
Litigation

[0001327567-24-000017:notes:110]
We are subject to legal proceedings, claims, tax matters, and litigation arising in the ordinary course of business, including, for instance, intellectual property and patent litigation. We accrue for contingencies when we believe that a loss is probable and that we can reasonably estimate the amount of any such loss.

[0001327567-24-000017:notes:111]
Legal matters could include speculative, substantial, or indeterminate monetary amounts. Significant judgment is required to determine both the likelihood of there being a loss and the estimated amount of a loss related to such matters, and we may be unable to estimate the reasonably possible loss or range of loss. The outcomes of outstanding legal matters are inherently unpredictable, and could, either individually or in aggregate, have a material adverse effect on us and our results of operations. To the extent there is a reasonable possibility that a loss exceeding any amounts already recognized may be incurred, we will either disclose the estimated additional loss or state that such an estimate cannot be made.

[0001327567-24-000017:notes:112]
The following matters arose in the ordinary course of business.

[0001327567-24-000017:notes:113]
Centripetal Networks, Inc. v. Palo Alto Networks

[0001327567-24-000017:notes:114]
On March 12, 2021, Centripetal Networks, Inc., filed a lawsuit against us in the United States District Court for the Eastern District of Virginia. The lawsuit alleges that our products infringe multiple Centripetal patents. We successfully challenged certain of these patents, which were found unpatentable by the U.S. Patent and Trademark Office (“PTO”). The case went to jury trial on January 22, 2024, on four patents, with three stayed pending review in the PTO. On January 31, 2024, the jury returned a verdict of non-willful infringement with a lump sum amount of $151.5 million, plus statutory interest. We have filed motions to overturn the verdict and seek a new trial, which is pending before the court. In addition, Centripetal filed infringement contentions on certain of their patents in the European Patent Office in Germany, to which we filed invalidity challenges. Those matters are still pending.

[0001327567-24-000017:notes:115]
As of April 30, 2024, we accrued $180.5 million for the verdict amount and estimated interest, which is recorded in other long-term liabilities on our condensed consolidated balance sheets. The corresponding charge was $3.7 million and $180.5 million for the three and nine months ended April 30, 2024, respectively, which is included in general and administrative expense on our condensed consolidated statements of operations.

[0001327567-24-000017:notes:116]
Finjan, Inc. v. Palo Alto Networks

[0001327567-24-000017:notes:117]
On November 4, 2014, Finjan, Inc., filed a lawsuit against us in the United States District Court for the Northern District of California. The lawsuit alleges that our products infringe multiple Finjan patents. The complaint requests injunctive relief, monetary damages, and attorneys fees. On March 11, 2024, the case was reassigned to a new judge and the October 21, 2024 trial date was vacated. A new trial date has not yet been set. We are unable, at this time, to reasonably estimate a possible loss or potential range of loss, if any.

[0001327567-24-000017:notes:118]
Taasera v. Palo Alto Networks

[0001327567-24-000017:notes:119]
On March 22, 2022, we filed a declaratory judgment action in the United States District Court for the Southern District of New York seeking a ruling that we are not infringing various Taasera patents. The parties have resolved all pending matters between them as of December 2023. The amounts paid by us to resolve these matters were not material.

[0001327567-24-000017:notes:120]
Lionra Technologies v. Palo Alto Networks

[0001327567-24-000017:notes:121]
On August 29, 2022, Lionra Technologies filed a lawsuit against us in the United States District Court for the Eastern District of Texas. The lawsuit alleges that our products infringe multiple Lionra patents. The complaint requests injunctive relief, monetary damages and attorneys fees. The patents at issue are currently under review by the U.S. Patent and Trademark Office. The May 20, 2024 trial date was vacated. A new trial date has not yet been set, but may be rescheduled to take place in the fourth quarter of fiscal 2024. We are unable, at this time, to reasonably estimate a possible loss or potential range of loss, if any.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001327567-24-000017:notes:122]
[same as prior period, unchanged from 0001327567-24-000005:notes:122]

[0001327567-24-000017:notes:123]
[same as prior period, unchanged from 0001327567-24-000005:notes:123]

[0001327567-24-000017:notes:124]
[same as prior period, unchanged from 0001327567-24-000005:notes:124]

[0001327567-24-000017:notes:125]
|  | Three Months Ended April 30, |  | Nine Months Ended April 30, |
|  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| Number of shares repurchased | 1.7 |  |  | — |  |  | 2.0 |  |  | 1.8 |  |
| Weighted average price per share(1) | $ | 293.91 |  |  | $ | — |  |  | $ | 284.00 |  |  | $ | 138.65 |  |
| Aggregate purchase price(1) | $ | 500.0 |  |  | $ | — |  |  | $ | 566.7 |  |  | $ | 250.0 |  |

[0001327567-24-000017:notes:126]
[same as prior period, unchanged from 0001327567-24-000005:notes:126]

[0001327567-24-000017:notes:127]
In addition to the share repurchase activity summarized in the table above, during the nine months ended April 30, 2023, we paid $22.7 million related to share repurchases of our common stock that were not settled as of July 31, 2022.

[0001327567-24-000017:notes:128]
As of April 30, 2024, $500.0 million remained available for future share repurchases under our current repurchase authorization. The total price of the shares repurchased and related transaction costs are reflected as a reduction to common stock and additional paid-in capital on our condensed consolidated balance sheets.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001327567-24-000017:notes:129]
[same as prior period, unchanged from 0001327567-24-000005:notes:129]

[0001327567-24-000017:notes:130]
The following table summarizes the RSU and PSU activity under our stock plans during the nine months ended April 30, 2024 (in millions, except per share amounts):

[0001327567-24-000017:notes:131]
|  | RSUs Outstanding |  | PSUs Outstanding |
|  | Number of Shares |  | Weighted-Average Grant-Date Fair Value Per Share |  |  |  | Aggregate Intrinsic Value |  | Number of Shares |  | Weighted-Average Grant-Date Fair Value Per Share |  |  |  | Aggregate Intrinsic Value |
| Balance—July 31, 2023 | 12.1 |  |  | $ | 142.61 |  |  |  |  | $ | 3,013.0 |  |  | 5.0 |  |  | $ | 128.64 |  |  |  |  | $ | 1,242.3 |  |
| Granted(1) | 3.8 |  |  | $ | 271.65 |  |  |  |  |  |  | 2.2 |  |  | $ | 182.79 |  |  |  |  |  |
| Vested | (4.6) |  |  | $ | 131.05 |  |  |  |  |  |  | (1.5) |  |  | $ | 116.51 |  |  |  |  |  |
| Forfeited | (1.0) |  |  | $ | 161.26 |  |  |  |  |  |  | (0.5) |  |  | $ | 135.54 |  |  |  |  |  |
| Balance—April 30, 2024 | 10.3 |  |  | $ | 194.03 |  |  |  |  | $ | 2,979.7 |  |  | 5.2 |  |  | $ | 154.42 |  |  |  |  | $ | 1,497.3 |  |

[0001327567-24-000017:notes:132]
[same as prior period, unchanged from 0001327567-24-000005:notes:132]

[0001327567-24-000017:notes:133]
[same as prior period, unchanged from 0001327567-24-000005:notes:133]

[0001327567-24-000017:notes:134]
[same as prior period, unchanged from 0001327567-24-000005:notes:134]

[0001327567-24-000017:notes:135]
During the nine months ended April 30, 2024, we granted 2.1 million shares of PSUs that contain service, performance, and market conditions. The service conditions are satisfied after a period of one to three years. The performance conditions are based on revenue growth or billing growth. The market condition is measured based on our total shareholder return (“TSR”) relative to the TSR of the companies listed in the Standard & Poor’s 500 index. As of April 30, 2024, we have approved 2.7 million shares of PSUs, which will be granted upon the performance condition being established during the next two fiscal years.

[0001327567-24-000017:notes:136]
The fair value of the PSUs subject to market conditions is estimated on the grant date using a Monte Carlo simulation model. The following table summarizes the assumptions used and the resulting grant-date fair value of our PSUs subject to market conditions granted during the nine months ended April 30, 2024:

[0001327567-24-000017:notes:137]
|  |  |  |  |  | Nine Months Ended April 30, 2024 |  |  |
| Volatility |  |  |  |  | 40.8% - 43.4% |  |  |
| Expected term (in years) |  |  |  |  | 0.9 - 2.9 |  |  |
| Dividend yield |  |  |  |  | 0.0 | % |  |  |
| Risk-free interest rate |  |  |  |  | 4.4% - 5.3% |  |  |
| Grant-date fair value per share |  |  |  |  | $346.92 - $621.21 |  |  |

[0001327567-24-000017:notes:138]
[same as prior period, unchanged from 0001327567-24-000005:notes:138]

[0001327567-24-000017:notes:139]
We have granted PSOs with both service and market conditions. The market conditions were achieved when certain stock price targets were met. As of April 30, 2024, all of our outstanding PSOs have been fully vested. The maximum contractual term of our outstanding PSOs is seven and a half years from the date of grant in fiscal year 2018 and 2019.

[0001327567-24-000017:notes:140]
The following table summarizes the PSO activity under our stock plans during the nine months ended April 30, 2024 (in millions, except per share amounts):

[0001327567-24-000017:notes:141]
|  |  |  |  |  |  |  |  |  | Number of Shares |  | Weighted-Average Exercise Price Per Share |  | Weighted-Average Remaining Contractual Term (Years) |  | Aggregate Intrinsic Value |
| Balance—July 31, 2023 |  |  |  |  |  |  |  |  | 6.4 |  |  | $ | 65.20 |  |  | 2.2 |  | $ | 1,184.6 |  |
| Exercised |  |  |  |  |  |  |  |  | (1.2) |  |  | $ | 64.85 |  |  |  |  |  |
| Balance—April 30, 2024 |  |  |  |  |  |  |  |  | 5.2 |  |  | $ | 65.29 |  |  | 1.5 |  | $ | 1,168.4 |  |
| Exercisable—April 30, 2024 |  |  |  |  |  |  |  |  | 5.2 |  |  | $ | 65.29 |  |  | 1.5 |  | $ | 1,168.4 |  |

[0001327567-24-000017:notes:142]
[same as prior period, unchanged from 0001327567-24-000005:notes:142]

[0001327567-24-000017:notes:143]
[same as prior period, unchanged from 0001327567-24-000005:notes:143]

[0001327567-24-000017:notes:144]
|  | Three Months Ended April 30, |  | Nine Months Ended April 30, |
|  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| Cost of product revenue | $ | 1.6 |  |  | $ | 2.5 |  |  | $ | 6.3 |  |  | $ | 7.5 |  |
| Cost of subscription and support revenue | 30.0 |  |  | 32.0 |  |  | 91.3 |  |  | 91.5 |  |
| Research and development | 128.2 |  |  | 125.4 |  |  | 386.9 |  |  | 373.1 |  |
| Sales and marketing | 74.3 |  |  | 80.5 |  |  | 229.1 |  |  | 256.3 |  |
| General and administrative | 29.4 |  |  | 36.8 |  |  | 96.2 |  |  | 104.7 |  |
| Total share-based compensation | $ | 263.5 |  |  | $ | 277.2 |  |  | $ | 809.8 |  |  | $ | 833.1 |  |

[0001327567-24-000017:notes:145]
As of April 30, 2024, total compensation cost related to unvested share-based awards not yet recognized was $2.2 billion. This cost is expected to be amortized over a weighted-average period of approximately 2.7 years.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001327567-24-000017:notes:146]
Income Taxes
For the three and nine months ended April 30, 2024, our benefit from income taxes reflected an effective tax rate of negative 11.0% and negative 231.7%, respectively. Our effective tax rates for the three months ended April 30, 2024 differed from the U.S. statutory tax rate primarily due to excess tax benefits from share-based compensation and the release of our valuation allowance. Our effective tax rates for the nine months ended April 30, 2024 differed from the U.S. statutory tax rate primarily due to the release of our valuation allowance.

[0001327567-24-000017:notes:147]
We regularly assess the need for a valuation allowance on our deferred tax assets. In making this assessment, we consider both positive and negative evidence related to the likelihood of realization of the deferred tax assets to determine, based on the weight of available evidence, whether it is more likely than not that some or all the deferred tax assets will not be realized. Based on our analysis of all positive and negative evidence during the fiscal quarter ended January 31, 2024, we concluded it is more likely than not that our U.S. federal, U.S. states other than California, and United Kingdom deferred tax assets will be realizable based on our recent profitability and continued forecasted income. In making these judgments, we considered our recent and expected ongoing profitability, which supports our conclusion of the realization of the deferred tax assets. We continue to maintain a valuation allowance for our California deferred tax assets due to the uncertainty regarding realizability of these deferred tax assets as they have not met the “more likely than not” realization criterion. We expect future research and development tax credit generation in California to exceed our ability to use the existing tax credits.

[0001327567-24-000017:notes:148]
As a result of the valuation allowance release, during the three and nine months ended April 30, 2024, we recognized a deferred tax benefit of $40.0 million and $3.3 billion, respectively, for the U.S. federal, U.S. states other than California, and United Kingdom deferred tax assets. Our U.S. federal and state deferred tax assets largely consist of capitalized research expenditures and accelerated recognition of deferred revenue for tax purposes. U.S. tax carryforwards (including net operating losses and tax credits) are expected to be fully utilized to the extent allowable by law. Our United Kingdom deferred tax assets largely consist of basis differences in intangible assets and related net operating losses expected to be utilized in the future.

[0001327567-24-000017:notes:149]
In addition, during the three and nine months ended April 30, 2024, we recognized a deferred tax expense of $7.4 million and $1.7 billion, respectively, for the U.S. federal indirect effect of foreign deferred taxes consistent with our policy to record deferred tax assets for basis differences relating to our global intangible low-taxed income. Accordingly, during the three and nine months ended April 30, 2024, we recognized a net tax benefit of $32.6 million and $1.6 billion, respectively, relating to our valuation allowance release. We will continue to monitor the need for a valuation allowance on our deferred tax assets.

[0001327567-24-000017:notes:150]
For the three and nine months ended April 30, 2023, our provision for income taxes reflected an effective tax rate of 17.7% and 15.1%, respectively. Our income taxes for the three and nine months ended April 30, 2023 were primarily due to U.S. federal and state income taxes, withholding taxes, and foreign income taxes. Our effective tax rates differed from the U.S. statutory tax rate primarily due to an increase in current taxes driven by capitalization of research and development expenditures with no offsetting deferred benefit as a result of our valuation allowance. This increase was offset by a tax benefit from a release of tax reserves related to uncertain tax positions resulting from an agreement with a non-U.S. tax authority to pay $28.9 million to settle a tax audit during the nine months ended April 30, 2023.


## us-gaap:EarningsPerShareTextBlock

[0001327567-24-000017:notes:151]
[same as prior period, unchanged from 0001327567-24-000005:notes:149]

[0001327567-24-000017:notes:152]
[same as prior period, unchanged from 0001327567-24-000005:notes:150]

[0001327567-24-000017:notes:153]
|  | Three Months Ended April 30, |  | Nine Months Ended April 30, |
|  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| Net income | $ | 278.8 |  |  | $ | 107.8 |  |  | $ | 2,219.9 |  |  | $ | 212.0 |  |
| Weighted-average shares used to compute net income per share, basic | 322.9 |  |  | 303.9 |  |  | 317.5 |  |  | 302.0 |  |
| Weighted-average effect of potentially dilutive securities: |  |  |  |  |  |  |  |
| Convertible senior notes | 9.5 |  |  | 19.3 |  |  | 11.4 |  |  | 17.4 |  |
| Warrants related to the issuance of convertible senior notes | 11.0 |  |  | 10.0 |  |  | 13.2 |  |  | 7.3 |  |
| Employee equity incentive plans | 11.2 |  |  | 11.5 |  |  | 11.9 |  |  | 11.4 |  |
| Weighted-average shares used to compute net income per share, diluted | 354.6 |  |  | 344.7 |  |  | 354.0 |  |  | 338.1 |  |
| Net income per share, basic | $ | 0.86 |  |  | $ | 0.35 |  |  | $ | 6.99 |  |  | $ | 0.70 |  |
| Net income per share, diluted | $ | 0.79 |  |  | $ | 0.31 |  |  | $ | 6.27 |  |  | $ | 0.63 |  |

[0001327567-24-000017:notes:154]
[same as prior period, unchanged from 0001327567-24-000005:notes:152]

[0001327567-24-000017:notes:155]
|  | Three Months Ended April 30, |  | Nine Months Ended April 30, |
|  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| Employee equity incentive plans | 2.4 |  |  | 3.2 |  |  | 2.4 |  |  | 5.0 |  |


## us-gaap:OtherNonoperatingIncomeAndExpenseTextBlock

[0001327567-24-000017:notes:156]
[same as prior period, unchanged from 0001327567-24-000005:notes:154]

[0001327567-24-000017:notes:157]
|  | Three Months Ended April 30, |  | Nine Months Ended April 30, |
|  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| Interest income | $ | 78.3 |  |  | $ | 65.9 |  |  | $ | 234.8 |  |  | $ | 151.9 |  |
| Foreign currency exchange gains (losses), net | 4.3 |  |  | (2.2) |  |  | 2.9 |  |  | (5.1) |  |
| Other, net | (5.8) |  |  | (3.6) |  |  | (5.9) |  |  | (9.3) |  |
| Total other income, net | $ | 76.8 |  |  | $ | 60.1 |  |  | $ | 231.8 |  |  | $ | 137.5 |  |


## us-gaap:SubsequentEventsTextBlock

[0001327567-24-000017:notes:158]
Subsequent Event
2025 Notes Conversion

[0001327567-24-000017:notes:159]
Subsequent to April 30, 2024, $123.2 million in aggregate principal amount of the 2025 Notes was converted or had been submitted by the holders for conversion and will settle during the fiscal quarter ending July 31, 2024.

[0001327567-24-000017:notes:160]
Acquisition

[0001327567-24-000017:notes:161]
On May 15, 2024, we entered into a definitive agreement with International Business Machines Corporation to acquire certain QRadar assets including intellectual property, customer relationships, and customer contracts. We agreed to pay $500.0 million in cash upon closing, and may make additional post-closing payments contingent upon the migration of QRadar on-premise customers to Cortex XSIAM through December 31, 2027. We expect the acquisition will help accelerate the growth of our Cortex XSIAM platform.

[0001327567-24-000017:notes:162]
The proposed acquisition is expected to close during our first quarter of fiscal 2025, subject to the satisfaction of regulatory approvals and other customary closing conditions.


## ecd:MtrlTermsOfTrdArrTextBlock

[0001327567-24-000017:notes:163]
Set forth below is certain information regarding Rule 10b5-1 trading plans adopted or terminated by our directors and officers (as defined in Rule 16a-1(f)) during the third quarter of fiscal 2024. The Rule 10b5-1 trading plans listed below are each intended to satisfy the affirmative defense of Rule 10b5-1(c).

[0001327567-24-000017:notes:164]
| Name |  | Title |  | Date Plan Was Adopted |  | Date Plan was Terminated |  | Expiration Date |  | Total Amount of Common Stock to be Sold Under the Plan |
| Nikesh Arora |  | Chief Executive Officer |  | March 27, 2024 |  | Not applicable |  | December 31, 2025 or when all shares have been sold |  | 2,444,760 |
| William “BJ” Jenkins |  | President |  | March 26, 2024 |  | Not applicable |  | June 30, 2025 or when all shares have been sold |  | 8,054 |
| Nir Zuk |  | Executive Vice President, Chief Technology Officer |  | April 1, 2024 |  | Not applicable |  | June 30, 2025 or when all shares have been sold |  | 432,000 |
