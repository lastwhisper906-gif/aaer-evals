# PANW note change history — 0001327567-24-000005 → 0001327567-24-000017


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2024-05-21):
[0001327567-24-000017:note_history:1]
We have entered into various non-cancelable agreements with cloud service providers, under which we are committed to minimum or fixed purchases of certain cloud services. In addition, in order to reduce manufacturing lead times and plan for adequate supply, we have entered into agreements with manufacturing partners and component suppliers to procure inventory based on our demand forecasts. The following table presents details of the aggregate future non-cancelable purchase commitments under these agreements as of April 30, 2024 (in millions):
  (was, 2024-02-21, similarity 0.989):
[0001327567-24-000005:note_history:1]
We have entered into various non-cancelable agreements with cloud service providers, under which we are committed to minimum or fixed purchases of certain cloud services. In addition, in order to reduce manufacturing lead times and plan for adequate supply, we have entered into agreements with manufacturing partners and component suppliers to procure inventory based on our demand forecasts. The following table presents details of the aggregate future non-cancelable purchase commitments under these agreements as of January 31, 2024 (in millions):

- changed (2024-05-21):
[0001327567-24-000017:note_history:2]
|  |  |  | Fiscal years ending July 31, |
|  | Total |  | Remaining 2024 |  | 2025 |  | 2026 |  | 2027 |  | 2028 |  | 2029 and Thereafter |
| Cloud | $ | 4,338.4 |  |  | $ | 1.0 |  |  | $ | 251.8 |  |  | $ | 581.1 |  |  | $ | 518.1 |  |  | $ | 585.6 |  |  | $ | 2,400.8 |  |
| Manufacturing | 210.6 |  |  | 54.8 |  |  | 115.8 |  |  | 40.0 |  |  | — |  |  | — |  |  | — |  |
| Other | 48.5 |  |  | — |  |  | 15.6 |  |  | 13.2 |  |  | 6.3 |  |  | 6.7 |  |  | 6.7 |  |
| Total purchase commitments | $ | 4,597.5 |  |  | $ | 55.8 |  |  | $ | 383.2 |  |  | $ | 634.3 |  |  | $ | 524.4 |  |  | $ | 592.3 |  |  | $ | 2,407.5 |  |
  (was, 2024-02-21, similarity 0.9978):
[0001327567-24-000005:note_history:2]
|  |  |  | Fiscal years ending July 31, |
|  | Total |  | Remaining 2024 |  | 2025 |  | 2026 |  | 2027 |  | 2028 |  | 2029 and Thereafter |
| Cloud | $ | 4,793.3 |  |  | $ | 0.6 |  |  | $ | 419.8 |  |  | $ | 868.4 |  |  | $ | 518.1 |  |  | $ | 585.6 |  |  | $ | 2,400.8 |  |
| Manufacturing | 218.9 |  |  | 109.3 |  |  | 69.6 |  |  | 40.0 |  |  | — |  |  | — |  |  | — |  |
| Other | 34.7 |  |  | 4.8 |  |  | 9.8 |  |  | 7.2 |  |  | 3.0 |  |  | 3.2 |  |  | 6.7 |  |
| Total purchase commitments | $ | 5,046.9 |  |  | $ | 114.7 |  |  | $ | 499.2 |  |  | $ | 915.6 |  |  | $ | 521.1 |  |  | $ | 588.8 |  |  | $ | 2,407.5 |  |

- added (2024-05-21):
[0001327567-24-000017:note_history:3]
On March 12, 2021, Centripetal Networks, Inc., filed a lawsuit against us in the United States District Court for the Eastern District of Virginia. The lawsuit alleges that our products infringe multiple Centripetal patents. We successfully challenged certain of these patents, which were found unpatentable by the U.S. Patent and Trademark Office (“PTO”). The case went to jury trial on January 22, 2024, on four patents, with three stayed pending review in the PTO. On January 31, 2024, the jury returned a verdict of non-willful infringement with a lump sum amount of $151.5 million, plus statutory interest. We have filed motions to overturn the verdict and seek a new trial, which is pending before the court. In addition, Centripetal filed infringement contentions on certain of their patents in the European Patent Office in Germany, to which we filed invalidity challenges. Those matters are still pending.

- changed (2024-05-21):
[0001327567-24-000017:note_history:4]
As of April 30, 2024, we accrued $180.5 million for the verdict amount and estimated interest, which is recorded in other long-term liabilities on our condensed consolidated balance sheets. The corresponding charge was $3.7 million and $180.5 million for the three and nine months ended April 30, 2024, respectively, which is included in general and administrative expense on our condensed consolidated statements of operations.
  (was, 2024-02-21, similarity 0.7591):
[0001327567-24-000005:note_history:4]
As of January 31, 2024, we accrued $176.8 million for the verdict amount and estimated interest. The accrual was recorded in other long-term liabilities on our condensed consolidated balance sheets with the corresponding charge included in general and administrative expense on our condensed consolidated statements of operations for the three and six months ended January 31, 2024.

- changed (2024-05-21):
[0001327567-24-000017:note_history:5]
On November 4, 2014, Finjan, Inc., filed a lawsuit against us in the United States District Court for the Northern District of California. The lawsuit alleges that our products infringe multiple Finjan patents. The complaint requests injunctive relief, monetary damages, and attorneys fees. On March 11, 2024, the case was reassigned to a new judge and the October 21, 2024 trial date was vacated. A new trial date has not yet been set. We are unable, at this time, to reasonably estimate a possible loss or potential range of loss, if any.
  (was, 2024-02-21, similarity 0.833):
[0001327567-24-000005:note_history:5]
On November 4, 2014, Finjan, Inc., filed a lawsuit against us in the United States District Court for the Northern District of California. The lawsuit alleges that our products infringe multiple Finjan patents. The complaint requests injunctive relief, monetary damages, and attorneys fees. The trial is set for October 21, 2024. We are unable, at this time, to reasonably estimate a possible loss or potential range of loss, if any.

- changed (2024-05-21):
[0001327567-24-000017:note_history:6]
On March 22, 2022, we filed a declaratory judgment action in the United States District Court for the Southern District of New York seeking a ruling that we are not infringing various Taasera patents. The parties have resolved all pending matters between them as of December 2023. The amounts paid by us to resolve these matters were not material.
  (was, 2024-02-21, similarity 0.9941):
[0001327567-24-000005:note_history:6]
On March 22, 2022, we filed a declaratory judgment action in the United States District Court for the Southern District of New York seeking a ruling that we are not infringing various Taasera patents. The parties have now resolved all pending matters between them as of December 2023. The amounts paid by us to resolve these matters were not material.

- added (2024-05-21):
[0001327567-24-000017:note_history:7]
On August 29, 2022, Lionra Technologies filed a lawsuit against us in the United States District Court for the Eastern District of Texas. The lawsuit alleges that our products infringe multiple Lionra patents. The complaint requests injunctive relief, monetary damages and attorneys fees. The patents at issue are currently under review by the U.S. Patent and Trademark Office. The May 20, 2024 trial date was vacated. A new trial date has not yet been set, but may be rescheduled to take place in the fourth quarter of fiscal 2024. We are unable, at this time, to reasonably estimate a possible loss or potential range of loss, if any.

- removed (2024-05-21):
[0001327567-24-000005:note_history:8]
On March 12, 2021, Centripetal Networks, Inc., filed a lawsuit against us in the United States District Court for the Eastern District of Virginia. The lawsuit alleges that our products infringe multiple Centripetal patents. We successfully challenged certain of these patents, which were found unpatentable by the U.S. Patent and Trademark Office (“PTO”). The case went to jury trial on January 22, 2024, on four patents, with three stayed pending review in the PTO. On January 31, 2024, the jury returned a verdict of non-willful infringement with a lump sum amount of $151.5 million, plus statutory interest. We are advancing post-trial motions that aim to eliminate patents and patent claims from the scope of the final judgment and corresponding damages. The trial judge will decide these motions before entering final judgment, after which there will likely be an appeal by one or both parties to the action. We respectfully disagree with the verdict and believe that it is contrary to both the law and the extensive evidence presented at trial, which is why we are seeking relief from the court. In addition, Centripetal filed infringement contentions on certain of their patents in the European Patent Office in Germany, to which we filed invalidity challenges. Those matters are still pending.

- removed (2024-05-21):
[0001327567-24-000005:note_history:9]
On August 29, 2022, Lionra Technologies filed a lawsuit against us in the United States District Court for the Eastern District of Texas. The lawsuit alleges that our products infringe multiple Lionra patents. The complaint requests injunctive relief, monetary damages and attorneys fees. The patents at issue are currently under review before the U.S. Patent and Trademark Office. Trial is set for May 20, 2024. We are unable, at this time, to reasonably estimate a possible loss or potential range of loss, if any.


## us-gaap:OrganizationConsolidationBasisOfPresentationBusinessDescriptionAndAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2024-05-21):
[0001327567-24-000017:note_history:10]
There have been no material changes to our significant accounting policies as of and for the nine months ended April 30, 2024, as compared to the significant accounting policies described in our Annual Report on Form 10-K for the fiscal year ended July 31, 2023.
  (was, 2024-02-21, similarity 0.9058):
[0001327567-24-000005:note_history:10]
There have been no material changes to our significant accounting policies as of and for the six months ended January 31, 2024, as compared to the significant accounting policies described in our Annual Report on Form 10-K for the fiscal year ended July 31, 2023.


## us-gaap:ConvertibleDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2024-05-21):
[0001327567-24-000017:note_history:11]
|  |  |  | April 30, 2024 | July 31, 2023 |
| Principal |  |  | $ | 1,165.2 |  |  |  |  |  |  | $ | 1,999.3 |  |  |  |
| Less: debt issuance costs, net of amortization |  |  | (2.7) |  |  |  |  |  |  | (7.8) |  |  |  |
| Net carrying amount |  |  | $ | 1,162.5 |  |  |  |  |  |  | $ | 1,991.5 |  |  |  |
  (was, 2024-02-21, similarity 0.9739):
[0001327567-24-000005:note_history:11]
|  |  |  | January 31, 2024 | July 31, 2023 |
| Principal |  |  | $ | 1,827.0 |  |  |  |  |  |  | $ | 1,999.3 |  |  |  |
| Less: debt issuance costs, net of amortization |  |  | (5.2) |  |  |  |  |  |  | (7.8) |  |  |  |
| Net carrying amount |  |  | $ | 1,821.8 |  |  |  |  |  |  | $ | 1,991.5 |  |  |  |


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2024-05-21):
[0001327567-24-000017:note_history:12]
Holders of the 2025 Notes were able to early convert their 2025 Notes during the fiscal quarter ended April 30, 2024 as the sales price condition had been met during the fiscal quarter ended January 31, 2024. During the three and nine months ended April 30, 2024, holders of the 2025 Notes converted $661.8 million and $834.1 million, respectively, in aggregate principal amount of the 2025 Notes, which we repaid in cash. We also issued 4.6 million and 5.7 million shares of our common stock to the holders of the 2025 Notes during the three and nine months ended April 30, 2024, respectively, for the conversion value in excess of the principal amount. These shares were fully offset by shares we received from the corresponding exercise of the note hedges. Refer to Note 16. Subsequent Event for additional information regarding conversion of the 2025 Notes after April 30, 2024 through the filing date of this Quarterly Report on Form 10-Q.
  (was, 2024-02-21, similarity 0.8783):
[0001327567-24-000005:note_history:12]
Holders of the 2025 Notes were able to early convert their 2025 Notes during the fiscal quarter ended January 31, 2024 as the sales price condition had been met during the fiscal quarter ended October 31, 2023. During the three and six months ended January 31, 2024, holders of the 2025 Notes converted $126.3 million and $172.3 million, respectively, in aggregate principal amount of the 2025 Notes, which we repaid in cash. We also issued 0.8 million and 1.1 million shares of our common stock to the holders of the 2025 Notes during the three and six months ended January 31, 2024, respectively, for the conversion value in excess of the principal amount. These shares were fully offset by shares we received from the corresponding exercise of the associated note hedges. Refer to Note 16. Subsequent Event for additional information regarding conversion of the 2025 Notes after January 31, 2024 through the filing date of this Quarterly Report on Form 10-Q.

- added (2024-05-21):
[0001327567-24-000017:note_history:13]
The sale price condition for the 2025 Notes was met during the fiscal quarter ended April 30, 2024 and as a result, holders may convert their 2025 Notes during the fiscal quarter ending July 31, 2024. The net carrying amount of the 2025 Notes was classified as a current liability on our condensed consolidated balance sheet as of April 30, 2024.

- changed (2024-05-21):
[0001327567-24-000017:note_history:14]
|  |  |  | April 30, 2024 | July 31, 2023 |
| Principal |  |  | $ | 1,165.2 |  |  |  |  |  |  | $ | 1,999.3 |  |  |  |
| Less: debt issuance costs, net of amortization |  |  | (2.7) |  |  |  |  |  |  | (7.8) |  |  |  |
| Net carrying amount |  |  | $ | 1,162.5 |  |  |  |  |  |  | $ | 1,991.5 |  |  |  |
  (was, 2024-02-21, similarity 0.9739):
[0001327567-24-000005:note_history:14]
|  |  |  | January 31, 2024 | July 31, 2023 |
| Principal |  |  | $ | 1,827.0 |  |  |  |  |  |  | $ | 1,999.3 |  |  |  |
| Less: debt issuance costs, net of amortization |  |  | (5.2) |  |  |  |  |  |  | (7.8) |  |  |  |
| Net carrying amount |  |  | $ | 1,821.8 |  |  |  |  |  |  | $ | 1,991.5 |  |  |  |

- added (2024-05-21):
[0001327567-24-000017:note_history:15]
The total estimated fair value of the 2025 Notes was $3.4 billion as of April 30, 2024 and $5.0 billion as of July 31, 2023. The fair value was determined based on the closing trading price per $100 of the 2025 Notes as of the last day of trading for the period. We consider the fair value of the 2025 Notes as of April 30, 2024 and July 31, 2023 to be a Level 2 measurement. The fair value of the 2025 Notes is primarily affected by the trading price of our common stock and market interest rates.

- changed (2024-05-21):
[0001327567-24-000017:note_history:16]
|  | Three Months Ended April 30, |  | Nine Months Ended April 30, |
|  | 2024 |  | 2023 |  | 2024 |  | 2023 |
|  | 2023 Notes |  | 2025 Notes |  | Total |  | 2023 Notes |  | 2025 Notes |  | Total |  | 2023 Notes |  | 2025 Notes |  | Total |  | 2023 Notes |  | 2025 Notes |  | Total |
| Contractual interest expense | $ | — |  |  | $ | 1.5 |  |  | $ | 1.5 |  |  | $ | 3.2 |  |  | $ | 1.8 |  |  | $ | 5.0 |  |  | $ | — |  |  | $ | 5.1 |  |  | $ | 5.1 |  |  | $ | 9.6 |  |  | $ | 5.6 |  |  | $ | 15.2 |  |
| Amortization of debt issuance costs | — |  |  | 0.8 |  |  | 0.8 |  |  | 0.7 |  |  | 1.1 |  |  | 1.8 |  |  | — |  |  | 2.9 |  |  | 2.9 |  |  | 2.1 |  |  | 3.2 |  |  | 5.3 |  |
| Total interest expense | $ | — |  |  | $ | 2.3 |  |  | $ | 2.3 |  |  | $ | 3.9 |  |  | $ | 2.9 |  |  | $ | 6.8 |  |  | $ | — |  |  | $ | 8.0 |  |  | $ | 8.0 |  |  | $ | 11.7 |  |  | $ | 8.8 |  |  | $ | 20.5 |  |
| Effective interest rate | — | % |  | 0.6 | % |  |  |  | 0.9 | % |  | 0.6 | % |  |  |  | — | % |  | 0.6 | % |  |  |  | 0.9 | % |  | 0.6 | % |  |  |
  (was, 2024-02-21, similarity 0.9764):
[0001327567-24-000005:note_history:16]
|  | Three Months Ended January 31, |  | Six Months Ended January 31, |
|  | 2024 |  | 2023 |  | 2024 |  | 2023 |
|  | 2023 Notes |  | 2025 Notes |  | Total |  | 2023 Notes |  | 2025 Notes |  | Total |  | 2023 Notes |  | 2025 Notes |  | Total |  | 2023 Notes |  | 2025 Notes |  | Total |
| Contractual interest expense | $ | — |  |  | $ | 1.7 |  |  | $ | 1.7 |  |  | $ | 3.2 |  |  | $ | 2.0 |  |  | $ | 5.2 |  |  | $ | — |  |  | $ | 3.6 |  |  | $ | 3.6 |  |  | $ | 6.4 |  |  | $ | 3.8 |  |  | $ | 10.2 |  |
| Amortization of debt issuance costs | — |  |  | 1.1 |  |  | 1.1 |  |  | 0.7 |  |  | 1.0 |  |  | 1.7 |  |  | — |  |  | 2.1 |  |  | 2.1 |  |  | 1.4 |  |  | 2.1 |  |  | 3.5 |  |
| Total interest expense | $ | — |  |  | $ | 2.8 |  |  | $ | 2.8 |  |  | $ | 3.9 |  |  | $ | 3.0 |  |  | $ | 6.9 |  |  | $ | — |  |  | $ | 5.7 |  |  | $ | 5.7 |  |  | $ | 7.8 |  |  | $ | 5.9 |  |  | $ | 13.7 |  |
| Effective interest rate | — | % |  | 0.6 | % |  |  |  | 0.9 | % |  | 0.6 | % |  |  |  | — | % |  | 0.6 | % |  |  |  | 0.9 | % |  | 0.6 | % |  |  |

- changed (2024-05-21):
[0001327567-24-000017:note_history:17]
As a result of the conversions of the 2025 Notes settled during the three and nine months ended April 30, 2024, we exercised the corresponding portion of our 2025 Note Hedges and received 4.6 million and 5.7 million shares of our common stock during the respective periods.
  (was, 2024-02-21, similarity 0.9066):
[0001327567-24-000005:note_history:17]
As a result of the conversions of the 2025 Notes settled during the three and six months ended January 31, 2024, we exercised the corresponding portion of our 2025 Note Hedges and received 0.8 million and 1.1 million shares of our common stock during the respective period.

- added (2024-05-21):
[0001327567-24-000017:note_history:18]
During the nine months ended April 30, 2024, we net settled all of the 2023 Warrants with 9.0 million shares of our common stock with a fair value of $2.4 billion. The number of net shares issued was determined based on the number of 2023 Warrants exercised multiplied by the difference between the strike price of the 2023 Warrants and their daily volume-weighted-average stock price.

- changed (2024-05-21):
[0001327567-24-000017:note_history:19]
As of April 30, 2024, there were no amounts outstanding and we were in compliance with all covenants under the Credit Agreement.
  (was, 2024-02-21, similarity 0.9675):
[0001327567-24-000005:note_history:19]
As of January 31, 2024, there were no amounts outstanding and we were in compliance with all covenants under the Credit Agreement.

- removed (2024-05-21):
[0001327567-24-000005:note_history:20]
The sale price condition for the 2025 Notes was met during the fiscal quarter ended January 31, 2024 and as a result, holders may convert their 2025 Notes during the fiscal quarter ending April 30, 2024. The net carrying amount of the 2025 Notes was classified as a current liability on our condensed consolidated balance sheet as of January 31, 2024.

- removed (2024-05-21):
[0001327567-24-000005:note_history:21]
The total estimated fair value of the 2025 Notes was $6.2 billion as of January 31, 2024 and $5.0 billion as of July 31, 2023. The fair value was determined based on the closing trading price per $100 of the 2025 Notes as of the last day of trading for the period. We consider the fair value of the 2025 Notes as of January 31, 2024 and July 31, 2023 to be a Level 2 measurement. The fair value of the 2025 Notes is primarily affected by the trading price of our common stock and market interest rates.

- removed (2024-05-21):
[0001327567-24-000005:note_history:22]
During the six months ended January 31, 2024, we net settled all of the 2023 Warrants with 9.0 million shares of our common stock with a fair value of $2.4 billion, of which 5.9 million shares of our common stock with a fair value of $1.7 billion were net settled during the three months ended January 31, 2024. The number of net shares issued was determined based on the number of 2023 Warrants exercised multiplied by the difference between the strike price of the 2023 Warrants and their daily volume-weighted-average stock price.


## us-gaap:DebtSecuritiesAvailableForSaleTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2024-05-21):
[0001327567-24-000017:note_history:23]
The following tables summarize the amortized cost, unrealized gains and losses, and fair value of our available-for-sale debt securities as of April 30, 2024 and July 31, 2023 (in millions):
  (was, 2024-02-21, similarity 0.9779):
[0001327567-24-000005:note_history:23]
The following tables summarize the amortized cost, unrealized gains and losses, and fair value of our available-for-sale debt securities as of January 31, 2024 and July 31, 2023 (in millions):

- changed (2024-05-21):
[0001327567-24-000017:note_history:24]
|  | April 30, 2024 |
|  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Fair Value |
| Cash equivalents: |  |  |  |  |  |  |  |
| Commercial paper | $ | 2.5 |  |  | $ | — |  |  | $ | — |  |  | $ | 2.5 |  |
| Total available-for-sale cash equivalents | $ | 2.5 |  |  | $ | — |  |  | $ | — |  |  | $ | 2.5 |  |
| Investments: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 25.5 |  |  | $ | — |  |  | $ | — |  |  | $ | 25.5 |  |
| Commercial paper | 171.0 |  |  | — |  |  | (0.1) |  |  | 170.9 |  |
| Corporate debt securities | 3,803.5 |  |  | 2.6 |  |  | (28.8) |  |  | 3,777.3 |  |
| U.S. government and agency securities | 85.0 |  |  | — |  |  | (0.4) |  |  | 84.6 |  |
| Non-U.S. government and agency securities | 87.9 |  |  | — |  |  | (0.9) |  |  | 87.0 |  |
| Asset-backed securities | 881.4 |  |  | 0.9 |  |  | (6.5) |  |  | 875.8 |  |
| Total available-for-sale investments | $ | 5,054.3 |  |  | $ | 3.5 |  |  | $ | (36.7) |  |  | $ | 5,021.1 |  |
  (was, 2024-02-21, similarity 0.6177):
[0001327567-24-000005:note_history:24]
|  | January 31, 2024 |
|  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Fair Value |
| Cash equivalents: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 11.0 |  |  | $ | — |  |  | $ | — |  |  | $ | 11.0 |  |
| Commercial paper | 252.1 |  |  | — |  |  | — |  |  | 252.1 |  |
| Corporate debt securities | 8.1 |  |  | — |  |  | — |  |  | 8.1 |  |
| U.S. government and agency securities | 10.0 |  |  | — |  |  | — |  |  | 10.0 |  |
| Total available-for-sale cash equivalents | $ | 281.2 |  |  | $ | — |  |  | $ | — |  |  | $ | 281.2 |  |
| Investments: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 61.7 |  |  | $ | — |  |  | $ | — |  |  | $ | 61.7 |  |
| Commercial paper | 163.3 |  |  | 0.2 |  |  | — |  |  | 163.5 |  |
| Corporate debt securities | 3,937.2 |  |  | 22.5 |  |  | (10.2) |  |  | 3,949.5 |  |
| U.S. government and agency securities | 160.5 |  |  | 1.1 |  |  | (0.1) |  |  | 161.5 |  |
| Non-U.S. government and agency securities | 87.8 |  |  | 0.8 |  |  | (0.3) |  |  | 88.3 |  |
| Asset-backed securities | 778.5 |  |  | 5.8 |  |  | (0.7) |  |  | 783.6 |  |
| Total available-for-sale investments | $ | 5,189.0 |  |  | $ | 30.4 |  |  | $ | (11.3) |  |  | $ | 5,208.1 |  |


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2024-05-21):
[0001327567-24-000017:note_history:25]
The following tables summarize the amortized cost, unrealized gains and losses, and fair value of our available-for-sale debt securities as of April 30, 2024 and July 31, 2023 (in millions):
  (was, 2024-02-21, similarity 0.9779):
[0001327567-24-000005:note_history:25]
The following tables summarize the amortized cost, unrealized gains and losses, and fair value of our available-for-sale debt securities as of January 31, 2024 and July 31, 2023 (in millions):

- changed (2024-05-21):
[0001327567-24-000017:note_history:26]
|  | April 30, 2024 |
|  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Fair Value |
| Cash equivalents: |  |  |  |  |  |  |  |
| Commercial paper | $ | 2.5 |  |  | $ | — |  |  | $ | — |  |  | $ | 2.5 |  |
| Total available-for-sale cash equivalents | $ | 2.5 |  |  | $ | — |  |  | $ | — |  |  | $ | 2.5 |  |
| Investments: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 25.5 |  |  | $ | — |  |  | $ | — |  |  | $ | 25.5 |  |
| Commercial paper | 171.0 |  |  | — |  |  | (0.1) |  |  | 170.9 |  |
| Corporate debt securities | 3,803.5 |  |  | 2.6 |  |  | (28.8) |  |  | 3,777.3 |  |
| U.S. government and agency securities | 85.0 |  |  | — |  |  | (0.4) |  |  | 84.6 |  |
| Non-U.S. government and agency securities | 87.9 |  |  | — |  |  | (0.9) |  |  | 87.0 |  |
| Asset-backed securities | 881.4 |  |  | 0.9 |  |  | (6.5) |  |  | 875.8 |  |
| Total available-for-sale investments | $ | 5,054.3 |  |  | $ | 3.5 |  |  | $ | (36.7) |  |  | $ | 5,021.1 |  |
  (was, 2024-02-21, similarity 0.6177):
[0001327567-24-000005:note_history:26]
|  | January 31, 2024 |
|  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Fair Value |
| Cash equivalents: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 11.0 |  |  | $ | — |  |  | $ | — |  |  | $ | 11.0 |  |
| Commercial paper | 252.1 |  |  | — |  |  | — |  |  | 252.1 |  |
| Corporate debt securities | 8.1 |  |  | — |  |  | — |  |  | 8.1 |  |
| U.S. government and agency securities | 10.0 |  |  | — |  |  | — |  |  | 10.0 |  |
| Total available-for-sale cash equivalents | $ | 281.2 |  |  | $ | — |  |  | $ | — |  |  | $ | 281.2 |  |
| Investments: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 61.7 |  |  | $ | — |  |  | $ | — |  |  | $ | 61.7 |  |
| Commercial paper | 163.3 |  |  | 0.2 |  |  | — |  |  | 163.5 |  |
| Corporate debt securities | 3,937.2 |  |  | 22.5 |  |  | (10.2) |  |  | 3,949.5 |  |
| U.S. government and agency securities | 160.5 |  |  | 1.1 |  |  | (0.1) |  |  | 161.5 |  |
| Non-U.S. government and agency securities | 87.8 |  |  | 0.8 |  |  | (0.3) |  |  | 88.3 |  |
| Asset-backed securities | 778.5 |  |  | 5.8 |  |  | (0.7) |  |  | 783.6 |  |
| Total available-for-sale investments | $ | 5,189.0 |  |  | $ | 30.4 |  |  | $ | (11.3) |  |  | $ | 5,208.1 |  |

- added (2024-05-21):
[0001327567-24-000017:note_history:27]
As of April 30, 2024, the gross unrealized losses that have been in a continuous unrealized loss position for less than 12 months were $30.3 million, which were related to $3.4 billion of available-for-sale debt securities, and the gross unrealized losses that have been in a continuous unrealized loss position for more than 12 months were $6.4 million, which were related to $722.1 million of available-for-sale debt securities. As of July 31, 2023 the gross unrealized losses that have been in a continuous unrealized loss position for less than 12 months were $30.7 million, which were related to $3.4 billion of available-for-sale debt securities, and the gross unrealized losses that have been in a continuous unrealized loss position for more than 12 months were $7.3 million, which were related to $481.8 million of available-for-sale debt securities.

- changed (2024-05-21):
[0001327567-24-000017:note_history:28]
Unrealized losses related to our available-for-sale debt securities are primarily due to interest rate fluctuations as opposed to credit quality. We do not intend to sell any of the securities in an unrealized loss position and it is not likely that we would be required to sell these securities before recovery of their amortized cost basis, which may be at maturity. We did not recognize any credit losses related to our available-for-sale debt securities during the three and nine months ended April 30, 2024 and 2023.
  (was, 2024-02-21, similarity 0.9815):
[0001327567-24-000005:note_history:28]
Unrealized losses related to our available-for-sale debt securities are primarily due to interest rate fluctuations as opposed to credit quality. We do not intend to sell any of the securities in an unrealized loss position and it is not likely that we would be required to sell these securities before recovery of their amortized cost basis, which may be at maturity. We did not recognize any credit losses related to our available-for-sale debt securities during the three and six months ended January 31, 2024 and 2023.

- changed (2024-05-21):
[0001327567-24-000017:note_history:29]
The following table summarizes the amortized cost and fair value of our available-for-sale debt securities as of April 30, 2024, by contractual years-to-maturity (in millions):
  (was, 2024-02-21, similarity 0.9766):
[0001327567-24-000005:note_history:29]
The following table summarizes the amortized cost and fair value of our available-for-sale debt securities as of January 31, 2024, by contractual years-to-maturity (in millions):

- added (2024-05-21):
[0001327567-24-000017:note_history:30]
Marketable equity securities consist of money market funds and are included in cash and cash equivalents on our condensed consolidated balance sheets. As of April 30, 2024 and July 31, 2023, the carrying values of our marketable equity securities were $763.9 million and $476.1 million, respectively. There were no unrealized gains or losses recognized for these securities during the three and nine months ended April 30, 2024 and 2023.

- removed (2024-05-21):
[0001327567-24-000005:note_history:31]
As of January 31, 2024, the gross unrealized losses that have been in a continuous unrealized loss position for less than 12 months were $5.1 million, which were related to $1.5 billion of available-for-sale debt securities, and the gross unrealized losses that have been in a continuous unrealized loss position for more than 12 months were $6.2 million, which were related to $752.8 million of available-for-sale debt securities. As of July 31, 2023 the gross unrealized losses that have been in a continuous unrealized loss position for less than 12 months were $30.7 million, which were related to $3.4 billion of available-for-sale debt securities, and the gross unrealized losses that have been in a continuous unrealized loss position for more than 12 months were $7.3 million, which were related to $481.8 million of available-for-sale debt securities.

- removed (2024-05-21):
[0001327567-24-000005:note_history:32]
Marketable equity securities consist of money market funds and are included in cash and cash equivalents on our condensed consolidated balance sheets. As of January 31, 2024 and July 31, 2023, the carrying values of our marketable equity securities were $859.3 million and $476.1 million, respectively. There were no unrealized gains or losses recognized for these securities during the three and six months ended January 31, 2024 and 2023.


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2024-05-21):
[0001327567-24-000017:note_history:33]
|  | Three Months Ended April 30, |  | Nine Months Ended April 30, |
|  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| Revenue: |  |  |  |  |  |  |  |
| Americas |  |  |  |  |  |  |  |
| United States | $ | 1,271.1 |  |  | $ | 1,105.2 |  |  | $ | 3,723.6 |  |  | $ | 3,153.8 |  |
| Other Americas | 88.5 |  |  | 74.0 |  |  | 256.8 |  |  | 213.1 |  |
| Total Americas | 1,359.6 |  |  | 1,179.2 |  |  | 3,980.4 |  |  | 3,366.9 |  |
| Europe, the Middle East, and Africa (“EMEA”) | 399.2 |  |  | 332.1 |  |  | 1,170.9 |  |  | 981.5 |  |
| Asia Pacific and Japan (“APAC”) | 226.0 |  |  | 209.6 |  |  | 686.7 |  |  | 591.0 |  |
| Total revenue | $ | 1,984.8 |  |  | $ | 1,720.9 |  |  | $ | 5,838.0 |  |  | $ | 4,939.4 |  |
  (was, 2024-02-21, similarity 0.9563):
[0001327567-24-000005:note_history:33]
|  | Three Months Ended January 31, |  | Six Months Ended January 31, |
|  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| Revenue: |  |  |  |  |  |  |  |
| Americas |  |  |  |  |  |  |  |
| United States | $ | 1,248.2 |  |  | $ | 1,042.3 |  |  | $ | 2,452.5 |  |  | $ | 2,048.6 |  |
| Other Americas | 86.0 |  |  | 74.7 |  |  | 168.3 |  |  | 139.1 |  |
| Total Americas | 1,334.2 |  |  | 1,117.0 |  |  | 2,620.8 |  |  | 2,187.7 |  |
| Europe, the Middle East, and Africa (“EMEA”) | 406.8 |  |  | 341.5 |  |  | 771.7 |  |  | 649.4 |  |
| Asia Pacific and Japan (“APAC”) | 234.1 |  |  | 196.6 |  |  | 460.7 |  |  | 381.4 |  |
| Total revenue | $ | 1,975.1 |  |  | $ | 1,655.1 |  |  | $ | 3,853.2 |  |  | $ | 3,218.5 |  |

- added (2024-05-21):
[0001327567-24-000017:note_history:34]
|  | Three Months Ended April 30, |  | Nine Months Ended April 30, |
|  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| Revenue: |  |  |  |  |  |  |  |
| Product | $ | 391.0 |  |  | $ | 388.1 |  |  | $ | 1,122.8 |  |  | $ | 1,071.0 |  |
| Subscription and support |  |  |  |  |  |  |  |
| Subscription | 1,045.6 |  |  | 838.1 |  |  | 3,061.0 |  |  | 2,417.5 |  |
| Support | 548.2 |  |  | 494.7 |  |  | 1,654.2 |  |  | 1,450.9 |  |
| Total subscription and support | 1,593.8 |  |  | 1,332.8 |  |  | 4,715.2 |  |  | 3,868.4 |  |
| Total revenue | $ | 1,984.8 |  |  | $ | 1,720.9 |  |  | $ | 5,838.0 |  |  | $ | 4,939.4 |  |

- changed (2024-05-21):
[0001327567-24-000017:note_history:35]
During the nine months ended April 30, 2024 and 2023, we recognized approximately $3.7 billion and $2.9 billion of revenue pertaining to amounts that were deferred as of July 31, 2023 and 2022, respectively.
  (was, 2024-02-21, similarity 0.965):
[0001327567-24-000005:note_history:35]
During the six months ended January 31, 2024 and 2023, we recognized approximately $2.7 billion and $2.1 billion of revenue pertaining to amounts that were deferred as of July 31, 2023 and 2022, respectively.

- changed (2024-05-21):
[0001327567-24-000017:note_history:36]
Remaining performance obligations were $11.3 billion as of April 30, 2024, of which we expect to recognize as revenue approximately $5.4 billion over the next 12 months and the remainder thereafter.
  (was, 2024-02-21, similarity 0.9786):
[0001327567-24-000005:note_history:36]
Remaining performance obligations were $10.8 billion as of January 31, 2024, of which we expect to recognize as revenue approximately $5.2 billion over the next 12 months and the remainder thereafter.

- removed (2024-05-21):
[0001327567-24-000005:note_history:37]
|  | Three Months Ended January 31, |  | Six Months Ended January 31, |
|  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| Revenue: |  |  |  |  |  |  |  |
| Product | $ | 390.7 |  |  | $ | 352.9 |  |  | $ | 731.8 |  |  | $ | 682.9 |  |
| Subscription and support |  |  |  |  |  |  |  |
| Subscription | 1,027.1 |  |  | 815.4 |  |  | 2,015.4 |  |  | 1,579.4 |  |
| Support | 557.3 |  |  | 486.8 |  |  | 1,106.0 |  |  | 956.2 |  |
| Total subscription and support | 1,584.4 |  |  | 1,302.2 |  |  | 3,121.4 |  |  | 2,535.6 |  |
| Total revenue | $ | 1,975.1 |  |  | $ | 1,655.1 |  |  | $ | 3,853.2 |  |  | $ | 3,218.5 |  |


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: tag_name, score: 1.0

- added (2024-05-21):
[0001327567-24-000017:note_history:38]
Subsequent to April 30, 2024, $123.2 million in aggregate principal amount of the 2025 Notes was converted or had been submitted by the holders for conversion and will settle during the fiscal quarter ending July 31, 2024.

- added (2024-05-21):
[0001327567-24-000017:note_history:39]
Acquisition

- added (2024-05-21):
[0001327567-24-000017:note_history:40]
On May 15, 2024, we entered into a definitive agreement with International Business Machines Corporation to acquire certain QRadar assets including intellectual property, customer relationships, and customer contracts. We agreed to pay $500.0 million in cash upon closing, and may make additional post-closing payments contingent upon the migration of QRadar on-premise customers to Cortex XSIAM through December 31, 2027. We expect the acquisition will help accelerate the growth of our Cortex XSIAM platform.

- added (2024-05-21):
[0001327567-24-000017:note_history:41]
The proposed acquisition is expected to close during our first quarter of fiscal 2025, subject to the satisfaction of regulatory approvals and other customary closing conditions.

- removed (2024-05-21):
[0001327567-24-000005:note_history:42]
Subsequent to January 31, 2024, $581.0 million in aggregate principal amount of the 2025 Notes was converted or had been submitted by the holders for conversion and will settle during the fiscal quarter ending April 30, 2024.
