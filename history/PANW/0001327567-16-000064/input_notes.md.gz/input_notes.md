# PANW notes — 0001327567-16-000064


## panw:ContractManufacturerLiabilitiesPolicyTextBlockPolicyTextBlock

[0001327567-16-000064:notes:1]
Contract Manufacturer Liabilities

[0001327567-16-000064:notes:2]
We outsource most of our manufacturing, repair, and supply chain management operations to our independent contract manufacturer and payments to it are a significant portion of our product cost of revenues. Although we could be contractually obligated to purchase manufactured products, we generally do not own the manufactured products. Product title transfers from our independent contract manufacturer to us and immediately to our channel partners upon shipment. Our independent contract manufacturer assembles our products using design specifications, quality assurance programs, and standards that we establish and it procures components and assembles our products based on our demand forecasts. These forecasts represent our estimates of future demand for our products based upon historical trends and analysis from our sales and product management functions as adjusted for overall market conditions. If the actual component usage and product demand are significantly lower than forecast, we accrue for costs for contractual manufacturing commitments in excess of our forecasted demand including costs for excess components or for carrying costs incurred by our contract manufacturer.


## panw:SharesAvailableForGrantTextBlock

[0001327567-16-000064:notes:3]
The following table presents the stock activity and the total number of shares available for grant as of July 31, 2016 (in millions):

[0001327567-16-000064:notes:4]
|  | Number of shares |
| Balance—July 31, 2015 | 8.1 |  |
| Authorized | 3.8 |  |
| RSUs and RSAs granted | (4.3 | ) |
| RSUs forfeited | 0.6 |  |
| Balance—July 31, 2016 | 8.2 |  |


## us-gaap:AvailableForSaleSecuritiesTextBlock

[0001327567-16-000064:notes:5]
The following tables summarize the amortized cost, unrealized gains and losses, and fair value of our available-for-sale investments as of July 31, 2016 and July 31, 2015 (in millions):

[0001327567-16-000064:notes:6]
|  | July 31, 2016 |
|  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Estimated Fair Value |
| Certificates of deposit | $ | 5.4 |  |  | $ | — |  |  | $ | — |  |  | $ | 5.4 |  |
| Commercial paper | 3.0 |  |  | — |  |  | — |  |  | 3.0 |  |
| Corporate debt securities | 286.7 |  |  | 0.8 |  |  | — |  |  | 287.5 |  |
| U.S. government and agency securities | 907.3 |  |  | 0.9 |  |  | (0.1 | ) |  | 908.1 |  |
| Total | $ | 1,202.4 |  |  | $ | 1.7 |  |  | $ | (0.1 | ) |  | $ | 1,204.0 |  |

[0001327567-16-000064:notes:7]
|  | July 31, 2015 |
|  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Estimated Fair Value |
| Certificates of deposit | $ | 1.0 |  |  | $ | — |  |  | $ | — |  |  | $ | 1.0 |  |
| Corporate debt securities | 190.9 |  |  | — |  |  | (0.2 | ) |  | 190.7 |  |
| U.S. government and agency securities | 760.2 |  |  | 0.3 |  |  | (0.2 | ) |  | 760.3 |  |
| Total | $ | 952.1 |  |  | $ | 0.3 |  |  | $ | (0.4 | ) |  | $ | 952.0 |  |


## us-gaap:BasisOfAccountingPolicyPolicyTextBlock

[0001327567-16-000064:notes:8]
Basis of Presentation

[0001327567-16-000064:notes:9]
The accompanying consolidated financial statements have been prepared in conformity with U.S. generally accepted accounting principles (“GAAP”). The consolidated financial statements include all adjustments necessary for a fair presentation of our annual results. All adjustments are of a normal recurring nature. Certain prior period amounts have been reclassified to conform with current period presentation.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001327567-16-000064:notes:10]
Acquisitions

[0001327567-16-000064:notes:11]
Fiscal 2015

[0001327567-16-000064:notes:12]
CirroSecure, Inc.

[0001327567-16-000064:notes:13]
On May 22, 2015, we completed our acquisition of CirroSecure, Inc. (“CirroSecure”), a privately-held cybersecurity company. The acquisition expands the functionality of our next-generation security platform by providing additional security for SaaS applications. We accounted for this transaction as a business combination in exchange for total cash consideration of $15.3 million.

[0001327567-16-000064:notes:14]
We allocated the purchase consideration to the assets acquired and liabilities assumed based on their estimated fair values and as a result, recorded a developed technology intangible asset of $11.0 million, goodwill of $8.1 million, and net liabilities of $3.8 million in our consolidated balance sheets as of the acquisition date. The developed technology is being amortized over an estimated useful life of seven years. The goodwill is attributable to the assembled workforce and expected post-acquisition synergies and is not deductible for income tax purposes.

[0001327567-16-000064:notes:15]
Fiscal 2014

[0001327567-16-000064:notes:16]
Cyvera Ltd.

[0001327567-16-000064:notes:17]
On April 9, 2014, we completed our acquisition of Cyvera Ltd. (“Cyvera”), a privately-held cybersecurity company located in Tel Aviv, Israel. The acquisition extends our next-generation security platform with an innovative approach to preventing attacks on the endpoint. We accounted for this transaction as a business combination in exchange for total consideration of approximately $177.6 million, which consisted of the following (in millions):

[0001327567-16-000064:notes:18]
|  | Amount |
| Cash | $ | 90.1 |  |
| Common stock (1.3 million shares) | 87.5 |  |
| Total | $ | 177.6 |  |

[0001327567-16-000064:notes:19]
As part of the acquisition, we agreed to replace Cyvera’s unvested options with our restricted stock units with an estimated fair value of $6.4 million. Of the total estimated fair value, a portion was allocated to the purchase consideration and the remainder was allocated to future services and is being expensed over the remaining service periods on a straight-line basis as share-based compensation. In addition, we issued 0.3 million shares of restricted common stock with a total fair value of $17.6 million to certain Cyvera employees. The restriction on these shares will be released over a period of three years from the acquisition date, subject to continued employment. These shares were excluded from the purchase consideration and are being expensed over the remaining service periods on a straight-line basis as share-based compensation.

[0001327567-16-000064:notes:20]
The following table summarizes our allocation of the purchase consideration based on the fair value of assets acquired and liabilities assumed (in millions):

[0001327567-16-000064:notes:21]
|  | Amount |
| Cash | $ | 6.9 |  |
| Goodwill | 145.3 |  |
| Identified intangible assets | 42.3 |  |
| Accrued and other liabilities, net | (7.0 | ) |
| Long-term deferred tax liability, net | (9.9 | ) |
| Total | $ | 177.6 |  |

[0001327567-16-000064:notes:22]
The following table presents details of the identified intangible assets acquired as of the date of acquisition (in millions, except years):

[0001327567-16-000064:notes:23]
|  | Fair Value |  | Estimated Useful Life |
| Developed technology | $ | 34.5 |  |  | 7 years |
| In-process research and development | 7.6 |  |  | N/A |
| Other | 0.2 |  |  | 2 years |
| Total | $ | 42.3 |  |  |  |

[0001327567-16-000064:notes:24]
Goodwill generated from this business combination is primarily attributable to the assembled workforce and synergies from combined selling opportunities of both network security products and endpoint security products. The goodwill is not deductible for income tax purposes.

[0001327567-16-000064:notes:25]
Morta Security, Inc.

[0001327567-16-000064:notes:26]
On December 26, 2013, we completed our acquisition of Morta Security, Inc. (“Morta”), a privately-held cybersecurity company. We accounted for this transaction as a business combination and exchanged total cash consideration of $10.3 million. Morta brings us a team of cybersecurity experts which will enhance the proven detection and prevention capabilities of our WildFire offering.

[0001327567-16-000064:notes:27]
|  | Amount |
| Goodwill | $ | 10.1 |  |
| Identified intangible assets | 2.2 |  |
| Net liabilities assumed | (2.0 | ) |
| Total | $ | 10.3 |  |

[0001327567-16-000064:notes:28]
The following table presents details of the identified intangible assets acquired (in millions, except years):

[0001327567-16-000064:notes:29]
|  | Fair Value |  | Estimated Useful Life |
| In-process research and development held for defensive purposes | $ | 1.9 |  |  | 3 years |
| Other | 0.3 |  |  | 2 years |
| Total | $ | 2.2 |  |  |  |

[0001327567-16-000064:notes:30]
Goodwill generated from this business combination is primarily attributable to human capital with threat intelligence experience and capabilities, and is not deductible for income tax purposes.


## us-gaap:BusinessDescriptionAndAccountingPoliciesTextBlock

[0001327567-16-000064:notes:31]
Description of Business and Summary of Significant Accounting Policies

[0001327567-16-000064:notes:32]
Description of Business

[0001327567-16-000064:notes:33]
Palo Alto Networks, Inc. (the “Company,” “we,” “us,” or “our”), located in Santa Clara, California, was incorporated in March 2005 under the laws of the State of Delaware and commenced operations in April 2005. We offer a next-generation security platform that empowers enterprises, service providers, and government entities to secure their organizations by safely enabling applications running on their networks and by preventing breaches that stem from targeted cyber attacks.

[0001327567-16-000064:notes:34]
Principles of Consolidation

[0001327567-16-000064:notes:35]
The consolidated financial statements include our accounts and our wholly owned subsidiaries. All significant intercompany balances and transactions have been eliminated in consolidation.

[0001327567-16-000064:notes:36]
Use of Estimates

[0001327567-16-000064:notes:37]
The preparation of consolidated financial statements in conformity with U.S. GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities and disclosure of contingent assets and liabilities at the date of the consolidated financial statements and the reported amounts of revenues and expenses during the reporting period. Such management estimates include, but are not limited to the best estimate of selling price for our products and services, share-based compensation, fair value of assets acquired and liabilities assumed in business combinations, the assessment of recoverability of our property and equipment, identified intangibles and goodwill, future taxable income, contract manufacturer liabilities, and loss contingencies. We base our estimates on historical experience and also on assumptions that we believe are reasonable. Actual results could differ materially from those estimates.

[0001327567-16-000064:notes:38]
Concentrations

[0001327567-16-000064:notes:39]
Financial instruments that subject us to concentrations of credit risk consist primarily of cash and cash equivalents, investments, and accounts receivable.

[0001327567-16-000064:notes:40]
We invest only in high-quality credit instruments and maintain our cash and cash equivalents and available-for-sale investments in fixed income securities. Management believes that the financial institutions that hold our investments are financially sound and, accordingly, are subject to minimal credit risk. Deposits held with banks may exceed the amount of insurance provided on such deposits.

[0001327567-16-000064:notes:41]
Our accounts receivables are primarily derived from our distributors representing various geographical locations. We perform ongoing credit evaluations and generally do not require collateral on accounts receivable. We maintain an allowance for doubtful accounts for estimated potential credit losses. As of July 31, 2016, four distributors represented 26.1%, 25.6%, 11.4%, and 11.0% of our gross accounts receivable. For fiscal 2016, two distributors represented 31.0% and 27.2% of our total revenue. We rely on an independent contract manufacturer to assemble most of our products and sole suppliers for a certain number of our components.

[0001327567-16-000064:notes:42]
Comprehensive Loss

[0001327567-16-000064:notes:43]
Comprehensive loss is comprised of net loss and other comprehensive income (loss). Unrealized gains and losses on available-for-sale investments are included in our other comprehensive income (loss).

[0001327567-16-000064:notes:44]
Foreign Currency Transactions

[0001327567-16-000064:notes:45]
The functional currency of our foreign subsidiaries is the U.S. dollar. Monetary assets and liabilities denominated in foreign currencies have been remeasured into U.S. dollars using the exchange rates in effect at the balance sheet dates. Foreign currency denominated income and expenses have been remeasured using the average exchange rates in effect during each period. Foreign currency remeasurement gains and losses and foreign currency transaction gains and losses are not significant to the financial statements.

[0001327567-16-000064:notes:46]
Cash and Cash Equivalents

[0001327567-16-000064:notes:47]
We consider all highly liquid investments held at financial institutions, such as commercial paper, money market funds, and other money market securities with original maturities of three months or less at date of purchase to be cash equivalents.

[0001327567-16-000064:notes:48]
Fair Value

[0001327567-16-000064:notes:49]
We define fair value as the price that would be received from selling an asset or paid to transfer a liability in an orderly transaction between market participants at the measurement date. When determining the fair value measurements for assets and liabilities which are required to be recorded at fair value, we consider the principal or most advantageous market in which to transact and the market-based risk. We apply fair value accounting for all financial assets and liabilities that are recognized or disclosed at fair value in the financial statements on a recurring basis. The carrying amounts reported in the consolidated financial statements approximate the fair value for cash and cash equivalents, accounts receivable, accounts payable, and accrued liabilities, due to their short-term nature.

[0001327567-16-000064:notes:50]
Investments

[0001327567-16-000064:notes:51]
We classify our investments as available-for-sale at the time of purchase since it is our intent that these investments are available for current operations, and include these investments on our consolidated balance sheet as either short-term or long-term investments depending on their maturity. Investments not considered cash equivalents and with maturities one year or less from the consolidated balance sheet date are classified as short-term investments. Investments with maturities greater than one year from the consolidated balance sheet date are classified as long-term investments.

[0001327567-16-000064:notes:52]
Investments are considered impaired when a decline in fair value is judged to be other-than-temporary. We consult with our investment managers and consider available quantitative and qualitative evidence in evaluating potential impairment of our investments on a quarterly basis. If the cost of an individual investment exceeds its fair value, we evaluate, among other factors, general market conditions, the duration and extent to which the fair value is less than cost, and our intent and ability to hold the investment. Once a decline in fair value is determined to be other-than-temporary, an impairment charge is recorded and a new cost basis in the investment is established.

[0001327567-16-000064:notes:53]
Accounts Receivable

[0001327567-16-000064:notes:54]
Trade accounts receivable are recorded at the invoiced amount, net of allowances for doubtful accounts. The allowance for doubtful accounts is based on our assessment of the collectability of accounts. Management regularly reviews the adequacy of the allowance for doubtful accounts by considering the age of each outstanding invoice, each channel partner’s expected ability to pay, and the collection history with each channel partner, when applicable, to determine whether a specific allowance is appropriate. Accounts receivable deemed uncollectible are charged against the allowance for doubtful accounts when identified. As of July 31, 2016 and 2015, the allowance for doubtful accounts activity was not significant.

[0001327567-16-000064:notes:55]
Property and Equipment

[0001327567-16-000064:notes:56]
Property and equipment are recorded at cost. Depreciation is computed using the straight-line method over the estimated useful lives of the assets, generally three to ten years. Leasehold improvements are depreciated over the shorter of the estimated useful lives of the improvements or the remaining lease term.

[0001327567-16-000064:notes:57]
Business Combinations

[0001327567-16-000064:notes:58]
We include the results of operations of the businesses that we acquire as of the respective dates of acquisition. We allocate the fair value of the purchase price of our acquisitions to the tangible assets acquired, liabilities assumed, and intangible assets acquired, based on their estimated fair values. The excess of the purchase price over the fair values of these identifiable assets and liabilities is recorded as goodwill. Additional information existing as of the acquisition date but unknown to us may become known during the remainder of the measurement period, not to exceed 12 months from the acquisition date, which may result in changes to the amounts and allocations recorded.

[0001327567-16-000064:notes:59]
Amortization of Intangible Assets

[0001327567-16-000064:notes:60]
Purchased intangible assets with finite lives are carried at cost, less accumulated amortization. Amortization is computed over the estimated useful lives of the respective assets. Acquisition-related in-process research and development represents the fair value of incomplete research and development projects that have not reached technological feasibility as of the date of acquisition. Initially, these assets are not subject to amortization. Assets related to projects that have been completed are transferred to developed technology, which are subject to amortization.

[0001327567-16-000064:notes:61]
Impairment of Goodwill, Intangible Assets, and Long-Lived Assets

[0001327567-16-000064:notes:62]
Goodwill is evaluated for impairment on an annual basis in the fourth quarter of our fiscal year, and whenever events or changes in circumstances indicate the carrying amount of goodwill may not be recoverable. We have elected to first assess qualitative factors to determine whether it is more likely than not that the fair value of our single reporting unit is less than its carrying amount. If we determine that it is more likely than not that the fair value of our single reporting unit is less than its carrying amount, then the two-step goodwill impairment test will be performed. The first step, identifying a potential impairment, compares the fair value of our single reporting unit with its carrying amount. If the carrying amount exceeds its fair value, the second step will be performed; otherwise, no further step is required. The second step, measuring the impairment loss, compares the implied fair value of the goodwill with the carrying amount of the goodwill. Any excess of the goodwill carrying amount over the implied fair value is recognized as an impairment loss.

[0001327567-16-000064:notes:63]
We evaluate events and changes in circumstances that could indicate carrying amounts of purchased intangible assets and long-lived assets may not be recoverable. When such events or changes in circumstances occur, we assess the recoverability of these assets by determining whether or not the carrying amount will be recovered through undiscounted expected future cash flows. If the total of the future undiscounted cash flows is less than the carrying amount of an asset, we record an impairment loss for the amount by which the carrying amount of the asset exceeds the fair value of the asset.

[0001327567-16-000064:notes:64]
Through July 31, 2016, we have not recognized any impairment losses on our goodwill, intangible assets, and long-lived assets.

[0001327567-16-000064:notes:65]
We outsource most of our manufacturing, repair, and supply chain management operations to our independent contract manufacturer and payments to it are a significant portion of our product cost of revenues. Although we could be contractually obligated to purchase manufactured products, we generally do not own the manufactured products. Product title transfers from our independent contract manufacturer to us and immediately to our channel partners upon shipment. Our independent contract manufacturer assembles our products using design specifications, quality assurance programs, and standards that we establish and it procures components and assembles our products based on our demand forecasts. These forecasts represent our estimates of future demand for our products based upon historical trends and analysis from our sales and product management functions as adjusted for overall market conditions. If the actual component usage and product demand are significantly lower than forecast, we accrue for costs for contractual manufacturing commitments in excess of our forecasted demand including costs for excess components or for carrying costs incurred by our contract manufacturer. Through July 31, 2016, we have not accrued any significant costs associated with this exposure.

[0001327567-16-000064:notes:66]
Convertible Senior Notes

[0001327567-16-000064:notes:67]
On June 30, 2014, we issued $575.0 million aggregate principal amount of 0.0% Convertible Senior Notes due 2019 (the “Notes”). In accounting for the issuance of the Notes, we separated the Notes into liability and equity components. The carrying amount of the liability component was calculated by measuring the fair value of a similar liability that does not have an associated convertible feature. The carrying amount of the equity component representing the conversion option was determined by deducting the fair value of the liability component from the par value of the Notes as a whole. This difference represents a debt discount that is amortized to interest expense using the effective interest method over the term of the Notes. The equity component is not remeasured as long as it continues to meet the conditions for equity classification. In accounting for the transaction costs related to the issuance of the Notes, we allocated the total amount incurred to the liability and equity components using the same proportions as the proceeds from the Notes. Transaction costs attributable to the liability component are being amortized to interest expense using the effective interest method over the term of the Notes. Transaction costs attributable to the equity component were netted with the equity component of the Notes in additional paid-in capital in the consolidated balance sheets.

[0001327567-16-000064:notes:68]
When the Notes are convertible, the net carrying amount of the Notes and related debt issuance costs will be classified as current liabilities and current assets, respectively, in our consolidated balance sheets. In addition, a portion of the equity component representing the conversion option will be reclassified to temporary equity in our consolidated balance sheets.

[0001327567-16-000064:notes:69]
Revenue Recognition

[0001327567-16-000064:notes:70]
We generate revenue from the sales of hardware and software products, subscriptions, support and maintenance, and other services primarily through a direct sales force and indirect relationships with channel partners, and, to a lesser extent, directly to end-customers.

[0001327567-16-000064:notes:71]
Revenue is recognized when all of the following criteria are met:

[0001327567-16-000064:notes:72]
| • | Persuasive Evidence of an Arrangement Exists. We rely upon non-cancelable sales agreements and purchase orders to determine the existence of an arrangement. |

[0001327567-16-000064:notes:73]
| • | Delivery has Occurred. We use shipping documents or transmissions of product or service contract registration codes to determine delivery. |

[0001327567-16-000064:notes:74]
| • | The Fee is Fixed or Determinable. We assess whether the fee is fixed or determinable based on the payment terms associated with the transaction. |

[0001327567-16-000064:notes:75]
| • | Collectability is Reasonably Assured. We assess collectability based on credit analysis and payment history. |

[0001327567-16-000064:notes:76]
We recognize product revenue at the time of shipment provided that all other revenue recognition criteria have been met. Our channel partners generally receive an order from an end-customer prior to placing an order with us. In addition, payment from our channel partners is not contingent on the partner’s success in sales to end-customers. Our channel partners generally do not stock appliances and only have limited stock rotation rights and no price protection rights. When necessary, we make certain estimates and maintain allowances for sales returns and other programs based on our historical experience. To date, these estimates have not been significant. We recognize services revenue from subscriptions and support and maintenance ratably over the contractual service period, which is typically one to five years. Other services revenue is recognized as the services are rendered.

[0001327567-16-000064:notes:77]
Most of our arrangements, other than renewals of subscriptions and support and maintenance, are multiple-element arrangements with a combination of hardware, software, subscriptions, support and maintenance, and other services. Products and services generally qualify as separate units of accounting. Our hardware deliverables typically include proprietary operating system software, which together deliver the essential functionality of our products. For multiple-element arrangements, we allocate revenue to each unit of accounting based on an estimated selling price at the arrangement inception. The estimated selling price for each element is based upon the following hierarchy: vendor-specific objective evidence (“VSOE”) of selling price, if available, third-party evidence (“TPE”) of selling price, if VSOE of selling price is not available, or best estimate of selling price (“BESP”), if neither VSOE of selling price nor TPE of selling price are available. The total arrangement consideration is allocated to each separate unit of accounting using the relative estimated selling prices of each unit based on the aforementioned selling price hierarchy. We limit the amount of revenue recognized for delivered elements to an amount that is not contingent upon future delivery of additional products or services or meeting of any specified performance conditions.

[0001327567-16-000064:notes:78]
In multiple-element arrangements where software deliverables are included, revenue is allocated to each separate unit of accounting for each of the non-software deliverables and to the software deliverables as a group using the relative estimated selling prices of each of the deliverables in the arrangement based on the aforementioned estimated selling price hierarchy. The arrangement consideration allocated to the software deliverables as a group is then allocated to each software deliverable using the residual method when VSOE of fair value of the undelivered items exists. Under the residual method, the amount of revenue allocated to delivered elements equals the total arrangement consideration less the aggregate fair value of any undelivered elements. In determining VSOE of fair value, we evaluate whether a substantial majority of the historical prices charged for a product or service sold on a standalone basis, as represented by a percentage of list price, fall within a reasonably narrow range. If VSOE of fair value of one or more undelivered items does not exist, revenue from the software portion of the arrangement is deferred and recognized at the earlier of: (i) delivery of those elements or (ii) when fair value can be established unless support and maintenance is the only undelivered element, in which case, the entire software arrangement fee is recognized ratably over the contractual service period.

[0001327567-16-000064:notes:79]
We account for multiple agreements with a single partner as one arrangement if the contractual terms and/or substance of those agreements indicate that they may be so closely related that they are, in effect, parts of a single arrangement.

[0001327567-16-000064:notes:80]
Revenues are reported net of sales taxes. Shipping charges billed to channel partners are included in revenues and related costs are included in cost of revenue. Sales commissions and other incremental costs to acquire contracts are also expensed as incurred. After receipt of a partner order, any amounts billed in excess of revenue recognized are recorded as deferred revenue.

[0001327567-16-000064:notes:81]
Advertising Costs

[0001327567-16-000064:notes:82]
Advertising costs, which are expensed and included in sales and marketing expense when incurred, were $6.6 million, $4.8 million, and $3.7 million, during the years ended July 31, 2016, 2015, and 2014, respectively.

[0001327567-16-000064:notes:83]
Software Development Costs

[0001327567-16-000064:notes:84]
Internally developed software includes security software developed to meet our internal needs to provide cloud-based subscription services to our end-customers and business software that we customize to meet our specific operational needs. These capitalized costs consist of internal compensation related costs and external direct costs incurred during the application development stage and will be amortized over a useful life of three to five years.

[0001327567-16-000064:notes:85]
The costs to develop software that is marketed externally have not been capitalized as we believe our current software development process is essentially completed concurrent with the establishment of technological feasibility. As such, all related software development costs are expensed as incurred and included in research and development expense in our consolidated statements of operations.

[0001327567-16-000064:notes:86]
Share-Based Compensation

[0001327567-16-000064:notes:87]
Compensation expense related to share-based transactions, including employee and non-employee director awards, is measured and recognized in the financial statements based on fair value on the grant date. We recognize share-based compensation expense, net of estimated forfeitures, on a straight-line basis over the requisite service periods of the related awards.

[0001327567-16-000064:notes:88]
Leases

[0001327567-16-000064:notes:89]
We rent our facilities under operating lease agreements and recognize related rent expense on a straight-line basis over the term of the lease. Some of our lease agreements contain rent holidays, scheduled rent increases, lease incentives, and renewal options. Rent holidays and scheduled rent increases are included in the determination of rent expense to be recorded over the lease term. Lease incentives are recognized as a reduction of rent expense on a straight-line basis over the term of the lease. Renewals are not assumed in the determination of the lease term unless they are deemed to be reasonably assured at the inception of the lease. We begin recognizing rent expense on the date that we obtain the legal right to use and control the leased space.

[0001327567-16-000064:notes:90]
Income Taxes

[0001327567-16-000064:notes:91]
We account for income taxes using the asset and liability method, which requires the recognition of deferred tax assets and liabilities for the expected future tax consequences of events that have been recognized in our financial statements or tax returns. In addition, deferred tax assets are recorded for the future benefit of utilizing net operating losses and research and development credit carryforwards. Valuation allowances are provided when necessary to reduce deferred tax assets to the amount expected to be realized.

[0001327567-16-000064:notes:92]
Significant judgment is required in determining any valuation allowance recorded against deferred tax assets. In assessing the need for a valuation allowance, we consider all available evidence, including past operating results, estimates of future taxable income, and the feasibility of tax planning strategies. In the event that we change our determination as to the amount of deferred tax assets that can be realized, we will adjust our valuation allowance with a corresponding impact to the provision for income taxes in the period in which such determination is made.

[0001327567-16-000064:notes:93]
We apply the authoritative accounting guidance prescribing a threshold and measurement attribute for the financial recognition and measurement of a tax position taken or expected to be taken in a tax return. We recognize liabilities for uncertain tax positions based on a two-step process. The first step is to evaluate the tax position for recognition by determining if the weight of available evidence indicates that it is more likely than not that the position will be sustained on audit, including resolution of related appeals or litigation processes, if any. The second step requires us to estimate and measure the tax benefit as the largest amount that is more likely than not to be realized upon ultimate settlement.

[0001327567-16-000064:notes:94]
Loss Contingencies

[0001327567-16-000064:notes:95]
We are subject to the possibility of various loss contingencies arising in the ordinary course of business. In determining loss contingencies, we consider the likelihood of loss or impairment of an asset, or the incurrence of a liability, as well as our ability to reasonably estimate the amount of loss. An estimated loss contingency is accrued when it is probable that an asset has been impaired or a liability has been incurred and the amount of loss can be reasonably estimated. If we determine that a loss is possible and the range of the loss can be reasonably determined, then we disclose the range of the possible loss. We regularly evaluate current information available to us to determine whether an accrual is required, an accrual should be adjusted or a range of possible loss should be disclosed.

[0001327567-16-000064:notes:96]
Recent Accounting Pronouncements

[0001327567-16-000064:notes:97]
In August 2016, the Financial Accounting Standards Board (“FASB”) issued new authoritative guidance addressing eight specific cash flow issues with the objective of reducing the existing diversity in practice in how certain transactions are presented and classified in the statement of cash flows. The standard is effective for us for our first quarter of fiscal 2019 and will be applied on a retrospective basis. Early adoption is permitted. We are currently evaluating whether this standard will have a material impact on our consolidated financial statements.

[0001327567-16-000064:notes:98]
In June 2016, the FASB issued new authoritative guidance on the accounting for credit losses on most financial assets and certain financial instruments. The standard replaces the existing incurred loss model with an expected credit loss model for financial assets measured at amortized cost, including trade receivables, and requires that credit losses on available-for-sale debt securities be presented as an allowance rather than as a write-down. The standard is effective for us for our first quarter of fiscal 2021 and will be applied on a modified-retrospective basis. Early adoption is permitted beginning our first quarter of fiscal 2020. We are currently evaluating whether this standard will have a material impact on our consolidated financial statements.

[0001327567-16-000064:notes:99]
In March 2016, the FASB issued authoritative guidance simplifying several aspects of the accounting for employee share-based payment transactions, including the income tax consequences, accounting for forfeitures, and classification of excess tax benefits on the statement of cash flows. The standard is effective for us for our first quarter of fiscal 2018, however, early adoption is permitted. We are currently evaluating whether this standard will have a material impact on our consolidated financial statements.

[0001327567-16-000064:notes:100]
In February 2016, the FASB issued new authoritative guidance on lease accounting. Among its provisions, the standard requires lessees to recognize right-of-use assets and lease liabilities on the balance sheet for operating leases and also requires additional qualitative and quantitative disclosures about lease arrangements. The standard is effective for us for our first quarter of fiscal 2020 and will be applied on a modified retrospective basis, with the option to elect certain practical expedients. Early adoption is permitted. We are currently evaluating whether this standard will have a material impact on our consolidated financial statements.

[0001327567-16-000064:notes:101]
In April 2015, the FASB issued new authoritative guidance on fees paid in a cloud computing arrangement. The standard requires customers in a cloud computing arrangement to evaluate whether the arrangement includes a software license. If the arrangement includes a software license, the customer should account for the software license element of the arrangement consistent with the acquisition of other software licenses. If the arrangement does not include a software license, the customer should account for the arrangement as a service contract. The standard is effective for us for our first quarter of fiscal 2017 and will be applied on a prospective basis. We do not expect the adoption of the standard will have a material impact on our consolidated financial statements.

[0001327567-16-000064:notes:102]
In April 2015, the FASB issued updated authoritative guidance to simplify the presentation of debt issuance costs. The amended standard requires that debt issuance costs related to a recognized debt liability be presented in the balance sheet as a direct deduction from the carrying amount of the related debt liability, consistent with the presentation of debt discounts, instead of being presented as an asset. The amended standard is effective for us for our first quarter of fiscal 2017 and will be applied on a retrospective basis. We do not expect the adoption of the standard will have a material impact on our consolidated financial statements.

[0001327567-16-000064:notes:103]
In May 2014, the FASB issued new authoritative guidance on revenue from contracts with customers. The new standard provides principles for recognizing revenue for the transfer of promised goods or services to customers with the consideration to which the entity expects to be entitled in exchange for those goods or services. The standard also requires significantly expanded disclosures about revenue recognition. The FASB subsequently delayed the effective date of the standard by one year and as a result, the standard is now effective for us for our first quarter of fiscal 2019 using either of two methods: (i) retrospective to each prior reporting period presented with the option to elect certain practical expedients as defined within the guidance; or (ii) retrospective with the cumulative effect of initially applying the guidance recognized at the date of initial application and providing certain additional disclosures as defined per the guidance. Early adoption as of the original effective date is permitted. We are currently evaluating adoption methods and whether this standard will have a material impact on our consolidated financial statements.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001327567-16-000064:notes:104]
Commitments and Contingencies

[0001327567-16-000064:notes:105]
We lease our facilities under various non-cancelable operating leases, which expire through the year ending July 31, 2028.

[0001327567-16-000064:notes:106]
In September 2012, we entered into two lease agreements for an aggregate of approximately 300,000 square feet of space in Santa Clara, California to serve as our corporate headquarters beginning in November 2013. The leases commenced in November 2012 and August 2013, expire in July 2023, and allow for two separate five-year options to extend the lease term. Payments under these leases are approximately $94.3 million over the lease term. Each lease has a rent holiday, which was included in the determination of rent expense.

[0001327567-16-000064:notes:107]
In July 2013, we entered into a 51-month sub-lease agreement for our previous corporate headquarters with a commencement date of January 2014. Net proceeds from this sub-lease are approximately $10.7 million over the lease term.

[0001327567-16-000064:notes:108]
In May 2015, we entered into three lease agreements for approximately 752,000 square feet of corporate office space in Santa Clara, California to serve as our future corporate headquarters. In October 2015, we entered into a fourth lease agreement for approximately 310,000 square feet of additional office space at the same location. The first lease commenced in February 2016 and will expire in April 2021. The remaining three leases will commence between May 2017 and December 2017 and expire in April 2028, however, the property is currently under construction and as a result, the lease commencement dates may change based on progress of the construction project. The leases contain a rent holiday period, scheduled rent increases, lease incentives, and renewal options which allow the lease terms to be extended through April 2046. Rental payments under the four lease agreements are approximately $376.7 million over the lease term.

[0001327567-16-000064:notes:109]
We recognized rent expense of $20.2 million, $15.4 million, and $13.2 million for the years ended July 31, 2016, 2015, and 2014, respectively. Rent expense is recognized on a straight-line basis over the term of the lease.

[0001327567-16-000064:notes:110]
The following table presents details of the aggregate future non-cancelable minimum rental payments under our operating leases as of July 31, 2016 (in millions):

[0001327567-16-000064:notes:111]
|  | Amount |
| Years ending July 31: |  |
| 2017 | $ | 27.3 |  |
| 2018 | 33.3 |  |
| 2019 | 46.2 |  |
| 2020 | 49.8 |  |
| 2021 | 54.1 |  |
| 2022 and thereafter | 298.6 |  |
| Committed gross lease payments | 509.3 |  |
| Less: proceeds from sublease rental | 5.1 |  |
| Net operating lease obligation | $ | 504.2 |  |

[0001327567-16-000064:notes:112]
Contract Manufacturer Commitments

[0001327567-16-000064:notes:113]
Our independent contract manufacturer procures components and assembles our products based on our forecasts. These forecasts are based on estimates of demand for our products primarily for the next 12 months, which are in turn based on historical trends and an analysis from our sales and product marketing organizations, adjusted for overall market conditions. In order to reduce manufacturing lead times and plan for adequate supply, we may issue forecasts and orders for components and products that are non-cancelable. As of July 31, 2016, our purchase commitments under such orders were $54.2 million, excluding obligations under contracts that we can cancel without a significant penalty.

[0001327567-16-000064:notes:114]
Litigation

[0001327567-16-000064:notes:115]
In December 2011, Juniper Networks, Inc. (“Juniper”) filed a complaint against us in the United States District Court for the District of Delaware alleging patent infringement, which sought preliminary and permanent injunctions against infringement, treble damages, and attorneys’ fees. On September 30, 2013, we filed a lawsuit against Juniper in the United States District Court for the Northern District of California alleging that Juniper’s products infringe three of our U.S. patents, and sought monetary damages and a permanent injunction. On May 27, 2014, we entered into a Settlement, Release and Cross-License Agreement (the “Settlement Agreement”) with Juniper to resolve all pending litigation between the parties, including those discussed above. Refer to Note 9. Legal Settlement for more information on the Settlement Agreement.

[0001327567-16-000064:notes:116]
In addition to the above matter, we are subject to legal proceedings, claims, and litigation arising in the ordinary course of business, including intellectual property litigation. Such matters are subject to many uncertainties and outcomes are not predictable with assurance. We accrue for contingencies when we believe that a loss is probable and that we can reasonably estimate the amount of any such loss.

[0001327567-16-000064:notes:117]
To the extent there is a reasonable possibility that a loss exceeding amounts already recognized may be incurred and the amount of such additional loss would be material, we will either disclose the estimated additional loss or state that such an estimate cannot be made. As of July 31, 2016, we have not recorded any significant accruals for loss contingencies associated with such legal proceedings, determined that an unfavorable outcome is probable or reasonably possible, or determined that the amount or range of any possible loss is reasonably estimable.

[0001327567-16-000064:notes:118]
Indemnification

[0001327567-16-000064:notes:119]
Under the indemnification provisions of our standard sales related contracts, we agree to defend our end-customers against third-party claims asserting infringement of certain intellectual property rights, which may include patents, copyrights, trademarks, or trade secrets, and to pay judgments entered on such claims. Our exposure under these indemnification provisions is generally limited to payments made to us for the alleged infringing products over the preceding twelve months under the agreement. However, certain agreements include indemnification provisions that could potentially expose us to losses in excess of these payments. In addition, we indemnify our officers, directors, and certain key employees while they are serving in good faith in their company capacities. To date, we have not recorded any accruals for loss contingencies associated with indemnification claims or determined that an unfavorable outcome is probable or reasonably possible.


## us-gaap:CompensationAndEmployeeBenefitPlansTextBlock

[0001327567-16-000064:notes:120]
Employee Benefit Plan

[0001327567-16-000064:notes:121]
We have established a 401(k) tax-deferred savings plan which permits participants to make contributions by salary deduction pursuant to Section 401(k) of the Internal Revenue Code. In fiscal 2016, we began to make matching contributions based upon the amount of employees’ contributions, subject to certain limitations. Our matching contributions to the plan were immaterial for the year ended July 31, 2016.


## us-gaap:ConvertibleDebtTableTextBlock

[0001327567-16-000064:notes:122]
The following table sets forth the components of the Notes as of July 31, 2016 and July 31, 2015 (in millions):

[0001327567-16-000064:notes:123]
|  | July 31, |
|  | 2016 |  | 2015 |
| Liability: |  |  |  |
| Principal | $ | 575.0 |  |  | $ | 575.0 |  |
| Less: debt discount, net of amortization | 66.8 |  |  | 87.9 |  |
| Net carrying amount | $ | 508.2 |  |  | $ | 487.1 |  |
| Equity (including temporary equity) | $ | 109.8 |  |  | $ | 109.8 |  |


## us-gaap:DebtDisclosureTextBlock

[0001327567-16-000064:notes:124]
On June 30, 2014, we issued $575.0 million aggregate principal amount of 0.0% Convertible Senior Notes due 2019 (the “Notes”). The Notes are governed by an indenture between us, as the issuer, and U.S. Bank National Association, as Trustee (the “Indenture”). The Notes are unsecured, unsubordinated obligations that do not contain any financial covenants or restrictions on the payments of dividends, the incurrence of indebtedness, or the issuance or repurchase of securities by us or any of our subsidiaries. The Notes mature on July 1, 2019 unless converted or repurchased in accordance with their terms prior to such date. We cannot redeem the Notes prior to maturity.

[0001327567-16-000064:notes:125]
The Notes are convertible for up to 5.2 million shares of our common stock at an initial conversion rate of approximately 9.068 shares of common stock per $1,000 principal amount, which is equal to an initial conversion price of approximately $110.28 per share of common stock, subject to adjustment. Holders of the Notes may surrender their Notes for conversion at their option at any time prior to the close of business on the business day immediately preceding January 1, 2019, only under the following circumstances:

[0001327567-16-000064:notes:126]
| • | during any fiscal quarter commencing after the fiscal quarter ending on October 31, 2014 (and only during such fiscal quarter), if the last reported sale price of our common stock for at least 20 trading days (whether or not consecutive) during a period of 30 consecutive trading days ending on the last trading day of the immediately preceding fiscal quarter is greater than or equal to 130% of the conversion price for the Notes on each applicable trading day (the “sale price condition”); |

[0001327567-16-000064:notes:127]
| • | during the five business day period after any five consecutive trading day period, in which the trading price per $1,000 principal amount of Notes for each trading day of the measurement period was less than 98% of the product of the last reported sale price of our common stock and the conversion rate for the Notes on each such trading day; or |

[0001327567-16-000064:notes:128]
| • | upon the occurrence of specified corporate events. |

[0001327567-16-000064:notes:129]
On or after January 1, 2019, holders may convert all or any portion of their Notes at any time prior to the close of business on the second scheduled trading day immediately preceding the maturity date regardless of the foregoing conditions. Upon conversion, holders will receive cash equal to the aggregate principal amount of the Notes to be converted, and, at our election, cash and/or shares of our common stock for any amounts in excess of the aggregate principal amount of the Notes being converted.

[0001327567-16-000064:notes:130]
The conversion price will be subject to adjustment in some events. Holders of the Notes who convert their Notes in connection with certain corporate events that constitute a “make-whole fundamental change” per the Indenture are, under certain circumstances, entitled to an increase in the conversion rate. Additionally, upon the occurrence of a corporate event that constitutes a “fundamental change” per the Indenture, holders of the Notes may require us to repurchase for cash all or a portion of the Notes at a purchase price equal to 100% of the principal amount of the Notes plus accrued and unpaid contingent interest.

[0001327567-16-000064:notes:131]
In accounting for the issuance of the Notes, we separated the Notes into liability and equity components. The carrying amount of the liability component was calculated by measuring the fair value of a similar liability that does not have an associated convertible feature. The carrying amount of the equity component representing the conversion option was determined by deducting the fair value of the liability component from the par value of the Notes as a whole. The difference between the principal amount of the Notes and the liability component (the “debt discount”), is amortized to interest expense using the effective interest method over the term of the Notes. The equity component of the Notes was recorded in additional paid-in capital in our consolidated balance sheets and is not remeasured as long as it continues to meet the conditions for equity classification.

[0001327567-16-000064:notes:132]
In accounting for the transaction costs related to the issuance of the Notes, we allocated the total amount incurred to the liability and equity components using the same proportions as the proceeds from the Notes. Transaction costs attributable to the liability component were recorded in other assets in our consolidated balance sheets and are being amortized to interest expense in our consolidated statements of operations using the effective interest method over the term of the Notes. Transaction costs attributable to the equity component were netted with the equity component of the Notes in additional paid-in capital in our consolidated balance sheets. We recorded liability issuance costs, or debt issuance costs, of $12.5 million and equity issuance costs of $2.9 million.

[0001327567-16-000064:notes:133]
The sale price condition was met during the fiscal quarter ended July 31, 2015, and as a result, holders could convert their Notes at any time during the fiscal quarter ending October 31, 2015. Accordingly, the net carrying amount of the Notes and related debit issuance costs were classified in current liabilities and current assets, respectively, and a portion of the equity component representing the conversion option was classified as temporary equity in our consolidated balance sheets as of July 31, 2015. The portion of the equity component classified as temporary equity was measured as the difference between the principal and net carrying amount of the Notes. The sale price condition was not met during the fiscal quarter ended July 31, 2016. Since the Notes were no longer convertible, the net carrying amount of the Notes and related debt issuance costs were reclassified into long-term liabilities and other assets, respectively, in our consolidated balance sheets as of July 31, 2016. In addition, the portion of the equity component classified as temporary equity was reclassified into additional paid-in capital in our consolidated balance sheets as of July 31, 2016.

[0001327567-16-000064:notes:134]
The total estimated fair value of the Notes was $761.9 million and $994.8 million at July 31, 2016 and July 31, 2015, respectively. The fair value was determined based on the closing trading price per $100 of the Notes as of the last day of trading for the period. We consider the fair value of the Notes at July 31, 2016 and July 31, 2015 to be a Level 2 measurement. The fair value of the Notes is primarily affected by the trading price of our common stock and market interest rates. As of July 31, 2016, the if-converted value of the Notes exceeded its principal amount by $80.0 million.

[0001327567-16-000064:notes:135]
The following table sets forth interest expense recognized related to the Notes (dollars in millions):

[0001327567-16-000064:notes:136]
|  | Year Ended July 31, |
|  | 2016 |  | 2015 |  | 2014 |
| Amortization of debt discount | $ | 21.1 |  |  | $ | 20.2 |  |  | $ | 1.6 |  |
| Amortization of debt issuance costs | 2.3 |  |  | 2.1 |  |  | 0.2 |  |
| Total interest expense recognized | $ | 23.4 |  |  | $ | 22.3 |  |  | $ | 1.8 |  |
| Effective interest rate of the liability component | 4.8 | % |  | 4.8 | % |  | 4.8 | % |

[0001327567-16-000064:notes:137]
Note Hedges

[0001327567-16-000064:notes:138]
To minimize the impact of potential economic dilution upon conversion of the Notes, we entered into convertible note hedge transactions (the “Note Hedges”) with respect to our common stock concurrent with the issuance of the Notes. The Note Hedges cover up to 5.2 million shares of our common stock at a strike price per share that corresponds to the initial conversion price of the Notes, which are also subject to adjustment, and are exercisable upon conversion of the Notes. The Note Hedges will expire upon maturity of the Notes. The Note Hedges are separate transactions and are not part of the terms of the Notes. Holders of the Notes will not have any rights with respect to the Note Hedges. The shares receivable related to the Note Hedges are excluded from the calculation of diluted earnings per share as they are antidilutive.

[0001327567-16-000064:notes:139]
We paid an aggregate amount of $111.0 million for the Note Hedges, which is included in additional paid-in capital in our consolidated balance sheets.

[0001327567-16-000064:notes:140]
Warrants

[0001327567-16-000064:notes:141]
Separately, but concurrently with our issuance of the Notes, we entered into transactions whereby we sold warrants (the “Warrants”) to acquire up to 5.2 million shares of our common stock at a strike price of approximately $137.85 per share, subject to adjustments. The shares issuable under the Warrants will be included in the calculation of diluted earnings per share when the average market value per share of our common stock for the reporting period exceeds the strike price of the Warrants. The Warrants are separate transactions and are not part of the Notes or Notes Hedges, and are not remeasured through earnings each reporting period. Holders of the Notes and Note Hedges will not have any rights with respect to the Warrants.

[0001327567-16-000064:notes:142]
We received aggregate proceeds of $78.3 million from the sale of the Warrants, which is included in additional paid-in capital in our consolidated balance sheets.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001327567-16-000064:notes:143]
Equity Award Plans

[0001327567-16-000064:notes:144]
Share-Based Compensation Plans

[0001327567-16-000064:notes:145]
2012 Equity Incentive Plan

[0001327567-16-000064:notes:146]
Our 2012 Equity Incentive Plan (our “2012 Plan”) was adopted by our board of directors and approved by the stockholders on June 5, 2012 and was effective one business day prior to the effectiveness of our registration statement for our initial public offering (“IPO”). Our 2012 Plan replaced our 2005 Equity Incentive Plan (our “2005 Plan”), which terminated upon the completion of our IPO, however, awards that were outstanding upon termination remained outstanding pursuant to their original terms. Our 2012 Plan provides for the granting of stock options, restricted stock awards (“RSAs”), restricted stock units (“RSUs”), stock appreciation rights, performance units, and performance shares to our employees, directors, and consultants.

[0001327567-16-000064:notes:147]
Awards granted under our 2012 Plan vest over the periods determined by the board of directors, generally three to four years from the date of grant, and our options expire no more than ten years after the date of grant. Since our IPO in 2012, awards granted under our 2012 Plan consist primarily of RSUs. Until vested, RSUs do not have the voting and dividend participation rights of common stock and the shares underlying the awards are not considered issued and outstanding.

[0001327567-16-000064:notes:148]
A total of 16.8 million shares of our common stock are reserved for issuance pursuant to our 2012 Plan as of July 31, 2016. This includes shares that are (i) reserved but unissued under our 2005 Plan on the effective date of our 2012 Plan or (ii) returned to our 2005 Plan as a result of expiration or termination of options. On the first day of each fiscal year, the number of shares in the reserve may be increased by the lesser of (i) 8,000,000 shares, (ii) 4.5% of the outstanding shares of common stock on the last day of our immediately preceding fiscal year, or (iii) such other amount as determined by our board of directors.

[0001327567-16-000064:notes:149]
2012 Employee Stock Purchase Plan

[0001327567-16-000064:notes:150]
Our 2012 Employee Stock Purchase Plan (our “2012 ESPP”) was adopted by our board of directors and approved by the stockholders on June 5, 2012 and was effective upon completion of our IPO.

[0001327567-16-000064:notes:151]
Our 2012 ESPP permits eligible employees to acquire shares of our common stock at 85% of the lower of the fair market value of our common stock on the first trading day of each offering period or on the exercise date. Each offering period will be approximately six months starting on the first trading date after March 15 and September 15 of each year. Participants may purchase shares of common stock through payroll deductions of up to 15% of their eligible compensation, subject to purchase limits of 625 shares during a six-month period or $25,000 worth of stock for each calendar year. During the year ended July 31, 2016, employees purchased 0.2 million shares of common stock under our 2012 ESPP at an average exercise price of $126.96 per share.

[0001327567-16-000064:notes:152]
A total of 2.4 million shares of our common stock are available for sale under our 2012 ESPP as of July 31, 2016. On the first day of each fiscal year, the number of shares in the reserve may be increased by the lesser of (i) 2,000,000 shares, (ii) 1% of the outstanding shares of our common stock on the first day of the fiscal year, or (iii) such other amount as determined by our board of directors.

[0001327567-16-000064:notes:153]
Stock Option Activities

[0001327567-16-000064:notes:154]
The following table summarizes the stock option activity under our stock plans during the reporting period (in millions, except per share amounts):

[0001327567-16-000064:notes:155]
|  | Options Outstanding |
|  | Number ofShares |  | Weighted- Average Exercise Price Per Share |  | Weighted- Average Remaining Contractual Term (Years) |  | Aggregate Intrinsic Value |
| Balance—July 31, 2015 | 3.3 |  |  | $ | 13.74 |  |  | 6.2 |  | $ | 562.9 |  |
| Options granted | — |  |  | — |  |  |  |  |  |
| Options forfeited | — |  |  | — |  |  |  |  |  |
| Options exercised | (1.2 | ) |  | 14.21 |  |  |  |  |  |
| Balance—July 31, 2016 | 2.1 |  |  | $ | 13.42 |  |  | 5.2 |  | $ | 244.9 |  |
| Options vested and expected to vest—July 31, 2016 | 2.1 |  |  | $ | 13.42 |  |  | 5.2 |  | $ | 244.9 |  |
| Options exercisable—July 31, 2016 | 2.1 |  |  | $ | 13.42 |  |  | 5.2 |  | $ | 244.9 |  |

[0001327567-16-000064:notes:156]
The intrinsic value of options exercised during the years ended July 31, 2016, 2015, and 2014 was $176.1 million, $301.1 million, and $198.8 million, respectively. The grant-date fair value of options vested during the years ended July 31, 2016, 2015, and 2014 was $8.1 million, $14.6 million, and $17.1 million, respectively.

[0001327567-16-000064:notes:157]
Restricted Stock Unit (“RSU”) and Restricted Stock Award (“RSA”) Activities

[0001327567-16-000064:notes:158]
The following table summarizes the RSU and RSA activity under our stock plans during the reporting period (in millions, except per share amounts):

[0001327567-16-000064:notes:159]
|  | RSAs Outstanding |  | RSUs Outstanding |
|  | Number of Shares |  | Weighted- Average Grant-Date Fair Value Per Share |  | Number of Shares |  | Weighted- Average Grant-Date Fair Value Per Share |  | Weighted- Average Remaining Contractual Term (Years) |  | Aggregate Intrinsic Value |
| Balance—July 31, 2015 | — |  |  | $ | — |  |  | 7.2 |  |  | $ | 95.66 |  |  | 1.2 |  | $ | 1,334.8 |  |
| Granted | 1.1 |  |  | 170.97 |  |  | 3.2 |  |  | 160.60 |  |  |  |  |  |
| Vested | — |  |  | — |  |  | (3.3 | ) |  | 89.76 |  |  |  |  |  |
| Forfeited | — |  |  | — |  |  | (0.6 | ) |  | 104.08 |  |  |  |  |  |
| Balance—July 31, 2016 | 1.1 |  |  | $ | 170.97 |  |  | 6.5 |  |  | $ | 130.14 |  |  | 1.1 |  | $ | 852.7 |  |
| Expected to vest—July 31, 2016 | 1.0 |  |  | $ | 170.97 |  |  | 6.2 |  |  | $ | 129.64 |  |  | 1.1 |  | $ | 810.0 |  |

[0001327567-16-000064:notes:160]
The weighted-average grant-date fair value of RSUs granted during the years ended July 31, 2016, 2015, and 2014 was $160.60, $122.36, and $61.00 per share, respectively. The aggregate fair value, as of the respective vesting dates, of RSUs vested during the years ended July 31, 2016, 2015, and 2014 was $513.0 million, $350.4 million, and $57.4 million, respectively.

[0001327567-16-000064:notes:161]
Shares Available for Grant

[0001327567-16-000064:notes:162]
We record share-based compensation awards based on estimated fair value as of the grant date. The fair value of RSUs and RSAs is based on the closing market price of our common stock on the date of grant. The fair value of shares sold through our 2012 ESPP are estimated on the grant date using the Black-Scholes option pricing model.

[0001327567-16-000064:notes:163]
The following table summarizes share-based compensation included in costs and expenses (in millions):

[0001327567-16-000064:notes:164]
|  | Year Ended July 31, |
|  | 2016 |  | 2015 |  | 2014 |
| Cost of product revenue | $ | 6.2 |  |  | $ | 3.9 |  |  | $ | 1.6 |  |
| Cost of services revenue | 40.9 |  |  | 20.4 |  |  | 9.4 |  |
| Research and development | 132.9 |  |  | 74.8 |  |  | 29.5 |  |
| Sales and marketing | 152.4 |  |  | 84.1 |  |  | 42.6 |  |
| General and administrative | 60.5 |  |  | 38.2 |  |  | 16.8 |  |
| Total share-based compensation | $ | 392.9 |  |  | $ | 221.4 |  |  | $ | 99.9 |  |

[0001327567-16-000064:notes:165]
During the year ended July 31, 2014, we accelerated the vesting of certain share-based awards in connection with our acquisitions of Cyvera and Morta and as a result, we recorded $3.4 million of compensation expense within general and administrative expense. At July 31, 2016, total compensation cost related to unvested share-based awards not yet recognized was $822.9 million, net of estimated forfeitures. This cost is expected to be amortized on a straight-line basis over a weighted-average period of approximately 2.4 years. Future grants will increase the amount of compensation expense to be recorded in these periods.


## us-gaap:EarningsPerShareTextBlock

[0001327567-16-000064:notes:166]
Net Income (Loss) Per Share

[0001327567-16-000064:notes:167]
Basic net income (loss) per share is computed by dividing net income (loss) by basic weighted-average shares outstanding during the period. Diluted net income (loss) per share is computed by dividing net income (loss) by diluted weighted-average shares outstanding, including potentially dilutive securities.

[0001327567-16-000064:notes:168]
The following table presents the computation of basic and diluted net loss per share of common stock (in millions, except per share data):

[0001327567-16-000064:notes:169]
|  | Year Ended July 31, |
|  | 2016 |  | 2015 |  | 2014 |
| Net loss | $ | (225.9 | ) |  | $ | (165.0 | ) |  | $ | (226.5 | ) |
| Weighted-average shares used to compute net loss per share, basic and diluted | 87.1 |  |  | 81.6 |  |  | 74.3 |  |
| Net loss per share, basic and diluted | $ | (2.59 | ) |  | $ | (2.02 | ) |  | $ | (3.05 | ) |

[0001327567-16-000064:notes:170]
The following securities were excluded from the computation of diluted net loss per share of common stock for the periods presented as their effect would have been antidilutive (in millions):

[0001327567-16-000064:notes:171]
|  | Year Ended July 31, |
|  | 2016 |  | 2015 |  | 2014 |
| RSUs | 6.5 |  |  | 7.2 |  |  | 6.0 |  |
| Convertible senior notes | 5.2 |  |  | 5.2 |  |  | 5.2 |  |
| Warrants related to the issuance of convertible senior notes | 5.2 |  |  | 5.2 |  |  | 5.2 |  |
| Options to purchase common stock | 2.1 |  |  | 3.3 |  |  | 5.8 |  |
| RSAs | 1.1 |  |  | — |  |  | — |  |
| ESPP shares | 0.1 |  |  | 0.1 |  |  | 0.1 |  |
| Total | 20.2 |  |  | 21.0 |  |  | 22.3 |  |


## us-gaap:FairValueAssetsAndLiabilitiesMeasuredOnRecurringAndNonrecurringBasisTableTextBlock

[0001327567-16-000064:notes:172]
The following table presents the fair value of our financial assets and liabilities using the above input categories as of July 31, 2016 and July 31, 2015 (in millions):

[0001327567-16-000064:notes:173]
|  |  | July 31, 2016 |  | July 31, 2015 |
|  |  | Level 1 |  | Level 2 |  | Level 3 |  | Total |  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| Short-term investments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Certificates of deposit |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 1.0 |  |  | $ | — |  |  | $ | 1.0 |  |
| Commercial paper |  | — |  |  | 3.0 |  |  | — |  |  | 3.0 |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Corporate debt securities |  | — |  |  | 121.4 |  |  | — |  |  | 121.4 |  |  | — |  |  | 97.8 |  |  | — |  |  | 97.8 |  |
| U.S. government and agency securities |  | — |  |  | 426.8 |  |  | — |  |  | 426.8 |  |  | — |  |  | 314.4 |  |  | — |  |  | 314.4 |  |
| Total short-term investments |  | — |  |  | 551.2 |  |  | — |  |  | 551.2 |  |  | — |  |  | 413.2 |  |  | — |  |  | 413.2 |  |
| Long-term investments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Certificates of deposit |  | — |  |  | 5.4 |  |  | — |  |  | 5.4 |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Corporate debt securities |  | — |  |  | 166.1 |  |  | — |  |  | 166.1 |  |  | — |  |  | 92.9 |  |  | — |  |  | 92.9 |  |
| U.S. government and agency securities |  | — |  |  | 481.3 |  |  | — |  |  | 481.3 |  |  | — |  |  | 445.9 |  |  | — |  |  | 445.9 |  |
| Total long-term investments |  | — |  |  | 652.8 |  |  | — |  |  | 652.8 |  |  | — |  |  | 538.8 |  |  | — |  |  | 538.8 |  |
| Total assets measured at fair value |  | $ | — |  |  | $ | 1,204.0 |  |  | $ | — |  |  | $ | 1,204.0 |  |  | $ | — |  |  | $ | 952.0 |  |  | $ | — |  |  | $ | 952.0 |  |


## us-gaap:FairValueDisclosuresTextBlock

[0001327567-16-000064:notes:174]
Fair Value Measurements

[0001327567-16-000064:notes:175]
We categorize assets and liabilities recorded at fair value on our consolidated balance sheets based upon the level of judgment associated with inputs used to measure their fair value. The categories are as follows:

[0001327567-16-000064:notes:176]
| • | Level 1—Inputs are unadjusted quoted prices in active markets for identical assets or liabilities. |

[0001327567-16-000064:notes:177]
| • | Level 2—Inputs are quoted prices for similar assets and liabilities in active markets or inputs that are observable for the assets or liabilities, either directly or indirectly through market corroboration, for substantially the full term of the financial instruments. |

[0001327567-16-000064:notes:178]
| • | Level 3—Inputs are unobservable inputs based on our own assumptions used to measure assets and liabilities at fair value. The inputs require significant management judgment or estimation. |

[0001327567-16-000064:notes:179]
Refer to Note 7. Convertible Senior Notes for the carrying amount and estimated fair value of our convertible senior notes as of July 31, 2016 and July 31, 2015.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001327567-16-000064:notes:180]
Intangible Assets

[0001327567-16-000064:notes:181]
The following table presents details of our purchased intangible assets as of July 31, 2016 and July 31, 2015 (in millions):

[0001327567-16-000064:notes:182]
|  | July 31, |
|  | 2016 |  | 2015 |
|  | Gross Carrying Amount |  | Accumulated Amortization |  | Net Carrying Amount |  | Gross Carrying Amount |  | Accumulated Amortization |  | Net Carrying Amount |
| Developed technology | $ | 53.1 |  |  | $ | (15.4 | ) |  | $ | 37.7 |  |  | $ | 53.1 |  |  | $ | (7.7 | ) |  | $ | 45.4 |  |
| Acquired intellectual property | 8.9 |  |  | (2.9 | ) |  | 6.0 |  |  | 8.2 |  |  | (1.9 | ) |  | 6.3 |  |
| In-process research and development held for defensive purposes | 1.9 |  |  | (1.6 | ) |  | 0.3 |  |  | 1.9 |  |  | (1.0 | ) |  | 0.9 |  |
| Other | 0.5 |  |  | (0.5 | ) |  | — |  |  | 0.5 |  |  | (0.4 | ) |  | 0.1 |  |
| Total purchased intangible assets | $ | 64.4 |  |  | $ | (20.4 | ) |  | $ | 44.0 |  |  | $ | 63.7 |  |  | $ | (11.0 | ) |  | $ | 52.7 |  |

[0001327567-16-000064:notes:183]
We recognized amortization expense of $9.4 million, $7.9 million, and $2.9 million for the years ended July 31, 2016, 2015, and 2014, respectively.

[0001327567-16-000064:notes:184]
The following table summarizes our estimated future amortization expense of intangible assets as of July 31, 2016 (in millions):

[0001327567-16-000064:notes:185]
|  | Amount |
| Years ending July 31: |  |
| 2017 | $ | 8.7 |  |
| 2018 | 8.3 |  |
| 2019 | 8.2 |  |
| 2020 | 8.1 |  |
| 2021 | 6.5 |  |
| 2022 and thereafter | 4.2 |  |
| Total future amortization expense | $ | 44.0 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0001327567-16-000064:notes:186]
The following table presents the components of income (loss) before income taxes (in millions):

[0001327567-16-000064:notes:187]
|  | Year Ended July 31, |
|  | 2016 |  | 2015 |  | 2014 |
| United States | $ | (216.2 | ) |  | $ | (47.5 | ) |  | $ | (149.3 | ) |
| Foreign | 11.1 |  |  | (108.1 | ) |  | (72.9 | ) |
| Total | $ | (205.1 | ) |  | $ | (155.6 | ) |  | $ | (222.2 | ) |

[0001327567-16-000064:notes:188]
The following table summarizes the provision for income taxes (in millions):

[0001327567-16-000064:notes:189]
|  | Year Ended July 31, |
|  | 2016 |  | 2015 |  | 2014 |
| Federal: |  |  |  |  |  |
| Current | $ | 1.9 |  |  | $ | 1.8 |  |  | $ | 0.8 |  |
| Deferred | (0.6 | ) |  | (3.0 | ) |  | — |  |
| State: |  |  |  |  |  |
| Current | 1.1 |  |  | 0.7 |  |  | 0.2 |  |
| Deferred | (0.1 | ) |  | (0.4 | ) |  | (0.3 | ) |
| Foreign: |  |  |  |  |  |
| Current | 19.1 |  |  | 10.7 |  |  | 4.7 |  |
| Deferred | (0.6 | ) |  | (0.4 | ) |  | (1.1 | ) |
| Total | $ | 20.8 |  |  | $ | 9.4 |  |  | $ | 4.3 |  |

[0001327567-16-000064:notes:190]
For the year ended July 31, 2016, our provision for income taxes increased compared to the year ended July 31, 2015 primarily due to an increase in foreign taxes and amortization of our deferred tax charges.

[0001327567-16-000064:notes:191]
For the year ended July 31, 2015, due to our acquisition of CirroSecure, a deferred tax liability was established for the book-tax basis difference related to purchased intangibles. The net deferred tax liability from acquisitions provided an additional source of income to support the realizability of our pre-existing deferred tax assets and as a result, we released a portion of the valuation allowance that was established in the previous year and recorded a tax benefit of $3.4 million.

[0001327567-16-000064:notes:192]
The following table presents the items accounting for the difference between income taxes computed at the federal statutory income tax rate and the provision for income taxes:

[0001327567-16-000064:notes:193]
|  | Year Ended July 31, |
|  | 2016 |  | 2015 |  | 2014 |
| Federal statutory rate | 35.0 | % |  | 35.0 | % |  | 35.0 | % |
| Effect of: |  |  |  |  |  |
| State taxes, net of federal tax benefit | (1.5 | ) |  | 3.6 |  |  | 1.3 |  |
| Foreign income at other than U.S. rates | (8.8 | ) |  | (6.5 | ) |  | (12.1 | ) |
| Change in valuation allowance | (24.9 | ) |  | (28.5 | ) |  | (21.3 | ) |
| Share-based compensation | (13.3 | ) |  | (10.2 | ) |  | (3.2 | ) |
| Amortization of deferred tax charges | (2.8 | ) |  | (2.2 | ) |  | — |  |
| Research credits | 9.5 |  |  | 6.7 |  |  | 1.3 |  |
| Other, net | (3.4 | ) |  | (3.9 | ) |  | (2.9 | ) |
| Total | (10.2 | )% |  | (6.0 | )% |  | (1.9 | )% |

[0001327567-16-000064:notes:194]
During the year ended July 31, 2016, we accounted for the outcome of The Gillette Company et al. v. California Franchise Tax Board which disallowed the election to use an evenly weighted, three factor apportionment formula utilized by us on our tax return for the year ended July 31, 2014. The impact for the change in apportionment is reflected in state taxes, net of federal tax benefit above and is fully offset by changes in our valuation allowance.

[0001327567-16-000064:notes:195]
During the year ended July 31, 2015, we completed several changes to our corporate structure to more closely align with the global nature of our business. As a result, we recorded deferred tax charges in prepaid expenses and other current assets and other assets on our consolidated balance sheets. These amounts are being amortized on a straight-line basis over the life of the associated assets as a component of provision for income taxes in our consolidated statements of operations.

[0001327567-16-000064:notes:196]
The following table presents the components of our deferred tax assets and liabilities as of July 31, 2016 and July 31, 2015 (in millions):

[0001327567-16-000064:notes:197]
|  | July 31, |
|  | 2016 |  | 2015 |
| Deferred tax assets: |  |  |  |
| Accruals and reserves | $ | 43.5 |  |  | $ | 38.9 |  |
| Deferred revenue | 62.0 |  |  | 35.3 |  |
| Research and development and foreign tax credits | 41.4 |  |  | 20.1 |  |
| Net operating loss carryforwards | 5.4 |  |  | 18.4 |  |
| Share-based compensation | 55.2 |  |  | 35.9 |  |
| Gross deferred tax assets | 207.5 |  |  | 148.6 |  |
| Valuation allowance | (189.4 | ) |  | (138.4 | ) |
| Total deferred tax assets | 18.1 |  |  | 10.2 |  |
| Deferred tax liabilities: |  |  |  |
| Fixed assets and intangible assets | (14.2 | ) |  | (7.9 | ) |
| Other deferred tax liabilities | (2.5 | ) |  | (1.6 | ) |
| Total deferred tax liabilities | (16.7 | ) |  | (9.5 | ) |
| Total | $ | 1.4 |  |  | $ | 0.7 |  |

[0001327567-16-000064:notes:198]
A valuation allowance is provided when it is more likely than not that the deferred tax asset will not be realized. Realization of deferred tax assets is dependent upon future taxable income, if any, the amount and timing of which are uncertain. At such time, if it is determined that it is more likely than not that the deferred tax assets are realizable, the valuation allowance will be adjusted. As of July 31, 2016, we have provided a valuation allowance for our federal and state deferred tax assets that we believe will, more likely than not, be unrealizable. The net valuation allowance increased by approximately $51.0 million from the year ended July 31, 2015 to the year ended July 31, 2016, which was primarily attributable to an increase in deferred tax assets in our federal and state jurisdictions.

[0001327567-16-000064:notes:199]
As of July 31, 2016, we had federal, state, and foreign NOL carryforwards of approximately $1.1 billion, $823.8 million, and $8.9 million, respectively as reported on our tax returns, available to reduce future taxable income, if any. If not utilized, our federal and state NOL carryforwards will expire in various amounts at various dates beginning in the years ending July 31, 2027 and July 31, 2017, respectively. Our foreign NOL will carry forward indefinitely.

[0001327567-16-000064:notes:200]
As of July 31, 2016, we had federal and state research and development tax credit carryforwards of approximately $37.1 million and $37.2 million, respectively as reported on our tax returns. If not utilized, the federal credit carryforwards will expire in various amounts at various dates beginning in the year ending July 31, 2026. The state credit will carry forward indefinitely.

[0001327567-16-000064:notes:201]
As of July 31, 2016, we had foreign tax credit carryforwards of $1.7 million as reported on our tax returns. If not utilized, the foreign tax credit carryforwards will expire in various amounts at various dates beginning in the year ending July 31, 2021.

[0001327567-16-000064:notes:202]
Utilization of the NOL carryforwards and credits may be subject to a substantial annual limitation due to the ownership change limitations provided by the Internal Revenue Code of 1986, as amended, and similar state provisions. The annual limitation may result in the expiration of NOLs and credits before utilization.

[0001327567-16-000064:notes:203]
We use the with-and-without approach to determine the recognition and measurement of excess tax benefits resulting from share-based awards. Accordingly, we have elected to recognize excess income tax benefits from share-based awards in additional paid-in capital only if an incremental income tax benefit would be realized after considering all other tax attributes presently available to us. As of July 31, 2016, we had excess tax benefits from share-based awards of $1.0 billion, $669.7 million, and $8.9 million included in federal, state, and foreign NOL, respectively. We also had $5.3 million of excess tax benefits from share-based awards included in federal research and development tax credit. The impact of this excess tax benefit is recognized as additional paid-in capital when it reduces taxes payable. We have elected to account for the indirect effects of share-based awards on other tax attributes, such as the research, foreign and other tax credits, through the consolidated statements of operations.

[0001327567-16-000064:notes:204]
During the years ended July 31, 2016, 2015, and 2014, we recorded excess tax benefits that resulted from allocating certain tax effects related to exercises of stock options and vesting of RSUs directly to stockholders’ equity in the amount of $0.5 million, $2.5 million, and $1.0 million, respectively.

[0001327567-16-000064:notes:205]
In December 2015, the Protecting Americans from Tax Hikes Act of 2015 (the “PATH Act”) was signed into law. Among its provisions, the PATH Act retroactively extends the bonus depreciation and other corporate tax incentives through December 31, 2019, and permanently extends the federal research and development credit. Due to the valuation allowance against our domestic deferred tax assets, we did not recognize any discrete tax benefits during the year ended July 31, 2016 as a result of the legislation.

[0001327567-16-000064:notes:206]
As of July 31, 2016, we had $127.7 million of unrecognized tax benefits, $21.9 million of which would affect income tax expense if recognized, after consideration of our valuation allowance in the United States and other assets. As of July 31, 2015, we had $67.2 million of unrecognized tax benefits, $10.8 million of which would affect income tax expense if recognized, after consideration of our valuation allowance in the United States. As of July 31, 2016, our federal, state, and foreign returns for the tax years 2008 through the current period remain subject to adjustment due to examination. Fiscal years outside the normal statute of limitation remain open to audit by tax authorities due to tax attributes generated in earlier years, which have been carried forward and may be audited in subsequent years when utilized. We do not expect the amount of unrecognized tax benefits as of July 31, 2016 to change significantly over the next 12 months. We recognize both interest and penalties associated with uncertain tax positions as a component of income tax expense. During the years ended July 31, 2016, 2015, and 2014, we recognized income tax expense related to interest and penalties of $1.6 million, $1.1 million, and $0.3 million, respectively. We had accrued interest and penalties on our consolidated balance sheets related to unrecognized tax benefits of $3.3 million and $1.8 million as of July 31, 2016 and 2015, respectively. The ultimate amount and timing of any future cash settlements cannot be predicted with reasonable certainty.

[0001327567-16-000064:notes:207]
The following table presents a reconciliation of the beginning and ending amount of our gross unrecognized tax benefits (in millions):

[0001327567-16-000064:notes:208]
|  | Year Ended July 31, |
|  | 2016 |  | 2015 |  | 2014 |
| Unrecognized tax benefits at the beginning of the period | $ | 67.2 |  |  | $ | 10.4 |  |  | $ | 6.6 |  |
| Additions for tax positions taken in prior years | 25.2 |  |  | 6.1 |  |  | 0.4 |  |
| Reductions for tax positions taken in prior years | — |  |  | (0.6 | ) |  | — |  |
| Additions for tax positions taken in the current year | 35.3 |  |  | 51.3 |  |  | 3.4 |  |
| Unrecognized tax benefits at the end of the period | $ | 127.7 |  |  | $ | 67.2 |  |  | $ | 10.4 |  |

[0001327567-16-000064:notes:209]
During the year ended July 31, 2016, our additions for tax positions taken in prior years and additions for tax positions taken in the current year were primarily attributable to uncertain tax positions relating to federal and state research and development credits, adjustments for California apportionment, and transfer pricing methodologies.

[0001327567-16-000064:notes:210]
As of July 31, 2016, we had approximately $9.7 million of undistributed earnings in foreign subsidiaries. We expect to permanently reinvest these earnings outside of the United States to fund future foreign operations. We project that we will have sufficient cash flow in the United States and will not need to repatriate the foreign earnings to finance our domestic operations. If we were to distribute these earnings to the United States, we would be subject to U.S. income taxes, an adjustment for foreign tax credits, and foreign withholding taxes. We have not recorded a deferred tax liability on any portion of our undistributed earnings in foreign subsidiaries. If we were to repatriate these earnings to the United States, any associated income tax liability would be insignificant.


## us-gaap:InvestmentsClassifiedByContractualMaturityDateTableTextBlock

[0001327567-16-000064:notes:211]
The following table summarizes the amortized cost and fair value of our available-for-sale investments as of July 31, 2016, by contractual years-to-maturity (in millions):

[0001327567-16-000064:notes:212]
|  | Amortized Cost |  | Fair Value |
| Due within one year | $ | 551.0 |  |  | $ | 551.2 |  |
| Due between one and three years | 651.4 |  |  | 652.8 |  |
| Total | $ | 1,202.4 |  |  | $ | 1,204.0 |  |


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock

[0001327567-16-000064:notes:213]
Unrealized losses related to these investments are due to interest rate fluctuations as opposed to credit quality. In addition, we do not intend to sell and it is not likely that we would be required to sell these investments before recovery of their amortized cost basis, which may be at maturity. As a result, there were no other-than-temporary impairments for these investments at July 31, 2016 and 2015.

[0001327567-16-000064:notes:214]
We received proceeds of $141.9 million, $18.5 million, and $74.6 million from sales of investments during the years ended July 31, 2016, 2015, and 2014, respectively. We use the specific identification method to determine the cost basis of investments sold.


## us-gaap:LegalMattersAndContingenciesTextBlock

[0001327567-16-000064:notes:215]
Legal Settlement

[0001327567-16-000064:notes:216]
Settlement, Release and Cross-License Agreement with Juniper

[0001327567-16-000064:notes:217]
On May 27, 2014, we entered into the Settlement Agreement with Juniper, whereby we resolved all pending litigation matters. Under the terms of the Settlement Agreement, we agreed to pay Juniper a one-time settlement amount comprised of $75.0 million in cash, 1.1 million shares of our common stock, and a warrant to purchase 0.5 million shares of our common stock, in exchange for the following:

[0001327567-16-000064:notes:218]
| • | Mutual dismissal with prejudice of all pending litigation between the parties and general release of all liability for Palo Alto Networks and Juniper, |

[0001327567-16-000064:notes:219]
| • | Cross-license between both parties for the patents-in-suit and associated family members and counterparts worldwide for the life of the patents, and |

[0001327567-16-000064:notes:220]
| • | Mutual covenant not to sue for infringement of any other patents for a period of eight years. |

[0001327567-16-000064:notes:221]
The fair value of the total consideration as of the settlement date was $182.5 million, which was comprised of $75.0 million in cash, $75.3 million in common stock, and $32.2 million in warrant. The fair values of the common stock and warrant were measured using the closing price of our common stock on the settlement date.

[0001327567-16-000064:notes:222]
The warrant was issued on June 3, 2014 and entitled Juniper to purchase up to 0.5 million shares of common stock at an exercise price of $0.0001 per share and was classified as a liability during the period it was outstanding. On July 1, 2014, Juniper exercised the warrant in full. Accordingly, we recorded the change in the fair value of the warrant liability through the exercise date of $5.9 million within other income (expense), net in our consolidated statement of operations for the year ended July 31, 2014.

[0001327567-16-000064:notes:223]
We accounted for the Settlement Agreement as a multiple-element arrangement and allocated the fair value of the consideration as of the settlement date to the identifiable elements based on their estimated fair values. Of the total settlement amount, $61.3 million was allocated to the licensing of intellectual property, $54.3 million was allocated to the mutual dismissal of claims, and the remaining amount was allocated to the mutual covenant not to sue. The mutual dismissal of claims and the mutual covenant not to sue have no identifiable future benefit, and as a result we recorded a settlement charge within legal settlement expense in our consolidated statement of operations for the year ended July 31, 2014. The licensing of intellectual property is being amortized to cost of product revenue in our consolidated statements of operations over the estimated period of benefit of five years.

[0001327567-16-000064:notes:224]
Mutual Covenant Not to Sue and Release Agreement

[0001327567-16-000064:notes:225]
On January 27, 2014, we executed a Mutual Covenant Not to Sue and Release Agreement with Fortinet, Inc., thereby extending an existing covenant for six more years. We evaluated the transaction as a multiple-element arrangement and allocated the one-time payment that we made in the amount of $20.0 million to each identifiable element using its relative fair value. Based on our estimates of fair value, we determined that the primary benefit of the arrangement is avoided litigation cost and the release of any potential past claims, with no material value attributable to future use or benefit. Accordingly, we recorded a $20.0 million settlement charge within legal settlement expense in our consolidated statement of operations for the year ended July 31, 2014.


## us-gaap:PropertyPlantAndEquipmentDisclosureTextBlock

[0001327567-16-000064:notes:226]
The following table presents details of our property and equipment, net as of July 31, 2016 and July 31, 2015 (in millions):

[0001327567-16-000064:notes:227]
|  | July 31, |
|  | 2016 |  | 2015 |
| Computers, equipment, and software | $ | 102.7 |  |  | $ | 62.6 |  |
| Leasehold improvements | 58.0 |  |  | 25.5 |  |
| Demonstration units | 20.1 |  |  | 16.0 |  |
| Furniture and fixtures | 14.6 |  |  | 6.6 |  |
| Total property and equipment | 195.4 |  |  | 110.7 |  |
| Less: accumulated depreciation | (78.2 | ) |  | (47.8 | ) |
| Total property and equipment, net | $ | 117.2 |  |  | $ | 62.9 |  |

[0001327567-16-000064:notes:228]
We recognized depreciation expense of $33.1 million, $20.3 million, and $14.0 million related to property and equipment during the years ended July 31, 2016, 2015, and 2014, respectively.


## us-gaap:QuarterlyFinancialInformationTextBlock

[0001327567-16-000064:notes:229]
Selected Quarterly Financial Data (Unaudited)

[0001327567-16-000064:notes:230]
The following tables set forth selected unaudited quarterly financial data for the years ended July 31, 2016 and 2015 (in millions, except per share amounts):

[0001327567-16-000064:notes:231]
|  | Three Months Ended |
|  | Oct. 31,2015 |  | Jan. 31,2016 |  | Apr. 30,2016 |  | Jul. 31,2016 |
| Revenue: |  |  |  |  |  |  |  |
| Product | $ | 147.7 |  |  | $ | 169.9 |  |  | $ | 162.1 |  |  | $ | 191.1 |  |
| Services | 149.5 |  |  | 164.8 |  |  | 183.7 |  |  | 209.7 |  |
| Total revenue | 297.2 |  |  | 334.7 |  |  | 345.8 |  |  | 400.8 |  |
| Cost of revenue: |  |  |  |  |  |  |  |
| Product | 38.8 |  |  | 44.9 |  |  | 43.2 |  |  | 48.5 |  |
| Services | 40.4 |  |  | 49.3 |  |  | 51.7 |  |  | 53.2 |  |
| Total cost of revenue | 79.2 |  |  | 94.2 |  |  | 94.9 |  |  | 101.7 |  |
| Total gross profit | 218.0 |  |  | 240.5 |  |  | 250.9 |  |  | 299.1 |  |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | 59.7 |  |  | 74.0 |  |  | 74.0 |  |  | 76.5 |  |
| Sales and marketing | 158.3 |  |  | 187.6 |  |  | 202.0 |  |  | 228.1 |  |
| General and administrative | 30.8 |  |  | 34.2 |  |  | 33.5 |  |  | 39.9 |  |
| Total operating expenses | 248.8 |  |  | 295.8 |  |  | 309.5 |  |  | 344.5 |  |
| Operating loss | (30.8 | ) |  | (55.3 | ) |  | (58.6 | ) |  | (45.4 | ) |
| Interest expense | (5.8 | ) |  | (5.8 | ) |  | (5.8 | ) |  | (6.0 | ) |
| Other income, net | 2.2 |  |  | 2.5 |  |  | 1.0 |  |  | 2.7 |  |
| Loss before income taxes | (34.4 | ) |  | (58.6 | ) |  | (63.4 | ) |  | (48.7 | ) |
| Provision for income taxes | 4.3 |  |  | 3.9 |  |  | 6.8 |  |  | 5.8 |  |
| Net loss | $ | (38.7 | ) |  | $ | (62.5 | ) |  | $ | (70.2 | ) |  | $ | (54.5 | ) |
| Net loss per share, basic and diluted | $ | (0.45 | ) |  | $ | (0.72 | ) |  | $ | (0.80 | ) |  | $ | (0.61 | ) |

[0001327567-16-000064:notes:232]
|  | Three Months Ended |
|  | Oct. 31,2014 |  | Jan. 31,2015 |  | Apr. 30,2015 |  | Jul. 31,2015 |
| Revenue: |  |  |  |  |  |  |  |
| Product | $ | 101.5 |  |  | $ | 115.6 |  |  | $ | 121.5 |  |  | $ | 154.1 |  |
| Services | 90.8 |  |  | 102.1 |  |  | 112.7 |  |  | 129.8 |  |
| Total revenue | 192.3 |  |  | 217.7 |  |  | 234.2 |  |  | 283.9 |  |
| Cost of revenue: |  |  |  |  |  |  |  |
| Product | 29.1 |  |  | 30.7 |  |  | 32.8 |  |  | 38.5 |  |
| Services | 24.3 |  |  | 28.7 |  |  | 31.6 |  |  | 35.8 |  |
| Total cost of revenue | 53.4 |  |  | 59.4 |  |  | 64.4 |  |  | 74.3 |  |
| Total gross profit | 138.9 |  |  | 158.3 |  |  | 169.8 |  |  | 209.6 |  |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | 37.3 |  |  | 47.0 |  |  | 48.4 |  |  | 53.1 |  |
| Sales and marketing | 106.4 |  |  | 122.8 |  |  | 131.1 |  |  | 162.4 |  |
| General and administrative | 19.0 |  |  | 27.0 |  |  | 27.0 |  |  | 28.6 |  |
| Total operating expenses | 162.7 |  |  | 196.8 |  |  | 206.5 |  |  | 244.1 |  |
| Operating loss | (23.8 | ) |  | (38.5 | ) |  | (36.7 | ) |  | (34.5 | ) |
| Interest expense | (5.5 | ) |  | (5.5 | ) |  | (5.7 | ) |  | (5.6 | ) |
| Other income (expense), net | 0.4 |  |  | 0.3 |  |  | — |  |  | (0.5 | ) |
| Loss before income taxes | (28.9 | ) |  | (43.7 | ) |  | (42.4 | ) |  | (40.6 | ) |
| Provision for (benefit from) income taxes | 1.2 |  |  | (0.7 | ) |  | 3.5 |  |  | 5.4 |  |
| Net loss | $ | (30.1 | ) |  | $ | (43.0 | ) |  | $ | (45.9 | ) |  | $ | (46.0 | ) |
| Net loss per share, basic and diluted | $ | (0.38 | ) |  | $ | (0.53 | ) |  | $ | (0.56 | ) |  | $ | (0.55 | ) |


## us-gaap:RevenueFromExternalCustomersByGeographicAreasTableTextBlock

[0001327567-16-000064:notes:233]
The following table presents revenue by geographic theater (in millions):

[0001327567-16-000064:notes:234]
|  | Year Ended July 31, |
|  | 2016 |  | 2015 |  | 2014 |
| Revenue: |  |  |  |  |  |
| Americas |  |  |  |  |  |
| United States | $ | 901.8 |  |  | $ | 593.8 |  |  | $ | 363.2 |  |
| Other Americas | 71.4 |  |  | 45.6 |  |  | 33.5 |  |
| Total Americas | 973.2 |  |  | 639.4 |  |  | 396.7 |  |
| Europe, the Middle East, and Africa (“EMEA”) | 247.1 |  |  | 178.7 |  |  | 126.9 |  |
| Asia Pacific and Japan (“APAC”) | 158.2 |  |  | 110.0 |  |  | 74.6 |  |
| Total revenue | $ | 1,378.5 |  |  | $ | 928.1 |  |  | $ | 598.2 |  |


## us-gaap:ScheduleOfEntityWideInformationRevenueFromExternalCustomersByProductsAndServicesTextBlock

[0001327567-16-000064:notes:235]
The following table presents revenue for groups of similar products and services (in millions):

[0001327567-16-000064:notes:236]
|  | Year Ended July 31, |
|  | 2016 |  | 2015 |  | 2014 |
| Revenue: |  |  |  |  |  |
| Product | $ | 670.8 |  |  | $ | 492.7 |  |  | $ | 340.1 |  |
| Services |  |  |  |  |  |
| Subscription | 357.0 |  |  | 212.7 |  |  | 123.2 |  |
| Support and maintenance | 350.7 |  |  | 222.7 |  |  | 134.9 |  |
| Total services | 707.7 |  |  | 435.4 |  |  | 258.1 |  |
| Total revenue | $ | 1,378.5 |  |  | $ | 928.1 |  |  | $ | 598.2 |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001327567-16-000064:notes:237]
Segment Information

[0001327567-16-000064:notes:238]
We conduct business globally and are primarily managed on a geographic theater basis. Our chief operating decision maker reviews financial information presented on a consolidated basis accompanied by information about revenue by geographic region for purposes of allocating resources and evaluating financial performance. We have one business activity and there are no segment managers who are held accountable for operations, operating results, and plans for levels, components, or types of products or services below the consolidated unit level. Accordingly, we are considered to be in a single reportable segment and operating unit structure.

[0001327567-16-000064:notes:239]
Substantially all of our assets were attributable to our U.S. operations as of July 31, 2016 and 2015.


## us-gaap:SubsequentEventsTextBlock

[0001327567-16-000064:notes:240]
Subsequent Events

[0001327567-16-000064:notes:241]
Share Repurchase

[0001327567-16-000064:notes:242]
On August 26, 2016, our board of directors authorized a $500.0 million share repurchase which will be funded from available working capital. Repurchases may be made at management’s discretion from time to time on the open market, through privately negotiated transactions, transactions structured through investment banking institutions, block purchase techniques, 10b5-1 trading plans, or a combination of the foregoing. The repurchase authorization will expire on August 31, 2018, and may be suspended or discontinued at any time.

[0001327567-16-000064:notes:243]
Hedging

[0001327567-16-000064:notes:244]
On August 30, 2016, we entered into forward contracts with a notional amount of €66.9 million to hedge the foreign currency exposure related to our euro-denominated expenditures for the fiscal year ending July 31, 2017. These forward contracts have been designated as hedging instruments for hedge accounting purposes.
