# PANW note change history — 0001327567-16-000048 → 0001327567-16-000053


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2016-05-27):
[0001327567-16-000053:note_history:1]
The following table presents details of the aggregate future non-cancelable minimum rental payments under our operating leases as of April 30, 2016 (in millions):
  (was, 2016-02-26, similarity 0.9747):
[0001327567-16-000048:note_history:1]
The following table presents details of the aggregate future non-cancelable minimum rental payments under our operating leases as of January 31, 2016 (in millions):

- changed (2016-05-27):
[0001327567-16-000053:note_history:2]
Our independent contract manufacturer procures components and assembles our products based on our forecasts. These forecasts are based on estimates of demand for our products primarily for the next 12 months, which are in turn based on historical trends and an analysis from our sales and product marketing organizations, adjusted for overall market conditions. In order to reduce manufacturing lead times and plan for adequate supply, we may issue forecasts and orders for components and products that are non-cancelable. As of April 30, 2016, our purchase commitments under such orders were $54.5 million, excluding obligations under contracts that we can cancel without a significant penalty.
  (was, 2016-02-26, similarity 0.9913):
[0001327567-16-000048:note_history:2]
Our independent contract manufacturer procures components and assembles our products based on our forecasts. These forecasts are based on estimates of demand for our products primarily for the next 12 months, which are in turn based on historical trends and an analysis from our sales and product marketing organizations, adjusted for overall market conditions. In order to reduce manufacturing lead times and plan for adequate supply, we may issue forecasts and orders for components and products that are non-cancelable. As of January 31, 2016, our purchase commitments under such orders were $39.0 million, excluding obligations under contracts that we can cancel without a significant penalty.

- added (2016-05-27):
[0001327567-16-000053:note_history:3]
To the extent there is a reasonable possibility that a loss exceeding amounts already recognized may be incurred and the amount of such additional loss would be material, we will either disclose the estimated additional loss or state that such an estimate cannot be made. As of April 30, 2016, we have not recorded any significant accruals for loss contingencies associated with such legal proceedings, determined that an unfavorable outcome is probable or reasonably possible, or determined that the amount or range of any possible loss is reasonably estimable.

- removed (2016-05-27):
[0001327567-16-000048:note_history:4]
To the extent there is a reasonable possibility that a loss exceeding amounts already recognized may be incurred and the amount of such additional loss would be material, we will either disclose the estimated additional loss or state that such an estimate cannot be made. As of January 31, 2016, we have not recorded any significant accruals for loss contingencies associated with such legal proceedings, determined that an unfavorable outcome is probable or reasonably possible, or determined that the amount or range of any possible loss is reasonably estimable.


## us-gaap:BusinessDescriptionAndAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- added (2016-05-27):
[0001327567-16-000053:note_history:5]
Basis of Presentation and Principles of Consolidation

- changed (2016-05-27):
[0001327567-16-000053:note_history:6]
There have been no material changes to our significant accounting policies as of and for the nine months ended April 30, 2016, as compared to the significant accounting policies described in our Annual Report on Form 10-K for the fiscal year ended July 31, 2015.
  (was, 2016-02-26, similarity 0.9058):
[0001327567-16-000048:note_history:6]
There have been no material changes to our significant accounting policies as of and for the six months ended January 31, 2016, as compared to the significant accounting policies described in our Annual Report on Form 10-K for the fiscal year ended July 31, 2015.

- added (2016-05-27):
[0001327567-16-000053:note_history:7]
In March 2016, the Financial Accounting Standards Board (“FASB”) issued authoritative guidance simplifying several aspects of the accounting for employee share-based payment transactions, including the income tax consequences, accounting for forfeitures, and classification of excess tax benefits on the statement of cash flows. The standard is effective for us for our first quarter of fiscal 2018, however, early adoption is permitted. We are currently evaluating whether this standard will have a material impact on our condensed consolidated financial statements.

- added (2016-05-27):
[0001327567-16-000053:note_history:8]
In February 2016, the FASB issued new authoritative guidance on lease accounting. Among its provisions, the standard requires lessees to recognize right-of-use assets and lease liabilities on the balance sheet for operating leases and also requires additional qualitative and quantitative disclosures about lease arrangements. The standard is effective for us for our first quarter of fiscal 2020 and will be applied on a modified retrospective basis, with the option to elect certain practical expedients. Early adoption is permitted. We are currently evaluating whether this standard will have a material impact on our condensed consolidated financial statements.

- changed (2016-05-27):
[0001327567-16-000053:note_history:9]
In April 2015, the FASB issued new authoritative guidance on fees paid in a cloud computing arrangement. The standard requires customers in a cloud computing arrangement to evaluate whether the arrangement includes a software license. If the arrangement includes a software license, the customer should account for the software license element of the arrangement consistent with the acquisition of other software licenses. If the arrangement does not include a software license, the customer should account for the arrangement as a service contract. The standard is effective for us for our first quarter of fiscal 2017 and will be applied on a prospective basis. We do not expect the adoption of the standard will have a material impact on our condensed consolidated financial statements.
  (was, 2016-02-26, similarity 0.8827):
[0001327567-16-000048:note_history:9]
In April 2015, the Financial Accounting Standards Board (“FASB”) issued new authoritative guidance on fees paid in a cloud computing arrangement. The standard requires customers in a cloud computing arrangement to evaluate whether the arrangement includes a software license. If the arrangement includes a software license, the customer should account for the software license element of the arrangement consistent with the acquisition of other software licenses. If the arrangement does not include a software license, the customer should account for the arrangement as a service contract. The standard is effective for us for our first quarter of fiscal 2017 and will be applied on either a prospective or retrospective basis. We are currently evaluating adoption methods and whether this standard will have a material impact on our condensed consolidated financial statements.

- removed (2016-05-27):
[0001327567-16-000048:note_history:10]
Basis of Presentation


## us-gaap:ConvertibleDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2016-05-27):
[0001327567-16-000053:note_history:11]
The following table sets forth the components of the Notes as of April 30, 2016 and July 31, 2015 (in millions):
  (was, 2016-02-26, similarity 0.9612):
[0001327567-16-000048:note_history:11]
The following table sets forth the components of the Notes as of January 31, 2016 and July 31, 2015 (in millions):

- changed (2016-05-27):
[0001327567-16-000053:note_history:12]
|  | April 30, 2016 |  | July 31, 2015 |
| Liability: |  |  |  |
| Principal | $ | 575.0 |  |  | $ | 575.0 |  |
| Less: debt discount, net of amortization | 72.2 |  |  | 87.9 |  |
| Net carrying amount | $ | 502.8 |  |  | $ | 487.1 |  |
| Equity (including temporary equity) | $ | (109.8 | ) |  | $ | (109.8 | ) |
  (was, 2016-02-26, similarity 0.9768):
[0001327567-16-000048:note_history:12]
|  | January 31, 2016 |  | July 31, 2015 |
| Liability: |  |  |  |
| Principal | $ | 575.0 |  |  | $ | 575.0 |  |
| Less: debt discount, net of amortization | 77.5 |  |  | 87.9 |  |
| Net carrying amount | $ | 497.5 |  |  | $ | 487.1 |  |
| Equity (including temporary equity) | $ | (109.8 | ) |  | $ | (109.8 | ) |


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2016-05-27):
[0001327567-16-000053:note_history:13]
| • | during the five business day period after any five consecutive trading day period, in which the trading price per $1,000 principal amount of Notes for each trading day of the measurement period was less than 98% of the product of the last reported sale price of our common stock and the conversion rate for the Notes on each such trading day; or |
  (was, 2016-02-26, similarity 0.956):
[0001327567-16-000048:note_history:13]
| • | during the five business day period after any five consecutive trading day period, in which the trading price per $1,000 principal amount of Notes for each trading day of the measurement period was less than 98% of the product of the last reported sale price of our common stock and the conversion rate for the Notes on each such trading day (the “trading price condition”); or |

- added (2016-05-27):
[0001327567-16-000053:note_history:14]
The sale price condition was initially met during the fiscal quarter ended April 30, 2015. The sale price condition continued to be met through the fiscal quarter ended April 30, 2016, and as a result, holders may convert their Notes at any time during the fiscal quarter ending July 31, 2016. Accordingly, the net carrying amount of the Notes was classified in current liabilities and a portion of the equity component representing the conversion option was classified as temporary equity in our condensed consolidated balance sheets as of April 30, 2016. The portion of the equity component classified as temporary equity is measured as the difference between the principal and net carrying amount of the Notes.

- changed (2016-05-27):
[0001327567-16-000053:note_history:15]
The following table sets forth the components of the Notes as of April 30, 2016 and July 31, 2015 (in millions):
  (was, 2016-02-26, similarity 0.9612):
[0001327567-16-000048:note_history:15]
The following table sets forth the components of the Notes as of January 31, 2016 and July 31, 2015 (in millions):

- changed (2016-05-27):
[0001327567-16-000053:note_history:16]
|  | April 30, 2016 |  | July 31, 2015 |
| Liability: |  |  |  |
| Principal | $ | 575.0 |  |  | $ | 575.0 |  |
| Less: debt discount, net of amortization | 72.2 |  |  | 87.9 |  |
| Net carrying amount | $ | 502.8 |  |  | $ | 487.1 |  |
| Equity (including temporary equity) | $ | (109.8 | ) |  | $ | (109.8 | ) |
  (was, 2016-02-26, similarity 0.9768):
[0001327567-16-000048:note_history:16]
|  | January 31, 2016 |  | July 31, 2015 |
| Liability: |  |  |  |
| Principal | $ | 575.0 |  |  | $ | 575.0 |  |
| Less: debt discount, net of amortization | 77.5 |  |  | 87.9 |  |
| Net carrying amount | $ | 497.5 |  |  | $ | 487.1 |  |
| Equity (including temporary equity) | $ | (109.8 | ) |  | $ | (109.8 | ) |

- changed (2016-05-27):
[0001327567-16-000053:note_history:17]
The total estimated fair value of the Notes was $844.4 million and $994.8 million at April 30, 2016 and July 31, 2015, respectively. The fair value was determined based on the closing trading price per $100 of the Notes as of the last day of trading for the period. We consider the fair value of the Notes at April 30, 2016 and July 31, 2015 to be a Level 2 measurement. The fair value of the Notes is primarily affected by the trading price of our common stock and market interest rates. As of April 30, 2016, the if-converted value of the Notes exceeded its principal amount by $210.9 million.
  (was, 2016-02-26, similarity 0.9354):
[0001327567-16-000048:note_history:17]
The total estimated fair value of the Notes was $840.2 million and $994.8 million at January 31, 2016 and July 31, 2015, respectively. The fair value was determined based on the closing trading price per $100 of the Notes as of the last day of trading for the period. We consider the fair value of the Notes at January 31, 2016 and July 31, 2015 to be a Level 2 measurement. The fair value of the Notes is primarily affected by the trading price of our common stock and market interest rates. As of January 31, 2016, the if-converted value of the Notes exceeded its principal amount by $278.7 million.

- changed (2016-05-27):
[0001327567-16-000053:note_history:18]
|  | Three Months Ended April 30, |  | Nine Months Ended April 30, |
|  | 2016 |  | 2015 |  | 2016 |  | 2015 |
| Amortization of debt discount | $ | 5.3 |  |  | $ | 5.1 |  |  | $ | 15.7 |  |  | $ | 15.1 |  |
| Amortization of debt issuance costs | 0.6 |  |  | 0.5 |  |  | 1.7 |  |  | 1.5 |  |
| Total interest expense recognized | $ | 5.9 |  |  | $ | 5.6 |  |  | $ | 17.4 |  |  | $ | 16.6 |  |
| Effective interest rate of the liability component | 4.8 | % |  | 4.8 | % |  | 4.8 | % |  | 4.8 | % |
  (was, 2016-02-26, similarity 0.946):
[0001327567-16-000048:note_history:18]
|  | Three Months Ended January 31, |  | Six Months Ended January 31, |
|  | 2016 |  | 2015 |  | 2016 |  | 2015 |
| Amortization of debt discount | $ | 5.2 |  |  | $ | 5.0 |  |  | $ | 10.4 |  |  | $ | 10.0 |  |
| Amortization of debt issuance costs | 0.6 |  |  | 0.5 |  |  | 1.1 |  |  | 1.0 |  |
| Total interest expense recognized | $ | 5.8 |  |  | $ | 5.5 |  |  | $ | 11.5 |  |  | $ | 11.0 |  |
| Effective interest rate of the liability component | 4.8 | % |  | 4.8 | % |  | 4.8 | % |  | 4.8 | % |

- removed (2016-05-27):
[0001327567-16-000048:note_history:19]
The sale price condition was initially met during the fiscal quarter ended April 30, 2015. The sale price condition continued to be met through the fiscal quarter ended January 31, 2016, and as a result, holders may convert their Notes at any time during the fiscal quarter ending April 30, 2016. Accordingly, the net carrying amount of the Notes was classified in current liabilities and a portion of the equity component representing the conversion option was classified as temporary equity in our condensed consolidated balance sheets as of January 31, 2016. The portion of the equity component classified as temporary equity is measured as the difference between the principal and net carrying amount of the Notes.


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2016-05-27):
[0001327567-16-000053:note_history:20]
The following tables summarize the amortized cost, unrealized gains and losses, and fair value of our available-for-sale investments as of April 30, 2016 and July 31, 2015 (in millions):
  (was, 2016-02-26, similarity 0.9258):
[0001327567-16-000048:note_history:20]
The following tables summarize the unrealized gains and losses and fair value of our available-for-sale investments as of January 31, 2016 and July 31, 2015 (in millions):

- added (2016-05-27):
[0001327567-16-000053:note_history:21]
|  | April 30, 2016 |
|  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Estimated Fair Value |
| Certificates of deposit | $ | 5.4 |  |  | $ | — |  |  | $ | — |  |  | $ | 5.4 |  |
| Corporate debt securities | 299.8 |  |  | 0.5 |  |  | — |  |  | 300.3 |  |
| U.S. government and agency securities | 914.4 |  |  | 0.5 |  |  | (0.2 | ) |  | 914.7 |  |
| Total | $ | 1,219.6 |  |  | $ | 1.0 |  |  | $ | (0.2 | ) |  | $ | 1,220.4 |  |

- changed (2016-05-27):
[0001327567-16-000053:note_history:22]
Unrealized losses related to these investments are due to interest rate fluctuations as opposed to credit quality. In addition, we do not intend to sell and it is not likely that we would be required to sell these investments before recovery of their amortized cost basis, which may be at maturity. As a result, there were no other-than-temporary impairments for these investments at April 30, 2016 and July 31, 2015.
  (was, 2016-02-26, similarity 0.9853):
[0001327567-16-000048:note_history:22]
Unrealized losses related to these investments are due to interest rate fluctuations as opposed to credit quality. In addition, we do not intend to sell and it is not likely that we would be required to sell these investments before recovery of their amortized cost basis, which may be at maturity. As a result, there were no other-than-temporary impairments for these investments at January 31, 2016 and July 31, 2015.

- changed (2016-05-27):
[0001327567-16-000053:note_history:23]
The following table summarizes the amortized cost and fair value of our available-for-sale investments as of April 30, 2016, by contractual years-to-maturity (in millions):
  (was, 2016-02-26, similarity 0.976):
[0001327567-16-000048:note_history:23]
The following table summarizes the amortized cost and fair value of our available-for-sale investments as of January 31, 2016, by contractual years-to-maturity (in millions):

- removed (2016-05-27):
[0001327567-16-000048:note_history:24]
|  | January 31, 2016 |
|  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Estimated Fair Value |
| Certificates of deposit | $ | 5.4 |  |  | $ | — |  |  | $ | — |  |  | $ | 5.4 |  |
| Corporate debt securities | 294.9 |  |  | 0.1 |  |  | (0.5 | ) |  | 294.5 |  |
| U.S. government and agency securities | 882.9 |  |  | 0.2 |  |  | (0.5 | ) |  | 882.6 |  |
| Total | $ | 1,183.2 |  |  | $ | 0.3 |  |  | $ | (1.0 | ) |  | $ | 1,182.5 |  |
