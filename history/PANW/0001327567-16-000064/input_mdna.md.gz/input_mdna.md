# PANW MD&A — 0001327567-16-000064


## mdna

[0001327567-16-000064:mdna:1]
| ITEM 7. | MANAGEMENT’S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS |

[0001327567-16-000064:mdna:2]
The following discussion and analysis of our financial condition and results of operations should be read in conjunction with our consolidated financial statements and related notes appearing elsewhere in this Annual Report on Form 10-K. The following discussion and analysis contains forward-looking statements based on current expectations and assumptions that are subject to risks and uncertainties, which could cause our actual results to differ materially from those anticipated or implied by any forward-looking statements. Factors that could cause or contribute to such differences include, but are not limited to, those discussed in this Annual Report on Form 10-K, and in particular, the risks discussed under the caption “Risk Factors” in Part I, Item 1A of this report.

[0001327567-16-000064:mdna:3]
Our Management’s Discussion and Analysis of Financial Condition and Results of Operations (“MD&A”) is organized as follows:

[0001327567-16-000064:mdna:4]
| • | Overview. A discussion of our business and overall analysis of financial and other highlights in order to provide context for the remainder of MD&A. |

[0001327567-16-000064:mdna:5]
| • | Key Financial Metrics. A summary of our GAAP and non-GAAP key financial metrics, which management monitors to evaluate our performance. |

[0001327567-16-000064:mdna:6]
| • | Results of Operations. A discussion of the nature and trends in our financial results and an analysis of our financial results comparing fiscal 2016 to 2015 and fiscal 2015 to 2014. |

[0001327567-16-000064:mdna:7]
| • | Liquidity and Capital Resources. An analysis of changes in our balance sheets and cash flows, and a discussion of our financial condition and our ability to meet cash needs. |

[0001327567-16-000064:mdna:8]
| • | Contractual Obligations and Commitments. An overview of our contractual obligations, contingent liabilities, commitments, and off-balance sheet arrangements outstanding as of July 31, 2016, including expected payment schedules. |

[0001327567-16-000064:mdna:9]
- 36 -

[0001327567-16-000064:mdna:10]
| • | Critical Accounting Estimates. A discussion of our accounting policies that require critical estimates, assumptions, and judgments. |

[0001327567-16-000064:mdna:11]
| • | Recent Accounting Pronouncements. A discussion of expected impacts of impending accounting changes on financial information to be reported in the future. |

[0001327567-16-000064:mdna:12]
Overview

[0001327567-16-000064:mdna:13]
We have pioneered the next generation of security through our innovative platform that allows enterprises, service providers, and government entities to secure their organizations by safely enabling applications running on their networks and by preventing breaches that stem from targeted cyber attacks. Our platform uses an innovative traffic classification engine that identifies network traffic by application, user, and content and provides consistent security across the network, endpoint, and cloud. Accordingly, our platform enables our end-customers to maintain the visibility and control needed to protect their valued data and critical control systems while pursuing technology initiatives, like cloud and mobility, that grow their business. We believe our platform offers superior performance compared to legacy approaches and reduces the total cost of ownership for organizations by simplifying their security infrastructure and eliminating the need for multiple, stand-alone security appliances and software products.

[0001327567-16-000064:mdna:14]
Our Next-Generation Security Platform consists of three major elements: our Next-Generation Firewall, our Advanced Endpoint Protection, and our Threat Intelligence Cloud. Our Next-Generation Firewall delivers application, user, and content visibility and control as well as protection against network-based cyber threats integrated within the firewall through our proprietary hardware and software architecture. Our Advanced Endpoint Protection prevents cyber attacks that aim to run malicious code or exploit software vulnerabilities on a broad variety of fixed and virtual endpoints and servers. Our Threat Intelligence Cloud provides central intelligence capabilities, security for SaaS applications, and automated delivery of preventative measures against cyber attacks.

[0001327567-16-000064:mdna:15]
For fiscal 2016, 2015, and 2014, total revenue was $1.4 billion, $928.1 million, and $598.2 million, respectively, representing year-over-year growth of 48.5% for fiscal 2016 and 55.1% for fiscal 2015. Our growth reflects the increased adoption of our hybrid SaaS revenue model, which consists of product, subscriptions, and support and maintenance. We believe this model will enable us to benefit from recurring revenues as we continue to grow our installed end-customer base. As of July 31, 2016, we had approximately 34,000 end-customers in over 140 countries. Our end-customers represent a broad range of industries including education, energy, financial services, government entities, healthcare, Internet and media, manufacturing, public sector, and telecommunications, and include some of the largest Fortune 100 and Global 2000 companies in the world.

[0001327567-16-000064:mdna:16]
Our product revenue grew to $670.8 million or 48.7% of total revenue for fiscal 2016, representing year-over-year growth of 36.2%. Product revenue is generated from sales of our appliances, primarily our Next-Generation Firewall, which is available in physical and virtualized form. Our Next-Generation Firewall incorporates our proprietary PAN-OS operating system, which provides a consistent set of capabilities across our entire product line. Our products are designed for different performance requirements throughout an organization, ranging from our PA-200, which is designed for enterprise remote offices, to our top-of-the-line PA-7080, which was released in August 2015 and is especially suited for very large enterprise deployments and service provider customers. The same firewall functionality that is delivered in our physical appliances is also available in our VM-Series virtual firewalls, which secure virtualized and cloud-based computing environments.

[0001327567-16-000064:mdna:17]
Our recurring services revenue grew to $707.7 million or 51.3% of total revenue for fiscal 2016, representing year-over-year growth of 62.5%, led by revenue from subscription services, which grew 67.8% to $357.0 million, and followed by support and maintenance services, which grew 57.5% to $350.7 million. Our subscriptions include two new services released during the first quarter of fiscal 2016: our Aperture subscription service, which provides added visibility and control within IT-sanctioned SaaS applications that are used to store and share end-customer’s data, and our AutoFocus cyber threat intelligence service, which provides prioritized actionable intelligence on targeted cyber attacks. Our subscriptions provide our end-customers with real-time access to the latest antivirus, intrusion prevention, web filtering, and modern malware prevention capabilities across fixed and mobile devices.

[0001327567-16-000064:mdna:18]
We maintain a field sales force that works closely with our channel partners in developing sales opportunities. We use a two-tier, indirect fulfillment model whereby we sell our products and services to our distributors, which, in turn, to our resellers, which then sell to our end-customers. When end-customers purchase an appliance, they typically purchase one or more of our subscriptions for additional functionality, as well as support and maintenance in order to receive ongoing security updates, upgrades, bug fixes, and repairs.

[0001327567-16-000064:mdna:19]
We believe that the growth of our business and our short-term and long-term success are dependent upon many factors, including our ability to extend our technology leadership, grow our base of end-customers, expand deployment of our platform and services within existing end-customers, and focus on end-customer satisfaction. To manage any future growth effectively, we must continue to improve and expand our information technology and financial infrastructure, our operating and administrative systems and controls, and our ability to manage headcount, capital, and processes in an efficient manner. While these areas present

[0001327567-16-000064:mdna:20]
- 37 -

[0001327567-16-000064:mdna:21]
significant opportunities for us, they also pose challenges and risks that we must successfully address in order to sustain the growth of our business and improve our operating results. For additional information regarding the challenges and risks we face, see the “Risk Factors” section in Part I, Item 1A of this Annual Report on Form 10-K.

[0001327567-16-000064:mdna:22]
Key Financial Metrics

[0001327567-16-000064:mdna:23]
We monitor the key financial metrics set forth in the tables below to help us evaluate growth trends, establish budgets, measure the effectiveness of our sales and marketing efforts, and assess operational efficiencies. We discuss revenue, gross margin, and the components of operating loss and margin below under “—Results of Operations.”

[0001327567-16-000064:mdna:24]
|  | July 31, |
|  | 2016 |  | 2015 |
|  | (in millions) |
| Total deferred revenue | $ | 1,240.8 |  |  | $ | 713.7 |  |
| Cash, cash equivalents, and investments | $ | 1,938.4 |  |  | $ | 1,327.8 |  |

[0001327567-16-000064:mdna:25]
|  | Year Ended July 31, |
|  | 2016 |  | 2015 |  | 2014 |
|  | (dollars in millions) |
| Total revenue | $ | 1,378.5 |  |  | $ | 928.1 |  |  | $ | 598.2 |  |
| Total revenue year-over-year percentage increase | 48.5 | % |  | 55.1 | % |  | 51.0 | % |
| Gross margin percentage | 73.2 | % |  | 72.9 | % |  | 73.3 | % |
| Operating loss | $ | (190.1 | ) |  | $ | (133.5 | ) |  | $ | (215.3 | ) |
| Operating margin percentage | (13.8 | )% |  | (14.4 | )% |  | (36.0 | )% |
| Billings | $ | 1,905.6 |  |  | $ | 1,219.1 |  |  | $ | 771.4 |  |
| Billings year-over-year percentage increase | 56.3 | % |  | 58.0 | % |  | 51.4 | % |
| Cash flow provided by operating activities | $ | 658.1 |  |  | $ | 350.3 |  |  | $ | 88.4 |  |
| Free cash flow (non-GAAP) | $ | 585.6 |  |  | $ | 316.5 |  |  | $ | 52.3 |  |

[0001327567-16-000064:mdna:26]
| • | Deferred Revenue. Our deferred revenue consists of amounts that have been invoiced but have not been recognized as revenue as of the period end. The majority of our deferred revenue balance consists of subscription and support and maintenance revenue that is recognized ratably over the contractual service period. We monitor our deferred revenue balance because it represents a significant portion of revenue to be recognized in future periods. |

[0001327567-16-000064:mdna:27]
| • | Billings. We define billings as total revenue plus the change in total deferred revenue during the period. We consider billings to be a key measure used by management to manage our business given our hybrid SaaS revenue model, and believe billings provides investors with an important indicator of the health and visibility of our business because it includes services revenue, which is recognized ratably over the subscription period or the period in which the services are expected to be performed, as the case may be, and product revenue, which is recognized at the time of shipment, provided that all other revenue recognition criteria have been met. We consider billings to be a useful metric for management and investors, particularly if we continue to experience increased sales of subscriptions and strong renewal rates for subscriptions and support and maintenance services, and as we monitor our near term cash flows. While we believe that billings provides useful information to investors and others in understanding and evaluating our operating results in the same manner as our management, it is important to note that other companies, including companies in our industry, may not use billings, may calculate billings differently, may have different billing frequencies, or may use other financial measures to evaluate their performance, all of which could reduce the usefulness of billings as a comparative measure. We calculate billings in the following manner: |

[0001327567-16-000064:mdna:28]
- 38 -

[0001327567-16-000064:mdna:29]
|  | Year Ended July 31, |
|  | 2016 |  | 2015 |  | 2014 |
|  | (in millions) |
| Billings: |  |  |  |  |  |
| Total revenue | $ | 1,378.5 |  |  | $ | 928.1 |  |  | $ | 598.2 |  |
| Add: change in total deferred revenue, net of acquired deferred revenue | 527.1 |  |  | 291.0 |  |  | 173.2 |  |
| Billings | $ | 1,905.6 |  |  | $ | 1,219.1 |  |  | $ | 771.4 |  |

[0001327567-16-000064:mdna:30]
| • | Cash Flow Provided by Operating Activities. We monitor cash flow provided by operating activities as a measure of our overall business performance. Our cash flow provided by operating activities is driven in large part by sales of our products and from up-front payments for both subscriptions and support and maintenance services. Monitoring cash flow provided by operating activities enables us to analyze our financial performance without the non-cash effects of certain items such as depreciation, amortization, and share-based compensation costs, thereby allowing us to better understand and manage the cash needs of our business. |

[0001327567-16-000064:mdna:31]
| • | Free Cash Flow (non-GAAP). We define free cash flow, a non-GAAP financial measure, as cash provided by operating activities less purchases of property, equipment, and other assets. We consider free cash flow to be a profitability and liquidity measure that provides useful information to management and investors about the amount of cash generated by the business after necessary capital expenditures. A limitation of the utility of free cash flow as a measure of our financial performance and liquidity is that it does not represent the total increase or decrease in our cash balance for the period. In addition, it is important to note that other companies, including companies in our industry, may not use free cash flow, may calculate free cash flow in a different manner than we do, or may use other financial measures to evaluate their performance, all of which could reduce the usefulness of free cash flow as a comparative measure. A reconciliation of free cash flow to cash flow provided by operating activities, the most directly comparable financial measure calculated and presented in accordance with GAAP, is provided below: |

[0001327567-16-000064:mdna:32]
|  | Year Ended July 31, |
|  | 2016 |  | 2015 |  | 2014 |
|  | (in millions) |
| Free cash flow (non-GAAP): |  |  |  |  |  |
| Net cash provided by operating activities | $ | 658.1 |  |  | $ | 350.3 |  |  | $ | 88.4 |  |
| Less: purchases of property, equipment, and other assets | 72.5 |  |  | 33.8 |  |  | 36.1 |  |
| Free cash flow (non-GAAP) (1) | $ | 585.6 |  |  | $ | 316.5 |  |  | $ | 52.3 |  |
| Net cash used in investing activities | $ | (338.9 | ) |  | $ | (679.0 | ) |  | $ | (320.3 | ) |
| Net cash provided by financing activities | $ | 39.4 |  |  | $ | 50.7 |  |  | $ | 575.1 |  |

[0001327567-16-000064:mdna:33]
______________

[0001327567-16-000064:mdna:34]
| (1) | Includes our cash payments of $75.0 million and $20.0 million in fiscal 2014 for the legal settlement with Juniper and the Mutual Covenant Not to Sue and Release Agreement with Fortinet, respectively. |

[0001327567-16-000064:mdna:35]
- 39 -

[0001327567-16-000064:mdna:36]
Results of Operations

[0001327567-16-000064:mdna:37]
The following table summarizes our results of operations for the periods presented and as a percentage of our total revenue for those periods based on our consolidated statements of operations data. The period to period comparison of results is not necessarily indicative of results for future periods.

[0001327567-16-000064:mdna:38]
|  | Year Ended July 31, |
|  | 2016 |  | 2015 |  | 2014 |
|  | Amount |  | % of Revenue |  | Amount |  | % of Revenue |  | Amount |  | % of Revenue |
|  | (dollars in millions) |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Product | $ | 670.8 |  |  | 48.7 | % |  | $ | 492.7 |  |  | 53.1 | % |  | $ | 340.1 |  |  | 56.9 | % |
| Services | 707.7 |  |  | 51.3 | % |  | 435.4 |  |  | 46.9 | % |  | 258.1 |  |  | 43.1 | % |
| Total revenue | 1,378.5 |  |  | 100.0 | % |  | 928.1 |  |  | 100.0 | % |  | 598.2 |  |  | 100.0 | % |
| Cost of revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Product | 175.4 |  |  | 12.7 | % |  | 131.1 |  |  | 14.1 | % |  | 85.5 |  |  | 14.3 | % |
| Services | 194.6 |  |  | 14.1 | % |  | 120.4 |  |  | 13.0 | % |  | 74.1 |  |  | 12.4 | % |
| Total cost of revenue (1) | 370.0 |  |  | 26.8 | % |  | 251.5 |  |  | 27.1 | % |  | 159.6 |  |  | 26.7 | % |
| Total gross profit | 1,008.5 |  |  | 73.2 | % |  | 676.6 |  |  | 72.9 | % |  | 438.6 |  |  | 73.3 | % |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |
| Research and development | 284.2 |  |  | 20.6 | % |  | 185.8 |  |  | 20.0 | % |  | 104.8 |  |  | 17.5 | % |
| Sales and marketing | 776.0 |  |  | 56.3 | % |  | 522.7 |  |  | 56.3 | % |  | 334.8 |  |  | 56.0 | % |
| General and administrative | 138.4 |  |  | 10.1 | % |  | 101.6 |  |  | 11.0 | % |  | 73.1 |  |  | 12.2 | % |
| Legal settlement | — |  |  | — | % |  | — |  |  | — | % |  | 141.2 |  |  | 23.6 | % |
| Total operating expenses (1) | 1,198.6 |  |  | 87.0 | % |  | 810.1 |  |  | 87.3 | % |  | 653.9 |  |  | 109.3 | % |
| Operating loss | (190.1 | ) |  | (13.8 | )% |  | (133.5 | ) |  | (14.4 | )% |  | (215.3 | ) |  | (36.0 | )% |
| Interest expense | (23.4 | ) |  | (1.7 | )% |  | (22.3 | ) |  | (2.4 | )% |  | (1.9 | ) |  | (0.3 | )% |
| Other income (expense), net | 8.4 |  |  | 0.6 | % |  | 0.2 |  |  | — | % |  | (5.0 | ) |  | (0.8 | )% |
| Loss before income taxes | (205.1 | ) |  | (14.9 | )% |  | (155.6 | ) |  | (16.8 | )% |  | (222.2 | ) |  | (37.1 | )% |
| Provision for income taxes | 20.8 |  |  | 1.5 | % |  | 9.4 |  |  | 1.0 | % |  | 4.3 |  |  | 0.8 | % |
| Net loss | $ | (225.9 | ) |  | (16.4 | )% |  | $ | (165.0 | ) |  | (17.8 | )% |  | $ | (226.5 | ) |  | (37.9 | )% |

[0001327567-16-000064:mdna:39]
(1)Includes share-based compensation as follows:

[0001327567-16-000064:mdna:40]
- 40 -

[0001327567-16-000064:mdna:41]
|  | Year Ended July 31, |
|  | 2016 |  | 2015 |  | 2014 |
|  | (in millions) |
| Cost of product revenue | $ | 6.2 |  |  | $ | 3.9 |  |  | $ | 1.6 |  |
| Cost of services revenue | 40.9 |  |  | 20.4 |  |  | 9.4 |  |
| Research and development | 132.9 |  |  | 74.8 |  |  | 29.5 |  |
| Sales and marketing | 152.4 |  |  | 84.1 |  |  | 42.6 |  |
| General and administrative | 60.5 |  |  | 38.2 |  |  | 16.8 |  |
| Total share-based compensation | $ | 392.9 |  |  | $ | 221.4 |  |  | $ | 99.9 |  |

[0001327567-16-000064:mdna:42]
Revenue

[0001327567-16-000064:mdna:43]
We derive revenue from sales of our products and services. Revenue is recognized when persuasive evidence of an arrangement exists, delivery has occurred, the fee is fixed or determinable, and collectability is reasonably assured. We expect our revenue to vary from quarter to quarter based on seasonal and cyclical factors.

[0001327567-16-000064:mdna:44]
Our total revenue is comprised of the following:

[0001327567-16-000064:mdna:45]
| • | Product Revenue. Product revenue is derived primarily from sales of our appliances. Product revenue also includes revenue derived from software licenses of Panorama and, to a lesser extent, the VM-Series. We recognize product revenue at the time of shipment, provided that all other revenue recognition criteria have been met. |

[0001327567-16-000064:mdna:46]
| • | Services Revenue. Services revenue is derived primarily from sales of our subscriptions and support and maintenance. Our contractual subscription and support and maintenance terms are typically one to five years. We recognize revenue from subscriptions and support and maintenance over the contractual service period. As a percentage of total revenue, we expect our services revenue to vary from quarter to quarter and increase over the long term as we introduce new subscriptions, such as Aperture and AutoFocus, renew existing services contracts, and expand our installed end-customer base. |

[0001327567-16-000064:mdna:47]
|  | Year Ended July 31, |  |  |  | Year Ended July 31, |  |  |
|  | 2016 |  | 2015 |  | Change |  | 2015 |  | 2014 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product | $ | 670.8 |  |  | $ | 492.7 |  |  | $ | 178.1 |  |  | 36.2 | % |  | $ | 492.7 |  |  | $ | 340.1 |  |  | $ | 152.6 |  |  | 44.8 | % |
| Services |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Subscription | 357.0 |  |  | 212.7 |  |  | 144.3 |  |  | 67.8 | % |  | 212.7 |  |  | 123.2 |  |  | 89.5 |  |  | 72.6 | % |
| Support and maintenance | 350.7 |  |  | 222.7 |  |  | 128.0 |  |  | 57.5 | % |  | 222.7 |  |  | 134.9 |  |  | 87.8 |  |  | 65.2 | % |
| Total services | 707.7 |  |  | 435.4 |  |  | 272.3 |  |  | 62.5 | % |  | 435.4 |  |  | 258.1 |  |  | 177.3 |  |  | 68.7 | % |
| Total revenue | $ | 1,378.5 |  |  | $ | 928.1 |  |  | $ | 450.4 |  |  | 48.5 | % |  | $ | 928.1 |  |  | $ | 598.2 |  |  | $ | 329.9 |  |  | 55.1 | % |
| Revenue by geographic theater: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas | $ | 973.2 |  |  | $ | 639.4 |  |  | $ | 333.8 |  |  | 52.2 | % |  | $ | 639.4 |  |  | $ | 396.7 |  |  | $ | 242.7 |  |  | 61.2 | % |
| EMEA | 247.1 |  |  | 178.7 |  |  | 68.4 |  |  | 38.2 | % |  | 178.7 |  |  | 126.9 |  |  | 51.8 |  |  | 40.8 | % |
| APAC | 158.2 |  |  | 110.0 |  |  | 48.2 |  |  | 43.8 | % |  | 110.0 |  |  | 74.6 |  |  | 35.4 |  |  | 47.4 | % |
| Total revenue | $ | 1,378.5 |  |  | $ | 928.1 |  |  | $ | 450.4 |  |  | 48.5 | % |  | $ | 928.1 |  |  | $ | 598.2 |  |  | $ | 329.9 |  |  | 55.1 | % |

[0001327567-16-000064:mdna:48]
Product revenue increased year-over-year for both fiscal 2016 and fiscal 2015. The increases in both periods were driven by increased demand for our higher end appliances. The change in product revenue due to pricing was not significant for either period.

[0001327567-16-000064:mdna:49]
Services revenue increased year-over-year for both fiscal 2016 and fiscal 2015. The increases in both periods were due to the adoption of subscriptions and high renewal rates for both subscriptions and support and maintenance services. The mix between subscription revenue and support and maintenance revenue will fluctuate over time, depending on the introduction of new

[0001327567-16-000064:mdna:50]
- 41 -

[0001327567-16-000064:mdna:51]
subscription offerings, renewals of support and maintenance services, and our ability to increase sales to new and existing customers. The change in services revenue due to pricing was not significant for either period.

[0001327567-16-000064:mdna:52]
With respect to geographic theaters, the Americas contributed the largest portion of the year-over-year increases in revenue for both fiscal 2016 and fiscal 2015 due to its larger and more established sales force compared to our other theaters. Revenue from both EMEA and APAC increased year-over-year for both fiscal 2016 and fiscal 2015 due to our investment in increasing the size of our sales force and number of channel partners in these theaters.

[0001327567-16-000064:mdna:53]
Cost of Revenue

[0001327567-16-000064:mdna:54]
Our cost of revenue consists of cost of product revenue and cost of services revenue.

[0001327567-16-000064:mdna:55]
Cost of Product Revenue

[0001327567-16-000064:mdna:56]
Cost of product revenue primarily includes costs paid to our third-party contract manufacturer. Our cost of product revenue also includes amortization of intellectual property licenses, product testing costs, shipping costs, personnel costs, which consist of salaries, benefits, bonuses, and share-based compensation associated with our operations organization, and allocated costs. Allocated costs consist of certain facilities, depreciation, benefits, recruiting, and information technology costs that we allocate based on headcount. We expect our cost of product revenue to increase as our product revenue increases.

[0001327567-16-000064:mdna:57]
|  | Year Ended July 31, |  |  |  | Year Ended July 31, |  |  |
|  | 2016 |  | 2015 |  | Change |  | 2015 |  | 2014 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| Cost of product revenue | $ | 175.4 |  |  | $ | 131.1 |  |  | $ | 44.3 |  |  | 33.8 | % |  | $ | 131.1 |  |  | $ | 85.5 |  |  | $ | 45.6 |  |  | 53.3 | % |
| Number of employees at period end | 91 |  |  | 67 |  |  | 24 |  |  | 35.8 | % |  | 67 |  |  | 50 |  |  | 17 |  |  | 34.0 | % |

[0001327567-16-000064:mdna:58]
Cost of product revenue increased for fiscal 2016 compared to fiscal 2015 due to an increase in product unit volume for our higher end appliances.

[0001327567-16-000064:mdna:59]
Cost of product revenue increased for fiscal 2015 compared to fiscal 2014 due to an increase in product unit volume, as well as amortization of intellectual property licenses of $10.2 million.

[0001327567-16-000064:mdna:60]
Cost of Services Revenue

[0001327567-16-000064:mdna:61]
Cost of services revenue includes personnel costs for our global customer support and technical operations organizations, amortization of acquired intangible assets, third-party professional services costs, and allocated costs. We expect our cost of services revenue to increase as our installed end-customer base grows.

[0001327567-16-000064:mdna:62]
|  | Year Ended July 31, |  |  |  | Year Ended July 31, |  |  |
|  | 2016 |  | 2015 |  | Change |  | 2015 |  | 2014 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| Cost of services revenue | $ | 194.6 |  |  | $ | 120.4 |  |  | $ | 74.2 |  |  | 61.7 | % |  | $ | 120.4 |  |  | $ | 74.1 |  |  | $ | 46.3 |  |  | 62.4 | % |
| Number of employees at period end | 539 |  |  | 357 |  |  | 182 |  |  | 51.0 | % |  | 357 |  |  | 229 |  |  | 128 |  |  | 55.9 | % |

[0001327567-16-000064:mdna:63]
Cost of services revenue increased year-over-year for both fiscal 2016 and fiscal 2015. The increases in both periods were driven by increases in personnel costs, which grew $42.1 million to $104.1 million for fiscal 2016 compared to fiscal 2015 and grew $25.8 million to $62.0 million for fiscal 2015 compared to fiscal 2014. The increases in personnel costs in both periods were due to headcount growth. The remaining increases in both periods were due to expansion of our customer service capabilities and infrastructure to support our growing installed end-customer base.

[0001327567-16-000064:mdna:64]
Gross Margin

[0001327567-16-000064:mdna:65]
Gross margin, or gross profit as a percentage of revenue, has been and will continue to be affected by a variety of factors, including the average sales price of our products, manufacturing costs, the mix of products sold, and the mix of revenue between products and services. For sales of our products, our higher end firewall products generally have higher gross margins than our lower end firewall products within each product series. For sales of our services, our subscriptions typically have higher gross

[0001327567-16-000064:mdna:66]
- 42 -

[0001327567-16-000064:mdna:67]
margins than our support and maintenance. We expect our gross margins to fluctuate over time depending on the factors described above.

[0001327567-16-000064:mdna:68]
|  | Year Ended July 31, |
|  | 2016 |  | 2015 |  | 2014 |
|  | Amount |  | GrossMargin |  | Amount |  | GrossMargin |  | Amount |  | GrossMargin |
|  | (dollars in millions) |
| Gross profit: |  |  |  |  |  |  |  |  |  |  |  |
| Product | $ | 495.4 |  |  | 73.9 | % |  | $ | 361.6 |  |  | 73.4 | % |  | $ | 254.6 |  |  | 74.9 | % |
| Services | 513.1 |  |  | 72.5 | % |  | 315.0 |  |  | 72.3 | % |  | 184.0 |  |  | 71.3 | % |
| Total gross profit | $ | 1,008.5 |  |  | 73.2 | % |  | $ | 676.6 |  |  | 72.9 | % |  | $ | 438.6 |  |  | 73.3 | % |

[0001327567-16-000064:mdna:69]
Product gross margin increased for fiscal 2016 compared to fiscal 2015 due to our continued focus on material cost reductions. Product gross margin decreased for fiscal 2015 compared to fiscal 2014 due to increased amortization of intellectual property licenses as a result of the Settlement Agreement with Juniper in May 2014.

[0001327567-16-000064:mdna:70]
Services gross margin was flat for fiscal 2016 compared to fiscal 2015. Services gross margin increased for fiscal 2015 compared to fiscal 2014 due to contributions from our higher margin subscription services, partially offset by increased amortization of purchased intangible assets.

[0001327567-16-000064:mdna:71]
Operating Expenses

[0001327567-16-000064:mdna:72]
Our operating expenses consist of research and development, sales and marketing, general and administrative, and legal settlement expense. Personnel costs are the most significant component of operating expenses and consist of salaries, benefits, bonuses, share-based compensation, and with regard to sales and marketing expense, sales commissions. Our operating expenses also include allocated costs, which consist of certain facilities, depreciation, benefits, recruiting, and information technology costs that we allocate based on headcount. We expect operating expenses to increase in absolute dollars and decrease over the long term as a percentage of revenue as we continue to scale our business. As of July 31, 2016, we expect to recognize approximately $822.9 million of share-based compensation expense over a weighted-average period of approximately 2.4 years, excluding additional share-based compensation expense related to any future grants of share-based awards. Share-based compensation expense, net of forfeitures, is recognized on a straight-line basis over the requisite service periods of the awards.

[0001327567-16-000064:mdna:73]
Research and Development

[0001327567-16-000064:mdna:74]
Research and development expense consists primarily of personnel costs. Research and development expense also includes prototype related expenses and allocated costs. We expect research and development expense to increase in absolute dollars as we continue to invest in our future products and services, although our research and development expense may fluctuate as a percentage of total revenue.

[0001327567-16-000064:mdna:75]
|  | Year Ended July 31, |  |  |  | Year Ended July 31, |  |  |
|  | 2016 |  | 2015 |  | Change |  | 2015 |  | 2014 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| Research and development | $ | 284.2 |  |  | $ | 185.8 |  |  | $ | 98.4 |  |  | 52.9 | % |  | $ | 185.8 |  |  | $ | 104.8 |  |  | $ | 81.0 |  |  | 77.3 | % |
| Number of employees at period end | 637 |  |  | 475 |  |  | 162 |  |  | 34.1 | % |  | 475 |  |  | 312 |  |  | 163 |  |  | 52.2 | % |

[0001327567-16-000064:mdna:76]
Research and development expense increased year-over-year for both fiscal 2016 and fiscal 2015. The increases in both periods were driven by increases in personnel costs, which grew $86.8 million to $236.4 million for fiscal 2016 compared to fiscal 2015 and grew $73.7 million to $149.6 million for fiscal 2015 compared to fiscal 2014. The increases in personnel costs in both periods were due to headcount growth.

[0001327567-16-000064:mdna:77]
Sales and Marketing

[0001327567-16-000064:mdna:78]
Sales and marketing expense consists primarily of personnel costs, including commission costs. We expense commission costs as incurred. Sales and marketing expense also includes costs for market development programs, promotional and other marketing costs, travel costs, professional services, and allocated costs. We continue to thoughtfully invest in headcount and have substantially grown our sales presence internationally. We expect sales and marketing expense to continue to increase in absolute

[0001327567-16-000064:mdna:79]
- 43 -

[0001327567-16-000064:mdna:80]
dollars as we increase the size of our sales and marketing organizations to increase touch points with end-customers and to expand our international presence, although our sales and marketing expense may fluctuate as a percentage of total revenue.

[0001327567-16-000064:mdna:81]
|  | Year Ended July 31, |  |  |  | Year Ended July 31, |  |  |
|  | 2016 |  | 2015 |  | Change |  | 2015 |  | 2014 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| Sales and marketing | $ | 776.0 |  |  | $ | 522.7 |  |  | $ | 253.3 |  |  | 48.5 | % |  | $ | 522.7 |  |  | $ | 334.8 |  |  | $ | 187.9 |  |  | 56.1 | % |
| Number of employees at period end | 2,092 |  |  | 1,443 |  |  | 649 |  |  | 45.0 | % |  | 1,443 |  |  | 956 |  |  | 487 |  |  | 50.9 | % |

[0001327567-16-000064:mdna:82]
Sales and marketing expense increased year-over-year for both fiscal 2016 and fiscal 2015. The increases in both periods were driven by increases in personnel costs, which grew $185.2 million to $553.0 million for fiscal 2016 compared to fiscal 2015 and grew $140.4 million to $367.8 million for fiscal 2015 compared to fiscal 2014. The increases in personnel costs in both periods were due to headcount growth.

[0001327567-16-000064:mdna:83]
General and Administrative

[0001327567-16-000064:mdna:84]
General and administrative expense consists of personnel costs for our executive, finance, human resources, legal, and information technology organizations, professional services costs, which consist primarily of legal, auditing, accounting, and other consulting costs, and certain non-recurring general expenses. Certain facilities, depreciation, benefits, recruiting, and information technology costs are allocated to other organizations based on headcount. We expect general and administrative expense to increase in absolute dollars due to additional costs associated with accounting, compliance, insurance, and investor relations, although our general and administrative expense may fluctuate as a percentage of total revenue.

[0001327567-16-000064:mdna:85]
|  | Year Ended July 31, |  |  |  | Year Ended July 31, |  |  |
|  | 2016 |  | 2015 |  | Change |  | 2015 |  | 2014 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| General and administrative | $ | 138.4 |  |  | $ | 101.6 |  |  | $ | 36.8 |  |  | 36.2 | % |  | $ | 101.6 |  |  | $ | 73.1 |  |  | $ | 28.5 |  |  | 38.8 | % |
| Number of employees at period end | 436 |  |  | 295 |  |  | 141 |  |  | 47.8 | % |  | 295 |  |  | 175 |  |  | 120 |  |  | 68.6 | % |

[0001327567-16-000064:mdna:86]
General and administrative expense increased year-over-year for both fiscal 2016 and fiscal 2015. The increases in both periods were driven by increases in personnel costs, which grew $32.9 million to $96.5 million for fiscal 2016 compared to fiscal 2015 and grew $31.4 million to $63.5 million for fiscal 2015 compared to fiscal 2014. The increases in personnel costs in both periods were due to headcount growth.

[0001327567-16-000064:mdna:87]
Legal Settlement

[0001327567-16-000064:mdna:88]
We incurred legal settlement expenses of $121.2 million and $20.0 million in fiscal 2014 related to the Settlement Agreement with Juniper and the Mutual Covenant Not to Sue and Release Agreement with Fortinet, respectively. Refer to the discussion under Note 9. Legal Settlement of Notes to Consolidated Financial Statements in Part II, Item 8 of this Annual Report on Form 10-K for information related to these matters.

[0001327567-16-000064:mdna:89]
- 44 -

[0001327567-16-000064:mdna:90]
Interest Expense

[0001327567-16-000064:mdna:91]
Interest expense primarily consists of the amortization of the debt discount and debt issuance costs related to the 0.0% Convertible Seniors Notes due 2019 (the “Notes”). This interest expense is non-cash and will range from $24.5 million to $25.7 million per year through fiscal 2019.

[0001327567-16-000064:mdna:92]
|  | Year Ended July 31, |  |  |  | Year Ended July 31, |  |  |
|  | 2016 |  | 2015 |  | Change |  | 2015 |  | 2014 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| Interest expense | $ | 23.4 |  |  | $ | 22.3 |  |  | $ | 1.1 |  |  | 4.8% |  | $ | 22.3 |  |  | $ | 1.9 |  |  | $ | 20.4 |  |  | NM |

[0001327567-16-000064:mdna:93]
Interest expense was flat for fiscal 2016 compared to fiscal 2015. Interest expense increased for fiscal 2015 compared to fiscal 2014 due to the amortization of the debt discount and debt issuance costs related to the Notes, which were issued on June 30, 2014.

[0001327567-16-000064:mdna:94]
Other Income (Expense), Net

[0001327567-16-000064:mdna:95]
Other income (expense), net includes interest income earned on our cash, cash equivalents, and investments, foreign currency remeasurement gains and losses, and foreign currency transaction gains and losses.

[0001327567-16-000064:mdna:96]
|  | Year Ended July 31, |  |  |  | Year Ended July 31, |  |  |
|  | 2016 |  | 2015 |  | Change |  | 2015 |  | 2014 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| Other income (expense), net | $ | 8.4 |  |  | $ | 0.2 |  |  | $ | 8.2 |  |  | NM |  | $ | 0.2 |  |  | $ | (5.0 | ) |  | $ | 5.2 |  |  | NM |

[0001327567-16-000064:mdna:97]
Other income (expense), net increased for fiscal 2016 compared to fiscal 2015 due to an increase in interest income and higher foreign currency remeasurement gains. In fiscal 2014, we recorded an expense of $5.9 million in other income (expense), net to record the change in fair value of the warrant issued to Juniper in connection with the Settlement Agreement. The warrant was classified as a liability on our consolidated balance sheets and remeasured to fair value from June 3, 2014, the issuance date of the warrant, through July 1, 2014, the date the warrant was exercised.

[0001327567-16-000064:mdna:98]
Provision for Income Taxes

[0001327567-16-000064:mdna:99]
Provision for income taxes consists primarily of income taxes in foreign jurisdictions in which we conduct business, withholding taxes, federal and state income taxes in the United States, and amortization of our deferred tax charges. We maintain a full valuation allowance for domestic deferred tax assets, including net operating loss carryforwards and tax credits.

[0001327567-16-000064:mdna:100]
In recent years, we reorganized our corporate structure and intercompany relationships to more closely align with the international nature of our business activities. Our corporate structure has caused, and may continue to cause, disproportionate relationships between our overall effective tax rate and other jurisdictional measures.

[0001327567-16-000064:mdna:101]
In fiscal 2015, we recorded deferred tax charges of $36.8 million in connection with a corporate restructure. The current portion of the deferred tax charges is included in prepaid expenses and other current assets and the remainder in other assets in our consolidated balance sheets. The deferred tax charges are being amortized on a straight-line basis over approximately seven years as a component of provision for income taxes.

[0001327567-16-000064:mdna:102]
|  | Year Ended July 31, |  |  |  |  |  | Year Ended July 31, |  |  |  |  |
|  | 2016 |  | 2015 |  | Change |  | 2015 |  | 2014 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| Provision for income taxes | $ | 20.8 |  |  | $ | 9.4 |  |  | $ | 11.4 |  |  | 121.4 | % |  | $ | 9.4 |  |  | $ | 4.3 |  |  | $ | 5.1 |  |  | 119.1 | % |
| Effective tax rate | (10.2 | )% |  | (6.0 | )% |  |  |  |  |  | (6.0 | )% |  | (1.9 | )% |  |  |  |  |

[0001327567-16-000064:mdna:103]
We recorded an income tax provision for fiscal 2016 due to federal, state, and foreign income taxes, withholding taxes, and amortization of our deferred tax charges. The provision for income taxes increased for fiscal 2016 compared to fiscal 2015 primarily due to an increase in foreign taxes and amortization of our deferred tax charges.

[0001327567-16-000064:mdna:104]
- 45 -

[0001327567-16-000064:mdna:105]
We recorded an income tax provision for fiscal 2015 due to federal, state, and foreign income taxes, foreign withholding taxes, and amortization of our deferred tax charges. The provision for income taxes increased for fiscal 2015 compared to fiscal 2014 due to amortization of our deferred tax charges and a shift in geographical mix of income, partially offset by the tax benefit from a partial release of the valuation allowance in connection with the acquisition of CirroSecure.

[0001327567-16-000064:mdna:106]
Liquidity and Capital Resources

[0001327567-16-000064:mdna:107]
|  | July 31, |
|  | 2016 |  | 2015 |
|  | (in millions) |
| Working capital (1) | $ | 872.3 |  |  | $ | 41.8 |  |
| Cash, cash equivalents, and investments: |  |  |  |
| Cash and cash equivalents | $ | 734.4 |  |  | $ | 375.8 |  |
| Investments | 1,204.0 |  |  | 952.0 |  |
| Total cash, cash equivalents, and investments | $ | 1,938.4 |  |  | $ | 1,327.8 |  |

[0001327567-16-000064:mdna:108]
______________

[0001327567-16-000064:mdna:109]
| (1) | As of July 31, 2015, the net carrying amount of the Notes was classified in current liabilities in our consolidated balance sheets. Refer to Note 7. Convertible Senior Notes of Notes to Consolidated Financial Statements included in Part II, Item 8 of this Annual Report on Form 10-K for more information. |

[0001327567-16-000064:mdna:110]
At July 31, 2016, our total cash, cash equivalents, and investments of $1.9 billion were held for general corporate purposes, of which approximately $148.6 million was held outside of the United States. We do not provide for federal income taxes on the undistributed earnings of our foreign subsidiaries, all of which we expect to reinvest outside of the United States indefinitely. However, if these funds were needed for our domestic operations, we would be required to accrue and pay U.S. taxes on undistributed earnings of foreign subsidiaries. There are no other restrictions on the use of these funds. If we were to repatriate these earnings to the United States, any associated income tax liability would be insignificant.

[0001327567-16-000064:mdna:111]
As of July 31, 2016, all of the Notes remained outstanding. The Notes mature on July 1, 2019, however, prior to January 1, 2019, holders may surrender their Notes for early conversion under certain circumstances. Upon conversion, we will pay cash equal to the aggregate principal amount of the Notes to be converted, and, at our election, will pay or deliver cash and/or shares of our common stock for the amount of our conversion obligation in excess of the aggregate principal amount of the Notes being converted. Refer to Note 7. Convertible Senior Notes of Notes to Consolidated Financial Statements included in Part II, Item 8 of this Annual Report on Form 10-K for information on the Notes.

[0001327567-16-000064:mdna:112]
On August 26, 2016, our board of directors authorized a $500.0 million share repurchase which will be funded from available working capital. Repurchases may be made at management’s discretion from time to time on the open market, through privately negotiated transactions, transactions structured through investment banking institutions, block purchase techniques, 10b5-1 trading plans, or a combination of the foregoing. The repurchase authorization will expire on August 31, 2018, and may be suspended or discontinued at any time.

[0001327567-16-000064:mdna:113]
The following table summarizes our cash flows for the years ended July 31, 2016, 2015, and 2014.

[0001327567-16-000064:mdna:114]
|  | Year Ended July 31, |
| 2016 |  | 2015 |  | 2014 |
|  | (in millions) |
| Net cash provided by operating activities | $ | 658.1 |  |  | $ | 350.3 |  |  | $ | 88.4 |  |
| Net cash used in investing activities | (338.9 | ) |  | (679.0 | ) |  | (320.3 | ) |
| Net cash provided by financing activities | 39.4 |  |  | 50.7 |  |  | 575.1 |  |
| Net increase (decrease) in cash and cash equivalents | $ | 358.6 |  |  | $ | (278.0 | ) |  | $ | 343.2 |  |

[0001327567-16-000064:mdna:115]
We believe that our cash flow from operations with existing cash and cash equivalents will be sufficient to meet our anticipated cash needs for the foreseeable future. Our future capital requirements will depend on many factors including our growth rate, the timing and extent of spending to support development efforts, the expansion of sales and marketing activities, the introduction of new and enhanced products and services offerings, the costs to acquire or invest in complementary businesses and technologies, the costs to ensure access to adequate manufacturing capacity, the investments in our new corporate headquarters,

[0001327567-16-000064:mdna:116]
- 46 -

[0001327567-16-000064:mdna:117]
and the continuing market acceptance of our products. In addition, from time to time we may incur additional tax liability in connection with certain tax structuring decisions.

[0001327567-16-000064:mdna:118]
We may also choose to seek additional equity or debt financing. In the event that additional financing is required from outside sources, we may not be able to raise it on terms acceptable to us or at all. If we are unable to raise additional capital when desired, our business, operating results, and financial condition may be adversely affected.

[0001327567-16-000064:mdna:119]
Operating Activities

[0001327567-16-000064:mdna:120]
Our operating activities have consisted of net loss adjusted for certain non-cash items and changes in assets and liabilities.

[0001327567-16-000064:mdna:121]
Cash provided by operating activities in fiscal 2016 was $658.1 million, an increase of $307.8 million compared to fiscal 2015. The increase was due to growth of our business and changes in our assets and liabilities during fiscal 2016, which included an increase in sales of subscription and support and maintenance contracts to new and existing customers as reflected by an increase in deferred revenue, and was partially offset by an increase in accounts receivable due to an increase in sales near the end of the period.

[0001327567-16-000064:mdna:122]
Cash provided by operating activities in fiscal 2015 was $350.3 million, an increase of $261.9 million compared to fiscal 2014. The increase was due to growth of our business and changes in our assets and liabilities during fiscal 2015. Additionally, in fiscal 2014, we made a total of $95.0 million in payments related to legal settlements. Changes in assets and liabilities for fiscal 2015 compared to fiscal 2014 include an increase in sales of subscriptions and support and maintenance contracts to new and existing customers as reflected by an increase in deferred revenue. In addition, during fiscal 2015, we made a tax payment of $12.8 million in connection with an intercompany transfer of intellectual property.

[0001327567-16-000064:mdna:123]
Investing Activities

[0001327567-16-000064:mdna:124]
Our investing activities have consisted of capital expenditures, net investment purchases, sales, and maturities, and business acquisitions. We expect to continue such activities as our business grows.

[0001327567-16-000064:mdna:125]
Cash used in investing activities during fiscal 2016 was $338.9 million, a decrease of $340.1 million compared to fiscal 2015, due to lower net purchases of available-for-sale investments and a payment of $15.1 million related to our acquisition of CirroSecure in fiscal 2015, partially offset by increased investment in infrastructure and facilities to support the growth of our business.

[0001327567-16-000064:mdna:126]
Cash used in investing activities during fiscal 2015 was $679.0 million, an increase of $358.7 million compared to fiscal 2014. The increase was due to higher net purchases of available-for-sale investments in fiscal 2015, partially offset by higher payments made in fiscal 2014 related to our acquisitions of Cyvera and Morta.

[0001327567-16-000064:mdna:127]
Financing Activities

[0001327567-16-000064:mdna:128]
Our financing activities have consisted of proceeds from the issuance of the Notes and proceeds from sales of shares through employee equity incentive plans.

[0001327567-16-000064:mdna:129]
Cash provided by financing activities during fiscal 2016 was $39.4 million, a decrease of $11.3 million compared to fiscal 2015, due to a payment of deferred consideration related to our acquisition of Cyvera, lower proceeds from the sale of shares through employee equity incentive plans, and a decrease in excess tax benefit from share-based compensation arrangements.

[0001327567-16-000064:mdna:130]
Cash provided by financing activities during fiscal 2015 was $50.7 million, a decrease of $524.4 million compared to fiscal 2014. The decrease was due to net proceeds from the issuance of the Notes of $527.7 million in fiscal 2014.

[0001327567-16-000064:mdna:131]
Contractual Obligations and Commitments

[0001327567-16-000064:mdna:132]
The following summarizes our contractual obligations and commitments as of July 31, 2016:

[0001327567-16-000064:mdna:133]
|  | Payments Due by Period |
|  | Total |  | Less Than 1 Year |  | 1 - 3 Years |  | 3- 5 Years |  | More Than 5 Years |
|  |  |  | (in millions) |  |  |
| 0.0% Convertible Senior Notes due 2019 | $ | 575.0 |  |  | $ | — |  |  | $ | 575.0 |  |  | $ | — |  |  | $ | — |  |
| Operating lease obligations (1) | 509.3 |  |  | 27.3 |  |  | 79.5 |  |  | 103.9 |  |  | 298.6 |  |
| Purchase obligations (2) | 54.2 |  |  | 54.2 |  |  | — |  |  | — |  |  | — |  |
| Total (3) | $ | 1,138.5 |  |  | $ | 81.5 |  |  | $ | 654.5 |  |  | $ | 103.9 |  |  | $ | 298.6 |  |

[0001327567-16-000064:mdna:134]
- 47 -

[0001327567-16-000064:mdna:135]
______________

[0001327567-16-000064:mdna:136]
| (1) | Consists of contractual obligations from our non-cancelable operating leases. Excludes contractual sublease proceeds of $5.1 million, of which $3.0 million will be received in less than one year and $2.1 million will be received in one to two years. Refer to Note 8. Commitments and Contingencies of Notes to Consolidated Financial Statements included in Part II, Item 8 of this Annual Report on Form 10-K for more information on our operating leases. |

[0001327567-16-000064:mdna:137]
| (2) | Consists of minimum purchase commitments of products and components with our independent contract manufacturer and original design manufacturers. Obligations under contracts that we can cancel without a significant penalty are not included in the table above. |

[0001327567-16-000064:mdna:138]
| (3) | No amounts related to income taxes are included. As of July 31, 2016, we had approximately $48.4 million of tax liabilities recorded related to uncertainty in income tax positions. |

[0001327567-16-000064:mdna:139]
Off-Balance Sheet Arrangements

[0001327567-16-000064:mdna:140]
Through July 31, 2016, we did not have any relationships with unconsolidated organizations or financial partnerships, such as structured finance or special purpose entities that would have been established for the purpose of facilitating off-balance sheet arrangements or other contractually narrow or limited purposes.

[0001327567-16-000064:mdna:141]
Critical Accounting Estimates

[0001327567-16-000064:mdna:142]
Our consolidated financial statements have been prepared in accordance with U.S. GAAP. The preparation of these consolidated financial statements requires us to make estimates and assumptions that affect the reported amounts of assets, liabilities, revenue, expenses, and related disclosures. We base our estimates on historical experience and on various other assumptions that we believe are reasonable under the circumstances. We evaluate our estimates and assumptions on an ongoing basis. Actual results may differ from these estimates. To the extent that there are material differences between these estimates and our actual results, our future financial statements will be affected.

[0001327567-16-000064:mdna:143]
The critical accounting policies requiring estimates, assumptions, and judgments that we believe have the most significant impact on our consolidated financial statements are described below.

[0001327567-16-000064:mdna:144]
Revenue Recognition

[0001327567-16-000064:mdna:145]
We recognize revenue when persuasive evidence of an arrangement exists, delivery has occurred, the fee is fixed or determinable, and collectability is reasonably assured. Most of our arrangements, other than renewals of subscriptions and support and maintenance, are multiple-element arrangements with a combination of hardware, software, subscriptions, support and maintenance, and other services. For multiple-element arrangements, we allocate revenue to each unit of accounting based on an estimated selling price at the arrangement inception. The estimated selling price for each element is based upon the following hierarchy:

[0001327567-16-000064:mdna:146]
| • | Vendor-specific objective evidence (“VSOE”) of selling price, if available, |

[0001327567-16-000064:mdna:147]
| • | Third-party evidence (“TPE”) of selling price, if VSOE of selling price is not available, or |

[0001327567-16-000064:mdna:148]
| • | Best estimate of selling price (“BESP”), if neither VSOE of selling price nor TPE of selling price are available. |

[0001327567-16-000064:mdna:149]
We establish VSOE of selling price using the prices charged for a deliverable when sold separately. We establish TPE of selling price by evaluating similar and interchangeable competitor products or services in standalone arrangements with similarly situated partners. We establish BESP primarily based on historical transaction pricing, whereby historical transactions are segregated based on our pricing model and our go-to-market strategy, which include factors such as type of sales channel (reseller, distributor, or end-customer), the geographies in which our products and services were sold (domestic or international), and offering type (products or services). To further support the best estimate of selling price as determined by the historical transaction pricing or when such information is unavailable, such as when there are limited sales of a new product or service, we consider the same factors we have established through our pricing model and go-to-market strategy. The determination of BESP is made through consultation with and approval by our management. In determining BESP, we rely on certain assumptions and apply significant judgment. As our business offerings evolve over time, we may be required to modify our estimated selling prices in subsequent periods, and the timing of our revenue recognition could be affected.

[0001327567-16-000064:mdna:150]
Share-Based Compensation

[0001327567-16-000064:mdna:151]
Compensation expense related to share-based transactions is measured and recognized in the financial statements based on fair value estimated on the grant date. The fair value of restricted stock units (“RSUs”) and restricted stock awards (“RSAs”) is based on the closing market price of our common stock on the date of grant. The fair value of stock options and shares sold

[0001327567-16-000064:mdna:152]
- 48 -

[0001327567-16-000064:mdna:153]
through our employee stock purchase plan (“ESPP”) are estimated on the grant date using the Black-Scholes option pricing model, which requires the use of subjective assumptions, including the expected term of the award and the expected volatility of the price of our common stock.

[0001327567-16-000064:mdna:154]
We recognize share-based compensation expense on a straight-line basis over the requisite service periods of the awards, net of estimated forfeitures. Our estimated forfeiture rate is based on an analysis of our actual historical forfeitures. A change in our estimated forfeiture rate could have a significant impact on our share-based compensation expense as the cumulative effect of adjusting the rate is recognized in the period the forfeiture estimate is changed.

[0001327567-16-000064:mdna:155]
We will continue to use judgment in evaluating the assumptions related to our share-based compensation expense on a prospective basis. As we continue to accumulate additional data, we may have refinements to our estimates, which could materially impact our future share-based compensation expense.

[0001327567-16-000064:mdna:156]
Income Taxes

[0001327567-16-000064:mdna:157]
We account for income taxes using the asset and liability method, which requires the recognition of deferred tax assets and liabilities for the expected future tax consequences of events that have been recognized in our financial statements or tax returns. In addition, deferred tax assets are recorded for the future benefit of utilizing net operating losses and research and development credit carryforwards. Valuation allowances are provided when necessary to reduce deferred tax assets to the amount expected to be realized.

[0001327567-16-000064:mdna:158]
Significant judgment is required in determining any valuation allowance recorded against deferred tax assets. In assessing the need for a valuation allowance, we consider all available evidence, including past operating results, estimates of future taxable income, and the feasibility of tax planning strategies. In the event that we change our determination as to the amount of deferred tax assets that can be realized, we will adjust our valuation allowance with a corresponding impact to the provision for income taxes in the period in which such determination is made.

[0001327567-16-000064:mdna:159]
We apply the authoritative accounting guidance prescribing a threshold and measurement attribute for the financial recognition and measurement of a tax position taken or expected to be taken in a tax return. We recognize liabilities for uncertain tax positions based on a two-step process. The first step is to evaluate the tax position for recognition by determining if the weight of available evidence indicates that it is more likely than not that the position will be sustained on audit, including resolution of related appeals or litigation processes, if any. The second step requires us to estimate and measure the tax benefit as the largest amount that is more likely than not to be realized upon ultimate settlement.

[0001327567-16-000064:mdna:160]
Significant judgment is also required in evaluating our uncertain tax positions and determining our provision for income taxes. Although we believe our reserves are reasonable, no assurance can be given that the final tax outcome of these matters will not be different from that which is reflected in our historical income tax provisions and accruals. We adjust these reserves in light of changing facts and circumstances, such as the closing of a tax audit or the refinement of an estimate. To the extent that the final tax outcome of these matters is different than the amounts recorded, such differences may impact the provision for income taxes in the period in which such determination is made.

[0001327567-16-000064:mdna:161]
Contract Manufacturer Liabilities

[0001327567-16-000064:mdna:162]
We outsource most of our manufacturing, repair, and supply chain management operations to our independent contract manufacturer, which procures components and assembles our products based on our demand forecasts. These forecasts of future demand are based upon historical trends and analysis from our sales and product management functions as adjusted for overall market conditions. We accrue for costs for manufacturing commitments in excess of our forecasted demand, including costs for excess components or for carrying costs incurred by our contract manufacturer. Actual component usage and product demand may be materially different from our forecast, and could be caused by factors outside of our control, which could have an adverse impact on our results of operations. To date, we have not accrued significant costs associated with this exposure.

[0001327567-16-000064:mdna:163]
Loss Contingencies

[0001327567-16-000064:mdna:164]
We are subject to the possibility of various loss contingencies arising in the ordinary course of business. We accrue for loss contingencies when it is probable that an asset has been impaired or a liability has been incurred and the amount of loss can be reasonably estimated. If we determine that a loss is possible and the range of the loss can be reasonably determined, then we disclose the range of the possible loss. We regularly evaluate current information available to us to determine whether an accrual is required, an accrual should be adjusted or a range of possible loss should be disclosed.

[0001327567-16-000064:mdna:165]
From time to time, we are involved in disputes, litigation, and other legal actions. However, there are many uncertainties associated with any litigation, and these actions or other third-party claims against us may cause us to incur substantial settlement charges, which are inherently difficult to estimate and could adversely affect our results of operations. The actual liability in any

[0001327567-16-000064:mdna:166]
- 49 -

[0001327567-16-000064:mdna:167]
such matters may be materially different from our estimates, which could result in the need to adjust our liability and record additional expenses.

[0001327567-16-000064:mdna:168]
Goodwill, Intangibles, and Other Long-Lived Assets

[0001327567-16-000064:mdna:169]
We make significant estimates, assumptions, and judgments when valuing goodwill and other purchased intangible assets in connection with the initial purchase price allocation of an acquired entity, as well as when evaluating impairment of goodwill and other purchased intangible assets on an ongoing basis. These estimates are based upon a number of factors, including historical experience, market conditions, and information obtained from the management of the acquired company. Critical estimates in valuing certain intangible assets include, but are not limited to, cash flows that an asset is expected to generate in the future, discount rates, the time and expense that would be necessary to recreate the assets, and the profit margin a market participant would receive. The amounts and useful lives assigned to identified intangible assets impacts the amount and timing of future amortization expense.

[0001327567-16-000064:mdna:170]
We evaluate goodwill for impairment on an annual basis in our fourth fiscal quarter or more frequently if we believe impairment indicators exist. We first analyze qualitative factors, which include industry and market considerations, overall financial performance, and other relevant events and factors affecting the reporting unit. If qualitative factors indicate that it is more likely than not that the reporting unit’s fair value is less than its carrying amount, then we will perform the quantitative analysis required under the two-step goodwill impairment test.

[0001327567-16-000064:mdna:171]
Under the two-step goodwill impairment test, we first compare the reporting unit’s carrying amount, including goodwill, to the fair value of the reporting unit. The fair value of the reporting unit is estimated using significant judgment based on a combination of the income and the market approaches. If the fair value of the reporting unit does not exceed the carrying amount of the net assets assigned to the reporting unit, then we perform the second step of the impairment test in order to determine the implied fair value of the reporting unit’s goodwill. When the carrying amount of a reporting unit’s goodwill exceeds its implied fair value, we record an impairment loss equal to the difference. Determining the fair value of a reporting unit is highly judgmental in nature and involves the use of significant estimates and assumptions. These estimates and assumptions include revenue growth rates and operating margins used to calculate projected future cash flows, operating trends, risk-adjusted discount rates, future economic and market conditions, and determination of appropriate market comparables. We base our fair value estimates on assumptions we believe to be reasonable but that are unpredictable and inherently uncertain. Actual future results may differ from those estimates.

[0001327567-16-000064:mdna:172]
We evaluate long-lived assets, such as property, equipment, and purchased intangible assets for impairment whenever events or changes in circumstances indicate that the carrying amount of the assets may not be recoverable. Such events or changes in circumstances include, but are not limited to, a significant decrease in the fair value of the underlying asset or asset group, a significant decrease in the benefits realized from the acquired assets, difficulty and delays in integrating the business, or a significant change in the operations of the acquired assets or use of an asset. A long-lived asset is considered impaired if its carrying amount exceeds the estimated future undiscounted cash flows the asset or asset group is expected to generate. If a long-lived asset is considered to be impaired, the impairment to be recognized is the amount by which the carrying amount of the asset exceeds the fair value of the asset or asset group.

[0001327567-16-000064:mdna:173]
To date, we have not recognized any impairment losses on our goodwill, intangible assets, and long-lived assets.

[0001327567-16-000064:mdna:174]
Recent Accounting Pronouncements

[0001327567-16-000064:mdna:175]
Refer to “Recent Accounting Pronouncements” in Note 1. Description of Business and Summary of Significant Accounting Policies of Notes to Consolidated Financial Statements included in Part II, Item 8 of this Annual Report on Form 10-K.
