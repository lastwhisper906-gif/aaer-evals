# PANW 8-K — 0001327567-16-000057 filed 2016-08-30

## item codes, every 8-K on or before 2016-09-08

- 2016-08-30 0001327567-16-000057 — 2.02, 5.03, 8.01, 9.01
- 2016-08-22 0001193125-16-687588 — 5.02, 9.01
- 2016-05-26 0001327567-16-000051 — 2.02, 9.01
- 2016-02-25 0001327567-16-000044 — 2.02, 5.02, 9.01
- 2015-12-14 0001327567-15-000038 — 5.07
- 2015-12-14 0001193125-15-402588 — 1.01, 9.01
- 2015-11-23 0001327567-15-000033 — 2.02, 9.01
- 2015-10-19 0001193125-15-347005 — 1.01, 9.01 — amendment, the index does not say of what
- 2015-09-09 0001327567-15-000022 — 2.02, 9.01
- 2015-08-19 0001193125-15-296115 — 1.01, 2.03
- 2015-06-01 0001193125-15-207786 — 1.01, 2.03
- 2015-05-27 0001327567-15-000015 — 2.02, 9.01
- 2015-03-02 0001327567-15-000006 — 2.02, 9.01
- 2014-12-15 0001327567-14-000046 — 5.07
- 2014-11-24 0001327567-14-000040 — 2.02, 9.01
- 2014-09-22 0001193125-14-348581 — 5.02, 9.01
- 2014-09-09 0001327567-14-000025 — 2.02, 9.01
- 2014-07-01 0001193125-14-257824 — 1.01, 2.03, 3.02, 9.01
- 2014-06-26 0001193125-14-249529 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2014-06-20 0001327567-14-000020 — 9.01 — amendment of 0001193125-14-140511
- 2014-06-04 0001327567-14-000016 — 3.02
- 2014-05-30 0001193125-14-218158 — 2.02 — amendment, the index does not say of what
- 2014-05-28 0001193125-14-215060 — 1.01, 2.02, 3.02, 9.01
- 2014-04-11 0001193125-14-140511 — 2.01, 3.02, 7.01, 9.01
- 2014-03-24 0001193125-14-111318 — 1.01, 3.02, 7.01, 9.01
- 2014-03-13 0001327567-14-000009 — 5.02
- 2014-02-24 0001193125-14-063754 — 2.02, 9.01
- 2013-12-12 0001327567-13-000040 — 5.07
- 2013-11-25 0001327567-13-000033 — 2.02, 9.01
- 2013-09-30 0001193125-13-384966 — 8.01
- 2013-09-09 0001193125-13-361421 — 2.02, 9.01
- 2013-05-30 0001193125-13-241542 — 2.02, 5.02, 9.01
- 2013-03-11 0001193125-13-101082 — 5.02, 9.01
- 2013-02-28 0001193125-13-084193 — 2.02, 9.01
- 2012-12-14 0001193125-12-503335 — 5.07
- 2012-12-06 0001193125-12-493700 — 2.02, 9.01
- 2012-09-24 0001193125-12-401534 — 1.01, 2.03
- 2012-09-20 0001193125-12-398433 — 5.02, 9.01
- 2012-09-10 0001193125-12-386605 — 2.02, 9.01

## late-filing notifications on or before 2016-09-08

- none on or before 2016-09-08

## item 2.02 — earnings release, exhibit 99.1

[0001327567-16-000057:8k_2_02:1]
EX-99.1
3
ex991q416earningsrelease.htm
EXHIBIT 99.1

[0001327567-16-000057:8k_2_02:2]
Exhibit

[0001327567-16-000057:8k_2_02:3]
Exhibit 99.1

[0001327567-16-000057:8k_2_02:4]
Palo Alto Networks Reports Fiscal Fourth Quarter and Fiscal Year 2016 Financial Results

[0001327567-16-000057:8k_2_02:5]
| • | Fiscal fourth quarter total revenue grows 41 percent year over year to $400.8 million |

[0001327567-16-000057:8k_2_02:6]
| • | Fiscal year 2016 total revenue grows 49 percent year over year to $1.4 billion |

[0001327567-16-000057:8k_2_02:7]
| • | Fiscal fourth quarter billings grow 45 percent year over year to $572.4 million |

[0001327567-16-000057:8k_2_02:8]
| • | Fiscal year 2016 billings grow 56 percent year over year to $1.9 billion |

[0001327567-16-000057:8k_2_02:9]
| • | Announces $500 million share repurchase authorization |

[0001327567-16-000057:8k_2_02:10]
SANTA CLARA, Calif. — August 30, 2016 — Palo Alto Networks® (NYSE: PANW), the next-generation security company, today announced financial results for its fiscal fourth quarter and fiscal year 2016 ended July 31, 2016.

[0001327567-16-000057:8k_2_02:11]
Total revenue for the fiscal fourth quarter 2016 grew 41 percent year over year to a record $400.8 million, compared with total revenue of $283.9 million for the fiscal fourth quarter 2015. GAAP net loss for the fiscal fourth quarter 2016 was $54.5 million, or $0.61 per diluted share, compared with GAAP net loss of $46.0 million, or $0.55 per diluted share, for the fiscal fourth quarter 2015.

[0001327567-16-000057:8k_2_02:12]
Non-GAAP net income for the fiscal fourth quarter 2016 was $46.2 million, or $0.50 per diluted share, compared with non-GAAP net income of $25.0 million, or $0.28 per diluted share, for the fiscal fourth quarter 2015. A reconciliation between GAAP and non-GAAP information is contained in the tables below.

[0001327567-16-000057:8k_2_02:13]
“Fourth quarter 2016 was a very strong finish to yet another record fiscal year. Revenue for the year was $1.4 billion, up 49 percent year over year, our customer base expanded to approximately 34,000 customers, we extended our platform capabilities both with new offerings and strategic partnerships, and

[0001327567-16-000057:8k_2_02:14]
we established new routes to market while driving significant growth across our partner ecosystem,” said Mark McLaughlin, chief executive officer of Palo Alto Networks. “The security industry is seeing a rapid transformation from legacy hardware and point products to integrated and automated capabilities that seamlessly work together as a platform. As the primary innovator driving this paradigm shift, customers are turning to our Next-Generation Security Platform in record numbers to more effectively prevent cyberattacks no matter where their data resides.”

[0001327567-16-000057:8k_2_02:15]
For fiscal year 2016, total revenue grew 49 percent to $1.4 billion, compared with $928.1 million in fiscal year 2015. GAAP net loss was $225.9 million, or $2.59 per diluted share, in fiscal year 2016, compared with GAAP net loss of $165.0 million, or $2.02 per diluted share, in fiscal year 2015. Non-GAAP net income for fiscal year 2016 was $152.6 million, or $1.67 per diluted share, compared with non-GAAP net income of $75.2 million, or $0.86 per diluted share, in fiscal year 2015.

[0001327567-16-000057:8k_2_02:16]
Steffan Tomlinson, chief financial officer of Palo Alto Networks, commented, “I am very pleased with our fourth quarter and fiscal year 2016 results, which once again demonstrate the competitive differentiation of our Next-Generation Security Platform and the power of our hybrid-SaaS model. In the fourth quarter, we delivered record revenue, billings and deferred revenue while generating $187.5 million in cash flow from operations and $171.2 million in free cash flow. We ended the fiscal year with approximately $1.9 billion in cash, cash equivalents and investments and are pleased to announce a $500 million share repurchase authorization.”

[0001327567-16-000057:8k_2_02:17]
Recent Highlights

[0001327567-16-000057:8k_2_02:18]
| • | Announced Executive Appointments – Underscoring our commitment to scaling our operations for continued unprecedented growth, Dave Peranich joined us as our new executive vice president of worldwide sales, reporting to Mark Anderson. Mark Anderson has been promoted to president with responsibility for sales, our go-to-market strategies, customer support and business |

[0001327567-16-000057:8k_2_02:19]
2

[0001327567-16-000057:8k_2_02:20]
development, reporting to Mark McLaughlin, our chairman and chief executive officer. Dave brings a wealth of experience from global sales leadership roles held over his nine-year tenure at Riverbed Technology, Inc., as well as previous leadership positions at other leading global technology companies.

[0001327567-16-000057:8k_2_02:21]
| • | Recognized as a Leader Again – For the fifth consecutive year, we were recognized as a leader in the Gartner, Inc. Magic Quadrant for Enterprise Network Firewalls report.1 |

[0001327567-16-000057:8k_2_02:22]
| • | Teamed With Accenture – To help organizations better protect themselves and mitigate risk, we teamed with Accenture, Splunk and Tanium to develop an integrated security offering, wrapped with Accenture services, that includes our Next-Generation Security Platform. |

[0001327567-16-000057:8k_2_02:23]
| • | Enhanced Traps™ Advanced Endpoint Protection – With our new Traps offering, version 3.4, we further strengthened our malware and exploit prevention capabilities, continuing to alleviate the need for legacy antivirus products to protect endpoints. |

[0001327567-16-000057:8k_2_02:24]
| • | Established WildFire™ EU Cloud – Our WildFire EU cloud, hosted in a newly established data center in the Netherlands, enables European organizations with data privacy, protection and localization concerns to realize the full power of our cloud-based threat analysis and prevention capabilities. |

[0001327567-16-000057:8k_2_02:25]
| • | Received ICSA Labs Certification – WildFire received ICSA Labs certification for the third quarter in a row as an Advanced Threat Defense solution. The combined power of our next-generation firewall, URL Filtering, WildFire service and Traps offering achieved this certification with a detection rate of 98 percent and the lowest false-positive rate of any product tested. |

[0001327567-16-000057:8k_2_02:26]
| • | Hosted More Than 800 Channel Partners at Our 2017 Sales Kickoff – We continued our investment in our channel relationships by hosting more than 800 channel partners who participated side by side with our sales representatives in our annual sales training event in mid-August. |

[0001327567-16-000057:8k_2_02:27]
___________

[0001327567-16-000057:8k_2_02:28]
1 Gartner, Inc. “Magic Quadrant for Enterprise Network Firewalls,” May 25, 2016.

[0001327567-16-000057:8k_2_02:29]
Financial Outlook

[0001327567-16-000057:8k_2_02:30]
Palo Alto Networks provides guidance based on current market conditions and expectations.

[0001327567-16-000057:8k_2_02:31]
For the fiscal first quarter 2017*, we expect:

[0001327567-16-000057:8k_2_02:32]
| • | Total fiscal first quarter revenue in the range of $396 to $402 million, representing year-over-year growth between 33 percent and 35 percent. |

[0001327567-16-000057:8k_2_02:33]
| • | Diluted non-GAAP net income per share in the range of $0.51 to $0.53 using 92 to 94 million shares. |

[0001327567-16-000057:8k_2_02:34]
For the fiscal year 2017*, we expect:

[0001327567-16-000057:8k_2_02:35]
| • | Diluted non-GAAP net income per share in the range of $2.75 to $2.80 using 94 to 96 million shares. |

[0001327567-16-000057:8k_2_02:36]
* This guidance reflects a change in accounting policy that we expect to adopt effective the fiscal first quarter 2017 related to sales commissions that are incremental and directly related to customer sales contracts for which revenue is deferred. Under this anticipated change in accounting policy, these commission costs would be accrued and deferred upon execution of a non-cancelable customer contract, and subsequently expensed over the term of such contract in proportion to the related revenue. We anticipate this change to have no material benefit to fiscal first quarter 2017 guidance as the vast majority of the benefit occurs in the second half of fiscal 2017 due to the timing of accelerated commission payments.

[0001327567-16-000057:8k_2_02:37]
Guidance for non-GAAP financial measures excludes share-based compensation related charges, including share-based payroll tax expense, acquisition related costs, amortization expense of acquired intangible assets, litigation-related charges, including legal settlements, non-cash interest expense related to our convertible senior notes, the foreign currency gains (losses) and tax effects associated with these

[0001327567-16-000057:8k_2_02:38]
4

[0001327567-16-000057:8k_2_02:39]
items, and certain non-recurring expenses. We have not reconciled diluted non-GAAP net income per share guidance to GAAP net income (loss) per diluted share because we do not provide guidance on GAAP net income (loss) and would not be able to present the various reconciling cash and non-cash items between GAAP net income (loss) and non-GAAP net income (loss) without unreasonable effort. Share-based compensation expense is impacted by the company’s future hiring and retention needs and, to a lesser extent, the future fair market value of the company’s common stock, all of which is difficult to predict and subject to constant change. The actual amount of share-based compensation in the fiscal first quarter and full fiscal year 2017 will have a significant impact on the company’s GAAP net income (loss) per diluted share. Accordingly, a reconciliation of the non-GAAP financial measure guidance to the corresponding GAAP measure is not available without unreasonable effort.

[0001327567-16-000057:8k_2_02:40]
$500 Million Share Repurchase Authorization

[0001327567-16-000057:8k_2_02:41]
On August 26, 2016, our board of directors authorized a $500 million share repurchase. This authorization allows the company to repurchase its shares opportunistically and will be funded from available working capital. Repurchases may be made at management’s discretion from time to time on the open market, through privately negotiated transactions, transactions structured through investment banking institutions, block purchase techniques, 10b5-1 trading plans, or a combination of the foregoing. The repurchase authorization will expire on August 31, 2018, and may be suspended or discontinued at any time. The company had approximately 90.5 million shares of common stock outstanding as of July 31, 2016.

[0001327567-16-000057:8k_2_02:42]
Conference Call Information

[0001327567-16-000057:8k_2_02:43]
Palo Alto Networks will host a conference call for analysts and investors to discuss its fiscal fourth quarter and fiscal year 2016 results and outlook for its fiscal first quarter and full fiscal year 2017 today at 4:30 p.m. Eastern time/1:30 p.m. Pacific time. Open to the public, investors may access the call by dialing 1-888-329-8889 or 1-719-457-2655 and using conference ID 8969485. A live audio webcast of the

[0001327567-16-000057:8k_2_02:44]
conference call, along with supplemental financial information, will also be accessible from the “Investors” section of our website at investors.paloaltonetworks.com. Following the webcast, an archived version will be available on our website for one year. A telephonic replay of the call will be available three hours after the call, will run for ten days, and may be accessed by dialing 1-888-203-1112 or 1-719-457-0820 and entering the passcode 8969485.

[0001327567-16-000057:8k_2_02:45]
Forward-Looking Statements

[0001327567-16-000057:8k_2_02:46]
This press release contains forward-looking statements that involve risks and uncertainties, including statements regarding our financial outlook for the fiscal first quarter and full fiscal year 2017, the impact of the change in accounting policy that we expect to adopt effective the first fiscal quarter of 2017, our ability to further establish ourselves as a leader in cybersecurity, the market opportunity ahead of us, our ability to integrate our products with third-party services, and our plans with respect to our share repurchase authorization. There are a significant number of factors that could cause actual results to differ materially from statements made in this press release, including: market conditions; the possibility that share repurchases may be suspended or discontinued; fluctuations in the trading volume and market price of shares of our common stock; competing future investment opportunities and alternative uses of cash; our limited operating history; risks associated with managing our rapid growth, particularly outside of the United States; our limited experience with new product introductions and the risks associated with new products, including software bugs; the failure to timely develop and achieve market acceptance of new products as well as existing products and services; rapidly evolving technological developments in the market for network security products; and general market, political, economic and business conditions.

[0001327567-16-000057:8k_2_02:47]
Additional risks and uncertainties that could affect our financial results are included under the captions “Risk Factors” and “Management’s Discussion and Analysis of Financial Condition and Results of Operations” in our Quarterly Report on Form 10-Q filed with the SEC on May 27, 2016, which is available on our website at investors.paloaltonetworks.com and on the SEC’s website at www.sec.gov.

[0001327567-16-000057:8k_2_02:48]
6

[0001327567-16-000057:8k_2_02:49]
Additional information will also be set forth in other filings that we make with the SEC from time to time. All forward-looking statements in this press release are based on information available to us as of the date hereof, and we do not assume any obligation to update the forward-looking statements provided to reflect events that occur or circumstances that exist after the date on which they were made.

[0001327567-16-000057:8k_2_02:50]
Non-GAAP Financial Measures and Other Key Metrics

[0001327567-16-000057:8k_2_02:51]
Palo Alto Networks has provided in this press release financial information that has not been prepared in accordance with generally accepted accounting principles in the United States (GAAP). The company uses these non-GAAP financial measures and key metrics internally in analyzing its financial results and believes that the use of these non-GAAP financial measures and key metrics is useful to investors as an additional tool to evaluate ongoing operating results and trends and in comparing the company’s financial results with other companies in its industry, many of which present similar non-GAAP financial measures or key metrics.

[0001327567-16-000057:8k_2_02:52]
The presentation of these non-GAAP financial measures and key metrics are not meant to be considered in isolation or as a substitute for comparable GAAP financial measures, and should be read only in conjunction with the company’s consolidated financial statements prepared in accordance with GAAP. A reconciliation of the company’s historical non-GAAP financial measures and key metrics to their most directly comparable GAAP measures has been provided in the financial statement tables included in this press release, and investors are encouraged to review these reconciliations.

[0001327567-16-000057:8k_2_02:53]
Non-GAAP net income and net income per share, diluted. Palo Alto Networks defines non-GAAP net income as net income (loss) plus share-based compensation related charges including share-based payroll tax expense, acquisition related costs, amortization expense of acquired intangible assets, litigation related charges including legal settlements, non-cash interest expense related to the company’s convertible senior notes, and intellectual property restructuring related charges. The company also excludes from non-GAAP

[0001327567-16-000057:8k_2_02:54]
net income the foreign currency gains (losses) and tax effects associated with these items in order to provide a complete picture of the company’s recurring core business operating results. The company defines non-GAAP net income per share, diluted, as non-GAAP net income divided by the weighted average diluted shares outstanding after giving effect to the anti-dilutive impact of the company’s note hedge agreements, which reduces the potential economic dilution that otherwise would occur upon conversion of the company’s convertible senior notes. Under GAAP, the anti-dilutive impact of the note hedge is not reflected in diluted shares outstanding. Palo Alto Networks believes that excluding these items from non-GAAP net income and non-GAAP net income per share, diluted, provides management and investors with greater visibility into the underlying performance of the company’s core business operating results, meaning its operating performance excluding these items and, from time to time, other discrete charges that are infrequent in nature, over multiple periods.

[0001327567-16-000057:8k_2_02:55]
Billings. Palo Alto Networks defines billings as total revenue plus the change in deferred revenue during the period. The company considers billings to be a key metric used by management to manage the company’s business given the company’s hybrid-SaaS revenue model, and believes billings provides investors with an important indicator of the health and visibility of the company’s business because it includes services revenue, which is recognized ratably over the subscription period or the period in which the services are expected to be performed, as the case may be, and product revenue, which is recognized at the time of shipment, provided that all other revenue recognition criteria have been met. The company considers billings to be a useful metric for management and investors, particularly if sales of subscriptions continue to increase and the company experiences strong renewal rates for subscriptions and support and maintenance.

[0001327567-16-000057:8k_2_02:56]
Free cash flow. Palo Alto Networks defines free cash flow as cash provided by operating activities less purchases of property, equipment, and other assets. The company considers free cash flow to be a

[0001327567-16-000057:8k_2_02:57]
8

[0001327567-16-000057:8k_2_02:58]
profitability and liquidity measure that provides useful information to management and investors about the amount of cash generated by the business after necessary capital expenditures.

[0001327567-16-000057:8k_2_02:59]
Investors are cautioned that there are a number of limitations associated with the use of non-GAAP financial measures and key metrics as analytical tools. In particular, the billings metric reported by the company includes amounts that have not yet been recognized as revenue and free cash flow does not represent the total increase or decrease in our cash balance for the period. In addition, many of the adjustments to the company’s GAAP financial measures reflect the exclusion of items that are recurring and will be reflected in the company’s financial results for the foreseeable future, such as share-based compensation, which is an important part of Palo Alto Networks employees’ compensation and impacts their performance. Furthermore, these non-GAAP financial measures are not based on any standardized methodology prescribed by GAAP, and the components that Palo Alto Networks excludes in its calculation of non-GAAP financial measures may differ from the components that its peer companies exclude when they report their non-GAAP results of operations. Palo Alto Networks compensates for these limitations by providing specific information regarding the GAAP amounts excluded from these non-GAAP financial measures. In the future, the company may also exclude non-recurring expenses and other expenses that do not reflect the company’s core business operating results.

[0001327567-16-000057:8k_2_02:60]
About Palo Alto Networks

[0001327567-16-000057:8k_2_02:61]
Palo Alto Networks is the next-generation security company, leading a new era in cybersecurity by safely enabling applications and preventing cyber breaches for tens of thousands of organizations worldwide. Built with an innovative approach and highly differentiated cyberthreat prevention capabilities, our game-changing security platform delivers security far superior to legacy or point products, safely enables daily business operations, and protects an organization’s most valuable assets. Find out more at www.paloaltonetworks.com.

[0001327567-16-000057:8k_2_02:62]
Palo Alto Networks and the Palo Alto Networks logo are trademarks of Palo Alto Networks, Inc. in the United States and in jurisdictions throughout the world. All other trademarks, trade names or service marks used or mentioned herein belong to their respective owners.

[0001327567-16-000057:8k_2_02:63]
Gartner does not endorse any vendor, product or service depicted in its research publications, and does not advise technology users to select only those vendors with the highest ratings or other designation. Gartner research publications consist of the opinions of Gartner’s research organization and should not be construed as statements of fact. Gartner disclaims all warranties, expressed or implied, with respect to this research, including any warranties of merchantability or fitness for a particular purpose.

[0001327567-16-000057:8k_2_02:64]
Media Contact:

[0001327567-16-000057:8k_2_02:65]
Jennifer Jasper Smith

[0001327567-16-000057:8k_2_02:66]
Head of Corporate Communications

[0001327567-16-000057:8k_2_02:67]
Palo Alto Networks

[0001327567-16-000057:8k_2_02:68]
408-638-3280

[0001327567-16-000057:8k_2_02:69]
jjsmith@paloaltonetworks.com

[0001327567-16-000057:8k_2_02:70]
Investor Relations Contact:

[0001327567-16-000057:8k_2_02:71]
Kelsey Turcotte

[0001327567-16-000057:8k_2_02:72]
Vice President of Investor Relations

[0001327567-16-000057:8k_2_02:73]
Palo Alto Networks

[0001327567-16-000057:8k_2_02:74]
408-753-3872

[0001327567-16-000057:8k_2_02:75]
kturcotte@paloaltonetworks.com

[0001327567-16-000057:8k_2_02:76]
| Palo Alto Networks, Inc. |
| Preliminary Consolidated Statements of Operations |
| (In millions, except per share data) |
| (Unaudited) |
|  | Three Months Ended July 31, |  | Year Ended July 31, |
|  | 2016 |  | 2015 |  | 2016 |  | 2015 |
| Revenue: |  |  |  |  |  |  |  |
| Product | $ | 191.1 |  |  | $ | 154.1 |  |  | $ | 670.8 |  |  | $ | 492.7 |  |
| Services | 209.7 |  |  | 129.8 |  |  | 707.7 |  |  | 435.4 |  |
| Total revenue | 400.8 |  |  | 283.9 |  |  | 1,378.5 |  |  | 928.1 |  |
| Cost of revenue: |  |  |  |  |  |  |  |
| Product | 48.5 |  |  | 38.5 |  |  | 175.4 |  |  | 131.1 |  |
| Services | 53.2 |  |  | 35.8 |  |  | 194.6 |  |  | 120.4 |  |
| Total cost of revenue | 101.7 |  |  | 74.3 |  |  | 370.0 |  |  | 251.5 |  |
| Total gross profit | 299.1 |  |  | 209.6 |  |  | 1,008.5 |  |  | 676.6 |  |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | 76.5 |  |  | 53.1 |  |  | 284.2 |  |  | 185.8 |  |
| Sales and marketing | 228.1 |  |  | 162.4 |  |  | 776.0 |  |  | 522.7 |  |
| General and administrative | 39.9 |  |  | 28.6 |  |  | 138.4 |  |  | 101.6 |  |
| Total operating expenses | 344.5 |  |  | 244.1 |  |  | 1,198.6 |  |  | 810.1 |  |
| Operating loss | (45.4 | ) |  | (34.5 | ) |  | (190.1 | ) |  | (133.5 | ) |
| Interest expense | (6.0 | ) |  | (5.6 | ) |  | (23.4 | ) |  | (22.3 | ) |
| Other income (expense), net | 2.7 |  |  | (0.5 | ) |  | 8.4 |  |  | 0.2 |  |
| Loss before income taxes | (48.7 | ) |  | (40.6 | ) |  | (205.1 | ) |  | (155.6 | ) |
| Provision for income taxes | 5.8 |  |  | 5.4 |  |  | 20.8 |  |  | 9.4 |  |
| Net loss | $ | (54.5 | ) |  | $ | (46.0 | ) |  | $ | (225.9 | ) |  | $ | (165.0 | ) |
| Net loss per share, basic and diluted | $ | (0.61 | ) |  | $ | (0.55 | ) |  | $ | (2.59 | ) |  | $ | (2.02 | ) |
| Weighted-average shares used to compute net loss per share, basic and diluted | 88.9 |  |  | 84.0 |  |  | 87.1 |  |  | 81.6 |  |

[0001327567-16-000057:8k_2_02:77]
11

[0001327567-16-000057:8k_2_02:78]
| Palo Alto Networks, Inc. |
| Reconciliation of GAAP to Non-GAAP Financial Measures |
| (In millions, except per share amounts) |
| (Unaudited) |
|  | Three Months Ended |  | Year Ended |
|  | July 31 |  | July 31 |
|  | 2016 |  | 2015 |  | 2016 |  | 2015 |
| GAAP net loss | $ | (54.5 | ) |  | $ | (46.0 | ) |  | $ | (225.9 | ) |  | $ | (165.0 | ) |
| Share-based compensation related charges | 112.7 |  |  | 68.9 |  |  | 407.5 |  |  | 233.2 |  |
| Acquisition related costs | — |  |  | 0.4 |  |  | — |  |  | 0.7 |  |
| Amortization expense of acquired intangible assets | 2.0 |  |  | 2.0 |  |  | 8.3 |  |  | 7.0 |  |
| Litigation related charges | 3.1 |  |  | 3.1 |  |  | 12.3 |  |  | 12.3 |  |
| Non-cash interest expense related to convertible notes | 6.0 |  |  | 5.6 |  |  | 23.4 |  |  | 22.2 |  |
| Foreign currency (gain) loss associated with non-GAAP adjustments | (0.6 | ) |  | 0.9 |  |  | (0.3 | ) |  | 1.4 |  |
| Income tax and other tax adjustments related to the above | (22.5 | ) |  | (9.9 | ) |  | (72.7 | ) |  | (36.6 | ) |
| Non-GAAP net income | $ | 46.2 |  |  | $ | 25.0 |  |  | $ | 152.6 |  |  | $ | 75.2 |  |
| GAAP net loss per share, diluted | $ | (0.61 | ) |  | $ | (0.55 | ) |  | $ | (2.59 | ) |  | $ | (2.02 | ) |
| Share-based compensation related charges | 1.25 |  |  | 0.81 |  |  | 4.58 |  |  | 2.79 |  |
| Acquisition related costs | 0.00 |  |  | 0.00 |  |  | 0.00 |  |  | 0.01 |  |
| Amortization expense of acquired intangible assets | 0.02 |  |  | 0.02 |  |  | 0.10 |  |  | 0.09 |  |
| Litigation related charges | 0.03 |  |  | 0.04 |  |  | 0.14 |  |  | 0.15 |  |
| Non-cash interest expense related to convertible notes | 0.07 |  |  | 0.07 |  |  | 0.27 |  |  | 0.27 |  |
| Foreign currency (gain) loss associated with non-GAAP adjustments | (0.01 | ) |  | 0.01 |  |  | 0.00 |  |  | 0.02 |  |
| Income tax and other tax adjustments related to the above | (0.25 | ) |  | (0.12 | ) |  | (0.83 | ) |  | (0.45 | ) |
| Non-GAAP net income per share, diluted | $ | 0.50 |  |  | $ | 0.28 |  |  | $ | 1.67 |  |  | $ | 0.86 |  |
| GAAP weighted-average shares used to compute net loss per share, diluted | 88.9 |  |  | 84.0 |  |  | 87.1 |  |  | 81.6 |  |
| Weighted-average effect of potentially dilutive securities [a] | 2.8 |  |  | 6.1 |  |  | 4.2 |  |  | 5.8 |  |
| Non-GAAP weighted-average shares used to compute net income per share, diluted | 91.7 |  |  | 90.1 |  |  | 91.3 |  |  | 87.4 |  |
| Net cash provided by operating activities | $ | 187.5 |  |  | $ | 111.3 |  |  | $ | 658.1 |  |  | $ | 350.3 |  |
| Less: purchases of property, equipment, and other assets | 16.3 |  |  | 11.9 |  |  | 72.5 |  |  | 33.8 |  |
| Free cash flow | $ | 171.2 |  |  | $ | 99.4 |  |  | $ | 585.6 |  |  | $ | 316.5 |  |
| Net cash provided by (used in) investing activities | $ | 0.4 |  |  | $ | (198.4 | ) |  | $ | (338.9 | ) |  | $ | (679.0 | ) |
| Net cash provided by (used in) financing activities | $ | (3.5 | ) |  | $ | 8.8 |  |  | $ | 39.4 |  |  | $ | 50.7 |  |

[0001327567-16-000057:8k_2_02:79]
___________

[0001327567-16-000057:8k_2_02:80]
[a]    Non-GAAP net income per share, diluted, includes the potentially dilutive effect of employee equity incentive plan awards and convertible senior notes outstanding. In addition, non-GAAP net income per share, diluted, includes the anti-dilutive impact of the company’s note hedge agreements, which reduced the potentially dilutive effect of the convertible notes by 0.6 million shares and 1.4 million shares for the fiscal fourth quarter and fiscal year ended July 31, 2016, respectively, and 2.1 million shares and 1.0 million shares for the fiscal fourth quarter and fiscal year ended July 31, 2015, respectively.

[0001327567-16-000057:8k_2_02:81]
12

[0001327567-16-000057:8k_2_02:82]
| Palo Alto Networks, Inc. |
| Calculation of Billings |
| (In millions) |
| (Unaudited) |
|  | Three Months Ended |  | Year Ended |
|  | July 31 |  | July 31 |
|  | 2016 |  | 2015 |  | 2016 |  | 2015 |
| Total revenue | $ | 400.8 |  |  | $ | 283.9 |  |  | $ | 1,378.5 |  |  | $ | 928.1 |  |
| Add: change in total deferred revenue | 171.6 |  |  | 109.7 |  |  | 527.1 |  |  | 291.0 |  |
| Billings | $ | 572.4 |  |  | $ | 393.6 |  |  | $ | 1,905.6 |  |  | $ | 1,219.1 |  |

[0001327567-16-000057:8k_2_02:83]
13

[0001327567-16-000057:8k_2_02:84]
| Palo Alto Networks, Inc. |
| Preliminary Consolidated Balance Sheets |
| (In millions) |
| (Unaudited) |
|  | July 31, 2016 |  | July 31, 2015 |
| Assets |  |  |  |
| Current assets: |  |  |  |
| Cash and cash equivalents | $ | 734.4 |  |  | $ | 375.8 |  |
| Short-term investments | 551.2 |  |  | 413.2 |  |
| Accounts receivable, net | 348.7 |  |  | 212.4 |  |
| Prepaid expenses and other current assets | 84.8 |  |  | 72.6 |  |
| Total current assets | 1,719.1 |  |  | 1,074.0 |  |
| Property and equipment, net | 117.2 |  |  | 62.9 |  |
| Long-term investments | 652.8 |  |  | 538.8 |  |
| Goodwill | 163.5 |  |  | 163.5 |  |
| Intangible assets, net | 44.0 |  |  | 52.7 |  |
| Other assets | 64.6 |  |  | 73.3 |  |
| Total assets | $ | 2,761.2 |  |  | $ | 1,965.2 |  |
| Liabilities, temporary equity, and stockholders’ equity |  |  |  |
| Current liabilities: |  |  |  |
| Accounts payable | $ | 30.2 |  |  | $ | 13.2 |  |
| Accrued compensation | 73.5 |  |  | 79.8 |  |
| Accrued and other liabilities | 39.2 |  |  | 28.2 |  |
| Deferred revenue | 703.9 |  |  | 423.9 |  |
| Convertible senior notes, net | — |  |  | 487.1 |  |
| Total current liabilities | 846.8 |  |  | 1,032.2 |  |
| Convertible senior notes, net | 508.2 |  |  | — |  |
| Long-term deferred revenue | 536.9 |  |  | 289.8 |  |
| Other long-term liabilities | 79.4 |  |  | 67.4 |  |
| Temporary equity | — |  |  | 87.9 |  |
| Stockholders’ equity: |  |  |  |
| Preferred stock | — |  |  | — |  |
| Common stock and additional paid-in capital | 1,515.5 |  |  | 988.7 |  |
| Accumulated other comprehensive income (loss) | 1.0 |  |  | (0.1 | ) |
| Accumulated deficit | (726.6 | ) |  | (500.7 | ) |
| Total stockholders’ equity | 789.9 |  |  | 487.9 |  |
| Total liabilities, temporary equity, and stockholders’ equity | $ | 2,761.2 |  |  | $ | 1,965.2 |  |

[0001327567-16-000057:8k_2_02:85]
14

[0001327567-16-000057:8k_2_02:86]
| Palo Alto Networks, Inc. |
| Preliminary Consolidated Statements of Cash Flows |
| (In millions) |
| (Unaudited) |
|  | Year Ended July 31, |
|  | 2016 |  | 2015 |
| Cash flows from operating activities |  |  |  |
| Net loss | $ | (225.9 | ) |  | $ | (165.0 | ) |
| Adjustments to reconcile net loss to net cash provided by operating activities: |  |  |  |
| Share-based compensation for equity based awards | 392.8 |  |  | 221.3 |  |
| Depreciation and amortization | 42.8 |  |  | 28.9 |  |
| Amortization of investment premiums, net of accretion of purchase discounts | 3.0 |  |  | 3.2 |  |
| Amortization of debt discount and debt issuance costs | 23.4 |  |  | 22.3 |  |
| Excess tax benefit from share-based compensation arrangements | (0.5 | ) |  | (2.5 | ) |
| Changes in operating assets and liabilities, net of effects of acquisitions: |  |  |  |
| Accounts receivable, net | (136.4 | ) |  | (76.8 | ) |
| Prepaid expenses and other assets | 2.6 |  |  | (34.2 | ) |
| Accounts payable | 15.1 |  |  | (3.5 | ) |
| Accrued compensation | (6.3 | ) |  | 31.1 |  |
| Accrued and other liabilities | 20.4 |  |  | 34.5 |  |
| Deferred revenue | 527.1 |  |  | 291.0 |  |
| Net cash provided by operating activities | 658.1 |  |  | 350.3 |  |
| Cash flows from investing activities |  |  |  |
| Purchases of investments | (1,037.0 | ) |  | (987.6 | ) |
| Proceeds from sales of investments | 141.9 |  |  | 18.5 |  |
| Proceeds from maturities of investments | 628.7 |  |  | 339.0 |  |
| Business acquisitions, net of cash acquired | — |  |  | (15.1 | ) |
| Purchases of property, equipment, and other assets | (72.5 | ) |  | (33.8 | ) |
| Net cash used in investing activities | (338.9 | ) |  | (679.0 | ) |
| Cash flows from financing activities |  |  |  |
| Proceeds from sales of shares through employee equity incentive plans | 45.3 |  |  | 48.2 |  |
| Excess tax benefit from share-based compensation arrangements | 0.5 |  |  | 2.5 |  |
| Payment of deferred consideration related to prior year business acquisition | (6.4 | ) |  | — |  |
| Net cash provided by financing activities | 39.4 |  |  | 50.7 |  |
| Net increase (decrease) in cash and cash equivalents | 358.6 |  |  | (278.0 | ) |
| Cash and cash equivalents - beginning of period | 375.8 |  |  | 653.8 |  |
| Cash and cash equivalents - end of period | $ | 734.4 |  |  | $ | 375.8 |  |

[0001327567-16-000057:8k_2_02:87]
15
