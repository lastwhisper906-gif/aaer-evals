# PANW note change history — 0001327567-23-000006 → 0001327567-23-000014


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2023-05-24):
[0001327567-23-000014:note_history:1]
In order to reduce manufacturing lead times and plan for adequate supply, we enter into agreements with manufacturing partners and component suppliers to procure inventory based on our demand forecasts. The following table presents details of the aggregate future minimum or fixed purchase commitments under these arrangements, excluding obligations under contracts that we can cancel as of April 30, 2023 (in millions):
  (was, 2023-02-22, similarity 0.9856):
[0001327567-23-000006:note_history:1]
In order to reduce manufacturing lead times and plan for adequate supply, we enter into agreements with manufacturing partners and component suppliers to procure inventory based on our demand forecasts. The following table presents details of the aggregate future minimum or fixed purchase commitments under these arrangements, excluding obligations under contracts that we can cancel as of January 31, 2023 (in millions):

- changed (2023-05-24):
[0001327567-23-000014:note_history:2]
We have entered into various non-cancelable agreements with certain service providers, under which we are committed to minimum or fixed purchases. The following table presents details of the aggregate future non-cancelable purchase commitments under these agreements as of April 30, 2023 (in millions):
  (was, 2023-02-22, similarity 0.9799):
[0001327567-23-000006:note_history:2]
We have entered into various non-cancelable agreements with certain service providers, under which we are committed to minimum or fixed purchases. The following table presents details of the aggregate future non-cancelable purchase commitments under these agreements as of January 31, 2023 (in millions):

- added (2023-05-24):
[0001327567-23-000014:note_history:3]
To the extent there is a reasonable possibility that a loss exceeding amounts already recognized may be incurred and the amount of such additional loss would be material, we will either disclose the estimated additional loss or state that such an estimate cannot be made. As of April 30, 2023, we have not recorded any significant accruals for loss contingencies associated with such legal proceedings, determined that an unfavorable outcome is probable or reasonably possible, or determined that the amount or range of any possible loss is reasonably estimable.

- removed (2023-05-24):
[0001327567-23-000006:note_history:4]
To the extent there is a reasonable possibility that a loss exceeding amounts already recognized may be incurred and the amount of such additional loss would be material, we will either disclose the estimated additional loss or state that such an estimate cannot be made. As of January 31, 2023, we have not recorded any significant accruals for loss contingencies associated with such legal proceedings, determined that an unfavorable outcome is probable or reasonably possible, or determined that the amount or range of any possible loss is reasonably estimable.


## us-gaap:OrganizationConsolidationBasisOfPresentationBusinessDescriptionAndAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2023-05-24):
[0001327567-23-000014:note_history:5]
There have been no material changes to our significant accounting policies as of and for the nine months ended April 30, 2023, as compared to the significant accounting policies described in our Annual Report on Form 10-K for the fiscal year ended July 31, 2022.
  (was, 2023-02-22, similarity 0.9058):
[0001327567-23-000006:note_history:5]
There have been no material changes to our significant accounting policies as of and for the six months ended January 31, 2023, as compared to the significant accounting policies described in our Annual Report on Form 10-K for the fiscal year ended July 31, 2022.


## us-gaap:ConvertibleDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2023-05-24):
[0001327567-23-000014:note_history:6]
The following table sets forth the net carrying amount of our Notes (in millions):
  (was, 2023-02-22, similarity 0.8258):
[0001327567-23-000006:note_history:6]
The following table sets forth the components of the Notes (in millions):

- changed (2023-05-24):
[0001327567-23-000014:note_history:7]
|  | April 30, 2023 | July 31, 2022 |
|  | 2023 Notes |  | 2025 Notes |  | Total |  | 2023 Notes |  | 2025 Notes |  | Total |
| Principal | $ | 1,691.9 |  |  | $ | 1,999.4 |  |  | $ | 3,691.3 |  |  | $ | 1,691.9 |  |  | $ | 1,999.4 |  |  | $ | 3,691.3 |  |
| Less: debt discount and debt issuance costs, net of amortization | (0.5) |  |  | (8.7) |  |  | (9.2) |  |  | (2.6) |  |  | (11.9) |  |  | (14.5) |  |
| Net carrying amount | $ | 1,691.4 |  |  | $ | 1,990.7 |  |  | $ | 3,682.1 |  |  | $ | 1,689.3 |  |  | $ | 1,987.5 |  |  | $ | 3,676.8 |  |
  (was, 2023-02-22, similarity 0.933):
[0001327567-23-000006:note_history:7]
|  | January 31, 2023 | July 31, 2022 |
|  | 2023 Notes |  | 2025 Notes |  | Total |  | 2023 Notes |  | 2025 Notes |  | Total |
| Liability component: |  |  |  |  |  |  |  |  |  |  |  |
| Principal | $ | 1,691.9 |  |  | $ | 1,999.4 |  |  | $ | 3,691.3 |  |  | $ | 1,691.9 |  |  | $ | 1,999.4 |  |  | $ | 3,691.3 |  |
| Less: debt discount and debt issuance costs, net of amortization | (1.2) |  |  | (9.8) |  |  | (11.0) |  |  | (2.6) |  |  | (11.9) |  |  | (14.5) |  |
| Net carrying amount | $ | 1,690.7 |  |  | $ | 1,989.6 |  |  | $ | 3,680.3 |  |  | $ | 1,689.3 |  |  | $ | 1,987.5 |  |  | $ | 3,676.8 |  |


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2023-05-24):
[0001327567-23-000014:note_history:8]
On or after April 1, 2023, holders may surrender their 2023 Notes for conversion at any time prior to maturity, in accordance with the terms described above. Such conversion requests will settle upon maturity of the 2023 Notes. The sale price condition for the 2025 Notes was met during the fiscal quarter ended April 30, 2023, and as a result, holders may convert their 2025 Notes at any time during the fiscal quarter ending July 31, 2023. The net carrying amount of the Notes was classified as a current liability on our condensed consolidated balance sheet as of April 30, 2023.

- changed (2023-05-24):
[0001327567-23-000014:note_history:9]
The following table sets forth the net carrying amount of our Notes (in millions):
  (was, 2023-02-22, similarity 0.8258):
[0001327567-23-000006:note_history:9]
The following table sets forth the components of the Notes (in millions):

- changed (2023-05-24):
[0001327567-23-000014:note_history:10]
|  | April 30, 2023 | July 31, 2022 |
|  | 2023 Notes |  | 2025 Notes |  | Total |  | 2023 Notes |  | 2025 Notes |  | Total |
| Principal | $ | 1,691.9 |  |  | $ | 1,999.4 |  |  | $ | 3,691.3 |  |  | $ | 1,691.9 |  |  | $ | 1,999.4 |  |  | $ | 3,691.3 |  |
| Less: debt discount and debt issuance costs, net of amortization | (0.5) |  |  | (8.7) |  |  | (9.2) |  |  | (2.6) |  |  | (11.9) |  |  | (14.5) |  |
| Net carrying amount | $ | 1,691.4 |  |  | $ | 1,990.7 |  |  | $ | 3,682.1 |  |  | $ | 1,689.3 |  |  | $ | 1,987.5 |  |  | $ | 3,676.8 |  |
  (was, 2023-02-22, similarity 0.933):
[0001327567-23-000006:note_history:10]
|  | January 31, 2023 | July 31, 2022 |
|  | 2023 Notes |  | 2025 Notes |  | Total |  | 2023 Notes |  | 2025 Notes |  | Total |
| Liability component: |  |  |  |  |  |  |  |  |  |  |  |
| Principal | $ | 1,691.9 |  |  | $ | 1,999.4 |  |  | $ | 3,691.3 |  |  | $ | 1,691.9 |  |  | $ | 1,999.4 |  |  | $ | 3,691.3 |  |
| Less: debt discount and debt issuance costs, net of amortization | (1.2) |  |  | (9.8) |  |  | (11.0) |  |  | (2.6) |  |  | (11.9) |  |  | (14.5) |  |
| Net carrying amount | $ | 1,690.7 |  |  | $ | 1,989.6 |  |  | $ | 3,680.3 |  |  | $ | 1,689.3 |  |  | $ | 1,987.5 |  |  | $ | 3,676.8 |  |

- changed (2023-05-24):
[0001327567-23-000014:note_history:11]
The total estimated fair value of the 2023 Notes and 2025 Notes were $3.5 billion and $3.7 billion at April 30, 2023, respectively, and $3.2 billion and $3.5 billion at July 31, 2022, respectively. The fair value was determined based on the closing trading price per $100 of the applicable series of the Notes as of the last day of trading for the period. We consider the fair value of the Notes at April 30, 2023 and July 31, 2022 to be a Level 2 measurement. The fair value of the Notes is primarily affected by the trading price of our common stock and market interest rates.
  (was, 2023-02-22, similarity 0.9613):
[0001327567-23-000006:note_history:11]
The total estimated fair value of the 2023 Notes and 2025 Notes were $3.0 billion and $3.3 billion at January 31, 2023, respectively, and $3.2 billion and $3.5 billion at July 31, 2022, respectively. The fair value was determined based on the closing trading price per $100 of the applicable series of the Notes as of the last day of trading for the period. We consider the fair value of the Notes at January 31, 2023 and July 31, 2022 to be a Level 2 measurement. The fair value of the Notes is primarily affected by the trading price of our common stock and market interest rates.

- changed (2023-05-24):
[0001327567-23-000014:note_history:12]
|  | Three Months Ended April 30, |  | Nine Months Ended April 30, |
|  | 2023 |  | 2022 |  | 2023 |  | 2022 |
|  | 2023 Notes |  | 2025 Notes |  | Total |  | 2023 Notes |  | 2025 Notes |  | Total |  | 2023 Notes |  | 2025 Notes |  | Total |  | 2023 Notes |  | 2025 Notes |  | Total |
| Contractual interest expense | $ | 3.2 |  | $ | 1.8 |  | $ | 5.0 |  |  | $ | 3.2 |  | $ | 1.8 |  |  | $ | 5.0 |  | $ | 9.6 |  | $ | 5.6 |  | $ | 15.2 |  |  | $ | 9.5 |  | $ | 5.6 |  | $ | 15.1 |  |
| Amortization of debt issuance costs | 0.7 |  | 1.1 |  | 1.8 |  |  | 0.7 |  | 1.1 |  |  | 1.8 |  | 2.1 |  | 3.2 |  | 5.3 |  |  | 2.1 |  | 3.3 |  | 5.4 |  |
| Total interest expense | $ | 3.9 |  | $ | 2.9 |  | $ | 6.8 |  |  | $ | 3.9 |  | $ | 2.9 |  |  | $ | 6.8 |  | $ | 11.7 |  | $ | 8.8 |  | $ | 20.5 |  |  | $ | 11.6 |  | $ | 8.9 |  | $ | 20.5 |  |
| Effective interest rate | 0.9 | % |  | 0.6 | % |  |  |  | 0.9 | % |  | 0.6 | % |  |  |  | 0.9 | % |  | 0.6 | % |  |  |  | 0.9 | % |  | 0.6 | % |  |  |
  (was, 2023-02-22, similarity 0.9724):
[0001327567-23-000006:note_history:12]
|  | Three Months Ended January 31, |  | Six Months Ended January 31, |
|  | 2023 |  | 2022 |  | 2023 |  | 2022 |
|  | 2023 Notes |  | 2025 Notes |  | Total |  | 2023 Notes |  | 2025 Notes |  | Total |  | 2023 Notes |  | 2025 Notes |  | Total |  | 2023 Notes |  | 2025 Notes |  | Total |
| Contractual interest expense | $ | 3.2 |  | $ | 2.0 |  | $ | 5.2 |  |  | $ | 3.1 |  | $ | 1.9 |  |  | $ | 5.0 |  | $ | 6.4 |  | $ | 3.8 |  | $ | 10.2 |  |  | $ | 6.3 |  | $ | 3.8 |  | $ | 10.1 |  |
| Amortization of debt issuance costs | 0.7 |  | 1.0 |  | 1.7 |  |  | 0.7 |  | 1.1 |  |  | 1.8 |  | 1.4 |  | 2.1 |  | 3.5 |  |  | 1.4 |  | 2.2 |  | 3.6 |  |
| Total interest expense | $ | 3.9 |  | $ | 3.0 |  | $ | 6.9 |  |  | $ | 3.8 |  | $ | 3.0 |  |  | $ | 6.8 |  | $ | 7.8 |  | $ | 5.9 |  | $ | 13.7 |  |  | $ | 7.7 |  | $ | 6.0 |  | $ | 13.7 |  |
| Effective interest rate | 0.9 | % |  | 0.6 | % |  |  |  | 0.9 | % |  | 0.6 | % |  |  |  | 0.9 | % |  | 0.6 | % |  |  |  | 0.9 | % |  | 0.6 | % |  |  |

- changed (2023-05-24):
[0001327567-23-000014:note_history:13]
On September 4, 2018, we entered into a credit agreement (the “2018 Credit Agreement”) with certain institutional lenders that provides for a $400.0 million unsecured revolving credit facility (the “2018 Credit Facility”), with an option to increase the amount of the 2018 Credit Facility by up to an additional $350.0 million, subject to certain conditions. The 2018 Credit Facility expired in April 2023.
  (was, 2023-02-22, similarity 0.6499):
[0001327567-23-000006:note_history:13]
On September 4, 2018, we entered into a credit agreement (the “Credit Agreement”) with certain institutional lenders that provides for a $400.0 million unsecured revolving credit facility (the “Credit Facility”), with an option to increase the amount of the Credit Facility by up to an additional $350.0 million, subject to certain conditions. The Credit Facility matures on the earlier of (i) September 4, 2023 and (ii) the date that is 91 days prior to the stated maturity of our 2023 Notes if (a) any of the 2023 Notes are still outstanding and (b) our unrestricted cash and cash equivalents are less than the then outstanding principal amount of our 2023 Notes plus $400.0 million.

- added (2023-05-24):
[0001327567-23-000014:note_history:14]
On April 13, 2023, we entered into a new credit agreement (the “2023 Credit Agreement”) with certain institutional lenders that provides for a $400.0 million unsecured revolving credit facility (the “2023 Credit Facility”), with an option to increase the amount of the 2023 Credit Facility by up to an additional $350.0 million, subject to certain conditions. The 2023 Credit Facility matures on April 13, 2028.

- added (2023-05-24):
[0001327567-23-000014:note_history:15]
The borrowings under the 2023 Credit Facility bear interest, at our option, at a base rate plus a spread of 0.00% to 0.375%, or an adjusted term Secured Overnight Financing Rate (“SOFR”) plus a spread of 1.00% to 1.375%, in each case with such spread being determined based on our leverage ratio. We are obligated to pay an ongoing commitment fee on undrawn amounts at a rate of 0.090% to 0.150%, depending on our leverage ratio. The interest rates and commitment fees are also subject to upward and downward adjustments based on our progress towards the achievement of certain sustainability goals related to greenhouse gas emissions.

- changed (2023-05-24):
[0001327567-23-000014:note_history:16]
As of April 30, 2023, there were no amounts outstanding and we were in compliance with all covenants under the 2023 Credit Agreement.
  (was, 2023-02-22, similarity 0.9597):
[0001327567-23-000006:note_history:16]
As of January 31, 2023, there were no amounts outstanding and we were in compliance with all covenants under the Credit Agreement.

- removed (2023-05-24):
[0001327567-23-000006:note_history:17]
The sale price condition for the Notes was met during the fiscal quarter ended January 31, 2023, and as a result, holders may convert their Notes at any time during the fiscal quarter ending April 30, 2023. The net carrying amount of the Notes was classified as a current liability on our condensed consolidated balance sheet as of January 31, 2023.

- removed (2023-05-24):
[0001327567-23-000006:note_history:18]
The borrowings under the Credit Facility currently bear interest, at our option, at a base rate plus a spread of 0.00% to 0.75%, or an adjusted LIBO Rate plus a spread of 1.00% to 1.75%, in each case with such spread being determined based on our leverage ratio. We are obligated to pay an ongoing commitment fee on undrawn amounts at a rate of 0.125% to 0.250%, depending on our leverage ratio. In March 2021, the ICE Benchmark Administration, the administrator of LIBO Rate, announced that it will cease publication of the LIBO Rate by June 2023. Under the terms of our Credit Facility, in the event of the discontinuance of the LIBO Rate, a mutually agreed-upon alternative benchmark rate will be established to replace the LIBO Rate, which may include the Secured Overnight Financing Rate (“SOFR”). We do not anticipate that the discontinuance of the LIBO Rate will materially impact our liquidity or financial position.


## us-gaap:DebtSecuritiesAvailableForSaleTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2023-05-24):
[0001327567-23-000014:note_history:19]
The following tables summarize the amortized cost, unrealized gains and losses, and fair value of our available-for-sale debt securities as of April 30, 2023 and July 31, 2022 (in millions):
  (was, 2023-02-22, similarity 0.9779):
[0001327567-23-000006:note_history:19]
The following tables summarize the amortized cost, unrealized gains and losses, and fair value of our available-for-sale debt securities as of January 31, 2023 and July 31, 2022 (in millions):

- changed (2023-05-24):
[0001327567-23-000014:note_history:20]
|  | April 30, 2023 |
|  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Fair Value |
| Cash equivalents: |  |  |  |  |  |  |  |
| Commercial paper | 369.0 |  |  | — |  |  | — |  |  | 369.0 |  |
| Corporate debt securities | 21.0 |  |  | — |  |  | — |  |  | 21.0 |  |
| U.S. government and agency securities | 49.9 |  |  | — |  |  | — |  |  | 49.9 |  |
| Total available-for-sale cash equivalents | $ | 439.9 |  |  | $ | — |  |  | $ | — |  |  | $ | 439.9 |  |
| Investments: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 194.1 |  |  | $ | — |  |  | $ | — |  |  | $ | 194.1 |  |
| Commercial paper | 618.3 |  |  | 0.1 |  |  | (0.5) |  |  | 617.9 |  |
| Corporate debt securities | 2,975.3 |  |  | 6.7 |  |  | (17.5) |  |  | 2,964.5 |  |
| U.S. government and agency securities | 360.9 |  |  | 0.1 |  |  | (3.0) |  |  | 358.0 |  |
| Non-U.S. government and agency securities | 56.3 |  |  | — |  |  | (0.5) |  |  | 55.8 |  |
| Asset-backed securities | 486.2 |  |  | 0.8 |  |  | (2.2) |  |  | 484.8 |  |
| Total available-for-sale investments | $ | 4,691.1 |  |  | $ | 7.7 |  |  | $ | (23.7) |  |  | $ | 4,675.1 |  |
  (was, 2023-02-22, similarity 0.7888):
[0001327567-23-000006:note_history:20]
|  | January 31, 2023 |
|  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Fair Value |
| Cash equivalents: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 6.5 |  |  | $ | — |  |  | $ | — |  |  | $ | 6.5 |  |
| Commercial paper | 175.2 |  |  | — |  |  | — |  |  | 175.2 |  |
| Corporate debt securities | 24.5 |  |  | — |  |  | — |  |  | 24.5 |  |
| Total available-for-sale cash equivalents | $ | 206.2 |  |  | $ | — |  |  | $ | — |  |  | $ | 206.2 |  |
| Investments: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 210.8 |  |  | $ | — |  |  | $ | — |  |  | $ | 210.8 |  |
| Commercial paper | 631.4 |  |  | 0.2 |  |  | (0.7) |  |  | 630.9 |  |
| Corporate debt securities | 2,927.9 |  |  | 9.0 |  |  | (18.8) |  |  | 2,918.1 |  |
| U.S. government and agency securities | 518.4 |  |  | — |  |  | (5.3) |  |  | 513.1 |  |
| Non-U.S. government and agency securities | 68.8 |  |  | — |  |  | (0.7) |  |  | 68.1 |  |
| Asset-backed securities | 481.7 |  |  | 1.0 |  |  | (2.5) |  |  | 480.2 |  |
| Total available-for-sale investments | $ | 4,839.0 |  |  | $ | 10.2 |  |  | $ | (28.0) |  |  | $ | 4,821.2 |  |


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2023-05-24):
[0001327567-23-000014:note_history:21]
The following tables summarize the amortized cost, unrealized gains and losses, and fair value of our available-for-sale debt securities as of April 30, 2023 and July 31, 2022 (in millions):
  (was, 2023-02-22, similarity 0.9779):
[0001327567-23-000006:note_history:21]
The following tables summarize the amortized cost, unrealized gains and losses, and fair value of our available-for-sale debt securities as of January 31, 2023 and July 31, 2022 (in millions):

- changed (2023-05-24):
[0001327567-23-000014:note_history:22]
|  | April 30, 2023 |
|  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Fair Value |
| Cash equivalents: |  |  |  |  |  |  |  |
| Commercial paper | 369.0 |  |  | — |  |  | — |  |  | 369.0 |  |
| Corporate debt securities | 21.0 |  |  | — |  |  | — |  |  | 21.0 |  |
| U.S. government and agency securities | 49.9 |  |  | — |  |  | — |  |  | 49.9 |  |
| Total available-for-sale cash equivalents | $ | 439.9 |  |  | $ | — |  |  | $ | — |  |  | $ | 439.9 |  |
| Investments: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 194.1 |  |  | $ | — |  |  | $ | — |  |  | $ | 194.1 |  |
| Commercial paper | 618.3 |  |  | 0.1 |  |  | (0.5) |  |  | 617.9 |  |
| Corporate debt securities | 2,975.3 |  |  | 6.7 |  |  | (17.5) |  |  | 2,964.5 |  |
| U.S. government and agency securities | 360.9 |  |  | 0.1 |  |  | (3.0) |  |  | 358.0 |  |
| Non-U.S. government and agency securities | 56.3 |  |  | — |  |  | (0.5) |  |  | 55.8 |  |
| Asset-backed securities | 486.2 |  |  | 0.8 |  |  | (2.2) |  |  | 484.8 |  |
| Total available-for-sale investments | $ | 4,691.1 |  |  | $ | 7.7 |  |  | $ | (23.7) |  |  | $ | 4,675.1 |  |
  (was, 2023-02-22, similarity 0.7888):
[0001327567-23-000006:note_history:22]
|  | January 31, 2023 |
|  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Fair Value |
| Cash equivalents: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 6.5 |  |  | $ | — |  |  | $ | — |  |  | $ | 6.5 |  |
| Commercial paper | 175.2 |  |  | — |  |  | — |  |  | 175.2 |  |
| Corporate debt securities | 24.5 |  |  | — |  |  | — |  |  | 24.5 |  |
| Total available-for-sale cash equivalents | $ | 206.2 |  |  | $ | — |  |  | $ | — |  |  | $ | 206.2 |  |
| Investments: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 210.8 |  |  | $ | — |  |  | $ | — |  |  | $ | 210.8 |  |
| Commercial paper | 631.4 |  |  | 0.2 |  |  | (0.7) |  |  | 630.9 |  |
| Corporate debt securities | 2,927.9 |  |  | 9.0 |  |  | (18.8) |  |  | 2,918.1 |  |
| U.S. government and agency securities | 518.4 |  |  | — |  |  | (5.3) |  |  | 513.1 |  |
| Non-U.S. government and agency securities | 68.8 |  |  | — |  |  | (0.7) |  |  | 68.1 |  |
| Asset-backed securities | 481.7 |  |  | 1.0 |  |  | (2.5) |  |  | 480.2 |  |
| Total available-for-sale investments | $ | 4,839.0 |  |  | $ | 10.2 |  |  | $ | (28.0) |  |  | $ | 4,821.2 |  |

- added (2023-05-24):
[0001327567-23-000014:note_history:23]
As of April 30, 2023, the gross unrealized losses that have been in a continuous unrealized loss position for less than 12 months were $16.6 million, which were related to $2.7 billion of available-for-sale debt securities, and the gross unrealized losses that have been in a continuous unrealized loss position for more than 12 months were $7.1 million, which were related to $474.2 million of available-for-sale debt securities. As of July 31, 2022 the gross unrealized losses that have been in a continuous unrealized loss position for less than 12 months were $24.8 million, which were related to $2.0 billion of available-for-sale debt securities, and the gross unrealized losses that have been in a continuous unrealized loss position for more than 12 months were not material.

- changed (2023-05-24):
[0001327567-23-000014:note_history:24]
Unrealized losses related to our available-for-sale debt securities are due to interest rate fluctuations as opposed to credit quality. We do not intend to sell any of the securities in an unrealized loss position and it is not likely that we would be required to sell these securities before recovery of their amortized cost basis, which may be at maturity. We did not recognize any credit losses related to our available-for-sale debt securities during the three and nine months ended April 30, 2023 and 2022.
  (was, 2023-02-22, similarity 0.9811):
[0001327567-23-000006:note_history:24]
Unrealized losses related to our available-for-sale debt securities are due to interest rate fluctuations as opposed to credit quality. We do not intend to sell any of the securities in an unrealized loss position and it is not likely that we would be required to sell these securities before recovery of their amortized cost basis, which may be at maturity. We did not recognize any credit losses related to our available-for-sale debt securities during the three and six months ended January 31, 2023 and 2022.

- changed (2023-05-24):
[0001327567-23-000014:note_history:25]
The following table summarizes the amortized cost and fair value of our available-for-sale debt securities as of April 30, 2023, by contractual years-to-maturity (in millions):
  (was, 2023-02-22, similarity 0.9766):
[0001327567-23-000006:note_history:25]
The following table summarizes the amortized cost and fair value of our available-for-sale debt securities as of January 31, 2023, by contractual years-to-maturity (in millions):

- changed (2023-05-24):
[0001327567-23-000014:note_history:26]
|  | Amortized Cost |  | Fair Value |
| Due within one year | $ | 2,414.2 |  |  | $ | 2,405.2 |  |
| Due between one and three years | 2,457.0 |  |  | 2,449.7 |  |
| Due between three and five years | 215.1 |  |  | 215.2 |  |
| Due between five and ten years | 36.7 |  |  | 36.8 |  |
| Due after ten years | 8.0 |  |  | 8.1 |  |
| Total | $ | 5,131.0 |  |  | $ | 5,115.0 |  |
  (was, 2023-02-22, similarity 0.9146):
[0001327567-23-000006:note_history:26]
|  | Amortized Cost |  | Fair Value |
| Due within one year | $ | 2,217.6 |  |  | $ | 2,206.8 |  |
| Due between one and three years | 2,658.4 |  |  | 2,651.4 |  |
| Due between three to five years | 123.8 |  |  | 123.5 |  |
| Due between five to ten years | 45.4 |  |  | 45.7 |  |
| Total | $ | 5,045.2 |  |  | $ | 5,027.4 |  |

- added (2023-05-24):
[0001327567-23-000014:note_history:27]
Marketable equity securities consist of money market funds and are included in cash and cash equivalents on our condensed consolidated balance sheets. As of April 30, 2023 and July 31, 2022, the carrying values of our marketable equity securities were $879.5 million and $1.2 billion, respectively. There were no unrealized gains or losses recognized for these securities during the three and nine months ended April 30, 2023 and 2022.

- removed (2023-05-24):
[0001327567-23-000006:note_history:28]
As of January 31, 2023, the gross unrealized losses that have been in a continuous unrealized loss position for less than 12 months were $17.2 million, which were related to $2.5 billion of available-for-sale debt securities, and the gross unrealized losses that have been in a continuous unrealized loss position for more than 12 months were $10.8 million, which were related to $571.6 million of available-for-sale debt securities. As of July 31, 2022 the gross unrealized losses that have been in a continuous unrealized loss position for less than 12 months were $24.8 million, which were related to $2.0 billion of available-for-sale debt securities, and the gross unrealized losses that have been in a continuous unrealized loss position for more than 12 months were not material.

- removed (2023-05-24):
[0001327567-23-000006:note_history:29]
Marketable equity securities consist of money market funds and are included in cash and cash equivalents on our condensed consolidated balance sheets. As of January 31, 2023 and July 31, 2022, the carrying values of our marketable equity securities were $655.9 million and $1.2 billion, respectively. There were no unrealized gains or losses recognized for these securities during the three and six months ended January 31, 2023 and 2022.


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2023-05-24):
[0001327567-23-000014:note_history:30]
|  | Three Months Ended April 30, |  | Nine Months Ended April 30, |
|  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Revenue: |  |  |  |  |  |  |  |
| Americas |  |  |  |  |  |  |  |
| United States | $ | 1,105.2 |  |  | $ | 887.2 |  |  | $ | 3,153.8 |  |  | $ | 2,557.5 |  |
| Other Americas | 74.0 |  |  | 61.5 |  |  | 213.1 |  |  | 173.8 |  |
| Total Americas | 1,179.2 |  |  | 948.7 |  |  | 3,366.9 |  |  | 2,731.3 |  |
| Europe, the Middle East, and Africa (“EMEA”) | 332.1 |  |  | 269.5 |  |  | 981.5 |  |  | 755.5 |  |
| Asia Pacific and Japan (“APAC”) | 209.6 |  |  | 168.5 |  |  | 591.0 |  |  | 464.2 |  |
| Total revenue | $ | 1,720.9 |  |  | $ | 1,386.7 |  |  | $ | 4,939.4 |  |  | $ | 3,951.0 |  |
  (was, 2023-02-22, similarity 0.9563):
[0001327567-23-000006:note_history:30]
|  | Three Months Ended January 31, |  | Six Months Ended January 31, |
|  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Revenue: |  |  |  |  |  |  |  |
| Americas |  |  |  |  |  |  |  |
| United States | $ | 1,042.3 |  |  | $ | 858.6 |  |  | $ | 2,048.6 |  |  | $ | 1,670.3 |  |
| Other Americas | 74.7 |  |  | 57.3 |  |  | 139.1 |  |  | 112.3 |  |
| Total Americas | 1,117.0 |  |  | 915.9 |  |  | 2,187.7 |  |  | 1,782.6 |  |
| Europe, the Middle East, and Africa (“EMEA”) | 341.5 |  |  | 252.2 |  |  | 649.4 |  |  | 486.0 |  |
| Asia Pacific and Japan (“APAC”) | 196.6 |  |  | 148.8 |  |  | 381.4 |  |  | 295.7 |  |
| Total revenue | $ | 1,655.1 |  |  | $ | 1,316.9 |  |  | $ | 3,218.5 |  |  | $ | 2,564.3 |  |

- added (2023-05-24):
[0001327567-23-000014:note_history:31]
|  | Three Months Ended April 30, |  | Nine Months Ended April 30, |
|  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Revenue: |  |  |  |  |  |  |  |
| Product | $ | 388.1 |  |  | $ | 351.5 |  |  | $ | 1,071.0 |  |  | $ | 955.0 |  |
| Subscription and support |  |  |  |  |  |  |  |
| Subscription | 838.1 |  |  | 639.8 |  |  | 2,417.5 |  |  | 1,836.6 |  |
| Support | 494.7 |  |  | 395.4 |  |  | 1,450.9 |  |  | 1,159.4 |  |
| Total subscription and support | 1,332.8 |  |  | 1,035.2 |  |  | 3,868.4 |  |  | 2,996.0 |  |
| Total revenue | $ | 1,720.9 |  |  | $ | 1,386.7 |  |  | $ | 4,939.4 |  |  | $ | 3,951.0 |  |

- changed (2023-05-24):
[0001327567-23-000014:note_history:32]
During the nine months ended April 30, 2023 and 2022, we recognized approximately $2.9 billion and $2.2 billion of revenue pertaining to amounts that were deferred as of July 31, 2022 and 2021, respectively.
  (was, 2023-02-22, similarity 0.965):
[0001327567-23-000006:note_history:32]
During the six months ended January 31, 2023 and 2022, we recognized approximately $2.1 billion and $1.6 billion of revenue pertaining to amounts that were deferred as of July 31, 2022 and 2021, respectively.

- changed (2023-05-24):
[0001327567-23-000014:note_history:33]
Remaining performance obligations were $9.2 billion as of April 30, 2023, of which we expect to recognize as revenue approximately $4.5 billion over the next 12 months and the remainder thereafter.
  (was, 2023-02-22, similarity 0.9786):
[0001327567-23-000006:note_history:33]
Remaining performance obligations were $8.8 billion as of January 31, 2023, of which we expect to recognize as revenue approximately $4.4 billion over the next 12 months and the remainder thereafter.

- removed (2023-05-24):
[0001327567-23-000006:note_history:34]
|  | Three Months Ended January 31, |  | Six Months Ended January 31, |
|  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Revenue: |  |  |  |  |  |  |  |
| Product | $ | 352.9 |  |  | $ | 308.0 |  |  | $ | 682.9 |  |  | $ | 603.5 |  |
| Subscription and support |  |  |  |  |  |  |  |
| Subscription | 815.4 |  |  | 618.0 |  |  | 1,579.4 |  |  | 1,196.8 |  |
| Support | 486.8 |  |  | 390.9 |  |  | 956.2 |  |  | 764.0 |  |
| Total subscription and support | 1,302.2 |  |  | 1,008.9 |  |  | 2,535.6 |  |  | 1,960.8 |  |
| Total revenue | $ | 1,655.1 |  |  | $ | 1,316.9 |  |  | $ | 3,218.5 |  |  | $ | 2,564.3 |  |
