# PANW notes — 0001327567-23-000014


## us-gaap:OrganizationConsolidationBasisOfPresentationBusinessDescriptionAndAccountingPoliciesTextBlock

[0001327567-23-000014:notes:1]
[same as prior period, unchanged from 0001327567-23-000006:notes:1]

[0001327567-23-000014:notes:2]
[same as prior period, unchanged from 0001327567-23-000006:notes:2]

[0001327567-23-000014:notes:3]
[same as prior period, unchanged from 0001327567-23-000006:notes:3]

[0001327567-23-000014:notes:4]
[same as prior period, unchanged from 0001327567-23-000006:notes:4]

[0001327567-23-000014:notes:5]
[same as prior period, unchanged from 0001327567-23-000006:notes:5]

[0001327567-23-000014:notes:6]
[same as prior period, unchanged from 0001327567-23-000006:notes:6]

[0001327567-23-000014:notes:7]
[same as prior period, unchanged from 0001327567-23-000006:notes:7]

[0001327567-23-000014:notes:8]
[same as prior period, unchanged from 0001327567-23-000006:notes:8]

[0001327567-23-000014:notes:9]
There have been no material changes to our significant accounting policies as of and for the nine months ended April 30, 2023, as compared to the significant accounting policies described in our Annual Report on Form 10-K for the fiscal year ended July 31, 2022.

[0001327567-23-000014:notes:10]
[same as prior period, unchanged from 0001327567-23-000006:notes:10]

[0001327567-23-000014:notes:11]
[same as prior period, unchanged from 0001327567-23-000006:notes:11]


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001327567-23-000014:notes:12]
[same as prior period, unchanged from 0001327567-23-000006:notes:12]

[0001327567-23-000014:notes:13]
[same as prior period, unchanged from 0001327567-23-000006:notes:13]

[0001327567-23-000014:notes:14]
|  | Three Months Ended April 30, |  | Nine Months Ended April 30, |
|  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Revenue: |  |  |  |  |  |  |  |
| Americas |  |  |  |  |  |  |  |
| United States | $ | 1,105.2 |  |  | $ | 887.2 |  |  | $ | 3,153.8 |  |  | $ | 2,557.5 |  |
| Other Americas | 74.0 |  |  | 61.5 |  |  | 213.1 |  |  | 173.8 |  |
| Total Americas | 1,179.2 |  |  | 948.7 |  |  | 3,366.9 |  |  | 2,731.3 |  |
| Europe, the Middle East, and Africa (“EMEA”) | 332.1 |  |  | 269.5 |  |  | 981.5 |  |  | 755.5 |  |
| Asia Pacific and Japan (“APAC”) | 209.6 |  |  | 168.5 |  |  | 591.0 |  |  | 464.2 |  |
| Total revenue | $ | 1,720.9 |  |  | $ | 1,386.7 |  |  | $ | 4,939.4 |  |  | $ | 3,951.0 |  |

[0001327567-23-000014:notes:15]
[same as prior period, unchanged from 0001327567-23-000006:notes:15]

[0001327567-23-000014:notes:16]
|  | Three Months Ended April 30, |  | Nine Months Ended April 30, |
|  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Revenue: |  |  |  |  |  |  |  |
| Product | $ | 388.1 |  |  | $ | 351.5 |  |  | $ | 1,071.0 |  |  | $ | 955.0 |  |
| Subscription and support |  |  |  |  |  |  |  |
| Subscription | 838.1 |  |  | 639.8 |  |  | 2,417.5 |  |  | 1,836.6 |  |
| Support | 494.7 |  |  | 395.4 |  |  | 1,450.9 |  |  | 1,159.4 |  |
| Total subscription and support | 1,332.8 |  |  | 1,035.2 |  |  | 3,868.4 |  |  | 2,996.0 |  |
| Total revenue | $ | 1,720.9 |  |  | $ | 1,386.7 |  |  | $ | 4,939.4 |  |  | $ | 3,951.0 |  |

[0001327567-23-000014:notes:17]
[same as prior period, unchanged from 0001327567-23-000006:notes:17]

[0001327567-23-000014:notes:18]
During the nine months ended April 30, 2023 and 2022, we recognized approximately $2.9 billion and $2.2 billion of revenue pertaining to amounts that were deferred as of July 31, 2022 and 2021, respectively.

[0001327567-23-000014:notes:19]
[same as prior period, unchanged from 0001327567-23-000006:notes:19]

[0001327567-23-000014:notes:20]
Remaining performance obligations were $9.2 billion as of April 30, 2023, of which we expect to recognize as revenue approximately $4.5 billion over the next 12 months and the remainder thereafter.


## us-gaap:FairValueDisclosuresTextBlock

[0001327567-23-000014:notes:21]
Fair Value Measurements 
The following table presents our financial assets and liabilities measured at fair value on a recurring basis as of April 30, 2023 and July 31, 2022 (in millions):

[0001327567-23-000014:notes:22]
|  |  | April 30, 2023 |  | July 31, 2022 |
|  |  | Level 1 |  | Level 2 |  | Level 3 |  | Total |  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| Cash equivalents: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 879.5 |  |  | $ | — |  |  | $ | — |  |  | $ | 879.5 |  |  | $ | 1,205.2 |  |  | $ | — |  |  | $ | — |  |  | $ | 1,205.2 |  |
| Certificates of deposit |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 155.3 |  |  | — |  |  | 155.3 |  |
| Commercial paper |  | — |  |  | 369.0 |  |  | — |  |  | 369.0 |  |  | — |  |  | 69.1 |  |  | — |  |  | 69.1 |  |
| Corporate debt securities |  | — |  |  | 21.0 |  |  | — |  |  | 21.0 |  |  | — |  |  | 19.5 |  |  | — |  |  | 19.5 |  |
| U.S. government and agency securities |  | — |  |  | 49.9 |  |  | — |  |  | 49.9 |  |  | — |  |  | 10.0 |  |  | — |  |  | 10.0 |  |
| Non-U.S. government and agency securities |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 5.1 |  |  | — |  |  | 5.1 |  |
| Total cash equivalents |  | 879.5 |  |  | 439.9 |  |  | — |  |  | 1,319.4 |  |  | 1,205.2 |  |  | 259.0 |  |  | — |  |  | 1,464.2 |  |
| Short-term investments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Certificates of deposit |  | — |  |  | 194.1 |  |  | — |  |  | 194.1 |  |  | — |  |  | 116.4 |  |  | — |  |  | 116.4 |  |
| Commercial paper |  | — |  |  | 617.9 |  |  | — |  |  | 617.9 |  |  | — |  |  | 79.0 |  |  | — |  |  | 79.0 |  |
| Corporate debt securities |  | — |  |  | 824.5 |  |  | — |  |  | 824.5 |  |  | — |  |  | 505.0 |  |  | — |  |  | 505.0 |  |
| U.S. government and agency securities |  | — |  |  | 324.4 |  |  | — |  |  | 324.4 |  |  | — |  |  | 798.2 |  |  | — |  |  | 798.2 |  |
| Non-U.S. government and agency securities |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 17.4 |  |  | — |  |  | 17.4 |  |
| Asset-backed securities |  | — |  |  | 4.4 |  |  | — |  |  | 4.4 |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Total short-term investments |  | — |  |  | 1,965.3 |  |  | — |  |  | 1,965.3 |  |  | — |  |  | 1,516.0 |  |  | — |  |  | 1,516.0 |  |

[0001327567-23-000014:notes:23]
|  |  | April 30, 2023 |  | July 31, 2022 |
|  |  | Level 1 |  | Level 2 |  | Level 3 |  | Total |  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| Long-term investments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Corporate debt securities |  | — |  |  | 2,140.0 |  |  | — |  |  | 2,140.0 |  |  | — |  |  | 761.2 |  |  | — |  |  | 761.2 |  |
| U.S. government and agency securities |  | — |  |  | 33.6 |  |  | — |  |  | 33.6 |  |  | — |  |  | 118.2 |  |  | — |  |  | 118.2 |  |
| Non-U.S. government and agency securities |  | — |  |  | 55.8 |  |  | — |  |  | 55.8 |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Asset-backed securities |  | — |  |  | 480.4 |  |  | — |  |  | 480.4 |  |  | — |  |  | 172.5 |  |  | — |  |  | 172.5 |  |
| Total long-term investments |  | — |  |  | 2,709.8 |  |  | — |  |  | 2,709.8 |  |  | — |  |  | 1,051.9 |  |  | — |  |  | 1,051.9 |  |
| Prepaid expenses and other current assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency forward contracts |  | — |  |  | 22.5 |  |  | — |  |  | 22.5 |  |  | — |  |  | 2.4 |  |  | — |  |  | 2.4 |  |
| Total prepaid expenses and other current assets |  | — |  |  | 22.5 |  |  | — |  |  | 22.5 |  |  | — |  |  | 2.4 |  |  | — |  |  | 2.4 |  |
| Other assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency forward contracts |  | — |  |  | 5.4 |  |  | — |  |  | 5.4 |  |  | — |  |  | 0.7 |  |  | — |  |  | 0.7 |  |
| Total other assets |  | — |  |  | 5.4 |  |  | — |  |  | 5.4 |  |  | — |  |  | 0.7 |  |  | — |  |  | 0.7 |  |
| Total assets measured at fair value |  | $ | 879.5 |  |  | $ | 5,142.9 |  |  | $ | — |  |  | $ | 6,022.4 |  |  | $ | 1,205.2 |  |  | $ | 2,830.0 |  |  | $ | — |  |  | $ | 4,035.2 |  |
| Accrued and other liabilities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency forward contracts |  | $ | — |  |  | $ | 18.8 |  |  | $ | — |  |  | $ | 18.8 |  |  | $ | — |  |  | $ | 32.4 |  |  | $ | — |  |  | $ | 32.4 |  |
| Total accrued and other liabilities |  | — |  |  | 18.8 |  |  | — |  |  | 18.8 |  |  | — |  |  | 32.4 |  |  | — |  |  | 32.4 |  |
| Other long-term liabilities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency forward contracts |  | — |  |  | 4.4 |  |  | — |  |  | 4.4 |  |  | — |  |  | 0.8 |  |  | — |  |  | 0.8 |  |
| Total other long-term liabilities |  | — |  |  | 4.4 |  |  | — |  |  | 4.4 |  |  | — |  |  | 0.8 |  |  | — |  |  | 0.8 |  |
| Total liabilities measured at fair value |  | $ | — |  |  | $ | 23.2 |  |  | $ | — |  |  | $ | 23.2 |  |  | $ | — |  |  | $ | 33.2 |  |  | $ | — |  |  | $ | 33.2 |  |

[0001327567-23-000014:notes:24]
Refer to Note 9. Debt for the carrying amount and estimated fair value of our convertible senior notes as of April 30, 2023 and July 31, 2022.


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock

[0001327567-23-000014:notes:25]
Cash Equivalents and Investments
Available-for-sale Debt Securities

[0001327567-23-000014:notes:26]
The following tables summarize the amortized cost, unrealized gains and losses, and fair value of our available-for-sale debt securities as of April 30, 2023 and July 31, 2022 (in millions):

[0001327567-23-000014:notes:27]
|  | April 30, 2023 |
|  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Fair Value |
| Cash equivalents: |  |  |  |  |  |  |  |
| Commercial paper | 369.0 |  |  | — |  |  | — |  |  | 369.0 |  |
| Corporate debt securities | 21.0 |  |  | — |  |  | — |  |  | 21.0 |  |
| U.S. government and agency securities | 49.9 |  |  | — |  |  | — |  |  | 49.9 |  |
| Total available-for-sale cash equivalents | $ | 439.9 |  |  | $ | — |  |  | $ | — |  |  | $ | 439.9 |  |
| Investments: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 194.1 |  |  | $ | — |  |  | $ | — |  |  | $ | 194.1 |  |
| Commercial paper | 618.3 |  |  | 0.1 |  |  | (0.5) |  |  | 617.9 |  |
| Corporate debt securities | 2,975.3 |  |  | 6.7 |  |  | (17.5) |  |  | 2,964.5 |  |
| U.S. government and agency securities | 360.9 |  |  | 0.1 |  |  | (3.0) |  |  | 358.0 |  |
| Non-U.S. government and agency securities | 56.3 |  |  | — |  |  | (0.5) |  |  | 55.8 |  |
| Asset-backed securities | 486.2 |  |  | 0.8 |  |  | (2.2) |  |  | 484.8 |  |
| Total available-for-sale investments | $ | 4,691.1 |  |  | $ | 7.7 |  |  | $ | (23.7) |  |  | $ | 4,675.1 |  |

[0001327567-23-000014:notes:28]
|  | July 31, 2022 |
|  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Fair Value |
| Cash equivalents: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 155.3 |  |  | $ | — |  |  | $ | — |  |  | $ | 155.3 |  |
| Commercial paper | 69.1 |  |  | — |  |  | — |  |  | 69.1 |  |
| Corporate debt securities | 19.5 |  |  | — |  |  | — |  |  | 19.5 |  |
| U.S. government and agency securities | 10.0 |  |  | — |  |  | — |  |  | 10.0 |  |
| Non-U.S. government and agency securities | 5.0 |  |  | 0.1 |  |  | — |  |  | 5.1 |  |
| Total available-for-sale cash equivalents | $ | 258.9 |  |  | $ | 0.1 |  |  | $ | — |  |  | $ | 259.0 |  |
| Investments: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 116.5 |  |  | $ | — |  |  | $ | (0.1) |  |  | $ | 116.4 |  |
| Commercial paper | 79.1 |  |  | — |  |  | (0.1) |  |  | 79.0 |  |
| Corporate debt securities | 1,276.8 |  |  | 1.3 |  |  | (11.9) |  |  | 1,266.2 |  |
| U.S. government and agency securities | 928.1 |  |  | 0.1 |  |  | (11.8) |  |  | 916.4 |  |
| Non-U.S. government and agency securities | 17.6 |  |  | — |  |  | (0.2) |  |  | 17.4 |  |
| Asset-backed securities | $ | 173.4 |  |  | $ | 0.2 |  |  | $ | (1.1) |  |  | $ | 172.5 |  |
| Total available-for-sale investments | $ | 2,591.5 |  |  | $ | 1.6 |  |  | $ | (25.2) |  |  | $ | 2,567.9 |  |

[0001327567-23-000014:notes:29]
As of April 30, 2023, the gross unrealized losses that have been in a continuous unrealized loss position for less than 12 months were $16.6 million, which were related to $2.7 billion of available-for-sale debt securities, and the gross unrealized losses that have been in a continuous unrealized loss position for more than 12 months were $7.1 million, which were related to $474.2 million of available-for-sale debt securities. As of July 31, 2022 the gross unrealized losses that have been in a continuous unrealized loss position for less than 12 months were $24.8 million, which were related to $2.0 billion of available-for-sale debt securities, and the gross unrealized losses that have been in a continuous unrealized loss position for more than 12 months were not material.

[0001327567-23-000014:notes:30]
Unrealized losses related to our available-for-sale debt securities are due to interest rate fluctuations as opposed to credit quality. We do not intend to sell any of the securities in an unrealized loss position and it is not likely that we would be required to sell these securities before recovery of their amortized cost basis, which may be at maturity. We did not recognize any credit losses related to our available-for-sale debt securities during the three and nine months ended April 30, 2023 and 2022.

[0001327567-23-000014:notes:31]
The following table summarizes the amortized cost and fair value of our available-for-sale debt securities as of April 30, 2023, by contractual years-to-maturity (in millions):

[0001327567-23-000014:notes:32]
|  | Amortized Cost |  | Fair Value |
| Due within one year | $ | 2,414.2 |  |  | $ | 2,405.2 |  |
| Due between one and three years | 2,457.0 |  |  | 2,449.7 |  |
| Due between three and five years | 215.1 |  |  | 215.2 |  |
| Due between five and ten years | 36.7 |  |  | 36.8 |  |
| Due after ten years | 8.0 |  |  | 8.1 |  |
| Total | $ | 5,131.0 |  |  | $ | 5,115.0 |  |

[0001327567-23-000014:notes:33]
Marketable Equity Securities

[0001327567-23-000014:notes:34]
Marketable equity securities consist of money market funds and are included in cash and cash equivalents on our condensed consolidated balance sheets. As of April 30, 2023 and July 31, 2022, the carrying values of our marketable equity securities were $879.5 million and $1.2 billion, respectively. There were no unrealized gains or losses recognized for these securities during the three and nine months ended April 30, 2023 and 2022.


## us-gaap:FinancingReceivablesTextBlock

[0001327567-23-000014:notes:35]
Financing ReceivablesThe following table summarizes our short-term and long-term financing receivables as of April 30, 2023 and July 31, 2022 (in millions):

[0001327567-23-000014:notes:36]
|  |  | April 30, 2023 |  | July 31, 2022 |
| Short-term financing receivables, gross |  | $ | 248.3 |  |  | $ | 112.6 |  |
| Allowance for credit losses |  | (3.1) |  |  | (1.3) |  |
| Short-term financing receivables, net |  | $ | 245.2 |  |  | $ | 111.3 |  |
| Long-term financing receivables, gross |  | $ | 395.0 |  |  | $ | 194.6 |  |
| Allowance for credit losses |  | (4.6) |  |  | (2.5) |  |
| Long-term financing receivables, net |  | $ | 390.4 |  |  | $ | 192.1 |  |

[0001327567-23-000014:notes:37]
There was no significant activity in allowance for credit losses during the three and nine months ended April 30, 2023 and 2022. Past due amounts on financing receivables were not material as of April 30, 2023 and July 31, 2022.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001327567-23-000014:notes:38]
[same as prior period, unchanged from 0001327567-23-000006:notes:38]

[0001327567-23-000014:notes:39]
As of April 30, 2023 and July 31, 2022, the total notional amount of our outstanding foreign currency forward contracts was $1.1 billion and $856.9 million, respectively. Refer to Note 3. Fair Value Measurements for the fair value of our derivative instruments as reported on our condensed consolidated balance sheets as of April 30, 2023 and July 31, 2022.
As of April 30, 2023, unrealized gains and losses in accumulated other comprehensive income (“AOCI”) related to our cash flow hedges were $2.6 million net gain, of which $4.7 million gains are expected to be recognized into earnings within the next 12 months. As of July 31, 2022, unrealized gains and losses in AOCI related to our cash flow hedges were $24.8 million net loss, of which $22.0 million losses are expected to be recognized into earnings within the next 12 months.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001327567-23-000014:notes:40]
[same as prior period, unchanged from 0001327567-23-000006:notes:40]

[0001327567-23-000014:notes:41]
[same as prior period, unchanged from 0001327567-23-000006:notes:41]

[0001327567-23-000014:notes:42]
[same as prior period, unchanged from 0001327567-23-000006:notes:42]

[0001327567-23-000014:notes:43]
As part of the acquisition, we issued replacement equity awards, which included 0.2 million shares of our restricted common stock. The total fair value of the replacement equity awards was $48.6 million, of which the portion attributable to services performed prior to the acquisition date was allocated to purchase consideration. The remaining fair value was allocated to future services and will be expensed over the remaining service periods as share-based compensation.

[0001327567-23-000014:notes:44]
[same as prior period, unchanged from 0001327567-23-000006:notes:44]

[0001327567-23-000014:notes:45]
[same as prior period, unchanged from 0001327567-23-000006:notes:45]

[0001327567-23-000014:notes:46]
[same as prior period, unchanged from 0001327567-23-000006:notes:46]

[0001327567-23-000014:notes:47]
[same as prior period, unchanged from 0001327567-23-000006:notes:47]

[0001327567-23-000014:notes:48]
[same as prior period, unchanged from 0001327567-23-000006:notes:48]


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001327567-23-000014:notes:49]
[same as prior period, unchanged from 0001327567-23-000006:notes:49]

[0001327567-23-000014:notes:50]
The following table presents details of our goodwill during the nine months ended April 30, 2023 (in millions):

[0001327567-23-000014:notes:51]
|  | Amount |
| Balance as of July 31, 2022 | $ | 2,747.7 |  |
| Goodwill acquired | 179.1 |  |
| Balance as of April 30, 2023 | $ | 2,926.8 |  |

[0001327567-23-000014:notes:52]
[same as prior period, unchanged from 0001327567-23-000006:notes:52]

[0001327567-23-000014:notes:53]
The following table presents details of our purchased intangible assets as of April 30, 2023 and July 31, 2022 (in millions):

[0001327567-23-000014:notes:54]
|  | April 30, 2023 |  | July 31, 2022 |
|  | Gross Carrying Amount |  | Accumulated Amortization |  | Net Carrying Amount |  | Gross Carrying Amount |  | Accumulated Amortization |  | Net Carrying Amount |
| Intangible assets subject to amortization: |  |  |  |  |  |  |  |  |  |  |  |
| Developed technology | $ | 633.2 |  |  | $ | (410.1) |  |  | $ | 223.1 |  |  | $ | 600.7 |  |  | $ | (347.9) |  |  | $ | 252.8 |  |
| Customer relationships | 172.7 |  |  | (68.5) |  |  | 104.2 |  |  | 172.7 |  |  | (52.2) |  |  | 120.5 |  |
| Acquired intellectual property | 14.6 |  |  | (5.8) |  |  | 8.8 |  |  | 11.3 |  |  | (4.8) |  |  | 6.5 |  |
| Trade name and trademarks | 9.4 |  |  | (9.4) |  |  | — |  |  | 9.4 |  |  | (9.4) |  |  | — |  |
| Other | 0.9 |  |  | (0.3) |  |  | 0.6 |  |  | 0.9 |  |  | (0.1) |  |  | 0.8 |  |
| Total intangible assets subject to amortization | 830.8 |  |  | (494.1) |  |  | 336.7 |  |  | 795.0 |  |  | (414.4) |  |  | 380.6 |  |
| Intangible assets not subject to amortization: |  |  |  |  |  |  |  |  |  |  |  |
| In-process research and development | 3.9 |  |  | — |  |  | 3.9 |  |  | 3.9 |  | — |  |  | 3.9 |  |
| Total purchased intangible assets | $ | 834.7 |  |  | $ | (494.1) |  |  | $ | 340.6 |  |  | $ | 798.9 |  |  | $ | (414.4) |  |  | $ | 384.5 |  |

[0001327567-23-000014:notes:55]
We recognized amortization expense of $25.8 million and $79.7 million for the three and nine months ended April 30, 2023, respectively, and $31.8 million and $95.3 million for the three and nine months ended April 30, 2022, respectively.

[0001327567-23-000014:notes:56]
The following table summarizes estimated future amortization expense of our intangible assets subject to amortization as of April 30, 2023 (in millions):

[0001327567-23-000014:notes:57]
|  |  |  | Fiscal years ending July 31, |
|  | Total |  | Remaining 2023 |  | 2024 |  | 2025 |  | 2026 |  | 2027 |  | 2028 and Thereafter |
| Future amortization expense | $ | 336.7 |  |  | $ | 25.2 |  |  | $ | 97.9 |  |  | $ | 84.2 |  |  | $ | 62.4 |  |  | $ | 35.3 |  |  | $ | 31.7 |  |


## us-gaap:DebtDisclosureTextBlock

[0001327567-23-000014:notes:58]
Debt
Convertible Senior Notes

[0001327567-23-000014:notes:59]
In July 2018, we issued $1.7 billion aggregate principal amount of 0.75% Convertible Senior Notes due 2023 (the “2023 Notes”) and in June 2020, we issued $2.0 billion aggregate principal amount of 0.375% Convertible Senior Notes due 2025 (the “2025 Notes,” and together with the 2023 Notes, the “Notes”). The 2023 Notes bear interest at a fixed rate of 0.75% per year, payable semi-annually in arrears on January 1 and July 1 of each year, beginning on January 1, 2019. The 2025 Notes bear interest at a fixed rate of 0.375% per year, payable semi-annually in arrears on June 1 and December 1 of each year, beginning on December 1, 2020. Each series of the convertible notes is governed by an indenture between us, as the issuer, and U.S. Bank National Association, as Trustee (individually, each an “Indenture,” and together, the “Indentures”). The Notes of each series are unsecured, unsubordinated obligations and the applicable Indenture governing each series of Notes does not contain any financial covenants or restrictions on the payments of dividends, the incurrence of indebtedness, or the issuance or repurchase of securities by us or any of our subsidiaries. The 2023 Notes and the 2025 Notes mature on July 1, 2023 and June 1, 2025, respectively. We cannot redeem the 2023 Notes prior to maturity. We may redeem for cash all or any portion of the 2025 Notes, at our option, on or after June 5, 2023, and prior to the 31st scheduled trading day immediately preceding the maturity date if the last reported sale price of our common stock has been at least 130% of the conversion price then in effect for at least 20 trading days during any 30 consecutive trading day period ending on and including the trading day preceding the date on which we provide notice of redemption. The redemption will be at a price equal to 100% of the principal amount of the 2025 Notes and adjusted for interest. If we call any or all of the 2025 Notes for redemption, holders may convert such 2025 Notes called for redemption at any time prior to the close of business on the second scheduled trading day immediately preceding the redemption date.

[0001327567-23-000014:notes:60]
The following table presents details of our Notes (number of shares in millions):

[0001327567-23-000014:notes:61]
|  | Conversion Rate per $1,000 Principal |  | Initial Conversion Price |  | Convertible Date |  | Initial Number of Shares |
| 2023 Notes | 11.2635 |  |  | $ | 88.78 |  |  | April 1, 2023 |  | 19.1 |  |
| 2025 Notes | 10.0806 |  |  | $ | 99.20 |  |  | March 1, 2025 |  | 20.1 |  |

[0001327567-23-000014:notes:62]
Holders of the Notes may surrender their Notes for conversion at their option at any time prior to the close of business on the business day immediately preceding their respective convertible dates only under the following circumstances:

[0001327567-23-000014:notes:63]
•during any fiscal quarter commencing after the fiscal quarters ending on October 31, 2018 and October 31, 2020 for the 2023 Notes and the 2025 Notes, respectively (and only during such fiscal quarter), if the last reported sale price of our common stock for at least 20 trading days (whether or not consecutive) during a period of 30 consecutive trading days ending on the last trading day of the immediately preceding fiscal quarter is greater than or equal to 130% of the applicable conversion price for the respective Notes on each applicable trading day (the “sale price condition”);

[0001327567-23-000014:notes:64]
•during the five business day period after any five consecutive trading day period (the “measurement period”) in which the trading price per $1,000 principal amount of the applicable series of Notes for each trading day of the measurement period was less than 98% of the product of the last reported sale price of our common stock and the applicable conversion rate for the respective Notes on each such trading day; or

[0001327567-23-000014:notes:65]
•upon the occurrence of specified corporate events.

[0001327567-23-000014:notes:66]
On or after the respective convertible date, holders may surrender all or any portion of their Notes for conversion at any time prior to the close of business on the second scheduled trading day immediately preceding the applicable maturity date regardless of the foregoing conditions, and such conversions will be settled upon the applicable maturity date. Upon conversion, holders of the Notes of a series will receive cash equal to the aggregate principal amount of the Notes of such series to be converted, and, at our election, cash and/or shares of our common stock for any amounts in excess of the aggregate principal amount of the Notes of such series being converted.

[0001327567-23-000014:notes:67]
The conversion price will be subject to adjustment in some events. Holders of the Notes of a series who convert their Notes of such series in connection with certain corporate events that constitute a “make-whole fundamental change” under the applicable Indenture are, under certain circumstances, entitled to an increase in the conversion rate for such series of Notes. Additionally, upon the occurrence of a corporate event that constitutes a “fundamental change” under the applicable Indenture, holders of the Notes of such series may require us to repurchase for cash all or a portion of the Notes of such series at a repurchase price equal to 100% of the principal amount of the Notes of such series plus accrued and unpaid interest to, but excluding, the fundamental change repurchase date.

[0001327567-23-000014:notes:68]
On or after April 1, 2023, holders may surrender their 2023 Notes for conversion at any time prior to maturity, in accordance with the terms described above. Such conversion requests will settle upon maturity of the 2023 Notes. The sale price condition for the 2025 Notes was met during the fiscal quarter ended April 30, 2023, and as a result, holders may convert their 2025 Notes at any time during the fiscal quarter ending July 31, 2023. The net carrying amount of the Notes was classified as a current liability on our condensed consolidated balance sheet as of April 30, 2023.

[0001327567-23-000014:notes:69]
The following table sets forth the net carrying amount of our Notes (in millions):

[0001327567-23-000014:notes:70]
|  | April 30, 2023 | July 31, 2022 |
|  | 2023 Notes |  | 2025 Notes |  | Total |  | 2023 Notes |  | 2025 Notes |  | Total |
| Principal | $ | 1,691.9 |  |  | $ | 1,999.4 |  |  | $ | 3,691.3 |  |  | $ | 1,691.9 |  |  | $ | 1,999.4 |  |  | $ | 3,691.3 |  |
| Less: debt discount and debt issuance costs, net of amortization | (0.5) |  |  | (8.7) |  |  | (9.2) |  |  | (2.6) |  |  | (11.9) |  |  | (14.5) |  |
| Net carrying amount | $ | 1,691.4 |  |  | $ | 1,990.7 |  |  | $ | 3,682.1 |  |  | $ | 1,689.3 |  |  | $ | 1,987.5 |  |  | $ | 3,676.8 |  |

[0001327567-23-000014:notes:71]
The total estimated fair value of the 2023 Notes and 2025 Notes were $3.5 billion and $3.7 billion at April 30, 2023, respectively, and $3.2 billion and $3.5 billion at July 31, 2022, respectively. The fair value was determined based on the closing trading price per $100 of the applicable series of the Notes as of the last day of trading for the period. We consider the fair value of the Notes at April 30, 2023 and July 31, 2022 to be a Level 2 measurement. The fair value of the Notes is primarily affected by the trading price of our common stock and market interest rates.

[0001327567-23-000014:notes:72]
The following table sets forth interest expense recognized related to the Notes (dollars in millions):

[0001327567-23-000014:notes:73]
|  | Three Months Ended April 30, |  | Nine Months Ended April 30, |
|  | 2023 |  | 2022 |  | 2023 |  | 2022 |
|  | 2023 Notes |  | 2025 Notes |  | Total |  | 2023 Notes |  | 2025 Notes |  | Total |  | 2023 Notes |  | 2025 Notes |  | Total |  | 2023 Notes |  | 2025 Notes |  | Total |
| Contractual interest expense | $ | 3.2 |  | $ | 1.8 |  | $ | 5.0 |  |  | $ | 3.2 |  | $ | 1.8 |  |  | $ | 5.0 |  | $ | 9.6 |  | $ | 5.6 |  | $ | 15.2 |  |  | $ | 9.5 |  | $ | 5.6 |  | $ | 15.1 |  |
| Amortization of debt issuance costs | 0.7 |  | 1.1 |  | 1.8 |  |  | 0.7 |  | 1.1 |  |  | 1.8 |  | 2.1 |  | 3.2 |  | 5.3 |  |  | 2.1 |  | 3.3 |  | 5.4 |  |
| Total interest expense | $ | 3.9 |  | $ | 2.9 |  | $ | 6.8 |  |  | $ | 3.9 |  | $ | 2.9 |  |  | $ | 6.8 |  | $ | 11.7 |  | $ | 8.8 |  | $ | 20.5 |  |  | $ | 11.6 |  | $ | 8.9 |  | $ | 20.5 |  |
| Effective interest rate | 0.9 | % |  | 0.6 | % |  |  |  | 0.9 | % |  | 0.6 | % |  |  |  | 0.9 | % |  | 0.6 | % |  |  |  | 0.9 | % |  | 0.6 | % |  |  |

[0001327567-23-000014:notes:74]
Note Hedges

[0001327567-23-000014:notes:75]
To minimize the impact of potential economic dilution upon conversion of our Notes, we entered into separate convertible note hedge transactions (the “2023 Note Hedges,” with respect to the 2023 Notes, the “2025 Note Hedges,” with respect to the 2025 Notes, and the 2023 Notes Hedges together with 2025 Note Hedges, the “Note Hedges”) with respect to our common stock concurrent with the issuance of each series of the Notes.

[0001327567-23-000014:notes:76]
The following table presents details of our Note Hedges (in millions):

[0001327567-23-000014:notes:77]
|  | Initial Number of Shares |  | Aggregate Purchase |
| 2023 Note Hedges | 19.1 |  |  | $ | 332.0 |  |
| 2025 Note Hedges | 20.1 |  |  | $ | 370.8 |  |

[0001327567-23-000014:notes:78]
The Note Hedges cover shares of our common stock at a strike price per share that corresponds to the initial applicable conversion price of the applicable series of the Notes, which are also subject to adjustment, and are exercisable upon conversion of the applicable series of the Notes. The Note Hedges will expire upon maturity of the applicable series of the Notes. The Note Hedges are separate transactions and are not part of the terms of the applicable series of the Notes. Holders of the Notes of either series will not have any rights with respect to the Note Hedges. Any shares of our common stock receivable by us under the Note Hedges are excluded from the calculation of diluted earnings per share as they are antidilutive. The aggregate amounts paid for the Note Hedges are included in additional paid-in capital on our condensed consolidated balance sheets.

[0001327567-23-000014:notes:79]
Warrants

[0001327567-23-000014:notes:80]
Separately, but concurrently with the issuance of each series of our Notes, we entered into transactions whereby we sold warrants (the “2023 Warrants,” with respect to the 2023 Notes, the “2025 Warrants,” with respect to the 2025 Notes, and the 2023 Warrants together with the 2025 Warrants, the “Warrants”) to acquire shares of our common stock, subject to anti-dilution adjustments. The 2023 Warrants and 2025 Warrants are exercisable beginning October 2023 and September 2025, respectively.

[0001327567-23-000014:notes:81]
The following table presents details of our Warrants (in millions, except per share data):

[0001327567-23-000014:notes:82]
|  | Initial Number of Shares |  | Strike Price per Share |  | Aggregate Proceeds |
| 2023 Warrants | 19.1 |  |  | $ | 139.27 |  |  | $ | 145.4 |  |
| 2025 Warrants | 20.1 |  |  | $ | 136.16 |  |  | $ | 202.8 |  |

[0001327567-23-000014:notes:83]
The shares issuable under the Warrants will be included in the calculation of diluted earnings per share when the average market value per share of our common stock for the reporting period exceeds the applicable strike price for such series of Warrants. The Warrants are separate transactions and are not part of either series of Notes or Note Hedges and are not remeasured through earnings each reporting period. Holders of the Notes of either series will not have any rights with respect to the Warrants. The aggregate proceeds received from the sale of the Warrants are included in additional paid-in capital on our condensed consolidated balance sheets.

[0001327567-23-000014:notes:84]
Revolving Credit Facility

[0001327567-23-000014:notes:85]
On September 4, 2018, we entered into a credit agreement (the “2018 Credit Agreement”) with certain institutional lenders that provides for a $400.0 million unsecured revolving credit facility (the “2018 Credit Facility”), with an option to increase the amount of the 2018 Credit Facility by up to an additional $350.0 million, subject to certain conditions. The 2018 Credit Facility expired in April 2023.

[0001327567-23-000014:notes:86]
On April 13, 2023, we entered into a new credit agreement (the “2023 Credit Agreement”) with certain institutional lenders that provides for a $400.0 million unsecured revolving credit facility (the “2023 Credit Facility”), with an option to increase the amount of the 2023 Credit Facility by up to an additional $350.0 million, subject to certain conditions. The 2023 Credit Facility matures on April 13, 2028.

[0001327567-23-000014:notes:87]
The borrowings under the 2023 Credit Facility bear interest, at our option, at a base rate plus a spread of 0.00% to 0.375%, or an adjusted term Secured Overnight Financing Rate (“SOFR”) plus a spread of 1.00% to 1.375%, in each case with such spread being determined based on our leverage ratio. We are obligated to pay an ongoing commitment fee on undrawn amounts at a rate of 0.090% to 0.150%, depending on our leverage ratio. The interest rates and commitment fees are also subject to upward and downward adjustments based on our progress towards the achievement of certain sustainability goals related to greenhouse gas emissions.

[0001327567-23-000014:notes:88]
As of April 30, 2023, there were no amounts outstanding and we were in compliance with all covenants under the 2023 Credit Agreement.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001327567-23-000014:notes:89]
Commitments and Contingencies
Purchase Commitments

[0001327567-23-000014:notes:90]
Manufacturing Purchase Commitments

[0001327567-23-000014:notes:91]
In order to reduce manufacturing lead times and plan for adequate supply, we enter into agreements with manufacturing partners and component suppliers to procure inventory based on our demand forecasts. The following table presents details of the aggregate future minimum or fixed purchase commitments under these arrangements, excluding obligations under contracts that we can cancel as of April 30, 2023 (in millions):

[0001327567-23-000014:notes:92]
|  |  |  | Fiscal years ending July 31, |
|  | Total |  | Remaining 2023 |  | 2024 |  | 2025 |  | 2026 |  | 2027 |  | 2028 and Thereafter |
| Manufacturing purchase commitments | $ | 182.6 |  |  | $ | 67.0 |  |  | $ | 40.6 |  |  | $ | 35.0 |  |  | $ | 40.0 |  |  | $ | — |  |  | $ | — |  |

[0001327567-23-000014:notes:93]
Other Purchase Commitments

[0001327567-23-000014:notes:94]
We have entered into various non-cancelable agreements with certain service providers, under which we are committed to minimum or fixed purchases. The following table presents details of the aggregate future non-cancelable purchase commitments under these agreements as of April 30, 2023 (in millions):

[0001327567-23-000014:notes:95]
|  |  |  | Fiscal years ending July 31, |
|  | Total |  | Remaining 2023 |  | 2024 |  | 2025 |  | 2026 |  | 2027 |  | 2028 and Thereafter |
| Other purchase commitments | $ | 1,634.5 |  |  | $ | 55.9 |  |  | $ | 159.8 |  |  | $ | 416.7 |  |  | $ | 517.5 |  |  | $ | 483.8 |  |  | $ | 0.8 |  |

[0001327567-23-000014:notes:96]
Additionally, we have a $157.5 million minimum purchase commitment with a service provider through September 2027 with no specified annual commitments.

[0001327567-23-000014:notes:97]
Litigation

[0001327567-23-000014:notes:98]
We are subject to legal proceedings, claims, and litigation arising in the ordinary course of business, including intellectual property litigation. Such matters are subject to many uncertainties and outcomes are not predictable with assurance. We accrue for contingencies when we believe that a loss is probable and that we can reasonably estimate the amount of any such loss.

[0001327567-23-000014:notes:99]
To the extent there is a reasonable possibility that a loss exceeding amounts already recognized may be incurred and the amount of such additional loss would be material, we will either disclose the estimated additional loss or state that such an estimate cannot be made. As of April 30, 2023, we have not recorded any significant accruals for loss contingencies associated with such legal proceedings, determined that an unfavorable outcome is probable or reasonably possible, or determined that the amount or range of any possible loss is reasonably estimable.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001327567-23-000014:notes:100]
[same as prior period, unchanged from 0001327567-23-000006:notes:99]

[0001327567-23-000014:notes:101]
[same as prior period, unchanged from 0001327567-23-000006:notes:100]

[0001327567-23-000014:notes:102]
[same as prior period, unchanged from 0001327567-23-000006:notes:101]

[0001327567-23-000014:notes:103]
|  |  |  | Nine Months Ended April 30, |
|  |  |  |  |  | 2023 |  | 2022 |
| Number of shares repurchased |  |  |  |  | 1.8 |  |  | 3.1 |  |
| Weighted average price per share (1) |  |  |  |  | $ | 138.65 |  |  | $ | 177.93 |  |
| Aggregate purchase price (1) |  |  |  |  | $ | 250.0 |  |  | $ | 550.0 |  |

[0001327567-23-000014:notes:104]
[same as prior period, unchanged from 0001327567-23-000006:notes:103]

[0001327567-23-000014:notes:105]
[same as prior period, unchanged from 0001327567-23-000006:notes:104]

[0001327567-23-000014:notes:106]
We did not repurchase shares of our common stock during the three months ended April 30, 2023 and 2022. In addition to the share repurchase activity summarized in the table above, during the nine months ended April 30, 2023, we paid $22.7 million related to share repurchases of our common stock that were not settled as of July 31, 2022.

[0001327567-23-000014:notes:107]
As of April 30, 2023, $750.0 million remained available for future share repurchases under our current repurchase authorization. The total price of the shares repurchased and related transaction costs are reflected as a reduction to common stock and additional paid-in capital on our condensed consolidated balance sheets.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001327567-23-000014:notes:108]
[same as prior period, unchanged from 0001327567-23-000006:notes:107]

[0001327567-23-000014:notes:109]
The following table summarizes the RSU and PSU activity under our stock plans during the nine months ended April 30, 2023 (in millions, except per share amounts):

[0001327567-23-000014:notes:110]
|  | RSUs Outstanding |  | PSUs Outstanding |
|  | Number of Shares |  | Weighted-Average Grant-Date Fair Value Per Share |  |  |  | Aggregate Intrinsic Value |  | Number of Shares |  | Weighted-Average Grant-Date Fair Value Per Share |  |  |  | Aggregate Intrinsic Value |
| Balance—July 31, 2022 | 14.8 |  |  | $ | 115.51 |  |  |  |  | $ | 2,456.9 |  |  | 3.1 |  |  | $ | 106.38 |  |  |  |  | $ | 513.7 |  |
| Granted(1) | 5.3 |  |  | $ | 164.53 |  |  |  |  |  |  | 2.8 |  |  | $ | 140.61 |  |  |  |  |  |
| Vested | (5.2) |  |  | $ | 107.45 |  |  |  |  |  |  | (1.2) |  |  | $ | 113.91 |  |  |  |  |  |
| Forfeited | (1.2) |  |  | $ | 124.37 |  |  |  |  |  |  | (0.3) |  |  | $ | 136.96 |  |  |  |  |  |
| Balance—April 30, 2023 | 13.7 |  |  | $ | 137.16 |  |  |  |  | $ | 2,492.5 |  |  | 4.4 |  |  | $ | 124.24 |  |  |  |  | $ | 798.2 |  |

[0001327567-23-000014:notes:111]
[same as prior period, unchanged from 0001327567-23-000006:notes:110]

[0001327567-23-000014:notes:112]
[same as prior period, unchanged from 0001327567-23-000006:notes:111]

[0001327567-23-000014:notes:113]
Our PSUs generally vest over a period of one to four years from the date of grant. The actual number of PSUs earned and eligible to vest is determined based on the level of achievement against certain performance conditions, such as revenue growth, billings and operating margin, or individual performance for the fiscal year; market conditions; or a combination of performance and market conditions for certain awards.

[0001327567-23-000014:notes:114]
During the nine months ended April 30, 2023, we granted 0.9 million shares of PSUs with both service and market conditions to certain employees. The market conditions are satisfied when the price of our common stock is equal to or exceeds stock price targets of $233.33, $266.67, $300.00, and $333.33 based on the average closing price for 30 consecutive trading days during the three- or four-year period following the date of grant. To the extent that the market conditions have been met, one-fourth of the awards will vest on each anniversary date of the grant date, subject to continued service. As of April 30, 2023, the stock price targets for these PSU awards have not been met.

[0001327567-23-000014:notes:115]
During the nine months ended April 30, 2023 and 2022, we granted 1.6 million and 0.6 million shares of PSUs, respectively, which contain service, performance and market conditions, to certain employees. The service conditions are satisfied over a period of one to three years. The performance conditions are based on revenue growth or billing growth. The market condition is measured based on our total shareholder return (“TSR”) relative to the TSR of the companies listed in the Standard & Poor’s 500 index. As of April 30, 2023, we have approved 2.3 million shares of PSUs, which will be granted upon the performance condition being established during the next two years.

[0001327567-23-000014:notes:116]
[same as prior period, unchanged from 0001327567-23-000006:notes:115]

[0001327567-23-000014:notes:117]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 30, |  | April 30, |
|  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Volatility | 38.3% |  | 39.1% - 41.1% |  | 38.3% - 44.8% |  | 36.0% - 41.1% |
| Expected term (in years) | 4.0 |  | 1.4 - 2.4 |  | 1.0 - 4.0 |  | 1.4 - 3.0 |
| Dividend yield | 0.0 | % |  | 0.0 | % |  | 0.0 | % |  | 0.0 | % |
| Risk-free interest rate | 4.1% |  | 1.5% - 2.0% |  | 3.2% - 4.1% |  | 0.2% - 2.0% |
| Grant-date fair value per share | $91.77 - $122.94 |  | $256.95 - $260.71 |  | $91.77 - $280.41 |  | $137.16 - $260.71 |

[0001327567-23-000014:notes:118]
[same as prior period, unchanged from 0001327567-23-000006:notes:117]

[0001327567-23-000014:notes:119]
We have granted PSOs with both service and market conditions to certain executives. The market conditions were achieved when certain stock price targets were met. As of April 30, 2023, all stock price targets for our outstanding PSOs have been satisfied. One-fourth of the PSOs will vest on each anniversary date of the grant date, subject to continued service. The contractual term for the PSOs outstanding ranges from seven to seven and a half years following the date of grant in fiscal year 2018 and 2019.

[0001327567-23-000014:notes:120]
The following table summarizes the PSO activity under our stock plans during the nine months ended April 30, 2023 (in millions, except per share amounts):

[0001327567-23-000014:notes:121]
|  |  |  | PSOs Outstanding |
|  |  |  |  |  |  |  |  |  | Number of Shares |  | Weighted-Average Exercise Price Per Share |  | Weighted-Average Remaining Contractual Term(Years) |  | Aggregate Intrinsic Value |
| Balance—July 31, 2022 |  |  |  |  |  |  |  |  | 8.0 |  |  | $ | 64.85 |  |  | 3.2 |  | $ | 809.3 |  |
| Exercised |  |  |  |  |  |  |  |  | (0.6) |  |  | $ | 62.08 |  |  |  |  |  |
| Balance—April 30, 2023 |  |  |  |  |  |  |  |  | 7.4 |  |  | $ | 65.09 |  |  | 2.4 |  | $ | 862.3 |  |
| Exercisable—April 30, 2023 |  |  |  |  |  |  |  |  | 7.4 |  |  | $ | 65.09 |  |  | 2.4 |  | $ | 862.3 |  |

[0001327567-23-000014:notes:122]
[same as prior period, unchanged from 0001327567-23-000006:notes:121]

[0001327567-23-000014:notes:123]
[same as prior period, unchanged from 0001327567-23-000006:notes:122]

[0001327567-23-000014:notes:124]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 30, |  | April 30, |
|  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Cost of product revenue | $ | 2.5 |  |  | $ | 2.3 |  |  | $ | 7.5 |  |  | $ | 6.9 |  |
| Cost of subscription and support revenue | 32.0 |  |  | 27.4 |  |  | 91.5 |  |  | 81.8 |  |
| Research and development | 125.4 |  |  | 112.7 |  |  | 373.1 |  |  | 361.9 |  |
| Sales and marketing | 80.5 |  |  | 75.7 |  |  | 256.3 |  |  | 228.8 |  |
| General and administrative | 36.8 |  |  | 29.2 |  |  | 104.7 |  |  | 93.3 |  |
| Total share-based compensation | $ | 277.2 |  |  | $ | 247.3 |  |  | $ | 833.1 |  |  | $ | 772.7 |  |

[0001327567-23-000014:notes:125]
As of April 30, 2023, total compensation cost related to unvested share-based awards not yet recognized was $2.1 billion. This cost is expected to be amortized over a weighted-average period of approximately 2.5 years.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001327567-23-000014:notes:126]
Income TaxesFor the three and nine months ended April 30, 2023, our provision for income taxes reflected an effective tax rate of 17.7% and 15.1%, respectively. For the three and nine months ended April 30, 2022, our provision for income taxes reflected an effective tax rate of negative 39.4% and negative 20.4%, respectively. 
Our income taxes for the three and nine months ended April 30, 2023 were primarily due to U.S. federal and state income taxes, withholding taxes, and foreign income taxes. Our effective tax rate varied for the three and nine months ended April 30, 2023 compared to the same periods in 2022 primarily due to an increase in current taxes driven by capitalization of research and development expenditures with no offsetting deferred benefit as a result of our valuation allowance. This increase was offset by a tax benefit from a release of tax reserves related to uncertain tax positions resulting from an agreement with a non-U.S. tax authority to pay $28.9 million to settle a tax audit during the nine months ended April 30, 2023.

[0001327567-23-000014:notes:127]
Our income taxes for the three and nine months ended April 30, 2022 were primarily due to foreign income taxes and withholding taxes. Our effective tax rates differed from the U.S. statutory tax rate primarily due to changes in our valuation allowance.

[0001327567-23-000014:notes:128]
As of April 30, 2023, our gross uncertain tax positions were $412.1 million and our interest and penalties were $7.2 million. We recognize both interest and penalties associated with uncertain tax positions as a component of income tax.

[0001327567-23-000014:notes:129]
We maintain a full valuation allowance for domestic and certain foreign deferred tax assets, including net operating loss carryforwards and certain domestic tax credits. We regularly evaluate the need for a valuation allowance. Due to recent profitability, a reversal of our valuation allowance in certain jurisdictions in the foreseeable future is reasonably possible.


## us-gaap:EarningsPerShareTextBlock

[0001327567-23-000014:notes:130]
Net Income (Loss) Per Share
Basic net income (loss) per share is computed by dividing net income (loss) by basic weighted-average shares outstanding during the period. Diluted net income (loss) per share is computed by dividing net income (loss) by diluted weighted-average shares outstanding during the period giving effect to all potentially dilutive securities to the extent they are dilutive. Potentially dilutive securities include shares issuable upon conversion of our convertible senior notes using the if-converted method. Potentially dilutive securities also include warrants related to the issuance of convertible senior notes and equity awards under our employee equity incentive plans using the treasury stock method.

[0001327567-23-000014:notes:131]
The following table presents the computation of basic and diluted net income (loss) per share of common stock (in millions, except per share data):

[0001327567-23-000014:notes:132]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 30, |  | April 30, |
|  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Net income (loss) | $ | 107.8 |  |  | $ | (73.2) |  |  | $ | 212.0 |  |  | $ | (270.3) |  |
| Weighted-average shares used to compute net income (loss) per share, basic | 303.9 |  |  | 296.7 |  |  | 302.0 |  |  | 294.7 |  |
| Weighted-average effect of potentially dilutive securities: |  |  |  |  |  |  |  |
| Convertible senior notes | 19.3 |  |  | — |  |  | 17.4 |  |  | — |  |
| Warrants related to the issuance of convertible senior notes | 10.0 |  |  | — |  |  | 7.3 |  |  | — |  |
| Employee equity incentive plans | 11.5 |  |  | — |  |  | 11.4 |  |  | — |  |
| Weighted-average shares used to compute net income (loss) per share, diluted | 344.7 |  |  | 296.7 |  |  | 338.1 |  |  | 294.7 |  |
| Net income (loss) per share, basic | $ | 0.35 |  |  | $ | (0.25) |  |  | $ | 0.70 |  |  | $ | (0.92) |  |
| Net income (loss) per share, diluted | $ | 0.31 |  |  | $ | (0.25) |  |  | $ | 0.63 |  |  | $ | (0.92) |  |

[0001327567-23-000014:notes:133]
[same as prior period, unchanged from 0001327567-23-000006:notes:131]

[0001327567-23-000014:notes:134]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 30, |  | April 30, |
|  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Convertible senior notes | — |  |  | 39.2 |  |  | — |  |  | 39.2 |  |
| Warrants related to the issuance of convertible senior notes | — |  |  | 39.2 |  |  | — |  |  | 39.2 |  |
| Employee equity incentive plans | 3.2 |  |  | 28.9 |  |  | 5.0 |  |  | 28.9 |  |
| Total | 3.2 |  |  | 107.3 |  |  | 5.0 |  |  | 107.3 |  |


## us-gaap:OtherNonoperatingIncomeAndExpenseTextBlock

[0001327567-23-000014:notes:135]
Other Income, NetThe following table sets forth the components of other income, net (in millions):

[0001327567-23-000014:notes:136]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 30, |  | April 30, |
|  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Interest income | $ | 65.9 |  |  | $ | 2.6 |  |  | $ | 151.9 |  |  | $ | 5.9 |  |
| Foreign currency exchange gains (losses), net | (2.2) |  |  | 3.5 |  |  | (5.1) |  |  | (2.1) |  |
| Other | (3.6) |  |  | (4.2) |  |  | (9.3) |  |  | (3.6) |  |
| Total other income, net | $ | 60.1 |  |  | $ | 1.9 |  |  | $ | 137.5 |  |  | $ | 0.2 |  |
