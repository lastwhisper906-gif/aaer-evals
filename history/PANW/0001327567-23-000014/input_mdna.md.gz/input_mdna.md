# PANW MD&A — 0001327567-23-000014


## mdna

[0001327567-23-000014:mdna:1]
[same as prior period, unchanged from 0001327567-23-000006:mdna:1]

[0001327567-23-000014:mdna:2]
[same as prior period, unchanged from 0001327567-23-000006:mdna:2]

[0001327567-23-000014:mdna:3]
[same as prior period, unchanged from 0001327567-23-000006:mdna:3]

[0001327567-23-000014:mdna:4]
[same as prior period, unchanged from 0001327567-23-000006:mdna:4]

[0001327567-23-000014:mdna:5]
•Results of Operations. A discussion of the nature and trends in our financial results and an analysis of our financial results comparing the three and nine months ended April 30, 2023 to the three and nine months ended April 30, 2022.

[0001327567-23-000014:mdna:6]
[same as prior period, unchanged from 0001327567-23-000006:mdna:6]

[0001327567-23-000014:mdna:7]
[same as prior period, unchanged from 0001327567-23-000006:mdna:7]

[0001327567-23-000014:mdna:8]
[same as prior period, unchanged from 0001327567-23-000006:mdna:8]

[0001327567-23-000014:mdna:9]
[same as prior period, unchanged from 0001327567-23-000006:mdna:9]

[0001327567-23-000014:mdna:10]
[same as prior period, unchanged from 0001327567-23-000006:mdna:10]

[0001327567-23-000014:mdna:11]
[same as prior period, unchanged from 0001327567-23-000006:mdna:24]

[0001327567-23-000014:mdna:12]
[same as prior period, unchanged from 0001327567-23-000006:mdna:13]

[0001327567-23-000014:mdna:13]
•Our network security platform, which includes our ML-Powered Next-Generation Firewalls, available in a number of form factors, including physical, virtual, and containerized appliances, as well as a cloud-delivered service, has been a leader in the industry for eleven consecutive years. Our network security platform also includes our Cloud-Delivered Security Services, such as Advanced Threat Prevention, Advanced WildFire®, Advanced URL Filtering, DNS Security, IoT Security, GlobalProtect™, Enterprise Data Loss Prevention (“Enterprise DLP”), AIOps, and SaaS Security. Through these add-on security services, our customers are able to secure their applications, users, devices, and content across our network security platform as well as the Prisma® and Cortex® product lines. Panorama™, our network security management solution, available as hardware or virtual machine, can centrally manage our network security platform irrespective of form factor, location, or scale. Our software-defined wide-area network (“SD-WAN”) is integrated with PAN-OS, so that our end-customers can get the security features of our ML-Powered Next-Generation Firewall together with SD-WAN functionality.

[0001327567-23-000014:mdna:14]
[same as prior period, unchanged from 0001327567-23-000006:mdna:15]

[0001327567-23-000014:mdna:15]
•Prisma Access is our next-generation cloud-delivered security platform that provides secure network access for employees across all locations with continuous threat inspection and unified policy management for information technology. We recently introduced Zero Trust Network Access (“ZTNA”) 2.0, which addresses major shortcomings in the first-generation ZTNA products in the industry (which we refer to as ZTNA 1.0). Prisma Access delivers granular least-privileged access to all applications and data across the enterprise, while continuously verifying trust and inspecting traffic for security. Prisma Access is also combined with Prisma SD-WAN to provide a comprehensive single-vendor Secure Access Service Edge (“SASE”) offering that we call Prisma SASE, that is used to secure hybrid workforces and enable the cloud-delivered branch.

[0001327567-23-000014:mdna:16]
[same as prior period, unchanged from 0001327567-23-000006:mdna:17]

[0001327567-23-000014:mdna:17]
•As a comprehensive Cloud Native Application Protection Platform (“CNAPP”), Prisma Cloud removes friction and guesswork out of securing hybrid and multi-cloud environments with continuous visibility and threat prevention. With code to cloud security coverage that encompasses code, infrastructure, workloads, data, networks, web applications, and APIs, Prisma Cloud is the only platform that addresses security needs at every step in the application lifecycle. For inline network security on multi and hybrid-cloud environments, we also offer our VM-Series and CN-Series Firewall offerings.

[0001327567-23-000014:mdna:18]
[same as prior period, unchanged from 0001327567-23-000006:mdna:19]

[0001327567-23-000014:mdna:19]
[same as prior period, unchanged from 0001327567-23-000006:mdna:20]

[0001327567-23-000014:mdna:20]
[same as prior period, unchanged from 0001327567-23-000006:mdna:21]

[0001327567-23-000014:mdna:21]
[same as prior period, unchanged from 0001327567-23-000006:mdna:22]

[0001327567-23-000014:mdna:22]
For the third quarter of fiscal 2023 and 2022, total revenue was $1.7 billion and $1.4 billion, respectively, representing year-over-year growth of 24.1%. Our growth reflects the increased adoption of our portfolio, which consists of product, subscriptions, and support. We believe our portfolio will enable us to benefit from recurring revenues and new revenues as we continue to grow our end-customer base. As of April 30, 2023, we had end-customers in over 180 countries. Our end-customers represent a broad range of industries, including education, energy, financial services, government entities, healthcare, Internet and media, manufacturing, public sector, and telecommunications, and include almost all of the Fortune 100 companies and a majority of the Global 2000 companies. We maintain a field sales force that works closely with our channel partners in developing sales opportunities. We primarily use a two-tiered, indirect fulfillment model whereby we sell our products, subscriptions, and support to our distributors, which, in turn, sell to our resellers, which then sell to our end-customers.

[0001327567-23-000014:mdna:23]
[same as prior period, unchanged from 0001327567-23-000006:mdna:33]

[0001327567-23-000014:mdna:24]
Our product revenue grew to $388.1 million, or 22.6% of total revenue, for the third quarter of fiscal 2023, representing year-over-year growth of 10.4%. Product revenue is primarily generated from sales of our appliances, primarily our ML-Powered Next-Generation Firewall. Product revenue also includes revenue derived from software licenses of Panaroma, SD-WAN, and the VM-Series. Our ML-Powered Next-Generation Firewall incorporates our PAN-OS operating system, which provides a consistent set of capabilities across our entire network security product line. Our appliances and software licenses include a broad set of built-in networking and security features and functionalities. Our products are designed for different performance requirements throughout an organization, ranging from our PA-410, which is designed for small organizations and remote or branch offices, to our top-of-the-line PA-7080, which is designed for large-scale data centers and service provider use. The same firewall functionality that is delivered in our physical appliances is also available in our VM-Series virtual firewalls, which secure virtualized and cloud-based computing environments, and in our CN-Series container firewalls, which secure container environments and traffic.

[0001327567-23-000014:mdna:25]
Our subscription and support revenue grew to $1.3 billion, or 77.4% of total revenue, for the third quarter of fiscal 2023, representing year-over-year growth of 28.7%. Our subscriptions provide our end-customers with near real-time access to the latest antivirus, intrusion prevention, web filtering, modern malware prevention, data loss prevention, and cloud access security broker capabilities across the network, endpoints, and the cloud. When end-customers purchase our physical, virtual, or container firewall appliances, or certain cloud offerings, they typically purchase support in order to receive ongoing security updates, upgrades, bug fixes, and repairs. In addition to the subscriptions purchased with these appliances, end-customers may also purchase other subscriptions on a per-user, per-endpoint, or capacity-based basis. We also offer professional services, including incident response, risk management, and digital forensic services.

[0001327567-23-000014:mdna:26]
We continue to invest in innovation as we evolve and further extend the capabilities of our portfolio, as we believe that innovation and timely development of new features and products are essential to meeting the needs of our end-customers and improving our competitive position. For example, in March 2023, we enhanced our Prisma SASE capabilities for organizations to leverage the power of artificial intelligence to drive better security outcomes and operating efficiencies.

[0001327567-23-000014:mdna:27]
[same as prior period, unchanged from 0001327567-23-000006:mdna:29]

[0001327567-23-000014:mdna:28]
[same as prior period, unchanged from 0001327567-23-000006:mdna:30]

[0001327567-23-000014:mdna:29]
Our overall performance depends in part on worldwide economic and geopolitical conditions and their impact on customer behavior. Worsening economic conditions, including inflation, higher interest rates, slower growth, fluctuations in foreign exchange rates, and other conditions such as the effects of COVID-19, may adversely affect our results of operations and financial performance.

[0001327567-23-000014:mdna:30]
The global supply chain and the semiconductor industry continue to experience challenges. We have experienced supply chain challenges, including chip and component shortages, which have, in certain cases, caused delays for us in acquiring chips, components and inventory and have resulted in increased costs as compared to historic levels. While we have experienced improvements in the availability of chips and components in general during the third quarter of fiscal 2023, we are still incurring increased costs and experiencing increased lead time for certain product deliveries to our end-customers. We will continue to work to minimize the effects from supply chain challenges.

[0001327567-23-000014:mdna:31]
[same as prior period, unchanged from 0001327567-23-000006:mdna:42]

[0001327567-23-000014:mdna:32]
[same as prior period, unchanged from 0001327567-23-000006:mdna:35]

[0001327567-23-000014:mdna:33]
[same as prior period, unchanged from 0001327567-23-000006:mdna:36]

[0001327567-23-000014:mdna:34]
|  | April 30, 2023 |  | July 31, 2022 |
|  | (in millions) |
| Total deferred revenue | $ | 8,089.6 |  |  | $ | 6,994.0 |  |
| Cash, cash equivalents, and investments | $ | 6,668.0 |  |  | $ | 4,686.4 |  |

[0001327567-23-000014:mdna:35]
|  | Three Months Ended April 30, |  | Nine Months Ended April 30, |
|  | 2023 |  | 2022 |  | 2023 |  | 2022 |
|  | (dollars in millions) |
| Total revenue | $ | 1,720.9 |  |  | $ | 1,386.7 |  |  | $ | 4,939.4 |  |  | $ | 3,951.0 |  |
| Total revenue year-over-year percentage increase | 24.1 | % |  | 29.1 | % |  | 25.0 | % |  | 30.1 | % |
| Gross margin | 72.4 | % |  | 68.2 | % |  | 71.6 | % |  | 69.0 | % |
| Operating income (loss) | $ | 78.7 |  |  | $ | (47.6) |  |  | $ | 133.8 |  |  | $ | (204.2) |  |
| Operating margin | 4.6 | % |  | (3.4) | % |  | 2.7 | % |  | (5.2) | % |
| Billings | $ | 2,256.2 |  |  | $ | 1,796.9 |  |  | $ | 6,034.3 |  |  | $ | 4,786.4 |  |
| Billings year-over-year percentage increase | 25.6 | % |  | 39.7 | % |  | 26.1 | % |  | 33.6 | % |
| Cash flow provided by operating activities |  |  |  |  | $ | 2,363.4 |  |  | $ | 1,461.0 |  |
| Free cash flow (non-GAAP) |  |  |  |  | $ | 2,254.3 |  |  | $ | 1,307.4 |  |

[0001327567-23-000014:mdna:36]
[same as prior period, unchanged from 0001327567-23-000006:mdna:39]

[0001327567-23-000014:mdna:37]
[same as prior period, unchanged from 0001327567-23-000006:mdna:40]

[0001327567-23-000014:mdna:38]
|  | Three Months Ended April 30, |  | Nine Months Ended April 30, |
|  | 2023 |  | 2022 |  | 2023 |  | 2022 |
|  | (in millions) |  | (in millions) |
| Billings: |  |  |  |  |  |  |  |
| Total revenue | $ | 1,720.9 |  |  | $ | 1,386.7 |  |  | $ | 4,939.4 |  |  | $ | 3,951.0 |  |
| Add: change in total deferred revenue, net of acquired deferred revenue | 535.3 |  |  | 410.2 |  |  | 1,094.9 |  |  | 835.4 |  |
| Billings | $ | 2,256.2 |  |  | $ | 1,796.9 |  |  | $ | 6,034.3 |  |  | $ | 4,786.4 |  |

[0001327567-23-000014:mdna:39]
[same as prior period, unchanged from 0001327567-23-000006:mdna:47]

[0001327567-23-000014:mdna:40]
[same as prior period, unchanged from 0001327567-23-000006:mdna:44]

[0001327567-23-000014:mdna:41]
[same as prior period, unchanged from 0001327567-23-000006:mdna:45]

[0001327567-23-000014:mdna:42]
|  | Nine Months Ended April 30, |
|  | 2023 |  | 2022 |
|  | (in millions) |
| Free cash flow (non-GAAP): |  |  |  |
| Net cash provided by operating activities | $ | 2,363.4 |  |  | $ | 1,461.0 |  |
| Less: purchases of property, equipment, and other assets | 109.1 |  |  | 153.6 |  |
| Free cash flow (non-GAAP) | $ | 2,254.3 |  |  | $ | 1,307.4 |  |
| Net cash used in investing activities | $ | (2,396.4) |  |  | $ | (461.3) |  |
| Net cash used in financing activities | $ | (91.5) |  |  | $ | (453.5) |  |

[0001327567-23-000014:mdna:43]
[same as prior period, unchanged from 0001327567-23-000006:mdna:57]

[0001327567-23-000014:mdna:44]
[same as prior period, unchanged from 0001327567-23-000006:mdna:49]

[0001327567-23-000014:mdna:45]
[same as prior period, unchanged from 0001327567-23-000006:mdna:50]

[0001327567-23-000014:mdna:46]
|  | Three Months Ended April 30, |  | Nine Months Ended April 30, |
|  | 2023 |  | 2022 |  | 2023 |  | 2022 |
|  | Amount |  | % of Revenue |  | Amount |  | % of Revenue |  | Amount |  | % of Revenue |  | Amount |  | % of Revenue |
|  | (dollars in millions) |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product | $ | 388.1 |  |  | 22.6 | % |  | $ | 351.5 |  |  | 25.3 | % |  | $ | 1,071.0 |  |  | 21.7 | % |  | $ | 955.0 |  |  | 24.2 | % |
| Subscription and support | 1,332.8 |  |  | 77.4 | % |  | 1,035.2 |  |  | 74.7 | % |  | 3,868.4 |  |  | 78.3 | % |  | 2,996.0 |  |  | 75.8 | % |
| Total revenue | 1,720.9 |  |  | 100.0 | % |  | 1,386.7 |  |  | 100.0 | % |  | 4,939.4 |  |  | 100.0 | % |  | 3,951.0 |  |  | 100.0 | % |
| Cost of revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product | 93.4 |  |  | 5.4 | % |  | 126.0 |  |  | 9.1 | % |  | 314.0 |  |  | 6.4 | % |  | 312.7 |  |  | 7.9 | % |
| Subscription and support | 381.4 |  |  | 22.2 | % |  | 314.5 |  |  | 22.7 | % |  | 1,088.9 |  |  | 22.0 | % |  | 913.7 |  |  | 23.1 | % |
| Total cost of revenue(1) | 474.8 |  |  | 27.6 | % |  | 440.5 |  |  | 31.8 | % |  | 1,402.9 |  |  | 28.4 | % |  | 1,226.4 |  |  | 31.0 | % |
| Total gross profit | 1,246.1 |  |  | 72.4 | % |  | 946.2 |  |  | 68.2 | % |  | 3,536.5 |  |  | 71.6 | % |  | 2,724.6 |  |  | 69.0 | % |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Research and development | 413.7 |  |  | 24.0 | % |  | 355.4 |  |  | 25.6 | % |  | 1,189.6 |  |  | 24.1 | % |  | 1,053.9 |  |  | 26.7 | % |
| Sales and marketing | 639.5 |  |  | 37.2 | % |  | 543.6 |  |  | 39.2 | % |  | 1,880.0 |  |  | 38.1 | % |  | 1,578.3 |  |  | 40.0 | % |
| General and administrative | 114.2 |  |  | 6.6 | % |  | 94.8 |  |  | 6.8 | % |  | 333.1 |  |  | 6.7 | % |  | 296.6 |  |  | 7.5 | % |
| Total operating expenses(1) | 1,167.4 |  |  | 67.8 | % |  | 993.8 |  |  | 71.6 | % |  | 3,402.7 |  |  | 68.9 | % |  | 2,928.8 |  |  | 74.2 | % |
| Operating income (loss) | 78.7 |  |  | 4.6 | % |  | (47.6) |  |  | (3.4) | % |  | 133.8 |  |  | 2.7 | % |  | (204.2) |  |  | (5.2) | % |
| Interest expense | (7.8) |  |  | (0.5) | % |  | (6.8) |  |  | (0.5) | % |  | (21.5) |  |  | (0.4) | % |  | (20.5) |  |  | (0.5) | % |
| Other income, net | 60.1 |  |  | 3.5 | % |  | 1.9 |  |  | 0.1 | % |  | 137.5 |  |  | 2.8 | % |  | 0.2 |  |  | — | % |
| Income (loss) before income taxes | 131.0 |  |  | 7.6 | % |  | (52.5) |  |  | (3.8) | % |  | 249.8 |  |  | 5.1 | % |  | (224.5) |  |  | (5.7) | % |
| Provision for income taxes | 23.2 |  |  | 1.3 | % |  | 20.7 |  |  | 1.5 | % |  | 37.8 |  |  | 0.8 | % |  | 45.8 |  |  | 1.1 | % |
| Net income (loss) | $ | 107.8 |  |  | 6.3 | % |  | $ | (73.2) |  |  | (5.3) | % |  | $ | 212.0 |  |  | 4.3 | % |  | $ | (270.3) |  |  | (6.8) | % |

[0001327567-23-000014:mdna:47]
[same as prior period, unchanged from 0001327567-23-000006:mdna:52]

[0001327567-23-000014:mdna:48]
[same as prior period, unchanged from 0001327567-23-000006:mdna:53]

[0001327567-23-000014:mdna:49]
|  | Three Months Ended April 30, |  | Nine Months Ended April 30, |
|  | 2023 |  | 2022 |  | 2023 |  | 2022 |
|  | (in millions) |
| Cost of product revenue | $ | 2.5 |  |  | $ | 2.3 |  |  | $ | 7.5 |  |  | $ | 6.9 |  |
| Cost of subscription and support revenue | 32.0 |  |  | 27.4 |  |  | 91.5 |  |  | 81.8 |  |
| Research and development | 125.4 |  |  | 112.7 |  |  | 373.1 |  |  | 361.9 |  |
| Sales and marketing | 80.5 |  |  | 75.7 |  |  | 256.3 |  |  | 228.8 |  |
| General and administrative | 36.8 |  |  | 29.2 |  |  | 104.7 |  |  | 93.3 |  |
| Total share-based compensation | $ | 277.2 |  |  | $ | 247.3 |  |  | $ | 833.1 |  |  | $ | 772.7 |  |

[0001327567-23-000014:mdna:50]
[same as prior period, unchanged from 0001327567-23-000006:mdna:55]

[0001327567-23-000014:mdna:51]
[same as prior period, unchanged from 0001327567-23-000006:mdna:56]

[0001327567-23-000014:mdna:52]
[same as prior period, unchanged from 0001327567-23-000006:mdna:70]

[0001327567-23-000014:mdna:53]
[same as prior period, unchanged from 0001327567-23-000006:mdna:59]

[0001327567-23-000014:mdna:54]
[same as prior period, unchanged from 0001327567-23-000006:mdna:60]

[0001327567-23-000014:mdna:55]
|  | Three Months Ended April 30, |  |  |  |  |  | Nine Months Ended April 30, |  |  |  |  |
|  | 2023 |  | 2022 |  | Change |  | 2023 |  | 2022 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| Product | $ | 388.1 |  |  | $ | 351.5 |  |  | $ | 36.6 |  |  | 10.4 | % |  | $ | 1,071.0 |  |  | $ | 955.0 |  |  | $ | 116.0 |  |  | 12.1 | % |

[0001327567-23-000014:mdna:56]
Product revenue for the three and nine months ended April 30, 2023 increased compared to the same periods in 2022 driven by increased demand for our new generation of hardware products and increased software revenue primarily due to a new go-to-market strategy for certain Network Security offerings, partially offset by decreased revenue from our prior generation of hardware products.

[0001327567-23-000014:mdna:57]
[same as prior period, unchanged from 0001327567-23-000006:mdna:63]

[0001327567-23-000014:mdna:58]
[same as prior period, unchanged from 0001327567-23-000006:mdna:64]

[0001327567-23-000014:mdna:59]
|  | Three Months Ended April 30, |  |  |  |  |  | Nine Months Ended April 30, |  |  |  |  |
|  | 2023 |  | 2022 |  | Change |  | 2023 |  | 2022 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| Subscription | $ | 838.1 |  |  | $ | 639.8 |  |  | $ | 198.3 |  |  | 31.0 | % |  | $ | 2,417.5 |  |  | $ | 1,836.6 |  |  | $ | 580.9 |  |  | 31.6 | % |
| Support | 494.7 |  |  | 395.4 |  |  | 99.3 |  |  | 25.1 | % |  | 1,450.9 |  |  | 1,159.4 |  |  | 291.5 |  |  | 25.1 | % |
| Total subscription and support | $ | 1,332.8 |  |  | $ | 1,035.2 |  |  | $ | 297.6 |  |  | 28.7 | % |  | $ | 3,868.4 |  |  | $ | 2,996.0 |  |  | $ | 872.4 |  |  | 29.1 | % |

[0001327567-23-000014:mdna:60]
Subscription and support revenue increased for the three and nine months ended April 30, 2023 compared to the same periods in 2022 due to increased demand for our subscription and support offerings from our end-customers. The mix between subscription revenue and support revenue will fluctuate over time, depending on the introduction of new subscription offerings, renewals of support services, and our ability to increase sales to new and existing end-customers.

[0001327567-23-000014:mdna:61]
[same as prior period, unchanged from 0001327567-23-000006:mdna:67]

[0001327567-23-000014:mdna:62]
|  | Three Months Ended April 30, |  |  |  |  |  | Nine Months Ended April 30, |  |  |  |  |
|  | 2023 |  | 2022 |  | Change |  | 2023 |  | 2022 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| Americas | $ | 1,179.2 |  |  | $ | 948.7 |  |  | $ | 230.5 |  |  | 24.3 | % |  | $ | 3,366.9 |  |  | $ | 2,731.3 |  |  | $ | 635.6 |  |  | 23.3 | % |
| EMEA | 332.1 |  |  | 269.5 |  |  | 62.6 |  |  | 23.2 | % |  | 981.5 |  |  | 755.5 |  |  | 226.0 |  |  | 29.9 | % |
| APAC | 209.6 |  |  | 168.5 |  |  | 41.1 |  |  | 24.4 | % |  | 591.0 |  |  | 464.2 |  |  | 126.8 |  |  | 27.3 | % |
| Total revenue | $ | 1,720.9 |  |  | $ | 1,386.7 |  |  | $ | 334.2 |  |  | 24.1 | % |  | $ | 4,939.4 |  |  | $ | 3,951.0 |  |  | $ | 988.4 |  |  | 25.0 | % |

[0001327567-23-000014:mdna:63]
With respect to geographic theaters, the increases in revenue for the three and nine months ended April 30, 2023 compared to the same periods in 2022 were driven primarily by the Americas, due to its larger sales force and a larger percentage of our customers located in the Americas. Revenue from our other geographic theaters, Europe, the Middle East, and Africa (“EMEA”) and Asia Pacific and Japan (“APAC”), increased for the three and nine months ended April 30, 2023 compared to the same periods in 2022 due to continued investment in our global sales force to support our growth and increase our customer base in the regions.

[0001327567-23-000014:mdna:64]
[same as prior period, unchanged from 0001327567-23-000006:mdna:82]

[0001327567-23-000014:mdna:65]
[same as prior period, unchanged from 0001327567-23-000006:mdna:72]

[0001327567-23-000014:mdna:66]
[same as prior period, unchanged from 0001327567-23-000006:mdna:73]

[0001327567-23-000014:mdna:67]
[same as prior period, unchanged from 0001327567-23-000006:mdna:74]

[0001327567-23-000014:mdna:68]
Cost of product revenue primarily includes costs paid to our manufacturing partners for procuring components and manufacturing our products. Our cost of product revenue also includes personnel costs, which consist of salaries, benefits, bonuses, share-based compensation and travel and entertainment associated with our operations organization, amortization of intellectual property licenses, product testing costs, shipping and tariff costs, and shared costs. Shared costs consist of certain facilities, depreciation, benefits, recruiting, and information technology costs that we allocate based on headcount. We expect our cost of product revenue to fluctuate with our revenue from hardware products.

[0001327567-23-000014:mdna:69]
|  | Three Months Ended April 30, |  |  |  |  |  | Nine Months Ended April 30, |  |  |  |  |
|  | 2023 |  | 2022 |  | Change |  | 2023 |  | 2022 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| Cost of product revenue | $ | 93.4 |  |  | $ | 126.0 |  |  | $ | (32.6) |  |  | (25.9) | % |  | $ | 314.0 |  |  | $ | 312.7 |  |  | $ | 1.3 |  |  | 0.4 | % |
| Number of employees at period end | 141 |  |  | 147 |  |  | (6) |  |  | (4.1) | % |  | 141 |  |  | 147 |  |  | (6) |  |  | (4.1) | % |

[0001327567-23-000014:mdna:70]
Cost of product revenue decreased for the three months ended April 30, 2023 compared to the same period in 2022 due to decreased demand for our prior generation hardware products, partially offset by increased demand for our new generation hardware products. The decrease was further driven by lower costs primarily due to an easing of supply chain challenges during the three months ended April 30, 2023. Cost of product revenue was relatively flat for the nine months ended April 30, 2023 compared to the same period in 2022 due to increased demand for our new generation hardware products as we shifted away from prior generation, and higher costs primarily driven by supply chain challenges during the first two quarters of fiscal 2023, offset by hardware product mix.

[0001327567-23-000014:mdna:71]
[same as prior period, unchanged from 0001327567-23-000006:mdna:78]

[0001327567-23-000014:mdna:72]
[same as prior period, unchanged from 0001327567-23-000006:mdna:79]

[0001327567-23-000014:mdna:73]
|  | Three Months Ended April 30, |  |  |  |  |  | Nine Months Ended April 30, |  |  |  |  |
|  | 2023 |  | 2022 |  | Change |  | 2023 |  | 2022 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| Cost of subscription and support revenue | $ | 381.4 |  |  | $ | 314.5 |  |  | $ | 66.9 |  |  | 21.3 | % |  | $ | 1,088.9 |  |  | $ | 913.7 |  |  | $ | 175.2 |  |  | 19.2 | % |
| Number of employees at period end | 2,815 |  |  | 2,400 |  |  | 415 |  |  | 17.3 | % |  | 2,815 |  |  | 2,400 |  |  | 415 |  |  | 17.3 | % |

[0001327567-23-000014:mdna:74]
Cost of subscription and support revenue increased for the three and nine months ended April 30, 2023 compared to the same periods in 2022, primarily due to increased costs to support the growth of our subscription and support offerings. Cloud hosting service costs, which support our cloud-based subscription offerings, increased $27.9 million for the three months ended April 30, 2023 compared to the same period in 2022, and increased $73.6 million for the nine months ended April 30, 2023 compared to the same period in 2022. Personnel costs grew $25.8 million to $168.3 million for the three months ended April 30, 2023 compared to the same period in 2022, and grew $68.2 million to $472.1 million for the nine months ended April 30, 2023 compared to the same period in 2022, primarily due to headcount growth.

[0001327567-23-000014:mdna:75]
[same as prior period, unchanged from 0001327567-23-000006:mdna:95]

[0001327567-23-000014:mdna:76]
[same as prior period, unchanged from 0001327567-23-000006:mdna:84]

[0001327567-23-000014:mdna:77]
[same as prior period, unchanged from 0001327567-23-000006:mdna:85]

[0001327567-23-000014:mdna:78]
|  | Three Months Ended April 30, |  | Nine Months Ended April 30, |
|  | 2023 |  | 2022 |  | 2023 |  | 2022 |
|  | Amount |  | Gross Margin |  | Amount |  | Gross Margin |  | Amount |  | Gross Margin |  | Amount |  | Gross Margin |
|  | (dollars in millions) |
| Product | $ | 294.7 |  |  | 75.9 | % |  | $ | 225.5 |  |  | 64.2 | % |  | $ | 757.0 |  |  | 70.7 | % |  | $ | 642.3 |  |  | 67.3 | % |
| Subscription and support | 951.4 |  |  | 71.4 | % |  | 720.7 |  |  | 69.6 | % |  | 2,779.5 |  |  | 71.9 | % |  | 2,082.3 |  |  | 69.5 | % |
| Total gross profit | $ | 1,246.1 |  |  | 72.4 | % |  | $ | 946.2 |  |  | 68.2 | % |  | $ | 3,536.5 |  |  | 71.6 | % |  | $ | 2,724.6 |  |  | 69.0 | % |

[0001327567-23-000014:mdna:79]
Product gross margin increased for the three months ended April 30, 2023 compared to the same period in 2022, primarily due to increased software revenue, lower costs primarily driven by an easing of supply chain challenges, and a favorable hardware product mix. Product gross margin increased for the nine months ended April 30, 2023 compared to the same period in 2022, primarily due to increased software revenue and a favorable hardware product mix, partially offset by higher costs primarily driven by supply chain challenges during the first two quarters of fiscal 2023.

[0001327567-23-000014:mdna:80]
Subscription and support gross margin increased for the three and nine months ended April 30, 2023 compared to the same periods in 2022, primarily due to our growth in subscription and support revenue, which outpaced the subscription and support costs.

[0001327567-23-000014:mdna:81]
[same as prior period, unchanged from 0001327567-23-000006:mdna:89]

[0001327567-23-000014:mdna:82]
Our operating expenses consist of research and development, sales and marketing, and general and administrative expenses. Personnel costs are the most significant component of operating expenses and consist of salaries, benefits, bonuses, share-based compensation, travel and entertainment, and with regard to sales and marketing expense, sales commissions. Our operating expenses also include shared costs, which consist of certain facilities, depreciation, benefits, recruiting, and information technology costs that we allocate based on headcount to each department. We expect operating expenses generally to increase in absolute dollars and decrease over the long term as a percentage of revenue as we continue to scale our business. As of April 30, 2023, we expect to recognize approximately $2.1 billion of share-based compensation expense over a weighted-average period of approximately 2.5 years, excluding additional share-based compensation expense related to any future grants of share-based awards. Share-based compensation expense is generally recognized on a straight-line basis over the requisite service periods of the awards.

[0001327567-23-000014:mdna:83]
[same as prior period, unchanged from 0001327567-23-000006:mdna:91]

[0001327567-23-000014:mdna:84]
[same as prior period, unchanged from 0001327567-23-000006:mdna:92]

[0001327567-23-000014:mdna:85]
|  | Three Months Ended April 30, |  |  |  |  |  | Nine Months Ended April 30, |  |  |  |  |
|  | 2023 |  | 2022 |  | Change |  | 2023 |  | 2022 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| Research and development | $ | 413.7 |  |  | $ | 355.4 |  |  | $ | 58.3 |  |  | 16.4 | % |  | $ | 1,189.6 |  |  | $ | 1,053.9 |  |  | $ | 135.7 |  |  | 12.9 | % |
| Number of employees at period end | 3,693 |  |  | 3,047 |  |  | 646 |  |  | 21.2 | % |  | 3,693 |  |  | 3,047 |  |  | 646 |  |  | 21.2 | % |

[0001327567-23-000014:mdna:86]
Research and development expense increased for the three and nine months ended April 30, 2023 compared to the same periods in 2022, primarily due to increased personnel costs, which grew $50.2 million to $328.0 million for the three months ended April 30, 2023 compared to the same period in 2022, and grew $107.9 million to $938.8 million for the nine months ended April 30, 2023 compared to the same period in 2022, largely due to headcount growth.

[0001327567-23-000014:mdna:87]
[same as prior period, unchanged from 0001327567-23-000006:mdna:109]

[0001327567-23-000014:mdna:88]
[same as prior period, unchanged from 0001327567-23-000006:mdna:97]

[0001327567-23-000014:mdna:89]
[same as prior period, unchanged from 0001327567-23-000006:mdna:98]

[0001327567-23-000014:mdna:90]
|  | Three Months Ended April 30, |  |  |  |  |  | Nine Months Ended April 30, |  |  |  |  |
|  | 2023 |  | 2022 |  | Change |  | 2023 |  | 2022 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| Sales and marketing | $ | 639.5 |  |  | $ | 543.6 |  |  | $ | 95.9 |  |  | 17.6 | % |  | $ | 1,880.0 |  |  | $ | 1,578.3 |  |  | $ | 301.7 |  |  | 19.1 | % |
| Number of employees at period end | 5,710 |  |  | 4,908 |  | 802 |  |  | 16.3 | % |  | 5,710 |  |  | 4,908 |  |  | 802 |  |  | 16.3 | % |

[0001327567-23-000014:mdna:91]
Sales and marketing expense increased for the three and nine months ended April 30, 2023 compared to the same periods in 2022, primarily due to increased personnel costs, which grew $69.9 million to $482.8 million for the three months ended April 30, 2023 compared to the same period in 2022, and grew $223.8 million to $1.4 billion for the nine months ended April 30, 2023 compared to the same period in 2022, largely due to headcount growth. The increases in both periods were further driven by increased costs associated with marketing activities.

[0001327567-23-000014:mdna:92]
[same as prior period, unchanged from 0001327567-23-000006:mdna:101]

[0001327567-23-000014:mdna:93]
[same as prior period, unchanged from 0001327567-23-000006:mdna:102]

[0001327567-23-000014:mdna:94]
|  | Three Months Ended April 30, |  |  |  |  |  | Nine Months Ended April 30, |  |  |  |  |
|  | 2023 |  | 2022 |  | Change |  | 2023 |  | 2022 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| General and administrative | $ | 114.2 |  |  | $ | 94.8 |  |  | $ | 19.4 |  |  | 20.5 | % |  | $ | 333.1 |  |  | $ | 296.6 |  |  | $ | 36.5 |  |  | 12.3 | % |
| Number of employees at period end | 1,620 |  |  | 1,368 |  |  | 252 |  |  | 18.4 | % |  | 1,620 |  |  | 1,368 |  |  | 252 |  |  | 18.4 | % |

[0001327567-23-000014:mdna:95]
General and administrative expense increased for the three and nine months ended April 30, 2023 compared to the same periods in 2022 primarily due to increased personnel costs, which grew $9.4 million to $77.8 million for the three months ended April 30, 2023 compared to the same period in 2022, and grew $18.0 million to $223.1 million for the nine months ended April 30, 2023 compared to the same period in 2022. The increases in personnel costs for both periods were primarily due to share-based compensation related to our recent acquisitions and headcount growth. The increases in both periods were further driven by slightly higher reserves due to increased receivables as a result of our business growth.

[0001327567-23-000014:mdna:96]
[same as prior period, unchanged from 0001327567-23-000006:mdna:105]

[0001327567-23-000014:mdna:97]
Interest expense primarily consists of interest expense related to our 0.75% Convertible Senior Notes due 2023 (the “2023 Notes”) and the 0.375% Convertible Senior Notes due 2025 (the “2025 Notes,” and together with “2023 Notes,” the “Notes”).

[0001327567-23-000014:mdna:98]
|  | Three Months Ended April 30, |  |  |  | Nine Months Ended April 30, |  |  |
|  | 2023 |  | 2022 |  | Change |  | 2023 |  | 2022 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| Interest expense | $ | 7.8 |  |  | $ | 6.8 |  |  | $ | 1.0 |  |  | 14.7 | % |  | $ | 21.5 |  |  | $ | 20.5 |  |  | $ | 1.0 |  |  | 4.9 | % |

[0001327567-23-000014:mdna:99]
Interest expense increased slightly for the three and nine months ended April 30, 2023 compared to the same periods in 2022 primarily due to certain additional costs during the three months ended April 30, 2023.

[0001327567-23-000014:mdna:100]
[same as prior period, unchanged from 0001327567-23-000006:mdna:126]

[0001327567-23-000014:mdna:101]
Other Income, Net

[0001327567-23-000014:mdna:102]
Other income, net includes interest income earned on our cash, cash equivalents, and investments, and gains and losses from foreign currency remeasurement and foreign currency transactions.

[0001327567-23-000014:mdna:103]
|  | Three Months Ended April 30, |  |  |  | Nine Months Ended April 30, |  |  |
|  | 2023 |  | 2022 |  | Change |  | 2023 |  | 2022 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| Other income, net | $ | 60.1 |  |  | $ | 1.9 |  |  | $ | 58.2 |  |  | * |  | $ | 137.5 |  |  | $ | 0.2 |  |  | $ | 137.3 |  |  | * |

[0001327567-23-000014:mdna:104]
[same as prior period, unchanged from 0001327567-23-000006:mdna:114]

[0001327567-23-000014:mdna:105]
[same as prior period, unchanged from 0001327567-23-000006:mdna:115]

[0001327567-23-000014:mdna:106]
The increases in other income, net for the three and nine months ended April 30, 2023 compared to the same periods in 2022 were primarily due to higher interest income earned as a result of higher interest rates and higher cash, cash equivalent, and investments balances for the three and nine months ended April 30, 2023 compared to 2022.

[0001327567-23-000014:mdna:107]
[same as prior period, unchanged from 0001327567-23-000006:mdna:117]

[0001327567-23-000014:mdna:108]
Provision for income taxes consists primarily of U.S. taxes driven by capitalization of research and development expenditures, foreign income taxes, and withholding taxes. We maintain a full valuation allowance for domestic and certain foreign deferred tax assets, including net operating loss carryforwards and certain domestic tax credits. Our valuation allowance has caused, and may continue to cause, disproportionate relationships between our overall effective tax rate and other jurisdictional measures. We regularly evaluate the need for a valuation allowance. Due to recent profitability, a reversal of our valuation allowance in certain jurisdictions in the foreseeable future is reasonably possible.

[0001327567-23-000014:mdna:109]
|  | Three Months Ended April 30, |  |  |  |  |  | Nine Months Ended April 30, |  |  |  |  |
|  |  |  |  |  | Change |  | 2023 |  | 2022 |  | Change |
|  | 2023 |  | 2022 |  | Amount |  | % |  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| Provision for income taxes | $ | 23.2 |  |  | $ | 20.7 |  |  | $ | 2.5 |  |  | 12.1 | % |  | $ | 37.8 |  |  | $ | 45.8 |  |  | $ | (8.0) |  |  | (17.5) | % |
| Effective tax rate | 17.7 | % |  | (39.4) | % |  |  |  |  |  | 15.1 | % |  | (20.4) | % |  |  |  |  |

[0001327567-23-000014:mdna:110]
Our provision for income taxes for the three and nine months ended April 30, 2023 was primarily due to U.S. federal and state income taxes, withholding taxes, and foreign income taxes. Our effective tax rate varied for the three and nine months ended April 30, 2023 compared to the same periods in 2022, primarily due to an increase in current taxes driven by capitalization of research and development expenditures with no offsetting deferred benefit as a result of our valuation allowance. This increase was offset by a release of uncertain tax positions during the nine months ended April 30, 2023 resulting from a tax settlement. Refer to Note 13. Income Taxes in Part I, Item 1 of this Quarterly Report on Form 10-Q for more information.

[0001327567-23-000014:mdna:111]
[same as prior period, unchanged from 0001327567-23-000006:mdna:139]

[0001327567-23-000014:mdna:112]
[same as prior period, unchanged from 0001327567-23-000006:mdna:121]

[0001327567-23-000014:mdna:113]
|  | April 30, 2023 |  | July 31, 2022 |
|  | (in millions) |
| Working capital(1) | $ | (2,227.6) |  |  | $ | (1,891.4) |  |
| Cash, cash equivalents, and investments: |  |  |  |
| Cash and cash equivalents | $ | 1,992.9 |  |  | $ | 2,118.5 |  |
| Investments | 4,675.1 |  |  | 2,567.9 |  |
| Total cash, cash equivalents, and investments | $ | 6,668.0 |  |  | $ | 4,686.4 |  |

[0001327567-23-000014:mdna:114]
[same as prior period, unchanged from 0001327567-23-000006:mdna:123]

[0001327567-23-000014:mdna:115]
(1)Current liabilities included net carrying amounts of convertible senior notes of $3.7 billion as of both April 30, 2023 and July 31, 2022. Refer to Note 9. Debt in Part I, Item 1 of this Quarterly Report on Form 10-Q for information on the Notes.

[0001327567-23-000014:mdna:116]
As of April 30, 2023, our total cash, cash equivalents, and investments of $6.7 billion were held for general corporate purposes. As of April 30, 2023, we had no unremitted earnings when evaluating our outside basis difference relating to our U.S. investment in foreign subsidiaries. However, there could be local withholding taxes payable due to various foreign countries if certain lower tier earnings are distributed. Withholding taxes that would be payable upon remittance of these lower tier earnings are not expected to be material.

[0001327567-23-000014:mdna:117]
[same as prior period, unchanged from 0001327567-23-000006:mdna:128]

[0001327567-23-000014:mdna:118]
In July 2018, we issued the 2023 Notes with an aggregate principal amount of $1.7 billion. In June 2020, we issued the 2025 Notes with an aggregate principal amount of $2.0 billion. The 2023 Notes mature on July 1, 2023 and the 2025 Notes mature on June 1, 2025; however, under certain circumstances, holders may surrender their Notes of a series for conversion prior to the applicable maturity date. Upon conversion of the Notes of a series, we will pay cash equal to the aggregate principal amount of the Notes of such series to be converted, and, at our election, will pay or deliver cash and/or shares of our common stock for the amount of our conversion obligation in excess of the aggregate principal amount of the Notes of such series being converted. All the 2023 Notes will mature on July 1, 2023 and at that time we will be obligated to pay the $1.7 billion principal amount of the 2023 Notes in cash. The sale price condition for the 2025 Notes was met during the fiscal quarter ended April 30, 2023, and as a result, holders may convert their 2025 Notes at any time during the fiscal quarter ending July 31, 2023. If all of the holders converted their 2025 Notes during this period, we would be obligated to settle the $2.0 billion principal amount of the 2025 Notes in cash. We believe that our cash provided by operating activities, our existing cash, cash equivalents and investments, and existing sources of and access to financing will be sufficient to meet our anticipated cash needs should the holders choose to convert their Notes during the fiscal quarter ending July 31, 2023 or hold the 2023 Notes until maturity on July 1, 2023. As of April 30, 2023, substantially all of our Notes remained outstanding. Refer to Note 9. Debt in Part I, Item 1 of this Quarterly Report on Form 10-Q for more information on the Notes.

[0001327567-23-000014:mdna:119]
In April 2023, we entered into a new credit agreement (the “2023 Credit Agreement”) that provides for a $400.0 million unsecured revolving credit facility (the “2023 Credit Facility”), with an option to increase the amount of the Credit Facility by up to an additional $350.0 million, subject to certain conditions. The interest rates and commitment fees are also subject to upward and downward adjustments based on our progress towards the achievement of certain sustainability goals related to greenhouse gas emissions. As of April 30, 2023, there were no amounts outstanding and we were in compliance with all covenants under the 2023 Credit Agreement. Refer to Note 9. Debt in Part I, Item 1 of this Quarterly Report on Form 10-Q for more information on the Credit Agreement.

[0001327567-23-000014:mdna:120]
[same as prior period, unchanged from 0001327567-23-000006:mdna:131]

[0001327567-23-000014:mdna:121]
In February 2019, our board of directors authorized a $1.0 billion share repurchase program. In December 2020, August 2021, and August 2022, our board of directors authorized additional $700.0 million, $676.1 million, and $915.0 million increases to this share repurchase program, respectively, bringing the total authorization under this share repurchase program to $3.3 billion. Repurchases will be funded from available working capital and may be made at management’s discretion from time to time. The expiration date of this repurchase authorization was extended to December 31, 2023, and our repurchase program may be suspended or discontinued at any time. As of April 30, 2023, $750.0 million remained available for future share repurchases under this repurchase program. Refer to Note 11. Stockholders’ Equity in Part I, Item 1 of this Quarterly Report on Form 10-Q for more information on this repurchase program.

[0001327567-23-000014:mdna:122]
[same as prior period, unchanged from 0001327567-23-000006:mdna:155]

[0001327567-23-000014:mdna:123]
[same as prior period, unchanged from 0001327567-23-000006:mdna:133]

[0001327567-23-000014:mdna:124]
We have entered into various non-cancelable operating leases primarily for our facilities with original lease periods expiring through the year ending July 31, 2032, with the most significant leases relating to our corporate headquarters in Santa Clara, California. As of April 30, 2023, we have total operating lease obligations of $327.9 million recorded on our condensed consolidated balance sheet.

[0001327567-23-000014:mdna:125]
As of April 30, 2023, our commitments to purchase products, components, cloud and other services totaled $2.0 billion. Refer to Note 10. Commitments and Contingencies in Part I, Item 1 of this Quarterly Report on Form 10-Q for more information on these commitments.

[0001327567-23-000014:mdna:126]
[same as prior period, unchanged from 0001327567-23-000006:mdna:136]

[0001327567-23-000014:mdna:127]
The following table summarizes our cash flows for the nine months ended April 30, 2023 and 2022:

[0001327567-23-000014:mdna:128]
|  | Nine Months Ended April 30, |
|  | 2023 |  | 2022 |
|  | (in millions) |
| Net cash provided by operating activities | $ | 2,363.4 |  |  | $ | 1,461.0 |  |
| Net cash used in investing activities | (2,396.4) |  |  | (461.3) |  |
| Net cash used in financing activities | (91.5) |  |  | (453.5) |  |
| Net increase (decrease) in cash, cash equivalents, and restricted cash | $ | (124.5) |  |  | $ | 546.2 |  |

[0001327567-23-000014:mdna:129]
[same as prior period, unchanged from 0001327567-23-000006:mdna:141]

[0001327567-23-000014:mdna:130]
[same as prior period, unchanged from 0001327567-23-000006:mdna:142]

[0001327567-23-000014:mdna:131]
[same as prior period, unchanged from 0001327567-23-000006:mdna:143]

[0001327567-23-000014:mdna:132]
[same as prior period, unchanged from 0001327567-23-000006:mdna:144]

[0001327567-23-000014:mdna:133]
Cash provided by operating activities during the nine months ended April 30, 2023 was $2.4 billion, an increase of $902.4 million compared to the same period in 2022. The increase was primarily due to growth of our business as reflected by increases in collections during the nine months ended April 30, 2023, partially offset by a decrease in cash due to timing of payments and higher cash expenditure to support our business growth.

[0001327567-23-000014:mdna:134]
[same as prior period, unchanged from 0001327567-23-000006:mdna:146]

[0001327567-23-000014:mdna:135]
[same as prior period, unchanged from 0001327567-23-000006:mdna:147]

[0001327567-23-000014:mdna:136]
Cash used in investing activities during the nine months ended April 30, 2023 was $2.4 billion, an increase of $1.9 billion compared to the same period in 2022. The increase was primarily due to an increase in purchases of investments and increase in net cash payments for business acquisitions, offset by an increase in proceeds from sales and maturities of investments during the nine months ended April 30, 2023.

[0001327567-23-000014:mdna:137]
[same as prior period, unchanged from 0001327567-23-000006:mdna:149]

[0001327567-23-000014:mdna:138]
[same as prior period, unchanged from 0001327567-23-000006:mdna:150]

[0001327567-23-000014:mdna:139]
- 35 -

[0001327567-23-000014:mdna:140]
Cash used in financing activities during the nine months ended April 30, 2023 was $91.5 million, a decrease of $362.0 million compared to the same period in 2022. The decrease was primarily due to decrease in repurchases of our common stock during the nine months ended April 30, 2023.

[0001327567-23-000014:mdna:141]
[same as prior period, unchanged from 0001327567-23-000006:mdna:152]

[0001327567-23-000014:mdna:142]
[same as prior period, unchanged from 0001327567-23-000006:mdna:153]

[0001327567-23-000014:mdna:143]
[same as prior period, unchanged from 0001327567-23-000006:mdna:154]
