# PANW MD&A — 0001327567-19-000016


## mdna

[0001327567-19-000016:mdna:1]
[same as prior period, unchanged from 0001327567-19-000008:mdna:1]

[0001327567-19-000016:mdna:2]
[same as prior period, unchanged from 0001327567-19-000008:mdna:23]

[0001327567-19-000016:mdna:3]
these forward-looking statements, except as required by law. Given these risks and uncertainties, readers are cautioned not to place undue reliance on such forward-looking statements.

[0001327567-19-000016:mdna:4]
[same as prior period, unchanged from 0001327567-19-000008:mdna:2]

[0001327567-19-000016:mdna:5]
[same as prior period, unchanged from 0001327567-19-000008:mdna:3]

[0001327567-19-000016:mdna:6]
[same as prior period, unchanged from 0001327567-19-000008:mdna:4]

[0001327567-19-000016:mdna:7]
| • | Results of Operations. A discussion of the nature and trends in our financial results and an analysis of our financial results comparing the three and nine months ended April 30, 2019 to the three and nine months ended April 30, 2018. |

[0001327567-19-000016:mdna:8]
[same as prior period, unchanged from 0001327567-19-000008:mdna:6]

[0001327567-19-000016:mdna:9]
| • | Contractual Obligations and Commitments. An overview of our contractual obligations, contingent liabilities, commitments, and off-balance sheet arrangements outstanding as of April 30, 2019, including expected payment schedules. |

[0001327567-19-000016:mdna:10]
[same as prior period, unchanged from 0001327567-19-000008:mdna:8]

[0001327567-19-000016:mdna:11]
[same as prior period, unchanged from 0001327567-19-000008:mdna:9]

[0001327567-19-000016:mdna:12]
[same as prior period, unchanged from 0001327567-19-000008:mdna:10]

[0001327567-19-000016:mdna:13]
We have pioneered the next generation of security through our innovative Security Operating Platform that empowers enterprises, service providers, and government entities to secure their organizations by safely enabling applications and data running in their networks, on their endpoints, and in the cloud, and by preventing breaches that stem from targeted cyberattacks. Our platform uses an innovative traffic classification engine that identifies network traffic by application, user, and content and provides consistent security across the network, endpoint, and cloud. Accordingly, our platform enables our end-customers to pursue transformative digital initiatives, like public cloud and mobility, that grow their business, while maintaining the visibility and control needed to protect their valued data and critical control systems. We believe the architecture of our platform offers superior performance compared to legacy approaches and reduces the total cost of ownership for organizations by simplifying their security operations and infrastructure and eliminating the need for multiple, stand-alone hardware and software security products, and consists of three primary areas of security capabilities.

[0001327567-19-000016:mdna:14]
Secure the Enterprise:

[0001327567-19-000016:mdna:15]
| • | Secure the network through our Next-Generation Firewalls, available as physical appliances, virtual appliances called VM-Series, or a cloud-delivered service called Prisma Access (formerly GlobalProtect cloud service), and Panorama management delivered as an appliance or as a virtual machine for the public or private cloud. This also includes security services such as WildFire, Threat Prevention, URL Filtering, GlobalProtect, and DNS Security that are delivered as SaaS subscriptions to our Next-Generation Firewalls. |

[0001327567-19-000016:mdna:16]
| • | Secure the endpoints through our Traps advanced endpoint protection software, delivered as a light-weight software agent with cloud or on-premise management capabilities. |

[0001327567-19-000016:mdna:17]
Secure the Cloud:

[0001327567-19-000016:mdna:18]
| • | Secure the cloud through our Prisma cloud security offerings, such as Prisma Public Cloud (formerly RedLock) for infrastructure monitoring and compliance in public clouds, Prisma Access (formerly GlobalProtect cloud service) for securing access to the cloud for mobile and branch office workers, and Prisma SaaS (formerly Aperture) for protecting SaaS applications, as well as VM-Series for in-line protection of workloads in public and private clouds and Traps for host-based public cloud infrastructure protection. These products are delivered as software or SaaS subscriptions. |

[0001327567-19-000016:mdna:19]
Secure the Future:

[0001327567-19-000016:mdna:20]
| • | Secure the future of security operations through our Cortex open and integrated AI-based continuous security platform with applications and services such as AutoFocus, Cortex XDR (formerly Magnifier), Demisto, and Cortex Data Lake (formerly Logging Service) that are delivered as SaaS subscriptions. |

[0001327567-19-000016:mdna:21]
[same as prior period, unchanged from 0001327567-19-000008:mdna:34]

[0001327567-19-000016:mdna:22]
For the third quarter of fiscal 2019 and 2018, total revenue was $726.6 million and $567.7 million, respectively, representing year-over-year growth of 28.0%. Our growth reflects the increased adoption of our hybrid SaaS revenue model, which consists of product, subscriptions, and support. We believe this model will enable us to benefit from recurring revenues as we continue to grow our installed end-customer base. As of April 30, 2019, we had end-customers in over 150 countries. Our end-customers represent a broad range of industries, including education, energy, financial services, government entities, healthcare, Internet and media, manufacturing, public sector, and telecommunications, and include some of the largest Fortune 100 and Global 2000 companies in the world. We maintain a field sales force that works closely with our channel partners in developing sales opportunities. We use a two-tiered, indirect fulfillment model whereby we sell our products, subscriptions, and support to our distributors, which, in turn, sell to our resellers, which then sell to our end-customers.

[0001327567-19-000016:mdna:23]
Our product revenue was $278.4 million, or 38.3% of total revenue, for the third quarter of fiscal 2019, representing year-over-year growth of 27.6%. Product revenue is generated from sales of our appliances, primarily our Next-Generation Firewall, which is available in physical and virtualized form. Our Next-Generation Firewall incorporates our proprietary PAN-OS operating system, which provides a consistent set of capabilities across our entire product line. Our products are designed for different performance requirements throughout an organization, ranging from our PA-220, which is designed for small organizations and remote or branch offices, to our top-of-the-line PA-7080, which is especially suited for very large enterprise deployments and service provider customers. The same firewall functionality that is delivered in our physical appliances is also available in our VM-Series virtual firewalls, which secure virtualized and cloud-based computing environments.

[0001327567-19-000016:mdna:24]
Our subscription and support revenue was $448.2 million, or 61.7% of total revenue, for the third quarter of fiscal 2019, representing year-over-year growth of 28.2%. Our subscriptions provide our end-customers with real-time access to the latest antivirus, intrusion prevention, web filtering, and modern malware prevention capabilities across the network, endpoints, and the cloud. When end-customers purchase our physical or virtual firewall appliances, they typically purchase support in order to receive ongoing security updates, upgrades, bug fixes, and repairs. In addition to the subscriptions purchased with these appliances, end-customers may also purchase other subscriptions on a per-user, per-endpoint, or capacity-based basis.

[0001327567-19-000016:mdna:25]
We continue to invest in innovation as we evolve and further extend the capabilities of our platform, as we believe that innovation and timely development of new features and products is essential to meeting the needs of our end-customers and improving our competitive position. For example: in October 2018, we acquired RedLock, Inc. (“RedLock”), which expanded our security capabilities for the public cloud with the addition of RedLock’s cloud security analytics technology; in February 2019, we introduced PAN-OS 9.0, with over 60 new features, our new DNS Security Service subscription, which uses machine learning to proactively block malicious domains and stop attacks in progress, and Cortex XDR, our cloud-based detection, investigation, and response application that natively integrates network, endpoint, and cloud data; and in March 2019, we acquired Demisto, Inc. (“Demisto”), which expanded the functionality of our platform with the addition of Demisto’s security orchestration, automation, and response product.

[0001327567-19-000016:mdna:26]
[same as prior period, unchanged from 0001327567-19-000008:mdna:22]

[0001327567-19-000016:mdna:27]
[same as prior period, unchanged from 0001327567-19-000008:mdna:24]

[0001327567-19-000016:mdna:28]
[same as prior period, unchanged from 0001327567-19-000008:mdna:25]

[0001327567-19-000016:mdna:29]
|  | April 30, 2019 |  | July 31, 2018 |
|  | (in millions) |
| Total deferred revenue(1) | $ | 2,632.2 |  |  | $ | 2,279.3 |  |
| Cash, cash equivalents, and investments | $ | 3,718.0 |  |  | $ | 3,950.9 |  |

[0001327567-19-000016:mdna:30]
[same as prior period, unchanged from 0001327567-19-000008:mdna:27]

[0001327567-19-000016:mdna:31]
[same as prior period, unchanged from 0001327567-19-000008:mdna:28]

[0001327567-19-000016:mdna:32]
[same as prior period, unchanged from 0001327567-19-000008:mdna:43]

[0001327567-19-000016:mdna:33]
|  | Three Months Ended April 30, |  | Nine Months Ended April 30, |
|  | 2019 |  | 2018(1) |  | 2019 |  | 2018(1) |
|  | (dollars in millions) |
| Total revenue | $ | 726.6 |  |  | $ | 567.7 |  |  | $ | 2,093.8 |  |  | $ | 1,615.1 |  |
| Total revenue year-over-year percentage increase | 28.0 | % |  | 32.5 | % |  | 29.6 | % |  | 29.5 | % |
| Gross margin | 71.8 | % |  | 71.8 | % |  | 71.8 | % |  | 71.5 | % |
| Operating loss | $ | (18.7 | ) |  | $ | (45.3 | ) |  | $ | (44.2 | ) |  | $ | (121.3 | ) |
| Operating margin | (2.6 | )% |  | (8.0 | )% |  | (2.1 | )% |  | (7.5 | )% |
| Billings | $ | 821.9 |  |  | $ | 724.7 |  |  | $ | 2,432.9 |  |  | $ | 1,993.3 |  |
| Billings year-over-year percentage increase | 13.4 | % |  | 32.7 | % |  | 22.1 | % |  | 26.1 | % |
| Cash flow provided by operating activities |  |  |  |  | $ | 824.1 |  |  | $ | 760.5 |  |
| Free cash flow (non-GAAP) |  |  |  |  | $ | 746.0 |  |  | $ | 673.9 |  |

[0001327567-19-000016:mdna:34]
[same as prior period, unchanged from 0001327567-19-000008:mdna:30]

[0001327567-19-000016:mdna:35]
[same as prior period, unchanged from 0001327567-19-000008:mdna:31]

[0001327567-19-000016:mdna:36]
[same as prior period, unchanged from 0001327567-19-000008:mdna:32]

[0001327567-19-000016:mdna:37]
[same as prior period, unchanged from 0001327567-19-000008:mdna:33]

[0001327567-19-000016:mdna:38]
|  | Three Months Ended April 30, |  | Nine Months Ended April 30, |
|  | 2019 |  | 2018(1) |  | 2019 |  | 2018(1) |
|  | (in millions) |
| Billings: |  |  |  |  |  |  |  |
| Total revenue | $ | 726.6 |  |  | $ | 567.7 |  |  | $ | 2,093.8 |  |  | $ | 1,615.1 |  |
| Add: change in total deferred revenue, net of acquired deferred revenue | 95.3 |  |  | 157.0 |  |  | 339.1 |  |  | 378.2 |  |
| Billings | $ | 821.9 |  |  | $ | 724.7 |  |  | $ | 2,432.9 |  |  | $ | 1,993.3 |  |

[0001327567-19-000016:mdna:39]
[same as prior period, unchanged from 0001327567-19-000008:mdna:36]

[0001327567-19-000016:mdna:40]
[same as prior period, unchanged from 0001327567-19-000008:mdna:37]

[0001327567-19-000016:mdna:41]
[same as prior period, unchanged from 0001327567-19-000008:mdna:38]

[0001327567-19-000016:mdna:42]
[same as prior period, unchanged from 0001327567-19-000008:mdna:51]

[0001327567-19-000016:mdna:43]
[same as prior period, unchanged from 0001327567-19-000008:mdna:39]

[0001327567-19-000016:mdna:44]
|  | Nine Months Ended April 30, |
|  | 2019 |  | 2018 |
|  | (in millions) |
| Free cash flow (non-GAAP): |  |  |  |
| Net cash provided by operating activities(1) | $ | 824.1 |  |  | $ | 760.5 |  |
| Less: purchases of property, equipment, and other assets | 78.1 |  |  | 86.6 |  |
| Free cash flow (non-GAAP)(1) | $ | 746.0 |  |  | $ | 673.9 |  |
| Net cash used in investing activities | $ | (1,377.2 | ) |  | $ | (313.6 | ) |
| Net cash used in financing activities | $ | (637.8 | ) |  | $ | (240.8 | ) |

[0001327567-19-000016:mdna:45]
[same as prior period, unchanged from 0001327567-19-000008:mdna:41]

[0001327567-19-000016:mdna:46]
[same as prior period, unchanged from 0001327567-19-000008:mdna:42]

[0001327567-19-000016:mdna:47]
[same as prior period, unchanged from 0001327567-19-000008:mdna:66]

[0001327567-19-000016:mdna:48]
[same as prior period, unchanged from 0001327567-19-000008:mdna:44]

[0001327567-19-000016:mdna:49]
[same as prior period, unchanged from 0001327567-19-000008:mdna:45]

[0001327567-19-000016:mdna:50]
|  | Three Months Ended April 30, |  | Nine Months Ended April 30, |
|  | 2019 |  | 2018(1) |  | 2019 |  | 2018(1) |
|  | Amount |  | % of Revenue |  | Amount |  | % of Revenue |  | Amount |  | % of Revenue |  | Amount |  | % of Revenue |
|  | (dollars in millions) |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product | $ | 278.4 |  |  | 38.3 | % |  | $ | 218.1 |  |  | 38.4 | % |  | $ | 790.5 |  |  | 37.8 | % |  | $ | 607.7 |  |  | 37.6 | % |
| Subscription and support | 448.2 |  |  | 61.7 | % |  | 349.6 |  |  | 61.6 | % |  | 1,303.3 |  |  | 62.2 | % |  | 1,007.4 |  |  | 62.4 | % |
| Total revenue | 726.6 |  |  | 100.0 | % |  | 567.7 |  |  | 100.0 | % |  | 2,093.8 |  |  | 100.0 | % |  | 1,615.1 |  |  | 100.0 | % |
| Cost of revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product | 78.0 |  |  | 10.7 | % |  | 68.9 |  |  | 12.1 | % |  | 233.7 |  |  | 11.2 | % |  | 190.4 |  |  | 11.8 | % |
| Subscription and support | 126.9 |  |  | 17.5 | % |  | 91.0 |  |  | 16.1 | % |  | 357.3 |  |  | 17.0 | % |  | 270.2 |  |  | 16.7 | % |
| Total cost of revenue(2) | 204.9 |  |  | 28.2 | % |  | 159.9 |  |  | 28.2 | % |  | 591.0 |  |  | 28.2 | % |  | 460.6 |  |  | 28.5 | % |
| Total gross profit | 521.7 |  |  | 71.8 | % |  | 407.8 |  |  | 71.8 | % |  | 1,502.8 |  |  | 71.8 | % |  | 1,154.5 |  |  | 71.5 | % |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Research and development | 139.1 |  |  | 19.1 | % |  | 99.6 |  |  | 17.5 | % |  | 380.8 |  |  | 18.2 | % |  | 290.4 |  |  | 18.0 | % |
| Sales and marketing | 339.0 |  |  | 46.7 | % |  | 271.4 |  |  | 47.8 | % |  | 973.6 |  |  | 46.5 | % |  | 784.3 |  |  | 48.5 | % |
| General and administrative | 62.3 |  |  | 8.6 | % |  | 82.1 |  |  | 14.5 | % |  | 192.6 |  |  | 9.2 | % |  | 201.1 |  |  | 12.5 | % |
| Total operating expenses(2) | 540.4 |  |  | 74.4 | % |  | 453.1 |  |  | 79.8 | % |  | 1,547.0 |  |  | 73.9 | % |  | 1,275.8 |  |  | 79.0 | % |
| Operating loss | (18.7 | ) |  | (2.6 | )% |  | (45.3 | ) |  | (8.0 | )% |  | (44.2 | ) |  | (2.1 | )% |  | (121.3 | ) |  | (7.5 | )% |
| Interest expense | (20.6 | ) |  | (2.8 | )% |  | (6.5 | ) |  | (1.1 | )% |  | (63.9 | ) |  | (3.1 | )% |  | (19.2 | ) |  | (1.2 | )% |
| Other income, net | 18.2 |  |  | 2.5 | % |  | 8.6 |  |  | 1.5 | % |  | 47.2 |  |  | 2.3 | % |  | 18.3 |  |  | 1.1 | % |
| Loss before income taxes | (21.1 | ) |  | (2.9 | )% |  | (43.2 | ) |  | (7.6 | )% |  | (60.9 | ) |  | (2.9 | )% |  | (122.2 | ) |  | (7.6 | )% |
| Provision for (benefit from) income taxes | (0.9 | ) |  | (0.1 | )% |  | (2.8 | ) |  | (0.5 | )% |  | 0.2 |  |  | — | % |  | 7.0 |  |  | 0.4 | % |
| Net loss | $ | (20.2 | ) |  | (2.8 | )% |  | $ | (40.4 | ) |  | (7.1 | )% |  | $ | (61.1 | ) |  | (2.9 | )% |  | $ | (129.2 | ) |  | (8.0 | )% |

[0001327567-19-000016:mdna:51]
[same as prior period, unchanged from 0001327567-19-000008:mdna:47]

[0001327567-19-000016:mdna:52]
[same as prior period, unchanged from 0001327567-19-000008:mdna:48]

[0001327567-19-000016:mdna:53]
[same as prior period, unchanged from 0001327567-19-000008:mdna:49]

[0001327567-19-000016:mdna:54]
|  | Three Months Ended April 30, |  | Nine Months Ended April 30, |
|  | 2019 |  | 2018 |  | 2019 |  | 2018 |
|  | (in millions) |
| Cost of product revenue | $ | 1.3 |  |  | $ | 1.7 |  |  | $ | 4.3 |  |  | $ | 5.5 |  |
| Cost of subscription and support revenue | 17.2 |  |  | 15.1 |  |  | 52.9 |  |  | 50.9 |  |
| Research and development | 45.1 |  |  | 35.4 |  |  | 129.6 |  |  | 108.4 |  |
| Sales and marketing | 54.5 |  |  | 50.7 |  |  | 169.2 |  |  | 155.2 |  |
| General and administrative | 20.1 |  |  | 20.8 |  |  | 75.7 |  |  | 60.2 |  |
| Total share-based compensation | $ | 138.2 |  |  | $ | 123.7 |  |  | $ | 431.7 |  |  | $ | 380.2 |  |

[0001327567-19-000016:mdna:55]
[same as prior period, unchanged from 0001327567-19-000008:mdna:78]

[0001327567-19-000016:mdna:56]
[same as prior period, unchanged from 0001327567-19-000008:mdna:52]

[0001327567-19-000016:mdna:57]
[same as prior period, unchanged from 0001327567-19-000008:mdna:53]

[0001327567-19-000016:mdna:58]
[same as prior period, unchanged from 0001327567-19-000008:mdna:54]

[0001327567-19-000016:mdna:59]
[same as prior period, unchanged from 0001327567-19-000008:mdna:55]

[0001327567-19-000016:mdna:60]
|  | Three Months Ended April 30, |  |  |  |  |  | Nine Months Ended April 30, |  |  |  |  |
|  | 2019 |  | 2018(1) |  | Change |  | 2019 |  | 2018(1) |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| Product | $ | 278.4 |  |  | $ | 218.1 |  |  | $ | 60.3 |  |  | 27.6 | % |  | $ | 790.5 |  |  | $ | 607.7 |  |  | $ | 182.8 |  |  | 30.1 | % |

[0001327567-19-000016:mdna:61]
[same as prior period, unchanged from 0001327567-19-000008:mdna:57]

[0001327567-19-000016:mdna:62]
[same as prior period, unchanged from 0001327567-19-000008:mdna:58]

[0001327567-19-000016:mdna:63]
Product revenue increased for the three and nine months ended April 30, 2019 compared to the three and nine months ended April 30, 2018. The increase in both periods was primarily due to increased demand for our appliances. The change in product revenue due to pricing was not significant for either period.

[0001327567-19-000016:mdna:64]
[same as prior period, unchanged from 0001327567-19-000008:mdna:60]

[0001327567-19-000016:mdna:65]
[same as prior period, unchanged from 0001327567-19-000008:mdna:61]

[0001327567-19-000016:mdna:66]
|  | Three Months Ended April 30, |  |  |  |  |  | Nine Months Ended April 30, |  |  |  |  |
|  | 2019 |  | 2018(1) |  | Change |  | 2019 |  | 2018(1) |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| Subscription | $ | 258.8 |  |  | $ | 192.0 |  |  | $ | 66.8 |  |  | 34.8 | % |  | $ | 739.8 |  |  | $ | 544.3 |  |  | $ | 195.5 |  |  | 35.9 | % |
| Support | 189.4 |  |  | 157.6 |  |  | 31.8 |  |  | 20.2 | % |  | 563.5 |  |  | 463.1 |  |  | 100.4 |  |  | 21.7 | % |
| Total subscription and support | $ | 448.2 |  |  | $ | 349.6 |  |  | $ | 98.6 |  |  | 28.2 | % |  | $ | 1,303.3 |  |  | $ | 1,007.4 |  |  | $ | 295.9 |  |  | 29.4 | % |

[0001327567-19-000016:mdna:67]
[same as prior period, unchanged from 0001327567-19-000008:mdna:63]

[0001327567-19-000016:mdna:68]
[same as prior period, unchanged from 0001327567-19-000008:mdna:64]

[0001327567-19-000016:mdna:69]
Subscription and support revenue increased for the three and nine months ended April 30, 2019 compared to the three and nine months ended April 30, 2018. The increase in both periods was due to increased demand for our subscription and support offerings from both new and existing end-customers. The mix between subscription revenue and support revenue will fluctuate over time, depending on the introduction of new subscription offerings, renewals of support services, and our ability to increase sales to new and existing customers. The change in subscription and support revenue due to changes in pricing was not significant for either period.

[0001327567-19-000016:mdna:70]
[same as prior period, unchanged from 0001327567-19-000008:mdna:91]

[0001327567-19-000016:mdna:71]
[same as prior period, unchanged from 0001327567-19-000008:mdna:67]

[0001327567-19-000016:mdna:72]
|  | Three Months Ended April 30, |  |  |  |  |  | Nine Months Ended April 30, |  |  |  |  |
|  | 2019 |  | 2018(1) |  | Change |  | 2019 |  | 2018(1) |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| Americas | $ | 497.8 |  |  | $ | 387.7 |  |  | $ | 110.1 |  |  | 28.4 | % |  | $ | 1,423.0 |  |  | $ | 1,110.3 |  |  | $ | 312.7 |  |  | 28.2 | % |
| EMEA | 138.7 |  |  | 110.1 |  |  | 28.6 |  |  | 26.0 | % |  | 414.7 |  |  | 312.0 |  |  | 102.7 |  |  | 32.9 | % |
| APAC | 90.1 |  |  | 69.9 |  |  | 20.2 |  |  | 28.9 | % |  | 256.1 |  |  | 192.8 |  |  | 63.3 |  |  | 32.8 | % |
| Total revenue | $ | 726.6 |  |  | $ | 567.7 |  |  | $ | 158.9 |  |  | 28.0 | % |  | $ | 2,093.8 |  |  | $ | 1,615.1 |  |  | $ | 478.7 |  |  | 29.6 | % |

[0001327567-19-000016:mdna:73]
[same as prior period, unchanged from 0001327567-19-000008:mdna:69]

[0001327567-19-000016:mdna:74]
[same as prior period, unchanged from 0001327567-19-000008:mdna:70]

[0001327567-19-000016:mdna:75]
With respect to geographic theaters, the Americas contributed the largest portion of the increase in revenue for the three and nine months ended April 30, 2019 compared to the three and nine months ended April 30, 2018, due to its larger and more established sales force compared to our other theaters. Revenue from both Europe, the Middle East, and Africa (“EMEA”) and Asia Pacific and Japan (“APAC”) increased for the three and nine months ended April 30, 2019 compared to the three and nine months ended April 30, 2018, due to our investment in increasing the size of our sales force and number of channel partners in these theaters.

[0001327567-19-000016:mdna:76]
[same as prior period, unchanged from 0001327567-19-000008:mdna:72]

[0001327567-19-000016:mdna:77]
[same as prior period, unchanged from 0001327567-19-000008:mdna:73]

[0001327567-19-000016:mdna:78]
[same as prior period, unchanged from 0001327567-19-000008:mdna:74]

[0001327567-19-000016:mdna:79]
[same as prior period, unchanged from 0001327567-19-000008:mdna:75]

[0001327567-19-000016:mdna:80]
|  | Three Months Ended April 30, |  |  |  | Nine Months Ended April 30, |  |  |  |  |
|  | 2019 |  | 2018 |  | Change |  | 2019 |  | 2018 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| Cost of product revenue | $ | 78.0 |  |  | $ | 68.9 |  |  | $ | 9.1 |  |  | 13.2 | % |  | $ | 233.7 |  |  | $ | 190.4 |  |  | $ | 43.3 |  |  | 22.7 | % |
| Number of employees at period end | 99 |  |  | 92 |  |  | 7 |  |  | 7.6 | % |  | 99 |  |  | 92 |  |  | 7 |  |  | 7.6 | % |

[0001327567-19-000016:mdna:81]
Cost of product revenue increased for the three and nine months ended April 30, 2019 compared to the three and nine months ended April 30, 2018. The increase in both periods was primarily due to an increase in product unit volume.

[0001327567-19-000016:mdna:82]
[same as prior period, unchanged from 0001327567-19-000008:mdna:101]

[0001327567-19-000016:mdna:83]
[same as prior period, unchanged from 0001327567-19-000008:mdna:79]

[0001327567-19-000016:mdna:84]
[same as prior period, unchanged from 0001327567-19-000008:mdna:80]

[0001327567-19-000016:mdna:85]
|  | Three Months Ended April 30, |  |  |  | Nine Months Ended April 30, |  |  |  |  |
|  | 2019 |  | 2018 |  | Change |  | 2019 |  | 2018 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| Cost of subscription and support revenue(1) | $ | 126.9 |  |  | $ | 91.0 |  |  | $ | 35.9 |  |  | 39.5 | % |  | $ | 357.3 |  |  | $ | 270.2 |  |  | $ | 87.1 |  |  | 32.2 | % |
| Number of employees at period end | 1,114 |  |  | 895 |  |  | 219 |  |  | 24.5 | % |  | 1,114 |  |  | 895 |  |  | 219 |  |  | 24.5 | % |

[0001327567-19-000016:mdna:86]
[same as prior period, unchanged from 0001327567-19-000008:mdna:82]

[0001327567-19-000016:mdna:87]
[same as prior period, unchanged from 0001327567-19-000008:mdna:83]

[0001327567-19-000016:mdna:88]
Cost of subscription and support revenue increased for the three and nine months ended April 30, 2019 compared to the three and nine months ended April 30, 2018. The increase in both periods was primarily due to increased costs to support the growth of our subscription and support business. Personnel costs grew $15.5 million to $66.0 million for the three months ended April 30, 2019 compared to the three months ended April 30, 2018, and grew $35.7 million to $187.6 million for the nine months ended April 30, 2019 compared to the nine months ended April 30, 2018, primarily due to headcount growth. Amortization of purchased intangible assets increased $7.3 million for the three months ended April 30, 2019 compared to the three months ended April 30, 2018, and increased $18.7 million for the nine months ended April 30, 2019 compared to the nine months ended April 30, 2018, as a result of our recent acquisitions. The remaining increase in both periods was primarily due to an increase in data center and cloud hosting costs to support the adoption of our cloud-based subscription offerings and costs to expand our customer service capabilities.

[0001327567-19-000016:mdna:89]
[same as prior period, unchanged from 0001327567-19-000008:mdna:85]

[0001327567-19-000016:mdna:90]
[same as prior period, unchanged from 0001327567-19-000008:mdna:86]

[0001327567-19-000016:mdna:91]
|  | Three Months Ended April 30, |  | Nine Months Ended April 30, |
|  | 2019 |  | 2018(1) |  | 2019 |  | 2018(1) |
|  | Amount |  | Gross Margin |  | Amount |  | Gross Margin |  | Amount |  | Gross Margin |  | Amount |  | Gross Margin |
|  | (dollars in millions) |
| Product | $ | 200.4 |  |  | 72.0 | % |  | $ | 149.2 |  |  | 68.4 | % |  | $ | 556.8 |  |  | 70.4 | % |  | $ | 417.3 |  |  | 68.7 | % |
| Subscription and support | 321.3 |  |  | 71.7 | % |  | 258.6 |  |  | 74.0 | % |  | 946.0 |  |  | 72.6 | % |  | 737.2 |  |  | 73.2 | % |
| Total gross profit | $ | 521.7 |  |  | 71.8 | % |  | $ | 407.8 |  |  | 71.8 | % |  | $ | 1,502.8 |  |  | 71.8 | % |  | $ | 1,154.5 |  |  | 71.5 | % |

[0001327567-19-000016:mdna:92]
[same as prior period, unchanged from 0001327567-19-000008:mdna:88]

[0001327567-19-000016:mdna:93]
[same as prior period, unchanged from 0001327567-19-000008:mdna:89]

[0001327567-19-000016:mdna:94]
Product gross margin increased for the three and nine months ended April 30, 2019 compared to the three and nine months ended April 30, 2018, primarily due to improved operations in our supply chain management and increased leverage of our operations organization.

[0001327567-19-000016:mdna:95]
[same as prior period, unchanged from 0001327567-19-000008:mdna:110]

[0001327567-19-000016:mdna:96]
Subscription and support gross margin decreased for the three and nine months ended April 30, 2019 compared to the three and nine months ended April 30, 2018, primarily due to higher costs to support the adoption of our cloud-based subscription offerings, partially offset by increased leverage of our global customer support organization.

[0001327567-19-000016:mdna:97]
[same as prior period, unchanged from 0001327567-19-000008:mdna:93]

[0001327567-19-000016:mdna:98]
Our operating expenses consist of research and development, sales and marketing, and general and administrative expense. Personnel costs are the most significant component of operating expenses and consist of salaries, benefits, bonuses, share-based compensation, travel and entertainment, and with regard to sales and marketing expense, sales commissions. Our operating expenses also include allocated costs, which consist of certain facilities, depreciation, benefits, recruiting, and information technology costs that we allocate based on headcount. We expect operating expenses to increase in absolute dollars and decrease over the long term as a percentage of revenue as we continue to scale our business. As of April 30, 2019, we expect to recognize approximately $1.4 billion of share-based compensation expense over a weighted-average period of approximately 2.8 years, excluding additional share-based compensation expense related to any future grants of share-based awards. Share-based compensation expense is generally recognized on a straight-line basis over the requisite service periods of the awards.

[0001327567-19-000016:mdna:99]
[same as prior period, unchanged from 0001327567-19-000008:mdna:95]

[0001327567-19-000016:mdna:100]
[same as prior period, unchanged from 0001327567-19-000008:mdna:96]

[0001327567-19-000016:mdna:101]
|  | Three Months Ended April 30, |  |  |  |  |  | Nine Months Ended April 30, |  |  |  |  |
|  | 2019 |  | 2018 |  | Change |  | 2019 |  | 2018 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| Research and development | $ | 139.1 |  |  | $ | 99.6 |  |  | $ | 39.5 |  |  | 39.7 | % |  | $ | 380.8 |  |  | $ | 290.4 |  |  | $ | 90.4 |  |  | 31.1 | % |
| Number of employees at period end | 1,336 |  |  | 899 |  |  | 437 |  |  | 48.6 | % |  | 1,336 |  |  | 899 |  |  | 437 |  |  | 48.6 | % |

[0001327567-19-000016:mdna:102]
Research and development expense increased for the three and nine months ended April 30, 2019 compared to the three and nine months ended April 30, 2018. The increase in both periods was primarily due to an increase in personnel costs, which grew $29.1 million to $111.5 million for the three months ended April 30, 2019 compared to the three months ended April 30, 2018, and grew $67.4 million to $308.3 million for the nine months ended April 30, 2019 compared to the nine months ended April 30, 2018. The increase in personnel costs in both periods was largely due to headcount growth. The remaining increase in both periods was primarily driven by an increase in allocated costs.

[0001327567-19-000016:mdna:103]
[same as prior period, unchanged from 0001327567-19-000008:mdna:99]

[0001327567-19-000016:mdna:104]
[same as prior period, unchanged from 0001327567-19-000008:mdna:100]

[0001327567-19-000016:mdna:105]
[same as prior period, unchanged from 0001327567-19-000008:mdna:119]

[0001327567-19-000016:mdna:106]
|  | Three Months Ended April 30, |  |  |  |  |  | Nine Months Ended April 30, |  |  |  |  |
|  | 2019 |  | 2018 |  | Change |  | 2019 |  | 2018 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| Sales and marketing(1) | $ | 339.0 |  |  | $ | 271.4 |  |  | $ | 67.6 |  |  | 24.9 | % |  | $ | 973.6 |  |  | $ | 784.3 |  |  | $ | 189.3 |  |  | 24.1 | % |
| Number of employees at period end | 3,194 |  |  | 2,599 |  |  | 595 |  |  | 22.9 | % |  | 3,194 |  |  | 2,599 |  |  | 595 |  |  | 22.9 | % |

[0001327567-19-000016:mdna:107]
[same as prior period, unchanged from 0001327567-19-000008:mdna:103]

[0001327567-19-000016:mdna:108]
[same as prior period, unchanged from 0001327567-19-000008:mdna:104]

[0001327567-19-000016:mdna:109]
Sales and marketing expense increased for the three and nine months ended April 30, 2019 compared to the three and nine months ended April 30, 2018. The increase in both periods was primarily due to an increase in personnel costs, which grew $45.4 million to $255.9 million for the three months ended April 30, 2019 compared to the three months ended April 30, 2018, and grew $119.6 million to $727.1 million for the nine months ended April 30, 2019 compared to the nine months ended April 30, 2018. The increase in personnel costs in both periods was largely due to headcount growth. The remaining increase in both periods was primarily driven by an increase in allocated costs and an increase in costs associated with marketing-related activities.

[0001327567-19-000016:mdna:110]
[same as prior period, unchanged from 0001327567-19-000008:mdna:106]

[0001327567-19-000016:mdna:111]
[same as prior period, unchanged from 0001327567-19-000008:mdna:107]

[0001327567-19-000016:mdna:112]
|  | Three Months Ended April 30, |  |  |  |  |  | Nine Months Ended April 30, |  |  |  |  |
|  | 2019 |  | 2018 |  | Change |  | 2019 |  | 2018 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| General and administrative | $ | 62.3 |  |  | $ | 82.1 |  |  | $ | (19.8 | ) |  | (24.1 | )% |  | $ | 192.6 |  |  | $ | 201.1 |  |  | $ | (8.5 | ) |  | (4.2 | )% |
| Number of employees at period end | 760 |  |  | 636 |  |  | 124 |  |  | 19.5 | % |  | 760 |  |  | 636 |  |  | 124 |  |  | 19.5 | % |

[0001327567-19-000016:mdna:113]
General and administrative expense decreased for the three months ended April 30, 2019 compared to the three months ended April 30, 2018, primarily due to a net decrease of $19.7 million in cease-use losses recognized on the lease of our previous corporate headquarter facilities. The remaining decrease was primarily driven by a decrease in costs related to business acquisitions, offset by an increase in personnel costs, which grew $8.2 million to $39.0 million for the three months ended April 30, 2019 compared to the three months ended April 30, 2018, largely due to headcount growth.

[0001327567-19-000016:mdna:114]
General and administrative expense decreased for the nine months ended April 30, 2019 compared to the nine months ended April 30, 2018, primarily due to a net decrease of $35.1 million in cease-use losses recognized on the lease of our previous corporate headquarter facilities. The decrease was partially offset by an increase in personnel costs, which grew $24.4 million to $128.9 million for the nine months ended April 30, 2019 compared to the nine months ended April 30, 2018, primarily due to headcount growth and expense related to the accelerated vesting of certain equity awards in connection with the RedLock acquisition of $14.2 million recognized during the three months ended October 31, 2018.

[0001327567-19-000016:mdna:115]
[same as prior period, unchanged from 0001327567-19-000008:mdna:131]

[0001327567-19-000016:mdna:116]
[same as prior period, unchanged from 0001327567-19-000008:mdna:111]

[0001327567-19-000016:mdna:117]
Interest expense primarily consists of non-cash interest expense from the amortization of the debt discount and debt issuance costs related to our 0.0% Convertible Senior Notes due 2019 (the “2019 Notes”) and 0.75% Convertible Senior Notes due 2023 (the “2023 Notes” and, together with the 2019 Notes, the “Notes”), and also includes the contractual interest expense related to our 2023 Notes.

[0001327567-19-000016:mdna:118]
|  | Three Months Ended April 30, |  |  |  | Nine Months Ended April 30, |  |  |
|  | 2019 |  | 2018 |  | Change |  | 2019 |  | 2018 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| Interest expense | $ | 20.6 |  |  | $ | 6.5 |  |  | $ | 14.1 |  |  | 216.9 | % |  | $ | 63.9 |  |  | $ | 19.2 |  |  | $ | 44.7 |  |  | 232.8 | % |

[0001327567-19-000016:mdna:119]
Interest expense increased for the three and nine months ended April 30, 2019 compared to the three and nine months ended April 30, 2018. The increase in both periods was primarily due to interest expense recognized on the 2023 Notes issued in July 2018, partially offset by a reduction in interest expense recognized on the 2019 Notes due to early conversions. We expect interest expense to increase in fiscal 2019 due to interest expense to be incurred on the 2023 Notes. Refer to Note 9. Debt in Part I, Item 1 of this Quarterly Report on Form 10-Q for more information on the Notes.

[0001327567-19-000016:mdna:120]
[same as prior period, unchanged from 0001327567-19-000008:mdna:115]

[0001327567-19-000016:mdna:121]
[same as prior period, unchanged from 0001327567-19-000008:mdna:116]

[0001327567-19-000016:mdna:122]
|  | Three Months Ended April 30, |  |  |  | Nine Months Ended April 30, |  |  |
|  | 2019 |  | 2018 |  | Change |  | 2019 |  | 2018 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| Other income, net | $ | 18.2 |  |  | $ | 8.6 |  |  | $ | 9.6 |  |  | 111.6 | % |  | $ | 47.2 |  |  | $ | 18.3 |  |  | $ | 28.9 |  |  | 157.9 | % |

[0001327567-19-000016:mdna:123]
Other income, net increased for the three and nine months ended April 30, 2019 compared to the three and nine months ended April 30, 2018. The increase in both periods was primarily driven by an increase in interest income, which grew $11.6 million for the three months ended April 30, 2019 compared to the three months ended April 30, 2018, and grew $34.0 million for the nine months ended April 30, 2019 compared to the nine months ended April 30, 2018. The increase in interest income was largely due to higher cash, cash equivalents, and investments balances and higher yields on these balances during the three and nine months ended April 30, 2019 compared to the three and nine months ended April 30, 2018. The increase in interest income for the three months ended April 30, 2019 was partially offset by an increase in foreign currency remeasurement losses. The increase in interest income for the nine months ended April 30, 2019 was partially offset by a loss of $2.6 million recognized related to the settlement of the 2019 Notes. Refer to Note 9. Debt in Part I, Item 1 of this Quarterly Report on Form 10-Q for more information on the Notes.

[0001327567-19-000016:mdna:124]
[same as prior period, unchanged from 0001327567-19-000008:mdna:144]

[0001327567-19-000016:mdna:125]
Provision for (Benefit from) Income Taxes

[0001327567-19-000016:mdna:126]
Provision for (benefit from) income taxes consists primarily of income taxes in foreign jurisdictions in which we conduct business, withholding taxes, and U.S. state income taxes. We maintain a full valuation allowance for domestic and certain foreign deferred tax assets, including net operating loss carryforwards and certain domestic tax credits. In recent years, we reorganized our corporate structure and intercompany relationships to more closely align with the international nature of our business activities. Our corporate structure has caused, and may continue to cause, disproportionate relationships between our overall effective tax rate and other jurisdictional measures. To the extent we revisit our corporate structure, it may have an impact on our tax provision.

[0001327567-19-000016:mdna:127]
|  | Three Months Ended April 30, |  | Change |  | Nine Months Ended April 30, |  | Change |
|  | 2019 |  | 2018 |  | Amount |  | % |  | 2019 |  | 2018 |  | Amount |  | % |
|  | (dollars in millions) |
| Provision for (benefit from) income taxes | $ | (0.9 | ) |  | $ | (2.8 | ) |  | $ | 1.9 |  |  | (67.9 | )% |  | $ | 0.2 |  |  | $ | 7.0 |  |  | $ | (6.8 | ) |  | (97.1 | )% |
| Effective tax rate | 4.3 | % |  | 6.5 | % |  |  |  |  |  |  | (0.3 | )% |  | (5.7 | )% |  |  |  |  |  |

[0001327567-19-000016:mdna:128]
We recorded an income tax benefit and an income tax provision for the three and nine months ended April 30, 2019, respectively. Key components of our provision for income taxes, excluding one-time items, include foreign and U.S. state income taxes and withholding taxes. Our provision for income taxes increased for the three months ended April 30, 2019 compared to the three months ended April 30, 2018, primarily due to a one-time tax benefit of $3.5 million recognized during the three months ended April 30, 2018 from an Israeli judicial ruling related to share-based compensation. Our provision for income taxes decreased for the nine months ended April 30, 2019 compared to the nine months ended April 30, 2018, primarily due to one-time tax benefits related to our acquisitions. Refer to Note 13. Income Taxes in Part I, Item 1 of this Quarterly Report on Form 10-Q for more information.

[0001327567-19-000016:mdna:129]
[same as prior period, unchanged from 0001327567-19-000008:mdna:124]

[0001327567-19-000016:mdna:130]
|  | April 30, 2019 |  | July 31, 2018 |
|  | (in millions) |
| Working capital(1)(2) | $ | 1,718.7 |  |  | $ | 2,036.8 |  |
| Cash, cash equivalents, and investments: |  |  |  |
| Cash and cash equivalents | $ | 1,314.9 |  |  | $ | 2,506.9 |  |
| Investments | 2,403.1 |  |  | 1,444.0 |  |
| Total cash, cash equivalents, and investments | $ | 3,718.0 |  |  | $ | 3,950.9 |  |

[0001327567-19-000016:mdna:131]
[same as prior period, unchanged from 0001327567-19-000008:mdna:126]

[0001327567-19-000016:mdna:132]
[same as prior period, unchanged from 0001327567-19-000008:mdna:127]

[0001327567-19-000016:mdna:133]
| (2) | The net carrying amount of the 0.0% Convertible Senior Notes due 2019 (the “2019 Notes”) was classified in current liabilities in our condensed consolidated balance sheets as of April 30, 2019 and July 31, 2018, respectively. Refer to Note 9. Debt in Part I, Item 1 of this Quarterly Report on Form 10-Q for more information. |

[0001327567-19-000016:mdna:134]
As of April 30, 2019, our total cash, cash equivalents, and investments of $3.7 billion were held for general corporate purposes, of which approximately $375.0 million was held outside of the United States. As of April 30, 2019, we had no unremitted earnings when evaluating our outside basis difference relating to our U.S. investment in foreign subsidiaries. However, there could be local withholding taxes payable due to various foreign countries if certain lower tier earnings are distributed. Withholding taxes that would be payable upon remittance of these lower tier earnings were not material as of April 30, 2019.

[0001327567-19-000016:mdna:135]
In June 2014, we issued the 2019 Notes with an aggregate principal amount of $575.0 million and in July 2018, we issued the 2023 Notes with an aggregate principal amount of $1.7 billion. As of April 30, 2019, $159.4 million of the 2019 Notes remained outstanding and all of the 2023 Notes remained outstanding. The 2019 Notes and the 2023 Notes mature on July 1, 2019 and July 1, 2023, respectively; however, under certain circumstances, holders may surrender their Notes of a series for conversion prior to the applicable maturity dates. Upon conversion of the Notes of a series, we will pay cash equal to the aggregate principal amount of the Notes of such series to be converted, and, at our election, will pay or deliver cash and/or shares of our common stock for the amount of our conversion obligation in excess of the aggregate principal amount of the Notes of such series being converted. There were no conversions of the 2019 Notes during the three months ended April 30, 2019. During the nine months ended April 30, 2019, holders converted $415.6 million in aggregate principal amount of the 2019 Notes, which we repaid in cash. We also issued 1.7 million shares

[0001327567-19-000016:mdna:136]
[same as prior period, unchanged from 0001327567-19-000008:mdna:163]

[0001327567-19-000016:mdna:137]
of common stock to the holders during the nine months ended April 30, 2019 for the conversion value in excess of the principal amount of the 2019 Notes converted, which were fully offset by shares received from our exercise of the associated note hedges. Refer to Note 9. Debt in Part I, Item 1 of this Quarterly Report on Form 10-Q for information on the Notes.

[0001327567-19-000016:mdna:138]
In September 2018, we entered into a credit agreement (the “Credit Agreement”) that provides for a $400.0 million unsecured revolving credit facility (the “Credit Facility”), with an option to increase the amount of the credit facility up to an additional $350.0 million, subject to certain conditions. As of April 30, 2019, there were no amounts outstanding, and we were in compliance with all covenants under the Credit Agreement. Refer to Note 9. Debt in Part I, Item 1 of this Quarterly Report on Form 10-Q for more information on the Credit Agreement.

[0001327567-19-000016:mdna:139]
In August 2016, our board of directors authorized a $500.0 million share repurchase program and, in February 2017, authorized a $500.0 million increase to the repurchase program, bringing the total authorization to $1.0 billion. Repurchases were to be funded from available working capital and could be made at management’s discretion from time to time. The repurchase program expired on December 31, 2018. In February 2019, our board of directors authorized a new $1.0 billion share repurchase program which will be funded from available working capital and will expire on December 31, 2020. As of April 30, 2019, $1.0 billion remained available for future share repurchases under the new repurchase authorization. Refer to Note 11. Stockholders’ Equity in Part I, Item 1 of this Quarterly Report on Form 10-Q for more information on the repurchase programs.

[0001327567-19-000016:mdna:140]
The following table summarizes our cash flows for the nine months ended April 30, 2019 and 2018:

[0001327567-19-000016:mdna:141]
|  | Nine Months Ended April 30, |
| 2019 |  | 2018 |
|  | (in millions) |
| Net cash provided by operating activities(1) | $ | 824.1 |  |  | $ | 760.5 |  |
| Net cash used in investing activities | (1,377.2 | ) |  | (313.6 | ) |
| Net cash used in financing activities | (637.8 | ) |  | (240.8 | ) |
| Net increase (decrease) in cash, cash equivalents, and restricted cash(1) | $ | (1,190.9 | ) |  | $ | 206.1 |  |

[0001327567-19-000016:mdna:142]
[same as prior period, unchanged from 0001327567-19-000008:mdna:137]

[0001327567-19-000016:mdna:143]
[same as prior period, unchanged from 0001327567-19-000008:mdna:138]

[0001327567-19-000016:mdna:144]
[same as prior period, unchanged from 0001327567-19-000008:mdna:139]

[0001327567-19-000016:mdna:145]
[same as prior period, unchanged from 0001327567-19-000008:mdna:140]

[0001327567-19-000016:mdna:146]
[same as prior period, unchanged from 0001327567-19-000008:mdna:141]

[0001327567-19-000016:mdna:147]
[same as prior period, unchanged from 0001327567-19-000008:mdna:142]

[0001327567-19-000016:mdna:148]
Cash provided by operating activities during the nine months ended April 30, 2019 was $824.1 million, an increase of $63.6 million compared to the nine months ended April 30, 2018. The increase was due to growth of our business, as reflected by an increase in billings, and an increase in collections during the nine months ended April 30, 2019. This was partially offset by a decrease due to repayments of the 2019 Notes attributable to the debt discount of $67.1 million during the nine months ended April 30, 2019, and the receipt of an upfront cash reimbursement of $38.2 million related to certain of our lease agreements during the nine months ended April 30, 2018.

[0001327567-19-000016:mdna:149]
[same as prior period, unchanged from 0001327567-19-000008:mdna:145]

[0001327567-19-000016:mdna:150]
[same as prior period, unchanged from 0001327567-19-000008:mdna:146]

[0001327567-19-000016:mdna:151]
- 42 -

[0001327567-19-000016:mdna:152]
Cash used in investing activities during the nine months ended April 30, 2019 was $1.4 billion, an increase of $1.1 billion compared to the nine months ended April 30, 2018, primarily due to higher net purchases of investments during the nine months ended April 30, 2019.

[0001327567-19-000016:mdna:153]
[same as prior period, unchanged from 0001327567-19-000008:mdna:148]

[0001327567-19-000016:mdna:154]
[same as prior period, unchanged from 0001327567-19-000008:mdna:149]

[0001327567-19-000016:mdna:155]
Cash used in financing activities during the nine months ended April 30, 2019 was $637.8 million, an increase of $397.0 million compared to the nine months ended April 30, 2018, primarily due to repayments of our 2019 Notes and an increase in repurchases of our common stock during the nine months ended April 30, 2019.

[0001327567-19-000016:mdna:156]
[same as prior period, unchanged from 0001327567-19-000008:mdna:151]

[0001327567-19-000016:mdna:157]
The following summarizes our contractual obligations and commitments as of April 30, 2019:

[0001327567-19-000016:mdna:158]
|  | Payments Due by Period |
|  | Total |  | Less Than 1 Year |  | 1-3 Years |  | 3-5 Years |  | More Than 5 Years |
|  |  |  | (in millions) |  |  |
| 0.0% Convertible Senior Notes due 2019(1) | $ | 159.4 |  |  | $ | 159.4 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| 0.75% Convertible Senior Notes due 2023 | 1,693.0 |  |  | — |  |  | — |  |  | 1,693.0 |  |  | — |  |
| Operating lease obligations(2) | 509.0 |  |  | 73.3 |  |  | 132.1 |  |  | 109.9 |  |  | 193.7 |  |
| Purchase obligations(3) | 434.6 |  |  | 137.3 |  |  | 27.3 |  |  | 105.0 |  |  | 165.0 |  |
| Total(4) | $ | 2,796.0 |  |  | $ | 370.0 |  |  | $ | 159.4 |  |  | $ | 1,907.9 |  |  | $ | 358.7 |  |

[0001327567-19-000016:mdna:159]
[same as prior period, unchanged from 0001327567-19-000008:mdna:154]

[0001327567-19-000016:mdna:160]
[same as prior period, unchanged from 0001327567-19-000008:mdna:155]

[0001327567-19-000016:mdna:161]
| (2) | Consists of contractual obligations from our non-cancelable operating leases. Excludes contractual sublease proceeds of $11.2 million, which consists of $5.6 million to be received in less than one year and $5.6 million to be received in one to three years. Refer to Note 10. Commitments and Contingencies in Part I, Item 1 of this Quarterly Report on Form 10-Q for more information on our operating leases. |

[0001327567-19-000016:mdna:162]
[same as prior period, unchanged from 0001327567-19-000008:mdna:157]

[0001327567-19-000016:mdna:163]
| (4) | No amounts related to income taxes are included. As of April 30, 2019, we had approximately $69.7 million of tax liabilities recorded related to uncertainty in income tax positions. |

[0001327567-19-000016:mdna:164]
[same as prior period, unchanged from 0001327567-19-000008:mdna:159]

[0001327567-19-000016:mdna:165]
As of April 30, 2019, we did not have any relationships with unconsolidated organizations or financial partnerships, such as structured finance or special purpose entities that would have been established for the purpose of facilitating off-balance sheet arrangements or other contractually narrow or limited purposes.

[0001327567-19-000016:mdna:166]
[same as prior period, unchanged from 0001327567-19-000008:mdna:161]

[0001327567-19-000016:mdna:167]
Our condensed consolidated financial statements have been prepared in accordance with U.S. GAAP. The preparation of these condensed consolidated financial statements requires us to make estimates and assumptions that affect the reported amounts of assets, liabilities, revenue, expenses, and related disclosures. We base our estimates on historical experience and on various other assumptions that we believe are reasonable under the circumstances. We evaluate our estimates and assumptions on an ongoing basis. Actual results may differ from these estimates. To the extent that there are material differences between these estimates and our actual results, our future financial statements will be affected.

[0001327567-19-000016:mdna:168]
We believe the critical accounting estimates discussed under Item 7, “Management’s Discussion and Analysis of Financial Condition and Results of Operations” in our Annual Report on Form 10-K for the fiscal year ended July 31, 2018, reflect our more significant judgments and estimates used in the preparation of our condensed consolidated financial statements. There have been no

[0001327567-19-000016:mdna:169]
- 43 -

[0001327567-19-000016:mdna:170]
significant changes to our critical accounting estimates as filed in such report, except for revenue recognition and deferred contract costs, due to our adoption of new accounting guidance, as described below. Refer to “Recently Adopted Accounting Pronouncements” in Note 1. Description of Business and Summary of Significant Accounting Policies in Part I, Item 1 of this Quarterly Report on Form 10-Q for more information on our adoption of the new accounting guidance.

[0001327567-19-000016:mdna:171]
[same as prior period, unchanged from 0001327567-19-000008:mdna:166]

[0001327567-19-000016:mdna:172]
[same as prior period, unchanged from 0001327567-19-000008:mdna:167]

[0001327567-19-000016:mdna:173]
[same as prior period, unchanged from 0001327567-19-000008:mdna:168]

[0001327567-19-000016:mdna:174]
[same as prior period, unchanged from 0001327567-19-000008:mdna:169]

[0001327567-19-000016:mdna:175]
[same as prior period, unchanged from 0001327567-19-000008:mdna:170]

[0001327567-19-000016:mdna:176]
[same as prior period, unchanged from 0001327567-19-000008:mdna:171]

[0001327567-19-000016:mdna:177]
Refer to “Recently Issued Accounting Pronouncements” in Note 1. Description of Business and Summary of Significant Accounting Policies in Part I, Item 1 of this Quarterly Report on Form 10-Q.
