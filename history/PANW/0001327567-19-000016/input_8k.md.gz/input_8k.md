# PANW 8-K — 0001327567-19-000014 filed 2019-05-29

## item codes, every 8-K on or before 2019-05-30

- 2019-05-29 0001327567-19-000014 — 2.02, 9.01
- 2019-04-15 0001327567-19-000011 — 5.02, 9.01
- 2019-04-01 0001193125-19-094613 — 8.01, 9.01
- 2019-03-28 0001193125-19-090572 — 3.02 — amendment of 0001327567-19-000003
- 2019-02-26 0001327567-19-000006 — 2.02, 8.01, 9.01
- 2019-02-19 0001327567-19-000003 — 3.02
- 2018-12-11 0001327567-18-000033 — 5.07
- 2018-11-29 0001327567-18-000029 — 2.02, 9.01
- 2018-10-15 0001193125-18-299312 — 5.02, 9.01
- 2018-09-25 0001193125-18-282542 — 5.02
- 2018-09-14 0001193125-18-274239 — 5.03, 9.01
- 2018-09-06 0001327567-18-000018 — 1.01, 2.02, 2.03, 9.01
- 2018-07-13 0001193125-18-217281 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2018-06-04 0001327567-18-000011 — 2.02, 5.02, 9.01
- 2018-02-26 0001327567-18-000004 — 2.02, 5.02, 7.01, 9.01
- 2017-12-12 0001193125-17-367477 — 5.07
- 2017-11-20 0001327567-17-000032 — 2.02, 5.02, 9.01
- 2017-08-31 0001327567-17-000021 — 2.02, 5.02, 9.01
- 2017-05-31 0001327567-17-000016 — 2.02, 9.01
- 2017-02-28 0001327567-17-000005 — 2.02, 8.01, 9.01
- 2016-12-12 0001193125-16-790757 — 5.07
- 2016-11-21 0001327567-16-000071 — 2.02, 9.01
- 2016-10-24 0001193125-16-745121 — 5.02, 9.01
- 2016-08-30 0001327567-16-000057 — 2.02, 5.03, 8.01, 9.01
- 2016-08-22 0001193125-16-687588 — 5.02, 9.01
- 2016-05-26 0001327567-16-000051 — 2.02, 9.01
- 2016-02-25 0001327567-16-000044 — 2.02, 5.02, 9.01
- 2015-12-14 0001327567-15-000038 — 5.07
- 2015-12-14 0001193125-15-402588 — 1.01, 9.01
- 2015-11-23 0001327567-15-000033 — 2.02, 9.01
- 2015-10-19 0001193125-15-347005 — 1.01, 9.01 — amendment, the index does not say of what
- 2015-09-09 0001327567-15-000022 — 2.02, 9.01
- 2015-08-19 0001193125-15-296115 — 1.01, 2.03
- 2015-06-01 0001193125-15-207786 — 1.01, 2.03
- 2015-05-27 0001327567-15-000015 — 2.02, 9.01
- 2015-03-02 0001327567-15-000006 — 2.02, 9.01
- 2014-12-15 0001327567-14-000046 — 5.07
- 2014-11-24 0001327567-14-000040 — 2.02, 9.01
- 2014-09-22 0001193125-14-348581 — 5.02, 9.01
- 2014-09-09 0001327567-14-000025 — 2.02, 9.01
- 2014-07-01 0001193125-14-257824 — 1.01, 2.03, 3.02, 9.01
- 2014-06-26 0001193125-14-249529 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2014-06-20 0001327567-14-000020 — 9.01 — amendment of 0001193125-14-140511
- 2014-06-04 0001327567-14-000016 — 3.02
- 2014-05-30 0001193125-14-218158 — 2.02 — amendment, the index does not say of what
- 2014-05-28 0001193125-14-215060 — 1.01, 2.02, 3.02, 9.01
- 2014-04-11 0001193125-14-140511 — 2.01, 3.02, 7.01, 9.01
- 2014-03-24 0001193125-14-111318 — 1.01, 3.02, 7.01, 9.01
- 2014-03-13 0001327567-14-000009 — 5.02
- 2014-02-24 0001193125-14-063754 — 2.02, 9.01
- 2013-12-12 0001327567-13-000040 — 5.07
- 2013-11-25 0001327567-13-000033 — 2.02, 9.01
- 2013-09-30 0001193125-13-384966 — 8.01
- 2013-09-09 0001193125-13-361421 — 2.02, 9.01
- 2013-05-30 0001193125-13-241542 — 2.02, 5.02, 9.01
- 2013-03-11 0001193125-13-101082 — 5.02, 9.01
- 2013-02-28 0001193125-13-084193 — 2.02, 9.01
- 2012-12-14 0001193125-12-503335 — 5.07
- 2012-12-06 0001193125-12-493700 — 2.02, 9.01
- 2012-09-24 0001193125-12-401534 — 1.01, 2.03
- 2012-09-20 0001193125-12-398433 — 5.02, 9.01
- 2012-09-10 0001193125-12-386605 — 2.02, 9.01

## late-filing notifications on or before 2019-05-30

- none on or before 2019-05-30

## item 2.02 — earnings release, exhibit 99.1

[0001327567-19-000014:8k_2_02:1]
EX-99.1
2
ex991q319earningsrelease.htm
EXHIBIT 99.1

[0001327567-19-000014:8k_2_02:2]
Exhibit

[0001327567-19-000014:8k_2_02:3]
Exhibit 99.1

[0001327567-19-000014:8k_2_02:4]
Palo Alto Networks Reports Fiscal Third Quarter 2019 Financial Results

[0001327567-19-000014:8k_2_02:5]
| • | Fiscal third quarter revenue grows 28 percent year over year to $726.6 million |

[0001327567-19-000014:8k_2_02:6]
| • | Deferred revenue grows 27 percent year over year to $2.6 billion |

[0001327567-19-000014:8k_2_02:7]
| • | Announces Prisma, as well as the proposed acquisitions of Twistlock and PureSec |

[0001327567-19-000014:8k_2_02:8]
SANTA CLARA, Calif. — May 29, 2019 — Palo Alto Networks (NYSE: PANW), the global cybersecurity leader, announced today financial results for its fiscal third quarter 2019, ended April 30, 2019.

[0001327567-19-000014:8k_2_02:9]
Total revenue for the fiscal third quarter 2019 grew 28 percent year over year to $726.6 million, compared with total revenue of $567.7 million for the fiscal third quarter 2018. GAAP net loss for the fiscal third quarter 2019 was $20.2 million, or $0.21 per diluted share, compared with GAAP net loss of $40.4 million, or $0.44 per diluted share, for the fiscal third quarter 2018.

[0001327567-19-000014:8k_2_02:10]
Non-GAAP net income for the fiscal third quarter 2019 was $130.1 million, or $1.31 per diluted share, compared with non-GAAP net income of $100.0 million, or $1.04 per diluted share, for the fiscal third quarter 2018. A reconciliation between GAAP and non-GAAP information is contained in the tables below.

[0001327567-19-000014:8k_2_02:11]
“Our team continues to execute on our plan and deliver robust results. The excitement around our new products is incredible and will only grow once customers have a chance to experience it for themselves,” said Nikesh Arora, chairman and CEO of Palo Alto Networks. “Both Twistlock and PureSec will be important additions to helping protect our customers’ journey to the cloud.

[0001327567-19-000014:8k_2_02:12]
Combining their capabilities with Prisma, our leading cloud security suite, is a huge win for all of our customers.”

[0001327567-19-000014:8k_2_02:13]
In a separate news release issued today, the company announced the proposed acquisitions of Twistlock, the leader in container security, and PureSec, a leader in serverless security. The company also announced PrismaTM, the industry’s most complete and comprehensive cloud security suite, earlier today.

[0001327567-19-000014:8k_2_02:14]
Financial Outlook

[0001327567-19-000014:8k_2_02:15]
Palo Alto Networks provides guidance based on current market conditions and expectations.

[0001327567-19-000014:8k_2_02:16]
For the fiscal fourth quarter 2019, we expect:

[0001327567-19-000014:8k_2_02:17]
| • | Total revenue in the range of $795 to $805 million, representing year-over-year growth between 21 percent and 22 percent on an ASC 606 basis. |

[0001327567-19-000014:8k_2_02:18]
| • | Diluted non-GAAP net income per share in the range of $1.41 to $1.42, using 100 to 102 million shares on an ASC 606 basis. This guidance includes the impact of approximately $15 million in net expense, or $0.12 per share, related to a full quarter of the Demisto acquisition as well as the proposed acquisitions of Twistlock and PureSec. It also includes the impact of tariffs of approximately $2.5 million, or $0.02 per share. |

[0001327567-19-000014:8k_2_02:19]
Guidance for non-GAAP financial measures excludes share-based compensation-related charges (including share-based payroll tax expense), acquisition-related costs, amortization expense of acquired intangible assets, litigation-related charges (including legal settlements), facility exit costs, non-cash charges related to convertible notes, foreign currency gains (losses), and income and other tax effects associated with these items, along with certain non-recurring expenses. We have not reconciled diluted non-GAAP net income per share guidance to GAAP

[0001327567-19-000014:8k_2_02:20]
2

[0001327567-19-000014:8k_2_02:21]
net income (loss) per diluted share because we do not provide guidance on GAAP net income (loss) and would not be able to present the various reconciling cash and non-cash items between GAAP net income (loss) and non-GAAP net income, including share-based compensation expense, without unreasonable effort. Share-based compensation expense is impacted by the company’s future hiring and retention needs and, to a lesser extent, the future fair market value of the company’s common stock, all of which is difficult to predict and subject to constant change. The actual amounts of such reconciling items will have a significant impact on the company’s GAAP net income (loss) per diluted share.

[0001327567-19-000014:8k_2_02:22]
Conference Call Information

[0001327567-19-000014:8k_2_02:23]
Palo Alto Networks will host a conference call for analysts and investors to discuss its fiscal third quarter 2019 results and outlook for its fiscal fourth quarter 2019 today at 4:30 p.m. Eastern time/1:30 p.m. Pacific time. Open to the public, investors may access the call by dialing 1-888-254-3590 or 1-720-543-0302 and using conference ID 5632791. A live audio webcast of the conference call, along with supplemental financial information, will also be accessible from the “Investors” section of our website at investors.paloaltonetworks.com. Following the webcast, an archived version will be available on our website for one year. A telephonic replay of the call will be available three hours after the call, will run for ten days, and may be accessed by dialing 1-888-203-1112 or 1-719-457-0820 and entering the passcode 5632791.

[0001327567-19-000014:8k_2_02:24]
Forward-Looking Statements

[0001327567-19-000014:8k_2_02:25]
This press release contains forward-looking statements that involve risks and uncertainties, including statements regarding the benefits and effectiveness of both Twistlock and PureSec’s technologies when integrated with Prisma and other technologies in our existing platform, and our financial outlook for the fiscal fourth quarter 2019. There are a significant number of factors that could cause actual results to differ materially from statements made in this press release,

[0001327567-19-000014:8k_2_02:26]
including: our limited operating history; our ability as an organization to acquire and integrate other companies, products or technologies in a successful manner; risks associated with managing our rapid growth; the risks associated with new products and subscription and support offerings, including the discovery of software bugs; our ability to attract and retain new customers; delays in the development or release of new subscription offerings, or the failure to timely develop and achieve market acceptance of new products and subscriptions as well as existing products and subscription and support offerings; rapidly evolving technological developments in the market for security products and subscription and support offerings; length of sales cycles; and general market, political, economic and business conditions.

[0001327567-19-000014:8k_2_02:27]
Additional risks and uncertainties that could affect our financial results are included under the captions “Risk Factors” and “Management’s Discussion and Analysis of Financial Condition and Results of Operations” in our Quarterly Report on Form 10-Q filed with the SEC on February 27, 2019, which is available on our website at investors.paloaltonetworks.com and on the SEC’s website at www.sec.gov. Additional information will also be set forth in other filings that we make with the SEC from time to time. All forward-looking statements in this press release are based on information available to us as of the date hereof, and we do not assume any obligation to update the forward-looking statements provided to reflect events that occur or circumstances that exist after the date on which they were made.

[0001327567-19-000014:8k_2_02:28]
Non-GAAP Financial Measures

[0001327567-19-000014:8k_2_02:29]
Palo Alto Networks has provided in this press release financial information that has not been prepared in accordance with generally accepted accounting principles in the United States (GAAP). The company uses these non-GAAP financial measures internally in analyzing its financial results and believes that the use of these non-GAAP financial measures is useful to investors as an additional tool to evaluate ongoing operating results and trends, and in

[0001327567-19-000014:8k_2_02:30]
4

[0001327567-19-000014:8k_2_02:31]
comparing the company’s financial results with other companies in its industry, many of which present similar non-GAAP financial measures.

[0001327567-19-000014:8k_2_02:32]
The presentation of these non-GAAP financial measures are not meant to be considered in isolation or as a substitute for comparable GAAP financial measures and should be read only in conjunction with the company’s consolidated financial statements prepared in accordance with GAAP. A reconciliation of the company’s historical non-GAAP financial measures to their most directly comparable GAAP measures has been provided in the financial statement tables included in this press release, and investors are encouraged to review these reconciliations.

[0001327567-19-000014:8k_2_02:33]
Non-GAAP net income and net income per share, diluted. Palo Alto Networks defines non-GAAP net income as net income (loss) plus share-based compensation-related charges, including share-based payroll tax expense, acquisition-related costs, amortization expense of acquired intangible assets, litigation-related charges, including legal settlements, facility exit costs, non-cash charges related to convertible notes, and intellectual property restructuring-related charges. The company also excludes from non-GAAP net income the foreign currency gains (losses) and tax effects associated with these items in order to provide a complete picture of the company’s recurring core business operating results. The company defines non-GAAP net income per share, diluted, as non-GAAP net income divided by the weighted-average diluted shares outstanding, which includes the potentially dilutive effect of the company’s employee equity incentive plan awards and the company’s convertible senior notes outstanding and related warrants, after giving effect to the anti-dilutive impact of the company’s note hedge agreements, which reduces the potential economic dilution that otherwise would occur upon conversion of the company’s convertible senior notes. Under GAAP, the anti-dilutive impact of the note hedge is not reflected in diluted shares outstanding. The company believes that excluding these items from non-GAAP net income and net income per share, diluted, provides

[0001327567-19-000014:8k_2_02:34]
management and investors with greater visibility into the underlying performance of the company’s core business operating results, meaning its operating performance excluding these items and, from time to time, other discrete charges that are infrequent in nature, over multiple periods.

[0001327567-19-000014:8k_2_02:35]
Investors are cautioned that there are a number of limitations associated with the use of non-GAAP financial measures as analytical tools. In particular, many of the adjustments to the company’s GAAP financial measures reflect the exclusion of items that are recurring and will be reflected in the company’s financial results for the foreseeable future, such as share-based compensation, which is an important part of Palo Alto Networks employees’ compensation and impacts their performance. Furthermore, these non-GAAP financial measures are not based on any standardized methodology prescribed by GAAP, and the components that Palo Alto Networks excludes in its calculation of non-GAAP financial measures may differ from the components that its peer companies exclude when they report their non-GAAP results of operations. Palo Alto Networks compensates for these limitations by providing specific information regarding the GAAP amounts excluded from these non-GAAP financial measures. In the future, the company may also exclude non-recurring expenses and other expenses that do not reflect the company’s core business operating results.

[0001327567-19-000014:8k_2_02:36]
About Palo Alto Networks

[0001327567-19-000014:8k_2_02:37]
Palo Alto Networks, the global cybersecurity leader, is shaping the cloud-centric future with technology that is transforming the way people and organizations operate. Our mission is to be the cybersecurity partner of choice, protecting our digital way of life. We help address the world’s greatest security challenges with continuous innovation that seizes the latest breakthroughs in artificial intelligence, analytics, automation, and orchestration. By delivering an integrated platform and empowering a growing ecosystem of partners, we are at the forefront of protecting

[0001327567-19-000014:8k_2_02:38]
6

[0001327567-19-000014:8k_2_02:39]
tens of thousands of organizations across clouds, networks, and mobile devices. Our vision is a world where each day is safer and more secure than the one before. For more information visit www.paloaltonetworks.com.

[0001327567-19-000014:8k_2_02:40]
Palo Alto Networks, Prisma, and the Palo Alto Networks logo are trademarks of Palo Alto Networks, Inc. in the United States and in jurisdictions throughout the world. All other trademarks, trade names, or service marks used or mentioned herein belong to their respective owners.

[0001327567-19-000014:8k_2_02:41]
Media Contact:

[0001327567-19-000014:8k_2_02:42]
Kristen Batch

[0001327567-19-000014:8k_2_02:43]
Senior Vice President of Corporate Communications, Palo Alto Networks

[0001327567-19-000014:8k_2_02:44]
Mobile: 503-516-6297

[0001327567-19-000014:8k_2_02:45]
kbatch@paloaltonetworks.com

[0001327567-19-000014:8k_2_02:46]
Investor Relations Contact:

[0001327567-19-000014:8k_2_02:47]
David Niederman

[0001327567-19-000014:8k_2_02:48]
Vice President of Investor Relations, Palo Alto Networks

[0001327567-19-000014:8k_2_02:49]
Office: 669-400-7323

[0001327567-19-000014:8k_2_02:50]
dniederman@paloaltonetworks.com

[0001327567-19-000014:8k_2_02:51]
| Palo Alto Networks, Inc. |
| Preliminary Condensed Consolidated Statements of Operations |
| (In millions, except per share data) |
| (Unaudited) |
|  | Three Months Ended April 30, |  | Nine Months Ended April 30, |
|  | 2019 |  | 2018 |  | 2019 |  | 2018 |
|  |  |  | (As Adjusted)(1) |  |  |  | (As Adjusted)(1) |
| Revenue: |  |  |  |  |  |  |  |
| Product | $ | 278.4 |  |  | $ | 218.1 |  |  | $ | 790.5 |  |  | $ | 607.7 |  |
| Subscription and support | 448.2 |  |  | 349.6 |  |  | 1,303.3 |  |  | 1,007.4 |  |
| Total revenue | 726.6 |  |  | 567.7 |  |  | 2,093.8 |  |  | 1,615.1 |  |
| Cost of revenue: |  |  |  |  |  |  |  |
| Product | 78.0 |  |  | 68.9 |  |  | 233.7 |  |  | 190.4 |  |
| Subscription and support | 126.9 |  |  | 91.0 |  |  | 357.3 |  |  | 270.2 |  |
| Total cost of revenue | 204.9 |  |  | 159.9 |  |  | 591.0 |  |  | 460.6 |  |
| Total gross profit | 521.7 |  |  | 407.8 |  |  | 1,502.8 |  |  | 1,154.5 |  |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | 139.1 |  |  | 99.6 |  |  | 380.8 |  |  | 290.4 |  |
| Sales and marketing | 339.0 |  |  | 271.4 |  |  | 973.6 |  |  | 784.3 |  |
| General and administrative | 62.3 |  |  | 82.1 |  |  | 192.6 |  |  | 201.1 |  |
| Total operating expenses | 540.4 |  |  | 453.1 |  |  | 1,547.0 |  |  | 1,275.8 |  |
| Operating loss | (18.7 | ) |  | (45.3 | ) |  | (44.2 | ) |  | (121.3 | ) |
| Interest expense | (20.6 | ) |  | (6.5 | ) |  | (63.9 | ) |  | (19.2 | ) |
| Other income, net | 18.2 |  |  | 8.6 |  |  | 47.2 |  |  | 18.3 |  |
| Loss before income taxes | (21.1 | ) |  | (43.2 | ) |  | (60.9 | ) |  | (122.2 | ) |
| Provision for (benefit from) income taxes | (0.9 | ) |  | (2.8 | ) |  | 0.2 |  |  | 7.0 |  |
| Net loss | $ | (20.2 | ) |  | $ | (40.4 | ) |  | $ | (61.1 | ) |  | $ | (129.2 | ) |
| Net loss per share, basic and diluted | $ | (0.21 | ) |  | $ | (0.44 | ) |  | $ | (0.65 | ) |  | $ | (1.42 | ) |
| Weighted-average shares used to compute net loss per share, basic and diluted | 94.4 |  |  | 91.9 |  |  | 94.1 |  |  | 91.3 |  |

[0001327567-19-000014:8k_2_02:52]
______________

[0001327567-19-000014:8k_2_02:53]
| (1) | Certain amounts have been adjusted due to the company’s adoption of the new revenue recognition standard (ASC 606) as of August 1, 2018 using the full retrospective method. |

[0001327567-19-000014:8k_2_02:54]
8

[0001327567-19-000014:8k_2_02:55]
| Palo Alto Networks, Inc. |
| Reconciliation of GAAP to Non-GAAP Financial Measures |
| (In millions, except per share amounts) |
| (Unaudited) |
|  | Three Months Ended |  | Nine Months Ended |
|  | April 30, |  | April 30, |
|  | 2019 |  | 2018 |  | 2019 |  | 2018 |
|  |  |  | (As Adjusted)(1) |  |  |  | (As Adjusted)(1) |
| GAAP net loss | $ | (20.2 | ) |  | $ | (40.4 | ) |  | $ | (61.1 | ) |  | $ | (129.2 | ) |
| Share-based compensation-related charges | 145.8 |  |  | 123.1 |  |  | 436.0 |  |  | 388.3 |  |
| Acquisition-related costs(2) | 2.9 |  |  | 13.3 |  |  | 20.0 |  |  | 13.3 |  |
| Amortization expense of acquired intangible assets | 14.6 |  |  | 3.6 |  |  | 38.0 |  |  | 8.6 |  |
| Litigation-related charges(3) | 3.1 |  |  | 3.1 |  |  | 9.2 |  |  | 9.2 |  |
| Facility exit costs(4) | 4.1 |  |  | 23.8 |  |  | 4.1 |  |  | 40.8 |  |
| Non-cash charges related to convertible notes(5) | 17.2 |  |  | 6.5 |  |  | 56.3 |  |  | 19.2 |  |
| Foreign currency (gain) loss associated with non-GAAP adjustments | 0.5 |  |  | (2.0 | ) |  | 0.6 |  |  | (0.5 | ) |
| Income tax and other tax adjustments related to the above(6) | (37.9 | ) |  | (31.0 | ) |  | (110.6 | ) |  | (80.7 | ) |
| Non-GAAP net income | $ | 130.1 |  |  | $ | 100.0 |  |  | $ | 392.5 |  |  | $ | 269.0 |  |
| GAAP net loss per share, diluted | $ | (0.21 | ) |  | $ | (0.44 | ) |  | $ | (0.65 | ) |  | $ | (1.42 | ) |
| Share-based compensation-related charges | 1.48 |  |  | 1.30 |  |  | 4.45 |  |  | 4.15 |  |
| Acquisition-related costs(2) | 0.03 |  |  | 0.14 |  |  | 0.21 |  |  | 0.15 |  |
| Amortization expense of acquired intangible assets | 0.15 |  |  | 0.04 |  |  | 0.40 |  |  | 0.09 |  |
| Litigation-related charges(3) | 0.03 |  |  | 0.03 |  |  | 0.10 |  |  | 0.10 |  |
| Facility exit costs(4) | 0.04 |  |  | 0.26 |  |  | 0.04 |  |  | 0.45 |  |
| Non-cash charges related to convertible notes(5) | 0.18 |  |  | 0.07 |  |  | 0.60 |  |  | 0.21 |  |
| Foreign currency (gain) loss associated with non-GAAP adjustments | 0.01 |  |  | (0.02 | ) |  | 0.01 |  |  | (0.01 | ) |
| Income tax and other tax adjustments related to the above(6) | (0.40 | ) |  | (0.34 | ) |  | (1.18 | ) |  | (0.88 | ) |
| Non-GAAP net income per share, diluted | $ | 1.31 |  |  | $ | 1.04 |  |  | $ | 3.98 |  |  | $ | 2.84 |  |
| GAAP weighted-average shares used to compute net loss per share, diluted | 94.4 |  |  | 91.9 |  |  | 94.1 |  |  | 91.3 |  |
| Weighted-average effect of potentially dilutive securities(7) | 5.2 |  |  | 4.3 |  |  | 4.6 |  |  | 3.3 |  |
| Non-GAAP weighted-average shares used to compute net income per share, diluted | 99.6 |  |  | 96.2 |  |  | 98.7 |  |  | 94.6 |  |

[0001327567-19-000014:8k_2_02:56]
___________

[0001327567-19-000014:8k_2_02:57]
| (1) | Certain amounts have been adjusted due to the company’s adoption of the new revenue recognition standard (ASC 606) as of August 1, 2018 using the full retrospective method. |

[0001327567-19-000014:8k_2_02:58]
| (2) | Consists of acquisition transaction costs, share-based compensation related to the cash settlement of certain equity awards, and costs to terminate certain employment and operating lease contracts of the acquired company. |

[0001327567-19-000014:8k_2_02:59]
| (3) | Consists of the amortization of intellectual property licenses. |

[0001327567-19-000014:8k_2_02:60]
| (4) | Consists of charges related to the relocation of the company’s corporate headquarters (cease-use loss of $15.4 million and accelerated depreciation during the three months ended October 31, 2017, and additional cease-use losses of $23.8 million and $4.1 million during the three months ended April 30, 2018 and April 30, 2019, respectively) and charges related to the relocation of the company’s research and development center in Israel (cease-use loss of $1.3 million and accelerated depreciation during the three months ended January 31, 2018). |

[0001327567-19-000014:8k_2_02:61]
| (5) | Consists primarily of non-cash interest expense related to the company’s convertible senior notes. Also includes a non-cash loss of $2.6 million during the nine months ended April 30, 2019, related to early conversions of the convertible notes during the period. |

[0001327567-19-000014:8k_2_02:62]
| (6) | The company changed its non-GAAP effective tax rate from 31% to 22% in its second quarter of fiscal 2018 due to the reduction of the U.S. federal corporate income tax rate under the U.S. Tax Cuts and Jobs Act, which was enacted into law on December 22, 2017. |

[0001327567-19-000014:8k_2_02:63]
| (7) | Non-GAAP net income per share, diluted, includes the potentially dilutive effect of employee equity incentive plan awards and convertible senior notes outstanding and related warrants. In addition, non-GAAP net income per share, diluted, includes the anti-dilutive impact of the company’s note hedge agreements, which reduced the potentially dilutive effect of the convertible notes by 0.8 million shares and 0.8 million shares for the three and nine months ended April 30, 2019, respectively, and 2.2 million shares and 1.6 million shares for the three and nine months ended April 30, 2018, respectively. |

[0001327567-19-000014:8k_2_02:64]
9

[0001327567-19-000014:8k_2_02:65]
| Palo Alto Networks, Inc. |
| Preliminary Condensed Consolidated Balance Sheets |
| (In millions) |
| (Unaudited) |
|  | April 30, 2019 |  | July 31, 2018 |
|  |  |  | (As Adjusted)(1) |
| Assets |  |  |  |
| Current assets: |  |  |  |
| Cash and cash equivalents | $ | 1,314.9 |  |  | $ | 2,506.9 |  |
| Short-term investments | 1,733.2 |  |  | 896.5 |  |
| Accounts receivable, net | 407.5 |  |  | 467.0 |  |
| Prepaid expenses and other current assets | 261.9 |  |  | 268.1 |  |
| Total current assets | 3,717.5 |  |  | 4,138.5 |  |
| Property and equipment, net | 275.0 |  |  | 273.1 |  |
| Long-term investments | 669.9 |  |  | 547.5 |  |
| Goodwill | 1,027.3 |  |  | 522.8 |  |
| Intangible assets, net | 234.2 |  |  | 140.8 |  |
| Other assets | 337.9 |  |  | 326.2 |  |
| Total assets | $ | 6,261.8 |  |  | $ | 5,948.9 |  |
| Liabilities, temporary equity, and stockholders’ equity |  |  |  |
| Current liabilities: |  |  |  |
| Accounts payable | $ | 68.6 |  |  | $ | 49.4 |  |
| Accrued compensation | 144.0 |  |  | 163.7 |  |
| Accrued and other liabilities | 178.5 |  |  | 124.6 |  |
| Deferred revenue | 1,449.6 |  |  | 1,213.6 |  |
| Convertible senior notes, net | 158.1 |  |  | 550.4 |  |
| Total current liabilities | 1,998.8 |  |  | 2,101.7 |  |
| Convertible senior notes, net | 1,414.7 |  |  | 1,369.7 |  |
| Long-term deferred revenue | 1,182.6 |  |  | 1,065.7 |  |
| Other long-term liabilities | 211.1 |  |  | 229.6 |  |
| Temporary equity | 1.1 |  |  | 21.9 |  |
| Stockholders’ equity: |  |  |  |
| Preferred stock | — |  |  | — |  |
| Common stock and additional paid-in capital | 2,340.8 |  |  | 1,967.4 |  |
| Accumulated other comprehensive loss | (7.2 | ) |  | (16.4 | ) |
| Accumulated deficit | (880.1 | ) |  | (790.7 | ) |
| Total stockholders’ equity | 1,453.5 |  |  | 1,160.3 |  |
| Total liabilities, temporary equity, and stockholders’ equity | $ | 6,261.8 |  |  | $ | 5,948.9 |  |

[0001327567-19-000014:8k_2_02:66]
______________

[0001327567-19-000014:8k_2_02:67]
| (1) | Certain amounts have been adjusted due to the company’s adoption of the new revenue recognition standard (ASC 606) as of August 1, 2018 using the full retrospective method. |

[0001327567-19-000014:8k_2_02:68]
10
