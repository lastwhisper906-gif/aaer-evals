# PANW notes — 0001327567-19-000016


## panw:ConvertibleDebtOtherDetailsTableTextBlock

[0001327567-19-000016:notes:1]
The following table presents details of the Notes (number of shares in millions):

[0001327567-19-000016:notes:2]
|  | Conversion Rate per $1,000 Principal |  | Initial Conversion Price |  | Convertible Date |  | Initial Number of Shares |
| 2019 Notes | 9.0680 |  |  | $ | 110.28 |  |  | January 1, 2019 |  | 5.2 |  |
| 2023 Notes | 3.7545 |  |  | $ | 266.35 |  |  | April 1, 2023 |  | 6.4 |  |


## panw:Scheduleof2019NotesConversionsTableTextBlock

[0001327567-19-000016:notes:3]
The following table presents details of conversions of the 2019 Notes during the nine months ended April 30, 2019 (in millions):

[0001327567-19-000016:notes:4]
|  | Nine Months Ended |
|  | April 30, 2019 |
| 2019 Notes principal converted and repaid in cash: |  |
| Allocated to liability component(1) | $ | 403.4 |  |
| Allocated to equity component(2) | 12.2 |  |
| Total principal converted and repaid in cash | $ | 415.6 |  |
| Loss on conversions of convertible senior notes(3) | $ | 2.6 |  |
| Shares of common stock issued in connection with conversion of convertible senior notes(4) | 1.7 |  |

[0001327567-19-000016:notes:5]
[same as prior period, unchanged from 0001327567-19-000008:notes:8]

[0001327567-19-000016:notes:6]
[same as prior period, unchanged from 0001327567-19-000008:notes:9]

[0001327567-19-000016:notes:7]
[same as prior period, unchanged from 0001327567-19-000008:notes:10]

[0001327567-19-000016:notes:8]
[same as prior period, unchanged from 0001327567-19-000008:notes:11]

[0001327567-19-000016:notes:9]
[same as prior period, unchanged from 0001327567-19-000008:notes:12]


## panw:ScheduleofNoteHedgeTransactionsTableTextBlock

[0001327567-19-000016:notes:10]
[same as prior period, unchanged from 0001327567-19-000008:notes:13]

[0001327567-19-000016:notes:11]
[same as prior period, unchanged from 0001327567-19-000008:notes:14]


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001327567-19-000016:notes:12]
[same as prior period, unchanged from 0001327567-19-000008:notes:15]

[0001327567-19-000016:notes:13]
Demisto, Inc.

[0001327567-19-000016:notes:14]
On March 28, 2019, we completed our acquisition of 100% of the voting equity interest of Demisto, Inc. (“Demisto”), a privately-held security company specializing in security orchestration, automation and response (“SOAR”). The acquisition expands the functionality of our platform with the addition of Demisto’s SOAR product. The total purchase consideration for the acquisition of Demisto was $474.2 million, which consisted of the following (in millions):

[0001327567-19-000016:notes:15]
|  | Amount |
| Cash | $ | 250.0 |  |
| Common stock (0.9 million shares) | 214.7 |  |
| Fair value of replacement equity awards | 9.5 |  |
| Total purchase consideration | $ | 474.2 |  |

[0001327567-19-000016:notes:16]
As part of the acquisition, we issued replacement equity awards, which included 0.3 million shares of our restricted common stock. The total fair value of the replacement equity awards was $105.2 million, of which the portion attributable to services performed prior to the acquisition date was allocated to the purchase consideration. The remaining fair value was allocated to future services and will be expensed over the remaining service periods as share-based compensation.

[0001327567-19-000016:notes:17]
[same as prior period, unchanged from 0001327567-19-000008:notes:19]

[0001327567-19-000016:notes:18]
|  | Amount |
| Goodwill | $ | 387.8 |  |
| Identified intangible assets | 76.3 |  |
| Cash | 25.9 |  |
| Net liabilities assumed | (15.8 | ) |
| Total | $ | 474.2 |  |

[0001327567-19-000016:notes:19]
Goodwill generated from this business combination is primarily attributable to the assembled workforce and expected post-acquisition synergies from integrating Demisto’s product into our platform. The goodwill is not deductible for income tax purposes.

[0001327567-19-000016:notes:20]
[same as prior period, unchanged from 0001327567-19-000008:notes:22]

[0001327567-19-000016:notes:21]
|  | Fair Value |  | Estimated Useful Life |
| Developed technology | $ | 56.6 |  |  | 6 years |
| Customer relationships | 19.7 |  |  | 6 years |
| Total | $ | 76.3 |  |  |  |

[0001327567-19-000016:notes:22]
[same as prior period, unchanged from 0001327567-19-000008:notes:16]

[0001327567-19-000016:notes:23]
On October 12, 2018, we completed our acquisition of 100% of the voting equity interest of RedLock, Inc. (“RedLock”), a privately-held cloud security company. The acquisition expands our security capabilities for the public cloud with the addition of RedLock’s cloud security analytics technology. The total purchase consideration for the acquisition of RedLock was $158.2 million, which consisted of $155.0 million in cash paid upon closing and $3.2 million in fair value of unvested equity awards attributable to services performed prior to the acquisition date.

[0001327567-19-000016:notes:24]
[same as prior period, unchanged from 0001327567-19-000008:notes:18]

[0001327567-19-000016:notes:25]
[same as prior period, unchanged from 0001327567-19-000008:notes:20]

[0001327567-19-000016:notes:26]
[same as prior period, unchanged from 0001327567-19-000008:notes:21]

[0001327567-19-000016:notes:27]
[same as prior period, unchanged from 0001327567-19-000008:notes:23]

[0001327567-19-000016:notes:28]
Additional Acquisition-Related Information

[0001327567-19-000016:notes:29]
The operating results of the acquired companies are included in our condensed consolidated statements of operations from the dates of acquisition. Pro forma results of operations have not been presented because the effects of the acquisitions were not material to our condensed consolidated statements of operations.

[0001327567-19-000016:notes:30]
Additional information related to the acquired companies, such as that related to income tax and other contingencies, existing as of the acquisition date but unknown to us may become known during the remainder of the measurement period, not to exceed 12 months from the respective acquisition date, which may result in changes to the amounts and allocations recorded.


## us-gaap:BusinessDescriptionAndAccountingPoliciesTextBlock

[0001327567-19-000016:notes:31]
[same as prior period, unchanged from 0001327567-19-000008:notes:26]

[0001327567-19-000016:notes:32]
[same as prior period, unchanged from 0001327567-19-000008:notes:27]

[0001327567-19-000016:notes:33]
[same as prior period, unchanged from 0001327567-19-000008:notes:28]

[0001327567-19-000016:notes:34]
[same as prior period, unchanged from 0001327567-19-000008:notes:29]

[0001327567-19-000016:notes:35]
[same as prior period, unchanged from 0001327567-19-000008:notes:30]

[0001327567-19-000016:notes:36]
[same as prior period, unchanged from 0001327567-19-000008:notes:31]

[0001327567-19-000016:notes:37]
Certain prior period amounts have been reclassified to conform to our current period presentation. In addition, certain prior period amounts have been adjusted due to our retrospective adoption of new accounting guidance related to revenue from contracts with customers and new accounting guidance related to the presentation of restricted cash and cash equivalents in the statement of cash flows. Refer to “Recently Adopted Accounting Pronouncements” below for more information.

[0001327567-19-000016:notes:38]
[same as prior period, unchanged from 0001327567-19-000008:notes:33]

[0001327567-19-000016:notes:39]
[same as prior period, unchanged from 0001327567-19-000008:notes:34]

[0001327567-19-000016:notes:40]
There have been no material changes to our significant accounting policies as of and for the nine months ended April 30, 2019, as compared to the significant accounting policies described in our Annual Report on Form 10-K for the fiscal year ended July 31, 2018, except for the change in our accounting policies for revenue recognition and deferred contract costs due to our adoption of new accounting guidance related to revenue from contracts with customers. Refer to “Recently Adopted Accounting Pronouncements” below, Note 2. Revenue, and Note 8. Deferred Contract Costs for more information.

[0001327567-19-000016:notes:41]
Recently Adopted Accounting Pronouncements

[0001327567-19-000016:notes:42]
[same as prior period, unchanged from 0001327567-19-000008:notes:37]

[0001327567-19-000016:notes:43]
[same as prior period, unchanged from 0001327567-19-000008:notes:38]

[0001327567-19-000016:notes:44]
[same as prior period, unchanged from 0001327567-19-000008:notes:39]

[0001327567-19-000016:notes:45]
[same as prior period, unchanged from 0001327567-19-000008:notes:40]

[0001327567-19-000016:notes:46]
[same as prior period, unchanged from 0001327567-19-000008:notes:41]

[0001327567-19-000016:notes:47]
[same as prior period, unchanged from 0001327567-19-000008:notes:42]

[0001327567-19-000016:notes:48]
[same as prior period, unchanged from 0001327567-19-000008:notes:43]

[0001327567-19-000016:notes:49]
In October 2016, the FASB issued authoritative guidance requiring the recognition of income tax consequences of an intra-entity transfer of an asset, other than inventory, when the transfer occurs. We adopted the standard in our first quarter of fiscal 2019 on a modified retrospective basis. As a result, we recorded the cumulative effect of the change as an increase to accumulated deficit of $28.3 million, with a corresponding decrease to prepaid expenses and other current assets and other assets in our condensed consolidated balance sheets as of August 1, 2018, the date of adoption. The cumulative effect adjustment represents the reclassification of unrecognized income tax effects from intra-entity transfers of assets other than inventory that occurred prior to the date of adoption.

[0001327567-19-000016:notes:50]
[same as prior period, unchanged from 0001327567-19-000008:notes:45]

[0001327567-19-000016:notes:51]
[same as prior period, unchanged from 0001327567-19-000008:notes:46]

[0001327567-19-000016:notes:52]
[same as prior period, unchanged from 0001327567-19-000008:notes:47]

[0001327567-19-000016:notes:53]
[same as prior period, unchanged from 0001327567-19-000008:notes:48]

[0001327567-19-000016:notes:54]
[same as prior period, unchanged from 0001327567-19-000008:notes:49]

[0001327567-19-000016:notes:55]
[same as prior period, unchanged from 0001327567-19-000008:notes:50]

[0001327567-19-000016:notes:56]
The adoption of the new standard did not have a material impact on our condensed consolidated financial statements for the fiscal years ended July 31, 2018 and 2017, with the exception of the accounting for incremental costs to obtain customer contracts, which primarily consist of sales commissions, due to the longer period of amortization. Under the previous accounting guidance, we deferred and amortized these costs over the term of the related contract. Under the new standard, we defer and amortize these costs for initial contracts that are not commensurate with renewal commissions over a benefit period of five years, which is typically longer than the initial contract term.

[0001327567-19-000016:notes:57]
The adoption of the standard using the full retrospective method required us to restate the prior periods presented in this Quarterly Report on Form 10-Q, with the cumulative effect of the change of $168.2 million reflected in accumulated deficit as of July 31, 2017. In adopting the new standard, we have also applied a transition practical expedient and have not disclosed revenue expected to be recognized from remaining performance obligations for periods prior to August 1, 2018.

[0001327567-19-000016:notes:58]
[same as prior period, unchanged from 0001327567-19-000008:notes:53]

[0001327567-19-000016:notes:59]
|  | Three Months Ended April 30, 2018 |  | Nine Months Ended April 30, 2018 |
|  | As Previously Reported |  | Impact of Adoption |  | As Adjusted |  | As Previously Reported |  | Impact of Adoption |  | As Adjusted |
| Condensed Consolidated Statements of Operations |  |  |  |  |  |  |  |  |  |  |  |
| Product revenue | $ | 215.2 |  |  | $ | 2.9 |  |  | $ | 218.1 |  |  | $ | 603.9 |  |  | $ | 3.8 |  |  | $ | 607.7 |  |
| Subscription and support revenue | 351.9 |  |  | (2.3 | ) |  | 349.6 |  |  | 1,011.1 |  |  | (3.7 | ) |  | 1,007.4 |  |
| Total revenue | 567.1 |  |  | 0.6 |  |  | 567.7 |  |  | 1,615.0 |  |  | 0.1 |  |  | 1,615.1 |  |
| Total cost of revenue | 159.9 |  |  | — |  |  | 159.9 |  |  | 460.6 |  |  | — |  |  | 460.6 |  |
| Total operating expenses | 458.8 |  |  | (5.7 | ) |  | 453.1 |  |  | 1,292.1 |  |  | (16.3 | ) |  | 1,275.8 |  |
| Operating loss | (51.6 | ) |  | 6.3 |  |  | (45.3 | ) |  | (137.7 | ) |  | 16.4 |  |  | (121.3 | ) |
| Net loss | (46.7 | ) |  | 6.3 |  |  | (40.4 | ) |  | (145.6 | ) |  | 16.4 |  |  | (129.2 | ) |
| Net loss per share, basic and diluted | $ | (0.51 | ) |  | $ | 0.07 |  |  | $ | (0.44 | ) |  | $ | (1.59 | ) |  | $ | 0.17 |  |  | $ | (1.42 | ) |

[0001327567-19-000016:notes:60]
[same as prior period, unchanged from 0001327567-19-000008:notes:55]

[0001327567-19-000016:notes:61]
[same as prior period, unchanged from 0001327567-19-000008:notes:56]

[0001327567-19-000016:notes:62]
Recently Issued Accounting Pronouncements

[0001327567-19-000016:notes:63]
[same as prior period, unchanged from 0001327567-19-000008:notes:58]

[0001327567-19-000016:notes:64]
[same as prior period, unchanged from 0001327567-19-000008:notes:59]

[0001327567-19-000016:notes:65]
[same as prior period, unchanged from 0001327567-19-000008:notes:60]

[0001327567-19-000016:notes:66]
In February 2016, the FASB issued new authoritative guidance on lease accounting. Among its provisions, the standard requires lessees to recognize right-of-use assets and lease liabilities on the balance sheet for operating leases and also requires additional qualitative and quantitative disclosures about lease arrangements. The standard is effective for us in our first quarter of fiscal 2020 and will be applied on a modified retrospective basis, with the option to elect certain practical expedients. Early adoption is permitted; however, we plan to adopt the new standard in our first quarter of fiscal 2020. We expect to recognize right-of-use assets and operating lease liabilities on our consolidated balance sheets upon adoption for our operating leases disclosed in Note 10. Commitments and Contingencies, which will materially increase our total assets and liabilities. We do not expect the adoption of this standard to have a material impact to our consolidated statements of operations and consolidated statements of cash flows. We continue to evaluate the accounting, transition, and disclosure requirements of this standard, including its impact on our systems, accounting policies, and processes.


## us-gaap:CapitalizedContractCostTableTextBlock

[0001327567-19-000016:notes:67]
The following table presents details of our short-term and long-term deferred contract costs as of April 30, 2019 and July 31, 2018 (in millions):

[0001327567-19-000016:notes:68]
|  | April 30, 2019 |  | July 31, 2018 |
| Short-term deferred contract costs | $ | 125.8 |  |  | $ | 113.2 |  |
| Long-term deferred contract costs | 251.8 |  |  | 224.8 |  |
| Total deferred contract costs | $ | 377.6 |  |  | $ | 338.0 |  |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001327567-19-000016:notes:69]
Commitments and Contingencies

[0001327567-19-000016:notes:70]
We lease our facilities under various non-cancelable operating leases, which expire through the year ending July 31, 2028.

[0001327567-19-000016:notes:71]
In May 2015 and October 2015, we entered into a total of three lease agreements for approximately 941,000 square feet of corporate office space in Santa Clara, California, which serves as our new corporate headquarters. The leases contain rent holiday periods, scheduled rent increases, lease incentives, and renewal options which allow the lease terms to be extended beyond their expiration dates of July 2028 through July 2046. In September 2017, per the terms of the lease agreements, the landlords exercised their option to amend our lease payment schedules and eliminate our rent holiday periods, which increased our rental payments by $24.4 million, $11.8 million, and $2.0 million for fiscal 2018, 2019, and 2020, respectively. In exchange, we received an upfront cash reimbursement of $38.2 million during the three months ended October 31, 2017, which we have applied and will apply against the future additional rental payments when due. As amended, rental payments under the three lease agreements are approximately $412.0 million over the lease term.

[0001327567-19-000016:notes:72]
In May 2015, we also entered into a lease agreement for approximately 122,000 square feet of space in Santa Clara, California, to serve as an extension of our previous corporate headquarters. The lease contains scheduled rent increases, lease incentives, and renewal options which allow the lease term to be extended beyond the expiration date of April 2021 through July 2046. Rental payments under the lease agreement are approximately $23.1 million over the lease term. In December 2017, we entered into an agreement to sublease this office space for the remaining lease term. Proceeds from this sublease will be approximately $16.3 million over the sublease term.

[0001327567-19-000016:notes:73]
In September 2012, we entered into two lease agreements for a total of approximately 300,000 square feet of space in Santa Clara, California, which served as our previous corporate headquarters through August 2017, when we relocated to our new corporate campus. The leases contain rent holiday periods and two separate five-year options to extend the lease term beyond their expiration dates of July 2023. Rental payments under these lease agreements are approximately $94.3 million over the lease term. In August 2017, we exited our previous corporate headquarter facilities and relocated to our new corporate campus, which resulted in the recognition of a cease-use loss of $39.2 million during the year ended July 31, 2018. Due to changes in market conditions in recent months, and the resulting changes to the amount and timing of estimated cash flows from sublease rentals that could be reasonably obtained, we recognized an additional cease-use loss of $4.1 million as general and administrative expense in our condensed consolidated statements of operations during the three and nine months ended April 30, 2019, and a corresponding liability in our condensed consolidated balance sheets. During the three and nine months ended April 30, 2019, we released $2.6 million and $7.6 million, respectively, of the cease-use liability through rental payments. As of April 30, 2019 and July 31, 2018, the remaining balance of the cease-use liability was $25.6 million and $29.1 million, respectively, which is expected to be paid through the end of the lease term in July 2023.

[0001327567-19-000016:notes:74]
The following table presents details of the aggregate future non-cancelable minimum rental payments under our operating leases as of April 30, 2019 (in millions):

[0001327567-19-000016:notes:75]
|  | Amount |
| Fiscal years ending July 31: |  |
| Remaining 2019 | $ | 17.8 |  |
| 2020 | 73.2 |  |

[0001327567-19-000016:notes:76]
| 2021 | 67.2 |  |
| 2022 | 63.0 |  |
| 2023 | 60.1 |  |
| 2024 and thereafter | 227.7 |  |
| Committed gross lease payments | 509.0 |  |
| Less: proceeds from sublease rentals | 11.2 |  |
| Net operating lease obligation | $ | 497.8 |  |

[0001327567-19-000016:notes:77]
Purchase Commitments

[0001327567-19-000016:notes:78]
Manufacturing Purchase Commitments

[0001327567-19-000016:notes:79]
Our electronics manufacturing service provider (“EMS provider”) procures components and assembles our products based on our forecasts. These forecasts are based on estimates of demand for our products primarily for the next 12 months, which are in turn based on historical trends and an analysis from our sales and product management organizations, adjusted for overall market conditions. In order to reduce manufacturing lead times and plan for adequate supply, we may issue non-cancelable orders for products and components to our manufacturing partners or component suppliers. As of April 30, 2019, our purchase commitments under such orders were $129.3 million, excluding obligations under contracts that we can cancel without a significant penalty.

[0001327567-19-000016:notes:80]
Other Purchase Commitments

[0001327567-19-000016:notes:81]
We have entered into various non-cancelable agreements with third-party providers for our use of certain cloud services, under which we are committed to minimum purchases through the year ending July 31, 2026. The following table presents details of the aggregate future non-cancelable purchase commitments under these agreements as of April 30, 2019 (in millions):

[0001327567-19-000016:notes:82]
|  | Amount |
| Fiscal years ending July 31: |  |
| Remaining 2019 | $ | — |  |
| 2020 | 8.0 |  |
| 2021 | 27.3 |  |
| 2022 | 47.5 |  |
| 2023 | 57.5 |  |
| 2024 and thereafter | 165.0 |  |
| Total other purchase commitments | $ | 305.3 |  |

[0001327567-19-000016:notes:83]
Litigation

[0001327567-19-000016:notes:84]
We are subject to legal proceedings, claims, and litigation arising in the ordinary course of business, including intellectual property litigation. Such matters are subject to many uncertainties and outcomes are not predictable with assurance. We accrue for contingencies when we believe that a loss is probable and that we can reasonably estimate the amount of any such loss.

[0001327567-19-000016:notes:85]
To the extent there is a reasonable possibility that a loss exceeding amounts already recognized may be incurred and the amount of such additional loss would be material, we will either disclose the estimated additional loss or state that such an estimate cannot be made. As of April 30, 2019, we have not recorded any significant accruals for loss contingencies associated with such legal proceedings, determined that an unfavorable outcome is probable or reasonably possible, or determined that the amount or range of any possible loss is reasonably estimable.


## us-gaap:ConvertibleDebtTableTextBlock

[0001327567-19-000016:notes:86]
The following table sets forth the components of the Notes as of April 30, 2019 and July 31, 2018 (in millions):

[0001327567-19-000016:notes:87]
|  | April 30, 2019 |  | July 31, 2018 |
|  | 2019 Notes |  | 2023 Notes |  | Total |  | 2019 Notes |  | 2023 Notes |  | Total |
| Liability component: |  |  |  |  |  |  |  |  |  |  |  |
| Principal | $ | 159.4 |  |  | $ | 1,693.0 |  |  | $ | 1,852.4 |  |  | $ | 575.0 |  |  | $ | 1,693.0 |  |  | $ | 2,268.0 |  |
| Less: debt discount and debt issuance costs, net of amortization | 1.3 |  |  | 278.3 |  |  | 279.6 |  |  | 24.6 |  |  | 323.3 |  |  | 347.9 |  |
| Net carrying amount | $ | 158.1 |  |  | $ | 1,414.7 |  |  | $ | 1,572.8 |  |  | $ | 550.4 |  |  | $ | 1,369.7 |  |  | $ | 1,920.1 |  |
| Equity component (including amounts classified as temporary equity) | $ | 30.4 |  |  | $ | 315.0 |  |  | $ | 345.4 |  |  | $ | 109.8 |  |  | $ | 315.0 |  |  | $ | 424.8 |  |


## us-gaap:DebtDisclosureTextBlock

[0001327567-19-000016:notes:88]
Debt

[0001327567-19-000016:notes:89]
Convertible Senior Notes

[0001327567-19-000016:notes:90]
In June 2014, we issued $575.0 million aggregate principal amount of 0.0% Convertible Senior Notes due 2019 (the “2019 Notes”) and in July 2018, we issued $1.7 billion aggregate principal amount of 0.75% Convertible Senior Notes due 2023 (the “2023 Notes” and, together with the 2019 Notes, the “Notes”). The 2023 Notes bear interest at a fixed rate of 0.75% per year, payable semi-annually in arrears on January 1 and July 1 of each year, beginning on January 1, 2019. Each series of Notes is governed by an indenture between us, as the issuer, and U.S. Bank National Association, as Trustee (individually, each an “Indenture,” and together, the “Indentures”). The Notes of each series are unsecured, unsubordinated obligations and the applicable Indenture governing each series of Notes does not contain any financial covenants or restrictions on the payments of dividends, the incurrence of indebtedness, or the issuance or repurchase of securities by us or any of our subsidiaries. The 2019 Notes and 2023 Notes mature on July 1, 2019 and July 1, 2023, respectively. We cannot redeem either series of Notes prior to the applicable maturity date.

[0001327567-19-000016:notes:91]
Holders of the Notes may surrender their Notes for conversion at their option at any time prior to the close of business on the business day immediately preceding their respective convertible dates only under the following circumstances:

[0001327567-19-000016:notes:92]
| • | during any fiscal quarter commencing after the fiscal quarters ending on October 31, 2014 and October 31, 2018, for the 2019 Notes and 2023 Notes, respectively (and only during such fiscal quarter), if the last reported sale price of our common stock for at least 20 trading days (whether or not consecutive) during a period of 30 consecutive trading days ending on the last trading day of the immediately preceding fiscal quarter is greater than or equal to 130% of the applicable conversion price for the respective Notes on each applicable trading day (the “sale price condition”); |

[0001327567-19-000016:notes:93]
| • | during the five business day period after any five consecutive trading day period (the “measurement period”) in which the trading price per $1,000 principal amount of the applicable series of Notes for each trading day of the measurement period was less than 98% of the product of the last reported sale price of our common stock and the applicable conversion rate for the respective Notes on each such trading day; or |

[0001327567-19-000016:notes:94]
| • | upon the occurrence of specified corporate events. |

[0001327567-19-000016:notes:95]
On or after the respective convertible date, holders may surrender all or any portion of their Notes for conversion at any time prior to the close of business on the second scheduled trading day immediately preceding the applicable maturity date regardless of the foregoing conditions, and such conversions will be settled upon the applicable maturity date. Upon conversion, holders of the Notes of a series will receive cash equal to the aggregate principal amount of the Notes of such series to be converted, and, at our election, cash and/or shares of our common stock for any amounts in excess of the aggregate principal amount of the Notes of such series being converted.

[0001327567-19-000016:notes:96]
The conversion price will be subject to adjustment in some events. Holders of the Notes of a series who convert their Notes of such series in connection with certain corporate events that constitute a “make-whole fundamental change” under the applicable Indenture are, under certain circumstances, entitled to an increase in the conversion rate for such series of Notes. Additionally, upon the occurrence of a corporate event that constitutes a “fundamental change” under the applicable Indenture, holders of the Notes of such series may require us to repurchase for cash all or a portion of the Notes of such series at a repurchase price equal to 100% of the principal amount of the Notes of such series plus accrued and unpaid interest to, but excluding, the fundamental change repurchase date.

[0001327567-19-000016:notes:97]
The sale price condition was met for the 2019 Notes during the fiscal quarters ended July 31, 2018 and October 31, 2018. As a result, holders were able to convert their 2019 Notes at any time during the fiscal quarter ended October 31, 2018 and up to January 1, 2019. On or after January 1, 2019, holders may surrender their 2019 Notes for conversion at any time prior to maturity, in accordance with the terms described above. Such conversion requests will settle upon maturity of the 2019 Notes in the fourth quarter of fiscal 2019. Accordingly, the net carrying amount of the 2019 Notes was classified as a current liability and the portion of the equity component representing the conversion option was classified as temporary equity in our condensed consolidated balance sheets as of April 30, 2019. As of April 30, 2019, $159.4 million in aggregate principal amount of the 2019 Notes remained outstanding.

[0001327567-19-000016:notes:98]
There were no conversions of the 2019 Notes during the three months ended April 30, 2019. The following table presents details of conversions of the 2019 Notes during the nine months ended April 30, 2019 (in millions):

[0001327567-19-000016:notes:99]
The sale price condition was not met for the 2023 Notes during the fiscal quarters ended April 30, 2019 or July 31, 2018. Since the 2023 Notes were not convertible, the net carrying amount of the 2023 Notes was classified as a long-term liability and the equity component was included in additional paid-in capital in our condensed consolidated balance sheets as of April 30, 2019 and July 31, 2018. As of April 30, 2019, all of the 2023 Notes remained outstanding.

[0001327567-19-000016:notes:100]
The total estimated fair value of the Notes was $2.3 billion and $2.7 billion at April 30, 2019 and July 31, 2018, respectively. The fair value was determined based on the closing trading price per $100 of the Notes as of the last day of trading for the period. We consider the fair value of the Notes at April 30, 2019 and July 31, 2018 to be a Level 2 measurement. The fair value of the Notes is primarily affected by the trading price of our common stock and market interest rates. As of April 30, 2019, the if-converted value of the 2019 Notes exceeded its principal amount by $191.1 million. Based on the closing price of our common stock on April 30, 2019, the if-converted value of the 2023 Notes was less than its principal amount.

[0001327567-19-000016:notes:101]
The following table sets forth interest expense recognized related to the Notes (dollars in millions):

[0001327567-19-000016:notes:102]
|  | Three Months Ended April 30, |  | Nine Months Ended April 30, |
|  | 2019 |  | 2018 |  | 2019 |  | 2018 |
|  | 2019 Notes |  | 2023 Notes |  | Total |  | 2019 Notes |  | 2023 Notes |  | Total |  | 2019 Notes |  | 2023 Notes |  | Total |  | 2019 Notes |  | 2023 Notes |  | Total |
| Contractual interest expense | $ | — |  |  | $ | 3.3 |  |  | $ | 3.3 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 9.6 |  |  | $ | 9.6 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Amortization of debt discount | 1.6 |  |  | 14.7 |  |  | 16.3 |  |  | 5.7 |  |  | — |  |  | 5.7 |  |  | 7.6 |  |  | 43.6 |  |  | 51.2 |  |  | 17.1 |  |  | — |  |  | 17.1 |  |
| Amortization of debt issuance costs | 0.3 |  |  | 0.5 |  |  | 0.8 |  |  | 0.8 |  |  | — |  |  | 0.8 |  |  | 1.0 |  |  | 1.4 |  |  | 2.4 |  |  | 2.1 |  |  | — |  |  | 2.1 |  |
| Total interest expense recognized | $ | 1.9 |  |  | $ | 18.5 |  |  | $ | 20.4 |  |  | $ | 6.5 |  |  | $ | — |  |  | $ | 6.5 |  |  | $ | 8.6 |  |  | $ | 54.6 |  |  | $ | 63.2 |  |  | $ | 19.2 |  |  | $ | — |  |  | $ | 19.2 |  |
| Effective interest rate of the liability component | 4.8 | % |  | 5.2 | % |  |  |  | 4.8 | % |  | — | % |  |  |  | 4.8 | % |  | 5.2 | % |  |  |  | 4.8 | % |  | — | % |  |  |

[0001327567-19-000016:notes:103]
Note Hedges

[0001327567-19-000016:notes:104]
To minimize the impact of potential economic dilution upon conversion of the Notes, we entered into separate convertible note hedge transactions (the “2019 Note Hedges,” with respect to the 2019 Notes, and the “2023 Note Hedges,” with respect to the 2023 Notes, and collectively, the “Note Hedges”) with respect to our common stock concurrent with the issuance of each series of Notes.

[0001327567-19-000016:notes:105]
The Note Hedges cover shares of our common stock at a strike price per share that corresponds to the initial applicable conversion price of the applicable series of Notes, which are also subject to adjustment, and are exercisable upon conversion of the applicable series of Notes. The Note Hedges will expire upon maturity of the applicable series of Notes. The Note Hedges are separate transactions and are not part of the terms of the applicable series of the Notes. Holders of the Notes of either series will not have any rights with respect to the Note Hedges. Any shares of our common stock receivable by us under the Note Hedges are excluded from the calculation of diluted earnings per share as they are antidilutive. The aggregate amounts paid for the Note Hedges are included in additional paid-in capital in our consolidated balance sheets.

[0001327567-19-000016:notes:106]
As a result of the conversions of the 2019 Notes settled during the nine months ended April 30, 2019, we exercised the corresponding portion of our 2019 Note Hedges and received 1.7 million shares of common stock during the period.

[0001327567-19-000016:notes:107]
Warrants

[0001327567-19-000016:notes:108]
Separately, but concurrently with the issuance of each series of Notes, we entered into transactions whereby we sold warrants (the “2019 Warrants,” with respect to the 2019 Notes, and the “2023 Warrants,” with respect to the 2023 Notes, and collectively, the “Warrants”) to acquire shares of our common stock, subject to anti-dilution adjustments. The 2019 Warrants and 2023 Warrants are exercisable beginning October 2019 and October 2023, respectively.

[0001327567-19-000016:notes:109]
The following table presents details of the Warrants (in millions, except per share data):

[0001327567-19-000016:notes:110]
|  | Initial Number of Shares |  | Strike Price per Share |  | Aggregate Proceeds |
| 2019 Warrants | 5.2 |  |  | $ | 137.85 |  |  | $ | 78.3 |  |
| 2023 Warrants | 6.4 |  |  | $ | 417.80 |  |  | $ | 145.4 |  |

[0001327567-19-000016:notes:111]
The shares issuable under the Warrants will be included in the calculation of diluted earnings per share when the average market value per share of our common stock for the reporting period exceeds the applicable strike price for such series of Warrants. The Warrants are separate transactions and are not part of either series of Notes or Note Hedges and are not remeasured through earnings each reporting period. Holders of the Notes of either series will not have any rights with respect to the Warrants. The aggregate proceeds received from the sale of the Warrants are included in additional paid-in capital in our consolidated balance sheets.

[0001327567-19-000016:notes:112]
Revolving Credit Facility

[0001327567-19-000016:notes:113]
On September 4, 2018, we entered into a credit agreement (the “Credit Agreement”) with certain institutional lenders that provides for a $400.0 million unsecured revolving credit facility (the “Credit Facility”), with an option to increase the amount of the Credit Facility by up to an additional $350.0 million, subject to certain conditions. The Credit Facility matures on the earlier of (i) September 4, 2023 and (ii) the date that is 91 days prior to the stated maturity of our 2023 Notes if (a) any of the 2023 Notes are still outstanding and (b) our unrestricted cash and cash equivalents are less than the then outstanding principal amount of our 2023 Notes plus $400.0 million.

[0001327567-19-000016:notes:114]
The borrowings under the Credit Facility bear interest, at our option, at a base rate plus a spread of 0.00% to 0.75%, or an adjusted LIBO rate plus a spread of 1.00% to 1.75%, in each case with such spread being determined based on our leverage ratio. We are obligated to pay an ongoing commitment fee on undrawn amounts at a rate of 0.125% to 0.250%, depending on our leverage ratio. As of April 30, 2019, there were no amounts outstanding and we were in compliance with all covenants under the Credit Agreement.


## us-gaap:DebtSecuritiesAvailableForSaleTableTextBlock

[0001327567-19-000016:notes:115]
The following tables summarize the amortized cost, unrealized gains and losses, and fair value of our available-for-sale securities as of April 30, 2019 and July 31, 2018 (in millions):

[0001327567-19-000016:notes:116]
|  | April 30, 2019 |
|  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Fair Value |
| Cash equivalents: |  |  |  |  |  |  |  |
| Commercial paper | $ | 27.0 |  |  | $ | — |  |  | $ | — |  |  | $ | 27.0 |  |
| Corporate debt securities | 15.0 |  |  | — |  |  | — |  |  | 15.0 |  |
| U.S. government and agency securities | 340.0 |  |  | — |  |  | — |  |  | 340.0 |  |
| Total available-for-sale cash equivalents | $ | 382.0 |  |  | $ | — |  |  | $ | — |  |  | $ | 382.0 |  |
| Investments: |  |  |  |  |  |  |  |
| Commercial paper | $ | 19.5 |  |  | $ | — |  |  | $ | — |  |  | $ | 19.5 |  |
| Corporate debt securities | 540.5 |  |  | 1.3 |  |  | (0.7 | ) |  | 541.1 |  |
| U.S. government and agency securities | 1,843.2 |  |  | 1.6 |  |  | (2.3 | ) |  | 1,842.5 |  |
| Total available-for-sale investments | $ | 2,403.2 |  |  | $ | 2.9 |  |  | $ | (3.0 | ) |  | $ | 2,403.1 |  |

[0001327567-19-000016:notes:117]
|  | July 31, 2018 |
|  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Fair Value |
| Cash equivalents: |  |  |  |  |  |  |  |
| Commercial paper | $ | 52.0 |  |  | $ | — |  |  | $ | — |  |  | $ | 52.0 |  |
| U.S. government and agency securities | 397.3 |  |  | — |  |  | — |  |  | 397.3 |  |
| Total available-for-sale cash equivalents | $ | 449.3 |  |  | $ | — |  |  | $ | — |  |  | $ | 449.3 |  |
| Investments: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 5.4 |  |  | $ | — |  |  | $ | — |  |  | $ | 5.4 |  |
| Non-U.S. government securities | 20.0 |  |  | — |  |  | — |  |  | 20.0 |  |
| Commercial paper | 22.3 |  |  | — |  |  | — |  |  | 22.3 |  |
| Corporate debt securities | 295.9 |  |  | — |  |  | (2.5 | ) |  | 293.4 |  |
| U.S. government and agency securities | 1,110.6 |  |  | — |  |  | (7.7 | ) |  | 1,102.9 |  |
| Total available-for-sale investments | $ | 1,454.2 |  |  | $ | — |  |  | $ | (10.2 | ) |  | $ | 1,444.0 |  |


## us-gaap:DeferredChargesPolicyTextBlock

[0001327567-19-000016:notes:118]
[same as prior period, unchanged from 0001327567-19-000008:notes:109]

[0001327567-19-000016:notes:119]
[same as prior period, unchanged from 0001327567-19-000008:notes:110]

[0001327567-19-000016:notes:120]
[same as prior period, unchanged from 0001327567-19-000008:notes:111]


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001327567-19-000016:notes:121]
[same as prior period, unchanged from 0001327567-19-000008:notes:112]

[0001327567-19-000016:notes:122]
[same as prior period, unchanged from 0001327567-19-000008:notes:113]

[0001327567-19-000016:notes:123]
[same as prior period, unchanged from 0001327567-19-000008:notes:114]

[0001327567-19-000016:notes:124]
[same as prior period, unchanged from 0001327567-19-000008:notes:115]

[0001327567-19-000016:notes:125]
As of April 30, 2019 and July 31, 2018, the total notional amount of our outstanding foreign currency forward contracts was $142.8 million and $288.5 million, respectively. Refer to Note 3. Fair Value Measurements for the fair value of our derivative instruments as reported in our condensed consolidated balance sheets as of April 30, 2019.

[0001327567-19-000016:notes:126]
During the three and nine months ended April 30, 2019 and 2018, both unrealized gains and losses recognized in AOCI related to our cash flow hedges and amounts reclassified into earnings were not material. Unrealized losses in AOCI related to our cash flow hedges as of April 30, 2019 and 2018 were not material.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001327567-19-000016:notes:127]
[same as prior period, unchanged from 0001327567-19-000008:notes:118]

[0001327567-19-000016:notes:128]
[same as prior period, unchanged from 0001327567-19-000008:notes:119]

[0001327567-19-000016:notes:129]
[same as prior period, unchanged from 0001327567-19-000008:notes:120]

[0001327567-19-000016:notes:130]
[same as prior period, unchanged from 0001327567-19-000008:notes:121]

[0001327567-19-000016:notes:131]
Demisto, Inc. 2015 Stock Option Plan

[0001327567-19-000016:notes:132]
In connection with our acquisition of Demisto on March 28, 2019, we assumed Demisto’s 2015 Stock Option Plan, as amended (the “Demisto Plan”), under which the assumed Demisto equity awards were granted. The assumed equity awards will be settled in shares of our common stock and will retain the terms and conditions under which they were originally granted; forfeited awards will not be returned to the Demisto Plan. No additional equity awards will be granted under the Demisto Plan. Refer to Note 6. Acquisitions for more information on the Demisto acquisition and the related equity awards assumed.

[0001327567-19-000016:notes:133]
[same as prior period, unchanged from 0001327567-19-000008:notes:122]

[0001327567-19-000016:notes:134]
[same as prior period, unchanged from 0001327567-19-000008:notes:123]

[0001327567-19-000016:notes:135]
|  | Stock Options Outstanding |  | PSOs Outstanding |
|  | Number of Shares |  | Weighted-Average Exercise Price Per Share |  | Weighted-Average Remaining Contractual Term(Years) |  | Aggregate Intrinsic Value |  | Number of Shares |  | Weighted-Average Exercise Price Per Share |  | Weighted-Average Remaining Contractual Term(Years) |  | Aggregate Intrinsic Value |
| Balance—July 31, 2018 | 1.0 |  |  | $ | 13.29 |  |  | 3.1 |  | $ | 199.8 |  |  | 1.2 |  |  | $ | 198.50 |  |  | 7.0 |  | $ | — |  |
| Granted | — |  |  | $ | — |  |  |  |  |  |  | 2.6 |  |  | $ | 191.97 |  |  |  |  |  |
| Exercised | (0.6 | ) |  | $ | 13.07 |  |  |  |  |  |  | — |  |  | $ | — |  |  |  |  |  |
| Forfeited | — |  |  | $ | — |  |  |  |  |  |  | — |  |  | $ | — |  |  |  |  |  |
| Balance—April 30, 2019 | 0.4 |  |  | $ | 13.54 |  |  | 2.5 |  | $ | 122.7 |  |  | 3.8 |  |  | $ | 193.98 |  |  | 6.5 |  | $ | 206.9 |  |
| Exercisable—April 30, 2019 | 0.4 |  |  | $ | 13.54 |  |  | 2.5 |  | $ | 122.7 |  |  | 3.8 |  |  | $ | 193.98 |  |  | 6.5 |  | $ | 206.9 |  |

[0001327567-19-000016:notes:136]
During the nine months ended April 30, 2019, we granted 2.6 million PSOs with both a market condition and a service condition to certain executives. The market condition requires the price of our common stock to equal or exceed $297.75, $397.00, $496.25, and $595.50 (the “stock price targets”) during the four-, five-, six-, and seven-year periods following the date of grant, respectively. To the extent that the stock price targets have been met, one-fourth of the PSOs will vest on the anniversary date of the grant date for such PSOs, subject to continued service. All outstanding PSOs may be exercised prior to vesting (“early exercised”). Shares of common stock issued upon early exercise of the PSOs will be restricted and, at our option, subject to repurchase if the option holder ceases to be a service provider.

[0001327567-19-000016:notes:137]
The aggregate fair value of the PSOs granted during the nine months ended April 30, 2019 was $154.5 million, which was estimated on the grant date using a Monte Carlo simulation model. The following table summarizes the assumptions used and the resulting grant-date fair values of our PSOs:

[0001327567-19-000016:notes:138]
|  | Nine Months Ended |
|  | April 30, 2019 |
| Volatility | 35.6% - 36.5% |  |
| Dividend yield | — | % |
| Risk-free interest rate | 3.1% - 3.2% |  |
| Weighted-average grant-date fair value per share | $56.44 - $59.64 |  |

[0001327567-19-000016:notes:139]
[same as prior period, unchanged from 0001327567-19-000008:notes:128]

[0001327567-19-000016:notes:140]
[same as prior period, unchanged from 0001327567-19-000008:notes:129]

[0001327567-19-000016:notes:141]
[same as prior period, unchanged from 0001327567-19-000008:notes:130]

[0001327567-19-000016:notes:142]
|  | RSAs and PSAs Outstanding |  | RSUs and PSUs Outstanding |
|  | Number of Shares |  | Weighted-Average Grant-Date Fair Value Per Share |  | Number of Shares |  | Weighted-Average Grant-Date Fair Value Per Share |  | Weighted-Average Remaining Contractual Term(Years) |  | Aggregate Intrinsic Value |
| Balance—July 31, 2018 | 0.3 |  |  | $ | 160.85 |  |  | 6.7 |  |  | $ | 160.20 |  |  | 1.6 |  | $ | 1,335.2 |  |
| Granted(1)(2) | — |  |  | $ | — |  |  | 3.0 |  |  | $ | 206.85 |  |  |  |  |  |
| Vested | (0.2 | ) |  | $ | 166.07 |  |  | (2.1 | ) |  | $ | 156.83 |  |  |  |  |  |
| Forfeited | — |  |  | $ | — |  |  | (0.6 | ) |  | $ | 159.19 |  |  |  |  |  |
| Balance—April 30, 2019 | 0.1 |  |  | $ | 148.54 |  |  | 7.0 |  |  | $ | 181.14 |  |  | 1.5 |  | $ | 1,738.8 |  |

[0001327567-19-000016:notes:143]
[same as prior period, unchanged from 0001327567-19-000008:notes:132]

[0001327567-19-000016:notes:144]
| (2) | Includes 0.3 million RSUs granted under the assumed RedLock Plan and Demisto Plan with a weighted-average grant-date fair value of $219.25 per share. |

[0001327567-19-000016:notes:145]
[same as prior period, unchanged from 0001327567-19-000008:notes:134]

[0001327567-19-000016:notes:146]
[same as prior period, unchanged from 0001327567-19-000008:notes:135]

[0001327567-19-000016:notes:147]
[same as prior period, unchanged from 0001327567-19-000008:notes:136]

[0001327567-19-000016:notes:148]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 30, |  | April 30, |
|  | 2019 |  | 2018 |  | 2019 |  | 2018 |
| Cost of product revenue | $ | 1.3 |  |  | $ | 1.7 |  |  | $ | 4.3 |  |  | $ | 5.5 |  |
| Cost of subscription and support revenue | 17.2 |  |  | 15.1 |  |  | 52.9 |  |  | 50.9 |  |
| Research and development | 45.1 |  |  | 35.4 |  |  | 129.6 |  |  | 108.4 |  |
| Sales and marketing | 54.5 |  |  | 50.7 |  |  | 169.2 |  |  | 155.2 |  |
| General and administrative | 20.1 |  |  | 20.8 |  |  | 75.7 |  |  | 60.2 |  |
| Total share-based compensation | $ | 138.2 |  |  | $ | 123.7 |  |  | $ | 431.7 |  |  | $ | 380.2 |  |

[0001327567-19-000016:notes:149]
In connection with our acquisition of RedLock, we accelerated the vesting of certain equity awards and as a result, we recorded $14.2 million of share-based compensation within general and administrative expense during the three months ended October 31, 2018.

[0001327567-19-000016:notes:150]
As of April 30, 2019, total compensation cost related to unvested share-based awards not yet recognized was $1.4 billion. This cost is expected to be amortized over a weighted-average period of approximately 2.8 years. Future grants will increase the amount of compensation expense to be recorded in these periods.


## us-gaap:EarningsPerShareTextBlock

[0001327567-19-000016:notes:151]
[same as prior period, unchanged from 0001327567-19-000008:notes:140]

[0001327567-19-000016:notes:152]
[same as prior period, unchanged from 0001327567-19-000008:notes:141]

[0001327567-19-000016:notes:153]
[same as prior period, unchanged from 0001327567-19-000008:notes:142]

[0001327567-19-000016:notes:154]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 30, |  | April 30, |
|  | 2019 |  | 2018 |  | 2019 |  | 2018 |
|  |  |  | (As Adjusted) |  |  |  | (As Adjusted) |
| Net loss | $ | (20.2 | ) |  | $ | (40.4 | ) |  | $ | (61.1 | ) |  | $ | (129.2 | ) |
| Weighted-average shares used to compute net loss per share, basic and diluted | 94.4 |  |  | 91.9 |  |  | 94.1 |  |  | 91.3 |  |
| Net loss per share, basic and diluted | $ | (0.21 | ) |  | $ | (0.44 | ) |  | $ | (0.65 | ) |  | $ | (1.42 | ) |

[0001327567-19-000016:notes:155]
[same as prior period, unchanged from 0001327567-19-000008:notes:144]

[0001327567-19-000016:notes:156]
|  | Three and Nine Months Ended |
|  | April 30, |
|  | 2019 |  | 2018 |
| Convertible senior notes | 7.8 |  |  | 5.2 |  |
| Warrants related to the issuance of convertible senior notes | 11.6 |  |  | 5.2 |  |
| RSUs and PSUs | 7.0 |  |  | 6.1 |  |
| Options to purchase common stock, including PSOs | 4.2 |  |  | 1.2 |  |
| RSAs and PSAs | 0.1 |  |  | 0.4 |  |
| ESPP shares | 0.1 |  |  | 0.1 |  |
| Total | 30.8 |  |  | 18.2 |  |


## us-gaap:FairValueDisclosuresTextBlock

[0001327567-19-000016:notes:157]
[same as prior period, unchanged from 0001327567-19-000008:notes:146]

[0001327567-19-000016:notes:158]
[same as prior period, unchanged from 0001327567-19-000008:notes:147]

[0001327567-19-000016:notes:159]
[same as prior period, unchanged from 0001327567-19-000008:notes:148]

[0001327567-19-000016:notes:160]
[same as prior period, unchanged from 0001327567-19-000008:notes:149]

[0001327567-19-000016:notes:161]
[same as prior period, unchanged from 0001327567-19-000008:notes:150]

[0001327567-19-000016:notes:162]
The following table presents the fair value of our financial assets and liabilities measured at fair value on a recurring basis using the above input categories as of April 30, 2019 and July 31, 2018 (in millions):

[0001327567-19-000016:notes:163]
|  |  | April 30, 2019 |  | July 31, 2018 |
|  |  | Level 1 |  | Level 2 |  | Level 3 |  | Total |  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| Cash equivalents: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 155.0 |  |  | $ | — |  |  | $ | — |  |  | $ | 155.0 |  |  | $ | 1,512.3 |  |  | $ | — |  |  | $ | — |  |  | $ | 1,512.3 |  |
| Commercial paper |  | — |  |  | 27.0 |  |  | — |  |  | 27.0 |  |  | — |  |  | 52.0 |  |  | — |  |  | 52.0 |  |
| Corporate debt securities |  | — |  |  | 15.0 |  |  | — |  |  | 15.0 |  |  | — |  |  | — |  |  | — |  |  | — |  |
| U.S. government and agency securities |  | — |  |  | 340.0 |  |  | — |  |  | 340.0 |  |  | — |  |  | 397.3 |  |  | — |  |  | 397.3 |  |
| Total cash equivalents |  | 155.0 |  |  | 382.0 |  |  | — |  |  | 537.0 |  |  | 1,512.3 |  |  | 449.3 |  |  | — |  |  | 1,961.6 |  |
| Short-term investments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Certificates of deposit |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 5.4 |  |  | — |  |  | 5.4 |  |
| Non-U.S. government securities |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 20.0 |  |  | — |  |  | 20.0 |  |
| Commercial paper |  | — |  |  | 19.5 |  |  | — |  |  | 19.5 |  |  | — |  |  | 22.3 |  |  | — |  |  | 22.3 |  |
| Corporate debt securities |  | — |  |  | 269.8 |  |  | — |  |  | 269.8 |  |  | — |  |  | 139.8 |  |  | — |  |  | 139.8 |  |
| U.S. government and agency securities |  | — |  |  | 1,443.9 |  |  | — |  |  | 1,443.9 |  |  | — |  |  | 709.0 |  |  | — |  |  | 709.0 |  |
| Total short-term investments |  | — |  |  | 1,733.2 |  |  | — |  |  | 1,733.2 |  |  | — |  |  | 896.5 |  |  | — |  |  | 896.5 |  |
| Long-term investments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Corporate debt securities |  | — |  |  | 271.3 |  |  | — |  |  | 271.3 |  |  | — |  |  | 153.6 |  |  | — |  |  | 153.6 |  |
| U.S. government and agency securities |  | — |  |  | 398.6 |  |  | — |  |  | 398.6 |  |  | — |  |  | 393.9 |  |  | — |  |  | 393.9 |  |
| Total long-term investments |  | — |  |  | 669.9 |  |  | — |  |  | 669.9 |  |  | — |  |  | 547.5 |  |  | — |  |  | 547.5 |  |
| Prepaid expenses and other current assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency forward contracts |  | — |  |  | 0.1 |  |  | — |  |  | 0.1 |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Total prepaid expenses and other current assets |  | — |  |  | 0.1 |  |  | — |  |  | 0.1 |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Total assets measured at fair value |  | $ | 155.0 |  |  | $ | 2,785.2 |  |  | $ | — |  |  | $ | 2,940.2 |  |  | $ | 1,512.3 |  |  | $ | 1,893.3 |  |  | $ | — |  |  | $ | 3,405.6 |  |
| Accrued and other liabilities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency forward contracts |  | $ | — |  |  | $ | 5.3 |  |  | $ | — |  |  | $ | 5.3 |  |  | $ | — |  |  | $ | 6.9 |  |  | $ | — |  |  | $ | 6.9 |  |
| Total accrued and other liabilities |  | — |  |  | 5.3 |  |  | — |  |  | 5.3 |  |  | — |  |  | 6.9 |  |  | — |  |  | 6.9 |  |
| Total liabilities measured at fair value |  | $ | — |  |  | $ | 5.3 |  |  | $ | — |  |  | $ | 5.3 |  |  | $ | — |  |  | $ | 6.9 |  |  | $ | — |  |  | $ | 6.9 |  |

[0001327567-19-000016:notes:164]
Refer to Note 9. Debt for the carrying amount and estimated fair value of our convertible senior notes as of April 30, 2019 and July 31, 2018.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001327567-19-000016:notes:165]
[same as prior period, unchanged from 0001327567-19-000008:notes:154]

[0001327567-19-000016:notes:166]
[same as prior period, unchanged from 0001327567-19-000008:notes:155]

[0001327567-19-000016:notes:167]
The following table presents details of our goodwill during the nine months ended April 30, 2019 (in millions):

[0001327567-19-000016:notes:168]
|  | Amount |
| Balance as of July 31, 2018 | $ | 522.8 |  |
| Goodwill acquired | 504.5 |  |
| Balance as of April 30, 2019 | $ | 1,027.3 |  |

[0001327567-19-000016:notes:169]
[same as prior period, unchanged from 0001327567-19-000008:notes:158]

[0001327567-19-000016:notes:170]
The following table presents details of our purchased intangible assets as of April 30, 2019 and July 31, 2018 (in millions):

[0001327567-19-000016:notes:171]
|  | April 30, 2019 |  | July 31, 2018 |
|  | Gross Carrying Amount |  | Accumulated Amortization |  | Net Carrying Amount |  | Gross Carrying Amount |  | Accumulated Amortization |  | Net Carrying Amount |
| Intangible assets subject to amortization: |  |  |  |  |  |  |  |  |  |  |  |
| Developed technology | $ | 259.9 |  |  | $ | (65.2 | ) |  | $ | 194.7 |  |  | $ | 154.7 |  |  | $ | (38.2 | ) |  | $ | 116.5 |  |
| Customer relationships | 37.2 |  |  | (3.2 | ) |  | 34.0 |  |  | 12.2 |  |  | (1.2 | ) |  | 11.0 |  |
| Acquired intellectual property | 8.9 |  |  | (5.0 | ) |  | 3.9 |  |  | 8.9 |  |  | (4.5 | ) |  | 4.4 |  |
| Trade name and trademarks | 9.4 |  |  | (9.4 | ) |  | — |  |  | 8.5 |  |  | (0.4 | ) |  | 8.1 |  |
| Other | 2.2 |  |  | (2.2 | ) |  | — |  |  | 2.2 |  |  | (2.2 | ) |  | — |  |
| Total intangible assets subject to amortization | 317.6 |  |  | (85.0 | ) |  | 232.6 |  |  | 186.5 |  |  | (46.5 | ) |  | 140.0 |  |
| Intangible assets not subject to amortization: |  |  |  |  |  |  |  |  |  |  |  |
| In-process research and development | 1.6 |  |  | — |  |  | 1.6 |  |  | 0.8 |  |  | — |  |  | 0.8 |  |
| Total purchased intangible assets | $ | 319.2 |  |  | $ | (85.0 | ) |  | $ | 234.2 |  |  | $ | 187.3 |  |  | $ | (46.5 | ) |  | $ | 140.8 |  |

[0001327567-19-000016:notes:172]
We recognized amortization expense of $14.7 million and $38.5 million for the three and nine months ended April 30, 2019, respectively, and $3.8 million and $9.2 million for the three and nine months ended April 30, 2018, respectively.

[0001327567-19-000016:notes:173]
The following table summarizes estimated future amortization expense of our intangible assets as of April 30, 2019 (in millions):

[0001327567-19-000016:notes:174]
|  | Amount |
| Fiscal years ending July 31: |  |
| Remaining 2019 | $ | 14.3 |  |
| 2020 | 56.9 |  |
| 2021 | 54.9 |  |
| 2022 | 50.4 |  |
| 2023 | 24.5 |  |
| 2024 and thereafter | 31.6 |  |
| Total future amortization expense | $ | 232.6 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0001327567-19-000016:notes:175]
[same as prior period, unchanged from 0001327567-19-000008:notes:164]

[0001327567-19-000016:notes:176]
Our provision for (benefit from) income taxes for the three and nine months ended April 30, 2019 reflects an effective tax rate of 4.3% and (0.3)%, respectively. Our effective tax rate for the nine months ended April 30, 2019 was negative as we recorded a provision for income taxes on year to date losses. The key components of our income tax provision, excluding one-time items, primarily consist of foreign and U.S. state income taxes and withholding taxes. During the nine months ended April 30, 2019, the effect of these key components was primarily offset by one-time tax benefits of $9.4 million and $4.9 million from partial releases of our valuation allowance related to the acquisitions of RedLock and Demisto recorded during the three months ended October 31, 2018 and April 30, 2019, respectively. Our effective tax rates differ from the U.S. statutory tax rate primarily due to deductibility of our share-based compensation, foreign income at other than U.S. tax rates, and changes in our valuation allowance.

[0001327567-19-000016:notes:177]
Our provision for (benefit from) income taxes for the three and nine months ended April 30, 2018 reflects an effective tax rate of 6.5% and (5.7)%. Our effective tax rate for the nine months ended April 30, 2018 was negative as we recorded a provision for income taxes on year to date losses. The key components of our income tax provision primarily consisted of foreign income taxes, withholding taxes, and amortization of our deferred tax charges. In addition, we recorded the following one-time tax benefits during the nine months ended April 30, 2018: $5.8 million due to new tax legislation enacted during the fiscal quarter ended January 31, 2018; $4.6 million due to a partial release of our valuation allowance related to our acquisition of Evident.io, Inc. during the fiscal quarter ended April 30, 2018; and $3.5 million due to an Israeli judicial ruling related to share-based compensation during the fiscal quarter ended April 30, 2018. Our effective tax rates differed from the U.S. statutory tax rate primarily due to deductibility of our share-based compensation, foreign income at other than U.S. tax rates, and changes in our valuation allowance.

[0001327567-19-000016:notes:178]
In December 2017, the Tax Cuts and Jobs Act (“TCJA”) was enacted into law. The SEC staff and FASB previously issued guidance that allowed companies to record provisional amounts for the effects of the TCJA during a measurement period not to extend beyond one year from the enactment date. The measurement period ended in December 2018 and we completed our accounting for the income tax effects of the TCJA during the three months ended January 31, 2019. During the three and nine months ended April 30, 2019, we did not have any significant adjustments to provisional estimates recorded in previous periods. The recorded impact for the effects of the TCJA is based on our current knowledge, assumptions, and interpretations of available guidance. We will continue to monitor the issuance of further guidance and record the necessary adjustments in the period additional guidance is issued.


## us-gaap:InvestmentsClassifiedByContractualMaturityDateTableTextBlock

[0001327567-19-000016:notes:179]
The following table summarizes the amortized cost and fair value of our available-for-sale securities as of April 30, 2019, by contractual years-to-maturity (in millions):

[0001327567-19-000016:notes:180]
|  | Amortized Cost |  | Fair Value |
| Due within one year | $ | 2,116.0 |  |  | $ | 2,115.2 |  |
| Due between one and three years | 669.2 |  |  | 669.9 |  |
| Total | $ | 2,785.2 |  |  | $ | 2,785.1 |  |


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock

[0001327567-19-000016:notes:181]
Cash Equivalents and Investments

[0001327567-19-000016:notes:182]
Available-for-sale Securities

[0001327567-19-000016:notes:183]
Unrealized losses related to these securities are due to interest rate fluctuations as opposed to credit quality. In addition, we do not intend to sell and it is not likely that we would be required to sell these securities before recovery of their amortized cost basis, which may be at maturity. As a result, there were no other-than-temporary impairments for these securities at April 30, 2019 and July 31, 2018.

[0001327567-19-000016:notes:184]
Marketable Equity Securities

[0001327567-19-000016:notes:185]
Marketable equity securities consist of money market funds and are included in cash and cash equivalents in our condensed consolidated balance sheets. As of April 30, 2019 and July 31, 2018, the carrying value of our marketable equity securities were $155.0 million and $1.5 billion, respectively. There were no unrealized gains or losses recognized for these securities during the three and nine months ended April 30, 2019 and 2018.


## us-gaap:OtherNonoperatingIncomeAndExpenseTextBlock

[0001327567-19-000016:notes:186]
[same as prior period, unchanged from 0001327567-19-000008:notes:175]

[0001327567-19-000016:notes:187]
[same as prior period, unchanged from 0001327567-19-000008:notes:176]

[0001327567-19-000016:notes:188]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 30, |  | April 30, |
|  | 2019 |  | 2018 |  | 2019 |  | 2018 |
| Interest income | $ | 18.3 |  |  | $ | 6.7 |  |  | $ | 51.7 |  |  | $ | 17.7 |  |
| Foreign currency exchange gains (losses), net | (0.1 | ) |  | 2.7 |  |  | (1.3 | ) |  | 0.9 |  |
| Other | — |  |  | (0.8 | ) |  | (3.2 | ) |  | (0.3 | ) |
| Total other income, net | $ | 18.2 |  |  | $ | 8.6 |  |  | $ | 47.2 |  |  | $ | 18.3 |  |


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock

[0001327567-19-000016:notes:189]
Related Party Transactions

[0001327567-19-000016:notes:190]
Certain members of our board of directors are affiliated with Greylock Partners, a venture capital firm. Entities affiliated with Greylock Partners owned a portion of the outstanding shares of Demisto immediately prior to completion of our acquisition of Demisto on March 28, 2019 and, as a result, received purchase consideration valued at $85.6 million during the three months ended April 30, 2019. Refer to Note 6. Acquisitions for more information on our acquisition of Demisto.


## us-gaap:RevenueFromContractWithCustomerPolicyTextBlock

[0001327567-19-000016:notes:191]
Our revenue consists of product revenue and subscription and support revenue. Revenue is recognized when control of promised products, subscriptions and support services are transferred to customers with the expected consideration in exchange for those products and services. Depending on who the contract is with, our customers are either our channel partners or our end-customers.

[0001327567-19-000016:notes:192]
We determine revenue recognition through the following steps:

[0001327567-19-000016:notes:193]
| • | Identification of the contract, or contracts, with a customer. |

[0001327567-19-000016:notes:194]
| • | Identification of the performance obligations in the contract. |

[0001327567-19-000016:notes:195]
| • | Determination of the transaction price. |

[0001327567-19-000016:notes:196]
| • | Allocation of the transaction price to the performance obligations in the contract. |

[0001327567-19-000016:notes:197]
| • | Recognition of revenue when, or as, we satisfy a performance obligation. |

[0001327567-19-000016:notes:198]
Revenues are reported net of sales taxes. Shipping charges billed to channel partners are included in revenues and related costs are included in cost of revenue.

[0001327567-19-000016:notes:199]
Product Revenue

[0001327567-19-000016:notes:200]
Product revenue is derived primarily from sales of our appliances. Product revenue also includes revenue derived from software licenses of Panorama and the VM-Series. We recognize product revenue at the time of hardware shipment or delivery of software license.

[0001327567-19-000016:notes:201]
Subscription and Support Revenue

[0001327567-19-000016:notes:202]
Subscription and support revenue is derived primarily from sales of our subscription and support offerings. We recognize subscription and support revenue over time as the services are performed. Our contractual subscription and support contracts are typically one to five years.

[0001327567-19-000016:notes:203]
Contracts with Multiple Performance Obligations

[0001327567-19-000016:notes:204]
The majority of our contracts with our customers include various combinations of our products and subscriptions and support which are distinct and accounted for as separate performance obligations. We account for multiple agreements with a single customer as a single contract if the contractual terms and/or substance of those agreements indicate that they may be so closely related that they are, in effect, parts of a single contract. The amount of consideration we expect to receive in exchange for delivering on the contract is allocated to each performance obligation based on its relative standalone selling price. If a contract contains a single performance obligation, no allocation is required.

[0001327567-19-000016:notes:205]
We establish standalone selling price using the prices charged for a deliverable when sold separately. If the standalone selling price is not observable through past transactions, we estimate the standalone selling price based on our pricing model and our go-to-market strategy, which include factors such as type of sales channel (reseller, distributor, or end-customer), the geographies in which our offerings were sold (domestic or international), and offering type (products, subscriptions, or support).

[0001327567-19-000016:notes:206]
Deferred Revenue

[0001327567-19-000016:notes:207]
We record deferred revenue when cash payments are received or due in advance of our performance. Our payment terms typically require payment within 30 to 45 days of the date we issue an invoice. The current portion of deferred revenue represents the amounts that are expected to be recognized as revenue within one year of the condensed consolidated balance sheet date.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001327567-19-000016:notes:208]
[same as prior period, unchanged from 0001327567-19-000008:notes:178]

[0001327567-19-000016:notes:209]
We record deferred revenue when cash payments are received or due in advance of our performance. Our payment terms typically require payment within 30 to 45 days of the date we issue an invoice. The current portion of deferred revenue represents the amounts that are expected to be recognized as revenue within one year of the condensed consolidated balance sheet date. During the nine months ended April 30, 2019, we recognized approximately $955.0 million of revenue pertaining to amounts that were deferred as of July 31, 2018.

[0001327567-19-000016:notes:210]
[same as prior period, unchanged from 0001327567-19-000008:notes:196]

[0001327567-19-000016:notes:211]
Revenue expected to be recognized from remaining performance obligations was $2.7 billion as of April 30, 2019, of which we expect to recognize approximately $1.5 billion over the next 12 months and the remainder thereafter.

[0001327567-19-000016:notes:212]
[same as prior period, unchanged from 0001327567-19-000008:notes:198]

[0001327567-19-000016:notes:213]
[same as prior period, unchanged from 0001327567-19-000008:notes:199]

[0001327567-19-000016:notes:214]
|  | Three Months Ended April 30, |  | Nine Months Ended April 30, |
|  | 2019 |  | 2018 |  | 2019 |  | 2018 |
|  |  |  | (As Adjusted) |  |  |  | (As Adjusted) |
| Revenue: |  |  |  |  |  |  |  |
| Americas |  |  |  |  |  |  |  |
| United States | $ | 464.3 |  |  | $ | 358.0 |  |  | $ | 1,314.8 |  |  | $ | 1,030.0 |  |
| Other Americas | 33.5 |  |  | 29.7 |  |  | 108.2 |  |  | 80.3 |  |
| Total Americas | 497.8 |  |  | 387.7 |  |  | 1,423.0 |  |  | 1,110.3 |  |
| Europe, the Middle East, and Africa (“EMEA”) | 138.7 |  |  | 110.1 |  |  | 414.7 |  |  | 312.0 |  |
| Asia Pacific and Japan (“APAC”) | 90.1 |  |  | 69.9 |  |  | 256.1 |  |  | 192.8 |  |
| Total revenue | $ | 726.6 |  |  | $ | 567.7 |  |  | $ | 2,093.8 |  |  | $ | 1,615.1 |  |

[0001327567-19-000016:notes:215]
[same as prior period, unchanged from 0001327567-19-000008:notes:201]

[0001327567-19-000016:notes:216]
|  | Three Months Ended April 30, |  | Nine Months Ended April 30, |
|  | 2019 |  | 2018 |  | 2019 |  | 2018 |
|  |  |  | (As Adjusted) |  |  |  | (As Adjusted) |
| Revenue: |  |  |  |  |  |  |  |
| Product | $ | 278.4 |  |  | $ | 218.1 |  |  | $ | 790.5 |  |  | $ | 607.7 |  |
| Subscription and support |  |  |  |  |  |  |  |
| Subscription | 258.8 |  |  | 192.0 |  |  | 739.8 |  |  | 544.3 |  |
| Support | 189.4 |  |  | 157.6 |  |  | 563.5 |  |  | 463.1 |  |
| Total subscription and support | 448.2 |  |  | 349.6 |  |  | 1,303.3 |  |  | 1,007.4 |  |
| Total revenue | $ | 726.6 |  |  | $ | 567.7 |  |  | $ | 2,093.8 |  |  | $ | 1,615.1 |  |

[0001327567-19-000016:notes:217]
We recognized amortization expense for our deferred contract costs of $57.2 million and $147.6 million during the three and nine months ended April 30, 2019, respectively, and $37.7 million and $101.9 million during the three and nine months ended April 30, 2018, respectively. We did not recognize any impairment losses on our deferred contract costs during the three and nine months ended April 30, 2019 or 2018.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001327567-19-000016:notes:218]
[same as prior period, unchanged from 0001327567-19-000008:notes:204]

[0001327567-19-000016:notes:219]
[same as prior period, unchanged from 0001327567-19-000008:notes:205]

[0001327567-19-000016:notes:220]
In August 2016, our board of directors authorized a $500.0 million share repurchase program to be funded from available working capital. In February 2017, our board of directors authorized a $500.0 million increase to our repurchase program, bringing the total authorization to $1.0 billion (our “original authorization”). Repurchases could be made at management’s discretion from time to time on the open market, through privately negotiated transactions, transactions structured through investment banking institutions, block purchase techniques, 10b5-1 trading plans, or a combination of the foregoing. This repurchase program expired on December 31, 2018.

[0001327567-19-000016:notes:221]
In February 2019, our board of directors authorized a new $1.0 billion share repurchase program which will be funded from available working capital. Repurchases may be made at management’s discretion from time to time on the open market, through privately negotiated transactions, transactions structured through investment banking institutions, block purchase techniques, 10b5-1 trading plans, or a combination of the foregoing. This repurchase authorization will expire on December 31, 2020, and may be suspended or discontinued at any time.

[0001327567-19-000016:notes:222]
During the nine months ended April 30, 2019, we repurchased and retired 1.9 million shares of our common stock under our original authorization for an aggregate purchase price of $330.0 million, including transaction costs. The total price of the shares repurchased and related transaction costs are reflected as a reduction to common stock and additional paid-in capital on our condensed consolidated balance sheets. As of April 30, 2019, $1.0 billion remained available for future share repurchases under our current repurchase authorization.


## us-gaap:SubsequentEventsTextBlock

[0001327567-19-000016:notes:223]
Subsequent Events

[0001327567-19-000016:notes:224]
Business Combination

[0001327567-19-000016:notes:225]
In May 2019, we entered into a definitive agreement to acquire Twistlock Ltd. (“Twistlock”), a privately-held container security company, for total consideration of approximately $410.0 million in cash, subject to adjustment. In May 2019, we also entered into a definitive agreement to acquire PureSec Ltd. (“PureSec”), a privately-held serverless security company, for total consideration of approximately $47.0 million in cash, subject to adjustment. We expect the acquisitions will extend our cloud security strategy with the additions of Twistlock and PureSec to our Prisma cloud security offerings. The acquisitions are expected to close during our fourth quarter of fiscal 2019.
