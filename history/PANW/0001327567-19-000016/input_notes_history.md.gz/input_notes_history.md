# PANW note change history — 0001327567-19-000008 → 0001327567-19-000016


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- added (2019-05-30):
[0001327567-19-000016:note_history:1]
In September 2012, we entered into two lease agreements for a total of approximately 300,000 square feet of space in Santa Clara, California, which served as our previous corporate headquarters through August 2017, when we relocated to our new corporate campus. The leases contain rent holiday periods and two separate five-year options to extend the lease term beyond their expiration dates of July 2023. Rental payments under these lease agreements are approximately $94.3 million over the lease term. In August 2017, we exited our previous corporate headquarter facilities and relocated to our new corporate campus, which resulted in the recognition of a cease-use loss of $39.2 million during the year ended July 31, 2018. Due to changes in market conditions in recent months, and the resulting changes to the amount and timing of estimated cash flows from sublease rentals that could be reasonably obtained, we recognized an additional cease-use loss of $4.1 million as general and administrative expense in our condensed consolidated statements of operations during the three and nine months ended April 30, 2019, and a corresponding liability in our condensed consolidated balance sheets. During the three and nine months ended April 30, 2019, we released $2.6 million and $7.6 million, respectively, of the cease-use liability through rental payments. As of April 30, 2019 and July 31, 2018, the remaining balance of the cease-use liability was $25.6 million and $29.1 million, respectively, which is expected to be paid through the end of the lease term in July 2023.

- changed (2019-05-30):
[0001327567-19-000016:note_history:2]
The following table presents details of the aggregate future non-cancelable minimum rental payments under our operating leases as of April 30, 2019 (in millions):
  (was, 2019-02-27, similarity 0.9747):
[0001327567-19-000008:note_history:2]
The following table presents details of the aggregate future non-cancelable minimum rental payments under our operating leases as of January 31, 2019 (in millions):

- changed (2019-05-30):
[0001327567-19-000016:note_history:3]
|  | Amount |
| Fiscal years ending July 31: |  |
| Remaining 2019 | $ | 17.8 |  |
| 2020 | 73.2 |  |
  (was, 2019-02-27, similarity 0.875):
[0001327567-19-000008:note_history:3]
|  | Amount |
| Fiscal years ending July 31: |  |
| Remaining 2019 | $ | 33.6 |  |
| 2020 | 69.0 |  |
| 2021 | 64.1 |  |
| 2022 | 59.9 |  |

- changed (2019-05-30):
[0001327567-19-000016:note_history:4]
| 2021 | 67.2 |  |
| 2022 | 63.0 |  |
| 2023 | 60.1 |  |
| 2024 and thereafter | 227.7 |  |
| Committed gross lease payments | 509.0 |  |
| Less: proceeds from sublease rentals | 11.2 |  |
| Net operating lease obligation | $ | 497.8 |  |
  (was, 2019-02-27, similarity 0.9344):
[0001327567-19-000008:note_history:4]
| 2023 | 58.6 |  |
| 2024 and thereafter | 223.8 |  |
| Committed gross lease payments | 509.0 |  |
| Less: proceeds from sublease rentals | 12.3 |  |
| Net operating lease obligation | $ | 496.7 |  |

- changed (2019-05-30):
[0001327567-19-000016:note_history:5]
Our electronics manufacturing service provider (“EMS provider”) procures components and assembles our products based on our forecasts. These forecasts are based on estimates of demand for our products primarily for the next 12 months, which are in turn based on historical trends and an analysis from our sales and product management organizations, adjusted for overall market conditions. In order to reduce manufacturing lead times and plan for adequate supply, we may issue non-cancelable orders for products and components to our manufacturing partners or component suppliers. As of April 30, 2019, our purchase commitments under such orders were $129.3 million, excluding obligations under contracts that we can cancel without a significant penalty.
  (was, 2019-02-27, similarity 0.9919):
[0001327567-19-000008:note_history:5]
Our electronics manufacturing service provider (“EMS provider”) procures components and assembles our products based on our forecasts. These forecasts are based on estimates of demand for our products primarily for the next 12 months, which are in turn based on historical trends and an analysis from our sales and product management organizations, adjusted for overall market conditions. In order to reduce manufacturing lead times and plan for adequate supply, we may issue non-cancelable orders for products and components to our manufacturing partners or component suppliers. As of January 31, 2019, our purchase commitments under such orders were $136.8 million, excluding obligations under contracts that we can cancel without a significant penalty.

- changed (2019-05-30):
[0001327567-19-000016:note_history:6]
We have entered into various non-cancelable agreements with third-party providers for our use of certain cloud services, under which we are committed to minimum purchases through the year ending July 31, 2026. The following table presents details of the aggregate future non-cancelable purchase commitments under these agreements as of April 30, 2019 (in millions):
  (was, 2019-02-27, similarity 0.9831):
[0001327567-19-000008:note_history:6]
We have entered into various non-cancelable agreements with third-party providers for our use of certain cloud services, under which we are committed to minimum purchases through the year ending July 31, 2026. The following table presents details of the aggregate future non-cancelable purchase commitments under these agreements as of January 31, 2019 (in millions):

- added (2019-05-30):
[0001327567-19-000016:note_history:7]
To the extent there is a reasonable possibility that a loss exceeding amounts already recognized may be incurred and the amount of such additional loss would be material, we will either disclose the estimated additional loss or state that such an estimate cannot be made. As of April 30, 2019, we have not recorded any significant accruals for loss contingencies associated with such legal proceedings, determined that an unfavorable outcome is probable or reasonably possible, or determined that the amount or range of any possible loss is reasonably estimable.

- removed (2019-05-30):
[0001327567-19-000008:note_history:8]
In September 2012, we entered into two lease agreements for a total of approximately 300,000 square feet of space in Santa Clara, California, which served as our previous corporate headquarters through August 2017, when we relocated to our new corporate campus. The leases contain rent holiday periods and two separate five-year options to extend the lease term beyond their expiration dates of July 2023. Rental payments under these lease agreements are approximately $94.3 million over the lease term. In August 2017, we exited our previous headquarter facilities and relocated to our new corporate campus, which resulted in the recognition of a cease-use loss of $39.2 million as general and administrative expense in our consolidated statements of operations during the year ended July 31, 2018, and a corresponding liability in our consolidated balance sheets. During the three and six months ended January 31, 2019, we released $2.5 million and $5.0 million, respectively, of the cease-use liability through rental payments. As of January 31, 2019, the remaining balance of the cease-use liability was $24.1 million, which is expected to be paid through the end of the lease term in July 2023.

- removed (2019-05-30):
[0001327567-19-000008:note_history:9]
To the extent there is a reasonable possibility that a loss exceeding amounts already recognized may be incurred and the amount of such additional loss would be material, we will either disclose the estimated additional loss or state that such an estimate cannot be made. As of January 31, 2019, we have not recorded any significant accruals for loss contingencies associated with such legal proceedings, determined that an unfavorable outcome is probable or reasonably possible, or determined that the amount or range of any possible loss is reasonably estimable.


## us-gaap:BusinessDescriptionAndAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- added (2019-05-30):
[0001327567-19-000016:note_history:10]
Certain prior period amounts have been reclassified to conform to our current period presentation. In addition, certain prior period amounts have been adjusted due to our retrospective adoption of new accounting guidance related to revenue from contracts with customers and new accounting guidance related to the presentation of restricted cash and cash equivalents in the statement of cash flows. Refer to “Recently Adopted Accounting Pronouncements” below for more information.

- changed (2019-05-30):
[0001327567-19-000016:note_history:11]
There have been no material changes to our significant accounting policies as of and for the nine months ended April 30, 2019, as compared to the significant accounting policies described in our Annual Report on Form 10-K for the fiscal year ended July 31, 2018, except for the change in our accounting policies for revenue recognition and deferred contract costs due to our adoption of new accounting guidance related to revenue from contracts with customers. Refer to “Recently Adopted Accounting Pronouncements” below, Note 2. Revenue, and Note 8. Deferred Contract Costs for more information.
  (was, 2019-02-27, similarity 0.9596):
[0001327567-19-000008:note_history:11]
There have been no material changes to our significant accounting policies as of and for the six months ended January 31, 2019, as compared to the significant accounting policies described in our Annual Report on Form 10-K for the fiscal year ended July 31, 2018, except for the change in our accounting policies for revenue recognition and deferred contract costs due to our adoption of new accounting guidance related to revenue from contracts with customers. Refer to “Recently Adopted Accounting Pronouncements” below, Note 2. Revenue, and Note 8. Deferred Contract Costs for more information.

- changed (2019-05-30):
[0001327567-19-000016:note_history:12]
|  | Three Months Ended April 30, 2018 |  | Nine Months Ended April 30, 2018 |
|  | As Previously Reported |  | Impact of Adoption |  | As Adjusted |  | As Previously Reported |  | Impact of Adoption |  | As Adjusted |
| Condensed Consolidated Statements of Operations |  |  |  |  |  |  |  |  |  |  |  |
| Product revenue | $ | 215.2 |  |  | $ | 2.9 |  |  | $ | 218.1 |  |  | $ | 603.9 |  |  | $ | 3.8 |  |  | $ | 607.7 |  |
| Subscription and support revenue | 351.9 |  |  | (2.3 | ) |  | 349.6 |  |  | 1,011.1 |  |  | (3.7 | ) |  | 1,007.4 |  |
| Total revenue | 567.1 |  |  | 0.6 |  |  | 567.7 |  |  | 1,615.0 |  |  | 0.1 |  |  | 1,615.1 |  |
| Total cost of revenue | 159.9 |  |  | — |  |  | 159.9 |  |  | 460.6 |  |  | — |  |  | 460.6 |  |
| Total operating expenses | 458.8 |  |  | (5.7 | ) |  | 453.1 |  |  | 1,292.1 |  |  | (16.3 | ) |  | 1,275.8 |  |
| Operating loss | (51.6 | ) |  | 6.3 |  |  | (45.3 | ) |  | (137.7 | ) |  | 16.4 |  |  | (121.3 | ) |
| Net loss | (46.7 | ) |  | 6.3 |  |  | (40.4 | ) |  | (145.6 | ) |  | 16.4 |  |  | (129.2 | ) |
| Net loss per share, basic and diluted | $ | (0.51 | ) |  | $ | 0.07 |  |  | $ | (0.44 | ) |  | $ | (1.59 | ) |  | $ | 0.17 |  |  | $ | (1.42 | ) |
  (was, 2019-02-27, similarity 0.9391):
[0001327567-19-000008:note_history:12]
|  | Three Months Ended January 31, 2018 |  | Six Months Ended January 31, 2018 |
|  | As Previously Reported |  | Impact of Adoption |  | As Adjusted |  | As Previously Reported |  | Impact of Adoption |  | As Adjusted |
| Condensed Consolidated Statements of Operations |  |  |  |  |  |  |  |  |  |  |  |
| Product revenue | $ | 202.2 |  |  | $ | 2.6 |  |  | $ | 204.8 |  |  | $ | 388.7 |  |  | $ | 0.9 |  |  | $ | 389.6 |  |
| Subscription and support revenue | 340.2 |  |  | 0.6 |  |  | 340.8 |  |  | 659.2 |  |  | (1.4 | ) |  | 657.8 |  |
| Total revenue | 542.4 |  |  | 3.2 |  |  | 545.6 |  |  | 1,047.9 |  |  | (0.5 | ) |  | 1,047.4 |  |
| Total cost of revenue | 159.3 |  |  | 0.1 |  |  | 159.4 |  |  | 300.7 |  |  | — |  |  | 300.7 |  |
| Total operating expenses | 414.9 |  |  | (6.2 | ) |  | 408.7 |  |  | 833.3 |  |  | (10.6 | ) |  | 822.7 |  |
| Operating loss | (31.8 | ) |  | 9.3 |  |  | (22.5 | ) |  | (86.1 | ) |  | 10.1 |  |  | (76.0 | ) |
| Net loss | (34.9 | ) |  | 9.3 |  |  | (25.6 | ) |  | (98.9 | ) |  | 10.1 |  |  | (88.8 | ) |
| Net loss per share, basic and diluted | $ | (0.38 | ) |  | $ | 0.10 |  |  | $ | (0.28 | ) |  | $ | (1.09 | ) |  | $ | 0.11 |  |  | $ | (0.98 | ) |

- added (2019-05-30):
[0001327567-19-000016:note_history:13]
In February 2016, the FASB issued new authoritative guidance on lease accounting. Among its provisions, the standard requires lessees to recognize right-of-use assets and lease liabilities on the balance sheet for operating leases and also requires additional qualitative and quantitative disclosures about lease arrangements. The standard is effective for us in our first quarter of fiscal 2020 and will be applied on a modified retrospective basis, with the option to elect certain practical expedients. Early adoption is permitted; however, we plan to adopt the new standard in our first quarter of fiscal 2020. We expect to recognize right-of-use assets and operating lease liabilities on our consolidated balance sheets upon adoption for our operating leases disclosed in Note 10. Commitments and Contingencies, which will materially increase our total assets and liabilities. We do not expect the adoption of this standard to have a material impact to our consolidated statements of operations and consolidated statements of cash flows. We continue to evaluate the accounting, transition, and disclosure requirements of this standard, including its impact on our systems, accounting policies, and processes.

- removed (2019-05-30):
[0001327567-19-000008:note_history:14]
Certain prior period amounts have been adjusted due to our retrospective adoption of new accounting guidance related to revenue from contracts with customers and new accounting guidance related to the presentation of restricted cash and cash equivalents in the statement of cash flows. Refer to “Recently Adopted Accounting Pronouncements” below for more information.

- removed (2019-05-30):
[0001327567-19-000008:note_history:15]
In February 2016, the FASB issued new authoritative guidance on lease accounting. Among its provisions, the standard requires lessees to recognize right-of-use assets and lease liabilities on the balance sheet for operating leases and also requires additional qualitative and quantitative disclosures about lease arrangements. The standard is effective for us in our first quarter of fiscal 2020 and will be applied on a modified retrospective basis, with the option to elect certain practical expedients. Early adoption is permitted; however, we plan to adopt the new standard in our first quarter of fiscal 2020. Upon adoption, we will recognize right-of-use assets and operating lease liabilities on our condensed consolidated balance sheets, which will increase our total assets and total liabilities. We expect our operating leases, as disclosed in Note 10. Commitments and Contingencies, will be subject to the new standard. We continue to evaluate the accounting, transition, and disclosure requirements of this standard, including its impact on our systems, accounting policies, and processes.


## us-gaap:OrganizationConsolidationBasisOfPresentationBusinessDescriptionAndAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- added (2019-05-30):
[0001327567-19-000016:note_history:16]
Certain prior period amounts have been reclassified to conform to our current period presentation. In addition, certain prior period amounts have been adjusted due to our retrospective adoption of new accounting guidance related to revenue from contracts with customers and new accounting guidance related to the presentation of restricted cash and cash equivalents in the statement of cash flows. Refer to “Recently Adopted Accounting Pronouncements” below for more information.

- changed (2019-05-30):
[0001327567-19-000016:note_history:17]
There have been no material changes to our significant accounting policies as of and for the nine months ended April 30, 2019, as compared to the significant accounting policies described in our Annual Report on Form 10-K for the fiscal year ended July 31, 2018, except for the change in our accounting policies for revenue recognition and deferred contract costs due to our adoption of new accounting guidance related to revenue from contracts with customers. Refer to “Recently Adopted Accounting Pronouncements” below, Note 2. Revenue, and Note 8. Deferred Contract Costs for more information.
  (was, 2019-02-27, similarity 0.9596):
[0001327567-19-000008:note_history:17]
There have been no material changes to our significant accounting policies as of and for the six months ended January 31, 2019, as compared to the significant accounting policies described in our Annual Report on Form 10-K for the fiscal year ended July 31, 2018, except for the change in our accounting policies for revenue recognition and deferred contract costs due to our adoption of new accounting guidance related to revenue from contracts with customers. Refer to “Recently Adopted Accounting Pronouncements” below, Note 2. Revenue, and Note 8. Deferred Contract Costs for more information.

- removed (2019-05-30):
[0001327567-19-000008:note_history:18]
Certain prior period amounts have been adjusted due to our retrospective adoption of new accounting guidance related to revenue from contracts with customers and new accounting guidance related to the presentation of restricted cash and cash equivalents in the statement of cash flows. Refer to “Recently Adopted Accounting Pronouncements” below for more information.


## us-gaap:ConvertibleDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2019-05-30):
[0001327567-19-000016:note_history:19]
The following table sets forth the components of the Notes as of April 30, 2019 and July 31, 2018 (in millions):
  (was, 2019-02-27, similarity 0.9612):
[0001327567-19-000008:note_history:19]
The following table sets forth the components of the Notes as of January 31, 2019 and July 31, 2018 (in millions):

- changed (2019-05-30):
[0001327567-19-000016:note_history:20]
|  | April 30, 2019 |  | July 31, 2018 |
|  | 2019 Notes |  | 2023 Notes |  | Total |  | 2019 Notes |  | 2023 Notes |  | Total |
| Liability component: |  |  |  |  |  |  |  |  |  |  |  |
| Principal | $ | 159.4 |  |  | $ | 1,693.0 |  |  | $ | 1,852.4 |  |  | $ | 575.0 |  |  | $ | 1,693.0 |  |  | $ | 2,268.0 |  |
| Less: debt discount and debt issuance costs, net of amortization | 1.3 |  |  | 278.3 |  |  | 279.6 |  |  | 24.6 |  |  | 323.3 |  |  | 347.9 |  |
| Net carrying amount | $ | 158.1 |  |  | $ | 1,414.7 |  |  | $ | 1,572.8 |  |  | $ | 550.4 |  |  | $ | 1,369.7 |  |  | $ | 1,920.1 |  |
| Equity component (including amounts classified as temporary equity) | $ | 30.4 |  |  | $ | 315.0 |  |  | $ | 345.4 |  |  | $ | 109.8 |  |  | $ | 315.0 |  |  | $ | 424.8 |  |
  (was, 2019-02-27, similarity 0.9897):
[0001327567-19-000008:note_history:20]
|  | January 31, 2019 |  | July 31, 2018 |
|  | 2019 Notes |  | 2023 Notes |  | Total |  | 2019 Notes |  | 2023 Notes |  | Total |
| Liability component: |  |  |  |  |  |  |  |  |  |  |  |
| Principal | $ | 159.4 |  |  | $ | 1,693.0 |  |  | $ | 1,852.4 |  |  | $ | 575.0 |  |  | $ | 1,693.0 |  |  | $ | 2,268.0 |  |
| Less: debt discount and debt issuance costs, net of amortization | 3.1 |  |  | 293.5 |  |  | 296.6 |  |  | 24.6 |  |  | 323.3 |  |  | 347.9 |  |
| Net carrying amount | $ | 156.3 |  |  | $ | 1,399.5 |  |  | $ | 1,555.8 |  |  | $ | 550.4 |  |  | $ | 1,369.7 |  |  | $ | 1,920.1 |  |
| Equity component (including amounts classified as temporary equity) | $ | 30.4 |  |  | $ | 315.0 |  |  | $ | 345.4 |  |  | $ | 109.8 |  |  | $ | 315.0 |  |  | $ | 424.8 |  |


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2019-05-30):
[0001327567-19-000016:note_history:21]
The sale price condition was met for the 2019 Notes during the fiscal quarters ended July 31, 2018 and October 31, 2018. As a result, holders were able to convert their 2019 Notes at any time during the fiscal quarter ended October 31, 2018 and up to January 1, 2019. On or after January 1, 2019, holders may surrender their 2019 Notes for conversion at any time prior to maturity, in accordance with the terms described above. Such conversion requests will settle upon maturity of the 2019 Notes in the fourth quarter of fiscal 2019. Accordingly, the net carrying amount of the 2019 Notes was classified as a current liability and the portion of the equity component representing the conversion option was classified as temporary equity in our condensed consolidated balance sheets as of April 30, 2019. As of April 30, 2019, $159.4 million in aggregate principal amount of the 2019 Notes remained outstanding.
  (was, 2019-02-27, similarity 0.6787):
[0001327567-19-000008:note_history:21]
The sale price condition was met for the 2019 Notes during the fiscal quarters ended July 31, 2018 and October 31, 2018. As a result, holders were able to convert their 2019 Notes at any time during the fiscal quarter ended October 31, 2018 and up to January 1, 2019. On or after January 1, 2019, holders may surrender their 2019 Notes for conversion at any time prior to maturity, in accordance with the terms described above. Such conversion requests will settle upon maturity of the 2019 Notes. Accordingly, the net carrying amount of the 2019 Notes was classified as a current liability and the portion of the equity component representing the conversion option was classified as temporary equity in our condensed consolidated balance sheets as of January 31, 2019. As of January 31, 2019, $159.4 million in aggregate principal amount of the 2019 Notes remained outstanding.

- changed (2019-05-30):
[0001327567-19-000016:note_history:22]
There were no conversions of the 2019 Notes during the three months ended April 30, 2019. The following table presents details of conversions of the 2019 Notes during the nine months ended April 30, 2019 (in millions):
  (was, 2019-02-27, similarity 0.6323):
[0001327567-19-000008:note_history:22]
The following table presents details of conversions of the 2019 Notes during the reporting period (in millions):

- changed (2019-05-30):
[0001327567-19-000016:note_history:23]
|  | Nine Months Ended |
|  | April 30, 2019 |
| 2019 Notes principal converted and repaid in cash: |  |
| Allocated to liability component(1) | $ | 403.4 |  |
| Allocated to equity component(2) | 12.2 |  |
| Total principal converted and repaid in cash | $ | 415.6 |  |
| Loss on conversions of convertible senior notes(3) | $ | 2.6 |  |
| Shares of common stock issued in connection with conversion of convertible senior notes(4) | 1.7 |  |
  (was, 2019-02-27, similarity 0.8736):
[0001327567-19-000008:note_history:23]
|  | Three Months Ended |  | Six Months Ended |
|  | January 31, 2019 |  | January 31, 2019 |
| 2019 Notes principal converted and repaid in cash: |  |  |  |
| Allocated to liability component(1) | $ | 86.3 |  |  | $ | 403.4 |  |
| Allocated to equity component(2) | 2.0 |  |  | 12.2 |  |
| Total principal converted and repaid in cash | $ | 88.3 |  |  | $ | 415.6 |  |
| Loss on conversions of convertible senior notes(3) | $ | 0.4 |  |  | $ | 2.6 |  |
| Shares of common stock issued in connection with conversion of convertible senior notes(4) | 0.3 |  |  | 1.7 |  |

- changed (2019-05-30):
[0001327567-19-000016:note_history:24]
The sale price condition was not met for the 2023 Notes during the fiscal quarters ended April 30, 2019 or July 31, 2018. Since the 2023 Notes were not convertible, the net carrying amount of the 2023 Notes was classified as a long-term liability and the equity component was included in additional paid-in capital in our condensed consolidated balance sheets as of April 30, 2019 and July 31, 2018. As of April 30, 2019, all of the 2023 Notes remained outstanding.
  (was, 2019-02-27, similarity 0.9042):
[0001327567-19-000008:note_history:24]
The sale price condition was not met for the 2023 Notes during the fiscal quarters ended January 31, 2019 or July 31, 2018. Since the 2023 Notes were not convertible, the net carrying amount of the 2023 Notes was classified as a long-term liability and the equity component was included in additional paid-in capital in our condensed consolidated balance sheets as of January 31, 2019 and July 31, 2018. As of January 31, 2019, all of the 2023 Notes remained outstanding.

- changed (2019-05-30):
[0001327567-19-000016:note_history:25]
The following table sets forth the components of the Notes as of April 30, 2019 and July 31, 2018 (in millions):
  (was, 2019-02-27, similarity 0.9612):
[0001327567-19-000008:note_history:25]
The following table sets forth the components of the Notes as of January 31, 2019 and July 31, 2018 (in millions):

- changed (2019-05-30):
[0001327567-19-000016:note_history:26]
|  | April 30, 2019 |  | July 31, 2018 |
|  | 2019 Notes |  | 2023 Notes |  | Total |  | 2019 Notes |  | 2023 Notes |  | Total |
| Liability component: |  |  |  |  |  |  |  |  |  |  |  |
| Principal | $ | 159.4 |  |  | $ | 1,693.0 |  |  | $ | 1,852.4 |  |  | $ | 575.0 |  |  | $ | 1,693.0 |  |  | $ | 2,268.0 |  |
| Less: debt discount and debt issuance costs, net of amortization | 1.3 |  |  | 278.3 |  |  | 279.6 |  |  | 24.6 |  |  | 323.3 |  |  | 347.9 |  |
| Net carrying amount | $ | 158.1 |  |  | $ | 1,414.7 |  |  | $ | 1,572.8 |  |  | $ | 550.4 |  |  | $ | 1,369.7 |  |  | $ | 1,920.1 |  |
| Equity component (including amounts classified as temporary equity) | $ | 30.4 |  |  | $ | 315.0 |  |  | $ | 345.4 |  |  | $ | 109.8 |  |  | $ | 315.0 |  |  | $ | 424.8 |  |
  (was, 2019-02-27, similarity 0.9897):
[0001327567-19-000008:note_history:26]
|  | January 31, 2019 |  | July 31, 2018 |
|  | 2019 Notes |  | 2023 Notes |  | Total |  | 2019 Notes |  | 2023 Notes |  | Total |
| Liability component: |  |  |  |  |  |  |  |  |  |  |  |
| Principal | $ | 159.4 |  |  | $ | 1,693.0 |  |  | $ | 1,852.4 |  |  | $ | 575.0 |  |  | $ | 1,693.0 |  |  | $ | 2,268.0 |  |
| Less: debt discount and debt issuance costs, net of amortization | 3.1 |  |  | 293.5 |  |  | 296.6 |  |  | 24.6 |  |  | 323.3 |  |  | 347.9 |  |
| Net carrying amount | $ | 156.3 |  |  | $ | 1,399.5 |  |  | $ | 1,555.8 |  |  | $ | 550.4 |  |  | $ | 1,369.7 |  |  | $ | 1,920.1 |  |
| Equity component (including amounts classified as temporary equity) | $ | 30.4 |  |  | $ | 315.0 |  |  | $ | 345.4 |  |  | $ | 109.8 |  |  | $ | 315.0 |  |  | $ | 424.8 |  |

- changed (2019-05-30):
[0001327567-19-000016:note_history:27]
The total estimated fair value of the Notes was $2.3 billion and $2.7 billion at April 30, 2019 and July 31, 2018, respectively. The fair value was determined based on the closing trading price per $100 of the Notes as of the last day of trading for the period. We consider the fair value of the Notes at April 30, 2019 and July 31, 2018 to be a Level 2 measurement. The fair value of the Notes is primarily affected by the trading price of our common stock and market interest rates. As of April 30, 2019, the if-converted value of the 2019 Notes exceeded its principal amount by $191.1 million. Based on the closing price of our common stock on April 30, 2019, the if-converted value of the 2023 Notes was less than its principal amount.
  (was, 2019-02-27, similarity 0.9395):
[0001327567-19-000008:note_history:27]
The total estimated fair value of the Notes was $2.1 billion and $2.7 billion at January 31, 2019 and July 31, 2018, respectively. The fair value was determined based on the closing trading price per $100 of the Notes as of the last day of trading for the period. We consider the fair value of the Notes at January 31, 2019 and July 31, 2018 to be a Level 2 measurement. The fair value of the Notes is primarily affected by the trading price of our common stock and market interest rates. As of January 31, 2019, the if-converted value of the 2019 Notes exceeded its principal amount by $119.1 million. Based on the closing price of our common stock on January 31, 2019, the if-converted value of the 2023 Notes was less than its principal amount.

- changed (2019-05-30):
[0001327567-19-000016:note_history:28]
|  | Three Months Ended April 30, |  | Nine Months Ended April 30, |
|  | 2019 |  | 2018 |  | 2019 |  | 2018 |
|  | 2019 Notes |  | 2023 Notes |  | Total |  | 2019 Notes |  | 2023 Notes |  | Total |  | 2019 Notes |  | 2023 Notes |  | Total |  | 2019 Notes |  | 2023 Notes |  | Total |
| Contractual interest expense | $ | — |  |  | $ | 3.3 |  |  | $ | 3.3 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 9.6 |  |  | $ | 9.6 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Amortization of debt discount | 1.6 |  |  | 14.7 |  |  | 16.3 |  |  | 5.7 |  |  | — |  |  | 5.7 |  |  | 7.6 |  |  | 43.6 |  |  | 51.2 |  |  | 17.1 |  |  | — |  |  | 17.1 |  |
| Amortization of debt issuance costs | 0.3 |  |  | 0.5 |  |  | 0.8 |  |  | 0.8 |  |  | — |  |  | 0.8 |  |  | 1.0 |  |  | 1.4 |  |  | 2.4 |  |  | 2.1 |  |  | — |  |  | 2.1 |  |
| Total interest expense recognized | $ | 1.9 |  |  | $ | 18.5 |  |  | $ | 20.4 |  |  | $ | 6.5 |  |  | $ | — |  |  | $ | 6.5 |  |  | $ | 8.6 |  |  | $ | 54.6 |  |  | $ | 63.2 |  |  | $ | 19.2 |  |  | $ | — |  |  | $ | 19.2 |  |
| Effective interest rate of the liability component | 4.8 | % |  | 5.2 | % |  |  |  | 4.8 | % |  | — | % |  |  |  | 4.8 | % |  | 5.2 | % |  |  |  | 4.8 | % |  | — | % |  |  |
  (was, 2019-02-27, similarity 0.9774):
[0001327567-19-000008:note_history:28]
|  | Three Months Ended January 31, |  | Six Months Ended January 31, |
|  | 2019 |  | 2018 |  | 2019 |  | 2018 |
|  | 2019 Notes |  | 2023 Notes |  | Total |  | 2019 Notes |  | 2023 Notes |  | Total |  | 2019 Notes |  | 2023 Notes |  | Total |  | 2019 Notes |  | 2023 Notes |  | Total |
| Contractual interest expense | $ | — |  |  | $ | 3.1 |  |  | $ | 3.1 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 6.3 |  |  | $ | 6.3 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Amortization of debt discount | 2.0 |  |  | 14.5 |  |  | 16.5 |  |  | 5.8 |  |  | — |  |  | 5.8 |  |  | 6.0 |  |  | 28.9 |  |  | 34.9 |  |  | 11.4 |  |  | — |  |  | 11.4 |  |
| Amortization of debt issuance costs | 0.2 |  |  | 0.4 |  |  | 0.6 |  |  | 0.6 |  |  | — |  |  | 0.6 |  |  | 0.7 |  |  | 0.9 |  |  | 1.6 |  |  | 1.3 |  |  | — |  |  | 1.3 |  |
| Total interest expense recognized | $ | 2.2 |  |  | $ | 18.0 |  |  | $ | 20.2 |  |  | $ | 6.4 |  |  | $ | — |  |  | $ | 6.4 |  |  | $ | 6.7 |  |  | $ | 36.1 |  |  | $ | 42.8 |  |  | $ | 12.7 |  |  | $ | — |  |  | $ | 12.7 |  |
| Effective interest rate of the liability component | 4.8 | % |  | 5.2 | % |  |  |  | 4.8 | % |  | — | % |  |  |  | 4.8 | % |  | 5.2 | % |  |  |  | 4.8 | % |  | — | % |  |  |

- changed (2019-05-30):
[0001327567-19-000016:note_history:29]
As a result of the conversions of the 2019 Notes settled during the nine months ended April 30, 2019, we exercised the corresponding portion of our 2019 Note Hedges and received 1.7 million shares of common stock during the period.
  (was, 2019-02-27, similarity 0.7983):
[0001327567-19-000008:note_history:29]
As a result of the conversions of the 2019 Notes settled during the three and six months ended January 31, 2019, we exercised the corresponding portion of our 2019 Note Hedges and received 0.3 million and 1.7 million shares of common stock during the respective periods.

- changed (2019-05-30):
[0001327567-19-000016:note_history:30]
The borrowings under the Credit Facility bear interest, at our option, at a base rate plus a spread of 0.00% to 0.75%, or an adjusted LIBO rate plus a spread of 1.00% to 1.75%, in each case with such spread being determined based on our leverage ratio. We are obligated to pay an ongoing commitment fee on undrawn amounts at a rate of 0.125% to 0.250%, depending on our leverage ratio. As of April 30, 2019, there were no amounts outstanding and we were in compliance with all covenants under the Credit Agreement.
  (was, 2019-02-27, similarity 0.9877):
[0001327567-19-000008:note_history:30]
The borrowings under the Credit Facility bear interest, at our option, at a base rate plus a spread of 0.00% to 0.75%, or an adjusted LIBO rate plus a spread of 1.00% to 1.75%, in each case with such spread being determined based on our leverage ratio. We are obligated to pay an ongoing commitment fee on undrawn amounts at a rate of 0.125% to 0.250%, depending on our leverage ratio. As of January 31, 2019, there were no amounts outstanding and we were in compliance with all covenants under the Credit Agreement.


## us-gaap:DebtSecuritiesAvailableForSaleTableTextBlock (debt) — matched_by: title_similarity, score: 0.9731

- changed (2019-05-30):
[0001327567-19-000016:note_history:31]
The following tables summarize the amortized cost, unrealized gains and losses, and fair value of our available-for-sale securities as of April 30, 2019 and July 31, 2018 (in millions):
  (was, 2019-02-27, similarity 0.9773):
[0001327567-19-000008:note_history:31]
The following tables summarize the amortized cost, unrealized gains and losses, and fair value of our available-for-sale securities as of January 31, 2019 and July 31, 2018 (in millions):

- changed (2019-05-30):
[0001327567-19-000016:note_history:32]
|  | April 30, 2019 |
|  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Fair Value |
| Cash equivalents: |  |  |  |  |  |  |  |
| Commercial paper | $ | 27.0 |  |  | $ | — |  |  | $ | — |  |  | $ | 27.0 |  |
| Corporate debt securities | 15.0 |  |  | — |  |  | — |  |  | 15.0 |  |
| U.S. government and agency securities | 340.0 |  |  | — |  |  | — |  |  | 340.0 |  |
| Total available-for-sale cash equivalents | $ | 382.0 |  |  | $ | — |  |  | $ | — |  |  | $ | 382.0 |  |
| Investments: |  |  |  |  |  |  |  |
| Commercial paper | $ | 19.5 |  |  | $ | — |  |  | $ | — |  |  | $ | 19.5 |  |
| Corporate debt securities | 540.5 |  |  | 1.3 |  |  | (0.7 | ) |  | 541.1 |  |
| U.S. government and agency securities | 1,843.2 |  |  | 1.6 |  |  | (2.3 | ) |  | 1,842.5 |  |
| Total available-for-sale investments | $ | 2,403.2 |  |  | $ | 2.9 |  |  | $ | (3.0 | ) |  | $ | 2,403.1 |  |
  (was, 2019-02-27, similarity 0.7019):
[0001327567-19-000008:note_history:32]
|  | January 31, 2019 |
|  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Fair Value |
| Cash equivalents: |  |  |  |  |  |  |  |
| Commercial paper | $ | 39.4 |  |  | $ | — |  |  | $ | — |  |  | $ | 39.4 |  |
| U.S. government and agency securities | 279.4 |  |  | — |  |  | — |  |  | 279.4 |  |
| Total available-for-sale cash equivalents | $ | 318.8 |  |  | $ | — |  |  | $ | — |  |  | $ | 318.8 |  |
| Investments: |  |  |  |  |  |  |  |
| Commercial paper | $ | 50.2 |  |  | $ | — |  |  | $ | — |  |  | $ | 50.2 |  |
| Corporate debt securities | 495.9 |  |  | 0.9 |  |  | (1.4 | ) |  | 495.4 |  |
| U.S. government and agency securities | 1,968.0 |  |  | 1.1 |  |  | (3.9 | ) |  | 1,965.2 |  |
| Total available-for-sale investments | $ | 2,514.1 |  |  | $ | 2.0 |  |  | $ | (5.3 | ) |  | $ | 2,510.8 |  |


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2019-05-30):
[0001327567-19-000016:note_history:33]
The following tables summarize the amortized cost, unrealized gains and losses, and fair value of our available-for-sale securities as of April 30, 2019 and July 31, 2018 (in millions):
  (was, 2019-02-27, similarity 0.9773):
[0001327567-19-000008:note_history:33]
The following tables summarize the amortized cost, unrealized gains and losses, and fair value of our available-for-sale securities as of January 31, 2019 and July 31, 2018 (in millions):

- changed (2019-05-30):
[0001327567-19-000016:note_history:34]
|  | April 30, 2019 |
|  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Fair Value |
| Cash equivalents: |  |  |  |  |  |  |  |
| Commercial paper | $ | 27.0 |  |  | $ | — |  |  | $ | — |  |  | $ | 27.0 |  |
| Corporate debt securities | 15.0 |  |  | — |  |  | — |  |  | 15.0 |  |
| U.S. government and agency securities | 340.0 |  |  | — |  |  | — |  |  | 340.0 |  |
| Total available-for-sale cash equivalents | $ | 382.0 |  |  | $ | — |  |  | $ | — |  |  | $ | 382.0 |  |
| Investments: |  |  |  |  |  |  |  |
| Commercial paper | $ | 19.5 |  |  | $ | — |  |  | $ | — |  |  | $ | 19.5 |  |
| Corporate debt securities | 540.5 |  |  | 1.3 |  |  | (0.7 | ) |  | 541.1 |  |
| U.S. government and agency securities | 1,843.2 |  |  | 1.6 |  |  | (2.3 | ) |  | 1,842.5 |  |
| Total available-for-sale investments | $ | 2,403.2 |  |  | $ | 2.9 |  |  | $ | (3.0 | ) |  | $ | 2,403.1 |  |
  (was, 2019-02-27, similarity 0.7019):
[0001327567-19-000008:note_history:34]
|  | January 31, 2019 |
|  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Fair Value |
| Cash equivalents: |  |  |  |  |  |  |  |
| Commercial paper | $ | 39.4 |  |  | $ | — |  |  | $ | — |  |  | $ | 39.4 |  |
| U.S. government and agency securities | 279.4 |  |  | — |  |  | — |  |  | 279.4 |  |
| Total available-for-sale cash equivalents | $ | 318.8 |  |  | $ | — |  |  | $ | — |  |  | $ | 318.8 |  |
| Investments: |  |  |  |  |  |  |  |
| Commercial paper | $ | 50.2 |  |  | $ | — |  |  | $ | — |  |  | $ | 50.2 |  |
| Corporate debt securities | 495.9 |  |  | 0.9 |  |  | (1.4 | ) |  | 495.4 |  |
| U.S. government and agency securities | 1,968.0 |  |  | 1.1 |  |  | (3.9 | ) |  | 1,965.2 |  |
| Total available-for-sale investments | $ | 2,514.1 |  |  | $ | 2.0 |  |  | $ | (5.3 | ) |  | $ | 2,510.8 |  |

- changed (2019-05-30):
[0001327567-19-000016:note_history:35]
Unrealized losses related to these securities are due to interest rate fluctuations as opposed to credit quality. In addition, we do not intend to sell and it is not likely that we would be required to sell these securities before recovery of their amortized cost basis, which may be at maturity. As a result, there were no other-than-temporary impairments for these securities at April 30, 2019 and July 31, 2018.
  (was, 2019-02-27, similarity 0.9851):
[0001327567-19-000008:note_history:35]
Unrealized losses related to these securities are due to interest rate fluctuations as opposed to credit quality. In addition, we do not intend to sell and it is not likely that we would be required to sell these securities before recovery of their amortized cost basis, which may be at maturity. As a result, there were no other-than-temporary impairments for these securities at January 31, 2019 and July 31, 2018.

- changed (2019-05-30):
[0001327567-19-000016:note_history:36]
The following table summarizes the amortized cost and fair value of our available-for-sale securities as of April 30, 2019, by contractual years-to-maturity (in millions):
  (was, 2019-02-27, similarity 0.9759):
[0001327567-19-000008:note_history:36]
The following table summarizes the amortized cost and fair value of our available-for-sale securities as of January 31, 2019, by contractual years-to-maturity (in millions):

- added (2019-05-30):
[0001327567-19-000016:note_history:37]
Marketable equity securities consist of money market funds and are included in cash and cash equivalents in our condensed consolidated balance sheets. As of April 30, 2019 and July 31, 2018, the carrying value of our marketable equity securities were $155.0 million and $1.5 billion, respectively. There were no unrealized gains or losses recognized for these securities during the three and nine months ended April 30, 2019 and 2018.

- removed (2019-05-30):
[0001327567-19-000008:note_history:38]
Marketable equity securities consist of money market funds and are included in cash and cash equivalents in our condensed consolidated balance sheets. As of January 31, 2019 and July 31, 2018, the carrying value of our marketable equity securities were $430.6 million and $1.5 billion, respectively. During the three and six months ended January 31, 2019 and 2018, there were no unrealized gains or losses recognized for these securities.


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock (related_parties) — matched_by: no_prior_note, score: 0.0

- added (2019-05-30):
[0001327567-19-000016:note_history:39]
Related Party Transactions

- added (2019-05-30):
[0001327567-19-000016:note_history:40]
Certain members of our board of directors are affiliated with Greylock Partners, a venture capital firm. Entities affiliated with Greylock Partners owned a portion of the outstanding shares of Demisto immediately prior to completion of our acquisition of Demisto on March 28, 2019 and, as a result, received purchase consideration valued at $85.6 million during the three months ended April 30, 2019. Refer to Note 6. Acquisitions for more information on our acquisition of Demisto.


## us-gaap:RevenueFromContractWithCustomerPolicyTextBlock (revenue_recognition_policy) — matched_by: title_similarity, score: 1.0

- added (2019-05-30):
[0001327567-19-000016:note_history:41]
Deferred Revenue

- added (2019-05-30):
[0001327567-19-000016:note_history:42]
We record deferred revenue when cash payments are received or due in advance of our performance. Our payment terms typically require payment within 30 to 45 days of the date we issue an invoice. The current portion of deferred revenue represents the amounts that are expected to be recognized as revenue within one year of the condensed consolidated balance sheet date.


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2019-05-30):
[0001327567-19-000016:note_history:43]
We record deferred revenue when cash payments are received or due in advance of our performance. Our payment terms typically require payment within 30 to 45 days of the date we issue an invoice. The current portion of deferred revenue represents the amounts that are expected to be recognized as revenue within one year of the condensed consolidated balance sheet date. During the nine months ended April 30, 2019, we recognized approximately $955.0 million of revenue pertaining to amounts that were deferred as of July 31, 2018.
  (was, 2019-02-27, similarity 0.9541):
[0001327567-19-000008:note_history:43]
We record deferred revenue when cash payments are received or due in advance of our performance. Our payment terms typically require payment within 30 to 45 days of the date we issue an invoice. The current portion of deferred revenue represents the amounts that are expected to be recognized as revenue within one year of the condensed consolidated balance sheet date. During the six months ended January 31, 2019, we recognized approximately $695.0 million of revenue pertaining to amounts that were deferred as of July 31, 2018.

- changed (2019-05-30):
[0001327567-19-000016:note_history:44]
Revenue expected to be recognized from remaining performance obligations was $2.7 billion as of April 30, 2019, of which we expect to recognize approximately $1.5 billion over the next 12 months and the remainder thereafter.
  (was, 2019-02-27, similarity 0.972):
[0001327567-19-000008:note_history:44]
Revenue expected to be recognized from remaining performance obligations was $2.6 billion as of January 31, 2019, of which we expect to recognize approximately $1.4 billion over the next 12 months and the remainder thereafter.

- changed (2019-05-30):
[0001327567-19-000016:note_history:45]
|  | Three Months Ended April 30, |  | Nine Months Ended April 30, |
|  | 2019 |  | 2018 |  | 2019 |  | 2018 |
|  |  |  | (As Adjusted) |  |  |  | (As Adjusted) |
| Revenue: |  |  |  |  |  |  |  |
| Americas |  |  |  |  |  |  |  |
| United States | $ | 464.3 |  |  | $ | 358.0 |  |  | $ | 1,314.8 |  |  | $ | 1,030.0 |  |
| Other Americas | 33.5 |  |  | 29.7 |  |  | 108.2 |  |  | 80.3 |  |
| Total Americas | 497.8 |  |  | 387.7 |  |  | 1,423.0 |  |  | 1,110.3 |  |
| Europe, the Middle East, and Africa (“EMEA”) | 138.7 |  |  | 110.1 |  |  | 414.7 |  |  | 312.0 |  |
| Asia Pacific and Japan (“APAC”) | 90.1 |  |  | 69.9 |  |  | 256.1 |  |  | 192.8 |  |
| Total revenue | $ | 726.6 |  |  | $ | 567.7 |  |  | $ | 2,093.8 |  |  | $ | 1,615.1 |  |
  (was, 2019-02-27, similarity 0.9599):
[0001327567-19-000008:note_history:45]
|  | Three Months Ended January 31, |  | Six Months Ended January 31, |
|  | 2019 |  | 2018 |  | 2019 |  | 2018 |
|  |  |  | (As Adjusted) |  |  |  | (As Adjusted) |
| Revenue: |  |  |  |  |  |  |  |
| Americas |  |  |  |  |  |  |  |
| United States | $ | 434.6 |  |  | $ | 346.0 |  |  | $ | 850.5 |  |  | $ | 672.0 |  |
| Other Americas | 40.4 |  |  | 27.3 |  |  | 74.7 |  |  | 50.6 |  |
| Total Americas | 475.0 |  |  | 373.3 |  |  | 925.2 |  |  | 722.6 |  |
| Europe, the Middle East, and Africa (“EMEA”) | 148.3 |  |  | 107.2 |  |  | 276.0 |  |  | 201.9 |  |
| Asia Pacific and Japan (“APAC”) | 87.9 |  |  | 65.1 |  |  | 166.0 |  |  | 122.9 |  |
| Total revenue | $ | 711.2 |  |  | $ | 545.6 |  |  | $ | 1,367.2 |  |  | $ | 1,047.4 |  |

- added (2019-05-30):
[0001327567-19-000016:note_history:46]
|  | Three Months Ended April 30, |  | Nine Months Ended April 30, |
|  | 2019 |  | 2018 |  | 2019 |  | 2018 |
|  |  |  | (As Adjusted) |  |  |  | (As Adjusted) |
| Revenue: |  |  |  |  |  |  |  |
| Product | $ | 278.4 |  |  | $ | 218.1 |  |  | $ | 790.5 |  |  | $ | 607.7 |  |
| Subscription and support |  |  |  |  |  |  |  |
| Subscription | 258.8 |  |  | 192.0 |  |  | 739.8 |  |  | 544.3 |  |
| Support | 189.4 |  |  | 157.6 |  |  | 563.5 |  |  | 463.1 |  |
| Total subscription and support | 448.2 |  |  | 349.6 |  |  | 1,303.3 |  |  | 1,007.4 |  |
| Total revenue | $ | 726.6 |  |  | $ | 567.7 |  |  | $ | 2,093.8 |  |  | $ | 1,615.1 |  |

- changed (2019-05-30):
[0001327567-19-000016:note_history:47]
The following table presents details of our short-term and long-term deferred contract costs as of April 30, 2019 and July 31, 2018 (in millions):
  (was, 2019-02-27, similarity 0.9708):
[0001327567-19-000008:note_history:47]
The following table presents details of our short-term and long-term deferred contract costs as of January 31, 2019 and July 31, 2018 (in millions):

- changed (2019-05-30):
[0001327567-19-000016:note_history:48]
|  | April 30, 2019 |  | July 31, 2018 |
| Short-term deferred contract costs | $ | 125.8 |  |  | $ | 113.2 |  |
| Long-term deferred contract costs | 251.8 |  |  | 224.8 |  |
| Total deferred contract costs | $ | 377.6 |  |  | $ | 338.0 |  |
  (was, 2019-02-27, similarity 0.9798):
[0001327567-19-000008:note_history:48]
|  | January 31, 2019 |  | July 31, 2018 |
| Short-term deferred contract costs | $ | 117.6 |  |  | $ | 113.2 |  |
| Long-term deferred contract costs | 230.7 |  |  | 224.8 |  |
| Total deferred contract costs | $ | 348.3 |  |  | $ | 338.0 |  |

- added (2019-05-30):
[0001327567-19-000016:note_history:49]
We recognized amortization expense for our deferred contract costs of $57.2 million and $147.6 million during the three and nine months ended April 30, 2019, respectively, and $37.7 million and $101.9 million during the three and nine months ended April 30, 2018, respectively. We did not recognize any impairment losses on our deferred contract costs during the three and nine months ended April 30, 2019 or 2018.

- removed (2019-05-30):
[0001327567-19-000008:note_history:50]
|  | Three Months Ended January 31, |  | Six Months Ended January 31, |
|  | 2019 |  | 2018 |  | 2019 |  | 2018 |
|  |  |  | (As Adjusted) |  |  |  | (As Adjusted) |
| Revenue: |  |  |  |  |  |  |  |
| Product | $ | 271.6 |  |  | $ | 204.8 |  |  | $ | 512.1 |  |  | $ | 389.6 |  |
| Subscription and support |  |  |  |  |  |  |  |
| Subscription | 249.7 |  |  | 183.3 |  |  | 481.0 |  |  | 352.3 |  |
| Support | 189.9 |  |  | 157.5 |  |  | 374.1 |  |  | 305.5 |  |
| Total subscription and support | 439.6 |  |  | 340.8 |  |  | 855.1 |  |  | 657.8 |  |
| Total revenue | $ | 711.2 |  |  | $ | 545.6 |  |  | $ | 1,367.2 |  |  | $ | 1,047.4 |  |

- removed (2019-05-30):
[0001327567-19-000008:note_history:51]
We recognized amortization expense for our deferred contract costs of $41.9 million and $83.0 million during the three and six months ended January 31, 2019, respectively, and $29.2 million and $57.3 million during the three and six months ended January 31, 2018, respectively. We did not recognize any impairment losses on our deferred contract costs during the three and six months ended January 31, 2019 or 2018.


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: tag_name, score: 1.0

- added (2019-05-30):
[0001327567-19-000016:note_history:52]
In May 2019, we entered into a definitive agreement to acquire Twistlock Ltd. (“Twistlock”), a privately-held container security company, for total consideration of approximately $410.0 million in cash, subject to adjustment. In May 2019, we also entered into a definitive agreement to acquire PureSec Ltd. (“PureSec”), a privately-held serverless security company, for total consideration of approximately $47.0 million in cash, subject to adjustment. We expect the acquisitions will extend our cloud security strategy with the additions of Twistlock and PureSec to our Prisma cloud security offerings. The acquisitions are expected to close during our fourth quarter of fiscal 2019.

- removed (2019-05-30):
[0001327567-19-000008:note_history:53]
In February 2019, we entered into a definitive agreement to acquire Demisto, Inc. (“Demisto”), a privately-held security company, in exchange for total consideration of approximately $560.0 million in cash and common stock, subject to adjustments. The number of shares of common stock to be issued in connection with the transaction will be finalized upon closing. The acquisition expands the functionality of our platform with the addition of Demisto’s security, orchestration, automation, and response product. The acquisition is expected to close during our third quarter of fiscal 2019.
