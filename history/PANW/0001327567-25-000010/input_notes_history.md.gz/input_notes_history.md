# PANW note change history — 0001327567-24-000040 → 0001327567-25-000010


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2025-02-14):
[0001327567-25-000010:note_history:1]
We have entered into various non-cancelable agreements with cloud service providers, under which we are committed to minimum or fixed purchases of certain cloud services. In addition, in order to reduce manufacturing lead times and plan for adequate supply, we have entered into agreements with manufacturing partners and component suppliers to procure inventory based on our demand forecasts. The following table presents details of the aggregate future non-cancelable purchase commitments under these agreements as of January 31, 2025 (in millions):
  (was, 2024-11-21, similarity 0.9872):
[0001327567-24-000040:note_history:1]
We have entered into various non-cancelable agreements with cloud service providers, under which we are committed to minimum or fixed purchases of certain cloud services. In addition, in order to reduce manufacturing lead times and plan for adequate supply, we have entered into agreements with manufacturing partners and component suppliers to procure inventory based on our demand forecasts. The following table presents details of the aggregate future non-cancelable purchase commitments under these agreements as of October 31, 2024 (in millions):

- changed (2025-02-14):
[0001327567-25-000010:note_history:2]
As of July 31, 2024, we accrued $184.4 million for the verdict amount and estimated interest. As of January 31, 2025, we accrued $142.8 million based on the judgment and estimated interest, which is recorded in other long-term liabilities on our condensed consolidated balance sheets. The corresponding amount was a charge of $1.4 million for the three months ended January 31, 2025, and a release of $41.6 million for the six months ended January 31, 2025, which is included in general and administrative expense on our condensed consolidated statements of operations.
  (was, 2024-11-21, similarity 0.762):
[0001327567-24-000040:note_history:2]
As of July 31, 2024, we accrued $184.4 million for the verdict amount and estimated interest. As of October 31, 2024, we reassessed our loss accrual and reduced the amount to $141.4 million based on the judgment and estimated interest, which is recorded in other long-term liabilities on our condensed consolidated balance sheets. The corresponding amount released was $43.0 million for the three months ended October 31, 2024, which is included in general and administrative expense on our condensed consolidated statements of operations.

- changed (2025-02-14):
[0001327567-25-000010:note_history:3]
Finjan, Inc. v. Palo Alto Networks
On November 4, 2014, Finjan, Inc., filed a lawsuit against us in the United States District Court for the Northern District of California. The lawsuit alleges that our products infringe multiple Finjan patents. The complaint requests injunctive relief, monetary damages, and attorneys fees. A trial date is set for June 9, 2025. We are unable, at this time, to reasonably estimate a possible loss or potential range of loss, if any.
  (was, 2024-11-21, similarity 0.9602):
[0001327567-24-000040:note_history:3]
On November 4, 2014, Finjan, Inc., filed a lawsuit against us in the United States District Court for the Northern District of California. The lawsuit alleges that our products infringe multiple Finjan patents. The complaint requests injunctive relief, monetary damages, and attorneys fees. A trial date is set for June 9, 2025. We are unable, at this time, to reasonably estimate a possible loss or potential range of loss, if any.

- removed (2025-02-14):
[0001327567-24-000040:note_history:4]
Finjan, Inc. v. Palo Alto Networks


## us-gaap:BusinessDescriptionAndAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- added (2025-02-14):
[0001327567-25-000010:note_history:5]
Stock Split

- added (2025-02-14):
[0001327567-25-000010:note_history:6]
On December 12, 2024, we effected a two-for-one stock split of our outstanding shares of common stock through an amendment to our restated certificate of incorporation (“Stock Split”), which also effected a proportionate increase in the number of authorized shares of our common stock from 1.0 billion to 2.0 billion. The par value per share of our common stock remains unchanged at $0.0001 per share after the Stock Split. All references made to share or per share amounts related to our common stock have been retroactively adjusted on the accompanying condensed consolidated financial statements and applicable disclosures to reflect the effects of the Stock Split.

- changed (2025-02-14):
[0001327567-25-000010:note_history:7]
There have been no material changes to our significant accounting policies as of and for the six months ended January 31, 2025, as compared to the significant accounting policies described in our Annual Report on Form 10-K for the fiscal year ended July 31, 2024, except for the update to the disclosure of our accounting policies as described below resulting from our acquisition of certain QRadar assets from International Business Machines Corporation (“IBM”). Refer to Note 7. Acquisition for additional information.
  (was, 2024-11-21, similarity 0.9442):
[0001327567-24-000040:note_history:7]
There have been no material changes to our significant accounting policies as of and for the three months ended October 31, 2024, as compared to the significant accounting policies described in our Annual Report on Form 10-K for the fiscal year ended July 31, 2024, except for the update to the disclosure of our accounting policies as described below resulting from our recent acquisition of certain QRadar assets from International Business Machines Corporation (“IBM”). Refer to Note 7. Acquisition for additional information.

- added (2025-02-14):
[0001327567-25-000010:note_history:8]
Expense Disaggregation Disclosures

- added (2025-02-14):
[0001327567-25-000010:note_history:9]
In November 2024, the FASB issued authoritative guidance that expands annual and interim disclosure of specified information about certain costs and expenses in the notes to financial statements. The standard is effective for our annual period in fiscal 2028 and interim periods beginning in the first quarter of fiscal 2029, and could be applied either prospectively or retrospectively. Early adoption is permitted. We are currently evaluating the impact of this standard on our disclosures in the consolidated financial statements.


## us-gaap:ConvertibleDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2025-02-14):
[0001327567-25-000010:note_history:10]
|  | January 31, 2025 |  | July 31, 2024 |
| Principal | $ | 534.2 |  |  | $ | 965.6 |  |
| Less: debt issuance costs, net of amortization | (0.4) |  |  | (1.7) |  |
| Net carrying amount | $ | 533.8 |  |  | $ | 963.9 |  |
  (was, 2024-11-21, similarity 0.6311):
[0001327567-24-000040:note_history:10]
|  |  |  | October 31, 2024 | July 31, 2024 |
| Principal |  |  | $ | 646.6 |  |  |  |  |  |  | $ | 965.6 |  |  |  |
| Less: debt issuance costs, net of amortization |  |  | (0.8) |  |  |  |  |  |  | (1.7) |  |  |  |
| Net carrying amount |  |  | $ | 645.8 |  |  |  |  |  |  | $ | 963.9 |  |  |  |


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2025-02-14):
[0001327567-25-000010:note_history:11]
Holders of the 2025 Notes were able to early convert their 2025 Notes during the fiscal quarter ended January 31, 2025 as the sales price condition had been met during the fiscal quarter ended October 31, 2024. During the three and six months ended January 31, 2025, holders of the 2025 Notes converted $112.4 million and $431.4 million, respectively, in aggregate principal amount of the 2025 Notes, which we repaid in cash. We also issued 1.7 million and 6.2 million shares of our common stock to the holders of the 2025 Notes during the three and six months ended January 31, 2025, respectively, for the conversion value in excess of the principal amount. During the three and six months ended January 31, 2024, holders of the 2025 Notes converted $126.3 million and $172.3 million, respectively, in aggregate principal amount of the 2025 Notes, which we repaid in cash. We also issued 1.7 million and 2.2 million shares of our common stock to the holders of the 2025 Notes during the three and six months ended January 31, 2024, respectively, for the conversion value in excess of the principal amount. These shares were fully offset by shares we received from the corresponding exercise of the note hedges. Refer to Note 16. Subsequent Events for additional information regarding conversion of the 2025 Notes after January 31, 2025 through the filing date of this Quarterly Report on Form 10-Q.
  (was, 2024-11-21, similarity 0.6554):
[0001327567-24-000040:note_history:11]
Holders of the 2025 Notes were able to early convert their 2025 Notes during the fiscal quarter ended October 31, 2024 as the sales price condition had been met during the fiscal quarter ended July 31, 2024. During the three months ended October 31, 2024 and 2023, holders of the 2025 Notes converted $319.0 million and $46.0 million, respectively, in aggregate principal amount of the 2025 Notes, which we repaid in cash. We also issued 2.3 million and 0.3 million shares of our common stock to the holders of the 2025 Notes during the three months ended October 31, 2024 and 2023, respectively, for the conversion value in excess of the principal amount. These shares were fully offset by shares we received from the corresponding exercise of the note hedges. Refer to Note 16. Subsequent Events for additional information regarding conversion of the 2025 Notes after October 31, 2024 through the filing date of this Quarterly Report on Form 10-Q.

- added (2025-02-14):
[0001327567-25-000010:note_history:12]
The sale price condition for the 2025 Notes was met during the fiscal quarter ended January 31, 2025 and, as a result, holders may convert their 2025 Notes during the fiscal quarter ending April 30, 2025 at any time prior to the close of business on the business day immediately preceding March 1, 2025 for settlement prior to the maturity date. The net carrying amount of the 2025 Notes was classified as a current liability on our condensed consolidated balance sheet as of January 31, 2025.

- changed (2025-02-14):
[0001327567-25-000010:note_history:13]
|  | January 31, 2025 |  | July 31, 2024 |
| Principal | $ | 534.2 |  |  | $ | 965.6 |  |
| Less: debt issuance costs, net of amortization | (0.4) |  |  | (1.7) |  |
| Net carrying amount | $ | 533.8 |  |  | $ | 963.9 |  |
  (was, 2024-11-21, similarity 0.6311):
[0001327567-24-000040:note_history:13]
|  |  |  | October 31, 2024 | July 31, 2024 |
| Principal |  |  | $ | 646.6 |  |  |  |  |  |  | $ | 965.6 |  |  |  |
| Less: debt issuance costs, net of amortization |  |  | (0.8) |  |  |  |  |  |  | (1.7) |  |  |  |
| Net carrying amount |  |  | $ | 645.8 |  |  |  |  |  |  | $ | 963.9 |  |  |  |

- added (2025-02-14):
[0001327567-25-000010:note_history:14]
The total estimated fair value of the 2025 Notes was $2.0 billion as of January 31, 2025 and $3.2 billion as of July 31, 2024. The fair value was determined based on the closing trading price per $100 of the 2025 Notes as of the last day of trading for the period. We consider the fair value of the 2025 Notes as of January 31, 2025 and July 31, 2024 to be a Level 2 measurement. The fair value of the 2025 Notes is primarily affected by the trading price of our common stock and market interest rates.

- added (2025-02-14):
[0001327567-25-000010:note_history:15]
|  | Three Months Ended January 31, |  | Six Months Ended January 31, |
|  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Contractual interest expense | $ | 0.6 |  |  | $ | 1.7 |  |  | $ | 1.3 |  |  | $ | 3.6 |  |
| Amortization of debt issuance costs | 0.3 |  |  | 1.1 |  |  | 0.8 |  |  | 2.1 |  |
| Total interest expense | $ | 0.9 |  |  | $ | 2.8 |  |  | $ | 2.1 |  |  | $ | 5.7 |  |
| Effective interest rate | 0.6 | % |  | 0.6 | % |  | 0.6 | % |  | 0.6 | % |

- added (2025-02-14):
[0001327567-25-000010:note_history:16]
As a result of the conversions of the 2025 Notes settled during the three and six months ended January 31, 2025, we exercised the corresponding portion of our 2025 Note Hedges and received 1.7 million and 6.2 million shares of our common stock during the respective periods. As a result of the conversions of the 2025 Notes settled during the three and six months ended January 31, 2024, we exercised the corresponding portion of our 2025 Note Hedges and received 1.7 million and 2.2 million shares of our common stock during the respective periods.

- added (2025-02-14):
[0001327567-25-000010:note_history:17]
During the six months ended January 31, 2024, we net settled all of the 2023 Warrants with 18.0 million shares of our common stock with a fair value of $2.4 billion, of which 11.9 million shares of our common stock with a fair value of $1.7 billion were net settled during the three months ended January 31, 2024. The number of net shares issued was determined based on the number of 2023 Warrants exercised multiplied by the difference between the strike price of the 2023 Warrants and their daily volume-weighted-average stock price.

- changed (2025-02-14):
[0001327567-25-000010:note_history:18]
As of January 31, 2025, there were no amounts outstanding and we were in compliance with all covenants under the Credit Agreement.
  (was, 2024-11-21, similarity 0.9516):
[0001327567-24-000040:note_history:18]
As of October 31, 2024, there were no amounts outstanding and we were in compliance with all covenants under the Credit Agreement.

- removed (2025-02-14):
[0001327567-24-000040:note_history:19]
The sale price condition for the 2025 Notes was met during the fiscal quarter ended October 31, 2024 and as a result, holders may convert their 2025 Notes during the fiscal quarter ending January 31, 2025. The net carrying amount of the 2025 Notes was classified as a current liability on our condensed consolidated balance sheet as of October 31, 2024.

- removed (2025-02-14):
[0001327567-24-000040:note_history:20]
The total estimated fair value of the 2025 Notes was $2.3 billion as of October 31, 2024 and $3.2 billion as of July 31, 2024. The fair value was determined based on the closing trading price per $100 of the 2025 Notes as of the last day of trading for the period. We consider the fair value of the 2025 Notes as of October 31, 2024 and July 31, 2024 to be a Level 2 measurement. The fair value of the 2025 Notes is primarily affected by the trading price of our common stock and market interest rates.

- removed (2025-02-14):
[0001327567-24-000040:note_history:21]
|  |  |  |  |  | Three Months Ended October 31, |
|  |  |  |  |  |  |  | 2024 |  |  |  | 2023 |
| Contractual interest expense |  |  |  |  |  |  |  |  |  |  |  |  |  |  | $ | 0.7 |  |  |  |  |  |  | $ | 1.9 |  |  |  |
| Amortization of debt issuance costs |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 0.5 |  |  |  |  |  |  | 1.0 |  |  |  |
| Total interest expense |  |  |  |  |  |  |  |  |  |  |  |  |  |  | $ | 1.2 |  |  |  |  |  |  | $ | 2.9 |  |  |  |
| Effective interest rate |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 0.6 | % |  |  |  |  |  | 0.6 | % |  |  |

- removed (2025-02-14):
[0001327567-24-000040:note_history:22]
As a result of the conversions of the 2025 Notes settled during the three months ended October 31, 2024 and 2023, we exercised the corresponding portion of our 2025 Note Hedges and received 2.3 million and 0.3 million shares of our common stock during the respective periods.

- removed (2025-02-14):
[0001327567-24-000040:note_history:23]
During the three months ended October 31, 2023, we net settled a portion of the 2023 Warrants with 3.1 million shares of our common stock with a fair value of $763.5 million. The number of net shares issued was determined based on the number of 2023 Warrants exercised multiplied by the difference between the strike price of the 2023 Warrants and their daily volume-weighted-average stock price.


## us-gaap:DebtSecuritiesAvailableForSaleTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2025-02-14):
[0001327567-25-000010:note_history:24]
The following tables summarize the amortized cost, unrealized gains and losses, and fair value of our available-for-sale debt securities as of January 31, 2025 and July 31, 2024 (in millions):
  (was, 2024-11-21, similarity 0.967):
[0001327567-24-000040:note_history:24]
The following tables summarize the amortized cost, unrealized gains and losses, and fair value of our available-for-sale debt securities as of October 31, 2024 and July 31, 2024 (in millions):

- changed (2025-02-14):
[0001327567-25-000010:note_history:25]
|  | January 31, 2025 |
|  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Fair Value |
| Cash equivalents: |  |  |  |  |  |  |  |
| Commercial paper | $ | 277.7 |  |  | $ | 0.1 |  |  | $ | — |  |  | $ | 277.8 |  |
| Corporate debt securities | 4.3 |  |  | — |  |  | — |  |  | 4.3 |  |
| U.S. government and agency securities | 18.0 |  |  | — |  |  | — |  |  | 18.0 |  |
| Total available-for-sale cash equivalents | $ | 300.0 |  |  | $ | 0.1 |  |  | $ | — |  |  | $ | 300.1 |  |
| Investments: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 1.0 |  |  | $ | — |  |  | $ | — |  |  | $ | 1.0 |  |
| Commercial paper | 34.6 |  |  | — |  |  | — |  |  | 34.6 |  |
| Corporate debt securities | 4,401.7 |  |  | 20.3 |  |  | (8.7) |  |  | 4,413.3 |  |
| U.S. government and agency securities | 99.1 |  |  | — |  |  | (0.1) |  |  | 99.0 |  |
| Non-U.S. government and agency securities | 28.8 |  |  | 0.3 |  |  | — |  |  | 29.1 |  |
| Asset-backed securities | 983.1 |  |  | 6.8 |  |  | (0.5) |  |  | 989.4 |  |
| Total available-for-sale investments | $ | 5,548.3 |  |  | $ | 27.4 |  |  | $ | (9.3) |  |  | $ | 5,566.4 |  |
  (was, 2024-11-21, similarity 0.9883):
[0001327567-24-000040:note_history:25]
|  | October 31, 2024 |
|  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Fair Value |
| Cash equivalents: |  |  |  |  |  |  |  |
| Commercial paper | $ | 228.7 |  |  | $ | — |  |  | $ | — |  |  | $ | 228.7 |  |
| Corporate debt securities | 34.2 |  |  | — |  |  | — |  |  | 34.2 |  |
| U.S. government and agency securities | 74.8 |  |  | — |  |  | — |  |  | 74.8 |  |
| Total available-for-sale cash equivalents | $ | 337.7 |  |  | $ | — |  |  | $ | — |  |  | $ | 337.7 |  |
| Investments: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 15.7 |  |  | $ | — |  |  | $ | — |  |  | $ | 15.7 |  |
| Commercial paper | 36.1 |  |  | — |  |  | — |  |  | 36.1 |  |
| Corporate debt securities | 4,115.2 |  |  | 25.3 |  |  | (7.8) |  |  | 4,132.7 |  |
| U.S. government and agency securities | 21.9 |  |  | — |  |  | — |  |  | 21.9 |  |
| Non-U.S. government and agency securities | 38.6 |  |  | 0.5 |  |  | — |  |  | 39.1 |  |
| Asset-backed securities | 976.1 |  |  | 7.1 |  |  | (0.8) |  |  | 982.4 |  |
| Total available-for-sale investments | $ | 5,203.6 |  |  | $ | 32.9 |  |  | $ | (8.6) |  |  | $ | 5,227.9 |  |


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2025-02-14):
[0001327567-25-000010:note_history:26]
The following tables summarize the amortized cost, unrealized gains and losses, and fair value of our available-for-sale debt securities as of January 31, 2025 and July 31, 2024 (in millions):
  (was, 2024-11-21, similarity 0.967):
[0001327567-24-000040:note_history:26]
The following tables summarize the amortized cost, unrealized gains and losses, and fair value of our available-for-sale debt securities as of October 31, 2024 and July 31, 2024 (in millions):

- changed (2025-02-14):
[0001327567-25-000010:note_history:27]
|  | January 31, 2025 |
|  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Fair Value |
| Cash equivalents: |  |  |  |  |  |  |  |
| Commercial paper | $ | 277.7 |  |  | $ | 0.1 |  |  | $ | — |  |  | $ | 277.8 |  |
| Corporate debt securities | 4.3 |  |  | — |  |  | — |  |  | 4.3 |  |
| U.S. government and agency securities | 18.0 |  |  | — |  |  | — |  |  | 18.0 |  |
| Total available-for-sale cash equivalents | $ | 300.0 |  |  | $ | 0.1 |  |  | $ | — |  |  | $ | 300.1 |  |
| Investments: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 1.0 |  |  | $ | — |  |  | $ | — |  |  | $ | 1.0 |  |
| Commercial paper | 34.6 |  |  | — |  |  | — |  |  | 34.6 |  |
| Corporate debt securities | 4,401.7 |  |  | 20.3 |  |  | (8.7) |  |  | 4,413.3 |  |
| U.S. government and agency securities | 99.1 |  |  | — |  |  | (0.1) |  |  | 99.0 |  |
| Non-U.S. government and agency securities | 28.8 |  |  | 0.3 |  |  | — |  |  | 29.1 |  |
| Asset-backed securities | 983.1 |  |  | 6.8 |  |  | (0.5) |  |  | 989.4 |  |
| Total available-for-sale investments | $ | 5,548.3 |  |  | $ | 27.4 |  |  | $ | (9.3) |  |  | $ | 5,566.4 |  |
  (was, 2024-11-21, similarity 0.9883):
[0001327567-24-000040:note_history:27]
|  | October 31, 2024 |
|  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Fair Value |
| Cash equivalents: |  |  |  |  |  |  |  |
| Commercial paper | $ | 228.7 |  |  | $ | — |  |  | $ | — |  |  | $ | 228.7 |  |
| Corporate debt securities | 34.2 |  |  | — |  |  | — |  |  | 34.2 |  |
| U.S. government and agency securities | 74.8 |  |  | — |  |  | — |  |  | 74.8 |  |
| Total available-for-sale cash equivalents | $ | 337.7 |  |  | $ | — |  |  | $ | — |  |  | $ | 337.7 |  |
| Investments: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 15.7 |  |  | $ | — |  |  | $ | — |  |  | $ | 15.7 |  |
| Commercial paper | 36.1 |  |  | — |  |  | — |  |  | 36.1 |  |
| Corporate debt securities | 4,115.2 |  |  | 25.3 |  |  | (7.8) |  |  | 4,132.7 |  |
| U.S. government and agency securities | 21.9 |  |  | — |  |  | — |  |  | 21.9 |  |
| Non-U.S. government and agency securities | 38.6 |  |  | 0.5 |  |  | — |  |  | 39.1 |  |
| Asset-backed securities | 976.1 |  |  | 7.1 |  |  | (0.8) |  |  | 982.4 |  |
| Total available-for-sale investments | $ | 5,203.6 |  |  | $ | 32.9 |  |  | $ | (8.6) |  |  | $ | 5,227.9 |  |

- added (2025-02-14):
[0001327567-25-000010:note_history:28]
As of January 31, 2025, the gross unrealized losses that have been in a continuous unrealized loss position for less than 12 months were $8.9 million, which were related to $1.5 billion of available-for-sale debt securities, and the gross unrealized losses that have been in a continuous unrealized loss position for more than 12 months were $0.4 million, which were related to $215.4 million of available-for-sale debt securities. As of July 31, 2024 the gross unrealized losses that have been in a continuous unrealized loss position for less than 12 months were $1.5 million, which were related to $949.4 million of available-for-sale debt securities, and the gross unrealized losses that have been in a continuous unrealized loss position for more than 12 months were $6.0 million, which were related to $915.3 million of available-for-sale debt securities.

- changed (2025-02-14):
[0001327567-25-000010:note_history:29]
Unrealized losses related to our available-for-sale debt securities are primarily due to interest rate fluctuations as opposed to credit quality. We do not intend to sell any of the securities in an unrealized loss position and it is not likely that we would be required to sell these securities before recovery of their amortized cost basis, which may be at maturity. We did not recognize any credit losses related to our available-for-sale debt securities during the three and six months ended January 31, 2025 and 2024.
  (was, 2024-11-21, similarity 0.9784):
[0001327567-24-000040:note_history:29]
Unrealized losses related to our available-for-sale debt securities are primarily due to interest rate fluctuations as opposed to credit quality. We do not intend to sell any of the securities in an unrealized loss position and it is not likely that we would be required to sell these securities before recovery of their amortized cost basis, which may be at maturity. We did not recognize any credit losses related to our available-for-sale debt securities during the three months ended October 31, 2024 and 2023.

- changed (2025-02-14):
[0001327567-25-000010:note_history:30]
The following table summarizes the amortized cost and fair value of our available-for-sale debt securities as of January 31, 2025, by contractual years-to-maturity (in millions):
  (was, 2024-11-21, similarity 0.9651):
[0001327567-24-000040:note_history:30]
The following table summarizes the amortized cost and fair value of our available-for-sale debt securities as of October 31, 2024, by contractual years-to-maturity (in millions):

- changed (2025-02-14):
[0001327567-25-000010:note_history:31]
Marketable equity securities consist of money market funds and are included in cash and cash equivalents on our condensed consolidated balance sheets. As of January 31, 2025 and July 31, 2024, the carrying values of our marketable equity securities were $1.3 billion and $494.0 million, respectively. There were no unrealized gains or losses recognized for these securities during the three and six months ended January 31, 2025 and 2024.
  (was, 2024-11-21, similarity 0.8775):
[0001327567-24-000040:note_history:31]
Marketable equity securities consist of money market funds and are included in cash and cash equivalents on our condensed consolidated balance sheets. As of October 31, 2024 and July 31, 2024, the carrying values of our marketable equity securities were $1.1 billion and $494.0 million, respectively. There were no unrealized gains or losses recognized for these securities during the three months ended October 31, 2024 and 2023.

- removed (2025-02-14):
[0001327567-24-000040:note_history:32]
As of October 31, 2024, the gross unrealized losses that have been in a continuous unrealized loss position for less than 12 months were $7.3 million, which were related to $1.2 billion of available-for-sale debt securities, and the gross unrealized losses that have been in a continuous unrealized loss position for more than 12 months were $1.3 million, which were related to $372.5 million of available-for-sale debt securities. As of July 31, 2024 the gross unrealized losses that have been in a continuous unrealized loss position for less than 12 months were $1.5 million, which were related to $949.4 million of available-for-sale debt securities, and the gross unrealized losses that have been in a continuous unrealized loss position for more than 12 months were $6.0 million, which were related to $915.3 million of available-for-sale debt securities.


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- added (2025-02-14):
[0001327567-25-000010:note_history:33]
|  | Three Months Ended January 31, |  | Six Months Ended January 31, |
|  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Revenue: |  |  |  |  |  |  |  |
| Americas |  |  |  |  |  |  |  |
| United States | $ | 1,400.5 |  |  | $ | 1,248.2 |  |  | $ | 2,744.6 |  |  | $ | 2,452.5 |  |
| Other Americas | 101.9 |  |  | 86.0 |  |  | 199.9 |  |  | 168.3 |  |
| Total Americas | 1,502.4 |  |  | 1,334.2 |  |  | 2,944.5 |  |  | 2,620.8 |  |
| Europe, the Middle East, and Africa (“EMEA”) | 480.0 |  |  | 406.8 |  |  | 921.4 |  |  | 771.7 |  |
| Asia Pacific and Japan (“APAC”) | 275.0 |  |  | 234.1 |  |  | 530.3 |  |  | 460.7 |  |
| Total revenue | $ | 2,257.4 |  |  | $ | 1,975.1 |  |  | $ | 4,396.2 |  |  | $ | 3,853.2 |  |

- added (2025-02-14):
[0001327567-25-000010:note_history:34]
|  | Three Months Ended January 31, |  | Six Months Ended January 31, |
|  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Revenue: |  |  |  |  |  |  |  |
| Product | $ | 421.5 |  |  | $ | 390.7 |  |  | $ | 775.3 |  |  | $ | 731.8 |  |
| Subscription and support |  |  |  |  |  |  |  |
| Subscription | 1,233.2 |  |  | 1,027.1 |  |  | 2,425.0 |  |  | 2,015.4 |  |
| Support | 602.7 |  |  | 557.3 |  |  | 1,195.9 |  |  | 1,106.0 |  |
| Total subscription and support | 1,835.9 |  |  | 1,584.4 |  |  | 3,620.9 |  |  | 3,121.4 |  |
| Total revenue | $ | 2,257.4 |  |  | $ | 1,975.1 |  |  | $ | 4,396.2 |  |  | $ | 3,853.2 |  |

- changed (2025-02-14):
[0001327567-25-000010:note_history:35]
During the six months ended January 31, 2025 and 2024, we recognized approximately $3.1 billion and $2.7 billion of revenue pertaining to amounts that were deferred as of July 31, 2024 and 2023, respectively.
  (was, 2024-11-21, similarity 0.9465):
[0001327567-24-000040:note_history:35]
During the three months ended October 31, 2024 and 2023, we recognized approximately $1.6 billion and $1.4 billion of revenue pertaining to amounts that were deferred as of July 31, 2024 and 2023, respectively.

- changed (2025-02-14):
[0001327567-25-000010:note_history:36]
Remaining performance obligations were $13.0 billion as of January 31, 2025, of which we expect to recognize as revenue approximately $6.1 billion over the next 12 months and the remainder thereafter.
  (was, 2024-11-21, similarity 0.9681):
[0001327567-24-000040:note_history:36]
Remaining performance obligations were $12.6 billion as of October 31, 2024, of which we expect to recognize as revenue approximately $5.9 billion over the next 12 months and the remainder thereafter.

- removed (2025-02-14):
[0001327567-24-000040:note_history:37]
|  |  |  | Three Months Ended October 31, |
|  |  |  |  |  | 2024 |  | 2023 |
| Revenue: |  |  |  |  |  |  |  |
| Americas |  |  |  |  |  |  |  |
| United States |  |  |  |  | $ | 1,344.1 |  |  | $ | 1,204.3 |  |
| Other Americas |  |  |  |  | 98.0 |  |  | 82.3 |  |
| Total Americas |  |  |  |  | 1,442.1 |  |  | 1,286.6 |  |
| Europe, the Middle East, and Africa (“EMEA”) |  |  |  |  | 441.4 |  |  | 364.9 |  |
| Asia Pacific and Japan (“APAC”) |  |  |  |  | 255.3 |  |  | 226.6 |  |
| Total revenue |  |  |  |  | $ | 2,138.8 |  |  | $ | 1,878.1 |  |

- removed (2025-02-14):
[0001327567-24-000040:note_history:38]
|  |  |  | Three Months Ended October 31, |
|  |  |  |  |  | 2024 |  | 2023 |
| Revenue: |  |  |  |  |  |  |  |
| Product |  |  |  |  | $ | 353.8 |  |  | $ | 341.1 |  |
| Subscription and support |  |  |  |  |  |  |  |
| Subscription |  |  |  |  | 1,191.8 |  |  | 988.3 |  |
| Support |  |  |  |  | 593.2 |  |  | 548.7 |  |
| Total subscription and support |  |  |  |  | 1,785.0 |  |  | 1,537.0 |  |
| Total revenue |  |  |  |  | $ | 2,138.8 |  |  | $ | 1,878.1 |  |


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: tag_name, score: 1.0

- added (2025-02-14):
[0001327567-25-000010:note_history:39]
Subsequent to January 31, 2025, $100.4 million in aggregate principal amount of the 2025 Notes was converted or had been submitted by the holders for conversion and will settle during the fiscal quarter ending April 30, 2025.

- removed (2025-02-14):
[0001327567-24-000040:note_history:40]
Subsequent to October 31, 2024, $106.0 million in aggregate principal amount of the 2025 Notes was converted or had been submitted by the holders for conversion and will settle during the fiscal quarter ending January 31, 2025.

- removed (2025-02-14):
[0001327567-24-000040:note_history:41]
Stock Split

- removed (2025-02-14):
[0001327567-24-000040:note_history:42]
On November 19, 2024, our board of directors approved a two-for-one stock split (the “stock split”) of our outstanding shares of common stock. The stock split is to be effected through an amendment to our restated certificate of incorporation, which will also effect a proportionate increase in the number of authorized shares of our common stock from 1.0 billion to 2.0 billion.

- removed (2025-02-14):
[0001327567-24-000040:note_history:43]
As a result of the stock split, each stockholder of record as of the close of trading on December 12, 2024 (the “record date”), will receive, after the close of trading on December 13, 2024, one additional share for every share held on the record date. Trading is expected to begin on a split-adjusted basis on December 16, 2024.
