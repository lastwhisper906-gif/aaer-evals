# PANW 8-K — 0001327567-25-000006 filed 2025-02-13

## item codes, every 8-K on or before 2025-02-14

- 2025-02-13 0001327567-25-000006 — 2.02, 9.01
- 2025-02-13 0001327567-25-000004 — 5.02, 9.01
- 2024-12-17 0001193125-24-280058 — 5.02, 9.01
- 2024-12-12 0001193125-24-277082 — 5.02, 5.03, 5.07, 9.01
- 2024-11-20 0001327567-24-000036 — 2.02, 8.01, 9.01
- 2024-11-15 0001193125-24-259308 — 8.01
- 2024-09-04 0001327567-24-000026 — 8.01, 9.01
- 2024-08-19 0001327567-24-000023 — 2.02, 8.01, 9.01
- 2024-05-20 0001327567-24-000015 — 2.02, 9.01
- 2024-05-16 0001327567-24-000010 — 8.01, 9.01
- 2024-02-20 0001327567-24-000003 — 2.02, 9.01
- 2023-12-14 0001193125-23-295527 — 5.02, 5.07, 9.01
- 2023-11-29 0001193125-23-285277 — 8.01, 9.01
- 2023-11-17 0001327567-23-000035 — 8.01, 9.01
- 2023-11-15 0001327567-23-000030 — 2.02, 9.01
- 2023-11-15 0001193125-23-277318 — 8.01
- 2023-08-18 0001327567-23-000020 — 2.02, 9.01
- 2023-06-08 0001193125-23-163506 — 7.01, 9.01
- 2023-06-05 0001193125-23-160228 — 7.01
- 2023-05-23 0001327567-23-000012 — 2.02, 9.01
- 2023-04-19 0001327567-23-000009 — 1.01, 2.03, 9.01
- 2023-02-21 0001327567-23-000005 — 2.02, 9.01
- 2022-12-16 0001193125-22-307346 — 5.02, 5.07
- 2022-11-17 0001327567-22-000035 — 2.02, 9.01
- 2022-11-15 0001193125-22-285017 — 8.01
- 2022-08-22 0001327567-22-000020 — 2.02, 8.01, 9.01
- 2022-05-23 0001193125-22-157474 — 5.02, 5.03, 9.01
- 2022-05-19 0001327567-22-000014 — 2.02, 9.01
- 2022-02-23 0001193125-22-049906 — 5.02
- 2022-02-22 0001327567-22-000006 — 2.02, 9.01
- 2021-12-15 0001193125-21-358074 — 5.02, 5.07
- 2021-11-18 0001327567-21-000037 — 2.02, 9.01
- 2021-10-12 0001193125-21-296438 — 3.01, 7.01, 9.01
- 2021-09-13 0001193125-21-270979 — 7.01, 9.01
- 2021-09-08 0001193125-21-267862 — 5.02, 9.01
- 2021-08-23 0001327567-21-000020 — 2.02, 9.01
- 2021-08-12 0001193125-21-244832 — 5.02, 9.01
- 2021-05-20 0001327567-21-000012 — 2.02, 9.01
- 2021-05-18 0001193125-21-164169 — 5.02 — amendment of 0001193125-21-162161
- 2021-05-14 0001193125-21-162161 — 5.02, 9.01
- 2021-03-19 0001193125-21-087516 — 5.02, 9.01
- 2021-02-22 0001628280-21-002659 — 2.02, 9.01
- 2021-02-22 0001193125-21-049293 — 5.02, 9.01
- 2020-12-18 0001193125-20-321568 — 8.01, 9.01
- 2020-12-16 0001193125-20-319091 — 3.02 — amendment of 0001193125-20-291707
- 2020-12-10 0001193125-20-314920 — 5.07
- 2020-12-08 0001193125-20-312056 — 5.02, 8.01, 9.01
- 2020-11-16 0001327567-20-000037 — 2.02, 9.01
- 2020-11-12 0001193125-20-291707 — 3.02
- 2020-10-19 0001193125-20-272060 — 5.02
- 2020-08-24 0001327567-20-000025 — 2.02, 9.01
- 2020-06-23 0001193125-20-176553 — 5.02, 9.01
- 2020-06-22 0001193125-20-175603 — 5.02, 9.01
- 2020-06-08 0001193125-20-163579 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2020-05-21 0001327567-20-000015 — 2.02, 9.01
- 2020-02-27 0001193125-20-050335 — 1.01, 2.03
- 2020-02-24 0001327567-20-000002 — 2.02, 9.01
- 2019-12-19 0001193125-19-319166 — 1.02, 9.01
- 2019-12-10 0001193125-19-310251 — 5.07
- 2019-11-25 0001327567-19-000036 — 2.02, 9.01
- 2019-11-25 0001193125-19-299886 — 5.02, 8.01 — amendment of 0001327567-19-000011
- 2019-10-22 0001193125-19-271660 — 5.02
- 2019-09-06 0001327567-19-000026 — 9.01 — amendment of 0001327567-19-000023
- 2019-09-04 0001327567-19-000023 — 2.02, 7.01, 9.01
- 2019-07-11 0001193125-19-192415 — 5.02, 9.01
- 2019-05-29 0001327567-19-000014 — 2.02, 9.01
- 2019-04-15 0001327567-19-000011 — 5.02, 9.01
- 2019-04-01 0001193125-19-094613 — 8.01, 9.01
- 2019-03-28 0001193125-19-090572 — 3.02 — amendment of 0001327567-19-000003
- 2019-02-26 0001327567-19-000006 — 2.02, 8.01, 9.01
- 2019-02-19 0001327567-19-000003 — 3.02
- 2018-12-11 0001327567-18-000033 — 5.07
- 2018-11-29 0001327567-18-000029 — 2.02, 9.01
- 2018-10-15 0001193125-18-299312 — 5.02, 9.01
- 2018-09-25 0001193125-18-282542 — 5.02
- 2018-09-14 0001193125-18-274239 — 5.03, 9.01
- 2018-09-06 0001327567-18-000018 — 1.01, 2.02, 2.03, 9.01
- 2018-07-13 0001193125-18-217281 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2018-06-04 0001327567-18-000011 — 2.02, 5.02, 9.01
- 2018-02-26 0001327567-18-000004 — 2.02, 5.02, 7.01, 9.01
- 2017-12-12 0001193125-17-367477 — 5.07
- 2017-11-20 0001327567-17-000032 — 2.02, 5.02, 9.01
- 2017-08-31 0001327567-17-000021 — 2.02, 5.02, 9.01
- 2017-05-31 0001327567-17-000016 — 2.02, 9.01
- 2017-02-28 0001327567-17-000005 — 2.02, 8.01, 9.01
- 2016-12-12 0001193125-16-790757 — 5.07
- 2016-11-21 0001327567-16-000071 — 2.02, 9.01
- 2016-10-24 0001193125-16-745121 — 5.02, 9.01
- 2016-08-30 0001327567-16-000057 — 2.02, 5.03, 8.01, 9.01
- 2016-08-22 0001193125-16-687588 — 5.02, 9.01
- 2016-05-26 0001327567-16-000051 — 2.02, 9.01
- 2016-02-25 0001327567-16-000044 — 2.02, 5.02, 9.01
- 2015-12-14 0001327567-15-000038 — 5.07
- 2015-12-14 0001193125-15-402588 — 1.01, 9.01
- 2015-11-23 0001327567-15-000033 — 2.02, 9.01
- 2015-10-19 0001193125-15-347005 — 1.01, 9.01 — amendment, the index does not say of what
- 2015-09-09 0001327567-15-000022 — 2.02, 9.01
- 2015-08-19 0001193125-15-296115 — 1.01, 2.03
- 2015-06-01 0001193125-15-207786 — 1.01, 2.03
- 2015-05-27 0001327567-15-000015 — 2.02, 9.01
- 2015-03-02 0001327567-15-000006 — 2.02, 9.01
- 2014-12-15 0001327567-14-000046 — 5.07
- 2014-11-24 0001327567-14-000040 — 2.02, 9.01
- 2014-09-22 0001193125-14-348581 — 5.02, 9.01
- 2014-09-09 0001327567-14-000025 — 2.02, 9.01
- 2014-07-01 0001193125-14-257824 — 1.01, 2.03, 3.02, 9.01
- 2014-06-26 0001193125-14-249529 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2014-06-20 0001327567-14-000020 — 9.01 — amendment of 0001193125-14-140511
- 2014-06-04 0001327567-14-000016 — 3.02
- 2014-05-30 0001193125-14-218158 — 2.02 — amendment, the index does not say of what
- 2014-05-28 0001193125-14-215060 — 1.01, 2.02, 3.02, 9.01
- 2014-04-11 0001193125-14-140511 — 2.01, 3.02, 7.01, 9.01
- 2014-03-24 0001193125-14-111318 — 1.01, 3.02, 7.01, 9.01
- 2014-03-13 0001327567-14-000009 — 5.02
- 2014-02-24 0001193125-14-063754 — 2.02, 9.01
- 2013-12-12 0001327567-13-000040 — 5.07
- 2013-11-25 0001327567-13-000033 — 2.02, 9.01
- 2013-09-30 0001193125-13-384966 — 8.01
- 2013-09-09 0001193125-13-361421 — 2.02, 9.01
- 2013-05-30 0001193125-13-241542 — 2.02, 5.02, 9.01
- 2013-03-11 0001193125-13-101082 — 5.02, 9.01
- 2013-02-28 0001193125-13-084193 — 2.02, 9.01
- 2012-12-14 0001193125-12-503335 — 5.07
- 2012-12-06 0001193125-12-493700 — 2.02, 9.01
- 2012-09-24 0001193125-12-401534 — 1.01, 2.03
- 2012-09-20 0001193125-12-398433 — 5.02, 9.01
- 2012-09-10 0001193125-12-386605 — 2.02, 9.01

## late-filing notifications on or before 2025-02-14

- none on or before 2025-02-14

## item 2.02 — earnings release, exhibit 99.1

[0001327567-25-000006:8k_2_02:1]
EX-99.1
2
ex991q225earningsrelease.htm
EX-99.1

[0001327567-25-000006:8k_2_02:2]
Document

[0001327567-25-000006:8k_2_02:3]
Exhibit 99.1

[0001327567-25-000006:8k_2_02:4]
Palo Alto Networks Reports Fiscal Second Quarter 2025 Financial Results

[0001327567-25-000006:8k_2_02:5]
•Fiscal second quarter revenue grew 14% year over year to $2.3 billion.

[0001327567-25-000006:8k_2_02:6]
•Next-Generation Security ARR grew 37% year over year to $4.8 billion.

[0001327567-25-000006:8k_2_02:7]
•Remaining performance obligation grew 21% year over year to $13.0 billion.

[0001327567-25-000006:8k_2_02:8]
SANTA CLARA, Calif., Feb. 13, 2025 — Palo Alto Networks (NASDAQ: PANW), the global cybersecurity leader, announced today financial results for its fiscal second quarter 2025, ended January 31, 2025.

[0001327567-25-000006:8k_2_02:9]
Total revenue for the fiscal second quarter 2025 grew 14% year over year to $2.3 billion, compared with total revenue of $2.0 billion for the fiscal second quarter 2024. GAAP net income for the fiscal second quarter 2025 was $0.3 billion, or $0.38 per diluted share, compared with GAAP net income of $1.7 billion, or $2.44 per diluted share, for the fiscal second quarter 2024. GAAP net income for the fiscal second quarter 2024 included a $1.5 billion net tax benefit from a release of the company’s valuation allowance.

[0001327567-25-000006:8k_2_02:10]
Non-GAAP net income for the fiscal second quarter 2025 was $0.6 billion, or $0.81 per diluted share, compared with non-GAAP net income of $0.5 billion, or $0.73 per diluted share, for the fiscal second quarter 2024. A reconciliation between GAAP and non-GAAP information is contained in the tables below.

[0001327567-25-000006:8k_2_02:11]
"In Q2, our strong business performance was fueled by customers adopting technology driven by the imperative of AI, including cloud investment and infrastructure modernization," said Nikesh Arora, chairman and CEO of Palo Alto Networks. "Our growth across regions and demand for our platforms demonstrate our customers’ confidence in our approach. It reaffirms our faith in our 2030 plans and our $15 billion NGS ARR goal."

[0001327567-25-000006:8k_2_02:12]
"Platformization drove our Q2 results, including strength in NGS ARR and RPO," said Dipak Golechha, chief financial officer of Palo Alto Networks. "As we drive leverage from our scale and see early benefits from AI-related efficiency initiatives, we again delivered profitable growth.  We expect this will continue and, as a result, we are raising operating margins and EPS for the year."

[0001327567-25-000006:8k_2_02:13]
Today, Palo Alto Networks also announced the appointment of Helle Thorning-Schmidt, former prime minister of Denmark, and Ralph Hamers, former chief executive officer of UBS Group AG and ING Group, to the company’s board of directors. More information can be found here.

[0001327567-25-000006:8k_2_02:14]
Financial Outlook

[0001327567-25-000006:8k_2_02:15]
Palo Alto Networks provides guidance based on current market conditions and expectations.

[0001327567-25-000006:8k_2_02:16]
For the fiscal third quarter 2025, we expect:

[0001327567-25-000006:8k_2_02:17]
•Next-Generation Security ARR of $5.03 billion to $5.08 billion, representing year-over-year growth of between 33% and 34%.

[0001327567-25-000006:8k_2_02:18]
•Remaining performance obligation of $13.5 billion to $13.6 billion, representing year-over-year growth of between 19% and 20%.

[0001327567-25-000006:8k_2_02:19]
•Total revenue in the range of $2.26 billion to $2.29 billion, representing year-over-year growth of between 14% and 15%.

[0001327567-25-000006:8k_2_02:20]
•Diluted non-GAAP net income per share in the range of $0.76 to $0.77, using 703 million to 706 million shares outstanding.

[0001327567-25-000006:8k_2_02:21]
For the fiscal year 2025, we expect:

[0001327567-25-000006:8k_2_02:22]
•Next-Generation Security ARR of $5.52 billion to $5.57 billion, representing year-over-year growth of between 31% and 32%.

[0001327567-25-000006:8k_2_02:23]
•Remaining performance obligation of $15.2 billion to $15.3 billion, representing year-over-year growth of between 19% and 20%.

[0001327567-25-000006:8k_2_02:24]
•Total revenue in the range of $9.14 billion to $9.19 billion, representing year-over-year growth of 14%.

[0001327567-25-000006:8k_2_02:25]
•Non-GAAP operating margin in the range of 28.0% to 28.5%.

[0001327567-25-000006:8k_2_02:26]
•Diluted non-GAAP net income per share in the range of $3.18 to $3.24, using 700 million to 708 million shares outstanding.

[0001327567-25-000006:8k_2_02:27]
•Adjusted free cash flow margin in the range of 37% to 38%.

[0001327567-25-000006:8k_2_02:28]
After the close of trading on December 12, 2024, Palo Alto Networks effected a two-for-one stock split. All share and per-share amounts presented have been retroactively adjusted to reflect the stock split.

[0001327567-25-000006:8k_2_02:29]
Guidance for non-GAAP financial measures excludes share-based compensation-related charges, including share-based payroll tax expense, acquisition-related costs, including change in fair value of contingent consideration liability, amortization expense of acquired intangible assets, litigation-related charges, including legal settlements, non-cash charges related to convertible notes, and income tax and other tax adjustments related to our long-term non-GAAP effective tax rate, along with certain non-recurring expenses and certain non-recurring cash flows. We have not reconciled non-GAAP operating margin guidance to GAAP operating margin, diluted non-GAAP net income per share guidance to GAAP net income per diluted share or adjusted free cash flow margin guidance to GAAP net cash from operating activities because we do not provide guidance on GAAP operating margin, GAAP net income or net cash from operating activities and would not be able to present the various reconciling cash and non-cash items between GAAP and non-GAAP financial measures because certain items that impact these measures are uncertain or out of our control, or cannot be reasonably predicted, including share-based compensation expense, without unreasonable effort. The actual amounts of such reconciling items will have a significant impact on the company's GAAP net income per diluted share and GAAP net cash from operating activities.

[0001327567-25-000006:8k_2_02:30]
Earnings Call Information

[0001327567-25-000006:8k_2_02:31]
Palo Alto Networks will host a video webcast for analysts and investors to discuss the company’s fiscal second quarter 2025 results as well as the outlook for its fiscal third quarter and fiscal year 2025 today at 4:30 p.m. Eastern time/1:30 p.m. Pacific time. Open to the public, investors may access the webcast, supplemental financial information and earnings slides from the “Investors” section of the company’s website at investors.paloaltonetworks.com. A replay will be available three hours after the conclusion of the webcast and archived for one year.

[0001327567-25-000006:8k_2_02:32]
Forward-Looking Statements

[0001327567-25-000006:8k_2_02:33]
This press release contains forward-looking statements that involve risks, uncertainties, and assumptions including statements regarding our platformization strategy and financial outlook for the fiscal third quarter 2025 and fiscal year 2025. There are a significant number of factors that could cause actual results to differ materially from forward-looking statements made or implied in this press release, including: developments and changes in general market, political, economic, and business conditions; failure of our platformization product offerings; failure to achieve the expected benefits of our strategic partnerships and acquisitions; changes in the fair value of our contingent consideration liability associated with acquisitions; risks associated with managing our growth; risks associated with new product, subscription and support offerings, including our product offerings that leverage AI; shifts in priorities or delays in the development or release of new product or subscription or other offerings, or the failure to timely develop and achieve market acceptance of new products and subscriptions as well as existing products, subscriptions and support offerings; failure of our business strategies; rapidly evolving technological developments in the market for security products, subscriptions and support offerings; defects, errors, or vulnerabilities in our products, subscriptions or support offerings; our customers’ purchasing decisions and the length of sales cycles; our competition; our ability to attract and retain new customers; our ability to acquire and integrate other companies, products, or technologies in a successful manner; our debt repayment obligations; and our share repurchase program, which may not be fully consummated or enhance shareholder value, and any share repurchases which could affect the price of our common stock.

[0001327567-25-000006:8k_2_02:34]
Additional risks and uncertainties on these and other factors that could affect our financial results and the forward-looking statements we make in this press release are included under the captions "Risk Factors" and "Management's Discussion and Analysis of Financial Condition and Results of Operations" and elsewhere in our Quarterly Report on Form 10-Q filed with the U.S. Securities and Exchange Commission (“SEC”) on November 21, 2024, which is available on our website at investors.paloaltonetworks.com and on the SEC's website at www.sec.gov. Additional information will also be set forth in other documents that we file with or furnish to the SEC from time to time. All forward-looking statements in this press release are based on our beliefs and information available to management as of the date hereof, and we do not assume any obligation to update the forward-looking statements provided to reflect events that occur or circumstances that exist after the date on which they were made.

[0001327567-25-000006:8k_2_02:35]
Non-GAAP Financial Measures and Other Key Metrics

[0001327567-25-000006:8k_2_02:36]
Palo Alto Networks has provided in this press release financial information that has not been prepared in accordance with generally accepted accounting principles in the United States (GAAP). The company uses these non-GAAP financial measures and other key metrics internally in analyzing its financial results and believes that the use of these non-GAAP financial measures and key metrics are helpful to investors as an additional tool to evaluate ongoing operating results and trends, and in comparing the company’s financial results with other companies in its industry, many of which present similar non-GAAP financial measures or key metrics.

[0001327567-25-000006:8k_2_02:37]
The presentation of these non-GAAP financial measures and key metrics are not meant to be considered in isolation or as a substitute for comparable GAAP financial measures and should be read only in conjunction with the company’s consolidated financial statements prepared in accordance with GAAP. A reconciliation of the company’s historical non-GAAP financial measures to their most directly comparable GAAP measures has been provided in the financial statement tables included in this press release, and investors are encouraged to review these reconciliations.

[0001327567-25-000006:8k_2_02:38]
Non-GAAP operating margin. Palo Alto Networks defines non-GAAP operating margin as non-GAAP operating income divided by total revenue. The company defines non-GAAP operating income as operating income plus share-based compensation-related charges, including share-based payroll tax expense, acquisition-related costs, including change in fair value of contingent consideration liability, amortization expense of acquired intangible assets, and litigation-related charges, including legal settlements. The company believes that non-GAAP operating margin provides management and investors with greater visibility into the underlying performance of the company’s core business operating results.

[0001327567-25-000006:8k_2_02:39]
Non-GAAP net income and net income per share, diluted. Palo Alto Networks defines non-GAAP net income as net income plus share-based compensation-related charges, including share-based payroll tax expense, acquisition-related costs, including change in fair value of contingent consideration liability, amortization expense of acquired intangible assets, litigation-related charges, including legal settlements, and non-cash charges related to convertible notes. The company also excludes from non-GAAP net income tax adjustments related to our long-term non-GAAP effective tax rate in order to provide a complete picture of the company’s recurring core business operating results. The company defines non-GAAP net income per share, diluted, as non-GAAP net income divided by the weighted-average diluted shares outstanding, which includes the potentially dilutive effect of the company’s employee equity incentive plan awards and the company’s convertible senior notes outstanding and related warrants, after giving effect to the anti-dilutive impact of the company’s note hedge agreements, which reduces the potential economic dilution that otherwise would occur upon conversion of the company’s convertible senior notes. Under GAAP, the anti-dilutive impact of the note hedge is not reflected in diluted shares outstanding. The company considers these non-GAAP financial measures to be useful metrics for management and investors for the same reasons that it uses non-GAAP operating margin.

[0001327567-25-000006:8k_2_02:40]
Next-Generation Security ARR. Palo Alto Networks defines Next-Generation Security ARR as the annualized allocated revenue of all active contracts as of the final day of the reporting period for Prisma and Cortex offerings inclusive of the VM-Series and related services, and certain cloud-delivered security services. Beginning the fiscal first quarter 2025, Next-Generation Security ARR includes revenue attributable to QRadar software as a service contracts. The company considers Next-Generation Security ARR to be a useful metric for management and investors to evaluate the performance of the company because Next-Generation Security is where the company has focused its innovation and the company expects its overall revenue to be disproportionately driven by this Next-Generation Security portfolio. Because Next-Generation Security ARR does not have the effect of providing a numerical measure that is different from any comparable GAAP measure, the company does not consider it a non-GAAP measure.

[0001327567-25-000006:8k_2_02:41]
Investors are cautioned that there are a number of limitations associated with the use of non-GAAP financial measures and key metrics as analytical tools. Many of the adjustments to the company’s GAAP financial measures reflect the exclusion of items that are recurring and will be reflected in the company’s financial results for the foreseeable future, such as share-based compensation, which is an important part of Palo Alto Networks’ employees’ compensation and impacts their performance. Furthermore, these non-GAAP financial measures are not based on any standardized methodology prescribed by GAAP, and the components that Palo Alto Networks excludes in its calculation of non-GAAP financial measures may differ from the components that its peer companies exclude when they report their non-GAAP results of operations. Palo Alto Networks compensates for these limitations by providing specific information regarding the GAAP amounts excluded from these non-GAAP financial measures. In the future, the company may also exclude non-recurring expenses and other expenses that do not reflect the company’s core business operating results.

[0001327567-25-000006:8k_2_02:42]
About Palo Alto Networks

[0001327567-25-000006:8k_2_02:43]
Palo Alto Networks is the global cybersecurity leader, committed to making each day safer than the one before with industry-leading, AI-powered solutions in network security, cloud security and security operations. Powered by Precision AI, our technologies deliver precise threat detection and swift response, minimizing false positives and enhancing security effectiveness. Our platformization approach integrates diverse security solutions into a unified, scalable platform, streamlining management and providing operational efficiencies with comprehensive protection. From defending network perimeters to safeguarding cloud environments and ensuring rapid incident response, Palo Alto Networks empowers businesses to achieve Zero Trust security and confidently embrace digital transformation in an ever-evolving threat landscape. This unwavering commitment to security and innovation makes us the cybersecurity partner of choice.

[0001327567-25-000006:8k_2_02:44]
At Palo Alto Networks, we're committed to bringing together the very best people in service of our mission, so we're also proud to be the cybersecurity workplace of choice, recognized among Newsweek's Most Loved Workplaces (2021-2024), with a score of 100 on the Disability Equality Index (2024, 2023, 2022), and HRC Best Places for LGBTQ+ Equality (2022). For more information, visit www.paloaltonetworks.com.

[0001327567-25-000006:8k_2_02:45]
Palo Alto Networks, the Palo Alto Networks logo, Cortex, Precision AI, and Prisma are trademarks of Palo Alto Networks, Inc. in the United States or in jurisdictions throughout the world. All other trademarks, trade names, or service marks used or mentioned herein belong to their respective owners. Any unreleased services or features (and any services or features not generally available to customers) referenced in this or other press releases or public statements are not currently available (or are not yet generally available to customers) and may not be delivered when expected or at all. Customers who purchase Palo Alto Networks applications should make their purchase decisions based on services and features currently generally available.

[0001327567-25-000006:8k_2_02:46]
Media Contact:

[0001327567-25-000006:8k_2_02:47]
Nicole Hockin

[0001327567-25-000006:8k_2_02:48]
VP, Global Communications, Palo Alto Networks

[0001327567-25-000006:8k_2_02:49]
press@paloaltonetworks.com

[0001327567-25-000006:8k_2_02:50]
Investor Relations Contact:

[0001327567-25-000006:8k_2_02:51]
Ryan Fenwick

[0001327567-25-000006:8k_2_02:52]
Sr. Manager - Investor Relations, Palo Alto Networks

[0001327567-25-000006:8k_2_02:53]
ir@paloaltonetworks.com

[0001327567-25-000006:8k_2_02:54]
1

[0001327567-25-000006:8k_2_02:55]
| Palo Alto Networks, Inc. |
| Preliminary Condensed Consolidated Statements of Operations |
| (In millions, except per share data) |
| (Unaudited) |
|  | Three Months Ended |  | Six Months Ended |
|  | January 31, |  | January 31, |
|  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Revenue: |  |  |  |  |  |  |  |
| Product | $ | 421.5 |  |  | $ | 390.7 |  |  | $ | 775.3 |  |  | $ | 731.8 |  |
| Subscription and support | 1,835.9 |  |  | 1,584.4 |  |  | 3,620.9 |  |  | 3,121.4 |  |
| Total revenue | 2,257.4 |  |  | 1,975.1 |  |  | 4,396.2 |  |  | 3,853.2 |  |
| Cost of revenue: |  |  |  |  |  |  |  |
| Product | 101.3 |  |  | 88.2 |  |  | 176.3 |  |  | 165.6 |  |
| Subscription and support | 497.9 |  |  | 410.9 |  |  | 977.0 |  |  | 806.3 |  |
| Total cost of revenue | 599.2 |  |  | 499.1 |  |  | 1,153.3 |  |  | 971.9 |  |
| Total gross profit | 1,658.2 |  |  | 1,476.0 |  |  | 3,242.9 |  |  | 2,881.3 |  |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | 505.7 |  |  | 447.9 |  |  | 986.1 |  |  | 857.4 |  |
| Sales and marketing | 758.3 |  |  | 673.0 |  |  | 1,478.4 |  |  | 1,333.5 |  |
| General and administrative | 153.8 |  |  | 301.5 |  |  | 251.5 |  |  | 421.6 |  |
| Total operating expenses | 1,417.8 |  |  | 1,422.4 |  |  | 2,716.0 |  |  | 2,612.5 |  |
| Operating income | 240.4 |  |  | 53.6 |  |  | 526.9 |  |  | 268.8 |  |
| Interest expense | (0.9) |  |  | (2.8) |  |  | (2.1) |  |  | (5.7) |  |
| Other income, net | 85.3 |  |  | 84.7 |  |  | 168.6 |  |  | 155.0 |  |
| Income before income taxes | 324.8 |  |  | 135.5 |  |  | 693.4 |  |  | 418.1 |  |
| Provision for (benefit from) income taxes | 57.5 |  |  | (1,611.4) |  |  | 75.4 |  |  | (1,523.0) |  |
| Net income | $ | 267.3 |  |  | $ | 1,746.9 |  |  | $ | 618.0 |  |  | $ | 1,941.1 |  |
| Net income per share, basic | $ | 0.41 |  |  | $ | 2.73 |  |  | $ | 0.94 |  |  | $ | 3.08 |  |
| Net income per share, diluted | $ | 0.38 |  |  | $ | 2.44 |  |  | $ | 0.87 |  |  | $ | 2.74 |  |
| Weighted-average shares used to compute net income per share, basic | 659.3 |  |  | 639.3 |  |  | 656.5 |  |  | 629.7 |  |
| Weighted-average shares used to compute net income per share, diluted | 709.0 |  |  | 715.0 |  |  | 709.1 |  |  | 707.3 |  |

[0001327567-25-000006:8k_2_02:56]
2

[0001327567-25-000006:8k_2_02:57]
| Palo Alto Networks, Inc. |
| Reconciliation of GAAP to Non-GAAP Financial Measures |
| (In millions, except per share amounts) |
| (Unaudited) |
|  | Three Months Ended |  | Six Months Ended |
|  | January 31, |  | January 31, |
|  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| GAAP operating income | $ | 240.4 |  |  | $ | 53.6 |  |  | $ | 526.9 |  |  | $ | 268.8 |  |
| Share-based compensation-related charges | 343.3 |  |  | 296.8 |  |  | 658.4 |  |  | 584.6 |  |
| Acquisition-related costs(1) | 9.7 |  |  | 7.3 |  |  | 24.8 |  |  | 7.3 |  |
| Amortization expense of acquired intangible assets | 43.8 |  |  | 27.9 |  |  | 84.5 |  |  | 52.4 |  |
| Litigation-related charges(2) | 3.2 |  |  | 178.6 |  |  | (38.0) |  |  | 180.4 |  |
| Non-GAAP operating income | $ | 640.4 |  |  | $ | 564.2 |  |  | $ | 1,256.6 |  |  | $ | 1,093.5 |  |
| Non-GAAP operating margin | 28.4 | % |  | 28.6 | % |  | 28.6 | % |  | 28.4 | % |
| GAAP net income | $ | 267.3 |  |  | $ | 1,746.9 |  |  | $ | 618.0 |  |  | $ | 1,941.1 |  |
| Share-based compensation-related charges | 343.3 |  |  | 296.8 |  |  | 658.4 |  |  | 584.6 |  |
| Acquisition-related costs(1) | 9.7 |  |  | 7.3 |  |  | 24.8 |  |  | 7.3 |  |
| Amortization expense of acquired intangible assets | 43.8 |  |  | 27.9 |  |  | 84.5 |  |  | 52.4 |  |
| Litigation-related charges(2) | 3.2 |  |  | 178.6 |  |  | (38.0) |  |  | 180.4 |  |
| Non-cash charges related to convertible notes(3) | 0.3 |  |  | 1.1 |  |  | 0.8 |  |  | 2.1 |  |
| Income tax and other tax adjustments(4) | (101.9) |  |  | (1,753.9) |  |  | (237.9) |  |  | (1,796.9) |  |
| Non-GAAP net income | $ | 565.7 |  |  | $ | 504.7 |  |  | $ | 1,110.6 |  |  | $ | 971.0 |  |
| GAAP net income per share, diluted | $ | 0.38 |  |  | $ | 2.44 |  |  | $ | 0.87 |  |  | $ | 2.74 |  |
| Share-based compensation-related charges | 0.50 |  |  | 0.44 |  |  | 0.96 |  |  | 0.88 |  |
| Acquisition-related costs(1) | 0.01 |  |  | 0.01 |  |  | 0.03 |  |  | 0.01 |  |
| Amortization expense of acquired intangible assets | 0.06 |  |  | 0.04 |  |  | 0.12 |  |  | 0.07 |  |
| Litigation-related charges(2) | 0.00 |  |  | 0.25 |  |  | (0.05) |  |  | 0.26 |  |
| Non-cash charges related to convertible notes(3) | 0.00 |  |  | 0.00 |  |  | 0.00 |  |  | 0.00 |  |
| Income tax and other tax adjustments(4) | (0.14) |  |  | (2.45) |  |  | (0.34) |  |  | (2.54) |  |
| Non-GAAP net income per share, diluted | $ | 0.81 |  |  | $ | 0.73 |  |  | $ | 1.59 |  |  | $ | 1.42 |  |
| GAAP weighted-average shares used to compute net income per share, diluted | 709.0 |  |  | 715.0 |  |  | 709.1 |  |  | 707.3 |  |
| Weighted-average anti-dilutive impact of note hedge agreements | (8.7) |  |  | (25.9) |  |  | (10.3) |  |  | (24.6) |  |
| Non-GAAP weighted-average shares used to compute net income per share, diluted | 700.3 |  |  | 689.1 |  |  | 698.8 |  |  | 682.7 |  |

[0001327567-25-000006:8k_2_02:58]
(1)    Consists of acquisition transaction costs, share-based compensation related to the cash settlement of certain equity awards, change in fair value of contingent consideration liability, and costs to terminate certain employment, operating lease, and other contracts of the acquired companies.

[0001327567-25-000006:8k_2_02:59]
(2)    Consists of the amortization of intellectual property licenses and covenant not to sue, and a legal contingency charge (credit).

[0001327567-25-000006:8k_2_02:60]
(3)     Consists of non-cash interest expense for amortization of debt issuance costs related to the company's convertible senior notes.

[0001327567-25-000006:8k_2_02:61]
(4)    Consists of income tax adjustments related to our long-term non-GAAP effective tax rate. During the three and six months ended January 31, 2024, it included a tax benefit from a release of our valuation allowance on U.S. federal, U.S. states other than California, and United Kingdom deferred tax assets.

[0001327567-25-000006:8k_2_02:62]
3

[0001327567-25-000006:8k_2_02:63]
| Palo Alto Networks, Inc. |
| Preliminary Condensed Consolidated Balance Sheets |
| (In millions) |
|  | January 31, 2025 |  | July 31, 2024 |
|  | (unaudited) |  |  |
| Assets |  |  |  |
| Current assets: |  |  |  |
| Cash and cash equivalents | $ | 2,226.3 |  |  | $ | 1,535.2 |  |
| Short-term investments | 1,006.6 |  |  | 1,043.6 |  |
| Accounts receivable, net | 1,495.5 |  |  | 2,618.6 |  |
| Short-term financing receivables, net | 754.9 |  |  | 725.9 |  |
| Short-term deferred contract costs | 376.1 |  |  | 369.0 |  |
| Prepaid expenses and other current assets | 480.4 |  |  | 557.4 |  |
| Total current assets | 6,339.8 |  |  | 6,849.7 |  |
| Property and equipment, net | 358.2 |  |  | 361.1 |  |
| Operating lease right-of-use assets | 372.9 |  |  | 385.9 |  |
| Long-term investments | 4,559.8 |  |  | 4,173.2 |  |
| Long-term financing receivables, net | 1,163.8 |  |  | 1,182.1 |  |
| Long-term deferred contract costs | 523.4 |  |  | 562.0 |  |
| Goodwill | 4,050.8 |  |  | 3,350.1 |  |
| Intangible assets, net | 771.4 |  |  | 374.9 |  |
| Deferred tax assets | 2,446.9 |  |  | 2,399.0 |  |
| Other assets | 364.7 |  |  | 352.9 |  |
| Total assets | $ | 20,951.7 |  |  | $ | 19,990.9 |  |
| Liabilities and stockholders’ equity |  |  |  |
| Current liabilities: |  |  |  |
| Accounts payable | $ | 149.3 |  |  | $ | 116.3 |  |
| Accrued compensation | 491.6 |  |  | 554.7 |  |
| Accrued and other liabilities | 777.6 |  |  | 506.7 |  |
| Deferred revenue | 5,599.9 |  |  | 5,541.1 |  |
| Convertible senior notes, net | 533.8 |  |  | 963.9 |  |
| Total current liabilities | 7,552.2 |  |  | 7,682.7 |  |
| Long-term deferred revenue | 5,662.5 |  |  | 5,939.4 |  |
| Deferred tax liabilities | 116.1 |  |  | 387.7 |  |
| Long-term operating lease liabilities | 363.0 |  |  | 380.5 |  |
| Other long-term liabilities | 882.6 |  |  | 430.9 |  |
| Total liabilities | 14,576.4 |  |  | 14,821.2 |  |
| Stockholders’ equity: |  |  |  |
| Preferred stock | — |  |  | — |  |
| Common stock and additional paid-in capital | 4,421.0 |  |  | 3,821.1 |  |
| Accumulated other comprehensive loss | (13.9) |  |  | (1.6) |  |
| Retained earnings | 1,968.2 |  |  | 1,350.2 |  |
| Total stockholders’ equity | 6,375.3 |  |  | 5,169.7 |  |
| Total liabilities and stockholders’ equity | $ | 20,951.7 |  |  | $ | 19,990.9 |  |

[0001327567-25-000006:8k_2_02:64]
4
