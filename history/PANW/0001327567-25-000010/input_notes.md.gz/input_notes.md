# PANW notes — 0001327567-25-000010


## us-gaap:BusinessDescriptionAndAccountingPoliciesTextBlock

[0001327567-25-000010:notes:1]
[same as prior period, unchanged from 0001327567-24-000040:notes:1]

[0001327567-25-000010:notes:2]
[same as prior period, unchanged from 0001327567-24-000040:notes:2]

[0001327567-25-000010:notes:3]
[same as prior period, unchanged from 0001327567-24-000040:notes:3]

[0001327567-25-000010:notes:4]
[same as prior period, unchanged from 0001327567-24-000040:notes:4]

[0001327567-25-000010:notes:5]
[same as prior period, unchanged from 0001327567-24-000040:notes:5]

[0001327567-25-000010:notes:6]
[same as prior period, unchanged from 0001327567-24-000040:notes:6]

[0001327567-25-000010:notes:7]
The preparation of condensed consolidated financial statements in conformity with U.S. GAAP requires management to make estimates and assumptions that affect the amounts reported and disclosed in the condensed consolidated financial statements and the accompanying notes. We evaluate our estimates on an ongoing basis. Management estimates include, but are not limited to, the standalone selling price for our products and services, share-based compensation, fair value of assets acquired and liabilities assumed in business combinations, fair value of contingent consideration liability, the assessment of recoverability of our intangibles and goodwill, valuation allowance against deferred tax assets, manufacturing partner and supplier liabilities, deferred contract cost benefit period, and loss contingencies. We base our estimates on assumptions, both historical and forward looking, that we believe are reasonable. Actual results could differ materially from those estimates due to risks and uncertainties, including uncertainty in the current economic environment.

[0001327567-25-000010:notes:8]
Stock Split

[0001327567-25-000010:notes:9]
On December 12, 2024, we effected a two-for-one stock split of our outstanding shares of common stock through an amendment to our restated certificate of incorporation (“Stock Split”), which also effected a proportionate increase in the number of authorized shares of our common stock from 1.0 billion to 2.0 billion. The par value per share of our common stock remains unchanged at $0.0001 per share after the Stock Split. All references made to share or per share amounts related to our common stock have been retroactively adjusted on the accompanying condensed consolidated financial statements and applicable disclosures to reflect the effects of the Stock Split.

[0001327567-25-000010:notes:10]
[same as prior period, unchanged from 0001327567-24-000040:notes:8]

[0001327567-25-000010:notes:11]
There have been no material changes to our significant accounting policies as of and for the six months ended January 31, 2025, as compared to the significant accounting policies described in our Annual Report on Form 10-K for the fiscal year ended July 31, 2024, except for the update to the disclosure of our accounting policies as described below resulting from our acquisition of certain QRadar assets from International Business Machines Corporation (“IBM”). Refer to Note 7. Acquisition for additional information.

[0001327567-25-000010:notes:12]
[same as prior period, unchanged from 0001327567-24-000040:notes:10]

[0001327567-25-000010:notes:13]
[same as prior period, unchanged from 0001327567-24-000040:notes:11]

[0001327567-25-000010:notes:14]
Contingent consideration obligations incurred in connection with a business combination are recorded at fair value on the acquisition date and remeasured at each subsequent reporting period until the related contingencies have been resolved, with the change in fair value recognized in general and administrative expense on our condensed consolidated statements of operations. Payments not made soon after the acquisition date to settle a contingent consideration liability are classified as cash flows from financing activities up to the amount of the contingent consideration liability recognized at the acquisition date.

[0001327567-25-000010:notes:15]
Recently Issued Accounting Pronouncements

[0001327567-25-000010:notes:16]
[same as prior period, unchanged from 0001327567-24-000040:notes:14]

[0001327567-25-000010:notes:17]
[same as prior period, unchanged from 0001327567-24-000040:notes:15]

[0001327567-25-000010:notes:18]
[same as prior period, unchanged from 0001327567-24-000040:notes:16]

[0001327567-25-000010:notes:19]
[same as prior period, unchanged from 0001327567-24-000040:notes:17]

[0001327567-25-000010:notes:20]
Expense Disaggregation Disclosures

[0001327567-25-000010:notes:21]
In November 2024, the FASB issued authoritative guidance that expands annual and interim disclosure of specified information about certain costs and expenses in the notes to financial statements. The standard is effective for our annual period in fiscal 2028 and interim periods beginning in the first quarter of fiscal 2029, and could be applied either prospectively or retrospectively. Early adoption is permitted. We are currently evaluating the impact of this standard on our disclosures in the consolidated financial statements.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001327567-25-000010:notes:22]
[same as prior period, unchanged from 0001327567-24-000040:notes:18]

[0001327567-25-000010:notes:23]
[same as prior period, unchanged from 0001327567-24-000040:notes:19]

[0001327567-25-000010:notes:24]
|  | Three Months Ended January 31, |  | Six Months Ended January 31, |
|  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Revenue: |  |  |  |  |  |  |  |
| Americas |  |  |  |  |  |  |  |
| United States | $ | 1,400.5 |  |  | $ | 1,248.2 |  |  | $ | 2,744.6 |  |  | $ | 2,452.5 |  |
| Other Americas | 101.9 |  |  | 86.0 |  |  | 199.9 |  |  | 168.3 |  |
| Total Americas | 1,502.4 |  |  | 1,334.2 |  |  | 2,944.5 |  |  | 2,620.8 |  |
| Europe, the Middle East, and Africa (“EMEA”) | 480.0 |  |  | 406.8 |  |  | 921.4 |  |  | 771.7 |  |
| Asia Pacific and Japan (“APAC”) | 275.0 |  |  | 234.1 |  |  | 530.3 |  |  | 460.7 |  |
| Total revenue | $ | 2,257.4 |  |  | $ | 1,975.1 |  |  | $ | 4,396.2 |  |  | $ | 3,853.2 |  |

[0001327567-25-000010:notes:25]
[same as prior period, unchanged from 0001327567-24-000040:notes:21]

[0001327567-25-000010:notes:26]
|  | Three Months Ended January 31, |  | Six Months Ended January 31, |
|  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Revenue: |  |  |  |  |  |  |  |
| Product | $ | 421.5 |  |  | $ | 390.7 |  |  | $ | 775.3 |  |  | $ | 731.8 |  |
| Subscription and support |  |  |  |  |  |  |  |
| Subscription | 1,233.2 |  |  | 1,027.1 |  |  | 2,425.0 |  |  | 2,015.4 |  |
| Support | 602.7 |  |  | 557.3 |  |  | 1,195.9 |  |  | 1,106.0 |  |
| Total subscription and support | 1,835.9 |  |  | 1,584.4 |  |  | 3,620.9 |  |  | 3,121.4 |  |
| Total revenue | $ | 2,257.4 |  |  | $ | 1,975.1 |  |  | $ | 4,396.2 |  |  | $ | 3,853.2 |  |

[0001327567-25-000010:notes:27]
[same as prior period, unchanged from 0001327567-24-000040:notes:23]

[0001327567-25-000010:notes:28]
During the six months ended January 31, 2025 and 2024, we recognized approximately $3.1 billion and $2.7 billion of revenue pertaining to amounts that were deferred as of July 31, 2024 and 2023, respectively.

[0001327567-25-000010:notes:29]
[same as prior period, unchanged from 0001327567-24-000040:notes:25]

[0001327567-25-000010:notes:30]
Remaining performance obligations were $13.0 billion as of January 31, 2025, of which we expect to recognize as revenue approximately $6.1 billion over the next 12 months and the remainder thereafter.


## us-gaap:FairValueDisclosuresTextBlock

[0001327567-25-000010:notes:31]
Fair Value Measurements
The following table presents our financial assets and liabilities measured at fair value on a recurring basis as of January 31, 2025 and July 31, 2024 (in millions):

[0001327567-25-000010:notes:32]
|  | January 31, 2025 |  | July 31, 2024 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| Cash equivalents: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds | $ | 1,291.9 |  |  | $ | — |  |  | $ | — |  |  | $ | 1,291.9 |  |  | $ | 494.0 |  |  | $ | — |  |  | $ | — |  |  | $ | 494.0 |  |
| Commercial paper | — |  |  | 277.8 |  |  | — |  |  | 277.8 |  |  | — |  |  | 299.6 |  |  | — |  |  | 299.6 |  |
| Corporate debt securities | — |  |  | 4.3 |  |  | — |  |  | 4.3 |  |  | — |  |  | 18.2 |  |  | — |  |  | 18.2 |  |
| U.S. government and agency securities | — |  |  | 18.0 |  |  | — |  |  | 18.0 |  |  | — |  |  | 149.6 |  |  | — |  |  | 149.6 |  |
| Total cash equivalents | 1,291.9 |  |  | 300.1 |  |  | — |  |  | 1,592.0 |  |  | 494.0 |  |  | 467.4 |  |  | — |  |  | 961.4 |  |
| Short-term investments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Certificates of deposit | — |  |  | 1.0 |  |  | — |  |  | 1.0 |  |  | — |  |  | 20.6 |  |  | — |  |  | 20.6 |  |
| Commercial paper | — |  |  | 34.6 |  |  | — |  |  | 34.6 |  |  | — |  |  | 79.9 |  |  | — |  |  | 79.9 |  |
| Corporate debt securities | — |  |  | 936.8 |  |  | — |  |  | 936.8 |  |  | — |  |  | 935.9 |  |  | — |  |  | 935.9 |  |
| U.S. government and agency securities | — |  |  | 15.6 |  |  | — |  |  | 15.6 |  |  | — |  |  | 2.7 |  |  | — |  |  | 2.7 |  |
| Non-U.S. government and agency securities | — |  |  | 3.1 |  |  | — |  |  | 3.1 |  |  | — |  |  | 4.2 |  |  | — |  |  | 4.2 |  |
| Asset-backed securities | — |  |  | 15.5 |  |  | — |  |  | 15.5 |  |  | — |  |  | 0.3 |  |  | — |  |  | 0.3 |  |
| Total short-term investments | — |  |  | 1,006.6 |  |  | — |  |  | 1,006.6 |  |  | — |  |  | 1,043.6 |  |  | — |  |  | 1,043.6 |  |

[0001327567-25-000010:notes:33]
|  | January 31, 2025 |  | July 31, 2024 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| Long-term investments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Corporate debt securities | — |  |  | 3,476.5 |  |  | — |  |  | 3,476.5 |  |  | — |  |  | 3,151.3 |  |  | — |  |  | 3,151.3 |  |
| U.S. government and agency securities | — |  |  | 83.4 |  |  | — |  |  | 83.4 |  |  | — |  |  | 19.0 |  |  | — |  |  | 19.0 |  |
| Non-U.S. government and agency securities | — |  |  | 26.0 |  |  | — |  |  | 26.0 |  |  | — |  |  | 54.4 |  |  | — |  |  | 54.4 |  |
| Asset-backed securities | — |  |  | 973.9 |  |  | — |  |  | 973.9 |  |  | — |  |  | 948.5 |  |  | — |  |  | 948.5 |  |
| Total long-term investments | — |  |  | 4,559.8 |  |  | — |  |  | 4,559.8 |  |  | — |  |  | 4,173.2 |  |  | — |  |  | 4,173.2 |  |
| Prepaid expenses and other current assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency forward contracts | — |  |  | 10.0 |  |  | — |  |  | 10.0 |  |  | — |  |  | 4.1 |  |  | — |  |  | 4.1 |  |
| Total prepaid expenses and other current assets | — |  |  | 10.0 |  |  | — |  |  | 10.0 |  |  | — |  |  | 4.1 |  |  | — |  |  | 4.1 |  |
| Other assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency forward contracts | — |  |  | 3.0 |  |  | — |  |  | 3.0 |  |  | — |  |  | 0.1 |  |  | — |  |  | 0.1 |  |
| Total other assets | — |  |  | 3.0 |  |  | — |  |  | 3.0 |  |  | — |  |  | 0.1 |  |  | — |  |  | 0.1 |  |
| Total assets measured at fair value | $ | 1,291.9 |  |  | $ | 5,879.5 |  |  | $ | — |  |  | $ | 7,171.4 |  |  | $ | 494.0 |  |  | $ | 5,688.4 |  |  | $ | — |  |  | $ | 6,182.4 |  |
| Accrued and other liabilities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency forward contracts | $ | — |  |  | $ | 28.2 |  |  | $ | — |  |  | $ | 28.2 |  |  | $ | — |  |  | $ | 15.3 |  |  | $ | — |  |  | $ | 15.3 |  |
| Contingent consideration | — |  |  | — |  |  | 312.8 |  |  | 312.8 |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Total accrued and other liabilities | — |  |  | 28.2 |  |  | 312.8 |  |  | 341.0 |  |  | — |  |  | 15.3 |  |  | — |  |  | 15.3 |  |
| Other long-term liabilities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency forward contracts | — |  |  | 2.5 |  |  | — |  |  | 2.5 |  |  | — |  |  | 0.9 |  |  | — |  |  | 0.9 |  |
| Contingent consideration | — |  |  | — |  |  | 352.1 |  |  | 352.1 |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Total other long-term liabilities | — |  |  | 2.5 |  |  | 352.1 |  |  | 354.6 |  |  | — |  |  | 0.9 |  |  | — |  |  | 0.9 |  |
| Total liabilities measured at fair value | $ | — |  |  | $ | 30.7 |  |  | $ | 664.9 |  |  | $ | 695.6 |  |  | $ | — |  |  | $ | 16.2 |  |  | $ | — |  |  | $ | 16.2 |  |

[0001327567-25-000010:notes:34]
[same as prior period, unchanged from 0001327567-24-000040:notes:30]

[0001327567-25-000010:notes:35]
[same as prior period, unchanged from 0001327567-24-000040:notes:31]

[0001327567-25-000010:notes:36]
|  | Three Months Ended January 31, 2025 |  | Six Months Ended January 31, 2025 |  |  |
| Contingent consideration liability at the beginning of the period | $ | 655.2 |  |  | $ | — |  |  |  |
| Initial valuation on the acquisition date | — |  |  | 648.9 |  |  |  |
| Change in fair value | 9.7 |  |  | 16.0 |  |  |  |
| Contingent consideration liability at the end of the period | $ | 664.9 |  |  | $ | 664.9 |  |  |  |

[0001327567-25-000010:notes:37]
The total estimated fair value of our financing receivables approximates their carrying amounts as of January 31, 2025 and July 31, 2024. We consider the fair value of our financing receivables to be a Level 3 measurement as we use unobservable inputs in determining discounted cash flows to estimate the fair value.

[0001327567-25-000010:notes:38]
Refer to Note 9. Debt for the carrying amount and estimated fair value of our convertible senior notes as of January 31, 2025 and July 31, 2024.


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock

[0001327567-25-000010:notes:39]
Cash Equivalents and Investments
Available-for-sale Debt Securities

[0001327567-25-000010:notes:40]
The following tables summarize the amortized cost, unrealized gains and losses, and fair value of our available-for-sale debt securities as of January 31, 2025 and July 31, 2024 (in millions):

[0001327567-25-000010:notes:41]
|  | January 31, 2025 |
|  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Fair Value |
| Cash equivalents: |  |  |  |  |  |  |  |
| Commercial paper | $ | 277.7 |  |  | $ | 0.1 |  |  | $ | — |  |  | $ | 277.8 |  |
| Corporate debt securities | 4.3 |  |  | — |  |  | — |  |  | 4.3 |  |
| U.S. government and agency securities | 18.0 |  |  | — |  |  | — |  |  | 18.0 |  |
| Total available-for-sale cash equivalents | $ | 300.0 |  |  | $ | 0.1 |  |  | $ | — |  |  | $ | 300.1 |  |
| Investments: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 1.0 |  |  | $ | — |  |  | $ | — |  |  | $ | 1.0 |  |
| Commercial paper | 34.6 |  |  | — |  |  | — |  |  | 34.6 |  |
| Corporate debt securities | 4,401.7 |  |  | 20.3 |  |  | (8.7) |  |  | 4,413.3 |  |
| U.S. government and agency securities | 99.1 |  |  | — |  |  | (0.1) |  |  | 99.0 |  |
| Non-U.S. government and agency securities | 28.8 |  |  | 0.3 |  |  | — |  |  | 29.1 |  |
| Asset-backed securities | 983.1 |  |  | 6.8 |  |  | (0.5) |  |  | 989.4 |  |
| Total available-for-sale investments | $ | 5,548.3 |  |  | $ | 27.4 |  |  | $ | (9.3) |  |  | $ | 5,566.4 |  |

[0001327567-25-000010:notes:42]
|  | July 31, 2024 |
|  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Fair Value |
| Cash equivalents: |  |  |  |  |  |  |  |
| Commercial paper | $ | 299.6 |  |  | $ | — |  |  | $ | — |  |  | $ | 299.6 |  |
| Corporate debt securities | 18.2 |  |  | — |  |  | — |  |  | 18.2 |  |
| U.S. government and agency securities | 149.6 |  |  | — |  |  | — |  |  | 149.6 |  |
| Total available-for-sale cash equivalents | $ | 467.4 |  |  | $ | — |  |  | $ | — |  |  | $ | 467.4 |  |
| Investments: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 20.6 |  |  | $ | — |  |  | $ | — |  |  | $ | 20.6 |  |
| Commercial paper | 79.9 |  |  | 0.1 |  |  | (0.1) |  |  | 79.9 |  |
| Corporate debt securities | 4,065.5 |  |  | 28.3 |  |  | (6.6) |  |  | 4,087.2 |  |
| U.S. government and agency securities | 21.9 |  |  | — |  |  | (0.2) |  |  | 21.7 |  |
| Non-U.S. government and agency securities | 57.9 |  |  | 0.7 |  |  | — |  |  | 58.6 |  |
| Asset-backed securities | 943.1 |  |  | 6.3 |  |  | (0.6) |  |  | 948.8 |  |
| Total available-for-sale investments | $ | 5,188.9 |  |  | $ | 35.4 |  |  | $ | (7.5) |  |  | $ | 5,216.8 |  |

[0001327567-25-000010:notes:43]
As of January 31, 2025, the gross unrealized losses that have been in a continuous unrealized loss position for less than 12 months were $8.9 million, which were related to $1.5 billion of available-for-sale debt securities, and the gross unrealized losses that have been in a continuous unrealized loss position for more than 12 months were $0.4 million, which were related to $215.4 million of available-for-sale debt securities. As of July 31, 2024 the gross unrealized losses that have been in a continuous unrealized loss position for less than 12 months were $1.5 million, which were related to $949.4 million of available-for-sale debt securities, and the gross unrealized losses that have been in a continuous unrealized loss position for more than 12 months were $6.0 million, which were related to $915.3 million of available-for-sale debt securities.

[0001327567-25-000010:notes:44]
Unrealized losses related to our available-for-sale debt securities are primarily due to interest rate fluctuations as opposed to credit quality. We do not intend to sell any of the securities in an unrealized loss position and it is not likely that we would be required to sell these securities before recovery of their amortized cost basis, which may be at maturity. We did not recognize any credit losses related to our available-for-sale debt securities during the three and six months ended January 31, 2025 and 2024.

[0001327567-25-000010:notes:45]
The following table summarizes the amortized cost and fair value of our available-for-sale debt securities as of January 31, 2025, by contractual years-to-maturity (in millions):

[0001327567-25-000010:notes:46]
|  | Amortized Cost |  | Fair Value |
| Due within one year | $ | 1,305.4 |  |  | $ | 1,306.7 |  |
| Due between one and three years | 1,769.2 |  |  | 1,776.7 |  |
| Due between three and five years | 2,453.7 |  |  | 2,461.0 |  |
| Due between five and ten years | 206.1 |  |  | 207.0 |  |
| Due after ten years | 113.9 |  |  | 115.1 |  |
| Total | $ | 5,848.3 |  |  | $ | 5,866.5 |  |

[0001327567-25-000010:notes:47]
Marketable Equity Securities

[0001327567-25-000010:notes:48]
Marketable equity securities consist of money market funds and are included in cash and cash equivalents on our condensed consolidated balance sheets. As of January 31, 2025 and July 31, 2024, the carrying values of our marketable equity securities were $1.3 billion and $494.0 million, respectively. There were no unrealized gains or losses recognized for these securities during the three and six months ended January 31, 2025 and 2024.


## us-gaap:FinancingReceivablesTextBlock

[0001327567-25-000010:notes:49]
Financing Receivables
The following table summarizes our short-term and long-term financing receivables as of January 31, 2025 and July 31, 2024 (in millions):

[0001327567-25-000010:notes:50]
|  | January 31, 2025 |  | July 31, 2024 |
| Short-term financing receivables, gross | $ | 859.7 |  |  | $ | 830.2 |  |
| Unearned income | (99.0) |  |  | (95.7) |  |
| Allowance for credit losses | (5.8) |  |  | (8.6) |  |
| Short-term financing receivables, net | $ | 754.9 |  |  | $ | 725.9 |  |
| Long-term financing receivables, gross | $ | 1,263.0 |  |  | $ | 1,286.4 |  |
| Unearned income | (89.6) |  |  | (94.6) |  |
| Allowance for credit losses | (9.6) |  |  | (9.7) |  |
| Long-term financing receivables, net | $ | 1,163.8 |  |  | $ | 1,182.1 |  |

[0001327567-25-000010:notes:51]
[same as prior period, unchanged from 0001327567-24-000040:notes:47]

[0001327567-25-000010:notes:52]
| Internal Risk Rating(1) |  | January 31, 2025 |  | July 31, 2024 |
|  | Fiscal Year of Origination |  |  |  | Fiscal Year of Origination |  |  |
|  | 2025 |  | 2024 |  | 2023 |  | 2022 |  | 2021 |  | Total |  | 2024 |  | 2023 |  | 2022 |  | 2021 |  | Total |
| 1 to 4 |  | $ | 45.3 |  |  | $ | 867.3 |  |  | $ | 354.8 |  |  | $ | 9.2 |  |  | $ | 21.5 |  |  | $ | 1,298.1 |  |  | $ | 885.9 |  |  | $ | 477.3 |  |  | $ | 14.7 |  |  | $ | 44.4 |  |  | $ | 1,422.3 |  |
| 5 to 6 |  | 156.0 |  |  | 326.9 |  |  | 121.9 |  |  | — |  |  | 1.1 |  |  | 605.9 |  |  | 272.2 |  |  | 172.0 |  |  | 21.1 |  |  | 1.1 |  |  | 466.4 |  |
| 7 to 10 |  | 0.1 |  |  | 2.1 |  |  | 18.3 |  |  | 0.3 |  |  | 9.3 |  |  | 30.1 |  |  | 3.2 |  |  | 25.0 |  |  | 0.3 |  |  | 9.1 |  |  | 37.6 |  |
| Amortized cost basis of financing receivables |  | $ | 201.4 |  |  | $ | 1,196.3 |  |  | $ | 495.0 |  |  | $ | 9.5 |  |  | $ | 31.9 |  |  | $ | 1,934.1 |  |  | $ | 1,161.3 |  |  | $ | 674.3 |  |  | $ | 36.1 |  |  | $ | 54.6 |  |  | $ | 1,926.3 |  |

[0001327567-25-000010:notes:53]
[same as prior period, unchanged from 0001327567-24-000040:notes:49]

[0001327567-25-000010:notes:54]
There was no significant activity in allowance for credit losses during the three and six months ended January 31, 2025 and 2024. Past due amounts on financing receivables were not material as of January 31, 2025 and July 31, 2024.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001327567-25-000010:notes:55]
[same as prior period, unchanged from 0001327567-24-000040:notes:51]

[0001327567-25-000010:notes:56]
As of January 31, 2025 and July 31, 2024, the total notional amount of our outstanding foreign currency forward contracts designated as cash flow hedges was $1.0 billion and $804.8 million, respectively. Refer to Note 3. Fair Value Measurements for the fair value of our derivative instruments as reported on our condensed consolidated balance sheets as of January 31, 2025 and July 31, 2024.

[0001327567-25-000010:notes:57]
As of January 31, 2025, unrealized gains and losses in accumulated other comprehensive income (“AOCI”) related to our cash flow hedges were a $16.0 million net loss, of which $14.1 million in losses are expected to be recognized into earnings within the next 12 months. As of July 31, 2024, unrealized gains and losses in AOCI related to our cash flow hedges were a $10.6 million net loss.

[0001327567-25-000010:notes:58]
As of January 31, 2025 and July 31, 2024, the notional amount of our outstanding foreign currency forward contracts not designated as hedging instruments was $567.2 million and $375.6 million, respectively.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001327567-25-000010:notes:59]
[same as prior period, unchanged from 0001327567-24-000040:notes:55]

[0001327567-25-000010:notes:60]
[same as prior period, unchanged from 0001327567-24-000040:notes:56]

[0001327567-25-000010:notes:61]
[same as prior period, unchanged from 0001327567-24-000040:notes:57]

[0001327567-25-000010:notes:62]
As part of the acquisition, we agreed to make post-closing payments to IBM contingent upon customers entering into qualified new transactions through June 30, 2028. We also expect to receive a return of purchase consideration of $6.3 million due to timing of transition of certain underlying customer contracts, of which $0.5 million was received during the three and six months ended January 31, 2025. In addition, we have entered into a transition services arrangement with IBM, under which IBM will perform certain services supporting the acquired assets and customers for a limited period of time.

[0001327567-25-000010:notes:63]
[same as prior period, unchanged from 0001327567-24-000040:notes:59]

[0001327567-25-000010:notes:64]
[same as prior period, unchanged from 0001327567-24-000040:notes:60]

[0001327567-25-000010:notes:65]
[same as prior period, unchanged from 0001327567-24-000040:notes:61]

[0001327567-25-000010:notes:66]
[same as prior period, unchanged from 0001327567-24-000040:notes:62]

[0001327567-25-000010:notes:67]
[same as prior period, unchanged from 0001327567-24-000040:notes:63]

[0001327567-25-000010:notes:68]
[same as prior period, unchanged from 0001327567-24-000040:notes:64]

[0001327567-25-000010:notes:69]
[same as prior period, unchanged from 0001327567-24-000040:notes:65]

[0001327567-25-000010:notes:70]
[same as prior period, unchanged from 0001327567-24-000040:notes:66]


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001327567-25-000010:notes:71]
[same as prior period, unchanged from 0001327567-24-000040:notes:67]

[0001327567-25-000010:notes:72]
The following table presents details of our goodwill during the six months ended January 31, 2025 (in millions):

[0001327567-25-000010:notes:73]
|  | Amount |
| Balance as of July 31, 2024 | $ | 3,350.1 |  |
| Goodwill acquired | 700.7 |  |
| Balance as of January 31, 2025 | $ | 4,050.8 |  |

[0001327567-25-000010:notes:74]
[same as prior period, unchanged from 0001327567-24-000040:notes:70]

[0001327567-25-000010:notes:75]
The following table presents details of our purchased intangible assets as of January 31, 2025 and July 31, 2024 (in millions):

[0001327567-25-000010:notes:76]
|  | January 31, 2025 |  | July 31, 2024 |
|  | Gross Carrying Amount |  | Accumulated Amortization |  | Net Carrying Amount |  | Gross Carrying Amount |  | Accumulated Amortization |  | Net Carrying Amount |
| Intangible assets subject to amortization: |  |  |  |  |  |  |  |  |  |  |  |
| Developed technology | $ | 825.9 |  |  | $ | (584.3) |  |  | $ | 241.6 |  |  | $ | 813.9 |  |  | $ | (526.2) |  |  | $ | 287.7 |  |
| Customer relationships | 636.7 |  |  | (122.5) |  |  | 514.2 |  |  | 172.7 |  |  | (96.1) |  |  | 76.6 |  |
| Acquired intellectual property | 24.3 |  |  | (8.9) |  |  | 15.4 |  |  | 18.2 |  |  | (7.9) |  |  | 10.3 |  |
| Trade name and trademarks | 9.4 |  |  | (9.4) |  |  | — |  |  | 9.4 |  |  | (9.4) |  |  | — |  |
| Other | 0.9 |  |  | (0.7) |  |  | 0.2 |  |  | 0.9 |  |  | (0.6) |  |  | 0.3 |  |
| Total purchased intangible assets | $ | 1,497.2 |  |  | $ | (725.8) |  |  | $ | 771.4 |  |  | $ | 1,015.1 |  |  | $ | (640.2) |  |  | $ | 374.9 |  |

[0001327567-25-000010:notes:77]
We recognized amortization expense of $44.3 million and $85.6 million for the three and six months ended January 31, 2025, respectively, and $28.4 million and $53.3 million for the three and six months ended January 31, 2024, respectively.

[0001327567-25-000010:notes:78]
The following table summarizes estimated future amortization expense of our intangible assets subject to amortization as of January 31, 2025 (in millions):

[0001327567-25-000010:notes:79]
|  |  |  | Fiscal years ending July 31, |
|  | Total |  | Remaining 2025 |  | 2026 |  | 2027 |  | 2028 |  | 2029 |  | 2030 and Thereafter |
| Future amortization expense | $ | 771.4 |  |  | $ | 80.6 |  |  | $ | 141.6 |  |  | $ | 110.7 |  |  | $ | 89.9 |  |  | $ | 63.9 |  |  | $ | 284.7 |  |


## us-gaap:DebtDisclosureTextBlock

[0001327567-25-000010:notes:80]
Debt
Convertible Senior Notes

[0001327567-25-000010:notes:81]
In June 2020, we issued $2.0 billion aggregate principal amount of 0.375% Convertible Senior Notes due 2025 (the “2025 Notes”). The 2025 Notes bear interest at a fixed rate of 0.375% per year, payable semi-annually in arrears on June 1 and December 1 of each year, beginning on December 1, 2020. The 2025 Notes are governed by an indenture between us, as the issuer, and U.S. Bank National Association, as Trustee (the “Indenture”). The 2025 Notes are unsecured, unsubordinated obligations and the Indenture governing the 2025 Notes does not contain any financial covenants or restrictions on the payments of dividends, the incurrence of indebtedness, or the issuance or repurchase of securities by us or any of our subsidiaries. The 2025 Notes mature on June 1, 2025. We may redeem for cash all or any portion of the 2025 Notes, at our option, on or after June 5, 2023 and prior to the 31st scheduled trading day immediately preceding the maturity date if the last reported sale price of our common stock has been at least 130% of the conversion price then in effect for at least 20 trading days during any 30 consecutive trading day period ending on and including the trading day preceding the date on which we provide notice of redemption. The redemption will be at a price equal to 100% of the principal amount of the 2025 Notes and adjusted for interest. If we call any or all of the 2025 Notes for redemption, holders may convert such 2025 Notes called for redemption at any time prior to the close of business on the second scheduled trading day immediately preceding the redemption date.

[0001327567-25-000010:notes:82]
The 2025 Notes are convertible for an initial 40.3 million shares of our common stock at a conversion rate of approximately 20.1612 shares of common stock per $1,000 principal amount, which is equal to an initial conversion price of approximately $49.60 per share of common stock, subject to adjustments. Holders of the 2025 Notes may surrender their 2025 Notes for conversion at their option at any time prior to the close of business on the business day immediately preceding March 1, 2025 only under the following circumstances:

[0001327567-25-000010:notes:83]
•during any fiscal quarter commencing after the fiscal quarters ending on October 31, 2020 (and only during such fiscal quarter), if the last reported sale price of our common stock for at least 20 trading days (whether or not consecutive) during a period of 30 consecutive trading days ending on the last trading day of the immediately preceding fiscal quarter is greater than or equal to 130% of the conversion price for the 2025 Notes on each applicable trading day (the “sale price condition”);

[0001327567-25-000010:notes:84]
•during the five business day period after any five consecutive trading day period (the “measurement period”) in which the trading price per $1,000 principal amount of the 2025 Notes for each trading day of the measurement period was less than 98% of the product of the last reported sale price of our common stock and the conversion rate for the 2025 Notes on each such trading day; or

[0001327567-25-000010:notes:85]
•upon the occurrence of specified corporate events.

[0001327567-25-000010:notes:86]
On or after March 1, 2025, holders may surrender all or any portion of their 2025 Notes for conversion at any time prior to the close of business on the second scheduled trading day immediately preceding the maturity date regardless of the foregoing conditions, and such conversions will be settled upon the maturity date. Upon conversion, holders of the 2025 Notes will receive cash equal to the aggregate principal amount of the 2025 Notes to be converted, and, at our election, cash and/or shares of our common stock for any amounts in excess of the aggregate principal amount of the 2025 Notes being converted.

[0001327567-25-000010:notes:87]
The conversion price will be subject to adjustment in some events. Holders of the 2025 Notes who convert their 2025 Notes in connection with certain corporate events that constitute a “make-whole fundamental change” under the Indenture are, under certain circumstances, entitled to an increase in the conversion rate. Additionally, upon the occurrence of a corporate event that constitutes a “fundamental change” under the Indenture, holders of the 2025 Notes may require us to repurchase for cash all or a portion of the 2025 Notes at a repurchase price equal to 100% of the principal amount of the 2025 Notes plus accrued and unpaid interest to, but excluding, the fundamental change repurchase date.

[0001327567-25-000010:notes:88]
Holders of the 2025 Notes were able to early convert their 2025 Notes during the fiscal quarter ended January 31, 2025 as the sales price condition had been met during the fiscal quarter ended October 31, 2024. During the three and six months ended January 31, 2025, holders of the 2025 Notes converted $112.4 million and $431.4 million, respectively, in aggregate principal amount of the 2025 Notes, which we repaid in cash. We also issued 1.7 million and 6.2 million shares of our common stock to the holders of the 2025 Notes during the three and six months ended January 31, 2025, respectively, for the conversion value in excess of the principal amount. During the three and six months ended January 31, 2024, holders of the 2025 Notes converted $126.3 million and $172.3 million, respectively, in aggregate principal amount of the 2025 Notes, which we repaid in cash. We also issued 1.7 million and 2.2 million shares of our common stock to the holders of the 2025 Notes during the three and six months ended January 31, 2024, respectively, for the conversion value in excess of the principal amount. These shares were fully offset by shares we received from the corresponding exercise of the note hedges. Refer to Note 16. Subsequent Events for additional information regarding conversion of the 2025 Notes after January 31, 2025 through the filing date of this Quarterly Report on Form 10-Q.

[0001327567-25-000010:notes:89]
The sale price condition for the 2025 Notes was met during the fiscal quarter ended January 31, 2025 and, as a result, holders may convert their 2025 Notes during the fiscal quarter ending April 30, 2025 at any time prior to the close of business on the business day immediately preceding March 1, 2025 for settlement prior to the maturity date. The net carrying amount of the 2025 Notes was classified as a current liability on our condensed consolidated balance sheet as of January 31, 2025.

[0001327567-25-000010:notes:90]
The following table sets forth the net carrying amount of our 2025 Notes (in millions):

[0001327567-25-000010:notes:91]
|  | January 31, 2025 |  | July 31, 2024 |
| Principal | $ | 534.2 |  |  | $ | 965.6 |  |
| Less: debt issuance costs, net of amortization | (0.4) |  |  | (1.7) |  |
| Net carrying amount | $ | 533.8 |  |  | $ | 963.9 |  |

[0001327567-25-000010:notes:92]
The total estimated fair value of the 2025 Notes was $2.0 billion as of January 31, 2025 and $3.2 billion as of July 31, 2024. The fair value was determined based on the closing trading price per $100 of the 2025 Notes as of the last day of trading for the period. We consider the fair value of the 2025 Notes as of January 31, 2025 and July 31, 2024 to be a Level 2 measurement. The fair value of the 2025 Notes is primarily affected by the trading price of our common stock and market interest rates.

[0001327567-25-000010:notes:93]
The following table sets forth interest expense recognized related to the 2025 Notes (dollars in millions):

[0001327567-25-000010:notes:94]
|  | Three Months Ended January 31, |  | Six Months Ended January 31, |
|  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Contractual interest expense | $ | 0.6 |  |  | $ | 1.7 |  |  | $ | 1.3 |  |  | $ | 3.6 |  |
| Amortization of debt issuance costs | 0.3 |  |  | 1.1 |  |  | 0.8 |  |  | 2.1 |  |
| Total interest expense | $ | 0.9 |  |  | $ | 2.8 |  |  | $ | 2.1 |  |  | $ | 5.7 |  |
| Effective interest rate | 0.6 | % |  | 0.6 | % |  | 0.6 | % |  | 0.6 | % |

[0001327567-25-000010:notes:95]
Note Hedges

[0001327567-25-000010:notes:96]
To minimize the impact of potential economic dilution upon conversion of our convertible senior notes, we entered into separate convertible note hedge transactions (the “2025 Note Hedges”) with respect to our common stock concurrent with the issuance of the 2025 Notes.

[0001327567-25-000010:notes:97]
The 2025 Note Hedges cover up to 40.3 million shares of our common stock at a strike price per share that corresponds to the initial conversion price of the 2025 Notes, which are also subject to adjustment, and are exercisable upon conversion of the 2025 Notes. The 2025 Note Hedges will expire upon maturity of the 2025 Notes. The 2025 Note Hedges are separate transactions and are not part of the terms of the 2025 Notes. Holders of the 2025 Notes will not have any rights with respect to the 2025 Note Hedges. Any shares of our common stock receivable by us under the 2025 Note Hedges are excluded from the calculation of diluted earnings per share as they are antidilutive. We paid an aggregate amount of $370.8 million for the 2025 Note Hedges, which is included in additional paid-in capital on our condensed consolidated balance sheets.

[0001327567-25-000010:notes:98]
As a result of the conversions of the 2025 Notes settled during the three and six months ended January 31, 2025, we exercised the corresponding portion of our 2025 Note Hedges and received 1.7 million and 6.2 million shares of our common stock during the respective periods. As a result of the conversions of the 2025 Notes settled during the three and six months ended January 31, 2024, we exercised the corresponding portion of our 2025 Note Hedges and received 1.7 million and 2.2 million shares of our common stock during the respective periods.

[0001327567-25-000010:notes:99]
Warrants

[0001327567-25-000010:notes:100]
Separately, but concurrently with the issuance of each series of our convertible senior notes, we entered into transactions whereby we sold warrants (the “2023 Warrants,” with respect to the 0.75% convertible senior notes due 2023 issued in July 2018, the “2025 Warrants,” with respect to the 2025 Notes, and the 2023 Warrants together with the 2025 Warrants, the “Warrants”) to acquire shares of our common stock, subject to anti-dilution adjustments. The 2023 Warrants and 2025 Warrants are exercisable over 60 scheduled trading days beginning October 2023 and September 2025, respectively.

[0001327567-25-000010:notes:101]
The following table presents details of our Warrants (in millions, except per share data):

[0001327567-25-000010:notes:102]
|  | Initial Number of Shares |  | Strike Price per Share |  | Aggregate Proceeds |
| 2023 Warrants (1) | 38.1 |  |  | $ | 69.63 |  |  | $ | 145.4 |  |
| 2025 Warrants | 40.3 |  |  | $ | 68.08 |  |  | $ | 202.8 |  |

[0001327567-25-000010:notes:103]
(1)The 2023 Warrants were net settled during the 60 scheduled trading days from October to December 2023.

[0001327567-25-000010:notes:104]
The shares issuable under the Warrants are included in the calculation of diluted earnings per share when the average market value per share of our common stock for the reporting period exceeds the applicable strike price for such series of Warrants. The Warrants are separate transactions and are not part of either series of Notes or Note Hedges and are not remeasured through earnings each reporting period. Holders of the Notes of either series will not have any rights with respect to the Warrants. The aggregate proceeds received from the sale of the Warrants are included in additional paid-in capital on our condensed consolidated balance sheets.

[0001327567-25-000010:notes:105]
During the six months ended January 31, 2024, we net settled all of the 2023 Warrants with 18.0 million shares of our common stock with a fair value of $2.4 billion, of which 11.9 million shares of our common stock with a fair value of $1.7 billion were net settled during the three months ended January 31, 2024. The number of net shares issued was determined based on the number of 2023 Warrants exercised multiplied by the difference between the strike price of the 2023 Warrants and their daily volume-weighted-average stock price.

[0001327567-25-000010:notes:106]
Revolving Credit Facility

[0001327567-25-000010:notes:107]
On April 13, 2023, we entered into a credit agreement (the “Credit Agreement”) with certain institutional lenders that provides for a $400.0 million unsecured revolving credit facility (the “Credit Facility”), with an option to increase the amount of the Credit Facility by up to an additional $350.0 million, subject to certain conditions. The Credit Facility matures on April 13, 2028.

[0001327567-25-000010:notes:108]
The borrowings under the Credit Facility bear interest, at our option, at a base rate plus a spread of 0.000% to 0.375%, or an adjusted term Secured Overnight Financing Rate (“SOFR”) plus a spread of 1.000% to 1.375%, in each case with such spread being determined based on our leverage ratio. We are obligated to pay an ongoing commitment fee on undrawn amounts at a rate of 0.090% to 0.150%, depending on our leverage ratio. The interest rates and commitment fees are also subject to upward and downward adjustments based on our progress towards the achievement of certain sustainability goals related to greenhouse gas emissions.

[0001327567-25-000010:notes:109]
As of January 31, 2025, there were no amounts outstanding and we were in compliance with all covenants under the Credit Agreement.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001327567-25-000010:notes:110]
Commitments and Contingencies
Purchase Commitments

[0001327567-25-000010:notes:111]
We have entered into various non-cancelable agreements with cloud service providers, under which we are committed to minimum or fixed purchases of certain cloud services. In addition, in order to reduce manufacturing lead times and plan for adequate supply, we have entered into agreements with manufacturing partners and component suppliers to procure inventory based on our demand forecasts. The following table presents details of the aggregate future non-cancelable purchase commitments under these agreements as of January 31, 2025 (in millions):

[0001327567-25-000010:notes:112]
|  |  |  | Fiscal years ending July 31, |
|  | Total |  | Remaining 2025 |  | 2026 |  | 2027 |  | 2028 |  | 2029 |  | 2030 and Thereafter |
| Cloud | $ | 3,921.4 |  |  | $ | 47.3 |  |  | $ | 277.6 |  |  | $ | 518.1 |  |  | $ | 599.6 |  |  | $ | 686.1 |  |  | $ | 1,792.7 |  |
| Manufacturing | 199.4 |  |  | 110.2 |  |  | 89.2 |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Other | 152.8 |  |  | 26.0 |  |  | 59.8 |  |  | 53.3 |  |  | 6.8 |  |  | 3.4 |  |  | 3.5 |  |
| Total purchase commitments | $ | 4,273.6 |  |  | $ | 183.5 |  |  | $ | 426.6 |  |  | $ | 571.4 |  |  | $ | 606.4 |  |  | $ | 689.5 |  |  | $ | 1,796.2 |  |

[0001327567-25-000010:notes:113]
Additionally, we have a $132.7 million minimum purchase commitment with a cloud service provider through September 2027 with no specified annual commitments.

[0001327567-25-000010:notes:114]
Litigation

[0001327567-25-000010:notes:115]
We are subject to legal proceedings, claims, tax matters, and litigation arising in the ordinary course of business, including, for instance, intellectual property and patent litigation. We accrue for contingencies when we believe that a loss is probable and that we can reasonably estimate the amount of any such loss.

[0001327567-25-000010:notes:116]
Legal matters could include speculative, substantial, or indeterminate monetary amounts. Significant judgment is required to determine both the likelihood of there being a loss and the estimated amount of a loss related to such matters, and we may be unable to estimate the reasonably possible loss or range of loss. The outcomes of outstanding legal matters are inherently unpredictable, and could, either individually or in aggregate, have a material adverse effect on us and our results of operations. To the extent there is a reasonable possibility that a loss exceeding any amounts already recognized may be incurred, we will either disclose the estimated additional loss or state that such an estimate cannot be made.

[0001327567-25-000010:notes:117]
The following matters arose in the ordinary course of business.

[0001327567-25-000010:notes:118]
Centripetal Networks, Inc. v. Palo Alto Networks

[0001327567-25-000010:notes:119]
On March 12, 2021, Centripetal Networks, Inc., filed a lawsuit against us in the United States District Court for the Eastern District of Virginia. The lawsuit alleges that our products infringe multiple Centripetal patents. We successfully challenged certain of these patents, which were found unpatentable by the U.S. Patent and Trademark Office (“PTO”). The case went to jury trial on January 22, 2024, on four patents. On January 31, 2024, the jury returned a verdict of non-willful infringement with a lump sum amount of $151.5 million, plus statutory interest. After post-trial motions, a judgment was issued on October 3, 2024 affirming infringement on three patents, reversing infringement on the fourth patent, and subsequently, reducing the damages amount to $113.6 million. We posted a surety bond that was agreed upon by the parties and approved by the court. This bond prevents execution of the judgment while appeals are pending. In addition, Centripetal filed infringement contentions on certain of their patents in the European Patent Office in Germany, to which we filed invalidity challenges. Those matters are still pending.

[0001327567-25-000010:notes:120]
As of July 31, 2024, we accrued $184.4 million for the verdict amount and estimated interest. As of January 31, 2025, we accrued $142.8 million based on the judgment and estimated interest, which is recorded in other long-term liabilities on our condensed consolidated balance sheets. The corresponding amount was a charge of $1.4 million for the three months ended January 31, 2025, and a release of $41.6 million for the six months ended January 31, 2025, which is included in general and administrative expense on our condensed consolidated statements of operations.

[0001327567-25-000010:notes:121]
Finjan, Inc. v. Palo Alto Networks
On November 4, 2014, Finjan, Inc., filed a lawsuit against us in the United States District Court for the Northern District of California. The lawsuit alleges that our products infringe multiple Finjan patents. The complaint requests injunctive relief, monetary damages, and attorneys fees. A trial date is set for June 9, 2025. We are unable, at this time, to reasonably estimate a possible loss or potential range of loss, if any.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001327567-25-000010:notes:122]
[same as prior period, unchanged from 0001327567-24-000040:notes:119]

[0001327567-25-000010:notes:123]
[same as prior period, unchanged from 0001327567-24-000040:notes:120]

[0001327567-25-000010:notes:124]
We did not repurchase shares of our common stock during the three and six months ended January 31, 2025. During the six months ended January 31, 2024, we repurchased and retired 0.6 million shares of our common stock under our current repurchase authorization for an aggregate purchase price of $66.7 million, including transaction costs, at an average price of $113.34 per share.

[0001327567-25-000010:notes:125]
As of January 31, 2025, $1.0 billion remained available for future share repurchases under our current repurchase authorization. The total price of the shares repurchased and related transaction costs are reflected as a reduction to common stock and additional paid-in capital on our condensed consolidated balance sheets.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001327567-25-000010:notes:126]
[same as prior period, unchanged from 0001327567-24-000040:notes:123]

[0001327567-25-000010:notes:127]
The following table summarizes the RSU and PSU activity under our stock plans during the six months ended January 31, 2025 (in millions, except per share amounts):

[0001327567-25-000010:notes:128]
|  | Unvested RSUs |  | Unvested PSUs |
|  | Number of Shares |  | Weighted-Average Grant-Date Fair Value Per Share |  |  |  | Aggregate Intrinsic Value |  | Number of Shares |  | Weighted-Average Grant-Date Fair Value Per Share |  |  |  | Aggregate Intrinsic Value |
| Balance—July 31, 2024 | 18.0 |  |  | $ | 102.59 |  |  |  |  | $ | 2,924.4 |  |  | 10.0 |  |  | $ | 77.95 |  |  |  |  | $ | 1,624.2 |  |
| Granted(1) | 4.2 |  |  | $ | 190.52 |  |  |  |  |  |  | 3.8 |  |  | $ | 201.59 |  |  |  |  |  |
| Vested(2) | (4.8) |  |  | $ | 86.49 |  |  |  |  |  |  | (1.1) |  |  | $ | 64.76 |  |  |  |  |  |
| Forfeited | (1.1) |  |  | $ | 106.64 |  |  |  |  |  |  | (3.2) |  |  | $ | 91.47 |  |  |  |  |  |
| Balance—January 31, 2025 | 16.3 |  |  | $ | 130.05 |  |  |  |  | $ | 3,000.4 |  |  | 9.5 |  |  | $ | 140.37 |  |  |  |  | $ | 1,758.0 |  |

[0001327567-25-000010:notes:129]
[same as prior period, unchanged from 0001327567-24-000040:notes:126]

[0001327567-25-000010:notes:130]
[same as prior period, unchanged from 0001327567-24-000040:notes:127]

[0001327567-25-000010:notes:131]
[same as prior period, unchanged from 0001327567-24-000040:notes:128]

[0001327567-25-000010:notes:132]
[same as prior period, unchanged from 0001327567-24-000040:notes:129]

[0001327567-25-000010:notes:133]
During the six months ended January 31, 2025, we granted 3.4 million shares of PSUs that contain service, performance, and market conditions, of which 0.1 million shares were granted during the three months ended January 31, 2025. The service conditions are satisfied after a period of one to three years. The performance conditions are based on an average of next-generation security annualized recurring revenue and non-GAAP net income per diluted share. The market condition is measured based on our total shareholder return (“TSR”) relative to the TSR of the companies listed in the Standard & Poor’s 500 index. As of January 31, 2025, we have approved 2.7 million shares of PSUs, which will be granted upon the performance condition being established during the next two fiscal years.

[0001327567-25-000010:notes:134]
The fair value of the PSUs subject to market conditions is estimated on the grant date using a Monte Carlo simulation model. The following table summarizes the assumptions used and the resulting grant-date fair value of our PSUs subject to market conditions granted during the three and six months ended January 31, 2025 and 2024:

[0001327567-25-000010:notes:135]
|  | Three Months Ended January 31, |  | Six Months Ended January 31, |
|  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Volatility | 43.5% - 43.9% |  | 40.9% |  | 43.5% - 47.6% |  | 40.8% - 43.4% |
| Expected term (in years) | 1.7 - 2.7 |  | 2.7 |  | 1.0 - 2.9 |  | 0.9 - 2.9 |
| Dividend yield | 0.0 | % |  | 0.0 | % |  | 0.0 | % |  | 0.0 | % |
| Risk-free interest rate | 4.2% |  | 4.5% |  | 3.7% - 4.5% |  | 4.5% - 5.3% |
| Grant-date fair value per share | $287.98 - $291.91 |  | $174.02 |  | $264.51 - $305.83 |  | $173.46 - $197.32 |

[0001327567-25-000010:notes:136]
[same as prior period, unchanged from 0001327567-24-000040:notes:133]

[0001327567-25-000010:notes:137]
We have granted PSOs with both service and market conditions. The market conditions were achieved when certain stock price targets were met. As of January 31, 2025, all of our outstanding PSOs have been fully vested. The maximum contractual term of our outstanding PSOs is seven and a half years from the date of grant in fiscal year 2018 and 2019.

[0001327567-25-000010:notes:138]
The following table summarizes the PSO activity under our stock plans during the six months ended January 31, 2025 (in millions, except per share amounts):

[0001327567-25-000010:notes:139]
|  |  |  |  |  |  |  |  |  | Number of Shares |  | Weighted-Average Exercise Price Per Share |  | Weighted-Average Remaining Contractual Term (Years) |  | Aggregate Intrinsic Value |
| Balance—July 31, 2024 |  |  |  |  |  |  |  |  | 9.6 |  |  | $ | 32.66 |  |  | 1.2 |  | $ | 1,244.9 |  |
| Exercised |  |  |  |  |  |  |  |  | (5.3) |  |  | $ | 32.49 |  |  |  |  |  |
| Balance—January 31, 2025 |  |  |  |  |  |  |  |  | 4.3 |  |  | $ | 32.87 |  |  | 0.8 |  | $ | 654.1 |  |
| Exercisable—January 31, 2025 |  |  |  |  |  |  |  |  | 4.3 |  |  | $ | 32.87 |  |  | 0.8 |  | $ | 654.1 |  |

[0001327567-25-000010:notes:140]
[same as prior period, unchanged from 0001327567-24-000040:notes:137]

[0001327567-25-000010:notes:141]
[same as prior period, unchanged from 0001327567-24-000040:notes:138]

[0001327567-25-000010:notes:142]
|  | Three Months Ended January 31, |  | Six Months Ended January 31, |
|  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Cost of product revenue | $ | 1.3 |  |  | $ | 2.3 |  |  | $ | 2.6 |  |  | $ | 4.7 |  |
| Cost of subscription and support revenue | 32.3 |  |  | 30.7 |  |  | 62.7 |  |  | 61.3 |  |
| Research and development | 139.6 |  |  | 138.6 |  |  | 277.4 |  |  | 258.7 |  |
| Sales and marketing | 90.2 |  |  | 75.6 |  |  | 166.6 |  |  | 154.8 |  |
| General and administrative | 57.1 |  |  | 28.1 |  |  | 105.5 |  |  | 66.8 |  |
| Total share-based compensation | $ | 320.5 |  |  | $ | 275.3 |  |  | $ | 614.8 |  |  | $ | 546.3 |  |

[0001327567-25-000010:notes:143]
As of January 31, 2025, total compensation cost related to unvested share-based awards not yet recognized was $2.5 billion. This cost is expected to be amortized over a weighted-average period of approximately 2.6 years.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001327567-25-000010:notes:144]
Income Taxes
For the three and six months ended January 31, 2025, our provision for income taxes reflected effective tax rates of 17.7% and 10.9%, respectively. Our income taxes for the three and six months ended January 31, 2025 were primarily due to U.S. and foreign income taxes. Our effective tax rate for the three and six months ended January 31, 2025 differed from the U.S. statutory tax rate primarily due to excess tax benefits from share-based compensation.

[0001327567-25-000010:notes:145]
For the three and six months ended January 31, 2024, our benefit from income taxes reflected an effective tax rate of negative 1,189.2% and negative 364.3%, respectively. Our effective tax rate for the three and six months ended January 31, 2024 differed from the U.S. statutory tax rate primarily due to the release of our valuation allowance on U.S. federal, U.S. states other than California, and United Kingdom (“U.K.”) deferred tax assets.
As a result of the valuation allowance release, during the three and six months ended January 31, 2024, we recognized a deferred tax benefit of $3.2 billion for the U.S. federal, U.S. states other than California, and U.K. deferred tax assets. In addition, during the three and six months ended January 31, 2024, we recognized a deferred tax expense of $1.7 billion for the U.S. federal indirect tax effect of foreign deferred taxes consistent with our policy to record deferred taxes for basis differences relating to our global intangible low-taxed income. Accordingly, during the three and six months ended January 31, 2024, we recognized a net tax benefit of $1.5 billion relating to our valuation allowance release.


## us-gaap:EarningsPerShareTextBlock

[0001327567-25-000010:notes:146]
[same as prior period, unchanged from 0001327567-24-000040:notes:144]

[0001327567-25-000010:notes:147]
[same as prior period, unchanged from 0001327567-24-000040:notes:145]

[0001327567-25-000010:notes:148]
|  | Three Months Ended January 31, |  | Six Months Ended January 31, |
|  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Net income | $ | 267.3 |  |  | $ | 1,746.9 |  |  | $ | 618.0 |  |  | $ | 1,941.1 |  |
| Weighted-average shares used to compute net income per share, basic | 659.3 |  |  | 639.3 |  |  | 656.5 |  |  | 629.7 |  |
| Weighted-average effect of potentially dilutive securities: |  |  |  |  |  |  |  |
| Convertible senior notes | 8.7 |  |  | 25.9 |  |  | 10.3 |  |  | 24.6 |  |
| Warrants related to the issuance of convertible senior notes | 25.8 |  |  | 25.3 |  |  | 25.2 |  |  | 28.6 |  |
| Employee equity incentive plans | 15.2 |  |  | 24.5 |  |  | 17.1 |  |  | 24.4 |  |
| Weighted-average shares used to compute net income per share, diluted | 709.0 |  |  | 715.0 |  |  | 709.1 |  |  | 707.3 |  |
| Net income per share, basic | $ | 0.41 |  |  | $ | 2.73 |  |  | $ | 0.94 |  |  | $ | 3.08 |  |
| Net income per share, diluted | $ | 0.38 |  |  | $ | 2.44 |  |  | $ | 0.87 |  |  | $ | 2.74 |  |

[0001327567-25-000010:notes:149]
[same as prior period, unchanged from 0001327567-24-000040:notes:147]

[0001327567-25-000010:notes:150]
|  | Three Months Ended January 31, |  | Six Months Ended January 31, |
|  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Employee equity incentive plans | 6.3 |  |  | 4.7 |  |  | 4.8 |  |  | 4.9 |  |


## us-gaap:OtherNonoperatingIncomeAndExpenseTextBlock

[0001327567-25-000010:notes:151]
[same as prior period, unchanged from 0001327567-24-000040:notes:149]

[0001327567-25-000010:notes:152]
|  | Three Months Ended January 31, |  | Six Months Ended January 31, |
|  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Interest income | $ | 86.9 |  |  | $ | 85.3 |  |  | $ | 172.6 |  |  | $ | 156.5 |  |
| Foreign currency exchange gains (losses), net | 2.4 |  |  | (6.5) |  |  | (5.1) |  |  | (1.4) |  |
| Other, net | (4.0) |  |  | 5.9 |  |  | 1.1 |  |  | (0.1) |  |
| Total other income, net | $ | 85.3 |  |  | $ | 84.7 |  |  | $ | 168.6 |  |  | $ | 155.0 |  |


## us-gaap:SubsequentEventsTextBlock

[0001327567-25-000010:notes:153]
Subsequent Events
2025 Notes Conversion

[0001327567-25-000010:notes:154]
Subsequent to January 31, 2025, $100.4 million in aggregate principal amount of the 2025 Notes was converted or had been submitted by the holders for conversion and will settle during the fiscal quarter ending April 30, 2025.


## ecd:MtrlTermsOfTrdArrTextBlock

[0001327567-25-000010:notes:155]
Set forth below is certain information regarding Rule 10b5-1 trading plans adopted or terminated by our directors and officers (as defined in Rule 16a-1(f)) during the second quarter of fiscal 2025. The Rule 10b5-1 trading plans listed below are each intended to satisfy the affirmative defense of Rule 10b5-1(c).

[0001327567-25-000010:notes:156]
| Name |  | Title |  | Date Plan Was Adopted |  | Date Plan was Terminated |  | Expiration Date |  | Total Amount of Common Stock to be Sold Under the Plan |
| Dipak Golechha |  | Executive Vice President, Chief Financial Officer |  | January 6, 2025 |  | Not applicable |  | March 31, 2026 or, if earlier, when all shares have been sold |  | 20,000 |
| Nir Zuk |  | Executive Vice President, Chief Technology Officer |  | January 9, 2025 |  | Not applicable |  | April 30, 2026 or, if earlier, when all shares have been sold |  | 1,449,828 |
