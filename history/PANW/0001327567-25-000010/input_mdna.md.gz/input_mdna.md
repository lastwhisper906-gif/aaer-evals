# PANW MD&A — 0001327567-25-000010


## mdna

[0001327567-25-000010:mdna:1]
[same as prior period, unchanged from 0001327567-24-000040:mdna:1]

[0001327567-25-000010:mdna:2]
[same as prior period, unchanged from 0001327567-24-000040:mdna:2]

[0001327567-25-000010:mdna:3]
[same as prior period, unchanged from 0001327567-24-000040:mdna:3]

[0001327567-25-000010:mdna:4]
[same as prior period, unchanged from 0001327567-24-000040:mdna:4]

[0001327567-25-000010:mdna:5]
•Results of Operations. A discussion of the nature and trends in our financial results and an analysis of our financial results comparing the three and six months ended January 31, 2025 to the three and six months ended January 31, 2024.

[0001327567-25-000010:mdna:6]
[same as prior period, unchanged from 0001327567-24-000040:mdna:6]

[0001327567-25-000010:mdna:7]
[same as prior period, unchanged from 0001327567-24-000040:mdna:7]

[0001327567-25-000010:mdna:8]
[same as prior period, unchanged from 0001327567-24-000040:mdna:8]

[0001327567-25-000010:mdna:9]
[same as prior period, unchanged from 0001327567-24-000040:mdna:21]

[0001327567-25-000010:mdna:10]
[same as prior period, unchanged from 0001327567-24-000040:mdna:10]

[0001327567-25-000010:mdna:11]
[same as prior period, unchanged from 0001327567-24-000040:mdna:11]

[0001327567-25-000010:mdna:12]
[same as prior period, unchanged from 0001327567-24-000040:mdna:12]

[0001327567-25-000010:mdna:13]
•Our network security platform, designed to deliver complete zero trust solutions to our customers, includes our hardware and software ML-Powered Next-Generation Firewalls, AI Runtime Security, as well as a cloud-delivered Secure Access Service Edge (“SASE”). Prisma® Access, our Security Services Edge (“SSE”) solution, when combined with Prisma SD-WAN, provides a comprehensive single-vendor SASE offering that is used to secure remote workforces and securely enable the cloud-delivered branch. Prisma Access Browser extends SASE security and data protection to the end user device, giving workers complete device freedom to access business applications securely using a secure browser. Our network security platform also includes our cloud-delivered security services, such as Advanced Threat Prevention, Advanced WildFire®, Advanced URL Filtering, Advanced DNS Security, IoT/OT Security, GlobalProtect®, Enterprise Data Loss Prevention (“Enterprise DLP”), AI for IT Operations (“AIOps”), software as a service (“SaaS”) Security, and AI Access Security. Through these add-on security services, our customers are able to secure their content, applications, users, and devices across their entire organization. Strata Cloud Manager, our network security management solution, centrally manages our network security platform irrespective of form factor, location, or scale. Strata Cloud Manager includes the Strata Copilot which provides a natural language interface to simplify and strengthen network security.

[0001327567-25-000010:mdna:14]
[same as prior period, unchanged from 0001327567-24-000040:mdna:14]

[0001327567-25-000010:mdna:15]
[same as prior period, unchanged from 0001327567-24-000040:mdna:15]

[0001327567-25-000010:mdna:16]
[same as prior period, unchanged from 0001327567-24-000040:mdna:16]

[0001327567-25-000010:mdna:17]
•We deliver the next generation of security operations capabilities that unifies standalone Security Information and Event Management (“SIEM”) tools, endpoint security, security automation, cloud detection and response (“CDR”), as well as attack surface management (“ASM”) capabilities on our Cortex platform. These include Cortex XSIAM®, for AI-driven security operations that replaces traditional SIEM tools, Cortex XDR® for the prevention, detection, and response to complex cybersecurity attacks, Cortex XSOAR® for security orchestration, automation, and response (“SOAR”), and Cortex Xpanse® for ASM. These products are delivered as SaaS or software subscriptions.

[0001327567-25-000010:mdna:18]
[same as prior period, unchanged from 0001327567-24-000040:mdna:18]

[0001327567-25-000010:mdna:19]
[same as prior period, unchanged from 0001327567-24-000040:mdna:19]

[0001327567-25-000010:mdna:20]
For the second quarter of fiscal 2025 and 2024, total revenue was $2.3 billion and $2.0 billion, respectively, representing year-over-year growth of 14.3%. Our growth reflects the increased adoption of our portfolio, which consists of product, subscriptions, and support. We believe our portfolio will enable us to benefit from recurring revenues and new revenues as we continue to grow our end-customer base. As of January 31, 2025, we had end-customers in over 180 countries. Our end-customers represent a broad range of industries, including education, energy, financial services, government entities, healthcare, Internet and media, manufacturing, public sector, and telecommunications, and include almost all of the Fortune 100 companies and a majority of the Global 2000 companies. We maintain a field sales force that works closely with our channel partners in developing sales opportunities. We primarily use a two-tiered, indirect fulfillment model whereby we sell our products, subscriptions, and support to our distributors, which, in turn, sell to our resellers, which then sell to our end-customers.

[0001327567-25-000010:mdna:21]
[same as prior period, unchanged from 0001327567-24-000040:mdna:30]

[0001327567-25-000010:mdna:22]
Our product revenue grew to $421.5 million, or 18.7% of total revenue, for the second quarter of fiscal 2025, representing year-over-year growth of 7.9%. Product revenue is derived from sales of our appliances, primarily our ML-Powered Next-Generation Firewall. Product revenue also includes revenue derived from software licenses of Panorama®, SD-WAN, and the VM-Series. Our ML-Powered Next-Generation Firewall incorporates our PAN-OS operating system, which provides a consistent set of capabilities across our entire network security product line. Our appliances and software licenses include a broad set of built-in networking and security features and functionalities. Our products are designed for different performance requirements throughout an organization, ranging from our PA-400 Series, which is designed for small organizations and remote or branch offices, to our top-of-the-line PA-7500, which is designed for large-scale data centers and service provider use. The same firewall functionality that is delivered in our physical appliances is also available in our VM-Series virtual firewalls, which secure virtualized and cloud-based computing environments, and in our CN-Series container firewalls, which secure container environments and traffic.

[0001327567-25-000010:mdna:23]
Our subscription and support revenue grew to $1.8 billion, or 81.3% of total revenue, for the second quarter of fiscal 2025, representing year-over-year growth of 15.9%. Our subscriptions provide our end-customers with near real-time access to the latest intrusion prevention, web security, modern malware prevention, data loss prevention, cloud access security broker and AI security capabilities across the network, endpoints, and the cloud. Our subscriptions also include security operations, which enable customers to leverage the AI-driven Cortex platform for advanced capabilities such as security information and event management, next-generation antivirus, endpoint detection and response, extended detection and response, identity threat detection and response, cloud detection and response, SOAR, as well as ASM. Additionally, we offer MDR for Cortex subscriptions, powered by Unit 42’s elite expertise. When customers purchase our physical, virtual, or container firewall appliances, or certain cloud offerings, they typically purchase support in order to receive ongoing security updates, upgrades, bug fixes, and repairs. In addition to the subscriptions purchased with these appliances, customers may also purchase other subscriptions on a per-user, per-endpoint, or capacity-based basis. We also offer professional services, including incident response, risk management, and digital forensic services.

[0001327567-25-000010:mdna:24]
We continue to invest in innovation as we evolve and further extend the capabilities of our portfolio, as we believe that innovation and timely development of new features and products are essential to meeting the needs of our end-customers and improving our competitive position. For example, in February 2025, we announced Cortex Cloud, the next version of Prisma Cloud, that brings together our CDR and CNAPP capabilities on the unified Cortex platform to provide centralized visibility, AI-driven insights, and end-to-end remediation across the cloud security ecosystem to stop attacks in real time.

[0001327567-25-000010:mdna:25]
[same as prior period, unchanged from 0001327567-24-000040:mdna:25]

[0001327567-25-000010:mdna:26]
[same as prior period, unchanged from 0001327567-24-000040:mdna:26]

[0001327567-25-000010:mdna:27]
Our overall performance depends in part on worldwide economic and geopolitical conditions and their impact on customer behavior. Changes in legislation or regulations and actions by regulators, including changes in enforcement and administration policies, may have an impact on our results of operations and financial condition. Further, worsening economic conditions, including inflation, high interest rates, slow growth, fluctuations in foreign exchange rates, supply chain disruptions, impacts of trade regulations, and other conditions, may adversely affect our results of operations and financial performance.

[0001327567-25-000010:mdna:28]
The hostilities in Israel and the surrounding region have continued to result in economic and political uncertainty. While we have business operations in Israel, and intend to continue growing our presence in Israel, we currently do not expect significant business disruption. We are actively monitoring, evaluating, and responding to the situation.

[0001327567-25-000010:mdna:29]
[same as prior period, unchanged from 0001327567-24-000040:mdna:29]

[0001327567-25-000010:mdna:30]
[same as prior period, unchanged from 0001327567-24-000040:mdna:37]

[0001327567-25-000010:mdna:31]
[same as prior period, unchanged from 0001327567-24-000040:mdna:31]

[0001327567-25-000010:mdna:32]
[same as prior period, unchanged from 0001327567-24-000040:mdna:32]

[0001327567-25-000010:mdna:33]
|  | January 31, 2025 |  | July 31, 2024 |
|  | (in billions) |
| Next-Generation Security Annualized Recurring Revenue | $ | 4.8 |  |  | $ | 4.2 |  |
| Remaining performance obligations | $ | 13.0 |  |  | $ | 12.7 |  |

[0001327567-25-000010:mdna:34]
|  | Three Months Ended January 31, |  | Six Months Ended January 31, |
|  | 2025 |  | 2024 |  | 2025 |  | 2024 |
|  | (dollars in millions) |
| Total revenue | $ | 2,257.4 |  |  | $ | 1,975.1 |  |  | $ | 4,396.2 |  |  | $ | 3,853.2 |  |
| Total revenue year-over-year percentage increase | 14.3 | % |  | 19.3 | % |  | 14.1 | % |  | 19.7 | % |
| Gross margin | 73.5 | % |  | 74.7 | % |  | 73.8 | % |  | 74.8 | % |
| Operating income | $ | 240.4 |  |  | $ | 53.6 |  |  | $ | 526.9 |  |  | $ | 268.8 |  |
| Operating margin | 10.6 | % |  | 2.7 | % |  | 12.0 | % |  | 7.0 | % |
| Cash flow provided by operating activities |  |  |  |  | $ | 2,066.5 |  |  | $ | 2,216.0 |  |
| Free cash flow (non-GAAP) |  |  |  |  | $ | 1,974.9 |  |  | $ | 2,144.0 |  |

[0001327567-25-000010:mdna:35]
[same as prior period, unchanged from 0001327567-24-000040:mdna:35]

[0001327567-25-000010:mdna:36]
[same as prior period, unchanged from 0001327567-24-000040:mdna:36]

[0001327567-25-000010:mdna:37]
[same as prior period, unchanged from 0001327567-24-000040:mdna:40]

[0001327567-25-000010:mdna:38]
[same as prior period, unchanged from 0001327567-24-000040:mdna:38]

[0001327567-25-000010:mdna:39]
|  | Six Months Ended January 31, |
|  | 2025 |  | 2024 |
|  | (in millions) |
| Free cash flow (non-GAAP): |  |  |  |
| Net cash provided by operating activities | $ | 2,066.5 |  |  | $ | 2,216.0 |  |
| Less: purchases of property, equipment, and other assets | 91.6 |  |  | 72.0 |  |
| Free cash flow (non-GAAP) | $ | 1,974.9 |  |  | $ | 2,144.0 |  |
| Net cash used in investing activities | $ | (924.6) |  |  | $ | (1,454.5) |  |
| Net cash used in financing activities | $ | (451.9) |  |  | $ | (114.4) |  |

[0001327567-25-000010:mdna:40]
[same as prior period, unchanged from 0001327567-24-000040:mdna:46]

[0001327567-25-000010:mdna:41]
[same as prior period, unchanged from 0001327567-24-000040:mdna:41]

[0001327567-25-000010:mdna:42]
[same as prior period, unchanged from 0001327567-24-000040:mdna:42]

[0001327567-25-000010:mdna:43]
|  | Three Months Ended January 31, |  | Six Months Ended January 31, |
|  | 2025 |  | 2024 |  | 2025 |  | 2024 |
|  | Amount |  | % of Revenue |  | Amount |  | % of Revenue |  | Amount |  | % of Revenue |  | Amount |  | % of Revenue |
|  | (dollars in millions) |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product | $ | 421.5 |  |  | 18.7 | % |  | $ | 390.7 |  |  | 19.8 | % |  | $ | 775.3 |  |  | 17.6 | % |  | $ | 731.8 |  |  | 19.0 | % |
| Subscription and support | 1,835.9 |  |  | 81.3 | % |  | 1,584.4 |  |  | 80.2 | % |  | 3,620.9 |  |  | 82.4 | % |  | 3,121.4 |  |  | 81.0 | % |
| Total revenue | 2,257.4 |  |  | 100.0 | % |  | 1,975.1 |  |  | 100.0 | % |  | 4,396.2 |  |  | 100.0 | % |  | 3,853.2 |  |  | 100.0 | % |
| Cost of revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product | 101.3 |  |  | 4.5 | % |  | 88.2 |  |  | 4.5 | % |  | 176.3 |  |  | 4.0 | % |  | 165.6 |  |  | 4.3 | % |
| Subscription and support | 497.9 |  |  | 22.0 | % |  | 410.9 |  |  | 20.8 | % |  | 977.0 |  |  | 22.2 | % |  | 806.3 |  |  | 20.9 | % |
| Total cost of revenue(1) | 599.2 |  |  | 26.5 | % |  | 499.1 |  |  | 25.3 | % |  | 1,153.3 |  |  | 26.2 | % |  | 971.9 |  |  | 25.2 | % |
| Total gross profit | 1,658.2 |  |  | 73.5 | % |  | 1,476.0 |  |  | 74.7 | % |  | 3,242.9 |  |  | 73.8 | % |  | 2,881.3 |  |  | 74.8 | % |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Research and development | 505.7 |  |  | 22.4 | % |  | 447.9 |  |  | 22.7 | % |  | 986.1 |  |  | 22.4 | % |  | 857.4 |  |  | 22.3 | % |
| Sales and marketing | 758.3 |  |  | 33.7 | % |  | 673.0 |  |  | 34.0 | % |  | 1,478.4 |  |  | 33.7 | % |  | 1,333.5 |  |  | 34.6 | % |
| General and administrative | 153.8 |  |  | 6.8 | % |  | 301.5 |  |  | 15.3 | % |  | 251.5 |  |  | 5.7 | % |  | 421.6 |  |  | 10.9 | % |
| Total operating expenses(1) | 1,417.8 |  |  | 62.9 | % |  | 1,422.4 |  |  | 72.0 | % |  | 2,716.0 |  |  | 61.8 | % |  | 2,612.5 |  |  | 67.8 | % |
| Operating income | 240.4 |  |  | 10.6 | % |  | 53.6 |  |  | 2.7 | % |  | 526.9 |  |  | 12.0 | % |  | 268.8 |  |  | 7.0 | % |
| Interest expense | (0.9) |  |  | — | % |  | (2.8) |  |  | (0.1) | % |  | (2.1) |  |  | — | % |  | (5.7) |  |  | (0.1) | % |
| Other income, net | 85.3 |  |  | 3.8 | % |  | 84.7 |  |  | 4.3 | % |  | 168.6 |  |  | 3.8 | % |  | 155.0 |  |  | 4.0 | % |
| Income before income taxes | 324.8 |  |  | 14.4 | % |  | 135.5 |  |  | 6.9 | % |  | 693.4 |  |  | 15.8 | % |  | 418.1 |  |  | 10.9 | % |
| Provision for (benefit from) income taxes | 57.5 |  |  | 2.6 | % |  | (1,611.4) |  |  | (81.5) | % |  | 75.4 |  |  | 1.7 | % |  | (1,523.0) |  |  | (39.5) | % |
| Net income | $ | 267.3 |  |  | 11.8 | % |  | $ | 1,746.9 |  |  | 88.4 | % |  | $ | 618.0 |  |  | 14.1 | % |  | $ | 1,941.1 |  |  | 50.4 | % |

[0001327567-25-000010:mdna:44]
[same as prior period, unchanged from 0001327567-24-000040:mdna:44]

[0001327567-25-000010:mdna:45]
|  | Three Months Ended January 31, |  | Six Months Ended January 31, |
|  | 2025 |  | 2024 |  | 2025 |  | 2024 |
|  | (in millions) |
| Cost of product revenue | $ | 1.3 |  |  | $ | 2.3 |  |  | $ | 2.6 |  |  | $ | 4.7 |  |
| Cost of subscription and support revenue | 32.3 |  |  | 30.7 |  |  | 62.7 |  |  | 61.3 |  |
| Research and development | 139.6 |  |  | 138.6 |  |  | 277.4 |  |  | 258.7 |  |
| Sales and marketing | 90.2 |  |  | 75.6 |  |  | 166.6 |  |  | 154.8 |  |
| General and administrative | 57.1 |  |  | 28.1 |  |  | 105.5 |  |  | 66.8 |  |
| Total share-based compensation | $ | 320.5 |  |  | $ | 275.3 |  |  | $ | 614.8 |  |  | $ | 546.3 |  |

[0001327567-25-000010:mdna:46]
[same as prior period, unchanged from 0001327567-24-000040:mdna:57]

[0001327567-25-000010:mdna:47]
[same as prior period, unchanged from 0001327567-24-000040:mdna:47]

[0001327567-25-000010:mdna:48]
[same as prior period, unchanged from 0001327567-24-000040:mdna:48]

[0001327567-25-000010:mdna:49]
[same as prior period, unchanged from 0001327567-24-000040:mdna:49]

[0001327567-25-000010:mdna:50]
[same as prior period, unchanged from 0001327567-24-000040:mdna:50]

[0001327567-25-000010:mdna:51]
|  | Three Months Ended January 31, |  |  |  |  |  | Six Months Ended January 31, |  |  |  |  |
|  | 2025 |  | 2024 |  | Change |  | 2025 |  | 2024 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| Product | $ | 421.5 |  |  | $ | 390.7 |  |  | $ | 30.8 |  |  | 7.9 | % |  | $ | 775.3 |  |  | $ | 731.8 |  |  | $ | 43.5 |  |  | 5.9 | % |

[0001327567-25-000010:mdna:52]
Product revenue increased for the three and six months ended January 31, 2025 compared to the same periods in 2024 driven by increased demand for our new generation of hardware products and accessories, and an increase in price of and allocation to on-premise software licenses due to enhanced features and capabilities during the fiscal quarter ended January 31, 2025. The increase in product revenue for the six months ended January 31, 2025 was partially offset by decreased demand for our prior generation of hardware products.

[0001327567-25-000010:mdna:53]
[same as prior period, unchanged from 0001327567-24-000040:mdna:53]

[0001327567-25-000010:mdna:54]
[same as prior period, unchanged from 0001327567-24-000040:mdna:54]

[0001327567-25-000010:mdna:55]
|  | Three Months Ended January 31, |  |  |  |  |  | Six Months Ended January 31, |  |  |  |  |
|  | 2025 |  | 2024 |  | Change |  | 2025 |  | 2024 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| Subscription | $ | 1,233.2 |  |  | $ | 1,027.1 |  |  | $ | 206.1 |  |  | 20.1 | % |  | $ | 2,425.0 |  |  | $ | 2,015.4 |  |  | $ | 409.6 |  |  | 20.3 | % |
| Support | 602.7 |  |  | 557.3 |  |  | 45.4 |  |  | 8.1 | % |  | 1,195.9 |  |  | 1,106.0 |  |  | 89.9 |  |  | 8.1 | % |
| Total subscription and support | $ | 1,835.9 |  |  | $ | 1,584.4 |  |  | $ | 251.5 |  |  | 15.9 | % |  | $ | 3,620.9 |  |  | $ | 3,121.4 |  |  | $ | 499.5 |  |  | 16.0 | % |

[0001327567-25-000010:mdna:56]
Subscription and support revenue increased for the three and six months ended January 31, 2025 compared to the same periods in 2024 primarily due to increased demand for our subscription and support offerings from our end-customers. The mix between subscription revenue and support revenue will fluctuate over time, depending on the introduction of new subscription offerings, renewals of support services, and our ability to increase sales to new and existing end-customers.

[0001327567-25-000010:mdna:57]
[same as prior period, unchanged from 0001327567-24-000040:mdna:67]

[0001327567-25-000010:mdna:58]
[same as prior period, unchanged from 0001327567-24-000040:mdna:58]

[0001327567-25-000010:mdna:59]
|  | Three Months Ended January 31, |  |  |  |  |  | Six Months Ended January 31, |  |  |  |  |
|  | 2025 |  | 2024 |  | Change |  | 2025 |  | 2024 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| Americas | $ | 1,502.4 |  |  | $ | 1,334.2 |  |  | $ | 168.2 |  |  | 12.6 | % |  | $ | 2,944.5 |  |  | $ | 2,620.8 |  |  | $ | 323.7 |  |  | 12.4 | % |
| Europe, the Middle East, and Africa (“EMEA”) | 480.0 |  |  | 406.8 |  |  | 73.2 |  |  | 18.0 | % |  | 921.4 |  |  | 771.7 |  |  | 149.7 |  |  | 19.4 | % |
| Asia Pacific and Japan (“APAC”) | 275.0 |  |  | 234.1 |  |  | 40.9 |  |  | 17.5 | % |  | 530.3 |  |  | 460.7 |  |  | 69.6 |  |  | 15.1 | % |
| Total revenue | $ | 2,257.4 |  |  | $ | 1,975.1 |  |  | $ | 282.3 |  |  | 14.3 | % |  | $ | 4,396.2 |  |  | $ | 3,853.2 |  |  | $ | 543.0 |  |  | 14.1 | % |

[0001327567-25-000010:mdna:60]
Revenue from the Americas, EMEA, and APAC increased for the three and six months ended January 31, 2025 compared to the same periods in 2024 as we continued to increase investment in our global sales force in order to support our growth and innovation, with the Americas contributing the highest increase in revenue due to its larger scale.

[0001327567-25-000010:mdna:61]
[same as prior period, unchanged from 0001327567-24-000040:mdna:61]

[0001327567-25-000010:mdna:62]
[same as prior period, unchanged from 0001327567-24-000040:mdna:62]

[0001327567-25-000010:mdna:63]
[same as prior period, unchanged from 0001327567-24-000040:mdna:63]

[0001327567-25-000010:mdna:64]
[same as prior period, unchanged from 0001327567-24-000040:mdna:64]

[0001327567-25-000010:mdna:65]
|  | Three Months Ended January 31, |  |  |  |  |  | Six Months Ended January 31, |  |  |  |  |
|  | 2025 |  | 2024 |  | Change |  | 2025 |  | 2024 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| Cost of product revenue | $ | 101.3 |  |  | $ | 88.2 |  |  | $ | 13.1 |  |  | 14.9 | % |  | $ | 176.3 |  |  | $ | 165.6 |  |  | $ | 10.7 |  |  | 6.5 | % |

[0001327567-25-000010:mdna:66]
Cost of product revenue increased for the three and six months ended January 31, 2025 compared to the same periods in 2024 primarily due to an increase in inventory reserves. The increase in cost of product revenue for the three months ended January 31, 2025 was further driven by increased demand for our new generation hardware products.

[0001327567-25-000010:mdna:67]
[same as prior period, unchanged from 0001327567-24-000040:mdna:77]

[0001327567-25-000010:mdna:68]
[same as prior period, unchanged from 0001327567-24-000040:mdna:68]

[0001327567-25-000010:mdna:69]
[same as prior period, unchanged from 0001327567-24-000040:mdna:69]

[0001327567-25-000010:mdna:70]
|  | Three Months Ended January 31, |  |  |  |  |  | Six Months Ended January 31, |  |  |  |  |
|  | 2025 |  | 2024 |  | Change |  | 2025 |  | 2024 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| Cost of subscription and support revenue | $ | 497.9 |  |  | $ | 410.9 |  |  | $ | 87.0 |  |  | 21.2 | % |  | $ | 977.0 |  |  | $ | 806.3 |  |  | $ | 170.7 |  |  | 21.2 | % |

[0001327567-25-000010:mdna:71]
Cost of subscription and support revenue increased for the three and six months ended January 31, 2025 compared to the same periods in 2024 primarily due to increased costs to support the growth of our subscription and support offerings. Cloud hosting service costs, which support our cloud-based subscription offerings, increased $45.9 million and $85.7 million for the three and six months ended January 31, 2025, respectively, compared to the same periods in 2024. Personnel costs grew $14.5 million and $25.8 million for the three and six months ended January 31, 2025, respectively, compared to the same periods in 2024, primarily due to headcount growth. The increase in cost of subscription and support revenue in both periods was further driven by increased professional services expense.

[0001327567-25-000010:mdna:72]
[same as prior period, unchanged from 0001327567-24-000040:mdna:72]

[0001327567-25-000010:mdna:73]
[same as prior period, unchanged from 0001327567-24-000040:mdna:73]

[0001327567-25-000010:mdna:74]
|  | Three Months Ended January 31, |  | Six Months Ended January 31, |
|  | 2025 |  | 2024 |  | 2025 |  | 2024 |
|  | Amount |  | Gross Margin |  | Amount |  | Gross Margin |  | Amount |  | Gross Margin |  | Amount |  | Gross Margin |
|  | (dollars in millions) |
| Product | $ | 320.2 |  |  | 76.0 | % |  | $ | 302.5 |  |  | 77.4 | % |  | $ | 599.0 |  |  | 77.3 | % |  | $ | 566.2 |  |  | 77.4 | % |
| Subscription and support | 1,338.0 |  |  | 72.9 | % |  | 1,173.5 |  |  | 74.1 | % |  | 2,643.9 |  |  | 73.0 | % |  | 2,315.1 |  |  | 74.2 | % |
| Total gross profit | $ | 1,658.2 |  |  | 73.5 | % |  | $ | 1,476.0 |  |  | 74.7 | % |  | $ | 3,242.9 |  |  | 73.8 | % |  | $ | 2,881.3 |  |  | 74.8 | % |

[0001327567-25-000010:mdna:75]
Product gross margin decreased for the three months ended January 31, 2025 compared to the same period in 2024 primarily due to an increase in inventory reserves. Product gross margin was relatively flat for the six months ended January 31, 2025 compared to the same period in 2024.

[0001327567-25-000010:mdna:76]
Subscription and support gross margin decreased for the three and six months ended January 31, 2025 compared to the same periods in 2024 primarily due to an increase in costs related to our cloud-based offerings.

[0001327567-25-000010:mdna:77]
[same as prior period, unchanged from 0001327567-24-000040:mdna:88]

[0001327567-25-000010:mdna:78]
[same as prior period, unchanged from 0001327567-24-000040:mdna:78]

[0001327567-25-000010:mdna:79]
Our operating expenses consist of research and development, sales and marketing, and general and administrative expenses. Personnel costs are the most significant component of operating expenses and consist of salaries, benefits, bonuses, share-based compensation, travel and entertainment, and with regard to sales and marketing expense, sales commissions. Our operating expenses also include shared costs, which consist of certain facilities, depreciation, benefits, recruiting, and information technology costs that we allocate based on headcount to each department. We expect operating expenses generally to increase in absolute dollars and to decrease over the long term as a percentage of revenue as we continue to scale our business. As of January 31, 2025, we expect to recognize approximately $2.5 billion of share-based compensation expense over a weighted-average period of approximately 2.6 years, excluding additional share-based compensation expense related to any future grants of share-based awards. Share-based compensation expense is generally recognized on a straight-line basis over the requisite service periods of the awards.

[0001327567-25-000010:mdna:80]
[same as prior period, unchanged from 0001327567-24-000040:mdna:80]

[0001327567-25-000010:mdna:81]
[same as prior period, unchanged from 0001327567-24-000040:mdna:81]

[0001327567-25-000010:mdna:82]
|  | Three Months Ended January 31, |  |  |  |  |  | Six Months Ended January 31, |  |  |  |  |
|  | 2025 |  | 2024 |  | Change |  | 2025 |  | 2024 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| Research and development | $ | 505.7 |  |  | $ | 447.9 |  |  | $ | 57.8 |  |  | 12.9 | % |  | $ | 986.1 |  |  | $ | 857.4 |  |  | $ | 128.7 |  |  | 15.0 | % |

[0001327567-25-000010:mdna:83]
Research and development expense increased for the three and six months ended January 31, 2025 compared to the same periods in 2024 primarily due to increased personnel costs, which grew $38.1 million and $87.1 million for the three and six months ended January 31, 2025, respectively, compared to the same periods in 2024, largely due to headcount growth. The increase in research and development expense in both periods was further driven by increased shared costs.

[0001327567-25-000010:mdna:84]
[same as prior period, unchanged from 0001327567-24-000040:mdna:84]

[0001327567-25-000010:mdna:85]
[same as prior period, unchanged from 0001327567-24-000040:mdna:85]

[0001327567-25-000010:mdna:86]
|  | Three Months Ended January 31, |  |  |  |  |  | Six Months Ended January 31, |  |  |  |  |
|  | 2025 |  | 2024 |  | Change |  | 2025 |  | 2024 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| Sales and marketing | $ | 758.3 |  |  | $ | 673.0 |  |  | $ | 85.3 |  |  | 12.7 | % |  | $ | 1,478.4 |  |  | $ | 1,333.5 |  |  | $ | 144.9 |  |  | 10.9 | % |

[0001327567-25-000010:mdna:87]
Sales and marketing expense increased for the three and six months ended January 31, 2025 compared to the same periods in 2024 primarily due to increased personnel costs, which grew $65.1 million and $122.7 million for the three and six months ended January 31, 2025, respectively, compared to the same periods in 2024, largely due to headcount growth.

[0001327567-25-000010:mdna:88]
[same as prior period, unchanged from 0001327567-24-000040:mdna:101]

[0001327567-25-000010:mdna:89]
[same as prior period, unchanged from 0001327567-24-000040:mdna:89]

[0001327567-25-000010:mdna:90]
[same as prior period, unchanged from 0001327567-24-000040:mdna:90]

[0001327567-25-000010:mdna:91]
|  | Three Months Ended January 31, |  |  |  |  |  | Six Months Ended January 31, |  |  |  |  |
|  | 2025 |  | 2024 |  | Change |  | 2025 |  | 2024 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| General and administrative | $ | 153.8 |  |  | $ | 301.5 |  |  | $ | (147.7) |  |  | (49.0) | % |  | $ | 251.5 |  |  | $ | 421.6 |  |  | $ | (170.1) |  |  | (40.3) | % |

[0001327567-25-000010:mdna:92]
General and administrative expense decreased for the three and six months ended January 31, 2025 compared to the same periods in 2024 primarily due to a litigation-related accrual of $176.8 million during the three months ended January 31, 2024 and a partial release of $43.0 million during the three months ended October 31, 2024. The decrease in general and administrative expense in both periods was partially offset by increased personnel costs, which grew $32.7 million and $47.8 million for the three and six months ended January 31, 2025, respectively, compared to the same periods in 2024, largely due to increased share-based compensation.

[0001327567-25-000010:mdna:93]
[same as prior period, unchanged from 0001327567-24-000040:mdna:93]

[0001327567-25-000010:mdna:94]
Interest expense primarily consists of interest expense related to our 0.375% Convertible Senior Notes due 2025 (the “2025 Notes”).

[0001327567-25-000010:mdna:95]
|  | Three Months Ended January 31, |  |  |  | Six Months Ended January 31, |  |  |
|  | 2025 |  | 2024 |  | Change |  | 2025 |  | 2024 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| Interest expense | $ | 0.9 |  |  | $ | 2.8 |  |  | $ | (1.9) |  |  | (67.9) | % |  | $ | 2.1 |  |  | $ | 5.7 |  |  | $ | (3.6) |  |  | (63.2) | % |

[0001327567-25-000010:mdna:96]
Interest expense decreased for the three and six months ended January 31, 2025 compared to the same periods in 2024 primarily due to early conversions of our 2025 Notes. Refer to Note 9. Debt in Part I, Item 1 of this Quarterly Report on Form 10-Q for more information on the Notes.

[0001327567-25-000010:mdna:97]
[same as prior period, unchanged from 0001327567-24-000040:mdna:97]

[0001327567-25-000010:mdna:98]
[same as prior period, unchanged from 0001327567-24-000040:mdna:98]

[0001327567-25-000010:mdna:99]
|  | Three Months Ended January 31, |  |  |  | Six Months Ended January 31, |  |  |
|  | 2025 |  | 2024 |  | Change |  | 2025 |  | 2024 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| Other income, net | $ | 85.3 |  |  | $ | 84.7 |  |  | $ | 0.6 |  |  | 0.7 | % |  | $ | 168.6 |  |  | $ | 155.0 |  |  | $ | 13.6 |  |  | 8.8 | % |

[0001327567-25-000010:mdna:100]
Other income, net was flat for the three months ended January 31, 2025 compared to the same period in 2024. Other income, net increased for the six months ended January 31, 2025 compared to the same period in 2024 primarily due to higher interest income as a result of higher average cash, cash equivalent, and investment balances for the six months ended January 31, 2025 compared to the same period in 2024.

[0001327567-25-000010:mdna:101]
[same as prior period, unchanged from 0001327567-24-000040:mdna:110]

[0001327567-25-000010:mdna:102]
PROVISION FOR (BENEFIT FROM) INCOME TAXES

[0001327567-25-000010:mdna:103]
Provision for (benefit from) income taxes consists primarily of U.S. and foreign income taxes. Our effective tax rate during the three and six months ended January 31, 2025 was lower than our statutory tax rate primarily due to excess tax benefits from share-based compensation. We regularly assess the need for a valuation allowance on our deferred tax assets. In making this assessment, we consider both positive and negative evidence related to the likelihood of realization of the deferred tax assets to determine, based on the weight of available evidence, whether it is more likely than not that some or all the deferred tax assets will not be realized. The assessment requires significant judgment and is performed for each of the applicable jurisdictions. Based on our analysis of all positive and negative evidence during the fiscal quarter ended January 31, 2025, we continue to maintain a valuation allowance for our California deferred tax assets due to the uncertainty regarding realizability of these deferred tax assets as they have not met the “more likely than not” realization criterion. We expect future research and development tax credit generation in California to exceed our ability to use the existing tax credits.

[0001327567-25-000010:mdna:104]
|  | Three Months Ended January 31, |  |  |  |  |  | Six Months Ended January 31, |  |  |  |  |
|  | 2025 |  | 2024 |  | Change |  | 2025 |  | 2024 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| Provision for (benefit from) income taxes | $ | 57.5 |  |  | $ | (1,611.4) |  |  | $ | 1,668.9 |  |  | (103.6) | % |  | $ | 75.4 |  |  | $ | (1,523.0) |  |  | $ | 1,598.4 |  |  | (105.0) | % |
| Effective tax rate | 17.7 | % |  | (1,189.2) | % |  |  |  |  |  | 10.9 | % |  | (364.3) | % |  |  |  |  |

[0001327567-25-000010:mdna:105]
Our provision for income taxes for the three and six months ended January 31, 2025 was primarily due to U.S. and foreign income taxes. Our effective tax rate increased for the three and six months ended January 31, 2025 compared to the same periods in 2024 primarily due to the release of our valuation allowance on U.S. federal, U.S. states other than California, and United Kingdom deferred tax assets in the second quarter of fiscal 2024. Refer to Note 13. Income Taxes in Part I, Item 1 of this Quarterly Report on Form 10-Q for more information.

[0001327567-25-000010:mdna:106]
[same as prior period, unchanged from 0001327567-24-000040:mdna:106]

[0001327567-25-000010:mdna:107]
|  | January 31, 2025 |  | July 31, 2024 |
|  | (in millions) |
| Working capital (deficit) | $ | (1,212.4) |  |  | $ | (833.0) |  |
| Cash, cash equivalents, and investments: |  |  |  |
| Cash and cash equivalents | $ | 2,226.3 |  |  | $ | 1,535.2 |  |
| Investments | 5,566.4 |  |  | 5,216.8 |  |
| Total cash, cash equivalents, and investments | $ | 7,792.7 |  |  | $ | 6,752.0 |  |

[0001327567-25-000010:mdna:108]
As of January 31, 2025, our total cash, cash equivalents, and investments of $7.8 billion were held for general corporate purposes. As of January 31, 2025, we had no unremitted earnings when evaluating our outside basis difference relating to our U.S. investment in foreign subsidiaries. However, there could be local withholding taxes due to various foreign countries if certain lower tier earnings are distributed. Withholding taxes that would be payable upon remittance of these lower tier earnings are not material.

[0001327567-25-000010:mdna:109]
[same as prior period, unchanged from 0001327567-24-000040:mdna:109]

[0001327567-25-000010:mdna:110]
[same as prior period, unchanged from 0001327567-24-000040:mdna:121]

[0001327567-25-000010:mdna:111]
[same as prior period, unchanged from 0001327567-24-000040:mdna:111]

[0001327567-25-000010:mdna:112]
In June 2020, we issued the 2025 Notes with an aggregate principal amount of $2.0 billion. The 2025 Notes mature on June 1, 2025; however, under certain circumstances, holders may surrender their 2025 Notes for conversion prior to the maturity date. Upon conversion of the 2025 Notes, we will pay cash equal to the aggregate principal amount of the 2025 Notes to be converted, and, at our election, we will pay or deliver cash and/or shares of our common stock for the amount of our conversion obligation in excess of the aggregate principal amount of the 2025 Notes being converted. During the three and six months ended January 31, 2025, we repaid in cash $112.4 million and $431.4 million, respectively, in aggregate principal amount of the 2025 Notes and issued 1.7 million and 6.2 million shares of common stock to the holders, respectively, for the conversion value in excess of the principal amount of the 2025 Notes converted, which were fully offset by shares we received from our exercise of the associated note hedges. Subsequent to January 31, 2025, through the filing date of this Quarterly Report on Form 10-Q, $100.4 million in aggregate principal amount of the 2025 Notes was converted or had been submitted by the holders for conversion and will settle during the fiscal quarter ending April 30, 2025.

[0001327567-25-000010:mdna:113]
The sale price condition for the 2025 Notes was met during the fiscal quarter ended January 31, 2025, and, as a result, holders may convert their 2025 Notes during the fiscal quarter ending April 30, 2025 at any time prior to the close of business on the business day immediately preceding March 1, 2025 for settlement prior to the maturity date. If all of the holders convert their 2025 Notes during this period, we would be obligated to settle the $534.2 million principal amount of the 2025 Notes in cash. We believe that our cash provided by operating activities, our existing cash, cash equivalents, and investments, and existing sources of and access to financing will be sufficient to meet our anticipated cash needs should the holders choose to convert their 2025 Notes during the fiscal quarter ending April 30, 2025 or hold the 2025 Notes until maturity on June 1, 2025. As of January 31, 2025, $534.2 million of our 2025 Notes remained outstanding. Refer to Note 9. Debt in Part I, Item 1 of this Quarterly Report on Form 10-Q for more information on the 2025 Notes.

[0001327567-25-000010:mdna:114]
In April 2023, we entered into a credit agreement (the “Credit Agreement”) that provides for a $400.0 million unsecured revolving credit facility (the “Credit Facility”), with an option to increase the amount of the Credit Facility by up to an additional $350.0 million, subject to certain conditions. The interest rates and commitment fees are also subject to upward and downward adjustments based on our progress towards the achievement of certain sustainability goals related to greenhouse gas emissions. As of January 31, 2025, there were no amounts outstanding, and we were in compliance with all covenants under the Credit Agreement. Refer to Note 9. Debt in Part I, Item 1 of this Quarterly Report on Form 10-Q for more information on the Credit Agreement.

[0001327567-25-000010:mdna:115]
[same as prior period, unchanged from 0001327567-24-000040:mdna:115]

[0001327567-25-000010:mdna:116]
In February 2019, our board of directors authorized a $1.0 billion share repurchase program. In December 2020, August 2021, August 2022, November 2023, and August 2024, our board of directors authorized additional $700.0 million, $676.1 million, $915.0 million, $316.7 million and $500.0 million increases to this share repurchase program, respectively, bringing the total authorization under this share repurchase program to $4.1 billion. Repurchases will be funded from available working capital and may be made at management’s discretion from time to time. As of January 31, 2025, $1.0 billion remained available for future share repurchases under this repurchase program. The repurchase authorization will expire on December 31, 2025, and may be suspended or discontinued at any time without prior notice. Refer to Note 11. Stockholders’ Equity in Part I, Item 1 of this Quarterly Report on Form 10-Q for more information on this repurchase program.

[0001327567-25-000010:mdna:117]
[same as prior period, unchanged from 0001327567-24-000040:mdna:117]

[0001327567-25-000010:mdna:118]
We have entered into various non-cancelable operating leases, primarily for our offices and data centers, with lease terms expiring through fiscal 2036. As of January 31, 2025, we have total operating lease obligations of $436.6 million recorded on our condensed consolidated balance sheet.

[0001327567-25-000010:mdna:119]
As of January 31, 2025, our commitments to purchase products, components, cloud and other services totaled $4.4 billion. Refer to Note 10. Commitments and Contingencies in Part I, Item 1 of this Quarterly Report on Form 10-Q for more information on these commitments.

[0001327567-25-000010:mdna:120]
Our acquisition of certain QRadar assets from International Business Machines Corporation (“IBM”) on August 31, 2024 included contingent consideration that requires potential future payments through the fiscal quarter ending October 2028. As of January 31, 2025, we have total contingent consideration obligations of $664.9 million recorded on our condensed consolidated balance sheet. Refer to Note 3. Fair Value Measurements and Note 7. Acquisition in Part I, Item 1 of this Quarterly Report on Form 10-Q for more information on these contingent consideration obligations.

[0001327567-25-000010:mdna:121]
[same as prior period, unchanged from 0001327567-24-000040:mdna:136]

[0001327567-25-000010:mdna:122]
[same as prior period, unchanged from 0001327567-24-000040:mdna:122]

[0001327567-25-000010:mdna:123]
The following table summarizes our cash flows for the six months ended January 31, 2025 and 2024:

[0001327567-25-000010:mdna:124]
|  | Six Months Ended January 31, |
|  | 2025 |  | 2024 |
|  | (in millions) |
| Net cash provided by operating activities | $ | 2,066.5 |  |  | $ | 2,216.0 |  |
| Net cash used in investing activities | (924.6) |  |  | (1,454.5) |  |
| Net cash used in financing activities | (451.9) |  |  | (114.4) |  |
| Net increase in cash, cash equivalents, and restricted cash | $ | 690.0 |  |  | $ | 647.1 |  |

[0001327567-25-000010:mdna:125]
[same as prior period, unchanged from 0001327567-24-000040:mdna:125]

[0001327567-25-000010:mdna:126]
[same as prior period, unchanged from 0001327567-24-000040:mdna:126]

[0001327567-25-000010:mdna:127]
[same as prior period, unchanged from 0001327567-24-000040:mdna:127]

[0001327567-25-000010:mdna:128]
Our operating activities have consisted of net income adjusted for certain non-cash items and changes in assets and liabilities. Our largest source of cash provided by our operations is receipts from our customers.

[0001327567-25-000010:mdna:129]
Cash provided by operating activities during the six months ended January 31, 2025 was $2.1 billion, a decrease of $149.5 million compared to the same period in 2024. The decrease was primarily due to higher payments of cash expenditure to support our business growth, partially offset by an increase in receipts from our customers during the six months ended January 31, 2025.

[0001327567-25-000010:mdna:130]
[same as prior period, unchanged from 0001327567-24-000040:mdna:130]

[0001327567-25-000010:mdna:131]
[same as prior period, unchanged from 0001327567-24-000040:mdna:131]

[0001327567-25-000010:mdna:132]
Cash used in investing activities during the six months ended January 31, 2025 was $924.6 million, a decrease of $529.9 million compared to the same period in 2024. The decrease was primarily due to lower purchases of investments, higher proceeds from sales and maturities of investments, and a decrease in net cash payments for business acquisitions during the six months ended January 31, 2025.

[0001327567-25-000010:mdna:133]
[same as prior period, unchanged from 0001327567-24-000040:mdna:133]

[0001327567-25-000010:mdna:134]
[same as prior period, unchanged from 0001327567-24-000040:mdna:134]

[0001327567-25-000010:mdna:135]
Cash used in financing activities during the six months ended January 31, 2025 was $451.9 million, an increase of $337.5 million compared to the same period in 2024. The increase was primarily due to an increase in cash used for repayments of the early conversion of our 2025 Notes and an increase in payments for tax withholding related to the net share settlement of employee equity awards, partially offset by a decrease in cash used to repurchase our common stock which did not recur during the six months ended January 31, 2025.

[0001327567-25-000010:mdna:136]
- 36 -

[0001327567-25-000010:mdna:137]
[same as prior period, unchanged from 0001327567-24-000040:mdna:137]

[0001327567-25-000010:mdna:138]
[same as prior period, unchanged from 0001327567-24-000040:mdna:138]

[0001327567-25-000010:mdna:139]
We believe the critical accounting estimates discussed under Item 7, “Management’s Discussion and Analysis of Financial Condition and Results of Operations” in our Annual Report on Form 10-K for the fiscal year ended July 31, 2024 reflect our more significant estimates, assumptions, and judgments that have the most significant impact on our condensed consolidated financial statements. There have been no significant changes to our critical accounting estimates as filed in such report, except for the update as described below resulting from our acquisition of certain IBM QRadar assets.

[0001327567-25-000010:mdna:140]
[same as prior period, unchanged from 0001327567-24-000040:mdna:140]

[0001327567-25-000010:mdna:141]
[same as prior period, unchanged from 0001327567-24-000040:mdna:141]

[0001327567-25-000010:mdna:142]
[same as prior period, unchanged from 0001327567-24-000040:mdna:142]

[0001327567-25-000010:mdna:143]
[same as prior period, unchanged from 0001327567-24-000040:mdna:143]

[0001327567-25-000010:mdna:144]
Refer to “Recently Issued Accounting Pronouncements” in Note 1. Description of Business and Summary of Significant Accounting Policies in Part I, Item 1 of this Quarterly Report on Form 10-Q for a description of recent accounting pronouncements and our expectation of their impact, if any, on our results of operations and financial condition.
