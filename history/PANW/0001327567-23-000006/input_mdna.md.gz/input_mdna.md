# PANW MD&A — 0001327567-23-000006


## mdna

[0001327567-23-000006:mdna:1]
[same as prior period, unchanged from 0001327567-22-000038:mdna:1]

[0001327567-23-000006:mdna:2]
[same as prior period, unchanged from 0001327567-22-000038:mdna:2]

[0001327567-23-000006:mdna:3]
[same as prior period, unchanged from 0001327567-22-000038:mdna:3]

[0001327567-23-000006:mdna:4]
[same as prior period, unchanged from 0001327567-22-000038:mdna:4]

[0001327567-23-000006:mdna:5]
•Results of Operations. A discussion of the nature and trends in our financial results and an analysis of our financial results comparing the three and six months ended January 31, 2023 to the three and six months ended January 31, 2022.

[0001327567-23-000006:mdna:6]
[same as prior period, unchanged from 0001327567-22-000038:mdna:6]

[0001327567-23-000006:mdna:7]
[same as prior period, unchanged from 0001327567-22-000038:mdna:7]

[0001327567-23-000006:mdna:8]
[same as prior period, unchanged from 0001327567-22-000038:mdna:8]

[0001327567-23-000006:mdna:9]
[same as prior period, unchanged from 0001327567-22-000038:mdna:9]

[0001327567-23-000006:mdna:10]
We empower enterprises, organizations, service providers, and government entities to protect themselves against today’s most sophisticated cyber threats. Our cybersecurity platforms and services help secure enterprise users, networks, clouds, and endpoints by delivering comprehensive cybersecurity backed by industry-leading artificial intelligence and automation. We are a leading provider of zero trust solutions that start with the next-generation of zero trust network access to secure remote workforces and extend into securing all users, applications and infrastructure with zero trust principles. Our security solutions are designed to increase security while reducing our customers’ total cost of ownership by improving operational efficiency and eliminating the need for siloed point products. Our company focuses on delivering value in five fundamental areas:

[0001327567-23-000006:mdna:11]
[same as prior period, unchanged from 0001327567-22-000038:mdna:33]

[0001327567-23-000006:mdna:12]
[same as prior period, unchanged from 0001327567-22-000038:mdna:12]

[0001327567-23-000006:mdna:13]
[same as prior period, unchanged from 0001327567-22-000038:mdna:13]

[0001327567-23-000006:mdna:14]
•Our network security platform, which includes our ML-Powered Next-Generation Firewalls, available in a number of form factors, including physical, virtual, and containerized appliances, as well as a cloud-delivered service, has been a leader in the industry for eleven consecutive years. Our network security platform also includes our Cloud-Delivered Security Services, such as Advanced Threat Prevention, Advanced WildFire®, Advanced URL Filtering, DNS Security, IoT Security, GlobalProtect™, Enterprise Data Loss Prevention (“Enterprise DLP”), AIOps, and SaaS Security. Through these add-on security services, our customers are able to secure their applications, users, devices, and content across our network security platform as well as the Prisma® and Cortex® product lines. Panorama™, our network security management solution, available as hardware or virtual machine, can centrally manage our network security platform irrespective of form factor, location, or scale. Our software-defined wide-area network (“SD-WAN”) is integrated with PAN-OS, so that our end-customers can get the security features of our PAN-OS ML-Powered Next-Generation Firewall together with SD-WAN functionality.

[0001327567-23-000006:mdna:15]
[same as prior period, unchanged from 0001327567-22-000038:mdna:15]

[0001327567-23-000006:mdna:16]
•Prisma Access is our next-generation cloud-delivered security platform that provides secure network access for employees across all locations with continuous threat inspection and unified policy management for information technology. We recently introduced Zero Trust Network Access (“ZTNA”) 2.0, which addresses major shortcomings in the first-generation ZTNA products in the industry (which we refer to as ZTNA 1.0). Prisma Access delivers granular least-privileged access to all applications and data across the enterprise, while continuously verifying trust and inspecting traffic for security. When combined with Prisma SD-WAN, Prisma Access provides a comprehensive single-vendor Secure Access Service Edge (“SASE”) offering that we call Prisma SASE, that is used to secure hybrid workforces and enable the cloud-delivered branch.

[0001327567-23-000006:mdna:17]
[same as prior period, unchanged from 0001327567-22-000038:mdna:17]

[0001327567-23-000006:mdna:18]
•As a comprehensive Cloud Native Application Protection Platform (“CNAPP”), Prisma Cloud secures hybrid and multi-cloud environments with continuous visibility and threat prevention across the entire  application lifecycle. With code to cloud security coverage that encompasses code, infrastructure, workloads, data, networks, web applications, and APIs, Prisma Cloud is the only platform that addresses security needs at every step in the cloud journey. For inline network security on multi and hybrid-cloud environments, we also offer our VM-Series and CN-Series Firewall offerings.

[0001327567-23-000006:mdna:19]
[same as prior period, unchanged from 0001327567-22-000038:mdna:19]

[0001327567-23-000006:mdna:20]
•We deliver the next generation of endpoint security, security analytics and security automation solutions through our Cortex portfolio. These include our industry-leading extended detection and response solution Cortex XDR® to prevent, detect, and respond to complex cybersecurity attacks, Cortex XSOAR® for security orchestration, automation, and response (“SOAR”), and Cortex Xpanse® for attack surface management (“ASM”). In October 2022, we released Cortex XSIAM®, our autonomous Security Operations Center (“SOC”) platform that delivers unified security operations functions including automated threat detection and response, user behavioral analytics, threat intelligence management, orchestration and workflow, endpoint protection, and cloud detection and response. These products are delivered as software or SaaS subscriptions.

[0001327567-23-000006:mdna:21]
[same as prior period, unchanged from 0001327567-22-000038:mdna:21]

[0001327567-23-000006:mdna:22]
•We enable security teams with up-to-date threat intelligence and deep cybersecurity expertise before, during and after attacks through our Unit 42 threat research and security consulting team. Unit 42 offers incident response, risk management, proactive cybersecurity assessment services, and managed detection and response and threat hunting services.

[0001327567-23-000006:mdna:23]
For the second quarter of fiscal 2023 and 2022, total revenue was $1.7 billion and $1.3 billion, respectively, representing year-over-year growth of 25.7%. Our growth reflects the increased adoption of our portfolio, which consists of product, subscriptions, and support. We believe our portfolio will enable us to benefit from recurring revenues and new revenues as we continue to grow our end-customer base. As of January 31, 2023, we had end-customers in over 180 countries. Our end-customers represent a broad range of industries, including education, energy, financial services, government entities, healthcare, Internet and media, manufacturing, public sector, and telecommunications, and include almost all of the Fortune 100 companies and a majority of the Global 2000 companies. We maintain a field sales force that works closely with our channel partners in developing sales opportunities. We primarily use a two-tiered, indirect fulfillment model whereby we sell our products, subscriptions, and support to our distributors, which, in turn, sell to our resellers, which then sell to our end-customers.

[0001327567-23-000006:mdna:24]
[same as prior period, unchanged from 0001327567-22-000038:mdna:43]

[0001327567-23-000006:mdna:25]
[same as prior period, unchanged from 0001327567-22-000038:mdna:26]

[0001327567-23-000006:mdna:26]
Our product revenue grew to $352.9 million, or 21.3% of total revenue, for the second quarter of fiscal 2023, representing year-over-year growth of 14.6%. Product revenue is primarily generated from sales of our appliances, primarily our ML-Powered Next-Generation Firewall. Product revenue also includes revenue derived from software licenses of Panaroma, SD-WAN, and the VM-Series. Our ML-Powered Next-Generation Firewall incorporates our PAN-OS operating system, which provides a consistent set of capabilities across our entire network security product line. Our appliances and software licenses include a broad set of built-in networking and security features and functionalities. Our products are designed for different performance requirements throughout an organization, ranging from our PA-410, which is designed for small organizations and remote or branch offices, to our top-of-the-line PA-7080, which is designed for large-scale data centers and service provider use. The same firewall functionality that is delivered in our physical appliances is also available in our VM-Series virtual firewalls, which secure virtualized and cloud-based computing environments, and in our CN-Series container firewalls, which secure container environments and traffic.

[0001327567-23-000006:mdna:27]
Our subscription and support revenue grew to $1.3 billion, or 78.7% of total revenue, for the second quarter of fiscal 2023, representing year-over-year growth of 29.1%. Our subscriptions provide our end-customers with near real-time access to the latest antivirus, intrusion prevention, web filtering, modern malware prevention, data loss prevention, and cloud access security broker capabilities across the network, endpoints, and the cloud. When end-customers purchase our physical, virtual, or container firewall appliances, or certain cloud offerings, they typically purchase support in order to receive ongoing security updates, upgrades, bug fixes, and repairs. In addition to the subscriptions purchased with these appliances, end-customers may also purchase other subscriptions on a per-user, per-endpoint, or capacity-based basis. We also offer professional services, including incident response, risk management, and digital forensic services.

[0001327567-23-000006:mdna:28]
We continue to invest in innovation as we evolve and further extend the capabilities of our portfolio, as we believe that innovation and timely development of new features and products are essential to meeting the needs of our end-customers and improving our competitive position. For example, in November 2022, we launched PAN-OS® 11.0 Nova, which introduced 50 product updates and innovations. Among them were the new Advanced WildFire® cloud-delivered security service that brings unprecedented protection against evasive malware and the updated Advanced Threat Prevention service which now protects against zero-day injection attacks.

[0001327567-23-000006:mdna:29]
[same as prior period, unchanged from 0001327567-22-000038:mdna:29]

[0001327567-23-000006:mdna:30]
[same as prior period, unchanged from 0001327567-22-000038:mdna:30]

[0001327567-23-000006:mdna:31]
[same as prior period, unchanged from 0001327567-22-000038:mdna:31]

[0001327567-23-000006:mdna:32]
We continue to monitor and respond to developments relating to COVID-19, which has resulted in significant global, social, and business disruption. The extent of the continued impact of COVID-19 on our operational and financial performance will depend on developments, including the duration and spread of the virus and its variants, impact on our end-customers’ spending, volume of sales and length of our sales cycles, impact on our partners, suppliers, and employees, actions that may be taken by governmental authorities, and other factors identified in the “Risk Factors” section in Part II, Item 1A of this Quarterly Report on Form 10-Q. The global supply chain and the semiconductor industry continue to experience challenges. We have experienced supply chain challenges, including chip and component shortages, which have, in certain cases, caused delays for us in acquiring chips, components and inventory and have resulted in increased costs as compared to historic levels. While we incurred increased costs and experienced increased lead time for certain product deliveries to our end-customers, we continue to work to minimize the effects from supply chain challenges.

[0001327567-23-000006:mdna:33]
[same as prior period, unchanged from 0001327567-22-000038:mdna:47]

[0001327567-23-000006:mdna:34]
[same as prior period, unchanged from 0001327567-22-000038:mdna:34]

[0001327567-23-000006:mdna:35]
[same as prior period, unchanged from 0001327567-22-000038:mdna:35]

[0001327567-23-000006:mdna:36]
[same as prior period, unchanged from 0001327567-22-000038:mdna:36]

[0001327567-23-000006:mdna:37]
|  | January 31, 2023 |  | July 31, 2022 |
|  | (in millions) |
| Total deferred revenue | $ | 7,554.0 |  |  | $ | 6,994.0 |  |
| Cash, cash equivalents, and investments | $ | 6,167.5 |  |  | $ | 4,686.4 |  |

[0001327567-23-000006:mdna:38]
|  | Three Months Ended January 31, |  | Six Months Ended January 31, |
|  | 2023 |  | 2022 |  | 2023 |  | 2022 |
|  | (dollars in millions) |
| Total revenue | $ | 1,655.1 |  |  | $ | 1,316.9 |  |  | $ | 3,218.5 |  |  | $ | 2,564.3 |  |
| Total revenue year-over-year percentage increase | 25.7 | % |  | 29.5 | % |  | 25.5 | % |  | 30.6 | % |
| Gross margin | 71.8 | % |  | 69.2 | % |  | 71.2 | % |  | 69.4 | % |
| Operating income (loss) | $ | 39.9 |  |  | $ | (73.9) |  |  | $ | 55.1 |  |  | $ | (156.6) |  |
| Operating margin | 2.4 | % |  | (5.6) | % |  | 1.7 | % |  | (6.1) | % |
| Billings | $ | 2,029.1 |  |  | $ | 1,607.9 |  |  | $ | 3,778.1 |  |  | $ | 2,989.5 |  |
| Billings year-over-year percentage increase | 26.2 | % |  | 32.4 | % |  | 26.4 | % |  | 30.1 | % |
| Cash flow provided by operating activities |  |  |  |  | $ | 1,931.3 |  |  | $ | 1,071.5 |  |
| Free cash flow (non-GAAP) |  |  |  |  | $ | 1,853.4 |  |  | $ | 956.2 |  |

[0001327567-23-000006:mdna:39]
[same as prior period, unchanged from 0001327567-22-000038:mdna:39]

[0001327567-23-000006:mdna:40]
•Billings. We define billings as total revenue plus the change in total deferred revenue, net of acquired deferred revenue, during the period. We consider billings to be a key metric used by management to manage our business. We believe billings provides investors with an important indicator of the health and visibility of our business because it includes subscription and support revenue, which is recognized ratably over the contractual service period, and product revenue, which is recognized at the time of hardware shipment or delivery of software license, provided that all other conditions for revenue recognition have been met. We consider billings to be a useful metric for management and investors, particularly if we continue to experience increased sales of subscriptions and strong renewal rates for subscription and support offerings, and as we monitor our near-term cash flows. While we believe that billings provides useful information to investors and others in understanding and evaluating our operating results in the same manner as our management, it is important to note that other companies, including companies in our industry, may not use billings, may calculate billings differently, may have different billing frequencies, or may use other financial measures to evaluate their performance, all of which could reduce the usefulness of billings as a comparative measure. We calculate billings in the following manner:

[0001327567-23-000006:mdna:41]
|  | Three Months Ended January 31, |  | Six Months Ended January 31, |
|  | 2023 |  | 2022 |  | 2023 |  | 2022 |
|  | (in millions) |  | (in millions) |
| Billings: |  |  |  |  |  |  |  |
| Total revenue | $ | 1,655.1 |  |  | $ | 1,316.9 |  |  | $ | 3,218.5 |  |  | $ | 2,564.3 |  |
| Add: change in total deferred revenue, net of acquired deferred revenue | 374.0 |  |  | 291.0 |  |  | 559.6 |  |  | 425.2 |  |
| Billings | $ | 2,029.1 |  |  | $ | 1,607.9 |  |  | $ | 3,778.1 |  |  | $ | 2,989.5 |  |

[0001327567-23-000006:mdna:42]
[same as prior period, unchanged from 0001327567-22-000038:mdna:57]

[0001327567-23-000006:mdna:43]
[same as prior period, unchanged from 0001327567-22-000038:mdna:44]

[0001327567-23-000006:mdna:44]
[same as prior period, unchanged from 0001327567-22-000038:mdna:42]

[0001327567-23-000006:mdna:45]
[same as prior period, unchanged from 0001327567-22-000038:mdna:45]

[0001327567-23-000006:mdna:46]
|  | Six Months Ended January 31, |
|  | 2023 |  | 2022 |
|  | (in millions) |
| Free cash flow (non-GAAP): |  |  |  |
| Net cash provided by operating activities | $ | 1,931.3 |  |  | $ | 1,071.5 |  |
| Less: purchases of property, equipment, and other assets | 77.9 |  |  | 115.3 |  |
| Free cash flow (non-GAAP) | $ | 1,853.4 |  |  | $ | 956.2 |  |
| Net cash used in investing activities | $ | (2,484.3) |  |  | $ | (504.2) |  |
| Net cash used in financing activities | $ | (219.7) |  |  | $ | (519.8) |  |

[0001327567-23-000006:mdna:47]
[same as prior period, unchanged from 0001327567-22-000038:mdna:72]

[0001327567-23-000006:mdna:48]
[same as prior period, unchanged from 0001327567-22-000038:mdna:48]

[0001327567-23-000006:mdna:49]
[same as prior period, unchanged from 0001327567-22-000038:mdna:49]

[0001327567-23-000006:mdna:50]
[same as prior period, unchanged from 0001327567-22-000038:mdna:50]

[0001327567-23-000006:mdna:51]
|  | Three Months Ended January 31, |  | Six Months Ended January 31, |
|  | 2023 |  | 2022 |  | 2023 |  | 2022 |
|  | Amount |  | % of Revenue |  | Amount |  | % of Revenue |  | Amount |  | % of Revenue |  | Amount |  | % of Revenue |
|  | (dollars in millions) |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product | $ | 352.9 |  |  | 21.3 | % |  | $ | 308.0 |  |  | 23.4 | % |  | $ | 682.9 |  |  | 21.2 | % |  | $ | 603.5 |  |  | 23.5 | % |
| Subscription and support | 1,302.2 |  |  | 78.7 | % |  | 1,008.9 |  |  | 76.6 | % |  | 2,535.6 |  |  | 78.8 | % |  | 1,960.8 |  |  | 76.5 | % |
| Total revenue | 1,655.1 |  |  | 100.0 | % |  | 1,316.9 |  |  | 100.0 | % |  | 3,218.5 |  |  | 100.0 | % |  | 2,564.3 |  |  | 100.0 | % |
| Cost of revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product | 100.5 |  |  | 6.1 | % |  | 97.8 |  |  | 7.4 | % |  | 220.6 |  |  | 6.9 | % |  | 186.7 |  |  | 7.3 | % |
| Subscription and support | 365.7 |  |  | 22.1 | % |  | 307.5 |  |  | 23.4 | % |  | 707.5 |  |  | 21.9 | % |  | 599.2 |  |  | 23.3 | % |
| Total cost of revenue(1) | 466.2 |  |  | 28.2 | % |  | 405.3 |  |  | 30.8 | % |  | 928.1 |  |  | 28.8 | % |  | 785.9 |  |  | 30.6 | % |
| Total gross profit | 1,188.9 |  |  | 71.8 | % |  | 911.6 |  |  | 69.2 | % |  | 2,290.4 |  |  | 71.2 | % |  | 1,778.4 |  |  | 69.4 | % |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Research and development | 404.1 |  |  | 24.4 | % |  | 359.0 |  |  | 27.3 | % |  | 775.9 |  |  | 24.1 | % |  | 698.5 |  |  | 27.2 | % |
| Sales and marketing | 625.5 |  |  | 37.8 | % |  | 528.8 |  |  | 40.1 | % |  | 1,240.5 |  |  | 38.6 | % |  | 1,034.7 |  |  | 40.4 | % |
| General and administrative | 119.4 |  |  | 7.2 | % |  | 97.7 |  |  | 7.4 | % |  | 218.9 |  |  | 6.8 | % |  | 201.8 |  |  | 7.9 | % |
| Total operating expenses(1) | 1,149.0 |  |  | 69.4 | % |  | 985.5 |  |  | 74.8 | % |  | 2,235.3 |  |  | 69.5 | % |  | 1,935.0 |  |  | 75.5 | % |
| Operating income (loss) | 39.9 |  |  | 2.4 | % |  | (73.9) |  |  | (5.6) | % |  | 55.1 |  |  | 1.7 | % |  | (156.6) |  |  | (6.1) | % |
| Interest expense | (6.9) |  |  | (0.4) | % |  | (6.8) |  |  | (0.5) | % |  | (13.7) |  |  | (0.4) | % |  | (13.7) |  |  | (0.5) | % |
| Other income (expense), net | 51.4 |  |  | 3.1 | % |  | (0.1) |  |  | — | % |  | 77.4 |  |  | 2.4 | % |  | (1.7) |  |  | (0.1) | % |
| Income (loss) before income taxes | 84.4 |  |  | 5.1 | % |  | (80.8) |  |  | (6.1) | % |  | 118.8 |  |  | 3.7 | % |  | (172.0) |  |  | (6.7) | % |
| Provision for income taxes | 0.2 |  |  | — | % |  | 12.7 |  |  | 1.0 | % |  | 14.6 |  |  | 0.5 | % |  | 25.1 |  |  | 1.0 | % |
| Net income (loss) | $ | 84.2 |  |  | 5.1 | % |  | $ | (93.5) |  |  | (7.1) | % |  | $ | 104.2 |  |  | 3.2 | % |  | $ | (197.1) |  |  | (7.7) | % |

[0001327567-23-000006:mdna:52]
[same as prior period, unchanged from 0001327567-22-000038:mdna:52]

[0001327567-23-000006:mdna:53]
[same as prior period, unchanged from 0001327567-22-000038:mdna:53]

[0001327567-23-000006:mdna:54]
|  | Three Months Ended January 31, |  | Six Months Ended January 31, |
|  | 2023 |  | 2022 |  | 2023 |  | 2022 |
|  | (in millions) |
| Cost of product revenue | $ | 2.6 |  |  | $ | 2.3 |  |  | $ | 5.0 |  |  | $ | 4.6 |  |
| Cost of subscription and support revenue | 30.7 |  |  | 27.7 |  |  | 59.5 |  |  | 54.4 |  |
| Research and development | 129.7 |  |  | 123.6 |  |  | 247.7 |  |  | 249.2 |  |
| Sales and marketing | 88.4 |  |  | 79.8 |  |  | 175.8 |  |  | 153.1 |  |
| General and administrative | 38.5 |  |  | 31.7 |  |  | 67.9 |  |  | 64.1 |  |
| Total share-based compensation | $ | 289.9 |  |  | $ | 265.1 |  |  | $ | 555.9 |  |  | $ | 525.4 |  |

[0001327567-23-000006:mdna:55]
[same as prior period, unchanged from 0001327567-22-000038:mdna:55]

[0001327567-23-000006:mdna:56]
[same as prior period, unchanged from 0001327567-22-000038:mdna:56]

[0001327567-23-000006:mdna:57]
[same as prior period, unchanged from 0001327567-22-000038:mdna:87]

[0001327567-23-000006:mdna:58]
[same as prior period, unchanged from 0001327567-22-000038:mdna:58]

[0001327567-23-000006:mdna:59]
[same as prior period, unchanged from 0001327567-22-000038:mdna:59]

[0001327567-23-000006:mdna:60]
Product revenue is derived from sales of our appliances, primarily our ML-Powered Next-Generation Firewall, which is available in a number of form factors, including as physical, virtual, and containerized appliances. Product revenue also includes revenue derived from software licenses of Panorama and SD-WAN. Our appliances and software licenses include a broad set of built-in networking and security features and functionalities. We recognize product revenue at the time of hardware shipment or delivery of software license.

[0001327567-23-000006:mdna:61]
|  | Three Months Ended January 31, |  |  |  |  |  | Six Months Ended January 31, |  |  |  |  |
|  | 2023 |  | 2022 |  | Change |  | 2023 |  | 2022 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| Product | $ | 352.9 |  |  | $ | 308.0 |  |  | $ | 44.9 |  |  | 14.6 | % |  | $ | 682.9 |  |  | $ | 603.5 |  |  | $ | 79.4 |  |  | 13.2 | % |

[0001327567-23-000006:mdna:62]
Product revenue for the three and six months ended January 31, 2023 increased compared to the same periods in 2022 driven by increased demand for our new generation of hardware products and increase in software revenue primarily due to a new go-to-market strategy for certain Network Security offerings, partially offset by a decrease in revenue from our prior generation of hardware products.

[0001327567-23-000006:mdna:63]
[same as prior period, unchanged from 0001327567-22-000038:mdna:63]

[0001327567-23-000006:mdna:64]
[same as prior period, unchanged from 0001327567-22-000038:mdna:64]

[0001327567-23-000006:mdna:65]
|  | Three Months Ended January 31, |  |  |  |  |  | Six Months Ended January 31, |  |  |  |  |
|  | 2023 |  | 2022 |  | Change |  | 2023 |  | 2022 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| Subscription | $ | 815.4 |  |  | $ | 618.0 |  |  | $ | 197.4 |  |  | 31.9 | % |  | $ | 1,579.4 |  |  | $ | 1,196.8 |  |  | $ | 382.6 |  |  | 32.0 | % |
| Support | 486.8 |  |  | 390.9 |  |  | 95.9 |  |  | 24.5 | % |  | 956.2 |  |  | 764.0 |  |  | 192.2 |  |  | 25.2 | % |
| Total subscription and support | $ | 1,302.2 |  |  | $ | 1,008.9 |  |  | $ | 293.3 |  |  | 29.1 | % |  | $ | 2,535.6 |  |  | $ | 1,960.8 |  |  | $ | 574.8 |  |  | 29.3 | % |

[0001327567-23-000006:mdna:66]
Subscription and support revenue increased for the three and six months ended January 31, 2023 compared to the same periods in 2022 due to increased demand for our subscription and support offerings from our end-customers. The mix between subscription revenue and support revenue will fluctuate over time, depending on the introduction of new subscription offerings, renewals of support services, and our ability to increase sales to new and existing end-customers.

[0001327567-23-000006:mdna:67]
[same as prior period, unchanged from 0001327567-22-000038:mdna:67]

[0001327567-23-000006:mdna:68]
|  | Three Months Ended January 31, |  |  |  |  |  | Six Months Ended January 31, |  |  |  |  |
|  | 2023 |  | 2022 |  | Change |  | 2023 |  | 2022 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| Americas | $ | 1,117.0 |  |  | $ | 915.9 |  |  | $ | 201.1 |  |  | 22.0 | % |  | $ | 2,187.7 |  |  | $ | 1,782.6 |  |  | $ | 405.1 |  |  | 22.7 | % |
| EMEA | 341.5 |  |  | 252.2 |  |  | 89.3 |  |  | 35.4 | % |  | 649.4 |  |  | 486.0 |  |  | 163.4 |  |  | 33.6 | % |
| APAC | 196.6 |  |  | 148.8 |  |  | 47.8 |  |  | 32.1 | % |  | 381.4 |  |  | 295.7 |  |  | 85.7 |  |  | 29.0 | % |
| Total revenue | $ | 1,655.1 |  |  | $ | 1,316.9 |  |  | $ | 338.2 |  |  | 25.7 | % |  | $ | 3,218.5 |  |  | $ | 2,564.3 |  |  | $ | 654.2 |  |  | 25.5 | % |

[0001327567-23-000006:mdna:69]
With respect to geographic theaters, the increase in revenue for the three and six months ended January 31, 2023 compared to the same periods in 2022 was driven primarily by the Americas, due to its larger sales force and a larger percentage of our customers located in the Americas. Revenue from our other geographic theaters, both Europe, the Middle East, and Africa (“EMEA”) and Asia Pacific and Japan (“APAC”), increased for the three and six months ended January 31, 2023 compared to the same periods in 2022 due to continued investment in our global sales force to support our growth and increase our customer base in the regions.

[0001327567-23-000006:mdna:70]
[same as prior period, unchanged from 0001327567-22-000038:mdna:99]

[0001327567-23-000006:mdna:71]
[same as prior period, unchanged from 0001327567-22-000038:mdna:73]

[0001327567-23-000006:mdna:72]
[same as prior period, unchanged from 0001327567-22-000038:mdna:70]

[0001327567-23-000006:mdna:73]
[same as prior period, unchanged from 0001327567-22-000038:mdna:71]

[0001327567-23-000006:mdna:74]
[same as prior period, unchanged from 0001327567-22-000038:mdna:74]

[0001327567-23-000006:mdna:75]
[same as prior period, unchanged from 0001327567-22-000038:mdna:75]

[0001327567-23-000006:mdna:76]
|  | Three Months Ended January 31, |  |  |  |  |  | Six Months Ended January 31, |  |  |  |  |
|  | 2023 |  | 2022 |  | Change |  | 2023 |  | 2022 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| Cost of product revenue | $ | 100.5 |  |  | $ | 97.8 |  |  | $ | 2.7 |  |  | 2.8 | % |  | $ | 220.6 |  |  | $ | 186.7 |  |  | $ | 33.9 |  |  | 18.2 | % |
| Number of employees at period end | 142 |  |  | 134 |  |  | 8 |  |  | 6.0 | % |  | 142 |  |  | 134 |  |  | 8 |  |  | 6.0 | % |

[0001327567-23-000006:mdna:77]
Cost of product revenue increased for the three and six months ended January 31, 2023 compared to the same periods in 2022 due to an increase in product volume and higher costs related to our product offerings, primarily driven by supply chain challenges, partially offset by hardware product mix.

[0001327567-23-000006:mdna:78]
[same as prior period, unchanged from 0001327567-22-000038:mdna:78]

[0001327567-23-000006:mdna:79]
[same as prior period, unchanged from 0001327567-22-000038:mdna:79]

[0001327567-23-000006:mdna:80]
|  | Three Months Ended January 31, |  |  |  |  |  | Six Months Ended January 31, |  |  |  |  |
|  | 2023 |  | 2022 |  | Change |  | 2023 |  | 2022 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| Cost of subscription and support revenue | $ | 365.7 |  |  | $ | 307.5 |  |  | $ | 58.2 |  |  | 18.9 | % |  | $ | 707.5 |  |  | $ | 599.2 |  |  | $ | 108.3 |  |  | 18.1 | % |
| Number of employees at period end | 2,751 |  |  | 2,380 |  |  | 371 |  |  | 15.6 | % |  | 2,751 |  |  | 2,380 |  |  | 371 |  |  | 15.6 | % |

[0001327567-23-000006:mdna:81]
Cost of subscription and support revenue increased for the three and six months ended January 31, 2023 compared to the same periods in 2022, primarily due to increased costs to support the growth of our subscription and support offerings. Cloud hosting service costs, which support our cloud-based subscription offerings, increased $26.8 million for the three months ended January 31, 2023 compared to the same period in 2022, and increased $45.8 million for the six months ended January 31, 2023 compared to the same period in 2022. Personnel costs grew $22.6 million to $161.2 million for the three months ended January 31, 2023 compared to the same period in 2022, and grew $42.4 million to $303.8 million for the six months ended January 31, 2023 compared to the same period in 2022, primarily due to headcount growth.

[0001327567-23-000006:mdna:82]
[same as prior period, unchanged from 0001327567-22-000038:mdna:115]

[0001327567-23-000006:mdna:83]
[same as prior period, unchanged from 0001327567-22-000038:mdna:88]

[0001327567-23-000006:mdna:84]
[same as prior period, unchanged from 0001327567-22-000038:mdna:82]

[0001327567-23-000006:mdna:85]
[same as prior period, unchanged from 0001327567-22-000038:mdna:83]

[0001327567-23-000006:mdna:86]
|  | Three Months Ended January 31, |  | Six Months Ended January 31, |
|  | 2023 |  | 2022 |  | 2023 |  | 2022 |
|  | Amount |  | Gross Margin |  | Amount |  | Gross Margin |  | Amount |  | Gross Margin |  | Amount |  | Gross Margin |
|  | (dollars in millions) |
| Product | $ | 252.4 |  |  | 71.5 | % |  | $ | 210.2 |  |  | 68.2 | % |  | $ | 462.3 |  |  | 67.7 | % |  | $ | 416.8 |  |  | 69.1 | % |
| Subscription and support | 936.5 |  |  | 71.9 | % |  | 701.4 |  |  | 69.5 | % |  | 1,828.1 |  |  | 72.1 | % |  | 1,361.6 |  |  | 69.4 | % |
| Total gross profit | $ | 1,188.9 |  |  | 71.8 | % |  | $ | 911.6 |  |  | 69.2 | % |  | $ | 2,290.4 |  |  | 71.2 | % |  | $ | 1,778.4 |  |  | 69.4 | % |

[0001327567-23-000006:mdna:87]
Product gross margin increased for the three months ended January 31, 2023 compared to the same period in 2022, primarily due to increased software revenue and favorable hardware product mix, partially offset by higher costs related to our hardware product offerings driven by supply chain challenges. Product gross margin decreased for the six months ended January 31, 2023 compared to the same period in 2022, primarily due to higher costs related to our hardware product offerings driven by supply chain challenges, partially offset by increased software revenue and favorable hardware product mix.

[0001327567-23-000006:mdna:88]
Subscription and support gross margin increased for the three and six months ended January 31, 2023 compared to the same periods in 2022, primarily due to our growth in subscription and support revenue, which outpaced the subscription and support costs.

[0001327567-23-000006:mdna:89]
[same as prior period, unchanged from 0001327567-22-000038:mdna:89]

[0001327567-23-000006:mdna:90]
Our operating expenses consist of research and development, sales and marketing, and general and administrative expenses. Personnel costs are the most significant component of operating expenses and consist of salaries, benefits, bonuses, share-based compensation, travel and entertainment, and with regard to sales and marketing expense, sales commissions. Our operating expenses also include shared costs, which consist of certain facilities, depreciation, benefits, recruiting, and information technology costs that we allocate based on headcount to each department. We expect operating expenses generally to increase in absolute dollars and decrease over the long term as a percentage of revenue as we continue to scale our business. As of January 31, 2023, we expect to recognize approximately $2.3 billion of share-based compensation expense over a weighted-average period of approximately 2.7 years, excluding additional share-based compensation expense related to any future grants of share-based awards. Share-based compensation expense is generally recognized on a straight-line basis over the requisite service periods of the awards.

[0001327567-23-000006:mdna:91]
[same as prior period, unchanged from 0001327567-22-000038:mdna:91]

[0001327567-23-000006:mdna:92]
[same as prior period, unchanged from 0001327567-22-000038:mdna:92]

[0001327567-23-000006:mdna:93]
|  | Three Months Ended January 31, |  |  |  |  |  | Six Months Ended January 31, |  |  |  |  |
|  | 2023 |  | 2022 |  | Change |  | 2023 |  | 2022 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| Research and development | $ | 404.1 |  |  | $ | 359.0 |  |  | $ | 45.1 |  |  | 12.6 | % |  | $ | 775.9 |  |  | $ | 698.5 |  |  | $ | 77.4 |  |  | 11.1 | % |
| Number of employees at period end | 3,649 |  |  | 2,880 |  |  | 769 |  |  | 26.7 | % |  | 3,649 |  |  | 2,880 |  |  | 769 |  |  | 26.7 | % |

[0001327567-23-000006:mdna:94]
Research and development expense increased for the three and six months ended January 31, 2023 compared to the same periods in 2022, primarily due to increase in personnel costs, which grew $34.5 million to $320.7 million for the three months ended January 31, 2023 compared to the same period in 2022, and grew $57.7 million to $610.8 million for the six months ended January 31, 2023 compared to the same period in 2022, largely due to headcount growth. The remaining increase in research and development expense was further driven by increased shared costs.

[0001327567-23-000006:mdna:95]
[same as prior period, unchanged from 0001327567-22-000038:mdna:129]

[0001327567-23-000006:mdna:96]
[same as prior period, unchanged from 0001327567-22-000038:mdna:100]

[0001327567-23-000006:mdna:97]
[same as prior period, unchanged from 0001327567-22-000038:mdna:95]

[0001327567-23-000006:mdna:98]
[same as prior period, unchanged from 0001327567-22-000038:mdna:96]

[0001327567-23-000006:mdna:99]
|  | Three Months Ended January 31, |  |  |  |  |  | Six Months Ended January 31, |  |  |  |  |
|  | 2023 |  | 2022 |  | Change |  | 2023 |  | 2022 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| Sales and marketing | $ | 625.5 |  |  | $ | 528.8 |  |  | $ | 96.7 |  |  | 18.3 | % |  | $ | 1,240.5 |  |  | $ | 1,034.7 |  |  | $ | 205.8 |  |  | 19.9 | % |
| Number of employees at period end | 5,778 |  |  | 4,826 |  | 952 |  |  | 19.7 | % |  | 5,778 |  |  | 4,826 |  |  | 952 |  |  | 19.7 | % |

[0001327567-23-000006:mdna:100]
Sales and marketing expense increased for the three and six months ended January 31, 2023 compared to the same periods in 2022, primarily due to increase in personnel costs, which grew $78.8 million to $482.0 million for the three months ended January 31, 2023 compared to the same period in 2022, and grew $153.9 million to $938.1 million for the six months ended January 31, 2023 compared to the same period in 2022, largely due to headcount growth and increased travel and entertainment expenses. The increase in the six months ended January 31, 2023 was further driven by increased costs associated with in-person events and go-to-market initiatives.

[0001327567-23-000006:mdna:101]
[same as prior period, unchanged from 0001327567-22-000038:mdna:101]

[0001327567-23-000006:mdna:102]
[same as prior period, unchanged from 0001327567-22-000038:mdna:102]

[0001327567-23-000006:mdna:103]
|  | Three Months Ended January 31, |  |  |  |  |  | Six Months Ended January 31, |  |  |  |  |
|  | 2023 |  | 2022 |  | Change |  | 2023 |  | 2022 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| General and administrative | $ | 119.4 |  |  | $ | 97.7 |  |  | $ | 21.7 |  |  | 22.2 | % |  | $ | 218.9 |  |  | $ | 201.8 |  |  | $ | 17.1 |  |  | 8.5 | % |
| Number of employees at period end | 1,612 |  |  | 1307 |  |  | 305 |  |  | 23.3 | % |  | 1,612 |  |  | 1,307 |  |  | 305 |  |  | 23.3 | % |

[0001327567-23-000006:mdna:104]
General and administrative expense increased for the three and six months ended January 31, 2023 compared to the same periods in 2022 primarily due to increase in personnel costs, which grew $9.4 million to $78.7 million for the three months ended January 31, 2023 compared to the same period in 2022, and grew $8.6 million to $145.3 million for the six months ended January 31, 2023 compared to the same period in 2022. The increase in personnel costs for both periods was primarily due to share-based compensation related to our recent acquisition and headcount growth. The remaining increase in general and administrative expense in both periods was primarily due to increase in acquisition-related costs and slightly higher reserves as a result of increased financing receivables.

[0001327567-23-000006:mdna:105]
[same as prior period, unchanged from 0001327567-22-000038:mdna:105]

[0001327567-23-000006:mdna:106]
Interest expense primarily consists of interest expense related to our 0.75% Convertible Senior Notes due 2023 (the “2023 Notes”) and the 0.375% Convertible Senior Notes due 2025 (the “2025 Notes,” and together with “2023 Notes,” the “Notes”).

[0001327567-23-000006:mdna:107]
|  | Three Months Ended January 31, |  |  |  | Six Months Ended January 31, |  |  |
|  | 2023 |  | 2022 |  | Change |  | 2023 |  | 2022 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| Interest expense | $ | 6.9 |  |  | $ | 6.8 |  |  | $ | 0.1 |  |  | 1.5 | % |  | $ | 13.7 |  |  | $ | 13.7 |  |  | $ | — |  |  | — | % |

[0001327567-23-000006:mdna:108]
Interest expense was relatively flat for the three and six months ended January 31, 2023 compared to the same periods in 2022.

[0001327567-23-000006:mdna:109]
[same as prior period, unchanged from 0001327567-22-000038:mdna:145]

[0001327567-23-000006:mdna:110]
[same as prior period, unchanged from 0001327567-22-000038:mdna:116]

[0001327567-23-000006:mdna:111]
[same as prior period, unchanged from 0001327567-22-000038:mdna:109]

[0001327567-23-000006:mdna:112]
[same as prior period, unchanged from 0001327567-22-000038:mdna:110]

[0001327567-23-000006:mdna:113]
|  | Three Months Ended January 31, |  |  |  | Six Months Ended January 31, |  |  |
|  | 2023 |  | 2022 |  | Change |  | 2023 |  | 2022 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| Other income (expense), net | $ | 51.4 |  |  | $ | (0.1) |  |  | $ | 51.5 |  |  | * |  | $ | 77.4 |  |  | $ | (1.7) |  |  | $ | 79.1 |  |  | * |

[0001327567-23-000006:mdna:114]
[same as prior period, unchanged from 0001327567-22-000038:mdna:112]

[0001327567-23-000006:mdna:115]
[same as prior period, unchanged from 0001327567-22-000038:mdna:113]

[0001327567-23-000006:mdna:116]
The increase in other income (expense), net for the three and six months ended January 31, 2023 compared to the same periods in 2022 was primarily due to higher interest income earned on our cash, cash equivalent, and investment balances as a result of higher interest rates for the three and six months ended January 31, 2023 compared to 2022.

[0001327567-23-000006:mdna:117]
[same as prior period, unchanged from 0001327567-22-000038:mdna:117]

[0001327567-23-000006:mdna:118]
[same as prior period, unchanged from 0001327567-22-000038:mdna:118]

[0001327567-23-000006:mdna:119]
|  | Three Months Ended January 31, |  |  |  |  |  | Six Months Ended January 31, |  |  |  |  |
|  |  |  |  |  | Change |  | 2023 |  | 2022 |  | Change |
|  | 2023 |  | 2022 |  | Amount |  | % |  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| Provision for income taxes | $ | 0.2 |  |  | $ | 12.7 |  |  | $ | (12.5) |  |  | (98.4) | % |  | $ | 14.6 |  |  | $ | 25.1 |  |  | $ | (10.5) |  |  | (41.8) | % |
| Effective tax rate | 0.2 | % |  | (15.7) | % |  |  |  |  |  | 12.3 | % |  | (14.6) | % |  |  |  |  |

[0001327567-23-000006:mdna:120]
Our provision for income taxes for the three and six months ended January 31, 2023 was primarily due to U.S. federal and state income taxes, withholding taxes, and foreign income taxes. Our effective tax rate varied for the three and six months ended January 31, 2023 compared to the same periods in 2022, primarily due to an increase in current taxes driven by capitalization of research and development expenditures with no offsetting deferred benefit as a result of our valuation allowance. This increase was offset by a release of uncertain tax positions during the three months ended January 31, 2023 resulting from a tax settlement. Refer to Note 13. Income Taxes in Part I, Item 1 of this Quarterly Report on Form 10-Q for more information.

[0001327567-23-000006:mdna:121]
[same as prior period, unchanged from 0001327567-22-000038:mdna:121]

[0001327567-23-000006:mdna:122]
|  | January 31, 2023 |  | July 31, 2022 |
|  | (in millions) |
| Working capital(1) | $ | (3,069.3) |  |  | $ | (1,891.4) |  |
| Cash, cash equivalents, and investments: |  |  |  |
| Cash and cash equivalents | $ | 1,346.3 |  |  | $ | 2,118.5 |  |
| Investments | 4,821.2 |  |  | 2,567.9 |  |
| Total cash, cash equivalents, and investments | $ | 6,167.5 |  |  | $ | 4,686.4 |  |

[0001327567-23-000006:mdna:123]
[same as prior period, unchanged from 0001327567-22-000038:mdna:123]

[0001327567-23-000006:mdna:124]
(1)Current liabilities included net carrying amounts of convertible senior notes of $3.7 billion as of both January 31, 2023 and July 31, 2022. Refer to Note 9. Debt in Part I, Item 1 of this Quarterly Report on Form 10-Q for information on the Notes.

[0001327567-23-000006:mdna:125]
As of January 31, 2023, our total cash, cash equivalents, and investments of $6.2 billion were held for general corporate purposes. As of January 31, 2023, we had no unremitted earnings when evaluating our outside basis difference relating to our U.S. investment in foreign subsidiaries. However, there could be local withholding taxes payable due to various foreign countries if certain lower tier earnings are distributed. Withholding taxes that would be payable upon remittance of these lower tier earnings are not expected to be material.

[0001327567-23-000006:mdna:126]
- 32 -

[0001327567-23-000006:mdna:127]
[same as prior period, unchanged from 0001327567-22-000038:mdna:130]

[0001327567-23-000006:mdna:128]
[same as prior period, unchanged from 0001327567-22-000038:mdna:126]

[0001327567-23-000006:mdna:129]
In July 2018, we issued the 2023 Notes with an aggregate principal amount of $1.7 billion. In June 2020, we issued the 2025 Notes with an aggregate principal amount of $2.0 billion. The 2023 Notes mature on July 1, 2023 and the 2025 Notes mature on June 1, 2025; however, under certain circumstances, holders may surrender their Notes of a series for conversion prior to the applicable maturity date. Upon conversion of the Notes of a series, we will pay cash equal to the aggregate principal amount of the Notes of such series to be converted, and, at our election, will pay or deliver cash and/or shares of our common stock for the amount of our conversion obligation in excess of the aggregate principal amount of the Notes of such series being converted. The sale price condition for the Notes was met during the fiscal quarter ended January 31, 2023, and as a result, holders may convert their Notes at any time during the fiscal quarter ending April 30, 2023. If all of the holders of the Notes converted their Notes during this period, we would be obligated to settle the $3.7 billion principal amount of the Notes in cash. We believe that our cash provided by operating activities, our existing cash, cash equivalents and investments, and existing sources of and access to financing will be sufficient to meet our anticipated cash needs should the holders choose to convert their Notes during the fiscal quarter ending April 30, 2023 or hold the 2023 Notes until maturity on July 1, 2023. As of January 31, 2023, substantially all of our Notes remained outstanding. Refer to Note 9. Debt in Part I, Item 1 of this Quarterly Report on Form 10-Q for more information on the Notes.

[0001327567-23-000006:mdna:130]
In September 2018, we entered into a credit agreement (the “Credit Agreement”) that provides for a $400.0 million unsecured revolving credit facility (the “Credit Facility”), with an option to increase the amount of the Credit Facility up to an additional $350.0 million, subject to certain conditions. As of January 31, 2023, there were no amounts outstanding and we were in compliance with all covenants under the Credit Agreement. Refer to Note 9. Debt in Part I, Item 1 of this Quarterly Report on Form 10-Q for more information on the Credit Agreement.

[0001327567-23-000006:mdna:131]
[same as prior period, unchanged from 0001327567-22-000038:mdna:132]

[0001327567-23-000006:mdna:132]
In February 2019, our board of directors authorized a $1.0 billion share repurchase program. In December 2020, August 2021, and August 2022, our board of directors authorized additional $700.0 million, $676.1 million, and $915.0 million increases to this share repurchase program, respectively, bringing the total authorization under this share repurchase program to $3.3 billion. Repurchases will be funded from available working capital and may be made at management’s discretion from time to time. The expiration date of this repurchase authorization was extended to December 31, 2023, and our repurchase program may be suspended or discontinued at any time. As of January 31, 2023, $750.0 million remained available for future share repurchases under this repurchase program. Refer to Note 11. Stockholders’ Equity in Part I, Item 1 of this Quarterly Report on Form 10-Q for more information on this repurchase program.

[0001327567-23-000006:mdna:133]
[same as prior period, unchanged from 0001327567-22-000038:mdna:134]

[0001327567-23-000006:mdna:134]
We have entered into various non-cancelable operating leases primarily for our facilities with original lease periods expiring through the year ending July 31, 2032, with the most significant leases relating to our corporate headquarters in Santa Clara, California. As of January 31, 2023, we have total operating lease obligations of $336.8 million recorded on our condensed consolidated balance sheet.

[0001327567-23-000006:mdna:135]
As of January 31, 2023, our commitments to purchase products, components, cloud and other services totaled $2.2 billion. Refer to Note 10. Commitments and Contingencies in Part I, Item 1 of this Quarterly Report on Form 10-Q for more information on these commitments.

[0001327567-23-000006:mdna:136]
[same as prior period, unchanged from 0001327567-22-000038:mdna:137]

[0001327567-23-000006:mdna:137]
The following table summarizes our cash flows for the six months ended January 31, 2023 and 2022:

[0001327567-23-000006:mdna:138]
|  | Six Months Ended January 31, |
|  | 2023 |  | 2022 |
|  | (in millions) |
| Net cash provided by operating activities | $ | 1,931.3 |  |  | $ | 1,071.5 |  |
| Net cash used in investing activities | (2,484.3) |  |  | (504.2) |  |
| Net cash used in financing activities | (219.7) |  |  | (519.8) |  |
| Net increase (decrease) in cash, cash equivalents, and restricted cash | $ | (772.7) |  |  | $ | 47.5 |  |

[0001327567-23-000006:mdna:139]
- 33 -

[0001327567-23-000006:mdna:140]
[same as prior period, unchanged from 0001327567-22-000038:mdna:146]

[0001327567-23-000006:mdna:141]
[same as prior period, unchanged from 0001327567-22-000038:mdna:140]

[0001327567-23-000006:mdna:142]
[same as prior period, unchanged from 0001327567-22-000038:mdna:141]

[0001327567-23-000006:mdna:143]
[same as prior period, unchanged from 0001327567-22-000038:mdna:142]

[0001327567-23-000006:mdna:144]
[same as prior period, unchanged from 0001327567-22-000038:mdna:143]

[0001327567-23-000006:mdna:145]
Cash provided by operating activities during the six months ended January 31, 2023 was $1.9 billion, an increase of $859.8 million compared to the same period in 2022. The increase was primarily due to growth of our business as reflected by increases in collections during the six months ended January 31, 2023, partially offset by higher cash expenditure to support our business growth.

[0001327567-23-000006:mdna:146]
[same as prior period, unchanged from 0001327567-22-000038:mdna:147]

[0001327567-23-000006:mdna:147]
[same as prior period, unchanged from 0001327567-22-000038:mdna:148]

[0001327567-23-000006:mdna:148]
Cash used in investing activities during the six months ended January 31, 2023 was $2.5 billion, an increase of $2.0 billion compared to the same period in 2022. The increase was primarily due to an increase in purchases of investments and increase in net cash payments for business acquisitions, offset by an increase in proceeds from sales and maturities of investments during the six months ended January 31, 2023.

[0001327567-23-000006:mdna:149]
[same as prior period, unchanged from 0001327567-22-000038:mdna:150]

[0001327567-23-000006:mdna:150]
[same as prior period, unchanged from 0001327567-22-000038:mdna:151]

[0001327567-23-000006:mdna:151]
Cash used in financing activities during the six months ended January 31, 2023 was $219.7 million, a decrease of $300.1 million compared to the same period in 2022. The decrease was primarily due to decrease in repurchases of our common stock during the six months ended January 31, 2023.

[0001327567-23-000006:mdna:152]
[same as prior period, unchanged from 0001327567-22-000038:mdna:153]

[0001327567-23-000006:mdna:153]
[same as prior period, unchanged from 0001327567-22-000038:mdna:154]

[0001327567-23-000006:mdna:154]
[same as prior period, unchanged from 0001327567-22-000038:mdna:155]

[0001327567-23-000006:mdna:155]
- 34 -

[0001327567-23-000006:mdna:156]
Table of Content
