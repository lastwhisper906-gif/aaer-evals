# PANW 8-K — 0001327567-23-000005 filed 2023-02-21

## item codes, every 8-K on or before 2023-02-22

- 2023-02-21 0001327567-23-000005 — 2.02, 9.01
- 2022-12-16 0001193125-22-307346 — 5.02, 5.07
- 2022-11-17 0001327567-22-000035 — 2.02, 9.01
- 2022-11-15 0001193125-22-285017 — 8.01
- 2022-08-22 0001327567-22-000020 — 2.02, 8.01, 9.01
- 2022-05-23 0001193125-22-157474 — 5.02, 5.03, 9.01
- 2022-05-19 0001327567-22-000014 — 2.02, 9.01
- 2022-02-23 0001193125-22-049906 — 5.02
- 2022-02-22 0001327567-22-000006 — 2.02, 9.01
- 2021-12-15 0001193125-21-358074 — 5.02, 5.07
- 2021-11-18 0001327567-21-000037 — 2.02, 9.01
- 2021-10-12 0001193125-21-296438 — 3.01, 7.01, 9.01
- 2021-09-13 0001193125-21-270979 — 7.01, 9.01
- 2021-09-08 0001193125-21-267862 — 5.02, 9.01
- 2021-08-23 0001327567-21-000020 — 2.02, 9.01
- 2021-08-12 0001193125-21-244832 — 5.02, 9.01
- 2021-05-20 0001327567-21-000012 — 2.02, 9.01
- 2021-05-18 0001193125-21-164169 — 5.02 — amendment of 0001193125-21-162161
- 2021-05-14 0001193125-21-162161 — 5.02, 9.01
- 2021-03-19 0001193125-21-087516 — 5.02, 9.01
- 2021-02-22 0001628280-21-002659 — 2.02, 9.01
- 2021-02-22 0001193125-21-049293 — 5.02, 9.01
- 2020-12-18 0001193125-20-321568 — 8.01, 9.01
- 2020-12-16 0001193125-20-319091 — 3.02 — amendment of 0001193125-20-291707
- 2020-12-10 0001193125-20-314920 — 5.07
- 2020-12-08 0001193125-20-312056 — 5.02, 8.01, 9.01
- 2020-11-16 0001327567-20-000037 — 2.02, 9.01
- 2020-11-12 0001193125-20-291707 — 3.02
- 2020-10-19 0001193125-20-272060 — 5.02
- 2020-08-24 0001327567-20-000025 — 2.02, 9.01
- 2020-06-23 0001193125-20-176553 — 5.02, 9.01
- 2020-06-22 0001193125-20-175603 — 5.02, 9.01
- 2020-06-08 0001193125-20-163579 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2020-05-21 0001327567-20-000015 — 2.02, 9.01
- 2020-02-27 0001193125-20-050335 — 1.01, 2.03
- 2020-02-24 0001327567-20-000002 — 2.02, 9.01
- 2019-12-19 0001193125-19-319166 — 1.02, 9.01
- 2019-12-10 0001193125-19-310251 — 5.07
- 2019-11-25 0001327567-19-000036 — 2.02, 9.01
- 2019-11-25 0001193125-19-299886 — 5.02, 8.01 — amendment of 0001327567-19-000011
- 2019-10-22 0001193125-19-271660 — 5.02
- 2019-09-06 0001327567-19-000026 — 9.01 — amendment of 0001327567-19-000023
- 2019-09-04 0001327567-19-000023 — 2.02, 7.01, 9.01
- 2019-07-11 0001193125-19-192415 — 5.02, 9.01
- 2019-05-29 0001327567-19-000014 — 2.02, 9.01
- 2019-04-15 0001327567-19-000011 — 5.02, 9.01
- 2019-04-01 0001193125-19-094613 — 8.01, 9.01
- 2019-03-28 0001193125-19-090572 — 3.02 — amendment of 0001327567-19-000003
- 2019-02-26 0001327567-19-000006 — 2.02, 8.01, 9.01
- 2019-02-19 0001327567-19-000003 — 3.02
- 2018-12-11 0001327567-18-000033 — 5.07
- 2018-11-29 0001327567-18-000029 — 2.02, 9.01
- 2018-10-15 0001193125-18-299312 — 5.02, 9.01
- 2018-09-25 0001193125-18-282542 — 5.02
- 2018-09-14 0001193125-18-274239 — 5.03, 9.01
- 2018-09-06 0001327567-18-000018 — 1.01, 2.02, 2.03, 9.01
- 2018-07-13 0001193125-18-217281 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2018-06-04 0001327567-18-000011 — 2.02, 5.02, 9.01
- 2018-02-26 0001327567-18-000004 — 2.02, 5.02, 7.01, 9.01
- 2017-12-12 0001193125-17-367477 — 5.07
- 2017-11-20 0001327567-17-000032 — 2.02, 5.02, 9.01
- 2017-08-31 0001327567-17-000021 — 2.02, 5.02, 9.01
- 2017-05-31 0001327567-17-000016 — 2.02, 9.01
- 2017-02-28 0001327567-17-000005 — 2.02, 8.01, 9.01
- 2016-12-12 0001193125-16-790757 — 5.07
- 2016-11-21 0001327567-16-000071 — 2.02, 9.01
- 2016-10-24 0001193125-16-745121 — 5.02, 9.01
- 2016-08-30 0001327567-16-000057 — 2.02, 5.03, 8.01, 9.01
- 2016-08-22 0001193125-16-687588 — 5.02, 9.01
- 2016-05-26 0001327567-16-000051 — 2.02, 9.01
- 2016-02-25 0001327567-16-000044 — 2.02, 5.02, 9.01
- 2015-12-14 0001327567-15-000038 — 5.07
- 2015-12-14 0001193125-15-402588 — 1.01, 9.01
- 2015-11-23 0001327567-15-000033 — 2.02, 9.01
- 2015-10-19 0001193125-15-347005 — 1.01, 9.01 — amendment, the index does not say of what
- 2015-09-09 0001327567-15-000022 — 2.02, 9.01
- 2015-08-19 0001193125-15-296115 — 1.01, 2.03
- 2015-06-01 0001193125-15-207786 — 1.01, 2.03
- 2015-05-27 0001327567-15-000015 — 2.02, 9.01
- 2015-03-02 0001327567-15-000006 — 2.02, 9.01
- 2014-12-15 0001327567-14-000046 — 5.07
- 2014-11-24 0001327567-14-000040 — 2.02, 9.01
- 2014-09-22 0001193125-14-348581 — 5.02, 9.01
- 2014-09-09 0001327567-14-000025 — 2.02, 9.01
- 2014-07-01 0001193125-14-257824 — 1.01, 2.03, 3.02, 9.01
- 2014-06-26 0001193125-14-249529 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2014-06-20 0001327567-14-000020 — 9.01 — amendment of 0001193125-14-140511
- 2014-06-04 0001327567-14-000016 — 3.02
- 2014-05-30 0001193125-14-218158 — 2.02 — amendment, the index does not say of what
- 2014-05-28 0001193125-14-215060 — 1.01, 2.02, 3.02, 9.01
- 2014-04-11 0001193125-14-140511 — 2.01, 3.02, 7.01, 9.01
- 2014-03-24 0001193125-14-111318 — 1.01, 3.02, 7.01, 9.01
- 2014-03-13 0001327567-14-000009 — 5.02
- 2014-02-24 0001193125-14-063754 — 2.02, 9.01
- 2013-12-12 0001327567-13-000040 — 5.07
- 2013-11-25 0001327567-13-000033 — 2.02, 9.01
- 2013-09-30 0001193125-13-384966 — 8.01
- 2013-09-09 0001193125-13-361421 — 2.02, 9.01
- 2013-05-30 0001193125-13-241542 — 2.02, 5.02, 9.01
- 2013-03-11 0001193125-13-101082 — 5.02, 9.01
- 2013-02-28 0001193125-13-084193 — 2.02, 9.01
- 2012-12-14 0001193125-12-503335 — 5.07
- 2012-12-06 0001193125-12-493700 — 2.02, 9.01
- 2012-09-24 0001193125-12-401534 — 1.01, 2.03
- 2012-09-20 0001193125-12-398433 — 5.02, 9.01
- 2012-09-10 0001193125-12-386605 — 2.02, 9.01

## late-filing notifications on or before 2023-02-22

- none on or before 2023-02-22

## item 2.02 — earnings release, exhibit 99.1

[0001327567-23-000005:8k_2_02:1]
EX-99.1
2
ex991q223earningsrelease.htm
EX-99.1

[0001327567-23-000005:8k_2_02:2]
Document

[0001327567-23-000005:8k_2_02:3]
Exhibit 99.1

[0001327567-23-000005:8k_2_02:4]
Palo Alto Networks Reports Fiscal Second Quarter 2023 Financial Results

[0001327567-23-000005:8k_2_02:5]
•Fiscal second quarter revenue and billings each grew 26% year over year to $1.7 billion and $2.0 billion, respectively

[0001327567-23-000005:8k_2_02:6]
•Trailing 12-months GAAP net income positive for period ending January 31, 2023

[0001327567-23-000005:8k_2_02:7]
•Remaining performance obligation grew 39% year over year to $8.8 billion

[0001327567-23-000005:8k_2_02:8]
SANTA CLARA, Calif., Feb. 21, 2023 — Palo Alto Networks (NASDAQ: PANW), the global cybersecurity leader, announced today financial results for its fiscal second quarter 2023, ended January 31, 2023.

[0001327567-23-000005:8k_2_02:9]
Total revenue for the fiscal second quarter 2023 grew 26% year over year to $1.7 billion, compared with total revenue of $1.3 billion for the fiscal second quarter 2022. GAAP net income for the fiscal second quarter 2023 was $84.2 million, or $0.25 per diluted share, compared with GAAP net loss of $93.5 million, or $0.32 per diluted share, for the fiscal second quarter 2022.

[0001327567-23-000005:8k_2_02:10]
Non-GAAP net income for the fiscal second quarter 2023 was $331.7 million, or $1.05 per diluted share, compared with non-GAAP net income of $185.0 million, or $0.58 per diluted share, for the fiscal second quarter 2022. A reconciliation between GAAP and non-GAAP information is contained in the tables below.

[0001327567-23-000005:8k_2_02:11]
"We continue to see our teams execute well in the midst of macroeconomic challenges, helping customers consolidate their security architectures," said Nikesh Arora, chairman and CEO of Palo Alto Networks. "The performance of our software-based and cloud-delivered portfolio validates the significant investments we have made over the last several years and has enabled us to raise our billings and NGS ARR guidance."

[0001327567-23-000005:8k_2_02:12]
"Our focus on driving profitable growth is reflected in our Q2 results," said Dipak Golechha, chief financial officer of Palo Alto Networks. "As a result, we are raising our cash flow margin and operating profitability targets as we remain focused on driving efficiency in our business."

[0001327567-23-000005:8k_2_02:13]
Financial Outlook

[0001327567-23-000005:8k_2_02:14]
Palo Alto Networks provides guidance based on current market conditions and expectations.

[0001327567-23-000005:8k_2_02:15]
For the fiscal third quarter 2023, we expect:

[0001327567-23-000005:8k_2_02:16]
•Total billings in the range of $2.20 billion to $2.25 billion, representing year-over-year growth of between 22% and 25%.

[0001327567-23-000005:8k_2_02:17]
•Total revenue in the range of $1.695 billion to $1.725 billion, representing year-over-year growth of between 22% and 24%.

[0001327567-23-000005:8k_2_02:18]
•Diluted non-GAAP net income per share in the range of $0.90 to $0.94, using 321 million to 327 million shares outstanding.

[0001327567-23-000005:8k_2_02:19]
For the fiscal year 2023, we are updating guidance and expect:

[0001327567-23-000005:8k_2_02:20]
•Total billings in the range of $9.10 billion to $9.20 billion, representing year-over-year growth of between 22% and 23%.

[0001327567-23-000005:8k_2_02:21]
•Total revenue in the range of $6.85 billion to $6.91 billion, representing year-over-year growth of between 25% and 26%.

[0001327567-23-000005:8k_2_02:22]
•Diluted non-GAAP net income per share in the range of $3.97 to $4.03, using 320 million to 326 million shares outstanding.

[0001327567-23-000005:8k_2_02:23]
•Adjusted free cash flow margin in the range of 36.5% to 37.5%.

[0001327567-23-000005:8k_2_02:24]
Guidance for non-GAAP financial measures excludes share-based compensation-related charges (including share-based payroll tax expense), acquisition-related costs, amortization expense of acquired intangible assets, litigation-related charges, including legal settlements, restructuring and other costs, non-cash charges related to convertible notes, foreign currency gains (losses), and income tax and other tax adjustments, along with certain non-recurring expenses and certain non-recurring cash flows. We have not reconciled diluted non-GAAP net income per share guidance to GAAP net income (loss) per diluted share or adjusted free cash flow margin guidance to GAAP net cash from operating activities because we do not provide guidance on GAAP net income (loss) or net cash from operating activities and would not be able to present the various reconciling cash and non-cash items between GAAP and non-GAAP financial measures because certain items that impact these measures are uncertain or out of our control, or cannot be reasonably predicted, including share-based compensation expense, without unreasonable effort. The actual amounts of such reconciling items will have a significant impact on the company's GAAP net income (loss) per diluted share and GAAP net cash from operating activities.

[0001327567-23-000005:8k_2_02:25]
Earnings Call Information

[0001327567-23-000005:8k_2_02:26]
Palo Alto Networks will host a video webcast for analysts and investors to discuss the company’s fiscal second quarter 2023 results as well as the outlook for its fiscal third quarter 2023 today at 4:30 p.m. Eastern time/1:30 p.m. Pacific time. Open to the public, investors may access the webcast, supplemental financial information and earnings slides from the “Investors” section of the company’s website at investors.paloaltonetworks.com. A replay will be available three hours after the conclusion of the webcast and archived for one year.

[0001327567-23-000005:8k_2_02:27]
Forward-Looking Statements

[0001327567-23-000005:8k_2_02:28]
This press release contains forward-looking statements that involve risks, uncertainties, and assumptions including statements regarding our financial outlook for the fiscal third quarter 2023 and fiscal year 2023. There are a significant number of factors that could cause actual results to differ materially from statements made in this press release, including: developments and changes in general market, political, economic, and business conditions; our ability to obtain adequate supply of our products from our third-party manufacturing partners; the duration and global impact of COVID-19; risks associated with managing our growth; risks associated with new products and subscription and support offerings, including the discovery of software bugs; shifts in priorities or delays in the development or release of new subscription offerings, or the failure to timely develop and achieve market acceptance of new products and subscriptions as well as existing products and subscription and support offerings; rapidly evolving technological developments in the market for security products and subscription and support offerings; our customers’ purchasing decisions and the length of sales cycles; our competition; our ability to attract and retain new customers; our ability as an organization to acquire and integrate other companies, products, or technologies in a successful manner; the effects of supply chain constraints and the global chip and component shortages and other factors affecting the manufacture, delivery, and cost of certain of our products; our debt repayment obligations; and our share repurchase program, which may not be fully consummated or enhance shareholder value, and any share repurchases which could affect the price of our common stock.

[0001327567-23-000005:8k_2_02:29]
Additional risks and uncertainties that could affect our financial results are included under the captions "Risk Factors" and "Management's Discussion and Analysis of Financial Condition and Results of Operations" in our Quarterly Report on Form 10-Q filed with the SEC on November 18, 2022, which is available on our website at investors.paloaltonetworks.com and on the SEC's website at www.sec.gov. Additional information will also be set forth in other filings that we make

[0001327567-23-000005:8k_2_02:30]
3

[0001327567-23-000005:8k_2_02:31]
with the SEC from time to time. All forward-looking statements in this press release are based on information available to us as of the date hereof, and we do not assume any obligation to update the forward-looking statements provided to reflect events that occur or circumstances that exist after the date on which they were made.

[0001327567-23-000005:8k_2_02:32]
Non-GAAP Financial Measures and Other Key Metrics

[0001327567-23-000005:8k_2_02:33]
Palo Alto Networks has provided in this press release financial information that has not been prepared in accordance with generally accepted accounting principles in the United States (GAAP). The company uses these non-GAAP financial measures and other key metrics internally in analyzing its financial results and believes that the use of these non-GAAP financial measures and key metrics are useful to investors as an additional tool to evaluate ongoing operating results and trends, and in comparing the company’s financial results with other companies in its industry, many of which present similar non-GAAP financial measures or key metrics.

[0001327567-23-000005:8k_2_02:34]
The presentation of these non-GAAP financial measures and key metrics are not meant to be considered in isolation or as a substitute for comparable GAAP financial measures and should be read only in conjunction with the company’s consolidated financial statements prepared in accordance with GAAP. A reconciliation of the company’s historical non-GAAP financial measures to their most directly comparable GAAP measures has been provided in the financial statement tables included in this press release, and investors are encouraged to review these reconciliations.

[0001327567-23-000005:8k_2_02:35]
Non-GAAP net income and net income per share, diluted. Palo Alto Networks defines non-GAAP net income as net income (loss) plus share-based compensation-related charges, including share-based payroll tax expense, acquisition-related costs, amortization expense of acquired intangible assets, litigation-related charges, including legal settlements, restructuring and other costs, and non-cash charges related to convertible notes. The company also excludes from non-GAAP net income foreign currency gains (losses) and tax adjustments to provide a complete picture of the company’s recurring core business operating results. The company defines non-GAAP net income per share, diluted, as non-GAAP net income divided by the weighted-average diluted shares outstanding, which includes the potentially dilutive effect of the company’s employee equity incentive plan awards and the company’s convertible senior notes outstanding and related warrants, after giving effect to the anti-dilutive impact of the company’s note hedge agreements, which reduces the potential economic dilution that otherwise would occur upon conversion of the company’s convertible senior notes. Under GAAP, the anti-dilutive impact of the note hedge is not

[0001327567-23-000005:8k_2_02:36]
reflected in diluted shares outstanding. The company believes that excluding these items from non-GAAP net income and net income per share, diluted, provides management and investors with greater visibility into the underlying performance of the company’s core business operating results, meaning its operating performance excluding these items and, from time to time, other discrete charges that are infrequent in nature, over multiple periods.

[0001327567-23-000005:8k_2_02:37]
Billings. Palo Alto Networks defines billings as total revenue plus the change in total deferred revenue, net of acquired deferred revenue, during the period. The company considers billings to be a key metric used by management to manage the company’s business and believes billings provides investors with an important indicator of the health and visibility of the company’s business because it includes subscription and support revenue, which is recognized ratably over the contractual service period, and product revenue, which is recognized at the time of hardware shipment or delivery of software license, provided that all other conditions for revenue recognition have been met. The company considers billings to be a useful metric for management and investors, particularly if sales of subscriptions continue to increase and the company experiences strong renewal rates for subscriptions and support.

[0001327567-23-000005:8k_2_02:38]
Investors are cautioned that there are a number of limitations associated with the use of non-GAAP financial measures and key metrics as analytical tools. In particular, the billings metric reported by the company includes amounts that have not yet been recognized as revenue. Additionally, many of the adjustments to the company’s GAAP financial measures reflect the exclusion of items that are recurring and will be reflected in the company’s financial results for the foreseeable future, such as share-based compensation, which is an important part of Palo Alto Networks employees’ compensation and impacts their performance. Furthermore, these non-GAAP financial measures are not based on any standardized methodology prescribed by GAAP, and the components that Palo Alto Networks excludes in its calculation of non-GAAP financial measures may differ from the components that its peer companies exclude when they report their non-GAAP results of operations. Palo Alto Networks compensates for these limitations by providing specific information regarding the GAAP amounts excluded from these non-GAAP financial measures. In the future, the company may also exclude non-recurring expenses and other expenses that do not reflect the company’s core business operating results.

[0001327567-23-000005:8k_2_02:39]
5

[0001327567-23-000005:8k_2_02:40]
About Palo Alto Networks

[0001327567-23-000005:8k_2_02:41]
Palo Alto Networks is the world’s cybersecurity leader. We innovate to outpace cyberthreats, so organizations can embrace technology with confidence. We provide next-gen cybersecurity to thousands of customers globally, across all sectors. Our best-in-class cybersecurity platforms and services are backed by industry-leading threat intelligence and strengthened by state-of-the-art automation. Whether deploying our products to enable the Zero Trust Enterprise, responding to a security incident, or partnering to deliver better security outcomes through a world-class partner ecosystem, we’re committed to helping ensure each day is safer than the one before. It’s what makes us the cybersecurity partner of choice.

[0001327567-23-000005:8k_2_02:42]
At Palo Alto Networks, we’re committed to bringing together the very best people in service of our mission, so we’re also proud to be the cybersecurity workplace of choice, recognized among Newsweek’s Most Loved Workplaces (2022, 2021), Comparably Best Companies for Diversity (2021), and HRC Best Places for LGBTQ Equality (2022). For more information, visit www.paloaltonetworks.com.

[0001327567-23-000005:8k_2_02:43]
Palo Alto Networks and the Palo Alto Networks logo are trademarks of Palo Alto Networks, Inc. in the United States and in jurisdictions throughout the world. All other trademarks, trade names, or service marks used or mentioned herein belong to their respective owners.

[0001327567-23-000005:8k_2_02:44]
Media Contact:

[0001327567-23-000005:8k_2_02:45]
Andria Leaf

[0001327567-23-000005:8k_2_02:46]
Director of Corporate Communications, Palo Alto Networks

[0001327567-23-000005:8k_2_02:47]
press@paloaltonetworks.com

[0001327567-23-000005:8k_2_02:48]
Investor Relations Contact:

[0001327567-23-000005:8k_2_02:49]
Clay Bilby

[0001327567-23-000005:8k_2_02:50]
Head of Investor Relations, Palo Alto Networks

[0001327567-23-000005:8k_2_02:51]
ir@paloaltonetworks.com

[0001327567-23-000005:8k_2_02:52]
| Palo Alto Networks, Inc. |
| Preliminary Condensed Consolidated Statements of Operations |
| (In millions, except per share data) |
| (Unaudited) |
|  | Three Months Ended |  | Six Months Ended |
|  | January 31, |  | January 31, |
|  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Revenue: |  |  |  |  |  |  |  |
| Product | $ | 352.9 |  |  | $ | 308.0 |  |  | $ | 682.9 |  |  | $ | 603.5 |  |
| Subscription and support | 1,302.2 |  |  | 1,008.9 |  |  | 2,535.6 |  |  | 1,960.8 |  |
| Total revenue | 1,655.1 |  |  | 1,316.9 |  |  | 3,218.5 |  |  | 2,564.3 |  |
| Cost of revenue: |  |  |  |  |  |  |  |
| Product | 100.5 |  |  | 97.8 |  |  | 220.6 |  |  | 186.7 |  |
| Subscription and support | 365.7 |  |  | 307.5 |  |  | 707.5 |  |  | 599.2 |  |
| Total cost of revenue | 466.2 |  |  | 405.3 |  |  | 928.1 |  |  | 785.9 |  |
| Total gross profit | 1,188.9 |  |  | 911.6 |  |  | 2,290.4 |  |  | 1,778.4 |  |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | 404.1 |  |  | 359.0 |  |  | 775.9 |  |  | 698.5 |  |
| Sales and marketing | 625.5 |  |  | 528.8 |  |  | 1,240.5 |  |  | 1,034.7 |  |
| General and administrative | 119.4 |  |  | 97.7 |  |  | 218.9 |  |  | 201.8 |  |
| Total operating expenses | 1,149.0 |  |  | 985.5 |  |  | 2,235.3 |  |  | 1,935.0 |  |
| Operating income (loss) | 39.9 |  |  | (73.9) |  |  | 55.1 |  |  | (156.6) |  |
| Interest expense | (6.9) |  |  | (6.8) |  |  | (13.7) |  |  | (13.7) |  |
| Other income (expense), net | 51.4 |  |  | (0.1) |  |  | 77.4 |  |  | (1.7) |  |
| Income (loss) before income taxes | 84.4 |  |  | (80.8) |  |  | 118.8 |  |  | (172.0) |  |
| Provision for income taxes | 0.2 |  |  | 12.7 |  |  | 14.6 |  |  | 25.1 |  |
| Net income (loss) | $ | 84.2 |  |  | $ | (93.5) |  |  | $ | 104.2 |  |  | $ | (197.1) |  |
| Net income (loss) per share, basic | $ | 0.28 |  |  | $ | (0.32) |  |  | $ | 0.35 |  |  | $ | (0.67) |  |
| Net income (loss) per share, diluted | $ | 0.25 |  |  | $ | (0.32) |  |  | $ | 0.31 |  |  | $ | (0.67) |  |
| Weighted-average shares used to compute net income (loss) per share, basic | 302.3 |  |  | 294.5 |  |  | 301.0 |  |  | 293.7 |  |
| Weighted-average shares used to compute net income (loss) per share, diluted | 331.6 |  |  | 294.5 |  |  | 335.0 |  |  | 293.7 |  |

[0001327567-23-000005:8k_2_02:53]
7

[0001327567-23-000005:8k_2_02:54]
| Palo Alto Networks, Inc. |
| Reconciliation of GAAP to Non-GAAP Financial Measures |
| (In millions, except per share amounts) |
| (Unaudited) |
|  | Three Months Ended |  | Six Months Ended |
|  | January 31, |  | January 31, |
|  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| GAAP net income (loss) | $ | 84.2 |  |  | $ | (93.5) |  |  | $ | 104.2 |  |  | $ | (197.1) |  |
| Share-based compensation-related charges | 298.6 |  |  | 283.3 |  |  | 577.5 |  |  | 553.5 |  |
| Acquisition-related costs(1) | 12.1 |  |  | — |  |  | 12.1 |  |  | 3.1 |  |
| Amortization expense of acquired intangible assets | 24.4 |  |  | 31.5 |  |  | 53.1 |  |  | 63.1 |  |
| Litigation-related charges(2) | 1.8 |  |  | 1.8 |  |  | 3.6 |  |  | 3.6 |  |
| Restructuring and other costs(3) | — |  |  | — |  |  | (2.2) |  |  | — |  |
| Non-cash charges related to convertible notes(4) | 1.7 |  |  | 1.8 |  |  | 3.5 |  |  | 3.6 |  |
| Foreign currency (gain) loss associated with non-GAAP adjustments | 2.3 |  |  | (0.5) |  |  | 0.5 |  |  | 0.6 |  |
| Income tax and other tax adjustments(5) | (93.4) |  |  | (39.4) |  |  | (154.2) |  |  | (75.1) |  |
| Non-GAAP net income | $ | 331.7 |  |  | $ | 185.0 |  |  | $ | 598.1 |  |  | $ | 355.3 |  |
| GAAP net income (loss) per share, diluted | $ | 0.25 |  |  | $ | (0.32) |  |  | $ | 0.31 |  |  | $ | (0.67) |  |
| Share-based compensation-related charges | 0.94 |  |  | 0.90 |  |  | 1.82 |  |  | 1.82 |  |
| Acquisition-related costs(1) | 0.04 |  |  | 0.00 |  |  | 0.04 |  |  | 0.01 |  |
| Amortization expense of acquired intangible assets | 0.07 |  |  | 0.11 |  |  | 0.16 |  |  | 0.21 |  |
| Litigation-related charges(2) | 0.01 |  |  | 0.01 |  |  | 0.01 |  |  | 0.01 |  |
| Restructuring and other costs(3) | 0.00 |  |  | 0.00 |  |  | (0.01) |  |  | 0.00 |  |
| Non-cash charges related to convertible notes(4) | 0.01 |  |  | 0.01 |  |  | 0.01 |  |  | 0.01 |  |
| Foreign currency (gain) loss associated with non-GAAP adjustments | 0.01 |  |  | 0.00 |  |  | 0.00 |  |  | 0.00 |  |
| Income tax and other tax adjustments(5) | (0.28) |  |  | (0.13) |  |  | (0.46) |  |  | (0.26) |  |
| Non-GAAP net income per share, diluted | $ | 1.05 |  |  | $ | 0.58 |  |  | $ | 1.88 |  |  | $ | 1.13 |  |
| GAAP weighted-average shares used to compute net income (loss) per share, diluted | 331.6 |  |  | 294.5 |  |  | 335.0 |  |  | 293.7 |  |
| Weighted-average dilutive effect of potentially dilutive securities(6) | — |  |  | 42.4 |  |  | — |  |  | 38.1 |  |
| Weighted-average anti-dilutive impact of note hedge agreements | (15.2) |  |  | (18.0) |  |  | (16.5) |  |  | (16.5) |  |
| Non-GAAP weighted-average shares used to compute net income per share, diluted | 316.4 |  |  | 318.9 |  |  | 318.5 |  |  | 315.3 |  |

[0001327567-23-000005:8k_2_02:55]
(1)    Consists of acquisition transaction costs, share-based compensation related to the cash settlement of certain equity awards, and costs to terminate certain employment, operating lease, and other contracts of the acquired companies.

[0001327567-23-000005:8k_2_02:56]
(2)    Consists of the amortization of intellectual property licenses and covenant not to sue.

[0001327567-23-000005:8k_2_02:57]
(3)    Consists of adjustments to restructuring and other costs.

[0001327567-23-000005:8k_2_02:58]
(4)     Consists primarily of non-cash interest expense for amortization of debt discount and issuance costs related to the company's convertible senior notes.

[0001327567-23-000005:8k_2_02:59]
(5)    Consists of income tax adjustments related to our long-term non-GAAP effective tax rate. In Q2'23, it included a tax benefit from a release of tax reserves related to uncertain tax positions resulting from a tax settlement.

[0001327567-23-000005:8k_2_02:60]
(6)    Consists of potentially dilutive effect of employee equity incentive plan awards and convertible senior notes outstanding and related warrants in periods with GAAP net loss position as they are excluded from GAAP weighted-average shares.

[0001327567-23-000005:8k_2_02:61]
| Palo Alto Networks, Inc. |
| Calculation of Billings |
| (In millions) |
| (Unaudited) |
|  | Three Months Ended |  | Six Months Ended |
|  | January 31, |  | January 31, |
|  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Total revenue | $ | 1,655.1 |  |  | $ | 1,316.9 |  |  | $ | 3,218.5 |  |  | $ | 2,564.3 |  |
| Add: change in total deferred revenue, net of acquired deferred revenue | 374.0 |  |  | 291.0 |  |  | 559.6 |  |  | 425.2 |  |
| Billings | $ | 2,029.1 |  |  | $ | 1,607.9 |  |  | $ | 3,778.1 |  |  | $ | 2,989.5 |  |

[0001327567-23-000005:8k_2_02:62]
9

[0001327567-23-000005:8k_2_02:63]
| Palo Alto Networks, Inc. |
| Preliminary Condensed Consolidated Balance Sheets |
| (In millions) |
|  | January 31, 2023 |  | July 31, 2022 |
|  | (unaudited) |  |  |
| Assets |  |  |  |
| Current assets: |  |  |  |
| Cash and cash equivalents | $ | 1,346.3 |  |  | $ | 2,118.5 |  |
| Short-term investments | 2,000.6 |  |  | 1,516.0 |  |
| Accounts receivable, net | 1,278.1 |  |  | 2,142.5 |  |
| Short-term deferred contract costs | 313.4 |  |  | 317.7 |  |
| Prepaid expenses and other current assets | 467.4 |  |  | 320.2 |  |
| Total current assets | 5,405.8 |  |  | 6,414.9 |  |
| Property and equipment, net | 344.7 |  |  | 357.8 |  |
| Operating lease right-of-use assets | 251.1 |  |  | 242.0 |  |
| Long-term investments | 2,820.6 |  |  | 1,051.9 |  |
| Long-term deferred contract costs | 511.3 |  |  | 550.1 |  |
| Goodwill | 2,912.3 |  |  | 2,747.7 |  |
| Intangible assets, net | 361.7 |  |  | 384.5 |  |
| Other assets | 555.9 |  |  | 504.7 |  |
| Total assets | $ | 13,163.4 |  |  | $ | 12,253.6 |  |
| Liabilities and stockholders’ equity |  |  |  |
| Current liabilities: |  |  |  |
| Accounts payable | $ | 128.3 |  |  | $ | 128.0 |  |
| Accrued compensation | 395.1 |  |  | 461.1 |  |
| Accrued and other liabilities | 328.9 |  |  | 399.2 |  |
| Deferred revenue | 3,942.5 |  |  | 3,641.2 |  |
| Convertible senior notes, net | 3,680.3 |  |  | 3,676.8 |  |
| Total current liabilities | 8,475.1 |  |  | 8,306.3 |  |
| Long-term deferred revenue | 3,611.5 |  |  | 3,352.8 |  |
| Long-term operating lease liabilities | 274.2 |  |  | 276.1 |  |
| Other long-term liabilities | 73.6 |  |  | 108.4 |  |
| Total liabilities | 12,434.4 |  |  | 12,043.6 |  |
| Stockholders’ equity: |  |  |  |
| Preferred stock | — |  |  | — |  |
| Common stock and additional paid-in capital | 2,303.0 |  |  | 1,932.7 |  |
| Accumulated other comprehensive loss | (11.1) |  |  | (55.6) |  |
| Accumulated deficit | (1,562.9) |  |  | (1,667.1) |  |
| Total stockholders’ equity | 729.0 |  |  | 210.0 |  |
| Total liabilities and stockholders’ equity | $ | 13,163.4 |  |  | $ | 12,253.6 |  |

[0001327567-23-000005:8k_2_02:64]
10
