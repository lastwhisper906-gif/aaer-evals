# PANW note change history — 0001327567-22-000038 → 0001327567-23-000006


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2023-02-22):
[0001327567-23-000006:note_history:1]
In order to reduce manufacturing lead times and plan for adequate supply, we enter into agreements with manufacturing partners and component suppliers to procure inventory based on our demand forecasts. The following table presents details of the aggregate future minimum or fixed purchase commitments under these arrangements, excluding obligations under contracts that we can cancel as of January 31, 2023 (in millions):
  (was, 2022-11-18, similarity 0.9832):
[0001327567-22-000038:note_history:1]
In order to reduce manufacturing lead times and plan for adequate supply, we enter into agreements with manufacturing partners and component suppliers to procure inventory based on our demand forecasts. The following table presents details of the aggregate future minimum or fixed purchase commitments under these arrangements, excluding obligations under contracts that we can cancel as of October 31, 2022 (in millions):

- changed (2023-02-22):
[0001327567-23-000006:note_history:2]
We have entered into various non-cancelable agreements with certain service providers, under which we are committed to minimum or fixed purchases. The following table presents details of the aggregate future non-cancelable purchase commitments under these agreements as of January 31, 2023 (in millions):
  (was, 2022-11-18, similarity 0.9766):
[0001327567-22-000038:note_history:2]
We have entered into various non-cancelable agreements with certain service providers, under which we are committed to minimum or fixed purchases. The following table presents details of the aggregate future non-cancelable purchase commitments under these agreements as of October 31, 2022 (in millions):

- changed (2023-02-22):
[0001327567-23-000006:note_history:3]
To the extent there is a reasonable possibility that a loss exceeding amounts already recognized may be incurred and the amount of such additional loss would be material, we will either disclose the estimated additional loss or state that such an estimate cannot be made. As of January 31, 2023, we have not recorded any significant accruals for loss contingencies associated with such legal proceedings, determined that an unfavorable outcome is probable or reasonably possible, or determined that the amount or range of any possible loss is reasonably estimable.
  (was, 2022-11-18, similarity 0.9875):
[0001327567-22-000038:note_history:3]
To the extent there is a reasonable possibility that a loss exceeding amounts already recognized may be incurred and the amount of such additional loss would be material, we will either disclose the estimated additional loss or state that such an estimate cannot be made. As of October 31, 2022, we have not recorded any significant accruals for loss contingencies associated with such legal proceedings, determined that an unfavorable outcome is probable or reasonably possible, or determined that the amount or range of any possible loss is reasonably estimable.


## us-gaap:OrganizationConsolidationBasisOfPresentationBusinessDescriptionAndAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2023-02-22):
[0001327567-23-000006:note_history:4]
There have been no material changes to our significant accounting policies as of and for the six months ended January 31, 2023, as compared to the significant accounting policies described in our Annual Report on Form 10-K for the fiscal year ended July 31, 2022.
  (was, 2022-11-18, similarity 0.9004):
[0001327567-22-000038:note_history:4]
There have been no material changes to our significant accounting policies as of and for the three months ended October 31, 2022, as compared to the significant accounting policies described in our Annual Report on Form 10-K for the fiscal year ended July 31, 2022.


## us-gaap:ConvertibleDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2023-02-22):
[0001327567-23-000006:note_history:5]
|  | January 31, 2023 | July 31, 2022 |
|  | 2023 Notes |  | 2025 Notes |  | Total |  | 2023 Notes |  | 2025 Notes |  | Total |
| Liability component: |  |  |  |  |  |  |  |  |  |  |  |
| Principal | $ | 1,691.9 |  |  | $ | 1,999.4 |  |  | $ | 3,691.3 |  |  | $ | 1,691.9 |  |  | $ | 1,999.4 |  |  | $ | 3,691.3 |  |
| Less: debt discount and debt issuance costs, net of amortization | (1.2) |  |  | (9.8) |  |  | (11.0) |  |  | (2.6) |  |  | (11.9) |  |  | (14.5) |  |
| Net carrying amount | $ | 1,690.7 |  |  | $ | 1,989.6 |  |  | $ | 3,680.3 |  |  | $ | 1,689.3 |  |  | $ | 1,987.5 |  |  | $ | 3,676.8 |  |
  (was, 2022-11-18, similarity 0.9867):
[0001327567-22-000038:note_history:5]
|  | October 31, 2022 | July 31, 2022 |
|  | 2023 Notes |  | 2025 Notes |  | Total |  | 2023 Notes |  | 2025 Notes |  | Total |
| Liability component: |  |  |  |  |  |  |  |  |  |  |  |
| Principal | $ | 1,691.9 |  |  | $ | 1,999.4 |  |  | $ | 3,691.3 |  |  | $ | 1,691.9 |  |  | $ | 1,999.4 |  |  | $ | 3,691.3 |  |
| Less: debt discount and debt issuance costs, net of amortization | (1.9) |  |  | (10.8) |  |  | (12.7) |  |  | (2.6) |  |  | (11.9) |  |  | (14.5) |  |
| Net carrying amount | $ | 1,690.0 |  |  | $ | 1,988.6 |  |  | $ | 3,678.6 |  |  | $ | 1,689.3 |  |  | $ | 1,987.5 |  |  | $ | 3,676.8 |  |


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2023-02-22):
[0001327567-23-000006:note_history:6]
The conversion price will be subject to adjustment in some events. Holders of the Notes of a series who convert their Notes of such series in connection with certain corporate events that constitute a “make-whole fundamental change” under the applicable Indenture are, under certain circumstances, entitled to an increase in the conversion rate for such series of Notes. Additionally, upon the occurrence of a corporate event that constitutes a “fundamental change” under the applicable Indenture, holders of the Notes of such series may require us to repurchase for cash all or a portion of the Notes of such series at a repurchase price equal to 100% of the principal amount of the Notes of such series plus accrued and unpaid interest to, but excluding, the fundamental change repurchase date.
  (was, 2022-11-18, similarity 0.9056):
[0001327567-22-000038:note_history:6]
The conversion price will be subject to adjustment in some events. Holders of the Notes of a series who convert their Notes of such series in connection with certain corporate events that constitute a “make-whole fundamental change” under the applicable Indenture are, under certain circumstances, entitled to an increase in the conversion rate for such series of Notes. Additionally, upon the occurrence of a corporate event that constitutes a “fundamental change” under the applicable Indenture, holders of the Notes of such series may require us to repurchase for cash all or a portion of the Notes of such series at a repurchase price equal to 100% of the

- added (2023-02-22):
[0001327567-23-000006:note_history:7]
The sale price condition for the Notes was met during the fiscal quarter ended January 31, 2023, and as a result, holders may convert their Notes at any time during the fiscal quarter ending April 30, 2023. The net carrying amount of the Notes was classified as a current liability on our condensed consolidated balance sheet as of January 31, 2023.

- changed (2023-02-22):
[0001327567-23-000006:note_history:8]
|  | January 31, 2023 | July 31, 2022 |
|  | 2023 Notes |  | 2025 Notes |  | Total |  | 2023 Notes |  | 2025 Notes |  | Total |
| Liability component: |  |  |  |  |  |  |  |  |  |  |  |
| Principal | $ | 1,691.9 |  |  | $ | 1,999.4 |  |  | $ | 3,691.3 |  |  | $ | 1,691.9 |  |  | $ | 1,999.4 |  |  | $ | 3,691.3 |  |
| Less: debt discount and debt issuance costs, net of amortization | (1.2) |  |  | (9.8) |  |  | (11.0) |  |  | (2.6) |  |  | (11.9) |  |  | (14.5) |  |
| Net carrying amount | $ | 1,690.7 |  |  | $ | 1,989.6 |  |  | $ | 3,680.3 |  |  | $ | 1,689.3 |  |  | $ | 1,987.5 |  |  | $ | 3,676.8 |  |
  (was, 2022-11-18, similarity 0.9867):
[0001327567-22-000038:note_history:8]
|  | October 31, 2022 | July 31, 2022 |
|  | 2023 Notes |  | 2025 Notes |  | Total |  | 2023 Notes |  | 2025 Notes |  | Total |
| Liability component: |  |  |  |  |  |  |  |  |  |  |  |
| Principal | $ | 1,691.9 |  |  | $ | 1,999.4 |  |  | $ | 3,691.3 |  |  | $ | 1,691.9 |  |  | $ | 1,999.4 |  |  | $ | 3,691.3 |  |
| Less: debt discount and debt issuance costs, net of amortization | (1.9) |  |  | (10.8) |  |  | (12.7) |  |  | (2.6) |  |  | (11.9) |  |  | (14.5) |  |
| Net carrying amount | $ | 1,690.0 |  |  | $ | 1,988.6 |  |  | $ | 3,678.6 |  |  | $ | 1,689.3 |  |  | $ | 1,987.5 |  |  | $ | 3,676.8 |  |

- added (2023-02-22):
[0001327567-23-000006:note_history:9]
The total estimated fair value of the 2023 Notes and 2025 Notes were $3.0 billion and $3.3 billion at January 31, 2023, respectively, and $3.2 billion and $3.5 billion at July 31, 2022, respectively. The fair value was determined based on the closing trading price per $100 of the applicable series of the Notes as of the last day of trading for the period. We consider the fair value of the Notes at January 31, 2023 and July 31, 2022 to be a Level 2 measurement. The fair value of the Notes is primarily affected by the trading price of our common stock and market interest rates.

- changed (2023-02-22):
[0001327567-23-000006:note_history:10]
|  | Three Months Ended January 31, |  | Six Months Ended January 31, |
|  | 2023 |  | 2022 |  | 2023 |  | 2022 |
|  | 2023 Notes |  | 2025 Notes |  | Total |  | 2023 Notes |  | 2025 Notes |  | Total |  | 2023 Notes |  | 2025 Notes |  | Total |  | 2023 Notes |  | 2025 Notes |  | Total |
| Contractual interest expense | $ | 3.2 |  | $ | 2.0 |  | $ | 5.2 |  |  | $ | 3.1 |  | $ | 1.9 |  |  | $ | 5.0 |  | $ | 6.4 |  | $ | 3.8 |  | $ | 10.2 |  |  | $ | 6.3 |  | $ | 3.8 |  | $ | 10.1 |  |
| Amortization of debt issuance costs | 0.7 |  | 1.0 |  | 1.7 |  |  | 0.7 |  | 1.1 |  |  | 1.8 |  | 1.4 |  | 2.1 |  | 3.5 |  |  | 1.4 |  | 2.2 |  | 3.6 |  |
| Total interest expense | $ | 3.9 |  | $ | 3.0 |  | $ | 6.9 |  |  | $ | 3.8 |  | $ | 3.0 |  |  | $ | 6.8 |  | $ | 7.8 |  | $ | 5.9 |  | $ | 13.7 |  |  | $ | 7.7 |  | $ | 6.0 |  | $ | 13.7 |  |
| Effective interest rate | 0.9 | % |  | 0.6 | % |  |  |  | 0.9 | % |  | 0.6 | % |  |  |  | 0.9 | % |  | 0.6 | % |  |  |  | 0.9 | % |  | 0.6 | % |  |  |
  (was, 2022-11-18, similarity 0.6402):
[0001327567-22-000038:note_history:10]
|  |  |  | Three Months Ended October 31, |
|  |  |  |  |  | 2022 |  | 2021 |
|  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 2023 Notes |  | 2025 Notes |  | Total |  | 2023 Notes |  | 2025 Notes |  | Total |
| Contractual interest expense |  |  |  |  |  |  |  |  |  |  |  |  |  |  | $ | 3.2 |  | $ | 1.8 |  | $ | 5.0 |  |  | $ | 3.2 |  | $ | 1.9 |  | $ | 5.1 |  |
| Amortization of debt issuance costs |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 0.7 |  | 1.1 |  | 1.8 |  |  | 0.7 |  | 1.1 |  | 1.8 |  |
| Total interest expense |  |  |  |  |  |  |  |  |  |  |  |  |  |  | $ | 3.9 |  | $ | 2.9 |  | $ | 6.8 |  |  | $ | 3.9 |  | $ | 3.0 |  | $ | 6.9 |  |
| Effective interest rate |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 0.9 | % |  | 0.6 | % |  |  |  | 0.9 | % |  | 0.6 | % |  |  |

- changed (2023-02-22):
[0001327567-23-000006:note_history:11]
As of January 31, 2023, there were no amounts outstanding and we were in compliance with all covenants under the Credit Agreement.
  (was, 2022-11-18, similarity 0.9516):
[0001327567-22-000038:note_history:11]
As of October 31, 2022, there were no amounts outstanding and we were in compliance with all covenants under the Credit Agreement.

- removed (2023-02-22):
[0001327567-22-000038:note_history:12]
principal amount of the Notes of such series plus accrued and unpaid interest to, but excluding, the fundamental change repurchase date.

- removed (2023-02-22):
[0001327567-22-000038:note_history:13]
The sale price condition for the Notes was met during the fiscal quarter ended October 31, 2022, and as a result, holders may convert their Notes at any time during the fiscal quarter ending January 31, 2023. The net carrying amount of the Notes was classified as a current liability on our condensed consolidated balance sheet as of October 31, 2022.

- removed (2023-02-22):
[0001327567-22-000038:note_history:14]
The total estimated fair value of the 2023 Notes and 2025 Notes were $3.3 billion and $3.5 billion at October 31, 2022, respectively, and $3.2 billion and $3.5 billion at July 31, 2022, respectively. The fair value was determined based on the closing trading price per $100 of the applicable series of the Notes as of the last day of trading for the period. We consider the fair value of the Notes at October 31, 2022 and July 31, 2022 to be a Level 2 measurement. The fair value of the Notes is primarily affected by the trading price of our common stock and market interest rates.


## us-gaap:DebtSecuritiesAvailableForSaleTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2023-02-22):
[0001327567-23-000006:note_history:15]
The following tables summarize the amortized cost, unrealized gains and losses, and fair value of our available-for-sale debt securities as of January 31, 2023 and July 31, 2022 (in millions):
  (was, 2022-11-18, similarity 0.967):
[0001327567-22-000038:note_history:15]
The following tables summarize the amortized cost, unrealized gains and losses, and fair value of our available-for-sale debt securities as of October 31, 2022 and July 31, 2022 (in millions):

- changed (2023-02-22):
[0001327567-23-000006:note_history:16]
|  | January 31, 2023 |
|  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Fair Value |
| Cash equivalents: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 6.5 |  |  | $ | — |  |  | $ | — |  |  | $ | 6.5 |  |
| Commercial paper | 175.2 |  |  | — |  |  | — |  |  | 175.2 |  |
| Corporate debt securities | 24.5 |  |  | — |  |  | — |  |  | 24.5 |  |
| Total available-for-sale cash equivalents | $ | 206.2 |  |  | $ | — |  |  | $ | — |  |  | $ | 206.2 |  |
| Investments: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 210.8 |  |  | $ | — |  |  | $ | — |  |  | $ | 210.8 |  |
| Commercial paper | 631.4 |  |  | 0.2 |  |  | (0.7) |  |  | 630.9 |  |
| Corporate debt securities | 2,927.9 |  |  | 9.0 |  |  | (18.8) |  |  | 2,918.1 |  |
| U.S. government and agency securities | 518.4 |  |  | — |  |  | (5.3) |  |  | 513.1 |  |
| Non-U.S. government and agency securities | 68.8 |  |  | — |  |  | (0.7) |  |  | 68.1 |  |
| Asset-backed securities | 481.7 |  |  | 1.0 |  |  | (2.5) |  |  | 480.2 |  |
| Total available-for-sale investments | $ | 4,839.0 |  |  | $ | 10.2 |  |  | $ | (28.0) |  |  | $ | 4,821.2 |  |
  (was, 2022-11-18, similarity 0.9484):
[0001327567-22-000038:note_history:16]
|  | October 31, 2022 |
|  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Fair Value |
| Cash equivalents: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 150.6 |  |  | $ | — |  |  | $ | — |  |  | $ | 150.6 |  |
| Commercial paper | 338.5 |  |  | — |  |  | — |  |  | 338.5 |  |
| Corporate debt securities | 37.3 |  |  | — |  |  | (0.1) |  |  | 37.2 |  |
| U.S. government and agency securities | 159.9 |  |  | — |  |  | — |  |  | 159.9 |  |
| Total available-for-sale cash equivalents | $ | 686.3 |  |  | $ | — |  |  | $ | (0.1) |  |  | $ | 686.2 |  |
| Investments: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 213.3 |  |  | $ | — |  |  | $ | (0.3) |  |  | $ | 213.0 |  |
| Commercial paper | 289.4 |  |  | — |  |  | (1.1) |  |  | 288.3 |  |
| Corporate debt securities | 2,321.6 |  |  | 0.4 |  |  | (36.8) |  |  | 2,285.2 |  |
| U.S. government and agency securities | 605.3 |  |  | — |  |  | (8.2) |  |  | 597.1 |  |
| Non-U.S. government and agency securities | 80.0 |  |  | — |  |  | (1.1) |  |  | 78.9 |  |
| Asset-backed securities | 372.8 |  |  | — |  |  | (4.1) |  |  | 368.7 |  |
| Total available-for-sale investments | $ | 3,882.4 |  |  | $ | 0.4 |  |  | $ | (51.6) |  |  | $ | 3,831.2 |  |


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2023-02-22):
[0001327567-23-000006:note_history:17]
The following tables summarize the amortized cost, unrealized gains and losses, and fair value of our available-for-sale debt securities as of January 31, 2023 and July 31, 2022 (in millions):
  (was, 2022-11-18, similarity 0.967):
[0001327567-22-000038:note_history:17]
The following tables summarize the amortized cost, unrealized gains and losses, and fair value of our available-for-sale debt securities as of October 31, 2022 and July 31, 2022 (in millions):

- changed (2023-02-22):
[0001327567-23-000006:note_history:18]
|  | January 31, 2023 |
|  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Fair Value |
| Cash equivalents: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 6.5 |  |  | $ | — |  |  | $ | — |  |  | $ | 6.5 |  |
| Commercial paper | 175.2 |  |  | — |  |  | — |  |  | 175.2 |  |
| Corporate debt securities | 24.5 |  |  | — |  |  | — |  |  | 24.5 |  |
| Total available-for-sale cash equivalents | $ | 206.2 |  |  | $ | — |  |  | $ | — |  |  | $ | 206.2 |  |
| Investments: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 210.8 |  |  | $ | — |  |  | $ | — |  |  | $ | 210.8 |  |
| Commercial paper | 631.4 |  |  | 0.2 |  |  | (0.7) |  |  | 630.9 |  |
| Corporate debt securities | 2,927.9 |  |  | 9.0 |  |  | (18.8) |  |  | 2,918.1 |  |
| U.S. government and agency securities | 518.4 |  |  | — |  |  | (5.3) |  |  | 513.1 |  |
| Non-U.S. government and agency securities | 68.8 |  |  | — |  |  | (0.7) |  |  | 68.1 |  |
| Asset-backed securities | 481.7 |  |  | 1.0 |  |  | (2.5) |  |  | 480.2 |  |
| Total available-for-sale investments | $ | 4,839.0 |  |  | $ | 10.2 |  |  | $ | (28.0) |  |  | $ | 4,821.2 |  |
  (was, 2022-11-18, similarity 0.9484):
[0001327567-22-000038:note_history:18]
|  | October 31, 2022 |
|  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Fair Value |
| Cash equivalents: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 150.6 |  |  | $ | — |  |  | $ | — |  |  | $ | 150.6 |  |
| Commercial paper | 338.5 |  |  | — |  |  | — |  |  | 338.5 |  |
| Corporate debt securities | 37.3 |  |  | — |  |  | (0.1) |  |  | 37.2 |  |
| U.S. government and agency securities | 159.9 |  |  | — |  |  | — |  |  | 159.9 |  |
| Total available-for-sale cash equivalents | $ | 686.3 |  |  | $ | — |  |  | $ | (0.1) |  |  | $ | 686.2 |  |
| Investments: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 213.3 |  |  | $ | — |  |  | $ | (0.3) |  |  | $ | 213.0 |  |
| Commercial paper | 289.4 |  |  | — |  |  | (1.1) |  |  | 288.3 |  |
| Corporate debt securities | 2,321.6 |  |  | 0.4 |  |  | (36.8) |  |  | 2,285.2 |  |
| U.S. government and agency securities | 605.3 |  |  | — |  |  | (8.2) |  |  | 597.1 |  |
| Non-U.S. government and agency securities | 80.0 |  |  | — |  |  | (1.1) |  |  | 78.9 |  |
| Asset-backed securities | 372.8 |  |  | — |  |  | (4.1) |  |  | 368.7 |  |
| Total available-for-sale investments | $ | 3,882.4 |  |  | $ | 0.4 |  |  | $ | (51.6) |  |  | $ | 3,831.2 |  |

- added (2023-02-22):
[0001327567-23-000006:note_history:19]
As of January 31, 2023, the gross unrealized losses that have been in a continuous unrealized loss position for less than 12 months were $17.2 million, which were related to $2.5 billion of available-for-sale debt securities, and the gross unrealized losses that have been in a continuous unrealized loss position for more than 12 months were $10.8 million, which were related to $571.6 million of available-for-sale debt securities. As of July 31, 2022 the gross unrealized losses that have been in a continuous unrealized loss position for less than 12 months were $24.8 million, which were related to $2.0 billion of available-for-sale debt securities, and the gross unrealized losses that have been in a continuous unrealized loss position for more than 12 months were not material.

- changed (2023-02-22):
[0001327567-23-000006:note_history:20]
Unrealized losses related to our available-for-sale debt securities are due to interest rate fluctuations as opposed to credit quality. We do not intend to sell any of the securities in an unrealized loss position and it is not likely that we would be required to sell these securities before recovery of their amortized cost basis, which may be at maturity. We did not recognize any credit losses related to our available-for-sale debt securities during the three and six months ended January 31, 2023 and 2022.
  (was, 2022-11-18, similarity 0.978):
[0001327567-22-000038:note_history:20]
Unrealized losses related to our available-for-sale debt securities are due to interest rate fluctuations as opposed to credit quality. We do not intend to sell any of the securities in an unrealized loss position and it is not likely that we would be required to sell these securities before recovery of their amortized cost basis, which may be at maturity. We did not recognize any credit losses related to our available-for-sale debt securities during the three months ended October 31, 2022 and 2021.

- changed (2023-02-22):
[0001327567-23-000006:note_history:21]
The following table summarizes the amortized cost and fair value of our available-for-sale debt securities as of January 31, 2023, by contractual years-to-maturity (in millions):
  (was, 2022-11-18, similarity 0.9651):
[0001327567-22-000038:note_history:21]
The following table summarizes the amortized cost and fair value of our available-for-sale debt securities as of October 31, 2022, by contractual years-to-maturity (in millions):

- changed (2023-02-22):
[0001327567-23-000006:note_history:22]
Marketable equity securities consist of money market funds and are included in cash and cash equivalents on our condensed consolidated balance sheets. As of January 31, 2023 and July 31, 2022, the carrying values of our marketable equity securities were $655.9 million and $1.2 billion, respectively. There were no unrealized gains or losses recognized for these securities during the three and six months ended January 31, 2023 and 2022.
  (was, 2022-11-18, similarity 0.8775):
[0001327567-22-000038:note_history:22]
Marketable equity securities consist of money market funds and are included in cash and cash equivalents on our condensed consolidated balance sheets. As of October 31, 2022 and July 31, 2022, the carrying values of our marketable equity securities were $933.2 million and $1.2 billion, respectively. There were no unrealized gains or losses recognized for these securities during the three months ended October 31, 2022 and 2021.

- removed (2023-02-22):
[0001327567-22-000038:note_history:23]
As of October 31, 2022, the gross unrealized losses that have been in a continuous unrealized loss position for less than 12 months were $45.7 million, which were related to $3.5 billion of available-for-sale debt securities, and the gross unrealized losses that have been in a continuous unrealized loss position for more than 12 months were not material. As of July 31, 2022 the gross unrealized losses that have been in a continuous unrealized loss position for less than 12 months were $24.8 million, which were related to $2.0 billion of available-for-sale debt securities, and the gross unrealized losses that have been in a continuous unrealized loss position for more than 12 months were not material.


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- added (2023-02-22):
[0001327567-23-000006:note_history:24]
|  | Three Months Ended January 31, |  | Six Months Ended January 31, |
|  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Revenue: |  |  |  |  |  |  |  |
| Americas |  |  |  |  |  |  |  |
| United States | $ | 1,042.3 |  |  | $ | 858.6 |  |  | $ | 2,048.6 |  |  | $ | 1,670.3 |  |
| Other Americas | 74.7 |  |  | 57.3 |  |  | 139.1 |  |  | 112.3 |  |
| Total Americas | 1,117.0 |  |  | 915.9 |  |  | 2,187.7 |  |  | 1,782.6 |  |
| Europe, the Middle East, and Africa (“EMEA”) | 341.5 |  |  | 252.2 |  |  | 649.4 |  |  | 486.0 |  |
| Asia Pacific and Japan (“APAC”) | 196.6 |  |  | 148.8 |  |  | 381.4 |  |  | 295.7 |  |
| Total revenue | $ | 1,655.1 |  |  | $ | 1,316.9 |  |  | $ | 3,218.5 |  |  | $ | 2,564.3 |  |

- added (2023-02-22):
[0001327567-23-000006:note_history:25]
|  | Three Months Ended January 31, |  | Six Months Ended January 31, |
|  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Revenue: |  |  |  |  |  |  |  |
| Product | $ | 352.9 |  |  | $ | 308.0 |  |  | $ | 682.9 |  |  | $ | 603.5 |  |
| Subscription and support |  |  |  |  |  |  |  |
| Subscription | 815.4 |  |  | 618.0 |  |  | 1,579.4 |  |  | 1,196.8 |  |
| Support | 486.8 |  |  | 390.9 |  |  | 956.2 |  |  | 764.0 |  |
| Total subscription and support | 1,302.2 |  |  | 1,008.9 |  |  | 2,535.6 |  |  | 1,960.8 |  |
| Total revenue | $ | 1,655.1 |  |  | $ | 1,316.9 |  |  | $ | 3,218.5 |  |  | $ | 2,564.3 |  |

- changed (2023-02-22):
[0001327567-23-000006:note_history:26]
During the six months ended January 31, 2023 and 2022, we recognized approximately $2.1 billion and $1.6 billion of revenue pertaining to amounts that were deferred as of July 31, 2022 and 2021, respectively.
  (was, 2022-11-18, similarity 0.9412):
[0001327567-22-000038:note_history:26]
During the three months ended October 31, 2022 and 2021, we recognized approximately $1.1 billion and $840.0 million of revenue pertaining to amounts that were deferred as of July 31, 2022 and 2021, respectively.

- changed (2023-02-22):
[0001327567-23-000006:note_history:27]
Remaining performance obligations were $8.8 billion as of January 31, 2023, of which we expect to recognize as revenue approximately $4.4 billion over the next 12 months and the remainder thereafter.
  (was, 2022-11-18, similarity 0.9681):
[0001327567-22-000038:note_history:27]
Remaining performance obligations were $8.3 billion as of October 31, 2022, of which we expect to recognize as revenue approximately $4.2 billion over the next 12 months and the remainder thereafter.

- removed (2023-02-22):
[0001327567-22-000038:note_history:28]
|  |  |  | Three Months Ended October 31, |
|  |  |  |  |  | 2022 |  | 2021 |
| Revenue: |  |  |  |  |  |  |  |
| Americas |  |  |  |  |  |  |  |
| United States |  |  |  |  | $ | 1,006.3 |  |  | $ | 811.7 |  |
| Other Americas |  |  |  |  | 64.4 |  |  | 55.0 |  |
| Total Americas |  |  |  |  | 1,070.7 |  |  | 866.7 |  |
| Europe, the Middle East, and Africa (“EMEA”) |  |  |  |  | 307.9 |  |  | 233.8 |  |
| Asia Pacific and Japan (“APAC”) |  |  |  |  | 184.8 |  |  | 146.9 |  |
| Total revenue |  |  |  |  | $ | 1,563.4 |  |  | $ | 1,247.4 |  |

- removed (2023-02-22):
[0001327567-22-000038:note_history:29]
|  |  |  | Three Months Ended October 31, |
|  |  |  |  |  | 2022 |  | 2021 |
| Revenue: |  |  |  |  |  |  |  |
| Product |  |  |  |  | $ | 330.0 |  |  | $ | 295.5 |  |
| Subscription and support |  |  |  |  |  |  |  |
| Subscription |  |  |  |  | 764.0 |  |  | 578.8 |  |
| Support |  |  |  |  | 469.4 |  |  | 373.1 |  |
| Total subscription and support |  |  |  |  | 1,233.4 |  |  | 951.9 |  |
| Total revenue |  |  |  |  | $ | 1,563.4 |  |  | $ | 1,247.4 |  |


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: no_current_note, score: 0.0

- removed (2023-02-22):
[0001327567-22-000038:note_history:30]
Subsequent Event
Business Combination

- removed (2023-02-22):
[0001327567-22-000038:note_history:31]
On November 17, 2022, we entered into a definitive agreement to acquire Cider Security Ltd., a privately-held cyber security company, for total consideration of approximately $250.0 million, including approximately $194.6 million in cash and approximately $55.4 million in replacement equity awards, subject to adjustment. We expect the acquisition will support Prisma Cloud’s platform approach to securing the entire application security lifecycle from code-to-cloud. The proposed acquisition is expected to close during our second quarter of fiscal 2023, subject to the satisfaction of customary closing conditions.
